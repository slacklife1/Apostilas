These files are meant to be sample files to help you use the
Java2 applet with your forum. Please make sure that your forum
is already working, then these sample files should provide
you with enough info to get your applet working.

Only the forumapplet.html need to be edited, leave the jar
in the sample directory as the forumapplet.html file.

*) You need to change the ForumFile parameter in two places (wherever
it appears in the html).

*) You also need to change the ServletURL parameter to tell the applet
what servlet to call...  It should be something like
 http://mydomain/servlet/com.ondelette.servlet.webforum.WebForumGenericServlet

Daniel Lemire, Ph.D.
http://www.ondelette.com
December 29th,2000
