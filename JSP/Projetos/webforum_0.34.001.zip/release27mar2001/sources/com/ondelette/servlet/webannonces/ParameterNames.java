

package com.ondelette.servlet.webannonces;

public interface ParameterNames {

  public static String DELETE = "_DELETE_";
  public static String ANNONCEFILEPARAM = "_ANNONCEFILE_";
  public static String SUBJECTPARAM = "_SUBJECT_";
  public static String URLPARAM = "_URL_";
  public static String EMAILPARAM = "_EMAIL_";
  public static String AUTHORPARAM = "_AUTHOR_";
  public static String PHONENUMBERPARAM = "_PHONENUMBER_";
  public static String ADDRESSPARAM= "_ADDRESS_";
  public static String ANNONCEPARAM = "_ANNONCE_";
  public static String ADMINPARAM = "_ADMIN_";

} 