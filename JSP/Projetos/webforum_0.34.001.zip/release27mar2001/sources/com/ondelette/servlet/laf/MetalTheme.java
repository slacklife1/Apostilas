

package com.ondelette.servlet.laf;

public class MetalTheme {

  public MetalTheme() {
  }
} 