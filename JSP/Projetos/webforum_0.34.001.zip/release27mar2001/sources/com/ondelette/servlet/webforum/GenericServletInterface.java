
package com.ondelette.servlet.webforum;

public interface GenericServletInterface {

  public final static char GET = 'g';
  public final static char PUT = 'p';
  public final static char END = 'e';
  //
  public final static char PAGE = 'P';
  public final static char MESSAGE = 'M';



}