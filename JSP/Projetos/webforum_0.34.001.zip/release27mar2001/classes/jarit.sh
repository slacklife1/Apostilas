jar cvf SwingForumApplet.jar *.gif com/ondelette/servlet/*.class com/ondelette/servlet/webforum/*.class com/ondelette/servlet/laf/*.class

