/**
 * CSCounter.java
 * Benjamin Sherman
 * CoolServlets.com
 * January 12, 2000
 * Version 1.4
 *
 * Any errors or feature requests can be reported on CoolServlets.com.
 * We hope you enjoy this program!
 *
 *    Copyright (C) 2000  Matt Tucker, Benjamin Sherman 
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 * 
 *    This program is distributed in the hope that it will be useful, 
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of 
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 *    GNU General Public License for more details. 
 * 
 *    You should have received a copy of the GNU General Public License 
 *    along with this program; if not, write to the Free Software 
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

import javax.servlet.*; 
import javax.servlet.http.*; 
import java.io.*; 
import java.util.*;
import java.lang.*;
import java.lang.reflect.Array; 
import com.coolservlets.textcounter.*; 
import com.coolservlets.util.*; 
import java.text.SimpleDateFormat; 
 
/** 
 * The main Java servlet for the CSCounter system.
 *
 * @author  Benjamin Sherman
 * @version 1.4
 */ 
public class CSCounter extends HttpServlet implements MaintainedServlet { 
    
    /** 
     * Initializes the servlet variables including the database, configuration 
     * settings, and maintenance thread. 
     */ 
    public void init(ServletConfig config) throws ServletException { 
	super.init(config); 
	//Read the text counter database from file 
	database = readDatabaseFile(); 
	/**
	 * We want to save the state of the servlet periodically to protect 
	 * against loss of data with servlet crashes. Use a maintenance thread 
	 * to do this every 20 minutes. Writing to file after every hit would 
	 * be inefficient. 
	 */
	maintenance = new ServletMaintenance(this,20,ServletMaintenance.MINUTES); 
	/**
	 * An object that formats dates to make them look nice. 
	 */
	simpleDate = new SimpleDateFormat(); 
	simpleDate.applyPattern("MMMM d, yyyy"); 
    } 
    /** 
     * Process the HTTP Get request. It will simply call the post function 
     */ 
    public void doGet(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException, IOException { 
	doPost( request, response ); 
    } 
    /** 
     * Process the HTTP Post request. 
     */ 
    public void doPost(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException, IOException { 
	
	response.setContentType("text/html"); 
	PrintWriter out = response.getWriter(); 
	
	/**
	 * The user can specify what font to use else the default "classic" font is used
	 * fontURL is the URL to a dircectory containing gif files named 0.gif, 1.gif etc..
	 * up to 9.gif.  user can add more fonts to the by placing a directory with gif images
	 * named in this fashion and passing in that fontURL
	 * The URL is the URL that your web browser would use
	 * defaults are classic, muffin, and silver
	 */
	String fontURL = request.getParameter("fontURL");
	
	/**
	 * The user can specify the key in the query string. If it is not specified, 
	 * a key will automatically be generated based on the URL of the calling page. 
	 */
	String key = request.getParameter("key"); 
	if (key == null) 
	    key = request.getRequestURI(); 
	
	String action = request.getParameter("action"); 
	/**
	 * User wants the current count (default). 
	 */
	if (action == null || action.equals("getCount")) { 
	    int countedint = database.getCount(key);
	    String countedstring = countedint + "";
	    char counted[] = countedstring.toCharArray();
	    int charlength = counted.length;
	    /**
	     * if fontURL is null (not specified), we will use plain text
	     */
	    if (fontURL == null) {
		for(int k=0; k < charlength; k++)
		    out.print(counted[k]);
	    }
	    /**
	     * otherwise we specified a font and will output the GIF counter
	     */
	    else {
		for(int k= 0; k < charlength; k++) 
		    out.print("<img src=\""+fontURL+"/"+counted[k]+".gif"+"\">");
	    }
	    
	}
	/**
	 * User wants the date the counter was created. 
	 */
	else if (action.equals("getDate")) 
	    out.println(simpleDate.format(database.getDate(key))); 
	out.close(); 
    } 
    /** 
     * Tasks that we want performed periodically. We'll simply save the counter 
     * database to disk. This method will be called by the ServletMaintenance 
     * object. 
     */ 
    public void doMaintenance() { 
	writeDatabaseFile(); 
    } 
    /** 
     * Returns servlet information 
     */ 
    public String getServletInfo() { 
	
	return "CSCounter 1.4 - CoolServlets.com"; 
    } 
    /** 
     * Called as the servlet is being destroyed. It saves the counter database 
     * and stops the maintenance thread. 
     */ 
    public void destroy() { 
	writeDatabaseFile(); 
	maintenance.shutDown(); 
    } 
    /** 
     * Writes the database file to disk. 
     */ 
    public synchronized void writeDatabaseFile() { 
	try { 
	    ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("coolservlets/data/CounterDatabase")); 
	    out.writeObject(database); 
	    out.close(); 
	} 
	catch (Exception e) {  } 
    } 
    /** 
     * Reads the database file from disk. 
     */ 
    private synchronized TextCounterDatabase readDatabaseFile() { 
	TextCounterDatabase tempdatabase = new TextCounterDatabase(); 
	try { 
	    ObjectInputStream in = new ObjectInputStream(new FileInputStream("coolservlets/data/CounterDatabase")); 
	    tempdatabase = (TextCounterDatabase)in.readObject(); 
	    in.close(); 
	} 
	catch (Exception e) { } 
	return tempdatabase; 
    } 
    
    private ServletMaintenance maintenance; 
    private TextCounterDatabase database; 
    private SimpleDateFormat simpleDate; 
} 








