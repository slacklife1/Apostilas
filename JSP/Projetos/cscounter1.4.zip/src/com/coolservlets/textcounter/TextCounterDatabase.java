/**
 * TextCounterDatabase.java
 * Matt Tucker
 * CoolServlets.com
 * April 26, 1999
 * Version 1.3
 *
 *    Copyright (C) 1999  Matt Tucker
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.coolservlets.textcounter;

import java.util.*;
import java.io.Serializable;

/**
 * A database that contains all of the active counters.
 *
 * Count records can be retrieved by a key. If an unrecognized key comes
 * through, a new counter will automatically be created.
 *
 * @author  Matt Tucker
 * @version 1.3
 */
public class TextCounterDatabase implements Serializable {

  public TextCounterDatabase() {
    database = new Hashtable();
  }
  /**
   * Looks for the requested counter in the database based on the provided
   * key. If no counter is found, it will create a new one. Getting the count
   * also increments the count.
   */
  public int getCount(String key) {
    if (database.containsKey(key))
      return ((TextCounter)(database.get(key))).getCount();
    else {
      TextCounter newCounter = new TextCounter();
      database.put(key,newCounter);
      return newCounter.getCount();
    }
  }
  /**
   * Looks for the creation date of a counter based on a key. If the counter
   * referenced can't be found, a new counter is created.
   */
  public Date getDate(String key) {
    if (database.containsKey(key))
      return ((TextCounter)(database.get(key))).getDate();
    else {
      TextCounter newCounter = new TextCounter();
      database.put(key,newCounter);
      return newCounter.getDate();
    }
  }   
  private Hashtable database;
} 