package guestbook;

import java.util.*;

public class Guestbook {

    private List list = Collections.synchronizedList(new LinkedList());

    public Guestbook() { }
	
	public void addEntry(String name, String message) {
		list.add(new GuestbookEntry(name, message));
    }

    public List getList() {
		return list;
    }
}
