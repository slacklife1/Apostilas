package guestbook;

import java.util.Date;

public class GuestbookEntry {

    private Date date;
    private String name;
    private String message;

    public GuestbookEntry(String name, String message) {
	date = new Date();
	this.name = name;
	this.message = message;
    }

    public Date getDate() {
	return date;
    }

    public String getName() {
	return name;
    }

    public String getMessage() {
	return message;
    }
}
