README the version 1.52 of org.szegedi.expose packages
==============================================================

BUILDING THE PACKAGES
---------------------
Altough the classes are precompiled in the distribution, you can
compile them by yourself. You will need the Ant tool from the
Apache Jakarta project (http://jakarta.apache.org) to do the build.
You will also need the original Freemaker classes available on
http://freemarker.sourceforge.net, and a Servlet API jar with
javax.servlet.* packages. The aforementioned Jakarta contains such
Servlet API jar. A build batch for Windows is provided. I guess it
would be easy for a person with UNIX experience to produce an
appropriate shell script from the batch.

LICENSING
---------
org.szegedi.freemarker.* packages are released under a license that
is virtually equivalent with Apache 1.1 license. This means that as
long as you leave the copyright and disclaimer in each source file
intact, and you acknowledge the use of the packages in your product,
you comply with it.

CONTACT
-------

Expose official site is http://www.szegedi.org/expose.
E-mail concerning Expose should go to expose@szegedi.org.