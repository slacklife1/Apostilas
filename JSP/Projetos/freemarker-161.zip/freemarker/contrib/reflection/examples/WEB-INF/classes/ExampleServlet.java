/*
Copyright 1999 by Scriptum, Inc.,
M�lyva utca 34, H-6771 Szeged, Hungary
All rights reserved.

This software is the confidential and proprietary information
of Scriptum, Inc. ("Confidential Information").  You
shall not disclose such Confidential Information and shall use
it only in accordance with the terms of the license agreement
you entered into with Scriptum.
*/

import freemarker.template.*;
import org.szegedi.freemarker.servlet.*;
import org.szegedi.freemarker.model.StaticModels;
import javax.servlet.http.*;

/**
 *
 * @author Attila Szegedi, Scriptum Inc.
 * @version 1.0
 */

public class ExampleServlet
extends
	FreemarkerServlet
{
	protected boolean preTemplateProcess(HttpServletRequest request, HttpServletResponse response, Template template, TemplateModelRoot root)
	{
		root.put("Static", StaticModels.INSTANCE);
		return true;
	}
}
