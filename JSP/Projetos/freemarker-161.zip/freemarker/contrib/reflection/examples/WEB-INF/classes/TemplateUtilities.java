import java.io.*;

public class TemplateUtilities
{
	private static final java.util.Comparator fileComparator = new java.util.Comparator()
	{
		public int compare(Object obj1, Object obj2)
		{
			return ((File)obj1).getName().compareTo(((File)obj2).getName());
		}
	};

	public static File[] listSubfilesSorted(String name)
	{
		File[] files = new File(name).listFiles();
		java.util.Arrays.sort(files, fileComparator);
		return files;
	}
}
