/*
 * FreeMarker: a tool that allows Java programs to generate HTML
 * output using templates.
 * Copyright (C) 1998 Benjamin Geer
 * Email: beroul@yahoo.com
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA  02111-1307, USA.
 */

package freemarker.testcase;

import java.io.IOException;
import junit.framework.*;

/**
 * Dummy test case. This tests the AbstractTestCase class, by generating
 * a test that is identical to the reference text. The input file is identical
 * to the template file, and no transformation is performed.
 */
public class DummyTestCase extends AbstractTestCase {

    /** Creates new DummyTestCase, with a filename for the reference and
     * template files.
     */
    public DummyTestCase( String aTestname ) {
        super( aTestname );
    }

    public void setUp() {
        setUpFiles( "test-dummy.html" );
    }
    
    /**
     * Performs the test.
     */
    public void runTest() {
        String aOutput;

        aOutput =  m_aTemplateText;
        showTestResults( m_aReferenceText, aOutput );
    }

    /**
     * Main method for caaling the test in standalone mode.
     */
    public static void main(String args[]) {
        AbstractTestCase cTester = new DummyTestCase( "test-dummy.html" );
        TestResult cResults = new TestResult();

        cTester.run( cResults );
    }
}
