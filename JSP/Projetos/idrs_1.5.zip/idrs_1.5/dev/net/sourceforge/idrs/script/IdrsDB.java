package net.sourceforge.idrs.script;
/**
 * IdrsDB.java<p>
 * Copyright (C) 2000 Marc Boorshtein under the GNU General Public License offered
 * without warenty
 */
public interface IdrsDB {
  public boolean next() throws Exception;

  public String getFieldData(String fieldname,String format) throws Exception;
  public String getFieldData(String fieldname) throws Exception;
  public int  getUpdateResult() throws Exception;
  

  public boolean moveTo(int location) throws Exception;
}