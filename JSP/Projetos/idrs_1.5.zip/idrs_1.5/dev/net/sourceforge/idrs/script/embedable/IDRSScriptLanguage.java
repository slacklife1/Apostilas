package net.sourceforge.idrs.script.embedable;

public interface IDRSScriptLanguage {
  /**
   Used for <$= $>
  */
  public String eval(String cmd) throws Exception;
  
  /**
   Used for <$ $>
  */
  public void exec(String cmds) throws Exception;
  
  /**
    Used for extracting objects
  */
  public Object getVal(String obj) throws Exception;
  
  /**
   Used for setting object
  */
  public void setVal(String name,Object val) throws Exception;
  
  public void importClass(String className) throws Exception;
  
  
}