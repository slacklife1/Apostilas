import java.math.*;
import java.io.*;

public class GenData {
  public static void main(String[] args) throws Exception {
    int i;
    long randomNum;
    String fname, lname, email,phone;
    PrintStream out = new PrintStream(new FileOutputStream(new File("sample.sql")));
    for (i = 0;i <= 1000;i++) {
      randomNum = Math.round(Math.random() * 25);
      switch ((int) randomNum) {
        case 0 : fname = "Marc";break;
        case 1 : fname = "Jack";break;
        case 2 : fname = "Allison";break;
        case 3 : fname = "Jessy";break;
        case 4 : fname = "Joe";break;
        case 5 : fname = "Matt";break;
        case 6 : fname = "Daniella";break;
        case 7 : fname = "Erin";break;
        case 8 : fname = "Laura";break;
        case 10 : fname = "Chris";break;
        case 11 : fname = "Jason";break;
        case 12 : fname = "John";break;
        case 13 : fname = "Glen";break;
        case 14 : fname = "Harry";break;
        case 15 : fname = "Jennifer";break;
        case 16 : fname = "Stacy";break;
        case 17 : fname = "Caroline";break;
        case 18 : fname = "Judy";break;
        case 19 : fname = "Jorge";break;
        case 20 : fname = "Miguel";break;
        case 21 : fname = "Albert";break;
        case 22 : fname = "Dave";break;
        case 23 : fname = "Donna";break;
        case 24 : fname = "Darline";break;
        case 25 : fname = "Mallisa";break;
        default : fname = "Marc";
      }

      randomNum = Math.round(Math.random() * 25);
      switch ((int) randomNum) {
        case 0 : lname = "Borstein";break;
        case 1 : lname = "Jackson";break;
        case 2 : lname = "Alluway";break;
        case 3 : lname = "Venutuda";break;
        case 4 : lname = "Leberstien";break;
        case 5 : lname = "Masona";break;
        case 6 : lname = "Barrs";break;
        case 7 : lname = "Brokavich";break;
        case 8 : lname = "Tenoritz";break;
        case 10 : lname = "Wallis";break;
        case 11 : lname = "Patrick";break;
        case 12 : lname = "Johnson";break;
        case 13 : lname = "Hill";break;
        case 14 : lname = "Smith";break;
        case 15 : lname = "Lomis";break;
        case 16 : lname = "Aldman";break;
        case 17 : lname = "Peters";break;
        case 18 : lname = "McGoin";break;
        case 19 : lname = "Asando";break;
        case 20 : lname = "Rodrigez";break;
        case 21 : lname = "Alansky";break;
        case 22 : lname = "Danvers";break;
        case 23 : lname = "Ryan";break;
        case 24 : lname = "Summers";break;
        case 25 : lname = "Winters";break;
        default : lname = "Borstein";
      }

      email = fname.toLowerCase().charAt(0) + lname.toLowerCase() + "@somplace.com";

      randomNum = Math.round(Math.random() * 8999) + 1000;
      phone = "(614)-472-" + Long.toString(randomNum);
      out.println("INSERT INTO contacts VALUES(" + Integer.toString(i) + ",'" + fname + "','" + lname + "','" + email + "','" + phone + "');");
    }
  }
}