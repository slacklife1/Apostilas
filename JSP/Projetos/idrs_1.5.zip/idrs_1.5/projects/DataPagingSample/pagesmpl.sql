CREATE TABLE contacts (
  id int,
  first varchar(20),
  last varchar(20),
  email varchar(70),
  phone varchar(30)
);

INSERT INTO contacts VALUES(1,'Marc','Johnson','mjohnson@someplace.com','456-765-1234');
INSERT INTO contacts VALUES(2,'Marc','Jackson','mjackson@someplace.com','456-765-1434');
INSERT INTO contacts VALUES(3,'Matt','Jamenson','mjamenson@someplace.com','456-765-1221');
INSERT INTO contacts VALUES(4,'Joe','Johnson','jjohnson@someplace.com','456-765-1254');
INSERT INTO contacts VALUES(5,'Jack','Johnson','jajohnson@someplace.com','456-765-1634');
INSERT INTO contacts VALUES(6,'Jenifer','Alley','jalley@someplace.com','456-765-5284');
INSERT INTO contacts VALUES(7,'Jenifer','Decon','jdecon@someplace.com','456-765-1824');
INSERT INTO contacts VALUES(8,'Jason','Verding','jverding@someplace.com','456-765-2084');
INSERT INTO contacts VALUES(9,'Allison','Johnson','ajohnson@someplace.com','456-765-0954');
INSERT INTO contacts VALUES(10,'Laura','Tenowitz','ltenowitz@someplace.com','456-765-3084');
INSERT INTO contacts VALUES(11,'Sarah','Stellas','sstellas@someplace.com','456-765-9514');
INSERT INTO contacts VALUES(12,'Laura','Juhnson','ljuhnson@someplace.com','456-765-0987');
INSERT INTO contacts VALUES(13,'Amy','Tisleing','atisleingl@someplace.com','456-765-3076');
INSERT INTO contacts VALUES(14,'Harry','Balmer','hbalmer@someplace.com','456-765-4065');
INSERT INTO contacts VALUES(15,'Jessy','Abromitz','jabromitz@someplace.com','456-765-0719');
INSERT INTO contacts VALUES(16,'Jack','Clintun','jclintun@someplace.com','456-765-0504');
INSERT INTO contacts VALUES(17,'Devin','Darhome','ddarhome@someplace.com','456-765-7105');
INSERT INTO contacts VALUES(18,'Daron','Johnson','djohnson@someplace.com','456-765-0888');
INSERT INTO contacts VALUES(19,'Daron','Asding','dasding@someplace.com','456-765-1111');
INSERT INTO contacts VALUES(20,'Allison','Postin','apostin@someplace.com','456-765-1212');
INSERT INTO contacts VALUES(21,'Harry','Changte','hchangte@someplace.com','456-765-1000');
INSERT INTO contacts VALUES(22,'Sarah','Isding','sisding@someplace.com','456-765-9876');
INSERT INTO contacts VALUES(23,'Laura','Lausdin','llausdin@someplace.com','456-765-0192');
INSERT INTO contacts VALUES(24,'Devin','Johnington','jjohnington@someplace.com','456-765-4563');
INSERT INTO contacts VALUES(25,'Allison','Stellas','astellas@someplace.com','456-765-8761');