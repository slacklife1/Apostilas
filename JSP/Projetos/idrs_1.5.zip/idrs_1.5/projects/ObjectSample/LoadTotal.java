import java.sql.*;//classes for connecting to a database
import IdrsDB;  //Used to retrieve data from an IDRS result set

public class LoadTotal {
 private String totalFieldName;

 public LoadTotal(String totalFieldName) {
   this.totalFieldName = totalFieldName;  //This holds onto the what we're going to call the field that will hold the total cost
 }

 public ResultSet getTotalSet(Integer id, java.sql.Connection con) throws Exception {
   String sql = "SELECT sum(itemcost) as " + this.totalFieldName +" FROM invoice WHERE custid = " + id.toString() + ";"; //creates a SQL statement that we can then use to get the total
   Statement stmt = con.createStatement();
   return stmt.executeQuery(sql);
 }

 public String getTotal(String caption, IdrsDB db) throws Exception {
 String totalReturn;
 //returns the total amount stored
 String total = db.getFieldData(this.totalFieldName,"number, currency");
 totalReturn = "<td>"+ caption + "</td><td>"+ total + "</td>";
 return totalReturn;
 }

}

