import net.sourceforge.idrs.script.IDRSScript; //needed to have IDRS Scripting support
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class EchoClass {

  public EchoClass() {
  
  }
  
  public String echoInput(IDRSScript idrs) throws Exception {
    PrintWriter out = idrs.getOut(); //gets the output stream back to the client
    HttpServletRequest req = idrs.getRequest();
    out.println("<table>");
    out.println("<tr><td>ID</td><td>" + req.getParameter("input_id") + "</td></tr>");
    out.println("<tr><td>First Name</td><td>" + req.getParameter("input_first") + "</td></tr>");  
    out.println("<tr><td>Last Name</td><td>" + req.getParameter("input_last") + "</td></tr>");
    out.println("<tr><td>Phone</td><td>" + req.getParameter("input_phone") + "</td></tr>");
    out.println("<tr><td>Email</td><td>" + req.getParameter("input_email") + "</td></tr>");
    out.println("</table>");
    return ""; //no need for a return, everything was printed
  }

}