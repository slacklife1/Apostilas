/* ============================================================ */
/*   $RCSfile: Jive_sybase.sql,v $          */
/*   $Revision: 1.2.2.1 $         */
/*   $Date: 2001/02/05 06:57:33 $             */
/* ============================================================ */

/* ============================================================ */
/*   Table: jiveFilter                                          */
/* ============================================================ */
create table jiveFilter
(
    filterObject   text                   null    ,
    forumID        integer                not null,
    filterIndex    integer                not null,
    constraint PK_JIVEFILTER primary key (forumID, filterIndex)
)
go

/* ============================================================ */
/*   Index: filterIndexIdx                                      */
/* ============================================================ */
create index filterIndexIdx on jiveFilter (filterIndex)
go

/* ============================================================ */
/*   Table: jiveForum                                           */
/* ============================================================ */
create table jiveForum
(
    forumID        integer                not null,
    name           varchar(255)           null    ,
    description    text                   null    ,
    modifiedDate   varchar(15)            null    ,
    creationDate   varchar(15)            null    ,
    moderated      integer                not null,
    constraint PK_JIVEFORUM primary key (forumID)
)
go

/* ============================================================ */
/*   Table: jiveForumProp                                       */
/* ============================================================ */
create table jiveForumProp
(
    forumID        integer                not null,
    name           varchar(30)            not null,
    propValue      varchar(255)           not null
)
/////////////////////
go

/* ============================================================ */
/*   Table: jiveGroup                                           */
/* ============================================================ */
create table jiveGroup
(
    groupID        integer                not null,
    name           varchar(50)            not null,
    description    varchar(255)           null    ,
    constraint PK_JIVEGROUP primary key (groupID)
)
go

/* ============================================================ */
/*   Table: jiveGroupPerm                                       */
/* ============================================================ */
create table jiveGroupPerm
(
    forumID        integer                not null,
    groupID        integer                not null,
    permission     integer                not null,
    constraint PK_JIVEGROUPPERM primary key (forumID, groupID, permission)
)
go

/* ============================================================ */
/*   Index: groupGroupIdx                                       */
/* ============================================================ */
create index groupGroupIdx on jiveGroupPerm (groupID)
go

/* ============================================================ */
/*   Table: jiveGroupUser                                       */
/* ============================================================ */
create table jiveGroupUser
(
    groupID        integer                not null,
    userID         integer                not null,
    administrator  integer                not null,
    constraint PK_JIVEGROUPUSER primary key (groupID, userID)
)
go

/* ============================================================ */
/*   Index: groupIdx                                            */
/* ============================================================ */
create index groupIdx on jiveGroupUser (userID)
go

/* ============================================================ */
/*   Table: jiveMessage                                         */
/* ============================================================ */
create table jiveMessage
(
    messageID      integer                not null,
    threadID       integer                default -1 null    ,
    subject        varchar(255)           null    ,
    userID         integer                not null,
    body           text                   null    ,
    modifiedDate   varchar(15)            not null    ,
    creationDate   varchar(15)            not null    ,
    approved       integer                not null,
    constraint PK_JIVEMESSAGE primary key (messageID)
)
go

/* ============================================================ */
/*   Index: messageCreationDateIdx                              */
/* ============================================================ */
create index messageCreationDateIdx on jiveMessage (creationDate)
go

/* ============================================================ */
/*   Index: messageModifiedDateIdx                              */
/* ============================================================ */
create index messageModifiedDateIdx on jiveMessage (modifiedDate)
go

/* ============================================================ */
/*   Index: messageApprovedIdx                                  */
/* ============================================================ */
create index messageApprovedIdx on jiveMessage (approved)
go

/* ============================================================ */
/*   Index: messageThreadIDIdx                                  */
/* ============================================================ */
create index messageThreadIDIdx on jiveMessage (threadID)
go

/* ============================================================ */
/*   Index: messageUserIDIdx                                    */
/* ============================================================ */
create index messageUserIDIdx on jiveMessage (userID)
go

/* ============================================================ */
/*   Table: jiveMessageTree                                     */
/* ============================================================ */
create table jiveMessageTree
(
    parentID       integer                not null,
    childID        integer                not null,
    constraint PK_JIVEMESSAGETREE primary key (parentID, childID)
)
go

/* ============================================================ */
/*   Index: childIdx                                            */
/* ============================================================ */
create index childIdx on jiveMessageTree (childID)
go

/* ============================================================ */
/*   Table: jiveMessageProp                                     */
/* ============================================================ */
create table jiveMessageProp
(
    messageID      integer                not null,
    name           varchar(50)            not null,
    propValue      varchar(255)           not null,
    constraint PK_JIVEMESSAGEPROP primary key (messageID, name)
)
go


/* ============================================================ */
/*   Table: jiveThread                                          */
/* ============================================================ */
create table jiveThread
(
    threadID       integer                not null,
    forumID        integer                not null    ,
    rootMessageID  integer                not null,
    creationDate   varchar(15)            not null    ,
    modifiedDate   varchar(15)            not null    ,
    approved       integer                not null,
    constraint PK_JIVETHREAD primary key (threadID)
)
go

/* ============================================================ */
/*   Index: messageCreationDateIdx                              */
/* ============================================================ */
create index threadCreationDateIdx on jiveThread (creationDate)
go

/* ============================================================ */
/*   Index: messageModifiedDateIdx                              */
/* ============================================================ */
create index threadModifiedDateIdx on jiveThread (modifiedDate)
go

/* ============================================================ */
/*   Index: messageForumIDIdx                                   */
/* ============================================================ */
create index threadForumIDIdx on jiveThread (forumID)
go

/* ============================================================ */
/*   Table: jiveUser                                            */
/* ============================================================ */
create table jiveUser
(
    userID         integer                not null,
    name           varchar(50)            null    ,
    username       varchar(30)            not null,
    passwordHash   varchar(32)            not null,
    email          varchar(30)            not null,
    emailVisible   integer                not null,
    nameVisible    integer                not null,
    constraint PK_JIVEUSER primary key (userID)
)
go

/* ============================================================ */
/*   Table: jiveUserPerm                                        */
/* ============================================================ */
create table jiveUserPerm
(
    forumID        integer                not null,
    userID         integer                not null,
    permission     integer                not null,
    constraint PK_JIVEUSERPERM primary key (forumID, userID, permission)
)
go

/* ============================================================ */
/*   Index: userUserIdx                                         */
/* ============================================================ */
create index userUserIdx on jiveUserPerm (userID)
go

/* ============================================================ */
/*   Table: jiveUserProp                                        */
/* ============================================================ */
create table jiveUserProp
(
    userID         integer                not null,
    name           varchar(30)            not null,
    propValue      varchar(255)           not null,
    constraint PK_JIVEUSERPROP primary key (userID, name)
)
go



