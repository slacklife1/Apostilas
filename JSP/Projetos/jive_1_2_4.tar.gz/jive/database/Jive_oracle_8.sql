
REM  // $RCSfile: Jive_oracle_8.sql,v $
REM  // $Revision: 1.2.2.1 $
REM  // $Date: 2001/02/05 06:57:33 $


REM  //////////////////////
REM  //  jiveFilter
REM  //////////////////////

CREATE TABLE jiveFilter (
  filterObject   BLOB NULL,
  forumID        INTEGER NOT NULL,
  filterIndex    INTEGER NOT NULL
);

CREATE INDEX filterIndexIdx ON jiveFilter (
  filterIndex  ASC
);

ALTER TABLE jiveFilter
  ADD ( 
    PRIMARY KEY (forumID,filterIndex) 
  );



REM  //////////////////////
REM  //  jiveForum
REM  //////////////////////

CREATE TABLE jiveForum (
  forumID        INTEGER NOT NULL,
  name           VARCHAR2(255) NULL,
  description    VARCHAR2(2000) NULL,
  modifiedDate   VARCHAR2(15) NULL,
  creationDate   VARCHAR2(15) NULL,
  moderated      INTEGER NOT NULL
);

ALTER TABLE jiveForum
  ADD ( 
    PRIMARY KEY (forumID) 
  );



REM  //////////////////////
REM  //  jiveForumProp
REM  //////////////////////
CREATE TABLE jiveForumProp (
  forumID     INTEGER NOT NULL,
  name        VARCHAR2(30) NOT NULL,
  propValue   VARCHAR2(255) NOT NULL
);

ALTER TABLE jiveForumProp
  ADD (
    PRIMARY KEY (forumID,name)
  );

  

REM  //////////////////////
REM  //  jiveGroup
REM  //////////////////////

CREATE TABLE jiveGroup (
  groupID       INTEGER NOT NULL,
  name          VARCHAR2(50) NOT NULL,
  description   VARCHAR2(255) NULL
);

ALTER TABLE jiveGroup
  ADD ( 
    PRIMARY KEY (groupID) 
  );



REM  //////////////////////
REM  //  jiveGroupPerm
REM  //////////////////////

CREATE TABLE jiveGroupPerm (
  forumID       INTEGER NOT NULL,
  groupID       INTEGER NOT NULL,
  permission    INTEGER NOT NULL
);

CREATE INDEX groupGroupIdx ON jiveGroupPerm (
  groupID   ASC
);

ALTER TABLE jiveGroupPerm
  ADD ( 
    PRIMARY KEY (forumID, groupID, permission) 
  );



REM  //////////////////////
REM  //  jiveGroupUser
REM  //////////////////////

CREATE TABLE jiveGroupUser (
  groupID          INTEGER NOT NULL,
  userID           INTEGER NOT NULL,
  administrator    INTEGER NOT NULL
);

CREATE INDEX groupIdx ON jiveGroupUser (
  userID     ASC
);

ALTER TABLE jiveGroupUser
  ADD ( 
    PRIMARY KEY (groupID, userID)
  );



REM  //////////////////////
REM  //  jiveMessage
REM  //////////////////////
  
CREATE TABLE jiveMessage (
  messageID          INTEGER NOT NULL,
  threadID           INTEGER DEFAULT -1,
  subject            VARCHAR2(255) NULL,
  userID             INTEGER NOT NULL,
  body               LONG VARCHAR NULL,
  modifiedDate       VARCHAR2(15) NOT NULL,
  creationDate       VARCHAR2(15) NOT NULL,
  approved           INTEGER NOT NULL
);

CREATE INDEX messageApprovedIdx ON jiveMessage (
  approved    ASC
);

CREATE INDEX messageThreadIDIdx ON jiveMessage (
  threadID    ASC
);

CREATE INDEX messageCreationDateIdx ON jiveMessage (
  creationDate    ASC
);

CREATE INDEX messageModifiedDateIdx ON jiveMessage (
  modifiedDate    ASC
);

CREATE INDEX messageUserIDIdx ON jiveMessage (
  userID    ASC
);

ALTER TABLE jiveMessage
  ADD ( 
    PRIMARY KEY (messageID)
  );



REM  //////////////////////
REM  //  jiveMessageTree
REM  //////////////////////
    
CREATE TABLE jiveMessageTree (
  parentID     INTEGER NOT NULL,
  childID      INTEGER NOT NULL
);

CREATE INDEX childIdx ON jiveMessageTree (
  childID      ASC
);

ALTER TABLE jiveMessageTree
  ADD ( 
    PRIMARY KEY (parentID, childID) 
  );



REM  //////////////////////
REM  //  jiveMessageProp
REM  //////////////////////
    
CREATE TABLE jiveMessageProp (
  messageID     INTEGER NOT NULL,
  name          VARCHAR2(50) NOT NULL,
  propValue     VARCHAR2(255) NOT NULL
);

ALTER TABLE jiveMessageProp
  ADD ( 
    PRIMARY KEY (messageID, name) 
  );


REM  //////////////////////
REM  //  jiveThread
REM  //////////////////////
    
CREATE TABLE jiveThread (
  threadID            INTEGER NOT NULL,
  forumID             INTEGER NOT NULL,
  rootMessageID       INTEGER NOT NULL,
  creationDate        VARCHAR2(15) NOT NULL,
  modifiedDate        VARCHAR2(15) NOT NULL,
  approved            INTEGER NOT NULL
);

CREATE INDEX threadCreationDateIdx ON jiveThread (
  creationDate    ASC
);

CREATE INDEX threadModifiedDateIdx ON jiveThread (
  modifiedDate    ASC
);

CREATE INDEX threadForumIDIdx ON jiveThread (
  forumID    ASC
);

ALTER TABLE jiveThread
  ADD ( 
    PRIMARY KEY (threadID) 
  );   



REM  //////////////////////
REM  //  jiveUser
REM  //////////////////////
    
CREATE TABLE jiveUser (
  userID               INTEGER NOT NULL,
  name                 VARCHAR2(50) NULL,
  username             VARCHAR2(30) NOT NULL,
  passwordHash         VARCHAR2(32) NOT NULL,
  email                VARCHAR2(30) NOT NULL,
  emailVisible         INTEGER NOT NULL,
  nameVisible          INTEGER NOT NULL
);

ALTER TABLE jiveUser
  ADD ( 
    PRIMARY KEY (userID) 
  );



REM  //////////////////////
REM  //  jiveUserPerm
REM  //////////////////////
    
CREATE TABLE jiveUserPerm (
  forumID          INTEGER NOT NULL,
  userID           INTEGER NOT NULL,
  permission       INTEGER NOT NULL
);

CREATE INDEX userUserIdx ON jiveUserPerm (
  userID    ASC
);

ALTER TABLE jiveUserPerm
  ADD ( 
    PRIMARY KEY (forumID, userID, permission)
  );



REM  //////////////////////
REM  //  jiveUserProp
REM  //////////////////////
    
CREATE TABLE jiveUserProp (
  userID      INTEGER NOT NULL,
  name        VARCHAR2(30) NOT NULL,
  propValue   VARCHAR2(255) NOT NULL
);

ALTER TABLE jiveUserProp
  ADD ( 
    PRIMARY KEY (userID, name) 
  );



 




