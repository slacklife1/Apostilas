/* ============================================================ */
/* Postgres SQL Script							    */
/* $RCSfile: Jive_postgres.sql,v $       */
/* $Revision: 1.1.2.2 $      */
/* $Date: 2001/02/05 06:57:33 $          */
/* ============================================================ */

     /* ============================================================ */
     /* Table: jiveFilter */
     /* ============================================================ */
     create table jiveFilter
     (
     filterObject oid ,
     forumID integer not null,
     filterIndex integer not null,
     constraint PK_JIVEFILTER primary key (forumID, filterIndex)
     )
     ;

     /* ============================================================ */
     /* Index: filterIndexIdx */
     /* ============================================================ */
     create index filterIndexIdx on jiveFilter (filterIndex)
     ;

     /* ============================================================ */
     /* Table: jiveForum */
     /* ============================================================ */
     create table jiveForum
     (
     forumID integer not null,
     name varchar(255) ,
     description text ,
     modifiedDate varchar(15) ,
     creationDate varchar(15) ,
     moderated integer not null,
     constraint PK_JIVEFORUM primary key (forumID)
     )
     ;

     /* ============================================================ */
     /* Table: jiveForumProp */
     /* ============================================================ */
     create table jiveForumProp
     (
     forumID integer not null,
     name varchar(30) not null,
     propValue varchar(255) not null
     )
     ;

     /* ============================================================ */
     /* Table: jiveGroup */
     /* ============================================================ */
     create table jiveGroup
     (
     groupID integer not null,
     name varchar(50) not null,
     description varchar(255) ,
     constraint PK_JIVEGROUP primary key (groupID)
     )
     ;

     /* ============================================================ */
     /* Table: jiveGroupPerm */
     /* ============================================================ */
     create table jiveGroupPerm
     (
     forumID integer not null,
     groupID integer not null,
     permission integer not null,
     constraint PK_JIVEGROUPPERM primary key (forumID, groupID, permission)
     )
     ;

     /* ============================================================ */
     /* Index: groupGroupIdx */
     /* ============================================================ */
     create index groupGroupIdx on jiveGroupPerm (groupID)
     ;

     /* ============================================================ */
     /* Table: jiveGroupUser */
     /* ============================================================ */
     create table jiveGroupUser
     (
     groupID integer not null,
     userID integer not null,
     administrator integer not null,
     constraint PK_JIVEGROUPUSER primary key (groupID, userID)
     )
     ;

     /* ============================================================ */
     /* Index: groupIdx */
     /* ============================================================ */
     create index groupIdx on jiveGroupUser (userID)
     ;

     /* ============================================================ */
     /* Table: jiveMessage */
     /* ============================================================ */
     create table jiveMessage
     (
     messageID integer not null,
     threadID integer default -1 ,
     subject varchar(255) ,
     userID integer not null,
     body text ,
     modifiedDate varchar(15) not null,
     creationDate varchar(15) not null,
     approved integer not null,
     constraint PK_JIVEMESSAGE primary key (messageID)
     )
     ;

     /* ============================================================ */
     /* Index: messageApprovedIdx */
     /* ============================================================ */
     create index messageApprovedIdx on jiveMessage (approved)
     ;

     /* ============================================================ */
     /* Index: messageCreationDateIdx */
     /* ============================================================ */
     create index messageCreationDateIdx on jiveMessage (creationDate)
     ;

     /* ============================================================ */
     /* Index: messageModifiedDateIdx */
     /* ============================================================ */
     create index messageModifiedDateIdx on jiveMessage (modifiedDate)
     ;

     /* ============================================================ */
     /* Index: messageThreadIDIdx */
     /* ============================================================ */
     create index messageThreadIDIdx on jiveMessage (threadID)
     ;

     /* ============================================================ */
     /* Index: messageUserIDIdx */
     /* ============================================================ */
     create index messageUserIDIdx on jiveMessage (userID)
     ;

     /* ============================================================ */
     /* Table: jiveMessageTree */
     /* ============================================================ */
     create table jiveMessageTree
     (
     parentID integer not null,
     childID integer not null,
     constraint PK_JIVEMESSAGETREE primary key (parentID, childID)
     )
     ;

     /* ============================================================ */
     /* Index: childIdx */
     /* ============================================================ */
     create index childIdx on jiveMessageTree (childID)
     ;

     /* ============================================================ */
     /* Table: jiveMessageProp */
     /* ============================================================ */
     create table jiveMessageProp
     (
     messageID integer not null,
     name varchar(50) not null,
     propValue varchar(255) not null,
     constraint PK_JIVEMESSAGEPROP primary key (messageID, name)
     )
     ;

     /* ============================================================ */
     /* Table: jiveThread */
     /* ============================================================ */
     create table jiveThread
     (
     threadID integer not null,
     forumID integer not null,
     rootMessageID integer not null,
     creationDate varchar(15) not null,
     modifiedDate varchar(15) not null,
     approved integer not null,
     constraint PK_JIVETHREAD primary key (threadID)
     )
     ;

     /* ============================================================ */
     /* Index: threadCreationDateIdx */
     /* ============================================================ */
     create index threadCreationDateIdx on jiveThread (creationDate)
     ;

     /* ============================================================ */
     /* Index: threadModifiedDateIdx */
     /* ============================================================ */
     create index threadModifiedDateIdx on jiveThread (modifiedDate)
     ;

     /* ============================================================ */
     /* Index: threadForumIDIdx */
     /* ============================================================ */
     create index threadForumIDIdx on jiveThread (forumID)
     ;

     /* ============================================================ */
     /* Table: jiveUser */
     /* ============================================================ */
     create table jiveUser
     (
     userID integer not null,
     name varchar(50) ,
     username varchar(30) not null,
     passwordHash varchar(32) not null,
     email varchar(30) not null,
     emailVisible integer not null,
     nameVisible integer not null,
     constraint PK_JIVEUSER primary key (userID)
     )
     ;

     /* ============================================================ */
     /* Table: jiveUserPerm */
     /* ============================================================ */
     create table jiveUserPerm
     (
     forumID integer not null,
     userID integer not null,
     permission integer not null,
     constraint PK_JIVEUSERPERM primary key (forumID, userID, permission)
     )
     ;

     /* ============================================================ */
     /* Index: userUserIdx */
     /* ============================================================ */
     create index userUserIdx on jiveUserPerm (userID)
     ;

     /* ============================================================ */
     /* Table: jiveUserProp */
     /* ============================================================ */
     create table jiveUserProp
     (
     userID integer not null,
     name varchar(30) not null,
     propValue varchar(255) not null,
     constraint PK_JIVEUSERPROP primary key (userID, name)
     )
     ;

