/* ============================================================ */
/* $RCSfile: Jive_sqlserver_7.sql,v $        */
/* $Revision: 1.3.2.1 $       */
/* $Date: 2001/02/05 06:57:33 $           */
/* ============================================================ */


/* ============================================================ */
/* Jive Filter                                                  */
/* ============================================================ */
create table jiveFilter
(
  filterObject   image         null,
  forumID        int           not null,
  filterIndex    int           not null,
  constraint     filterPK primary key (forumID,filterIndex)
);

create index filterIndexIdx on jiveFilter (filterIndex);


/* ============================================================ */
/* Jive Forum                                                   */
/* ============================================================ */
create table jiveForum
(
  forumID        int           not null,
  name           varchar(255)  null,
  description    varchar(2000) null,
  modifiedDate   varchar(15)   null,
  creationDate   varchar(15)   null,
  moderated      int           not null,
  constraint     forumPK primary key (forumID)
);


/* ============================================================ */
/* Jive Forum Properties                                        */
/* ============================================================ */
create table jiveForumProp
(
  forumID        int           not null,
  name           varchar(30)   not null,
  propValue      varchar(255)  not null,
  constraint     forumPropPK primary key (forumID, name)
);


/* ============================================================ */
/* Jive Group                                                   */
/* ============================================================ */
create table jiveGroup
(
  groupID       int            not null,
  name          varchar(50)    not null,
  description   varchar(255)   null,
  constraint    groupPK primary key (groupID)
);


/* ============================================================ */
/* Jive GroupPerm                                               */
/* ============================================================ */
create table jiveGroupPerm
(
  forumID       int            not null,
  groupID       int            not null,
  permission    int            not null,
  constraint    groupPermPK primary key (forumID, groupID, permission)
);

create index groupGroupIdx on jiveGroupPerm (groupID);


/* ============================================================ */
/* Jive GroupUser                                               */
/* ============================================================ */
create table jiveGroupUser
(
  groupID       int            not null,
  userID        int            not null,
  administrator int            not null,
  constraint    groupUserPK primary key (groupID, userID)
);

create index groupIdx on jiveGroupUser (userID);


/* ============================================================ */
/* Jive Message                                                 */
/* ============================================================ */
create table jiveMessage
(
  messageID     int            not null,
  threadID      int            not null
                               default -1,
  subject       varchar(255)   null,
  userID        int            not null,
  body          text           null,
  modifiedDate  char(15)       not null,
  creationDate  char(15)       not null,
  approved      int            not null,
  constraint    messagePK primary key (messageID)
);

create index messageApprovedIdx on jiveMessage (approved);

create index messageThreadIDIdx on jiveMessage (threadID);

create index messageCreationDateIdx on jiveMessage (creationDate);

create index messageModifiedDateIdx on jiveMessage (modifiedDate);

create index messageUserIDIdx on jiveMessage (userID);


/* ============================================================ */
/* Jive MessageTree                                             */
/* ============================================================ */
create table jiveMessageTree
(
  parentID      int            not null,
  childID       int            not null,
  constraint    messageTreePK primary key (parentID, childID)
);

create index childIdx on jiveMessageTree (childID);


/* ============================================================ */
/* Jive MessageProp                                             */
/* ============================================================ */
create table jiveMessageProp
(
  messageID     int            not null,
  name          varchar(50)    not null,
  propValue     varchar(255)   not null,
  constraint    messagePropPK primary key (messageID, name)
);


/* ============================================================ */
/* Jive Thread                                                  */
/* ============================================================ */
create table jiveThread
(
  threadID      int            not null,
  forumID       int            not null,
  rootMessageID int            not null,
  creationDate  char(15)       not null,
  modifiedDate  char(15)       not null,
  approved      int            not null,
  constraint    threadPK primary key (threadID)
);

create index threadCreationDateIdx on jiveThread (creationDate);

create index threadModifiedDateIdx on jiveThread (modifiedDate);

create index threadForumIDIdx on jiveThread (forumID);


/* ============================================================ */
/* Jive User                                                    */
/* ============================================================ */
CREATE TABLE jiveUser (
  userID        int            not null,
  name          varchar(50)    null,
  username      varchar(30)    not null,
  passwordHash  varchar(32)    not null,
  email         varchar(30)    not null,
  emailVisible  int            not null,
  nameVisible   int            not null,
  constraint    userPK primary key (userID)
);


/* ============================================================ */
/* Jive UserPerm                                                */
/* ============================================================ */
create table jiveUserPerm
(
  forumID       int            not null,
  userID        int            not null,
  permission    int            not null,
  constraint    userPermPK primary key (forumID, userID, permission)
);

create index userUserIdx on jiveUserPerm (userID);


/* ============================================================ */
/* Jive UserProp                                                */
/* ============================================================ */
create table jiveUserProp
(
  userID        int            not null,
  name          varchar(30)    not null,
  propValue     varchar(255)   not null,
  constraint    userPropPK primary key (userID, name)
);


