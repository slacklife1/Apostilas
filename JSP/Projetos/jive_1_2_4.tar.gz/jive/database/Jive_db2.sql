
--  $RCSfile: Jive_db2.sql,v $
--  $Revision: 1.2.2.2 $
--  $Date: 2001/04/13 04:05:25 $

--  //////////////////////
--  //  jiveFilter
--  //////////////////////

CREATE TABLE jiveFilter (
  filterObject   BLOB(32768) ,
  forumID        INTEGER NOT NULL,
  filterIndex    INTEGER NOT NULL
);

CREATE INDEX filterIndexIdx ON jiveFilter (
  filterIndex  ASC
 );

ALTER TABLE jiveFilter
  ADD PRIMARY KEY (forumID,filterIndex) 
  ;

--  //////////////////////
--  //  jiveForum
--  //////////////////////

CREATE TABLE jiveForum (
  forumID        INTEGER NOT NULL,
  name           VARCHAR(255) ,
  description    VARCHAR(2000) ,
  modifiedDate   VARCHAR(15) ,
  creationDate   VARCHAR(15) ,
  moderated      INTEGER NOT NULL
);

ALTER TABLE jiveForum
  ADD PRIMARY KEY (forumID) 
  ;

--  //////////////////////
--  //  jiveForumProp
--  //////////////////////
CREATE TABLE jiveForumProp (
  forumID     INTEGER NOT NULL,
  name        VARCHAR(30) NOT NULL,
  propValue   VARCHAR(255) NOT NULL
);

ALTER TABLE jiveForumProp
  ADD PRIMARY KEY (forumID,name)
  ;

--  //////////////////////
--  //  jiveGroup
--  //////////////////////

CREATE TABLE jiveGroup (
  groupID       INTEGER NOT NULL,
  name          VARCHAR(50) NOT NULL,
  description   VARCHAR(255) 
);

ALTER TABLE jiveGroup
  ADD PRIMARY KEY (groupID) 
  ;

--  //////////////////////
--  //  jiveGroupPerm
--  //////////////////////

CREATE TABLE jiveGroupPerm (
  forumID       INTEGER NOT NULL,
  groupID       INTEGER NOT NULL,
  permission    INTEGER NOT NULL
);

CREATE INDEX groupGroupIdx ON jiveGroupPerm (
  groupID   ASC
);

ALTER TABLE jiveGroupPerm
  ADD PRIMARY KEY (forumID, groupID, permission) 
  ;

--  //////////////////////
--  //  jiveGroupUser
--  //////////////////////

CREATE TABLE jiveGroupUser (
  groupID          INTEGER NOT NULL,
  userID           INTEGER NOT NULL,
  administrator    INTEGER NOT NULL
);

CREATE INDEX groupIdx ON jiveGroupUser (
  userID     ASC
);

ALTER TABLE jiveGroupUser
  ADD PRIMARY KEY (groupID, userID)
  ;

--  //////////////////////
--  //  jiveMessage
--  //////////////////////
  
CREATE TABLE jiveMessage (
  messageID          INTEGER NOT NULL,
  threadID           INTEGER DEFAULT -1,
  subject            VARCHAR(255) ,
  userID             INTEGER NOT NULL,
  body               LONG VARCHAR ,
  modifiedDate       VARCHAR(15) NOT NULL,
  creationDate       VARCHAR(15) NOT NULL,
  approved           INTEGER NOT NULL
);


--  *************************************
--  Change the name of the 4 index bellow
--  *************************************

CREATE INDEX msgApprovedIdx ON jiveMessage (
  approved        ASC
);

CREATE INDEX msgThreadIDIdx ON jiveMessage (
  threadID        ASC
);

CREATE INDEX msgModifiedDateIdx ON jiveMessage (
  modifiedDate    ASC
);

CREATE INDEX msgCreationDateIdx ON jiveMessage (
  creationDate    ASC
);

CREATE INDEX msgUserIDIdx ON jiveMessage (
  userID    ASC
);

ALTER TABLE jiveMessage
  ADD PRIMARY KEY (messageID)
  ;

--  //////////////////////
--  //  jiveMessageTree
--  //////////////////////
    
CREATE TABLE jiveMessageTree (
  parentID     INTEGER NOT NULL,
  childID      INTEGER NOT NULL
);

CREATE INDEX childIdx ON jiveMessageTree (
  childID      ASC
);

ALTER TABLE jiveMessageTree
  ADD PRIMARY KEY (parentID, childID) 
  ;

--  //////////////////////
--  //  jiveMessageProp
--  //////////////////////
    
CREATE TABLE jiveMessageProp (
  messageID     INTEGER NOT NULL,
  name          VARCHAR(50) NOT NULL,
  propValue     VARCHAR(255) NOT NULL
);

ALTER TABLE jiveMessageProp
  ADD PRIMARY KEY (messageID, name) 
  ;

--  //////////////////////
--  //  jiveThread
--  //////////////////////
    
CREATE TABLE jiveThread (
  threadID            INTEGER NOT NULL,
  forumID             INTEGER NOT NULL,
  rootMessageID       INTEGER NOT NULL,
  creationDate        VARCHAR(15) NOT NULL,
  modifiedDate        VARCHAR(15) NOT NULL,
  approved            INTEGER NOT NULL
);

--  *************************************
--  Change the name of the 3 index bellow
--  *************************************
CREATE INDEX thdModifiedDateIdx ON jiveThread (
  modifiedDate    ASC
);

CREATE INDEX thdCreationDateIdx ON jiveThread (
  creationDate    ASC
);

CREATE INDEX thdForumIDIdx ON jiveThread (
  forumID    ASC
);

ALTER TABLE jiveThread
  ADD PRIMARY KEY (threadID) 
  ;   

--  //////////////////////
--  //  jiveUser
--  //////////////////////
    
CREATE TABLE jiveUser (
  userID               INTEGER NOT NULL,
  name                 VARCHAR(50) ,
  username             VARCHAR(30) NOT NULL,
  passwordHash         VARCHAR(32) NOT NULL,
  email                VARCHAR(30) NOT NULL,
  emailVisible         INTEGER NOT NULL,
  nameVisible          INTEGER NOT NULL
);

ALTER TABLE jiveUser
  ADD PRIMARY KEY (userID) 
  ;

--  //////////////////////
--  //  jiveUserPerm
--  //////////////////////
    
CREATE TABLE jiveUserPerm (
  forumID          INTEGER NOT NULL,
  userID           INTEGER NOT NULL,
  permission       INTEGER NOT NULL
);

CREATE INDEX userUserIdx ON jiveUserPerm (
  userID    ASC
);

ALTER TABLE jiveUserPerm
  ADD PRIMARY KEY (forumID, userID, permission)
  ;


--  //////////////////////
--  //  jiveUserProp
--  //////////////////////
    
CREATE TABLE jiveUserProp (
  userID      INTEGER NOT NULL,
  name        VARCHAR(30) NOT NULL,
  propValue   VARCHAR(255) NOT NULL
);

ALTER TABLE jiveUserProp
  ADD PRIMARY KEY (userID, name) 
  ;
