
# $RCSfile: Jive_mysql.sql,v $
# $Revision: 1.2.2.1 $
# $Date: 2001/02/05 06:57:33 $

CREATE TABLE jiveFilter (
  filterObject   BLOB,
  forumID        INT NOT NULL,
  filterIndex    INT NOT NULL,
  KEY            (forumID),
  KEY            (filterIndex)
);

CREATE TABLE jiveForum (
  forumID           INT NOT NULL,
  name              VARCHAR(255),
  description       TEXT,
  modifiedDate      VARCHAR(15),
  creationDate      VARCHAR(15),
  moderated         INT NOT NULL,
  PRIMARY KEY       (forumID)
);

CREATE TABLE jiveForumProp (
  forumID     INT NOT NULL,
  name        VARCHAR(30) NOT NULL,
  propValue   VARCHAR(255) NOT NULL,
  KEY         (forumID,name)
);

CREATE TABLE jiveGroup (
  groupID      INT NOT NULL,
  name         VARCHAR(50) NOT NULL,
  description  VARCHAR(255),
  PRIMARY KEY  (groupID)
);

CREATE TABLE jiveGroupPerm (
  forumID      INT NOT NULL,
  groupID      INT NOT NULL,
  permission   INT NOT NULL,
  KEY          (forumID),
  KEY          (groupID)
);

CREATE TABLE jiveGroupUser (
  groupID        INT NOT NULL,
  userID         INT NOT NULL,
  administrator  INT NOT NULL,
  PRIMARY KEY   (groupID,userID)
);

CREATE TABLE jiveMessage (
  messageID     INT NOT NULL,
  threadID      INT NOT NULL DEFAULT -1,
  subject       VARCHAR(255),
  userID        INT NOT NULL,
  body          TEXT,
  modifiedDate  VARCHAR(15) NOT NULL,
  creationDate  VARCHAR(15) NOT NULL,
  approved      INT NOT NULL,
  PRIMARY KEY   (messageID),
  KEY           (userID),
  KEY           (threadID),
  KEY           (approved),
  KEY           (creationDate),
  KEY           (modifiedDate)
);

CREATE TABLE jiveMessageTree (
  parentID   INT NOT NULL,
  childID    INT NOT NULL,
  KEY        (parentID),
  KEY        (childID)
);

CREATE TABLE jiveMessageProp (
  messageID    INT NOT NULL,
  name         VARCHAR(30) NOT NULL,
  propValue    VARCHAR(255) NOT NULL,
  PRIMARY KEY  (messageID,name)
);

CREATE TABLE jiveThread (
  threadID      INT NOT NULL,
  forumID       INT NOT NULL,
  rootMessageID INT NOT NULL,
  approved      INT NOT NULL,
  creationDate  VARCHAR(15) NOT NULL,
  modifiedDate  VARCHAR(15) NOT NULL,
  PRIMARY KEY   (threadID),
  KEY           (forumID),
  KEY           (rootMessageID),
  KEY           (creationDate),
  KEY           (modifiedDate)
);

CREATE TABLE jiveUser (
  userID        INT NOT NULL,
  name          VARCHAR(50),
  username      VARCHAR(30) NOT NULL,
  passwordHash  VARCHAR(32) NOT NULL,   
  email         VARCHAR(30) NOT NULL,
  emailVisible  INT NOT NULL,
  nameVisible   INT NOT NULL,
  PRIMARY KEY   (userID)
);

CREATE TABLE jiveUserPerm (
  forumID      INT NOT NULL,
  userID       INT NOT NULL,
  permission   INT NOT NULL,
  KEY          (forumID),
  KEY          (userID)
);

CREATE TABLE jiveUserProp (
  userID     INT NOT NULL,
  name       VARCHAR(30) NOT NULL,
  propValue  VARCHAR(255) NOT NULL,
  KEY        (userID,name)
);


