
; $RCSfile: Jive_hsql.sql,v $
; $Revision: 1.2.2.1 $
; $Date: 2001/02/05 06:57:33 $
; 
; Adapted from Instant DB Schema
; by Corey Puffalt (corey@geekden.org)

;  //////////////////////
;  //  jiveFilter
;  //////////////////////

CREATE TABLE jiveFilter (
  filterObject	 BINARY,
  forumID		 INT  NOT NULL,
  filterIndex	 INT  NOT NULL,
  PRIMARY KEY (forumID,filterIndex) 
);

CREATE INDEX filterIndexIdx ON jiveFilter (
  filterIndex
 );


;  //////////////////////
;  //  jiveForum
;  //////////////////////

CREATE TABLE jiveForum (
  forumID		 INT  NOT NULL,
  name			 VARCHAR(255),
  description	 VARCHAR(2000),
  modifiedDate	 VARCHAR(15),
  creationDate	 VARCHAR(15),
  moderated		 INT  NOT NULL,
  PRIMARY KEY (forumID) 
);


;  //////////////////////
;  //  jiveForumProp
;  //////////////////////

CREATE TABLE jiveForumProp (
  forumID	  INT  NOT NULL,
  name		  VARCHAR(30) NOT NULL,
  propValue	  VARCHAR(255) NOT NULL,
  PRIMARY KEY (forumID,name)
);


;  //////////////////////
;  //  jiveGroup
;  //////////////////////

CREATE TABLE jiveGroup (
  groupID		INT	 NOT NULL,
  name			VARCHAR(50)	NOT NULL,
  description   VARCHAR(255),
  PRIMARY KEY (groupID) 
);


;  //////////////////////
;  //  jiveGroupPerm
;  //////////////////////

CREATE TABLE jiveGroupPerm (
  forumID		INT	 NOT NULL,
  groupID		INT	 NOT NULL,
  permission    INT	 NOT NULL,
  PRIMARY KEY (forumID,groupID,permission) 
);

CREATE INDEX groupGroupIdx ON jiveGroupPerm (
  groupID
);


;  //////////////////////
;  //  jiveGroupUser
;  //////////////////////

CREATE TABLE jiveGroupUser (
  groupID		   INT	NOT	NULL,
  userID		   INT	NOT	NULL,
  administrator	   INT  NOT NULL,
  PRIMARY KEY (groupID,userID)
);

CREATE INDEX groupIdx ON jiveGroupUser (
  userID
);


;  //////////////////////
;  //  jiveMessage
;  //////////////////////
  
CREATE TABLE jiveMessage (
  messageID			 INT NOT NULL,
  threadID			 INT,
  subject			 VARCHAR(255),
  userID			 INT  NOT NULL,
  body				 LONGVARCHAR,
  modifiedDate		 VARCHAR(15) NOT NULL,
  creationDate		 VARCHAR(15) NOT NULL,
  approved			 INT  NOT NULL,
  PRIMARY KEY		(messageID)
);

CREATE INDEX messageApprovedIdx ON jiveMessage (
  approved
);

CREATE INDEX messageThreadIDIdx ON jiveMessage (
  threadID
);

CREATE INDEX messageCreationDateIdx ON jiveMessage (
  creationDate
);

CREATE INDEX messageModifiedDateIdx ON jiveMessage (
  modifiedDate
);

CREATE INDEX messageUserIDIdx ON jiveMessage (
  userID
);


;  //////////////////////
;  //  jiveMessageTree
;  //////////////////////
    
CREATE TABLE jiveMessageTree (
  parentID	   INT	NOT	NULL,
  childID	   INT	NOT	NULL,
  PRIMARY KEY (parentID,childID) 
);

CREATE INDEX childIdx ON jiveMessageTree (
  childID
);


;  //////////////////////
;  //  jiveMessageProp
;  //////////////////////
    
CREATE TABLE jiveMessageProp (
  messageID	    INT	 NOT NULL,
  name			VARCHAR(50)	NOT NULL,
  propValue	    VARCHAR(255) NOT NULL,
  PRIMARY KEY (messageID,name) 
);


;  //////////////////////
;  //  jiveThread
;  //////////////////////
    
CREATE TABLE jiveThread (
  threadID			  INT  NOT NULL,
  forumID			  INT  NOT NULL,
  rootMessageID		  INT  NOT NULL,
  creationDate		  VARCHAR(15) NOT NULL,
  modifiedDate		  VARCHAR(15) NOT NULL,
  approved			  INT  NOT NULL,
  PRIMARY KEY (threadID) 
);

CREATE INDEX threadCreationDateIdx ON jiveThread (
  creationDate
);

CREATE INDEX threadModifiedDateIdx ON jiveThread (
  modifiedDate
);

CREATE INDEX threadForumIDIdx ON jiveThread (
  forumID
);


;  //////////////////////
;  //  jiveUser
;  //////////////////////
    
CREATE TABLE jiveUser (
  userID			   INT	NOT	NULL,
  name				   VARCHAR(50),
  username			   VARCHAR(30) NOT NULL,
  passwordHash		   VARCHAR(32) NOT NULL,
  email				   VARCHAR(30) NOT NULL,
  emailVisible		   INT	NOT	NULL,
  nameVisible		   INT	NOT	NULL,
  PRIMARY KEY (userID) 
);


;  //////////////////////
;  //  jiveUserPerm
;  //////////////////////
    
CREATE TABLE jiveUserPerm (
  forumID		   INT	NOT	NULL,
  userID		   INT	NOT	NULL,
  permission	   INT	NOT	NULL,
  PRIMARY KEY (forumID,userID,permission)
);

CREATE INDEX userUserIdx ON jiveUserPerm (
  userID
);


;  //////////////////////
;  //  jiveUserProp
;  //////////////////////
    
CREATE TABLE jiveUserProp (
  userID	  INT  NOT NULL,
  name		  VARCHAR(30) NOT NULL,
  propValue	  VARCHAR(255) NOT NULL,
  PRIMARY KEY (userID,name) 
);



