/**
 * $Header: /home/coolserv/.cvs/coolserv/jive/source/taglib/com/coolservlets/forum/tags/IsSummaryTag.java,v 1.2 2000/12/11 00:16:14 gnielsen Exp $
 * $Revision: 1.2 $
 * $Date: 2000/12/11 00:16:14 $
 *
 * Copyright (C) 2000 CoolServlets.com. All rights reserved.
 *
 * ===================================================================
 * The Apache Software License, Version 1.1
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by
 *        CoolServlets.com (http://www.coolservlets.com)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Jive" and "CoolServlets.com" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please
 *    contact webmaster@coolservlets.com.
 *
 * 5. Products derived from this software may not be called "Jive",
 *    nor may "Jive" appear in their name, without prior written
 *    permission of CoolServlets.com.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL COOLSERVLETS.COM OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of CoolServlets.com. For more information
 * on CoolServlets.com, please see <http://www.coolservlets.com>.
 */

package com.coolservlets.forum.tags;

import java.io.*;
import javax.servlet.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import javax.servlet.http.*;
import com.coolservlets.forum.tags.*;

/**
 * JSP Tag <b>is_summary</b>, used to test if the current message
 * while walking a thread is greater than or equal to the users
 * message_depth but less than the users thread_depth.
 * <p>
 * Includes body of tag if the current message
 * while walking a thread is greater than or equal to the users
 * message_depth but less than the users thread_depth.
 * <p>
 * Must be nested inside a <b>walk</b> tag.
 * <p>
 * JSP Tag Lib Descriptor
 * <p><pre>
 *  &lt;name&gt;is_summary&lt;/name&gt;
 *  &lt;tagclass&gt;com.coolservlets.forum.tags.IsSummaryTag&lt;/tagclass&gt;
 *  &lt;bodycontent&gt;JSP&lt;/bodycontent&gt;
 *  &lt;info&gt;
 *        When walking a tree of messages, body is included if this message is
 *        above the users message_depth, but below the users thread_depth.
 *  &lt;/info&gt;
 * </pre>
 *
 * @see WalkTag
 *
 * @author Glenn Nielsen
 */
public class IsSummaryTag extends TagSupport
{

  /**
   * Method called at start of is_summary Tag
   *
   * @return EVAL_BODY if current message while walking a thread is greater than or equal to the users message_depth but less than the users thread_depth or SKIP_BODY
   */
  public final int doStartTag() throws JspException
  {
    // Find the parent walk ta
    WalkTag wt = null;
    try {
      wt = (WalkTag)this.findAncestorWithClass(this,
        Class.forName("com.coolservlets.forum.tags.WalkTag"));
    } catch(Exception e) {
      return SKIP_BODY;
    }

    if( wt.isSummary() )
      return EVAL_BODY_INCLUDE;
    return SKIP_BODY;
  }

}
