
/**
 *  TreeInterface.java
 */

package com.coolservlets.forum.util.tree;

public interface TreeInterface {

    public void addChild(TreeObject child);
} 
