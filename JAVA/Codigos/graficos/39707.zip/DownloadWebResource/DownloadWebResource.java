/*
	Written On: 30th March 2005, Wednesday

	By: Sunil Dhummi (sdhummi@tataelxsi.co.in)

	Description:
		The program attempts to read a web resource using a byte stream. This resource is them
		attempted to be stored on the local disk.
		
	Version: 0.0a
*/

import java.net.*;
import java.io.*;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class DownloadWebResource implements ActionListener
{
	/*
		URL class object stores the web resource address (with methods to extract 
		different parts of Web address)
	*/
	private URL url = null;

	private String filePath = null;
	private String destPath = null;
	
	/*
		GUI (Swing) related components
	*/
	private JFrame frame = null;
	private JPanel panel = null;
	
	private JTextField webResourcePath = null;
	private JTextField resourceDestPath = null;
	private JTextField proxyHost = null;
	private JTextField proxyPort = null;
	private JButton downloadResource = null;

	public static void main(String[] args) 
	{
		/*
				Invoke Gui in a thread safe manner
		*/
		javax.swing.SwingUtilities.invokeLater(new Runnable(){
			public void run(){
				DownloadWebResource id = new DownloadWebResource();
				id.createAndShowGUI();
			}
		});
	}
	
	/*
		Setup the GUI
	*/
	public void createAndShowGUI()
	{
		JFrame.setDefaultLookAndFeelDecorated(true);
		
		/*
			Setup the frame. Also, enter the Window Header text
		*/
		frame = new JFrame("Download Utility");
		
		/*
			If user clicks on "X" button, exit by default
		*/
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		/*
			Setup the panel that shall contain GUI components.
			Like textfields, buttons etc - which will be contained
			in the panel.
		*/
		panel = new JPanel(new GridLayout(2,3));
		
		/*
			Create the textfields and button.
			Add them to the panel.
		*/
		webResourcePath = new JTextField("Web Resource Address (http://www.SunilWeb.com/index.asp)");
		webResourcePath.setColumns(20);
		panel.add(webResourcePath);
		
		resourceDestPath = new JTextField("Destination Path (ex: c:\\)");
		resourceDestPath.setColumns(20);
		panel.add(resourceDestPath);
		
		proxyHost = new JTextField("Enter Proxy Host here (local computer should have: localhost)");
		proxyHost.setColumns(15);
		panel.add(proxyHost);
		
		proxyPort = new JTextField("Port Address to download from (default should be: 80 or 8080)");
		proxyPort.setColumns(4);
		panel.add(proxyPort);
		
		downloadResource = new JButton("Download");
		panel.add(downloadResource);	
		downloadResource.addActionListener(this);
	
		frame.getContentPane().add(panel);		
		frame.pack();
		frame.setVisible(true);
	}

	public void actionPerformed(ActionEvent e)
	{
		if(e.getActionCommand().equals("Download"))
		{			
			filePath = new String(webResourcePath.getText());
			
			destPath = new String(resourceDestPath.getText());
			
			String strProxyHost = proxyHost.getText();
			String strProxyPort = proxyPort.getText();
						
			System.setProperty("http.proxyHost",strProxyHost);
			System.setProperty("http.proxyPort",strProxyPort);
			
			writeFile();
		}
	}
	
	/*
		Optional: Print the URL Details
	*/
	public String printURLDetails()
	{
		String urlDetails;
		
		urlDetails = "URL Protocol: " + url.getProtocol();
		urlDetails += "\n" + "URL Host: " + url.getHost();
		urlDetails += "\n" + "URL  Port: " + url.getPort();
		urlDetails += "\n" + "URL File: " + url.getFile();
		urlDetails += "\n" + "URL Path: " + url.getPath();		
		urlDetails += "\n" + "File Path: " + filePath;
		
		return urlDetails;
	}
	
	/*
		Important Function:
			Extract the web resource (a file - html, picture, sound, video)
			byte by byte. Create a file and store these bytes in it.
			
			When all bytes have downloaded, the file is formed on your hard disk
			(at the location specified by you).
	*/
	public void writeFile()
	{
		try
		{	
			/*
				Create URL Object (see "Java net package" api's)
			*/
			url = new URL(filePath); 
			
			int b;
	
			/*
				Create the appropraite File Name
			*/
			File destFile = new File(destPath);
			
			/*
				Create a "buffered" input stream that reads
				the file byte by byte.
				
				BufferedInputStream takes the InputStream object (provided
				by the URL object)
			*/
			BufferedInputStream in = new BufferedInputStream(url.openStream());
						
			/*
				To store the File (byte by byte), create
				object of FileOutputStream
			*/
			FileOutputStream out = new FileOutputStream(destFile);
		
			/*
				Read byte by byte (from the web resource) till Eof.
				
				For each byte, store it in the opened file
			*/
			while((b = in.read()) != -1)
			{
				out.write(b);
			}

			/*
				Note: Performed ASCII related file operations
				using objects of FileReader or FileWriter will
				only work for text files.
				
				You can only download images, sound and other
				multimedia formats using Byte Stream classes
				like BufferedInputStream and FileOutputStream.
				
				Refer to Java Network Tutorial.
				
				Understand difference b/w URL's and Sockets
				
				Refer to Java Input Output Tutorial also.
				
				Understand the difference between Byte and Ascii
				operations.
			*/
			
			in.close();
			out.close();
			url = null;
		}
		catch(MalformedURLException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
