ELM VE

1 Required softwares
  1. Java2 SDK, Standard Edition, v 1.4
    (http://java.sun.com/j2se/)
  2. Java3d 1.2
    (http://java.sun.com/products/java-media/3D/)
  3. Xj3D (x3d.jar)
    (http://www.web3d.org/TaskGroups/x3d/Xj3D/HowToInstall.html)
    (http://web3d.metrolink.com/cgi-bin/cvsweb.cgi/)

2 Build
  2.1 Windows
    Run build.bat and release\build.bat.
  2.2 Unix
    Run build.sh and release/build.sh.

  If you do not like compiling, you can get pre-compiled jar file
  from ELM-VE support page.

3 Install
  Copy elm.jar into j2sdk-installed-dir/jre/lib/ext.
  Make a shortcut of elm.jar at desktop if you like.

4 Run
  Double click the shortcut icon. Or enter the following command.

    java ac.hiu.j314.elmve.ElmLauncher

Support:
  http://elm-ve.sourceforge.net/

Contact:
  ksaito@do-johodai.ac.jp
