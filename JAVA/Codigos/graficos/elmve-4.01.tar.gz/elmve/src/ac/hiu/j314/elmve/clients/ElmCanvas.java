package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class ElmCanvas extends JPanel implements Runnable, ComponentListener {
    private static final long serialVersionUID = 1L;
    protected int WIDTH=400;
    protected int HEIGHT=400;
    protected int width;
    protected int height;
    BufferedImage image;
    Graphics g;
    protected ElmLightBG backGround = null;
    protected Hashtable<ElmStub,ElmLightUI> uiHash = new Hashtable<ElmStub,ElmLightUI>();
    protected Thread thread;
    double cenX = 0.0;
    double cenY = 0.0;
    double ppm = 25.0;
    ElmClient client;

    public ElmCanvas(ElmClient ec) {
        client = ec;
        this.addComponentListener(this);
        thread = new Thread(this);
        thread.setName("ElmCanvas");
        thread.setPriority(1);
        thread.start();
        this.addMouseListener(new MyMouseAdapter());
        this.addMouseMotionListener(new MyMouseMotionAdapter());
        mode = EDIT_MODE;
    }

    public void componentHidden(ComponentEvent e){;}
    public void componentMoved(ComponentEvent e){;}
    public void componentShown(ComponentEvent e){;}
    public void componentResized(ComponentEvent e){
        width = getWidth();
        height = getHeight();
        image = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
        g = image.getGraphics();
    }

    public void run() {
        while (true) {
            if ((backGround!=null)&&(g!=null)) {
                boolean needPaint = false;
                if (backGround.needPaint())
                    needPaint = true;
                Enumeration enu = uiHash.elements();
                while (enu.hasMoreElements()) {
                    ElmLightUI ui = (ElmLightUI)enu.nextElement();
                    if (ui.needPaint())
                        needPaint = true;
                }
needPaint=true;//gaha
                if (needPaint==true) {
                    Graphics gg = g.create(0,0,width,height);
                    backGround.interpolate();
                    backGround.paint(gg);
                    backGround.needPaint(false);
                    gg.dispose();
                    enu = uiHash.elements(); 
                    while (enu.hasMoreElements()) {
                        ElmLightUI ui = (ElmLightUI)enu.nextElement();
                        ui.interpolate();
                    }
                    enu = uiHash.elements(); 
                    while (enu.hasMoreElements()) {
                        ElmLightUI ui = (ElmLightUI)enu.nextElement();
                        Dimension d = ui.getSize();
                        Place pl = ui.getPlace();
                        Point po = placeToPoint(pl);
                        gg = g.create(po.x-d.width/2,po.y-d.height/2,
                                      d.width,d.height);
                        ui.paint(gg);
                        ui.needPaint(false);
                        gg.dispose();
                    }
                    repaint();
                }
                try {wait();}catch(Exception e){;}
                try {Thread.sleep(100);}catch(Exception e){;}
            }
        }
    }

    public void paint(Graphics g) {
        if (image!=null)
            g.drawImage(image,0,0,width,height,null);
        super.paintChildren(g);
        try {
            notifyAll();
        } catch(Exception e) {
        }
    }

    public Dimension getPreferredSize() {
        return new Dimension(WIDTH,HEIGHT);
    }

    protected void processElmLightPacket(ElmLightPacket elmLightPacket) {
        if (elmLightPacket.backGround != null)
            if (elmLightPacket.backGround.type == ElmLightData.NEW)
                resetBackground(elmLightPacket.backGround);
            else if (elmLightPacket.backGround.type == ElmLightData.UPDATE)
                updateBackground(elmLightPacket.backGround);
        Iterator i = elmLightPacket.eachUI.iterator();
        while (i.hasNext()) {
            ElmLightData elmLightData = (ElmLightData)i.next();
            if (elmLightData == null)
                continue;
            else if (elmLightData.type == ElmLightData.NEW)
                addNewUI(elmLightData);
            else if (elmLightData.type == ElmLightData.OLD)
                delOldUI(elmLightData);
            else if (elmLightData.type == ElmLightData.UPDATE)
                updateUI(elmLightData);
        }
        double xyz[] = new double[3];
//        elmLightPacket.camera.place.get(xyz);
//        setCenX(xyz[0]);
//        setCenY(xyz[1]);
        backGround.setCen(elmLightPacket.camera.place);
    }

    protected void resetBackground(ElmLightData elmLightData) {
        backGround = elmLightData.makeBG(this);
        backGround.setPlace(elmLightData.place);
        backGround.setElm(elmLightData.elm);
        backGround.init(elmLightData);
        backGround.needPaint(true);
        uiHash.clear();
((ElmLightClient)client).refreshElmLightCanvas();
    }

    protected void updateBackground(ElmLightData elmLightData) {
        backGround.setPlace(elmLightData.place);
        backGround.update(elmLightData);
        backGround.needPaint(true);
    }

    protected void addNewUI(ElmLightData elmLightData) {
        ElmLightUI ui = elmLightData.makeUI();
        uiHash.put(elmLightData.elm,ui);
        ui.setElm(elmLightData.elm);
        ui.init(elmLightData);
        ui.needPaint(true);
    }

    protected void delOldUI(ElmLightData elmLightData) {
        uiHash.remove(elmLightData.elm);
        backGround.needPaint(true);
    }

    protected void updateUI(ElmLightData elmLightData) {
        ElmLightUI ui = (ElmLightUI)uiHash.get(elmLightData.elm);
        if (ui == null) {
            System.out.println("ElmCanvas.updateUI(). ???");
            return;
        }
        ui.setPlace(elmLightData.place);
        ui.update(elmLightData);
        ui.needPaint(true);
    }

    public ElmLightUI getElmAt(int x,int y) {
        Enumeration enu = uiHash.elements();
        while (enu.hasMoreElements()) {
            ElmLightUI ui = (ElmLightUI)enu.nextElement();
            Dimension d = ui.getSize();
            Place pl = ui.getPlace();
            Point po = placeToPoint(pl);
            if ((po.x-d.width<x)&&(po.x+d.width>x))
                if ((po.y-d.height<y)&&(po.y+d.height>y))
                    return ui;
        }
        return null;
    }

    public void pointToPlace(Point po,Place pl) {
        double x =  ((double)(po.x-width/2))/ppm + cenX;
        double y = -((double)(po.y-height/2))/ppm + cenY;
        pl.set(x,y,0.0);
    }

    public Place pointToPlace(Point p) {
        double x =  ((double)(p.x-width/2))/ppm + cenX;
        double y = -((double)(p.y-height/2))/ppm + cenY;
        return new Place(x,y,0.0);
    }

    public Place pointToPlace(int px,int py) {
        double x =  ((double)(px-width/2))/ppm + cenX;
        double y = -((double)(py-height/2))/ppm + cenY;
        return new Place(x,y,0.0);
    }

    public void placeToPoint(Place pl,Point po) {
        double xyz[] = new double[3];
        pl.get(xyz);
        po.x =  (int)((xyz[0]-cenX)*ppm)+width/2;
        po.y = -(int)((xyz[1]-cenY)*ppm)+height/2;
    }

    public Point placeToPoint(Place p) {
        double xyz[] = new double[3];
        p.get(xyz);
        int x =  (int)((xyz[0]-cenX)*ppm)+width/2;
        int y = -(int)((xyz[1]-cenY)*ppm)+height/2;
        return new Point(x,y);
    }

    public Point placeToPoint(double x,double y) {
        int xx =  (int)((x-cenX)*ppm)+width/2;
        int yy = -(int)((y-cenY)*ppm)+height/2;
        return new Point(xx,yy);
    }

    public void setCenX(double x) {
        cenX = x;
    }

    public double getCenX() {
        return cenX;
    }

    public void setCenY(double y) {
        cenY = y;
    }

    public double getCenY() {
        return cenY;
    }

    public void setPPM(double ppm) {
        this.ppm = ppm;
    }

    public double getPPM() {
        return ppm;
    }

    public void move(Place p) {
System.out.println("gaha");
    }

//----------------------------------------------------------------------

    int mode;
    static final int RUN_MODE=0;
    static final int EDIT_MODE=1;
    static final int MOVE_MODE=2;
    static final int CUSTOMIZE_MODE=3;
    static final int CONNECT_MODE=4;
    static final int SELECT_MODE=5;
    static final int SCALE_MODE=6;
    static final int NODE_ADD_MODE=7;
    static final int NODE_DEL_MODE=8;
    Rectangle rec;
    int firstX,firstY;
    int preX,preY;
    ElmLightUI selectedElm;
    class MyMouseAdapter extends MouseAdapter {
        public void mousePressed(MouseEvent e) {
            switch (mode) {
            case EDIT_MODE:
                if ((e.getModifiers() & InputEvent.BUTTON3_MASK)!=0) {
                    firstX=preX=e.getX();
                    firstY=preY=e.getY();
                    selectedElm = getElmAt(firstX,firstY);
                    if (selectedElm==null) {
                        mode = SELECT_MODE;
                    } else {
                        Graphics g = getGraphics();
                        g.setXORMode(Color.white);
                        g.drawLine(firstX,firstY,firstX,firstY);
                        g.dispose();
                        mode = CONNECT_MODE;
                    }
               } else {
                    preX= e.getX();
                    preY= e.getY();
                    selectedElm = getElmAt(preX,preY);
                    if (selectedElm==null) {
                        mode = SELECT_MODE;
                    } else {
                        Place pl = selectedElm.getPlace();
                        Dimension d = selectedElm.getSize();
                        Point po = placeToPoint(pl);
                        rec = new Rectangle(po.x-d.width/2,po.y-d.height/2,
                                            d.width,d.height);
                        Graphics g = getGraphics();
                        g.setXORMode(Color.white);
                        g.drawRect(rec.x,rec.y,rec.width,rec.height);
                        g.dispose();
                        mode = MOVE_MODE;
                    }
                }
                break;
            case SCALE_MODE:
                break;
            }
        }

        public void mouseClicked(MouseEvent e) {
            switch (mode) {
            case EDIT_MODE:
                if (e.getClickCount()==2) {
                    ElmLightUI a = getElmAt(e.getX(),e.getY());
                    if ((e.getModifiers() & InputEvent.BUTTON1_MASK)!=0) {
                        sendCommand("openCustomizer "+a.getElm().getName());
                    } else if ((e.getModifiers() & InputEvent.BUTTON3_MASK)!=0) {
//                        if (a.isSet()) {
//                            sendCommand("cd "+a.getElm().getName());
//                        }
                    }
                } else {
                    if ((e.getModifiers() & InputEvent.BUTTON2_MASK)==0) return;
                    ElmLightUI a = getElmAt(e.getX(),e.getY());
                    if (a==null) {
                        double xyz[] = new double[3];
                        pointToPlace(e.getX(),e.getY()).get(xyz);
                        sendCommand("touchAuto "+xyz[0]+" "+xyz[1]);
                    } else {
                        sendCommand("rm "+a.getElm().getName());
                    }
                    mode = EDIT_MODE;
                }
                break;
            }
        }

        public void mouseReleased(MouseEvent e) {
            Graphics g = getGraphics();
            switch (mode) {
            case MOVE_MODE:
                g.setXORMode(Color.white);
                g.drawRect(rec.x,rec.y,rec.width,rec.height);
                Point mp = new Point(rec.x+rec.width/2,rec.y+rec.height/2);
                double xyz[] = new double[3];
                pointToPlace(mp).get(xyz);
                sendCommand("locate "+selectedElm.getElm().getName()+" "
                                          +xyz[0]+" "+xyz[1]);
                mode = EDIT_MODE;
                break;
            case CONNECT_MODE:
                g.setXORMode(Color.white);
                g.drawLine(firstX,firstY,preX,preY);
                ElmLightUI comp2 = getElmAt(e.getX(),e.getY());
                if (comp2 != null) {
                    sendCommand("connectNodes "
                                +comp2.getElm().getName()+" "
                                +selectedElm.getElm().getName());
                }
                mode = EDIT_MODE;
                break;
            case SELECT_MODE:
                mode = EDIT_MODE;
                break;
            }
            g.dispose();
        }
    }

    class MyMouseMotionAdapter extends MouseMotionAdapter {
        public void mouseDragged(MouseEvent e) {
            Graphics g = getGraphics();
            switch (mode) {
            case MOVE_MODE:
                g.setXORMode(Color.white);
                g.drawRect(rec.x,rec.y,rec.width,rec.height);
                rec = new Rectangle(rec.x+(e.getX()-preX),
                                rec.y+(e.getY()-preY),rec.width,rec.height);
                preX=e.getX();
                preY=e.getY();
                g.drawRect(rec.x,rec.y,rec.width,rec.height);
                break;
            case CONNECT_MODE:
                g.setXORMode(Color.white);
                g.drawLine(firstX,firstY,preX,preY);
                preX=e.getX();
                preY=e.getY();
                g.drawLine(firstX,firstY,preX,preY);
                break;
            }
            g.dispose();
        }
    }

    void sendCommand(String command) {
        try {
            ((ElmClient)client).processCommand(command);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
