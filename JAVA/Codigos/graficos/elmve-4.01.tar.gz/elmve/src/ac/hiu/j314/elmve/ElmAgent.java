package ac.hiu.j314.elmve;

import java.util.*;
import java.io.*;

public class ElmAgent extends Elm {
    private static final long serialVersionUID = 1L;
    String defaultChildClass = "ac.hiu.j314.elmve.Elm";
    String loginName;
    String password;
    String home;

    protected void init() {
        a2UI = "x-res:///ac/hiu/j314/elmve/ui/resources/axis.a2";
        a3UI = "x-res:///ac/hiu/j314/elmve/ui/resources/axis.a3";
//        isInterpolate = true;
    }
    public void cd(Request r) {
        String path = r.getString(0);
        
        ElmStub elm = getElm(path);
        if (elm == null) {
            send(makeReply(r,"I can not cd."));
            return;
        }
        Request req = makeRequest(ElmVE.elmVE.topElm,"transfer",
                                  this,parent,elm);
        receive(req,"cd2",r);
        send(req);
    }
    public void cd2(ReplySet rs) {
        send(makeReply(rs.getRequest(0),"Ok."));
    }

    public void go(Request r) {
        Serializable args[] = {this,r.getString(0)};
        send(makeMyOrder(getElm("/sys/transpoter"),"transportAgent",args),100);
        send(makeReply(r,"transporting..."));
    }

//----------------------------------------------------------------------

    protected void prepareForTranslation() {
        super.prepareForTranslation();
    }

    public void rm(Request r) {
        ElmStub elm = getElm(r.getString(0));
        if ((elm == null) || !(elm.isLocal())) {
            send(makeReply(r,"Remove - BAD."));
            return;
        }
        send(makeMyOrder(elm,"dispose",elm));
        send(makeReply(r,"Remove - OK."));
    }

    public void rm(Order o) {
        ElmStub elm = getElm(o.getString(0));
        if ((elm == null) || !(elm.isLocal())) {
            return;
        }
        send(makeMyOrder(elm,"dispose",elm));
    }

    public void mv(Request r) {
        ElmStub e = getElm(r.getString(0));
        if ((e == null) || !(e.isLocal())) {
            send(makeReply(r,"mv - BAD."));
            return;
        }
        send(makeMyOrder(e,"setName",r.getString(1)));
        send(makeReply(r,"mv - OK."));
    }

    public void cp(Request r) {
        ElmStub eElm = getElm(r.getString(0));
        String nElmName = r.getString(1);
        if ((eElm == null) || !(eElm.isLocal())) {
            send(makeReply(r,"No such Elm."));
            return;
        }
        Elm nElm = ElmVE.elmVE.cloneElm(eElm.elm);
        if (nElm == null) {
            send(makeReply(r,eElm.getName()+" is not cloneable."));
            return;
        }
        nElm.setName(nElmName);
        parent.elm.addElm(nElm.stub);
        send(makeReply(r,"Ok."));
    }

//----------------------------------------------------------------------

    public void addElms(Request r) {
        String className = r.getString(0);
        int nOfElm = r.getInt(1);
        for (int i=0;i<nOfElm;i++) {
            makeElm(className,"n"+i);
        }
        send(makeReply(r,"done"));
    }

    public void changeChildType(Request r) {
        defaultChildClass = r.getString(0);
        send(makeReply(r,"changeChildType - OK."));
    }

    public void cct(Request r) {
        defaultChildClass = r.getString(0);
        send(makeReply(r,"changeChildType - OK."));
    }

//----------------------------------------------------------------------

    public void load(Request r) {
        try {
            String fileName = r.getString(0);
            loadFromXML(fileName);
            send(makeReply(r,"Ok."));
        } catch (Exception e) {
            e.printStackTrace();
            send(makeReply(r,"Fail."));
        }
    }

    public void loadElmFromText(Request r) {
        try {
            String fileName = r.getString(0);
            ElmStreamTokenizer f_in = W.getEST(fileName);
            String className = f_in.nextString();
            String elmName = f_in.nextString();
            makeElm(className,elmName);
            ElmStub e = getElm(elmName);
            MyRequest rr = makeMyRequest(e,"loadFromText",fileName);
            receive(rr,"loadElmFromText2",r);
            send(rr);
        } catch (Exception ee) {
            ee.printStackTrace();
            send(makeReply(r,"Fail."));
        }
    }
    public void loadElmFromText2(ReplySet rs) {
        if ("Ok.".equals(rs.getString(0,0)))
            send(makeReply(rs.getRequest(0),"Ok."));
        else
            send(makeReply(rs.getRequest(0),"Fail."));
    }

    public void save(Request r) {
        String elmName = r.getString(0);
        String fileName = r.getString(1);
        ElmStub e = getElm(elmName);
        MyRequest rr = makeMyRequest(e,"saveAsXML",fileName);
        receive(rr,"save2",r);
        send(rr);
    }
    public void save2(ReplySet rs) {
        if ("Ok.".equals(rs.getString(0,0)))
            send(makeReply(rs.getRequest(0),"Ok."));
        else
            send(makeReply(rs.getRequest(0),"Fail."));
    }

    public void saveElmSet(Request r) {
        ElmSet es = new ElmSet();
        for (int i=0;i<(r.getArgCount()-1);i++) {
            es.add(getElm(r.getString(i)));
        }
        String fileName = r.getString(r.getArgCount()-1);
        MyRequest rr = makeMyRequest("saveElmSetAsXML",es,fileName);
        receive(rr,"saveElmSet2",r);
        send(rr);
    }
    public void saveElmSet2(ReplySet rs) {
        if ("Ok.".equals(rs.getString(0,0)))
            send(makeReply(rs.getRequest(0),"Ok."));
        else
            send(makeReply(rs.getRequest(0),"Fail."));
    }

    public void saveElmAsText(Request r) {
        String elmName = r.getString(0);
        String fileName = r.getString(1);
        ElmStub e = getElm(elmName);
        MyRequest rr = makeMyRequest(e,"saveAsText",fileName);
        receive(rr,"saveElmAsText2",r);
        send(rr);
    }
    public void saveElmAsText2(ReplySet rs) {
        if ("Ok.".equals(rs.getString(0,0)))
            send(makeReply(rs.getRequest(0),"Ok."));
        else
            send(makeReply(rs.getRequest(0),"Fail."));
    }

//----------------------------------------------------------------------

    public void locate(Request r) {
        ElmStub elm = getElm(r.getString(0));
        if ((elm != null) && (elm.isLocal())) {
            if (r.getArgCount() == 3) {
                Place p = new Place(r.getDouble(1),r.getDouble(2),0.0);
                send(makeOrder(elm,"setPlace",p));
            } else if (r.getArgCount() == 4) {
                Place p = new Place(r.getDouble(1),r.getDouble(2),
                                    r.getDouble(3));
                send(makeOrder(elm,"setPlace",p));
            } else {
                send(makeReply(r,"locate?\n"));
                return;
            }
//            a.interruption = true;
//            parent.interruption = true;
            send(makeReply(r,"locate!\n"));
            repaint(); 
        } else {
            send(makeReply(r,"??\n"));
        }
    }

    public void rotate(Request r) {
        ElmStub elm = getElm(r.getString(0));
        double x,y,z,w;
        if (elm != null) {
            Rotation ro = new Rotation(r.getDouble(1),r.getDouble(2),
                                       r.getDouble(3),r.getDouble(4));
            send(makeOrder(elm,"setRotation",ro));
            send(makeReply(r,"rotate!"));
        } else {
            send(makeReply(r,"no such elm."));
        }
    }

//----------------------------------------------------------------------

    public void goNorth(Order o) {
        place.add(new Place(0.0,0.5,0.0));
        repaint();
    }

    public void goSouth(Order o) {
        place.add(new Place(0.0,-0.5,0.0));
        repaint();
    }

    public void goWest(Order o) {
        place.add(new Place(-0.5,0.0,0.0));
        repaint();
    }

    public void goEast(Order o) {
        place.add(new Place(0.5,0.0,0.0));
        repaint();
    }

    Matrix4 mTmp = new Matrix4();
    Place vTmp = new Place();
    static Rotation luQuat =
        new Rotation( Math.sin(Math.PI/60.0),0.0,0.0,Math.cos(Math.PI/60.0));
    static Rotation ldQuat =
        new Rotation(-Math.sin(Math.PI/60.0),0.0,0.0,Math.cos(Math.PI/60.0));
    static Rotation lrQuat =
        new Rotation(0.0,-Math.sin(Math.PI/60.0),0.0,Math.cos(Math.PI/60.0));
    static Rotation llQuat =
        new Rotation(0.0, Math.sin(Math.PI/60.0),0.0,Math.cos(Math.PI/60.0));
    static Rotation tcQuat =
        new Rotation(0.0,0.0, Math.sin(Math.PI/60.0),Math.cos(Math.PI/60.0));
    static Rotation tccQuat =
        new Rotation(0.0,0.0,-Math.sin(Math.PI/60.0),Math.cos(Math.PI/60.0));
    public void lookUp(Order o) {
        rotation.mul(luQuat);
        repaint();
    }

    public void lookDown(Order o) {
        rotation.mul(ldQuat);
        repaint();
    }

    public void lookRight(Order o) {
        rotation.mul(lrQuat);
        repaint();
    }

    public void lookLeft(Order o) {
        rotation.mul(llQuat);
        repaint();
    }

    public void turnClockwise(Order o) {
        rotation.mul(tcQuat);
        repaint();
    }

    public void turnCounterclockwise(Order o) {
        rotation.mul(tccQuat);
        repaint();
    }

    public void goFront(Order o) {
        vTmp.set(0.0,0.0,-0.5);
        mTmp.set(rotation);
        mTmp.transform(vTmp);
        place.add(vTmp);
        repaint();
    }

    public void goBack(Order o) {
        vTmp.set(0.0,0.0,0.5);
        mTmp.set(rotation);
        mTmp.transform(vTmp);
        place.add(vTmp);
        repaint();
    }

    public void goRight(Order o) {
        vTmp.set(0.5,0.0,0.0);
        mTmp.set(rotation);
        mTmp.transform(vTmp);
        place.add(vTmp);
        repaint();
    }

    public void goLeft(Order o) {
        vTmp.set(-0.5,0.0,0.0);
        mTmp.set(rotation);
        mTmp.transform(vTmp);
        place.add(vTmp);
        repaint();
    }

    public void goUp(Order o) {
        vTmp.set(0.0,0.5,0.0);
        mTmp.set(rotation);
        mTmp.transform(vTmp);
        place.add(vTmp);
        repaint();
    }

    public void goDown(Order o) {
        vTmp.set(0.0,-0.5,0.0);
        mTmp.set(rotation);
        mTmp.transform(vTmp);
        place.add(vTmp);
        repaint();
    }

//----------------------------------------------------------------------

    protected String a2UI() {return "x-res:///ac/hiu/j314/elmve/ui/resources/axis.a2";}
    protected String a3UI() {return "x-res:///ac/hiu/j314/elmve/ui/resources/axis.a3";}

    protected void copyData(ElmAgent ea) {
        if (ea.children!=null) {
            Iterator i = ea.children.iterator();
            while (i.hasNext()) {
                Elm e = (Elm)i.next();
                addElm(e.stub);
            }
        }
    }
}
