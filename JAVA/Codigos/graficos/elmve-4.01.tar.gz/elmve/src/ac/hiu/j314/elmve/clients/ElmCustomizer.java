package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;

public abstract class ElmCustomizer extends Elm {
    protected ElmStub elm;
    protected ElmStub client;
    protected ElmStub avatar;

    public void setElm(ElmStub e) {
        this.elm = e;
    }

    public void setClient(ElmStub c) {
        this.client = c;
    }

    public void setAvatar(ElmStub a) {
        this.avatar = a;
    }

    public void startProcessing(MyOrder o) {
        send(makeMyOrder(elm,"addCustomizer",this.getStub(),avatar));
    }

//----------------------------------------------------------------------
    protected void send(Message m) {
        ElmStub e = m.getReceiver();
        if (!(  (e.equals(this))
              ||(e.equals(elm))
              ||(e.equals(avatar)))) {
            System.err.println("forbidden.");
            return;
        }
        super.send(m);
    }
//----------------------------------------------------------------------

    protected void dispose() {
        send(makeMyOrder(elm,"delCustomizer",this.getStub()));
        super.dispose();
    }
}
