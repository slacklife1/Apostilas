package ac.hiu.j314.elmve.graph;

import ac.hiu.j314.elmve.*;

public abstract class EIconLink extends Link {
    protected String images[] = {"x-res:///ac/hiu/j314/elmve/resources/error.gif"};

//    public EIconLink(Dummy d) {
//        super(d);
//    }

    protected String elm2DUIClass(){return "ac.hiu.j314.elmve.ui.EIcon2DUI";}
    protected String elmLightUIClass()
        {return "ac.hiu.j314.elmve.ui.EIconLightUI";}

    public void get2DUIData(MyRequest r) {
        send(makeReply(r,images,0,true));
    }
    public void get2DUIRepaintData(MyRequest r) {
        send(makeReply(r,0));
    }
    public void getLightUIData(MyRequest r) {
        send(makeReply(r,images,0,getName()));
    }
    public void getLightUIRepaintData(MyRequest r) {
        send(makeReply(r,0));
    }
}
