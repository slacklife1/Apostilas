package ac.hiu.j314.elmve.comp;

import ac.hiu.j314.elmve.*;

public class EIcon extends Elm {
    private static final long serialVersionUID = 1L;
    protected String elm2DUIClass(){return "ac.hiu.j314.elmve.ui.EIcon2DUI";}

    public void get2DUIData(MyRequest r) {
        String img0[] = {"x-res:///ac/hiu/j314/elmve/comp/resources/icon.png"};
        send(makeReply(r,img0,0,true));
    }
    public void get2DUIRepaintData(MyRequest r) {
        send(makeReply(r,0));
    }
}
