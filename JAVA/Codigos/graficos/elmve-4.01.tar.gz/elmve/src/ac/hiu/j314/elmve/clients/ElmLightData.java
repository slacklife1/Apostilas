package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;
import java.lang.reflect.*;
import java.io.*;

public class ElmLightData implements Serializable {
    private static final long serialVersionUID = 1L;
    public static final int NEW = 1;
    public static final int OLD = 2;
    public static final int UPDATE = 3;
    public int type;
    public String className;
    public ElmStub elm;
    public Place place = new Place();
    public Serializable[] data;

    public ElmLightData(int type) {
        this.type = type;
    }

    public ElmLightUI makeUI() {
        try {
            Class c = ElmVE.classLoader.loadClass(className);
            Constructor con = c.getConstructor(new Class[0]);
            ElmLightUI ui = (ElmLightUI)con.newInstance(new Object[0]);
            ui.setElm(elm);
            ui.setPlace(place);
            return ui;
        } catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public ElmLightBG makeBG(ElmCanvas canvas) {
        try {
            Class c = ElmVE.classLoader.loadClass(className);
            Constructor con = c.getConstructor(new Class[0]);
            ElmLightBG bg = (ElmLightBG)con.newInstance(new Object[0]);
            bg.setElm(elm);
            bg.setPlace(place);
            bg.canvas = canvas;
            return bg;
        } catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public int getDataCount() {
        return data.length;
    }

    public Serializable getAll() {
        return data;
    }

    public Serializable get(int i) {
        return data[i];
    }

    public int getInt(int i) {
        return ((Integer)data[i]).intValue();
    }

    public long getLong(int i) {
        return ((Long)data[i]).longValue();
    }

    public double getDouble(int i) {
        return ((Double)data[i]).doubleValue();
    }

    public boolean getBoolean(int i) {
        return ((Boolean)data[i]).booleanValue();
    }

    public String getString(int i) {
        return (String)data[i];
    }

    public Place getPlace(int i) {
        return (Place)data[i];
    }

    public Rotation getRotation(int i) {
        return (Rotation)data[i];
    }
}
