package ac.hiu.j314.elmve.graph;

public class SocketData {
    public String socketName;
    public String linkClass;
    public int linkNumber;
    public int linkedNumber;
    public int linkDirection;

    public SocketData(String sName,String cName,int no0,int no1,int d) {
        socketName = sName;
        linkClass = cName;
        linkNumber = no0;
        linkedNumber = no1;
        linkDirection = d;
    }
}
