package ac.hiu.j314.elmve;

public class ElmSystem extends Elm implements NeverSave {
    private static final long serialVersionUID = 1L;
    ElmStub client;
    ElmStub transporter;

    protected void init() {
        a2UI = "x-res:///ac/hiu/j314/elmve/ui/resources/sys.a2";
        a3UI = "x-res:///ac/hiu/j314/elmve/ui/resources/sys.a3";
    }

    public void addClient(ElmStub c) {
        client = c;
        addElm(c);
        c.elm.init();
    }

    public void addTransporter(ElmStub t) {
        transporter = t;
        addElm(t);
        t.elm.init();
    }

    public void changeJDKHome(Order o) {
        ElmVE.elmVE.elmConfig.changeJDKHome(o.getString(0));
    }
    public void changeJDKHome(Request r) {
        ElmVE.elmVE.elmConfig.changeJDKHome(r.getString(0));
        send(makeReply(r,NULL));
    }
    public void addClassPath(Order o) {
        ElmVE.elmVE.elmConfig.addClassPath(o.getString(0));
    }
    public void addClassPath(Request r) {
        ElmVE.elmVE.elmConfig.addClassPath(r.getString(0));
        send(makeReply(r,NULL));
    }
    public void refreshClassLoader(Order o) {
        ElmVE.elmVE.elmConfig.refreshClassLoader();
    }
    public void refreshClassLoader(Request r) {
        ElmVE.elmVE.elmConfig.refreshClassLoader();
        send(makeReply(r,NULL));
    }
}
