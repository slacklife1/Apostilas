package ac.hiu.j314.elmve;

import java.io.*;
import java.util.*;

public class CustomizerStack implements Serializable {
    private static final long serialVersionUID = 1L;
    //no restriction.
    public static final int POLICY0 = 0;
    //anyone can open only 1 customizer.
    public static final int POLICY1 = 1;
    //anyone can open each 1 customizer.
    public static final int POLICY2 = 2;
    //only tow users can open each 1 customizer.
    public static final int POLICY3 = 3;
    //only owner can open 1 customizer.
    public static final int POLICY4 = 4;
    //owner or admin can open 1 customizer.
    public static final int POLICY5 = 5;
    //only admin can open 1 customizer.
    public static final int POLICY6 = 6;

    int policy;
    ArrayList<Serializable[]> stack = new ArrayList<Serializable[]>();

    public CustomizerStack(int p) {
        policy = p;
    }

    public boolean isReplySuitable(ElmStub sender,ElmStub elm) {
        //sender must be ElmAvatar
        if (!sender.instanceOf("ac.hiu.j314.elmve.ElmAvatar"))
            return false;

        switch (policy) {
        case POLICY0:
System.out.println("CustomizerStack:POLICY0");
            return true;
        case POLICY1:
System.out.println("CustomizerStack:POLICY1");
            if (stack.size()==0)
                return true;
            else
                return false;
        case POLICY2:
System.out.println("CustomizerStack:POLICY2");
            Iterator i = stack.iterator();
            while (i.hasNext()) {
                Serializable s[] = (Serializable[])i.next();
                if (sender.equals((ElmStub)s[1]))
                    return false;
            }
            return true;
        case POLICY3:
System.out.println("CustomizerStack:POLICY3");
            if (stack.size()>=2)
                return false;
            i = stack.iterator();
            while (i.hasNext()) {
                Serializable s[] = (Serializable[])i.next();
                if (sender.equals((ElmStub)s[1]))
                    return false;
            }
            return true;
        case POLICY4:
System.out.println("CustomizerStack:POLICY4");
            if (sender.owner.equals(elm.owner) && stack.size()==0)
                return true;
            else
                return false;
        case POLICY5:
System.out.println("CustomizerStack:POLICY5");
            if (((sender.owner.equals(elm.owner))
		 || (sender.owner.equals(ElmVE.elmVE.admin.userID)))
                && (stack.size()==0))
                return true;
            else
                return false;
        case POLICY6:
System.out.println("CustomizerStack:POLICY6");
            if (sender.owner.equals(ElmVE.elmVE.admin.userID)&&(stack.size()==0))
                return true;
            else
                return false;
        }
        return false;
    }

    public void add(ElmStub customizer,ElmStub avatar) {
        Serializable s[] = {customizer,avatar};
        stack.add(s);
    }

    public void del(ElmStub customizer) {
        for (int i=0;i<stack.size();i++) {
            Serializable s[] = (Serializable[])stack.get(i);
            if (customizer.equals((ElmStub)s[0])) {
                stack.remove(i);
            }
        }
    }

    public ElmSet getCustomizers() {
        ElmSet ret = new ElmSet();
        Iterator i = stack.iterator();
        while (i.hasNext()) {
            Serializable s[] = (Serializable[])i.next();
            ret.add((ElmStub)s[0]);
        }
        return ret;
    }
}
