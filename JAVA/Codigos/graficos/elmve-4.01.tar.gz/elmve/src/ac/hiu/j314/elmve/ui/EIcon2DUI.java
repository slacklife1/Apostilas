package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.clients.*;
import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.net.*;

public class EIcon2DUI extends Elm2DUI {
    private static final long serialVersionUID = 1L;
    protected JLabel label;
    protected Image images[];
    protected int imageNumber = 0;
    protected static Image errImg;

    public void init(Elm2DData d) {
        try {
            setOpaque(false);
            label = new JLabel();
            add(label);
            label.setHorizontalTextPosition(JLabel.CENTER);
            label.setVerticalTextPosition(JLabel.BOTTOM);
            Serializable resourceNames[] = (Serializable[])d.get(0);
            imageNumber = d.getInt(1);
            images = new Image[resourceNames.length];

            for (int i=0;i<resourceNames.length;i++) {
                images[i]=makeImage((String)resourceNames[i]);
            }
            ImageIcon ii = new ImageIcon(images[imageNumber]);
            label.setIcon(ii);
            if (d.getBoolean(2)) {
                label.setText(elm.getName());
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public void update(Elm2DData d) {
        imageNumber = d.getInt(0);
        label.setIcon(new ImageIcon(images[imageNumber]));
        repaint();
    }

    protected Image makeImage(String source) {
        Toolkit toolkit = this.getToolkit();
        try {
            URL resource = W.getResource(source);
            return toolkit.getImage(resource);
        } catch(NullPointerException e) {
            if (errImg == null) {
                URL resource = W.getResource("x-res:///ac/hiu/j314/elmve/ui/resources/error.gif");
                errImg = toolkit.getImage(resource);
                return errImg;
            } else {
                return errImg;
            }
        }
    }
}
