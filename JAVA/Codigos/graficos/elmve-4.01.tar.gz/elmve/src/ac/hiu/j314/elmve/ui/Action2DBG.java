package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.clients.*;
import ac.hiu.j314.a23.*;
import java.awt.*;

import javax.swing.*;

public class Action2DBG extends Elm2DBG {
    private static final long serialVersionUID = 1L;
    protected Action2D a2;
    protected ImageIcon image;
    protected ImageIcon scaledImage;
    protected int wppmOld,hppmOld;

    public void init(Elm2DData d) {
        a2 = A2Loader.load(d.getString(0));
        if (a2 == null) {
System.out.println("Action2DBG.init(). gaha!!!");
            return;
        }

        setOpaque(false);
        image = new ImageIcon(a2.getImage(d.get(1)));
    }

    public void update(Elm2DData d) {
        if (a2 == null) {
System.out.println("Action2DBG.update(). gaha!!!");
            return;
        }
        image = new ImageIcon(a2.getImage(d.get(0)));
        repaint();
    }
    public void paintComponent(Graphics g) {
        if(image.getIconWidth()==-1 || image.getIconHeight()==-1){
System.out.println("Room2DBG.paintComponent().");
            repaint();
            return;
        }

        double ppm=getPPM();
        double ccx=getCenX();
        double ccy=getCenY();
        int gw,gh,wi,hi,wppm,hppm,xc,yc;
        xc=(int)(ccx*ppm);
        yc=(int)(ccy*ppm);
        wppm=(int)((double)image.getIconWidth()*(ppm/25.0));
        hppm=(int)((double)image.getIconHeight()*(ppm/25.0));
        if(wppm!=wppmOld || hppm!=hppmOld){
            scaledImage = new ImageIcon(image.getImage().getScaledInstance
                                        (wppm,hppm,Image.SCALE_DEFAULT));
            wppmOld=wppm;
            hppmOld=hppm;
        }
        gw = getWidth();
        gh = getHeight();
        for(hi=(yc%hppm)-hppm;hi<gh;hi=hi+hppm){
            for(wi=-(xc%wppm)-wppm;wi<gw;wi=wi+wppm){
                scaledImage.paintIcon(this,g,wi,hi);
            }
        }
    }
}
