package ac.hiu.j314.elmve;

import java.rmi.*;

public interface RemoteElmBridge extends Remote {
    public boolean receiveMessage(Message m) throws RemoteException;
    public ElmSet getElms(String uri) throws RemoteException;
    public byte[] loadClassData(String elmVE,String name) throws RemoteException;
    public byte[] elmFindResource(String elmVE,String name) throws RemoteException;
    public String getBridgeData() throws RemoteException;
    public void stopBridge() throws RemoteException;
}
