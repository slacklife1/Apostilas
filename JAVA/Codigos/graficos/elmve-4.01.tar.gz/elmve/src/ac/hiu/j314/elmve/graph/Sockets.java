package ac.hiu.j314.elmve.graph;

import ac.hiu.j314.elmve.*;
import java.util.*;

public class Sockets {
    public static final int HEAD = 1;
    public static final int TAIL = 2;
    public static final int BOTH = 3;

    protected Elm node;
    protected ArrayList<Socket> sockets = new ArrayList<Socket>();

    public Sockets(Elm n) {
        node = n;
    }

    public ElmSet getLinks() {
        ElmSet ret = new ElmSet();
        Iterator i = sockets.iterator();
        while (i.hasNext())
            ret.addAll(((Socket)i.next()).getLinks());
        return ret;
    }

    public void reset() {
        sockets.clear();
    }

    public void resetLink() {
        Iterator i = sockets.iterator();
        while (i.hasNext()) {
            Socket s = (Socket)i.next();
            s.resetLink();
        }
    }

    public void addSocket(String sName,String cName,int no,int direction) {
        sockets.add(new Socket(sName,cName,no,direction));
    }

    protected SocketsData getSocketsData() {
        SocketsData ret = new SocketsData();
        Iterator i = sockets.iterator();
        while (i.hasNext()) {
            ret.add(((Socket)i.next()).getSocketData());
        }
        return ret;
    }

    protected void addLink(ElmStub link,ElmStub node,
                           String sName,int direction) {
        Socket socket = null;
        Iterator i = sockets.iterator();
        while (i.hasNext()) {
            Socket s = (Socket)i.next();
            if (s.socketName.equals(sName)) {
                socket = s;
                break;
            }
        }
        if (socket != null)
            socket.add(link,node,direction);
    }

    protected void delLink(ElmStub link,ElmStub node,
                           String sName,int direction) {
        Socket socket = null;
        Iterator i = sockets.iterator();
        while (i.hasNext()) {
            Socket s = (Socket)i.next();
            if (s.socketName.equals(sName)) {
                socket = s;
                break;
            }
        }
        if (socket != null)
            socket.del(link,node,direction);
    }

    protected void delLinkByLink(ElmStub l) {
        Iterator i = sockets.iterator();
        while (i.hasNext()) {
            Socket s = (Socket)i.next();
            if (s.delLinkByLink(l))
                break;
        }
    }

    protected ElmSet getOutLinks() {
        ElmSet ret = new ElmSet();
        Iterator i = sockets.iterator();
        while (i.hasNext())
            ret.addAll(((Socket)i.next()).getOutLinks());
        return ret;
    }

    protected ElmSet getInLinks() {
        ElmSet ret = new ElmSet();
        Iterator i = sockets.iterator();
        while (i.hasNext())
            ret.addAll(((Socket)i.next()).getInLinks());
        return ret;
    }

    protected ElmSet getBothLinks() {
        ElmSet ret = new ElmSet();
        Iterator i = sockets.iterator();
        while (i.hasNext())
            ret.addAll(((Socket)i.next()).getBothLinks());
        return ret;
    }

    protected ElmSet getLinkedNodes() {
        ElmSet ret = new ElmSet();
        Iterator i = sockets.iterator();
        while (i.hasNext())
            ret.addAll(((Socket)i.next()).getLinkedNodes());
        return ret;
    }

    protected ElmSet getOutNodes() {
        ElmSet ret = new ElmSet();
        Iterator i = sockets.iterator();
        while (i.hasNext())
            ret.addAll(((Socket)i.next()).getOutNodes());
        return ret;
    }

    protected ElmSet getInNodes() {
        ElmSet ret = new ElmSet();
        Iterator i = sockets.iterator();
        while (i.hasNext())
            ret.addAll(((Socket)i.next()).getInNodes());
        return ret;
    }
}
