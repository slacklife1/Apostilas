package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;
import java.awt.*;

public abstract class ElmLightUI {
    protected final Place place = new Place();
    protected ElmStub elm;
    protected boolean interpolate = false;
    protected Place interpolatePlace;
    protected boolean needPaint;

    public abstract void init(ElmLightData data);

    public abstract void update(ElmLightData data);

    public abstract void paint(Graphics g);

    public abstract Dimension getSize();

    public void setInterpolate(boolean b) {
        if (b==true) {
            interpolate = true;
            interpolatePlace = new Place();
        } else {
            interpolate = false;
        }
    }

    public void setPlace(Place place) {
        this.place.set(place);
    }

    public Place getPlace() {
        if (interpolate) {
            return interpolatePlace;
        } else {
            return place;
        }
    }

    public void interpolate() {
        if (!interpolate)
            return;

        Place p = new Place(place);
        p.sub(interpolatePlace);
        p.scale(0.2);
        interpolatePlace.add(p);
    }

    public void setElm(ElmStub e) {
        elm = e;
    }

    public ElmStub getElm() {
        return elm;
    }

    public boolean needPaint() {
        if (interpolate==false) {
            return needPaint;
        } else if (needPaint==true) {
            return true;
        } else if ((interpolatePlace==null)||
                   (place.distance(interpolatePlace)>0.01)) {
            return true;
        } else {
            return false;
        }
    }

    public void needPaint(boolean b) {
        needPaint = b;
    }
}
