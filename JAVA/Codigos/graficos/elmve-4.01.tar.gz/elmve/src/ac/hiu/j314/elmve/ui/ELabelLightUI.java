package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.clients.*;
import java.awt.*;

public class ELabelLightUI extends ElmLightUI {
    protected String name;
    protected int width = 0;
    protected int height = 0;

    public void init(ElmLightData data) {
        name = data.getString(0);
    }
    public void update(ElmLightData data) {
        name = data.getString(0);
    }

    public void paint(Graphics g) {
        if ((width==0)||(height==0)) {
            FontMetrics fm = g.getFontMetrics();
            width = fm.stringWidth(name)+4;
            height = fm.getHeight()+2;
        }
        g.setColor(Color.green);
        g.fillRect(0,0,width,height);
        g.setColor(Color.black);
        g.drawRect(0,0,width-1,height-1);
        g.setColor(Color.black);
        g.drawString(name,2,height-6);
    }

    public Dimension getSize() {
        return new Dimension(width,height);
    }
}
