package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.clients.*;

public class Simple2DBG extends Elm2DBG {
    private static final long serialVersionUID = 1L;

    public void init(Elm2DData d) {
doLayout();
repaint();
    }

    public void update(Elm2DData d) {
doLayout();
repaint();
    }
}
