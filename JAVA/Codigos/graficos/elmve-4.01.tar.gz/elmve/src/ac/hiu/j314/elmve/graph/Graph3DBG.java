package ac.hiu.j314.elmve.graph;

import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.clients.*;
import java.util.*;
import javax.media.j3d.*;
import javax.vecmath.*;

public class Graph3DBG extends Elm3DBG {
    ArrayList lines;
    protected BranchGroup bg1;
    protected BranchGroup bg2;
    protected BranchGroup bg3;

    public void init(Elm3DData d) {
        lines = (ArrayList)d.get(0);
    }

    public javax.media.j3d.Node getSceneGraph() {
        bg1 = new BranchGroup();
        bg1.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
        bg1.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
        bg1.setCapability(BranchGroup.ALLOW_DETACH);
        bg1.setCapability(Group.ALLOW_CHILDREN_WRITE);
        bg2 = new BranchGroup();
        bg2.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
        bg2.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
        bg2.setCapability(BranchGroup.ALLOW_DETACH);
        bg1.addChild(bg2);
        bg3 = new BranchGroup();
        bg3.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
        bg3.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
        bg3.setCapability(BranchGroup.ALLOW_DETACH);
        bg1.addChild(bg3);
        Background back = new Background(0.3f,0.3f,0.5f);
        BoundingSphere bounds = new BoundingSphere(new Point3d(0.0,0.0,0.0),100.0);
        back.setApplicationBounds(bounds);
        bg2.addChild(back);

        QuadArray tfa = new QuadArray(4,GeometryArray.COORDINATES);
        tfa.setCoordinate(0,new Point3f(10.0f,-10.0f,-0.2f));
        tfa.setCoordinate(1,new Point3f(10.0f,10.0f,-0.2f));
        tfa.setCoordinate(2,new Point3f(-10.0f,10.0f,-0.2f));
        tfa.setCoordinate(3,new Point3f(-10.0f,-10.0f,-0.2f));
        Appearance look = new Appearance();
        look.setColoringAttributes(new ColoringAttributes(0.1f,0.5f,0.1f,ColoringAttributes.FASTEST));
        Shape3D shape = new Shape3D(tfa,look);
//        Shape3D shape = new com.sun.j3d.utils.geometry.ColorCube(0.01);
        bg2.addChild(shape);

        tfa = new QuadArray(4,GeometryArray.COORDINATES);
        tfa.setCoordinate(3,new Point3f(10.0f,-10.0f,-0.2f));
        tfa.setCoordinate(2,new Point3f(10.0f,10.0f,-0.2f));
        tfa.setCoordinate(1,new Point3f(-10.0f,10.0f,-0.2f));
        tfa.setCoordinate(0,new Point3f(-10.0f,-10.0f,-0.2f));
        look = new Appearance();
        look.setColoringAttributes(new ColoringAttributes(0.2f,0.2f,0.2f,ColoringAttributes.FASTEST));
        shape = new Shape3D(tfa,look);
//        shape = new com.sun.j3d.utils.geometry.ColorCube(0.01);
        bg2.addChild(shape);

        AmbientLight al = new AmbientLight(true,new Color3f(1.0f,1.0f,1.0f));
        al.setInfluencingBounds(bounds);
        bg2.addChild(al);


        look = new Appearance();
        look.setColoringAttributes(new ColoringAttributes(1.0f,1.0f,1.0f,ColoringAttributes.FASTEST));
        Iterator i = lines.iterator();
        while (i.hasNext()) {
            Line l = (Line)i.next();
            Place p1 = l.getHeadPlace();
            Place p2 = l.getTailPlace();
            double xyz[] = new double[3];
            LineArray la = new LineArray(2,LineArray.COORDINATES);
            p1.get(xyz);
            la.setCoordinate(0,new Point3d(xyz[0],xyz[1],xyz[2]));
            p2.get(xyz);
            la.setCoordinate(1,new Point3d(xyz[0],xyz[1],xyz[2]));
            shape = new Shape3D(la,look);
            bg3.addChild(shape);
        }
        return bg1;
    }

    public void update(Elm3DData d) {
        lines = (ArrayList)d.get(0);
        bg3.detach();
        bg3 = new BranchGroup();
        bg3.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
        bg3.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
        bg3.setCapability(BranchGroup.ALLOW_DETACH);
        Shape3D shape;
        Appearance look = new Appearance();
        look.setColoringAttributes(new ColoringAttributes(1.0f,1.0f,1.0f,ColoringAttributes.FASTEST));
        Iterator i = lines.iterator();
        while (i.hasNext()) {
            Line l = (Line)i.next();
            Place p1 = l.getHeadPlace();
            Place p2 = l.getTailPlace();
            double xyz[] = new double[3];
            LineArray la = new LineArray(2,LineArray.COORDINATES);
            p1.get(xyz);
            la.setCoordinate(0,new Point3d(xyz[0],xyz[1],xyz[2]));
            p2.get(xyz);
            la.setCoordinate(1,new Point3d(xyz[0],xyz[1],xyz[2]));
            shape = new Shape3D(la,look);
            bg3.addChild(shape);
        }
        bg1.addChild(bg3);
    }
}
