package ac.hiu.j314.elmve;

import java.io.*;

public class Rotation implements Serializable {
    private static final long serialVersionUID = 1L;
    double x;
    double y;
    double z;
    double w;

    public Rotation() {
        this.x = 0.0;
        this.y = 0.0;
        this.z = 0.0;
        this.w = 1.0;
    }

    public Rotation(double x,double y,double z,double w) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.w = w;
    }

    public Rotation(Rotation r) {
        this.x = r.x;
        this.y = r.y;
        this.z = r.z;
        this.w = r.w;
    }

    public synchronized void set(Rotation r) {
        x = r.x;
        y = r.y;
        z = r.z;
        w = r.w;
    }

    public synchronized void set(double r[]) {
        x = r[0];
        y = r[1];
        z = r[2];
        w = r[3];
    }

    public synchronized void get(Rotation r) {
        r.x = x;
        r.y = y;
        r.z = z;
        r.w = w;
    }

    public synchronized void get(double r[]) {
        r[0] = x;
        r[1] = y;
        r[2] = z;
        r[3] = w;
    }

    public synchronized void mul(Rotation r) {
        double xx =  x*r.w + y*r.z - z*r.y + w*r.x;
        double yy = -x*r.z + y*r.w + z*r.x + w*r.y;
        double zz =  x*r.y - y*r.x + z*r.w + w*r.z;
        double ww = -x*r.x - y*r.y - z*r.z + w*r.w;
        x = xx;
        y = yy;
        z = zz;
        w = ww;
    }

    public String toString() {
        return "("+x+", "+y+", "+z+", "+w+")";
    }
}
