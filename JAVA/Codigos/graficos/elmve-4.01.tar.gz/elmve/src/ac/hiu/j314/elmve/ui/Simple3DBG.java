package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.clients.*;
import javax.media.j3d.*;
import javax.vecmath.*;

public class Simple3DBG extends Elm3DBG {
    public Node getSceneGraph() {
        Group g = new Group();
        Background back = new Background(0.3f,0.3f,0.5f);
        BoundingSphere bounds = new BoundingSphere(new Point3d(0.0,0.0,0.0),100.0);
        back.setApplicationBounds(bounds);
        g.addChild(back);

        QuadArray tfa = new QuadArray(4,GeometryArray.COORDINATES);
        tfa.setCoordinate(0,new Point3f(10.0f,-10.0f,-3.0f));
        tfa.setCoordinate(1,new Point3f(10.0f,10.0f,-3.0f));
        tfa.setCoordinate(2,new Point3f(-10.0f,10.0f,-3.0f));
        tfa.setCoordinate(3,new Point3f(-10.0f,-10.0f,-3.0f));
        Appearance look = new Appearance();
        look.setColoringAttributes(new ColoringAttributes(0.1f,0.5f,0.1f,ColoringAttributes.FASTEST));
        Shape3D shape = new Shape3D(tfa,look);
        g.addChild(shape);

        tfa = new QuadArray(4,GeometryArray.COORDINATES);
        tfa.setCoordinate(3,new Point3f(10.0f,-10.0f,-3.0f));
        tfa.setCoordinate(2,new Point3f(10.0f,10.0f,-3.0f));
        tfa.setCoordinate(1,new Point3f(-10.0f,10.0f,-3.0f));
        tfa.setCoordinate(0,new Point3f(-10.0f,-10.0f,-3.0f));
        look = new Appearance();
        look.setColoringAttributes(new ColoringAttributes(0.2f,0.2f,0.2f,ColoringAttributes.FASTEST));
        shape = new Shape3D(tfa,look);
        g.addChild(shape);

        AmbientLight al = new AmbientLight(true,new Color3f(1.0f,1.0f,1.0f));
        al.setInfluencingBounds(bounds);
        g.addChild(al);

        g.setCapability(Group.ALLOW_CHILDREN_WRITE);
        g.setCapability(BranchGroup.ALLOW_DETACH);

        return g;
    }

    public void init(Elm3DData d) {
        ;
    }

    public void update(Elm3DData d) {
        ;
    }
}
