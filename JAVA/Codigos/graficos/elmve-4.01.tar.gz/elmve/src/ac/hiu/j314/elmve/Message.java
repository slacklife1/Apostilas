package ac.hiu.j314.elmve;

import java.io.*;

public class Message implements Serializable {
    private static final long serialVersionUID = 1L;
static int veid = (new java.util.Random()).nextInt();
static int counter = 0;
int messageID;
    ElmStub sender;
    ElmStub receiver;
    String methodName;
    Serializable arguments[];

    Message(ElmStub sender,ElmStub receiver,
            String methodName,Serializable args[]) {
this.messageID=veid+counter++;
        this.sender = sender;
        this.receiver = receiver;
        this.methodName = methodName;
        this.arguments = args;
    }

    Message(ElmStub sender,ElmStub receiver,
            String methodName,Serializable arg) {
        this.sender = sender;
        this.receiver = receiver;
        this.methodName = methodName;
        Serializable args[] = {arg};
        this.arguments = args;
    }

    public ElmStub getSender() {
        return sender;
    }

    public ElmStub getReceiver() {
        return receiver;
    }

    public String getMethodName() {
        return methodName;
    }

    public int getArgCount() {
        if (arguments==null)
            return 0;
        else
            return arguments.length;
    }

    public Serializable[] getAll() {
        return arguments;
    }

    public Serializable get(int i) {
        try {
            return arguments[i];
        } catch(NullPointerException e) {
            return null;
        }
    }

    public int getInt(int i) {
        return ((Integer)arguments[i]).intValue();
    }

    public long getLong(int i) {
        return ((Long)arguments[i]).longValue();
    }

    public double getDouble(int i) {
        return ((Double)arguments[i]).doubleValue();
    }

    public float getFloat(int i) {
        return ((Float)arguments[i]).floatValue();
    }

    public boolean getBoolean(int i) {
        return ((Boolean)arguments[i]).booleanValue();
    }

    public ElmStub getElm(int i) {
        return (ElmStub)arguments[i];
    }

    public Order getOrder(int i) {
        return (Order)arguments[i];
    }

    public MyOrder getMyOrder(int i) {
        return (MyOrder)arguments[i];
    }

    public Request getRequest(int i) {
        return (Request)arguments[i];
    }

    public MyRequest getMyRequest(int i) {
        return (MyRequest)arguments[i];
    }

    public String getString(int i) {
        return (String)arguments[i];
    }

    public Place getPlace(int i) {
        return (Place)arguments[i];
    }

    public Rotation getRotation(int i) {
        return (Rotation)arguments[i];
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append(sender.getName()+"->");
        sb.append(receiver.getName()+":");
        sb.append(methodName+"(");
        if (arguments != null) {
            for (int i=0;i<arguments.length;i++)
                sb.append(arguments[i].toString()+"  ");
        }
        sb.append(methodName+")");
        return sb.toString();
    }
}
