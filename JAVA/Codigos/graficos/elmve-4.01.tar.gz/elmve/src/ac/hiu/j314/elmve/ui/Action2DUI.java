package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.clients.*;
import ac.hiu.j314.a23.*;
import java.awt.*;
import javax.swing.*;

public class Action2DUI extends Elm2DUI {
    private static final long serialVersionUID = 1L;
    protected Action2D a2;
    protected JLabel label;

    public void init(Elm2DData d) {
        a2 = A2Loader.load(d.getString(0));
        if (a2 == null) {
System.out.println("Action2DUI.init(). gaha!!!");
            return;
        }

        setOpaque(false);
        label = new JLabel();
        add(label);
        label.setHorizontalTextPosition(JLabel.CENTER);
        label.setVerticalTextPosition(JLabel.BOTTOM);
        Image image = a2.getImage(d.get(1));
        ImageIcon ii = new ImageIcon(image);
        label.setIcon(ii);
        if (d.getString(2)!=null) {
            label.setText(d.getString(2));
        }
    }

    public void update(Elm2DData d) {
        if (a2 == null) {
System.out.println("Action2DUI.update(). gaha!!!");
            return;
        }
        Image image = a2.getImage(d.get(0));
        label.setIcon(new ImageIcon(image));
        repaint();
    }
}
