package ac.hiu.j314.elmve.graph;

import java.io.*;
import java.util.*;

public class SocketsData implements Serializable {
    private static final long serialVersionUID = 1L;
    protected ArrayList<SocketData> socketsData = new ArrayList<SocketData>();

    public void add(SocketData sd) {
        socketsData.add(sd);
    }

    public ArrayList get() {
        return socketsData;
    }
}
