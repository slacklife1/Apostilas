package ac.hiu.j314.elmve;

import java.io.*;
import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
import java.lang.reflect.*;
import java.util.*;
import java.applet.*;
import ac.hiu.j314.a23.*;

/**
 * translation messages.
 * generate and manage Elm Objects.
 *
 */

public class ElmVE extends UnicastRemoteObject implements RemoteElmVE {
    private static final long serialVersionUID = 1L;
    static ElmVE elmVE = null;
    static public ClassLoader classLoader = null;

    String keyStorePassword = "";
    ElmConfig elmConfig;
    Registry registry;
    ArrayList<Elm> allElms;
    ElmStub topElm;
    ElmStub elmSystem;
    ElmStub elmClient;
    PrintWriter logOut;
    ElmUser admin;
    ElmServer thisServer;
    ArrayList<ElmStub> allAgents = new ArrayList<ElmStub>();
    String defaultAvatarClass = "ac.hiu.j314.elmve.ElmAvatar";

    boolean noLoadDefaultRoom = false;
    boolean disableClient = false;
    boolean denyLogin = false;
    String clientClass = "ac.hiu.j314.elmve.clients.Elm2DClient";
    String baseDir = null;
    String homeDir;
    String classesDir;
    String extJarsDir;
    String avatarDir;
    String roomFile = null;
    String confFile = null;
    Applet applet = null;
    String startPlace = "/";
    String keyStoreFile = null;

//----------------------------------------------------------------------

    ElmVE() throws RemoteException {
        super();
        init();
    }
    void init() throws RemoteException {
        allElms = new ArrayList<Elm>();
        logOut = new LogWriter();
        elmConfig = new ElmConfig();
        String s = "//"+W.getIPAddress()+"/ElmVE";
        thisServer = new ElmServer(s,"thisServer");
        try {
            ElmVE.classLoader = new ElmClassLoader(this.getClass().getClassLoader());
            System.setSecurityManager(null); // JavaWebStart、かつVCompiler使用時に必要
            A23.initA23();
            A23.setClassLoader(classLoader);
        } catch(Exception e) {
            e.printStackTrace();
            System.out.println("ElmVE. initializing error!!");
        }
    }

    public boolean receiveMessage(Message m) {
        if (!elmConfig.checkImportACL(m))
            return false;
        ElmStub e = null;
        Iterator i = allElms.iterator();
        while (i.hasNext()) {
            Elm ee = (Elm)i.next();
            if (ee.stub.equals(m.receiver)) {
                e = ee.stub;
                break;
            }
        }
        if (e == null)
            return false;
        e.elm.receiveMessage(m);
        return true;
    }

    boolean sendMessage(Message m) {
        if (m.receiver.isLocal()) {
            m.receiver.elm.receiveMessage(m);
            return true;
        }
        if (!elmConfig.checkExportACL(m))
            return false;
        try {
            if (elmConfig.elmBridge.equals("none")) {
                RemoteElmVE remoteVE =
                    (RemoteElmVE)Naming.lookup(m.receiver.server.uri);
                return remoteVE.receiveMessage(m);
            } else {
                RemoteElmBridge remoteBridge =
                    (RemoteElmBridge)Naming.lookup("//"+elmConfig.elmBridge+"/ElmBridge");
                return remoteBridge.receiveMessage(m);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public ElmSet getElms(String uri) {
        if (ElmVE.elmVE.elmConfig.isPublicURI(uri)) {
            ElmSet elms = topElm.elm.getElms(uri);
            return elms;
        } else {
            return null;
        }
    }

    ElmStub refreshStub(ElmStub es) {
        Iterator i = allElms.iterator();
        while (i.hasNext()) {
            Elm ret = (Elm)i.next();
            if (ret.stub.equals(es))
                return ret.stub;
        }
        return es;
    }

    static Class argCTmp[] = new Class[0];
    static Object argOTmp[] = new Object[0];
    ElmStub makeElm(String className,String name,String owner) {
        try {
            Class c = classLoader.loadClass(className);
            Constructor con = c.getDeclaredConstructor(argCTmp);
            Elm elm = (Elm)con.newInstance(argOTmp);
            elm.stub.name = name;
            elm.stub.owner = owner;
            return elm.stub;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    ElmStub[] makeElms(String className,String names[],String owner) {
        try {
            ElmStub elms[] = new ElmStub[names.length];
            Class c = classLoader.loadClass(className);
            Constructor con = c.getDeclaredConstructor(argCTmp);
            for (int i=0;i<names.length;i++) {
                Elm elm = (Elm)con.newInstance(argOTmp);
                elm.stub.name = names[i];
                elm.stub.owner = owner;
                elms[i] = elm.stub;
            }
            return elms;
        } catch (Exception e) {
            return new ElmStub[0];
        }
    }

    void putElm(ElmStub es) {
        allElms.add(es.elm);
        if (es.elm instanceof ElmAgent)
            allAgents.add(es);
    }

    void removeElm(ElmStub es) {
        allElms.remove(es.elm);
        if (es.elm instanceof ElmAgent)
            allAgents.remove(es);
    }

    Elm cloneElm(Elm e) {
//        try {
            Elm elm = null;//(Elm)e.clone();
            allElms.add(elm);
            return elm;
//        } catch (CloneNotSupportedException ee) {
//            return null;
//        }
    }

    ElmSet getRemoteElms(String uri) {
        String path = W.getLocalPath(uri);
        String elmVEPath = W.getElmVEPath(uri);
        try {
            if (elmConfig.elmBridge.equals("none")) {
                RemoteElmVE remoteVE =
                    (RemoteElmVE)Naming.lookup(elmVEPath);
                return remoteVE.getElms(path);
            } else {
                RemoteElmBridge remoteBridge =
                    (RemoteElmBridge)Naming.lookup("//"+elmConfig.elmBridge+"/ElmBridge");
                return remoteBridge.getElms(uri);
            }
        } catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    void addLogListener(Elm elm) {
System.out.println("ElmVE.addLogListener(). Not implemented yet.");
    }

    void removeLogListener(Elm elm) {
System.out.println("ElmVE.removeLogListener(). Not implemented yet.");
    }

    public byte[] loadClassData(String name) throws RemoteException {
        return ((ElmClassLoader)classLoader).elmLoadClassData(name);
    }

    public byte[] elmFindResource(String name) throws RemoteException {
        return ((ElmClassLoader)classLoader).elmFindResource(name);
    }

//----------------------------------------------------------------------

    void parseArgs(String args[]) {
        for (int i=0;i<args.length;i++) {
            if (args[i].equals("--help")
                || args[i].equals("-h")) {
System.out.println("USAGE: java ac.hiu.j314.elmve.ElmVE [option option ...]");
System.out.println("Options");
System.out.println("  [ --help  | -h ]");
System.out.println("    print this message.");
System.out.println("  [ --name | -n ] servername");
System.out.println("    specify this server name.");
System.out.println("  [ --empty | -e ]");
System.out.println("    no load a default room.");
System.out.println("  [ --client | -c ]");
System.out.println("    specify class of client.");
System.out.println("  [ --server | -s ]");
System.out.println("    disable client. (boot as a server).");
System.out.println("  [ --deny | -d ]");
System.out.println("    deny login.");
System.out.println("  [ --room | -r ]");
System.out.println("    specify the room file.");
System.out.println("  [ --config ]");
System.out.println("    specify the config file.");
System.out.println("  [ --keystorepassword ]");
System.out.println("    specify keystore password.");
System.out.println("  [ --keystorefile ]");
System.out.println("    specify keystore file.");
System.out.println("  [ --elmbasedir ]");
System.out.println("    specify elm base directory.");
                System.exit(0);
            } else if (args[i].equals("--name")
                       || args[i].equals("-n")) {
                thisServer.setServerName(args[i+1]);
                i++;
            } else if (args[i].equals("--empty")
                       || args[i].equals("-e")) {
                noLoadDefaultRoom = true;
            } else if (args[i].equals("--client")
                       || args[i].equals("-c")) {
                clientClass = args[i+1];
                i++;
            } else if (args[i].equals("--server")
                       || args[i].equals("-s")) {
                disableClient = true;
            } else if (args[i].equals("--deny")
                       || args[i].equals("-d")) {
                denyLogin = true;
            } else if (args[i].equals("--room")
                       || args[i].equals("-r")) {
                roomFile = args[i+1];
                i++;
            } else if (args[i].equals("--config")) {
                confFile = args[i+1];
                i++;
            } else if (args[i].equals("--keystorefile")) {
                keyStoreFile = args[i+1];
                i++;
            } else if (args[i].equals("--keystorepassword")) {
                keyStorePassword = args[i+1];
                i++;
            } else if (args[i].equals("--elmbasedir")) {
                baseDir = args[i+1];
                i++;
            }
        }
    }

    void initParameter() {
        if (baseDir == null) {
            baseDir = "file:"+System.getProperty("user.home");
            baseDir = baseDir + W.sepa + ".elm";
        }
        homeDir = baseDir + W.sepa;
        homeDir = homeDir + thisServer.serverName + W.sepa;
        classesDir = homeDir+"outerClasses";
        extJarsDir = homeDir+"extJars";
        avatarDir = homeDir+"avatarDir";
        if (keyStoreFile == null)
            keyStoreFile = homeDir+"elmKeystore";

        File f = null;
        if (homeDir.startsWith("file:"))
            f = new File(homeDir.substring(5));
        else
            f = new File(homeDir);
        f.mkdirs();
        
        if (classesDir.startsWith("file:"))
            f = new File(classesDir.substring(5));
        else
            f = new File(classesDir);
        f.mkdirs();
        
        if (extJarsDir.startsWith("file:"))
            f = new File(extJarsDir.substring(5));
        else
            f = new File(extJarsDir);
        f.mkdirs();
        
        if (avatarDir.startsWith("file:"))
            f = new File(avatarDir.substring(5));
        else
            f = new File(avatarDir);
        f.mkdirs();

        if (roomFile == null)
            roomFile = homeDir + "eServer.ew";
        if (confFile == null)
            confFile = homeDir + "eServer.conf";

        if (keyStoreFile.startsWith("file:"))
            f = new File(keyStoreFile.substring(5));
        else
            f = new File(keyStoreFile);

        System.setProperty("java.rmi.server.hostname",W.getIPAddress());
        try {
            if (f.isFile()) {
                System.setProperty("javax.net.ssl.trustStore",
                                   f.getAbsolutePath());
                UnicastRemoteObject.unexportObject(this,true);
                RMISSLClientSocketFactory c = new RMISSLClientSocketFactory();
                RMISSLServerSocketFactory s =
                    new RMISSLServerSocketFactory(keyStoreFile,keyStorePassword);
                UnicastRemoteObject.exportObject(this,0,c,s);
            } else {
                UnicastRemoteObject.unexportObject(this,true);
                UnicastRemoteObject.exportObject(this,0);
            }
        } catch(Exception e) {
            e.printStackTrace();
            System.exit(0);
        }
    }

    void prepareElmSystem() {
        elmSystem = makeElm("ac.hiu.j314.elmve.ElmSystem","sys",admin.userID);
        elmSystem.elm.setPlace(new Place(0.0,5.0,0.0));
        ((TopElm)topElm.elm).addSystem(elmSystem);
    }

    void prepareClient() {
        elmClient = makeElm(clientClass,"client",admin.userID);
        elmClient.elm.setPlace(new Place(-5.0,5.0,0.0));
        ((ElmSystem)elmSystem.elm).addClient(elmClient);
        ((ElmClient)elmClient.elm).preparation();
    }

    void prepareTransporter() {
        ElmStub t = makeElm("ac.hiu.j314.elmve.Transporter",
                            "transporter",admin.userID);
        t.elm.setPlace(new Place(5.0,5.0,0.0));
        ((ElmSystem)elmSystem.elm).addTransporter(t);
    }

    void quit() {
        try {
            ((ElmClient)elmClient.elm).close();
            if (applet == null) {
                Naming.unbind(thisServer.uri);
                File f = null;
                if (homeDir.startsWith("file:"))
                    f = new File(homeDir.substring(5));
                else
                    f = new File(homeDir);
                f.mkdirs();
                ((TopElm)topElm.elm).saveWorld(roomFile);
                elmConfig.saveAsXML(confFile);
                ((TopElm)topElm.elm).recursiveDispose();
                if (homeDir.startsWith("file:"))
                    f = new File(homeDir.substring(5)+"tmp");
                else
                    f = new File(homeDir+"tmp");
                recursiveDelete(f);
                System.exit(0);
            }
        } catch(Exception e) {
            e.printStackTrace();
            if (applet == null) {
                System.exit(0);
            }
        }
    }

    void recursiveDelete(File f) {
        File ff[] = f.listFiles();
        if (ff != null)
            for (int i=0;i<ff.length;i++)
                recursiveDelete(ff[i]);
        f.delete();
    }

    void kill() {
        try {
            if (elmClient!=null)
                ((ElmClient)elmClient.elm).close();
            if (applet == null) {
                Naming.unbind(thisServer.uri);
                File f = new File(homeDir);
                f.mkdirs();
                ((TopElm)topElm.elm).saveWorld(roomFile);
                ((TopElm)topElm.elm).recursiveDispose();
                if (homeDir.startsWith("file:"))
                    f = new File(homeDir.substring(5)+"tmp");
                else
                    f = new File(homeDir+"tmp");
                recursiveDelete(f);
                System.exit(0);
            }
        } catch(Exception e) {
            e.printStackTrace();
            if (applet == null) {
                System.exit(0);
            }
        }
    }

    void bind() {
        try {
            if (applet==null) {
                String names[] = Naming.list("//localhost/");
                for (int i=0;i<names.length;i++) {
System.out.println(names[i]);
                    if (names[i].endsWith("/"+thisServer.serverName)) {
                        System.err.println("The server named '"
                                           +thisServer.serverName
					   +"' has already run");
                        System.exit(1);
                    }
                }
            }
System.out.println("gaha1");
            Naming.rebind("//localhost/"+thisServer.serverName,this);
System.out.println("gaha2");
        } catch (Exception e) {
System.out.println("ElmVE.bind() Cannot bind.(applet?)");
//            e.printStackTrace();
        }
    }

//----------------------------------------------------------------------

    void setElmClassPath(ArrayList<String> cps) {
        if (applet==null) {
            ((ElmClassLoader)classLoader).setElmClassPath(cps);
            elmConfig.saveAsXML(confFile);
        }
    }

    ArrayList getElmClassPath() {
        if (applet==null)
            return ((ElmClassLoader)classLoader).getElmClassPath();
        else
            return new ArrayList();
    }

//----------------------------------------------------------------------

    void startAsApplication(String args[]) {
        parseArgs(args);
        initParameter();
        elmConfig.loadFromXML(confFile);
System.out.println(thisServer.serverName);
        bind();
        topElm = makeElm("ac.hiu.j314.elmve.TopElm","root",admin.userID);
        topElm.path="/";
        topElm.elm.init();
        if (!noLoadDefaultRoom) {
            try {
                ((TopElm)topElm.elm).loadWorld(roomFile);
            } catch(Exception e) {
//e.printStackTrace(); //gaha
                System.out.println("Start with an empty room.");
                topElm = makeElm("ac.hiu.j314.elmve.TopElm","root",admin.userID);
                topElm.path="/";
                topElm.elm.init();
                System.out.println(roomFile);
            }
        }
        prepareElmSystem();
        if (!denyLogin)
            prepareTransporter();
        if (!disableClient)
            prepareClient();
    }

//----------------------------------------------------------------------

    void startAsApplet(Applet a) {
        applet = a;
        parseParameter();
        elmConfig.loadFromXML(confFile);
        bind();
        topElm = makeElm("ac.hiu.j314.elmve.TopElm","root",admin.userID);
        topElm.path="/";
        topElm.elm.init();
        if (!noLoadDefaultRoom) {
            try {
                ((TopElm)topElm.elm).loadWorld(roomFile);
            } catch(Exception e) {
//                e.printStackTrace();
                System.out.println("Start with an empty room.");
            }
        }
        topElm.elm.recursiveInit();
        prepareElmSystem();
        prepareClient();
        ((ElmClient)elmClient.elm).setAvatarToStartPlace(startPlace);
    }

    void parseParameter() {
        String s = applet.getParameter("name");
        if (s != null)
            thisServer.setServerName(s);
        s = applet.getParameter("client");
        if (s != null)
            clientClass = s;
        s = applet.getParameter("deny");
        if (s != null)
            denyLogin = true;
        s = applet.getParameter("roomFile");
        if (s != null)
            roomFile = s;
        s = applet.getParameter("configFile");
        if (s != null)
            confFile = s;
        s = applet.getParameter("startPlace");
        if (s != null)
            startPlace = s;
        s = applet.getParameter("keystorepassword");
        if (s != null)
            keyStorePassword = s;
System.out.println("roomFile:"+roomFile);
System.out.println("name:"+thisServer.serverName);
System.out.println("client:"+clientClass);
    }

    public void stopServer() throws RemoteException {
        Thread t = new Thread() {
            public void run() {
                try{Thread.sleep(1000);}catch(Exception e) {}
                kill();
            }
        };
        t.start();
    }
//----------------------------------------------------------------------

    public static void main(String args[]) {
        if (elmVE != null) {
            System.out.println("ElmVE must be the unique instance in a JavaVM.");
            return;
        }
        try {
            elmVE = new ElmVE();
            elmVE.startAsApplication(args);
        } catch(Exception e) {
            e.printStackTrace();
            System.exit(0);
        }
    }
}
