package ac.hiu.j314.elmve;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.io.*;

class ConfigDialog {
    static AdminConfigPane adminConfigPane;
    static CPConfigPane cpConfigPane;
    static AccountConfigPane accountConfigPane;
    static InACLConfigPane inACLConfigPane;
    static OutACLConfigPane outACLConfigPane;
    static BridgeConfigPane bridgeConfigPane;
    static PubSpacesConfigPane pubSpacesConfigPane;
    static PubClassConfigPane pubClassConfigPane;
    static ProxyConfigPane proxyConfigPane;
    static ExtJarsConfigPane extJarsConfigPane;

    static int showConfigDialog(Component parentComp,
                                       ElmConfig elmConfig) {
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("admin",null,makeAdminPanel(elmConfig),
                          "Admin configuration");
        tabbedPane.setSelectedIndex(0);
        tabbedPane.addTab("users",null,makeElmAccountsPanel(elmConfig),
                          "ELM accounts");
        tabbedPane.addTab("pubSpace",null,makePubSpacesPanel(elmConfig),
                          "Public Space");
        tabbedPane.addTab("path",null,makeElmPathPanel(elmConfig),
                          "ELM classpath");
        tabbedPane.addTab("pubClass",null,makePubClassPanel(elmConfig),
                          "Public Class");
        tabbedPane.addTab("impor",null,makeInSecurityPanel(elmConfig),
                          "Import Security");
        tabbedPane.addTab("export",null,makeOutSecurityPanel(elmConfig),
                          "Export Security");
        tabbedPane.addTab("bridge",null,makeElmBridgePanel(elmConfig),
                          "ElmBridge");
        tabbedPane.addTab("proxy",null,makeProxyPanel(elmConfig),
                          "proxy");
        tabbedPane.addTab("extJars",null,makeExtJarsPanel(elmConfig),
                          "extJars");
        Object options[] = {"Ok","Cancel"};
        int result=JOptionPane.showOptionDialog(parentComp,
                                                tabbedPane,
                                                "ConfigDialog",
                                                JOptionPane.DEFAULT_OPTION,
                                                JOptionPane.INFORMATION_MESSAGE,
                                                null,options,options[0]);
        if (result==0) {
            elmConfig.setAdmin(adminConfigPane.getAdminData());
            elmConfig.setAccountsData(accountConfigPane.getAccountsData());
            elmConfig.setPubSpacesData(pubSpacesConfigPane.getPubSpacesData());
            elmConfig.setElmClassPath(cpConfigPane.getCPConfig());
            elmConfig.setPubClassData(pubClassConfigPane.getPubClassData());
            elmConfig.setInACLData(inACLConfigPane.getInACLData());
            elmConfig.setOutACLData(outACLConfigPane.getOutACLData());
            elmConfig.setBridgeData(bridgeConfigPane.getBridgeData());
            elmConfig.setProxyData(proxyConfigPane.getProxyData());
//            elmConfig.setExtJarsData(extJarsConfigPane.getExtJarsData());
        }
        return result;
    }

    static JPanel makeAdminPanel(ElmConfig ec) {
        adminConfigPane = new AdminConfigPane(ec.getAdmin());
        return adminConfigPane;
    }

    static JPanel makeElmAccountsPanel(ElmConfig ec) {
        accountConfigPane = new AccountConfigPane(ec.getAccountsData());
        return accountConfigPane;
    }

    static JPanel makePubSpacesPanel(ElmConfig ec) {
        pubSpacesConfigPane = new PubSpacesConfigPane(ec.getPubSpacesData());
        return pubSpacesConfigPane;
    }

    static JPanel makeElmPathPanel(ElmConfig ec) {
        cpConfigPane = new CPConfigPane(ec.getElmClassPath());
        return cpConfigPane;
    }

    static JPanel makePubClassPanel(ElmConfig ec) {
        pubClassConfigPane = new PubClassConfigPane(ec.getPubClassData());
        return pubClassConfigPane;
    }

    static JPanel makeInSecurityPanel(ElmConfig ec) {
        inACLConfigPane = new InACLConfigPane(ec.getInACLData());
        return inACLConfigPane;
    }

    static JPanel makeOutSecurityPanel(ElmConfig ec) {
        outACLConfigPane = new OutACLConfigPane(ec.getOutACLData());
        return outACLConfigPane;
    }

    static JPanel makeElmBridgePanel(ElmConfig ec) {
        bridgeConfigPane = new BridgeConfigPane(ec.getBridgeData());
        return bridgeConfigPane;
    }

    static JPanel makeProxyPanel(ElmConfig ec) {
        proxyConfigPane = new ProxyConfigPane(ec.getProxyData());
        return proxyConfigPane;
    }

    static JPanel makeExtJarsPanel(ElmConfig ec) {
        extJarsConfigPane = new ExtJarsConfigPane();
        return extJarsConfigPane;
    }

    static class AdminConfigPane extends JPanel implements ActionListener {
        private static final long serialVersionUID = 1L;
        JTextField userID;
        JPasswordField password0;
        JPasswordField password1;
        JPasswordField password2;
        JButton checkButton;
        JTextField checkTF;
        AdminConfigPane(ElmUser admin) {
            JPanel panel = new JPanel();
            add(panel);
            GridBagLayout layout = new GridBagLayout();
            panel.setLayout(layout);
            GridBagConstraints c = new GridBagConstraints();
            c.fill=GridBagConstraints.HORIZONTAL;

            JLabel ll = new JLabel("userID");
            c.gridx=0;c.gridy=0;c.gridwidth=1;c.gridheight=1;
            panel.add(ll,c);

            userID = new JTextField(admin.userID,30);
            c.gridx=1;c.gridy=0;c.gridwidth=1;c.gridheight=1;
            panel.add(userID,c);

            JLabel l0 = new JLabel("OLD password");
            c.gridx=0;c.gridy=1;c.gridwidth=1;c.gridheight=1;
            panel.add(l0,c);

            password0 = new JPasswordField();
            c.gridx=1;c.gridy=1;c.gridwidth=2;c.gridheight=1;
            panel.add(password0,c);

            JLabel l1 = new JLabel("NEW password");
            c.gridx=0;c.gridy=2;c.gridwidth=1;c.gridheight=1;
            panel.add(l1,c);

            password1 = new JPasswordField();
            c.gridx=1;c.gridy=2;c.gridwidth=2;c.gridheight=1;
            panel.add(password1,c);

            JLabel l2 = new JLabel("NEW password");
            c.gridx=0;c.gridy=3;c.gridwidth=1;c.gridheight=1;
            panel.add(l2,c);

            password2 = new JPasswordField();
            c.gridx=1;c.gridy=3;c.gridwidth=2;c.gridheight=1;
            panel.add(password2,c);

            checkButton = new JButton("Check");
            checkButton.addActionListener(this);
            c.gridx=0;c.gridy=4;c.gridwidth=2;c.gridheight=1;
            panel.add(checkButton,c);

            checkTF = new JTextField(30);
            checkTF.setEditable(false);
            c.gridx=0;c.gridy=5;c.gridwidth=2;c.gridheight=1;
            panel.add(checkTF,c);
        }

        ElmUser getAdminData() {
            String ret = ElmVE.elmVE.admin.password;
            String pw0 = new String(password0.getPassword());
            String pw1 = new String(password1.getPassword());
            String pw2 = new String(password2.getPassword());
            if (ElmVE.elmVE.admin.password.equals(pw0))
                if (!pw1.equals(pw2))
                    ret = pw1;
            if (ret.equals(""))
                ret = ElmVE.elmVE.admin.password;
            return new ElmUser("admin",userID.getText(),ret,"admin",
                               "ac.hiu.j314.elmve.ElmAvatar","/");
        }

        public void actionPerformed(ActionEvent ae) {
            if (ae.getSource() == checkButton) {
                String pw0 = new String(password0.getPassword());
                String pw1 = new String(password1.getPassword());
                String pw2 = new String(password2.getPassword());
                String ret = "OK";
                if (!ElmVE.elmVE.admin.password.equals(pw0))
                    ret = "wrong!!";
                if (!pw1.equals(pw2))
                    ret = "wrong!!";
                if (pw1.equals("") || pw2.equals(""))
                    ret = "wrong!!";
                checkTF.setText(ret);
            }
        }
    }

    static class AccountConfigPane extends JPanel implements ActionListener {
        private static final long serialVersionUID = 1L;
        JList aList;
        DefaultListModel dlm;
        JTextField nameTF;
        JTextField userIDTF;
        JPasswordField passwd1PF;
        JPasswordField passwd2PF;
        JTextField roleTF;
        JTextField avatarTF;
        JTextField homeTF;
        JButton addButton;
        JButton delButton;
        ArrayList<String> passwdAL = new ArrayList<String>();
        AccountConfigPane(ArrayList ad) {
            JPanel panel = new JPanel();
            add(panel);
            GridBagLayout layout = new GridBagLayout();
            panel.setLayout(layout);
            GridBagConstraints c = new GridBagConstraints();
            c.fill=GridBagConstraints.HORIZONTAL;

            Iterator i = ad.iterator();
            dlm = new DefaultListModel();
            while (i.hasNext()) {
                ElmUser eu = (ElmUser)i.next();
                dlm.addElement(eu.name+":"+eu.userID+":"+
                               "*****"+":"+eu.role+":"+eu.avatar+":"+eu.home);
                passwdAL.add(eu.password);
            }
            aList = new JList(dlm);
            aList.setFixedCellWidth(400);
            aList.setFixedCellHeight(30);
            JScrollPane jsp = new JScrollPane(aList);
            c.gridx=0;c.gridy=0;c.gridwidth=3;c.gridheight=1;
            panel.add(jsp,c);

            JLabel l0 = new JLabel("name");
            c.gridx=0;c.gridy=1;c.gridwidth=1;c.gridheight=1;
            panel.add(l0,c);

            nameTF = new JTextField(30);
            c.gridx=1;c.gridy=1;c.gridwidth=2;c.gridheight=1;
            panel.add(nameTF,c);

            JLabel l1 = new JLabel("userID");
            c.gridx=0;c.gridy=2;c.gridwidth=1;c.gridheight=1;
            panel.add(l1,c);

            userIDTF = new JTextField(30);
            c.gridx=1;c.gridy=2;c.gridwidth=2;c.gridheight=1;
            panel.add(userIDTF,c);

            JLabel l2 = new JLabel("password");
            c.gridx=0;c.gridy=3;c.gridwidth=1;c.gridheight=1;
            panel.add(l2,c);

            passwd1PF = new JPasswordField(30);
            c.gridx=1;c.gridy=3;c.gridwidth=2;c.gridheight=1;
            panel.add(passwd1PF,c);

            JLabel l3 = new JLabel("password");
            c.gridx=0;c.gridy=4;c.gridwidth=1;c.gridheight=1;
            panel.add(l3,c);

            passwd2PF = new JPasswordField(30);
            c.gridx=1;c.gridy=4;c.gridwidth=2;c.gridheight=1;
            panel.add(passwd2PF,c);

            JLabel l4 = new JLabel("role");
            c.gridx=0;c.gridy=5;c.gridwidth=1;c.gridheight=1;
            panel.add(l4,c);

            roleTF = new JTextField("guest",30);
            c.gridx=1;c.gridy=5;c.gridwidth=2;c.gridheight=1;
            panel.add(roleTF,c);

            JLabel l5 = new JLabel("avatar");
            c.gridx=0;c.gridy=6;c.gridwidth=1;c.gridheight=1;
            panel.add(l5,c);

            avatarTF = new JTextField("default",30);
            c.gridx=1;c.gridy=6;c.gridwidth=2;c.gridheight=1;
            panel.add(avatarTF,c);

            JLabel l6 = new JLabel("home");
            c.gridx=0;c.gridy=7;c.gridwidth=1;c.gridheight=1;
            panel.add(l6,c);

            homeTF = new JTextField("/",30);
            c.gridx=1;c.gridy=7;c.gridwidth=2;c.gridheight=1;
            panel.add(homeTF,c);

            addButton = new JButton("Add");
            addButton.addActionListener(this);
            c.gridx=0;c.gridy=8;c.gridwidth=1;c.gridheight=1;
            panel.add(addButton,c);

            delButton = new JButton("Del");
            delButton.addActionListener(this);
            c.gridx=1;c.gridy=8;c.gridwidth=1;c.gridheight=1;
            panel.add(delButton,c);
        }

        public void actionPerformed(ActionEvent ae) {
            if (ae.getSource() == addButton) {
                String n = nameTF.getText();
                if (n.equals("admin"))
                    return;
                for (int i=0;i< aList.getModel().getSize();i++) {
                    StringTokenizer st = new StringTokenizer((String)dlm.getElementAt(i),":");
                    if (n.equals(st.nextToken()))
                        return;
                }
                String p1 = new String(passwd1PF.getPassword());
                String p2 = new String(passwd2PF.getPassword());
                if (!p1.equals(p2))
                    return;
                dlm.addElement(nameTF.getText()+":"+
                               userIDTF.getText()+":"+
                               "*****"+":"+
                               roleTF.getText()+":"+
                               avatarTF.getText()+":"+
                               homeTF.getText());
                passwdAL.add(p1);
                nameTF.setText("");
                userIDTF.setText("");
                passwd1PF.setText("");
                passwd2PF.setText("");
                roleTF.setText("");
                avatarTF.setText("default");
                homeTF.setText("/");
            } else if (ae.getSource() == delButton) {
                int i = aList.getSelectedIndex();
                dlm.remove(i);
                passwdAL.remove(i);
            }
        }

        public ArrayList<ElmUser> getAccountsData() {
            ArrayList<ElmUser> ret = new ArrayList<ElmUser>();
            for(int i=0;i< aList.getModel().getSize();i++) {
                StringTokenizer st =
                    new StringTokenizer((String)dlm.getElementAt(i),":");
                String name = st.nextToken();
                String userID = st.nextToken();
                String passwd = (String)passwdAL.get(i);st.nextToken();
                String role = st.nextToken();
                String avatar = st.nextToken();
                String home = st.nextToken();
                ElmUser eu = new ElmUser(name,userID,passwd,role,avatar,home);
                ret.add(eu);
            }
            return ret;
        }
    }

    static class PubSpacesConfigPane extends JPanel implements ActionListener {
        private static final long serialVersionUID = 1L;
        JList aList;
        DefaultListModel dlm;
        JTextField pathTF;
        JButton addButton;
        JButton delButton;
        PubSpacesConfigPane(ArrayList al) {
            JPanel panel = new JPanel();
            add(panel);
            GridBagLayout layout = new GridBagLayout();
            panel.setLayout(layout);
            GridBagConstraints c = new GridBagConstraints();
            c.fill=GridBagConstraints.HORIZONTAL;

            dlm = new DefaultListModel();
            Iterator i = al.iterator();
            while (i.hasNext()) {
                String s = (String)i.next();
                dlm.addElement(s);
            }
            aList = new JList(dlm);
            aList.setFixedCellWidth(400);
            aList.setFixedCellHeight(30);
            JScrollPane jsp = new JScrollPane(aList);
            c.gridx=0;c.gridy=0;c.gridwidth=3;c.gridheight=1;
            panel.add(jsp,c);

            JLabel l0 = new JLabel("path:");
            c.gridx=0;c.gridy=1;c.gridwidth=1;c.gridheight=1;
            panel.add(l0,c);

            pathTF = new JTextField(30);
            c.gridx=1;c.gridy=1;c.gridwidth=2;c.gridheight=1;
            panel.add(pathTF,c);

            c.gridx=0;c.gridy=2;c.gridwidth=1;c.gridheight=1;
            addButton = new JButton("Add");
            addButton.addActionListener(this);
            panel.add(addButton,c);

            c.gridx=1;c.gridy=2;c.gridwidth=1;c.gridheight=1;
            delButton = new JButton("Del");
            delButton.addActionListener(this);
            panel.add(delButton,c);
        }

        public void actionPerformed(ActionEvent ae) {
            if (ae.getSource() == addButton) {
                dlm.addElement(pathTF.getText());
                pathTF.setText("");
            } else if (ae.getSource() == delButton) {
                dlm.remove(aList.getSelectedIndex());
            }
        }

        public ArrayList<String> getPubSpacesData() {
            ArrayList<String> ret = new ArrayList<String>();
            for(int i=0;i< aList.getModel().getSize();i++)
                ret.add((String)dlm.getElementAt(i));
            return ret;
        }
    }

    static class CPConfigPane extends JPanel implements ActionListener {
        private static final long serialVersionUID = 1L;
        JList cpList;
        DefaultListModel dlm;
        JTextField textField;
        JButton addButton;
        JButton delButton;
        CPConfigPane(ArrayList cps) {
            JPanel panel = new JPanel();
            GridBagLayout layout = new GridBagLayout();
            panel.setLayout(layout);
            add(panel);
            GridBagConstraints c = new GridBagConstraints();
            c.fill=GridBagConstraints.HORIZONTAL;

            Iterator i = cps.iterator();
            dlm = new DefaultListModel();
            while (i.hasNext())
                dlm.addElement((String)i.next());
            cpList = new JList(dlm);
            cpList.setFixedCellWidth(400);
            cpList.setFixedCellHeight(30);
            JScrollPane jsp = new JScrollPane(cpList);
            c.gridx=0;c.gridy=0;c.gridwidth=3;c.gridheight=1;
            panel.add(jsp,c);

            JLabel l0 = new JLabel("Path:");
            c.gridx=0;c.gridy=1;c.gridwidth=1;c.gridheight=1;
            panel.add(l0,c);

            textField = new JTextField(40);
            c.gridx=1;c.gridy=1;c.gridwidth=2;c.gridheight=1;
            panel.add(textField,c);

            addButton = new JButton("Add");
            addButton.addActionListener(this);
            c.gridx=0;c.gridy=2;c.gridwidth=1;c.gridheight=1;
            panel.add(addButton,c);

            delButton = new JButton("Del");
            delButton.addActionListener(this);
            c.gridx=1;c.gridy=2;c.gridwidth=1;c.gridheight=1;
            panel.add(delButton,c);

            Component glue = Box.createGlue();
            c.gridx=2;c.gridy=2;c.gridwidth=1;c.gridheight=1;
            panel.add(glue,c);
        }

        public void actionPerformed(ActionEvent ae) {
            if (ae.getSource() == addButton) {
                dlm.addElement(textField.getText());
                textField.setText("");
            } else {
                dlm.remove(cpList.getSelectedIndex());
            }
        }

        public ArrayList<String> getCPConfig() {
            ArrayList<String> ret = new ArrayList<String>();
            for(int i=0;i< cpList.getModel().getSize();i++) {
                ret.add((String)dlm.getElementAt(i));
            }
            return ret;
        }
    }

    static class PubClassConfigPane extends JPanel implements ActionListener {
        private static final long serialVersionUID = 1L;
        JList aList;
        DefaultListModel dlm;
        JTextField pathTF;
        JButton addButton;
        JButton delButton;
        PubClassConfigPane(ArrayList al) {
            JPanel panel = new JPanel();
            add(panel);
            GridBagLayout layout = new GridBagLayout();
            panel.setLayout(layout);
            GridBagConstraints c = new GridBagConstraints();
            c.fill=GridBagConstraints.HORIZONTAL;

            dlm = new DefaultListModel();
            Iterator i = al.iterator();
            while (i.hasNext()) {
                String s = (String)i.next();
                dlm.addElement(s);
            }
            aList = new JList(dlm);
            aList.setFixedCellWidth(400);
            aList.setFixedCellHeight(30);
            JScrollPane jsp = new JScrollPane(aList);
            c.gridx=0;c.gridy=0;c.gridwidth=3;c.gridheight=1;
            panel.add(jsp,c);

            JLabel l0 = new JLabel("path:");
            c.gridx=0;c.gridy=1;c.gridwidth=1;c.gridheight=1;
            panel.add(l0,c);

            pathTF = new JTextField(30);
            c.gridx=1;c.gridy=1;c.gridwidth=2;c.gridheight=1;
            panel.add(pathTF,c);

            addButton = new JButton("Add");
            addButton.addActionListener(this);
            c.gridx=0;c.gridy=2;c.gridwidth=1;c.gridheight=1;
            panel.add(addButton,c);

            delButton = new JButton("Del");
            delButton.addActionListener(this);
            c.gridx=1;c.gridy=2;c.gridwidth=1;c.gridheight=1;
            panel.add(delButton,c);
        }

        public void actionPerformed(ActionEvent ae) {
            if (ae.getSource() == addButton) {
                dlm.addElement(pathTF.getText());
                pathTF.setText("");
            } else if (ae.getSource() == delButton) {
                dlm.remove(aList.getSelectedIndex());
            }
        }

        public ArrayList<String> getPubClassData() {
            ArrayList<String> ret = new ArrayList<String>();
            for(int i=0;i< aList.getModel().getSize();i++)
                ret.add((String)dlm.getElementAt(i));
            return ret;
        }
    }

    static class InACLConfigPane extends JPanel implements ActionListener {
        private static final long serialVersionUID = 1L;
        JComboBox defaultPolicyCB;
        JList aList;
        DefaultListModel dlm;
        JTextField stringExpressionTF;
        JButton addButton;
        JButton delButton;
        InACLConfigPane(Serializable s[]) {
            int defaultPolicy = ((Integer)s[0]).intValue();
            ArrayList al = (ArrayList)s[1];

            JPanel panel = new JPanel();
            add(panel);
            GridBagLayout layout = new GridBagLayout();
            panel.setLayout(layout);
            GridBagConstraints c = new GridBagConstraints();
            c.fill=GridBagConstraints.HORIZONTAL;

            Object objs[] = {"ACCEPT","DENY"};
            defaultPolicyCB = new JComboBox(objs);
            if (defaultPolicy==ElmACE.ACCEPT)
                defaultPolicyCB.setSelectedIndex(0);
            else
                defaultPolicyCB.setSelectedIndex(1);
            c.gridx=0;c.gridy=0;c.gridwidth=1;c.gridheight=1;
            panel.add(defaultPolicyCB,c);

            dlm = new DefaultListModel();
            Iterator i = al.iterator();
            while (i.hasNext()) {
                ElmACE ea = (ElmACE)i.next();
                dlm.addElement(ea.stringExpression);
            }
            aList = new JList(dlm);
            aList.setFixedCellWidth(400);
            aList.setFixedCellHeight(30);
            JScrollPane jsp = new JScrollPane(aList);
            c.gridx=0;c.gridy=1;c.gridwidth=3;c.gridheight=1;
            panel.add(jsp,c);

            JLabel l0 = new JLabel("ACE:");
            c.gridx=0;c.gridy=2;c.gridwidth=1;c.gridheight=1;
            panel.add(l0,c);

            stringExpressionTF = new JTextField(30);
            c.gridx=1;c.gridy=2;c.gridwidth=2;c.gridheight=1;
            panel.add(stringExpressionTF,c);

            addButton = new JButton("Add");
            addButton.addActionListener(this);
            c.gridx=0;c.gridy=3;c.gridwidth=1;c.gridheight=1;
            panel.add(addButton,c);

            delButton = new JButton("Del");
            delButton.addActionListener(this);
            c.gridx=1;c.gridy=3;c.gridwidth=1;c.gridheight=1;
            panel.add(delButton,c);
        }

        public void actionPerformed(ActionEvent ae) {
            if (ae.getSource() == addButton) {
                dlm.addElement(stringExpressionTF.getText());
                stringExpressionTF.setText("");
            } else if (ae.getSource() == delButton) {
                dlm.remove(aList.getSelectedIndex());
            }
        }

        public Serializable[] getInACLData() {
            ArrayList<ElmACE> ret = new ArrayList<ElmACE>();
            for(int i=0;i< aList.getModel().getSize();i++) {
                ElmACE ea = new ElmACE((String)dlm.getElementAt(i));
                ret.add(ea);
            }
            Integer dp = new Integer(defaultPolicyCB.getSelectedIndex()==0?
                                     ElmACE.ACCEPT:ElmACE.DENY);
            Serializable s[] = {dp,ret};
            return s;
        }
    }

    static class OutACLConfigPane extends JPanel implements ActionListener {
        private static final long serialVersionUID = 1L;
        JComboBox defaultPolicyCB;
        JList aList;
        DefaultListModel dlm;
        JTextField stringExpressionTF;
        JButton addButton;
        JButton delButton;
        OutACLConfigPane(Serializable s[]) {
            int defaultPolicy = ((Integer)s[0]).intValue();
            ArrayList al = (ArrayList)s[1];

            JPanel panel = new JPanel();
            add(panel);
            GridBagLayout layout = new GridBagLayout();
            panel.setLayout(layout);
            GridBagConstraints c =new GridBagConstraints();
            c.fill=GridBagConstraints.HORIZONTAL;

            Object o[] = {"ACCEPT","DENY"};
            defaultPolicyCB = new JComboBox(o);
            if (defaultPolicy==ElmACE.ACCEPT)
                defaultPolicyCB.setSelectedIndex(0);
            else
                defaultPolicyCB.setSelectedIndex(1);
            c.gridx=0;c.gridy=0;c.gridwidth=1;c.gridheight=1;
            panel.add(defaultPolicyCB,c);

            dlm = new DefaultListModel();
            Iterator i = al.iterator();
            while (i.hasNext()) {
                ElmACE ea = (ElmACE)i.next();
                dlm.addElement(ea.stringExpression);
            }
            aList = new JList(dlm);
            aList.setFixedCellWidth(400);
            aList.setFixedCellHeight(30);
            JScrollPane jsp = new JScrollPane(aList);
            c.gridx=0;c.gridy=1;c.gridwidth=3;c.gridheight=1;
            panel.add(jsp,c);

            JLabel l0 = new JLabel("ACE:");
            c.gridx=0;c.gridy=2;c.gridwidth=1;c.gridheight=1;
            panel.add(l0,c);

            stringExpressionTF = new JTextField(30);
            c.gridx=1;c.gridy=2;c.gridwidth=2;c.gridheight=1;
            panel.add(stringExpressionTF,c);

            addButton = new JButton("Add");
            addButton.addActionListener(this);
            c.gridx=0;c.gridy=3;c.gridwidth=1;c.gridheight=1;
            panel.add(addButton,c);

            delButton = new JButton("Del");
            delButton.addActionListener(this);
            c.gridx=1;c.gridy=3;c.gridwidth=1;c.gridheight=1;
            panel.add(delButton,c);
        }

        public void actionPerformed(ActionEvent ae) {
            if (ae.getSource() == addButton) {
                dlm.addElement(stringExpressionTF.getText());
                stringExpressionTF.setText("");
            } else if (ae.getSource() == delButton) {
                dlm.remove(aList.getSelectedIndex());
            }
        }

        public Serializable[] getOutACLData() {
            ArrayList<ElmACE> ret = new ArrayList<ElmACE>();
            for(int i=0;i< aList.getModel().getSize();i++) {
                ElmACE ea = new ElmACE((String)dlm.getElementAt(i));
                ret.add(ea);
            }
            Integer dp = new Integer(defaultPolicyCB.getSelectedIndex()==0?
                                     ElmACE.ACCEPT:ElmACE.DENY);
            Serializable s[] = {dp,ret};
            return s;
        }
    }

    static class BridgeConfigPane extends JPanel {
        private static final long serialVersionUID = 1L;
        JTextField bridgeTF;
        BridgeConfigPane(String b) {
            Box box = Box.createVerticalBox();
            add(box);
            box.add(new JLabel("Enter bridge IP address like below"));
            box.add(new JLabel("'xxx.xxx.xxx.xxx'"));
            box.add(new JLabel("if no bridge is needed 'none'"));
            bridgeTF = new JTextField(b,20);
            box.add(bridgeTF);
        }

        public String getBridgeData() {
            return bridgeTF.getText();
        }
    }

    static class ProxyConfigPane extends JPanel {
        private static final long serialVersionUID = 1L;
        JCheckBox proxySetCB;
        JTextField proxyHostTF;
        JTextField proxyPortTF;
        JCheckBox ftpProxySetCB;
        JTextField ftpProxyHostTF;
        JTextField ftpProxyPortTF;
        ProxyConfigPane(String b[]) {
            Box box = Box.createVerticalBox();
            add(box);
            proxySetCB = new JCheckBox("proxySet");
            if (b[0].equals("true"))proxySetCB.setSelected(true);
            box.add(proxySetCB);
            Box box1 = Box.createHorizontalBox();
            box1.add(new JLabel("proxyHost"));
            proxyHostTF = new JTextField(b[1],20);
            box1.add(proxyHostTF);
            box.add(box1);
            Box box2 = Box.createHorizontalBox();
            box2.add(new JLabel("proxyPort"));
            proxyPortTF = new JTextField(b[2],20);
            box2.add(proxyPortTF);
            box.add(box2);
            ftpProxySetCB = new JCheckBox("ftpProxySet");
            if (b[3].equals("true"))ftpProxySetCB.setSelected(true);
            box.add(ftpProxySetCB);
            Box box3 = Box.createHorizontalBox();
            box3.add(new JLabel("ftpProxyHost"));
            ftpProxyHostTF = new JTextField(b[4],20);
            box3.add(ftpProxyHostTF);
            box.add(box3);
            Box box4 = Box.createHorizontalBox();
            box4.add(new JLabel("ftpProxyPort"));
            ftpProxyPortTF = new JTextField(b[5],20);
            box4.add(ftpProxyPortTF);
            box.add(box4);
        }

        public String[] getProxyData() {
            String p[] = new String[6];
            p[0]=proxySetCB.isSelected()?"true":"false";
            p[1]=proxyHostTF.getText();
            p[2]=proxyPortTF.getText();
            p[3]=ftpProxySetCB.isSelected()?"true":"false";
            p[4]=ftpProxyHostTF.getText();
            p[5]=ftpProxyPortTF.getText();
            return p;
        }
    }

    static class ExtJarsConfigPane extends JPanel implements ActionListener {
        private static final long serialVersionUID = 1L;
        JList ejList;
        DefaultListModel dlm;
        JButton addButton;
        JButton delButton;
        ExtJarsConfigPane() {
            JPanel panel = new JPanel();
            GridBagLayout layout = new GridBagLayout();
            panel.setLayout(layout);
            add(panel);
            GridBagConstraints c = new GridBagConstraints();
            c.fill=GridBagConstraints.HORIZONTAL;

            String extJarsDirString = null;
            if (ElmVE.elmVE.extJarsDir.startsWith("file:"))
                extJarsDirString = ElmVE.elmVE.extJarsDir.substring(5);
            else
                extJarsDirString = ElmVE.elmVE.extJarsDir;
            File extJarsDir = new File(extJarsDirString);
            String extJars[] = extJarsDir.list();
            dlm = new DefaultListModel();
            for (int i=0;i<extJars.length;i++)
                dlm.addElement(extJars[i]);
            ejList = new JList(dlm);
            ejList.setFixedCellWidth(400);
            ejList.setFixedCellHeight(30);
            JScrollPane jsp = new JScrollPane(ejList);
            c.gridx=0;c.gridy=0;c.gridwidth=3;c.gridheight=1;
            panel.add(jsp,c);

            addButton = new JButton("Add");
            addButton.addActionListener(this);
            c.gridx=0;c.gridy=1;c.gridwidth=1;c.gridheight=1;
            panel.add(addButton,c);

            delButton = new JButton("Del");
            delButton.addActionListener(this);
            c.gridx=1;c.gridy=1;c.gridwidth=1;c.gridheight=1;
            panel.add(delButton,c);

            Component glue = Box.createGlue();
            c.gridx=2;c.gridy=1;c.gridwidth=1;c.gridheight=1;
            panel.add(glue,c);
        }

        public void actionPerformed(ActionEvent ae) {
            if (ae.getSource() == addButton) {
                JFileChooser chooser = new JFileChooser();
                int returnVal = chooser.showOpenDialog(this);
                if(returnVal == JFileChooser.APPROVE_OPTION) {
                    try {
                        File input = chooser.getSelectedFile();
                        String extJarsDirString = null;
                        if (ElmVE.elmVE.extJarsDir.startsWith("file:"))
                            extJarsDirString = ElmVE.elmVE.extJarsDir.substring(5);
                        else
                            extJarsDirString = ElmVE.elmVE.extJarsDir;
                        File output = new File(extJarsDirString+W.sepa
                                               +input.getName());
                        FileInputStream fis = new FileInputStream(input);
                        FileOutputStream fos = new FileOutputStream(output);
                        byte buf[]=new byte[256];
                        int len;
                        while((len=fis.read(buf))!=-1)
                            fos.write(buf,0,len);
                        fos.flush();
                        fos.close();
                        fis.close();
                        dlm.addElement(input.getName());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } else {
                String rmFile = (String)ejList.getSelectedValue();
                String extJarsDirString = null;
                if (ElmVE.elmVE.extJarsDir.startsWith("file:"))
                    extJarsDirString = ElmVE.elmVE.extJarsDir.substring(5);
                else
                    extJarsDirString = ElmVE.elmVE.extJarsDir;
                File f = new File(extJarsDirString+W.sepa+rmFile);
                f.delete();
                dlm.remove(ejList.getSelectedIndex());
            }
        }
    }
}
