package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.clients.*;
import ac.hiu.j314.a23.*;
import java.awt.*;

public class ActionLightUI extends ElmLightUI {
    protected Action2D a2;
    protected String label = null;
    protected Image image;
    protected int width = 0;
    protected int height = 0;
    protected int labelWidth = 0;
    protected int labelHeight = 0;

    public void init(ElmLightData d) {
        a2 = A2Loader.load(d.getString(0));
        if (a2 == null) {
            System.out.println("ActionLightUI.init(). gaha!!!");
            return;
         }
        image = a2.getImage(d.get(1));
        label = d.getString(2);
        setInterpolate(d.getBoolean(3));
    }

    public void update(ElmLightData d) {
        if (a2 == null) {
            System.out.println("ActionLightUI.update(). gaha!!!");
            return;
         }
        image = a2.getImage(d.get(0));
    }

    public void paint(Graphics g) {
        if (a2 != null) {
            int x = width/2-image.getWidth(null)/2;
            g.drawImage(image,x,0,null);
        }
        if (((labelWidth==0)||(labelHeight==0))&&(label!=null)) {
            FontMetrics fm = g.getFontMetrics();
            labelWidth = fm.stringWidth(label);
            labelHeight = fm.getHeight();
        }
        if (label != null) {
            int x = width/2-labelWidth/2;
            g.setColor(Color.black);
            g.drawString(label,x,height-4);
        }
    }

    public Dimension getSize() {
        if (a2 == null) {
            width = 0;
            height = 0;
        } else {
            width = image.getWidth(null);
            height = image.getHeight(null);
        }
        if (label!=null) {
            width = (width<labelWidth)?labelWidth:width;
            height = height + labelHeight;
        }
        return new Dimension(width,height);
    }
}
