package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.clients.*;
import java.awt.*;

public class EHiddenLightUI extends ElmLightUI {

    public void init(ElmLightData data) {
    }
    public void update(ElmLightData data) {
    }

    public void paint(Graphics g) {
    }

    public Dimension getSize() {
        return new Dimension(1,1);
    }
}
