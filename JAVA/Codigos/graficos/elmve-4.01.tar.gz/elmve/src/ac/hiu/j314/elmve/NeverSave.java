package ac.hiu.j314.elmve;

public interface NeverSave {
}
