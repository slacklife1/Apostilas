package ac.hiu.j314.elmve.graph;

import ac.hiu.j314.elmve.clients.*;
import java.awt.*;
import java.util.*;

public class Graph2DBG extends Elm2DBG {
    private static final long serialVersionUID = 1L;
    ArrayList lines;

    public void init(Elm2DData d) {
        lines = (ArrayList)d.get(0);
    }

    public void update(Elm2DData d) {
        lines = (ArrayList)d.get(0);
    }

    public void paintComponent(Graphics g) {
        g.setColor(getBackground());
        g.fillRect(0,0,getWidth(),getHeight());
        if (lines == null)
            return;
        g.setColor(Color.black);
        Iterator i = lines.iterator();
        Point p1;
        Point p2;
        while (i.hasNext()) {
            Line l = (Line)i.next();
            p1 = placeToPoint(l.getHeadPlace());
            p2 = placeToPoint(l.getTailPlace());
            l.paint(g,p1,p2);
        }
    }

    public void setCenX(double x) {;}
    public void setCenY(double y) {;}
    public void setPPM(double ppm) {;}
    public double getCenX() {return 0.0;}
    public double getCenY() {return 0.0;}
    public double getPPM() {return 0.0;}
}
