package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;

import java.io.*;

import javax.media.j3d.*;

public abstract class Elm3DBG {
    public static final Serializable NULL = Elm.NULL;
    public static final Serializable OK = Elm.OK;
    public static final Serializable ERROR = Elm.ERROR;

    String name;
    protected ElmClient client;
    protected ElmStub elm;

    public void setName(String name) {
        this.name = name;
    }

    public abstract void init(Elm3DData data);

    public abstract void update(Elm3DData data);

    public abstract Node getSceneGraph();

    public BranchGroup getBranchGroup() {
        BranchGroup bg = new BranchGroup();
        TransformGroup tg = new TransformGroup();
        bg.addChild(tg);
        tg.addChild(getSceneGraph());
        bg.setCapability(Group.ALLOW_CHILDREN_WRITE);
        bg.setCapability(BranchGroup.ALLOW_DETACH);
        return bg;
    }

    public void setElm(ElmStub e) {
        elm = e;
    }

    public void setClient(ElmClient c) {
        client = c;
    }

//----------------------------------------------------------------------
    public UIOrder makeOrder(String methodName,Serializable... args) {
        return new UIOrder(methodName,args);
    }
    public UIMyOrder makeMyOrder(String methodName,Serializable... args) {
        return new UIMyOrder(methodName,args);
    }
    public void send(UIMessage msg) {
        if (msg instanceof UIOrder)
            client.relayOrder(elm,msg.methodName,msg.arguments);
        else if (msg instanceof UIMyOrder)
            client.relayMyOrder(elm,msg.methodName,msg.arguments);
    }
}
