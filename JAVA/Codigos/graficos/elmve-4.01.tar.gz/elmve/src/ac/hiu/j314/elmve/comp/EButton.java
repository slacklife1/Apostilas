package ac.hiu.j314.elmve.comp;

import ac.hiu.j314.elmve.*;

public class EButton extends Elm {
    private static final long serialVersionUID = 1L;

    protected String elm2DUIClass(){return "ac.hiu.j314.elmve.ui.EButton2DUI";}

    public void get2DUIData(MyRequest r) {
        send(makeReply(r,getName()));
    }
    public void get2DUIRepaintData(MyRequest r) {
        send(makeReply(r,NULL));
    }

    public void catchEButtonEvent(Order o) {
System.out.println("EButton.catchEButtonEvent().");
    }
}
