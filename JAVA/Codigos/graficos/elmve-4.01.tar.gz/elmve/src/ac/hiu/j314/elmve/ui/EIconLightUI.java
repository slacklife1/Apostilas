package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.clients.*;
import java.awt.*;
import java.io.*;
import java.net.*;

public class EIconLightUI extends ElmLightUI {
    protected String label = null;
    protected Image images[];
    protected int imageNumber = 0;
    protected int width;
    protected int height;
    protected int labelWidth = 0;
    protected int labelHeight = 0;
    protected static Image errImg;

    public void init(ElmLightData d) {
        try {
            Serializable resourceNames[] = (Serializable[])d.get(0);
            imageNumber = d.getInt(1);
            label = d.getString(2);
            images = new Image[resourceNames.length];

            for (int i=0;i<resourceNames.length;i++) {
                images[i]=makeImage((String)resourceNames[i]);
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public void update(ElmLightData d) {
        imageNumber = d.getInt(0);
    }

    public void paint(Graphics g) {
        if (((labelWidth==0)||(labelHeight==0))&&(label!=null)) {
            FontMetrics fm = g.getFontMetrics();
            labelWidth = fm.stringWidth(label);
            labelHeight = fm.getHeight();
        }
        if (images[imageNumber]!=null) {
            int x = width/2-images[imageNumber].getWidth(null)/2;
            g.drawImage(images[imageNumber],x,0,null);
        }
        if (label!=null) {
            int x = width/2-labelWidth/2;
            g.setColor(Color.black);
            g.drawString(label,x,height-4);
        }
    }

    public Dimension getSize() {
        if (images[imageNumber]==null) {
            width=0;
            height=0;
        } else {
            width = images[imageNumber].getWidth(null);
            height = images[imageNumber].getHeight(null);
        }
        if (label!=null){
            width = (width<labelWidth)?labelWidth:width;
            height = height + labelHeight;
        }
        return new Dimension(width,height);
    }

    protected Image makeImage(String source) {
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        try {
            URL resource = W.getResource(source);
            return toolkit.getImage(resource);
        } catch(NullPointerException e) {
            if (errImg == null) {
                URL resource = W.getResource("x-res:///ac/hiu/j314/elmve/ui/resources/error.gif");
                errImg = toolkit.getImage(resource);
                return errImg;
            } else {
                return errImg;
            }
        }
    }
}
