package ac.hiu.j314.elmve;

import java.io.*;
import java.util.*;
import java.net.*;
import org.w3c.dom.*;

public class TopElm extends Elm {
    private static final long serialVersionUID = 1L;
    ElmStub elmSystem;

    protected void init() {
        super.init();
        initOwnEngine("topElm",1);
    }

    public void repaint() {
        return;
    }

    /**
      * saveWorld
      */
    void saveWorld(String fileName) {
        try {
            if (fileName.startsWith("file:"))
                fileName = fileName.substring(5);
            FileOutputStream os = new FileOutputStream(fileName);

            Document d = W.makeEmptyDocumentDOM();
            Element e = W.makeElementDOM(d,"elmWorld");
            W.addChildDOM(d,e);
            W.addLineFeedDOM(d,e);

            ArrayList<Elm> al = getAllDescendants(new ArrayList<Elm>());
            Iterator i = al.iterator();
            while (i.hasNext()) {
                Elm elm = (Elm)i.next();
                if (elm.stub.instanceOf("ac.hiu.j314.elmve.EcoElm"))
                    if (((EcoElm)elm).areChildrenSleeping==true)
                        ((EcoElm)elm).wakeChildrenUp();
            }
            al = getAllDescendants(new ArrayList<Elm>());
            i = al.iterator();
            while (i.hasNext()) {
                Elm elm = (Elm)i.next();
                if (elm.stub.instanceOf("ac.hiu.j314.elmve.NeverSave"))
                    continue;
                Element ee = W.makeElementDOM(d,"elm");
                W.addChildDOM(e,ee);
                if (elm==this)
                    W.addAttrDOM(d,ee,"rootElm","true");
                elm.saveAsXML(d,ee);
                W.addLineFeedDOM(d,e);
            }

            W.saveDocumentToOutputStreamDOM(d,os);
        } catch(Exception e) {
	    e.printStackTrace();
        }
    }

    public void saveWorld(MyRequest r) {
        String fileName = r.getString(0);
        try {
            saveWorld(fileName);
            send(makeReply(r,"Ok."));
        } catch (Exception e) {
            send(makeReply(r,"Fail."));
        }
        
    }

    /* toSaveString (except client) */
    public String toSaveString() {
        StringBuffer sb = new StringBuffer();
        sb.append("//[][][][][] Elm's status [][][][][]\n");
        sb.append("//***** Class and Name *****\n");
        sb.append(this.getClass().getName()+" \""+stub.name+"\"\n");
        double d[] = new double[4];
        this.place.get(d);
        sb.append("//x y z\n");
        sb.append(d[0]+" "+d[1]+" "+d[2]+"\n");
        this.rotation.get(d);
        sb.append("//rotation\n");
        sb.append(d[0]+" "+d[1]+" "+d[2]+" "+d[3]+"\n");
        sb.append("//number of children\n");
        if (children == null) {
            sb.append("0\n");
        } else {
            int n = 0;
            if (getLocalElms("client").size() != 0)
                n++;
            if (getLocalElms("transporter").size() != 0)
                n++;
            sb.append(""+(children.size()-n)+"\n");
            Iterator i = children.iterator();
            sb.append("//children class and name\n");
            while (i.hasNext()) {
                Elm le = (Elm)i.next();
                if (le.getName().equals("client"))
                    continue;
                if (le.getName().equals("transporter"))
                    continue;
                sb.append(le.getClass().getName());
                sb.append("  "+le.getName()+"\n");
            }
            sb.append("// each child data\n");
            i = children.iterator();
            while (i.hasNext()) {
                Elm le = (Elm)i.next();
                if (le.getName().equals("sys"))
                    continue;
                sb.append(le.toSaveString());
            }
        }
        return sb.toString();
    }

    void loadWorld(String fileName) throws IOException {
        URL url = W.getResource(fileName);
        InputStream is = url.openStream();

        Document d = W.loadDocumentFromInputStreamDOM(is);
        Element e = d.getDocumentElement();

        if (!e.getTagName().equals("elmWorld")) {
            System.out.println("TopElm.loadWorld(). Wrong data.");
            return;
        }

        children = new ArrayList<Elm>(); // clear !!!

        LoadedElmSet elmSet = new LoadedElmSet();
        ElmStub rootElm = null;
        ArrayList al = W.getChildrenByTagNameDOM(e,"elm");
        Iterator i = al.iterator();
        while (i.hasNext()) {
            ElmStub es = makeElmFromXMLWorld((Element)i.next(),elmSet);
            if (es!=null)
                rootElm = es;
        }

        i = al.iterator();
        while (i.hasNext())
            loadBasicDataFromXMLWorld((Element)i.next(),elmSet);

        rootElm.elm.recursiveInit();

        i = al.iterator();
        while (i.hasNext())
            loadExtensionExecWorld((Element)i.next(),elmSet);
    }

    ElmStub makeElmFromXMLWorld(Element e,LoadedElmSet elmSet) {
        Element ee = W.getChildByTagNameDOM(e,"basicData");
        Element eee = W.getChildByTagNameDOM(ee,"stub");
        String name = W.getDataDOM(eee,"name");
        String className = W.getDataDOM(eee,"className");
        String owner = W.getDataDOM(eee,"owner");
        long oldID = Long.parseLong(W.getDataDOM(eee,"elmID"));
        if (ElmStub.idCounter<=oldID)
            ElmStub.idCounter = oldID+1;
        Elm elm = null;
        if (W.getAttrDataDOM(e,"rootElm").equals("true")) {
            elm = this;
            elm.stub.name = name;
            elm.stub.owner = owner;
            elm.stub.elmID=oldID;
            elmSet.addElm(elm.stub.elmID,elm.stub);
            if (ElmStub.idCounter <= oldID)
                ElmStub.idCounter = oldID+1;
            return elm.stub;
        } else {
            elm = ElmVE.elmVE.makeElm(className,name,owner).elm;
            elm.stub.elmID=oldID;
            elmSet.addElm(elm.stub.elmID,elm.stub);
            if (ElmStub.idCounter <= oldID)
                ElmStub.idCounter = oldID+1;
            return null;
        }
    }

    void loadBasicDataFromXMLWorld(Element e,LoadedElmSet elmSet) {
        Element basicData = W.getChildByTagNameDOM(e,"basicData");
        Element stubData = W.getChildByTagNameDOM(basicData,"stub");

        long elmID = Long.parseLong(W.getDataDOM(stubData,"elmID"));
        ElmStub es = elmSet.getElm(elmID);
        if (es == null) {
            System.out.println("TopElm.loadBasicDataFromXMLWorld(). ???");
            return;
        }

        Element place = W.getChildByTagNameDOM(basicData,"place");
        Element rotation = W.getChildByTagNameDOM(basicData,"rotation");

        es.loadFromXML(stubData);

        double xyzw[] = new double[4];
        xyzw[0] = Double.parseDouble(W.getAttrDataDOM(place,"x"));
        xyzw[1] = Double.parseDouble(W.getAttrDataDOM(place,"y"));
        xyzw[2] = Double.parseDouble(W.getAttrDataDOM(place,"z"));
        es.elm.place.set(xyzw);

        xyzw[0] = Double.parseDouble(W.getAttrDataDOM(rotation,"x"));
        xyzw[1] = Double.parseDouble(W.getAttrDataDOM(rotation,"y"));
        xyzw[2] = Double.parseDouble(W.getAttrDataDOM(rotation,"z"));
        xyzw[3] = Double.parseDouble(W.getAttrDataDOM(rotation,"w"));
        es.elm.rotation.set(xyzw);

        Element children = W.getChildByTagNameDOM(e,"children");
        ArrayList al = W.getChildrenByTagNameDOM(children,"elmRef");
        Iterator i = al.iterator();
        while (i.hasNext()) {
            Element elmRef = (Element)i.next();
            elmID = Long.parseLong(W.getAttrDataDOM(elmRef,"elmID"));
            es.elm.addElm(elmSet.getElm(elmID));
        }
    }

    void loadExtensionExecWorld(Element e,LoadedElmSet elmSet) {
        Element basicData = W.getChildByTagNameDOM(e,"basicData");
        Element stubData = W.getChildByTagNameDOM(basicData,"stub");

        long elmID = Long.parseLong(W.getDataDOM(stubData,"elmID"));
        ElmStub es = elmSet.getElm(elmID);
        if (es==null) {
            System.out.println("TopElm.loadExtensionExecWorld(). ???");
            return;
        }

        Element ext = W.getChildByTagNameDOM(e,"extension");
        es.elm.loadExtension(ext,elmSet);
    }

    /**
      * loadFromText(tokenizer)
      */
    public void loadFromText(ElmStreamTokenizer f_in) throws IOException {
        if (!f_in.nextString().equals(this.getClass().getName()))
            throw new IOException("Elm.loadFromText(); class does not match!");
        stub.name = f_in.nextString();
        double d[] = new double[4];
        d[0] = f_in.nextDouble();
        d[1] = f_in.nextDouble();
        d[2] = f_in.nextDouble();
        place.set(d);
        d[0] = f_in.nextDouble();
        d[1] = f_in.nextDouble();
        d[2] = f_in.nextDouble();
        d[3] = f_in.nextDouble();
        rotation.set(d);
        int cNumber = f_in.nextInt();
        if (cNumber != 0) {
            children = new ArrayList<Elm>();
            String nameTmp[] = new String[cNumber];
            for (int i=0;i<cNumber;i++) {
                String className = f_in.nextString();
                nameTmp[i] = f_in.nextString();
                makeElmInside(className,nameTmp[i]);
            }
            for (int i=0;i<cNumber;i++) {
                ElmStub le = getLocalElm("/"+nameTmp[i]);
                le.elm.loadFromText(f_in);
            }
        }
    }

    public void addSystem(ElmStub c) {
        elmSystem = c;
        addElm(c);
        c.elm.init();
    }

    public void setElmClassPath(Request r) {
        ArrayList<String> al = (ArrayList<String>)r.get(0);
        ElmVE.elmVE.setElmClassPath(al);
        send(makeReply(r,"ok"));
    }

    public void getElmClassPath(Request r) {
        send(makeReply(r,ElmVE.elmVE.getElmClassPath()));
    }

    public void transfer(Request r) {
        Elm e = (Elm)r.get(0);
        ElmStub f = r.getElm(1);
        ElmStub t =r.getElm(2);
        f.elm.delElm(e.stub);
        if (t.instanceOf("ac.hiu.j314.elmve.EcoElm")) {
            MyRequest rr = makeMyRequest(t,"wakeChildrenUp",NULL);
            receive(rr,"transfer2",r);
            send(rr);
        } else {
            send(makeMyOrder("transfer3",r));
        }
    }
    public void transfer2(ReplySet rs) {
        send(makeMyOrder("transfer3",rs.getRequest(0)));
    }
    public void transfer3(MyOrder o) {
        Request r = o.getRequest(0);
        Elm     e = (Elm)r.get(0);
        ElmStub t = r.getElm(2);
        t.elm.addElm(e.stub);
        send(makeReply(r,"Ok"));
    }

    protected void dispose() {
    }
}
