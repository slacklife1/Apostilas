package ac.hiu.j314.elmve;

import java.util.*;
import java.io.*;
import org.w3c.dom.*;

//     ADMIN   SELF  OWNER REMOTE
// ANT
// APE
// BAT
// BEE
// CAT
// COW
// DOG
// ELK
// FLY
// FOX
// GNU
// HEN
// OWL
// PIG
// RAT
// YAK

public final class ElmACL {
    //simple policy
    public static final int ANT =  0;
    public static final int APE =  1;
    public static final int BAT =  2;
    public static final int BEE =  3;
    public static final int CAT =  4;
    public static final int COW =  5;
    public static final int DOG =  6;
    public static final int ELK =  7;
    public static final int FLY =  8;
    public static final int FOX =  9;
    public static final int GNU = 10;
    public static final int HEN = 11;
    public static final int OWL = 12;
    public static final int PIG = 13;
    public static final int RAT = 14;
    public static final int YAK = 15;

    ArrayList<ElmACE> acl;
    int defaultPolicy;
    boolean locked = false;

    public ElmACL() {
        acl = new ArrayList<ElmACE>();
    }

    public ElmACL(boolean dp) {
        acl = new ArrayList<ElmACE>();
        defaultPolicy = (dp?ElmACE.ACCEPT:ElmACE.DENY);
    }

    public ElmACL(int i) {
        acl = new ArrayList<ElmACE>();
        switch (i) {
        case ANT:
            defaultPolicy = ElmACE.ACCEPT;
            locked = true;
            break;
        case APE:
            acl.add(new ElmACE("S_SELF ACCEPT"));
            acl.add(new ElmACE("S_SAMEOWNER ACCEPT"));
            acl.add(new ElmACE("S_ADMIN ACCEPT"));
            defaultPolicy = ElmACE.DENY;
            locked = true;
            break;
        case BAT:
            acl.add(new ElmACE("S_ADMIN ACCEPT"));
            defaultPolicy = ElmACE.DENY;
            locked = true;
            break;
        case BEE:
            acl.add(new ElmACE("S_ADMIN ACCEPT"));
            defaultPolicy = ElmACE.DENY;
            locked = true;
            break;
        case CAT:
            acl.add(new ElmACE("S_ADMIN ACCEPT"));
            defaultPolicy = ElmACE.DENY;
            locked = true;
            break;
        case COW:
            acl.add(new ElmACE("S_ADMIN ACCEPT"));
            defaultPolicy = ElmACE.DENY;
            locked = true;
            break;
        case DOG:
            acl.add(new ElmACE("S_ADMIN ACCEPT"));
            defaultPolicy = ElmACE.DENY;
            locked = true;
            break;
        case ELK:
            acl.add(new ElmACE("S_ADMIN ACCEPT"));
            defaultPolicy = ElmACE.DENY;
            locked = true;
            break;
        case FLY:
            acl.add(new ElmACE("S_ADMIN ACCEPT"));
            defaultPolicy = ElmACE.DENY;
            locked = true;
            break;
        case FOX:
            acl.add(new ElmACE("S_ADMIN ACCEPT"));
            defaultPolicy = ElmACE.DENY;
            locked = true;
            break;
        case GNU:
            acl.add(new ElmACE("S_ADMIN ACCEPT"));
            defaultPolicy = ElmACE.DENY;
            locked = true;
            break;
        case HEN:
            acl.add(new ElmACE("S_ADMIN ACCEPT"));
            defaultPolicy = ElmACE.DENY;
            locked = true;
            break;
        case OWL:
            acl.add(new ElmACE("S_ADMIN ACCEPT"));
            defaultPolicy = ElmACE.DENY;
            locked = true;
            break;
        case PIG:
            acl.add(new ElmACE("S_ADMIN ACCEPT"));
            defaultPolicy = ElmACE.DENY;
            locked = true;
            break;
        case RAT:
            acl.add(new ElmACE("S_ADMIN ACCEPT"));
            defaultPolicy = ElmACE.DENY;
            locked = true;
            break;
        case YAK:
            defaultPolicy = ElmACE.DENY;
            locked = true;
            break;
        }
    }

    public void lock() {
        locked = true;
    }

    public void addPolicy(String s) {
        if (locked)
            return;
        acl.add(new ElmACE(s));
    }

    boolean check(Message m,Elm e) {
        Iterator i = acl.iterator();
        while (i.hasNext()) {
            ElmACE ace = (ElmACE)i.next();
            int c = ace.check(m,e);
            if (c == ElmACE.ACCEPT)
                return true;
            if (c == ElmACE.DENY)
                return false;
        }
        return (defaultPolicy==ElmACE.ACCEPT?true:false);
    }

    public void saveAsXML(Document d,Element e) {
        Element ee = W.makeElementDOM(d,"ACL");
        W.addChildDOM(e,ee);
        W.addAttrDOM(d,ee,"defaultPolicy",
                     (defaultPolicy==ElmACE.ACCEPT?"ACCEPT":"DENY"));
        W.addLineFeedDOM(d,ee);
        Iterator i = acl.iterator();
        while (i.hasNext()) {
            ElmACE ace = (ElmACE)i.next();
            Element eee = W.makeElementDOM(d,"ACE");
            W.addChildDOM(ee,eee);
            Text t = d.createTextNode(ace.stringExpression);
            W.addChildDOM(eee,t);
            W.addLineFeedDOM(d,ee);
        }
        W.addLineFeedDOM(d,e);
    }

    public void loadFromXML(Element e) {
        acl.clear();
        defaultPolicy
            = (W.getAttrDataDOM(e,"defaultPolicy").equals("ACCEPT")?
               ElmACE.ACCEPT:ElmACE.DENY);
        ArrayList al = W.getChildrenByTagNameDOM(e,"ACE");
        Iterator i = al.iterator();
        while (i.hasNext()) {
            Element ee = (Element)i.next();
            Text t = (Text)ee.getFirstChild();
            acl.add(new ElmACE(t.getData()));
        }
    }

    void setACLData(Serializable s[]) {
        defaultPolicy = ((Integer)s[0]).intValue();
        acl.clear();
//      acl.addAll((ArrayList<ElmACE>)s[1]); <-- 無検査キャスト
        ArrayList al = (ArrayList)s[1];
        for (Object o : al)
            acl.add((ElmACE)o);
    }

    Serializable[] getACLData() {
        Serializable ret[] = {defaultPolicy,(ArrayList)acl.clone()};
        return ret;
    }
    
}
