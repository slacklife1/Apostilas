package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;
import java.util.*;
import javax.media.j3d.*;
import javax.vecmath.*;
import java.awt.*;
import java.awt.event.*;

public class PickingBehavior extends Behavior {
    ElmCanvas3D canvas;
    View view;
    TransformGroup vptg;
    Transform3D vpt = new Transform3D();
    javax.media.j3d.Locale locale;
    ElmClient client;

    public PickingBehavior(ElmCanvas3D c,View v,TransformGroup tg,
                           javax.media.j3d.Locale l,ElmClient cc) {
        canvas = c;
        view = v;
        vptg = tg;
        locale = l;
        client = cc;
    }

    public void initialize() {
        WakeupOnAWTEvent w = new WakeupOnAWTEvent(MouseEvent.MOUSE_PRESSED);
        wakeupOn(w);
    }

    public void processStimulus(Enumeration criteria) {
        while (criteria.hasMoreElements()) {
            WakeupOnAWTEvent w = (WakeupOnAWTEvent)criteria.nextElement();
            AWTEvent e[] = w.getAWTEvent();
            for (int i=0;i<e.length;i++) {
                if (e[i].getID()==MouseEvent.MOUSE_PRESSED)
                    processMousePressed((MouseEvent)e[i]);
                else if (e[i].getID()==MouseEvent.MOUSE_DRAGGED)
                    processMouseDragged((MouseEvent)e[i]);
                else
                    processMouseReleased((MouseEvent)e[i]);
            }
        }
    }

    void processMouseClicked(ElmStub e) {
        try {
            if (e!=null)
                client.processCommand("openCustomizer "+e.getName());
        } catch(Exception ee) {
            ee.printStackTrace();
        }
        WakeupOnAWTEvent w = new WakeupOnAWTEvent(MouseEvent.MOUSE_PRESSED);
        wakeupOn(w);
    }

    int mouseX;
    int mouseY;
    long pressedTime;
    void processMousePressed(MouseEvent me) {
//        System.out.println("gaha:mousePressed");

        mouseX = me.getX();
        mouseY = me.getY();
        pressedTime = System.currentTimeMillis();

        ElmStub e = pickElm(me.getX(),me.getY());

        if (e!=null) {
            canvas.processMousePressed(e);
        }

        WakeupOnAWTEvent ws[] = new WakeupOnAWTEvent[2];
        ws[0] = new WakeupOnAWTEvent(MouseEvent.MOUSE_DRAGGED);
        ws[1] = new WakeupOnAWTEvent(MouseEvent.MOUSE_RELEASED);
        WakeupOr w = new WakeupOr(ws);
        wakeupOn(w);
    }

    void processMouseDragged(MouseEvent me) {
//        System.out.println("gaha:mouseDragged");

        WakeupOnAWTEvent ws[] = new WakeupOnAWTEvent[2];
        ws[0] = new WakeupOnAWTEvent(MouseEvent.MOUSE_DRAGGED);
        ws[1] = new WakeupOnAWTEvent(MouseEvent.MOUSE_RELEASED);
        WakeupOr w = new WakeupOr(ws);
        wakeupOn(w);
    }
    void processMouseReleased(MouseEvent me) {
//        System.out.println("gaha:mouseReleased");

        int xx = me.getX()-mouseX;
        int yy = me.getY()-mouseY;

        if (xx*xx+yy*yy < 18) {
            if (System.currentTimeMillis()-pressedTime < 500) {
                ElmStub e = pickElm(me.getX(),me.getY());
                pressedTime = 0;
                processMouseClicked(e);
                return;
            }
        }

        Point3d v1 = canvasToPhysicalCS(mouseX,mouseY);
        Point3d v2 = canvasToPhysicalCS(me.getX(),me.getY());
        v2.sub(v1);
        vptg.getTransform(vpt);

        if ((me.getModifiers() & MouseEvent.SHIFT_MASK)!=0)
            canvas.processMouseReleased(v2,vpt,v1.z,true);
        else
            canvas.processMouseReleased(v2,vpt,v1.z,false);

        WakeupOnAWTEvent w = new WakeupOnAWTEvent(MouseEvent.MOUSE_PRESSED);
        wakeupOn(w);
    }

    Point3d canvasToVirtualCS(int x,int y) {
        Point3d point = canvasToPhysicalCS(x,y);
        physicalCSToVirtualCS(point);
        return point;
    }

    Point3d canvasToPhysicalCS(int x,int y) {
        int dw = canvas.getWidth();
        int dh = canvas.getHeight();
        double ww = canvas.getPhysicalWidth();
        double tt = view.getFieldOfView();

        double dx =  ((double)x)*ww/((double)dw)-ww/2.0;
        double dy = -((double)y)*ww/((double)dw)
                    +(ww*((double)dh)/((double)dw)/2.0);
        double dz = -ww/2.0/Math.tan(tt/2.0);

        return new Point3d(dx,dy,dz);
    }

    Point3d physicalCSToVirtualCS(Point3d p) {
        vptg.getTransform(vpt);
        vpt.transform(p);
        return p;
    }
    Vector3d physicalCSToVirtualCS(Vector3d v) {
        vptg.getTransform(vpt);
        vpt.transform(v);
        return v;
    }

    ElmStub pickElm(int x,int y) {
        Vector3d v = new Vector3d(canvasToPhysicalCS(x,y));
        Point3d p = new Point3d(0.0,0.0,0.0);
        physicalCSToVirtualCS(v);
        physicalCSToVirtualCS(p);
        PickRay pr = new PickRay(p,v);
        SceneGraphPath sgp = locale.pickClosest(pr);

        if (sgp==null) {
            return null;
        }

        for (int i=0;i<sgp.nodeCount();i++) {
            Node n = sgp.getNode(i);
            if (n instanceof EBranchGroup) {
                EBranchGroup ebn = (EBranchGroup)n;
                return ebn.getElm();
            }
        }

        return null;
    }
}
