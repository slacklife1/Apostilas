package ac.hiu.j314.elmve;

import java.io.*;
import java.util.*;
import java.net.*;
import org.w3c.dom.*;

public class EcoElm extends Elm {
    private static final long serialVersionUID = 1L;
    boolean areChildrenSleeping = false;
    long standByTime = 1000*60*1;

    public void init() {
System.out.println("gaha:0");
        send(makeMyOrder("standBy",NULL));
    }

    public void standBy(MyOrder o) {
System.out.println("gaha:1");
        send(makeMyOrder("checkAvatars",NULL),standByTime);
    }

    public void checkAvatars(MyOrder o) {
System.out.println("gaha:2");
        ElmSet es = getElmsInside("@ElmAgent");
        es.addAll(getElmsInside("*/@ElmAgent"));
        es.addAll(getElmsInside("*/*/@ElmAgent"));
        es.addAll(getElmsInside("*/*/*/@ElmAgent"));
        es.addAll(getElmsInside("*/*/*/*/@ElmAgent"));
        if (es.size()!=0)
            send(makeMyOrder("checkAvatars",NULL),standByTime);
        else
            send(makeMyOrder("putChildrenToSleep",NULL));
    }

    public void putChildrenToSleep(MyOrder o) {
System.out.println("gaha:3");
        try {
System.out.println("gaha:"+stub.path);
            String fileName=ElmVE.elmVE.homeDir+"tmp";
            fileName = fileName
                +stub.path.substring(0,stub.path.lastIndexOf('/')+1);
            fileName = fileName.replace('#','n');
            fileName = fileName+stub.elmID;
            if (fileName.startsWith("file:"))
                fileName = fileName.substring(5);
System.out.println(fileName);
            File f = new File(fileName);
            f.getParentFile().mkdirs();
            saveTmp(fileName);
            cleanChildren();
            areChildrenSleeping = true;
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public void wakeChildrenUp(MyRequest r) {
        if (areChildrenSleeping==false) {
            send(makeReply(r,NULL));
            return;
        }
        wakeChildrenUp();
        send(makeMyOrder("checkAvatars",NULL),standByTime);
    }

    void wakeChildrenUp() {
System.out.println("gaha:4");
        try {
System.out.println("gaha:"+stub.path);
            String fileName=ElmVE.elmVE.homeDir+"tmp";
            fileName = fileName
                +stub.path.substring(0,stub.path.lastIndexOf('/')+1);
            fileName = fileName.replace('#','n');
            fileName = fileName+stub.elmID;
            if (fileName.startsWith("file:"))
                fileName = fileName.substring(5);
            loadTmp(fileName);
            areChildrenSleeping = false;
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    /**
      * saveTmp
      */
    void saveTmp(String fileName) {
        try {
            if (fileName.startsWith("file:"))
                fileName = fileName.substring(5);
            FileOutputStream os = new FileOutputStream(fileName);

            Document d = W.makeEmptyDocumentDOM();
            Element e = W.makeElementDOM(d,"elmTmp");
            W.addChildDOM(d,e);
            W.addLineFeedDOM(d,e);

            ArrayList<Elm> al = getAllDescendants(new ArrayList<Elm>());
            Iterator i = al.iterator();
            while (i.hasNext()) {
                Elm elm = (Elm)i.next();
                if (elm.stub.instanceOf("ac.hiu.j314.elmve.NeverSave"))
                    continue;
                Element ee = W.makeElementDOM(d,"elm");
                W.addChildDOM(e,ee);
                if (elm==this)
                    W.addAttrDOM(d,ee,"rootElm","true");
                elm.saveAsXML(d,ee);
                W.addLineFeedDOM(d,e);
            }

            W.saveDocumentToOutputStreamDOM(d,os);
        } catch(Exception e) {
	    e.printStackTrace();
        }
    }

    void recursiveInit2() {
        if (children!=null) {
            Iterator i = children.iterator();
            while (i.hasNext())
                ((Elm)i.next()).recursiveInit();
        }
    }

    void loadTmp(String fileName) throws IOException {
        URL url = W.getResource(fileName);
        InputStream is = url.openStream();

        Document d = W.loadDocumentFromInputStreamDOM(is);
        Element e = d.getDocumentElement();

        if (!e.getTagName().equals("elmTmp")) {
            System.out.println("EcoElm.loadTmp(). Wrong data.");
            return;
        }

        children = new ArrayList<Elm>(); // clear !!!

        LoadedElmSet elmSet = new LoadedElmSet();
        ArrayList al = W.getChildrenByTagNameDOM(e,"elm");
        Iterator i = al.iterator();
        while (i.hasNext())
            makeElmFromXMLTmp((Element)i.next(),elmSet);

        i = al.iterator();
        while (i.hasNext())
            loadBasicDataFromXMLTmp((Element)i.next(),elmSet);

        i = al.iterator();
        while (i.hasNext())
            loadExtensionExecTmp((Element)i.next(),elmSet);

        this.recursiveInit2();
    }

    ElmStub makeElmFromXMLTmp(Element e,LoadedElmSet elmSet) {
        Element ee = W.getChildByTagNameDOM(e,"basicData");
        Element eee = W.getChildByTagNameDOM(ee,"stub");
        String name = W.getDataDOM(eee,"name");
        String className = W.getDataDOM(eee,"className");
        String owner = W.getDataDOM(eee,"owner");
        long oldID = Long.parseLong(W.getDataDOM(eee,"elmID"));
        Elm elm = null;
        if (W.getAttrDataDOM(e,"rootElm").equals("true")) {
            elm = this;
            elm.stub.name = name;
            elm.stub.owner = owner;
            elm.stub.elmID=oldID;
            elmSet.addElm(elm.stub.elmID,elm.stub);
            if (ElmStub.idCounter <= oldID)
                ElmStub.idCounter = oldID+1;
            return elm.stub;
        } else {
            elm = ElmVE.elmVE.makeElm(className,name,owner).elm;
            elm.stub.elmID=oldID;
            elmSet.addElm(elm.stub.elmID,elm.stub);
            if (ElmStub.idCounter <= oldID)
                ElmStub.idCounter = oldID+1;
            return null;
        }
    }

    void loadBasicDataFromXMLTmp(Element e,LoadedElmSet elmSet) {
        Element basicData = W.getChildByTagNameDOM(e,"basicData");
        Element stubData = W.getChildByTagNameDOM(basicData,"stub");

        long elmID = Long.parseLong(W.getDataDOM(stubData,"elmID"));
        ElmStub es = elmSet.getElm(elmID);
        if (es == null) {
            System.out.println("EcoElm.loadBasicDataFromXMLTmp(). ???");
            return;
        }

        Element place = W.getChildByTagNameDOM(basicData,"place");
        Element rotation = W.getChildByTagNameDOM(basicData,"rotation");

        es.loadFromXML(stubData);

        double xyzw[] = new double[4];
        xyzw[0] = Double.parseDouble(W.getAttrDataDOM(place,"x"));
        xyzw[1] = Double.parseDouble(W.getAttrDataDOM(place,"y"));
        xyzw[2] = Double.parseDouble(W.getAttrDataDOM(place,"z"));
        es.elm.place.set(xyzw);

        xyzw[0] = Double.parseDouble(W.getAttrDataDOM(rotation,"x"));
        xyzw[1] = Double.parseDouble(W.getAttrDataDOM(rotation,"y"));
        xyzw[2] = Double.parseDouble(W.getAttrDataDOM(rotation,"z"));
        xyzw[3] = Double.parseDouble(W.getAttrDataDOM(rotation,"w"));
        es.elm.rotation.set(xyzw);

        Element children = W.getChildByTagNameDOM(e,"children");
        ArrayList al = W.getChildrenByTagNameDOM(children,"elmRef");
        Iterator i = al.iterator();
        while (i.hasNext()) {
            Element elmRef = (Element)i.next();
            elmID = Long.parseLong(W.getAttrDataDOM(elmRef,"elmID"));
            es.elm.addElm(elmSet.getElm(elmID));
        }
    }

    void loadExtensionExecTmp(Element e,LoadedElmSet elmSet) {
        Element basicData = W.getChildByTagNameDOM(e,"basicData");
        Element stubData = W.getChildByTagNameDOM(basicData,"stub");

        long elmID = Long.parseLong(W.getDataDOM(stubData,"elmID"));
        ElmStub es = elmSet.getElm(elmID);
        if (es==null) {
            System.out.println("TopElm.loadExtensionExecWorld(). ???");
            return;
        }

        Element ext = W.getChildByTagNameDOM(e,"extension");
        es.elm.loadExtension(ext,elmSet);
    }
}
