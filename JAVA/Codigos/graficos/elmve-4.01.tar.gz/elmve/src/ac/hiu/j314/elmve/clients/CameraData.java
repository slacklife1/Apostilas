package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;
import java.io.*;

public class CameraData implements Serializable {
    private static final long serialVersionUID = 1L;
    public static final int NEW = 1;
    public static final int MOVE = 2;
    public int type;
    public Place place = new Place();
    public Rotation rotation = new Rotation();

    public CameraData(int type) {
        this.type = type;
    }
}
