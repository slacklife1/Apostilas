package ac.hiu.j314.elmve.clients;

import java.io.*;
import java.util.*;

public class ElmLightPacket implements Serializable {
    private static final long serialVersionUID = 1L;
    public ElmLightData backGround;
    public ArrayList<ElmLightData> eachUI;
    public CameraData camera;
}
