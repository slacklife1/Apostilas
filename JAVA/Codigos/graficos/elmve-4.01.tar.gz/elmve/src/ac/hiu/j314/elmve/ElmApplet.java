package ac.hiu.j314.elmve;

import java.awt.event.*;
import javax.swing.*;

public class ElmApplet extends JApplet implements ActionListener {
    private static final long serialVersionUID = 1L;
    Box box;
    ElmVE elmVE;
    JButton startButton;
    JButton killButton;

    public void init() {
        box = Box.createVerticalBox();
        box.add(new JLabel("ElmApplet"));
        startButton = new JButton("Start");
        startButton.addActionListener(this);
        killButton = new JButton("Kill");
        killButton.addActionListener(this);
        box.add(startButton);
        box.add(killButton);
        getContentPane().add(box);
        try {
            ElmVE.classLoader
                = Class.forName("ac.hiu.j314.elmve.W").getClassLoader();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == startButton)
            startElmVE();
        else if (ae.getSource() == killButton)
            killElmVE();
    }

    void startElmVE() {
        try {
            elmVE = new ElmVE();
            ElmVE.elmVE = this.elmVE;
            elmVE.startAsApplet(this);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    void killElmVE() {
        elmVE.kill();
    }
}
