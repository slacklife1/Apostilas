package ac.hiu.j314.elmve.graph;

import ac.hiu.j314.elmve.*;
import java.awt.*;

public class SLine implements Line {
    private static final long serialVersionUID = 1L;
    protected Place headPlace;
    protected Place tailPlace;
    protected boolean directed;

    public SLine(Place h,Place t,boolean d) {
        headPlace = h;
        tailPlace = t;
        directed = d;
    }

    public Place getHeadPlace() {
        return headPlace;
    }

    public Place getTailPlace() {
        return tailPlace;
    }

    public void paint(Graphics g,Point h,Point t) {
        if (directed)
            drawArrow(g,t.x,t.y,h.x,h.y);
        else
            g.drawLine(t.x,t.y,h.x,h.y);
    }

    static int arcX[] = {0,20,20,0};
    static int arcY[] = {0,-5,5,0};

    void drawArrow(Graphics g,int xt,int yt,int xh,int yh) {
        double theta = Math.atan((double)(yh-yt)/(double)Math.abs(xh-xt));
        if (xh-xt>0)
            theta += Math.PI;
        else
            theta = - theta;
        double sin = Math.sin(theta);
        double cos = Math.cos(theta);
        Polygon arc = new Polygon();
        for (int i=0;i<4;i++)
            arc.addPoint((int)(cos*(double)arcX[i]-sin*(double)arcY[i]),
                         (int)(sin*(double)arcX[i]+cos*(double)arcY[i]));
        arc.translate((6*xh+xt)/7,(6*yh+yt)/7);
        g.fillPolygon(arc);
        g.drawLine(xt,yt,xh,yh);
    }
}
