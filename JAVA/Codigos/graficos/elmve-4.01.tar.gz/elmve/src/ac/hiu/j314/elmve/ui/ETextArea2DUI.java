package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.clients.*;
import javax.swing.*;
import java.awt.event.*;

public class ETextArea2DUI extends Elm2DUI implements ActionListener {
    private static final long serialVersionUID = 1L;
    protected JTextArea textArea;
    protected JButton doneButton;

    public void init(Elm2DData d) {
        setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));
        textArea = new JTextArea(d.getString(0));
        add(textArea);
        doneButton = new JButton("Done");
        add(doneButton);
        doneButton.addActionListener(this);
    }

    public void update(Elm2DData d) {
        textArea.setText(d.getString(0));
    }

    public void actionPerformed(ActionEvent ae) {
        send(makeOrder("catchETextAreaEvent",textArea.getText()));
    }
}
