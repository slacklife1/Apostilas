package ac.hiu.j314.elmve.graph;

import ac.hiu.j314.elmve.*;
import java.util.*;

public class Socket {
    protected String socketName;
    protected String className;
    protected int number;
    protected int direction;
    protected ArrayList<SS> links = new ArrayList<SS>();

    public Socket(String sName,String cName,int no,int d) {
        socketName = sName;
        className = cName;
        number = no;
        direction = d;
    }

    public SocketData getSocketData() {
        return new SocketData(socketName,className,number,links.size(),direction);
    }

    public void add(ElmStub l,ElmStub n,int d) {
        links.add(new SS(l,n,d));
    }
    public void del(ElmStub l,ElmStub n,int d) {
        Iterator i = links.iterator();
        while (i.hasNext()) {
            SS ss = (SS)i.next();
            if (ss.link.equals(l))
                links.remove(ss);
        }
    }

    public ElmSet getLinks() {
        ElmSet ret = new ElmSet();
        Iterator i = links.iterator();
        while (i.hasNext()) {
            SS ss = (SS)i.next();
            ret.add(ss.link);
        }
        return ret;
    }

    public ElmSet getOutLinks() {
        ElmSet ret = new ElmSet();
        Iterator i = links.iterator();
        while (i.hasNext()) {
            SS ss = (SS)i.next();
            if (ss.direction == Sockets.TAIL)
                ret.add(ss.link);
        }
        return ret;
    }

    public ElmSet getInLinks() {
        ElmSet ret = new ElmSet();
        Iterator i = links.iterator();
        while (i.hasNext()) {
            SS ss = (SS)i.next();
            if (ss.direction == Sockets.HEAD)
                ret.add(ss.link);
        }
        return ret;
    }

    public ElmSet getBothLinks() {
        ElmSet ret = new ElmSet();
        Iterator i = links.iterator();
        while (i.hasNext()) {
            SS ss = (SS)i.next();
            if (ss.direction == Sockets.BOTH)
                ret.add(ss.link);
        }
        return ret;
    }

    public ElmSet getLinkedNodes() {
        ElmSet ret = new ElmSet();
        Iterator i = links.iterator();
        while (i.hasNext()) {
            SS ss = (SS)i.next();
            ret.add(ss.node);
        }
        return ret;
    }

    public ElmSet getOutNodes() {
        ElmSet ret = new ElmSet();
        Iterator i = links.iterator();
        while (i.hasNext()) {
            SS ss = (SS)i.next();
            if (ss.direction==Sockets.TAIL)
                ret.add(ss.node);
        }
        return ret;
    }

    public ElmSet getInNodes() {
        ElmSet ret = new ElmSet();
        Iterator i = links.iterator();
        while (i.hasNext()) {
            SS ss = (SS)i.next();
            if (ss.direction==Sockets.HEAD)
                ret.add(ss.node);
        }
        return ret;
    }

    protected boolean delLinkByLink(ElmStub l) {
        SS ssTmp = null;
        Iterator i = links.iterator();
        while (i.hasNext()) {
            SS ss = (SS)i.next();
            if (ss.link.equals(l)) {
                ssTmp = ss;
                break;
            }
        }
        if (ssTmp!=null) {
            links.remove(ssTmp);
            return true;
        }
        return false;
    }

    void resetLink() {
        links.clear();
    }

    class SS {
        ElmStub link;
        ElmStub node;
        int direction;

        SS(ElmStub l,ElmStub n,int d) {
            link = l;
            node = n;
            direction = d;
        }
    }
}
