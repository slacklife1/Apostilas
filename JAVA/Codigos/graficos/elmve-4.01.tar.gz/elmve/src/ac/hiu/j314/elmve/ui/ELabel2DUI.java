package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.clients.*;
import javax.swing.*;

public class ELabel2DUI extends Elm2DUI {
    private static final long serialVersionUID = 1L;
    protected JLabel label;

    public void init(Elm2DData d) {
        label = new JLabel();
        add(label);
        label.setText(d.getString(0));
    }

    public void update(Elm2DData d) {
        label.setText(d.getString(0));
        repaint();
    }
}
