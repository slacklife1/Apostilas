package ac.hiu.j314.elmve;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;
import java.net.*;
import java.io.*;
import org.w3c.dom.*;

public class ElmLauncher implements ActionListener, ChangeListener {
    JFrame frame;
    Box baseBox;
    JButton okButton;
    JButton cancelButton;
    JCheckBox rmiregistryCB;
    JTextField serverNameTF;
    JComboBox clientClassCB;
    JButton clientRemoveButton;
    JCheckBox emptyCB;
    JTextField roomFileTF;
    JCheckBox bridgeCB;
    JTextField bridgeConfFileTF;
    JTextField bridgeOutIPTF;
    JTextField bridgeInIPTF;
    JButton autoButton;
    JPasswordField ksPasswordPF;

    String confFile;
    Document confDoc;

    protected void makeUI() {
        frame = new JFrame("ElmLauncher");
        baseBox = Box.createVerticalBox();
        frame.getContentPane().add(baseBox);

        Box box0 = Box.createHorizontalBox();
        rmiregistryCB = new JCheckBox("rmiregistry:");
        box0.add(rmiregistryCB);

        Box box1 = Box.createHorizontalBox();
        box1.add(new JLabel("Server Name:"));
        serverNameTF = new JTextField();
        box1.add(serverNameTF);

        Box box2 = Box.createHorizontalBox();
        box2.add(new JLabel("Client Class:"));
        clientClassCB = new JComboBox();
        clientClassCB.setEditable(true);
        box2.add(clientClassCB);
        clientRemoveButton = new JButton("rm");
        clientRemoveButton.addActionListener(this);
        box2.add(clientRemoveButton);

        Box box3 = Box.createHorizontalBox();
        emptyCB = new JCheckBox("Disable process of loading VE file:");
        box3.add(emptyCB);
        emptyCB.addChangeListener(this);

        Box box4 = Box.createHorizontalBox();
        box4.add(new JLabel("VE File:"));
        roomFileTF = new JTextField();
        box4.add(roomFileTF);

        Box box5 = Box.createVerticalBox();
        bridgeCB = new JCheckBox("Enable ElmBridge:");
        box5.add(bridgeCB);
        Box box5_1 = Box.createHorizontalBox();
        box5_1.add(new JLabel("conf:"));
        bridgeConfFileTF = new JTextField();
        box5_1.add(bridgeConfFileTF);
        Box box5_2 = Box.createHorizontalBox();
        box5_2.add(new JLabel("out:"));
        bridgeOutIPTF = new JTextField();
        box5_2.add(bridgeOutIPTF);
        autoButton = new JButton("auto");
        autoButton.addActionListener(this);
        box5_2.add(autoButton);
        Box box5_3 = Box.createHorizontalBox();
        box5_3.add(new JLabel("in:"));
        bridgeInIPTF = new JTextField();
        box5_3.add(bridgeInIPTF);
        box5.add(box5_1);
        box5.add(box5_2);
        box5.add(box5_3);

        Box box6 = Box.createHorizontalBox();
        box6.add(new JLabel("keystorePassword"));
        ksPasswordPF = new JPasswordField();
        box6.add(ksPasswordPF);

        Box box7 = Box.createHorizontalBox();
        okButton = new JButton("OK");
        okButton.addActionListener(this);
        box7.add(okButton);
        cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(this);
        box7.add(cancelButton);

        baseBox.add(box0);
        baseBox.add(box1);
        baseBox.add(box2);
        baseBox.add(box3);
        baseBox.add(box4);
        baseBox.add(box5);
        baseBox.add(box6);
        baseBox.add(box7);
    }

    void packAndShow() {
        frame.pack();
        Dimension d = frame.getSize();
        GraphicsConfiguration gc = frame.getGraphicsConfiguration();
        Rectangle b = gc.getBounds();
        frame.setLocation(b.x + b.width/2  - d.width/2,
                          b.y + b.height/2 - d.height/2);
        frame.setVisible(true);
        okButton.requestFocus();
    }

    boolean bbb(String s) {
        return (new Boolean(s)).booleanValue();
    }

    protected void loadConfiguration() {
        try {
            confFile = System.getProperty("user.home");
            confFile = confFile + W.sepa + ".elm" + W.sepa + "elmve.conf";
            URL url = W.getResource(confFile);
            InputStream is = url.openStream();
            confDoc = W.loadDocumentFromInputStreamDOM(is);
            Element e = confDoc.getDocumentElement();

            Element ee = W.getChildByTagNameDOM(e,"rmiregistry");
            String s = W.getAttrDataDOM(ee,"enable");
            rmiregistryCB.setSelected(bbb(s));

            s = W.getDataDOM(e,"serverName");
            serverNameTF.setText(s);

            ee = W.getChildByTagNameDOM(e,"clients");
            Element eee = null;
            ArrayList<String> tmpAl = new ArrayList<String>();
            String defaultClient = null;
            ArrayList al = W.getChildrenByTagNameDOM(ee,"client");
            Iterator i = al.iterator();
            while (i.hasNext()) {
                eee = (Element)i.next();
                String clientString = W.getDataDOM(eee);
                tmpAl.add(clientString);
                String defaultString = W.getAttrDataDOM(eee,"default");
                if (defaultString.equals("true")) {
                    defaultClient = clientString;
                }
            }
            String ss[] = (String[])tmpAl.toArray(new String[0]);
            clientClassCB.removeAllItems();
            for (int ii=0;ii<ss.length;ii++)
                clientClassCB.addItem(ss[ii]);
            clientClassCB.setSelectedItem(defaultClient);

            ee = W.getChildByTagNameDOM(e,"loadVE");
            s = W.getAttrDataDOM(ee,"enable");
            emptyCB.setSelected(bbb(s)==false);
            s = W.getAttrDataDOM(ee,"file");
            roomFileTF.setText(s);

            ee = W.getChildByTagNameDOM(e,"elmBridge");
            s = W.getAttrDataDOM(ee,"enable");
            bridgeCB.setSelected(bbb(s));
            s = W.getAttrDataDOM(ee,"confFile");
            bridgeConfFileTF.setText(s);

            ee = W.getChildByTagNameDOM(e,"outIPAddress");
            s = W.getDataDOM(ee);
            bridgeOutIPTF.setText(s);

//            ee = W.getChildByTagNameDOM(e,"inIPAddress");
//            s = W.getDataDOM(ee);
//            bridgeInIPTF.setText(s);
            bridgeInIPTF.setText(W.getIPAddress());
        } catch (Exception ee) {
//ee.printStackTrace(); //gaha
            makeDefaultConfiguration();
            saveConfiguration();
            System.out.println("A default config file was created.");
        }
        packAndShow();
    }

    protected void makeDefaultConfiguration() {
        rmiregistryCB.setSelected(true);
        serverNameTF.setText("ElmVE");
        clientClassCB.removeAllItems();
        clientClassCB.addItem("ac.hiu.j314.elmve.clients.Elm2DClient");
        clientClassCB.addItem("ac.hiu.j314.elmve.clients.Elm3DClient");
        clientClassCB.addItem("ac.hiu.j314.elmve.clients.ElmLightClient");
        clientClassCB.setSelectedItem("ac.hiu.j314.elmve.clients.ElmLightClient");
        emptyCB.setSelected(false);
        roomFileTF.setText("");
        bridgeCB.setSelected(false);
        bridgeConfFileTF.setText("x-res:///ac/hiu/j314/elmve/resources/bridge.conf");
        bridgeOutIPTF.setText("");
        bridgeInIPTF.setText(W.getIPAddress());
    }

    protected void saveConfiguration() {
        try {
            FileOutputStream fos = new FileOutputStream(confFile);
            confDoc = W.makeEmptyDocumentDOM();
            Element e = W.makeElementDOM(confDoc,"conf");
            W.addChildDOM(confDoc,e);
            W.addLineFeedDOM(confDoc,e);

            Element ee = W.makeElementDOM(confDoc,"rmiregistry");
            boolean b = rmiregistryCB.isSelected();
            W.addAttrDOM(confDoc,ee,"enable",(b?"true":"false"));
            W.addChildDOM(e,ee);
            W.addLineFeedDOM(confDoc,e);

            ee = W.addDataDOM(confDoc,e,"serverName",serverNameTF.getText());
            W.addChildDOM(e,ee);
            W.addLineFeedDOM(confDoc,e);

            ee = W.makeElementDOM(confDoc,"clients");
            W.addLineFeedDOM(confDoc,ee);
            String s = (String)clientClassCB.getSelectedItem();
            Element eee = null;
            boolean tmpFlag = false;
            for (int i=0;i<clientClassCB.getItemCount();i++) {
                String ss = (String)clientClassCB.getItemAt(i);
                if (ss.equals(""))
                    continue;
                eee = W.makeElementDOM(confDoc,"client");
                if (ss.equals(s)) {
                    W.addAttrDOM(confDoc,eee,"default","true");
                    tmpFlag = true;
                }
                W.addDataDOM(confDoc,eee,ss);
                W.addChildDOM(ee,eee);
                W.addLineFeedDOM(confDoc,ee);
            }
            if (tmpFlag==false) {
                if (!s.equals("")) {
                    eee = W.makeElementDOM(confDoc,"client");
                    W.addAttrDOM(confDoc,eee,"default","true");
                    W.addDataDOM(confDoc,eee,s);
                    W.addChildDOM(ee,eee);
                    W.addLineFeedDOM(confDoc,ee);
                }
            }
            W.addChildDOM(e,ee);
            W.addLineFeedDOM(confDoc,e);

            ee = W.makeElementDOM(confDoc,"loadVE");
            b = emptyCB.isSelected();
            W.addAttrDOM(confDoc,ee,"enable",(b?"false":"true"));
            W.addAttrDOM(confDoc,ee,"file",roomFileTF.getText());
            W.addChildDOM(e,ee);
            W.addLineFeedDOM(confDoc,e);

            ee = W.makeElementDOM(confDoc,"elmBridge");
            b = bridgeCB.isSelected();
            W.addAttrDOM(confDoc,ee,"enable",(b?"true":"false"));
            W.addAttrDOM(confDoc,ee,"confFile",bridgeConfFileTF.getText());
            W.addChildDOM(e,ee);
            W.addLineFeedDOM(confDoc,e);

            ee = W.addDataDOM(confDoc,e,"outIPAddress",bridgeOutIPTF.getText());
            W.addChildDOM(e,ee);
            W.addLineFeedDOM(confDoc,e);

//            ee = W.addDataDOM(confDoc,e,"inIPAddress",bridgeInIPTF.getText());
//            W.addLineFeedDOM(confDoc,ee);
//            W.addChildDOM(e,ee);

            W.saveDocumentToOutputStreamDOM(confDoc,fos);
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == okButton) {
            saveConfiguration();
            startElmRMIRegistry();
            startElmBridge();
            startElmVE();
        } else if (ae.getSource() == autoButton) {
            setOuterIP();
        } else if (ae.getSource() == cancelButton) {
            cancel();
        } else if (ae.getSource() == clientRemoveButton) {
            int i = clientClassCB.getSelectedIndex();
            if (i!=-1)
                clientClassCB.removeItemAt(i);
            else
                clientClassCB.setSelectedItem("");
        }
    }

    public void stateChanged(ChangeEvent ce) {
        if (emptyCB.isSelected())
            roomFileTF.setEditable(false);
        else
            roomFileTF.setEditable(true);
    }

    protected void startElmRMIRegistry() {
        if (!rmiregistryCB.isSelected())
            return;
        ElmRMIRegistry.main(null);
    }

    protected void startElmBridge() {
        if (!bridgeCB.isSelected())
            return;
        ArrayList<String> al = new ArrayList<String>();
        String bridgeConfFile = bridgeConfFileTF.getText();
        if (!bridgeConfFile.equals("")) {
            al.add("--conf");
            al.add(bridgeConfFile);
        }
        String outIP = bridgeOutIPTF.getText();
        if (!outIP.equals("")) {
            al.add("--outer");
            al.add(outIP);
        }
        String inIP = bridgeInIPTF.getText();
        if (!inIP.equals("")) {
            al.add("--inner");
            al.add(inIP);
        }
        String args[] = (String[])al.toArray(new String[0]);
        try {
            ElmBridge eb = new ElmBridge(args);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    protected void startElmVE() {
        ElmVE.main(makeArgs());
        frame.dispose();
    }

    protected String[] makeArgs() {
        ArrayList<String> al = new ArrayList<String>();
        al.add("--name");
        al.add(serverNameTF.getText());
        al.add("--client");
        al.add((String)clientClassCB.getSelectedItem());
        if (emptyCB.isSelected()) {
            al.add("--empty");
        } else {
            String rf = roomFileTF.getText();
            rf = rf.trim();
            if (!rf.equals("")) {
                al.add("--room");
                al.add(rf);
            }
        }
        String pw = new String(ksPasswordPF.getPassword());
        pw = pw.trim();
        if (!pw.equals("")) {
            al.add("--keystorepassword");
            al.add(pw);
        }
        
        return (String[])al.toArray(new String[0]);
    }

    protected void cancel() {
        System.exit(0);
    }

    protected void setOuterIP() {
        try {
            URL url = new URL("http://elm-ve.sf.net/ipCheck/ipCheck.cgi");
            InputStreamReader isr = new InputStreamReader(url.openStream());
            BufferedReader br = new BufferedReader(isr);
            String ip = br.readLine();
            ip=ip.trim();
            bridgeOutIPTF.setText(ip);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String args[]) {
        ElmLauncher launcher = new ElmLauncher();
        launcher.makeUI();
        launcher.loadConfiguration();
    }
}
