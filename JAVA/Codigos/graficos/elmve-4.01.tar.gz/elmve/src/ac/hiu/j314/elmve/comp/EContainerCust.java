package ac.hiu.j314.elmve.comp;

import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.clients.*;
import java.awt.event.*;
import javax.swing.*;

public class EContainerCust extends ElmCustomizer implements ActionListener {
    private static final long serialVersionUID = 1L;
    JFrame frame;
    JTextField widthTF;
    JTextField heightTF;
    JButton doneButton;

    public void startProcessing(MyOrder o) {
        super.startProcessing(o);

        frame = new JFrame("EContainerCust");
        Box box = Box.createVerticalBox();
        Box b1 = Box.createHorizontalBox();
        b1.add(new JLabel("X:"));
        widthTF = new JTextField(10);
        widthTF.addActionListener(this);
        b1.add(widthTF);
        box.add(b1);
        Box b2 = Box.createHorizontalBox();
        b2.add(new JLabel("Y:"));
        heightTF = new JTextField(10);
        heightTF.addActionListener(this);
        b2.add(heightTF);
        box.add(b2);
        frame.getContentPane().add(box);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                Double d = new Double(widthTF.getText());
                send(makeOrder(elm,"setContainerWidth",d));
                d = new Double(heightTF.getText());
                send(makeOrder(elm,"setContainerHeight",d));
                frame.dispose();
                dispose();
            }
        });
        frame.pack();
        frame.setVisible(true);

        Request r = makeRequest(elm,"getWH",NULL);
        receive(r,"setWH",NULL);
        send(r);
    }

    public void setWH(ReplySet rs) {
        widthTF.setText(""+rs.getDouble(0,0));
        heightTF.setText(""+rs.getDouble(0,1));
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == widthTF) {
            Double d = new Double(widthTF.getText());
            send(makeOrder(elm,"setContainerWidth",d));
        } else if (ae.getSource() == heightTF) {
            Double d = new Double(heightTF.getText());
            send(makeOrder(elm,"setContainerHeight",d));
        }
    }
}
