package ac.hiu.j314.elmve;

import java.io.*;
import java.net.*;
import java.rmi.server.*;
import java.security.KeyStore;
import javax.net.ssl.*;

class RMISSLServerSocketFactory implements RMIServerSocketFactory,
                                                  Serializable {
    private static final long serialVersionUID = 1L;
    String keyStoreFile = null;
    String keyStorePassword = null;
    public RMISSLServerSocketFactory(String ksf, String ksp) {
        keyStoreFile = ksf;
        keyStorePassword = ksp;
    }
    public ServerSocket createServerSocket(int port) throws IOException { 
        SSLServerSocketFactory ssf = null;
        try {
            SSLContext ctx;
            KeyManagerFactory kmf;
            KeyStore ks;
            char[] passphrase = keyStorePassword.toCharArray();

            ctx = SSLContext.getInstance("TLS");
            kmf = KeyManagerFactory.getInstance("SunX509");
            ks = KeyStore.getInstance("JKS");

            String ksFile = null;
            if (keyStoreFile.startsWith("file:"))
                ksFile = keyStoreFile.substring(5);
            else
                ksFile = keyStoreFile;
            ks.load(new FileInputStream(ksFile), passphrase);
            kmf.init(ks, passphrase);
            ctx.init(kmf.getKeyManagers(), null, null);

            ssf = ctx.getServerSocketFactory();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ssf.createServerSocket(port);
    }
}
