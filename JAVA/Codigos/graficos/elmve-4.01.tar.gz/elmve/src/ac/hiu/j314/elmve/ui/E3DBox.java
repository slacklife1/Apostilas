package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.clients.*;
import javax.media.j3d.*;

public class E3DBox extends Elm3DUI {
    public void init(Elm3DData data) {
    }

    public Node getSceneGraph() {
        return new com.sun.j3d.utils.geometry.ColorCube(0.12);
    }

    public void update(Elm3DData d) {
        ;
    }
}
