package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.image.codec.jpeg.*;
import java.io.*;
import java.util.*;

public class ElmCanvas3D extends Canvas3D {
    private static final long serialVersionUID = 1L;
    volatile boolean check = false;
    GraphicsContext3D gc;
    Raster readRaster;
    ElmClient client;

    protected VirtualUniverse universe;
    protected javax.media.j3d.Locale locale;
    protected javax.media.j3d.View view;
    protected BranchGroup rootGroup;
    protected TransformGroup tGroup;
    protected Transform3D transform;
    protected BranchGroup vpGroup;
    protected Elm3DBehavior cameraBehavior;
    protected ViewPlatform vp;

    protected Elm3DBG background;
    Hashtable<ElmStub,Elm3DUI> uiHash = new Hashtable<ElmStub,Elm3DUI>();

    public ElmCanvas3D(GraphicsConfiguration graCon,ElmClient c) {
        super(graCon);
        client = c;
        gc = getGraphicsContext3D();
    }

    public void postSwap() {
        super.postSwap();
        if (check) {
            gc.readRaster(readRaster);
            check = false;
        }
    }

    public void saveImage(File file) throws IOException {
        int width = getWidth();
        int height = getHeight();
        BufferedImage bImage = new BufferedImage(
                               width,height,BufferedImage.TYPE_INT_RGB);
        ImageComponent2D ic2d = new ImageComponent2D(
                                ImageComponent.FORMAT_RGB,bImage);
        DepthComponentFloat dcf = new DepthComponentFloat(width,height);
        readRaster = new Raster(new Point3f(0.0f,0.0f,0.0f),
                            Raster.RASTER_COLOR,0,0,width,height,
                            ic2d,null);
        check = true;
        while(check) {
            try{Thread.sleep(300);}catch(Exception e){;}
        }

        ImageComponent2D ic = readRaster.getImage();
        BufferedImage image = ic.getImage();

        FileOutputStream out = new FileOutputStream(file);
        JPEGImageEncoder e = JPEGCodec.createJPEGEncoder(out);
        e.encode(image);
        out.close();
    }

    protected void prepareVirtualUniverse() {
        universe = new VirtualUniverse();
        locale = new javax.media.j3d.Locale(universe);

        PhysicalBody body = new PhysicalBody();
        PhysicalEnvironment environment = new PhysicalEnvironment();

        view = new javax.media.j3d.View();
        view.addCanvas3D(this);
        view.setPhysicalBody(body);
        view.setPhysicalEnvironment(environment);
//        view.setFrontClipDistance(0.001);
        view.setBackClipDistance(1000.0);

        vpGroup = new BranchGroup();
        tGroup = new TransformGroup();
        tGroup.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
        tGroup.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
        vpGroup.addChild(tGroup);
        transform = new Transform3D();
        tGroup.setTransform(transform);
        cameraBehavior = new Elm3DBehavior();
        cameraBehavior.setTransform(tGroup,transform);
        BoundingSphere bs = new BoundingSphere(new Point3d(0.0,0.0,0.0),
                                               10.0);
        cameraBehavior.setSchedulingBounds(bs);
//        vpGroup.addChild(cameraBehavior);
        tGroup.addChild(cameraBehavior);
        vp = new ViewPlatform();
//System.out.println(vp.getActivationRadius());
        tGroup.addChild(vp);
        DirectionalLight dl = new DirectionalLight();
        dl.setInfluencingBounds(new BoundingSphere(new Point3d(0.0,0.0,0.0),100.0));
        tGroup.addChild(dl);

        view.attachViewPlatform(vp);

        vpGroup.setCapability(BranchGroup.ALLOW_DETACH);
        vpGroup.setCapability(BranchGroup.ALLOW_CHILDREN_WRITE);
        vpGroup.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
        vpGroup.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);

        PickingBehavior pb = new PickingBehavior(this,view,tGroup,locale,client);
        vpGroup.addChild(pb);
        BoundingSphere sb = new BoundingSphere(new Point3d(0.0,0.0,0.0),10.0);
        pb.setSchedulingBounds(sb);

        rootGroup = new BranchGroup();
        rootGroup.setCapability(BranchGroup.ALLOW_DETACH);
        rootGroup.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
        rootGroup.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
        rootGroup.setCapability(BranchGroup.ALLOW_CHILDREN_WRITE);

        locale.addBranchGraph(rootGroup);
    }

    void catch3DUIData(Elm3DPacket elm3DPacket) {
        if (elm3DPacket.backGround != null)
            if (elm3DPacket.backGround.type == Elm3DData.NEW)
                resetBackground(elm3DPacket.backGround);
            else if (elm3DPacket.backGround.type == Elm3DData.UPDATE)
                updateBackground(elm3DPacket.backGround);
        Iterator i = elm3DPacket.eachUI.iterator();
        while (i.hasNext()) {
            Elm3DData elm3DData = (Elm3DData)i.next();
            if (elm3DData == null)
                continue;
            else if (elm3DData.type == Elm3DData.NEW)
                addNewUI(elm3DData);
            else if (elm3DData.type == Elm3DData.OLD)
                delOldUI(elm3DData);
            else if (elm3DData.type == Elm3DData.UPDATE)
                updateUI(elm3DData);
        }
        if (elm3DPacket.camera != null)
            processCameraData(elm3DPacket.camera);

    }

    void resetBackground(Elm3DData elm3DData) {
        background = elm3DData.makeBG();
	while(rootGroup == null){try{Thread.sleep(1000);}catch(Exception e){;}}
        rootGroup.detach();
        rootGroup = new BranchGroup();
        rootGroup.addChild(background.getBranchGroup());
        rootGroup.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
        rootGroup.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
        rootGroup.setCapability(BranchGroup.ALLOW_CHILDREN_WRITE);
        rootGroup.setCapability(BranchGroup.ALLOW_DETACH);
        locale.addBranchGraph(rootGroup);
        uiHash.clear();
    }

    void updateBackground(Elm3DData elm3DData) {
        background.update(elm3DData);
    }

    void addNewUI(Elm3DData elm3DData) {
        Elm3DUI ui = elm3DData.makeUI();
        ui.setClient(client);
        rootGroup.addChild(ui.getBranchGroup());
        ui.move(elm3DData.place,elm3DData.rotation);
        uiHash.put(elm3DData.elm,ui);
    }

    void delOldUI(Elm3DData elm3DData) {
        Elm3DUI ui = (Elm3DUI)uiHash.get(elm3DData.elm);
        if (ui == null)
            return;
        ui.detach();
        uiHash.remove(elm3DData.elm);
    }

    void updateUI(Elm3DData elm3DData) {
        Elm3DUI ui = (Elm3DUI)uiHash.get(elm3DData.elm);
        if (ui == null) {
            System.out.println("Elm3DClient.updateUI().");
            System.out.println("null"+elm3DData.elm.getName());
        } else {
            ui.move(elm3DData.place,elm3DData.rotation);
            ui.update(elm3DData);
        }
    }

    void processCameraData(CameraData camera) {
        if (camera.type == CameraData.NEW) {
            vpGroup.detach();
            rootGroup.addChild(vpGroup);
            cameraBehavior.move(camera.place,camera.rotation);
        } else if (camera.type == CameraData.MOVE) {
            cameraBehavior.move(camera.place,camera.rotation);
        }
    }

    ElmStub pressedElm = null;
    Place pressedElmPlace = null;
    void processMousePressed(ElmStub e) {
        if (pressedElm!=null)
            return;
        pressedElm = e;
        Elm3DUI ui = (Elm3DUI)uiHash.get(e);
        if (ui == null)
            return;
        pressedElmPlace = ui.getPlace();
    }

    void processMouseReleased(Point3d vec,Transform3D vpt,double z,boolean b) {
        if ((pressedElm==null)||(pressedElmPlace==null))
            return;
        Place epp = pressedElmPlace;
        double d[] = new double[3];

        epp.get(d);
        Point3d ev = new Point3d(d[0],d[1],d[2]);
        Transform3D vptInverse = new Transform3D();
        vpt.invert();
        vpt.transform(ev);

        double k = ev.z/z;
        vec.scale(k);
        if (b) {
            double dTmp = vec.y;
            vec.y = vec.z;
            vec.z = dTmp;
        }
        ev.x = ev.x + vec.x;
        ev.y = ev.y + vec.y;
        ev.z = ev.z + vec.z;

        vpt.invert();
        vpt.transform(ev);

//        send(makeOrder(pressedElm,"setPlace",new Place(ev.x,ev.y,ev.z)));
        try {
            client.processCommand("locate "+pressedElm.getName()+" "
                                  +ev.x+" "+ev.y+" "+ev.z);
        } catch(Exception e) {
            e.printStackTrace();
        }
        pressedElm = null;
        pressedElmPlace = null;
    }

    public Dimension getPreferredSize() {
        return new Dimension(500,500);
    }
}
