package ac.hiu.j314.elmve;

import java.io.*;
import java.util.*;

public class LoadedElmSet {
    ArrayList<Serializable[]> elmSet;

    LoadedElmSet() {
        elmSet = new ArrayList<Serializable[]>();
    }

    void addElm(long elmID,ElmStub elm) {
        Serializable s[] = {new Long(elmID),elm};
        elmSet.add(s);
    }

    public ElmStub getElm(long l) {
        Iterator i = elmSet.iterator();
        while (i.hasNext()) {
            Serializable s[] = (Serializable[])i.next();
            if (((Long)s[0]).longValue()==l) {
                return (ElmStub)s[1];
            }
        }
        return null;
    }
}
