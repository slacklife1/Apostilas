package ac.hiu.j314.elmve.clients;

import java.io.*;
import java.util.*;

public class Elm2DPacket implements Serializable {
    private static final long serialVersionUID = 1L;
    public Elm2DData backGround;
    public ArrayList<Elm2DData> eachUI;
    public CameraData camera;
}
