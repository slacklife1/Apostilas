package ac.hiu.j314.elmve;

import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
import java.util.*;
import java.io.*;
import java.net.*;
import org.w3c.dom.*;

public class ElmBridge extends UnicastRemoteObject implements RemoteElmBridge {
    private static final long serialVersionUID = 1L;
    static ElmBridge elmBridge = null;

    Registry registry;
    byte outerAddress[] = new byte[4];
    byte innerAddress[] = new byte[4];
    String outerAddressString;
    String innerAddressString;
    String confFile;
    ElmACL bridgeACL = new ElmACL();
    String keyStorePassword = "";
    String keyStoreFile = "";

    public ElmBridge(String args[]) throws RemoteException {
        super();

        parseArgs(args);

        initParams();

        loadACL();

        bind();
    }

    void parseArgs(String args[]) {
        for (int i=0;i<args.length;i++) {
            if (args[i].equals("--help")
                || args[i].equals("-h")) {
System.out.println("USAGE: java ac.hiu.j314.elmve.ElmBridge [option ...]");
System.out.println("Options");
System.out.println("  [ --help | -h]");
System.out.println("    print this message.");
System.out.println("  [ --conf | -c] filename");
System.out.println("    specify the config file.");
System.out.println("  [ --inner | -i] xxx.xxx.xxx.xxx");
System.out.println("    specify inner IP address.");
System.out.println("  [ --outer | -o] xxx.xxx.xxx.xxx");
System.out.println("    specify outer IP address.");
System.out.println("  [ --keystorepassword ]");
System.out.println("    specify keystore password.");
System.out.println("  [ --keystorefile ]");
System.out.println("    specify keystore file.");
                System.exit(0);
            } else if (args[i].equals("--conf")
                       || args[i].equals("-c")) {
                confFile = args[i+1];
                i++;
            } else if (args[i].equals("--inner")
                       || args[i].equals("-i")) {
                innerAddressString = args[i+1];
                i++;
            } else if (args[i].equals("--outer")
                       || args[i].equals("-o")) {
                outerAddressString = args[i+1];
                i++;
            } else if (args[i].equals("--keystorepassword")) {
                keyStorePassword = args[i+1];
                i++;
            } else if (args[i].equals("--keystorefile")) {
                keyStoreFile = args[i+1];
                i++;
            }
        }
    }

    void initParams() {
        StringTokenizer st = new StringTokenizer(innerAddressString,".");
        innerAddress[0]=(byte)Integer.parseInt(st.nextToken());
        innerAddress[1]=(byte)Integer.parseInt(st.nextToken());
        innerAddress[2]=(byte)Integer.parseInt(st.nextToken());
        innerAddress[3]=(byte)Integer.parseInt(st.nextToken());
 
        
        st = new StringTokenizer(outerAddressString,".");
        outerAddress[0]=(byte)Integer.parseInt(st.nextToken());
        outerAddress[1]=(byte)Integer.parseInt(st.nextToken());
        outerAddress[2]=(byte)Integer.parseInt(st.nextToken());
        outerAddress[3]=(byte)Integer.parseInt(st.nextToken());

        File f = null;
        if (keyStoreFile.startsWith("file:"))
            f = new File(keyStoreFile.substring(5));
        else
            f = new File(keyStoreFile);

        System.setProperty("java.rmi.server.hostname",outerAddressString);
        try {
            if (f.isFile()) {
                System.setProperty("javax.net.ssl.trustStore",
                                   f.getAbsolutePath());
                UnicastRemoteObject.unexportObject(this,true);
                RMISSLClientSocketFactory c = new RMISSLClientSocketFactory();
                RMISSLServerSocketFactory s =
                    new RMISSLServerSocketFactory(keyStoreFile,keyStorePassword);
                UnicastRemoteObject.exportObject(this,1100,c,s);
            } else {
                UnicastRemoteObject.unexportObject(this,true);
                UnicastRemoteObject.exportObject(this,1100);
            }
        } catch(Exception e) {
            e.printStackTrace();
            System.exit(0);
        }
    }

    void loadACL() {
        try {
            URL url = W.getResource(confFile);
            Document d = W.loadDocumentFromInputStreamDOM(url.openStream());
            Element e = d.getDocumentElement();

            if (!e.getTagName().equals("bridgeACL")) {
                System.out.println("Wrong config file.");
                System.exit(0);
            }

            Element ee = W.getChildByTagNameDOM(e,"ACL");
            bridgeACL.loadFromXML(ee);
        } catch(Exception e) {
//ioe.printStackTrace();
            System.out.println("Can not load config file.");
            System.exit(0);
        }
    }

    void bind() {
        try {
System.out.println(outerAddressString);
            String names[] = Naming.list("//localhost/");
            for (int i=0;i<names.length;i++) {
System.out.println(names[i]);
                if (names[i].endsWith("/ElmBridge")) {
                    System.err.println("ElmBridge has already run");
                    System.exit(1);
                }
            }
//            Naming.rebind("//"+innerAddressString+"/ElmBridge",this);
//gaha;
            Naming.rebind("//localhost/ElmBridge",this);
System.out.println("ElmBridge:bind!");
        } catch (Exception e) {
System.out.println("ElmBridge.bind() Cannot bind.(?)");
//            e.printStackTrace();
        }
    }

    public boolean receiveMessage(Message m) throws RemoteException {
System.out.println("receiveMessage");
//System.out.println(m.sender.toString());
//System.out.println(m.receiver.toString());
//System.out.println(m.methodName);
        if (!bridgeACL.check(m,null))
            return false;
        try {
            if (m.receiver.server.bridge == null) {
                int i0=m.receiver.server.address[0];i0=i0<0?i0+256:i0;
                int i1=m.receiver.server.address[1];i1=i1<0?i1+256:i1;
                int i2=m.receiver.server.address[2];i2=i2<0?i2+256:i2;
                int i3=m.receiver.server.address[3];i3=i3<0?i3+256:i3;
                String noBridgeElmPath =
                    "//"+i0+"."+i1+"."+i2+"."+i3+
                    "/"+m.receiver.server.serverName;
                RemoteElmVE remoteVE =
                    (RemoteElmVE)Naming.lookup(noBridgeElmPath);
                if (remoteVE.receiveMessage(m)) {
                    return true;
                } else {
                    return false;
                }
            }
            if ((m.receiver.server.bridge[0]==outerAddress[0])&&
                (m.receiver.server.bridge[1]==outerAddress[1])&&
                (m.receiver.server.bridge[2]==outerAddress[2])&&
                (m.receiver.server.bridge[3]==outerAddress[3])) {
                int i0=m.receiver.server.address[0];i0=i0<0?i0+256:i0;
                int i1=m.receiver.server.address[1];i1=i1<0?i1+256:i1;
                int i2=m.receiver.server.address[2];i2=i2<0?i2+256:i2;
                int i3=m.receiver.server.address[3];i3=i3<0?i3+256:i3;
                String noBridgeElmPath =
                    "//"+i0+"."+i1+"."+i2+"."+i3+
                    "/"+m.receiver.server.serverName;
                RemoteElmVE remoteVE =
                    (RemoteElmVE)Naming.lookup(noBridgeElmPath);
                return remoteVE.receiveMessage(m);
            }
            int i0=m.receiver.server.bridge[0];i0=i0<0?i0+256:i0;
            int i1=m.receiver.server.bridge[1];i1=i1<0?i1+256:i1;
            int i2=m.receiver.server.bridge[2];i2=i2<0?i2+256:i2;
            int i3=m.receiver.server.bridge[3];i3=i3<0?i3+256:i3;
            String remoteBridgePath =
                "//"+i0+"."+i1+"."+i2+"."+i3+"/ElmBridge";
            RemoteElmBridge remoteBridge =
                (RemoteElmBridge)Naming.lookup(remoteBridgePath);
            return remoteBridge.receiveMessage(m);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public ElmSet getElms(String uri) throws RemoteException {
System.out.println("getElms");
System.out.println(uri);
        try {
            StringTokenizer st = new StringTokenizer(uri,"/");
            String h = st.nextToken();
            if (h.indexOf(';')==-1) {
                String path = W.getLocalPath(uri);
                String elmVEPath = W.getElmVEPath(uri);
                RemoteElmVE remoteVE =
                    (RemoteElmVE)Naming.lookup(elmVEPath);
                return remoteVE.getElms(path);
            }

            StringTokenizer st2 = new StringTokenizer(h,";");
            String hh = st2.nextToken();
            String noBridgeElmPath="//"+uri.substring(uri.indexOf(';')+1);
            if (hh.equals(outerAddressString)) {
                String path = W.getLocalPath(noBridgeElmPath);
                String elmVEPath = W.getElmVEPath(noBridgeElmPath);
                RemoteElmVE remoteVE =
                    (RemoteElmVE)Naming.lookup(elmVEPath);
                ElmSet elms = remoteVE.getElms(path);
                if (elms != null) {
                    Iterator i = elms.iterator();
                    while (i.hasNext()) {
                        ElmStub es = (ElmStub)i.next();
                        es.server.bridge = outerAddress;
                    }
                }
                return elms;
            }

System.out.println("**gaha1**");
            String remoteBridgePath="//"+hh+"/ElmBridge";
System.out.println("**gaha2**"+remoteBridgePath);
            RemoteElmBridge remoteBridge =
                (RemoteElmBridge)Naming.lookup(remoteBridgePath);
System.out.println("**gaha3**");
            ElmSet es = remoteBridge.getElms(noBridgeElmPath);
System.out.println("**gaha4**"+es.size());
            return es;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public byte[] loadClassData(String elmve,String name)
    throws RemoteException {
System.out.println("loadClassData");
System.out.println(elmve);
System.out.println(name);
        try {
            if (elmve.indexOf(';')==-1) {
                RemoteElmVE remoteVE =
                    (RemoteElmVE)Naming.lookup(elmve);
                return remoteVE.loadClassData(name);
            } else {
                String h1 = elmve.substring(2,elmve.indexOf(';'));
                String h2 = elmve.substring(elmve.indexOf(';'));
                if (h1.equals(outerAddressString)) {
                    RemoteElmVE remoteVE =
                        (RemoteElmVE)Naming.lookup("//"+h2);
                    return remoteVE.loadClassData(name);
                } else {
                    RemoteElmBridge remoteBridge =
                        (RemoteElmBridge)Naming.lookup("//"+h1+"/ElmBridge");
                    return remoteBridge.loadClassData(elmve,name);
                }
            }
        } catch(Exception e) {
            return null;
        }
    }
    public byte[] elmFindResource(String elmve,String name)
    throws RemoteException {
System.out.println("elmFindResource");
System.out.println(elmve);
System.out.println(name);
        try {
            if (elmve.indexOf(';')==-1) {
                RemoteElmVE remoteVE =
                    (RemoteElmVE)Naming.lookup(elmve);
                return remoteVE.elmFindResource(name);
            } else {
                String h1 = elmve.substring(2,elmve.indexOf(';'));
                String h2 = elmve.substring(elmve.indexOf(';'));
                if (h1.equals(outerAddressString)) {
                    RemoteElmVE remoteVE =
                        (RemoteElmVE)Naming.lookup("//"+h2);
                    return remoteVE.elmFindResource(name);
                } else {
                    RemoteElmBridge remoteBridge =
                        (RemoteElmBridge)Naming.lookup("//"+h1+"/ElmBridge");
                    return remoteBridge.elmFindResource(elmve,name);
                }
            }
        } catch(Exception e) {
            return null;
        }
    }

    public String getBridgeData() throws RemoteException {
System.out.println("getBridgeData");
        return outerAddressString;
    }

    public void stopBridge() throws RemoteException {
        Thread t = new Thread() {
            public void run() {
                try{Thread.sleep(1000);}catch(Exception e) {}
                System.out.println("ElmBridge.stopBridge() stoped.");
                System.exit(0);
            }
        };
        t.start();
    }

    public static void main(String args[]) throws RemoteException {
         elmBridge = new ElmBridge(args);
    }
}
