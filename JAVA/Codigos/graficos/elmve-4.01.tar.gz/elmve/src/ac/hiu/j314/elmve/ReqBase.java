package ac.hiu.j314.elmve;

import java.io.*;

public class ReqBase extends Message {
    private static final long serialVersionUID = 1L;

    /** (arg:fuku) */
    ReqBase(ElmStub sender,ElmStub receiver,
            String methodName,Serializable arguments[]) {
        super(sender,receiver,methodName,arguments);
    }
}
