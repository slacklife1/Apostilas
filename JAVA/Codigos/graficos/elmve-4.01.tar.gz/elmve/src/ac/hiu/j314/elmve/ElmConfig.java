package ac.hiu.j314.elmve;

import java.util.*;
import java.io.*;
import java.net.*;
import org.w3c.dom.*;
import java.rmi.*;
import ac.hiu.j314.a23.A23;

class ElmConfig {
    ArrayList<ElmUser> accounts = new ArrayList<ElmUser>();
    ElmACL importACL = new ElmACL();
    ElmACL exportACL = new ElmACL();
    ElmVE elmVE;
    String elmBridge = "none";
    ArrayList<String> pubSpaces = new ArrayList<String>();
    String proxySet;
    String proxyHost;
    String proxyPort;
    String ftpProxySet;
    String ftpProxyHost;
    String ftpProxyPort;

    boolean saveAsXML(String fileName) {
        try {
            if (fileName.startsWith("file:"))
                fileName = fileName.substring(5);
            FileOutputStream fos = new FileOutputStream(fileName);
            Document d = W.makeEmptyDocumentDOM();
            Element e = W.makeElementDOM(d,"elmConfig");
            W.addChildDOM(d,e);
            W.addLineFeedDOM(d,e);

            Element ee = W.makeElementDOM(d,"accounts");
            W.addChildDOM(e,ee);
            W.addLineFeedDOM(d,ee);
            Element eee = W.makeElementDOM(d,"admin");
            W.addChildDOM(ee,eee);
            W.addLineFeedDOM(d,eee);
            ElmVE.elmVE.admin.saveAsXML(d,eee);
            W.addLineFeedDOM(d,ee);

            Iterator i = accounts.iterator();
            while (i.hasNext()) {
                ElmUser eu = (ElmUser)i.next();
                eee = W.makeElementDOM(d,"user");
                W.addChildDOM(ee,eee);
                W.addLineFeedDOM(d,eee);
                eu.saveAsXML(d,eee);
                W.addLineFeedDOM(d,ee);
            }
            W.addLineFeedDOM(d,e);

            ee = W.makeElementDOM(d,"pubSpaces");
            W.addChildDOM(e,ee);
            W.addLineFeedDOM(d,ee);
            i = pubSpaces.iterator();
            while (i.hasNext()) {
                String s = (String)i.next();
                W.addDataDOM(d,ee,"path",s);
                W.addLineFeedDOM(d,ee);
            }
            W.addLineFeedDOM(d,e);

            ee = W.makeElementDOM(d,"elmPath");
            W.addChildDOM(e,ee);
            W.addLineFeedDOM(d,ee);
            if (ElmVE.classLoader instanceof ElmClassLoader)
                ((ElmClassLoader)ElmVE.classLoader).saveAsXML(d,ee);
            W.addLineFeedDOM(d,e);

            ee = W.makeElementDOM(d,"importACL");
            W.addChildDOM(e,ee);
            W.addLineFeedDOM(d,ee);
            importACL.saveAsXML(d,ee);
            W.addLineFeedDOM(d,e);

            ee = W.makeElementDOM(d,"exportACL");
            W.addChildDOM(e,ee);
            W.addLineFeedDOM(d,ee);
            exportACL.saveAsXML(d,ee);
            W.addLineFeedDOM(d,e);

            W.addDataDOM(d,e,"elmBridge",elmBridge);
            W.addLineFeedDOM(d,e);

            ee = W.makeElementDOM(d,"proxy");
            W.addChildDOM(e,ee);
            W.addLineFeedDOM(d,ee);
            W.addDataDOM(d,ee,"proxySet",proxySet);
            W.addLineFeedDOM(d,ee);
            W.addDataDOM(d,ee,"proxyHost",proxyHost);
            W.addLineFeedDOM(d,ee);
            W.addDataDOM(d,ee,"proxyPort",proxyPort);
            W.addLineFeedDOM(d,ee);
            W.addDataDOM(d,ee,"ftpProxySet",ftpProxySet);
            W.addLineFeedDOM(d,ee);
            W.addDataDOM(d,ee,"ftpProxyHost",ftpProxyHost);
            W.addLineFeedDOM(d,ee);
            W.addDataDOM(d,ee,"ftpProxyPort",ftpProxyPort);
            W.addLineFeedDOM(d,ee);

            W.saveDocumentToOutputStreamDOM(d,fos);

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    void loadFromXML(String fileName) {
        try {
            URL url = W.getResource(fileName);
            InputStream is = url.openStream();
            Document d = W.loadDocumentFromInputStreamDOM(is);
            Element e = d.getDocumentElement();

            accounts.clear();
            Element ee = W.getChildByTagNameDOM(e,"accounts");
            Element eee = W.getChildByTagNameDOM(ee,"admin");
            ElmUser eu = new ElmUser();
            eu.loadFromXML(eee);
            ElmVE.elmVE.admin = eu;
            ArrayList al = W.getChildrenByTagNameDOM(ee,"user");
            Iterator i = al.iterator();
            while (i.hasNext()) {
                eee = (Element)i.next();
                eu = new ElmUser();
                eu.loadFromXML(eee);
                accounts.add(eu);
            }

            pubSpaces.clear();
            ee = W.getChildByTagNameDOM(e,"pubSpaces");
            al = W.getChildrenByTagNameDOM(ee,"path");
            i = al.iterator();
            while (i.hasNext()) {
                eee = (Element)i.next();
                Text t = (Text)eee.getFirstChild();
                pubSpaces.add(t.getData());
            }

            ee = W.getChildByTagNameDOM(e,"elmPath");
            if (ElmVE.classLoader instanceof ElmClassLoader)
                ((ElmClassLoader)ElmVE.classLoader).loadFromXML(ee);

            ee = W.getChildByTagNameDOM(e,"importACL");
            eee = W.getChildByTagNameDOM(ee,"ACL");
            importACL.loadFromXML(eee);

            ee = W.getChildByTagNameDOM(e,"exportACL");
            eee = W.getChildByTagNameDOM(ee,"ACL");
            exportACL.loadFromXML(eee);

            elmBridge = W.getDataDOM(e,"elmBridge");
            if (!elmBridge.equals("none"))
                enableBridge();

            if (ElmVE.elmVE.applet == null) {
                ee = W.getChildByTagNameDOM(e,"proxy");
                proxySet = W.getDataDOM(ee,"proxySet");
                proxyHost = W.getDataDOM(ee,"proxyHost");
                proxyPort = W.getDataDOM(ee,"proxyPort");
                if (proxySet.equals("true")) {
                    System.getProperties().put("proxySet","true");
                    System.getProperties().put("proxyHost",proxyHost);
                    System.getProperties().put("proxyPort",proxyPort);
                } else {
                    System.getProperties().put("proxySet","false");
                }
                ftpProxySet = W.getDataDOM(ee,"ftpProxySet");
                ftpProxyHost = W.getDataDOM(ee,"ftpProxyHost");
                ftpProxyPort = W.getDataDOM(ee,"ftpProxyPort");
                if (ftpProxySet.equals("true")) {
                    System.getProperties().put("ftpProxySet","true");
                    System.getProperties().put("ftpProxyHost",ftpProxyHost);
                    System.getProperties().put("ftpProxyPort",ftpProxyPort);
                } else {
                    System.getProperties().put("ftpProxySet","false");
                }
            }
        } catch (Exception ee) {
//ee.printStackTrace(); //gaha
            makeDefaultConfiguration();
            saveAsXML(fileName);
            System.out.println("A default config file was created.");
        }
    }

    void makeDefaultConfiguration() {
        ElmVE.elmVE.admin = new ElmUser("admin","admin@elm-ve.sf.net",
                                        "adminPassword","admin",
                                        "ac.hiu.j314.elmve.ElmAvatar","/");
        accounts.clear();
        accounts.add(new ElmUser("guest","guest@elm-ve.sf.net",
                                 "guest","guest","default","/"));
        importACL = new ElmACL(false);
        exportACL = new ElmACL(false);
        elmBridge = "none";
        pubSpaces.clear();
        pubSpaces.add("/sys/transporter");
        proxySet = "false";
        proxyHost = "none";
        proxyPort = "none";
        ftpProxySet = "false";
        ftpProxyHost = "none";
        ftpProxyPort = "none";
    }

    ArrayList getElmClassPath() {
        return ((ElmClassLoader)ElmVE.classLoader).getElmClassPath();
    }

    void setElmClassPath(ArrayList<String> al) {
        ((ElmClassLoader)ElmVE.classLoader).setElmClassPath(al);
    }

    void setAdmin(ElmUser admin) {
        ElmVE.elmVE.admin = admin;
    }

    ElmUser getAdmin() {
        return ElmVE.elmVE.admin;
    }

    void setAccountsData(ArrayList<ElmUser> al) {
        accounts.clear();
        accounts.addAll(al);
    }

    ArrayList getAccountsData() {
        return (ArrayList)accounts.clone();
    }

    void setInACLData(Serializable s[]) {
        importACL.setACLData(s);
    }

    void setOutACLData(Serializable s[]) {
        exportACL.setACLData(s);
    }

    Serializable[] getInACLData() {
        return importACL.getACLData();
    }

    Serializable[] getOutACLData() {
        return exportACL.getACLData();
    }

    void setBridgeData(String b) {
        elmBridge = b;
        if (elmBridge.equals("none"))
            disableBridge();
        else
            enableBridge();
    }

    String getBridgeData() {
        return elmBridge;
    }

    void setProxyData(String p[]) {
        proxySet = p[0];
        proxyHost = p[1];
        proxyPort = p[2];
        ftpProxySet = p[3];
        ftpProxyHost = p[4];
        ftpProxyPort = p[5];
        if (proxySet.equals("true")) {
            System.getProperties().put("proxySet","true");
            System.getProperties().put("proxyHost",proxyHost);
            System.getProperties().put("proxyPort",proxyPort);
        } else {
            System.getProperties().put("proxySet","false");
        }
        if (ftpProxySet.equals("true")) {
            System.getProperties().put("ftpProxySet","true");
            System.getProperties().put("ftpProxyHost",ftpProxyHost);
            System.getProperties().put("ftpProxyPort",ftpProxyPort);
        } else {
            System.getProperties().put("ftpProxySet","false");
        }
    }

    String[] getProxyData() {
        String p[] = new String[6];
        p[0]=proxySet;
        p[1]=proxyHost;
        p[2]=proxyPort;
        p[3]=ftpProxySet;
        p[4]=ftpProxyHost;
        p[5]=ftpProxyPort;
        return p;
    }

    boolean checkLogin(String name,String password) {
        if (ElmVE.elmVE.admin.name.equals(name))
            if (ElmVE.elmVE.admin.password.equals(password))
                return true;
        Iterator i = accounts.iterator();
        while (i.hasNext()) {
            ElmUser eu = (ElmUser)i.next();
            if (eu.name.equals(name))
                if (eu.password.equals(password))
                    return true;
                else
                    return false;
        }
        return false;
    }

    ElmUser getUser(String name) {
        if (name.equals("admin"))
            return ElmVE.elmVE.admin;
        Iterator i = accounts.iterator();
        while (i.hasNext()) {
            ElmUser eu = (ElmUser)i.next();
            if (eu.name.equals(name))
                return eu;
        }
        return null;
    }

    ArrayList getPubSpacesData() {
        return (ArrayList)pubSpaces.clone();
    }

    void setPubSpacesData(ArrayList<String> al) {
        pubSpaces.clear();
        pubSpaces.addAll(al);
    }

    ArrayList getPubClassData() {
        return ((ElmClassLoader)ElmVE.classLoader).getExportElmClassPath();
    }

    void setPubClassData(ArrayList<String> al) {
        ((ElmClassLoader)ElmVE.classLoader).setExportElmClassPath(al);
    }

    boolean checkImportACL(Message m) {
        return importACL.check(m,null);
    }

    boolean checkExportACL(Message m) {
        return exportACL.check(m,null);
    }

    boolean isPublicURI(String uri) {
        Iterator i = pubSpaces.iterator();
        while (i.hasNext()) {
            String c = (String)i.next();
            if (c.endsWith("**")) {
                if (uri.startsWith(c.substring(0,c.lastIndexOf('/')+1)))
                    return true;
            } else if (c.endsWith("*")) {
                if (uri.startsWith(c.substring(0,c.lastIndexOf('/')+1))) {
                    String s = uri.substring(c.lastIndexOf('/')+1);
                    if (s.indexOf('/')==-1)
                        return true;
                }
            } else {
                if (uri.equals(c))
                    return true;
            }
        }
        return false;
    }

    void enableBridge() {
        try {
            RemoteElmBridge bridge =
                (RemoteElmBridge)Naming.lookup("//"+elmBridge+"/ElmBridge");
            String s = bridge.getBridgeData();
            StringTokenizer st = new StringTokenizer(s,".");
            byte b[] = new byte[4];
            b[0]=(byte)Integer.parseInt(st.nextToken());
            b[1]=(byte)Integer.parseInt(st.nextToken());
            b[2]=(byte)Integer.parseInt(st.nextToken());
            b[3]=(byte)Integer.parseInt(st.nextToken());
            ElmVE.elmVE.thisServer.bridge=b;

            ElmVE.elmVE.thisServer.makeURI();

            ElmVE.elmVE.admin.reflectBridgeConfig();
            Iterator i = accounts.iterator();
            while (i.hasNext()) {
                ElmUser eu = (ElmUser)i.next();
                eu.reflectBridgeConfig();
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    void disableBridge() {
        ElmVE.elmVE.thisServer.bridge=null;
    }

    void changeJDKHome(String s) {
        ((ElmClassLoader)ElmVE.classLoader).setJDKHome(s);
    }
    void addClassPath(String s) {
        ((ElmClassLoader)ElmVE.classLoader).addClassPath(s);
    }
    void delClassPath(String s) {
        ((ElmClassLoader)ElmVE.classLoader).delClassPath(s);
    }
    void refreshClassLoader() {
        try {
            ArrayList<String> cp = ((ElmClassLoader)ElmVE.classLoader).getElmClassPath();
            ArrayList<String> ecp = ((ElmClassLoader)ElmVE.classLoader).getExportElmClassPath();
            String javaHome = ((ElmClassLoader)ElmVE.classLoader).getJDKHome();
            ElmVE.classLoader = new ElmClassLoader(this.getClass().getClassLoader());
            A23.setClassLoader(ElmVE.classLoader);
            ((ElmClassLoader)ElmVE.classLoader).setElmClassPath(cp);
            ((ElmClassLoader)ElmVE.classLoader).setExportElmClassPath(ecp);
            ((ElmClassLoader)ElmVE.classLoader).setJDKHome(javaHome);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
