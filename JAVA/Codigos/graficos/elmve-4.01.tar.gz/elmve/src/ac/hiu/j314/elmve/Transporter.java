package ac.hiu.j314.elmve;

import java.util.*;

public class Transporter extends Elm implements NeverSave {
    private static final long serialVersionUID = 1L;
    ArrayList<ElmAgent> agentBackup = new ArrayList<ElmAgent>();

    protected String elm2DUIClass(){return "ac.hiu.j314.elmve.ui.EHidden2DUI";}
    protected String elm3DUIClass(){return "ac.hiu.j314.elmve.ui.EHidden3DUI";}
    protected String elmLightUIClass()
        {return "ac.hiu.j314.elmve.ui.EHiddenLightUI";}

    public void get2DUIData(MyRequest r) {
        send(makeReply(r,NULL));
    }
    public void get2DUIRepaintData(MyRequest r) {
        send(makeReply(r,NULL));
    }
    public void get3DUIData(MyRequest r) {
        send(makeReply(r,NULL));
    }
    public void get3DUIRepaintData(MyRequest r) {
        send(makeReply(r,NULL));
    }
    public void getLightUIData(MyRequest r) {
        send(makeReply(r,NULL));
    }
    public void getLightUIRepaintData(MyRequest r) {
        send(makeReply(r,NULL));
    }

    public void transportAgent(MyOrder o) {
        ElmAgent agent = (ElmAgent)o.get(0);
        agent.parent.elm.delElm(agent.stub);
        agent.prepareForTranslation();
        try{Thread.sleep(1000);}catch(Exception e){;}
        agent.engine.suspend();
        agentBackup.add(agent);
        String location = o.getString(1);
        String elmVELocation = W.getElmVEPath(location);
        String localPath = W.getLocalPath(location);
        ElmStub t = getElm(elmVELocation+"/sys/transporter");
        if (t==null) {
            System.out.println("can't transport.");
            send(makeMyOrder("failTransport",agent));
            return;
        }
        t = refreshStub(t);
        MyRequest r = makeMyRequest(t,"catchAgent",agent,localPath);
        receive(r,"transportAgent3",agent);
        send(r);
        send(makeMyOrder("failTransport",agent),5000);
    }
    public void transportAgent3(ReplySet rs) {
        ElmAgent agent = (ElmAgent)rs.get(0);
        if (rs.getBoolean(0,0)) {
System.out.println("gaha:1");
            agentBackup.remove(agent);
        } else {
System.out.println("gaha:2");
            send(makeMyOrder("failTransport",agent));
        }
    }

    public void failTransport(MyOrder o) {
        ElmAgent agent = (ElmAgent)o.get(0);
        if (!agentBackup.contains(agent)) {
System.out.println("gaha:3");
            return;
        }
        System.out.println("can't transport.");
        if (agent instanceof ElmAvatar) {
            ((ElmAvatar)agent).lastUpdateTime = -1;
            ((ElmAvatar)agent).lastElms = new ElmSet();
            if (((ElmAvatar)agent).client.isLocal()) {
                ((ElmAvatar)agent).client
                      = refreshStub(((ElmAvatar)agent).client);
            }
        }
        String path = agent.stub.path;
        path = path.substring(0,path.lastIndexOf('/')+1);
        ElmStub es = getElm(path);
        es.elm.addElm(agent.stub);
        agent.initOwnEngine("ElmAgent",2);
        agent.recursiveRefreshElm();
        if (agent instanceof ElmAvatar) {
            send(makeMyOrder(((ElmAvatar)agent).client,"bindAvatar",
                         agent.stub));
        }
    }

    public void catchAgent(MyRequest r) {
        ElmAgent agent = (ElmAgent)r.get(0);

        if (!ElmVE.elmVE.elmConfig.checkLogin(agent.loginName,agent.password)) {
System.out.println("gaha:password wrong!");
            send(makeReply(r,false));
            return;
        }

        Iterator i = ElmVE.elmVE.allAgents.iterator();
        while (i.hasNext()) {
            ElmStub es = (ElmStub)i.next();
            if (agent.loginName.equals(es.name)) {
                send(makeReply(r,false));
System.out.println("gaha:same agent already in!");
                return;
            }
        }

        ElmUser eu = ElmVE.elmVE.elmConfig.getUser(agent.loginName);
        ElmStub newAgent = W.makeElmAgent(eu);
        newAgent.elm.initOwnEngine("avatar",2);

        ElmStub esPath = getLocalElm(r.getString(1));
        esPath.elm.addElm(newAgent);

        agent.recursiveRegenerateElmStub();
        ((ElmAgent)newAgent.elm).copyData(agent);
//copy contents of old avatar into new avatar

        if (newAgent.instanceOf("ac.hiu.j314.elmve.ElmAvatar")) {
            ((ElmAvatar)newAgent.elm).home = ((ElmAvatar)agent).home;
            ((ElmAvatar)newAgent.elm).lastUpdateTime = -1;
            ((ElmAvatar)newAgent.elm).lastElms = new ElmSet();
            ElmStub elmClient = ((ElmAvatar)agent).client;
            if (elmClient.isLocal()) {
                elmClient = refreshStub(elmClient);
            }
            ((ElmAvatar)newAgent.elm).client = elmClient;
            send(makeMyOrder(elmClient,"bindAvatar",newAgent));
        }

        send(makeReply(r,true));
    }
}
