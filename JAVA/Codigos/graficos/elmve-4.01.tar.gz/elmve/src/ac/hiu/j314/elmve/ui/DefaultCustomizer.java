package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.clients.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DefaultCustomizer extends ElmCustomizer
                               implements ActionListener {
    private static final long serialVersionUID = 1L;
    JFrame frame;
    JTextField newNameTF;
    JButton chNameButton;

    public void startProcessing(MyOrder o) {
        super.startProcessing(o);
        frame = new JFrame("DefaultCustomizer");
        JPanel panel = new JPanel();
        frame.getContentPane().add(panel);
        GridBagLayout layout = new GridBagLayout();
        panel.setLayout(layout);
        GridBagConstraints c = new GridBagConstraints();
        c.fill=GridBagConstraints.HORIZONTAL;

        newNameTF = new JTextField(o.getString(0),20);
        newNameTF.addActionListener(this);
        c.gridx=0;c.gridy=0;c.gridwidth=1;c.gridheight=1;
        panel.add(newNameTF,c);

        chNameButton = new JButton("change");
        chNameButton.addActionListener(this);
        c.gridx=1;c.gridy=0;c.gridwidth=1;c.gridheight=1;
        panel.add(chNameButton,c);

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                frame.dispose();
                dispose();
            }
        });
        frame.pack();
        frame.setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == newNameTF) {
            send(makeMyOrder(elm,"setName",newNameTF.getText()));
        } else if (ae.getSource() == chNameButton) {
            send(makeMyOrder(elm,"setName",newNameTF.getText()));
        }
    }
}
