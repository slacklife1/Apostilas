package ac.hiu.j314.elmve;

import java.util.*;

public class ReqSet extends ArrayList<ReqBase> {
    private static final long serialVersionUID = 1L;
}
