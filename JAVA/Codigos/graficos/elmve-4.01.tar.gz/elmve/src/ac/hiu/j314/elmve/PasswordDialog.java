package ac.hiu.j314.elmve;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class PasswordDialog {
    static String data[] = null;
    static WaitingRoom wr = new WaitingRoom();
    static int result;

    public static int showPasswordDialog() {
        JFrame frame = new JFrame();

        Box b1 = Box.createVerticalBox();

        JPanel panel = new JPanel();
        GridBagLayout layout = new GridBagLayout();
        panel.setLayout(layout);
        GridBagConstraints c = new GridBagConstraints();
        c.fill=GridBagConstraints.HORIZONTAL;
        c.weightx=0.5;

        c.gridx = 0;c.gridy = 0;
        JLabel l1 = new JLabel("name");
        panel.add(l1,c);

        c.gridx = 1;c.gridy = 0;
        JTextField nameTF = new JTextField(20);
        nameTF.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                synchronized(wr) {
                    result=0;
                    wr.bell();
                }
            }
        });
        panel.add(nameTF,c);

        c.gridx = 0;c.gridy = 1;
        JLabel l2 = new JLabel("password");
        panel.add(l2,c);

        c.gridx = 1;c.gridy = 1;
        JPasswordField passwdPF = new JPasswordField(20);
        passwdPF.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                synchronized(wr) {
                    result=0;
                    wr.bell();
                }
            }
        });
        panel.add(passwdPF,c);

        b1.add(panel);

        Box b2 = Box.createHorizontalBox();
        JButton okButton = new JButton("Ok");
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                synchronized(wr) {
                    result=0;
                    wr.bell();
                }
            }
        });
        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                synchronized(wr) {
                    result=1;
                    wr.bell();
                }
            }
        });

        b2.add(okButton);
        b2.add(cancelButton);

        b1.add(b2);
        frame.getContentPane().add(b1);
        frame.pack();
        Dimension d = frame.getSize();
        GraphicsConfiguration gc = frame.getGraphicsConfiguration();
        Rectangle b = gc.getBounds();
        frame.setLocation(b.x + b.width/2  - d.width/2,
                          b.y + b.height/2 - d.height/2);
        frame.setVisible(true);

        synchronized(wr) {
            wr.room();
        }

        if (result==0) {
            data = new String[2];
            data[0] = nameTF.getText();
            data[1] = new String(passwdPF.getPassword());
        } else {
            data = new String[2];
            data[0] = null;
            data[1] = null;
        }

        frame.dispose();

        return result;
    }

    static String[] getPasswordData() {
        return data;
    }
}
