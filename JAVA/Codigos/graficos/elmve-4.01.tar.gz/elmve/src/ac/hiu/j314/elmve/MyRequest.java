package ac.hiu.j314.elmve;

import java.io.*;

public class MyRequest extends ReqBase {
    private static final long serialVersionUID = 1L;

    MyRequest(ElmStub sender, ElmStub receiver,
              String methodName, Serializable arguments[]) {
        super(sender,receiver,methodName,arguments);
    }
}
