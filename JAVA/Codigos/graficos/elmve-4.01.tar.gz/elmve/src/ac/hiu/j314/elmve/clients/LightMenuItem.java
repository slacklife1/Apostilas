package ac.hiu.j314.elmve.clients;

import java.util.*;
import java.awt.event.*;

public class LightMenuItem {
    String label;
    ArrayList<LightMenuItem> children = new ArrayList<LightMenuItem>();
    ArrayList<ActionListener> actionListeners = new ArrayList<ActionListener>();

    public LightMenuItem(String l) {
        label = l;
    }

    public void add(LightMenuItem lmi) {
        children.add(lmi);
    }

    public void add(LightMenuItem lmi,int i) {
        children.add(i,lmi);
    }

    public void addActionListener(ActionListener al) {
        actionListeners.add(al);
    }

    public int size() {
        return children.size();
    }

    public int indexOf(Object o) {
        return children.indexOf(o);
    }

    public LightMenuItem get(int i) {
        return (LightMenuItem)children.get(i);
    }

    protected void processEvent() {
        Iterator i = actionListeners.iterator();
        while (i.hasNext()) {
            ActionListener al = (ActionListener)i.next();
            ActionEvent ae = new ActionEvent(this,ActionEvent.ACTION_PERFORMED,label);
            al.actionPerformed(ae);
        }
    }
}
