package ac.hiu.j314.elmve.graph;

import ac.hiu.j314.elmve.*;
import java.io.*;
import java.awt.*;

public interface Line extends Serializable {
    public Place getHeadPlace();
    public Place getTailPlace();
    public void paint(Graphics g,Point head,Point tail);
}
