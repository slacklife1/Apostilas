package ac.hiu.j314.elmve;

import java.io.*;
import java.util.*;

public class ReplySet extends Message {
    private static final long serialVersionUID = 1L;
    protected ReqBase[] requests;
    protected Reply[] replies;

    /** (fuku,fuku) */
    ReplySet(ElmStub a,ArrayList<ReqBase> requests,
             String methodName,Serializable[] args) {
        super(a,a,methodName,args);
        this.requests = (ReqBase[])requests.toArray(new ReqBase[0]);
        this.replies = new Reply[requests.size()];
    }

    /** (tan,fuku) */
    ReplySet(ElmStub a,ReqBase request,
             String methodName,Serializable[] args) {
        super(a,a,methodName,args);
        requests = new ReqBase[1];
        requests[0] = request;
        replies = new Reply[1];
    }

    /** (fuku,tan) */
    ReplySet(ElmStub a,ArrayList<ReqBase> requests,
             String methodName,Serializable arg) {
        super(a,a,methodName,arg);
        this.requests = (ReqBase[])requests.toArray(new ReqBase[0]);
        this.replies = new Reply[requests.size()];
    }

    /** (tan,tan) */
    ReplySet(ElmStub a,ReqBase request,
             String methodName,Serializable arg) {
        super(a,a,methodName,arg);
        requests = new ReqBase[1];
        requests[0] = request;
        replies = new Reply[1];
    }

    boolean setReply(Reply r) {
        for (int i=0;i<requests.length;i++) {
            if (requests[i].messageID == r.request.messageID) {
                replies[i] = r;
                return true;
            }
        }
        return false;
    }

    boolean isReady() {
        for (int i=0;i<replies.length;i++) {
            if (replies[i] == null)
                return false;
        }
        return true;
    }

    public Reply[] getReplies() {
        return replies;
    }

    public int getReplyCount() {
        return replies.length;
    }

    public Reply getReply(int i) {
        return replies[i];
    }

    public Serializable get(int i,int j) {
        return replies[i].get(j);
    }

    public int getInt(int i,int j) {
        return replies[i].getInt(j);
    }

    public long getLong(int i,int j) {
        return replies[i].getLong(j);
    }

    public double getDouble(int i,int j) {
        return replies[i].getDouble(j);
    }

    public float getFloat(int i,int j) {
        return replies[i].getFloat(j);
    }

    public boolean getBoolean(int i,int j) {
        return replies[i].getBoolean(j);
    }

    public ElmStub getElm(int i,int j) {
        return replies[i].getElm(j);
    }

    public Order getOrder(int i,int j) {
        return replies[i].getOrder(j);
    }

    public MyOrder getMyOrder(int i,int j) {
        return replies[i].getMyOrder(j);
    }

    public Request getRequest(int i,int j) {
        return replies[i].getRequest(j);
    }

    public MyRequest getMyRequest(int i,int j) {
        return replies[i].getMyRequest(j);
    }

    public String getString(int i,int j) {
        return replies[i].getString(j);
    }

    public Place getPlace(int i,int j) {
        return replies[i].getPlace(j);
    }

    public Rotation getRotation(int i,int j) {
        return replies[i].getRotation(j);
    }

    public String toString() {
        try {
            StringBuffer sb = new StringBuffer();
            for (int i=0;i<replies.length;i++)
                sb.append(replies[i].toString());
            return sb.toString();
        } catch(Exception e) {
            return "null";
        }
    }
}
