package ac.hiu.j314.elmve.comp;

import ac.hiu.j314.elmve.clients.*;
import java.awt.*;

public class EContainer2DBG extends Elm2DBG {
    private static final long serialVersionUID = 1L;
    protected double width = 3.0;
    protected double height = 3.0;

    public void init(Elm2DData d) {
        width = d.getDouble(0);
        height = d.getDouble(1);
    }

    public void update(Elm2DData d) {
        width = d.getDouble(0);
        height = d.getDouble(1);
        repaint();
    }

    public void paintComponent(Graphics g) {
        g.setColor(getBackground());
        g.fillRect(0,0,getWidth(),getHeight());
        Point p1 = placeToPoint(-width/2.0,height/2.0);
        Point p2 = placeToPoint(width/2.0,-height/2.0);
        g.setColor(Color.black);
        g.drawRect(p1.x,p1.y,p2.x-p1.x,p2.y-p1.y);
    }

    public void setCenX(double x) {;}
    public void setCenY(double y) {;}
    public void setPPM(double ppm) {;}
    public double getCenX() {return 0.0;}
    public double getCenY() {return 0.0;}
    public double getPPM() {return 0.0;}
}
