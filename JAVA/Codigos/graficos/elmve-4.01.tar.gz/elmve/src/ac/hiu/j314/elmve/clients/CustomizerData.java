package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;
import java.lang.reflect.*;
import java.io.*;

public class CustomizerData implements Serializable {
    private static final long serialVersionUID = 1L;
    public ElmStub elm;
    public String className;
    public Serializable data[];

    public ElmCustomizer makeCustomizer() {
        try {
            Class c = ElmVE.classLoader.loadClass(className);
            Constructor con = c.getConstructor(new Class[0]);
            ElmCustomizer ec =
                (ElmCustomizer)con.newInstance(new Object[0]);
            ec.setElm(elm);
            return ec;
        } catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public int getDataCount() {
        return data.length;
    }

    public Serializable getAll() {
        return data;
    }

    public Serializable get(int i) {
        return data[i];
    }

    public int getInt(int i) {
        return ((Integer)data[i]).intValue();
    }

    public long getLong(int i) {
        return ((Long)data[i]).longValue();
    }

    public double getDouble(int i) {
        return ((Double)data[i]).doubleValue();
    }

    public boolean getBoolean(int i) {
        return ((Boolean)data[i]).booleanValue();
    }

    public String getString(int i) {
        return (String)data[i];
    }

    public Place getPlace(int i) {
        return (Place)data[i];
    }

    public Rotation getRotation(int i) {
        return (Rotation)data[i];
    }
}
