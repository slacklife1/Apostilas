package ac.hiu.j314.elmve;

import java.util.*;

public class ElmSet extends ArrayList<ElmStub> {
    private static final long serialVersionUID = 1L;
}
