package ac.hiu.j314.elmve.graph;

import ac.hiu.j314.elmve.*;
import java.io.*;

public class SLink extends Link {
    private static final long serialVersionUID = 1L;
    protected boolean isDirected;

//    public SLink(Dummy d) {
//        super(d);
//    }

    protected void init() {
        isDirected = false;
    }

    protected String customizerClass()
        {return "ac.hiu.j314.elmve.graph.SLinkCustomizer";}

    public Serializable[] getCustomizerData() {
        return null;
    }

    public void getLines(MyRequest r) {
        send(makeReply(r,new SLine(getPlace(head),getPlace(tail),isDirected)));
    }

    public boolean isDirected() {
        return isDirected;
    }

    public void setDirection(boolean d) {
        isDirected = d;
    }
}
