package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;

import java.io.*;

import javax.media.j3d.*;
import javax.vecmath.*;

public abstract class Elm3DUI {
    public static final Serializable NULL = Elm.NULL;
    public static final Serializable OK = Elm.OK;
    public static final Serializable ERROR = Elm.ERROR;

    ElmStub elm;
    ElmClient client;
    Place place = new Place();
    TransformGroup tg;
    Transform3D t;
    EBranchGroup bg;
    Elm3DBehavior behavior = null;

    public abstract void init(Elm3DData data);

    public abstract Node getSceneGraph();

    public abstract void update(Elm3DData data);

    public void setPlace(Place p) {
        place.set(p);
    }

    public Place getPlace() {
        return place;
    }

    public void setInterpolate(boolean b) {
        if (b)
            behavior = new Elm3DBehavior();
        else
            behavior = null;
    }

    public EBranchGroup getBranchGroup() {
        bg = new EBranchGroup();
        bg.setElm(elm);
        tg = new TransformGroup();
        tg.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
        bg.addChild(tg);
        t = new Transform3D();
        tg.setTransform(t);
        tg.addChild(getSceneGraph());
//        bg.setCapability(Group.ALLOW_CHILDREN_WRITE);
        bg.setCapability(BranchGroup.ALLOW_DETACH);
        if (behavior != null) {
            behavior.setTransform(tg,t);
            BoundingSphere bs = new BoundingSphere(new Point3d(0.0,0.0,0.0),
                                                   10.0);
            behavior.setSchedulingBounds(bs);
//            bg.addChild(behavior);
            tg.addChild(behavior);
        }
        return bg;
    }

    public void setElm(ElmStub e) {
        elm = e;
    }

    public void setClient(ElmClient client) {
        this.client = client;
    }

    public void move(Place p,Rotation r) {
        place.set(p);
        if (behavior!=null) {
            behavior.move(p,r);
        } else {
            Quat4d q = new Quat4d();
            q.set(W.toQuat4d(r));
            t.set(q,W.toVector3d(p),1.0);
            tg.setTransform(t);
        }
    }

    public void detach() {
        bg.detach();
    }
//----------------------------------------------------------------------
    public UIOrder makeOrder(String methodName,Serializable... args) {
        return new UIOrder(methodName,args);
    }
    public UIMyOrder makeMyOrder(String methodName,Serializable... args) {
        return new UIMyOrder(methodName,args);
    }
    public void send(UIMessage msg) {
        if (msg instanceof UIOrder)
            client.relayOrder(elm,msg.methodName,msg.arguments);
        else if (msg instanceof UIMyOrder)
            client.relayMyOrder(elm,msg.methodName,msg.arguments);
    }
}
