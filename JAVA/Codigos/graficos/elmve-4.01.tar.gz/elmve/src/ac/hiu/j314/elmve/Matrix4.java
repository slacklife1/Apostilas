package ac.hiu.j314.elmve;

import java.io.*;

public class Matrix4 implements Serializable {
    private static final long serialVersionUID = 1L;
    double a[][];

    public Matrix4() {
        a = new double[4][4];
    }

    public Matrix4(double a[][]) {
        for (int i=0;i<4;i++)
            for (int j=0;j<4;j++)
                this.a[i][j] = a[i][j];
    }

    public synchronized void set(Rotation r) {
        double d = r.w*r.w + r.x*r.x + r.y*r.y + r.z*r.z;
//        double d = 1.0;
        a[0][0] = 2.0*(-r.y*r.y - r.z*r.z)/d+1.0;
        a[0][1] = 2.0*( r.x*r.y - r.w*r.z)/d;
        a[0][2] = 2.0*( r.x*r.z + r.w*r.y)/d;
        a[1][0] = 2.0*( r.x*r.y + r.w*r.z)/d;
        a[1][1] = 2.0*(-r.x*r.x - r.z*r.z)/d+1.0;
        a[1][2] = 2.0*( r.y*r.z - r.w*r.x)/d;
        a[2][0] = 2.0*( r.x*r.z - r.w*r.y)/d;
        a[2][1] = 2.0*( r.y*r.z + r.w*r.x)/d;
        a[2][2] = 2.0*(-r.x*r.x - r.y*r.y)/d+1.0;

        a[3][3] = 1.0;
    }

    public synchronized void transform(Place p) {
        double x,y,z;
        x = a[0][0]*p.x+a[0][1]*p.y+a[0][2]*p.z+a[0][3];
        y = a[1][0]*p.x+a[1][1]*p.y+a[1][2]*p.z+a[1][3];
        z = a[2][0]*p.x+a[2][1]*p.y+a[2][2]*p.z+a[2][3];
        p.x = x;
        p.y = y;
        p.z = z;
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        for (int i=0;i<4;i++){
            for (int j=0;j<4;j++){
                sb.append(""+a[i][j]+", ");
            }
            sb.append("\n");
        }
        return sb.toString();
    }
}
