package ac.hiu.j314.elmve.comp;

import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.clients.*;
import java.io.*;
import java.util.*;
import org.w3c.dom.*;

public class EContainer extends Elm {
    private static final long serialVersionUID = 1L;
    double w = 3.0;
    double h = 3.0;

    ArrayList<Elm2DData> comps = new ArrayList<Elm2DData>();

    protected String elm2DUIClass()
        {return "ac.hiu.j314.elmve.comp.EContainer2DUI";}
    protected String elm2DBGClass()
        {return "ac.hiu.j314.elmve.comp.EContainer2DBG";}
    protected String customizerClass()
        {return "ac.hiu.j314.elmve.comp.EContainerCust";}

    public void get2DUIData(MyRequest r) {
        ElmSet elms = getElmsInside("*");
        if (elms.size()==0) {
            comps = new ArrayList<Elm2DData>();
            ArrayList<Serializable> ret = new ArrayList<Serializable>();
            ret.add(w);
            ret.add(h);
            ret.addAll(comps);
            send(makeReply(r,ret));
        }
        ReqSet reqs = makeMyRequest(elms,"send2DUIData",NULL);
        receive(reqs,"get2DUIData2",r);
        send(reqs);
    }
    public void get2DUIData2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);

        comps = new ArrayList<Elm2DData>();
        for (int i=0;i<rs.getReplyCount();i++) {
            comps.add((Elm2DData)rs.get(i,0));
        }

        ArrayList<Serializable> ret = new ArrayList<Serializable>();
        ret.add(w);
        ret.add(h);
        ret.addAll(comps);
        send(makeReply(r,ret));
    }

    public void get2DUIRepaintData(MyRequest r) {
        ElmSet elms = getElmsInside("*");
        if (elms.size()==0) {
            comps = new ArrayList<Elm2DData>();
            ArrayList<Serializable> ret = new ArrayList<Serializable>();
            ret.add(w);
            ret.add(h);
            ret.addAll(comps);
            send(makeReply(r,ret));
        }
        ReqSet reqs = makeMyRequest(elms,"send2DUIData",NULL);
        receive(reqs,"get2DUIRepaintData2",r);
        send(reqs);
    }
    public void get2DUIRepaintData2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);

        comps = new ArrayList<Elm2DData>();
        for (int i=0;i<rs.getReplyCount();i++) {
            comps.add((Elm2DData)rs.get(i,0));
        }

        ArrayList<Serializable> ret = new ArrayList<Serializable>();
        ret.add(w);
        ret.add(h);
        send(makeReply(r,ret));
    }

    public void get2DBGData(MyRequest r) {
        send(makeReply(r,w,h));
    }

    public void get2DBGRepaintData(MyRequest r) {
        send(makeReply(r,w,h));
    }

    public void setContainerWidth(Order o) {
        w=o.getDouble(0);
        repaint();
    }

    public void setContainerHeight(Order o) {
        h=o.getDouble(0);
        repaint();
    }

    public void getWH(Request r) {
        send(makeReply(r,w,h));
    }

    protected void saveExtension(Document d,Element e) {
        Element ee = W.makeElementDOM(d,"size");
        W.addChildDOM(e,ee);
        W.addDataDOM(d,ee,"w",""+w);
        W.addDataDOM(d,ee,"h",""+h);
    }
    protected void loadExtension(Element e,LoadedElmSet elmSet) {
        Element ee = W.getChildByTagNameDOM(e,"size");
        w = Double.parseDouble(W.getDataDOM(ee,"w"));
        h = Double.parseDouble(W.getDataDOM(ee,"h"));
    }

    public String toSaveString() {
        return super.toSaveString()+w+" "+h+"\n";
    }

    public void loadFromText(ElmStreamTokenizer f_in) throws IOException {
        super.loadFromText(f_in);
        w = f_in.nextDouble();
        h = f_in.nextDouble();
    }
}
