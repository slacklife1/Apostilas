package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.clients.*;
import javax.media.j3d.*;

public class EHidden3DUI extends Elm3DUI {
    public void init(Elm3DData data) {
    }

    public Node getSceneGraph() {
        return new Group();
    }

    public void update(Elm3DData d) {
        ;
    }
}
