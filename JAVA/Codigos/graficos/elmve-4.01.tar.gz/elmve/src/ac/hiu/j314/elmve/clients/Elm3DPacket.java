package ac.hiu.j314.elmve.clients;

import java.io.*;
import java.util.*;

public class Elm3DPacket implements Serializable {
    private static final long serialVersionUID = 1L;
    public Elm3DData backGround;
    public ArrayList<Elm3DData> eachUI;
    public CameraData camera;
}
