package ac.hiu.j314.elmve.graph;

import ac.hiu.j314.elmve.*;
import java.util.*;
import java.io.*;
import org.w3c.dom.*;

public class Node extends Elm {
    private static final long serialVersionUID = 1L;
    public static final int HEAD = 0;
    public static final int TAIL = 1;
    public static final int BOTH = 2;

    static Place dummyPlace = new Place();

    protected Sockets sockets;

    public Node() {
        sockets = new Sockets(this);
        sockets.addSocket("default","ac.hiu.j314.elmve.graph.SLink",
                          -1,Sockets.BOTH);
    }

    public void getSocketsData(Request r) {
        send(makeReply(r,sockets.getSocketsData()));
    }

    public void addLink(Order o) {
        sockets.addLink(o.getElm(0),o.getElm(1),o.getString(2),o.getInt(3));
        repaint();
    }

    public void delLink(Order o) {
        sockets.delLink(o.getElm(0),o.getElm(1),o.getString(2),o.getInt(3));
        repaint();
    }

    public void delLinkByLink(MyOrder o) {
        sockets.delLinkByLink(o.getElm(0));
        repaint();
    }

    protected void setPlace(Place p) {
        ElmSet al = sockets.getLinks();
        send(makeOrder(al,"setPlace",dummyPlace));
        super.setPlace(p);
        repaint();
    }

    protected ArrayList getOutLinks() {
        return sockets.getOutLinks();
    }

    protected ArrayList getLinkedNodes() {
        return sockets.getLinkedNodes();
    }

    protected ArrayList getOutNodes() {
        return sockets.getOutNodes();
    }

    protected ArrayList getInNodes() {
        return sockets.getInNodes();
    }

    protected void saveExtension(Document d,Element e) {
        Element ee = W.makeElementDOM(d,"Links");
        W.addChildDOM(e,ee);
        Iterator i = sockets.sockets.iterator();
        while (i.hasNext()) {
            Socket socket = (Socket)i.next();
            Iterator j = socket.links.iterator();
            while (j.hasNext()) {
                Socket.SS ss = (Socket.SS)j.next();
                Element eee = W.makeElementDOM(d,"link");
                W.addChildDOM(ee,eee);
                W.addAttrDOM(d,eee,"linkID",""+ss.link.getElmID());
                W.addAttrDOM(d,eee,"nodeID",""+ss.node.getElmID());
                W.addAttrDOM(d,eee,"socketName",socket.socketName);
                String di = (ss.direction==HEAD?"HEAD":(ss.direction==TAIL?"TAIL":"BOTH"));
                W.addAttrDOM(d,eee,"direction",di);
            }
        }
    }
    protected void loadExtension(Element e,LoadedElmSet elmSet) {
        sockets.resetLink();
        Element ee = W.getChildByTagNameDOM(e,"Links");
        ArrayList al = W.getChildrenByTagNameDOM(ee,"link");
        Iterator i = al.iterator();
        while (i.hasNext()) {
            Element eee = (Element)i.next();
            long linkID = Long.parseLong(W.getAttrDataDOM(eee,"linkID"));
            ElmStub link = elmSet.getElm(linkID);
            long nodeID = Long.parseLong(W.getAttrDataDOM(eee,"nodeID"));
            ElmStub node = elmSet.getElm(nodeID);
            String socketName = W.getAttrDataDOM(eee,"socketName");
            String di = W.getAttrDataDOM(eee,"direction");
            int d = (di.equals("HEAD")?HEAD:(di.equals("TAIL")?TAIL:BOTH));
            sockets.addLink(link,node,socketName,d);
        }
    }

    public String toSaveString() {
        StringBuffer sb = new StringBuffer();
        sb.append(super.toSaveString());
        sb.append("// number of Sockets\n");
        sb.append(""+sockets.sockets.size()+"\n");
        Iterator i = sockets.sockets.iterator();
        while (i.hasNext()) {
            Socket s = (Socket)i.next();
            sb.append("//socket data\n");
            sb.append(s.socketName+" "+s.className+" "+s.number+" "+s.direction+"\n");
            sb.append(s.links.size()+"\n");
            Iterator j = s.links.iterator();
            while (j.hasNext()) {
                Socket.SS ss = (Socket.SS)j.next();
                sb.append("'"+ss.link.getName()+"' ");
                sb.append("'"+ss.node.getName()+"' ");
                sb.append(""+ss.direction+" ");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    public void loadFromText(ElmStreamTokenizer f_in) throws IOException {
        super.loadFromText(f_in);
        int n = f_in.nextInt();
        for (int i=0;i<n;i++) {
            String sName = f_in.nextString();
            String cName = f_in.nextString();
            int no = f_in.nextInt();
            int d = f_in.nextInt();
            Socket s = new Socket(sName,cName,no,d);
            int m = f_in.nextInt();
            for (int j=0;j<m;j++) {
                String lName = f_in.nextString();
                ElmStub ll = getElm(lName);
                String nName = f_in.nextString();
                ElmStub nn = getElm(nName);
                int dd = f_in.nextInt();
                s.add(ll,nn,dd);
            }
            sockets.sockets.add(s);
        }
//sockets.loadFromText(f_in);
    }

    public void repaint() {
        super.repaint();
        send(makeMyOrder(getElm("."),"repaint",NULL));
        Iterator i = sockets.getLinks().iterator();
        while (i.hasNext())
            send(makeMyOrder((ElmStub)i.next(),"repaint",NULL));
    }

    protected void dispose() {
        ArrayList al = sockets.getLinks();
        Iterator i = al.iterator();
        while (i.hasNext()) {
            ElmStub l = (ElmStub)i.next();
            send(makeMyOrder(l,"dispose",this.getStub()));
        }
        super.dispose();
    }
}
