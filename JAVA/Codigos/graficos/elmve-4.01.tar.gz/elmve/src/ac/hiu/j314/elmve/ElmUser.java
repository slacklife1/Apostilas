package ac.hiu.j314.elmve;

import java.io.*;
import org.w3c.dom.*;

class ElmUser implements Serializable {
    private static final long serialVersionUID = 1L;
    String name;
    String userID;
    String password;
    String role;
    String avatar;
    String home;

    ElmUser() {
    }

    ElmUser(String name,String userID,String password,String role,
            String avatar,String home) {
        this.name = name;
        this.userID = userID;
        this.password = password;
        this.role = role;
        this.avatar = avatar;
        this.home = home;
    }

    void saveAsXML(Document d,Element e) {
        W.addDataDOM(d,e,"name",name);
        W.addDataDOM(d,e,"userID",userID);
        W.addLineFeedDOM(d,e);
        W.addDataDOM(d,e,"password",password);
        W.addDataDOM(d,e,"role",role);
        W.addLineFeedDOM(d,e);
        W.addDataDOM(d,e,"avatar",avatar);
        W.addDataDOM(d,e,"home",W.getLocalPath(home));
        W.addLineFeedDOM(d,e);
    }

    void loadFromXML(Element e) {
        name = W.getDataDOM(e,"name");
        userID = W.getDataDOM(e,"userID");
        password = W.getDataDOM(e,"password");
        role = W.getDataDOM(e,"role");
        avatar = W.getDataDOM(e,"avatar");
        home = ElmVE.elmVE.thisServer.toString()+W.getDataDOM(e,"home");
    }

    void reflectBridgeConfig() {
        home = ElmVE.elmVE.thisServer.toString()+W.getLocalPath(home);
System.out.println("gaha ElmUser.reflectBridgeConfig()");
System.out.println("gaha"+home);
    }
}
