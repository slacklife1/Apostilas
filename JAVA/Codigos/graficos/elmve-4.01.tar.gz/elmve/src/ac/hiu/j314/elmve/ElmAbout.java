package ac.hiu.j314.elmve;

import java.awt.event.*;
import java.net.*;
import java.io.*;
import javax.swing.*;

public class ElmAbout {
    JFrame frame;
    JEditorPane editor;

    public ElmAbout() {
        frame = new JFrame("ElmAbout");
        JScrollPane pane = new JScrollPane();
        JViewport port = pane.getViewport();
        editor = new JEditorPane();
        editor.setEditable(false);
        port.add(editor);
        frame.getContentPane().add(pane);
        try {
            URL resource =
                W.getResource("x-res:///ac/hiu/j314/elmve/resources/about.html");
            editor.setPage(resource);
        } catch(IOException e) {
            e.printStackTrace();
        }

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                frame.dispose();
            }
        });

        frame.setSize(500,500);
        frame.setVisible(true);
    }
}
