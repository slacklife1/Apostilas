package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.clients.*;
import javax.swing.*;
import java.awt.event.*;

public class ECheckBox2DUI extends Elm2DUI implements ActionListener {
    private static final long serialVersionUID = 1L;
    protected JCheckBox checkBox;

    public void init(Elm2DData d) {
        checkBox = new JCheckBox();
        add(checkBox);
        checkBox.addActionListener(this);
        checkBox.setSelected(d.getBoolean(0));
    }

    public void update(Elm2DData d) {
        checkBox.setSelected(d.getBoolean(0));
        repaint();
    }

    public void actionPerformed(ActionEvent ae) {
        send(makeOrder("catchECheckBoxEvent",NULL));
    }
}
