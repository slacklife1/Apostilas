package ac.hiu.j314.elmve;

import java.io.*;
import java.net.*;
import java.util.*;

import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;
import javax.vecmath.*;

public class W {
    public static String sepa = System.getProperty("file.separator");
    public static Class orderClass = new Order(null,null,null,null).getClass();
    public static Class requestClass = new Request(null,null,null,null).getClass();

    public static Message makeMessageFromString(Elm elm, String ss)
                                                throws ElmException {
        ss = ss.trim();
        if (ss.endsWith("&")) {
            return makeOrderFromString(elm,ss);
        } else {
            return makeRequestFromString(elm,ss);
        }
    }

    public static Request makeRequestFromString(Elm elm, String ss)
                                                throws ElmException {
        ss = ss.trim();
        if (ss.equals(""))
            return null;
        StringTokenizer st = new StringTokenizer(ss);
        Vector<String> v = new Vector<String>();
        while (st.hasMoreTokens())
            v.add(st.nextToken());

        String s = (String)v.remove(0);

        ElmStub receiver;
        if (s.startsWith("##")) {
            receiver = elm.getElm(s.substring(2));
            if (receiver == null) {
                throw new ElmException("No such elms!("+s.substring(2)+")");
            }
            if (v.size() == 0) {
                throw new ElmException("No message name.");
            }
            s = (String)v.remove(0);
        } else if (s.startsWith("#")) {
            s = s.substring(1);
            receiver = elm.parent;
        } else {
            receiver = elm.stub;
        }

        Serializable args[] = new Serializable[v.size()];
        for (int i=0;i<v.size();i++)
            args[i] = (Serializable)W.stringToObject((String)v.get(i));

        return new Request(elm.stub,receiver,s,args);
    }

    public static Order makeOrderFromString(Elm elm, String ss)
                                            throws ElmException {
        ss = ss.trim();
        if (ss.equals(""))
            return null;
        StringTokenizer st = new StringTokenizer(ss);
        Vector<String> v = new Vector<String>();
        while (st.hasMoreTokens())
            v.add(st.nextToken());

        String s = (String)v.remove(0);

        ElmStub receiver;
        if (s.startsWith("##")) {
            receiver = elm.getElm(s.substring(2));
            if (receiver == null)
                throw new ElmException("No such elms!("+s.substring(2)+")");
            if (v.size() == 0) {
                throw new ElmException("No message name.");
            }
            s = (String)v.remove(0);
        } else if (s.startsWith("#")) {
            s = s.substring(1);
            receiver = elm.parent;
        } else {
            receiver = elm.stub;
        }

        Serializable args[] = new Serializable[v.size()];
        for (int i=0;i<v.size();i++)
            args[i] = (Serializable)W.stringToObject((String)v.get(i));

        return new Order(elm.stub,receiver,s,args);
    }

    /*
    public static Integer p(int i) {
        return new Integer(i);
    }

    public static Long p(long l) {
        return new Long(l);
    }

    public static Double p(double d) {
        return new Double(d);
    }

    public static Float p(float f) {
        return new Float(f);
    }

    public static Boolean p(boolean b) {
        return new Boolean(b);
    }

    public static int p(Integer i) {
        return i.intValue();
    }

    public static long p(Long l) {
        return l.longValue();
    }

    public static double p(Double d) {
        return d.doubleValue();
    }

    public static float p(Float f) {
        return f.floatValue();
    }

    public static boolean p(Boolean b) {
        return b.booleanValue();
    }

    public static Serializable[] pp() {
        Serializable o[] = new Serializable[0];
        return o;
    }

    public static Serializable[] pp(Serializable o0) {
        Serializable o[] = new Serializable[1];
        o[0] = o0;
        return o;
    }

    public static Serializable[] pp(Serializable o0,Serializable o1) {
        Serializable o[] = new Serializable[2];
        o[0] = o0;
        o[1] = o1;
        return o;
    }

    public static Serializable[] pp(Serializable o0,Serializable o1,
                                    Serializable o2) {
        Serializable o[] = new Serializable[3];
        o[0] = o0;
        o[1] = o1;
        o[2] = o2;
        return o;
    }

    public static Serializable[] pp(Serializable o0,Serializable o1,
                                    Serializable o2,Serializable o3) {
        Serializable o[] = new Serializable[4];
        o[0] = o0;
        o[1] = o1;
        o[2] = o2;
        o[3] = o3;
        return o;
    }

    public static Serializable[] pp(Serializable o0,Serializable o1,
                                    Serializable o2,Serializable o3,
                                    Serializable o4) {
        Serializable o[] = new Serializable[5];
        o[0] = o0;
        o[1] = o1;
        o[2] = o2;
        o[3] = o3;
        o[4] = o4;
        return o;
    }

    public static Serializable[] pp(Serializable o0,Serializable o1,
                                    Serializable o2,Serializable o3,
                                    Serializable o4,Serializable o5) {
        Serializable o[] = new Serializable[6];
        o[0] = o0;
        o[1] = o1;
        o[2] = o2;
        o[3] = o3;
        o[4] = o4;
        o[5] = o5;
        return o;
    }

    public static Serializable[] pp(Serializable o0,Serializable o1,
                                    Serializable o2,Serializable o3,
                                    Serializable o4,Serializable o5,
                                    Serializable o6) {
        Serializable o[] = new Serializable[7];
        o[0] = o0;
        o[1] = o1;
        o[2] = o2;
        o[3] = o3;
        o[4] = o4;
        o[5] = o5;
        o[6] = o6;
        return o;
    }

    public static Serializable[] pp(Serializable o0,Serializable o1,
                                    Serializable o2,Serializable o3,
                                    Serializable o4,Serializable o5,
                                    Serializable o6,Serializable o7) {
        Serializable o[] = new Serializable[8];
        o[0] = o0;
        o[1] = o1;
        o[2] = o2;
        o[3] = o3;
        o[4] = o4;
        o[5] = o5;
        o[6] = o6;
        o[7] = o7;
        return o;
    }

    public static Serializable[] pp(Serializable o0,Serializable o1,
                                    Serializable o2,Serializable o3,
                                    Serializable o4,Serializable o5,
                                    Serializable o6,Serializable o7,
                                    Serializable o8) {
        Serializable o[] = new Serializable[9];
        o[0] = o0;
        o[1] = o1;
        o[2] = o2;
        o[3] = o3;
        o[4] = o4;
        o[5] = o5;
        o[6] = o6;
        o[7] = o7;
        o[8] = o8;
        return o;
    }

    public static Serializable[] pp(Serializable o0,Serializable o1,
                                    Serializable o2,Serializable o3,
                                    Serializable o4,Serializable o5,
                                    Serializable o6,Serializable o7,
                                    Serializable o8,Serializable o9) {
        Serializable o[] = new Serializable[10];
        o[0] = o0;
        o[1] = o1;
        o[2] = o2;
        o[3] = o3;
        o[4] = o4;
        o[5] = o5;
        o[6] = o6;
        o[7] = o7;
        o[8] = o8;
        o[9] = o9;
        return o;
    }
    */
    public static String f(double d,int i,int j) {
        if (d == 0.0)
            return "+0.00000000000000".substring(0,i+2)
                  +"E+000000000000000".substring(0,j+2);
        String s = (d<0.0)?"-":"+";
        d = Math.abs(d);
        double k = Math.ceil(Math.log(d)/Math.log(10.0))-1;
        d = d/Math.pow(10.0,k);
        if (d == 10.0) {d /= 10.0;k+=1.0;}
        String ss = ""+d;
        ss = ss+"00000000000000";
        s = s + ss.substring(0,i+1);
        s = s + ((k<0.0)?"E-":"E+");
        k = Math.abs(k);
        ss = ""+(int)k;
        ss = "00000000000000"+ss;
        s = s + ss.substring(ss.length()-j,ss.length());
        return s;
    }

    public static String toSaveString(String s) {
        StringBuffer sb = new StringBuffer(s);
        int i=0;
        while (sb.length()>i) {
            if (sb.charAt(i) == '\n') {
                sb = sb.replace(i,i+1,"\\n");
                i++;i++;
            } else {
                i++;
            }
        }
        return "\""+sb.toString()+"\"";
    }

    public static Object stringToObject(String ss) {
// This method transrates a string to a object
// Integer -> Integer, Double -> Double
// other -> String
// a string ends with 'f' or 'F' -> Float
// a string ends with 'l' or 'L' -> Long

        Object o;
        try {
            if (ss.endsWith("l") ||
                ss.endsWith("L"))
                o = new Long(ss.substring(0,ss.length()-1));
            else
                o = new Integer(ss);
        } catch(Exception e) {
            try {
                if (ss.charAt(ss.length()-1)=='f' ||
                    ss.charAt(ss.length()-1)=='F')
                    o = new Float(ss);
                else
                    o = new Double(ss);
            } catch (Exception ee) {
                if (ss.startsWith("\"") && ss.endsWith("\"")) {
                    ss = ss.substring(1);
                    ss = ss.substring(0,ss.length()-1);
                } else if (ss.startsWith("'") && ss.endsWith("'")) {
                    ss = ss.substring(1);
                    ss = ss.substring(0,ss.length()-1);
                }
                o = ss;
            }
        }
        return o;
    }

    static Class c = new W().getClass();
    public static ElmStreamTokenizer getEST(String file) throws IOException {
        ElmStreamTokenizer est = null;
        try {
            if (file.startsWith("x-res:")) {
                file = file.substring(6);
                while (file.startsWith("/"))
                    file = file.substring(1);
                URL url = ElmVE.classLoader.getResource(file);
                if (url == null)
                    url = c.getResource(file);
                InputStreamReader isr = new InputStreamReader(url.openStream());
                est = new ElmStreamTokenizer(isr);
            } else {
                URL url = new URL(file);
                InputStreamReader isr = new InputStreamReader(url.openStream());
                est = new ElmStreamTokenizer(isr);
            }
        } catch (MalformedURLException me) {
            try {
                FileReader reader = new FileReader(file);
                est = new ElmStreamTokenizer(reader);
            } catch (FileNotFoundException fe) {
                throw new IOException();
            }
        }
        return est;
    }

    public static URL getResource(String resource) {
        if (resource.startsWith("http:") ||
            resource.startsWith("file:")) {
            try {
                return new URL(resource);
            } catch(Exception e) {
                return null;
            }
        } else if (resource.startsWith("x-res:")) {
            resource = resource.substring(6);
            while (resource.startsWith("/"))
                resource = resource.substring(1);
            URL ret = ElmVE.classLoader.getResource(resource);
            if (ret == null)
                ret = c.getResource(resource);
            return ret;
        } else {
            try {
                return new URL("file:"+resource);
            } catch(Exception e) {
                return null;
            }
        }
    }

    public static String getIPAddress() {
        try {
            InetAddress ia = InetAddress.getLocalHost();
            return ia.getHostAddress();
        } catch (java.net.UnknownHostException ue) {
            ue.printStackTrace();
            return null;
        }
    }

    public static byte[] getIPAddressByByte() {
        try {
            InetAddress ia = InetAddress.getLocalHost();
            return ia.getAddress();
        } catch (java.net.UnknownHostException ue) {
            ue.printStackTrace();
            return null;
        }
    }

    public static String getLocalPath(String path) {
        path = path.trim();
        if (path.startsWith("//")) {
            path = path.substring(2);
            path = path.substring(path.indexOf("/")+1);
            if (path.indexOf("/")==-1)
                path = "/";
            else
                path = path.substring(path.indexOf("/"));
        }
        return path;
    }

    public static String getElmVEPath(String path) {
        path = path.trim();
        if (!path.startsWith("//"))
            return null;
        int i = path.indexOf("/",2);
        i = path.indexOf("/",i+1);
        if (i==-1)
            i=path.length();
        path = path.substring(0,i);
        return path;
    }
//--DOM-----------------------------------------------------------------
    public static void domdom(Node n) {
        System.out.println(n.toString());
        NodeList nl = n.getChildNodes();
        for (int i=0;i<nl.getLength();i++)
            domdom(nl.item(i));
    }

    public static Document makeEmptyDocumentDOM() {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            return db.newDocument();
        } catch(ParserConfigurationException pce) {
            pce.printStackTrace();
            return null;
        }
    }

    public static Document loadDocumentFromFileDOM(String fileName)
	throws IOException {
        try {
            InputStream is = new File(fileName).toURL().openStream();
            return loadDocumentFromInputStreamDOM(is);
        } catch (Exception e) {
            throw new IOException();
        }
    }

    public static Document loadDocumentFromInputStreamDOM(InputStream is)
	throws IOException {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            return db.parse(is);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void saveDocumentAsFileDOM(Document d,String fileName)
	throws IOException {
        try {
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer t = tf.newTransformer();
            DOMSource source = new DOMSource(d);
            StreamResult result = new StreamResult(new File(fileName));
            t.transform(source,result);
        } catch (Exception e) {
            throw new IOException();
        }
    }

    public static void saveDocumentToOutputStreamDOM(Document d,OutputStream os)
	throws IOException {
        try {
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer t = tf.newTransformer();
            DOMSource source = new DOMSource(d);
            StreamResult result = new StreamResult(os);
            t.transform(source,result);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Element makeElementDOM(Document d,String tagName) {
        return d.createElement(tagName);
    }
    public static void addChildDOM(Element e,Node n) {
        e.appendChild(n);
    }
    public static void addChildDOM(Document d,Node n) {
        d.appendChild(n);
    }
    public static Element addDataDOM(Document d,Element e,String tagName,
                              String data) {
        Element eTmp = d.createElement(tagName);
        eTmp.appendChild(d.createTextNode(data));
        e.appendChild(eTmp);
        return eTmp;
    }
    public static void addDataDOM(Document d,Element e,String data) {
        e.appendChild(d.createTextNode(data));
    }
    public static void addLineFeedDOM(Document d,Element e) {
        e.appendChild(d.createTextNode("\n"));
    }
    public static void addAttrDOM(Document d,Element e,String attrName,
                              String data) {
        e.setAttribute(attrName,data);
    }

    public static Element getChildByTagNameDOM(Element e,String tagName) {
        ArrayList al = getChildrenByTagNameDOM(e,tagName);
        if (al.size()>0)
            return (Element)al.get(0);
        else
            return null;
    }

    public static ArrayList getChildrenByTagNameDOM(Element e,String tagName) {
        ArrayList<Node> ret = new ArrayList<Node>();
        NodeList nl = e.getChildNodes();
        for (int i=0;i<nl.getLength();i++) {
            Node ee = nl.item(i);
            if (!(ee instanceof Element))
                continue;
            if (tagName.equals(((Element)ee).getTagName()))
                ret.add(ee);
        }
        return ret;
    }

    public static String getDataDOM(Element e,String tagName) {
        Element eTmp = getChildByTagNameDOM(e,tagName);
        Text t = (Text)eTmp.getFirstChild();
        if (t==null)
            return null;
        else
            return t.getData();
    }

    public static String getDataDOM(Element e) {
        Text t = (Text)e.getFirstChild();
        if (t==null)
            return null;
        else
            return t.getData();
    }

    public static String getAttrDataDOM(Element e,String attrName) {
        return e.getAttribute(attrName);
    }

    static ElmStub makeElmAgent(ElmUser eu) {
        ElmStub es = null;
        if (eu.avatar.equals("default")) {
            es = ElmVE.elmVE.makeElm(ElmVE.elmVE.defaultAvatarClass,
                                     eu.name,eu.userID);
        } else {
            es = ElmVE.elmVE.makeElm(eu.avatar,eu.name,eu.userID);
        }

        es.role = eu.role;
        ((ElmAgent)es.elm).home = eu.home;

        return es;
    }

//----------------------------------------------------------------------

    public static Vector3d toVector3d(Place p) {
        return new Vector3d(p.x,p.y,p.z);
    }

    public static Point3d toPoint3d(Place p) {
        return new Point3d(p.x,p.y,p.z);
    }

    public static Quat4d toQuat4d(Rotation r) {
        return new Quat4d(r.x,r.y,r.z,r.w);
    }
//----------------------------------------------------------------------
    public static String dotDecimal2String(byte address[]) {
        int i0 = address[0]<0?address[0]+256:address[0];
        int i1 = address[1]<0?address[1]+256:address[1];
        int i2 = address[2]<0?address[2]+256:address[2];
        int i3 = address[3]<0?address[3]+256:address[3];
        return ""+i0+"."+i1+"."+i2+"."+i3;
    }
    public static byte[] string2dotDecimal(String uri) {
        byte address[] = new byte[4];
        StringTokenizer st = new StringTokenizer(uri,"/");
        StringTokenizer st2 = new StringTokenizer(st.nextToken(),".");
        address[0]=(byte)Integer.parseInt(st2.nextToken());
        address[1]=(byte)Integer.parseInt(st2.nextToken());
        address[2]=(byte)Integer.parseInt(st2.nextToken());
        address[3]=(byte)Integer.parseInt(st2.nextToken());
        return address;
    }
    /**
     * とりあえず、てきとう。
     * 
     */
    public static String searchJDKHome() {
        if (W.sepa.equals("/")) {
            if (new File("/usr/local/jdk1.5.0_02/lib/tools.jar").exists())
                return "/usr/local/jdk1.5.0_02";
            else if (new File("/usr/local/jdk1.5.0_01/lib/tools.jar").exists())
                return "/usr/local/jdk1.5.0_01";
            else if (new File("/usr/local/jdk1.5.0/lib/tools.jar").exists())
                return "/usr/local/jdk1.5.0";
            return "-----";
        } else if (W.sepa.equals("\\")) {
            if (new File("C:\\Program Files\\Java\\jdk1.5.0_02\\lib\\tools.jar").exists())
                return "C:\\Program Files\\Java\\jdk1.5.0_02";
            else if (new File("C:\\Program Files\\Java\\jdk1.5.0_01\\lib\\tools.jar").exists())
                return "C:\\Program Files\\Java\\jdk1.5.0_01";
            else if (new File("C:\\Program Files\\Java\\jdk1.5.0\\lib\\tools.jar").exists())
                return "C:\\Program Files\\Java\\jdk1.5.0";
            else if (new File("C:\\usr\\local\\j2sdk\\lib\\tools.jar").exists())
                return "C:\\usr\\local\\j2sdk";
            return "-----";
        } else {
            return "-----";
        }
    }
}
