package ac.hiu.j314.elmve.comp;

import ac.hiu.j314.elmve.*;

public class ECheckBox extends Elm {
    private static final long serialVersionUID = 1L;

    protected String elm2DUIClass()
        {return "ac.hiu.j314.elmve.ui.ECheckBox2DUI";}

    public void get2DUIData(MyRequest r) {
        send(makeReply(r,false));
    }
    public void get2DUIRepaintData(MyRequest r) {
        send(makeReply(r,NULL));
    }

    public void catchECheckBoxEvent(Order o) {
System.out.println("ECheckBox.catchECheckBoxEvent().");
    }
}
