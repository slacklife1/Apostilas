package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;
import java.io.*;
import java.lang.reflect.*;

public class Elm3DData implements Serializable {
    private static final long serialVersionUID = 1L;
    public static final int NEW = 1;
    public static final int OLD = 2;
    public static final int UPDATE = 3;
    public int type;
    public String className;
    public ElmStub elm;
    public Place place = new Place();
    public Rotation rotation = new Rotation();
    public Serializable data[];

    public Elm3DData(int type) {
        this.type = type;
    }

    public Elm3DBG makeBG() {
        try {
            Elm3DBG bg = null;
            Class bgClass = ElmVE.classLoader.loadClass(className);
            Constructor con = bgClass.getConstructor(new Class[0]);
            bg = (Elm3DBG)con.newInstance(new Object[0]);
            bg.setElm(elm);
            bg.init(this);
            return bg;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public Elm3DUI makeUI() {
        try {
            Elm3DUI ui = null;
            Class cbClass = ElmVE.classLoader.loadClass(className);
            Constructor con = cbClass.getConstructor(new Class[0]);
            ui = (Elm3DUI)con.newInstance(new Object[0]);
            ui.setElm(elm);
            ui.setPlace(place);
            ui.init(this);
            return ui;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public int getDataCount() {
        return data.length;
    }

    public Serializable getAll() {
        return data;
    }

    public Serializable get(int i) {
        return data[i];
    }

    public int getInt(int i) {
        return ((Integer)data[i]).intValue();
    }

    public long getLong(int i) {
        return ((Long)data[i]).longValue();
    }

    public double getDouble(int i) {
        return ((Double)data[i]).doubleValue();
    }

    public boolean getBoolean(int i) {
        return ((Boolean)data[i]).booleanValue();
    }

    public String getString(int i) {
        return (String)data[i];
    }

    public Place getPlace(int i) {
        return (Place)data[i];
    }

    public Rotation getRotation(int i) {
        return (Rotation)data[i];
    }
}
