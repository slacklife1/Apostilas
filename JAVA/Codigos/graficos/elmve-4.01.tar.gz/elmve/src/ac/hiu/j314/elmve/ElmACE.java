package ac.hiu.j314.elmve;

import java.util.*;
import java.io.*;

//
//(S|D)_BADDRESS
//(S|D)_ADDRESS
//(S|D)_SERVERNAME
//(S|D)_ADMIN
//(S|D)_SELF
//(S|D)_OWNER
//(S|D)_ROLE
//(S|D)_REMOTE
//(S|D)_LOCAL
//(S|D)_MYCUSTMIZER
//(S|D)_INNERSPACE
//(S|D)_OUTERSPACE
//
//(S|D)_NAME
//(S|D)_CLASS
//(S|D)_PACKAGE
//(S|D)_PATH
//

class ElmACE implements Serializable {
    private static final long serialVersionUID = 1L;
    static final int ACCEPT = 0;
    static final int DENY = 1;
    static final int NO_MATCH = 2;

    static final int CAN_NOT_PARSE = -1;
    static final int S_BADDRESS = 0;
    static final int D_BADDRESS = 1;
    static final int S_ADDRESS = 2;
    static final int D_ADDRESS = 3;
    static final int S_SERVERNAME = 4;
    static final int D_SERVERNAME = 5;
    static final int S_ADMIN = 6;
    static final int D_ADMIN = 7;
    static final int S_SELF = 8;
    static final int D_SELF = 9;
    static final int S_OWNER = 10;
    static final int D_OWNER = 11;
    static final int S_ROLE = 12;
    static final int D_ROLE = 13;
    static final int S_REMOTE = 14;
    static final int D_REMOTE = 15;
    static final int S_LOCAL = 16;
    static final int D_LOCAL = 17;
    static final int S_MYCUSTOMIZER = 18;
    static final int D_MYCUSTOMIZER = 19;
    static final int S_INNERSPACE = 20;
    static final int D_INNERSPACE = 21;
    static final int S_OUTERSPACE = 22;
    static final int D_OUTERSPACE = 23;

    String stringExpression;
    int type;
    byte address[];
    byte mask[];
    String serverName;
    String userID;
    String role;
    int target;

    ElmACE() {
    }

    ElmACE(String s) {
        stringExpression = s.trim();
        parseStringExpression();
    }

    void parseStringExpression() {
        if (stringExpression.startsWith("S_BADDRESS"))
            sBAddressParse();
        else if (stringExpression.startsWith("D_BADDRESS"))
            dBAddressParse();
        else if (stringExpression.startsWith("S_ADDRESS"))
            sAddressParse();
        else if (stringExpression.startsWith("D_ADDRESS"))
            dAddressParse();
        else if (stringExpression.startsWith("S_SERVERNAME"))
            sServerNameParse();
        else if (stringExpression.startsWith("D_SERVERNAME"))
            dServerNameParse();
        else if (stringExpression.startsWith("S_ADMIN"))
            sAdminParse();
        else if (stringExpression.startsWith("D_ADMIN"))
            dAdminParse();
        else if (stringExpression.startsWith("S_SELF"))
            sSelfParse();
        else if (stringExpression.startsWith("D_Sefl"))
            dSelfParse();
        else if (stringExpression.startsWith("S_OWNER"))
            sOwnerParse();
        else if (stringExpression.startsWith("D_OWNER"))
            dOwnerParse();
        else if (stringExpression.startsWith("S_ROLE"))
            sRoleParse();
        else if (stringExpression.startsWith("D_ROLE"))
            dRoleParse();
        else if (stringExpression.startsWith("S_REMOTE"))
            sRemoteParse();
        else if (stringExpression.startsWith("D_REMOTE"))
            dRemoteParse();
        else if (stringExpression.startsWith("S_LOCAL"))
            sLocalParse();
        else if (stringExpression.startsWith("D_LOCAL"))
            dLocalParse();
        else if (stringExpression.startsWith("S_MYCUSTOMIZER"))
            sMyCustomizerParse();
        else if (stringExpression.startsWith("D_MYCUSTOMIZER"))
            dMyCustomizerParse();
        else if (stringExpression.startsWith("S_INNERSPACE"))
            sInnerSpaceParse();
        else if (stringExpression.startsWith("D_INNERSPACE"))
            dInnerSpaceParse();
        else if (stringExpression.startsWith("S_OUTERSPACE"))
            sOuterSpaceParse();
        else if (stringExpression.startsWith("D_OUTERSPACE"))
            dOuterSpaceParse();
        else
            cannotParse();
    }

    void sBAddressParse() {
        type = S_BADDRESS;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();

        StringTokenizer st2 = new StringTokenizer(st.nextToken(),"./");
        address = new byte[4];
        address[0] = (byte)Integer.parseInt(st2.nextToken());
        address[1] = (byte)Integer.parseInt(st2.nextToken());
        address[2] = (byte)Integer.parseInt(st2.nextToken());
        address[3] = (byte)Integer.parseInt(st2.nextToken());

        st2 = new StringTokenizer(st.nextToken(),"./");
        mask = new byte[4];
        mask[0] = (byte)Integer.parseInt(st2.nextToken());
        mask[1] = (byte)Integer.parseInt(st2.nextToken());
        mask[2] = (byte)Integer.parseInt(st2.nextToken());
        mask[3] = (byte)Integer.parseInt(st2.nextToken());

        address[0] = (byte)(address[0] & mask[0]);
        address[1] = (byte)(address[1] & mask[1]);
        address[2] = (byte)(address[2] & mask[2]);
        address[3] = (byte)(address[3] & mask[3]);

        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void dBAddressParse() {
        type = D_BADDRESS;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();

        StringTokenizer st2 = new StringTokenizer(st.nextToken(),"./");
        address = new byte[4];
        address[0] = (byte)Integer.parseInt(st2.nextToken());
        address[1] = (byte)Integer.parseInt(st2.nextToken());
        address[2] = (byte)Integer.parseInt(st2.nextToken());
        address[3] = (byte)Integer.parseInt(st2.nextToken());

        st2 = new StringTokenizer(st.nextToken(),"./");
        mask = new byte[4];
        mask[0] = (byte)Integer.parseInt(st2.nextToken());
        mask[1] = (byte)Integer.parseInt(st2.nextToken());
        mask[2] = (byte)Integer.parseInt(st2.nextToken());
        mask[3] = (byte)Integer.parseInt(st2.nextToken());

        address[0] = (byte)(address[0] & mask[0]);
        address[1] = (byte)(address[1] & mask[1]);
        address[2] = (byte)(address[2] & mask[2]);
        address[3] = (byte)(address[3] & mask[3]);

        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void sAddressParse() {
        type = S_ADDRESS;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();

        StringTokenizer st2 = new StringTokenizer(st.nextToken(),"./");
        address = new byte[4];
        address[0] = (byte)Integer.parseInt(st2.nextToken());
        address[1] = (byte)Integer.parseInt(st2.nextToken());
        address[2] = (byte)Integer.parseInt(st2.nextToken());
        address[3] = (byte)Integer.parseInt(st2.nextToken());

        st2 = new StringTokenizer(st.nextToken(),"./");
        mask = new byte[4];
        mask[0] = (byte)Integer.parseInt(st2.nextToken());
        mask[1] = (byte)Integer.parseInt(st2.nextToken());
        mask[2] = (byte)Integer.parseInt(st2.nextToken());
        mask[3] = (byte)Integer.parseInt(st2.nextToken());

        address[0] = (byte)(address[0] & mask[0]);
        address[1] = (byte)(address[1] & mask[1]);
        address[2] = (byte)(address[2] & mask[2]);
        address[3] = (byte)(address[3] & mask[3]);

        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void dAddressParse() {
        type = D_ADDRESS;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();

        StringTokenizer st2 = new StringTokenizer(st.nextToken(),"./");
        address = new byte[4];
        address[0] = (byte)Integer.parseInt(st2.nextToken());
        address[1] = (byte)Integer.parseInt(st2.nextToken());
        address[2] = (byte)Integer.parseInt(st2.nextToken());
        address[3] = (byte)Integer.parseInt(st2.nextToken());

        st2 = new StringTokenizer(st.nextToken(),"./");
        mask = new byte[4];
        mask[0] = (byte)Integer.parseInt(st2.nextToken());
        mask[1] = (byte)Integer.parseInt(st2.nextToken());
        mask[2] = (byte)Integer.parseInt(st2.nextToken());
        mask[3] = (byte)Integer.parseInt(st2.nextToken());

        address[0] = (byte)(address[0] & mask[0]);
        address[1] = (byte)(address[1] & mask[1]);
        address[2] = (byte)(address[2] & mask[2]);
        address[3] = (byte)(address[3] & mask[3]);

        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void sServerNameParse() {
        type = S_SERVERNAME;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();

        serverName = st.nextToken();

        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void dServerNameParse() {
        type = D_SERVERNAME;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();

        serverName = st.nextToken();

        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void sAdminParse() {
        type = S_ADMIN;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();
        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void dAdminParse() {
        type = D_ADMIN;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();
        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void sSelfParse() {
        type = S_SELF;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();
        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void dSelfParse() {
        type = D_SELF;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();
        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void sOwnerParse() {
        type = S_OWNER;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();

        userID = st.nextToken();

        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void dOwnerParse() {
        type = D_OWNER;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();

        userID = st.nextToken();

        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void sRoleParse() {
        type = S_ROLE;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();

        role = st.nextToken();

        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void dRoleParse() {
        type = D_ROLE;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();

        role = st.nextToken();

        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void sRemoteParse() {
        type = S_REMOTE;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();
        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void dRemoteParse() {
        type = D_REMOTE;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();
        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void sLocalParse() {
        type = S_LOCAL;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();
        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void dLocalParse() {
        type = D_LOCAL;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();
        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void sMyCustomizerParse() {
        type = S_MYCUSTOMIZER;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();
        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void dMyCustomizerParse() {
        type = D_MYCUSTOMIZER;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();
        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void sInnerSpaceParse() {
        type = S_INNERSPACE;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();
        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void dInnerSpaceParse() {
        type = D_INNERSPACE;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();
        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void sOuterSpaceParse() {
        type = S_OUTERSPACE;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();
        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void dOuterSpaceParse() {
        type = D_OUTERSPACE;
        StringTokenizer st = new StringTokenizer(stringExpression);
        st.nextToken();
        target = (st.nextToken().equals("ACCEPT")?ACCEPT:DENY);
    }
    void cannotParse() {
        type = CAN_NOT_PARSE;
    }

    int check(Message m) {
        return check(m,null);
    }

    int check(Message m,Elm e) {
        switch (type) {
        case S_BADDRESS:
            return sBAddressCheck(m);
        case D_BADDRESS:
            return dBAddressCheck(m);
        case S_ADDRESS:
            return sAddressCheck(m);
        case D_ADDRESS:
            return dAddressCheck(m);
        case S_SERVERNAME:
            return sServerNameCheck(m);
        case D_SERVERNAME:
            return dServerNameCheck(m);
        case S_ADMIN:
            return sAdminCheck(m);
        case D_ADMIN:
            return dAdminCheck(m);
        case S_SELF:
            return sSelfCheck(m,e);
        case D_SELF:
            return dSelfCheck(m,e);
        case S_OWNER:
            return sOwnerCheck(m);
        case D_OWNER:
            return dOwnerCheck(m);
        case S_ROLE:
            return sRoleCheck(m);
        case D_ROLE:
            return dRoleCheck(m);
        case S_REMOTE:
            return sRemoteCheck(m);
        case D_REMOTE:
            return dRemoteCheck(m);
        case S_LOCAL:
            return sLocalCheck(m);
        case D_LOCAL:
            return dLocalCheck(m);
        case S_MYCUSTOMIZER:
            return sMyCustomizerCheck(m,e);
        case D_MYCUSTOMIZER:
            return dMyCustomizerCheck(m,e);
        case S_INNERSPACE:
            return sInnerSpaceCheck(m,e);
        case D_INNERSPACE:
            return dInnerSpaceCheck(m,e);
        case S_OUTERSPACE:
            return sOuterSpaceCheck(m,e);
        case D_OUTERSPACE:
            return dOuterSpaceCheck(m,e);
        }
        return NO_MATCH;
    }

    byte aTmp[] = new byte[4];

    int sBAddressCheck(Message m) {
        if (m.sender.server.bridge == null)
            return NO_MATCH;
        aTmp[0] = (byte)(m.sender.server.bridge[0] & mask[0]);
        aTmp[1] = (byte)(m.sender.server.bridge[1] & mask[1]);
        aTmp[2] = (byte)(m.sender.server.bridge[2] & mask[2]);
        aTmp[3] = (byte)(m.sender.server.bridge[3] & mask[3]);
        
        if ((aTmp[3] == address[3])&&
            (aTmp[2] == address[2])&&
            (aTmp[1] == address[1])&&
            (aTmp[0] == address[0]))
            return target;
        else
            return NO_MATCH;
    }
    int dBAddressCheck(Message m) {
        if (m.receiver.server.bridge == null)
            return NO_MATCH;
        aTmp[0] = (byte)(m.receiver.server.bridge[0] & mask[0]);
        aTmp[1] = (byte)(m.receiver.server.bridge[1] & mask[1]);
        aTmp[2] = (byte)(m.receiver.server.bridge[2] & mask[2]);
        aTmp[3] = (byte)(m.receiver.server.bridge[3] & mask[3]);
        
        if ((aTmp[3] == address[3])&&
            (aTmp[2] == address[2])&&
            (aTmp[1] == address[1])&&
            (aTmp[0] == address[0]))
            return target;
        else
            return NO_MATCH;
    }
    int sAddressCheck(Message m) {
        aTmp[0] = (byte)(m.sender.server.address[0] & mask[0]);
        aTmp[1] = (byte)(m.sender.server.address[1] & mask[1]);
        aTmp[2] = (byte)(m.sender.server.address[2] & mask[2]);
        aTmp[3] = (byte)(m.sender.server.address[3] & mask[3]);
        
        if ((aTmp[3] == address[3])&&
            (aTmp[2] == address[2])&&
            (aTmp[1] == address[1])&&
            (aTmp[0] == address[0]))
            return target;
        else
            return NO_MATCH;
    }
    int dAddressCheck(Message m) {
        aTmp[0] = (byte)(m.receiver.server.address[0] & mask[0]);
        aTmp[1] = (byte)(m.receiver.server.address[1] & mask[1]);
        aTmp[2] = (byte)(m.receiver.server.address[2] & mask[2]);
        aTmp[3] = (byte)(m.receiver.server.address[3] & mask[3]);
        
        if ((aTmp[3] == address[3])&&
            (aTmp[2] == address[2])&&
            (aTmp[1] == address[1])&&
            (aTmp[0] == address[0]))
            return target;
        else
            return NO_MATCH;
    }
    int sServerNameCheck(Message m) {
        if (m.sender.server.serverName.equals(serverName))
            return target;
        else
            return NO_MATCH;
    }
    int dServerNameCheck(Message m) {
        if (m.receiver.server.serverName.equals(serverName))
            return target;
        else
            return NO_MATCH;
    }
    int sAdminCheck(Message m) {
        if (m.sender.role.equals("admin"))
            return target;
        else
            return NO_MATCH;
    }
    int dAdminCheck(Message m) {
        if (m.receiver.role.equals("admin"))
            return target;
        else
            return NO_MATCH;
    }
    int sSelfCheck(Message m,Elm e) {
        if (m.sender.equals(e))
            return target;
        else
            return NO_MATCH;
    }
    int dSelfCheck(Message m,Elm e) {
        if (m.receiver.equals(e))
            return target;
        else
            return NO_MATCH;
    }
    int sOwnerCheck(Message m) {
        if (m.sender.owner.equals(userID))
            return target;
        else
            return NO_MATCH;
    }
    int dOwnerCheck(Message m) {
        if (m.receiver.owner.equals(userID))
            return target;
        else
            return NO_MATCH;
    }
    int sRoleCheck(Message m) {
        if (m.sender.role.equals(role))
            return target;
        else
            return NO_MATCH;
    }
    int dRoleCheck(Message m) {
        if (m.receiver.role.equals(role))
            return target;
        else
            return NO_MATCH;
    }
    int sRemoteCheck(Message m) {
        if (!(m.sender.server.equals(ElmVE.elmVE.thisServer)))
            return target;
        else
            return NO_MATCH;
    }
    int dRemoteCheck(Message m) {
        if (!(m.receiver.server.equals(ElmVE.elmVE.thisServer)))
            return target;
        else
            return NO_MATCH;
    }
    int sLocalCheck(Message m) {
        if (m.sender.server.equals(ElmVE.elmVE.thisServer))
            return target;
        else
            return NO_MATCH;
    }
    int dLocalCheck(Message m) {
        if (m.receiver.server.equals(ElmVE.elmVE.thisServer))
            return target;
        else
            return NO_MATCH;
    }
    int sMyCustomizerCheck(Message m,Elm e) {
        Iterator i = e.customizerStack.getCustomizers().iterator();
        while (i.hasNext()) {
            ElmStub es = (ElmStub)i.next();
            if (m.sender.equals(e))
                return target;
        }
        return NO_MATCH;
    }
    int dMyCustomizerCheck(Message m,Elm e) {
        Iterator i = e.customizerStack.getCustomizers().iterator();
        while (i.hasNext()) {
            ElmStub es = (ElmStub)i.next();
            if (m.receiver.equals(e))
                return target;
        }
        return NO_MATCH;
    }
    int sInnerSpaceCheck(Message m,Elm e) {
        String s1 = m.sender.path.substring(0,m.sender.path.lastIndexOf('/'));
        String s2 = e.stub.path.substring(0,e.stub.path.lastIndexOf('/'));
        if (s1.equals(s2))
            return target;
        else
            return NO_MATCH;
    }
    int dInnerSpaceCheck(Message m,Elm e) {
        String s1 = m.receiver.path.substring(0,m.sender.path.lastIndexOf('/'));
        String s2 = e.stub.path.substring(0,e.stub.path.lastIndexOf('/'));
        if (s1.equals(s2))
            return target;
        else
            return NO_MATCH;
    }
    int sOuterSpaceCheck(Message m,Elm e) {
        String s1 = m.sender.path.substring(0,m.sender.path.lastIndexOf('/'));
        String s2 = e.stub.path.substring(0,e.stub.path.lastIndexOf('/'));
        if (!s1.equals(s2))
            return target;
        else
            return NO_MATCH;
    }
    int dOuterSpaceCheck(Message m,Elm e) {
        String s1 = m.receiver.path.substring(0,m.sender.path.lastIndexOf('/'));
        String s2 = e.stub.path.substring(0,e.stub.path.lastIndexOf('/'));
        if (!s1.equals(s2))
            return target;
        else
            return NO_MATCH;
    }

    public String toString() {
        return stringExpression;
    }
}
