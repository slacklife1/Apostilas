package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.clients.*;
import javax.swing.*;
import java.awt.event.*;

public class ETextField2DUI extends Elm2DUI implements ActionListener {
    private static final long serialVersionUID = 1L;
    protected JTextField textField;

    public void init(Elm2DData d) {
        textField = new JTextField();
        add(textField);
        textField.addActionListener(this);
        textField.setText(d.getString(0));
    }

    public void update(Elm2DData d) {
        textField.setText(d.getString(0));
    }

    public void actionPerformed(ActionEvent ae) {
        send(makeOrder("catchETextFieldEvent",textField.getText()));
    }
}
