package ac.hiu.j314.elmve.graph;

import ac.hiu.j314.elmve.clients.*;
import java.awt.*;
import java.util.*;

public class GraphLightBG extends ElmLightBG {
    ArrayList lines;

    public void init(ElmLightData d) {
        lines = (ArrayList)d.get(0);
    }

    public void update(ElmLightData d) {
        lines = (ArrayList)d.get(0);
    }

    public void paint(Graphics g) {
        Rectangle r = g.getClipBounds();
        g.setColor(Color.lightGray);
        g.fillRect(0,0,r.width,r.height);
        if (lines == null)
            return;
        g.setColor(Color.black);
        Iterator i = lines.iterator();
        Point p1;
        Point p2;
        while (i.hasNext()) {
            Line l = (Line)i.next();
            p1 = placeToPoint(l.getHeadPlace());
            p2 = placeToPoint(l.getTailPlace());
            l.paint(g,p1,p2);
        }
    }
}
