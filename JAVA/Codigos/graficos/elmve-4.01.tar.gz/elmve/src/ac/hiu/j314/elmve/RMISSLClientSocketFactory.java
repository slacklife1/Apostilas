package ac.hiu.j314.elmve;

import java.io.*;
import java.net.*;
import java.rmi.server.*;
import javax.net.ssl.*;

class RMISSLClientSocketFactory implements RMIClientSocketFactory,
                                           Serializable {
    private static final long serialVersionUID = 1L;

    public Socket createSocket(String host, int port) throws IOException {
        SSLSocketFactory factory =
            (SSLSocketFactory)SSLSocketFactory.getDefault();
        SSLSocket socket = (SSLSocket)factory.createSocket(host, port);
        return socket;
    }
}
