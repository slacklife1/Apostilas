package ac.hiu.j314.elmve;

import ac.hiu.j314.elmve.clients.*;
import ac.hiu.j314.elmve.graph.*;
import java.io.*;
import java.util.*;


public abstract class ElmClient extends Elm implements NeverSave,
                                                       Runnable {
    public static final Serializable NULL = Elm.NULL;
    public static final Serializable OK = Elm.OK;
    public static final Serializable ERROR = Elm.ERROR;

    volatile protected ElmStub avatar;

    public ElmClient() {
        ElmVE.elmVE.defaultAvatarClass = avatarClass();
        reader = new BufferedReader(new InputStreamReader(System.in));
        Thread t = new Thread(this);
        t.setName("Elm1DClient");
        t.setPriority(1);
        t.start();
    }

    protected String elm2DUIClass(){return "ac.hiu.j314.elmve.ui.EHidden2DUI";}
    protected String elm3DUIClass(){return "ac.hiu.j314.elmve.ui.EHidden3DUI";}
    protected String elmLightUIClass()
        {return "ac.hiu.j314.elmve.ui.EHiddenLightUI";}

    public void get2DUIData(MyRequest r) {
        send(makeReply(r,NULL));
    }
    public void get2DUIRepaintData(MyRequest r) {
        send(makeReply(r,NULL));
    }
    public void get3DUIData(MyRequest r) {
        send(makeReply(r,NULL));
    }
    public void get3DUIRepaintData(MyRequest r) {
        send(makeReply(r,NULL));
    }
    public void getLightUIData(MyRequest r) {
        send(makeReply(r,NULL));
    }
    public void getLightUIRepaintData(MyRequest r) {
        send(makeReply(r,NULL));
    }

    public abstract void startProcessing(MyOrder o);

    public void bindAvatar(MyOrder o) {
        avatar = o.getElm(0);
    }

    public void processCommand(String command) throws ElmException {
        command = command.trim();
        if (command.startsWith("###")) {
            command = command.substring(3);
            Request r = W.makeRequestFromString(this,command);
            receive(r,"receiveReply",NULL);
            send(r);
        } else {
            Request r = makeRequest(avatar,"processStringCommand",command);
            receive(r,"receiveReply",NULL);
            send(r);
        }
    }

    void preparation() {
        MyRequest r = makeMyRequest("passwordInput",NULL);
        receive(r,"preparation2",NULL);
        send(r);
    }
    public void preparation2(ReplySet rs) {
        if (rs.get(0,0)==NULL) {
            System.out.println("canceled");
            ElmVE.elmVE.quit();
            return;
        }
        String userName = rs.getString(0,0);
        String password = rs.getString(0,1);
        if (ElmVE.elmVE.elmConfig.checkLogin(userName,password)) {
            prepareAvatar(userName,password);
	    send(makeMyOrder("startProcessing",NULL));
        } else {
            MyRequest r = makeMyRequest("passwordInput",NULL);
            receive(r,"preparation2",NULL);
            send(r);
        }
    }

    void prepareAvatar(String userName,String password) {
        if (ElmVE.elmVE.elmConfig.checkLogin(userName,password)) {
            ElmUser eu = ElmVE.elmVE.elmConfig.getUser(userName);
            if (eu==null) {
                System.out.println("??? gaha ???.");
                ElmVE.elmVE.quit();
                return;
            }
            ElmStub es = W.makeElmAgent(eu);
            ElmStub home = getElm(eu.home);
            if (home==null)
                home = getElm("/");
            home.elm.addElm(es);
            avatar = es;

            ((ElmAvatar)avatar.elm).client = this.stub;
//            ((ElmAvatar)avatar.elm).home = ElmVE.elmVE.thisServer.uri;
            avatar.role = eu.role;
            avatar.elm.init();
        } else {
            System.out.println("canceled");
            ElmVE.elmVE.quit();
            return;
        }
    }

    public abstract void configPreference(MyRequest r);

    MyRequest myRequestPreservation;
    public void configPreferenceText(MyRequest r) {
        if (!BAT.check(r,this)) {
            System.out.println("some illegal access?");
            send(makeReply(r,NULL));
            return;
        }
        myRequestPreservation = r;
        send(makeMyOrder("configPreferenceTextMain0",NULL));
    }
    public void configPreferenceTextMain0(MyOrder o) {
        String msg = "*** configuration ***\n"
                   + "  0: save and exit.\n"
                   + "  1: do not save and exit.\n"
                   + "  2: admin password.\n"
                   + "  3: account config.\n"
                   + "  4: public spaces config.\n"
                   + "  5: Elm classpath.\n"
                   + "  6: public Classes config.\n"
                   + "  7: import ACL config.\n"
                   + "  8: export ACL config.\n"
                   + "  9: bridge config.\n"
                   + " 10: proxy config.\n"
                   + " 11: extJars config.\n"
                   + "input number >> ";

        Request r = makeRequest("getLines",msg);
        receive(r,"configPreferenceTextMain1",NULL);
        send(r);
    }
    public void configPreferenceTextMain1(ReplySet rs) {
        int inputNumber;
        try {
            inputNumber = Integer.parseInt(rs.getString(0,0));
        } catch(NumberFormatException e) {
            inputNumber = -1;
        }

        ElmConfig elmConfig = ElmVE.elmVE.elmConfig;
        switch (inputNumber) {
        case 0:
            elmConfig.saveAsXML(ElmVE.elmVE.confFile);
            send(makeReply(myRequestPreservation,NULL));
            break;
        case 1:
            send(makeReply(myRequestPreservation,NULL));
            break;
        case 2:
            send(makeMyOrder("adminPasswordText",NULL));
            break;
        case 3:
            ArrayList accounts = elmConfig.getAccountsData();
            send(makeMyOrder("accountConfigText",accounts));
            break;
        case 4:
            ArrayList path = elmConfig.getPubSpacesData();
            send(makeMyOrder("publicSpacesConfigText",path));
            break;
        case 5:
            ArrayList elmPath = elmConfig.getElmClassPath();
            send(makeMyOrder("elmClasspathText",elmPath));
            break;
        case 6:
            ArrayList pubPath = elmConfig.getPubClassData();
            send(makeMyOrder("publicClassConfigText",pubPath));
            break;
        case 7:
            Serializable data[] = elmConfig.getInACLData();
            send(makeMyOrder("importACLConfigText",data));
            break;
        case 8:
            data = elmConfig.getOutACLData();
            send(makeMyOrder("exportACLConfigText",data));
            break;
        case 9:
            send(makeMyOrder("bridgeConfigText",NULL));
            break;
        case 10:
            send(makeMyOrder("proxyConfigText",NULL));
            break;
        case 11:
            send(makeMyOrder("extJarsConfigText",NULL));
            break;
        default:
            send(makeMyOrder("configPreferenceTextMain0",NULL));
        }
    }
    public void adminPasswordText(MyOrder o) {
        Serializable msg[] = new String[3];
        msg[0] = "*** Admin configure ***\n"
               + "Input user ID: ";
        msg[1] = "Input admin password: ";
        msg[2] = "Input admin password again: ";
        Request r = makeRequest("getLines",msg);
        receive(r,"adminPasswordText2",NULL);
        send(r);
    }
    public void adminPasswordText2(ReplySet rs) {
        String s0 = rs.getString(0,0);
        String s1 = rs.getString(0,1);
        String s2 = rs.getString(0,2);

        if (!s1.equals(s2)) {
            System.out.println("once again!");
            send(makeMyOrder("adminPasswordText",NULL));
            return;
        }
        ElmVE.elmVE.elmConfig.setAdmin(new ElmUser("admin",s0,s1,"admin",
                                                   "ac.hiu.j314.elmve.ElmAvatar",
                                                   "/"));
        System.out.println("set!");
        send(makeMyOrder("configPreferenceTextMain0",NULL));
    }

    public void accountConfigText(MyOrder o) {
        ArrayList accounts = (ArrayList)o.get(0);
        String msg = "*** account configuration ***\n"
                   + "  0: set account and back.\n"
                   + "  1: cancel and back.\n"
                   + "  2: print account.\n"
                   + "  3: add.\n"
                   + "  4: remove.\n"
                   + "input number >> ";
        Request r = makeRequest("getLines",msg);
        receive(r,"accountConfigText2",accounts);
        send(r);
    }
    public void accountConfigText2(ReplySet rs) {
//      ArrayList<ElmUser> accounts = (ArrayList<ElmUser>)rs.get(0); // <-- 無検査キャスト
        ArrayList al = (ArrayList)rs.get(0);
        ArrayList<ElmUser> accounts = new ArrayList<ElmUser>();
        for (Object o : al)
            accounts.add((ElmUser)o);
        
        int inputNumber;
        try {
            inputNumber = Integer.parseInt(rs.getString(0,0));
        } catch(Exception e) {
            inputNumber = -1;
        }
        switch (inputNumber) {
        case 0:
            ElmVE.elmVE.elmConfig.setAccountsData(accounts);
            send(makeMyOrder("configPreferenceTextMain0",NULL));
            break;
        case 1:
            send(makeMyOrder("configPreferenceTextMain0",NULL));
            break;
        case 2:
            int n=0;
            Iterator i = accounts.iterator();
            while (i.hasNext()) {
                ElmUser eu = (ElmUser)i.next();
                System.out.println(""+n+":  "+eu.name+":"+eu.userID+":"
                                   +eu.password+":"+eu.role+":"
                                   +eu.avatar+":"+eu.home);
                n++;
            }
            send(makeMyOrder("accountConfigText",accounts));
            break;
        case 3:
            String msg = "input user accountData\n"
                       + "format   name:userID:password:role:avatar:home\n"
                       + "input >> ";
            Request r = makeRequest("getLines",msg);
            receive(r,"accountAddConfigText",accounts);
            send(r);
            break;
        case 4:
            msg = "input number >> ";
            r = makeRequest("getLines",msg);
            receive(r,"accountRemoveConfigText",accounts);
            send(r);
            break;
        default:
            send(makeMyOrder("configPreferenceTextMain0",NULL));
        }
    }
    public void accountAddConfigText(ReplySet rs) {
//      ArrayList<ElmUser> accounts = (ArrayList<ElmUser>)rs.get(0); // <-- 無検査キャスト
        ArrayList al = (ArrayList)rs.get(0);
        ArrayList<ElmUser> accounts = new ArrayList<ElmUser>();
        for (Object o : al)
            accounts.add((ElmUser)o);
        String s = rs.getString(0,0);
        StringTokenizer st = new StringTokenizer(s,":");
        ElmUser eu = null;
        try {
            eu = new ElmUser(st.nextToken(),st.nextToken(),
                             st.nextToken(),st.nextToken(),
                             st.nextToken(),st.nextToken());
            accounts.add(eu);
        } catch(Exception eeeee) {
            eeeee.printStackTrace();
        }
        send(makeMyOrder("accountConfigText",accounts));
    }
    public void accountRemoveConfigText(ReplySet rs) {
        ArrayList accounts = (ArrayList)rs.get(0);
        String s = rs.getString(0,0);
        try {
            accounts.remove(Integer.parseInt(s));
        } catch(Exception e) {;}
        send(makeMyOrder("accountConfigText",accounts));
    }

    public void publicSpacesConfigText(MyOrder o) {
        ArrayList path = (ArrayList)o.get(0);
        String msg = "*** public spaces configure ***\n"
                   + "  0: set path and back.\n"
                   + "  1: cancel and back.\n"
                   + "  2: print spaces.\n"
                   + "  3: add.\n"
                   + "  4: remove.\n"
                   + "input number >> ";
        Request r = makeRequest("getLines",msg);
        receive(r,"publicSpacesConfigText2",path);
        send(r);
    }
    public void publicSpacesConfigText2(ReplySet rs) {
//      ArrayList<String> path = (ArrayList<String>)rs.get(0); // <-- 無検査キャスト
        ArrayList al = (ArrayList)rs.get(0);
        ArrayList<String> path = new ArrayList<String>();
        for (Object o : al)
            path.add((String)o);
        
        int inputNumber;
        try {
            inputNumber = Integer.parseInt(rs.getString(0,0));
        } catch(Exception e) {
            inputNumber = -1;
        }
        switch (inputNumber) {
        case 0:
            ElmVE.elmVE.elmConfig.setPubSpacesData(path);
            send(makeMyOrder("configPreferenceTextMain0",path));
            break;
        case 1:
            send(makeMyOrder("configPreferenceTextMain0",path));
            break;
        case 2:
            int n=0;
            Iterator i = path.iterator();
            while (i.hasNext()) {
                System.out.println(""+n+": "+(String)i.next());
                n++;
            }
            send(makeMyOrder("publicSpacesConfigText",path));
            break;
        case 3:
            String msg = "input path >> ";
            Request r = makeRequest("getLines",msg);
            receive(r,"publicSpacesAddConfigText",path);
            send(r);
            break;
        case 4:
            msg = "input number >> ";
            r = makeRequest("getLines",msg);
            receive(r,"publicSpacesRemoveConfigText",path);
            send(r);
            break;
        default:
            send(makeMyOrder("configPreferenceTextMain0",NULL));
        }
    }
    public void publicSpacesAddConfigText(ReplySet rs) {
//      ArrayList<String> path = (ArrayList<String>)rs.get(0); // <-- 無検査キャスト
        ArrayList al = (ArrayList)rs.get(0);
        ArrayList<String> path = new ArrayList<String>();
        for (Object o : al)
            path.add((String)o);
        path.add(rs.getString(0,0));
        send(makeMyOrder("publicSpacesConfigText",path));
    }
    public void publicSpacesRemoveConfigText(ReplySet rs) {
        ArrayList path = (ArrayList)rs.get(0);
        try {
            path.remove(Integer.parseInt(rs.getString(0,0)));
        } catch(Exception e) {;}
        send(makeMyOrder("publicSpacesConfigText",path));
    }

    public void elmClasspathText(MyOrder o) {
        ArrayList elmPath = (ArrayList)o.get(0);
        String msg = "*** Elm classpath configure ***\n"
                   + "  0: set path and back.\n"
                   + "  1: cancel and back.\n"
                   + "  2: print paths.\n"
                   + "  3: add.\n"
                   + "  4: remove.\n"
                   + "input number >> ";
        Request r = makeRequest("getLines",msg);
        receive(r,"elmClasspathText2",elmPath);
        send(r);
    }
    public void elmClasspathText2(ReplySet rs) {
        ArrayList<String> elmPath = (ArrayList<String>)rs.get(0);
        int inputNumber;
        try {
            inputNumber = Integer.parseInt(rs.getString(0,0));
        } catch(Exception e) {
            inputNumber = -1;
        }
        switch (inputNumber) {
        case 0:
            ElmVE.elmVE.elmConfig.setElmClassPath(elmPath);
            send(makeMyOrder("configPreferenceTextMain0",NULL));
            break;
        case 1:
            send(makeMyOrder("configPreferenceTextMain0",NULL));
            break;
        case 2:
            int n=0;
            Iterator i = elmPath.iterator();
            while (i.hasNext()) {
                System.out.println(""+n+": "+(String)i.next());
                n++;
            }
            send(makeMyOrder("elmClasspathText",elmPath));
            break;
        case 3:
            String msg = "input path >> ";
            Request r = makeRequest("getLines",msg);
            receive(r,"elmClasspathAddText",elmPath);
            send(r);
            break;
        case 4:
            msg = "input number >> ";
            r = makeRequest("getLines",msg);
            receive(r,"elmClasspathRemoveText",elmPath);
            send(r);
            break;
        default:
            send(makeMyOrder("configPreferenceTextMain0",NULL));
        }
    }
    public void elmClasspathAddText(ReplySet rs) {
        ArrayList<String> elmPath = (ArrayList<String>)rs.get(0);
        String p = rs.getString(0,0);
        elmPath.add(p);
        send(makeMyOrder("elmClasspathText",elmPath));
    }
    public void elmClasspathRemoveText(ReplySet rs) {
        ArrayList elmPath = (ArrayList)rs.get(0);
        String n = rs.getString(0,0);
        try {
            elmPath.remove(Integer.parseInt(n));
        } catch(Exception e) {;}
        send(makeMyOrder("elmClasspathText",elmPath));
    }

    public void publicClassConfigText(MyOrder o) {
        ArrayList pubPath = (ArrayList)o.get(0);
        String msg = "*** public spaces configure ***"
                   + "  0: set path and back.\n"
                   + "  1: cancel and back.\n"
                   + "  2: print path.\n"
                   + "  3: add.\n"
                   + "  4: remove.\n"
                   + "input number >> ";
        Request r = makeRequest("getLines",msg);
        receive(r,"publicClassConfigText2",pubPath);
        send(r);
    }
    public void publicClassConfigText2(ReplySet rs) {
        ArrayList<String> pubPath = (ArrayList<String>)rs.get(0);
        int inputNumber;
        try {
            inputNumber = Integer.parseInt(rs.getString(0,0));
        } catch(Exception e) {
            inputNumber = -1;
        }
        switch (inputNumber) {
        case 0:
            ElmVE.elmVE.elmConfig.setPubClassData(pubPath);
            send(makeMyOrder("configPreferenceTextMain0",NULL));
            break;
        case 1:
            send(makeMyOrder("configPreferenceTextMain0",NULL));
            break;
        case 2:
            int n=0;
            Iterator i = pubPath.iterator();
            while (i.hasNext()) {
                System.out.println(""+n+": "+(String)i.next());
                n++;
            }
            send(makeMyOrder("publicClassConfigText",pubPath));
            break;
        case 3:
            String msg = "input path >> ";
            Request r = makeRequest("getLines",msg);
            receive(r,"publicClassConfigAddText",pubPath);
            send(r);
            break;
        case 4:
            msg = "input number >> ";
            r = makeRequest("getLines",msg);
            receive(r,"publicClassConfigRemoveText",pubPath);
            send(r);
            break;
        default:
            send(makeMyOrder("configPreferenceTextMain0",NULL));
        }
    }
    public void publicClassConfigAddText(ReplySet rs) {
        ArrayList<String> pubPath = (ArrayList<String>)rs.get(0);
        pubPath.add(rs.getString(0,0));
        send(makeMyOrder("publicClassConfigText",pubPath));
    }
    public void publicClassConfigRemoveText(ReplySet rs) {
        ArrayList pubPath = (ArrayList)rs.get(0);
        try {
            pubPath.remove(Integer.parseInt(rs.getString(0,0)));
        } catch(Exception e) {;}    
        send(makeMyOrder("publicClassConfigText",pubPath));
    }

    public void importACLConfigText(MyOrder o) {
        Serializable data[] = o.getAll();
        String msg = "*** import ACL configure ***\n"
                   + "  0: set ACL and back.\n"
                   + "  1: cancel and back.\n"
                   + "  2: print ACL.\n"
                   + "  3: change default policy.\n"
                   + "  4: add.\n"
                   + "  5: remove.\n"
                   + "input number >> ";
        Request r = makeRequest("getLines",msg);
        receive(r,"importACLConfigText2",data);
        send(r);
    }
    public void importACLConfigText2(ReplySet rs) {
        Serializable data[] = rs.getAll();
int dp = ((Integer)data[0]).intValue();
boolean defaultPolicy = (dp==ElmACE.ACCEPT?true:false);
ArrayList acl = (ArrayList)data[1];
        int inputNumber;
        try {
            inputNumber = Integer.parseInt(rs.getString(0,0));
        } catch(Exception e) {
            inputNumber = -1;
        }
        switch (inputNumber) {
        case 0:
            Integer ii
                = new Integer((defaultPolicy?ElmACE.ACCEPT:ElmACE.DENY));
            Serializable s[] = {ii,acl};
            ElmVE.elmVE.elmConfig.setInACLData(s);
            send(makeMyOrder("configPreferenceTextMain0",NULL));
            break;
        case 1:
            send(makeMyOrder("configPreferenceTextMain0",NULL));
            break;
        case 2:
            System.out.println("default policy="+defaultPolicy);
            int n=0;
            Iterator i = acl.iterator();
            while (i.hasNext()) {
                System.out.println(""+n+": "+((ElmACE)i.next()).toString());
                n++;
            }
            send(makeMyOrder("importACLConfigText",data));
            break;
        case 3:
            String msg = "input default policy.(true|false): ";
            Request r = makeRequest("getLines",msg);
            receive(r,"importACLConfigDefText",data);
            send(r);
            break;
        case 4:
            msg = "input ACE >> ";
            r = makeRequest("getLines",msg);
            receive(r,"importACLConfigAddText",data);
            send(r);
            break;
        case 5:
            msg = "input number >> ";
            r = makeRequest("getLines",msg);
            receive(r,"importACLConfigRemoveText",data);
            send(r);
            break;
        default:
            send(makeMyOrder("configPreferenceTextMain0",NULL));
        }
    }
    public void importACLConfigDefText(ReplySet rs) {
        Serializable data[] = rs.getAll();
        String s = rs.getString(0,0);
        int i = (Boolean.valueOf(s).booleanValue()?ElmACE.ACCEPT:ElmACE.DENY);
        send(makeMyOrder("importACLConfigText",i,data[1]));
    }
    public void importACLConfigAddText(ReplySet rs) {
        Serializable data[] = rs.getAll();
        ArrayList<ElmACE> acl = (ArrayList<ElmACE>)data[1];
        String s = rs.getString(0,0);
        ElmACE ace = new ElmACE(s);
        if (ace.type == ElmACE.CAN_NOT_PARSE) {
            System.out.println("Can not parse!!! canseled.");
        } else {
            acl.add(ace);
        }
        send(makeMyOrder("importACLConfigText",data[0],acl));
    }
    public void importACLConfigRemoveText(ReplySet rs) {
        Serializable data[] = rs.getAll();
        ArrayList acl = (ArrayList)data[1];
        String s = rs.getString(0,0);
        try {
            acl.remove(Integer.parseInt(s));
        }catch(Exception e) {;}
        send(makeMyOrder("importACLConfigText",data[0],acl));
    }

    public void exportACLConfigText(MyOrder o) {
        Serializable data[] = o.getAll();
        String msg = "*** export ACL configure ***\n"
                   + "  0: set ACL and back.\n"
                   + "  1: cancel and back.\n"
                   + "  2: print ACL.\n"
                   + "  3: change default policy.\n"
                   + "  4: add.\n"
                   + "  5: remove.\n"
                   + "input number >> ";
        Request r = makeRequest("getLines",msg);
        receive(r,"exportACLConfigText2",data);
        send(r);
    }
    public void exportACLConfigText2(ReplySet rs) {
        Serializable data[] = rs.getAll();
int dp = ((Integer)data[0]).intValue();
boolean defaultPolicy = (dp==ElmACE.ACCEPT?true:false);
ArrayList acl = (ArrayList)data[1];
        int inputNumber;
        try {
            inputNumber = Integer.parseInt(rs.getString(0,0));
        } catch(Exception e) {
            inputNumber = -1;
        }
        switch (inputNumber) {
        case 0:
            Integer ii
                = new Integer((defaultPolicy?ElmACE.ACCEPT:ElmACE.DENY));
            Serializable s[] = {ii,acl};
            ElmVE.elmVE.elmConfig.setOutACLData(s);
            send(makeMyOrder("configPreferenceTextMain0",NULL));
            break;
        case 1:
            send(makeMyOrder("configPreferenceTextMain0",NULL));
            break;
        case 2:
            System.out.println("default policy="+defaultPolicy);
            int n=0;
            Iterator i = acl.iterator();
             while (i.hasNext()) {
                System.out.println(""+n+": "+((ElmACE)i.next()).toString());
                n++;
            }
            send(makeMyOrder("exportACLConfigText",data));
            break;
        case 3:
            String msg = "input default policy.(true|false): ";
            Request r = makeRequest("getLines",msg);
            receive(r,"exportACLConfigDefText",data);
            send(r);
            break;
        case 4:
            msg = "input ACE >> ";
            r = makeRequest("getLines",msg);
            receive(r,"exportACLConfigAddText",data);
            send(r);
            break;
        case 5:
            msg = "input number >> ";
            r = makeRequest("getLines",msg);
            receive(r,"exportACLConfigRemoveText",data);
            send(r);
            break;
        default:
            send(makeMyOrder("configPreferenceTextMain0",NULL));
        }
    }
    public void exportACLConfigDefText(ReplySet rs) {
        Serializable data[] = rs.getAll();
        String s = rs.getString(0,0);
        int i = (Boolean.valueOf(s).booleanValue()?ElmACE.ACCEPT:ElmACE.DENY);
        send(makeMyOrder("exportACLConfigText",i,data[1]));
    }
    public void exportACLConfigAddText(ReplySet rs) {
        Serializable data[] = rs.getAll();
        ArrayList<ElmACE> acl = (ArrayList<ElmACE>)data[1];
        String s = rs.getString(0,0);
        ElmACE ace = new ElmACE(s);
        if (ace.type == ElmACE.CAN_NOT_PARSE) {
            System.out.println("Can not parse!!! canseled.");
        } else {
            acl.add(ace);
        }
        send(makeMyOrder("exportACLConfigText",data[0],acl));
    }
    public void exportACLConfigRemoveText(ReplySet rs) {
        Serializable data[] = rs.getAll();
        ArrayList acl = (ArrayList)data[1];
        String s = rs.getString(0,0);
        try {
            acl.remove(Integer.parseInt(s));
        } catch(Exception e) {;}
        send(makeMyOrder("exportACLConfigText",data[0],acl));
    }

    public void bridgeConfigText(MyOrder o) {
        String msg = "input bridge IP address\n"
                   + "format (xxx.xxx.xxx.xxx)\n"
                   + "if you do not need bridge, format (none)\n"
                   + "input >> ";
        Request r = makeRequest("getLines",msg);
        receive(r,"bridgeConfigText2",NULL);
        send(r);
    }
    public void bridgeConfigText2(ReplySet rs) {
        String s = rs.getString(0,0);
        ElmVE.elmVE.elmConfig.setBridgeData(s);
        send(makeMyOrder("configPreferenceTextMain0",NULL));
    }

    public void proxyConfigText(MyOrder o) {
        Serializable msg[] = new String[6];
        msg[0] = "input proxy data\n"
               + "proxySet(true|false)>> ";
        msg[1] = "proxyHost>> ";
        msg[2] = "proxyPort>> ";
        msg[3] = "ftpProxySet(true|false)>> ";
        msg[4] = "ftpProxyHost>> ";
        msg[5] = "ftpProxyPort>> ";
        Request r = makeRequest("getLines",msg);
        receive(r,"proxyConfigText2",NULL);
        send(r);
    }
    public void proxyConfigText2(ReplySet rs) {
        String p[] = new String[6];
        p[0] = rs.getString(0,0);
        p[1] = rs.getString(0,1);
        p[2] = rs.getString(0,2);
        p[3] = rs.getString(0,3);
        p[4] = rs.getString(0,4);
        p[5] = rs.getString(0,5);
        ElmVE.elmVE.elmConfig.setProxyData(p);
        send(makeMyOrder("configPreferenceTextMain0",NULL));
    }

    public void extJarsConfigText(MyOrder o) {
        String msg = "*** ExtJars configure ***\n"
                   + "  0: cancel and back.\n"
                   + "  1: print ExtJars.\n"
                   + "  2: add.\n"
                   + "  3: remove.\n"
                   + "input number >> ";
        Request r = makeRequest("getLines",msg);
        receive(r,"extJarsConfigText2",NULL);
        send(r);
    }
    public void extJarsConfigText2(ReplySet rs) {
        int inputNumber;
        try {
            inputNumber = Integer.parseInt(rs.getString(0,0));
        } catch(Exception e) {
            inputNumber = -1;
        }
        switch (inputNumber) {
        case 0:
            send(makeMyOrder("configPreferenceTextMain0",NULL));
            break;
        case 1:
            String extJarsDirString = null;
            if (ElmVE.elmVE.extJarsDir.startsWith("file:"))
                extJarsDirString = ElmVE.elmVE.extJarsDir.substring(5);
            else
                extJarsDirString = ElmVE.elmVE.extJarsDir;
            File extJarsDir = new File(extJarsDirString);
            String extJars[] = extJarsDir.list();
            for (int i=0;i<extJars.length;i++)
                System.out.println(""+i+": "+extJars[i]);
            send(makeMyOrder("extJarsConfigText",NULL));
            break;
        case 2:
            String msg = "input path >> ";
            Request r = makeRequest("getLines",msg);
            receive(r,"extJarsAddConfigText",NULL);
            send(r);
            break;
        case 3:
            msg = "input the jarfile >> ";
            r = makeRequest("getLines",msg);
            receive(r,"extJarsRemoveConfigText",NULL);
            send(r);
            break;
        default:
            send(makeMyOrder("configPreferenceTextMain0",NULL));
        }
    }
    public void extJarsAddConfigText(ReplySet rs) {
        try{
            File input = new File(rs.getString(0,0));
            String extJarsDirString = null;
            if (ElmVE.elmVE.extJarsDir.startsWith("file:"))
                extJarsDirString = ElmVE.elmVE.extJarsDir.substring(5);
            else
                extJarsDirString = ElmVE.elmVE.extJarsDir;
            File output = new File(extJarsDirString+W.sepa
                                   +input.getName());
            FileInputStream fis = new FileInputStream(input);
            FileOutputStream fos = new FileOutputStream(output);
            byte buf[]=new byte[256];
            int len;
            while((len=fis.read(buf))!=-1)
                fos.write(buf,0,len);
            fos.flush();
            fos.close();
            fis.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
        send(makeMyOrder("extJarsConfigText",NULL));
    }
    public void extJarsRemoveConfigText(ReplySet rs) {
        try {
            String rmFile = rs.getString(0,0);
            String extJarsDirString = null;
            if (ElmVE.elmVE.extJarsDir.startsWith("file:"))
                extJarsDirString = ElmVE.elmVE.extJarsDir.substring(5);
            else
                extJarsDirString = ElmVE.elmVE.extJarsDir;
            File f = new File(extJarsDirString+W.sepa+rmFile);
            f.delete();
        } catch(Exception e) {
            e.printStackTrace();
        }
        send(makeMyOrder("extJarsConfigText",NULL));
    }

    protected void configPreferenceGUI(MyRequest r) {
        if (!BAT.check(r,this)) {
            System.out.println("some illegal access?");
            send(makeReply(r,NULL));
            return;
        }
        int result = ConfigDialog.showConfigDialog(null,ElmVE.elmVE.elmConfig);
        if (result==0)
            ElmVE.elmVE.elmConfig.saveAsXML(ElmVE.elmVE.confFile);
        send(makeReply(r,NULL));
    }

    public abstract void passwordInput(MyRequest r);
    public void passwordInputText(MyRequest r) {
        if ((avatar!=null)&&(!r.sender.equals(avatar))) {
            send(makeReply(r,NULL));
            return;
        }
        Serializable msg[] = new String[2];
        msg[0] = "To cancel login, just push Enter key 2 times.\n"
	       + "Input user name: ";
        msg[1] = "Input password: ";
        Request rr = makeRequest("getLines",msg);
        receive(rr,"passwordInputText2",r);
        send(rr);
    }
    public void passwordInputText2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);
        String userName = rs.getString(0,0).trim();
        String password = rs.getString(0,1).trim();
        if (userName.equals("") && password.equals(""))
            send(makeReply(r,NULL));
        else
            send(makeReply(r,userName,password));
    }

    public void passwordInputGUI(MyRequest r) {
        if ((avatar!=null)&&(!r.sender.equals(avatar))) {
            send(makeReply(r,NULL));
            return;
        }
        int result = PasswordDialog.showPasswordDialog();
        if (result==0) {
            send(makeReply(r,(Serializable[])PasswordDialog.getPasswordData()));
            return;
        } else {
            send(makeReply(r,NULL));
            return;
        }
    }

    protected String avatarClass(){return "ac.hiu.j314.elmve.ElmAvatar";}

    public final void receiveReply(ReplySet rs) {
        Serializable reply = rs.get(0,0);
        if (reply instanceof CustomizerData)
            processCustomizerData((CustomizerData)reply);
        else {
            printReply(rs);
        }
    }

    protected abstract void printReply(ReplySet rs);

    public abstract void printMessage(Order o);

    public abstract void refresh(Request r);

    void processCustomizerData(CustomizerData cd) {
        makeElmInside(cd.className,cd.elm.name);
        ElmStub ec = getElm(stub.name+"/"+cd.elm.name);
        ((ElmCustomizer)ec.elm).setClient(this.stub);
        ((ElmCustomizer)ec.elm).setElm(cd.elm);
        ((ElmCustomizer)ec.elm).setAvatar(avatar);
        send(makeMyOrder(ec,"startProcessing",cd.data));
    }

    public abstract void close();

//    public void relayMessage(Elm elm,String methodName,Serializable args[]) {
//        send(makeOrder(elm,methodName,args));
//    }

    public void relayOrder(ElmStub e,String methodName,
                              Serializable args[]) {
        send(makeMyOrder(avatar,"relayOrder",e,methodName,args));
    }

    public void relayMyOrder(ElmStub e,String methodName,
                                Serializable args[]) {
        send(makeMyOrder(avatar,"relayMyOrder",
                                e,methodName,args));
    }

//----------------------------------------------------------------------

    protected void quit() {
        ElmVE.elmVE.quit();
    }

    protected void kill() {
        ElmVE.elmVE.kill();
    }

//----------------------------------------------------------------------

    public void showConnectDialog(MyRequest r) {
        SocketsData headSData = (SocketsData)r.get(0);
        SocketsData tailSData = (SocketsData)r.get(1);

        ConnectDialog.showConnectDialog(null,headSData,tailSData);
        Serializable c[] = ConnectDialog.getCData();
        send(makeReply(r,c));
    }

    void setAvatarToStartPlace(String sp) {
        send(makeMyOrder("setAvatarToStartPlace1",sp));
    }

    public void setAvatarToStartPlace1(MyOrder o) {
        String sp = o.getString(0);
        if (avatar == null) {
            send(makeMyOrder("setAvatarToStartPlace1",sp));
        } else {
            Request r = makeRequest(avatar,"cd",sp);
            receive(r,"setAvatarToStartPlace2",NULL);
            send(r);
        }
    }

    public void setAvatarToStartPlace2(ReplySet rs) {
        ;
    }
//---------------------------------

    BufferedReader reader;
    ArrayList<Request> reqs = new ArrayList<Request>();
    Request currentRequest = null;
    int nextRetCount;
    Serializable ret[];

    public void getLines(Request r) {
        if (currentRequest==null) {
            currentRequest = r;
            nextRetCount = 0;
            ret = new Serializable[currentRequest.getArgCount()];
            String s = currentRequest.getString(nextRetCount);
            System.out.print(s);
        } else {
            reqs.add(0,r);
        }
    }

    public void returnLine(MyOrder o) {
        if (currentRequest!=null) {
            ret[nextRetCount] = o.getString(0);
            nextRetCount++;
            if (nextRetCount==ret.length) {
                send(makeReply(currentRequest,ret));
                if (reqs.size()==0) {
                    currentRequest = null;
                } else {
                    currentRequest = (Request)reqs.get(0);
                    nextRetCount = 0;
                    ret = new Serializable[currentRequest.getArgCount()];
                    reqs.remove(0);
                    String s = currentRequest.getString(nextRetCount);
                    System.out.print(s);
                }
            } else {
                String s = currentRequest.getString(nextRetCount);
                System.out.print(s);
            }
        }
    }

    public void run() {
        while (true) {
            String command = null;
            try {
                command = reader.readLine();
                if (command==null) {//???????????????
                    System.out.println("Text input disabled.");
                    return;         //???????????????
                }
                command.trim();
            } catch (Exception e) {
                e.printStackTrace();
                break;
            }
            send(makeMyOrder("returnLine",command));
        }
    }

//---------------------------------

//    BufferedReader reader;
//    public void getLines(Request r) {
//        String questions[] = new String[r.getArgCount()];
//        String answers[] = new String[r.getArgCount()];
//        for (int i=0;i<questions.length;i++) {
//            questions[i] = r.getString(i);
//        }
//        for (int i=0;i<questions.length;i++) {
//            System.out.print(questions[i]);
//            String inputLine = null;
//            try {
//                inputLine = reader.readLine();
//            } catch(Exception e) {
//                inputLine = null;
//            }
//            if (inputLine == null) {
//                System.out.println("????gaha????");
//                answers[i] = "????gaha????";
//            } else {
//                answers[i] = inputLine;
//            }
//        }
//        send(makeReply(r,answers));
//    }
}
