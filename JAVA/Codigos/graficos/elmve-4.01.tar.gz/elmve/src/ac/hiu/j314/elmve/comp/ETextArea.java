package ac.hiu.j314.elmve.comp;

import ac.hiu.j314.elmve.*;

public class ETextArea extends Elm {
    private static final long serialVersionUID = 1L;
    protected String text = "          ";

    protected String elm2DUIClass()
        {return "ac.hiu.j314.elmve.ui.ETextArea2DUI";}

    public void get2DUIData(MyRequest r) {
        send(makeReply(r,text));
    }
    public void get2DUIRepaintData(MyRequest r) {
        send(makeReply(r,text));
    }

    public void catchETextAreaEvent(Order o) {
        text = o.getString(0);
System.out.println("ETextArea.catchETextAreaEvent()."+text);
    }
}
