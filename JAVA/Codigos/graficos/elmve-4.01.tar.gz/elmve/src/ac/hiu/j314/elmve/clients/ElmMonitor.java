package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import java.util.*;
import java.io.*;
import com.sun.image.codec.jpeg.*;

//class ElmMonitor extends JComponent {
class ElmMonitor extends JPanel {
    private static final long serialVersionUID = 1L;
    protected ElmClient client;
    protected Elm2DBG backGround = null;
    protected Hashtable<ElmStub,JComponent> uiHash;

    ElmMonitor(ElmClient client) {
        super();
        this.client = client;
        setLayout(new BorderLayout());
        uiHash = new Hashtable<ElmStub,JComponent>();
    }

    public Dimension getPreferredSize() {
        return new Dimension(400,400);
    }

    public void processElm2DPacket(Elm2DPacket elm2DPacket,ElmEditor editor) {
        if (elm2DPacket.backGround != null)
            if (elm2DPacket.backGround.type == Elm2DData.NEW)
                resetBackground(elm2DPacket.backGround,editor);
            else if (elm2DPacket.backGround.type == Elm2DData.UPDATE)
                updateBackground(elm2DPacket.backGround);
        Iterator i = elm2DPacket.eachUI.iterator();
        while (i.hasNext()) {
            Elm2DData elm2DData = (Elm2DData)i.next();
            if (elm2DData == null)
                continue;
            else if (elm2DData.type == Elm2DData.NEW)
                addNewUI(elm2DData);
            else if (elm2DData.type == Elm2DData.OLD)
                delOldUI(elm2DData);
            else if (elm2DData.type == Elm2DData.UPDATE)
                updateUI(elm2DData);
        }
        double xyz[] = new double[3];
        elm2DPacket.camera.place.get(xyz);
        backGround.setCenX(xyz[0]);
        backGround.setCenY(xyz[1]);
doLayout();
repaint();
    }

public void doLayout() {
super.doLayout();
if (backGround != null)
((JComponent)backGround).doLayout();
}

    protected void resetBackground(Elm2DData elm2DData,ElmEditor editor) {
        if ((editor != null) && (backGround != null)) {
            ((Component)backGround).removeMouseListener(editor.myMouseAdapter);
            ((Component)backGround).removeMouseMotionListener(editor.myMouseMotionAdapter);
        }
        backGround = elm2DData.makeBG();
        if (editor != null) {
            ((Component)backGround).addMouseListener(editor.myMouseAdapter);
            ((Component)backGround).addMouseMotionListener(editor.myMouseMotionAdapter);
        }
        removeAll();
        add((JComponent)backGround,"Center");
        backGround.setPlace(elm2DData.place);
        backGround.setElm(elm2DData.elm);
        backGround.init(elm2DData);
        uiHash.clear();
doLayout();
repaint();
    }

    protected void updateBackground(Elm2DData elm2DData) {
        backGround.setPlace(elm2DData.place);
        backGround.setElm(elm2DData.elm);
        backGround.update(elm2DData);
doLayout();
repaint();
    }

    public void addNewUI(Elm2DData elm2DData) {
        Elm2DUI ui = elm2DData.makeUI();
        JComponent c = (JComponent)ui;
        uiHash.put(elm2DData.elm,c);
        ui.setPPM(backGround.getPPM());
        ((JComponent)backGround).add(c);
        ui.setElm(elm2DData.elm);
        ui.setClient(client);
        ui.init(elm2DData);
doLayout();
repaint();
    }

    public void delOldUI(Elm2DData elm2DData) {
        JComponent c = uiHash.get(elm2DData.elm);
        if (c == null)
            return;
        ((JComponent)backGround).remove(c);
        uiHash.remove(elm2DData.elm);
doLayout();
repaint();
    }

    public void updateUI(Elm2DData elm2DData) {
        Elm2DUI ui = (Elm2DUI)uiHash.get(elm2DData.elm);
        if (ui == null) {
            System.out.println("ElmMonitor.updateUI(). ???");
            return;
        }
        ui.setPlace(elm2DData.place);
        ui.setElm(elm2DData.elm);
        ui.update(elm2DData);
doLayout();
repaint();
    }

    public Elm2DBG getBackGround() {
        return backGround;
    }

    public Elm2DUI getElmAt(int x,int y) {
        return backGround.getElm2DUIAt(x,y);
    }

    public Place pointToPlace(int x,int y) {
        return backGround.pointToPlace(x,y);
    }

    public Place pointToPlace(Point p) {
        return backGround.pointToPlace(p);
    }

    public void placeToPoint(Place pl,Point po) {
        backGround.placeToPoint(pl,po);
    }

    public Point placeToPoint(Place p) {
        return backGround.placeToPoint(p);
    }

    public Point placeToPoint(double x,double y) {
        return backGround.placeToPoint(x,y);
    }

    public void expand() {
        double ppm = backGround.getPPM();
        backGround.setPPM(2.0*ppm);
        doLayout();
        repaint();
    }

    public void reduce() {
        double ppm = backGround.getPPM();
        backGround.setPPM(0.5*ppm);
        doLayout();
        repaint();
    }

    public void move(Place p) {
//while (backGround == null);
        double pp[] = new double[3];
        p.get(pp);
        backGround.setCenX(pp[0]);
        backGround.setCenY(pp[1]);
        repaint();
    }

    public void north() {
        double cenY = backGround.getCenY();
        backGround.setCenY(cenY + 200.0/backGround.getPPM());
        doLayout();
        repaint();
    }

    public void south() {
        double cenY = backGround.getCenY();
        backGround.setCenY(cenY - 200.0/backGround.getPPM());
        doLayout();
        repaint();
    }

    public void west() {
        double cenX = backGround.getCenX();
        backGround.setCenX(cenX - 200.0/backGround.getPPM());
        doLayout();
        repaint();
    }

    public void east() {
        double cenX = backGround.getCenX();
        backGround.setCenX(cenX + 200.0/backGround.getPPM());
        doLayout();
        repaint();
    }

    public void saveImage(File file) throws IOException {
        int w = getWidth();
        int h = getHeight();
        BufferedImage bi = new BufferedImage(w,h,BufferedImage.TYPE_INT_RGB);
        Graphics g = bi.getGraphics();
        paint(g);
        FileOutputStream out = new FileOutputStream(file);
        JPEGImageEncoder e = JPEGCodec.createJPEGEncoder(out);
        e.encode(bi);
        out.close();
    }

    public Graphics getMonitorGraphics() {
        return ((Component)backGround).getGraphics();
    }
}
