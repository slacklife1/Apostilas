package ac.hiu.j314.elmve;

import java.rmi.*;
import java.io.*;

public class ServerControl {
    public static void main(String args[]) {
        try {
            File f = new File("/etc/elmve/elmKeystore");
            if (f.isFile()) {
                System.setProperty("javax.net.ssl.trustStore",
                                   f.getAbsolutePath());
            }

            if (args.length != 1) {
                error();
            }
            if (args[0].equals("stop")) {
                String names[] = Naming.list("//localhost/");
                for (int i=0;i<names.length;i++) {
                    Remote r = Naming.lookup(names[i]);
                    if (r instanceof RemoteElmVE) {
                        ((RemoteElmVE)r).stopServer();
                    }
                }
            } else if (args[0].equals("stopBridge")) {
                String names[] = Naming.list("//localhost/");
                for (int i=0;i<names.length;i++) {
                    Remote r = Naming.lookup(names[i]);
                    if (r instanceof RemoteElmBridge) {
                        ((RemoteElmBridge)r).stopBridge();
                    }
                }
            } else {
                error();
            }
        } catch(Exception e) {
            System.out.println("ServerControl.main()");
            System.out.println("error?");
        }
    }

    static void error() {
        System.out.println("USAGE: java ac.hiu.j314.elmve.ServerControl [stop|stopBridge]");
        System.exit(0);
    }
}
