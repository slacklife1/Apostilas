package ac.hiu.j314.elmve.clients;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.*;
import java.net.*;

public class BuildTimeWindow {
    JFrame window;

    public BuildTimeWindow(String versionTextFile) {
        window = new JFrame("version");
        window.getContentPane().setLayout(new java.awt.BorderLayout());
        JScrollPane pane = new JScrollPane();
        JViewport port = pane.getViewport();
        JEditorPane editor = new JEditorPane();
        port.add(editor);
        window.getContentPane().add(pane);
        window.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                window.setVisible(false);
            }
        });
        editor.setContentType("text/plane");
        try {
//          URL url = ClassLoader.getSystemResource(versionTextFile);
            URL url = new URL(versionTextFile);
            editor.setPage(url);
        } catch(Exception e) {
            editor.setText("no version ???");
        }
        window.setSize(300,100);
        window.setVisible(true);
    }
}
