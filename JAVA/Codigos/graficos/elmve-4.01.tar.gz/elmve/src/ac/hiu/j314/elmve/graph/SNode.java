package ac.hiu.j314.elmve.graph;

import ac.hiu.j314.elmve.*;
import java.util.*;
import java.io.*;
import org.w3c.dom.*;

public class SNode extends Elm {
    private static final long serialVersionUID = 1L;
    public static final int HEAD=0;
    public static final int TAIL=1;
    public static final int BOTH=2;

    protected ArrayList<ElmStub> nodes;
    protected ArrayList<Integer> directions;

    public SNode() {
        nodes = new ArrayList<ElmStub>();
        directions = new ArrayList<Integer>();
    }

    public void add(Order o) {
        nodes.add(o.getElm(0));
        directions.add((Integer)o.get(1));
        repaint();
    }

    public void del(Order o) {
        ElmStub n = o.getElm(0);
        int i = nodes.indexOf(n);
        if (i>=0) {
            nodes.remove(i);
            directions.remove(i);
            repaint();
        }
    }

    public void connect(MyOrder o) {
        ElmStub n = o.getElm(0);
        int d = o.getInt(1);
        int i = nodes.indexOf(n);
        if ((i>=0)&&(d==((Integer)directions.get(i)).intValue())) {
            nodes.remove(i);
            directions.remove(i);
        } else {
            nodes.add(n);
            directions.add(new Integer(d));
        }
        repaint();
    }

    protected ElmSet getOutNodes() {
        ElmSet ret = new ElmSet();
        Iterator i = nodes.iterator();
        Iterator j = directions.iterator();
        while (i.hasNext()) {
            ElmStub n = (ElmStub)i.next();
            int d = ((Integer)j.next()).intValue();
            if (d==TAIL) {
                ret.add(n);
            }
        }
        return ret;
    }

    protected ElmSet getInNodes() {
        ElmSet ret = new ElmSet();
        Iterator i = nodes.iterator();
        Iterator j = directions.iterator();
        while (i.hasNext()) {
            ElmStub n = (ElmStub)i.next();
            int d = ((Integer)j.next()).intValue();
            if (d==HEAD) {
                ret.add(n);
            }
        }
        return ret;
    }

    protected ArrayList getNodes() {
        return (ArrayList)nodes.clone();
    }

    public void getLines(MyRequest r) {
        ArrayList<SLine> ret = new ArrayList<SLine>();
        Iterator i = nodes.iterator();
        Iterator j = directions.iterator();
        while (i.hasNext()) {
            ElmStub n = (ElmStub)i.next();
            int d = ((Integer)j.next()).intValue();
            if (d==HEAD)
                ret.add(new SLine(this.getPlace(),getPlace(n),true));
            else if (d==TAIL)
                ret.add(new SLine(getPlace(n),this.getPlace(),true));
            else
                ret.add(new SLine(this.getPlace(),getPlace(n),false));
        }
        send(makeReply(r,ret));
    }

    protected void saveExtension(Document d,Element e) {
        Element ee = W.makeElementDOM(d,"Links");
        W.addChildDOM(e,ee);
        Iterator i = nodes.iterator();
        Iterator j = directions.iterator();
        while (i.hasNext()) {
            ElmStub n = (ElmStub)i.next();
            int di = ((Integer)j.next()).intValue();
            Element eee = W.makeElementDOM(d,"link");
            W.addChildDOM(ee,eee);
            W.addAttrDOM(d,eee,"elmID",""+n.getElmID());
            W.addAttrDOM(d,eee,"direction",
                         ""+(di==BOTH?"BOTH":(di==HEAD?"HEAD":"TAIL")));
        }
    }
    protected void loadExtension(Element e,LoadedElmSet elmSet) {
        Element ee = W.getChildByTagNameDOM(e,"Links");
        ArrayList al = W.getChildrenByTagNameDOM(ee,"link");
        Iterator i = al.iterator();
        while (i.hasNext()) {
            Element eee = (Element)i.next();
            long elmID = Long.parseLong(W.getAttrDataDOM(eee,"elmID"));
            String di = W.getAttrDataDOM(eee,"direction");
            int d=(di.equals("BOTH")?BOTH:(di.equals("HEAD")?HEAD:TAIL));
            nodes.add(elmSet.getElm(elmID));
            directions.add(new Integer(d));
        }
    }

    public String toSaveString() {
        StringBuffer sb = new StringBuffer();
        sb.append(super.toSaveString());
        sb.append("// number of links\n");
        sb.append(""+nodes.size()+"\n");
        sb.append("// linked nodes\n");
        Iterator i = nodes.iterator();
        Iterator j = directions.iterator();
        while (i.hasNext()) {
            ElmStub n = (ElmStub)i.next();
            int d = ((Integer)j.next()).intValue();
            sb.append("'"+n.getName()+"' "+d+" ");
        }
        sb.append("\n");
        return sb.toString();
    }

    public void loadFromText(ElmStreamTokenizer f_in) throws IOException {
        super.loadFromText(f_in);
        nodes = new ArrayList<ElmStub>();
        directions = new ArrayList<Integer>();
        int n = f_in.nextInt();
        for (int i=0;i<n;i++) {
            String name = f_in.nextString();
            int d = f_in.nextInt();
            ElmStub node = getElm(name);
            nodes.add(node);
            directions.add(new Integer(d));
        }
    }

    public void repaint() {
        super.repaint();
        send(makeMyOrder(getElm("."),"repaint",NULL));
    }

    public void disposeConnection(MyOrder o) {
        ElmStub n = o.getElm(0);
        int i = nodes.indexOf(n);
        nodes.remove(i);
        directions.remove(i);
    }

    protected void dispose() {
        Iterator i = nodes.iterator();
        while (i.hasNext()) {
            ElmStub n = (ElmStub)i.next();
            send(makeMyOrder(n,"disposeConnection",this.getStub()));
        }
        super.dispose();
    }
}
