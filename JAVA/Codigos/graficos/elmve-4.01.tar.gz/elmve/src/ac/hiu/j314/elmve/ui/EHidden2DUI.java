package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.clients.*;
import java.awt.*;

public class EHidden2DUI extends Elm2DUI {
    private static final long serialVersionUID = 1L;
    protected Dimension size;

    public EHidden2DUI() {
         size = new Dimension(1,1);
    }

    public void init(Elm2DData d) {
    }

    public void update(Elm2DData d) {
    }

    public Dimension getPreferredSize() {
        return size;
    }

    public void paint(Graphics g) {
    }
}
