package ac.hiu.j314.elmve.clients;

import java.io.*;

public class UIMyOrder extends UIMessage {
    private static final long serialVersionUID = 1L;

    public UIMyOrder(String methodName,Serializable arguments[]) {
        super(methodName,arguments);
    }
}
