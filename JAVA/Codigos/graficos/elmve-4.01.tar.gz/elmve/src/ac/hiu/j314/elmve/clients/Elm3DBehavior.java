package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;
import java.util.*;
import javax.media.j3d.*;
import javax.vecmath.*;

public class Elm3DBehavior extends Behavior {
    TransformGroup tg;
    Transform3D t;
    Quat4d nextQ = new Quat4d();
    Vector3d nextV = new Vector3d();
    Quat4d nowQ = new Quat4d();
    Vector3d nowV = new Vector3d();

    public Elm3DBehavior() {
    }

    public void setTransform(TransformGroup tg,Transform3D t) {
        this.tg = tg;
        this.t = t;
    }

    public void initialize() {
        WakeupOnElapsedTime w = new WakeupOnElapsedTime(100);
        wakeupOn(w);
    }

    public void processStimulus(Enumeration criteria) {
        t.get(nowQ,nowV);

        nowQ.normalize();
        nowQ.interpolate(nextQ,0.2);
        nowQ.normalize();
        nowV.interpolate(nextV,0.2);

        t.set(nowQ,nowV,1.0);
        tg.setTransform(t);
        WakeupOnElapsedTime w = new WakeupOnElapsedTime(100);
        wakeupOn(w);
    }

    public void move(Place p,Rotation r) {
        nextV.set(W.toVector3d(p));
        nextQ.set(W.toQuat4d(r));
        nextQ.normalize();
    }
}
