package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;
import java.io.*;
import javax.swing.*;
import javax.swing.text.*;
import java.awt.event.*;

public class ElmLightClient extends ElmClient implements ActionListener {
    private static final long serialVersionUID = 1L;
    protected JFrame frame;
    protected Box baseBox;
    protected ElmCanvas canvas;
    protected LightMenu menu;
    protected LightMenuItem fileMenuItem;
    protected LightMenuItem loadMenuItem;
    protected LightMenuItem saveMenuItem;
    protected LightMenuItem quitMenuItem;
    protected LightMenuItem killMenuItem;
    protected LightMenuItem configMenuItem;
    protected LightMenuItem consoleMenuItem;
    protected LightMenuItem helpMenuItem;
    protected LightMenuItem buildTimeMenuItem;
    protected LightMenuItem aboutMenuItem;
    protected JTextField commandLine;
    protected JTextArea textArea;
    protected JFrame consoleFrame;
    protected JTextArea consoleTextArea;
    protected JButton clearConsoleButton;
    protected String menus[];
    protected boolean b1 = true;

    protected MyKeyAdapter keyAdapter;

    protected void init() {
        super.init();
        initOwnEngine("ElmLightClient",1);
    }

    public void startProcessing(MyOrder o) {
        keyAdapter = new MyKeyAdapter();
        frame = new JFrame();
        frame.addKeyListener(keyAdapter);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                try {
                    quit();
                    try{Thread.sleep(3000);}catch(Exception ee){;}
                    kill();
                    try{Thread.sleep(3000);}catch(Exception ee){;}
                    System.exit(1);
                } catch(Exception e) {
                    e.printStackTrace();
                }
            }
        });
        baseBox = Box.createVerticalBox();
        frame.getContentPane().add(baseBox);
        makeCanvas();
        makeMenu();
        if (b1) {
            makeInputArea();
        }
        makeTextArea();

        consoleFrame = new JFrame("Console");
        Box b = Box.createVerticalBox();
        consoleTextArea = new JTextArea(20,60);
        consoleTextArea.setEditable(false);
        JScrollPane sp = new JScrollPane(consoleTextArea);
        b.add(sp);
        clearConsoleButton = new JButton("Clear");
        clearConsoleButton.addActionListener(this);
        b.add(clearConsoleButton);
        consoleFrame.getContentPane().add(b);
        consoleFrame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                consoleFrame.setVisible(false);
            }
        });
        PrintStream systemOut = System.out;
        JTextAreaOutputStream jtaos = new JTextAreaOutputStream(consoleTextArea,systemOut);
        PrintStream ps = new PrintStream(jtaos,true);
        System.setOut(ps);
        System.setErr(ps);
        consoleFrame.pack();

        frame.pack();
        frame.setVisible(true);

        send(makeMyOrder(avatar,"gatherLightUIData",NULL));
    }

    public void bindAvatar(MyOrder o) {
        super.bindAvatar(o);
        send(makeMyOrder(avatar,"gatherLightUIData",NULL));
    }

    void makeMenu() {
        menu = new LightMenu();
        menu.setVisible(false);

        makeFileMenu();
        makeConfigMenu();
        makeConsoleMenu();
        makeHelpMenu();

        canvas.add(menu);
    }

    void makeFileMenu() {
        fileMenuItem = new LightMenuItem("File");
        loadMenuItem = new LightMenuItem("Load");
        saveMenuItem = new LightMenuItem("Save");
        quitMenuItem = new LightMenuItem("Quit");
        killMenuItem = new LightMenuItem("Kill");
        loadMenuItem.addActionListener(this);
        saveMenuItem.addActionListener(this);
        quitMenuItem.addActionListener(this);
        killMenuItem.addActionListener(this);
        fileMenuItem.add(loadMenuItem);
        fileMenuItem.add(saveMenuItem);
        fileMenuItem.add(quitMenuItem);
        fileMenuItem.add(killMenuItem);
        menu.add(fileMenuItem);
    }

    void makeConfigMenu() {
        configMenuItem = new LightMenuItem("Config");
        configMenuItem.addActionListener(this);
        menu.add(configMenuItem);
    }

    void makeConsoleMenu() {
        consoleMenuItem = new LightMenuItem("Console");
        consoleMenuItem.addActionListener(this);
        menu.add(consoleMenuItem);
    }

    void makeHelpMenu() {
        helpMenuItem = new LightMenuItem("Help");
        aboutMenuItem = new LightMenuItem("About");
        aboutMenuItem.addActionListener(this);
        helpMenuItem.add(aboutMenuItem);
        buildTimeMenuItem = new LightMenuItem("Build Time");
        buildTimeMenuItem.addActionListener(this);
        helpMenuItem.add(buildTimeMenuItem);
        menu.add(helpMenuItem);
    }

    void makeCanvas() {
        canvas = new ElmCanvas(this);
        canvas.addKeyListener(keyAdapter);
        baseBox.add(canvas);
    }

    void makeInputArea() {
        Box b = Box.createHorizontalBox();
        commandLine = new JTextField();
        commandLine.addActionListener(this);
        b.add(commandLine);
        JButton catchButton = new JButton("Catch");
        catchButton.addKeyListener(keyAdapter);
        b.add(catchButton);
        baseBox.add(b);
    }

    void makeTextArea() {
        textArea = new JTextArea(7,40);
        textArea.setEditable(false);
        textArea.addKeyListener(keyAdapter);
        JScrollPane sp = new JScrollPane(textArea);
        baseBox.add(sp);
    }

    public void printReply(ReplySet rs) {
        if (textArea!=null) {
            textArea.append(rs.toString()+"\n");
            Document d = textArea.getDocument();
            Position p = d.getEndPosition();
            Caret c = textArea.getCaret();
            c.setDot(p.getOffset());
        }
    }

    public void printMessage(Order o) {
        if (textArea!=null) {
            textArea.append(o.getString(0)+"\n");
            Document d = textArea.getDocument();
            Position p = d.getEndPosition();
            Caret c = textArea.getCaret();
            c.setDot(p.getOffset());
        }
    }

    public void actionPerformed(ActionEvent ae) {
        try {
            if (ae.getSource() == commandLine) {
                String command = commandLine.getText();
                commandLine.setText("");
                command = command.trim();
                processCommand(command);
//System.out.println(command);
            } else if (ae.getSource() == loadMenuItem) {
                showLoadDialog();
            } else if (ae.getSource() == saveMenuItem) {
                showSaveDialog();
            } else if (ae.getSource() == quitMenuItem) {
                processCommand("quit");
            } else if (ae.getSource() == killMenuItem) {
                processCommand("kill");
try{Thread.sleep(3000);}catch(Exception e){;}
System.exit(1);
            } else if (ae.getSource() == configMenuItem) {
                send(makeMyOrder(avatar,"configure",NULL));
            } else if (ae.getSource() == consoleMenuItem) {
                consoleFrame.setVisible(true);
            } else if (ae.getSource() == aboutMenuItem) {
                new ElmAbout();
            } else if (ae.getSource() == buildTimeMenuItem) {
                new BuildTimeWindow("x-res:///buildTime.txt");
            } else if (ae.getSource() == clearConsoleButton) {
                consoleTextArea.setText("");
            }
        } catch(ElmException e) {
            e.printStackTrace();
        }
    }

    void showLoadDialog() {
        JFileChooser chooser = new JFileChooser();
        int returnVal = chooser.showOpenDialog(frame);
        if (returnVal != JFileChooser.APPROVE_OPTION)
            return;
        try {
            processCommand("load "+chooser.getSelectedFile().getPath());
        } catch(ElmException ee) {
            ee.printStackTrace();
        }
    }

    void showSaveDialog() {
        String m = "Before saveing, You must\n"
                   +"be in Elm object which\n"
                   +"you will save.";
        int result = JOptionPane.showConfirmDialog(frame,m,"save",
                                                   JOptionPane.YES_NO_OPTION);
        if (result!=JOptionPane.YES_OPTION)
            return;

        JFileChooser chooser = new JFileChooser();
        int returnVal = chooser.showOpenDialog(frame);
        if (returnVal != JFileChooser.APPROVE_OPTION)
            return;
        try {
            processCommand("save . "+chooser.getSelectedFile().getPath());
        } catch (ElmException ee) {
            ee.printStackTrace();
        }
    }

    public void configPreference(MyRequest r) {
        super.configPreferenceGUI(r);
    }

    public void passwordInput(MyRequest r) {
        super.passwordInputGUI(r);
    }

    public void catchLightUIData(Request r) {
        ElmLightPacket elmLightPacket = (ElmLightPacket)r.get(0);
        canvas.processElmLightPacket(elmLightPacket);
        send(makeReply(r,NULL));
    }

    public void refresh(Request r) {
        send(makeMyOrder(avatar,"gatherLightUIData",NULL));
        send(makeReply(r,NULL));
    }

    public void processKeyPressed(KeyEvent e) {
        menu.processKeyEvent(e);
        if (menu.processed==true)
            return;
        try {
            switch (e.getKeyCode()) {
            case KeyEvent.VK_UP:
                processCommand("goNorth &");
                break;
            case KeyEvent.VK_DOWN:
                processCommand("goSouth &");
                break;
            case KeyEvent.VK_RIGHT:
                processCommand("goEast &");
                break;
            case KeyEvent.VK_LEFT:
                processCommand("goWest &");
                break;
            default:
                break;
            }
        } catch(ElmException ee) {
            ee.printStackTrace();
        }
    }

    public void processKeyReleased(KeyEvent e) {
    }

    public void processKeyTyped(KeyEvent e) {
    }

    class MyKeyAdapter extends KeyAdapter {
        public void keyPressed(KeyEvent e) {
            processKeyPressed(e);
        }
        public void keyReleased(KeyEvent e) {
            processKeyReleased(e);
        }
        public void keyTyped(KeyEvent e) {
            processKeyTyped(e);
        }
    }

    public void close() {
        if (frame!=null)
            frame.dispose();
    }

    void refreshElmLightCanvas() {
        send(makeMyOrder("refreshElmLightCanvas2",NULL),200);
    }
    public void refreshElmLightCanvas2(MyOrder o) {
        canvas.backGround.needPaint(true);
        send(makeMyOrder("refreshElmLightCanvas3",NULL),200);
    }
    public void refreshElmLightCanvas3(MyOrder o) {
        canvas.backGround.needPaint(true);
    }
}
