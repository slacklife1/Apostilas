package ac.hiu.j314.elmve;

import ac.hiu.j314.elmve.clients.*;
import ac.hiu.j314.elmve.graph.*;
import java.lang.reflect.*;
import java.util.*;
import java.io.*;
import java.net.*;
import org.w3c.dom.*;

public class ElmAvatar extends ElmAgent implements NeverSave {
    private static final long serialVersionUID = 1L;
    static final int TEXT_MODE = 0;
    static final int SWING_MODE = 1;
    static final int J3D_MODE = 2;

    protected ElmStub client;
    int mode = TEXT_MODE;
    int updateCounter = -100;
    int lastUpdateTime = -1;

    protected void init() {
        super.init();
        initOwnEngine("avatar",2);
        String filename = ElmVE.elmVE.avatarDir+W.sepa+getName();
        loadAvatarData(filename);
    }

    void loadAvatarData(String filename) {
        try {
            URL url = W.getResource(filename);
            InputStream is = url.openStream();
            loadAvatarData(is);
        } catch (Exception e) {
//            e.printStackTrace();
        }
    }

    void loadAvatarData(InputStream is) {
        try {
            Document d = W.loadDocumentFromInputStreamDOM(is);
            Element e = d.getDocumentElement();

            if (!e.getTagName().equals("avatarData")) {
                System.out.println("ElmAvatar.loadAvatarData(). Wrong data.");
                return;
            }

            loadAvatarData(e);
	} catch(Exception e) {
            e.printStackTrace();
        }
    }

    protected void loadAvatarData(Element e) {
        ;
    }

    protected void dispose() {
        super.dispose();
        String filename = ElmVE.elmVE.avatarDir+W.sepa+getName();
        saveAvatarData(filename);
    }

    void saveAvatarData(String filename) {
        try {
            if (filename.startsWith("file:"))
                filename = filename.substring(5);
            FileOutputStream fos
                = new FileOutputStream(filename);
            saveAvatarData(fos);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void saveAvatarData(OutputStream os) {
        try {
            Document d = W.makeEmptyDocumentDOM();
            Element e = W.makeElementDOM(d,"avatarData");
            W.addChildDOM(d,e);
            W.addLineFeedDOM(d,e);

            saveAvatarData(d,e);
            W.addLineFeedDOM(d,e);

            W.saveDocumentToOutputStreamDOM(d,os);
        } catch(Exception e) {
	    e.printStackTrace();
        }
    }

    protected void saveAvatarData(Document d,Element e) {
        ;
    }

    public void setHome(MyRequest r) {
        home = r.getString(0);
        send(makeReply(r,NULL));
    }

    public void setClient(MyRequest r) {
        client = r.getElm(0);
        send(makeReply(r,NULL));
    }

    protected void sendMsgToClient(String msg) {
        send(makeOrder(client,"printMessage",msg));
    }

    public void processStringCommand(Request r) {
        String command = r.getString(0);
        try {
            command = command.trim();
            Message m = W.makeMessageFromString(this,command);
            if (m instanceof Order) {
                send(m);
                send(makeReply(r,NULL));
            } else if (m instanceof Request) {
                receive((Request)m,"processStringCommand2",r);
                send(m);
            }
        } catch(ElmException e) {
            send(makeReply(r,"I can not process the command line("
                                    +command+")."));
        }
    }
    public void processStringCommand2(ReplySet rs) {
        Serializable args[] = rs.getReply(0).getAll();
        send(makeReply(rs.getRequest(0),args));
    }

    public void relayOrder(MyOrder o) {
        ElmStub e = o.getElm(0);
        String methodName = o.getString(1);
        Serializable args[] = (Serializable[])o.get(2);
        send(makeOrder(e,methodName,args));
    }

    public void relayMyOrder(MyOrder o) {
        ElmStub e = o.getElm(0);
        String methodName = o.getString(1);
        Serializable args[] = (Serializable[])o.get(2);
        send(makeMyOrder(e,methodName,args));
    }

    public void catchErrorLog(MyRequest r) {
        ElmVE.elmVE.addLogListener(this);
        send(makeReply(r,"catchErrorLog!"));
    }

    public void ignoreErrorLog(Request r) {
        ElmVE.elmVE.removeLogListener(this);
        send(makeReply(r,"ignoreErrorLog!"));
    }

    public void help(Request r) {
        StringBuffer sb = new StringBuffer();
        Class ac = this.getClass();
        Method m[] = ac.getMethods();
sb.append("--ElmAvatar--\n");
        for (int i=0;i<m.length;i++) {
            Class args[] = m[i].getParameterTypes();
            if (args.length!=1)
                continue;
            if ((args[0]==W.orderClass)||(args[0]==W.requestClass))
                sb.append(m[i].getName()+"\n");
        }
        if (parent != null) {
            ac = parent.getClass();
            m = ac.getMethods();
sb.append("--"+ac.getName()+"--\n");
            for (int i=0;i<m.length;i++) {
                Class args[] = m[i].getParameterTypes();
                if (args.length!=1)
                    continue;
                if ((args[0]==W.orderClass)||(args[0]==W.requestClass))
                    sb.append("#"+m[i].getName()+"\n");
            }
        }
        send(makeReply(r,sb.toString()));
    }

    public void cd(Request r) {
        String path = r.getString(0);
        
        ElmStub elm = getElm(path);
        if (elm == null) {
            send(makeReply(r,"I can not cd."));
            return;
        }
        Request req = makeRequest(ElmVE.elmVE.topElm,"transfer",
                                  this,parent,elm);
        receive(req,"cd2",r);
        send(req);
    }
    public void cd2(ReplySet rs) {
        send(makeReply(rs.getRequest(0),"Ok."));
        lastUpdateTime = -1;
        lastElms.remove(stub);
    }

    public void go(Request r) {
        String locationString = r.getString(0);
        MyRequest rr = makeMyRequest(client,"passwordInput",NULL);
        receive(rr,"go2",r,locationString);
        send(rr);
    }
    public void go2(ReplySet rs) {
        loginName = rs.getString(0,0);
        if (loginName==null) {
            send(makeReply(rs.getRequest(0),"canceled."));
            return;
        }
        password = rs.getString(0,1);
        Serializable args[] = {this,rs.getString(1)};
        send(makeMyOrder(getElm("/sys/transporter"),"transportAgent",args),100);
        send(makeReply(rs.getRequest(0),"transporting..."));
    }

    public void goHome(Request r) {
        MyRequest rr = makeMyRequest(client,"passwordInput",NULL);
        receive(rr,"goHome2",r);
        send(rr);
    }
    public void goHome2(ReplySet rs) {
        loginName = rs.getString(0,0);
        if (loginName==null) {
            send(makeReply(rs.getRequest(0),"canceled."));
            return;
        }
        password = rs.getString(0,1);
        Serializable args[] = {this,home,"/"};
        send(makeMyOrder(getElm("/sys/transporter"),"transportAgent",args),100);
        send(makeReply(rs.getRequest(0),"transporting..."));
    }

    public void relogin(Request r) {
        if (client.isLocal()) {
            MyRequest rr = makeMyRequest(client,"passwordInput",NULL);
            receive(rr,"relogin2",r);
            send(rr);
        } else {
            send(makeReply(r,"'relogin' can't use in remote server."));
        }
    }
    public void relogin2(ReplySet rs) {
        if (rs.get(0,0)==null) {
            send(makeReply(rs.getRequest(0),"canceled."));
            return;
        }
        loginName = rs.getString(0,0);
        password = rs.getString(0,1);
        if (loginName.equals(getName())) {
            send(makeReply(rs.getRequest(0),"same account."));
            return;
        }
        if (ElmVE.elmVE.elmConfig.checkLogin(loginName,password)) {
            Serializable args[] = {this,home,"/"};
            send(makeMyOrder(getElm("/sys/transporter"),"transportAgent",args),100);
            send(makeReply(rs.getRequest(0),"relogin."));
        } else {
            MyRequest rr = makeMyRequest(client,"passwordInput",NULL);
            receive(rr,"relogin2",rs.getRequest(0));
            send(rr);
        }
    }

    public void cat(Request r) {
        ElmStub e = null;
        if (r.getArgCount()==0)
            e = parent;
        else
            e = getElm(r.getString(0));
        String answer;
        if (e == null) {
            send(makeReply(r,"no such Elm."));
            return;
        }
        Request rr = makeRequest(e,"toString",NULL);
        receive(rr,"cat2",r);
        send(rr);
    }
    public void cat2(ReplySet rs) {
        String ans = rs.getString(0,0);
        send(makeReply(rs.getRequest(0),ans));
    }

    public void ls(Request r) {
        StringBuffer sb = new StringBuffer();
        ArrayList al = null;
        if (r.getArgCount()==0)
            al = getElms("*");
        else
            al = getElms(r.getString(0));
        if (al!=null) {
            Iterator i = al.iterator();
            while (i.hasNext()) {
                ElmStub es = (ElmStub)i.next();
                sb.append(es.getName());
                sb.append("(id="+es.elmID+")\n");
            }
        }
        send(makeReply(r,sb.toString()));
    }

    public void pwd(Request r) {
        String p = parent.elm.getPath();
        send(makeReply(r,p));
    }

    public void pfp(Request r) {
        send(makeReply(r,parent.elm.getFullPath()));
    }

    public void pidp(Request r) {
        send(makeReply(r,parent.elm.getIDPath()));
    }

    public void whereis(Request r) {
        String reqName = r.getString(0);
        ArrayList al = (ArrayList)(ElmVE.elmVE.allAgents.clone());
        Iterator i = al.iterator();
        while (i.hasNext()) {
            ElmStub ea = (ElmStub)i.next();
            if (reqName.equals(ea.name)) {
                send(makeReply(r,ea.elm.getPath()));
                return;
            }
        }
        send(makeReply(r,"not found in this server."));
    }

    public void finger(Request r) {
        String ret = "";
        ArrayList al = (ArrayList)(ElmVE.elmVE.allAgents.clone());
        Iterator i = al.iterator();
        while (i.hasNext()) {
            ElmStub es = (ElmStub)i.next();
            ret = ret + es.elm.getPath() + "\n";
        }
        send(makeReply(r,ret));
    }

    public void addAnElm(Request r) {
        sendMsgToClient("add an elm...");
        String className = r.getString(0);
        String objectName = r.getString(1);
        makeElm(className,objectName);
        sendMsgToClient("done.");
        send(makeReply(r,""));
    }

    public void touch(Request r) {
        try {
            makeElm(defaultChildClass,r.getString(0));
            ElmStub e = getElm(r.getString(0));
            if (r.getArgCount() == 3) {
                Place p = new Place(r.getDouble(1),r.getDouble(2),0.0);
                send(makeOrder(e,"setPlace",p));
            } else if (r.getArgCount() == 4) {
                Place p = new Place(r.getDouble(1),r.getDouble(2),
                                    r.getDouble(3));
                send(makeOrder(e,"setPlace",p));
            } else {
                Place p = getPlace();
                p.add(new Place(3.0,0.0,0.0));
                send(makeOrder(e,"setPlace",p));
            }
//            e.interruption = true;
//            parent.interruption = true;
            send(makeReply(r,"touch - OK."));
        } catch (Exception ee) {
            ee.printStackTrace();
            send(makeReply(r,"error!"));
        }
    }

    int nNumber = 0;
    public void touchAuto(Request r) {
        try {
            while(getElm("n"+nNumber)!=null)
                nNumber++;
            makeElm(defaultChildClass,"n"+nNumber);
            ElmStub e = getElm("n"+nNumber);
            if (r.getArgCount() == 2) {
                Place p = new Place(r.getDouble(0),r.getDouble(1),0.0);
                send(makeOrder(e,"setPlace",p));
            } else if (r.getArgCount() == 3) {
                Place p = new Place(r.getDouble(0),r.getDouble(1),
                                    r.getDouble(2));
                send(makeOrder(e,"setPlace",p));
            } else {
                Place p = getPlace();
                p.add(new Place(3.0,0.0,0.0));
                send(makeOrder(e,"setPlace",p));
            }
            send(makeReply(r,"touch - OK."));
        } catch (Exception ee) {
            ee.printStackTrace();
            send(makeReply(r,"error!"));
        }
    }

//----------------------------------------------------------------------

    public void quit(Request r) {
        String p = parent.elm.getFullPath();
        String pp = W.getLocalPath(p);
        String ppp = W.getElmVEPath(p); 
System.out.println("**gaha**"+ppp);
System.out.println("**gaha**"+W.getElmVEPath(home));
        if (!ppp.equals(W.getElmVEPath(home))) {
            send(makeReply(r,"goHome first!(1)"));
        } else {
            int n = 0;
            int nn = 0;
            while (true) {
                nn = pp.indexOf('/',nn);
                if (nn == -1)
                    break;
                nn++;
                n++;
            }
            if (n>3)
                send(makeReply(r,"goHome first!(2)"));
            else
                ElmVE.elmVE.quit();
        }
    }

    public void kill(Request r) {
        ElmVE.elmVE.kill();
    }

//----------------------------------------------------------------------

    public void saveWorld(Request r) {
        String fileName = r.getString(0);
        MyRequest rr = makeMyRequest(ElmVE.elmVE.topElm,"saveWorld",fileName);
        receive(rr,"saveWorld2",r);
        send(rr);
    }
    public void saveWorld2(ReplySet rs) {
        if ("Ok.".equals(rs.getString(0,0)))
            send(makeReply(rs.getRequest(0),"Ok."));
        else
            send(makeReply(rs.getRequest(0),"Fail."));
    }

    public void backupWorldAsText(Request r) {
        String fileName = r.getString(0);
        MyRequest rr = makeMyRequest(ElmVE.elmVE.topElm,"saveAsText",fileName);
        receive(rr,"backupWorldAsText2",r);
        send(rr);
    }
    public void backupWorldAsText2(ReplySet rs) {
        if ("Ok.".equals(rs.getString(0,0)))
            send(makeReply(rs.getRequest(0),"Ok."));
        else
            send(makeReply(rs.getRequest(0),"Fail."));
    }

//----------------------------------------------------------------------

    protected void prepareForTranslation() {
        super.prepareForTranslation();
        lastElms = new ElmSet();
    }

//----------------------------------------------------------------------

    protected ElmSet lastElms = new ElmSet();
    protected ElmStub lastBGElm = null;

    public void gather2DUIData(MyOrder o) {
        ElmStub bgElm = parent;
        ElmSet elms = getElms("*");
        ElmSet newElms = (ElmSet)elms.clone();
        newElms.removeAll(lastElms);
        ElmSet oldElms = (ElmSet)lastElms.clone();
        oldElms.removeAll(elms);
        elms.removeAll(newElms);
        elms.removeAll(oldElms);

        ReqSet reqs = new ReqSet();
        if ((lastBGElm == null)||(!lastBGElm.equals(bgElm))) {
            reqs.add(makeMyRequest(parent,"send2DBGData",NULL));
        } else {
            reqs.add(makeMyRequest(parent,"send2DBGRepaintData",
                                   lastUpdateTime));
        }
        reqs.addAll(makeMyRequest(newElms,"send2DUIData",NULL));
        reqs.addAll(makeMyRequest(elms,"send2DUIRepaintData",
                                  lastUpdateTime));
        Elm2DPacket ret = new Elm2DPacket();
        ret.camera = get2DCameraData(lastUpdateTime);
        lastUpdateTime = Elm.uiTimer;
        ret.eachUI = new ArrayList<Elm2DData>();
        Iterator i = oldElms.iterator();
        while (i.hasNext()) {
            Elm2DData d = new Elm2DData(Elm2DData.OLD);
            d.elm = (ElmStub)i.next();
            ret.eachUI.add(d);
        }
        lastElms.clear();
        lastElms.addAll(newElms);
        lastElms.addAll(elms);
        lastBGElm = bgElm;
        receive(reqs,"gather2DUIData2",ret);
        send(reqs);
    }
    public void gather2DUIData2(ReplySet rs) {
        boolean needRepaint = false;
        Elm2DPacket ret = (Elm2DPacket)rs.get(0);
        if (ret.eachUI.size() != 0) {
System.out.println("needRepaint(gaha1)");
            needRepaint = true;
        }
        if (rs.get(0,0)!=NULL) {
            needRepaint = true;
            ret.backGround = (Elm2DData)rs.get(0,0);
        } else {
            ret.backGround = null;
        }
        for (int i=1;i<rs.getReplyCount();i++) {
            if (rs.get(i,0)!=NULL) {
                needRepaint = true;
                ret.eachUI.add((Elm2DData)rs.get(i,0));
            }
        }
        if (needRepaint) {
            Request r = makeRequest(client,"catch2DUIData",ret);
            receive(r,"gather2DUIData3",NULL);
            send(r);
        } else {
            send(makeMyOrder("gather2DUIData",NULL),200);
        }
    }
    public void gather2DUIData3(ReplySet rs) {
        send(makeMyOrder("gather2DUIData",NULL),200);
    }

    public void gather3DUIData(MyOrder o) {
        ElmStub bgElm = parent;
        ElmSet elms = getElms("*");
        ElmSet newElms = (ElmSet)elms.clone();
        newElms.removeAll(lastElms);
        ElmSet oldElms = (ElmSet)lastElms.clone();
        oldElms.removeAll(elms);
        elms.removeAll(newElms);
        elms.removeAll(oldElms);

        ReqSet reqs = new ReqSet();
        if ((lastBGElm == null)||(!lastBGElm.equals(bgElm))) {
            reqs.add(makeMyRequest(parent,"send3DBGData",NULL));
        } else {
            reqs.add(makeMyRequest(parent,"send3DBGRepaintData",
                                   lastUpdateTime));
        }
        reqs.addAll(makeMyRequest(newElms,"send3DUIData",NULL));
        reqs.addAll(makeMyRequest(elms,"send3DUIRepaintData",
                                  lastUpdateTime));
        Elm3DPacket ret = new Elm3DPacket();
        ret.camera = get3DCameraData(lastUpdateTime);
        lastUpdateTime = Elm.uiTimer;
        ret.eachUI = new ArrayList<Elm3DData>();
        Iterator i = oldElms.iterator();
        while (i.hasNext()) {
            Elm3DData d = new Elm3DData(Elm3DData.OLD);
            d.elm = (ElmStub)i.next();
            ret.eachUI.add(d);
        }
        lastElms.clear();
        lastElms.addAll(newElms);
        lastElms.addAll(elms);
        lastBGElm = bgElm;
        receive(reqs,"gather3DUIData2",ret);
        send(reqs);
    }
    public void gather3DUIData2(ReplySet rs) {
        boolean needRepaint = false;
        Elm3DPacket ret = (Elm3DPacket)rs.get(0);
        if (rs.get(0,0)!=NULL) {
            needRepaint = true;
            ret.backGround = (Elm3DData)rs.get(0,0);
        } else {
            ret.backGround = null;
        }
        for (int i=1;i<rs.getReplyCount();i++) {
            if (rs.get(i,0)!=NULL) {
                needRepaint = true;
                ret.eachUI.add((Elm3DData)rs.get(i,0));
            }
        }
        Request r = makeRequest(client,"catch3DUIData",ret);
        receive(r,"gather3DUIData3",NULL);
        send(r);
    }
    public void gather3DUIData3(ReplySet rs) {
        send(makeMyOrder("gather3DUIData",NULL),200);
    }

    public void gatherLightUIData(MyOrder o) {
        ElmStub bgElm = parent;
        ElmSet elms = getElms("*");
        ElmSet newElms = (ElmSet)elms.clone();
        newElms.removeAll(lastElms);
        ElmSet oldElms = (ElmSet)lastElms.clone();
        oldElms.removeAll(elms);
        elms.removeAll(newElms);
        elms.removeAll(oldElms);

        ReqSet reqs = new ReqSet();
        if ((lastBGElm == null)||(!lastBGElm.equals(bgElm))) {
            reqs.add(makeMyRequest(parent,"sendLightBGData",NULL));
        } else {
            reqs.add(makeMyRequest(parent,"sendLightBGRepaintData",
                                   lastUpdateTime));
        }
        reqs.addAll(makeMyRequest(newElms,"sendLightUIData",NULL));
        reqs.addAll(makeMyRequest(elms,"sendLightUIRepaintData",
                                  lastUpdateTime));
        ElmLightPacket ret = new ElmLightPacket();
        ret.camera = getLightCameraData(lastUpdateTime);
        lastUpdateTime = Elm.uiTimer;
        ret.eachUI = new ArrayList<ElmLightData>();
        Iterator i = oldElms.iterator();
        while (i.hasNext()) {
            ElmLightData d = new ElmLightData(ElmLightData.OLD);
            d.elm = (ElmStub)i.next();
            ret.eachUI.add(d);
        }
        lastElms.clear();
        lastElms.addAll(newElms);
        lastElms.addAll(elms);
        lastBGElm = bgElm;
        receive(reqs,"gatherLightUIData2",ret);
        send(reqs);
    }
    public void gatherLightUIData2(ReplySet rs) {
        boolean needRepaint = false;
        ElmLightPacket ret = (ElmLightPacket)rs.get(0);
        if (rs.get(0,0)!=NULL) {
            needRepaint = true;
            ret.backGround = (ElmLightData)rs.get(0,0);
        } else {
            ret.backGround = null;
        }
        for (int i=1;i<rs.getReplyCount();i++) {
            if (rs.get(i,0)!=NULL) {
                needRepaint = true;
                ret.eachUI.add((ElmLightData)rs.get(i,0));
            }
        }
        Request r = makeRequest(client,"catchLightUIData",ret);
        receive(r,"gatherLightUIData3",NULL);
        send(r);
    }
    public void gatherLightUIData3(ReplySet rs) {
        send(makeMyOrder("gatherLightUIData",NULL),200);
    }

    CameraData get2DCameraData(int lut) {
        if ((lastBGElm==null)||(!lastBGElm.equals(parent))) {
            CameraData cd = new CameraData(CameraData.NEW);
            get2DCameraData(cd);
            return cd;
        } else if (lut < updateTime) {
            CameraData cd = new CameraData(CameraData.MOVE);
            get2DCameraData(cd);
            return cd;
        } else {
CameraData cd = new CameraData(CameraData.MOVE);
get2DCameraData(cd);
return cd;
//            return null;
        }
    }

    protected void get2DCameraData(CameraData cd) {
        cd.place.set(this.place);
        cd.rotation.set(this.rotation);
    }

    CameraData get3DCameraData(int lut) {
        if ((lastBGElm==null)||(!lastBGElm.equals(parent))) {
            CameraData cd = new CameraData(CameraData.NEW);
            get3DCameraData(cd);
            return cd;
        } else if (lut < updateTime) {
            CameraData cd = new CameraData(CameraData.MOVE);
            get3DCameraData(cd);
            return cd;
        } else {
CameraData cd = new CameraData(CameraData.MOVE);
get3DCameraData(cd);
return cd;
//            return null;
        }
    }

    Matrix4 mTmp = new Matrix4();
    Place vTmp = new Place();
    protected void get3DCameraData(CameraData cd) {
        vTmp.set(0.0,5.0,15.0);
        mTmp.set(this.rotation);
        mTmp.transform(vTmp);
        vTmp.add(this.place);
        cd.place.set(vTmp);
        cd.rotation.set(this.rotation);
    }

    CameraData getLightCameraData(int lut) {
        if ((lastBGElm==null)||(!lastBGElm.equals(parent))) {
            CameraData cd = new CameraData(CameraData.NEW);
            getLightCameraData(cd);
            return cd;
        } else if (lut < updateTime) {
            CameraData cd = new CameraData(CameraData.MOVE);
            getLightCameraData(cd);
            return cd;
        } else {
CameraData cd = new CameraData(CameraData.MOVE);
getLightCameraData(cd);
return cd;
//            return null;
        }
    }

    protected void getLightCameraData(CameraData cd) {
        cd.place.set(this.place);
        cd.rotation.set(this.rotation);
    }
//----------------------------------------------------------------------

    public void openCustomizer(Request r) {
        ElmStub e = getElm(r.getString(0));
        MyRequest rr = makeMyRequest(e,"sendCustomizerData",NULL);
        receive(rr,"openCustomizer2",r);
        send(rr);
    }
    public void openCustomizer2(ReplySet rs) {
        CustomizerData ret = (CustomizerData)rs.get(0,0);
        send(makeReply(rs.getRequest(0),ret));
    }
//----------------------------------------------------------------------
    public String toString() {
        return super.toString()+" home :"+home+"\n";
    }
//----------------------------------------------------------------------
    int lNumber = 0;
    public void connectNodes(Request r) {
        ElmStub e1 = getElm(r.getString(0));
        ElmStub e2 = getElm(r.getString(1));
        if (  (e1.instanceOf("ac.hiu.j314.elmve.graph.Node"))
            &&(e2.instanceOf("ac.hiu.j314.elmve.graph.Node"))) {
            ReqSet reqs = new ReqSet();
            reqs.add(makeRequest(e1,"getSocketsData",NULL));
            reqs.add(makeRequest(e2,"getSocketsData",NULL));
            reqs.add(makeRequest(e1,"getPlace",NULL));
            reqs.add(makeRequest(e2,"getPlace",NULL));
            receive(reqs,"connectNodes2",r,e1,e2);
            send(reqs);
        } else if (  (e1.instanceOf("ac.hiu.j314.elmve.graph.SNode"))
                   &&(e2.instanceOf("ac.hiu.j314.elmve.graph.SNode"))) {
            MyRequest req = makeMyRequest(client,"showConnectDialog",
                                    null,null);
            receive(req,"connectNodes21",r,e1,e2);
            send(req);
        } else {
            send(makeReply(r,"no."));
        }
    }
    public void connectNodes2(ReplySet rs) {
        Request r = rs.getRequest(0);
        ElmStub e1 = rs.getElm(1);
        ElmStub e2 = rs.getElm(2);
        Place p1 = (Place)rs.getPlace(2,0);
        Place p2 = (Place)rs.getPlace(3,0);

        SocketsData headSData = (SocketsData)rs.get(0,0);
        SocketsData tailSData = (SocketsData)rs.get(1,0);

        MyRequest req = makeMyRequest(client,"showConnectDialog",
                                headSData,tailSData);
        receive(req,"connectNodes3",r,e1,e2,p1,p2);
        send(req);
    }
    public void connectNodes3(ReplySet rs) {
        Request r = rs.getRequest(0);
        ElmStub e1 = rs.getElm(1);
        ElmStub e2 = rs.getElm(2);
        Place p1 = (Place)rs.getPlace(3);
        Place p2 = (Place)rs.getPlace(4);
        Serializable c[] = rs.getReply(0).getAll();

        if (c[1]==null) {
            send(makeReply(r,"cancel!"));
            return;
        }

        while (getElm("l"+lNumber)!=null)
            lNumber++;
        makeElm((String)c[1],"l"+lNumber);
        ElmStub link = getLocalElm("l"+lNumber);
        lNumber++;
        send(makeOrder(link,"initLink",e1,e2,c[2]));

        p1.add(p2);
        p1.scale(0.5);
        send(makeOrder(link,"setPlace",p1));

        if (((Link)link.elm).isDirected()) {
            send(makeOrder(e1,"addLink",link,e2,c[3],Sockets.HEAD));
            send(makeOrder(e2,"addLink",link,e1,c[4],Sockets.TAIL));
        } else {
            send(makeOrder(e1,"addLink",link,e2,c[3],Sockets.BOTH));
            send(makeOrder(e2,"addLink",link,e1,c[4],Sockets.BOTH));
        }
        send(makeReply(r,"connect!"));
    }
    public void connectNodes21(ReplySet rs) {
        Request r = rs.getRequest(0);
        ElmStub e1 = rs.getElm(1);
        ElmStub e2 = rs.getElm(2);
        Serializable c[] = rs.getReply(0).getAll();

        if (((Boolean)c[2]).booleanValue()) {
            send(makeMyOrder(e1,"connect",e2,SNode.HEAD));
            send(makeMyOrder(e2,"connect",e1,SNode.TAIL));
        } else {
            send(makeMyOrder(e1,"connect",e2,SNode.BOTH));
            send(makeMyOrder(e2,"connect",e1,SNode.BOTH));
        }
        send(makeReply(r,"Ok."));
    }

//    void goToStartPlace(String sp) {
//        Request r = makeRequest("cd",sp);
//        receive(r,"goToStartPlace2",null);
//        send(r);
//    }
//    public void goToStartPlace2(ReplySet rs) {
//        ;
//    }

    public void configure(Request r) {
        if ((r.sender.equals(client))||(r.sender.equals(this))) {
            MyRequest rr = makeMyRequest(client,"configPreference",NULL);
            receive(rr,"configure2",r);
            send(rr);
            return;
        }
        send(makeReply(r,"some illegal access?"));
        return;
    }
    public void configure2(ReplySet rs) {
        Request r = rs.getRequest(0);
        send(makeReply(r,NULL));
    }

    public void configure(MyOrder o) {
        if (o.sender.equals(client)) {
            MyRequest rr = makeMyRequest(client,"configPreference",NULL);
            receive(rr,"configure2_2",NULL);
            send(rr);
            return;
        }
        System.out.println("some illegal access?");
        return;
    }
    public void configure2_2(ReplySet rs) {
        ;
    }
}
