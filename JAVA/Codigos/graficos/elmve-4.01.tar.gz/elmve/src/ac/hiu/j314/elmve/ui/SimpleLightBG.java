package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.clients.*;
import java.awt.*;

public class SimpleLightBG extends ElmLightBG {
    public void init(ElmLightData data) {
    }
    public void update(ElmLightData data) {
    }

    public void paint(Graphics g) {
        Rectangle r = g.getClipBounds();
        g.setColor(Color.lightGray);
        g.fillRect(0,0,r.width,r.height);
    }
}
