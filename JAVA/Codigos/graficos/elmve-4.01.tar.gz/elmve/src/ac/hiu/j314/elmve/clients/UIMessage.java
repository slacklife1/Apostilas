package ac.hiu.j314.elmve.clients;

import java.io.*;

public class UIMessage implements Serializable {
    private static final long serialVersionUID = 1L;
    public String methodName;
    public Serializable arguments[];

    public UIMessage(String methodName,Serializable args[]) {
        this.methodName = methodName;
        this.arguments = args;
    }

    public UIMessage(String methodName,Serializable arg) {
        this.methodName = methodName;
        Serializable args[] = {arg};
        this.arguments = args;
    }
}
