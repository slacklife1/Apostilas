package ac.hiu.j314.elmve;

import java.util.*;

class Engine1 implements Engine, Runnable {
    Thread thread;
    ArrayList<Elm> elms;
    ArrayList<Elm> activeElms;
    volatile boolean suspendRequest = false;
    volatile boolean killRequest = false;
    volatile int status = R;
    static final int S = 0;
    static final int R = 1;
    WaitingRoom wr = new WaitingRoom();

    Engine1(String name,int priority) {
        elms = new ArrayList<Elm>();
        activeElms = new ArrayList<Elm>();
        thread = new Thread(this);
        thread.setName(name);
        thread.setPriority(priority);
        thread.start();
    }

    void changePriority(int i) {
        thread.setPriority(i);
    }

    public void run() {
        Elm e;
        while (true) {
            synchronized (wr) {
                if (killRequest) return;
                if (activeElms.size() == 0)
                    e = null;
                else
                    e = (Elm)activeElms.remove(0);
                if ((e == null) || suspendRequest) {
                    status = S;
                    wr.room();
                    status = R;
                }
            }
            if (e != null)
                e.processOneMessage();
        }
    }

    void employ(Elm e) {
        synchronized (wr) {
            if (!elms.contains(e))
                elms.add(e);
        }
    }

    void dismiss(Elm e) {
        synchronized (wr) {
            elms.remove(e);
            while (activeElms.contains(e))
                activeElms.remove(e);
            e.status = Elm.SUSPENDED;
        }
    }

    public void take(Elm e) {
        synchronized (wr) {
            activeElms.add(e);
            if (suspendRequest == false) {
                e.status = Elm.RUNNING;
                wr.bell();
            }
        }
    }

    public void suspend() {
        if (suspendRequest == true) return;
        suspendRequest = true;
        while (status == R) try{Thread.sleep(100);}catch(Exception e){;}
        synchronized (wr) {
            Iterator i = elms.iterator();
            while (i.hasNext()) {
                Elm ee = (Elm)i.next();
                ee.status = Elm.SUSPENDED;
            }
        }
    }

    public void resume() {
        synchronized (wr) {
            if (status == R) return;
            Iterator i = elms.iterator();
            while (i.hasNext()) {
                Elm ee = (Elm)i.next();
                ee.status = Elm.RUNNING;
            }
            suspendRequest = false;
            wr.bell();
        }
    }

    public void dispose() {
        synchronized (wr) {
            killRequest = true;
            suspendRequest = false;
            wr.bell();
        }
    }
}
