package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;
import java.awt.*;
import javax.swing.*;
import java.io.*;

public class ElmLayout implements LayoutManager, Serializable {
    private static final long serialVersionUID = 1L;
    int pWidth = 400;
    int pHeight = 400;
    double cenX = 0.0;
    double cenY = 0.0;
    double ppm = 25.0;

    public void addLayoutComponent(String name, Component comp) {
    }

    public void removeLayoutComponent(Component comp) {
    }

    public Dimension preferredLayoutSize(Container parent) {
        return new Dimension(400,400);
    }

    public Dimension minimumLayoutSize(Container parent) {
        return new Dimension(100,100);
    }

    public void layoutContainer(Container parent) {
        Dimension d = parent.getSize();
        pWidth = d.width;
        pHeight = d.height;
        for (int i=0;i<parent.getComponentCount();i++) {
if (!(parent.getComponent(i) instanceof Elm2DUI))
continue;
            JComponent kid = (JComponent)parent.getComponent(i);
            Dimension pref = kid.getPreferredSize();
            Point po = placeToPoint(((Elm2DUI)kid).getPlace());
            kid.setBounds(po.x-pref.width/2,
                          po.y-pref.height/2,
                          pref.width,pref.height);
        }
    }

    public void pointToPlace(Point po,Place pl) {
        double x =  ((double)(po.x-pWidth/2))/ppm + cenX;
        double y = -((double)(po.y-pHeight/2))/ppm + cenY;
        pl.set(x,y,0.0);
    }

    public Place pointToPlace(Point p) {
        double x =  ((double)(p.x-pWidth/2))/ppm + cenX;
        double y = -((double)(p.y-pHeight/2))/ppm + cenY;
        return new Place(x,y,0.0);
    }

    public Place pointToPlace(int px,int py) {
        double x =  ((double)(px-pWidth/2))/ppm + cenX;
        double y = -((double)(py-pHeight/2))/ppm + cenY;
        return new Place(x,y,0.0);
    }

    public void placeToPoint(Place pl,Point po) {
        double xyz[] = new double[3];
        pl.get(xyz);
        po.x =  (int)((xyz[0]-cenX)*ppm)+pWidth/2;
        po.y = -(int)((xyz[1]-cenY)*ppm)+pHeight/2;
    }

    public Point placeToPoint(Place p) {
        double xyz[] = new double[3];
        p.get(xyz);
        int x =  (int)((xyz[0]-cenX)*ppm)+pWidth/2;
        int y = -(int)((xyz[1]-cenY)*ppm)+pHeight/2;
        return new Point(x,y);
    }

    public Point placeToPoint(double x,double y) {
        int xx =  (int)((x-cenX)*ppm)+pWidth/2;
        int yy = -(int)((y-cenY)*ppm)+pHeight/2;
        return new Point(xx,yy);
    }

    public void setCenX(double x) {
        cenX = x;
    }

    public double getCenX() {
        return cenX;
    }

    public void setCenY(double y) {
        cenY = y;
    }

    public double getCenY() {
        return cenY;
    }

    public void setPPM(double ppm) {
        this.ppm = ppm;
    }

    public double getPPM() {
        return ppm;
    }
}
