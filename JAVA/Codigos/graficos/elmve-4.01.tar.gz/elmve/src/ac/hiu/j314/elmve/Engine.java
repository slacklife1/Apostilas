package ac.hiu.j314.elmve;

interface Engine {
    public void take(Elm e);
    public void resume();
    public void suspend();
    public void dispose();
}
