package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;
import java.io.*;
import javax.swing.*;
import javax.swing.text.*;
import java.awt.event.*;

public class Elm2DClient extends ElmClient implements ActionListener {
    private static final long serialVersionUID = 1L;
    protected JFrame frame;
    protected Box baseBox;
    protected JMenuBar menuBar;
    protected JMenuItem loadMenuItem;
    protected JMenuItem saveMenuItem;
    protected JMenuItem quitMenuItem;
    protected JMenuItem killMenuItem;
    protected JMenuItem screenShotMenuItem;
    protected JMenuItem configMenuItem;
    protected JMenuItem consoleMenuItem;
    protected JMenuItem aboutMenuItem;
    protected JMenuItem buildTimeMenuItem;
    protected ElmEditor elmEditor;
    protected JTextField commandLine;
    protected JTextArea textArea;
    protected JButton catchButton;
    protected JFrame consoleFrame;
    protected JTextArea consoleTextArea;
    protected JButton clearConsoleButton;
    protected MyKeyAdapter keyAdapter;
    protected String menus[];
    protected boolean b1 = true;
    protected boolean b2 = true;
    protected boolean b3 = true;

    protected void init() {
        super.init();
        initOwnEngine("Elm2DClient",1);
        menus = new String[5];
        menus[0] = "File";
        menus[1] = "Image";
        menus[2] = "Config";
        menus[3] = "Console";
        menus[4] = "Help";
    }

    public void startProcessing(MyOrder o) {
        frame = new JFrame();
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                quit();
                try{Thread.sleep(3000);}catch(Exception e){;}
                kill();
                try{Thread.sleep(3000);}catch(Exception e){;}
                System.exit(1);
            }
        });
        baseBox = Box.createVerticalBox();
        frame.getContentPane().add(baseBox);
        makeMenuBar();
        makeEditor();
        if (b3) {
            makeInputArea();
        }
        makeTextArea();

        consoleFrame = new JFrame("Console");
        Box b = Box.createVerticalBox();
        consoleTextArea = new JTextArea(20,60);
        consoleTextArea.setEditable(false);
        JScrollPane sp = new JScrollPane(consoleTextArea);
        b.add(sp);
        clearConsoleButton = new JButton("Clear");
        clearConsoleButton.addActionListener(this);
        b.add(clearConsoleButton);
        consoleFrame.getContentPane().add(b);
        consoleFrame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                consoleFrame.setVisible(false);
            }
        });
        PrintStream systemOut = System.out;
        JTextAreaOutputStream jtaos = new JTextAreaOutputStream(consoleTextArea,systemOut);
        PrintStream ps = new PrintStream(jtaos,true);
        System.setOut(ps);
        System.setErr(ps);
        consoleFrame.pack();

        frame.pack();
        frame.setVisible(true);

        keyAdapter = new MyKeyAdapter();
        frame.addKeyListener(keyAdapter);
        elmEditor.addKeyListener(keyAdapter);
        if (b1) {
            elmEditor.expandButton.addKeyListener(keyAdapter);
            elmEditor.reduceButton.addKeyListener(keyAdapter);
            elmEditor.upButton.addKeyListener(keyAdapter);
        }
        if (b2) {
            elmEditor.northButton.addKeyListener(keyAdapter);
            elmEditor.southButton.addKeyListener(keyAdapter);
            elmEditor.westButton.addKeyListener(keyAdapter);
            elmEditor.eastButton.addKeyListener(keyAdapter);
        }
        elmEditor.monitor.addKeyListener(keyAdapter);
        if (b3) {
            catchButton.addKeyListener(keyAdapter);
        }
        textArea.addKeyListener(keyAdapter);

        send(makeMyOrder(avatar,"gather2DUIData",NULL));
    }

    public void bindAvatar(MyOrder o) {
        super.bindAvatar(o);
        send(makeMyOrder(avatar,"gather2DUIData",NULL));
    }

    void makeMenuBar() {
        menuBar = new JMenuBar();

        for (int i=0;i<menus.length;i++) {
            JMenu m = new JMenu(menus[i]);
            menuBar.add(m);
        }

        makeFileMenu();
        makeImageMenu();
        makeConfigMenu();
        makeConsoleMenu();
        makeHelpMenu();

        frame.setJMenuBar(menuBar);
    }

    void makeFileMenu() {
        JMenu fileMenu = null;
        for (int i=0;i<menus.length;i++) {
            if (menus[i].equals("File")) {
                fileMenu = menuBar.getMenu(i);
                break;
            }
        }
        if (fileMenu==null)
            return;
        loadMenuItem = new JMenuItem("Load");
        saveMenuItem = new JMenuItem("Save");
        quitMenuItem = new JMenuItem("Quit");
        killMenuItem = new JMenuItem("Kill");
        loadMenuItem.addActionListener(this);
        saveMenuItem.addActionListener(this);
        quitMenuItem.addActionListener(this);
        killMenuItem.addActionListener(this);
        fileMenu.add(loadMenuItem);
        fileMenu.add(saveMenuItem);
        fileMenu.add(quitMenuItem);
        fileMenu.add(killMenuItem);
    }

    void makeImageMenu() {
        JMenu imageMenu = null;
        for (int i=0;i<menus.length;i++) {
            if (menus[i].equals("Image")) {
                imageMenu = menuBar.getMenu(i);
                break;
            }
        }
        if (imageMenu==null)
            return;
        screenShotMenuItem = new JMenuItem("ScreenShot");
        screenShotMenuItem.addActionListener(this);
        imageMenu.add(screenShotMenuItem);
    }

    void makeConfigMenu() {
        JMenu configMenu = null;
        for (int i=0;i<menus.length;i++) {
            if (menus[i].equals("Config")) {
                configMenu = menuBar.getMenu(i);
                break;
            }
        }
        if (configMenu==null)
            return;
        configMenuItem = new JMenuItem("Config");
        configMenuItem.addActionListener(this);
        configMenu.add(configMenuItem);
    }

    void makeConsoleMenu() {
        JMenu consoleMenu = null;
        for (int i=0;i<menus.length;i++) {
            if (menus[i].equals("Console")) {
                consoleMenu = menuBar.getMenu(i);
                break;
            }
        }
        if (consoleMenu==null)
            return;
        consoleMenuItem = new JMenuItem("Console");
        consoleMenuItem.addActionListener(this);
        consoleMenu.add(consoleMenuItem);
    }

    void makeHelpMenu() {
        JMenu helpMenu = null;
        for (int i=0;i<menus.length;i++) {
            if (menus[i].equals("Help")) {
                helpMenu = menuBar.getMenu(i);
                break;
            }
        }
        if (helpMenu == null)
            return;
        aboutMenuItem = new JMenuItem("About");
        aboutMenuItem.addActionListener(this);
        helpMenu.add(aboutMenuItem);
        buildTimeMenuItem = new JMenuItem("Build Time");
        buildTimeMenuItem.addActionListener(this);
        helpMenu.add(buildTimeMenuItem);
    }

    void makeEditor() {
        elmEditor = new ElmEditor(this,b1,b2);
        baseBox.add(elmEditor);
    }

    void makeInputArea() {
        Box b = Box.createHorizontalBox();
        commandLine = new JTextField();
        commandLine.addActionListener(this);
        b.add(commandLine);
        catchButton = new JButton("Catch");
        b.add(catchButton);
        baseBox.add(b);
    }

    void makeTextArea() {
        textArea = new JTextArea(7,40);
        textArea.setEditable(false);
        JScrollPane sp = new JScrollPane(textArea);
        baseBox.add(sp);
    }

    public void printReply(ReplySet rs) {
        if (textArea!=null) {
            textArea.append(rs.toString()+"\n");
            Document d = textArea.getDocument();
            Position p = d.getEndPosition();
            Caret c = textArea.getCaret();
            c.setDot(p.getOffset());
        }
    }

    public void printMessage(Order o) {
        if (textArea!=null) {
            textArea.append(o.getString(0)+"\n");
            Document d = textArea.getDocument();
            Position p = d.getEndPosition();
            Caret c = textArea.getCaret();
            c.setDot(p.getOffset());
        }
    }

    public void actionPerformed(ActionEvent ae) {
        try {
            if (ae.getSource() == commandLine) {
                String command = commandLine.getText();
                commandLine.setText("");
                command = command.trim();
                processCommand(command);
//System.out.println(command);
            } else if (ae.getSource() == loadMenuItem) {
                showLoadDialog();
            } else if (ae.getSource() == saveMenuItem) {
                showSaveDialog();
            } else if (ae.getSource() == quitMenuItem) {
                quit();
            } else if (ae.getSource() == killMenuItem) {
                kill();
            } else if (ae.getSource() == screenShotMenuItem) {
                showScreenShotDialog();
            } else if (ae.getSource() == configMenuItem) {
                send(makeMyOrder(avatar,"configure",NULL));
            } else if (ae.getSource() == consoleMenuItem) {
                consoleFrame.setVisible(true);
            } else if (ae.getSource() == clearConsoleButton) {
                consoleTextArea.setText("");
            } else if (ae.getSource() == aboutMenuItem) {
                new ElmAbout();
            } else if (ae.getSource() == buildTimeMenuItem) {
                new BuildTimeWindow("x-res:///buildTime.txt");
            }
        } catch(ElmException e) {
            e.printStackTrace();
        }
    }

    void showLoadDialog() {
        JFileChooser chooser = new JFileChooser();
        int returnVal = chooser.showOpenDialog(frame);
        if (returnVal != JFileChooser.APPROVE_OPTION)
            return;
        try {
            processCommand("load "+chooser.getSelectedFile().getPath());
        } catch(ElmException ee) {
            ee.printStackTrace();
        }
    }

    void showSaveDialog() {
        String m = "Before saveing, You must\n"
                   +"be in Elm object which\n"
                   +"you will save.";
        int result = JOptionPane.showConfirmDialog(frame,m,"save",
                                                   JOptionPane.YES_NO_OPTION);
        if (result!=JOptionPane.YES_OPTION)
            return;

        JFileChooser chooser = new JFileChooser();
        int returnVal = chooser.showOpenDialog(frame);
        if (returnVal != JFileChooser.APPROVE_OPTION)
            return;
        try {
            processCommand("save . "+chooser.getSelectedFile().getPath());
        } catch (ElmException ee) {
            ee.printStackTrace();
        }
    }

    void showScreenShotDialog() {
        JFileChooser chooser = new JFileChooser();
        int returnVal = chooser.showOpenDialog(frame);
        if (returnVal != JFileChooser.APPROVE_OPTION)
            return;
        try {
            elmEditor.saveImage(chooser.getSelectedFile());
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    public void configPreference(MyRequest r) {
        super.configPreferenceGUI(r);
    }

    public void passwordInput(MyRequest r) {
        super.passwordInputGUI(r);
    }

    public void catch2DUIData(Request r) {
        Elm2DPacket elm2DPacket = (Elm2DPacket)r.get(0);
        elmEditor.processElm2DPacket(elm2DPacket);
        send(makeReply(r,NULL));
    }

    public void refresh(Request r) {
        send(makeMyOrder(avatar,"gather2DUIData",NULL));
        send(makeReply(r,NULL));
    }

    public void processKeyPressed(KeyEvent e) {
        try {
            switch (e.getKeyCode()) {
            case KeyEvent.VK_UP:
                processCommand("goNorth &");
                break;
            case KeyEvent.VK_DOWN:
                processCommand("goSouth &");
                break;
            case KeyEvent.VK_RIGHT:
                processCommand("goEast &");
                break;
            case KeyEvent.VK_LEFT:
                processCommand("goWest &");
                break;
            default:
                break;
            }
        } catch(ElmException ee) {
            ee.printStackTrace();
        }
    }

    public void processKeyReleased(KeyEvent e) {
    }

    public void processKeyTyped(KeyEvent e) {
    }

    class MyKeyAdapter extends KeyAdapter {
        public void keyPressed(KeyEvent e) {
            processKeyPressed(e);
        }
        public void keyReleased(KeyEvent e) {
            processKeyReleased(e);
        }
        public void keyTyped(KeyEvent e) {
            processKeyTyped(e);
        }
    }

    public void close() {
        if (frame!=null)
            frame.dispose();
    }
}
