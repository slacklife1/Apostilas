package ac.hiu.j314.elmve;

import java.util.*;
import java.io.*;

class ElmTimerTask extends TimerTask {
    Elm elm;
    Serializable msg;

    public ElmTimerTask(Elm e,Message m) {
        elm = e;
        msg = m;
    }

    public ElmTimerTask(Elm e,ArrayList m) {
        elm = e;
        msg = m;
    }

    public void run() {
        if (msg instanceof Message) {
            elm.send((Message)msg);
        } else if (msg instanceof OdrSet){
            elm.send((OdrSet)msg);
        } else if (msg instanceof ReqSet) {
            elm.send((ReqSet)msg);
        }
    }
}

