package ac.hiu.j314.elmve;

import java.rmi.*;

public interface RemoteElmVE extends Remote {
    public boolean receiveMessage(Message m) throws RemoteException;
    public ElmSet getElms(String uri) throws RemoteException;
    public byte[] loadClassData(String name) throws RemoteException;
    public byte[] elmFindResource(String name) throws RemoteException;
    public void stopServer() throws RemoteException;
}
