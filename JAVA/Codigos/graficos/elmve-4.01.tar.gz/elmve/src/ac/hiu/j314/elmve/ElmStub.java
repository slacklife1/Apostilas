package ac.hiu.j314.elmve;

import java.io.*;
import org.w3c.dom.*;

// The identification of Elm Object.
// It distinguishs all possible Elm Objects.

public class ElmStub implements Serializable {
    private static final long serialVersionUID = 1L;

    static long idCounter = 0;
    long elmID;
    ElmServer server;

    String name;
    String path;
    String owner;
    String className;
    String role = "";
    transient Elm elm = null;

    ElmStub(Elm e) {
        elmID = idCounter++;
        server = ElmVE.elmVE.thisServer;

        className = e.getClass().getName();
        elm = e;
        //name value is set each time.
        //path value is set each time.
        //owner value is set each time.
    }

    public String getName() {
        return name;
    }

    public long getElmID() {
        return elmID;
    }

    public String getClassName() {
        return className;
    }

    public boolean isLocal() {
        return server.equals(ElmVE.elmVE.thisServer);
    }

    public boolean equals(Object elm) {
        try {
            ElmStub es = (ElmStub)elm;
            if (this == es)
                return true;
            if (elmID != es.elmID)
                return false;
            if (!server.equals(es.server))
                return false;
            return true;
        } catch(ClassCastException cce1) {
            try {
                Elm e = (Elm)elm;
                return equals(e.stub);
            } catch(ClassCastException cce2) {
                return false;
            }
        }
    }

    public int hashCode() {
        return (int)elmID+server.hashCode();
    }

    public String toString() {
        return "ElmStub("+name+",id="+elmID+",local="+isLocal()+")";
    }

    public boolean instanceOf(String cn) {
        Class<?> thisClass = null;
        Class<?> targetClass = null;
        try {
            thisClass = ElmVE.classLoader.loadClass(className);
            targetClass = ElmVE.classLoader.loadClass(cn);
        } catch(Exception e) {
            return false;
        }
        return targetClass.isAssignableFrom(thisClass); 
    }

    boolean isInPackage(String pn) {
        String s = className.substring(0,className.lastIndexOf("."));
        return s.equals(pn);
    }

    void saveAsXML(Document d,Element e) {
        W.addLineFeedDOM(d,e);
        W.addDataDOM(d,e,"elmID",""+elmID);
        W.addLineFeedDOM(d,e);
        W.addDataDOM(d,e,"name",name);
        W.addLineFeedDOM(d,e);
        W.addDataDOM(d,e,"className",className);
        W.addLineFeedDOM(d,e);
        W.addDataDOM(d,e,"owner",owner);
        W.addLineFeedDOM(d,e);
    }

    void loadFromXML(Element e) {
        elmID = Long.parseLong(W.getDataDOM(e,"elmID"));
        name = W.getDataDOM(e,"name");
        className = W.getDataDOM(e,"className");
        owner = W.getDataDOM(e,"owner");
    }

    void loadFromXMLExceptID(Element e) {
//        elmID = Long.parseLong(W.getDataDOM(e,"elmID"));
        name = W.getDataDOM(e,"name");
        className = W.getDataDOM(e,"className");
        owner = W.getDataDOM(e,"owner");
    }
}
