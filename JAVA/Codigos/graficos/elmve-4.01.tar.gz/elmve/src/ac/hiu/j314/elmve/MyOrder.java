package ac.hiu.j314.elmve;

import java.io.*;

public class MyOrder extends OdrBase {
    private static final long serialVersionUID = 1L;

    MyOrder(ElmStub sender, ElmStub receiver,
            String methodName, Serializable arguments[]) {
        super(sender,receiver,methodName,arguments);
    }
}
