package ac.hiu.j314.elmve;

import java.util.*;

public class OdrSet extends ArrayList<OdrBase> {
    private static final long serialVersionUID = 1L;
}
