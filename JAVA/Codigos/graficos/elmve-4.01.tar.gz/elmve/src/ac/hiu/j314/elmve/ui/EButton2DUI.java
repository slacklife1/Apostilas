package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.clients.*;
import javax.swing.*;
import java.awt.event.*;

public class EButton2DUI extends Elm2DUI implements ActionListener {
    private static final long serialVersionUID = 1L;
    protected JButton button;

    public void init(Elm2DData d) {
        button = new JButton();
        add(button);
        button.addActionListener(this);
        button.setText(d.getString(0));
    }

    public void update(Elm2DData d) {
        ;
    }

    public void actionPerformed(ActionEvent ae) {
        send(makeOrder("catchEButtonEvent",NULL));
    }
}
