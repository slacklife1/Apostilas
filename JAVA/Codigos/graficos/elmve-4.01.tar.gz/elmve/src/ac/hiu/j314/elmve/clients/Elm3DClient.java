package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;
import java.io.*;
import javax.media.j3d.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;

public class Elm3DClient extends ElmClient implements ActionListener {
    private static final long serialVersionUID = 1L;
    protected Frame frame;
    protected MenuBar menuBar;
    protected MenuItem quitMenuItem;
    protected MenuItem killMenuItem;
    protected MenuItem screenShotMenuItem;
    protected MenuItem configMenuItem;
    protected MenuItem consoleMenuItem;
    protected MenuItem aboutMenuItem;
    protected MenuItem buildTimeMenuItem;
    protected TextField textField;
    protected JTextArea textArea;
    protected JFrame consoleFrame;
    protected JTextArea consoleTextArea;
    protected JButton clearConsoleButton;
    protected String menus[];
    protected boolean b1=true;

    protected ElmCanvas3D canvas3d;

    protected void init() {
        super.init();
        initOwnEngine("Elm3DClient",1);
        menus = new String[5];
        menus[0] = "File";
        menus[1] = "Image";
        menus[2] = "Config";
        menus[3] = "Console";
        menus[4] = "Help";
    }

    public void startProcessing(MyOrder o) {
        frame = new Frame("Elm3DClient");
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                quit();
                try{Thread.sleep(3000);}catch(Exception e){;}
                kill();
                try{Thread.sleep(3000);}catch(Exception e){;}
                System.exit(1);
            }
        });
        frame.setLayout(new BorderLayout());

        makeMenuBar();

        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice gd = ge.getDefaultScreenDevice();
        GraphicsConfiguration gcs[] = gd.getConfigurations();
        GraphicsConfigTemplate3D gct3d = new GraphicsConfigTemplate3D();
        GraphicsConfiguration gc = gct3d.getBestConfiguration(gcs);

        canvas3d = new ElmCanvas3D(gc,this);
//        canvas3d.setSize(500,500);
        canvas3d.addKeyListener(new MyKeyAdapter());
        frame.add(canvas3d,"Center");

        if (b1) {
            textField = new TextField();
            textField.addActionListener(this);
            Box box = Box.createHorizontalBox();
            box.add(textField);
            Button b = new Button("Catch");
            b.addKeyListener(new MyKeyAdapter());
            box.add(b);
            frame.add(box,"North");
        }

        textArea = new JTextArea(5,5);
        textArea.setEditable(false);
        JScrollPane sp = new JScrollPane(textArea);
        frame.add(sp,"South");

        canvas3d.prepareVirtualUniverse();

        consoleFrame = new JFrame("Console");
        Box b = Box.createVerticalBox();
        consoleTextArea = new JTextArea(20,60);
        consoleTextArea.setEditable(false);
        JScrollPane sp2 = new JScrollPane(consoleTextArea);
        b.add(sp2);
        clearConsoleButton = new JButton("Clear");
        clearConsoleButton.addActionListener(this);
        b.add(clearConsoleButton);
        consoleFrame.getContentPane().add(b);
        consoleFrame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                consoleFrame.setVisible(false);
            }
        });
        PrintStream systemOut = System.out;
        JTextAreaOutputStream jtaos = new JTextAreaOutputStream(consoleTextArea,systemOut);
        PrintStream ps = new PrintStream(jtaos,true);
        System.setOut(ps);
        System.setErr(ps);
        consoleFrame.pack();

        frame.pack();
        frame.setVisible(true);
        send(makeMyOrder(avatar,"gather3DUIData",NULL));
    }

    void makeMenuBar() {
        menuBar = new MenuBar();

        for (int i=0;i<menus.length;i++) {
            Menu m = new Menu(menus[i]);
            menuBar.add(m);
        }

        makeFileMenu();
        makeImageMenu();
        makeConfigMenu();
        makeConsoleMenu();
        makeHelpMenu();

        frame.setMenuBar(menuBar);
    }

    void makeFileMenu() {
        Menu fileMenu = null;
        for (int i=0;i<menus.length;i++) {
            if (menus[i].equals("File")) {
                fileMenu = menuBar.getMenu(i);
                break;
            }
        }
        if (fileMenu==null)
            return;

        quitMenuItem = new MenuItem("Quit");
        quitMenuItem.addActionListener(this);
        fileMenu.add(quitMenuItem);
        killMenuItem = new MenuItem("Kill");
        killMenuItem.addActionListener(this);
        fileMenu.add(killMenuItem);
    }

    void makeImageMenu() {
        Menu imageMenu = null;
        for (int i=0;i<menus.length;i++) {
            if (menus[i].equals("Image")) {
                imageMenu = menuBar.getMenu(i);
                break;
            }
        }
        if (imageMenu==null)
            return;

        screenShotMenuItem = new MenuItem("screenShot");
        screenShotMenuItem.addActionListener(this);
        imageMenu.add(screenShotMenuItem);
    }

    void makeConfigMenu() {
        Menu configMenu = null;
        for (int i=0;i<menus.length;i++) {
            if (menus[i].equals("Config")) {
                configMenu = menuBar.getMenu(i);
                break;
            }
        }
        if (configMenu==null)
            return;
        configMenuItem = new MenuItem("Config");
        configMenuItem.addActionListener(this);
        configMenu.add(configMenuItem);
    }

    void makeConsoleMenu() {
        Menu consoleMenu = null;
        for (int i=0;i<menus.length;i++) {
            if (menus[i].equals("Console")) {
                consoleMenu = menuBar.getMenu(i);
                break;
            }
        }
        if (consoleMenu==null)
            return;
        consoleMenuItem = new MenuItem("Console");
        consoleMenuItem.addActionListener(this);
        consoleMenu.add(consoleMenuItem);
    }

    void makeHelpMenu() {
        Menu helpMenu = null;
        for (int i=0;i<menus.length;i++) {
            if (menus[i].equals("Help")) {
                helpMenu = menuBar.getMenu(i);
                break;
            }
        }
        if (helpMenu == null)
            return;
        aboutMenuItem = new MenuItem("About");
        aboutMenuItem.addActionListener(this);
        helpMenu.add(aboutMenuItem);
        buildTimeMenuItem = new MenuItem("Build Time");
        buildTimeMenuItem.addActionListener(this);
        helpMenu.add(buildTimeMenuItem);
    }

//----------------------------------------------------------------------

    public void actionPerformed(ActionEvent ae) {
        try {
            if (ae.getSource() == textField) {
                String command = textField.getText();
                command = command.trim();
                if (command.equals(""))
                    return;
                processCommand(command);
                textField.setText("");
            } else if (ae.getSource() == quitMenuItem) {
                quit();
            } else if (ae.getSource() == killMenuItem) {
                kill();
            } else if (ae.getSource() == screenShotMenuItem) {
                JFileChooser chooser = new JFileChooser();
                int returnVal = chooser.showOpenDialog(frame);
                if (returnVal != JFileChooser.APPROVE_OPTION)
                    return;
                try {
                    canvas3d.saveImage(chooser.getSelectedFile());
                } catch(IOException e) {
                    e.printStackTrace();
                }
            } else if (ae.getSource() == configMenuItem) {
                send(makeMyOrder(avatar,"configure",NULL));
            } else if (ae.getSource() == consoleMenuItem) {
                consoleFrame.setVisible(true);
            } else if (ae.getSource() == clearConsoleButton) {
                consoleTextArea.setText("");
            } else if (ae.getSource() == aboutMenuItem) {
                new ElmAbout();
            } else if (ae.getSource() == buildTimeMenuItem) {
                new BuildTimeWindow("x-res:///buildTime.txt");
            }
        } catch(Exception ee) {
            ee.printStackTrace();
        }
    }

//----------------------------------------------------------------------

    public void refresh(Request r) {
        send(makeMyOrder(avatar,"gather3DUIData",NULL));
        send(makeReply(r,NULL));
    }

    public void catch3DUIData(Request r) {
        Elm3DPacket elm3DPacket = (Elm3DPacket)r.get(0);
        canvas3d.catch3DUIData(elm3DPacket);
        send(makeReply(r,NULL));
    }

    public void bindAvatar(MyOrder o) {
        super.bindAvatar(o);
        send(makeMyOrder(avatar,"gather3DUIData",NULL));
    }

    public void printReply(ReplySet rs) {
        print(rs.toString());
    }

    public void printMessage(Order o) {
        print(o.getString(0));
    }

    protected void print(String m) {
        if (textArea!=null) {
            textArea.append(m+"\n");
            Document d = textArea.getDocument();
            Position p = d.getEndPosition();
            Caret c = textArea.getCaret();
            c.setDot(p.getOffset());
        }
    }

    public void processKeyPressed(KeyEvent e) {
        try {
            switch (e.getKeyCode()) {
            case KeyEvent.VK_UP:
                processCommand("lookUp &");
                break;
            case KeyEvent.VK_DOWN:
                processCommand("lookDown &");
                break;
            case KeyEvent.VK_RIGHT:
                processCommand("lookRight &");
                break;
            case KeyEvent.VK_LEFT:
                processCommand("lookLeft &");
                break;
            case KeyEvent.VK_S:
                processCommand("turnClockwise &");
                break;
            case KeyEvent.VK_X:
                processCommand("turnCounterclockwise &");
                break;
            case KeyEvent.VK_A:
                processCommand("goFront &");
                break;
            case KeyEvent.VK_Z:
                processCommand("goBack &");
                break;
            case KeyEvent.VK_D:
                processCommand("goRight &");
                break;
            case KeyEvent.VK_C:
                processCommand("goLeft &");
                break;
            case KeyEvent.VK_F:
                processCommand("goUp &");
                break;
            case KeyEvent.VK_V:
                processCommand("goDown &");
                break;
            default:
                break;
            }
        } catch(ElmException ee) {
            ee.printStackTrace();
        }
    }

    public void processKeyReleased(KeyEvent e) {
    }

    public void processKeyTyped(KeyEvent e) {
    }

    class MyKeyAdapter extends KeyAdapter {
        public void keyPressed(KeyEvent e) {
            processKeyPressed(e);
        }
        public void keyReleased(KeyEvent e) {
            processKeyReleased(e);
        }
        public void keyTyped(KeyEvent e) {
            processKeyTyped(e);
        }
    }

    public void close() {
        if (frame != null)
            frame.dispose();
    }

    public void configPreference(MyRequest r) {
        super.configPreferenceGUI(r);
    }

    public void passwordInput(MyRequest r) {
        super.passwordInputGUI(r);
    }
}
