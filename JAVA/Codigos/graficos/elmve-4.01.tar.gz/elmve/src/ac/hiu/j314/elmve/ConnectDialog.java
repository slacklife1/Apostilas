package ac.hiu.j314.elmve;

import ac.hiu.j314.elmve.graph.*;
import java.awt.*;
import javax.swing.*;
import java.util.*;
import java.io.*;

public class ConnectDialog extends JOptionPane {
    private static final long serialVersionUID = 1L;
    //cData[0]:true->Node,false->SNode
    //cData[1]:Link's className
    //cData[2]:true->directed,false->
    //cData[3]:head socket index or name
    //cData[4]:tail socket index or name
    protected static Serializable cData[];

    public static int showConnectDialog(Component parentComp,
                                        SocketsData headSData,
                                        SocketsData tailSData) {
        cData = new Serializable[5];

        calCandidateLinkType(headSData,tailSData);

        if (cData[0]==null) {
            JOptionPane.showMessageDialog(parentComp,"There is no candidate links.");
            return 0;
        }

        JComboBox headCB = new JComboBox();
        if (((Boolean)cData[0]).booleanValue()) {
            Iterator i = headSData.get().iterator();
            while (i.hasNext()) {
                SocketData sd = (SocketData)i.next();
                headCB.addItem(sd.socketName);
            }
            headCB.setSelectedIndex(((Integer)cData[3]).intValue());
        } else {
            headCB.setEnabled(false);
        }

        JComboBox tailCB = new JComboBox();
        if (((Boolean)cData[0]).booleanValue()) {
            Iterator i = tailSData.get().iterator();
            while (i.hasNext()) {
                SocketData sd = (SocketData)i.next();
                tailCB.addItem(sd.socketName);
            }
            tailCB.setSelectedIndex(((Integer)cData[4]).intValue());
        } else {
            tailCB.setEnabled(false);
        }

        JCheckBox dirCB = new JCheckBox("Directed?");
        if (((Boolean)cData[0]).booleanValue())
            dirCB.setEnabled(false);
        else
            dirCB.setSelected(((Boolean)cData[2]).booleanValue());

        Box messageBox = Box.createHorizontalBox();
        messageBox.add(headCB);
        messageBox.add(dirCB);
        messageBox.add(tailCB);
        Object options[] = {"Ok","Cancel"};
        int result = JOptionPane.showOptionDialog(parentComp,
                                                  messageBox,
                                                  "ConnectionDialog",
                                                  JOptionPane.DEFAULT_OPTION,
                                                  JOptionPane.INFORMATION_MESSAGE,
                                                  null,options,options[0]);
        if (headSData != null)
            cData[1] = ((SocketData)headSData.get().get(headCB.getSelectedIndex())).linkClass;// class fo connection
        cData[2] = new Boolean(dirCB.isSelected());//directed or not directed
        cData[3] = (String)headCB.getSelectedItem();//socket no of head
        cData[4] = (String)tailCB.getSelectedItem();//socket no of tail

        return result;
    }

    public static Serializable[] getCData() {
        return cData;
    }

    public static void calCandidateLinkType(SocketsData h,SocketsData t) {
        if (h==null) {
            cData[0] = new Boolean(false);
            cData[1] = null;
            cData[2] = new Boolean(false);
            cData[3] = null;
            cData[4] = null;
        } else {
            Iterator i = h.get().iterator();
            Iterator j = t.get().iterator();
            while (i.hasNext()) {
                SocketData sd1 = (SocketData)i.next();
                while (j.hasNext()) {
                    SocketData sd2 = (SocketData)j.next();
                    if ((sd1.linkNumber!=-1)&&(sd1.linkNumber<=sd1.linkedNumber))
                        continue;
                    if ((sd2.linkNumber!=-1)&&(sd2.linkNumber<=sd2.linkedNumber))
                        continue;
                    if (sd1.linkClass.equals(sd2.linkClass)) {
                        cData[0] = new Boolean(true);
                        cData[1] = sd1.linkClass;
                        cData[2] = null;
                        cData[3] = new Integer(h.get().indexOf(sd1));
                        cData[4] = new Integer(t.get().indexOf(sd2));
                    }
                }
            }
        }
    }
}
