package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;

import java.io.*;

import javax.swing.*;
import java.awt.*;

public abstract class Elm2DUI extends JPanel {
    public static final Serializable NULL = Elm.NULL;
    public static final Serializable OK = Elm.OK;
    public static final Serializable ERROR = Elm.ERROR;

    protected final Place place = new Place();
    protected ElmClient client;
    protected ElmStub elm;
    protected double ppm;

    public abstract void init(Elm2DData data);

    public void setPlace(Place place) {
        this.place.set(place);
    }

    public Place getPlace() {
        return place;
    }

    public boolean isSet() {
        return false;
    }

    public abstract void update(Elm2DData data);

    public void setElm(ElmStub e) {
        elm = e;
    }

    public ElmStub getElm() {
        return elm;
    }

    public void setClient(ElmClient c) {
        this.client = c;
    }

    public void setPPM(double ppm) {this.ppm = ppm;}
    public double getPPM() {return ppm;}

    public void paintComponent(Graphics g) {
    }

//    public void update(Graphics g) {
//        paint(g);
//    }
//----------------------------------------------------------------------
    public UIOrder makeOrder(String methodName,Serializable... args) {
        return new UIOrder(methodName,args);
    }
    public UIMyOrder makeMyOrder(String methodName,Serializable... args) {
        return new UIMyOrder(methodName,args);
    }
    public void send(UIMessage msg) {
        if (msg instanceof UIOrder)
            client.relayOrder(elm,msg.methodName,msg.arguments);
        else if (msg instanceof UIMyOrder)
            client.relayMyOrder(elm,msg.methodName,msg.arguments);
    }
}
