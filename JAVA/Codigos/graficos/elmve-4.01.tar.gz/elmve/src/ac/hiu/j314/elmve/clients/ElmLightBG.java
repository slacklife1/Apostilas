package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;

import java.awt.*;

public abstract class ElmLightBG {
    protected final Place place = new Place();
    protected ElmStub elm;
    ElmCanvas canvas;
    protected Place cenPlace = new Place();
    protected Place oldCenPlace = new Place();
    protected boolean needPaint;

    public ElmLightBG() {
    }

    public abstract void init(ElmLightData data);

    public abstract void update(ElmLightData data);

    public abstract void paint(Graphics g);

    public void setCen(Place p) {
        cenPlace.set(p);
    }

    public void interpolate() {
        double xyz[]=new double[3];
        Place p = new Place(cenPlace);
        p.sub(oldCenPlace);
        p.scale(0.2);
        oldCenPlace.add(p);
        oldCenPlace.get(xyz);
        setCenX(xyz[0]);
        setCenY(xyz[1]);
    }

    public void setPlace(Place place) {
        this.place.set(place);
    }

    public void setElm(ElmStub e) {
        elm = e;
    }

    public boolean needPaint() {
        if (needPaint==true) {
            return true;
        } else if ((cenPlace==null)||(oldCenPlace==null)||
                   (cenPlace.distance(oldCenPlace)>0.01)) {
            return true;
        } else {
            return false;
        }
    }

    public void needPaint(boolean b) {
        needPaint = b;
    }
//----------------------------------------------------------------------

    protected void pointToPlace(Point po,Place pl) {
        canvas.pointToPlace(po,pl);
    }

    protected Place pointToPlace(Point p) {
        return canvas.pointToPlace(p);
    }

    protected Place pointToPlace(int px,int py) {
        return canvas.pointToPlace(px,py);
    }

    protected void placeToPoint(Place pl,Point po) {
        canvas.placeToPoint(pl,po);
    }

    protected Point placeToPoint(Place p) {
        return canvas.placeToPoint(p);
    }

    protected Point placeToPoint(double x,double y) {
        return canvas.placeToPoint(x,y);
    }

    protected void setCenX(double x) {
        canvas.setCenX(x);
    }

    protected double getCenX() {
        return canvas.getCenX();
    }

    protected void setCenY(double y) {
        canvas.setCenY(y);
    }

    protected double getCenY() {
        return canvas.getCenY();
    }

    protected void setPPM(double ppm) {
        canvas.setPPM(ppm);
    }

    protected double getPPM() {
        return canvas.getPPM();
    }
}
