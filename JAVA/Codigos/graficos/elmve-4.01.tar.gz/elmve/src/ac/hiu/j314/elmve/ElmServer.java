package ac.hiu.j314.elmve;

import org.w3c.dom.*;
import java.util.*;
import java.io.*;

class ElmServer implements Serializable {
    private static final long serialVersionUID = 1L;

    static long idCounter = 0;

    long id;
    byte address[] = new byte[4];
    byte bridge[];
    String serverName = "ElmVE";
    String serverType;
    long oldID = -1;

    String uri;

    ElmServer() {
        id=idCounter++;
    }

    ElmServer(String uri,String serverType) {
        id=idCounter++;
        StringTokenizer st = new StringTokenizer(uri,"/");
        StringTokenizer st2 = new StringTokenizer(st.nextToken(),".");
        address[0]=(byte)Integer.parseInt(st2.nextToken());
        address[1]=(byte)Integer.parseInt(st2.nextToken());
        address[2]=(byte)Integer.parseInt(st2.nextToken());
        address[3]=(byte)Integer.parseInt(st2.nextToken());
        serverName = st.nextToken();
        this.serverType = serverType;
        makeURI();
    }

    public boolean equals(Object es) {
        try {
            ElmServer server = (ElmServer)es;
            if (this==server)
                return true;
            if (!serverName.equals(server.serverName))
                return false;
            if (address[3]!=server.address[3])
                return false;
            if (address[2]!=server.address[2])
                return false;
            if (address[1]!=server.address[1])
                return false;
            if (address[0]!=server.address[0])
                return false;
            return true;
        } catch(ClassCastException cce) {
            return false;
        }
    }

    public int hashCode() {
        return serverName.hashCode()+address[0]+address[1]+address[2]+address[3];
    }

    void saveAsXML(Document d,Element e) {
        W.addAttrDOM(d,e,"id",""+id);
        int i0 = address[0]<0?address[0]+256:address[0];
        int i1 = address[1]<0?address[1]+256:address[1];
        int i2 = address[2]<0?address[2]+256:address[2];
        int i3 = address[3]<0?address[3]+256:address[3];
        W.addDataDOM(d,e,"address",""+i0+"."+i1+"."+i2+"."+i3);
        W.addLineFeedDOM(d,e);
        W.addDataDOM(d,e,"serverName",serverName);
        W.addDataDOM(d,e,"serverType",serverType);
        W.addLineFeedDOM(d,e);
    }

    void loadFromXML(Element e) {
        oldID = Long.parseLong(W.getAttrDataDOM(e,"id"));
        StringTokenizer st = new StringTokenizer(W.getDataDOM(e,"address"),".");
        address[0] = (byte)Integer.parseInt(st.nextToken());
        address[1] = (byte)Integer.parseInt(st.nextToken());
        address[2] = (byte)Integer.parseInt(st.nextToken());
        address[3] = (byte)Integer.parseInt(st.nextToken());
        serverName = W.getDataDOM(e,"serverName");
        serverType = W.getDataDOM(e,"serverType");
        makeURI();
    }

    void makeURI() {
        if (bridge != null) {
            uri = "//"+W.dotDecimal2String(bridge)+";"
                       +W.dotDecimal2String(address)+"/"+serverName;
        } else {
            uri = "//"+W.dotDecimal2String(address)+"/"+serverName;
        }
    }

    void setServerName(String n) {
        serverName = n;
        makeURI();
    }

    public String toString() {
        return uri;
    }
}
