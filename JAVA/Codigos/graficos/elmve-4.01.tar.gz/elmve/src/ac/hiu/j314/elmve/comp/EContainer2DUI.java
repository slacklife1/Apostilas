package ac.hiu.j314.elmve.comp;

import ac.hiu.j314.elmve.clients.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;

public class EContainer2DUI extends Elm2DUI {
    private static final long serialVersionUID = 1L;
    int w = 300;
    int h = 300;

    public void init(Elm2DData d) {
        setLayout(new ELayout());
        Iterator i = ((ArrayList)d.get(0)).iterator();
        double width = ((Double)i.next()).doubleValue();
        double height = ((Double)i.next()).doubleValue();
        w = (int)(width*ppm);
        h = (int)(height*ppm);
        while (i.hasNext()) {
            Elm2DData dd = (Elm2DData)i.next();
            Elm2DUI ui = dd.makeUI();
            ui.setElm(d.elm);
            ui.setClient(client);
            ui.init(dd);
            add((JComponent)ui);
        }
        setBorder(new TitledBorder(elm.getName()));
    }

    public void update(Elm2DData d) {
        Iterator i = ((ArrayList)d.get(0)).iterator();
        double width = ((Double)i.next()).doubleValue();
        double height = ((Double)i.next()).doubleValue();
        w = (int)(width*ppm);
        h = (int)(height*ppm);
    }

    public Dimension getPreferredSize() {
        return new Dimension(w,h);
    }
}
