package ac.hiu.j314.elmve.comp;

import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.ui.*;

import java.awt.*;

public class EPoint extends Elm {
    private static final long serialVersionUID = 1L;
    protected String elm2DUIClass(){return "ac.hiu.j314.elmve.ui.EPoint2DUI";}

    public void get2DUIData(MyRequest r) {
        Dimension d = new Dimension(15,15);
        send(makeReply(r,d,EPoint2DUI.SQUARE,Color.black));
    }
    public void get2DUIRepaintData(MyRequest r) {
        send(makeReply(r,Color.black));
    }
}
