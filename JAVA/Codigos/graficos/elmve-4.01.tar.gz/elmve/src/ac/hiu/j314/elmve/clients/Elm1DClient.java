package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;

public class Elm1DClient extends ElmClient {
    private static final long serialVersionUID = 1L;

    protected void init() {
        super.init();
    }

    public void startProcessing(MyOrder o) {
        send(makeMyOrder("commandInputLoop",NULL));
    }

    public void printReply(ReplySet rs) {
        System.out.println(rs);
        send(makeMyOrder("commandInputLoop",NULL));
    }

    public void printMessage(Order o) {
        System.out.println(o.getString(0));
    }

    public void refresh(Request r) {
        send(makeReply(r,NULL));
    }

    public void configPreference(MyRequest r) {
        super.configPreferenceText(r);
    }

    public void passwordInput(MyRequest r) {
        super.passwordInputText(r);
    }

    public void commandInputLoop(MyOrder o) {
        String msg = "> ";
        Request r = makeRequest("getLines",msg);
        receive(r,"commandInputLoop2",NULL);
        send(r);
    }
    public void commandInputLoop2(ReplySet rs) {
        String command = rs.getString(0,0);
        command.trim();
        if (command.equals("")) {
            send(makeMyOrder("commandInputLoop",NULL));
            return;
        }
        try {
            if (command.endsWith("&")) {
                processCommand(command);
                send(makeMyOrder("commandInputLoop",NULL));
            } else {
                processCommand(command);
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public void close() {
    }
}
