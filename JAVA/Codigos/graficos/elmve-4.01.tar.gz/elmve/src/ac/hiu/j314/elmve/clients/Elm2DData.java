package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;
import java.lang.reflect.*;
import java.io.*;

public class Elm2DData implements Serializable {
    private static final long serialVersionUID = 1L;
    public static final int NEW = 1;
    public static final int OLD = 2;
    public static final int UPDATE = 3;
    public int type;
    public String className;
    public ElmStub elm;
    public Place place = new Place();
    public Serializable[] data;

    public Elm2DData(int type) {
        this.type = type;
    }

    public Elm2DUI makeUI() {
        try {
            Class c = ElmVE.classLoader.loadClass(className);
            Constructor con = c.getConstructor(new Class[0]);
            Elm2DUI ui = (Elm2DUI)con.newInstance(new Object[0]);
            ui.setElm(elm);
            ui.setPlace(place);
//            ui.init(data);
            return ui;
        } catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public Elm2DBG makeBG() {
        try {
            Class c = ElmVE.classLoader.loadClass(className);
            Constructor con = c.getConstructor(new Class[0]);
            Elm2DBG ui = (Elm2DBG)con.newInstance(new Object[0]);
            ui.setElm(elm);
            ui.setPlace(place);
//            ui.init(data);
            return ui;
        } catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public int getDataCount() {
        return data.length;
    }

    public Serializable getAll() {
        return data;
    }

    public Serializable get(int i) {
        return data[i];
    }

    public int getInt(int i) {
        return ((Integer)data[i]).intValue();
    }

    public long getLong(int i) {
        return ((Long)data[i]).longValue();
    }

    public double getDouble(int i) {
        return ((Double)data[i]).doubleValue();
    }

    public boolean getBoolean(int i) {
        return ((Boolean)data[i]).booleanValue();
    }

    public String getString(int i) {
        return (String)data[i];
    }

    public Place getPlace(int i) {
        return (Place)data[i];
    }

    public Rotation getRotation(int i) {
        return (Rotation)data[i];
    }
}
