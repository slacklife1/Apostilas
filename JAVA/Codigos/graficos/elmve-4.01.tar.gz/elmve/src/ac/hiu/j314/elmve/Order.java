package ac.hiu.j314.elmve;

import java.io.*;

public class Order extends OdrBase {
    private static final long serialVersionUID = 1L;

    Order(ElmStub sender, ElmStub receiver,
          String methodName,Serializable arguments[]) {
        super(sender,receiver,methodName,arguments);
    }
}
