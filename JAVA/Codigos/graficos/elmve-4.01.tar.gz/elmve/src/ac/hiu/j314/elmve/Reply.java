package ac.hiu.j314.elmve;

import java.io.*;

public class Reply extends Message {
    private static final long serialVersionUID = 1L;
    Message request;

    Reply(ReqBase r,Serializable[] arguments) {
        super(r.receiver,r.sender,r.methodName,arguments);
        request = r;
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        if (arguments == null)
            return "null  ";
        for (int i=0;i<arguments.length;i++)
            if (arguments[i] == null)
                sb.append("null  ");
            else
                sb.append(arguments[i].toString()+"  ");
        return sb.toString();
    }
}
