package ac.hiu.j314.elmve;

import java.rmi.*;
import java.rmi.registry.*;

public class ElmRMIRegistry {
    protected static Registry registry;

    public static void main(String args[]) {
        try {
            registry = LocateRegistry.createRegistry(1099);
            System.out.println("RMIRegistry is created.");
        } catch(RemoteException ee) {
            System.out.println("RMIRegistry has already run.");
        }
    }
}
