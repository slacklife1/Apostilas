package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.clients.*;
import ac.hiu.j314.a23.*;
import javax.media.j3d.*;

public class Action3DUI extends Elm3DUI {
    protected Action3D a3;
    protected String label = null;// not implemented yet!

    public void init(Elm3DData data) {
        try {
            a3 = A3Loader.load(data.getString(0));
        } catch (Exception e) {
            e.printStackTrace();
        }
        a3.change(data.get(1));
        label = data.getString(2);
        setInterpolate(data.getBoolean(3));
    }

    public void update(Elm3DData d) {
        if (a3 == null) {
System.out.println("Action3DUI.update(). gaha!!!");
            return;
        }
        a3.change(d.get(0));
    }

    public javax.media.j3d.Node getSceneGraph() {
    	Transform3D t = new Transform3D();
    	t.rotX(1.57);
    	TransformGroup tg = new TransformGroup(t);
    	tg.addChild(a3.getNode());
        return tg;
    }
}
