package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;

class ElmEditor extends JPanel implements ActionListener {
    private static final long serialVersionUID = 1L;
    ElmClient client;
    JButton northButton;
    JButton southButton;
    JButton westButton;
    JButton eastButton;
    JButton expandButton;
    JButton reduceButton;
    JButton upButton;
    ElmMonitor monitor;
    MyMouseAdapter myMouseAdapter;
    MyMouseMotionAdapter myMouseMotionAdapter;

    int mode;
    static final int RUN_MODE=0;
    static final int EDIT_MODE=1;
    static final int MOVE_MODE=2;
    static final int CUSTOMIZE_MODE=3;
    static final int CONNECT_MODE=4;
    static final int SELECT_MODE=5;
    static final int SCALE_MODE=6;
    static final int NODE_ADD_MODE=7;
    static final int NODE_DEL_MODE=8;

    ElmEditor(ElmClient client,boolean b1,boolean b2) {
        this.client = client;
        setLayout(new BorderLayout());
        myMouseAdapter = new MyMouseAdapter();
        myMouseMotionAdapter = new MyMouseMotionAdapter();

        monitor = new ElmMonitor(client);

        Box box = Box.createHorizontalBox();
        JPanel panel = new JPanel(new BorderLayout());

        if (b1) {
            expandButton = new JButton("Expand");
            expandButton.addActionListener(this);
            box.add(expandButton);
            reduceButton = new JButton("Reduce");
            reduceButton.addActionListener(this);
            box.add(reduceButton);
            upButton = new JButton("Up");
            upButton.addActionListener(this);
            box.add(upButton);
            add(box,"North");
        }

        if (b2) {
            northButton = new JButton("^");
            northButton.addActionListener(this);
            panel.add(northButton,"North");
            southButton = new JButton("v");
            southButton.addActionListener(this);
            panel.add(southButton,"South");
            westButton = new JButton("<");
            westButton.addActionListener(this);
            panel.add(westButton,"West");
            eastButton = new JButton(">");
            eastButton.addActionListener(this);
            panel.add(eastButton,"East");
        }

        panel.add(monitor,"Center");

        add(panel,"Center");

        mode = EDIT_MODE;
setDoubleBuffered(true);//??
    }

//    void downToAnime(ElmSet a) {
//        Graphics g = monitor.getGraphics();
//        Rectangle r1 = monitor.getBounds();
//        Rectangle r2 = a.getBounds();
//        for (int i=1;i<30;i++) {
//try{Thread.sleep(10);}catch(Exception e){;}
//            int ax = (30-i)*r2.x/30;
//            int ay = (30-i)*r2.y/30;
//            int bx = (30-i)*r2.width /30 + i*r1.width /30;
//            int by = (30-i)*r2.height/30 + i*r1.height/30;
//            g.drawRect(ax,ay,bx,by);
//        }
//        g.dispose();
//    }

    public void saveImage(File file) throws IOException {
        monitor.saveImage(file);
    }

//----------------------------------------------------------------------

    Rectangle rec;
    int firstX,firstY;
    int preX,preY;
    Elm2DUI selectedElm;
    class MyMouseAdapter extends MouseAdapter {
        public void mousePressed(MouseEvent e) {
            switch (mode) {
            case EDIT_MODE:
                if ((e.getModifiers() & InputEvent.BUTTON3_MASK)!=0) {
                    firstX=preX=e.getX();
                    firstY=preY=e.getY();
                    selectedElm = monitor.getElmAt(firstX,firstY);
                    if (selectedElm==null) {
                        mode = SELECT_MODE;
                    } else {
                        Graphics g = monitor.getMonitorGraphics();
                        g.setXORMode(Color.white);
                        g.drawLine(firstX,firstY,firstX,firstY);
                        g.dispose();
                        mode = CONNECT_MODE;
                    }
               } else {
                    preX= e.getX();
                    preY= e.getY();
                    selectedElm = monitor.getElmAt(preX,preY);
                    if (selectedElm==null) {
                        mode = SELECT_MODE;
                    } else {
                        rec = ((JComponent)selectedElm).getBounds();
                        Graphics g = monitor.getMonitorGraphics();
                        g.setXORMode(Color.white);
                        g.drawRect(rec.x,rec.y,rec.width,rec.height);
                        g.dispose();
                        mode = MOVE_MODE;
                    }
                }
                break;
            case SCALE_MODE:
                break;
            }
        }

        public void mouseClicked(MouseEvent e) {
            switch (mode) {
            case EDIT_MODE:
                if (e.getClickCount()==2) {
                    Elm2DUI a = monitor.getElmAt(e.getX(),e.getY());
                    if ((e.getModifiers() & InputEvent.BUTTON1_MASK)!=0) {
//                        if (a==null)
//                            a = monitor.getBackGround();
//                        a.interruption=true;
//                        mode = CUSTOMIZE_MODE;
                        sendCommand("openCustomizer "+a.getElm().getName());
//                        mode = EDIT_MODE;
//                        receiver.drawRequest = true;

                    } else if ((e.getModifiers() & InputEvent.BUTTON3_MASK)!=0) {
                        if (a.isSet()) {
//                            downToAnime((ElmSet)a);
                            sendCommand("cd "+a.getElm().getName());
                        }
                    }
                } else {
                    if ((e.getModifiers() & InputEvent.BUTTON2_MASK)==0) return;
                    Elm2DUI a = monitor.getElmAt(e.getX(),e.getY());
                    if (a==null) {
                        double xyz[] = new double[3];
                        monitor.pointToPlace(e.getX(),e.getY()).get(xyz);
                        sendCommand("touchAuto "+xyz[0]+" "+xyz[1]);
                    } else {
                        sendCommand("rm "+a.getElm().getName());
                    }
                    mode = EDIT_MODE;
                }
                break;
            }
        }

        public void mouseReleased(MouseEvent e) {
            Graphics g = monitor.getMonitorGraphics();
            switch (mode) {
            case MOVE_MODE:
                g.setXORMode(Color.white);
                g.drawRect(rec.x,rec.y,rec.width,rec.height);
                Point mp = new Point(rec.x+rec.width/2,rec.y+rec.height/2);
                double xyz[] = new double[3];
                monitor.pointToPlace(mp).get(xyz);
                sendCommand("locate "+selectedElm.getElm().getName()+" "
                                          +xyz[0]+" "+xyz[1]);
                mode = EDIT_MODE;
                break;
            case CONNECT_MODE:
                g.setXORMode(Color.white);
                g.drawLine(firstX,firstY,preX,preY);
                Elm2DUI comp2 = monitor.getElmAt(e.getX(),e.getY());
                if (comp2 != null) {
                    sendCommand("connectNodes "
                                +comp2.getElm().getName()+" "
                                +selectedElm.getElm().getName());
                }
                mode = EDIT_MODE;
                break;
            case SELECT_MODE:
                mode = EDIT_MODE;
                break;
            }
            g.dispose();
        }
    }

    class MyMouseMotionAdapter extends MouseMotionAdapter {
        public void mouseDragged(MouseEvent e) {
            Graphics g = monitor.getMonitorGraphics();
            switch (mode) {
            case MOVE_MODE:
                g.setXORMode(Color.white);
                g.drawRect(rec.x,rec.y,rec.width,rec.height);
                rec = new Rectangle(rec.x+(e.getX()-preX),
                                rec.y+(e.getY()-preY),rec.width,rec.height);
                preX=e.getX();
                preY=e.getY();
                g.drawRect(rec.x,rec.y,rec.width,rec.height);
                break;
            case CONNECT_MODE:
                g.setXORMode(Color.white);
                g.drawLine(firstX,firstY,preX,preY);
                preX=e.getX();
                preY=e.getY();
                g.drawLine(firstX,firstY,preX,preY);
                break;
            }
            g.dispose();
        }
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == expandButton) {
            monitor.expand();
        } else if (e.getSource() == reduceButton) {
            monitor.reduce();
        } else if (e.getSource() == upButton) {
            sendCommand("cd ..");
        } else if (e.getSource() == northButton) {
            monitor.north();
        } else if (e.getSource() == southButton) {
            monitor.south();
        } else if (e.getSource() == westButton) {
            monitor.west();
        } else if (e.getSource() == eastButton) {
            monitor.east();
        }
    }

    public void processElm2DPacket(Elm2DPacket elm2DPacket) {
        monitor.processElm2DPacket(elm2DPacket,this);
    }

//    public void doLayout() {
//        super.doLayout();
//        monitor.doLayout();
//    }

    protected void sendCommand(ElmStub e,String methodName,
                               Serializable args[]) {
        client.relayOrder(e,methodName,args);
    }
    protected void sendCommand(ElmStub e,String methodName,Serializable arg) {
        Serializable args[] = {arg};
        client.relayOrder(e,methodName,args);
    }
    protected void sendCommand(String command) {
        try {
            ((ElmClient)client).processCommand(command);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

//----------------------------------------------------------------------

    public void setVisibleB1(boolean b) {
        expandButton.setVisible(b);
        reduceButton.setVisible(b);
        upButton.setVisible(b);
    }

    public void setVisibleB2(boolean b) {
        northButton.setVisible(b);
        southButton.setVisible(b);
        westButton.setVisible(b);
        eastButton.setVisible(b);
    }
}
