package ac.hiu.j314.elmve;

import java.io.*;

class LogWriter extends PrintWriter {
    public LogWriter() {
        super(System.out,true);
    }
}
