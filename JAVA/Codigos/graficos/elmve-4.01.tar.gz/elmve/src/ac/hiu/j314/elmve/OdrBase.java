package ac.hiu.j314.elmve;

import java.io.Serializable;

public class OdrBase extends Message {
    private static final long serialVersionUID = 1L;

    OdrBase (ElmStub sender, ElmStub receiver,
             String methodName,Serializable arguments[]) {
        super(sender,receiver,methodName,arguments);
    }
}
