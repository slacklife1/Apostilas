package ac.hiu.j314.elmve.graph;

import ac.hiu.j314.elmve.*;
import java.util.*;

public class Graph extends Elm {
    private static final long serialVersionUID = 1L;
    ArrayList<Line> lines;

    protected String elm2DBGClass()
        {return "ac.hiu.j314.elmve.graph.Graph2DBG";}
    protected String elm3DBGClass()
        {return "ac.hiu.j314.elmve.graph.Graph3DBG";}
    protected String elmLightBGClass()
        {return "ac.hiu.j314.elmve.graph.GraphLightBG";}

    public void get2DBGData(MyRequest r) {
        ElmSet nodes = getElmsInside("@ac.hiu.j314.elmve.graph.Link");
        nodes.addAll(getElmsInside("@ac.hiu.j314.elmve.graph.SNode"));
        if (nodes.size()==0) {
            lines = new ArrayList<Line>();
            send(makeReply(r,lines));
            return;
        }
        ReqSet reqs = makeMyRequest(nodes,"getLines",NULL);
        receive(reqs,"get2DBGData2",r);
        send(reqs);
    }
    public void get2DBGData2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);

        lines = new ArrayList<Line>();
        for (int i=0;i<rs.getReplyCount();i++) {
            Object o = rs.get(i,0);
            if (o instanceof ArrayList) {
//              lines.addAll((ArrayList<Line>)o); // <--なんでだめ？gaha
                for (Object line : (ArrayList)o) {
                    lines.add((Line)line);
                }
            } else
                lines.add((Line)o);
        }
        send(makeReply(r,lines));
    }
    public void get2DBGRepaintData(MyRequest r) {
        ElmSet nodes = getElmsInside("@ac.hiu.j314.elmve.graph.Link");
        nodes.addAll(getElmsInside("@ac.hiu.j314.elmve.graph.SNode"));
        if (nodes.size()==0) {
            lines = new ArrayList<Line>();
            send(makeReply(r,lines));
            return;
        }
        ReqSet reqs = makeMyRequest(nodes,"getLines",NULL);
        receive(reqs,"get2DBGRepaintData2",r);
        send(reqs);
    }
    public void get2DBGRepaintData2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);

        lines = new ArrayList<Line>();
        for (int i=0;i<rs.getReplyCount();i++) {
            Object o = rs.get(i,0);
            if (o instanceof ArrayList) {
//                lines.addAll((ArrayList<Line>)o); <-- gaha
                for (Object line : (ArrayList)o)
                    lines.add((Line)line);
            } else
                lines.add((Line)o);
        }

        send(makeReply(r,lines));
    }

    public void get3DBGData(MyRequest r) {
        ElmSet nodes = getElmsInside("@ac.hiu.j314.elmve.graph.Link");
        nodes.addAll(getElmsInside("@ac.hiu.j314.elmve.graph.SNode"));
        if (nodes.size()==0) {
            lines = new ArrayList<Line>();
            send(makeReply(r,lines));
            return;
        }
        ReqSet reqs = makeMyRequest(nodes,"getLines",NULL);
        receive(reqs,"get3DBGData2",r);
        send(reqs);
    }
    public void get3DBGData2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);

        lines = new ArrayList<Line>();
        for (int i=0;i<rs.getReplyCount();i++) {
            Object o = rs.get(i,0);
            if (o instanceof ArrayList) {
//                lines.addAll((ArrayList<Line>)o); <-- gaha
                for (Object line : (ArrayList)o)
                    lines.add((Line)line);
            } else
                lines.add((Line)o);
        }

        send(makeReply(r,lines));
    }
    public void get3DBGRepaintData(MyRequest r) {
        ElmSet nodes = getElmsInside("@ac.hiu.j314.elmve.graph.Link");
        nodes.addAll(getElmsInside("@ac.hiu.j314.elmve.graph.SNode"));
        if (nodes.size()==0) {
            lines = new ArrayList<Line>();
            send(makeReply(r,lines));
            return;
        }
        ReqSet reqs = makeMyRequest(nodes,"getLines",NULL);
        receive(reqs,"get3DBGRepaintData2",r);
        send(reqs);
    }
    public void get3DBGRepaintData2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);

        lines = new ArrayList<Line>();
        for (int i=0;i<rs.getReplyCount();i++) {
            Object o = rs.get(i,0);
            if (o instanceof ArrayList) {
//                lines.addAll((ArrayList)o); // <-- gaha
                for (Object line : (ArrayList)o)
                    lines.add((Line)line);
            } else
                lines.add((Line)o);
        }

        send(makeReply(r,lines));
    }

    public void getLightBGData(MyRequest r) {
        ElmSet nodes = getElmsInside("@ac.hiu.j314.elmve.graph.Link");
        nodes.addAll(getElmsInside("@ac.hiu.j314.elmve.graph.SNode"));
        if (nodes.size()==0) {
            lines = new ArrayList<Line>();
            send(makeReply(r,lines));
            return;
        }
        ReqSet reqs = makeMyRequest(nodes,"getLines",NULL);
        receive(reqs,"getLightBGData2",r);
        send(reqs);
    }
    public void getLightBGData2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);

        lines = new ArrayList<Line>();
        for (int i=0;i<rs.getReplyCount();i++) {
            Object o = rs.get(i,0);
            if (o instanceof ArrayList) {
//                lines.addAll((ArrayList<Line>)o); // <-- gaha
                for (Object line : (ArrayList)o)
                    lines.add((Line)line);
            } else
                lines.add((Line)o);
        }

        send(makeReply(r,lines));
    }
    public void getLightBGRepaintData(MyRequest r) {
        ElmSet nodes = getElmsInside("@ac.hiu.j314.elmve.graph.Link");
        nodes.addAll(getElmsInside("@ac.hiu.j314.elmve.graph.SNode"));
        if (nodes.size()==0) {
            lines = new ArrayList<Line>();
            send(makeReply(r,lines));
            return;
        }
        ReqSet reqs = makeMyRequest(nodes,"getLines",NULL);
        receive(reqs,"getLightBGRepaintData2",r);
        send(reqs);
    }
    public void getLightBGRepaintData2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);

        lines = new ArrayList<Line>();
        for (int i=0;i<rs.getReplyCount();i++) {
            Object o = rs.get(i,0);
            if (o instanceof ArrayList) {
//                lines.addAll((ArrayList<Line>)o); // <-- gaha
                for (Object line : (ArrayList)o)
                    lines.add((Line)line);
            } else
                lines.add((Line)o);
        }

        send(makeReply(r,lines));
    }
}
