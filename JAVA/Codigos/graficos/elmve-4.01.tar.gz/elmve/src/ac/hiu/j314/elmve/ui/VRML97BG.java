package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.clients.*;
import java.net.*;
import javax.media.j3d.*;

//import org.cybergarage.x3d.j3d.loader.*;
import org.web3d.j3d.loaders.VRML97Loader;
import com.sun.j3d.loaders.Scene;

public class VRML97BG extends Elm3DBG {
    protected String source;
    static Scene dummyScene;

    public void init(Elm3DData d) {
        source = d.getString(0);
    }

    public Node getSceneGraph() {
        return getScene().getSceneGroup();
    }

    public Scene getScene() {
        VRML97Loader loader = new VRML97Loader();
        Scene scene = null;
        try {
            URL loadUrl = W.getResource(source);
            scene = loader.load(loadUrl);
        } catch (Exception ee) {
            ee.printStackTrace();
        }
        if (scene == null) {
            System.out.println("Error!");
            return getDummyScene();
        }
        return scene;
    }

    public void update(Elm3DData d) {
        ;
    }

    protected Scene getDummyScene() {
        if (dummyScene == null) {
            try {
                VRML97Loader loader = new VRML97Loader();
                URL loadUrl = W.getResource("x-res:///ac/hiu/j314/elmve/ui/resources/error.wrl");
                dummyScene = loader.load(loadUrl);
            } catch(Exception e) {
                e.printStackTrace();
            }
        }
        return dummyScene;
    }
}
