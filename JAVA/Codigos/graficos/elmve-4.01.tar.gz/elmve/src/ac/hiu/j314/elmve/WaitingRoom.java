package ac.hiu.j314.elmve;

import java.io.*;

class WaitingRoom implements Serializable {
    private static final long serialVersionUID = 1L;

    void room() {
        try {wait();}catch(Exception e){;}
    }

    void bell() {
        notifyAll();
    }
}
