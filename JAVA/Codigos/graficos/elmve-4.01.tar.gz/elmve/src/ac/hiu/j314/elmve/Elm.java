package ac.hiu.j314.elmve;

import ac.hiu.j314.elmve.clients.*;
import java.io.*;
import java.util.*;
import java.lang.reflect.*;
import java.net.*;
import org.w3c.dom.*;

/**
 * Elm is most important class in ELM-VE package.
 * 
 */

public class Elm implements Serializable {
    private static final long serialVersionUID = 1L;
    static Timer timer = new Timer();
    static int uiTimer;
    static final int SUSPENDED = 0;
    static final int RUNNING = 1;
    public static final Serializable NULL = "NULL";
    public static final Serializable OK = "OK";
    public static final Serializable ERROR = "ERROR";

    protected static final ElmACL ANT = new ElmACL(ElmACL.ANT);
    protected static final ElmACL APE = new ElmACL(ElmACL.APE);
    protected static final ElmACL BAT = new ElmACL(ElmACL.BAT);
    protected static final ElmACL BEE = new ElmACL(ElmACL.BEE);
    protected static final ElmACL CAT = new ElmACL(ElmACL.CAT);
    protected static final ElmACL COW = new ElmACL(ElmACL.COW);
    protected static final ElmACL DOG = new ElmACL(ElmACL.DOG);
    protected static final ElmACL ELK = new ElmACL(ElmACL.ELK);
    protected static final ElmACL FLY = new ElmACL(ElmACL.FLY);
    protected static final ElmACL FOX = new ElmACL(ElmACL.FOX);
    protected static final ElmACL GNU = new ElmACL(ElmACL.GNU);
    protected static final ElmACL HEN = new ElmACL(ElmACL.HEN);
    protected static final ElmACL OWL = new ElmACL(ElmACL.OWL);
    protected static final ElmACL PIG = new ElmACL(ElmACL.PIG);
    protected static final ElmACL RAT = new ElmACL(ElmACL.RAT);
    protected static final ElmACL YAK = new ElmACL(ElmACL.YAK);

    ElmStub stub = null;
    final Place place = new Place();
    final Rotation rotation = new Rotation();
    ArrayList<Message> messages;
    ArrayList<ReplySet> replySets;
    ElmStub parent;
    ArrayList<Elm> children = null;
    transient protected CustomizerStack customizerStack = null;
    transient Engine engine = null;
    boolean ownEngine = false;
    boolean interruption = false;
    int updateTime;
    volatile int status = RUNNING;
    WaitingRoom wr = new WaitingRoom();

    protected Elm() {
        stub = new ElmStub(this);
        messages = new ArrayList<Message>();
        replySets = new ArrayList<ReplySet>();
    }

    protected void init() {
    }
    void recursiveInit() {
        if (children!=null) {
            Iterator i = children.iterator();
            while (i.hasNext())
                ((Elm)i.next()).recursiveInit();
        }
        init();
    }

    void regenerateElmStub() {
        ElmStub oldStub = stub;
        stub = new ElmStub(this);
        stub.name = oldStub.name;
        stub.owner = oldStub.owner;
    }
    void recursiveRegenerateElmStub() {
        regenerateElmStub();
        if (children!=null) {
            Iterator i = children.iterator();
            while (i.hasNext())
                ((Elm)i.next()).recursiveRegenerateElmStub();
        }
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        double xyz[] = new double[3];
        place.get(xyz);
        sb.append("ELM Object name="+stub.name+" ID="+stub.elmID+" statuc="
                  +(status==SUSPENDED?"SUSPENDED":"RUNNING")+"\n");
        sb.append(" X="+xyz[0]+", Y="+xyz[1]+", Z="+xyz[2]+"\n");
        sb.append(" Class:"+stub.className+"\n");
        sb.append(" path :"+getFullPath()+"\n");
        sb.append(" owner:"+stub.owner+"\n");
        sb.append(" role :"+stub.role+"\n");
        if (children != null)
            sb.append(" I have "+children.size()+" children.\n");
        return sb.toString();
    }
    public void toString(Request r) {
        send(makeReply(r,toString()));
    }

//-------------------------------------------
// Methods for internal use
//-------------------------------------------

    void setEngine(Engine e) {
        if (!ownEngine) {
            engine = e;
        }
    }

    void refreshElm() {
        if (engine==null)
            setEngine(parent.elm.engine);
    }
    void recursiveRefreshElm() {
        this.refreshElm();
        if (children!=null) {
            Iterator i = children.iterator();
            while (i.hasNext()) {
                Elm e = (Elm)i.next();
                e.parent = this.stub;
                e.recursiveRefreshElm();
            }
        }
    }

    protected ElmStub getStub() {
        return this.stub;
    }

    void resume() {
        if (status != SUSPENDED)
            return;
        if (interruption) {
            processInterruption();
            interruption = false;
        }
        engine.resume();
    }

    void suspend() {
        if (status == SUSPENDED)
            return;
        engine.suspend();
    }

    void processInterruption() {
    }

// Methos for process messages (important!)

    void receiveMessage(Message m) {
        boolean b = false;
        synchronized (wr) {
            if (m instanceof Reply) {
                Iterator i = replySets.iterator();
                while (i.hasNext()) {
                    ReplySet rep = (ReplySet)i.next();
                    if (rep.setReply((Reply)m)) {
                        if (rep.isReady()) {
                            replySets.remove(rep);
                            messages.add(rep);
                            b = true;
                        }
                        break;
                    }
                }
            } else {
                messages.add(m);
                b = true;
            }
        }
        if (b) engine.take(this);
    }

    void processOneMessage() {
        Message m = selectMessage();
        if (m == null) {
            return;
        }
        try {
            String methodName = m.getMethodName();
            Object[] oo = {m};
            Class[] arg = {m.getClass()};
            Method method = getClass().getMethod(methodName,arg);
            method.invoke(this,oo);
        } catch(NoSuchMethodException e) {
            ElmStub sender = m.getSender();
//          ElmVE.elmVE.logOut.print(sender.getName()+" sent a message named ");
//          ElmVE.elmVE.logOut.print("\""+m.getMethodName()+"(");
//          ElmVE.elmVE.logOut.print(m.getClass().getName()+")\" ");
//          ElmVE.elmVE.logOut.print("to me("+stub.name+"). ");
//          ElmVE.elmVE.logOut.println("But I don't have such method.");
            System.out.print(sender.getName()+" sent a message named ");
            System.out.print("\""+m.getMethodName()+"(");
            System.out.print(m.getClass().getName()+")\" ");
            System.out.print("to me("+stub.name+"). ");
            System.out.println("But I don't have such method.");
            if (m instanceof ReqBase)
                send(makeReply((ReqBase)m,NULL));
            return;
        } catch (InvocationTargetException e) {
            ElmVE.elmVE.logOut.print("Exception occurred in "+stub.name);
            ElmVE.elmVE.logOut.print("\'s method named "+m.getMethodName()+".");
            Throwable ta = e.getTargetException();
            ta.printStackTrace();
            if (m instanceof ReqBase)
                send(makeReply((ReqBase)m,NULL));
        } catch (IllegalAccessException e) {
            e.printStackTrace();
            if (m instanceof ReqBase)
                send(makeReply((ReqBase)m,NULL));
        }
    }

    protected Message selectMessage() {
        synchronized (wr) {
            if (messages.size()==0)
                return null;
            Message m = (Message)messages.remove(0);
            return m;
        }
    }

// Methods for process children.

    void addElm(ElmStub e) {
        if (children == null)
            children = new ArrayList<Elm>();
        synchronized (children) {
            e.elm.parent=this.stub;
            e.elm.setEngine(engine);
            e.elm.updateTime=Elm.uiTimer;
            if (e.elm.parent.elm.parent==null)
                e.path=getIDPath()+"#"+e.elmID;
            else
                e.path=getIDPath()+"/#"+e.elmID;
            children.add(e.elm);
            ElmVE.elmVE.putElm(e);
        }
    }

    void delElm(ElmStub es) {
        try {
            synchronized (children) {
                children.remove(es.elm);
                ElmVE.elmVE.removeElm(es);
            }
        } catch (NullPointerException e) {
            return;
        }
    }

    void cleanChildren() {
        try {
            synchronized (children) {
                while (children.size()!=0) {
                    Elm e = (Elm)children.remove(0);
                    ElmVE.elmVE.removeElm(e.stub);
                }
            }
        } catch (NullPointerException e) {
            return;
        }
    }

// Methods for retrieving ELM objects

    ElmSet getLocalElms(String uri) {
        uri = uri.trim();
        if (uri.equals("/")) {
            ElmSet ret = new ElmSet();
            ret.add(ElmVE.elmVE.topElm);
            return ret;
        } else if (uri.equals(".") && (parent!=null)) {
            ElmSet ret = new ElmSet();
            ret.add(parent);
            return ret;
        } else if (uri.equals("..") && (parent!=null)
                   && (parent.elm.parent!=null)) {
            ElmSet ret = new ElmSet();
            ret.add(parent.elm.parent);
            return ret;
        } else if (uri.startsWith("/")) {
            uri = uri.substring(1);
            return ElmVE.elmVE.topElm.elm.getElmsRecursively(uri);
        } else if (uri.startsWith("../") && (parent!=null)
                   && (parent.elm.parent!=null)) {
            uri = uri.substring(3);
            return parent.elm.parent.elm.getElmsRecursively(uri);
        } else if (parent != null) {
            if (uri.startsWith("./"))
                uri = uri.substring(2);
            return parent.elm.getElmsRecursively(uri);
        } else {
System.out.println(parent == null);
System.out.println("'"+uri+"'");
            return null;
        }
    }

    ElmSet getElmsRecursively(String uri) {
        String s1 = null;
        String s2 = null;
        if (uri.indexOf('/') == -1) {
            s1 = uri;
        } else {
            s1 = uri.substring(0,uri.indexOf('/'));
            s2 = uri.substring(uri.indexOf('/')+1,uri.length());
        }
        if (children==null)
            return new ElmSet();
        synchronized (children) {
            ElmSet ret = new ElmSet();
            Iterator i = children.iterator();
            if (s1.equals("*")) {
                while (i.hasNext()) {
                    Elm elm = (Elm)i.next();
                    if (s2 == null)
                        ret.add(elm.stub);
                    else
                        ret.addAll(elm.getElmsRecursively(s2));
                }
            } else if (s1.startsWith("@")) {
                String cName = s1.substring(1);
                while (i.hasNext()) {
                    Elm elm = (Elm)i.next();
                    if (elm.stub.instanceOf(cName))
                        if (s2 == null)
                            ret.add(elm.stub);
                        else
                            ret.addAll(elm.getElmsRecursively(s2));
                }
            } else if (s1.startsWith("#")) {
                long eid = Long.parseLong(s1.substring(1));
                while (i.hasNext()) {
                    Elm elm = (Elm)i.next();
                    if (elm.stub.elmID == eid)
                        if (s2 == null)
                            ret.add(elm.stub);
                        else
                            ret.addAll(elm.getElmsRecursively(s2));
                }
            } else {
                while (i.hasNext()) {
                    Elm elm = (Elm)i.next();
                    if (s1.equals(elm.getName()))
                        if (s2 == null)
                            ret.add(elm.stub);
                        else
                            ret.addAll(elm.getElmsRecursively(s2));
                }
            }
            return ret;
        }
    }
    
    ElmStub getLocalElm(String uri) {
        ArrayList al = getLocalElms(uri);
        if (al.size() != 0) {
            return (ElmStub)al.get(0);
        } else {
            return null;
        }
    }

    protected String getPath() {
        if (parent==null)
            return "/";
        else
            if (parent.elm.parent == null)
                return "/"+stub.name;
            else
                return parent.elm.getPath()+"/"+stub.name;
    }

    protected String getFullPath() {
        return ElmVE.elmVE.thisServer.uri+getPath();
    }

    protected String getIDPath() {
        return stub.path;
    }

    protected ElmSet getNearestElms(int no,String className) {
        return parent.elm.getNearestLocalElms(this,no,className);
    }

    ElmSet getNearestLocalElms(Elm elm,int no,String className) {
        Class c = null;
        try {
            c = ElmVE.classLoader.loadClass(className);
        } catch(Exception e) {
            return null;
        }
        Place p1 = new Place();
        Place p2 = new Place();
        Elm le = null;
        ElmSet ret = new ElmSet();
        for (int i=0;i<no;i++) {
            double dd = Double.MAX_VALUE;
            Iterator ii = children.iterator();
            while (ii.hasNext()) {
                Elm e2 = (Elm)ii.next();
                if (e2 == elm)
                    continue;
                if (!c.isInstance(e2))
                    continue;
                if (ret.contains(e2.stub))
                    continue;
                elm.getPlace(p1);
                e2.getPlace(p2);
                double ddd = p1.distanceSquared(p2);
                if (ddd < dd) {
                    le = e2;
                    dd = ddd;
                }
            }
            if (le!=null)
                ret.add(le.stub);
            else
                ret.add(null);
        }
        return ret;
    }

    protected ElmSet getNeighborElms(double d,String className) {
        return parent.elm.getNeighborLocalElms(this,d,className);
    }

    ElmSet getNeighborLocalElms(Elm elm,double d,String className) {
        Class c = null;
        try {
            c = ElmVE.classLoader.loadClass(className);
        } catch(Exception e) {
            return null;
        }
        Place p1 = new Place();
        Place p2 = new Place();
        elm.getPlace(p1);
        ElmSet ret = new ElmSet();
        Iterator ii = children.iterator();
        while (ii.hasNext()) {
            Elm e2 = (Elm)ii.next();
            if (e2 == elm)
                continue;
            if (!c.isInstance(e2))
                continue;
            e2.getPlace(p2);
            double ddd = p1.distanceSquared(p2);
            if (ddd < d)
                ret.add(e2.stub);
        }
        return ret;
    }

// Methods to save or load ELM objects data.

    /**
      * saveAsXML(fileName)
      */
    void saveAsXML(String fileName) throws Exception {
        try {
            if (fileName.startsWith("file:"))
                fileName = fileName.substring(5);
//            File f = new File(fileName);
//            f.createNewFile();
            FileOutputStream fos
                = new FileOutputStream(fileName);
            saveAsXML(fos);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
      * saveAsXML(OutputStream)
      */
    void saveAsXML(OutputStream os) {
        try {
            Document d = W.makeEmptyDocumentDOM();
            Element e = W.makeElementDOM(d,"elmData");
            W.addChildDOM(d,e);
            W.addLineFeedDOM(d,e);

            ArrayList al = getAllDescendants(new ArrayList<Elm>());
            Iterator i = al.iterator();
            while (i.hasNext()) {
                Elm elm = (Elm)i.next();
                if (elm.stub.instanceOf("ac.hiu.j314.elmve.EcoElm"))
                    if (((EcoElm)elm).areChildrenSleeping==true)
                        ((EcoElm)elm).wakeChildrenUp();
            }
            al = getAllDescendants(new ArrayList<Elm>());
            i = al.iterator();
            while (i.hasNext()) {
                Elm elm = (Elm)i.next();
                if (elm.stub.instanceOf("ac.hiu.j314.elmve.NeverSave"))
                    continue;
                Element ee = W.makeElementDOM(d,"elm");
                W.addChildDOM(e,ee);
                if (elm==this)
                    W.addAttrDOM(d,ee,"rootElm","true");
                elm.saveAsXML(d,ee);
                W.addLineFeedDOM(d,e);
            }

            W.saveDocumentToOutputStreamDOM(d,os);
        } catch(Exception e) {
	    e.printStackTrace();
        }
    }

    void saveElmSetAsXML(ArrayList elms,String fileName) throws Exception {
        try {
            if (fileName.startsWith("file:"))
                fileName = fileName.substring(5);
            FileOutputStream fos
                = new FileOutputStream(fileName);
            saveElmSetAsXML(elms,fos);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    void saveElmSetAsXML(ArrayList elms,OutputStream os) {
        try {
            Document d = W.makeEmptyDocumentDOM();
            Element e = W.makeElementDOM(d,"elmData");
            W.addChildDOM(d,e);
            W.addLineFeedDOM(d,e);

            ArrayList<Elm> al = new ArrayList<Elm>();
            Iterator i = elms.iterator();
            while (i.hasNext()) {
                ElmStub es = (ElmStub)i.next();
                al.addAll(es.elm.getAllDescendants(new ArrayList<Elm>()));
            }
            i = al.iterator();
            while (i.hasNext()) {
                Elm elm = (Elm)i.next();
                if (elm.stub.instanceOf("ac.hiu.j314.elmve.EcoElm"))
                    if (((EcoElm)elm).areChildrenSleeping==true)
                        ((EcoElm)elm).wakeChildrenUp();
            }
            al = new ArrayList<Elm>();
            i = elms.iterator();
            while (i.hasNext()) {
                ElmStub es = (ElmStub)i.next();
                al.addAll(es.elm.getAllDescendants(new ArrayList<Elm>()));
            }
            i = al.iterator();
            while (i.hasNext()) {
                Elm elm = (Elm)i.next();
                if (elm.stub.instanceOf("ac.hiu.j314.elmve.NeverSave"))
                    continue;
                Element ee = W.makeElementDOM(d,"elm");
                W.addChildDOM(e,ee);
                if (elms.contains(elm.stub))
                    W.addAttrDOM(d,ee,"rootElm","true");
                elm.saveAsXML(d,ee);
                W.addLineFeedDOM(d,e);
            }

            W.saveDocumentToOutputStreamDOM(d,os);
        } catch(Exception e) {
	    e.printStackTrace();
        }
    }

    /**
      * saveAsText(fileName)
      */
    void saveAsText(String fileName) throws IOException {
        if (fileName.startsWith("file:"))
            fileName = fileName.substring(5);
        FileWriter writer = new FileWriter(fileName);
        PrintWriter f_out = new PrintWriter(writer);

        f_out.print(this.toSaveString());
        f_out.close();
    }

    /**
      * saveAsText(PrintWriter)
      */
    void saveAsText(PrintWriter f_out) throws IOException {
        f_out.print(this.toSaveString());
    }

//-------------------------------------------
// Methods that can be used subclass.
//-------------------------------------------

    protected void initOwnEngine(String name,int i) {
        engine = new Engine1(name,i);
        ownEngine = true;
    }

    protected void setName(String name) {
        this.stub.name = name;
        repaint();
    }

    protected String getName() {
        return stub.name;
    }

    protected long getElmID() {
        return stub.elmID;
    }

    protected void setPlace(Place p) {
        this.place.set(p);
        repaint();
    }

    protected void setPlace(double xyz[]) {
        this.place.set(xyz);
        repaint();
    }

    protected void getPlace(Place p) {
        p.set(this.place);
    }

    protected void getPlace(double xyz[]) {
        this.place.get(xyz);
    }

    protected Place getPlace() {
        return new Place(place);
    }

    protected void getPlace(ElmStub e,Place p) {
        p.set(e.elm.place);
    }

    protected void getPlace(ElmStub e,double xyz[]) {
        e.elm.place.get(xyz);
    }

    protected Place getPlace(ElmStub e) {
        return new Place(e.elm.place);
    }

    protected void setRotation(Rotation r) {
        rotation.set(r);
        repaint();
    }

    protected void setRotation(double xyzw[]) {
        rotation.set(xyzw);
        repaint();
    }

    protected void getRotation(Rotation r) {
        r.set(this.rotation);
    }

    protected void getRotation(double xyzw[]) {
        this.rotation.get(xyzw);
    }

    protected Rotation getRotation() {
        return new Rotation(rotation);
    }

    protected void getRotation(ElmStub e,Rotation r) {
        r.set(e.elm.rotation);
    }

    protected void getRotation(ElmStub e,double xyzw[]) {
        e.elm.rotation.get(xyzw);
    }

    protected Rotation getRotation(ElmStub e) {
        return new Rotation(e.elm.rotation);
    }

    protected ElmStub getElm(String uri) {
        if (uri.startsWith("//")) {
            if (W.getElmVEPath(uri).equals(ElmVE.elmVE.thisServer.uri)) {
                uri = W.getLocalPath(uri);
                return getLocalElm(uri);
            } else {
                ArrayList al = ElmVE.elmVE.getRemoteElms(uri);
                if ((al==null)||(al.size()==0))
                    return null;
                else
                    return (ElmStub)al.get(0);
            }
        } else {
            return getLocalElm(uri);
        }
    }

    protected ElmSet getElms(String uri) {
        if (uri.startsWith("//")
            && (!W.getElmVEPath(uri).equals(ElmVE.elmVE.thisServer.uri))) {
            return ElmVE.elmVE.getRemoteElms(uri);
        } else {
            ElmSet elms = getLocalElms(uri);
            ElmSet ret = new ElmSet();
            ret.addAll(elms);
            return ret;
        }
    }

    protected ElmStub getElmInside(String uri) {
        return getElm(stub.name+"/"+uri);
    }

    protected ElmSet getElmsInside(String uri) {
        return getElms(stub.name+"/"+uri);
    }

/**
 * Prepareation for transfer
 */
    protected void prepareForTranslation() {
messages = new ArrayList<Message>();
replySets = new ArrayList<ReplySet>();
        if (children != null) {
            Iterator i = children.iterator();
            while (i.hasNext())
                ((Elm)i.next()).prepareForTranslation();
        }
    }

//-------------------------------------------
// Methods for creation of messages
//-------------------------------------------

// creation of Order messages
    protected Order makeOrder(ElmStub a, String methodName,
                              Serializable... arguments) {
        return new Order(this.stub,a,methodName,arguments);
    }

    protected Order makeOrder(String methodName,Serializable... arguments) {
        ElmStub es = this.stub;
        return new Order(es,es,methodName,arguments);
    }

    protected OdrSet makeOrder(ElmSet es, String methodName,
                               Serializable... args) {
        OdrSet ret = new OdrSet();
        Iterator i = es.iterator();
        while (i.hasNext())
            ret.add(new Order(this.stub,(ElmStub)i.next(),
                              methodName,args));
        return ret;
    }

// creation of MyOrder messages

    protected MyOrder makeMyOrder(ElmStub a, String methodName,
                                  Serializable... arguments) {
        return new MyOrder(this.stub,a,methodName,arguments);
    }

    protected MyOrder makeMyOrder(String methodName,Serializable... arguments) {
        ElmStub es = this.stub;
        return new MyOrder(es,es,methodName,arguments);
    }

    protected OdrSet makeMyOrder(ElmSet es, String methodName,
                                 Serializable... args) {
        OdrSet ret = new OdrSet();
        Iterator i = es.iterator();
        while (i.hasNext())
            ret.add(new MyOrder(this.stub,(ElmStub)i.next(),methodName,args));
        return ret;
    }

// creation of Request messages

    protected Request makeRequest(ElmStub a, String methodName,
                                  Serializable... arguments) {
        return new Request(this.stub,a,methodName,arguments);
    }

    protected Request makeRequest(String methodName,Serializable... arguments) {
        ElmStub es = this.stub;
        return new Request(es,es,methodName,arguments);
    }

    protected ReqSet makeRequest(ElmSet es, String methodName,
                                 Serializable... args) {
        ReqSet ret = new ReqSet();
        Iterator i = es.iterator();
        while (i.hasNext())
            ret.add(new Request(this.stub,(ElmStub)i.next(),methodName,args));
        return ret;
    }

// creation of MyRequest messages

    protected MyRequest makeMyRequest(ElmStub a, String methodName,
                                  Serializable... arguments) {
        return new MyRequest(this.stub,a,methodName,arguments);
    }

    protected MyRequest makeMyRequest(String methodName,
                                      Serializable... arguments) {
        ElmStub es = this.stub;
        return new MyRequest(es,es,methodName,arguments);
    }

    protected ReqSet makeMyRequest(ElmSet es, String methodName,
                                   Serializable... args) {
        ReqSet ret = new ReqSet();
        Iterator i = es.iterator();
        while (i.hasNext())
            ret.add(new MyRequest(this.stub,(ElmStub)i.next(),
                                  methodName,args));
        return ret;
    }

// creation of reply messages

    protected Reply makeReply(ReqBase request,Serializable... arguments) {
        return new Reply(request,arguments);
    }

//-------------------------------------------
// Methods for transmission messages
//-------------------------------------------

// sending messages

    protected void send(Message m) {
/*
System.out.print(m.receiver.isLocal()?"L:":"R:");
if (m instanceof MyOrder)
 System.out.print("MyOrder  :");
else if (m instanceof Order)
 System.out.print("Order    :");
else if (m instanceof MyRequest)
 System.out.print("MyRequest:");
else if (m instanceof Request)
 System.out.print("Request  :");
else if (m instanceof Reply)
 System.out.print("Reply    :");
System.out.print(m.sender.name+"->"+m.receiver.name);
System.out.print("("+m.methodName+")\n");
*/
        if (m.receiver.isLocal()) {
try {
            m.receiver.elm.receiveMessage(m);
} catch(Exception e) {
e.printStackTrace();
System.out.println(m.receiver);
}
        } else {
            ElmVE.elmVE.sendMessage(m);
        }
    }

    protected void send(Message m,long t) {
        timer.schedule(new ElmTimerTask(this,m),t);
    }

    protected void send(OdrSet os) {
        Iterator i = os.iterator();
        while (i.hasNext())
            send((Message)i.next());
    }
    protected void send(ReqSet rs) {
        Iterator i = rs.iterator();
        while (i.hasNext())
            send((Message)i.next());
    }

    protected void send(OdrSet os,long t) {
        timer.schedule(new ElmTimerTask(this,os),t);
    }
    protected void send(ReqSet rs,long t) {
        timer.schedule(new ElmTimerTask(this,rs),t);
    }

// prepare for reply

    protected void receive(ReqSet requests,String methodName,
                           Serializable... args) {
        if (requests.size()!=0)
            replySets.add(new ReplySet(this.stub,requests,methodName,args));
        else
            receiveMessage(new ReplySet(this.stub,requests,methodName,args));
    }

    protected void receive(ReqBase request,String methodName,
                                   Serializable... args) {
        replySets.add(new ReplySet(this.stub,request,methodName,args));
    }

    protected ElmStub refreshStub(ElmStub es) {
        return ElmVE.elmVE.refreshStub(es);
    }

//-------------------------------------------
// Methods for creating ELM objects
//-------------------------------------------

    protected ElmStub makeElm(String className,String name) {
        ElmStub e = ElmVE.elmVE.makeElm(className,name,stub.owner);
        e.elm.setEngine(engine);
        if (e != null) {
            parent.elm.addElm(e);
            e.elm.setPlace(this.place);
            e.elm.init();
        }
        return e;
    }

    protected ElmStub[] makeElms(String className,String names[]) {
        ElmStub e[] = ElmVE.elmVE.makeElms(className,names,stub.owner);
        for (int i=0;i<e.length;i++) {
            if (e[i] != null) {
                parent.elm.addElm(e[i]);
                e[i].elm.setPlace(this.place);
                e[i].elm.init();
            }
        }
        return e;
    }

    protected ElmStub makeElmInside(String className,String name) {
        ElmStub e = ElmVE.elmVE.makeElm(className,name,stub.owner);
        if (e != null) {
            addElm(e);
            e.elm.setPlace(this.place);
            e.elm.init();
        }
        return e;
    }

    protected ElmStub[] makeElmsInside(String className,String names[]) {
        ElmStub e[] = ElmVE.elmVE.makeElms(className,names,stub.owner);
        for (int i=0;i<e.length;i++) {
            if (e[i] != null) {
                addElm(e[i]);
                e[i].elm.setPlace(this.place);
                e[i].elm.init();
            }
        }
        return e;
    }

//-------------------------------------------
// Methods for geting data of user interfaces.
//-------------------------------------------

    protected String a2UI = "x-res:///ac/hiu/j314/elmve/ui/resources/box.a2";
    protected String a2BG = "x-res:///ac/hiu/j314/elmve/ui/resources/background1.a2";
    protected String a3UI = "x-res:///ac/hiu/j314/elmve/ui/resources/box.a3";
    protected String a3BG = "x-res:///ac/hiu/j314/elmve/ui/resources/background1.a3";
    protected Serializable actionID = new Integer(0);
    protected boolean isInterpolate = false;
    protected String elm2DUIClass() {return "ac.hiu.j314.elmve.ui.Action2DUI";}
    protected String elm2DBGClass() {return "ac.hiu.j314.elmve.ui.Action2DBG";}
    protected String elm3DUIClass() {return "ac.hiu.j314.elmve.ui.Action3DUI";}
    protected String elm3DBGClass() {return "ac.hiu.j314.elmve.ui.Action3DBG";}
    protected String elmLightUIClass() {return "ac.hiu.j314.elmve.ui.ActionLightUI";}
    protected String elmLightBGClass() {return "ac.hiu.j314.elmve.ui.ActionLightBG";}
    protected String customizerClass() {return "ac.hiu.j314.elmve.ui.DefaultCustomizer";}

    protected int customizerPolicy(){return CustomizerStack.POLICY1;}

    public void get2DUIData(MyRequest r) {
        send(makeReply(r,a2UI,actionID,stub.name));
    }
    public void get2DUIRepaintData(MyRequest r) {
        send(makeReply(r,actionID));
    }
    public void get2DBGData(MyRequest r) {
        send(makeReply(r,a2BG,actionID));
    }
    public void get2DBGRepaintData(MyRequest r) {
        send(makeReply(r,actionID));
    }
    public void get3DUIData(MyRequest r) {
        send(makeReply(r,a3UI,actionID,stub.name,isInterpolate));
    }
    public void get3DUIRepaintData(MyRequest r) {
        send(makeReply(r,actionID));
    }
    public void get3DBGData(MyRequest r) {
        send(makeReply(r,a3BG,actionID));
    }
    public void get3DBGRepaintData(MyRequest r) {
        send(makeReply(r,actionID));
    }
    public void getLightUIData(MyRequest r) {
        send(makeReply(r,a2UI,actionID,stub.name,isInterpolate));
    }
    public void getLightUIRepaintData(MyRequest r) {
        send(makeReply(r,actionID));
    }
    public void getLightBGData(MyRequest r) {
        send(makeReply(r,a2BG,actionID));
    }
    public void getLightBGRepaintData(MyRequest r) {
        send(makeReply(r,actionID));
    }

    public void getCustomizerData(MyRequest r) {
        send(makeReply(r,stub.name));
    }

    protected void repaint() {
        updateTime = Elm.uiTimer;
    }
    protected void changeAction(Serializable actionID) {
        this.actionID = actionID;
        repaint();
    }
    protected void changeAction(int actionID) {
        this.actionID = actionID;
        repaint();
    }
    public void changeAction(MyOrder o) {
        changeAction(o.get(0));
    }

//-------------------------------------------
// Methods to save or load ELM objects data.
//-------------------------------------------

    void saveAsXML(Document d,Element e) {
        W.addAttrDOM(d,e,"elmID",""+stub.elmID);
        W.addLineFeedDOM(d,e);
        Element basicData = W.makeElementDOM(d,"basicData");
        W.addChildDOM(e,basicData);
        W.addLineFeedDOM(d,basicData);
        Element stubData = W.makeElementDOM(d,"stub");
        W.addChildDOM(basicData,stubData);
        stub.saveAsXML(d,stubData);
        W.addLineFeedDOM(d,basicData);
        double xyzw[] = new double[4];
        this.place.get(xyzw);
        Element place = W.makeElementDOM(d,"place");
        W.addChildDOM(basicData,place);
        W.addAttrDOM(d,place,"x",""+xyzw[0]);
        W.addAttrDOM(d,place,"y",""+xyzw[1]);
        W.addAttrDOM(d,place,"z",""+xyzw[2]);
        W.addLineFeedDOM(d,basicData);
        this.rotation.get(xyzw);
        Element rotation = W.makeElementDOM(d,"rotation");
        W.addChildDOM(basicData,rotation);
        W.addAttrDOM(d,rotation,"x",""+xyzw[0]);
        W.addAttrDOM(d,rotation,"y",""+xyzw[1]);
        W.addAttrDOM(d,rotation,"z",""+xyzw[2]);
        W.addAttrDOM(d,rotation,"w",""+xyzw[3]);
        W.addLineFeedDOM(d,basicData);
        W.addLineFeedDOM(d,e);

        Element children = W.makeElementDOM(d,"children");
        W.addChildDOM(e,children);

        if (this.children != null) {
            W.addLineFeedDOM(d,children);
            Iterator i = this.children.iterator();
            while (i.hasNext()) {
                Elm child = (Elm)i.next();
                if (child.stub.instanceOf("ac.hiu.j314.elmve.NeverSave"))
                    continue;
                Element elmRef = W.makeElementDOM(d,"elmRef");
                W.addChildDOM(children,elmRef);
                W.addAttrDOM(d,elmRef,"elmID",""+child.stub.elmID);
                W.addLineFeedDOM(d,children);
            }
        }
        W.addLineFeedDOM(d,e);
        Element ext = W.makeElementDOM(d,"extension");
        W.addChildDOM(e,ext);
        saveExtension(d,ext);
        W.addLineFeedDOM(d,e);
    }

    protected void saveExtension(Document d,Element e) {
        ;
    }

    protected String toSaveString() {
        StringBuffer sb = new StringBuffer();
        sb.append("//[][][][][] Elm's status [][][][][]\n");
        sb.append("//***** Class and Name *****\n");
        sb.append(this.getClass().getName()+" \""+stub.name+"\"\n");
        double d[] = new double[4];
        this.place.get(d);
        sb.append("//x y z\n");
        sb.append(d[0]+" "+d[1]+" "+d[2]+"\n");
        this.rotation.get(d);
        sb.append("//rotation\n");
        sb.append(d[0]+" "+d[1]+" "+d[2]+" "+d[3]+"\n");
        sb.append("//number of children\n");
        if (children == null) {
            sb.append("0\n");
        } else {
            sb.append(""+children.size()+"\n");
            Iterator i = children.iterator();
            sb.append("//children class and name\n");
            while (i.hasNext()) {
                Elm le = (Elm)i.next();
                sb.append(le.getClass().getName());
                sb.append("  \""+le.getName()+"\"\n");
            }
            sb.append("// each child data\n");
            i = children.iterator();
            while (i.hasNext()) {
                Elm le = (Elm)i.next();
                sb.append(le.toSaveString());
            }
        }
        return sb.toString();
    }

    /**
      * loadFromXML(fileName)
      */
    protected void loadFromXML(String fileName) throws Exception {
        URL url = W.getResource(fileName);
        InputStream is = url.openStream();
        loadFromXML(is);
    }

    /**
      * loadFromXML(InputStream)
      */
    void loadFromXML(InputStream is) {
        try {
            Document d = W.loadDocumentFromInputStreamDOM(is);
            Element e = d.getDocumentElement();

            if (!e.getTagName().equals("elmData")) {
                System.out.println("Elm.loadFromXML(). Wrong data.");
                return;
            }

            LoadedElmSet elmSet = new LoadedElmSet();
            ArrayList<ElmStub> rootElms = new ArrayList<ElmStub>();
            ArrayList al = W.getChildrenByTagNameDOM(e,"elm");
            Iterator i = al.iterator();
            while (i.hasNext()) {
                ElmStub es = makeElmFromXML((Element)i.next(),elmSet);
                if (es!=null) {
                    rootElms.add(es);
                    parent.elm.addElm(es);
                }
            }

            i = al.iterator();
            while (i.hasNext())
                loadBasicDataFromXML((Element)i.next(),elmSet);

            i = rootElms.iterator();
            while (i.hasNext()) {
                ElmStub es = (ElmStub)i.next();
                es.elm.recursiveInit();
            }

            i = al.iterator();
            while (i.hasNext())
                loadExtensionExec((Element)i.next(),elmSet);
	} catch(Exception e) {
            e.printStackTrace();
        }
    }

    ElmStub makeElmFromXML(Element e,LoadedElmSet elmSet) {
        Element ee = W.getChildByTagNameDOM(e,"basicData");
        Element eee = W.getChildByTagNameDOM(ee,"stub");
        String name = W.getDataDOM(eee,"name");
        String className = W.getDataDOM(eee,"className");
        String owner = W.getDataDOM(eee,"owner");
        long oldID = Long.parseLong(W.getDataDOM(eee,"elmID"));
        Elm elm = ElmVE.elmVE.makeElm(className,name,owner).elm;
        elmSet.addElm(oldID,elm.stub);
        if (W.getAttrDataDOM(e,"rootElm").equals("true"))
            return elm.stub;
        else
            return null;
    }

    /**
      * loadFromXML(Element)
      */
    void loadBasicDataFromXML(Element e,LoadedElmSet elmSet) {
        Element basicData = W.getChildByTagNameDOM(e,"basicData");
        Element stubData = W.getChildByTagNameDOM(basicData,"stub");

        long elmID = Long.parseLong(W.getDataDOM(stubData,"elmID"));
        ElmStub es = elmSet.getElm(elmID);
        if (es==null) {
            System.out.println("Elm.loadBasicDataFromXML(). ???");
            return;
        }

        Element place = W.getChildByTagNameDOM(basicData,"place");
        Element rotation = W.getChildByTagNameDOM(basicData,"rotation");

        es.loadFromXMLExceptID(stubData);

        double xyzw[] = new double[4];
        xyzw[0] = Double.parseDouble(W.getAttrDataDOM(place,"x"));
        xyzw[1] = Double.parseDouble(W.getAttrDataDOM(place,"y"));
        xyzw[2] = Double.parseDouble(W.getAttrDataDOM(place,"z"));
        es.elm.place.set(xyzw);

        xyzw[0] = Double.parseDouble(W.getAttrDataDOM(rotation,"x"));
        xyzw[1] = Double.parseDouble(W.getAttrDataDOM(rotation,"y"));
        xyzw[2] = Double.parseDouble(W.getAttrDataDOM(rotation,"z"));
        xyzw[3] = Double.parseDouble(W.getAttrDataDOM(rotation,"w"));
        es.elm.rotation.set(xyzw);

        Element children = W.getChildByTagNameDOM(e,"children");
        ArrayList al = W.getChildrenByTagNameDOM(children,"elmRef");
        Iterator i = al.iterator();
        while (i.hasNext()) {
            Element elmRef = (Element)i.next();
            elmID = Long.parseLong(W.getAttrDataDOM(elmRef,"elmID"));
            ElmStub elmTmp = elmSet.getElm(elmID);
            es.elm.addElm(elmTmp);
        }
    }

    void loadExtensionExec(Element e,LoadedElmSet elmSet) {
        Element basicData = W.getChildByTagNameDOM(e,"basicData");
        Element stubData = W.getChildByTagNameDOM(basicData,"stub");

        long elmID = Long.parseLong(W.getDataDOM(stubData,"elmID"));
        ElmStub es = elmSet.getElm(elmID);
        if (es==null) {
            System.out.println("Elm.loadExtensionExec(). ???");
            return;
        }

        Element ext = W.getChildByTagNameDOM(e,"extension");
        es.elm.loadExtension(ext,elmSet);
    }

    protected void loadExtension(Element e,LoadedElmSet elmSet) {
        ;
    }

    /**
      * loadFromText(fileName)
      */
    void loadFromText(String fileName) throws Exception {
        ElmStreamTokenizer f_in = W.getEST(fileName);
        loadFromText(f_in);
    }

    /**
      * loadFromText(tokenizer)
      */
    protected void loadFromText(ElmStreamTokenizer f_in) throws IOException {
        if (!f_in.nextString().equals(this.getClass().getName()))
            throw new IOException("Elm.loadFromText(); class does not match!");
        stub.name = f_in.nextString();
        double d[] = new double[4];
        d[0] = f_in.nextDouble();
        d[1] = f_in.nextDouble();
        d[2] = f_in.nextDouble();
        place.set(d);
        d[0] = f_in.nextDouble();
        d[1] = f_in.nextDouble();
        d[2] = f_in.nextDouble();
        d[3] = f_in.nextDouble();
        rotation.set(d);
        int cNumber = f_in.nextInt();
        if (cNumber != 0) {
            children = new ArrayList<Elm>();
            String nameTmp[] = new String[cNumber];
            for (int i=0;i<cNumber;i++) {
                String className = f_in.nextString();
                nameTmp[i] = f_in.nextString();
                makeElmInside(className,nameTmp[i]);
            }
            for (int i=0;i<cNumber;i++) {
                ElmStub es = getLocalElm(stub.name+"/"+nameTmp[i]);
                es.elm.loadFromText(f_in);
            }
        }
    }

    void recursiveDispose() {
        if (children!=null) {
            Elm e[] = (Elm[])children.toArray(new Elm[0]);
            for (int i=0;i<e.length;i++)
                e[i].recursiveDispose();
        }
        dispose();
    }
    protected void dispose() {
        parent.elm.delElm(this.stub);
    }

//----------------------------------------------------------------------
// ELM Methods
//----------------------------------------------------------------------

    public void setName(MyOrder o) {
        setName(o.getString(0));
    }

    public void setPlace(Order o) {
        setPlace(o.getPlace(0));
    }

    public void setPlace(Request r) {
        setPlace(r.getPlace(0));
        send(makeReply(r,"Ok"));
    }

    public void getPlace(Request r) {
        Place p = new Place();
        getPlace(p);
        send(makeReply(r,p));
    }

    public void setRotation(Order o) {
        rotation.set(o.getRotation(0));
    }

    public void getRotation(Request r) {
        send(makeReply(r,rotation));
    }

    public void catchError(MyOrder o) {
System.out.println("Elm.catchError().Error !");
    }

    public void getPath(MyRequest r) {
        send(makeReply(r,getPath()));
    }

    public void getFullPath(MyRequest r) {
        send(makeReply(r,getFullPath()));
    }

    public void getIDPath(MyRequest r) {
        send(makeReply(r,stub.path));
    }

// Methods for user interfaces

    public void repaint(MyOrder o) {
        repaint();
    }

    public void send2DUIData(MyRequest r) {
        MyRequest req = makeMyRequest("get2DUIData",NULL);
        receive(req,"send2DUIData2",r);
        send(req);
    }
    public void send2DUIData2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);
        Elm2DData elm2DData = null;
        elm2DData = new Elm2DData(Elm2DData.NEW);
        elm2DData.className = elm2DUIClass();
        elm2DData.data = rs.getReply(0).getAll();
        elm2DData.elm = this.stub;
        elm2DData.place.set(this.place);
        send(makeReply(r,elm2DData));
    }
    public void send2DUIRepaintData(MyRequest r) {
        if (r.getInt(0) < updateTime) {
            MyRequest req = makeMyRequest("get2DUIRepaintData",NULL);
            receive(req,"send2DUIRepaintData2",r);
            send(req);
        } else {
            send(makeReply(r,NULL));
        }
    }
    public void send2DUIRepaintData2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);
        Elm2DData elm2DData = null;
        elm2DData = new Elm2DData(Elm2DData.UPDATE);
        elm2DData.data = rs.getReply(0).getAll();
        elm2DData.elm = this.stub;
        elm2DData.place.set(this.place);
        send(makeReply(r,elm2DData));
    }

    public void send2DBGData(MyRequest r) {
        Elm.uiTimer++;
        MyRequest req = makeMyRequest("get2DBGData",NULL);
        receive(req,"send2DBGData2",r);
        send(req);
    }
    public void send2DBGData2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);
        Elm2DData elm2DData = null;
        elm2DData = new Elm2DData(Elm2DData.NEW);
        elm2DData.className = elm2DBGClass();
        elm2DData.data = rs.getReply(0).getAll();
        elm2DData.elm = this.stub;
        elm2DData.place.set(this.place);
        send(makeReply(r,elm2DData));
    }
    public void send2DBGRepaintData(MyRequest r) {
        Elm.uiTimer++;
        if (r.getInt(0) < updateTime) {
            MyRequest req = makeMyRequest("get2DBGRepaintData",NULL);
            receive(req,"send2DBGRepaintData2",r);
            send(req);
        } else {
            send(makeReply(r,NULL));
        }
    }
    public void send2DBGRepaintData2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);
        Elm2DData elm2DData = null;
        elm2DData = new Elm2DData(Elm2DData.UPDATE);
        elm2DData.data = rs.getReply(0).getAll();
        elm2DData.elm = this.stub;
        elm2DData.place.set(this.place);
        send(makeReply(r,elm2DData));
    }

    public void send3DUIData(MyRequest r) {
        MyRequest req = makeMyRequest("get3DUIData",NULL);
        receive(req,"send3DUIData2",r);
        send(req);
    }
    public void send3DUIData2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);
        Elm3DData elm3DData = null;
        elm3DData = new Elm3DData(Elm3DData.NEW);
        elm3DData.className = elm3DUIClass();
        elm3DData.data = rs.getReply(0).getAll();
        elm3DData.elm = this.stub;
        elm3DData.place.set(this.place);
        elm3DData.rotation.set(this.rotation);
        send(makeReply(r,elm3DData));
    }
    public void send3DUIRepaintData(MyRequest r) {
        if (r.getInt(0) < updateTime) {
            MyRequest req = makeMyRequest("get3DUIRepaintData",NULL);
            receive(req,"send3DUIRepaintData2",r);
            send(req);
        } else {
            send(makeReply(r,NULL));
        }
    }
    public void send3DUIRepaintData2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);
        Elm3DData elm3DData = null;
        elm3DData = new Elm3DData(Elm3DData.UPDATE);
        elm3DData.data = rs.getReply(0).getAll();
        elm3DData.elm = this.stub;
        elm3DData.place.set(this.place);
        elm3DData.rotation.set(this.rotation);
        send(makeReply(r,elm3DData));
    }

    public void send3DBGData(MyRequest r) {
        Elm.uiTimer++;
        MyRequest req = makeMyRequest("get3DBGData",NULL);
        receive(req,"send3DBGData2",r);
        send(req);
    }
    public void send3DBGData2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);
        Elm3DData elm3DData = null;
        elm3DData = new Elm3DData(Elm3DData.NEW);
        elm3DData.className = elm3DBGClass();
        elm3DData.data = rs.getReply(0).getAll();
        elm3DData.elm = this.stub;
        elm3DData.place.set(this.place);
        elm3DData.rotation.set(this.rotation);
        send(makeReply(r,elm3DData));
    }
    public void send3DBGRepaintData(MyRequest r) {
        Elm.uiTimer++;
        if (r.getInt(0) < updateTime) {
            MyRequest req = makeMyRequest("get3DBGRepaintData",NULL);
            receive(req,"send3DBGRepaintData2",r);
            send(req);
        } else {
            send(makeReply(r,NULL));
        }
    }
    public void send3DBGRepaintData2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);
        Elm3DData elm3DData = null;
        elm3DData = new Elm3DData(Elm3DData.UPDATE);
        elm3DData.data = rs.getReply(0).getAll();
        elm3DData.elm = this.stub;
        elm3DData.place.set(this.place);
        elm3DData.rotation.set(this.rotation);
        send(makeReply(r,elm3DData));
    }

    public void sendLightUIData(MyRequest r) {
        MyRequest req = makeMyRequest("getLightUIData",NULL);
        receive(req,"sendLightUIData2",r);
        send(req);
    }
    public void sendLightUIData2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);
        ElmLightData elmLightData = null;
        elmLightData = new ElmLightData(ElmLightData.NEW);
        elmLightData.className = elmLightUIClass();
        elmLightData.data = rs.getReply(0).getAll();
        elmLightData.elm = this.stub;
        elmLightData.place.set(this.place);
        send(makeReply(r,elmLightData));
    }
    public void sendLightUIRepaintData(MyRequest r) {
        if (r.getInt(0) < updateTime) {
            MyRequest req = makeMyRequest("getLightUIRepaintData",NULL);
            receive(req,"sendLightUIRepaintData2",r);
            send(req);
        } else {
            send(makeReply(r,NULL));
        }
    }
    public void sendLightUIRepaintData2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);
        ElmLightData elmLightData = null;
        elmLightData = new ElmLightData(ElmLightData.UPDATE);
        elmLightData.data = rs.getReply(0).getAll();
        elmLightData.elm = this.stub;
        elmLightData.place.set(this.place);
        send(makeReply(r,elmLightData));
    }
    public void sendLightBGData(MyRequest r) {
        Elm.uiTimer++;
        MyRequest req = makeMyRequest("getLightBGData",NULL);
        receive(req,"sendLightBGData2",r);
        send(req);
    }
    public void sendLightBGData2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);
        ElmLightData elmLightData = null;
        elmLightData = new ElmLightData(ElmLightData.NEW);
        elmLightData.className = elmLightBGClass();
        elmLightData.data = rs.getReply(0).getAll();
        elmLightData.elm = this.stub;
        elmLightData.place.set(this.place);
        send(makeReply(r,elmLightData));
    }
    public void sendLightBGRepaintData(MyRequest r) {
        Elm.uiTimer++;
        if (r.getInt(0) < updateTime) {
            MyRequest req = makeMyRequest("getLightBGRepaintData",NULL);
            receive(req,"sendLightBGRepaintData2",r);
            send(req);
        } else {
            send(makeReply(r,NULL));
        }
    }
    public void sendLightBGRepaintData2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);
        ElmLightData elmLightData = null;
        elmLightData = new ElmLightData(ElmLightData.UPDATE);
        elmLightData.data = rs.getReply(0).getAll();
        elmLightData.elm = this.stub;
        elmLightData.place.set(this.place);
        send(makeReply(r,elmLightData));
    }

// Methods for customizer

    public void sendCustomizerData(MyRequest r) {
        MyRequest req = makeMyRequest("getCustomizerData",NULL);
        receive(req,"sendCustomizerData2",r);
        send(req);
    }
    public void sendCustomizerData2(ReplySet rs) {
        MyRequest r = rs.getMyRequest(0);
        if (customizerStack==null)
            customizerStack = new CustomizerStack(customizerPolicy());
        if (customizerStack.isReplySuitable(r.sender,this.stub)) {
            CustomizerData cd = new CustomizerData();
            cd.className = customizerClass();
            cd.elm = this.stub;
            cd.data = rs.getReply(0).getAll();
            send(makeReply(r,cd));
        } else {
            System.out.println("you cannot open this customizer for some reason.");
            send(makeReply(r,NULL));
        }
    }

    public void addCustomizer(MyOrder o) {
        customizerStack.add(o.getElm(0),o.getElm(1));
    }

    public void delCustomizer(MyOrder o) {
        customizerStack.del(o.getElm(0));
    }

// Methods to save or load data

    public void saveAsXML(MyRequest r) {
        try {
            saveAsXML(r.getString(0));
            send(makeReply(r,"Ok."));
        } catch(Exception e) {
            e.printStackTrace();
            send(makeReply(r,"Fail."));
        }
    }

    public void saveElmSetAsXML(MyRequest r) {
        try {
            saveElmSetAsXML((ArrayList)r.get(0),r.getString(1));
            send(makeReply(r,"Ok."));
        } catch(Exception e) {
            e.printStackTrace();
            send(makeReply(r,"Fail."));
        }
    }

    public void saveAsText(MyRequest r) {
        try {
            saveAsText(r.getString(0));
            send(makeReply(r,"Ok."));
        } catch(IOException e) {
            e.printStackTrace();
            send(makeReply(r,"Fail."));
        }
    }

    public void loadFromText(MyRequest r) {
        try {
            loadFromText(r.getString(0));
            send(makeReply(r,"Ok."));
        } catch(Exception e) {
            e.printStackTrace();
            send(makeReply(r,"Fail."));
        }
    }

// connect

    public void connect(MyOrder o) {
    }

// dispose

    public void dispose(MyOrder o) {
        dispose();
    }

//----------------------------------------------------------------------

    ArrayList<Elm> getAllDescendants(ArrayList<Elm> al) {
        al.add(this);
        if (children!=null) {
            Iterator i = children.iterator();
            while (i.hasNext()) {
                Elm elm = (Elm)i.next();
                elm.getAllDescendants(al);
            }
        }
        return al;
    }

    public void changeDirectory(MyOrder o) {
        String path = o.getString(0);

        ElmStub elm = getElm(path);
        if (elm == null)
            return;
        Request req = makeRequest(ElmVE.elmVE.topElm,"transfer",
                                  this,parent,elm);
        receive(req,"changeDirectory2",NULL);
        send(req);
    }
    public void changeDirectory2(ReplySet rs) {
        ;
    }

    public void changeDirectory(MyRequest r) {
        String path = r.getString(0);

        ElmStub elm = getElm(path);
        if (elm == null)
            return;
        Request req = makeRequest(ElmVE.elmVE.topElm,"transfer",
                                  this,parent,elm);
        receive(req,"changeDirectory22",r);
        send(req);
    }
    public void changeDirectory22(ReplySet rs) {
        send(makeReply(rs.getMyRequest(0),NULL));
    }
}
