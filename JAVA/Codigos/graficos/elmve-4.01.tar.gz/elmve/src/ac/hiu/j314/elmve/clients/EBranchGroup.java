package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;
import javax.media.j3d.*;

public class EBranchGroup extends BranchGroup {
    public EBranchGroup() {
        super();
        setCapability(ENABLE_PICK_REPORTING);
    }

    public void setElm(ElmStub es) {
        setUserData(es);
    }

    public ElmStub getElm() {
        return (ElmStub)getUserData();
    }
}
