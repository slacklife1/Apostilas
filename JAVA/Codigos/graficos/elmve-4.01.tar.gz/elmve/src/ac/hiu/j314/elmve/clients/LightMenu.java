package ac.hiu.j314.elmve.clients;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class LightMenu extends JPanel {
    private static final long serialVersionUID = 1L;
    LightMenuItem rootMenuItem;
    ArrayList<LightMenuItem> selectPath;

    public LightMenu() {
        rootMenuItem = new LightMenuItem("root");
        selectPath = new ArrayList<LightMenuItem>();
        selectPath.add(rootMenuItem);
    }

    public void add(LightMenuItem lmi) {
        if (rootMenuItem.size()==0)
            selectPath.add(lmi);
        rootMenuItem.add(lmi);
    }

    public void add(LightMenuItem lmi,int i) {
        if (rootMenuItem.size()==0)
            selectPath.add(lmi);
        rootMenuItem.add(lmi,i);
    }

    public void paint(Graphics g) {
        Dimension d = getSize();
        g.setColor(Color.white);
        g.fillRect(0,0,d.width,d.height);
        g.setColor(Color.black);
        g.drawRect(3,3,d.width-6,d.height-6);

        for (int level=0;level<selectPath.size()-1;level++) {
            LightMenuItem clmi = (LightMenuItem)selectPath.get(level);
            LightMenuItem nlmi = (LightMenuItem)selectPath.get(level+1);
            for (int i=0;i<clmi.size();i++) {
                LightMenuItem lmi = clmi.get(i);
                if (lmi == nlmi) {
                    float f = 1.0f - ((float)(level+1))/10.0f;
                    f = f<0.5f?0.5f:f;
                    g.setColor(new Color(0,f,f));
                    g.fillRect(10+level*20,10+i*20+level*5,280-level*20,20);
                    g.setColor(Color.blue);
                    g.drawRect(10+level*20,10+i*20+level*5,280-level*20,20);
                    g.setColor(Color.red);
                    g.drawString(lmi.label,15+level*20,25+i*20+level*5);
                } else {
                    float f = 1.0f - ((float)(level+1))/10.0f;
                    f = f<0.5f?0.5f:f;
                    g.setColor(new Color(f,f,f));
                    g.fillRect(10+level*20,10+i*20+level*5,280-level*20,20);
                    g.setColor(Color.blue);
                    g.drawRect(10+level*20,10+i*20+level*5,280-level*20,20);
                    g.setColor(Color.black);
                    g.drawString(lmi.label,15+level*20,25+i*20+level*5);
                }
            }
        }
    }

    public Dimension getPreferredSize() {
        return new Dimension(300,380);
    }

    boolean processed;
    public void processKeyEvent(KeyEvent e) {
        LightMenuItem parent;
        LightMenuItem current;
        int i;

        if ((this.isVisible()==false)&&(e.getKeyCode()!=KeyEvent.VK_ESCAPE)) {
            processed = false;
            return;
        }

        switch (e.getKeyCode()) {
        case KeyEvent.VK_UP:
            parent = (LightMenuItem)selectPath.get(selectPath.size()-2);
            current = (LightMenuItem)selectPath.get(selectPath.size()-1);
            i = parent.indexOf(current);
            if (i==0)
                break;
            selectPath.remove(selectPath.size()-1);
            selectPath.add(parent.get(i-1));
            repaint();
            break;
        case KeyEvent.VK_DOWN:
            parent = (LightMenuItem)selectPath.get(selectPath.size()-2);
            current = (LightMenuItem)selectPath.get(selectPath.size()-1);
            i = parent.indexOf(current);
            if (i==parent.size()-1)
                break;
            selectPath.remove(selectPath.size()-1);
            selectPath.add(parent.get(i+1));
            repaint();
            break;
        case KeyEvent.VK_RIGHT:
            current = (LightMenuItem)selectPath.get(selectPath.size()-1);
            if (current.children.size()==0)
                break;
            selectPath.add((LightMenuItem)current.children.get(0));
            repaint();
            break;
        case KeyEvent.VK_LEFT:
            if (selectPath.size()==2)
                break;
            selectPath.remove(selectPath.size()-1);
            repaint();
            break;
        case KeyEvent.VK_ENTER:
            current = (LightMenuItem)selectPath.get(selectPath.size()-1);
            if (current.children.size()!=0) {
                selectPath.add((LightMenuItem)current.children.get(0));
                repaint();
            } else {
                current.processEvent();
                setVisible(false);
                reset();
            }
            break;
        case KeyEvent.VK_SPACE:
            current = (LightMenuItem)selectPath.get(selectPath.size()-1);
            if (current.children.size()!=0) {
                selectPath.add((LightMenuItem)current.children.get(0));
                repaint();
            } else {
                current.processEvent();
                setVisible(false);
                reset();
            }
            break;
        case KeyEvent.VK_ESCAPE:
            if (this.isVisible()==true) {
                setVisible(false);
                reset();
                processed = false;
            } else {
                setVisible(true);
            }
            break;
        default:
            break;
        }
        processed = true;
    }

    public void reset() {
        selectPath.clear();
        selectPath.add(rootMenuItem);
        selectPath.add(rootMenuItem.get(0));
    }
}
