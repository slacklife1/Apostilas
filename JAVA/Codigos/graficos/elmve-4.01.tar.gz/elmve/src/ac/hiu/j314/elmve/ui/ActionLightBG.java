package ac.hiu.j314.elmve.ui;

import ac.hiu.j314.elmve.clients.*;
import ac.hiu.j314.a23.*;
import java.awt.*;

public class ActionLightBG extends ElmLightBG {
    protected Action2D a2;
    protected Image image;
    protected Image scaledImage;
    protected int wppmOld,hppmOld;

    public void init(ElmLightData d) {
        a2 = A2Loader.load(d.getString(0));
        if (a2 == null) {
System.out.println("Action2DBG.init(). gaha!!!");
            return;
        }
        image = a2.getImage(d.get(1));
    }

    public void update(ElmLightData d) {
        if (a2 == null) {
System.out.println("Action2DBG.update(). gaha!!!");
            return;
        }
        image = a2.getImage(d.get(0));
    }
    public void paint(Graphics g) {
        if(image.getWidth(null)==-1 || image.getHeight(null)==-1){
System.out.println("Room2DBG.paintComponent().");
            return;
        }
        Rectangle r = g.getClipBounds();
        double ppm=getPPM();
        double ccx=getCenX();
        double ccy=getCenY();
        int gw,gh,wi,hi,wppm,hppm,xc,yc;
        xc=(int)(ccx*ppm);
        yc=(int)(ccy*ppm);
        wppm=(int)((double)image.getWidth(null)*(ppm/25.0));
        hppm=(int)((double)image.getHeight(null)*(ppm/25.0));
        if(wppm!=wppmOld || hppm!=hppmOld){
            scaledImage = image.getScaledInstance(wppm,hppm,Image.SCALE_DEFAULT);
            wppmOld=wppm;
            hppmOld=hppm;
        }
        gw = r.width;
        gh = r.height;
        for(hi=(yc%hppm)-hppm;hi<gh;hi=hi+hppm){
            for(wi=-(xc%wppm)-wppm;wi<gw;wi=wi+wppm){
                g.drawImage(scaledImage,wi,hi,null);
            }
        }
    }
}
