package ac.hiu.j314.elmve.graph;

import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.ui.*;
import java.io.*;
import java.awt.*;
import org.w3c.dom.*;

public abstract class Link extends Elm {
    protected ElmStub head;
    protected ElmStub tail;

    protected String elm2DUIClass()
        {return "ac.hiu.j314.elmve.ui.EPoint2DUI";}

    public void get2DUIData(MyRequest r) {
        send(makeReply(r,new Dimension(10,10),EPoint2DUI.CIRCLE,Color.black));
    }
    public void get2DUIRepaintData(MyRequest r) {
        send(makeReply(r,Color.black));
    }

    public void initLink(Order o) {
        head = o.getElm(0);
        tail = o.getElm(1);
    }

    protected void setPlace(Place p) {
        if ((head!=null)&&(tail!=null)) {
            Place p1 = getPlace(head);
            Place p2 = getPlace(tail);
            p1.scale(3.0);
            p2.scale(2.0);
            p1.add(p2);
            p1.scale(0.2);
            super.setPlace(p1);
        } else {
            super.setPlace(p);
        }
    }

    public abstract void getLines(MyRequest r);

    public abstract boolean isDirected();

    protected void saveExtension(Document d,Element e) {
        Element ee = W.makeElementDOM(d,"headAndTail");
        W.addChildDOM(e,ee);
        W.addDataDOM(d,ee,"headID",""+head.getElmID());
        W.addDataDOM(d,ee,"tailID",""+tail.getElmID());
    }
    protected void loadExtension(Element e,LoadedElmSet elmSet) {
        Element ee = W.getChildByTagNameDOM(e,"headAndTail");
        long l;
        l = Long.parseLong(W.getDataDOM(ee,"headID"));
        head = elmSet.getElm(l);
        l = Long.parseLong(W.getDataDOM(ee,"tailID"));
        tail = elmSet.getElm(l);
    }

    public String toSaveString() {
        StringBuffer sb = new StringBuffer();
        sb.append(super.toSaveString());
        sb.append("//head\n");
        sb.append("\""+head.getName()+"\"\n");
        sb.append("//tail\n");
        sb.append("\""+tail.getName()+"\"\n");
        return sb.toString();
    }

    public void loadFromText(ElmStreamTokenizer f_in) throws IOException {
        super.loadFromText(f_in);
        head = getElm(f_in.nextString());
        tail = getElm(f_in.nextString());
    }

    public void dispose(MyOrder o) {
        if (o.getArgCount()==0) {
            dispose();
        } else if (o.getArgCount()==1) {
            ElmStub es = o.getElm(0);
            if (head.equals(es))
                send(makeMyOrder(tail,"delLinkByLink",this.getStub()));
            else
                send(makeMyOrder(head,"delLinkByLink",this.getStub()));
            dispose();
        }
    }
}
