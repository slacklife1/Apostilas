package ac.hiu.j314.elmve.clients;

import ac.hiu.j314.elmve.*;

import java.io.*;

import javax.swing.*;
import java.awt.*;

//public abstract class Elm2DBG extends JComponent {
public abstract class Elm2DBG extends JPanel {
    public static final Serializable NULL = Elm.NULL;
    public static final Serializable OK = Elm.OK;
    public static final Serializable ERROR = Elm.ERROR;

    protected final Place place = new Place();
    protected ElmClient client;
    protected ElmStub elm;
    ElmLayout elmLayout;

    public Elm2DBG() {
        elmLayout = new ElmLayout();
        setLayout(elmLayout);
    }

    public abstract void init(Elm2DData data);

    public void setPlace(Place place) {
        this.place.set(place);
    }

    public Place getPlace() {
        return place;
    }

    public boolean isSet() {
        return true;
    }

    public abstract void update(Elm2DData data);

    public void setElm(ElmStub e) {
        elm = e;
    }

    public void setClient(ElmClient c) {
        this.client = c;
    }

    public void pointToPlace(Point po,Place pl) {
        elmLayout.pointToPlace(po,pl);
    }

    public Place pointToPlace(Point p) {
        return elmLayout.pointToPlace(p);
    }

    public Place pointToPlace(int px,int py) {
        return elmLayout.pointToPlace(px,py);
    }

    public void placeToPoint(Place pl,Point po) {
        elmLayout.placeToPoint(pl,po);
    }

    public Point placeToPoint(Place p) {
        return elmLayout.placeToPoint(p);
    }

    public Point placeToPoint(double x,double y) {
        return elmLayout.placeToPoint(x,y);
    }

    public Elm2DUI getElm2DUIAt(int x,int y) {
        Component c = getComponentAt(x,y);
        if (c == this)
            return null;
        else
            return (Elm2DUI)c;
    }

    public void setCenX(double x) {elmLayout.setCenX(x);}
    public void setCenY(double y) {elmLayout.setCenY(y);}
    public void setPPM(double ppm) {
        elmLayout.setPPM(ppm);
        Component c[] = getComponents();
        for (int i=0;i<c.length;i++) {
            if (c[i] instanceof Elm2DUI) {
                Elm2DUI ui = (Elm2DUI)c[i];
                ui.setPPM(ppm);
            }
        }
    }
    public double getCenX() {return elmLayout.getCenX();}
    public double getCenY() {return elmLayout.getCenY();}
    public double getPPM() {return elmLayout.getPPM();}
//----------------------------------------------------------------------
    public UIOrder makeOrder(String methodName,Serializable... args) {
        return new UIOrder(methodName,args);
    }
    public UIMyOrder makeMyOrder(String methodName,Serializable... args) {
        return new UIMyOrder(methodName,args);
    }
    public void send(UIMessage msg) {
        if (msg instanceof UIOrder)
            client.relayOrder(elm,msg.methodName,msg.arguments);
        else if (msg instanceof UIMyOrder)
            client.relayMyOrder(elm,msg.methodName,msg.arguments);
    }
}
