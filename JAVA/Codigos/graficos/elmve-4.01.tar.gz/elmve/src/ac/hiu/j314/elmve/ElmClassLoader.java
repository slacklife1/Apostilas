package ac.hiu.j314.elmve;

import java.io.*;
import java.util.*;
import java.net.*;
import org.w3c.dom.*;
import java.rmi.*;
import java.util.jar.*;

class ElmClassLoader extends ClassLoader {
    protected String elmClassPath[] = new String[0];
    protected String exportElmClassPath[] = new String[0];
    protected String jdkHome = "none";

    protected ElmClassLoader() {
        super();
    }

    protected ElmClassLoader(ClassLoader cl) {
        super(cl);
    }

    public Class<?> findClass(String name) throws ClassNotFoundException {
        byte[] b = loadClassData(name);
        if (b == null)
            throw new ClassNotFoundException();
        return defineClass(name,b,0,b.length);
    }

    byte[] loadClassData(String name) {
        if (W.sepa.equals("/"))
            name = name.replace('.','/');
        else if (W.sepa.equals("\\"))
            name = name.replace('.','\\');
        else
            name = name.replace('.','/');
        String s = ElmVE.elmVE.classesDir+W.sepa+name+".class";
        if (s.startsWith("file:"))
            s = s.substring(5);
        File f = new File(s);
        try {
            if (f.isFile()) {
                long l = f.length();
                byte b[] = new byte[(int)l];
                FileInputStream fis =
                    new FileInputStream(ElmVE.elmVE.classesDir+W.sepa+name+".class");
                fis.read(b);
                return b;
            }
        } catch(Exception e) {
//            e.printStackTrace();
        }
        for (int i=0;i<elmClassPath.length;i++) {
            if (elmClassPath[i].endsWith(".jar")) {
                byte[] b = loadClassDataFromJarFile(elmClassPath[i],name);
                if (b != null)
                    return b;
                else
                    continue;
            } else if (elmClassPath[i].startsWith("//")) {
                byte b[] = null;
                if (ElmVE.elmVE.elmConfig.elmBridge.equals("none"))
                    b = loadClassDataFromRemoteElmVE(elmClassPath[i],name);
                else
                    b = loadClassDataFromRemoteElmBridge(elmClassPath[i],name);
                if (b != null)
                    return b;
                else
                    continue;
            } else {
                byte[] b = loadClassDataFromFile(elmClassPath[i],name);
                if (b != null)
                    return b;
                else
                    continue;
            }
        }
        String extJarsDirString = null;
        if (ElmVE.elmVE.extJarsDir.startsWith("file:"))
            extJarsDirString = ElmVE.elmVE.extJarsDir.substring(5);
        else
            extJarsDirString = ElmVE.elmVE.extJarsDir;
        try {
            File extJarsDir = new File(extJarsDirString);
            String extJars[] = extJarsDir.list();
            for (int i=0;i<extJars.length;i++) {
                if (extJars[i].endsWith(".jar")) {
                    byte[] b = loadClassDataFromJarFile(extJarsDirString+W.sepa+
                                                        extJars[i],name);
                    if (b != null)
                        return b;
                    else
                        continue;
                }
            }
        } catch (Exception e) {
//            e.printStackTrace();
        }
        if (!jdkHome.equals("none")) {
            String javaToolsJar = jdkHome+W.sepa+"lib"+W.sepa+"tools.jar";
            byte[] b = loadClassDataFromJarFile(javaToolsJar,name);
            if (b != null)
                return b;
        }
        return null;
    }

    byte[] loadClassDataFromJarFile(String classPath,String name) {
        try {
            name = name.replace('\\','/'); // <- こういうことで良いのかな？
            FileInputStream fis = new FileInputStream(classPath);
            JarInputStream jis = new JarInputStream(fis);
            JarEntry je;
            while ((je = jis.getNextJarEntry())!=null) {
                if (je.getName().equals(name+".class")) {
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    byte b[] = new byte[1024];
                    while (true) {
                        int len = jis.read(b);
                        if (len<0) {
                            break;
                        }
                        baos.write(b,0,len);
                    }
                    return baos.toByteArray();
                } else {
                    continue;
                }
            }
            return null;
        } catch (Exception e) {
//e.printStackTrace();
            return null;
        }
    }
    byte[] loadClassDataFromFile(String classPath,String name) {
        try {
            File f = new File(classPath+W.sepa+name+".class");
            if (!f.isFile())
                return null;
            long l = f.length();
            byte b[] = new byte[(int)l];
            FileInputStream fis =
                new FileInputStream(classPath+W.sepa+name+".class");
            fis.read(b);
            return b;
        } catch(Exception e) {
//e.printStackTrace();
            return null;
        }
    }

    byte[] loadClassDataFromRemoteElmVE(String elmve,String name) {
        try {
            RemoteElmVE remoteVE =
                (RemoteElmVE)Naming.lookup(elmve);
            byte[] b = remoteVE.loadClassData(name);
            String s = ElmVE.elmVE.classesDir+W.sepa+name+".class";
            if (s.startsWith("file:"))
                s = s.substring(5);
            File f = new File(s);
            f.getParentFile().mkdirs();
            FileOutputStream fos = new FileOutputStream(f);
            fos.write(b);
            return b;
        } catch(Exception e) {
            return null;
        }
    }

    byte[] loadClassDataFromRemoteElmBridge(String elmve,String name) {
        try {
            RemoteElmBridge remoteBridge =
                (RemoteElmBridge)Naming.lookup(
                    "//"+ElmVE.elmVE.elmConfig.elmBridge+"/ElmBridge");
            byte[] b = remoteBridge.loadClassData(elmve,name);
            String s = ElmVE.elmVE.classesDir+W.sepa+name+".class";
            if (s.startsWith("file:"))
                s = s.substring(5);
            File f = new File(s);

            f.getParentFile().mkdirs();
            FileOutputStream fos = new FileOutputStream(f);
            fos.write(b);
            return b;
        } catch(Exception e) {
            return null;
        }
    }

    byte[] elmLoadClassData(String name) {
        try {
            for (int i=0;i<exportElmClassPath.length;i++) {
                File f = new File(exportElmClassPath[i]+W.sepa+name+".class");
                if (!f.isFile())
                    return null;
                long l = f.length();
                byte b[] = new byte[(int)l];
                FileInputStream fis =
                    new FileInputStream(exportElmClassPath[i]+W.sepa+name+".class");
                fis.read(b);
                return b;
            }
            return null;
        } catch(Exception e) {
            return null;
        }
    }

    protected URL findResource(String name) {
        URL ret = getClass().getResource(name);
        if (ret!=null)
            return ret;
        try {
            String s = ElmVE.elmVE.classesDir+name;
            if (s.startsWith("file:"))
                s = s.substring(5);
            File f = new File(s);
            if (f.isFile()) {
                ret = f.toURL();
                if (ret != null)
                    return ret;
            }
        } catch(Exception e) {
        }
        for (int i=0;i<elmClassPath.length;i++) {
            if (elmClassPath[i].startsWith("//")) {
                if (ElmVE.elmVE.elmConfig.elmBridge.equals("none"))
                    ret = findResourceFromRemoteElmVE(elmClassPath[i],name);
                else
                    ret = findResourceFromRemoteElmBridge(elmClassPath[i],name);
                if (ret != null)
                    return ret;
            } else if (elmClassPath[i].endsWith(".jar")) {
                ret = findResourceFromJarFile(elmClassPath[i],name);
                if (ret != null)
                    return ret;
            } else {
                ret = findResourceFromFile(elmClassPath[i],name);
                if (ret != null)
                    return ret;
            }
        }
        String extJarsDirString = null;
        if (ElmVE.elmVE.extJarsDir.startsWith("file:"))
            extJarsDirString = ElmVE.elmVE.extJarsDir.substring(5);
        else
            extJarsDirString = ElmVE.elmVE.extJarsDir;
        File extJarsDir = new File(extJarsDirString);
        String extJars[] = extJarsDir.list();
        for (int i=0;i<extJars.length;i++) {
            if (extJars[i].endsWith(".jar")) {
                ret = findResourceFromJarFile(extJarsDirString + W.sepa +
                                              extJars[i],name);
                if (ret != null)
                    return ret;
            }
        }
        if (!jdkHome.equals("none")) {
            String javaToolsJar = jdkHome+W.sepa+"lib"+W.sepa+"tools.jar";
            ret = findResourceFromJarFile(javaToolsJar,name);
            if (ret != null)
                return ret;
        }
        return null;
    }

    URL findResourceFromJarFile(String classPath,String name) {
        try {
            JarFile jf = new JarFile(classPath);
            if (name.startsWith("/"))
                name=name.substring(1);
            JarEntry je = jf.getJarEntry(name);
            if (je==null)
                return null;
            URL url = new URL("jar:"+"file:"+classPath+"!/"+name);
            return url;
        } catch(Exception e) {
//e.printStackTrace();
            return null;
        }
    }
    URL findResourceFromFile(String classPath,String name) {
        try {
            if (!name.startsWith("/"))
                name = "/"+name;
            File f = new File(classPath+name);
            if (!f.isFile())
                return null;
            URL ret = f.toURL();
            if (ret != null)
                return ret;
            else
                return null;
        } catch(Exception e) {
            return null;
        }
    }

    URL findResourceFromRemoteElmVE(String elmve,String name) {
        try {
            RemoteElmVE remoteVE =
                (RemoteElmVE)Naming.lookup(elmve);
            byte[] b = remoteVE.elmFindResource(name);
            String s = ElmVE.elmVE.classesDir+name;
            if (s.startsWith("file:"))
                s = s.substring(5);
            File f = new File(s);
            f.getParentFile().mkdirs();
            FileOutputStream fos = new FileOutputStream(f);
            fos.write(b);
            return f.toURL();
        } catch(Exception e) {
            return null;
        }
    }

    URL findResourceFromRemoteElmBridge(String elmve,String name) {
        try {
            RemoteElmBridge remoteBridge =
                (RemoteElmBridge)Naming.lookup(
                    "//"+ElmVE.elmVE.elmConfig.elmBridge+"/ElmBridge");
            byte[] b = remoteBridge.elmFindResource(elmve,name);
            String s = ElmVE.elmVE.classesDir+name;
            if (s.startsWith("file:"))
                s = s.substring(5);
            File f = new File(s);
            f.getParentFile().mkdirs();
            FileOutputStream fos = new FileOutputStream(f);
            fos.write(b);
            return f.toURL();
        } catch(Exception e) {
            return null;
        }
    }

    byte[] elmFindResource(String name) {
        try {
            for (int i=0;i<exportElmClassPath.length;i++) {
                File f = new File(exportElmClassPath[i]+name);
                if (!f.isFile())
                    break;
                long l = f.length();
                byte b[] = new byte[(int)l];
                FileInputStream fis =
                    new FileInputStream(elmClassPath[i]+name);
                fis.read(b);
                return b;
            }
            return null;
        } catch(Exception e) {
            return null;
        }
    }

    protected void setElmClassPath(ArrayList<String> cp) {
        String cps[] = new String[cp.size()];
        Iterator i = cp.iterator();
        int j=0;
        while (i.hasNext()) {
            cps[j] = (String)i.next();
            j++;
        }
        elmClassPath = cps;
    }

    protected ArrayList<String> getElmClassPath() {
        ArrayList<String> ret = new ArrayList<String>();
        for (int i=0;i<elmClassPath.length;i++)
            ret.add(elmClassPath[i]);
        return ret;
    }

    protected void setExportElmClassPath(ArrayList<String> cp) {
        String cps[] = new String[cp.size()];
        Iterator i = cp.iterator();
        int j=0;
        while (i.hasNext()) {
            cps[j] = (String)i.next();
            j++;
        }
        exportElmClassPath = cps;
    }

    protected ArrayList<String> getExportElmClassPath() {
        ArrayList<String> ret = new ArrayList<String>();
        for (int i=0;i<exportElmClassPath.length;i++)
            ret.add(exportElmClassPath[i]);
        return ret;
    }

    void loadFromXML(Element e) throws Exception {
        Element ee = W.getChildByTagNameDOM(e,"innerPath");
        ArrayList al = W.getChildrenByTagNameDOM(ee,"path");
        ArrayList<String> cp = new ArrayList<String>();
        Iterator i = al.iterator();
        while (i.hasNext()) {
            Element eee = (Element)i.next();
            Text t = (Text)eee.getFirstChild();
            cp.add(t.getData());
        }
        setElmClassPath(cp);
        ee = W.getChildByTagNameDOM(e,"exportPath");
        al = W.getChildrenByTagNameDOM(ee,"path");
        cp = new ArrayList<String>();
        i = al.iterator();
        while (i.hasNext()) {
            Element eee = (Element)i.next();
            Text t = (Text)eee.getFirstChild();
            cp.add(t.getData());
        }
        setExportElmClassPath(cp);
        ee = W.getChildByTagNameDOM(e,"jdkHome");
        Text t = (Text)ee.getFirstChild();
        jdkHome = t.getData();
    }

    void saveAsXML(Document d,Element e) throws Exception {
        Element ee = W.makeElementDOM(d,"innerPath");
        W.addChildDOM(e,ee);
        W.addLineFeedDOM(d,ee);
        for (int i=0;i<elmClassPath.length;i++) {
            W.addDataDOM(d,ee,"path",elmClassPath[i]);
            W.addLineFeedDOM(d,ee);
        }
        W.addLineFeedDOM(d,e);
        ee = W.makeElementDOM(d,"exportPath");
        W.addChildDOM(e,ee);
        W.addLineFeedDOM(d,ee);
        for (int i=0;i<exportElmClassPath.length;i++) {
            W.addDataDOM(d,ee,"path",exportElmClassPath[i]);
            W.addLineFeedDOM(d,ee);
        }
        W.addLineFeedDOM(d,e);
        W.addDataDOM(d,e,"jdkHome",jdkHome);
        W.addLineFeedDOM(d,e);
    }
    void setJDKHome(String s) {
        jdkHome = s;
    }
    String getJDKHome() {
        return jdkHome;
    }
    void addClassPath(String s) {
        for (int i=0;i<elmClassPath.length;i++) {
            if (elmClassPath[i].equals(s))
                return;
        }
        String newElmClassPath[] = new String[elmClassPath.length+1];
        for (int i=0;i<elmClassPath.length;i++) {
            newElmClassPath[i] = elmClassPath[i];
        }
        newElmClassPath[elmClassPath.length] = s;
        elmClassPath = newElmClassPath;
    }
    void delClassPath(String s) {
        boolean b = false;
        for (int i=0;i<elmClassPath.length;i++) {
            if (elmClassPath[i].equals(s)) {
                b = true;
                break;
            }
        }
        if (b==false)
            return;
        String newElmClassPath[] = new String[elmClassPath.length-1];
        int ii = 0;
        for (int i=0;i<elmClassPath.length;i++) {
            if (elmClassPath[i].equals(s)) {
                continue;
            } else {
                newElmClassPath[ii] = elmClassPath[i];
                ii++;
            }
        }
        elmClassPath = newElmClassPath;
    }
}
