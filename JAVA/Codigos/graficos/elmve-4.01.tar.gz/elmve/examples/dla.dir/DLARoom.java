import ac.hiu.j314.elmve.*;

import java.util.*;

public class DLARoom extends Elm {
    public void exec(Order o) {
        ElmSet elms = getElmsInside("@DLA");
        send(makeMyOrder(elms,"exec",NULL));
    }

    public void susp(Order o) {
        ElmSet elms = getElmsInside("@DLA");
        send(makeMyOrder(elms,"susp",NULL));
    }

    public void makeDLAs(Request r) {
//        delAllElms();
        int n = r.getInt(0);
        for (int i=0;i<n;i++) {
            makeElmInside("DLA","n"+i);
            Place p = new Place(20.0*Math.random()-10.0,
                                20.0*Math.random()-10.0,
                                0.0);
            ElmStub elm = getElmInside("n"+i);
            send(makeOrder(elm,"setPlace",p));
        }
        repaint();
        send(makeReply(r,"Ok."));
    }
}
