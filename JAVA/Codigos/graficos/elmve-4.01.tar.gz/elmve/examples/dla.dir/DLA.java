import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.ui.*;
import java.io.*;
import java.awt.*;
import java.util.*;
import org.w3c.dom.*;

/** (DLA) **/
public class DLA extends Elm {
    public static Place origine = new Place();
    public boolean value = false;
    public boolean suspendRequest = false;

    protected String elm2DUIClass(){return "ac.hiu.j314.elmve.ui.EPoint2DUI";}

    public void getValue(Request r) {
        send(makeReply(r,value));
    }

    public void random_walk(MyOrder o) {
        if (value || suspendRequest)
            return;
        Place p1 = new Place();
        getPlace(p1);
        Place p2 = new Place(0.2*Math.random()-0.1,
                             0.2*Math.random()-0.1,0.0);
        p1.add(p2);
        double dd = p1.distance(origine);
        if (dd>10.0)
            p1.scale(10.0/dd);
        setPlace(p1);
        repaint();

        if (dd<0.2) {
            value = true;
            repaint();
            return;
        }

        ElmSet es = getNeighborElms(0.2,"DLA");
        if (es.size()==0) {
            send(makeMyOrder("random_walk",NULL));
            return;
        }
        ReqSet reqs = makeRequest(es,"getValue",NULL);
        receive(reqs,"check",NULL);
        send(reqs);
    }

    public void check(ReplySet rs) {
        for (int i=0;i<rs.getReplyCount();i++) {
            if (rs.getBoolean(i,0)) {
                value = true;
                repaint();
                return;
            }
        }
        send(makeMyOrder("random_walk",NULL));
    }

    public void exec(MyOrder o) {
        suspendRequest = false;
        send(makeMyOrder("random_walk",NULL));
    }

    public void susp(MyOrder o) {
        suspendRequest = true;
    }
//----------------------------------------------------------------------
    protected void saveExtension(Document d,Element e) {
        W.addDataDOM(d,e,"value",""+value);
    }
    protected void loadExtension(Element e,LoadedElmSet elmSet) {
        value = Boolean.valueOf(W.getDataDOM(e,"value")).booleanValue();
    }
//----------------------------------------------------------------------
    public void get2DUIData(MyRequest r) {
        Dimension d = new Dimension(10,10);
        Integer i = EPoint2DUI.CIRCLE;
        Color c = null;
        if (value)
            c = Color.white;
        else
            c = Color.black;
        send(makeReply(r,d,i,c));
    }
    public void get2DUIRepaintData(MyRequest r) {
        if (value)
            send(makeReply(r,Color.white));
        else
            send(makeReply(r,Color.black));
    }
}
