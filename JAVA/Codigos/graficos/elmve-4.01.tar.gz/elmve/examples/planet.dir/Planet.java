import ac.hiu.j314.elmve.*;
import java.util.*;

public class Planet extends Elm {
    Place v = new Place();
    Place f = new Place();

    public void calForce(MyRequest r) {
        ElmStub elms[] = (ElmStub[])getElms("@Planet").toArray(new ElmStub[0]);
        f = new Place();
        for (int i=0;i<elms.length;i++) {
            if (elms[i].equals(this)) continue;
            Place rr = new Place();
            rr.sub(getPlace(elms[i]),getPlace());
            double rrr = rr.length();
//            rr.scale(0.00001/rrr/rrr/rrr);
            rr.scale(0.00001/rrr/rrr);
            f.add(rr);
        }
        send(makeReply(r,NULL));
    }

    public void move(MyRequest r) {
        v.add(f);
        Place p = getPlace();
        p.add(v);
        setPlace(p);
        repaint();
        send(makeReply(r,NULL));
    }
}
