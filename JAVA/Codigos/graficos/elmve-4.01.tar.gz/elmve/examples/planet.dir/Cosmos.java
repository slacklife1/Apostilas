import ac.hiu.j314.elmve.*;
import java.util.*;

public class Cosmos extends Elm {
    boolean killq = false;

    public void exec(Order o) {
        killq = false;
        ElmSet es = getElmsInside("@Planet");
        ReqSet reqs = makeMyRequest(es,"calForce",NULL);
        receive(reqs,"move",NULL);
        send(reqs);
    }

    public void susp(Order o) {
        killq = true;
    }

    public void calForce(ReplySet r) {
        if (killq == true) return;
        ElmSet es = getElmsInside("@Planet");
        ReqSet reqs = makeMyRequest(es,"calForce",NULL);
        receive(reqs,"move",NULL);
        send(reqs);
    }

    public void move(ReplySet r) {
        ElmSet es = getElmsInside("@Planet");
        ReqSet reqs = makeMyRequest(es,"move",NULL);
        receive(reqs,"calForce",NULL);
        send(reqs);
    }
}
