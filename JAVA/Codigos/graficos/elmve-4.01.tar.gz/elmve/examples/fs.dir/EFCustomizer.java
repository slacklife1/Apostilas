import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.clients.*;
import java.io.*;
import java.awt.event.*;
import javax.swing.*;

public class EFCustomizer extends ElmCustomizer implements ActionListener {
    JFrame frame;
    JTextArea textArea;
    JButton doneButton;
    String elmName;
    String text;

    public void startProcessing(MyOrder o) {
        super.startProcessing(o);

        frame = new JFrame("EFCustomizer");
        String elmName = o.getString(0);
        String text = o.getString(1);
        Box box = Box.createVerticalBox();
        box.add(new JLabel(elmName));
        textArea = new JTextArea(text,10,10);
        box.add(textArea);
        doneButton = new JButton("Done");
        doneButton.addActionListener(this);
        box.add(doneButton);
        frame.getContentPane().add(box);
        frame.pack();
        frame.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        send(makeOrder(elm,"setText",textArea.getText()));
        frame.dispose();
        dispose();
    }
}
