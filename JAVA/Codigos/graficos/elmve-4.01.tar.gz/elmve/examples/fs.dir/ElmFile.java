import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.ui.*;
import java.awt.*;
import java.io.*;
import org.w3c.dom.*;

public class ElmFile extends Elm {
    String text = "null";

    protected String customizerClass(){return "EFCustomizer";}

    protected void saveExtension(Document d,Element e) {
        W.addDataDOM(d,e,"text",text);
    }
    protected void loadExtension(Element e,LoadedElmSet elmSet) {
        text = W.getDataDOM(e,"text");
    }
    public String toSaveString() {
        return super.toSaveString()+W.toSaveString(text);
    }

    public void loadFromText(ElmStreamTokenizer f_in) throws IOException {
        super.loadFromText(f_in);
        text = f_in.nextString();
    }

    public String toString() {
        return getName()+":\n"+text;
    }

    public void getCustomizerData(MyRequest r) {
        send(makeReply(r,getName(),text));
    }

    public void setText(Order o) {
        text = o.getString(0);
    }
}
