import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.comp.*;
import java.io.*;
import java.util.*;

public class ExecElm3 extends EButton {
    boolean b = true;

    public void catchEButtonEvent(Order o) {
        if (b)
            send(makeOrder(getElm("."),"exec",NULL));
        else
            send(makeOrder(getElm("."),"susp",NULL));
        b = !b;
    }
}
