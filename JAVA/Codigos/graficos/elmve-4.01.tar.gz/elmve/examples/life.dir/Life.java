import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.ui.*;
import java.util.*;
import java.awt.*;
import java.io.*;

public class Life extends Elm {
    boolean value;
    boolean nextValue;
    ElmSet neighbors;
    boolean edge;

    protected String elm2DUIClass(){return "ac.hiu.j314.elmve.ui.EPoint2DUI";}

    public void init(MyRequest r) {
        neighbors = getNearestElms(8,"Life");
        ReqSet rr = makeRequest(neighbors,"getPlace",this);
        receive(rr,"init2",r);
        send(rr);
    }
    public void init2(ReplySet rs) {
        Place pTmp = new Place();
        for (int i=0;i<8;i++)
            pTmp.add(rs.getPlace(i,0));
        pTmp.scale(1.0/8.0);
        pTmp.sub(getPlace());
        if (pTmp.length() > 0.001) {
            edge = true;
            value = false;
        } else {
            edge = false;
            value = Math.random()>0.8?true:false;
        }
        send(makeReply(rs.getMyRequest(0),NULL));
    }

    public void getValue(MyRequest r) {
        send(makeReply(r,value));
    }

    public void cal(MyRequest r) {
        ReqSet reqs = makeMyRequest(neighbors,"getValue",NULL);
        receive(reqs,"cal2",r);
        send(reqs);
    }
    public void cal2(ReplySet rs) {
        if (!edge) {
            int iTmp = 0;
            for (int i=0;i<8;i++)
                if (rs.getBoolean(i,0))
                    iTmp++;
            if (iTmp>3)
                nextValue = false;
            else if (iTmp>2)
                nextValue =true;
            else if (iTmp>1)
                nextValue = value;
            else
                nextValue = false;
        }
        send(makeReply(rs.getMyRequest(0),NULL));
    }

    public void change(MyRequest r) {
        if (!edge) {
            value = nextValue;
            repaint();
        }
        send(makeReply(r,NULL));
    }

    public void get2DUIData(MyRequest r) {
        Dimension d = new Dimension(13,13);
        Integer i = EPoint2DUI.SQUARE;
        send(makeReply(r,d,i,Color.white));
    }
    public void get2DUIRepaintData(MyRequest r) {
        send(makeReply(r,value?Color.black:Color.white));
    }
}
