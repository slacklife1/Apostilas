import ac.hiu.j314.elmve.*;
import java.util.*;

public class LifeSpace extends Elm {
    boolean killq = false;

    public void exec(Order o) {
        ElmSet es = getElmsInside("@Life");
        ReqSet reqs = makeMyRequest(es,"init",NULL);
        receive(reqs,"cal",NULL);
        send(reqs);
    }

    public void susp(Order o) {
        killq = true;
    }

    public void cal(ReplySet r) {
        if (killq == true) return;
        ElmSet es = getElmsInside("@Life");
        ReqSet reqs = makeMyRequest(es,"cal",NULL);
        receive(reqs,"change",NULL);
        send(reqs);
    }

    public void change(ReplySet r) {
        ElmSet es = getElmsInside("@Life");
        ReqSet reqs = makeMyRequest(es,"change",NULL);
        receive(reqs,"cal",NULL);
        send(reqs);
    }
}
