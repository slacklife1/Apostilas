import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.graph.*;
import java.awt.*;

public class SpringLine implements Line {
    protected Place head;
    protected Place tail;

    public SpringLine(Place h,Place t) {
        head = h;
        tail = t;
    }

    public Place getHeadPlace() {
        return head;
    }

    public Place getTailPlace() {
        return tail;
    }

    public void paint(Graphics g,Point h,Point t) {
        g.setColor(Color.red);
        g.drawLine(h.x,h.y,t.x,t.y);
    }
}
