import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.graph.*;
import java.util.*;

public class Sinker extends Node {
    Place v = new Place();
    Place f = new Place();

    public Sinker() {
        sockets.reset();
        sockets.addSocket("forceLink","SpringLink",-1,Sockets.BOTH);
    }

    public void calForce(MyRequest r) {
        Place pTmp = new Place();
        Place place1 = getPlace();
        f.set(0.0,0.0,0.0);
        ArrayList nodes = getLinkedNodes();
        Iterator i = nodes.iterator();
        while (i.hasNext()) {
            ElmStub a = (ElmStub)i.next();
            Place place2 = getPlace(a);
            double dist = place1.distance(place2);
            double k = 0.02*(dist-2.0);
            pTmp.sub(place2,place1);
            pTmp.scale(k);
            f.add(pTmp);
        }
        pTmp.set(0.0,-0.01,0.0);
        f.add(pTmp);
        pTmp.scale(-0.05,v);
        f.add(pTmp);
        send(makeReply(r,NULL));
    }

    public void move(MyRequest r) {
        Place pTmp = new Place();
        pTmp.scale(0.01,f);
        v.add(pTmp);
        Place t = getPlace();
        double txy[] = new double[3];
        double vxy[] = new double[3];
        t.get(txy);
        v.get(vxy);
        if (txy[0]<-8.0) vxy[0]= Math.abs(vxy[0]);
        if (txy[0]> 8.0) vxy[0]=-Math.abs(vxy[0]);
        if (txy[1]<-8.0) vxy[1]= Math.abs(vxy[1]);
        if (txy[1]> 8.0) vxy[1]=-Math.abs(vxy[1]);
        v.set(vxy);
        t.add(v);
        setPlace(t);
        repaint();
        send(makeReply(r,NULL));
    }
}
