import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.graph.*;
import java.util.*;

public class SNet extends Graph {
    boolean killq = false;

    public void exec(Order o) {
        killq = false;
        ElmSet es = getElmsInside("@Sinker");
        ReqSet reqs = makeMyRequest(es,"calForce",NULL);
        receive(reqs,"move",NULL);
        send(reqs);
    }

    public void susp(Order o) {
        killq = true;
    }

    public void calForce(ReplySet r) {
        ElmSet es = getElmsInside("@Sinker");
        ReqSet reqs = makeMyRequest(es,"calForce",NULL);
        receive(reqs,"move",NULL);
        send(reqs);
    }

    public void move(ReplySet r) {
        if (killq == true) return;
        ElmSet es = getElmsInside("@Sinker");
        ReqSet reqs = makeMyRequest(es,"move",NULL);
        receive(reqs,"calForce",NULL);
        send(reqs);
    }

}
