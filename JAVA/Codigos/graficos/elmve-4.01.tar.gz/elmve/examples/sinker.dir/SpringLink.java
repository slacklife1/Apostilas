import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.graph.*;

import java.io.*;

public class SpringLink extends Link {
    protected String elm2DUIClass(){return "ac.hiu.j314.elmve.ui.EHidden2DUI";}
    public void get2DUIData(MyRequest r) {
        send(makeReply(r,NULL));
    }
    public void get2DUIRepaintData(MyRequest r) {
        send(makeReply(r,NULL));
    }

    public void getLines(MyRequest r) {
        send(makeReply(r,new SpringLine(getPlace(head),getPlace(tail))));
    }

    public boolean isDirected() {
        return false;
    }
}
