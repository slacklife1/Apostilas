import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.graph.*;

public class Fulcrum extends Node {
    public Fulcrum() {
        sockets.reset();
        sockets.addSocket("forceLink","SpringLink",-1,Sockets.BOTH);
    }

    public void calForce(MyRequest r) {
        send(makeReply(r,NULL));
    }

    public void move(MyRequest r) {
        send(makeReply(r,NULL));
    }
}
