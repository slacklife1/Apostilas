import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.graph.*;
import java.awt.*;

public class MyLine implements Line {
    protected Place head;
    protected Place tail;

    public MyLine(Place h,Place t) {
        head = h;
        tail = t;
    }

    public Place getHeadPlace() {
        return head;
    }

    public Place getTailPlace() {
        return tail;
    }

    static int arcX[] = {0,20,20,0};
    static int arcY[] = {0,-5,5,0};

    public void paint(Graphics g,Point h,Point t) {
        g.setColor(Color.blue);
        double theta = Math.atan((double)(h.y-t.y)/(double)Math.abs(h.x-t.x));
        if (h.x-t.x>0)
            theta += Math.PI;
        else
            theta = - theta;
        double sin = Math.sin(theta);
        double cos = Math.cos(theta);
        Polygon arc = new Polygon();
        for (int i=0;i<4;i++)
            arc.addPoint((int)(cos*(double)arcX[i]-sin*(double)arcY[i]),
                         (int)(sin*(double)arcX[i]+cos*(double)arcY[i]));
        arc.translate((6*h.x+t.x)/7,(6*h.y+t.y)/7);
        g.fillPolygon(arc);
        g.drawLine(t.x,t.y,h.x,h.y);
    }
}

