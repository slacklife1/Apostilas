import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.graph.*;
import java.io.*;

public class MyLink extends Link {
    protected String text = "               ";

    public void getLines(MyRequest r) {
        send(makeReply(r,new MyLine(getPlace(head),getPlace(tail))));
    }

    public boolean isDirected() {
        return true;
    }

    protected String elm2DUIClass()
        {return "ac.hiu.j314.elmve.ui.ETextField2DUI";}
    public void get2DUIData(MyRequest r) {
        send(makeReply(r,text));
    }
    public void get2DUIRepaintData(MyRequest r) {
        send(makeReply(r,text));
    }
    public void catchETextFieldEvent(Order o) {
        text = o.getString(0);
    }
}

