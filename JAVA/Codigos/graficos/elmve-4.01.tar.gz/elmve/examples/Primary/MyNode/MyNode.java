import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.graph.*;

public class MyNode extends Node {
    protected void init() {
        super.init();
        sockets.reset();
        sockets.addSocket("myLink","MyLink",1,Sockets.BOTH);
    }
}

