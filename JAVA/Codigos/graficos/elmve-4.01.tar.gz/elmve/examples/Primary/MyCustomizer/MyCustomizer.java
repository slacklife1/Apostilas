import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.clients.*;
import java.io.*;
import java.awt.event.*;
import javax.swing.*;
import java.rmi.*;

public class MyCustomizer extends ElmCustomizer implements ActionListener {
    JFrame frame;
    JTextField textField1;
    JTextField textField2;
    JButton doneButton;

    public void startProcessing(MyOrder o) {
        super.startProcessing(o);

        frame = new JFrame("ExamCustomizer");
        Box box = Box.createVerticalBox();
        textField1 = new JTextField(40);
        textField1.addActionListener(this);
        box.add(textField1);
        textField2 = new JTextField(40);
        box.add(textField2);
        doneButton = new JButton("Done");
        doneButton.addActionListener(this);
        box.add(doneButton);
        frame.getContentPane().add(box);
        frame.pack();
        frame.setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == textField1) {
            send(makeOrder(elm,"catchNewLine",textField1.getText()));
            textField1.setText("");
        } else if (ae.getSource() == doneButton) {
            frame.dispose();
            dispose();
        }
    }

    public void catchNewLine(Order o) {
        textField2.setText(o.getString(0));
    }
}
