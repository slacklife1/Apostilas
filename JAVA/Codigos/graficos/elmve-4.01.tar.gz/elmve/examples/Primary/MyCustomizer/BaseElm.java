import ac.hiu.j314.elmve.*;
import java.io.*;

public class BaseElm  extends Elm {
    protected String customizerClass(){return "MyCustomizer";}

    public void getCustomizerData(MyRequest r) {
        send(makeReply(r,NULL));
    }

    public void catchNewLine(Order o) {
        String kaiwa = o.getString(0);
        send(makeOrder(customizerStack.getCustomizers(),"catchNewLine",kaiwa));
System.out.println(kaiwa);
    }
}
