#!/bin/sh
cp ../../../release/elmve.jar .

