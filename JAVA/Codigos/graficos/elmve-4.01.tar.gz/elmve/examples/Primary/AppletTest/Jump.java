import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.comp.*;
import java.io.*;

public class Jump extends EButton {
    public void catchEButtonEvent(Order o) {
        double x = 10.0*Math.random()-5.0;
        double y = 10.0*Math.random()-5.0;
        double z = 10.0*Math.random()-5.0;
        setPlace(new Place(x,y,z));
        repaint();
    }
}

