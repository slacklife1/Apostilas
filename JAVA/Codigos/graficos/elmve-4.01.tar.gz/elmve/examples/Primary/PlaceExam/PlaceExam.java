import ac.hiu.j314.elmve.*;

public class PlaceExam extends Elm {
    double theta;

    public void method1(Order o) {
        theta += 0.1;
        double xyz[] = new double[3];
        xyz[0] = 5.0*Math.cos(theta);
        xyz[1] = 5.0*Math.sin(theta);
        setPlace(xyz);
        repaint();
        send(makeOrder("method1",NULL),1000);
    }
}
