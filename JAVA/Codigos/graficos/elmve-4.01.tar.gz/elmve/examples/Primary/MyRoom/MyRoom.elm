<?xml version="1.0" encoding="UTF-8"?>
<elmData>
<elm>
<basicData>
<className>MyRoom</className>
<name>MyRoom</name>
<place x="0.0" y="0.0" z="0.0"/>
<rotation w="1.0" x="0.0" y="0.0" z="0.0"/>
</basicData>
<children>
<elm>
<basicData>
<className>OrderExam</className>
<name>node1</name>
<place x="0.0" y="0.0" z="0.0"/>
<rotation w="1.0" x="0.0" y="0.0" z="0.0"/>
</basicData>
<children/>
</elm>
<elm>
<basicData>
<className>OrderExam</className>
<name>node2</name>
<place x="1.0" y="-1.0" z="0.0"/>
<rotation w="1.0" x="0.0" y="0.0" z="0.0"/>
</basicData>
<children/>
</elm>
<elm>
<basicData>
<className>OrderExam</className>
<name>node3</name>
<place x="-1.0" y="-1.0" z="0.0"/>
<rotation w="1.0" x="0.0" y="0.0" z="0.0"/>
</basicData>
<children/>
</elm>
</children>
</elm>
</elmData>