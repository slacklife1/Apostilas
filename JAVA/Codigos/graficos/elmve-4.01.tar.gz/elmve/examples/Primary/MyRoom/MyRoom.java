import ac.hiu.j314.elmve.*;
import java.util.*;

public class MyRoom extends Elm {
    public void searchNextElm(Request r) {
        ElmSet es = getElmsInside("@OrderExam");
        ReqSet reqs = makeRequest(es,"searchNextElm",NULL);
        receive(reqs,"searchNextElm2",r);
        send(reqs);
    }
    public void searchNextElm2(ReplySet rs) {
        send(makeReply(rs.getRequest(0),"Ok"));
    }

    public void loop(Request r) {
        ElmStub elm = getElmInside("node1");
        send(makeOrder(elm,"loop",NULL));
        send(makeReply(r,"Ok."));
    }
}
