import ac.hiu.j314.elmve.*;

public class OrderExam extends Elm {
    ElmStub nextElm;

    public void searchNextElm(Request r) {
        String nextElmName = null;
        if (getName().equals("node1")) {
            nextElmName = "node2";
        } else if (getName().equals("node2")){
            nextElmName = "node3";
        } else if (getName().equals("node3")) {
            nextElmName = "node1";
        }
        nextElm = getElm(nextElmName);
        send(makeReply(r,"Ok"));
    }

    public void loop(Order o) {
        System.out.println(getName());
        send(makeOrder(nextElm,"loop",NULL));
    }
}
