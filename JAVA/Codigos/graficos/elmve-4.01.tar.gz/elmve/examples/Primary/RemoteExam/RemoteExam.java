import ac.hiu.j314.elmve.*;

public class RemoteExam extends Elm {
    String remotePath = "//localhost/ElmVE/remote";

    public void setRemotePath(Order o) {
        remotePath = o.getString(0);
    }

    public void remoteCall1(Order o) {
        ElmStub elm = getElm(remotePath);
        send(makeOrder(elm,"remoteCall2",NULL));
    }

    public void remoteCall2(Order o) {
        System.out.println("remoteCall2");
    }
}
