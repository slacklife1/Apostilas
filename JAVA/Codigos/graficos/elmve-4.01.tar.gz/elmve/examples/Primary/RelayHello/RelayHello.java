import ac.hiu.j314.elmve.*;

public class RelayHello extends Elm {
    public void relayHello(Request r1) {
        ElmStub helloElm = getElm("hello");
        Request r2 = makeRequest(helloElm,"hello",NULL);
        receive(r2,"relayHello2",r1);
        send(r2);
    }
    public void relayHello2(ReplySet rs) {
        String helloMessage = rs.getString(0,0);
        send(makeReply(rs.getRequest(0),helloMessage));
    }
}
