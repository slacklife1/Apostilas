import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.clients.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class My2DUI extends Elm2DUI implements ActionListener {
    String msg[] = {"msg0","msg1","msg2","msg3","msg4",
                    "msg5","msg6","msg7","msg8","msg9"};
    int counter = 0;
    JButton lButton;
    JLabel msgLabel;
    JButton rButton;

    public My2DUI() {
        this.setLayout(new BoxLayout(this,BoxLayout.X_AXIS));
    }

    public void init(Elm2DData d) {
        counter = d.getInt(0) % 10;
        lButton = new JButton("<");
        lButton.addActionListener(this);
        add(lButton);
        msgLabel = new JLabel(msg[counter]);
        add(msgLabel);
        rButton = new JButton(">");
        rButton.addActionListener(this);
        add(rButton);
    }

    public void update(Elm2DData d) {
        counter = d.getInt(0) % 10;
        msgLabel.setText(msg[counter]);
        repaint();
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == lButton) {
            counter += 9; counter = counter % 10;
            msgLabel.setText(msg[counter]);
            repaint();
            send(makeOrder("lButton",W.p(counter)));
        } else if (ae.getSource() == rButton) {
            counter++; counter = counter % 10;
            msgLabel.setText(msg[counter]);
            repaint();
            send(makeOrder("rButton",W.p(counter)));
        }
    }
}
