import ac.hiu.j314.elmve.*;

import java.io.*;

public class MyElm3 extends Elm {
    int n;

    protected String elm2DUIClass(){return "My2DUI";}

    public void get2DUIData(MyRequest r) {
        send(makeReply(r,W.pp(W.p(0))));
    }
    public void get2DUIRepaintData(MyRequest r) {
        send(makeReply(r,W.pp(W.p(n))));
    }

    public void lButton(Order o) {
	n = o.getInt(0); 
        System.out.println("MyElm3.lButton().");
    }

    public void rButton(Order o) {
        n = o.getInt(0);
	System.out.println("MyElm3.rButton().");
    }

    public void setNumber(Order o) {
        n = o.getInt(0)%10;
        repaint();
    }
}
