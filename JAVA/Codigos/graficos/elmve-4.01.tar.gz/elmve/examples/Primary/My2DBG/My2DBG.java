import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.clients.*;

import java.io.*;
import java.awt.*;

public class My2DBG extends Elm2DBG {
    int n;

    public void init(Elm2DData d) {
        n = d.getInt(0);
    }

    public void update(Elm2DData d) {
        n = d.getInt(0);
        repaint();
    }

    public void paintComponent(Graphics g) {
        g.setColor(getBackground());
        g.fillRect(0,0,getWidth(),getHeight());
        g.setColor(Color.black);

        double deltaTheta = 2.0*Math.PI/(double)n;
        double theta1 = 0.0;
        double theta2 = 0.0;
        for (int i=0;i<n;i++) {
            theta2 = theta1 + deltaTheta;
            double x1 = 3.0*Math.cos(theta1);
            double y1 = 3.0*Math.sin(theta1);
            double x2 = 3.0*Math.cos(theta2);
            double y2 = 3.0*Math.sin(theta2);

            Point p1 = placeToPoint(x1,y1);
            Point p2 = placeToPoint(x2,y2);
            g.drawLine(p1.x,p1.y,p2.x,p2.y);

            theta1 = theta1 + deltaTheta;
        }
    }
}
