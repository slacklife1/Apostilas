import ac.hiu.j314.elmve.*;

import java.io.*;

public class My2DBGTest extends Elm {
    int c = 0;

    protected String elm2DBGClass(){return "My2DBG";}

    public void get2DBGData(MyRequest r) {
        send(makeReply(r,c+3));
    }

    public void get2DBGRepaintData(MyRequest r) {
        send(makeReply(r,c+3));
    }

    public void method1(Order o) {
        c++; c = c % 3;
        repaint();
        send(makeOrder("method1",NULL),1000);
    }
}
