import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.ui.*;

import java.io.*;

public class Ch2DUI extends Elm {
    int imgNo;

    protected String elm2DUIClass(){return "ac.hiu.j314.elmve.ui.EIcon2DUI";}
    protected String elm2DBGClass(){return "ac.hiu.j314.elmve.ui.Simple2DBG";}

    public void get2DUIData(MyRequest r) {
        Serializable images[] = {"x-res:///testImage0.gif",
                                 "x-res:///testImage1.gif"};
        send(makeReply(r,images,0,true));
    }
    public void get2DUIRepaintData(MyRequest r) {
        send(makeReply(r,imgNo));
    }

    public void method1(Order o) {
        imgNo = (imgNo==0)?1:0;
        repaint();
        send(makeOrder("method1",NULL),5000);
    }
}
