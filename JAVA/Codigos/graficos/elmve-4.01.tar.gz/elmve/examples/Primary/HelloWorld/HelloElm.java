import ac.hiu.j314.elmve.*;

public class HelloElm extends Elm {
    public void hello(Request r) {
        send(makeReply(r,"Hello Virtual World!"));
    }
}
