import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.clients.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MyClient extends ElmClient implements ActionListener {
    JFrame frame;
    JTextField textField;
    JTextArea textArea;

    protected void init() {
        super.init();
        initOwnEngine("MyClient",1);
    }

    public void startProcessing(MyOrder o) {
        frame = new JFrame("MyClient");
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                quit();
                try{Thread.sleep(3000);}catch(Exception e){;}
                kill();
                try{Thread.sleep(3000);}catch(Exception e){;}
                System.exit(1);
            }
        });
        textField = new JTextField();
        textField.addActionListener(this);
        textArea = new JTextArea(10,20);
        JScrollPane sp = new JScrollPane(textArea);
        frame.getContentPane().setLayout(new BorderLayout());
        frame.getContentPane().add(textField);
        frame.getContentPane().add(sp,"South");
        frame.pack();
        frame.setVisible(true);
    }

    public void configPreference(MyRequest r) {
        super.configPreferenceGUI(r);
    }

    public void passwordInput(MyRequest r) {
        super.passwordInputGUI(r);
    }

    public void printReply(ReplySet rs) {
        print(rs.toString());
    }

    public void printMessage(Order o) {
        print(o.getString(0));
    }

    protected void print(String s) {
        textArea.append(s);
    }

    public void refresh(Request r) {
        textArea.setText(null);
        send(makeReply(r,NULL));
    }

    public void close() {
        frame.dispose();
    }


    public void actionPerformed(ActionEvent ae) {
        try {
            if (ae.getSource() == textField) {
                processCommand(textField.getText());
                textField.setText("");
            }
        } catch (ElmException ee) {
            ee.printStackTrace();
        }
    }
}
