#!/bin/sh

if echo `ps auxw` | grep [r]miregistry > /dev/null ; then
    echo "rmiregistry is already running."
else
    echo "starting rmiregistry."
    rmiregistry &
fi

java -cp .:../../../release/elmve-all.jar ac.hiu.j314.elmve.ElmVE --client MyClient $* &
