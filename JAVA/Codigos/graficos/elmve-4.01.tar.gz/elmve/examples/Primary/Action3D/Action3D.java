import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.ui.*;

import java.io.*;

public class Action3D extends Elm {
    int imgNo;

    protected String elm3DUIClass(){return "ac.hiu.j314.elmve.ui.Action3DUI";}

    public void get3DUIData(MyRequest r) {
        send(makeReply(r,"file:/home/ksaito/media/A3/ballet/ballet.a3",
                         0,getName(),true));
    }
    public void get3DUIRepaintData(MyRequest r) {
        send(makeReply(r,imgNo));
    }

    public void method1(Order o) {
        imgNo = (imgNo==0)?1:0;
        repaint();
        send(makeOrder("method1",NULL),5000);
    }
}
