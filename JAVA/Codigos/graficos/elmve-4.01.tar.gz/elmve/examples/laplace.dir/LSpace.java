import ac.hiu.j314.elmve.*;

import java.util.*;

public class LSpace extends Elm {
    public void exec(Order o) {
        ElmSet elms = getElmsInside("@Laplace");
        send(makeMyOrder(elms,"exec",NULL));
    }

    public void susp(Order o) {
        ElmSet elms = getElmsInside("@Laplace");
        send(makeMyOrder(elms,"susp",NULL));
    }

    public void makeLaplaces(Request r) {
//        delAllElms();
        int n = r.getInt(0);
        int nn = (int)Math.floor(Math.sqrt((double)n));
        for (int i=0;i<n;i++) {
            makeElmInside("Laplace","n"+i);
            Place p = new Place((i % nn)*(16.0-2.0)/nn-7.0,
                                (i / nn)*(16.0-2.0)/nn-7.0,
                                0.0);
            ElmStub elm = getElmInside("n"+i);
            send(makeOrder(elm,"setPlace",p));
        }
        repaint();
        send(makeReply(r,"Ok."));
    }
}
