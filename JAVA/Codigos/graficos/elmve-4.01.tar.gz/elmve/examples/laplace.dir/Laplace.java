import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.ui.*;
import java.io.*;
import java.util.*;
import java.awt.*;

public class Laplace extends Elm {
    float value = 0.5f;
    float oldValue = 100.0f;
    boolean edge = false;
    ElmSet neighbors;
    boolean stopRequest = false;

    protected String elm2DUIClass(){return "ac.hiu.j314.elmve.ui.EPoint2DUI";}

    public void exec(MyOrder o) {
        neighbors = getNearestElms(4,"Laplace");
        ReqSet rr = makeRequest(neighbors,"getPlace",this);
        receive(rr,"exec2",NULL);
        send(rr);
    }
    public void exec2(ReplySet rs) {
        Place pTmp = new Place();
        for (int i=0;i<4;i++)
            pTmp.add(rs.getPlace(i,0));
        pTmp.scale(1.0/4.0);
        pTmp.sub(getPlace());
        if (pTmp.length() > 0.001) {
            edge = true;
            getPlace(pTmp);
            double dist = pTmp.distance(new Place(5.0,5.0,0.0));
            value = (float)(0.5+0.499*Math.sin(dist));
        } else {
            getPlace(pTmp);
            if (pTmp.length() < 2.5) {
                edge = true;
                value = 1.0f;
            }
        }
        repaint();
        send(makeMyOrder("move",NULL));
    }

    public void getValue(Request r) {
        send(makeReply(r,value));
    }

    public void move(MyOrder o) {
        if (stopRequest || edge)
            return;
        ReqSet reqs = makeRequest(neighbors,"getValue",NULL);
        receive(reqs,"move2",NULL);
        send(reqs);
    }
    public void move2(ReplySet rs) {
        oldValue = value;
        float vTmp = rs.getFloat(0,0);
        vTmp += rs.getFloat(1,0);
        vTmp += rs.getFloat(2,0);
        vTmp += rs.getFloat(3,0);
        value = vTmp/4.0f;
        repaint();
        if (Math.abs(value-oldValue)< 0.001)
            return;
        send(makeMyOrder("move",NULL));
    }

    public void susp(Order o) {
        stopRequest = true;
    }

//----------------------------------------------------------------------

    public void get2DUIData(MyRequest r) {
        Dimension d = new Dimension(13,13);
        Integer i = EPoint2DUI.SQUARE;
        Color c = new Color(value,0.0f,1.0f-value);
        send(makeReply(r,d,i,c));
    }
    public void get2DUIRepaintData(MyRequest r) {
        send(makeReply(r,new Color(value,0.0f,1.0f-value)));
    }
}
