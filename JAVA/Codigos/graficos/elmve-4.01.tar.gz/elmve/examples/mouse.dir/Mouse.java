import ac.hiu.j314.elmve.*;
import ac.hiu.j314.elmve.ui.*;
import ac.hiu.j314.elmve.graph.*;
import java.awt.*;
import java.io.*;
import java.util.*;

public class Mouse extends SNode {
    boolean value = false;

    protected String elm2DUIClass()
        {return "ac.hiu.j314.elmve.ui.ECheckBox2DUI";}

    public void catchECheckBoxEvent(Order o) {
        value = !value;
        repaint();
        ElmSet nodes = getOutNodes();
        send(makeOrder(nodes,"catchECheckBoxEvent",NULL));
    }

    public void get2DUIData(MyRequest r) {
        send(makeReply(r,value));
    }
    public void get2DUIRepaintData(MyRequest r) {
        send(makeReply(r,value));
    }
}
