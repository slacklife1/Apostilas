/*
 * Program - Sr Slider
 * File Name - SR_Slider.java
 * Author - Shovon
 * Web site - http://www.shuvorim.tk
 * Email - ahsanul_haque_shovon@yahoo.com
 * (C) http://www.shuvorim.tk
 * All rights reserved.
 */


//imports
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.net.*;
import java.io.*;

public class SR_Slider extends Frame implements ActionListener, WindowListener, Runnable
{
  public static void main(String Pagli[])
  {
    new SR_Slider();
  }

  Thread time; //new thread
  File fl;
  URL dir;
  MediaTracker mt;

  //here you can use an array
  Image p1, p2, p3, p4, p5, p6, p7,
  p8, p9, p10, p11, p12, p13, p14,
  p15, p16, p17, p18, p19, p20;

  About ab; //instance of About class
  Panel bottom;

  AudioClip b_n, rfs;
  Toolkit tk;
  Dimension dim;

  Button back, next, refresh, auto, abt, ext;
  Color sky;
  Font f;
  int count, x;

  public SR_Slider()
  {
    setTitle("SR-Slider 1.0");
    setLayout(new BorderLayout());
    bottom = new Panel();

    time = new Thread(this);
    sky = new Color(0,140,255); //color - skyblue
    setBackground(Color.white);
    f = new Font("Courier",Font.BOLD,16);
    count = 0;
    x = 0;
    mt=new MediaTracker(this);

    try
    {
      //getting all images and add them to the MediaTracker
      p1 = Toolkit.getDefaultToolkit().getImage("image/p1.jpg");
      mt.addImage(p1, 0);
      p2 = Toolkit.getDefaultToolkit().getImage("image/p2.jpg");
      mt.addImage(p2, 1);
      p3 = Toolkit.getDefaultToolkit().getImage("image/p3.jpg");
      mt.addImage(p3, 2);
      p4 = Toolkit.getDefaultToolkit().getImage("image/p4.jpg");
      mt.addImage(p4, 3);
      p5 = Toolkit.getDefaultToolkit().getImage("image/p5.jpg");
      mt.addImage(p5, 4);
      p6 = Toolkit.getDefaultToolkit().getImage("image/p6.jpg");
      mt.addImage(p6, 5);
      p7 = Toolkit.getDefaultToolkit().getImage("image/p7.jpg");
      mt.addImage(p7, 6);

      fl = new File("user.dir");
      dir = fl.toURL();
      b_n = Applet.newAudioClip(new URL(dir, "sound/bk_nxt.au"));
      rfs = Applet.newAudioClip(new URL(dir, "sound/rfsh.au"));
    }

    catch(MalformedURLException e)
    {
      //do nothing!
    }

    //designing back button	
    back=new Button("Back");
    back.setFont(f);
    back.setBackground(sky);
    back.setForeground(Color.white);

    //designing next button
    next=new Button("Next");
    next.setFont(f);
    next.setBackground(sky);
    next.setForeground(Color.white);

    //designing refresh button
    refresh=new Button("Reset");
    refresh.setFont(f);
    refresh.setBackground(sky);
    refresh.setForeground(Color.white);

    //designing auto button
    auto=new Button("SlideShow");
    auto.setFont(f);
    auto.setBackground(sky);
    auto.setForeground(Color.white);

    //designing abt button
    abt=new Button("About");
    abt.setFont(f);
    abt.setBackground(sky);
    abt.setForeground(Color.white);

    //designing ext button
    ext=new Button("Exit");
    ext.setFont(f);
    ext.setBackground(sky);
    ext.setForeground(Color.white);

    //adding ActionListener to all buttons
    back.addActionListener(this);
    next.addActionListener(this);
    refresh.addActionListener(this);
    auto.addActionListener(this);
    abt.addActionListener(this);
    ext.addActionListener(this);

    //adding all components to the Frame
    bottom.add(back);
    bottom.add(next);
    bottom.add(refresh);
    bottom.add(auto);
    bottom.add(abt);
    bottom.add(ext);

    add(bottom, BorderLayout.SOUTH);
    addWindowListener(this);

    tk = this.getToolkit();
    dim = tk.getScreenSize(); //getting the current screen resolution

    setBounds(dim.width/6, dim.height/6, 540, 420);
    setResizable(false);
    setVisible(true);
  }

  public void paint(Graphics g)
  {
    if(count <  1)
     g.drawImage(p1, 0, 0, this);

    if(count == 1)
     g.drawImage(p2, 0, 0, this);

    if(count == 2)
     g.drawImage(p3, 0, 0, this);

    if(count == 3)
     g.drawImage(p4, 0, 0, this);

    if(count == 4)
     g.drawImage(p5, 0, 0, this);

    if(count == 5)
     g.drawImage(p6, 0, 0, this);

    if(count == 6)
     g.drawImage(p7, 0, 0, this);
  }

  public void update(Graphics g)
  {
    paint(g);
  }

  public void actionPerformed(ActionEvent ae)
  {
    if(ae.getSource() == ext)
    {
      dispose();
      setVisible(false);
      System.exit(0);
    }

    if(ae.getSource() == next)
    {
      b_n.play();

      if(count < 7)
      {
	count++;
	repaint();
      }
    }

    if(ae.getSource() == back)
    {
      b_n.play();

      if(count == 0)
       count=0;

      if(count > 0)
      {
	count--;
	repaint();
      }
    }

    if(ae.getSource() == refresh)
    {
      rfs.play();
      time.suspend(); //suspends the thread
      count=0;
      repaint();
    }

    if(ae.getSource() == auto)
    {
      b_n.play();

      if(x < 1)
      {
	time.start();
	x++;
      }

      else
      {
	time.resume(); //resumes the thread
      }
    }

    if(ae.getSource() == abt)
    {
      ab = new About();
    }
  }

  public void run()
  {
    try
    {
      for(int i=1;i>0;i++)
      {
	b_n.play();
	time.sleep(3000);
	count++;

	if(count > 6)
	{
	  time.suspend(); //suspends the thread
	  count = 0;
	}

	repaint();
      }
    }

    catch(InterruptedException e)
    {
      //do nothing!
    }
  }

  //handling window events
  public void windowClosing(WindowEvent we)
  {
    dispose();
    setVisible(false);
    System.exit(0);
  }

  public void windowClosed(WindowEvent we)
  {
    //do nothing!
  }

  public void windowOpened(WindowEvent we)
  {
    //do nothing!
  }

  public void windowActivated(WindowEvent we)
  {
    //do nothing!
  }

  public void windowDeactivated(WindowEvent we)
  {
    //do nothing!
  }

  public void windowIconified(WindowEvent we)
  {
    //do nothing!
  }

  public void windowDeiconified(WindowEvent we)
  {
    //do nothing!
  }

  class About extends Frame implements WindowListener
  {
    Font f, f2;
    Color sky;

    private About()
    {
      setTitle("About");
      setLayout(new FlowLayout());
      setBackground(Color.white);

      f = new Font("Verdana", Font.BOLD, 24);
      f2 = new Font("Verdana", Font.BOLD, 12);
      sky = new Color(0,140,255); //color - skyblue

      addWindowListener(this);
      tk = this.getToolkit();
      dim = tk.getScreenSize(); //getting the current screen resolution

      setBounds(dim.width/4, dim.height/4, 280,190);
      setResizable(false);
      setVisible(true);
    }

    public void paint(Graphics g)
    {
      g.setColor(Color.red);
      g.setFont(f);
      g.drawString("SR-Slider 1.0", 10, 60);
      g.setColor(sky);
      g.setFont(f2);
      g.drawString("Author: Shovon", 10, 80);
      g.drawString("http://www.shuvorim.tk", 10, 100);
      g.drawString("ahsanul_haque_shovon@yahoo.com", 10, 120);
      g.drawString("(C) http://www.shuvorim.tk", 10, 140);
      g.drawString("All rights reserved.", 10, 160);
    }

    //handling window events
    public void windowClosing(WindowEvent we)
    {
      dispose();
      setVisible(false);
    }

    public void windowClosed(WindowEvent we)
    {
      //do nothing!
    }

    public void windowOpened(WindowEvent we)
    {
      //do nothing!
    }

    public void windowActivated(WindowEvent we)
    {
      //do nothing!
    }

    public void windowDeactivated(WindowEvent we)
    {
      //do nothing!
    }

    public void windowIconified(WindowEvent we)
    {
      //do nothing!
    }

    public void windowDeiconified(WindowEvent we)
    {
      //do nothing!
    }
  }
}
