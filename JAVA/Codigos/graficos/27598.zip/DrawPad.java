import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DrawPad extends JFrame {
    
    public DrawPad() {
        init();
    }
    
    private void init() {
        jPanel1 = new JPanel();
        jColorChooser1 = new JColorChooser();

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent evt) {
                exitForm(evt);
            }
        });

        jPanel1.setBackground(new Color(255, 255, 255));
        jPanel1.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent evt) {
                jPanel1MousePressed(evt);
            }
        });

        jPanel1.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent evt) {
                jPanel1MouseDragged(evt);
            }
        });

        getContentPane().add(jPanel1, BorderLayout.CENTER);

        jColorChooser1.setAutoscrolls(true);
        getContentPane().add(jColorChooser1, BorderLayout.SOUTH);

        pack();
    }

    private void jPanel1MouseDragged(MouseEvent evt) {
        int x = evt.getX(), y = evt.getY();
        Graphics g = jPanel1.getGraphics();

        g.setColor(jColorChooser1.getColor());
        
        g.drawLine(old_mouse_x, old_mouse_y, x, y);
        old_mouse_x = x;
        old_mouse_y = y;
    }

    private void jPanel1MousePressed(MouseEvent evt) {
        old_mouse_x = evt.getX();
        old_mouse_y = evt.getY();
        System.out.println(old_mouse_x);
    }

    private void exitForm(WindowEvent evt) {
        System.exit(0);
    }

    public static void main(String args[]) {
        new DrawPad().show();
    }
    
    
    private JColorChooser jColorChooser1;
    private JPanel jPanel1;
    
    private int old_mouse_x = 0;
    private int old_mouse_y = 0;
    
    private Dimension size = new Dimension(600, 600);
    
    public Dimension getPreferredSize() {
        return size;
    }
}
