/*
 * Copyright 2005 Frank W. Zammetti
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package javawebparts.taglib.ajaxtags.config;


import java.lang.reflect.Field;


/**
 * This class holds configuration information on an event handler defined for
 * a given event of an Ajax-enabled element.  This class represents both
 * request and response handlers (the target parameter is ignored for
 * response handlers).
 *
 * @author <a href="mailto:fzammetti@omnytex.com">Frank W. Zammetti</a>
 */
public class AjaxEventHandler {


  /**
   * The type of a handler.
   */
  private String type = "";


  /**
   * The target a handler submits its request to if it is a request handler
   */
  private String target = "";


  /**
   * The parameter for a handler.  Meaning of value is handler-specific.
   */
  private String parameter = "";


  /**
   * The method for a handler.  Either GET or POST.
   */
  private String method = "GET";


  /**
   * Flag: Is the configuration frozen?
   */
  private boolean frozen;


  /**
   * Sets the method of this event handler.
   *
   * @param inMethod The method of this event handler
   */
  public void setMethod(String inMethod) {

    if (!frozen) {
      method = inMethod.toUpperCase();
    }

  } // End setMethod().


  /**
   * Returns the method of this event handler.
   *
   * @return The method of this event handler
   */
  public String getMethod() {

    return method;

  } // End getMethod().


  /**
   * Sets the type of this event handler.
   *
   * @param inType The type of this event handler
   */
  public void setType(String inType) {

    if (!frozen) {
      type = inType;
    }

  } // End setType().


  /**
   * Returns the type of this event handler.
   *
   * @return The type of this event handler
   */
  public String getType() {

    return type;

  } // End getType().


  /**
   * Sets the target (URL) of this handler.
   *
   * @param inTarget The URL this handler submits to
   */
  public void setTarget(String inTarget) {

    if (!frozen) {
      target = inTarget;
    }

  } // End setTarget().


  /**
   * Returns the target (URL) of this handler.
   *
   * @return The URL this handler submits to
   */
  public String getTarget() {

    return target;

  } // End getTarget().


  /**
   * Sets the handler-specific parameter string for this handler.
   *
   * @param inParameter The parameter string for this handler
   */
  public void setParameter(String inParameter) {

    if (!frozen) {
      parameter = inParameter;
    }

  } // End setParameter().


  /**
   * Returns the handler-specific parameter string for this handler.
   *
   * @return The parameter string for this handler
   */
  public String getParameter() {

    return parameter;

  } // End getParameter().


  /**
   * Freezes the configuration of this object.
   */
  public void freeze() {

    frozen = true;

  } // End freeze().


  /**
   * Returns true if this onject's config is frozen, false otherwise.
   *
   * @return True if frozen, false if not.
   */
  public boolean isFrozen() {

    return frozen;

  } // End isFrozen().


  /**
   * Overriden toString method.
   *
   * @return A reflexively-built string representation of this bean
   */
  public String toString() {

    String str = null;
    StringBuffer sb = new StringBuffer(1000);
    sb.append("[" + super.toString() + "]={");
    boolean firstPropertyDisplayed = false;
    try {
      Field[] fields = this.getClass().getDeclaredFields();
      for (int i = 0; i < fields.length; i++) {
        if (firstPropertyDisplayed) {
          sb.append(", ");
        } else {
          firstPropertyDisplayed = true;
        }
        sb.append(fields[i].getName() + "=" + fields[i].get(this));
      }
      sb.append("}");
      str = sb.toString().trim();
    } catch (IllegalAccessException iae) { iae.printStackTrace(); }
    return str;

  } // End toString().


} // End class.