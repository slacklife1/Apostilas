/*
 * Copyright 2005 Frank W. Zammetti
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package javawebparts.taglib.ajaxtags.handlers;


/**
 * This class renders the Javascript for the request sender function.  This is
 * used by all std request handlers.
 *
 * @author <a href="mailto:fzammetti@omnytex.com">Frank W. Zammetti</a>
 */
public class RequestSender implements HandlerRendererBase {

  /**
   * This is the contextPath of the request being serviced.
   */
  private String contextPath;


  /**
   * Debug flag, should the Ajax calls be debugged or not
   */
  private boolean debug;


  /**
   * Mutator for contextPath field.
   *
   * @param inContextPath New value for contextPath field.
   */
  public void setContextPath(String inContextPath) {

    contextPath = inContextPath;

  } // End setContextPath.


  /**
   * Setter for the debugFlag
   *
   * @param inDebugFlag debugFlag
   */
  public void setDebug(boolean inDebugFlag) {

    debug = inDebugFlag;

  } // End setDebug()



  /**
   * Render the Javascript for the common ajaxRequestSender function, and
   * the accompanying page-scope variables.
   *
   * @return The Javascript to insert into the page
   */
  public String render() {

    StringBuffer sb = new StringBuffer(2048);

    sb.append("<script>\n");

    // Globals
    sb.append("var calls = new Array();\n");
    sb.append("var pendingResponseCount = 0;\n");
    sb.append("var shouldDebugAjax = ");
    if (debug) {
      sb.append("true");
    } else {
      sb.append("false");
    }
    sb.append(";\n");
    sb.append("var assureUnique = 1;\n");
    sb.append("\n");

    // ajaxRequestSender()
    sb.append("function ajaxRequestSender(form, target, qs, dom, " +
      "resHandler, resHandlerParam, method, async, mungedRef, timerObj, " +
      "ajaxRef) {\n\n");
    sb.append("  contextPath = \"" + contextPath + "\";\n");
    sb.append("  if (target.charAt(0) == '/') {\n");
    sb.append("    targetURI = contextPath + target;\n");
    sb.append("  } else {\n");
    sb.append("    targetURI = target;\n");
    sb.append("  }\n");
    sb.append("  if (shouldDebugAjax) {\n");
    sb.append("    alert('ajaxRequestSender() called.  About to " +
      "request URL\\n'\n");
    sb.append("    + 'call key: [' + calls.length + ']\\n'\n");
    sb.append("    + 'URL: [' + targetURI + ']\\n'\n");
    sb.append("    + 'form: [' + form + ']\\n'\n");
    sb.append("    + 'dom(xml): [' + dom + ']\\n'\n");
    sb.append("    + 'resHandlerParam: [' + resHandlerParam + ']\\n'\n");
    sb.append("    + 'callback function: [' + resHandler + ']\\n'\n");
    sb.append("    + 'async: [' + async + ']\\n'\n");
    sb.append("    + 'method: [' + method + ']\\n'\n");
    sb.append("    + 'mungedRef: [' + mungedRef + ']\\n'\n");
    sb.append("    + 'timerObj: [' + timerObj + ']\\n'\n");
    sb.append("    + 'method: [' + method + ']\\n'\n");
    sb.append("    + 'ajaxRef: [' + ajaxRef + ']\\n'\n");
    sb.append("    + 'querystring: [' + qs + ']');\n");
    sb.append("  }\n\n");
    sb.append("  var xReq = createXMLHttpRequest();\n\n");
    sb.append("  callKey = '' + calls.length;\n");
    sb.append("  call = {xmlHttpRequest: xReq,\n");
    sb.append("    callbackFunction: resHandler,\n");
    sb.append("    form: form,\n");
    sb.append("    resHandlerParam: resHandlerParam,\n");
    sb.append("    mungedRef: mungedRef,\n");
    sb.append("    timerObj: timerObj,\n");
    sb.append("    ajaxRef: ajaxRef,\n");
    sb.append("    URL: targetURI + qs};\n");
    sb.append("  calls[callKey] = call;\n\n");
    sb.append("  eval('f = function() { onResponseStateChange(' + " +
      "callKey + '); }');\n");
    sb.append("  xReq.onreadystatechange = f;\n\n");

    sb.append("  var parmInTarget = (target.indexOf('?') > 0);\n");
    sb.append("  if (parmInTarget && qs) {\n");
    sb.append("    qs = qs.replace('?','&');\n");
    sb.append("  }\n");
    sb.append("  if (qs == \"\" && !parmInTarget) {\n");
    sb.append("    qs = \"?\";\n");
    sb.append("  } else {\n");
    sb.append("    qs += \"&\";\n");
    sb.append("  }\n");
    sb.append("  aud = new Date();\n");
    sb.append("  aus = '';\n");
    sb.append("  aus += aud.getMonth() + aud.getDay() + aud.getFullYear();\n");
    sb.append("  aus += aud.getHours() + aud.getMinutes();\n");
    sb.append("  aus += aud.getSeconds() + aud.getMilliseconds();\n");
    sb.append("  qs += \"assureUnique=\" + aus + " +
      "assureUnique++;\n");
    sb.append("  qs += \"&ajaxRef=\" + ajaxRef;\n");
    sb.append("  xReq.open(method, targetURI + qs, async);\n");
    sb.append("  xReq.send(dom);\n");
    sb.append("}\n");

    // onResponseStateChange()
    sb.append("function onResponseStateChange(callKey) {\n");
    sb.append("\n");
    sb.append("  call = calls[callKey];\n");
    sb.append("  xmlHttpRequest = call.xmlHttpRequest;\n");
    sb.append("\n");
    sb.append("  if (xmlHttpRequest.readyState < 4) {\n");
    sb.append("    return;\n");
    sb.append("  }\n");
    sb.append("\n");
    sb.append("  if (xmlHttpRequest.status == 200) {\n");
    sb.append("    if (shouldDebugAjax) {\n");
    sb.append("      alert('Call ' + callKey + ' with context [' + " +
      "call.resHandlerParam + ']'\n");
    sb.append("           + ' to ' + call.url + ' has returned.');\n");
    sb.append("    }\n");
    sb.append("    callbackFunction = call.callbackFunction;\n");
    sb.append("    if (!callbackFunction) {\n");
    sb.append("      eval('f = function() { onResponseStateChange(' + " +
      "callKey + '); }'); \n");
    sb.append("      setTimeout(f, 100); \n");
    sb.append("    }\n");
    sb.append("    callbackFunction(xmlHttpRequest, " +
      "call.form, call.resHandlerParam); \n");
    sb.append("if (call.timerObj != null) {\n");
    sb.append("timerObj = setTimeout(call.mungedRef + \"_timedFirer()\", " +
      "eval(\"delay_\" + call.mungedRef));\n");
    sb.append("}\n");
    sb.append("  } else {\n");
    sb.append("    alert(xmlHttpRequest.status);\n");
    sb.append("  }\n");
    sb.append("\n");
    sb.append("  call = null;\n");
    sb.append("  delete calls[callKey];\n");
    sb.append("  pendingResponseCount--;\n");
    sb.append("}\n");
    sb.append("\n");

    // createXMLHttpRequest()
    sb.append("function createXMLHttpRequest() {\n");
    sb.append("  var xmlHttpRequest;\n");
    sb.append("  if (window.XMLHttpRequest) {\n");
    sb.append("    return new XMLHttpRequest();\n");
    sb.append("  } else if (window.ActiveXObject) {\n");
    sb.append("    return new ActiveXObject('Microsoft.XMLHTTP')\n");
    sb.append("  }\n");
    sb.append("}\n");
    sb.append("\n");

    sb.append("</script>\n");

    return sb.toString();

  } // End render()

} // End class
