/*
 * Copyright 2005 Frank W. Zammetti
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package javawebparts.taglib.basicstr;


import java.io.IOException;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.BodyTagSupport;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * This class is a custom tag that trims a string.  This function can work
 * in a number of ways, defined by setting the following attributes:
 * <br><br>
 * type - This is the type of trim to perform.  This can be one of the following
 * values: left, right or both.  'left' trims characters from the start of a
 * string, 'right' trims them from the end and 'both' trims from the start
 * as well as the end.  Required: Yes.
 * <br>
 * chars - If specified, the characters listed will be trimmed, and only
 * them.  Note that these characters get inserted into a regular expressino,
 * so if you need to trim characters that have special meaning to a regex, you
 * will have to manually escape them properly.  Required: No (when this
 * attribute is not present, the default function of trimming only whitespace
 * will be used).
 *
 * @author <a href="mailto:fzammetti@omnytex.com">Frank W. Zammetti</a>.
 */
public class TrimTag extends BodyTagSupport {


  /**
   * This static initializer block tries to load all the classes this one
   * depends on (those not from standard Java anyway) and prints an error
   * meesage if any cannot be loaded for any reason.
   */
  static {
    try {
      Class.forName("javax.servlet.jsp.JspException");
      Class.forName("javax.servlet.jsp.JspWriter");
      Class.forName("javax.servlet.jsp.PageContext");
      Class.forName("javax.servlet.jsp.tagext.BodyTagSupport");
      Class.forName("org.apache.commons.logging.Log");
      Class.forName("org.apache.commons.logging.LogFactory");
    } catch (ClassNotFoundException e) {
      System.err.println("TrimTag" +
        " could not be loaded by classloader because classes it depends" +
        " on could not be found in the classpath...");
      e.printStackTrace();
    }
  }


  /**
   * Log instance.
   */
  private static Log log = LogFactory.getLog(TrimTag.class);


  /**
   * Page Context of the tag.
   */
  private PageContext pageContext;


  /**
   * This is the body content text to be altered.
   */
  private String text = "";


  /**
   * This is the trim type attribute.  Valid values are left, right, both.
   */
  private String type = "";


  /**
   * This is the list of characters to trim when other than whitespace.
   */
  private String chars;


  /**
   * type mutator.
   *
   * @param inType Trim type.
   */
  public void setType(String inType) {

    type = inType;

  } // End setType().


  /**
   * chars mutator.
   *
   * @param inChars Chars to trim if other than whitespace.
   */
  public void setChars(String inChars) {

    chars = inChars;

  } // End setChars().


  /**
   * Set the Page Context of the tag.
   *
   * @param inPageContext Page context.
   */
  public void setPageContext(PageContext inPageContext) {

    pageContext = inPageContext;

  } // End setPageContext().


  /**
   * Alter the body content.
   *
   * @return              Return code.
   * @throws JspException If anything goes wrong.
   */
  public int doAfterBody() throws JspException {

    String bcs = bodyContent.getString();
    if (bcs == null) {
      bcs = "";
    }
    // Perform the appriproate trim when whitespace is being trimmed.
    if (type.equalsIgnoreCase("left") && chars == null) {
      text = bcs.replaceAll("^\\s+", "");
    }
    if (type.equalsIgnoreCase("right") && chars == null) {
      text = bcs.replaceAll("\\s+$", "");
    }
    if (type.equalsIgnoreCase("both") && chars == null) {
      text = bcs.trim();
    }
    // Perform the appriproate trim when arbitrary characters are being trimmed.
    if (type.equalsIgnoreCase("left") && chars != null) {
      text = bcs.replaceAll("^[" + chars + "]+", "");
    }
    if (type.equalsIgnoreCase("right") && chars != null) {
      text = bcs.replaceAll("[" + chars + "]+$", "");
    }
    if (type.equalsIgnoreCase("both") && chars != null) {
      text = bcs.replaceAll("^[" + chars + "]+", "");
      text = bcs.replaceAll("[" + chars + "]+$", "");
    }
    return SKIP_BODY;

  } // End doAfterBody().


  /**
   * Render the altered body.
   *
   * @return              Return code.
   * @throws JspException If anything goes wrong.
   */
  public int doEndTag() throws JspException {

    try {
      JspWriter out = pageContext.getOut();
      out.print(text);
    } catch (IOException ioe) {
      throw new JspException(ioe.toString());
    }
    return EVAL_PAGE;

  } // doEndTag().


} // End class.
