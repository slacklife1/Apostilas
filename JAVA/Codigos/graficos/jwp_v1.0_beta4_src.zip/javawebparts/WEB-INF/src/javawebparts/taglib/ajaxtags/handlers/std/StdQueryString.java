/*
 * Copyright 2005 Frank W. Zammetti
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package javawebparts.taglib.ajaxtags.handlers.std;


import javawebparts.taglib.ajaxtags.handlers.HandlerRendererBase;


/**
 * This class renders the Javascript for the std:QueryString request handler.
 * <br><br>
 * The QueryString request handler constructs a query string and sends it to
 * the specified target.  It is good any time you need to make a request to a
 * server resource.  Note that you can do a GET or POST with this handler,
 * based on the setting of the method attribute.
 * <br><br>
 * Parameter: A comma-separated list of name-value pairs.  The name is the
 * parameter that will be submitted, the value is the form element to get the
 * value from.
 * <br><br>
 * Example configuration:
 * <br><br>
 * &lt;requestHandler type="std:QueryString" method="get"&gt;<br>
 * &nbsp;&nbsp;&lt;target&gt;ajaxSelectTest&lt;/target&gt;<br>
 * &nbsp;&nbsp;lt;parameter&gt;keyParm=selbox1,<br>
 * someOtherParamName=textBox1&lt;/parameter&gt;<br>
 * &lt;/requestHandler&gt;<br>
 *
 * @author <a href="mailto:fzammetti@omnytex.com">Frank W. Zammetti</a>
 */
public class StdQueryString implements HandlerRendererBase {


  /**
   * This static initializer block tries to load all the classes this one
   * depends on (those not from standard Java anyway) and prints an error
   * meesage if any cannot be loaded for any reason.
   */
  static {
    try {
      Class.forName(
        "javawebparts.taglib.ajaxtags.handlers.HandlerRendererBase");
    } catch (ClassNotFoundException e) {
      System.err.println("StdQueryString" +
        " could not be loaded by classloader because classes it depends" +
        " on could not be found in the classpath...");
      e.printStackTrace();
    }
  }


  /**
   * Render the Javascript for this handler.
   *
   * @return The Javascript contents to insert into the page
   */
  public String render() {

    StringBuffer sb = new StringBuffer(2048);

    sb.append("function StdQueryString(form, target, param, resHandler, " +
      "resHandlerParam, method, mungedRef, timerObj, ajaxRef) {\n");
    sb.append("  qs = '';\n");
    sb.append("  nvp = param.split(',');\n");
    sb.append("  i = 0;\n");
    sb.append("  while (i < nvp.length) {\n");
    sb.append("    if (qs == '')  { qs += '?'; }\n");
    sb.append("    if (qs != '?') { qs += '&'; }\n");
    sb.append("    nav = nvp[i].split('=');\n");
    sb.append("    if (nav[1].charAt(0) == '\\'') {\n");
    sb.append("      fe = nav[1].substring(1, nav[1].length - 1);\n");
    sb.append("    } else {\n");
    sb.append("      fe = eval('document.' + form.name + '[\"' + " +
      "nav[1] + '\"]');\n");
    sb.append("      fe = fe.value;\n");
    sb.append("    }\n");
    sb.append("    qs += nav[0] + '=' + escape(fe);\n");
    sb.append("    i++;\n");
    sb.append("  }\n");
    sb.append("  ajaxRequestSender(form, target, qs, null, resHandler, " +
      "resHandlerParam, method, true, mungedRef, timerObj, ajaxRef" +
      ");\n");
    sb.append("}\n");

    return sb.toString();

  } // End render()

} // End class
