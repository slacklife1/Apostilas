/*
 * Copyright 2005 Frank W. Zammetti
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package javawebparts.taglib.ajaxtags;


import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import javawebparts.taglib.ajaxtags.config.AjaxHandler;
import javax.servlet.http.HttpServletRequest;
import javawebparts.taglib.ajaxtags.handlers.HandlerRendererBase;
import javawebparts.taglib.ajaxtags.handlers.RequestSender;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.TagSupport;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * This class is a custom tag (AjaxEnableTag) that must be placed on a page
 * AFTER all other Ajax-enabled tags.  Its job is to render Javascript or
 * external reference links for all the handlers required on the page.
 * Each Ajax-enabled tag that fires will add its request and response handlers
 * in PageContext.  They will add to an attribute named AjaxHandlersUsed of type
 * HashSet.  In this class we iterate over that collection and for each standard
 * handler we have it's renderer render it's code, or we render a link to the
 * external .js file for custom handlers, if their location is not local.
 *
 * @author <a href="mailto:fzammetti@omnytex.com">Frank W. Zammetti</a>
 */
public class AjaxEnableTag extends TagSupport {


  /**
   * This static initializer block tries to load all the classes this one
   * depends on (those not from standard Java anyway) and prints an error
   * meesage if any cannot be loaded for any reason.
   */
  static {
    try {
      Class.forName("javawebparts.taglib.ajaxtags.config.AjaxHandler");
      Class.forName(
        "javawebparts.taglib.ajaxtags.handlers.HandlerRendererBase");
      Class.forName("javawebparts.taglib.ajaxtags.handlers.RequestSender");
      Class.forName("javax.servlet.jsp.JspException");
      Class.forName("javax.servlet.jsp.JspWriter");
      Class.forName("javax.servlet.jsp.PageContext");
      Class.forName("javax.servlet.jsp.tagext.TagSupport");
      Class.forName("org.apache.commons.logging.Log");
      Class.forName("org.apache.commons.logging.LogFactory");
    } catch (ClassNotFoundException e) {
      System.err.println("AjaxEnableTag" +
        " could not be loaded by classloader because classes it depends" +
        " on could not be found in the classpath...");
      e.printStackTrace();
    }
  }


  /**
   * Log instance.
   */
  private static Log log = LogFactory.getLog(AjaxEnableTag.class);


  /**
   * Page Context of the tag.
   */
  private PageContext pageContext;

  /**
   * Debug flag, should the Ajax calls be debugged or not
   */
  private boolean debug;


  /**
   * Set the Page Context of the tag.
   *
   * @param inPageContext Page Context of the tag
   */
  public void setPageContext(PageContext inPageContext) {

    pageContext = inPageContext;

  } // End setPageContext()


  /**
   * Set the debugFlag of the tag.
   *
   * @param inDebugFlag debugFlag of the tag
   */
  public void setDebug(boolean inDebugFlag) {

    debug = inDebugFlag;

  } // End setDebug()


  /**
   * Render the results of the tag.
   *
   * @return              Return code.
   * @throws JspException If anything goes wrong
   */
  public int doStartTag() throws JspException {

    log.info("AjaxEnableTag.doStartTag()...");

    try {

      JspWriter out = pageContext.getOut();

      // Get the list of all std handlers used on the page before this tag
      // was hit.  Each Ajax-enabled tag puts an entry in this set if it
      // references a std handler.
      HashSet stdHandlersUsed = (HashSet)
        pageContext.getAttribute("AjaxHandlersUsed",
        PageContext.REQUEST_SCOPE);

      StringBuffer jsCode = new StringBuffer(2048);
      // We always want the global variables and requestSender present, so
      // that even if we're only using custom handlers, they can make use of
      // this.  There's no way that I can see to determine if a handler
      // actually needs this or not, so we'll just add it regardless.
      // We also need to determine the contextPath of the request and set it
      // on the RequestSender class before we call render() because this
      // will be prepended to all URLs called.
      // Also the debugFlag (from the tag) for the Ajax calls will be set on
      // the RequestSender class.
      String contextPath =
        ((HttpServletRequest)pageContext.getRequest()).getContextPath();
      RequestSender rs = new RequestSender();
      rs.setContextPath(contextPath);
      rs.setDebug(debug);
      jsCode.append(rs.render());

      // If the element was null, it means either (a) there were no
      // Ajax-enabled tags on the page before this tag was encountered, or
      // (b) only custom handlers were used throughout.  So, we only want
      // to do something here if it was NOT null.
      if (stdHandlersUsed != null) {

        // Cycle through the list of handlers...
        for (Iterator it = stdHandlersUsed.iterator(); it.hasNext();) {

          // Now we instantiate the appropriate renderer class for the handler
          // we are rendering and ask it to render the needed Javascript.
          AjaxHandler handler     = (AjaxHandler)it.next();
          String      location    = handler.getLocation();
          String      handlerName = handler.getFunction();

          // If it's a standard handler, call the appropriate renderer
          if (handler.isSTD()) {

            Class cRenderer = Class.forName(
              "javawebparts.taglib.ajaxtags.handlers.std." +
              handlerName);
            HandlerRendererBase renderer =
              (HandlerRendererBase)cRenderer.newInstance();
            jsCode.append("<script>\n" + renderer.render() + "</script>\n\n");

          // It's a custom handler...
          } else {

            // Insert a script link if it's an external function
            if (!location.toLowerCase().equalsIgnoreCase("local")) {
              jsCode.append("<script src='" + location + "'></script>\n\n");
            }
          }

        }

        out.print(jsCode);

      } // End if (stdHandlersUsed != null)

      return SKIP_BODY;

    } catch (ClassNotFoundException cnfe) {
      throw new JspException(cnfe.toString());
    } catch (InstantiationException ie) {
      throw new JspException(ie.toString());
    } catch (IOException ioe) {
      throw new JspException(ioe.toString());
    } catch (IllegalAccessException iae) {
      throw new JspException(iae.toString());
    }

  } //  End doStartTag()


} // End class
