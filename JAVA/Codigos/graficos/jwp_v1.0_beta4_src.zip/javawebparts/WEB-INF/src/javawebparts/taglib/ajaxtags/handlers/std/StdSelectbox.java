/*
 * Copyright 2005 Herman van Rosmalen
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package javawebparts.taglib.ajaxtags.handlers.std;


import javawebparts.taglib.ajaxtags.handlers.HandlerRendererBase;


/**
 * This class renders the Javascript for the std:Selectbox response handler.
 *
 * @author <a href="mailto:herros@gmail.com">Herman van Rosmalen</a>
 */
public class StdSelectbox implements HandlerRendererBase {


  /**
   * This static initializer block tries to load all the classes this one
   * depends on (those not from standard Java anyway) and prints an error
   * meesage if any cannot be loaded for any reason.
   */
  static {
    try {
      Class.forName(
        "javawebparts.taglib.ajaxtags.handlers.HandlerRendererBase");
    } catch (ClassNotFoundException e) {
      System.err.println("StdSelectbox" +
        " could not be loaded by classloader because classes it depends" +
        " on could not be found in the classpath...");
      e.printStackTrace();
    }
  }


  /**
   * Render the Javascript for this handler.
   *
   * @return The Javascript contents to insert into the page
   */
  public String render() {

    StringBuffer sb = new StringBuffer();

    sb.append("function StdSelectbox(ajaxXHR, ajaxFRM, ajaxRHP) {\n");
    sb.append("   var list = ajaxXHR.responseXML.getElementsByTagName" +
      "('list').item(0); \n");
    sb.append("   targetNames = ajaxRHP.split(','); \n");
    sb.append("   for (var k=targetNames.length-1; k>=0; k--) {\n");
    sb.append("     var targetName = targetNames[k]; \n");
    sb.append("     var targetFields = " +
      "document.getElementsByName(targetName); \n");
    sb.append("     for (var j=0; j < targetFields.length; j++) { \n");
    sb.append("       var targetField = targetFields[j]; \n");
    sb.append("       targetField.options.length = 0; \n");
    sb.append("       if (list != null) {\n");
    sb.append("        targetField.disabled = false; \n");
    sb.append("        var items = list.childNodes; \n");
    sb.append("        for (var i=0; i < items.length; i++) { \n");
    sb.append("         targetField.options[i] = new Option(items[i]." +
      "firstChild.nodeValue, items[i].getAttribute(\"value\")); \n");
    sb.append("        } \n");
    sb.append("       } \n");
    sb.append("     } \n");
    sb.append("     try { \n");
    sb.append("      targetFields[0].focus(); \n");
    sb.append("     } catch(error) {} \n");
    sb.append("   }\n");
    sb.append("}\n");

    
    return sb.toString();

  } // End render()


} // End class
