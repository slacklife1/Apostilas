/*
 * Copyright 2005 Frank W. Zammetti
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package javawebparts.taglib.ajaxtags.config;


import java.lang.reflect.Field;


/**
 * This class holds configuration information on each event for an Ajax-enabled
 * element that has been defined as implementing Ajax functionality.
 *
 * @author <a href="mailto:fzammetti@omnytex.com">Frank W. Zammetti</a>
 */
public class AjaxEvent {


  /**
   * The type of an event.
   */
  private String type = "";


  /**
   * The request handler defined for an event.
   */
  private AjaxEventHandler requestHandler;


  /**
   * The response handler defined for an event.
   */
  private AjaxEventHandler responseHandler;


  /**
   * The form this event operates on, if any.
   */
  private String form;


  /**
   * Flag: Is the configuration frozen?
   */
  private boolean frozen;


  /**
   * Sets the form this event operates on.
   *
   * @param inForm The form this event operates on.
   */
  public void setForm(String inForm) {

    if (!frozen) {
      form = inForm;
    }

  } // End setForm().


  /**
   * Returns the form this event operates on.
   *
   * @return The form this event operates on.
   */
  public String getForm() {

    return form;

  } // End getForm().


  /**
   * Sets the type of the event.
   *
   * @param inType The type of the event
   */
  public void setType(String inType) {

    if (!frozen) {
      type = inType;
    }

  } // End setType()


  /**
   * Returns the type of the event.
   *
   * @return The type of the event
   */
  public String getType() {

    return type;

  } // End getType()


  /**
   * Sets the AjaxEventHandler instance that will serve as the request handler
   * for this event.
   *
   * @param inRequestHandler AjaxEventHandler instance
   */
  public void setRequestHandler(AjaxEventHandler inRequestHandler) {

    if (!frozen) {
      inRequestHandler.freeze();
      requestHandler = inRequestHandler;
    }

  } // End setRequestHandler()


  /**
   * Returns the AjaxEventHandler instance that serves as the request handler
   * for this event.
   *
   * @return AjaxEventHandler instance
   */
  public AjaxEventHandler getRequestHandler() {

    return requestHandler;

  } // End AjaxEventHandler()


  /**
   * Sets the AjaxEventHandler instance that will serve as the response handler
   * for this event.
   *
   * @param inResponseHandler AjaxEventHandler instance
   */
  public void setResponseHandler(AjaxEventHandler inResponseHandler) {

    if (!frozen) {
      inResponseHandler.freeze();
      responseHandler = inResponseHandler;
    }

  } // End setResponseHandler()


  /**
   * Returns the AjaxEventHandler instance that serves as the response handler
   * for this event.
   *
   * @return AjaxEventHandler instance
   */
  public AjaxEventHandler getResponseHandler() {

    return responseHandler;

  } // End getResponseHandler()


  /**
   * Freezes the configuration of this object.
   */
  public void freeze() {

    frozen = true;

  } // End freeze()


  /**
   * Returns true if this onject's config is frozen, false otherwise.
   *
   * @return True if frozen, false if not.
   */
  public boolean isFrozen() {

    return frozen;

  } // End isFrozen()


  /**
   * Overriden toString method.
   *
   * @return A reflexively-built string representation of this bean
   */
  public String toString() {

    String str = null;
    StringBuffer sb = new StringBuffer(1000);
    sb.append("[" + super.toString() + "]={");
    boolean firstPropertyDisplayed = false;
    try {
      Field[] fields = this.getClass().getDeclaredFields();
      for (int i = 0; i < fields.length; i++) {
        if (firstPropertyDisplayed) {
          sb.append(", ");
        } else {
          firstPropertyDisplayed = true;
        }
        sb.append(fields[i].getName() + "=" + fields[i].get(this));
      }
      sb.append("}");
      str = sb.toString().trim();
    } catch (IllegalAccessException iae) { iae.printStackTrace(); }
    return str;

  } // End toString()


} // End class