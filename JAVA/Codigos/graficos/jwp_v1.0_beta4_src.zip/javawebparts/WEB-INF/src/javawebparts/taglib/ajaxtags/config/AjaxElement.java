/*
 * Copyright 2005 Frank W. Zammetti
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package javawebparts.taglib.ajaxtags.config;


import java.lang.reflect.Field;
import java.util.HashMap;


/**
 * This class holds configuration information on each element of a form
 * that has been Ajax-enabled.
 *
 * @author <a href="mailto:fzammetti@omnytex.com">Frank W. Zammetti</a>
 */
public class AjaxElement {


  /**
   * Ajax reference ID.
   */
  private String ajaxRef = "";


  /**
   * The collection of events defined for an element.
   */
  private HashMap events = new HashMap();


  /**
   * Flag: Is the configuration frozen?
   */
  private boolean frozen;


  /**
   * Sets the ajaxRef for the element.
   *
   * @param inAjaxRef The ajaxRef top assign to this element
   */
  public void setAjaxRef(String inAjaxRef) {

    if (!frozen) {
      ajaxRef = inAjaxRef;
    }

  } // End setAjaxRef()


  /**
   * Returns the ajaxRef for the element.
   *
   * @return The ajaxRef for the element
   */
  public String getAjaxRef() {

    return ajaxRef;

  } // End getAjaxRef()


  /**
   * Adds an AjaxEvent instance to the collection for the element.
   *
   * @param event The AjaxEvenet instance to add
   */
  public void addEvent(AjaxEvent event) {

    if (!frozen) {
      event.freeze();
      events.put(event.getType(), event);
    }

  } // End addEvent()


  /**
   * Returns the AjaxEvent instance for the named UI event.
   *
   * @param  type The event type.
   * @return      The AjaxEvent for the names UI event
   */
  public AjaxEvent getEvent(String type) {

    return (AjaxEvent)events.get(type);

  } // End getEvent()


  /**
   * Returns the collection of AjaxEvent instances for this element.
   *
   * @return The collection of AjaxEvent instances for this element.
   */
  public HashMap getEvents() {

    return events;

  } // End getEvents()


  /**
   * Freezes the configuration of this object.
   */
  public void freeze() {

    frozen = true;

  } // End freeze()


  /**
   * Returns true if this onject's config is frozen, false otherwise.
   *
   * @return True if frozen, false if not.
   */
  public boolean isFrozen() {

    return frozen;

  } // End isFrozen()


  /**
   * Overriden toString method.
   *
   * @return A reflexively-built string representation of this bean
   */
  public String toString() {

    String str = null;
    StringBuffer sb = new StringBuffer(1000);
    sb.append("[" + super.toString() + "]={");
    boolean firstPropertyDisplayed = false;
    try {
      Field[] fields = this.getClass().getDeclaredFields();
      for (int i = 0; i < fields.length; i++) {
        if (firstPropertyDisplayed) {
          sb.append(", ");
        } else {
          firstPropertyDisplayed = true;
        }
        sb.append(fields[i].getName() + "=" + fields[i].get(this));
      }
      sb.append("}");
      str = sb.toString().trim();
    } catch (IllegalAccessException iae) { iae.printStackTrace(); }
    return str;

  } // End toString()


} // End class