/*
 * Copyright 2005 Frank W. Zammetti
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package javawebparts.taglib.ajaxtags.handlers.std;


import javawebparts.taglib.ajaxtags.handlers.HandlerRendererBase;


/**
 * This class renders the Javascript for the std:SendByID request handler.
 * <br><br>
 * The SendByID handler allows you to send an AJAX request that contains values
 * taken from arbitrary page element by calls to document.GetElementById().
 * This is nice if you want to send values from an editable &lt;div&gt;
 * for example, or want to have a bunch of form elements that aren't part of
 * a form but are addressable by id attributes.  This handler can send the
 * values as a query string *or* as an XML document.
 * <br><br>
 * Parameter: A comma-separated list.  The first element MUST be the type of
 * request to make, either the value "xml" or "querystring".  If the value is
 * "xml", then this element must also contain the root node name.  In other
 * words, if you want to send XML and you want the root element to be
 * "person", then the first element of this CSV list should be "xml.person".
 * After that, the elements are in the form X.Y, where X is the ID of the
 * element to get the value from, and Y is the property of that element to read.
 * So, you can do "myDiv.innerHTML", or "myDiv.innerText" or
 * "myTextbox.value", or any other accessible property of the element.
 * <br><br>
 * Example configuration:
 * <br><br>
 * &lt;element ajaxRef="Button2"&gt;
 * &nbsp;&nbsp;&lt;event type="onclick" form="TestPage"&gt;
 * &nbsp;&nbsp;&nbsp;&nbsp;&lt;requestHandler type="std:SendByID"
 * method="get"&gt;
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;target&gt;../../sendByIDTest&lt;
 * /target&gt;
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;parameter&gt;xml.person,
 * firstName.innerText,lastName.value&lt;/parameter&gt;
 * &nbsp;&nbsp;&nbsp;&nbsp;&lt;/requestHandler&gt;
 * &nbsp;&nbsp;&nbsp;&nbsp;&lt;responseHandler type="std:CodeExecuter"&gt;
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;parameter /&gt;
 * &nbsp;&nbsp;&nbsp;&nbsp;&lt;/responseHandler&gt;
 * &nbsp;&nbsp;&lt;/event&gt;
 * &lt;/element&gt;
 * <br><br>
 * This is taken directly from the sample app.  It will allow us to attach an
 * onClick AJAX event to element, presumably a button based on the
 * ajaxRef, but not necessarily, that will use this handler to send an XML
 * document containing the elements firstName and lastName, where firstName
 * is populated from the innerText property of the element on the page with
 * the id firstName, and lastNAme is populated from the value property of the
 * element on the page with the id lastName.
 * <br><br>
 * Assuming firstName is a &lt;div&gt; element on the page, and &lt;lastName&gt;
 * is a textbox, and firstName contains the text "Frank" and lastName contains
 * the value "Zammetti", the resultant XML in this case would be:
 * <br><br>
 * &lt;person&gt;
 * &nbsp;&nbsp;&lt;firstName&gt;Frank&lt;/firstName&gt;
 * &nbsp;&nbsp;&lt;lastName&gt;Zammetti&lt;/lastName&gt;
 * &lt;/person&gt;
 *
 * @author <a href="mailto:fzammetti@omnytex.com">Frank W. Zammetti</a>
 */
public class StdSendByID implements HandlerRendererBase {


  /**
   * This static initializer block tries to load all the classes this one
   * depends on (those not from standard Java anyway) and prints an error
   * meesage if any cannot be loaded for any reason.
   */
  static {
    try {
      Class.forName(
        "javawebparts.taglib.ajaxtags.handlers.HandlerRendererBase");
    } catch (ClassNotFoundException e) {
      System.err.println("StdSendByID" +
        " could not be loaded by classloader because classes it depends" +
        " on could not be found in the classpath...");
      e.printStackTrace();
    }
  }


  /**
   * Render the Javascript for this handler.
   *
   * @return The Javascript contents to insert into the page
   */
  public String render() {

    StringBuffer sb = new StringBuffer(2048);

    sb.append("function StdSendByID(form, target, param, resHandler, " +
      "resHandlerParam, method, mungedRef, timerObj, ajaxRef) {\n");
    sb.append("  a = param.split(\",\");\n");
    sb.append("  requestType = a[0];\n");
    sb.append("  if (requestType.toLowerCase().indexOf(\"querystring\") " +
      "!= -1) {\n");
    sb.append("    qs = \"?\";\n");
    sb.append("    for (i = 1; i < a.length; i++) {\n");
    sb.append("      nextElement = a[i];\n");
    sb.append("      b = nextElement.split(\".\");\n");
    sb.append("      id = b[0];\n");
    sb.append("      attr = b[1];\n");
    sb.append("      if (qs != \"?\") {\n");
    sb.append("        qs += \"&\";\n");
    sb.append("      }\n");
    sb.append("      qs += id + \"=\";\n");
    sb.append("      qs += escape(eval(\"document.getElementById('\" + id + " +
      "\"').\" + attr));\n");
    sb.append("    }\n");
    sb.append("    ajaxRequestSender(form, target, qs, null, resHandler, " +
      "resHandlerParam, method, true);\n");
    sb.append("  }\n");
    sb.append("  if (requestType.toLowerCase().indexOf(\"xml\") != -1) {\n");
    sb.append("    b = requestType.split(\".\");\n");
    sb.append("    rootNode = b[1];\n");
    sb.append("    xml = \"<\" + rootNode + \">\";\n");
    sb.append("    for (i = 1; i < a.length; i++) {\n");
    sb.append("      nextElement = a[i];\n");
    sb.append("      b = nextElement.split(\".\");\n");
    sb.append("      id = b[0];\n");
    sb.append("      attr = b[1];\n");
    sb.append("      xml += \"<\" + id + \">\";\n");
    sb.append("      xml += escape(eval(\"document.getElementById('\" + id + " +
      "\"').\" + attr));\n");
    sb.append("      xml += \"</\" + id + \">\";\n");
    sb.append("    }\n");
    sb.append("    xml += \"</\" + rootNode + \">\";\n");
    sb.append("    ajaxRequestSender(form, target, '', xml, resHandler, " +
      "resHandlerParam, method, true, mungedRef, timerObj, ajaxRef);\n");
    sb.append("  }\n");
    sb.append("}\n");

    return sb.toString();

  } // End render()

} // End class
