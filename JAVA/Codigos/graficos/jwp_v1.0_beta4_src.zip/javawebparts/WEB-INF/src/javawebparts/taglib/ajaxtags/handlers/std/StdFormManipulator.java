/*
 * Copyright 2006 Herman van Rosmalen
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package javawebparts.taglib.ajaxtags.handlers.std;


import javawebparts.taglib.ajaxtags.handlers.HandlerRendererBase;


/**
 * This class renders the Javascript for the std:Selectbox response handler.
 *
 * @author <a href="mailto:herros@gmail.com">Herman van Rosmalen</a>
 */
public class StdFormManipulator implements HandlerRendererBase {


  /**
   * This static initializer block tries to load all the classes this one
   * depends on (those not from standard Java anyway) and prints an error
   * meesage if any cannot be loaded for any reason.
   */
  static {
    try {
      Class.forName(
        "javawebparts.taglib.ajaxtags.handlers.HandlerRendererBase");
    } catch (ClassNotFoundException e) {
      System.err.println("StdFormManipulator" +
        " could not be loaded by classloader because classes it depends" +
        " on could not be found in the classpath...");
      e.printStackTrace();
    }
  }


  /**
   * Render the Javascript for this handler.
   *
   * @return The Javascript contents to insert into the page
   */
  public String render() {

    StringBuffer sb = new StringBuffer();

    sb.append("function StdFormManipulator(ajaxXHR, ajaxFRM, ajaxRHP) {\n");
    sb.append("  var formNode = ajaxXHR.responseXML.getElementsByTagName" +
      "('form').item(0); \n");
    sb.append("  if (!(formNode)) { \n");
    sb.append("     alert('Response from server should be XML in format\\n" +
      "<form name=...>\\n <formproperty name=... value=.../>\\n " +
      "<element name=... value=...>\\n  <property name=... value=.../>\\n " +
      "</element>\\n</form>');\n");
    sb.append("     return;\n");
    sb.append("   }\n");
    sb.append("   var form = document.getElementsByName(formNode." +
      "getAttribute('name'))[0];\n");
    sb.append("   if (!(form)) {\n");
    sb.append("     alert('There is no form named ' + " +
      "formNode.getAttribute('name'));\n");
    sb.append("     return;\n");
    sb.append("   }\n");
    sb.append("   var children = formNode.getElementsByTagName(" +
      "'formproperty');\n");
    sb.append("   for (i=0;i<children.length;i++) {\n");
    sb.append("     JWPchangeproperty(form, children[i]);");
    sb.append("   }\n");
    sb.append("   var children = formNode.getElementsByTagName('element');\n");
    sb.append("   for (i=0;i<children.length;i++) {\n");
    sb.append("     JWPchangeelement(form, children[i]);");
    sb.append("   }\n");
    sb.append(" }\n");
    sb.append(" function JWPchangeproperty(target, node) {\n");
    sb.append("   var propName = node.getAttribute('name');\n");
    sb.append("   var propValue = node.getAttribute('value');\n");
    sb.append("   target[propName] = propValue;\n");
    sb.append(" }\n");
    sb.append(" function JWPchangeelement(target, node) {\n");
    sb.append("   var field = target[node.getAttribute('name')];\n");
    sb.append("   if (!(field)) {\n");
    sb.append("     alert('There is no element named ' + node.getAttribute('" +
      "name'));\n");
    sb.append("     return;\n");
    sb.append("   }\n");
    sb.append("   field.value = node.getAttribute('value');\n");
    sb.append("   var properties = node.getElementsByTagName('property');\n");
    sb.append("   for (var j=0; j<properties.length; j++) {\n");
    sb.append("     var propName = properties[j].getAttribute('name');\n");
    sb.append("     var fieldProp = '';\n");
    sb.append("     var fieldProps = propName.split('.');\n");
    sb.append("     for (var k=0;k<fieldProps.length;k++) {\n");
    sb.append("       fieldProp += '[\"' + fieldProps[k] + '\"]';\n");
    sb.append("     }\n");
    sb.append("     try {\n");
    sb.append("       eval('field' + fieldProp + ' = properties[j]." +
     "getAttribute(\"value\")');\n");
    sb.append("     } catch (error) {alert('Setting field property " +
     "returns error: ' + error.message);}\n");
    sb.append("   }\n");
    sb.append(" }\n");
    return sb.toString();

  } // End render()


} // End class
