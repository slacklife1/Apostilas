/*
 * Copyright 2005 Frank W. Zammetti
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package javawebparts.taglib.ajaxtags.config;


import java.lang.reflect.Field;
import java.util.HashMap;


/**
 * This class holds configuration information on each form that contains
 * Ajax-enabled elements.
 *
 * @author <a href="mailto:fzammetti@omnytex.com">Frank W. Zammetti</a>
 */
public class AjaxForm {


  /**
   * Ajax reference ID.
   */
  private String ajaxRef = "";


  /**
   * Does this form represent the entire page, for elements outside any forms?.
   */
  private String isPage = "false";


  /**
   * Form this event will operate on.
   */
  private String form;


  /**
   * Elements defined for this form.
   */
  private HashMap elements = new HashMap();


  /**
   * Flag: Is the configuration frozen?
   */
  private boolean frozen;


  /**
   * isPage setter.
   *
   * @param inIsPage isPage.
   */
  public void setIsPage(String inIsPage) {

    if (!frozen) {
      isPage = inIsPage;
    }

  } // End setIsPage().


  /**
   * isPage getter.
   *
   * @return isPage.
   */
  public String getIsPage() {

    return isPage;

  } // End getIsPage().


  /**
   * ajaxRef setter.
   *
   * @param inAjaxRef ajaxRef.
   */
  public void setAjaxRef(String inAjaxRef) {

    if (!frozen) {
      ajaxRef = inAjaxRef;
    }

  } // End setAjaxRef().


  /**
   * ajaxRef getter.
   *
   * @return The ajaxRef.
   */
  public String getAjaxRef() {

    return ajaxRef;

  } // End getAjaxRef().


  /**
   * Puts an element in the collection.
   *
   * @param element The element to put in the collection.
   */
  public void addElement(AjaxElement element) {

    if (!frozen) {
      element.freeze();
      elements.put(element.getAjaxRef(), element);
    }

  } // End addElement().


  /**
   * Gets an element from the collection.
   *
   * @param  inAjaxRef The ajaxRef of the element to retrieve.
   * @return           The corresponding AjaxElement.
   */
  public AjaxElement getElement(String inAjaxRef) {

    return (AjaxElement)elements.get(inAjaxRef);

  } // End getElement().


  /**
   * Freezes the configuration of this object.
   */
  public void freeze() {

    frozen = true;

  } // End freeze().


  /**
   * Returns true if this onject's config is frozen, false otherwise.
   *
   * @return True if frozen, false if not.
   */
  public boolean isFrozen() {

    return frozen;

  } // End isFrozen().


  /**
   * Overriden toString method.
   *
   * @return A reflexively-built string representation of this bean
   */
  public String toString() {

    String str = null;
    StringBuffer sb = new StringBuffer(1000);
    sb.append("[" + super.toString() + "]={");
    boolean firstPropertyDisplayed = false;
    try {
      Field[] fields = this.getClass().getDeclaredFields();
      for (int i = 0; i < fields.length; i++) {
        if (firstPropertyDisplayed) {
          sb.append(", ");
        } else {
          firstPropertyDisplayed = true;
        }
        sb.append(fields[i].getName() + "=" + fields[i].get(this));
      }
      sb.append("}");
      str = sb.toString().trim();
    } catch (IllegalAccessException iae) { iae.printStackTrace(); }
    return str;

  } // End toString().


} // End class.