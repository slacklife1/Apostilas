/*
 * Copyright 2005 Frank W. Zammetti
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package javawebparts.taglib.ajaxtags;


import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.StringTokenizer;
import javawebparts.taglib.ajaxtags.config.AjaxConfig;
import javawebparts.taglib.ajaxtags.config.AjaxElement;
import javawebparts.taglib.ajaxtags.config.AjaxEvent;
import javawebparts.taglib.ajaxtags.config.AjaxEventHandler;
import javawebparts.taglib.ajaxtags.config.AjaxForm;
import javawebparts.taglib.ajaxtags.config.AjaxHandler;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.TagSupport;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * This class is a custom tag (AjaxEventTag) that emits the small script
 * element following a form element to be Ajax-enabled.  This script it emits
 * will set the appropriate event handler on the element.
 *
 * @author <a href="mailto:fzammetti@omnytex.com">Frank W. Zammetti</a>
 */
public class AjaxEventTag extends TagSupport {


  /**
   * This static initializer block tries to load all the classes this one
   * depends on (those not from standard Java anyway) and prints an error
   * meesage if any cannot be loaded for any reason.
   */
  static {
    try {
      Class.forName("javawebparts.taglib.ajaxtags.config.AjaxConfig");
      Class.forName("javawebparts.taglib.ajaxtags.config.AjaxElement");
      Class.forName("javawebparts.taglib.ajaxtags.config.AjaxEvent");
      Class.forName("javawebparts.taglib.ajaxtags.config.AjaxEventHandler");
      Class.forName("javawebparts.taglib.ajaxtags.config.AjaxForm");
      Class.forName("javawebparts.taglib.ajaxtags.config.AjaxHandler");
      Class.forName("javax.servlet.jsp.JspException");
      Class.forName("javax.servlet.jsp.JspWriter");
      Class.forName("javax.servlet.jsp.PageContext");
      Class.forName("javax.servlet.jsp.tagext.TagSupport");
      Class.forName("org.apache.commons.logging.Log");
      Class.forName("org.apache.commons.logging.LogFactory");
    } catch (ClassNotFoundException e) {
      System.err.println("AjaxEventTag" +
        " could not be loaded by classloader because classes it depends" +
        " on could not be found in the classpath...");
      e.printStackTrace();
    }
  }


  /**
   * Log instance.
   */
  private static Log log = LogFactory.getLog(AjaxEventTag.class);


  /**
   * Page Context of the tag.
   */
  private PageContext pageContext;


  /**
   * The Ajax reference ID.
   */
  private String ajaxRef;


  /**
   * Set the Page Context of the tag.
   *
   * @param inPageContext Page Context of the tag
   */
  public void setPageContext(PageContext inPageContext) {

    pageContext = inPageContext;

  } // End setPageContext()


  /**
   * Sets the Ajax reference ID.
   *
   * @param inAjaxRef ajaxRef.
   */
  public void setAjaxRef(String inAjaxRef) {

    ajaxRef = inAjaxRef;

  } // End setAjaxRef().


  /**
   * Returns the Ajax reference ID.
   *
   * @return ajaxRef.
   */
  public String getAjaxRef() {

    return ajaxRef;

  } // End getAjaxRef().


  /**
   * Render the results of the tag.
   *
   * @return              Return code.
   * @throws JspException If anything goes wrong
   */
  public int doStartTag() throws JspException {

    log.info("Processing AjaxEnableTag tag " + ajaxRef + "...");

    // Parse the ajaxRef into the form and element parts
    StringTokenizer st = new StringTokenizer(ajaxRef, "/");
    String formRef     = st.nextToken();
    String elementRef  = st.nextToken();
    log.info("ajaxRef of parent form = " + formRef);
    log.info("ajaxRef of element = " + elementRef);

    // Look up form in config...
    AjaxForm aForm = (AjaxForm)AjaxConfig.getForm(formRef);
    if (aForm == null) {
      log.info("Couldn't find form ajaxRef = " + formRef);
      return SKIP_BODY;
    }
    String isPage = aForm.getIsPage();
    log.debug("aForm = " + aForm);

    // Look up element in config...
    AjaxElement aElement = (AjaxElement)aForm.getElement(elementRef);
    if (aElement == null) {
      log.info("Couldn't find element ajaxRef = " + elementRef);
      return SKIP_BODY;
    }
    log.debug("aElement = " + aElement);

    // Begin the output code.
    String mungedRef = "jwpatp_" + ajaxRef.replace('/', '_');
    StringBuffer sCode = new StringBuffer(1024);
    sCode.append("<jwpatp id=\"jwpatp_" + ajaxRef + "\"/>");
    sCode.append("<script>");
    sCode.append("o_" + mungedRef + "=document.getElementById(\"jwpatp_" +
      ajaxRef + "\");");
    sCode.append("while((o_" + mungedRef + "=o_" + mungedRef +
      ".previousSibling).nodeType!=1){} ");

    // Iterate over the collection of events configured for this element
    // and emit the appropriate code.
    HashMap events = aElement.getEvents();
    for (Iterator it = events.keySet().iterator(); it.hasNext();) {

      AjaxEvent aEvent = (AjaxEvent)events.get(it.next());
      String eventType = aEvent.getType();

      // Look up event in config...
      if (aEvent == null) {
        log.info("Event " + eventType + " not configured to be handled");
        return SKIP_BODY;
      }
      String htmlForm = aEvent.getForm();
      log.debug("aEvent = " + aEvent);

      // See if there is already a collection in request scope of the
      // pageContext for the handlers used on the page.  If so, get it,
      // if not, get a new blank one.
      HashSet handlersUsed = (HashSet)pageContext.getAttribute(
        "AjaxHandlersUsed", PageContext.REQUEST_SCOPE);
      if (handlersUsed == null) {
        handlersUsed = new HashSet();
      }

      // Get the request handler and the function to call.
      AjaxEventHandler aReqEventHandler = aEvent.getRequestHandler();
      String      aReqType    = aReqEventHandler.getType();
      String      aReqMethod  = aReqEventHandler.getMethod();
      AjaxHandler aReqHandler = (AjaxHandler)AjaxConfig.getHandler(aReqType);
      if (aReqHandler == null) {
        log.error("Unknown handler type : " + aReqType);
      }
      String reqFuncName = aReqHandler.getFunction();
      handlersUsed.add(aReqHandler);
      log.info("Request handler function name = " + reqFuncName);

      // Get the response handler and the function to call.
      AjaxEventHandler aResEventHandler = aEvent.getResponseHandler();
      String      aResType    = aResEventHandler.getType();
      AjaxHandler aResHandler = (AjaxHandler)AjaxConfig.getHandler(aResType);
      if (aResHandler == null) {
        log.error("Unknown handler type : " + aResType);
      }
      String resFuncName = aResHandler.getFunction();
      handlersUsed.add(aResHandler);
      log.info("Response handler function name = " + resFuncName);

      // Put the collection of handlers used in pageContext
      pageContext.setAttribute("AjaxHandlersUsed", handlersUsed,
        PageContext.REQUEST_SCOPE);

      // Now build the event handler anonymous function code.
      sCode.append("function " + mungedRef + "_f_" + eventType + "(){");
      sCode.append(reqFuncName + "(");
      if (htmlForm != null) {
        sCode.append("document.forms[\"" + htmlForm + "\"],");
      }
      if (htmlForm == null && isPage.equalsIgnoreCase("false")) {
        sCode.append("o_" + mungedRef + ".form,");
      }
      if (htmlForm == null && isPage.equalsIgnoreCase("true")) {
        log.info("Misconfiguration: when isPage is true, form attribute of " +
          "event element must be defined");
        return SKIP_BODY;
      }
      sCode.append("\"" + aReqEventHandler.getTarget() + "\",");
      sCode.append("\"" + jsSafeString(aReqEventHandler.getParameter()) +
        "\",");
      sCode.append(resFuncName + ",");
      sCode.append("\"" + jsSafeString(aResEventHandler.getParameter()) +
        "\", \"" + aReqMethod + "\", null, null, \"" + ajaxRef + "\")");
      sCode.append(";}");

      // If there is aready an event handler append our code to it!!
      // (if there's going to be an attribute to DO overwrite the handler
      // create the (boolean) attribute, uncomment the if and else pieces
      // .. and change "overwriteTheEventHandler" into the new attribute
      // name....) if (!overwriteTheEventHandler) {
      sCode.append("if (o_" + mungedRef + "." + eventType + "){");
      sCode.append(mungedRef + "_" + eventType + "_old=o_" + mungedRef + "." +
        eventType + ";");
      sCode.append("o_" + mungedRef + "." + eventType + "=function(){");
      sCode.append(mungedRef + "_" + eventType + "_old();");
      sCode.append(mungedRef + "_f_" + eventType + "();};}else{");
      sCode.append("o_" + mungedRef + "." + eventType + "=" + mungedRef +
        "_f_" + eventType + ";}");
      // } else {
      // sCode.append("o_" + mungedRef + "." + eventType + "=" + mungedRef +
      //       "_f_" + eventType + ";");
      // }

    } // End for loop

    // Complete the emitted code.
    sCode.append("</script>");
    log.debug(sCode.toString());

    // Display it for debugging purposes.
    log.debug("Ready to emit: " + sCode);

    // Actually emit the code that has been built up to the page.
    JspWriter out = pageContext.getOut();
    try {
      out.print(sCode);
    } catch (IOException ioe) {
      throw new JspException(ioe.toString());
    }

    return SKIP_BODY;

  } //  End doStartTag()


    /**
     * This method makes a string "safe" for use in JScript.  That means that
     * aspostrophes, quotes and hard linebreaks are replaced with the
     * corresponding escape sequences.  This is important because many strings
     * passed back to the GUI are inserted into JScript string.  If the text
     * that is inserted contains quotes, apostrophes or line breaks, it will
     * almost certainly break the JScript code.  This method should be called on
     * any string going back to the GUI.  This method also trims the string.
     *
     * @param  inString Is the string to make "safe"
     * @return          A string with escape sequences
     */
    public static String jsSafeString(String inString) {

      if (inString != null) {
        // Trivial rejection: If a quick indexOf doesn't find any quotes,
        // apostrophes or carriage return/linefeeds, no need to do the rest
        // of the work
        if (inString.indexOf("'")   == -1 && inString.indexOf("\"") == -1 &&
          inString.indexOf("\r")  == -1 && inString.indexOf("\n") == -1) {
          return inString; // Just return the string as-is in this case
        } else { // Must have found at least one of those characters...
          // If there are carriage return/linefeeds in the output data, convert
          // them to \r\n.
          String workString = inString.trim();
          StringBuffer outString = new StringBuffer(workString.length() * 2);
          // Get byte array based on input string
          byte[] workStringBytes = workString.getBytes();
          // Begin scanning the byte array looking for "unsafe" data to escape
          int i = 0;
          while (i < workStringBytes.length) {
            // Carriage Return + Linefeed...
            if (workStringBytes[i] == '\r' && workStringBytes[i + 1] == '\n') {
              outString.append("\\r\\n"); // Append the correct escape sequence
              i = i + 2; // Move two bytes forward in the source array
            // Apostrophe that isn't already escaped...
            } else if (workStringBytes[i] == '\'' && (i == 0 || (i > 0 &&
              workStringBytes[i-1] != 92))) {
              outString.append("\\'"); // Append the correct escape sequence
              i = i + 1; // Move to the next byte in the source array
            // Quotation Mark that isn't already escaped...
            } else if (workStringBytes[i] == '\"' &&
              (i == 0 || (i > 0 && workStringBytes[i-1] != 92))) {
              outString.append("\\\""); // Append the correct escape sequence
              i = i + 1; // Move to the next byte in the source array
            // Backslash that isn't already escaped...
            } else if (workStringBytes[i] == '\\' &&
              (i == 0 || (i > 0 && workStringBytes[i-1] != 92))) {
              outString.append("\\\\"); // Append the correct escape sequence
              i = i + 1; // Move to the next byte in the source array
            } else { // Any other chaacter
              // Or if it's not carriage return/linefeed, append actual byte...
              outString.append((char)workStringBytes[i]);
              i = i + 1; // Move to the next byte in the source array
            }
          }
          // All done, return the final string
          return outString.toString().trim();
        }
      } else { // inString was NULL
        return "";
      }

    } // End jsSafeString()


} // End class
