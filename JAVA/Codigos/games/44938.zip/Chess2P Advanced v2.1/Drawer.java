//12:47 AM 1/24/2005 u 2:23 AM 1/24/2005 u 11:04 AM 1/24/2005 bs 11:11 AM 1/24/2005 bs 11:28 AM 1/24/2005 bs 11:30 AM 1/24/2005 bs 12:05 PM 1/24/2005 bs 2:59 PM 1/24/2005
//u 11:43 PM 1/24/2005 u 11:44 PM 1/24/2005 bs 1:00 PM 1/25/2005 board color changed 9:57 AM 1/26/2005 shapeOfChessPieceModified 10:19 AM 1/26/2005 u 10:51 AM 1/26/2005
//u 5:53 PM 1/28/2005
//u 8:57 PM 2/12/2006

//Class that draws the board from an ChessInstance object

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
import javax.swing.*;

public class Drawer implements java.io.Serializable
{
   Chess2P c2p;
   Graphics2D g2d;
   public Drawer( Chess2P a, BufferedImage b )
   {
      c2p = a;
      g2d = b.createGraphics();
      g2d.setRenderingHint( RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON );
   }
   public void drawU( ChessInstance ci )
   {
      g2d.setColor( new Color( 128, 0, 255 ) );
      g2d.fillRect( 0, 0, 800, 600 );
      if( ci == null )
      {
         //System.out.println( "Drawer drawU found null argument - returning" );
         return;
      }
      for( int x = 0; x <= 7; x++ )
      {
         for( int y = 0; y <= 7; y++ )
         {
            int x1 = 0, y1 = 360, x2 = 440, y2 = 360;
            int a = x * 45, b = ( y + 1 ) * 45;
            x1 += a;
            y1 -= b;
            x2 += a;
            y2 -= b;
            if( ( ( ( x + y ) % 2 ) == 0 ) )  //black square
            {
               g2d.setColor( new Color( 116, 126, 175 ) );
               g2d.fillRect( x1, y1, 45, 45 );
               g2d.fillRect( x2, y2, 45, 45 );
            }
            else  //white square
            {
               g2d.setColor( new Color( 78, 214, 122 ) );
               g2d.fillRect( x1, y1, 45, 45 );
               g2d.fillRect( x2, y2, 45, 45 );
            }
         }
      }
      for( int x = 0; x <= 7; x++ )
      {
         for( int y = 0; y <= 7; y++ )
         {
            int t = ci.getPieceU( x, y, true );
            int c = ci.getTeamU( x, y, true );
            if( t < 1 || t > 12 )
               continue;
            if( c == C.WHITE )
            {
               g2d.setColor( Color.white );
            }
            else
            {
               g2d.setColor( Color.black );
            }
            int x1 = 0, y1 = 360, x2 = 440, y2 = 360;
            int a1 = x * 45, b1 = ( y + 1) * 45, a2 = ( 7 - x ) * 45, b2 = ( 7 - y + 1) * 45;
            x1 += a1;
            y1 -= b1;
            x2 += a2;
            y2 -= b2;
            GeneralPath gp1 = getGeneralPathU( t );
            GeneralPath gp2 = getGeneralPathU( t );
            AffineTransform at1 = AffineTransform.getTranslateInstance( (double) x1, (double) y1 );
            AffineTransform at2 = AffineTransform.getTranslateInstance( (double) x2, (double) y2 );
            gp1.transform( at1 );
            gp2.transform( at2 );
            g2d.fill( gp1 );
            g2d.fill( gp2 );

         }
      }
      for( int x = 0; x <= 7; x++ )
      {
         for( int y = 0; y <= 3; y++ )
         {
            int t = ci.getPieceU( x, y, false );
            int c = ci.getTeamU( x, y, false );
            if( t < 1 || t > 12 )
               continue;
            if( c == C.WHITE )
            {
               g2d.setColor( Color.white );
            }
            else
            {
               g2d.setColor( Color.black );
            }
            int x1 = 0, y1 = 600;
            int a = x * 45, b = ( y + 1 ) * 45;
            x1 += a;
            y1 -= b;
            GeneralPath gp1 = getGeneralPathU( t );
            AffineTransform at1 = AffineTransform.getTranslateInstance( (double) x1, (double) y1 );
            gp1.transform( at1 );
            g2d.fill( gp1 );
         }
      }

      g2d.setStroke( new BasicStroke( 4.0f ) );
      g2d.setColor( new Color( 157, 79, 183 ) );
      int x1, y1, x2, y2;
      x1 = 0 + 20;
      y1 = 360 - 20;
      x2 = 800 - 20;
      y2 = 0 + 20;

      if( ci.fromX() != -1 && ci.fromY() != -1  && ci.toX() != -1  && ci.toY() != -1   )
      {
         g2d.drawLine( x1 + ( ci.fromX() * 45 ), y1 - ( ci.fromY() * 45 ), x1 + ( ci.toX() * 45 ) + 10 , y1 - ( ci.toY() * 45 )  );
         g2d.drawLine( x2 - ( ci.fromX() * 45 ), y2 + ( ci.fromY() * 45 ), x2 - ( ci.toX() * 45 ) -10 , y2 + ( ci.toY() * 45 )  );
      }
      //c2p.refreshU();
   }
   private GeneralPath getGeneralPathU( int p )
   {
      if( p < 1 || p > 12 )
      {
         return null;
      }
      GeneralPath gp = new GeneralPath();
      if( p == C.WP || p == C.BP )
      {
         int a[] = { 7, 40, 37, 40, 33, 34, 25, 31, 25, 13, 27, 13, 23, 9, 21, 9, 17, 13, 19, 13, 19, 31, 11, 34 };
         constructGeneralPathU( gp, a );
      }
      else if( p == C.WR || p == C.BR )
      {
         int a[] = { 9, 40, 9, 34, 12, 34, 12, 6, 32, 6, 32, 34, 35, 34, 35, 40 };
         constructGeneralPathU( gp, a );
      }
      else if( p == C.WN || p == C.BN )
      {
         int a[] = { 9, 40, 22, 16, 20, 16, 10, 21, 9, 18, 18, 7, 20, 4, 21, 9, 23, 4, 27, 10, 27, 29, 33, 40 };
         constructGeneralPathU( gp, a );
      }
      else if( p == C.WB || p == C.BB )
      {
         int a[] = { 9, 40, 18, 22, 14, 14, 19, 9, 22, 3, 24, 9, 29, 14, 25, 22, 34, 40 };
         constructGeneralPathU( gp, a );
      }
      else if( p == C.WQ || p == C.BQ )
      {
         int a[] = { 14, 40, 30, 40, 30, 34, 26, 34, 26, 14, 28, 14, 28, 6, 24, 6, 24, 4, 20, 4, 20, 6, 16, 6, 16, 14, 18, 14, 18, 34, 14, 34  };
         constructGeneralPathU( gp, a );
      }
      else if( p == C.WK || p == C.BK )
      {
         int a[] = { 13, 40, 13, 34, 16, 34, 16, 10, 19, 10, 19, 7, 17, 7, 17, 5, 19, 5, 19, 2, 21, 2, 21, 5, 23, 5, 23, 7, 21, 7, 21, 10, 25, 10, 25, 34, 28, 34, 28, 40 };
         constructGeneralPathU( gp, a );
      }
      return gp;
   }
   private void constructGeneralPathU( GeneralPath gp, int [] a )
   {
      gp.moveTo( a[ 0 ], a[ 1 ] );
      for( int i = 2; i < a.length; i += 2 )
      {
         gp.lineTo( a[ i ], a[ i + 1 ] );
      }
      gp.closePath();
   }
   public void d( String msg )   //for debugging
   {
     System.out.println( msg );
   }
}