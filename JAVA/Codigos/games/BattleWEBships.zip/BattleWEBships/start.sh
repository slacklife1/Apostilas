#!/bin/bash
#
# this is the BattleWEBships start script for Linux/Unix/Mac OS-X
#
# if your java binaries are in the search path (PATH variable)
# otherwise, uncomment and modify the following line:
#
# export JAVA_HOME="/usr/local/java/bin/"
#
if [[ a$JAVA_HOME == 'a' ]] ;
	then JAVA_CMD="java"
		 echo "using default java binaries in path"
	else JAVA_CMD="$JAVA_HOME/java"
		 echo "using java binaries in $JAVA_HOME"
fi
$JAVA_CMD -classpath ./WEB-INF/lib/webbase.jar:./WEB-INF/classes game.Battleships
echo "Java error:"
echo " + You need Java to run BattleWEBships."
echo " + It seems you do not have installed a Java JRE (Java runtime environment)"
echo " + or Java SDK (Java software development kit) on your computer."
echo " + Please download any version (1.3 or higher) from the Sun website."
echo " + You may set the JAVA_HOME export in this start.sh file"
echo " + if Java is not in your computer's search PATH"
