#!/bin/sh
echo "compiling the BattleWEBships project"
javac -v -d WEB-INF/classes -sourcepath source -classpath WEB-INF/classes:WEB-INF/lib/webbase.jar source/game/*java
echo "done."
