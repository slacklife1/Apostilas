/*
 * BattleshipsServlet.java
 *
 * Created on 23. November 2004, 11:04
 */

package servlet;

/**
 *  this is the servlet-version of the Battleships application
 *
 *  the main point is to include the servlet interface definition; the neccessary methods
 *  are implemented in the webbase framework (NApplication) already.
 */
public class BattleshipsServlet extends game.Battleships implements javax.servlet.Servlet {
    // that's all!
}
