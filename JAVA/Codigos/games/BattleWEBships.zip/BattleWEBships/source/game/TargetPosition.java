/*
 * TargetPosition.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 11. November 2004, 13:20
 */

package game;

/**
 *  a simple (x,y) position object
 */
public class TargetPosition {
    
    public TargetPosition( int x, int y ) {
        xpos = x;
        ypos = y;
    }
    
    public int getX() { return xpos; }
    public int getY() { return ypos; }
    
    int xpos, ypos;
}
