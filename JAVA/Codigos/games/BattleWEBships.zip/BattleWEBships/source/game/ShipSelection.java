/*
 * ShipSelection.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 11. November 2004, 16:44
 */

package game;

import com.nex.webbase.*;

/**
 *  this is the menu to select the ship type to place on your board
 *  while in the editing mode.
 *  the abstract methods selectShipType( ) informs the editor which ship type
 *  the user wants to place on the board.
 *  the editorFinished(), editorClear() and editorRandom() methods tell the editor
 *  to stop editing, clear all editings or create a random setting.
 */
public abstract class ShipSelection extends NTable implements NSelectListener, NClickListener {

    public abstract void editorFinished();
    public abstract void editorClear();
    public abstract void editorRandom();
    public abstract void selectShipType( ShipType type );
    
    /** Creates a new instance of ShipSelection */
    public ShipSelection( ShipType [] types, int [] count ) {
        super( 2, types.length+2 );
        setPadding(2);
        setWrapping(NOWRAP);
        setBackgroundColor(LIGHT_GREY);
        setElementsOrientation(LEFT+VCENTER);
        joinCells(0,0,getColumns()-1,0);
        //TF shiptype_selector = selector;
        headline.setBackgroundColor(GREY3);
        headline.setForegroundColor(WHITE);
        headline.setFontstyle      (BOLD );
        add( headline );
        add( buttons  ); add( "ships left" );
        buttons.add( clear_button );
        buttons.add( random_button );
        buttons.add( finish_button );
        ship_count = count;
        ship_types = types;
        initRadioButtons();
        finish_button.setBackgroundColor(ORANGE);
        radio_group  .addListener( this );
        clear_button .addListener( this );
        random_button.addListener( this );
        finish_button.addListener( this );
    }

    // the ship type is selected from a radio button menu
    // the ships_left_txt shows the number of ships remaining to be placed.
    private void initRadioButtons() {
        radio          = new NRadioButton[ ship_types.length ];
        ships_left_txt = new NText       [ ship_types.length ];
        for (int i=0; i<ship_types.length; i++) {
            radio[i] = new NRadioButton( ship_types[i].getShipClassName(), radio_group, false, new Integer(i) );
            ships_left_txt[i] = new NText();
            ships_left_txt[i].setOrientation(CENTER);
            add( radio[i]          );
            add( ships_left_txt[i] );
        }
        resetCounter ();
        updateCounter();
    }

    // finds the first valid highlightable (selected) position in the radio button menu
    // if all ships have been placed, all radio buttons are disabled, null is selected:
    private void highlightValidPosition() {
        int i=0;
        while (i<radio.length) {
            if (radio[i].getEnabled()) {
                radio_group.setSelected( radio[i] );
                highlight(i);
                return;
            }
            else i++;
        }
        // no radio button enabled - all ships have been placed:
        selectShipType( null );
    }
    
    // upon a restart in editing, the counter values are reset:
    public void resetCounter() {
        ships_left = new int [ ship_count.length ];
        for (int i=0; i<ship_count.length; i++) {
            ships_left[i] = ship_count[i];
            radio[i].setEnabled( ships_left[i]>0 );
        }
        highlightValidPosition();
    }

    // sets all ships_left values to 0 and disabled all radio buttons
    // called on selecting the random button, placing all ships at once:
    public void clearCounter() {
        for (int i=0; i<ship_count.length; i++) {
            ships_left[i] = 0;
            radio[i].setEnabled( false );
        }
    }
    
    // update all ship_left_txt Strings:
    public void updateCounter() {
        int total_left = 0;
        for (int i=0; i<ship_count.length; i++) {
            ships_left_txt[i].setText( ships_left[i] );
            total_left += ships_left[i];
        }
        // have all ships have been placed:
        finish_button.setEnabled( total_left==0 );
    }
    
    // notify menu that a ship of supplied type has been placed.
    // if this was the last ship of that type remaining to be placed,
    // the appropriate radio button is disabled.
    public void decreaseCounter( ShipType type ) {
        for (int i=0; i<ship_types.length; i++) {
            if (ship_types[i]==type) {
                ships_left[i]--;
                if (ships_left[i] == 0) {
                    radio[i].setEnabled( false );
                    highlightValidPosition();
                }
            }
        }
        updateCounter();
    }
    
    // highlight the menu table row of the specified position:
    private void highlight( int position ) {
        getRow(selected_pos+2).setStyle(null);
        if (position>=0) {
            selected_pos = position;
            getRow(selected_pos+2).setStyle(Highlighting);
            selectShipType( ship_types[ position ] );
        }
    }

    // a menu entry (radio button) was selected. 
    // as radio buttons have no (radio button) group index, the
    // position of the button is retrieved from the Integer attached
    // to the button in the data object:
    public void onSelect( NSelectEvent e ) {
        int sel = ((Integer) e.getData()).intValue();
        highlight( sel );
    }

    // handle button clicks:
    public void onClick( NClickEvent e ) {
        if (e.getSource() == clear_button ) editorClear();
        else
        if (e.getSource() == random_button) editorRandom();
        else
        if (e.getSource() == finish_button) editorFinished();
    }
    
    // the style definition for the highlighted menu entry:
    static NStyle     Highlighting  = new NStyle() {{ setBackgroundColor(ORANGE); setForegroundColor(WHITE); }};
    
    ShipType []       ship_types;
    int []            ships_left,
                      ship_count;
    int               selected_pos  = 0;
    
    NRadioButtonGroup radio_group   = new NRadioButtonGroup();
    NRadioButton []   radio         = null;
    NButton           clear_button  = new NButton("clear"),
                      random_button = new NButton("random"),
                      finish_button = new NButton("play!");
    NPanel            buttons       = new NPanel();
    NText []          ships_left_txt= null;
    NText             headline      = new NText("select ship type for positioning");
}
