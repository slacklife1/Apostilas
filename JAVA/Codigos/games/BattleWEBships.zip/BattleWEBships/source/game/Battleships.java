/*
 * GameApplicationjava
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 11. November 2004, 10:54
 */

package game;

import com.nex.webbase.*;
import com.nex.system.WebServer;

/**
 *  the Battleships game - play Battleships against a computer player
 *
 *  written as a web application using the webbase gui library (version 1.22 or higher)
 *  2004, nextwebstep.com
 */
public class Battleships extends GameApplication implements EditingFinished {

    // global setting: size of the player's boards:
    public static int          BoardSizeX = 9,
                               BoardSizeY = 9;

    // initialization of game:
    public void initGame() {
        myself   = new Player("Player");
        opponent = new ComputerPlayer( AllTypes, ShipCount );
        getPlayfield().setPlayerNames( myself.getName(), opponent.getName() );
        // add( getPlayfield() );
        gotoEditMode();
    }

    // called by the restart button:
    public void restartGame() {
        gotoEditMode();
    }
    
    
    // clear own fleet & offet ship placements:
    private void gotoEditMode() {
        displayGameMessage("edit your fleet");
        displayGameMessage("");
        myself.getFleet().clear();
        getPlayfield().editShipsPlacement( AllTypes, ShipCount, myself, this);
    }
    
    // callback: called when editing is finished & "play" button was pressed:
    public void editingFinished() {
        opponent.getFleet().random( AllTypes, ShipCount );
        opponent.reset();
        displayGameMessage("");
        Game game = new GameVersusComputer( getPlayfield(), myself, opponent ) {
            // handle game String messages by setting the message texts:
            public void message( String msg ) {
                displayGameMessage( msg );
            }
        };
        playGame( game, myself );
    }

    // the players:
    Player          myself         = null,
                    opponent       = null;

    
	final static int PORTNO = 26299;

	// global main starts a web server on port PORTNO:
	public static void main( String [] args ) {
		WebServer ws = new WebServer( PORTNO );
        // run it (creates a thread!):
        ws.start();
		System.out.println("Hello! The webbase web server has been started on port "+PORTNO);
		System.out.println("To access the BattleWEBships game, enter");
		System.out.println();
		System.out.println("    http://localhost:"+PORTNO+"/game.Battleships");
		System.out.println();
		System.out.println("in your web browser");
	}
}
