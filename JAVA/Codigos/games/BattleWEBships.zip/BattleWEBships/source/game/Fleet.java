/*
 * Fleet.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 11. November 2004, 11:31
 */

package game;

import com.nex.webbase.*;
import java.util.Vector;
import java.util.Iterator;
import java.util.Random;
import java.util.LinkedList;

/**
 *  a Fleet is the group of a Player's ships
 */
public class Fleet {

    public final static int MinShipDist = 1;   // minimum distance between ships

    final static int NO_SHIP = -1,
                     MISS    = -2;
    
    // Creates a new instance of Fleet 
    public Fleet() {
        board = new int[ GameApplication.BoardSizeY ] [ GameApplication.BoardSizeX ];
        clear();
    }

    // clear the fleet information (clears board and ships list)
    public void clear() {
        for (int y=0 ; y < GameApplication.BoardSizeY ; y++) {
            for (int x=0 ; x < GameApplication.BoardSizeX ; x++) {
                board[y][x] = NO_SHIP;
            }
        }
        ships.clear();
    }
    
    // chekcs if the specified area is free to place a ship:
    private boolean checkAreaFree( int x0, int y0, int x1, int y1 ) {
        if (x0<0) x0=0;
        if (y0<0) y0=0;
        if (x1>GameApplication.BoardSizeX) x1 = GameApplication.BoardSizeX;
        if (y1>GameApplication.BoardSizeY) y1 = GameApplication.BoardSizeY;
        for (int y=y0; y<y1; y++) 
        for (int x=x0; x<x1; x++) {
            if (board[y][x] >= 0) return false;  // interferes with other ship
        }
        return true; // no other ship found in area -> play place ship here
    }

    // can a ship of the specified type be placed on the specified position?
    public boolean isPositionFree( int posx, int posy, boolean vertical, ShipType ship_type ) {
        int length = ship_type.getLength(),
            M      = MinShipDist;
        if ( vertical ) {
            // vertical:   check if a ship of specified type can be placed in the posx column:
            if ( posy + length > GameApplication.BoardSizeY ) return false; // ship is too long for board
            return checkAreaFree( posx-M, posy-M, posx+1+M, posy+length+M );
        }
        else {
            // horizontal: check if a ship of specified type can be placed in the posy row:
            if ( posx + length > GameApplication.BoardSizeX ) return false; // ship is too long for board
            return checkAreaFree( posx-M, posy-M, posx+length+M, posy+1+M );
        }
    }

    // place a (new) ship on the specified positions:
    private void placeShip( Ship ship, int x0, int y0, int x1, int y1 ) {
        ships.add( ship );
        int index = ships.indexOf( ship );
        for (int y=y0; y<y1; y++) 
        for (int x=x0; x<x1; x++) {
            board[y][x] = index;
        }
    }
    
    // place a (new) ship on it's (constructor-) specified position
    public  void placeShip( Ship ship ) {
        if (ship.isVertical()) {
            placeShip( ship, ship.getX(), ship.getY(), ship.getX()+1, ship.getY()+ship.getLength() );
        }
        else {
            placeShip( ship, ship.getX(), ship.getY(), ship.getX()+ship.getLength(), ship.getY()+1 );
        }
    }

    // returns the last position bombed by the opponent player:
    public TargetPosition getLastBombPosition() { return last_bomb_position; }
    
    // bomb the specified (x,y) position.
    // returns the ship hit (if any).
    public Ship bomb( int x, int y ) {
        last_bomb_position = new TargetPosition( x, y );
        int index = board[y][x];
        if (index>=0) {
            // there is a ship at this position:
            Ship ship = (Ship) ships.get(index);
            ship.bomb(x,y);
            return ship;
        }
        else {
            // found pure water...
            board[y][x] = MISS;
            return null;
        }
    }

    // true if there is a ship at the specified position
    public boolean isShip( int x, int y ) {
        return board[y][x] >= 0;
    }
    
    // true if the specified position has been bombed already:
    public boolean isBombed( int x, int y ) {
        if (board[y][x] == MISS) 
            return true;
        else {
            Ship s = getShip(x,y);
            return (s != null && s.wasHit(x,y));
        }
    }

    // retrieve the ship at the specified position (if any)
    public Ship getShip( int x, int y ) {
        if (board[y][x]>=0)
            return (Ship) ships.get( board[y][x] );
        else
            return null;
    }

    // create a random placement of the specified ship types & numbers:
    public void random( ShipType [] ship_types, int [] count ) {
        clear();
        for (int t=0; t<ship_types.length; t++) {
            ShipType type   = ship_types[t];
            int      number = count[t];
            while (number>0) {
                LinkedList li = new LinkedList();
                for (int y=0; y<GameApplication.BoardSizeY; y++)
                for (int x=0; x<GameApplication.BoardSizeX; x++) {
                    if (isPositionFree(x,y,true,type)) {
                        li.add( new int[] { x,y, ShipGraphics.VERTICAL } );
                    }
                    if (isPositionFree(x,y,false,type)) {
                        li.add( new int[] { x,y, ShipGraphics.HORIZONTAL } );
                    }
                }
                if (li.isEmpty()) throw new RuntimeException("Fleet.random was not able to place all ships. Is the BoardSizeX/Y large enough (>=8) ??");
                // ok, choose a coordinate for ship by random:
                int [] coords = (int []) li.get( random.nextInt( li.size() ) );
                placeShip( new Ship( type, coords[0], coords[1], coords[2]==ShipGraphics.VERTICAL ) );
                number--;
            }
        }
    }

    // true if the whole fleet was sunk
    public boolean allSunk() {
        Iterator it = ships.iterator();
        while (it.hasNext()) {
            if ( !((Ship) it.next()).isSunk() ) return false; // at least this ship has not been sunk
        }
        return true; // all ships have been sunk
    }
    
    static Random  random = new Random( System.currentTimeMillis() );
    
    int [][]       board  = null;
    Vector         ships  = new Vector();
    TargetPosition last_bomb_position = new TargetPosition(0,0);
    
}
