/*
 * OwnDisplay.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 12. November 2004, 15:31
 */

package game;

import com.nex.webbase.*;
import java.util.LinkedList;

/**
 *  Display variant showing own fleet (all ships are visible all the time)
 */
public class OwnDisplay extends Display {
    
    public OwnDisplay(Playfield playfield, int offsetX, int offsetY, Player fleet_owner) {
        super( playfield, offsetX, offsetY, fleet_owner );
    }

    public void updateDisplay() {
        super.updateDisplay();
        // in a player's own display, the last-bombed position is marked:
        TargetPosition pos = getFleet().getLastBombPosition();
        getPlayfield().markPosition( pos.getX(), pos.getY() );
    }
    
    public NComponent updateDisplay(int xpos, int ypos) {
        Fleet   fleet  = getFleet();
        Ship    ship   = fleet.getShip ( xpos, ypos );
        if (ship != null) {
            int rel_pos=ship.getRelativePosition( xpos,ypos );
            String image_url = ship.getShipGraphic(rel_pos, false);
            return new NImage( image_url );
        }
        if (fleet.isBombed(xpos,ypos))
            return new NImage( Images.MissImageUrl );
        else
            return null;
    }

}
