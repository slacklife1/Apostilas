
/* 
 * ShipGraphics.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 */

package game;

import com.nex.webbase.*;

/*
 *  the ShipGraphics object keeps track of the several images needed to display one ship type.
 *  All graphics are found at /game/resources/ in the java class path and accessed as resources
 *  (via the class path, not from the webserver file path, see the NApplication.createResourcePath() method).
 *  The image filenames consist of a basename (like "ba" for battleships) + an image index 1..length.
 *  Horizontal (x-axis) graphics are followed by an 'x' character additionally.
 *  Enemy-style images are preceeded by an 'e' character.
 *
 *  Example:   /game/resources/ecr3x.png  is the 3rd image of the horizontal version of an enemy's cruiser.
 */
public class ShipGraphics {

	public static int	VERTICAL   = 0,
						HORIZONTAL = 1;

	public static int	OWN   = 0,
						ENEMY = 1;

	String [][][] url_of_ship_part;
	int			  ship_length;
			
	public ShipGraphics( NApplication app, String basename, int length ) {
		ship_length = length;
		url_of_ship_part = new String[ length ] [ 2 ] [ 2 ];
		for (int pos=0; pos<length; pos++) {
            String filename_postfix = ""+(1+pos);   // graphic files are numbered ba1.png, ba2.png, ba3.png etc.
			url_of_ship_part [pos] [ VERTICAL ] [ OWN ] = app.createResourcePath("game/resources/"    +basename+filename_postfix+ ".png");
			url_of_ship_part [pos] [HORIZONTAL] [ OWN ] = app.createResourcePath("game/resources/"    +basename+filename_postfix+"x.png");
			url_of_ship_part [pos] [ VERTICAL ] [ENEMY] = app.createResourcePath("game/resources/"+"e"+basename+filename_postfix+ ".png");
			url_of_ship_part [pos] [HORIZONTAL] [ENEMY] = app.createResourcePath("game/resources/"+"e"+basename+filename_postfix+"x.png");
		}
	}
 
    // access the nth (0..n-1) image of this ship type's graphical representation.
    // must specify vertical or horizontal and own or enemy display mode:
    public String getShipGraphic( int pos, int vertical_or_horizontal, int own_or_enemy ) {
        return url_of_ship_part[ pos ] [ vertical_or_horizontal ] [ own_or_enemy ];
    }
}
