/*
 * Editor.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 15. November 2004, 17:31
 */

package game;

/**
 * this Editor class combines the ship type selection menu (ShipSelection) with an
 * EditorDisplay display on the specified Playfield.
 *
 * The end of editing is reported to the specified EditingFinished listener.
 */
public class Editor extends ShipSelection implements ShipPlacer {
    
    // position of the EditorDisplay on the Playfield (== right side display)
    final static int    editorPosX = GameApplication.BoardSizeX+1,
                        editorPosY = 2;
    
    // Creates a new instance of Editor
    public Editor( ShipType [] ship_types, int [] counts,  Playfield playfield, Player fleet_owner, EditingFinished edit_end ) {
        super( ship_types, counts );
        this.fleet      = fleet_owner.getFleet();
        this.all_types  = ship_types;
        this.ship_counts= counts;
        this.edit_end   = edit_end;
        setFontsize(12);
        setOrientation(STRETCH);
        setForegroundColor( GREY2 );
        setTableFrameColor( GREY2 );
        resetCounter();
        edit_disp = new EditorDisplay( playfield, editorPosX, editorPosY, fleet_owner, this );
        edit_disp.updateDisplay();
    }
    
    // when a new ship type is selected to be positioned, the editor display has to be updated:
    public void selectShipType(ShipType type) {
        editor_type = type;
        if (edit_disp != null)
            edit_disp.updateDisplay();
    }
    
    // returns the currently selected ship type:
    public ShipType getCurrentType() {
        return editor_type;
    }
    
    // a new ship is to be placed in the edited fleet.
    // update the display & decrease the counter for the ship type:
    public void positionShip(int posx, int posy, boolean vertical) {
        Ship ship = new Ship(editor_type,posx,posy,vertical );
        fleet.placeShip( ship );
        edit_disp.updateDisplay();
        decreaseCounter( editor_type );
    }

    // reset (clear) the editor & fleet:
    public void editorClear() {
        fleet.clear();
        resetCounter();
        updateCounter();
        edit_disp.updateDisplay();
    }
    
    // create a random fleet:
    public void editorRandom() {
        fleet.random( all_types, ship_counts );
        clearCounter();
        updateCounter();
        editor_type = null;
        edit_disp.updateDisplay();
    }

    // report the editorFinished message to the specified listener
    public void editorFinished() {
        edit_end.editingFinished();
    }
    
    int []          ship_counts     = null;
    ShipType []     all_types       = null;
    ShipType        editor_type     = null;
    EditorDisplay   edit_disp       = null;
    Fleet           fleet           = null;
    EditingFinished edit_end        = null;
}
