/*
 * ShipPlacerButton.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 12. November 2004, 15:38
 */

package game;

import com.nex.webbase.*;

/**
 *  a ShipPlaceButton is either a vertical or horizontal arrow button,
 *  triggering a ShipPlacer.positionShip(x,y,vertical_or_horizontal) event
 *  when clicked.
 *  The button image URLs are static globals in the Images class.
 */
public class ShipPlacerButton extends NImageButton implements NClickListener {
    
    /** Creates a new instance of ShipPlacerButton */
    public ShipPlacerButton( int x, int y, boolean vertical, ShipPlacer p ) {
        super( vertical ? Images.PlaceButtonDown0 : Images.PlaceButtonRight0 ,
               vertical ? Images.PlaceButtonDown1 : Images.PlaceButtonRight1 , null );
        addListener( this );
        ship_placer = p;
        posx = x;
        posy = y;
        is_vertical = vertical;
    }
    
    // a button click triggers a ShipPlacer position event:
    public void onClick( NClickEvent e ) {
        ship_placer.positionShip( posx, posy, is_vertical );
    }
    
    ShipPlacer ship_placer;
    int        posx, posy;
    boolean    is_vertical;
}
