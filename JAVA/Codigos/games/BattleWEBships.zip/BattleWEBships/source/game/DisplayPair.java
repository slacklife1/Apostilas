/*
 * DisplayPair.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 19. November 2004, 11:24
 */

package game;

/**
 * A DisplayPair is a pair of Display objects for the screen display for ONE player,
 * consisting of the display of one's OWN ships,
 * and the display of the OPPONENTS ships.
 *
 * Note that in a 2-human-players game, you would have TWO DisplayPairs:
 *
 * Pair1 (player1 screen):  Player1 ships (own=visible) + Player2 ships (not/partially visible)
 * Pair2 (player2 screen):  Player2 ships (own=visible) + Player1 ships (not/partially visible)
 */
public class DisplayPair {
    
    // creates a new DisplayPair, 
    // consisting of one display for player 1 and one for player 2:
    public DisplayPair( Display d1, Display d2 ) {
        display1 = d1;
        display2 = d2;
    }
    
    public Display getPlayer1Display() {
        return display1;
    }

    public Display getPlayer2Display() {
        return display2;
    }
    
    Display display1,   // the display instance for player 1 ships
            display2;   // the display instance for player 2 ships
}
