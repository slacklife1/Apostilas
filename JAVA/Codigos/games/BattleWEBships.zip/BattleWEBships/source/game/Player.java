/*
 * Player.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 18. November 2004, 13:47
 */

package game;

/**
 *  the basic Player is a quite abstract definition of what a battleships player has to do:
 *  1) when requested to perform his next move (requestMove),
 *  2) wait until the Player chooses a target (the Move), then
 *  3) inform the MoveListener (i.e., the Game) about the selected Move (executeMove).
 *  4) the Game informs the player about the result of the Move (reportHit).
 */
public class Player {
    
    // create a player with supplied name
    public Player(String name) {
        fleet = new Fleet();
        playername = name;
    }
    
    // returns the player's fleet
    public Fleet getFleet() {
        return fleet;
    }
    
    // the framework requests the next move
    // the move may be executed directly (see ComputerPlayer), or later
    // (after the human player selects a position to bomb on the board).
    public void requestMove( MoveListener listener ) {
        move_target = listener;
        waiting     = true;
    }
    
    // get wait status: are we waiting for this player to select his next move?
    public boolean waitingForMove() {
        return waiting;
    }
    
    // execute the supplied Move (== bomb position x/y)
    protected void executeMove( Move m ) {
        waiting = false;
        move_target.doMove( m );
    }

    // result of the Move (hit yes/no, which ship) is reported back to the player:
    public void reportHit( Move m ) { /* information on the executed move can be retrieved from m here */ }

    // get player's name
    public String getName() { return playername; }

    // reset internal state (used by ComputerPlayer):
    public void reset() { }
    
    Fleet        fleet;
    String       playername;
    boolean      waiting     = false;
    MoveListener move_target = null;
}
