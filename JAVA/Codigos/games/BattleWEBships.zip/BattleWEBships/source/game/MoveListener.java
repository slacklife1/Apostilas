/*
 * MoveListener.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 18. November 2004, 14:01
 */

package game;

/**
 *  target of Players' moves (the Game object is a MoveListener)
 */
public interface MoveListener {
    public void doMove( Move m ); 
}
