/*
 * ShipPlacer.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 12. November 2004, 15:33
 */

package game;

/**
 *  a ShipPlacer is the part of the editor handling the positioning of the ship
 *  currently to be placed on the board.
 */
public interface ShipPlacer {
    
    // returns the type of the ship currently to be placed on the board:
    public ShipType getCurrentType();
    
    // place a ship of the current type on the board:
    public void     positionShip( int posx, int posy, boolean vertical );
}
