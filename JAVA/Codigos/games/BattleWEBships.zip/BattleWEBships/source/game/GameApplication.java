/*
 * GameApplication.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 11. November 2004, 10:54
 */

package game;

import com.nex.webbase.*;

/**
 *  the Battleships application framework
 *
 *  written as a web application using the webbase gui library (version 1.22 or higher)
 *  2004, nextwebstep.com
 */
public abstract class GameApplication extends NApplication implements NClickListener {

    // global setting: size of the player's boards:
    public static int          BoardSizeX = 9,
                               BoardSizeY = 9;

    // initialization of Battleships
    // note: createResorcePath may not already be called in the constructor,
    //       that's why we put all initializations here in the init() method.
    public void init() {
        Images.initImageUrls( this );
        if (AllTypes == null) {
            // getShipTypes inits image URLs as well, so pass the application (this) object:
            AllTypes = ShipType.getShipTypes(this);
        }
        setDescription    ("nextwebstep's Battleships");
        setBackgroundColor( LIGHT_GREY );
        // the playfield table is the one and only component in this game:
        cancel_game .addListener( this );
        restart_game.addListener( this );
        add( playfield );
        initGame();
        add( messages );
    }

    // initialization of game:
    public abstract void initGame();

    // called by the restart button:
    public abstract void restartGame();

    // playGame is easy: create an opponent display at the left, the own fleet display on the right
    public void playGame(Game g, Player p) {
        myself = p;
        game   = g;
        current_button = cancel_game;
        game.start();
    }

    // called before each screen refresh.
    // display playfield when waiting for own move, or wait message if opponent's turn:
    public void beforePaint() {
        boolean timeout = (waiting != null && waiting.getCount() >= 10);
        if ( game != null ) {
            if (myself.waitingForMove() || !game.isRunning() || timeout) {
                // own move is expected or game has ended: display playfield
                clear();
                add( playfield );
                add( messages );
                add( current_button );
                setRefresh( 0 );
                waiting = null;
                if (timeout) {
                    game = null;
                    System.out.println("restart!");
                    restartGame();
                }
            }
            else {
                // opponent's move is expected. display wait info string
                if (waiting == null) waiting = new WaitInfo();
                else                 waiting.update();
                clear();
                add( waiting );
                setRefresh( 3 );
            }
        }
        else {
            setRefresh( 0 );
        }
        
    }

    // event handler: cancel or restart button was pressed:
    public void onClick( NClickEvent e ) {
        if ( e.getSource() == cancel_game ) {
            // before restarting the game, reveal the opponent's ships:
            current_button = restart_game;
            game.revealSolution();
        }
        else
        if ( e.getSource() == restart_game ) {
            remove( restart_game );
            // restart the game (go to ship placing again)
            game = null;
            restartGame();
        }
    }

    public void displayGameMessage( String msg ) {
        message1.setText( message2.getText() );
        message2.setText( msg );
    }

    protected Playfield getPlayfield() {
        return playfield;
    }
    
    // the game logic itself (asking both players to move alternatively):
    private Game            game           = null;
    
    // player (owner of this application. in a 2-player game, every player has started his own app!)
    private Player          myself         = null;
    
    // the (table-based) playfield, displaying both oppenent and own ships:
    private Playfield       playfield      = new Playfield();
    
    // buttons to cancel/restart a running game:
    private NButton         cancel_game    = new NButton("cancel game"),
                            restart_game   = new NButton("start new game"),
                            current_button = null;
    
    // game message texts
    private NText           message1 = new NText(""),
                            message2 = new NText("");
    
    // messages are displayed in a 1x2 grid:
    private NGrid           messages = new NGrid(1,2) {{ add(message1); add(message2); }};
    
    // simple "wait-for-opponent's-next-move" text
    private WaitInfo        waiting        = null;
    
    // types of ships available & number of ships per type (1 each except 2 destroyers):
    protected static ShipType []    AllTypes  = null;
    protected static int []         ShipCount = { 1,1,1,2 };


}
