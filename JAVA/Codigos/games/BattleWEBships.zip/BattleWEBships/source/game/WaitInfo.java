/*
 * WaitInfo.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 18. November 2004, 15:11
 */

package game;

import com.nex.webbase.*;

/**
 *  a simple wait info text with counter
 *  the counter is increased every time the update() method is invoked.
 */
public class WaitInfo extends NPanel implements NClickListener {
    
    /** Creates a new instance of WaitInfo */
    public WaitInfo() {
        add( text );
        add( refresh );
        refresh.addListener(this);
        update();
    }

    public void update() {
        String txt = "waiting for opponent's move";
        count++;
        for (int i=0; i<count; i++) txt+=".";
        text.setText( txt );
    }
    
    public int getCount() {
        return count;
    }
    
    // dummy function; implemented only so the refresh button becomes active:
    public void onClick( NClickEvent e ) { /* dummy */ }
    
    NButton refresh = new NButton("refresh");
    NText   text    = new NText();
    
    int count = 0;
}
