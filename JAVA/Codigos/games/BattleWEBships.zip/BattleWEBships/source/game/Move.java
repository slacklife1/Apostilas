/*
 * Move.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 18. November 2004, 14:01
 */

package game;

/**
 *  a Move is the bombing of a (xpos,ypos) position.
 *
 *  once evaluated, the Move is returned to the Player's implementation
 *  of the reportHit( m ) method, where isHit() and getShip() can be used
 *  to retrieve information about the effects of the Move.
 */
public class Move extends TargetPosition {

    public Move( int xpos, int ypos ) {
        super(xpos,ypos);
    }
       
    public void setHit( Ship sh ) {
        ship = sh;
    }
    
    public boolean isHit() {
        return ship != null;
    }
    
    public Ship getShip() {
        return ship;
    }
    
    Ship ship = null;
}
