/*
 * ShipType.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 11. November 2004, 11:04
 */

package game;

import com.nex.webbase.*;

/**
 *  a ShipType has all the information about the type:
 *  - length
 *  - ship class name
 *  - several names for individual ships
 *  - the ship graphics' URL paths
 *
 *  ShipType creates a static array of types on the initial call to getShipTypes().
 */
public class ShipType {
    
    /** Creates a new instance of ShipType */
    private ShipType( NApplication app, String ship_class, String [] ship_names, String basename, int length ) {
        graphics   = new ShipGraphics( app, basename, length );
        shiplength = length;
        namesavail = ship_names;
        classname  = ship_class;
    }
    
    public int getLength() { 
        return shiplength; 
    }
    
    public String getNextName() { 
        int max = namesavail.length;
        namecount++;
        return namesavail[ namecount % max ];
    }
    
    public String getShipClassName() {
        return classname;
    }
    
    public String getShipGraphic( int pos, int vertical_or_horizontal, int own_or_enemy ) {
        return graphics.getShipGraphic( pos, vertical_or_horizontal, own_or_enemy );
    }
    
    // get all available ship types.
    // this method is called with an "app" parameter for creating image URLs
    // (the ships graphics are accessed from the java class path, not from the webserver file 
    //  path so you can package the whole game .class .png files in one .JAR archive!)
    public static ShipType [] getShipTypes( NApplication app ) {
        if (all_types == null) {
            // init ship types:
            all_types = new ShipType [] {
                new ShipType( app, "Carrier"    , CarrierNames   , "ca", 5 ),
                new ShipType( app, "Battleship" , BattleshipNames, "ba", 4 ),
                new ShipType( app, "Cruiser"    , CruiserNames   , "cr", 3 ),
                new ShipType( app, "Destroyer"  , DestroyerNames , "de", 2 )
            };
        }
        return all_types;
    }
    
    private static ShipType []     all_types = null;
    private final static String [] DestroyerNames  = { "Weasel", "Rabbit", "Snake", "Racer", "Jumper" },
                                   CruiserNames    = { "Striker", "St George", "Rising Sun", "Rescue", "Othello" },
                                   BattleshipNames = { "Invincible", "Mighty B", "New York", "P.S.Reed", "Hamlet"  },
                                   CarrierNames    = { "Washington", "Lincoln", "Rutherford", "VanDahlen" , "San Diego" };

    private ShipGraphics        graphics   = null;
    private int                 shiplength = 0;
    private String []           namesavail = null;
    private String              classname  = null;
    private int                 namecount  = 0;
    
    
}
