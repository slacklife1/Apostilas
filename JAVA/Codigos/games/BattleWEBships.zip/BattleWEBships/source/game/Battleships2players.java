/*
 * Battleships2players.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 22. November 2004, 17:53
 */

package game;

import com.nex.webbase.*;

/**
 *  demo implementation of a 2-human-players Battleships game.
 *
 *  both players have to start the game in their browsers
 *  and are connected by the WaitForPlayer class.
 */
public class Battleships2players extends GameApplication {

    // a 2-player game starts with the input of the player's name:
    public void initGame() {
        enter_values.add( "enter your name:");
        enter_values.add( name );
        enter_values.add( ok );
        enter_values.add( error );
        error.setForegroundColor(RED);
        ok.addListener( checkvalues );
        restartGame();
    }

    // called by the restart button:
    public void restartGame() {
        getPlayfield().crossWordMessage("         "+"  enter  "+"your name" );
        add( enter_values );
    }
    
    // create a 2-human-player game.
    // each player needs an individual DisplayPair (dp1, dp2)
    // to display both his and the opponent's fleet.
    private Game create2PlayerGame( Player p1, Playfield pf1, Player p2, Playfield pf2) {
        pf1.setPlayerNames( p1.getName(), p2.getName() );
        pf2.setPlayerNames( p2.getName(), p1.getName() );
        
        Display p1_display_own      = new OwnDisplay     ( pf1 , Game.OwnDisplayPosX     ,2, p1 ),
                p1_display_opponent = new OpponentDisplay( pf1 , Game.OpponentDisplayPosX,2, p2 , p1 );

        Display p2_display_own      = new OwnDisplay     ( pf2 , Game.OwnDisplayPosX     ,2, p2 ),
                p2_display_opponent = new OpponentDisplay( pf2 , Game.OpponentDisplayPosX,2, p1 , p2 );
        
        DisplayPair dp1 = new DisplayPair(p1_display_own, p1_display_opponent),
                    dp2 = new DisplayPair(p2_display_opponent, p2_display_own);
        
        return new Game( p1, p2, new DisplayPair [] { dp1, dp2 } ) {
            // handle game String messages by setting the message texts:
            public void message( String msg ) {
                displayGameMessage( msg );
            }
        };
    }

    // init the 2 human players game:
    private void init2playersGame( WaitForPlayer myself, WaitForPlayer other ) {
        Game game = myself.getGame();
        if (game == null) {
            game = create2PlayerGame( myself.getPlayer(), myself.getPlayfield(), 
                                      other .getPlayer(), other .getPlayfield() );
            myself.setGame( game );
            other .setGame( game );
        }
        playGame( game, myself.getPlayer() );
    }

    // overloading the beforePaint() callback to display a "waiting" component
    // while waiting for another human player to start the game:
    public void beforePaint() {
        if (myself_waiting != null) {
            // waiting for another human player:
            WaitForPlayer other_waiting = myself_waiting.getOtherPlayer();
            if (myself_waiting.update() && other_waiting == null) {
                // while waiting, keep up refreshing:
                setRefresh(2); 
                return;
            }
            else {
                // ok, has found opponent - init the game:
                remove( myself_waiting );
                if (other_waiting!=null) { 
                    init2playersGame( myself_waiting, other_waiting );
                    myself_waiting = null;
                }
                else {
                    // return to the "enter your name" input:
                    add( enter_values );
                }
            }
        }
        super.beforePaint();
    }

    // check the name input
    // once a valid name has been provided, a new Player is created
    // and set to wait-mode.
    NClickListener checkvalues = new NClickListener() {
        public void onClick( NClickEvent e ) {
            if ( e.getSource() == ok ) {
                if (name.getText().trim().length()==0) error.setText("must enter a name!");
                else {
                    error.setText("");
                    remove( enter_values );
                    Player me = new Player( name.getText() );
                    me.getFleet().random( AllTypes, ShipCount );
                    Display d = new OwnDisplay( getPlayfield(), Game.OwnDisplayPosX, 2, me);
                    d.updateDisplay();
                    myself_waiting = new WaitForPlayer( me, getPlayfield(), 15 );
                    add( myself_waiting );
                }
            }
        }
    };
    
    
    WaitForPlayer myself_waiting = null;
    
    NInput        name           = new NInput();
    NText         error          = new NText("");
    NButton       ok             = new NButton(" ok ");
    NGrid         enter_values   = new NGrid(2);
}
