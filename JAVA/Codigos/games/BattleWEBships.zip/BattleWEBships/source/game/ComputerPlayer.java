/*
 * ComputerOpponent.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 16. November 2004, 19:53
 */

package game;

import java.util.LinkedList;
import java.util.Iterator;
import java.util.Random;

/**
 *  the ComputerPlayer class is a fully working computer opponent to play GameApplication
 *  
 *  It does not use any of the fleet logic or knowledge defined anywhere in the program,
 *  but defines it's own logic and knowledge of the game.
 *
 *  Basically, it works like this:
 *  1) bomb positions at random
 *  2) once a ship is hit, bomb around this ship until the ship is sunk.
 *
 *  Of course, 1) is a bit more intelligent than simple random bombing. All positions
 *  that are not possible to hide another ship (because there is an adjacent ship already,
 *  or because there would not be enough space for a ship to be vertically/horizontally)
 *  are excluded, of course.
 */
public class ComputerPlayer extends Player {

    final static int UNKNOWN = 0, MISS = 1, SHIP = 2;
    
    final static int Maxlen = 10;
    
    /** Creates a new instance of ComputerOpponent */
    public ComputerPlayer( ShipType [] types, int [] count ) {
        super("ComputerPlayer");
        this.counts = count;
        this.types  = types;
        // create an array of result flags:
        results = new int [GameApplication.BoardSizeY][GameApplication.BoardSizeX];
        reset();
    }

    // resets the player. 
    public void reset() {
        current_seek = null;
        lengths = new int [Maxlen];
        for (int i=0; i<lengths.length; i++) lengths[i] = 0;
        for (int i=0; i<types.length; i++) lengths[ types[i].getLength() ] += counts[i];
        // create a list of all possible target positions:
        for (int y=0; y<GameApplication.BoardSizeY; y++) 
        for (int x=0; x<GameApplication.BoardSizeX; x++) {
            positions.add( new TargetPosition(x,y) );
            results[y][x] = UNKNOWN;
        }
    }
    
    // returns the minimum size of all remaining (yet unsunk) ships:
    public int getMinimumShipSize() {
        for (int i=0; i<Maxlen; i++) {
            if (lengths[i] != 0) { return i; }
        }
        System.out.println("NOMINSIZE");
        return 0;
    }

    // the Game framework requests a move from the player:
    public void requestMove( MoveListener listener ) {
        super.requestMove( listener );
        // directly execute the move already on request (no wait neccessary):
        Move m = calcNextMove();
        executeMove( m );
    }

    // after executing the Move, the Player is informed about the result (hit yes/no):
    public void reportHit( Move m ) { 
        if (m.isHit())
            results[ m.getY() ] [ m.getX() ] = SHIP;
        else
            results[ m.getY() ] [ m.getX() ] = MISS;
        if (current_seek != null ) 
            current_seek.setResult( m.getX(), m.getY(), m.isHit() );
        Ship s = m.getShip();
        if (s != null) {
            if (current_seek != null ) {
                if (s.isSunk()) {
                    current_seek = null;
                    lengths[s.getLength()] --;
                }
            }
            else {
                int possible_above = possibleSpaceY( m.getX(), m.getY(), -1 ),
                    possible_below = possibleSpaceY( m.getX(), m.getY(), +1 ),
                    possible_right = possibleSpaceX( m.getX(), m.getY(), +1 ),
                    possible_left  = possibleSpaceX( m.getX(), m.getY(), -1 );
                current_seek = new ShipSeeker( m.getX(), m.getY(),
                                               getMinimumShipSize(),
                                               possible_left, possible_right,
                                               possible_above, possible_below);

            }
        }
    }

    /* private functions for the computer logic: */

    // is there a ship in the area (x0,y0) x (x1,y1)? Note: (x1,y1) are inclusive values!
    private boolean seesShip( int x0, int y0, int x1, int y1 ) {
        if (x0<0) x0=0; if (x1==GameApplication.BoardSizeX) x1--;
        if (y0<0) y0=0; if (y1==GameApplication.BoardSizeY) y1--;
        for (int y=y0; y<=y1; y++)
        for (int x=x0; x<=x1; x++) {
            if (results[y][x]==SHIP) { /* System.out.print("ship_at_"+x+","+y+" ");*/ return true; }// a ship in area
        }
        return false; // no ship in area
    }

    // how long could a ship extend from (x,y) to left (add=-1) or right (add=+1)?
    // if a ship is at (x-2,y) or (x+2,y), there is definitely no ship at (x-1,y) or (x+1,y)
    // as there is a MinShipDist distance between ships:
    private int possibleSpaceX( int x, int y, int add ) {
        if (x+add < 0 || x+add == GameApplication.BoardSizeX) return 0; // no space
        else
        if (seesShip(x+add,y-Fleet.MinShipDist,x+add,y+Fleet.MinShipDist)) return -1; // position adjacent to ship
        else
        if (results[y][x+add] == MISS) return 0;
        else {
            // unknown - assume water and continue
            return 1+possibleSpaceX(x+add,y,add);
        }
    }

    // how long could a ship extend from (x,y) to above (add=-1) or below (add=+1)?
    // see possibleSpaceX for more info.
    private int possibleSpaceY( int x, int y, int add ) {
        if (y+add < 0 || y+add == GameApplication.BoardSizeY) return 0; // no space
        else
        if (seesShip(x-Fleet.MinShipDist,y+add,x+Fleet.MinShipDist,y+add)) return -1; // position adjacent to ship
        else
        if (results[y+add][x] == MISS) return 0;
        else {
            // unknown - assume water and continue
            return 1+possibleSpaceY(x,y+add,add);
        }
    }
    
    // is it possible that there is a ship at the (yet unknown) position (x,y) when the
    // minimum size of yet-to-be-sunk ships is min_length?
    private boolean positionPossible( int x, int y, int min_length ) {
        int possible_above = possibleSpaceY( x, y, -1 ),
            possible_below = possibleSpaceY( x, y, +1 ),
            possible_right = possibleSpaceX( x, y, +1 ),
            possible_left  = possibleSpaceX( x, y, -1 );
     
        return  (results[y][x] == UNKNOWN) &&                      // (x,y) is still undiscovered AND
                possible_above >= 0 && possible_below >= 0 &&      // may not be <0 (adjacent ship)
                possible_right >= 0 && possible_left  >= 0 &&      // may not be <0 (adjacent ship)
                (possible_left +possible_right+1 >= min_length ||  // must be at least enough space in either
                 possible_above+possible_below+1 >= min_length);   // horizontal or vertical direction
    }
    

    // get the next position to bomb
    // if there is a current_seek (ship that is found, but not yet sunk), first finish bombing this
    // otherwise, choose a random position, check if it's worth bombing (possiblePossition(x,y)) and
    // return as a new Move(x,y).
    private Move calcNextMove() {
        int min_len = getMinimumShipSize();
        if (current_seek != null) {
            Move m = null;
            do {
                m = current_seek.getNextTry();
                if (m != null && results[ m.getY() ] [ m.getX() ] == UNKNOWN) return m;
            } while (m != null);
            current_seek = null;
        }
        while ( !positions.isEmpty() ) {
            int sz = positions.size(),
                p  = random.nextInt( sz );
            TargetPosition try_pos = (TargetPosition) positions.remove(p);
            if ( positionPossible(try_pos.getX(), try_pos.getY(), min_len) ) {
                Move m = new Move( try_pos.getX(), try_pos.getY() );
                return m;
            }
        }
        // no more positions found - this is an error:
        throw new RuntimeException("ComputerPlayer.calcNextMove has run out of possible target positions!");
    }

    static Random  random = new Random( System.currentTimeMillis() );
    
    ShipSeeker  current_seek = null;
    LinkedList  positions    = new LinkedList();
    int [][]    results      = null;
    int      [] lengths      = null;
    int      [] counts       = null;
    ShipType [] types        = null;

    
    /*
     * If a position (x,y) was hit, the ShipSeeker helps to find the next possible positions around (x,y)
     * to find the complete ship.
     *
     * At first, it may not be clear if the ship extends vertical or horizontal.
     * This _may_ be clear if the number of possible (undiscovered) positions in one direction is
     * not high enough (not enough space to place a ship of min_length); otherwise, it is simply tried out.
     *
     * The positions possible (Moves) are returned by getNextTry().
     * A feedback has to be returned to the ShipSeeker with setResult(x,y,hit-yes-or-no);
     */
    private static class ShipSeeker {
        // after a hit on position (xpos,ypos), this structure helps searching to find the rest of the ship.
        // must specify the min length of ships that are expected and the possible (undiscovered) space to
        // each direction left, right, above and below:
        public ShipSeeker( int xpos, int ypos, int min_length, int possL, int possR, int possA, int possB ) {
            int vertical_placement_possible   = ((possA+possB+1) >= min_length ? 1 : 0),
                horizontal_placement_possible = ((possL+possR+1) >= min_length ? 1 : 0);
            above_possible = possA * vertical_placement_possible;
            below_possible = possB * vertical_placement_possible;
            right_possible = possR * horizontal_placement_possible;
            left_possible  = possL * horizontal_placement_possible;
            minX = maxX = xpos;
            minY = maxY = ypos;
        }
        
        // gets the next position recommended to bomb (may be water!) to finish bombing the ship:
        public Move getNextTry() {
            int dir = next_dir++,
                end_dir = dir;
            if (next_dir == 4) next_dir = 0;
            do {
                if ( dir==RIGHT && right_possible>0 ) return new Move( maxX+1, minY );
                if ( dir==LEFT  &&  left_possible>0 ) return new Move( minX-1, minY );
                if ( dir==ABOVE && above_possible>0 ) return new Move( minX, minY-1 );
                if ( dir==BELOW && below_possible>0 ) return new Move( minX, maxY+1 );
                dir++;
                if (dir==4) dir = 0;
            } while (dir != end_dir );
            throw new RuntimeException("ShipSeeker.getNextTry() has no more possible targets!");
        }

        // feedback: notifies the ShipSeeker if the position (xpos,ypos) was a hit.
        public void setResult( int xpos, int ypos, boolean hit ) {
            if (hit) {
                // a hit extends the ship x OR y placement and sets the other directions to 0:
                if (xpos<minX) { minX=xpos;  left_possible--; above_possible = below_possible = 0; }
                else
                if (xpos>maxX) { maxX=xpos; right_possible--; above_possible = below_possible = 0; }
                else
                if (ypos<minY) { minY=ypos; above_possible--;  left_possible = right_possible = 0; }
                else
                if (ypos>maxY) { maxY=ypos; below_possible--;  left_possible = right_possible = 0; }
            }
            else {
                // a miss only clears the direction targeted at:
                if (xpos<minX) {  left_possible = 0; }
                else
                if (xpos>maxX) { right_possible = 0; }
                else
                if (ypos<minY) { above_possible = 0; }
                else
                if (ypos>maxY) { below_possible = 0; }
            }
        }
        
        
        int above_possible, below_possible, right_possible, left_possible;
        int minX, maxX, minY, maxY;
        
        static       int next_dir = random.nextInt(4);
        static final int ABOVE = 0, BELOW = 1, LEFT = 2, RIGHT = 3;
    }
    
}
