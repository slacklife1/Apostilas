/*
 * Game.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 18. November 2004, 13:50
 */

package game;

/**
 *  the Game object triggers the program flow of the battleships game
 *  by calling the Players one after the other to perform their next move.
 *
 *  The Game also updates the supplied DisplayPairs (pairs of Displays,
 *  one Display for each player and opponent, one DisplayPair for each 
 *  screen (for each human player)).
 *
 *  you can overload the message(String) method to receive text messages about
 *  the game progress.
 */
public class Game implements MoveListener {

    // horizontal position of own & opponent's board on the playfield
    public final static int  OwnDisplayPosX      = GameApplication.BoardSizeX+1,
                             OpponentDisplayPosX = 0;

    // creates a new instance of a game - 
    // two players with a single display pair (game displayed on one screen only)
    public Game( Player p1, Player p2, DisplayPair dp ) {
        this( p1, p2, new DisplayPair [] { dp } );
    }
    
    // creates a new instance of a game - 
    // two players with a display(s) for both players:
    public Game( Player p1, Player p2, DisplayPair [] dps ) {
        player1  = p1;
        player2  = p2;
        displays = dps;
        current_player = player1;
    }
 
    // update all displays showing the fleet of Player p:
    void updateAllDisplays( Player p ) {
        for (int i=0; i<displays.length; i++) {
            Display d;
            if ( p == player1 ) d = displays[i].getPlayer1Display();
            else                d = displays[i].getPlayer2Display();
            d.updateDisplay();
        }
    }

    // reveal all ships still unhit/unsunk:
    public void revealSolution() {
        running = false;
        for (int i=0; i<displays.length; i++) {
            displays[i].getPlayer1Display().revealShips();
            displays[i].getPlayer2Display().revealShips();
        }
    }

    // start the game (init displays & request first move):
    public synchronized void start() {
        if (!started) {
            started = true;
            updateAllDisplays( player1 );
            updateAllDisplays( player2 );
            // init the first move:
            nextMove();
        }
    }
    
    // initialize next move of current_player
    public void nextMove() {
        // this method will return immediately; the move is 
        // executed by the player.executeMove() method any time later
        current_player.requestMove( this );
    }

    // a move was executed by the current player
    // this move (= bomb position (x,y)) effects the other player's fleet:
    public void doMove( Move m ) {
        Player  p;
        if (current_player == player1) {
            p = player2;
        }
        else {
            p = player1;
        }
        // bomb other player's fleet & update display:
        Ship hit_ship = p.getFleet().bomb( m.getX(), m.getY() );
        m.setHit( hit_ship );
        if (hit_ship != null) {
            if (hit_ship.isSunk())  message( current_player.getName()+" sinks "+p.getName()+"'s "+hit_ship.getShipClassName()+" '"+hit_ship.getName()+"'!" );
            else                    message( current_player.getName()+" hits "+p.getName()+"'s ship." );
            if (p.getFleet().allSunk()) {
                message( current_player.getName()+" wins!" );
                revealSolution();
            }
        }
        else {
            message( current_player.getName()+" misses!" );
        }
        current_player.reportHit( m );
        updateAllDisplays( p );
        // current player is now the other player, init next move:
        current_player = p;
        if (isRunning()) nextMove();
    }

    public void message(String msg) { /* overload this to receive game messages! */ }
    
    public boolean isRunning() { return running; }
    
    Player         player1, player2,
                   current_player;
    
    DisplayPair [] displays;
    boolean        running = true,
                   started = false;
}
