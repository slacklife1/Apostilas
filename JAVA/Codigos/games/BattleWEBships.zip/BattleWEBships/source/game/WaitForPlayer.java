/*
 * WaitForPlayer.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 22. November 2004, 18:51
 */

package game;

import com.nex.webbase.*;
import java.util.LinkedList;

/**
 *  WaitForPlayer is a wrapper for Player objects. 
 *
 *  to wait until a possible opponent has started a game as well,
 *  call update() until the wait count expires.
 *
 *  Once an opponent is found in the waitlist, the opponent
 *  is connected to this player. getOtherPlayer() returns the opponent.
 *
 *  Battleships2players.java uses this class to create a game of 
 *  two named human players.
 */
public class WaitForPlayer extends NPanel {
    
    public WaitForPlayer( Player player, Playfield pf, int countdown ) {
        this.countdown = countdown;
        this.player    = player;
        this.playfield = pf;
        synchronized (waitlist) {
            waitlist.add( this );
        }
        setFontsize(16);
        add("Welcome "+player.getName()+"!");
        add("Waiting for a human opponent");
        add( countdown_txt );
        countdown_txt.setForegroundColor(ORANGE);
        update();
    }
    
    public Player       getPlayer()     { return player; }
    public Playfield    getPlayfield()  { return playfield; }
    
    public boolean update() {
        countdown--;
        countdown_txt.setText( "<"+countdown+">" );
        if (countdown == 0) {
            synchronized (waitlist) {
                waitlist.remove( this );
                this.opponent = null;
            }
        }
        return countdown>0;
    }
    
    public Game getGame() {
        return game;
    }

    public void setGame( Game g ) {
        game = g;
    }
    
    // check if another player is in the waitlist
    // or an opponent has been assigned to this player
    // returns the opponent, if any.
    public WaitForPlayer getOtherPlayer() {
        synchronized (waitlist) {
            if (opponent != null) 
                return opponent;
            if (waitlist.size()>1) {
                waitlist.remove( this );
                WaitForPlayer other = (WaitForPlayer) waitlist.removeFirst();
                // connect this waiting player and the other waiting player:
                this .opponent = other;
                other.opponent = this;
                return other;
            }
        }
        // no opponent found:
        return null;
    }

    NText           countdown_txt = new NText();
    int             countdown;
    Player          player;
    Game            game      = null;
    WaitForPlayer   opponent  = null;
    Playfield       playfield = null;
    
    static LinkedList waitlist = new LinkedList();
}
