/*
 * GameStarter.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 16. November 2004, 15:32
 */

package game;

/**
 *  End-of-editing event signal
 */
public interface EditingFinished {
    
    /** Creates a new instance of GameStarter */
    public void editingFinished();
    
}
