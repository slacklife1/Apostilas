/*
 * Images.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 19. November 2004, 10:58
 */

package game;

import com.nex.webbase.*;

/**
 *  this static class manages the non-ship graphics of this game:
 *  (see ShipGraphics for more details and ship graphics)
 */
public class Images {
    
    // global URLs of images & button icons (see init method)
    public static String       HitImageUrl       = null,
                               MissImageUrl      = null,
                               Query0ImageUrl    = null,
                               Query1ImageUrl    = null,
                               Query2ImageUrl    = null,
                               PlaceButtonRight0 = null,
                               PlaceButtonRight1 = null,
                               PlaceButtonDown0  = null,
                               PlaceButtonDown1  = null;
    
    public static void initImageUrls( NApplication app ) {
        if (HitImageUrl == null) {
            // init graphic urls (images are accessed from the classpath here, not as files!)
            HitImageUrl       = app.createResourcePath("game/resources/hit.png");
            MissImageUrl      = app.createResourcePath("game/resources/miss.png");
            Query0ImageUrl    = app.createResourcePath("game/resources/query0.png");
            Query1ImageUrl    = app.createResourcePath("game/resources/query1.png");
            Query2ImageUrl    = app.createResourcePath("game/resources/query2.png");
            PlaceButtonRight0 = app.createResourcePath("game/resources/arrow_right0.png");
            PlaceButtonRight1 = app.createResourcePath("game/resources/arrow_right1.png");
            PlaceButtonDown0  = app.createResourcePath("game/resources/arrow_down0.png");
            PlaceButtonDown1  = app.createResourcePath("game/resources/arrow_down1.png");
        }
    }
}
