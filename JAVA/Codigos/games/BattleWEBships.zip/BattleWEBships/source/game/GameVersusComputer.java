/*
 * GameVersusComputer.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 19. November 2004, 11:37
 */

package game;

/**
 *  A GameVersusComputer is the most simple version of a Battleships game.
 */
public class GameVersusComputer extends Game {
    
    // Creates a new instance of GameVersusComputer
    public GameVersusComputer( Playfield playfield, Player human, Player computer ) {
        super( human,
               computer,
               new DisplayPair( 
                   new OwnDisplay     (playfield, OwnDisplayPosX     ,2, human    ), 
                   new OpponentDisplay(playfield, OpponentDisplayPosX,2, computer, human )
               )
             );
    }
    

}
