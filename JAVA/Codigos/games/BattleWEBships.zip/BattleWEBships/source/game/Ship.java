/*
 * Ship.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 11. November 2004, 11:36
 */

package game;

/**
 *  a Ship is a part of a Fleet
 */
public class Ship {
    
    // create a new ship of specified type with the supplied coordinates:
    public Ship( ShipType type, int posx, int posy, boolean vertical ) {
        ship_type   = type;
        is_vertical = vertical;
        bombed      = new boolean[ getLength() ];
        ship_x      = posx;
        ship_y      = posy;
        name        = type.getNextName();
        for (int i=0; i<bombed.length; i++) {
            bombed[i] = false;
        }
    }
    
    // gets the relative position (0..length-1) of this ship for
    // absolute coordinates (posx,posy).
    // returns -1 if this ship is not on this position:
    public int getRelativePosition( int posx, int posy ) {
        int rel_pos = -1;
        if (is_vertical) {
            if ( posx == ship_x ) rel_pos = posy-ship_y;
        } else {
            if ( posy == ship_y ) rel_pos = posx-ship_x;
        }
        if (rel_pos >=0 && rel_pos < getLength() ) {
            return rel_pos;
        }
        // this ship is not on the specified position
        return -1;
    }

    // try to bomb this ship at the specified position
    // returns true, if the ship was hit:
    public boolean bomb( int posx, int posy ) {
        int rel_pos=getRelativePosition(posx,posy);
        if (rel_pos >=0 ) {
            // ok, the ship was hit on it's relative position rel_pos:
            if (!bombed[rel_pos]) {
                bombed[rel_pos] = true;
                hits++;
                return true;
            }
        }
        return false; // no hit
    }

    // was this ship hit on the specified position?
    public boolean wasHit( int posx, int posy ) {
        int rel_pos=getRelativePosition(posx,posy);
        return (rel_pos >= 0) && bombed[ rel_pos ];
    }

    // the image URL used to display the specified position of the ship
    // depends on the "bomb state" of the ship (enemy ships are not displayed until sunk):
    public String getShipGraphic( int pos, boolean enemy_display ) {
        int direction = 0;
        if (isVertical())  direction = ShipGraphics.VERTICAL;
        else               direction = ShipGraphics.HORIZONTAL;
        if (enemy_display) {
            // display of enemy ships (display HitImage if not yet sunk):
            if (isSunk())    return ship_type.getShipGraphic( pos, direction, ShipGraphics.ENEMY );
            else
            if (bombed[pos]) return Images.HitImageUrl;
            else
                return null;
        }
        else {
            // display of own ships:
            if (bombed[pos]) return Images.HitImageUrl;
            else             return ship_type.getShipGraphic( pos, direction, ShipGraphics.OWN );
        }
    }
    
    // true if all parts of the ship have been hit:
    public boolean isSunk() {
        return hits == ship_type.getLength();
    }
    
    // x start position of ship
    public int     getX()             { return ship_x; }

    // y start position of ship
    public int     getY()             { return ship_y; }
    
    // true if the ship is in a column, false if in a row:
    public boolean isVertical()       { return is_vertical; }
    
    // returns the length of the ship (defined by it's type)
    public int     getLength()        { return ship_type.getLength(); }
    
    // returns the ship class name (destroyer, cruiser, battleship, carrier):
    public String  getShipClassName() { return ship_type.getShipClassName(); }
    
    // returns this ship's individual name:
    public String  getName()          { return name; }
    
    
    int        hits = 0, 
               ship_x, ship_y;  // left upper position of ship
    boolean    is_vertical;
    boolean [] bombed;
    String     name;
    ShipType   ship_type;
}
