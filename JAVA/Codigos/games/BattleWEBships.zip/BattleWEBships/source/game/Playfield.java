/*
 * Playfield.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 15. November 2004, 16:49
 */

package game;

import com.nex.webbase.*;
import java.util.Random;

/**
 *  the Playfield is a table of appropriate size to display both the
 *  opponent's (left side) and the player's (right side) board.
 *
 *  the size of one board is defined in the Battleships class (BoardSizeX/Y).
 *
 *  the Playfield can be used for editing a player's ships placement
 *  (ship type selecting Editor is displayed on the left during this, see below).
 */
public class Playfield extends NTable implements EditingFinished {
    
    static int cols            = GameApplication.BoardSizeX*2 + 1,
               rows            = GameApplication.BoardSizeY+2;
    
    int []     rowheights      = new int[ rows ],
               colwidths       = new int[ cols ];
    
    NStyle     framestyle      = new NStyle() {{ setFontsize( 16 ); setBackgroundColor( LIGHT_GREY ); setForegroundColor( GREY2 );}};
    
    NText      headline1       = new NText("Enemy"),
               headline2       = new NText("You");
    
    NText []   myfield_labelX  = new NText[ GameApplication.BoardSizeX ],
               myfield_labelY  = new NText[ GameApplication.BoardSizeY ];
    
    // create a new playfield, with coordinates display and headline.
    public Playfield() {
        super( cols, rows );
        for (int i=0; i<cols; i++) colwidths [i] = 50;
        for (int i=0; i<rows; i++) rowheights[i] = 50;
        rowheights[0]=30;
        rowheights[1]=20;
        colwidths [GameApplication.BoardSizeX]=20;
        setBackgroundColor( LIGHT_BLUE0 );
        setPadding( 0 );
        setRowHeightsPixels( rowheights );
        setColumnWidthsPixels( colwidths );
        setElementsOrientation( CENTER );
        joinCells( 0, 0, GameApplication.BoardSizeX-1, 0 );
        joinCells( GameApplication.BoardSizeX+1, 0, GameApplication.BoardSizeX*2, 0);
        setElement( 0                       , 0, headline1);
        setElement( GameApplication.BoardSizeX+1, 0, headline2);
        setForegroundColor( WHITE );
        headline1.setFontsize( 16 );
        headline2.setFontsize( 16 );
        setFontsize( 24 );
        setFontstyle( BOLD );
        setTableFrameColor( LIGHT_GREY );
        getRow(1).setStyle( framestyle );
        getColumn(GameApplication.BoardSizeX).setStyle( framestyle );
        for (int i=0; i<GameApplication.BoardSizeX; i++) {
            myfield_labelX[i] = new NText( ""+(i+1) );
            setElement(                          i, 1, ""+(i+1));
            setElement( GameApplication.BoardSizeX+1+i, 1, myfield_labelX[i]);
        }
        for (int i=0; i<GameApplication.BoardSizeY; i++) {
            myfield_labelY[i] = new NText( ""+(char) ('A'+i) );
            setElement( GameApplication.BoardSizeX, 2+i, myfield_labelY[i]);
        }
        headline1.setBackgroundColor(GREY3);
        headline2.setBackgroundColor(GREY3);
        headline1.setForegroundColor(WHITE);
        headline2.setForegroundColor(WHITE);
    }

    // highlight the position on the player's (right side) board
    // (marks the position of the opponent's last move)
    public void markPosition( int xpos, int ypos ) {
        myfield_labelX[ mark_x ].setBackgroundColor( NONE );
        myfield_labelY[ mark_y ].setBackgroundColor( NONE );
        if (xpos>=0) {
            mark_x = xpos;
            mark_y = ypos;
            myfield_labelX[ mark_x ].setBackgroundColor( GREY4 );
            myfield_labelY[ mark_y ].setBackgroundColor( GREY4 );
        }
    }

    // display a crossword-style message text on the left playfield board:
    public void crossWordMessage( String text ) {
        int pos = 0;
        for (int y=0; y<GameApplication.BoardSizeY; y++)
        for (int x=0; x<GameApplication.BoardSizeX; x++) {
            NText letter = null;
            if (pos<text.length()) {
                letter = new NText( ""+text.charAt(pos++) );
            }
            setElement( x, y+2, letter );
        }
    }
    
    // go to editing mode
    // on the left half of the playfield, a message and the ship type selector menu is displayed.
    // on the right, the selected ship type can be placed on the board:
    public void editShipsPlacement( ShipType [] types, int [] counts, Player fleet_owner, EditingFinished edit_end ) {
        this.edit_end = edit_end;
        ships_editor  = new Editor( types, counts, this, fleet_owner, this );
        crossWordMessage("Position "+
                         "all ships"+
                         "on right "+
                         "side down"+
                         "or across");
        joinCells(1,2+GameApplication.BoardSizeY-4,GameApplication.BoardSizeX-2,2+GameApplication.BoardSizeY-2);
        setElement(1,2+GameApplication.BoardSizeY-4,ships_editor);
        markPosition(-1,-1);
    }
    
    // called from the ship type selector (ships_editor object) when editing is finished
    // clears the message text on the left and notified the edit_end message receiver.
    public void editingFinished() {
        crossWordMessage("");
        unjoinCells(1,2+GameApplication.BoardSizeY-4,GameApplication.BoardSizeX-2,2+GameApplication.BoardSizeY-2);
        edit_end.editingFinished();
    }
    
    // sets the player names to be displayed in the top row:
    public void setPlayerNames( String player, String opponent ) {
        headline1.setText( opponent+"'s ships" );
        headline2.setText( player  +"'s ships" );
    }
    
    Editor          ships_editor = null;
    EditingFinished edit_end     = null;
    int             mark_x       = 0,
                    mark_y       = 0;
}
