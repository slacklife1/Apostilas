/*
 * EditorDisplay.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 12. November 2004, 15:31
 */

package game;

import com.nex.webbase.*;
import java.util.LinkedList;

/**
 *  a Display variant for editing a Player's ships positions.
 *
 *  depending on the currently set type of the ShipPlacer, all positions available for
 *  placing a new ship (vertically or horizontally) are filled with ShipPlacerButtons.
 */
public class EditorDisplay extends Display {
    
    // creates a new EditorDisplay for the fleet of the specified Player.
    // Placement of new ships is done via the ShipPlacer object:
    public EditorDisplay(Playfield playfield, int offsetX, int offsetY, Player fleet_owner, ShipPlacer placer) {
        super( playfield, offsetX, offsetY, fleet_owner );
        ship_placer = placer;
    }
    
    public NComponent updateDisplay(int xpos, int ypos) {
        Fleet fleet  = getFleet();
        Ship  ship   = fleet.getShip ( xpos, ypos );
        if (ship != null) {
            int rel_pos=ship.getRelativePosition( xpos,ypos );
            return new NImage( ship.getShipGraphic(rel_pos, false) );
        }
        else {
            ShipType type = ship_placer.getCurrentType();
            if (type == null) return null;
            boolean vert = fleet.isPositionFree(xpos,ypos,true ,type),
                    hori = fleet.isPositionFree(xpos,ypos,false,type);
            if (vert || hori) {
                NPanel panel = new NPanel();
                if (hori) {
                    panel.add( new ShipPlacerButton( xpos, ypos, false, ship_placer ) );
                    panel.setOrientation(panel.LEFT);
                }
                if (vert) {
                    panel.add( new ShipPlacerButton( xpos, ypos, true , ship_placer ) );
                }
                return panel;
            }
        }
        return null; // nothing to display
    }

    
    ShipPlacer ship_placer;
}
