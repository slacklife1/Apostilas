/*
 * Display.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 12. November 2004, 15:06
 */

package game;

import com.nex.webbase.*;

/**
 *  a Display is the visual representation of a Player's fleet.
 *
 *  This may be the player's own fleet (OwnDisplay, fully visible) as well
 *  as the opponent's fleet (OpponentDisplay, visible only after ships have been hit),
 *  or the EditorDisplay for editing your ships' positions.
 *
 *  A Display is a sub-area of a Playfield table of BoardSizeX/Y, starting at the
 *  specified offset position.
 */
public abstract class Display {
    
    // each Display-derived class has to implement the updateDisplay for a specified
    // board position (0..BoardSizeX-1, 0..BoardSizeY-1).
    // This method must return the webbase component needed to display this position
    // either an image, a button, a text, or null if nothing is to be displayed here.
    public abstract NComponent updateDisplay(int xpos, int ypos);

    // Creates a new instance of Display (offsetX/Y is the position of the specified Playfield).
    protected Display(Playfield playfield, int offsetX, int offsetY, Player fleet_owner) {
        this.playfield = playfield;
        this.offsetX   = offsetX;
        this.offsetY   = offsetY;
        this.player    = fleet_owner;
    }

    // update all positions
    public void updateDisplay() {
        for (int y=0; y<GameApplication.BoardSizeY; y++)
        for (int x=0; x<GameApplication.BoardSizeY; x++) {
            playfield.setElement( offsetX+x, offsetY+y, updateDisplay(x,y) );
        }
    }
    
    // reveal all not yet discovered ships.
    public void revealShips() { /* this is used in the OpponentDisplay class */ }
    
    // get the displayed Fleet
    public Fleet     getFleet()     { return player.getFleet(); }
    
    // get the Fleet's owner
    public Player    getPlayer()    { return player; }
    
    // get the surrounding Playfield:
    public Playfield getPlayfield() { return playfield; }
    
    private  Playfield  playfield;
    private  int        offsetX, offsetY;
    private  Player     player;
}
