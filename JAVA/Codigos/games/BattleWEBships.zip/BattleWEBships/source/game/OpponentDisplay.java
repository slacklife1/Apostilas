/*
 * OpponentDisplay.java
 *
 * this version of Battleships is a web application using the webbase gui library
 * 2004, nextwebstep.com
 * this source code is freeware, please feel free to enhance it!
 *
 * Created on 12. November 2004, 15:31
 */

package game;

import com.nex.webbase.*;
import java.util.LinkedList;

/**
 *  Display variant showing opponent's fleet (ships visible when hit/sunk only)
 *
 *  During the game, a '?'-image button is displayed for all positions yet to be bombed.
 *  the display is the ClickListener event handler for all those buttons.
 *  A click triggers the attacker's (i.e., the current player's) executeMove, bombing the
 *  displayed opponent's fleet.
 *
 *  Once the reavalShips() method was called, all enemy ships are displayed
 *  (when cancelling game or opponent wins)
 */
public class OpponentDisplay extends Display implements NClickListener {
    
    public OpponentDisplay( Playfield playfield, int offsetX, int offsetY, Player opponent, Player attacker ) {
        super( playfield, offsetX, offsetY, opponent );
        this.attacker = attacker;
    }
    
    public NComponent updateDisplay(int xpos, int ypos) {
        Fleet  fleet  = getFleet();
        Ship   ship   = fleet.getShip ( xpos, ypos );
        if (ship != null) {
            int     rel_pos            = ship.getRelativePosition( xpos,ypos );
            boolean enemy_display_mode = !reveal || ship.wasHit(xpos,ypos);
            String  image_url          = ship.getShipGraphic(rel_pos, enemy_display_mode);
            if (image_url != null)
                return new NImage( image_url );
        }
        if (fleet.isBombed(xpos,ypos))
            return new NImage( Images.MissImageUrl );
        // else: no ship or ship not yet displayed:
        if (reveal) return null;
        // this button enables the opponent to bomb my fleet:
        NImageButton select = new NImageButton( Images.Query0ImageUrl, Images.Query1ImageUrl, Images.Query2ImageUrl );
        select.addListener( this );
        select.setData( new TargetPosition( xpos, ypos ) );
        return select;
    }

    // reveal positions of all ships (if not yet hit/sunk)
    public void revealShips() {
        reveal = true;
        updateDisplay();
    }
    
    public void onClick( NClickEvent e ) {
        // the opponent as clicked a target position on my fleet:
        TargetPosition pos = (TargetPosition) e.getData();
        // this target position is new 'move' of the attacker:
        attacker.executeMove( new Move(pos.getX(),pos.getY()) );
    }

    boolean reveal = false;
    Player  attacker;
}
