This is the main readme text.
Different folders have their own readme text files.
