All images and texts in this folder are only for realizing the program
The program does not need these files to run.