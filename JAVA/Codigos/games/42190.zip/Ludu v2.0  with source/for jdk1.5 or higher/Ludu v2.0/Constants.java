//11:29 AM 10/9/2004 u 12:01 PM 10/16/2004 u 9:25 PM 11/8/2004
public class Constants implements java.io.Serializable
{
   public static final int RED = 0, BLUE = 1, GREEN = 2, YELLOW = 3, SINGLE = 0, DOUBLE = 1, CLICK_SOUND = 0, ERROR_SOUND = 1, SHAKE_SOUND = 2, LAUNCH_SOUND = 3, SELECT_SOUND = 4, MOVE_SOUND = 5, GAME_OVER_SOUND = 6, HELP_SOUND = 7, KILL_SOUND = 8, GENERATE_DIE = 0, GUTI_SELECT_MOVE = 1, PART_1 = 0, PART_2 = 1, PART_3 = 2;
}