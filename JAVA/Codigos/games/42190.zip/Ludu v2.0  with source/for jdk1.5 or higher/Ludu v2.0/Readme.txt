If you have already installed java at 'C:\Java\jdk1.5.0_02' directory you can:
Compile all files by just double clicking 'Compile.bat' file and then
Run program by double clicking 'Run.bat' file.( in windows systems ).
For playing the game your monitor must support 800 X 600 resolution and
set monitor resolution to 800 X 600 pixels before running the program.