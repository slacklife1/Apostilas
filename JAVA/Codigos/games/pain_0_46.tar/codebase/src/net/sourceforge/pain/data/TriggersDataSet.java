package net.sourceforge.pain.data;

import net.sourceforge.pain.db.*;

import java.util.*;

/**
 * Set of triggers
 * used to store object triggers per role or per type by Root.
 */

public final class TriggersDataSet extends DbObject {
    private static final int TRIGGERS_SET = 0;
    private static final int NFIELDS = 1;

    public TriggersDataSet() {
    }

    TriggersDataSet(final PainDB db) throws RuntimeException {
        super(db);
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        types[TRIGGERS_SET] = DbType.REFERENCE_SET;
        names[TRIGGERS_SET] = "triggers";

        return new DbClassSchema(types, names);
    }

    /**
     * will delete all triggers data
     */
    void removeAll() {
        Set set = getRefSet(TRIGGERS_SET);
        int size = set.size();
        if (size == 0) {
            return;
        }
        TriggerData[] td = new TriggerData[size];
        set.toArray(td);
        set.clear();
        for (int i = 0; i < td.length; i++) {
            td[i].delete();
        }
    }

    public void delete() {
        removeAll();
        super.delete();
    }

    void addTrigger(TriggerData t) {
        getRefSet(TRIGGERS_SET).add(t);
    }

    void removeTrigger(TriggerData t) {
        if (getRefSet(TRIGGERS_SET).remove(t)) {
            t.delete();
        }
    }

    boolean isEmpty() {
        return getRefSet(TRIGGERS_SET).isEmpty();
    }

    Iterator iterator() {
        return new TriggerDataSetIterator(getRefSet(TRIGGERS_SET).iterator());
    }

     static final class TriggerDataSetIterator implements Iterator {
        private final Iterator it;
        private TriggerData lastReturned;

        public TriggerDataSetIterator(Iterator it) {
            this.it = it;
        }

        public void remove() {
            it.remove();
            lastReturned.delete();
        }

        public boolean hasNext() {
            return it.hasNext();
        }

        public Object next() {
            lastReturned = (TriggerData) it.next();
            return lastReturned;
        }
    }



/*    List detachRoleTriggers(Role role) {
        ArrayList detachedTD = new ArrayList();
        for (Iterator it = getRefSet(TRIGGERS_SET).iterator(); it.hasNext();) {
            TriggerData td = (TriggerData) it.next();
            if (td.getTriggeredRole() == role) {
                detachedTD.add(td);
                iterator().remove();
            }
        }
        return detachedTD;
    }

    void addTriggers(List triggers) {
        DbReferenceSet set = getRefSet(TRIGGERS_SET);
        for (int i = 0; i < triggers.size(); i++) {
            TriggerData t = (TriggerData) triggers.get(i);
            set.add(t);
        }
    }
    */
}
