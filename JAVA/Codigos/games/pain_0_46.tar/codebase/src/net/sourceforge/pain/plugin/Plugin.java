package net.sourceforge.pain.plugin;

import java.util.*;

/**
 * Base class for all plugin impls
 * Plugin is a set of classes that provides custom functionality to
 * server and should not be reloaded every time logic classes are reloaded
 * Sample of plugins: text commands or socials to events mapping (this mapping should not
 * be reloaded every time logic is reloaded), plugins that has SQL connections to
 * some stat database, shutdown timer plugin (emits shutdown evet by timer and
 * should not be reloaded on logic reloading)
 * Plugins should not have direct references to logic classes (plugins
 * should use events).
 * Logic is allowed to have direct references to plugins.  
 *
 */
public abstract class Plugin {

    /** plugin name is a package suffix after net.sf.pain.plugin. prefix
     * (see CodebaseLaunchar settings)
     */
    protected String pluginName;

    /**
     * child plugin names, should not be modified from other package!
     */
    protected final Set childs = new HashSet();

    public Plugin() {
        if (getClass().getClassLoader().getClass() != PluginClassLoader.class) {
            throw new RuntimeException("Plugin class:" + getClass().getName() + " must be loaded by PluginManager!");
        }
    }

    protected abstract void init() throws Exception;

    protected abstract void deinit();

    /**
     * This method is used from static PAIN code. Static code should not to have any direct links to reloadable plugins
     *
     * @param key
     * @param args
     */
    public Object invoke(int key, Object[] args) {
        throw new UnsupportedOperationException();
    }

    /**
     * plugin
     * child plugin should be reloaded when parent is reloading
     *
     * @param pluginName
     */
    synchronized final void addChild(String pluginName) {
        if (childs.contains(pluginName)) {
            return;
        }
        childs.add(pluginName);
    };


    final void removeChild(String pluginName) {
        childs.remove(pluginName);
    };

    public String toString() {
        return getClass().getName();
    }

    public final Set getDependedPlugins() {
        return Collections.unmodifiableSet(childs);
    }

    public final String getPluginName() {
        return pluginName;
    }
}
