package net.sourceforge.pain.network.console;

/**
 * User: fmike  Date: May 27, 2004  Time: 2:26:46 AM
 */
public final class DefaultConsoleFactory implements ConsoleFactory {
    public BasicConsole provideConsole(ConsoleAdapter ad) {
        return new BasicConsole(ad);
    }
}
