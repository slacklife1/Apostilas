package net.sourceforge.pain.network.guitool;

import java.io.*;

/**
 * Binary network packet image
 * NOTE(and todo): this class should be synchronized with 'guitool' analog
 */
public final class GTNetPacket implements Serializable {
    public static final int SEQUENCE_ID_ASYNC = 0;

    public String eventClassName;
    public int sequence_id;
    public Object data;

    public GTNetPacket(String name, Object data) {
        this(name, data, SEQUENCE_ID_ASYNC);
    }

    public GTNetPacket(String name, Object data, int sequence_id) {
        this.eventClassName = name;
        this.data = data;
        this.sequence_id = sequence_id;
    }
}
