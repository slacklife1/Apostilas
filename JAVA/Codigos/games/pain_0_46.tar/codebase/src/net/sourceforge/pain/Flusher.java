package net.sourceforge.pain;

import net.sourceforge.pain.util.*;

import java.io.*;

public class Flusher implements PulseListener {

    /**
     * period in Codebase PULSEs for flushes, could be changed from outside.
     * default value is 30 seconds
     */
    public int flushingPeriodInTicks = 30 * net.sourceforge.pain.Pulse.PULSE_PER_SCD;

    /**
     * time in Codebase PULSEs when for next flush, could be changed from outside
     */
    public int nextFlushTime = flushingPeriodInTicks;

    Flusher() {
    }

    public void pulse(int time) {
//		Log.debug(time+"/"+nextFlushTime);
        if (nextFlushTime <= time) {
            Log.debug("flushing data to disk!");
            try {
                Codebase.getDB().flush();
            } catch (IOException e) {
                Log.error(e);
            }
            Log.debug("saved");
            nextFlushTime = time + flushingPeriodInTicks;
        }
    }
}
