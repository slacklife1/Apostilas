package net.sourceforge.pain.network.console.telnet;


/**
 * Provides mapping from string based color codes({r, {W ..) to constants.
 */
public class AnsiColor {

    /** java.awt.Color is too expensive to be used here*/

    /**
     * Color numbers
     * it's mapping for the different terminal types
     */
    public static final int COLOR_CLEAR = -1;
    public static final int COLOR_BLACK = 0;
    public static final int COLOR_RED = 1;
    public static final int COLOR_GREEN = 2;
    public static final int COLOR_YELLOW = 3;
    public static final int COLOR_BLUE = 4;
    public static final int COLOR_MAGENTA = 5;
    public static final int COLOR_CYAN = 6;
    public static final int COLOR_WHITE = 7;

    /**
     * brighter colors
     */
    public static final int COLOR_DARK_GREY = 8;
    public static final int COLOR_BRIGHT_RED = 9;
    public static final int COLOR_BRIGHT_GREEN = 10;
    public static final int COLOR_BRIGHT_YELLOW = 11;
    public static final int COLOR_BRIGHT_BLUE = 12;
    public static final int COLOR_BRIGHT_MAGENTA = 13;
    public static final int COLOR_BRIGHT_CYAN = 14;
    public static final int COLOR_BRIGHT_WHITE = 15;

    // special
    public static final int COLOR_BEEP = 16;

    public static int toColor(char c) {
        int color = COLOR_CLEAR;
        switch (c) {
            /* normal colors */
            case 'd':
            case '0':
                color = COLOR_BLACK;
                break;

            case 'r':
            case '1':
                color = COLOR_RED;
                break;

            case 'g':
            case '2':
                color = COLOR_GREEN;
                break;

            case 'y':
            case '3':
                color = COLOR_YELLOW;
                break;

            case 'b':
            case '4':
                color = COLOR_BLUE;
                break;

            case 'm':
            case '5':
                color = COLOR_MAGENTA;
                break;

            case 'c':
            case '6':
                color = COLOR_CYAN;
                break;

            case 'w':
            case '7':
                color = COLOR_WHITE;
                break;

                /* light colors */
            case 'D':
            case '8':
            case ')':
                color = COLOR_DARK_GREY;
                break;

            case 'R':
            case '!':
                color = COLOR_BRIGHT_RED;
                break;

            case 'G':
            case '@':
                color = COLOR_BRIGHT_GREEN;
                break;

            case 'Y':
            case '#':
                color = COLOR_BRIGHT_YELLOW;
                break;

            case 'B':
//			case '$':
                color = COLOR_BRIGHT_BLUE;
                break;

            case 'M':
            case '%':
                color = COLOR_BRIGHT_MAGENTA;
                break;

            case 'C':
            case '^':
                color = COLOR_BRIGHT_CYAN;
                break;

            case 'W':
            case '&':
                color = COLOR_BRIGHT_WHITE;
                break;

                /* special colors */
            case 'x':
                color = COLOR_CLEAR;
                break;

            case '*':
                color = COLOR_BEEP;
                break;
        }
        return color;
    }

}
