package net.sourceforge.pain.network.guitool;

import net.sourceforge.pain.util.*;

import java.net.*;
import java.util.*;

public final class GuiToolServer implements Runnable {

    private ServerSocket serverSocket;
    private int port;
    private Set connections = Collections.synchronizedSet(new HashSet());
    private boolean started;
    GuiToolSessionManager sm = null;

    public GuiToolServer(GuiToolSessionManager sm, int port) {
        Log.info("GuiToolServer  created");
        this.sm = sm;
        this.port = port;
        Thread worker = new Thread(this);
        worker.setDaemon(true);
        worker.start();
    }

    public void run() {
        started = true;
        work();
    }

    public void work() {
        try {
            Log.info("GTS:creating server socket on port:" + port);
            serverSocket = new ServerSocket(port, 50, InetAddress.getByName("127.0.0.1"));
            serverSocket.setSoTimeout(0);
            Log.info("GTS:Server Initialised. listening...");
            do {
                try {
                    Socket socket = serverSocket.accept();
                    Log.debug("GTS:connection accepted[" + connections.size() + "]:" + socket.getInetAddress());
                    GuiToolConnection con = new GuiToolConnection(this, socket);
                    sm.onConnect(con);
                    connections.add(con);
                    Thread worker = new Thread(con);
                    worker.start();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } while (started);
        } catch (Exception e) {
            Log.error(e);
        }
    }

    protected void onClose(GuiToolConnection con) {
        Log.debug("GTS:closing connection:[" + connections.size() + "]" + con.socket.getInetAddress());
        connections.remove(con);
        sm.onDisconnect(con);
    }

    public void stop() {
        started = false;
    }


}
