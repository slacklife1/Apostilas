package net.sourceforge.pain;


public interface PulseListener {

    public void pulse(int time) throws Exception;

}
