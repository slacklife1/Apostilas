package net.sourceforge.pain.admin.console.command;

import net.sourceforge.pain.*;
import net.sourceforge.pain.admin.console.*;
import net.sourceforge.pain.plugin.*;

import java.util.*;


/**
 * User: fmike  Date: Jun 2, 2004  Time: 2:15:15 AM
 */
public class PlugListAdminCommand extends AdminCommandHandler {
    public PlugListAdminCommand() {
    }

    public void processCommand(String params) throws Exception {
        List list = Codebase.getPluginManager().getActivePluginsList();
        console.out("{cActive plugins list:{x\n");
        for (Iterator it = list.iterator(); it.hasNext();) {
            Plugin p = (Plugin) it.next();
            console.out("    " + p.getPluginName() + "\n");
        }

    }


    public void showHelp() {
        console.out("Usage: " + commandName + " - lists loaded plugins\n");
    }
}
