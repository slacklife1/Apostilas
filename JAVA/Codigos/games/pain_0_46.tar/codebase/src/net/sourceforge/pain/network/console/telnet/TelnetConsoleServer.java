package net.sourceforge.pain.network.console.telnet;


import net.sourceforge.pain.network.console.*;
import net.sourceforge.pain.util.*;

import java.net.*;
import java.util.*;


/** simple console server realization*/
public class TelnetConsoleServer implements Runnable {

    private ServerSocket serverSocket;
    private int port;
    private Set connections = Collections.synchronizedSet(new HashSet());
    private boolean started;
    private AbstractConsoleManager cm;

    public TelnetConsoleServer(int port, AbstractConsoleManager cm) {
        this.cm = cm;
        Log.info("TelnetConsoleServer created");
        this.port = port;
        Thread worker = new Thread(this);
        worker.setDaemon(true);
        worker.start();
    }

    public void run() {
        started = true;
        work();
    }

    void work() {
        ConnectionChecker checker = new ConnectionChecker();
        Thread checkThread = new Thread(checker);
        checkThread.setDaemon(true);
        checkThread.start();
        try {
            Log.info("TelnetConsoleServer:creating server socket on port:" + port);
            serverSocket = new ServerSocket(port, 50);
            serverSocket.setSoTimeout(0);
            Log.info("Server Initialised. listening...");
            do {
                try {
                    Socket socket = serverSocket.accept();

                    Log.debug("TelnetConsoleServer:connection accepted[" + connections.size() + "]:" + socket.getInetAddress());
                    TelnetConsoleAdapter con = new TelnetConsoleAdapter(this, socket, cm);
                    connections.add(con);
                    Thread worker = new Thread(con);
                    worker.start();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } while (started);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            checker.interrupted = true;
            checkThread.interrupt();
        }
    }

    protected void onClose(TelnetConsoleAdapter con) {
        Log.debug("TelnetConsoleServer:closing connection:[" + connections.size() + "]" + con.socket.getInetAddress());
        connections.remove(con);
    }

    public void stop() {
        started = false;
    }

    private class ConnectionChecker implements Runnable {

        public static final int CHECK_TIMEOUT = 5000;
        boolean interrupted = false;

        public void run() {
            while (!interrupted) {
                try {
                    Collection c = new ArrayList(connections);
                    long checkBarrier = System.currentTimeMillis() - CHECK_TIMEOUT;
                    for (Iterator it = c.iterator(); it.hasNext();) {
                        TelnetConsoleAdapter con = (TelnetConsoleAdapter) it.next();
                        if (con.lastFlushTime < checkBarrier) {
                            Log.debug("TelnetConsoleServer:AYT to " + con.socket.getRemoteSocketAddress());
                            con.ping();
                        }
                    }
                    Thread.sleep(CHECK_TIMEOUT);
                } catch (InterruptedException e) {
                    interrupted = true;
                } catch (Exception e) {
                    Log.error(e.getMessage(), e);
                }
            }
        }
    }
}
