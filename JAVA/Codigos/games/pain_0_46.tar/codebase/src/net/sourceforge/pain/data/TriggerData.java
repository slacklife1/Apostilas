package net.sourceforge.pain.data;

import net.sourceforge.pain.*;
import net.sourceforge.pain.db.*;
import net.sourceforge.pain.logic.*;

/**
 * All classes that exteds TriggerData are DbObjects
 * and should add only new fields to save
 * All subclasses should be defined in data.trigger package
 * and should not contain any logical code.
 * TRIGGER_LOGIC_CLASS_NAME should provide us with a valid
 * logic handler for this trigger.
 */
public class TriggerData extends DbObject {

    /**
     * trigger type
     */
    private static int TRIGGER_EVENT_TYPE = 0;

    /**
     * role the trigger is applied
     */
    private static int TRIGGERED_ROLE = 1;

    /**
     * class name with trigger logic code
     */
    private static int TRIGGER_CLASS_NAME = 2;

    /**
     * for trigger data subclasses use
     */
    protected static int LAST_BASE_FIELD_INDEX = 2;

    private static int NFIELDS = 3;


    public TriggerData() {
    }

    public TriggerData(final PainDB db, Role triggeredRole, Class triggerImplClass, int triggerEventType) throws Exception {
        super(db);
        if (triggeredRole == null) {
            throw new NullPointerException("triggered role is null!");
        }
        if (!Trigger.class.isAssignableFrom(triggerImplClass)) {
            throw new IllegalArgumentException("Illegal trigger impl class!");
        }
        setTriggerEventType(triggerEventType);
        setTriggerClassName(triggerImplClass.getName().substring(Codebase.TRIGGERS_LOGIC_PACKAGE_PREFIX.length()));
        setTriggeredRole(triggeredRole);
        triggeredRole.getRoot().onTriggerCreated(triggeredRole, this);
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];
        fillSuperSchema(types, names);
        return new DbClassSchema(types, names);
    }

    public static void fillSuperSchema(byte[] types, String[] names) {
        types[TRIGGER_EVENT_TYPE] = DbType.INT;
        names[TRIGGER_EVENT_TYPE] = "type";

        types[TRIGGERED_ROLE] = DbType.REFERENCE;
        names[TRIGGERED_ROLE] = "triggered_role";

        types[TRIGGER_CLASS_NAME] = DbType.STRING;
        names[TRIGGER_CLASS_NAME] = "trigger_class_name";
    }


    public final String getTriggerClassName() {
        return getString(TRIGGER_CLASS_NAME);
    }

    final void setTriggerClassName(String triggerClassName) {
        setString(TRIGGER_CLASS_NAME, triggerClassName);
    }

    public final int getTriggerEventType() {
        return getInt(TRIGGER_EVENT_TYPE);
    }

    final void setTriggerEventType(int type) {
        setInt(TRIGGER_EVENT_TYPE, type);
    }

    public final Role getTriggeredRole() {
        return (Role) getReference(TRIGGERED_ROLE);
    }

    final void setTriggeredRole(Role role) {
        setReference(TRIGGERED_ROLE, role);
    }

}
