package net.sourceforge.pain.network.console;


import net.sourceforge.pain.*;
import net.sourceforge.pain.logic.*;

/**
 * User console management systems.
 * Maps all events from remote console to custom for mudlib logic.
 */

public final class UserConsoleManager extends AbstractConsoleManager  {
    public UserConsoleManager(int port, ConsoleFactory cf) {
        super("UserCM", port, cf);
    }

    public void emitEvent(Class eventClass, BasicConsole c) throws Exception {
        Codebase.processEvent(eventClass, c);
    }

    protected  void initEventClasses() throws Exception {
        LogicLoader llm = Codebase.getLogicLoader();
        EVENT_CONSOLE_INPUT_CLASS = llm.provideEventClass("console.ConsoleInputEvent");
        EVENT_CONSOLE_EXPIRED_CLASS = llm.provideEventClass("console.ConsoleExpiredEvent");
        EVENT_NEW_CONNECTION_CLASS = llm.provideEventClass("console.LoginEvent");
        EVENT_CONSOLE_DISCONNECT_CLASS = llm.provideEventClass("console.ConnectionLostEvent");
        EVENT_PROMPT_CLASS = llm.provideEventClass("console.ShowPrompt");
    }

}
