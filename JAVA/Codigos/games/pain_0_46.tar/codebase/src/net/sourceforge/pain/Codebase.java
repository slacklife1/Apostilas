package net.sourceforge.pain;


import net.sourceforge.pain.data.*;
import net.sourceforge.pain.db.*;
import net.sourceforge.pain.logic.*;
import net.sourceforge.pain.network.console.*;
import net.sourceforge.pain.network.guitool.*;
import net.sourceforge.pain.plugin.*;
import net.sourceforge.pain.util.*;

import java.util.*;

/**
 * PAiN mud codebase static context
 * contains references to core codebase singleton classes
 * like user console service manager, admin console service manager,
 * logic/plugins loaders, database instance.
 */
public final class Codebase {

    public static final Date serverStartTime = new Date();
    public static final String CODEBASE_VERSION = "0.46";

    private static CodebaseData codebaseData = null;

    private static net.sourceforge.pain.Pulse pulse = new net.sourceforge.pain.Pulse();

    private static AdminConsoleManager adminCM;
    private static UserConsoleManager userCM;
    private static GuiToolSessionManager guiSM;
    private static PluginManager plm;
    private static PainDB db;

    private static LogicLoader logicLoader;
    public static String OBJECT_FACTORY_PACKAGE_PREFIX;
    public static String TRIGGERS_LOGIC_PACKAGE_PREFIX;
    public static String AFFECTS_LOGIC_PACKAGE_PREFIX;


    private Codebase() {
    }

    /**
     * @return database instance
     */
    public static PainDB getDB() {
        return db;
    }

    static void setDB(PainDB _db) {
        assert  db == null;
        Codebase.db = _db;
        codebaseData = (CodebaseData) db.getRoot();
    }

    public static CodebaseData getCodebaseData() {
        return codebaseData;
    }

    static void setUserConsoleManager(UserConsoleManager consoleManager) {
        assert userCM == null;
        userCM = consoleManager;
    }

    static void setAdminConsoleManager(AdminConsoleManager consoleManager) {
        assert adminCM == null;
        adminCM = consoleManager;
    }


    public static UserConsoleManager getUserConsoleManager() {
        return userCM;
    }

    public static AdminConsoleManager getAdminConsoleManager() {
        return adminCM;
    }

    public static Pulse getPulse() {
        return pulse;
    }

    /**
     * @param eventClassSuffix event class name suffix within event logic package
     * @param params           - passed to event
     * @throws Exception if eny error occurs during event instance instantiation
     */
    public static Object processEvent(String eventClassSuffix, Object params) throws Exception {
        return processEvent(logicLoader.provideEventClass(eventClassSuffix), params);
    }

    /**
     * @param eventImplClass - event impl class. (Note all references to logic
     *                       classes should be released by static code during logic reloading to allow
     *                       Java GC do it's work
     * @param params         - passed to event
     * @throws Exception if eny error occurs during event instance instantiation
     */
    public static Object processEvent(Class eventImplClass, Object params) throws Exception {
        Event e = (Event) eventImplClass.newInstance();
        try {
            return e.processEvent(params);
        } catch (AssertionError err) {
            Log.error("ASSERTION!", err);
            throw new RuntimeException(err);
        }
    }

    /**
     * @return loader responsible for logic classes loading
     */
    public static LogicLoader getLogicLoader() {
        return logicLoader;
    }

    /**
     * @return loader responsible for plugins loading
     */
    public static PluginManager getPluginManager() {
        return plm;
    }

    static void setPluginManager(PluginManager _plm) {
        assert plm == null;
        plm = _plm;
    }


    /**
     * forces codebase to shutdown on next pulse beat
     */
    public static void shutdown() {
        pulse.stopPulse(true);
    }

    /**
     * flushes database caches to file and calls System.exit(0)
     * Shutdown is allowed only if no active transaction exists
     */
    static void _shutdown() {
        Log.debug("Flushing all data before exit!");
        try {
            db.flush();
        } catch (Exception e) {
            Log.error(e.getMessage(), e);
        }
        db.close();
        Log.debug("Shutted down.");
        System.exit(0);
    }


    static void setGuiToolSessionManager(GuiToolSessionManager guiToolSessionManager) {
        assert guiSM == null;
        guiSM = guiToolSessionManager;
        pulse.addListener(guiSM);
    }

    /**
     * @return GUITool (binary, object-serialization stream) service manager
     */
    public GuiToolSessionManager getGuiToolSessionManager() {
        return guiSM;
    }

    static void setLogicLoader(LogicLoader llm) {
        assert logicLoader == null;
        logicLoader = llm;
    }
}

