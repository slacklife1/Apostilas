package net.sourceforge.pain.data.role;

import net.sourceforge.pain.data.*;
import net.sourceforge.pain.db.*;


/**
 * Basic prototype info
 * vnum is a unique key prototype identified by.
 */
public final class PrototypeInfo extends Prototype {

    private static final int VNUM = 1 + LAST_BASE_FIELD_INDEX;
    private static final int NAME = 2 + LAST_BASE_FIELD_INDEX;
    private static final int DESC = 3 + LAST_BASE_FIELD_INDEX;
    private static final int AUTHOR = 4 + LAST_BASE_FIELD_INDEX;
    private static final int NFIELDS = 5 + LAST_BASE_FIELD_INDEX;

    public PrototypeInfo(PainDB db) {
        super(db);
    }


    public PrototypeInfo() {
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        fillSuperSchema(types, names);

        types[VNUM] = DbType.STRING;
        names[VNUM] = "vnum";

        types[NAME] = DbType.STRING;
        names[NAME] = "name";

        types[DESC] = DbType.STRING;
        names[DESC] = "desc";

        types[AUTHOR] = DbType.STRING;
        names[AUTHOR] = "author";

        return new DbClassSchema(types, names);
    }

    public void setVnum(String value) {
        setString(VNUM, value);
    }

    public void setAuthor(String value) {
        setString(AUTHOR, value);
    }

    public String getVnum() {
        return getString(VNUM);
    }

    public String getAuthor() {
        return getString(AUTHOR);
    }

    public void setName(String name) {
        setString(NAME, name);
    }

    public void setDesc(String desc) {
        setString(DESC, desc);
    }

    public String getName() {
        return getString(NAME);
    }

    public String getDesc() {
        return getString(DESC);
    }

    public String toString() {
        return "vnum=" + getVnum() + " name=" + getName();
    }

    protected Role fillObject(Role target) {
        return target; // nothing to add
    }

    public Class getPrototypedRoleClass() {
        return null;
    }
}

