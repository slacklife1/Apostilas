package net.sourceforge.pain.util;

import java.io.*;

public class IOUtils {

    public static byte[] getFileData(String fullFilePath) throws IOException {
        Log.debug("Loading file:" + fullFilePath);
        InputStream is = new FileInputStream(fullFilePath);
        try {
            byte[] data = new byte[is.available()];
            is.read(data);
            return data;
        } finally {
            is.close();
        }
    }

}
