package net.sourceforge.pain.admin.console.command;

import net.sourceforge.pain.admin.console.*;
import net.sourceforge.pain.data.role.*;

/**
 * User: fmike  Date: Jun 2, 2004  Time: 2:45:26 AM
 */
public class ChangePassAdminCommand extends AdminCommandHandler {
    public void processCommand(String params) {
        if (params == null) {
            showHelp();
            return;
        }
        String[] passes = AdminConsoleInputEvent.whitespacesSplitPattern.split(params);
        if (passes.length != 2) {
            showHelp();
            return;
        }
        if (passes[1].length() < 3) {
            console.out("new password is too short\n");
            return;
        }
        Administrator admin = getAdminAccount();
        if (!admin.getPassword().equals(passes[0])) {
            console.out("Error: wrong password\n");
        } else {
            admin.setPassword(passes[1]);
            console.out("Password changed.\n");
        }
    }

    public void showHelp() {
        console.out("Command: " + commandName + " - allows to change admin password\n");
        console.out("Usage: " + commandName + " <old_pass> <new_pass>\n");
    }
}
