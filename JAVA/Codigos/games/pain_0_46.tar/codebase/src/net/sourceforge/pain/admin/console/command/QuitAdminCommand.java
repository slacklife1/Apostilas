package net.sourceforge.pain.admin.console.command;

import net.sourceforge.pain.*;
import net.sourceforge.pain.admin.console.*;

/**
 * User: fmike  Date: Jun 2, 2004  Time: 3:02:02 AM
 */
public class QuitAdminCommand extends AdminCommandHandler {
    public void processCommand(String params) {
        Codebase.getAdminConsoleManager().closeConsole(console);
        AdminConsoleEvent.removeAdminConsoleFromMapping(console);
    }

    public void showHelp() {
        console.out("Command: "+commandName+" - closes admin connection\n");
    }
}
