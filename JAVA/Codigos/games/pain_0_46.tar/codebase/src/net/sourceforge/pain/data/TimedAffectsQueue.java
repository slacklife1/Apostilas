package net.sourceforge.pain.data;

import net.sourceforge.pain.db.*;

/**
 *
 */

public class TimedAffectsQueue extends DbObject {

    private static final int OFF_FIRST = 0;
    private static final int OFF_LAST = 1;

    private static final int NFIELDS = 2;


    public TimedAffectsQueue() {
    }

    TimedAffectsQueue(PainDB db) {
        super(db);
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        types[OFF_FIRST] = DbType.REFERENCE;
        names[OFF_FIRST] = "off_first";

        types[OFF_LAST] = DbType.REFERENCE;
        names[OFF_LAST] = "off_last";

        return new DbClassSchema(types, names);
    }

    public TimedAffectData getFirstOff() {
        return (TimedAffectData) getReference(OFF_FIRST);
    }


     TimedAffectData getLastOff() {
        return (TimedAffectData) getReference(OFF_LAST);
    }

    void setFirstOff(TimedAffectData d) {
        setReference(OFF_FIRST, d);
    }

    void setLastOff(TimedAffectData d) {
        setReference(OFF_LAST, d);
    }
}
