package net.sourceforge.pain;

import net.sourceforge.pain.util.*;

/**
 * CodebaseLauncher use this interface impl class for mudlib configuration/startup
 */
public interface MudlibInitializer {
    /** method called before any codebase services started
     * to check that all settings are correct
     * @param props
     */
    void readSetting(PropertiesReader props);

    /**
     *  method called after most codebase services(except pulse, user console, guitool) started.
     *  allow mudlib safely check data integrity, init components and services before user logins.
     */
    void init() throws Exception;
}
