package net.sourceforge.pain.util;

/**
 * Set of formatiing utils.
 */
public class FormatUtils {
    private FormatUtils(){}

    public static String formatStacktrace(Throwable t) {
        return "{RError!: " + t.getClass().getName() + ":" + t.getMessage() + "\n{w" + ClassUtils.getStackTrace(t) + "{x";
    }
}
