package net.sourceforge.pain.util;


import java.util.*;


/**
 * Simple impl of dice
 */
public final class Dice {

    private static Random random = new Random();

    private final int[] dice;

    public Dice(int numDice, int numSides, int add) {
        dice = new int[]{numDice, numSides, add};
    }

    public Dice(int[] dice) {
        this.dice = dice;
    }

    /**
     * format: XdY+Z
     */
    public Dice(String diceStr) {
        dice = new int[3];
        int d = diceStr.indexOf('d');
        if (d < 1) {
            throw new IllegalArgumentException("Invalid dice string:" + diceStr);
        }
        dice[0] = Integer.parseInt(diceStr.substring(0, d));
        int p = diceStr.indexOf('+', d);
        if (p < d + 1 || p > diceStr.length() - 1) {
            throw new IllegalArgumentException("Invalid dice string:" + diceStr);
        }
        dice[1] = Integer.parseInt(diceStr.substring(d + 1, p));
        dice[2] = Integer.parseInt(diceStr.substring(p + 1));
    }

    public int roll() {
        return roll(dice);
    }

    public static int roll(int[] dice) {
        return roll(dice[0], dice[1], dice[2]);
    }

    public static int roll(int numDice, int numSides) {
        return roll(numDice, numSides, 0);
    }

    public static int roll(int numDice, int numSides, int add) {
        if (numDice == 0 || numSides == 0) {
            return add;
        }
        int max = numDice * numSides;
        int randRange = max - numDice;
        return add + numDice + (randRange == 0 ? 0 : random.nextInt(randRange));
    }

    public int getMaxRoll() {
        return getMaxRoll(dice);
    }

    public static int getMaxRoll(int[] dice) {
        return dice[0] * dice[1] + dice[2];
    }

    public int[] data() {
        return dice;
    }

    public String toString() {
        return format(dice);
    }

    public static String format(int[] dice) {
        return new StringBuffer("Dice(").append(dice == null ? "NULL" : dice[0] + "d" + dice[1] + "+" + dice[2]).append(")").toString();
    }


}
