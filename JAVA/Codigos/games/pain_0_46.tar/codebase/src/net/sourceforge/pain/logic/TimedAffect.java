package net.sourceforge.pain.logic;

import net.sourceforge.pain.data.*;

/**
 * Affects timing (Affect stop time) is automaticaly managed by codebase.
 * <p/>
 * This class is linked statically to Core (could not be reloaded)
 * all it's subclasses in '..logic.affect.*'  package are loaded(linked) dynamically
 * <p/>
 */
public abstract class TimedAffect extends Affect {

    protected TimedAffect(AffectData ad) {
        super(ad);
    }

    /**
     * this method is automatially called when affect time is expired
     * affect impl could manually delete affect data or it will be deleted automatically
     * if it's stop time was not changed by this method call
     */
    public abstract void onAffectTimeExpired();

    /**
     * reflection is 10 times slower than 'new' method call (jdk1.4.2)
     * First time affect instance is created by codebase with reflection,
     * but all subsequent affect instance creations use this method call.
     * (It's required for all affects to have a public constructor like 'AffectAAA(AffectData ad)'
     * this constructor is used during first Affect instantiation by codebase)
     *
     * @return new Affect object instance, inited with AffectData param
     */
    public abstract Affect newInstance(AffectData ad);


}
