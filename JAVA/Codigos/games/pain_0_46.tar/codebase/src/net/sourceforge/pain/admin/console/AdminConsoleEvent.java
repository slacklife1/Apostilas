package net.sourceforge.pain.admin.console;

import net.sourceforge.pain.network.console.*;
import net.sourceforge.pain.logic.*;
import net.sourceforge.pain.db.*;
import net.sourceforge.pain.*;

import java.util.*;

/**
 * Base event class for admin console events
 * Admin console events (and all codebase administrative code) are not reloaded.
 * This allows  to restore server if mudlib reloading error occured
 * User: fmike  Date: Jun 1, 2004  Time: 2:33:14 AM
 */
public abstract class AdminConsoleEvent implements Event {
    static HashMap adminsByConsole = new HashMap();
    public static void removeAdminConsoleFromMapping(BasicConsole c) {
        adminsByConsole.remove(c);
    }

    public Object processEvent(Object param) throws Exception {
        final BasicConsole bc = (BasicConsole) param;
        final DbTransaction t = new DbTransaction() {
            public Object execute(Object[] params) throws Exception {
                process(bc);
                return null;
            }
        };
        Codebase.getDB().execute(t);
        return null;
    }

   public abstract void process(BasicConsole c);
}
