package net.sourceforge.pain.admin.console;

import net.sourceforge.pain.network.console.*;
import net.sourceforge.pain.util.*;

/**
 * User: fmike  Date: Jun 1, 2004  Time: 2:38:54 AM
 */
public class AdminLoginEvent extends AdminConsoleEvent {
    public void process(BasicConsole c) {
        Log.debug("AdminLoginEvent..");
        AdminLoginShell shell = new AdminLoginShell();
        shell.console = c;
        shell.processCommand(null);
    }
}
