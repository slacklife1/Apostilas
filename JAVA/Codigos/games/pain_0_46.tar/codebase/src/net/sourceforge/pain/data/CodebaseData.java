package net.sourceforge.pain.data;


import net.sourceforge.pain.db.*;


/**
 * Database root object. 
 */
public final class CodebaseData extends DbObject {

    private static final int VERSION = 0;
    private static final int PULSER = 1;
    private static final int ADMIN_ACCOUNTS_MAP = 2;
    private static final int TIMED_AFFECTS_QUEUE = 3;
    private static final int MUDLIB_ROOT = 4;
    private static final int NFIELDS = 5;

    public CodebaseData() {
    }

    public CodebaseData(PainDB db, String version) throws Exception {
        super(db);
        // all these values aggregated!
        setReference(PULSER, new CodebasePulse(db));
        setString(VERSION, version);
        setReference(TIMED_AFFECTS_QUEUE, new TimedAffectsQueue(db));

    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        types[VERSION] = DbType.STRING;
        names[VERSION] = "version";

        types[PULSER] = DbType.REFERENCE;
        names[PULSER] = "pulse";

        types[ADMIN_ACCOUNTS_MAP] = DbType.STRING_KEY_MAP;
        names[ADMIN_ACCOUNTS_MAP] = "admins_accounts";

        types[TIMED_AFFECTS_QUEUE] = DbType.REFERENCE;
        names[TIMED_AFFECTS_QUEUE] = "timed_affects_queue";

        types[MUDLIB_ROOT] = DbType.REFERENCE;
        names[MUDLIB_ROOT] = "mudlib_root";

        return new DbClassSchema(types, names);
    }


    public String getVersion() {
        return getString(VERSION);
    }

    public CodebasePulse getCodebasePulse() {
        return (CodebasePulse) getReference(PULSER);
    }


    public DbStringKeyMap getAdmins() {
        return getStringKeyMap(ADMIN_ACCOUNTS_MAP);
    }

    public TimedAffectsQueue getAffectsQueue() {
        return (TimedAffectsQueue) getReference(TIMED_AFFECTS_QUEUE);
    }

    public DbObject getMudLibRoot() {
        return getReference(MUDLIB_ROOT);
    }

    public void setMudLibRoot(DbObject root) {
        setReference(MUDLIB_ROOT, root);
    }
}


