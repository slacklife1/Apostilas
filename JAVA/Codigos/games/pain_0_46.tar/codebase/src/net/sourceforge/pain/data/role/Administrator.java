package net.sourceforge.pain.data.role;

import net.sourceforge.pain.db.*;

/**
 * Admin-console administrators account.
 */
public final class Administrator extends DbObject {

    protected static final int LOGIN = 0;
    protected static final int PASSWORD = 1;
    protected static final int NFIELDS = 2;

    public Administrator() {
    }

    public Administrator(PainDB db) {
        super(db);
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        types[LOGIN] = DbType.STRING;
        names[LOGIN] = "login";

        types[PASSWORD] = DbType.STRING;
        names[PASSWORD] = "password";

        return new DbClassSchema(types, names);
    }

    public String getLogin() {
        return getString(LOGIN);
    }

    public void setLogin(String login) {
        setString(LOGIN, login);
    }

    public String getPassword() {
        return getString(PASSWORD);
    }

    public void setPassword(String password) {
        setString(PASSWORD, password);
    }
}

