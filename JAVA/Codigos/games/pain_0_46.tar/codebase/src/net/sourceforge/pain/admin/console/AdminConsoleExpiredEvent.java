package net.sourceforge.pain.admin.console;

import net.sourceforge.pain.network.console.*;
import net.sourceforge.pain.util.*;

/**
 * User: fmike  Date: Jun 1, 2004  Time: 2:38:09 AM
 */
public class AdminConsoleExpiredEvent extends AdminConsoleEvent {
    public void process(BasicConsole c) {
        Log.debug("AdminConsoleExpiredEvent...");
        c.out("timeout\n");
        AdminConsoleEvent.adminsByConsole.remove(c);//console will be closed
    }
}
