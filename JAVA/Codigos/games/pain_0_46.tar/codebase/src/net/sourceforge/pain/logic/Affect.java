package net.sourceforge.pain.logic;

import net.sourceforge.pain.data.*;

/**
 * Affects logic base class. (Controller for persistent AffectData)
 * <p/>
 * this class is linked statically to Core (could not be reloaded)
 * all it's subclasses are loaded(linked) dynamically and will be reloaded  when
 * LogicLocader.reload() method call
 * <p/>
 * Note:Codebase requires from all affect controllers (Affect subclasses)
 * to provide constructor with single (AffectData d) param.
 * This constructor is used for automatic affect controller
 * instantiation and initialization with persistent image by codebase
 */

public abstract class Affect {

    protected AffectData ad;

    protected Affect(AffectData ad) {
        if (ad == null) {
            throw new NullPointerException("Affect: AffectData is null!");
        }
        this.ad = ad;
    }

}
