package net.sourceforge.pain.logic;


/**
 * Boundary event to logical system
 * Event impl usually contains code with mapping of
 * external to system events  to  virtual world logic.
 * (boundary=> user console, admin gui tool, plugins..)
 * Event is statically loaded interface, all it's implementors loaded dynamically!
 */
public interface Event {
    Object processEvent(Object param) throws Exception;
}
