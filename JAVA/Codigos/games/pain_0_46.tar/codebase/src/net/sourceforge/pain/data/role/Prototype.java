package net.sourceforge.pain.data.role;

import net.sourceforge.pain.data.*;
import net.sourceforge.pain.db.*;

/**
 * Base class for all prototypes.
 */
public abstract class Prototype extends Role {

    public Prototype() {
    }

    public Prototype(PainDB db) {
        super(db);
    }


    public abstract Class getPrototypedRoleClass();


    public String getVnum() {
        return ((PrototypeInfo) getRole(PrototypeInfo.class)).getVnum();
    }

    public String toString() {
        return "TODO: add toString()";
    }
}
