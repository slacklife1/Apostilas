package net.sourceforge.pain;

/**
 * Date: Jan 16, 2003
 * Time: 4:52:06 AM
 */
public abstract class PulsePeriodListener implements PulseListener {

    public static final int PERIOD_IN_PULSE = 1;
    public static final int PERIOD_IN_SECONDS = 2;
    private int period;
    private int timeToAct;

    public PulsePeriodListener(int period, int periodType) {
        switch (periodType) {
            case PERIOD_IN_PULSE:
                this.period = period;
                break;
            case PERIOD_IN_SECONDS:
                this.period = period * 1000 / Pulse.PULSE_PER_SCD;
                break;
            default:
                throw new IllegalArgumentException("Illegal Period type:" + periodType);
        }
        timeToAct = 0;
    }

    public void pulse(int time) throws Exception {
        if (time == timeToAct) {
            return;
        }
        timeToAct += period;
        onPeriod(time);

    }

    protected abstract void onPeriod(int time) throws Exception;
}
