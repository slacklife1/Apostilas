package net.sourceforge.pain.admin.console.command;

import net.sourceforge.pain.*;
import net.sourceforge.pain.admin.console.*;

/**
 * User: fmike  Date: Jun 25, 2004  Time: 3:02:02 AM
 */
public class KillServerAdminCommand extends AdminCommandHandler {
    public void processCommand(String params) throws Exception {
        Codebase.shutdown();
    }

    public void showHelp() {
        console.out("Command: " + commandName + " - forces server to shutdown  without any notification to mudlib\n");
    }
}
