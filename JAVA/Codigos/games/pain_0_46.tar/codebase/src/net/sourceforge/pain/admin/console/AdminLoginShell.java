package net.sourceforge.pain.admin.console;

import net.sourceforge.pain.*;
import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.util.*;

import java.util.*;

/**
 * User: fmike  Date: Jun 1, 2004  Time: 2:54:55 AM
 */
public class AdminLoginShell extends AdminCommandHandler {

    public static final int STATE_INIT = 0;
    public static final int STATE_WAIT_LOGIN = 1;
    public static final int STATE_WAIT_PASS = 2;

    private int state = STATE_INIT;
    private String login;
    private String pass;

    public void processCommand(String line) {
        try {
            switch (state) {
                case STATE_INIT:
                    init();
                    return;
                case STATE_WAIT_LOGIN:
                    processLogin(line);
                    return;
                case STATE_WAIT_PASS:
                    processPass(line);
                    return;
                default:
                    throw new IllegalStateException("??");
            }
        } catch (Exception e) {
            Log.error(e);
            Codebase.getAdminConsoleManager().closeConsole(console);
        }

    }

    private void processPass(String line) {
        pass = line;
        Map adminsAccounts = Codebase.getCodebaseData().getAdmins();
        Administrator admin = (Administrator) adminsAccounts.get(login);
        if (admin == null || !admin.getPassword().equals(pass)) {
            console.out("Illegal user name or password\n");
            Codebase.getAdminConsoleManager().closeConsole(console);
        } else {
            AdminLoginEvent.adminsByConsole.put(console, admin);
            console.setCommandMode();
        }
    }


    private void init() {
        console.setRawMode(this);
        console.out("Administrators console (PAiN " + Codebase.CODEBASE_VERSION + ")\n");
        console.out("login:");
        state = STATE_WAIT_LOGIN;
    }

    private void processLogin(String line) {
        login = line;
        console.out("password:");
        state = STATE_WAIT_PASS;
    }

    public void showHelp() {
        console.out("admin login shell\n");
    }
}
