package net.sourceforge.pain.network.guitool;

import net.sourceforge.pain.*;
import net.sourceforge.pain.util.*;

import java.util.*;

public final class GuiToolSessionManager extends PulsePeriodListener {
    public static final String MANAGEMENT_SERVER_EVENT = "guitool.GuiToolEvent";

    private final ArrayList connections = new ArrayList();
    private final GuiToolServer server;

    public GuiToolSessionManager(int port) {
        super(10, PERIOD_IN_PULSE);
        server = new GuiToolServer(this, port);
    }

    protected void onPeriod(int time) {
        final int nCons = connections.size();
        for (int i = 0; i < nCons; i++) {
            GuiToolConnection c = (GuiToolConnection) connections.get(i);
            if (c.inputEvents.isEmpty()) {
                continue;
            }
            try {
                Codebase.processEvent(MANAGEMENT_SERVER_EVENT, c);
            } catch (Exception e) {
                Log.error(e);
            }
        }
    }

    void onConnect(GuiToolConnection c) {
        connections.add(c);
    }

    void onDisconnect(GuiToolConnection c) {
        connections.remove(c);
    }

    public void close() {
        while (!connections.isEmpty()) {
            GuiToolConnection connection = (GuiToolConnection) connections.remove(connections.size() - 1);
            connection.forceClose();
        }
        server.stop();
    }

    public void closeConnection(GuiToolConnection c) {
        c.forceClose(); // will calls back to onDisconnect
    }

}
