package net.sourceforge.pain.logic;

/**
 * Allows receive events on logic reloading by LogicLoader.
 */
public interface LogicReloadListener {
    void onLogicReloading();
}
