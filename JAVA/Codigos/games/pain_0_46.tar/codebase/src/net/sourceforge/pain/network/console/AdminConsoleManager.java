package net.sourceforge.pain.network.console;

import net.sourceforge.pain.admin.console.*;

/**
 * Administrators console management systems.
 * Maps all events from remote console to administrators
 * logic.
 */
public final class AdminConsoleManager extends AbstractConsoleManager {

    public AdminConsoleManager(int port) throws Exception {
        super("AdminCM", port, new DefaultConsoleFactory());
        initEventClasses();
    }

    public void emitEvent(Class eventClass, BasicConsole c) throws Exception {
        ((AdminConsoleEvent)eventClass.newInstance()).process(c);
    }

    protected void initEventClasses() throws Exception {
        EVENT_CONSOLE_INPUT_CLASS = Class.forName("net.sourceforge.pain.admin.console.AdminConsoleInputEvent");
        EVENT_CONSOLE_EXPIRED_CLASS = Class.forName("net.sourceforge.pain.admin.console.AdminConsoleExpiredEvent");
        EVENT_NEW_CONNECTION_CLASS = Class.forName("net.sourceforge.pain.admin.console.AdminLoginEvent");
        EVENT_CONSOLE_DISCONNECT_CLASS = Class.forName("net.sourceforge.pain.admin.console.AdminConnectionLostEvent");
        EVENT_PROMPT_CLASS = Class.forName("net.sourceforge.pain.admin.console.AdminShowPrompt");
    }

    protected BasicConsole provideConsole(ConsoleAdapter adapter) {
        return new BasicConsole(adapter);
    }
}
