package net.sourceforge.pain.admin.console;

import net.sourceforge.pain.network.console.*;
import net.sourceforge.pain.data.role.*;

/**
 * User: fmike  Date: Jun 1, 2004  Time: 2:55:23 AM
 */
public abstract class AdminCommandHandler {
    Administrator admin;
    protected BasicConsole console;
    protected String commandName;


    public abstract void processCommand(String params) throws Exception;
    public abstract void showHelp();

    public String getCommandName() {
        return commandName;
    }

    public BasicConsole getConsole() {
            return console;
    }

    public Administrator getAdminAccount() {
        return (Administrator) AdminConsoleEvent.adminsByConsole.get(console);
    }

}
