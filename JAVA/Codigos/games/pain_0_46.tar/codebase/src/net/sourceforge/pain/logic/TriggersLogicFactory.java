package net.sourceforge.pain.logic;

import net.sourceforge.pain.*;
import net.sourceforge.pain.data.*;

import java.util.*;

/**
 * User: fmike  Date: May 29, 2004  Time: 6:56:19 PM
 */
public class TriggersLogicFactory {
    private static final Map triggerImplsCache = new HashMap();
    private static Object[] triggerParamsValues = new TriggerData[1];
    private static Class[] triggerParamsTypes = new Class[]{TriggerData.class};

    //todo: test cache performance: do we need it at all -->> yes reflection 10 times slower (jdk1.4.2)
    public static Trigger provideTriggerImpl(TriggerData td) throws Exception {
        String classNameSuffix = td.getTriggerClassName();
        Trigger sample = (Trigger) triggerImplsCache.get(classNameSuffix);
        if (sample == null) {
            Class c = Class.forName(Codebase.TRIGGERS_LOGIC_PACKAGE_PREFIX + classNameSuffix);
            sample = (Trigger) c.getDeclaredConstructor(triggerParamsTypes).newInstance(triggerParamsValues);
            triggerImplsCache.put(classNameSuffix, sample);
        }
        triggerParamsValues[0] = td;
        Trigger t = sample.newInstance(td);
        triggerParamsValues[0] = null;
        return t;
    }

    /**
     * codebase internal-use method
     */
    static void __cleanCaches() {
        triggerImplsCache.clear();
    }

}
