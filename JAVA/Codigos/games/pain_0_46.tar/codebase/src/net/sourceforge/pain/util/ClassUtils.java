package net.sourceforge.pain.util;

/**
 * Set of utility methods.
 */
public class ClassUtils {

    public static String classNameWithoutPackage(Class clazz) {
        String name = clazz.getName();
        int i = name.lastIndexOf('.');
        return name.substring(i + 1);
    }

    public static String getStackTrace(Throwable t) {
        final StackTraceElement[] stack = t.getStackTrace();
        StringBuffer result = new StringBuffer(2048);
        for (int i = 0; i < stack.length; i++) {
            result.append("\t");
            result.append(stack[i].toString());
            result.append("\n");
        }
        return result.toString();
    }
}
