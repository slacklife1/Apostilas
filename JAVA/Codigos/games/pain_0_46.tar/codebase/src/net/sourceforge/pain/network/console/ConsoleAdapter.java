package net.sourceforge.pain.network.console;



import java.io.*;


public abstract class ConsoleAdapter {

    public static final String NEW_LINE = "\r\n";
    protected BasicConsole console = null;

    private AbstractConsoleManager cm;

    public ConsoleAdapter() {
    }

    /**
     * super class should call this method ONLY when it ready
     * to accept data
     */
    public void init(AbstractConsoleManager cm) {
        this.cm = cm;
        console = cm.register(this);
    }

    public void lineReceived(String line) {
        console.input.add(line);
    }

    protected abstract void forceClose();

    public void closedRemote() {
        cm.onRemoteClose(console);
    }

    public abstract void outText(String text);


    /**
     * this method used to notify console adapter that end of the current text output reached
     * if adapter wants it may flush this output every time we send text
     * but adapter MUST flush all it's output buffer when we call flush manually.
     * NOTE: method impl should not block!
     */
    public abstract void flush() throws IOException;

    /** @return remote IP */
    public abstract String getRemoteAddr();
}
