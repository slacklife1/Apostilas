package net.sourceforge.pain.admin.console.command;

import net.sourceforge.pain.*;
import net.sourceforge.pain.admin.console.*;

/**
 * User: fmike  Date: Jun 25, 2004  Time: 3:02:02 AM
 */
public class ShutdownServerAdminCommand extends AdminCommandHandler {
    public void processCommand(String params) throws Exception {
        Object o = Codebase.processEvent("ShutdownRequestEvent", null);
        console.out("mudlib ShutdownRequestEvent reply: " + o + "\n");
    }

    public void showHelp() {
        console.out("Command: " + commandName + " - sends shutdown event to mudlib\n");
    }
}
