package net.sourceforge.pain.admin.console.command;

import net.sourceforge.pain.*;
import net.sourceforge.pain.admin.console.*;
import net.sourceforge.pain.plugin.*;

import java.util.*;

/**
 * User: fmike  Date: Jun 2, 2004  Time: 2:15:15 AM
 */
public class ReloadCodeAdminCommand extends AdminCommandHandler {

    public static final int RELOAD = 1;
    public static final int LOAD = 2;
    public static final int UNLOAD = 3;

    private int actionType;

    public ReloadCodeAdminCommand(int actionType) {
        this.actionType = actionType;
    }

    public void processCommand(String params) throws Exception {
        if (params == null || params.length() == 0) {
            showHelp();
            return;
        }
        if (actionType == RELOAD && params.equalsIgnoreCase("LOGIC")) {
            Codebase.getLogicLoader().reload();
            console.out("new classloader for logic classes setted up\n");
        } else if (!params.startsWith("plugin:")) {
            showHelp();
        } else {
            reloadPlugin(params.substring("plugin:".length()));
        }
    }

    private void reloadPlugin(String pluginName) throws Exception {
        PluginManager plm = Codebase.getPluginManager();
        Plugin p = plm.getPlugin(pluginName);
        if (actionType == UNLOAD || actionType == RELOAD) {
            if (p == null) {
                console.out("Plugin:{W'" + pluginName + "'{x was not loaded!\n");
            } else {
                for (Iterator it = p.getDependedPlugins().iterator(); it.hasNext();) {
                    String childName = (String) it.next();
                    console.out("Direct depended plugins to unload:{W'" + childName + "'{x\n");
                }
                console.out("Unloading plugin:{W'" + pluginName + "'{x\n");
                plm.unloadPlugin(p);
            }
        }
        if (actionType == RELOAD || actionType == LOAD) {
            if (plm.getPlugin(pluginName) != null) {
                console.out("Plugin:{W'" + pluginName + "'{x is already loaded\n");
            } else {
                console.out("Loading plugin:'{W" + pluginName + "'{x\n");
                plm.loadPlugin(pluginName);
            }
        }
    }

    public void showHelp() {
        switch (actionType) {
            case RELOAD:
                console.out("Command : " + commandName + " - allows to reload logic classes or plugins\n");
                console.out("Usage: " + commandName + " <logic> or plugin:<name>\n");
                break;
            case LOAD:
                console.out("Command : " + commandName + " - loads plugins\n");
                console.out("Usage: " + commandName + " plugin:<name>\n");
                break;
            case UNLOAD:
                console.out("Command : " + commandName + " - unloads plugins\n");
                console.out("Usage: " + commandName + " plugin:<name>\n");
                break;
        }
    }
}
