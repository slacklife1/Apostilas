package net.sourceforge.pain.admin.console;

import net.sourceforge.pain.admin.console.command.*;
import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.network.console.*;
import net.sourceforge.pain.util.*;

import java.util.*;
import java.util.regex.*;

/**
 * User: fmike  Date: Jun 1, 2004  Time: 2:36:16 AM
 */
public class AdminConsoleInputEvent extends AdminConsoleEvent {
    public static final Pattern whitespacesSplitPattern = Pattern.compile("\\S{1}\\s+\\S{1}");
    private static final String[] parsedCommand = new String[2];
    private static final HashMap handlers = new HashMap();

    static {
        handlers.put("quit", new QuitAdminCommand());
        handlers.put("exit", new QuitAdminCommand());
        handlers.put("reload", new ReloadCodeAdminCommand(ReloadCodeAdminCommand.RELOAD));
        handlers.put("load", new ReloadCodeAdminCommand(ReloadCodeAdminCommand.LOAD));
        handlers.put("unload", new ReloadCodeAdminCommand(ReloadCodeAdminCommand.UNLOAD));
        handlers.put("password", new ChangePassAdminCommand());
        handlers.put("pluglist", new PlugListAdminCommand());
        handlers.put("help", new HelpAdminCommand());
        handlers.put("shutdown", new ShutdownServerAdminCommand());
        handlers.put("killserver", new KillServerAdminCommand());
    }

    public void process(BasicConsole console) {
        try {
            Log.debug("AdminConsoleInputEvent..");
            AdminCommandHandler handler;
            String line = console.popInputLine();
            String params;
            if (console.isRawMode()) {
                handler = (AdminCommandHandler) console.getRawCommand();
                params = line;
            } else {
                parseCommand(line, parsedCommand);
                String command = parsedCommand[0].toLowerCase();
                params = parsedCommand[1];
                handler = (AdminCommandHandler) handlers.get(command);
                if (handler == null) {
                    console.out("Error: command not found : " + command + "\n");
                    return;
                }
                handler.commandName = command;
            }
            handler.console = console;
            handler.admin = (Administrator) AdminConsoleEvent.adminsByConsole.get(console);
            handler.processCommand(params);
        } catch (Exception e) {
            console.out(FormatUtils.formatStacktrace(e));
        }
    }


    /**
     * Splits line on 2 parts (command and params strings) and
     * saves to result array (result[0] = command, result[1] = params string)
     *
     * @param line   - input line
     * @param result - String[2]
     */
    public static void parseCommand(String line, String result[]) {
        Matcher matcher = whitespacesSplitPattern.matcher(line);
        if (matcher.find()) { // found spaces after command
            int commandEnd = matcher.start() + 1;
            result[0] = line.substring(0, commandEnd).trim(); //remove leading spaces
            int argStart = matcher.end() - 1;
            result[1] = line.substring(argStart);
        } else {
            result[0] = line.trim();
            result[1] = null;
        }
    }

    public static AdminCommandHandler provideAdminCommandHandler(String command, BasicConsole console) {
        AdminCommandHandler h = (AdminCommandHandler) handlers.get(command);
        if (h != null) {
            h.console = console;
            h.commandName = command;
        }
        return h;
    }

    public static Map getCommandsMapping() {
        return Collections.unmodifiableMap(handlers);
    }
}
