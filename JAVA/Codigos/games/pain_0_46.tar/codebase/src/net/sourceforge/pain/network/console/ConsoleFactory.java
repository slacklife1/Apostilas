package net.sourceforge.pain.network.console;

/**
 * Allows to user provide custom Console class impl (extends Console)
 */
public interface ConsoleFactory {
    public BasicConsole provideConsole(ConsoleAdapter ad);
}
