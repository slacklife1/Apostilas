package net.sourceforge.pain.data;

import net.sourceforge.pain.db.*;

/**
 * Codebase pulse counter persistent image 
 */
public final class CodebasePulse extends DbObject {

    protected static final int PULSE = 0;
    protected static final int NFIELDS = 1;

    public CodebasePulse() {
    }

    public CodebasePulse(PainDB db) {
        super(db);
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        types[PULSE] = DbType.INT;
        names[PULSE] = "pulse";
        return new DbClassSchema(types, names);
    }

    public int getPulse() {
        return getInt(PULSE);
    }

    public void setPulse(int time) {
        setInt(PULSE, time);
    }
}
