package net.sourceforge.pain.admin.console.command;

import net.sourceforge.pain.admin.console.*;

import java.util.*;


/**
 * User: fmike  Date: Jun 2, 2004  Time: 2:15:15 AM
 */
public class HelpAdminCommand extends AdminCommandHandler {
    public HelpAdminCommand() {
    }

    public void processCommand(String params) throws Exception {
        if (params == null || params.length() == 0) {
            Map commands = AdminConsoleInputEvent.getCommandsMapping();
            ArrayList names = new ArrayList(commands.keySet());
            Collections.sort(names);
            console.out("Available admin commands:\n");
            for (Iterator it = names.iterator(); it.hasNext();) {
                console.out((String) it.next() + "\n");
            }
        } else {
            AdminCommandHandler h = AdminConsoleInputEvent.provideAdminCommandHandler(params.toLowerCase(), console);
            if (h == null) {
                console.out("Command not found:" + params + "\n");
            } else {
                h.showHelp();
            }
        }
    }

    public void showHelp() {
        console.out("Command : " + commandName + " - shows help for specified command\n");
        console.out("Usage : " + commandName + " <command> \n");
    }
}
