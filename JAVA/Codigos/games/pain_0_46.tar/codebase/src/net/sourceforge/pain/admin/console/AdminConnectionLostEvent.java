package net.sourceforge.pain.admin.console;

import net.sourceforge.pain.network.console.*;
import net.sourceforge.pain.util.*;

/**
 * User: fmike  Date: Jun 1, 2004  Time: 2:39:13 AM
 */
public class AdminConnectionLostEvent extends AdminConsoleEvent {
    public void process(BasicConsole c) {
        Log.debug("AdminConnectionLostEvent..");
        AdminConsoleEvent.adminsByConsole.remove(c);
    }
}
