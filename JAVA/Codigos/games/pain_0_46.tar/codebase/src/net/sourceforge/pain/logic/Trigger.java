package net.sourceforge.pain.logic;

import net.sourceforge.pain.data.*;

/**
 * Base class for all trigger logic impls (controller over persistent TriggerData).
 * This class is linked statically, all it's subclasses should be located
 * in ...logic.triggers(.impl) package (see CodebaseLauncher properties).
 * and will be linked dynamically (will be reloaded on LogicLoader.reload() call)
 */
public abstract class Trigger {
    protected TriggerData td;

    /**
     * Constructor used to create trigger with existing model: persistent TriggerData object
     * required for all subclasses
     */
    public Trigger(TriggerData td) {
        this.td = td;
    }

    /**
     * factory method, used to avoid reflection and security checks for
     * new trigger instance creations
     * should return new instance of trigger initialized with TriggerData
     */
    public abstract Trigger newInstance(TriggerData td);

    public abstract int getTriggerEventType();
}
