package net.sourceforge.pain.db;

import java.io.*;
import java.lang.reflect.*;

/**
 * User: fmike  Date: 20.03.2003  Time: 19:25:42
 */
final class DbRuntimeMetaClass extends DbClassImpl {
    private final Constructor readConstructor;

    DbRuntimeMetaClass(final PainDB db) throws NoSuchMethodException {
        super(db, DbClassImage.schema.fieldTypes, DbClassImage.schema.fieldNames, DbClassImage.class.getName());
        readConstructor = DbClassImage.class.getDeclaredConstructor(new Class[0]);
    }

    Constructor getReadConstructor() {
        return readConstructor;
    }

    public final void delete() {
        throw new RuntimeException("BUG!");
    }

    public Serializable getOid() {
        throw new RuntimeException("BUG!");
    }

    public int pain_getIndexId() {
        throw new RuntimeException("BUG!");
    }

}
