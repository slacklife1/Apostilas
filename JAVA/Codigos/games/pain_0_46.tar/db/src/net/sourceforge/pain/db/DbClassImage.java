package net.sourceforge.pain.db;

/**
 * User: fmike  Date: 18.03.2003  Time: 17:09:34
 */
final class DbClassImage extends DbObject {
	static final DbClassSchema schema = new DbClassSchema(new byte[]{DbType.STRING, DbType.ARRAY_OF_BYTE, DbType.ARRAY_OF_STRING}, new String[]{"className", "types", "names"});
	private DbRuntimeClass runtimeClass;

	DbClassImage() {
	}

	DbClassImage(final PainDB db) throws RuntimeException {
		super(db);
	}

	public static DbClassSchema provideSchema() {
		return schema;
	}

	void setClassName(final String className) {
		setString(0, className);
	}

	void setFieldTypes(final byte[] types) {
		setByteArray(1, types);
	}

	void setFieldNames(final String[] fieldNames) {
		setStringArray(2, fieldNames);
	}

	String getClassName() {
		return getString(0);
	}

	byte[] getFieldTypes() {
		return getByteArray(1);
	}

	String[] getFieldNames() {
		return getStringArray(2);
	}

	int getNumberOfFields() {
		return getFieldTypes().length;
	}

	DbClassImpl getDbRuntimeClass() {
		return runtimeClass;
	}

	void setDbRuntimeClass(final DbRuntimeClass clazz) {
		runtimeClass = clazz;
	}

}

