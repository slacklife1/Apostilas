package net.sourceforge.pain.db;

/**
 * PAiN  Date: 10.04.2003  Time: 1:39:31
 */
final class DbConstants {

	static final int[] ZERO_INT_ARRAY = new int[0];
	static final String[] ZERO_STRING_ARRAY = new String[0];

	static final int STATE_OBJ_DETACHED = 0;
	static final int STATE_OBJ_DELETED = 1;
	static final int STATE_OBJ_NEW = 2;
	static final int STATE_OBJ_DIRTY = 3;
	static final int STATE_OBJ_CLEAN = 4;


	static final int STATE_CLASS_NEW = 1;
	static final int STATE_CLASS_DELETED = 2;
	static final int STATE_CLASS_NEW_AND_DELETED = 3;

	public static String OBJ_STATE_NAMES[] = new String[] {"DETACHED", "DELETED", "NEW", "DIRTY", "CLEAN" };
}
