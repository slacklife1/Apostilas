package net.sourceforge.pain.util;

import java.util.*;

/**
 * Wrapper Iterator.
 * Forbids remove operation.
 * User: fmike  Date: Mar 6, 2004  Time: 3:04:37 AM
 */
public final class ReadOnlyIterator implements Iterator {
        private final Iterator it;

        public ReadOnlyIterator(Iterator it) {
            this.it = it;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }

        public boolean hasNext() {
            return it.hasNext();
        }

        public Object next() {
            return it.next();
        }
    }
