package net.sourceforge.pain.db;

import java.util.*;

/**
 * PAiN  Date: 30.03.2003  Time: 20:59:37
 */
final class DbExtentIterator implements Iterator {
	private final DbClassImpl dbClass;
	private DbObject current;
	private int modCount;
    private final boolean weak;
    private boolean currentRemoved;

	DbExtentIterator(final DbClassImpl dbClass, boolean weak) {
        this.weak = weak;
		this.dbClass = dbClass;
		current = null;
		modCount = dbClass.modCount;
        currentRemoved = false;
	}

	public boolean hasNext() {
		checkState();
		return (current==null && dbClass.firstInExtent!=null) || (current!=null && current.next != null);
	}

	private void checkState() {
		dbClass.checkDbState();
		if (!weak && dbClass.modCount != modCount) {
			throw new ConcurrentModificationException();
		}
	}

	public Object next() {
		checkState();
		if (current == null) {
			if (dbClass.firstInExtent == null) {
				throw new NoSuchElementException();
			}
			current = dbClass.firstInExtent;
		} else {
			if (current.next == null) {
				throw new NoSuchElementException();
			}
			current = current.next;
		}
        if (weak) {
            dbClass.weakIteratorReassign(this, current);
        }
		return current;
	}

	public void remove() {
		checkState();
		if (current == null) { //its possible if weak == true and currentRemoved is also true
			throw new IllegalStateException();
		}
		final DbObject victim = current;
		current = current.prev;
        if (weak) {
            dbClass.weakIteratorReassign(this, current);
        }
		victim.delete();
		modCount = dbClass.modCount;
	}

    protected void onCurrentDelete() {
        assert weak;
        if (current!=null) { //possible if currentRemoved is true
            current = current.next;
        }
        dbClass.weakIteratorReassign(this, current);
        currentRemoved = true;
    }
}
