package net.sourceforge.pain.db;

/**
 * User: fmike  Date: 12.03.2003  Time: 17:33:57
 */
final class DbIntBuffer {

	int[] data;
	private int size;

	DbIntBuffer() {
		data = new int[4];
	}

	public DbIntBuffer(final int[] data) {
		this.data = data;
	}

	public DbIntBuffer(final int capacity) {
		data = new int[capacity];
	}

	final void ensureCapacity(final int capacity) {
		if (capacity > data.length) {
			final int twiceCapacity = data.length << 1;
			final int newLen = capacity > twiceCapacity ? capacity : twiceCapacity;
			final int[] newArr = new int[newLen];
			System.arraycopy(data, 0, newArr, 0, this.size);
			data = newArr;
		}
	}

	final int[] toArray() {
		final int[] result = new int[size];
		System.arraycopy(data, 0, result, 0, size);
		return result;
	}

	public void add(final int[] addData) {
		if (addData.length > 0) {
			ensureCapacity(size + addData.length);
			System.arraycopy(addData, 0, data, size, addData.length);
			size += addData.length;
		}
	}


	public void add(final int[] addData, final int from, final int length) {
		if (addData.length > 0) {
			ensureCapacity(size + length);
			System.arraycopy(addData, from, data, size, length);
			size += length;
		}
	}

	public void addFromTo(final int[] addData, final int from, final int to) {
		add(addData, from, to - from);
	}


	public void add(final int v) {
		ensureCapacity(size + 1);
		data[size] = v;
		size++;
	}

	public int getSize() {
		return size;
	}

	public boolean isEmpty() {
		return size == 0;
	}

	public int removeLast() {
		return data[--size];
	}

	public void clear() {
		size = 0;
	}


}
