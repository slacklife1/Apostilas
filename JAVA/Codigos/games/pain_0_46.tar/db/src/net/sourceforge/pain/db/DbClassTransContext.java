package net.sourceforge.pain.db;



/**
 * User: fmike  Date: 09.04.2003  Time: 18:54:21
 */
final class DbClassTransContext {
	DbTransactionContext trans;
	DbClassTransContext prevTransContext;
	DbClassImpl nextClassInTrans;

	/** new or dirty or deleted objects of this class*/
	DbObject firstObjInTrans;

	int state;

    DbClassImpl.ClassData backupData; // null for a new created classes

	DbClassTransContext(final DbTransactionContext trans) {
		this.trans = trans;
	}
}
