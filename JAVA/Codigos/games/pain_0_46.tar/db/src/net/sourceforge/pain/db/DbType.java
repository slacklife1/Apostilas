package net.sourceforge.pain.db;

/**
 * All supported PAiN DB field types
 */
public final class DbType {

    public static final int SEPARATELY_SAVED_COLLECTION_FLAG = 0x40;
    public static final int SEPARATELY_SAVED_COLLECTION_FLAG_FILTER = 0x3F;

    public static final int BOOLEAN = 1;
    public static final int BYTE = 2;
    public static final int CHAR = 3;
    public static final int DOUBLE = 4;
    public static final int FLOAT = 5;
    public static final int INT = 6;
    public static final int LONG = 7;
    public static final int SHORT = 8;
    public static final int STRING = 9;
    public static final int REFERENCE = 10;

    public static final int ARRAY_OF_BYTE = 12;
    public static final int ARRAY_OF_CHAR = 13;
    public static final int ARRAY_OF_INT = 16;
    public static final int ARRAY_OF_STRING = 19;

    /**
     * list of references to DbObjects, linked realization
     */
    public static final int LINKED_LIST = 20;
    /**
     * list of references to DbObjects, array based
     */
    public static final int ARRAY_LIST = 21;
    /**
     * Map with Integer keys and DbObject values
     */
    public static final int INT_KEY_MAP = 22;
    /**
     * Map with String keys and DbObject values
     */
    public static final int STRING_KEY_MAP = 23;
    /**
     * set of DbObjects
     */
    public static final int REFERENCE_SET = 24;
    /**
     * set of Strings
     */
    public static final int STRING_SET = 25;
    /**
     * Map with String keys and String values
     */
    public static final int STRING_MAP = 26;

    /**
     * same as LINKED_LIST | SEPARATELY_SAVED_COLLECTION_FLAG
     */
    public static final int SEPARATELY_SAVED_LINKED_LIST = LINKED_LIST | SEPARATELY_SAVED_COLLECTION_FLAG;
    /**
     * same as  ARRAY_LIST | SEPARATELY_SAVED_COLLECTION_FLAG
     */
    public static final int SEPARATELY_SAVED_ARRAY_LIST = ARRAY_LIST | SEPARATELY_SAVED_COLLECTION_FLAG;
    /**
     * same as  INT_KEY_MAP | SEPARATELY_SAVED_COLLECTION_FLAG
     */
    public static final int SEPARATELY_SAVED_INT_KEY_MAP = INT_KEY_MAP | SEPARATELY_SAVED_COLLECTION_FLAG;
    /**
     * same as STRING_KEY_MAP | SEPARATELY_SAVED_COLLECTION_FLAG
     */
    public static final int SEPARATELY_SAVED_STRING_KEY_MAP = STRING_KEY_MAP | SEPARATELY_SAVED_COLLECTION_FLAG;
    /**
     * same as  REFERENCE_SET | SEPARATELY_SAVED_COLLECTION_FLAG
     */
    public static final int SEPARATELY_SAVED_REFERENCE_SET = REFERENCE_SET | SEPARATELY_SAVED_COLLECTION_FLAG;
    /**
     * same as  STRING_SET | SEPARATELY_SAVED_COLLECTION_FLAG
     */
    public static final int SEPARATELY_SAVED_STRING_SET = STRING_SET | SEPARATELY_SAVED_COLLECTION_FLAG;
    /**
     * same as  STRING_MAP | SEPARATELY_SAVED_COLLECTION_FLAG
     */
    public static final int SEPARATELY_SAVED_STRING_MAP = STRING_MAP | SEPARATELY_SAVED_COLLECTION_FLAG;

    private static String[] typeNames = new String[27];

    static {
        typeNames[BOOLEAN] = "boolean";
        typeNames[BYTE] = "byte";
        typeNames[CHAR] = "char";
        typeNames[DOUBLE] = "double";
        typeNames[FLOAT] = "float";
        typeNames[INT] = "int";
        typeNames[LONG] = "long";
        typeNames[SHORT] = "short";
        typeNames[STRING] = "String";
        typeNames[REFERENCE] = "reference";

        typeNames[ARRAY_OF_BYTE] = "byte[]";
        typeNames[ARRAY_OF_CHAR] = "char[]";
        typeNames[ARRAY_OF_INT] = "int[]";
        typeNames[ARRAY_OF_STRING] = "String[]";

        typeNames[LINKED_LIST] = "LinkedList";
        typeNames[ARRAY_LIST] = "ArrayList";
        typeNames[INT_KEY_MAP] = "IntKeyMap";
        typeNames[STRING_KEY_MAP] = "StringKeyMap";
        typeNames[REFERENCE_SET] = "ReferenceSet";
        typeNames[STRING_SET] = "StringSet";
        typeNames[STRING_MAP] = "StringMap";

    }


    static final boolean isValidDbType(int type) {
        type = type & SEPARATELY_SAVED_COLLECTION_FLAG_FILTER;
        return type > 0 && type < typeNames.length && typeNames[type] != null;
    }

    /**
     * @return String name for the specified type
     */
    public static String name(int type) {
        String name = (type > 0 && type < typeNames.length ? typeNames[type & SEPARATELY_SAVED_COLLECTION_FLAG_FILTER] : null);
        if (name == null) {
            throw new IllegalArgumentException("Illegal type:" + type);
        }
        return name;
    }

    public static boolean isArray(int type) {
        return type == ARRAY_OF_BYTE || type == ARRAY_OF_CHAR || type == ARRAY_OF_INT || type == ARRAY_OF_STRING;
    }

    public static boolean isCollection(int type) {
        switch (type & SEPARATELY_SAVED_COLLECTION_FLAG_FILTER) {
            case LINKED_LIST:
            case ARRAY_LIST:
            case INT_KEY_MAP:
            case STRING_KEY_MAP:
            case REFERENCE_SET:
            case STRING_SET:
            case STRING_MAP:
                return true;
        }
        return false;


    }

    static boolean isSCollection(byte type) {
        return (type & SEPARATELY_SAVED_COLLECTION_FLAG) > 0;
    }
}
