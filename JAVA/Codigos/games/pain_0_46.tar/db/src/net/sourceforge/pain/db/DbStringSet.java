package net.sourceforge.pain.db;

import java.util.*;

/**
 * This class implements the <tt>Set</tt> interface. Only not null String values supported.<br>
 * PAiN Db will not support more general serializable objects Set as it brokes database design<br>
 * but Strings(Immutable) Sets are too convinient to be missed.
 * This class is still experimental and could be removed with next release.
 * (possible usage alternative: Cookie class and StingKeyMap)
 */

public final class DbStringSet extends DbAbstractStringMap implements Set {

	public DbStringSet(final DbObject owner, final String[] image, final int fid) {
		super(owner, image, fid);
	}

	public DbStringSet(final DbObject owner, final int fid) {
		super(owner, fid);
	}

	Object createBackupImage() {
		if (nElements == 0) {
			return DbConstants.ZERO_STRING_ARRAY;
		}
		final String image[] = new String[nElements];
		int pos = 0;
		final int nItems = nElements;
		for (int i = 0; pos < nItems; i++) {
			for (AStringMapEntry e = data[i]; e != null; e = e.next) {
				image[pos] = e.key;
				pos += 1;
			}
		}
		return image;
	}

	void restoreFromImage(final String[] image) {
		final int len = image.length;
		nElements = len;
		if (data == null || data.length < nElements || data.length > nElements * 2) {
			data = nElements == 0 ? ZERO_DATA : new AStringMapEntry[(int) (nElements / DEFAULT_LOAD_FACTOR)];
		}
		for (int i = 0; i < len; i++) {
			final String key = image[i];
			new AStringMapEntry(key, key);
		}
	}


/* ----------------- SET interface Impl ----------------*/

	public int size() {
		return x_size();
	}

	public void clear() {
		x_clear();
	}

	public boolean isEmpty() {
		return x_isEmpty();
	}

	public Object[] toArray() {
		return x_toArray(KEYS);
	}

	public boolean add(Object o) {
		String s = (String) o;
		return x_put(s, s) == null;
	}

	public boolean contains(Object o) {
		return x_get(o) != null;
	}

	public boolean remove(Object o) {
		return x_remove((String) o) != null;
	}

	public boolean addAll(Collection c) {
		throw new UnsupportedOperationException();
	}

	public boolean containsAll(Collection c) {
		throw new UnsupportedOperationException();
	}

	public boolean removeAll(Collection c) {
		throw new UnsupportedOperationException();
	}

	public boolean retainAll(Collection c) {
		throw new UnsupportedOperationException();
	}

	public Iterator iterator() {
		return x_iterator(KEYS);
	}

	public Object[] toArray(Object a[]) {
		return x_toArray(KEYS, a);
	}
}
