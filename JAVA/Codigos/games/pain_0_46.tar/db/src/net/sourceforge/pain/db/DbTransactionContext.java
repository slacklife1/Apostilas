package net.sourceforge.pain.db;


/**
 * User: fmike  Date: 09.04.2003  Time: 16:05:11
 */
final class DbTransactionContext {

	private final int transactionNo;
	final DbTransactionContext upperLevelTrans;

	DbClassImpl firstClassInTrans; //classes with backupData cashes for objects


	int rootIndex; //root index assigned in this transaction

	DbTransactionContext(final int transactionNo, final DbTransactionContext upperLevelTrans, final int rootIndex) {
		this.transactionNo = transactionNo;
		this.upperLevelTrans = upperLevelTrans;
		this.rootIndex = rootIndex;
	}

}
