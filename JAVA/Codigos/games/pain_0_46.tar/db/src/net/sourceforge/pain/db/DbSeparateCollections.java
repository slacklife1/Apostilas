package net.sourceforge.pain.db;

final class DbSeparateLinkedList extends DbObject {
    DbSeparateLinkedList() {
    }

    DbSeparateLinkedList(final PainDB db) throws RuntimeException {
        super(db);
    }

    public static DbClassSchema provideSchema() {
        return new DbClassSchema(new byte[]{DbType.LINKED_LIST}, new String[]{"linked_list"});
    }

    DbLinkedList getLinkedList() {
        return getLinkedList(0);
    }
}

final class DbSeparateArrayList extends DbObject {
    DbSeparateArrayList() {
    }

    DbSeparateArrayList(final PainDB db) throws RuntimeException {
        super(db);
    }

    public static DbClassSchema provideSchema() {
        return new DbClassSchema(new byte[]{DbType.ARRAY_LIST}, new String[]{"array_list"});
    }

    DbArrayList getArrayList() {
        return getArrayList(0);
    }
}
final class DbSeparateReferenceSet extends DbObject {
    DbSeparateReferenceSet() {
    }

    DbSeparateReferenceSet(final PainDB db) throws RuntimeException {
        super(db);
    }

    public static DbClassSchema provideSchema() {
        return new DbClassSchema(new byte[]{DbType.REFERENCE_SET}, new String[]{"reference_set"});
    }

    DbReferenceSet getRefSet() {
        return getRefSet(0);
    }
}
final class DbSeparateIntKeyMap extends DbObject {
    DbSeparateIntKeyMap() {
    }

    DbSeparateIntKeyMap(final PainDB db) throws RuntimeException {
        super(db);
    }

    public static DbClassSchema provideSchema() {
        return new DbClassSchema(new byte[]{DbType.INT_KEY_MAP}, new String[]{"int_key_map"});
    }

    DbIntKeyMap getIntKeyMap() {
        return getIntKeyMap(0);
    }
}

final class DbSeparateStringKeyMap extends DbObject {
    DbSeparateStringKeyMap () {
    }

    DbSeparateStringKeyMap(final PainDB db) throws RuntimeException {
        super(db);
    }

    public static DbClassSchema provideSchema() {
        return new DbClassSchema(new byte[]{DbType.STRING_KEY_MAP}, new String[]{"stirng_key_map"});
    }

    DbStringKeyMap getStringKeyMap() {
        return getStringKeyMap(0);
    }
}

final class DbSeparateStringSet extends DbObject {
    DbSeparateStringSet() {
    }

    DbSeparateStringSet(final PainDB db) throws RuntimeException {
        super(db);
    }

    public static DbClassSchema provideSchema() {
        return new DbClassSchema(new byte[]{DbType.STRING_SET}, new String[]{"string_set"});
    }

    DbStringSet getStringSet() {
        return getStringSet(0);
    }
}

final class DbSeparateStringMap extends DbObject {
    DbSeparateStringMap() {
    }

    DbSeparateStringMap(final PainDB db) throws RuntimeException {
        super(db);
    }

    public static DbClassSchema provideSchema() {
        return new DbClassSchema(new byte[]{DbType.STRING_MAP}, new String[]{"string_map"});
    }

    DbStringMap getStringMap() {
        return getStringMap(0);
    }
}
