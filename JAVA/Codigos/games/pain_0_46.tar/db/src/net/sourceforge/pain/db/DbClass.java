package net.sourceforge.pain.db;

import java.io.*;
import java.util.*;

/**
 * Persistent Class for DbObject
 */
public interface DbClass {

	public PainDB getDB();

	public int getNumberOfFields();

	public String getClassName();

	/**
	 * @param n number of field
	 * @return field name
	 */
	public String getFieldName(int n);

	/**
	 * @param n number of field
	 * @return field type {@link DbType class constants}
	 */
	public byte getFieldType(int n);

	/**
     * @param weak ignores class extent modifications (new objects creation, object removal)
     * during iteration if 'weak' is true.
     * 'weak'==true will lead to ConcurredModificationExcepiton if class extend is changing
     * during iteration
     * Weak iterator will see all new objects created during it's traversal
     * WARN: weakIterator could throw IllegalStateException
     * if the 'next' object was removed between 'hasNext' and 'next' method call and there is
     * no more objects to iterate (should call these methods locally in code)
	 * @return Iterator instance to iterate all objects (not deleted)
	 * of this class in database
	 */
	public Iterator extentIterator(boolean weak);

    /** equal to extentIterator(false) */
    public Iterator extentIterator();

	/**
	 * @return number of objects for this DbClass in Database (without objects in deleted state)
	 */
	public int getNumberOfObjects();

	/**
	 * removes all objects for this class and dbClass itself
	 */
	public void delete();

	/**
	 * @return serializable class id.
	 */
	public Serializable getOid();

    /** this is optimization method
     * specially produced for PAiN Mud Codebase
     * for performance purpose
     * It use knowledge that index id for the class
     * stays the same whole DbClass instance lifetime
     * (But it couldbe reused after class removal)
     */
    public int pain_getIndexId();


}
