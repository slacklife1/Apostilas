package net.sourceforge.pain.util;

import java.io.*;
import java.util.*;

/**
 * java.util.Properties wrapper.
 */
public final class PropertiesReader {

    private Properties props;
    private String fileName;
    private boolean silent = false;


    public PropertiesReader(String fileName) {
        init(fileName);
    }

    public PropertiesReader(Properties p) {
        props = p;
    }

    private void init(String fileName) {
        this.fileName = fileName;
        Log.debug("Reading properties from: " + fileName);
        props = new Properties();
        try {
            InputStream stream = null;
            try {
                stream = new FileInputStream(fileName);
                props.load(stream);
            } finally {
                if (stream != null) {
                    stream.close();
                }
            }
        } catch (Exception e) {
            props = null;
            Log.error(e.getMessage(), e);
            throw new RuntimeException("cant read: " + fileName);
        }
        Log.debug("Properties Read");
    }

    public void setSilent(boolean silent) {
        this.silent = silent;
    }

    public String get(String key) {
        return get(key, true);
    }

    public String get(String key, boolean notNull) {
        String result = getProperty(key);
        if (notNull && result == null) {
            throw new RuntimeException("[" + fileName + "] property is not assigned: '" + key + "'");
        }
        return result;
    }

    public String getProperty(String key) {
        String value = props.getProperty(key);
        if (!silent) {
            Log.debug("[" + fileName + "] asking property: " + key + "=" + value);
        }
        return value;

    }

    public long getLong(String key) {
        return Long.parseLong(getProperty(key));
    }

    public long getLong(String key, long minValue) {
        long result = getLong(key);
        if (result < minValue) {
            throw new RuntimeException("[" + fileName + "]'" + key + "' must be greater then: " + minValue + " (" + result + ")");
        }
        return result;
    }

    public boolean getBoolean(String key) {
        return getProperty(key).trim().equalsIgnoreCase("true");
    }

    public boolean getBoolean(String key, boolean defaultValue) {
        String value = getProperty(key);
        if (value == null) {
            return defaultValue;
        }
        return value.trim().equalsIgnoreCase("true");
    }


    public int getInt(String key) {
        return Integer.parseInt(getProperty(key));
    }

    public int getInt(String key, int minValue) {
        int result = getInt(key);
        if (result < minValue) {
            throw new RuntimeException("[" + fileName + "]'" + key + "' must be greater then: " + minValue + " (" + result + ")");
        }
        return result;
    }

    public int getInt(String key, int minValue, int defaultValue) {
        String value = getProperty(key);
        if (value == null) {
            return defaultValue;
        }
        int result = getInt(key);
        if (result < minValue) {
            throw new RuntimeException("[" + fileName + "]'" + key + "' must be greater then: " + minValue + " (" + result + ")");
        }
        return result;
    }

    public double getDouble(String key) {
        return Double.parseDouble(getProperty(key));
    }

    public double getDouble(String key, double minValue) {
        double result = getDouble(key);
        if (result < minValue) {
            throw new RuntimeException("[" + fileName + "]'" + key + "' must be greater then: " + minValue + " (" + result + ")");
        }
        return result;
    }

    public double getDouble(String key, double minValue, double maxValue) {
        double result = getDouble(key, minValue);
        if (result > maxValue) {
            throw new RuntimeException("[" + fileName + "]'" + key + "' must be less then: " + maxValue + " (" + result + ")");
        }
        return result;
    }

    public Properties getProperties() {
        return props;
    }


}

