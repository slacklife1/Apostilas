package net.sourceforge.pain.db;

import java.util.*;

/**
 * PAiN  Date: 12.04.2003  Time: 3:26:54
 */
abstract class DbCollection {

	final DbObject owner;
	final int fid;

	public DbCollection(final DbObject owner, final int fid) {
		this.owner = owner;
		this.fid = fid;
	}

	abstract Object createBackupImage();

	abstract void restoreFromBackup(Object image);

	abstract void _clear();


}
