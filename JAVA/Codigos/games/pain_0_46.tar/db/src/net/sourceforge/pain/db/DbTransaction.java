package net.sourceforge.pain.db;

/**
 * PAiN Db transaction wrapping class.
 */
public interface DbTransaction {

    /**
	 *  transaction is rolled back if exception occurs in method implementation.
     */
	public Object execute(Object[] params) throws Exception;

}
