package net.sourceforge.pain.db;

final class DbStringBuffer {

	String[] data;
	private int size;

	DbStringBuffer() {
		data = new String[4];
	}

	public DbStringBuffer(final String[] data) {
		this.data = data;
	}

	public DbStringBuffer(final int capacity) {
		data = new String[capacity];
	}

	final void ensureCapacity(final int capacity) {
		if (capacity > data.length) {
			final int twiceCapacity = data.length << 1;
			final int newLen = capacity > twiceCapacity ? capacity : twiceCapacity;
			final String[] newArr = new String[newLen];
			System.arraycopy(data, 0, newArr, 0, this.size);
			data = newArr;
		}
	}

	final String[] toArray() {
		final String[] result = new String[size];
		System.arraycopy(data, 0, result, 0, size);
		return result;
	}

	public void add(final String[] addData) {
		ensureCapacity(size + addData.length);
		System.arraycopy(addData, 0, data, size, addData.length);
		size += addData.length;
	}


	public void add(final String[] addData, final int from, final int length) {
		ensureCapacity(size + length);
		System.arraycopy(addData, from, data, size, length);
		size += length;
	}

	public void addFromTo(final String[] addData, final int from, final int to) {
		ensureCapacity(size + (to - from));
		System.arraycopy(addData, from, data, size, to - from);
		size += to - from;
	}


	public void add(final String v) {
		ensureCapacity(size + 1);
		data[size] = v;
		size++;
	}

	public int getSize() {
		return size;
	}

	public boolean isEmpty() {
		return size == 0;
	}

	public String removeLast() {
		return data[--size];
	}

	public void clear() {
		size = 0;
	}

	public int capacity() {
		return data.length;
	}


}
