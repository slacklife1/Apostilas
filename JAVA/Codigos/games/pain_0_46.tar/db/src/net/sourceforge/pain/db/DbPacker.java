package net.sourceforge.pain.db;

/**
 * User: fmike  Date: 04.03.2003  Time: 20:32:43
 Class for packing/unpacking image
 */
final class DbPacker {


	static short unpack2(final byte[] arr, final int offs) {
		return (short) ((arr[offs] << 8) | (arr[offs + 1] & 0xFF));
	}

	static int unpack4(final byte[] arr, final int offs) {
		return (arr[offs] << 24) | ((arr[offs + 1] & 0xFF) << 16)
		        | ((arr[offs + 2] & 0xFF) << 8) | (arr[offs + 3] & 0xFF);
	}

	static long unpack8(final byte[] arr, final int offs) {
		return ((long) unpack4(arr, offs) << 32)
		        | (unpack4(arr, offs + 4) & 0xFFFFFFFFL);
	}

	static void pack2(final byte[] arr, final int offs, final short val) {
		arr[offs] = (byte) (val >> 8);
		arr[offs + 1] = (byte) val;
	}

	static void pack4(final byte[] arr, final int offs, final int val) {
		arr[offs] = (byte) (val >> 24);
		arr[offs + 1] = (byte) (val >> 16);
		arr[offs + 2] = (byte) (val >> 8);
		arr[offs + 3] = (byte) val;
	}

	static void pack8(final byte[] arr, final int offs, final long val) {
		pack4(arr, offs, (int) (val >> 32));
		pack4(arr, offs + 4, (int) val);
	}

	static byte[] intArrayToBytes(final int[] array) {
		final int len = array.length;
		final byte[] bar = new byte[len * 4];
		for (int i = 0; i < len; i++) {
			pack4(bar, i * 4, array[i]);
		}
		return bar;
	}

	static byte[] charArrayToBytes(final char[] array) {
		final int len = array.length;
		final byte[] bar = new byte[len * 2];
		for (int i = 0; i < len; i++) {
			pack2(bar, i * 2, (short)array[i]);
		}
		return bar;
	}

	static byte[] shortArrayToBytes(final short[] array) {
		final int len = array.length;
		final byte[] bar = new byte[len * 2];
		for (int i = 0; i < len; i++) {
			pack2(bar, i * 2, array[i]);
		}
		return bar;
	}

	static byte[] longArrayToBytes(final long[] array) {
		final int len = array.length;
		final byte[] bar = new byte[len * 8];
		for (int i = 0; i < len; i++) {
			pack8(bar, i * 8, array[i]);
		}
		return bar;
	}

	static byte[] floatArrayToBytes(final float[] array) {
		final int len = array.length;
		final byte[] bar = new byte[len * 4];
		for (int i = 0; i < len; i++) {
			pack4(bar, i * 4, Float.floatToIntBits(array[i]));
		}
		return bar;
	}


	static byte[] floatArrayToBytes(final double[] array) {
		final int len = array.length;
		final byte[] bar = new byte[len * 8];
		for (int i = 0; i < len; i++) {
			pack8(bar, i * 8, Double.doubleToLongBits((array[i])));
		}
		return bar;
	}

	static byte[] booleanArrayToBytes(final boolean[] array) {
		final int len = array.length;
		final byte[] bar = new byte[len];
		for (int i = 0; i < len; i++) {
			bar[i] = (byte) (array[i] ? 1 : 0);
		}
		return bar;
	}

}

