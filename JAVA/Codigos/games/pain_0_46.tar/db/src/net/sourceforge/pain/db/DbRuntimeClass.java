package net.sourceforge.pain.db;

import java.io.*;
import java.lang.reflect.*;

/**
 * User: fmike  Date: 12.03.2003  Time: 18:51:13
 */
final class DbRuntimeClass extends DbClassImpl {

//	final Set objects = new HashSet();
	final DbClassImage image;
	private final Class objectClass;
	private final Constructor readConstructor;

	DbRuntimeClass(final DbClassImage image) throws RuntimeException {
		super(image.getDB(), image.getFieldTypes(), image.getFieldNames(), image.getClassName());
		this.image = image;
		try {
			objectClass = Class.forName(getClassName());
			readConstructor = objectClass.getDeclaredConstructor(new Class[0]);
		} catch (Exception e) {
			throw new RuntimeException("No default constructor was found:"+image.getClassName(), e);
		}
		image.setDbRuntimeClass(this);
	}

	Class getObjectClass() {
		return objectClass;
	}

	Constructor getReadConstructor() {
		return readConstructor;
	}

	int[] getPageNums() {
		return image.pageNums;
	}

	int getClassId() {
		return image.indexId;
	}

	public final void delete() {
		getDB().removeClass(this);
	}

	public Serializable getOid() {
		return image.getOid();
	}

    public int pain_getIndexId() {
        return image.indexId;
    }

}
