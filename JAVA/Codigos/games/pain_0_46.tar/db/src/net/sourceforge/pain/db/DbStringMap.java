package net.sourceforge.pain.db;

import java.util.*;

/**
 * This class implements the <tt>Map</tt> interface. Only not null String keys and values supported.<br>
 */

public final class DbStringMap extends DbAbstractStringMap implements Map {

	public DbStringMap(final DbObject owner, final String[] image, final int fid) {
		super(owner, image, fid);
	}

	public DbStringMap(final DbObject owner, final int fid) {
		super(owner, fid);
	}

	Object createBackupImage() {
		if (nElements == 0) {
			return DbConstants.ZERO_STRING_ARRAY;
		}
		final int imageLen = nElements * 2;
		final String image[] = new String[imageLen];
		int pos = 0;
		for (int i = 0; pos < imageLen; i++) {
			for (AStringMapEntry e = data[i]; e != null; e = e.next) {
				image[pos] = e.key;
				image[pos + 1] = e.value;
				pos += 2;
			}
		}
		return image;
	}

	void restoreFromImage(final String[] image) {
		final int len = image.length;
		nElements = len / 2;
		if (data == null || data.length < nElements || data.length > nElements * 2) {
			data = nElements == 0 ? ZERO_DATA : new AStringMapEntry[(int) (nElements / DEFAULT_LOAD_FACTOR)];
		}
		for (int i = 0; i < len; i += 2) {
			final String key = image[i];
			final String value = image[i + 1];
			new AStringMapEntry(key, value);
		}
	}


/* ----------------- SET interface Impl ----------------*/

	public int size() {
		return x_size();
	}

	public void clear() {
		x_clear();
	}

	public boolean isEmpty() {
		return x_isEmpty();
	}

	public boolean containsKey(Object key) {
		return x_get(key) != null;
	}

	public boolean containsValue(Object value) {
		return x_containsValue(value);
	}

	public Collection values() {
		return x_values();
	}

	public void putAll(Map t) {
		throw new UnsupportedOperationException();
	}

	public Set entrySet() {
		return x_entrySet();
	}

	public Set keySet() {
		return x_keySet();
	}

	public Object get(Object key) {
		return x_get(key);
	}

	public Object remove(Object key) {
		return x_remove((String)key);
	}

	public Object put(Object key, Object value) {
		return x_put((String)key, (String)value);
	}
}
