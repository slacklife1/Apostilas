package net.sourceforge.pain.db;

/**
 * PAiN  Date: 01.04.2003  Time: 1:21:48
 * Inverse reference to Object wich contain this ref from owner of collection
 */
abstract class DbInverseRef {

	/** chained list from inverseREfeference of the obj */
	DbInverseRef nextInverseRef;
	private DbInverseRef prevInverseRef;

	/** object we reference to */
	DbObject obj;


	DbInverseRef(final DbObject obj) {
		this.obj = obj;
		if (obj == null) {
			return;
		}
		nextInverseRef = obj.inverseRef;
		if (nextInverseRef != null) {
			nextInverseRef.prevInverseRef = this;
		}
		obj.inverseRef = this;
	}

	abstract void _onTargetDelete();

	/**
	 * called on obj deletion from PainDB
	 */
	final void onTargetDelete() {
		_onTargetDelete();
		obj = null;
	}

	final void onReferenceDestroy() {
		if (obj == null) {
			return;
		}
		if (this == obj.inverseRef) {
			obj.inverseRef = nextInverseRef;
		} else {
			prevInverseRef.nextInverseRef = nextInverseRef;
		}
		if (nextInverseRef != null) {
			nextInverseRef.prevInverseRef = prevInverseRef;
		}
	}

}
