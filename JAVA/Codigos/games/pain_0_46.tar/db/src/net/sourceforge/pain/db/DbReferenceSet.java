package net.sourceforge.pain.db;

import net.sourceforge.pain.util.*;

import java.util.*;

/*
/**
 * This class implements the <tt>Set</tt> interface. Only not null DbObject values supported.
 */

public final class DbReferenceSet extends DbAbstractMap implements Set {

	/**load from image during startup*/
	DbReferenceSet(final DbObject owner, final int[] image, final int fid) {
		super(owner, fid);
		restoreFromImage(image);
	}

	/** new object with set field during runtime */
	DbReferenceSet(final DbObject owner, final int fid) {
		super(owner, fid);
	}


	void restoreFromImage(Object backupImage) {
		final int image[] = (int[]) backupImage;
		final PainDB db = owner._getDB();
		final int len = image.length;
		nElements = len;
		if (data == null || data.length < nElements || data.length > nElements * 2) {
			data = nElements == 0 ? ZERO_DATA : new SetEntry[(int) (nElements / DEFAULT_LOAD_FACTOR)];
		}
		for (int i = 0; i < len; i++) {
			final int indexId = image[i];
			new SetEntry(indexId == -1 ? null : db.getObjectByIndexId(indexId));
		}
	}

	Object createBackupImage() {
		if (nElements == 0) {
			return DbConstants.ZERO_INT_ARRAY;
		}
		final int image[] = new int[nElements];
		int pos = 0;
		final int len = data.length;
		for (int i = 0; i < len; i++) {
			for (DbAbstractMap.AMapEntry e = data[i]; e != null; e = e.next) {
				image[pos] = e.obj.indexId;
				pos += 1;
			}
		}
		return image;
	}


// ---- DbAbstract Map impls ---- ///
	int a_getIndex(DbAbstractMap.UniversalKey key) {
		return _getIndex(key.intKey);
	}

	private int _getIndex(final int key) {
		return (key & 0x7FFFFFFF) % data.length;
	}


	Object a_get(Object key) {
		throw new RuntimeException("bug");
	}

	void a_addNewEntry(DbAbstractMap.UniversalKey key, DbObject value) {
		new SetEntry(value);
	}

// --- map interface ------//
	
	public int size() {
		return x_size();
	}

	public void clear() {
		x_clear();
	}

	public boolean isEmpty() {
		return x_isEmpty();
	}

	public Object[] toArray() {
		return x_values().toArray();
	}

	public boolean add(Object o) {
		ukey.intKey = ((DbObject) o).indexId;
		return x_put(ukey, o) != o;
	}

	public boolean contains(Object o) {
		ukey.intKey = ((DbObject) o).indexId;
		return x_get(ukey) != null;
	}

	public boolean remove(Object o) {
		ukey.intKey = ((DbObject) o).indexId;
		return x_remove(ukey) != null;
	}

	public boolean addAll(Collection c) {
		final int size = _size();
		for (Iterator it = c.iterator(); it.hasNext();) {
			add(it.next());
		}
		return size != x_size();
	}

	public boolean containsAll(Collection c) {
		for (Iterator it = c.iterator(); it.hasNext();) {
			DbObject obj = (DbObject) it.next();
			ukey.intKey = obj.indexId;
			if (x_get(ukey) != obj) {
				return false;
			}
		}
		return true;
	}

	public boolean removeAll(Collection c) {
		boolean result = false;
		for (Iterator it = c.iterator(); it.hasNext();) {
			DbObject obj = (DbObject) it.next();
			ukey.intKey = obj.indexId;
			result = x_remove(ukey) != null || result;
		}
		return result;
	}

	public boolean retainAll(Collection c) {
		throw new UnsupportedOperationException();
	}

	public Iterator iterator() {
		return x_valuesIterator();
	}

	public Object[] toArray(Object a[]) {
		return x_values().toArray(a);
	}
// ----------------------------------------------//

    public Iterator readOnlyIterator() {
        return new ReadOnlyIterator(iterator());
    }

//----------------- inners -----------------------//

	final class SetEntry extends AMapEntry {
		SetEntry(final DbObject obj) {
			super(obj);
			linkToMap();
		}

		public Object getKey() {
			throw new RuntimeException("bug");
		}

		int getIndex() {
			return _getIndex(obj.indexId);
		}

		boolean hasSameKey(UniversalKey ukey) {
			return ukey.intKey == obj.indexId;
		}
	};

}
