package net.sourceforge.pain.db;

/**
 * Class schema for the persistent object fields.
 * Any class that extends {@link DbObject} should provide its class schema.<br>
 * DbClassSchema is two arrays: types of fields and names of fields.
 * All supported field types specified in {@link DbType} class
 */
public final class DbClassSchema {

	final byte[] fieldTypes;
	final String[] fieldNames;


	public DbClassSchema(final byte[] types, final String[] names) {
		fieldTypes = types;
		fieldNames = names;
		check();
	}

	private void check() {
		final int len = fieldNames.length;
		for (int i = 0; i < len; i++) {
			if (!DbType.isValidDbType(fieldTypes[i])) {
				throw new RuntimeException("illegal field type:" + fieldTypes[i] + " name:"+fieldNames[i]+" fieldNum:"+i);
			}
			if (fieldNames[i] == null || fieldNames[i].length() == 0) {
				throw new RuntimeException("wrong field name!:'" + fieldNames[i] + "' fieldNum:" + i);
			}
			for (int j = 0; j < i; j++) {
				if (fieldNames[j].equalsIgnoreCase(fieldNames[i])) {
					throw new RuntimeException("dublicate name:" + fieldNames[i]);
				}
			}
		}
	}
}

