package net.sourceforge.pain.db;

/**
 * User: fmike  Date: 12.03.2003  Time: 17:33:57
 */
final class DbByteBuffer {

	byte[] data;
	private int size;

	public DbByteBuffer(final int capacity) {
		data = new byte[capacity];
	}

	public DbByteBuffer() {
		data = new byte[16];
	}

	public DbByteBuffer(final byte[] data) {
		this.data = data;
	}

	public void prepareToAdd(final int nElementsToAdd) {
		ensureCapacity(size + nElementsToAdd);
	}

	private void ensureCapacity(int newCapacity) {
		if (newCapacity > data.length) {
			newCapacity = newCapacity > (data.length * 2) ? newCapacity : data.length * 2;
			final byte[] newArr = new byte[newCapacity];
			System.arraycopy(data, 0, newArr, 0, size);
			data = newArr;
		}
	}

	final byte[] toArray() {
		final byte[] result = new byte[size];
		System.arraycopy(data, 0, result, 0, size);
		return result;
	}

	public void add(final byte[] addData) {
		ensureCapacity(size + addData.length);
		_add(addData);
	}

	private void _add(final byte[] addData) {
		System.arraycopy(addData, 0, data, size, addData.length);
		size += addData.length;
	}


	public void add(final byte[] addData, final int from, final int length) {
		ensureCapacity(size + length);
		System.arraycopy(addData, from, data, size, length);
		size += length;
	}

	public void addFromTo(final byte[] addData, final int from, final int to) {
		ensureCapacity(size + (to - from));
		System.arraycopy(addData, from, data, size, to - from);
		size += to - from;
	}


	public void add(final byte v) {
		ensureCapacity(size + 1);
		data[size] = v;
		size++;
	}

	public void add(final short v) {
		ensureCapacity(size + 2);
		DbPacker.pack2(data, size, v);
		size += 2;
	}

	public void add(final char v) {
		ensureCapacity(size + 2);
		_add(v);
	}

	private void _add(final char v) {
		DbPacker.pack2(data, size, (short) v);
		size += 2;
	}

	public void add(final int v) {
		ensureCapacity(size + 4);
		_add(v);
	}

	void _add(final int v) {
		DbPacker.pack4(data, size, v);
		size += 4;
	}

	public void add(final long v) {
		ensureCapacity(size + 8);
		_add(v);
	}

	private void _add(final long v) {
		DbPacker.pack8(data, size, v);
		size += 8;
	}

	public int getSize() {
		return size;
	}

	public void add(final int[] v) {
		final int len = v.length;
		ensureCapacity(size + (len << 2));
		for (int i = 0; i < len; i++) {
			DbPacker.pack4(data, size + (i << 2), v[i]);
		}
		size += len << 2;
	}

	public void clear() {
		size = 0;
	}

	public void add(final char[] charBuf, final int from, final int length) {
		ensureCapacity(size + (length << 1));
		for (int i = from; i < length; i++) {
			_add(charBuf[i]);
		}
	}

	public void add(final char[] chars) {
		add(chars, 0, chars.length);
	}


}
