package net.sourceforge.pain.db;

import java.io.*;

/**
 * Serializable DbObject ID
 */
public final class DbOid implements Serializable {

	int indexId;
	long versionId;

	private int hashCode;

	public DbOid() {
		hashCode = 0;
	}

	public DbOid(String image) {
		int sep = image.indexOf('/');
		if (sep <= 1) {
			throw new RuntimeException("Illegal DbOid image:" + image);
		}
		final int len_1 = image.length() - 1;
		if (image.charAt(0) != '[' || image.charAt(len_1) != ']') {
			throw new RuntimeException("Illegal DbOid image:" + image);
		}
		indexId = Integer.parseInt(image.substring(1, sep));
		versionId = Long.parseLong(image.substring(sep + 1, len_1));
	}

	DbOid(final int indexId, final long versionId) {
		this.indexId = indexId;
		this.versionId = versionId;
		hashCode = 0;
	}


	public boolean equals(final Object o) {
		if (this == o) {
			return true;
		}
		if (!(o instanceof DbOid)) {
			return false;
		}

		final DbOid dbOid = (DbOid) o;

		if (indexId != dbOid.indexId) {
			return false;
		}
		if (versionId != dbOid.versionId) {
			return false;
		}

		return true;
	}


	public int hashCode() {
		if (hashCode == 0) {
			hashCode = generateHashCode();
		}
		return hashCode;
	}

	private int generateHashCode() {
		int result;
		result = indexId;
		result = 29 * result + (int) (versionId ^ (versionId >>> 32));
		result = 29 * result + hashCode;
		return result;
	}


	/** this method use knowledge about PAiN DB internals
	 *  it public only for use with  PAiN Mud Codebase
	 */
//	public long getVersionId() {
//		return versionId;
//	}

	static String toString(int i, long v) {
		return "[" + i + "/" + v + "]";
	}

	public String toString() {
		return toString(indexId, versionId);
	}
}


