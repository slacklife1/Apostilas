package net.sourceforge.pain.db;

/**
 * User: fmike  Date: 09.04.2003  Time: 16:04:00
 */
final class DbObjectTransContext {

	DbTransactionContext trans;
	DbObjectTransContext prevTransContext;
	int backupDataIndex;
	DbObject nextObjInTrans;

	int state;

	DbObjectTransContext(final DbTransactionContext trans) {
		this.trans = trans;
	}


}
