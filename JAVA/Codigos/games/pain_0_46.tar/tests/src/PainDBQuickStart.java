
import net.sourceforge.pain.db.*;

import java.util.*;

public class PainDBQuickStart {

    public static void main(String[] args) throws Exception {
        final PainDB db = new PainDB("mydbfile");

        // Example 1: new object creation
        db.beginTransaction();
        MyDataObject obj = new MyDataObject(db);
        obj.setMyIntField(10);
        obj.setMyStringField("Hello World!");
        db.commitTransaction();

        // Example 2: transparent collections support
        db.beginTransaction();
        for (int i = 0; i < 100; i++) {
            MyDataObject myReference = new MyDataObject(db);
            myReference.setMyStringField("my_reference");
            obj.getMyReferences().add(myReference);
        }
        db.commitTransaction();


        //Example 3: rollback
        db.beginTransaction();
        for (Iterator it = obj.getMyReferences().iterator(); it.hasNext();) {
            MyDataObject myReference = (MyDataObject) it.next();
            it.remove();
            myReference.delete();
        }
        db.rollbackTransaction(); // here all changes done in  last transaction will be rolled back


        //Example 4: savepoints (subtransactions)
        db.beginTransaction();
        obj.setMyStringField("new value 1");
        db.beginTransaction(); // internal transaction (savepoint)!
        obj.setMyStringField("new value 2");
        db.rollbackTransaction(); // here we rolling back all changes done in internal transaction
        db.commitTransaction(); // commiting all changes done in first level transaction

        //Example 5: transaction wrapper, it's convinient to never write commit or rollback :)
        DbTransaction t = new DbTransaction() {
            public Object execute(Object[] params) {
                MyDataObject myDataObject = new MyDataObject(db);
                myDataObject.setMyStringField("this transaction will be commited if no exception thrown!");
                return null;
            }
        };
        db.execute(t);


        //Example 6: Subtransactions wrapping.
        DbTransaction t1 = new DbTransaction() {
            public Object execute(Object[] params) throws Exception {
                final MyDataObject myDataObject = new MyDataObject(db);
                myDataObject.setMyStringField("value1");
                DbTransaction t2 = new DbTransaction() {
                    public Object execute(Object[] params) throws Exception {
                        myDataObject.setMyStringField("value2");
                        return null;
                    }
                };
                db.execute(t2);
                assert(myDataObject.getMyStringField().equals("value2"));
                return null;
            }
        };
        db.execute(t1);

        //example 7: automatic removal all references during object deletion
        db.beginTransaction();
        MyDataObject obj7_1 = new MyDataObject(db);
        MyDataObject obj7_2 = new MyDataObject(db);
        obj7_1.getMyReferences().add(obj7_2);
        assert (obj7_1.getMyReferences().contains(obj7_2));
        obj7_2.delete();
        assert (obj7_1.getMyReferences().isEmpty());
        db.commitTransaction();

        db.close();
    }
}

