package net.sourceforge.pain.db;

import junit.framework.*;
import net.sourceforge.pain.db.data.*;

import java.io.*;

/**
 * User: fmike  Date: Aug 26, 2003   Time: 3:30:29 AM
 */
public final class DeleteTest extends TestCase {


    private PainDB db;

    public DeleteTest() {
        super("DeleteTest");
    }

    protected void setUp() throws Exception {
        db = new PainDB(getName() + ".db");
        db.ALLOW_PLAIN_WRITE = true; // allow work without transactions
        db.MANUAL_FLUSH_MODE = true; // commit will not flush (objects stays dirty)

    }

    protected void tearDown() throws Exception {
        if (db != null) {
            File file = new File(db.getDbFileName());
            if (!db.isClosed()) {
                db.forceClose();
            }
            db = null;
            file.delete();
        }
    }

    public void testDelete1() {
        ObjWithActiveDelete1 obj1 = new ObjWithActiveDelete1(db);
        ObjWithActiveDelete1 obj2 = new ObjWithActiveDelete1(db);
        obj1.setRef1(obj2);

        obj1.delete();
        assertTrue(obj2.isDetached());
    }

    public void testDeleteOnRollback1() {
        db.beginTransaction();
        ObjWithActiveDelete1 obj1 = new ObjWithActiveDelete1(db);
        ObjWithActiveDelete1 obj2 = new ObjWithActiveDelete1(db);
        obj1.setRef1(obj2);
        db.rollbackTransaction();
    }

    public void testDeleteOnRollback2() {
        db.beginTransaction();
        ObjWithActiveDelete2 obj2 = new ObjWithActiveDelete2(db);
        ObjWithActiveDelete1 obj1 = new ObjWithActiveDelete1(db);
        obj2.setRef1(obj1);
        db.rollbackTransaction();
    }

    public void testDeleteOnRollback2InverseClasscreation() {
        db.beginTransaction();
        ObjWithActiveDelete1 obj1 = new ObjWithActiveDelete1(db);
        ObjWithActiveDelete2 obj2 = new ObjWithActiveDelete2(db);
        obj2.setRef1(obj1);
        db.rollbackTransaction();
    }

    public void testInverseRemoveBugs1() throws IOException {
        db.beginTransaction();
        AllFieldTypesObject obj1 = new AllFieldTypesObject(db);
        AllFieldTypesObject obj2 = new AllFieldTypesObject(db);

        AllFieldTypesObject[] objs = new AllFieldTypesObject[2];
        for (int i = 0; i < objs.length; i++) {
            objs[i] = new AllFieldTypesObject(db);
            objs[i].getREFERENCE_SET().add(obj1);
            objs[i].getREFERENCE_SET().add(obj2);
        }
        objs[0].getREFERENCE_SET().remove(obj2);  //breaking second item in inverse refs list of obj2 (with a bug)
        obj2.delete();   // here we got assertion error from DbAbstractMap.unlinkFromMap when try to inlink inverse ref already removed
        db.commitTransaction();
    }

    public void testSeparateCollectionsRemovedOnDelete() throws Exception {
        AllFieldTypesObject obj1 = new AllFieldTypesObject(db);
        assertEquals(8, db.getNumberOfObjectsInDb()); // obj1 + 7 separate collections
        obj1.delete();
        assertEquals(0, db.getNumberOfObjectsInDb()); // obj1 + 7 separate collections were deleted and detached

        db.beginTransaction();
        obj1 = new AllFieldTypesObject(db);
        assertEquals(8, db.getNumberOfObjectsInDb()); // obj1 + 7 separate collections
        db.rollbackTransaction();
        assertEquals(0, db.getNumberOfObjectsInDb()); // obj1 + 7 separate collections were detached

        db.beginTransaction();
        obj1 = new AllFieldTypesObject(db);
        assertEquals(8, db.getNumberOfObjectsInDb()); // obj1 + 7 separate collections
        obj1.delete();
        assertEquals(8, db.getNumberOfObjectsInDb()); // obj1 + 7 separate collections deleted (could be rolled back)
        assertTrue(obj1.isDeleted());
        db.commitTransaction();
        assertEquals(0, db.getNumberOfObjectsInDb()); // obj1 + 7 separate collections detached
        assertTrue(obj1.isDetached());

        obj1 = new AllFieldTypesObject(db);
        assertEquals(8, db.getNumberOfObjectsInDb()); // obj1 + 7 separate collections
        db.beginTransaction();
        assertEquals(8, db.getNumberOfObjectsInDb()); // obj1 + 7 separate collections
        obj1.delete();
        assertEquals(8, db.getNumberOfObjectsInDb()); // obj1 + 7 separate collections deleted (could be rolled back)
        assertTrue(obj1.isDeleted());
        db.rollbackTransaction();
        assertEquals(8, db.getNumberOfObjectsInDb()); // obj1 + 7 separate collections were restored
        assertTrue(obj1.isDirty()); //will be clean only after flush
        db.flush();
        assertTrue(obj1.isClean()); 
        obj1.delete();
        assertEquals(0, db.getNumberOfObjectsInDb()); // obj1 + 7 separate collections were deleted and detached
        assertTrue(obj1.isDetached());

        db.beginTransaction();
        obj1 = new AllFieldTypesObject(db);
        assertEquals(8, db.getNumberOfObjectsInDb()); // obj1 + 7 separate collections
        db.commitTransaction();
        assertEquals(8, db.getNumberOfObjectsInDb()); // obj1 + 7 separate collections saved
    }
}
