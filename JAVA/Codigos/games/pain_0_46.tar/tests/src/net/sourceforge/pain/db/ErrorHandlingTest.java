package net.sourceforge.pain.db;

import junit.framework.*;
import net.sourceforge.pain.db.data.*;

import java.io.*;

/**
 * Checking error handling of database
 */
public final class ErrorHandlingTest extends TestCase {


    private PainDB db;

    public ErrorHandlingTest() {
        super("ErrorHandlingTest");
    }

    protected void setUp() throws Exception {
        db = new PainDB(getName() + ".db");
        db.ALLOW_PLAIN_WRITE = true; // allow work without transactions
        db.MANUAL_FLUSH_MODE = true; // commit will not flush (objects stays dirty)

    }

    protected void tearDown() throws Exception {
        if (db != null) {
            File file = new File(db.getDbFileName());
            if (!db.isClosed()) {
                db.forceClose();
            }
            db = null;
            file.delete();
        }
    }

    /**
     * explicit commits error handling
     */
    public void testExplicitCommit1() throws Exception {
        Exception exc = null;
        try {
            db.commitTransaction();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);
        exc = null;
        db.beginTransaction();
        db.commitTransaction();

        try {
            db.commitTransaction();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);

        exc = null;
        db.beginTransaction();
        db.beginTransaction();
        db.beginTransaction();
        db.commitTransaction();
        db.commitTransaction();
        db.commitTransaction();

        try {
            db.commitTransaction();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);

    }

    /**
     * explicit rollbacks error handling
     */
    public void testExplicitRollback1() {
        Exception exc = null;
        try {
            db.rollbackTransaction();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);
        exc = null;
        db.beginTransaction();
        db.rollbackTransaction();

        try {
            db.rollbackTransaction();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);

        exc = null;
        db.beginTransaction();
        db.beginTransaction();
        db.beginTransaction();
        db.rollbackTransaction();
        db.rollbackTransaction();
        db.rollbackTransaction();

        try {
            db.rollbackTransaction();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);
    }

    /**
     * deleted object access error handling
     */
    public void testDeletedAccess1() throws Exception {
        Exception exc = null;
        AllFieldTypesObject obj;
        db.beginTransaction();
        obj = new AllFieldTypesObject(db);
        db.rollbackTransaction();
        try {
            obj.getOid();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);

        db.beginTransaction();
        obj = new AllFieldTypesObject(db);
        db.beginTransaction();
        obj.delete();
        assertTrue(obj.isDeleted());
        _testAllTypesExceptionOnGet(obj);
        db.commitTransaction();
        assertTrue(obj.isDeleted());
        _testAllTypesExceptionOnGet(obj);
        db.commitTransaction();
    }

    private void _testAllTypesExceptionOnGet(AllFieldTypesObject obj) {
        Exception exc = null;
        try {
            obj.getARRAY_LIST();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);

        exc = null;
        try {
            obj.getARRAY_OF_BYTE();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);

        exc = null;
        try {
            obj.getARRAY_OF_CHAR();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);

        exc = null;
        try {
            obj.getARRAY_OF_INT();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);

        exc = null;
        try {
            obj.getARRAY_OF_STRING();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);

        exc = null;
        try {
            obj.getBOOLEAN();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);

        exc = null;
        try {
            obj.getBYTE();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);

        exc = null;
        try {
            obj.getCHAR();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);

        exc = null;
        try {
            obj.getDOUBLE();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);

        exc = null;
        try {
            obj.getFLOAT();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);


        exc = null;
        try {
            obj.getINT();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);


        exc = null;
        try {
            obj.getINT_KEY_MAP();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);


        exc = null;
        try {
            obj.getLINKED_LIST();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);

        exc = null;
        try {
            obj.getLONG();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);


        exc = null;
        try {
            obj.getREFERENCE();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);

        exc = null;
        try {
            obj.getREFERENCE_SET();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);


        exc = null;
        try {
            obj.getSHORT();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);

        exc = null;
        try {
            obj.getSTRING();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);

        exc = null;
        try {
            obj.getSTRING_KEY_MAP();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);

        exc = null;
        try {
            obj.getSTRING_SET();
        } catch (Exception e) {
            exc = e;
        }
        assertNotNull(exc);
    }

    /**
     * detached object access error handling
     */
    public void testDetachedAccess1() throws Exception {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        obj.delete();
        assertTrue(obj.isDetached());
        _testAllTypesExceptionOnGet(obj);

        db.beginTransaction();
        obj = new AllFieldTypesObject(db);
        db.rollbackTransaction();
        assertTrue(obj.isDetached());
        _testAllTypesExceptionOnGet(obj);

        db.beginTransaction();
        obj = new AllFieldTypesObject(db);
        assertTrue(obj.isNew());
        db.beginTransaction();
        assertTrue(obj.isNew());
        obj.delete();
        assertTrue(obj.isDeleted());
        db.commitTransaction();
        assertTrue(obj.isDeleted());
        db.commitTransaction();
        assertTrue(obj.isDetached());
        _testAllTypesExceptionOnGet(obj);
    }
}
