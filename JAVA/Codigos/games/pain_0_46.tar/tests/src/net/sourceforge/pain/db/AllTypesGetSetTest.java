package net.sourceforge.pain.db;

import junit.framework.*;
import net.sourceforge.pain.db.data.*;

import java.io.*;

/**
 * User: fmike * Date: Aug 24, 2003  * Time: 11:15:30 PM
 */
public final class AllTypesGetSetTest extends TestCase {

    private PainDB db;

    public AllTypesGetSetTest() {
        super("AllTypesGetSetTest");
    }

    protected void setUp() throws Exception {
        db = new PainDB(getName() + ".db");
        db.ALLOW_PLAIN_WRITE = true; // allow work without transactions
    }

    protected void tearDown() throws Exception {
        if (db != null) {
            File file = new File(db.getDbFileName());
            db.close();
            db = null;
            file.delete();
        }

    }


    public void testBOOLEAN() {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        assertEquals(false, obj.getBOOLEAN());

        obj.setBOOLEAN(true);
        assertEquals(true, obj.getBOOLEAN());

        obj.setBOOLEAN(false);
        assertEquals(false, obj.getBOOLEAN());
    }


    public void testBYTE() {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        assertEquals((byte) 0, obj.getBYTE());

        obj.setBYTE((byte) 100);
        assertEquals((byte) 100, obj.getBYTE());

        obj.setBYTE((byte) -100);
        assertEquals((byte) -100, obj.getBYTE());
    }

    public void testCHAR() {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        assertEquals((char) 0, obj.getCHAR());

        obj.setCHAR('\t');
        assertEquals('\t', obj.getCHAR());

        obj.setCHAR('x');
        assertEquals('x', obj.getCHAR());
    }


    public void testDOUBLE() {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        assertEquals(0D, obj.getDOUBLE(), 0D);

        obj.setDOUBLE(Math.PI);
        assertEquals(Math.PI, obj.getDOUBLE(), 0D);

        obj.setDOUBLE(Math.E);
        assertEquals(Math.E, obj.getDOUBLE(), 0D);

        obj.setDOUBLE(Double.NaN);
        assertTrue(Double.isNaN(obj.getDOUBLE()));

        obj.setDOUBLE(Double.POSITIVE_INFINITY);
        assertEquals(Double.POSITIVE_INFINITY, obj.getDOUBLE(), 0D);

        obj.setDOUBLE(Double.NEGATIVE_INFINITY);
        assertEquals(Double.NEGATIVE_INFINITY, obj.getDOUBLE(), 0D);

    }


    public void testFLOAT() {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        assertEquals(0F, obj.getFLOAT(), 0F);

        obj.setFLOAT((float) Math.E);
        assertEquals((float) Math.E, obj.getFLOAT(), 0F);

        obj.setFLOAT((float) Math.PI);
        assertEquals((float) Math.PI, obj.getFLOAT(), 0F);

        obj.setFLOAT(Float.NaN);
        assertTrue(Float.isNaN(obj.getFLOAT()));

        obj.setFLOAT(Float.POSITIVE_INFINITY);
        assertEquals(Float.POSITIVE_INFINITY, obj.getFLOAT(), 0F);

        obj.setFLOAT(Float.NEGATIVE_INFINITY);
        assertEquals(Float.NEGATIVE_INFINITY, obj.getFLOAT(), 0F);

    }


    public void testINT() {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        assertEquals(0, obj.getINT());

        obj.setINT(Integer.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, obj.getINT());

        obj.setINT(0);
        assertEquals(0, obj.getINT());
    }


    public void testLONG() {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        assertEquals(0L, obj.getLONG());

        obj.setLONG(Long.MIN_VALUE);
        assertEquals(Long.MIN_VALUE, obj.getLONG());

        obj.setLONG(-1L);
        assertEquals(-1L, obj.getLONG());
    }


    public void testSHORT() {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        assertEquals((short) 0, obj.getSHORT());

        obj.setSHORT(Short.MIN_VALUE);
        assertEquals(Short.MIN_VALUE, obj.getSHORT());

        obj.setSHORT((short) 1024);
        assertEquals((short) 1024, obj.getSHORT());
    }


    public void testSTRING() {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        assertNull(obj.getSTRING());

        final String v1 = "some test string 1";
        obj.setSTRING(v1);
        assertEquals(v1, obj.getSTRING());

        final String v2 = "some test string 2";
        obj.setSTRING(v2);
        assertEquals(v2, obj.getSTRING());

        obj.setSTRING(null);
        assertNull(obj.getSTRING());
    }


    public void testREFERENCE() {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        assertNull(obj.getREFERENCE());

        obj.setREFERENCE(obj);
        assertEquals(obj, obj.getREFERENCE());

        obj.setREFERENCE(null);
        assertNull(obj.getREFERENCE());
    }


    public void testARRAY_OF_BYTE() {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        assertNull(obj.getARRAY_OF_BYTE());

        byte[] v1 = new byte[]{1, 2, 3, 4};
        obj.setARRAY_OF_BYTE(v1);
        assertEquals(v1, obj.getARRAY_OF_BYTE());
        assertTrue(v1 == obj.getARRAY_OF_BYTE());

        obj.setARRAY_OF_BYTE(null);
        assertNull(obj.getARRAY_OF_BYTE());
    }


    public void testARRAY_OF_CHAR() {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        assertNull(obj.getARRAY_OF_CHAR());

        char[] v1 = new char[]{'H', 'e', 'l', 'l', 'o', '!'};
        obj.setARRAY_OF_CHAR(v1);
        assertEquals(v1, obj.getARRAY_OF_CHAR());
        assertTrue(v1 == obj.getARRAY_OF_CHAR());

        obj.setARRAY_OF_CHAR(null);
        assertNull(obj.getARRAY_OF_CHAR());
    }


    public void testARRAY_OF_INT() {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        assertNull(obj.getARRAY_OF_INT());

        int[] v1 = new int[]{1, 2, 3, 4};
        obj.setARRAY_OF_INT(v1);
        assertEquals(v1, obj.getARRAY_OF_INT());
        assertTrue(v1 == obj.getARRAY_OF_INT());

        obj.setARRAY_OF_INT(null);
        assertNull(obj.getARRAY_OF_INT());
    }


    public void testARRAY_OF_STRING() {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        assertNull(obj.getARRAY_OF_STRING());

        String[] v1 = new String[]{"1", null, "3", "456789"};
        obj.setARRAY_OF_STRING(v1);
        assertEquals(v1, obj.getARRAY_OF_STRING());
        assertTrue(v1 == obj.getARRAY_OF_STRING());

        obj.setARRAY_OF_STRING(null);
        assertNull(obj.getARRAY_OF_STRING());
    }


    public void testLINKED_LIST() {
        _testLINKED_LIST(false);
    }

    public void testSEPARATELY_SAVED_LINKED_LIST() {
        _testLINKED_LIST(true);
    }

    private void _testLINKED_LIST(boolean sep) {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        DbLinkedList list = sep ? obj.getSEPARATELY_SAVED_LINKED_LIST() : obj.getLINKED_LIST();
        assertNotNull(list);
        assertEquals(0, list.size());

        list.add(obj);
        assertEquals(1, list.size());

        list.add(obj);
        assertEquals(2, list.size());
        assertTrue(list.get(1) == obj);

        assertEquals(0, list.indexOf(obj));

        list.remove(obj);
        assertEquals(1, list.size());

        list.remove(obj);
        assertEquals(0, list.size());


        list.add(obj);
        list.add(obj);
        list.addAll(list);
        assertEquals(4, list.size());

        list.retainAll(list);
        assertEquals(4, list.size());
        assertTrue(list.get(3) == obj);

        assertTrue(list.contains(obj));
        assertFalse(list.contains(list));

        list.clear();
        assertTrue(list.isEmpty());
    }


    public void testARRAY_LIST() {
        _testARRAY_LIST(false);
    }

    public void testSEPARATELY_SAVED_ARRAY_LIST() {
        _testARRAY_LIST(true);
    }

    private void _testARRAY_LIST(boolean sep) {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        DbArrayList list = sep ? obj.getSEPARATELY_SAVED_ARRAY_LIST() : obj.getARRAY_LIST();
        assertNotNull(list);
        assertEquals(0, list.size());

        list.add(obj);
        assertEquals(1, list.size());

        list.add(obj);
        assertEquals(2, list.size());
        assertTrue(list.get(1) == obj);

        assertEquals(0, list.indexOf(obj));

        list.remove(obj);
        assertEquals(1, list.size());

        list.remove(obj);
        assertEquals(0, list.size());

        list.add(obj);
        list.add(obj);
        list.addAll(list);
        assertEquals(4, list.size());
        assertTrue(list.get(3) == obj);

        list.retainAll(list);
        assertEquals(4, list.size());

        assertTrue(list.contains(obj));
        assertFalse(list.contains(list));

        list.clear();
        assertTrue(list.isEmpty());
    }


    public void testINT_KEY_MAP() {
        _testINT_KEY_MAP(false);
    }

    public void testSEPARATELY_SAVED_INT_KEY_MAP() {
        _testINT_KEY_MAP(true);
    }

    private void _testINT_KEY_MAP(boolean sep) {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        DbIntKeyMap map = sep ? obj.getSEPARATELY_SAVED_INT_KEY_MAP() : obj.getINT_KEY_MAP();
        assertNotNull(map);
        assertEquals(0, map.size());

        map.put(1, obj);
        assertEquals(1, map.size());
        assertTrue(obj == map.get(1));
        assertNull(map.get(2));

        assertTrue(map.put(1, obj) == obj);
        assertEquals(1, map.size());
        map.put(2, obj);
        assertEquals(2, map.size());

        assertTrue(map.containsValue(obj));
        assertTrue(map.containsKey(2));
        assertFalse(map.containsKey(3));
        assertTrue(obj == map.remove(1));
        assertEquals(1, map.size());
        map.clear();
        assertEquals(0, map.size());
    }


    public void testSTRING_KEY_MAP() {
        _testSTRING_KEY_MAP(false);
    }

    public void testSEPARATELY_SAVED_STRING_KEY_MAP() {
        _testSTRING_KEY_MAP(true);
    }

    private void _testSTRING_KEY_MAP(boolean sep) {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        DbStringKeyMap map = sep ? obj.getSEPARATELY_SAVED_STRING_KEY_MAP() : obj.getSTRING_KEY_MAP();
        assertNotNull(map);
        assertEquals(0, map.size());

        final String key1 = "111";
        final String key2 = "222";
        final String key3 = "333";

        map.put(key1, obj);
        assertEquals(1, map.size());
        assertTrue(obj == map.get(key1));
        assertNull(map.get(key2));

        assertTrue(map.put(key1, obj) == obj);
        assertEquals(1, map.size());
        map.put(key2, obj);
        assertEquals(2, map.size());

        assertTrue(map.containsValue(obj));
        assertTrue(map.containsKey(key2));
        assertFalse(map.containsKey(key3));
        assertTrue(obj == map.remove(key1));
        assertEquals(1, map.size());
        map.clear();
        assertEquals(0, map.size());
    }

    public void testREFERENCE_SET() {
        _testREFERENCE_SET(false);
    }

    public void testSEPARATELY_SAVED_REFERENCE_SET() {
        _testREFERENCE_SET(true);
    }

    private void _testREFERENCE_SET(boolean sep) {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        DbReferenceSet set = sep ? obj.getSEPARATELY_SAVED_REFERENCE_SET() : obj.getREFERENCE_SET();
        assertNotNull(set);
        assertEquals(0, set.size());

        set.add(obj);
        assertEquals(1, set.size());

        set.add(obj);
        assertEquals(1, set.size());


        set.remove(obj);
        assertEquals(0, set.size());


        set.add(obj);
        set.add(obj);
//		set.addAll(set); unsupported -> todo
        assertEquals(1, set.size());

//		set.retainAll(set); unsupported -> todo
//		assertEquals(1, set.size());

        assertTrue(set.contains(obj));
        ClassCastException e = null;
        try {
            set.contains(set);
        } catch (ClassCastException ex) {
            e = ex;
        }
        assertNotNull(e);

        set.clear();
        assertTrue(set.isEmpty());
    }

    public void testSTRING_SET() {
        _testSTRING_SET(false);
    }

    public void testSEPARATELY_SAVED_STRING_SET() {
        _testSTRING_SET(true);
    }

    private void _testSTRING_SET(boolean sep) {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        DbStringSet set = sep ? obj.getSEPARATELY_SAVED_STRING_SET() : obj.getSTRING_SET();
        assertNotNull(set);
        assertEquals(0, set.size());

        final String obj1 = "lalala";
        set.add(obj1);
        assertEquals(1, set.size());

        set.add(obj1);
        assertEquals(1, set.size());


        set.remove(obj1);
        assertEquals(0, set.size());


        set.add(obj1);
        set.add(obj1);
//		set.addAll(set); unsupported -> todo
        assertEquals(1, set.size());

//		set.retainAll(set); unsupported -> todo
//		assertEquals(1, set.size());

        assertTrue(set.contains(obj1));
        assertFalse(set.contains(set));

        set.clear();
        assertTrue(set.isEmpty());
    }

    public void testSTRING_MAP() {
        _testSTRING_MAP(false);
    }

    public void testSEPARATELY_SAVED_STRING_MAP() {
        _testSTRING_MAP(true);
    }

    private void _testSTRING_MAP(boolean sep) {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        DbStringMap map = sep ? obj.getSEPARATELY_SAVED_STRING_MAP() : obj.getSTRING_MAP();
        assertNotNull(map);
        assertEquals(0, map.size());

        final String key1 = "key1";
        final String obj1 = "lalala";
        map.put(key1, obj1);
        assertEquals(1, map.size());

        map.put(key1, obj1);
        assertEquals(1, map.size());


        map.remove(key1);
        assertEquals(0, map.size());


        map.put(key1, obj1);
        map.put(key1, obj1);
//		map.addAll(map); unsupported -> todo
        assertEquals(1, map.size());

//		map.retainAll(map); unsupported -> todo
//		assertEquals(1, map.size());

        assertTrue(map.containsKey(key1));
        assertTrue(map.containsValue(obj1));

        map.clear();
        assertTrue(map.isEmpty());
    }
}
