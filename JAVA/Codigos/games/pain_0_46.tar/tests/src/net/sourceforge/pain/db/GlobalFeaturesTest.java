package net.sourceforge.pain.db;

import junit.framework.*;
import net.sourceforge.pain.db.data.*;

import java.io.*;

/**
 * User: fmike * Date: Aug 24, 2003  * Time: 11:15:30 PM
 */
public final class GlobalFeaturesTest extends TestCase {

    private PainDB db;

    public GlobalFeaturesTest() {
        super("GlobalFeaturesTest");
    }

    protected void setUp() throws Exception {
        db = new PainDB(getName() + ".db");
        db.ALLOW_PLAIN_WRITE = true; // allow work without transactions
    }

    protected void tearDown() throws Exception {
        if (db != null) {
            File file = new File(db.getDbFileName());
            if (!db.isClosed()) {
                db.forceClose();
            }
            db = null;
            file.delete();
        }

    }

    public void testBackup1() throws Exception {
        db.beginTransaction();
        final int N = 100;
        for (int i = 0; i < N; i++) {
            new AllFieldTypesObject(db);
        }
        db.commitTransaction();
        DbClass dbClass = db.getDbClass(AllFieldTypesObject.class);
        assertEquals(N, dbClass.getNumberOfObjects());

        final String fileName = db.getDbFileName();
        String backupName = fileName + ".backup";
        db.backupTo(backupName, true);
        db.close();

        db = new PainDB(backupName);
        new File(fileName).delete(); // old db file

        dbClass = db.getDbClass(AllFieldTypesObject.class);
        assertEquals(N, dbClass.getNumberOfObjects());
    }


    public void testExportImport1() throws Exception {
        String xmlFileName = "testExportImport1.xml";
        String newDbFileName = "testExportImport1.pdb";
        new File(xmlFileName).delete();
        new File(newDbFileName).delete();

        db.beginTransaction();
        final int N = 100;
        Object oids[] = new Object[N];
        for (int i = 0; i < N; i++) {
            AllFieldTypesObject obj = new AllFieldTypesObject(db);
            fillObject(obj, i);
            oids[i] = obj.getOid();
        }
        db.setRoot(db.getObject(oids[10]));
        assertSame(db.getRoot(), db.getObject(oids[10]));
        db.commitTransaction();
        assertSame(db.getRoot(), db.getObject(oids[10]));
        db.exportToXml(xmlFileName);
        db.close();

        db = PainDB.importFromXml(xmlFileName, newDbFileName);
        db.beginTransaction();
        for (int i = 0; i < N; i++) {
            AllFieldTypesObject obj = (AllFieldTypesObject) db.getObject(oids[i]);
            checkObject(obj, i);
        }
        assertSame(db.getRoot(), db.getObject(oids[10]));
        db.commitTransaction();
        db.close();

        new File(xmlFileName).delete();
        new File(newDbFileName).delete();
    }

    private void fillObject(AllFieldTypesObject obj, int i) {
        obj.setSTRING("some string " + i);
        obj.setINT(i);
        obj.setLONG(i * (long) i);
        obj.setBOOLEAN((i & 0x1) == 0);
        obj.setREFERENCE(obj);
        obj.getINT_KEY_MAP().put(i, obj);
        obj.getSTRING_MAP().put("key" + i, "value" + i);
        obj.getSTRING_SET().add("" + i);
        obj.setARRAY_OF_STRING(new String[]{"" + i});
        obj.setARRAY_OF_INT(new int[]{i});
    }

    private void checkObject(AllFieldTypesObject obj, int i) {
        assertEquals(obj.getSTRING(), "some string " + i);
        assertEquals(obj.getINT(), i);
        assertEquals(obj.getLONG(), i * (long) i);
        assertEquals(obj.getBOOLEAN(), (i & 0x1) == 0);
        assertSame(obj.getREFERENCE(), obj);
        assertSame(obj.getINT_KEY_MAP().get(i), obj);
        assertEquals(obj.getSTRING_MAP().get("key" + i), "value" + i);
        assertTrue(obj.getSTRING_SET().contains("" + i));
        assertEquals(obj.getARRAY_OF_STRING().length, 1);
        assertEquals(obj.getARRAY_OF_STRING()[0], "" + i);
        assertEquals(obj.getARRAY_OF_INT().length, 1);
        assertEquals(obj.getARRAY_OF_INT()[0], i);
    }

}
