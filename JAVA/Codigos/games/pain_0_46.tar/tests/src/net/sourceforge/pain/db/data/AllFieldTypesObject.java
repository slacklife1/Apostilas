package net.sourceforge.pain.db.data;

import net.sourceforge.pain.db.*;

/**
 * User: fmike  Date: Aug 24, 2003   Time: 11:26:06 PM
 */
public final class AllFieldTypesObject extends DbObject {

    private static int n = 0;
    private static final int BOOLEAN_FIELD = n++;
    private static final int BYTE_FIELD = n++;
    private static final int CHAR_FIELD = n++;
    private static final int DOUBLE_FIELD = n++;
    private static final int FLOAT_FIELD = n++;
    private static final int INT_FIELD = n++;
    private static final int LONG_FIELD = n++;
    private static final int SHORT_FIELD = n++;
    private static final int STRING_FIELD = n++;
    private static final int REFERENCE_FIELD = n++;

    private static final int ARRAY_OF_BYTE_FIELD = n++;
    private static final int ARRAY_OF_CHAR_FIELD = n++;
    private static final int ARRAY_OF_INT_FIELD = n++;
    private static final int ARRAY_OF_STRING_FIELD = n++;

    private static final int LINKED_LIST_FIELD = n++;
    private static final int ARRAY_LIST_FIELD = n++;
    private static final int INT_KEY_MAP_FIELD = n++;
    private static final int STRING_KEY_MAP_FIELD = n++;
    private static final int REFERENCE_SET_FIELD = n++;
    private static final int STRING_SET_FIELD = n++;
    private static final int STRING_MAP_FIELD = n++;

    private static final int SEPARATELY_SAVED_LINKED_LIST_FIELD = n++;
    private static final int SEPARATELY_SAVED_ARRAY_LIST_FIELD = n++;
    private static final int SEPARATELY_SAVED_INT_KEY_MAP_FIELD = n++;
    private static final int SEPARATELY_SAVED_STRING_KEY_MAP_FIELD = n++;
    private static final int SEPARATELY_SAVED_REFERENCE_SET_FIELD = n++;
    private static final int SEPARATELY_SAVED_STRING_SET_FIELD = n++;
    private static final int SEPARATELY_SAVED_STRING_MAP_FIELD = n++;

    private static final int NFIELDS = n;

    public AllFieldTypesObject() {
    }

    public AllFieldTypesObject(PainDB db) {
        super(db);
    }


    public static DbClassSchema provideSchema() {
        byte[] types = new byte[NFIELDS];
        String[] names = new String[NFIELDS];

        types[BOOLEAN_FIELD] = DbType.BOOLEAN;
        names[BOOLEAN_FIELD] = "BOOLEAN_FIELD";

        types[BYTE_FIELD] = DbType.BYTE;
        names[BYTE_FIELD] = "BYTE_FIELD";

        types[CHAR_FIELD] = DbType.CHAR;
        names[CHAR_FIELD] = "CHAR_FIELD";

        types[DOUBLE_FIELD] = DbType.DOUBLE;
        names[DOUBLE_FIELD] = "DOUBLE_FIELD";

        types[FLOAT_FIELD] = DbType.FLOAT;
        names[FLOAT_FIELD] = "FLOAT_FIELD";

        types[INT_FIELD] = DbType.INT;
        names[INT_FIELD] = "INT_FIELD";

        types[LONG_FIELD] = DbType.LONG;
        names[LONG_FIELD] = "LONG_FIELD";

        types[SHORT_FIELD] = DbType.SHORT;
        names[SHORT_FIELD] = "SHORT_FIELD";

        types[STRING_FIELD] = DbType.STRING;
        names[STRING_FIELD] = "STRING_FIELD";

        types[REFERENCE_FIELD] = DbType.REFERENCE;
        names[REFERENCE_FIELD] = "REFERENCE_FIELD";


        types[ARRAY_OF_BYTE_FIELD] = DbType.ARRAY_OF_BYTE;
        names[ARRAY_OF_BYTE_FIELD] = "ARRAY_OF_BYTE_FIELD";

        types[ARRAY_OF_CHAR_FIELD] = DbType.ARRAY_OF_CHAR;
        names[ARRAY_OF_CHAR_FIELD] = "ARRAY_OF_CHAR_FIELD";

        types[ARRAY_OF_INT_FIELD] = DbType.ARRAY_OF_INT;
        names[ARRAY_OF_INT_FIELD] = "ARRAY_OF_INT_FIELD";

        types[ARRAY_OF_STRING_FIELD] = DbType.ARRAY_OF_STRING;
        names[ARRAY_OF_STRING_FIELD] = "ARRAY_OF_STRING_FIELD";


        types[LINKED_LIST_FIELD] = DbType.LINKED_LIST;
        names[LINKED_LIST_FIELD] = "LINKED_LIST_FIELD";

        types[ARRAY_LIST_FIELD] = DbType.ARRAY_LIST;
        names[ARRAY_LIST_FIELD] = "ARRAY_LIST_FIELD";

        types[INT_KEY_MAP_FIELD] = DbType.INT_KEY_MAP;
        names[INT_KEY_MAP_FIELD] = "INT_KEY_MAP_FIELD";

        types[STRING_KEY_MAP_FIELD] = DbType.STRING_KEY_MAP;
        names[STRING_KEY_MAP_FIELD] = "STRING_KEY_MAP_FIELD";

        types[REFERENCE_SET_FIELD] = DbType.REFERENCE_SET;
        names[REFERENCE_SET_FIELD] = "REFERENCE_SET_FIELD";

        types[STRING_SET_FIELD] = DbType.STRING_SET;
        names[STRING_SET_FIELD] = "STRING_SET";

        types[STRING_MAP_FIELD] = DbType.STRING_MAP;
        names[STRING_MAP_FIELD] = "STRING_MAP";


        types[SEPARATELY_SAVED_LINKED_LIST_FIELD] = DbType.SEPARATELY_SAVED_LINKED_LIST;
        names[SEPARATELY_SAVED_LINKED_LIST_FIELD] = "SEPARATELY_SAVED_LINKED_LIST_FIELD";

        types[SEPARATELY_SAVED_ARRAY_LIST_FIELD] = DbType.SEPARATELY_SAVED_ARRAY_LIST;
        names[SEPARATELY_SAVED_ARRAY_LIST_FIELD] = "SEPARATELY_SAVED_ARRAY_LIST_FIELD";

        types[SEPARATELY_SAVED_INT_KEY_MAP_FIELD] = DbType.SEPARATELY_SAVED_INT_KEY_MAP;
        names[SEPARATELY_SAVED_INT_KEY_MAP_FIELD] = "SEPARATELY_SAVED_INT_KEY_MAP_FIELD";

        types[SEPARATELY_SAVED_STRING_KEY_MAP_FIELD] = DbType.SEPARATELY_SAVED_STRING_KEY_MAP;
        names[SEPARATELY_SAVED_STRING_KEY_MAP_FIELD] = "SEPARATELY_SAVED_STRING_KEY_MAP_FIELD";

        types[SEPARATELY_SAVED_REFERENCE_SET_FIELD] = DbType.SEPARATELY_SAVED_REFERENCE_SET;
        names[SEPARATELY_SAVED_REFERENCE_SET_FIELD] = "SEPARATELY_SAVED_REFERENCE_SET_FIELD";

        types[SEPARATELY_SAVED_STRING_SET_FIELD] = DbType.SEPARATELY_SAVED_STRING_SET;
        names[SEPARATELY_SAVED_STRING_SET_FIELD] = "SEPARATELY_SAVED_STRING_SET";

        types[SEPARATELY_SAVED_STRING_MAP_FIELD] = DbType.SEPARATELY_SAVED_STRING_MAP;
        names[SEPARATELY_SAVED_STRING_MAP_FIELD] = "SEPARATELY_SAVED_STRING_MAP";


        return new DbClassSchema(types, names);
    }


    public boolean getBOOLEAN() {
        return getBoolean(BOOLEAN_FIELD);
    }

    public void setBOOLEAN(boolean v) {
        setBoolean(BOOLEAN_FIELD, v);
    }

    public byte getBYTE() {
        return getByte(BYTE_FIELD);
    }

    public void setBYTE(byte v) {
        setByte(BYTE_FIELD, v);
    }

    public char getCHAR() {
        return getChar(CHAR_FIELD);
    }

    public void setCHAR(char v) {
        setChar(CHAR_FIELD, v);
    }

    public double getDOUBLE() {
        return getDouble(DOUBLE_FIELD);
    }

    public void setDOUBLE(double v) {
        setDouble(DOUBLE_FIELD, v);
    }

    public float getFLOAT() {
        return getFloat(FLOAT_FIELD);
    }

    public void setFLOAT(float v) {
        setFloat(FLOAT_FIELD, v);
    }

    public int getINT() {
        return getInt(INT_FIELD);
    }

    public void setINT(int v) {
        setInt(INT_FIELD, v);
    }

    public long getLONG() {
        return getLong(LONG_FIELD);
    }

    public void setLONG(long v) {
        setLong(LONG_FIELD, v);
    }

    public short getSHORT() {
        return getShort(SHORT_FIELD);
    }

    public void setSHORT(short v) {
        setShort(SHORT_FIELD, v);
    }

    public String getSTRING() {
        return getString(STRING_FIELD);
    }

    public void setSTRING(String v) {
        setString(STRING_FIELD, v);
    }

    public DbObject getREFERENCE() {
        return getReference(REFERENCE_FIELD);
    }

    public void setREFERENCE(DbObject v) {
        setReference(REFERENCE_FIELD, v);
    }

    public byte[] getARRAY_OF_BYTE() {
        return getByteArrayForRead(ARRAY_OF_BYTE_FIELD);
    }

    public void setARRAY_OF_BYTE(byte[] v) {
        setByteArray(ARRAY_OF_BYTE_FIELD, v);
    }

    public char[] getARRAY_OF_CHAR() {
        return getCharArrayForRead(ARRAY_OF_CHAR_FIELD);
    }

    public void setARRAY_OF_CHAR(char[] v) {
        setCharArray(ARRAY_OF_CHAR_FIELD, v);
    }

    public int[] getARRAY_OF_INT() {
        return getIntArrayForRead(ARRAY_OF_INT_FIELD);
    }

    public void setARRAY_OF_INT(int[] v) {
        setIntArray(ARRAY_OF_INT_FIELD, v);
    }

    public String[] getARRAY_OF_STRING() {
        return getStringArrayForRead(ARRAY_OF_STRING_FIELD);
    }

    public void setARRAY_OF_STRING(String[] v) {
        setStringArray(ARRAY_OF_STRING_FIELD, v);
    }

    public DbLinkedList getLINKED_LIST() {
        return getLinkedList(LINKED_LIST_FIELD);
    }


    public DbArrayList getARRAY_LIST() {
        return getArrayList(ARRAY_LIST_FIELD);
    }


    public DbIntKeyMap getINT_KEY_MAP() {
        return getIntKeyMap(INT_KEY_MAP_FIELD);
    }


    public DbStringKeyMap getSTRING_KEY_MAP() {
        return getStringKeyMap(STRING_KEY_MAP_FIELD);
    }


    public DbReferenceSet getREFERENCE_SET() {
        return getRefSet(REFERENCE_SET_FIELD);
    }

    public DbStringSet getSTRING_SET() {
        return getStringSet(STRING_SET_FIELD);
    }

    public DbStringMap getSTRING_MAP() {
        return getStringMap(STRING_MAP_FIELD);
    }

    public DbLinkedList getSEPARATELY_SAVED_LINKED_LIST() {
        return getLinkedList(SEPARATELY_SAVED_LINKED_LIST_FIELD);
    }


    public DbArrayList getSEPARATELY_SAVED_ARRAY_LIST() {
        return getArrayList(SEPARATELY_SAVED_ARRAY_LIST_FIELD);
    }


    public DbIntKeyMap getSEPARATELY_SAVED_INT_KEY_MAP() {
        return getIntKeyMap(SEPARATELY_SAVED_INT_KEY_MAP_FIELD);
    }


    public DbStringKeyMap getSEPARATELY_SAVED_STRING_KEY_MAP() {
        return getStringKeyMap(SEPARATELY_SAVED_STRING_KEY_MAP_FIELD);
    }


    public DbReferenceSet getSEPARATELY_SAVED_REFERENCE_SET() {
        return getRefSet(SEPARATELY_SAVED_REFERENCE_SET_FIELD);
    }

    public DbStringSet getSEPARATELY_SAVED_STRING_SET() {
        return getStringSet(SEPARATELY_SAVED_STRING_SET_FIELD);
    }

    public DbStringMap getSEPARATELY_SAVED_STRING_MAP() {
        return getStringMap(SEPARATELY_SAVED_STRING_MAP_FIELD);
    }

}
