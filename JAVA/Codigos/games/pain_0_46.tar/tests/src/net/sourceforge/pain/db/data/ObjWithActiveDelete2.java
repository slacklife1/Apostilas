package net.sourceforge.pain.db.data;

import net.sourceforge.pain.db.*;

/**
 * User: fmike  Date: Oct 16, 2003   Time: 2:22:04 AM
 */
public class ObjWithActiveDelete2 extends DbObject {
    private static final int REF1 = 0;
    private static final int NFIELDS = 1;


    public ObjWithActiveDelete2() {
    }

    public ObjWithActiveDelete2(final PainDB db) throws RuntimeException {
        super(db);
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        types[REF1] = DbType.REFERENCE;
        names[REF1] = "ref1";

        return new DbClassSchema(types, names);
    }

    public ObjWithActiveDelete1 getRef1() {
        return (ObjWithActiveDelete1) getReference(REF1);
    }

    public void setRef1(ObjWithActiveDelete1 ref) {
        setReference(REF1, ref);
    }

    public void delete() {
        ObjWithActiveDelete1 ref1 = getRef1();
        if (ref1 != null) {
            ref1.delete();
        }
        super.delete();
    }
}
