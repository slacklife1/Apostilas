package net.sourceforge.pain.db;

import junit.framework.*;
import net.sourceforge.pain.db.data.*;

import java.io.*;

/**
 * User: fmike  Date: Aug 26, 2003   Time: 3:30:29 AM
 */
public final class PlainWriteModeTest extends TestCase {


    private PainDB db;

    public PlainWriteModeTest() {
        super("PlainWriteModeTest");
    }

    protected void setUp() throws Exception {
        db = new PainDB(getName() + ".db");
        db.ALLOW_PLAIN_WRITE = true; // allow work without transactions
    }

    protected void tearDown() throws Exception {
        if (db != null) {
            File file = new File(db.getDbFileName());
            if (!db.isClosed()) {
                db.close();
            }
            db = null;
            file.delete();
        }
    }

    public void testState1() throws IOException {
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        assertTrue(obj.isDirty()); // in plain write mode there is no NEW state

        obj.setBOOLEAN(true);
        assertTrue(obj.isDirty());

        db.flush();

        assertTrue(obj.isClean());

        boolean v = obj.getBOOLEAN();
        assertEquals(true, v);
        assertTrue(obj.isClean());

        obj.setBOOLEAN(v);
        assertTrue(obj.isDirty());

        db.flush();

        assertTrue(obj.isClean());
        obj.delete();
        assertTrue(obj.isDetached());

        db.flush();
        assertTrue(obj.isDetached());
    }

    public void testStartStop1() throws Exception {
        db.MANUAL_FLUSH_MODE = true; // will not flush on close
        assertTrue(db.isDatabaseEmpty());
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        assertFalse(db.isDatabaseEmpty());

        Object oid = obj.getOid();
        String fileName = db.getDbFileName();
        db.close();
        assertTrue(db.isClosed());
        assertTrue(obj.isDetached());

        db = new PainDB(fileName);
        obj = (AllFieldTypesObject) db.getObject(oid);
        assertNull(obj);

        obj = new AllFieldTypesObject();
        assertTrue(obj.isDetached());

        obj = new AllFieldTypesObject(db);
        assertTrue(obj.isDirty());
        obj.setREFERENCE(obj);
        oid = obj.getOid();
        assertSame(obj, db.getObject(oid));
        db.flush();
        assertTrue(obj.isClean());
        assertSame(obj, db.getObject(oid));
        assertSame(obj.getREFERENCE(), obj);
        assertEquals(oid, obj.getOid());
        db.close();
        assertTrue(obj.isDetached());
        db = new PainDB(fileName);
        obj = (AllFieldTypesObject) db.getObject(oid);
        assertNotNull(obj);
        assertSame(obj, obj.getREFERENCE());
        assertTrue(obj.isClean());

        obj.delete();
        assertTrue(obj.isDetached());
        db.close(); // no flush where done
        assertTrue(obj.isDetached());

    }
}
