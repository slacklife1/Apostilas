package net.sourceforge.pain.db;

import junit.framework.*;
import net.sourceforge.pain.db.data.*;

import java.io.*;
import java.util.*;

/**
 * User: fmike  Date: Aug 26, 2003   Time: 3:30:29 AM
 */
public final class ClassStateTest extends TestCase {


    private PainDB db;

    public ClassStateTest() {
        super("ClassStateTest");
    }

    protected void setUp() throws Exception {
        db = new PainDB(getName() + ".db");
        db.ALLOW_PLAIN_WRITE = true; // allow work without transactions
        db.MANUAL_FLUSH_MODE = true; // commit will not flush (objects stays dirty)

    }

    protected void tearDown() throws Exception {
        if (db != null) {
            File file = new File(db.getDbFileName());
            if (!db.isClosed()) {
                db.forceClose();
            }

            db = null;
            file.delete();
        }
    }

    /**
     * create object, delete class, commit, ensure that obj is detached
     */
    public void testState1() throws Exception {
        db.beginTransaction();
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        DbClass dbClass = obj.getDbClass();
        dbClass.delete();
        assertTrue(obj.isDeleted());
        db.commitTransaction();
        assertTrue(obj.isDetached());
        assertNull(db.getDbClass(obj.getClass()));
    }

    /**
     * create object, rollback, ensure that obj is detached
     */
    public void testState2() {
        db.beginTransaction();
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        DbClass dbClass = obj.getDbClass();
        Object classId = dbClass.getOid();
        Object oid = obj.getOid();
        assertTrue(obj.isNew());
        assertSame(obj, db.getObject(oid));
        assertSame(dbClass, db.getClass(classId));
        db.rollbackTransaction();
        assertNull(db.getObject(oid));
        assertNull(db.getClass(classId));
        assertNull(db.getDbClass(obj.getClass()));
        assertTrue(obj.isDetached());
    }

    /**
     * create object, delete class, rollback, ensure that obj is detached
     */
    public void testState3() {
        db.beginTransaction();
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        DbClass dbClass = obj.getDbClass();
        Object classId = dbClass.getOid();
        Object oid = obj.getOid();
        dbClass.delete();
        assertTrue(obj.isDeleted());
        assertNull(db.getObject(oid));
        assertNull(db.getClass(classId));
        db.rollbackTransaction();
        assertNull(db.getObject(oid));
        assertNull(db.getClass(classId));
        assertNull(db.getDbClass(obj.getClass()));
    }

    /**
     * create object, rollback, ensure that new object creation will have new dbclass instance
     */
    public void testState4() throws Exception {
        db.beginTransaction();
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        DbClass dbClass1 = obj.getDbClass();
        db.rollbackTransaction();
        assertTrue(obj.isDetached());

        db.beginTransaction();
        obj = new AllFieldTypesObject(db);
        final DbClass dbClass2 = obj.getDbClass();
        assertNotSame(dbClass2, dbClass1);
        assertTrue(obj.isNew());
        db.commitTransaction();

        db.beginTransaction();
        obj = new AllFieldTypesObject(db);
        assertSame(obj.getDbClass(), dbClass2);
        db.commitTransaction();

    }

    /**
     * create object, commit, new trans, delete class, rollback, ensure that class is alive
     */
    public void testState5() throws Exception {
        db.beginTransaction();
        AllFieldTypesObject obj = new AllFieldTypesObject(db);
        DbClass dbClass1 = obj.getDbClass();
        db.commitTransaction();
        assertTrue(obj.isDirty());

        db.beginTransaction();
        dbClass1.delete();
        assertTrue(obj.isDeleted());
        db.rollbackTransaction();

        db.beginTransaction();
        assertTrue(obj.isDirty());
        assertSame(dbClass1, obj.getDbClass());
        assertSame(db.getDbClass(obj.getClass()), dbClass1);
        db.commitTransaction();
    }

    public void testWeakExtentIterator1() throws IOException {
        db.beginTransaction();
        AllFieldTypesObject obj1 = new AllFieldTypesObject(db);
        AllFieldTypesObject obj2 = new AllFieldTypesObject(db);
        AllFieldTypesObject obj3 = new AllFieldTypesObject(db);
        Iterator it = obj1.getDbClass().extentIterator(true);
        assertTrue(it.hasNext());
        assertEquals(obj1, it.next());
        obj2.delete();
        assertTrue(it.hasNext());
        assertEquals(obj3, it.next());
        assertFalse(it.hasNext());
        db.commitTransaction();
    }

    public void testWeakExtentIterator2() throws IOException {
        AllFieldTypesObject obj1 = new AllFieldTypesObject(db);
        AllFieldTypesObject obj2 = new AllFieldTypesObject(db);
        AllFieldTypesObject obj3 = new AllFieldTypesObject(db);

        db.beginTransaction();
        Iterator it = obj1.getDbClass().extentIterator(true);
        assertTrue(it.hasNext());
        assertEquals(obj1, it.next());
        obj2.delete();
        assertTrue(it.hasNext());
        assertEquals(obj3, it.next());
        assertFalse(it.hasNext());
        db.commitTransaction();
        assertFalse(it.hasNext());
    }

    public void testWeakExtentIterator3()  {
        AllFieldTypesObject obj1 = new AllFieldTypesObject(db);
        AllFieldTypesObject obj2 = new AllFieldTypesObject(db);
        AllFieldTypesObject obj3 = new AllFieldTypesObject(db);

        db.beginTransaction();
        Iterator it = obj1.getDbClass().extentIterator(true);
        assertTrue(it.hasNext());
        assertEquals(obj1, it.next());
        obj2.delete();
        assertTrue(it.hasNext());
        assertEquals(obj3, it.next());
        assertFalse(it.hasNext());
        db.rollbackTransaction();

        assertTrue(it.hasNext());//removed object restored
        assertEquals(obj2, it.next());
        assertFalse(it.hasNext());
        AllFieldTypesObject obj4 = new AllFieldTypesObject(db);
        assertTrue(it.hasNext());//removed object restored
        assertEquals(obj4, it.next());
        assertFalse(it.hasNext());
    }

}
