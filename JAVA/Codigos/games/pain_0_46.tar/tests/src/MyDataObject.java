
import net.sourceforge.pain.db.*;

import java.util.*;

/**
 * Any subclass of DbObject is persistent object
 */
public class MyDataObject extends DbObject {

    /**
     * This constructor is used by PAiN DB during startup.
     * No field access allowed from it.
     */
    public MyDataObject() {
    }

    /**
     * This constructor is used by user for new objects creation
     * object is atteched to given database.
     * Object schema is automatically imported to db
     */
    public MyDataObject(PainDB db) throws RuntimeException {
        super(db);
    }

    /**
     * method called by database every time new class added to database
     * (one per class)
     */
    public static DbClassSchema provideSchema() {
        byte[] types = new byte[3];
        String[] names = new String[3];

        types[0] = DbType.INT;
        names[0] = "my_int_field";

        types[1] = DbType.STRING;
        names[1] = "my_string_field";

        types[2] = DbType.REFERENCE_SET;
        names[2] = "my_references";

        return new DbClassSchema(types, names);
    }

    public int getMyIntField() {
        return getInt(0);
    }

    public void setMyIntField(int value) {
        setInt(0, value);
    }

    public String getMyStringField() {
        return getString(1);
    }

    public void setMyStringField(String value) {
        setString(1, value);
    }

    public Set getMyReferences() {
        return getRefSet(2);
    }
}
