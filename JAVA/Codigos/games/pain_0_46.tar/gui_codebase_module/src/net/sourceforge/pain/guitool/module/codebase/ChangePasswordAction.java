package net.sourceforge.pain.guitool.module.codebase;

import net.sourceforge.pain.guitool.*;
import net.sourceforge.pain.network.guitool.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * User: fmike  Date: Jun 20, 2004  Time: 9:36:49 PM
 */
public class ChangePasswordAction extends AbstractAction {
    public ChangePasswordAction() {
        super("Change password");
    }

    public void actionPerformed(ActionEvent e) {
        new ChangePassPerformer().changePass();
    }
}


class ChangePassDialog extends JDialog {
//    JPanel panel = new JPanel();
    JPasswordField oldPassField = new JPasswordField();
    JPasswordField newPassField = new JPasswordField();
    JPasswordField repeatNewPassField = new JPasswordField();
    JLabel oldPassLabel = new JLabel();
    JLabel newPassLabel = new JLabel();
    JLabel repeatPassLabel = new JLabel();
    JToggleButton cancelButton = new JToggleButton();
    JToggleButton changeButton = new JToggleButton();

    public ChangePassDialog(Frame frame) {
        super(frame, "Change password", true);
        jbInit();
    }


    private void jbInit() {
        this.getContentPane().setLayout(null);

        oldPassLabel.setFont(new java.awt.Font("Dialog", 1, 12));
        oldPassLabel.setText("Old password");
        oldPassLabel.setBounds(new Rectangle(14, 18, 110, 18));
        newPassLabel.setBounds(new Rectangle(14, 48, 110, 18));
        newPassLabel.setText("New password");
        newPassLabel.setFont(new java.awt.Font("Dialog", 1, 12));
        repeatPassLabel.setBounds(new Rectangle(14, 79, 110, 18));
        repeatPassLabel.setText("Repeat password");
        repeatPassLabel.setFont(new java.awt.Font("Dialog", 1, 12));

        oldPassField.setText("");
        oldPassField.setBounds(new Rectangle(118, 18, 109, 21));

        newPassField.setText("");
        newPassField.setBounds(new Rectangle(118, 48, 109, 21));

        repeatNewPassField.setText("");
        repeatNewPassField.setBounds(new Rectangle(118, 79, 109, 21));

        cancelButton.setBorder(BorderFactory.createEtchedBorder());
        cancelButton.setText("Cancel");
        cancelButton.setBounds(new Rectangle(25, 110, 83, 23));

        changeButton.setBorder(BorderFactory.createEtchedBorder());
        changeButton.setText("Change");
        changeButton.setBounds(new Rectangle(144, 110, 83, 23));

        final Container contentPane = getContentPane();
        contentPane.setBounds(0, 0, 240, 175);
        contentPane.add(changeButton, null);
        contentPane.add(oldPassLabel, null);
        contentPane.add(newPassLabel, null);
        contentPane.add(repeatPassLabel, null);
        contentPane.add(newPassField, null);
        contentPane.add(oldPassField, null);
        contentPane.add(repeatNewPassField, null);
        contentPane.add(cancelButton, null);
        setBounds(contentPane.getBounds());
    }
}


class ChangePassPerformer {
    ChangePassDialog d;

    public void changePass() {
        d = new ChangePassDialog(GUITool.appFrame);
        initDialog();
        d.show();
        d.dispose();

    }

    private void initDialog() {
        ChangePassPerformer.MyButtonListener bl = new MyButtonListener();
        d.cancelButton.addActionListener(bl);
        d.changeButton.addActionListener(bl);
        d.setLocationRelativeTo(null);   //center of the screen

        MyKeyListener kl = new MyKeyListener();
        d.cancelButton.addKeyListener(kl);
        d.changeButton.addKeyListener(kl);
        d.oldPassField.addKeyListener(kl);
        d.newPassField.addKeyListener(kl);
        d.repeatNewPassField.addKeyListener(kl);
    }

    private class MyButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            final Object source = e.getSource();
            if (source == d.cancelButton) {
                d.hide();
            } else if (source == d.changeButton && _changePass()) {
                d.hide();
            }
        }


    }

    private void onPassChanged() {
        final String message = "Password changed";
        GUITool.log(message);
        JOptionPane.showMessageDialog(d, message);
    }

    private boolean _changePass() {
        try {
            String oldPass = new String(d.oldPassField.getPassword());
            String newPass = new String(d.newPassField.getPassword());
            String repreatNewPass = new String(d.repeatNewPassField.getPassword());
            if (oldPass.length() == 0) {
                JOptionPane.showMessageDialog(d, "Old pass is empty", "Error", JOptionPane.ERROR_MESSAGE);
                d.oldPassField.requestFocus();
                return false;
            }
            if (newPass.length() < 5) {
                JOptionPane.showMessageDialog(d, newPass.length() == 0 ? "New pass is empty" : "New pass is too short", "Error", JOptionPane.ERROR_MESSAGE);
                d.newPassField.requestFocus();
                return false;
            }

            if (!repreatNewPass.equals(newPass)) {
                JOptionPane.showMessageDialog(d, "Repeat password error", "Error", JOptionPane.ERROR_MESSAGE);
                d.repeatNewPassField.requestFocus();
                return false;
            }
            GTNetPacket reply = GTMessenger.sendBlocking(new GTNetPacket("ChangePassword", new String[]{oldPass, newPass}));
            if (reply.data.equals("OK")) {
                onPassChanged();
                return true;
            } else {
                JOptionPane.showMessageDialog(d, reply.data, "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private class MyKeyListener implements KeyListener {
        boolean myPress = false;

        public void keyPressed(KeyEvent e) {
            myPress = true;
        }

        public void keyReleased(KeyEvent e) {
            if (myPress) {
                myPress = false;
                final int keyCode = e.getKeyCode();
                if (keyCode == KeyEvent.VK_ESCAPE) {
                    e.consume();
                    d.hide();
                } else if (keyCode == KeyEvent.VK_ENTER) {
                    e.consume();
                    if (_changePass()) {
                        d.hide();
                    }
                }
            }
        }

        public void keyTyped(KeyEvent e) {
        }
    }
}
