package net.sourceforge.pain.guitool.module.codebase;

import net.sourceforge.pain.guitool.*;
import net.sourceforge.pain.network.guitool.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import javax.swing.text.html.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.List;
import java.util.Map;

/**
 * User: fmike  Date: Jun 24, 2004  Time: 1:18:54 AM
 */
public class ServerStatusWorkspaceItem implements GTWorkspaceItem {
    private static ServerStatusWorkspaceItem instance;
    public static final String name = "Server status";

    private JEditorPane pane;

    public ServerStatusWorkspaceItem() throws IOException, BadLocationException {
        pane = HTMLComponentsRegistry.get(ServerStatusWorkspaceItem.class);
        pane.addHyperlinkListener(new MyHyperlinkListenerImpl());
    }

    public static ServerStatusWorkspaceItem instance() throws Exception {
        if (instance == null) {
            instance = new ServerStatusWorkspaceItem();
        }
        return instance;
    }


    void refresh() {
        GUITool.log("refreshing server status info");
        try {
            GTNetPacket response = GTMessenger.sendBlocking(new GTNetPacket("ServerStatus", ""));
            Map map = (Map) response.data;
            HTMLDocument doc = (HTMLDocument) pane.getDocument();
            for (Iterator it = map.keySet().iterator(); it.hasNext();) {
                String key = (String) it.next();
                String value = (String) map.get(key);
                javax.swing.text.Element e = doc.getElement(key);
                if (e == null) {
                    GUITool.log("unknown status property:" + key);
                } else {
                    doc.setInnerHTML(e, value);
                }
            }
        } catch (Exception e) {
            GTErrorDialog.showError(e);
        }
    }


    public Component getComponent() {
        return pane;
    }

    public String getDisplayName() {
        return name;
    }

    public void onClosing() {
        //do nothing
    }

    public GTModule getOwnerModule() {
        return CodebaseGTModule.instance();
    }

    private class MyHyperlinkListenerImpl implements HyperlinkListener {
        public void hyperlinkUpdate(HyperlinkEvent ev) {
            if (ev.getEventType() != HyperlinkEvent.EventType.ACTIVATED) {
                return;
            }
            try {
                final String urlStr = ev.getURL().toString();
                if (urlStr.endsWith("/update")) {
                    refresh();
                } else if (urlStr.endsWith("/reload")) {
                    try {
                        if (JOptionPane.YES_OPTION == JOptionPane.showConfirmDialog(pane, "Reload logic code?", "Select an option:", JOptionPane.YES_NO_OPTION)) {
                            GUITool.log("ReloadCode: start");
                            GTNetPacket p = GTMessenger.sendBlocking(new GTNetPacket("ReloadLogicGTEvent", new String[]{"reload"}));
                            GUITool.log("ReloadCode: " + p.data);
                            JOptionPane.showMessageDialog(pane, "Code reloading status:" + (String) p.data);
                        }
                    } catch (Exception e) {
                        GTErrorDialog.showError(e);
                    }
                } else if (urlStr.endsWith("/shutdown")) {
                    try {
                        if (JOptionPane.YES_OPTION == JOptionPane.showConfirmDialog(pane, "Shutdown Server? (Server could not be started from GuiTool)", "Select an option:", JOptionPane.YES_NO_OPTION)) {
                            GUITool.log("ShutdownServer: start");
                            GTNetPacket p = GTMessenger.sendBlocking(new GTNetPacket("RestartGTEvent", new String[]{"shutdown"}));
                            GUITool.log("ShutdownServer: " + p.data);
                            JOptionPane.showMessageDialog(pane, "ServerShutdown status:" + (String) p.data);
                        }
                    } catch (Exception e) {
                        GTErrorDialog.showError(e);
                    }
                } else {
                    GTErrorDialog.showError("Unknown action:" + urlStr);
                }
            } catch (IllegalStateException e) {
                GTErrorDialog.showError(e);
            }
        }
    }
}

class ServerStatusAction extends GTExplorerActionNode {
    public ServerStatusAction() {
        super(ServerStatusWorkspaceItem.name);
    }

    public List getChildNodes() {
        return null;
    }

    public void actionPerformed(ActionEvent e) {
        final ServerStatusWorkspaceItem item;
        try {
            item = ServerStatusWorkspaceItem.instance();
        } catch (Exception e1) {
            throw new RuntimeException(e1);
        }
        item.refresh();
        GUITool.getWorkspace().addWorkspaceItem(item);
    }
}