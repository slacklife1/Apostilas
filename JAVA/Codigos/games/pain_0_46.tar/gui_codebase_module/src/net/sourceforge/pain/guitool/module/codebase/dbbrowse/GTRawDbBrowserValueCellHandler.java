package net.sourceforge.pain.guitool.module.codebase.dbbrowse;

import net.sourceforge.pain.db.*;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;

/**
 * User: fmike  Date: Feb 23, 2004  Time: 2:06:00 AM
 */
public class GTRawDbBrowserValueCellHandler extends AbstractCellEditor implements TableCellRenderer, TableCellEditor {
    private GTRawDbBrowser owner;

    class CellWidget {
        JPanel panel = new JPanel(new GridBagLayout());
        JPanel upPanel = new JPanel(new GridBagLayout());
        JButton button = new JButton();
        JTextArea text = new JTextArea();
        JPanel detailedPanel = new JPanel(new GridBagLayout());
    }

    CellWidget render = new CellWidget();
    CellWidget edit = new CellWidget();

    final Font BUTTON_FONT = new Font("Arial", Font.CENTER_BASELINE, 9);
    final Insets ZERO_INSETS = new Insets(0, 0, 0, 0);

    private GridBagConstraints constraints = new GridBagConstraints();

    public GTRawDbBrowserValueCellHandler(GTRawDbBrowser owner) {
        this.owner = owner;

        constraints.gridheight = 1;
        constraints.gridwidth = 1;
        constraints.insets = new Insets(0, 0, 0, 0);
        constraints.anchor = GridBagConstraints.FIRST_LINE_START;
        constraints.weightx = 1;


        initCellWidget(render);
        initCellWidget(edit);
        edit.button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onEditButtonClick();
            }
        });

    }

    private void initCellWidget(CellWidget cw) {
        cw.button.setFont(BUTTON_FONT);
        cw.button.setMargin(ZERO_INSETS);
        applyTextAreaParams(cw.text);

        cw.detailedPanel.setBorder(null);
        cw.detailedPanel.setOpaque(false);
        cw.upPanel.setBorder(null);
        cw.upPanel.setOpaque(false);
        constraints.gridx = 0;
        constraints.gridy = 0;
        cw.upPanel.add(cw.text, constraints);
        constraints.gridx = 1;
        cw.upPanel.add(cw.button, constraints);

        cw.panel.setBorder(null);
        constraints.gridx = 0;
        constraints.gridy = 0;
        cw.panel.add(cw.upPanel, constraints);
    }

    private static void applyTextAreaParams(JTextArea text) {
        text.setBorder(null);
        text.setEditable(false);
        text.setLineWrap(true);
        text.setWrapStyleWord(true);
        text.setMargin(new Insets(0, 0, 0, 0));
        text.setOpaque(false);
    }


    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        //System.out.println("GTRawDbBrowserValueCellHandler.getTableCellRendererComponent");
        return getTableCellComponent(render, value, table, row, isSelected);
    }

    private void recreateComponentContent(CellWidget c, FieldInfo info) {
        if (c.detailedPanel.isVisible()) {
            c.detailedPanel.setVisible(false);
            c.panel.remove(c.detailedPanel);
            c.detailedPanel.removeAll();
        }
        boolean collection = false;
        if (info.type == DbType.REFERENCE) {
            c.button.setText(">>");
            c.button.setEnabled(info.value != null);
            c.button.setVisible(true);
            c.text.setText("" + (String) info.value);
        } else if (DbType.isArray(info.type) || (collection = DbType.isCollection(info.type))) {
            int len = collection ? info.getValueCollectionLength() : info.getValueArrLength();
            c.button.setText(info.detailedView ? " - " : " + ");
            c.button.setEnabled(info.value != null && len != 0);
            c.button.setVisible(true);
            c.text.setText(info.value == null ? "null" : len + " items");

            if (info.detailedView && len > 0) {
                for (int i = 0; i < len; i++) {
                    JPanel p = new JPanel(new GridBagLayout());
                    p.setOpaque(false);
                    p.setBorder(null);
                    JTextArea editA = new JTextArea();
                    applyTextAreaParams(editA);
                    JComponent editB;
                    if (collection) {
                        if (info.type == DbType.LINKED_LIST || info.type == DbType.ARRAY_LIST || info.type == DbType.REFERENCE_SET) {
                            editA.setText("" + i);
                        } else {
                            editA.setText(""+info.getCollectionElement1(i));

                        }
                        if (info.type == DbType.STRING_MAP || info.type == DbType.STRING_SET) {
                            JTextArea textB = new JTextArea();
                            applyTextAreaParams(textB);
                            textB.setText("" + info.getCollectionElement2(i));
                            editB = textB;
                        } else {
                            final String oid = "" + info.getCollectionElement2(i);
                            JButton b = new JButton(oid);
                            b.setFont(BUTTON_FONT);
                            b.setMargin(ZERO_INSETS);
                            if (oid.length() == 0) {
                                b.setEnabled(false);
                            } else {
                                b.addActionListener(new ActionListener() {
                                    public void actionPerformed(ActionEvent e) {
                                        gotoReference(oid);
                                    }
                                });
                            }
                            editB = b;
                        }
                    } else { //array
                        editA.setText("" + i);
                        JTextArea textB = new JTextArea();
                        applyTextAreaParams(textB);
                        textB.setText(info.getValueArrElement(i));
                        editB = textB;
                    }
                    constraints.gridx = 0;
                    constraints.gridy = 0;
                    p.add(editA, constraints);
                    constraints.gridx = 1;
                    p.add(editB, constraints);
                    constraints.gridx = 0;
                    constraints.gridy = i;
                    c.detailedPanel.add(p, constraints);
                }
                constraints.gridx = 0;
                constraints.gridy = 1;
                c.panel.add(c.detailedPanel, constraints);
                c.detailedPanel.setVisible(true);
            }
        } else {
            c.button.setVisible(false);
            c.text.setText((String) info.value);
        }
    }

    private Component getTableCellComponent(CellWidget c, Object value, JTable table, int row, boolean isSelected) {
        //System.out.println("GTRawDbBrowserValueCellHandler.getTableCellComponent: sel:"+isSelected);
        recreateComponentContent(c, (FieldInfo) value);
        int h = c.panel.getPreferredSize().height;
        if (table.getRowHeight(row) != h) {
            table.setRowHeight(row, h);
        }
        if (isSelected) {
            c.panel.setForeground(table.getSelectionForeground());
            c.panel.setBackground(table.getSelectionBackground());
        } else {
            c.panel.setForeground(table.getForeground());
            c.panel.setBackground(table.getBackground());
        }
        return c.panel;
    }


    /// -- cell editor --//
    FieldInfo editInfo;

    private void onEditButtonClick() {
        if (editInfo.type == DbType.REFERENCE) {
            gotoReference((String) editInfo.value);
        } else if (editInfo.isArray() || editInfo.isCollection()) {
            editInfo.detailedView = !editInfo.detailedView;
            stopCellEditing();
        }

    }

    private void gotoReference(String oid) {
        stopCellEditing();
        owner.executeQuery(oid);
    }


    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
        //System.out.println("GTRawDbBrowserValueCellHandler.getTableCellEditorComponent");
        editInfo = (FieldInfo) value;
        return getTableCellComponent(edit, value, table, row, true);
    }

    public Object getCellEditorValue() {
        return edit.panel;
    }

}