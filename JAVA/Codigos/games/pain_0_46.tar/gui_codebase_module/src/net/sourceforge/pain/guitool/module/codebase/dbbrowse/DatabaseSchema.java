package net.sourceforge.pain.guitool.module.codebase.dbbrowse;

import net.sourceforge.pain.network.guitool.*;

import java.util.*;

/**
 * User: fmike  Date: Apr 19, 2004  Time: 2:07:50 AM
 */
public class DatabaseSchema {
    private ArrayList classes = new ArrayList();

    public DatabaseSchema(GTNetPacket packet) {
        ArrayList pclasses = (ArrayList) packet.data;
        for (int i = 0; i < pclasses.size(); i++) {
            ArrayList classInfoData = (ArrayList) pclasses.get(i);
            final ClassInfo classInfo = new ClassInfo((String) classInfoData.get(0), (String[]) classInfoData.get(1), (byte[]) classInfoData.get(2));
            classes.add(classInfo);
        }
    }

    public ClassInfo findClassName(String className) {
        for (int i = 0; i < classes.size(); i++) {
            ClassInfo classInfo = (ClassInfo) classes.get(i);
            if (classInfo.className.endsWith(className)) {
                return classInfo;
            }
        }
        return null;
    }

    public class ClassInfo {
        private String className;
        private String[] fieldsNames;
        private byte[] fieldsTypes;

        public ClassInfo(String className, String[] names, byte[] types) {
            this.className = className;
            fieldsNames = names;
            fieldsTypes = types;
        }

        public int getFieldType(String fieldName) {
            for (int i = 0; i < fieldsNames.length; i++) {
                if (fieldName.equals(fieldsNames[i])) {
                    return fieldsTypes[i];
                }
            }
            return -1;
        }

    }
}
