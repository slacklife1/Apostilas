package net.sourceforge.pain.guitool.module.codebase;

import net.sourceforge.pain.guitool.*;

import javax.swing.*;
import javax.swing.text.*;
import javax.swing.text.html.*;
import java.io.*;
import java.util.*;

/**
 * User: fmike  Date: Jun 24, 2004  Time: 1:13:32 AM
 */
class HTMLComponentsRegistry {

    private HTMLComponentsRegistry() {
    }

    private static final HashMap componentByClass = new HashMap();
    private static StyleSheet commonStyleSheet = null;

    public static synchronized JEditorPane get(Class clazz) throws IOException, BadLocationException {
        JEditorPane instance = (JEditorPane) componentByClass.get(clazz);
        if (instance == null) {
            final String fileName = "/" + clazz.getName().replace('.', '/') + ".html";
            final byte[] bytes = GUITool.readResource(clazz, fileName);
            String text = bytes == null ? "resource not found: " + fileName : new String(bytes);
            instance = new JEditorPane();
            instance.setContentType("text/html");
            instance.setEditable(false);
            StyleSheet styles = getCommonStyleSheet();
            HTMLEditorKit kit = new HTMLEditorKit();
            kit.setStyleSheet(styles);
            Document doc = kit.createDefaultDocument();
            kit.read(new StringReader(text), doc, 0);
            instance.setDocument(doc);
        }
        return instance;
    }

    private static StyleSheet getCommonStyleSheet() throws IOException {
        if (commonStyleSheet == null) {
            commonStyleSheet = new StyleSheet();
            final byte[] bytes = GUITool.readResource(CodebaseGTModule.class, "/pain.css");
            if (bytes == null) {
                GTErrorDialog.showError("CodebaseModule: resource not found: pain.css");
            } else {
                commonStyleSheet.loadRules(new StringReader(new String(bytes)), null);
            }
        }
        return commonStyleSheet;
    }
}


