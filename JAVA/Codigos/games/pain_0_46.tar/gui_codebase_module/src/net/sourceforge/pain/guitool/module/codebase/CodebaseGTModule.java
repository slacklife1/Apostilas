package net.sourceforge.pain.guitool.module.codebase;

import net.sourceforge.pain.guitool.*;
import net.sourceforge.pain.guitool.module.codebase.dbbrowse.*;

import javax.swing.*;
import java.util.*;

/**
 * User: fmike  Date: Jun 20, 2004  Time: 8:00:23 PM
 */
public class CodebaseGTModule extends GTModule {

    final DBBrowseAction browseAction = new DBBrowseAction();
    final ServerStatusAction serverStatusAction = new ServerStatusAction();
    final AccountOptionsAction accountOptionsAction = new AccountOptionsAction();
    private static GTModule single;

    public CodebaseGTModule(GTModuleInfo moduleInfo) {
        super(moduleInfo);
        assert single == null;
        single = this;
    }

    public void onUnload() {
        //do nothing
    }

    public List getExplorerActionNodes() {
        List actionsList = new ArrayList();
        actionsList.add(browseAction);
        actionsList.add(serverStatusAction);
        actionsList.add(accountOptionsAction);
        return actionsList;
    }

    public JMenu getMainMenuItems() {
        JMenu menu = new JMenu("Codebase Tools");
        menu.add(new ChangePasswordAction());
        menu.add(browseAction);
        menu.add(serverStatusAction);
        menu.add(accountOptionsAction);
        return menu;
    }

    public static GTModule instance() {
        return single;
    }
}
