package net.sourceforge.pain.guitool.module.codebase;


import net.sourceforge.pain.guitool.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

/**
 * User: fmike  Date: Jun 24, 2004  Time: 10:05:05 PM
 */
public class AccountOptionsWorkspaceItem implements GTWorkspaceItem {

    private static AccountOptionsWorkspaceItem instance;
    public static final String name = "Account options";
    private JEditorPane pane;

    public AccountOptionsWorkspaceItem() throws IOException, BadLocationException {
        pane = HTMLComponentsRegistry.get(AccountOptionsWorkspaceItem.class);
        pane.addHyperlinkListener(new MyHyperlinkListenerImpl());

    }

    public static AccountOptionsWorkspaceItem instance() throws Exception {
        if (instance == null) {
            instance = new AccountOptionsWorkspaceItem();
        }
        return instance;
    }


    private void showChangePassDialog() {
        GUITool.log("change pass");
        new ChangePassPerformer().changePass();
    }


    // GTWorkspaceItem impl
    public String getDisplayName() {
        return name;
    }

    public void onClosing() {
        //do nothing
    }

    public GTModule getOwnerModule() {
        return CodebaseGTModule.instance();
    }

    public Component getComponent() {
        return instance.pane;
    }


    final class MyHyperlinkListenerImpl implements HyperlinkListener {
        public void hyperlinkUpdate(HyperlinkEvent ev) {
            if (ev.getEventType() != HyperlinkEvent.EventType.ACTIVATED) {
                return;
            }
            showChangePassDialog();
        }
    }

}

class AccountOptionsAction extends GTExplorerActionNode {
    public AccountOptionsAction() {
        super(AccountOptionsWorkspaceItem.name);
    }

    public java.util.List getChildNodes() {
        return null;
    }

    public void actionPerformed(ActionEvent e) {
        final AccountOptionsWorkspaceItem item;
        try {
            item = AccountOptionsWorkspaceItem.instance();
        } catch (Exception e1) {
            throw new RuntimeException(e1);
        }
        GUITool.getWorkspace().addWorkspaceItem(item);
    }
}
