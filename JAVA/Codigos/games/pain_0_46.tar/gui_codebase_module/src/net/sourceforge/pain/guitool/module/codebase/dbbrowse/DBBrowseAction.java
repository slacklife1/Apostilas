package net.sourceforge.pain.guitool.module.codebase.dbbrowse;

import net.sourceforge.pain.guitool.*;
import net.sourceforge.pain.guitool.module.codebase.*;

import java.awt.*;
import java.awt.event.*;
import java.util.List;

/**
 * User: fmike  Date: Jun 21, 2004  Time: 1:14:20 AM
 */
public class DBBrowseAction extends GTExplorerActionNode {
    public DBBrowseAction() {
        super("Raw database browser");
    }

    public void actionPerformed(ActionEvent e) {
        GUITool.getWorkspace().addWorkspaceItem(new GTWorkspaceItem() {
            Component c;

            public String getDisplayName() {
                return "Database browser";
            }

            public Component getComponent() {
                if (c == null) {
                    c = GTRawDbBrowser.instance();
                }
                return c;
            }

            public void onClosing() {
            }

            public GTModule getOwnerModule() {
                return CodebaseGTModule.instance();
            }
        });
    }

    public List getChildNodes() {
        return null;
    }
}
