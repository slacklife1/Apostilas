package net.sourceforge.pain.guitool.module.codebase.dbbrowse;

import net.sourceforge.pain.db.*;

/**
 * User: fmike  Date: Feb 24, 2004  Time: 1:20:06 AM
 */
public class FieldInfo {
    String name;
    int type;
    Object value;
    boolean detailedView = false;

    public FieldInfo(String name, int type, Object value) {
        this.name = name;
        this.type = type;
        this.value = value;
    }

    public String getTypeName() {
        return DbType.name(type);
    }

    public int getValueArrLength() {
        if (value == null) {
            return 0;
        }
        if (type == DbType.ARRAY_OF_BYTE) {
            return ((byte[]) value).length;
        } else if (type == DbType.ARRAY_OF_CHAR) {
            return ((char[]) value).length;
        } else if (type == DbType.ARRAY_OF_INT) {
            return ((int[]) value).length;
        } else if (type == DbType.ARRAY_OF_STRING) {
            return ((String[]) value).length;
        }
        throw new RuntimeException("not array!");
    }

    public boolean isArray() {
        return DbType.isArray(type);
    }

    public String getValueArrElement(int i) {
        if (type == DbType.ARRAY_OF_BYTE) {
            return "" + ((byte[]) value)[i];
        } else if (type == DbType.ARRAY_OF_CHAR) {
            return "" + ((char[]) value)[i];
        } else if (type == DbType.ARRAY_OF_INT) {
            return "" + ((int[]) value)[i];
        } else if (type == DbType.ARRAY_OF_STRING) {
            return "" + ((String[]) value)[i];
        }
        throw new RuntimeException("not array!");
    }

    public Object getCollectionElement1(int i) {
        Object[] v = (Object[]) value;
        if (type == DbType.REFERENCE_SET || type == DbType.STRING_SET || type == DbType.LINKED_LIST || type == DbType.ARRAY_LIST) {
              return  v[i];
        } else {
            return  ((Object[]) v[0])[i];
        }
    }

    public Object getCollectionElement2(int i) {
        Object[] v = (Object[]) value;
        if (type == DbType.REFERENCE_SET || type == DbType.STRING_SET || type == DbType.LINKED_LIST || type == DbType.ARRAY_LIST) {
            return  v[i];
        } else {
            return ((Object[]) v[1])[i];
        }
    }

    public int getValueCollectionLength() {
        if (value == null) {
            return 0;
        }
        if (type == DbType.REFERENCE_SET || type == DbType.STRING_SET || type == DbType.LINKED_LIST || type == DbType.ARRAY_LIST) {
            return ((Object[]) value).length;
        } else {
            return ((Object[]) ((Object[]) value)[0]).length;
        }
    }

    public boolean isCollection() {
        return DbType.isCollection(type);
    }


}
