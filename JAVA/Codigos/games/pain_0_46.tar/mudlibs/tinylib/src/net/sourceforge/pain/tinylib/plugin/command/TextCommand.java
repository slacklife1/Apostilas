package net.sourceforge.pain.tinylib.plugin.command;

/**
 * TextCommand class is very simple
 * it contains command to class name(command handler) mapping
 * command mapping is loaded during startup (to build shortcut map)
 * if command class is null default classname will be used:COMMAND_PACKAGE+Command
 * Tag is any string parameter, transparently transported to command hanler
 */
public final class TextCommand {

    public final String commandClassName;
    public final String name; //unique key for all commands
    public final String tag;

    public TextCommand(String name, String className, String tag) {
        this.name = name.toLowerCase();
        this.commandClassName = className;
        this.tag = tag;
    }


    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof TextCommand)) {
            return false;
        }
        TextCommand c = (TextCommand) obj;
        return name.equals(c.name);
    }

    public int hashCode() {
        return (name != null ? name.hashCode() : 0);
    }
}

