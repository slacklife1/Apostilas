package net.sourceforge.pain.tinylib.logic.factory;

import net.sourceforge.pain.tinylib.data.type.*;


public final class PlayerFactory {


    public static void destroy(Player player) {
        Player prev = player.getPrevActivePlayer();
        if (prev != null) {
            Player next = player.getNextActivePlayer();
            prev.setNextActivePlayer(next);
            if (next != null) {
                next.setPrevActivePlayer(prev);
                player.setNextActivePlayer(null);
            }
            player.setPrevActivePlayer(null);
        }
    }

}