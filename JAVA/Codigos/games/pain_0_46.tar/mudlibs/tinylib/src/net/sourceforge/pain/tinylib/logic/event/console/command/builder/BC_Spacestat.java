package net.sourceforge.pain.tinylib.logic.event.console.command.builder;


import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;
import net.sourceforge.pain.tinylib.util.*;

/**
 * PAiN  Date: 05.06.2003  Time: 1:40:02
 */
public final class BC_Spacestat extends BuilderCommand {

    public void processBuilderCommand(BuilderShell p, String args) throws Exception {
        final Console console = p.console;
        final Room room;
        final Space space;
        if (args != null) {
            room = (Room) Mudlib.getWorld().getRoomsByIdMap().get(args);
            if (room == null) {
                MessageOutFn.outln(p.console, "No room found:" + args);
                return;
            }
            space = room.asSpace();
        } else {
            Located l = console.getPlayer().asLocated();
            space = l.getLocation();
            room = (Room) space.getRole(Room.class);
        }
        MessageOutFn.outln(console, "Room ID:{W" + (room == null ? " NONE" : room.getRoomUniqueId()) + "{x");
        MessageOutFn.outln(console, "Space :{Y" + space.getName() + "{x");
        MessageOutFn.outln(console, "Detailed desc:{C<<{x" + space.getDesc() + "{C>>{x");
        MessageOutFn.outln(console, "Capacity:{C" + space.getCapacity() + "{x");
        // exits
        if (room != null) {
            MessageOutFn.outln(console, "Exits info:");
            int nExists = 0;
            for (int i = Room.FIRST_DIR; i <= Room.LAST_DIR; i++) {
                Exit exit = room.getExit(i);
                if (exit != null) {
                    nExists++;
                    Room targetSpace = exit.getTargetRoom();
                    if (targetSpace == null) {
                        MessageOutFn.outln(console, "{R BUG:exit has no target space:" + LangUtil.exitName[i] + "{x");
                    } else {
                        MessageOutFn.outln(console, LangUtil.exitName[i] + ":" + targetSpace.asSpace().getName());
                    }
                }
            }
            if (nExists == 0) {
                MessageOutFn.outln(console, "No exists found");
            }

        } else {
            MessageOutFn.outln(console, "Space has not exits");
        }
        // in space:
        MessageOutFn.outln(console, "Content:");
        for (Located obj = space.getFirstInSpace(); obj != null; obj = obj.getNextInSpace()) {
            if (obj.is(Physical.class)) {
                final Interactive inter = ((Interactive) obj.getRole(Interactive.class));
                MessageOutFn.outln(console, "\tPhysical:" + inter.getName() + " target list:" + TargetList.string(inter.getTargetList()));
            } else if (obj.is(Interactive.class)) {
                Interactive inter = (Interactive) obj.getRole(Interactive.class);
                MessageOutFn.outln(console, "\tInteractive:" + inter.getName() + " target list:" + TargetList.string(inter.getTargetList()));
            } else if (obj.is(SpaceReset.class)) {
                PrototypeInfo proto = ((SpaceReset)obj.getRole(SpaceReset.class)).getResettedPrototype();
                if (proto != null) {
                    MessageOutFn.outln(console, "\tResetted prototype:" + proto.getVnum() + " name:" + proto.getName());
                } else {
                    MessageOutFn.outln(console, "{\t{R WARN:{x reset with no prototype!");
                }
            } else {
                MessageOutFn.outln(console, "\t" + obj.getOid());//todo
            }
        }

    }

    public void showHelp(Console console) {
        MessageOutFn.outln(console, "Builder command STAT shows various stats of the current space");
        MessageOutFn.outln(console, "Usage: stat");
    }

}



