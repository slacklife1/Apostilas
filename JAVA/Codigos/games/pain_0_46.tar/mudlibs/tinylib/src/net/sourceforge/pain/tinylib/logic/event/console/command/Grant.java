package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;
import net.sourceforge.pain.tinylib.plugin.command.*;

import java.util.*;

public final class Grant extends GrantedCommand {

    public void processCommand() throws Exception {
        String text = commandParams == null ? "" : commandParams.trim();
        int spaceIndex = text.indexOf(' ');
        if (spaceIndex < 1) {
            MessageOutFn.outln(console, "ERROR:Grant whom what?");
            return;
        }
        String playerName = text.substring(0, spaceIndex);
        final String commandName = text.substring(spaceIndex).trim();
        if (text.length() == 0) {
            MessageOutFn.out(console, "ERROR:Grant what?");
            return;
        }
        Player target = ("self".equals(playerName)) ? player : GlobalFindFn.findPlayerByName(playerName);
        if (target == null) {
            MessageOutFn.outln(console, "No player found with name {c" + Utils.formatName(playerName) + "{x");
            return;
        }

        final boolean isGrant = isGrant();
        final boolean isUngrant = isUNGrant();
        final boolean isReject = isReject();
        final boolean isUnreject = isGrant || isUngrant || isReject ? false : true;

        final Set commandSet = (isGrant || isUNGrant()) ? target.getGrantedCommands() : target.getRejectedCommands();

        CommandMapper commandMapper = ConsoleInputEvent.getCommandMapper();
        TextCommand textCommand = commandMapper.findCommand(commandName);
        if (textCommand == null || ShowCommandTag.class.getName().endsWith(textCommand.commandClassName)) {
            MessageOutFn.outln(console, "Command not found:" + commandName);
            return;
        }
        if (textCommand.name.length() != commandName.length()) {
            MessageOutFn.outln(console, "You should specify full command name:" + commandName);
            return;
        }
        if (isUnreject) {
            removeReject(commandSet, textCommand);
            return;
        }
        final CommandHandler ch = ConsoleInputEvent.instantiateCommandHandler(textCommand.commandClassName);
        ch.player = target;
        if (isGrant) {
            if (!(ch instanceof GrantedCommand)) {
                MessageOutFn.outln(console, "ERROR:Not a grantable command:{c" + textCommand.name + "{x");
                return;
            }
            ((GrantedCommand) ch).onGrantAdded();
            commandSet.add(textCommand.commandClassName);
            MessageOutFn.outln(console, "Done.");
        } else if (isReject) {
            commandSet.add(textCommand.commandClassName);
            MessageOutFn.outln(console, "Done.");
        } else { //ungrant
            ungrant(ch, commandSet, textCommand);
        }


    }

    private void ungrant(CommandHandler ch, final Set commandSet, TextCommand textCommand) throws Exception {
        if (ch instanceof GrantedCommand) {
            if (commandSet.remove(textCommand.commandClassName)) {
                ((GrantedCommand) ch).onGrantRemoved();
                MessageOutFn.outln(console, "Grant removed: {c" + textCommand.name + "{x");
            } else {
                MessageOutFn.outln(console, "ERROR:No grant found: {c" + textCommand.name + "{x");
            }
        } else {
            MessageOutFn.outln(console, "ERROR:Not a grantable command: {c" + textCommand.name + "{x");
        }
    }

    private void removeReject(final Set commandSet, TextCommand textCommand) {
        boolean removed = commandSet.remove(textCommand.commandClassName);
        if (removed) {
            MessageOutFn.outln(console, "Done. Command is not more in rejection list:{c" + textCommand.name + "{x");
        } else {
            MessageOutFn.outln(console, "ERROR: Command is not in rejection list:{c" + textCommand.name + "{x");
        }
    }

    public void showHelp() {
        if (isGrant()) {
            MessageOutFn.outln(console, command.name + ": adds granted commands to player");
            MessageOutFn.outln(console, "Usage: " + command.name + " <player_name> <grantable_command>");
        } else if (isUNGrant()) {
            MessageOutFn.outln(console, command.name + ": removes granted commands from player");
            MessageOutFn.outln(console, "Usage: " + command.name + " <player_name> <grantable_command>");
        } else if (isReject()) {
            MessageOutFn.outln(console, command.name + ": rejects common command to be executed by player");
            MessageOutFn.outln(console, "Usage: " + command.name + " <player_name> <command>");
        } else { // UNREJECT
            MessageOutFn.outln(console, command.name + ": removes rejected command mark from player");
            MessageOutFn.outln(console, "Usage: " + command.name + " <player_name> <command>");
        }
    }

    private boolean isGrant() {
        return command.tag.equals("GRANT");
    }

    private boolean isUNGrant() {
        return command.tag.equals("UNGRANT");
    }

    private boolean isReject() {
        return command.tag.equals("REJECT");
    }

//	private boolean isUNReject() {
//		return command.tag.equals("UNREJECT");
//	}
//

}
