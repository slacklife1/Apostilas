package net.sourceforge.pain.tinylib.logic.affect;

import net.sourceforge.pain.*;
import net.sourceforge.pain.data.*;
import net.sourceforge.pain.logic.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

/**
 * Immobility affect controller.
 * This class could be created
 * 1) by user while affecting some object with affect + providing affect specific params
 * 2) by codebase core, during affectOn(delayed), onAffectTimeExpired methods calls
 * <p/>
 * Codebase require from all affect controllers (Affect subclasses) to have constructor with (AffectData d) param.
 * this constructor is used for automatically affect controller instantiation and initialization with
 * persistent image
 */
public class ImmobilityAffect extends TimedAffect {


    /**
     * this constructor is required by codebase
     */
    public ImmobilityAffect(AffectData ad) {
        super(ad);
    }

    public static void applyToObject(Creature mob, int duration) throws Exception {
        new TimedAffectData(Codebase.getDB(), mob, ImmobilityAffect.class, AffectType.AFFECT_IMMOBILE, duration);
        MessageOutFn.outln(mob, "You can't move anymore");//just an example
    }

    /**
     * called by affect timer
     */
    public void onAffectTimeExpired() {
        _cancelAffect(ad, ad.getAffectedRole());
    }

    /**
     * user is allowed to cancel affect manualy
     */
    public static void cancelAffect(Creature mob) {
        TimedAffectData ad = (TimedAffectData) mob.getAffectData(AffectType.AFFECT_IMMOBILE);
        _cancelAffect(ad, mob);
    }

    private static void _cancelAffect(AffectData ad, Role mob) {
        ad.delete();
        MessageOutFn.outln(mob, "You can move now");//just an example
    }

    public Affect newInstance(AffectData ad) {
        return new ImmobilityAffect(ad);
    }

}
