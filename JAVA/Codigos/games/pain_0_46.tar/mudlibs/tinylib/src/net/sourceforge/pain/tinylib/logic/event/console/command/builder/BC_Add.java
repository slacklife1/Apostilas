package net.sourceforge.pain.tinylib.logic.event.console.command.builder;

import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

/**
 * PAiN  Date: 05.06.2003  Time: 1:40:02
 */
public final class BC_Add extends BuilderCommand {

    public void processBuilderCommand(BuilderShell p, String args) throws Exception {
        Prototype role = p.builder.getEditedRole();
        if (role == null) {
            MessageOutFn.outln(p.console, "No active role found!");
        } else if (args == null) {
            showHelp(p.console);
        } else {
            args = args.trim();
            try {
                Class protoClass = Class.forName("net.sourceforge.pain.tinylib.data.prototype." + args);
                Prototype proto = (Prototype) role.addRole(protoClass);
                p.builder.setEditedRole(proto);
                MessageOutFn.outln(p.console, "Role Added:" + protoClass.getName());
            } catch (ClassNotFoundException e) {
                MessageOutFn.outln(p.console, "No prototype found with name:" + args);
            }
        }
    }

    public void showHelp(Console console) {
        MessageOutFn.outln(console, "Builder command ADD adds specified role to the active prototype");
        MessageOutFn.outln(console, "Usage: add <Prototype_Role_Name>");
    }

}



