package net.sourceforge.pain.tinylib.logic.transform.rom24support;


import java.util.*;


public class ROMRoom {

    public String vnum;
    public String name;
    public String desc;
    public String[] exits = new String[6]; //vnums
    public String[] exitsDescs = new String[6];

    public List resets = new ArrayList();

    public ROMRoom(String vnum) {
        this.vnum = vnum;
    }

}

