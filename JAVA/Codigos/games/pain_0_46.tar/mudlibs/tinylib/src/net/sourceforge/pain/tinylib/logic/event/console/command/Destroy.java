package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.data.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;


public final class Destroy extends CommandHandler {

    public void processCommand() throws Exception {
        String target = commandParams;
        if (target == null || target.length() == 0) {
            MessageOutFn.outln(console, "Destroy what?");
        } else {
            final Interactive victim = SpaceFindFn.findByPrefix(player.asLocated(), target);
            if (victim == null) {
                MessageOutFn.outln(console, "It isn't here");
                return;
            }
            Physical ph = (Physical) victim.getRole(Physical.class);
            if (ph == null) {
                MessageOutFn.outln(console, "You failed.");
                return;
            }
            if (victim.is(Creature.class)) {
                MessageOutFn.outOne(player, "But $e is alive!", victim);
                return;
            }
            if (victim.sameObjectAs(player)) {
                MessageOutFn.outln(console, "You can't destroy yourself");
                return;
            }
            MessageOutFn.outOne(victim, "$n {*{R[*] POWER HIT [*]{x you", player);
            MessageOutFn.outOne(player, "You {*{R[*] POWER HIT [*]{x $n", victim);
            MessageOutFn.outSpaceNoVictim(player, victim, "$n {*{R[*] POWER HIT [*]{x $N", player, victim);
            MessageOutFn.outln(victim, "You have been DESTROYED!");
            Console victimConsole = ConsoleFn.getConsole(victim);
            if (victimConsole != null) {
                ConsoleFn.forceDisconnect(victimConsole);
            }
            MessageOutFn.outOne(player, "$n is DESTROYED!", victim);
            MessageOutFn.outSpaceNoVictim(player, victim, "$n is destroyed!", victim);
            ObjectFactory.destroyObject(victim);
        }
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": destroys physical objects");
    }
}
