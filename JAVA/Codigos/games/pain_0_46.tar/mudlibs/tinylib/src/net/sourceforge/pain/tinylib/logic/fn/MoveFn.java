package net.sourceforge.pain.tinylib.logic.fn;

import net.sourceforge.pain.data.*;
import net.sourceforge.pain.logic.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.trigger.*;
import net.sourceforge.pain.tinylib.logic.trigger.impl.*;
import net.sourceforge.pain.util.*;

import java.util.*;

public class MoveFn implements RelocationErrors {


    public static void move(Located located, int direction) {
        checkCanMove(located, direction);
        Room fromRoom = (Room) located.getLocation().getRole(Room.class);
        Exit exit = fromRoom.getExit(direction);
        final Room toRoom = exit.getTargetRoom();
        callBeforeMovedOutTriggers(located, toRoom);
        RelocateFn.relocate(located, toRoom.asSpace());
        callAfterMovedInTriggers(located, fromRoom, toRoom);
    }

    private static void callBeforeMovedOutTriggers(Located located, Room dstRoom) {
        for (Iterator it = dstRoom.getTriggersByEventType(TriggerType.TRIGGER_BEFORE_MOVED_OUT); it.hasNext();) {
            try {
                BeforeMovedOutTrigger t = (BeforeMovedOutTrigger) TriggersLogicFactory.provideTriggerImpl((TriggerData) it.next());
                t.onBeforeMovedOut(located, dstRoom);
            } catch (Exception e) {
                Log.error(e);
            }
        }
    }

    private static void callAfterMovedInTriggers(Located located, Room srcRoom, Room dstRoom) {
        for (Iterator it = dstRoom.getTriggersByEventType(TriggerType.TRIGGER_AFTER_MOVED_IN); it.hasNext();) {
            try {
                AfterMovedInInTrigger t = (AfterMovedInInTrigger) TriggersLogicFactory.provideTriggerImpl((TriggerData) it.next());
                t.onAfterMovedIn(located, srcRoom);
            } catch (Exception e) {
                Log.error(e);
            }
        }
    }

    public static void checkCanMove(Located located, int direction) {
        final Space dstLocation = located.getLocation();
        Room fromRoom = (Room) dstLocation.getRole(Room.class);
        if (fromRoom == null) { // not Room -> can't go
            throw new LogicException(ERR_MOVE_NO_EXITS_FOUND, "Not a room");
        }
        Exit exit = fromRoom.getExit(direction);
        if (exit == null) { // no exit found by direction
            throw new LogicException(ERR_MOVE_NO_EXITS_FOUND, "Exit not found");
        }
        final Room toRoom = exit.getTargetRoom();
        RelocateFn.checkCanRelocate(located, toRoom.asSpace());

    }

}
