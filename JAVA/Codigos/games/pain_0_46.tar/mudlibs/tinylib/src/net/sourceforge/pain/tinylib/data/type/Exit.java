package net.sourceforge.pain.tinylib.data.type;


import net.sourceforge.pain.data.*;
import net.sourceforge.pain.db.*;


/**
 * Exit.
 */
public final class Exit extends Role {

    private static final int TARGET_ROOM = 1 + LAST_BASE_FIELD_INDEX;
    private static final int EXIT_DESC = 2 + LAST_BASE_FIELD_INDEX;
    private static final int MOVE_COST = 3 + LAST_BASE_FIELD_INDEX;
    private static final int NFIELDS = 4 + LAST_BASE_FIELD_INDEX;

    public Exit(PainDB db) {
        super(db);
    }

    public Exit() {
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        fillSuperSchema(types, names);

        types[TARGET_ROOM] = DbType.REFERENCE;
        names[TARGET_ROOM] = "target_room";

        types[EXIT_DESC] = DbType.STRING;
        names[EXIT_DESC] = "exit_desc";

        types[MOVE_COST] = DbType.INT;
        names[MOVE_COST] = "move_costs";

        return new DbClassSchema(types, names);
    }

    public Room getTargetRoom() {
        return (Room) getReference(TARGET_ROOM);
    }

    public void setTargetRoom(Room value) {
        setReference(TARGET_ROOM, value);
    }

    public String getExitDesc() {
        return getString(EXIT_DESC);
    }

    public void setExitDesc(String desc) {
        setString(EXIT_DESC, desc);
    }

    public int getMoveCost() {
        return getInt(MOVE_COST);
    }

    public void setMoveConst(int moveCost) {
        setInt(MOVE_COST, moveCost);
    }
}
