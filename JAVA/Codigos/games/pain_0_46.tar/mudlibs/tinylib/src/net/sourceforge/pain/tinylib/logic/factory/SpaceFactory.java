package net.sourceforge.pain.tinylib.logic.factory;

import net.sourceforge.pain.tinylib.data.prototype.*;
import net.sourceforge.pain.tinylib.data.type.*;

/**
 * User: fmike  Date: Sep 13, 2003   Time: 8:38:14 PM
 */
public class SpaceFactory {

    public static void init(SpacePrototype proto, Space obj) {
        obj.setCapacity(proto.getCapacity());
        obj.setName(proto.getSpaceName());
        obj.setDesc(proto.getSpaceDesc());
    }
}
