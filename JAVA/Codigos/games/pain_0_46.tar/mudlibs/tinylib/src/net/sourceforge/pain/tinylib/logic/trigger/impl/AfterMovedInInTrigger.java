package net.sourceforge.pain.tinylib.logic.trigger.impl;

import net.sourceforge.pain.logic.*;
import net.sourceforge.pain.data.*;
import net.sourceforge.pain.tinylib.logic.trigger.*;
import net.sourceforge.pain.tinylib.data.type.*;

/**
 * User: fmike  Date: May 31, 2004  Time: 1:26:26 AM
 */
public abstract class AfterMovedInInTrigger extends Trigger {
    public AfterMovedInInTrigger(TriggerData td) {
        super(td);
    }

    public int getTriggerEventType() {
        return TriggerType.TRIGGER_AFTER_MOVED_IN;
    }

    public abstract void onAfterMovedIn(Located located, Room srcSpace);

}

