package net.sourceforge.pain.tinylib.logic.transform.rom24support;


public final class ROMMobileReset {

    public ROMMobile mob;
    public String comment;
    public int count;

    public String toString() {
        return "ROMMobileReset{" +
                "mob=" + mob.vnum +
                ", comment='" + comment + "'" +
                ", count=" + count +
                "}";
    }


}
