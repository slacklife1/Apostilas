package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.*;
import net.sourceforge.pain.plugin.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.util.*;

import java.util.*;

/**
 * duplicate of reload/load/unload admin console command
 */
public final class ReloadCode extends GrantedCommand {

    public void processCommand() {
        if (commandParams != null) {
            try {
                commandParams = commandParams.trim();
                if (commandParams.equals("LOGIC")) {
                    reloadLogic();
                } else if (commandParams.startsWith("plugin:")) {
                    reloadPlugin();
                } else {
                    showHelp();
                }
            } catch (Exception e) {
                Log.error(e.getMessage(), e);
                MessageOutFn.outln(console, "{RReloading error!:" + e.getClass().getName() + "\n{G" + e.getMessage() + "{x");
            } catch (NoClassDefFoundError e) {
                MessageOutFn.outln(console, "{RCritical reloading error!:" + e.getClass().getName() + "\n{G" + e.getMessage() + "{x");
            }
        } else {
            showHelp();
        }
    }

    private void reloadPlugin() throws Exception {
        String pluginName = commandParams.substring("plugin:".length());
        PluginManager plm = Codebase.getPluginManager();
        Plugin p = plm.getPlugin(pluginName);
        if ("UNLOAD".equals(command.tag) || "RELOAD".equals(command.tag)) {
            if (p == null) {
                MessageOutFn.outln(console, "Plugin:{W'" + pluginName + "'{x was not loaded!");
            } else {
                for (Iterator it = p.getDependedPlugins().iterator(); it.hasNext();) {
                    String childName = (String) it.next();
                    MessageOutFn.outln(console, "Direct depended plugins to unload:{W'" + childName + "'{x");
                }
                MessageOutFn.outln(console, "Unloading plugin:{W'" + pluginName + "'{x");
                plm.unloadPlugin(p);
            }
        }
        if ("RELOAD".equals(command.tag) || "LOAD".equals(command.tag)) {
            if (plm.getPlugin(pluginName) != null) {
                MessageOutFn.outln(console, "Plugin:{W'" + pluginName + "'{x is already loaded");
            } else {
                MessageOutFn.outln(console, "Loading plugin:'{W" + pluginName + "'{x");
                plm.loadPlugin(pluginName);
            }
        }
    }

    private void reloadLogic() {
        if (!"RELOAD".equals(command.tag)) {
            MessageOutFn.outln(console, "You can RELOAD logic classes only!");
        } else {
            Codebase.getLogicLoader().reload();
            MessageOutFn.outln(console, "{GLogic classes reloaded!{x"); // WARN: here (this function) we still have old code working (cached by JVM)
        }
    }


    public void showHelp() {
        if ("LOAD".equals(command.tag)) {
            MessageOutFn.outln(console, "This command loads plugins");
            MessageOutFn.outln(console, "Specify plugin name(classname suffix) to load plugin: 'plugin:name...'");
        } else if ("RELOAD".equals(command.tag)) {
            MessageOutFn.outln(console, "This command reloads logic code");
            MessageOutFn.outln(console, "Specify 'LOGIC' to reload all classes in 'logic' package ");
            MessageOutFn.outln(console, "OR specify plugin name(classname suffix) to reload plugin: 'plugin:name..'");
            MessageOutFn.outln(console, "WARN: all sub plugins will be unloaded and will not be loaded again!");
        } else if ("UNLOAD".equals(command.tag)) {
            MessageOutFn.outln(console, "This command unloads plugins");
            MessageOutFn.outln(console, "Specify plugin name(classname suffix) to unload plugin: 'plugin:name..'");
            MessageOutFn.outln(console, "WARN: all sub plugins will be unloaded!");
        }
    }
}
