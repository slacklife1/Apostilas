package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.*;
import net.sourceforge.pain.plugin.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.plugin.shutdown.*;
import net.sourceforge.pain.util.*;


public final class Shutdown extends GrantedCommand {

    final static String SHUTDOWN_PLUGIN_NAME = "shutdown.ShutdownTimer";

    public void processCommand() throws Exception {
        if (commandParams == null) {
            showUsage();
            return;
        }
        if ("EMERGENCY".equals(commandParams)) { // if there are some problems with plugins or code..
            Codebase.shutdown();
        } else {
            PluginManager plm = Codebase.getPluginManager();
            ShutdownTimer shutTimer = (ShutdownTimer) plm.getPlugin(SHUTDOWN_PLUGIN_NAME);

            if (shutTimer == null) {
                MessageOutFn.outln(console, "ShutdownTimer plugin is not loaded!");
                return;
            }

            commandParams = commandParams.toUpperCase();
            final boolean wasRunned = shutTimer.isShutdownInProcess();
            Log.debug("shutdown was runned:" + wasRunned);
            if ("STOP".equals(commandParams) || "CANCEL".equals(commandParams)) {
                if (wasRunned) {
                    shutTimer.cancel(true);
                } else {
                    MessageOutFn.outln(console, "Shutdown was not runned!");
                    return;
                }
            } else if ("NOW".equals(commandParams)) {
                shutTimer.now();
            } else if ("PULSE".equals(commandParams)) {
                if (!wasRunned) {
                    MessageOutFn.outln(console, "Shutdown was not runned!");
                    return;
                }
                MessageOutFn.outln(console, "Shutdown time " + shutTimer.getTimeBeforeShutdown() + " sec.");
            } else {
                int minutes;
                try {
                    minutes = Integer.parseInt(commandParams);
                } catch (Exception e) {
                    showUsage();
                    return;
                }
                minutes = Math.max(minutes, 0);
                shutTimer.startShutdown(minutes * 60, !wasRunned);
                if (wasRunned) {
                    MessageOutFn.outln(console, "Shutdown time changed");
                }
            }

        }
    }

    private void showUsage() {
        MessageOutFn.outln(console, command.name + ": specify time in minutes to shutdown");
        MessageOutFn.outln(console, "params:  'NOW' for instant shutdown or 'CANCEL|STOP' to stop, 'PULSE' - show shutdown timing");
    }
}
