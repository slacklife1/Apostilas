package net.sourceforge.pain.tinylib.logic.event.console.command.builder;

import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.db.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.prototype.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;
import net.sourceforge.pain.util.*;

/**
 * PAiN  Date: 05.06.2003  Time: 1:40:02
 */
public final class BC_Show extends BuilderCommand {
    private static final String spacer = "                  ";
    private static String header = null;

    public void processBuilderCommand(BuilderShell p, String args) throws Exception {
        final Prototype role = p.builder.getEditedRole();
        if (role == null) {
            MessageOutFn.outln(p.console, "No active role found!");
        } else {
            final DbClass clazz = role.getDbClass();
            final int nFields = clazz.getNumberOfFields();
            if (header == null) {
                header = "{cName" + spacer.substring(4);
                header += "Type" + spacer.substring(4);
                header += "Value{x";
            }
            Log.debug(header);
            MessageOutFn.outln(p.console, header);
            for (int fid = 2; fid < nFields; fid++) { //fid = 0 is Ref to Root
                String fieldName = clazz.getFieldName(fid);
                final int type = clazz.getFieldType(fid);
                final String value;
                switch (type) {
                    case DbType.BOOLEAN:
                        value = "" + role.getBoolean(fid);
                        break;
                    case DbType.BYTE:
                        value = "" + role.getByte(fid);
                        break;
                    case DbType.CHAR:
                        value = "" + role.getChar(fid);
                        break;
                    case DbType.DOUBLE:
                        value = "" + role.getDouble(fid);
                        break;
                    case DbType.FLOAT:
                        value = "" + role.getFloat(fid);
                        break;
                    case DbType.INT:
                        value = "" + role.getInt(fid);
                        break;
                    case DbType.LONG:
                        value = "" + role.getLong(fid);
                        break;
                    case DbType.SHORT:
                        value = "" + role.getShort(fid);
                        break;
                    case DbType.STRING:
                        value = "" + role.getString(fid);
                        break;
                    case DbType.ARRAY_OF_INT:
                        int[] arr = role.getIntArray(fid);
                        if (arr == null) {
                            value = "null";
                        } else if (role.getClass() == CreaturePrototype.class && fieldName.endsWith("dice")) {
                            value = Dice.format(arr);
                        } else {
                            value = "len[" + arr.length + "] {{" + Utils.formatTopArrayItems(10, arr, ",") + "}";
                        }
                        break;
                    case DbType.ARRAY_OF_STRING:
                        String[] sarr = role.getStringArray(fid);
                        if (sarr == null) {
                            value = "null";
                        } else {
                            value = "len[" + sarr.length + "] {{" + Utils.formatTopArrayItems(10, sarr, ",") + "}";
                        }
                        break;
                    case DbType.REFERENCE:
                        DbObject obj = role.getReference(fid);
                        if (obj == null) {
                            value = "null";
                        } else {
                            value = ClassUtils.classNameWithoutPackage(obj.getClass());
                        }
                        break;
                    default:
                        value = "unparsed";
                }
                fieldName += addSpaces(fieldName);
                String typeStr = DbType.name(type);
                typeStr += addSpaces(typeStr);
                MessageOutFn.outln(p.console, fieldName + typeStr + value);
            }
        }
    }

    private String addSpaces(String value) {
        if (value.length() > spacer.length()) {
            return "";
        }
        return spacer.substring(value.length());
    }

    public void showHelp(Console console) {
        MessageOutFn.outln(console, "Builder command SHOW shows field names, field types and values for edited prototypes role");
        MessageOutFn.outln(console, "Usage: show");
    }

}



