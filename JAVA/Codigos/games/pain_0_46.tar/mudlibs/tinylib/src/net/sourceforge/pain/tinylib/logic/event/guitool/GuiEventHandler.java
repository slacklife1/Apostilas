package net.sourceforge.pain.tinylib.logic.event.guitool;

import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.network.guitool.*;

public abstract class GuiEventHandler {
    protected GTNetPacket packet;
    public GuiToolConnection connection;
    public Administrator admin;

    public abstract void processEvent();

    protected void send(Object data) {
        connection.send(new GTNetPacket("", data, packet.sequence_id));
    }
}
