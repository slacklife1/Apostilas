package net.sourceforge.pain.tinylib.logic.event;

import net.sourceforge.pain.*;
import net.sourceforge.pain.db.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

import java.util.*;

/**
 * PAiN  Date: 14.04.2003  Time: 0:38:36
 */
public class CheckSafeShutdown extends AbstractEvent {

    public Object execute(Object param) throws Exception {
        final PainDB db = Codebase.getDB();
        final DbClass playerClass = db.getDbClass(Player.class);
        final Space commonQuitSpace = Mudlib.getWorld().getPlayersQuitSpace();
        if (playerClass != null) { // if db is empty this class could be absent
            for (Iterator it = playerClass.extentIterator(false); it.hasNext();) {
                final Player p = (Player) it.next();
                final Located located = p.asLocated();
                final Space lastLocation = located.getLocation();
                if (lastLocation != commonQuitSpace) {
                    RelocateFn.relocate(located, commonQuitSpace);
                    p.setQuitSpace(lastLocation);
                }
                p.setNextActivePlayer(null);
                p.setPrevActivePlayer(null);
            }
            Mudlib.getWorld().setFirstActivePlayer(null);
            return null;
        }
        return "ok";
    }
}
