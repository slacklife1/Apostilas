package net.sourceforge.pain.tinylib.logic.event.guitool.event;

import net.sourceforge.pain.*;
import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.tinylib.logic.event.guitool.*;
import net.sourceforge.pain.util.*;

import java.util.*;

public class Login extends GuiEventHandler {

    public void processEvent() {
        String[] data = (String[]) packet.data;
        String login = data[0];
        String pass = data[1];
        if (login == null || pass == null) {
            fail();
            return;
        }
        Log.debug("GuiToolLogin[" + login + "/" + pass + "]");
        Map adminAccounts = Codebase.getCodebaseData().getAdmins();
        Administrator admin = (Administrator) adminAccounts.get(login);
        if (pass.equals(admin.getPassword())) {
            GuiToolEvent.sendInfoMessage(connection, "ok", packet.sequence_id);
            connection.guiAdminId = admin.getOid();
            return;
        }
        fail();
    }

    private void fail() {
        GuiToolEvent.processFailedEvent(connection, "Auth failed", packet.sequence_id);
        connection.forceClose();
    }
}
