package net.sourceforge.pain.tinylib.logic.fn;

import net.sourceforge.pain.tinylib.data.type.*;

public class GetFn {

    public static void get(Creature creature, Physical target) {
        if (target.sameObjectAs(creature)) {
            MessageOutFn.outln(creature, "You can't do that.");
            return;
        }
        if (target.is(Creature.class)) { // maybe fight? maybe flag to fight?
            MessageOutFn.outln(creature, "You can't do that.");
            return;
        }
        RelocateFn.relocate(target.asLocated(), creature.getInventory());
        final Interactive iTarget = target.asInteractive();
        MessageOutFn.outln(creature, "You get " + iTarget.getDesc() + ".");
        MessageOutFn.outSpace(creature, "$n gets $P.", creature, iTarget, Receptive.SEE);
    }

}
