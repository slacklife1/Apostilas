package net.sourceforge.pain.tinylib.logic.fn;


import net.sourceforge.pain.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.util.*;

import java.io.*;

public final class LogoFn {

    private static final String VERSION_TOKEN = "$VERSION$";

    public static void showLogo(Console console) {
        String currentLogo;
        if (logo == null) {
            try {
                loadLogo();
                currentLogo = logo;
            } catch (IOException e) {
                Log.error(e.getMessage(), e);
                currentLogo = logo2;
            }
        } else {
            currentLogo = logo;
        }
        MessageOutFn.out(console, currentLogo);
    }

    private static void loadLogo() throws IOException {
        FileReader reader = new FileReader(Mudlib.CONFIG_DIR + "/logo");
        try {
            StringBuffer buf = new StringBuffer();

            do {
                int c = reader.read();

                if (c == -1) {
                    break;
                }
                buf.append((char) c);
            } while (true);
            logo = insertVersionInfo(buf.toString());
        } finally {
            reader.close();
        }

    }

    public static String insertVersionInfo(String template) {
        int versionStart = template.indexOf(VERSION_TOKEN);
        int versionEnd = versionStart + VERSION_TOKEN.length();
        return (template.substring(0, versionStart) + Codebase.CODEBASE_VERSION + template.substring(versionEnd));
    }

    private static String logo = null;
    private static String logo2 =
            "                                                       ..       :               \n" +
            "                    .                  .               .   .  .                 \n" +
            "      .           .                .               .. .  .  *                   \n" +
            "             *          .                    ..        .                        \n" +
            "                           .             .     . :  .   .    .  .               \n" +
            "            .                         .   .  .  .   .                           \n" +
            "                                         . .  *:. . .                           \n" +
            ".                                 .  .   . .. .         .                       \n" +
            "                         .     . .  . ...    .    .           *                 \n" +
            "       .              .  .  . .    . .  . .                                     \n" +
            "                        .    .     . ...   ..   .       .               .       \n" +
            "                 .  .    . *.   . .                                             \n" +
            "    .                   :.  .           .                                       \n" +
            "                 .   .    .    .                                                \n" +
            "             .  .  .    .    Original PAiN MUD Server by Mike Fursov            \n" +
            "            .  .. :.    .    Based on ideas from DIKU, LP, LAMBDA, ADOM         \n" +
            "     .   ... .                  .               .                               \n" +
            " .    :.  . .   *.           PAiN $VERSION$ copyright (c) 2002-2004 Mike Fursov \n" +
            "   .  *.              	.                                         (fmike@mail.ru)\n" +
            " . .    .               .             *.                         .              \n" +
            "	                                                                \n";

    static {
        logo2 = insertVersionInfo(logo2);
    }

}
