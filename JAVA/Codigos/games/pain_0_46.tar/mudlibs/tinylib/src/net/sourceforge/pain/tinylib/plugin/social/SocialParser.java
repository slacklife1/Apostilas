package net.sourceforge.pain.tinylib.plugin.social;


import net.sourceforge.pain.util.*;

import java.io.*;
import java.util.*;

public final class SocialParser {
    public static final int STATE_WAIT_SOCIAL = 1;
    public static final int STATE_WAIT_NAME = 2;
    public static final int STATE_INSIDE_BLOCK = 3;

    private int state = STATE_WAIT_SOCIAL;

    public Collection parseSocials(BufferedReader reader) throws Exception {
        Collection result = new LinkedList();
        SocialEntry entry = null;
        boolean hasTemplates = false;

        while (true) {
            String line = reader.readLine();

            //				Log.debug("line:" + line + " state:" + state);
            if (line == null) {
                throw new RuntimeException("unexpected end of file!");
            }
            line = line.trim();
            switch (state) {
                case STATE_WAIT_SOCIAL:
                    if (line.equals("#SOCIAL")) {
                        entry = new SocialEntry();
                        state = STATE_WAIT_NAME;
                    } else if (line.equals("#$")) {
                        return result;
                    }
                    break;

                case STATE_WAIT_NAME:
                    if (line.startsWith("name")) {
                        String name = line.substring(4).trim();

                        if (name.length() == 0) {
                            throw new RuntimeException("wrong social name format!:" + line);
                        }
                        entry.tag = name;
                        state = STATE_INSIDE_BLOCK;
                    } else if (line.length() > 0) {
                        throw new RuntimeException("unexpected line in social  STATE_WAIT_NAME:" + line);
                    }
                    break;

                case STATE_INSIDE_BLOCK:
                    int templateType = -1;

                    if (line.equals("end")) {
                        if (hasTemplates) {
                            result.add(entry);
                            state = STATE_WAIT_SOCIAL;
                        } else {
                            Log.debug("social :" + entry.tag + " has no active templates, skipping");
                        }
                    } else if (line.startsWith("found_char")) {
                        templateType = SocialEntry.FOUND_CHAR;
                    } else if (line.startsWith("found_vict")) {
                        templateType = SocialEntry.FOUND_VICT;
                    } else if (line.startsWith("found_notvict")) {
                        templateType = SocialEntry.FOUND_NOVICT;
                    } else if (line.startsWith("notfound_char")) {
                        templateType = SocialEntry.NOT_FOUND_CHAR;
                    } else if (line.startsWith("noarg_char")) {
                        templateType = SocialEntry.NOARG_CHAR;
                    } else if (line.startsWith("noarg_room")) {
                        templateType = SocialEntry.NOARG_ROOM;
                    } else if (line.startsWith("self_char")) {
                        templateType = SocialEntry.SELF_CHAR;
                    } else if (line.startsWith("self_room")) {
                        templateType = SocialEntry.SELF_SPACE;
                    }
                    if (templateType != -1) {
                        int start = line.indexOf(' ');
                        int end = line.indexOf('~');

                        if (start < 9 || end < start + 1) {
                            throw new RuntimeException("wrong template line:" + line);
                        }
                        hasTemplates = true;
                        entry.template[templateType] = line.substring(start + 1, end);
                    }
                    break;

                default:
                    throw new RuntimeException("BUG!");
            }
        }
    }
}
