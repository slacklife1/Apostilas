package net.sourceforge.pain.tinylib.logic.factory;

import net.sourceforge.pain.tinylib.data.prototype.*;
import net.sourceforge.pain.tinylib.data.type.*;

/**
 * User: fmike  Date: Sep 13, 2003   Time: 8:38:14 PM
 */
public class PhysicalFactory {

    public static void init(PhysicalPrototype proto, Physical obj) {
        obj.setAppearanceDesc(proto.getAppearanceDesc());
        obj.setSize(proto.getSize());
        obj.setWeight(proto.getWeight());
    }

}
