package net.sourceforge.pain.tinylib.logic.fn;

import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;

public final class SpaceFindFn {

    private SpaceFindFn() {
    }

    public static Interactive findByPrefix(Located actor, String namePrefix) {
        return findByPrefix(actor, actor.getLocation(), namePrefix);
    }

    public static Interactive findByPrefix(Located actor, Space location, String namePrefix) {
        if (namePrefix == null || namePrefix.length() == 0) {
            return null;
        }

        String prefix = namePrefix.toLowerCase();
        if (namePrefix.equals("self")) {
            Interactive interactive = (Interactive) actor.getRole(Interactive.class);
            if (interactive != null) {
                return interactive;
            }
            // else we will look for this obj;
        }

        String mostSimilarName = null;
        Interactive result = null;
        for (Located obj = location.getFirstInSpace(); obj != null; obj = obj.getNextInSpace()) { // backstep lists are chained
            Interactive interactive = (Interactive) obj.getRole(Interactive.class);
            if (interactive == null) {
                continue;
            }
            String[] inames = interactive.getTargetList();
            for (int i = 0; i < inames.length; i++) {
                String iname = inames[i];
                if (iname.startsWith(prefix)) {
                    if (iname.length() == prefix.length()) {
                        return interactive; // found exact
                    }
                    if (mostSimilarName == null) {
                        mostSimilarName = iname;
                        result = interactive;
                        continue;
                    } else {
                        if (Utils.isCloserTo(prefix, iname, mostSimilarName)) {
                            mostSimilarName = iname;
                            result = interactive;
                        }
                    }
                }
            }
        }
        return result;
    }

}

