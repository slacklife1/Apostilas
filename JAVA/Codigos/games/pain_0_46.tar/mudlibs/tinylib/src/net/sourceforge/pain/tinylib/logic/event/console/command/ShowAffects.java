package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.*;
import net.sourceforge.pain.data.*;
import net.sourceforge.pain.tinylib.logic.affect.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

import java.util.*;


public final class ShowAffects extends CommandHandler {


    public void processCommand() throws Exception {
        Iterator it = player.getAffects();
        MessageOutFn.outln(console, "Affect name \tTime left(min)");
        if (it.hasNext()) {
            int time = Codebase.getPulse().currentTime();
            do {
                AffectData ad = (AffectData) it.next();
                String name = AffectType.getAffectName(ad.getAffectType());
                int offTime = ad.getAffectOffTime();
                String durationStr = offTime == -1 ? "-" : "" + Math.max(1, (time - offTime) / Pulse.PULSE_PER_MIN); //affects off time checked not every pulse
                MessageOutFn.outln(console, "{w" + name + "{c\t" + durationStr + "{x");
            } while (it.hasNext());
        } else {
            MessageOutFn.outln(console, "None.");
        }
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": shows players affects");
        MessageOutFn.outln(console, "Usage:" + command.name);
    }
}
