package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

public final class Goto extends GrantedCommand {

    public void processCommand() {
        String target = commandParams == null ? "" : commandParams.trim();
        if (target.length() == 0) {
            MessageOutFn.outln(console, "Goto where?");
            return;
        }

        Player p = GlobalFindFn.findActivePlayerByName(target);
        Space targetSpace;
        if (p != null) {
            targetSpace = p.getLocation();
        } else {
            Room room = (Room) Mudlib.getWorld().getRoomsByIdMap().get(target);
            if (room == null) {
                MessageOutFn.outln(console, "No such location!");
                return;
            }
            targetSpace = room.asSpace();
        }

        final Located located = player.asLocated();
        try {

            RelocateFn.checkCanRelocate(located, targetSpace);
            MessageOutFn.outSpace(player, "$n leaves room", player);
            //	Log.debug("setting location from:"+space.getVnum()+" to :"+targetSpace.getVnum());
            if (targetSpace != located.getLocation()) {
                RelocateFn.relocate(located, targetSpace);
            }
            ShowFn.showSpace(player.asReceptive(), targetSpace);
            MessageOutFn.outSpace(located, "$n arrives", player);
        } catch (LogicException e) {
            if (e.errorCode == RelocationErrors.ERR_NOT_ENOUGH_TARGET_SPACE) {
                MessageOutFn.outln(console, "There's no more room there.");
                return;
            } else {
                throw e;
            }
        }

    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": moves you to the specified unique space or player");
    }
}
