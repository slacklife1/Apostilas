package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

public final class Say extends CommandHandler {

    public void processCommand() throws Exception {
        String textToSay = commandParams;
        if (textToSay == null || textToSay.length() == 0) {
            MessageOutFn.outln(console, "Say what?");
        } else {
//			MessageOutFn.outln(player, "{WNote:{x different code :)");
            MessageOutFn.outOne(player, "You say {w'$t'{x", textToSay);
            MessageOutFn.outSpace(player, "$n says '{w$T{x'", player, textToSay);
        }
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": sends a message to all awake players in your room.");
    }
}
