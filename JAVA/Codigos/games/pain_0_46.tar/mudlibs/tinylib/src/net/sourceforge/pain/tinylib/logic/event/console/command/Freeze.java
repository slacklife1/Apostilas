package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.affect.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

public final class Freeze extends GrantedCommand {

    public void processCommand() throws Exception {
        String target = commandParams;
        final boolean stopFreeze = "OFF".equals(command.tag);
        if (target == null || target.length() == 0) {
            MessageOutFn.outln(console, stopFreeze ? "Remove freeze from whom?" : "Freeze whom?");
            return;
        }
        final Interactive victim = SpaceFindFn.findByPrefix(player.asLocated(), target);
        if (victim == null) {
            MessageOutFn.outln(console, "They aren't here");
            return;
        }
        Creature mob = (Creature) victim.getRole(Creature.class);
        if (mob == null) {
            MessageOutFn.outln(console, "You failed.");
            return;
        }

        if (stopFreeze) {
            if (!victim.isAffected(AffectType.AFFECT_IMMOBILE)) {
                MessageOutFn.outOne(player, "$n is not frozen.", victim);
            } else {
                ImmobilityAffect.cancelAffect(mob);
                MessageOutFn.outln(player, "FREEZE removed.");
            }
        } else {
            if (victim.isAffected(AffectType.AFFECT_IMMORTAL)) {
                MessageOutFn.outln(player, "Not on immortals.");
            } else if (victim.isAffected(AffectType.AFFECT_IMMOBILE)) {
                MessageOutFn.outln(player, "Already frozen.");
            } else {
                ImmobilityAffect.applyToObject((Creature) victim.getRole(Creature.class), Pulse.PULSE_PER_MIN);
                MessageOutFn.outln(player, "FREEZE set.");
            }
        }
    }

    public void showHelp() {
        final boolean stopFreeze = "OFF".equals(command.tag);
        if (stopFreeze) {
            MessageOutFn.outln(console, command.name + ": removes IMMOBILE affect from target");
        } else {
            MessageOutFn.outln(console, command.name + ": adds IMMOBILE affect to victim");
        }
    }
}
