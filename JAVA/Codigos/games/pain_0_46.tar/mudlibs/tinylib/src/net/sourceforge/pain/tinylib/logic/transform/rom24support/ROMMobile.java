package net.sourceforge.pain.tinylib.logic.transform.rom24support;


public class ROMMobile {

    public String vnum;
    public String[] nameList;
    public String shortDesc;
    public String longDesc;
    public String lookDesc;
    public String race;

    public String act;
    public String affect;
    public String alignment;
    public String group;

    public int level;
    public int hitBonus;

    public int[] hitDice; //0d1+2
    public int[] manaDice;
    public int[] damDice;

    public String damType;

    public int armor[]; // 0=, 1=, 2=, 3=

    public String offenses;
    public String immunities;
    public String resistances;
    public String vulnerabilities;

    public String position1;
    public String position2;
    public String gender;
    public int treasure;

    public int limit;

    public ROMMobile(String vnum) {
        this.vnum = vnum;
    }
}

