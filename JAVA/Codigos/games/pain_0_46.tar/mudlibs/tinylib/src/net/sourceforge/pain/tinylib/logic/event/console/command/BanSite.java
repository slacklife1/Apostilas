package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.util.*;

import java.net.*;
import java.util.*;

public final class BanSite extends GrantedCommand {


    public void processCommand() throws Exception {
        if (commandParams == null) {
            showHelp();
            return;
        }
        StringTokenizer st = new StringTokenizer(commandParams, " ,\t");
        String banTypeStr = st.hasMoreTokens() ? st.nextToken().toLowerCase() : null;
        String addr = st.hasMoreTokens() ? st.nextToken().toLowerCase() : null;
        String reason = st.hasMoreTokens() ? st.nextToken("\n").trim() : null;
        if (addr == null || (reason == null && !"off".equals(banTypeStr))) {
            showHelp();
            return;
        }
        String addrIP;
        String addrHost;
        if (addr.matches("^\\d{2,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}$")) {
            addrIP = addr;
            addrHost = addr;
        } else {
            addrHost = addr;
            try {
                addrIP = InetAddress.getByName(addr).getHostAddress();
            } catch (Exception e) {
                MessageOutFn.outln(console, FormatUtils.formatStacktrace(e));
                return;
            }
        }
        Map bansMap = Mudlib.getWorld().getSiteBans();
        if (banTypeStr.equals("off")) { //removing ban
            boolean ok = false;
            SiteBan ban = (SiteBan) bansMap.get(SiteBan.getSiteBanKey(addrIP, SiteBan.SITE_BAN_ALL));
            if (ban != null) {
                ok = true;
                MessageOutFn.outln(console, "Removing ALL ban..");
                ban.delete();
            }
            ban = (SiteBan) bansMap.get(SiteBan.getSiteBanKey(addrIP, SiteBan.SITE_BAN_NEWBIES));
            if (ban != null) {
                ok = true;
                MessageOutFn.outln(console, "Removing NEWBIES ban..");
                ban.delete();
            }
            if (ok) {
                MessageOutFn.outln(console, "DONE.");
            } else {
                MessageOutFn.outln(console, "No bans found for site:" + addrIP);
            }
        } else {
            int type = SiteBan.SITE_BAN_ALL;
            if (banTypeStr.equals("newbies")) {
                type = SiteBan.SITE_BAN_NEWBIES;
            } else if (!banTypeStr.equals("all")) {
                showHelp();
                return;
            }
            SiteBan ban = (SiteBan) bansMap.get(SiteBan.getSiteBanKey(addrIP, type));
            if (ban != null) {
                MessageOutFn.outln(console, "Site is already banned");
                MessageOutFn.outln(console, "AdminUtils  :" + ban.getAdminName());
                MessageOutFn.outln(console, "Ban time:" + new Date(ban.getBanTime()));
                MessageOutFn.outln(console, "Reason  :" + ban.getReason());
                return;
            }
            bansMap.put(SiteBan.getSiteBanKey(addrIP, type), new SiteBan(Codebase.getDB(), addrIP, addrHost, type, player.getLogin(), reason));
            MessageOutFn.outln(console, "Site banned.");
        }
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": <ban_type> <ip-or-hostname> <reason>");
        MessageOutFn.outln(console, "where <ban_type> = ['off', 'newbies', 'all']");
    }

}
