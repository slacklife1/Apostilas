package net.sourceforge.pain.tinylib.logic.event.console;

import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.logic.fn.*;


public final class MoreShell extends CommandHandler {
    public static final int LINES_PER_SCREEN = 37;
    CommandHandler prevShell;
    String text;
    int pos;

    public MoreShell() {
    }

    public void run(Console c, String textToShow) {
        this.console = c;
        this.text = textToShow;
        pos = 0;
        prevShell = (CommandHandler) c.getRawCommand();
        c.setRawMode(this);
        printNextPart();
    }

    public void processCommand() throws Exception {
        String line = console.popInputLine();
        if (line.length() == 0) {
            printNextPart();
        } else { //user stopped listing
            finish();
        }
    }

    private void finish() {
        if (prevShell == null) {
            console.setCommandMode();
        } else {
            console.setRawMode(prevShell);
        }
    }

    private void printNextPart() {
        for (int i = 0; i < LINES_PER_SCREEN; i++) {
            int nextLineStartPos = text.indexOf('\n', pos);
            if (nextLineStartPos == -1 || nextLineStartPos == text.length() - 1) {
                MessageOutFn.outln(console, text.substring(pos));
                finish();
                return;
            } else {
                MessageOutFn.outln(console, text.substring(pos, nextLineStartPos));
                pos = nextLineStartPos + 1;
            }
        }
        MessageOutFn.out(console, "\n{c[ENTER - next page, other input - stop]{x ");
    }
}
