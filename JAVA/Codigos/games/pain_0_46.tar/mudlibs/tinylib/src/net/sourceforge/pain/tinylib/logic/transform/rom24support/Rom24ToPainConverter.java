package net.sourceforge.pain.tinylib.logic.transform.rom24support;


import net.sourceforge.pain.*;
import net.sourceforge.pain.data.*;
import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.*;
import net.sourceforge.pain.tinylib.data.prototype.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.util.*;

import java.io.*;
import java.util.*;


public final class Rom24ToPainConverter {

    private static final int[] defaultMoveDice = new int[]{1, 100, 0};

    private Rom24ToPainConverter() {
    };

    public static void transform(File areaListFile, Rom24ConversionLogListener l) throws Exception {
        String path = areaListFile.getParent();
        ArrayList areaFiles = new ArrayList();
        if (areaListFile.getName().endsWith(".are")) { // not area list but area file
            areaFiles.add(areaListFile.getAbsolutePath());
        } else {
            log(l, "Opening area list file for reading:" + areaListFile.getAbsolutePath());
            BufferedReader reader = new BufferedReader(new FileReader(areaListFile));
            log(l, "Reading area list file");
            try {
                while (true) {
                    String areaFileName = reader.readLine();
                    if (areaFileName == null) {
                        break;
                    }
                    areaFileName = areaFileName.trim();
                    if (areaFileName.equals("$")) { // end of list
                        break;
                    }
                    if (!areaFileName.startsWith("#") && !areaFileName.startsWith("!")) {
                        areaFiles.add(path + File.separator + areaFileName);
                    }
                }
            } finally {
                reader.close();
            }
            Log.info("Area list file read");
            log(l, "Area list file read (found areas:" + areaFiles.size() + "), loading areas..");
        }
        Log.info("Loading areas..");
        ArrayList areas = new ArrayList();
        for (int i = 0; i < areaFiles.size(); i++) {
            String fileName = (String) areaFiles.get(i);
            Log.info("Loading area :" + fileName);
            log(l, "Loading area:" + fileName + " , num:" + i);
            Rom24AreaModel area = Rom24AreaLoader.loadArea(fileName);
            if (area.areaName == null) {
                throw new RuntimeException("ParseError: Area has no name:" + fileName);
            }
            areas.add(area);
            Log.info("Area:" + fileName + " loaded OK");
        }

        Log.info("ROM areas parsed!");
        log(l, "area loading done, importing  data...");
        Log.info("Creating areas and rooms");

        convert(areas, l);

        Log.info("schema converted OK!");
        log(l, "convertion done!");
        log(l, "{w Note: {c rooms vnums adjusted with rom24:<vnum> prefix");
        log(l, "{c use 'goto' or builders 'link' command to check (example: goto rom24:3001){x");
    }

    private static void convert(ArrayList areas, Rom24ConversionLogListener l) throws Exception {
        World world = Mudlib.getWorld();
        Map world_roomsById = world.getRoomsByIdMap();
        Map world_protosByVnum = world.getPrototypesByVnumMap();
        Map world_areasByName = world.getAreasByName();
        for (int j = 0; j < areas.size(); j++) {
            Rom24AreaModel romArea = (Rom24AreaModel) areas.get(j);
            Area area = (Area) ObjectFactory.createRaw(Area.class);
            area.setResetMessage(romArea.resetMessage);
            area.setResetPeriod(Pulse.PULSE_PER_MIN * 3);
            area.setNextResetTime(0);
            area.setAreaDesc(romArea.areaName);
            area.setName(romArea.areaName);
            world_areasByName.put(romArea.areaName, area);

            // creating rooms;
            for (Iterator it = romArea.rooms.values().iterator(); it.hasNext();) {
                ROMRoom romRoom = (ROMRoom) it.next();
                Log.info("creating room:" + romRoom.vnum);
                Room room = (Room) ObjectFactory.createRaw(Room.class);
                room.setArea(area);
                area.getRooms().add(room);
                room.setRoomUniqueId(romRoomIdToPain(romRoom.vnum));
                world_roomsById.put(room.getRoomUniqueId(), room);
                Space space = room.asSpace();
                space.setName(romRoom.name);
                space.setDesc(romRoom.desc);
                space.setCapacity(1000);
                // exits will be bound later
            }

            //creating mobile prototypes
            Log.info("Creating creatures prototypes");
            Race defaultRace = (Race) world.getRaces().iterator().next(); // temporaty unprocessed
            for (Iterator it = romArea.mobiles.values().iterator(); it.hasNext();) {
                ROMMobile romMobile = (ROMMobile) it.next();
                Log.info("creating creature prototype:" + romMobile.vnum);
                PrototypeInfo p = (PrototypeInfo) ObjectFactory.createRaw(PrototypeInfo.class);
                p.setVnum(romMobileVnumToPain(romMobile.vnum));
                p.setName(romMobile.shortDesc);
                PhysicalPrototype ph = (PhysicalPrototype) p.addRole(PhysicalPrototype.class);
                ph.setAppearanceDesc(romMobile.lookDesc);
                ph.setWeight(1);
                ph.setSize(1);

                InteractivePrototype ip = ph.asInteractivePrototype();
                ip.setTargetList(romMobile.nameList);
                ip.setInteractiveName(romMobile.shortDesc);
                ip.setDesc(romMobile.longDesc);

                CreaturePrototype cp = (CreaturePrototype) p.addRole(CreaturePrototype.class);
                cp.setHPDice(new Dice(romMobile.hitDice));
                cp.setSex(romMobile.gender.equals("male") ? CreaturePrototype.SEX_MALE : romMobile.gender.equals("female") ? CreaturePrototype.SEX_FEMALE : romMobile.gender.equals("either") ? CreaturePrototype.SEX_EITHER : CreaturePrototype.SEX_UNDEFINED);
                cp.setRace(defaultRace);
                cp.setMovePointsDice(new Dice(defaultMoveDice));

                final SpacePrototype inventoryPrototype = (SpacePrototype) ObjectFactory.createRaw(SpacePrototype.class);
                inventoryPrototype.setSpaceName("Inventory");
                inventoryPrototype.setSpaceDesc("");
                inventoryPrototype.setCapacity(Integer.MAX_VALUE);
                cp.setInventoryPrototype(inventoryPrototype);

                world_protosByVnum.put(p.getVnum(), p);
            }

            //creating object prototypes
            Log.info("Creating thing prototypes");
            for (Iterator it = romArea.objects.values().iterator(); it.hasNext();) {
                ROMObject romObject = (ROMObject) it.next();
                Log.info("creating thing prototype:" + romObject.vnum);
                PrototypeInfo p = (PrototypeInfo) ObjectFactory.createRaw(PrototypeInfo.class);
                p.setName(romObject.shortDesc);
                p.setVnum(romObjVnumToPain(romObject.vnum));
                PhysicalPrototype ph = (PhysicalPrototype) p.addRole(PhysicalPrototype.class);
                ph.setAppearanceDesc(romObject.longDesc);
                ph.setWeight(1);
                ph.setSize(1);

                InteractivePrototype ip = ph.asInteractivePrototype();
                ip.setTargetList(romObject.nameList);
                ip.setInteractiveName(romObject.shortDesc);
                ip.setDesc(romObject.longDesc);
                world_protosByVnum.put(p.getVnum(), p);
            }
        }
        // binding room exits
        // and resets
        log(l, "linking rooms and creating resets...");
        Log.info("Creating exits and resets");
        for (int j = 0; j < areas.size(); j++) {
            Rom24AreaModel romArea = (Rom24AreaModel) areas.get(j);
            Area area = (Area) world_areasByName.get(romArea.areaName);
            for (Iterator it = romArea.rooms.values().iterator(); it.hasNext();) {
                ROMRoom romRoom = (ROMRoom) it.next();
                Room room1 = (Room) world_roomsById.get(romRoomIdToPain(romRoom.vnum));
                Space space1 = room1.asSpace();
                for (int i = 0; i < romRoom.exits.length; i++) {
                    if (romRoom.exits[i] != null) {
                        Room room2 = (Room) world_roomsById.get(romRoomIdToPain(romRoom.exits[i]));
                        if (room2 == null) {
                            continue;
                        }
                        Exit exit1to2 = (Exit) ObjectFactory.createRaw(Exit.class);
                        exit1to2.setTargetRoom(room2);
                        exit1to2.setExitDesc(romRoom.exitsDescs[i]);
                        exit1to2.setMoveConst(1);
                        room1.setExit(i, exit1to2);
                    }
                }

                if (romRoom.resets.size() > 0) {
                    for (int r = 0; r < romRoom.resets.size(); r++) {
                        Object romReset = romRoom.resets.get(r);
                        PrototypeInfo p;
                        if (romReset instanceof ROMMobileReset) {
                            ROMMobileReset mreset = (ROMMobileReset) romReset;
                            Log.info("mob reset :" + mreset.mob.vnum);
                            p = (PrototypeInfo) world_protosByVnum.get(romMobileVnumToPain(mreset.mob.vnum));
                        } else {// this is ROMObjectReset
                            ROMObjectReset oreset = (ROMObjectReset) romReset;
                            Log.info("obj reset :" + oreset.obj.vnum);
                            p = (PrototypeInfo) world_protosByVnum.get(romObjVnumToPain(oreset.obj.vnum));
                        }
                        if (p == null) {
                            Log.warn("Prototype is not found for reset:" + romReset.toString() + "space vnum:" + romRoom.vnum + " space name:" + romRoom.name);
                        } else {
                            SpaceReset reset = (SpaceReset) ObjectFactory.createRaw(SpaceReset.class);
                            reset.setResettedPrototype(p);
                            RelocateFn.addToSpace(space1, (Located) reset.getRole(Located.class));
                            area.getResets().add(reset);
                        }
                    }
                }
            }// rooms
        } // areas
    }

    private static String romRoomIdToPain(String vnum) {
        return "rom24:" + vnum;
    }

    private static String romMobileVnumToPain(String vnum) {
        return "rom24creature:" + vnum;
    }

    private static String romObjVnumToPain(String vnum) {
        return "rom24thing:" + vnum;
    }

    private static void log(Rom24ConversionLogListener l, String message) {
        if (l != null) {
            l.onConversionMessage(message);
        }
    }

}