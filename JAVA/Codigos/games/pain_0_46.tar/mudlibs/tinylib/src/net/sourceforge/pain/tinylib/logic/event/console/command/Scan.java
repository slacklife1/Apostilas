package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;


public final class Scan extends CommandHandler {

    private final static int range = 4;

    public boolean isAccessible() {
        return super.isAccessible() && player.asReceptive().canSee();
    }

    public void processNotAccessible() {
        MessageOutFn.outln(console, "You can't see anything!");
    }

    public void processCommand() throws Exception {
        int dir = -1;
        String dirStr = commandParams;
        if (dirStr != null) {
            dirStr = dirStr.toLowerCase().trim();
            if ("north".startsWith(dirStr)) {
                dir = Room.DIR_NORTH;
            } else if ("east".startsWith(dirStr)) {
                dir = Room.DIR_EAST;
            } else if ("south".startsWith(dirStr)) {
                dir = Room.DIR_SOUTH;
            } else if ("west".startsWith(dirStr)) {
                dir = Room.DIR_WEST;
            } else if ("up".startsWith(dirStr)) {
                dir = Room.DIR_UP;
            } else if ("down".startsWith(dirStr)) {
                dir = Room.DIR_DOWN;
            } else {
                MessageOutFn.outln(console, "Wrong direction.");
            }
        }
        if (dir == -1) {
            lookAround();
        } else {
            lookDir(dir);
        }
    }

    private void lookDir(int dir) {
        MessageOutFn.outSpace(player, "$n scans $T.", player, LangUtil.exitName[dir]);
        MessageOutFn.outOne(player, "You scan $t.", LangUtil.exitName[dir]);
        Space space = player.getLocation();
        Room room = (Room) space.getRole(Room.class);
        if (room == null) {
            return;
        }

        for (int i = 1; i <= range; i++) {
            Exit exit = room.getExit(dir);
            if (exit == null) {
                break;
            }
            space = exit.getTargetRoom().asSpace();
            boolean rangeTitleShown = false;
            for (Located obj = space.getFirstInSpace(); obj != null; obj = obj.getNextInSpace()) {
                Interactive interactive = (Interactive) obj.getRole(Interactive.class);
                if (interactive == null) {
                    continue;
                }
                if (!rangeTitleShown) {
                    MessageOutFn.outln(console, "***** {cRange " + i + "{x *****");
                    rangeTitleShown = true;
                }
                MessageOutFn.outln(console, interactive.getName());
            }
            room = (Room) space.getRole(Room.class);
            if (room == null) {
                break;
            }
        }
    }

    private void lookAround() {
        MessageOutFn.outSpace(player, "$n looks all around.", player, null);
        MessageOutFn.outln(console, "Looking around you see:");
        MessageOutFn.outln(console, "{Chere{x:");
        Space space = player.getLocation();
        scanSpace(space);

        Room link = (Room) space.getRole(Room.class);
        if (link == null) {
            return;
        }

        for (int dir = Room.DIR_NORTH; dir <= Room.DIR_DOWN; dir++) {
            Exit exit = link.getExit(dir);
            if (exit == null) {
                continue;
            }
            space = exit.getTargetRoom().asSpace();
            MessageOutFn.outln(console, "{C" + LangUtil.exitName[dir] + "{x:");
            scanSpace(space);
        }
    }

    private void scanSpace(Space space) {
        Interactive pli = player.asInteractive();
        for (Located obj = space.getFirstInSpace(); obj != null; obj = obj.getNextInSpace()) {
            Interactive i = (Interactive) obj.getRole(Interactive.class);
            if (i == null) {
                continue;
            }
            if (i != pli) {
                MessageOutFn.outln(console, "    " + i.getName());
            }
        }
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": scans the specified direction.");
    }

}
