package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;

public final class DateTime extends CommandHandler {

    public void processCommand() throws Exception {
        WorldCalendar time = new WorldCalendar(Codebase.getPulse().currentTime());
        int day = time.day + 1;

        if (!"DATE".equals(command.tag)) {
            String str = "It is " + ((time.hour == 12 || time.hour == 0) ? 12 : time.hour % 12) +
                    " o'clock " + (time.hour >= 12 ? "pm" : "am") +
                    ", Day of " + WorldCalendar.dayNames[time.dayOfWeek] +
                    ", " + day + getSuffix(day) +
                    " the Month of " + WorldCalendar.monthNames[time.month] + ".\n";

            MessageOutFn.out(console, str);
            MessageOutFn.outOne(super.player, "It's $t.",
                    (time.hour >= 5 && time.hour < 9) ? "dawn" :
                    (time.hour >= 9 && time.hour < 12) ? "morning" :
                    (time.hour >= 12 && time.hour < 18) ? "mid-day" :
                    (time.hour >= 18 && time.hour < 21) ? "evening" :
                    "night");
        } else {
            String str = "Day of " + WorldCalendar.dayNames[time.dayOfWeek] +
                    ", " + day + getSuffix(day) +
                    " the Month of " + WorldCalendar.monthNames[time.month] + ". " + time.year + " A.D.\n";

            MessageOutFn.out(console, str);
        }
    }

    private static String getSuffix(int number) {
        if (number > 4 && number < 20) {
            return "th";
        } else if (number % 10 == 1) {
            return "st";
        } else if (number % 10 == 2) {
            return "nd";
        } else if (number % 10 == 3) {
            return "rd";
        } else {
            return "th";
        }
    }

    public void showHelp() {
        if ("DATE".equals(command.tag)) {
            MessageOutFn.outln(console, command.name + ": shows current date");
        } else { // time
            MessageOutFn.outln(console, command.name + ": shows current day time");
        }
    }
}

