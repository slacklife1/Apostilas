package net.sourceforge.pain.tinylib.logic.fn;


import net.sourceforge.pain.*;
import net.sourceforge.pain.data.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.util.*;


public final class ConsoleFn {

    public static void logoutUser(Console console) {
        _logoutUser(console, false);
    }

    private static void _logoutUser(Console console, boolean silent) {
        Player p = console.getPlayer();
        if (!silent) {
            MessageOutFn.outln(console, "Good bye!");
            MessageOutFn.outSpace(p, "$n leaves the game", p, null);
        }
        console.setPlayer(null);
        Codebase.getUserConsoleManager().closeConsole(console);
        PlayerActivationFn.inactivatePlayerAccount(p);
    }


    public static void loginUser(final Console console, final Player player) {
        if (console.getPlayer() != null || ConsoleFn.getConsole(player) != null) {
            throw new RuntimeException("console.getPlayer() == null && ConsoleFn.getConsole(player) == null violated");
        }
        Log.debug("ConsoleFn: logging user in:" + player.getLogin());

        PlayerActivationFn.activatePlayerAccount(player);

        console.setPlayer(player);
        console.setCommandMode();

        MessageOutFn.outln(console, "Hello {w" + player.getInteractiveName() + "{x !\n ");
        MessageOutFn.outSpace(player, "$n enters the game", player);
        ShowFn.showSpace(player.asReceptive(), player.asLocated().getLocation());
        Log.debug("ConsoleFn: user logged in:" + player.getLogin());
    }

    /**
     * forces console to disconnect
     */
    public static void forceDisconnect(Console c) {
        Player p = c.getPlayer();
        if (p != null) {
            _logoutUser(c, true);
        } else {
            Codebase.getUserConsoleManager().closeConsole(c);
        }
    }

    public static Console getConsole(Role obj) {
        Player p = (Player) obj.getRole(Player.class);
        if (p == null) {
            return null;
        }
        return Console.getConsoleByOwner(p);
    }
}
