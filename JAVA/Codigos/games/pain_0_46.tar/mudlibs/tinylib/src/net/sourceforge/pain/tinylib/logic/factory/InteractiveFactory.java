package net.sourceforge.pain.tinylib.logic.factory;

import net.sourceforge.pain.tinylib.data.prototype.*;
import net.sourceforge.pain.tinylib.data.type.*;


/**
 * User: fmike  Date: Sep 13, 2003   Time: 8:38:14 PM
 */
public class InteractiveFactory {

    public static void init(InteractivePrototype proto, Interactive obj) {
        obj.setDesc(proto.getDesc());
        obj.setTargetList(proto.getTargetList());
        obj.setName(proto.getInteractiveName());
    }

}
