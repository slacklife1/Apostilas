package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;


public final class Force extends GrantedCommand {


    public void processCommand() throws Exception {
        if (commandParams == null) {
            showHelp();
            return;
        }
        String[] params = new String[2];
        ConsoleInputEvent.parseCommand(commandParams, params);
        if (params[1] == null) {
            showHelp();
            return;
        }
        String name = params[0];
        final Player p;
        if ("self".equals(name.toLowerCase())) {
            p = player;
        } else {
            p = GlobalFindFn.findActivePlayerByName(params[0]);
        }
        if (p == null) {
            MessageOutFn.outln(console, "No player found with name {c" + Utils.formatName(params[0]) + "{x");
            return;
        }
        Console c = Console.getConsoleByOwner(p);
        c.pushInputLine(params[1]);
        if (p != player) { //if not self
            MessageOutFn.outln(console, "Done.");
        }
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": forces player to execute console command");
        MessageOutFn.outln(console, "Usage:" + command.name + " <player_name> <command>");
    }
}
