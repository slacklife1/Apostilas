package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

public final class Credits extends CommandHandler {

    public void processCommand() throws Exception {
        MessageOutFn.outln(console, "Credits:");
        MessageOutFn.outln(console, "codebase version : PAiN MUD Codebase v" + Codebase.CODEBASE_VERSION + "  (http://pain.sf.net)");
        MessageOutFn.outln(console, "mudlib version   : tinylib (sample library) (http://pain.sf.net)");
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": codebase/mudlib version info");
    }

}
