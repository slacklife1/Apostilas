package net.sourceforge.pain.tinylib.logic.event.guitool;

import net.sourceforge.pain.*;
import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.network.guitool.*;
import net.sourceforge.pain.tinylib.logic.event.*;
import net.sourceforge.pain.util.*;

public class GuiToolEvent extends AbstractEvent {

    public Object execute(Object param) throws Exception {
        GuiToolConnection c = (GuiToolConnection) param;
        GTNetPacket packet = (GTNetPacket) c.inputEvents.removeFirst();
        try {
            if (packet == null) {
                Log.warn("GTNetPacket is null??");
                return null;
            }

            if (c.guiAdminId == null) {
                if (!"Login".equals(packet.eventClassName)) {
                    processFailedEvent(c, "Not logged in", packet.sequence_id);
                    return null;
                }
            }
            GuiEventHandler handler = getGuiEventHandler(packet);
            if (handler == null) {
                processFailedEvent(c, "Event handler not found:" + packet.eventClassName, packet.sequence_id);
            } else {
                handler.connection = c;
                handler.admin = c.guiAdminId == null ? null : (Administrator) Codebase.getDB().getObject(c.guiAdminId);
                handler.processEvent();
            }
        } catch (Exception e) {
            Log.error(e);
            processFailedEvent(c, "Internal Error:" + e.getMessage(), packet.sequence_id);
        }

        return null;
    }

    private static final String GT_EVENTS_PACKAGE_PREFIX = "net.sourceforge.pain.tinylib.logic.event.guitool.event.";
    private GuiEventHandler getGuiEventHandler(GTNetPacket packet) {
        try {
            GuiEventHandler h = (GuiEventHandler) Class.forName(GT_EVENTS_PACKAGE_PREFIX + packet.eventClassName).newInstance();
            h.packet = packet;
            return h;
        } catch (Exception e) {
            Log.error(e);
        }
        return null;
    }

    public static void processFailedEvent(GuiToolConnection c, Object note, int sequenceId) {
        c.send(new GTNetPacket("ERROR", note, sequenceId));
    }

    public static void sendInfoMessage(GuiToolConnection c, Object message, int sequenceId) {
        c.send(new GTNetPacket("INFO", message, sequenceId));
    }
}
