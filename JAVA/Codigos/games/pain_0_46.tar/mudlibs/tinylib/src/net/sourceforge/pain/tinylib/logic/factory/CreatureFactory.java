package net.sourceforge.pain.tinylib.logic.factory;

import net.sourceforge.pain.data.*;
import net.sourceforge.pain.tinylib.data.prototype.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.util.*;

/**
 * User: fmike  Date: Sep 13, 2003   Time: 8:38:14 PM
 */
public class CreatureFactory {

    public static void init(CreaturePrototype proto, Creature obj) throws Exception {
        int lifePoints = proto.getHPDice().roll();
        obj.setHitPoints(lifePoints);
        obj.setMaxHitPoints(lifePoints);
        int sex = proto.getSex();
        switch (sex) {
            case CreaturePrototype.SEX_FEMALE:
                sex = Creature.SEX_FEMALE;
                break;
            case CreaturePrototype.SEX_MALE:
                sex = Creature.SEX_MALE;
                break;
            case CreaturePrototype.SEX_UNDEFINED:
                sex = Creature.SEX_UNDEFINED;
                break;
            case CreaturePrototype.SEX_EITHER:
                sex = (System.currentTimeMillis() & 0x1) == 0 ? Creature.SEX_FEMALE : Creature.SEX_MALE;
                break;
            default:
                throw new RuntimeException("BUG!, life form prototype sex:" + sex);
        }
        Log.debug("setting sex to:" + sex);
        obj.setSex(sex);
        obj.setRace(proto.getRace());

        int moves = proto.getMovePointsDice().roll();
        obj.setMaxMoves(moves);
        obj.setMoves(moves);


        Space inventory = (Space) ObjectFactory.createObject(proto.getInventoryPrototype()).getRole(Space.class);
        inventory.setDesc("Inside inventory");
        obj.setInventory(inventory);
    }

}
