package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.*;
import net.sourceforge.pain.util.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;


public final class Backup extends GrantedCommand {


    public void processCommand() throws Exception {
        if (commandParams == null) {
            showHelp();
            return;
        }
        String fileName = commandParams.trim();
        long time = System.currentTimeMillis();
        try {
            Codebase.getDB().backupTo(fileName, false);
        } catch (Exception e) {
            MessageOutFn.outln(console, FormatUtils.formatStacktrace(e));
            throw e;
        }
        time = System.currentTimeMillis() - time;
        MessageOutFn.outln(console, "Done. time:" + (time / 1000D) + " sec.");
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": backups database to specified file");
        MessageOutFn.outln(console, "Usage:" + command.name + " <backup_db_file_name>");
        MessageOutFn.outln(console, "NOTE: last flush database image will be saved");
    }
}
