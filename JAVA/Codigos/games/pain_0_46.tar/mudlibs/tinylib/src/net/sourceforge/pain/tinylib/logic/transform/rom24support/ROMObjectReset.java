package net.sourceforge.pain.tinylib.logic.transform.rom24support;


public class ROMObjectReset {

    public ROMObject obj;
    public int count;
    public String comment;

    public String toString() {
        return "ROMObjectReset{" +
                "obj=" + obj.vnum +
                ", count=" + count +
                ", comment='" + comment + "'" +
                "}";
    }


}
