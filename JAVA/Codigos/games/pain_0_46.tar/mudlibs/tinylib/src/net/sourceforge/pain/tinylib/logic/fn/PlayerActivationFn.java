package net.sourceforge.pain.tinylib.logic.fn;

import net.sourceforge.pain.data.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.util.*;

import java.util.*;

/**
 * Methods for activate/inactivate player account on logon/logoff
 * User: fmike  Date: Jun 26, 2004  Time: 8:37:17 PM
 */
public final class PlayerActivationFn {

    public static void activatePlayerAccount(Player p) {
        relocatePlayerToSpaceBeforeQuit(p);
        freezeAllTimedAffects(p, false);
        addPlayerToActiveList(p);
    }

    public static void inactivatePlayerAccount(Player p) {
        removePlayerFromActiveList(p);
        freezeAllTimedAffects(p, true);
        relocatePlayerToQuitSpace(p);
    }

    private static void relocatePlayerToQuitSpace(Player p) {
        Located ploc = p.asLocated();
        p.setQuitSpace(ploc.getLocation());
        RelocateFn.relocate(ploc, Mudlib.getWorld().getPlayersQuitSpace());
    }

    private static void freezeAllTimedAffects(Player p, boolean freeze) {
        for (Iterator it = p.getAffects(); it.hasNext();) {
            AffectData ad = (AffectData) it.next();
            if (ad.isTimedAffect()) {
                TimedAffectData tad = (TimedAffectData) ad;
                tad.setFrozen(freeze);
            }
        }
    }

    private static void relocatePlayerToSpaceBeforeQuit(Player player) {
        final Located ploc = player.asLocated();
        final Space quitSpace = player.getQuitSpace();
        if (quitSpace != null) {
            try {
                RelocateFn.relocate(ploc, quitSpace);
            } catch (LogicException e) {
                if (e.errorCode == RelocationErrors.ERR_NOT_ENOUGH_TARGET_SPACE) {
                    MessageOutFn.outln(player, "The place you exited has not enough room to accept you back");
                }
                throw e;
            }
        } else {
            Log.warn("BUG:: player was disconnected with rollback");
            //todo: make this impossible
        }
    }

    private static void removePlayerFromActiveList(Player p) {
        Player prev = p.getPrevActivePlayer();
        Player next = p.getNextActivePlayer();
        p.setPrevActivePlayer(null);//playes os not active from now
        final World world = Mudlib.getWorld();
        final Player firstActivePlayer = world.getFirstActivePlayer();

        if (prev != p) {//prev is never null for active, if prev ==p this is last active player
            if (next != null) {
                next.setPrevActivePlayer(prev);
            } else { //p is last in list
                firstActivePlayer.setPrevActivePlayer(prev);
            }
            if (p != firstActivePlayer) {
                prev.setNextActivePlayer(next);
            } else {
                world.setFirstActivePlayer(next);
            }

        } else {
            world.setFirstActivePlayer(null);
        }


        p.setPrevActivePlayer(null);
        p.setNextActivePlayer(null);
    }

    private static void addPlayerToActiveList(Player player) {
        final World world = Mudlib.getWorld();
        Player firstActive = world.getFirstActivePlayer();
        player.setNextActivePlayer(null);
        if (firstActive == null) {
            player.setPrevActivePlayer(player);
            world.setFirstActivePlayer(player);
        } else {
            final Player prev = firstActive.getPrevActivePlayer();
            firstActive.setPrevActivePlayer(player);
            player.setPrevActivePlayer(prev);
            prev.setNextActivePlayer(player);
        }
    }

}
