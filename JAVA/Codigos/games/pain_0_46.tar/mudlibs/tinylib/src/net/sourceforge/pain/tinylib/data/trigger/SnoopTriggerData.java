package net.sourceforge.pain.tinylib.data.trigger;

import net.sourceforge.pain.data.*;
import net.sourceforge.pain.db.*;
import net.sourceforge.pain.tinylib.data.type.*;

public final class SnoopTriggerData extends TriggerData {

    private static final int SNOOPER = 1 + LAST_BASE_FIELD_INDEX;
    private static final int NFIELDS = 2 + LAST_BASE_FIELD_INDEX;

    public SnoopTriggerData() {
    }

    public SnoopTriggerData(PainDB db, Player snooper, Player snooped, Class triggerImplClass, int triggerType) throws Exception {
        super(db, snooped, triggerImplClass, triggerType);
        setSnooperPlayer(snooper);
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];
        fillSuperSchema(types, names);

        types[SNOOPER] = DbType.REFERENCE;
        names[SNOOPER] = "snooper_player";

        return new DbClassSchema(types, names);
    }

    public Player getSnooperPlayer() {
        return (Player) getReference(SNOOPER);
    }

    public void setSnooperPlayer(Player p) {
        setReference(SNOOPER, p);
    }

}
