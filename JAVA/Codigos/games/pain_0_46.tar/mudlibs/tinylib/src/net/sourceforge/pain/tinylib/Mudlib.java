package net.sourceforge.pain.tinylib;


import net.sourceforge.pain.tinylib.data.*;


public final class Mudlib {

    private static World world;
    public static  String CONFIG_DIR;

    private Mudlib() {
    }


    public static World getWorld() {
        return world;
    }

    protected static void setWorld(World world) {
        Mudlib.world = world;
    }
    

}

