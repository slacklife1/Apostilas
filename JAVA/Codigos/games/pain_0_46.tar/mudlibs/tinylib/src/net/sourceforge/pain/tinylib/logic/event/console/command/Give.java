package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;

public final class Give extends CommandHandler {

    public boolean isAccessible() {
        return super.isAccessible() && player.is(Creature.class);
    }


    public void processCommand() throws Exception {
        if (commandParams == null || commandParams.length() == 0) {
            MessageOutFn.outln(console, "Give what to whom?");
            return;
        }
        String[] tokens = Utils.WHITESPACE_SPLIT_PATTERN.split(commandParams.toLowerCase());
        if (tokens.length == 1 || (tokens.length == 2 && "to".equals(tokens[1]))) {
            MessageOutFn.outln(console, "Give to whom?");
            return;
        }
        String objName = tokens[0];
        String targetName = tokens.length > 2 && "to".equals(tokens[1]) ? tokens[2] : tokens[1];

        // look for obj
        Creature creature = (Creature) player.getRole(Creature.class);
        final Located plocated = player.asLocated();
        Interactive iObj = SpaceFindFn.findByPrefix(plocated, creature.getInventory(), objName);
        Physical physObj = iObj != null ? (Physical) iObj.getRole(Physical.class) : null;
        if (physObj == null) {
            if (iObj != null) {
                MessageOutFn.outln(console, "You failed.");
            } else {
                MessageOutFn.outln(console, "You do not have that item.");
            }
            return;
        }

        // look for target
        Interactive iTarget = SpaceFindFn.findByPrefix(plocated, targetName);
        Creature cTarget = iTarget != null ? (Creature) iTarget.getRole(Creature.class) : null;
        if (cTarget == null) {
            if (iTarget != null) {
                MessageOutFn.outln(console, "You failed.");
            } else {
                MessageOutFn.outln(console, "They aren't here.");
            }
            return;
        }
        if (cTarget.sameObjectAs(player)) {
            MessageOutFn.outln(console, "You failed.");
            return;
        }
        GiveFn.give(creature, physObj, cTarget);
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": use this command to give items to other persons");
    }

}
