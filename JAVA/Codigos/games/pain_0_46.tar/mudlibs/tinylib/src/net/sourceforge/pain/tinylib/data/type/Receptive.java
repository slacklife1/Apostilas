package net.sourceforge.pain.tinylib.data.type;


import net.sourceforge.pain.data.*;
import net.sourceforge.pain.db.*;

/**
 * Receptive objects can receive events from outside.<br>
 * Ability to SEE, to HEAR and to FEEL is a main parameters of Receptive object.
 * Receptive objects are required to be <code>Located</code>
 */
public final class Receptive extends Role {

    public static final int HEAR = 1 + LAST_BASE_FIELD_INDEX;
    public static final int SEE = 2 + LAST_BASE_FIELD_INDEX;
    public static final int FEEL = 3 + LAST_BASE_FIELD_INDEX; //touches, pain, ....
    private static final int NFIELDS = 4 + LAST_BASE_FIELD_INDEX;

    public final static Class superroles[] = new Class[]{Located.class};

    public Receptive(PainDB db) {
        super(db);
        setCanHear(true);
        setCanSee(true);
        setCanFeel(true);
    }

    public Receptive() {
    }


    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];
        fillSuperSchema(types, names);

        types[HEAR] = DbType.BOOLEAN;
        names[HEAR] = "can_hear";

        types[SEE] = DbType.BOOLEAN;
        names[SEE] = "can_see";

        types[FEEL] = DbType.BOOLEAN;
        names[FEEL] = "can_feel";

        return new DbClassSchema(types, names);
    }

    public Class[] getSuperroles() {
        return superroles;
    }

    public Located asLocated() {
        return (Located) getRole(Located.class);
    }


    public boolean canHear() {
        return getBoolean(HEAR);
    }

    public void setCanHear(boolean canHear) {
        setBoolean(HEAR, canHear);
    }

    public boolean canSee() {
        return getBoolean(SEE);
    }

    public void setCanSee(boolean canSee) {
        setBoolean(SEE, canSee);
    }

    public boolean canFeel() {
        return getBoolean(FEEL);
    }

    public void setCanFeel(boolean canFeel) {
        setBoolean(FEEL, canFeel);
    }

    public boolean has(int receptionType) {
        switch (receptionType) {
            case FEEL:
                return canFeel();
            case SEE:
                return canSee();
            case HEAR:
                return canHear();
            default:
                throw new RuntimeException("Unknown reception receptionType!:" + receptionType);
        }
    }
}
