package net.sourceforge.pain.tinylib.data.type;


import net.sourceforge.pain.data.*;
import net.sourceforge.pain.db.*;


/*
 If Space is Room it has exits (6 in default impl) and unique id
 All links are references to Exit objects
 */

public final class Room extends Role {

    private static final int NORTH = 1 + LAST_BASE_FIELD_INDEX;
    private static final int EAST = 2 + LAST_BASE_FIELD_INDEX;
    private static final int SOUTH = 3 + LAST_BASE_FIELD_INDEX;
    private static final int WEST = 4 + LAST_BASE_FIELD_INDEX;
    private static final int UP = 5 + LAST_BASE_FIELD_INDEX;
    private static final int DOWN = 6 + LAST_BASE_FIELD_INDEX;

    /**
     * since VNUM is prototype only property we should assign UNIQUE_ROOM_ID to
     * any space that statically referenced by code (by not db object)
     * every Room will have an UNIQUE_ROOM_ID - > some kind of VNUM but not VNUM
     */
    private static final int UNIQUE_ROOM_ID = 7 + LAST_BASE_FIELD_INDEX;

    private static final int AREA = 8 + LAST_BASE_FIELD_INDEX;

    private static final int NFIELDS = 9 + LAST_BASE_FIELD_INDEX;

    private static final int[] dbDirects = new int[]{NORTH, EAST, SOUTH, WEST, UP, DOWN};

    public final static Class[] superroles = new Class[]{Space.class};

    public Room() {
    }

    public Room(PainDB db) {
        super(db);
    }

    public Class[] getSuperroles() {
        return superroles;
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];
        fillSuperSchema(types, names);
        types[NORTH] = DbType.REFERENCE;
        names[NORTH] = "north";
        types[EAST] = DbType.REFERENCE;
        names[EAST] = "east";
        types[SOUTH] = DbType.REFERENCE;
        names[SOUTH] = "south";
        types[WEST] = DbType.REFERENCE;
        names[WEST] = "west";
        types[UP] = DbType.REFERENCE;
        names[UP] = "up";
        types[DOWN] = DbType.REFERENCE;
        names[DOWN] = "down";
        types[UNIQUE_ROOM_ID] = DbType.STRING;
        names[UNIQUE_ROOM_ID] = "unique_space_id";
        types[AREA] = DbType.REFERENCE;
        names[AREA] = "area";

        return new DbClassSchema(types, names);
    }

    public Exit getExit(int direction) {
        if (direction < 0 || direction > 6) {
            throw new IllegalArgumentException("wrong direction:" + direction);
        }
        return (Exit) getReference(dbDirects[direction]);
    }

    public void setExit(int direction, Exit exit) {
        if (direction < 0 || direction > 6) {
            throw new IllegalArgumentException("wrong direction:" + direction);
        }
        setReference(dbDirects[direction], exit);
    }

    public String getRoomUniqueId() {
        return getString(UNIQUE_ROOM_ID);
    }

    public void setRoomUniqueId(String id) {
        setString(UNIQUE_ROOM_ID, id);
    }

    public static final int DIR_NORTH = 0;
    public static final int DIR_EAST = 1;
    public static final int DIR_SOUTH = 2;
    public static final int DIR_WEST = 3;
    public static final int DIR_UP = 4;
    public static final int DIR_DOWN = 5;

    public final static int FIRST_DIR = DIR_NORTH;
    public final static int LAST_DIR = DIR_DOWN;

    public static final int[] reverseDir = new int[]{DIR_SOUTH, DIR_WEST, DIR_NORTH, DIR_EAST, DIR_DOWN, DIR_UP};

    public Space asSpace() {
        return (Space) getRole(Space.class);
    }

    public String getName() {
        return asSpace().getName();
    }

    public String getDesc() {
        return asSpace().getDesc();
    }

    public int getCapacity() {
        return asSpace().getCapacity();
    }

    public Area getArea() {
        return (Area) getReference(AREA);
    }

    public void setArea(Area area) {
        setReference(AREA, area);
    }
}
