package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;


public final class Who extends CommandHandler {

    public void processCommand() throws Exception {
        int n = 0;
        for (Player p = Mudlib.getWorld().getFirstActivePlayer(); p != null; p = p.getNextActivePlayer()) {
            MessageOutFn.outln(console, "  " + p.getInteractiveName());
            n++;
        }
        MessageOutFn.outln(console, "{x\nPlayers found: " + n + ".");
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": shows the players currently in game.");
    }
}
