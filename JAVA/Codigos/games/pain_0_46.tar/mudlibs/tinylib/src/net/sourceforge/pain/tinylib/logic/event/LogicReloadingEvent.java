package net.sourceforge.pain.tinylib.logic.event;

import net.sourceforge.pain.*;
import net.sourceforge.pain.network.console.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.util.*;

import java.util.*;

/**
 * PAiN  Date: 20.05.2003  Time: 1:11:25
 */
public class LogicReloadingEvent extends AbstractEvent {

    public Object execute(Object param) throws Exception {
        stopActiveSubShells();
        return null;
    }

    private void stopActiveSubShells() {
        // Moving all consoles to command mode!
        final UserConsoleManager cm = Codebase.getUserConsoleManager();
        for (Iterator it = cm.consoles().iterator(); it.hasNext();) {
            Console c = (Console) it.next();
            final Player p = c.getPlayer();
            if (p != null) {
                Log.debug(p.asInteractive().getName() + " raw:" + c.isRawMode());
                if (c.isRawMode() && c.getPlayer() != null) {
                    c.setCommandMode();
                    MessageOutFn.outln(c, "{wCode reloaded!{x");
                    ShowFn.showSpace(p.asReceptive(), p.asLocated().getLocation());
                } else {
                    c.setCommandMode();
                }
            } else {// player is just logging in
                MessageOutFn.outln(c, "\n{WAction aborted, server code is reloading!{x");
                c.setCommandMode();
                cm.closeConsole(c);
            }
        }
    }

}
