package net.sourceforge.pain.tinylib.data;

import net.sourceforge.pain.db.*;

/**
 * User: fmike  Date: May 9, 2004  Time: 2:42:26 AM
 */
public final class SiteBan extends DbObject {
    public static final int SITE_BAN_NEWBIES = 1;
    public static final int SITE_BAN_ALL = 2;

    private static final int SITE_IP = 0;
    private static final int SITE_HOST = 1;
    private static final int BAN_TYPE = 2;
    private static final int BAN_TIME = 3;
    private static final int ADMIN_NAME = 4;
    private static final int REASON = 5;
    private static final int NFIELDS = 6;

    public SiteBan() {
    }

    public SiteBan(final PainDB db, String siteIP, String hostName, int banType, String adminName, String reason) throws RuntimeException {
        super(db);
        setLong(BAN_TIME, System.currentTimeMillis());
        setString(REASON, reason);
        setString(ADMIN_NAME, adminName);
        setInt(BAN_TYPE, banType);
        setString(SITE_IP, siteIP);
        setString(SITE_HOST, hostName);
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        types[SITE_IP] = DbType.STRING;
        names[SITE_IP] = "site_ip";

        types[SITE_HOST] = DbType.STRING;
        names[SITE_HOST] = "site_host";

        types[BAN_TYPE] = DbType.INT;
        names[BAN_TYPE] = "ban_type";

        types[BAN_TIME] = DbType.LONG;
        names[BAN_TIME] = "ban_time";

        types[ADMIN_NAME] = DbType.STRING;
        names[ADMIN_NAME] = "admin_name";

        types[REASON] = DbType.STRING;
        names[REASON] = "reason";

        return new DbClassSchema(types, names);
    }

    public String getReason() {
        return getString(REASON);
    }

    public String getAdminName() {
        return getString(ADMIN_NAME);
    }

    public int getBanType() {
        return getInt(BAN_TYPE);
    }

    public long getBanTime() {
        return getLong(BAN_TIME);
    }

    public String getSiteIP() {
        return getString(SITE_IP);
    }

    public String getSiteHost() {
        return getString(SITE_HOST);
    }

    public static String getSiteBanKey(String ip, int type) {
        return ip + "_" + type;
    }

}

