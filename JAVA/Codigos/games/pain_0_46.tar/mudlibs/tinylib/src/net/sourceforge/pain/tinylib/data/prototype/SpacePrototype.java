package net.sourceforge.pain.tinylib.data.prototype;

import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.db.*;
import net.sourceforge.pain.tinylib.data.type.*;


/**
 * any Role instance with this type considered as Element of with internal Space (space inside object)
 */
public final class SpacePrototype extends Prototype {

    /**
     * Space capacity of the phisical objects, measured in the same units as Physical.size
     */
    private static final int CAPACITY = 1 + LAST_BASE_FIELD_INDEX;

    /**
     * any space could have specific name, or not:)  )
     */
    private static final int SPACE_NAME = 2 + LAST_BASE_FIELD_INDEX;

    /**
     * We can look around in any Space, event in backpack or chests
     */
    private static final int SPACE_DESC = 3 + LAST_BASE_FIELD_INDEX;


    private static final int NFIELDS = 4 + LAST_BASE_FIELD_INDEX;

    private final static Class superroles[] = new Class[]{PrototypeInfo.class};

    public SpacePrototype() {
    }

    public SpacePrototype(PainDB db) {
        super(db);
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        fillSuperSchema(types, names);

        types[CAPACITY] = DbType.INT;
        names[CAPACITY] = "capacity";

        types[SPACE_NAME] = DbType.STRING;
        names[SPACE_NAME] = "spaceName";

        types[SPACE_DESC] = DbType.STRING;
        names[SPACE_DESC] = "spaceDesc";

        return new DbClassSchema(types, names);
    }

    public String getSpaceDesc() {
        return getString(SPACE_DESC);
    }

    public void setSpaceDesc(String value) {
        setString(SPACE_DESC, value);
    }

    public String getSpaceName() {
        return getString(SPACE_NAME);
    }

    public void setSpaceName(String value) {
        setString(SPACE_NAME, value);
    }

    public int getCapacity() {
        return getInt(CAPACITY);
    }

    public void setCapacity(int value) {
        setInt(CAPACITY, value);
    }

    public Class getPrototypedRoleClass() {
        return Space.class;
    }

    protected Class[] getSuperroles() {
        return superroles;
    }
}
