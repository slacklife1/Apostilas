package net.sourceforge.pain.tinylib.logic.event.console.command.builder;

import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;

import java.util.*;

public final class BC_Exitname extends BuilderCommand {

    public void processBuilderCommand(BuilderShell p, String args) throws Exception {
        Space space = p.player.asLocated().getLocation();
        Room link = (Room) space.getRole(Room.class);
        if (args != null) {
            StringTokenizer st = new StringTokenizer(args, " ");
            String directionStr = st.nextToken();
            String desc = st.hasMoreTokens() ? st.nextToken("\n").trim() : null;
            if (desc == null) {
                showUsage(p.console);
                return;
            }
            if (directionStr.length() != 1) {
                MessageOutFn.outln(p.console, "ERROR:Illegal direction:" + directionStr);
                return;
            }
            int dir;
            try {
                dir = Utils.exitCharToDir(directionStr.charAt(0));
            } catch (Exception e) {
                MessageOutFn.outln(p.console, "ERROR:Illegal direction:" + directionStr);
                return;
            }
            Exit e = link == null ? null : link.getExit(dir);
            if (e == null) {
                MessageOutFn.outln(p.console, "ERROR:No exit found:" + LangUtil.exitName[dir]);
                return;
            }
            e.setExitDesc(desc);
            MessageOutFn.outln(p.console, "Exit desc changed to:{c" + desc + "{x");
        }
    }

    public void showUsage(Console console) {
        MessageOutFn.outln(console, "EXITNAME:Command syntax <DIRECTION> <EXIT_DESC>\n");
    }

    public void showHelp(Console console) {
        MessageOutFn.outln(console, "Builder command EXITNAME assign description for exit.");
        MessageOutFn.outln(console, "Usage: exitname <DIRECTION>  <EXIT_DESC>");
        MessageOutFn.outln(console, "{wDIRECTION{x is a letter from (N,E,S,W,U,D)");
    }

}
