package net.sourceforge.pain.tinylib.logic.event.guitool.event;

import net.sourceforge.pain.*;
import net.sourceforge.pain.db.*;
import net.sourceforge.pain.tinylib.logic.event.guitool.*;

import java.util.*;

public class DbLoadSchemaEvent extends GuiEventHandler {

    public void processEvent() {
        PainDB db = Codebase.getDB();
        ArrayList result = new ArrayList();
        for (Iterator it = db.getDbClassesIterator(); it.hasNext();) {
            DbClass clazz = (DbClass) it.next();
            String[] fieldNames = new String[clazz.getNumberOfFields()];
            byte[] fieldTypes = new byte[clazz.getNumberOfFields()];
            for (int i = 0; i < fieldNames.length; i++) {
                fieldNames[i] = clazz.getFieldName(i);
                fieldTypes[i] = clazz.getFieldType(i);
            }
            final ArrayList classInfo = new ArrayList();
            classInfo.add(clazz.getClassName());
            classInfo.add(fieldNames);
            classInfo.add(fieldTypes);
            result.add(classInfo);
        }

        send(result);
    }
}
