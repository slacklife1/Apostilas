package net.sourceforge.pain.tinylib.logic.event.console;


import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.logic.event.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.util.*;

public final class ConsoleExpiredEvent extends AbstractEvent {

    public Object execute(Object param) throws Exception {
        Log.debug("Console expired!");
        Console console = (Console) param;
        if (console.getPlayer() != null) {
            MessageOutFn.outln(console, "connection timeout..");
            ConsoleFn.logoutUser(console);
        }
        return null;
    }
}
