package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;


public final class Emote extends CommandHandler {

    public void processCommand() throws Exception {
        String emoteText = commandParams;
        if (emoteText == null || emoteText.length() == 0) {
            MessageOutFn.outln(console, "Emote what?");
        } else {
            MessageOutFn.outSpace(player, "$n $T", player, emoteText);
            MessageOutFn.outOne(player, "$n $T", player, emoteText);
        }
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": emote");
    }
}
