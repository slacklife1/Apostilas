package net.sourceforge.pain.tinylib.logic.event;

import net.sourceforge.pain.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;
import net.sourceforge.pain.util.*;

import java.util.*;

/**
 * PAiN  Date: 20.05.2003  Time: 1:11:25
 */
public class ShutdownWarn extends AbstractEvent {

    public Object execute(Object param) throws Exception {
        int timeInSec = ((Integer) param).intValue();
        String str;
        if (timeInSec < 0) {
            str = "{GShutdown Stopped!{x\n";
        } else if (timeInSec == 0) {
            str = "{GServer is shutting down!{x\n";
        } else {
            str = "{CServer will be shutted down in " + formatTime(timeInSec) + "!{x\n";
        }
        Collection consoles = new ArrayList(Codebase.getUserConsoleManager().consoles());
        for (Iterator it = consoles.iterator(); it.hasNext();) {
            MessageOutFn.outln((Console) it.next(), str);
        }
        if (timeInSec == 0) { //detaching consoles
            for (Iterator it = consoles.iterator(); it.hasNext();) {
                try {
                    ConsoleFn.logoutUser((Console) it.next());
                } catch (Exception e) {
                    Log.error(e.getMessage());
                }
            }
        }
        return null;
    }

    private static String formatTime(int timeInSec) {
        int hours = timeInSec / 3600;
        int minutes = (timeInSec % 3600) / 60;
        int secs = timeInSec % 60;
        StringBuffer result = new StringBuffer();
        if (hours > 0) {
            result.append("" + hours).append(LangUtil.s(hours, " hour"));
        }
        if (minutes > 0) {
            result.append("" + minutes).append(LangUtil.s(minutes, " minute"));
        }
        if (secs > 0) {
            result.append("" + secs).append(LangUtil.s(secs, " second"));
        }
        return result.toString();
    }
}
