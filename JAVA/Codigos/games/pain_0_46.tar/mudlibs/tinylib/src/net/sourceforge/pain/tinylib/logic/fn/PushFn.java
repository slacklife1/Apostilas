package net.sourceforge.pain.tinylib.logic.fn;

import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;

public class PushFn implements RelocationErrors {

    public static void push(Creature actor, Physical victim, int direction) {
        final Located victim_located = victim.asLocated();
        MessageOutFn.outOne(victim, "$n1 pushes you to $t2.", actor, LangUtil.exitName[direction]);
        MoveFn.checkCanMove(victim_located, direction);
        MessageOutFn.outOne(actor, "You push $n1 to $t2.", victim, LangUtil.exitName[direction]);
        MessageOutFn.outSpaceNoVictim(actor, victim.asInteractive(), "$n1 pushes $n2 to $t3.", actor, victim, LangUtil.exitName[direction]);
        MoveFn.move(victim_located, direction);
        if (victim.is(Receptive.class)) {
            ShowFn.showSpace((Receptive) victim.getRole(Receptive.class), victim_located.getLocation());
        }
        MessageOutFn.outSpace(victim, "$n arrives", victim);
    }
}
