package net.sourceforge.pain.tinylib.logic.event.console.command.builder;

import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

import java.util.*;

/**
 * PAiN  Date: 05.06.2003  Time: 1:40:02
 */
public final class BC_Resets extends BuilderCommand {

    public void processBuilderCommand(BuilderShell p, String args) throws Exception {
        Prototype r = p.builder.getEditedRole();
        PrototypeInfo pi;
        if (r == null) {
            MessageOutFn.outln(p.console, "No active prototype found!");
            return;
        }
        pi = (PrototypeInfo) r.getRole(PrototypeInfo.class);
        MessageOutFn.outln(p.console, "Resets for active prototype (vnum=" + pi.getVnum() + ") :");
        Map areasByName = Mudlib.getWorld().getAreasByName();
        int total = 0;
        for (Iterator it = areasByName.values().iterator(); it.hasNext();) {
            Area area = (Area) it.next();
            final Set resets = area.getResets();
            for (Iterator it2 = resets.iterator(); it2.hasNext();) {
                SpaceReset reset = (SpaceReset) it2.next();
                if (reset.getResettedPrototype() == pi) {
                    total++;
                    MessageOutFn.outln(p.console, "Group:" + area.getName() + " space:" + reset.getLocation().getName());
                }
            }
        }
        MessageOutFn.outln(p.console, "Found resets:" + total);
    }


    public void showHelp(Console console) {
        MessageOutFn.outln(console, "Builder command RESETS shows all reset of active prototype.");
        MessageOutFn.outln(console, "Usage: resets");
    }

}



