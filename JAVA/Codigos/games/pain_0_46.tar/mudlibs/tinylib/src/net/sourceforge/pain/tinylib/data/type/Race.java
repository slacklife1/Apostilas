package net.sourceforge.pain.tinylib.data.type;


import net.sourceforge.pain.data.*;
import net.sourceforge.pain.db.*;


/**
 * Any object with this type is a Race.
 * There will several predefined Races with different roles buckets,
 * but all of them will have Race role
 */
public final class Race extends Role {

    private static final int NAME = 1 + LAST_BASE_FIELD_INDEX;
    private static final int SIZE = 2 + LAST_BASE_FIELD_INDEX;
    private static final int NFIELDS = 3 + LAST_BASE_FIELD_INDEX;

    public Race(PainDB db) {
        super(db);
    }

    public Race() {
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        fillSuperSchema(types, names);

        types[NAME] = DbType.STRING;
        names[NAME] = "name";

        types[SIZE] = DbType.INT;
        names[SIZE] = "size";

        return new DbClassSchema(types, names);
    }

    public void setName(String name) {
        setString(NAME, name);
    }

    public String getName() {
        return getString(NAME);
    }

    public int getMinCreaturesSize() {
        return getInt(SIZE);
    }

    public void setCreaturesSize(int size) {
        setInt(SIZE, size);
    }
}

