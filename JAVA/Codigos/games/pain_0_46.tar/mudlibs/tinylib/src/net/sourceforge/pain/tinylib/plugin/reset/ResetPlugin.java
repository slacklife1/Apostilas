package net.sourceforge.pain.tinylib.plugin.reset;

import net.sourceforge.pain.*;
import net.sourceforge.pain.plugin.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.util.*;

import java.util.*;

public final class ResetPlugin extends Plugin implements PulseListener {

    public static final int RESETS_GRANULARITY = 10 * Pulse.PULSE_PER_SCD; // 3 seconds
    private int nextCheckTime = 0;


    public ResetPlugin() {
    }

    protected void init() throws Exception {
        Codebase.getPulse().addListener(this);
    }

    protected void deinit() {
        Codebase.getPulse().removeListener(this);
    }

    public void pulse(int time) {
        if (nextCheckTime > time) {
            return;
        }
        nextCheckTime = time + RESETS_GRANULARITY;
        Collection areas = Mudlib.getWorld().getAreasByName().values();
        for (Iterator it = areas.iterator(); it.hasNext();) {
            Area area = (Area) it.next();
            final int nextResetTime = area.getNextResetTime();
            if (nextResetTime > time) {
                nextCheckTime = nextResetTime < nextCheckTime ? nextResetTime : nextCheckTime;
            } else {
                reset(area);
                int groupResetPeriod = area.getResetPeriod();
                nextCheckTime = groupResetPeriod < nextCheckTime ? groupResetPeriod : nextCheckTime;
                area.setNextResetTime(time + groupResetPeriod);
                break; // one group per pulse
            }
        }
    }

    private static void reset(Area area) {
        try {
            Codebase.processEvent("ResetEvent", area);
        } catch (Exception e) {
            Log.error("ResetPlugin:", e);
        }
    }

}