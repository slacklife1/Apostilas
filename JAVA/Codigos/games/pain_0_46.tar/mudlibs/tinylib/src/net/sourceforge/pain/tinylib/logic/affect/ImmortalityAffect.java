package net.sourceforge.pain.tinylib.logic.affect;

import net.sourceforge.pain.*;
import net.sourceforge.pain.data.*;
import net.sourceforge.pain.logic.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

/**
 * User: fmike  Date: Mar 22, 2004  Time: 3:51:36 AM
 */
public final class ImmortalityAffect extends Affect {

    public ImmortalityAffect(AffectData ad) {
        super(ad);
    }

    public static void makeImmortal(Creature c) throws Exception {
        new AffectData(Codebase.getDB(), c, ImmortalityAffect.class, AffectType.AFFECT_IMMORTAL);
        MessageOutFn.outln(c, "Immortality ON");//just an example
    }

    public static void makeMortal(Creature c) throws Exception {
        AffectData ad = c.getAffectData(AffectType.AFFECT_IMMORTAL);
        if (ad == null) {
            return;
        }
        ad.delete();
        MessageOutFn.outln(c, "Immortality OFF!");//just an example
    }

}
