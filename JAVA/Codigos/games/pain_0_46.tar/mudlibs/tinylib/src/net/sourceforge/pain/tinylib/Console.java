package net.sourceforge.pain.tinylib;


import net.sourceforge.pain.*;
import net.sourceforge.pain.network.console.*;
import net.sourceforge.pain.tinylib.data.type.*;

import java.util.*;

/**
 * mudlib specific console extention
 */ 
public final class Console extends BasicConsole {

    private static final HashMap consoleByPlayerId = new HashMap();

    private Object playerId;

    protected Console(ConsoleAdapter adapter) {
        super(adapter);
    }

    public Player getPlayer() {
        return (Player) (playerId == null ? null : Codebase.getDB().getObject(playerId));
    }

    public void setPlayer(Player newPlayer) {
        if (playerId != null && newPlayer != null) {
            throw new RuntimeException("Owner redefinition not supported!");
        }
        if (playerId == null && newPlayer == null) {
            throw new RuntimeException("BUG, newPlayer is null!");
        }
        if (newPlayer == null) {
            consoleByPlayerId.remove(playerId);
            playerId = null;
        } else {
            playerId = newPlayer.getOid();
            consoleByPlayerId.put(newPlayer.getOid(), this);
        }
    }


    public static Console getConsoleByOwner(Player player) {
        return (Console) consoleByPlayerId.get(player.getOid());
    }
}
