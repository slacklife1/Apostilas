package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.plugin.social.*;
import net.sourceforge.pain.util.*;


public final class SocialHandler extends CommandHandler {

    public static final String SOCIAL_PLUGIN = "social.SocialPlugin";

    public void processCommand() throws Exception {
        Interactive source = (Interactive) console.getPlayer().getRole(Interactive.class);
        if (source == null) {
            MessageOutFn.outln(console, "You can't do that!");
            return;
        }
        Log.debug("processing social, TAG:" + command.tag);
        SocialEntry social = getSocialTemplate(command.tag);

        boolean needNoArgChar = false; //act as social without args for char
        boolean needNoArgRoom = false; //act as social without args for room(space)

        if (commandParams != null && commandParams.length() > 0) {
            Interactive victim = SpaceFindFn.findByPrefix(source.asLocated(), commandParams);
            if (victim == null) {
                if (social.template[SocialEntry.NOT_FOUND_CHAR] != null) {
                    MessageOutFn.outln(console, social.template[SocialEntry.NOT_FOUND_CHAR]);
                } else {
                    needNoArgChar = true;
                }
            } else if (victim == source) {
                if (social.template[SocialEntry.SELF_CHAR] != null) {
                    MessageOutFn.outln(console, social.template[SocialEntry.SELF_CHAR]);
                } else {
                    needNoArgChar = true;
                }
                if (social.template[SocialEntry.SELF_SPACE] != null) {
                    MessageOutFn.outSpace(source, social.template[SocialEntry.SELF_SPACE], source);
                } else {
                    needNoArgRoom = true;
                }
            } else {
                if (social.template[SocialEntry.FOUND_CHAR] != null) {
                    MessageOutFn.outOne(source, social.template[SocialEntry.FOUND_CHAR], source, victim);
                } else {
                    needNoArgChar = true;
                }
                if (social.template[SocialEntry.FOUND_VICT] != null) {
                    MessageOutFn.outOne(victim, social.template[SocialEntry.FOUND_VICT], source, victim);
                }
                if (social.template[SocialEntry.FOUND_NOVICT] != null) {
                    MessageOutFn.outSpaceNoVictim(source, victim, social.template[SocialEntry.FOUND_NOVICT], source, victim);
                } else {
                    needNoArgRoom = true;
                }
            }
        } else {
            needNoArgChar = true;
            needNoArgRoom = true;
        }

        if (needNoArgChar) {
            if (social.template[SocialEntry.NOARG_CHAR] != null) {
                MessageOutFn.outln(console, social.template[SocialEntry.NOARG_CHAR]);
            }
        }
        if (needNoArgRoom) {
            if (social.template[SocialEntry.NOARG_ROOM] != null) {
                MessageOutFn.outSpace(source, social.template[SocialEntry.NOARG_ROOM], source);
            }
        }
    }

    private static SocialEntry getSocialTemplate(String name) {
        SocialPlugin plugin = (SocialPlugin) Codebase.getPluginManager().getPlugin(SOCIAL_PLUGIN);
        return plugin.getSocial(name);
    }

    public void showHelp() {
        MessageOutFn.outln(console, "Social command");
    }
}
