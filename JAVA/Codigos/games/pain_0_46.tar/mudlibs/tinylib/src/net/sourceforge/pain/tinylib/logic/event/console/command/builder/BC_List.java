package net.sourceforge.pain.tinylib.logic.event.console.command.builder;

import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;

import java.util.*;

/**
 * PAiN  Date: 06.06.2003  Time: 0:52:45
 */
public class BC_List extends BuilderCommand {
    public void processBuilderCommand(BuilderShell p, String args) throws Exception {
        java.util.List protos = p.builder.getEditedPrototypesList();
        Console console = p.console;
        MessageOutFn.outln(console, "  List of prototypes:");
        if (protos.isEmpty()) {
            MessageOutFn.outln(console, "    No active prototypes found.\n");
        } else {
            MessageOutFn.outln(console, "    N" + Utils.whiteSpaceChars(5 - Utils.numStrLen(protos.size())) + "VNUM \tNAME");
            Prototype editedRole = p.builder.getEditedRole();
            PrototypeInfo active = editedRole == null ? null : (PrototypeInfo) editedRole.getRole(PrototypeInfo.class);
            int i = 0;
            for (Iterator it = protos.iterator(); it.hasNext(); i++) {
                PrototypeInfo pi = (PrototypeInfo) it.next();
                String name = pi.getName();
                String vnum = pi.getVnum();
                MessageOutFn.outln(console, "" + (pi == active ? "  {CA{x " : "    ") + i + Utils.whiteSpaceChars(5 - Utils.numStrLen(i)) + "{c" + vnum + "{x \t" + name);
            }
            MessageOutFn.outln(console, "{y====  Total:" + protos.size() + "{x");
        }

    }

    public void showHelp(Console console) {
        MessageOutFn.outln(console, "Builder command LIST shows list of edited prototypes");
        MessageOutFn.outln(console, "Usage: list");
    }
}
