package net.sourceforge.pain.tinylib.logic.event.guitool.event;

import net.sourceforge.pain.tinylib.logic.event.guitool.*;

public class ChangePassword extends GuiEventHandler {

    public void processEvent() {
        String[] data = (String[]) packet.data;
        String oldPass = data[0];
        String newPass = data[1];
        if (!admin.getPassword().equals(oldPass)) {
            GuiToolEvent.processFailedEvent(connection, "Wrong password", packet.sequence_id);
        } else if (newPass == null || newPass.length() == 0) {
            GuiToolEvent.processFailedEvent(connection, "Wrong password", packet.sequence_id);
        } else {
            admin.setPassword(newPass);
            GuiToolEvent.sendInfoMessage(connection, "OK", packet.sequence_id);
        }
    }
}
