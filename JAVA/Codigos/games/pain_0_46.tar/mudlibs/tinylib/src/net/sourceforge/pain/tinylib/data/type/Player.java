package net.sourceforge.pain.tinylib.data.type;


import net.sourceforge.pain.data.*;
import net.sourceforge.pain.db.*;

import java.util.*;


/**
 * Object considered to be a remote user instance.
 */
public final class Player extends Role {

    private static final int LOGIN = 1 + LAST_BASE_FIELD_INDEX;
    private static final int PASSWORD = 2 + LAST_BASE_FIELD_INDEX;

    /**
     * never is null (circular)
     */
    private static final int PREV_ACTIVE = 3 + LAST_BASE_FIELD_INDEX;

    /**
     * ends with null (line)
     */
    private static final int NEXT_ACTIVE = 4 + LAST_BASE_FIELD_INDEX;

    /**
     * players that logged off from the world are moved to special space. (uniqe per player)
     */
    private static final int QUIT_SPACE = 5 + LAST_BASE_FIELD_INDEX;

    /**
     * Granted commands allowed for player
     */
    private static final int GRANTED_COMMANDS = 6 + LAST_BASE_FIELD_INDEX;

    /**
     * common commands explicitly denied to execute by player
     */
    private static final int REJECTED_COMMANDS = 7 + LAST_BASE_FIELD_INDEX;

    private static final int NFIELDS = 8 + LAST_BASE_FIELD_INDEX;

    private final static Class superroles[] = new Class[]{Interactive.class, Receptive.class};


    public Player(PainDB db) {
        super(db);
    }

    public Player() {
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        fillSuperSchema(types, names);

        types[LOGIN] = DbType.STRING;
        names[LOGIN] = "login";

        types[PASSWORD] = DbType.STRING;
        names[PASSWORD] = "password";

        types[PREV_ACTIVE] = DbType.REFERENCE;
        names[PREV_ACTIVE] = "prev_active";

        types[NEXT_ACTIVE] = DbType.REFERENCE;
        names[NEXT_ACTIVE] = "next_active";

        types[QUIT_SPACE] = DbType.REFERENCE;
        names[QUIT_SPACE] = "quit_space";

        types[GRANTED_COMMANDS] = DbType.STRING_SET;
        names[GRANTED_COMMANDS] = "granted_commands";

        types[REJECTED_COMMANDS] = DbType.STRING_SET;
        names[REJECTED_COMMANDS] = "rejected_commands";

        return new DbClassSchema(types, names);
    }

    public void setPassword(String newPass) {
        setString(PASSWORD, newPass);
    }

    public String getPassword() {
        return getString(PASSWORD);
    }

    public void setLogin(String name) { //should be lowercase
        setString(LOGIN, name);
    }

    public String getLogin() { //lowercase
        return getString(LOGIN);
    }

    /**
     * only PlayerActivationFn is allowed to use this func
     */
    public void setPrevActivePlayer(Player p) {
        setReference(PREV_ACTIVE, p);
    }

    public Player getPrevActivePlayer() {
        return (Player) getReference(PREV_ACTIVE);
    }

    /**
     * only PlayerActivationFn is allowed to use this func
     */
    public void setNextActivePlayer(Player p) {
        setReference(NEXT_ACTIVE, p);
    }

    public Player getNextActivePlayer() {
        return (Player) getReference(NEXT_ACTIVE);
    }

    public void setQuitSpace(Space value) {
        setReference(QUIT_SPACE, value);
    }

    public Space getQuitSpace() {
        return (Space) getReference(QUIT_SPACE);
    }

    public Class[] getSuperroles() {
        return superroles;
    }

    public Space getLocation() {
        return asLocated().getLocation();
    }

    public Interactive asInteractive() {
        return (Interactive) getRole(Interactive.class);
    }

    public Receptive asReceptive() {
        return (Receptive) getRole(Receptive.class);
    }

    public Located asLocated() {
        return (Located) getRole(Located.class);
    }

    public Set getGrantedCommands() {
        return getStringSet(GRANTED_COMMANDS);
    }

    public Set getRejectedCommands() {
        return getStringSet(REJECTED_COMMANDS);
    }

    public String getInteractiveName() {
        return asInteractive().getName();
    }

    /**
     * playes is not active when logged off
     */
    public boolean isActive() {
        return getPrevActivePlayer() != null;
    }
}
