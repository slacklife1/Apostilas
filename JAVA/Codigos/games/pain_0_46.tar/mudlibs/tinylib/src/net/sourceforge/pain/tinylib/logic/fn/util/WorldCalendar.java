package net.sourceforge.pain.tinylib.logic.fn.util;


/**
 * Converts PAiN time into dates
 */
public class WorldCalendar {

    public static final String[] monthNames = new String[]{
        "Winter",
        "the Winter Wolf",
        "the Frost Giant",
        "the Old Forces",
        "the Grand Struggle",
        "the Spring",
        "Nature",
        "Futility",
        "the Dragon",
        "the Sun",
        "the Heat",
        "the Battle",
        "the Dark Shades",
        "the Shadows",
        "the Long Shadows",
        "the Ancient Darkness",
        "the Great Evil",
        "the Pain"
    };


    public static final String[] dayNames = new String[]{
        "the Moon",
        "the Bull",
        "Deception",
        "Thunder",
        "Freedom",
        "the Great Gods",
        "the Sun"
    };

    /**
     * 1 Earth year ~ 36 PAiN years
     * 1 PAiN year ~ 10 Earth days
     * 1 PAiN hour ~ 114 Earth seconds
     * REMARK: SOME SYSTEM CODE DEPENDS ON CALENDAR (Tickers, refreshers...)
     */

    public static final int PULSE_IN_YEAR = (int) Math.pow(2, 23);
    public static final int PULSE_IN_MONTH = PULSE_IN_YEAR / monthNames.length;

    /**
     * each month has 17 days
     */
    public static final int PULSE_IN_DAY = PULSE_IN_MONTH / 17;
    public static final int PULSE_IN_HOUR = PULSE_IN_DAY / 24;


    public int year;
    public int month;
    public int day;
    public int dayOfWeek;
    public int hour;

    public WorldCalendar(final int time) {
        year = time / PULSE_IN_YEAR;
        int residue = time % PULSE_IN_YEAR;
        month = residue / PULSE_IN_MONTH;
        residue = residue % PULSE_IN_MONTH;
        day = residue / PULSE_IN_DAY;
        dayOfWeek = day % dayNames.length;
        residue = residue % PULSE_IN_DAY;
        hour = residue / PULSE_IN_HOUR;
    }

}