package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

public final class Prompt extends CommandHandler {

    public void processCommand() throws Exception {
        if (commandParams == null) {
            String style = player.getRoleClientProperty(PromptFn.promptKey) == null ? "classic" : "visual";
            MessageOutFn.outln(console, "prompt style is {w" + style + "{x");
            return;
        }
        if ("classic".equals(commandParams)) {
            player.putRoleClientProperty(PromptFn.promptKey, null);
        } else if ("visual".equals(commandParams)) {
            player.putRoleClientProperty(PromptFn.promptKey, "visual");

        } else {
            showHelp();
        }

    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": changes user prompt presentation");
        MessageOutFn.outln(console, "params: <classic|visual>");
    }

}
