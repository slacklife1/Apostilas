package net.sourceforge.pain.tinylib.logic.fn;


import net.sourceforge.pain.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.util.*;

import java.util.*;

/**
 * this class used to out some system message (area reset, weather change)
 * to the specified range. TODO: more clear specification (shouts......)
 */
public final class RangeOutFn {

    public static final int RANGE_WORLD = 0;
//	public static final int RANGE_SPACE_GROUP = 1;


    public static void outWorld(String message) {
        if (message == null) {
            Log.error("Message is NULL!");
        } else {
            for (Iterator it = Codebase.getDB().extentIterator(Receptive.class); it.hasNext();) {
                Receptive r = (Receptive) it.next();
                MessageOutFn.outln(r, message, Receptive.HEAR);
            }
        }
    }
}
