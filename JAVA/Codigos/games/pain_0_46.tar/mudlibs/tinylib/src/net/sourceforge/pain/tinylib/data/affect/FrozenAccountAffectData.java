package net.sourceforge.pain.tinylib.data.affect;

import net.sourceforge.pain.data.*;
import net.sourceforge.pain.db.*;
import net.sourceforge.pain.tinylib.data.type.*;

/**
 * User: fmike  Date: May 8, 2004  Time: 1:24:26 AM
 */
public final class FrozenAccountAffectData extends AffectData {
    private static int REASON = LAST_BASE_FIELD_INDEX + 1;
    private static int FREEZE_DATE = LAST_BASE_FIELD_INDEX + 2;
    private static int ADMIN_NAME = LAST_BASE_FIELD_INDEX + 3;

    protected static int NFIELDS = LAST_BASE_FIELD_INDEX + 4;

    public FrozenAccountAffectData() {
    }

    public FrozenAccountAffectData(PainDB db, String adminName, Player victim, String reason, Class aClass, int typeId) throws Exception {
        super(db, victim, aClass, typeId);
        setReason(reason);
        setFreezeDate(System.currentTimeMillis());
        setAdminName(adminName);
    }


    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];
        fillSuperSchema(types, names);

        types[REASON] = DbType.STRING;
        names[REASON] = "reason";

        types[FREEZE_DATE] = DbType.LONG;
        names[FREEZE_DATE] = "freeze_date";

        types[ADMIN_NAME] = DbType.STRING;
        names[ADMIN_NAME] = "admin_name";

        return new DbClassSchema(types, names);

    }

    public void setReason(String reason) {
        setString(REASON, reason);
    }

    public String getReason() {
        return getString(REASON);
    }

    private void setAdminName(String name) {
        setString(ADMIN_NAME, name);
    }

    public String getAdminName() {
        return getString(ADMIN_NAME);
    }

    private void setFreezeDate(long time) {
        setLong(FREEZE_DATE, time);
    }

    /**
     * date-time in millis
     */
    public long getFreezeDate() {
        return getLong(FREEZE_DATE);
    }


}
