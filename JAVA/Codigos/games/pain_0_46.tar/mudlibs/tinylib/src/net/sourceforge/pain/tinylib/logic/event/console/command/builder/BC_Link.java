package net.sourceforge.pain.tinylib.logic.event.console.command.builder;

import net.sourceforge.pain.data.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;

import java.util.*;

/**
 * PAiN  Date: 05.06.2003  Time: 1:40:02
 */
public final class BC_Link extends BuilderCommand {

    public void processBuilderCommand(BuilderShell p, String args) throws Exception {
        boolean failed = true;
        final Space space = p.player.asLocated().getLocation();
        Room fromRoomRole = (Room) space.getRole(Room.class);
        if (args != null) {
            StringTokenizer st = new StringTokenizer(args, " ");
            final String directionStr = st.nextToken();
            final int dir = Utils.exitNameToDir(directionStr);
            if (dir == -1) {
                MessageOutFn.outln(p.console, "ERROR:Illegal direction:" + directionStr);
                return;
            }
            Exit e = fromRoomRole == null ? null : fromRoomRole.getExit(dir);
            if (e != null) {
                MessageOutFn.outln(p.console, "ERROR:Direction is busy:" + e.getTargetRoom().asSpace().getName());
                return;
            }
            boolean single = false;
            if (st.hasMoreTokens()) {
                String uniqueName = null;
                String token = st.nextToken();
                if ("SINGLE".equalsIgnoreCase(token)) {
                    single = true;
                    if (st.hasMoreTokens()) {
                        uniqueName = st.nextToken("\n").trim();
                    }
                } else {
                    uniqueName = token;
                }
                if (uniqueName != null) {
                    Room targetIndexedSpace = (Room) Mudlib.getWorld().getRoomsByIdMap().get(uniqueName);
                    if (targetIndexedSpace == null) {
                        MessageOutFn.outln(p.console, "ERROR: no named space found with name:" + uniqueName);
                        return;
                    }

                    Room targetRoomRole = (Room) targetIndexedSpace.getRole(Room.class);
// here we should ensure that we deal with Rooms but not with simple Spaces
// we should add Room role to src and dst Spaces if they are not Rooms
                    if (fromRoomRole == null) {
                        fromRoomRole = (Room) space.addRole(Room.class);
                    }
                    if (targetRoomRole == null) {
                        targetRoomRole = (Room) targetIndexedSpace.addRole(Room.class);
                    }
                    int reverseDir = Room.reverseDir[dir];
                    if (!single && targetRoomRole.getExit(reverseDir) != null) {
                        MessageOutFn.outln(p.console, "ERROR: reverse dir is used, use SINGLE option to create single way link");
                        return;
                    }
                    // ok, creating!
                    failed = false;
                    link(p.console, fromRoomRole, dir, targetRoomRole);
                    if (!single) { //backward link
                        link(p.console, targetRoomRole, reverseDir, fromRoomRole);
                    }


                }
            }

        }
        if (failed) {
            showUsage(p.console);
        }
    }

    private static void link(Console console, Room fromRoom, int dir, Room targetRoom) throws Exception {
        MessageOutFn.outln(console, "Creating link from {Y" + fromRoom.asSpace().getName() + "{x direction:{C" + LangUtil.exitName[dir] + "{x target space:{Y" + targetRoom.asSpace().getName() + "{x");
        Room link = (Room) fromRoom.getRole(Room.class);
        if (link == null) {
            link = (Room) fromRoom.addRole(Room.class);
        }
        Exit e = (Exit) ObjectFactory.createRaw(Exit.class);
        e.setTargetRoom(targetRoom);
        link.setExit(dir, e);
    }


    public void showUsage(Console console) {
        MessageOutFn.outln(console, "LINK:Command syntax <DIRECTION> [SINGLE] <UNIQUE_ROOM_ID>\n");
    }

    public void showHelp(Console console) {
        MessageOutFn.outln(console, "Builder command LINK creates exit from current room to other.");
        MessageOutFn.outln(console, "Usage: link <DIRECTION> [SINGLE] <UNIQUE_ROOM_ID>");
        MessageOutFn.outln(console, "{wDIRECTION{x is a letter from (N,E,S,W,U,D)");
        MessageOutFn.outln(console, "{wSINGLE{x is optional param. Used when single way link should be created");
        MessageOutFn.outln(console, "{wUNIQUE_ROOM_ID{x is unique name of the target space");
        MessageOutFn.outln(console, "NOTE: 'Room' role will be added to current or target space if needed");
    }

}
