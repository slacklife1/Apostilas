package net.sourceforge.pain.tinylib.logic.event.guitool.event;

import net.sourceforge.pain.*;
import net.sourceforge.pain.tinylib.logic.event.guitool.*;
import net.sourceforge.pain.tinylib.plugin.shutdown.*;

public class RestartGTEvent extends GuiEventHandler {

    public void processEvent() {
        String[] data = (String[]) packet.data;
        if ("shutdown".equals(data[0])) {
            ShutdownTimer t = (ShutdownTimer) Codebase.getPluginManager().getPlugin("shutdown.ShutdownTimer");
            t.startShutdown(10, true);
            send("Shutdown in 10 seconds");
        } else {
            send("Wrong action");
        }

    }
}
