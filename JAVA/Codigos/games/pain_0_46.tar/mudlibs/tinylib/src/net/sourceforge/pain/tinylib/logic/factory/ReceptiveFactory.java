package net.sourceforge.pain.tinylib.logic.factory;

import net.sourceforge.pain.tinylib.data.prototype.*;
import net.sourceforge.pain.tinylib.data.type.*;


/**
 * User: fmike  Date: Sep 13, 2003   Time: 8:38:14 PM
 */
public class ReceptiveFactory {

    public static void init(ReceptivePrototype proto, Receptive obj) {
        obj.setCanFeel(proto.canFeel());
        obj.setCanHear(proto.canHear());
        obj.setCanSee(proto.canSee());
    }
}
