package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

public final class Get extends CommandHandler {

    public boolean isAccessible() {
        return super.isAccessible() && player.is(Creature.class);
    }


    public void processCommand() throws Exception {
        String targetName = commandParams;
        if (targetName == null) {
            MessageOutFn.outln(console, "Get what?");
            return;
        }
        Interactive iTarget = SpaceFindFn.findByPrefix(player.asLocated(), targetName);
        Physical physTarget = iTarget != null ? (Physical) iTarget.getRole(Physical.class) : null;
        if (physTarget == null) {
            if (iTarget != null) {
                MessageOutFn.outln(console, "You failed.");
            } else {
                MessageOutFn.outln(console, "I see no " + targetName + " here.");
            }
            return;
        }
        try {
            GetFn.get((Creature) player.getRole(Creature.class), physTarget);
        } catch (LogicException e) {
            if (e.errorCode == RelocationErrors.ERR_NOT_ENOUGH_TARGET_SPACE) {
                MessageOutFn.outln(console, "There's no more room there.");
            } else {
                throw e;
            }
        }
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": use this command to get items");
    }

}
