package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.data.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.affect.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;


public final class Kill extends CommandHandler {

    public void processCommand() throws Exception {
        String target = commandParams;
        if (target == null || target.length() == 0) {
            MessageOutFn.outln(console, "Kill whom?");
        } else {
            final Interactive victim = SpaceFindFn.findByPrefix(player.asLocated(), target);
            if (victim == null) {
                MessageOutFn.outln(console, "They aren't here");
            } else if (victim.sameObjectAs(player)) {
                MessageOutFn.outln(console, "Suicide is a mortal sin.");
            } else if (victim.isAffected(AffectType.AFFECT_IMMORTAL)) {
                MessageOutFn.outln(console, "You failed.");
            } else {
                Creature creature = (Creature) victim.getRole(Creature.class);
                if (creature == null) {
                    MessageOutFn.outln(console, "You failed.");
                } else {
                    // real kill!!
                    MessageOutFn.outOne(victim, "$n {*{R[*] POWER HIT [*]{x you", player);
                    MessageOutFn.outOne(player, "You {*{R[*] POWER HIT [*]{x $n", victim);
                    MessageOutFn.outSpaceNoVictim(player, victim, "$n {*{R[*] POWER HIT [*]{x $N", player, victim);
                    MessageOutFn.outln(victim, "You have been KILLED!");
                    Console victimConsole = ConsoleFn.getConsole(victim);
                    if (victimConsole != null) {
                        ConsoleFn.forceDisconnect(victimConsole);
                    }
                    MessageOutFn.outOne(player, "$n is DEAD!", victim);
                    MessageOutFn.outSpaceNoVictim(player, victim, "$n is DEAD!", victim);
                    ObjectFactory.destroyObject(victim);
                }
            }
        }
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": allow you to kill any creature in room");
    }
}
