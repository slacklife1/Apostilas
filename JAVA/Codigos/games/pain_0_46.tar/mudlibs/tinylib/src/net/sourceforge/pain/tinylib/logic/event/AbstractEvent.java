package net.sourceforge.pain.tinylib.logic.event;

import net.sourceforge.pain.*;
import net.sourceforge.pain.db.*;
import net.sourceforge.pain.logic.*;

/**
 * AbstractEvent is a base class for any Event, this class is a first reloadable class in Events hierarchy
 */
public abstract class AbstractEvent implements Event {

    public Object processEvent(final Object param) throws Exception {
        final DbTransaction t = new DbTransaction() {
            public Object execute(Object[] params) throws Exception {
                return AbstractEvent.this.execute(param);
            }
        };
        return Codebase.getDB().execute(t);
    }

    public AbstractEvent() {
        // debug check
        ClassLoader loader = Codebase.getLogicLoader().getActiveClassLoader();
        if (loader != getClass().getClassLoader()) {
            throw new RuntimeException("Event impl was loaded with illegal classloader");
        }
    }

    public abstract Object execute(Object param) throws Exception;

}
