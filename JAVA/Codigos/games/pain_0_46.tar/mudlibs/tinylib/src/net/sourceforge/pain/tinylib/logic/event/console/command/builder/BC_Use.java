package net.sourceforge.pain.tinylib.logic.event.console.command.builder;

import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

import java.util.*;

/**
 * PAiN  Date: 05.06.2003  Time: 1:40:02
 */
public final class BC_Use extends BuilderCommand {

    public void processBuilderCommand(BuilderShell p, String args) throws Exception {
        if (p.activeCommand == null) {
            if (args != null && args.length() > 0) {
                String params[] = new String[2];
                ConsoleInputEvent.parseCommand(args, params);
                params[0] = params[0].toLowerCase();
                if ("vnum".equals(params[0])) {
                    switchToVnum(p, params[1]);
                } else if ("role".equals(params[0])) {
                    switchToRole(p, params[1]);
                } else if (params[1] == null) {
                    switchToProtoInList(p, params[0]);
                } else {
                    showUsage(p);
                }
            } else if (p.builder.getEditedRole() == null) {
                showUsage(p);
            } else { //do nothing
                return;
            }
        } else {
            MessageOutFn.outln(p.console, "not implemented!\n");
            p.setActiveCommand(null);
        }
    }

    private void switchToProtoInList(BuilderShell p, String num) {
        if (num == null) {
            showUsage(p);
        }
        try {
            int n = Integer.parseInt(num);
            java.util.List prototypes = p.builder.getEditedPrototypesList();
            if (n < 0 || n >= prototypes.size()) {
                MessageOutFn.outln(p.console, "No such element in edit list:" + n);
            } else {
                p.builder.setEditedRole((PrototypeInfo) prototypes.get(n));
                MessageOutFn.outln(p.console, "edited prototype changed to " + n + " in list");
            }
        } catch (NumberFormatException e) {
            showUsage(p);
        }

    }

    private void switchToRole(BuilderShell p, String roleName) {
        if (roleName == null) {
            showUsage(p);
        }
        Prototype editedRole = p.builder.getEditedRole();
        if (editedRole == null) {
            MessageOutFn.outln(p.console, "Active prototype not found");
            return;
        }

        Class clazz = null;
        try {
            clazz = Class.forName("net.sourceforge.pain.tinylib.data.prototype." + roleName);
        } catch (ClassNotFoundException e) {
        }
        Prototype prot;
        if (clazz == null || (prot = (Prototype) editedRole.getRole(clazz)) == null) {
            MessageOutFn.outln(p.console, "No such role:" + roleName);
        } else {
            p.builder.setEditedRole(prot);
            MessageOutFn.outln(p.console, "Edited role setted to:" + roleName);
        }


    }

    private void switchToVnum(BuilderShell p, String vnum) {
        if (vnum == null) {
            showUsage(p);
        }
        PrototypeInfo pi = (PrototypeInfo) Mudlib.getWorld().getPrototypesByVnumMap().get(vnum);
        if (pi == null) {
            MessageOutFn.outln(p.console, "No prototype found with vnum: '" + vnum + "'");
//			Set set = Mudlib.getWorld().getPrototypesRegistry().getPrototypesMap().keySet();
//			for (Iterator it = set.iterator(); it.hasNext();) {
//				Object key = it.next();
//				MessageOutFn.outln(p.console, "'" + key + "' " + key.getClass().getLogin());
//			}
        } else {
            List prototypes = p.builder.getEditedPrototypesList();
            if (!prototypes.contains(pi)) {
                MessageOutFn.outln(p.console, "Adding prototype to edit list, vnum:" + vnum);
                prototypes.add(pi);
            }
            p.builder.setEditedRole(pi);
            MessageOutFn.outln(p.console, "Edited prototype changed to prototype with vnum:" + vnum);
        }
    }

    private void showUsage(BuilderShell p) {
        MessageOutFn.outln(p.console, "Use:Command syntax: \n\t1) vnum <VNUM> \n\t2) role <ROLE_NAME> \n\t3) <NUM>  - number of prototype in list \n\t4) <no params> - nothing \n");
    }

    public void showHelp(Console console) {
        MessageOutFn.outln(console, "Builder command USE changes the edited prototype");
        MessageOutFn.outln(console, "Usage: use vnum <VNUM> - changes edited prototype to VNUM and adds it to edited prototypes list");
        MessageOutFn.outln(console, "Usage: use role <ROLE_NAME> - changes the edited role of current prototype");
        MessageOutFn.outln(console, "Usage: use <NUM> - changes the edited edited prototype to prototype with  NUM index in the edited prototypes list");
    }

}
