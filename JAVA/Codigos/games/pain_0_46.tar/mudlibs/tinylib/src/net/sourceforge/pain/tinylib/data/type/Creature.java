package net.sourceforge.pain.tinylib.data.type;

import net.sourceforge.pain.data.*;
import net.sourceforge.pain.db.*;


public final class Creature extends Role {

    private static final int MAX_HP = 1 + LAST_BASE_FIELD_INDEX;
    private static final int HP = 2 + LAST_BASE_FIELD_INDEX;
    private static final int RACE = 3 + LAST_BASE_FIELD_INDEX;
    private static final int SEX = 4 + LAST_BASE_FIELD_INDEX;
    private static final int INVENTORY = 5 + LAST_BASE_FIELD_INDEX;;
    private static final int MAX_MOVES = 6 + LAST_BASE_FIELD_INDEX;
    private static final int MOVES = 7 + LAST_BASE_FIELD_INDEX;
    private static final int NFIELDS = 8 + LAST_BASE_FIELD_INDEX;


    /**
     * only 3 values allowed for sex. If you wnat to have more mystical ones you should name it by different name
     * in different role.
     */
    public static final int SEX_UNDEFINED = 0;
    public static final int SEX_MALE = 1;
    public static final int SEX_FEMALE = 2;


    public final static Class superroles[] = new Class[]{Physical.class, Receptive.class};

    public Creature(PainDB db) {
        super(db);
    }

    public Creature() {
    }

    public Class[] getSuperroles() {
        return superroles;
    }


    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        fillSuperSchema(types, names);

        types[MAX_HP] = DbType.INT;
        names[MAX_HP] = "max_hp";

        types[HP] = DbType.INT;
        names[HP] = "hp";

        types[RACE] = DbType.REFERENCE;
        names[RACE] = "race";

        types[SEX] = DbType.INT;
        names[SEX] = "sex";

        types[INVENTORY] = DbType.REFERENCE;
        names[INVENTORY] = "inventory";

        types[MAX_MOVES] = DbType.INT;
        names[MAX_MOVES] = "max_moves";

        types[MOVES] = DbType.INT;
        names[MOVES] = "moves";

        return new DbClassSchema(types, names);
    }

    public void setHitPoints(int value) {
        setInt(HP, value);
    }

    public void setMaxHitPoints(int value) {
        setInt(MAX_HP, value);
    }

    public int getHitPoints() {
        return getInt(HP);
    }

    public int getMaxLifePoints() {
        return getInt(MAX_HP);
    }

    public Interactive asInteractive() {
        return (Interactive) getRole(Interactive.class);
    }

    public Race getRace() {
        return (Race) getReference(RACE);
    }

    public void setRace(Race race) {
        setReference(RACE, race);
    }

    public int getSex() {
        return getInt(SEX);
    }

    public void setSex(int sex) {
        setInt(SEX, sex);
    }

    public boolean isMale() {
        return getSex() == SEX_MALE;
    }

    public boolean isFemale() {
        return getSex() == SEX_FEMALE;
    }


    public Space getInventory() {
        return (Space) getReference(INVENTORY);
    }

    public void setInventory(Space inventory) {
        setReference(INVENTORY, inventory);
    }

    public void setMoves(int value) {
        setInt(MOVES, value);
    }

    public void setMaxMoves(int value) {
        setInt(MAX_MOVES, value);
    }

    public int getMoves() {
        return getInt(MOVES);
    }

    public int getMaxMoves() {
        return getInt(MAX_MOVES);
    }


    public final void delete() {
        getInventory().delete();
        super.delete();
    }

    public Located asLocated() {
        return (Located) getRole(Located.class);
    }

    public Receptive asReceptive() {
        return (Receptive) getRole(Receptive.class);
    }
}

