package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.data.*;
import net.sourceforge.pain.tinylib.data.trigger.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;
import net.sourceforge.pain.tinylib.logic.trigger.*;
import net.sourceforge.pain.tinylib.logic.trigger.impl.*;

import java.util.*;


public final class Snoop extends GrantedCommand {


    public void processCommand() throws Exception {
        if ("STOP".equals(command.tag)) {
            stopSnoop();
        } else {
            startSnoop();
        }
    }

    private void stopSnoop() {
        if (commandParams == null || commandParams.length() == 0) {
            MessageOutFn.outln(console, "Stop snoop whom?");
            return;
        }
        String name = commandParams;
        final Player victim = GlobalFindFn.findPlayerByName(name);
        if (victim == null) {
            MessageOutFn.outln(console, "No player found with name {c" + Utils.formatName(name) + "{x");
            return;
        }
        Class snoopClass = SnoopTriggerData.class;
        for (Iterator it = victim.getTriggersByEventType(TriggerType.TRIGGER_CONSOLE_INPUT); it.hasNext();) {
            TriggerData td = (TriggerData) it.next();
            if (td.getClass() == snoopClass && ((SnoopTriggerData) td).getSnooperPlayer() == player) {
                it.remove();//will delete trigger data from db
                MessageOutFn.outln(console, "Done.");
                return;
            }
        }
        MessageOutFn.outln(console, "Not snooped");
    }

    private void startSnoop() throws Exception {
        if (commandParams == null || commandParams.length() == 0) {
            MessageOutFn.outln(console, "Snoop whom?");
            return;
        }
        String name = commandParams;
        final Player victim = GlobalFindFn.findPlayerByName(name);
        if (victim == null) {
            MessageOutFn.outln(console, "No player found with name {c" + Utils.formatName(name) + "{x");
            return;
        }
        if (victim == player) {
            MessageOutFn.outln(console, "You failed");
            return;
        }
        //SnoopTriggerData is a persistent image of trigger
        if (isSnooped(victim, player)) {
            MessageOutFn.outln(console, "Already snooped");
            return;
        }
        SnoopTrigger.makeSnooper(player, victim);
        MessageOutFn.outln(console, "Done.");
    }

    public static boolean isSnooped(Player victim, Player player) {
        Class snoopClass = SnoopTriggerData.class;
        for (Iterator it = victim.getTriggersByEventType(TriggerType.TRIGGER_CONSOLE_INPUT); it.hasNext();) {
            TriggerData td = (TriggerData) it.next();
            if (td.getClass() == snoopClass && ((SnoopTriggerData) td).getSnooperPlayer() == player) {
                return true;
            }
        }
        return false;
    }

    public void showHelp() {
        if ("STOP".equals(command.tag)) {
            MessageOutFn.outln(console, command.name + ": stops snoops on player input");
        } else {
            MessageOutFn.outln(console, command.name + ": snoops on player input");
        }
        MessageOutFn.outln(console, "Usage:" + command.name + " <player_name>");
    }
}
