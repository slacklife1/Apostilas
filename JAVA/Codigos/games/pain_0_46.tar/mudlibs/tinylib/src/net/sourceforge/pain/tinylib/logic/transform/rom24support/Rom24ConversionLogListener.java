package net.sourceforge.pain.tinylib.logic.transform.rom24support;

/**
 * User: fmike  Date: Mar 20, 2004  Time: 1:36:21 AM
 */
public interface Rom24ConversionLogListener {

    void onConversionMessage(String message);
}
