package net.sourceforge.pain.tinylib.logic.event.console.command.builder;

import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;

import java.util.*;

/**
 * PAiN  Date: 05.06.2003  Time: 1:40:02
 */
public final class BC_Unlink extends BuilderCommand {

    public void processBuilderCommand(BuilderShell p, String args) throws Exception {
        boolean failed = true;
        final Space space = p.player.asLocated().getLocation();
        Room room = (Room) space.getRole(Room.class);
        if (room == null) {
            MessageOutFn.outln(p.console, "ERROR:No exists found");
            return;
        }
        if (args != null) {
            StringTokenizer st = new StringTokenizer(args, " ");
            final String directionStr = st.nextToken();
            if (directionStr.length() != 1) {
                MessageOutFn.outln(p.console, "Illegal direction:" + directionStr);
                return;
            }
            final int dir;
            try {
                dir = Utils.exitCharToDir(directionStr.charAt(0));
            } catch (Exception e) {
                MessageOutFn.outln(p.console, "Illegal direction:" + directionStr);
                return;
            }
            Exit e = room.getExit(dir);
            if (e == null) {
                MessageOutFn.outln(p.console, "ERROR:No exists found");
                return;
            }
            boolean single = false;
            if (!st.hasMoreTokens() || (single = "SINGLE".equals(st.nextToken()))) {
                failed = false;
                Room targetRoom = e.getTargetRoom();
                if (!single) {
                    int reverseDir = Room.reverseDir[dir];
                    Exit reverseExit = targetRoom.getExit(reverseDir);
                    if (reverseExit != null) {
                        unlink(p.console, targetRoom, reverseDir, room);
                    }
                }
                unlink(p.console, room, dir, targetRoom);
            }
        }
        if (failed) {
            showUsage(p.console);
        }
    }

    void unlink(Console console, Room link, int dir, Room targetRoom) throws Exception {
        Space space = link.asSpace();
        MessageOutFn.outln(console, "Destroying path from {Y" + space.getName() + "{x direction:{C" + LangUtil.exitName[dir] + "{x to {Y" + targetRoom.asSpace().getName() + "{x");
        Exit e = link.getExit(dir);
        e.delete();
    }

    public void showUsage(Console console) {
        MessageOutFn.outln(console, "UNLINK:Command syntax <DIRECTION> [SINGLE]\n");
    }

    public void showHelp(Console console) {
        MessageOutFn.outln(console, "Builder command UNPATH destroys exit from current space");
        MessageOutFn.outln(console, "Usage: unlink <DIRECTION> [SINGLE]");
        MessageOutFn.outln(console, "where {wDIRECTION{x is a letter from (N,E,S,W,U,D)");
        MessageOutFn.outln(console, "if {wSINGLE{x option is specified only single way link will be destroyed");
        MessageOutFn.outln(console, "NOTE: Room role will be removed from current or target space ");
        MessageOutFn.outln(console, "      if no other exits will found from space");
    }

}
