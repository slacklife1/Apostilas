package net.sourceforge.pain.tinylib.logic.transform.rom24support;


import java.util.*;


public class ROMObject {

    public String vnum;
    public String[] nameList;
    public String shortDesc;
    public String longDesc;

    public String material;

    public String typeFlags;
    public String extraFlags;
    public String wearFlags;

    public String value[] = new String[5];

    public int level;
    public int weight;
    public int cost;
    public String condition;

    public List applies;
    public List extreDesc;

    public int limit;

    public ROMObject(String vnum) {
        this.vnum = vnum;
    }

}

