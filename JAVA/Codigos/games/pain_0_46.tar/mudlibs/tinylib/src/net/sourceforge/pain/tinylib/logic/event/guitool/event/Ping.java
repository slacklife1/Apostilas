package net.sourceforge.pain.tinylib.logic.event.guitool.event;

import net.sourceforge.pain.network.guitool.*;
import net.sourceforge.pain.tinylib.logic.event.guitool.*;

public class Ping extends GuiEventHandler {

    public void processEvent() {
        connection.send(new GTNetPacket("Ping", "pong", packet.sequence_id));
    }

}
