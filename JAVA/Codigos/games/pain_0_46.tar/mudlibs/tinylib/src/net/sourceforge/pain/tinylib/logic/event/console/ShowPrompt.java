package net.sourceforge.pain.tinylib.logic.event.console;


import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.logic.event.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

public final class ShowPrompt extends AbstractEvent {

    public Object execute(Object param) throws Exception {
        PromptFn.printPrompt((Console) param);
        return null;
    }
}
