package net.sourceforge.pain.tinylib.logic.event.console.command.builder;

import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.util.*;

import java.util.*;

/**
 * PAiN  Date: 05.06.2003  Time: 1:40:02
 */
public final class BC_Roles extends BuilderCommand {

    public void processBuilderCommand(BuilderShell p, String args) throws Exception {
        Prototype role = p.builder.getEditedRole();
        if (role == null) {
            MessageOutFn.outln(p.console, "No active role found!");
        } else {
            MessageOutFn.outln(p.console, "{wEdited prototype Roles:{x");
            for (Iterator it = role.rolesIterator(); it.hasNext();) {
                Prototype proto = (Prototype) it.next();
                MessageOutFn.outln(p.console, "{c" + ClassUtils.classNameWithoutPackage(proto.getClass()) + "{W:{x " + proto.toString());
            }
        }
    }

    public void showHelp(Console console) {
        MessageOutFn.outln(console, "Builder command ROLES shows all roles of the current prototype");
        MessageOutFn.outln(console, "Usage: roles");
    }

}



