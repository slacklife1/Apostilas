package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;
import net.sourceforge.pain.tinylib.plugin.command.*;

import java.util.*;

public final class ShowGrants extends GrantedCommand {

    public void processCommand() {
        String playerName = commandParams;
        if (playerName == null) {
            showHelp();
            return;
        }
        final Player target = ("self".equals(playerName)) ? player : GlobalFindFn.findPlayerByName(playerName);
        if (target == null) {
            MessageOutFn.outln(console, "No player found with name {c" + Utils.formatName(playerName) + "{x");
            return;
        }
        boolean granted = isShowGrants();
        final Set commandsSet = granted ? target.getGrantedCommands() : target.getRejectedCommands();
        MessageOutFn.outln(console, (granted ? "Granted" : "Rejected") + " commands for " + target.getInteractiveName());
        if (commandsSet.isEmpty()) {
            MessageOutFn.outln(console, "Not found.");
        } else if (commandsSet.contains("_all")) {
            // only implementor has grant "_all".
            // Using this constant we simplify initial world creation script.
            MessageOutFn.outln(console, "All available commands allowed!");
        } else {
            CommandMapper commandMapper = ConsoleInputEvent.getCommandMapper();
            StringBuffer b = new StringBuffer(100);
            for (Iterator it = commandsSet.iterator(); it.hasNext();) {
                b.delete(0, b.length());
                String commandClass = (String) it.next();
                Set commands = commandMapper.getAllCommandsForClassName(commandClass);
                if (commands == null || commands.isEmpty()) {
                    b.append("No command names mapped");
                } else {
                    for (Iterator it2 = commands.iterator(); it2.hasNext();) {
                        String commandName = (String) it2.next();
                        if (b.length() > 0) {
                            b.append(", ");
                        }
                        b.append("{c").append(commandName).append("{x");
                    }
                }
                MessageOutFn.outln(console, "Class: {c" + commandClass + "{x Commands:" + b);
            }
            final int n = commandsSet.size();
            MessageOutFn.outln(console, "Found: " + n + " unique " + LangUtil.s(n, "command") + " in list");
        }

    }

    public void showHelp() {
        if (isShowGrants()) {
            MessageOutFn.outln(console, command.name + ": shows granted commands to player");
            MessageOutFn.outln(console, "Usage: " + command.name + " <player_name> ");
        } else { // REJECTS
            MessageOutFn.outln(console, command.name + ": shows rejected to player commands");
            MessageOutFn.outln(console, "Usage: " + command.name + " <player_name> ");

        }
    }

    private boolean isShowGrants() {
        return "GRANTS".equals(command.tag);
    }
}
