package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

public final class Tell extends CommandHandler {

    public void processCommand() throws Exception {
        String text = commandParams == null ? "" : commandParams.trim();
        int spaceIndex = text.indexOf(' ');
        if (spaceIndex < 1) {
            MessageOutFn.outln(console, "Tell whom what?");
            return;
        }
        String namePrefix = text.substring(0, spaceIndex);
        text = text.substring(spaceIndex).trim();
        if (text.length() == 0) {
            MessageOutFn.out(console, "Tell what?");
            return;
        }
        Interactive target = GlobalFindFn.findInteractiveByPrefix(player, namePrefix);
        if (target == null) {
            MessageOutFn.outln(console, "They aren't here.");
            return;
        }
        TellFn.doTell(player.asInteractive(), target, text);
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ":sends a message to one awake player anywhere in the world.");
    }
}
