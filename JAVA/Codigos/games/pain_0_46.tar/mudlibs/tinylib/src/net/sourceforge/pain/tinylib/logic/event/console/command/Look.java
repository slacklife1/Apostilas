package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;


public final class Look extends CommandHandler {

    public boolean isAccessible() {
        return super.isAccessible() && player.asReceptive().canSee();
    }

    public void processNotAccessible() {
        MessageOutFn.outln(console, "You can't see anything!");
    }

    public void processCommand() throws Exception {
        Receptive receptive = player.asReceptive();
        String targetName = commandParams;
        if ("INVENTORY".equals(command.tag)) {
            lookInventory();
        } else if (targetName == null) {
            lookSpace();
        } else {
            targetName = targetName.trim().toLowerCase();
            if (targetName.length() > 3 && (targetName.startsWith("on ") || targetName.startsWith("at "))) {
                targetName = targetName.substring(3).trim();
            }
            Interactive actor = player.asInteractive();
            Interactive victim = SpaceFindFn.findByPrefix(actor.asLocated(), targetName);
            if (victim == null) {
                Room lsp = (Room) player.getLocation().getRole(Room.class);
                int exitDir;
                if (lsp != null && (exitDir = Utils.exitNameToDir(targetName)) >= 0) {
                    Exit ex = lsp.getExit(exitDir);
                    if (ex == null || ex.getExitDesc() == null) {
                        MessageOutFn.outln(console, "Nothing special there.");
                    } else {
                        MessageOutFn.outln(console, ex.getExitDesc());
                    }
                } else {
                    MessageOutFn.outln(console, "You don't see that here.");
                }
            } else {
                if (victim == actor) {
                    MessageOutFn.outSpace(actor, "$n looks at $mself.", actor, actor);
                } else {
                    MessageOutFn.outOne(victim, "$n looks at you.", actor, null);
                    MessageOutFn.outSpaceNoVictim(actor, victim, "$n looks at $N.", actor, victim);
                }
                ShowFn.showObject(receptive, victim);
            }
        }
    }

    private void lookInventory() {
        Creature c = (Creature) player.getRole(Creature.class);
        if (c == null) {
            ConsoleInputEvent.processFailedCommand(console);
            return;
        }
        ShowFn.showSpace(player.asReceptive(), c.getInventory());
    }

    private void lookSpace() {
        ShowFn.showSpace(player.asReceptive(), player.getLocation());
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ":shows description of the place and interactive objects in it");
    }
}
