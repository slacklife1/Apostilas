package net.sourceforge.pain.tinylib.logic.fn;

/**
 * Thrown if some logical errors occurs (moving to illegal location...)
 */
public class LogicException extends RuntimeException {
    public final int errorCode;

    public LogicException(int errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }
}
