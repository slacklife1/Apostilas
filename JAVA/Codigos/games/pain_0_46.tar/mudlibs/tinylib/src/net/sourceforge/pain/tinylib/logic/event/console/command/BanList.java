package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

import java.text.*;
import java.util.*;

public final class BanList extends GrantedCommand {
    private static final SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yy HH:mm");

    public void processCommand() throws Exception {
        Map bans = Mudlib.getWorld().getSiteBans();
        MessageOutFn.outln(console, "IP \t HOST \t TYPE \t ADMIN \t PULSE");
        if (bans.isEmpty()) {
            MessageOutFn.outln(console, "No bans found");
            return;
        }
        for (Iterator it = bans.values().iterator(); it.hasNext();) {
            SiteBan ban = (SiteBan) it.next();
            MessageOutFn.outln(console, ban.getSiteIP() + "\t" + ban.getSiteHost() + "\t" + (ban.getBanType() == SiteBan.SITE_BAN_ALL ? " all " : " newbies ") + "\t" + ban.getAdminName() + "\t" + formatter.format(new Date(ban.getBanTime())));
        }
        MessageOutFn.outln(console, "TOTAL: " + bans.size() + " bans");
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ":  print list of banned sites");
        MessageOutFn.outln(console, "where <ban_type> = {'off', 'newbies', 'all'}");
    }

}
