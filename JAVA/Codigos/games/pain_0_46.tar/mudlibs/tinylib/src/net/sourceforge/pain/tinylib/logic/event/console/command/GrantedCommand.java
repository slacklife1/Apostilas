package net.sourceforge.pain.tinylib.logic.event.console.command;



import net.sourceforge.pain.tinylib.logic.event.console.*;

import java.util.*;

public abstract class GrantedCommand extends CommandHandler {

    public boolean isAccessible() {
        if (!super.isAccessible()) {
            return false;
        }
        final Set grantedCommands = player.getGrantedCommands();
        if (grantedCommands.contains("_all")) {// implementor mark
            return true;
        }
        String grantedCommandClass = getClass().getName().substring(ConsoleInputEvent.COMMAND_PACKAGE_PREFIX.length());
        if (grantedCommands.contains(grantedCommandClass)) {
            return true;
        }
        return false;
    }

    /**
     * Empty. subclasses should override this method to make some specific work here
     */
    public void onGrantAdded() throws Exception {

    }

    /**
     * Empty. subclasses should override this method to make some specific work here
     */
    public void onGrantRemoved() throws Exception {
    }
}
