package net.sourceforge.pain.tinylib.logic.fn.util;


import net.sourceforge.pain.tinylib.data.type.*;

import java.util.regex.*;

/**
 * PAiN  Date: 05.06.2003  Time: 1:57:10
 */
public final class Utils {

    private final static String[] spaces = new String[20];
    public static Pattern WHITESPACE_SPLIT_PATTERN = Pattern.compile("[\\s]+");

    static {
        StringBuffer buf = new StringBuffer(spaces.length);
        for (int i = 0; i < spaces.length; i++) {
            buf.append(' ');
            spaces[i] = buf.toString();
        }
    }

    public static String whiteSpaceChars(int n) {
        if (n < 10) {
            return spaces[n];
        } else {
            StringBuffer s = new StringBuffer(n);
            while (--n >= 0) {
                s.append(' ');
            }
            return s.toString();
        }
    }

    public static int numStrLen(int num) {
        int strLen = num < 0 ? 2 : 1;
        while (Math.abs(num) > 9) {
            strLen++;
            num = num / 10;
        }
        return strLen;
    }


    public static String formatName(String name) {
        return Character.toUpperCase(name.charAt(0)) + name.substring(1);
    }

    public static int exitCharToDir(final char direction) throws IllegalArgumentException {
        int dir;
        switch (direction) {
            case 'n':
            case 'N':
                dir = Room.DIR_NORTH;
                break;
            case 'e':
            case 'E':
                dir = Room.DIR_EAST;
                break;
            case 's':
            case 'S':
                dir = Room.DIR_SOUTH;
                break;
            case 'w':
            case 'W':
                dir = Room.DIR_WEST;
                break;
            case 'u':
            case 'U':
                dir = Room.DIR_UP;
                break;
            case 'd':
            case 'D':
                dir = Room.DIR_DOWN;
                break;
            default:
                throw new IllegalArgumentException("Illegal Direction:" + direction);
        }
        return dir;
    }

    /**
     * @param exitName - lowercase value
     * @return direction or -1 if fails
     */
    public static int exitNameToDir(final String exitName) {
        if (exitName != null) {
            String[] exitNames = LangUtil.exitName;
            int len = exitNames.length;
            for (int i = 0; i < len; i++) {
                if (exitNames[i].startsWith(exitName)) {
                    return i;
                }
            }
        }
        return -1;
    }


    /**
     * starts check starting from target.length() character
     *
     * @param prefix is prefix for both name and thenName.
     * @return IF name IS CLOSER TO target THAN thanName
     */
    public static boolean isCloserTo(String prefix, String name, String thenName) {
        int lenDif = name.length() - thenName.length();
        if (lenDif < 0) {
            return true; // name is shorter
        }
        if (lenDif > 0) {
            return false; // thenName is shorter
        }
        int len = name.length();
        for (int i = prefix.length(); i < len; i++) {
            char nc = name.charAt(i);
            char tnc = thenName.charAt(i);
            if (nc != tnc) {
                return nc < tnc;
            }
        }
        return true;
    }

    public static String formatTopArrayItems(int max, int[] arr, String sep) {
        StringBuffer buf = new StringBuffer();
        int n = Math.min(max, arr.length);
        for (int i = 0; i < n; i++) {
            if (i > 0) {
                buf.append(sep);
            }
            buf.append(arr[i]);
        }
        return buf.toString();
    }

    public static String formatTopArrayItems(int max, String[] sarr, String sep) {
        StringBuffer buf = new StringBuffer();
        int n = Math.min(max, sarr.length);
        for (int i = 0; i < n; i++) {
            if (i > 0) {
                buf.append(sep);
            }
            buf.append(sarr[i]);
        }
        return buf.toString();
    }
}
