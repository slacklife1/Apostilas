package net.sourceforge.pain.tinylib.logic.event.console.command.builder;

import net.sourceforge.pain.data.*;
import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

import java.util.*;

/**
 * PAiN  Date: 05.06.2003  Time: 1:40:02
 */
public final class BC_Reset extends BuilderCommand {

    public void processBuilderCommand(BuilderShell p, String args) throws Exception {
        Prototype role = p.builder.getEditedRole();
        PrototypeInfo resettedPrototype;
        if (role == null || (resettedPrototype = (PrototypeInfo) role.getRole(PrototypeInfo.class)) == null) {
            MessageOutFn.outln(p.console, "No active prototype found!");
            return;
        }

        if (args == null || args.length() < 3) {
            showHelp(p.console);
            return;
        }
        String result[] = new String[2];
        ConsoleInputEvent.parseCommand(args, result);
        String uniqueSpaceId = result[0];
        String areaName = result[1];
        if (areaName == null) {
            showHelp(p.console);
            return;
        }
        Room is = (Room) Mudlib.getWorld().getRoomsByIdMap().get(uniqueSpaceId);
        if (is == null) {
            MessageOutFn.outln(p.console, "Room not found: '" + uniqueSpaceId + "'");
            return;
        }
        Space space = is.asSpace();
        Map world_areasByName = Mudlib.getWorld().getAreasByName();
        Area area = (Area) world_areasByName.get(areaName);
        if (area == null) {
            MessageOutFn.outln(p.console, "Area not found: '" + areaName + "'");
            BuilderShell.showAreasList(p);
            return;
        }
        SpaceReset spaceReset = (SpaceReset) ObjectFactory.createRaw(SpaceReset.class);
        spaceReset.setResettedPrototype(resettedPrototype);
        RelocateFn.addToSpace(space, (Located) spaceReset.getRole(Located.class));
        area.getResets().add(spaceReset);
        p.builder.setEditedRole(null);
        p.builder.getEditedPrototypesList().remove(resettedPrototype);

        MessageOutFn.outln(p.console, "Prototype :" + resettedPrototype.getName() + " was resetted in " + space.getName());
        MessageOutFn.outln(p.console, "Area used:" + area.getName());

    }


    public void showHelp(Console console) {
        MessageOutFn.outln(console, "Builder command RESET resets the edited prototype.");
        MessageOutFn.outln(console, "Usage: reset <unique_room_id> <area_name>");
    }

}

