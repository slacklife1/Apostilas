package net.sourceforge.pain.tinylib.logic.affect;

/**
 * User: fmike  Date: Mar 6, 2004  Time: 2:15:58 AM
 */
public final class AffectType {
    //just example of usage:
    
    public static int AFFECT_IMMORTAL = 1;
    public static int AFFECT_IMMOBILE = 2;
    public static int AFFECT_NOTELL = 3;
    public static int AFFECT_FROZEN_ACCOUNT = 4;

    private static int LAST_AFFECT_INDEX_PLUS_1 = 5;
    private static String[] names = new String[LAST_AFFECT_INDEX_PLUS_1];

    static {
        names[0] = "";
        names[AFFECT_IMMORTAL] = "immortality";
        names[AFFECT_IMMOBILE] = "immobility";
        names[AFFECT_NOTELL] = "notell";
        names[AFFECT_FROZEN_ACCOUNT] = "frozen account";
    }


    public static String getAffectName(int affectType) {
        return names[affectType];
    }

}
