package net.sourceforge.pain.tinylib.logic.event.console;


import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.*;
import net.sourceforge.pain.tinylib.logic.event.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

public final class LoginEvent extends AbstractEvent {

    public Object execute(Object param) throws Exception {
        Console c = (Console) param;
        if (checkBan(c)) {
            return null;
        }
        new LoginShell().run(c);
        return null;
    }

    private boolean checkBan(Console c) {
        SiteBan ban = (SiteBan) Mudlib.getWorld().getSiteBans().get(SiteBan.getSiteBanKey(c.getRemoteAddr(), SiteBan.SITE_BAN_ALL));
        if (ban != null) {
            MessageOutFn.outln(c, "Your site has been banned from this mud.");
            ConsoleFn.forceDisconnect(c);
            return true;
        }
        return false;
    }
}
