package net.sourceforge.pain.tinylib.logic.event.console.command.builder;

import net.sourceforge.pain.*;
import net.sourceforge.pain.data.*;
import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

import java.util.*;

/**
 * PAiN  Date: 05.06.2003  Time: 1:40:02
 */
public final class BC_Del extends BuilderCommand {

    public void processBuilderCommand(BuilderShell p, String args) throws Exception {
        if (args == null) {
            showUsage(p.console);
            return;
        }
        Prototype r = p.builder.getEditedRole();
        if (r == null) {
            MessageOutFn.outln(p.console, "No active prototype found");
            return;
        }
        PrototypeInfo pi = (PrototypeInfo) r.getRole(PrototypeInfo.class);
        if (!args.equals(pi.getVnum())) {
            MessageOutFn.outln(p.console, "Invalid vnum specified: '" + args + "'");
            MessageOutFn.outln(p.console, "Active prototype vnum: '" + pi.getVnum() + "' name:" + pi.getName());
            return;
        }
        // ok removal:
        Map areas = Mudlib.getWorld().getAreasByName();
        int totalRemoved = 0;
        for (Iterator areasIt = areas.values().iterator(); areasIt.hasNext();) {
            Area area = (Area) areasIt.next();
            final Set resets = area.getResets();
            for (Iterator resetsIt = resets.iterator(); resetsIt.hasNext();) {
                SpaceReset reset = (SpaceReset) resetsIt.next();
                if (reset.getResettedPrototype() == pi) {
                    SpaceReset sr = (SpaceReset) reset.getRole(SpaceReset.class);
                    if (sr != null) {
                        MessageOutFn.outln(p.console, "Removing reset from area:" + area.getName() + " space:" + sr.getLocation().getName());
                    } else {
                        MessageOutFn.outln(p.console, "Removing reset from area:" + area.getName());
                    }
                    totalRemoved++;
                    resetsIt.remove();
                    ObjectFactory.destroyObject(reset);
                }
            }
        }
        String name = pi.getName();
        String vnum = pi.getVnum();
        removeFromBuilderLists(pi);
        ObjectFactory.destroyObject(pi);
        MessageOutFn.outln(p.console, "Total resets removed: " + totalRemoved);
        MessageOutFn.outln(p.console, "Prototype: " + vnum + "/" + name + " removed");
    }

    private void removeFromBuilderLists(PrototypeInfo pi) {
        for (Iterator it = Codebase.getDB().getDbClass(Builder.class).extentIterator(false); it.hasNext();) {
            Builder b = (Builder) it.next();
            b.getEditedPrototypesList().remove(pi);
        }
        return;
    }

    public void showUsage(Console console) {
        MessageOutFn.outln(console, "DEL:Command syntax <VNUM>\n");
    }

    public void showHelp(Console console) {
        MessageOutFn.outln(console, "Builder command DEL removes  the prototype and all it's resets");
        MessageOutFn.outln(console, "To avoid accidental prototype removal this command removes only");
        MessageOutFn.outln(console, "active prototype (command 'USE' makes prototype active and VNUM used as confirmation");
        MessageOutFn.outln(console, "Usage: del <VNUM>");
    }

}
