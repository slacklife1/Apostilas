package net.sourceforge.pain.tinylib.logic.trigger;

/**
 * User: fmike  Date: Nov 26, 2003   Time: 3:22:59 AM
 */
public interface TriggerType {

    public static final int TRIGGER_CONSOLE_INPUT = 1;
    public static final int TRIGGER_BEFORE_MOVED_OUT = 2;
    public static final int TRIGGER_AFTER_MOVED_IN = 3;

}
