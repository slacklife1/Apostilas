package net.sourceforge.pain.tinylib.logic.event.guitool.event;

import net.sourceforge.pain.*;
import net.sourceforge.pain.tinylib.logic.event.guitool.*;

public class ReloadLogicGTEvent extends GuiEventHandler {

    public void processEvent() {
        String[] data = (String[]) packet.data;
        if ("reload".equals(data[0])) {
            Codebase.getLogicLoader().reload();
            send("ok");
        } else {
            send("Wrong action");
        }

    }
}
