package net.sourceforge.pain.tinylib.logic.fn;

import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.affect.*;

/**
 * User: fmike  Date: May 8, 2004  Time: 1:03:26 AM
 */
public class TellFn {

    public static final void doTell(Interactive src, Interactive victim, String message) {
        if (src.isAffected(AffectType.AFFECT_NOTELL)) {
            MessageOutFn.outln(src, "Your message didn't get through.");
            return;
        }
        if (src == victim) {
            MessageOutFn.outln(src, "Talking to yourself, eh?");
            return;
        }
        MessageOutFn.outOne(src, "You tell $N '{w$t{x'", message, victim);
        MessageOutFn.outOne(victim, "$n tells you '{w$T{x'", src, message);
    }
}
