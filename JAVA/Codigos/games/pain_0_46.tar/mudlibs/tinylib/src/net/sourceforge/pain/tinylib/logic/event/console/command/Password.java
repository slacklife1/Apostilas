package net.sourceforge.pain.tinylib.logic.event.console.command;


import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.util.*;

public final class Password extends CommandHandler {
    public static final int STATE_INITIAL = 0;
    public static final int STATE_OLD_ASKED = 1;
    public static final int STATE_NEW_ASKED = 2;
    public static final int STATE_NEW_CONFIRM_ASKED = 3;

    private int state = STATE_INITIAL;
    private String newPass;

    public void processCommand() throws Exception {
        switch (state) {
            case STATE_INITIAL:
                askOld();
                console.setRawMode(this);
                break;
            case STATE_OLD_ASKED:
                askNew(console.popInputLine());
                break;
            case STATE_NEW_ASKED:
                askNewConfirm(console.popInputLine());
                break;
            case STATE_NEW_CONFIRM_ASKED:
                processConfirm(console.popInputLine());
                break;
            default:
                Log.debug("Password:BUG!!");
                console.setCommandMode();
        }
    }


    private void askOld() {
        MessageOutFn.out(console, "Enter your OLD password(ENTER to cancel):");
        state = STATE_OLD_ASKED;
    }

    private void askNew(String input) {
        if (input == null || input.trim().length() == 0) {
            console.setCommandMode();
            return;
        }
        if (!input.equals(player.getPassword())) {
            console.setCommandMode();
            MessageOutFn.outln(console, "{RInvalid password{x");
            return;
        }
        MessageOutFn.out(console, "Enter your NEW password(ENTER to cancel):");
        state = STATE_NEW_ASKED;
    }

    private void askNewConfirm(String input) {
        if (input == null || input.trim().length() == 0) {
            console.setCommandMode();
            return;
        }
        newPass = input;
        MessageOutFn.out(console, "Repeat your new password(ENTER to cancel):");
        state = STATE_NEW_CONFIRM_ASKED;
    }

    private void processConfirm(String input) {
        if (input == null || input.trim().length() == 0) {
            console.setCommandMode();
            return;
        }
        if (!newPass.equals(input)) {
            MessageOutFn.outln(console, "{wPasswords mismatch{x");
            askNew(player.getPassword());
            return;
        }

        player.setPassword(newPass);
        MessageOutFn.outln(console, "\n{WYour password has been changed to {Y'" + newPass + "'{W!{x");
        console.setCommandMode();
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": changes password.");
    }
}
