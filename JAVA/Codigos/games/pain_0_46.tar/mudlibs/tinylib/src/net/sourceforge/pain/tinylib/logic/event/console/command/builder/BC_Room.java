package net.sourceforge.pain.tinylib.logic.event.console.command.builder;

import net.sourceforge.pain.data.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

import java.util.*;

/**
 * PAiN  Date: 05.06.2003  Time: 1:40:02
 */
public final class BC_Room extends BuilderCommand {

    private Room room;
    private int state = STATE_INITIAL;

    private static final int STATE_INITIAL = 0;
    private static final int STATE_ASK_CREATE_NEW = 1;
    private static final int STATE_ENTER_NAME = 2;
    private static final int STATE_ENTER_DESC = 3;
    private static final int STATE_ENTER_CAPACITY = 4;
    private static final int STATE_CHOOSE_AREA = 5;

    private String room_id;
    private String newName;
    private String newDesc;
    private int newCapcacity;
    private Area newArea;


    public void processBuilderCommand(BuilderShell p, String args) throws Exception {
        if (state > STATE_INITIAL) {
            processReply(p, args);
        } else if (args == null || args.length() == 0) {
            showUsage(p.console);
        } else {
            String id = args;
            Map reg = Mudlib.getWorld().getRoomsByIdMap();
            room = (Room) reg.get(id);

            p.activeCommand = this;
            room_id = id;
            if (room == null) {
                askToCreateNew(p);
            } else {
                MessageOutFn.outln(p.console, "Room found!");
                MessageOutFn.outln(p.console, "{W" + room.getName() + "{x");
                MessageOutFn.outln(p.console, room.getDesc());
                MessageOutFn.outln(p.console, "Capaciy :" + room.getCapacity());
                askName(p);
            }
        }
    }

    private void processReply(BuilderShell p, String reply) throws Exception {
        switch (state) {
            case STATE_ASK_CREATE_NEW:
                if ("Y".equalsIgnoreCase(reply.substring(0, 1))) {
                    askName(p);
                } else {
                    cancelCommand(p);
                }
                break;
            case STATE_ENTER_NAME:
                reply = reply.trim();
                if (reply.length() == 0) {
                    if (room == null) {
                        MessageOutFn.outln(p.console, "Name is too short!");
                        askName(p);
                    } else {
                        newName = room.getName();
                        MessageOutFn.outln(p.console, "Reusing old name:" + newName);
                        askRoomDesc(p);
                    }
                } else if (reply.equalsIgnoreCase("x")) {
                    cancelCommand(p);
                } else if (reply.length() == 1) {
                    MessageOutFn.outln(p.console, "Name is too short!");
                    askName(p);
                } else {
                    newName = reply;
                    askRoomDesc(p);
                }
                break;
            case STATE_ENTER_DESC:
                reply = reply.trim();
                if (reply.length() == 0) {
                    if (room == null) {
                        MessageOutFn.outln(p.console, "Description is too short!");
                        askRoomDesc(p);
                    } else {
                        newDesc = room.getDesc();
                        MessageOutFn.outln(p.console, "Reusing old desc.");
                        askRoomCapacity(p);
                    }
                } else if (reply.equalsIgnoreCase("x")) {
                    cancelCommand(p);
                } else if (reply.length() < 10) {
                    MessageOutFn.outln(p.console, "Description is too short!");
                    askRoomDesc(p);
                } else {
                    newDesc = reply;
                    askRoomCapacity(p);
                }
                break;
            case STATE_ENTER_CAPACITY:
                reply = reply.trim();
                if (reply.length() == 0) {
                    if (room == null) {
                        askRoomCapacity(p);
                    } else {
                        newCapcacity = room.getCapacity();
                        MessageOutFn.outln(p.console, "Reusing old capacity.");
                        askArea(p);
                    }
                } else if (reply.equalsIgnoreCase("x")) {
                    cancelCommand(p);
                } else {
                    try {
                        newCapcacity = Integer.parseInt(reply);
                        if (newCapcacity < 0) {
                            throw new IllegalArgumentException("specified capacity < 0 :" + newCapcacity);
                        }
                    } catch (Exception e) {
                        MessageOutFn.outln(p.console, e);
                        newCapcacity = 0;
                        askRoomCapacity(p);
                    }
                    if (newCapcacity > 0) {
                        askArea(p);
                    }
                }
                break;
            case STATE_CHOOSE_AREA:
                if (reply.length() == 0) {
                    if (room == null) {
                        askArea(p);
                    } else {
                        newArea = room.getArea();
                        MessageOutFn.outln(p.console, "Reusing old area: " + newArea.getName());
                        finish(p);
                    }
                } else if (reply.equalsIgnoreCase("x")) {
                    cancelCommand(p);
                } else if (reply.equalsIgnoreCase("l")) {
                    BuilderShell.showAreasList(p);
                } else {
                    newArea = (Area) Mudlib.getWorld().getAreasByName().get(reply);
                    if (newArea == null) {
                        MessageOutFn.outln(p.console, "area not found :" + reply);
                        BuilderShell.showAreasList(p);
                    } else {
                        finish(p);
                    }
                }
                break;
        }

    }


    private void finish(BuilderShell p) throws Exception {
        if (room == null) { //new room
            final Map roomsByIdMap = Mudlib.getWorld().getRoomsByIdMap();
            if (roomsByIdMap.containsKey(room_id)) {
                MessageOutFn.outln(p.console, "Room id was asynchronously used by other builder");
                cancelCommand(p);
                return;
            }
            room = (Room) ObjectFactory.createRaw(Room.class);
            fillCachedFields();
            room.setRoomUniqueId(room_id);
            roomsByIdMap.put(room_id, room);
        } else {
            fillCachedFields();
        }
        MessageOutFn.outln(p.console, "Done. Use 'goto' command to relocate to new room ('goto " + room_id + "')");
        p.activeCommand = null;
    }

    private void fillCachedFields() {
        Space space = room.asSpace();
        space.setName(newName);
        space.setDesc(newDesc);
        space.setCapacity(newCapcacity);

        final Area oldArea = room.getArea();
        if (oldArea != newArea) {
            if (oldArea != null) {
                oldArea.getRooms().remove(space);
            }
            newArea.getRooms().add(space);
            room.setArea(newArea);
        }

    }

    private void cancelCommand(BuilderShell p) {
        p.activeCommand = null;
    }

    private void askName(BuilderShell p) {
        MessageOutFn.out(p.console, "Enter new space name (" + (room == null ? "" : "ENTER - leave old, ") + "'X' to stop command) :");
        state = STATE_ENTER_NAME;
    }

    private void askRoomDesc(BuilderShell p) {
        MessageOutFn.out(p.console, "Enter new space desc (" + (room == null ? "" : "ENTER - leave old, ") + "'X' to stop command) :");
        state = STATE_ENTER_DESC;
    }

    private void askRoomCapacity(BuilderShell p) {
        MessageOutFn.out(p.console, "Enter new space capacity (" + (room == null ? "" : "ENTER - leave old, ") + "'X' to stop command) :");
        state = STATE_ENTER_CAPACITY;
    }

    private void askArea(BuilderShell p) {
        MessageOutFn.out(p.console, "Enter area name (" + (room == null ? "" : "ENTER - leave old, ") + "'X' to stop command, 'L'-show areas list) :");
        state = STATE_CHOOSE_AREA;
    }

    private void askToCreateNew(BuilderShell p) {
        MessageOutFn.outln(p.console, "Space not found:" + room_id);
        MessageOutFn.out(p.console, "Would you like to create new? (Y/N):");
        state = STATE_ASK_CREATE_NEW;

    }


    public void showUsage(Console console) {
        MessageOutFn.outln(console, "Space:Command syntax <ROOM_ID>\n");
    }

    public void showHelp(Console console) {
        MessageOutFn.outln(console, "Builder command ROOM is used to create or modify rooms");
        MessageOutFn.outln(console, "Usage: room <ROOM_ID>");
    }

    public String getName() {
        return "Room";
    }
}
