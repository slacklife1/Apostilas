package net.sourceforge.pain.tinylib.data.prototype;


import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.db.*;
import net.sourceforge.pain.tinylib.data.type.*;


/**
 * this types defines all information that enough to interpret the object as physical matter
 * if object is easier it's weight = 0
 */
public final class PhysicalPrototype extends Prototype {


    /**
     * Size of the object
     */
    private static final int SIZE = 1 + LAST_BASE_FIELD_INDEX;

    /**
     * Weight of the object
     */
    private static final int WEIGHT = 2 + LAST_BASE_FIELD_INDEX;

    /**
     * We can observe any physical object
     */
    private static final int APPEARANCE_DESC = 3 + LAST_BASE_FIELD_INDEX;

    private static final int NFIELDS = 4 + LAST_BASE_FIELD_INDEX;

    private final static Class superroles[] = new Class[]{InteractivePrototype.class};

    public PhysicalPrototype(PainDB db) {
        super(db);
    }

    public PhysicalPrototype() {
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        fillSuperSchema(types, names);

        types[SIZE] = DbType.INT;
        names[SIZE] = "size";

        types[WEIGHT] = DbType.INT;
        names[WEIGHT] = "weight";

        types[APPEARANCE_DESC] = DbType.STRING;
        names[APPEARANCE_DESC] = "appearance";

        return new DbClassSchema(types, names);
    }

    public void setSize(int value) {
        setInt(SIZE, value);
    }

    public void setWeight(int value) {
        setInt(WEIGHT, value);
    }

    public void setAppearanceDesc(String value) {
        setString(APPEARANCE_DESC, value);
    }

    public int getSize() {
        return getInt(SIZE);
    }

    public int getWeight() {
        return getInt(WEIGHT);
    }

    public String getAppearanceDesc() {
        return getString(APPEARANCE_DESC);
    }

    public Class[] getSuperroles() {
        return superroles;
    }


    public Class getPrototypedRoleClass() {
        return Physical.class;
    }

    public InteractivePrototype asInteractivePrototype() {
        return (InteractivePrototype) getRole(InteractivePrototype.class);
    }

    public String toString() {
        return "size=" + getSize() + " weight=" + getWeight() + " appearanceDesc=" + getAppearanceDesc();
    }
}
