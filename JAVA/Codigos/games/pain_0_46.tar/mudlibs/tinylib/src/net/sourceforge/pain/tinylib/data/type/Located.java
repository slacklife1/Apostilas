package net.sourceforge.pain.tinylib.data.type;


import net.sourceforge.pain.data.*;
import net.sourceforge.pain.db.*;


/**
 * Object with <code>Located</code> role is located somewhere in <code>Space</code>.<br>
 * It's locations specified by <code>space</code> field and should never be <code>null</code><br>
 * <code>next_in_space</code> - next located object in space, <code>null</code> if last<br>
 * <code>prev_in_space</code> - previous located object in space, never <code>null</code> (circular)
 */
public final class Located extends Role {

    private static final int SPACE = 1 + LAST_BASE_FIELD_INDEX;
    private static final int NEXT_IN_SPACE = 2 + LAST_BASE_FIELD_INDEX; //backward iteration has null -> last element
    private static final int PREV_IN_SPACE = 3 + LAST_BASE_FIELD_INDEX; //backward iteration has no nulls (easy to get last in space (first->prev))
    private static final int NFIELDS = 4 + LAST_BASE_FIELD_INDEX;

    public Located(PainDB db) {
        super(db);
    }

    public Located() {
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        fillSuperSchema(types, names);

        types[SPACE] = DbType.REFERENCE;
        names[SPACE] = "space";

        types[NEXT_IN_SPACE] = DbType.REFERENCE;
        names[NEXT_IN_SPACE] = "next_in_space";

        types[PREV_IN_SPACE] = DbType.REFERENCE;
        names[PREV_IN_SPACE] = "prev_in_space";

        return new DbClassSchema(types, names);
    }


    public Space getLocation() {
        return (Space) getReference(SPACE);
    }

    /**
     * Tinylib:only RelocateFn is allowed to use this method
     */
    public void managed_setLocation(Space space) {
        setReference(SPACE, space);
    }

    public Located getNextInSpace() {
        return (Located) getReference(NEXT_IN_SPACE);
    }

    public Located getPrevInSpace() {
        return (Located) getReference(PREV_IN_SPACE);
    }

    public void setNextInSpace(Located l) {
        setReference(NEXT_IN_SPACE, l);
    }

    public void setPrevInSpace(Located l) {
        setReference(PREV_IN_SPACE, l);
    }
}
