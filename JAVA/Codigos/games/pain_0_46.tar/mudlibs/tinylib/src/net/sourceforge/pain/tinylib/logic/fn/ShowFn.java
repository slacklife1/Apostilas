package net.sourceforge.pain.tinylib.logic.fn;

import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;
import net.sourceforge.pain.data.*;

/**
 * PAiN  Date: 04.06.2003  Time: 1:17:35
 */
public final class ShowFn {

    public static void showSpace(Receptive receptive, Space space) {
        if (!receptive.canSee()) {
            MessageOutFn.outln(receptive, "You can't see anything!");
            return;
        }
        Located looker = (Located) receptive.getRole(Located.class);
        MessageOutFn.outln(receptive, "{W" + space.getName() + "{x", Receptive.SEE);
        final String desc = space.getDesc();
        if (desc != null) {
            MessageOutFn.outln(receptive, desc, Receptive.SEE);
        }

        for (Located obj = space.getFirstInSpace(); obj != null; obj = obj.getNextInSpace()) {
            Interactive i = (Interactive) obj.getRole(Interactive.class);
            if (i != null && obj != looker) {
                MessageOutFn.outln(receptive, "  " + i.getDesc(), Receptive.SEE);
            }
        }
    }

    public static void showObject(Receptive receptive, Interactive victim) {
        final Console console = ConsoleFn.getConsole(receptive);
        if (!receptive.canSee()) {
            MessageOutFn.outln(console, "You can't see anything!");
            return;
        }
        Physical p = (Physical) victim.getRole(Physical.class);
        String appearanceDesc = p == null ? null : p.getAppearanceDesc();
        if (appearanceDesc == null) {
            MessageOutFn.outln(console, victim.getDesc());
        } else {
            MessageOutFn.outln(console, appearanceDesc);
        }
        Creature creature = (Creature) victim.getRole(Creature.class);
        if (creature != null) {
            Race r = creature.getRace();
            MessageOutFn.outln(console, LangUtil.He(creature.getSex()) + " is " + r.getName().toLowerCase());
        }
    }

    
}
