package net.sourceforge.pain.tinylib.logic.fn;

import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.util.*;


/**
 * PAiN  Date: 14.04.2003  Time: 0:50:45
 */
public final class RelocateFn {

    public static void relocate(Located obj, Space dst) {
        checkCanRelocate(obj, dst);
        removeFromSpace(obj);		// removing obj from src space
        _addToSpace(dst, obj);		// adding obj to dst space
    }

    public static void removeFromSpace(Located obj) {
        final Space space = obj.getLocation();
        final Located prev = obj.getPrevInSpace();
        final Located next = obj.getNextInSpace();
        if (prev != obj) { // backward iteration has no nulls! see Located.java
            final Located firstInSpace = space.getFirstInSpace();
            if (next != null) {
                next.setPrevInSpace(prev);
            } else { // obj is last, and obj was prev for first
                firstInSpace.setPrevInSpace(prev);
            }
            if (obj != firstInSpace) { //last in list should have next = null
                prev.setNextInSpace(next);
            } else {
                space.setFirstInSpace(next);
            }

        } else { // there only one obj in space
            space.setFirstInSpace(null);
        }
        obj.managed_setLocation(null);
        obj.setNextInSpace(null);
        obj.setPrevInSpace(null);
    }

    /**
     * used for new created objects
     */
    public static void addToSpace(Space space, Located obj) {
        checkCanRelocate(obj, space);
        _addToSpace(space, obj);
    }

    private static void _addToSpace(Space space, Located obj) {
        Located first = space.getFirstInSpace();
        if (first != null) {
            final Located prev = first.getPrevInSpace(); // last in list
            prev.setNextInSpace(obj);
            obj.setPrevInSpace(prev);
        } else {
            space.setFirstInSpace(obj);
            first = obj;
        }
        first.setPrevInSpace(obj);  //backward list should be without nulls!
        obj.setNextInSpace(null); // forward list finished on null!
        obj.managed_setLocation(space);
    }


    public static void checkCanRelocate(Located located, Space dstLocation) {
        Physical ph = (Physical) located.getRole(Physical.class);
        if (ph != null) {
            final int leftCapacityInSpace = getLeftCapacityInSpace(dstLocation);
            final int size = ph.getSize();
//            Log.debug("Left:" + leftCapacityInSpace + " size=" + size);
            if (size > leftCapacityInSpace) {
                throw new LogicException(RelocationErrors.ERR_NOT_ENOUGH_TARGET_SPACE, "Not enough space");
            }
        }
    }

    private static int getLeftCapacityInSpace(Space dstLocation) {
        int capacity = dstLocation.getCapacity();
        int usedCapacity = 0;
        for (Located l = dstLocation.getFirstInSpace(); l != null; l = l.getNextInSpace()) {
            Physical p = (Physical) l.getRole(Physical.class);
            if (p != null) {
                usedCapacity += p.getSize();
            }
        }
        int leftCapacity = capacity - usedCapacity;
        if (leftCapacity < 0) {
            Log.error("BUG??: RelocateFn: negative capacity:" + dstLocation.getOid());
        }
        return leftCapacity;
    }
}
