package net.sourceforge.pain.tinylib.data.prototype;


import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.db.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.util.*;

public final class InteractivePrototype extends Prototype {

    /**
     * we see interactive object in space via it's  DESC
     */
    private static final int DESC = LAST_BASE_FIELD_INDEX + 1;

    /**
     * We can interact with object via one of it's target names
     */
    public static final int TARGET_LIST = LAST_BASE_FIELD_INDEX + 2;

    /**
     * usage example: 'Interactive_Name' tells you..
     */
    private static final int INTERACTIVE_NAME = 3 + LAST_BASE_FIELD_INDEX;


    private static final int NFIELDS = LAST_BASE_FIELD_INDEX + 4;

    private final static Class superroles[] = new Class[]{LocatedPrototype.class};

    public InteractivePrototype(PainDB db) {
        super(db);
    }

    public InteractivePrototype() {
    }

    public Class[] getSuperroles() {
        return superroles;
    }


    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        fillSuperSchema(types, names);

        types[DESC] = DbType.STRING;
        names[DESC] = "desc";

        types[TARGET_LIST] = DbType.ARRAY_OF_STRING;
        names[TARGET_LIST] = "target_list";

        types[INTERACTIVE_NAME] = DbType.STRING;
        names[INTERACTIVE_NAME] = "interactive_name";

        return new DbClassSchema(types, names);
    }

    public void setDesc(String value) {
        setString(DESC, value);
    }

    public void setTargetList(String[] list) {
        setStringArray(TARGET_LIST, list);
    }


    public String getDesc() {
        return getString(DESC);
    }

    public String[] getTargetList() {
        return getStringArrayForRead(TARGET_LIST);
    }

    public Class getPrototypedRoleClass() {
        return Interactive.class;
    }

    public void setInteractiveName(String value) {
        setString(INTERACTIVE_NAME, value);
    }

    public String getInteractiveName() {
        return getString(INTERACTIVE_NAME);
    }

    public String toString() {
        return "interactive_name=" + getInteractiveName() + " desc=" + getDesc() + " target_list=" + TargetList.string(getTargetList());
    }
}
