package net.sourceforge.pain.tinylib.logic.factory;

import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.data.prototype.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.util.*;

/**
 * User: fmike * Date: Aug 23, 2003  * Time: 2:08:59 AM
 */
public final class LocatedFactory {

    public static void init(LocatedPrototype proto , Located obj) {
        //do nothing
    }

    public static void destroy(Located obj) {
        Space space = obj.getLocation();
        if (space != null) {
            Log.debug("LocatedFactory.destroy");
            RelocateFn.removeFromSpace(obj);
        }
    }

}
