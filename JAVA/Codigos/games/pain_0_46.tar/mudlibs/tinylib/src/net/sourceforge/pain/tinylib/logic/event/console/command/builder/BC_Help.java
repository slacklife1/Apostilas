package net.sourceforge.pain.tinylib.logic.event.console.command.builder;

import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

/**
 * PAiN  Date: 16.06.2003  Time: 2:07:48
 */
public class BC_Help extends BuilderCommand {
    public void processBuilderCommand(BuilderShell p, String args) throws Exception {
        if (args == null || args.length() == 0) {
            showHelp(p.console);
        } else {
            try {
                Class c = Class.forName(BuilderShell.commandNameToClassName(args.trim()));
                BuilderCommand command = (BuilderCommand) c.newInstance();
                command.showHelp(p.console);
            } catch (ClassNotFoundException e) {
                MessageOutFn.outln(p.console, "No help found for: " + args);
            }
        }
    }

    public void showHelp(Console console) {
        MessageOutFn.outln(console, "Builder command HELP shows help topic on specified builder command");
        MessageOutFn.outln(console, "Usage: help <builder_command_name>");
        MessageOutFn.outln(console, "Available builder commands: {cadd, del, exitname, link, list, new,");
        MessageOutFn.outln(console, " remove, reset, resets, roles, room, set, show, spacestat, unlink, use{x");
        MessageOutFn.outln(console, "To stop builder session use '@' command");
    }
}
