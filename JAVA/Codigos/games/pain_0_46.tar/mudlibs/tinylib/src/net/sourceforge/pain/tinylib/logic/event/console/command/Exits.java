package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;
import net.sourceforge.pain.util.*;

public final class Exits extends CommandHandler {

    public void processCommand() throws Exception {
        Space space = player.getLocation();
        Room lspace = (Room) space.getRole(Room.class);
        boolean exitsFound = false;
        MessageOutFn.outln(console, "Obvious exits:");
        if (lspace != null) {// ok we are NOT in space without any exits (backpacks, chests, or in someones stomach :) )
            for (int dir = Room.FIRST_DIR; dir <= Room.LAST_DIR; dir++) {
                Exit e = lspace.getExit(dir);
                if (e == null) {
                    continue;
                }
                Room targetSpace = e.getTargetRoom();
                if (targetSpace == null) { // this is a bug, exits should lead somewhere
                    Log.error("BUG! exit without space:" + space.getName() + " dir:" + LangUtil.directionName(dir));
                    continue;
                }
                exitsFound = true;
                final String dirName = LangUtil.directionName(dir);
                MessageOutFn.outln(console, "{C " + dirName + Utils.whiteSpaceChars(5 - dirName.length()) + "{x - " + targetSpace.asSpace().getName());
            }
        }
        if (!exitsFound) {
            MessageOutFn.outln(console, "None.");
        }


    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": shows available exits");
    }

}
