package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

public final class Quit extends CommandHandler {

    public void processCommand() throws Exception {
        ConsoleFn.logoutUser(console);
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": logouts user");
    }

}
