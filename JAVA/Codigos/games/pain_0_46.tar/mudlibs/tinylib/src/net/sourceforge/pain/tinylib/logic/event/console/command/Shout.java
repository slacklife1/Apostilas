package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

import java.util.*;

public final class Shout extends CommandHandler {

    public void processCommand() throws Exception {
        String text = commandParams;
        if (text == null) {
            MessageOutFn.outln(console, "You're silent");
        } else {
            MessageOutFn.outOne(player, "You shout '{Y$t{x'", text);
            Receptive plr = player.asReceptive();
            Interactive pli = player.asInteractive();
            for (Iterator it = Codebase.getDB().extentIterator(Receptive.class); it.hasNext();) {
                Receptive r = (Receptive) it.next();
                if (r != plr) {
                    MessageOutFn.outOne(r, "$n shouts '{Y$T{x'", pli, text);
                }
            }
        }
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": sends a message to all awake players in the world.");
    }
}

