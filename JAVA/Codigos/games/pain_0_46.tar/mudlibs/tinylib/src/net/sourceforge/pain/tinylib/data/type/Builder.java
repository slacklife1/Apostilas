package net.sourceforge.pain.tinylib.data.type;

import net.sourceforge.pain.data.*;
import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.db.*;

import java.util.*;

/**
 * PAiN  Date: 05.06.2003  Time: 0:48:15
 */
public class Builder extends Role {

    private static final int PROTOTYPES = 1 + LAST_BASE_FIELD_INDEX;
    private static final int EDITED_ROLE = 2 + LAST_BASE_FIELD_INDEX;
    private static final int NFIELDS = 3 + LAST_BASE_FIELD_INDEX;

    private final static Class superroles[] = new Class[]{Player.class};

    public Builder(PainDB db) {
        super(db);
    }

    public Builder() {
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        fillSuperSchema(types, names);

        types[PROTOTYPES] = DbType.ARRAY_LIST;
        names[PROTOTYPES] = "prototypes";

        types[EDITED_ROLE] = DbType.REFERENCE;
        names[EDITED_ROLE] = "edited_role";


        return new DbClassSchema(types, names);
    }

    public List getEditedPrototypesList() {
        return getArrayList(PROTOTYPES);
    }

    public Prototype getEditedRole() {
        return (Prototype) getReference(EDITED_ROLE);
    }

    public void setEditedRole(Prototype prototype) {
        setReference(EDITED_ROLE, prototype);
    }

    public Class[] getSuperroles() {
        return superroles;
    }

}