package net.sourceforge.pain.tinylib.logic.fn;

/**
 * User: fmike  Date: May 31, 2004  Time: 1:46:51 AM
 */
public interface RelocationErrors {
    public static final int ERR_MOVE_NO_EXITS_FOUND = 1;
    public static final int ERR_MOVE_NOT_ENOUGH_MOVE_POINTS = 2;
    public static final int ERR_NOT_ENOUGH_TARGET_SPACE = 3;
}
