package net.sourceforge.pain.tinylib.logic.trigger.impl;

import net.sourceforge.pain.*;
import net.sourceforge.pain.data.*;
import net.sourceforge.pain.logic.*;
import net.sourceforge.pain.tinylib.data.trigger.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.trigger.*;

public final class SnoopTrigger extends ConsoleInputTrigger {
    public SnoopTrigger(TriggerData td) {
        super(td);
    }

    public void onConsoleInput(Player p, String text) {
        Player snooper = ((SnoopTriggerData) td).getSnooperPlayer();
        MessageOutFn.outln(snooper, "{w[SNOOP:" + p.getInteractiveName() + "]:{x" + text);
    }

    public Trigger newInstance(TriggerData td) {
        return new SnoopTrigger(td);
    }

    public static void makeSnooper(Player snooper, Player snooped) throws Exception {
        if (snooped == null) {
            throw new NullPointerException("snooped player is null");
        }
        if (snooper == null) {
            throw new NullPointerException("snooper player is null");
        }
        new SnoopTriggerData(Codebase.getDB(), snooper, snooped, SnoopTrigger.class, TriggerType.TRIGGER_CONSOLE_INPUT);
    }
}
