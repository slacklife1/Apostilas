package net.sourceforge.pain.tinylib.logic.event.guitool.event;

import net.sourceforge.pain.*;
import net.sourceforge.pain.network.guitool.*;
import net.sourceforge.pain.plugin.*;
import net.sourceforge.pain.tinylib.logic.event.guitool.*;

import java.text.*;
import java.util.*;

public class ServerStatus extends GuiEventHandler {
    static final DateFormat dateFormat = SimpleDateFormat.getDateTimeInstance(SimpleDateFormat.MEDIUM, SimpleDateFormat.MEDIUM);

    public void processEvent() {
        Map statusMap = new HashMap();
        statusMap.put("start_time", dateFormat.format(Codebase.serverStartTime));
        StringBuffer sb = new StringBuffer();
        for (Iterator it = Codebase.getPluginManager().getActivePluginsList().iterator(); it.hasNext();) {
            Plugin p = (Plugin) it.next();
            sb.append("<li>").append(p.getPluginName());

        }
        statusMap.put("plugins", sb.toString());
        connection.send(new GTNetPacket("REPLY", statusMap, packet.sequence_id));
    }
}
