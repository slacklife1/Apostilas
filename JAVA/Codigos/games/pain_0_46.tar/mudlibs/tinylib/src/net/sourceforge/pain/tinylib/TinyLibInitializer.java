package net.sourceforge.pain.tinylib;


import net.sourceforge.pain.*;
import net.sourceforge.pain.data.*;
import net.sourceforge.pain.db.*;
import net.sourceforge.pain.tinylib.data.*;
import net.sourceforge.pain.util.*;

import java.io.*;


public class TinyLibInitializer implements MudlibInitializer {
    String configDir;
    File plugins_config;

    public void readSetting(PropertiesReader props) {
        configDir = props.get("tinylib.etc_dir");
        final String plugFile = configDir + "/plugins.cfg";
        plugins_config = new File(plugFile);
        if (!plugins_config.exists() || plugins_config.isDirectory() || !plugins_config.canRead()) {
            throw new RuntimeException("plugins startup file not found:" + plugFile);
        }

    }

    public void init() throws Exception {
        Mudlib.CONFIG_DIR = configDir;
        loadWorld();
        checkSafeShutdown();
        Codebase.getPluginManager().loadPluginsFromFile(plugins_config);
    }


    private static void loadWorld() throws Exception {
        PainDB db = Codebase.getDB();
        CodebaseData data = Codebase.getCodebaseData();
        Log.info("loading World");
        World world = (World) data.getMudLibRoot();
        if (world == null) {
            Log.debug("Non inited database detected!, creating world!");
            world = new World(db);
            data.setMudLibRoot(world);
            Mudlib.setWorld(world);
            Codebase.processEvent("deploy.CreateInitialWorldEvent", null);
            Log.debug("World Created!");
        } else {
            Log.info("World instance found");
            Mudlib.setWorld(world);
        }


        Log.info("flushing all startup fixes");
        db.flush();
        Log.info("Flushed OK!");
    }


    private static void checkSafeShutdown() throws Exception {
        Codebase.processEvent("CheckSafeShutdown", null);
    }
}
