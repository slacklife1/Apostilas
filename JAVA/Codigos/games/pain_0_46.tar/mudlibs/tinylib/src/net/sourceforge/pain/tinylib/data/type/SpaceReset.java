package net.sourceforge.pain.tinylib.data.type;

import net.sourceforge.pain.data.*;
import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.db.*;

/**
 * Reset that is binded with a space
 */

public class SpaceReset extends Role {

    private static final int RESETTED_PROTOTYPE = 1 + LAST_BASE_FIELD_INDEX;
    private static final int LAST_RESETTED_OBJECT = 2 + LAST_BASE_FIELD_INDEX;
    private static final int NFIELDS = 3 + LAST_BASE_FIELD_INDEX;

    private final static Class superroles[] = new Class[]{Located.class};

    public SpaceReset(PainDB db) {
        super(db);
    }

    public SpaceReset() {
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        fillSuperSchema(types, names);

        types[RESETTED_PROTOTYPE] = DbType.REFERENCE;
        names[RESETTED_PROTOTYPE] = "resetted_prototype";

        types[LAST_RESETTED_OBJECT] = DbType.REFERENCE;
        names[LAST_RESETTED_OBJECT] = "last_resetted_object";

        return new DbClassSchema(types, names);
    }


    public Class[] getSuperroles() {
        return superroles;
    }


    public PrototypeInfo getResettedPrototype() {
        return (PrototypeInfo) getReference(RESETTED_PROTOTYPE);
    }

    public void setResettedPrototype(PrototypeInfo p) {
        setReference(RESETTED_PROTOTYPE, p);
    }

    public Role getLastResettedObject() {
        return (Role) getReference(LAST_RESETTED_OBJECT);
    }

    public void setLastResettedObject(Role obj) {
        setReference(LAST_RESETTED_OBJECT, obj);
    }

    public Space getLocation() {
        return ((Located)getRole(Located.class)).getLocation();
    }
}