package net.sourceforge.pain.tinylib.logic.fn;

import net.sourceforge.pain.tinylib.data.type.*;

public class GiveFn {

    public static void give(Creature source, Physical obj, Creature target) {
        RelocateFn.relocate(obj.asLocated(), target.getInventory());

        final Interactive iTarget = target.asInteractive();
        final Interactive iObj = obj.asInteractive();
        final Interactive iEquipped = source.asInteractive();

        MessageOutFn.outln(source, "You give " + iObj.getDesc() + " to " + iTarget.getName() + ".");
        MessageOutFn.outln(target, iEquipped.getName() + " gives you " + iObj.getName() + ".");
        MessageOutFn.outSpaceNoVictim(iEquipped, iTarget, "$n1 gives $n2 to $n3", iEquipped, iObj, iTarget, Receptive.SEE);
    }

}
