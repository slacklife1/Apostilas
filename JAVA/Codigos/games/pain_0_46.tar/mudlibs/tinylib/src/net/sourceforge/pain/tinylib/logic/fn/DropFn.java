package net.sourceforge.pain.tinylib.logic.fn;

import net.sourceforge.pain.tinylib.data.type.*;

public class DropFn {

    public static void drop(Creature creature, Physical target) {
        final Located located = creature.asLocated();
        RelocateFn.relocate(target.asLocated(), located.getLocation());
        final Interactive iTarget = target.asInteractive();
        MessageOutFn.outln(creature, "You drop " + iTarget.getDesc() + ".");
        MessageOutFn.outSpace(creature, "$n drops $P.", creature, iTarget, Receptive.SEE);
    }
}
