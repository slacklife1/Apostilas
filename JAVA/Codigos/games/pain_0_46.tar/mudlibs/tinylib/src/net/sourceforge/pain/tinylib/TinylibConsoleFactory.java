package net.sourceforge.pain.tinylib;

import net.sourceforge.pain.network.console.*;

/**
 * User: fmike  Date: May 31, 2004  Time: 2:55:49 AM
 */
public class TinylibConsoleFactory implements ConsoleFactory {
    public BasicConsole provideConsole(ConsoleAdapter ad) {
        return new Console(ad);
    }
}
