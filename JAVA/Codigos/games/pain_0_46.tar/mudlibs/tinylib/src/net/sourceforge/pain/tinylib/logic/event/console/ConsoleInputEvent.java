package net.sourceforge.pain.tinylib.logic.event.console;

import net.sourceforge.pain.*;
import net.sourceforge.pain.admin.console.*;
import net.sourceforge.pain.data.*;
import net.sourceforge.pain.logic.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.event.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.trigger.*;
import net.sourceforge.pain.tinylib.plugin.command.*;
import net.sourceforge.pain.util.*;

import java.util.*;

/**
 * PAiN MUD CODEBASE.
 * User: fmike
 * Date: Jan 13, 2003
 * Time: 6:27:33 AM
 */
public class ConsoleInputEvent extends AbstractEvent {
    public static final String COMMAND_PACKAGE_PREFIX = "net.sourceforge.pain.tinylib.logic.event.console.command.";

    private static final String[] parsedCommand = new String[2];

    public Object execute(Object param) throws Exception {
        final Console console = (Console) param;
        triggerConsoleInput(console.getPlayer(), console.peekInputLine());
        CommandHandler handler;
        if (console.isRawMode()) {
            handler = (CommandHandler) console.getRawCommand();
        } else {
            final String line = console.popInputLine().trim();
            if (line.length() == 0) {
                return null;
            }
            handler = getCommandHandler(line, console);
            if (handler == null) {
                processFailedCommand(console);
            } else if (!handler.isAccessible()) {
                handler.processNotAccessible();
                handler = null;
            }
        }
        if (handler != null) {
            handler.processCommand();
        }
        return null;
    }

    private void triggerConsoleInput(Player p, String line) {
        if (p == null) {
            return;
        }
        for (Iterator it = p.getTriggersByEventType(TriggerType.TRIGGER_CONSOLE_INPUT); it.hasNext();) {
            try {
                ConsoleInputTrigger t = (ConsoleInputTrigger) TriggersLogicFactory.provideTriggerImpl((TriggerData) it.next());
                t.onConsoleInput(p, line);
            } catch (Exception e) {
                Log.error(e);
            }
        }
    }


    public static CommandHandler getCommandHandler(String inputLine, Console console) throws Exception {
        CommandHandler handler;
        parseCommand(inputLine, parsedCommand);
        String commandName = parsedCommand[0];
        String commandParams = parsedCommand[1];
        CommandMapper commandMapper = getCommandMapper();
        TextCommand textCommand = commandMapper.findCommand(commandName);
        if (textCommand == null) {
            return null;
        }
        handler = instantiateCommandHandler(textCommand.commandClassName);
        handler.commandParams = commandParams;
        handler.command = textCommand;
        Log.debug("ConsoleInputEvent.getCommandHandler: command:'" + commandName + "' tag:'" + textCommand.tag + "' args:'" + commandParams + "'");
        handler.console = console;
        handler.player = console.getPlayer();
        return handler;
    }

    public static CommandMapper getCommandMapper() {
        return (CommandMapper) Codebase.getPluginManager().getPlugin("command.CommandMapper");
    }

    public static CommandHandler instantiateCommandHandler(String commandClassName) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        return (CommandHandler) Codebase.getLogicLoader().provideClass(COMMAND_PACKAGE_PREFIX + commandClassName).newInstance();
    }


    public static void processFailedCommand(Console console) {
        MessageOutFn.out(console, "what?\n");
    }

    public static void parseCommand(String line, String[] parsedcommand) {
        AdminConsoleInputEvent.parseCommand(line, parsedcommand);
    }


}
