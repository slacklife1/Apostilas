package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.*;
import net.sourceforge.pain.util.*;
import net.sourceforge.pain.db.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;
import net.sourceforge.pain.tinylib.logic.transform.rom24support.*;

import java.io.*;


public final class ImportRom24 extends GrantedCommand implements Rom24ConversionLogListener {


    public void processCommand() throws Exception {
        final String areaFile = commandParams;
        if (areaFile == null) {
            usageLine();
            return;
        }
        try {
            DbTransaction t = new DbTransaction() {
                public Object execute(Object[] params) throws Exception {
                    Rom24ToPainConverter.transform(new File(areaFile), (Rom24ConversionLogListener) ImportRom24.this);
                    return null;
                }
            };
            Codebase.getDB().execute(t);
            MessageOutFn.out(console, "Convertion finished!\n");
        } catch (Exception e) {
            MessageOutFn.out(console, FormatUtils.formatStacktrace(e));
            MessageOutFn.out(console, "\n{WConvertion was rolled back, database is not affected{x\n");
        }
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": imports ROM2.4 areas from arealist file");
        usageLine();
        MessageOutFn.outln(console, "Note:This is blocking command and import could take a noticable time");
        MessageOutFn.outln(console, "Note: a number of resets could be created during import");
        MessageOutFn.outln(console, "and it will affect system performance first minute");
    }

    private void usageLine() {
        MessageOutFn.outln(console, "Usage:" + command.name + " <full path to arealist file>");
    }

    public void onConversionMessage(String message) {
        MessageOutFn.outln(console, "{wconverter:{x" + message + "{x");
        console.flushOutput();
    }
}
