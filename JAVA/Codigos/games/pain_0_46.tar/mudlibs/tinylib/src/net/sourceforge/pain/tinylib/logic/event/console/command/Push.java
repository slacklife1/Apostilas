package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;

public final class Push extends CommandHandler {

    public void processNotAccessible() {
        MessageOutFn.outln(console, "push? you do not know how to do it");
    }

    public void processCommand() throws Exception {
        Creature actor = (Creature) player.getRole(Creature.class);


        if (commandParams == null || commandParams.length() == 0) {
            MessageOutFn.outln(console, "Push whom to what direction?");
            return;
        }
        String tokens[] = new String[2];
        ConsoleInputEvent.parseCommand(commandParams, tokens); //extracts first token to tokens[0]
        if (tokens[1] == null || tokens[1].length() == 0) {
            MessageOutFn.outln(console, "Push whom to what direction?");
            return;
        }
        Interactive ivictim = SpaceFindFn.findByPrefix(actor.asLocated(), tokens[0]);
        if (ivictim == null) {
            MessageOutFn.outln(console, "They aren't here.");
            return;
        }
        if (ivictim.sameObjectAs(player)) {
            MessageOutFn.outln(console, "That's pointless.");
            return;
        }
        Physical victim = (Physical) ivictim.getRole(Physical.class);
        if (victim == null) {
            MessageOutFn.outln(console, "Push non physical one?");
            return;
        }
        int direction = Utils.exitNameToDir(tokens[1].toLowerCase());
        if (direction == -1) {
            MessageOutFn.outln(console, "Alas, you cannot push that way.");
            return;
        }
        try {
            PushFn.push(actor, victim, direction);
        } catch (LogicException e) {
            switch (e.errorCode) {
                case RelocationErrors.ERR_MOVE_NO_EXITS_FOUND:
                    MessageOutFn.outln(console, "Alas, you cannot push that way!");
                    break;
                case RelocationErrors.ERR_NOT_ENOUGH_TARGET_SPACE:
                    MessageOutFn.outln(console, "There's no more room there.");
                    break;
                default:
                    MessageOutFn.outln(console, "You failed.");
            }
        }
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": push target object to specified direction");
        MessageOutFn.outln(console, "Usage : " + command.name + " <victim (is Physical)> <direction>");
    }

}
