package net.sourceforge.pain.tinylib.data.prototype;



import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.db.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.util.*;


public final class CreaturePrototype extends Prototype {

    public static final int HIT_POINTS_DICE = LAST_BASE_FIELD_INDEX + 1;
    public static final int RACE = LAST_BASE_FIELD_INDEX + 2;
    private static final int SEX = LAST_BASE_FIELD_INDEX + 3;
    private static final int INVENTORY_PROTO = LAST_BASE_FIELD_INDEX + 4;
    public static final int MOVE_POINTS_DICE = LAST_BASE_FIELD_INDEX + 5;
    private static final int NFIELDS = LAST_BASE_FIELD_INDEX + 6;


    private final static Class[] superroles = new Class[]{PhysicalPrototype.class, ReceptivePrototype.class};

    public static final int SEX_UNDEFINED = 0;
    public static final int SEX_MALE = 1;
    public static final int SEX_FEMALE = 2;
    public static final int SEX_EITHER = 3;

    public static final String[] SEX_NAMES = new String[]{"UNDEFINED", "MALE", "FEMALE", "EITHER"};


    public CreaturePrototype(PainDB db) {
        super(db);
    }

    public CreaturePrototype() {
    }

    public Class[] getSuperroles() {
        return superroles;
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        fillSuperSchema(types, names);

        types[HIT_POINTS_DICE] = DbType.ARRAY_OF_INT;
        names[HIT_POINTS_DICE] = "hp_dice";

        types[RACE] = DbType.REFERENCE;
        names[RACE] = "race";

        types[SEX] = DbType.INT;
        names[SEX] = "sex";

        types[INVENTORY_PROTO] = DbType.REFERENCE;
        names[INVENTORY_PROTO] = "inventory";

        types[MOVE_POINTS_DICE] = DbType.ARRAY_OF_INT;
        names[MOVE_POINTS_DICE] = "mp_dice";

        return new DbClassSchema(types, names);
    }

    public Dice getHPDice() {
        return new Dice(getIntArray(HIT_POINTS_DICE));
    }

    public void setHPDice(Dice dice) {
        setIntArray(HIT_POINTS_DICE, dice.data());
    }

    public Class getPrototypedRoleClass() {
        return Creature.class;
    }

    public Race getRace() {
        return (Race) getReference(RACE);
    }

    public void setRace(Race race) {
        setReference(RACE, race);
    }

    public int getSex() {
        return getInt(SEX);
    }

    public void setSex(int sex) {
        if (sex < SEX_UNDEFINED || sex > SEX_EITHER) {
            throw new IllegalArgumentException("Invalid field valud:" + sex);
        }
        setInt(SEX, sex);
    }

    public String toString() {
        int[] dice = getIntArray(HIT_POINTS_DICE);
        Race race = getRace();
        int sex = getSex();
        SpacePrototype sp = getInventoryPrototype();
        return "hp_dice=" + (dice == null ? "null" : Dice.format(dice))
                + " race=" + (race == null ? "null" : race.getName())
                + " sex=" + SEX_NAMES[sex] + "inv name=" + (sp == null ? null : sp.getSpaceName()) + " desc=" + (sp == null ? null : sp.getSpaceDesc());
    }

    public SpacePrototype getInventoryPrototype() {
        return (SpacePrototype) getReference(INVENTORY_PROTO);
    }

    public void setInventoryPrototype(SpacePrototype p) {
        setReference(INVENTORY_PROTO, p);
    }

    public Dice getMovePointsDice() {
        return new Dice(getIntArray(MOVE_POINTS_DICE));
    }

    public void setMovePointsDice(Dice dice) {
        setIntArray(MOVE_POINTS_DICE, dice.data());
    }

    public void delete() {
        getInventoryPrototype().delete();
        super.delete();
    }


}
