package net.sourceforge.pain.tinylib.logic.event;

import net.sourceforge.pain.*;
import net.sourceforge.pain.tinylib.plugin.shutdown.*;


/**
 * PAiN  Date: 14.04.2003  Time: 0:38:36
 */
public class ShutdownRequestEvent extends AbstractEvent {

    public static final Integer shutTime = new Integer(20);

    public Object execute(Object param) throws Exception {
        ShutdownTimer shutTimer = (ShutdownTimer) Codebase.getPluginManager().getPlugin("shutdown.ShutdownTimer");
        if (shutTimer != null && !shutTimer.isShutdownInProcess()) {
            shutTimer.startShutdown(shutTime.intValue(), true);
        }
        return shutTime;
    }

}
