package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.*;
import net.sourceforge.pain.plugin.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

import java.util.*;


/**
 * duplicate of 'pluglist' admin console command 
 */
public final class PlugList extends GrantedCommand {


    public void processCommand() throws Exception {
        List list = Codebase.getPluginManager().getActivePluginsList();
        MessageOutFn.outln(console, "{cActive plugins list:{x");
        for (Iterator it = list.iterator(); it.hasNext();) {
            Plugin p = (Plugin) it.next();
            MessageOutFn.outln(console, "    " + p.getPluginName());
        }
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": shows active plugins list");
        MessageOutFn.outln(console, "Usage:" + command.name);
    }
}
