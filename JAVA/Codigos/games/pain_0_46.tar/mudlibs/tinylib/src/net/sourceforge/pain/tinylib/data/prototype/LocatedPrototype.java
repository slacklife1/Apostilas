package net.sourceforge.pain.tinylib.data.prototype;


import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.db.*;
import net.sourceforge.pain.tinylib.data.type.*;


public final class LocatedPrototype extends Prototype {

    private static final int NFIELDS = LAST_BASE_FIELD_INDEX + 1;

    private final static Class[] superroles = new Class[]{PrototypeInfo.class};

    public LocatedPrototype(PainDB db) {
        super(db);
    }

    public LocatedPrototype() {
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        fillSuperSchema(types, names);

        return new DbClassSchema(types, names);
    }

    public Class getPrototypedRoleClass() {
        return Located.class;
    }

    public String toString() {
        return "no fields to show";
    }

    protected Class[] getSuperroles() {
        return superroles;
    }

}
