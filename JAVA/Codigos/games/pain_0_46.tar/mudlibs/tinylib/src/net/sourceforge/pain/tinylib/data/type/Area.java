package net.sourceforge.pain.tinylib.data.type;


import net.sourceforge.pain.data.*;
import net.sourceforge.pain.db.*;
import net.sourceforge.pain.tinylib.*;

import java.util.*;


/**
 * set of rooms and rooms resets
 */
public final class Area extends Role {


    private static final int NAME = 1 + LAST_BASE_FIELD_INDEX;
    private static final int ROOMS = 2 + LAST_BASE_FIELD_INDEX;
    private static final int RESETS = 3 + LAST_BASE_FIELD_INDEX;
    private static final int NEXT_RESET_TIME = 4 + LAST_BASE_FIELD_INDEX;
    private static final int RESET_PERIOD = 5 + LAST_BASE_FIELD_INDEX;
    private static final int RESET_MESSAGE = 6 + LAST_BASE_FIELD_INDEX;
    private static final int AREA_DESC = 7 + LAST_BASE_FIELD_INDEX;
    private static final int NFIELDS = 8 + LAST_BASE_FIELD_INDEX;

    public Area() {
    }

    public Area(PainDB db) {
        super(db);
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];
        fillSuperSchema(types, names);

        types[NAME] = DbType.STRING;
        names[NAME] = "name";

        types[ROOMS] = DbType.SEPARATELY_SAVED_REFERENCE_SET;
        names[ROOMS] = "rooms";

        types[RESETS] = DbType.SEPARATELY_SAVED_REFERENCE_SET;
        names[RESETS] = "resets";

        types[NEXT_RESET_TIME] = DbType.INT;
        names[NEXT_RESET_TIME] = "next_reset_time";

        types[RESET_PERIOD] = DbType.INT;
        names[RESET_PERIOD] = "reset_period";

        types[RESET_MESSAGE] = DbType.STRING;
        names[RESET_MESSAGE] = "reset_message";

        types[AREA_DESC] = DbType.STRING;
        names[AREA_DESC] = "area_desc";


        return new DbClassSchema(types, names);
    }

    public Set getRooms() {
        return getRefSet(ROOMS);
    }
    
    public String getName() {
        return getString(NAME);
    }

    public void setName(String newName) {
        setString(NAME, newName);
    }

    public int getResetPeriod() {
        return getInt(RESET_PERIOD);
    }

    public void setResetPeriod(int time) {
        setInt(RESET_PERIOD, time);
    }


    public int getNextResetTime() {
        return getInt(NEXT_RESET_TIME);
    }

    public void setNextResetTime(int time) {
        setInt(NEXT_RESET_TIME, time);
    }

    public String getResetMessage() {
        return getString(RESET_MESSAGE);
    }

    public void setResetMessage(String message) {
        setString(RESET_MESSAGE, message);
    }

    public void setAreaDesc(String desc) {
        setString(AREA_DESC, desc);
    }

    public String getAreaDesc() {
        return getString(AREA_DESC);
    }

    public Set getResets() {
        return getRefSet(RESETS);
    }
}

