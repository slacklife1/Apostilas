package net.sourceforge.pain.tinylib.logic.trigger;

import net.sourceforge.pain.data.*;
import net.sourceforge.pain.logic.*;
import net.sourceforge.pain.tinylib.data.type.*;

/**
 * User: fmike  Date: Nov 25, 2003   Time: 3:25:29 AM
 */
public abstract class ConsoleInputTrigger extends Trigger {

    protected ConsoleInputTrigger(TriggerData td) {
        super(td);
    }

    public abstract void onConsoleInput(Player p, String text);

    public final int getTriggerEventType() {
        return TriggerType.TRIGGER_CONSOLE_INPUT;
    }
}
