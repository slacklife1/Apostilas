package net.sourceforge.pain.tinylib.data.type;


import net.sourceforge.pain.data.*;
import net.sourceforge.pain.db.*;


/**
 * Object with <code>Space</code> role is an element of space by itself.<br>
 * Any <code>Located</code> object is allowed to be located inside space.<br>
 * It has limited or unlimited <code>capacity</code> for <code>Physical</code> objects inside (<code>Physical.size</code> field)<br>
 * Also it has it <code>name</code> (not unique) and internal space description<br>
 * Space content is organized in double-linked list of located objects
 */
public final class Space extends Role {

    /**
     * Space capacity of the phisical objects, measured in the same units as Physical.size
     */
    private static final int CAPACITY = 1 + LAST_BASE_FIELD_INDEX;

    /**
     * any space could have specific name, or not:)  )
     */
    private static final int SPACE_NAME = 2 + LAST_BASE_FIELD_INDEX;

    /**
     * We can look around in any Space, event in backpack or chests
     */
    private static final int SPACE_DESC = 3 + LAST_BASE_FIELD_INDEX;

    /**
     * First of Located in this space Objects
     */
    private static final int FIRST_IN_SPACE = 4 + LAST_BASE_FIELD_INDEX;

    private static final int NFIELDS = 5 + LAST_BASE_FIELD_INDEX;

    public Space() {
    }

    public Space(PainDB db) {
        super(db);
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        fillSuperSchema(types, names);

        types[CAPACITY] = DbType.INT;
        names[CAPACITY] = "capacity";

        types[SPACE_NAME] = DbType.STRING;
        names[SPACE_NAME] = "name";

        types[SPACE_DESC] = DbType.STRING;
        names[SPACE_DESC] = "desc";

        types[FIRST_IN_SPACE] = DbType.REFERENCE;
        names[FIRST_IN_SPACE] = "first_in_space";

        return new DbClassSchema(types, names);
    }

    public Located getFirstInSpace() {
        return (Located) getReference(FIRST_IN_SPACE);
    }

    public void setFirstInSpace(Located l) {
        setReference(FIRST_IN_SPACE, l);
    }

    public String getDesc() {
        return getString(SPACE_DESC);
    }

    public void setDesc(String value) {
        setString(SPACE_DESC, value);
    }

    public String getName() {
        return getString(SPACE_NAME);
    }

    public void setName(String value) {
        setString(SPACE_NAME, value);
    }

    public int getCapacity() {
        return getInt(CAPACITY);
    }

    public void setCapacity(int value) {
        setInt(CAPACITY, value);
    }

}
