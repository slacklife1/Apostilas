package net.sourceforge.pain.tinylib.logic.event.console.command.builder;

import net.sourceforge.pain.tinylib.*;

/**
 * PAiN  Date: 05.06.2003  Time: 1:31:27
 */
public abstract class BuilderCommand {

    public abstract void processBuilderCommand(BuilderShell p, String args) throws Exception;

    public String getName() {
        return "-";
    }

    public abstract void showHelp(Console console);

}
