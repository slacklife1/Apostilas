package net.sourceforge.pain.tinylib.data.type;


import net.sourceforge.pain.data.*;
import net.sourceforge.pain.db.*;


/**
 * Interactive role is a one of the base concepts of PAiN engine.<br>
 * We can interact only with Interactive objects.<br>
 * Any Interactive object has a 'interactive_name' property, for player characters this<br>
 * field contains player name. <br>
 * 'target_list' field contains all names we can use to interact with  object.<br>
 * 'interactive_desc' is a small description we can see about this object.<br>
 * Interactive objects are required to be Receptive<br>
 * in order to receive events from outside world
 */

public final class Interactive extends Role {

    /**
     * we see interactive object in space via it's  DESC
     */
    private static final int DESC = 1 + LAST_BASE_FIELD_INDEX;

    /**
     * We can interact with object via one of it's target names
     */
    private static final int TARGET_LIST = 2 + LAST_BASE_FIELD_INDEX;

    /**
     * usage example: 'Interactive_Name' tells you..
     */
    private static final int INTERACTIVE_NAME = 3 + LAST_BASE_FIELD_INDEX;

    private static final int NFIELDS = 4 + LAST_BASE_FIELD_INDEX;

    private final static Class superroles[] = new Class[]{Located.class};

    public Interactive(PainDB db) {
        super(db);
    }

    public Interactive() {
    }

    public Class[] getSuperroles() {
        return superroles;
    }


    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        fillSuperSchema(types, names);

        types[DESC] = DbType.STRING;
        names[DESC] = "desc";

        types[TARGET_LIST] = DbType.ARRAY_OF_STRING;
        names[TARGET_LIST] = "target_list";

        types[INTERACTIVE_NAME] = DbType.STRING;
        names[INTERACTIVE_NAME] = "interactive_name";

        return new DbClassSchema(types, names);
    }

    public void setDesc(String value) {
        setString(DESC, value);
    }

    public String getDesc() {
        return getString(DESC);
    }

    public void setName(String value) {
        setString(INTERACTIVE_NAME, value);
    }

    public String getName() {
        return getString(INTERACTIVE_NAME);
    }

    /**
     * all values should be in lowercase
     *
     * @param list
     */
    public void setTargetList(String[] list) {
        setStringArray(TARGET_LIST, list);
    }

    public String[] getTargetList() {
        return getStringArrayForRead(TARGET_LIST);
    }

    public Space getLocation() {
        return ((Located) getRole(Located.class)).getLocation();
    }

    public Located asLocated() {
        return (Located) getRole(Located.class);
    }


}
