package net.sourceforge.pain.tinylib.logic.fn;

import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.type.*;

/*
* Original code written by fmike.
* Visual addition written by lukeo
*/

public final class PromptFn {
    public static String promptKey = "prompt";

    public static void printPrompt(Console console) {
        Player p = console.getPlayer();
        Creature creature = (Creature)
                p.getRole(Creature.class);
        MessageOutFn.out(console, "\n");
        Room exits = (Room) p.getLocation().getRole(Room.class);
        StringBuffer promptBuf = new StringBuffer();
        if (creature != null) {
            if (p.getRoleClientProperty(promptKey) != null) {
                promptBuf.append("< " + hpToVisual(creature) + " > | ");
                promptBuf.append("< " + mpToVisual(creature) + " > ");
            } else {
                promptBuf.append(creature.getHitPoints() + "/" + creature.getMaxLifePoints() + "hp ");
                promptBuf.append(creature.getMoves() + "/" + creature.getMaxMoves() + "mv ");
            }
        }
        if (creature != null) {
            promptBuf.append(": {c");
        } else {
            promptBuf.append("{c");
        }

        boolean exitsFound = false;
        if (exits != null) {
            if (exits.getExit(Room.DIR_NORTH) != null) {
                promptBuf.append("N");
                exitsFound = true;
            }
            if (exits.getExit(Room.DIR_EAST) != null) {
                promptBuf.append("E");
                exitsFound = true;
            }
            if (exits.getExit(Room.DIR_SOUTH) != null) {
                promptBuf.append("S");
                exitsFound = true;
            }
            if (exits.getExit(Room.DIR_WEST) != null) {
                promptBuf.append("W");
                exitsFound = true;
            }
            if (exits.getExit(Room.DIR_UP) != null) {
                promptBuf.append("U");
                exitsFound = true;
            }
            if (exits.getExit(Room.DIR_DOWN) != null) {
                promptBuf.append("D");
                exitsFound = true;
            }
        }
        if (!exitsFound) {
            promptBuf.append("*");
        }
        promptBuf.append(" {x# ");
        MessageOutFn.out(console, promptBuf.toString());
    }


    public static String hpToVisual(Creature creature) {
        // This will print out the prompt in a
        // visual manner instead of numbers. The large
        // values will need to be converted to smaller
        // ones by merely dividing (I think) [edit: instead
        // of converting the numbers to smaller ones, a
        // few 'ifs' can be used to work it out] and then
        // that many bars will be printed out.
        // This method of visualisation is quite boring
        // and unoriginal, so perhaps I will design a
        // slider type way to display information.
        int currentHP, maxHP;
        // values for the hp.
        currentHP = creature.getHitPoints();
        maxHP = creature.getMaxLifePoints();
        // apply the players values to the variables.
        String hpOutput;
        double hpBarWorth = maxHP / 6;
        if (currentHP <= maxHP && currentHP > maxHP - hpBarWorth) {
            // if the currentHP is between maximumHP and
            // 5/6ths of the maxHP, then there should be
            // 6 stars (full health)
            hpOutput = "{r**{y**{g**{x";
        } else if (currentHP <= maxHP - hpBarWorth && currentHP > maxHP - (2 * hpBarWorth)) {
            // if the currentHP is between 5/6ths and 4/6ths
            // then there should be 5 stars.
            hpOutput = "{r**{y**{g*{x ";
        } else if (currentHP <= maxHP - (2 * hpBarWorth) && currentHP > maxHP - (3 * hpBarWorth)) {
            // etc. etc...
            hpOutput = "{r**{y** {x ";
        } else if (currentHP <= maxHP - (3 * hpBarWorth) && currentHP > maxHP - (4 * hpBarWorth)) {
            hpOutput = "{r**{y* {x  ";
        } else if (currentHP <= maxHP - (4 * hpBarWorth) && currentHP > maxHP - (5 * hpBarWorth)) {
            hpOutput = "{r**  {x  ";
        } else if (currentHP <= maxHP - (5 * hpBarWorth)) {
            hpOutput = "{r*    {x ";
        } else {
            hpOutput = "ERROR: please report to an admin.";
        }
        return hpOutput;
    }


    public static String mpToVisual(Creature creature) {
        // the same as hpToVisual except using the players MP.
        int currentMP = creature.getMoves();
        int maxMP = creature.getMaxMoves();
        String mpOutput;
        double mpBarWorth = maxMP / 6;
        if (currentMP <= maxMP && currentMP > maxMP - mpBarWorth) {
            // if the currentHP is between maximumHP and
            // 5/6ths of the maxHP, then there should be
            // 6 stars (full health)
            mpOutput = "{r**{y**{g**{x";
        } else if (currentMP <= maxMP - mpBarWorth && currentMP > maxMP - (2 * mpBarWorth)) {
            // if the currentHP is between 5/6ths and 4/6ths
            // then there should be 5 stars.
            mpOutput = "{r**{y**{g*{x ";
        } else if (currentMP <= maxMP - (2 * mpBarWorth) && currentMP > maxMP - (3 * mpBarWorth)) {
            // etc. etc...
            mpOutput = "{r**{y** {x ";
        } else if (currentMP <= maxMP - (3 * mpBarWorth) && currentMP > maxMP - (4 * mpBarWorth)) {
            mpOutput = "{r**{y* {x  ";
        } else if (currentMP <= maxMP - (4 * mpBarWorth) && currentMP > maxMP - (5 * mpBarWorth)) {
            mpOutput = "{r**   {x ";
        } else if (currentMP <= maxMP - (5 * mpBarWorth)) {
            mpOutput = "{r*   {x  ";
        } else if (currentMP <= 0) {
            mpOutput = "      ";
        } else {
            mpOutput = "ERROR: please report to an admin.";
        }
        return mpOutput;
    }
}