package net.sourceforge.pain.tinylib.logic.event.deploy;

import net.sourceforge.pain.*;
import net.sourceforge.pain.data.*;
import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.logic.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.*;
import net.sourceforge.pain.tinylib.data.prototype.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.affect.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.util.*;

import java.util.*;

/**
 * User: fmike  Date: Mar 10, 2004  Time: 2:28:44 AM
 * This event is generated during new database creation
 * Event impl should create initial world image.
 * Note: Core is not initialized yet, and plugins are not loaded
 * during this event call.
 * <p/>
 */
public class CreateInitialWorldEvent implements Event {

    public Object processEvent(Object param) throws Exception {
        World world = Mudlib.getWorld();

        world.setName("PAiN world");

        Race hr = (Race) ObjectFactory.createRaw(Race.class);
        hr.setName("Human");
        hr.setCreaturesSize(10);
        world.getRaces().add(hr);

        Race dr = (Race) ObjectFactory.createRaw(Race.class);
        dr.setName("Dwarf");
        dr.setCreaturesSize(6);
        world.getRaces().add(dr);

        Race er = (Race) ObjectFactory.createRaw(Race.class);
        er.setName("Elf");
        er.setCreaturesSize(5);
        world.getRaces().add(er);

        Log.info("Creating areas and rooms");

        Area area = (Area) ObjectFactory.createRaw(Area.class);
        area.setName("Initial");
        area.setAreaDesc("Initial Area");
        area.setResetPeriod(Pulse.PULSE_PER_MIN * 3);
        world.getAreasByName().put(area.getName(), area);

        //creating 2 rooms and tunnel
        Room room1 = (Room) ObjectFactory.createRaw(Room.class);
        room1.setRoomUniqueId("first");
        world.getRoomsByIdMap().put(room1.getRoomUniqueId(), room1);
        area.getRooms().add(room1);
        room1.setArea(area);
        Space space1 = room1.asSpace();
        space1.setName("A Clammy Cavern");
        space1.setDesc("The air in this darkly lit cavern is close and humid. Not only does the stench of decay float endlessly from \n" +
                "the damp stone floor, but the air seems choking and warm. The cavern expands a great distance away to all \n" +
                "sides, causing the floor and ceiling to merge into one in the gloom. A flickering, orange glow is cast \n" +
                "across the room from various directions from iron sconces in the wall � though the flames seem almost as \n" +
                "candles from a distance as they try to pierce the shadow.\n" +
                "At the far north of the cavern a sudden chill breeze flows from an even darker passage.");
        space1.setCapacity(Integer.MAX_VALUE);


        Room room2 = (Room) ObjectFactory.createRaw(Room.class);
        room2.setRoomUniqueId("second");
        world.getRoomsByIdMap().put(room2.getRoomUniqueId(), room2);
        area.getRooms().add(room2);
        room2.setArea(area);
        Space space2 = room2.asSpace();
        space2.setName("A Thin Passage");
        space2.setDesc("Barely wider than the shoulders of a man, this passage has a cold air in it. The walls are cut straight from \n" +
                "the rock � cold and damp to the touch, while the ceiling is rough and uneven, only just high enough to walk \n" +
                "under. The passage slopes gradually northwards, continuing for over a hundred yards. The light in the \n" +
                "passage enters from either end, leaving the centre in an almost impenetrable gloom.");
        space2.setCapacity(10);


        Room room3 = (Room) ObjectFactory.createRaw(Room.class);
        room3.setRoomUniqueId("third");
        world.getRoomsByIdMap().put(room3.getRoomUniqueId(), room3);
        area.getRooms().add(room3);
        room3.setArea(area);
        Space space3 = room3.asSpace();
        space3.setName("A Huge, Airy Cavern ");
        space3.setDesc("Wide and open, this spacious cavern has a high ceiling, and then floor quickly changes from a browny-orange \n" +
                "rock to the south, into smooth, hard granite. The walls are cut also from this dark granite, though have \n" +
                "become smooth like the floor over many hundreds of years. Cold air wafts into the cavern from shafts in the \n" +
                "high roof, which send arrows of light shooting down to the floor. The cavern is rounded, with the only exit \n" +
                "a small passage in the southern wall.");
        space3.setCapacity(Integer.MAX_VALUE);


//binding rooms exits
        Exit exitRoom1ToRoom2 = (Exit) ObjectFactory.createRaw(Exit.class);
        exitRoom1ToRoom2.setTargetRoom(room2);
        exitRoom1ToRoom2.setMoveConst(1);
        exitRoom1ToRoom2.setExitDesc("a thin passage");
        room1.setExit(Room.DIR_NORTH, exitRoom1ToRoom2);

        Exit exitRoom2ToRoom1 = (Exit) ObjectFactory.createRaw(Exit.class);
        exitRoom2ToRoom1.setTargetRoom(room1);
        exitRoom2ToRoom1.setMoveConst(1);
        exitRoom2ToRoom1.setExitDesc("a clammy cavern");
        room2.setExit(Room.DIR_SOUTH, exitRoom2ToRoom1);


        Exit exitRoom2ToRoom3 = (Exit) ObjectFactory.createRaw(Exit.class);
        exitRoom2ToRoom3.setTargetRoom(room3);
        exitRoom2ToRoom3.setMoveConst(1);
        exitRoom2ToRoom3.setExitDesc("a huge, airy cavern");
        room2.setExit(Room.DIR_NORTH, exitRoom2ToRoom3);

        Exit exitRoom3ToRoom2 = (Exit) ObjectFactory.createRaw(Exit.class);
        exitRoom3ToRoom2.setTargetRoom(room2);
        exitRoom3ToRoom2.setMoveConst(1);
        exitRoom3ToRoom2.setExitDesc("a thin passage");
        room3.setExit(Room.DIR_SOUTH, exitRoom3ToRoom2);

        world.setDefaultBirthSpace(space1);


        Log.info("Creating GOD");
        Player gp = (Player) ObjectFactory.createRaw(Player.class);
        gp.setLogin("god");
        gp.setPassword("god");
        gp.setQuitSpace(space1);
        gp.addRole(Builder.class);
        world.getPlayersByLoginMap().put(gp.getLogin(), gp);
        Interactive gi = gp.asInteractive();
        gi.setName("God");
        gi.setDesc("God");
        gi.setTargetList(new String[]{"god", "creator"});
        RelocateFn.addToSpace(space1, gp.asLocated());
        Creature creature = (Creature) gp.addRole(Creature.class);
        Space inventory = (Space) ObjectFactory.createRaw(Space.class);
        inventory.setCapacity(Integer.MAX_VALUE);
        inventory.setName("Inventory");
        inventory.setDesc("Inside inventory");
        creature.setInventory(inventory);
        creature.setMaxHitPoints(1000);
        creature.setHitPoints(1000);
        creature.setMaxMoves(1000);
        creature.setMoves(1000);
        ImmortalityAffect.makeImmortal(creature);

        // granting comands to 'god':
        Set granted = gp.getGrantedCommands();
        granted.add("_all"); // special keyword, all commands allowed

        Log.info("Creating thing!");
        Physical tp = (Physical) ObjectFactory.createRaw(Physical.class);
        tp.setSize(3);
        tp.setWeight(20);
        tp.setAppearanceDesc("small stone");
        Interactive ti = tp.asInteractive();
        ti.setName("small stone");
        ti.setDesc("small stone");
        ti.setTargetList(new String[]{"stone", "small"});
        RelocateFn.addToSpace(space1, ti.asLocated());

        // create new player proto
        PrototypeInfo newPlayerProto = (PrototypeInfo) ObjectFactory.createRaw(PrototypeInfo.class);
        newPlayerProto.setVnum("player");
        newPlayerProto.setName("New players prototype");
        newPlayerProto.setAuthor("god");

        CreaturePrototype cp = (CreaturePrototype) newPlayerProto.addRole(CreaturePrototype.class);
        cp.setHPDice(new Dice(10, 10, 10));
        cp.setSex(CreaturePrototype.SEX_EITHER);
        cp.setRace(hr);
        cp.setMovePointsDice(new Dice(10, 10, 50));

        PhysicalPrototype pp = (PhysicalPrototype) newPlayerProto.getRole(PhysicalPrototype.class);
        pp.setAppearanceDesc("You see nothing special about him");
        pp.setSize(1);
        pp.setWeight(1);

        ReceptivePrototype rp = (ReceptivePrototype) newPlayerProto.getRole(ReceptivePrototype.class);
        rp.setCanFeel(true);
        rp.setCanHear(true);
        rp.setCanSee(true);

        InteractivePrototype ip = (InteractivePrototype) newPlayerProto.getRole(InteractivePrototype.class);
        ip.setDesc("human");
        ip.setTargetList(new String[]{"man", "human", "creature"});


        PrototypeInfo inventoryProto = (PrototypeInfo) ObjectFactory.createRaw(PrototypeInfo.class);
        inventoryProto.setName("default inventory prototype");
        inventoryProto.setVnum("inventory0");
        SpacePrototype invProto = (SpacePrototype) inventoryProto.addRole(SpacePrototype.class);
        invProto.setSpaceName("Inventory");
        invProto.setSpaceDesc("");
        invProto.setCapacity(Integer.MAX_VALUE);
        cp.setInventoryPrototype(invProto);

        world.getPrototypesByVnumMap().put(inventoryProto.getVnum(), inventoryProto);
        world.getPrototypesByVnumMap().put(newPlayerProto.getVnum(), newPlayerProto);

        Log.info("world created!");
        return null;
    }
}
