package net.sourceforge.pain.tinylib.logic.fn.util;

import net.sourceforge.pain.data.*;
import net.sourceforge.pain.tinylib.data.type.*;

/**
 * User: fmike * Date: Aug 17, 2003  * Time: 2:55:35 AM
 */
public final class LangUtil {
    public static final String[] exitName = new String[]{"north", "east", "south", "west", "up", "down"};


    public static final String he(int sex) {
        if (sex == Creature.SEX_MALE) {
            return "he";
        } else if (sex == Creature.SEX_FEMALE) {
            return "she";
        }
        return "it";

    }

    public static final String He(int sex) {
        if (sex == Creature.SEX_MALE) {
            return "He";
        } else if (sex == Creature.SEX_FEMALE) {
            return "She";
        }
        return "It";
    }

    private static String him(int sex) {
        if (sex == Creature.SEX_MALE) {
            return "him";
        } else if (sex == Creature.SEX_FEMALE) {
            return "her";
        }
        return "it";

    }

    private static String his(int sex) {
        if (sex == Creature.SEX_MALE) {
            return "his";
        } else if (sex == Creature.SEX_FEMALE) {
            return "her";
        }
        return "its";

    }

    public static final String he(Role obj) {
        Creature creature = (Creature) obj.getRole(Creature.class);
        if (creature == null) {
            return he(Creature.SEX_UNDEFINED);
        } else {
            return he(creature.getSex());
        }
    }


    public static final String him(Role obj) {
        Creature creature = (Creature) obj.getRole(Creature.class);
        if (creature == null) {
            return him(Creature.SEX_UNDEFINED);
        } else {
            return him(creature.getSex());
        }
    }


    public static final String his(Role  obj) {
        Creature creature = (Creature) obj.getRole(Creature.class);
        if (creature == null) {
            return his(Creature.SEX_UNDEFINED);
        } else {
            return his(creature.getSex());
        }
    }

    public static String directionName(int type) {
        return exitName[type];

    }

    public static String s(int num, String str) {
        if (num > 1) {
            return str + "s";
        }
        return str;
    }


}
