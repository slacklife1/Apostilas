package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.affect.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;

public final class Go extends CommandHandler {

    public boolean isAccessible() {
        return super.isAccessible() && player.is(Creature.class);
    }

    public void processNotAccessible() {
        MessageOutFn.outln(console, "go? you do not know how to do it");
    }

    public void processCommand() throws Exception {
        Creature creature = (Creature) player.getRole(Creature.class);
        //todo: this check should be done in xxxFn classes
        if (creature.isAffected(AffectType.AFFECT_IMMOBILE)) {
            MessageOutFn.outln(console, "You can't go!");
            return;
        }
        final String directionStr = command.tag;
        int dir = Utils.exitCharToDir(directionStr.charAt(0));
        try {
            boolean affectMoves = creature.getMoves() > 5;//hack, no refreshing timer still :(
            GoFn.go(creature, dir, affectMoves);
        } catch (LogicException e) {
            switch (e.errorCode) {
                case RelocationErrors.ERR_MOVE_NO_EXITS_FOUND:
                    MessageOutFn.outln(console, "Alas, you cannot go that way!");
                    break;
                case RelocationErrors.ERR_MOVE_NOT_ENOUGH_MOVE_POINTS:
                    MessageOutFn.outln(console, "You are too exhausted.");
                    break;
                case RelocationErrors.ERR_NOT_ENOUGH_TARGET_SPACE:
                    MessageOutFn.outln(console, "There's no more room there.");
                    break;
                default:
                    MessageOutFn.outln(console, "You failed.");
            }
        }
    }

    public void showHelp() {
        final String dir;
        switch (command.tag.charAt(0)) {
            case 'N':
                dir = "north";
                break;
            case 'E':
                dir = "east";
                break;
            case 'S':
                dir = "south";
                break;
            case 'W':
                dir = "west";
                break;
            case 'U':
                dir = "up";
                break;
            case 'D':
                dir = "down";
                break;
            default:
                throw new RuntimeException("BUG! wrong direction!:" + command.tag);
        }
        MessageOutFn.outln(console, command.name + ": command allows you to go " + dir);
    }

}
