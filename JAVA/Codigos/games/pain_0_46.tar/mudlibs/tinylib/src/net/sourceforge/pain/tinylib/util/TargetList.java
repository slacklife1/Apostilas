/*
 * Created by IntelliJ IDEA.
 * User: fmike
 * Date: 20.07.2003
 * Time: 0:56:28
 */
package net.sourceforge.pain.tinylib.util;

/**
 * This class presents a target list wrapper. It provides basic operations on target list.
 * (We keep array of Strings as target list in db)
 */
public final class TargetList {

    /**
     * add name to the start of target list and converts it to lowercase
     */
    public static String[] addNameToList(String list[], String name) {
        return addNameToList(list, 0, name);
    }


    /**
     * add name to target list and converts it to lowercase
     */
    public static String[] addNameToList(String list[], int index, String name) {
        String newList[] = new String[list.length + 1];
        if (index == 0) {
            System.arraycopy(list, 0, newList, 1, list.length);
        } else if (index == list.length) {
            System.arraycopy(list, 0, newList, 0, list.length);
        } else {
            System.arraycopy(list, 0, newList, 0, index);
            System.arraycopy(list, index, newList, index + 1, list.length - index);
        }
        newList[index] = name.toLowerCase();
        return newList;
    }

    public static String string(String[] targetList) {
        if (targetList == null) {
            return null;
        }
        if (targetList.length == 0) {
            return "<<empty>>";
        }
        StringBuffer b = new StringBuffer();
        for (int i = 0; i < targetList.length; i++) {
            b.append(targetList[i]);
            if (i < targetList.length - 1) {
                b.append(" ");
            }
        }
        return b.toString();
    }


}