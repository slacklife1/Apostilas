package net.sourceforge.pain.tinylib.logic.event.console.command.builder;

import net.sourceforge.pain.data.*;
import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

import java.util.*;

/**
 * PAiN  Date: 05.06.2003  Time: 1:40:02
 */
public final class BC_New extends BuilderCommand {

    public void processBuilderCommand(BuilderShell p, String args) throws Exception {
        if (args != null) {
            String params[] = new String[2];
            ConsoleInputEvent.parseCommand(args, params);
            if (params[1] != null) {
                Map prototypesByVnum = Mudlib.getWorld().getPrototypesByVnumMap();
                final String vnum = params[0];
                if (prototypesByVnum.containsKey(vnum)) {
                    MessageOutFn.outln(p.console, "Vnum is already in use:" + vnum);
                } else {
                    MessageOutFn.outln(p.console, "Prototype created vnum:" + vnum + " name:" + params[1]);
                    PrototypeInfo prototype = (PrototypeInfo) ObjectFactory.createRaw(PrototypeInfo.class);
                    prototype.setAuthor(p.console.getPlayer().getInteractiveName());
                    prototype.setName(params[1]);
                    prototype.setDesc("NONE");
                    prototype.setVnum(vnum);
                    prototypesByVnum.put(vnum, prototype);
                    p.builder.getEditedPrototypesList().add(prototype);
                    p.builder.setEditedRole(prototype);
                }
                return;
            } else {
                showUsage(p.console);
            }
        } else {
            showUsage(p.console);
        }
    }

    public void showUsage(Console console) {
        MessageOutFn.outln(console, "NEW:Command syntax <VNUM> <PROTONAME>\n");
    }

    public void showHelp(Console console) {
        MessageOutFn.outln(console, "Builder command NEW creates new prototype object and adds it to edited prototypes list");
        MessageOutFn.outln(console, "Usage: new <VNUM> <PROTONAME>");
    }

}
