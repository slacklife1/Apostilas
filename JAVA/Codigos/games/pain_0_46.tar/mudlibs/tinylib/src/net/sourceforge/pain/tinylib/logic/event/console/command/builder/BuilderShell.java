package net.sourceforge.pain.tinylib.logic.event.console.command.builder;

import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.event.console.command.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.util.*;

import java.util.*;

/**
 * PAiN  Date: 05.06.2003  Time: 0:57:23
 */
public final class BuilderShell extends GrantedCommand {

    private static final String[] parsedCommand = new String[2];

    Builder builder = null;
    BuilderCommand activeCommand;

    public void processCommand() throws Exception {
        if (console.isCommandMode()) {
            builder = (Builder) player.getRole(Builder.class);
            if (builder != null) {
                showBuilderGreatings();
                showBuilderPrompt();
                Log.debug("BUILD_PROCESSOR:setting console to raw mode!");
                console.setRawMode(this);
            } else {
                processNotAccessible();
            }
        } else if (activeCommand != null) {
            processSubCommand();
        } else {
            String line = console.popInputLine();
            if (line.length() == 0) {
                showBuilderPrompt();
            } else if (line.equals("@")) {
                console.setCommandMode();
            } else {
                try {
                    processBuildCommand(line);
                } catch (Exception e) {
                    Log.error(e);
                    MessageOutFn.outln(console, FormatUtils.formatStacktrace(e));
                    throw e; // should rethrow to rollback changes since we do not create internal subtransaction
                }
                if (activeCommand == null) {
                    showBuilderPrompt();
                }
            }

        }
    }

    private void processSubCommand() throws Exception {
        try {
            activeCommand.processBuilderCommand(this, console.popInputLine());
        } catch (Exception e) {
            activeCommand = null;
            MessageOutFn.outln(console, FormatUtils.formatStacktrace(e));
            throw e;
        } finally {
            if (activeCommand == null) {
                showBuilderPrompt();
            }
        }
    }

    private void processBuildCommand(String line) throws Exception {
        ConsoleInputEvent.parseCommand(line, parsedCommand);
        String command = parsedCommand[0];
        String args = parsedCommand[1];
        Class builderCommandClass = null;

        Log.debug("BUILD_PROCESSOR: command:" + command);
        String className = commandNameToClassName(command);
        Log.debug("BUILD_PROCESSOR: commandNameToClassName" + className);
        try {
            builderCommandClass = Class.forName(className);
        } catch (ClassNotFoundException e) {
            Log.warn("Build command not found:" + command);
        }
        if (builderCommandClass == null) {
            MessageOutFn.outln(console, "ERROR:Unknown builder command\n");
        } else {
            BuilderCommand bcommand = (BuilderCommand) builderCommandClass.newInstance();
            bcommand.processBuilderCommand(this, args);
        }

    }

    static String commandNameToClassName(String command) {
        return "net.sourceforge.pain.tinylib.logic.event.console.command.builder.BC_" + Utils.formatName(command);
    }

    private void showBuilderPrompt() {
        java.util.List pList = builder.getEditedPrototypesList();
        int pListSize = pList.size();
        MessageOutFn.out(console, "\n{c");
        if (pListSize == 0) {
            MessageOutFn.out(console, "[builder:no active prototypes]");
        } else {
            Prototype pr = builder.getEditedRole();
            if (pr == null) {
                MessageOutFn.out(console, "[builder: no active roles, prototypes in list:" + pListSize + "]");
            } else {
                PrototypeInfo pi = (PrototypeInfo) pr.getRole(PrototypeInfo.class);
                MessageOutFn.out(console, "[builder:" + pi.getVnum() + ":" + pi.getName() + "]");
                MessageOutFn.out(console, "[" + ClassUtils.classNameWithoutPackage(pr.getClass()) + "]");
            }
        }
        MessageOutFn.out(console, (activeCommand == null ? "-" : activeCommand.getName()) + ">");
        MessageOutFn.out(console, "{x");
    }

    private void showBuilderGreatings() {
        MessageOutFn.outln(console, ">> Builder mode enabled!");
    }

    void setActiveCommand(BuilderCommand command) {
        activeCommand = command;
        if (activeCommand == null) {
            showBuilderPrompt();
        }
    }

    public void showHelp() {
        MessageOutFn.outln(console, command.name + ": enables the builder mode");
    }

    public void onGrantAdded() throws Exception {
        player.addRole(Builder.class);
    }

    public void onGrantRemoved() throws Exception {
        player.removeRole(Builder.class);
    }

    static void showAreasList(BuilderShell p) {
        MessageOutFn.outln(p.console, "Areas list:");
        StringBuffer buf = new StringBuffer();
        ArrayList list = new ArrayList();
        final Map areasByName = Mudlib.getWorld().getAreasByName();
        list.addAll(areasByName.keySet());
        Collections.sort(list);
        for (int i = 0; i < list.size(); i++) {
            String name = (String) list.get(i);
            Area area = (Area) areasByName.get(name);
            buf.append(name + ":\t" + area.getAreaDesc());
        }
        new MoreShell().run(p.console, buf.toString());
    }
}
