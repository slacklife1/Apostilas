package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;


public final class ShowCommandTag extends CommandHandler {

    public void processCommand() throws Exception {
        MessageOutFn.outln(console, command.tag);
    }

}
