package net.sourceforge.pain.tinylib.plugin.social;


public final class SocialEntry {

    public static final int FOUND_CHAR = 0;
    public static final int FOUND_NOVICT = 1;
    public static final int FOUND_VICT = 2;
    public static final int NOT_FOUND_CHAR = 3;
    public static final int NOARG_CHAR = 4;
    public static final int NOARG_ROOM = 5;
    public static final int SELF_CHAR = 6;
    public static final int SELF_SPACE = 7;

    public String[] template = new String[8];
    public String tag;

}
