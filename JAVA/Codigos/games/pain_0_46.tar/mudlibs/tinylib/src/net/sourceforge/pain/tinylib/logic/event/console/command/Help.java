/*
 * Created by IntelliJ IDEA.
 * User: fmike
 * Date: 22.06.2003
 * Time: 2:11:51
 */
package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.*;
import net.sourceforge.pain.tinylib.logic.event.console.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.plugin.command.*;

import java.util.*;

public final class Help extends CommandHandler {

    public void processCommand() throws Exception {
        String commandName = commandParams;
        if (commandName == null || commandName.trim().length() == 0) {
            showHelp();
        } else {
            commandName = commandName.toLowerCase();
            CommandHandler commandHandler = ConsoleInputEvent.getCommandHandler(commandName, console);
            if (commandHandler == null || commandHandler.getClass() == ShowCommandTag.class) {
                MessageOutFn.outln(console, "Command not found:{c" + commandName + "{x");
                if (commandName.length() > 1) {
                    showHint(commandName);
                }
            } else if (!commandHandler.isAccessible()) {
                MessageOutFn.outln(console, "Command not accessible:{c" + commandHandler.command.name + "{x");
            } else {
                MessageOutFn.outln(console, "HELP on command: {C" + commandHandler.command.name + "{x");
                commandHandler.showHelp();
                MessageOutFn.outln(console, "");
            }
        }
    }

    private void showHint(String commandName) {
        commandName = commandName.substring(0, 1);
        List commands = new ArrayList();
        for (Iterator it = ConsoleInputEvent.getCommandMapper().getCommands().iterator(); it.hasNext();) {
            TextCommand command = (TextCommand) it.next();
            if (!command.name.startsWith(commandName)) {
                continue;
            }
            if (command.commandClassName.endsWith("ShowCommandTag") || command.commandClassName.endsWith("SocialHandler")) {
                continue;
            }
            commands.add(command);
        }
        if (!commands.isEmpty()) {
            showCommandList(commandName, commands);
        }
    }

    private void showCommandList(String commandName, List commands) {
        MessageOutFn.outln(console, "Available commands (without socials) by mask:{c" + commandName + "*{x");
        for (Iterator it = commands.iterator(); it.hasNext();) {
            TextCommand textCommand = (TextCommand) it.next();
            MessageOutFn.outln(console, textCommand.name);
        }
    }

    public void showHelp() {
        MessageOutFn.outln(console, "This command shows a help for any console command.");
        MessageOutFn.outln(console, "Usage: help <command_name>");
        MessageOutFn.outln(console, "Available commands (without socials):");
        final CommandMapper commandMapper = ((CommandMapper) (Codebase.getPluginManager().getPlugin("command.CommandMapper")));
        ArrayList list = new ArrayList(200);
        for (Iterator it = commandMapper.getCommands().iterator(); it.hasNext();) {
            TextCommand command = (TextCommand) it.next();
            final String commandClassName = command.commandClassName;
            if (commandClassName.endsWith("ShowCommandTag")) {
                continue; // this is not a command
            }
            if (commandClassName.endsWith("SocialHandler")) {
                continue; // too many socials to show
            }
//			if (rejectedCommands.contains(commandClassName)) {
//				continue; // command is rejected to user
//			}
            list.add(command.name);

        }
        Collections.sort(list);
        StringBuffer sb = new StringBuffer(list.size() * 8);
        for (Iterator it = list.iterator(); it.hasNext();) {
            sb.append(it.next()).append('\n');
        }
        new MoreShell().run(console, sb.toString());
    }

}