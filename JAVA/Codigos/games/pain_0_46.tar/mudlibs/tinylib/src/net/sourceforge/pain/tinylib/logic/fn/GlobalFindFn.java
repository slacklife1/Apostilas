package net.sourceforge.pain.tinylib.logic.fn;


import net.sourceforge.pain.*;
import net.sourceforge.pain.data.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;

import java.util.*;


public final class GlobalFindFn {

    private GlobalFindFn() {
    }

    /**
     * Looks for active and not active players by exact login matching
     */
    public static Player findPlayerByName(String name) {
        if (name == null) {
            return null;
        }
        name = name.toLowerCase();
        return (Player) Mudlib.getWorld().getPlayersByLoginMap().get(name);
    }

    /**
     * Looks for active player by exact login matching
     */

    public static Player findActivePlayerByName(String name) {
        if (name == null) {
            return null;
        }
        name = name.toLowerCase();
        Player p = (Player) Mudlib.getWorld().getPlayersByLoginMap().get(name);
        if (p == null || p.getPrevActivePlayer() == null) { // logged out (prev is never null (circular))
            return null;
        }
        return p;
    }

    public static Interactive findInteractiveByPrefix(Role actor, String prefix) {
        if (prefix == null || prefix.length() == 0) {
            return null;
        }
        prefix = prefix.toLowerCase();
        if (prefix.equals("self")) {
            Interactive i = (Interactive) actor.getRole(Interactive.class);
            if (i != null) {
                return i;
            }
        }
        Player p = findActivePlayerByName(prefix);
        if (p != null) {
            return p.asInteractive();
        }

        String mostSimilarName = null;
        Interactive result = null;
        Player resPlayer = null;
        for (Iterator it = Codebase.getDB().getDbClass(Interactive.class).extentIterator(); it.hasNext();) {
            Interactive i = (Interactive) it.next();
            String inames[] = i.getTargetList();
            for (int j = 0; j < inames.length; j++) {
                String checkedName = inames[j];
                if (checkedName.startsWith(prefix)) {
                    if (checkedName.length() == prefix.length()) {
                        return i; // found exact
                    }
                    if (mostSimilarName == null) {
                        mostSimilarName = checkedName;
                        result = i;
                        continue;
                    } else {
                        if (Utils.isCloserTo(prefix, checkedName, mostSimilarName)) {
                            Player checkedPlayer = (Player) i.getRole(Player.class);
                            if (resPlayer != null && checkedPlayer == null) {
                                // nothing to do, players has priority in global search
                            } else {
                                mostSimilarName = checkedName;
                                result = i;
                                resPlayer = checkedPlayer;
                            }
                        }
                    }
                }
            }
        }
        return result;
    }

}
