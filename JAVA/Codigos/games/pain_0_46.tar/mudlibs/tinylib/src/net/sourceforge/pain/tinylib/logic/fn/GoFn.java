package net.sourceforge.pain.tinylib.logic.fn;

import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.util.*;

public class GoFn implements RelocationErrors {
    public static void go(Creature mob, int direction, boolean affectMoves) {
        final Located located = mob.asLocated();
        MoveFn.checkCanMove(located, direction);
        int moveCost = ((Room) located.getLocation().getRole(Room.class)).getExit(direction).getMoveCost();
        int movesPoints = mob.getMoves();
        if (affectMoves && moveCost > movesPoints) {
            throw new LogicException(ERR_MOVE_NOT_ENOUGH_MOVE_POINTS, "Not enough go points");
        }
        MessageOutFn.outSpace(mob, "$n leaves $T", mob, LangUtil.directionName(direction));
        MoveFn.move(located, direction);
        //ok move is done
        if (affectMoves) {
            mob.setMoves(movesPoints - moveCost);
        }
        ShowFn.showSpace(mob.asReceptive(),  mob.asLocated().getLocation());
        MessageOutFn.outSpace(mob, "$n arrives", mob);

    }
}
