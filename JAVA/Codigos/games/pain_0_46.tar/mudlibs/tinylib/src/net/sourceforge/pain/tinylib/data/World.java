package net.sourceforge.pain.tinylib.data;


import net.sourceforge.pain.data.*;
import net.sourceforge.pain.db.*;
import net.sourceforge.pain.tinylib.data.type.*;

import java.util.*;


public final class World extends DbObject {

    private static final int NAME = 0;
    private static final int PROTOTYPES_BY_VNUM = 1;
    private static final int RACES = 2;
    private static final int ROOMS_BY_VNUM = 3;
    private static final int FIRST_ACTIVE_PLAYER = 4;
    private static final int AREAS_BY_NAME = 5;
    private static final int PLAYERS_QUIT_SPACE = 6;
    private static final int DEFAULT_BIRTH_SPACE = 7;
    private static final int PLAYERS_BY_LOGIN = 8;
    private static final int SITE_BANS = 9;
    private static final int NFIELDS = 10;

    public World() {
    }

    public World(PainDB db) throws Exception {
        super(db);
        final Space quitSpace = (Space) ObjectFactory.createRaw(Space.class);
        quitSpace.setCapacity(Integer.MAX_VALUE);
        quitSpace.setDesc("quit space");
        quitSpace.setName("quit space");
        setReference(PLAYERS_QUIT_SPACE, quitSpace);
    }

    public static DbClassSchema provideSchema() {
        byte types[] = new byte[NFIELDS];
        String names[] = new String[NFIELDS];

        types[NAME] = DbType.STRING;
        names[NAME] = "name";

        types[PROTOTYPES_BY_VNUM] = DbType.SEPARATELY_SAVED_STRING_KEY_MAP;
        names[PROTOTYPES_BY_VNUM] = "prototypes_by_vnum";

        types[ROOMS_BY_VNUM] = DbType.SEPARATELY_SAVED_STRING_KEY_MAP;
        names[ROOMS_BY_VNUM] = "rooms_by_vnum";

        types[RACES] = DbType.SEPARATELY_SAVED_REFERENCE_SET;
        names[RACES] = "races";

        types[FIRST_ACTIVE_PLAYER] = DbType.REFERENCE;
        names[FIRST_ACTIVE_PLAYER] = "first_active_player";

        types[AREAS_BY_NAME] = DbType.SEPARATELY_SAVED_STRING_KEY_MAP;
        names[AREAS_BY_NAME] = "area_by_name";

        types[PLAYERS_QUIT_SPACE] = DbType.REFERENCE;
        names[PLAYERS_QUIT_SPACE] = "players_quit_space";

        types[DEFAULT_BIRTH_SPACE] = DbType.REFERENCE;
        names[DEFAULT_BIRTH_SPACE] = "default_birth_space";

        types[PLAYERS_BY_LOGIN] = DbType.SEPARATELY_SAVED_STRING_KEY_MAP;
        names[PLAYERS_BY_LOGIN] = "players_by_login";

        types[SITE_BANS] = DbType.SEPARATELY_SAVED_STRING_KEY_MAP;
        names[SITE_BANS] = "sites_bans";

        return new DbClassSchema(types, names);
    }

    public void setName(String name) {
        setString(NAME, name);
    }

    public String getName() {
        return getString(NAME);
    }

    public Player getFirstActivePlayer() {
        return (Player) getReference(FIRST_ACTIVE_PLAYER);
    }

    public void setFirstActivePlayer(Player p) {
        setReference(FIRST_ACTIVE_PLAYER, p);
    }

    public Map getPrototypesByVnumMap() {
        return getStringKeyMap(PROTOTYPES_BY_VNUM);
    }

    public Map getRoomsByIdMap() {
        return getStringKeyMap(ROOMS_BY_VNUM);
    }

    public Set getRaces() {
        return getRefSet(RACES);
    }

    public Space getPlayersQuitSpace() {
        return (Space) getReference(PLAYERS_QUIT_SPACE);
    }

    public Space getDefaultBirthSpace() {
        return (Space) getReference(DEFAULT_BIRTH_SPACE);
    }

    public void setDefaultBirthSpace(Space space) {
        setReference(DEFAULT_BIRTH_SPACE, space);
    }

    /**
     * keys: lowercase player names,
     * values: Player class instances
     */
    public Map getPlayersByLoginMap() {
        return getStringKeyMap(PLAYERS_BY_LOGIN);
    }


    public Map getAreasByName() {
        return getStringKeyMap(AREAS_BY_NAME);
    }

    public Map getSiteBans() {
        return getStringKeyMap(SITE_BANS);
    }
}


