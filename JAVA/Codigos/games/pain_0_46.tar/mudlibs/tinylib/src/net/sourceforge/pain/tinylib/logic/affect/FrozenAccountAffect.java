package net.sourceforge.pain.tinylib.logic.affect;

import net.sourceforge.pain.*;
import net.sourceforge.pain.data.*;
import net.sourceforge.pain.logic.*;
import net.sourceforge.pain.tinylib.data.affect.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

/**
 * Player with a frozen account is not able to login
 * <p/>
 * Codebase require from all affect controllers (Affect subclasses) to have constructor with (AffectData d) param.
 * this constructor is used for automatically affect controller instantiation and initialization with
 * persistent image
 */
public class FrozenAccountAffect extends Affect {


    /**
     * this constructor is required by codebase
     */
    public FrozenAccountAffect(AffectData ad) {
        super(ad);
    }

    public static void applyToObject(String adminName, Player victim, String reason) throws Exception {
        if (adminName == null) {
            throw new NullPointerException("adminName should not be NULL!");
        }
        new FrozenAccountAffectData(Codebase.getDB(), adminName, victim, reason, FrozenAccountAffect.class, AffectType.AFFECT_FROZEN_ACCOUNT);
        MessageOutFn.outln(victim, "Your account has been frozen");//just an example
    }

    /**
     * user is allowed to cancel affect manualy
     */
    public static void cancelAffect(Player p) {
        AffectData ad = p.getAffectData(AffectType.AFFECT_FROZEN_ACCOUNT);
        ad.delete();
    }

}
