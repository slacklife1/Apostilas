package net.sourceforge.pain.tinylib.logic.event;

import net.sourceforge.pain.*;
import net.sourceforge.pain.data.*;
import net.sourceforge.pain.data.role.*;
import net.sourceforge.pain.db.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.util.*;

import java.util.*;

/**
 * PAiN  Date: 14.04.2003  Time: 0:38:36
 */
public class ResetEvent extends AbstractEvent {
    /**
     * warn: single thread model!
     */
    private static final Set tmp_passedSpaces = new HashSet();
    private final static String DEFAULT_RESET_MESSAGE = "The earth rumbles with the after affects of another experience gone away...";

    public Object execute(Object param) throws Exception {
        Area area = (Area) param;
        String resetMessage = area.getResetMessage();
        Log.debug("ResetPlugin:Making reset on " + area.getName());
        if (resetMessage == null) {
            resetMessage = DEFAULT_RESET_MESSAGE;
        }

        Set resets = area.getResets();
        PainDB db = Codebase.getDB();
        for (Iterator it = resets.iterator(); it.hasNext();) {
            final SpaceReset sr = (SpaceReset) it.next();
            final Space space = sr.getLocation();
            if (!tmp_passedSpaces.contains(space)) {
                tmp_passedSpaces.add(space);
                MessageOutFn.outSpace(space, resetMessage);
            }
            if (sr.getLastResettedObject() != null) {
                continue;
            }
            // single reset done in transaction.
            // it will not agget to others if fail.
            DbTransaction t = new DbTransaction() {
                public Object execute(Object[] params) throws Exception {
                    Prototype p = sr.getResettedPrototype();
                    final Role obj = ObjectFactory.createObject(p);
                    final Located l = (Located) obj.getRole(Located.class);
                    try {
                        RelocateFn.addToSpace(space, l);
                        sr.setLastResettedObject(obj);
                    } catch (LogicException e) {
                        if (e.errorCode == RelocationErrors.ERR_NOT_ENOUGH_TARGET_SPACE) {
                            //ok reset failed
                        } else {
                            Log.error("ResetEvent:Unexpected logic error, code" + e.errorCode);
                        }
                    }

                    return null;
                }
            };
            try {
                db.execute(t);
            } catch (Exception e) {
                Log.error("ResetPlugin: something wrong!", e);
            }
        }
        tmp_passedSpaces.clear();
        return param;
    }
}
