package net.sourceforge.pain.tinylib.logic.event.console.command;

import net.sourceforge.pain.*;
import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.affect.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.affect.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

import java.util.*;

public final class AccountFreeze extends GrantedCommand {

    public void processCommand() throws Exception {
        StringTokenizer st = new StringTokenizer(commandParams == null ? "" : commandParams);
        String target = st.hasMoreTokens() ? st.nextToken() : null;
        String reason = st.hasMoreTokens() ? st.nextToken("\n") : null;
        final boolean stopFreeze = "OFF".equals(command.tag);
        if (!stopFreeze && (reason == null || target == null)) {
            showHelp();
            return;
        }
        if (stopFreeze && target == null) {
            listFrozenAccounts();
            return;
        }
        if (target == null || target.length() == 0) {
            MessageOutFn.outln(console, stopFreeze ? "Remove freeze from whom?" : "Freeze whom?");
            return;
        }
        final Player victim = (Player) Mudlib.getWorld().getPlayersByLoginMap().get(target.toLowerCase());
        if (victim == null) {
            MessageOutFn.outln(console, "No player found with name:" + target);
            return;
        }
        if (stopFreeze) {
            if (!victim.isAffected(AffectType.AFFECT_FROZEN_ACCOUNT)) {
                MessageOutFn.outOne(victim, "$n account is not frozen.", victim);
            } else {
                FrozenAccountAffect.cancelAffect(victim);
                MessageOutFn.outln(player, "ACCOUNT FREEZE removed.");
            }
        } else {
            if (victim.isAffected(AffectType.AFFECT_IMMORTAL)) {
                MessageOutFn.outln(player, "Not on immortals.");
            } else if (victim.isAffected(AffectType.AFFECT_FROZEN_ACCOUNT)) {
                MessageOutFn.outln(player, "Account is already frozen.");
            } else {
                FrozenAccountAffect.applyToObject(player.getLogin(), victim, reason);
                MessageOutFn.outln(player, "ACCOUNT FREEZE set.");
            }
        }
    }

    private void listFrozenAccounts() {
        int n = 0;
        Iterator it = Codebase.getDB().extentIterator(FrozenAccountAffectData.class, true);
        if (it != null) {
            while (it.hasNext()) {
                FrozenAccountAffectData ad = (FrozenAccountAffectData) it.next();
                Player pl = (Player) ad.getAffectedRole();
                MessageOutFn.outln(console, pl.getLogin());
                n++;
            }
        }
        MessageOutFn.outln(console, "Total: " + n + " accounts");

    }

    public void showHelp() {
        final boolean stopFreeze = "OFF".equals(command.tag);
        if (stopFreeze) {
            MessageOutFn.outln(console, command.name + ": removes accountoff flag and allows player to login");
            MessageOutFn.outln(console, "Usage: " + command.name + " <player_name>");
        } else {
            MessageOutFn.outln(console, command.name + ": disallows affect player to login");
            MessageOutFn.outln(console, "Usage: " + command.name + " <player_name> <reason>");
        }
    }
}
