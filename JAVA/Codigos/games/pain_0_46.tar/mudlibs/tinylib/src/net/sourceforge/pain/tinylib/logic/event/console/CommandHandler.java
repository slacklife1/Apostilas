package net.sourceforge.pain.tinylib.logic.event.console;

import net.sourceforge.pain.tinylib.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.*;
import net.sourceforge.pain.tinylib.plugin.command.*;

/**
 * Abstract class for any console command impl
 * User: fmike  Date: Jan 16, 2003  Time: 4:16:04 AM
 */
public abstract class CommandHandler {

    public TextCommand command;
    public Console console;
    public Player player;
    public String commandParams;

    public abstract void processCommand() throws Exception;

    /**
     * default Impl. Sould be overriden
     */
    public void showHelp() {
        MessageOutFn.outln(console, "no help found for " + command.name + "\n");
    }

    /**
     * called if command is not accessible by player  (lack of skill...)
     * default impl. Any specific command is allowed to everride this method
     */
    public void processNotAccessible() {
        ConsoleInputEvent.processFailedCommand(console);
    }


    /**
     * checks is command accessible for player.
     * automatically called before processCommand method call
     * By default checks player rejection command list.
     * Should be overriden in subclass to add more conditions.
     * Implementation should not do anything except accessibility checking
     */
    public boolean isAccessible() {
        return !player.getRejectedCommands().contains(command.commandClassName);
    }

}
