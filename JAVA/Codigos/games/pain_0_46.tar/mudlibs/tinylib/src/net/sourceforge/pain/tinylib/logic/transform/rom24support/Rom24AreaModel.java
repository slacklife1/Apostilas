package net.sourceforge.pain.tinylib.logic.transform.rom24support;

import java.util.*;

/**
 * User: fmike  Date: Mar 20, 2004  Time: 1:28:38 AM
 */
public class Rom24AreaModel {

    protected static String defaultDamType = "beating";
    protected String fileName = null;
    protected StringBuffer tmpBuffer = new StringBuffer();
    public String areaName;
    public String areaAuthor;
    public String levelRange;
    public String vnumRange;
    public String resetMessage;
    public String flags;
    public HashMap rooms = new HashMap();
    public HashMap mobiles = new HashMap();
    public HashMap objects = new HashMap();

}
