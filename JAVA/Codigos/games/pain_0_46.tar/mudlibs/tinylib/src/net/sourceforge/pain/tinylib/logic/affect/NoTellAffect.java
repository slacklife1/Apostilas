package net.sourceforge.pain.tinylib.logic.affect;

import net.sourceforge.pain.*;
import net.sourceforge.pain.data.*;
import net.sourceforge.pain.logic.*;
import net.sourceforge.pain.tinylib.data.type.*;
import net.sourceforge.pain.tinylib.logic.fn.*;

/**
 * NoTell Affect
 * <p/>
 * Codebase require from all affect controllers (Affect subclasses) to have constructor with (AffectData d) param.
 * this constructor is used for automatically affect controller instantiation and initialization with
 * persistent image
 */
public class NoTellAffect extends Affect {


    /**
     * this constructor is required by codebase
     */
    public NoTellAffect(AffectData ad) {
        super(ad);
    }

    public static void applyToObject(Interactive inter) throws Exception {
        new AffectData(Codebase.getDB(), inter, NoTellAffect.class, AffectType.AFFECT_NOTELL);
        MessageOutFn.outln(inter, "You can't tell anymore");//just an example
    }

    /**
     * user is allowed to cancel affect manualy
     */
    public static void cancelAffect(Creature mob) {
        AffectData ad = mob.getAffectData(AffectType.AFFECT_NOTELL);
        ad.delete();
        MessageOutFn.outln(mob, "You can tell now");//just an example
    }

}
