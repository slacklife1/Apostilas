package net.sourceforge.pain.guitool;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

/**
 * User: fmike  Date: Jun 12, 2004  Time: 7:59:34 PM
 */
public class GTWorkspace implements GTModuleLoadingListener {
    private JTabbedPane tabbedpane;
    private List items = new ArrayList();
    private JPopupMenu tabPopupMenu = new JPopupMenu();

    public GTWorkspace() {
        tabbedpane = new JTabbedPane();
        tabbedpane.setTabPlacement(JTabbedPane.BOTTOM);
        GUITool.addModuleLoadingListener(this);
        bindActions();

    }

    private void bindActions() {
        InputMap map = tabbedpane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        map.put(KeyStroke.getKeyStroke(KeyEvent.VK_F4, InputEvent.CTRL_MASK), "closeTab");
        map.put(KeyStroke.getKeyStroke(KeyEvent.VK_W, InputEvent.CTRL_MASK), "closeTab");
        final CloseTabAction closeAction = new CloseTabAction();
        tabbedpane.getActionMap().put("closeTab", closeAction);
        tabbedpane.addMouseListener(new TabMouseAdapter());
        tabPopupMenu.add(closeAction);
    }

    Component getComponent() {
        return tabbedpane;
    }

    public void addWorkspaceItem(GTWorkspaceItem item) {
        String name = item.getDisplayName();
        Component c = item.getComponent();
        Component[] components = tabbedpane.getComponents();
        for (int i = 0; i < components.length; i++) {
            Component component = components[i];
            if (c == component) {
                tabbedpane.setSelectedComponent(c);
                return;
            }
        }
        tabbedpane.add(name, c);
        tabbedpane.setSelectedComponent(c);
        items.add(item);
    }

    public void removeWorkspaceItem(GTWorkspaceItem item) {
        final Component c = item.getComponent();
        try {
            item.onClosing();
        } catch (Exception e) {
            GTErrorDialog.showError(e);
        }
        tabbedpane.remove(c);
    }


    public void onModuleLoaded(GTModule module) {
        //do nothing
    }

    public void onModuleUnloading(GTModule module) {
        for (Iterator it = items.iterator(); it.hasNext();) {
            final GTWorkspaceItem item = (GTWorkspaceItem) it.next();
            removeWorkspaceItem(item);
            it.remove();
        }
    }

    class CloseTabAction extends AbstractAction {
        public CloseTabAction() {
            super("Close");
        }

        public void actionPerformed(ActionEvent e) {
            Component c = tabbedpane.getSelectedComponent();
            for (int i = 0; i < items.size(); i++) {
                GTWorkspaceItem item = (GTWorkspaceItem) items.get(i);
                if (item.getComponent() == c) {
                    removeWorkspaceItem(item);
                    return;
                }
            }
            GTErrorDialog.showError("CorrespondingWorkspace item was not found for closing component!");
            tabbedpane.remove(c);
        }
    }

    private class TabMouseAdapter extends MouseAdapter {
        public void mouseClicked(MouseEvent e) {
            if (e.getClickCount() == 1 && e.getButton() == MouseEvent.BUTTON3) {
                Point clickPoint = e.getPoint();
                for (int i = 0; i < tabbedpane.getTabCount(); i++) {
                    if (tabbedpane.getUI().getTabBounds(tabbedpane, i).contains(clickPoint)) {
                        tabPopupMenu.show(tabbedpane.getComponentAt(i), e.getX(), e.getY());
                        return;
                    }
                }
            }
        }
    }

}
