package net.sourceforge.pain.guitool;

import java.awt.*;

/**
 * User: fmike  Date: Jun 12, 2004  Time: 8:17:42 PM
 */
public class GTLauncher {
    private static String logo = "/net/sourceforge/pain/guitool/Splash.jpg";

    public static void main(String[] args) {
        GUITool.appFrame = new GTApplicationFrame(GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration());
        GUITool.appFrame.go(logo);
    }

}
