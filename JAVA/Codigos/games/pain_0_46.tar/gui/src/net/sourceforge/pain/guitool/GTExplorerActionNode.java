package net.sourceforge.pain.guitool;

import javax.swing.*;
import java.util.*;

/**
 *
 */
public abstract class GTExplorerActionNode extends AbstractAction {

    protected GTExplorerActionNode() {
    }

    protected GTExplorerActionNode(String name) {
        super(name);
    }

    protected GTExplorerActionNode(String name, Icon icon) {
        super(name, icon);
    }


    public abstract List getChildNodes();

}
