package net.sourceforge.pain.guitool;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

class GTApplicationFrame extends JFrame {
    private static final int PREFERRED_WIDTH = 720;
    private static final int PREFERRED_HEIGHT = 600;

    GTMainMenu mainMenu;
    GTMainPanel mainPanel;
    GTStatusBar statusBar;

    private JPanel appPanel;
    private JWindow splashScreen;
    private JLabel splashLabel;


    public GTApplicationFrame(GraphicsConfiguration grc) {
        super(grc);
    }

    void go(String splashImage) {
        createSplashScreen(splashImage);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                if (!GUITool.exiting) {
                    GUITool.exit(0);
                }
            }

        });
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                if (splashScreen != null) {
                    splashScreen.show();
                }
            }
        });
        initialize();
        loadModules();
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                showAppFrame();
                hideSplash();
            }
        });
    }

    private void loadModules() {
        GTModuleLoader.onAppStartup();
    }

    private void initialize() {
        appPanel = new JPanel();
        appPanel.setPreferredSize(new Dimension(PREFERRED_WIDTH, PREFERRED_HEIGHT));
        appPanel.setLayout(new BorderLayout());

        JPanel top = new JPanel();
        top.setLayout(new BorderLayout());
        appPanel.add(top, BorderLayout.NORTH);

        mainMenu = new GTMainMenu();
        top.add(mainMenu.menuBar, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new BorderLayout());
        appPanel.add(centerPanel, BorderLayout.CENTER);

        statusBar = new GTStatusBar();
        appPanel.add(statusBar, BorderLayout.SOUTH);

        mainPanel = new GTMainPanel();
        centerPanel.add(mainPanel, BorderLayout.CENTER);

        getContentPane().add(appPanel, BorderLayout.CENTER);
    }

    public void createSplashScreen(String imageName) {
        try {
            splashLabel = new JLabel(loadImage(imageName));
            splashScreen = new JWindow(this);
            splashScreen.getContentPane().add(splashLabel);
            splashScreen.pack();
            Rectangle screenRect = getGraphicsConfiguration().getBounds();
            splashScreen.setLocation(screenRect.x + screenRect.width / 2 - splashScreen.getSize().width / 2,
                    screenRect.y + screenRect.height / 2 - splashScreen.getSize().height / 2);
        } catch (IOException e) {
            //ignore
        }

    }

    public void hideSplash() {
        if (splashScreen != null) {
            splashScreen.setVisible(false);
        }
        splashScreen = null;
        splashLabel = null;

    }


    public void showAppFrame() {
        // put management in a frame and show it
        setTitle("PAiN Management Tool");

        pack();

        Rectangle screenRect = getGraphicsConfiguration().getBounds();
        Insets screenInsets = Toolkit.getDefaultToolkit().getScreenInsets(getGraphicsConfiguration());

        // Make sure we don't place the demo off the screen.
        int centerWidth = screenRect.width < getSize().width ?
                screenRect.x :
                screenRect.x + screenRect.width / 2 - getSize().width / 2;
        int centerHeight = screenRect.height < getSize().height ?
                screenRect.y :
                screenRect.y + screenRect.height / 2 - getSize().height / 2;

        centerHeight = centerHeight < screenInsets.top ?
                screenInsets.top : centerHeight;

        setLocation(centerWidth, centerHeight);


//        workspacePanel.vSplitPane.setDividerLocation(5/6D);
        mainPanel.hSplitPane.setDividerLocation(mainPanel.hSplitPane.getResizeWeight());
        mainPanel.vSplitPane.setDividerLocation(mainPanel.vSplitPane.getResizeWeight());
        show();
    }


    private static ImageIcon loadImage(String imagePath) throws IOException {
        final byte[] resource = GUITool.readResource(GUITool.class, imagePath);
        return new ImageIcon(resource);
    }

}
