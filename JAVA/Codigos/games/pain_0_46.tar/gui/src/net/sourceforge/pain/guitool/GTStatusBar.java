package net.sourceforge.pain.guitool;

import javax.swing.*;
import java.awt.*;


class GTStatusBar extends JPanel implements GTConnectionStateListener {
    //  Message | State: Disconnected
    JLabel message;
    JLabel connectStatus;

    public GTStatusBar() {
        setLayout(new GridLayout(1, 2));
        message = new JLabel();
        message.setBorder(BorderFactory.createEtchedBorder());

        connectStatus = new JLabel();
        connectStatus.setBorder(BorderFactory.createEtchedBorder());
        connectStatus.setHorizontalAlignment(SwingConstants.RIGHT);

        add(message);
        add(connectStatus);

        setConnected(false);
        GTMessenger.addConnectionStateListener(this);
    }

    public void setContextMessage(String m) {
        message.setText(m);
    }


    public void onConnectionStateChanged(boolean connected) {
        setConnected(connected);
    }

    private void setConnected(boolean connected) {
        connectStatus.setText(connected ? "Connected" : "Disconnected");
    }

}
