package net.sourceforge.pain.guitool;

import java.awt.*;

/**
 * User: fmike  Date: Jun 12, 2004  Time: 8:01:15 PM
 */
public interface GTWorkspaceItem {

    String getDisplayName();

    Component getComponent();

    void onClosing();

    GTModule getOwnerModule();
}
