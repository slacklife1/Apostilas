package net.sourceforge.pain.guitool;

import java.io.*;

/**
 * Some IO methods used from number of classes.
 */
public class GTIOUtils {
    public static byte[] readAllFromStream(InputStream is) throws IOException {
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        try {
            int b;
            while ((b = is.read()) != -1) {
                os.write(b);
            }
            byte[] buf = os.toByteArray();
            return buf;
        } finally {
            os.close();
        }
    }
}
