package net.sourceforge.pain.guitool;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

class GTMainPanel extends JPanel {
    public final GTExplorer explorer;
    public final GTWorkspace workSpace;
    public final GTLogPanel logPanel;

    JSplitPane hSplitPane;
    JSplitPane vSplitPane;

    public GTMainPanel() {
        explorer = new GTExplorer();
        logPanel = new GTLogPanel();
        workSpace = new GTWorkspace();

        GUITool.addModuleLoadingListener(explorer);
        
        vSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, workSpace.getComponent(), logPanel);
        vSplitPane.setContinuousLayout(true);
        vSplitPane.setOneTouchExpandable(true);
        vSplitPane.setBorder(new EtchedBorder());
        vSplitPane.setResizeWeight(5 / 6D);
        vSplitPane.setDividerSize(9);

        hSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, explorer.getComponent(), vSplitPane);
        hSplitPane.setContinuousLayout(true);
        hSplitPane.setOneTouchExpandable(true);
        hSplitPane.setResizeWeight(1 / 4D);
        hSplitPane.setDividerSize(9);

        setLayout(new BorderLayout());
        add(hSplitPane, BorderLayout.CENTER);

        setBackground(Color.black);
    }
}

