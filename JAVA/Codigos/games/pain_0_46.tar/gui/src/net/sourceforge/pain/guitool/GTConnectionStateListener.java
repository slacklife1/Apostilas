package net.sourceforge.pain.guitool;

/**
 * User: fmike  Date: Jun 12, 2004  Time: 8:42:52 PM
 */
public interface GTConnectionStateListener {
    void onConnectionStateChanged(boolean connected);
}
