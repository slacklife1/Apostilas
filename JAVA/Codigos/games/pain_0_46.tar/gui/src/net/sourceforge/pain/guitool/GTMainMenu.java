package net.sourceforge.pain.guitool;

import javax.swing.*;
import java.awt.event.*;
import java.util.*;

/**
 * User: fmike  Date: Jun 13, 2004  Time: 1:23:03 AM
 */
class GTMainMenu implements GTModuleLoadingListener {
    JMenuBar menuBar;
    private ServerMenu serverMenu;
    private final HashMap modulesMenu = new HashMap();

    public GTMainMenu() {
        menuBar = new JMenuBar();
        serverMenu = new ServerMenu();
        GTMessenger.addConnectionStateListener(serverMenu);
        GUITool.addModuleLoadingListener(this);
        menuBar.add(serverMenu.menu);
    }


    public void onModuleLoaded(GTModule module) {
        JMenu menu = module.getMainMenuItems();
        if (menu != null) {
            modulesMenu.put(module.getModuleInfo().name, menu);
            menuBar.setVisible(false);
            menuBar.add(menu);
            menuBar.setVisible(true);

        }
    }

    public void onModuleUnloading(GTModule module) {
        JMenu menu = (JMenu) modulesMenu.remove(module.getModuleInfo().name);
        if (menu != null) {
            menuBar.remove(menu);
            menuBar.repaint();
        }
    }


    private static class ServerMenu implements GTConnectionStateListener {
        JMenu menu;
        JMenuItem connectItem;
        JMenuItem disconnectItem;
        JMenuItem modulesListItem;
        JMenuItem exitItem;

        public void onConnectionStateChanged(boolean connected) {
            connectItem.setEnabled(!connected);
            disconnectItem.setEnabled(connected);
        }

        public ServerMenu() {
            menu = new JMenu("Server");
            menu.setMnemonic('S');

            connectItem = new JMenuItem("Connect..");
            connectItem.setMnemonic('C');
            menu.add(connectItem);

            disconnectItem = new JMenuItem("Disconnect");
            disconnectItem.setMnemonic('D');
            menu.add(disconnectItem);
            disconnectItem.setEnabled(false);


            modulesListItem = new JMenuItem("Modules..");
            modulesListItem.setMnemonic('M');
            menu.add(modulesListItem);

            menu.addSeparator();

            exitItem = new JMenuItem("Exit");
            exitItem.setMnemonic('x');
            menu.add(exitItem);

            bindActions();

        }

        private void bindActions() {
            connectItem.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    GTMessenger.connect();
                }
            });

            disconnectItem.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    GTMessenger.disconnect();
                }
            });

            modulesListItem.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    new GTModulesLoadingDialog().show();
                }
            });

            exitItem.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    GUITool.exit(0);
                }
            });

        }
    }
}
