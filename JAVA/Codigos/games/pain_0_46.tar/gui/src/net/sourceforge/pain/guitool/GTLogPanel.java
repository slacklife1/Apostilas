package net.sourceforge.pain.guitool;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.text.*;
import java.util.*;

class GTLogPanel extends JScrollPane {

    final JTextArea logArea;
    final DateFormat timeFormat;


    public GTLogPanel() {
        logArea = new JTextArea();
        logArea.setLineWrap(false);
        logArea.setEditable(false);
        getViewport().add(logArea);
        timeFormat = SimpleDateFormat.getDateTimeInstance(SimpleDateFormat.SHORT, SimpleDateFormat.MEDIUM);
    }

    public void appendMessage(String message) {
        message = "[" + timeFormat.format(new Date()) + "] " + message + "\n";
        try {
            if (logArea.getLineCount() > 300) {
                int end = logArea.getLineEndOffset(50);
                logArea.setText(logArea.getText().substring(end));
            }
            logArea.append(message);
            final Rectangle aRect = logArea.modelToView(logArea.getText().length());
            if (aRect != null) {
                logArea.scrollRectToVisible(aRect);
            }
        } catch (BadLocationException e) {
            e.printStackTrace();
        }
    }
}
