package net.sourceforge.pain.guitool;

import net.sourceforge.pain.network.guitool.*;

import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import java.util.prefs.*;

public class GTMessenger {
    private static final HashSet listeners = new HashSet();
    private static GTClientConnection c;

    private GTMessenger() {
    }

    static void connect() {
        assert c == null;
        c = new GTConnectDialogController().connect();
        if (c != null) {
            notifyListeners(true);
            GUITool.log("connected");
        }
    }

    public static boolean isConnected() {
        return c != null;
    }


    public static void disconnect() {
        assert  c != null;
        c.close();
        c = null;
        notifyListeners(false);
        GUITool.log("disconnected");
    }

    public static void addConnectionStateListener(GTConnectionStateListener l) {
        listeners.add(l);

    }

    public static void removeConnectionStateListener(GTConnectionStateListener l) {
        listeners.remove(l);
    }

    public static synchronized GTNetPacket sendBlocking(GTNetPacket p) throws Exception {
        if (c == null) {
            connect();
        }
        return c.sendBlocking(p);
    }


    static void _onRemoteDisconnect() {
        c = null;
        notifyListeners(false);
    }

    private static void notifyListeners(boolean state) {
        for (Iterator it = listeners.iterator(); it.hasNext();) {
            try {
                GTConnectionStateListener listener = (GTConnectionStateListener) it.next();
                listener.onConnectionStateChanged(state);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    private static class GTConnectDialogController {
        private GTConnectDialog d;
        private GTClientConnection con;

        private String host;
        private int port;
        private String login;
        private String password;

        public GTClientConnection connect() {
            d = new GTConnectDialog(GUITool.appFrame);
            try {
                initDialog();
                d.show();
                d.dispose();
                d = null;
            } finally {
                d = null;
            }
            return con;
        }

        private void initDialog() {
            MyKeyListener kl = new MyKeyListener();
            d.hostField.addKeyListener(kl);
            d.portField.addKeyListener(kl);
            d.loginField.addKeyListener(kl);
            d.passwordField.addKeyListener(kl);
            d.connectButton.addKeyListener(kl);
            d.cancelButton.addKeyListener(kl);
            d.panel.addKeyListener(kl);

            initFields();

            MyButtonListener bl = new MyButtonListener();
            d.connectButton.addActionListener(bl);
            d.cancelButton.addActionListener(bl);
            d.setLocationRelativeTo(null);   //center of the screen
        }

        private boolean checkDialog() {
            host = d.hostField.getText().trim();
            if (host.length() == 0) {
                JOptionPane.showMessageDialog(d, "Empty host value", "Error", JOptionPane.ERROR_MESSAGE);
                d.hostField.requestFocus();
                return false;
            }
            try {
                port = Integer.parseInt(d.portField.getText().trim());
                if (port < 1 || port > Short.MAX_VALUE * 2) {
                    throw new Exception();
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(d, "Illegal port:" + d.portField.getText(), "Error", JOptionPane.ERROR_MESSAGE);
                d.portField.requestFocus();
                return false;
            }

            login = d.loginField.getText();
            if (login.length() < 3) {
                JOptionPane.showMessageDialog(d, "Illegal login:" + login, "Error", JOptionPane.ERROR_MESSAGE);
                d.loginField.requestFocus();
                return false;
            }
            char[] pass = d.passwordField.getPassword();
            if (pass.length == 0) {
                JOptionPane.showMessageDialog(d, "Password is empty!", "Error", JOptionPane.ERROR_MESSAGE);
                d.passwordField.requestFocus();
                return false;
            }
            password = new String(pass);

            return true;
        }

        private boolean _connect() {
            try {
                con = new GTClientConnection(host, port, login, password);
                storePreferences();
                return true;
            } catch (Exception e) {
                e.printStackTrace();
                if (con != null) {
                    con.close();
                }
                String failMessage = e.getMessage();
                JOptionPane.showMessageDialog(GUITool.appFrame, failMessage, "Connection error", JOptionPane.ERROR_MESSAGE);
                GUITool.statusMessage(failMessage);
                return false;
            }
        }

        private void storePreferences() {
            Preferences p = GUITool.coreSettings;
            p.put("HOST", host);
            p.putInt("PORT", port);
            p.put("LOGIN", login);
            p.put("PASSWORD", password);
            try {
                p.flush();
            } catch (BackingStoreException e) {
                e.printStackTrace();
            }
        }

        private class MyButtonListener implements ActionListener {
            public void actionPerformed(ActionEvent e) {
                final Object source = e.getSource();
                if (source == d.cancelButton) {
                    d.dispose();
                } else if (source == d.connectButton) {
                    if (checkDialog() && _connect()) {
                        d.dispose();
                    }
                }
            }
        }

        private class MyKeyListener implements KeyListener {
            boolean myPress = false;

            public void keyPressed(KeyEvent e) {
                myPress = true;
            }

            public void keyReleased(KeyEvent e) {
                if (myPress) {
                    myPress = false;
                    final int keyCode = e.getKeyCode();
                    if (keyCode == KeyEvent.VK_ESCAPE) {
                        e.consume();
                        d.hide();
                    } else if (keyCode == KeyEvent.VK_ENTER) {
                        e.consume();
                        if (checkDialog() && _connect()) {
                            d.hide();
                        }
                    }
                }
            }

            public void keyTyped(KeyEvent e) {
            }
        }


        private void initFields() {
            Preferences p = GUITool.coreSettings;
            d.hostField.setText(p.get("HOST", "127.0.0.1"));
            d.portField.setText("" + p.getInt("PORT", 5555));
            d.loginField.setText(p.get("LOGIN", "root"));
            d.passwordField.setText(p.get("PASSWORD", "root"));
        }

    }

}

