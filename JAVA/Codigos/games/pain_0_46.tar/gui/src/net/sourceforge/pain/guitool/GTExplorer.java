package net.sourceforge.pain.guitool;

import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

/**
 * User: fmike  Date: Jun 12, 2004  Time: 7:59:20 PM
 */
class GTExplorer implements GTModuleLoadingListener {
    private JTree tree;
    private DefaultTreeModel treeModel;
    private JPopupMenu treeLeafPopupMenu = new JPopupMenu();

    public GTExplorer() {
        treeModel = new DefaultTreeModel(new DefaultMutableTreeNode("GUITool Explorer"));
        tree = new JTree(treeModel);
        GUITool.addModuleLoadingListener(this);
        bindActions();
    }

    private void bindActions() {
        InputMap map = tree.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        map.put(KeyStroke.getKeyStroke((char) KeyEvent.VK_ENTER), "openAction");
        final OpenAction openAction = new OpenAction();
        tree.getActionMap().put("openAction", openAction);
        tree.addMouseListener(new TreeMouseAdapter());
        treeLeafPopupMenu.add(openAction);
    }


    public Component getComponent() {
        return tree;
    }

    public void onModuleLoaded(GTModule module) {
        List nodes = module.getExplorerActionNodes();
        if (nodes != null && !nodes.isEmpty()) {
            GTExplorerTreeNode node = new GTExplorerTreeNode(nodes);
            node.ownerModule = module;
            DefaultMutableTreeNode rootNode = (DefaultMutableTreeNode) treeModel.getRoot();
            rootNode.add(node);
            treeModel.reload();
            tree.expandPath(new TreePath(new Object[]{rootNode, node}));
        }
    }

    public void onModuleUnloading(GTModule module) {
        GTExplorerTreeNode moduleNode = null;
        final Enumeration enumeration = ((MutableTreeNode) treeModel.getRoot()).children();
        while (enumeration.hasMoreElements()) {
            GTExplorerTreeNode node = (GTExplorerTreeNode) enumeration.nextElement();
            if (node.ownerModule == module) {
                moduleNode = node;
                break;
            }
        }
        if (moduleNode != null) {
            treeModel.removeNodeFromParent(moduleNode);
        }
    }

    class GTExplorerTreeNode implements MutableTreeNode {
        Vector children;
        MutableTreeNode parent;
        GTExplorerActionNode actionNode;
        GTModule ownerModule;

        GTExplorerTreeNode(List actionNodes) {
            populateChildren(actionNodes);
        }

        GTExplorerTreeNode(GTExplorerTreeNode parent, GTExplorerActionNode actionNode) {
            this.parent = parent;
            this.actionNode = actionNode;
            populateChildren(actionNode.getChildNodes());
        }

        private void populateChildren(List actionNodes) {
            children = new Vector();
            if (actionNodes != null && actionNodes.size() > 0) {
                for (int i = 0; i < actionNodes.size(); i++) {
                    GTExplorerActionNode node = (GTExplorerActionNode) actionNodes.get(i);
                    children.add(new GTExplorerTreeNode(this, node));
                }
            }
        }

        public String toString() {
            return actionNode == null ? ownerModule.getModuleInfo().name : (String) actionNode.getValue(Action.NAME);
        }
        //tree node interface

        public int getChildCount() {
            return children.size();
        }

        public boolean getAllowsChildren() {
            return !children.isEmpty();
        }

        public boolean isLeaf() {
            return children.isEmpty();
        }

        public Enumeration children() {
            return children.elements();
        }

        public TreeNode getParent() {
            return parent;
        }

        public TreeNode getChildAt(int childIndex) {
            return (TreeNode) children.get(childIndex);
        }

        public int getIndex(TreeNode node) {
            return children.indexOf(node);
        }

        //mutable interface:

        public void removeFromParent() {
            parent.remove(this);
        }

        public void remove(int index) {
            children.remove(index);
        }

        public void setUserObject(Object object) {
            throw new UnsupportedOperationException();
        }

        public void remove(MutableTreeNode node) {
            children.remove(node);
        }

        public void setParent(MutableTreeNode newParent) {
            parent = (MutableTreeNode) newParent;
        }

        public void insert(MutableTreeNode child, int index) {
            children.insertElementAt(child, index);
        }
    }

    private void openActionOnNode(GTExplorerTreeNode node) {
        if (node.isLeaf()) {
            try {
                node.actionNode.actionPerformed(new ActionEvent(this, 0, "doubleClick"));
            } catch (Exception e1) {
                GTErrorDialog.showError(e1);
            }
        }
    }

    private class TreeMouseAdapter extends MouseAdapter {
        public void mouseClicked(MouseEvent e) {
            if (e.getClickCount() == 2 && e.getButton() == MouseEvent.BUTTON1) {
                TreePath path = tree.getPathForLocation(e.getX(), e.getY());
                if (path != null & path.getPathCount() > 1) {
                    GTExplorerTreeNode node = (GTExplorerTreeNode) path.getLastPathComponent();
                    openActionOnNode(node);
                }
            } else if (e.getClickCount() == 1 && e.getButton() == MouseEvent.BUTTON3) {
                TreePath path = tree.getPathForLocation(e.getX(), e.getY());
                if (path != null) {
                    tree.setSelectionPath(path);
                    if (path.getPathCount() > 1 && ((GTExplorerTreeNode) path.getLastPathComponent()).isLeaf()) {
                        treeLeafPopupMenu.show(tree, e.getX(), e.getY());
                    }
                }
            }
        }
    }

    class OpenAction extends AbstractAction {
        public OpenAction() {
            super("Open");
        }

        public void actionPerformed(ActionEvent e) {
            final TreePath selectionPath = tree.getSelectionPath();
            if (selectionPath != null && selectionPath.getPathCount() > 1) {
                GTExplorerTreeNode node = (GTExplorerTreeNode) selectionPath.getLastPathComponent();
                openActionOnNode(node);
            }
        }
    }
}
