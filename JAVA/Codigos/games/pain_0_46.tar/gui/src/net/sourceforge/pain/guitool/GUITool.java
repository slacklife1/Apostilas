package net.sourceforge.pain.guitool;

import java.io.*;
import java.util.*;
import java.util.prefs.*;


public class GUITool {
    public static GTApplicationFrame appFrame;

    static final Preferences coreSettings = Preferences.userNodeForPackage(GUITool.class);
    private static final HashSet listeners = new HashSet();

    private GUITool() {
    }

    /**
     * gui logging
     */
    public static void log(String message) {
        appFrame.mainPanel.logPanel.appendMessage(message);
    }

    public static void statusMessage(String message) {
        appFrame.statusBar.setContextMessage(message);
    }

    static void loadModule(GTModuleLoader loader) throws Exception {
        if (loader.isModuleLoaded()) {
            throw new RuntimeException("already loaded");
        }
        GTModule module;
        String name = loader.moduleInfo.name;
        log("Loading module: " + name);
        try {
            module = loader.loadModule();
        } catch (Exception e) {
            log("Module loading failed: " + name);
            throw e;
        }
        for (Iterator it = listeners.iterator(); it.hasNext();) {
            GTModuleLoadingListener listener = (GTModuleLoadingListener) it.next();
            try {
                listener.onModuleLoaded(module);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        log("Module loaded: " + name);
    }


    static void unloadModule(GTModuleLoader loader) {
        if (!loader.isModuleLoaded()) {
            throw new RuntimeException("module not loaded");
        }
        final String name = loader.moduleInfo.name;
        log("Unloading module: " + name);
        for (Iterator it = listeners.iterator(); it.hasNext();) {
            GTModuleLoadingListener listener = (GTModuleLoadingListener) it.next();
            try {
                listener.onModuleUnloading(loader.module);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        try {
            loader.unloadModule();
        } catch (Exception e) {
            e.printStackTrace();
        }
        log("Module unloaded: " + name);
    };


    public static void addModuleLoadingListener(GTModuleLoadingListener l) {
        listeners.add(l);
    }

    public static void removeModuleLoadingListener(GTModuleLoadingListener l) {
        listeners.remove(l);
    }

    static boolean exiting = false;

    public static void exit(int exitCode) {
        if (exiting) {
            throw new IllegalStateException("GUITool is already in exit process");
        }
        exiting = true;
        try {
            for (Iterator it = GTModuleLoader.getModules().iterator(); it.hasNext();) {
                GTModuleLoader l = (GTModuleLoader) it.next();
                if (l.isModuleLoaded()) {
                    try {
                        unloadModule(l);
                    } catch (Exception e) {
                        GTErrorDialog.showError(e);
                    }
                }
            }
        } catch (Exception e) {
            GTErrorDialog.showError(e);
        }
        try {
            if (GTMessenger.isConnected()) {
                GTMessenger.disconnect();
            }
        } catch (Exception e) {
            GTErrorDialog.showError(e);
        }
        if (appFrame.isDisplayable()) {
            appFrame.dispose();
        }
        try {
            coreSettings.flush();
        } catch (BackingStoreException e) {
            GTErrorDialog.showError(e);
        }
        System.exit(exitCode);
    }

    public static GTWorkspace getWorkspace() {
        return appFrame.mainPanel.workSpace;
    }


    public static byte[] readResource(Class clazz, String fileName) throws IOException {
        final InputStream is = clazz.getResourceAsStream(fileName);
        if (is == null) {
            return null;
        }
        try {
            return GTIOUtils.readAllFromStream(is);
        } finally {
            is.close();
        }
    }

}
