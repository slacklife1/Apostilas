package net.sourceforge.pain.guitool;

import java.io.*;
import java.util.*;
import java.util.zip.*;

/**
 * User: fmike  Date: Jun 13, 2004  Time: 2:11:31 AM
 */
class GTModuleLoader {
    private static final HashMap moduleLoaderByPackageRoot = new HashMap();
    private static final HashMap moduleLoaderByName = new HashMap();

    private final File fileRef;
    GTModule.GTModuleInfo moduleInfo;
    GTModule module;

    // only for loaded state;
    private JarClassLoader classLoader;

    private GTModuleLoader(File file) throws IOException {
        fileRef = file;
        readModuleInfo();
    }

    static void onAppStartup() {
        final byte[] byteArray = GUITool.coreSettings.getByteArray("modules", null);
        if (byteArray == null) {
            return;
        }
        String str = new String(byteArray);
        StringTokenizer st = new StringTokenizer(str, "\n");
        while (st.hasMoreTokens()) {
            String moduleFilePath = st.nextToken();
            boolean loaded = "true".equals(st.nextToken());
            try {
                GTModuleLoader ml = installModule(new File(moduleFilePath));
                if (loaded) {
                    GUITool.loadModule(ml);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    static void saveModulesState() {
        StringBuffer installedModules = new StringBuffer();
        for (Iterator it = moduleLoaderByName.values().iterator(); it.hasNext();) {
            GTModuleLoader loader = (GTModuleLoader) it.next();
            installedModules.append(loader.fileRef.getAbsolutePath()).append("\n").append(loader.isModuleLoaded()).append("\n");
        }
        GUITool.coreSettings.putByteArray("modules", installedModules.toString().getBytes());
    }

    static GTModuleLoader installModule(File file) throws IOException {
        GTModuleLoader loader = new GTModuleLoader(file);
        moduleLoaderByName.put(loader.moduleInfo.name, loader);
        moduleLoaderByPackageRoot.put(loader.moduleInfo.modulePackageRoot, loader);
        return loader;
    }


    public static void uninstallModule(GTModuleLoader loader) {
        moduleLoaderByName.remove(loader.moduleInfo.name);
        moduleLoaderByPackageRoot.remove(loader.moduleInfo.modulePackageRoot);
    }


    boolean isModuleLoaded() {
        return module != null;
    }

    synchronized GTModule loadModule() throws Exception {
        ensureLoaded(false);
        String oldModulePackageRoot = moduleInfo.modulePackageRoot;
        readModuleInfo();
        if (!oldModulePackageRoot.equals(moduleInfo.modulePackageRoot)) {
            moduleLoaderByPackageRoot.remove(oldModulePackageRoot);
        }
        try {
            classLoader = new JarClassLoader();
            Class cls = classLoader.provideClass(moduleInfo.moduleImplClass);
            module = (GTModule) cls.getDeclaredConstructor(new Class[]{GTModule.GTModuleInfo.class}).newInstance(new Object[]{moduleInfo});
        } finally {
            if (module == null) {
                classLoader = null;
            }
        }
        return module;

    }

    synchronized void unloadModule() {
        ensureLoaded(true);
        try {
            module.onUnload();
        } catch (Exception e) {
            e.printStackTrace();
        }
        module = null;
        classLoader = null;
    }

    private void ensureLoaded(boolean expectLoaded) {
        if (expectLoaded && !isModuleLoaded()) {
            throw new RuntimeException("Module is not loaded: " + moduleInfo.name);
        } else if (!expectLoaded && isModuleLoaded()) {
            throw new RuntimeException("Module is already loaded: " + moduleInfo.name);
        }
    }

    private void readModuleInfo() throws IOException {
        ZipFile file = new ZipFile(fileRef);
        try {
            ZipEntry e = file.getEntry("module.info");
            if (e == null) {
                throw new RuntimeException("Illegal module: 'module.info' was not found");
            }
            Properties p = new Properties();
            p.load(file.getInputStream(e));
            GTModule.GTModuleInfo mi = new GTModule.GTModuleInfo(this, get(p, ("module_name")), get(p, "module_desc"), get(p, "module_build_info"), get(p, "module_package_root"), get(p, "module_impl_class"));
            if (moduleInfo != null && !moduleInfo.name.equals(mi.name)) {
                throw new RuntimeException("Module name does not match :" + mi.name);
            }
            GTModuleLoader ml = (GTModuleLoader) moduleLoaderByPackageRoot.get(mi.modulePackageRoot);
            if (ml != null && ml != this) {
                throw new RuntimeException("module package root is already in use! : " + mi.modulePackageRoot + "/" + ml.moduleInfo.name);
            }
            ml = (GTModuleLoader) moduleLoaderByName.get(mi.name);
            if (ml != this && ml != null) {
                throw new RuntimeException("module name is already in use! : " + mi.name);
            }
            if (!mi.moduleImplClass.startsWith(mi.modulePackageRoot)) {
                throw new RuntimeException("Module impl package differs from module package root");
            }
            mi.props = p;
            this.moduleInfo = mi;
        } finally {
            try {
                file.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private String get(Properties p, String key) {
        String result = p.getProperty(key);
        if (result == null) {
            throw new RuntimeException("[GTModuleLoader] property is not assigned: '" + key + "'");
        }
        return result;
    }


    static GTModuleLoader getModuleLoaderByName(String name) {
        return (GTModuleLoader) moduleLoaderByName.get(name);
    }

    static Collection getModules() {
        return Collections.unmodifiableCollection(moduleLoaderByName.values());
    }

    private static JarClassLoader findClassLoader(String className) {
        if (className.startsWith("java") || className.startsWith("sun.")) {
            return null;
        }
        for (Iterator it = moduleLoaderByPackageRoot.entrySet().iterator(); it.hasNext();) {
            Map.Entry e = (Map.Entry) it.next();
            if (className.startsWith((String) e.getKey())) {
                return ((GTModuleLoader) e.getValue()).classLoader;
            }
        }
        return null;
    }

    final class JarClassLoader extends ClassLoader {
        public JarClassLoader() {
        }

        /*
         * load class overriden to prohibit to find module classes in system classpath
         */
        public Class loadClass(String name) throws ClassNotFoundException {
            return provideClass(name);
        }

        public synchronized Class provideClass(String className) throws ClassNotFoundException {
            Class c = findLoadedClass(className);
            if (c != null) {
                return c;
            }
            JarClassLoader cl = GTModuleLoader.findClassLoader(className);
            if (cl != null && cl != this) {
                throw new RuntimeException("Module require classes from other module: unsupported!");
            }
            if (cl == null) { //system class
                try {
                    c = Class.forName(className);
                } catch (LinkageError error) {
                    throw new ClassNotFoundException("Error during system class loading!", error);
                }
                return c;
            }
            // loading from jar
            try {
                c = defineClassFromEntry(className);
            } catch (IOException e) {
                throw new RuntimeException(e);
            } catch (LinkageError e) {
                throw new RuntimeException(e);
            }

            return c;
        }


        private Class defineClassFromEntry(String className) throws IOException, ClassNotFoundException {
            ZipFile file = new ZipFile(fileRef);
            try {
                String entryName = className.replace('.', '/') + ".class";
                ZipEntry e = file.getEntry(entryName);
                if (e == null) {
                    throw new ClassNotFoundException("File not found:" + entryName);
                }
                InputStream is = file.getInputStream(e);
                try {
                    byte[] buf = GTIOUtils.readAllFromStream(is);
                    Class c = super.defineClass(className, buf, 0, buf.length);
                    return c;
                } finally {
                    try {
                        is.close();
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
            } finally {
                try {
                    file.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }


        public InputStream getResourceAsStream(String entryName) {
            try {
                ZipFile file = new ZipFile(fileRef);
                try {
                    ZipEntry e = file.getEntry(entryName);
                    if (e == null) {
                        return null;
                    }
                    InputStream is = file.getInputStream(e);
                    try {
                        byte buf[] = GTIOUtils.readAllFromStream(is);
                        return new ByteArrayInputStream(buf);
                    } finally {
                        try {
                            is.close();
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                    }
                } finally {
                    try {
                        file.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
                return null;
            }
        }
    }
}
