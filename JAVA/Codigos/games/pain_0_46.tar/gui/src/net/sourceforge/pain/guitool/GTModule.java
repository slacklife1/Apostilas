package net.sourceforge.pain.guitool;

import javax.swing.*;
import java.util.*;

/**
 * PAIN_GUI
 */
public abstract class GTModule {
    protected GTModuleInfo moduleInfo;

    protected GTModule(GTModuleInfo moduleInfo) {
        this.moduleInfo = moduleInfo;
    }

    public abstract void onUnload();

    public abstract List getExplorerActionNodes();

    public abstract JMenu getMainMenuItems();

    public GTModuleInfo getModuleInfo() {
        return moduleInfo;
    }

    public static class GTModuleInfo {
        final GTModuleLoader loader;

        GTModuleInfo(GTModuleLoader loader, String name, String desc, String buildInfo, String modulePackageRoot, String moduleImplClass) {
            this.loader = loader;
            this.name = name;
            this.desc = desc;
            this.buildInfo = buildInfo;
            this.modulePackageRoot = modulePackageRoot;
            this.moduleImplClass = moduleImplClass;
        }

        public final String name;
        public final String desc;
        public final String buildInfo;
        public final String modulePackageRoot;
        public final String moduleImplClass;
        public Properties props;
    }
}
