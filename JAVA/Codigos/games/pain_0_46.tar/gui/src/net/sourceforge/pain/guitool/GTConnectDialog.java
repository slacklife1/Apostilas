package net.sourceforge.pain.guitool;

import javax.swing.*;
import java.awt.*;

class GTConnectDialog extends JDialog {

    JPanel panel = new JPanel();
    JButton connectButton = new JButton();
    JButton cancelButton = new JButton();
    JTextField hostField = new JTextField();
    JTextField loginField = new JTextField();
    JPasswordField passwordField = new JPasswordField();
    JFormattedTextField portField = new JFormattedTextField();
    JLabel hostLabel = new JLabel();
    JLabel loginLabel = new JLabel();
    JLabel passLabel = new JLabel();
    JLabel portLabel = new JLabel();

    public GTConnectDialog(Frame frame) {
        super(frame, "Connection Dialog", true);
        jbInit();
    }

    private void jbInit() {
        panel.setLayout(null);
        panel.setInputVerifier(null);
        panel.setBounds(new Rectangle(0, 0, 240, 210));
        panel.setBorder(null);

        hostLabel.setFont(new Font("Dialog", 1, 12));
        hostLabel.setText("Host");
        hostLabel.setBounds(new Rectangle(9, 17, 60, 24));
        hostField.setBounds(new Rectangle(75, 17, 149, 26));

        portLabel.setBounds(new Rectangle(9, 48, 60, 24));
        portLabel.setText("Port");
        portLabel.setFont(new Font("Dialog", 1, 12));
        portField.setBounds(new Rectangle(75, 49, 49, 26));


        loginLabel.setFont(new Font("Dialog", 1, 12));
        loginLabel.setText("Login");
        loginLabel.setBounds(new Rectangle(9, 80, 48, 26));
        loginField.setBounds(new Rectangle(75, 81, 149, 26));

        passLabel.setBounds(new Rectangle(9, 111, 64, 26));
        passLabel.setText("Password");
        passLabel.setFont(new Font("Dialog", 1, 12));
        passwordField.setBounds(new Rectangle(75, 112, 149, 26));

        connectButton.setBorder(BorderFactory.createEtchedBorder());
        connectButton.setActionCommand("Connect");
        connectButton.setMnemonic('C');
        connectButton.setBounds(new Rectangle(9, 145, 94, 24));
        connectButton.setText("Connect");

        cancelButton.setBorder(BorderFactory.createEtchedBorder());
        cancelButton.setMaximumSize(new Dimension(37, 19));
        cancelButton.setBounds(new Rectangle(130, 145, 94, 24));
        cancelButton.setText("Cancel");


        panel.add(hostField);
        panel.add(loginField);
        panel.add(connectButton);
        panel.add(portField);
        panel.add(passLabel);
        panel.add(cancelButton);
        panel.add(passwordField);
        panel.add(hostLabel);
        panel.add(portLabel);
        panel.add(loginLabel);

        Container contentPane = getContentPane();
        contentPane.setLayout(null);
        contentPane.add(panel);

        setBounds(panel.getBounds());
    }

}
