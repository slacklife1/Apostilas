package net.sourceforge.pain.guitool;


import javax.swing.*;
import java.awt.*;

/**
 * User: fmike  Date: Jun 19, 2004  Time: 4:37:44 PM
 */
public class GTErrorDialog {

    public static void showError(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void showError(String message) {
        showError(GUITool.appFrame, message);
    }

    public static void showError(Component parent, Exception e) {
        e.printStackTrace();
        String name = e.getClass().getName();
        int i = name.lastIndexOf('.');
        showError(parent, name.substring(i + 1) + ":" + e.getMessage());
    }

    public static void showError(Exception e) {
        showError(GUITool.appFrame, e);
    }
}
