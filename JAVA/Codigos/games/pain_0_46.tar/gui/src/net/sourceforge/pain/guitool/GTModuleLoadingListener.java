package net.sourceforge.pain.guitool;

/**
 * User: fmike  Date: Jun 13, 2004  Time: 1:15:55 AM
 */
public interface GTModuleLoadingListener {
    /**called after module is loaded*/
    void onModuleLoaded(GTModule module);

    /**called before module unloading*/
    void onModuleUnloading(GTModule module);
}
