The game is similar to the clan bomber game in linux and windows. 
We developed this code as part of my 7th sem VTU Java Project using swings.

The zip file doesnt contain all the source files. 
Only 2 java files are present in the zip file.

If you are interested in the code than send across a mail to my e-mail ID.

shrinidhi_karanth@yahoo.com


