import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.lang.Integer;

public class BomberPlayer extends Thread {
    public BomberGame game = null;
    private BomberMap map = null;
    public boolean[][] bombGrid = null;
    private boolean bombKeyDown = false;
    private byte currentDirKeyDown = 0x00;
    private final int width = BomberMain.size;
    private final int height = 44 / (32 / BomberMain.size);
    private boolean isExploding = false;
    private boolean isDead = false;
    public int[] keys = null;
    public int totalBombs = 1;
    public int usedBombs = 0;
    public int fireLength = 1;
    public boolean isActive = true;
    public int x = 0;
    public int y = 0;
    private int playerNo = 0;
    private int state = DOWN;
    private boolean moving = false;
    private int frame = 0;
    private boolean clear = false;

    private static final byte BUP = 0x01;
    private static final byte BDOWN = 0x02;
    private static final byte BLEFT = 0x04;
    private static final byte BRIGHT = 0x08;
    private static final byte BBOMB = 0x10;
    private static final int UP = 0;
    private static final int DOWN = 1;
    private static final int LEFT = 2;
    private static final int RIGHT = 3;
    private static final int BOMB = 4;
    private static final int EXPLODING = 4;
    private static Image[][][] sprites = null;
    private static Object hints = null;

    static {
        if (Main.J2) {
            RenderingHints h = null;
            h = new RenderingHints(null);
            h.put(RenderingHints.KEY_TEXT_ANTIALIASING,
             RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            h.put(RenderingHints.KEY_FRACTIONALMETRICS,
             RenderingHints.VALUE_FRACTIONALMETRICS_ON);
            h.put(RenderingHints.KEY_ALPHA_INTERPOLATION,
             RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
            h.put(RenderingHints.KEY_ANTIALIASING,
             RenderingHints.VALUE_ANTIALIAS_ON);
            h.put(RenderingHints.KEY_COLOR_RENDERING,
             RenderingHints.VALUE_COLOR_RENDER_QUALITY);
            hints = (RenderingHints)h;
        }

        sprites = new Image[2][5][3];
        int[] states = { UP, DOWN, LEFT, RIGHT, EXPLODING };
        Toolkit tk = Toolkit.getDefaultToolkit();
        String path = new String();
        try {
            for (int p = 0; p < 2; p++) {
                for (int d = 0; d < 5; d++) {
                    for (int f = 0; f < 3; f++) {
                        path = BomberMain.RP + "Images/";
                        path += "Bombermans/Player " + (p + 1) + "/";
                        path += states[d] + "" + (f + 1) + ".gif";
                        sprites[p][d][f] = tk.getImage(
                        new File(path).getCanonicalPath());
                    }
                }
            }
        }
        catch (Exception e) { //new ErrorDialog(e); 
	}
    }

    public BomberPlayer(BomberGame game, BomberMap map, int playerNo) {
        this.game = game;
        this.map = map;
        this.playerNo = playerNo;

        bombGrid = new boolean[17][17];
        for (int i = 0; i < 17; i++) for (int j = 0; j < 17; j++)
            bombGrid[i][j] = false;

        int r = 0, c = 0;
        switch (this.playerNo)
        {
            case 1: r = c = 1; break;
            case 2: r = c = 15; break;
           
        }
        x = r << BomberMain.shiftCount;
        y = c << BomberMain.shiftCount;

        MediaTracker tracker = new MediaTracker(game);
        try {
            int counter = 0;
            for (int p = 0; p < 2; p++) {
                for (int d = 0; d < 5; d++) {
                    for (int f = 0; f < 3; f++) {
                        tracker.addImage(sprites[p][d][f], counter++);
                    }
                }
            }
            tracker.waitForAll();
        }
        catch (Exception e) { //new ErrorDialog(e); 
	}

        keys = new int[5];

	if(playerNo==1)
	{
		keys[0]=KeyEvent.VK_UP;
		keys[1]=KeyEvent.VK_DOWN;
		keys[2]=KeyEvent.VK_LEFT;
		keys[3]=KeyEvent.VK_RIGHT;
		keys[4]=KeyEvent.VK_BACK_SLASH;
	}
	else
	{
		keys[0]=KeyEvent.VK_R;
		keys[1]=KeyEvent.VK_F;
		keys[2]=KeyEvent.VK_D;
		keys[3]=KeyEvent.VK_G;
		keys[4]=KeyEvent.VK_Z;
	}
		
        setPriority(Thread.MAX_PRIORITY);
        start();
    }

    public void keyPressed(KeyEvent evt)
    {
        byte newKey = 0x00;
        if (!isExploding && !isDead &&
        evt.getKeyCode() == keys[UP] ||
        evt.getKeyCode() == keys[DOWN] ||
        evt.getKeyCode() == keys[LEFT] ||
        evt.getKeyCode() == keys[RIGHT])
        {
            if (evt.getKeyCode() == keys[DOWN]) 
                currentDirKeyDown = BDOWN;
            
            else if (evt.getKeyCode() == keys[UP]) 
                currentDirKeyDown = BUP;
        
            else if (evt.getKeyCode() == keys[LEFT]) 
                currentDirKeyDown = BLEFT;

            else if (evt.getKeyCode() == keys[RIGHT])
                currentDirKeyDown = BRIGHT;
        }

	if (!isExploding && !isDead &&
        evt.getKeyCode() == keys[BOMB] && !bombKeyDown && isActive)
        {
            bombKeyDown = true;
            interrupt();
        }
    }

    public void keyReleased(KeyEvent evt)
    {
        if (!isExploding && !isDead && (
        evt.getKeyCode() == keys[UP] ||
        evt.getKeyCode() == keys[DOWN] ||
        evt.getKeyCode() == keys[LEFT] ||
        evt.getKeyCode() == keys[RIGHT]))
        {
            if (evt.getKeyCode() == keys[DOWN]) {
		    if(currentDirKeyDown==BDOWN)
		    	    currentDirKeyDown=0;
		    	    
            }
            else if (evt.getKeyCode() == keys[UP]) {
		    if(currentDirKeyDown==BUP)
		    	    currentDirKeyDown=0;
            }

	    else if (evt.getKeyCode() == keys[LEFT]) {
		    if(currentDirKeyDown==BLEFT)
		    	    currentDirKeyDown=0;
	    }
            else if (evt.getKeyCode() == keys[RIGHT]) {
		    if(currentDirKeyDown==BRIGHT)
		        currentDirKeyDown=0;
            }
        }

	if (!isExploding && !isDead && evt.getKeyCode() == keys[BOMB])
        {
            bombKeyDown = false;
            interrupt();
        }
    }

    public void deactivate()
    {
        isActive = false;
    }

    public void kill()
    {
        if (!isDead && !isExploding)
        {
            BomberGame.playersLeft -= 1;
            frame = 0;
            state = EXPLODING;
            moving = true;
            isExploding = true;
 		currentDirKeyDown=0;           
            interrupt();
        }
    }

    public int getX() { return x; }
    public int getY() { return y; }

    public boolean isDead() { return (isDead | isExploding); }

    public void run()
    {
        boolean canMove;
        int lastState = 0;
        int shiftCount = BomberMain.shiftCount;
        int offset = 1 << (BomberMain.shiftCount / 2);
        int size = BomberMain.size;
        int halfSize = BomberMain.size / 2;
        int bx = 0, by = 0;
	
        while (true) {
            if (!isExploding && !isDead && bombKeyDown && isActive) {
                if ((totalBombs - usedBombs) > 0 &&
                map.grid[x >> shiftCount][y >> shiftCount]
                != BomberMap.BOMB && !bombGrid[(x + halfSize) >>
                BomberMain.shiftCount][(y + halfSize) >>
                BomberMain.shiftCount]) {
                    usedBombs += 1;
                    bombGrid[(x + halfSize) >> BomberMain.shiftCount]
                    [(y + halfSize) >> BomberMain.shiftCount] = true;
                    map.createBomb(x + halfSize, y + halfSize, playerNo);
                }
            }

            if (!isExploding && !isDead && currentDirKeyDown>0) {
                lastState = currentDirKeyDown;
                frame = (frame + 1) % 3;
                moving = true;
                canMove = false;
                if (currentDirKeyDown > 0) {
                    if ((currentDirKeyDown & BLEFT) > 0) {
                        state = LEFT;
                        canMove = (x % size != 0 || 
			(y % size == 0 && (map.grid[(x >> shiftCount) - 1][y >> shiftCount] <= BomberMap.NOTHING)) ||
			((map.grid[(x >> shiftCount) - 1][y >> shiftCount] <= BomberMap.NOTHING) && 
			 (map.grid[(x >> shiftCount) - 1][(y >> shiftCount) +1] <= BomberMap.NOTHING)));

                        if (!canMove) {
                            int oy = 0;
                            for (oy = -offset; oy < 0; oy += (size / 4)) {
                                if ((y + oy) % size == 0 &&
                                map.grid[(x >> shiftCount) - 1]
                                [(y + oy) >> shiftCount] <= BomberMap.NOTHING) {
                                    canMove = true; break;
                                }
                            }
                            if (!canMove) {
                                for (oy = (size / 4); oy <= offset;
                                oy += (size / 4)) {
                                    if ((y + oy) % size == 0 &&
                                    map.grid[(x >> shiftCount) - 1]
                                    [(y + oy) >> shiftCount]
                                    <= BomberMap.NOTHING) {
                                        canMove = true; break;
                                    }
                                }
                            }
                            if (canMove) {
                                clear = true; game.paintImmediately(x,
                                y - halfSize, width, height);
                                y += oy;
                                clear = false; game.paintImmediately(x,
                                y - halfSize, width, height);
                            }
                        }
                        if (canMove) {
                            clear = true; game.paintImmediately(x,
                            y - halfSize, width, height);
                            x -= (size / 4);
                            clear = false; game.paintImmediately(x,
                            y - halfSize, width, height);
                        }
                        else {
                            moving = false; game.paintImmediately(x,
                            y - halfSize, width, height);
                        }
                    }
                    else if ((currentDirKeyDown & BRIGHT) > 0) {
                        state = RIGHT;
                        canMove = false;
                        canMove = (x % size != 0 || 
			(y % size == 0 && (map.grid[(x >> shiftCount) + 1][y >> shiftCount] <= BomberMap.NOTHING)) ||
			((map.grid[(x >> shiftCount) + 1][y >> shiftCount] <= BomberMap.NOTHING) &&
			 (map.grid[(x >> shiftCount) + 1][(y >> shiftCount)+1] <= BomberMap.NOTHING)));
                        if (!canMove) {
                            int oy = 0;
                            for (oy = -offset; oy < 0; oy += (size / 4)) {
                                if ((y + oy) % size == 0 &&
                                map.grid[(x >> shiftCount) + 1]
                                [(y + oy) >> shiftCount] <= BomberMap.NOTHING) {
                                    canMove = true; break;
                                }
                            }
                            if (!canMove) {
                                for (oy = (size / 4); oy <= offset;
                                oy += (size / 4)) {
                                    if ((y + oy) % size == 0 &&
                                    map.grid[(x >> shiftCount) + 1]
                                    [(y + oy) >> shiftCount]
                                    <= BomberMap.NOTHING) {
                                        canMove = true; break;
                                    }
                                }
                            }
                            if (canMove) {
                                clear = true; game.paintImmediately(x,
                                y - halfSize, width, height);
                                y += oy;
                                clear = false; game.paintImmediately(x,
                                y - halfSize, width, height);
                            }
                        }
                        if (canMove) {
                            clear = true; game.paintImmediately(x,
                            y - halfSize, width, height);
                            x += (size / 4);
                            clear = false; game.paintImmediately(x,
                            y - halfSize, width, height);
                        }
                        else {
                            moving = false;
                            game.paintImmediately(x,
                            y - halfSize, width, height);
                        }
                    }
                    else if ((currentDirKeyDown & BUP) > 0) {
                        state = UP;
                        canMove = false;
                        canMove = (y % size != 0 || 
			(x % size == 0 && (map.grid[x >> shiftCount][(y >> shiftCount) - 1] <= BomberMap.NOTHING)) ||
			((map.grid[x >> shiftCount][(y >> shiftCount) - 1] <= BomberMap.NOTHING) &&
			 (map.grid[(x >> shiftCount)+1][(y >> shiftCount) - 1] <= BomberMap.NOTHING)));

                        if (!canMove) {
                            int ox = 0;
                            for (ox = -offset; ox < 0; ox += (size / 4)) {
                                if ((x + ox) % size == 0 &&
                                map.grid[(x + ox) >> shiftCount]
                                [(y >> shiftCount) - 1] <= BomberMap.NOTHING) {
                                    canMove = true; break;
                                }
                            }
                            if (!canMove) {
                                for (ox = (size / 4); ox <= offset; ox += (size / 4)) {
                                    if ((x + ox) % size == 0 &&
                                    map.grid[(x + ox) >> shiftCount]
                                    [(y >> shiftCount) - 1]
                                    <= BomberMap.NOTHING) {
                                        canMove = true; break;
                                    }
                                }
                            }
                            if (canMove) {
                                clear = true; game.paintImmediately(x,
                                y - halfSize, width, height);
                                x += ox;
                                clear = false; game.paintImmediately(x,
                                y - halfSize, width, height);
                            }
                        }
                        if (canMove) {
                            clear = true; game.paintImmediately(x,
                            y - halfSize, width, height);
                            y -= (size / 4);
                            clear = false; game.paintImmediately(x,
                            y - halfSize, width, height);
                        }
                        else {
                            moving = false; game.paintImmediately(x,
                            y - halfSize, width, height);
                        }
                    }
                    else if ((currentDirKeyDown & BDOWN) > 0)
                    {
                        state = DOWN;
                        canMove = false;
                        canMove = (y % size != 0 || 
			(x % size == 0 && (map.grid[x >> shiftCount][(y >> shiftCount) + 1]<= BomberMap.NOTHING)) ||
			((map.grid[x >> shiftCount][(y >> shiftCount) + 1]<= BomberMap.NOTHING) &&
			 (map.grid[(x >> shiftCount)+1][(y >> shiftCount) + 1]<= BomberMap.NOTHING)));

                        if (!canMove) {
                            int ox = 0;
                            for (ox = -offset; ox < 0; ox += (size / 4)) {
                                if ((x + ox) % size == 0 &&
                                map.grid[(x + ox) >> shiftCount]
                                [(y >> shiftCount) + 1] <= BomberMap.NOTHING) {
                                    canMove = true; break;
                                }
                            }
                            if (!canMove) {
                                for (ox = (size / 4); ox <= offset;
                                ox += (size / 4)) {
                                    if ((x + ox) % size == 0 &&
                                    map.grid[(x + ox) >> shiftCount]
                                    [(y >> shiftCount) + 1]
                                    <= BomberMap.NOTHING) {
                                        canMove = true; break;
                                    }
                                }
                            }
                            if (canMove) {
                                clear = true; game.paintImmediately(x,
                                y - halfSize, width, height);
                                x += ox;
                                clear = false; game.paintImmediately(x,
                                y - halfSize, width, height);
                            }
                        }
                        if (canMove) {
                            clear = true; game.paintImmediately(x,
                            y - halfSize, width, height);
                            y += (size / 4);
                            clear = false; game.paintImmediately(x,
                            y - halfSize, width, height);
                        }
                        else {
                            moving = false; game.paintImmediately(x,
                            y - halfSize, width, height);
                        }
                    }
                }
            }
            else if (!isExploding && !isDead && lastState != currentDirKeyDown)
            {
                frame = 0;
                moving = false;
                game.paintImmediately(x, y - halfSize, width, height);
                lastState = currentDirKeyDown;
            }
            else if (!isDead && isExploding)
            {
                if (frame >= 2) isDead = true;
                game.paintImmediately(x, y - halfSize, width, height);
                frame = (frame + 1) % 3;
            }
            else if (isDead)
            {
                clear = true;
                game.paintImmediately(x, y - halfSize, width, height);
                break;
            }
            if (map.bonusGrid[x >> shiftCount][y >> shiftCount] != null)
               { bx = x; by = y; }
            else if (map.bonusGrid[x >> shiftCount][(y + halfSize)
                 >> shiftCount] != null) { bx = x; by = y + halfSize; }
            else if (map.bonusGrid[(x + halfSize) >> shiftCount][y
                 >> shiftCount] != null) { bx = x + halfSize; by = y; }
            if (bx != 0 && by != 0) {
                map.bonusGrid[bx >> shiftCount][by >>
                shiftCount].giveToPlayer(playerNo);
                bx = by = 0;
            }
            if (isDead) break;
            try { sleep(65); } catch (Exception e) { }
        }
        interrupt();
    }

    public void paint(Graphics graphics)
    {
        Graphics g = graphics;
        paint2D(graphics); 
    }

    public void paint2D(Graphics graphics) {
        Graphics2D g2 = (Graphics2D)graphics;
        g2.setRenderingHints((RenderingHints)hints);
        if (!isDead && !clear)
        {
            if (moving)
               g2.drawImage(sprites[playerNo - 1][state][frame],
               x, y - (BomberMain.size / 2), width, height, null);
            else
                g2.drawImage(sprites[playerNo - 1][state][0],
                x, y - (BomberMain.size / 2), width, height, null);
        }
    }
}



