import javax.swing.*;

public class Main
{
    public static BomberMain bomberMain = null;
    public static final String RP = "./";
    public static boolean J2 = true;

       public static void startBomberman() {
        bomberMain = new BomberMain();
       }

    public static void main(String[] args)
    {
        boolean bombermanMode = false;
        startBomberman();
    }
}
