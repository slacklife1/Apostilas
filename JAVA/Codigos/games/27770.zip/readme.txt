Simple 2D car racing game. Use up, down,
left, right key to move the car and adjust
the speed. Due to user comments I made
some fixes, enjoy!