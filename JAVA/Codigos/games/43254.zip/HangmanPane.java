import javax.swing.*;
import java.awt.*;

public class HangmanPane extends Canvas {
    private int ctr = 5;

    public HangmanPane() {
        setSize(new Dimension(100,320));
    }

    public void paint(Graphics g) {
        Graphics2D g2d = (Graphics2D)g;
        g2d.setColor(Color.black);
        g2d.drawRect(0,0,15,220);
        g2d.drawRect(15,0,40,10);
        g2d.drawRoundRect(55,0,4,70,2,2);
        BasicStroke stroke = new BasicStroke(4,BasicStroke.CAP_ROUND,
        BasicStroke.JOIN_ROUND);
        g2d.setStroke(stroke);
        //head
        if (ctr < 5) g2d.drawOval(27,70,60,60);
        //body
        if (ctr < 4) g2d.drawLine(58,131,58,210);
        //arms
        if (ctr < 1) g2d.drawLine(15,140,100,140);
        //leg left
        if (ctr < 3) g2d.drawLine(57,210,17,280);
        //leg right
        if (ctr < 2) g2d.drawLine(58,210,93,280);
    }

    public void setDisplay(int d) { ctr = d; repaint(); }

    public void clear() { setDisplay(5); }

    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.getContentPane().add(new HangmanPane());
        frame.pack();
        frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}