import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

class AvailableLettersPanel extends JPanel implements ActionListener, KeyListener {
	private JButton[] letters;
	private ArrayList listeners;
	private boolean isEnabled;

	public AvailableLettersPanel() {
		setLayout(new GridLayout(2, 13));
		setPreferredSize(new Dimension(650, 100));
		setBorder(BorderFactory.createTitledBorder(
			BorderFactory.createLineBorder(Color.black),
            "Available Letters",
            TitledBorder.CENTER,
            TitledBorder.DEFAULT_POSITION));
		letters = new JButton[26];
		char c = 'A';
		for (int i = 0; i < letters.length; i++, c++) {
			letters[i] = new JButton(c+"");
			letters[i].setFocusable(false);
			letters[i].addActionListener(this);
			//letters[i].addKeyListener(this);
			add(letters[i]);
		}
		addKeyListener(this);
		listeners = new ArrayList();
		isEnabled = true;
	}

	public void addALPListener(ALPListener listener) {
		listeners.add(listener);
	}

	public void actionPerformed(ActionEvent e) {
        updatePanel(((JButton)e.getSource()).getText().charAt(0));
	}

    public void updatePanel(char letterPressed) {
        // return if user pressed a non-letter key
        if (!Character.isLetter(letterPressed) ||
        !letters[letterPressed-'A'].isEnabled()) return;
		System.out.println("Pressed "+letterPressed+"...disabling...");
        letters[letterPressed-'A'].setEnabled(false);
		for (int i = 0; i < listeners.size(); i++) {
			((ALPListener)listeners.get(i)).letterChosen(letterPressed);
		}
    }

	public void keyTyped(KeyEvent e) {
        System.out.println("Key Typed");
        updatePanel(Character.toUpperCase(e.getKeyChar()));
    }
	public void keyPressed(KeyEvent e) {}
    public void keyReleased(KeyEvent e) {}

	/** enables all button-letters
     */
/*	public void enable() {
		for (int i = 0; i < letters.length; i++)
			letters[i].setEnabled(true);
	}*/
    /** disables all letters that are still available
     */
/*	public void disable() {
        for (int i = 0; i < letters.length; i++)
	       if (letters[i].isEnabled())
	           letters[i].setEnabled(false);
    }*/

    public void setEnabled(boolean isEnabled) {
		for (int i = 0; i < letters.length; i++)
			letters[i].setEnabled(isEnabled);
		this.isEnabled = isEnabled;
    }
}