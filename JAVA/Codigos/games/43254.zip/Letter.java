import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

// class for the letters of the string to guess
class Letter extends JLabel {
	private char value;
	private boolean isShown;

	public Letter(char value) {
		this.value = Character.toUpperCase(value);
		if (Character.isLetter(value)) {
    		setText("_");
    		setPreferredSize(new Dimension(30, 25));
            setOpaque(true);
    		setBackground(Color.lightGray);
            //setText(value+"");
        } else {
            setText(value+"");
        }
        setHorizontalAlignment(JLabel.CENTER);
		isShown = false;
	}

	public boolean isEqual(char c) {
		return value == c;
	}
    // return true if Letter.value is not a letter
	public boolean isSpecial() {
	   return !Character.isLetter(value);
    }

	public void show() {
		setText(value+"");
		isShown = true;
        setBackground(getBackground().darker());
	}
    // returns true if getText() returns an underscore
	public boolean isShown() {
	   return isShown;//getText().equals(value+"");
	}

	public String toString() {
	   return this.hashCode()+"[value="+value+"]";
    }
}