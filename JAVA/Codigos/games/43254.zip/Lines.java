import java.io.*;
import java.util.ArrayList;
import java.util.LinkedList;

public class Lines
{
	private ArrayList list;
    private LinkedList prevList = null;
	private int lookBackSize = -1;

    public Lines()
    {
        BufferedReader in = null;
        try {
            in = new BufferedReader(new FileReader("lines.txt"));
            String line = "";
            OneLine ol;
            list = new ArrayList();
            while ((line = in.readLine()) != null) {
                ol = new OneLine();
                int index = line.lastIndexOf(",");
                ol.line = line.substring(0, index);
                ol.clue = line.substring(index+1);
                list.add(ol);
            }
        }
        catch (IOException iox) {
            iox.printStackTrace();
            System.exit(1);
        }
        finally {
            try {
                in.close();
            } catch (IOException iox) {
                System.out.println("Can't close in stream.");
                iox.printStackTrace();
                System.exit(1);
            }
        }
        prevList = new LinkedList();
        lookBackSize = list.size()/2;
    }

    public OneLine nextWord() {
        int index = -1;
        Integer iindex = null;
        // make sure next word is not the same as the last list.size()/2 words
        do { 
        	index = (int)(Math.random()*list.size()); 
            iindex = new Integer(index);
        } while (prevList.contains(iindex));
        // add new word to previous list
        if (prevList.size() == lookBackSize) prevList.removeLast();
		prevList.addFirst(iindex);
        System.out.println(index);
        return (OneLine)list.get(index);
    }
}