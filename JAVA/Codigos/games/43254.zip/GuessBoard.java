import javax.swing.JPanel;
import javax.swing.BorderFactory;
import javax.swing.border.*;
import java.awt.*;
import java.util.ArrayList;

// is where the line-to-guess will appear. Letters correctly guessed appear as
// they are, otherwise, appears as underscore
class GuessBoard extends JPanel {
    private TitledBorder border;
    private String textToGuess;
    private ArrayList letters;
    private int totalCorrectMatch, charLen;
    public static final int NO_MATCH = 0, USED_PREVIOUSLY = -1;

	public GuessBoard() {
        setPreferredSize(new Dimension(650, 240));
        border = BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Color.black),
            "",
            TitledBorder.CENTER,
            TitledBorder.DEFAULT_POSITION,
            new Font("Default", Font.PLAIN, 12)//,
            );//Color.orange);
        setBorder(border);
        setTitle("Hangman v0");
        letters = new ArrayList();
        setLayout(new FlowLayout(FlowLayout.CENTER, 28, 0));
	}

    // stores and displays the text to guess
	public void setTextToGuess(String text, String clue) {
        textToGuess = text;
        border.setTitle("  "+clue+"  ");
        digest();
        charLen = 0;
        for (int i=0;i<text.length();i++)
            if (Character.isLetter(text.charAt(i))) charLen++;
    }

    // groups text-to-guess into words, creates Letter objects for the letters
    //  of each words, adds objects to a panel, and adds this panel to this
    //  GuessBoard object
    private void digest() {
        int from = 0, to = textToGuess.indexOf(' ', from);
        while (to != -1) {
            generate(textToGuess.substring(from, to));
            from = to+1;
            to = textToGuess.indexOf(' ', from);
        }
        to = textToGuess.length();
        generate(textToGuess.substring(from, to));
    }
    // creates a panel containing Letter objects of each letter in String s
    //  if s.length >= 2, else creates a Letter object
    private void generate(String s) {
        if (s.length() < 2) {
            Letter l = new Letter(s.charAt(0));
            add(l);
            letters.add(l);
        } else if (s.length() >= 2) {
            JPanel p = new JPanel();
            for (int i = 0; i < s.length(); i++) {
                Letter l = new Letter(s.charAt(i));
                p.add(l);
                letters.add(l);
            }
            add(p);
        }
    }
    // matches the character in c to every letter (not displayed yet) in this board
    public int match(char c) {
        System.out.println("Finding a match for "+c);
        int nMatch = 0;
        Letter l = null;
        for (int i = 0; i < letters.size(); i++) {
            l = (Letter)letters.get(i);
            if (l.isSpecial()) continue; // skip if non-letter
            System.out.print(l.toString());
            // matches the letter guessed by user
            if (l.isEqual(c)) { // letter matched
                System.out.print(" found match");
                if (!l.isShown()) { // not yet revealed
                    System.out.print(" not revealed");
                    nMatch++;
                    l.show();
                }
                else {
                    System.out.print(" previously revealed");
                    nMatch = -1;
                    i = letters.size();
                }
            }
            System.out.println();
        }
        System.out.println("There are "+nMatch+" for "+c);
        if (nMatch > 0)
            totalCorrectMatch += nMatch;
        System.out.println("Total correct matches: "+totalCorrectMatch);
        System.out.println("Current word length: "+textToGuess.length());
        return nMatch; // return how many matches found
    }
    // reveal all the letters
    public void showAll() {
        for (int i = 0; i < letters.size(); i++)
            ((Letter)letters.get(i)).show();
        border.setTitle("  You Lose! The Correct Answer is  ");
        repaint();
    }
    /** removes all displayed letters in this board
     */
    public void clear() {
        super.removeAll();
        letters.clear();
        totalCorrectMatch = 0;
        repaint();
    }

    public boolean isComplete() {
        return totalCorrectMatch == charLen;
    }

    public void setTitle(String title) {
        border.setTitle("  "+title+"  ");
        repaint();
    }
}