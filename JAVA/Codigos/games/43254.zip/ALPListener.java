/**
 * Listener to AvailableLettersPanel class.
 * @param letter the letter chosen by the user
 * @return none
 */
interface ALPListener {
	public void letterChosen(char letter);
}