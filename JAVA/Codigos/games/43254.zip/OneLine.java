public class OneLine
{
    public String line, clue;
}