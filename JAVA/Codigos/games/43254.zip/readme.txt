compile with jdk1.4 up

it is not finished. needs to keep scores.

need some constructive criticism. send to trfrust@yahoo.com