import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class HangmanFrame extends JFrame implements ALPListener, KeyListener {
	private AvailableLettersPanel alp;
	private GuessBoard board;
	private int turnsLeft = 5;
	private HangmanPane hp;
	private Lines lines;
	private JButton jbStart, jbNext;
	private int accmatch = 0;
	private OneLine ol;

	public HangmanFrame() {
		super("Hangman");
		JPanel c = new JPanel();
		alp = new AvailableLettersPanel();
		alp.addALPListener(this);
		alp.disable();
		lines = new Lines();
		board = new GuessBoard();
        //board.setTextToGuess("BEND AND BE STRAIGHT, YIELD AND OVERCOME", "Lao Tzu");
        //board.setTextToGuess("THE WORLD IS A VAMPIRE", "Smashing Pumpkins");
        //board.setTextToGuess("I was once like you; You should be like me too.", "Painting Scripture");
        //board.setTextToGuess("Supercalifragilisticexpialidocious","Mary Poppins");
        /*lbl = new JLabel[5];
        JPanel p=new JPanel();
        p.setPreferredSize(new Dimension(650, 55));
        p.setBorder(BorderFactory.createLineBorder(Color.black));
        p.setLayout(new GridLayout(1,lbl.length));
        Font font=new Font("default",Font.BOLD,40);
        for (int i=0; i<lbl.length; i++) {
            lbl[i]=new JLabel("X");
            lbl[i].setHorizontalAlignment(JLabel.CENTER);
            lbl[i].setFont(font);
            lbl[i].setEnabled(false);
            p.add(lbl[i]);
        }*/
        hp = new HangmanPane();
        JPanel p = new JPanel();
        p.add(hp);
        p.setBorder(BorderFactory.createEmptyBorder(2,2,0,0));

        JPanel btn = new JPanel();
        btn.setLayout(new BoxLayout(btn, BoxLayout.LINE_AXIS));
        btn.add(Box.createHorizontalGlue());
        btn.add(jbStart = new JButton("Start"));
        btn.add(Box.createRigidArea(new Dimension(10,0)));
        btn.add(jbNext = new JButton("Next"));
        jbNext.setEnabled(false);
        btn.setBorder(BorderFactory.createEmptyBorder(0,0,5,5));

        jbStart.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("Start");
                initBoard();
                jbStart.setEnabled(false);
                HangmanFrame.this.requestFocus();
            }
        });
        jbNext.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("Next");
                initBoard();
                jbNext.setEnabled(false);
                HangmanFrame.this.requestFocus();
            }
        });
		addKeyListener(this);
		addWindowListener(new WindowAdapter() {
		  public void windowClosing(WindowEvent e) { dispose(); System.exit(0); }
		});
		//c.setLayout(new FlowLayout());
		c.setLayout(new BoxLayout(c, BoxLayout.PAGE_AXIS));
		//c.add(p);
		c.add(board);
		c.add(alp);
        c.setBorder(BorderFactory.createEmptyBorder(0,4,5,5));
		//setSize(670, 445);
		getContentPane().add(c);
		getContentPane().add(p, BorderLayout.WEST);
		getContentPane().add(btn, BorderLayout.SOUTH);
		pack();
		setResizable(false);
		//setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}

	public void initBoard() {
	   ol = lines.nextWord();
	   board.clear();
	   board.setTextToGuess(ol.line,ol.clue);
	   alp.setEnabled(true);
	   hp.clear();
	   //validate();
	   validate();
	   turnsLeft = 5;
	   requestFocus();
    }

	public static void main(String[] args) {
        JFrame.setDefaultLookAndFeelDecorated(true);
		new HangmanFrame();
	}

	public void letterChosen(char c) {
        System.out.println("Letter chosen: "+c);
        int match = board.match(c);
        accmatch += match;
        if (match == board.NO_MATCH && match != board.USED_PREVIOUSLY) { // no match found
            // wrong guess
            hp.setDisplay(--turnsLeft);
            System.out.println(turnsLeft+" turns left");
        }

        // board not yet complete and there are no turns left
        if (turnsLeft <= 0 && !board.isComplete()) {
            // game lost
            board.showAll();
            alp.setEnabled(false);
            validate();
            jbStart.setEnabled(true);
            jbStart.requestFocus();
        }
        else if (board.isComplete()){
            // game won
            alp.setEnabled(false);
            board.setTitle("Correct!");
            validate();
            jbNext.setEnabled(true);
            jbNext.requestFocus();
        }
	}

    // pass key typed event to alp and let alp handle it
	public void keyTyped(KeyEvent e) { alp.keyTyped(e); }
    public void keyPressed(KeyEvent e) {}
    public void keyReleased(KeyEvent e) {}
}