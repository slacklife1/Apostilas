import java.awt.event.*;
import java.applet.Applet;
import java.awt.*;
import java.net.*;
import java.util.ArrayList;

/**
 * @author Daniel Newman (danielnewman106@hotmail.com
 * @homepage http://www.personal.leeds.ac.uk/~jhs3dn
 */
public class GoatsAndTigers extends Applet implements ActionListener, MouseMotionListener, MouseListener
{
    Image offscreen;
    Graphics g2;
    Color bgColor = Color.white;
    int[][] board = new int[5][5]; // 0 = empty, 1 = goat, 2 = tiger
    int phase, level, selectedGoat, mouseX, mouseY, draggedPieceX, draggedPieceY;
    Button newGameBtn, nextLevelBtn;
    Image goat, tiger, congrats;
    URL base;
    boolean dragging = false, animating;
    boolean[] remainingGoat = new boolean[20];
    ArrayList possibleMoves = new ArrayList ();
    
    public void actionPerformed (ActionEvent e)
    {
        if (e.getSource() == newGameBtn)
        {
            start ();
        }
        else
        if (e.getSource() == nextLevelBtn)
        {
            resetBoard ();
            phase = 1;
            loadImages (level);
            repaint ();
            nextLevelBtn.setVisible (false);
        }
    }
    
    public void mouseDragged (MouseEvent e)
    {
        if (!dragging)
            return;
        mouseX = e.getX() - 16;
        mouseY = e.getY() - 16;
        repaint();
    }
    
    public void mouseMoved (MouseEvent e) {}
    public void mouseEntered (MouseEvent e) {}    
    public void mouseExited (MouseEvent e) {}    
    public void mouseClicked (MouseEvent e) {}
    
    public void mouseReleased (MouseEvent e)
    {
        if (!dragging)
            return;
            
        dragging = false;
            
        int x = e.getX(), y = e.getY();
       
        // If the user dropped outside the board
        if (x < 20 || y < 20 || x > 450 || y > 450)
        {
            if (phase == 1)
                remainingGoat[selectedGoat] = true;
            else
                board[draggedPieceX][draggedPieceY] = 1;
            repaint ();
            return;
        }

        int i = (int)((x / 100.0) + 0.25), j = (int)((y / 100.0) + 0.25);
        if (i < 0)
            i = 0;
        else if (i > 4)
            i = 4;
        if (j < 0)
            j = 0;
        else if (j > 4)
            j = 4;
        if (b(i,j) == 0 && (phase == 1 || validGoatMove (draggedPieceX, draggedPieceY, i, j)))
        {
            board[i][j] = 1;
            if (phase == 1 && endOfPhase1())
                phase = 2;
            if (i != draggedPieceX || j != draggedPieceY)
                doAI ();
            repaint ();
            return;
        }
        
        if (phase == 1)
            remainingGoat[selectedGoat] = true;
        else
            board[draggedPieceX][draggedPieceY] = 1;
        
        repaint ();
    }
    
    boolean validGoatMove (int x1, int y1, int x2, int y2)    
    {
        if (x1 < 0 || x1 > 4 || x2 < 0 || x2 > 4 || y1 < 0 || y1 > 4 || y2 < 0 || y2 > 4)
            return false;

        int dx = x1 - x2, dy = y1 - y2;
        
        if (dx == 0 && dy == 0)
            return false;
            
        if (dx > 1 || dx < -1 || dy > 1 || dy < -1)
            return false;
            
        if (dx == 1)
        {
            if (dy == 1)
                return canMoveUpLeft (x1, y1);
            if (dy == -1)
                return canMoveDownLeft (x1, y1);
        }            
        else if (dx == -1)
        {
            if (dy == 1)
                return canMoveUpRight (x1, y1);
            if (dy == -1)
                return canMoveDownRight (x1, y1);
        }
            
        return true;    
    }

    public void mousePressed (MouseEvent e)
    {
        int x = e.getX (), y = e.getY ();
        
        // Check to see if a remaining goat was selected
        if (x >= 460)
        {
            int i = (int)((y-10) / 40);
            if (remainingGoat[i])
            {
                selectedGoat = i;
                remainingGoat[i] = false;
                dragging = true;
            }
        }
        else if (y >= 460)
        {
            int i = (int)((x-10) / 40) + 10;
            if (remainingGoat[i])
            {
                selectedGoat = i;
                remainingGoat[i] = false;
                dragging = true;
            }
        }
        
        // If we are in phase 2 then see if a goat has been selected
        if (phase == 2)
            // If the the user has clicked within the board
            if (x >= 20 && x <= 450 && y >= 20 && y <= 450)
            {
                int i = (int)((x / 100.0) + 0.25), j = (int)((y / 100.0) + 0.25);
                if (b(i,j) == 1)
                {
                    draggedPieceX = i;
                    draggedPieceY = j;
                    board[i][j] = 0;
                    dragging = true;
                }
                /*
                if (draggedPieceX < 0)
                    draggedPieceX = 0;
                if (draggedPieceX > 4)
                    draggedPieceX = 4;
                if (draggedPieceY < 0)
                    draggedPieceY = 0;
                if (draggedPieceY > 4)
                    draggedPieceY = 4;*/                
            }
    }
    
    public void init()
    {
        offscreen = createImage (500, 500);
        g2 = offscreen.getGraphics ();
        try { base = getDocumentBase (); } catch (Exception e) {}
        setLayout (null);
        newGameBtn = new Button ("New Game");
        add (newGameBtn);
        newGameBtn.addActionListener (this);
        newGameBtn.setBounds (410, 460, 80, 30);
        nextLevelBtn = new Button ("Next Level");
        add (nextLevelBtn);
        nextLevelBtn.addActionListener (this);
        nextLevelBtn.setBounds (200, 225, 100, 50);
        nextLevelBtn.setVisible (false);
        addMouseMotionListener (this);
        addMouseListener (this);
    }

    public void start()
    {
        nextLevelBtn.setVisible (false);
        resetBoard ();
        phase = 1;
        loadImages (1);
        repaint ();
        draggedPieceX = draggedPieceY = -1;
    }
    
    boolean endOfPhase1 ()
    {
        for (int i = 0; i < 20; i++)
            if (remainingGoat[i])
                return false;

        return true;
    }
    
    boolean canMoveDownLeft (int i, int j)
    {
        if (i == 0 || j == 4)
            return false;
            
        if (i + j == 4)
            return true;
            
        if (i == 2 && j == 0 || i == 1 && j == 1)
            return true;
            
        if (i == 4 && j == 2 || i == 3 && j == 3)
            return true;
            
        return false;
    }
    
    boolean canMoveDownRight (int i, int j)
    {
        if (i == 4 || j == 4)
            return false;
    
        if (i == j || (i == 0 && j == 2) || (i == 1 && j == 3) || (i == 2 && j == 0) || (i == 3 && j == 1))
            return true;
            
        return false;
    }
    
    boolean canMoveUpRight (int i, int j)
    {
        if (j == 0)
            return false;

        if (i + j == 4 || (i == 0 && j == 2) || (i == 1 && j == 1) || (i == 2 && j == 4) || (i == 3 && j == 3))
            return true;
    
        return false;
    }

    boolean canMoveUpLeft (int i, int j)
    {
        if (j == 0 || i == 0)
            return false;

        if (i == j || (i == 1 && j == 3) || (i == 2 && j == 4) || (i == 3 && j == 1) || (i == 4 && j == 2))
            return true;
            
        return false;
    }

    void updatePossibleMoves ()
    {
        possibleMoves.clear ();
        for (int i = 0; i < 5; i++)
            for (int j = 0; j < 5; j++)
                // if the square contains a tiger
                if (board[i][j] == 2)
                {
                    // can move down?
                    if (j < 4)
                    {
                        if (board[i][j+1] == 0)
                            possibleMoves.add (new Move(i, j, i, j + 1, board));
                        else if (j < 3 && board[i][j+1] == 1 && board[i][j+2] == 0)
                            possibleMoves.add (new Move(i, j, i, j + 2, board));                
                    }
                    
                    // can move up?
                    if (j > 0)
                    {
                        if (board[i][j-1] == 0)
                            possibleMoves.add (new Move(i, j, i, j - 1, board));
                        else if (j > 1 && board[i][j-1] == 1 && board[i][j-2] == 0)
                            possibleMoves.add (new Move(i, j, i, j - 2, board));
                    }
                    
                    // can move left?
                    if (i > 0)
                    {
                        if (board[i-1][j] == 0)
                            possibleMoves.add (new Move(i, j, i - 1, j, board));
                        else if (i > 1 && board[i-1][j] == 1 && board[i-2][j] == 0)
                            possibleMoves.add (new Move(i, j, i - 2, j, board));
                    }
                    
                    // can move right?
                    if (i < 4)
                    {
                        if (board[i+1][j] == 0)
                            possibleMoves.add (new Move(i, j, i + 1, j, board));
                        else if (i < 3 && board[i+1][j] == 1 && board[i+2][j] == 0)
                            possibleMoves.add (new Move(i, j, i + 2, j, board));
                    }
                    
                    // can move diagonal down-left?
                    if (i > 0 && j < 4 && canMoveDownLeft (i, j))
                    {
                        if (board[i-1][j+1] == 0)
                            possibleMoves.add (new Move(i, j, i - 1, j + 1, board));
                        else if (i > 1 && j < 3 && board[i-1][j+1] == 1 && board[i-2][j+2] == 0)
                            possibleMoves.add (new Move(i, j, i - 2, j + 2, board));
                    }
                    
                    // can move diagonal down-right?
                    if (i < 4 && j < 4 && canMoveDownRight (i, j))
                    {
                        if (board[i+1][j+1] == 0)
                            possibleMoves.add (new Move(i, j, i + 1, j + 1, board));
                        else if (i < 3 && j < 3 && board[i+1][j+1] == 1 && board[i+2][j+2] == 0)
                            possibleMoves.add (new Move(i, j, i + 2, j + 2, board));                    
                    }
                    
                    // can move diagonal up-left?
                    if (i > 0 && j > 0 && canMoveUpLeft (i, j))
                    {
                        if (board[i-1][j-1] == 0)
                            possibleMoves.add (new Move(i, j, i - 1, j - 1, board));
                        else if (i > 1 && j > 1 && board[i-1][j-1] == 1 && board[i-2][j-2] == 0)
                            possibleMoves.add (new Move(i, j, i - 2, j - 2, board));
                    }
                    
                    // can move diagonal up-right?
                    if (i < 4 && j > 0 && canMoveUpRight (i, j))
                    {
                        if (board[i+1][j-1] == 0)
                            possibleMoves.add (new Move(i, j, i + 1, j - 1, board));
                        else if (i < 3 && j > 1 && board[i+1][j-1] == 1 && board[i+2][j-2] == 0)
                            possibleMoves.add (new Move(i, j, i + 2, j - 2, board));
                    }
                }
    }
    
    public boolean isTakingMove (Move m)
    {
        return (m.x1 - m.x2 == 2 || m.x2 - m.x1 == 2 || m.y1 - m.y2 == 2 || m.y2 - m.y1 == 2);
    }
    
    void doAI_1 ()
    {
        // If it isn't possible to take then make a random move
        if (!tryToTake())
            doMove ((Move)(possibleMoves.get((int)(Math.random()*possibleMoves.size()))));
    }
    
    int b(int i, int j)
    {
        if (i < 0 || i > 4 || j < 0 || j > 4)
            return -1;
            
        return board[i][j];
    }
    
    int b(int[][] a, int i, int j)
    {
        if (i < 0 || i > 4 || j < 0 || j > 4)
            return -1;
            
        return a[i][j];
    }
    
    int[][] copyBoard ()
    {
        int[][] a = new int[5][5];
        for (int i = 0; i < 5; i++)
            for (int j = 0; j < 5; j++)
                a[i][j] = board[i][j];

        return a;
    }
    
    int numberOfPiecesThreatened (int[][] brd)
    {
        int r = 0;
        for (int i = 0; i < 5; i++)
            for (int j = 0; j < 5; j++)
                if (brd[i][j] == 2)
                {
                    if (i > 1)
                    {
                        if (j > 1 && brd[i-1][j-1] == 1 && brd[i-2][j-2] == 0)
                            r++;
                        if (brd[i-1][j] == 1 && brd[i-2][j] == 0)
                            r++;
                        if (j < 3 && brd[i-1][j+1] == 1 && brd[i-2][j+2] == 0)
                            r++;
                    }
                    if (j < 3 && brd[i][j+1] == 1 && brd[i][j+2] == 0)
                        r++;
                    if (i < 3)
                    {
                        if (j < 3 && brd[i+1][j+1] == 1 && brd[i+2][j+2] == 0)
                            r++;
                        if (brd[i+1][j] == 1 && brd[i+2][j] == 0)
                            r++;
                        if (j > 1 && brd[i+1][j-1] == 1 && brd[i+2][j-2] == 0)
                            r++;
                    }
                    if (j > 1 && brd[i][j-1] == 1 && brd[i][j-2] == 0)
                        r++;
                }
    
        return r;
    }
    
     /**
     * #1: Try to take
     * #2: Try to make a move that will threaten more then one piece
     * #3: Try to make a move that will threaten one piece
     * #4: Make any random move
     */
    void doAI_2 ()
    {
        if (tryToTake())
            return;
        
        int s = possibleMoves.size ();
        ArrayList threatensOne = new ArrayList(), threatensMany = new ArrayList ();
        for (int x = 0; x < s; x++)
        {
            int[][] brd = copyBoard ();
            Move m = (Move) (possibleMoves.get(x));
            brd[m.x2][m.y2] = brd[m.x1][m.y1];
            brd[m.x1][m.y1] = 0;
            int t = numberOfPiecesThreatened (brd);
            if (t == 1)
                threatensOne.add (m);
            else if (t > 1)
                threatensMany.add (m);
        }
        // #2:
        int s2 = threatensMany.size ();
        if (s2 > 0)
        {
            doMove ((Move) (possibleMoves.get((int)(Math.random()*s2))));
            return;
        }
        // #3:
        s2 = threatensOne.size ();
        if (s2 > 0)
        {
            doMove ((Move) (possibleMoves.get((int)(Math.random()*s2))));
            return;
        }
        
        // #4: pick any random move
        doMove ((Move)(possibleMoves.get((int)(Math.random()*s))));
    }
    
    void doAI_3 ()
    {
        // Make a list of all taking moves
        ArrayList takes = new ArrayList ();
        int s = possibleMoves.size (), s2;
        for (int i = 0; i < s; i++)
        {
            Move m = (Move)(possibleMoves.get(i));
            // check to see if a piece is being jumped over
            if (isTakingMove(m))           
            // If so then add this move to "takes"
                takes.add (m);
        }

        // If there are any taking moves then pick one at random
        s2 = takes.size ();
        if (s2 > 0)
        {
            doMove ((Move)(takes.get((int)(Math.random()*s2))));
            return;
        }
    
        // Make a list of all moves where tiger would be able to take next turn:
        for (int i = 0; i < 5; i++)
            for (int j = 0; j < 5; j++)
                // If square contains a tiger
                if (board[i][j] == 2)
                {
                    if (i > 1 && j > 1 && board[i-1][j-1] == 1 && board[i-2][j-2] == 0)
                        takes.add (new Move(i, j, i - 2, j - 2, board));
                    if (i > 1 && board[i-1][j] == 1 && board[i-2][j] == 0)
                        takes.add (new Move(i, j, i - 2, j, board));
                    if (i > 1 && j < 3 && board[i-1][j+1] == 1 && board[i-2][j+2] == 0)
                        takes.add (new Move(i, j, i - 2, j + 2, board));
                    if (j < 3 && board[i][j+1] == 1 && board[i][j+2] == 0)
                        takes.add (new Move(i, j, i, j + 2, board));
                    if (i < 3 && j < 3 && board[i+1][j+1] == 1 && board[i+2][j+2] == 0)
                        takes.add (new Move(i, j, i + 2, j + 2, board));
                    if (i < 3 && board[i+1][j] == 1 && board[i+2][j] == 0)
                        takes.add (new Move(i, j, i + 2, j, board));
                    if (i < 3 && j > 1 && board[i+1][j-1] == 1 && board[i+2][j-2] == 0)
                        takes.add (new Move(i, j, i + 2, j - 2, board));
                    if (j > 1 && board[i][j-1] == 1 && board[i][j-2] == 0)
                        takes.add (new Move(i, j, i, j - 2, board));
                }
        // If there are any such moves then pick one at random
        s2 = takes.size();
        if (s2 > 0)
        {
            doMove ((Move)(takes.get((int)(Math.random()*s2))));
            return;
        }
        
        // Otherwise try to move most isolated goat (the goat with least adjacent goats)
        
        
        // Otherwise make any random move
        doMove ((Move)(possibleMoves.get((int)(Math.random()*possibleMoves.size()))));
    }

    void doAI ()
    {
        updatePossibleMoves ();
        if (possibleMoves.size() == 0)
        {
            level++;
            phase = 3;
            repaint ();
            nextLevelBtn.setVisible (true);
            return;
        }
        
        switch (level)
        {
        case 1: doAI_1(); break;
        case 2: doAI_2(); break;
        default: case 3: doAI_3(); break;
        }
        repaint ();
    }
    
    boolean tryToTake ()
    {
        ArrayList takingMoves = new ArrayList ();
        
        int s = possibleMoves.size(), s2;
        for (int i = 0; i < s; i++)
        {
            Move m = (Move)(possibleMoves.get(i));
            if (isTakingMove (m))
                takingMoves.add (m);
        }
        s2 = takingMoves.size ();
        if (s2 > 0)
        {
            doMove ((Move)(takingMoves.get((int)(Math.random()*s2))));
            return true;
        }
    
        return false;
    }
    
    void doMove (Move m)
    {
        board[m.x2][m.y2] = board[m.x1][m.y1];
        board[m.x1][m.y1] = 0;
        
        // If this is a taking move then remove the middle piece
        if (isTakingMove (m))
            board[(m.x1+m.x2)>>1][(m.y1+m.y2)>>1] = 0;
    }

    void loadImages (int i)
    {
        level = i;
        String s1 = "1_Buckeye.gif", s2 = "";
        switch (i)
        {
        case 1: s2 = "1_BrownMoth.gif"; break;
        case 2: s2 = "2_Bunny.gif"; break;
        case 3: s2 = "3_Crab.gif"; break;
        case 4: s2 = "4_Snail.gif"; break;
        case 5: s2 = "5_FishGold.gif"; break;
        case 6: s2 = "6_FishBlue.gif"; break;
        case 7: s2 = "7_CoolShark.gif"; break;
        }
        
        goat = getImage (base, s1);
        tiger = getImage (base, s2);
        
        congrats = getImage (base, "congrats.gif");
    }
    
    void resetBoard ()
    {
        for (int i = 0; i < 20; i++)
            remainingGoat[i] = true;
            
        for (int i = 0; i < 5; i++)
            for (int j = 0; j < 5; j++)
                board[i][j] = 0;
        board[0][0] = board[4][0] = board[0][4] = board[4][4] = 2;
    }
    
    void drawBoard ()
    {
        // draw black outline of board
        g2.setColor (Color.black);
        g2.drawRect (30, 30, 400, 400);
        for (int i = 0; i < 3; i++)
        {
            int j = 130 + (100*i);
            g2.drawLine (30, j, 430, j);
            g2.drawLine (j, 30, j, 430);
        }
        g2.drawLine (30, 30, 430, 430);
        g2.drawLine (30, 230, 230, 430);
        g2.drawLine (230, 30, 430, 230);
        g2.drawLine (30, 230, 230, 30);
        g2.drawLine (230, 30, 430, 230);
        g2.drawLine (230, 430, 430, 230);
        g2.drawLine (30, 430, 430, 30);
        
        // Draw the goat and tiger images
        for (int i = 0; i < 5; i++)
            for (int j = 0; j < 5; j++)
                if (board[i][j] != 0)
                {
                    Image im = board[i][j] == 1 ? goat : tiger;
                    g2.drawImage (im, 14 + (i*100), 14 + (j*100), this);
                }
    
    }
    
    void drawRemainingGoats ()
    {
        for (int i = 0; i < 10; i++)
            if (remainingGoat[i])
                g2.drawImage (goat, 460, 10 + (i * 40), this);
        for (int i = 0; i < 10; i++)
            if (remainingGoat[i+10])
                g2.drawImage (goat, 10 + (i * 40), 460, this);            
    }
    
    public void update (Graphics g)
    {
        paint (g);
    }

    public void paint(Graphics g)
    {
        // Clear the offscreen surface
        g2.setColor (bgColor);
        g2.fillRect (0, 0, 500, 500);
        
        if (phase > 2)
        {
            g2.setColor (bgColor);
            g2.fillRect (0, 0, 500, 500);
            g2.setColor (Color.black);
            g2.drawImage (congrats, 70, 80, this);
            String s;
            if (level > 7)
            {
                s = "You have completed Bagha Chal";
                nextLevelBtn.setVisible (false);            
            }
            else
                s = "Now try level " + level;
            g2.setFont (new Font("SansSerif", 0, 34));
            g2.drawString (s, 250 - (g2.getFontMetrics().stringWidth(s) >> 1) , 350);
            
            // Draw victory animation
            
            g.drawImage (offscreen, 0, 0, this);
            return;
        }
        // if we are still waiting for images to download then display a "loading" message
        if (phase == 0)
        {
            g2.setColor (bgColor);
            g2.fillRect (0, 0, 500, 500);
            g2.drawString ("Downloading images...", 50, 50);
            g.drawImage (offscreen, 0, 0, this);
            return;
        }
        
        drawBoard ();
        drawRemainingGoats ();
        
        if (dragging)
            g2.drawImage (goat, mouseX, mouseY, this);
                
        // Blt the offscreen image to screen
        g.drawImage (offscreen, 0, 0, this);
    }

}
