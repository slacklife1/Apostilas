
package net.phbwt.jtans.guiinfo;


import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;
import java.net.*;
import java.io.*;


public class InfoWindowController {

    public static final String VERSION = "1.0";

    /** package des resource i18n (bundle et html) */
    private static final String LOCATION = "net.phbwt.jtans.i18n";

    private static ResourceBundle i18n = ResourceBundle.getBundle(LOCATION + ".info");

    private Icon aboutIcon = null;
    private String aboutMsg = null;

    private JDialog helpWindow = null;

//      private static JComponent infoComponent = null;

    public void showAboutWindow() {
	
	if ( aboutMsg == null ) {
	    aboutMsg = 
		"<html><head></head><body>"
		+ "<b>jTans</b>  v" + VERSION + "<br>"
		+ "http://jtans.sourceforge.net<br><br>"
		+ "<b>Philippe Banwarth</b><br>"
		+ "bwt@altern.org<br><br>"
		+ i18n.getString("translator")
		+ "</body></html>";
	} 

	if ( aboutIcon == null ) {
	    aboutIcon = new ImageIcon(InfoWindowController.class.getResource("jTans.jpg"));
	} 

	JOptionPane.showMessageDialog( null,
				       aboutMsg,
				       "jTans",
				       JOptionPane.INFORMATION_MESSAGE,
				       aboutIcon );
    }


    public void showHelpWindow() {
	
	if ( helpWindow == null ) {


	    // texte principal

	    JEditorPane pane;
	    
	    try {
		String pageName = "/" + LOCATION.replace('.', '/')
		    + "/" + i18n.getString("help.htmlpage");

		URL pageUrl = InfoWindowController.class.getResource(pageName);

		pane = new JEditorPane(pageUrl);
		pane.addHyperlinkListener(new HyperlinkListener(){
			public void hyperlinkUpdate(HyperlinkEvent e) {
			    if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
				JEditorPane pane = (JEditorPane) e.getSource();
				try {
				    pane.setPage(e.getURL());
				} catch (IOException ioe) {
				    System.err.println("*WARNING*: can't load URL " + e.getURL());
				    ioe.printStackTrace(System.err);
				}
			    }
			}
		    });

	    } catch (IOException e) {
		pane = new JEditorPane("text/html", "Can't find help, sorry :" + e.getMessage());
	    }

	    pane.setEditable(false);

	    JComponent helpComponent = new JScrollPane(pane);
	    helpComponent.setPreferredSize(new Dimension(500, 400));


	    // boutton fermeture

/// 	    JButton closeButton = new JButton(i18n.getString("help.close"));
/// 	    closeButton.addActionListener(new ActionListener() {
/// 		    public void actionPerformed(ActionEvent e) {
/// 			helpWindow.hide();
/// 			helpWindow.dispose();
/// 		    }
/// 		});


	
	    Box mainBox = Box.createVerticalBox();
//  	mainBox.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
	    mainBox.add(helpComponent);
//  	    mainBox.add(Box.createGlue());
//  	    mainBox.add(new JSeparator());
//  	    mainBox.add(Box.createGlue());
///	    mainBox.add(closeButton);


// 	    JOptionPane.showMessageDialog(null,
// 					  mainBox,
// 					  i18n.getString("help.title"),
// 					  JOptionPane.INFORMATION_MESSAGE,
// 					  null);
 	    helpWindow = new JDialog();
	    helpWindow.setTitle(i18n.getString("help.title"));
	    helpWindow.setModal(false);
 	    helpWindow.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
 	    helpWindow.getContentPane().add(mainBox);
	}


//  	JOptionPane.showMessageDialog( null,
//  				       helpComponent,
//  //    				       new JLabel(i18n.getString("help")),
//  //  				       new JScrollPane(new JLabel(i18n.getString("help"))),
//  				       "jTans",
//  				       JOptionPane.INFORMATION_MESSAGE,
//  				       null );

	helpWindow.pack();
	helpWindow.show();
    }


    public static void main (String[] args) {

	InfoWindowController test = new InfoWindowController();
	test.showHelpWindow();
	test.showAboutWindow();

//  	System.exit(0);
    }
}

