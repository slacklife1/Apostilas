
package net.phbwt.jtans.guicommon;

import net.phbwt.jtans.calc.*;

import java.io.*;
import java.util.*;
import java.net.*;


/**
 * Groupe de figure.
 * Bas�e sur un fichier ou une resource.
 */

public class FigureGroup implements Serializable, Config.ConfigItem {

    static final long serialVersionUID = 1;

    // nom de base des resources 
    private static final String RESOURCES_PATH = "net/phbwt/jtans/figures";

    // types
    public static final int FILE = 1;
    public static final int RESOURCE = 2;

    private int type;  // RESOURCE ou FILE

    private File file;              // pour le type FILE
    private String resourceName;    // pour le type RESOURCE

    private transient List fList = null;  // la liste
    private transient String name = null;  // le nom de base utilis� pour memoriser les figures trouv�es 

    private static String[] resources = null;  // liste des resources


    public FigureGroup() {
	type = RESOURCE;
	resourceName = "default.figures";
	file = null;
    }


    public FigureGroup(int t, String resName, String fileName) {
	type = t;
	resourceName = resName;
	file = (fileName == null) ? null : new File(fileName);
    }


    /**
     * Get the value of type.
     * @return value of type.
     */

    public int getType() {
	return type;
    }
    

    /**
     * Set the value of type.
     * @param v  Value to assign to type.
     */

    public void setType(int  v) {
	this.type = v;
	fList = null;
	name = null;
    }
    

    public File getFile() {
	return file;
    }
    

    public void setFile(File  v) {
	this.file = v;
	fList = null;
	name = null;
    }
    

    public String getResourceName() {
	return resourceName;
    }

    
    public void setResourceName(String  v) {
	this.resourceName = v;
	fList = null;
	name = null;
    }
    

    /**
     * Renvoi le nom de base. 
     */

    public String getName() {
	if ( name == null ) {
	    switch ( type ) {
	    case FILE:
		name = (file != null) ? file.getName() : "no file" ;
		break;
		
	    case RESOURCE:
		name = resourceName.substring(resourceName.lastIndexOf('/') + 1);
		break;
		
	    default:
		System.err.println("*error* : type de FigureList inconnu");
		name = "";
		break;
	    }
	} 

	return name;
    }


    /**
     * Cherche la liste des resources disponibles.
     * La liste est construite au premier appel � partir
     * du/des fichier(s) texte 'figureResourceList.txt' plac� avec les classes.
     *
     * @return la liste sous forme de tableau, �ventuellement de taille 0
     *         (entre autre si le fichier n'existe pas).
     */

    public static String[] getResources() {
	
	if ( resources == null ) {
	    
	    Collection coll = new TreeSet(); // ignore les copie et trie le contenu

	    try {

		String rName = RESOURCES_PATH + "/figureResourceList.txt";

		for ( Enumeration e = Surface.class.getClassLoader().getResources(rName);
		      e.hasMoreElements(); ) {
		    
		    InputStream is = ((URL) e.nextElement()).openStream();
		    if ( is != null ) {
			BufferedReader in = new BufferedReader(new InputStreamReader(is));
			
			String s;
			while ( (s = in.readLine()) != null ) {
			    s = s.trim();
			    if ( !"".equals(s) ) {
				coll.add(s);
			    }
			} 
			
			in.close();
		    }
		} 
	    } catch (IOException e) {
		e.printStackTrace(System.err);
	    }

	    resources = (String[]) coll.toArray(new String[0]);
	} 
	
	return resources;
    }


    /**
     * Renvoi la liste de figures correspondant.
     * Apr�s l'avoir instanci� si n�cessaire.
     *
     * @return un Paint, Color.black si le type n'est pas initialis�.
     *
     * @throws Exception vari�es si une texture n'est pas trouv�e.
     */

    public List getList() throws Exception {

	if ( fList == null ) {
		
	    switch ( type ) {
		
	    case FILE:
		if ( file != null ) {
		    fList = loadFigures(file.toURL());
		} else {
		    throw new RuntimeException("pas de fichier");
		} 
		
		break;
		
	    case RESOURCE:
		if (resourceName != null ) {
		    URL url = Surface.class.getResource("/" + RESOURCES_PATH + "/" + resourceName);
		    if ( url == null ) {
			throw new RuntimeException( "pas trouve la resource figures : "
						    + resourceName );
		    } 
		    fList = loadFigures(url);
		} else {
		    throw new RuntimeException("pas de nom de ressource");
		} 
		
		break;
	    }
	} 
	
	return fList;
    }


    /**
     * M�thode utilitaire : Renvoi la liste de figures, avec une valeur par defaut.
     * Apr�s l'avoir instanci� si n�cessaire.
     *
     * @return un Paint, Color.black si le type n'est pas initialis�.
     *
     * @throws Exception vari�es si une texture n'est pas trouv�e.
     */

    public List getListNoError() {

	List ret;
	
	try {

	    ret = getList();

	} catch (Exception e) {
	    ret = new ArrayList();
	    ret.add(new CalcFigure.StoredFigure());
	    name = "none";
	    
	    System.err.println("*INFO*: pas trouve les figures");
	    e.printStackTrace(System.err);
	}

	return ret;
    }


    /**
     * Charge les figures.
     */

    private List loadFigures(URL nom) throws IOException {

	long time = System.currentTimeMillis();

	List list = new ArrayList();
	
	Reader in = new BufferedReader(new InputStreamReader(nom.openStream()));
	StreamTokenizer st = new StreamTokenizer(in);
	st.ordinaryChars('+', '9');
	st.wordChars('+', '9');
	st.eolIsSignificant(true);
//  	    st.parseNumbers();
	
	int figNumber;
	try {
	    st.nextToken();
	    st.nextToken();
	    st.nextToken();
	    figNumber = Integer.parseInt(st.sval);
	    st.nextToken();
	} catch (Exception e) {
	    // catch juste pour avoir un message plus explicite
	    throw new RuntimeException("bad format line 1 : " + e);
	} 
	
	for ( int i = figNumber - 1 ; i >= 0 ; i-- ) {
	    list.add(new CalcFigure.StoredFigure(st));
	} 
	
	in.close();

	System.err.println("*INFO*: chargement des figures :" + (System.currentTimeMillis() - time));

	return list;
    }


    /**
     *
     */

    public String toString() {

	return "FigureGroup:type=" + type
	    + ":resource=" + resourceName
	    + ":file=" + file;
    }


    /**
     * test.
     */

    public static void main (String[] args) {
	try {
	    String[] strs = getResources();

	    System.out.println("*****");

	    for ( int i = 0; i < strs.length; i++) {
		System.out.println(strs[i]);
	    }

	    System.out.println("*****");
	     
	} catch (Exception e) {
	    e.printStackTrace();
	} 
    } 

    public Object clone() throws CloneNotSupportedException {
	return super.clone();
    }
} 

