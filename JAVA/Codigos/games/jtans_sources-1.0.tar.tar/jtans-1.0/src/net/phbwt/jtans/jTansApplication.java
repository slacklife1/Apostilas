
package net.phbwt.jtans;

import net.phbwt.jtans.guicommon.*;

import java.io.*;
import java.util.Locale;
import java.util.zip.*;


public class jTansApplication extends AbstractApplication {
    
    private static final String CONFIG_NAME = ".jTans.config.gz";


    public static void main(String[] args){
//  	Locale.setDefault(new Locale("es", "ES"));

	jTansApplication jt = new jTansApplication();
	jt.start();
    }
    

    protected Config retrieveConfig() {
	
	Config ret;

	try {

	    ObjectInputStream ois = new ObjectInputStream(new GZIPInputStream(new BufferedInputStream(new FileInputStream(System.getProperty("user.home") + "/" + CONFIG_NAME))));
	    ret = (Config) ois.readObject();
	    ois.close();
	} catch (Exception e) {
	    System.err.println("*INFO*:can't find/load preferences");
	    e.printStackTrace(System.err);
	    ret = new Config();
	}

	return ret;
    }


    protected void saveConfig(Config cf) {

	try {
	    
	    ObjectOutputStream oos = new ObjectOutputStream(new GZIPOutputStream(new BufferedOutputStream(new FileOutputStream(System.getProperty("user.home") + "/" + CONFIG_NAME))));
	    
	    oos.writeObject(config);
	    
	    oos.close();
	    
	} catch (Exception ex) {
	    System.err.println("*INFO*: Can't save config:");
	    ex.printStackTrace(System.err);
	} 
    }
}    

