
package net.phbwt.jtans.guiconfig;

import net.phbwt.jtans.guicommon.*;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.JSlider;
import javax.swing.event.*;


/**
 * Contient juste une m�thode statique.
 */

final class TraitComponentGroup {

    /**
     * Ajoute un groupe composants g�rant un Trait.
     * Les composant sont plac� dans le GridBagLayout d'un autre composant.
     * Ne g�n�re pas d'�v�nement : affiche les dialog et
     * met � jour le Trait.
     */

    static void addGroup( final JComponent parent,
			  final Trait tr,
			  String label,
			  GridBagConstraints gbc,
			  ResourceBundle i18n ) {

	//
	// Construction des composants 
	//

	// zone d'affichage d'exemple
	final TraitExampleComponent exampleArea = new TraitExampleComponent(tr);


	// slider largeur du trait
	final JSlider widthComp = new JSlider( 100,
					       1000,
					       (int) (tr.getWidth() * 100) );
	widthComp.setPaintTicks(true);
	widthComp.setMinorTickSpacing(100);
	widthComp.addChangeListener( new ChangeListener() {
		public void stateChanged(ChangeEvent e) {
		    tr.setWidth(((JSlider) e.getSource()).getValue() / 100f);
		    exampleArea.repaint();
		}
	    });


	// choix d'une couleur
	final JButton chooseButton = new JButton(i18n.getString("trait.choose"));
	chooseButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {

		    Color col = JColorChooser.showDialog(parent, null, tr.getColor());
		    if ( col != null ) {
			tr.setColor(col);
		    } 
	
		    exampleArea.repaint();
		}
	    });
	

	//
	// Ajout des composants
	//

	GridBagLayout gbl = (GridBagLayout)parent.getLayout();
	JComponent comp;

	gbc.anchor = GridBagConstraints.CENTER;

//    	gbc.gridx++;
	gbc.weightx = 0;
	gbc.weighty = 0;
	gbc.fill = GridBagConstraints.HORIZONTAL;
	comp = new JLabel(label);
	gbl.setConstraints(comp, gbc);
	parent.add(comp);

  	gbc.gridx++;

  	gbc.gridx++;
	comp = chooseButton;
	gbl.setConstraints(comp, gbc);
	parent.add(comp);

  	gbc.gridx ++;
	comp = widthComp;
	gbl.setConstraints(comp, gbc);
	parent.add(comp);

  	gbc.gridx++;
	gbc.weightx = 1.0;
	gbc.weighty = 1.0;
	gbc.fill = GridBagConstraints.BOTH;
	comp = exampleArea;
	gbl.setConstraints(comp, gbc);
	parent.add(comp);
    }
}

