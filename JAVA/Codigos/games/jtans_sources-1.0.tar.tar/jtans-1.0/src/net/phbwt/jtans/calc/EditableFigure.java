
package net.phbwt.jtans.calc;

import java.util.*;
import java.awt.Point;


/**
 * Figure en coordonn�es d'affichage (i.e. en pixel) pouvant modifier la CalcFigure encapsul�e.
 * Ajoute :
 * - la notion "d'ordre d'empilement".
 * - une pi�ce selectionn�e (il y en a toujours une).
 * - des limites d'affichage (et les m�thodes maintenant les pi�ces dedans).
 * - une rotation 'quantifi�e'.
 */

public class EditableFigure extends PixelFigure {

    // les formes affichables correspondant aux pi�ces non selectionn�es
    private List shapes;

    // la forme affichable correspondant � la piece selectionn�e (il y en a toujours une)
    private PixelPiece selectedDisplayPiece;

    // la piece pr�c�demment selectionn�e (ou null)
    private PixelPiece previousSelectedPiece = null;

    // pour la rotation par step
    private boolean isRotStep = true;
    private double stepStart = 0;
    private double stepVal = Math.PI / 16;

    int xMin, xMax, yMin, yMax;  // limites d'affichage


    public EditableFigure(CalcFigure figure) {
	calcFig = figure;

	shapes = new ArrayList();

	for ( Iterator i = calcFig.pieceIterator(); i.hasNext(); ) {
	    shapes.add(new PixelPiece(this, (CalcPiece) i.next()));
	} 

	selectedDisplayPiece = (PixelPiece) shapes.remove(0);
    }


    public void setScale(double newScale) {
	scale = newScale;

	for ( Iterator i = shapes.iterator(); i.hasNext(); ) {
	    ((PixelPiece) i.next()).resetShape();
	} 

	selectedDisplayPiece.resetShape();
	super.reset();
    }


    /**
     * Change les limites de la figure.
     * V�rifie que les pi�ces sont � l'int�rieur. 
     */

    public void setLimits(int x1, int y1, int x2, int y2) {
	xMin = x1;
	xMax = x2;
	yMin = y1;
	yMax = y2;

	for ( Iterator i = shapes.iterator(); i.hasNext(); ) {
	    ensurePieceIsInLimits((PixelPiece) i.next(), 0, 0);
	} 

	ensurePieceIsInLimits(selectedDisplayPiece, 0, 0);
    }


    public void setSteppedRotation(double v, double s) {
	if ( v > 0 ) {
	    isRotStep = true;
	    stepStart = s;
	    stepVal = v;

	    for ( Iterator i = shapes.iterator(); i.hasNext(); ) {
		PixelPiece pp = (PixelPiece) i.next();
		pp.setRotation(constrainRotation(pp.getRotation()));
	    } 

	    setRotationForSelectedPiece(selectedDisplayPiece.getRotation());

	} else {
	    isRotStep = false;
	}
    }


//      public int getSelectedPiecePosX() {
//  	return (int)(calcFig.pieces[CalcFigure.PIECE_SELECTED].posX * scale + ARON) + refX;
//      }


//      public int getSelectedPiecePosY() {
//  	return (int)(calcFig.pieces[CalcFigure.PIECE_SELECTED].posY * scale + ARON) + refY;
//      }


//      public double getSelectedPieceRotation() {
//  	return selectedDisplayPiece.getRotation();
//      }


    public PixelPiece getSelectedPiece() {
	return selectedDisplayPiece;
    }


    /**
     * Renvoi la pr�c�dente pi�ce selectionn�e (�ventuellement null).
     * C'est une r�f�rence � une pi�ce faisant partie des pi�ces non selectionn�es. 
     */

    public PixelPiece getPreviousSelectedPiece() {
	return previousSelectedPiece;
    }


    /**
     * Renvoi un Iterator sur les pi�ces non selectionn�es
     * commen�ant par la pi�ce la plus en dessous.
     */

    public Iterator pieceIteratorBottomUp() {
	return shapes.iterator();
    }


    /**
     * Renvoi un Iterator sur les pi�ces non selectionn�es
     * commen�ant par la pi�ce la plus au dessus.
     */

    public Iterator pieceIteratorTopDown() {

	final int first = shapes.size();
	
	return new Iterator() {
		
		int index = first;

		public boolean hasNext() {
		    return index > 0;
		}

		public Object next() {
		    return shapes.get(--index);
		}

		public void remove() {
		    shapes.remove(index);
		}
	    };
    }


    /**
     * Modifie l'angle de la pi�ce selectionn�e.
     *
     * @return true si l'angle a effectivement chang�.
     */

    public boolean setRotationForSelectedPiece(double rot) {

	rot = constrainRotation(rot);

	if ( Math.abs(rot - selectedDisplayPiece.getRotation() ) < 1E-5 ) {
	    return false;
	} else {
	    selectedDisplayPiece.setRotation(rot);
	    return true;
	} 
    }


    /**
     * Modifie l'angle d'une pi�ce.
     * L'angle est ajust� suivant le type de rotation.
     *
     * @return true si l'angle a effectivement chang�
     *         ou si mode continue.
     */

    private double constrainRotation(double rot) {

	rot = CalcPiece.normalizeAngle(rot);

	if ( isRotStep ) {
//  	    System.out.print("rot1=" + rot);
	    rot -= stepStart - stepVal / 2;
//  	    System.out.print(":rot2=" + rot);
	    rot -= rot % stepVal;
//  	    System.out.print(":rot3=" + rot);
	    rot += stepStart;
//  	    System.out.println(":rot4=" + rot);
	}

	return rot;
    }
    

    /**
     * Flip la pi�ce selectionn�e.
     */

    public void flipSelectedPiece() {
	selectedDisplayPiece.flip();
    }


    /**
     * Modifie la pi�ce selectionn�e.
     */

    public Point translateSelectedPiece(int dx, int dy) {
	return ensurePieceIsInLimits(selectedDisplayPiece, dx, dy);
    }


    public static final int SEL_NONE = -1;
    public static final int SEL_ACTUAL = 0;
    public static final int SEL_NEW = 1;


    /**
     * D�termine la pi�ce se trouvant � une position donn�e.
     * Le cas �ch�ant la pi�ce est s�lectionn�e.
     *
     * @return SEL_ACTUAL, SEL_NEW ou SEL_NONE.
     */

    public int selectAt(int x, int y) {

	double xf = (x - refX) / scale;
	double yf = (y - refY) / scale;


	if ( selectedDisplayPiece.contains(xf, yf)) {
	    return SEL_ACTUAL;
	} else {
	    for ( Iterator i = pieceIteratorTopDown(); i.hasNext(); ) {
		PixelPiece currentShape = (PixelPiece) i.next();
		if ( currentShape.contains(xf, yf) ) {
		    i.remove();
		    shapes.add(selectedDisplayPiece); // ajoute � la fin (i.e. en haut)
		    
		    previousSelectedPiece = selectedDisplayPiece;
		    selectedDisplayPiece = currentShape;
		    return SEL_NEW;
		} 
	    } 

	    // aucune (mais ne d�selectionne pas celle �ventuellement d�j� selectionn�e)
	    return SEL_NONE;
	} 
    }


    private Point dumPoint = new Point();  // renvoy�

    /**
     * Translate la pi�ce pour qu'elle soit dans les limites.
     *
     * @param delta un d�placement � ajouter � la position.
     *        au retour contient le d�placement r�el.
     *
     * @return un Point contenant la translation effectu�e.
     *         Le point est r�utilis� � chaque appel.
     */

    private Point ensurePieceIsInLimits(PixelPiece p, int dx, int dy) {

	int x = p.getPosX();
	int y = p.getPosY();

	if ( x + dx < xMin ) {
	    dumPoint.x = xMin - x;
	} else if ( x + dx > xMax ) {
	    dumPoint.x = xMax - x;
	} else {
	    dumPoint.x = dx;
	} 
	
	if ( y + dy < yMin ) {
	    dumPoint.y = yMin - y;
	} else if ( y + dy > yMax ) {
	    dumPoint.y = yMax - y;
	} else {
	    dumPoint.y = dy;
	} 
	
	if ( dumPoint.x != 0 || dumPoint.y != 0) {
	    p.translate(dumPoint.x, dumPoint.y);
	} 

	return dumPoint;
    }
}  

