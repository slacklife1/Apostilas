
package net.phbwt.jtans.guicommon;

import java.awt.*;
import java.io.*;

/**
 * Repr�sente les param�tres d'un trait (largeur et couleur).
 */

public class Trait implements Serializable, Config.ConfigItem {

    static final long serialVersionUID = 1;

    private float width; // la largeur du trait
    private Color color;  // la couleur du trait

    private transient Stroke stroke = null; // Stroke correspondant � la largeur


    Trait() {}


    Trait(Color c, float w) {
	color = c;
	width = w;
    }


    /**
     * Get the value of width.
     * @return value of width.
     */

    public float getWidth() {
	return width;
    }
    

    /**
     * Set the value of width.
     * @param v  Value to assign to width.
     */

    public void setWidth(float  v) {
	this.width = v;
	stroke = null;
    }


    /**
     * Get the value of color.
     * @return value of color.
     */

    public Color getColor() {
	return color;
    }
    

    /**
     * Set the value of color.
     * @param v  Value to assign to color.
     */

    public void setColor(Color  v) {
	this.color = v;
    }


    /**
     * Renvoi la largeur dont il faut agrandir la zone entour� par le trait.
     */

    public int getGrow() {
	return (int)(width + 2F);
    }


    /**
     * Renvoi le Stroke correspondant.
     * Apr�s l'avoir instanci� si n�c�ssaire.
     *
     * @return un Stroke qui va bien.
     */

    public Stroke getStroke() {

	if ( stroke == null ) {

	    stroke = new BasicStroke(width, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL);
	}

	return stroke;
    }

    
    public Object clone() throws CloneNotSupportedException {
	return super.clone();
    }
} 

