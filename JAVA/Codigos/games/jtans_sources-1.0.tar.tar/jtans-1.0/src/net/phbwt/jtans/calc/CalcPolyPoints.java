
package net.phbwt.jtans.calc;


/**
 * Liste de points en flottants.
 * Sur le modele de Polygon.
 * Le nombre de points est donn� par npoints, PAS par la taille des tableaux.
 */

public class CalcPolyPoints {
    
    public double[] xpoints;
    public double[] ypoints;

    public int npoints;


    CalcPolyPoints(int nbr) {
	npoints = nbr;
	xpoints = new double[nbr];
	ypoints = new double[nbr];
    }

 
    /**
     * Constructeur permettant de r�server de la place pour des points suppl�mentaires.
     */

    CalcPolyPoints(int nbr, int nbrMax) {
	npoints = nbr;
	xpoints = new double[nbrMax];
	ypoints = new double[nbrMax];
    }

    
    /**
     * Constructeur � partir de tableaux existants.
     * Le nombre de points est d�termin� par la taille de x.
     * Les tableaux ne sont PAS copi�s.
     */

    CalcPolyPoints(double[] x, double[] y) {
	npoints = x.length;
	this.xpoints = x;
	this.ypoints = y;
	
    }

    
    /**
     * Concat�ne un CalcPolyPoints � la fin de celui-ci.
     * Il doit rester suffisament de points disponibles.
     *
     * @return l'index du premier point ajout�.
     */

    public int addCalcPolyPoints(CalcPolyPoints cp) {

	System.arraycopy(cp.xpoints, 0, xpoints, npoints, cp.npoints);
	System.arraycopy(cp.ypoints, 0, ypoints, npoints, cp.npoints);

	npoints += cp.npoints;

	return npoints - cp.npoints;
    }

    
    /**
     * Ajoute un points.
     * il doit rester de la place.
     * 
     * @return l'index du point ajout�.
     */

    public int addPoint(double x, double y) {
	xpoints[npoints] = x;
	ypoints[npoints] = y;
	
	return npoints++;
    } 


    public void clear() {
	npoints = 0;
    }


    /**
     * Calcule la direction d'un segment.
     * Compris entre -PI et PI.
     */

    double angle(int pnt1, int pnt2) {
	return Math.atan2(xpoints[pnt1] - xpoints[pnt2], ypoints[pnt1] - ypoints[pnt2]);
    }


    /**
     * Calcule le carr� de la distance entre deux points.
     *
     * @param pnt1 position du premier point.
     * @param pnt1 idem deuxi�me point.
     */

    double distSqr(int pnt1, int pnt2) {

	double dx = xpoints[pnt1] - xpoints[pnt2];
	double dy = ypoints[pnt1] - ypoints[pnt2];

	return dx * dx + dy * dy;
    }


    /**
     * Calcule le carre de la distance et le deplacement entre un point et un segment.
     *
     * @param seg0 index du point de debut du segment.
     * @param seg1 index du point de fi du segment.
     * @param pnt  index du point.
     * @param res  CalcPolyPoints contenant (au moins) un point dans lequel sera place
     *             le deplacement du vecteur au point (normal au vecteur).
     *             N'est pas modifi� si la projection n'est pas sur le segment.
     *             Peut �tre null.
     *
     * @return la distance entre le point et le segment ou 1E5 si la projection n'est pas
     *         sur le segment.
     */
    
    double distSegSqr(int seg0, int seg1, int pnt, CalcPolyPoints res) {

	double scal, dum;

	double segDx = xpoints[seg1] - xpoints[seg0];
	double segDy = ypoints[seg1] - ypoints[seg0];
	double resDx = xpoints[pnt] - xpoints[seg0];
	double resDy = ypoints[pnt] - ypoints[seg0];

	double segLenSqr = segDx * segDx + segDy * segDy;

	if ( (scal = (resDx * segDx) + (resDy * segDy)) < 0 ||
	     (dum = scal / segLenSqr) > 1 ) {
	    return 1E5;
	}

	resDx -= segDx * dum;
	resDy -= segDy * dum;
	
	if ( res != null ) {
	    res.xpoints[0] = resDx;
	    res.ypoints[0] = resDy;
	} 

	return resDx * resDx + resDy * resDy;
    }
}
