
package net.phbwt.jtans.calc;


/**
 * Polygone en flottant.
 * Sur le modele de Polygon.
 * Le nombre de points est donn� par npoints, PAS par la taille des tableaux.
 * Ajoute un attribut correspondat au type (plein ou vide).
 */

public final class CalcOutlinePolygon extends CalcPolyPoints{
    
    public int type;

    public static final int NORMAL = 5;
    public static final int BACK = 6;
    public static final int ON = 7;

    CalcOutlinePolygon(int pn, int pmax, int t) {
	super(pn, pmax);
	type = t;
    }
}
