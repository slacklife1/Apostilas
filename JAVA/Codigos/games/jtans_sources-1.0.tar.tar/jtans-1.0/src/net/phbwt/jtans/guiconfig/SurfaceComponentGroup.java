
package net.phbwt.jtans.guiconfig;

import net.phbwt.jtans.guicommon.*;

import java.awt.*;
import javax.swing.*;
import javax.swing.JSlider;
import java.awt.event.*;
import javax.swing.event.*;
import java.util.*;


/**
 * Contient juste une m�thode statique.
 */

final class SurfaceComponentGroup {

    private static String[] typeLabels = null;

    /**
     * Ajoute un groupe composants g�rant une Surface.
     * Les composant sont plac� dans le GridBagLayout d'un autre composant.
     * Ne g�n�re pas d'�v�nement : affiche les dialog et
     * met � jour la Surface.
     */

    public static void addGroup( final JComponent parent,
				 final Surface surf,
				 final String label,
				 GridBagConstraints gbc,
				 final JFileChooser fileChooser,
				 final ResourceBundle i18n ) {

	if ( typeLabels == null) {
	    typeLabels = new String[] {
		i18n.getString("surface.type.color"),
		i18n.getString("surface.type.base"),
		i18n.getString("surface.type.file")
	    };
	}

	if ( surf == null ) {
	    System.err.println("*WARNING*:config incomplete: manque " + label);
	    return;
	} 

	//
	// Construits les composants.
	//

	// zone d'exemple 
	final SurfaceExampleComponent exampleArea = new SurfaceExampleComponent(surf);
	
	// slider luminosit�
	final JSlider brightComp = new JSlider( 50,
						150,
						(int) (surf.getBrightness() * 100) );
	brightComp.setPaintTicks(true);
	brightComp.setMinorTickSpacing(10);
	brightComp.addChangeListener( new ChangeListener() {
		public void stateChanged(ChangeEvent e) {
		    JSlider src = (JSlider) e.getSource();
		    if ( !src.getValueIsAdjusting() ) {
			surf.setBrightness(src.getValue() / 100f);
			
  			exampleArea.repaint();
		    } 
		}
	    });
	    

	// combo type
	final JComboBox typeComp = new JComboBox(typeLabels);
	switch ( surf.getType() ) {
	case Surface.COLOR:
	    typeComp.setSelectedIndex(0);
	    brightComp.setEnabled(false);
	    break;
	    
	case Surface.BASE_TEXTURE:
	    typeComp.setSelectedIndex(1);
	    break;
	    
	case Surface.USER_TEXTURE:
	    typeComp.setSelectedIndex(2);
	    break;
	} 
	typeComp.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {

		    switch (((JComboBox) e.getSource()).getSelectedIndex()) {
		    case 0:
			surf.setType(Surface.COLOR);
			brightComp.setEnabled(false);
			break;
			
		    case 2:
			surf.setType(Surface.USER_TEXTURE);
			brightComp.setEnabled(true);
			break;
			
		    case 1:
			surf.setType(Surface.BASE_TEXTURE);
			brightComp.setEnabled(true);
			break;
		    } 

		    exampleArea.repaint();
		}
	    });

	// bouton "choisir..."
	final JButton chooseButton = new JButton(i18n.getString("surface.choose"));
	chooseButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {

		    try {

			switch ( surf.getType() ) {
			case Surface.COLOR:
			    Color col = JColorChooser.showDialog(parent, null, surf.getColor());
			    if ( col != null ) {
				surf.setColor(col);
			    } 
			    break;
			    
			case Surface.USER_TEXTURE:

			    if ( fileChooser == null ) {
				throw new Exception(i18n.getString("error.restricted"));
			    } 

			    if ( surf.getTextureFile() != null ) {
				fileChooser.setSelectedFile(surf.getTextureFile());
			    }
			    
			    if ( fileChooser.showOpenDialog(parent) == JFileChooser.APPROVE_OPTION ) {
				surf.setTextureFile(fileChooser.getSelectedFile());
			    } 
			    
			    break;
			    
			case Surface.BASE_TEXTURE:
			    String name = (String) JOptionPane.showInputDialog( parent,
										null,
										null,
										JOptionPane.QUESTION_MESSAGE,
										null,
										Surface.getBaseTextures(),
										surf.getBaseTextureName());
			    if ( name != null ) {
				surf.setBaseTextureName(name);
			    } 
			    break;
			    
			default:
			    break;
			}
			
			// teste la texture
			surf.getPaint(exampleArea);
			
		    } catch (Exception ex) {
			JOptionPane.showMessageDialog( exampleArea,
						       i18n.getString("error.surface.load")
						       + " : " + ex.getMessage() );
		    } 
		    
		    exampleArea.repaint();
		}
	    });
	

	//
	// Ajoute les composants.
	//

	GridBagLayout gbl = (GridBagLayout) parent.getLayout();
	JComponent comp;

	gbc.anchor = GridBagConstraints.CENTER;

//    	gbc.gridx++;
	gbc.weightx = 0d;
	gbc.weighty = 0d;
	gbc.fill = GridBagConstraints.HORIZONTAL;
	comp = new JLabel(label);
	gbl.setConstraints(comp, gbc);
	parent.add(comp);

  	gbc.gridx++;
	comp = typeComp;
	gbl.setConstraints(comp, gbc);
	parent.add(comp);

  	gbc.gridx++;
	comp = chooseButton;
	gbl.setConstraints(comp, gbc);
	parent.add(comp);

  	gbc.gridx++;
	comp = brightComp;
	gbl.setConstraints(comp, gbc);
	parent.add(comp);

  	gbc.gridx++;
	gbc.weightx = 1d;
	gbc.weighty = 1d;
	gbc.fill = GridBagConstraints.BOTH;
	comp = exampleArea;
	gbl.setConstraints(comp, gbc);
	parent.add(comp);
    }


//      private static void checkAndRepaint(Surface s, JComponent c, String l) {
	
//  	try {
//  	    s.getPaint(c);
	     
//  	} catch (Exception e) {
//  	    JOptionPane.showMessageDialog(c, "Can't get " + l + " : " + e.getMessage());
//  	} 
	
//  	c.repaint();
//      }
}

