
package net.phbwt.jtans.guimain;

import javax.swing.*;

/**
 * quick and (very) dirty status bar.
 */

class StatusBar extends JLabel {

    private String[] messages;
    private int currentLevel = -1;

    StatusBar(int max) {
	messages = new String[max];
    }

    public void setMessage(int level, String message) {

// 	long time = System.currentTimeMillis();
	
	messages[level] = message;

	if ( message == null ) {
	    if (level >= currentLevel) {
		for (currentLevel = level - 1; currentLevel >= 0 && messages[currentLevel] == null; currentLevel--);
		super.setText(currentLevel >= 0 ? messages[currentLevel] : "jTans");
	    }
	} else {
	    if (level >= currentLevel) {
		currentLevel = level;
		super.setText(message);
	    }
	}

// 	time = System.currentTimeMillis() - time;
// 	System.out.println("status set time" + time);
    }

    public void setText(String txt) {
	currentLevel = -1;
	super.setText(txt);
    }
}
