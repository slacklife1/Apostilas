
package net.phbwt.jtans.calc;


/**
 * Trap�ze
 */

public final class CalcPieceT extends CalcPiece {
    
    private static final double X = CC / 2;
    private static final double Y = (CC + CL) / 2;
    

    CalcPieceT(double x, double y, double r, boolean fl) {
	super(x, y, r, fl);
    }


    public void setFigure(CalcFigure cf) {
	init(cf, 4, 4);
    }


//      private void readObject( ObjectInputStream in )
//  	throws IOException, ClassNotFoundException {

//  	in.defaultReadObject();

//  	initTransient(4, 4);
//      }


    public CalcPolyPoints getPolygon() {

	if ( polygonLastChange != pieceChangeCount ) {
	    
	    double rot = rotation;
	    
	    double rotCos = Math.cos(rot);
	    double rotSin = Math.sin(rot);
	    
	    double prex = posX - (rotCos * X + rotSin * Y);
	    double prey = posY + (rotSin * X - rotCos * Y);

	    if ( isFlipped ) {

		xt[0] = prex;
		yt[0] = prey;
		    
		xt[1] = prex + rotCos * CC + rotSin * CC;
		yt[1] = prey - rotSin * CC + rotCos * CC;
		    
		xt[2] = prex + rotCos * CC + rotSin * (CC + CL);
		yt[2] = prey - rotSin * CC + rotCos * (CC + CL);
		    
		xt[3] = prex               + rotSin * CL;
		yt[3] = prey               + rotCos * CL;

	    } else {

		xt[0] = prex               + rotSin * CC;
		yt[0] = prey               + rotCos * CC;
		    
		xt[1] = prex + rotCos * CC;
		yt[1] = prey - rotSin * CC;
		    
		xt[2] = prex + rotCos * CC + rotSin * CL;
		yt[2] = prey - rotSin * CC + rotCos * CL;
		    
		xt[3] = prex               + rotSin * (CC + CL);
		yt[3] = prey               + rotCos * (CC + CL);
	    } 

	    polygonLastChange = pieceChangeCount;		
	} 
	
	return calcPolygon;
    }


    public void putInTinyTab() {
	if ( pieceTinyLastChange != pieceChangeCount ) {
		
	    double rot = rotation;
		
	    double rotCos = Math.cos(rot);
	    double rotSin = Math.sin(rot);
		
	    double prex = posX - (rotCos * X + rotSin * Y);
	    double prey = posY + (rotSin * X - rotCos * Y);
	
	    int index = tinyTabIndex;

	    if ( isFlipped ) {
		    
		index = putSmallTriangleAt( index,
					    prex + CC * rotCos + CC * rotSin,
					    prey - CC * rotSin + CC * rotCos,
					    rot + 5.0 * HT );
		    
		index = putSmallTriangleAt( index,
					    prex               + CL * rotSin,
					    prey               + CL * rotCos,
					    rot + 1.0 * HT );
	    } else {
		index = putSmallTriangleAt( index,
					    prex               + CC * rotSin,
					    prey               + CC * rotCos,
					    rot + 1.0 * HT );
		    
		index = putSmallTriangleAt( index,
					    prex + CC * rotCos + CL * rotSin,
					    prey - CC * rotSin + CL * rotCos,
					    rot + 5.0 * HT );
	    }
		
//  		index = putSmallTriangleAt( index,
//  				 prex + XX * rotCos + YY * rotSin,
//  				 prey - XX * rotSin + YY * rotCos,
//  				 rot + RR * HT );
		
	
	    pieceTinyLastChange = pieceChangeCount;		
	}	
    }
}
