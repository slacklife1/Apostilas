
package net.phbwt.jtans;

import net.phbwt.jtans.guimain.*;
import net.phbwt.jtans.guicommon.*;
import net.phbwt.jtans.guiconfig.ConfigWindow;
import net.phbwt.jtans.guiinfo.InfoWindowController;

import javax.swing.*;
import java.util.*;
import java.awt.event.*;


/**
 * La version Applet.
 * Observe MainWindow : "jtans.help" et "jtans.about".
 */

public class jTansApplet extends JApplet implements Observer {

    protected ConfigWindow configWindow;
    protected MainWindow mainWindow;
    protected InfoWindowController infoWindow;
    
    private Config config;

    private static ResourceBundle i18n = null;


    public void init() {

	if ( i18n == null ) {
	    i18n = ResourceBundle.getBundle("net.phbwt.jtans.i18n.main");
	} 

	//
	// la config
	//

	config = new Config();


	//
	// les fen�tres
	//

	mainWindow = new MainWindow(config);
	configWindow = new ConfigWindow(config);
	infoWindow = new InfoWindowController();

	mainWindow.fill(this);


	//
	// les menus : le premier (config) est cr��, les autres sont demand�s � MainWindow.
	//

	JMenu firstMenu = new JMenu(i18n.getString("menu.game"));
	firstMenu.add(i18n.getString("menu.game.configure")).addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    configWindow.show();
		}
	    });
	
	JMenuBar menuBar = new JMenuBar();
	menuBar.add(firstMenu);
	for ( Iterator i = mainWindow.getMenus().iterator(); i.hasNext(); ) {
	    menuBar.add((JMenu) i.next());
	}
	
	mainWindow.addObserver(this);

	setJMenuBar(menuBar);
    }


    /**
     * Gestion des evenement venants de MainWindow.
     */

    public void update(Observable obs, Object obj) {

	if ( "jtans.help".equals(obj)) {
	    infoWindow.showHelpWindow();
	} else if ( "jtans.about".equals(obj)) {
	    infoWindow.showAboutWindow();
	} 
    }
}

