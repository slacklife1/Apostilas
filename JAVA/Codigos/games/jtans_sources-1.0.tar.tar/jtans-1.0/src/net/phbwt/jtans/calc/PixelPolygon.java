
package net.phbwt.jtans.calc;

import java.awt.*;


/**
 * Polygone en pixels calcul� � partir d'un polygone en flottants.
 * Les points peuvent �tre modifi�s.
 * Les sous classes doivent fournir le polygone flottant.
 */

public abstract class PixelPolygon extends Polygon {

    protected static final double ARON = 0.39999;  // pour les arrondit

    protected PixelFigure figure;     // la figure dont fait partie cette pi�ce

    
    /**
     * Les sous classes doivent faire un resetShape() � la fin de leur constructeur.
     *
     * @param np le nb de points du polygone.
     */

    protected PixelPolygon(PixelFigure f, int np) {
	
	figure = f;

	xpoints = new int[np];
	ypoints = new int[np];
	npoints = np;

//  	resetShape();
    }


    /**
     * Recalcule les point de la shape � partir de la calcFigure
     * et du polygone fl.
     */

    public void resetShape() {

//  	System.out.println("shape reset");

	CalcPolyPoints cp = getPolygon();

	for ( int i = cp.npoints - 1; i >= 0 ; i-- ) {
	    xpoints[i] = (int)(cp.xpoints[i] * figure.scale + ARON) + figure.refX;
	    ypoints[i] = (int)(cp.ypoints[i] * figure.scale + ARON) + figure.refY;
	} 

  	resetBounds();
    }


    /**
     * Provoque un recalcul des limites lors du prochain affichage.
     */

    public void resetBounds() {
	bounds = null;
    }

    
    protected abstract CalcPolyPoints getPolygon();
}

