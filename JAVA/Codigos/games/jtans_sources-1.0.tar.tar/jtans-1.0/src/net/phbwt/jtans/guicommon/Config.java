
package net.phbwt.jtans.guicommon;

import net.phbwt.jtans.calc.CalcFigure;

import java.util.*;
import java.awt.*;
import java.io.*;
//  import java.io.Serializable;
//  import java.io.ObjectStreamException;


/**
 *  Classe contenant la config.
 *  Il est garanti qu'elle contient une valeur pour toutes les clefs.
 *  Bas�e sur une Hashmap.
 *
 *  Les RenderingHints sont g�r�s � part :
 *    - ils ne sont pas s�rializable
 *    - pour que la GUI puisse les g�rer par des index num�rique.
 *
 *  Le(s) Composite est g�r� comme un double. 
 */

public class Config extends Observable implements Serializable, Cloneable {

    static final long serialVersionUID = 1;

    public static final int ROTATION_CONTINUOUS = 13;
    public static final int ROTATION_STEP_32 = 14;
    public static final int ROTATION_STEP_AUTO = 15;


    // les propri�t�s de base
    private Map properties = new HashMap();
    // les figures d�j� trouv�es
    private Map solvedMap = null;

    private Hint[] hints;
    private transient RenderingHints renderingHints = null;


    /**
     * Interface rendant la m�thode clone() publique.
     * Pour �viter de l'appeler par introspection. 
     */

    public interface ConfigItem extends Cloneable {
	Object clone() throws CloneNotSupportedException;
    }


    /**
     * Constructeur d'une config ayant les valeurs par d�faut.
     */

    public Config() {

	addDefaultValues();
    }


    /**
     * Constructeur clonant une autre Config.
     * Deep copy : toutes les valeurs sont clon�es.
     */

    public Config (Config cf) {

  	hints = new Hint[cf.hints.length];
	updateFromConfig(cf);

	addDefaultValues();
    }


    /**
     * 'Constructeur' de d�-s�rialisation.
     */

    private void readObject(java.io.ObjectInputStream in)
	throws IOException, ClassNotFoundException {

	in.defaultReadObject();
	addDefaultValues();
    }


    /**
     * Ajoute les valeurs par d�faut pour les clefs
     * et les Hint absents.
     * Doit �tre appel� � la fin de la cr�ation d'une instance.
     */

    private void addDefaultValues() {
	
	if ( solvedMap == null ) {
	    solvedMap = new HashMap();
	} 

	// les Hint
	if ( hints == null ) {
	    hints = new Hint[0];
	}

	if ( hints.length < Hint.getTypesNumber() ) {
	    // on ajoute les nouveaux Hint.
	    Hint[] newHints = new Hint[Hint.getTypesNumber()];

	    System.arraycopy(hints, 0, newHints, 0, hints.length);

	    for ( int i = Hint.getTypesNumber() - 1; i >= hints.length; i-- ) {
		newHints[i] = Hint.newInstance(i);
	    } 
	    
	    hints = newHints;
//  	    renderingHints = null; // destruction du cache
	}

	// test non factoris�s pour �viter de cr�er inutilement des objets.

	// main
	if (!contains("main.piece.normal")) {
	    putVal("main.piece.normal",
		   new Surface(Surface.COLOR, Color.black, "burtwood.jpg", null, 1f ));
	}
	if (!contains("main.piece.selected")) {
	    putVal("main.piece.selected",
		   new Surface(Surface.COLOR, new Color(100, 100, 100),
			       "burtwood.jpg", null, 1.2f ));
	}
	if (!contains("main.piece.border")) {
	    putVal("main.piece.border",
		   new Trait(Color.blue, 1));
	}
	if (!contains("main.background")) {
	    putVal("main.background",
		   new Surface(Surface.COLOR, new Color(190, 190, 200),
			       "paper.jpg", null, 1f ));
	}
	if (!contains("main.outline")) {
	    putVal("main.outline",
		   new Trait(Color.red, 1));
	}
	if (!contains("main.rotation")) {
	    putVal("main.rotation",
		   new Trait(Color.black, 1));
	}
	if (!contains("main.piece.selected.alpha")) {
	    putDouble("main.piece.selected.alpha", 0.5d);
	}

	// small
	if (!contains("small.piece.normal")) {
	    putVal("small.piece.normal",
		   new Surface(Surface.COLOR, Color.black, null, null, 1f ));
	}
	if (!contains("small.piece.selected")) {
	    putVal("small.piece.selected",
		   new Surface(Surface.COLOR, new Color(100, 100, 100), null, null, 1f ));
	}
	if (!contains("small.background.normal")) {
	    putVal("small.background.normal",
		   new Surface(Surface.COLOR, Color.white, null, null, 1f ));
	    
	}
	if (!contains("small.background.solved")) {
	    putVal("small.background.solved",
		   new Surface(Surface.COLOR, new Color(150, 255, 150), null, null, 1f ));
	}

	// game parameter
	if (!contains("main.scale")) {
	    putDouble("main.scale", 0.1);
	}
	if (!contains("main.rotationStep")) {
	    putInt("main.rotationStep", ROTATION_STEP_32);
	}
	if (!contains("main.compareAccuracy")) {
	    putInt("main.compareAccuracy", CalcFigure.COMPARE_ACCURACY_MEDIUM);
	}
	if (!contains("main.figureList")) {
	    putVal("main.figureList",
		   new FigureGroup());
	}
	if (!contains("main.showStatus")) {
	    putBoolean("main.showStatus", true);
	}
    }


    /**
     * Ajoute toutes les valeurs contenues dans une Config.
     * Les valeurs sont clon�es.
     * Ecrase �ventuellement les valeurs actuelles.
     */

    public void updateFromConfig(Config cf) {

	// les hints (les tabeaux doivent avoir la meme taille)
	for ( int i = hints.length - 1; i >= 0; i-- ) {
	    hints[i] = Hint.newInstance(i, cf.hints[i].getSelectedValueIndex());
	} 

//  	renderingHints = null; // destruction du cache

	// le reste
	try {
	    for ( Iterator i = cf.properties.keySet().iterator(); i.hasNext(); ) {
		String key = (String) i.next();
		Object value = cf.getVal(key);

//  		System.err.println("\nclone:key=" + key + ":val=" + value );

		Object newValue;
		if ( value instanceof Double ) {
// 		    newValue = new Double(((Double) value).doubleValue());
		    newValue = value;
		} else if ( value instanceof Integer ) {
// 		    newValue = new Integer(((Integer) value).intValue());
		    newValue = value;
		} else if ( value instanceof Boolean ) {
		    newValue = value;
		} else if ( value instanceof ConfigItem ) {
		    newValue = ((ConfigItem) value).clone();
		} else {
		    System.err.println("*warning*:type non prevu -> clonage");
		    newValue = value.getClass().getMethod("clone", null).invoke(value, null);
		}
		
//    		System.err.println("clone:key=" + key + ":new val=" + newValue );
//    		System.err.println();
		putVal(key, newValue);
	    }
	} catch (Exception e) {
	    System.err.println("*error*:Config contenant une valeur non cloneable ?");
	    e.printStackTrace(System.err);
	} 
    }


    public void notifyChanges() {
	setChanged();
	notifyObservers(this);
    }


    public RenderingHints getRenderingHints() {
	
	if (renderingHints == null) {
	    renderingHints = new RenderingHints(null);	
	} 
	
	for ( int i = hints.length - 1; i >= 0; i-- ) {
	    Hint h = hints[i];
	    renderingHints.put(h.getKey(), h.getRenderingHint());
	} 

	return renderingHints;
    }


    public Hint getHint(int h) {
	if ( h < hints.length ) {
	    // existe dans la config
	    return hints[h];
	} else {
	    throw new RuntimeException("*error*: Hint inconnu");
	} 
    }


    private void putVal(String key, Object value) {

//  	// la config DOIT contenir des valeur pour toutes les clef
//  	if ( properties.get(key) == null ) {
//  	    System.err.println("*error* ajout clef inconnue :" + key);
//  	} 
	
	properties.put(key, value);
    }


    private boolean contains(String key) {
	return properties.containsKey(key);
    }


    private Object getVal(String key) {
	Object ret = properties.get(key);
	if ( ret == null ) {
	    System.err.println("*error* clef inconnue :" + key);
	}
	return ret;
    }


    public Surface getSurface(String key) {
	return (Surface) getVal(key);
    }


    public FigureGroup getFigureGroup(String key) {
	return (FigureGroup) getVal(key);
    }


    public Trait getTrait(String key) {
	return (Trait) getVal(key);
    }


    public int getInt(String key, int defaultValue) {
	
	Integer d = (Integer) getVal(key);
	
	if ( d != null ) {
	    return d.intValue();
	} else {
	    return defaultValue;
	} 
    }
	

    public void putInt(String key, int value) {
	putVal(key, new Integer(value));
    }
	

    public double getDouble(String key, double defaultValue) {
	
	Double d = (Double) getVal(key);
	
	if ( d != null ) {
	    return d.doubleValue();
	} else {
	    return defaultValue;
	} 
    }
	

    public void putDouble(String key, double value) {
	putVal(key, new Double(value));
    }

	
    public boolean getBoolean(String key, boolean defaultValue) {
	
	Object o = getVal(key);
	
	return o == null ? defaultValue : Boolean.TRUE.equals(o);
    }
	

    public void putBoolean(String key, boolean value) {
	putVal(key, value ? Boolean.TRUE : Boolean.FALSE);
    }
	

    /**
     * Renvoi un Composite. Pour l'instant c'est toujours un AlphaComposite ou null.
     *
     * @return un alphaComposite, null s'il n'y en a pas ou s'il est opaque.
     */

    public Composite getComposite(String key) {
	
	double val = getDouble(key, 1.d);

	if ( Math.abs(val - 1d) > 1E-4 ) {
	    return AlphaComposite.getInstance(AlphaComposite.SRC_OVER, (float) val);
	} else {
	    return null;
	} 
    }


    /**
     * D�termine si une figure a d�j� �t� r�solue.
     * rem : le nom doit �tre fourni car la FigureList de la config
     *       peut �tre diff�rente de celle utilis�e
     *       (modif en cours avant apply, cancel, ok).
     */

    public boolean isSolved(String name, int nr) {
	BitSet bs = (BitSet) solvedMap.get(name);

//  	System.out.println("Bitset pour" + name + "=" +bs);

	return (bs != null) && bs.get(nr);
    }


    /**
     * Change l'�tat d'une figure.
     * rem : le nom doit �tre fourni car la FigureList de la config
     *       peut �tre diff�rente de celle utilis�e
     *       (modif en cours avant apply, cancel, ok).
     */

    public void setSolved(String name, int nr, boolean so) {
	BitSet bs = (BitSet) solvedMap.get(name); // pas getVal() car peut ne pas exister

	if ( bs == null ) {
	    bs = new BitSet();
	    solvedMap.put(name, bs);
	} 

	if ( so ) {
	    bs.set(nr);
	} else {
	    bs.clear(nr);
	} 
    }


    /**
     * Efface l'�tat de toutes les figures d'une liste.
     */

    public void clearSolved (String name) {
	solvedMap.remove(name);
    }


    /**
     * Efface l'�tat de toutes les figures.
     */

    public void clearAllSolved () {
	solvedMap.clear();
    }


//      /**
//       * Ajoute toutes les valeurs contenues dans une Config.
//       * Les valeurs ne sont PAS copi�es.
//       * Ecrase �ventuellement les valeurs actuelles.
//       */

//      public void updateFromConfig(Config cf) {

//  	// les hints
//  	for ( int i = hints.length - 1; i >= 0; i-- ) {
//  	    hints[i] = cf.hints[i];
//  	} 
	
//  	this.properties.keySet().clear();

//  //  	// le reste
//  //  	// � priori cf est une ancienne version de this
//  //  	// donc this peut contenir plus de clefs que cf mais pas l'inverse 

//  //  	this.properties.keySet().removeAll(cf.properties.keySet());

//  //  	for ( Iterator i = this.properties.keySet().iterator(); i.hasNext(); ) {
//  //  	    Object key = i.next();
//  //  	    this.properties.remove(key);
//  //  	    System.err.println("*error*:nouvelle clef dans la config ? : " + key);
//  //  	}

//  	this.properties.putAll(cf.properties);
//      }


    /**
     * Clone la config (deep copy).
     */

    public Object clone() {

	Config newConfig = new Config(this);

//  	System.out.println("\n\nthis" + this );
//  	System.out.println("\n\nnew" + newConfig );

	return newConfig;
    }


    public String toString() {

	StringBuffer sb = new StringBuffer(2048);

	sb.append("Config:\n");

	for ( int i = hints.length - 1; i >= 0; i-- ) {
	    Hint h = hints[i];
	    sb.append("hint=" + h.getKey() + "   val=" + h.getRenderingHint());
	} 

	for ( Iterator i = properties.keySet().iterator(); i.hasNext(); ) {
	    String key = (String) i.next();
	    sb.append("key=" + key + "   val=" + properties.get(key) + "\n");
	}
	
	return sb.toString();
    }


    /**
     * Objet contenant un RenderingHints et les valeurs possibles correspondantes.
     * Permet � un objet externe (composant GUI) de r�cuperer ou de s�lectionner
     * une valeur, et de r�cup�rer les noms correspondants.
     * N'utilise pas d'it�rateurs car les type et les valeurs sont r�f�renc�s par
     * des entiers.
     * Les m�thodes public sont g�n�ralement destin�es � la GUI,
     * les m�thodes package � la la Config.
     */

    public static class Hint implements Cloneable, Serializable {

  	static final long serialVersionUID = Config.serialVersionUID;

	private final transient RenderingHints.Key key;
	private final transient String keyName;

	private final transient Object[] values;
	private final transient String[] valueNames;

	private int selectedValueIndex;  // la selection actuelle (parmi values)

	// utilis�e pour la s�rialisation
	// valide uniquement sur instances obtenues par newInstance()
	private int type = -1;


	/**
	 * Constructeur priv�s destin� � l'initialisation des attributs de classe.
	 * Utiliser newInstance pour obtenir une copie modifiable.
	 */

	private Hint(String kn, RenderingHints.Key k, String[] vn, Object[] v, int dsv) {
	    key = k;
	    keyName = kn;
	    values = v;
	    valueNames = vn;
	    selectedValueIndex = dsv;
	    // type n'est pas initialis� : obtenir une copie par newInstance()
	}

	public String getKeyName() {
	    return keyName;
	}
	
	RenderingHints.Key getKey() {
	    return key;
	}
	
	public String[] getValueNames() {
	    return valueNames;
	}

	/**
	 * Renvoi le num�ro de la valeur en cours.
	 * 
	 * @return 0 � getValuesNumber() - 1.
	 */

	public int getSelectedValueIndex() {
	    return selectedValueIndex;
	}

	public void setSelectedValueIndex(int i) {
	    selectedValueIndex = i;
	}

//  	public int getValuesNumber() {
//  	    return values.length;
//  	}

	public Object getRenderingHint() {
	    return values[selectedValueIndex];
	}


	/**
	 * Cr�e une nouvelle instance (Factory method).
	 * A partir d'une copie des instances de base (pour partager les tableaux
	 * de donn�es).
	 * 
	 * @param type de 0 � getTypeNumber() - 1.
	 * @param selectedValueIndex de 0 � getValueNumber() OU -1 valeur par d�fault.
	 */

	static Hint newInstance(int type, int selectedValueIndex) {

	    Hint ret;

	    try {
		ret = (Hint) baseHints[type].clone();
		if ( selectedValueIndex != -1 ) {
		    ret.setSelectedValueIndex(selectedValueIndex);
		} 
	    } catch (CloneNotSupportedException e) {
		e.printStackTrace(System.err);
		throw new RuntimeException("*error*:pb. de clonage d'un Hint");
	    }
	    
	    ret.type = type; // pour s�rialisation

	    return ret;
	}

	static Hint newInstance(int type) {
	    return newInstance(type, -1);
	}

	/**
	 * Remplace l'objet d�-s�rialis� par une instance ayant les attributs
	 * transient initialis�s.
	 */

	Object readResolve() throws ObjectStreamException {
	    return newInstance(type, selectedValueIndex);
	}

	/**
	 * Nombre de Hint.
	 */

	public static int getTypesNumber() {
	    return baseHints.length;
	}

	// les objets de base, l'attribut type n'est pas initialis�.
	// les objets r�ellement utilis�s sont des copies obtenues par
	// newInstance().
	// en cas d'ajout ailleurs qu'a la fin ou de suppression : changer le nr.
	// de version de Config.
	private static final Hint[] baseHints = new Hint[] {
	    new Hint( "hint.antialiasing",
		      RenderingHints.KEY_ANTIALIASING,
		      new String[] {"hint.0.default", "hint.0.off", "hint.0.on"},		    
		      new Object[] { RenderingHints.VALUE_ANTIALIAS_DEFAULT,
				     RenderingHints.VALUE_ANTIALIAS_OFF,
				     RenderingHints.VALUE_ANTIALIAS_ON },
		      0 ),
	    new Hint( "hint.colorRendering",
		      RenderingHints.KEY_COLOR_RENDERING,
		      new String[] {"hint.1.default", "hint.1.speed", "hint.1.quality"},
		      new Object[] { RenderingHints.VALUE_COLOR_RENDER_DEFAULT,
				     RenderingHints.VALUE_COLOR_RENDER_SPEED,
				     RenderingHints.VALUE_COLOR_RENDER_QUALITY },
		      0 ),
	    new Hint( "hint.interpolation",
		      RenderingHints.KEY_INTERPOLATION,
		      new String[] {"hint.2.nearestNeighbor", "hint.2.bilinear", "hint.2.bicubic"},
		      new Object[] { RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR,
				     RenderingHints.VALUE_INTERPOLATION_BILINEAR,
				     RenderingHints.VALUE_INTERPOLATION_BICUBIC },
		      0 ),
	    new Hint( "hint.dithering",
		      RenderingHints.KEY_DITHERING,
		      new String[] {"hint.3.Default", "hint.3.Disabled", "hint.3.Enabled"},
		      new Object[] { RenderingHints.VALUE_DITHER_DEFAULT,
				     RenderingHints.VALUE_DITHER_DISABLE,
				     RenderingHints.VALUE_DITHER_ENABLE },
		      0 ),
	    new Hint( "hint.fractionalMetrics",
		      RenderingHints.KEY_FRACTIONALMETRICS,
		      new String[] {"hint.4.default", "hint.4.off", "hint.4.on"},
		      new Object[] { RenderingHints.VALUE_FRACTIONALMETRICS_DEFAULT,
				     RenderingHints.VALUE_FRACTIONALMETRICS_OFF,
				     RenderingHints.VALUE_FRACTIONALMETRICS_ON },
		      0),
	    new Hint( "hint.rendering",
		      RenderingHints.KEY_RENDERING,
		      new String[] {"hint.5.default", "hint.5.speed", "hint.5.quality"},
		      new Object[] { RenderingHints.VALUE_RENDER_DEFAULT,
				     RenderingHints.VALUE_RENDER_SPEED,
				     RenderingHints.VALUE_RENDER_QUALITY },
		      0 ),
	    new Hint( "hint.alphaInterpolation",
		      RenderingHints.KEY_ALPHA_INTERPOLATION,
		      new String[] {"hint.6.default", "hint.6.speed", "hint.6.quality"},
		      new Object[] { RenderingHints.VALUE_ALPHA_INTERPOLATION_DEFAULT,
				     RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED,
				     RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY },
		      0 ) };
    }
}

