
package net.phbwt.jtans.guiconfig;

import net.phbwt.jtans.calc.CalcFigure;
import net.phbwt.jtans.guicommon.*;

import java.util.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;

/**
 * Objet g�rant la fen�tre de configuration.
 * La <code>Config</code> pass�e au constructeur est clon�e.
 * C'est la copie qui est modifi�e. 
 * ok ou apply : l'original est mis � jour
 * ok : la fen�tre est ferm�e.
 * cancel : elle est d�truite (les composants ont des r�f�rences sur le contenu de la config).
 */

public class ConfigWindow {

    private Config editedConfig;  // config copi�e en d�but d'�dition 
    private Config origConfig; 
    
    private JFrame window = null;

    private JFileChooser fileChooser = null;

    private static ResourceBundle i18n = ResourceBundle.getBundle("net.phbwt.jtans.i18n.config");

    
    public ConfigWindow(Config cf ) {

//  	if ( i18n == null ) {
//  	    i18n = ResourceBundle.getBundle("net.phbwt.jtans.i18n.config");
//  	} 

	origConfig = cf;
    }


    public void show () {

	if ( fileChooser == null ) {
	    try {
		fileChooser = new JFileChooser();
	    } catch (SecurityException e) {
		System.err.println("*INFO*: wont'be able to access filesystem :");
		e.printStackTrace(System.err);
	    }
	} 

	if (editedConfig == null ) {
	    editedConfig = (Config) origConfig.clone();
	} 
	
	if ( window == null) {
	    
	    GridBagConstraints gbc = new GridBagConstraints();
	    gbc.insets = new Insets(1, 3, 1, 3);

	    //
	    // Cr�e le TabbedPane
	    //

	    JTabbedPane jtb = new JTabbedPane();
  	    jtb.addTab( i18n.getString("game.tabTitle"),
			null,
			gameParametersTab(gbc),
			i18n.getString("game.tabHint") );

	    jtb.addTab( i18n.getString("main.tabTitle"),
			null,
			mainFigureTab(gbc),
			i18n.getString("main.tabHint") );

	    jtb.addTab( i18n.getString("small.tabTitle"),
			null,
			smallFigureTab(gbc),
			i18n.getString("small.tabHint") );

  	    jtb.addTab( i18n.getString("hint.tabTitle"),
			null,
			renderingTab(gbc),
			i18n.getString("hint.tabHint") );


	    //
	    // buttons
	    //

	    JButton okButton = new JButton(i18n.getString("ok"));
	    okButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
			window.hide();
			window.dispose();

			origConfig.updateFromConfig(editedConfig); 
			origConfig.notifyChanges();
		    }
		});


	    JButton cancelButton = new JButton(i18n.getString("cancel"));
	    cancelButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {

//  			System.out.println("\n\nactual" + config);
//  			System.out.println("\n\nold" + oldConfig);
			
			abort();
		    }
		});


	    JButton applyButton = new JButton(i18n.getString("apply"));
	    applyButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
			origConfig.updateFromConfig(editedConfig); 
			origConfig.notifyChanges();
		    }
		});


	    Box bottomBox = Box.createHorizontalBox();
	    bottomBox.add(Box.createGlue());
	    bottomBox.add(okButton);
	    bottomBox.add(Box.createGlue());
	    bottomBox.add(cancelButton);
	    bottomBox.add(Box.createGlue());
	    bottomBox.add(applyButton);
	    bottomBox.add(Box.createGlue());


	    Box mainBox = Box.createVerticalBox();
//  	mainBox.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
	    mainBox.add(jtb);
	    mainBox.add(Box.createGlue());
	    mainBox.add(new JSeparator());
	    mainBox.add(Box.createGlue());
	    mainBox.add(bottomBox);


	    window = new JFrame(i18n.getString("global.title"));
	    window.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
	    window.getContentPane().add(mainBox);
//  	    window.addWindowListener(new WindowAdapter() {
//    		    public void windowClosing(WindowEvent e) { System.exit(0); }
//  		});
	}
	
	window.pack();
	window.show();
    } 


    //************************************************************************

    /**
     * Cr�e le tab correspondant � la figure �ditable.
     *
     * @param gbc les contraintes de base.
     */

    private JComponent mainFigureTab(GridBagConstraints gbc) {

	    JComponent tab = new JPanel();
	    tab.setOpaque(true);
//  	    tab.setDoubleBuffered(true);
	    tab.setLayout(new GridBagLayout());
	    

	    // 1�re ligne de label

	    gbc.gridx = 0;
	    gbc.gridy = 0;

	    GridBagLayout gbl = (GridBagLayout)tab.getLayout();
	    Component comp;
	    gbc.anchor = GridBagConstraints.CENTER;

	    gbc.gridx++;
	    gbc.weightx = 0;
	    gbc.weighty = 0;
	    gbc.fill = GridBagConstraints.NONE;
	    comp = new JLabel((i18n.getString("main.type")));
	    gbl.setConstraints(comp, gbc);
	    tab.add(comp);

	    gbc.gridx += 2;
	    comp = new JLabel((i18n.getString("main.brightness-width")));
	    gbl.setConstraints(comp, gbc);
	    tab.add(comp);


	    // lignes suivantes

	    gbc.gridx = 0;
	    gbc.gridy++;
	    gbc.fill = GridBagConstraints.HORIZONTAL;

	    SurfaceComponentGroup.addGroup( tab,
					    editedConfig.getSurface("main.piece.normal"),
					    i18n.getString("main.piece.normal"),
					    gbc,
					    fileChooser,
					    i18n );

	    gbc.gridx = 0;
	    gbc.gridy++;
	    SurfaceComponentGroup.addGroup( tab,
					    editedConfig.getSurface("main.piece.selected"),
					    i18n.getString("main.piece.selected"),
					    gbc,
					    fileChooser,
					    i18n );

	    gbc.gridx = 0;
	    gbc.gridy++;
	    TraitComponentGroup.addGroup( tab,
					  editedConfig.getTrait("main.piece.border"),
					  i18n.getString("main.piece.border"),
					  gbc,
					  i18n );

	    gbc.gridx = 0;
	    gbc.gridy++;
	    SurfaceComponentGroup.addGroup( tab,
					    editedConfig.getSurface("main.background"),
					    i18n.getString("main.background"),
					    gbc,
					    fileChooser,
					    i18n );

	    gbc.gridx = 0;
	    gbc.gridy++;
	    TraitComponentGroup.addGroup( tab,
					  editedConfig.getTrait("main.outline"),
					  i18n.getString("main.outline"),
					  gbc,
					  i18n );

	    gbc.gridx = 0;
	    gbc.gridy++;
	    TraitComponentGroup.addGroup( tab,
					  editedConfig.getTrait("main.rotation"),
					  i18n.getString("main.rotation"),
					  gbc,
					  i18n );


	    
	    JSlider alphaSlider = new JSlider( 0, 95,
					       (int) ( 100d
						       - editedConfig.getDouble("main.piece.selected.alpha", 1d)
						       * 100 ) );
	    alphaSlider.addChangeListener( new ChangeListener() {
		    public void stateChanged(ChangeEvent e) {
			editedConfig.putDouble( "main.piece.selected.alpha",
						(1d - ((JSlider) e.getSource()).getValue() / 100d) );
		    }
		});
	    
//  	    JComponent comp;
//  	    GridBagLayout gbl = (GridBagLayout) tab.getLayout();

	    gbc.gridx = 0;
	    gbc.gridy++;
	    comp = new JLabel(i18n.getString("main.piece.selected.alpha"));
	    gbl.setConstraints(comp, gbc);
	    tab.add(comp);

	    gbc.gridx++;
	    gbc.gridwidth = 3;
	    comp = alphaSlider;
	    gbl.setConstraints(comp, gbc);
	    tab.add(comp);
	    gbc.gridwidth = 1;

	    return tab;
    }


    //************************************************************************

    /**
     * Cr�e le tab correspondant � la petite figure.
     *
     * @param gbc les contraintes de base.
     */

    private JComponent smallFigureTab(GridBagConstraints gbc) {

	    JComponent tab = new JPanel();
	    tab.setOpaque(true);
//  	    tab.setDoubleBuffered(true);
	    tab.setLayout(new GridBagLayout());
	    

	    // 1�re ligne de label

	    gbc.gridx = 0;
	    gbc.gridy = 0;

	    GridBagLayout gbl = (GridBagLayout)tab.getLayout();
	    Component comp;
	    gbc.anchor = GridBagConstraints.CENTER;

	    gbc.gridx++;
	    gbc.weightx = 0;
	    gbc.weighty = 0;
	    gbc.fill = GridBagConstraints.NONE;
	    comp = new JLabel((i18n.getString("small.type")));
	    gbl.setConstraints(comp, gbc);
	    tab.add(comp);

	    gbc.gridx += 2;
	    comp = new JLabel((i18n.getString("small.brightness")));
	    gbl.setConstraints(comp, gbc);
	    tab.add(comp);


	    // lignes suivantes

	    gbc.fill = GridBagConstraints.HORIZONTAL;
	    gbc.gridx = 0;
	    gbc.gridy++;
	    SurfaceComponentGroup.addGroup( tab,
					    editedConfig.getSurface("small.piece.normal"),
					    i18n.getString("small.piece.normal"),
					    gbc,
					    fileChooser,
					    i18n );

	    gbc.gridx = 0;
	    gbc.gridy++;
	    SurfaceComponentGroup.addGroup( tab,
					    editedConfig.getSurface("small.piece.selected"),
					    i18n.getString("small.piece.selected"),
					    gbc,
					    fileChooser,
					    i18n );

	    gbc.gridx = 0;
	    gbc.gridy++;
	    SurfaceComponentGroup.addGroup( tab,
					    editedConfig.getSurface("small.background.normal"),
					    i18n.getString("small.background.normal"),
					    gbc,
					    fileChooser,
					    i18n );

	    gbc.gridx = 0;
	    gbc.gridy++;
	    SurfaceComponentGroup.addGroup( tab,
					    editedConfig.getSurface("small.background.solved"),
					    i18n.getString("small.background.solved"),
					    gbc,
					    fileChooser,
					    i18n );

	    return tab;
    }


    //************************************************************************

    /**
     * Cr�e le tab correspondant au rendering hints.
     *
     * @param gbc les contraintes des base.
     */

    private JComponent renderingTab(GridBagConstraints gbc) {

	JComponent tab = new JPanel();
	tab.setOpaque(true);
//  	tab.setDoubleBuffered(true);
	tab.setLayout(new GridBagLayout());
	

	for ( int i = 0; i < Config.Hint.getTypesNumber(); i++) { // croissant
	    gbc.gridx = 0;
	    gbc.gridy = i;
	    addRenderingComponents(tab, gbc, editedConfig.getHint(i));
	} 
	
	return tab;
    }


    // utilis�e par renderingTab.
    private void addRenderingComponents( JComponent parent,
					 GridBagConstraints gbc,
					 Config.Hint hint ) {
	
	GridBagLayout gbl = (GridBagLayout) parent.getLayout();
	JComponent comp;

//    	gbc.gridx++;
	gbc.weightx = 0;
	gbc.weighty = 0;
	gbc.fill = GridBagConstraints.HORIZONTAL;
	comp = new JLabel(i18n.getString(hint.getKeyName()));
	gbl.setConstraints(comp, gbc);
	parent.add(comp);

	String[] valuesN = hint.getValueNames();
	String[] valuesL = new String[valuesN.length];

	for ( int i = valuesN.length - 1; i >= 0; i-- ) {
	    valuesL[i] = i18n.getString(valuesN[i]);
	} 

	JComboBox comp2 = new JComboBox(valuesL);
	comp2.putClientProperty("hint", hint);
	comp2.setSelectedIndex(hint.getSelectedValueIndex());

	comp2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    JComboBox cb = (JComboBox) e.getSource();
		    ((Config.Hint) cb.getClientProperty("hint"))
			.setSelectedValueIndex(cb.getSelectedIndex());
		}
	    });

  	gbc.gridx++;
	gbl.setConstraints(comp2, gbc);
	parent.add(comp2);
    }


    //************************************************************************

    private static final int[] rotValues = new int[] {
	Config.ROTATION_CONTINUOUS,
	Config.ROTATION_STEP_32,
	Config.ROTATION_STEP_AUTO
    };
    
    private static final String[] rotLabels = new String[] {
	i18n.getString("game.rotation.continuous"),
	i18n.getString("game.rotation.step32"),
	i18n.getString("game.rotation.stepAuto")
    };
    
    private static final int[] accurValues = new int[] {
	CalcFigure.COMPARE_ACCURACY_LOW,
	CalcFigure.COMPARE_ACCURACY_MEDIUM,
	CalcFigure.COMPARE_ACCURACY_HIGH
    };
    
    private static final String[] accurLabels = new String[] {
	i18n.getString("game.accuracy.low"),
	i18n.getString("game.accuracy.medium"),
	i18n.getString("game.accuracy.high")
    };
    
    private static final int[] figTypeValues = new int[] {
	FigureGroup.RESOURCE,
	FigureGroup.FILE
    };
    
    private static final String[] figTypeLabels = new String[] {
	i18n.getString("game.figures.type.resource"),
	i18n.getString("game.figures.type.file")
    };
    

    /**
     * Cr�e le tab correspondant aux game parameters.
     *
     * @param gbc les contraintes des base.
     */

    private JComponent gameParametersTab(GridBagConstraints gbc) {

	JComponent tab = new JPanel();
	tab.setOpaque(true);
	tab.setLayout(new GridBagLayout());
	
	//
	// Construit les composants.
	//

	// taille relative
	JSlider pieceSize = new JSlider(8, 18, (int)(editedConfig.getDouble("main.scale", 0.1) * 100));
	pieceSize.addChangeListener( new ChangeListener() {
		public void stateChanged(ChangeEvent e) {
		    editedConfig.putDouble("main.scale", ((JSlider)e.getSource()).getValue() / 100d);
		}
	    });


	// combo rotation continue/quantifi�e
	final JComboBox rotationComp = new JComboBox(rotLabels);
	rotationComp.setSelectedIndex(search(rotValues,
					     editedConfig.getInt("main.rotationStep",
								 Config.ROTATION_STEP_32)));
	rotationComp.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    editedConfig.putInt("main.rotationStep",
					rotValues[((JComboBox)e.getSource()).getSelectedIndex()]);
		}
	    });


	// combo precision de la comparaison
	final JComboBox accuracyComp = new JComboBox(accurLabels);
	accuracyComp.setSelectedIndex(search(accurValues,
					     editedConfig.getInt( "main.compareAccuracy",
								  CalcFigure.COMPARE_ACCURACY_MEDIUM )));
	accuracyComp.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    editedConfig.putInt("main.compareAccuracy",
					accurValues[((JComboBox)e.getSource()).getSelectedIndex()]);
		}
	    });


	// combo type de figurelist
	final FigureGroup figGroup = editedConfig.getFigureGroup("main.figureList");
	final JComboBox figTypeComp = new JComboBox(figTypeLabels);
	figTypeComp.setSelectedIndex(search(figTypeValues, figGroup.getType()));
	figTypeComp.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    figGroup.setType(figTypeValues[((JComboBox) e.getSource()).getSelectedIndex()]);
		}
	    });

	// bouton "choisir..."
	final JButton figChooseButton = new JButton(i18n.getString("game.figures.choose"));
	figChooseButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {

		    try {

			switch ( figGroup.getType() ) {
			    
			case FigureGroup.FILE:

			    if ( fileChooser == null ) {
				throw new Exception(i18n.getString("restricted"));
			    } 

			    if ( figGroup.getFile() != null ) {
				fileChooser.setSelectedFile(figGroup.getFile());
			    }
			    
			    if ( fileChooser.showOpenDialog(figChooseButton) 
				 == JFileChooser.APPROVE_OPTION ) {
				figGroup.setFile(fileChooser.getSelectedFile());
			    } 
			    
			    break;
			    
			case FigureGroup.RESOURCE:
			    String name = (String) JOptionPane.showInputDialog( figChooseButton,
										null,
										null,
										JOptionPane.QUESTION_MESSAGE,
										null,
										FigureGroup.getResources(),
										figGroup.getResourceName() );
			    if ( name != null ) {
				figGroup.setResourceName(name);
			    } 
			    break;
			    
			default:
			    break;
			}

			// teste le r�sultat (si on a rien fait, c'est peu couteux)
			figGroup.getList();
			
		    } catch (Exception ex) {
			System.err.println("*INFO*:Can't get figure file:");
			ex.printStackTrace();
			JOptionPane.showMessageDialog( figChooseButton,
						       i18n.getString("error.figures.load")
						       + " : " + ex.getMessage() );
		    } 
		}
	    });
	

	// checkbox show statusbar
	JCheckBox showStatusComp = new JCheckBox("", editedConfig.getBoolean("main.showStatus", true));
	showStatusComp.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    editedConfig.putBoolean("main.showStatus",
					    ((JCheckBox)e.getSource()).isSelected());
		}
	    });


	//
	// Ajoute les composants.
	//

	Component comp;
	GridBagLayout gbl = (GridBagLayout) tab.getLayout();

	gbc.gridx = 0;
	gbc.gridy = 0;
	gbc.gridwidth = 1;
	gbc.weightx = 0;
	gbc.weighty = 0;
	gbc.fill = GridBagConstraints.HORIZONTAL;
	comp = new JLabel(i18n.getString("game.size"));
	gbl.setConstraints(comp, gbc);
	tab.add(comp);

	gbc.gridx++;
	gbc.gridwidth = 2;
	comp = pieceSize;
	gbl.setConstraints(comp, gbc);
	tab.add(comp);


	gbc.gridx = 0;
	gbc.gridy++;
	gbc.gridwidth = 1;
	comp = new JLabel(i18n.getString("game.accuracy"));
	gbl.setConstraints(comp, gbc);
	tab.add(comp);

	gbc.gridx++;
	gbc.gridwidth = 2;
	comp = accuracyComp;
	gbl.setConstraints(comp, gbc);
	tab.add(comp);


	gbc.gridx = 0;
	gbc.gridy++;
	gbc.gridwidth = 1;
	comp = new JLabel(i18n.getString("game.rotation"));
	gbl.setConstraints(comp, gbc);
	tab.add(comp);

	gbc.gridx++;
	gbc.gridwidth = 2;
	comp = rotationComp;
	gbl.setConstraints(comp, gbc);
	tab.add(comp);


	gbc.gridx = 0;
	gbc.gridy++;
	gbc.gridwidth = 1;
	comp = new JLabel(i18n.getString("game.figures"));
	gbl.setConstraints(comp, gbc);
	tab.add(comp);

	gbc.gridx++;
	comp = figTypeComp;
	gbl.setConstraints(comp, gbc);
	tab.add(comp);

	gbc.gridx++;
	comp = figChooseButton;
	gbl.setConstraints(comp, gbc);
	tab.add(comp);


	gbc.gridx = 0;
	gbc.gridy++;
	gbc.gridwidth = 1;
	comp = new JLabel(i18n.getString("game.showStatus"));
	gbl.setConstraints(comp, gbc);
	tab.add(comp);

	gbc.gridx++;
	comp = showStatusComp;
	gbl.setConstraints(comp, gbc);
	tab.add(comp);

	return tab;
    }


    /**
     * Annule une configuration en cours, ferme la fen�tre.
     * Ne notifie pas les Observer.
     */
     
    public void abort() {

	if ( window != null ) {
	    window.hide();
	    window.dispose();
	    window = null;    // sinon r�f�rence toujours les anciennes valeurs
	}

	editedConfig = null;

//  	if ( oldConfig != null ) {
//  	    config.updateFromConfig(oldConfig);
//  	    oldConfig = null;  //fin d'�dition
	    
//  	    setChanged();            // *n* 
//  	    notifyObservers(config); // *n*
//  	}
    }


    //************************************************************************

    /**
     * D�termine dans un tableau d'int l'index d'une valeur.
     */

    public static int search(int[] values, int key) {
	for ( int i = values.length - 1; i >= 0; i-- ) {
	    if ( key == values[i] ) {
		return i;
	    } 
	}

	throw new RuntimeException("valeur inconnue");
    }


    /**
     * D�termine dans un tableau de double la position de la valeurs la plus
     * proche d'une valeur donn�e.
     */

    public static int posIndex(double[] values, double val ) {
	int i;
	for ( i = 0;
	      i < values.length - 1 && val > (values[i] + values[i + 1]) / 2;
	      i++ );

	return i;
    }


    /**
     * Cr�e un tableau de String correspondant �
     * un tableau de double
     */

    public static String[] createLabels( double[] values ) {
	
	String[] ret = new String[values.length]; 

	for ( int i = values.length - 1; i >= 0; i--) {
	    ret[i] = Double.toString(values[i]);
	} 
	
	return ret;
    }
}

