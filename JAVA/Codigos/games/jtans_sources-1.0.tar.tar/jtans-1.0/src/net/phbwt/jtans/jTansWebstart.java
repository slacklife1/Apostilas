
package net.phbwt.jtans;

import net.phbwt.jtans.guicommon.*;

import java.io.*;
import java.net.*;
import java.util.zip.*;

import javax.jnlp.*;

public class jTansWebstart extends AbstractApplication {
    
    private static final String CONFIG_NAME = "jTansConfig";

    private PersistenceService persistenceService = null;
    private BasicService basicService = null;
    private URL configURL = null;

    public static void main(String[] args){
//  	Locale.setDefault(new Locale("fr", "FR"));

	jTansWebstart jt = new jTansWebstart();
	jt.start();
    }
    

    public Config retrieveConfig() {
	
	Config ret;

	try {

	    persistenceService = (PersistenceService) ServiceManager.lookup("javax.jnlp.PersistenceService");
	    basicService = (BasicService) ServiceManager.lookup("javax.jnlp.BasicService");

            URL codebase = basicService.getCodeBase();
            configURL = new URL(codebase.toString() + CONFIG_NAME );
            FileContents fc = persistenceService.get(configURL);

//  	    System.out.println(fc.getMaxLength());
	    
	    InputStream ist = fc.getInputStream();
	    ObjectInputStream ois = new ObjectInputStream(new GZIPInputStream(new BufferedInputStream(ist)));

	    ret = (Config) ois.readObject();

	    ois.close();
	} catch (Exception e) {
	    System.err.println("*INFO*:can't find/load preferences:");
	    e.printStackTrace(System.err);
	    ret = new Config();
	}

//  	System.out.println("aa" + configURL);

	return ret;
    }


    /**
     * Sauve la config.
     * L'init doit avoir �t� faite (retrieveConfig()).
     */

    public void saveConfig(Config cf) {

//  	System.out.println("saving config for " + configURL);

	try {
	    
	    if ( persistenceService == null || basicService == null ) {
		throw new RuntimeException("Service Unavailable"); 
	    }
		
	    long taille = 4096; // *fixme* trouver la bonne taille
	    
	    try {
		persistenceService.delete(configURL);
	    } catch (Exception e) { } 	    

	    if ( persistenceService.create(configURL, taille) < taille ) {
		throw new RuntimeException("not enough space to save config");
	    } 
	    
	    FileContents fc = persistenceService.get(configURL);
	    
	    OutputStream os = fc.getOutputStream(false);
	    
	    ObjectOutputStream oos = new ObjectOutputStream(new GZIPOutputStream(new BufferedOutputStream(os)));
	    oos.writeObject(config);
	    oos.close();
	    
//  	    System.out.println("saved config for" + configURL);
		
	} catch (Exception ex) {
	    System.err.println("*INFO*: Can't save config:");
	    ex.printStackTrace(System.err);
	} 
    }
}    

