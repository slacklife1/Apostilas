
package net.phbwt.jtans;

import net.phbwt.jtans.guimain.*;
import net.phbwt.jtans.guicommon.*;
import net.phbwt.jtans.guiconfig.ConfigWindow;
import net.phbwt.jtans.guiinfo.InfoWindowController;

import javax.swing.*;
import java.awt.event.*;
import java.util.*;

/*
 * Superclasse des applications (standard ou webstart).
 * Reste � implementer la r�cup�ration/sauvegarde de la config.
 * et le main.
 * Observe MainWindow : "jtans.help" et "jtans.about".
 */

public abstract class AbstractApplication implements Observer {
    
    protected ConfigWindow configWindow;
    protected MainWindow mainWindow;
    protected InfoWindowController infoWindow;
    
    protected Config config;

    protected static ResourceBundle i18n = null;


    protected AbstractApplication() {

	if ( i18n == null ) {
	    i18n = ResourceBundle.getBundle("net.phbwt.jtans.i18n.main");
	} 
    }


    protected void start(){
	
//  	try {

//  	    CalcFigure dumFig = new CalcFigure();

//  	    ByteArrayOutputStream baos = new ByteArrayOutputStream(2000);
//  	    ObjectOutputStream oos = new ObjectOutputStream(baos);
	
//  	    oos.writeObject(dumFig);

//  	    byte[] dumArray = baos.toByteArray();

//  	    System.out.println(new String(dumArray) + " *** " + dumArray.length);

//  	    oos.close();
//  	    oos = null;


//  	    ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(dumArray));

//  	    CalcFigure dumFig2 = (CalcFigure)ois.readObject();

//  	} catch (Exception e) {
//  	    e.printStackTrace();
//  	} 
	
	//
	// la config
	//

	config = retrieveConfig();


	//
	// les fen�tres
	//

	mainWindow = new MainWindow(config);
	configWindow = new ConfigWindow(config);
	infoWindow = new InfoWindowController();

	JFrame mainWinFrame = new JFrame("jTans");
	mainWinFrame.addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
//  		    System.out.println("main closing");
		    quit();
		}
//  		public void windowClosed(WindowEvent e) {
//  		    System.out.println("main closed");
//  		    quit();
//  		}
	    });
	
	mainWindow.fill(mainWinFrame);


	//
	// les menus : le premier (config, quit) est cr��, les autres sont demand�s � MainWindow.
	//

	JMenu firstMenu = new JMenu(i18n.getString("menu.game"));
	firstMenu.add(i18n.getString("menu.game.configure")).addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    configWindow.show();
		}
	    });
	firstMenu.add(i18n.getString("menu.game.quit")).addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    quit();
		}
	    });
	
	JMenuBar menuBar = new JMenuBar();
	menuBar.add(firstMenu);
	for ( Iterator i = mainWindow.getMenus().iterator(); i.hasNext(); ) {
	    menuBar.add((JMenu) i.next());
	}
	
	mainWindow.addObserver(this);


	/* fin */

	mainWinFrame.setJMenuBar(menuBar);
	mainWinFrame.pack();
	mainWinFrame.setSize(mainWinFrame.getPreferredSize());  // ???
	mainWinFrame.show();
    }

    
    private void quit() {
	
	configWindow.abort();

	saveConfig(config);
	
//  	try {
//  	    Thread.sleep(60000);
//  	} catch (InterruptedException e) {	} 

	System.exit(0);
    }


    /**
     * Gestion des evenement venants de MainWindow.
     */

    public void update(Observable obs, Object obj) {

	if ( "jtans.help".equals(obj)) {
	    infoWindow.showHelpWindow();
	} else if ( "jtans.about".equals(obj)) {
	    infoWindow.showAboutWindow();
	} 
    }


    protected abstract Config retrieveConfig();
    protected abstract void saveConfig(Config cf);
}    

