
package net.phbwt.jtans.calc;

import java.util.*;
import java.io.*;


/**
 * Contient une liste de pieces formant une figure.
 * Il n'y a pas de notion d'ordre ou de pi�ce s�lectionn�e.
 */

public class CalcFigure {
	
    private static final boolean DEBUG = false;

    public static final int COMPARE_ACCURACY_HIGH = 16;
    public static final int COMPARE_ACCURACY_MEDIUM = 17;
    public static final int COMPARE_ACCURACY_LOW = 18;

    private static final int NB_PIECES = 7;  // nb. de pieces.
    private static final int NB_TINY = 32;   // nb. de tiny triangles.

    private Set pieces;  // les pi�ces peuvent �tre modifi�es mais pas le Set
    
    // modifi� par chaque changement d'une pi�ce
    public int figureChangeCount;

    // liste des tiny triangles (chaque pi�ce calcule les siens dans les tableaux)
    public CalcPolyTriangles figureTinyTab;
    private int figureTinyTabLastChange;
    private double tinyXMean, tinyYMean;

    // gestion de la figure outline
    private List outlinePolygons;   // list de CalcOutlinePolygon
    private int outlinePolygonsLastChange;

    // gestion des bornes de la figure.
    private CalcPolyPoints minMax;     // point 0 : haut gauche, point 1 : bas droite. 
    private int minMaxLastChange;

    // juste pour les calculs de comparaison
    private boolean[] libre;


    /**
     * Constructeur cr�ant une figure 'par d�faut'.
     */

    public CalcFigure() {
	
	initTransient();

	pieces = new HashSet(NB_PIECES);
	pieces.add(new CalcPieceGT(0.90, 0.90, 0               , false));
	pieces.add(new CalcPieceGT(1.54, 1.84, CalcPiece.HT * 4, false));
	pieces.add(new CalcPieceMT(3.83, 0.54, CalcPiece.HT * 3, false));
	pieces.add(new CalcPiecePT(2.78, 2.16, CalcPiece.HT * 2, false));
	pieces.add(new CalcPiecePT(4.76, 0.88, CalcPiece.HT * 4, false));
	pieces.add(new CalcPieceT( 3.00, 1.22, CalcPiece.HT * 5, false));
	pieces.add(new CalcPieceC( 4.20, 2.00, CalcPiece.HT * 2, false));

	for ( Iterator i = pieces.iterator(); i.hasNext(); ) {
	    ((CalcPiece) i.next()).setFigure(this);
	} 
    }
    

    /**
     * Constructeur priv� utilis� par une StoredFigure.
     */

    private CalcFigure(Set pcs) {
	
	initTransient();

	pieces = pcs;

	for ( Iterator i = pieces.iterator(); i.hasNext(); ) {
	    ((CalcPiece) i.next()).setFigure(this);
	} 
    }
    

//      private void readObject( ObjectInputStream in )
//  	throws IOException, ClassNotFoundException {

//  	initTransient();

//  	in.defaultReadObject();
//      }


    /**
     * Initialise les variables 'de travail'.
     * Appel�e par les constructeurs et par la d�s�rialisation
     * AVANT de (re)cr�er les pi�ces.  
     */

    private void initTransient() {

	figureTinyTab = new CalcPolyTriangles(NB_TINY);
	figureTinyTabLastChange = -1;

	minMax = new CalcPolyPoints(2);
	minMaxLastChange = -1;
 
	outlinePolygons = null;
	outlinePolygonsLastChange = -1;

	libre = new boolean[NB_TINY];

	figureChangeCount = 0;
    }

    
//      public void selectPiece(int p) {
//  	// cf EditableFigure.selectAt()
//  	if ( p >= PIECE_UNSEL_FIRST &&  p <= PIECE_UNSEL_LAST ){
//  	    CalcPiece dum = pieces[p];
//  	    System.arraycopy(pieces, p + 1, pieces, p, NB_PIECES - 1 - p);
//  	    pieces[NB_PIECES - 1] = dum;
//  	}
//      }


//      public int selectAt(double x, double y) {
//  	for (int i = NB_PIECES - 1; i >= 0; i--){
//  	    if (pieces[i].contains(x, y)){
//  		selectPiece(i);
//  		return i;
//  	    }
//  	}
//  	return -1;
//      }


    public CalcPolyTriangles getFigureTinyTab() {

	if ( figureTinyTabLastChange != figureChangeCount ) {

	    for ( Iterator i = pieces.iterator(); i.hasNext(); ) {
		((CalcPiece) i.next()).putInTinyTab();
	    } 

	    // centrage
	    double[] x = figureTinyTab.xtriangles;
	    double[] y = figureTinyTab.ytriangles;
	    tinyXMean = tinyYMean = 0;

	    for ( int i = NB_TINY - 1; i >= 0; i-- ) {
		tinyXMean += x[i];
		tinyYMean += y[i];
	    } 
	    
	    tinyXMean /= NB_TINY;
	    tinyYMean /= NB_TINY;

	    figureTinyTabLastChange = figureChangeCount;
	}

	return figureTinyTab;
    }


    public CalcPolyPoints getMinMax() {
	if ( minMaxLastChange != figureChangeCount ) {

	    double minX = 1e10;
	    double minY = 1e10;
	    double maxX = -1e10;
	    double maxY = -1e10;

	    for ( Iterator i = pieces.iterator(); i.hasNext(); ) {
		CalcPolyPoints cp = ((CalcPiece) i.next()).getPolygon();
		double[] x = cp.xpoints;
		double[] y = cp.ypoints;

		for ( int j = 0; j < cp.npoints; j++ ) {
		    if ( x[j] < minX) {
			minX = x[j];
		    }
		    if ( y[j] < minY) {
			minY = y[j];
		    }
		    if ( x[j] > maxX) {
			maxX = x[j];
		    }
		    if ( y[j] > maxY) {
			maxY = y[j];
		    }
		} 
	    }

//  	    System.out.println(minX + ":" + minY + ":" + maxX + ":" + maxY);
	    
	    minMax.xpoints[0] = minX;
	    minMax.xpoints[1] = maxX;
	    minMax.ypoints[0] = minY;
	    minMax.ypoints[1] = maxY;

	    minMaxLastChange = figureChangeCount;
	} 

	return minMax;
    }


    /**
     * Iterator sur les pi�ces.
     */

    public Iterator pieceIterator() {
	return pieces.iterator();
    }


    /**
     * Liste des polygones de l' outline.
     */

    public List getOutlinePolygons() {

	if ( outlinePolygonsLastChange != figureChangeCount ) {

	    outlinePolygons = StaticCalcOutline.createOutline(this);

	    outlinePolygonsLastChange = figureChangeCount;
	} 

	return outlinePolygons;
    }


    /**
     *
     */

    public String toString() {

	StringBuffer sb = new StringBuffer(200);
	
	sb.append(getClass().getName());

	sb.append("[");
	for ( Iterator i = pieces.iterator(); i.hasNext(); ) {
	    sb.append(((CalcPiece) i.next()).toString());
	}
	sb.append("]");

	return sb.toString();
    }


    /**
     * Compare deux figures.
     *
     * @param accuracy precision de la comparaison. [0..2]
     */

    public boolean compare( CalcFigure fig2, int accuracy ) {

	long time = System.currentTimeMillis();

	double distMinMax;
	double dirDiffMax;

	switch ( accuracy ) {
	case COMPARE_ACCURACY_HIGH:
	    distMinMax = 1;
	    dirDiffMax = 64;
	    break;
	    
	case COMPARE_ACCURACY_LOW:
	    distMinMax = 4;
	    dirDiffMax = 32;
	    break;
	    
	case COMPARE_ACCURACY_MEDIUM:
	default:
	    distMinMax = 2;
	    dirDiffMax = 32;
	    break;
	} 
	
	distMinMax = Math.pow(distMinMax * 0.1, 2);
	dirDiffMax = Math.PI * 2 / dirDiffMax;

	CalcPolyTriangles tab1 = this.getFigureTinyTab();
	CalcPolyTriangles tab2 = fig2.getFigureTinyTab();

	double[] x1 = tab1.xtriangles;
	double[] y1 = tab1.ytriangles;
	double[] r1 = tab1.rtriangles;

	double[] x2 = tab2.xtriangles;
	double[] y2 = tab2.ytriangles;
	double[] r2 = tab2.rtriangles;

	for ( int i = NB_TINY - 1; i >= 0; i-- ) {
	    libre[i] = true;
	} 
	
	int i, j;
	int jMin;
	double dist, distMin;
	double iX, iY, iDir;
	double dirDiff;

	for (i = NB_TINY - 1; i >= 0; i--) {
	    jMin = 0;
	    distMin = 100000;
	    iX = x1[i] - tinyXMean + fig2.tinyXMean;
	    iY = y1[i] - tinyYMean + fig2.tinyYMean;
	    iDir = r1[i];

	    for (j = NB_TINY - 1; j >= 0; j--) {
		if (libre[j]) {

		    dist = Math.pow(iX - x2[j], 2) + Math.pow(iY - y2[j], 2);
		    dirDiff = Math.abs(iDir - r2[j]);

		    if ( dirDiff > Math.PI ) {
			 dirDiff = Math.PI * 2 - dirDiff;
		    }

		    if ( dist < distMin && dirDiff < dirDiffMax ) {
			distMin = dist;
			jMin = j;
		    }
		}
	    }

	    libre[jMin] = false;

	    if ( distMin > distMinMax ) {

		if ( DEBUG ) {
		    time = System.currentTimeMillis() - time;  // *debug*
		    System.out.println("comparaison --- " + time);
		}
		    
		return false;
	    }
	}

	if ( DEBUG ) {
	    time = System.currentTimeMillis() - time;  // *debug*
	    System.out.println("comparaison *** " + time);
	}
		
	return true;
    }

    
    /**
     * La StoredFigure correspondante.
     */

    public StoredFigure getStoredFigure() {
	return new StoredFigure(this);
    }


    /**
     * Version all�g�e.
     * Contient le minimum d'attribut et des m�thodes de conversion avec le format
     * des fichiers gTans.
     */

    public static class StoredFigure {

	private CalcPiece.StoredPiece[] pieces;


	/**
	 * valeurs par defaut.
	 */

	public StoredFigure() {

	    this(new CalcFigure());
	}


	/**
	 * CalcFigure -> StoredFigure.
	 */

	private StoredFigure( CalcFigure cf ) {

	    this.pieces = new CalcPiece.StoredPiece[cf.pieces.size()];

	    int idx = 0;
	    for ( Iterator i = cf.pieces.iterator(); i.hasNext(); ) {
		this.pieces[idx++] = ((CalcPiece) i.next()).getStoredPiece();
	    } 
	}

	
	/**
	 * StoredFigure -> CalcFigure.
	 */

	public CalcFigure getCalcFigure() {

	    Set pcs = new HashSet(this.pieces.length);

	    for ( int i = this.pieces.length - 1; i >= 0; i-- ) {
		pcs.add(this.pieces[i].getCalcPiece());
	    } 

	    return new CalcFigure(pcs);
	}


	/**
	 * Constructeur lisant dans un fichier au format gTans.
	 *
	 * @param st doit �tre en mode eolIsSignificant(true) et parseNumber().
	 */

	public StoredFigure(StreamTokenizer st) throws IOException {

	    pieces = new CalcPiece.StoredPiece[NB_PIECES];

//  	    for (int i  = 0; i < 10 ; i++) {
//  		st.nextToken();
//  		System.out.println(st.ttype + " " + st.sval + " " + st.nval);
		
//  	    } 

	    // une ligne de 3 nombres inutiles
	    if ( st.nextToken() != StreamTokenizer.TT_WORD ||
  		 st.nextToken() != StreamTokenizer.TT_WORD ||
  		 st.nextToken() != StreamTokenizer.TT_WORD ||
  		 st.nextToken() != StreamTokenizer.TT_EOL ) {
		throw new RuntimeException("ERROR : bad figure format : line=" + st.lineno());
	    }

	    for ( int i = this.pieces.length - 1; i >= 0; i-- ) {
		pieces[i] = new CalcPiece.StoredPiece(st);
	    } 

	    if ( st.nextToken() != StreamTokenizer.TT_EOL &&
		 st.ttype != StreamTokenizer.TT_EOF) {
		throw new RuntimeException("bad end of figure : missing empty line : line=" + st.lineno());
	    }
	}


	/**
	 * Convertit en String au format gTans. 
	 */

	public String toString() {

	    StringBuffer sb = new StringBuffer(512);

	    sb.append("1.0 1.0 1024\n");

	    for ( int i = pieces.length - 1; i >= 0; i-- ) {
		sb.append(pieces[i].toString());
	    } 

	    sb.append("\n");

	    return sb.toString();
	}
    }
}

