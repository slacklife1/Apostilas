
package net.phbwt.jtans.guimain;

import net.phbwt.jtans.guicommon.*;
import net.phbwt.jtans.calc.*;

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;


/**
 * Emet des PropertyChangeEvent :
 *   PROPERTY_FOUND lorsque la solution est trouv�e/resett�e.
 *   PROPERTY_SELECTION lorsque une pi�ce (de)selectionn�e.
 *
 * G�re tous les autre events (bon d'accord, c'est pas bien).
 */

public final class EditableFigureComponent extends JPanel implements Observer {

    public static final String PROPERTY_SELECTION = "jt.selection";
    public static final String PROPERTY_FOUND = "jt.found";

    private static final boolean DEBUG = false;

    public static final int MODE_NONE = 1;
    public static final int MODE_MOVE = 2;
    public static final int MODE_ROTATION = 3;

    // la config n�cessitant des acc�s graphiques
    private boolean gfxIsConfigured = false;

    // le fond et les pieces (unsel et sel)
    private Surface bgSurface;
    private Paint bgPaint;
    private Surface unselectedFiguresSurface;
    private Paint unselectedFiguresPaint;
    private Surface selectedFigureSurface;
    private Paint selectedFigurePaint;
    private Composite selectedFigureComposite;
    
    // le trait
    private Paint traitPaint;
    private Stroke traitStroke;
    private int traitGrow;  // augmentation de la zone � rafraichir pour tenir compte de la largeur du stroke

    // bordure des shapes
    private Paint borderPaint;
    private Stroke borderStroke;
    private int borderGrow; // augmentation de la zone � rafraichir pour tenir compte de la largeur du stroke

    // outline
    private Paint outlinePaint;
    private Stroke outlineStroke;

    // la marque "trouv�"
    private Shape foundMarkShapeScaled; // rescal�e � chaque changement de taille
    private Stroke foundMarkStroke;
    private Composite foundMarkComposite = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.2f);

    // rendering hints
    private RenderingHints hints;

    public EditableFigure fig;        // la figure dont les pi�ces sont affich�es
    public DisplayFigure outlineFig;  // la figure outlin�e

    private double refScale;

    // variables li�es au buffer offscreen 
    protected BufferedImage offImg; 
    protected Graphics2D offImgGr;
    protected int offImgW, offImgH;
    
    // taille des bordures haut et gauche (pour placement de l'image)
    int compBorderTop, compBorderLeft;
    
    // zone � rafraichir pour effacer la pi�ce selectionn�e
    Rectangle selectedPieceLastBounds;
    // juste pour �viter de cr�er un objet local pour le grow()
    Rectangle selectedPieceActualBounds = new Rectangle();
    
    // zone � rafraichir pour effacer le trait de rotation 
    Rectangle traitLastBounds;
    // juste pour �viter de cr�er un objet local pour le grow()
    Rectangle traitActualBounds = new Rectangle();

    // trait de rotation
    Line2D.Double traitShape = new Line2D.Double();

    // derni�re position de la souris (pour MOVE et trait de ROTATION)
    // r�el ou dans les limites
    int lastX, lastY;

    // il y a une pi�ce selectionn�e
    boolean isSelected = false;

    // l'outline est affich�e
    boolean withOutline = false;

    // trouv� maintenant ( != figure d�j� trouv�e)
    boolean isFound = false;
    int compareAccuracy;

    // d�placement/rotation
    int actualMode = MODE_NONE;
    
    // gestion de la rotation
    int rotOriginX, rotOriginY;
    double rotOriginAngle;
    double rotRefAngle;

    // i18n
    private static ResourceBundle i18n = null;


    /**
     *
     * @param ef La figure affich�e.
     * @param of La figure outlin�e.
     * @param li l'Observer notifi� lorsque la solution est trouv�e 
     */

    EditableFigureComponent(EditableFigure ef, DisplayFigure of, Config cf) {
	setOpaque(true);
	setDoubleBuffered(true);
	
	fig = ef;
	outlineFig = of;

	config(cf);
	cf.addObserver(this);

	if ( i18n == null ) {
	    i18n = ResourceBundle.getBundle("net.phbwt.jtans.i18n.main");
	} 
	
	// changement de taille
	this.addComponentListener(new ComponentAdapter() {
		public void componentResized(ComponentEvent e) {

		    if ( DEBUG ) {
			System.out.println("taille");
		    } 
		    
		    setScale(refScale);

		    offImg = null;

		    // marque
		    foundMarkShapeScaled = null;  // � recr�er
		    foundMarkStroke = new BasicStroke(((float) getWidth()) / 150f,
						      BasicStroke.CAP_ROUND,
						      BasicStroke.JOIN_ROUND);

		    repaint(); // sinon pb. � la diparition de la statusbar
		}
	    });


	// click
	this.addMouseListener(new MouseAdapter() { 
		public void mouseReleased(MouseEvent e) {
		    traitShape.setLine(rotOriginX, rotOriginY, rotOriginX, rotOriginY);
		    refreshSelectedPiece();
		    actualMode = MODE_NONE;

		    if (!isFound && fig.getCalcFigure().compare(outlineFig.getCalcFigure(),
							      compareAccuracy)) {
			isFound = true;
			unselect();
			repaint(); // dessine la marque

			firePropertyChange(PROPERTY_FOUND, false, true);
		    } 
		}

		public void mousePressed(MouseEvent e) {

		    // d�j� trouv�
		    if (isFound) return;

		    int x = e.getX();
		    int y = e.getY();
		    int sel = fig.selectAt( x, y);
		    
		    if ( sel == EditableFigure.SEL_NONE &&
			 isSelected &&
			 (e.getModifiers() & InputEvent.BUTTON1_MASK) != 0 ) {
			// passage en mode rotation
//  			System.out.println("mode rot");
			actualMode = MODE_ROTATION;
			rotOriginX = fig.getSelectedPiece().getPosX();
			rotOriginY = fig.getSelectedPiece().getPosY();
			rotOriginAngle = fig.getSelectedPiece().getRotation();
			rotRefAngle = Math.atan2(x - rotOriginX, y - rotOriginY);
//  			System.out.println("mode rot:orig=" + rotOriginAngle + ":ref=" + rotRefAngle);

			traitShape.setLine(rotOriginX, rotOriginY, x, y);
			refreshSelectedPiece();
		    } 

		    if ( sel != EditableFigure.SEL_NONE ) {
			// click dans une piece
//  			System.out.println("mode move");
			actualMode = MODE_MOVE;
			if ( sel == EditableFigure.SEL_NEW || !isSelected ) {
			    // selection d'une nouvelle piece (ou de l'ancienne si non selectionn�e)
			    boolean oldSel = isSelected;
			    isSelected = true;
//  			    refreshAll();
			    redrawOffscreenImage(true);
			    repaint();

			    firePropertyChange(PROPERTY_SELECTION, oldSel, true);
			} 
		    } 
		    
		    if ( ( e.getClickCount() == 2 ||
			   (e.getModifiers() & InputEvent.BUTTON3_MASK) != 0 )
			 && isSelected ) {
			fig.flipSelectedPiece();
			refreshSelectedPiece();
		    } 

		    lastX = x;
		    lastY = y;
		}
	    });
    

	// drag 
	this.addMouseMotionListener(new MouseMotionAdapter() { 
		public void mouseDragged(MouseEvent e) {
		    
		    switch ( actualMode) {

		    case MODE_MOVE:
			Point p = fig.translateSelectedPiece(e.getX() - lastX, e.getY() - lastY);

			lastX += p.x;
			lastY += p.y;
			refreshSelectedPiece();

			break;
			
		    case MODE_ROTATION:
			double angle = rotOriginAngle -
			    rotRefAngle +
			    Math.atan2(e.getX() - rotOriginX, e.getY() - rotOriginY);
//  			System.out.println("angle=" + angle);

			fig.setRotationForSelectedPiece(angle);

			lastX = e.getX();
			lastY = e.getY();

			traitShape.setLine(rotOriginX, rotOriginY, lastX, lastY);

			refreshSelectedPiece();

			break;
		    } 
		} 
	    });
    }


    /**
     * Prend en compte les modifs de la config.
     * N'est pas appell� � l'init.
     */

    public void update(Observable obs, Object obj) {

	if ( DEBUG ) {
	    System.out.println("editfig update");
	}	

	config((Config) obs);
	refreshAll();
    }


    /**
     * R�cup�re les param�tres dans la config.
     * Pas d'acc�s graphiques.
     */

    private void config(Config cf) {

	if ( DEBUG ) {
	    System.out.println("editfig config");
	}	

	Trait t;

	bgSurface = cf.getSurface("main.background");
	
	unselectedFiguresSurface = cf.getSurface("main.piece.normal");
	
	selectedFigureSurface = cf.getSurface("main.piece.selected");
	
	selectedFigureComposite = cf.getComposite("main.piece.selected.alpha");

	t = cf.getTrait("main.rotation");
	traitPaint = t.getColor(); 
	traitStroke = t.getStroke(); 
	traitGrow = t.getGrow();
	
	t = cf.getTrait("main.piece.border");
	borderPaint = t.getColor(); 
	borderStroke = t.getStroke(); 
	borderGrow = t.getGrow();
	
	t = cf.getTrait("main.outline");
	outlinePaint = t.getColor(); 
	outlineStroke = t.getStroke(); 

	// taille relative
	setScale(cf.getDouble("main.scale", 0.1d));

	// type de rotation
	switch ( cf.getInt("main.rotationStep", Config.ROTATION_STEP_32)) {
	case Config.ROTATION_CONTINUOUS:
	    fig.setSteppedRotation(-1d, 0d);
	    break;
	    
	case Config.ROTATION_STEP_32:
	    fig.setSteppedRotation(Math.PI / 16, 0d);
	    break;
	    
	case Config.ROTATION_STEP_AUTO:
	    fig.setSteppedRotation(Math.PI / 16, 0d);
	    break;
	} 

	// pr�cision de comparaison
	compareAccuracy = cf.getInt("main.compareAccuracy", CalcFigure.COMPARE_ACCURACY_MEDIUM);
//  	System.out.println("accuracy" + compareAccuracy);

	// rendering
	hints = cf.getRenderingHints();

	// provoque une re-init graphique
	offImg = null;           // pour dessiner avec les bons hints
	gfxIsConfigured = false;
    }


    /**
     * post config (n�cessitant un contexte graphique).
     */

    private void configGfx() {

	if ( DEBUG ) {
	    System.out.println("editfig config gfx");
	}
	
	bgPaint = bgSurface.getPaintNoError(this); 
	unselectedFiguresPaint = unselectedFiguresSurface.getPaintNoError(this); 
	selectedFigurePaint = selectedFigureSurface.getPaintNoError(this); 


//  	if ( bgSurface != null) {
//  	    bgPaint = bgSurface.getPaint(this); 
//  	} else {
//  	    bgPaint = new Color(190, 190, 200);
//  	}
	
//  	if ( unselectedFiguresSurface != null) {
//  	    unselectedFiguresPaint = unselectedFiguresSurface.getPaint(this); 
//  	} else {
//  	    unselectedFiguresPaint = Color.black;
//  	}

//  	if ( selectedFigureSurface != null) {
//  	    selectedFigurePaint = selectedFigureSurface.getPaint(this); 
//  	} else {
//  	    selectedFigurePaint = new Color(100, 100, 100);
//  	}

	gfxIsConfigured = true;
    }


    public final void paintComponent(Graphics g){

	// partie graphique de la configuration (si n�cessaire)
	if ( !gfxIsConfigured ) {
	    configGfx();
	} 

	Graphics2D g2 = (Graphics2D)g;
	Stroke oldStroke = g2.getStroke();
	Composite oldComposite = null; // utilis� si le composite est modifi�

	// cr�e et dessine le buffer
	if ( offImg == null ) {
	    redrawOffscreenImage(false);
	}	

	// le fond et les shapes non selectionn�es
      	g2.drawImage(offImg, compBorderLeft, compBorderTop, this);

	// le trait de rotation
	if ( actualMode == MODE_ROTATION ) {
	    // dessin du trait
	    g2.setPaint(traitPaint);
  	    g2.setStroke(traitStroke);
  	    g2.draw(traitShape);
	    if ( traitLastBounds == null ) {
		traitLastBounds = new Rectangle();
	    } 
	    // recopie le contenu (pas la r�f�rence)
	    traitLastBounds.setBounds(traitShape.getBounds());
   	    traitLastBounds.grow(traitGrow, traitGrow);  // en gros moiti� de la largeur du trait
	} 

	// dessin de la shape selectionn�e
	if ( isSelected ) {
	    
	    g2.setPaint(selectedFigurePaint);

	    if ( selectedFigureComposite != null ) {
		oldComposite = g2.getComposite();
		g2.setComposite(selectedFigureComposite);
	    } 
	} else {
	    g2.setPaint(unselectedFiguresPaint);
	} 

	g2.fill(fig.getSelectedPiece());
	g2.setPaint(borderPaint);
	g2.setStroke(borderStroke);
	g2.draw(fig.getSelectedPiece());

	// pour effacement de l'ancienne pi�ce
	if ( selectedPieceLastBounds == null ) {
	    selectedPieceLastBounds = new Rectangle();
	} 

	// recopie le contenu (pas la r�f�rence)
	selectedPieceLastBounds.setBounds(fig.getSelectedPiece().getBounds());
	selectedPieceLastBounds.grow(borderGrow, borderGrow);  // moiti� de la largeur du trait

	// marque
	if ( isFound ) {

	    long time = System.currentTimeMillis();

	    // (re)cr�e la forme
	    if (foundMarkShapeScaled == null) {
		foundMarkShapeScaled = createFoundMarkShape(g2);
	    }

	    if (oldComposite == null) {
		oldComposite = g2.getComposite();
	    } 
	    
	    g2.setComposite(foundMarkComposite);
	    g2.setPaint(Color.white);
	    g2.fill(foundMarkShapeScaled);
	    g2.setStroke(foundMarkStroke);
	    g2.setPaint(Color.black);
	    g2.draw(foundMarkShapeScaled);

	    if (DEBUG) {
		time = System.currentTimeMillis() - time; // *debug*
		System.out.println("redraw foundMark :" + time);
	    } 
	} 	

	// restaure l'�tat de d�part
	g2.setStroke(oldStroke);
	if (oldComposite != null) {
	    g2.setComposite(oldComposite);
	} 
    }
    
    
    /**
     * Red�ssine le buffer apr�s l'avoir cr�� si n�cessaire.
     * Dessine le fond, l'outline, les pi�ces no selectionn�es.
     */

    protected void redrawOffscreenImage(boolean fast){

	if ( DEBUG ) {
	    System.out.println("offscreenImage redessine");
	}
	    
	if ( offImg == null ) {

	    if ( DEBUG ) {
		System.out.println("offscreenImage recree");
	    }

	    Insets in = getInsets();
	    compBorderLeft = in.left;
	    compBorderTop = in.top;
	    int w = getWidth() - in.left - in.right;
	    int h = getHeight() - in.top - in.bottom;
	    
	    offImg = (BufferedImage)createImage(w, h);
	    offImgGr = (Graphics2D)offImg.createGraphics();

  	    offImgGr.translate(-compBorderLeft, -compBorderTop);
//  	    fig.setRefX(-compBorderLeft, -compBorderTop);

//  	    offImgGr.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC));
//  	    offImgGr.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION,
//  				      RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED);

	    // valeur par d�faut �cras�es
	    offImgGr.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				      RenderingHints.VALUE_ANTIALIAS_OFF);
	    offImgGr.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING,
				      RenderingHints.VALUE_COLOR_RENDER_SPEED);
	    offImgGr.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
				      RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
	    offImgGr.setRenderingHint(RenderingHints.KEY_DITHERING,
				      RenderingHints.VALUE_DITHER_DISABLE);
	    offImgGr.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,
				      RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
	    offImgGr.setRenderingHint(RenderingHints.KEY_RENDERING,
				      RenderingHints.VALUE_RENDER_SPEED);

	    offImgGr.addRenderingHints(hints);

	    offImgW = w;
	    offImgH = h;

	    fast = false;
	}
	
	long time = System.currentTimeMillis(); // *debug*

	if ( fast && fig.getPreviousSelectedPiece() != null ) {
	    Rectangle rect = fig.getPreviousSelectedPiece().getBounds()
		.union(fig.getSelectedPiece().getBounds());
	    rect.grow(traitGrow, traitGrow);
	    offImgGr.setClip(rect);
	} else {
	    offImgGr.setClip(null);
	} 

	// le fond
	offImgGr.setPaint(bgPaint);
	offImgGr.fill(new Rectangle(compBorderLeft, compBorderTop, offImgW, offImgH));
	
	// l'outline
	if ( withOutline ) {
	    offImgGr.setPaint(outlinePaint);
	    offImgGr.setStroke(outlineStroke);
	    for ( Iterator i = outlineFig.outlineIterator(); i.hasNext(); ) {
		offImgGr.draw((PixelOutlinePolygon) i.next());
	    } 
	} 
	
	// les shapes non s�lectionn�es
	for ( Iterator i = fig.pieceIteratorBottomUp(); i.hasNext();) {
	    Shape s = (Shape)i.next();
	    offImgGr.setPaint(unselectedFiguresPaint);
	    offImgGr.fill(s);
	    offImgGr.setPaint(borderPaint);
	    offImgGr.setStroke(borderStroke);
	    offImgGr.draw(s);
	}

//  	// les tiny triangles
//  	offImgGr.setPaint(Color.red);
//  	TinyTab tt = fig.calcFig.getFigureTinyTab();
//  	for ( int i = 0; i < tt.ntriangles; i++ ) {
//  	    int x = (int)(tt.xtriangles[i] * fig.scale) + fig.refX;
//  	    int y = (int)(tt.ytriangles[i] * fig.scale) + fig.refY;
//  	    offImgGr.drawLine(x, y, x + 1, y + 1);
//  	} 

//  	// la shape selectionn�e
//  	offImgGr.setPaint(selectedFigurePaint);
//  	offImgGr.fill(fig.shapes[CalcFigure.PIECE_SELECTED]);

	if ( DEBUG ) {
	    time = System.currentTimeMillis() - time; // *debug*
	    System.out.println("duree redraw=" + time + ":clipping=" + offImgGr.getClip());
	}
    }
    
    
    public void refreshSelectedPiece() {

	if ( actualMode == MODE_ROTATION ) {
	    
	    // red�ssine le fond sous le trait de rotation
	    if ( traitLastBounds != null ) {
  		this.repaint(traitLastBounds);
	    } 
	    
	    // red�ssine le trait
	    traitActualBounds.setBounds(traitShape.getBounds());
	    traitActualBounds.grow(traitGrow, traitGrow);  // moiti� de la largeur du stroke
	    this.repaint(traitActualBounds);
	} 

	// red�ssine le fond sous l'ancienne position
	if ( selectedPieceLastBounds != null ) {
	    this.repaint(selectedPieceLastBounds);
	} 
	
	// d�ssine � la position actuelle
	selectedPieceActualBounds.setBounds(fig.getSelectedPiece().getBounds());
	selectedPieceActualBounds.grow(borderGrow, borderGrow);  // moiti� de la largeur du trait
	this.repaint(selectedPieceActualBounds);
    }


    public void refreshAll() {

	if ( !gfxIsConfigured ) {
	    configGfx();
	} 

	redrawOffscreenImage(false);
	this.repaint();
    }


    /**
     * (D�) s�lectionne l'affichage de l'outline.
     * Appelle refreshAll(). 
     */

    public void toggleOutline() {
	withOutline = ! withOutline;
	refreshAll();
    }

    
    /**
     * Change de figure outline.
     * Passe en mode outline non affich�e.
     * Peut appeller refreshAll(). 
     */

    public void setOutlineFigure(DisplayFigure df) {
	outlineFig = df;

	if (isFound) {
	    isFound = false;
	    firePropertyChange(PROPERTY_FOUND, true, false);
 	    repaint(); // efface la marque
	}

	setScale(refScale);
	if ( withOutline ) {
	    toggleOutline();
	} 
    }


    /**
     * D�s�lectionne la piece.
     * Appelle refreshAll(). 
     */

    public void unselect() {
	if (isSelected) {
	    isSelected = false;
// 	    refreshAll();
	    refreshSelectedPiece();

	    firePropertyChange(PROPERTY_SELECTION, true, false);
	} 
    }


    /**
     * Flippe la piece.
     * Appelle refreshSelectedPiece(). 
     */

    public void flip() {
	if (! isFound) {
	    fig.flipSelectedPiece();
	    refreshSelectedPiece();
	} 
    }


    /**
     * Modifie la taille relative des pi�ce.
     * Recalcule le scale interne (qui d�pends aussi de la taille du composant).
     * L'outline est recentr�e.
     * ne redessine pas : peut �tre suivie par refreshAll();
     */

    public void setScale(double newScale) {
	
	refScale = newScale;

	Insets in = getInsets();
	double scale = refScale * (getWidth() - in.left - in.right);
	fig.setScale(scale);
	fig.setLimits( in.left,
		       in.top,
		       getWidth() - in.right,
		       getHeight() - in.bottom );
	outlineFig.setScale(scale);
	outlineFig.center( in.left,
			   in.top,
			   getWidth() - in.right,
			   getHeight() - in.bottom );
    }


    protected final Graphics getComponentGraphics(Graphics g) {
	((Graphics2D) g).addRenderingHints(hints);
//  	((Graphics2D) g).setComposite(AlphaComposite.getInstance(AlphaComposite.SRC));
//  	((Graphics2D) g).setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION,
//  			   RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED);
	return g;
    }


    /**
     * Cr�e la forme.
     */

    private Shape createFoundMarkShape(Graphics2D g2) {

	if (DEBUG) {
	    System.out.println("createFoundMarkShape");
	}

	Shape ret;

	// arrangement (1 : toute la largeur/hauteur)
	double scaleX, scaleY;

	// creation de la marque/texte
	Font f = new Font("SansSerif", Font.PLAIN, 10);
	java.awt.font.GlyphVector gv;
 	String symbol = i18n.getString("foundMarkSymbol");
	if (f.canDisplayUpTo(symbol) < 0) {
	    gv = f.createGlyphVector(g2.getFontRenderContext(), symbol);
	    scaleX = scaleY = .75;
	} else {
	    // manque des glyph : fallback sur le 2�me texte
	    gv = f.createGlyphVector(g2.getFontRenderContext(), i18n.getString("foundMarkText"));
	    scaleX = 1;
	    scaleY = .5;
	} 
	Shape s = gv.getOutline();

	AffineTransform at = new AffineTransform();

	// [0..1] -> taille et pos. du component
	Insets in = getInsets();
	at.translate(in.left, in.top);
	at.scale(getWidth() - in.left - in.right, getHeight() - in.top - in.bottom);

	// arrangement
	at.translate((1 - scaleX) / 2, (1 - scaleY) / 2);
	at.scale(scaleX, scaleY);

	// texte -> [0..1]
	Rectangle r = s.getBounds();
	at.scale(1d / (r.getMaxX() - r.getMinX()), 1d / (r.getMaxY() - r.getMinY()));
	at.translate(-r.getMinX(), -r.getMinY());

	// transformation
	ret = at.createTransformedShape(s);

	return ret;
    }
}

