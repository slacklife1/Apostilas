
package net.phbwt.jtans.guimain;

import java.awt.*;
//  import java.awt.image.*;
//  import javax.swing.*;
//  import javax.swing.border.*;
//  import javax.swing.text.*;
//  import java.awt.event.*;


/**
 * Layout Manager gerant un composant carr�.
 * Ne peut contenir qu'un composant qu'il positionne
 * comme le plus grand carr� centr� possible dans le conteneur.
 */

public class LayoutCarre implements LayoutManager {
	
    private Dimension minDim = new Dimension(), prefDim = new Dimension();
    private double proportion;
    private boolean tailleInconnue = true;
    
    private void resetDim(Container parent) {
	if (parent.getComponentCount() > 0) {
	    Component comp = parent.getComponent(0);
	    proportion = 1.0;               //inutile pour l'instant

	    minDim = comp.getMinimumSize();

	    prefDim = comp.getPreferredSize();
	    prefDim.width = Math.max(prefDim.width, (int)(prefDim.height / proportion));
	    prefDim.height = Math.max(prefDim.height, (int)(prefDim.width * proportion));

	    tailleInconnue = false;
	}
    } 
    
    
    public void addLayoutComponent(String name, Component comp) {
	//System.out.println("add n c");
    }
    
    
    public void removeLayoutComponent(Component comp) {
	//System.out.println("rem");
    }
    
    
    public Dimension minimumLayoutSize(Container parent) {
	//System.out.println("min");
	
	if (tailleInconnue){
	    resetDim(parent);
	}
	
	return minDim;
    }
    
    
    public Dimension preferredLayoutSize(Container parent) {
	//System.out.println("pref");
	
	if (tailleInconnue){
	    resetDim(parent);
	}
	
	return prefDim;
    }
    
    
    public void layoutContainer(Container parent){
	
	if (tailleInconnue){
	    resetDim(parent);
	}
	
	switch (parent.getComponentCount()){
	    
	case 0:
	    break;
	    
	case 1:
	    Dimension taille = parent.getSize();
	    Insets insets = parent.getInsets();

	    taille.width -= insets.left + insets.right;
	    taille.height -= insets.top + insets.bottom;

	    int x = Math.min(taille.width, (int)(taille.height / proportion));
	    int y = Math.min(taille.height, (int)(taille.width * proportion));

	    parent.getComponent(0).setBounds( (taille.width-x) / 2 + insets.left,
					      (taille.height-y) / 2 + insets.top,
					      x,
					      y );
	    break;
	    
	default:
	    throw new IndexOutOfBoundsException("pas plus de 1 object");
	    
	}
    }
}
