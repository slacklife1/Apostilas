
package net.phbwt.jtans.guiconfig;

import net.phbwt.jtans.guicommon.*;

import java.awt.*;
import javax.swing.*;

/**
 * Component un exemple de Trait.
 */ 

final class TraitExampleComponent extends JLabel {

    private static Dimension preferredSize = new Dimension(30, 15);
    private static Dimension maxSize = new Dimension(500000, 200);

    private Trait trait;

    TraitExampleComponent(Trait t) {
	setOpaque(true);

	trait = t;

	setMinimumSize(preferredSize);
	setPreferredSize(preferredSize);
	setMaximumSize(maxSize);
//  	setBorder(BorderFactory.createEtchedBorder());
    }


    protected void paintComponent(Graphics g) {

	Graphics2D g2 = (Graphics2D)g;

	Stroke oldStroke = g2.getStroke();

	Insets inse = getInsets();

  	g2.setPaint(getBackground());

	g2.fillRect( inse.left,
		     inse.top,
		     getWidth() - inse.right,
		     getHeight() - inse.bottom );

	g2.setPaint(trait.getColor());
	g2.setStroke(trait.getStroke());

	int posY = inse.top + (getHeight() - inse.top - inse.bottom) / 2;

	g2.drawLine( inse.left,
		     posY,
		     getWidth() - inse.right,
		     posY );

	g2.setStroke(oldStroke);
    }
}

