
package net.phbwt.jtans.guiconfig;

import net.phbwt.jtans.guicommon.*;

import java.awt.*;
import javax.swing.*;

/**
 * Component remplis par un Surface.
 */ 

final class SurfaceExampleComponent extends JLabel {

    private static Dimension preferredSize = new Dimension(30, 15);
    private static Dimension maxSize = new Dimension(500000, 200);

    private Surface surface;

    SurfaceExampleComponent(Surface s) {
	setOpaque(true);

	surface = s;

	setMinimumSize(preferredSize);
	setPreferredSize(preferredSize);
	setMaximumSize(maxSize);
	setBorder(BorderFactory.createEtchedBorder());
    }


//      void setPaint(Paint p) {
//  	surface = p;
//  	repaint();
//      }


    protected void paintComponent(Graphics g) {

	Graphics2D g2 = (Graphics2D)g;

	g2.setPaint(surface.getPaintNoError(this));

	Insets inse = getInsets();

	g2.fillRect( inse.left,
		     inse.top,
		     getWidth() - inse.left - inse.right,
		     getHeight() - inse.top - inse.bottom );
    }
}

