//Example for ToolkitAWT and ListItemsSelectedMove
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import java.awt.*;
import java.awt.event.*;
import java.applet.Applet;

import softhema.system.toolkits.ToolkitAWT;

public class AppletListItemsSelectedMove extends Applet
{
  Button btnMoveUp = new Button();
  Button btnMoveDown = new Button();
  List list = new List();
  BorderLayout borderLayout = new BorderLayout();

  public AppletListItemsSelectedMove()
  {
   try
   {
    list.setMultipleSelections(true);   
    btnMoveUp.setLabel("Move Up");
    btnMoveUp.addActionListener(new java.awt.event.ActionListener()
    {

      public void actionPerformed(ActionEvent e)
      {
        btnMoveUp_actionPerformed(e);
      }
    });
    this.setLayout(borderLayout);

    btnMoveDown.setLabel("Move Down");
    btnMoveDown.addActionListener(new java.awt.event.ActionListener()
    {

      public void actionPerformed(ActionEvent e)
      {
        btnMoveDown_actionPerformed(e);
      }
    });
    this.add(btnMoveUp, BorderLayout.NORTH);
    this.add(list, BorderLayout.CENTER);
    this.add(btnMoveDown, BorderLayout.SOUTH);

   }
   catch(Exception e)
   {
      e.printStackTrace();
   }
  }

  public void start()
  {
    list.clear();
    list.addItem("cat");
    list.addItem("dog");
    list.addItem("fish");
    list.addItem("bear");
    list.addItem("bird");
    list.addItem("snake");
  }

  void btnMoveUp_actionPerformed(ActionEvent e)
  {
      ToolkitAWT.ListItemsSelectedMoveUp(list);
  }

  void btnMoveDown_actionPerformed(ActionEvent e)
  {
      ToolkitAWT.ListItemsSelectedMoveDown(list);
  }

}                
