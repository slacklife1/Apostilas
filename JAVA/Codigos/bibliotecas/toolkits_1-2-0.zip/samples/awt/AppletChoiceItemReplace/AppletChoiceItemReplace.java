//Example for ToolkitAWT and ChoiceItemReplace
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

import softhema.system.toolkits.ToolkitAWT;


public class AppletChoiceItemReplace extends Applet
{
  Choice choiceSelect = new Choice();
  TextField txtSelect = new TextField();
  BorderLayout borderLayout = new BorderLayout();

  public AppletChoiceItemReplace()
  {
    try
    {
    this.setLayout(borderLayout);
    borderLayout.setVgap(3);

    txtSelect.addTextListener(new java.awt.event.TextListener()
    {

      public void textValueChanged(TextEvent e)
      {
        txtSelect_textValueChanged(e);
      }
    });

    this.add(choiceSelect, BorderLayout.NORTH);
    this.add(txtSelect, BorderLayout.CENTER);

    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  public void start()
  {
      this.remove(choiceSelect);
      choiceSelect = new Choice();
      choiceSelect.addItemListener(new java.awt.event.ItemListener()
      {
       public void itemStateChanged(ItemEvent e)
       {
        choiceSelect_itemStateChanged(e);
       }
      });
      this.add(choiceSelect, BorderLayout.NORTH);

      choiceSelect.addItem("monkey");
      choiceSelect.addItem("snake");
      choiceSelect.addItem("cat");
      choiceSelect.addItem("dog");
      choiceSelect.addItem("rabbit");
      choiceSelect.addItem("bird");
      choiceSelect.select(0);
      choiceSelect_itemStateChanged(null);
  }

  void choiceSelect_itemStateChanged(ItemEvent e)
  {
      txtSelect.setText( choiceSelect.getSelectedItem() );
  }

  void txtSelect_textValueChanged(TextEvent e)
  {
      ToolkitAWT.ChoiceItemReplace( choiceSelect,
                                    choiceSelect.getSelectedIndex(),
                                    txtSelect.getText(),
                                    true
                                   );
  }
}
