//Example for ToolkitAWT and ListItemsSelectedMove
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import java.awt.*;
import java.awt.event.*;

import softhema.system.toolkits.ToolkitAWT;

public class ListItemsSelectedMove extends Frame
{
  Button btnMoveUp = new Button();
  Button btnMoveDown = new Button();
  List list = new List();
  BorderLayout borderLayout = new BorderLayout();

  public ListItemsSelectedMove()
  {
   try
   {
    list.setMultipleSelections(true);   
    btnMoveUp.setLabel("Move Up");
    btnMoveUp.addActionListener(new java.awt.event.ActionListener()
    {

      public void actionPerformed(ActionEvent e)
      {
        btnMoveUp_actionPerformed(e);
      }
    });
    this.setLayout(borderLayout);
    btnMoveDown.setName("");
    btnMoveDown.setLabel("Move Down");
    btnMoveDown.addActionListener(new java.awt.event.ActionListener()
    {

      public void actionPerformed(ActionEvent e)
      {
        btnMoveDown_actionPerformed(e);
      }
    });
    this.addWindowListener(new java.awt.event.WindowAdapter()
    {

      public void windowClosing(WindowEvent e)
      {
        this_windowClosing(e);
      }
    });
    this.add(btnMoveUp, BorderLayout.NORTH);
    this.add(list, BorderLayout.CENTER);
    this.add(btnMoveDown, BorderLayout.SOUTH);

    list.addItem("cat");
    list.addItem("dog");
    list.addItem("fish");
    list.addItem("bear");
    list.addItem("bird");
    list.addItem("snake");
    setSize(150,250);
    setTitle("Softhema AWT Example");
    show(true);
   }
   catch(Exception e)
   {
      e.printStackTrace();
   }
  }

  public static void main(String[] args)
  {
    ListItemsSelectedMove listItemsSelectedMove1 = new ListItemsSelectedMove();
  }


  void btnMoveUp_actionPerformed(ActionEvent e)
  {
      ToolkitAWT.ListItemsSelectedMoveUp(list);
  }

  void btnMoveDown_actionPerformed(ActionEvent e)
  {
      ToolkitAWT.ListItemsSelectedMoveDown(list);
  }

  void this_windowClosing(WindowEvent e)
  {
    System.exit(0);
  }
}                
