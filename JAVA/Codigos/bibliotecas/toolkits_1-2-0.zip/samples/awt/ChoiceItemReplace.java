//Example for ToolkitAWT and ChoiceItemReplace
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitAWT;
import java.awt.*;
import java.awt.event.*;

public class ChoiceItemReplace extends Frame
{
  Choice choiceSelect = new Choice();
  TextField txtSelect = new TextField();
  BorderLayout borderLayout = new BorderLayout();

  public ChoiceItemReplace()
  {
    try
    {
    this.setLayout(borderLayout);
    borderLayout.setVgap(3);
    this.setTitle("Softhema Example");
    this.addWindowListener(new java.awt.event.WindowAdapter()
    {

      public void windowClosing(WindowEvent e)
      {
        this_windowClosing(e);
      }
    });
    choiceSelect.addItemListener(new java.awt.event.ItemListener()
    {

      public void itemStateChanged(ItemEvent e)
      {
        choiceSelect_itemStateChanged(e);
      }
    });
    txtSelect.addTextListener(new java.awt.event.TextListener()
    {

      public void textValueChanged(TextEvent e)
      {
        txtSelect_textValueChanged(e);
      }
    });
    this.add(choiceSelect, BorderLayout.NORTH);
    this.add(txtSelect, BorderLayout.CENTER);

      choiceSelect.addItem("monkey");
      choiceSelect.addItem("snake");
      choiceSelect.addItem("cat");
      choiceSelect.addItem("dog");
      choiceSelect.addItem("rabbit");
      choiceSelect.addItem("bird");
      choiceSelect.select(0);
      choiceSelect_itemStateChanged(null);
      setSize(400,80);
      show(true);
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  public static void main(String[] args)
  {
    ChoiceItemReplace choiceItemReplace = new ChoiceItemReplace();
  }

  void choiceSelect_itemStateChanged(ItemEvent e)
  {
      txtSelect.setText( choiceSelect.getSelectedItem() );
  }

  void txtSelect_textValueChanged(TextEvent e)
  {
      ToolkitAWT.ChoiceItemReplace( choiceSelect,
                                    choiceSelect.getSelectedIndex(),
                                    txtSelect.getText(),
                                    true
                                   );
  }

  void this_windowClosing(WindowEvent e)
  {
    System.exit(0);
  }
}
