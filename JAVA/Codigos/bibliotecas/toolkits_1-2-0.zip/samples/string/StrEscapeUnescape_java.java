//Example for ToolkitString.strEscape_Java and strUnescape_Java
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitString;
import softhema.system.toolkits.ToolkitIO;

public class StrEscapeUnescape_java
{
  public static void main( String[] args )
  {
   try
   {
     System.out.println( "Example Line 1\nExample Line\t2" );
     System.out.println( "Example Line 1\\nExample Line\\t2" );

     System.out.println( ToolkitString.strEscape_Java("Example Line 1\nExample Line\t2") );
     System.out.println( ToolkitString.strUnescape_Java("Example Line 1\\nExample Line\\t2") );
   }
   catch( Exception e )
   {
     e.printStackTrace();
   }
  }
}