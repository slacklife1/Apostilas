//Example for ToolkitString.strLike
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitString;
import softhema.system.toolkits.ToolkitIO;

public class StrSqueeze
{
  public static void main( String[] args )
  {
   try
   {
      ToolkitIO.printf("Input the text:");
      String[] as = new String[1];
      ToolkitIO.scanf("%ls", as );
      String sText = as[0];

      ToolkitIO.printf("\nInput the characters to eliminate:");
      ToolkitIO.scanf("%ls", as );
      char[] ach = as[0].toCharArray();

      String sNew = ToolkitString.strSqueeze( sText, ach );
      ToolkitIO.printf("\nNew text:%s", sNew );
   }
   catch( Exception e )
   {
     e.printStackTrace();
   }
  }
}