//Example for ToolkitString.isLikeEx
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitString;
import softhema.system.toolkits.ToolkitIO;

public class IsLikeEx
{
  public static void main( String[] args )
  {
   try
   {
      ToolkitIO.printf("\nInput a password:");
      String pwd = ToolkitIO.readStringLine();

      if( ToolkitString.isLikeEx( pwd, "[a-z]?*" ) )
      {
        //The password must contains two s-characters.
        ToolkitIO.printf("\nThe password %s is correct.", pwd);
      }
      else
      {
        ToolkitIO.printf("\nThe password %s is not correct.", pwd);
      }
   }
   catch( Exception e )
   {
     e.printStackTrace();
   }
  }
}