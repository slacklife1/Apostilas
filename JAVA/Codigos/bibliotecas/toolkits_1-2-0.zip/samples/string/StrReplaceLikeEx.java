//Example for ToolkitString.strReplaceLikeEx
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitString;

public class StrReplaceLikeEx
{
  public static void main( String[] args )
  {
   try
   {
      System.out.println( ToolkitString.strReplaceLikeEx("abcdefghi", "b[a-e]", "x") );
      System.out.println( ToolkitString.strReplaceLikeEx("abcdefghi", "[a-e][a-e]", "x") );
      System.out.println( ToolkitString.strReplaceLikeEx("abcdefghi", "?[c-e][a-e]?", "x") );
      System.out.println( ToolkitString.strReplaceLikeEx("abcdefghi", "?[c-e][a-e]*", "x") );
      System.out.println( ToolkitString.strReplaceLikeEx("abcdefghi", "?[c-e]*[a-e]", "x") );
      System.out.println( ToolkitString.strReplaceLikeEx("abcdefghi", "?[c-e]*[f-h]", "x") );
      System.out.println( ToolkitString.strReplaceLikeEx("abcdefghi", "?[c-e]*[g-h]", "x") );
   }
   catch( Exception e )
   {
     e.printStackTrace();
   }
  }
}