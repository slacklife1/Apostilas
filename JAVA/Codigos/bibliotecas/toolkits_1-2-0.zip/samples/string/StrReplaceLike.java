//Example for ToolkitString.strReplaceLike
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitString;

public class StrReplaceLike
{
  public static void main( String[] args )
  {
   try
   {
      System.out.println( ToolkitString.strReplaceLike("abcde", "f", "x") );
      System.out.println( ToolkitString.strReplaceLike("abcde", "*", "xyz") );
      System.out.println( ToolkitString.strReplaceLike("abcde", "*", "") );
      System.out.println( ToolkitString.strReplaceLike("abcde", "abc*", "xyz") );
      System.out.println( ToolkitString.strReplaceLike("abcde", "*c", "xyz") );
      System.out.println( ToolkitString.strReplaceLike("abcde", "b?d", "xyz") );
      System.out.println( ToolkitString.strReplaceLike("abcde", "b?d?", "xyz") );
      System.out.println( ToolkitString.strReplaceLike("abcde", "b*d", "x") );  
   }
   catch( Exception e )
   {
     e.printStackTrace();
   }
  }
}