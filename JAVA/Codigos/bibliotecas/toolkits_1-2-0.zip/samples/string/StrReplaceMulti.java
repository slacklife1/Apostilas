//Example for ToolkitString.strReplaceMulti
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitString;
import softhema.system.toolkits.ToolkitIO;
import javax.swing.JOptionPane;

public class StrReplaceMulti
{
  public static void main( String[] args )
  {
   try
   {
      String s = JOptionPane.showInputDialog("Input text:");
      
      String sNew = ToolkitString.strReplaceMulti( s, new String[]{"�", "�", "�", "�", "�", "�", "�"},
                                                      new String[]{"ae","oe","ue","ss","Ae","Oe","Ue" } );

      ToolkitIO.printf("\n%s", sNew);
   }
   catch( Exception e )
   {
     e.printStackTrace();
   }
  }
}