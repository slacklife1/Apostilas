//Example for ToolkitString.strReplaceLike
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitString;

public class StrReplaceLike2
{
  public static void main( String[] args )
  {
   try
   {
      System.out.println( ToolkitString.strReplaceLike("Hello World Hello World Hello World", "Hello World", "Hi") );
      System.out.println( ToolkitString.strReplaceLike("Hello World Hello World Hello World", "H*d", "Hi") );
      System.out.println( ToolkitString.strReplaceLike("Hello World Hello World Hello World", "e*ld", "i") );
      System.out.println( ToolkitString.strReplaceLike("Hello World Hello World Hello World", "?e*d", "Hi") );

      System.out.println( ToolkitString.strReplaceLikeOnce("Hello World Hello World Hello World", "Hello World", "Hi") );
      System.out.println( ToolkitString.strReplaceLikeOnce("Hello World Hello World Hello World", "H*d", "Hi") );
      System.out.println( ToolkitString.strReplaceLikeOnce("Hello World Hello World Hello World", "e*ld", "i") );
      System.out.println( ToolkitString.strReplaceLikeOnce("Hello World Hello World Hello World", "?e*d", "Hi") );
   }
   catch( Exception e )
   {
     e.printStackTrace();
   }
  }
}