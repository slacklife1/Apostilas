//Example for ToolkitString.strReplaceLike
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitString;

public class StrReplaceLike4
{
  public static void main( String[] args )
  {
   try
   {

     String s;
     String sResult;
     String sRandom = "";

     for( int i = 0 ; i < 10000 ; i++ )
     {
        sRandom += (char) ('a' + (int)(Math.random() * 25));
     }

     s = "Example - Hello" + sRandom + "World - Example";

     sResult = ToolkitString.strReplaceLikeOnce( s , "Hello*World", "Hi" );

     System.out.println( sResult );

   }
   catch( Exception e )
   {
     e.printStackTrace();
   }
  }
}