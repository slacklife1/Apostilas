//Example for ToolkitString.strSplit
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitString;
import softhema.system.toolkits.ToolkitIO;

public class StrSplit
{
  public static void main( String[] args )
  {
   try
   {
     String[] as = ToolkitString.strSplit( "This is an example\nThis is the second line\n\rAnd this is the third line" );
     for( int i = 0 ; i < as.length ; i++)
     {
       ToolkitIO.printf("\n%3d:", i);
       ToolkitIO.printf("%s", as[i]);
     }
   }
   catch( Exception e )
   {
     e.printStackTrace();
   }
  }
}