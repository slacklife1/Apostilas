//Example for ToolkitString.strSplit
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitString;
import softhema.system.toolkits.ToolkitIO;

public class StrSplit2
{
  public static void main( String[] args )
  {
   try
   {
     String sSeparators = " \n\r\t,;:";
     char[] acSeparators = sSeparators.toCharArray();

     String[] as = ToolkitString.strSplit( ":::*software development*,software development:example:::java;:end::" , acSeparators, '*' );
     for( int i = 0 ; i < as.length ; i++)
     {
       ToolkitIO.printf("\n%3d:", i);
       ToolkitIO.printf("%s", as[i]);
     }
   }
   catch( Exception e )
   {
     e.printStackTrace();
   }
  }
}