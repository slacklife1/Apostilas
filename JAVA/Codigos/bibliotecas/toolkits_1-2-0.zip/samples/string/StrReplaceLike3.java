//Example for ToolkitString.strReplaceLike
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitString;

public class StrReplaceLike3
{
  public static void main( String[] args )
  {
   try
   {
      System.out.println( ToolkitString.strReplaceLike("men in black", "m*n*b*k", "mib") );
      System.out.println( ToolkitString.strReplaceLike("rush hour", "*r??? ?our", "rh") );
      System.out.println( ToolkitString.strReplaceLike("lethal weapon", "???p??", "sword") );
      System.out.println( ToolkitString.strReplaceLike("the fifth element", "e?e*t", "floor") );
      System.out.println( ToolkitString.strReplaceLike("independance day", "i*e??*e", "new") );
      System.out.println( ToolkitString.strReplaceLike("titanic", "?c", "") );
   }
   catch( Exception e )
   {
     e.printStackTrace();
   }
  }
}