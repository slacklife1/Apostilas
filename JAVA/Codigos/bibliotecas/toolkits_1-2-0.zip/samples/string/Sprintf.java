//Example for ToolkitString.strLike
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitString;
import java.util.ArrayList;
import java.util.List;

public class Sprintf
{
  public static void main( String[] args )
  {
   try
   {
     List list = new ArrayList();
     list.add( "Hello" );
     list.add( "World" );

     String s;
     s = ToolkitString.sprintf("%s %s !", list);
     
     System.out.println(s);
   }
   catch( Exception e )
   {
     e.printStackTrace();
   }
  }
}