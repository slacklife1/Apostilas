//Example for ToolkitString.strReplaceLike
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class AppletStrReplaceLike extends Applet
{
  Panel panel1 = new Panel();
  Label label1 = new Label();
  Label label2 = new Label();
  Label label3 = new Label();
  Label label4 = new Label();
  BorderLayout borderLayout1 = new BorderLayout();
  Label label5 = new Label();
  Panel panel2 = new Panel();
  BorderLayout borderLayout2 = new BorderLayout();
  Panel panel3 = new Panel();
  FlowLayout flowLayout1 = new FlowLayout();
  Button btnExample1 = new Button();
  Button btnExample2 = new Button();
  Button btnExample3 = new Button();
  Button btnExample4 = new Button();
  Button btnExample5 = new Button();
  Button btnExample6 = new Button();
  Panel panel4 = new Panel();
  BorderLayout borderLayout3 = new BorderLayout();
  Panel panel5 = new Panel();
  FlowLayout flowLayout2 = new FlowLayout();
  Checkbox chkIgnoreCase = new Checkbox();
  Checkbox chkReplaceOnce = new Checkbox();
  Checkbox chkExtended = new Checkbox();
  Panel panel6 = new Panel();
  BorderLayout borderLayout4 = new BorderLayout();
  Panel panel7 = new Panel();
  TextArea txtText = new TextArea();
  Label label6 = new Label();
  TextArea txtPattern = new TextArea();
  Label label7 = new Label();
  TextArea txtReplacement = new TextArea();
  Label lblText = new Label();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  Panel panel8 = new Panel();
  BorderLayout borderLayout5 = new BorderLayout();
  Button btnExecute = new Button();
  TextArea txtResult = new TextArea();
  Label lblText1 = new Label();
  Panel panel9 = new Panel();
  GridBagLayout gridBagLayout2 = new GridBagLayout();
  BorderLayout borderLayout6 = new BorderLayout();

  public AppletStrReplaceLike()
  {
    try 
    {
      jbInit();
      setBackground( SystemColor.control );
      validate();
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception
  {
    this.setLayout(borderLayout1);
    panel1.setLayout(borderLayout2);
    label5.setText("String result = ToolkitString.strReplaceLike( text , pattern , replacement " +
    ");");
    panel2.setLayout(borderLayout3);
    panel3.setLayout(flowLayout1);
    btnExample1.setLabel("Example1");
    btnExample1.addActionListener(new java.awt.event.ActionListener()
    {

      public void actionPerformed(ActionEvent e)
      {
        btnExample1_actionPerformed(e);
      }
    });
    btnExample2.setLabel("Example2");
    btnExample2.addActionListener(new java.awt.event.ActionListener()
    {

      public void actionPerformed(ActionEvent e)
      {
        btnExample2_actionPerformed(e);
      }
    });
    btnExample3.setLabel("Example3");
    btnExample3.addActionListener(new java.awt.event.ActionListener()
    {

      public void actionPerformed(ActionEvent e)
      {
        btnExample3_actionPerformed(e);
      }
    });
    btnExample4.setLabel("Example4");
    btnExample4.addActionListener(new java.awt.event.ActionListener()
    {

      public void actionPerformed(ActionEvent e)
      {
        btnExample4_actionPerformed(e);
      }
    });
    btnExample5.setLabel("Example5");
    btnExample5.addActionListener(new java.awt.event.ActionListener()
    {

      public void actionPerformed(ActionEvent e)
      {
        btnExample5_actionPerformed(e);
      }
    });
    btnExample6.setLabel("Example6");
    btnExample6.addActionListener(new java.awt.event.ActionListener()
    {

      public void actionPerformed(ActionEvent e)
      {
        btnExample6_actionPerformed(e);
      }
    });
    panel4.setLayout(borderLayout4);
    panel5.setLayout(flowLayout2);
    chkIgnoreCase.setLabel("Ignore case");
    chkReplaceOnce.setLabel("Replace once");
    chkExtended.setLabel("Extended");
    panel6.setLayout(borderLayout5);
    panel7.setLayout(gridBagLayout1);
    label6.setText("replacement:");
    label7.setText("pattern:");
    lblText.setText("text:");
    panel8.setLayout(borderLayout6);
    btnExecute.setLabel("Execute");
    btnExecute.addActionListener(new java.awt.event.ActionListener()
    {

      public void actionPerformed(ActionEvent e)
      {
        btnExecute_actionPerformed(e);
      }
    });
    lblText1.setText("result:");
    panel9.setLayout(gridBagLayout2);
    borderLayout6.setVgap(5);
    borderLayout5.setVgap(5);
    this.add(panel1, BorderLayout.CENTER);
    panel1.add(label5, BorderLayout.NORTH);
    panel1.add(panel2, BorderLayout.CENTER);
    panel2.add(panel3, BorderLayout.NORTH);
    panel3.add(btnExample1, null);
    panel3.add(btnExample2, null);
    panel3.add(btnExample3, null);
    panel3.add(btnExample4, null);
    panel3.add(btnExample5, null);
    panel3.add(btnExample6, null);
    panel2.add(panel4, BorderLayout.CENTER);
    panel4.add(panel5, BorderLayout.NORTH);
    panel5.add(chkIgnoreCase, null);
    panel5.add(chkReplaceOnce, null);
    panel5.add(chkExtended, null);
    panel4.add(panel6, BorderLayout.CENTER);
    panel6.add(panel7, BorderLayout.NORTH);

    GridBagConstraints gridBag = new GridBagConstraints();
    gridBag.gridx = 0;
    gridBag.gridy = 0;
    gridBag.gridwidth = 1;
    gridBag.gridheight = 1;
    gridBag.weightx = 0.0;
    gridBag.weighty = 0.0;
    gridBag.anchor = GridBagConstraints.WEST;
    gridBag.fill = GridBagConstraints.NONE;
    gridBag.insets = new Insets(0, 0, 0, 0);
    gridBag.ipadx = 43;
    gridBag.ipady = 63;
    panel7.add(lblText, gridBag );

    gridBag = new GridBagConstraints();
    gridBag.gridx = 1;
    gridBag.gridy = 0;
    gridBag.gridwidth = 1;
    gridBag.gridheight = 1;
    gridBag.weightx = 1.0;
    gridBag.weighty = 1.0;
    gridBag.anchor = GridBagConstraints.CENTER;
    gridBag.fill = GridBagConstraints.BOTH;
    gridBag.insets = new Insets(0, 0, 0, 0);
    gridBag.ipadx = -67;
    gridBag.ipady = -84;
    panel7.add(txtText, gridBag);

    gridBag = new GridBagConstraints();
    gridBag.gridx = 0;
    gridBag.gridy = 1;
    gridBag.gridwidth = 1;
    gridBag.gridheight = 1;
    gridBag.weightx = 0.0;
    gridBag.weighty = 0.0;
    gridBag.anchor = GridBagConstraints.WEST;
    gridBag.fill = GridBagConstraints.NONE;
    gridBag.insets = new Insets(15, 0, 0, 0);
    gridBag.ipadx = 43;
    gridBag.ipady = 63;
    panel7.add(label7, gridBag);

    gridBag = new GridBagConstraints();
    gridBag.gridx = 1;
    gridBag.gridy = 1;
    gridBag.gridwidth = 1;
    gridBag.gridheight = 1;
    gridBag.weightx = 1.0;
    gridBag.weighty = 1.0;
    gridBag.anchor = GridBagConstraints.CENTER;
    gridBag.fill = GridBagConstraints.BOTH;
    gridBag.insets = new Insets(15, 0, 0, 0);
    gridBag.ipadx = -66;
    gridBag.ipady = -84;
    panel7.add(txtPattern, gridBag);

    gridBag = new GridBagConstraints();
    gridBag.gridx = 0;
    gridBag.gridy = 2;
    gridBag.gridwidth = 1;
    gridBag.gridheight = 1;
    gridBag.weightx = 0.0;
    gridBag.weighty = 0.0;
    gridBag.anchor = GridBagConstraints.WEST;
    gridBag.fill = GridBagConstraints.NONE;
    gridBag.insets = new Insets(15, 0, 2, 0);
    gridBag.ipadx = 44;
    gridBag.ipady = 63;
    panel7.add(label6, gridBag);

    gridBag = new GridBagConstraints();
    gridBag.gridx = 1;
    gridBag.gridy = 2;
    gridBag.gridwidth = 1;
    gridBag.gridheight = 1;
    gridBag.weightx = 1.0;
    gridBag.weighty = 1.0;
    gridBag.anchor = GridBagConstraints.CENTER;
    gridBag.fill = GridBagConstraints.BOTH;
    gridBag.insets = new Insets(15, 0, 2, 0);
    gridBag.ipadx = -67;
    gridBag.ipady = -84;
    panel7.add(txtReplacement, gridBag);

    panel6.add(panel8, BorderLayout.CENTER);
    panel8.add(btnExecute, BorderLayout.NORTH);
    panel8.add(panel9, BorderLayout.CENTER);

    gridBag = new GridBagConstraints();
    gridBag.gridx = 0;
    gridBag.gridy = 0;
    gridBag.gridwidth = 1;
    gridBag.gridheight = 1;
    gridBag.weightx = 0.0;
    gridBag.weighty = 0.0;
    gridBag.anchor = GridBagConstraints.WEST;
    gridBag.fill = GridBagConstraints.NONE;
    gridBag.insets = new Insets(0, 0, 0, 0);
    gridBag.ipadx = 32;
    gridBag.ipady = 63;
    panel9.add(lblText1, gridBag);

    gridBag = new GridBagConstraints();
    gridBag.gridx = 1;
    gridBag.gridy = 0;
    gridBag.gridwidth = 1;
    gridBag.gridheight = 1;
    gridBag.weightx = 1.0;
    gridBag.weighty = 1.0;
    gridBag.anchor = GridBagConstraints.CENTER;
    gridBag.fill = GridBagConstraints.BOTH;
    gridBag.insets = new Insets(0, 52, 0, 0);
    gridBag.ipadx = -72;
    gridBag.ipady = -84;
    panel9.add(txtResult, gridBag);

    this.add(label1, BorderLayout.NORTH);
    this.add(label2, BorderLayout.EAST);
    this.add(label3, BorderLayout.SOUTH);
    this.add(label4, BorderLayout.WEST);
  }


  void btnExecute_actionPerformed(ActionEvent e)
  {
      try
      {
           String sText = txtText.getText();
           String sPattern = txtPattern.getText();
           String sReplacement = txtReplacement.getText();

           if( chkExtended.getState() )
           {
             //Extended
              if( chkIgnoreCase.getState() )
              {
                 if( chkReplaceOnce.getState() )
                 {
                    txtResult.setText( ToolkitString.strReplaceLikeExOnceIgnoreCase( sText, sPattern, sReplacement ) );
                 }
                 else
                 {
                    txtResult.setText( ToolkitString.strReplaceLikeExIgnoreCase( sText, sPattern, sReplacement ) );
                 }
              }
              else
              {
                 if( chkReplaceOnce.getState() )
                 {
                    txtResult.setText( ToolkitString.strReplaceLikeExOnce( sText, sPattern, sReplacement ) );
                 }
                 else
                 {
                    txtResult.setText( ToolkitString.strReplaceLikeEx( sText, sPattern, sReplacement ) );
                 }
              }
           }
           else
           {
              if( chkIgnoreCase.getState() )
              {
                 if( chkReplaceOnce.getState() )
                 {
                    txtResult.setText( ToolkitString.strReplaceLikeOnceIgnoreCase( sText, sPattern, sReplacement ) );
                 }
                 else
                 {
                    txtResult.setText( ToolkitString.strReplaceLikeIgnoreCase( sText, sPattern, sReplacement ) );
                 }
              }
              else
              {
                 if( chkReplaceOnce.getState() )
                 {
                    txtResult.setText( ToolkitString.strReplaceLikeOnce( sText, sPattern, sReplacement ) );
                 }
                 else
                 {
                    txtResult.setText( ToolkitString.strReplaceLike( sText, sPattern, sReplacement ) );
                 }
              }
           }

      }
      catch( Exception x )
      {
         x.printStackTrace();
         txtResult.setText(x.getClass().getName() + ";" + x.getMessage());
      }
  }

  void btnExample1_actionPerformed(ActionEvent e)
  {
      chkExtended.setState(false);
      chkIgnoreCase.setState(false);
      chkReplaceOnce.setState(false);
      txtText.setText("Hello world");
      txtPattern.setText("world");
      txtReplacement.setText("people");
      txtResult.setText("Press Button Execute");
  }

  void btnExample2_actionPerformed(ActionEvent e)
  {
      chkExtended.setState(false);
      chkIgnoreCase.setState(false);
      chkReplaceOnce.setState(false);
      txtText.setText("abcdefghijklmno");
      txtPattern.setText("d*h");
      txtReplacement.setText("x");
      txtResult.setText("Press Button Execute");
  }

  void btnExample3_actionPerformed(ActionEvent e)
  {
      chkExtended.setState(true);
      chkIgnoreCase.setState(true);
      chkReplaceOnce.setState(false);
      txtText.setText("Hello World\nHello World\nHello World");
      txtPattern.setText("[a-g]*[l-m]d");
      txtReplacement.setText("i");
      txtResult.setText("Press Button Execute");
  }

  void btnExample4_actionPerformed(ActionEvent e)
  {
      chkExtended.setState(false);
      chkIgnoreCase.setState(false);
      chkReplaceOnce.setState(true);
      txtText.setText("Hello World\nHello World\nHello World");
      txtPattern.setText("?ll?");
      txtReplacement.setText("i");
      txtResult.setText("Press Button Execute");
  }

  void btnExample5_actionPerformed(ActionEvent e)
  {
      chkExtended.setState(false);
      chkIgnoreCase.setState(false);
      chkReplaceOnce.setState(false);
      txtText.setText("Hello World\nHello World\nHello World");
      txtPattern.setText("???o*d");
      txtReplacement.setText("i");
      txtResult.setText("Press Button Execute");
  }

  void btnExample6_actionPerformed(ActionEvent e)
  {
      chkExtended.setState(true);
      chkIgnoreCase.setState(true);
      chkReplaceOnce.setState(false);
      txtText.setText("Hello World\nHello World\nHello World");
      txtPattern.setText("[A-Z]*d");
      txtReplacement.setText("super");
      txtResult.setText("Press Button Execute");
  }
}