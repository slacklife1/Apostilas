//Example for ToolkitString.likeIndices
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitString;

public class LikeIndices
{
  public static void main( String[] args )
  {
   try
   {
     int[] ai;

     ai = ToolkitString.likeIndices( "abcdefghi", "abc" );
     System.out.println( "start:" + ai[0] + " end:" + ai[1] );

     ai = ToolkitString.likeIndices( "abcdefghi", "bcd" );
     System.out.println( "start:" + ai[0] + " end:" + ai[1] );

     ai = ToolkitString.likeIndices( "abcdefghi", "b?d" );
     System.out.println( "start:" + ai[0] + " end:" + ai[1] );

     ai = ToolkitString.likeIndices( "abcdefghi", "b*e" );
     System.out.println( "start:" + ai[0] + " end:" + ai[1] );

     ai = ToolkitString.likeIndicesEx( "abcdefghi", "b[a-i]*[a-i]h" );
     System.out.println( "start:" + ai[0] + " end:" + ai[1] );
   }
   catch( Exception e )
   {
     e.printStackTrace();
   }
  }
}