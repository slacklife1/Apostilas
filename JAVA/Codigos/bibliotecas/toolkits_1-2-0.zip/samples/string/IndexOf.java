//Example for ToolkitString.strLike
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitString;
import softhema.system.toolkits.ToolkitIO;

public class IndexOf
{
  public static void main( String[] args )
  {
   try
   {
     ToolkitIO.printf("\nInput the text:");
     String s = ToolkitIO.readStringLine();  
     ToolkitIO.printf("\nInput the search items separated by space:");
     String sSearch = ToolkitIO.readStringLine();
     String []aSearch = ToolkitString.strSplit( sSearch );

     int index = ToolkitString.indexOf( s, aSearch );
             
     System.out.println( "found index:" + index );
   }
   catch( Exception e )
   {
     e.printStackTrace();
   }
  }
}