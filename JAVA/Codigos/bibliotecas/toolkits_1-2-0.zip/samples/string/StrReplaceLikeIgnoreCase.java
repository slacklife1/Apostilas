//Example for ToolkitString.strReplaceLikeIgnoreCase
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitString;

public class StrReplaceLikeIgnoreCase
{
  public static void main( String[] args )
  {
   try
   {
      System.out.println( ToolkitString.strReplaceLikeIgnoreCase("ABCDE", "f", "x") );
      System.out.println( ToolkitString.strReplaceLikeIgnoreCase("ABCDE", "*", "xyz") );
      System.out.println( ToolkitString.strReplaceLikeIgnoreCase("ABCDE", "*", "") );
      System.out.println( ToolkitString.strReplaceLikeIgnoreCase("ABCDE", "abc*", "xyz") );
      System.out.println( ToolkitString.strReplaceLikeIgnoreCase("ABCDE", "*c", "xyz") );
      System.out.println( ToolkitString.strReplaceLikeIgnoreCase("ABCDE", "b?d", "xyz") );
      System.out.println( ToolkitString.strReplaceLikeIgnoreCase("ABCDE", "b?d?", "xyz") );
      System.out.println( ToolkitString.strReplaceLikeIgnoreCase("ABCDE", "b*d", "x") );  
   }
   catch( Exception e )
   {
     e.printStackTrace();
   }
  }
}