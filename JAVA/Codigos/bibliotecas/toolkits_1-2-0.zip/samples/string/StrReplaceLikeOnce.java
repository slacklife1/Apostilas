//Example for ToolkitString.strReplaceLikeOnce
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitString;

public class StrReplaceLikeOnce
{
  public static void main( String[] args )
  {
   try
   {
      System.out.println( ToolkitString.strReplaceLikeOnce("abcdefghiabcdefghi", "??d***f", "x") );
      System.out.println( ToolkitString.strReplaceLikeOnce("abcdefghiabcdefghi", "*?d?", "x") );

      System.out.println( ToolkitString.strReplaceLike("abcdefghiabcdefghi", "??d***f", "x") );
      System.out.println( ToolkitString.strReplaceLike("abcdefghiabcdefghi", "*?d?", "x") );
   }
   catch( Exception e )
   {
     e.printStackTrace();
   }
  }
}