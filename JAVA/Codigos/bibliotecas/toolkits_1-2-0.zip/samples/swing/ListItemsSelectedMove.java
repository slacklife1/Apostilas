//Example ListItemsSelectedMove
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import softhema.system.toolkits.ToolkitSwing;

public class ListItemsSelectedMove extends JFrame
{
  JButton jBtnMoveUp = new JButton();
  JButton jBtnMoveDown = new JButton();
  JScrollPane jScrollPane = new JScrollPane();
  JList jList = new JList();
  BorderLayout borderLayout = new BorderLayout();

  public ListItemsSelectedMove()
  {
   try
   {
    jBtnMoveUp.setText("Move up");
    jBtnMoveUp.addActionListener(new java.awt.event.ActionListener()
    {

      public void actionPerformed(ActionEvent e)
      {
        jBtnMoveUp_actionPerformed(e);
      }
    });
    this.getContentPane().setLayout(borderLayout);
    jBtnMoveDown.setText("Move down");
    jBtnMoveDown.addActionListener(new java.awt.event.ActionListener()
    {

      public void actionPerformed(ActionEvent e)
      {
        jBtnMoveDown_actionPerformed(e);
      }
    });
    this.addWindowListener(new java.awt.event.WindowAdapter()
    {

      public void windowClosing(WindowEvent e)
      {
        this_windowClosing(e);
      }
    });
    this.getContentPane().add(jBtnMoveUp, BorderLayout.NORTH);
    this.getContentPane().add(jBtnMoveDown, BorderLayout.SOUTH);
    this.getContentPane().add(jScrollPane, BorderLayout.CENTER);
    jScrollPane.getViewport().add(jList, null);

     Vector vec = new Vector();
      
      vec.addElement("red");
      vec.addElement("green");
      vec.addElement("blue");
      vec.addElement("black");
      vec.addElement("violett");
      vec.addElement("white");
      vec.addElement("gray");
      vec.addElement("brown");

     jList.setListData(vec);

      setTitle("Softhema Example");
      setSize(150,250);
      setVisible(true);
   }
   catch(Exception e)
   {
     e.printStackTrace();
   }
  }

  public static void main(String[] args)
  {
    ListItemsSelectedMove listItemsSelectedMove = new ListItemsSelectedMove();
  }


  void jBtnMoveUp_actionPerformed(ActionEvent e)
  {
     ToolkitSwing.ListItemsSelectedMoveUp( jList );
  }

  void jBtnMoveDown_actionPerformed(ActionEvent e)
  {
     ToolkitSwing.ListItemsSelectedMoveDown( jList );
  }

  void this_windowClosing(WindowEvent e)
  {
    System.exit(0);
  }
}
