//Example for ToolkitFile.listFilesRecursive
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitFile;
import softhema.system.toolkits.ToolkitIO;
import java.util.Vector;
import java.io.File;

public class ListFilesRecursive
{
  public static void main( String[] args )
  {
   try
   {
     Vector v = new Vector();

     ToolkitIO.printf("%s", "Input a directory:");
     ToolkitIO.scanf("%ls", v);
     
     String sDirectory = (String) v.elementAt(0);
     File dir = new File( sDirectory );

     File[] aFilesAndSubDirs = ToolkitFile.listFilesRecursive( dir, true );
     File[] aFilesOnly = ToolkitFile.listFilesRecursive( dir, false );

     int countFiles = aFilesOnly.length;
     int countDirs = aFilesAndSubDirs.length - countFiles;
        
     ToolkitIO.printf("In the directory \"%s\" are %i files and %i subdirectories.\n", sDirectory, new Integer(countFiles), new Integer(countDirs) );     
   }
   catch( Exception e )
   {
     e.printStackTrace();
   }
  }
}