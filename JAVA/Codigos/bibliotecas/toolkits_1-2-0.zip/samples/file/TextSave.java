//Example for ToolkitFile.textSave
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitFile;
import softhema.system.toolkits.ToolkitIO;
import java.util.Vector;
import java.io.File;

public class TextSave
{
  public static void main( String[] args )
  {
   try
   {

     ToolkitIO.printf("\n%s", "Input text terminated by * and carriage return:\n");

     String []as = new String[1];
     ToolkitIO.scanf("%[^*]", as);
     String sText = as[0];

     ToolkitIO.printf("\nInput the file to save:");
     ToolkitIO.scanf("%ls", as);
     String sFile = as[0];

     File file = new File(sFile);

     ToolkitFile.textSave( file, sText );

   }
   catch( Exception e )
   {
     e.printStackTrace();
   }
  }
}