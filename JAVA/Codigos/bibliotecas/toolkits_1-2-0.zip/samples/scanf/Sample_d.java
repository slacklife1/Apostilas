//Example for scanf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;
import java.io.IOException;
import java.util.Vector;

public class Sample_d
{
  public static void main( String[] args )
  {
   try
   {
     Vector v = new Vector();

     ToolkitIO.scanf( "%d" , v ); 
     // %d : decimale integer
     // input example: 1234
     // input example: 1234abcd

     Integer objInt = (Integer) v.elementAt(0);
     System.out.println( objInt.toString() );
   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}