//Example for scanf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;

import java.io.IOException;
import java.util.Vector;
import java.math.BigDecimal;

public class Sample2
{
  public static void main( String[] args )
  {
   try
   {
     Vector v = new Vector();

     ToolkitIO.scanf( "%lf %s" , v ); 
     // %ld : long float (BigDecimal)
     // %x : hexnumber

     // input example: 1234.5678 abcd
     // input example: 1234.5678E+2 xxxx

     BigDecimal big = (BigDecimal) v.elementAt(0);
     System.out.println( big.toString() );

     String s = (String) v.elementAt(1);
     System.out.println( s );
   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}