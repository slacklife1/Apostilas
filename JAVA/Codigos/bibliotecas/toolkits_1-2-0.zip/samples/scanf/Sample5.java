//Example for scanf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;

import java.io.IOException;
import java.util.Vector;
import java.math.BigInteger;

public class Sample5
{
  public static void main( String[] args )
  {
   try
   {
     Vector vec = new Vector();

     ToolkitIO.printf( "\nInteger 0ne=" );
     ToolkitIO.scanf( "%li" , vec ); 

     ToolkitIO.printf( "\nInteger Two=" );
     ToolkitIO.scanf( "%li", vec );

     BigInteger i1 = (BigInteger) vec.elementAt(0);
     BigInteger i2 = (BigInteger) vec.elementAt(1);

     BigInteger i3 = i1.add( i2 );

     vec.addElement( i3 );


     ToolkitIO.printf( "\n Integer One + Integer Two = Integer Three");
     ToolkitIO.printf( "\n %%ld + %%ld = %%ld : %ld + %ld = %ld", vec );
     ToolkitIO.printf( "\n %%lo + %%lo = %%lo : %lo + %lo = %lo", vec );
     ToolkitIO.printf( "\n %%lx + %%lx = %%lx : %lx + %lx = %lx", vec );
     ToolkitIO.printf( "\n %%010LX + %%010LX = %%010LX : %010LX + %010LX = %010LX", vec );
     ToolkitIO.printf( "\n %%-10LX + %%-10LX = %%-10LX : %-10LX + %-10LX = %-10LX", vec );

   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}