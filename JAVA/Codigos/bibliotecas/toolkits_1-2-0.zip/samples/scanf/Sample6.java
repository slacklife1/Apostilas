//Example for scanf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;

import java.io.IOException;
import java.util.Vector;


public class Sample6
{
  public static void main( String[] args )
  {
   try
   {
      Vector vec;      

      vec = new Vector();
      ToolkitIO.printf("input word:");
      ToolkitIO.scanf("%s", vec); //scan one word
      ToolkitIO.printf("%s\n", vec);

      ToolkitIO.flushInOut();

      vec = new Vector();
      ToolkitIO.printf("input number+text:");
      ToolkitIO.scanf("%d", vec);
      ToolkitIO.scanf(" %s", vec );
      ToolkitIO.printf("|%d| and |%s|\n", vec);

      ToolkitIO.flushInOut();

      vec = new Vector();
      ToolkitIO.printf("input number and text:");
      ToolkitIO.scanf( System.in, "%d", vec);
      ToolkitIO.scanf( System.in, "%s", vec );
      ToolkitIO.printf("|%d| and |%s|\n", vec);

      ToolkitIO.flushInOut();

      vec = new Vector();
      ToolkitIO.printf("input number+text:");
      ToolkitIO.scanf( "%d %s", vec);
      ToolkitIO.printf("|%d| and |%s|\n", vec);

      ToolkitIO.flushInOut();

      vec = new Vector();
      ToolkitIO.printf("input aeiou-text:");
      ToolkitIO.scanf("%[aeiou]",vec); //scan one line
      ToolkitIO.printf("%s\n", vec);

      ToolkitIO.flushInOut();

      vec = new Vector();
      ToolkitIO.printf("input line:");
      ToolkitIO.scanf("%[^\n\r]",vec); //scan one line
      ToolkitIO.printf("%s\n", vec);

   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}