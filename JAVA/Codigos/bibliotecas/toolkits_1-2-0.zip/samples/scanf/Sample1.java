//Example for scanf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;

import java.io.IOException;
import java.util.Vector;
import java.math.BigInteger;

public class Sample1
{
  public static void main( String[] args )
  {
   try
   {
     Vector v = new Vector();

     ToolkitIO.scanf( "%ld %x" , v ); 
     // %ld : long decimale integer (BigInteger)
     // %x : hexnumber

     // input example: 1234 abcd
     // input example: 1234 ff

     BigInteger big = (BigInteger) v.elementAt(0);
     System.out.println( big.toString() );

     Integer objInt = (Integer) v.elementAt(1);
     System.out.println( objInt.toString() );
   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}