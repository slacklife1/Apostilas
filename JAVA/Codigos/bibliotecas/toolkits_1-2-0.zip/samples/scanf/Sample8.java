//Example for scanf and printf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;

import java.io.IOException;
import java.util.Vector;

public class Sample8
{
  public static void main( String[] args )
  {
   try
   {

     Object[] aobj = new Object[6];

     ToolkitIO.scanf("%s %s %s %5$s %4$s %3$s", aobj); //Input example:a b c d e f\n

     ToolkitIO.printf("\n%s %s %s %s %s %s", aobj);

   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}