//Example for scanf and printf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;

import java.io.IOException;
import java.util.Vector;

public class Sample7
{
  public static void main( String[] args )
  {
   try
   {
     Vector v = new Vector();
     
     ToolkitIO.printf("\n%s", "Input the temperature in Fahrenheit:");
     ToolkitIO.scanf("%f", v );
     
     float fahrenheit = ( (Number) v.elementAt(0) ).floatValue();
     float celsius = (5.0f / 9.0f) * (fahrenheit - 32);

     v.addElement( new Float( celsius ) );

     ToolkitIO.printf("%.2f Fahrenheit is %.2f Celsius\n", v);
     ToolkitIO.printf("%.2e Fahrenheit is %.2e Celsius\n", v);
     ToolkitIO.printf("%.2g Fahrenheit is %.2g Celsius\n", v);
   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}