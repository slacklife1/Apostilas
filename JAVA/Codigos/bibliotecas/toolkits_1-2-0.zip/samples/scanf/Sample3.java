//Example for scanf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;

import java.io.IOException;
import java.util.Vector;
import java.math.BigDecimal;

public class Sample3
{
  public static void main( String[] args )
  {
   try
   {
     Vector vec = new Vector();

     ToolkitIO.printf( "\nNumber 0ne=" );
     ToolkitIO.scanf( "%lf" , vec ); 

     ToolkitIO.printf( "\nNumber Two=" );
     ToolkitIO.scanf( "%lf", vec );

     double n1 = ( (Number) vec.elementAt(0) ).doubleValue();
     double n2 = ( (Number) vec.elementAt(1) ).doubleValue();

     double n3 = n1 + n2;
     vec.addElement( new Double( n3 ) );

     ToolkitIO.printf( "\n Number One + Number Two = Number Three");
     ToolkitIO.printf( "\n %%lf + %%lf = %%lf : %lf + %lf = %lf", vec );
     ToolkitIO.printf( "\n %%le + %%le = %%le : %le + %le = %le", vec );
     ToolkitIO.printf( "\n %%lg + %%lg = %%lg : %lg + %lg = %lg", vec );

   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}