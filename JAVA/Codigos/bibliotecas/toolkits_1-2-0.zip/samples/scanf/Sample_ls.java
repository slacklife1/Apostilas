//Example for scanf and %ls
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;

import java.io.IOException;
import java.util.Vector;


public class Sample_ls
{
  public static void main( String[] args )
  {
   try
   {
     Vector v = new Vector();

     ToolkitIO.scanf( "%ls%ls" , v ); 
     // %ls : line string
  

     // input example: This is the first line.\nAnd this is the second line.\n

     String line1 = (String) v.elementAt(0);
     System.out.println( line1 );

     String line2 = (String) v.elementAt(1);
     System.out.println( line2 );
   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}