//Example for scanf and printf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;

import java.io.IOException;
import java.util.Vector;

public class Sample9
{
  public static void main( String[] args )
  {
   try
   {

     Vector vec = new Vector();
     vec.addElement("a");
     vec.addElement("b");
     vec.addElement("c");
 
     ToolkitIO.scanf("%s %s %s", vec); //Input example:d e f\n

     ToolkitIO.printf("\n%s %s %s %s %s %s\n", vec);

     ToolkitIO.scanf("%3$s %s %s", vec); //Input example:a b c\n

     ToolkitIO.printf("\n%s %s %s %s %s %s", vec);

   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}