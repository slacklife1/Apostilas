//Example for printf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;

import java.io.IOException;
import java.math.BigInteger;
import java.math.BigDecimal;

public class Sample3
{
  public static void main( String[] args )
  {
   try
   {
    //some hardcore examples
     ToolkitIO.printf("\n %s %s %s %0$s %s %s %2$s %1$s %0$s", "a", "b", "c");
     ToolkitIO.printf("\n fieldwitdh=%i precision=%i value=%lf (%0$*.*lf)", new Integer(6), new Integer(3), new Double(3.1415926) );       
     ToolkitIO.printf("\n (%0$.6lf), (%0$.0lf), (%0$#.0lf), (%0$ .0lf), (%0$+8.4lf), (%0$-10.4lf)" , 3.1415926);
     ToolkitIO.printf("\n (%0$.6lf), (%0$.0lf), (%0$#.0lf), (%0$ .0lf), (%0$+8.4lf), (%0$-10.4lf)" , -3.1415926);
     ToolkitIO.printf("\n (%0$.6lf), (%0$.0lf), (%0$#.0lf), (%0$ 3.0lf), (%0$-+8.4lf), (%0$+-10.4lf)" , 3.1415926);
     ToolkitIO.printf("\n (%0$.6lf), (%0$.0lf), (%0$#.0lf), (%0$ 3.0lf), (%0$-+8.4lf), (%0$+-10.4lf)" , -3.1415926);
     ToolkitIO.printf("\n (%0$,6lf), (%0$,0lf), (%0$#,0lf), (%0$ 3,0lf), (%0$-+8,4lf), (%0$+-10,4lf)" , 3.1415926);
     ToolkitIO.printf("\n (%0$,6lf), (%0$,0lf), (%0$#,0lf), (%0$ 3,0lf), (%0$-+8,4lf), (%0$+-10,4lf)" , -3.1415926);
     ToolkitIO.printf("\n (%0$,6lf), (%0$,0lf), (%0$#,0lf), (%0$0,0lf), (%0$0+8,4lf), (%0$0+-10,4lf)" , 3.1415926);
     ToolkitIO.printf("\n (%0$,6lf), (%0$,0lf), (%0$#,0lf), (%0$0,0lf), (%0$0+8,4lf), (%0$0+-10,4lf)" , -3.1415926);
     ToolkitIO.printf("\n (%0$lx), (%0$lo), (%0$li),(%0$#lx), (%0$#lo), (%0$#li)", 255);
     ToolkitIO.printf("\n (%0$lx), (%0$lo), (%0$li),(%0$#lx), (%0$#lo), (%0$#li)", -255);
     ToolkitIO.printf("\n (%0$lx), (%0$lo), (%0$li),(%0$#010lx), (%0$#010lo), (%0$#010li)", 255);
     ToolkitIO.printf("\n (%0$lx), (%0$lo), (%0$li),(%0$#010lx), (%0$#010lo), (%0$#010li)", -255);
     ToolkitIO.printf("\n (%lu), (%lu), (%0$li), (%1$li), (%0$lx), (%1$lx)", new BigInteger("255"), new BigInteger("-255") );
     ToolkitIO.printf("\n %#lx = %0$#lo = %0$li", new BigInteger("abcdefabcdefffffffffffffffffffffff",16 ) );
     ToolkitIO.printf("\n %ld %ld %ld %ld", new Long(1234), new BigInteger("1234"), new String("1234"), new Short( (short)1234 ) );
   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}