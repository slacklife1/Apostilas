//Example for printf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;
import java.io.IOException;
import java.math.BigInteger;

public class Sample_ld
{
  public static void main( String[] args )
  {
   try
   {
    BigInteger big = new BigInteger("123456789123456789123456789123456789123456789");

    System.out.print("\"");
     ToolkitIO.printf("%ld", big );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%55ld", big );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%055lx", new Long(123456789123456789L) );
    System.out.println("\"");

   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}