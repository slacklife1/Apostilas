//Example for printf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;
import java.io.IOException;

public class Sample_floating2
{
  public static void main( String[] args )
  {
   try
   {

    System.out.print("\"");
     ToolkitIO.printf("%.3LG", 1234567.8912345 );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.3LG",  0.00123456789  );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.3LG", 0.0012 ); 
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.3LG", 0.000123456789 );  
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.3LG", 0.0000123456789 );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.3LG", 0.00000123456789 );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.3LG", 0.00000999999999 );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.3LG", 0.00999999999 );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.3LG", 0.00191919191 );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.3LG", 123.456789 );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.3LG", 12345678.9 );
    System.out.println("\"");
   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}