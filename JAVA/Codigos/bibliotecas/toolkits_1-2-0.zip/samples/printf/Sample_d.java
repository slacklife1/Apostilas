//Example for printf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;
import java.io.IOException;

public class Sample_d
{
  public static void main( String[] args )
  {
   try
   {
    Integer i = new Integer(1);
    Integer j = new Integer(29);
    Integer k = new Integer(230551777);

    System.out.print("\"");
     ToolkitIO.printf("%d", i );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%10d", i );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%010d", i );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%010d", new Integer( -1 ) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%-12d", j );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%12o", j );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%-12x", j );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%d", k );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%5d", k );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%17d", k );
    System.out.println("\"");

   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}