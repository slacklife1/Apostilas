//Example for printf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;
import java.io.IOException;

public class Sample_f
{
  public static void main( String[] args )
  {
   try
   {

    System.out.print("\"");
     ToolkitIO.printf("%f", new Float(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.1f", new Float(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.7f", new Float(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.12f", new Float(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%20.3f", new Float(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%-20.3f", new Float(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%20.3f", new Float(-333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%020.3f", new Float(-333.123456789) );
    System.out.println("\"");

   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}