//Example for printf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import java.awt.*;
import java.awt.event.*;
import softhema.system.toolkits.ToolkitString;

public class PrintfTest extends Frame
{
  Panel panel1 = new Panel();
  Panel panel2 = new Panel();
  Label jLabel1 = new Label();
  Label label1 = new Label();
  TextField txtArg5 = new TextField();
  BorderLayout borderLayout2 = new BorderLayout();
  Panel panel3 = new Panel();
  BorderLayout borderLayout3 = new BorderLayout();
  Panel panel4 = new Panel();
  TextField txtArg4 = new TextField();
  Label label2 = new Label();
  BorderLayout borderLayout4 = new BorderLayout();
  Panel panel5 = new Panel();
  TextField txtArg3 = new TextField();
  Label label3 = new Label();
  BorderLayout borderLayout5 = new BorderLayout();
  Panel panel6 = new Panel();
  TextField txtArg2 = new TextField();
  Label label4 = new Label();
  BorderLayout borderLayout6 = new BorderLayout();
  Panel panel7 = new Panel();
  TextField txtArg1 = new TextField();
  Label label5 = new Label();
  BorderLayout borderLayout7 = new BorderLayout();
  Panel panel8 = new Panel();
  TextField txtArg0 = new TextField();
  Label label6 = new Label();
  BorderLayout borderLayout8 = new BorderLayout();
  Panel panel9 = new Panel();
  TextField txtFormat = new TextField();
  Label label7 = new Label();
  GridLayout gridLayout1 = new GridLayout();
  Button btnGenerateOutput = new Button();
  Panel panel11 = new Panel();
  BorderLayout borderLayout9 = new BorderLayout();
  TextField txtOutput = new TextField();
  BorderLayout borderLayout10 = new BorderLayout();
  Panel panel12 = new Panel();
  Label label8 = new Label();
  Panel panel10 = new Panel();
  BorderLayout borderLayout1 = new BorderLayout();
  BorderLayout borderLayout11 = new BorderLayout();
  Panel panel13 = new Panel();
  Button btnExample4 = new Button();
  Button btnExample5 = new Button();
  Button btnExample3 = new Button();
  Button btnExample2 = new Button();
  Button btnExample1 = new Button();
  BorderLayout borderLayout12 = new BorderLayout();

  public PrintfTest()
  {
   try
   {
    this.setLayout(borderLayout11);
    jLabel1.setText("output = softhema.system.toolkits.ToolkitString.sprintf( formatstring, " +
    "arg0, arg1, arg2, arg3, arg4, arg5);");
    panel2.setLayout(borderLayout2);
    label1.setText("arg5:");
    panel3.setLayout(gridLayout1);
    panel4.setLayout(borderLayout3);
    label2.setText("arg4:");
    panel5.setLayout(borderLayout4);
    label3.setText("arg3:");
    panel6.setLayout(borderLayout5);
    label4.setText("arg2:");
    panel7.setLayout(borderLayout6);
    label5.setText("arg1:");
    panel8.setLayout(borderLayout7);
    txtArg0.setText("World");
    label6.setText("arg0:");
    panel9.setLayout(borderLayout8);
    txtFormat.setText("Hello %s");
    label7.setText("formatstring:");
    gridLayout1.setRows(7);
    gridLayout1.setVgap(2);
    btnGenerateOutput.setLabel("Generate output");
    btnGenerateOutput.addActionListener(new java.awt.event.ActionListener()
    {

      public void actionPerformed(ActionEvent e)
      {
        btnGenerateOutput_actionPerformed(e);
      }
    });
    panel11.setLayout(borderLayout9);
    panel12.setLayout(borderLayout10);
    label8.setText("output:");
    panel10.setLayout(borderLayout1);
    borderLayout11.setVgap(15);
    borderLayout9.setVgap(8);
    this.setTitle("Softhema - Test of printf");
    this.addWindowListener(new java.awt.event.WindowAdapter()
    {

      public void windowClosing(WindowEvent e)
      {
        this_windowClosing(e);
      }
    });
    panel1.setLayout(borderLayout12);
    btnExample4.setLabel("Example 4");
    btnExample4.addActionListener(new java.awt.event.ActionListener()
    {

      public void actionPerformed(ActionEvent e)
      {
        btnExample4_actionPerformed(e);
      }
    });
    btnExample5.setLabel("Example 5");
    btnExample5.addActionListener(new java.awt.event.ActionListener()
    {

      public void actionPerformed(ActionEvent e)
      {
        btnExample5_actionPerformed(e);
      }
    });
    btnExample3.setLabel("Example 3");
    btnExample3.addActionListener(new java.awt.event.ActionListener()
    {

      public void actionPerformed(ActionEvent e)
      {
        btnExample3_actionPerformed(e);
      }
    });
    btnExample2.setLabel("Example 2");
    btnExample2.addActionListener(new java.awt.event.ActionListener()
    {

      public void actionPerformed(ActionEvent e)
      {
        btnExample2_actionPerformed(e);
      }
    });
    btnExample1.setLabel("Example 1");
    btnExample1.addActionListener(new java.awt.event.ActionListener()
    {

      public void actionPerformed(ActionEvent e)
      {
        btnExample1_actionPerformed(e);
      }
    });
    this.add(panel1, BorderLayout.NORTH);
    panel1.add(jLabel1, BorderLayout.NORTH);
    panel1.add(panel13, BorderLayout.CENTER);
    panel13.add(btnExample1, null);
    panel13.add(btnExample2, null);
    panel13.add(btnExample3, null);
    panel13.add(btnExample4, null);
    panel13.add(btnExample5, null);
    this.add(panel10, BorderLayout.CENTER);
    panel10.add(panel11, BorderLayout.SOUTH);
    panel11.add(btnGenerateOutput, BorderLayout.CENTER);
    panel11.add(panel12, BorderLayout.SOUTH);
    panel12.add(label8, BorderLayout.WEST);
    panel12.add(txtOutput, BorderLayout.CENTER);
    panel10.add(panel3, BorderLayout.NORTH);
    panel3.add(panel9, null);
    panel9.add(label7, BorderLayout.WEST);
    panel9.add(txtFormat, BorderLayout.CENTER);
    panel3.add(panel8, null);
    panel8.add(label6, BorderLayout.WEST);
    panel8.add(txtArg0, BorderLayout.CENTER);
    panel3.add(panel7, null);
    panel7.add(label5, BorderLayout.WEST);
    panel7.add(txtArg1, BorderLayout.CENTER);
    panel3.add(panel6, null);
    panel6.add(label4, BorderLayout.WEST);
    panel6.add(txtArg2, BorderLayout.CENTER);
    panel3.add(panel5, null);
    panel5.add(label3, BorderLayout.WEST);
    panel5.add(txtArg3, BorderLayout.CENTER);
    panel3.add(panel4, null);
    panel4.add(label2, BorderLayout.WEST);
    panel4.add(txtArg4, BorderLayout.CENTER);
    panel3.add(panel2, null);
    panel2.add(label1, BorderLayout.WEST);
    panel2.add(txtArg5, BorderLayout.CENTER);
    setSize(598,335);
    setBackground( SystemColor.control );
    validate();
   }
   catch(Exception e)
   {
      e.printStackTrace();
   }
  }

  public static void main(String[] args)
  {
    PrintfTest printfTest = new PrintfTest();
    printfTest.setVisible(true);
  }

  void this_windowClosing(WindowEvent e)
  {
     System.exit(0);
  }

  void btnExample1_actionPerformed(ActionEvent e)
  {
     txtFormat.setText("Hello %s");
     txtArg0.setText("World");
     txtArg1.setText("");
     txtArg2.setText("");
     txtArg3.setText("");
     txtArg4.setText("");
     txtArg5.setText("");
     btnGenerateOutput_actionPerformed(null);
  }

  void btnExample2_actionPerformed(ActionEvent e)
  {
     txtFormat.setText("%d %o %x %s");
     txtArg0.setText("16");
     txtArg1.setText("16");
     txtArg2.setText("16");
     txtArg3.setText("examples");
     txtArg4.setText("");
     txtArg5.setText("");
     btnGenerateOutput_actionPerformed(null);
  }

  void btnExample3_actionPerformed(ActionEvent e)
  {
     txtFormat.setText("%05d %05o %05x %s");
     txtArg0.setText("16");
     txtArg1.setText("16");
     txtArg2.setText("16");
     txtArg3.setText("examples");
     txtArg4.setText("");
     txtArg5.setText("");
     btnGenerateOutput_actionPerformed(null);
  }

  void btnExample4_actionPerformed(ActionEvent e)
  {
     txtFormat.setText("%f %e %g %s");
     txtArg0.setText("123.456789012345");
     txtArg1.setText("123.456789012345");
     txtArg2.setText("123.456789012345");
     txtArg3.setText("examples");
     txtArg4.setText("");
     txtArg5.setText("");
     btnGenerateOutput_actionPerformed(null);
  }

  void btnExample5_actionPerformed(ActionEvent e)
  {
     txtFormat.setText("%10.3f %10.3e %10.3g %.2s");
     txtArg0.setText("123.456789012345");
     txtArg1.setText("123.456789012345");
     txtArg2.setText("123.456789012345");
     txtArg3.setText("examples");
     txtArg4.setText("");
     txtArg5.setText("");
     btnGenerateOutput_actionPerformed(null);
  }

  void btnGenerateOutput_actionPerformed(ActionEvent e)
  {
   try
   {
     String sFormat = txtFormat.getText();
     String sArg0 = txtArg0.getText();
     String sArg1 = txtArg1.getText();
     String sArg2 = txtArg2.getText();
     String sArg3 = txtArg3.getText();
     String sArg4 = txtArg4.getText();
     String sArg5 = txtArg5.getText();

     String sOutput;

     sOutput = ToolkitString.sprintf(sFormat, sArg0, sArg1, sArg2, sArg3, sArg4, sArg5);

     txtOutput.setText( sOutput );
   }
   catch( Exception x )
   {
     x.printStackTrace();
     txtOutput.setText("Exception:" + x.getClass().getName() + ";" + x.getMessage() );
   }
  }
}