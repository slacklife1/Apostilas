//Example for printf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;

import java.io.IOException;

public class Sample_s
{
  public static void main( String[] args )
  {
   try
   {
   
    System.out.print("\"");
     ToolkitIO.printf("%s", "Java is wonderful" );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%7s", "Java is wonderful" );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%30s", "Java is wonderful" );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.4s", "Java is wonderful" );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%-.4s", "Java is wonderful" );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%30.4s", "Java is wonderful" );
    System.out.println("\"");

   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}