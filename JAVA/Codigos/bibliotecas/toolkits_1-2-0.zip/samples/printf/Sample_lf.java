//Example for printf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;
import java.io.IOException;

public class Sample_lf
{
  public static void main( String[] args )
  {
   try
   {

    System.out.print("\"");
     ToolkitIO.printf("%lf", new Double(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.1lf", new Double(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.7lf", new Double(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.12lf", new Double(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%20.3lf", new Double(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%-20.3lf", new Double(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%20.3lf", new Double(-333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%020.3lf", new Double(-333.123456789) );
    System.out.println("\"");

   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}