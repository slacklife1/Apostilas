//Example for printf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;

import java.io.IOException;

public class Sample2
{
  public static void main( String[] args )
  {
   try
   {
    System.out.println("Hello" + " " + "World");
    // or
    ToolkitIO.printf("%s %s", "Hello", "World");
    System.out.println();
    // or
    ToolkitIO.printf("%s %s", new Object[]{"Hello", "World"} );
    System.out.println();
   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}