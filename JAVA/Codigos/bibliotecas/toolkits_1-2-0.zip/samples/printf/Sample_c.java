//Example for printf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;
import java.io.IOException;

public class Sample_c
{
  public static void main( String[] args )
  {
   try
   {
   
    System.out.print("\"");
     ToolkitIO.printf("%c", new Character('w') );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%2c", new Character('w') );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%-3c", new Character('w') );
    System.out.println("\"");

   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}