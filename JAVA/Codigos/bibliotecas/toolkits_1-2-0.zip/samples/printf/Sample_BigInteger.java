//Example for printf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;
import java.io.IOException;
import java.math.BigInteger;

public class Sample_BigInteger
{
  public static void main( String[] args )
  {
   try
   {

    System.out.print("\"");
     ToolkitIO.printf("%ld", new BigInteger("123456789123456789123456789123456789123456789") );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%50ld", new BigInteger("123456789123456789123456789123456789123456789") );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%050ld", new BigInteger("123456789123456789123456789123456789123456789") );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%lx", new BigInteger("123456789123456789123456789123456789123456789") );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%lo", new BigInteger("123456789123456789123456789123456789123456789") );
    System.out.println("\"");

   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}