//Example for printf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;

import java.io.IOException;

public class Sample1
{
  public static void main( String[] args )
  {
   try
   {
    ToolkitIO.printf("Hello %s", "World");
   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}