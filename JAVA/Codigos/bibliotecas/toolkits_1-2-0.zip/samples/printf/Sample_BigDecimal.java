//Example for printf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;

public class Sample_BigDecimal
{
  public static void main( String[] args )
  {
   try
   {
    BigInteger i = new BigInteger("3330123456789012345678901234567890123456789");
    BigDecimal d = new BigDecimal( i, 40 );
    // d = 333.012345678901234567890123456789012345679

    System.out.print("\"");
     ToolkitIO.printf("%lf", d );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%le", d );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%lg", d );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.5lf", d );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.5le", d );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.5lg", d );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%20.3lf", d );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%20.3le", d );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%20.3lg", d );
    System.out.println("\"");

   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}