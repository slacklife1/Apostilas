//Example for printf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;
import java.io.IOException;

public class Sample_floating
{
  public static void main( String[] args )
  {
   try
   {

    System.out.print("\"");
     ToolkitIO.printf("%f", 0.00123456789123456789f );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%1f", 0.00123456789123456789 );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.lf", 0.00123456789123456789 ); // precision is zero
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%,lf", 333.987654321 );  // precision is zero
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.7lf", 0.00123456789123456789 );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%,lf", 0.00123456789123456789 );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%,6f", 0.00123456789123456789 );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%,3le", 0.00123456789123456789 );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%,3LE", 0.00123456789123456789 );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%,3LG", 0.00123456789123456789 );
    System.out.println("\"");
   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}