//Example for printf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;
import java.io.IOException;

public class Sample_le
{
  public static void main( String[] args )
  {
   try
   {

    System.out.print("\"");
     ToolkitIO.printf("%le", new Double(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.1le", new Double(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.7le", new Double(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.12le", new Double(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%20.3le", new Double(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%-20.3le", new Double(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%20.3le", new Double(-333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%020.3le", new Double(-333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%020.4le", new Double(-.000123456789) );
    System.out.println("\"");

   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}