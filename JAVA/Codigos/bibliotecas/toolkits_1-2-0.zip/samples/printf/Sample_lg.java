//Example for printf
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitIO;

import java.io.IOException;

public class Sample_lg
{
  public static void main( String[] args )
  {
   try
   {

    System.out.print("\"");
     ToolkitIO.printf("%lg", new Double(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.1lg", new Double(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.7lg", new Double(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%.12lg", new Double(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%20.3lg", new Double(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%-20.2lg", new Double(333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%20.2lg", new Double(-333.123456789) );
    System.out.println("\"");

    System.out.print("\"");
     ToolkitIO.printf("%020.4lg", new Double(-333.123456789) );
    System.out.println("\"");

   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}