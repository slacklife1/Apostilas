//Example for ToolkitCollection and method listReverseOrder
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitCollection;

import softhema.system.toolkits.ToolkitIO;
import java.io.IOException;
import java.util.*;

public class ListReverseOrder2
{
  public static void main( String[] args )
  {
   try
   {
     Vector vec = new Vector();
     vec.addElement( "red" );
     vec.addElement( "yellow" );
     vec.addElement( "blue" );
     vec.addElement( "orange" );
     vec.addElement( "white" );

     //mix it
     ToolkitCollection.listReverseOrder( vec );
    
     //print new order
     ToolkitIO.printf("\nnew order:\n%s\n%s\n%s\n%s\n%s\n", vec);
   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}