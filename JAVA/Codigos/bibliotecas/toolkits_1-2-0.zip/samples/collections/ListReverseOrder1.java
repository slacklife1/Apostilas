//Example for ToolkitCollection and method listReverseOrder
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitCollection;

import softhema.system.toolkits.ToolkitIO;
import java.io.IOException;
import java.util.*;

public class ListReverseOrder1
{
  public static void main( String[] args )
  {
   try
   {
     List list = new ArrayList();
     list.add( "red" );
     list.add( "yellow" );
     list.add( "blue" );
     list.add( "orange" );
     list.add( "white" );

     //mix it
     ToolkitCollection.listReverseOrder( list );
    
     //print new order
     ToolkitIO.printf("\nnew order:\n%s\n%s\n%s\n%s\n%s\n", list);
   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}