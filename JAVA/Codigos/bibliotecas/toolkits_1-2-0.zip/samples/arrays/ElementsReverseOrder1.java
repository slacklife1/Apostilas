//Example for ToolkitArray and method elementsReverseOrder
//Copyright by Softhema 2001
//Autor:Harald St�binger
//All rights reserved.

import softhema.system.toolkits.ToolkitArray;

import softhema.system.toolkits.ToolkitIO;
import java.io.IOException;

public class ElementsReverseOrder1
{
  public static void main( String[] args )
  {
   try
   {
     String[] as = new String[5];
     as[0] = "red";
     as[1] = "yellow";
     as[2] = "blue";
     as[3] = "orange";
     as[4] = "white";

     //mix it
     ToolkitArray.elementsReverseOrder( as );
    
     //print new order
     ToolkitIO.printf("\nnew order:\n%s\n%s\n%s\n%s\n%s\n", as);
   }
   catch( IOException e )
   {
     e.printStackTrace();
   }
  }
}