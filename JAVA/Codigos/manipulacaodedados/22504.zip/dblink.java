/*
dblink.java v 1.51
Doubly Linked List
with
insert, delete, find, display, insertionsort, nodeswap, bubblesort ,selectionsort
07-July-2002
Modified with BubbleSort & SelectionSort:11-July-2002
Deepak <deepak-p@eth.net>
*/

import java.io.*;

class node
{
    int data;
    node next,prev;
    node(int d)
    {
	data=d;
	next=null;
	prev=null;
    }
    node()
    {
	data=0;
	next=null;
	prev=null;
    }
}

class dbll
{
    node start;
    dbll()
    {
	start=null;
    }
    void additemlast(int data)
    {
	node t=new node(data);
	if(start==null)
	{
	    start=t;
	    return;
	}
	node t1=start;
	while(t1.next!=null)t1=t1.next;
	t1.next=t;
	t.prev=t1;
	return;
    }
    void additemfirst(int data)
    {
	node t=new node(data);
	if(start==null)
	{
	    start=t;
	    return;
	}
	start.prev=t;
	t.next=start;
	start=t;
    }
    void additemafter(int data,int ind)
    {
	node t=new node(data);
	node t1=start;
	while(t1.data!=ind)t1=t1.next;
	if(t1.next==null)
	{
	    t1.next=t;
	    t.prev=t1;
	    return;
	}
	t1.next.prev=t;
	t.next=t1.next;
	t.prev=t1;
	t1.next=t;
    }
    void deleteitem(int data)
    {
	if(start.data==data)
	{
	    if(start.next!=null)start.next.prev=null;
	    start=start.next;
	    return;
	}
	if(!finditem(data))return;
	node t1=start;
	while(t1.next.data!=data)t1=t1.next;
	if(t1.next.next!=null)t1.next.next.prev=t1;
	t1.next=t1.next.next;
    }
    void insertionsort()
    {
	node t=start.next;
	int d;
	while(t!=null)
	{
	    d=t.data;
	    node t2=t,t1=t.prev;
	    t=t.next;
	    deleteitem(t2.data);
	    while(t1!=null && t1.data>d)t1=t1.prev;
	    if(t1==null)additemfirst(d);
	    else additemafter(d,t1.data);
	}
	return;
    }	    
    void selectionsort()
    {
	node t1=start;
	if(t1==null)return;
	while(t1.next!=null)t1=t1.next;
	while(t1!=null)
	{
	    node t2=start,t3=t1;
	    while(t2!=t1)
	    {
		if(t2.data>t3.data)t3=t2;
		t2=t2.next;
	    }
	    int temp=t3.data;
	    t3.data=t1.data;
	    t1.data=temp;
	    t1=t1.prev;
	}
    }	    
    node getnode(int data)
    {
	if(!finditem(data))return null;
	node t=start;
	while(t.data!=data)t=t.next;
	return t;
    }
    void swapnodes(int d1,int d2)
    {
	node t1=getnode(d1),t2=getnode(d2);
	if(t1==null || t2==null)
	    return;
	boolean st1,st2;
	if(t1==start)st1=true;else st1=false;
	if(t2==start)st2=true;else st2=false;
	if(t1.next==t2)
	{
	    if(t2.next!=null)t2.next.prev=t1;
	    if(t1.prev!=null)t1.prev.next=t2;
	    t1.next=t2.next;
	    t2.prev=t1.prev;
	    t2.next=t1;
	    t1.prev=t2;
	}
	else if(t2.next==t1)
	{
	    if(t1.next!=null)t1.next.prev=t2;
	    if(t2.prev!=null)t2.prev.next=t1;
	    t2.next=t1.next;
	    t1.prev=t2.prev;
	    t1.next=t2;
	    t2.prev=t1;
	}
	else
	{
     	    if(t1.next!=null)t1.next.prev=t2;
	    if(t1.prev!=null)t1.prev.next=t2;
	    if(t2.next!=null)t2.next.prev=t1;
    	    if(t2.prev!=null)t2.prev.next=t1;
    	    node t3=t1.next;
    	    t1.next=t2.next;
	    t2.next=t3;
	    t3=t1.prev;
	    t1.prev=t2.prev;
	    t2.prev=t3;
	}
	if(st1)start=t2;
	else if(st2)start=t1;
    }	
    void bubblesort()
    {
	if(start==null)return;
	if(start.next==null)return;
	node t1=start;
	while(t1.next!=null)t1=t1.next;
	while(t1!=null)
	{
	    node t2=start;
	    while(t2!=t1)
	    {
		if(t2.data>t2.next.data)
		{
		    int t=t2.data;
		    t2.data=t2.next.data;
		    t2.next.data=t;
		}
		t2=t2.next;
	    }
	    t1=t1.prev;
	}
	return;
    }
    boolean finditem(int data)
    {
	node t=start;
	while(t!=null && t.data!=data)t=t.next;
	if(t==null)return false;
	return true;
    }
    void deletelast()
    {
	if(start==null)return;
	if(start.next==null)
	{
	    start=null;
	    return;
	}
	node t=start;
	while(t.next.next!=null)t=t.next;
	t.next=null;
	return;
    }
    void deletefirst()
    {
	if(start.next==null)
	{
	    start=null;
	    return;
	}
	start=start.next;
	start.prev=null;
    }	
    void display()
    {
	node t=start;
	System.out.println();
	while(t!=null)
	{
	    System.out.print(t.data+"  ");
	    t=t.next;
	}
    }
}

class dblink
{
    public static void main(String args[])throws IOException
    {
	dbll d=new dbll();
	DataInputStream in=new DataInputStream(System.in);
	System.out.println("Dblink.java v1.51\nDeepak\n<deepak-p@eth.net>\n11-July-2002");
	int ch=3;
	while(ch!=20)
	{
	    System.out.println("\n1.AddItemFirst\n2.AddItemLast\n3.DeleteItem\n4.AddItemAfter\n5.FindItem\n6.Display\n7.SwapNodes\n8.InsertionSort\n9.DeleteLast\n10.DeleteFirst\n11.BubbleSort\n12.SelectionSort\n13.Exit");
    	    ch=Integer.parseInt(in.readLine());
	    switch(ch)
	    {
		case 1:
		{
		    System.out.println("Enter item:");
		    int i=Integer.parseInt(in.readLine());
		    d.additemfirst(i);
		    break;
		}
		case 2:
		{
		    System.out.println("Enter item:");
		    int i=Integer.parseInt(in.readLine());
		    d.additemlast(i);
		    break;
		}
		case 3:
		{
		    System.out.println("Enter item:");
		    int i=Integer.parseInt(in.readLine());
		    d.deleteitem(i);
		    break;
		}	    
		case 4:
		{
		    System.out.println("Enter item:");
		    int i=Integer.parseInt(in.readLine());
		    System.out.println("Enter index:");
		    int j=Integer.parseInt(in.readLine());
		    d.additemafter(i,j);
		    break;
		}
		case 5:
		{
		    System.out.println("Enter item:");
		    int i=Integer.parseInt(in.readLine());
		    System.out.println(d.finditem(i));
		    break;
		}
		case 6:
		{
		    d.display();
		    break;
		}
		case 7:
		{
		    System.out.println("Enter Item1:");
		    int i=Integer.parseInt(in.readLine());
		    System.out.println("Enter Item2:");
		    int j=Integer.parseInt(in.readLine());
		    d.swapnodes(i,j);
		    break;
		}    
		case 8:
		{
		    d.insertionsort();
		    System.out.println("Done..");
		    break;
		}
		case 9:
		{
		    d.deletelast();
		    System.out.println("Done..");
		    break;
		}
		case 10:
		{
		    d.deletefirst();
		    System.out.println("Done..");
		    break;
		}
		case 11:
		{
		    d.bubblesort();
		    System.out.println("Done..");
		    break;
		}
		case 12:
		{
		    d.selectionsort();
		    System.out.println("Done..");
		    break;
		}
		default:
		    ch=20;
	    }
	}
	return;
    }
}
