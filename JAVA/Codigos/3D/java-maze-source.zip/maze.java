/*
java maze, a fast raycasting engine written in the Java language
version 20000321
Copyright (C) 2004 Jonathan Thomas

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

contact me with greetings, comments, (sensible) questions: jthomas@deverse.co.uk
*/

import java.applet.*;
import java.awt.*;
import java.net.*;
import java.awt.image.*;
import java.awt.event.*;

public final class maze extends Applet implements Runnable, KeyListener
{
    final static double fullCircle=Math.PI*2;
    double multiplier;

	Graphics myGraphics;
	
    final int numWallTextures=22;
	final int numObjectTextures=1;
    final int numObjects=1000;

	double objectXpos[];
	double objectZpos[];
	
	Thread renderer;
    Thread title;
    Thread initialiser;
	
	int counter;
	
    int nextPaletteEntry=1;
    byte[] paletteReds=new byte[256];
    byte[] paletteGreens=new byte[256];
    byte[] paletteBlues=new byte[256];
    IndexColorModel myColorModel;
	
	byte wallTextureData[][];
	byte objectTextureData[][];
	
	int appletWidth;
	int appletHeight;
	
	long newtime;
	
    int map[];
    int lightMap[];
    byte floorMap[];
    byte ceilingMap[];
	int intersectionX;
	int intersectionY;
	int screenX;
	
	double playerXpos;
	double playerYpos;
	
	double XHops;
	double YHops;
	double XHopSize;
	double YHopSize;

	int currentRayXpos;
	int currentRayYpos;
	double startRayXpos;
	double startRayYpos;
	
	int blockHit;
	int blockDistance;

    int blockLightRecord[];
    int blockHitRecord[];
    int blockDistanceRecord[];
    int textureXRecord[];

	double xMeasure;
	double yMeasure;
	
	double playerDirection;
	double copyOfPlayerDirection;
	double rayDirection;

	double rotationStep;
	
	double distanceAdjuster[];

	boolean runningForwards;
	boolean runningBackwards;
	boolean rightStepping;
	boolean leftStepping;
	boolean turningLeft;
	boolean turningRight;

	int frames;

	byte renderBuffer[];

	double firstRayXMove;
	double firstRayYMove;
	double lastRayXMove;
	double lastRayYMove;

	int zBuffer[];

	// renderbufferVline
	
	int offset;
	int endOffset;
	int step;
	int source;
	byte colour;

	// render

	double ax,az;
	double tx,tz;
	int sx,sy;

	int zoneLength;
	double furthestWall;

    // duh

    int floorDestOffset;
    int ceilingDestOffset;

    int floorY;
    int floorX;

    double runStartX;
    double runEndX;
    double runStartY;
    double runEndY;

    double yAtMinX;
    double yAtMaxX;
    double xAtMinY;
    double xAtMaxY;

    int textureXStep; // also used by drawobject
    int textureYStep;

    int textureXpos;
    int textureYpos;

    // drawobject

    byte[] shadeTable;
    byte[] shadeTable2;

    byte[] floorTexture;
    byte[] ceilingTexture;

    int pixel;
    int tileOffset;
    int oldTileOffset=666;
    int pixelOffset;

    boolean drawingFloor;
    int pixelsSkipped;

    public maze() { // required for netscape compatibility
	}
	
	public String getAppletInfo() {
        return "Java maze\nJonathan Thomas 1999\nhttp://www.geocities.com/siliconvalley/campus/5009/";  
	}
	
    void createLightMap() {
            PixelGrabber convertor;
            int[] tempTextureData=new int[256*256];

            Image lightMapImage=getImage(getCodeBase(),"lights.gif");
			MediaTracker watch=new MediaTracker(this);
            watch.addImage(lightMapImage,1);

			try {
				watch.waitForAll();
			} catch (InterruptedException i) {
				System.out.println("Image loading interrupted");
				Thread.currentThread().stop();
			}

            convertor=new PixelGrabber(lightMapImage,0,0,256,256,tempTextureData,0,256);
			try {
                convertor.grabPixels();
			} catch (InterruptedException i) {
				System.out.println("Pixel grabber interrupted");
			}

            int doc;
            for (doc=0; doc<65536; doc++) {
                lightMap[doc]=(tempTextureData[doc]&255)+64;
                if (lightMap[doc]>255)
                    lightMap[doc]=255;
            }


    }

    void createShadeTable(byte[] table, IndexColorModel palette, int disRed,int disGreen, int disBlue) {
        int searchRed,searchGreen,searchBlue;
        int abs_dif,smallest_dif;

        int shade,col,currentCol,smallest_dif_col;
        int destinationOffset;
        int searchCol;

        destinationOffset=0;

        for (shade=0; shade<256; shade++) {
            for (col=0; col<256; col++) {
                searchCol=col-128;
                if (searchCol<0)
                    searchCol=256+searchCol;

                searchRed=(disRed+((palette.getRed(searchCol)-disRed)*shade/256));
                searchGreen=(disGreen+((palette.getGreen(searchCol)-disGreen)*shade/256));
                searchBlue=(disBlue+((palette.getBlue(searchCol)-disBlue)*shade/256));

                smallest_dif=768;
                smallest_dif_col=0;

                for (currentCol=0; currentCol<256; currentCol++) {
                    abs_dif=Math.abs(palette.getRed(currentCol)-searchRed)+
                            Math.abs(palette.getGreen(currentCol)-searchGreen)+
                            Math.abs(palette.getBlue(currentCol)-searchBlue);

                    if (abs_dif<smallest_dif) {
                        smallest_dif=abs_dif;
                        smallest_dif_col=currentCol;
                    }
                } 

            table[destinationOffset]=(byte)smallest_dif_col;
            destinationOffset++;
            }

        }
    }

	public void loadTextureSet(int numTextures, String filename, byte[][] destArray) {
		Image tempTexture;
		int[] tempTextureData=new int[64*64];
		PixelGrabber textureGrabber;
		
		for (counter=0; counter<numTextures; counter++) {
							
            getAppletContext().showStatus("[java maze] Loading "+filename+" #"+(counter+1)+"/"+numTextures);      
			
			tempTexture=getImage(getCodeBase(),filename+counter+".gif");
			MediaTracker watch=new MediaTracker(this);
			watch.addImage(tempTexture,1);

			try {
				watch.waitForAll();
			} catch (InterruptedException i) {
				System.out.println("Image loading interrupted");
				Thread.currentThread().stop();
			}
		
			if (watch.isErrorAny()==true) {
				System.out.println("Problems loading texture");
				Thread.currentThread().stop();
			} else {
				System.out.println("Texture loaded ok");
			}		
	
			textureGrabber=new PixelGrabber(tempTexture,0,0,64,64,tempTextureData,0,64);
			try {
				textureGrabber.grabPixels();
			} catch (InterruptedException i) {
				System.out.println("Pixel grabber interrupted");
			}
			convertPixels(64,64,tempTextureData,destArray[counter]);
		}
	}

	public void loadTextures() {
		wallTextureData=new byte[numWallTextures][64*64];
		objectTextureData=new byte[numObjectTextures][64*64];
		
		loadTextureSet(numObjectTextures,"object",objectTextureData);
		loadTextureSet(numWallTextures,"texture",wallTextureData);
	}
	
	public void init() {   
	}
		
	public void convertPixels(int width,int height,int[] sourcePixels,byte[] destPixels) {
		int currentPixel;
		int currentPaletteEntry=0;
		boolean match;
		
		byte sourceRed,sourceGreen,sourceBlue;

		for (currentPixel=0;currentPixel<(width*height); currentPixel++) {
			sourceRed=(byte)((sourcePixels[currentPixel]>>16)&248);
			sourceGreen=(byte)((sourcePixels[currentPixel]>>8)&248);
			sourceBlue=(byte)((sourcePixels[currentPixel])&248);
			
			if ((sourceRed==0) && (sourceGreen==64) && (sourceBlue==0)) {
				destPixels[currentPixel]=0; // transparent pixel
			} else {
				match=false;
				currentPaletteEntry=0;

				while ((match==false) && (currentPaletteEntry<nextPaletteEntry)) {
					if ( (paletteReds[currentPaletteEntry]==sourceRed) &&
						 (paletteGreens[currentPaletteEntry]==sourceGreen) &&
						 (paletteBlues[currentPaletteEntry]==sourceBlue)) {
						match=true;
						destPixels[currentPixel]=(byte)currentPaletteEntry;
					}
					currentPaletteEntry++;
				}
			
				if (match==false) {
					paletteReds[nextPaletteEntry]=sourceRed;
					paletteGreens[nextPaletteEntry]=sourceGreen;
					paletteBlues[nextPaletteEntry]=sourceBlue;
					destPixels[currentPixel]=(byte)nextPaletteEntry;
					nextPaletteEntry++;
					if (nextPaletteEntry==256) {
						System.out.println("ERROR: Too many colours in textures");
						Thread.currentThread().stop();
					}
				}
			}				
		}		
	}
	
    public void renderBufferVLine(byte texture[],int screenX,int height, int textureX, boolean transparent, int lightLevel) { 
	 
        int light=(lightLevel<<8)+128;
        textureX=textureX*64;

        if (height>0) {
			step=(64<<16)/height;
		
			if (height>appletHeight) {
				height=appletHeight;
				source=((64<<16)/2)-(step*(height/2));
				offset=screenX;
				endOffset=screenX+(height*appletWidth);
			} else {
				source=0;
				offset=(((appletHeight/2)-(height/2))*appletWidth)+screenX;
				endOffset=offset+(height*appletWidth);
			}
		
			if (transparent==true) {
				while (offset<endOffset) {
                    pixel=texture[textureX+(source>>16)]; // =(source>>16)<<6
                    if (pixel!=0) 
                        renderBuffer[offset]=shadeTable[pixel+light];
					offset+=appletWidth;
					source+=step;
				}
			} else {
				while (offset<endOffset) {
                    renderBuffer[offset]=shadeTable[texture[textureX+(source>>16)]+light];
                    //renderBuffer[offset]=120;
                    offset+=appletWidth;
                    source+=step;
				}
			}
		}
    }

    public void drawObject(int screenX, int height, int distance, int light) {

        int currentScreenX;
        int textureXStep;
        int textureX;
        int endScreenX;
        int currentTextureX=0;

        if (height>0) {
			textureXStep=(64<<16)/height;
			currentScreenX=screenX-height/2;
			if ( ((screenX+(height/2)) >=0) && ((screenX-(height/2)) <appletWidth))  {
				endScreenX=screenX+(height/2);
			
				if (endScreenX>appletWidth)
					endScreenX=appletWidth;
				
				if (currentScreenX<0) {
					currentTextureX-=(textureXStep*currentScreenX);
					currentScreenX=0;
				}

                while (currentScreenX<endScreenX) {
                    if (zBuffer[currentScreenX]>distance) 
                            renderBufferVLine(objectTextureData[0],currentScreenX, height,currentTextureX>>16,true,light);
                    currentScreenX++;
                    currentTextureX+=textureXStep;
                }
			}
		}
	}
	
	public void mapGen() {
		
		int xpos,ypos,width,height,ystart,yend,tileColour,cx,cy;

		for (cy=0; cy<256; cy++) 
			for (cx=0; cx<256; cx++)
                map[(cx<<8)+cy]=-1;
		
        for (counter=0; counter<300; counter++) {
			xpos=(int)(Math.random()*200);
			ypos=(int)(Math.random()*200);
			
			width=(int)(Math.random()*50);
			height=(int)(Math.random()*50);

            tileColour=(int)(Math.random()*22);
			
			for (cx=xpos; cx<(xpos+width); cx++) {
                map[(ypos<<8)+cx]=tileColour;
                map[((ypos+height)<<8)+cx]=tileColour;
			}

			for (cy=ypos; cy<(ypos+height); cy++) {
                map[(cy<<8)+xpos]=tileColour;
                map[(cy<<8)+xpos+width]=tileColour;
			}
		}

		for (counter=0; counter<1500; counter++) {
			xpos=(int)(Math.random()*255);
			ystart=(int)(Math.random()*255);
			do {
			yend=(int)(Math.random()*255);
			} while ((ystart>yend) || ((yend-ystart)>18));
			for (cy=ystart; cy<yend; cy++)
                map[(cy<<8)+xpos]=-1;
			xpos=(int)(Math.random()*255);
			ystart=(int)(Math.random()*255);
			do {
			yend=(int)(Math.random()*255);
			} while ((ystart>yend) || ((yend-ystart)>15));
			for (cy=ystart; cy<yend; cy++)
                map[(xpos<<8)+cy]=-1;
		}
		
		for (counter=0; counter<256; counter++) {
            map[(counter<<8)+0]=1;
            map[(counter<<8)+255]=1;
            map[counter]=1;
            map[(255<<8)+counter]=1;     
		}
	}
	
    public void drawFloor() {

        int light=0;
        int mapOffset;
        int textureOffset;

        // calculate starting point from furthestWall

        floorY=(int)((33280*appletHeight)/furthestWall)/2;
        if (floorY<appletHeight) {

            floorDestOffset=(appletWidth*(appletHeight/2))+(floorY*appletWidth);
            ceilingDestOffset=(appletWidth*(appletHeight/2-1))-(floorY*appletWidth);
				
            for (; floorY<appletHeight/2; floorY++) {                           

                runStartX=startRayXpos+Math.sin(fullCircle+rayDirection)*multiplier/floorY;
                runEndX=startRayXpos+Math.sin(rayDirection-(rotationStep*appletWidth))*multiplier/floorY;
                textureXStep=(int)((runEndX-runStartX)/appletWidth);
                textureXpos=(int)runStartX;
                runStartY=startRayYpos+Math.cos(fullCircle+rayDirection)*multiplier/floorY;
                runEndY=startRayYpos+Math.cos(rayDirection-(rotationStep*appletWidth))*multiplier/floorY;
                textureYStep=(int)((runEndY-runStartY)/appletWidth);
                textureYpos=(int)runStartY;

                if ( (runStartX<0) || (runStartX>16777216) ||
                     (runStartY<0) || (runStartY>16777216) ||
                     (runEndX<0) || (runEndX>16777216) ||
                     (runEndY<0) || (runEndY>16777216) ) {

                     yAtMinX=runStartY+((runEndY-runStartY)/(runEndX-runStartX)*(0-runStartX));
                     yAtMaxX=runStartY+((runEndY-runStartY)/(runEndX-runStartX)*(16777215-runStartX));
                     xAtMinY=runStartX+((runEndX-runStartX)/(runEndY-runStartY)*(0-runStartY));
                     xAtMaxY=runStartX+((runEndX-runStartX)/(runEndY-runStartY)*(16777215-runStartY));

                     floorDestOffset+=appletWidth;
                     ceilingDestOffset-=appletWidth;
                } else {

                    for (floorX=0; floorX<appletWidth; floorX++) {

                        tileOffset=(((textureYpos&0xFFFF0000)>>8)+(textureXpos>>16));
                        if (tileOffset!=oldTileOffset) {
                            light=(lightMap[tileOffset]<<8)+128;
                            floorTexture=wallTextureData[floorMap[tileOffset]];
                            ceilingTexture=wallTextureData[ceilingMap[tileOffset]];
                        }

                        pixelOffset=(((textureYpos&64527)>>4))+((textureXpos&65535)>>10);
                        renderBuffer[floorDestOffset]=shadeTable[floorTexture[pixelOffset]+light];
                        renderBuffer[ceilingDestOffset]=shadeTable[ceilingTexture[pixelOffset]+light];

                        textureXpos+=textureXStep;
                        textureYpos+=textureYStep;

                        floorDestOffset++;
                        ceilingDestOffset++;
                        oldTileOffset=tileOffset;
                    }
                    ceilingDestOffset-=appletWidth*2;
                }

            }

        }

    }

    public void render() {
		
		furthestWall=0;

		copyOfPlayerDirection=playerDirection;
		rayDirection=copyOfPlayerDirection+(rotationStep*(appletWidth/2));
		startRayXpos=playerXpos;
		startRayYpos=playerYpos;
		screenX=0;

        // now calculate walls

		firstRayXMove=Math.sin(fullCircle+rayDirection);
		firstRayYMove=Math.cos(fullCircle+rayDirection);
		lastRayXMove=Math.sin(rayDirection-(rotationStep*appletWidth));
		lastRayYMove=Math.cos(rayDirection-(rotationStep*appletWidth));

		while (screenX<appletWidth) {
			currentRayXpos=(int)startRayXpos;
			currentRayYpos=(int)startRayYpos;
			XHopSize=firstRayXMove+((lastRayXMove-firstRayXMove)*screenX/appletWidth);
			YHopSize=firstRayYMove+((lastRayYMove-firstRayYMove)*screenX/appletWidth);
			blockHit=-1;
			
			if (XHopSize>0) {
				if (YHopSize>0)
					downRight();
				else
					upRight();
			} else {
				if (YHopSize>0)
					downLeft();
				else
					upLeft();
			}
			
			xMeasure=currentRayXpos-startRayXpos;
			yMeasure=currentRayYpos-startRayYpos;
            zBuffer[screenX]=blockDistance=(int)(Math.sqrt((xMeasure*xMeasure)+(yMeasure*yMeasure))/distanceAdjuster[screenX]);
			if (blockDistance>furthestWall)
				furthestWall=blockDistance;

            blockHitRecord[screenX]=blockHit;
            blockDistanceRecord[screenX]=blockDistance;

            if ((blockHit&1)==0)
                textureXRecord[screenX]=((int)currentRayXpos&65535)/1024;
            else
                textureXRecord[screenX]=((int)currentRayYpos&65535)/1024;
            
			screenX++;
		}

        // calculate and draw the floor

        drawFloor();

        // draw walls

        for (screenX=0; screenX<appletWidth; screenX++) {
            renderBufferVLine(wallTextureData[blockHitRecord[screenX]/2],
                              screenX,
                              (int)((33280*appletHeight)/blockDistanceRecord[screenX]),
                              textureXRecord[screenX],
                              false,
                              blockLightRecord[screenX]);
        }

        // calculate and draw objects
		
		for (counter=0; counter<numObjects; counter++) {
			tz = (ax=objectXpos[counter]-startRayXpos)*Math.sin(copyOfPlayerDirection) + (az=objectZpos[counter]-startRayYpos)*Math.cos(copyOfPlayerDirection);
			
			if ((tz>0) && (tz<furthestWall)) {
				tx = ax*Math.cos(copyOfPlayerDirection) - az*Math.sin(copyOfPlayerDirection);
				sx = (int)((appletWidth/2)-(tx*(appletWidth/2))/tz);
                drawObject(sx,(int)((33280*appletHeight)/tz),(int)tz,
                          lightMap[ (((int)objectZpos[counter]&0xFFFF0000)>>8) + ((int)objectXpos[counter]>>16)]);
			}
		}

	}
	
	public void downRight() {
				
		intersectionX=(((int)(currentRayXpos)&0xFFFF0000)+65536); 
		intersectionY=(((int)(currentRayYpos)&0xFFFF0000)+65536); 
		while (blockHit==-1) {
			XHops=(intersectionX-currentRayXpos)/XHopSize; 
			YHops=(intersectionY-currentRayYpos)/YHopSize; 
			if (XHops<YHops) {
				currentRayXpos=intersectionX;
				currentRayYpos+=(XHops*YHopSize);
                if (map[(((intersectionY>>16)-1)<<8)+(intersectionX>>16)]>-1) {
                    blockHit=map[(((intersectionY>>16)-1)<<8)+(intersectionX>>16)]*2+1;
                    blockLightRecord[screenX]=lightMap[((intersectionY&0xFFFF0000)>>8) + (intersectionX>>16)];
                    }
				else 
					intersectionX+=65536;
			} else {
				currentRayYpos=intersectionY;
				currentRayXpos+=(YHops*XHopSize);
                if (map[((intersectionY>>16)<<8)+((intersectionX>>16)-1)]>-1) {
                    blockHit=map[((intersectionY>>16)<<8)+((intersectionX>>16)-1)]*2;
                    blockLightRecord[screenX]=lightMap[((intersectionY&0xFFFF0000)>>8) + (intersectionX>>16)];
                    }
				else 
					intersectionY+=65536;
			}
		}
	}

	public void upRight() {

		intersectionX=(((int)(currentRayXpos)&0xFFFF0000)+65536);
		intersectionY=(((int)(currentRayYpos)&0xFFFF0000)); 
		while (blockHit==-1) {
			XHops=(intersectionX-currentRayXpos)/XHopSize; 
			YHops=(intersectionY-currentRayYpos)/YHopSize; 
			if (XHops<YHops) {
				currentRayXpos=intersectionX;
				currentRayYpos+=(XHops*YHopSize);
                if (map[((intersectionY>>16)<<8)+(intersectionX>>16)]>-1) {
                    blockHit=map[((intersectionY>>16)<<8)+(intersectionX>>16)]*2+1;
                    blockLightRecord[screenX]=lightMap[((intersectionY&0xFFFF0000)>>8) + (intersectionX>>16)];
                }
				else
					intersectionX+=65536;
			} else {
				currentRayYpos=intersectionY;
				currentRayXpos+=(YHops*XHopSize);
                if (map[(((intersectionY>>16)-1)<<8)+((intersectionX>>16)-1)]>-1) {
                    blockHit=map[(((intersectionY>>16)-1)<<8)+((intersectionX>>16)-1)]*2;
                    blockLightRecord[screenX]=lightMap[((intersectionY&0xFFFF0000)>>8) + (intersectionX>>16)];
                    }
				else 
					intersectionY-=65536;
			}
		}
	}

	public void downLeft() {
		
		intersectionX=(((int)(currentRayXpos)&0xFFFF0000)); 
		intersectionY=(((int)(currentRayYpos)&0xFFFF0000)+65536); 
		while (blockHit==-1) {
			XHops=(intersectionX-currentRayXpos)/XHopSize; 
			YHops=(intersectionY-currentRayYpos)/YHopSize; 
			if (XHops<YHops) {
				currentRayXpos=intersectionX;
				currentRayYpos+=(XHops*YHopSize);
                if (map[(((intersectionY>>16)-1)<<8)+((intersectionX>>16)-1)]>-1) {
                    blockHit=map[(((intersectionY>>16)-1)<<8)+((intersectionX>>16)-1)]*2+1;
                    blockLightRecord[screenX]=lightMap[((intersectionY&0xFFFF0000)>>8) + (intersectionX>>16)];
                    }
				else 
					intersectionX-=65536;
			} else {
				currentRayYpos=intersectionY;
				currentRayXpos+=(YHops*XHopSize);
                if (map[((intersectionY>>16)<<8)+(intersectionX>>16)]>-1) {
                    blockHit=map[((intersectionY>>16)<<8)+(intersectionX>>16)]*2;
                    blockLightRecord[screenX]=lightMap[((intersectionY&0xFFFF0000)>>8) + (intersectionX>>16)];
                    }
				else 
					intersectionY+=65536;
			}
		}
	}

	public void upLeft() {
		
		intersectionX=(((int)(currentRayXpos)&0xFFFF0000)); 
		intersectionY=(((int)(currentRayYpos)&0xFFFF0000)); 
		while (blockHit==-1) {
			XHops=(intersectionX-currentRayXpos)/XHopSize; 
			YHops=(intersectionY-currentRayYpos)/YHopSize; 
			if (XHops<YHops) {
				currentRayXpos=intersectionX;
				currentRayYpos+=(XHops*YHopSize);
                if (map[((intersectionY>>16)<<8)+((intersectionX>>16)-1)]>-1) {
                    blockHit=map[((intersectionY>>16)<<8)+((intersectionX>>16)-1)]*2+1;
                    blockLightRecord[screenX]=lightMap[((intersectionY&0xFFFF0000)>>8) + (intersectionX>>16)];
                    }
				else 
					intersectionX-=65536;
			} else {
				currentRayYpos=intersectionY;
				currentRayXpos+=(YHops*XHopSize);
                if (map[(((intersectionY>>16)-1)<<8)+(intersectionX>>16)]>-1) {
                    blockHit=map[(((intersectionY>>16)-1)<<8)+(intersectionX>>16)]*2;
                    blockLightRecord[screenX]=lightMap[((intersectionY&0xFFFF0000)>>8) + (intersectionX>>16)];
                    }
				else 
					intersectionY-=65536;
			}
		}
	}

    public void destroy() {
		myGraphics.dispose();
	}

    public void update(Graphics g) { // required for netscape compatibility    
	}
	
    public void paint(Graphics g) { // required for netscape compatibility
	}

    public void start() {

        if (initialiser==null) {
            initialiser = new Thread(this,"initialiser");
            initialiser.start();
		}

        if (title==null) {
            title = new Thread(this,"titleScreen");
            title.start();
		}
    }

    public void initialiser() {
		
        getAppletContext().showStatus("[java maze] One moment...");

        addKeyListener(this);

		myGraphics=getGraphics();		
        appletWidth=getSize().width;
        appletHeight=getSize().height;
        multiplier=33280*appletWidth/2*1.4;

		renderBuffer=new byte[appletWidth*appletHeight];
				
        map=new int[65536];
        lightMap=new int[65536];
        floorMap=new byte[65536];
        ceilingMap=new byte[65536];

        blockLightRecord=new int[appletWidth];
        blockHitRecord=new int[appletWidth];
        blockDistanceRecord=new int[appletWidth];
        textureXRecord=new int[appletWidth];

		loadTextures();
        createLightMap();

		mapGen();

		objectXpos=new double[numObjects];
		objectZpos=new double[numObjects];

		for (counter=0; counter<numObjects; counter++) {	
            objectZpos[counter]=(Math.round(Math.random()*255)*65536)+32768;
            objectXpos[counter]=(Math.round(Math.random()*255)*65536)+32768;
		}

		rotationStep=fullCircle/(appletWidth*4);
		distanceAdjuster=new double[appletWidth];
		
		double firstRayXMove=Math.sin(fullCircle/8*3);
		double lastRayXMove=Math.sin(fullCircle/8*5);
		double firstRayYMove=Math.cos(fullCircle/8*3);
		double lastRayYMove=Math.cos(fullCircle/8*5);
		for (counter=0; counter<appletWidth; counter++) {
			XHopSize=firstRayXMove+((lastRayXMove-firstRayXMove)*counter/appletWidth);
			YHopSize=firstRayYMove+((lastRayYMove-firstRayYMove)*counter/appletWidth);
			distanceAdjuster[counter]=Math.sqrt((XHopSize*XHopSize)+(YHopSize*YHopSize))*1.4;
		}
		
		myColorModel=new IndexColorModel(8, 256, paletteReds,paletteGreens,paletteBlues);
        shadeTable=new byte[65536];

        getAppletContext().showStatus("[java maze] number crunching...");
        createShadeTable(shadeTable,myColorModel, 0,0,0);

        getAppletContext().showStatus("[java maze] starting...");

		zBuffer=new int[appletWidth];

        // init end

        byte c;
        int d,x,y,x2,y2,xc,yc;
        for (d=0; d<5000; d++) {
            c=(byte)(Math.random()*22);
            x=(int)(Math.random()*230);
            y=(int)(Math.random()*230);
            x2=x+(int)(Math.random()*12);
            y2=y+(int)(Math.random()*12);
            for (yc=y; yc<y2; yc++)
                for (xc=x; xc<x2; xc++)
                    floorMap[(yc*256)+xc]=c;
        }

        for (d=0; d<5000; d++) {
            c=(byte)(Math.random()*22);
            x=(int)(Math.random()*230);
            y=(int)(Math.random()*230);
            x2=x+(int)(Math.random()*12);
            y2=y+(int)(Math.random()*12);
            for (yc=y; yc<y2; yc++)
                for (xc=x; xc<x2; xc++)
                    ceilingMap[(yc*256)+xc]=c;
        }

		playerXpos=(65536*128)+32768;
		playerYpos=(65536*128)+32768;
		playerDirection=fullCircle/4*1;
		
		rightStepping=leftStepping=turningLeft=turningRight=runningForwards=runningBackwards=false;
		
		if (renderer==null) {
            renderer = new Thread(this,"renderer");
			renderer.start();
		}

	}
	
	public void run()
	{
        if (Thread.currentThread().getName().equals("initialiser")) 
            initialiser();
        if (Thread.currentThread().getName().equals("renderer"))
            renderer();
        if (Thread.currentThread().getName().equals("titleScreen")) 
            title();

	}

    public void title() {
        while (myGraphics==null) {}
        myGraphics.setColor(Color.black);
        myGraphics.fillRect(0,0,appletWidth,appletHeight);
    }

	public void renderer() {
		frames=0;
        MemoryImageSource pictureArray=new MemoryImageSource(appletWidth,  appletHeight, myColorModel,  renderBuffer,  0,  appletWidth);
        pictureArray.setAnimated(true);
        Image displayImage=createImage(pictureArray);
		    
        newtime=System.currentTimeMillis()+1000;

		while (1==1) {
			if (System.currentTimeMillis()>newtime) {
                getAppletContext().showStatus("[java maze] "+frames+ "FPS");
				frames=0;
				newtime+=1000;
			}			

            render();
            pictureArray.newPixels();                 
            myGraphics.drawImage(displayImage,0,0,this);            

			if (turningLeft) {
                playerDirection+=fullCircle/48;
				if (playerDirection>fullCircle)
					playerDirection-=fullCircle;
			}
			
			if (turningRight) {
                playerDirection-=fullCircle/48;
				if (playerDirection<0)
					playerDirection+=fullCircle;
			}
			
			if (rightStepping) {
                playerXpos+=Math.sin(playerDirection-(fullCircle/4))*10000;
                playerYpos+=Math.cos(playerDirection-(fullCircle/4))*10000;
			}

			if (leftStepping) {
                playerXpos+=Math.sin(playerDirection+(fullCircle/4))*10000;
                playerYpos+=Math.cos(playerDirection+(fullCircle/4))*10000;
			}
			
			if (runningForwards) {
                playerXpos+=Math.sin(playerDirection)*10000;
                playerYpos+=Math.cos(playerDirection)*10000;
			}

			if (runningBackwards) {
                playerXpos-=Math.sin(playerDirection)*10000;
                playerYpos-=Math.cos(playerDirection)*10000;
			}
			frames++;
		}
	}
	
	public void stop() {
		if (renderer!=null) {
			renderer.stop();
			renderer=null;
		}
	}
	
    public void keyPressed(KeyEvent event) {
        int keyPressed=event.getKeyCode();
        switch(keyPressed) {
        case KeyEvent.VK_UP:
			runningForwards=true;
			break;
        case KeyEvent.VK_DOWN:
			runningBackwards=true;
			break;
        case KeyEvent.VK_LEFT:
            if (event.isControlDown())
                leftStepping=true;
            else
                turningLeft=true;
			break;
        case KeyEvent.VK_RIGHT:
            if (event.isControlDown())
                rightStepping=true;
            else
                turningRight=true;
			break;
        }
    }

    public void keyTyped(KeyEvent event) {
    }

    public void keyReleased(KeyEvent event) {
        int keyPressed=event.getKeyCode();

        switch (keyPressed) {
        case KeyEvent.VK_UP:   runningForwards=false;             break;
        case KeyEvent.VK_DOWN: runningBackwards=false;            break;
        case KeyEvent.VK_LEFT: turningLeft=leftStepping=false;    break;
        case KeyEvent.VK_RIGHT:turningRight=rightStepping=false;  break;
		}
    }

}
