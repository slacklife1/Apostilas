/*
 * Author 		: David Mckay
 * Time & Date 	: 24-Jun-2003 - 20:21:07
 *
 * E-Mail 		: DavidMckay@Blueyonder.co.uk
 */

/**
 */
public class KButtonGroup
{
	private KButton[] buttons;
	private int noOfButtons;
	private int currentSelected;

	public KButtonGroup(int maxSize)
	{
		buttons = new KButton[maxSize];
		noOfButtons = 0;
		currentSelected = -1;
	}

	public void addKButton(KButton newButton)
	{
		if(!inGroup(newButton))
		{
			newButton.setKButtonGroup(this);
			buttons[noOfButtons++] = newButton;
		}
	}

	private boolean inGroup(KButton button)
	{
		for(int i = 0; i < noOfButtons; i++)
			if(buttons[i] == button)
				return true;
		return false;
	}

	public void handleButtonClick(KButton button, boolean tf)
	{
		if(tf)
		{
			for(int i = 0; i < noOfButtons; i++)
				if(buttons[i] != button)
					buttons[i].setSelected(false);
			button.setSelected(true);
		}
		else
		{
			for(int i = 0; i < noOfButtons; i++)
				buttons[i].setSelected(false);
		}
	}
}
