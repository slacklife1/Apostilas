/*
 * Author 		: David Mckay
 * Time & Date 	: 23-Jun-2003 - 19:24:13
 *
 * E-Mail 		: DavidMckay@Blueyonder.co.uk
 */

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.font.TextAttribute;
import java.awt.font.TextLayout;
import java.text.AttributedString;
import javax.swing.JComponent;

/**
 */
public class KButton extends JComponent implements MouseListener
{
	/** States
	 */
	private boolean selected;
	private boolean highlighted;

	/** ButtonGroup - Currently only allows one
	 */
	private KButtonGroup group;

	/** The text to draw on the button
	 */
	private String text;

	/** Font to be used to draw the text on the button
	 */
	private Font textFont;

	/** Colours used for various states of the button
	 */
	private Color normalColourOne 		= new Color(255, 255, 255);
	private Color normalColourTwo 		= new Color(  0,   0,   0);
	private Color normalTextColour 		= new Color(255, 255, 255);

	private Color highlightColourOne 	= new Color(  0,   0, 128);
	private Color highlightColourTwo 	= new Color(255, 255,   0);
	private Color highlightTextColour 	= new Color(255,   0,   0);

	private Color selectedColourOne 	= new Color(128, 255,  128);
	private Color selectedColourTwo 	= new Color(255, 128,   64);
	private Color selectedTextColour 	= new Color(  0, 192,  128);


	/** Constructor
	 */
	public KButton(String text)
	{
		super();

		addMouseListener(this);

		this.text = text;

		textFont = new Font("Comic Sans MS", Font.PLAIN, 14);

		selected 	= false;
		highlighted = false;
	}

	/** Set & Get Methods
	 */
	public void setKButtonGroup(KButtonGroup bGroup)
	{
		group = bGroup;
	}

	public Dimension getMinimumSize()
	{
		return new Dimension(100, 25);
	}

	public Dimension getPreferredSize()
	{
		return new Dimension(250, 50);
	}

	public void setSelected(boolean tf)
	{
		selected = tf;
		repaint();
	}

	public String getText()
	{
		return text;
	}


	/** Mouse Events
	 */
	public void mouseClicked(MouseEvent mEvent) 	{}
	public void mouseReleased(MouseEvent mEvent) 	{}

	public void mouseEntered(MouseEvent mEvent)
	{
		highlighted = true;
		repaint();
	}

	public void mouseExited(MouseEvent mEvent)
	{
		highlighted = false;
		repaint();
	}

	public void mousePressed(MouseEvent mEvent)
	{
		if(selected)
			selected = false;
		else
			selected = true;
		group.handleButtonClick(this, selected);
		repaint();
	}

	/** Paint The Button Using The Graphics Context Passed
	 */
	public void paint(Graphics g)
	{
		Graphics2D g2D = (Graphics2D)g;

		fillBackground(g2D);
		drawBorder(g2D);
		drawText(g2D);
	}

	private void fillBackground(Graphics2D g2D)
	{
		GradientPaint gPaint;

		g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
								RenderingHints.VALUE_ANTIALIAS_ON);

		if(selected || highlighted)
			gPaint = new GradientPaint
					(0, 0, selected?selectedColourOne:highlightColourOne,
					 45, 45, selected?selectedColourTwo:highlightColourTwo);
		else
			gPaint = new GradientPaint(0, 0, normalColourOne, 20, 20, normalColourTwo);

		g2D.setPaint(gPaint);
		g2D.fillRect(0, 0, getWidth(), getHeight());
	}

	private void drawBorder(Graphics2D g2D)
	{
		g2D.setColor(Color.white);
		g2D.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
	}

	private void drawText(Graphics2D g2D)
	{
		AttributedString fancyText = new AttributedString(text);
		fancyText.addAttribute(TextAttribute.FONT, textFont);

		if(selected)
			fancyText.addAttribute(TextAttribute.FOREGROUND, selectedTextColour, 0, text.length());
		else if(highlighted)
			fancyText.addAttribute(TextAttribute.FOREGROUND, highlightTextColour, 0, text.length());
		else
			fancyText.addAttribute(TextAttribute.FOREGROUND, normalTextColour, 0, text.length());

		TextLayout tl = new TextLayout(fancyText.getIterator(), g2D.getFontRenderContext());
		double yPosition = ((getHeight() - tl.getBounds().getHeight()) / 2) + (tl.getBounds().getHeight());
		tl.draw(g2D, 25, (float)yPosition);
	}

}
