package demo;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;

import com.japisoft.framework.dockable.InnerWindowProperties;
import com.japisoft.framework.dockable.JDock;

/**
 * This is a demo showing inner windows with a borderLayout
 * @author (c) 2004 JAPISoft
 */
public class InnerWindowBorderLayout {

	public static void main( String[] args ) {

		// Main panel 
		JDock pane = new JDock();

		// Action for removing the default shadow
		// pane.setShadowMode( false );

		// The default JDock layout is a BorderLayout

		pane.addInnerWindow( new InnerWindowProperties( 
				"T1", "Tree", new JScrollPane( new JTree() ) ), BorderLayout.WEST );
		pane.addInnerWindow( new InnerWindowProperties(
				"TA", "Text Area", new JTextArea() ), BorderLayout.CENTER );
		pane.addInnerWindow( new JTextField( "SOUTH" ), BorderLayout.SOUTH );
				
		pane.addInnerWindow( new JTextField( "NORTH" ), BorderLayout.NORTH );
		
		JTree t = null;
		
		pane.addInnerWindow( new InnerWindowProperties( "T2", "Tree 2", t = new JTree() ), BorderLayout.EAST );

		// We set an initial size as sample
		
		t.setPreferredSize( new Dimension( 200, 50 ) );
		
		
		JFrame frame = new JFrame();
		frame.getContentPane().add( pane.getView() );
		frame.setSize( 600, 500 );
		frame.setVisible( true );

	}
	
}
