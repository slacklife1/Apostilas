package demo;

import java.awt.*;
import javax.swing.*;

import com.japisoft.framework.dockable.JDock;


/**
 * Here a sample of usage of the GridBagLayout without 
 * inner frames. The user can resize the inner part.
 * @author (c) JAPISoft 
 *  */
public class SimpleGridBagLayout extends JFrame {
	  JScrollPane spTree = new JScrollPane();
	  JScrollPane spList = new JScrollPane();
	  JScrollPane spList2 = new JScrollPane();
	  JList downList = new JList();
	  JScrollPane spText = new JScrollPane();
	  JTextArea textArea = new JTextArea();
	  GridBagLayout gridBagLayout1 = new GridBagLayout();
	  JTree tree = new JTree();
	  JList listRightDown = new JList();
	  JList listRightTop = new JList();

	  public SimpleGridBagLayout() {
	  	initUI();
	  }
	  
	  private void initUI() {
	  	
	  	JDock dock = new JDock();

	    dock.setLayout(gridBagLayout1);
	    textArea.setText("jTextArea1");
	    dock.add(spTree,  new GridBagConstraints(0, 0, 1, 2, 1.0, 1.0
	            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(2, 4, 0, 0), 138, 364));
	    dock.add(spList,  new GridBagConstraints(2, 0, 1, 1, 1.0, 1.0
	            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(2, 0, 0, 3), 116, 240));
	    dock.add(spList2,  new GridBagConstraints(2, 1, 1, 1, 1.0, 1.0
	            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 3), 116, 118));
	    dock.add(downList,  new GridBagConstraints(0, 2, 3, 1, 1.0, 1.0
	            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 4, 5, 3), 527, 114));
	    dock.add(spText,  new GridBagConstraints(1, 0, 1, 2, 1.0, 1.0
	            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(2, 0, 0, 0), 184, 346));
	    spText.getViewport().add(textArea, null);
	    spTree.getViewport().add(tree, null);
	    spList2.getViewport().add(listRightDown, null);
	    spList.getViewport().add(listRightTop, null);
	    
	    getContentPane().add( dock.getView() );
	  }

	  public static void main( String[] args ) {
	    SimpleGridBagLayout frame = new SimpleGridBagLayout();
	    frame.setBounds( 0, 0, 600, 500 );
	    frame.setVisible( true );
	  }
	}
