package demo;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;

import com.japisoft.framework.dockable.JDock;

/**
 * Here a simple demo with component without inner frame. The user
 * can only resize each part.
 * @author (c) 2004 JAPISoft
 */
public class SimpleBorderLayout {

	public static void main( String[] args ) {

		// Main panel 
		JDock pane = new JDock();

		// The default layout is already a borderLayout
		// pane.setLayout( new BorderLayout() );
		
		pane.addInnerWindow( new JScrollPane( new JTree() ), BorderLayout.WEST );
		pane.addInnerWindow( new JTextArea(), BorderLayout.CENTER );
		pane.addInnerWindow( new JTextField( "SOUTH" ), BorderLayout.SOUTH );
		
		JTextField tf;
		
		pane.addInnerWindow( tf = new JTextField( "NORTH" ), BorderLayout.NORTH );
		
		// We define as sample an initial size
		tf.setPreferredSize( new Dimension( 100, 50 ) );
		
		pane.addInnerWindow( new JScrollPane( new JTree() ), BorderLayout.EAST );
		
		JFrame frame = new JFrame();
		frame.getContentPane().add( pane.getView() );
		frame.setSize( 600, 500 );
		frame.setVisible( true );

	}
	
}
