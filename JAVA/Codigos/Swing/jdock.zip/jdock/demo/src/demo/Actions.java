package demo;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.text.JTextComponent;

import com.japisoft.framework.dockable.InnerWindowProperties;
import com.japisoft.framework.dockable.JDock;
import com.japisoft.framework.dockable.JDockEvent;
import com.japisoft.framework.dockable.JDockListener;
import com.japisoft.framework.dockable.action.ActionModel;
import com.japisoft.framework.dockable.action.BasicActionModel;
import com.japisoft.framework.dockable.action.CommonActionManager;
import com.japisoft.framework.dockable.action.common.ExtractAction;
import com.japisoft.framework.dockable.action.common.MaxMinAction;

/**
 * This is a demo showing inner windows with custom actions for the header.
 * @author (c) 2004 JAPISoft
 */
public class Actions {

	public static void main( String[] args ) {

		// We add everywhere the Extract action
		
		CommonActionManager.addCommonAction( ExtractAction.class );
		
		// We remove everywhere the maximize/minimize action

		CommonActionManager.removeCommonAction( MaxMinAction.class );
		
		// Main panel 
		JDock pane = new JDock();

		// Action for removing the default shadow
		// pane.setShadowMode( false );

		// The default JDock layout is a BorderLayout

		JTextArea textArea = new JTextArea();
		
		Action[] actions = 
			new Action[] {
				new CopyAction( textArea ),
				new CutAction( textArea ),
				ActionModel.SEPARATOR,		// Here a separator
				new PasteAction( textArea ),
				ActionModel.SEPARATOR,	// Here another one
				new ExtractAction()	// This is a default action
		};

		JScrollPane sp = null;

		pane.addInnerWindow( 
				new InnerWindowProperties(
						"T1", "Tree", sp = new JScrollPane( new JTree() ) ),		
				BorderLayout.WEST );

		// We give a preferred size for this tree

		sp.setPreferredSize( new Dimension( 150, 100 ) );
		
		Icon icon1 = new ImageIcon( Actions.class.getResource( "Copy16.gif" ) );
		
		pane.addInnerWindow( 
				new InnerWindowProperties(
						"TA", "Text Area", icon1, new BasicActionModel( actions ), textArea ), BorderLayout.CENTER );

		JTextField tf = new JTextField( "SOUTH" );
		tf.setPreferredSize( new Dimension( 100, 150 ) );
		
		pane.addInnerWindow( 
				new InnerWindowProperties(
				"TE1", "Text1", tf ), BorderLayout.SOUTH );

		pane.setInnerWindowIconForId( "TE1", pane.getInnerWindowIconForId( "TA" ) );
				
		pane.addInnerWindow( 
				new InnerWindowProperties(
						"TE2", "Text2", new JTextField( "NORTH" ) ), BorderLayout.NORTH );
		
		// We want no title for this inner window
		
		pane.addInnerWindow( 
				new InnerWindowProperties(
						"T2", null, new JScrollPane( new JTree() ) ), BorderLayout.EAST );

		// We remove the extract action from the T1 inner frame and the TE1 inner frame 

		ActionModel model1 = pane.getInnerWindowActionsForId( "T1" );
		Action a1 = model1.getActionByClass( ExtractAction.class );
		model1.removeAction( a1 );

		ActionModel model2 = pane.getInnerWindowActionsForId( "TE1" );
		Action a2 = model2.getActionByClass( ExtractAction.class );
		model2.removeAction( a2 );

		//		pane.setEnabledStatusBar( true );
		
		// We show the jdock content
		
		JFrame frame = new JFrame();
		frame.getContentPane().add( pane.getView() );
		frame.setSize( 600, 500 );
		frame.setVisible( true );

	}

	// Sample of actions
	
	// Copy the text selection
	
	static class CopyAction extends AbstractAction {
		
		private JTextComponent text;

		public CopyAction( JTextComponent text ) {
			this.text = text;
			putValue( Action.SHORT_DESCRIPTION, "Copy action" );
			putValue( Action.SMALL_ICON, new ImageIcon( getClass().getResource( "Copy16.gif" ) ) );
		}
		public void actionPerformed( ActionEvent e ) {
			text.copy();
		}
	}

	// Cut the text selection
	
	static class CutAction extends AbstractAction {
		
		private JTextComponent text;

		public CutAction( JTextComponent text ) {
			this.text = text;
			putValue( Action.SHORT_DESCRIPTION, "Cut the selection" );
			putValue( Action.SMALL_ICON, new ImageIcon( getClass().getResource( "Cut16.gif" ) ) );
		}
		public void actionPerformed( ActionEvent e ) {
			text.cut();
		}
	}

	// Paste the text selection
	
	static class PasteAction extends AbstractAction {
		
		private JTextComponent text;

		public PasteAction( JTextComponent text ) {
			this.text = text;
			putValue( Action.SHORT_DESCRIPTION, "Paste the clipboard" );
			putValue( Action.SMALL_ICON, new ImageIcon( getClass().getResource( "Paste16.gif" ) ) );
		}
		public void actionPerformed( ActionEvent e ) {
			text.paste();
		}
	}
		

}
