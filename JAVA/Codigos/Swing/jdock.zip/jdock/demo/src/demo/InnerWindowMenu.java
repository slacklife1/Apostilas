package demo;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;

import com.japisoft.framework.dockable.InnerWindowProperties;
import com.japisoft.framework.dockable.JDock;
import com.japisoft.framework.dockable.JDockEvent;
import com.japisoft.framework.dockable.JDockListener;
import com.japisoft.framework.dockable.State;

/**
 * Here a sample with a menu for hiding or showing an inner window. Note that
 * when removing / adding a component the components size depends on your layout. In
 * this sample this is a borderLayout.
 * @author (c) 2004 JAPISoft / http://www.japisoft.com
 * @version 1.0
 * */
public class InnerWindowMenu {

	public static void main( String[] args ) {
		
		// Main panel 
		final JDock pane = new JDock();

		// Set a status bar with hidden/shown inner windows
		
		pane.setEnabledStatusBar( true );
		
		pane.addInnerWindow( new InnerWindowProperties( 
				"T1", "Tree", new JScrollPane( new JTree() ) ), BorderLayout.WEST );
		pane.addInnerWindow( 
				new InnerWindowProperties( 
						"TA", "Text Area", new JTextArea() ), BorderLayout.CENTER );
		pane.addInnerWindow( new InnerWindowProperties( 
				"Text", "Text field", new JTextField( "SOUTH" ) ), BorderLayout.SOUTH );
		
		JTextField tf = new JTextField( "NORTH" );
		
		// We force an initial dimension
		
		tf.setPreferredSize( new Dimension( 100, 50 ) );
		
		// Here a name for managing this component, this is the id for the anonymous window
		tf.setName( "anonymous" );

		pane.addInnerWindow( tf, BorderLayout.NORTH );
		pane.addInnerWindow( new InnerWindowProperties( "T2", "Tree 2", new JScrollPane( new JTree() ) ), BorderLayout.EAST );

		JFrame frame = new JFrame();
		frame.getContentPane().add( pane.getView() );
		frame.setSize( 600, 500 );
		
		JMenuBar bar = new JMenuBar();
		
		// Menu for hidding / showing an inner window
		
		JMenu menu = new JMenu( "Hide/Show" );
		bar.add( menu );

		// Menu sample for destroying an inner window
		// Destroy means the inner window can't be used after
		
		JMenu menu2 = new JMenu( "Destroy" );
		JMenuItem item1 = menu2.add( new AbstractAction() {
			public void actionPerformed( ActionEvent e ) {
				pane.removeInnerWindow( "T1" );
			}
		});
		item1.setText( "T1" );
		bar.add( menu2 );

		// Menu sample for selecting an inner window

		JMenu menu4 = new JMenu( "Select" );
		item1 = menu4.add( new AbstractAction() {
			public void actionPerformed( ActionEvent e ) {
				pane.selectInnerWindow( "T2" );
			}
		});
		item1.setText( "Tree 2" );
		item1 = menu4.add( new AbstractAction() {
			public void actionPerformed( ActionEvent e ) {
				pane.selectInnerWindow( "TA" );
			}
		});
		item1.setText( "Text Area" );
		item1 = menu4.add( new AbstractAction() {
			public void actionPerformed( ActionEvent e ) {
				pane.selectInnerWindow( "anonymous" );
			}
		});
		item1.setText( "Anonymous textfield" );

		bar.add( menu4 );

		// Menu sample for maximizing

		JMenu menu5 = new JMenu( "Maximize/Restore" );
		item1 = menu5.add( new AbstractAction() {
			public void actionPerformed( ActionEvent e ) {
				pane.maximizedRestoredInnerWindow( "TA" );
			}
		});
		item1.setText( "Text Area" );
		item1 = menu5.add( new AbstractAction() {
			public void actionPerformed( ActionEvent e ) {
				pane.maximizedRestoredInnerWindow( "anonymous" );
			}
		});
		item1.setText( "Anonymous textfield" );

		bar.add( menu5 );

		// Menu sample for extracting an inner window content

		JMenu menu6 = new JMenu( "Extractor" );
		item1 = menu6.add( new AbstractAction() {
			public void actionPerformed( ActionEvent e ) {
				pane.extractInnerWindow( "TA" );
			}
		});
		item1.setText( "Text Area" );
		
		bar.add( menu6 );

		// Menu sample for showing a shadow when resizing or moving an inner window

		JMenu menu7 = new JMenu( "Shadow" );
		item1 = menu7.add( new AbstractAction() {
			public void actionPerformed( ActionEvent e ) {
				if ( pane.isEnabledResizeShasow() )
					pane.setEnabledResizeShadow( false );
				else
					pane.setEnabledResizeShadow( true );
			}
		});
		item1.setText( "Resize" );

		item1 = menu7.add( new AbstractAction() {
			public void actionPerformed( ActionEvent e ) {
				if ( pane.isEnabledDraggingShasow() )
					pane.setEnabledDraggingShadow( false );
				else
					pane.setEnabledDraggingShadow( true );
			}
		});
		item1.setText( "Dragging" );
		
		bar.add( menu7 );
		
		JMenu menu8 = new JMenu( "State" );

		// Menu for saving a state
		
		item1 = menu8.add( new AbstractAction() {
			public void actionPerformed( ActionEvent e ) {
				state = pane.getState();
			}
		});
		item1.setText( "Save" );

		// Menu for restoring a state
		
		item1 = menu8.add( new AbstractAction() {
			public void actionPerformed( ActionEvent e ) {
				if ( state != null )
					pane.setState( state );
			}
		});
		item1.setText( "Restore" );
		
		bar.add( menu8 );

		// Menu for fixing an inner window
		
		JMenu menu9 = new JMenu( "Fixed/Unfixed" );
		item1 = menu9.add( new AbstractAction() {
			public void actionPerformed( ActionEvent e ) {
				if ( pane.isInnerWindowFixed( "TA" ) )
					pane.setInnerWindowFixed( "TA", false );
				else
					pane.setInnerWindowFixed( "TA", true );
			}			
		} );
		item1.setText( "Text area" );
		
		bar.add( menu9 );
		
		// Menu for disposing the JDock panel and terminating this
		// application
		
		JMenu menu3 = new JMenu( "Exit" );
		item1 = menu3.add( new AbstractAction() {
			public void actionPerformed( ActionEvent e ) {
				pane.dispose();
				System.exit( 0 );
			}
		});
		item1.setText( "JDock" );
		bar.add( menu3 );

		frame.setJMenuBar( bar );
		
		// Here the way for having the menu managed by JDock;
		pane.setMenuWindow( menu );

		// We add a listener as a sample
		
		pane.addJDockListener( new TestJDockListener() );
		
		frame.setVisible( true );
	}

	static State state;
	
	// Listener about the user action
	
	static class TestJDockListener implements JDockListener {

		public void jdockAction(JDockEvent event) {
			System.out.println( event.toString() );
		}

	}

}
