package ss.widgets;

import java.util.Observer;
import java.util.Observable;

/**
A simple extension of numberfiels.
The Observable should call notifyObservers(Object value ) were value is a Number Class Object
(except Character, Short, and Byte which are not suported by the NumberField )
*/
public class NumberValueMonitorField
	extends NumberField implements Observer
{
/**
@param arg a BigDecimal, BigInteger, Double, Float, Long or Integer reflecting the value of the Observable
*/
	public void update (Observable o, Object arg)
	{	this.setText (arg.toString ());	}
}
