package ss.widgets;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Observer;
import java.util.Observable;

/**
	A demonstration of Observable / Observer interface pair.
	@see ss.widgets.Widget
	@see ss.widgets.NumberValueMonitorField
*/
public class TestObservable
	extends Observable
{

	private int value;
	// private Integer Value; /// no need.

/**
 	does nothing if value==val
 	 else if the value changed sets value
 	 and notifies observers by calling notifyObservers(new Integer(value))
 	 a NumberValueMonitorField can be the observer and it will write the Integer value.
 */
	public void setValue(int val)
	{
		if(value!=val)
		{
			value=val;
			setChanged ();
			notifyObservers(new Integer(value));
		}
	}

	public int getValue()
	{	return value ;	}


}
