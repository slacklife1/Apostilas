package ss.widgets;


import java.io.*;
import java.util.*;
import java.awt.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.text.html.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Observer;
import java.util.Observable;
import java.awt.event.MouseListener;
import java.util.EventListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

public class NumberField
	extends JTextField
{
	public NumberField()
	{
		super();
		super.setDocument (new NumberDoc());
	}
	BigDecimal bd;

	public BigDecimal getBigDecimalValue()
	{
		String text=getText();
		if(text.length ()==0 ||text.equals ("-") )return null;
		if(bd==null) bd= new BigDecimal(text);
		return bd;
	}

	int valueType;
	public static final int
		type_BigDecimal=1,
		type_BigInteger=2,
		type_Double =3,
		type_Float=4,
		type_Long=5,
		type_Integer=6,
		type_Unknkown=0,
		type_Unsupported=-1;
		//  maxtype = type_Integer;

	public void setType(int i)
	{
		if(i<-1 ||i>type_Integer)i=-1;
		valueType=i;
	}

	public void setType(Object value)
	{
		if(! (value instanceof Number)) throw new ClassCastException();
		if(value instanceof BigDecimal)
		{	valueType= type_BigDecimal;		}
		else if(value instanceof BigInteger)
		{	valueType= type_BigInteger;		}
		else if(value instanceof Double)
		{	valueType= type_Double;		}
		else if(value instanceof Integer)
		{	valueType= type_Integer;		}
		else if(value instanceof Long)
		{	valueType= type_Long;		}
		else if(value instanceof Float)
		{	valueType= type_Float;	}
		setText(value.toString ());
	}

	public void setValue(Object value)
	{
		setType(value);
		setText(value.toString ());
	}

	public Object getValue()
	{
		Object obj=null;
		{
			String txt = getText();
			if(txt==null||txt.length()<1 || (txt.length ()==1 &&(txt.charAt (0)=='-'||txt.charAt (0)=='.' )))return null;
			switch (valueType)
		    {
		    	case type_BigInteger:
		    		obj= new BigInteger(txt);
		    	break;	case type_Double:
					obj= new Double(txt);
		    	break;	case type_Float:
		    		obj= new Float(txt);
		    	break;	case type_Integer:
		    		obj= new Integer(txt);
		    	break;	case type_Long:
		    		obj= new Long(txt);
		    	break;
			    	case type_BigDecimal:
			    	case type_Unsupported:
			    	case type_Unknkown:
		    	default :
		    		obj= new BigDecimal(getText());
		    }
		}
		return obj;
	}

}
