package ss.widgets;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.text.html.*;
import java.awt.event.*;
import java.util.Observer;
import java.util.Observable;

/**
 * a simple counter that increments the BigInteger current by inc
 * notifyObservers(current) is called after each increment (better to set an update inteval especially if the delay is too small)
 * and before thread termination
*/

public class TestCounter
	extends Observable
	implements Runnable
{

	BigInteger max= new BigInteger("9999999999"), current = new BigInteger("0");
	BigInteger inc = new BigInteger("1");
	int updateDelay = 1000;
	int delay =1000;

	void TestCounter()
	{	}

	public void increment()
	{
		current=current.add(inc);
		setChanged ();
	}

	public void reset()
	{	current= new BigInteger("0");	}

	Thread counter;
	public void start()
	{
		yield=false;
		if(counter ==null || !counter.isAlive ())
		{
			counter = new Thread(this,"counter");
			counter.start ();
		}
	}

	/**
	 kills counter with a rude interupt;
	*/
	public void stop()
	{
		yield=false;
		if(counter!=null &&counter.isAlive ())
		try
	    {   counter.interrupt ();   }
	    catch (Exception ex) {}
	    reset();
	}

	/**
	 suspends counting, but does not stopr the loo0p.
	 It would be better to exit the loop, and restart without resetting.
	*/
	public void pause()
	{	yield=true; 		}

	private boolean yield;

/**
 	counts contuously forever until current==max

 */
	public void run()
	{
		int x=0;
		while(true)
		{
			x=0;
			while(yield || x==0 )
			{
				try
			    {
			    	x++;
			    	counter.sleep (delay);
			    }
			    catch (InterruptedException ex) {}
		  	}
		    increment();
			this.notifyObservers (current);
			if(current.compareTo (max) >=0) break;
		}
		notifyObservers(max);
	}
}
