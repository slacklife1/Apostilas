package ss.widgets;

import java.util.*;
import java.awt.*;
import java.math.BigDecimal ;
import java.math.BigInteger;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.text.html.*;

/*
 * @(#)Widgets.java 1.0 03/08/21
 * Application Project
 *
 	A silly JFrame to test NumberFields, and NumberValueMonitorFields.
	mouse clicks and mouse drags are registered int two NumberFields
	and a counter is updated

The first NumberField is a direct input demo.
The JComboBox selector determines the type of Number which is returned when getValue() is called
If there is an exception casting the value, the next Highest type is called.
(this is determined in the actionPerformed() method.)
ie if the type is Inyeger, and a decimal is inserted, then type is decremented, and a Long is attempted,
hovever Long will throw an exception at the offending decimal separator, and the NumberField type will be changed to Float.
If Float can not handle the value, Double, BigInteger, and finally the default BigDecimal will be tried.
and string of umbers entered into a NumberField should produce a valid BigDecimal as the NumberField s self correcting

The start button starts the timer, (and becomes a pause button.)
The pause button pauses the counting (timer still runs in early versions)

Mouse drags and mouse clicks are entered in the NumberFields.

the last JTextField is a status field.
will accept commands (eventually)

 */

import java.awt.*;
import java.awt.event.*;
import java.util.Observer;
import java.util.Observable;
import java.awt.event.MouseListener;
import java.util.EventListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;


public class Widgets
	extends JFrame
	implements ActionListener, MouseListener, MouseMotionListener
{

	Object [] numbertypes =
	{
		"Unknown",
		"BigDecimal",
		"BigInteger",
		"Double",
		"Float",
		"Long",
		"Integer"
	};

	JPanel mousePan = new JPanel();
	JPanel npan = new JPanel();

	NumberValueMonitorField
		nf_mx = new NumberValueMonitorField(),
		nf_my = new NumberValueMonitorField();
	TestObservable
		omx = new TestObservable(),
		omy= new TestObservable();


	JTextField status = new JTextField();
	NumberField nf = new NumberField();
	JComboBox typebox = new JComboBox(numbertypes);


	JPanel counterPanel = new JPanel();
	JButton b_start = new JButton("Start");
	NumberValueMonitorField nf_counter = new NumberValueMonitorField();
	TestCounter counter = new TestCounter();


	public Widgets()
	{
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				dispose();
				System.exit(0);
			}
		});

		addMouseMotionListener(this);
		addMouseListener (this);

		Component[] components = this.getComponents ();
		for(int n=0; n<components.length; n++)
		{
			components[n].addMouseMotionListener (this);
			components[n].addMouseListener (this);
		}

		nf_mx.setColumns(5);
		nf_my.setColumns(5);

		counter.addObserver (nf_counter);
		b_start.addActionListener (this);
		b_start.setSelected (true);

		mousePan.add(nf_mx);
		mousePan.add(nf_my);

		omx.addObserver (nf_mx);
		omy.addObserver (nf_my);

		nf.addActionListener (this);
		nf.setColumns(24);
		npan.setLayout (new BorderLayout());

		npan.add(nf,"North");
		npan.add(typebox,"Center");

		nf_counter.setColumns (counter.max.toString ().length()+1);
		counterPanel.add(b_start);
		counterPanel.add(nf_counter);
		npan.add(counterPanel,"South");

		typebox.setSelectedIndex (0);
		typebox.setMaximumRowCount (7);

		getContentPane().add(npan,"North");
		getContentPane().add(mousePan,"Center");
		getContentPane().add(status,"South");
		pack();
		setBackground(Color.blue);
		setForeground(Color.green);

		setVisible(true);
	}





	String [] selectedText ={"Start","Pause"};

	int type;
	public void actionPerformed (ActionEvent e)
    {
    	// say(nf.getValue ().getClass ().getName ()+"="+nf.getValue ());
    	if(e.getSource ().equals (nf))
    	{
	    	if(typebox.getSelectedIndex ()!=type)
	    	{
	    		type= typebox.getSelectedIndex ();
	    		nf.setType (type);
	    	}
	    	Object val =null;

	    	try
		    {  	val = nf.getValue ();     }
		    catch (NumberFormatException ex)
		    {
		    	if(type<1)
		    	{
		    		status.setText("Exception " +ex.getClass().getName ());
		    	}
				else
		    	{
		    		status.setText("auto casting ");
		    		typebox.setSelectedIndex (--type);
		    		nf.setType (type);
		    		actionPerformed(e);
		    	}
		    	return;
		    }
			status.setText ("Type=("+type+") "+val.getClass ().getName ()+", value="+val.toString () );
		}
		else if(e.getSource ().equals (b_start))
		{
			boolean sel = b_start.isSelected ();
			if(sel){counter.start ();} else counter.pause ();
			b_start.setSelected(!sel);
			int i = b_start.isSelected ()? 0:1;
			b_start.setText(selectedText[i]);

		}

    }



	void say(String S)
    {System.out.println(S);}

	public static void main(String args[])
	{

		System.out.println("Starting Widgets...");
		Widgets mainFrame = new Widgets();
		// mainFrame.setSize(400, 400);
		mainFrame.setTitle("Widgets Demo");
		mainFrame.setVisible(true);
	}

	public void mouseClicked (MouseEvent e)
	{
		omx.setValue ( e.getX ());
		omy.setValue ( e.getY ());
	}

	public void mousePressed (MouseEvent e)
	{	}

	public void mouseReleased (MouseEvent e)
	{}

	public void mouseEntered (MouseEvent e)
	{}

	public void mouseExited (MouseEvent e)
	{		}

	public void mouseDragged (MouseEvent e)
	{
		omx.setValue ( e.getX ());
		omy.setValue ( e.getY ());
	}
	public void mouseMoved (MouseEvent e)
	{	}
}









