package ss.widgets;

import java.io.*;
import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import javax.swing.text.*;
import java.text.*;

/**
 *
 	A simple Document that acceprs only numbers and the two necessary symbols, "." and "-"
 	but the minus sign must be the first character and . must appear only once.
 	User's Local symbols for decimal separator and minus sign are used.
*/

public class NumberDoc
	extends PlainDocument
{
	DecimalFormat nform = (DecimalFormat) NumberFormat.getInstance ();
	char cdot= nform.getDecimalFormatSymbols ().getDecimalSeparator ();
	char cmin= nform.getDecimalFormatSymbols ().getMinusSign ();
	String sdot= new String( (new char[]{cdot}));
	String smin= new String((new char[]{cmin}));

	boolean isinteger =true;
	private int base=10;
	public void setBase(int base)
	{}

	int getBase()
	{ return base; }

	public void insertString (int off, String s, AttributeSet a)
		throws BadLocationException
	{
		// char cc[] = s.toCharArray ();
		StringBuffer sb = new StringBuffer(s);
		for(int n=sb.length ()-1; n>=0; n-- )
		{
			char c= sb.charAt (n);
			if(! (Character.isDigit (c) || c==cmin||c==cdot) )	sb.deleteCharAt (n);
		}
		int m=0;
		while ((m=sb.indexOf (smin))>0) sb.deleteCharAt (m);
		int d= sb.indexOf (sdot);
		while ((m=sb.lastIndexOf (sdot))!=d ) sb.deleteCharAt (m);
		super.insertString (off,sb.toString (), a);
	}
}
