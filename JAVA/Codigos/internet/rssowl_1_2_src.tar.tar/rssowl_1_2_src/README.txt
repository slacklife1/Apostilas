/*   **********************************************************************  **
 **   Copyright notice                                                       **
 **                                                                          **
 **   (c) 2003-2005 RSSOwl Development Team                                  **
 **   http://www.rssowl.org/                                                 **
 **                                                                          **
 **   All rights reserved                                                    **
 **                                                                          **
 **   This program and the accompanying materials are made available under   **
 **   the terms of the Common Public License v1.0 which accompanies this     **
 **   distribution, and is available at:                                     **
 **   http://www.rssowl.org/legal/cpl-v10.html                               **
 **                                                                          **
 **   A copy is found in the file cpl-v10.html and important notices to the  **
 **   license from the team is found in the textfile LICENSE.txt distributed **
 **   in this package.                                                       **
 **                                                                          **
 **   This copyright notice MUST APPEAR in all copies of the file!           **
 **                                                                          **
 **   Contributors:                                                          **
 **     RSSOwl - initial API and implementation (bpasero@rssowl.org)         **
 **                                                                          **
 **  **********************************************************************  */

RSSOwl Version 1.2 Source Release
---------------------------------

	Welcome to the source release of RSSOwl - RSS / RDF / Atom newsreader.
	To compile RSSOwl's sourcecode you will need the Java SDK 1.4+. Download
	it from java.sun.com if neccessary.
	
	Follow this step by step instruction on howto compile RSSOwl:
	
	1.) Unzip RSSOwl's sourcecode
	
		Use your favorite Zip-Tool to unzip RSSOwl' sourcecode. Let's place
		all files into a directory called "rssowl".
	
	
	2.) Download SWT - Standard Widget Toolkit
	
		To compile RSSOwl from source, you need to download the SWT library for 
		your operating system. Currently supported are:
	
		Windows 98/ME/2000/XP
	
			http://download.eclipse.org/eclipse/downloads/drops/S-3.2M3-200511021600/download.php?dropFile=swt-3.2M3-win32-win32-x86.zip
	
		Linux (x86/GTK 2)
	
			http://download.eclipse.org/eclipse/downloads/drops/S-3.2M3-200511021600/download.php?dropFile=swt-3.2M3-gtk-linux-x86.zip
			
		Linux (x86_64/GTK 2)
	
			http://download.eclipse.org/eclipse/downloads/drops/S-3.2M3-200511021600/download.php?dropFile=swt-3.2M3-gtk-linux-x86_64.zip
	
		Mac OSX (Mac/Carbon)
	
			http://download.eclipse.org/eclipse/downloads/drops/S-3.2M3-200511021600/download.php?dropFile=swt-3.2M3-carbon-macosx-ppc.zip
	
		Solaris 8 (SPARC/GTK 2)
	
			http://download.eclipse.org/eclipse/downloads/drops/S-3.2M3-200511021600/download.php?dropFile=swt-3.2M3-gtk-solaris-sparc.zip

		Other Operating Systems
		
			RSSOwl is supporting a lot more operating systems. For example Linux 64 Bit, Solaris Motif, AIX and HP-UX. In order to compile
			to these operating systems, download the correct SWT version and follow the steps below. Make sure to change the build.xml ANT
			script to reflect the binary libraries included in the SWT archive.

		Note: In case Eclipse is no longer offering this version of SWT anymore, it is always safe to download the 
		      latest "Integration Build" or "Milestone" of SWT. Therefor open http://download.eclipse.org/eclipse/downloads/index.php
		      and find "Stream Integration Build" or "Stream Stable Build", click the link and download the SWT version
		      for your OS on bottom of the page (labeled "SWT Binary and Source").
	
	3.) Place *.jar into "lib/"
	
		After you have unzipped RSSOwl's sourcecode, you should find a directory
		called "lib/" containing some JAR files. Place all .jar files from the 
		downloaded SWT into there. 
	
	
	4.) Place native SWT libraries into "rssowl"
	
		There are now some files left from the swt archive, which are the native libraries
		for SWT. Their fileending is .dll for Windows, .so on Linux / Solaris and .jnilib on Mac. 
		Place those files in your "rssowl" directory.
		
	
	5.) Compile the sourcecode
	
		There are two ways to compile RSSOwl. The simple one is using Apache ANT with the
		"build.xml" that you will find in the "src" folder. ANT is opensource and available
		at "http://ant.apache.org". From the "src"-directory simply run the "deploy" target
		for your operating system. For example, if you want to compile RSSOwl Linux, type
		"ant deploy_linux" (other targets are deploy_win, deploy_mac and deploy_solaris).
		
		Please note that for some targets you should have a look into the "build.xml" and
		change some pathes. It might also be neccessary to change the property "swt_version"
		to the value matching the SWT version you are using.
		
		If you are not familiar with ANT, you may also compile the sourcecode from the console 
		using javac. Make sure to have all libraries from the "lib"-directory on your classpath.
		Also make sure to use UTF-8 as encoding for javac, because all sources are UTF-8 encoded.
	
	
	6.) Execute RSSOwl
	
		Call "java -jar -Djava.library.path=. rssowl.jar" from the console while being in the
		directory "rssowl", which is the same directory where the "rssowl.jar" is in.
		
		With "-Djava.library.path=." we are telling Java to use the current directory as
		the Java Library Path. It is very important that the native SWT files are located
		in that directory, otherwise an "Unsatisfied Link Error" will show up. Because the
		native SWT files are located in the same directory where "rssowl.jar" is in (see
		step 4), it will work with "." as path.
		
		Note on Mac: If you are running RSSOwl without using the application bundle on Mac, it 
		             is very important to pass "-XstartOnFirstThread" as argument to executing Java call.
	
	
	7.) Any Problems?
	
		Feel free to ask your question in our forum: http://sourceforge.net/forum/?group_id=86683
		or join the IRC at #rssowl in irc.freenode.net

Visit us at
	http://www.rssowl.org


System Requirements
-------------------

Java 2 Runtime Environment 1.4.x or higher

CREDITS:
--------

RSSOwl development team:

	Benjamin Pasero 						(Developer / Project Admin and Manager)
	Garry Forbes 								(Doc Writer / Tutorial)
	Christophe Dumez Translator (I18N)	
	Geon Goo 										(I18N)
	Marcelo B.									(I18N)
	Merlin Ran 									(I18N)
	Tobias Eichert 							(Web Designer)
	Kay Patzwald								(Packager)
	Dane W. Smith               (Promoter)

Special thanks to:

	Jesse Ross		 								(RSSOwl Artwork)
	Tonny Bredsgaard 							(I18N)
	Jose Dominguez 								(I18N)
	Claudio Fontana 							(I18N)
	Joris Kluivers 								(I18N)
	Jacaranda Bill 								(I18N)
	Sergey Rozenblat 							(I18N)
	Ruben						 							(I18N)
	Marcelo Fenoll Ramal Tradutor (I18N)
	Valeri Damianov 							(I18N)
	Eivind Syverts 								(I18N)
	Takashi Komatsubara 					(I18N)
  Ryszard Sierotnik 						(I18N)
  Omi Azad 											(I18N)
  Patrik Johansson 							(I18N)
  Jerry Giant										(I18N)
	Samu Reinikainen							(I18N)
	Alexandr											(I18N)
	Lukas Petrovicky							(I18N)
	Jure Zemljič									(I18N)
	Engin Erenturk								(I18N)
	Toon Geens										(I18N)
	Alan Cheng										(I18N)
	Balázs												(I18N)
	Patipat Susumpow							(I18N)
	Aleksandar Urošević           (I18N)
  Konstantin Zadorozhny					(Very Good Ideas)
  John Tey
  Mark Woodman

Make a donation:
----------------
RSSOwl is free software and you may use it without paying for it.
If you like the tool, and want to contribute, a donation is possible
via paypal, following this URL:
http://sourceforge.net/donate/index.php?group_id=86683

Thanks!