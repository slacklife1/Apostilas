/*   **********************************************************************  **
 **   Copyright notice                                                       **
 **                                                                          **
 **   (c) 2003-2005 RSSOwl Development Team                                  **
 **   http://www.rssowl.org/                                                 **
 **                                                                          **
 **   All rights reserved                                                    **
 **                                                                          **
 **   This program and the accompanying materials are made available under   **
 **   the terms of the Common Public License v1.0 which accompanies this     **
 **   distribution, and is available at:                                     **
 **   http://www.rssowl.org/legal/cpl-v10.html                               **
 **                                                                          **
 **   A copy is found in the file cpl-v10.html and important notices to the  **
 **   license from the team is found in the textfile LICENSE.txt distributed **
 **   in this package.                                                       **
 **                                                                          **
 **   This copyright notice MUST APPEAR in all copies of the file!           **
 **                                                                          **
 **   Contributors:                                                          **
 **     RSSOwl - initial API and implementation (bpasero@rssowl.org)         **
 **                                                                          **
 **  **********************************************************************  */

package net.sourceforge.rssowl.controller.thread;

import net.sourceforge.rssowl.controller.GUI;
import net.sourceforge.rssowl.controller.dialog.ValidateFeedDialog;
import net.sourceforge.rssowl.dao.NewsfeedFactoryException;
import net.sourceforge.rssowl.dao.feedparser.FeedParser;
import net.sourceforge.rssowl.util.GlobalSettings;
import net.sourceforge.rssowl.util.shop.XMLShop;

import org.jdom.DocType;
import org.jdom.Document;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXParseException;

import java.io.File;
import java.io.IOException;

/**
 * This thread is used to validate a newsfeed and give the results to the
 * calling ValidateFeedDialog
 * 
 * @author <a href="mailto:bpasero@rssowl.org">Benjamin Pasero </a>
 * @version 1.2
 */
public class FeedValidator extends ExtendedThread {

  /** Temp name of the locally saved XML document */
  private static final String TMP_XML_NAME = "validation.tmp";

  private String feedPath;
  private String format;
  private String humanReadableFeedFormat;
  String dtdToValidate;
  boolean isWarningOrError;
  boolean overrideDTD;
  ValidateFeedDialog rssOwlValidateFeedDialog;

  /**
   * Instantiate a new FeedValidator
   * 
   * @param rssOwlValidateFeedDialog The calling validate feed dialog
   * @param feedPath The path of the feed to validate
   * @param format The feed format (may be auto-detection to let RSSOwl detect
   * it)
   * @param overrideDTD TRUE if the DTD declaration should get overriden
   */
  public FeedValidator(ValidateFeedDialog rssOwlValidateFeedDialog, String feedPath, String format, boolean overrideDTD) {
    this.feedPath = feedPath;
    this.rssOwlValidateFeedDialog = rssOwlValidateFeedDialog;
    this.format = format;
    this.overrideDTD = overrideDTD;
    setName("Feed Validator Thread");
  }

  /**
   * Download, Save and Validate given feed.
   * 
   * @see java.lang.Runnable#run()
   */
  public void run() {

    try {

      /** Download feed to append custom DTD */
      if (!isStopped())
        downloadFeed();

      /** Validate feed from disk */
      if (!isStopped())
        validateFeed();
    }

    /** Log Exceptions */
    catch (JDOMException e) {
      rssOwlValidateFeedDialog.addMessage(ValidateFeedDialog.LEVEL_ERROR, e.getLocalizedMessage(), -1);
    } catch (IOException e) {
      rssOwlValidateFeedDialog.addMessage(ValidateFeedDialog.LEVEL_ERROR, e.getLocalizedMessage(), -1);
    } catch (NewsfeedFactoryException e) {
      rssOwlValidateFeedDialog.addMessage(ValidateFeedDialog.LEVEL_ERROR, e.getReason(), -1);
    } catch (IllegalArgumentException e) {
      rssOwlValidateFeedDialog.addMessage(ValidateFeedDialog.LEVEL_ERROR, e.getLocalizedMessage(), -1);
    }

    /** Finish operation */
    if (!isStopped())
      rssOwlValidateFeedDialog.finishValidation((format.equals(GUI.i18n.getTranslation("FORMAT_AUTO_DETECT"))) ? humanReadableFeedFormat : format);
  }

  /**
   * Stop the Feed Validator
   */
  public void stopThread() {
    super.stopThread();
    interrupt();
  }

  /**
   * Auto detect the format from the given document
   * 
   * @param document The newsfeed as XMl document
   * @throws NewsfeedFactoryException If an error occurs
   */
  private void autoDetectFormat(Document document) throws NewsfeedFactoryException {
    int feedFormat = new FeedParser(document, feedPath).getFeedFormat();

    /** Supported formats for the validator are RSS 0.91, 0.92 and 2.0 */
    switch (feedFormat) {

      /** Newsfeed format is: RSS 0.91 */
      case FeedParser.FEED_FORMAT_RSS_0_91:
        dtdToValidate = "rss-0.91.dtd";
        humanReadableFeedFormat = ValidateFeedDialog.FORMAT_RSS_0_91;
        break;

      /** Newsfeed format is: RSS 0.92 */
      case FeedParser.FEED_FORMAT_RSS_0_92:
        dtdToValidate = "rss-0.92.dtd";
        humanReadableFeedFormat = ValidateFeedDialog.FORMAT_RSS_0_92;
        break;

      /** Newsfeed format is: RSS 2.0 */
      case FeedParser.FEED_FORMAT_RSS_2_0:
        dtdToValidate = "rss-2.0.dtd";
        humanReadableFeedFormat = ValidateFeedDialog.FORMAT_RSS_2_0;
        break;

      /** Default case: Use RSS 0.91 */
      default:
        dtdToValidate = "rss-0.91.dtd";
        humanReadableFeedFormat = ValidateFeedDialog.FORMAT_RSS_0_91;
    }
  }

  /**
   * Download the newsfeed to save it locally. This allows to apply a custom DTD
   * to the document. In dependance of the newsfeed format a DTD is chosen from
   * the res.jar.
   * 
   * @throws JDOMException If an error occurs
   * @throws IOException If an error occurs
   * @throws NewsfeedFactoryException If an error occurs
   * @throws IllegalArgumentException If an error occurs
   */
  private void downloadFeed() throws JDOMException, IOException, NewsfeedFactoryException, IllegalArgumentException {

    /** Parse XML document */
    Document document = XMLShop.getXMLDocument(feedPath);

    /** Handle Doctype Declaration */
    if (overrideDTD)
      setDTDToValidate(document);

    /** Save the file */
    saveFeed(document);
  }

  /**
   * Write the document to disk.
   * 
   * @param document The document to save
   */
  private void saveFeed(Document document) {
    XMLShop.writeXML(document, GlobalSettings.WORKING_DIR + GlobalSettings.PATH_SEPARATOR + TMP_XML_NAME, true);
  }

  /**
   * This method sets a null.dtd as Doctype to the document and then sets the
   * DTD that should be used to validate the XML.
   * 
   * @param document The document to validate
   * @throws NewsfeedFactoryException If an error occurs
   */
  private void setDTDToValidate(Document document) throws NewsfeedFactoryException {

    /** Currently only RSS Supported */
    String formatPrefix = "rss";

    /** User has selected RSS 0.91 */
    if (format.equals(ValidateFeedDialog.FORMAT_RSS_0_91))
      dtdToValidate = "rss-0.91.dtd";

    /** User has selected RSS 0.92 */
    else if (format.equals(ValidateFeedDialog.FORMAT_RSS_0_92))
      dtdToValidate = "rss-0.92.dtd";

    /** User has selected RSS 2.0 */
    else if (format.equals(ValidateFeedDialog.FORMAT_RSS_2_0))
      dtdToValidate = "rss-2.0.dtd";

    /** User has selected auto detection */
    else
      autoDetectFormat(document);

    /** Override possible doctype in document */
    DocType docType = new DocType(formatPrefix, XMLShop.NULL_DTD);
    document.setDocType(docType);
  }

  /**
   * Validate the newsfeed using JDom
   * 
   * @throws JDOMException If an error occurs
   * @throws IOException If an error occurs
   * @throws IllegalArgumentException If an error occurs
   */
  private void validateFeed() throws JDOMException, IOException, IllegalArgumentException {
    SAXBuilder builder = new SAXBuilder("org.apache.xerces.parsers.SAXParser", true);
    isWarningOrError = false;

    /** Use one of the supported DTDs if overrideDTD is set to TRUE */
    if (overrideDTD) {
      builder.setEntityResolver(new EntityResolver() {

        /**
         * @see org.xml.sax.EntityResolver#resolveEntity(java.lang.String,
         * java.lang.String)
         */
        public InputSource resolveEntity(String publicId, String systemId) {
          return new InputSource(getClass().getResourceAsStream("/usr/" + dtdToValidate));
        }
      });
    }

    /** Custom error handling: Write into Feed Validation Dialog */
    builder.setErrorHandler(new ErrorHandler() {

      /** XML Error */
      public void error(SAXParseException e) {
        rssOwlValidateFeedDialog.addMessage(ValidateFeedDialog.LEVEL_ERROR, e.getLocalizedMessage(), e.getLineNumber());
        isWarningOrError = true;
      }

      /** XML Fatal Error */
      public void fatalError(SAXParseException e) {
        rssOwlValidateFeedDialog.addMessage(ValidateFeedDialog.LEVEL_ERROR, e.getLocalizedMessage(), e.getLineNumber());
        isWarningOrError = true;
      }

      /** XML Warning */
      public void warning(SAXParseException e) {
        rssOwlValidateFeedDialog.addMessage(ValidateFeedDialog.LEVEL_WARNING, e.getLocalizedMessage(), e.getLineNumber());
        isWarningOrError = true;
      }
    });

    /** Validate the newsfeed */
    builder.build(new File(GlobalSettings.WORKING_DIR + GlobalSettings.PATH_SEPARATOR + TMP_XML_NAME));

    /** There was no error or warning, give out success message */
    if (!isWarningOrError)
      rssOwlValidateFeedDialog.addMessage(ValidateFeedDialog.LEVEL_OK, GUI.i18n.getTranslation("NEWSFEED_VALID") + " [" + ((humanReadableFeedFormat != null) ? humanReadableFeedFormat : format) + "]", -1);
  }
}