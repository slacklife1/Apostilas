/*   **********************************************************************  **
 **   Copyright notice                                                       **
 **                                                                          **
 **   (c) 2003-2005 RSSOwl Development Team                                  **
 **   http://www.rssowl.org/                                                 **
 **                                                                          **
 **   All rights reserved                                                    **
 **                                                                          **
 **   This program and the accompanying materials are made available under   **
 **   the terms of the Common Public License v1.0 which accompanies this     **
 **   distribution, and is available at:                                     **
 **   http://www.rssowl.org/legal/cpl-v10.html                               **
 **                                                                          **
 **   A copy is found in the file cpl-v10.html and important notices to the  **
 **   license from the team is found in the textfile LICENSE.txt distributed **
 **   in this package.                                                       **
 **                                                                          **
 **   This copyright notice MUST APPEAR in all copies of the file!           **
 **                                                                          **
 **   Contributors:                                                          **
 **     RSSOwl - initial API and implementation (bpasero@rssowl.org)         **
 **                                                                          **
 **  **********************************************************************  */

package net.sourceforge.rssowl.controller.sort;

import net.sourceforge.rssowl.model.NewsItem;

import java.util.Hashtable;

/**
 * Class used to compare two RSSNewsItems by publisher.
 * 
 * @author <a href="mailto:masterludo@gmx.net">Ludovic Kim-Xuan Galibert </a>
 * @version 1.2
 */
public class PublisherSorter extends AbstractSorter {

  /**
   * Creates a new instance of PublisherSorter.
   * 
   * @param someItems a Hashtable containing RSSNewsItems, may be null.
   */
  public PublisherSorter(Hashtable someItems) {
    super(someItems);
  }

  /**
   * Compare the given objects by publisher.
   * 
   * @param o1 the first key (news title) to retrieve the first NewsItem to
   * compare
   * @param o2 the second key (news title) to retrieve the second NewsItem to
   * compare
   * @return 0 if both RSSNewsItems have exactly the same publisher, -1 if the
   * first NewsItem's publisher is alphabetically before the second, and 1 if
   * the second NewsItem's publisher is alphabetically before the first.
   */
  public int compare(Object o1, Object o2) {
    NewsItem item1 = (NewsItem) getItems().get(o1);
    NewsItem item2 = (NewsItem) getItems().get(o2);

    String publisher1 = item1.getPublisher();
    String publisher2 = item2.getPublisher();

    int result;

    /** Compare both values */
    if (publisher1 != null && publisher2 != null) {
      result = publisher1.compareTo(publisher2);

      /** If publisher are same, order the news by next sort order item */
      if (0 == result)
        result = completeCompare(o1, o2);
    }

    /** NewsItem1 is alphabetical before NewsItem2 */
    else if (publisher1 != null) {
      result = -1;
    }

    /** NewsItem2 is alphabetical before NewsItem1 */
    else {
      result = 1;
    }

    /** Return result of compare */
    return result;
  }
}