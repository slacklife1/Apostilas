/*   **********************************************************************  **
 **   Copyright notice                                                       **
 **                                                                          **
 **   (c) 2003-2005 RSSOwl Development Team                                  **
 **   http://www.rssowl.org/                                                 **
 **                                                                          **
 **   All rights reserved                                                    **
 **                                                                          **
 **   This program and the accompanying materials are made available under   **
 **   the terms of the Common Public License v1.0 which accompanies this     **
 **   distribution, and is available at:                                     **
 **   http://www.rssowl.org/legal/cpl-v10.html                               **
 **                                                                          **
 **   A copy is found in the file cpl-v10.html and important notices to the  **
 **   license from the team is found in the textfile LICENSE.txt distributed **
 **   in this package.                                                       **
 **                                                                          **
 **   This copyright notice MUST APPEAR in all copies of the file!           **
 **                                                                          **
 **   Contributors:                                                          **
 **     RSSOwl - initial API and implementation (bpasero@rssowl.org)         **
 **                                                                          **
 **  **********************************************************************  */

package net.sourceforge.rssowl.controller.thread;

import net.sourceforge.rssowl.controller.GUI;
import net.sourceforge.rssowl.dao.SettingsSaver;

/**
 * The SettingsManager is responsible to save Settings in a certain interval.
 * Whenever Favorites, Categories or Blogrolls are added, edited or removed, the
 * SettingsManager is told to save Settings next time it checks for the
 * <code>isSaveRequested</code> flag.
 * 
 * @author <a href="mailto:bpasero@rssowl.org">Benjamin Pasero </a>
 * @version 1.2
 */
public class SettingsManager extends ExtendedThread {
  private static SettingsManager instance;
  private static final int SLEEP_INTERVAL = 1 * 60 * 1000;
  private boolean isSaveRequested;
  GUI rssOwlGui;

  /**
   * Singleton Instantiation of SettingsManager.
   * 
   * @param rssOwlGui The Main Controller.
   */
  private SettingsManager(GUI rssOwlGui) {
    this.rssOwlGui = rssOwlGui;
    setName("Settings Manager Thread");
    setDaemon(true);
  }

  /**
   * Get the single instance of the SettingsManager.
   * 
   * @return The single instance of the SettingsManager.
   */
  public static SettingsManager getInstance() {
    if (instance == null)
      instance = new SettingsManager(GUI.rssOwlGui);
    return instance;
  }

  /**
   * Request save of Settings. Next time the Manager checks for the
   * <code>isSaveRequested</code> flag, Settings will be saved.
   */
  public void requestSave() {
    isSaveRequested = true;
  }

  /**
   * @see java.lang.Runnable#run()
   */
  public void run() {

    /** Run until stopped */
    while (!isStopped() && GUI.isAlive() && !isInterrupted()) {

      /** Sleep for some time */
      try {
        sleep(SLEEP_INTERVAL);
      } catch (InterruptedException e) {
        break;
      }

      /** Save Settings in a Exception safe manner */
      if (isSaveRequested && !isStopped() && GUI.isAlive() && !isInterrupted())
        try {
          GUI.display.asyncExec(new Runnable() {
            public void run() {
              new SettingsSaver(rssOwlGui).saveUserSettings(false);
            }
          });
        } catch (Exception e) {
          GUI.logger.log("SettingsManager#run()", e);
        } finally {
          isSaveRequested = false;
        }
    }
  }

  /**
   * @see net.sourceforge.rssowl.controller.thread.ExtendedThread#stopThread()
   */
  public synchronized void stopThread() {
    super.stopThread();
    interrupt();
  }
}