/*   **********************************************************************  **
 **   Copyright notice                                                       **
 **                                                                          **
 **   (c) 2003-2005 RSSOwl Development Team                                  **
 **   http://www.rssowl.org/                                                 **
 **                                                                          **
 **   All rights reserved                                                    **
 **                                                                          **
 **   This program and the accompanying materials are made available under   **
 **   the terms of the Common Public License v1.0 which accompanies this     **
 **   distribution, and is available at:                                     **
 **   http://www.rssowl.org/legal/cpl-v10.html                               **
 **                                                                          **
 **   A copy is found in the file cpl-v10.html and important notices to the  **
 **   license from the team is found in the textfile LICENSE.txt distributed **
 **   in this package.                                                       **
 **                                                                          **
 **   This copyright notice MUST APPEAR in all copies of the file!           **
 **                                                                          **
 **   Contributors:                                                          **
 **     RSSOwl - initial API and implementation (bpasero@rssowl.org)         **
 **                                                                          **
 **  **********************************************************************  */

package net.sourceforge.rssowl.controller.dialog;

import net.sourceforge.rssowl.controller.DisposeListenerImpl;
import net.sourceforge.rssowl.controller.GUI;
import net.sourceforge.rssowl.controller.MenuManager;
import net.sourceforge.rssowl.controller.thread.FeedValidator;
import net.sourceforge.rssowl.util.GlobalSettings;
import net.sourceforge.rssowl.util.shop.FileShop;
import net.sourceforge.rssowl.util.shop.FontShop;
import net.sourceforge.rssowl.util.shop.LayoutDataShop;
import net.sourceforge.rssowl.util.shop.LayoutShop;
import net.sourceforge.rssowl.util.shop.PaintShop;
import net.sourceforge.rssowl.util.shop.StringShop;
import net.sourceforge.rssowl.util.shop.WidgetShop;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ShellAdapter;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.graphics.FontMetrics;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;

/**
 * Class displays a Dialog prompting for a URL / Path to an existing newsfeed. A
 * "validate"-button calls the RSSOwlFeedValidtor to validate the given feed.
 * Errors and warnings are given out to a table.
 * 
 * @author <a href="mailto:bpasero@rssowl.org">Benjamin Pasero </a>
 * @version 1.2
 */
public class ValidateFeedDialog {

  /** Newsfeed format: RSS 0.91 */
  public static final String FORMAT_RSS_0_91 = "RSS 0.91";

  /** Newsfeed format: RSS 0.92 */
  public static final String FORMAT_RSS_0_92 = "RSS 0.92";

  /** Newsfeed format: RSS 2.0 */
  public static final String FORMAT_RSS_2_0 = "RSS 2.0";

  /** Level: XML Error */
  public static final int LEVEL_ERROR = 1;

  /** Level: XML Valid */
  public static final int LEVEL_OK = 2;

  /** Level: XML Warning */
  public static final int LEVEL_WARNING = 0;

  /** Height of the dialog in DLUs */
  private static final int DIALOG_HEIGHT = 300;

  /** Width of the dialog in DLUs */
  private static final int DIALOG_WIDTH = 420;

  private Thread animator;
  private TableColumn columnLevel;
  private Composite composite;
  private String feedPath;
  private Shell parent;
  private String title;
  TableColumn columnLine;
  TableColumn columnMessage;
  MenuItem copyItem;
  Text feedPathInput;
  CLabel messageLabel;
  Table messageTable;
  Button overrideDTDCheck;
  FeedValidator rssOwlFeedValidator;
  Combo selectFormat;
  Shell shell;
  Button validateButton;
  boolean validating;

  /**
   * Creates an input dialog with Validate and Stop button. Prompts for a URL /
   * Path to validate for.
   * 
   * @param dialogTitle the dialog title
   * @param feedPath To preset the feedPath input field
   */
  public ValidateFeedDialog(String dialogTitle, String feedPath) {
    this.title = dialogTitle;
    this.feedPath = feedPath;
    validating = false;
    parent = GUI.shell;
    createDialogArea();
  }

  /**
   * Add an error / warning or OK message into the table
   * 
   * @param level The level of the message
   * @param message The message to display
   * @param line The linenumber where the message occured or -1 if no line is
   * available
   */
  public void addMessage(final int level, final String message, final int line) {

    /** Only perform operation if RSSOwl was not yet closed */
    if (GUI.isAlive()) {
      GUI.display.syncExec(new Runnable() {
        public void run() {

          /** The user may have closed the dialog already! */
          if (!messageTable.isDisposed() && validating) {
            TableItem tableItem = new TableItem(messageTable, SWT.NONE);

            switch (level) {

              /** Give out error message */
              case LEVEL_ERROR:
                tableItem.setImage(PaintShop.iconError);
                tableItem.setText(1, message.replaceAll("\n", " "));
                tableItem.setText(2, (line != -1) ? String.valueOf(line) : "-");
                break;

              /** Give out warning message */
              case LEVEL_WARNING:
                tableItem.setImage(PaintShop.iconWarning);
                tableItem.setText(1, message.replaceAll("\n", " "));
                tableItem.setText(2, (line != -1) ? String.valueOf(line) : "-");
                break;

              /** Give out OK message */
              case LEVEL_OK:
                tableItem.setImage(PaintShop.iconValidate);
                tableItem.setText(1, message);
                break;
            }
          }
        }
      });
    }
  }

  /**
   * Finish / Stop the running validation
   * 
   * @param feedFormat Human readable name of the validated feed
   */
  public void finishValidation(final String feedFormat) {

    /** Reset flag */
    validating = false;

    /** Stop animation if running */
    stopStatusMessageAnimate();

    /** Interrupt validator thread */
    rssOwlFeedValidator.stopThread();

    /** Only update GUI if RSSOwl was not yet closed */
    if (GUI.isAlive()) {
      GUI.display.asyncExec(new Runnable() {
        public void run() {
          setValidateButtonState(false);
          setMessage(GUI.i18n.getTranslation("LABEL_VALIDATION_FINISHED") + ((feedFormat != null) ? " [" + feedFormat + "]" : ""));

          /** Set state of copy menuitem */
          if (!copyItem.isDisposed() && !messageTable.isDisposed())
            copyItem.setEnabled((messageTable.getItemCount() > 0));
        }
      });
    }
  }

  /** Display the dialog */
  public void open() {
    WidgetShop.openDialogsCount++;
    shell.open();
  }

  /**
   * Perform the validation and use the feedPath from the input field
   */
  public void performValidation() {
    if (WidgetShop.isset(feedPathInput) && StringShop.isset(feedPathInput.getText())) {
      performValidation(feedPathInput.getText().trim());
      setValidateButtonState(true);
    }
  }

  /**
   * Clear the message label
   */
  private void clearMessageLabel() {

    /** The user may have closed the dialog already! */
    if (!messageLabel.isDisposed()) {
      messageLabel.setImage(null);
      messageLabel.setText("");
    }
  }

  /** Create the dialog components */
  private void createDialogArea() {

    /** Shell for the dialog */
    shell = new Shell(parent, SWT.CLOSE | SWT.TITLE | SWT.MIN | SWT.MAX | SWT.RESIZE);
    shell.setLayout(new FillLayout());

    /** On Mac do not set Shell Image since it will change the Dock Image */
    if (!GlobalSettings.isMac())
      shell.setImage(PaintShop.iconValidate);

    shell.setText(title);
    shell.addDisposeListener(new DisposeListener() {
      public void widgetDisposed(DisposeEvent e) {

        /** Counter was already updated */
        if (!shell.getMinimized())
          WidgetShop.openDialogsCount--;

        /** Interrupt validator thread when disposing the dialog */
        if (rssOwlFeedValidator != null)
          rssOwlFeedValidator.stopThread();

        /** Stop animation if running */
        stopStatusMessageAnimate();

        /** Reset flag */
        validating = false;
      }
    });

    /** Update Counter for open dialogs */
    shell.addShellListener(new ShellAdapter() {
      public void shellDeiconified(ShellEvent e) {
        WidgetShop.openDialogsCount++;
      }

      public void shellIconified(ShellEvent e) {
        WidgetShop.openDialogsCount--;
      }
    });

    /** Using composite for the components */
    composite = new Composite(shell, SWT.NONE);
    composite.setLayout(LayoutShop.createGridLayout(2, 0, 5));

    /** Dialog Message Holder */
    Composite dialogMessageHolder = new Composite(composite, SWT.NONE);
    dialogMessageHolder.setLayout(LayoutShop.createGridLayout(1, 5, 0));
    dialogMessageHolder.setLayoutData(new GridData(SWT.FILL, SWT.BEGINNING, true, false, 2, 1));

    /** Dialog Message */
    Label dialogMessage = new Label(dialogMessageHolder, SWT.WRAP);
    dialogMessage.setText(GUI.i18n.getTranslation("MESSAGEBOX_FILL_URL") + ":");
    dialogMessage.setLayoutData(new GridData(SWT.FILL, SWT.BEGINNING, true, false));
    dialogMessage.setFont(FontShop.dialogFont);

    /** Hold the validation components */
    Composite validationHolder = new Composite(composite, SWT.NONE);
    validationHolder.setLayout(LayoutShop.createGridLayout(3, 5, 0));
    validationHolder.setLayoutData(new GridData(SWT.FILL, SWT.BEGINNING, true, false, 2, 1));

    /** Input to enter a URL / Path to a newsfeed */
    feedPathInput = new Text(validationHolder, SWT.SINGLE | SWT.BORDER);
    feedPathInput.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
    feedPathInput.setFont(FontShop.dialogFont);
    feedPathInput.setFocus();
    feedPathInput.setText((feedPath != null) ? feedPath : "");
    feedPathInput.addKeyListener(new KeyAdapter() {

      /** Listen on "Enter" key */
      public void keyPressed(KeyEvent e) {
        if (e.character == SWT.CR && !feedPathInput.getText().equals("")) {
          performValidation(feedPathInput.getText().trim());
          setValidateButtonState(true);
        }
      }
    });

    /** Add Drop Support and run Discovery on Drop */
    WidgetShop.setupDropSupport(feedPathInput, new Runnable() {
      public void run() {
        if (StringShop.isset(feedPathInput.getText()) && !validating) {
          performValidation(feedPathInput.getText().trim());
          setValidateButtonState(true);
        }
      }
    });

    /** Tweak Text Widget */
    WidgetShop.tweakTextWidget(feedPathInput);

    /** Perform the validation after click */
    validateButton = new Button(validationHolder, SWT.NONE);
    validateButton.setText(GUI.i18n.getTranslation("BUTTON_VALIDATE"));
    validateButton.setData("BUTTON_VALIDATE");
    validateButton.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_END));
    validateButton.setFont(FontShop.dialogFont);
    validateButton.setEnabled(!feedPathInput.getText().equals(""));
    validateButton.addSelectionListener(new SelectionAdapter() {
      public void widgetSelected(SelectionEvent e) {

        /** Path must not be empty */
        if (feedPathInput.getText().equals(""))
          return;

        /** Start validation and set button to "Stop" */
        if (validateButton.getData().equals("BUTTON_VALIDATE")) {
          performValidation(feedPathInput.getText().trim());
          setValidateButtonState(true);
        }

        /** Stop validation and set button to "Validate" */
        else {
          finishValidation(null);
          setValidateButtonState(false);
        }
      }
    });

    /** Make Validate Button the default button of the dialog */
    shell.setDefaultButton(validateButton);

    /** Set validate button enabled / disabled in dependance of feed path input */
    feedPathInput.addModifyListener(new ModifyListener() {
      public void modifyText(ModifyEvent e) {
        validateButton.setEnabled(!feedPathInput.getText().trim().equals(""));

        /** Clear possible results from previous validation */
        clearResults();
      }
    });

    /** Open the file dialog to select a file to open */
    Button openFromFileButton = new Button(validationHolder, SWT.PUSH);
    openFromFileButton.setText(GUI.i18n.getTranslation("BUTTON_FILE") + "...");
    openFromFileButton.setFont(FontShop.dialogFont);
    openFromFileButton.addSelectionListener(new SelectionAdapter() {
      public void widgetSelected(SelectionEvent e) {
        String file = FileShop.getFilePath(shell, null, null, SWT.OPEN, null);

        if (file != null) {

          /** Fill the feedpath input field */
          feedPathInput.setText(file);

          /** Focus on url test button */
          validateButton.setFocus();
        }
      }
    });

    /** Composite to hold format controlls */
    Composite formatHolder = new Composite(composite, SWT.NONE);
    formatHolder.setLayout(LayoutShop.createGridLayout(3, 5, 0));
    formatHolder.setLayoutData(LayoutDataShop.createGridData(GridData.FILL_HORIZONTAL, 2));

    Label selectFormatLabel = new Label(formatHolder, SWT.NONE);
    selectFormatLabel.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_BEGINNING));
    selectFormatLabel.setFont(FontShop.dialogFont);
    selectFormatLabel.setText(GUI.i18n.getTranslation("LABEL_FEED_TYPE") + ": ");

    /** Combo to select the format, or let RSSOwl auto-detect it */
    selectFormat = new Combo(formatHolder, SWT.READ_ONLY);
    selectFormat.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_BEGINNING));
    selectFormat.setFont(FontShop.dialogFont);
    selectFormat.setEnabled(true);
    selectFormat.add(GUI.i18n.getTranslation("FORMAT_AUTO_DETECT"));
    selectFormat.add(FORMAT_RSS_0_91);
    selectFormat.add(FORMAT_RSS_0_92);
    selectFormat.add(FORMAT_RSS_2_0);
    selectFormat.select(0);

    /** Holder for the override DTD checkbox */
    Composite overrideHolder = new Composite(formatHolder, SWT.NONE);
    overrideHolder.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_END | GridData.FILL_HORIZONTAL));
    overrideHolder.setLayout(LayoutShop.createGridLayout(1, 5, 0));

    /**
     * Checkbox to select wether the validator should override the DTD
     * declaration
     */
    overrideDTDCheck = new Button(overrideHolder, SWT.CHECK);
    overrideDTDCheck.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_END));
    overrideDTDCheck.setFont(FontShop.dialogFont);
    overrideDTDCheck.setSelection(true);
    overrideDTDCheck.setText(GUI.i18n.getTranslation("LABEL_OVERRIDE_DTD"));
    overrideDTDCheck.addSelectionListener(new SelectionAdapter() {

      /** Disable selectFormat combo when checkbox is checked */
      public void widgetSelected(SelectionEvent e) {
        selectFormat.setEnabled(overrideDTDCheck.getSelection());
      }
    });

    /** Provide a 5px margin around the Table */
    Composite tableHolderMargin = new Composite(composite, SWT.NONE);
    tableHolderMargin.setLayout(LayoutShop.createFillLayout(5, 0));
    tableHolderMargin.setLayoutData(LayoutDataShop.createGridData(GridData.FILL_BOTH, 2));

    /** Holding the result table */
    final Composite tableHolder = new Composite(tableHolderMargin, SWT.NONE);

    /** Table to display the results of the search */
    messageTable = new Table(tableHolder, SWT.BORDER | SWT.FULL_SELECTION);
    messageTable.setLinesVisible(true);
    messageTable.setHeaderVisible(true);
    messageTable.setFont(FontShop.dialogFont);

    /** Column: Error Level */
    columnLevel = new TableColumn(messageTable, SWT.LEFT);
    columnLevel.setWidth(25);

    /** Column: Error Message */
    columnMessage = new TableColumn(messageTable, SWT.LEFT);
    columnMessage.setText(GUI.i18n.getTranslation("LABEL_DESCRIPTION"));

    /** Column: Error Line */
    columnLine = new TableColumn(messageTable, SWT.LEFT);
    columnLine.setText(GUI.i18n.getTranslation("TABLE_HEADER_LINE"));
    columnLine.pack();

    /** Dynamically resize the TableColumns as the Dialog resizes */
    tableHolder.addControlListener(new ControlAdapter() {
      public void controlResized(ControlEvent e) {
        Rectangle area = tableHolder.getClientArea();
        int width = area.width - 2 * messageTable.getBorderWidth() - messageTable.getVerticalBar().getSize().x;
        int otherColsWidth = 25 + columnLine.getWidth();
        Point oldSize = messageTable.getSize();
        if (oldSize.x > area.width) {
          columnMessage.setWidth(width - otherColsWidth);
          messageTable.setSize(area.width, area.height);
        } else {
          messageTable.setSize(area.width, area.height);
          columnMessage.setWidth(width - otherColsWidth);
        }
      }
    });

    /** Popup menue */
    Menu messageTableMenu = new Menu(messageTable);

    /** Copy error message */
    copyItem = new MenuItem(messageTableMenu, SWT.NONE);
    copyItem.setText(GUI.i18n.getTranslation("POP_COPY"));
    copyItem.setEnabled(false);
    copyItem.addSelectionListener(new SelectionAdapter() {
      public void widgetSelected(SelectionEvent e) {
        if (messageTable.getSelectionCount() > 0)
          new Clipboard(GUI.display).setContents(new Object[] { messageTable.getSelection()[0].getText(1) }, new Transfer[] { TextTransfer.getInstance() });
      }
    });

    /** Init the Mnemonics */
    MenuManager.initMnemonics(messageTableMenu);

    /** Apply Menu */
    messageTable.setMenu(messageTableMenu);

    /** Label Holder */
    Composite dialogMessageLabelHolder = new Composite(composite, SWT.NONE);
    dialogMessageLabelHolder.setLayout(LayoutShop.createGridLayout(1, 5, 0));
    dialogMessageLabelHolder.setLayoutData(LayoutDataShop.createGridData(GridData.FILL_HORIZONTAL, 2));

    /** Message Label */
    messageLabel = new CLabel(dialogMessageLabelHolder, SWT.NONE);
    messageLabel.setFont(FontShop.dialogFont);
    messageLabel.setLayoutData(new GridData(SWT.FILL, SWT.BEGINNING, true, false));
    messageLabel.addDisposeListener(DisposeListenerImpl.getInstance());

    /** Set Size calculating with Dialog Font and DLUs */
    GC gc = new GC(shell);
    gc.setFont(FontShop.dialogFont);
    FontMetrics fontMetrics = gc.getFontMetrics();
    int width = Dialog.convertHorizontalDLUsToPixels(fontMetrics, DIALOG_WIDTH);
    int height = Dialog.convertVerticalDLUsToPixels(fontMetrics, DIALOG_HEIGHT);
    shell.setSize(width, height);
    gc.dispose();

    /** Position shell */
    LayoutShop.positionShell(shell, false, WidgetShop.openDialogsCount);

    /** Set Mnemonics to Buttons */
    WidgetShop.initMnemonics(new Button[] { validateButton, openFromFileButton, overrideDTDCheck });
  }

  /** Start a thread to animate the status message */
  private void startStatusMessageAnimate() {
    animator = new Thread() {
      public void run() {
        while (!isInterrupted()) {

          /** Set points every 300ms */
          try {
            for (int i = 1; i < 6; i++) {
              sleep(300);
              setStatusPoints(i);
            }
          } catch (InterruptedException e) {
            return;
          }
        }
      }
    };
    animator.setName("Validate Status Animator Thread");
    animator.setDaemon(true);
    animator.start();
  }

  /**
   * Clear the message label and the result table
   */
  void clearResults() {
    clearMessageLabel();

    if (WidgetShop.isset(messageTable))
      messageTable.removeAll();
  }

  /**
   * Perform the validation and use the given feedPath from the input field
   * 
   * @param feedPath The URL / Path to a newsfeed for validaiton
   */
  void performValidation(String feedPath) {
    if (!feedPath.equals("")) {

      /** Clear message table */
      messageTable.removeAll();

      /** Update flag */
      validating = true;

      /** Reset message label */
      clearMessageLabel();

      /** Set validation is running message */
      messageLabel.setText(GUI.i18n.getTranslation("LABEL_VALIDATING"));

      /** Animate message label */
      startStatusMessageAnimate();

      /** Create a new feed validator thread */
      rssOwlFeedValidator = new FeedValidator(this, feedPath, selectFormat.getText(), overrideDTDCheck.getSelection());
      rssOwlFeedValidator.start();
    }
  }

  /**
   * Set a message to the messageLabel and the search image
   * 
   * @param message The message
   */
  void setMessage(String message) {

    /** The user may have closed the dialog already! */
    if (!messageLabel.isDisposed())
      messageLabel.setText(message);
  }

  /**
   * Set a number of points to the status message
   * 
   * @param number The number of points
   */
  void setStatusPoints(final int number) {

    /** Only perform this Runnable if RSSOwl was not closed */
    if (GUI.isAlive()) {
      GUI.display.asyncExec(new Runnable() {
        public void run() {
          String points = "";

          /** Create String with points */
          for (int i = 0; i < number; i++)
            points += ".";

          /** Set animated message, if message label and parent is not disposed */
          if (!messageLabel.isDisposed() && !messageLabel.getParent().isDisposed())
            messageLabel.setText(GUI.i18n.getTranslation("LABEL_VALIDATING") + points);
        }
      });
    }
  }

  /**
   * Set the status of the validate button. If validating is TRUE change the
   * button to display "Stop".
   * 
   * @param validating TRUE if validating
   */
  void setValidateButtonState(boolean validating) {
    if (GUI.isAlive() && !validateButton.isDisposed()) {
      validateButton.setText(GUI.i18n.getTranslation((validating == true) ? "BUTTON_STOP_VALIDATION" : "BUTTON_VALIDATE"));
      validateButton.setData((validating == true) ? "BUTTON_STOP_VALIDATION" : "BUTTON_VALIDATE");
    }

    /** Update */
    if (GUI.isAlive() && !validateButton.isDisposed() && !validateButton.getParent().isDisposed()) {
      validateButton.update();
      validateButton.getParent().layout(true);
    }
  }

  /** Stop the animation on the status message */
  void stopStatusMessageAnimate() {
    if (animator != null && !animator.isInterrupted())
      animator.interrupt();
  }
}