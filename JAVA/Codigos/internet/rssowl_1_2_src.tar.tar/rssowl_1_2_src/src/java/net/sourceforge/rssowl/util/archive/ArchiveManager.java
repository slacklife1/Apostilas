/*   **********************************************************************  **
 **   Copyright notice                                                       **
 **                                                                          **
 **   (c) 2003-2005 RSSOwl Development Team                                  **
 **   http://www.rssowl.org/                                                 **
 **                                                                          **
 **   All rights reserved                                                    **
 **                                                                          **
 **   This program and the accompanying materials are made available under   **
 **   the terms of the Common Public License v1.0 which accompanies this     **
 **   distribution, and is available at:                                     **
 **   http://www.rssowl.org/legal/cpl-v10.html                               **
 **                                                                          **
 **   A copy is found in the file cpl-v10.html and important notices to the  **
 **   license from the team is found in the textfile LICENSE.txt distributed **
 **   in this package.                                                       **
 **                                                                          **
 **   This copyright notice MUST APPEAR in all copies of the file!           **
 **                                                                          **
 **   Contributors:                                                          **
 **     RSSOwl - initial API and implementation (bpasero@rssowl.org)         **
 **                                                                          **
 **  **********************************************************************  */

package net.sourceforge.rssowl.util.archive;

import net.sourceforge.rssowl.controller.GUI;
import net.sourceforge.rssowl.util.GlobalSettings;
import net.sourceforge.rssowl.util.shop.XMLShop;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

/**
 * The ArchiveManager handles loading and saving of the archive on startup and
 * shutdown. Its the maincontroller of the whole archive and other objects from
 * RSSOwl access the archive through this class.
 * 
 * @author <a href="mailto:bpasero@rssowl.org">Benjamin Pasero </a>
 * @version 1.2
 */
public class ArchiveManager {
  private Archive archive;
  private SAXBuilder builder;
  ArchiveIndex index;

  /**
   * Instantiate a new ArchiveManager
   */
  public ArchiveManager() {
    builder = new SAXBuilder("org.apache.xerces.parsers.SAXParser");
  }

  /**
   * Create a unique archive file to save an archive item
   * 
   * @return File The unique file
   * @throws IOException If an error occurs
   */
  public File createUniqueArchiveFile() throws IOException {
    return File.createTempFile("rss", ".xml", new File(GlobalSettings.ARCHIVE_DIR));
  }

  /**
   * @return Returns the archive.
   */
  public Archive getArchive() {
    return archive;
  }

  /**
   * Load the archive
   * 
   * @return Archive The archive
   */
  public Archive loadArchive() {
    Archive archive = new Archive(this);
    ArrayList files = new ArrayList();
    Enumeration keys = index.getKeys();

    /** Foreach items in the archive */
    while (keys.hasMoreElements()) {
      String feedurl = (String) keys.nextElement();
      String fileName = index.getValue(feedurl);
      files.add(fileName);

      /** Load the archive item if it exists as file */
      if (isArchiveFileExisting(fileName)) {
        ArchiveItem item = loadArchiveItem(feedurl);
        archive.addItem(item);
      }
    }

    /** Add index to files */
    files.add("index.xml");

    File[] allFiles = new File(GlobalSettings.ARCHIVE_DIR).listFiles();

    /** Cleanup files that are not listed in the index */
    for (int a = 0; a < allFiles.length; a++)
      if (allFiles[a].isFile() && !files.contains(allFiles[a].getName()))
        allFiles[a].delete();

    return archive;
  }

  /**
   * Save all archive items
   */
  public void saveArchive() {
    ArrayList toDelete = new ArrayList();
    Enumeration keys = archive.getKeys();
    while (keys.hasMoreElements()) {
      String feedurl = (String) keys.nextElement();
      ArchiveItem item = archive.getItem(feedurl);

      /** Save this item because it has entries */
      if (item.getEntries().size() > 0) {
        saveArchiveItem(item);
      }

      /** Delete this item because it has no entries */
      else {
        toDelete.add(feedurl);

        /** Delete archive item file */
        if (item.getFile().getName() != null && isArchiveFileExisting(item.getFile().getName()))
          deleteArchiveFile(item.getFile().getName());
      }
    }

    /** Delete from Index */
    for (int a = 0; a < toDelete.size(); a++)
      index.removeIndex(toDelete.get(a));
  }

  /**
   * Shutdown process
   */
  public void shutdown() {
    saveArchive();
    saveIndex();
  }

  /**
   * Startup process
   */
  public void startup() {
    index = loadIndex();
    archive = loadArchive();
  }

  /**
   * Delete a file from the archive
   * 
   * @param fileName The file to delete
   */
  private void deleteArchiveFile(String fileName) {
    new File(GlobalSettings.ARCHIVE_DIR + GlobalSettings.PATH_SEPARATOR + fileName).delete();
  }

  /**
   * Delete the index file
   */
  private void deleteIndex() {
    deleteArchiveFile(GlobalSettings.ARCHIVE_DIR + GlobalSettings.PATH_SEPARATOR + "index.xml");
  }

  /**
   * Check if the given archive file is existing
   * 
   * @param fileName The name of the file
   * @return TRUE if the file exists in the archive
   */
  private boolean isArchiveFileExisting(String fileName) {
    return new File(GlobalSettings.ARCHIVE_DIR + GlobalSettings.PATH_SEPARATOR + fileName).exists();
  }

  /**
   * Check if the index file is exsiting
   * 
   * @return TRUE if the archive index file exists
   */
  private boolean isIndexExisting() {
    return new File(GlobalSettings.ARCHIVE_DIR + GlobalSettings.PATH_SEPARATOR + "index.xml").exists();
  }

  /**
   * Load an archive item from the archive
   * 
   * @param feedurl The URL of the feed
   * @return ArchiveItem The archive item from the archive
   */
  private ArchiveItem loadArchiveItem(String feedurl) {
    ArchiveItem archiveItem = new ArchiveItem(feedurl);

    /** Get the filename of the archive item */
    String itemFileName = index.getValue(feedurl);
    archiveItem.setFile(new File(GlobalSettings.ARCHIVE_DIR + GlobalSettings.PATH_SEPARATOR + itemFileName));

    try {
      Document document = builder.build(new File(GlobalSettings.ARCHIVE_DIR + GlobalSettings.PATH_SEPARATOR + itemFileName));
      Element root = document.getRootElement();
      List entries = root.getChildren("entry");
      Iterator entriesIt = entries.iterator();

      /** Load all archive entries from the archive item */
      while (entriesIt.hasNext()) {
        Element entry = (Element) entriesIt.next();
        Element newstitle = entry.getChild("newstitle");
        Element newslink = entry.getChild("newslink");
        Element newsdate = entry.getChild("newsdate");

        ArchiveEntry rssOwlArchiveEntry = new ArchiveEntry(newslink.getText(), newstitle.getText(), (newsdate != null) ? newsdate.getText() : "NULL");
        archiveItem.addEntry(rssOwlArchiveEntry);
      }
    } catch (JDOMException e) {
      GUI.logger.log("loadArchiveItem()", e);
    } catch (IOException e) {
      GUI.logger.log("loadArchiveItem()", e);
    } catch (IllegalArgumentException e) {
      GUI.logger.log("loadArchiveItem()", e);
    }
    return archiveItem;
  }

  /**
   * Load the archive index
   * 
   * @return ArchiveIndex The archive index
   */
  private ArchiveIndex loadIndex() {
    ArchiveIndex index = new ArchiveIndex(this);

    /** If the index does not exist, return an empty one */
    if (!isIndexExisting())
      return index;

    try {

      /** Parse index.xml */
      Document document = builder.build(new File(GlobalSettings.ARCHIVE_DIR + GlobalSettings.PATH_SEPARATOR + "index.xml"));

      Element root = document.getRootElement();
      List items = root.getChildren("item");
      Iterator itemsIt = items.iterator();

      /** Foreach item */
      while (itemsIt.hasNext()) {
        Element item = (Element) itemsIt.next();
        Element itemKey = item.getChild("feedurl");
        Element itemValue = item.getChild("filename");

        /** Add entry to index */
        index.addIndex(itemKey.getText(), itemValue.getText());
      }
    } catch (JDOMException e) {
      GUI.logger.log("loadIndex()", e);
    } catch (IOException e) {
      GUI.logger.log("loadIndex()", e);
    } catch (IllegalArgumentException e) {
      GUI.logger.log("loadIndex()", e);
    }
    return index;
  }

  /**
   * Save an archiveitem to a unique file
   * 
   * @param archiveItem An archive item that contains severyl archive entries
   */
  private void saveArchiveItem(ArchiveItem archiveItem) {

    /** Get the file name of the archive item */
    String itemFileName = index.getValue(archiveItem.getFeedurl());

    /** Delete old archive item file */
    if (itemFileName != null && isArchiveFileExisting(itemFileName))
      deleteArchiveFile(itemFileName);

    Document document = new Document();
    Element root = new Element("item");
    document.setRootElement(root);

    /** Save each entry */
    Enumeration elements = archiveItem.getEntries().elements();
    while (elements.hasMoreElements()) {
      ArchiveEntry rssOwlArchiveEntry = (ArchiveEntry) elements.nextElement();
      Element entry = new Element("entry");
      root.addContent(entry);

      Element newstitle = new Element("newstitle");
      newstitle.setText(rssOwlArchiveEntry.getNewsTitle());
      entry.addContent(newstitle);

      Element newslink = new Element("newslink");
      newslink.setText(rssOwlArchiveEntry.getNewsLink());
      entry.addContent(newslink);

      Element newsdate = new Element("newsdate");
      newsdate.setText(rssOwlArchiveEntry.getNewsdate());
      entry.addContent(newsdate);
    }

    /** Write item */
    XMLShop.writeXML(document, archiveItem.getFile());
  }

  /**
   * Save the archive index
   */
  private void saveIndex() {
    Document document = new Document();

    /** Root */
    Element root = new Element("index");
    document.setRootElement(root);

    /** Indices */
    Enumeration keys = index.getKeys();
    while (keys.hasMoreElements()) {
      String feedurl = (String) keys.nextElement();
      String filename = index.getValue(feedurl);

      /** Create new entry */
      Element item = new Element("item");
      root.addContent(item);

      /** Key of entry */
      Element entryKey = new Element("feedurl");
      entryKey.setText(feedurl);
      item.addContent(entryKey);

      /** Value of entry */
      Element entryValue = new Element("filename");
      entryValue.setText(filename);
      item.addContent(entryValue);
    }

    /** Delte old index before saving */
    if (isIndexExisting())
      deleteIndex();

    /** Write Index */
    XMLShop.writeXML(document, GlobalSettings.ARCHIVE_DIR + GlobalSettings.PATH_SEPARATOR + "index.xml");
  }
}