/*   **********************************************************************  **
 **   Copyright notice                                                       **
 **                                                                          **
 **   (c) 2003-2005 RSSOwl Development Team                                  **
 **   http://www.rssowl.org/                                                 **
 **                                                                          **
 **   All rights reserved                                                    **
 **                                                                          **
 **   This program and the accompanying materials are made available under   **
 **   the terms of the Common Public License v1.0 which accompanies this     **
 **   distribution, and is available at:                                     **
 **   http://www.rssowl.org/legal/cpl-v10.html                               **
 **                                                                          **
 **   A copy is found in the file cpl-v10.html and important notices to the  **
 **   license from the team is found in the textfile LICENSE.txt distributed **
 **   in this package.                                                       **
 **                                                                          **
 **   This copyright notice MUST APPEAR in all copies of the file!           **
 **                                                                          **
 **   Contributors:                                                          **
 **     RSSOwl - initial API and implementation (bpasero@rssowl.org)         **
 **                                                                          **
 **  **********************************************************************  */

package net.sourceforge.rssowl.controller.dnd;

import net.sourceforge.rssowl.model.TabItemData;
import net.sourceforge.rssowl.util.shop.WidgetShop;

import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.custom.CTabItem;
import org.eclipse.swt.dnd.DND;
import org.eclipse.swt.dnd.DragSource;
import org.eclipse.swt.dnd.DragSourceAdapter;
import org.eclipse.swt.dnd.DragSourceEvent;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.dnd.Transfer;

/**
 * This class impements basic Drag and Drop support to the CTabFolder. It allows
 * the user to drag a tabitem that displays a newsfeed and drop it in a category
 * of the favorites tree. On success RSSOwl will create a favorite out of the
 * URL and title of the dragged tabitem.
 * 
 * @author <a href="mailto:bpasero@rssowl.org">Benjamin Pasero </a>
 * @version 1.2
 */
public class NewsTabFolderDND {

  /** Support drag and drop operations */
  private static final int operations = DND.DROP_COPY;

  /** Array of transfer types */
  private static final Transfer[] types = new Transfer[] { TextTransfer.getInstance() };

  private DragSource source;
  private CTabFolder tabFolder;
  FavoritesTreeDND rssOwlFavoritesTreeDND;

  /**
   * Instantiate a new NewsTabFolderDND
   * 
   * @param tabFolder The CTabFolder to apply basic drag and drop support
   * @param rssOwlFavoritesTreeDND A reference to the drag and drop class of the
   * favorites tree. This is needed because the drop target will be the tree
   */
  public NewsTabFolderDND(CTabFolder tabFolder, FavoritesTreeDND rssOwlFavoritesTreeDND) {
    this.tabFolder = tabFolder;
    this.rssOwlFavoritesTreeDND = rssOwlFavoritesTreeDND;
    initDragAndDrop();
  }

  /**
   * Dispose the DragSource object
   */
  public void dispose() {
    source.dispose();
  }

  /**
   * Create the Drag Source on the tabfolder. Valid drag sources are newsfeeds
   */
  private void createDragSource() {
    source = new DragSource(tabFolder, operations);
    source.setTransfer(types);
    source.addDragListener(new DragSourceAdapter() {

      /** Reset the DragSourceItem field */
      public void dragFinished(DragSourceEvent event) {
        rssOwlFavoritesTreeDND.setDragSourceItem(null);
      }

      /** Set Feed Title and URL into Data Slot */
      public void dragSetData(DragSourceEvent event) {

        /** The source item is stored in the DND class of the favorites tree */
        TabItemData sourceData = (TabItemData) rssOwlFavoritesTreeDND.getDragSourceItem().getData();

        /** URL and Title as Drag Data */
        String url = "";
        String title = "";

        /** A Newsfeed is being dragged */
        if (sourceData.isFeed()) {
          title = sourceData.getTitle();
          url = sourceData.getUrl();
        }

        /** A Browser is being dragged */
        else if (sourceData.isBrowser()) {
          title = rssOwlFavoritesTreeDND.getDragSourceItem().getText();

          /** Retrieve URL from Browser if available */
          if (sourceData.getRSSOwlBrowserPanel() != null && WidgetShop.isset(sourceData.getRSSOwlBrowserPanel().getBrowser()))
            url = sourceData.getRSSOwlBrowserPanel().getBrowser().getUrl();
        }

        /** Set Data */
        event.data = url + System.getProperty("line.separator") + title;
      }

      /** Reset the DragSourceItem field */
      public void dragStart(DragSourceEvent event) {

        /** Retrieve a valid drag source tabitem */
        CTabItem validDragSourceTabItem = getValidDragSourceTabItem();

        /** TabItem is valid */
        if (validDragSourceTabItem != null) {
          event.doit = true;

          /** Store the item in the DND class of the favorites tree */
          rssOwlFavoritesTreeDND.setDragSourceItem(validDragSourceTabItem);
        }

        /** TabItem is invalid */
        else {
          event.doit = false;
        }
      }
    });
  }

  /**
   * Init Drag and Drop on the tree widget. Note that the Drop target is created
   * in the DND class of the favorites tree
   */
  private void initDragAndDrop() {
    createDragSource();
  }

  /**
   * Valid source items to drag from the tabfolder are tabs that display a
   * newsfeed
   * 
   * @return CTabItem The dragged tabitem or null if the tab is not valid to be
   * dragged
   */
  CTabItem getValidDragSourceTabItem() {
    CTabItem tabItem = tabFolder.getSelection();

    /** User has not selected a tab */
    if (tabItem == null)
      return null;

    /** Tab must be from the type Feed or Browser */
    if (!((TabItemData) tabItem.getData()).isFeed() && !((TabItemData) tabItem.getData()).isBrowser())
      return null;

    /** It is not allowed to dragg an aggregated category */
    if (((TabItemData) tabItem.getData()).isAggregatedCat())
      return null;

    /** Return tabItem to dragg */
    return tabItem;
  }
}