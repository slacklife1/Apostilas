/*   **********************************************************************  **
 **   Copyright notice                                                       **
 **                                                                          **
 **   (c) 2003-2005 RSSOwl Development Team                                  **
 **   http://www.rssowl.org/                                                 **
 **                                                                          **
 **   All rights reserved                                                    **
 **                                                                          **
 **   This program and the accompanying materials are made available under   **
 **   the terms of the Common Public License v1.0 which accompanies this     **
 **   distribution, and is available at:                                     **
 **   http://www.rssowl.org/legal/cpl-v10.html                               **
 **                                                                          **
 **   A copy is found in the file cpl-v10.html and important notices to the  **
 **   license from the team is found in the textfile LICENSE.txt distributed **
 **   in this package.                                                       **
 **                                                                          **
 **   This copyright notice MUST APPEAR in all copies of the file!           **
 **                                                                          **
 **   Contributors:                                                          **
 **     RSSOwl - initial API and implementation (bpasero@rssowl.org)         **
 **                                                                          **
 **  **********************************************************************  */

package net.sourceforge.rssowl.controller.thread;

import net.sourceforge.rssowl.controller.GUI;
import net.sourceforge.rssowl.controller.NewsTabFolder;
import net.sourceforge.rssowl.util.GlobalSettings;
import net.sourceforge.rssowl.util.search.SearchDefinition;

import java.util.Vector;

/**
 * The RSS queue loader is a thread that loads feed from a Vector. The feeds are
 * loaded feed by feed beginning with the first element of the vector.
 * 
 * @author <a href="mailto:bpasero@rssowl.org">Benjamin Pasero </a>
 * @version 1.2
 */
public class FeedQueueLoader extends Thread {
  private Vector feedQueue;

  /**
   * Instantiate a new FeedQueueLoader Thread
   */
  public FeedQueueLoader() {
    feedQueue = new Vector();
    setDaemon(true);
    setName("Queue Loader Thread");
  }

  /**
   * Add a feed to the queue
   * 
   * @param url URL of the feed
   */
  public void addFeed(String url) {

    /** Keep the order */
    if (feedQueue.contains(url))
      feedQueue.remove(url);

    feedQueue.add(url);
  }

  /**
   * @see java.lang.Thread#run()
   */
  public void run() {

    /** For each feed in the feed queue until is interrupted or app was closed */
    while (!feedQueue.isEmpty() && GUI.isAlive() && !isInterrupted()) {

      /** Load feed in display runnable */
      if (GUI.isAlive() && !isInterrupted()) {
        GUI.display.syncExec(new Runnable() {
          public void run() {

            /** If no Tabs are used, only load last Feed of List */
            String feedUrl = GlobalSettings.displaySingleTab ? getLastFeed() : getNextFeed();

            /** Load the Feed */
            GUI.rssOwlGui.loadNewsFeed(feedUrl, SearchDefinition.NO_SEARCH, true, true, NewsTabFolder.DISPLAY_MODE_FOCUS_FIRST);
          }
        });
      }

      /** If no Tabs are used, only load one Feed */
      if (GlobalSettings.displaySingleTab)
        return;
    }
  }

  /**
   * Start the RSS Queue loader Thread
   */
  public void startThread() {
    start();
  }

  /**
   * Stop the RSS Queue loader Thread
   */
  public void stopThread() {
    interrupt();
  }

  /**
   * Get the last feed to load
   * 
   * @return String URL of the last feed
   */
  String getLastFeed() {
    return (String) feedQueue.remove(feedQueue.size() - 1);
  }

  /**
   * Get the next feed to load
   * 
   * @return String URL of the next feed
   */
  String getNextFeed() {
    return (String) feedQueue.remove(0);
  }
}