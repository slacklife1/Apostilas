/*   **********************************************************************  **
 **   Copyright notice                                                       **
 **                                                                          **
 **   (c) 2003-2005 RSSOwl Development Team                                  **
 **   http://www.rssowl.org/                                                 **
 **                                                                          **
 **   All rights reserved                                                    **
 **                                                                          **
 **   This program and the accompanying materials are made available under   **
 **   the terms of the Common Public License v1.0 which accompanies this     **
 **   distribution, and is available at:                                     **
 **   http://www.rssowl.org/legal/cpl-v10.html                               **
 **                                                                          **
 **   A copy is found in the file cpl-v10.html and important notices to the  **
 **   license from the team is found in the textfile LICENSE.txt distributed **
 **   in this package.                                                       **
 **                                                                          **
 **   This copyright notice MUST APPEAR in all copies of the file!           **
 **                                                                          **
 **   Contributors:                                                          **
 **     RSSOwl - initial API and implementation (bpasero@rssowl.org)         **
 **                                                                          **
 **  **********************************************************************  */

package net.sourceforge.rssowl.dao.feedparser;

import net.sourceforge.rssowl.dao.NewsfeedFactoryException;
import net.sourceforge.rssowl.model.Channel;
import net.sourceforge.rssowl.model.NewsItem;
import net.sourceforge.rssowl.util.shop.StringShop;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.Namespace;

import java.util.Iterator;
import java.util.List;

/**
 * Parser for the RSS 0.91 Format <br />
 * Specification: http://backend.userland.com/rss091
 * 
 * @author <a href="mailto:bpasero@rssowl.org">Benjamin Pasero </a>
 * @version 1.2
 */
public class RSS_0_91_Parser extends BaseRSSParser {

  /**
   * Instantiate a new Parser for this format.
   * 
   * @param document The document containing the data to parse
   * @param rssChannel The Channel to fill with data from the document
   * @param url The URL of the Newsfeed that is parsed
   * @param nameSpaces Possible Namespaces of the XML document
   * @throws NewsfeedFactoryException If any error occurs
   */
  public RSS_0_91_Parser(Document document, Channel rssChannel, String url, Namespace nameSpaces[]) throws NewsfeedFactoryException {
    super(document, rssChannel, url, nameSpaces);
  }

  /**
   * @see net.sourceforge.rssowl.dao.feedparser.AbstractFeedParser#parse()
   */
  public void parse() throws NewsfeedFactoryException {

    /** Parse common attributes */
    super.parse();

    /** Temp String */
    String str;

    /** Get Channel Element */
    Element channel = getChildElement(root, "channel");

    /** Get the Channel Newsitems */
    List items = getChildren(channel, "item");

    /** Try validating for items in root element */
    if (items.size() == 0)
      items = getChildren(root, "item");

    Iterator itemsIt = items.iterator();

    /** For each newsitem */
    while (itemsIt.hasNext()) {
      Element item = (Element) itemsIt.next();
      NewsItem newsItem = new NewsItem();

      /** Title of NewsItem */
      str = getChildValue("title", item);
      if (StringShop.isset(str))
        newsItem.setTitle(str);

      /** Link of NewsItem */
      str = getChildValue("link", item);
      if (StringShop.isset(str))
        newsItem.setLink(str);

      /** Description of NewsItem */
      str = getChildValue("description", item);
      if (StringShop.isset(str))
        newsItem.setDescription(str);

      /** Set part of description as title if title is not available */
      if (!StringShop.isset(newsItem.getTitle()) && newsItem.getDescription() != null)
        newsItem.setTitle(newsItem.getDescription(), true);

      /**
       * <p>
       * pubDate of NewsItem
       * </p>
       * Note: The Specification of RSS 0.91 does not tell anything about the
       * publishDate being part of a valid RSS 0.91 Feed. But some Feeds tend to
       * use it anyways, so let's try to parse it from the Feed.
       */
      str = getChildValue("pubDate", item);
      if (StringShop.isset(str)) {
        newsItem.setPubDate(str, true);
        rssChannel.addAvailableNewsItemInfo("TABLE_HEADER_PUBDATE");
      }

      /** Parse dublin core module */
      parseDCModule(item, newsItem);

      /** Add NewsItem to Channel */
      rssChannel.insertItem(newsItem);
    }
  }
}