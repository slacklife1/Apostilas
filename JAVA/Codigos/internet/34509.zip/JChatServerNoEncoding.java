/*
 * Created on 23.03.2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
/**
 * @author Rustam Bunyadov
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;

public class JChatServerNoEncoding extends Thread implements ActionListener {

    private static final int kPortNumber = 3785;

    private ServerSocket fServerSocket;

    private JEditorPane inputPane;

    private JEditorPane dialogPane;

    private JTextField addressField;

    private JTextField nickField;

    private String currentMessage = "";

    private String encodedMessage = "";

    private Vector messageList = new Vector();

    private JFrame frame;

    public JChatServerNoEncoding(String title) {
        super(title);
        try {
            fServerSocket = new ServerSocket(kPortNumber);
            System.out.println("Server started");
        } catch (IOException ioe) {
            System.out.println("Port not open");
            System.exit(1);
        }
        frame = new JFrame();
        JMenuBar myMenuBar = new JMenuBar();
        frame.setJMenuBar(myMenuBar);
        JMenu myFileMenu = new JMenu("File");
        myMenuBar.add(myFileMenu);
        JMenuItem myFileSaveMenuItem = new JMenuItem("Save...");
        JMenuItem myFileClearMenuItem = new JMenuItem("Clear All");
        myFileSaveMenuItem.addActionListener(this);
        myFileClearMenuItem.addActionListener(this);
        myFileSaveMenuItem.setActionCommand("actSave");
        myFileClearMenuItem.setActionCommand("actClear");
        myFileMenu.add(myFileSaveMenuItem);
        myFileMenu.addSeparator();
        myFileMenu.add(myFileClearMenuItem);
        Container cont = frame.getContentPane();
        cont.setLayout(new BorderLayout());
        dialogPane = new JEditorPane();
        dialogPane.setEditable(false);
        dialogPane.setPreferredSize(new Dimension(400, 300));
        inputPane = new JEditorPane();
        inputPane.setPreferredSize(new Dimension(350, 70));
        JLabel addressLabel = new JLabel("IP adress :");
        JLabel nickLabel = new JLabel("Nick :");
        addressField = new JTextField("192.168.0.191");
        addressField.setPreferredSize(new Dimension(100, 20));
        nickField = new JTextField("Barbarossa");
        nickField.setPreferredSize(new Dimension(100, 20));

        JButton btnSend = new JButton("Send/Scroll");
        btnSend.setMnemonic('s');
        btnSend.setFocusable(false);
        btnSend.setActionCommand("actSend");
        btnSend.addActionListener(this);

        JScrollPane inputScroller = new JScrollPane(inputPane);
        inputScroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        JScrollPane dialogScroller = new JScrollPane(dialogPane);
        dialogScroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        JPanel configPane = new JPanel();
        configPane.setLayout(new FlowLayout(FlowLayout.LEFT));
        configPane.add(nickLabel);
        configPane.add(nickField);
        configPane.add(addressLabel);
        configPane.add(addressField);

        JPanel bottomPane1 = new JPanel();
        bottomPane1.setLayout(new BorderLayout());
        bottomPane1.add(inputScroller,BorderLayout.CENTER);
        bottomPane1.add(btnSend,BorderLayout.EAST);
        
        JPanel bottomPane2 = new JPanel();
        bottomPane2.setLayout(new BorderLayout());
        bottomPane2.add(configPane, BorderLayout.NORTH);
        bottomPane2.add(bottomPane1, BorderLayout.CENTER);
        
        cont.add(dialogScroller, BorderLayout.CENTER);
        cont.add(bottomPane2, BorderLayout.SOUTH);
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public void run() {
        Socket theClientSocket;
        while (true) {
            //waiting for client connection
            if (fServerSocket == null) return;
            try {
                theClientSocket = fServerSocket.accept();
                PrintWriter theWriter = new PrintWriter(new OutputStreamWriter(theClientSocket.getOutputStream()));
                theWriter.println(encodedMessage);
                theWriter.flush();
                theWriter.close();
                theClientSocket.close();
            } catch (IOException ioe) {
                System.out.println("Exception: " + ioe.getMessage());
                System.exit(1);
            }
        }
    }

    public static void main(String[] args) {
        JChatServerNoEncoding cs = new JChatServerNoEncoding("JChatServer");
        cs.start();
        JChatClient cc = cs.new JChatClient();
        cc.start();
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
     */
    public class JChatClient extends Thread {

        public JChatClient() {
        }

        public void run() {
            Socket theSocket;
            BufferedReader theReader;
            String theAddress = addressField.getText();
            while (true) {
                try {
                    theAddress = addressField.getText();
                    theSocket = new Socket(theAddress, kPortNumber);
                    theReader = new BufferedReader(new InputStreamReader(theSocket.getInputStream()));
                    StringBuffer theStringBuffer = new StringBuffer(128);
                    String theLine;
                    StringBuffer entireMessage = new StringBuffer();
                    int c;
                    while ((theLine = theReader.readLine()) != null) {
                        entireMessage.append(theLine);
                    }
                    if (entireMessage.toString().length() > 0) {
                        String decodedMessage = entireMessage.toString();
                        StringTokenizer st = new StringTokenizer(decodedMessage, " ");
                        String messageId = st.nextToken();
                        boolean messageExists = false;
                        for (int i = 0; i < messageList.size(); i++) {
                            if (messageId.equals(messageList.get(i).toString())) {
                                messageExists = true;
                                break;
                            }
                        }
                        if (!messageExists) {
                            String history = dialogPane.getText();
                            dialogPane.setText(history + "\r" + decodedMessage + "\r");
                            messageList.addElement(messageId);
                            frame.setVisible(true);
                        }
                    }
                    theReader.close();
                    theSocket.close();
                    addressField.setBackground(new Color(0, 255, 0));
                    sleep(1000);
                } catch (IOException ioe) {
                    addressField.setBackground(new Color(255, 0, 0));
                    System.out.println("Exception: " + ioe.getMessage());
                } catch (InterruptedException ie) {
                    addressField.setBackground(new Color(255, 0, 0));
                    System.out.println("Exception: " + ie.getMessage());
                }
            }
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
     */
    public void actionPerformed(ActionEvent e) {
        String actionCommand = e.getActionCommand();
        if (actionCommand.equals("actSave")) {
            try {
                JFileChooser fc = new JFileChooser();
                fc.showSaveDialog(frame);
                String all = dialogPane.getText();
                File file = fc.getSelectedFile();
                if (file != null) {//if Cancel button is not pressed
                    FileWriter fw = new FileWriter(file);
                    BufferedWriter bw = new BufferedWriter(fw);
                    bw.write(all, 0, all.length());
                    bw.close();
                    fw.close();
                }
            } catch (IOException ie) {
                System.out.println(ie);
            }
        } else if (actionCommand.equals("actClear")) {
            dialogPane.setText("");
        } else if (actionCommand.equals("actSend")) {
            if (!inputPane.getText().equals("")) {
                Calendar c = Calendar.getInstance();
                currentMessage = c.get(Calendar.HOUR_OF_DAY) + ":" + c.get(Calendar.MINUTE) + ":" + c.get(Calendar.SECOND) + " <" + nickField.getText() + ">: " + inputPane.getText();
                dialogPane.setText(dialogPane.getText() + "\r" + currentMessage + "\r");
                inputPane.setText("");
                encodedMessage = currentMessage;
            } else {
                dialogPane.setText(dialogPane.getText() + " ");
            }
        }
    }
}
