package biz.source_code.miniTemplator;

import java.util.HashMap;
import java.io.File;
import java.io.IOException;

/**
* A cache manager for MiniTemplator objects.
* This class is used to cache MiniTemplator objects in memory, so that
* each template file is only read and parsed once.
* <p>
*
* License: This module is released under the <a href="http://www.gnu.org/licenses/lgpl.html" target="_top">GNU/LGPL</a> license.<br>
*
* <p>
* Version history:<br>
* 2004-11-06 chdh: Module created.<br>
* 2004-11-07 chdh: Method "clear" added.
*/
public class MiniTemplatorCache {

private HashMap<String,MiniTemplator> cache;

/**
* Creates a new MiniTemplatorCache object.
*/
public MiniTemplatorCache() {
   cache = new HashMap<String,MiniTemplator>(); }

/**
* Returns a cloned MiniTemplator object from the cache.
* If there is not yet a MiniTemplator object with the specified <code>templateFileName</code>
* in the cache, a new MiniTemplator object is created and stored in the cache.
* Then the cached MiniTemplator object is cloned and the clone object is returned.
* @param  templateFileName the name of the template file.
* @return a cloned and reset MiniTemplator object.
*/
public MiniTemplator get (String templateFileName)
      throws IOException, MiniTemplator.TemplateSyntaxException {
   return getClone (templateFileName,null,false); }

/**
* Returns a cloned MiniTemplator object from the cache.
* Same as {@link #get(String)}, but with a <code>subtemplateBasePath</code> parameter.
* @param  templateFileName the name of the template file.
* @param  subtemplateBasePath a file system directory path, to be used for subtemplates.
* @return a cloned and reset MiniTemplator object.
*/
public MiniTemplator get (String templateFileName, String subtemplateBasePath)
      throws IOException, MiniTemplator.TemplateSyntaxException {
   return getClone (templateFileName,subtemplateBasePath,true); }

private synchronized MiniTemplator getClone (String templateFileName, String subtemplateBasePath, boolean passSubtemplateBasePath)
      throws IOException, MiniTemplator.TemplateSyntaxException {
   MiniTemplator mt = cache.get(templateFileName);
   if (mt == null) {
      File file = new File(templateFileName);
      if (passSubtemplateBasePath)
         mt = new MiniTemplator(file,subtemplateBasePath);
       else
         mt = new MiniTemplator(file);
      cache.put (templateFileName,mt); }
   return mt.cloneReset(); }

/**
* Clears the cache.
*/
public synchronized void clear() {
   cache.clear(); }

} // end class MiniTemplatorCache
