// File Sample2.java
// A more complex example of how to use the MiniTemplator class.

import java.io.*;
import biz.source_code.miniTemplator.*;

public class Sample2 {

static final String TemplateFileName = "Sample2_template.htm";
static final String OutputFileName   = "Sample2_out.htm";

private static void generateCalendarPage() throws Exception {
   MiniTemplator t = new MiniTemplator(new File(TemplateFileName));
   t.setVariable ("year","2003");
   t.setVariable ("month","April");
   for (int weekOfYear=14; weekOfYear<=18; weekOfYear++) {
      for (int dayOfWeek=0; dayOfWeek<7; dayOfWeek++) {
         int dayOfMonth = (weekOfYear*7 + dayOfWeek) - 98;
         if (dayOfMonth >= 1 && dayOfMonth <= 30)
            t.setVariable ("dayOfMonth",Integer.toString(dayOfMonth));
          else
            t.setVariable ("dayOfMonth","&nbsp;");
         t.addBlock ("day"); }
      t.setVariable ("weekOfYear",Integer.toString(weekOfYear));
      t.addBlock ("week"); }
   t.generateOutput (new File(OutputFileName)); }

public static void main (String args[]) {
   try {
      generateCalendarPage(); }
    catch (Exception e) {
      e.printStackTrace(); }}

};
