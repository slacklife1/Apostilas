package paas.server;

import java.io.*;
import java.net.*;
import paas.client.*;


public class ClientThread extends Thread implements Runnable
{
  ClientGroup parent;
  Socket theSocket;

  ObjectOutputStream objout = null;
  ObjectInputStream objin = null;
  String alias;

  public ClientThread(Socket s, ClientGroup p)
  {
    theSocket = s;
    parent = p;
  }
  public void finalize()
  {
    try
    {
      objin.close();
      theSocket.close();
      objout = null;
      parent.removeThread(this);
    }
    catch(Exception ex)
    {
      System.out.println("Error in closing ClientThead: " + ex.getMessage());
    }
    return;
  }
  public boolean Message(ClientPacket cpack)
  {
    try
    {
      objout.writeObject(cpack);
      objout.flush();
    }
    catch(Exception ex) {return false;}
    return true;
  }
  public void run()
  {
    try
    {
      objout = new ObjectOutputStream(theSocket.getOutputStream());
      objout.flush();
      objin = new ObjectInputStream(theSocket.getInputStream());

    } catch (Exception e){System.out.println("Exception: " + e.getMessage());}

    while(theSocket != null)
    {
      ServerPacket pac = null;
      ClientPacket cpacket = new ClientPacket();
      try
      {
        objout.writeObject(cpacket);
        objout.flush();
      }
      catch(Exception ex)
      {
        System.out.println("unable to ping: " + ex.getMessage());
        parent.logout(this);
        this.finalize();
        break;
      }
      try
      {
        pac = (ServerPacket)objin.readObject();

        if(pac != null)
        {
          if(pac.getIsMessage())
          {
            Message msg = pac.getMessage();
            if(msg != null)
            {
              if(msg.isLogin())
              {
                parent.newLogin(msg.getLogin(),this);
              }
              else if(msg.isChatMessage())
              {
                if(msg.isWhishper())
                {
                  parent.sendMessage(msg,pac.getUser(), msg.getTarget());
                }
                else
                {
                  parent.sendMessage(msg);
                }
              }
            }
          }
        }
      }
      catch (Exception e) {};
     }
     return;
  }
  public String getAlias()
  {
    return alias;
  }
  public void setAlias(String str)
  {
    alias = str;
    return;
  }
}