package paas.server;

import java.net.*;
import java.util.*;
import java.io.*;
import paas.client.*;

public class ClientGroup extends Thread implements Runnable
{
  Vector theGroup;

  public ClientGroup()
  {
    theGroup = new Vector();
  }
  public void addClient(Socket s)
  {
    ClientThread tempThread = new ClientThread(s,this);
    theGroup.addElement(tempThread);
    tempThread.start();
    return;
  }
  public Vector calcList()
  {
    ClientThread t;
    Vector v = new Vector();
    String temp;
    for(int i =0; i < theGroup.size(); i++)
    {
      t = (ClientThread) theGroup.elementAt(i);
      if(t != null)
      {
        temp = t.getAlias();
        v.addElement(temp);
      }
    }
    return v;
  }
  public void clean()
  {
    ClientThread tempThread;
    for(int i =0; i < theGroup.size(); i++)
    {
      tempThread = (ClientThread)theGroup.elementAt(i);
      if(tempThread == null || !tempThread.isAlive())
      {
        theGroup.remove(tempThread);
        theGroup.trimToSize();
        System.out.println("removed thread");
      }
    }
    return;
  }
  public void removeThread(ClientThread t)
  {
    t = null;
  }
  public void newLogin(User user, ClientThread t)
  {
    t.setAlias(user.getUsername());
    Message msg = new Message();
    msg.setIsMessage(true);
    msg.setMessage(t.getAlias()+" has signed in");
    msg.setUsersList(calcList());
    sendMessage(msg);
    return;
  }
  public void logout(ClientThread t)
  {
    String name = t.getAlias();
    if(t != null && name != null)
    {
      theGroup.removeElement(t);
      clean();
      Message msg = new Message();
      msg.setIsMessage(true);
      msg.setMessage(name + " has left the room");
      msg.setUsersList(calcList());
      sendMessage(msg);
    }
    return;
  }
  public void sendMessage(Message msg)
  {
    ClientPacket cpack = new ClientPacket();
    cpack.setIsMessage(true);
    cpack.setMessage(msg);

    for(int i = 0; i < theGroup.size(); i++)
    {
      ((ClientThread)theGroup.elementAt(i)).Message(cpack);
    }

    return;
  }
  public void sendMessage(Message msg, User user, String target)
  {
    ClientPacket cpack = new ClientPacket();
    cpack.setIsMessage(true);
    cpack.setMessage(msg);
    cpack.setUser(user);

    for(int i = 0; i < theGroup.size(); i++)
    {
      ClientThread t = (ClientThread) theGroup.elementAt(i);
      if(t.getAlias().equals(target))
        t.Message(cpack);
    }

    return;
  }

  public void run()
  {
    while(true)
    {
      try{
        sleep(3000); }catch(Exception ex) {}
      clean();
    }
  }
}