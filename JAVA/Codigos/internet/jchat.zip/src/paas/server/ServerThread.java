package paas.server;

import java.net.*;

public class ServerThread extends Thread implements Runnable
{
  ServerSocket serverSocket = null;
  ClientGroup group;

  public ServerThread()
  {
    try
    {
      serverSocket = new ServerSocket(1123);
    }
    catch(Exception ex) {System.out.println("Error connecting: " + ex.getMessage());}
    System.out.println("Server Successfully connected. Waiting for connection..");
    group = new ClientGroup();
    group.start();
  }
  public void finalize()
  {
    try
    {
      serverSocket.close();
    }
    catch(Exception ex)
    {
      System.out.println("Error closing server connection: " + ex.getMessage());
    }
    serverSocket = null;
    return;
  }
  public void run()
  {
    while(serverSocket != null)
    {
      Socket tempSocket;
      try
      {
        tempSocket = serverSocket.accept();
        System.out.println("Recieved new Connection");
        group.addClient(tempSocket);
      }
      catch(Exception ex)
      {
        System.out.println("New Connection Failure: " + ex.getMessage());
      }
    }
  }
}