package paas.client;


public class User implements java.io.Serializable
{
  private String firstname;
  private String username;

  public User()
  {
  }

  public void setFirstname(String firstname)
  {
    this.firstname = firstname;
  }

  public void setUsername(String username)
  {
    this.username = username;
  }

  public String getFirstname()
  {
    return firstname;
  }
  public String getUsername()
  {
    return username;
  }
}