package paas.client;

import java.util.Vector;

public class Message implements java.io.Serializable
{
  private boolean isLogin;
  private boolean ismsg;
  private boolean isChatMessage;
  private boolean isWhishper;

  private User user = null;
  private String msg;
  private String chatMessage;
  private String target;
  private Vector usersList;

  public Message()
  {
  }

  public void setIsLogin(boolean il)
  {
    this.isLogin = il;
  }

  public void setLogin(User u)
  {
    this.user = u;
  }

  public void setLogout(User u)
  {
    this.user = u;
  }

  public void setIsMessage(boolean im)
  {
    this.ismsg = im;
  }

  public void setIsChatMessage(boolean icm)
  {
    this.isChatMessage = icm;
  }

  public void setMessage(String msg)
  {
    this.msg = msg;
  }

  public void setChatMessage(String cm)
  {
    this.chatMessage = cm;
  }

  public void setUsersList(Vector v)
  {
    this.usersList = v;
  }

  public void setIsWhishper(boolean iw)
  {
    this.isWhishper = iw;
  }

  public void setTarget(String name)
  {
    this.target = name;
  }

  public boolean isLogin()
  {
    return isLogin;
  }

  public User getLogin()
  {
    return user;
  }

  public User getLogout()
  {
    return user;
  }

  public boolean isMessage()
  {
    return ismsg;
  }

  public boolean isChatMessage()
  {
    return isChatMessage;
  }

  public boolean isWhishper()
  {
    return isWhishper;
  }

  public String getMessage()
  {
    return msg;
  }

  public String chatMessage()
  {
    return chatMessage;
  }

  public Vector getUsersList()
  {
    return usersList;
  }
  public String getTarget()
  {
    return target;
  }
}