package paas.client.gui;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.*;

import javax.swing.*;

import paas.client.*;

public class ClientGUI extends JFrame implements Runnable, ActionListener
{
  private JPanel leftPanel = new JPanel();
  private JLabel lblOnlineUsers = new JLabel();
  private JPanel onlineUsersPanel = new JPanel();
  private JPanel tabPanel = new JPanel();
  private JLabel heading = new JLabel();
  private JScrollPane onlineUserPane = new JScrollPane();
  private JMenu fmenu = new JMenu("File");
  private JMenuBar menu = new JMenuBar();
  private JMenuItem exitbtn = new JMenuItem("Exit",'x');

  public User user;
  private Socket socket = null;
  private ObjectOutputStream objout;
  private ObjectInputStream objin;
  private Thread thread = null;
  private UsersList usersList;
  private JScrollPane tabScrollPane = new JScrollPane();
  private JTabbedPane TabbedPane = new JTabbedPane();
  private JPanel chatPanel = new JPanel();
  private JTextField chatTextField = new JTextField();
  private JButton SendButton = new JButton();
  private JScrollPane chatScrollPane = new JScrollPane();
  private JEditorPane chatEditor = new JEditorPane();
  private JScrollPane logScrollPane = new JScrollPane();
  private JTextArea LogEditor = new JTextArea();

  public ClientGUI() {}

  public ClientGUI(User user)
  {
    this.user = user;
    thread = new Thread(this);
    usersList = new UsersList(this);

    fmenu.setMnemonic('F');
    fmenu.add(exitbtn);
    menu.add(fmenu);
    this.setJMenuBar(menu);

    try
    {
      jbInit();
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
    thread.start();


    exitbtn.addActionListener(this);
    SendButton.addActionListener(this);
    chatTextField.addActionListener(this);
  }
  public void actionPerformed(ActionEvent e)
  {
    if(e.getSource().equals(SendButton))
    {
      if(chatTextField.getText().length() != 0)
      {
        Message chatMsg = new Message();
        ServerPacket chatpacket = new ServerPacket();
        chatMsg.setIsChatMessage(true);
        chatMsg.setIsWhishper(false);
        chatMsg.setMessage(user.getUsername() + " says: " + chatTextField.getText());
        chatTextField.setText("");

        chatpacket.setIsMessage(true);
        chatpacket.setMessage(chatMsg);
        sendChatMessage(chatpacket);
        return;
      }
    }
    else if(e.getSource().equals(chatTextField))
    {
      SendButton.doClick();
      return;
    }
    else if(e.getSource().equals(exitbtn))
    {
      System.exit(0);
    }
  }

  public void run()
  {
    while(socket==null && thread != null)
    {
      try
      {
        socket = new Socket("localhost", 1123);
        objout = new ObjectOutputStream(socket.getOutputStream());
        objout.flush();
        objin = new ObjectInputStream(socket.getInputStream());
      }
      catch (Exception e)
      {
        LogEditor.append("Unable to contact host. Retrying ...\n");
        System.out.println("unable to contact with host retrying.....");
        socket=null;
        try { thread.sleep(5000);} catch(Exception ex){};
      }
    }
    ServerPacket sp = new ServerPacket();

    Message m = new Message();
    m.setIsLogin(true);
    m.setLogin(user);
    sp.setIsMessage(true);
    sp.setMessage(m);
    output(sp);  //send a login message to server */

    this.setTitle(user.getFirstname());

    LogEditor.append("Logged in to server successfully.\n");

    while (socket != null && objin != null && thread != null)
    {
      try
      {
        ClientPacket cPacket = null;
        cPacket = (ClientPacket) objin.readObject();
        if(cPacket != null)
        {
          if(cPacket.isPing()) {/** do nothing **/ }

          if(cPacket.isMessage())
          {
            Message msg = cPacket.getMessage();
            if(msg.isMessage())
            {
              if(msg.getMessage() != null)
              {
                LogEditor.append(msg.getMessage() + "\n");
                Vector data = msg.getUsersList();

                if(data != null && data.size() != 0)
                {
                  Vector v = getList(data);
                  this.updateList(v,getIcons(v));
                }
              }
            }
            else if(msg.isChatMessage())
            {
              if(msg.isWhishper())
              {
                usersList.openWhisperDialog(cPacket.getUser().getUsername(),msg.getMessage());
              }
              else //append text to text area
                chatEditor.setText(chatEditor.getText() + msg.getMessage() + "\n");
            }
          }
        }
      }
      catch(ClassCastException ex){}
      catch(Exception ex)
      {
        System.out.println("Exception in client GUI " + ex.getMessage());
        LogEditor.append("Exception: " + ex.getMessage() + "\n");
        try{thread.sleep(2000);}catch(Exception e){}
      }
    }
  }

  public boolean output(ServerPacket packet)
  {
    try
    {
      objout.writeObject(packet);
      objout.flush();
      return true;
    }
    catch (Exception ex)
    {
        LogEditor.append("Exception: " + ex.getMessage() + "\n");
        return false;
    }
  }

  public void sendChatMessage(ServerPacket chatpacket)
  {
    output(chatpacket);
  }

  private void updateList(Vector list, Vector icons)
  {
    usersList.removeAll();
    usersList.setUsersList(list);
    usersList.setUsersIcon(icons);
  }

  private Vector getList(Vector v)
  {
    Vector temp = new Vector();
    String s;
    for(int i = 0; i < v.size(); i++)
    {
      s = (String)v.elementAt(i);
      if( s != null && s.length() != 0 && s.indexOf(user.getUsername()) == -1)
      {
        temp.addElement(s);
      }
    }
    return temp;
  }
  private Vector getIcons(Vector v)
  {
    Vector tmphold = new Vector();

    for(int i =0; i < v.size(); i++)
      tmphold.addElement(new ImageIcon("images\\online.gif"));

    return tmphold;
  }
  public void finalize()
  {
    try
    {
      objout.close();
      objin.close();
      socket.close();
    } catch (Exception e){};
    socket = null;
    thread = null;
    return;
}
  private void jbInit() throws Exception
  {
    this.getContentPane().setLayout(null);
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    this.setSize(new Dimension(800, 600));
    this.setVisible(true);
    leftPanel.setBorder(BorderFactory.createLineBorder(Color.black));
    leftPanel.setBounds(new Rectangle(8, 98, 214, 437));
    leftPanel.setLayout(null);
    lblOnlineUsers.setFont(new java.awt.Font("Serif", 1, 15));
    lblOnlineUsers.setHorizontalAlignment(SwingConstants.CENTER);
    lblOnlineUsers.setHorizontalTextPosition(SwingConstants.CENTER);
    lblOnlineUsers.setText("Online users");
    lblOnlineUsers.setBounds(new Rectangle(11, 8, 193, 32));
    onlineUsersPanel.setOpaque(false);
    onlineUsersPanel.setBounds(new Rectangle(7, 49, 197, 254));
    onlineUsersPanel.setLayout(null);
    tabPanel.setBorder(BorderFactory.createLineBorder(Color.black));
    tabPanel.setBounds(new Rectangle(232, 94, 560, 441));
    tabPanel.setLayout(null);
    heading.setFont(new java.awt.Font("Serif", 1, 25));
    heading.setHorizontalAlignment(SwingConstants.CENTER);
    heading.setText("Java Chat Demo");
    heading.setBounds(new Rectangle(237, 16, 361, 68));
    onlineUserPane.setBorder(null);
    onlineUserPane.setOpaque(false);
    onlineUserPane.setBounds(new Rectangle(-4, 1, 207, 248));
    usersList.setFont(new java.awt.Font("Dialog", Font.BOLD, 15));
    usersList.setOpaque(false);
    usersList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    tabScrollPane.setBounds(new Rectangle(3, 2, 551, 434));
    chatPanel.setLayout(null);
    chatTextField.setBounds(new Rectangle(2, 368, 460, 27));
    SendButton.setBounds(new Rectangle(466, 367, 64, 28));
    SendButton.setToolTipText("");
    SendButton.setText("Send");
    chatScrollPane.setBounds(new Rectangle(5, 1, 536, 364));
    chatEditor.setCaretColor(UIManager.getColor("InternalFrame.activeTitleBackground"));
    chatEditor.setEditable(false);
    LogEditor.setEditable(false);
    this.getContentPane().add(leftPanel, null);
    leftPanel.add(lblOnlineUsers, null);
    leftPanel.add(onlineUsersPanel, null);
    onlineUsersPanel.add(onlineUserPane, null);
    onlineUserPane.getViewport().setView(usersList);
    this.getContentPane().add(tabPanel, null);
    tabPanel.add(tabScrollPane, null);
    TabbedPane.add(logScrollPane,  "Log");
    logScrollPane.getViewport().add(LogEditor, null);
    this.getContentPane().add(heading, null);
    TabbedPane.add(chatPanel, "Chat");
    chatPanel.add(chatTextField, null);
    chatPanel.add(SendButton, null);
    chatPanel.add(chatScrollPane, null);

    chatScrollPane.getViewport().add(chatEditor, null);

    tabScrollPane.getViewport().add(TabbedPane, null);
  }
  public void exit()
  {
    thread.interrupt();
    thread.destroy();
    thread = null;
    try
    {
      objout.writeObject("logout");
      objout.flush();
    }
    catch(Exception ex){}
  }
}