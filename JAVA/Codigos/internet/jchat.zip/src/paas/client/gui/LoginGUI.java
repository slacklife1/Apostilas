package paas.client.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import paas.client.*;

public class LoginGUI extends JDialog implements ActionListener, WindowListener
{
  private JLabel keylabel = new JLabel();
  private JLabel infoLabel = new JLabel();
  private JLabel FirstnameLabel = new JLabel();
  private JLabel UsernameLabel = new JLabel();
  private JTextField txtfirstname = new JTextField();
  private JTextField txtUsername = new JTextField();
  private JButton btnLogin = new JButton();
  private JButton btnReset = new JButton();
  private JFrame fowner;

  public LoginGUI(){}

  public LoginGUI(JFrame owner, boolean modal)
  {
    super(owner,modal);
    fowner = owner;

    btnLogin.addActionListener(this);
    btnReset.addActionListener(this);
    this.addWindowListener(this);
    try
    {
      jbInit();
      keylabel.setIcon(new ImageIcon("images/key.gif"));
      Dimension windowSize = Toolkit.getDefaultToolkit().getScreenSize();
      setBounds(windowSize.width/4,windowSize.height/4,320,250);
      this.setVisible(true);
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }
  public void actionPerformed(ActionEvent e)
  {
    Object obj = e.getSource();

    if(obj.equals(btnLogin))
    {
      if(txtfirstname.getText().length() == 0)
        JOptionPane.showMessageDialog(fowner,"Please enter user name", "PAAS", JOptionPane.ERROR_MESSAGE);

      else if(txtUsername.getText().length() == 0)
        JOptionPane.showMessageDialog(fowner,"Please enter password", "PAAS", JOptionPane.ERROR_MESSAGE);
      else
      {
        User user = new User();
        user.setUsername(txtUsername.getText());
        user.setFirstname(txtfirstname.getText());

        ClientGUI cgui = new ClientGUI(user);
        this.setVisible(false);
        this.dispose();
        System.gc();

      }
    }
    if(obj.equals(btnReset))
    {
      txtfirstname.setText("");
      txtUsername.setText("");
    }
  }
  private void jbInit() throws Exception
  {
    keylabel.setBounds(new Rectangle(54, 9, 230, 53));
    this.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
    this.setTitle("Login");
    this.getContentPane().setLayout(null);
    infoLabel.setFont(new java.awt.Font("Serif", 1, 12));
    infoLabel.setForeground(Color.blue);
    infoLabel.setToolTipText("");
    infoLabel.setText("Please enter information to login");
    infoLabel.setBounds(new Rectangle(8, 70, 227, 27));
    FirstnameLabel.setFont(new java.awt.Font("Serif", 1, 12));
    FirstnameLabel.setForeground(Color.blue);
    FirstnameLabel.setLabelFor(txtfirstname);
    FirstnameLabel.setText("First name");
    FirstnameLabel.setBounds(new Rectangle(8, 101, 86, 25));
    UsernameLabel.setBounds(new Rectangle(9, 135, 86, 25));
    UsernameLabel.setFont(new java.awt.Font("Serif", 1, 12));
    UsernameLabel.setForeground(Color.blue);
    UsernameLabel.setLabelFor(txtUsername);
    UsernameLabel.setText("User name");
    txtfirstname.setBounds(new Rectangle(98, 104, 139, 24));
    txtUsername.setBounds(new Rectangle(98, 134, 139, 24));
    btnLogin.setBounds(new Rectangle(85, 172, 65, 29));
    btnLogin.setText("Login");
    btnReset.setText("Reset");
    btnReset.setBounds(new Rectangle(167, 172, 67, 29));
    this.getContentPane().add(txtfirstname, null);
    this.getContentPane().add(FirstnameLabel, null);
    this.getContentPane().add(UsernameLabel, null);
    this.getContentPane().add(txtUsername, null);
    this.getContentPane().add(infoLabel, null);
    this.getContentPane().add(keylabel, null);
    this.getContentPane().add(btnReset, null);
    this.getContentPane().add(btnLogin, null);
  }
  public void windowDeactivated(WindowEvent e){}
  public void windowActivated(WindowEvent e){}
  public void windowDeiconified(WindowEvent e){}
  public void windowIconified(WindowEvent e){}
  public void windowClosed(WindowEvent e){}
  public void windowClosing(WindowEvent e){System.exit(0);}
  public void windowOpened(WindowEvent e){}
}