package paas.client.gui;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import paas.client.*;

public class WhisperDialog extends JFrame implements WindowListener, ActionListener
{
  private JScrollPane chatScrollPane = new JScrollPane();
  private JTextPane chatTextPane = new JTextPane();
  private JTextField textField = new JTextField();
  private JButton sendButton = new JButton();

  private ClientGUI parent;
  private String target;

  public WhisperDialog(ClientGUI cgui, String t)
  {
    parent = cgui;
    target = t;
    try
    {
      jbInit();
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
    Dimension windowSize = Toolkit.getDefaultToolkit().getScreenSize();
    setBounds(windowSize.width/4,windowSize.height/4,383,245);
    this.setVisible(true);
    this.addWindowListener(this);
    sendButton.addActionListener(this);
    textField.addActionListener(this);
  }

  public void actionPerformed(ActionEvent e)
  {
    if(e.getSource().equals(sendButton))
    {
      Message chatMsg = new Message();
      ServerPacket chatpacket = new ServerPacket();
      chatMsg.setIsChatMessage(true);
      chatMsg.setIsWhishper(true);
      chatMsg.setTarget(target);
      String text = parent.user.getUsername() + " says: " + textField.getText();
      chatMsg.setMessage(text);
      appendText(text);
      textField.setText("");

      chatpacket.setIsMessage(true);
      chatpacket.setMessage(chatMsg);
      chatpacket.setUser(parent.user);
      parent.sendChatMessage(chatpacket);
    }
    if(e.getSource().equals(textField))
      sendButton.doClick();
  }

  public void appendText(String msg)
  {
    chatTextPane.setText(chatTextPane.getText() + msg + "\n");
  }
  public void sendMessage()
  {

  }

  public String getTarget()
  {
    return target;
  }

  public void setOfflined()
  {
    sendButton.disable();
    textField.disable();
    appendText(target + " has left");
  }

  private void jbInit() throws Exception
  {
    this.getContentPane().setLayout(null);
    chatScrollPane.setBounds(new Rectangle(3, 2, 369, 171));
    chatTextPane.setEditable(false);
    textField.setBounds(new Rectangle(2, 177, 295, 36));
    sendButton.setBounds(new Rectangle(301, 177, 67, 36));
    sendButton.setText("Send");
    this.setResizable(false);
    this.setTitle("Whisper");
    this.getContentPane().add(chatScrollPane, null);
    this.getContentPane().add(textField, null);
    this.getContentPane().add(sendButton, null);
    chatScrollPane.getViewport().add(chatTextPane, null);
  }
  public void windowDeactivated(WindowEvent e){}
  public void windowActivated(WindowEvent e){}
  public void windowDeiconified(WindowEvent e){}
  public void windowIconified(WindowEvent e){}
  public void windowClosed(WindowEvent e){}
  public void windowClosing(WindowEvent e)
  {
    chatTextPane.setText("");
  }
  public void windowOpened(WindowEvent e){}
}