package paas.client.gui;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;

public class UsersList extends JList implements MouseListener
{
  private Vector usersList;
  private Vector icons;
  private ClientGUI parent;
  WhisperDialog wd;
  private Vector whisperGroup = new Vector();

  public UsersList(ClientGUI parent)
  {
    this.parent = parent;
    this.addMouseListener(this);
  }
  private void updateList()
  {
    this.removeAll();
    this.setListData(usersList);
  }

  public void setUsersList(Vector v)
  {
    usersList = v;
    updateList();
    this.setCellRenderer(new UserCellRenderer());
  }

  public void setUsersIcon(Vector ic)
  {
    icons = ic;
  }

  class UserCellRenderer extends JLabel implements ListCellRenderer
  {
    Color highlightColor = new Color(0, 0, 128);

    UserCellRenderer()
    {
      setOpaque(true);
    }
    public Component getListCellRendererComponent(
              JList list,
              Object value,
              int index,
              boolean isSelected,
              boolean cellHasFocus)
    {
      if (index == -1)
      {
        int selected = list.getSelectedIndex();
        if (selected == -1)
          return this;
        else
          index = selected;
      }
      setText(" " + (String)usersList.elementAt(index));
      try {
        setIcon( (ImageIcon) icons.elementAt(index));
      }catch(ArrayIndexOutOfBoundsException e){}

      if(isSelected)
      {
         setBackground(highlightColor);
         setForeground(Color.white);
      }
      else
      {
         setBackground(Color.white);
         setForeground(Color.black);
       }
       return this;
    }
  }

  public void openWhisperDialog(String target, String message)
  {
    WhisperDialog d = checkTarget(target);
    if(d == null)
    {
      WhisperDialog w = new WhisperDialog(parent,target);
      whisperGroup.addElement(w);
      w.appendText(message);
      w.setVisible(true);
    }
    else
    {
      d.appendText(message);
      d.setVisible(true);
    }
  }

  public WhisperDialog checkTarget(String target)
  {
    for(int j =0; j < whisperGroup.size(); j++)
    {
      WhisperDialog wg = (WhisperDialog) whisperGroup.elementAt(j);
      if(wg.getTarget().equals(target))
      {
        return wg;
      }
    }
    return null;
  }

  public void mouseExited(MouseEvent e){}
  public void mouseEntered(MouseEvent e){}
  public void mouseReleased(MouseEvent e){}
  public void mousePressed(MouseEvent e){}
  public void mouseClicked(MouseEvent e)
  {
    if(e.getClickCount() == 2)
    {
      int index = this.getSelectedIndex();
      if(index != -1 || index > 0)
      {
        String target = (String) this.getModel().getElementAt(index);
        if(target != null)
        {
          WhisperDialog d = checkTarget(target);

          if(d == null)
          {
            wd = new WhisperDialog(parent,target);
            whisperGroup.addElement(wd);
          }
          else
          {
            d.setVisible(true);
          }
        }
      }
    }
  }
}