package paas.client;

public class ClientPacket implements java.io.Serializable
{
  private boolean isMessage;

  private User user = null;
  private Message msg = null;
  private String exception = null;
  private boolean isping;

  public ClientPacket()
  {
  }

  public void setIsMessage(boolean im)
  {
    this.isMessage = im;
  }

  public void setUser(User u)
  {
    this.user = u;
  }

  public void setMessage(Message m)
  {
    this.msg = m;
  }

  public void setIsPing(boolean ip)
  {
    this.isping = ip;
  }

  public boolean isMessage()
  {
    return isMessage;
  }

  public User getUser()
  {
    return user;
  }

  public Message getMessage()
  {
    return msg;
  }

  public void setException(String exp)
  {
    this.exception = exp;
  }
  public String getException()
  {
    return exception;
  }

  public boolean isPing()
  {
    return isping;
  }
}