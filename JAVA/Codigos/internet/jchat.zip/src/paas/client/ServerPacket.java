package paas.client;

import java.net.*;
import java.io.*;

public class ServerPacket implements java.io.Serializable
{
  private boolean islogin;
  private boolean isregister;
  private boolean isMessage;

  private User user = null;
  private String exception = null;
  private Message msg = null;

  public ServerPacket()
  {
  }
  public void setIsLogin(boolean il)
  {
    this.islogin = il;
  }

  public void setIsRegister(boolean ir)
  {
    this.isregister = ir;
  }

  public void setIsMessage(boolean im)
  {
    this.isMessage = im;
  }

  public void setUser(User u)
  {
    this.user = u;
  }

  public void setMessage(Message m)
  {
    this.msg = m;
  }

  public boolean getIsLogin()
  {
    return islogin;
  }

  public boolean getIsRegister()
  {
    return isregister;
  }

  public boolean getIsMessage()
  {
    return isMessage;
  }

  public User getUser()
  {
    return user;
  }

  public Message getMessage()
  {
    return msg;
  }

  public void setException(String exp)
  {
    this.exception = exp;
  }
  public String getException()
  {
    return exception;
  }

}