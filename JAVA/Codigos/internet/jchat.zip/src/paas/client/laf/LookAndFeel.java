package paas.client.laf;
import javax.swing.*;
import java.io.*;
import com.l2fprod.gui.plaf.skin.*;

public class LookAndFeel
{
  public LookAndFeel()
  {
    try
    {
      Skin skin = new CompoundSkin(SkinLookAndFeel.loadThemePack("skins/themepack.zip"),SkinLookAndFeel.loadThemePack("skins/themepack.zip"));
      SkinLookAndFeel.setSkin(skin);
      UIManager.setLookAndFeel("com.l2fprod.gui.plaf.skin.SkinLookAndFeel");
    }
    catch(Exception ex){}
  }
  public static void setAquaTheme()
  {
    try
    {
      Skin skin = new CompoundSkin(SkinLookAndFeel.loadThemePack("skins/aquathemepack.zip"),SkinLookAndFeel.loadThemePack("skins/aquathemepack.zip"));
      SkinLookAndFeel.setSkin(skin);
      UIManager.setLookAndFeel("com.l2fprod.gui.plaf.skin.SkinLookAndFeel");
    }
    catch(Exception ex){}
  }
  public static void setBeosTheme()
  {
    try
    {
      Skin skin = new CompoundSkin(SkinLookAndFeel.loadThemePack("skins/beosthemepack.zip"),SkinLookAndFeel.loadThemePack("skins/beosthemepack.zip"));
      SkinLookAndFeel.setSkin(skin);
      UIManager.setLookAndFeel("com.l2fprod.gui.plaf.skin.SkinLookAndFeel");
    }
    catch(Exception ex){}
  }
  public static void setModernTheme()
  {
    try
    {
      Skin skin = new CompoundSkin(SkinLookAndFeel.loadThemePack("skins/modernthemepack.zip"),SkinLookAndFeel.loadThemePack("skins/modernthemepack.zip"));
      SkinLookAndFeel.setSkin(skin);
      UIManager.setLookAndFeel("com.l2fprod.gui.plaf.skin.SkinLookAndFeel");
    }
    catch(Exception ex){}
  }
  public static void setWhistlerTheme()
  {
    try
    {
      Skin skin = new CompoundSkin(SkinLookAndFeel.loadThemePack("skins/whistlerthemepack.zip"),SkinLookAndFeel.loadThemePack("skins/whistlerthemepack.zip"));
      SkinLookAndFeel.setSkin(skin);
      UIManager.setLookAndFeel("com.l2fprod.gui.plaf.skin.SkinLookAndFeel");
    }
    catch(Exception ex){}
  }
  public static void setXPTheme()
  {
    try
    {
      Skin skin = new CompoundSkin(SkinLookAndFeel.loadThemePack("skins/xplunathemepack.zip"),SkinLookAndFeel.loadThemePack("skins/xplunathemepack.zip"));
      SkinLookAndFeel.setSkin(skin);
      UIManager.setLookAndFeel("com.l2fprod.gui.plaf.skin.SkinLookAndFeel");
    }
    catch(Exception ex){}
  }
}