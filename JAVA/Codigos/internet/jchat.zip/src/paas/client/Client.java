package paas.client;

import paas.client.gui.*;
import paas.client.laf.LookAndFeel;

public class Client
{
  public Client()
  {
    new LookAndFeel();
    new Splash();
  }
  public static void main(String [] args)
  {
    new Client();
  }
}