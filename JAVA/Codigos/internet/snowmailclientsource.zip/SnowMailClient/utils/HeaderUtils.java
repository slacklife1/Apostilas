package SnowMailClient.utils;

import SnowMailClient.model.*;

import java.util.*;
import java.text.*;
import java.io.*;

public class HeaderUtils
{

  public HeaderUtils()
  {

  } // Constructor


  /** gets the charset from the header.
      It is dissimulated in the content-type entry, within some other datas
  */
  public static String getHeader_Charset_entry(Header header) throws Exception
  {
    String ct = header.getEntryValue("Content-Type", "").toUpperCase();
    int pos = ct.indexOf("CHARSET=");
    if(pos>=0)
    {
      String cs = ct.substring(pos+8).trim();
      
      // maybe starts with quotes
      if(cs.startsWith("\"")) cs = cs.substring(1);

      // maybe  utf-8;***
      pos = cs.indexOf(";");
      if(pos>0) cs = cs.substring(0,pos);

      // maybe ends with quotes
      if(cs.endsWith("\"")) cs = cs.substring(0,cs.length()-1);
      return cs;
    }       
    return "iso-8859-1";
  }           


} // HeaderUtils
