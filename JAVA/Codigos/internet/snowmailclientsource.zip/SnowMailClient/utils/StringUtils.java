package SnowMailClient.utils;

public class StringUtils
{

  public StringUtils()
  {

  } // Constructor



  /** used for example to detect html files (starting with <html>)
    ignores the blanks at the text start
  */
  public static boolean startsWithIgnoresCaseAndBlanks(String text, String start)
  {   
    // Can be boost with Knuth's algorithm for fast search... ###
    for(int i=0; i<text.length()-start.length(); i++)
    {                    
       //System.out.println("\""+text.substring(i, i+start.length())+"\"");
       if( text.substring(i, i+start.length()).equalsIgnoreCase(start)) return true;

       if( text.charAt(i)==' ' || text.charAt(i)=='\r' || text.charAt(i)=='\n'
           || text.charAt(i)=='\t') continue;
       break;
    }
    return false;
  }

  /** finds the index of <tagName
     @return the position of the first letter of the tag, not <  
  */
  public static int indexOfStartTagIgnoreCase(String text, String tagName)
  {
    for(int i=0; i<text.length()-tagName.length(); i++)
    {                          
      if(text.charAt(i)=='<')
      {
         String tt = text.substring(i+1,i+1+tagName.length());
         //System.out.println("."+tt+".");
         if(tt.compareToIgnoreCase(tagName)==0) return i+1;
      }               
    }
    return -1;
  }  
                          
  /** finds the index of tagName>  
     @return the position of >
  */
  public static int indexOfEndTagIgnoreCase(String text, String tagName)
  {
    for(int i=tagName.length(); i<text.length(); i++)
    {
      if(text.charAt(i)=='>')
      {
         String tt = text.substring(i-tagName.length(), i);
         //System.out.println("."+tt+".");
         if(tt.compareToIgnoreCase(tagName)==0) return i;
      }
    }
    return -1;
  }     
  
  
  public static String toString(byte[] array)
  {   
    if(array==null) return "null";
    if(array.length==0) return "{}";
    StringBuffer sb = new StringBuffer("{");
    for(byte b:array)
    {
      sb.append(""+b);
      sb.append(", ");

    }
    return sb.substring(0, sb.length()-2)+"}";    
  }

  public static void main(String[] a)
  {
    System.out.println(indexOfStartTagIgnoreCase("<br>  \r\t\n   <br><p>   <html>", "bR"));
  }

} // StringUtils
