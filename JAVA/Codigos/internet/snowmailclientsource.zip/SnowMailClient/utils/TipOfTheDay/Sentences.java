    
package SnowMailClient.utils.TipOfTheDay;

public final class Sentences
{

  public Sentences()
  {

  } // Constructor
   /*
  String[][] surrealistes = 
    {
      {"Esquivons les ecchymoses des esquimaux aux mots exquis.", ""}
    };

  String[][] philo =
    {
      {"Planung bedeutet, den Zufall durch den Irrtum zu ersetzen.", "Peter Ustinov"},
      {"L'univers et la b�tise humaine sont infinis."
      +"Je ne suis pas sur quand � ce que j'avance � propos de l'univers.", "Albert Einstein"}

    };  */

} // Sentences
