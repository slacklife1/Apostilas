package SnowMailClient.utils;

import java.util.*;
import java.nio.*;
import java.nio.charset.*;

public class CharsetUtils
{

  public CharsetUtils()
  {

  } // Constructor

  /** @return true if the text can be encoded using the given charset.
  */
  public static boolean isEncodingSupported(String text, String charsetName)
  {
    try
    {
      Charset charset = Charset.forName(charsetName);
      CharsetEncoder ce = charset.newEncoder();
      //ce.onUnmappableCharacter(CodingErrorAction.REPORT);  // Cause exception
      return ce.canEncode(text);
      //return true;
    }
    catch(Exception e)
    {
      //System.out.println("Cannot encode "+e.getMessage());
      return false;
    }
  }

  public static int getFirstEncodingError(String text, String charsetName)
  {
      Charset charset = Charset.forName(charsetName);
      CharsetEncoder ce = charset.newEncoder();
      for(int i=0; i<text.length(); i++)
      {
        if(!ce.canEncode(text.charAt(i))) return i;
      }        
      
      return -1;
   }


  /** return a suitable charset name for encoding the text
      try first 7bit, 8bit, 9bit
  */
  public static String getMinimalEncodingCharset(String text)
  {
    String[] charsets = new String[]{"us-ascii", "iso-8859-1", "iso-8859-2", "iso-8859-4", "utf-8"};
    for(String cs : charsets)
    {
      if(isEncodingSupported(text, cs)) return cs;
    }

    // SHOULD NEVER OCCURS                        
    System.out.println("NO CHARSET FOUND ????????????");
    return "utf-8";
  }

  public static void main(String[] a )
  {
    System.out.println(isEncodingSupported("���", "us-ascii"));
    System.out.println(isEncodingSupported("����\u0106", "iso-8859-1"));
    System.out.println(isEncodingSupported("����", "iso-8859-2"));
                       
    System.out.println(getMinimalEncodingCharset("ABC"));
    System.out.println(getMinimalEncodingCharset("ABC���"));
    System.out.println(getMinimalEncodingCharset("ABC\u0106"));
    System.out.println(getMinimalEncodingCharset("ABC\u0106����"));

  }


} // CharsetUtils
