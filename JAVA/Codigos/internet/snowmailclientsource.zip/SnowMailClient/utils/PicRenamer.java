package SnowMailClient.utils;

import java.io.*;
import java.nio.*;                                                                                                 
import java.util.*;
import javax.imageio.*;
import java.awt.image.*;


/** convert/rewrite all images to PNG and jpeg in a directory and subdirectories

    PNG => PNG
    the rest => JPEG

    Goal: progressive jpegs cause JVM crash when embedded in jar files !!

*/
public class PicRenamer    
{
                        
  public PicRenamer(File base)
  {                            
    Vector<File> im = new Vector<File>();
    getImagesRecurse(im, base);      
    
    System.out.println(""+im.size()+" images found in "+base.getAbsolutePath());
                                    
    String[] wfn = ImageIO.getWriterFormatNames();
    System.out.println("Supported Write Format");
    for(int i=0; i<wfn.length; i++)
    {
      System.out.println("   "+wfn[i]);
    }                                                                                                                                            
    System.out.println(".\n");

    for(int i=0; i<im.size(); i++)
    {
      try{
       convertFiles((File) im.elementAt(i));                                                                             
      } catch(Exception e) {e.printStackTrace();}
    }
                                                                                                                          
                               
                                          
  } // Constructor

                                                                                                                                                          
  /** convert GIF in PNG and rewrite jpegs    
  */
  public void convertFiles(File in) throws Exception
  {
    BufferedImage im = ImageIO.read(in);
    String outName = in.getAbsolutePath();
    int posPt = outName.lastIndexOf(".");   
    String originalExtension = outName.substring(posPt+1).toUpperCase();

    // delete the original
    in.delete();

    if(originalExtension.equals("PNG") || originalExtension.equals("GIF"))
    {
      outName = outName.substring(0,posPt) + ".PNG";
      //System.out.println("writing "+outName);
      ImageIO.write(im, "PNG", new File(outName));
    }
    else
    {
      outName = outName.substring(0,posPt) + ".JPEG";
      System.out.println("writing "+outName);
      ImageIO.write(im, "JPEG", new File(outName));
    }
  }  
  


  public void getImagesRecurse(Vector<File> im, File base)
  {
    for(File fi : base.listFiles())
    {
       if(fi.isDirectory())
       {
         getImagesRecurse(im, fi);
       }
       else
       {
         String name = fi.getName().toUpperCase();
         if(name.endsWith(".JPG")) im.add(fi);
         if(name.endsWith(".BMP")) im.add(fi);
         if(name.endsWith(".PNG")) im.add(fi);
         if(name.endsWith(".GIF")) im.add(fi);
       }                                                  
    }
  }                                                                                                               
                                                                                                                        
 /**  
  *  Static main method
  */ 
  public static void main( String[] arguments )
  {                                                  
     new PicRenamer(new File("e:/temp/st"));
  } // main



} // PicRenamer
