package SnowMailClient.utils.storage;

import SnowMailClient.SnowMailClientApp;
import snow.utils.gui.*;
import snow.Language.Language;

import snow.utils.storage.*;

import java.util.*;
import java.util.zip.*;
import java.io.*;                                                                        
import javax.swing.*;
import java.text.*;
               
/**
  @todo: ## verify that destination is not in the backuped folders !!
*/            
public final class Backup implements Vectorizable
{                        
  long lastBackup = 0;                                                                        
  long minTimeBetweenTwoBackups = 1000*60*5;  // 5 minutes
  private String destinationBackupFolder = "";
  boolean isAutomaticBackupEnabled = true;

  public Backup()
  {
     if(System.getProperty("os.name", "Windows").indexOf("Windows")>0)
     {
        destinationBackupFolder = "c:/SnowMailBackup/";
     }
     else
     {  
        // linux
        destinationBackupFolder = System.getProperty("user.home",".")
                       + File.pathSeparator + "SnowMailBackup" + File.pathSeparator;
     }
  } // Constructor
  
  public String getBackupDestinationDirectory() 
  {
    return destinationBackupFolder;
  }  
  
  public void setBackupDestination(String destinationBackupFolder)
  {
    this.destinationBackupFolder = destinationBackupFolder;
  }        

  public boolean isAutomaticBackupEnabled()
  {
    return isAutomaticBackupEnabled;
  }
  
  public void setIsAutomaticBackupEnabled(boolean is)
  {
    isAutomaticBackupEnabled = is;
  }

  public synchronized void checkDoBackup()
  {                    
     long now = new Date().getTime();
     if(isAutomaticBackupEnabled && (now-lastBackup > minTimeBetweenTwoBackups))
     {
        doBackupNow();
     }
     else
     {
        System.out.println("No backup to do, last was made = "+new Date(lastBackup));
     }
  }
  
  

  public synchronized void doBackupNow()
  {                       
    if( SwingUtilities.isEventDispatchThread() )
    {                 
       throw new RuntimeException("Must be called from another thread than EDT");
    }

    File destFolder = new File(destinationBackupFolder);
    if(!destFolder.exists())
    {
       destFolder.mkdirs();
    }                                                                     

    File backupFile = new File(destinationBackupFolder, getActualBackupName()+"SnowMailBackup.zip");
    final ProgressModalDialog progress = new ProgressModalDialog(SnowMailClientApp.getInstance(), "Backup", false);
    progress.setCommentLabel(Language.translate("Saving opened folders")+"...");
    progress.start();
                              

    SnowMailClientApp.getInstance().saveAllMails(false);
                                       
    progress.setCommentLabel(backupFile.getAbsolutePath());


    synchronized( FileUtils.getLockForFileAccess() )
    { 
      FileOutputStream fos = null;
      ZipOutputStream zos = null;  
      try   
      {
        fos = new FileOutputStream(backupFile);
        zos = new ZipOutputStream(fos);  
        Vector<File> allFiles = new Vector<File>();
        File rootFile = SnowMailClientApp.getInstance().getSnowMailRoot();
        FileUtils.getAllFilesRecurse(rootFile, allFiles);                
        progress.setProgressBounds(allFiles.size());
                                                                    
        for(int i=0; i<allFiles.size(); i++)
        {  
           if(progress.wasCancelled()) break;
           
           // Thread.sleep(100);                                          
           
           File file = (File) allFiles.elementAt(i);
           progress.setProgressValue(i, ""+file.getName());
           String relativeName = file.getAbsolutePath();
           relativeName = relativeName.substring(
              rootFile.getParentFile().getAbsolutePath().length()+1,
              relativeName.length());

           FileUtils.addToZip(zos, file, relativeName);
        }               

      }                                                                
      catch(Exception e)
      {                                 
        e.printStackTrace();                                               
      }
      finally                                                         
      {                                                                
        if(zos!=null) try{ zos.close(); } catch(Exception ee) { ee.printStackTrace(); }
        if(fos!=null) try{ fos.close(); } catch(Exception ee) { ee.printStackTrace(); }

        progress.closeDialog();
      }
    }
    lastBackup = new Date().getTime();
    
    organizeBackupArchive(new File(destinationBackupFolder));
  }                       


  private void organizeBackupArchive(File base)
  {
     //1) list all backup files
     Vector<File> allBackups = new Vector<File>();
     getAllBackups(base, allBackups);
     //System.out.println("There are "+allBackups.size()+" backups to reorganize.");

     if(allBackups.size()<3)
     {
       return;
     }


     // 2) sort, first = last backup
     Collections.sort(allBackups, new Comparator<File>()
     {
        public int compare(File file1, File file2)
        {
           if(file1.lastModified() == file2.lastModified()) return 0;
           if(file1.lastModified() > file2.lastModified()) return -1;
           return 1;
        }
     });

     long lastBackupTime = ((File) allBackups.firstElement()).lastModified();
     long oldestBackupTime = ((File) allBackups.lastElement()).lastModified();
     //System.out.println("Oldest backup = "+new Date(oldestBackupTime));
     //System.out.println("Last backup (Age=0) = "+new Date(lastBackupTime));
     
     // Sort in the various categories (age 0 is the youngest archive)
     //
     Vector<File> youngerThanHour  = new Vector<File>();  // keep all               (usually 1)
     Vector<File> youngerThanDay   = new Vector<File>();  // keep at most one each 3 hour   (max 6)
     Vector<File> youngerThanWeek  = new Vector<File>();  // keep at most one each day      (max 7)
     Vector<File> youngerThanMonth = new Vector<File>();  // keep at most one each week     (max 5)
     Vector<File> olderThanMonth   = new Vector<File>();  // keep at most one per month     (12 per year)

     for(int i=0; i<allBackups.size()-1; i++)
     {
        File file = allBackups.elementAt(i);
        long time = file.lastModified();                                                         

        // 1 find age category (day, week, month)
        long ageFromNowSec = (lastBackupTime-time)/1000;
        //System.out.println("Age = "+ageFromNowSec+" s");
               

        if(ageFromNowSec<3600)
        {
           youngerThanHour.add(file);                                                                                                         
        }
        else if(ageFromNowSec<24*3600)
        {
           youngerThanDay.add(file);
        }
        else if(ageFromNowSec<7*24*3600)
        {
           youngerThanWeek.add(file);
        }
        else if(ageFromNowSec<30*24*3600)
        {
           youngerThanMonth.add(file);
        }
        else
        {
           olderThanMonth.add(file);
        }
     }                                                                                                                           
     
     if(false)
     {
       System.out.println("Backup structure before reordering\n<begin>");
       System.out.println("   younger than 1 hour  : "+youngerThanHour.size());
       System.out.println("   younger than 1 day   : "+youngerThanDay.size());
       System.out.println("   younger than 1 week  : "+youngerThanWeek.size());
       System.out.println("   younger than 1 month : "+youngerThanMonth.size());
       System.out.println("   older than 1 month   : "+olderThanMonth.size());
       System.out.println("<end>");
     }

     purge(youngerThanDay,   3600* 3);
     purge(youngerThanWeek,  3600*24);
     purge(youngerThanMonth, 3600*24* 7);
     purge(olderThanMonth,   3600*24*30);

  }

  /**
  */
  private void purge(Vector<File> files, long minDistanceSec)
  {
     if(files.size()<3) return;  // requires at least tree, otherwise keep all (0 or 1 or 2)

     long t0 = ((File) files.lastElement()).lastModified();  // oldest backup

     for(int i=files.size()-2; i>=1; i--)   // keep the first and the last
     {
        File file = (File) files.elementAt(i);
        //System.out.println("Purging "+file);

        long ti = file.lastModified();
        long distSec = (ti-t0)/1000;
        if(distSec < minDistanceSec)
        {
          //System.out.println("     Deleting "+file);
          if(!file.delete()) {file.deleteOnExit();}
        }
        else
        { 
          // keep
          t0 = ti;
        }
     }
  }


  private void getAllBackups(File folder, Vector<File> files)
  {
     File[] backupFiles = folder.listFiles(new FilenameFilter()
     {
       public boolean accept(File dir, String name)
       {
          return name.toUpperCase().endsWith("SNOWMAILBACKUP.ZIP");
       }
     });

    files.addAll(Arrays.asList(backupFiles));
  }

  
                            
  public String getActualBackupName()
  {
     SimpleDateFormat sdf = new SimpleDateFormat("yyyy MM dd HH'h'mm", Locale.ENGLISH);
     String userName = System.getProperty("user.name", "home");
     return sdf.format(new Date()) + " ("+userName+")";
  }                                                                                              

  // Vectorizable
  //
                                                                                               
  public Vector<Object> getVectorRepresentation() throws VectorizeException
  {
     Vector<Object> v = new Vector<Object>();
     v.addElement(2);    //0: version
     v.addElement(destinationBackupFolder);
     v.addElement(minTimeBetweenTwoBackups);
     v.addElement(lastBackup);
     v.addElement(isAutomaticBackupEnabled);
     return v;
  }

  public void createFromVectorRepresentation(Vector<Object> v) throws VectorizeException
  {
     int version = (Integer) v.elementAt(0);
     if(version==1)
     {
        destinationBackupFolder = (String) v.elementAt(1);
        minTimeBetweenTwoBackups = (Long) v.elementAt(2);
        lastBackup = (Long) v.elementAt(3);
     }
     else if(version==2)
     {
        destinationBackupFolder = (String) v.elementAt(1);
        minTimeBetweenTwoBackups = (Long) v.elementAt(2);
        lastBackup = (Long) v.elementAt(3);
        isAutomaticBackupEnabled = (Boolean) v.elementAt(4);
     }
     else
     {
        throw new VectorizeException("Bad version "+version);
     }
  }



} // Backup
