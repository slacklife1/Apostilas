package SnowMailClient.utils;

import SnowMailClient.crypto.Utilities;
import snow.utils.storage.*;
import SnowMailClient.model.Header;
import SnowMailClient.model.Address;
import SnowMailClient.model.HeaderEntry;
import java.util.*;
import java.text.*;
import java.io.*;
import java.text.SimpleDateFormat;


public final class MailMessageUtils
{                                            
   private static final SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss Z", Locale.ENGLISH);

   // used when parsing
   private static final SimpleDateFormat pdateFormat = new SimpleDateFormat("d MMM yyyy HH:mm:ss Z", Locale.ENGLISH);
   private static final SimpleDateFormat pbadButFrequentDateFormat  = new SimpleDateFormat("d MMM yyyy HH:mm:ss Z", Locale.ENGLISH);
   private static final SimpleDateFormat pbadButFrequentDateFormat2  = new SimpleDateFormat("d MMM yyyy HH:mm:ss", Locale.ENGLISH);
   private static final SimpleDateFormat pbadButFrequentDateFormat3 = new SimpleDateFormat("d MMM yyyy HH:mm Z", Locale.ENGLISH);
   private static final SimpleDateFormat pbadButFrequentDateFormat4 = new SimpleDateFormat("MM.dd.yyyy HH:mm:ss", Locale.ENGLISH);
                                                               
    /** correct format
         "14 Feb 2004 18:07:05 +0100"
        sometimes encountered
         "28 Dec 2003 11:05:44 -0000"
         "16 Mar 2004 17:41:59 -00"
         TODO####  '01 Jun 2004 21:39 -0700'
         05 Jun 2004  1:10 -0700
         // ONLY ONCE: Fri, 29 Oct 2004 08:47:14
         
         Tuesday, 17 Jan 2006 09:35:04 +01:00     //bad : at the end
         //Jan2006: 
         
         Cannot parse date from 'Fr, 24 Jun 2005 03:55:07'
    */
   public final static String msgDateFormat(Date date)
   {
     return dateFormat.format(date);
   }

   /** Sometimes encountered: %CURRENT_DATE_TIME 
   
   */
   public final static Date parseDateFromString(String s) throws Exception
   { 
     // remove the day name, if any (always , separated)
     int posComa = s.indexOf(",");
     if(posComa>=0)
     {
       s = s.substring(posComa+1).trim();
     }     
     
     try
     {
       return pdateFormat.parse(s);
     }
     catch(Exception e1)
     {
       try
       {
         return pbadButFrequentDateFormat.parse(s);
       }
       catch(Exception e2)  {  }

       try                      
       {
         return pbadButFrequentDateFormat2.parse(s);
       }
       catch(Exception e2)  {  }

       try                      
       {
         return pbadButFrequentDateFormat3.parse(s);
       }
       catch(Exception e2)  {  }
       
       try                      
       {
         return pbadButFrequentDateFormat4.parse(s);
       }
       catch(Exception e2)  {  }
              
       try
       {
         return pdateFormat.parse(s+"00");
       }                      
       catch(Exception e3)  {  }
       

       
       if(s.equalsIgnoreCase("%CURRENT_DATE_TIME")) return new Date();
       
       if(s.endsWith(":00"))
       {
          // rare, but occurs, bad z   (or correct seconds...)
          return parseDateFromString(s.substring(0,s.length()-3));                  
       }       
     }
     
     throw new Exception("Cannot parse date from "+s);
   } 
    
/**
 zmailer
 Message-Id: <19980601143757Z2848-6117+4@nic.funet.fi>
              YYYYMMDDhhmmssZnnnn-nnn+nn@hostname     
*/
   public static String createMessageID(Address address)
   {
     int rand = (int)(Math.random()*1e8);
     return "<"+rand+"."+address.getMailAddress()+">";

     //return "<AAA"+rand+"BBB@62.65.146.182>";

     //return "<EOECLIBDGGBLJBCOFBJLEEDPCAAA."+address.getMailAddress()+">";
     //return "<EOECLIBDGGBLJBCOFBJLMEDPCAAA."+address.getMailAddress()+">";

   }

   public static final DecimalFormat formatSize0 = new DecimalFormat("0.0");
   public static final DecimalFormat formatSize = new DecimalFormat("0");
   
   public static String formatSize(long size)
   {
      if(size>3000000) return ""+formatSize.format(size/1000000.0) +" MB";
      if(size>1000000) return ""+formatSize0.format(size/1000000.0) +" MB";
      if(size>3000) return ""+formatSize.format(size/1000.0) +" kB";
      if(size>1000) return ""+formatSize0.format(size/1000.0) +" kB";
      return ""+(size) +" B"; 
   }
   
   
   /** parse the to string and strip out the mail address from "some name <address@somewhere>"
    * @return   someone@somewhere.yes
    */
   public static String grabAddress(String addddressssssss)
   {
      // kill white space
      String strToCmd = addddressssssss.trim();

      // check if the address contains a < if so then just use whats inside
      // otherwise use the address given
      int intFoundStart = strToCmd.indexOf('<');
      if (intFoundStart != -1)
      {   
         // found it strip everything from inside
         int intFoundEnd = strToCmd.indexOf('>');
         if (intFoundEnd != -1)
         {
            return strToCmd.substring(intFoundStart+1,intFoundEnd).trim();
         }
         else
         {
            return strToCmd.substring(intFoundStart+1,strToCmd.length()).trim();
         }
      }
      else
      {
         // not found - use as is
         return strToCmd;
      }
   }

    
   /** I saw 5 variants 
         =?iso-8859-1?q?ugly=20est=20la?=    ==>  "ugly est la"
         =?iso-8859-1?B?bej2gej1ot431re?=    ==>  decode base 64(bej2gej1ot431re)
         =?utf-8?B?TWljcm9zb2Z0IE91dGxvb2sgVGVzdCBNZXNzYWdl?=
         [La Lettre] =?ISO-8859-1?Q?Num=E9ro?=_=?ISO-8859-1?Q?sp=E9cial?=
         =?windows-1252?Q? Frage H=E4uschen Lofoten ab 060704?=    // #### not implemented...
         
         WARNING: THIS ONLY DECODE THE FIRST.

         Subject: [Sondage: les sentiments des =?ISO-8859-1?Q?Fran=E7ais?= =?ISO-8859-1?Q?=E0?= l'=?ISO-8859-1?Q?=E9gard?= de l'Europe]
   */                                  
   public static String decodeCharsetCodedArgument_(String arg)
   {                         
      int beginOffest = 15;
      int begCode =0;

      String charset = "iso-8859-1";  // default
      if((begCode = arg.toLowerCase().indexOf("=?iso-8859-1?"))!=-1)
      {
         beginOffest = begCode+15;
         charset = "iso-8859-1";
      }
      else if((begCode = arg.toLowerCase().indexOf("=?utf-8?"))!=-1)
      {
         beginOffest = begCode+10;
         charset = "utf-8";
      }
      else
      {
         // not encoded
         return arg;
      }     

      if(arg.length()<beginOffest+1)
      {
         return arg; // error...
      }

      // search for the coded portion delimiter end
      int posEnd = arg.indexOf("?=", beginOffest+3);
      if(posEnd==-1) return arg; // error
      if(beginOffest>=arg.length()) return arg;  // error

      String coded = arg.substring(beginOffest, posEnd);        //## out of bounds -1 ########



      char chat = arg.charAt(beginOffest-2);
      if(chat=='q' || chat=='Q')
      {     
         coded = decodeQuotedPrintable(coded, charset);
      }
      else if(chat=='b' || chat=='B')
      {
         try
         {
           coded = new String(Utilities.decodeBase64(coded), charset);
         }
         catch(Exception e)
         {
           e.printStackTrace();
           return arg;   
         }
      }
      else
      {
        return arg; // error
      }

      return arg.substring(0,begCode) + coded + arg.substring(posEnd+2);
   }   
   

   /** decode quoted printable text
   */
   public static String decodeQuotedPrintable(String in, String charset)
   {
     StringBuffer sb = new StringBuffer(in);
     ByteArrayOutputStream bos = new ByteArrayOutputStream();
                        
     for(int i=0; i<sb.length(); i++)
     {
       char ci = sb.charAt(i);
       
       // ignore
       if(ci == '\r') continue;
       

       if(ci != '=')
       {
          bos.write((byte) ci);
       }
       else
       {
          int end = i+3;
          if(end>sb.length()) end = sb.length();
          String code = sb.substring(i+1, end);
          if(code.equals("\r\n"))  // ignore
          {             
             i+=2;
          }
          else if(code.startsWith("\n"))  // ignore
          {
             i+=1;
          }
          else
          {
             // parse char code
             try
             {
                bos.write((byte) Integer.parseInt(code, 16));
                i+=2;
             }
             catch(NumberFormatException e)
             {         
               // System.out.println("Cannot parse quoted printable code '"+code+"'");
                //e.printStackTrace();
             }
          }
       }
     }
             
     try
     {
       return new String(bos.toByteArray(), charset);
     }
     catch(Exception e)
     {
       return in;
     }
   }


   /** return false if one of the bytes is outside of [0,127]
     char [  0 : 127] <> byte[   0 : 127]
     char [128 : 255] <> byte[-128 :  -1]
   */
   public static boolean is7Bits(byte[] chars)
   {
     if(chars==null) return true;

     for(byte c: chars)
     {
       if(c>127) return false;
       if(c<0) return false;
     }
     return true;
   } 
   

   public static int byteCharToInt(byte b)
   {
     if(b<0) return 256+b;
     return b;
   }

   /** encode the chars with values above 7 bits according to the quoted printable definition
       //the return bytes are 7 bits => can be get with getBytes("us-ascii");
   */
   public static byte[] encodeMessageQuotedPrintable(byte[] bytes)
   {                                 
       StringBuffer reply = new StringBuffer(); 
       int lineLength = 0;                      
       for(int i=0; i<bytes.length; i++)
       {
         int ci = byteCharToInt(bytes[i]);
         
         if(ci==61)  // =
         {                          
           lineLength += 3;
           reply.append("="+getHexa(61));
         }
         else if(ci>=32 && ci<=126)
         {
           lineLength++;
           if(lineLength>76)  
           {
              reply.append("=\r\n");  // soft break.
              lineLength = 0;
           }  

           reply.append((char) ci);

         }
         else if(ci==10)  // "\n"
         {
           lineLength += 3;
           if(lineLength>76)
           {
                reply.append("=\r\n");
                lineLength = 0;
           }
           reply.append("=0A");

         }
         else
         {
           lineLength += 3;
           if(lineLength>76)
           {
                reply.append("=\r\n");
                lineLength = 0;
           }
           reply.append("=");
           reply.append(getHexa(ci));
         }
       
       } // end loop over the bytes
       
       try
       {
         return reply.toString().getBytes("us-ascii");
       }
       catch(Exception e)
       {
         return reply.toString().getBytes();
       }
   }  


   /** encode single lines, as appearing in the header.
       For the subject and addressees
       Encodes only if necessary...
       wraps the "=?utf-8?q?" + CODED TEXT + "?="
   */
   public static String encodeLine_QuotedPrintable(String text)
   {
     boolean needed = false;
     String charset = CharsetUtils.getMinimalEncodingCharset(text);

     StringBuffer reply = new StringBuffer();
     byte[] textBytes = null;
     try                   
     {
       textBytes = text.getBytes(charset);  // utf-8
     }
     catch(Exception e)
     {
       textBytes = text.getBytes(); // this will NEVER occur
     }

     for(byte b: textBytes)
     {
       int ci = byteCharToInt(b);
       //System.out.println(""+((int) ci));
       if (ci==61) // =
       {
         needed = true;
         reply.append("=");
         reply.append(getHexa(61));
       }
       else if(ci>=32 && ci<128)
       {
         reply.append((char)b);  // ok, no quote needed
       }
       else
       {              
         needed = true;
         reply.append("=");
         reply.append(getHexa(ci));
       }
     }

     if(needed)
     {
       // [March2005] was iso-8859-1 !
       return "=?"+charset+"?q?"+ reply.toString() +"?=";
     }
     else
     {
       return reply.toString();
     }
   }


   public static final String base16 = "0123456789ABCDEF";
   public static String getHexa(int val)
   {
     int first = val/16;
     int second = val-first*16;
     return ""+base16.charAt(first)+""+base16.charAt(second);
   }
   
   /** try recurse until whole sentence is decoded
   */
   public static String decodeCharsetCodedArgumentFully(String in)
   {
      int level = 0;
      String prec = in;
      while(level<20)
      {
        String dec = decodeCharsetCodedArgument_(prec);
        if(dec.equals(prec)) return dec;
        prec = dec;
        level++;  
      }   
      return prec;
   }

   public static void main(String[] aaa)
   {
       System.out.println("reply="+decodeCharsetCodedArgument_("=?iso-8859-1?q?hello=20I=20am?=AAABBB"));
       System.out.println("reply="+decodeCharsetCodedArgument_("=?iso-8859-1?B?c3VucmlzZSBlLU5ld3NsZXR0ZXI=?=UU"));
       System.out.println("reply="+decodeCharsetCodedArgument_("=?utf-8?B?TWljcm9zb2Z0IE91dGxvb2sgVGVzdCBNZXNzYWdl?="));
                                          
     
      String enc = encodeLine_QuotedPrintable("����");
      System.out.println(""+enc);              
      System.out.println(decodeCharsetCodedArgument_(enc));

      byte[] bytes = "\r\n".getBytes();                                                                         
      for(byte b: bytes)
      {
        int ib = byteCharToInt(b);          
        System.out.println(""+b+" "+ib);      
      }

      byte[] b = encodeMessageQuotedPrintable("Hello\r\nComment =\n vas t�?".getBytes());
      System.out.println("ENC="+new String(b));  
      System.out.println("DEC="+decodeQuotedPrintable(new String(b), "iso-8859-1"));
      
      System.out.println(msgDateFormat(new Date()));
      try
      {
        System.out.println(parseDateFromString("Tuesday, 17 Jan 2006 09:35:04 +01:00"));
        System.out.println(parseDateFromString("Fr, 24 Jun 2005 03:55:07"));
      } catch(Exception ex) {ex.printStackTrace();}
      
   }


}
