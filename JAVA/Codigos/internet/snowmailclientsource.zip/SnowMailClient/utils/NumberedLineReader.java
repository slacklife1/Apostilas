package SnowMailClient.utils;

import java.util.*;
import java.io.*;
         
         
/** the number is usually used a human-readable debug information
    this also stores a cache of the last line.
*/
public class NumberedLineReader extends BufferedReader
{         
  private int lineNumber = 0;
  private String lastLine = null;
  /** only for one line !
  */
  private boolean undo = false;
           

  public NumberedLineReader(String cont)
  {
     super( new StringReader( cont ) );     
  } // Constructor


  public final String readLine() throws IOException
  {
     if(undo)
     {
       undo = false;
     }
     else
     {
       lineNumber++;
       lastLine = super.readLine();
     }
     return lastLine;
  }

  /** this undoes the read of the last line.
   => the next readLine will return exactely the same line
  */
  public final void undoRead()
  {
    if(undo==true)         throw new RuntimeException("Only one undo allowed !");
    if(lastLine==null) throw new RuntimeException("No line to undo !");
    this.undo = true;
  }

  public final String getLastLineCached() { return lastLine; }

  public final int getLineNumber() { return lineNumber; }

} // NumberedLineReader
