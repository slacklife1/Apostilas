package SnowMailClient.GnuPG;

import SnowMailClient.model.*;
import snow.utils.gui.*;   
import snow.concurrent.*;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.GnuPG.model.*;
import SnowMailClient.Language.*;
import java.util.*;

/** used during send/receive
*/
public class MessageActions
{

  public MessageActions()
  {

  } // Constructor

  /** signing requires password
      ensures that it is available here.
      the mail will be signed on send
  */
  public static void prepare_Signing_Mail( MailMessage mess, Interrupter interrupter) throws Exception
  {
     String fromMailAddress = mess.getFromAddress().getMailAddress();
     GnuPGLink gpg = SnowMailClientApp.getInstance().getGnuPGLink();

     if(!gpg.isGPG_available())
     {
       throw new Exception(Language.translate("GnuPG is not available, please install it first or send without signing."));
     }

     GnuPGKeyID[] kids = gpg.getSecretKeyIDForAddress(fromMailAddress);
     if(kids.length==0) throw new Exception(Language.translate("No key to sign with %", fromMailAddress));

     byte[] pass = gpg.getPasswordForKeyAskIfNotFoundOrNotValid(kids[0], true, SnowMailClientApp.getInstance());
     if(pass==null) throw new Exception(Language.translate("No password given to sign with %", fromMailAddress));
               
     //mess.signContent(gpg, kids[0], pass, pmd);
     
     if(mess.getMimeTree().isMimeMessageFormat())
     {
       throw new Exception("Signing messages with attachement is not implemented yet !");
     }

     String signedTest = gpg.sign(mess.getCompleteContentAsString(), kids[0], pass, interrupter);


  }   


  /** ensures that all recipients have a public key available
  */
  public static void prepareEncryptMail(MailMessage mess) throws Exception
  {  
     Vector<Address> toMailAddress = mess.getToAddresses();
     if(toMailAddress.size()>1)
     {
       throw new Exception(Language.translate("Only one recipient is allowed for encrypted mail"));
     }

     GnuPGLink gpg = SnowMailClientApp.getInstance().getGnuPGLink();

     if(!gpg.isGPG_available()) 
     {
       throw new Exception(Language.translate("GnuPG is not available, please install it first or send without encrypting."));
     }
     
     StringBuffer errorBuffer = new StringBuffer();
     for(Address to: toMailAddress)
     {
        String toAddress = to.getMailAddress();
        GnuPGKeyID[] kids = gpg.getPublicKeyIDForAddress(toAddress);
        if(kids.length==0)
        {
          errorBuffer.append("\n" + toAddress);
        }
        else
        {
          // ### ask which ?
          GnuPGKeyID kid = kids[0];            
          String ct = kid.getCalculatedTrust();
          if(!(ct.equals("u") || ct.equals("f")))
          {
            errorBuffer.append("\n"+Language.translate("Bad trust for %", toAddress)+": "+kid.getCalculatedTrustMessage());
          }
        }
     }
     
     if(errorBuffer.length()>0)
     {
       throw new Exception(
       Language.translate("No public keys found for following recipient,\nplease import them first or do not encrypt.")
       +"\n"+errorBuffer.toString());
     }

  }   

} // MessageActions
