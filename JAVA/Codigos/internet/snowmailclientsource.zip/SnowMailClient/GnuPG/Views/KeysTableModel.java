package SnowMailClient.GnuPG.Views;

import snow.utils.storage.*;
import snow.SortableTable.*;
import SnowMailClient.Language.Language;
import SnowMailClient.GnuPG.model.*;
import SnowMailClient.GnuPG.GnuPGLink;

import java.util.*;
import java.awt.EventQueue;       
import java.text.*;

public final class KeysTableModel extends FineGrainTableModel
{ 
  private final Vector<GnuPGKeyID> keys = new Vector<GnuPGKeyID>();
  private boolean advancedMode = true;
                                                                                                                                            
  private static final String[] COLUMN_NAMES = new String[]{
     Language.translate("Type"),
     Language.translate("Trust"),
     Language.translate("Name"),                                                                                                       
     Language.translate("Mail address"),     
     Language.translate("Capabilities"),
     Language.translate("Created"),
     Language.translate("Expires") };

  private static final int[] PREFERED_COLUMN_WIDTHS = new int[]{6,7,16,20, 6, 7,7};

  public static final SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.ENGLISH);

  public KeysTableModel()
  {

  } // Constructor

  public void setKeys(TreeSet<GnuPGKeyID> k )
  {
     this.fireTableModelWillChange();
     keys.clear();
     keys.addAll(k);
     this.fireTableDataChanged();
     this.fireTableModelHasChanged();
  }

  public void addKeys(TreeSet<GnuPGKeyID> k )
  {                
     this.fireTableModelWillChange();
     keys.addAll(k);
     this.fireTableDataChanged();
     this.fireTableModelHasChanged();
  }                   
  
  /** refresh the model. Reread all keys.
      Use a trick because with GPG 1.4.0, the first time always fails after a key add or remove => do one dummy refresh

  */    
  public void refreshModel(GnuPGLink link)
  {
     this.fireTableModelWillChange();

     // reread the keys
     try
     { 
       // TRICK
       link.setGPGPath(link.getPathToGPG());
     }
     catch(Exception ignored) {}

     try
     {
       link.setGPGPath(link.getPathToGPG());
       keys.clear();
       keys.addAll( link.getAllPublicKeyIDs());
       if(advancedMode)
       {
         keys.addAll( link.getAllSecretKeyIDs());
       }
     }
     catch(Exception e) { throw new RuntimeException(e); }

     this.fireTableDataChanged();
     this.fireTableModelHasChanged();

  }

  public GnuPGKeyID getKeyAt(int pos)
  {
     return keys.elementAt(pos);
  }


  public int getRowCount()
  {
     return keys.size();
  }

  public int getColumnCount()
  {
     return COLUMN_NAMES.length;
  }

  public final Object getValueAt(int row, int column)
  {
     GnuPGKeyID k = keys.elementAt(row);
     if(column==0)
     {
       if(k.isSecret()) return Language.translate("Secret");
       return Language.translate("Public");
     }
     if(column==1)
     {
       if(k.isSecret()) return "";  // no meaning for secret keys !
       if(k.hasExpired()) return Language.translate("Expired");
       return k.getCalculatedTrust();
     }
     if(column==2) return k.getNames();
     if(column==3) return k.getMails();
     if(column==4) return k.getKeyCapabilities();
     if(column==5)
     {
       long ed = k.getCreationDate();
       if(ed==-1) return "";
       return dateFormat.format(ed);
     }
     if(column==6)
     {
       long ed = k.getExpirationDate();
       if(ed==-1) return "";
       return dateFormat.format(ed);
     }
     return "?";
  }

  public String getColumnName(int col)
  {
     return COLUMN_NAMES[col];
  }
                                              
/* Let the default implementation do their job correctly...

  public boolean hitForTextSearch(int row, String txt)
  {
    return true;
  }

  public int compareForColumnSort(int pos1, int pos2, int col)
  {
                      
  }*/
  public void setAdvancedMode(boolean is, GnuPGLink link)
  {
    advancedMode = is;
    this.refreshModel(link);
  }
  
  public int getPreferredColumnWidth(int column)
  {                          
    return PREFERED_COLUMN_WIDTHS[column];
  }


} // KeysTableModel
