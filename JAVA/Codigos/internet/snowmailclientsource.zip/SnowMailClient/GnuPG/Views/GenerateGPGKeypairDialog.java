package SnowMailClient.GnuPG.Views;


import SnowMailClient.GnuPG.*;
import SnowMailClient.GnuPG.Main.GnuPGCommands;
import SnowMailClient.Language.Language;
import SnowMailClient.SnowMailClientApp;
import snow.SortableTable.*;
import snow.utils.gui.*;
import SnowMailClient.model.accounts.*;

import SnowMailClient.GnuPG.model.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.util.*;


public final class GenerateGPGKeypairDialog extends JDialog implements ItemListener
{
  private final CloseControlPanel ccp;
  private final JComboBox mailAddressesCB;
  private final JTextField nameField = new JTextField(20);
  private final JPasswordField passphraseField = new JPasswordField(20);
  private final JPasswordField passphraseVerifField = new JPasswordField(20);
  private final JTextField commentField = new JTextField("Snowmail", 20);
  private final JComboBox strengthCB = new JComboBox(new String[]{"4096", "2048", "1024"});
  private final JComboBox validityCB = new JComboBox(new String[]{Language.translate("Never expires"), "2010-01-01"});
  
  private final KeysTableModel tableModel;
                               


  public GenerateGPGKeypairDialog(JDialog parent, KeysTableModel tableModel)
  {
    super(parent, Language.translate("Generate a new GnuPG keypair (DSA & El-Gamal)"), true);
    this.tableModel = tableModel;
    
    getContentPane().setLayout(new BorderLayout());

    // center
    mailAddressesCB = new JComboBox(SnowMailClientApp.getInstance().getAccounts().getAllMailAddresses());
    JPanel centerPanel = new JPanel();
    GridLayout3 gl = new GridLayout3(2,centerPanel);
    centerPanel.setLayout(gl);
    getContentPane().add(centerPanel, BorderLayout.CENTER);

    gl.add(Language.translate("Mail Address"));
    gl.add(mailAddressesCB, true);
    mailAddressesCB.setEditable(true);
    mailAddressesCB.setMaximumRowCount(20);
    mailAddressesCB.addItemListener(this);

    gl.add(Language.translate("Name"));
    gl.add(nameField, false);

    gl.add(Language.translate("Comment"));
    gl.add(commentField, false);

    gl.add(Language.translate("Passphrase"));
    gl.add(passphraseField, false);
                                                 
    gl.add(Language.translate("Verification"));
    gl.add(passphraseVerifField, false);
    
                                 
    gl.add(Language.translate("El-Gamal key length"));
    gl.add(strengthCB, false);
    strengthCB.setSelectedIndex(1);

    gl.add(Language.translate("Expiration date"));
    gl.add(validityCB, false);     
    validityCB.setSelectedIndex(1);
    validityCB.setEditable(true);

    // south
    ccp = new CloseControlPanel(this, true, true, Language.translate("Generate keypair"));
    getContentPane().add(ccp, BorderLayout.SOUTH);
                                                                                           
    // initial field fill  
    itemStateChanged(null);

    // Modal visibility
    pack();
    SnowMailClientApp.centerComponentOnMainFrame(this);
    setVisible(true);  
    
    if(!ccp.getWasCancelled())
    {
       generateKeyPair();
    }

  } // Constructor


//  public boolean wasCancelled()    { return ccp.cancelled; }

  public String getMailAddress()   { return (String) mailAddressesCB.getSelectedItem(); }
  public String getUserName()      { return this.nameField.getText(); }
  public String getComment()       { return this.commentField.getText(); }
  public String getKeyLength()     { return (String) this.strengthCB.getSelectedItem(); }
  private final String  getPassphrase() { return new String(passphraseField.getPassword()); }
  public String getValidity()
  {
    if(validityCB.getSelectedIndex()==0) return "0";
    return (String) validityCB.getSelectedItem();
  }

   
  public void itemStateChanged(ItemEvent e)
  {
     String mail = (String) mailAddressesCB.getSelectedItem();
     MailAccount ma = SnowMailClientApp.getInstance().getAccounts().getMailAccount(mail);
     if(ma!=null)
     {
        nameField.setText(ma.getName());
     }
     else                                     
     {
        // let all field stay
     }
  } 
  
  private void checkParams() throws Exception
  {
     if(getPassphrase().length()<6) throw new Exception(Language.translate("Passphrase should have at least 6 characters"));
     if(!Arrays.equals(passphraseVerifField.getPassword(), passphraseField.getPassword()))
     {
       throw new Exception(Language.translate("Passphrase verification failed"));
     }
  }                              

  private void generateKeyPair() 
  {
     final ProgressModalDialog progress = new ProgressModalDialog(this, Language.translate("Generating GnuPG keypair"), false);
     SnowMailClientApp.centerComponentOnMainFrame(progress);

     Thread t = new Thread()
     {
       public void run()
       {
         try
         { 
           checkParams();
             
           GnuPGCommands.generateNew_DSA_ElG_KeyPair(SnowMailClientApp.getInstance().getGnuPGLink().getPathToGPG(),
              getUserName(),
              getComment(),
              getMailAddress(),
              getPassphrase(),
              getKeyLength(),
              getValidity(),
              progress);         
                                                                                                                                       
           EventQueue.invokeLater(new Runnable() { public void run() {
             tableModel.refreshModel(SnowMailClientApp.getInstance().getGnuPGLink());
           }});
         }
         catch(Exception ex)
         {
           JOptionPane.showMessageDialog(progress,
              Language.translate("Error:")+"\n"+ex.getMessage(),                 
              Language.translate("Cannot generate keys"), JOptionPane.ERROR_MESSAGE);
           ex.printStackTrace();
         }
         finally
         {
           progress.closeDialog();                                                                                                                  
         }
       }
     };

     t.start();   
     t.setPriority(Thread.NORM_PRIORITY-1);
     // Wait
     progress.start();      
    

  }

} // GenerateGPGKeypairDialog
