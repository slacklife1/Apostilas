package SnowMailClient.GnuPG.Views;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

import snow.utils.gui.*;
import SnowMailClient.Language.Language;
import SnowMailClient.utils.storage.*;
import SnowMailClient.GnuPG.Main.GnuPGCommands;
import SnowMailClient.GnuPG.model.GnuPGKeyID;
import SnowMailClient.GnuPG.*;
import SnowMailClient.SnowMailClientApp;
import snow.lookandfeel.*;

public final class GPGPasswordDialog extends JDialog
{
  final private transient GnuPGLink link;
  final private transient GnuPGKeyID keyID;

  private final transient JPasswordField passField = new JPasswordField();
  private boolean wasCancelled = false;
                             
  public GPGPasswordDialog(JFrame owner, GnuPGLink link, GnuPGKeyID keyID, String description)
  {
     super(owner, Language.translate("GPG Password dialog"), true);
     this.link = link;
     this.keyID = keyID;
                                                                                                                                                 
      JTextArea descrTA = new JTextArea(description);
      descrTA.setOpaque(false);
      descrTA.setBorder(BorderFactory.createEmptyBorder(3,3,3,3));
      descrTA.setEditable(false);

      getContentPane().setLayout( new BorderLayout());

      JPanel centerPanel = new JPanel(new BorderLayout());
      centerPanel.setBorder(BorderFactory.createEmptyBorder(5,3,5,3));
      JPanel passPanel = new JPanel(new GridLayout(1, 2));
      centerPanel.add(passPanel,BorderLayout.CENTER);
      getContentPane().add(centerPanel, BorderLayout.CENTER);
      getContentPane().add(descrTA, BorderLayout.NORTH);

      JPanel contrlpanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

      getContentPane().add(contrlpanel, BorderLayout.SOUTH);
                      
      ActionListener disposeActionListener = new ActionListener()
      {
       public void actionPerformed(ActionEvent e)
        {
           wasCancelled = true; 
           dispose();   
        }
      };
      ActionListener okActionListener = new ActionListener()
      {
       public void actionPerformed(ActionEvent e)
        {
          okAction();
        }                   
      };


      JButton cancel = new JButton(Language.translate("Cancel"));
      cancel.setIcon(SnowMailClientApp.loadImageIcon("pics/cancel.PNG"));
      contrlpanel.add(cancel);
      cancel.addActionListener(disposeActionListener);

      JButton close = new JButton(Language.translate(" Ok "));
      close.setIcon(SnowMailClientApp.loadImageIcon("pics/ok.PNG"));
      contrlpanel.add(close);
      //final JDialog ref = this;
      close.addActionListener(okActionListener);

      passPanel.add(new JLabel("Password "));
      passPanel.add(passField);
              
      passField.addActionListener(okActionListener);
        


      this.getRootPane().registerKeyboardAction( disposeActionListener,
                                               KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false),
                                               JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT );

      this.getRootPane().registerKeyboardAction( okActionListener,
                                               KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0, false),
                                               JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT );




     // modal
     //setSize(300,300);
     pack();
     SnowMailClientApp.centerComponentOnMainFrame(this);
     passField.requestFocus();
     setVisible(true);
     
     
  } // Constructor
      
      
  private void okAction()
  {
     // verify the pass
     if(isPasswordValid()) dispose();
     passField.setBackground(ThemesManager.getInstance().getRed());

  }


  public boolean isPasswordValid()
  {
    try
    {
      return GnuPGCommands.verifySecretKeyPassword(link.getPathToGPG(), keyID, getPassword());
    } 
    catch(Exception e)
    {
      e.printStackTrace();
      return false;
    }
  }

  public byte[] getPassword()
  {                          
    return new String(passField.getPassword()).getBytes();
  }

  public boolean hasBeenCancelled() { return wasCancelled; }



} // GPGPasswordDialog
