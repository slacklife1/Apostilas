package SnowMailClient.GnuPG.Views;

import snow.SortableTable.*;
import snow.lookandfeel.*;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.SpamFilter.*;
import SnowMailClient.GnuPG.model.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.beans.*;
                
/** DefaultTableCellRenderer seems not to like transparent bg ???
 ### can be optmized for performance...
*/                          
public final class KeysTableCellRenderer extends JLabel implements TableCellRenderer
{
  Font normalFont, boldFont;


  public KeysTableCellRenderer()
  {
    super();
    setup();
  } // Constructor

  /**
   * Notification from the <code>UIManager</code> that the look and feel
   * [L&F] has changed.
   * Replaces the current UI object with the latest version from the
   * <code>UIManager</code>.
   */
  public void updateUI()
  {
     super.updateUI();
     setup();
  }

  private void setup()
  {
     normalFont = UIManager.getFont("Table.font");
     int fontSize = normalFont.getSize();
     boldFont = //new Font(normalFont.getFontName(), Font.BOLD, fontSize);
                normalFont.deriveFont(Font.BOLD);
     Border emptyBorder = new EmptyBorder(fontSize/4, fontSize/2, fontSize/4, fontSize/2);
     this.setBorder(emptyBorder);

  }

  public Component getTableCellRendererComponent(
         JTable table, Object value, boolean isSelected, boolean hasFocus,
         int row, int column)
  {
     String text = value.toString();
     this.setText(text);
     setOpaque(false);

     SortableTableModel sortableTableModel = (SortableTableModel) table.getModel();
     int ind = sortableTableModel.getIndexInUnsortedFromTablePos(row);
     KeysTableModel ktm = (KeysTableModel) sortableTableModel.getBasicTableModel();

     GnuPGKeyID key = ktm.getKeyAt(ind);
     this.setFont(normalFont);

     // selection
     if(isSelected)
     {
        setBackground(UIManager.getColor("Tree.selectionBackground"));
        setOpaque(true);
     }

     int modelCol = sortableTableModel.getColumnForViewIndex(column);

     boolean showRed = false;
     boolean showGreen = false;
     if(modelCol==1)
     {
        String trust = key.getCalculatedTrust();
        if(trust.equals("u") || trust.equals("f"))
        {
          showGreen = true;
        }
        else if(trust.equals("m") || trust.equals("e") || trust.equals("n"))
        {
          showRed = true;
        }
     }
     else if (modelCol==6)
     { 
        if(key.hasExpired()) showRed=true;
     }



     if(showGreen)
     {
        if(isSelected)
        {

          setBackground(ThemesManager.getInstance().getGreen().darker());
        } 
        else
        {
          setBackground(ThemesManager.getInstance().getGreen());
        }
        setOpaque(true);
     }
     else if(showRed)
     {
        if(isSelected)
        {
          setBackground(ThemesManager.getInstance().getRed().darker());
        }
        else
        {
          setBackground(ThemesManager.getInstance().getRed());
        }
        setOpaque(true);
     }

     return this;
  }



} // KeysTableCellRenderer
