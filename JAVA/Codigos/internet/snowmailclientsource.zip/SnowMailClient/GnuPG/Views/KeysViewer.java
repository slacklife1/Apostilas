package SnowMailClient.GnuPG.Views;

import SnowMailClient.GnuPG.*;
import SnowMailClient.GnuPG.Main.GnuPGCommands;
import SnowMailClient.Language.Language;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.crypto.PassphraseDialog;
import SnowMailClient.crypto.SecretKeyManager;
import snow.crypto.*;
import snow.SortableTable.*;
import snow.utils.gui.*;


import SnowMailClient.GnuPG.model.*;
                        
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.util.*;


public final class KeysViewer extends JDialog
{           
  final private GnuPGLink link;
  final private KeysTableModel tableModel = new KeysTableModel();
  final private SortableTableModel sortableTableModel;

  final private JTable table = new JTable();
//  final private JSenseButton addKeyButton  = new JSenseButton(Language.translate("Import key"));
//  final private JSenseButton getKeyButton  = new JSenseButton(Language.translate("Get key from server"));
  final private JSenseButton closeButton   = new JSenseButton(Language.translate("Close"));
  final private JSenseButton refreshButton = new JSenseButton(Language.translate("Refresh"));

//  final private JSenseButton generateKeyPairButton = new JSenseButton(Language.translate("Generate new KeyPair"));
                                 
  final private JCheckBox advancedModeCB = new JCheckBox(Language.translate("Advanced Mode"), false);
            
  public KeysViewer()
  {
     super(SnowMailClientApp.getInstance(), Language.translate("GnuPG explorer"), true);

     link = SnowMailClientApp.getInstance().getGnuPGLink();
     try
     {
       link.setGPGPath(link.getPathToGPG());
     } catch(Exception ignored) {}

     if(!link.isGPG_available())
     {            
        // Abort => no gpg available !                 

        JOptionPane.showMessageDialog(SnowMailClientApp.getInstance(),
          Language.translate("Please first set the GPG path."),
          Language.translate("GPG not installed"),
          JOptionPane.WARNING_MESSAGE);

        sortableTableModel = null;
        return;
     }

     // read keys
       
     tableModel.refreshModel(link);
                                    
     // center table
                                              
     sortableTableModel = new SortableTableModel(tableModel);
     table.setModel(sortableTableModel);
     sortableTableModel.installGUI(table);
     table.setDefaultRenderer(Object.class, new KeysTableCellRenderer());

     table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

     this.getContentPane().setLayout(new BorderLayout());
     this.getContentPane().add(new JScrollPane(table), BorderLayout.CENTER);

     // north search
     AdvancedSearchPanel sp = new AdvancedSearchPanel(Language.translate("Search"), null, sortableTableModel, false);
     this.getContentPane().add(sp, BorderLayout.NORTH);
     sp.add(Box.createHorizontalStrut(100));
     sp.add(advancedModeCB);
     advancedModeCB.addActionListener(new ActionListener()
     {                     
       public void actionPerformed(ActionEvent ae)
       {
          if(advancedModeCB.isSelected())
          {
            int[] range = new int[tableModel.getColumnCount()];
            for(int i=0; i<range.length; i++) range[i] = i;
            sortableTableModel.setVisibleColumns(range);
          }
          else
          {
            sortableTableModel.setVisibleColumns(new int[]{1,2,3,6});
          }
          tableModel.setAdvancedMode(advancedModeCB.isSelected(), link);
          sortableTableModel.setPreferredColumnSizesFromModel();
       }
     });

     sortableTableModel.setVisibleColumns(new int[]{1,2,3,6});
     tableModel.setAdvancedMode(false, link);
     sortableTableModel.setPreferredColumnSizesFromModel();
                                              
     // South
     //
     JPanel southPanel = new JPanel(); // new FlowLayout(FlowLayout.LEFT));
     southPanel.setBorder(new EmptyBorder(4,5,4,5));
     southPanel.setLayout(new BoxLayout(southPanel, BoxLayout.X_AXIS));

     this.getContentPane().add(southPanel, BorderLayout.SOUTH);
     //southPanel.add(addKeyButton);
     //southPanel.add(getKeyButton);
     //southPanel.add(generateKeyPairButton);
     southPanel.add(refreshButton);  
     southPanel.add(Box.createHorizontalGlue());
     southPanel.add(closeButton);

     closeButton.setBackground(Color.orange);
     closeButton.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
          setVisible(false);
       }
     });



     refreshButton.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
          try
          {
            tableModel.refreshModel(link);
          }
          catch(Exception ex)
          {
               JOptionPane.showMessageDialog(KeysViewer.this,
                   ex.getMessage(),
                   Language.translate("Cannot read the keys from GnuPG"),
                   JOptionPane.ERROR_MESSAGE);
          }
       }
     });






     table.addMouseListener(new MouseAdapter()
     {
       @Override public void mousePressed(MouseEvent me)
       {
         if(me.isPopupTrigger())
         {
           showPopup(me);
         }
       }

       @Override public void mouseReleased(MouseEvent me)
       {
         if(me.isPopupTrigger())
         {
           showPopup(me);
         }
       }

     });
     
     this.createMenu();

     // Display (Modal)

     SnowMailClientApp.getInstance().getProperties().setComponentSizeFromINIFile(this, "gpgExplorer", 800,600,100,100);
     SnowMailClientApp.centerComponentOnMainFrame(this);
     this.setVisible(true);

     SnowMailClientApp.getInstance().getProperties().saveComponentSizeInINIFile(this, "gpgExplorer");


  } // Constructor

  private void createMenu()
  {  
     this.setJMenuBar(new JMenuBar());  
                                           
     JSenseMenu importMenu = new JSenseMenu(Language.translate("Import"));
     getJMenuBar().add(importMenu);
                     
     JMenuItem addKeyItem  = new JMenuItem(Language.translate("Import key from file"));
     importMenu.add(addKeyItem);
                                
     JMenuItem getKeyItem  = new JMenuItem(Language.translate("Import a key from server"));
     importMenu.add(getKeyItem);
      
     JMenuItem refreshKeysItem  = new JMenuItem(Language.translate("Refresh keys from server"));
     importMenu.add(refreshKeysItem);
            
     JSenseMenu createMenu = new JSenseMenu(Language.translate("Generate"));  
     getJMenuBar().add(createMenu);
                
     JMenuItem generateKeyPairItem = new JMenuItem(Language.translate("Generate a new KeyPair"));
     createMenu.add(generateKeyPairItem);

     addKeyItem.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
          addKeyAction();
       }
     });

     getKeyItem.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
          new GetKeyFromServerDialog(KeysViewer.this, tableModel);
       }
     }); 
     
     refreshKeysItem.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
          refreshKeysAction();     
       }
     });  
     
     generateKeyPairItem.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
          try
          {
               new GenerateGPGKeypairDialog(KeysViewer.this, tableModel);
          }
          catch(Exception ex)
          {
               JOptionPane.showMessageDialog(KeysViewer.this,
                   ex.getMessage(),
                   Language.translate("Cannot generate new keypair"),
                   JOptionPane.ERROR_MESSAGE);
          }
       }
     });         
  }


  private void showPopup(MouseEvent me)
  {
     JPopupMenu popup = new JPopupMenu("Key popup");
     int[] sels = table.getSelectedRows();
     if(sels.length!=1) return;

     int pos = sortableTableModel.getIndexInUnsortedFromTablePos(sels[0]);
     final GnuPGKeyID key = tableModel.getKeyAt(pos);

     final boolean hasAssociatedSecretKey = !key.isSecret() && link.hasSecretKeyAssociated(key);

     popup.add(key.getNames()+" / "+key.getKeyID());
     popup.addSeparator();


     if(!key.isSecret())
     {    
        // public keys 
        JMenuItem viewTrustItem = new JMenuItem(Language.translate("View/set key trust"));
        popup.add(viewTrustItem);
        viewTrustItem.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent ae)
          { 
             new SetTrustDialog(KeysViewer.this, tableModel, key);
          }
        });

        JMenuItem viewPubKeyItem = new JMenuItem(Language.translate("View public key"));
        popup.add(viewPubKeyItem);
        viewPubKeyItem.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent ae)
          {
             try
             {
               String pkc = link.getPublicKeyContent(key);
               displayKeyContentTextArea(pkc, key, Language.translate("Public key of %",key.getKeyID()));
             }
             catch(Exception ex)
             {
               ex.printStackTrace();
               JOptionPane.showMessageDialog(KeysViewer.this,
                   ex.getMessage(),
                   Language.translate("Cannot display the public key"),
                   JOptionPane.ERROR_MESSAGE);
             }
          }
        });
        
        JMenuItem sendPubKeyItem = new JMenuItem(Language.translate("Publish public key to keyserver"));
        popup.add(sendPubKeyItem);
        sendPubKeyItem.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent ae)
          {

             final ProgressModalDialog progress = new ProgressModalDialog(KeysViewer.this,
                    Language.translate("Publishing public key to keyserver"), false);
             SnowMailClientApp.centerComponentOnMainFrame(progress);

             Thread t = new Thread()
             {
               public void run()
               {  
                 try
                 {                           
                   GnuPGCommands.sendPublicKey(
                     link.getPathToGPG(),
                     key,
                     progress);
                 }                  
                 catch(Exception ex)
                 {
                   ex.printStackTrace();
                   JOptionPane.showMessageDialog(KeysViewer.this,
                       ex.getMessage(),
                       Language.translate("Cannot send the public key"),
                       JOptionPane.ERROR_MESSAGE);
                 }
                 finally
                 {
                   progress.closeDialog();
                 }
               }
             };
             t.setPriority(Thread.NORM_PRIORITY-1);
             t.start();
             
             // modal dialog wait until completion
             progress.start();
          }  
        });

     }
     else
     {
       JMenuItem viewSecretKeyItem = new JMenuItem(Language.translate("View secret key"));
       popup.add(viewSecretKeyItem);
       viewSecretKeyItem.addActionListener(new ActionListener()
       {
         public void actionPerformed(ActionEvent ae)
         {
           try
           {
              String skc = link.getSecretKeyContent(key);
              displayKeyContentTextArea(skc, key, Language.translate("Secret key of %",key.getKeyID()));
           }
           catch(Exception ex)
           {
              ex.printStackTrace();
              JOptionPane.showMessageDialog(KeysViewer.this,
                 ex.getMessage(),
                 Language.translate("Cannot display the secret key"),
                 JOptionPane.ERROR_MESSAGE);
           }
         }
       });
       
       if(link.getPasswordForKey(key)!=null)
       {
         JMenuItem viewPassItem = new JMenuItem(Language.translate("View password"));
         popup.add(viewPassItem);
         viewPassItem.addActionListener(new ActionListener()
         {
           public void actionPerformed(ActionEvent ae)
           {
                //ask for the global passphrase
                SecretKeyID skid = SecretKeyUtilities.computeSignature(
                   SecretKeyManager.getInstance().getUserKeyForEncryption());
                PassphraseDialog pd = new PassphraseDialog(KeysViewer.this,
                   Language.translate("Enter the SnowMail password"), true, skid, Language.translate("Security Check"));
  
                if(pd.matchesID())
                {
                   JOptionPane.showMessageDialog(
                      KeysViewer.this, new String(link.getPasswordForKey(key)),          
                      Language.translate("Password for %", key.getMails()),
                      JOptionPane.INFORMATION_MESSAGE);
                } 
           }
         });
       }
     }



     // for both secret and public
     JMenuItem removeKeyItem = new JMenuItem(Language.translate("Remove key"));
     popup.add(removeKeyItem);
     removeKeyItem.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       { 
         
         if(hasAssociatedSecretKey)
         {
             int rep = JOptionPane.showConfirmDialog(KeysViewer.this,
                 Language.translate("This will also remove the associated private key. Do you want to proceed ?"),
                 Language.translate("Removing public and private key"),
                 JOptionPane.YES_NO_OPTION);
             if(rep!=JOptionPane.YES_OPTION) return;
         }
                                      

         try
         {    
             if(hasAssociatedSecretKey)
             {
               link.removePublicAndPrivateKey(key);
             }
             else
             {
               link.removeKey(key);
             }
             
             // NEEDS TWO CALLS, CAUSE OF A BUG in GPG... ?
             tableModel.refreshModel(link);
         }
         catch(Exception ex)
         {
              ex.printStackTrace();
              JOptionPane.showMessageDialog(KeysViewer.this,
                 ex.getMessage(),
                 Language.translate("Cannot remove the key"),
                 JOptionPane.ERROR_MESSAGE);

         }
       }
     });
     
     

     popup.show(table, me.getX(), me.getY());
  }  
  
  private void refreshKeysAction()
  {
     final ProgressModalDialog progress = new ProgressModalDialog(KeysViewer.this,
            Language.translate("Refreshing all keys from keyserver"), false);
     SnowMailClientApp.centerComponentOnMainFrame(progress);
         
     Thread t = new Thread()
     {
       public void run()
       {
          try
          {
             GnuPGCommands.refreshPublicKeysFromServer(link.getPathToGPG(),progress);
             EventQueue.invokeLater(new Runnable()
             {
               public void run()
               {
                 tableModel.refreshModel(link);
               }
             });
          }
          catch(Exception ex)
          {
             ex.printStackTrace();
             JOptionPane.showMessageDialog(KeysViewer.this,
                ex.getMessage(),
                Language.translate("Cannot refresh the keys"),
                JOptionPane.ERROR_MESSAGE);
          }
          finally
          {
             progress.closeDialog();
          }
       }
     };
     t.setPriority(Thread.NORM_PRIORITY-1);
     t.start();

     // modal
     progress.start();
  }

  private void addKeyAction()
  {
     JDialog dialog = new JDialog(this, Language.translate("Add a new key to the GPG keyring"), true);
     JTextArea ta = new JTextArea();
     dialog.setLayout(new BorderLayout());
     dialog.add(new JScrollPane(ta), BorderLayout.CENTER);
     CloseControlPanel ccp = new CloseControlPanel(dialog, false, false, Language.translate("Add the key in GPG"));
     dialog.add(ccp, BorderLayout.SOUTH);

     // display modal

     SnowMailClientApp.getInstance().getProperties().setComponentSizeFromINIFile(dialog, "gpgExplorer.addKeyDialog", 600,650,120,120);
     SnowMailClientApp.centerComponentOnMainFrame(dialog);
     dialog.setVisible(true);

     SnowMailClientApp.getInstance().getProperties().saveComponentSizeInINIFile(dialog, "gpgExplorer.addKeyDialog");
     if(ccp.getWasCancelled()) return;

     String key = ta.getText();
     try
     {
        link.addKey(key);
        tableModel.refreshModel(link);
     }
     catch(Exception ex)
     {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(KeysViewer.this,
           ex.getMessage(),
           Language.translate("Cannot add the key"),
           JOptionPane.ERROR_MESSAGE);       
     }

  }                                                                                                                                         


  private void displayKeyContentTextArea(String content, GnuPGKeyID key, String title)
  {
     JDialog dialog = new JDialog(this, title, true);
     StringBuffer tacont = new StringBuffer();
     tacont.append(Language.translate("Key fingerprint")+" = "+key.getFingerprint()+"\r\n");
     tacont.append(Language.translate("Key length")+" = "+key.getKeyLength()+"\r\n");

     if(!key.isSecret())
     {
       tacont.append(Language.translate("Calculate key trust")+" = "+key.getCalculatedTrustMessage()+"\r\n");
     }


     tacont.append("\r\n");
     tacont.append(content);
     JTextArea ta = new JTextArea(tacont.toString());
     ta.setEditable(false);
     dialog.setLayout(new BorderLayout());
     dialog.add(new JScrollPane(ta), BorderLayout.CENTER);
     CloseControlPanel ccp = new CloseControlPanel(dialog, false, false, Language.translate("Close"));
     dialog.add(ccp, BorderLayout.SOUTH);

     // display modal
                                      
     SnowMailClientApp.getInstance().getProperties().setComponentSizeFromINIFile(dialog, "gpgExplorer.displayTextArea", 600,650,120,120);
     SnowMailClientApp.centerComponentOnMainFrame(dialog);
     dialog.setVisible(true);

     SnowMailClientApp.getInstance().getProperties().saveComponentSizeInINIFile(dialog, "gpgExplorer.displayTextArea");
  }

  



} // KeysViewer
