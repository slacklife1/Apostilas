package SnowMailClient.GnuPG.Views;

import SnowMailClient.GnuPG.*;
import SnowMailClient.GnuPG.Main.GnuPGCommands;
import SnowMailClient.Language.Language;
import SnowMailClient.SnowMailClientApp;
import snow.SortableTable.*;
import snow.utils.gui.*;

import SnowMailClient.model.accounts.*;

import SnowMailClient.GnuPG.model.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.util.*;

                                      
public final class GetKeyFromServerDialog extends JDialog
{
  private final KeysTableModel tableModel;
  
  private final JTextField searchTF = new JTextField(12);
  private final JSenseButton searchButton = new JSenseButton(Language.translate("Search"));
  
 // private final JTextArea resultTA = new JTextArea(10,50);
  
  private final KeySearchResultTableModel previewTableModel = new KeySearchResultTableModel();
  private final SortableTableModel stm;
  private final JTable previewTable = new JTable();

  public GetKeyFromServerDialog(JDialog parent, KeysTableModel tableModel)
  {
    super(parent, Language.translate("Search/retrieve public keys from keyserver"), true);
    this.tableModel = tableModel;                                 
    getContentPane().setLayout(new BorderLayout());
                      
    // center
    JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    searchPanel.setBorder(new EmptyBorder(3,4,3,4));
    getContentPane().add(searchPanel, BorderLayout.NORTH);
    searchPanel.add(new JLabel(Language.translate("Search")+":"));
    searchPanel.add(searchTF);
    searchPanel.add(searchButton);

    searchTF.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent ae)
      {
        searchKeys(searchTF.getText());
      }
    });

    searchButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent ae)
      {
        searchKeys(searchTF.getText());
      }
    });
    
    // center                                                                
    stm = new SortableTableModel(previewTableModel);
    previewTable.setModel(stm);
    stm.installGUI(previewTable);                                            
    getContentPane().add(new JScrollPane(previewTable), BorderLayout.CENTER);

    
    // south
    final CloseControlPanel ccp = new CloseControlPanel(this, true, true, Language.translate("Import selected keys"));
    getContentPane().add(ccp, BorderLayout.SOUTH);
      
    previewTable.getSelectionModel().addListSelectionListener(new ListSelectionListener()
    {  
      public void valueChanged(ListSelectionEvent lse)
      {
         ccp.getOkButton().setEnabled(previewTable.getSelectedRows().length>0);
      }
    });   
    
    ccp.getOkButton().setEnabled(false);
          
    // modal dialog show
    pack();
    SnowMailClientApp.centerComponentOnMainFrame(this);
    setVisible(true);
    
    if(!ccp.getWasAccepted()) return;
    
    // retrieve selected
    importSelectedKeys();
  } // Constructor


  private void searchKeys(final String text)
  {
     final ProgressModalDialog progress = new ProgressModalDialog(this, Language.translate("Sending request to the keyserver"), false);
     SnowMailClientApp.centerComponentOnMainFrame(progress);
     //progress.setProgressValue(0, "");

     Thread t = new Thread()
     {
       public void run()
       {
         try
         {
           final Vector<KeyIDFromSearchResult> keys = GnuPGCommands.searchKeysOnServer(
                 SnowMailClientApp.getInstance().getGnuPGLink().getPathToGPG(),
              text,
              progress);


           
           EventQueue.invokeLater(new Runnable() { public void run() {
             //tableModel.refreshModel(SnowMailClientApp.getInstance().getGnuPGLink());
             //resultTA.setText(reply);
             previewTableModel.setKeys(keys);
             
           }});                         
         }
         catch(Exception ex)
         {
           JOptionPane.showMessageDialog(progress,
              Language.translate("Error:")+"\n"+ex.getMessage(),
              Language.translate("Cannot search keys"), JOptionPane.ERROR_MESSAGE);
           ex.printStackTrace();          
         }
         finally
         {
           progress.closeDialog();                                                                                                                  
         }
       }
     };

     t.start();   
     t.setPriority(Thread.NORM_PRIORITY-1);
     // Wait
     progress.start();      
                 
  }  
  
  private void importSelectedKeys()
  {  
     for(int sel : previewTable.getSelectedRows())
     {
       int pos = stm.getIndexInUnsortedFromTablePos(sel);
       KeyIDFromSearchResult key = this.previewTableModel.getKeyAt(pos);
       try          
       {
          GnuPGCommands.importKeyFromServer(
                 SnowMailClientApp.getInstance().getGnuPGLink().getPathToGPG(),
                 key,
                 null);

          tableModel.refreshModel(SnowMailClientApp.getInstance().getGnuPGLink());

       }
       catch(Exception e)
       {
          e.printStackTrace();
       }
     }
  }


} // GetKeyFromServerDialog
