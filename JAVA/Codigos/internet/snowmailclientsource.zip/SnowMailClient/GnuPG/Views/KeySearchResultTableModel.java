package SnowMailClient.GnuPG.Views;

import snow.utils.storage.*;
import snow.SortableTable.*;
import SnowMailClient.Language.Language;
import SnowMailClient.GnuPG.model.*;
import SnowMailClient.GnuPG.GnuPGLink;

import java.util.*;
import java.awt.EventQueue;       
import java.text.*;  
                                          
public final class KeySearchResultTableModel extends FineGrainTableModel
{
  private Vector<KeyIDFromSearchResult> keys = new Vector<KeyIDFromSearchResult>();
  
  public KeySearchResultTableModel()
  {
  }
  
  public void setKeys(Vector<KeyIDFromSearchResult> keys)
  {   
     this.fireTableModelWillChange();
     this.keys = keys;               
     this.fireTableDataChanged();
     this.fireTableModelHasChanged();
  } // Constructor
   
  public KeyIDFromSearchResult getKeyAt(int pos)
  {
     return keys.elementAt(pos);  
  }   
                     

  private static final String[] COLUMN_NAMES = new String[]{
     Language.translate("Name(s)"), 
     //Language.translate("ID"),
     Language.translate("Remarks") 
  };
                           
  private static final int[] PREFERED_COLUMN_WIDTHS = new int[]{25,6};
                                                              
  public String getColumnName(int col)
  {
     return COLUMN_NAMES[col];
  }

  public int getPreferredColumnWidth(int column)
  {                          
    return PREFERED_COLUMN_WIDTHS[column];
  }                                                              
       
  public int getRowCount()
  {
     return keys.size();
  }

  public int getColumnCount()
  {
     return COLUMN_NAMES.length;
  }

  public Object getValueAt(int row, int column)
  {
    KeyIDFromSearchResult k = keys.elementAt(row);
    switch(column)
    {
      case 0: return k.toStringAddresses();
      //case 1: return k.getKeyShortID();
      case 1: return k.getRemarks();
    }   
    return "";
  }

} // KeySearchResultTableModel
