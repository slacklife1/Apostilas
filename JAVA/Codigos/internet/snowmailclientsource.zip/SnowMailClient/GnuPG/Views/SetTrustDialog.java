package SnowMailClient.GnuPG.Views;

import SnowMailClient.GnuPG.*;
import SnowMailClient.GnuPG.Main.GnuPGCommands;
import SnowMailClient.Language.Language;
import SnowMailClient.SnowMailClientApp;
import snow.SortableTable.*;
import snow.utils.gui.*;

import SnowMailClient.model.accounts.*;

import SnowMailClient.GnuPG.model.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.util.*;

public final class SetTrustDialog extends JDialog implements ItemListener
{
  private final CloseControlPanel ccp;
  private final JComboBox trustLevelCB;
  private final KeysTableModel tableModel;
  private final GnuPGKeyID key;

  private final JTextArea actualTrustArea = new JTextArea();

  public SetTrustDialog(JDialog parent, KeysTableModel tableModel, GnuPGKeyID key)
  {
    super(parent, Language.translate("Set the trust level for %", key.getNames()), true);

    this.tableModel = tableModel;
    this.key = key;

    getContentPane().setLayout(new BorderLayout());

    // north
    getContentPane().add(actualTrustArea, BorderLayout.NORTH);                                                               
    actualTrustArea.setEditable(false);
    
    actualTrustArea.setBorder(new EmptyBorder(3,5,3,5));
    actualTrustArea.setText(Language.translate("The actual calculated trust is")+": "+key.getCalculatedTrustMessage()
      +"\n\n"
      +Language.translate("Please enter your trust (ownertrust) for this key:")
    );                                    

    trustLevelCB = new JComboBox(new String[]{
         Language.translate("I don't know or won't say"), //1  -
         Language.translate("I do NOT trust"),           //2
         Language.translate("I trust marginally"),   //3  m
         Language.translate("I trust fully"),        //4  f
         Language.translate("I trust ultimately")    //5  u
    });

    // center
    JPanel centerPanel = new JPanel();
    centerPanel.setBorder(new EmptyBorder(3,5,3,5));
    GridLayout3 gl = new GridLayout3(1, centerPanel);
    centerPanel.setLayout(gl);
    getContentPane().add(centerPanel, BorderLayout.CENTER);
    
    actualTrustArea.setBackground(centerPanel.getBackground());

    //gl.add(Language.translate("Trust level"), false);
    gl.add(trustLevelCB, true);
    trustLevelCB.addItemListener(this);
             
    // south  
    ccp = new CloseControlPanel(this, true, true, Language.translate("Update the ownertrust level"));
    getContentPane().add(ccp, BorderLayout.SOUTH);

    // Modal visibility
    pack();
    SnowMailClientApp.centerComponentOnMainFrame(this);
    setVisible(true);

    if(!ccp.getWasCancelled())
    {
      setTrustLevel();
    }

  }

  public void itemStateChanged(ItemEvent e)
  {   
  }
  
  private void setTrustLevel()
  {                                                                                                 
     final ProgressModalDialog progress = new ProgressModalDialog(this, Language.translate("Updating the trust level"), false);
     SnowMailClientApp.centerComponentOnMainFrame(progress);
                                                         
     Thread t = new Thread()
     {
       public void run()
       {
         try
         { 

           GnuPGCommands.setTrust(SnowMailClientApp.getInstance().getGnuPGLink().getPathToGPG(),
              key,
              ((Integer) trustLevelCB.getSelectedIndex()).intValue()+1,
              progress);
                                                                                                                                       
           EventQueue.invokeLater(new Runnable() { public void run() {
             tableModel.refreshModel(SnowMailClientApp.getInstance().getGnuPGLink());
           }});
         }
         catch(Exception ex)
         {
           JOptionPane.showMessageDialog(progress,
              Language.translate("Error:")+"\n"+ex.getMessage(),                 
              Language.translate("Cannot update the trust level"), JOptionPane.ERROR_MESSAGE);
           ex.printStackTrace();
         }
         finally
         {
           progress.closeDialog();                                                                                                                  
         }
       }
     };

     t.start();   
     t.setPriority(Thread.NORM_PRIORITY-1);
     // Wait
     progress.start();   
  }

} // SetTrustDialog
