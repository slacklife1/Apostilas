package SnowMailClient.GnuPG.model;

import java.text.*;
import java.util.*;
import SnowMailClient.Language.*;

public final class SignatureVerificationResult
{
  final static private SimpleDateFormat madeFormat = new SimpleDateFormat("MM/dd/yy HH:mm:ss");
  private boolean goodSignature = false;

  private String madeString = "";
  private long madeDate = -1;
  private String signatureFrom = "";
  private String warning = "";

  public SignatureVerificationResult()
  {
  } // Constructor

  /**      
      gpg: Signature made 02/13/05 21:34:22 Westeurop�ische Normalzeit using DSA key ID 3CDE995E
  */
  public void parseLine(String line) throws Exception
  {
    int pos = line.indexOf("Signature made");
    if(pos>=0)
    {
      madeString = line.substring(pos+15);
      //System.out.println("MadeString: "+madeString);
      try
      {
        madeDate = madeFormat.parse(madeString).getTime();
      }
      catch(Exception e) { e.printStackTrace(); }
    }

    pos = line.indexOf("Good signature");
    if(pos>=0)
    {
       goodSignature = true;
       pos = line.indexOf("from");
       if(pos==-1) throw new Exception("No from in the good signature text");
       signatureFrom = line.substring(pos+5);
    }

    pos = line.indexOf("BAD signature");
    if(pos>=0)
    {
       goodSignature = false;
       pos = line.indexOf("from");
       if(pos==-1) throw new Exception("No from in the good signature text");
       signatureFrom = line.substring(pos+5);
    }

    pos = line.toUpperCase().indexOf("WARNING");
    if(pos>=0)
    {
       warning = line.substring(pos+9).trim();
    }
  }  
  
  public boolean isSignatureGood() { return goodSignature; }
  public String getSigner() { return signatureFrom; }  
  public long getSignatureDate() { return this.madeDate; }
  

  public String toString()
  {
    StringBuffer sb = new StringBuffer();
    if(goodSignature)
    {
      //return Language.translate("GOOD signature from %1 made at %2", signatureFrom, madeString);
      sb.append( Language.translate("GOOD signature from %", signatureFrom) + " ("+madeFormat.format(new Date(madeDate))+")" );
    }
    else
    {
      sb.append( Language.translate("BAD signature from %", signatureFrom) );
    }

    if(warning.length()>0)
    {
      sb.append("\n  "+Language.translate("Warning")+": "+warning);
    }

    return sb.toString();
  }




} // SignatureVerificationResult
