package SnowMailClient.GnuPG.model;

import java.util.*;
import java.io.*;
import java.text.*;
import SnowMailClient.Language.Language;

/** represent a keyID read from the keystore
*/
public final class GnuPGKeyID implements Comparable
{                      
  public static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);

  public enum TrustType { Unknown(1), Never(2), Marginal(3), Fully(4), Ultimatively(5);  // q,n,m,f,u
      int code;
      TrustType(int code)
      {
        this.code = code;
      }
      public int getCode() { return code; }
  }
  
  private String type ;    // pub, sec
  private String shortID;   // 1024D/DCCA76DF
  private String keyID;          
  
/**
  -  Not yet calculated
  e  Trust  calculation  has  failed; probably due to an expired key
  q  ot enough information for calculation
  n  Never trust this key
  m  Marginally trusted
  f  Fully trusted
  u  Ultimately trusted  

  e  das Vertrauen l��t sich gerade nicht berechnen (Schl�ssel ist wahrscheinlich �ber dem Verfallsdatum)
  q  ich habe wenig Informationen/ich bin mir nicht sicher
  n  ich vertraue dem Schl�ssel nie
  m  ich vertraue dem Schl�ssel halbwegs
  f  ich vertraue dem Schl�ssel voll
  u  ich vertraue dem Schl�ssel uneingeschr�nkt (ultimately)
*/
  private String calculatedTrust;
  private String fingerprint = "no fingerprint found !";
  private String keyCapabilities;
  private int algorithm;
  private int keyLength;
  
  

  private long expires = -1, created = -1;

  private final Vector<UIDRecord> uids = new Vector<UIDRecord>();
  private final Vector<GnuPGKeyID> subKeys = new Vector<GnuPGKeyID>();

  
  boolean mainKey = true;
  public GnuPGKeyID(boolean mainKey)
  {
    this.mainKey = mainKey;
  } // empty constructor
  
  public void addSubKey(GnuPGKeyID sk)
  {  
    subKeys.addElement(sk);
  }
   
  /** this is the complete ID (name + (comment) + <mail>
  */                                           
  public String getKeyID()        { return keyID;  }
  public String getCalculatedTrust() 
  {
    return calculatedTrust;
  }

  public String getCalculatedTrustMessage()   
  {                        
    if(calculatedTrust.equalsIgnoreCase("e")) 
    {
      if(this.hasExpired())
      {
        return Language.translate("Trust calculation failed, key has expired");
      }
      else
      {
        return Language.translate("Trust calculation has failed");
      }
    }
    if(calculatedTrust.equalsIgnoreCase("q")) return Language.translate("Not enough information for calculation");
    if(calculatedTrust.equalsIgnoreCase("n")) return Language.translate("Never trust this key");
    if(calculatedTrust.equalsIgnoreCase("m")) return Language.translate("Marginally trusted");
    if(calculatedTrust.equalsIgnoreCase("f")) return Language.translate("Fully trusted");
    if(calculatedTrust.equalsIgnoreCase("u")) return Language.translate("Ultimately trusted");
    // - 
    return Language.translate("Not yet calculated");
  }

  public int getKeyLength()        { return this.keyLength;  }
  public int getAlgorithm()        { return this.algorithm;  }
  public String getAlgorithmName()
  {
    switch(algorithm)
    {
      case 1:  return "RSA";
      case 16: return "Elgamal"; // (encrypt only)";
      case 17: return "DSA"; // (sign only)";
      case 20: return "Elgamal"; // (sign and encrypt, don't use!)";
      default: return Language.translate("unknown algorithm");
    }
  }
  public long getCreationDate()   { return created; }
  public Vector<UIDRecord> getUIDs() { return uids; }
  public String getNames()
  {
    if(uids.size()==0) return "No UID !";
    UIDRecord r = uids.firstElement();
    return r.getName();
  }

  public String getMails() 
  {
    if(uids.size()==0) return "No UID !";
    UIDRecord r = uids.firstElement();
    return r.getMail();
  }

  public long getExpirationDate() { return expires; }
  public boolean hasExpired() 
  {
    if(expires<0) return false; // never
    if(expires<System.currentTimeMillis()) return true;
    return false;
  }

  public String getFingerprint()  { return fingerprint; }
  public String getKeyCapabilities() { return keyCapabilities; }
  
  public boolean isSecret() { return type.equalsIgnoreCase("sec"); }



  public String toString()
  {        
    if(this.isSecret()) return "Secret key "+getMails() ;
    return "Public key "+getMails() ;
  }            
  
  
  public int compareTo(Object okey)
  {
     GnuPGKeyID key2 = (GnuPGKeyID) okey;
     
     return toString().compareTo(key2.toString());
  }

               
  //
  // Robust parsing from colon print
  //     

  /** 1.4.0 example  ssb::1024:16:194A98B13443A525:1106759649::::::::::
  */
  public void parseSEC_colon_format(String line) throws Exception
  {
    Scanner scanner = new Scanner(line);
    scanner.useDelimiter(":");

    String r1 = scanner.next();
    if(!r1.equalsIgnoreCase("sec")) throw new Exception("SEC reader read only sec records!, not "+r1);
    
    type = "sec";  
    parse_sec_or_pub(scanner);
  }
  
  /** 1.4.0 example
  */
  public void parsePUB_colon_format(String line) throws Exception
  {                 
    //System.out.println(""+line);
    
    Scanner scanner = new Scanner(line);
    scanner.useDelimiter(":");

    String r1 = scanner.next();
    if(!r1.equalsIgnoreCase("pub")) throw new Exception("PUB reader read only pub records!, not "+r1);

    type = "pub";
    parse_sec_or_pub(scanner);
  }   
  
  public void parseSUB_colon_format(String line) throws Exception
  {                 
    //System.out.println(""+line);
    
    Scanner scanner = new Scanner(line);
    scanner.useDelimiter(":");

    String r1 = scanner.next();
    if(!r1.equalsIgnoreCase("sub")) throw new Exception("SUB reader read only sub records!, not "+r1);

    type = "sub";
    parse_sec_or_pub(scanner);
  }  
  
  public void parseSSB_colon_format(String line) throws Exception
  {                 
    //System.out.println(""+line);
    
    Scanner scanner = new Scanner(line);
    scanner.useDelimiter(":");

    String r1 = scanner.next();
    if(!r1.equalsIgnoreCase("ssb")) throw new Exception("SSB reader read only ssb records!, not "+r1);

    type = "ssb";
    parse_sec_or_pub(scanner);  
  }            

  private void parse_sec_or_pub(Scanner scanner) throws Exception
  {          
    calculatedTrust = scanner.next().trim();
                   
    int strength = scanner.nextInt();
    keyLength = strength;

    int algo = scanner.nextInt();
    algorithm = algo;

    keyID = scanner.next();

    String creationDate = scanner.next();
    long cdmilisec = Long.parseLong(creationDate)*1000;
    created = cdmilisec;

    String expirationDate = scanner.next().trim();
    if(expirationDate.length()>0)
    {
      long edmilisec = Long.parseLong(expirationDate)*1000;
      this.expires = edmilisec;    

    }

    skip(scanner, 1, type+"2");      
    String ignore = scanner.next();

    skip(scanner, 2, type+"3");
    keyCapabilities = scanner.next();
  }
          
  /** fingerprint read
  */
  public void parseFPR_colon_format(String line) throws Exception
  {
    Scanner scanner = new Scanner(line);
    scanner.useDelimiter(":");

    String r1 = scanner.next();
    if(!r1.equalsIgnoreCase("fpr")) throw new Exception("FPR reader read only fpr records!, not "+r1);

    skip(scanner, 8, "FPR0");
    this.fingerprint = scanner.next();
    skip(scanner, 0, "FPR1");
  }  
  
  /** parse name and mail
  */
  public void parseUID_colon_format(String line) throws Exception
  {
    UIDRecord uid = new UIDRecord();
    uid.parseUID_colon_format(line);
    this.uids.add(uid);
  
  }        

  private void skip(Scanner scanner, int n, String prefix)
  {
     for(int i=0; i<n; i++)
     {
        if(!scanner.hasNext()) 
        {
          System.out.println(""+prefix+" has no more entries, stopped skip("+n+") after "+i);
          return;                                                                            
        }

        String ent = scanner.next();
        if(ent.length()>0)
        {
          System.out.println(prefix+" unread rec("+i+")="+ent);
        }
     }
  }
} // KeyID
