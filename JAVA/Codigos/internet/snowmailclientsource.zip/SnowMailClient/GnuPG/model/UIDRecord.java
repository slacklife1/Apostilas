package SnowMailClient.GnuPG.model;

import java.util.*;
import java.io.*;
import java.text.*;

              
/**
   represent a single uid as in                                                                                 
     uid:f::::::::Werner Koch <wk@gnupg.org>:
   A key can have severa uid records  
*/
public final class UIDRecord
{
  private String name;
  private String mail;
  
  public UIDRecord()                                                                                              
  {
                     
  } // Constructor
  
  public final String getName() { return name; }
  public final String getMail() { return mail; }

  /** parse name and mail
  */
  public void parseUID_colon_format(String line) throws Exception
  {
    Scanner scanner = new Scanner(line);
    scanner.useDelimiter(":");
                                     
    String r1 = scanner.next();
    if(!r1.equalsIgnoreCase("uid")) throw new Exception("UID reader read only uid records!, not "+r1);

    String ignored = scanner.next();
    skip(scanner, 3, "UID0");  // forget
    ignored = scanner.next();
    skip(scanner, 1, "UID1");  // forget

    String id1 = scanner.next();

    skip(scanner, 1, "UID2");
    String nameAndMail = scanner.next();
    //System.out.println("UID1= "+id1);
    //System.out.println("UID2= "+id2);

    // search mail
    int posS = nameAndMail.indexOf("<");
    int posE = nameAndMail.indexOf(">", posS+1);

    if(posS>=0&&posE>0)
    {                                    
      name = nameAndMail.substring(0,posS).trim();
      mail = nameAndMail.substring(posS+1, posE).trim();
    }
    else
    {
      name = nameAndMail.trim();
    }   
    //System.out.println("Name="+name);
    //System.out.println("Mail="+mail);
      


    skip(scanner, 0, "UID"); //no more entries
  }        

  private void skip(Scanner scanner, int n, String prefix)
  {
     for(int i=0; i<n; i++)
     {
        if(!scanner.hasNext()) 
        {
          System.out.println(""+prefix+" has no more entries, stopped skip("+n+") after "+i);
          return;                                                                            
        }

        String ent = scanner.next();
        if(ent.length()>0)
        {
          System.out.println(prefix+" unread rec("+i+")="+ent);
        }
     }
  }

} // UIDRecord
