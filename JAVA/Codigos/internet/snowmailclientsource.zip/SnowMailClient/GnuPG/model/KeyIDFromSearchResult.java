package SnowMailClient.GnuPG.model;

import java.util.*;  
import SnowMailClient.Language.Language;
import java.text.*;  
    
/**
(1)	Vanessa Karlo <vanessa.karlo@iba-media.com>
 	Vanessa Karlo <vanessa@professionalexpert.com>
 	  1024 bit DSA key 49D5900B, created: 2005-01-10
(2)	Vanessa Gomes de Oliveira <gomes@comput.ibilce.unesp.br>
  	  1024 bit DSA key 6071465E, created: 2004-11-30
(3)	Vanessa <kf132595@hotmail.com>
  	  2048 bit RSA key 5F0D372F, created: 2004-11-21, expires: 2004-12-22 (expired)
(4)	Vanessa <99190001@webmail.stut.edu.tw>
  	  2048 bit RSA key 0AFF37FF, created: 2004-11-16, expires: 2004-12-20 (expired)
(5)	Vanessa Michele Rose Warner (personal gpg key) <ness@nessuk.org>
  	  1024 bit DSA key 59309409, created: 2004-11-05
(6)	Vanessa Karlo <vanessa@professionalexpert.com>
  	  1024 bit DSA key 67D501DD, created: 2004-10-20 (revoked)     
(7)	Vanesssa Karlo <vanessa@professionalexpert.com>
 	  1024 bit DSA key 5A887734, created: 2004-10-16

*/
public final class KeyIDFromSearchResult
{
  private final Vector<String> addresses = new Vector<String>();  
  private boolean revoked = false;
  private boolean expired = false;
  private int keyLength   = -1;
  private long created    = -1;
  private long expires    = -1;   // never
  private String shortID  = null;
  private String algorithm = null;
          
  public static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
          
  public KeyIDFromSearchResult()
  {

  } // Constructor
  
  /** can have multiple addresses
  */
  public void addAddress(String add)
  { 
     addresses.add(add);
  }      
  
  public void parseIDLine(String kid)
  {       
     Scanner s = new Scanner(kid);
     keyLength = s.nextInt();
     s.next();
     algorithm = s.next();
     s.next();
     shortID = this.removeComa(s.next());
     s.next(); // created:
     if(!s.hasNext()) return;
     
     String n = s.next();

     try
     {
       created = dateFormat.parse(n).getTime();
     }
     catch(Exception e)
     {
       e.printStackTrace();
     }
     
     
     if(!s.hasNext()) return;
     
     n = s.next();   
     
     if(n.startsWith("expired")) 
     { 
        expired = true;
        return;
     }  
     
     if(n.indexOf("revoked")>=0)
     {
        revoked = true;
     }
     
     if(n.equalsIgnoreCase("expires:"))  
     {
        try        
        {   
          n = s.next();                         
          this.expires = dateFormat.parse(n).getTime();
          if(System.currentTimeMillis() > expires) expired=true;
        }
        catch(Exception e)
        {
          e.printStackTrace();
        }        
     }
  }  
  
  private String removeComa(String in)
  {
    if(in.endsWith(","))return in.substring(0,in.length()-1);
    return in;
  }
  
  public String getKeyShortID()
  {
     return shortID;
  }                 
  
  public String getRemarks()
  {
     if(revoked) return Language.translate("Revoqued").toUpperCase();
     if(expired) return Language.translate("Expired").toUpperCase();
     return "";
  }

  public String toString()
  {  
     StringBuffer sb = new StringBuffer();
     if(getRemarks().length()>0) 
     {
       sb.append(getRemarks()+"\t");
     }
     sb.append(toStringAddresses());
     sb.append("\t");           
     sb.append(shortID);
     sb.append("\t, created ");           
     sb.append(dateFormat.format(new Date(this.created)));
     sb.append("\t, expires ");           
     sb.append(dateFormat.format(new Date(this.expires)));
     return sb.toString();
  }
  
  public String toStringAddresses()
  {  
     StringBuffer sb = new StringBuffer(); 
     if(addresses.size()==1)
     {
       sb.append(addresses.elementAt(0));
     }
     else
     {
       sb.append(addresses);
     }
     //sb.append("\t");           
     //sb.append(shortID);
     return sb.toString();
  }    

} // KeyIDFromSearchResult
