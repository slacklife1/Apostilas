package SnowMailClient.GnuPG.LineProcessors;

import SnowMailClient.GnuPG.model.*;
import java.util.*;
import java.io.*;
      
public class KeySearchResultProcessor implements LineProcessor
{
  private final Vector<KeyIDFromSearchResult> keys = new Vector<KeyIDFromSearchResult>();
  private KeyIDFromSearchResult actual = null;       
    
  public KeySearchResultProcessor()
  {

  } // Constructor

  public Vector<KeyIDFromSearchResult> getKeyIDs() { return keys; }

  public void processLine(String _line)
  {
    String line = _line.trim();
    if(line.startsWith("gpg:"))
    {
      // ignore messages from gpg, they are conversion errors, not very illuminating...  
      // like  gpg: conversion from `utf-8' to `CP850' failed: Illegal byte sequence
    }
    else if(line.startsWith("("))
    {      
      actual = new KeyIDFromSearchResult();
      keys.addElement(actual);
      int pos = line.indexOf(")");
      if(pos>0) line = line.substring(pos+1).trim();
      actual.addAddress(line);
    }
    else if(line.indexOf("@")>0)
    {
      actual.addAddress(line);
    } 
    else
    {
      actual.parseIDLine(line);
    }

  }
  
  
  public String toString()
  {
    StringBuffer sb = new StringBuffer();
    for(KeyIDFromSearchResult k: keys)
    {
       sb.append(""+k+"\n");
    }
    return sb.toString();
  }


  
  public static void main(String[] a)
  {    
    KeySearchResultProcessor kr = new KeySearchResultProcessor();
    kr.test();
  }
  
  private void test()
  {                                                                                                         
    try
    { 
      
      FileInputStream fis = new FileInputStream("c:/temp/kex.txt");
      BufferedReader r= new BufferedReader(new InputStreamReader(fis));
      String line;
      while((line=r.readLine())!=null)
      {  
        processLine(line);
      } 
      System.out.println(""+this);                     
      
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }


} // KeySearchResultProcessor


/*

(1)	Vanessa Karlo <vanessa.karlo@iba-media.com>
 	Vanessa Karlo <vanessa@professionalexpert.com>
 	  1024 bit DSA key 49D5900B, created: 2005-01-10
(2)	Vanessa Gomes de Oliveira <gomes@comput.ibilce.unesp.br>
  	  1024 bit DSA key 6071465E, created: 2004-11-30
(3)	Vanessa <kf132595@hotmail.com>
  	  2048 bit RSA key 5F0D372F, created: 2004-11-21, expires: 2004-12-22 (expired)
(4)	Vanessa <99190001@webmail.stut.edu.tw>
  	  2048 bit RSA key 0AFF37FF, created: 2004-11-16, expires: 2004-12-20 (expired)
(5)	Vanessa Michele Rose Warner (personal gpg key) <ness@nessuk.org>
  	  1024 bit DSA key 59309409, created: 2004-11-05
(6)	Vanessa Karlo <vanessa@professionalexpert.com>
  	  1024 bit DSA key 67D501DD, created: 2004-10-20 (revoked)
(7)	Vanesssa Karlo <vanessa@professionalexpert.com>
 	  1024 bit DSA key 5A887734, created: 2004-10-16
(8)	Vanessa Innes <vji@georgetown.edu>
 	  1024 bit DSA key 4BD5B818, created: 2004-08-13
(9)	vanessa de lima lopez <guachiguachi70@hotmail.com>
 	  1024 bit DSA key 46C76F12, created: 2004-06-14
(10)	Vanessa Vieira <yeye149@hotmail.com>
 	  1024 bit DSA key 3566F0D9, created: 2004-06-11
(11)	Vanessa Matas (Ambar) <ambar@fibranet.org>
  	  1024 bit DSA key 1167FE29, created: 2004-05-16

*/
