package SnowMailClient.GnuPG.LineProcessors;


/** Simply prints the read line
*/
public final class SimpleLineProcessor implements LineProcessor
{
  String linePrefix;

  public SimpleLineProcessor(String linePrefix)
  { 
    this.linePrefix = linePrefix;
  }

  public void processLine(String line)
  {
    System.out.println(linePrefix+line);
  }

}
