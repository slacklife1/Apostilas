package SnowMailClient.GnuPG.LineProcessors;

import java.util.*;

public final class ErrorLineProcessor implements LineProcessor
{
  final Vector<String> errorLines = new Vector<String>();

  public ErrorLineProcessor()
  {
  } // Constructor

  public void processLine(String line)
  {
     if(line.trim().length()>0)
     {
       System.out.println("GPG Error stream: "+line);
       errorLines.add(line);
     }
  }

  public boolean hasError()
  {
     for(String line: errorLines)
     {
        if(line.toLowerCase().indexOf("error")>=0)
        {
          // ignore loading errors, occur in 1.4 cause an iconv.dll not found
          if(line.toLowerCase().indexOf("error loading")==-1) return true;
        }
     }

     return false;
  }

  public boolean hasText(String lower)
  {
     for(String line: errorLines)
     {
        if(line.toLowerCase().indexOf(lower)>=0) return true;
     }

     return false;
  }

  public Vector<String> getAllLines() { return errorLines; }

  public String getAllErrorMessage()
  {
     StringBuffer sb = new StringBuffer();
     for(String line: errorLines)
     {
        sb.append(line);
        sb.append("\n");
     }
     return sb.toString().trim();
  }




} // ErrorLineProcessor
