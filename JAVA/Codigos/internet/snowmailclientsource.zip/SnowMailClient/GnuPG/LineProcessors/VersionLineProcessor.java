package SnowMailClient.GnuPG.LineProcessors;

import SnowMailClient.GnuPG.model.*;
import java.util.*;

/** to be used in the gobbler to read keys from gpg output response
    either public or secret key, depending on the gpg command
*/
public final class VersionLineProcessor implements LineProcessor
{
  String version = "";
  String completeVersionDescription = "";

  public void processLine(String line)
  {
    completeVersionDescription += "\n"+line;
    if(version.length()==0) version = line.trim();
  }

  public String getVersion() { return version; }
  public String getCompleteVersionDescription() { return completeVersionDescription.trim(); }
  

}

                               
