package SnowMailClient.GnuPG.LineProcessors;
   
public interface LineProcessor
{
   public void processLine(String line);
     
} // LineProcessor  