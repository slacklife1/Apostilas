package SnowMailClient.GnuPG.LineProcessors;

import SnowMailClient.GnuPG.model.*;
import java.util.*;
import java.io.*;

public final class KeyIDReader implements LineProcessor    
{
  Vector<GnuPGKeyID> keyIDs = new Vector<GnuPGKeyID>();
  GnuPGKeyID last = null; 


  /**
            crt = X.509 certificate
            crs = X.509 certificate and private key available
	
	    uat = user attribute (same as user id except for field 10).
            sig = signature           
            rev = revocation signature
	    pkd = public key data (special field format, see below)
            grp = reserved for gpgsm  
            rvk = revocation key
            spk = signature subpacket
  */
  public void processLine(String line) //throws Exception
  { 
    if(line.length()<3) return;   // ignores !
    //System.out.println(">>> "+line);

    String recordType = line.substring(0,3).toLowerCase();
    if(recordType.equals("gpg"))          // greeting
    {
    }
    else if(recordType.equals("---"))     // stupid separation
    {
    }
    else if(recordType.equals("tru"))     // trust database information
    {
    }
    else if(recordType.equals("sec"))     // secret key
    {
      last= new GnuPGKeyID(true);
      this.keyIDs.add(last);

      try
      {
        last.parseSEC_colon_format(line);
      } catch(Exception e) {throw new RuntimeException(e); }

    }
    else if(recordType.equals("pub"))     // public key
    {
      last = new GnuPGKeyID(true);
      this.keyIDs.add(last);

      try
      {
        last.parsePUB_colon_format(line);
      } catch(Exception e) {throw new RuntimeException(e); }

    }
    else if(recordType.equals("fpr"))     // fingerprint: (fingerprint is in field 10)
    {         
      try           
      {
        last.parseFPR_colon_format(line);
      } catch(Exception e) {throw new RuntimeException(e); }

    }
    else if(recordType.equals("uid"))     // uid = user id (only field 10 is used).
    {
      try
      {
        last.parseUID_colon_format(line);
      } catch(Exception e) {throw new RuntimeException(e); }
    }
    else if(recordType.equals("sub"))     // subkey (secondary key)
    {
      GnuPGKeyID sk = new GnuPGKeyID(false);
      try
      {
        sk.parseSUB_colon_format(line);
        last.addSubKey(sk);
      } catch(Exception e) {throw new RuntimeException(e); }
    }
    else if(recordType.equals("ssb"))     // secret subkey (secondary key)
    {
      GnuPGKeyID sk = new GnuPGKeyID(false);
      try
      {
        sk.parseSSB_colon_format(line);
        last.addSubKey(sk);
      } catch(Exception e) {throw new RuntimeException(e); }
    }   
    else if(recordType.equals("uat"))
    {
      // ???
      // uat = user attribute (same as user id except for field 10).
    }
    else
    {
      System.out.println("Unknown key list record: "+recordType);
      System.out.println("  "+line);     
    }   
  }
  


  public Vector<GnuPGKeyID> getKeyIDs() {return keyIDs;}




} // KeyIDReader

/**
Format of colon listings
========================
First an example:

$ gpg --fixed-list-mode --with-colons --list-keys \
   --with-fingerprint --with-fingerprint wk@gnupg.org

pub:f:1024:17:6C7EE1B8621CC013:899817715:1055898235::m:::scESC:
fpr:::::::::ECAF7590EB3443B5C7CF3ACB6C7EE1B8621CC013:
uid:f::::::::Werner Koch <wk@g10code.com>:
uid:f::::::::Werner Koch <wk@gnupg.org>:
sub:f:1536:16:06AD222CADF6A6E1:919537416:1036177416:::::e:
fpr:::::::::CF8BCC4B18DE08FCD8A1615906AD222CADF6A6E1:
sub:r:1536:20:5CE086B5B5A18FF4:899817788:1025961788:::::esc:
fpr:::::::::AB059359A3B81F410FCFF97F5CE086B5B5A18FF4:

The double --with-fingerprint prints the fingerprint for the subkeys
too, --fixed-list-mode is the modern listing way printing dates in
seconds since Epoch and does not merge the first userID with the pub
record.


 1. Field:  Type of record
	    pub = public key
            crt = X.509 certificate
            crs = X.509 certificate and private key available
	    sub = subkey (secondary key)
	    sec = secret key
	    ssb = secret subkey (secondary key)
	    uid = user id (only field 10 is used).
	    uat = user attribute (same as user id except for field 10).
            sig = signature
            rev = revocation signature
	    fpr = fingerprint: (fingerprint is in field 10)
	    pkd = public key data (special field format, see below)
            grp = reserved for gpgsm
            rvk = revocation key
            tru = trust database information
            spk = signature subpacket  

 2. Field:  A letter describing the calculated trust. This is a single
	    letter, but be prepared that additional information may follow
	    in some future versions. (not used for secret keys)
		o = Unknown (this key is new to the system)
                i = The key is invalid (e.g. due to a missing self-signature)
		d = The key has been disabled
		    (deprecated - use the 'D' in field 12 instead)
		r = The key has been revoked
		e = The key has expired
		- = Unknown trust (i.e. no value assigned)
		q = Undefined trust
	            '-' and 'q' may safely be treated as the same
		    value for most purposes
		n = Don't trust this key at all
		m = There is marginal trust in this key
		f = The key is fully trusted
		u = The key is ultimately trusted.  This often means
		    that the secret key is available, but any key may
		    be marked as ultimately trusted.
 3. Field:  length of key in bits.
 4. Field:  Algorithm:	1 = RSA
		       16 = Elgamal (encrypt only)
		       17 = DSA (sometimes called DH, sign only)
		       20 = Elgamal (sign and encrypt - don't use them!)
	    (for other id's see include/cipher.h)
 5. Field:  KeyID
 6. Field:  Creation Date (in UTC).  For UID and UAT records, this is the
            self-signature date.  Note that the dae is usally printed
            in seconds since epoch, however, we are migrating to an ISO
            8601 format (e.g. "19660205T091500").  This is currently
            only relevant for X.509, A simple way to detect the format
            is be scannning for the 'T'.
 7. Field:  Key or user ID/user attribute expiration date or empty if none.
 8. Field:  Used for serial number in crt records (used to be the Local-ID).
            For UID and UAT records, this is a hash of the user ID contents
            used to represent that exact user ID.  For trust signatures,
            this is the trust depth seperated by the trust value by a
            space.
 9. Field:  Ownertrust (primary public keys only)
	    This is a single letter, but be prepared that additional
	    information may follow in some future versions.  For trust
	    signatures with a regular expression, this is the regular
	    expression value, quoted as in field 10.
10. Field:  User-ID.  The value is quoted like a C string to avoid
	    control characters (the colon is quoted "\x3a").
            This is not used with --fixed-list-mode in gpg.
            A UAT record puts the attribute subpacket count here, a
	    space, and then the total attribute subpacket size.
            In gpgsm the issuer name comes here
            An FPR record stores the fingerprint here.
            The fingerprint of an revocation key is stored here.
11. Field:  Signature class.  This is a 2 digit hexnumber followed by
            either the letter 'x' for an exportable signature or the
            letter 'l' for a local-only signature.
            The class byte of an revocation key is also given here,
            'x' and 'l' ist used the same way.
12. Field:  Key capabilities:
                e = encrypt
                s = sign
                c = certify
                a = authentication
	    A key may have any combination of them in any order.  In
	    addition to these letters, the primary key has uppercase
	    versions of the letters to denote the _usable_
	    capabilities of the entire key, and a potential letter 'D'
	    to indicate a disabled key.
13. Field:  Used in FPR records for S/MIME keys to store the fingerprint of
            the issuer certificate.  This is useful to build the
            certificate path based on certificates stored in the local
            keyDB; it is only filled if the issue certificate is
            available. The advantage of using this value is that it is
            guaranteed to have been been build by the same lookup
            algorithm as gpgsm uses.
            For "uid" recods this lists the preferences n the sameway the 
            -edit menu does.
	    For "sig" records, this is the fingerprint of the key that
	    issued the signature.  Note that this is only filled in if
	    the signature verified correctly.  Note also that for
	    various technical reasons, this fingerprint is only
	    available if --no-sig-cache is used.

14. Field   Flag field used in the --edit menu output:

15. Field   Used in sec/sbb to print the serial number of a token
            (internal protect mode 1002) or a '#' if that key is a
            simple stub (internal protect mode 1001)

All dates are displayed in the format yyyy-mm-dd unless you use the
option --fixed-list-mode in which case they are displayed as seconds
since Epoch.  More fields may be added later, so parsers should be
prepared for this. When parsing a number the parser should stop at the
first non-number character so that additional information can later be
added.

If field 1 has the tag "pkd", a listing looks like this:
pkd:0:1024:B665B1435F4C2 .... FF26ABB:
    !  !   !-- the value
    !  !------ for information number of bits in the value
    !--------- index (eg. DSA goes from 0 to 3: p,q,g,y)


The "tru" trust database records have the fields:

 2: Reason for staleness of trust.  If this field is empty, then the
    trustdb is not stale.  This field may have multiple flags in it:

    o: Trustdb is old
    t: Trustdb was built with a different trust model than the one we
       are using now.

 3: Trust model:
    0: Classic trust model, as used in PGP 2.x.
    1: PGP trust model, as used in PGP 6 and later.  This is the same
       as the classic trust model, except for the addition of trust
       signatures.

    GnuPG before version 1.4 used the classic trust model by default.
    GnuPG 1.4 and later uses the PGP trust model by default.
                                                     
 4: Date trustdb was created in seconds since 1/1/1970.
 5: Date trustdb will expire in seconds since 1/1/1970.  

The "spk" signature subpacket records have the fields:

 2: Subpacket number as per RFC-2440 and later.
 3: Flags in hex.  Currently the only two bits assigned are 1, to
    indicate that the subpacket came from the hashed part of the
    signature, and 2, to indicate the subpacket was marked critical.
 4: Length of the subpacket.  Note that this is the length of the
    subpacket, and not the length of field 5 below.  Due to the need
    for %-encoding, the length of field 5 may be up to 3x this value.
 5: The subpacket data.  Printable ASCII is shown as ASCII, but other
    values are rendered as %XX where XX is the hex value for the byte.

*/
