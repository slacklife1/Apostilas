package SnowMailClient.GnuPG.LineProcessors;


import java.util.*;
import java.io.*;
               
public final class StreamLineGobbler extends Thread
{
    private InputStream  inputStream;
    LineProcessor lineProcessor;


   /**
    *  Constructor 1.
    */
    public StreamLineGobbler( final InputStream inputStream, LineProcessor lineProcessor)
    {
      this.inputStream = inputStream;
      this.lineProcessor = lineProcessor;
    }



    public void run()
    {
      try
       {     
         final InputStreamReader isr = new InputStreamReader(this.inputStream);
         final BufferedReader br = new BufferedReader(isr);
         String line = null;
         while( (line = br.readLine()) != null)
         {
            lineProcessor.processLine( line );
         }
       }
      catch( IOException ioe )
       {
         ioe.printStackTrace();
       }
    } //run



}
