package SnowMailClient.GnuPG.Main;

import java.util.*;
import java.io.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

import SnowMailClient.utils.*;

import snow.utils.gui.*;
import snow.crypto.*;
import snow.concurrent.*;

import SnowMailClient.utils.storage.*;
import SnowMailClient.GnuPG.LineProcessors.*;
import SnowMailClient.GnuPG.model.*;
import SnowMailClient.crypto.*;
import SnowMailClient.Language.Language;
                                                                                  
                               
/** Here are all the commands that call gpg.exe and gobbles the in & out streams
*/                                              
public final class GnuPGCommands
{                             
                        
  private GnuPGCommands()
  {

  } // Constructor
  
  /** read all the public keys present in the gpg installation
  */                         
  public static Vector<GnuPGKeyID> readPublicKeyIDs(String pathToGPG) throws Exception
  {    
    if(!new File(pathToGPG).exists()) throw new Exception(Language.translate("GnuPG path invalid"));
    Process p = Runtime.getRuntime().exec(new String[]{pathToGPG, "--no-greeting", "--with-fingerprint", "--fixed-list-mode", "--with-colons", "--list-public-keys"});
                
    // forget errors
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();

    KeyIDReader keyIDLineProcessor = new KeyIDReader();
    StreamLineGobbler inGobbler = new StreamLineGobbler(p.getInputStream(), keyIDLineProcessor);
    inGobbler.start();

    int rep = p.waitFor();
    try
    {
      inGobbler.join(5000);
    } catch(Exception e) {}

    try
    {
      errGobbler.join(5000);
    } catch(Exception e) {}

    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());

    return keyIDLineProcessor.getKeyIDs();
  }

  
  public static Vector<GnuPGKeyID> readSecretKeyIDs(String pathToGPG) throws Exception
  {
    if(!new File(pathToGPG).exists()) throw new Exception(Language.translate("GnuPG path invalid"));
    Process p = Runtime.getRuntime().exec(new String[]{pathToGPG, "--no-greeting", "--with-fingerprint", "--fixed-list-mode", "--with-colons", "--list-secret-keys"});
                        
    // forget errors
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();

    KeyIDReader keyIDLineProcessor = new KeyIDReader();
    StreamLineGobbler inGobbler = new StreamLineGobbler(p.getInputStream(), keyIDLineProcessor);
    inGobbler.start();

    int rep = p.waitFor();

    try
    {
      inGobbler.join(5000);
    } catch(Exception e) {}

    try
    {
      errGobbler.join(5000);
    } catch(Exception e) {}

    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());

    return keyIDLineProcessor.getKeyIDs();
  }    
  
  /** read version of gpg (1.2.2, 1.4.0, ...)
  */
  public static String readGPGVersion(String pathToGPG) throws Exception
  {                                   
    if(!new File(pathToGPG).exists()) throw new Exception(Language.translate("GnuPG path invalid"));
    Process p = Runtime.getRuntime().exec(new String[]{pathToGPG, "--version"});

    // forget errors         
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();

    VersionLineProcessor vlp = new VersionLineProcessor();
    StreamLineGobbler inGobbler = new StreamLineGobbler(p.getInputStream(), vlp);
    inGobbler.start();

    int rep = p.waitFor();
    
    try
    {
      inGobbler.join(5000);               
    } catch(Exception e) {}

    try                                                                             
    {
      errGobbler.join(5000);
    } catch(Exception e) {}

    //CAUTION, in 1.4, some DLL are not read...
    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());

    // vlp.getCompleteVersionDescription();

    return vlp.getVersion();  // only the first line
  }
  

  
  /** encrypt for a given recipient
  */
  public static String encryptBufferForRecipient(
                           String pathToGPG, 
                           String message, 
                           GnuPGKeyID keyID, 
                           boolean ascii,
                           Interrupter interrupter) throws Exception
  {
    //System.out.println("Encrypting for "+keyID.getKeyID());

    Process p = Runtime.getRuntime().exec(new String[]{
       pathToGPG, "-e"+(ascii?"a":""),
       "--quiet", "--yes", "--batch", "--no-greeting",
       "--trust-model", "always",      // :-(
       "-r", keyID.getFingerprint()
    });

    if(interrupter!=null)
    {
      interrupter.setProcessToOptionalKill(p);
    }


    // forget errors
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();

    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    StreamGobbler inGobbler = new StreamGobbler(p.getInputStream(), bos);
    inGobbler.start();                           

    // write message
    ByteArrayInputStream bin = new ByteArrayInputStream(message.getBytes());
    byte[] buf = new byte[256];
    int read =-1;
    while(( read=bin.read(buf))!=-1)
    {
       p.getOutputStream().write(buf,0,read);
    }

    // EOF
    try
    {
      p.getOutputStream().flush();
      p.getOutputStream().close();
    }                      
    catch(Exception ignored) {}

    int rep = p.waitFor();

    try
    {
      inGobbler.join(5000);
    } catch(Exception e) {}

    try
    {
      errGobbler.join(5000);
    } catch(Exception e) {}
   
    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());
    /* occurs often when trust not set !
     GPG Error stream: gpg: DAB17279: There is no assurance this key belongs to the named user
     GPG Error stream: gpg: [stdin]: encryption failed: unusable public key
    */
    if(errorProcessor.hasText("failed")) throw new Exception(errorProcessor.getAllErrorMessage());

    return new String(bos.toByteArray());
  }


  public static boolean verifySecretKeyPassword(String pathToGPG, GnuPGKeyID keyID, byte[] pass) throws Exception
  {
     try
     {
       ByteArrayInputStream bin = new ByteArrayInputStream("Hello this is a test".getBytes());
       byte[] result = signBuffer(pathToGPG, bin, keyID, pass, null);
       if(result==null) return false;
       
       return true;
     }
     catch(BadPasswordException be)
     {             
       return false;
     }
     catch(Exception e)
     {
       throw e;
     }
  }
  
   

  /** sign a message with the key.
     This appends a clear text signature that wraps the original clear text.
     CAUTION: The text is NOT enciphered
  */                                               
  public static byte[] signBuffer(String pathToGPG, ByteArrayInputStream bin, GnuPGKeyID keyID, byte[] pass, Interrupter interrupter
     ) throws Exception
  {
    Process p = Runtime.getRuntime().exec(new String[]{
       pathToGPG, "--clearsign", "--sign", "-a",
       "--quiet", "--yes", "--no-greeting",
       "-u",  "\""+keyID.getKeyID()+"\"",
       "--passphrase-fd", "0"            // give password in stdin
    });  
    
    if(interrupter!=null) interrupter.setProcessToOptionalKill(p);        
                
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();    

    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    StreamGobbler inGobbler = new StreamGobbler(p.getInputStream(), bos);
    inGobbler.start();
                                
    // give password in stdin
    p.getOutputStream().write(pass);
    p.getOutputStream().write((byte)'\n');
    p.getOutputStream().flush();             

    // write message
    byte[] buf = new byte[256];
    int read =-1;
    while(( read=bin.read(buf))!=-1)
    {
       p.getOutputStream().write(buf,0,read);
    }

    // EOF
    p.getOutputStream().flush();
    p.getOutputStream().close();

    int rep = p.waitFor();

    try
    {
      inGobbler.join(5000);
    } catch(Exception e) {}

    try
    {
      errGobbler.join(5000);
    } catch(Exception e) {}

    if(errorProcessor.hasText("bad passphrase"))                                          
    {
      throw new BadPasswordException(Language.translate("Bad passphrase for %",keyID.getKeyID()));
    }                    

    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());

    return bos.toByteArray();
  }  

  /** @throws Exception
  *
  public static Vector<SignatureVerificationResult> decryptMessage(String pathToGPG, InputStream signedMessage) throws Exception
  {
    Process p = Runtime.getRuntime().exec(new String[]{
       pathToGPG, "--quiet", "--decrypt"});
                                       
    return null;
  }*/
                                       

  /** @throws Exception
  */                                                   
  public static Vector<SignatureVerificationResult> verifySignature(
                                String pathToGPG, InputStream signedMessage,
                                ProgressModalDialog progress) throws Exception
  {                         
    Process p = Runtime.getRuntime().exec(new String[]{
       pathToGPG, "--no-greeting", "--quiet", "--batch", "--fixed-list-mode", "--with-colons", "--verify",});
                  
    if(progress!=null) progress.setProcessToOptionalKill(p);
                   
    // the signature verify occurs on the error stream !!

    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();      

    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    StreamGobbler inGobbler = new StreamGobbler(p.getInputStream(), bos);
    inGobbler.start();             
                           
    // write message
    byte[] buf = new byte[256];
    int read =-1;
    while(( read=signedMessage.read(buf))!=-1)
    {
       p.getOutputStream().write( buf, 0, read);
    }         

    // EOF
    p.getOutputStream().flush();
    p.getOutputStream().close();

    int rep = p.waitFor();

    try
    {
      inGobbler.join(5000);
    } catch(Exception e) {}

    try
    {
      errGobbler.join(5000);
    } catch(Exception e) {}
    
    // ok, whole process & read terminated. 
    // let us analyse the output now
    Vector<SignatureVerificationResult> signatures = parseSignaturesFromOutput(errorProcessor.getAllErrorMessage());

    if(errorProcessor.hasText("invalid")) throw new Exception(errorProcessor.getAllErrorMessage());
    if(errorProcessor.hasText("CRC error")) throw new Exception(errorProcessor.getAllErrorMessage());

    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());

    return signatures;
  }


  private static Vector<SignatureVerificationResult> parseSignaturesFromOutput(String text) throws Exception
  {
     System.out.println("\n========= Parse signature verif from ========\n"+text+"\n\n");
     BufferedReader br = new BufferedReader(new StringReader(text));
     Vector<SignatureVerificationResult> signatures = new Vector<SignatureVerificationResult>();

     SignatureVerificationResult actual = null; 
     String line = null;
     while((line = br.readLine())!=null)
     {     
       if(line.indexOf("Signature made")>=0)
       {
         // this is the start of a new signature result
         if(actual!=null) signatures.addElement(actual);
         actual = new SignatureVerificationResult();
         actual.parseLine(line);
       }
       else
       {           
         if(actual!=null) actual.parseLine(line);
       }
     }
     
     if(actual!=null) signatures.addElement(actual);

     return signatures;
  }  
  
   
  /** decrypt for a given recipient  
  */
  public static String decryptBufferForRecipient(String pathToGPG, 
                  String encryptedMessage, GnuPGKeyID keyID, byte[] pass,
                  ProgressModalDialog progress) throws Exception
  {
    Process p = Runtime.getRuntime().exec(new String[]{
       pathToGPG, 
       //"--quiet", "--yes",
       "--no-greeting",
       "--passphrase-fd", "0", //,            // give password in stdin
       //"-r",  "\""+keyID.getKeyID()+"\""     
       "--decrypt"                                                   
    });  
                   
    if(progress!=null)
    {
      progress.setProcessToOptionalKill(p);
    }

    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();

    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    StreamGobbler inGobbler = new StreamGobbler(p.getInputStream(), bos);
    inGobbler.start();
    
    // give password in stdin
    p.getOutputStream().write(pass);
    p.getOutputStream().write((byte)'\n');
    p.getOutputStream().flush();             

    // write message 
    ByteArrayInputStream bin = new ByteArrayInputStream(encryptedMessage.getBytes());
    byte[] buf = new byte[256];
    int read =-1;
    while(( read=bin.read(buf))!=-1)
    {
       p.getOutputStream().write(buf,0,read);
    }
        
    // EOF
    p.getOutputStream().flush();
    p.getOutputStream().close();

    int rep = p.waitFor();

    try
    {
      inGobbler.join(5000);
    } catch(Exception e) {}

    try
    {
      errGobbler.join(5000);
    } catch(Exception e) {}                                                                       

    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());
    if(errorProcessor.hasText("failed")) throw new Exception(errorProcessor.getAllErrorMessage());

    return new String(bos.toByteArray());      
  }


  /** set the trust
  1 = I don't know or won't say
  2 = I do NOT trust                                                                                             
  3 = I trust marginally
  4 = I trust fully
  5 = I trust ultimately     
  */                                     
  public static void setTrust(String pathToGPG,
                  GnuPGKeyID keyID, int newTrust,
                  ProgressModalDialog progress) throws Exception
  {
    System.out.println("Set trust to "+newTrust+" for "+keyID.getMails());

    Process p = Runtime.getRuntime().exec(new String[]{
       pathToGPG, "--yes", "--yes",
       "--no-comments", "--no-greeting",
       "--command-fd", "0", 
       "--edit-key", keyID.getFingerprint()
    });
             
    if(progress!=null)
    {
      progress.setProcessToOptionalKill(p);
    }

    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();                 

    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    StreamGobbler inGobbler = new StreamGobbler(p.getInputStream(), bos);
    inGobbler.start();


    // write trust
    p.getOutputStream().write("trust".getBytes());
    p.getOutputStream().write((byte)'\n');
    p.getOutputStream().flush();

    p.getOutputStream().write((""+newTrust).getBytes());
    p.getOutputStream().write((byte)'\n');
    p.getOutputStream().flush();
                                         
    if(newTrust==5)
    {
      p.getOutputStream().write("y".getBytes());
      p.getOutputStream().write((byte)'\n');
      p.getOutputStream().flush();
    }

    p.getOutputStream().write("save".getBytes());
    p.getOutputStream().write((byte)'\n');
    p.getOutputStream().flush();

    p.getOutputStream().close();

    int rep = p.waitFor();

    try
    {
      inGobbler.join(5000);
    } catch(Exception e) {}

    try
    {
      errGobbler.join(5000);
    } catch(Exception e) {}


    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());
    if(errorProcessor.hasText("failed")) throw new Exception(errorProcessor.getAllErrorMessage());

    System.out.println("SetTrust err message="+errorProcessor.getAllErrorMessage());
    System.out.println("SetTrust response="+new String(bos.toByteArray()));

  }

  /** finds out which key is needed to decrypt the message
      try to decrypt with a false password and analyse the result.
      @return {name, ID}
  */
  public static String[] determineUsedKey(String pathToGPG,
                  String encryptedMessage,
                  ProgressModalDialog progress) throws Exception
  {
    Process p = Runtime.getRuntime().exec(new String[]{
       pathToGPG,
       //"--quiet", "--yes",
       "--no-greeting",
       "--passphrase-fd", "0",       // give password in stdin
       "--decrypt"                                                   
    });  
                   
    if(progress!=null)
    {
      progress.setProcessToOptionalKill(p);
    }

    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();

    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    StreamGobbler inGobbler = new StreamGobbler(p.getInputStream(), bos);
    inGobbler.start();
    
    // give password in stdin
    p.getOutputStream().write("---------------------------�*@\n".getBytes());    // surely false
    p.getOutputStream().flush();             

    // write message 
    ByteArrayInputStream bin = new ByteArrayInputStream(encryptedMessage.getBytes());
    byte[] buf = new byte[256];
    int read =-1;
    while(( read=bin.read(buf))!=-1)
    {
       p.getOutputStream().write(buf,0,read);
    }
        
    // EOF
    p.getOutputStream().flush();
    p.getOutputStream().close();

    int rep = p.waitFor();

    try
    {
      inGobbler.join(5000);
    } catch(Exception e) {}

    try
    {
      errGobbler.join(5000);
    } catch(Exception e) {}
     
    // if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());
    // if(errorProcessor.hasText("failed")) throw new Exception(errorProcessor.getAllErrorMessage()); 
    String erm = errorProcessor.getAllErrorMessage();// + new String(bos.toByteArray());
    int pos = erm.indexOf("ID "); 
    if(pos==-1) throw new Exception(Language.translate("Cannot find key ID in")+erm);
    int posEnd=erm.indexOf(",", pos+3);
    String ID = erm.substring(pos+3,posEnd);
//    System.out.println("ERM="+erm);

    pos = erm.indexOf("  \"");
    if(pos==-1) throw new Exception(Language.translate("Cannot find key name in")+erm);
    posEnd=erm.indexOf("\"", pos+3);
    String name = erm.substring(pos+3,posEnd);
  
    return new String[]{ID, name};
  }


  public static String getPublicKey(String pathToGPG, GnuPGKeyID id) throws Exception                                        
  {
    Process p = Runtime.getRuntime().exec(new String[]{
       pathToGPG, "--armor", "--export", id.getKeyID()
    });
                            

    // forget errors
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();
                                                                                                                      
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    StreamGobbler inGobbler = new StreamGobbler(p.getInputStream(), bos);
    inGobbler.start();

    int rep = p.waitFor();
    try
    {
      inGobbler.join(5000);
    } catch(Exception e) {}

    try
    {
      errGobbler.join(5000);
    } catch(Exception e) {}

    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());
    if(errorProcessor.hasText("warning")) throw new Exception(errorProcessor.getAllErrorMessage());

    return new String(bos.toByteArray());
  }   
  
  
  public static String getSecretKey(String pathToGPG, GnuPGKeyID id) throws Exception
  {
    Process p = Runtime.getRuntime().exec(new String[]{
       pathToGPG, "--armor", "--export-secret-keys", id.getKeyID()
    });
                

    // forget errors
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();

    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    StreamGobbler inGobbler = new StreamGobbler(p.getInputStream(), bos);
    inGobbler.start();

    int rep = p.waitFor();
    try
    {
      inGobbler.join(5000);
    } catch(Exception e) {}

    try
    {
      errGobbler.join(5000);
    } catch(Exception e) {}

    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());

    return new String(bos.toByteArray());
  }
         
         
  public static void addKey(String pathToGPG, String asciikey) throws Exception
  {
    Process p = Runtime.getRuntime().exec(new String[]{
       pathToGPG, "--batch", "--quiet", "--yes", "--import"
    });


    // forget errors
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();

    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    StreamGobbler inGobbler = new StreamGobbler(p.getInputStream(), bos);
    inGobbler.start();    
        
    // write key
    p.getOutputStream().write(asciikey.getBytes());
    p.getOutputStream().write("\r\n".getBytes());
    // EOF
    p.getOutputStream().flush();
    p.getOutputStream().close();

                                                                                                                
    int rep = p.waitFor();
    try                                                                                    
    {                                        
      inGobbler.join(5000);                                                                                 
    } catch(Exception e) {}                                                                                                                   
                                                                                                     
    try     
    {
      errGobbler.join(5000);
    } catch(Exception e) {} 
     
    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());
    
    System.out.println("in: "+new String(bos.toByteArray()));                                                        
  }   
  
  public static void removePublicKey(String pathToGPG, GnuPGKeyID id) throws Exception
  {
    Process p = Runtime.getRuntime().exec(new String[] {
        pathToGPG, "--yes", "--batch", "--delete-key", id.getFingerprint().replaceAll(" ", "")});
        
    // errors           
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);       
    errGobbler.start();                        

    // output
    SimpleLineProcessor simpleLineProcessor = new SimpleLineProcessor("Out: ");
    StreamLineGobbler inGobbler = new StreamLineGobbler(p.getInputStream(), simpleLineProcessor);
    inGobbler.start();

    int rep = p.waitFor();

    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());
    if(errorProcessor.hasText("failed")) throw new Exception(errorProcessor.getAllErrorMessage());

  }


  public static void removePublicAndPrivateKey(String pathToGPG, GnuPGKeyID id) throws Exception
  {
    Process p = Runtime.getRuntime().exec(new String[] {
        pathToGPG, "--no-greeting", "--yes", "--batch", "--delete-secret-and-public-key", id.getFingerprint().replaceAll(" ", "")});

    // errors
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();

    // output
    SimpleLineProcessor simpleLineProcessor = new SimpleLineProcessor("Out: ");
    StreamLineGobbler inGobbler = new StreamLineGobbler(p.getInputStream(), simpleLineProcessor);
    inGobbler.start();

    int rep = p.waitFor();
    try                                                                                    
    {                                        
      inGobbler.join(5000);                                                                                 
    } catch(Exception e) {}                                                                                                                   
                                                                                                     
    try     
    {
      errGobbler.join(5000);
    } catch(Exception e) {}     

    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());
    if(errorProcessor.hasText("failed")) throw new Exception(errorProcessor.getAllErrorMessage());

  }                                                                                                                                           
  
  /* WARNING: use an experimental feature of 1.4.0  
Unattended key generation
=========================
This feature allows unattended generation of keys controlled by a
parameter file.  To use this feature, you use --gen-key together with
--batch and feed the parameters either from stdin or from a file given
on the commandline.

The format of this file is as follows:
  o Text only, line length is limited to about 1000 chars.
  o You must use UTF-8 encoding to specify non-ascii characters.
  o Empty lines are ignored.
  o Leading and trailing spaces are ignored.
  o A hash sign as the first non white space character indicates a comment line.
  o Control statements are indicated by a leading percent sign, the
    arguments are separated by white space from the keyword.
  o Parameters are specified by a keyword, followed by a colon.  Arguments
    are separated by white space.
  o The first parameter must be "Key-Type", control statements
    may be placed anywhere.
  o Key generation takes place when either the end of the parameter file
    is reached, the next "Key-Type" parameter is encountered or at the
    control statement "%commit"
  o Control statements:
    %echo <text>
	Print <text>.
    %dry-run
	Suppress actual key generation (useful for syntax checking).
    %commit
	Perform the key generation.  An implicit commit is done
	at the next "Key-Type" parameter.
    %pubring <filename>
    %secring <filename>
	Do not write the key to the default or commandline given
	keyring but to <filename>.  This must be given before the first
	commit to take place, duplicate specification of the same filename
	is ignored, the last filename before a commit is used.
	The filename is used until a new filename is used (at commit points)
	and all keys are written to that file.	If a new filename is given,
	this file is created (and overwrites an existing one).
	Both control statements must be given.
   o The order of the parameters does not matter except for "Key-Type"
     which must be the first parameter.  The parameters are only for the
     generated keyblock and parameters from previous key generations are not
     used. Some syntactically checks may be performed.
     The currently defined parameters are:
     Key-Type: <algo-number>|<algo-string>
	Starts a new parameter block by giving the type of the
	primary key. The algorithm must be capable of signing.
	This is a required parameter.
     Key-Length: <length-in-bits>
	Length of the key in bits.  Default is 1024.
     Key-Usage: <usage-list>
        Space or comma delimited list of key usage, allowed values are
        "encrypt" and "sign".  This is used to generate the key flags.
        Please make sure that the algorithm is capable of this usage.
     Subkey-Type: <algo-number>|<algo-string>
	This generates a secondary key.  Currently only one subkey
	can be handled.
     Subkey-Length: <length-in-bits>
	Length of the subkey in bits.  Default is 1024.
     Subkey-Usage: <usage-list>
        Similar to Key-Usage.
     Passphrase: <string>
	If you want to specify a passphrase for the secret key,
	enter it here.	Default is not to use any passphrase.
     Name-Real: <string>
     Name-Comment: <string>
     Name-Email: <string>
	The 3 parts of a key. Remember to use UTF-8 here.
	If you don't give any of them, no user ID is created.
     Expire-Date: <iso-date>|(<number>[d|w|m|y])
	Set the expiration date for the key (and the subkey).  It
	may either be entered in ISO date format (2000-08-15) or as
	number of days, weeks, month or years. Without a letter days
	are assumed.
     Preferences: <string>
        Set the cipher, hash, and compression preference values for
	this key.  This expects the same type of string as "setpref"
	in the --edit menu.
     Revoker: <algo>:<fpr> [sensitive]
        Add a designated revoker to the generated key.  Algo is the
	public key algorithm of the designated revoker (i.e. RSA=1,
	DSA=17, etc.)  Fpr is the fingerprint of the designated
	revoker.  The optional "sensitive" flag marks the designated
	revoker as sensitive information.  Only v4 keys may be
	designated revokers.
     Handle: <string>
        This is an optional parameter only used with the status lines
        KEY_CREATED and KEY_NOT_CREATED.  STRING may be up to 100
        characters and should not contauin spaces.  It is useful for
        batch key generation to associate a key parameter block with a
        status line.


Here is an example:
$ cat >foo <<EOF
     %echo Generating a standard key
     Key-Type: DSA
     Key-Length: 1024
     Subkey-Type: ELG-E
     Subkey-Length: 1024
     Name-Real: Joe Tester
     Name-Comment: with stupid passphrase
     Name-Email: joe@foo.bar
     Expire-Date: 0
     Passphrase: abc
     %pubring foo.pub
     %secring foo.sec
     # Do a commit here, so that we can later print "done" :-)
     %commit
     %echo done
EOF
$ gpg --batch --gen-key foo
 [...]
$ gpg --no-default-keyring --secret-keyring ./foo.sec \
				  --keyring ./foo.pub --list-secret-keys
/home/wk/work/gnupg-stable/scratch/foo.sec
------------------------------------------
sec  1024D/915A878D 2000-03-09 Joe Tester (with stupid passphrase) <joe@foo.bar>
ssb  1024g/8F70E2C0 2000-03-09

  */    
  
  /** WARNING: use an experimental feature of 1.4.0
  */
  public static void generateNew_DSA_ElG_KeyPair(String pathToGPG,
     String nameReal, String nameComment, String nameEmail, String passphrase, String elgKeyLength, String expires, 
     ProgressModalDialog progress) throws Exception
  {
    Process p = Runtime.getRuntime().exec(new String[] {
        pathToGPG, "--batch", "--gen-key"});
  
    if(progress!=null)
      progress.setProcessToOptionalKill(p);

    // forget errors
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();                  

    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    StreamGobbler inGobbler = new StreamGobbler(p.getInputStream(), bos);
    inGobbler.start();

    // write batch arguments
    //p.getOutputStream().write("%echo Start".getBytes());
    p.getOutputStream().write(("Key-Type: DSA").getBytes());
    p.getOutputStream().write(("\r\nKey-Length: 1024").getBytes());  // DSA have fixed 1024
    p.getOutputStream().write( "\r\nSubkey-Type: ELG-E".getBytes());
    p.getOutputStream().write(("\r\nSubkey-Length: "+elgKeyLength).getBytes());   // Elg-e: 1024-4096

    p.getOutputStream().write(("\r\nName-Real: "   +nameReal).getBytes());                                                                             
    p.getOutputStream().write(("\r\nName-Comment: "+nameComment).getBytes());
    p.getOutputStream().write(("\r\nName-Email: "  +nameEmail).getBytes());

    p.getOutputStream().write(("\r\nExpire-Date: "+expires).getBytes());
    p.getOutputStream().write(("\r\nPassphrase: "+passphrase).getBytes());
//    p.getOutputStream().write("\r\n%commit".getBytes());
//    p.getOutputStream().write("\r\n%echo done #*�!?@;,!".getBytes());
                        
    // EOF                               
    p.getOutputStream().flush();
    p.getOutputStream().close();


    int rep = p.waitFor();
    try
    {
      inGobbler.join(5000);
    } catch(Exception e) {}

    try
    {
      errGobbler.join(5000);
    } catch(Exception e) {}        

    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());
    if(errorProcessor.hasText("invalid")) throw new Exception(errorProcessor.getAllErrorMessage());
    if(errorProcessor.hasText("missing")) throw new Exception(errorProcessor.getAllErrorMessage());
  }


  public static void sendPublicKey(String pathToGPG, GnuPGKeyID id, ProgressModalDialog progress) throws Exception
  {
    Process p = Runtime.getRuntime().exec(new String[] {

        pathToGPG,
         "--no-greeting",
        //"--yes", "--batch",
         "--send-keys",
         "--keyserver", "subkeys.pgp.net",
         id.getFingerprint().replaceAll(" ", "")});
  
    if(progress!=null)
      progress.setProcessToOptionalKill(p);

    // errors
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();

    // output
    SimpleLineProcessor simpleLineProcessor = new SimpleLineProcessor("Out: ");
    StreamLineGobbler inGobbler = new StreamLineGobbler(p.getInputStream(), simpleLineProcessor);
    inGobbler.start();

    // write key
    //p.getOutputStream().write(asciikey.getBytes());
    //p.getOutputStream().write("\r\n".getBytes());
    // EOF
    p.getOutputStream().flush();
    p.getOutputStream().close();

    int rep = p.waitFor();
    try
    {
      inGobbler.join(5000);
    } catch(Exception e) {}

    try
    {
      errGobbler.join(5000);
    } catch(Exception e) {}


    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());                
    if(errorProcessor.hasText("failed")) throw new Exception(errorProcessor.getAllErrorMessage());

  }
                      
  public static Vector<KeyIDFromSearchResult> searchKeysOnServer(String pathToGPG, String text, ProgressModalDialog progress) throws Exception
  {
    Process p = Runtime.getRuntime().exec(new String[] {

        pathToGPG, "--yes", 
        //"--batch",  
        "--no-greeting",
         "--keyserver", "hkp://subkeys.pgp.net",
         "--search-keys", text                                                                                   
    });
    
    if(progress!=null)
    {
      progress.setProcessToOptionalKill(p);
    }

    // errors
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();

    // output                     
    KeySearchResultProcessor keyProcessor = new KeySearchResultProcessor();
    StreamLineGobbler inGobbler = new StreamLineGobbler(p.getInputStream(), keyProcessor);
    inGobbler.start();

    // EOF
    //p.getOutputStream().flush();
    //p.getOutputStream().close();        


    int rep = p.waitFor();
    try
    {
      inGobbler.join(5000);
    } catch(Exception e) {}


    try
    {
      errGobbler.join(5000);
    } catch(Exception e) {}

    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());
    //if(errorProcessor.hasText("failed")) throw new Exception(errorProcessor.getAllErrorMessage());
    // failed: illegal byte sequence occurs often !...
    //  so we must let it pass
      
    return keyProcessor.getKeyIDs();
  }

  public static void importKeyFromServer(String pathToGPG, KeyIDFromSearchResult key, ProgressModalDialog progress) throws Exception
  { 
    Process p = Runtime.getRuntime().exec(new String[] {

        pathToGPG, "--yes", "--batch",
         "--keyserver", "hkp://subkeys.pgp.net",
         "--recv-keys", key.getKeyShortID()
    });
    
    if(progress!=null)
    {
      progress.setProcessToOptionalKill(p);
    }

    // errors
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();                                                                                               

    // output nothing todo, is internal processed
    //KeySearchResultProcessor keyProcessor = new KeySearchResultProcessor();
    StreamLineGobbler inGobbler = new StreamLineGobbler(p.getInputStream(), errorProcessor);
    inGobbler.start();

    // EOF
    //p.getOutputStream().flush();
    //p.getOutputStream().close();


    int rep = p.waitFor();
    try
    {
      inGobbler.join(5000);
    } catch(Exception e) {}


    try
    {
      errGobbler.join(5000);
    } catch(Exception e) {}

    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());
    //if(errorProcessor.hasText("failed")) throw new Exception(errorProcessor.getAllErrorMessage());
    
  }


  public static void refreshPublicKeysFromServer(String pathToGPG, ProgressModalDialog progress) throws Exception           
  {
      Process p = Runtime.getRuntime().exec(new String[] {
        pathToGPG, "--yes", "--batch", "--no-greeting",
        "--keyserver", "hkp://subkeys.pgp.net",
        "--refresh-keys"
      });

      if(progress!=null) progress.setProcessToOptionalKill(p);

    // errors
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();                                                                                               

    // output nothing todo, is internal processed
    StreamLineGobbler inGobbler = new StreamLineGobbler(p.getInputStream(), errorProcessor);
    inGobbler.start();

    // EOF
    //p.getOutputStream().flush();
    //p.getOutputStream().close();    

    int rep = p.waitFor();
    try
    {
      inGobbler.join(5000);
    } catch(Exception e) {}


    try
    {
      errGobbler.join(5000);
    } catch(Exception e) {}

    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());
    if(errorProcessor.hasText("failed")) throw new Exception(errorProcessor.getAllErrorMessage());
  }



  //
  //   not used yet ...
  //

  public static void symmetricEncryptFile(String pathToGPG, File src, File dest, char[] pass, boolean ascii) throws Exception
  {

    Process p = Runtime.getRuntime().exec(new String[] {
        pathToGPG, "-c"+(ascii?"a":""),
        "--no-greeting",
        //"--enable-progress-filter",
        "-o", dest.getAbsolutePath(),
        "--passphrase-fd", "0",            // give password in stdin
        src.getAbsolutePath()} );
                                                                                                          
    // errors    
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();

    // output             
    SimpleLineProcessor simpleLineProcessor = new SimpleLineProcessor("Out: ");
    StreamLineGobbler inGobbler = new StreamLineGobbler(p.getInputStream(), simpleLineProcessor);
    inGobbler.start();          

    // give password in stdin
    for(int i=0; i<pass.length; i++)
    {
      p.getOutputStream().write((byte) pass[i]);
      // erase password
      //pass[i] = (char)0;
    }
    p.getOutputStream().write((byte)'\n');
    p.getOutputStream().flush();  

    int rep = p.waitFor();

    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());
  }


  public static void encryptFile(String pathToGPG, File src, File dest, GnuPGKeyID keyID, boolean ascii) throws Exception
  {
    Process p = Runtime.getRuntime().exec(new String[]{
       pathToGPG, "-e"+(ascii?"a":""),
       "--enable-progress-filter",
       "-r",  "\""+keyID.getKeyID()+"\"",
       "-o", dest.getAbsolutePath(),
       src.getAbsolutePath()});
                

    // forget errors
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();

    SimpleLineProcessor simpleLineProcessor = new SimpleLineProcessor("Out: ");
    StreamLineGobbler inGobbler = new StreamLineGobbler(p.getInputStream(), simpleLineProcessor);
    inGobbler.start();

    int rep = p.waitFor();               

    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());
  }


  public static byte[] encryptBuffer(String pathToGPG, ByteArrayInputStream bin, char[] pass, boolean ascii) throws Exception
  {
    Process p = Runtime.getRuntime().exec(new String[]{
       pathToGPG, "-c"+(ascii?"a":""),
       "--quiet", "--no-greeting",
       //"--enable-progress-filter",
       "--passphrase-fd", "0"            // give password in stdin

    });                           


    // forget errors
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();

    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    StreamGobbler inGobbler = new StreamGobbler(p.getInputStream(), bos);
    inGobbler.start();

    // give password on stdin
    for(int i=0; i<pass.length; i++)
    {
      p.getOutputStream().write((byte) pass[i]);
      // erase password
      //pass[i] = (char)0;
    }
    p.getOutputStream().write((byte)'\n');
    p.getOutputStream().flush();

    // write message
    byte[] buf = new byte[256];
    int read =-1;
    while(( read=bin.read(buf))!=-1)
    {
       p.getOutputStream().write(buf,0,read);
    }

    // EOF
    p.getOutputStream().flush();
    p.getOutputStream().close();

    int rep = p.waitFor();
    try                    
    {
      inGobbler.join(5000);
    } catch(Exception e) {}

    try                       
    {
      errGobbler.join(5000);
    } catch(Exception e) {}      

    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());

    return bos.toByteArray();
  }                                   
       
       
                                     
  public static void encryptBuffer(String pathToGPG, InputStream bin, char[] pass, OutputStream bos, boolean ascii, ProgressModalDialog pd) throws Exception
  {
    Process p = Runtime.getRuntime().exec(new String[]{
       pathToGPG, "-c"+(ascii?"a":""),
       "--quiet", "--no-greeting",
       "--passphrase-fd", "0"            // give password in stdin
    });


    // forget errors
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();

    StreamGobbler inGobbler = new StreamGobbler(p.getInputStream(), bos);
    inGobbler.start();

    // give password on stdin
    for(int i=0; i<pass.length; i++)
    {
      p.getOutputStream().write((byte) pass[i]);
      // erase password
      //pass[i] = (char)0;
    }
    p.getOutputStream().write((byte)'\n');
    p.getOutputStream().flush();
    //System.out.println("wrote pass");

    // write message
    byte[] buf = new byte[256];
    int read =-1;
    while(( read=bin.read(buf))!=-1)
    {
       p.getOutputStream().write(buf,0,read);
       pd.incrementProgress(read);
       
       if(pd.wasCancelled())
       {
           p.destroy();
           //break;
           throw new Exception("Encryption Aborted");
       }
    }
    System.out.println("wrote mess");

    // EOF
    p.getOutputStream().flush();
    p.getOutputStream().close();

    //System.out.println("wait");
    //int rep = p.waitFor();
    //System.out.println("ok");
    try                    
    {
      inGobbler.join(5000);
    } catch(Exception e) {}

    try
    {
      errGobbler.join(5000);
    } catch(Exception e) {}      

    if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());

  }


  public static byte[] decryptBuffer(String pathToGPG, ByteArrayInputStream bin, char[] pass) throws Exception
  {
    Process p = Runtime.getRuntime().exec(new String[]{
       pathToGPG,
       "--enable-progress-filter", "--no-greeting",
       "--quiet",
       "-d",
       "--passphrase-fd", "0",            // give password in stdin
    });


    // forget errors
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();

    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    StreamGobbler inGobbler = new StreamGobbler(p.getInputStream(), bos);
    inGobbler.start();

    // give password on stdin
    for(int i=0; i<pass.length; i++)
    {
      p.getOutputStream().write((byte) pass[i]);
      // erase password
      //pass[i] = (char)0;
    }
    p.getOutputStream().write((byte)'\n');
    p.getOutputStream().flush();
    //System.out.println("wrote pass");

    // write message
    byte[] buf = new byte[256];
    int read =-1;
    while(( read=bin.read(buf))!=-1)
    {
       p.getOutputStream().write(buf,0,read);
    }
    //System.out.println("wrote mess");

    // EOF
    p.getOutputStream().flush();
    p.getOutputStream().close();

    //int rep = p.waitFor();
    //System.out.println("ok");
    try                    
    {
      inGobbler.join(5000);
    } catch(Exception e) {}

    try
    {
      errGobbler.join(5000);
    } catch(Exception e) {}      

    String err = errorProcessor.getAllErrorMessage();
    String err_ = err.toLowerCase();
    if(err.indexOf("bad key")>=0) throw new Exception(Language.translate("Bad key"));
    if(err.indexOf("failed")>=0) throw new Exception(err);
    if(err.indexOf("no valid")>=0) throw new Exception(err);

    return bos.toByteArray();
  }            


  /** give the info about the encrypted buffer
  */
  public static String infoBuffer(String pathToGPG, ByteArrayInputStream bin) throws Exception
  {
    Process p = Runtime.getRuntime().exec(new String[]
    {
       pathToGPG,
       "--decrypt",
       "--verbose",
       // "--list-packets",
       "--no-greeting",
       "--passphrase-fd", "0",            // give password in stdin
    });     


    // forget errors
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();

    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    StreamGobbler inGobbler = new StreamGobbler(p.getInputStream(), bos);
    inGobbler.start();

    // give password on stdin
/*    for(int i=0; i<pass.length; i++)
    {
      p.getOutputStream().write((byte) pass[i]);
      // erase password
      pass[i] = (char)0;
    }
 */
    //System.out.println("write password");
    p.getOutputStream().write((byte)'\n');
    p.getOutputStream().flush();

    //System.out.println("write mess pass");

    // write message
    byte[] buf = new byte[1024];
    int read =-1;
    while(( read=bin.read(buf))!=-1)
    {
       p.getOutputStream().write(buf,0,read);
    }
    //System.out.println("wrote mess");


    // EOF
    p.getOutputStream().flush();
    p.getOutputStream().close();

    //System.out.println("wait");
    //int rep = p.waitFor();
    //System.out.println("ok");
    try                    
    {
      inGobbler.join(5000);
    } catch(Exception e) {}

    try
    {
      errGobbler.join(5000);
    } catch(Exception e) {}      

    String err = errorProcessor.getAllErrorMessage();
    System.out.println("ERROR=\n"+err);
                                       
    //String err_ = err.toLowerCase();
    //if(err.indexOf("bad key") >=0) throw new Exception("Bad key");
    //if(err.indexOf("failed")  >=0) throw new Exception(err);
    //if(err.indexOf("no valid")>=0) throw new Exception(err);

    return new String(bos.toByteArray());
  }
       
     
  public static void decryptFile(String pathToGPG, File src, File dest, char[] pass) throws Exception
  {
    Process p = Runtime.getRuntime().exec(new String[] {
       pathToGPG,                       
       "--enable-progress-filter",
       "--quiet",  "--no-greeting",                
       "-o",dest.getAbsolutePath(),
       "--passphrase-fd", "0",            // give password in stdin  
       "-d",          
       src.getAbsolutePath()});

    System.out.println("Decrypt Started");

    // forget errors
    ErrorLineProcessor errorProcessor = new ErrorLineProcessor();
    StreamLineGobbler errGobbler = new StreamLineGobbler(p.getErrorStream(), errorProcessor);
    errGobbler.start();

    SimpleLineProcessor simpleLineProcessor = new SimpleLineProcessor("Out: ");
    StreamLineGobbler inGobbler = new StreamLineGobbler(p.getInputStream(), simpleLineProcessor);
    inGobbler.start();

    // give password in stdin
    p.getOutputStream().write((new String(pass)+"\n").getBytes());
    p.getOutputStream().flush();
                            

    System.out.println("Wait");
    int rep = p.waitFor();
    System.out.println("OK");
    
    String err = errorProcessor.getAllErrorMessage();            
    String err_ = err.toLowerCase();                      
    if(err.indexOf("bad key")>=0) throw new Exception(Language.translate("Bad key"));
    if(err.indexOf("failed")>=0) throw new Exception(err);
    if(err.indexOf("no valid")>=0) throw new Exception(err);

    //if(errorProcessor.hasError()) throw new Exception(errorProcessor.getAllErrorMessage());
  }                              

} // GnuPGCommands

