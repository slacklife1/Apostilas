package SnowMailClient.GnuPG;


import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;

import snow.utils.gui.*;
import snow.concurrent.*;
import SnowMailClient.Language.Language;
import snow.utils.storage.*;
import SnowMailClient.utils.*;
import SnowMailClient.GnuPG.Main.GnuPGCommands;
import SnowMailClient.GnuPG.model.*;
import SnowMailClient.GnuPG.Views.GPGPasswordDialog;
import SnowMailClient.SnowMailClientApp;


/** Establish a link with an external GnuPG application and allow encrypt / decrypt buffers
    caches the key id's and the passwords
    get the link from the main app

  Usage:
     0) Set the gpg path (auto in constructor, read from props)
     1) Get a secret or public key ID
     2) Encrypt, decrypt, get keys, ...

*/
public final class GnuPGLink
{                   
  // Parameters

  private String pathToGPG = "c:/app/gnupg/gpg.exe";
  private String gpgVersion = "";

  // Read from gpg at each startup or gpg path change
  TreeSet<GnuPGKeyID> publicKeyIDsModel = new TreeSet<GnuPGKeyID>();  // sorted keys
  TreeSet<GnuPGKeyID> secretKeyIDsModel = new TreeSet<GnuPGKeyID>();  // sorted keys

  // cache
  final private Hashtable<String, byte[]> keyPasswords = new Hashtable<String, byte[]>();

  private boolean isGPG_available = false;


  public GnuPGLink()  
  {                
  } // Constructor
    
    
  public Vector<Object> getVectorRepresentation()
  {
    Vector<Object> rep = new Vector<Object>();
    rep.addElement(1);   //0: version
    rep.addElement(pathToGPG); // 1
    rep.addElement(gpgVersion); //2

    Vector<Object> keyPasswordsKeys = new Vector<Object>();
    Vector<Object> keyPasswordsValues = new Vector<Object>();

    for(String id: keyPasswords.keySet())
    {
       keyPasswordsKeys.add(id);
       keyPasswordsValues.addElement(keyPasswords.get(id));
    }

    rep.add(keyPasswordsKeys);    // 3
    rep.add(keyPasswordsValues);  // 4

    return rep;
  }
  
  public void createFromVectorRepresentation(Vector<Object> v)
  {
    int version = (Integer) v.elementAt(0);
    if(version==1)
    {  
       pathToGPG = (String) v.elementAt(1);
       gpgVersion = (String) v.elementAt(2);
       Vector<String> ke = (Vector<String>) v.elementAt(3);
       Vector<byte[]> va = (Vector<byte[]>) v.elementAt(4);
       keyPasswords.clear();
       for(int i=0; i<ke.size(); i++)
       {
         keyPasswords.put(ke.elementAt(i), va.elementAt(i));
       }

       // read actual public and private keys from GPG !
       try
       {
          setGPGPath(pathToGPG);
       } catch(Exception ignored) { System.out.println("No GPG Link");}
    }
    else                                                   
    {
      throw new RuntimeException("Bad version "+version);
    }
  }
  

  public String getGPGVersionString() { return this.gpgVersion; }


  /** true if the path is valid, and keys successfully read.
  */
  public boolean isGPG_available() { return isGPG_available; }
  
  public String getPathToGPG() { return this.pathToGPG; }

  /** set the path and read all the private/public key IDs
  */      
  public void setGPGPath(String path) throws Exception
  {
    pathToGPG = path;
                       
    //properties.setProperty("gpgpath", path);      
    
    gpgVersion = GnuPGCommands.readGPGVersion(path);                                                               
    //System.out.println("GPG Version is "+gpgVersion);
    //if(gpgVersion.compareTo("1.4")<0) throw new Exception("Bad GPG version "+gpgVersion);
    
    publicKeyIDsModel.clear();
    publicKeyIDsModel.addAll( GnuPGCommands.readPublicKeyIDs(path) );

    secretKeyIDsModel.clear();
    secretKeyIDsModel.addAll( GnuPGCommands.readSecretKeyIDs(path) );

    isGPG_available = true;

  }   
  
  public TreeSet getAllPublicKeyIDs() { return publicKeyIDsModel; }
  public TreeSet getAllSecretKeyIDs() { return secretKeyIDsModel; }
  
  public GnuPGKeyID[] getPublicKeyIDForAddress(String mail)
  {
    Vector<GnuPGKeyID> rep = new Vector<GnuPGKeyID>();
    for(GnuPGKeyID k: publicKeyIDsModel)
    {
      for(UIDRecord uid: k.getUIDs())
      {
        if(uid.getMail().compareToIgnoreCase(mail)==0) rep.addElement(k);
      }
    }
    return rep.toArray(new GnuPGKeyID[rep.size()]);
  }



  public GnuPGKeyID[] getSecretKeyIDForAddress(String mail)
  {    
    Vector<GnuPGKeyID> rep = new Vector<GnuPGKeyID>();
    for(GnuPGKeyID k: secretKeyIDsModel)
    {
      for(UIDRecord uid: k.getUIDs())
      {
         if(uid.getMail().compareToIgnoreCase(mail)==0) rep.addElement(k);
      }
    }
    return rep.toArray(new GnuPGKeyID[rep.size()]);
  } 
  
  public boolean hasSecretKeyAssociated(GnuPGKeyID kid)
  {
    for(GnuPGKeyID k: secretKeyIDsModel)
    {
      if(k.getFingerprint().compareToIgnoreCase(kid.getFingerprint())==0) return true;
    }
    return false;
  }

  /** null if not found
  */
  public byte[] getPasswordForKey(GnuPGKeyID kid)
  {
    return this.keyPasswords.get(kid.getKeyID());
  }

  public void setPasswordForKey(GnuPGKeyID kid, byte[] pass)
  {
    this.keyPasswords.put(kid.getKeyID(), pass);
  }

  /** @return null if cancelled
  */
  public byte[] getPasswordForKeyAskIfNotFoundOrNotValid(GnuPGKeyID kid, boolean store, JFrame parent)
  {
    byte[] pass = this.keyPasswords.get(kid.getKeyID());

    if(pass!=null)
    {
      // verify
      try
      {
        if(GnuPGCommands.verifySecretKeyPassword(pathToGPG, kid, pass))
        {
          // password ok !
          return pass;
        }
      } catch(Exception ignored){}
    }

    // no password or bad password

    GPGPasswordDialog pd = new GPGPasswordDialog(parent, this, kid, Language.translate("Enter the password for the GPG key\n%", kid.getKeyID()));
    if(pd.isPasswordValid())
    {
      if(store)
      {
        this.setPasswordForKey(kid, pd.getPassword());
      }
      return pd.getPassword();
    }

    return null;
  }

  /** shows a dialog that asks for the gpg path
  */
  public void askGPGPath(JFrame dialogParent)
  {
     final JDialog dialog = new JDialog(dialogParent, Language.translate("GnuPG Location Selection"), true);
     //final String[] rep = new String[]{null};
     final FileField gpgPathTF = new FileField(pathToGPG, false, Language.translate("Path to gpg.exe")+": ", false);

     dialog.getContentPane().setLayout(new BorderLayout());

     JPanel inputPanel = new JPanel();
     inputPanel.setBorder( BorderFactory.createBevelBorder(BevelBorder.LOWERED));
     inputPanel.add(gpgPathTF);

     dialog.getContentPane().add(inputPanel, BorderLayout.CENTER);


     JPanel labelP = new JPanel(new BorderLayout());
     JTextArea explainTA = new JTextArea( Language.translate(
        "\nPlease give the location of the application gpg.exe (Gnu Privacy Guard)."
      + "\nYou must use at least version 1.4 or later."
      + "\nIf you don't find this program, you have to install first GnuPG"
      + "\non your computer. Visit the homepage at www.gnupg.org.") );

     explainTA.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
     explainTA.setBackground(dialog.getContentPane().getBackground());
     explainTA.setForeground(dialog.getContentPane().getForeground());

     labelP.add(explainTA, BorderLayout.CENTER);
     explainTA.setEditable(false);
     dialog.getContentPane().add(labelP, BorderLayout.NORTH);

     CloseControlPanel ccp = new CloseControlPanel(dialog, true, true, Language.translate("Ok"));
     dialog.getContentPane().add(ccp, BorderLayout.SOUTH);

                           
     gpgPathTF.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e2)
       {
         dialog.setVisible(false);
       }
     });


     dialog.pack();
     SnowMailClientApp.centerComponentOnMainFrame(dialog);
     dialog.setVisible(true);         

     if(ccp.getWasCancelled()) return;

     try
     {
        setGPGPath(gpgPathTF.getPath().getAbsolutePath());
     } catch(Exception e){ e.printStackTrace(); }
  }
  
  
  // Functions interface
  //
  
  /** sign the content with the given key.
  */
  public String sign(String content, GnuPGKeyID kid, byte[] pass, Interrupter interrupter) throws Exception
  {                                                                                      
     ByteArrayInputStream bin = new ByteArrayInputStream(content.getBytes());
     byte[] rep = GnuPGCommands.signBuffer(this.pathToGPG, bin, kid, pass, interrupter );
     return new String(rep);
  } 

  public byte[] sign(ByteArrayInputStream bin, GnuPGKeyID kid, byte[] pass, Interrupter interrupter) throws Exception
  {
     byte[] rep = GnuPGCommands.signBuffer(this.pathToGPG, bin, kid, pass, interrupter );
     return rep;
  }

  public String getPublicKeyContent(GnuPGKeyID kid) throws Exception
  {
     return GnuPGCommands.getPublicKey(this.pathToGPG, kid);
  }

  public String getSecretKeyContent(GnuPGKeyID kid) throws Exception
  {
     return GnuPGCommands.getSecretKey(this.pathToGPG, kid);
  }

  public void addKey(String asciiKey) throws Exception
  {
     GnuPGCommands.addKey(this.pathToGPG, asciiKey);
  }

  public void removeKey(GnuPGKeyID kid) throws Exception
  {
     if(kid.isSecret())
     {
        // remove both...
        GnuPGCommands.removePublicAndPrivateKey(pathToGPG, kid);
     }               
     else
     {
        GnuPGCommands.removePublicKey(pathToGPG, kid);
     }
  }

  public void removePublicAndPrivateKey(GnuPGKeyID kid) throws Exception
  {
    GnuPGCommands.removePublicAndPrivateKey(pathToGPG, kid);
  }

} // GnuPGLink
