package SnowMailClient;

import SnowMailClient.view.folders.*;               
import SnowMailClient.view.*;                                                         
import SnowMailClient.view.html.*;
import SnowMailClient.view.actions.*;
import SnowMailClient.model.AddressBook;
import SnowMailClient.model.folders.*;
import SnowMailClient.model.accounts.*;          
import SnowMailClient.model.StyledTextDocument;
import SnowMailClient.MailEngine.MyX509TrustManager;
import SnowMailClient.MailEngine.transfer.*;
import SnowMailClient.crypto.*;                      
import SnowMailClient.utils.storage.Backup;
import SnowMailClient.Synthesizer.SynthesizerDemo;
import SnowMailClient.Language.Language;
import SnowMailClient.Language.Editor.TranslationEditor;
import KhumPanGame.MoveApp;
import SnowMailClient.SpamFilter.*;
import snow.FileEncryptor.*;
import SnowMailClient.GnuPG.GnuPGLink;
import SnowMailClient.GnuPG.Views.KeysViewer;
import snow.lookandfeel.*;
import snow.utils.storage.*;
import snow.utils.gui.*;  
import snow.crypto.*; 
             
import java.awt.*;    
import java.awt.image.*;
import java.awt.event.*;    
import java.awt.datatransfer.*;  
import javax.swing.*;
import javax.swing.tree.*;     
import javax.swing.text.*;
import javax.swing.border.*;
import javax.net.ssl.*;
import javax.crypto.SecretKey;
import java.security.cert.*;
import java.security.*;
import javax.swing.plaf.metal.*;

import java.util.*;
import java.text.*;
import java.io.*;
import java.net.*;
import java.beans.*;

                                         
/**  Todo:
   1) correct address mamagment (add/remove, spam/...)
   2) update spam stats...
*/
public final class SnowMailClientApp extends JFrame
{
  public static boolean debug = false;  // not final, maybe set in the command line


  // models for data storage
  private final AppProperties properties    = new AppProperties();
  private StorageTreeModel storageTreeModel = null;
  private final MailAccounts mailAccounts   = new MailAccounts();
  private final AddressBook addressBook     = new AddressBook(false);
  private final AddressBook spamBook        = new AddressBook(true);
  private final WordStatistic wordStatistic = new WordStatistic();
  private final GnuPGLink gnuPGLink         = new GnuPGLink();

  final private Backup backup = new Backup();

  // views
  private FoldersView foldersView = null;
  private FolderView folderView = null;
  private final MailView mailView;
  private final JToolBar toolbar = new JToolBar("SnowMail Toolbar");
  private final SearchTreePanel searchTreePanel;

  public final Vector<JComponent> advancedComponents = new Vector<JComponent>();
  public final void addAdvancedComponent(final JComponent comp)
  {
    advancedComponents.add(comp);
    comp.setVisible(this.advancedMode);
  }


  private static File snowMailRoot = null;

  private final JSplitPane splitPaneHorizontal,
     splitPaneVerticalLeft2, splitPaneVerticalRight;

  private static final String TITLE      = "SnowMail";
  private static final String VERSION    = "2.0";
  private static final String SUBVERSION = "08";

  /** @deprecated console ### maybe not is useful for stats */
  private final StyledTextDocument globalConsole = new StyledTextDocument();
  private JTextPane  consolePane;
  private JScrollPane consoleScroll;

  private static SnowMailClientApp ref;
  private JCheckBoxMenuItem[] metalThemesMenuItems = null;

  private boolean advancedMode = false;


  public SnowMailClientApp()
  {
    super();

    // not "visible", but exist => see the icon and application in windows
    setLocation(0,0);
    setSize(0,0);
    setTitle(TITLE+" "+VERSION);


    // title is set at the end
    this.setIconImage(SnowMailClientApp.loadImageIcon("pics/snowmailicon.PNG").getImage());

    ref = this;

    setVisible(true);

    ProgressModalDialog startupProgress = new ProgressModalDialog(this, Language.translate("Starting of ") + TITLE, false);
    startupProgress.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);  // if the user closes! ### NOT WORKING !!!
    startupProgress.setShowCancel(false);
    startupProgress.setProgressBounds(100);
    startupProgress.setLocationRelativeTo(null);
    startupProgress.start();

    // root folder must exist
    checkRootDir();

    startupProgress.setProgressValue(10, Language.translate("Check SSL certificates")+"...");
    initializeSSLCertificateInfo();

    // keys
    startupProgress.setProgressValue(15, Language.translate("Loading keys")+"...");
    try
    {   
      SecretKeyManager skm = SecretKeyManager.getInstance();
                       
      File ksFile = new File(snowMailRoot, "userkeystore");
      
      // exists only if the user setted a secret pass
      if(ksFile.exists())
      {    
         try
         {
            Vector<Object> vec = FileCipherManager.getInstance().decipherVectorFromFile_ASK_KEY_IF_NEEDED(
              ksFile, startupProgress,
              Language.translate("Snowmail passphrase"),
              Language.translate("Enter your secret passphrase to start SnowMail") );
            skm.createFromVectorRepresentation( vec );
         }               
         catch(BadPasswordException e)
         {
            System.exit(0);   // Fatal...
         }
      }
      else
      {
        // create it !
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
    


    // properties   
    startupProgress.setProgressValue(20, Language.translate("Loading properties")+"...");
    try
    {
      File propFile = new File(snowMailRoot, "properties");
      if(propFile.exists())
      {                         
        properties.createFromVectorRepresentation( this.readVectorFromFile( propFile, startupProgress ));
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }

    this.advancedMode = properties.getBoolean("advancedMode", true);

    // Backup
    //
    try
    {
      File bcFile = new File(snowMailRoot, "backup");
      if(bcFile.exists())
      {
        backup.createFromVectorRepresentation( readVectorFromFile( bcFile, startupProgress ));
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    } 
    

    // models
    startupProgress.setProgressValue(30, Language.translate("Reading system mail folders")+"...");
    try
    {
      File mailStorageRoot = new File(snowMailRoot, "MailStorage");
      storageTreeModel = new StorageTreeModel(mailStorageRoot);
      foldersView = new FoldersView(storageTreeModel, this);
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }               
      
    // accounts
    startupProgress.setProgressValue(60, Language.translate("Reading mail accounts")+"...");
    try
    {
      File accountsFile = new File(snowMailRoot, "accounts");
      if(accountsFile.exists())
      {
        mailAccounts.createFromVectorRepresentation( readVectorFromFile( accountsFile, startupProgress ));
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
       
    // address book
    startupProgress.setProgressValue(70, Language.translate("Reading address book")+"...");
    try
    {
      File adbFile = new File(snowMailRoot, "addressBook");
      if(adbFile.exists())
      {
        addressBook.createFromVectorRepresentation( readVectorFromFile( adbFile, startupProgress ));
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }

    // spam book
    startupProgress.setProgressValue(80, Language.translate("Reading spam book")+"...");
    try
    {
      File spamFile = new File(snowMailRoot, "spamBook");
      if(spamFile.exists())
      {
        spamBook.createFromVectorRepresentation( readVectorFromFile( spamFile, startupProgress ));
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }

    // statistics
    //
    startupProgress.setProgressValue(85, Language.translate("Reading spam statistics")+"...");
    try  
    {
      File statFile = new File(snowMailRoot, "wordStatistic");
      if(statFile.exists())
      {
        this.wordStatistic.createFromVectorRepresentation(
           readVectorFromFile( statFile, startupProgress ));
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
    catch(Error e)
    {
      e.printStackTrace();
    }
    

    // GnuPG
    //
    startupProgress.setProgressValue(90, Language.translate("Reading GnuPG keys")+"...");
    File file = new File(snowMailRoot, "gnuPGLink");
    try
    {
       if(file.exists())
       {
         this.gnuPGLink.createFromVectorRepresentation(
             readVectorFromFile( file, startupProgress ));
       }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
    catch(Error e)
    {
      e.printStackTrace();
    }
    


    startupProgress.setProgressValue(95, Language.translate("Building views")+"...");

    mailView = new MailView(mailAccounts);
    folderView = new FolderView(properties, foldersView, mailView);

    // gui
    getContentPane().setLayout(new BorderLayout(0,0));
    getContentPane().add(toolbar, BorderLayout.NORTH);
    toolbar.setOpaque(false);

    // splits
    //
    SnowBackgroundPanel consolePanel = new SnowBackgroundPanel(new BorderLayout());
    this.advancedComponents.add(consolePanel);
    consolePane = new JTextPane(globalConsole.doc);
    consolePane.setOpaque(false);
    consoleScroll = new JScrollPane(consolePane);
    consoleScroll.setOpaque(false);
    consoleScroll.getViewport().setOpaque(false);
    consolePanel.add(consoleScroll, BorderLayout.CENTER);
                  
  /*  splitPaneVerticalLeft1 = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
      searchTreePanel = new SearchTreePanel(),
      consolePanel);
    splitPaneVerticalLeft1.setOneTouchExpandable(true);*/

    splitPaneVerticalLeft2 = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
      foldersView,
      searchTreePanel = new SearchTreePanel());
    splitPaneVerticalLeft2.setOneTouchExpandable(true);


    splitPaneVerticalRight = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
      folderView,
      mailView);
    splitPaneVerticalRight.setOneTouchExpandable(true);
                                                                                                           
    splitPaneHorizontal = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
      splitPaneVerticalLeft2,
      splitPaneVerticalRight);
    splitPaneHorizontal.setOneTouchExpandable(true);

    getContentPane().add(splitPaneHorizontal, BorderLayout.CENTER);

    splitPaneHorizontal.setBorder(null);   
   // splitPaneVerticalLeft1.setBorder(null);
    splitPaneVerticalLeft2.setBorder(null);
    splitPaneVerticalRight.setBorder(null);
    //new EmptyBorder(fontSize, fontSize, fontSize, fontSize)

    // view installations



    setMenu();

    // ui sizes from props
    Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
    properties.setComponentSizeFromINIFile(this, "SnowMailClientApp",
      (int)(screen.getWidth()-100), (int)(screen.getHeight()-100), 50,50);
    /*splitPaneVerticalLeft1.setDividerLocation(
      properties.getInteger("splitPaneVerticalLeft", (int)(screen.getHeight()/2)));*/

    splitPaneVerticalLeft2.setDividerLocation(
      properties.getInteger("splitPaneVerticalLeft2", (int)(screen.getHeight()/2)));

    splitPaneVerticalRight.setDividerLocation(
      properties.getInteger("splitPaneVerticalRight", (int)(screen.getHeight()/3)));

    splitPaneHorizontal.setDividerLocation(
      properties.getInteger("splitPaneHorizontal", (int)(screen.getWidth()/4)));
                                         
    this.mailView.hideAttachmentSplit();                                     
                                         
    addWindowListener(new WindowAdapter()
    {
        @Override public void windowClosed(WindowEvent e)
        {
           terminateApplication();
        }
        //  Invoked when a window has been closed.
        @Override public void windowClosing(WindowEvent e)                                       
        {
           terminateApplication();
        }
        //  Invoked when a window is in the process of being closed.
    });
    
    consolePane.addPropertyChangeListener(
     new PropertyChangeListener()
     {                 
        public void propertyChange(PropertyChangeEvent e)
        {
            String name = e.getPropertyName();
            if (name.equals("UI"))
             {
               SwingUtilities.invokeLater( new Runnable()
                {
                   public void run()
                   {
                     updateSpecialUI();
                   }
                });
             }      
        /*    else
            {
              System.out.println(">"+name);
            }*/
        }                         
     });
      
      
    // set snowmail title and made app visible !
    //
    String firstSendAccount = Language.translate("No mail account for sending set");
    MailAccount ma0 = this.mailAccounts.getSendMailAccount();
    if(ma0!=null) firstSendAccount = ma0.getAddress();
    this.setTitle(TITLE+" "+VERSION+" ["+firstSendAccount+"]");

    for(JComponent comp : this.advancedComponents)
    {
      comp.setVisible(advancedMode);
    }

    // MAIN VISIBLE !
    setVisible(true);
    startupProgress.setVisible(false);

    DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM, Language.getInstance().getLocale());
    DateFormat df2 = DateFormat.getTimeInstance(DateFormat.SHORT, Language.getInstance().getLocale());

    this.getGlobalConsole().appendLine(Language.translate("Started the")+" "
       +df.format(new Date())+Language.translate(" at ")+df2.format(new Date())+"\n");
       
    // set global passphrase, if necessary
    //FileCipherManager.getInstance();
    if(!SecretKeyManager.getInstance().isUserKeySet())               
    {
          //SecretKeyManager.getInstance().
          PassphraseSettingDialog psd = new PassphraseSettingDialog(SnowMailClientApp.this,
              Language.translate("Snowmail Passphrase setting"),
              true,
              Language.translate("Please enter and confirm the snowMail global passphrase.\nThis passphrase will protect all your stored data."));

          if(!psd.wasCancelled())
          {                                                                                                     
            try
            {
              SecretKeyManager.getInstance().setUserKeyForEncryption( psd.getKey() );
            }
            catch(Exception ee) { System.exit(-1); }
          }
          else
          {
            JOptionPane.showMessageDialog(this,
               Language.translate("SnowMail require a global passphrase"),
               Language.translate("Error"), JOptionPane.ERROR_MESSAGE);
            System.exit(-1);
          }
    }

   }
   
   public void makeSearchTreeVisible()
   {
     splitPaneVerticalLeft2.setDividerLocation(0.6);
   }


   private void updateSpecialUI()
   {                    
      //fontSize = UIManager.getFont("Label.font").getSize();
      // the textpane don't update correctly his opacity itself !!
      consolePane.setOpaque(false);
      consoleScroll.setOpaque(false);
      consoleScroll.getViewport().setOpaque(false);
                      
    splitPaneHorizontal.setBorder(null);   
    //splitPaneVerticalLeft1.setBorder(null);
    splitPaneVerticalLeft2.setBorder(null);
    splitPaneVerticalRight.setBorder(null);
                      

      //System.out.println("Snow client app UI updated !!");
   }
   
   /** Only after the constructor has been called ! */
   public static SnowMailClientApp getInstance() { return ref; }

   public FoldersView getFoldersView()          { return foldersView;      }
   public FolderView getFolderView()            { return folderView;       }
   public MailView getMailView()                { return mailView;         }
   public AppProperties getProperties()         { return properties;       }
   public File getSnowMailRoot()                { return snowMailRoot;     }
   public Backup getBackup()                    { return backup;           }
   public StorageTreeModel getFoldersModel()    { return storageTreeModel; }
   public AddressBook getAddressBook()          { return addressBook;      }
   public AddressBook getSpamBook()             { return spamBook;         }
   /** @ deprecated */
   public StyledTextDocument getGlobalConsole() { return globalConsole;    }
   public SearchTreePanel getSearchPanel()  { return this.searchTreePanel; }
   public WordStatistic getWordStatistic()      { return wordStatistic;    }
   public MailAccounts getAccounts()            { return mailAccounts;     }
   public GnuPGLink getGnuPGLink()              { return gnuPGLink;        }
          
   private void setMenu()
   {
      // File
      //
      JMenuBar menuBar = new JMenuBar();      

      this.setJMenuBar(menuBar);
      JMenu fileMenu = new JMenu(Language.translate("File"));
      getJMenuBar().add(fileMenu);

      final JMenuItem modeItem = new JMenuItem( (advancedMode?Language.translate("Change to simple mode"):Language.translate("Change to advanced mode")) );
      //passItem.setIcon(SnowMailClientApp.loadImageIcon("pics/key.PNG"));
      fileMenu.add(modeItem);
      fileMenu.addSeparator();
      modeItem.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          advancedMode = !advancedMode;
          modeItem.setText((advancedMode?Language.translate("Change to simple mode"):Language.translate("Change to advanced mode")));
          for(JComponent comp : advancedComponents)
          {
            comp.setVisible(advancedMode);
          }
              
        }
      });



      JMenuItem saveItem = new JMenuItem(Language.translate("Save all opened folders"));
      saveItem.setIcon(SnowMailClientApp.loadImageIcon("pics/save.PNG"));
      saveItem.setAccelerator(KeyStroke.getKeyStroke( KeyEvent.VK_S, KeyEvent.CTRL_MASK ) );
      fileMenu.add(saveItem);
      saveItem.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          Thread t = new Thread(){
            public void run()
            {
              setCursor(Cursor.WAIT_CURSOR);
              saveAllMails(false);  // ATTENTION: if true, the view must "reload"
              setCursor(Cursor.DEFAULT_CURSOR);
            }};
          t.setPriority(Thread.NORM_PRIORITY-1);
          t.start();
        }
      });


      JMenuItem passItem = new JMenuItem(Language.translate("Set storage passphrase"));
      passItem.setIcon(SnowMailClientApp.loadImageIcon("pics/key.PNG"));
      fileMenu.addSeparator();
      fileMenu.add(passItem);
      passItem.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        { 
          // ask for the old password
          SecretKey sk = SecretKeyManager.getInstance().getUserKeyForEncryption();
          if(sk!=null)
          {                                    
            SecretKeyID skid = SecretKeyUtilities.computeSignature(sk);
            PassphraseDialog pd = new PassphraseDialog(SnowMailClientApp.this, 
                Language.translate("Snowmail passphrase"), true, skid, 
                Language.translate("Enter the old passphrase"));
                                                    
            if(!pd.matchesID())
            {
              return;
            }
          }

          //2:
          PassphraseSettingDialog psd = new PassphraseSettingDialog(SnowMailClientApp.this, 
              Language.translate("Snowmail Passphrase setting"), 
              true, 
              Language.translate("Please enter and confirm the new SnowMail passphrase"));
          if(!psd.wasCancelled())
          {  
            try
            {
              SecretKeyManager.getInstance().setUserKeyForEncryption( psd.getKey() );
            }
            catch(Exception ee) {}
          }

        }
      });


      JMenuItem backupNowItem = new JMenuItem(Language.translate("Do a backup now"));
      this.addAdvancedComponent(backupNowItem);
      backupNowItem.setIcon(SnowMailClientApp.loadImageIcon("pics/zip.PNG"));
      fileMenu.addSeparator();
      fileMenu.add(backupNowItem);
      backupNowItem.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          Thread t = new Thread(){
            public void run() {
              backup.doBackupNow();
            }};
          t.setPriority(Thread.NORM_PRIORITY-1);
          t.start();
        }
      });
         
      JMenuItem backupItem = new JMenuItem(new BackupConfigurationAction());
      fileMenu.add(backupItem);  
      
      JMenuItem quitItem = new JMenuItem(Language.translate("Quit"));
      quitItem.setIcon(SnowMailClientApp.loadImageIcon("pics/cancel.PNG"));
      quitItem.setAccelerator( KeyStroke.getKeyStroke( KeyEvent.VK_Q, KeyEvent.CTRL_MASK ) );
      fileMenu.addSeparator();
      fileMenu.add(quitItem);                               
      quitItem.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e) 
        {
          terminateApplication();
        }
      });

      // Mail and accounts
      //

      JMenu mailMenu = new JMenu(Language.translate("Mail"));
      getJMenuBar().add(mailMenu);   

/*      ReceiveAction receiveAction = new ReceiveAction(
         this, this.mailAccounts,
         storageTreeModel.getInboxFolder(),
         storageTreeModel.getOutboxFolder()); */

      MailTransferAction receiveAction = new MailTransferAction( MailTransferModel.TransferType.Receive );
      MailTransferAction sendAction2 = new MailTransferAction( MailTransferModel.TransferType.Send );
      MailTransferAction sendAndReceiveAction = new MailTransferAction( MailTransferModel.TransferType.SendAndReceive );

/*
      SendAction sendAction = new SendAction(
         this, this.mailAccounts,
         storageTreeModel.getSentFolder(),
         storageTreeModel.getOutboxFolder(),
         this.folderView);    */
                              
      PreviewAllAction previewAllAction = new PreviewAllAction();

      mailMenu.add(receiveAction);
      mailMenu.add(sendAction2);
      mailMenu.add(sendAndReceiveAction);
      //mailMenu.add(new SendAndReceiveAction( sendAction, rac));

      mailMenu.addSeparator();
      CreateNewMail createNewMailAction = new CreateNewMail(mailAccounts, storageTreeModel.getComposeFolder());
      mailMenu.add(createNewMailAction);

      ReplyAction replyAction = new ReplyAction(folderView, mailAccounts, storageTreeModel.getComposeFolder(), false);
      mailMenu.add(replyAction);

      ReplyAction replyAllAction = new ReplyAction(folderView, mailAccounts, storageTreeModel.getComposeFolder(), true);
      JMenuItem replyAllMI = new JMenuItem(replyAllAction);
      mailMenu.add(replyAllMI);
      this.advancedComponents.add(replyAllMI);

      ForwardAction forwardAction = new ForwardAction(folderView, mailAccounts, storageTreeModel.getComposeFolder());
      mailMenu.add(forwardAction);

      mailMenu.addSeparator();     
      JMenuItem miCopyClip = new JMenuItem(new CopyMessagesToClipboardAsText(folderView));
      mailMenu.add(miCopyClip);
      this.advancedComponents.add(miCopyClip);
      mailMenu.add(new DeleteMailAction(folderView, storageTreeModel.getDeletedFolder()));


      JSeparator sep = new JSeparator();
      mailMenu.add(sep);
      this.addAdvancedComponent(sep);

      JMenuItem sma = new JMenuItem(new SaveMailAction(folderView));
      mailMenu.add(sma);
      this.addAdvancedComponent(sma);

      JMenuItem ime = new JMenuItem(new ImportMailMessage(folderView));
      mailMenu.add(ime);
      this.addAdvancedComponent(ime);

      toolbar.add(createToolbarButton(createNewMailAction));
      toolbar.add(createToolbarButton(replyAction));

      toolbar.addSeparator();
      //toolbar.add(createToolbarButton(receiveAction));
      toolbar.add(createToolbarButton(receiveAction));

                                                                              
      JComponent previewButton = createToolbarButton(previewAllAction);
      this.addAdvancedComponent(previewButton);
      toolbar.add(previewButton);
      
      toolbar.add(createToolbarButton(sendAction2));

      toolbar.addSeparator();
      EditAddressBookAction addressAction = new EditAddressBookAction(this, addressBook, properties);
      toolbar.add(createToolbarButton(addressAction));

      toolbar.addSeparator();
      EditAccountsAction accountsAction = new EditAccountsAction(this, mailAccounts, properties);
      toolbar.add(createToolbarButton(accountsAction));

      mailMenu.addSeparator();
      mailMenu.add(accountsAction);
      mailMenu.add(addressAction);

      
      // GnuPG
      //   
                         
      JMenu cryptoMenu = new JSenseMenu(Language.translate("Crypto"));
      getJMenuBar().add(cryptoMenu);

      JMenu gpgMenu = new JSenseMenu(Language.translate("GnuPG"));
      cryptoMenu.add(gpgMenu);

      JMenuItem configureGnuPG = new JMenuItem(Language.translate("Configure GnuPG"));
      gpgMenu.add(configureGnuPG);
      configureGnuPG.addActionListener(new ActionListener()
      {               
        public void actionPerformed(ActionEvent e)
        {
           gnuPGLink.askGPGPath(SnowMailClientApp.this);
        }
      });

      JMenuItem gpgOverview = new JMenuItem(Language.translate("GnuPG explorer"));
      gpgMenu.add(gpgOverview);
      gpgOverview.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
           //gnuPGLink.askGPGPath(SnowMailClientApp.this);
           new KeysViewer();
        }
      });


      // Spam filter
      //

      JMenu spamMenu = new JMenu(Language.translate("SPAM Filter"));
      getJMenuBar().add(spamMenu);
      this.addAdvancedComponent(spamMenu);


      spamMenu.add(new AddToSpamAction(folderView));
      spamMenu.add(new AddToHAMAction(folderView));
      spamMenu.add(new RemoveSPAMCategory(folderView));

      JMenuItem trainSpamFilterMI = new JMenuItem(Language.translate("Train Spam Filter with all mails"));
      spamMenu.addSeparator();
      spamMenu.add(trainSpamFilterMI);
      trainSpamFilterMI.addActionListener(new ActionListener()
      {                                                                                        
        public void actionPerformed(ActionEvent e)
        {
          Thread t = new Thread()
          {
            public void run()
            {
               trainSpamFilterAction();
            }
          };
          t.setPriority(Thread.NORM_PRIORITY-1);
          t.start();
        }
      });
                                   
      JMenuItem viewSpamStatMI = new JMenuItem(Language.translate("View statistics word list"));
      this.addAdvancedComponent(viewSpamStatMI);
      spamMenu.addSeparator();
      spamMenu.add(viewSpamStatMI);
      viewSpamStatMI.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          new StatViewer(SnowMailClientApp.this);
        }
      });

      JComponent exportStatAction = new JMenuItem(new ExportStatisticsAction());
      spamMenu.add(exportStatAction);
      this.addAdvancedComponent(exportStatAction);

      // Language
      //
      JMenu languageMenu = new JMenu(Language.translate("Language"));
      getJMenuBar().add(languageMenu);
      addAdvancedComponent(languageMenu);

      // English is not in the list
      String[] languages = Language.getInstance().getAvailableInternalLanguages();
      if(languages.length==0)
      {
         // english is already in the list
         languages = Language.getInstance().getAvailableLanguages();
      }
      else
      {
         // add english
         String[] languages2 = new String[languages.length+1];
         for(int i=0; i<languages.length; i++)
         {
           languages2[i+1] = languages[i];
         }
         languages2[0] = Language.ENGLISH;
         languages = languages2;
      }

      ButtonGroup languageGroup = new ButtonGroup();
      for(int i=0; i<languages.length; i++)
      {
        JCheckBoxMenuItem li = new JCheckBoxMenuItem(languages[i],
           languages[i].equals(Language.getInstance().getActualTranslation()));
        languageGroup.add(li);
        final String language = languages[i];
        languageMenu.add(li);
        li.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
             Language.getInstance().setActualTranslation(language,true);
             JOptionPane.showMessageDialog(SnowMailClientApp.this,
                Language.translate("Please restart SnowMail to activate the new language."),
                Language.translate("Language selection"),
                JOptionPane.INFORMATION_MESSAGE
             );

          }
        });
      }
      
      JMenuItem languageEditorMI = new JMenuItem(Language.translate("Interface Translation Editor"));
      advancedComponents.add(languageEditorMI);
      languageMenu.addSeparator();
      languageMenu.add(languageEditorMI);
      languageEditorMI.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          new TranslationEditor();
        }
      });

      /* 
      // Look and Feel
      // 
      JMenu lfMenu = new JMenu(Language.translate("Look and Feel"));
      getJMenuBar().add(lfMenu);
      this.addAdvancedComponent(lfMenu);

      // the menu items are aleady defined
      for(int i=0; i<metalThemes.length; i++)
      {
        lfMenu.add(metalThemesMenuItems[i]);
        final int ii = i;
        metalThemesMenuItems[i].addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
            properties.setInteger("matalTheme_index", ii);
            try
            {
              setMetalTheme(ii);
            }
            catch(Exception ex)
            {
              System.out.println("Exception: "+ex.getMessage());
            }
          }
        });
      }


      JMenuItem custMI = new JMenuItem(Language.translate("Customize actual theme"));
      custMI.setIcon(SnowMailClientApp.loadImageIcon("pics/CustomizeTheme.PNG"));
      lfMenu.addSeparator();
      lfMenu.add(custMI);
      custMI.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {                  
            new ThemesCustomizerFrame(ref, properties);
          }
        }); */ 
      
      JMenu lfMenu = ThemesManager.getInstance().getThemesMenu();
      getJMenuBar().add(lfMenu);
      addAdvancedComponent(lfMenu);


       if(debug)
       {
         JMenu debugMenu = new JMenu(Language.translate("Debug"));
         getJMenuBar().add(debugMenu);
         debugMenu.add(new NewMailFromContent(mailAccounts, storageTreeModel.getComposeFolder()));             
       }   
       
      // Utilities
      //
      //JMenu utilitiesMenu = new JMenu(Language.translate("Utilities"));
      //advancedComponents.add(utilitiesMenu);
      //getJMenuBar().add(utilitiesMenu);
      JMenuItem encryptMenuItem = new JMenuItem(Language.translate("Encrypt a File"));
      cryptoMenu.addSeparator();
      cryptoMenu.add(encryptMenuItem);
      this.addAdvancedComponent(encryptMenuItem);
      encryptMenuItem.addActionListener(new ActionListener()
      { public void actionPerformed(ActionEvent e)
        {
          Thread t = new Thread(){ public void run() 
          {
            SimpleFileEncryptorUI.simpleEncryptFileUI(
                  SnowMailClientApp.getInstance().getProperties(), 
                  SnowMailClientApp.getInstance());
          }};
          t.setPriority(Thread.NORM_PRIORITY-1);
          t.start();
        }
      });  

      JMenuItem decryptMenuItem = new JMenuItem(Language.translate("Decrypt a File"));
      cryptoMenu.add(decryptMenuItem);
      this.addAdvancedComponent(decryptMenuItem);
      decryptMenuItem.addActionListener(new ActionListener()
      { public void actionPerformed(ActionEvent e)
        {
          Thread t = new Thread(){ public void run() {
            SimpleFileEncryptorUI.simpleDecryptFileUI(
                  SnowMailClientApp.getInstance().getProperties(),
                  SnowMailClientApp.getInstance()
            );
          }};  
          t.setPriority(Thread.NORM_PRIORITY-1);
          t.start();
        }
      });

      JMenuItem verifyHashMenuItem = new JMenuItem(Language.translate("Compute or verify HashCode"));
      cryptoMenu.add(verifyHashMenuItem);
      this.addAdvancedComponent(verifyHashMenuItem);
      verifyHashMenuItem.addActionListener(new ActionListener()
      { public void actionPerformed(ActionEvent e)
        {
          new HashCodeDialog(SnowMailClientApp.this, SnowMailClientApp.this.properties);
        }
      });

      // Help
      //
      JMenu helpMenu = new JMenu(Language.translate("Help"));
      getJMenuBar().add(helpMenu); 

      JMenuItem game = new JMenuItem(Language.translate("Khun Pan: a nice game"));
      helpMenu.add(game);  
      helpMenu.addSeparator();
      game.addActionListener(new ActionListener()
      { public void actionPerformed(ActionEvent e)
        {
           new MoveApp(false);
        }
      });
            
      JMenuItem helpMenuItem = new JMenuItem(Language.translate("About"));
      helpMenu.add(helpMenuItem);
      helpMenuItem.addActionListener(new ActionListener()
      { public void actionPerformed(ActionEvent e)
        {
          HTMLViewer htmv = new HTMLViewer(SnowMailClientApp.this,
              Language.translate("SnowMail HTML Viewer - About SnowMail"), true, false, false);
          htmv.setContent(
              "<html><body><H2>SnowMail version "+VERSION+"_"+SUBVERSION+", February 2006</H2>\n\n"
              +"<br> + Multiple POP/SMTP accounts"
              +"<br> + Virtual keyboard to type unicode characters. Polish, Lituanian and Russian maps"
              +"<br> + SSL connections (if the mail server support them and the certificates are present in the truststore file)"
              +"<br> + GnuPG 1.4 support for signing/encrypting outgoing mails and verify/decrypt incoming mails, "
              +"<br>    keys explorer, import, keypair generation, ownertrust edit"
              +"<br> + Strong passphrase cryptography (128 bits Blowfish) used for saving mail folders and account data"
              +"<br> + Addressbook (acting as whitelist) and blacklist"
              +"<br> + Statistical SPAM filter"
              +"<br> + Quick messages preview with header spam analysis"
              +"<br> + Full MIME tree view (content structure and attachments)"
              +"<br> + Internal secure HTML viewer (filtered without links, scripts and images)"
              +"<br> + Freeware and freesource"
              +"<br> + 100% pure Java 5, own protocol implementations, from the RFC's"
              +"<br><br>Homepage: http://snowmail.sn.funpic.de (mirrored on www.geocities.com/stephanchaud)"
              +"<br>Author: Stephan Heiss, stephan@www.snowraver.org"
              +"</body></html>");                  

          htmv.setSize(600,520);
          centerComponentOnMainFrame(htmv);
          htmv.animateBackground(true);
          htmv.setVisible(true);
          htmv.animateBackground(false);
        }
      });

      // Memory label at the right
      //
      MemoryInfoPanel mip = new MemoryInfoPanel();
      //gridBagConstraints.anchor = gridBagConstraints.LINE_END;
      menuBar.add(Box.createHorizontalGlue());
      menuBar.add(mip);
      this.addAdvancedComponent(mip);

   }
   
   
   /** to be called outside from EDT
     trains the filter and class all mails...
   */
   private void trainSpamFilterAction()
   {                   
     ProgressModalDialog progressDialog = new ProgressModalDialog(
         SnowMailClientApp.getInstance(),
         Language.translate("SPAM filter generation"), false);

     progressDialog.setCommentLabel(Language.translate("Analysing all mails")+"...");
     progressDialog.start();   
                                        
     try
     {                          
        progressDialog.setProgressBounds( storageTreeModel.getTotalNumberOfFolders() * 2 );

        // Training
        //
        wordStatistic.deleteStatistic();
        storageTreeModel.analyseAllMailsToTrainSPAMFilter(progressDialog);
        progressDialog.setProgressComment(Language.translate("Building word statistic"));

        if(  wordStatistic.getNumberOfSPAMMails()==0 )                      
        {
          throw new Exception(Language.translate("You have %1 hams and %2 spam mails.",
             ""+wordStatistic.getNumberOfHAMMails(),
             ""+wordStatistic.getNumberOfSPAMMails())
             +"\n"+Language.translate("You must first define some spam mails."));
        }
        if(  wordStatistic.getNumberOfHAMMails()==0 )
        {
          throw new Exception(Language.translate("You have %1 hams and %2 spam mails.",
             ""+wordStatistic.getNumberOfHAMMails(),
             ""+wordStatistic.getNumberOfSPAMMails())
             +"\n"+Language.translate("You must have at least one non-spam mail!"));
        }

        wordStatistic.buildStatistics(progressDialog);

                                     
        // Analysis  
        //
        progressDialog.setCommentLabel(Language.translate("Filtering all mails")+"...");
        storageTreeModel.filterAllMailsIntoSPAMCategory(progressDialog);

        progressDialog.closeDialog();

        JTextArea text = new JTextArea(wordStatistic.toStringStat());
        text.setEditable(false);
        JDialog dialog = new JDialog(SnowMailClientApp.getInstance(), Language.translate("SPAM Filter results"), true);
        text.setBackground(dialog.getBackground());
        JScrollPane jsp = new JScrollPane(text);
        jsp.setOpaque(false);
        text.setOpaque(false);
        jsp.getViewport().setOpaque(false);

        dialog.getContentPane().setLayout(new BorderLayout());
        CloseControlPanel ccp = new CloseControlPanel(dialog, false, false, Language.translate("Close"));
        dialog.getContentPane().add(ccp, BorderLayout.SOUTH);
        dialog.getContentPane().add(jsp, BorderLayout.CENTER);
        dialog.setSize(400,400);
        centerComponentOnMainFrame(dialog);
        dialog.setVisible(true);             
     }
     catch(Exception e2)              
     {
       e2.printStackTrace();   
       JOptionPane.showMessageDialog(this,
          Language.translate("Error")+": "+e2.getMessage(), 
          Language.translate("Error occured during SPAM filter training"),
          JOptionPane.ERROR_MESSAGE);  
     }          
     finally
     {
       progressDialog.closeDialog();
     }

   }

   private JSenseButton createToolbarButton(Action a)
   {
     //return a;/*
     JSenseButton bt = new JSenseButton(a);
     bt.setFocusPainted(false);
     return bt;
   }                 


   private void checkRootDir()
   {
    if(snowMailRoot.exists())
    {
      if(!snowMailRoot.isDirectory())
      {
        JOptionPane.showMessageDialog(null,
          Language.translate("The snowmail root folder can't be created, a file with the same name already exists")+":"
          +"\n  "+snowMailRoot.getAbsolutePath()
          +"\n"+
          Language.translate("Delete this file and restart SnowMail."),
          Language.translate("Fatal Error"), JOptionPane.ERROR_MESSAGE);

        System.exit(0);
      }
    }
    else
    {
      // create
      if(!snowMailRoot.mkdirs())
      {
        JOptionPane.showMessageDialog(null,
          Language.translate("The snowmail root folder can't be created.")
          +"\n "+snowMailRoot.getAbsolutePath()
          +"\n"
          +Language.translate("Please check that you have the sufficient privileges for this directory and restart SnowMail"),
          Language.translate("Fatal Error"), JOptionPane.ERROR_MESSAGE);

        System.exit(0); 
      }
    }               
  } // Constructor  
  
  
  /** cause the actual edited mail to save and
      The opened folders to save in file
  */
  public void saveAllMails(boolean close)
  {
    // all folders
    mailView.saveActualMessage();   // cause current to save
    try
    {                  
      this.storageTreeModel.storeAllOpenedFolders(close);
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }   
  }

  private void terminateApplication()
  {
    Thread t = new Thread()
    {
      public void run()   
      {                  
         int_terminate();
      }
    };
    t.start();
  }
              
  /** called in a thread to show UI progress
  */
  private void int_terminate()
  { 
    this.getAccounts().closeAllOpenedPOPConnections();

    mailView.callBeforeTerminating();
    
    ProgressModalDialog startupProgress = new ProgressModalDialog(this, Language.translate("Closing of") + " " + TITLE, false);
    startupProgress.setShowCancel(false);
    startupProgress.setProgressBounds(100);
    centerComponentOnMainFrame(startupProgress);
    startupProgress.start();


    properties.saveComponentSizeInINIFile(this, "SnowMailClientApp");
    properties.setInteger("splitPaneHorizontal", splitPaneHorizontal.getDividerLocation());
   // properties.setInteger("splitPaneVerticalLeft", splitPaneVerticalLeft1.getDividerLocation());
    properties.setInteger("splitPaneVerticalLeft2", splitPaneVerticalLeft2.getDividerLocation());
    properties.setInteger("splitPaneVerticalRight", splitPaneVerticalRight.getDividerLocation());

    properties.setBoolean("advancedMode", advancedMode);
    

    foldersView.terminateViewAndSaveSelection(properties);

    // properties
    startupProgress.setProgressValue(10, Language.translate("Saving properties")+"...");
    try
    {
      File propFile = new File(snowMailRoot, "properties");
      saveVectorToFile( propFile, properties.getVectorRepresentation());
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }

      
    // keys, stored ONLY IF THE USER HAS SET A PASSWORD
    // otherwise, we will NOT save them with the default password !!!

    startupProgress.setProgressValue(20, Language.translate("Saving keys")+"...");
    try
    {

      if( SecretKeyManager.getInstance().isUserKeySet() )
      {
        File keyFile = new File(snowMailRoot, "userkeystore");               
        saveVectorToFile( keyFile, SecretKeyManager.getInstance().getVectorRepresentation());
      }   
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }

    // accounts
    startupProgress.setProgressValue(30, Language.translate("Saving accounts")+"...");
    try                                  
    {
      File accountsFile = new File(snowMailRoot, "accounts");
      saveVectorToFile(accountsFile, mailAccounts.getVectorRepresentation() );
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }

    // addressBook
    startupProgress.setProgressValue(40, Language.translate("Saving addresses")+"...");
    try
    {
      File adbFile = new File(snowMailRoot, "addressBook");
      saveVectorToFile(adbFile, addressBook.getVectorRepresentation() );
    }
    catch(Exception e)
    {
      e.printStackTrace();                         
    }

    // spamBook
    startupProgress.setProgressValue(45, Language.translate("Saving spam addresses")+"...");
    try
    {
      File spamFile = new File(snowMailRoot, "spamBook");     
      saveVectorToFile(spamFile, spamBook.getVectorRepresentation() );
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }

    // statistic spam filter
    startupProgress.setProgressValue(50, Language.translate("Saving statistics")+"...");
    try
    {                                             
      File statFile = new File(snowMailRoot, "wordStatistic");
      saveVectorToFile(statFile, this.wordStatistic.getVectorRepresentation() );
    }                     
    catch(Exception e)
    {
      e.printStackTrace();
    }    
    
    // only saved if encrypted on the disk !
    if( SecretKeyManager.getInstance().isUserKeySet() )
    {  
      startupProgress.setProgressValue(55, Language.translate("Saving GnuPG passwords")+"...");                                     
      try
      {                  
        File propFile = new File(snowMailRoot, "gnuPGLink");
        saveVectorToFile( propFile, this.gnuPGLink.getVectorRepresentation());
      }                              
      catch(Exception e)
      {
        e.printStackTrace();
      }

    }


    // backup
    startupProgress.setProgressValue(60, Language.translate("Backup")+"...");
    try
    {
      backup.checkDoBackup();
      File bcFile = new File(snowMailRoot, "backup");
      saveVectorToFile( bcFile, backup.getVectorRepresentation());
    }
    catch(Exception e)            
    {
      e.printStackTrace();   
    } 
    
    
                                       
    startupProgress.setProgressValue(65, Language.translate("Saving all opened folders")+"...");
    saveAllMails(false);

    startupProgress.setVisible(false);
     
    // bye bye, see you soon, hopefully
    System.exit(0);
  }
  
  
  /** read /decipher the file
  */
  private Vector<Object> readVectorFromFile(File file, Object frameOrDialog_parent) throws Exception
  {

     try        
     {      
        // normally, it don't ask,because the key will be prompted
        // when the keyfile is read
        // exceptions: the keyfile is deleted
        // an old file has replaced one of the system files (properties, or spamlist...)
        Vector<Object> v = FileCipherManager.getInstance().decipherVectorFromFile_ASK_KEY_IF_NEEDED(
                file,
                frameOrDialog_parent, 
                Language.translate("Passphrase protected file"),
                Language.translate("Enter your Snowmail secret passphrase"));
        return v;    
     }
     catch(Exception ee)    
     {                
       // important: don't let user in...
       System.exit(0);
       return null;
     }        
  }

  /** used to store the snowmail files (not mail folders)
      keymanager, ...   
  */
  private void saveVectorToFile(File file, Vector<Object> v) throws Exception
  {
     FileCipherManager.getInstance().encipherVectorToFile(v, file,
                  SecretKeyManager.getInstance().getActualKey());
  }
                    
  /** used to center dialogs on this main frame
   */
   public static void centerComponentOnMainFrame(Component c)
   {      
       int x, y, w, h;
       if(ref==null || ref.getSize().getWidth()<100)
       {
          Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
          x = 0;
          y = 0;
          w = (int) screen.getWidth();
          h = (int) screen.getHeight();
       }
       else
       {
          x = (int) ref.getLocation().getX();
          y = (int) ref.getLocation().getY();
          w = (int) ref.getSize().getWidth();
          h = (int) ref.getSize().getHeight();
       }

       int px = x + (int) (w - c.getSize().getWidth())/2;
       int py = y + (int) (h - c.getSize().getHeight())/2;
       if(px<0) px = 0;
       if(py<0) py = 0;
       c.setLocation(px,py);
   }              

  /** load an ImageIcon, either in the jar file (during the normal execution)
      or in the source path, during the development.
      Every images are read in the event dispatch thread to avoid some runtime exceptions.
  */
  public static ImageIcon loadImageIcon(final String name)
  {                  
    final ImageIcon[] iconContainer = new ImageIcon[1];
    SwingSafeRunnable ssr = new SwingSafeRunnable(new Runnable()
    {
      public void run()
      {
        URL url = SnowMailClientApp.class.getResource(name);
        if(url!=null)
        {
           iconContainer[0] = new ImageIcon(Toolkit.getDefaultToolkit().getImage(url));
        }
        else
        {                                                                                       
           iconContainer[0] = new ImageIcon("SnowMailClient/" + name);
        }
      }
    }, true);
    ssr.run();
    return iconContainer[0];
  } 
  
  
  public static void copyToClipboard(final String content)
  {                      
     Clipboard clip = java.awt.Toolkit.getDefaultToolkit().getSystemClipboard();
     Transferable transferable = new Transferable()
     {
        public DataFlavor[] getTransferDataFlavors()
        {
          return new DataFlavor[]{DataFlavor.plainTextFlavor};
        }
        public boolean isDataFlavorSupported(DataFlavor f)
        {
          return f.equals(DataFlavor.plainTextFlavor);
        }
        public Object getTransferData(DataFlavor f) { return content; }            
     };
     clip.setContents(
       transferable,
       new ClipboardOwner()
       {
         public void lostOwnership(Clipboard c, Transferable t)
         {
         }    
       });
  }
      
      
  public static JPanel wrapLeft(Component c)
  {               
    JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT,0,0));
    p.setOpaque(false);
    p.add(c);
    return p;
  }  

  public static JPanel wrapRight(Component c)
  {
    JPanel p = new JPanel(new FlowLayout(FlowLayout.RIGHT,0,0));
    p.setOpaque(false);
    p.add(c);
    return p;
  }                       



  private void initializeSSLCertificateInfo()
  {
     File trustStoreFile = new File(this.getSnowMailRoot(),
              "trustStore.certificates");
     
     System.setProperty("javax.net.ssl.trustStore", trustStoreFile.getAbsolutePath() );
       
     if(!trustStoreFile.exists())
     {       
       // copy the default keystore
       if(!copySSLTrustStore(trustStoreFile))
       {
          JOptionPane.showMessageDialog(
            null,
             Language.translate("No SSL Truststore fount at\n   %"
                +"\nThis keystore must contain all your trusted sites certificates."
                +"\nWithout this keystore, you'll not be able to establish SSL connections.",
                trustStoreFile.getAbsolutePath()
            ),
            Language.translate("TrustStore is not present"),
            JOptionPane.ERROR_MESSAGE);
       }
     }
     else
     {
       //ok System.out.println("TrustStore present: "+trustStoreFile.getAbsolutePath());
     }


  }


  private boolean copySSLTrustStore(File file)
  {
        // smart intelligent clever mode,
        // try to extract from jarfile
        ClassLoader cl = SnowMailClientApp.class.getClassLoader();

        FileOutputStream fos = null;
        try
        {
          URL url = cl.getResource("trustStore.certificates");
          InputStream is = null;
          if(url!=null)                                                                       
          {               
            is = url.openStream();
          }
          else
          {
            is = new FileInputStream("trustStore.certificates");
          }
          
                                                                                            
          if(is!=null)
          {  
            // copy  
            File parentDir = file.getParentFile();
            if(!parentDir.exists()) parentDir.mkdirs();
            fos = new FileOutputStream(file);  
                        
            byte[] buffer = new byte[256];
            int read = 0;            
            while((read=is.read(buffer))!=-1)
            {
              fos.write(buffer,0,read);
            }         
            return true;
          }
          else
          {
            System.out.println("URL is null, cannot copy certificate");
            return false;
          }
        }
        catch(Exception e)
        {
          e.printStackTrace();
          return false;
        }
        finally
        {
          if(fos!=null) {try{ fos.close(); } catch(Exception ee){}}
        }
  }


  /**  Options (with examples)
          -homeDir="c:/document and settings/mr.bean"
          -DEBUG=TRUE
  */
  public static void main( String[] arguments )
  {
     parseArguments(arguments);
     if(snowMailRoot==null)
     {            
       // default dir, if not set as argument
       snowMailRoot = new File(System.getProperty("user.home"), "snowmail");
     }            

     // Activate the language
     Language.baseDirectory = snowMailRoot.getAbsolutePath();
     Language.getInstance();


     // initialize the L&F defaults
     ThemesManager.baseDirectory = snowMailRoot.getAbsolutePath();
     ThemesManager.getInstance();
     JFrame.setDefaultLookAndFeelDecorated(true);
     JDialog.setDefaultLookAndFeelDecorated(true);

                      
     // here we really start    
     // [26Oct2005]
     // with 1.5.0_02: 
     //     Exception in thread "AWT-EventQueue-0" java.lang.NoSuchMethodError: java.nio.DirectByteBuffer.checkBounds(III)V
     
     // BLOCKS IF EDT BECAUSE OF MODAL DIALOG...!!
     new SnowMailClientApp();

     // jing some bells
     //SynthesizerDemo.main(null);

  } // main


  /** is static because must be evaluated before instance created...
  */
  private static void parseArguments(String[] args)
  {
    if(args==null || args.length==0) return;

    debug = false;
    for(int i=0; i<args.length; i++)                                                                         
    {
      //System.out.println("Start argument "+args[i]);
      if(args[i].toUpperCase().startsWith("-HOMEDIR="))
      {
         String snowMailRootName = removeQuotes(args[i].substring(9).trim()).trim();
         snowMailRoot = new File(snowMailRootName);
                                                                                                            
         System.out.println("homeDir = "+snowMailRootName);
      }
/*      if(args[i].toUpperCase().startsWith("-USERNAME="))
      {
         String userName = RemoveQuotes(args[i].substring(10).trim()).trim();
         //snowMailRoot = new File(snowMailRootName);
                      
         System.out.println("User name = "+userName);
      }*/
      if(args[i].toUpperCase().startsWith("-DEBUG=TRUE"))
      {
         debug = true;
      }

    }
  }

  /** @return the text without starting quotes " or '
  */
  public static String removeQuotes(String _text)
  {
         String text = _text;
         if(text.charAt(0)=='\"'
         || text.charAt(0)=='\'')
         {
           text = text.substring(1);
         }

         if(text.charAt(text.length()-1)=='\"'
         || text.charAt(text.length()-1)=='\'')
         {
           text = text.substring(1);
         }
         return text;
    
  }   

} // SnowMailClientApp
