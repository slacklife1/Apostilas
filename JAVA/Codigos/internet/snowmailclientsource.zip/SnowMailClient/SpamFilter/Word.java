package SnowMailClient.SpamFilter;

import snow.utils.storage.*;
import java.util.*;

/**
    1) during the train operation, the occurences are counted
    2) calculateProbs is called 
*/
public final class Word implements Comparable
{                
  public String word; 
  
  private int occurencesInHAM = 0;
  private int occurencesInSPAM = 0;
  private double spamProb =-1;
         

  public Word(String w)       
  {
    this.word = w;
  }

  public Word(String w, int occurencesInHAM, int occurencesInSPAM)
  {
    this.word = w;              
    this.occurencesInHAM = occurencesInHAM;  
    this.occurencesInSPAM = occurencesInSPAM;
  }

  public double getSpamProb() { return spamProb; }
  // called in some special cases
  public void setSpamProb(double p) { spamProb = p; }
  public void addSpamOccurence() { occurencesInSPAM++; }
  public void addHamOccurence() { occurencesInHAM++; }
                                
  public int getHamOccurences()  { return occurencesInHAM; }
  public int getSpamOccurences() { return occurencesInSPAM; }


  /** @param the total number of messages, spam or hams
  */
  public void calculateProbs(double totHams, double totSpams)
  {
    if(occurencesInHAM==0)
    {                       
      if(occurencesInSPAM<10)
      {
        spamProb = 0.9998;
      }
      else
      {
        spamProb = 0.9999;
      }
    }
    else if(occurencesInSPAM==0)
    {                          
      if(occurencesInHAM<10)
      {
        spamProb = 0.0003;
      }
      else
      {
        spamProb = 0.0002;
      }
    }
    else
    {
      // not zero occurences
      // count ham two times
      spamProb = (double) occurencesInSPAM / totSpams /
         ( (double) occurencesInHAM*2.0 / totHams + (double) occurencesInSPAM / totSpams);
    }
  }

  // search
  //

  public boolean equalsIgnoreCase(String w)
  {
    return word.equalsIgnoreCase(w);
  }
                         
  public boolean equals(Object o)
  {
    if(!(o instanceof Word)) throw new RuntimeException("Bad class "+o.getClass());
    Word w2 = (Word) o;
    return word.equals(w2.word);
  }        
  
  public int hashCode()    
  {
    return word.hashCode();
  }

  /** in decreasing spam prob
  */
  public int compareTo(Object o)
  {
    if(!(o instanceof Word)) throw new RuntimeException("Bad class "+o.getClass());
    Word w2 = (Word) o;

    if( this.spamProb > w2.spamProb) return -1;
    if( this.spamProb < w2.spamProb) return 1;
    
    // same probability => compare words
    return this.word.compareTo(w2.word);
  }

  public String toString()
  {
     return word+" ("+occurencesInHAM+" / "+occurencesInSPAM+" / "+this.spamProb+")";
  }                                      

  
  static class RelevanceComparator implements Comparator
  {
    public int compare(Object o1, Object o2)
    {
      Word w1 = (Word) o1;
      Word w2 = (Word) o2;
      double d1 = Math.abs( w1.getSpamProb() - 0.5);
      double d2 = Math.abs( w2.getSpamProb() - 0.5);
      
      if(d1>d2) return -1;
      if(d1<d2) return 1;

      // d1==d2
      // important, to be able to suppress multiple occurences of the same word later
      return w1.word.compareTo(w2.word);
    }            

  }

} // Word
