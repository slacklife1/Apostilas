package SnowMailClient.SpamFilter;

import java.util.*;

public final class SpamResult
{
  private double probability;
  private final Vector mostSignificantWords;
  private final Vector allWords;
                          
  public SpamResult(Vector allWords, Vector mostSignificantWords, double probability)
  {
    this.mostSignificantWords = mostSignificantWords;
    this.allWords = allWords;    
    this.probability = probability;
  } // Constructor

  public double getProbability() { return probability; }

  public Vector getMostSignificantWords() { return mostSignificantWords; }
  public Vector getAllWords() { return allWords; }
  


} // SpamResult
