package SnowMailClient.SpamFilter;

import java.util.*;
              
/** rules: 
    1) ! is a character
    2) . is a character if between two digits
    
*/
public final class WordTokenizer implements Iterator
{
  int pos = 0;
  String text;                          

  public WordTokenizer(String text)
  {
    this.text = text;
    avanceToNextWordStart();
  } // Constructor
                       
  public boolean hasMoreTokens()
  {
    return pos != text.length();
  }
  
  // Iterator interface ### 1.5 => specify type
  //
  public Object next() { return nextToken(); }
  public boolean hasNext() { return hasMoreTokens(); }
  public void remove() { throw new RuntimeException("Not supported"); }

  public String nextToken()
  {
    StringBuffer token = new StringBuffer();
    for(; pos<text.length(); pos++)
    {
       char chi = text.charAt(pos);
       // end of word reached                                                                                                                          
       if(!isWordChar(chi))
       {
         if(chi=='.' || chi==',')
         {
           // rule 2, if "." or "," is between two digits, it is a constituent
           // this keeps IP's and prices intact 
           // URL's not...
           char chi1 = text.charAt(pos-1);
           if(pos+1==text.length()) break;
           char chi2 = text.charAt(pos+1);

           if(!Character.isDigit(chi1)
           || !Character.isDigit(chi2)) break;
         }
         else          
         {      
           break;
         }
       }

       token.append(chi);
    }
    avanceToNextWordStart(); 
    return token.toString();
  }

  /** advance up to the next non-separator
  */
  private void avanceToNextWordStart()
  {
    for(; pos<text.length(); pos++)
    {
      char chi = text.charAt(pos);
      if(isWordChar(chi)) return;
    }     
  }

  private boolean isWordChar(char c)
  {
    if(c>='a' && c<='z') return true;
    if(c>='A' && c<='Z') return true;
    if(c>='0' && c<='9') return true;
    if(c=='-' || c=='_' || c=='!') return true;
    
    return false;
  }
  
  public static String[] extractWords(String text)
  {
    WordTokenizer wt = new WordTokenizer(text);
    Vector<String> words = new Vector<String>();
    while(wt.hasMoreTokens())                                                                                                                     
    {
      String w = wt.nextToken();
      if(w.length()!=0)
      { 
        // #### sometimes the last word is empty... when for example terminating with <html>
        //
        words.add(w);
      }
      else
      {
        System.out.println("################ Problem ?");
      }
    }              
    return (String[]) words.toArray(new String[words.size()]);
  }


 /**
  *  Static main method
  */
  public static void main( String[] arguments )
  {
    WordTokenizer wt = new WordTokenizer("   Hello2-t!!!    th-is is teXtz 44.and another,a.b <html>Shit<pre></pre>"
    +" http://62.65.146.182.is  http://www.aaa.bbb a cool IP 34,23$       is my price</html>");
    while(wt.hasMoreTokens())  
    {
      System.out.println(""+wt.nextToken());
    }
         
    double[] t = new double[]{1,2,3};
    test(t);
    System.out.println(t[0]);
  } // main


  private static void test(double[] a)
  {
    a[0] = 12;
  }

} // WordTokenizer
