package SnowMailClient.SpamFilter;

import SnowMailClient.*;
import SnowMailClient.model.*;
import SnowMailClient.model.multipart.*;
import snow.utils.storage.*;
import SnowMailClient.utils.TextSearch.EditDistance;
import snow.utils.gui.*;
import SnowMailClient.html.HTMLTextExtractor;

import java.util.*;
import java.util.regex.*;
import java.io.*;
import java.text.DecimalFormat;


/** Read "A Plan for SPAM" 2002 and 2003 articles for explanations
*/
public final class WordStatistic implements Vectorizable
{
  // parameters
  private static final int NUMBER_OF_WORD_TO_CONSIDER_FOR_A_MESSAGE = 17;
  private static final int NUMBER_OF_WORD_TO_CONSIDER_FOR_A_HEADER = 13;
  private static final double SPAM_PROBABILITY_LIMIT = 0.95;
  boolean considerOnlyOneOccurenceOfEachWord = true;

  private int maxDistanceApproximateSearch = 0;  // Slow
  private int foundWithTolerance1 = 0;


  // stored data
  //

  private int nSpamMails = 0;
  private int nHamMails = 0;
  private int nUnclassedMails = 0;

  // quick access {key = word)
  private Hashtable<String,Word> wordsHashtable = new Hashtable<String,Word>();

  /** quick acces based on word lengths,
      very efficient for tolerant search (search only on categories +-1 length)
  */
  private Hashtable<Integer, Hashtable> wordsHashtableForLength = new Hashtable<Integer, Hashtable>();
                                           
  // stats 
  public int result_false_positives = 0;
  public int result_detected_spams  = 0;


  public int result_false_positives_header = 0;
  public int result_detected_spams_header  = 0;
                         
  private StringBuffer falsePositivesBuffer = new StringBuffer();
  public void addFalsePositive(String ref)
  {
    falsePositivesBuffer.append("\r\n "+ref);
  }
              
  public int getNumberOfWords()
  {
    return wordsHashtable.size();
  }

  /** all words should be added here
  */
  private void addWord(Word word)
  {
    wordsHashtable.put(word.word, word);
    if(!this.wordsHashtableForLength.containsKey(word.word.length()))
    {
      wordsHashtableForLength.put(word.word.length(), new Hashtable());
    }

    wordsHashtableForLength.get(word.word.length()).put(word.word, word);
  }

  /** all words should be removed here
  */
  private void removeWord(Word word)
  {
    wordsHashtable.remove(word.word);
    wordsHashtableForLength.get(word.word.length()).remove(word.word);
  }

  /** used in the stat viewer
  */
  public Hashtable<String,Word> getAllWords() { return wordsHashtable; }


  /** null if not found */
  public Word getWordExact(String word)
  {
    return wordsHashtable.get(word);
  }

  int notFoundWords = 0;


  /** try alternatives if not found.
   *  This
  */      
  public Word getWord_using_alternatives(final String prefix, final String word)
  {         
    if(word.length()==0)
    { 
       System.out.println("Zero length word !");
       return null;              
    }              
    String nw = normalize(word);
    Word w = wordsHashtable.get(prefix + nw);
    if(w!=null) return w;                        

    // alternatives   
    if(nw.endsWith("#"))
    {
      w = wordsHashtable.get(prefix + nw.substring(0,nw.length()-2));
      if(w!=null) return w;

      w = tryAlternativeCases(prefix, nw.substring(0,nw.length()-2));
      if(w!=null) return w;
    }   
    else
    {
      w = wordsHashtable.get(prefix + nw+"#");
      if(w!=null) return w;
          
      w = tryAlternativeCases(prefix, nw+"#");
      if(w!=null) return w;
    }

    w = tryAlternativeCases(prefix, nw);
    if(w!=null) return w;



    // try all without prefix
    if(prefix.length()>0)
    {
      w = getWord_using_alternatives("", word);  
      if(w!=null) return w;
      return null;
    }
    // else

    // try with edit distance (SLOW !)
    //
    if(maxDistanceApproximateSearch>0)
    {
      w = searchWord_with_tolerance(word, maxDistanceApproximateSearch);
      if(w!=null) return w;
    }

    // not found...
    return null;
  }



  /** apply an edit-distance algorithm to find approximate matches
  */
  private Word searchWord_with_tolerance(String word, int maxDist)
  {                       
    String wordUP = word.toUpperCase();
    
    int wlen = wordUP.length();
    if(wlen>15) return null;   // too long and too small prob to find a match !                                                      
                                  
    // look only potential correct lengths !
    //int i = wlen;
    for(int i=wlen-maxDist;  i<=wlen+maxDist;  i++)
    {
       if(wordsHashtableForLength.containsKey(i))
       {
          // all the words of length i
          Hashtable wordsi = wordsHashtableForLength.get(i);
          Collection<Word> s = wordsi.values();

          for(Word w: s)
          {
             int d = EditDistance.editDistance(wordUP, w.word.toUpperCase(), maxDist);
             if(d<=maxDist)
             {
                System.out.println(""+w.word+" is similar to "+word);
                foundWithTolerance1 ++;
                return w;
             }
          }
       }
    }
    
    //System.out.println("No similar word found for "+word);

    return null;
  }

  
  /**  Bug
       bug
       BUG
  */
  private Word tryAlternativeCases(String prefix, String nw)
  {
    // p*BUG
    Word w = wordsHashtable.get(prefix + nw.toUpperCase());
    if(w!=null) return w;

    // p*bug
    w = wordsHashtable.get(prefix + nw.toLowerCase());
    if(w!=null) return w;

    if(nw.length()>1)
    {
      // p*Bug
      w = wordsHashtable.get(prefix + Character.toUpperCase(nw.charAt(0))+nw.substring(1,nw.length()-1).toLowerCase());
      if(w!=null) return w;
    }
    return null;
  }


  public int getNumberOfHAMMails()   { return nHamMails; }
  public int getNumberOfSPAMMails()  { return nSpamMails; }

  public void deleteStatistic()
  {                    
    wordsHashtable.clear();
    this.wordsHashtableForLength.clear();

    nSpamMails = 0;
    nHamMails = 0;
    nUnclassedMails = 0;
    result_false_positives = 0;
    result_detected_spams = 0;
    result_false_positives_header = 0;
    result_detected_spams_header = 0;  
    foundWithTolerance1 = 0;

    falsePositivesBuffer.setLength(0);
  }

                
  public String toStringStat()
  {
    StringBuffer sb = new StringBuffer();
    sb.append("\r\nStatistic has "+wordsHashtable.size()+" words");
    sb.append("\r\n\r\n  Number of HAM mails = " + nHamMails);
    sb.append("\r\n  Number of SPAM mails = " + nSpamMails);
    sb.append("\r\n  Number of unclassed mails = "+nUnclassedMails);
    sb.append("\r\n\r\nDetection results");
    sb.append("\r\n  Number of detected spams = " + this.result_detected_spams);
    if(nSpamMails>0)
    {      
       DecimalFormat df = new DecimalFormat("00.00");
       double x = (double) result_detected_spams/nSpamMails*100.0;
       sb.append( "  ("+ df.format(x)+"%)");
    }
    sb.append("\r\n  Number of false positives = " + this.result_false_positives);
    if(nHamMails>0)
    {
       DecimalFormat df = new DecimalFormat("0.0000");
       double x = (double) result_false_positives/nHamMails*100.0;
       sb.append( "  ("+ df.format(x)+"%)");
    }

    sb.append("\r\n\r\nDetection results using only the header");
    sb.append("\r\n  Number of detected spams = " + this.result_detected_spams_header);
    sb.append("\r\n  Number of false positives = " + this.result_false_positives_header);

    sb.append("\r\n\r\n Words not found = "+this.notFoundWords);
    sb.append("\r\n Found with tolerance "+maxDistanceApproximateSearch+" = " + foundWithTolerance1);
    
    /* Debug     
    sb.append("\r\n\r\n"+this.wordsHashtableForLength.size()+" different word lengths");
    Set<Integer> keys = wordsHashtableForLength.keySet();
    for(Integer i: keys)
    {
       Hashtable ht = wordsHashtableForLength.get(i);
       sb.append("\r\n length "+i+": "+ht.size()+" elements");
    }*/
                                  

    if(falsePositivesBuffer.length()>0)
    {
      sb.append("\r\n\r\nFalse positives:");
      sb.append(falsePositivesBuffer.toString());
    }

    return sb.toString();
  }                                   

  /** call this after added all mails...
    this will delete entries with bad stat (ratio near 0.5)
    or rare words
    
    This is also called after a recreation of the stats, because to save storage, 
    the words are only stored with their counts, the probs need to be recomputed
    at each startup (this is very fast)
  */
  public void buildStatistics(ProgressModalDialog progress)
  {                   

    int nSingles = 0;
    int nNotSeparators = 0;

    // 1: calculate totals
    //
    for(Word w: wordsHashtable.values())
    {
      if(w.getSpamOccurences() + w.getHamOccurences() < 5)
      {
        nSingles++;
      }
    }

    // System.out.println("Build stat "+this.nHamMails+" / "+this.nSpamMails);

    // 2: calc probs and remove the not signifiant ones
    //
    Vector<Word> toRemove = new Vector<Word>();
    for(Word w: wordsHashtable.values())
    {
       w.calculateProbs(this.nHamMails, this.nSpamMails);

       if(w.getSpamProb()>0.47 && w.getSpamProb()<0.53)
       {
          //toRemove.add(w);    // ConcurrentAccesException if directly removed !
          nNotSeparators++;
       }
    }

    for(Word w: toRemove)
    {
       wordsHashtable.remove(w);
    }
    
    System.out.println("Number of words not discriminating: "+nNotSeparators+", number appearing less than 5: "+nSingles);
  }
  
  public static boolean isSpam(double messProb)
  {
    return messProb>SPAM_PROBABILITY_LIMIT;
  }

  /** @return a spam probability [0..1]
  */                       
  public SpamResult calculateSpamProbability(Header head)
  {
    // search for words
    Vector<Word> foundWords = new Vector<Word>();
    for(int i=0; i<head.getEntriesCount(); i++)
    {
      HeaderEntry he = head.getEntryAt(i);
      scanWords(foundWords, he.getKey().toLowerCase()+"*", he.getValue());
    }

    //  search for the 12 more relevant words
    return calculateSPAMProbability(foundWords, NUMBER_OF_WORD_TO_CONSIDER_FOR_A_HEADER);
  }          
  
  

  /** @return a spam probability [0..1]
  */
  public SpamResult calculateSpamProbability(MailMessage mess)
  {
    // 1) search for words

    Vector<Word> foundWords = new Vector<Word>();

    // in the header   
    Header head = mess.getHeader();
    for(int i=0; i<head.getEntriesCount(); i++)
    {
      HeaderEntry he = head.getEntryAt(i);
      scanWords(foundWords, he.getKey().toLowerCase()+"*", he.getValue());
    }

    // in the message     
    if(MimeUtils.isMultipart(mess))
    {    
       // in mime
       MimeTreeModel mimeTree = mess.getMimeTree();
       MimePart mp = mimeTree.getRootPart();
       scanWordsRecurse(foundWords, mp);
    }
    else
    {
       this.scanWords(foundWords, "", mess.getMessageBody());
    }

    // 2) search for the 20 more relevant words
    return calculateSPAMProbability(foundWords, NUMBER_OF_WORD_TO_CONSIDER_FOR_A_MESSAGE);
  }

  

  private SpamResult calculateSPAMProbability(Vector<Word> allWords, int numberOfMostRelevantWordsToConsider)
  {
    // search for the more relevant words
    Vector<Word> mostRelevantWords = new Vector<Word>();
    Collections.sort(allWords, new Word.RelevanceComparator());

    String lastWord = "";
    if(allWords.size()>numberOfMostRelevantWordsToConsider)
    {
      for(int i=0; i<numberOfMostRelevantWordsToConsider*14; i++)
      {

        Word wi = (Word) allWords.elementAt(i);
        if(wi.word.equals(lastWord) && considerOnlyOneOccurenceOfEachWord)
        {
          // don't put multiple occurences ( ??? )
        }
        else
        {
          mostRelevantWords.addElement( wi );
          if(mostRelevantWords.size()>=numberOfMostRelevantWordsToConsider)
          {   
            break;
          }
          lastWord = wi.word;
        }
      }
    }

    double probSPAM_log = 0;
    double probHAM_log = 0;

    for(Word wi: mostRelevantWords)
    {
      probSPAM_log += Math.log(wi.getSpamProb());
      probHAM_log += Math.log(1.0 - wi.getSpamProb());
    }

    double p = Math.exp(probSPAM_log) / ( Math.exp(probSPAM_log) + Math.exp(probHAM_log)) ;

    return new SpamResult(allWords, mostRelevantWords, p);
  }


  /**
      @prefix is added to the word,   example subject*
         this is used to put header & tag infos in the stat and distinguish them.
  */                  
  private void scanWords(Vector<Word> foundWords, String prefix, String text)
  {                            
    String[] w = WordTokenizer.extractWords(text);

    for(int i=0; i<w.length; i++)
    {
      
      Word word = this.getWord_using_alternatives(prefix, w[i]);
      if(word!=null)      
      {
        foundWords.add(word);
      }
      else
      {      
        this.notFoundWords++;
        // word not found...
        // has a spam prob of 0.4
        Word wo = new Word(prefix+normalize(w[i]));
        wo.setSpamProb(0.4);
        foundWords.add(wo);
        
        //System.out.println("Not found: "+wo.word);
      }  
    }
  }

  private void scanHTML(Vector<Word> foundWords, String htmlText)
  {
    try
    { 
      // 1) html text content
      HTMLTextExtractor he = new HTMLTextExtractor(htmlText, false);
      String[] w = WordTokenizer.extractWords(he.getTextOnly());

      for(int i=0; i<w.length; i++)
      {
        Word word = this.getWord_using_alternatives("", w[i]);
        if(word!=null)
        {
          foundWords.add(word);
        }
        else
        {
          // word not found...
          // has a spam prob of 0.4
          this.notFoundWords++;
          Word wo = new Word(normalize(w[i]));
          wo.setSpamProb(0.4);
          foundWords.add(wo);
        }
      }

      // 2) unknown tags
      Vector<String> tags = he.getUnknownTags();
      for(int i=0; i<tags.size(); i++)
      {
        String[] wt = WordTokenizer.extractWords((String) tags.elementAt(i));
        for(int t=0; t<wt.length; t++)
        {
          String wtt = normalize(wt[t]);
          Word word = this.getWord_using_alternatives("tag*", wtt);
          if(word!=null)
          {
            foundWords.add(word);
          }
          else
          {
            this.notFoundWords++;
            // tag not found...
            // unknown (invalid!) tags has a predisposition to be spam
            Word wo = new Word("tag*"+wtt);
            wo.setSpamProb(0.95);
            foundWords.add(wo);
          }
        }
      }

      // 3) hrefs
      Vector<String> hrefs = he.getLinksHREFs();
      for(int i=0; i<hrefs.size(); i++)
      {   
        this.scanWords(foundWords, "href*", (String) hrefs.elementAt(i));
      }

      // 4) images
      Vector<String> images = he.getImageSrcs();
      for(int i=0; i<images.size(); i++)
      {
        this.scanWords(foundWords, "img*", (String) images.elementAt(i));
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }


  private void scanWordsRecurse(Vector<Word> foundWords, MimePart part)
  {             
    if(part.isLeaf())
    {     
      if(part.getContentTYPE() == MimePart.ContentType.TEXT)
      {
        if(part.lookIfContentIsHTML())
        {
          this.scanHTML(foundWords, part.getBodyAsText());
        }
        else
        {
          this.scanWords(foundWords, "", part.getBodyAsText());
        }
      }      
      else
      {
      }
    }
    else          
    {
      for(int i=0; i<part.getChildCount(); i++)
      {
        scanWordsRecurse(foundWords, part.getPartAt(i));
      }
    }
  }

                            

  /** used to train the filter.
      adds the words to the stat.
      Look in the header, body and attachments...
  */
  public void addMessageToStat(MailMessage mess)
  {
    // is it spam or not ??
    boolean isSPAM = mess.getIsSPAM();

    //if neither spam or ham, unclassified message doesn't participate to stat
    if( !isSPAM && !mess.getIsHAM() )
    {
      nUnclassedMails++;
      return;
    }



    // For the global counting
    if(isSPAM)
    {
      nSpamMails++;
    }
    else
    {
      nHamMails++;
    }

    // add header
    Header head = mess.getHeader();
    for(int i=0; i<head.getEntriesCount(); i++)
    {
      HeaderEntry he = head.getEntryAt(i);                                                                                                            
      addTextToStat(he.getKey().toLowerCase()+"*", he.getValue(), isSPAM );
    }
    
    // add multipart & attachment (###)
    if(MimeUtils.isMultipart(mess))
    {       
      MimeTreeModel mimeTree = mess.getMimeTree();
      MimePart mp = mimeTree.getRootPart();
      addMimePartToStatRecurse(mp, isSPAM);
    }
    else
    {
      addTextToStat("", mess.getMessageBody(), isSPAM);
    }
  }

  
  private int minWordLength = 1;
  
  /** adds normal unformatted text to the stat.
  */
  private void addTextToStat(String prefix, String text, boolean isSPAM)
  {
    String[] w = WordTokenizer.extractWords(text);

    for(int i=0; i<w.length; i++)
    {
      String wi = prefix+normalize(w[i]);
      Word word = this.getWordExact(wi);                                                         
      if(word==null)     
      {
        word = new Word(wi);
        if(word.word.length() >= minWordLength)
        {
          addWord(word);
        }
      }

      if(isSPAM)
      {
        word.addSpamOccurence();
      }
      else
      {
        word.addHamOccurence();
      }
    }
  }

  /** adds HTML formatted text to the stat.
  */
  private void addHTMLToStat(String htmlText, boolean isSPAM)
  {
    try
    {              
      HTMLTextExtractor he = new HTMLTextExtractor(htmlText, false);
      this.addTextToStat("", he.getTextOnly(), isSPAM);
                        
      // bad tags                     
      Vector<String> ut = he.getUnknownTags();
      for(int i=0; i<ut.size(); i++)
      {
         this.addTextToStat("tag*", (String) ut.elementAt(i), isSPAM);
      }                         

      // links
      Vector<String> refs = he.getLinksHREFs();
      for(int i=0; i<refs.size(); i++)
      {                        
         this.addTextToStat("href*", (String) refs.elementAt(i), isSPAM);
      }

      // images
      Vector<String> images = he.getImageSrcs();
      for(int i=0; i<images.size(); i++)
      {                 
         this.addTextToStat("img*", (String) images.elementAt(i), isSPAM);
      }

    }
    catch(Exception e)
    {
      e.printStackTrace();  // should not occur...
    }

    // ###
  }

  /** adds the text and HTML...
  */    
  private void addMimePartToStatRecurse(MimePart part, boolean isSPAM)
  {
    if(part.isLeaf())
    {
      // analyse part
      if(part.getContentTYPE()== MimePart.ContentType.TEXT)
      {
        if(part.lookIfContentIsHTML())
        {
          this.addHTMLToStat(part.getBodyAsText(), isSPAM);
        }
        else
        {
          this.addTextToStat("", part.getBodyAsText(), isSPAM);
        }
      }
      else
      {
        // not text...
        // ### add attachment name, ...
      }
    }
    else
    {
      // recurse
      for(int i=0; i<part.getChildCount(); i++)
      {
        addMimePartToStatRecurse(part.getPartAt(i), isSPAM);
      }
    }
  }
  
  // Utils
  //    

                               
  public void exportStatToFile(File f) throws Exception
  {
    Vector<Word> words = new Vector<Word>();
    Enumeration<Word> enume = wordsHashtable.elements();
    while(enume.hasMoreElements())
    {
      words.add(enume.nextElement());
    }
    Collections.sort(words);
                    
                    
    FileOutputStream fos = null;
    PrintWriter pw = null;
    try
    {
      fos = new FileOutputStream(f);
      pw = new PrintWriter(fos);

      pw.print(""+this.toStringStat()+"\n\n");

      for(int i=0; i<words.size(); i++)
      {
         Word wi = words.elementAt(i);
         pw.println(""+wi.word+"\t"+wi.getSpamProb()); //+"\t"+wi.occurencesInSPAM+"\t"+wi.occurencesInHAM);
      }
    }
    catch(Exception e)
    {
      throw e;
    }
    finally
    {
      if(pw!=null) pw.close();
      if(fos!=null) fos.close();
    }
  }

    /**  Either 
          Hello, hello: ok
          hELLo => hELLO
          hello!!!!! => hello#
    */
    public static String normalize(String s)
    {
      if(s.length()<2) return s;
                  
      StringBuffer normalized = new StringBuffer();
      
      boolean hasLow = false;
      boolean hasUp  = false;
      boolean hasDigits  = false;
      boolean hasSpecial  = false;

      for(int i=1; i<s.length(); i++)
      {             
        char ci = s.charAt(i);
        if(Character.isLowerCase(ci))
        {
          hasLow = true;
          normalized.append(ci);
        }
        else if(Character.isUpperCase(ci))
        {
          hasUp = true;         
          normalized.append(ci);
        }
        else if(Character.isDigit(ci))
        {
          hasDigits = true;     
          normalized.append(ci);
        }
        else if(ci=='.')
        {
          // let them, they are constituents of IP's
          normalized.append(ci);
        }
        else
        {
          hasSpecial = true;    
          // forget the special chars
        }
      }

      if(hasSpecial)
      {
        normalized.append('#');
      }

      // look at the first char

      if( Character.isUpperCase(s.charAt(0)) )
      {
        if(hasUp)
        {
          // BuG => BUG
          return s.charAt(0) + normalized.toString().toUpperCase();
        }
        else
        {
          // Bug
          return s.charAt(0) + normalized.toString();
        }
      }
      else if( Character.isLowerCase(s.charAt(0)) )
      {
        if(hasUp)
        {
          // mismatch like bUg => bUG
          return Character.toUpperCase(s.charAt(0)) + normalized.toString().toUpperCase();
        }
        else
        {
          // bug
          return s.charAt(0) + normalized.toString();
        }
      }
      else  
      {
         //  
      }


      return s.charAt(0) + normalized.toString();
    }

  // Vectorizable
  //

  public Vector<Object> getVectorRepresentation() throws VectorizeException
  {
     Vector<Object> v = new Vector<Object>();

     v.addElement(2); // 0: version
     String[] wl = new String[wordsHashtable.size()];
     int[] occHam = new int[wordsHashtable.size()];
     int[] occSpam = new int[wordsHashtable.size()];

     int i=0;
     Enumeration words = this.wordsHashtable.elements();
     while(words.hasMoreElements())
     {
        Word w = (Word) words.nextElement();
        wl[i] = w.word;
        occHam[i] = w.getHamOccurences();
        occSpam[i] = w.getSpamOccurences();
        i++;
     }
     v.addElement(wl);     // 1
     v.addElement(occHam);
     v.addElement(occSpam);  
     v.addElement(this.nHamMails);     // 4   // storing raw arrays is much more faster than making vectors with their elements !
     v.addElement(this.nSpamMails);
     v.addElement(this.nUnclassedMails);  // 6

     return v;
  }

  public void createFromVectorRepresentation(Vector<Object> v) throws VectorizeException
  {
    int version = ((Integer)v.elementAt(0)).intValue();
    if(version==2)                         
    { 
      this.deleteStatistic();
      
      String[] wl = (String[]) v.elementAt(1);  
      int[] occHam = (int[]) v.elementAt(2);
      int[] occSpam = (int[]) v.elementAt(3);
      if(v.size()>4)
      {
        nHamMails = (Integer) v.elementAt(4);
        nSpamMails = (Integer) v.elementAt(5);
      }
      if(v.size()>6)
      {
        nUnclassedMails = (Integer) v.elementAt(6);
      }

      for(int i=0; i<wl.length; i++)
      {                             
        Word w = new Word(wl[i], occHam[i], occSpam[i]);
        addWord(w);    
      }                     

      buildStatistics(null);      
    }
    else                 
    {
      throw new VectorizeException("Bad vectorized Word version "+version);
    }
  }

/* TODO: visually similar character recognition for approximate matching !
   IDEA2: Keyboard distance ?
   IDEA3: Phonetic distance (soundex) ?

   Classification: ( => Automatic ?)

   abcdefghijklmnopqrstuvwxyz1234567890
   ABCDEFGHIJKLMNOPQRSTUVWXYZ

   a c e o 0 O C D G Q 

   b d h k

   f i l r s t I J L T 1 2 7  

   g j p q y Y 9  
                     
   m w M W

   n u v N U V

   x z X Z

   4 5 6 7

   A B E F H K P R S 3 8 


*/

} // Word
