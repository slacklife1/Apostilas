package SnowMailClient.SpamFilter;

import snow.SortableTable.*;
import snow.lookandfeel.*;
import SnowMailClient.model.MailMessage;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.SpamFilter.*;
import SnowMailClient.view.FolderView;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.beans.*;
                
/** DefaultTableCellRenderer seems not to like transparent bg ???
 ### can be optmized for performance...
*/                          
public final class SpamStatTableCellRenderer extends JLabel implements TableCellRenderer
{
  Font normalFont, boldFont;
  FolderView folderView;
  SortableTableModel sortableTableModel;
                      
  private Color unknownBackground   = new Color(180,180, 250);  // TextField.ba
                                  

  public SpamStatTableCellRenderer(FolderView folderView,
                                     SortableTableModel sortableTableModel )
  {
    super();
    this.folderView = folderView;
    this.sortableTableModel = sortableTableModel;

    setup();
  } // Constructor

  /**
   * Notification from the <code>UIManager</code> that the look and feel
   * [L&F] has changed.
   * Replaces the current UI object with the latest version from the
   * <code>UIManager</code>.
   */
  public void updateUI()
  {
     super.updateUI();
     setup();
  }

  private void setup()
  {
     normalFont = UIManager.getFont("Label.font");
     int fontSize = normalFont.getSize();
     boldFont = new  Font(normalFont.getFontName(), Font.BOLD, fontSize+2);
     Border emptyBorder = new EmptyBorder(fontSize/4, fontSize/2, fontSize/4, fontSize/2);
     this.setBorder(emptyBorder);

  }

  public Component getTableCellRendererComponent(
         JTable table, Object value, boolean isSelected, boolean hasFocus,
         int row, int column)
  {
     this.setText(value.toString());

     int ind = sortableTableModel.getIndexInUnsortedFromTablePos(row);
     boolean newMail = false;

     MailMessage mess = this.folderView.getMailFolder().getMessageAt(ind);
     newMail = mess.getIsNew();

     // selection
     if(isSelected && column!=5 && column!=0)
     {
        setBackground(UIManager.getColor("Tree.selectionBackground"));
        setOpaque(true);
     }
     else
     {
        setOpaque(false);
        if(column==0)
        {          
          // from background => spam or white list info
          String from = mess.getFromAddress().getMailAddress();
          if(SnowMailClientApp.getInstance().getAddressBook().getAddress(from)!=null)
          {
             if(isSelected)
             {
               setBackground(ThemesManager.getInstance().getGreen().darker());
             }
             else
             {
               setBackground(ThemesManager.getInstance().getGreen());
             }
             setOpaque(true);
          }
          else if(SnowMailClientApp.getInstance().getSpamBook().getAddress(from)!=null)
          {
             if(isSelected)     
             {
               setBackground(ThemesManager.getInstance().getRed().darker());
             }
             else
             {
               setBackground(ThemesManager.getInstance().getRed());
             }
             setOpaque(true);
          }
          else
          {
             if(isSelected)
             {       
               setBackground(UIManager.getColor("Tree.selectionBackground"));
               setOpaque(true);
             }
             else
             {
               setOpaque(false);
             }
          }
        }
        else if(column==5)     // spam filter 
        {
          setText("");                            
          double prob = mess.getSPAMProbability();
          if(WordStatistic.isSpam(prob))
          {
             if(isSelected)
             {
               setBackground(ThemesManager.getInstance().getRed().darker());
             }
             else
             {
               setBackground(ThemesManager.getInstance().getRed());
             }                        
             setOpaque(true);
          }
          else
          {
             setOpaque(false);
          }

        }
     }

     if(newMail)
     {
       setFont(this.boldFont);
     }                        
     else
     {
       this.setFont(normalFont);
     }    
     return this;
  }



}// SpamStatTableCellRenderer
