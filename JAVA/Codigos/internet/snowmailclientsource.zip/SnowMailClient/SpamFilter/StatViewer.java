package SnowMailClient.SpamFilter;

import snow.SortableTable.*;
import snow.utils.gui.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import SnowMailClient.Language.*;
import SnowMailClient.*;
import java.util.*;

public final class StatViewer extends JDialog
{
  final private JTable table = new JTable();
  final private SortableTableModel sortableTableModel;
  final private Hashtable<String,Word> wordsTable = SnowMailClientApp.getInstance().getWordStatistic().getAllWords();
                        
  public final static String TITLE = Language.translate("SPAM Statistics");

  public StatViewer(JFrame parent)
  {
    super(parent, TITLE, true);
    getContentPane().setLayout(new BorderLayout());

    // Center

    sortableTableModel = new SortableTableModel(new SpamStatTableModel(wordsTable));
    table.setModel(sortableTableModel);
    sortableTableModel.installGUI(table);
    this.getContentPane().add(new JScrollPane(table), BorderLayout.CENTER);

    // Search
    AdvancedSearchPanel searchPanel = new AdvancedSearchPanel(Language.translate("Search")+": ", null, sortableTableModel, true);
    this.getContentPane().add(searchPanel, BorderLayout.NORTH);

    // Close Panel
    CloseControlPanel ccp = new CloseControlPanel(this, false, true, Language.translate("Close"));
    this.getContentPane().add(ccp, BorderLayout.SOUTH);
    
    updateTitleLabel();
    
    SnowMailClientApp.getInstance().getProperties().setComponentSizeFromINIFile(
      this, "SpamStatViewer", 340,600, 200,100);
    setVisible(true);
    SnowMailClientApp.getInstance().getProperties().saveComponentSizeInINIFile(this, "SpamStatViewer");
  } // Constructor


  private void updateTitleLabel()
  {
    String hitString = (sortableTableModel.getRowCount()<wordsTable.size() ?
         " ("+sortableTableModel.getRowCount()+" "+Language.translate("hits")+")"
        :"");
    setTitle(TITLE+" ["+wordsTable.size()+" "+Language.translate("words")+"]"+hitString);
  }


} // StatViewer
