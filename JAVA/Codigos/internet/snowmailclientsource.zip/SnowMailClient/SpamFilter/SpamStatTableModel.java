package SnowMailClient.SpamFilter;

import snow.SortableTable.*;
import SnowMailClient.Language.*;
import javax.swing.table.*;
import java.util.*;
import java.text.DecimalFormat;
                               
public final class SpamStatTableModel extends FineGrainTableModel
{
  static final private String[] COLUMN_NAMES = new String[]{
    Language.translate("Word"),          
    Language.translate("SPAM probability"),
    Language.translate("Ham occurences"),
    Language.translate("SPAM occurences")
    };

  final private Vector<Word> words = new Vector<Word>();

  final private DecimalFormat df = new DecimalFormat("0.00000");

  public SpamStatTableModel(Hashtable<String,Word> wordsTable)
  {
    words.addAll(wordsTable.values());
  } // Constructor



  public final int getRowCount() {return words.size();}
  public final int getColumnCount() {return 4;}

  public final Word getWordAt(int pos)
  {
    return (Word) words.elementAt(pos);
  }
                                    
  
  public final Object getValueAt(int row, int column)
  {
    Word w = getWordAt(row);
    if(column==0) return w.word;
    if(column==1) return df.format(w.getSpamProb());
    if(column==2) return w.getHamOccurences();
    if(column==3) return w.getSpamOccurences();


    return "?";
  }

  public final int compareForColumnSort(int pos1, int pos2, int col)
  { 
    if(col==1)
    {
      Word w1 = getWordAt(pos1);
      Word w2 = getWordAt(pos2);
      return this.compareDoubles(w1.getSpamProb(), w2.getSpamProb());
    }
    else
    {
      return super.compareForColumnSort(pos1,pos2,col);
    }
  }

  public final String getColumnName(int col)
  {
    return COLUMN_NAMES[col];
  }

} // SpamStatTableModel
             
