package SnowMailClient.MailEngine;

import java.security.*;
import java.security.cert.*;

import javax.net.ssl.*;

/** NOT USED !!!
*/
public final class MyX509TrustManager implements X509TrustManager
{

    public MyX509TrustManager()
    {
    }

    public void checkClientTrusted(X509Certificate[] chain,
                                   String authType)
    {
      System.out.println("checkClientTrusted()");
      System.out.println("Auth type="+authType);

    }

    public void checkServerTrusted(X509Certificate[] chain,
                                   String authType)
                                   throws CertificateException
    {
      System.out.println("checkServerTrusted()");
      System.out.println("Auth type="+authType);
    }

    public X509Certificate[] getAcceptedIssuers() {
        return new X509Certificate[]{};
    }
}                      

 // MyX509TrustManager
