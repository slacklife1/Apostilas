package SnowMailClient.MailEngine.transfer;

import SnowMailClient.SnowMailClientApp;
import SnowMailClient.model.*;
import SnowMailClient.model.accounts.*;
import SnowMailClient.model.folders.*;
import SnowMailClient.utils.storage.*;
import SnowMailClient.utils.*;
import snow.utils.gui.*;
import snow.SortableTable.*;
import SnowMailClient.Language.Language;

import java.util.*;
import java.text.*;
import javax.swing.table.*;
import javax.swing.*;
import java.awt.*;

/**
*/
public final class MailTransferModel extends FineGrainTableModel
{
  private final Vector<TransferItem> transferItems = new Vector<TransferItem>();
  private boolean hasBeenChangedByUser = false;
  private static final String[] COLUMN_NAMES = new String[] {
    Language.translate("Type"),
    Language.translate("Account"),
    Language.translate("Mails"),
    Language.translate("Progress")
  };

  private int[] COLUMN_PREFERED_SIZES = new int[] { 4, 18, 4, 6 };

  public enum TransferType { Send, Receive, SendAndReceive }

  public MailTransferModel(MailAccounts mac, TransferType type)
  {
     super();

     // collect accounts to receive mails
     //
     for(int i=0; i<mac.getRowCount(); i++)
     {
       if(mac.getAccount(i).getUseToReadMails()
         && (type==TransferType.Receive || type==TransferType.SendAndReceive))
       {
          transferItems.add(new TransferItem(mac.getAccount(i), TransferItem.TransferType.Receive));
       }
     }

     // collect the mails in the outbox
     if(type==TransferType.Send || type==TransferType.SendAndReceive)
     {
       try
       {                                  
         Hashtable<MailAccount, Vector<MailMessage>> sendAccounts = new Hashtable();
         final MailFolder folder = SnowMailClientApp.getInstance().getFoldersModel().getOutboxFolder().getMailFolder();
         for(MailMessage _mess : folder.getAllMessages())
         {         
            MailMessage mess = _mess;
            String toAddress = mess.getToAddressesText();
            String fromMailAddress = mess.getFromAddress().getMailAddress();
            MailAccount account = mac.getMailAccount(fromMailAddress);
            
            if(!sendAccounts.containsKey(account))
            {
                sendAccounts.put(account, new Vector<MailMessage>());
            }                                           
            sendAccounts.get(account).add(mess);
         }
         
         for(MailAccount maco : sendAccounts.keySet())
         {
            TransferItem tri = new TransferItem(maco, TransferItem.TransferType.Send);
            tri.messagesToSend.addAll( sendAccounts.get(maco) );
            transferItems.add(tri);
         }
       }
       catch(Exception e)
       {
         e.printStackTrace();
       }
     }

     progress.setStringPainted(true);
  } // Constructor

             
  public String getColumnName(int col)
  {
     return COLUMN_NAMES[col];
  }
    
    
  public int getPreferredColumnWidth(int column)
  {
    if(column>=0 && column<COLUMN_PREFERED_SIZES.length) return COLUMN_PREFERED_SIZES[column];
    return -1;
  }

    
  public int getColumnCount() { return COLUMN_NAMES.length; }


  public int compareForColumnSort(int pos1, int pos2, int col)
  {
     return super.compareForColumnSort(pos1, pos2, col);
  } 
  
  public int getRowCount() { return transferItems.size(); }

  public Vector<TransferItem> getTransferItems()
  {
    return transferItems;
  }
  
  private final JProgressBar progress = new JProgressBar(0, 100);

  public Object getValueAt(int row, int col)
  {
    TransferItem dac = transferItems.elementAt(row);
    if(col==0)
    {
      if(dac.transferType == TransferItem.TransferType.Receive)
      {
        return Language.translate("Receive");
      }
      else
      {
        return Language.translate("Send");
      }
    }
    if(col==1) return dac.ma.getAddress();
    if(col==2)
    {
      if( dac.numberOfMailsToDownload==-1) return "";
      if( dac.numberOfMailsToDownload== 0) return Language.translate("-");
      return ""+dac.numberOfDownladedMails+" / "+dac.numberOfMailsToDownload;

    }
    if(col==3)
    {
      if(dac.error!=null) return Language.translate("Error") + ": " + dac.error.getMessage();

      if( dac.totalBytesToDownload==-1) return "";
      if( dac.totalBytesToDownload== 0)  return "";

      progress.setValue(  dac.totalDownloadedBytes *100 / dac.totalBytesToDownload);
      progress.setString(
      //MailMessageUtils.formatSize(dac.totalDownloadedBytes) + " / "
        MailMessageUtils.formatSize(dac.totalBytesToDownload));
      return progress;
    }
    return "?";
  }

  public void updateView()
  {
    EventQueue.invokeLater(new Runnable() { public void run() {
      fireTableModelWillChange();
      fireTableDataChanged();    
      fireTableModelHasChanged();
    }});
  }
  
  public void setTableRenderer(JTable table)
  {  
    CellRenderer dt = new CellRenderer();
    table.setDefaultRenderer(String.class, dt);
    table.setDefaultRenderer(Integer.class, dt);
    table.setDefaultRenderer(Component.class, dt);    
  }

  /** just allows JProgressBar to act as CellRenderer
  */
  class CellRenderer extends DefaultTableCellRenderer
  {
     public Component getTableCellRendererComponent(
                          JTable table, Object val, boolean sel, boolean foc, int row, int col)
     {
        if(val instanceof Component)
        {
          return (Component) val;
        }
        return super.getTableCellRendererComponent(table,val,sel,foc,row,col);
     }
  }

} // MailTransferModel
