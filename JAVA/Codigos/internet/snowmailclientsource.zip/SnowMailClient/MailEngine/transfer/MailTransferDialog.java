package SnowMailClient.MailEngine.transfer;

import SnowMailClient.MailEngine.*;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.model.*;
import SnowMailClient.model.accounts.*;
import SnowMailClient.model.folders.*;
import SnowMailClient.view.*;
import SnowMailClient.view.MessagesPreview.*;
import SnowMailClient.view.accounts.AccountsEditor;
import SnowMailClient.utils.NumberedLineReader;
import snow.utils.gui.*;
import snow.utils.ArrayUtils;

import snow.concurrent.*;
import snow.SortableTable.*;

import SnowMailClient.utils.*;
import SnowMailClient.view.dialogs.*;
import SnowMailClient.Language.Language;
import snow.lookandfeel.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.util.Vector;
import java.io.*;
import java.text.*;

public class MailTransferDialog extends JDialog
{
  final private CloseControlPanel ccp  = new CloseControlPanel(this, true, true, Language.translate("?"));
  final private MailTransferModel mailDownloadModel;
  final private SortableTableModel stm;
  final private JTable table;

  public boolean downloadTerminated = false;

  private final JTextArea errorTA = new JTextArea(3, 40);
  private MailFolder sentFolder, outboxFolder;

  private final AccountLog transferLog = new AccountLog();

  public MailTransferDialog(JFrame parent, MailTransferModel.TransferType type)
  {
     super( parent, Language.translate("Mail transfer"), true);
     this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

     FolderTreeNode sent   = SnowMailClientApp.getInstance().getFoldersModel().getSentFolder();
     FolderTreeNode outbox = SnowMailClientApp.getInstance().getFoldersModel().getOutboxFolder();

     try
     {
        sentFolder  = sent.getMailFolder();
        outboxFolder = outbox.getMailFolder();
     }
     catch(Exception ex)
     {
        ex.printStackTrace();
     } 

     this.mailDownloadModel = new MailTransferModel(SnowMailClientApp.getInstance().getAccounts(), type);
     this.stm = new SortableTableModel(mailDownloadModel);
     this.table = new JTable(stm);
     
     ToolTipManager.sharedInstance().registerComponent(table);

     if(mailDownloadModel.getTransferItems().size()==0)
     {                                  
       JOptionPane.showMessageDialog(SnowMailClientApp.getInstance(),
          Language.translate("There are no accounts to read mail from.\nActivate the checkbox read in the accounts editor."),
            Language.translate("No accounts to check"), 
          JOptionPane.INFORMATION_MESSAGE);
       downloadTerminated = true;
       return;
     }        
     
     stm.installGUI(table);
     mailDownloadModel.setTableRenderer(table);
     
     JTabbedPane tabbedPane = new JTabbedPane();
     JPanel centerPanel = new JPanel(new BorderLayout());
     tabbedPane.add(Language.translate("Transfer"), centerPanel);
     getContentPane().add(tabbedPane, BorderLayout.CENTER);
     centerPanel.add(new JScrollPane(table), BorderLayout.CENTER);
     centerPanel.add(errorTA, BorderLayout.SOUTH);                                                   
        
     errorTA.setEditable(false);  
     errorTA.setBorder(new EmptyBorder(3,3,3,3));
     errorTA.setForeground(Color.red);
                                               
     JTextPane logPane = new JTextPane(transferLog.doc);
     logPane.setEditable(false);
     tabbedPane.add(Language.translate("Log"), new JScrollPane(logPane) );

     ccp.getOkButton().setVisible(false);
     getContentPane().add(ccp, BorderLayout.SOUTH);
     
     table.getSelectionModel().addListSelectionListener(new ListSelectionListener()
     {  
        public void valueChanged(ListSelectionEvent lse)
        {
           int selrview = table.getSelectedRow();
           errorTA.setText("");
           errorTA.setVisible(false);
           if( selrview==-1)
           {
              return;
           }         
           int pos = stm.getIndexInUnsortedFromTablePos(selrview);
           if(pos==-1) return;
           TransferItem dac = mailDownloadModel.getTransferItems().elementAt(pos);
           if(dac.error!=null)
           {
              errorTA.setText(""+dac.error.getMessage());
              errorTA.setVisible(true);
              //Debug: dac.error.printStackTrace();
           }
           
           table.setToolTipText(dac.status.toString());
        }
     });

     this.addWindowListener(new WindowAdapter()
     {
       @Override public void windowClosing(WindowEvent we)
       {
         onClose();
       }
       @Override public void windowClosed(WindowEvent we)
       {
         onClose();
       }
     });
     
     Thread t = new Thread()
     {
       public void run()
       {
         // this waits until termination 
         errorTA.setVisible(false);
         startAllTransfers(); 
         mailDownloadModel.updateView();
                  
         downloadTerminated = true;
         
         // look if errors occured
         if(hasErrors())
         {
           // let the user close after looking at the errors
         }
         else
         {
           setVisible(false);
         }
       }
     };      
     t.setPriority(Thread.MIN_PRIORITY);
     t.start();
     
     int fs = UIManager.getFont("Label.font").getSize();
     SnowMailClientApp.getInstance().getProperties().setComponentSizeFromINIFile(this, "MailDownloadDialog",
          fs*45, fs*28, 10, 10);
     //pack();    
     setLocationRelativeTo(parent);
     setVisible(true); // Modal, but not always 
     
     
  } // Constructor
  
  private boolean hasErrors()
  {               
     for(TransferItem tri : mailDownloadModel.getTransferItems())
     {
        if(tri.error != null) return true;
     }
     return false;
  }

  /** parallel download AND wait until all terminated
  */
  private void startAllTransfers()
  {
    Vector<TransferItem> dacs = mailDownloadModel.getTransferItems();
    Vector<Thread> threads = new Vector<Thread>();
    for(TransferItem _dac : dacs)
    {
       final TransferItem dac = _dac;
       if(dac.transferType==TransferItem.TransferType.Receive)
       {
         Thread t = new Thread() { public void run() {
           downloadAllMails(dac);
         }};
         t.setPriority(Thread.NORM_PRIORITY-1);
         threads.add(t);
         t.start();
       }
       else if(dac.transferType==TransferItem.TransferType.Send)
       {
         Thread t = new Thread() { public void run() {
           sendAllMails(dac);
         }};
         t.setPriority(Thread.NORM_PRIORITY-1);
         threads.add(t);
         t.start();
       }

    }

    // wait for all
    for(Thread t: threads)
    {
       try{ t.join(); } catch(Exception e) {}
    }
  }
  
  /** send all the mails with the given account (one after each other)
  */
  private void sendAllMails(final TransferItem dac)
  {
      
        //
        transferLog.append("\r\n"+Language.translate("Sending % mails", ""+dac.messagesToSend.size()));
        dac.numberOfMailsToDownload = dac.messagesToSend.size();
        dac.totalDownloadedBytes = 0;
        dac.totalBytesToDownload = 0;
        dac.numberOfDownladedMails = 0;
        
        //MailMessage mess;
        for(MailMessage mess : dac.messagesToSend)
        {                                        
          // ### only approximatively the size to send
          dac.totalBytesToDownload += mess.getSize();
        }

        for(MailMessage mess : dac.messagesToSend)
        { 
          dac.numberOfDownladedMails++;

          Counter counter = new Counter()
          {
             public void increment(int count)
             {
                super.increment(count);
                dac.totalDownloadedBytes += count;
                mailDownloadModel.updateView();
             }
          };
          
          try
          {
             if(mess.getToAddresses().size()==0)
             {
                throw new Exception(Language.translate("The mail message has no destinee"));
             }
             transferLog.append("\r\n" + Language.translate("Sending message to %", ""+mess.getToAddresses()));
             dac.status.setLength(0);
             dac.status.append(Language.translate("Sending message to %", ""+mess.getToAddresses()));
             TransferFunctions.sendMail(mess, dac.interrupter, counter);
          }
          catch(Exception e)
          {
             dac.error = e;
             transferLog.appendError("\r\n"+Language.translate("Error")+": "+e.getMessage());
          }
        }

        // all sent
        //dac.totalDownloadedBytes = dac.totalBytesToDownload;

  }

  /** receive all the mails
  */
  private void downloadAllMails(final TransferItem dac)
  {
     try
     {
       SecurePopConnection sp = dac.ma.getCheckedPopConnection();  // must be retrieved and cached, the get looks if alive, sending NOOPs

       dac.numberOfMailsToDownload = sp.getNumberOfMessages()[0];
       dac.numberOfDownladedMails = 0;

       dac.totalBytesToDownload = sp.getNumberOfMessages()[1];
       dac.totalDownloadedBytes = 0;

       mailDownloadModel.updateView();

       String[] uidls  = sp.getMessagesUIDLs();
       int[] messSizes = sp.getSizes_from_MessagesLIST(sp.getMessagesLIST_());

    /*   if(uidls.length != messSizes.length)  // Fixed dec 2005
       {
         System.out.println( "UIDLS: "+ArrayUtils.toString(uidls) );
         System.out.println( "sizes: "+ArrayUtils.toString(messSizes) );
         throw new Exception("Internal error: bad UIDLs");
       } */

    ml:for(int i=0; i<messSizes.length; i++)
       {
          // get header...
          Header header = new Header();
          try
          {
            String str = sp.getMessageTop(uidls[i], 0);
            Header.parseHeader(new NumberedLineReader(str), header);
          }
          catch(Exception ignored)
          {
            // not so important...
          }

          String from    = header.getEntryValue("from",    "?");
          String to      = header.getEntryValue("to",      "?");
          String subject = header.getEntryValue("subject", "?");
          
          dac.status.setLength(0);
          dac.status.append(Language.translate("Receiving mail from %", from));
          
          // ask for large messages
          if(messSizes[i] > 100000) // 100k
          {
             int rep = JOptionPane.showConfirmDialog(SnowMailClientApp.getInstance(),
                Language.translate("The message")
                +"\n"+Language.translate("  from: %",from)
                +"\n"+Language.translate("  to: %",to)
                +"\n"+Language.translate("  subject: %",subject)
                +"\n"+Language.translate("has a size of %.\nDo you want to download it ?", MailMessageUtils.formatSize(messSizes[i])),
                Language.translate("Big message warning"),
                JOptionPane.YES_NO_OPTION);

             if(!(rep==JOptionPane.OK_OPTION))
             {
               dac.totalBytesToDownload -= messSizes[i];
               dac.numberOfMailsToDownload--;
               continue ml;  // go to the next message
             }
          }

          Counter counter = new Counter()
          {
             public void increment(int count)
             {
               super.increment(count);
               dac.totalDownloadedBytes += count;
               mailDownloadModel.updateView();
             }
          };
          dac.numberOfDownladedMails++;
          String messContent = sp.getMessage(uidls[i], dac.interrupter, counter);
          mailDownloadModel.updateView();

          final MailMessage mess = new MailMessage();
          mess.parse(messContent);

          transferLog.append("\r\nReceived: "+mess.getFromAddress()+" to "+mess.getToAddresses());

          addReceivedMessage(mess);
          // read and add was successful => delete from server
          if(true)
          {
             sp.deleteMessage(uidls[i]);
          }
       }

       // terminated
       dac.totalDownloadedBytes = dac.totalBytesToDownload;
     }
     catch(Exception e)
     {
       dac.error = e;
       transferLog.appendError("\r\n"+Language.translate("Error")+": "+e.getMessage());
     }
  }

  /** also calculate the spam prob and increment the stats of senders
  */
  private void addReceivedMessage(final MailMessage mess) throws Exception
  {
     try
     {
       double p = SnowMailClientApp.getInstance().getWordStatistic().calculateSpamProbability(mess).getProbability();
       mess.setSPAMProbability(p);
     }
     catch(Exception es)
     {
       es.printStackTrace();
     }

     mess.setHasBeenReceived(true);
     mess.setEditable(false);

     final MailFolder mf = SnowMailClientApp.getInstance().getFoldersModel().getInboxFolder().getMailFolder();
     EventQueue.invokeLater(new Runnable()
     {
       public void run()
       {
         mf.addMessage(mess);
       }
     });

     // increment the number of mails received from IF the address is in the book
     SnowMailClientApp.getInstance().getAddressBook().incrementMailsReceivedFromIfPresent( mess.getFromAddress() );
     SnowMailClientApp.getInstance().getSpamBook().incrementMailsReceivedFromIfPresent( mess.getFromAddress() );

  }

  /** called when the dialog closes. either on normal close or when cancell was pressed
  */
  private void onClose()
  {
     SnowMailClientApp.getInstance().getProperties().saveComponentSizeInINIFile(this, "MailDownloadDialog");
     ToolTipManager.sharedInstance().unregisterComponent(table);
     downloadTerminated = true;

     if(ccp.getWasCancelled())
     {
        // stop all process !!
        for(TransferItem dac : this.mailDownloadModel.getTransferItems())
        {
           Process p = dac.interrupter.process;
           if(p != null)
           {
              try{ p.destroy(); }  catch(Exception e) {}
           }
           dac.interrupter.stopEvaluation();
        }
     }
  }

}
