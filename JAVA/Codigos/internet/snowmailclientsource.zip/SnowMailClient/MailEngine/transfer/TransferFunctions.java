package SnowMailClient.MailEngine.transfer;

import SnowMailClient.model.folders.*;
import SnowMailClient.model.accounts.*;
import SnowMailClient.model.*;
import snow.utils.gui.*;
import snow.concurrent.*;
                           
import SnowMailClient.MailEngine.*;                           
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.view.folders.*;
import SnowMailClient.view.FolderView;
import SnowMailClient.Language.Language;
import SnowMailClient.GnuPG.*;
import SnowMailClient.GnuPG.model.GnuPGKeyID;

import java.awt.*;         
import java.util.*;
import java.awt.event.*;     
import javax.swing.*; 
import javax.swing.event.*;   
import javax.swing.tree.*; 


public class TransferFunctions
{

  private TransferFunctions()
  {

  } // Constructor

  /** send the mail and put it in the sent folder (if succeded)
  */
  public static void sendMail(final MailMessage mess, Interrupter interrupter, Counter counter) throws Exception
  {      
    // just a little check     
    if( SwingUtilities.isEventDispatchThread())
    {
       new Throwable("Must be called from another thread than EDT").printStackTrace();
    }
    SnowMailClientApp.getInstance().saveAllMails(false);


    SecureSmtpConnection ssmtp = null;
               
    try
    {
       String fromMailAddress = mess.getFromAddress().getMailAddress();
       MailAccount account = SnowMailClientApp.getInstance().getAccounts().getMailAccount(fromMailAddress);
       if(account==null)
       {
         throw new Exception(Language.translate("No mail account found to send message, use a valid from address"));
       }

       if(mess.getMustBeSigned())
       {
         try
         {
           MessageActions.prepare_Signing_Mail(mess, interrupter);
         }
         catch(Exception e)
         {
           throw e;
         }
       }

       if(mess.getMustBeEncrypted())
       {                                    
         try
         {
           MessageActions.prepareEncryptMail(mess);
         }
         catch(Exception e)
         {
           throw e;
         }
       }

       ssmtp = account.getSMTPConnection();

       //progressDialog.setMessageProgressActive(mess.getSize());
       ssmtp.sendMessage( mess, interrupter, counter );

       // no more bold in views, no more editable
       mess.setIsNoMoreNew();
       //mess.setHasBeenSent(true);
       mess.setEditable(false);


       EventQueue.invokeLater(new Runnable()
       {
         public void run()
         {
           try
           {
              SnowMailClientApp.getInstance().getFoldersModel().getSentFolder().getMailFolder().addMessage(mess);
              // remove after successful add.
              SnowMailClientApp.getInstance().getFoldersModel().getOutboxFolder().getMailFolder().removeMessage(mess);
           }
           catch(Exception e)
           {
              JOptionPane.showMessageDialog(SnowMailClientApp.getInstance().getContentPane(),
                ""+e.getMessage(),
                Language.translate("Cannot move mail message from outbox to sent folder."
                +"\nHowever, the message was succesfully sent."),
                JOptionPane.ERROR_MESSAGE);
              e.printStackTrace();
           }
         }
       });

       // add the address to the book
       for(Address a : mess.getToAddresses())
       {
         SnowMailClientApp.getInstance().getAddressBook().incrementMailsSendedTo( a );
       }       

    }
    catch(Exception e)
    { 
      throw e;
    }
    finally
    {
      if(ssmtp!=null)
      {
        try
        {
          ssmtp.terminateSession();
        }
        catch(Exception bof) {}
      } 
    }
  }
    



} // TransferFunctions
