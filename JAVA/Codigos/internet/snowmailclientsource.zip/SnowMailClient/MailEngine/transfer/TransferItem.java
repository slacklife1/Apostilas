package SnowMailClient.MailEngine.transfer;

import SnowMailClient.model.accounts.*;
import SnowMailClient.model.MailMessage;
import snow.concurrent.*;
import java.util.*;

/** Wraps a mail account to send of receive mails...
*/
public class TransferItem
{
               
     public final MailAccount ma;
     public int numberOfMailsToDownload = -1;
     public int numberOfDownladedMails  = -1;
     
     public int totalBytesToDownload = -1;
     public int totalDownloadedBytes = -1;
     
     public Throwable error = null;
     
     final public Interrupter interrupter = new Interrupter();
     
     public enum TransferType { Receive, Send }
     final public TransferType transferType;
     
     final public Vector<MailMessage> messagesToSend = new Vector<MailMessage>();
     public final StringBuffer status = new StringBuffer();

     protected TransferItem(MailAccount ma, TransferType type)
     {
        this.ma = ma;                                             
        this.transferType = type;
     }
     
     
} // TransferItem
