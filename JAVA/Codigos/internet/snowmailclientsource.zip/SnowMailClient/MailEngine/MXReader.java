package SnowMailClient.MailEngine;


import javax.naming.*;
import javax.naming.directory.*;
import java.net.*;
import java.util.*;


public final class MXReader
{


  public static final Vector<MXRecord> getMXRecordWithoutCache(String domainName) throws Exception
  {
     final Vector<MXRecord> records = new Vector<MXRecord>();

     DirContext ictx = new InitialDirContext();
     Attributes attributes = ictx.getAttributes("dns:/"+domainName, new String[] {"MX"});
     if (attributes != null)
     {
       NamingEnumeration attribNames = attributes.getIDs();
       while (attribNames.hasMore())
       {
          String name = (String) attribNames.next();
          Attribute attr = attributes.get(name);
          System.out.println(attr);
          for(int i=0; i<attr.size(); i++)
          {
            Scanner s = new Scanner(""+attr.get(i));
            int priority = s.nextInt();
            String server = s.next();
            if(server.endsWith(".")) server = server.substring(0, server.length()-1);
            records.add( new MXRecord(priority, server) );              
          } 
       }
     }                         
     
     Collections.sort( records );

     return records;
  }
  
  
  public static void main(String[] a)
  {
    try
    {
      System.out.println( getMXRecordWithoutCache("gmx.ch") );
      System.out.println( getMXRecordWithoutCache("bluewin.ch") );
      System.out.println( getMXRecordWithoutCache("snowraver.org") );
    } 
    catch(Exception e)
    {
      e.printStackTrace();
    }                         
  }

  public final static class MXRecord implements Comparable
  {
     final public int priority;
     final public String server;

     public MXRecord(int priority, String server)
     {
       this.priority = priority;
       this.server = server;
     }

     public final int compareTo(Object o)
     {
       MXRecord mr = (MXRecord) o;
       if(mr.priority > priority) return 1;
       if(mr.priority < priority) return -1;
       return 0;
     }
     
     public String toString()
     {
       return server+" ("+priority+")";
     }
  }


} // MXReader
