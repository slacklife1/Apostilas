package SnowMailClient.MailEngine;


import SnowMailClient.crypto.*;
import SnowMailClient.utils.*;
import snow.utils.gui.*;
import snow.crypto.*;
import snow.concurrent.*;
import SnowMailClient.model.*;
import SnowMailClient.model.accounts.*;
import SnowMailClient.Language.Language;


import java.io.*;
import java.net.*;
import javax.net.ssl.*;

import javax.swing.JProgressBar;
import javax.swing.SwingUtilities;
import java.util.Vector;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.concurrent.*;

/**
 *  basic POP3 reader + snowraver SPAS autentication + crypto
 *  and also a non secure standard mode.
 *  manages the connection to a mail account
 */
public final class SecurePopConnection
{             
  final private MailAccount mailAccount;
  final private AccountLog accountLog;
  final private String username;
  final private String password;

  private Socket connection;
  private boolean secure;
                                    
  private OutputStreamWriter out = null;
  private BufferedReader in = null;
  private byte[] pass = null;    

  /** at the beginning, encrypt is false, it is turned on after a successful SPAS
     login on snowserver */
  private boolean encryptNow = false;

  // access to ADUR, STOP, GELO    commands
  private boolean adminPrivileges = false;                                                      

  private final static boolean debug = false;
                         
  // store the message UIDL's (used to identify a message rather than the message number)
  // this database is updated at connection update (each login)
  private final LinkedHashMap<String, Integer> messageUIDLs = new LinkedHashMap<String, Integer>();
  
  private boolean sslMode = false;  



  /** initialize a new session
   *  handshake with SPAS if secure mode or USER/PASS of the last century of primitive hello world programmers
   *  parameters are taken from the mailAccount settings.
   *
   * it also directly test for new message, retriving all the UIDL's
   */
  public SecurePopConnection(MailAccount mailAccount) throws Exception
  {
      this.mailAccount = mailAccount;

      this.accountLog = mailAccount.getAccountLog();
      this.username   = mailAccount.getAccountUserName();
      this.password   = mailAccount.getAccountPassword();
      this.secure     = mailAccount.isSnowraverAccount();//securePasswordProtocolSnowRaver;
      this.sslMode    = mailAccount.useSSLPOP();
      
      
      if(sslMode)
      {  
        try
        {
           accountLog.appendComment("\n"
             +Language.translate("Opening new connection to SSL POP Server %1 on port %2",mailAccount.getPop(),""+mailAccount.getSSLPopPort()));
           accountLog.appendComment("=========== "+(new Date())+" ==========");
           connection = SSLConnection.createSSLConnection(mailAccount.getPop(), mailAccount.getSSLPopPort());
        }
        catch(Exception e)
        {                             
           //e.printStackTrace();
           accountLog.appendError(Language.translate("Error")+":"+e.getMessage());
           throw e;       
        }                        

      }
      else
      {  
        // normal mode, NO ssl
        try
        {
           accountLog.appendComment("\n"
             +Language.translate("Opening new connection to POP Server %1 on port %2",mailAccount.getPop(),""+mailAccount.getPopPort()));
           connection = new Socket(mailAccount.getPop(), mailAccount.getPopPort());
           connection.setSoTimeout(1000*60);
           accountLog.appendComment("=========== "+(new Date())+" ==========");
        }
        catch(Exception e)
        {
           accountLog.appendError(Language.translate("Error")+": "+e.getMessage());
           throw new Exception(Language.translate("Cannot connect to %",mailAccount.getPop()));
        }
      }      

      out = new OutputStreamWriter(connection.getOutputStream()); //, "utf-8");
      in = new BufferedReader( new InputStreamReader(connection.getInputStream())); // , "utf-8"));

      //greetings
      String line = readOneLineFromServer();
      if(!line.toLowerCase().startsWith("+ok")) 
         throw new Exception(Language.translate("Bad POP3 Greetings, awaiting +OK*, reveived")+" "+line);

      // read timestamp
      String timestamp = null;
      int pos = line.indexOf("<");
      if(pos !=- 1)
      {
        timestamp = line.substring(pos).trim();
        // secure case, verify that this stamp is not trivial... ###
        if(secure)
        {
           if(timestamp.length()<3) 
             throw new Exception("Too short timestamp, security leak because replay attack possible ? "+timestamp);
        }
      }
      else
      {
        if(secure)
        {
           throw new Exception("No timestamp in the greeting, secure mode not possible..., \nwaiting +OK* <xxxx.xxxx>, received "+line);
        }
      }

      if(secure)
      {
         String secPass = Utilities.hashPassword(timestamp+Utilities.hashPassword(password));
         String secUser = Utilities.hashPassword(username);

         sendOneLineToServer("SPAS "+secUser+" "+secPass);
         line = readOneLineFromServer();
         if(!line.toLowerCase().startsWith("+ok"))
         {
            throw new BadPasswordException("Secure SPAS failled,\n"+line);
         }

         adminPrivileges = line.endsWith("admin");

         // from now, everything is encrypted with the password hash that is our shared
         // secret with the server.         
         byte[] hash = Utilities.hashPassword(password).getBytes();
         pass = new byte[16];
         System.arraycopy(hash, 0, pass, 0,16);
         encryptNow = true;
      }
      else
      {
         // no security mode, send password and username as text over the net !
         logUsingAuthentication();
      }

      retrieveMessagesUIDL();
  }   
  
  
  /** explain what the status is
  */
  public String getConnectionStatusExplanation()
  {          
     StringBuffer sb = new StringBuffer();
     sb.append(Language.translate("POP Connection status")+":");
     sb.append("\n   Connected to " +connection.getInetAddress()
          +", port "+connection.getPort()+", local port="+connection.getLocalPort());
     if(this.sslMode)
     {     
       sb.append("\n   +++ SSL mode is active.");
       if(this.connection instanceof SSLSocket)
       {
         SSLSocket sconnection = (SSLSocket) connection;
         SSLSession sSLSession = sconnection.getSession();
         if(sSLSession!=null)
         {                                                                                      
           String cipherSuite = sSLSession.getCipherSuite();
           String proto = sSLSession.getProtocol();
           sb.append("\n      Protocol="+proto+", Cipher suite="+cipherSuite);
         }
       }   
       else
       {
          sb.append("\nERROR: socket is not instance of SSLSocket");
       }
     }
     else       
     {
       sb.append("\n   --- SSL mode is NOT active.");
     }

     if(encryptNow)
     {
       sb.append("\n   +++ Snow encryption is active.");
     }
     else
     {
       sb.append("\n   --- Snow encryption not active.");
     }

     return sb.toString();
  }
     

  final private Vector<String> authenticationTypes = new Vector<String>();

  private synchronized void logUsingAuthentication() throws Exception
  {
      sendOneLineToServer("AUTH");
      String line = readOneLineFromServer();
      if(!line.toLowerCase().startsWith("+ok"))
      {    
         accountLog.appendError("Cannot authenticate using AUTH, try old unsecure method");
         logUsingUserAndPass();
         //throw new Exception("USER error : "+line);
         // [Sept 2005]: was missing !
         return;
      }
      // normally receive a list of supported auth mechanisms
      line = readOneLineFromServer().trim();
      boolean cancrammd5 = false;
      while(!line.equals("."))
      {
          if( line.toLowerCase().indexOf("cram-md5")!=-1) cancrammd5 = true;
          authenticationTypes.addElement(line);
          line = readOneLineFromServer().trim();
      }

      if(cancrammd5)
      {
          sendOneLineToServer("AUTH CRAM-MD5");
          line = readOneLineFromServer();
          if(!line.toLowerCase().startsWith("+ "))
          {
             throw new Exception("Sent >AUTH CRAM-MD5, awaiting '+ code'\nreceived: "+line);
          }
          String stamp = new String(Utilities.decodeBase64(line.substring(2).trim()));
          String rep = Utilities.HMAC_KEYED_CRAM_MD5(password.getBytes(), stamp.getBytes(),username);
          sendOneLineToServer(rep);
          line = readOneLineFromServer();
          if(!line.toLowerCase().startsWith("+ok"))
          {
             throw new Exception("AUTH failed, received: "+line);
          }
          // OK, we are authenticated !
      }
      else
      {
          logUsingUserAndPass();
      }
  }

  /** unsecure !!!
  */
  private synchronized void logUsingUserAndPass() throws Exception
  {

        sendOneLineToServer("USER "+username);
        String line = readOneLineFromServer();
        if(!line.toLowerCase().startsWith("+ok")) throw new Exception("USER error : "+line);

        if(!this.mailAccount.getAllowUnsecurePasswordProtocols())
        {
          throw new Exception(
             Language.translate("Stopped authentication process for %\r\nbecause the unsecure protocol USER / PASS was requested.",
                    this.mailAccount.getAddress())); 
        }

        sendOneLineToServer("PASS "+password);
        //accountLog.append("#################  NOT SECURE MODE #################");

        line = readOneLineFromServer();
        if(!line.toLowerCase().startsWith("+ok")) throw new BadPasswordException("PASS error : "+line);
  }



  /** does this account have special admin privileges.
     + used to turn on the associated admin menu items
  */           
  public boolean hasAdminPrivileges() {return adminPrivileges;}


  /** send the public key on the server
  */
  public synchronized void publishPublicKey(String address, String publickey) throws Exception
  {
      sendOneLineToServer("CHPK "+address+" "+ publickey);
      String line = readOneLineFromServer();
      if(!line.toLowerCase().startsWith("+ok")) throw new Exception("CHPK error : "+line);
  }      


  /** special command to change this account password
   */
  public synchronized  void changePassword(String newHash) throws Exception
  {
      sendOneLineToServer("CPAS "+ newHash);
      String line = readOneLineFromServer(); 
      if(!line.toLowerCase().startsWith("+ok")) throw new Exception("CPAS error : "+line);
  }  


  /** special command to add a new user
   */
  public synchronized  void addNewUser(String name, String hash) throws Exception
  {
      if(!adminPrivileges) throw new Exception(
        Language.translate("Requires administrator privileges"));
      sendOneLineToServer("ADUR "+ name+" "+hash);
      String line = readOneLineFromServer();
      if(!line.toLowerCase().startsWith("+ok")) throw new Exception("ADUR error : "+line);
  }

  /** special command to set a user's password
   */
  public synchronized void setUserPassword(String name, String hash) throws Exception
  {
      if(!adminPrivileges) throw new Exception(Language.translate("Requires administrator privileges"));
      sendOneLineToServer("SUPA "+ name+" "+hash);    
      String line = readOneLineFromServer();
      if(!line.toLowerCase().startsWith("+ok")) throw new Exception("SUPA error : "+line);
  }

  /** special command, add a new forbidden address
   */
  public synchronized void addNewForbiddenFrom(String forbidden) throws Exception
  {
      sendOneLineToServer("ADFO "+ forbidden);
      String line = readOneLineFromServer();
      if(!line.toLowerCase().startsWith("+ok")) throw new Exception("ADFO error : "+line);
  }

  /** special command, remove the forbidden address
   */
  public synchronized void removeForbiddenFrom(String forbidden) throws Exception
  {
      sendOneLineToServer("REFO "+ forbidden);
      String line = readOneLineFromServer();
      if(!line.toLowerCase().startsWith("+ok")) throw new Exception("REFO error : "+line);
  }


  public synchronized Vector getForbiddenList() throws Exception
  {
      sendOneLineToServer("GEFO");
      String line = readOneLineFromServer();
      if(!line.toLowerCase().startsWith("+ok")) throw new Exception("GEFO error : "+line);
      Vector<String> addresses = new Vector<String>();
      while(true)
      {
         line = readOneLineFromServer();
         if(line==null || line.equals(".")) break;
         addresses.addElement(line);
      }
      return addresses;
  }


  /** special command
   */
  public synchronized void getServerLogFile(AccountLog log) throws Exception
  {
      if(!adminPrivileges) throw new Exception(Language.translate("Requires administrator privileges"));
      sendOneLineToServer("GELO")   ;
      String line = readOneLineFromServer();
      if(!line.toLowerCase().startsWith("+ok")) throw new Exception("GELO error : "+line);
                
      while(true)
      {
        line = readOneLineFromServer();
        if( line==null || line.equals(".")) break;
        log.appendLine(line);
      }
  }

  
  /** @return  a message list in the format  
         mess number "space" size in bytes
  */
  public synchronized String[] getMessagesLIST_() throws Exception
  {
      sendOneLineToServer("LIST");
      String line = readOneLineFromServer();
      if(!line.toLowerCase().startsWith("+ok")) throw new Exception("STAT error : "+line);

      Vector<String> ident = new Vector<String>();
      while(true)
      {
         line = readOneLineFromServer();
         if(line==null || line.equals(".")) break;
         ident.addElement(line);
      }
      return (String[]) ident.toArray(new String[ident.size()]);
  }


  /** @return
  */
  public synchronized int[] getSizes_from_MessagesLIST(String[] list) throws Exception
  {
     int[] sizes = new int[list.length];
     for(int i=0; i<list.length; i++)
     {
        String nn = list[i].trim();
        int pos = nn.lastIndexOf(" ");
        try
        {
          nn = nn.substring(pos+1);
          sizes[i] = Integer.parseInt(nn);
        }         
        catch(NumberFormatException e)
        {
          System.out.println("Cannot parse a number from "+nn);
        }
     }
     return sizes;
  }

  /** @return all the messages UIDL's 
  */
  public synchronized String[] getMessagesUIDLs() throws Exception
  {
     String[] uidls = new String[messageUIDLs.size()];
     return (String[]) messageUIDLs.keySet().toArray(uidls);
  }  
  

  /** put the uidl's in the hashtable messageUIDLs
      with following syntax :
        key = UIDL (String), object = message number (Integer)
      
      this index must be rebuild at each login in the mailserver
  */
  private synchronized void retrieveMessagesUIDL() throws Exception
  {         
      messageUIDLs.clear();
              
      sendOneLineToServer("UIDL");
      String line = readOneLineFromServer();
      if(!line.toLowerCase().startsWith("+ok")) throw new Exception("UIDL error : "+line);

      while(true)
      {
         line = readOneLineFromServer();
         if(line==null || line.equals(".")) break;
         int pos = line.indexOf(" ");
         if(pos==-1) throw new Exception("Bad UIDL line : "+line);
         String number = line.substring(0,pos);
         String ident = line.substring(pos+1);
         messageUIDLs.put(ident, new Integer(number));
      }                             
                                 
      //System.out.println("Message uidls for "+this.username+" = "+messageUIDLs);
  }


  /** @return {n, totalSize in bytes}
  */
  public synchronized int[] getNumberOfMessages() throws Exception
  {
      sendOneLineToServer("STAT");
      String line = readOneLineFromServer();
      if(!line.toLowerCase().startsWith("+ok")) throw new Exception("STAT error : "+line);

      // read number of messages
      String nStr = line.substring(4);   // "7 2334"   7 messages, total of 2334 chars
      int numberOfMessages = 0;
      int pos = nStr.indexOf(" ");
      int size = 0;
      if(pos!=-1)
      {
         try
         {
            numberOfMessages = Integer.parseInt( nStr.substring(0,pos) );
         }
         catch(NumberFormatException e)
         {
            throw new Exception("ERROR Cannot read the number of messages in '"+nStr.substring(0,pos)+"'");
         }   
         
         try
         {
            size = Integer.parseInt(nStr.substring(pos+1) );
         }
         catch(NumberFormatException e)
         {
            // not fatal, this is just used for progress
            size = numberOfMessages*2000;
         }
      }
      return new int[]{numberOfMessages, size};
  }


  public synchronized void deleteMessage(String uidl) throws Exception
  {
     deleteMessage(getMessageNumberFromUIDL(uidl));  
     // no exception => remove the UIDL from the list
     this.messageUIDLs.remove(uidl);
  }

  /**
  */
  private synchronized void deleteMessage(int number) throws Exception
  {
      sendOneLineToServer( "DELE "+number );
      String line = readOneLineFromServer();
      if(!line.toLowerCase().startsWith("+ok")) throw new Exception("DELE error : "+line);
  }


  public synchronized void sendFile(byte[] bytes, String name) throws Exception
  {
      sendOneLineToServer( "SEFI "+name);
      String line = readOneLineFromServer();
      if(!line.toLowerCase().startsWith("+ok")) throw new Exception("SEFI error : "+line);

      OutputStream os = connection.getOutputStream();
      DataOutputStream dos = new DataOutputStream(os);
      dos.writeInt(bytes.length);

      ByteArrayInputStream bis = new ByteArrayInputStream(bytes);

      byte[] buf = new byte[256];
      int read = 0;
      while((read=bis.read(buf))!=-1)
      {
         dos.write(buf,0,read);
      }
      dos.flush();
  }


  public synchronized void deleteFile(String name) throws Exception
  {                                                                
      sendOneLineToServer( "DEFI "+name);
      String line = readOneLineFromServer();
      if(!line.toLowerCase().startsWith("+ok")) throw new Exception("DEFI error : "+line);
  }


  public synchronized boolean hasFile(String name) throws Exception
  {
      sendOneLineToServer( "HAFI "+name);
      String line = readOneLineFromServer();
      if(!line.toLowerCase().startsWith("+ok")) throw new Exception("HAFI error : "+line);
      String rep = line.substring(3).trim().toLowerCase();
      if(rep.equals("yes")) return true;
      return false;
  }


  public synchronized byte[] getFile(String name) throws Exception
  {
      sendOneLineToServer( "GEFI "+name);
      String line = readOneLineFromServer();
      if(!line.toLowerCase().startsWith("+ok")) throw new Exception("GEFI error : "+line);

      InputStream is = connection.getInputStream();
      DataInputStream dis = new DataInputStream(is);
      int size = dis.readInt();

      byte[] bytes = new byte[size];
      dis.readFully(bytes);
      return bytes;
  }



  /** this return the message number (session dependent) from the UIDL (robust)
  */
  private synchronized int getMessageNumberFromUIDL(String uidl) throws Exception
  {                               
     if(!messageUIDLs.containsKey(uidl))
     {
        throw new Exception("Message uidl='"+uidl+"' not found on server");
        // try to get the number direct ???
     }
     return ((Integer) messageUIDLs.get(uidl)).intValue();
  }

  
  /** @return the first lines of the message.
      @param len = 0 => only the header
  */
  public synchronized String getMessageTop(String ident, int len) throws Exception
  {
     return getMessageTop(  
        getMessageNumberFromUIDL(ident), len);
  }
           
  /** not robust, the message number is not a ggod identifier,
     it may have changed. Use getMessageTop(String ident, int len) instead
  */
  private synchronized String getMessageTop(int number, int len) throws Exception
  {
      StringBuffer message = new StringBuffer();
      sendOneLineToServer( "TOP "+number+" "+len );
      String line = readOneLineFromServer();
      if(!line.toLowerCase().startsWith("+ok"))
      {
        throw new Exception("TOP error : "+line);
      }

      while(true)
      {
         line = readOneLineFromServer();
         if(line==null || line.equals(".")) break;
         message.append(line);
         message.append("\r\n");
      }
      return message.toString().trim();
  }
     
  /** @param progress can be null
  */               
  public synchronized String getMessage(String UIDL, Interrupter interrupter, Counter counter) throws Exception
  {                          
     return getMessage(getMessageNumberFromUIDL(UIDL), interrupter, counter);
  }

  /** @param progress can be null
  */
  private synchronized String getMessage(int number, final Interrupter interrupter, Counter counter) throws Exception
  {                                                                                           
      StringBuffer message = new StringBuffer();
      sendOneLineToServer( "RETR " + number );

      String line = readOneLineFromServer();
      if(!line.toLowerCase().startsWith("+ok")) throw new Exception("RETR error : "+line);
                                 
      int readTotal = 0;    
      long lastTime = 0;
      int incr = 0;      
      
      while(true)            
      {
         if(interrupter!=null && interrupter.shouldStopEvaluation())
         {        
           // important: close the connection, otherwise, we will hang the line !
           //  or the mailbox on server side!
           try
           {
             in.close();
           } catch(Exception e) {}
           throw new ManualInterruptedException(Language.translate("The message reception was cancelled by the user"));
         }

         line = readOneLineFromServer();
         if(line==null || line.equals(".")) break;
         message.append(line);
         message.append("\r\n");
         readTotal += line.length();
         incr += line.length();

         long time = System.currentTimeMillis();
         if(counter!=null && (time-lastTime) > 200)
         {
           lastTime = time;     
           counter.increment(incr);
           incr=0;
         }
      }

      if(counter!=null)
      {
         counter.increment(incr);
      }

      return message.toString();
  }


  /** after this, one have to reconnect...
      sends a QUIT to the server 
      close the socket connection
   */
  public synchronized void terminateSession() throws Exception
  {   
      //System.out.println("Terminate session "+username);
      //new Throwable().printStackTrace();
      
      sendOneLineToServer("QUIT");
      //read dummy line
      String dummyIgnoredLine = readOneLineFromServer();
      // ## it returns -ERR if not all messages were deleted
      messageUIDLs.clear();
      
      try
      {
        this.connection.close();
      }
      catch(Exception e)
      {
        e.printStackTrace();
      }
  }    


  /** @return true if the line is alive, to determine if yes,
   *  make a NOOP ping
   */
  public synchronized boolean isAlive()
  {
     try
     {
         sendOneLineToServer( "NOOP" );
         String line = readOneLineFromServer();
         if(!line.toLowerCase().startsWith("+ok")) return false;
     }
     catch(Exception e)
     {
         return false;
     }
     return true;
  }

                     
  /**
   *  use encryption when activated (after secure logon)
   */
  private synchronized void sendOneLineToServer(String _line) throws Exception
  {
    String line = _line;

    accountLog.appendSendLine(line, encryptNow);

    if(encryptNow)
    {
      line = Utilities.encryptSingleLineBlowfishFormat64(_line, pass);
    }
    out.write(line+"\r\n");
    out.flush();
  }



  /**
   *  use encryption when activated (after secure logon)
   */
  private synchronized String readOneLineFromServer() throws Exception
  {
    String line = in.readLine();
    if (line==null) return null;  // connection broken or terminated...

    if(encryptNow)
    {                
      if(line.length() ==0) throw new Exception("Zero length line received");
      line = Utilities.decryptSingleLineBlowfishFormat64(line, pass);
    }

    accountLog.appendReadLine(line, encryptNow);
    return line;
  }


}
