package SnowMailClient.MailEngine;


import SnowMailClient.crypto.*;
import SnowMailClient.GnuPG.GnuPGLink;
import SnowMailClient.GnuPG.Main.GnuPGCommands;
import SnowMailClient.GnuPG.model.*;

import SnowMailClient.utils.*;
import SnowMailClient.model.*;
import snow.utils.storage.*;
import snow.crypto.*;
import SnowMailClient.model.accounts.*;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.Language.Language;  
import snow.utils.gui.*;  
import snow.concurrent.*;

import java.io.*;   
import java.net.*;
import javax.net.ssl.*;
     
import java.math.*;
import javax.swing.*;
import java.util.*;                                   
import java.awt.EventQueue;

/**
 * SMTP connection
 */
public final class SecureSmtpConnection
{
  final private MailAccount mailAccount;
  final private AccountLog accountLog;
  final private String username;
  final private String password;

  private Socket connection;
  private String domainName;

  private boolean secure;  // snow mail encryption
  private boolean sslMode;
                
  //private PrintWriter out = null;   // Better with OutputStreamWriter ??
  private OutputStreamWriter out = null;

  private BufferedReader in = null;
  // used to encrypt all traffic when encrypt = true, SPAS loggin
  private byte[] key = null;
  private boolean encrypt = false;

  // read during EHLO
  private final AppProperties ehloContent = new AppProperties();


  private final static boolean debug = false;

  // special mode to pass through some firewals
  private boolean shouldUseTunellingOnPOP = true;
  private boolean tunellingOnPOPActive = false;

  boolean forceAUTH = false;
  final private Vector<String> ehloPreamble = new Vector<String>();

  /** initialize a new SMTP session with SPAS extended security
   */
  public SecureSmtpConnection(MailAccount mailAccount,
     //String smtpServer,
     //int port,
     //int popPortForSMTPTunnelling,
     String domainName,
     //boolean useSSL,
     //int sslSMTPPort,
     //boolean useSSLPOPForTunelling,
     //int sslPopPortForSMTPTunnelling,
     boolean forceAUTH
    )  throws Exception
  {
      this.mailAccount = mailAccount;
      this.accountLog  = mailAccount.getAccountLog();
      this.username    = mailAccount.getAccountUserName();
      this.password    = mailAccount.getAccountPassword();
      this.secure      = mailAccount.isSnowraverAccount();
      this.domainName  = domainName;
      this.sslMode     = mailAccount.useSSLSMTP();
      this.forceAUTH = forceAUTH;

      if(!secure || !shouldUseTunellingOnPOP)
      {
         // normal case, not on snowraver and not tunnelling
         if(sslMode)
         {
           accountLog.appendComment("\nOpening new connection to SSL SMTP Server "+mailAccount.getSMTP()+" on port "+mailAccount.getSSLSMTPPort());
           try
           {
              connection = SSLConnection.createSSLConnection(mailAccount.getSMTP(), mailAccount.getSSLSMTPPort());
              accountLog.appendComment("=========== "+(new Date())+" ==========");
           }                                            
           catch(Exception e)
           {
              accountLog.appendError("SMTP SSL connection Error:"+e.getMessage());
              throw e;
           }
         }
         else
         {
           accountLog.appendComment("\nOpening new connection to SMTP Server "+mailAccount.getSMTP()+" on port "+mailAccount.getSMTPPort());
           try
           {     
              connection = new Socket(mailAccount.getSMTP(), mailAccount.getSMTPPort());
              connection.setSoTimeout(1000*60);
              accountLog.appendComment("=========== "+(new Date())+" ==========");
           }
           catch(Exception e)
           {
              accountLog.appendError("SMTP connection Error:"+e.getMessage());
              throw new Exception("Cannot connect to "+mailAccount.getSMTP());
           }
         }
         
         // better OutputStreamWriter ??
         out = new OutputStreamWriter(connection.getOutputStream()); //, "utf-8");
         in = new BufferedReader( new InputStreamReader(connection.getInputStream())); //, "utf-8"));

      }
      else
      {
         // tricky... only avaiable on www.snowraver.org
         // System.out.println("Tunnelling SMTP on POP");
         if(mailAccount.useSSLPOP()) 
         {
           try
           {
              accountLog.appendComment("\nOpening new connection to SSL SMTP Server "+mailAccount.getSMTP()+" on the POP port "+mailAccount.getSSLPopPort());
              connection = SSLConnection.createSSLConnection(mailAccount.getSMTP(), mailAccount.getSSLPopPort());
           }
           catch(Exception e)
           {
              accountLog.appendError("Error:"+e.getMessage());
              throw e;
           }                                                                                                                            
           sslMode = true;
         }
         else
         {  
           try
           {
              accountLog.appendComment("\nOpening new connection to SMTP Server "+mailAccount.getSMTP()+" on the POP port "+mailAccount.getPopPort());
              connection = new Socket(mailAccount.getSMTP(), mailAccount.getPopPort());
           }
           catch(Exception e)
           {
              accountLog.appendError("Error:"+e.getMessage());
              throw e;
           }         
         }
         try
         {
            //out = new PrintWriter(connection.getOutputStream(), true);
            out = new OutputStreamWriter(connection.getOutputStream()); //, "utf-8");
            in = new BufferedReader( new InputStreamReader(connection.getInputStream())); //, "utf-8"));
            String line = in.readLine();  
            if(!line.toLowerCase().startsWith("+ok"))
            {
               throw new Exception("Cannot connect to "+mailAccount.getSMTP()
                             +" for pop tunnelling, waiting +ok, received="+line);
            }                                        
            accountLog.appendComment("=========== "+(new Date())+" ==========");
         }
         catch(Exception e)
         {
            accountLog.appendError("Error:"+e.getMessage());
            throw new Exception("Cannot connect to "+mailAccount.getSMTP());
         }
         
         // connect in SMTP mode
         out.write("SMTP\r\n");
         out.flush();  // [Feb2004] AAAAArgggg, this is VERY IMPORTANT, otherwise, the server wait and wait... until timeout !!!

         // answer !
         String line = readOneLineFromServer();
         if(!line.toLowerCase().startsWith("+ok"))
         {
           String err = "Cannot initiate SMTP on POP, waiting +ok, received "+line;
           accountLog.appendError(err);
           throw new Exception(err);
         }                           
         
         tunellingOnPOPActive = true;

      }

      connect();
  }
     
     
  /** explain what the status is
  */
  public final String getConnectionStatusExplanation()
  {
     StringBuffer sb = new StringBuffer();
     sb.append("SMTP Connection status:");
     if(tunellingOnPOPActive)
     {              
       sb.append("\n   +++ SMTP is tunnelled through the POP server.");
     }
     sb.append("\n   Connected to " +connection.getInetAddress()+", port "+connection.getPort()+", local port="+connection.getLocalPort());
     if(this.sslMode)
     {          
       sb.append("\n   +++ SSL mode is active.");
     }
     else
     {
       sb.append("\n   --- SSL mode is NOT active.");
     }

     if(encrypt)
     {
       sb.append("\n   +++ Snow encryption is active.");
     }
     else
     {
       sb.append("\n   --- Snow encryption not active.");
     }

     return sb.toString();
  }


  /** make the connection
  */                                    
  private void connect() throws Exception
  {
     //greetings
     String line = readOneLineFromServer();
     if(line==null || !line.toLowerCase().startsWith("220")) throw new Exception("Bad Greetings, awaiting 220 xxx, reveived "+line);

     if(secure)
     {
        // verify that we have a snowserver
        if(line.toLowerCase().indexOf("snowraver.org")==-1)
        {  
           //ask...
           int rep = JOptionPane.showConfirmDialog(null,
                 "The server is not Snowraver encryption compatible\n greetings="+line
                 +"\nDo you want to send your message through this server, WITHOUT encryption ?");
           if(rep != JOptionPane.YES_OPTION )
           {
              throw new Exception("Send aborted");
           }
           // regular SMTP protocol, not crypted
           simpleEHLOConnect(); 
        }
        else
        {
          // read timestamp
          String timestamp = null;
          int pos = line.indexOf("<");
          if(pos !=- 1)
          {
            timestamp = line.substring(pos).trim();
            if(timestamp.length()<3) 
            {
               throw new Exception("Too short timestamp, security leak because replay attack possible ? "+timestamp);
            }
          }
          else
          {
             throw new Exception("No timestamp in the greeting, secure mode not possible..., \nwaiting +OK* <xxxx.xxxx>, received "+line);
          }

          String secPass = Utilities.hashPassword( timestamp+Utilities.hashPassword(password));
          String secUser = Utilities.hashPassword( username);

          sendOneLineToServer("SPAS "+secUser+" "+secPass);
          line = readOneLineFromServer();
          if(!line.toLowerCase().startsWith("250"))
          {
             throw new BadPasswordException("Secure SPAS failled "+line);
          }
          // from now all the traffic will be encrypted
          byte[] hash = Utilities.hashPassword(password).getBytes();
          key = new byte[16];
          System.arraycopy(hash, 0, key, 0,16);

          encrypt = true;
        }
     }
     else
     {
        simpleEHLOConnect();
     }
  }


  


  /** connect and read the preamble of ehlo, if present
      Uses HELO if ehlo not supported
      ###
  */
  private void simpleEHLOConnect() throws Exception
  {
     // regular SMTP protocol, not crypted
     sendOneLineToServer("EHLO "+domainName);
     while(true)
     {
        String line = readOneLineFromServer();
        if(!line.toLowerCase().startsWith("250"))
        {
           oldEasyHELOConnect();
           return;
        }
        String cont = line.substring(3).trim();

        if(!cont.startsWith("-"))
        {
           // last line
           ehloPreamble.addElement(cont);
           break;
        }
        else
        {
           ehloPreamble.addElement(cont.substring(1));
        }
     }

     /*
     System.out.println("EHLO PREAMBLE:");
     System.out.println("<ehlo>");
     for(int i=0; i<ehloPreamble.size(); i++)
     {
        System.out.println(" "+(String) ehloPreamble.elementAt(i));
     }
     System.out.println("</ehlo>");
     */

     // authenticate
     if(forceAUTH || canAuthenticateCRAMMD5() || canAuthenticateLogin()) authenticate();
  }

  public final boolean canAuthenticateCRAMMD5()
  {
     for(String eli : ehloPreamble)
     {
        if(eli.toLowerCase().indexOf("cram-md5")!=-1) return true;
     }                                                                                                         
     return false;    
  }

  // NOT SECURE !
  //
  public final boolean canAuthenticateLogin()
  {
     for(String eli : ehloPreamble)
     {
        if(eli.toLowerCase().indexOf("login")!=-1) return true;
     }
     return false;
  }

  private void authenticate() throws Exception
  {
    if(this.canAuthenticateCRAMMD5())
    {
      sendOneLineToServer("AUTH CRAM-MD5");
      String rep1 = readOneLineFromServer();
      if(!rep1.startsWith("334")) throw new Exception("I send AUTH CRAM-MD5 and wait 334 <hash>, but I received: "+rep1);
      String stamp = new String(Utilities.decodeBase64(rep1.substring(4)));
      //System.out.println("AUTH server stamp = '"+stamp+"'");
      String hmac = Utilities.HMAC_KEYED_CRAM_MD5(password.getBytes(), stamp.getBytes(), username);
      sendOneLineToServer(hmac);
      String rep2 = readOneLineFromServer();
      if(!rep2.startsWith("235")) throw new Exception("Bad authentication: "+rep2);

      // OK, auth was successful
      return;
    }

    // [Oct2005] yahoo authenticate plain ! :-(
    if(this.canAuthenticateLogin())
    {              
      sendOneLineToServer("AUTH LOGIN");
      String rep1 = readOneLineFromServer();
      if(!rep1.startsWith("334")) throw new Exception("I send AUTH CRAM-MD5 and wait 334 <hash>, but I received: "+rep1);
      sendOneLineToServer(""+Utilities.encodeBase64(this.username.getBytes()));                                  
      String rep2 = readOneLineFromServer();
      if(!rep2.startsWith("334")) throw new Exception("Bad authentication username: "+rep2);
      
      if(!this.mailAccount.getAllowUnsecurePasswordProtocols())
      {
        throw new Exception(Language.translate("Stopped authentication because the unsecure protocol USER / PASS was requested."));
      }


      sendOneLineToServer(""+Utilities.encodeBase64(this.password.getBytes()));
      String rep3 = readOneLineFromServer();
      if(!rep3.startsWith("235")) throw new Exception("Bad authentication password: "+rep3);

      // OK, auth was successful  
      return;
    }
  }  
  
  public static void main(String[] a)
  {
    System.out.println(Utilities.encodeBase64("hans".getBytes()));
  }

  private void oldEasyHELOConnect() throws Exception
  {
     sendOneLineToServer("HELO "+domainName);
     String line = readOneLineFromServer();
     if(!line.toLowerCase().startsWith("250")) throw new Exception("Bad HELO "+line);
  }

                      
  //
  // Public methods
  //


  /** @param progress can be null 
      sign and encrypt (only when one recipient) if required
  */
  public void sendMessage(final MailMessage message, Interrupter interrupter, Counter counter) throws Exception
  {
        
     int bytesSended = 0;            

     String from = message.getFromAddress().getMailAddress();
     if(from.equals("?")) throw new Exception("\"From:\" field is not correct");

     sendOneLineToServer("MAIL FROM:<"+MailMessageUtils.grabAddress(from)+">");
/*NOT OK     sendOneLineToServer("MAIL FROM:<"+MailMessageUtils.GrabAddress(from)
         +"> AUTH="+MailMessageUtils.GrabAddress(from)+"");*/

     String line = readOneLineFromServer();
     if(!line.toLowerCase().startsWith("250"))
     {
       throw new Exception("MAIL FROM error :"+line);
     }
                
     Vector<Address> tos = message.getToAddresses();
     if(tos.size()==0) throw new Exception("\"To:\" field is empty ??");

     for(Address a: tos)
     {
        String to = a.getMailAddress();
        sendOneLineToServer("RCPT TO:<"+to+">"); 
        line = readOneLineFromServer();
        if(!line.toLowerCase().startsWith("250")) throw new Exception("RCPT TO error : "+line);
     }

     // send the mail                 
     sendOneLineToServer("DATA");
     line = readOneLineFromServer();
     if(!line.toLowerCase().startsWith("354")) throw new Exception("DATA error : "+line);
     // send the mail lines

     // send the header, followed by an empty line (delimit the header end)
     // set the send date
     // message.setActualdate();
     message.setActualDate();
     
     
     byte[] completeMessageContentBytes = null;
     if(message.getMustBeSigned())
     {             
        GnuPGLink gpg = SnowMailClientApp.getInstance().getGnuPGLink();
        GnuPGKeyID[] kids = gpg.getSecretKeyIDForAddress(from);
        if(kids.length==0) 
        {
          throw new Exception(Language.translate("No key to sign with %", from));
        }

        byte[] pass = gpg.getPasswordForKeyAskIfNotFoundOrNotValid(kids[0], true, SnowMailClientApp.getInstance());
        if(pass==null) 
        {
          throw new Exception(Language.translate("No password given to sign with %", from));
        }
             
        completeMessageContentBytes = message.getCompleteContentToSend(
           SnowMailClientApp.getInstance().getGnuPGLink(),
           kids[0], pass,  
           interrupter);
     }
     else
     {  
        //no sign
        completeMessageContentBytes = message.getCompleteContentToSend(
           SnowMailClientApp.getInstance().getGnuPGLink(),
           null, null,
           interrupter);
     }

     String completeMailContent = new String(completeMessageContentBytes);

     if(message.getMustBeEncrypted())
     {                           
       // send the header + the complete content encrypted (the encrypted part also contains the header copy)

       GnuPGLink gpg = SnowMailClientApp.getInstance().getGnuPGLink();
       String toa = tos.firstElement().getMailAddress();
       GnuPGKeyID kid = gpg.getPublicKeyIDForAddress(toa)[0];


       completeMailContent = message.getHeader().to_ASCII_String()  // repeat the header in clear text !!
                            + "\r\n"        
                            + GnuPGCommands.encryptBufferForRecipient(gpg.getPathToGPG(),
                                    completeMailContent, kid, true, interrupter);

       message.setHasBeenEncrypted(true);
     }

     // read message line per line
     BufferedReader reader = new BufferedReader(new StringReader(completeMailContent)); // NO CHARSET HERE !
     line = reader.readLine();
     long lastProgressUpdate = 0; 
     int incr =0;

     while(line!=null)                                                                                          
     {
        long now = System.currentTimeMillis();
        if(counter!=null && (now-lastProgressUpdate)>200)                                                   
        {
           lastProgressUpdate = now;
           counter.increment(incr);
           incr=0;
        }                    

        // if the line is a point, it will be recognize as a message end
        // when a line start with a point, the point is IGNORED,
        // so we just add a point (AND REMOVE IT AT MESSAGE DECODING)                             
        if(line.startsWith(".")) line = "."+line;

        bytesSended += line.length();
        incr += line.length();
        
        sendOneLineToServer(line);

        line = reader.readLine();       
     }

     sendOneLineToServer(".");  // end of message
     line = readOneLineFromServer();
     if(!line.toLowerCase().startsWith("250")) throw new Exception("DATA error :"+line);

     sendOneLineToServer("RSET");
     line = readOneLineFromServer();
     if(!line.toLowerCase().startsWith("250")) throw new Exception("RSET error :"+line);

     // mark the message as been sent
     message.setHasBeenSent(true);

     if(counter!=null)
     {
        counter.increment(incr);
     }
  }


  /** @return the rsa public key {n, e}
   */
  public BigInteger[] getPublicKey(String address) throws Exception
  {
     sendOneLineToServer("GEPK "+address);
     String line = readOneLineFromServer();
     if(!line.toLowerCase().startsWith("250")) throw new Exception("Get Public Key error :"+line);
     line = line.substring(6).trim();                 
     int pos = line.indexOf(' ');
     if(pos==-1) throw new Exception("Bad public key format");
     String n = line.substring(0, pos);
     String e = line.substring(pos+1);
     // ### may throw runtime exceptions... if bat format...
     return new BigInteger[]{
          new BigInteger(n),
          new BigInteger(e)};
  }


  /** after this, one have to reconnect...
   */
  public void terminateSession() throws Exception
  {
      sendOneLineToServer("QUIT");
      connection.close();
  }


  /** @return true if the line is alive, to determine if yes,
   *  make a NOOP ping
   */
  public boolean isAlive()
  {
    try
    {
      sendOneLineToServer("NOOP");
      String line = readOneLineFromServer();
      if(!line.toLowerCase().startsWith("250")) return false;
    }
    catch(Exception e)
    {
        return false;
    }
    return true;
  }


  /**
   *  use encryption when activated (after secure logon)
   */
  private void sendOneLineToServer(String _line) throws Exception
  {                    
    String line = _line;
    accountLog.appendSendLine(line, encrypt);

    if(encrypt)         
    {
      line = Utilities.encryptSingleLineBlowfishFormat64(_line, key);
    }
    out.write(line);
    out.write("\r\n");
    out.flush();
  }
                   
  /**
   *  use encryption when activated (after secure logon)
   */
  private String readOneLineFromServer() throws Exception
  {
    String line = in.readLine();
    if (line==null) return null;  // connection broken or terminated...

    accountLog.appendReadLine(line, encrypt);

    if(encrypt)
    {
      return Utilities.decryptSingleLineBlowfishFormat64(line, key);
    }
    return line;
  }


}
