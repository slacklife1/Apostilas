package SnowMailClient.MailEngine;

import SnowMailClient.Language.Language;
import java.util.*;
import javax.net.ssl.*;
import java.net.*;

public final class SSLConnection
{
  private SSLConnection() {}

  /** just create an ssl connection to the host at the given port
  */
  public static Socket createSSLConnection(String host, int port) throws Exception
  {
     boolean debug = false;

     Socket s0 = null;
     try
     {
         s0 = new Socket(host, port);  
         s0.setSoTimeout(1000*60);
     }
     catch(Exception e)
     {
       throw new Exception(Language.translate("Cannot connect to %1 on port %2", host, ""+port), e);
     }

     try
     {
         SSLSocketFactory ssf = (SSLSocketFactory) SSLSocketFactory.getDefault();
         SSLSocket sconnection = (SSLSocket) ssf.createSocket(s0, host, port, true);
         sconnection.setSoTimeout(1000*60);

         sconnection.setEnabledProtocols(sconnection.getEnabledProtocols());
         sconnection.setEnabledCipherSuites(sconnection.getEnabledCipherSuites());
                
         sconnection.setUseClientMode(true);
         sconnection.setNeedClientAuth(false);
         sconnection.setWantClientAuth(false);
         sconnection.setEnableSessionCreation(true);

         sconnection.startHandshake();
         
         SSLSession sSLSession = sconnection.getSession();

         if(debug && sSLSession!=null)
         {
           String cipherSuite = sSLSession.getCipherSuite();
           System.out.println("Cipher suite used = "+cipherSuite);

           String proto = sSLSession.getProtocol();
           System.out.println("Protocol = "+proto);
         }

         return sconnection;
     }
     catch(Exception e)
     {
         throw new Exception(Language.translate("Cannot initiale SSL connection to %1 on port %2", host, ""+port), e);
     }

  } // Constructor





} // SSLConnection
