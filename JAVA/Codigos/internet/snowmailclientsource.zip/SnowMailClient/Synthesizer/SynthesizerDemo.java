package SnowMailClient.Synthesizer;

import javax.sound.midi.ShortMessage;
import javax.sound.midi.Synthesizer;
import javax.sound.midi.Receiver;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.midi.InvalidMidiDataException;

/** from java sun tech tipps March2004
*/
public final class SynthesizerDemo {
  private ShortMessage message = new ShortMessage();
  private Synthesizer synth;
  private Receiver receiver;

  public SynthesizerDemo() {
    try {
      synth = MidiSystem.getSynthesizer();
      synth.open();
      receiver = synth.getReceiver();
    } catch (MidiUnavailableException e) {
      e.printStackTrace();
    }
  }

  public void playNote(int note, int duration) {
    setShortMessage(ShortMessage.NOTE_ON, note);
    receiver.send(message, -1);                           
    try {
      Thread.sleep(duration);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    setShortMessage(ShortMessage.NOTE_OFF, note);
    receiver.send(message, -1);
  }

  public void setInstrument(int instrument) {
    synth.getChannels()[0].programChange(instrument);
  }

  private void setShortMessage(
                            int onOrOff, int note) {
    try {
      message.setMessage(onOrOff, 0, note, 70);
    } catch (InvalidMidiDataException e) {
      e.printStackTrace();
    }
  }

  public void playOctave(int baseNote) {
    for (int i = 0; i < 24; i+=2) {
      playNote(baseNote + i, 50);
    }      
  }

  public static void main(String[] args) {
    SynthesizerDemo synth = new SynthesizerDemo();
    synth.setInstrument(53); 
    //can set instrument here                                           
    synth.playOctave(60);
  }
  
}
