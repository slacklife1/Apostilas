package SnowMailClient.html;

import snow.utils.storage.*;

import java.io.*;
import java.text.*;
import java.util.*;
import javax.swing.tree.TreeNode;
import javax.swing.tree.DefaultMutableTreeNode;


/** tags with body: UL, H1, H2
*/
public final class HTMLTag 
{
  static final String[] tagsWithBody = new String[] {
     "H1", "H2", "H3", "H4", "H5", "TITLE", "BODY", "HTML", "B", "I", "CENTER"};

  public final Properties parameters = new Properties();
  public String name;
  public boolean valid = true;
  public int tagOpeningStartPos;
  public int tagOpeningEndPos;     
  public boolean hasBody = false;
  public int tagClosingStartPos;
  public int tagClosingEndPos;


  public HTMLTag()
  {

  } // Constructor
  
  /** the first char must be an opening <
     the parsing occurs only between startParse and endParse
  */                                                                   
  public static HTMLTag parseTag(String text, int startParse, int endParse)
  {                                                                   
    HTMLTag tag = new HTMLTag();                           
    tag.tagOpeningStartPos = startParse;
                            
    // 1) Scan for the opening tag name and optional params
    //
    StringBuffer name = new StringBuffer();
    int i=startParse+1;                
    for(; i<endParse; i++)         
    {
      char ci = text.charAt(i);
      if(ci=='>')
      {
        // end reached, there are no parameters
        tag.tagOpeningEndPos = i;
        break;
      }
      else if(ci==' ' || ci=='\t' || ci=='\r' || ci=='\n')
      {
        // there are params, read them up to next >
        int posEnd = text.indexOf(">", i);
        if(posEnd==-1)
        {
           System.out.println("Tag "+name.toString()+" end > not reached");
           tag.valid = false;
           tag.tagOpeningEndPos = i;
           break;                  
        }
        else
        {
           tag.parameters.put("args", text.substring(i+1,posEnd));
           tag.tagOpeningEndPos = posEnd;
           break;
        }
      }
      else    
      {
        // continue scan    
        name.append(ci);
      }
    }
    tag.name = name.toString();

    if( i==endParse )
    {
       System.out.println("Tag "+name.toString()+" end not reached");
       tag.tagOpeningEndPos = endParse-1;
       tag.valid = false;
    }

    // 2) body
    //
    if(contains(tagsWithBody,tag.name))
    {
      tag.hasBody = true;
      String seekFor = "</"+tag.name+">";
      int pos = indexOfEndTag(text, tag.name, i, endParse);
      if(pos!=-1)
      {
        tag.tagClosingStartPos = pos;
        tag.tagClosingEndPos = pos+tag.name.length()+2;
      }                         
      else
      {
        tag.tagClosingStartPos = endParse-1;  // end
        tag.tagClosingEndPos = endParse-1;
      }

    }                        

    return tag;
  }

  
  /** ignoring case !
      return the position of the <, -1 if not found
  */                                                                                                                                       
  public static int indexOfEndTag(String text, String tag, int startFrom, int maxPos)
  {
    int i = startFrom;
    while(true)
    {
      int pos = text.indexOf("</", i);
      if(pos==-1) return -1;
      if(pos>=maxPos) return -1;
      
      try
      {
        // caution, because we seeked only </, it can be that we run out of index when we extract the full name
        String endName = text.substring(pos+2, pos+2+tag.length());
        if(endName.equalsIgnoreCase(tag)) return pos;
      }
      catch(Exception e)
      {
        // error                  
        System.out.println("End of "+tag+" not found");
        return -1;
      }

      // continue
      i = pos+1;
    }
  }

  public static Vector<HTMLTag> parseAllTags(String text, int startParse, int endParse)
  {
    Vector<HTMLTag> tags = new Vector<HTMLTag>();
    StringBuffer textCont = new StringBuffer();

    int pos = startParse;
    for(;pos<endParse; pos++)
    {
      char ci = text.charAt(pos);
      if(ci=='<')
      {
        HTMLTag tag = parseTag(text, pos, endParse);
        System.out.println(""+tag);
        tags.addElement(tag);
        
        pos = tag.tagOpeningEndPos; 
      }
      else
      {
        textCont.append(ci);
      }                  
    }  
    return tags;                           
  }

  public String toString()
  {                            
    StringBuffer s = new StringBuffer();
    //s.append("\nTag "+name+" pos=["+this.tagOpeningStartPos+".."+tagOpeningEndPos+"], valid = "+valid);
    s.append("\nTag "+name);
    if(!valid) 
    {
      s.append(" INVALID !");
    }
    String args = parameters.getProperty("args", null);
    if(args!=null)
    {
      s.append("\n Args = "+args);
    }
    if(this.hasBody)
    {
      s.append("\n Body end ="+this.tagClosingEndPos);
    }
    return s.toString();
  }              
                                

  public static boolean contains(String[] a, String b)
  {
    for(int i=0; i<a.length; i++)
    {
      if(a[i].equals(b)) return true;
    }
    return false;
  }

  public static void main(String[] a)
  {       
    try
    {
      String cont = new String(FileUtils.getFileContent(new File("c:/data/test2.htm")));
      Vector<HTMLTag> tags = HTMLTag.parseAllTags(cont, 0, cont.length());
      System.out.println("\n\n#tags="+tags.size());
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }

  }

} // HTMLTag     
