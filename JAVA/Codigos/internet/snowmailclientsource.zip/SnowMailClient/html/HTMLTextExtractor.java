package SnowMailClient.html;

import snow.utils.storage.*;

import java.text.*;
import javax.swing.text.*;
import javax.swing.text.html.*;
import javax.swing.text.html.parser.*;
import java.io.*;
import java.util.*;

/** Use java embedded HTML parser with our handler implementation HTMLEditorKit.ParserCallback
    to extract the text of a html page,
    also make a list of image references,
    hrefs, font faces and unknown tags.

*/
public final class HTMLTextExtractor extends HTMLEditorKit.ParserCallback
{
  // the text only
  private StringBuffer textOnly = new StringBuffer();
  boolean includePicturesAndReferences = false;

  private Vector<String> unknownTags = new Vector<String>();
  private Vector<String> aHrefs = new Vector<String>();
  private Vector<String> images = new Vector<String>();
  private Vector<String> fonts = new Vector<String>();

  private Vector<String> scriptsTagInfos = new Vector<String>();
  private Vector<String> metaTagInfos = new Vector<String>();
  private Vector<String> linkTagInfos = new Vector<String>();

  // internal data

  int newLines = 0;
  int indent = 0;


  /** @param includePicturesAndReferences should be false
     when parsing words for spam, because the pics and refs are put in the
     words DB with semantics (url*...) and get from this class with getLinks...
  */
  public HTMLTextExtractor(String cont, boolean includePicturesAndReferences) throws Exception
  {   
      this.includePicturesAndReferences = includePicturesAndReferences;
      ParserDelegator pd = new ParserDelegator();

      StringReader r = new StringReader(cont);
      pd.parse(r,
        this,
        true);   // don't stop when charset changes !!!  almost every pages cause parser crash if false

  } // Constructor

  // Parse results
  //

  public String getTextOnly() { return textOnly.toString(); }
  public Vector<String> getUnknownTags()  { return unknownTags; }

  /** the a href references
  */
  public Vector getLinksHREFs()    { return aHrefs; }
  
  /** the img src names                                                                                                      
  */
  public Vector<String> getImageSrcs()   { return images; }
  public Vector<String> getFontFaces()   { return fonts; }       
  
  public Vector<String> getScriptTagInfos() { return scriptsTagInfos; }
  public Vector<String> getMetaTagInfos() { return metaTagInfos; }
  public Vector<String> getLinkTagInfos() { return linkTagInfos; }


  // Parser's handles...
  //       

  public void handleText(char[] data, int pos)
  {
    if(newLines>0)
    {
      // maximum two new lines
      for(int i=0; i<newLines; i++)
      {
         textOnly.append("\r\n");
         if(i==1) break;
      }
      
      // indentation
      for(int i=0; i<indent; i++)
      {
        textOnly.append(" ");                                                                                              
      }
      newLines=0;
    }
    textOnly.append(new String(data));
  }

  public void handleComment(char[] data, int pos)
  {
    //System.out.println("COMMENT "+new String(data));
  }

  public void handleEndOfLineString(String eol)
  {
    // seems to happend only at the end of the file
    //textOnly.append("EOL");
  }

  public void handleError(String errorMsg, int pos)
  {   
    // a lot of errors are encountered
    //textOnly.append(" [Error "+errorMsg+"] ");
  }

  public void handleSimpleTag(HTML.Tag t, MutableAttributeSet a, int pos)
  {
    if(t==HTML.Tag.BR || t==HTML.Tag.P)
    {               
      //textOnly.append("\r\n");
      newLines++;
    }
    else if(t==HTML.Tag.META)
    {            
      //System.out.println("META");
    }
    else if(t==HTML.Tag.LINK)
    {
      //ignore
    }
    else if (t==HTML.Tag.HR)
    {     
      //ignore ### horizontal rule
    }
    else if(t==HTML.Tag.IMG)
    {
      String src = (String) a.getAttribute(HTML.Attribute.SRC);
      if(src!=null)
      {
        images.add(src);
        if(includePicturesAndReferences)
        {
          textOnly.append(" [image "+src+"] ");
        }
      }
    }                                                                                                                        
    else
    {                                                   
      // unknown tags...
      if(t.toString().equals("tbody"))
      {
        // ignore
      }
      else
      {          
        //System.out.println("Unknown simple Tag "+t);
        unknownTags.add(""+t);
      }
    }                                                                                                                              
  }
                                                       


  public void handleStartTag(HTML.Tag t, MutableAttributeSet a, int pos)
  {
    //System.out.println(""+t);
    
    if(t==HTML.Tag.P)
    {
      newLines++;
    }                                                                                                                                          
    else if(t==HTML.Tag.UL || t==HTML.Tag.OL)
    {                    
      indent += 5;
    }                   
    else if(t==HTML.Tag.LI)
    {
      newLines++;
    }
    else if(t==HTML.Tag.CENTER)
    {
      newLines++;
      indent+=10;
    }
    else if(t==HTML.Tag.BLOCKQUOTE)
    {
      newLines++;
      indent+=5;
    }  
    else if(t==HTML.Tag.SCRIPT)
    {
      //System.out.println("SCRIPT ! ");
    }
    else if(t==HTML.Tag.TITLE || t==HTML.Tag.H1 || t==HTML.Tag.H2 || t==HTML.Tag.H3
         || t==HTML.Tag.H4 || t==HTML.Tag.H5 || t==HTML.Tag.H6
         || t==HTML.Tag.TABLE
         || t==HTML.Tag.TR    )
    {
      newLines++;
    }
    else if(t==HTML.Tag.TD)
    {
      textOnly.append("\t");
    }
    else if(t==HTML.Tag.A)
    {                           
      String ref = (String) a.getAttribute(HTML.Attribute.HREF);
      if(ref!=null)
      {
        this.aHrefs.add(ref);
        if(includePicturesAndReferences)
        {
          textOnly.append(" [link "+ref+"] ");
        }
      }
    }
    else if(t==HTML.Tag.FONT)
    {
      String face = (String) a.getAttribute(HTML.Attribute.FACE);
      if(face!=null)
      {
        this.fonts.add(face);
      }
    }
    else if(t==HTML.Tag.B    || t==HTML.Tag.I || t==HTML.Tag.U
         || t==HTML.Tag.BODY || t==HTML.Tag.PRE
         || t==HTML.Tag.HTML || t==HTML.Tag.HEAD                                                                                        
         || t==HTML.Tag.SUP  || t==HTML.Tag.SUB
         || t==HTML.Tag.CODE )
    {
      // just ignore
    }
    else
    {
      //System.out.println("Unknown start tag "+t);
      unknownTags.add(""+t);   
    }   
    
    //if(t.breaksFlow()) textOnly.append("\r\n");
  }                                                    

  public void handleEndTag(HTML.Tag t, int pos)
  {                    
    if(t==HTML.Tag.TITLE || t==HTML.Tag.H1 || t==HTML.Tag.H2 || t==HTML.Tag.H3
       || t==HTML.Tag.H4 || t==HTML.Tag.H5 || t==HTML.Tag.H6)
    {           
      // new line
      newLines ++;
      //textOnly.append("\r\n");
    }
    else if(t==HTML.Tag.UL || t==HTML.Tag.OL)
    {
      indent -= 5;
      newLines ++;
    }
    else if(t==HTML.Tag.BLOCKQUOTE)
    {
      indent -= 5;
      newLines ++;
    }
    else if(t==HTML.Tag.CENTER)
    {
      indent -= 10;
      newLines ++;
    }
    else if(t==HTML.Tag.P
        || t==HTML.Tag.UL || t==HTML.Tag.OL
        || t==HTML.Tag.PRE || t==HTML.Tag.TABLE    )
    {
      newLines ++;
    }
    else if(t==HTML.Tag.TR || t==HTML.Tag.TD)
    {
      // ignore                                                                                                         
    }
    else if(t==HTML.Tag.LI || t==HTML.Tag.A || t==HTML.Tag.HEAD
       || t==HTML.Tag.B || t==HTML.Tag.I || t==HTML.Tag.U
       || t==HTML.Tag.BODY || t==HTML.Tag.HTML
       || t==HTML.Tag.FONT || t==HTML.Tag.BASEFONT
       || t==HTML.Tag.SUP || t==HTML.Tag.SUB
       || t==HTML.Tag.CODE)
    {                               
      // ignore
    }
    else
    {
      //System.out.println("Unknown end tag "+t);                                                                        
      unknownTags.add(""+t);
    } 
                  
    //if(t.breaksFlow()) textOnly.append("\r\n");
  }



  public static void main(String[] a)
  {
    try
    {
      //String cont = new String(FileUtils.getFileContent(new File("c:/data/test.htm")));
      String cont = new String(FileUtils.getFileContent(new File("C:/sources/Schmortopf_IDE/Internet/Schmortopf/versionhistory.htm")));
      //String cont = new String(FileUtils.getFileContent(new File("c:/proj/test.htm")));
      HTMLTextExtractor t = new  HTMLTextExtractor(cont, true);
      System.out.println("\n========== TEXT. ===========\n"+t.getTextOnly());
    }                                        
    catch(Exception e)                  
    {
      e.printStackTrace();
    }

  }
}
 // HTMLTextExtractor
