package SnowMailClient.html;

import snow.utils.storage.*;
import SnowMailClient.utils.StringUtils;

import java.text.*;
import javax.swing.text.*;
import javax.swing.text.html.*;
import javax.swing.text.html.parser.*;
import java.io.*;
import java.util.*;

/** Clean an HTML source...

    We use HTMLEditorKit.ParserCallback to parse and rewrite the whole html
                               
      0) remove unknown tags
      1) remove <SCRIPT> ... </SCRIPT>
      2) remove <LINK ...>
      3) remove <META ...>
      4) remove comments <! .. >
      5) remove some attributes, as Colors, background, ...

      We have so a clear structure of the tables, images and text, black on white.
*/
public final class HTMLCleaner extends HTMLEditorKit.ParserCallback
{
  // the clean HTML text recomposed
  private StringBuffer cleanHTMLText = new StringBuffer();
                                    
  private Object[] authorizedTags = new Object[]{        // Tag OR String !
     HTML.Tag.HTML, HTML.Tag.HEAD, HTML.Tag.TITLE, HTML.Tag.BODY,
     HTML.Tag.H1, HTML.Tag.H2, HTML.Tag.H3, HTML.Tag.H4, HTML.Tag.H5, HTML.Tag.H6,
     HTML.Tag.BR, HTML.Tag.P, HTML.Tag.CENTER,
     HTML.Tag.PRE, HTML.Tag.TEXTAREA, HTML.Tag.BLOCKQUOTE,
     HTML.Tag.HR,
     HTML.Tag.B,     HTML.Tag.I,     HTML.Tag.U,     HTML.Tag.EM, HTML.Tag.SUB, HTML.Tag.SUP, HTML.Tag.STRIKE, HTML.Tag.STRONG,
     HTML.Tag.UL, HTML.Tag.LI, HTML.Tag.OL,  HTML.Tag.DL, HTML.Tag.DT, HTML.Tag.DD,   // lists
     //HTML.Tag.FONT,
     //HTML.Tag.BASEFONT,
     HTML.Tag.TABLE,  HTML.Tag.TD,   HTML.Tag.TR, HTML.Tag.TH, HTML.Tag.TT,      // tables
     HTML.Tag.A,
     HTML.Tag.IMG,  // treated manually in handleSingleTag
     HTML.Tag.ADDRESS,
     HTML.Tag.AREA,
     HTML.Tag.CITE,
     //HTML.Tag.NOFRAMES,  HTML.Tag.FRAME,  HTML.Tag.FRAMESET,
     //HTML.Tag.MAP,
     //HTML.Tag.OBJECT
     //HTML.Tag.MENU,
     //HTML.Tag.META,
     //HTML.Tag.INPUT,
     //HTML.Tag.IMPLIED,
     //HTML.Tag.OPTION,
     //HTML.Tag.PARAM,
     //HTML.Tag.APPLET,
     //HTML.Tag.STYLE
  };

  private Object[] tagsToIgnoreContent = new Object[]{
     HTML.Tag.COMMENT,
     HTML.Tag.SCRIPT,
     HTML.Tag.OBJECT,
     HTML.Tag.APPLET
  };


  private Object[] forbiddenAttributes = new Object[]
  {
    "background",  // background images
    "color", "bgcolor",
    "text", "vlink", "alink", "link"  // colors defined in the header
  };

           
  
  int ignoreContentDepth = 0;  // when >0, the content is ignored. Start/end Tags iterates this counter

  private TagComparator tagComparator = new TagComparator();
  private boolean excludeImages;

  public HTMLCleaner(String cont, boolean excludeImages) throws Exception
  {
      this.excludeImages = excludeImages;
      // for quick binary search
      Arrays.sort(authorizedTags, tagComparator);
      Arrays.sort(forbiddenAttributes, tagComparator);
      Arrays.sort(tagsToIgnoreContent, tagComparator);


      ParserDelegator pd = new ParserDelegator();
      StringReader r = new StringReader(cont);
      pd.parse(r,
        this,
        true);   // don't stop when charset changes !!!  almost every pages cause parser crash if false

  } // Constructor

  public static String cleanHTML(String html, boolean excludeImages) throws Exception
  {
    HTMLCleaner hc = new HTMLCleaner(html, excludeImages);
    return hc.getCleanHTMLText();
  }

  static class TagComparator implements Comparator
  {
    public int compare(Object o1, Object o2)
    {                                                                             
       String tn1 = ""+o1;   // instance of HTML.Tag or string
       String tn2 = ""+o2;

       return tn1.compareTo(tn2);
    }
  }

  private boolean isAuthorizedTag(String t)
  {
     int pos = Arrays.binarySearch(authorizedTags, t, tagComparator);
     if(pos<0) return false;
     return true;
  }

  private boolean isAuthorizedAttribute(String t)
  {
     int pos = Arrays.binarySearch(forbiddenAttributes, t, tagComparator);
     if(pos>=0) return false;
     return true;
  }

  private boolean isIgnoreContentTag(String t)
  {
     int pos = Arrays.binarySearch(tagsToIgnoreContent, t, tagComparator);
     if(pos>=0) return true;
     return false;
  }

  // Parse results
  //

  public String getCleanHTMLText() { return cleanHTMLText.toString(); }


  // Parser's handles...
  //       

  public void handleText(char[] data, int pos)
  {   
    if(ignoreContentDepth>0) return;
    
    cleanHTMLText.append(new String(data));
  }

  public void handleComment(char[] data, int pos)
  {
    //System.out.println("COMMENT "+new String(data));
  }

  public void handleEndOfLineString(String eol)
  {                
    // seems to happend only at the end of the file
    //textOnly.append("EOL");
  }

  public void handleError(String errorMsg, int pos)
  {
    // a lot of errors are encountered
    //textOnly.append(" [Error "+errorMsg+"] ");
  }
   
  public void handleSimpleTag(HTML.Tag t, MutableAttributeSet a, int pos)
  {
    if(t==HTML.Tag.IMG)
    {
      if(this.excludeImages)
      {
        String src = (String) a.getAttribute(HTML.Attribute.SRC);
        if(StringUtils.startsWithIgnoresCaseAndBlanks(src, "cid:"))
        {
          // allow embedded images
          this.cleanHTMLText.append(" <img src="+src+"> ");
        }
        else
        {
          this.cleanHTMLText.append(" [image "+src+"] ");
        }
        return;
      } 
    }

    //System.out.println(""+t);
    if(this.isAuthorizedTag(t.toString()))
    {
      cleanHTMLText.append("\r\n<"+t+""+argumentsToString(a)+">");
    }
  }

  public void handleStartTag(HTML.Tag t, MutableAttributeSet a, int pos)
  {
    if(isIgnoreContentTag(t.toString()))
    {
      ignoreContentDepth++;
    }
    else if(this.isAuthorizedTag(t.toString()))
    {
      cleanHTMLText.append("\r\n<"+t+""+argumentsToString(a)+">");
    }
  }

  public void handleEndTag(HTML.Tag t, int pos)
  {
    if(isIgnoreContentTag(t.toString()))
    {
      ignoreContentDepth--;
    }
    else if(this.isAuthorizedTag(t.toString()))
    {
      cleanHTMLText.append("\r\n</"+t+">");
    }
  }                                                                                                                                             


  // Utils
  //
  
  private String argumentsToString(MutableAttributeSet a)
  {
    Enumeration names = a.getAttributeNames();
    StringBuffer sb = new StringBuffer();
    while(names.hasMoreElements())                                                                                                     
    {
      Object ato = names.nextElement();

      if(ato instanceof HTML.Attribute)
      {                                                                                                                                            
         HTML.Attribute at = (HTML.Attribute) ato;
         if(this.isAuthorizedAttribute(at.toString()))
         {
           String val = (String) a.getAttribute(at);

           sb.append(" ");
           sb.append( at.toString() );
           sb.append( "=\"" );
           sb.append( val );
           sb.append( "\"" );
         }
         else
         {
           //System.out.println("not accepted attr "+at.toString());
         }
      }
      else
      {
         // ###
         //System.out.println("??? "+ato+" "+(String) a.getAttribute(ato));
      }
    }
    return sb.toString();
  }
  
  // Test
  //                                                                                                                                             

  public static void main(String[] a)
  {
    try
    {                         
      //String cont = new String(FileUtils.getFileContent(new File("c:/data/test.htm")));
      //String cont = new String(FileUtils.getFileContent(new File("C:/sources/Schmortopf_IDE/Internet/Schmortopf/versionhistory.htm")));
      String cont = new String(FileUtils.getFileContent(new File("C:/sources/other/mail/client/www.snowraver.org/java/SnowMail/main.htm")));     
      //String cont = new String(FileUtils.getFileContent(new File("c:/proj/test.htm")));
      HTMLCleaner t = new  HTMLCleaner(cont, false);
      System.out.println("\n========== TEXT ===========\n"+t.getCleanHTMLText());                                                                   
      FileUtils.saveToFile(t.getCleanHTMLText().getBytes(), new File("C:/sources/other/mail/client/www.snowraver.org/java/SnowMail/aaa.htm"));
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  } 
}
