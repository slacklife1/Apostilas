package SnowMailClient.view;

/** to detect when smthng was edited
*/                     
public interface EditionListener
{
   public void mailMessageHeaderHasBeenEdited(Object source);
   public void mailMessageContentHasBeenEdited(Object source);

} // EditionListner
