package SnowMailClient.view.addresses;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

import SnowMailClient.model.*;
import snow.SortableTable.*;
import snow.utils.gui.*;

import SnowMailClient.*;
import SnowMailClient.view.FolderViewTableCellRenderer;  
import SnowMailClient.Language.Language;

                     
public class SpamBookView extends JDialog
{
  final private AddressBook addressBook;
  final private JTable table = new JTable();
  final private SortableTableModel sortableTableModel;
  final private JTextField searchTF = new JTextField("",7);
  final private JTextField searchTF2 = new JTextField("",7);
  final private JSenseButton moveToAddressBookButton = new JSenseButton(
     Language.translate(" Move to Address Book "));


  public int fontSize = UIManager.getFont("Label.font").getSize();

  private static String TITLE = Language.translate("Spam Book");

  public SpamBookView(AddressBookView ref)
  {
     super(ref, TITLE, true);
     addressBook = SnowMailClientApp.getInstance().getSpamBook();
          
     setContentPane(new SnowBackgroundPanel(new BorderLayout()));

     sortableTableModel = new SortableTableModel(addressBook);
     table.setModel(sortableTableModel);
     sortableTableModel.installGUI(table);
     table.setOpaque(false);
     table.getColumnModel().getColumn(2).setMaxWidth(fontSize*9);
     table.getColumnModel().getColumn(3).setMaxWidth(fontSize*7);
     //table.getColumnModel().getColumn(4).setMaxWidth(fontSize*7);
     //table.getColumnModel().getColumn(5).setMaxWidth(fontSize*7);


     // north
     //
     JPanel northPanel = new JPanel(new BorderLayout());
     getContentPane().add(northPanel, BorderLayout.NORTH);
     JPanel searchPanel = new JPanel();
     northPanel.add(searchPanel, BorderLayout.WEST);
     searchPanel.add(new JLabel(Language.translate("Search")+": "));
     searchPanel.add(searchTF);      
     searchPanel.add(new JLabel(" & "));
     searchPanel.add(searchTF2);  
     KeyAdapter ska = new KeyAdapter()
     {
        @Override public void keyReleased(KeyEvent e)
        {
           sortableTableModel.search(searchTF.getText(), searchTF2.getText(), false);
           updateTitle();
        }
     };
     searchTF.addKeyListener(ska);
     searchTF2.addKeyListener(ska);
                         

     // center
     JPanel centerPanel = new JPanel(new BorderLayout());
     getContentPane().add(centerPanel, BorderLayout.CENTER);
     
     JScrollPane tableScrollPane = new JScrollPane(table);
     centerPanel.add(tableScrollPane, BorderLayout.CENTER);  
                            
                                       
     // south
     JPanel controlPanel = new JPanel();
     controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.X_AXIS));
     controlPanel.setBorder(new EmptyBorder(5,5,5,5));
     getContentPane().add(controlPanel, BorderLayout.SOUTH);

     final JSenseButton removeBT = new JSenseButton(Language.translate("Remove"), SnowMailClientApp.loadImageIcon("pics/delete.PNG"));
     GUIUtils.setSmallDimensions(removeBT);
     controlPanel.add(removeBT);
     removeBT.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       {
         int[] sel = table.getSelectedRows();
         Vector<Address> addressesToRemove = new Vector<Address>();
         for(int i=0; i<sel.length; i++)
         {
           int pos = sortableTableModel.getIndexInUnsortedFromTablePos(sel[i]);
           Address address = addressBook.getAddressAt(pos);
           addressesToRemove.add(address);
         }

         int rep = JOptionPane.showConfirmDialog(SpamBookView.this,
            "Do you want to delete the "+addressesToRemove.size()+" selected addresses ?");
         if(rep!=JOptionPane.OK_OPTION) return;

         for(int i=0; i<addressesToRemove.size(); i++)
         {
            addressBook.removeAddress( (Address) addressesToRemove.elementAt(i) );
         }     
         updateTitle();
       }
     });

     controlPanel.add(moveToAddressBookButton);
     GUIUtils.setSmallDimensions(moveToAddressBookButton);
     moveToAddressBookButton.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       { 
         int[] sel = table.getSelectedRows();
         Vector<Address> addressesToRemove = new Vector<Address>();
         for(int i=0; i<sel.length; i++)
         {
           int pos = sortableTableModel.getIndexInUnsortedFromTablePos(sel[i]);
           Address address = addressBook.getAddressAt(pos);
           addressesToRemove.add(address);
         }

         for(int i=0; i<addressesToRemove.size(); i++)
         {
            Address a = (Address) addressesToRemove.elementAt(i);
            SnowMailClientApp.getInstance().getAddressBook().addAddress(a);
            addressBook.removeAddress( a );                                                                        
         }       
         updateTitle();
       }
     });                 
     
     final JSenseButton closeBT = new JSenseButton(Language.translate("Close"));
     GUIUtils.setSmallDimensions(closeBT);
     controlPanel.add(Box.createHorizontalGlue());
     controlPanel.add(closeBT);
     closeBT.setBackground(Color.orange);
     closeBT.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       {
         terminateFrame();
         setVisible(false);
       }
     });
        
      table.getSelectionModel().addListSelectionListener(new ListSelectionListener()
      {
        public void valueChanged(ListSelectionEvent e)
        {
          removeBT.setEnabled(table.getSelectedRowCount()>0);
        }
      });        


     addWindowListener(new WindowAdapter()
     {
        @Override public void windowClosed(WindowEvent e)
        {
           terminateFrame();
        }
        //  Invoked when a window has been closed.
        @Override public void windowClosing(WindowEvent e)
        {
           terminateFrame();
        }
        //  Invoked when a window is in the process of being closed.
     });

     SnowMailClientApp.getInstance().getProperties().setComponentSizeFromINIFile(this,
        "SpamBookEditor", fontSize*48,fontSize*50,200,100);
     
     updateTitle();             
     
     setVisible(true);  // modal

  }

  private void updateTitle()
  {
     int total = addressBook.getRowCount();
     int found = this.sortableTableModel.getRowCount();
     if(sortableTableModel.isSearchActive())
     {
       setTitle(TITLE+" ["+total+Language.translate(" addresses")+", "+found
         +Language.translate(" matching search")+"]");
     }
     else
     {
       setTitle(TITLE+" ["+total+Language.translate(" addresses")+"]");
     }
  }


  private void terminateFrame()
  {
     SnowMailClientApp.getInstance().getProperties().saveComponentSizeInINIFile(
        this, "SpamBookEditor");
  }

} // SpamBookView                                                      
