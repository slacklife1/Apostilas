package SnowMailClient.view.addresses;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

import SnowMailClient.model.*;
import snow.SortableTable.*;
import snow.utils.gui.*;
import SnowMailClient.*;
import SnowMailClient.view.FolderViewTableCellRenderer;
import SnowMailClient.Language.Language;
                     

public class AddressBookView extends JDialog
{
  final private AddressBook addressBook;
  final private JTable table = new JTable();
  final private SortableTableModel sortableTableModel;                    
  final private JTextField searchTF = new JTextField("",7);
  final private JTextField searchTF2 = new JTextField("",7);
  private JTextArea selectedArea = new JTextArea(3,50);
  final private JSenseButton moveToSpamButton = new JSenseButton(
          Language.translate("Move to blacklist"),
          SnowMailClientApp.loadImageIcon("pics/addtospam.PNG"));
  final private JSenseButton spamListButton = new JSenseButton(
          Language.translate("View blacklist")); 

  
  final private JCheckBox compactViewCB = new JCheckBox(Language.translate("Compact View"), false);

  public int fontSize = UIManager.getFont("Label.font").getSize();
                                    
  private static String TITLE = Language.translate("Address Book");

  public AddressBookView(SnowMailClientApp ref)
  {
     super(ref, TITLE, true);
     addressBook = ref.getAddressBook();

          
     setContentPane(new SnowBackgroundPanel(new BorderLayout()));

     sortableTableModel = new SortableTableModel(addressBook);
     table.setModel(sortableTableModel);                
     sortableTableModel.installGUI(table);
     table.setOpaque(false);
     table.getColumnModel().getColumn(2).setMaxWidth(fontSize*9);
     table.getColumnModel().getColumn(3).setMaxWidth(fontSize*7);
     table.getColumnModel().getColumn(4).setMaxWidth(fontSize*7);
     table.getColumnModel().getColumn(5).setMaxWidth(fontSize*7);

     
     // north  
     //
     JPanel northPanel = new JPanel(new BorderLayout());                                                                        

     getContentPane().add(northPanel, BorderLayout.NORTH);
     northPanel.add(
        new SearchPanel(Language.translate("Search")+": ", null,
                        sortableTableModel, true, true), BorderLayout.WEST);
     northPanel.add(compactViewCB, BorderLayout.CENTER);
     compactViewCB.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       {
         if(compactViewCB.isSelected())
         {
           sortableTableModel.setVisibleColumns(new int[]{0,1});
         }
         else
         {
           int[] cols = new int[sortableTableModel.getBasicTableModel().getColumnCount()];
           for(int i=0; i<cols.length; i++)
           {
             cols[i] = i;
           }
           sortableTableModel.setVisibleColumns( cols );                                                                
         }
       }
     });

/*     JPanel searchPanel = new JPanel();
     northPanel.add(searchPanel, BorderLayout.WEST);
     searchPanel.add(new JLabel(Language.translate("Search")+": "));
     searchPanel.add(searchTF);
     searchPanel.add(new JLabel(" & "));
     searchPanel.add(searchTF2);  
     KeyAdapter ska = new KeyAdapter()
     {
        @Override public void keyReleased(KeyEvent e)
        {
           sortableTableModel.search(searchTF.getText(), searchTF2.getText(), false);
           updateTitle();
        }                  
     };
     searchTF.addKeyListener(ska);
     searchTF2.addKeyListener(ska);  
     
     searchTF.addFocusListener(new FocusListener()
     { 
        public void focusGained(FocusEvent e)
        {
           searchTF.selectAll();
        }
        public void focusLost(FocusEvent e)
        {     
        }       
     });
     
     searchTF2.addFocusListener(new FocusListener()
     {
        public void focusGained(FocusEvent e)
        {
           searchTF2.selectAll();
        }
        public void focusLost(FocusEvent e)
        {
        }
     });  */   
                         
     spamListButton.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       {
         spamListAction();
         updateTitle();  
       }
     });

     // center
     JPanel centerPanel = new JPanel(new BorderLayout());
     getContentPane().add(centerPanel, BorderLayout.CENTER);
     
     JScrollPane tableScrollPane = new JScrollPane(table);
     centerPanel.add(tableScrollPane, BorderLayout.CENTER);  
                            
     //centerPanel.add(new JScrollPane(selectedArea), BorderLayout.SOUTH);
                                        
     // south
     JPanel controlPanel = new JPanel();
     controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.X_AXIS));
     controlPanel.setBorder(new EmptyBorder(5,5,5,5));
     getContentPane().add(controlPanel, BorderLayout.SOUTH);
                                                                                               
     final JSenseButton addBT = new JSenseButton(Language.translate("Add"), SnowMailClientApp.loadImageIcon("pics/user.PNG"));
     GUIUtils.setSmallDimensions(addBT);
     controlPanel.add(addBT);
     addBT.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       {
         addAction();  
         updateTitle();
       }
     });                                                                                                                          

     final JSenseButton removeBT = new JSenseButton(Language.translate("Remove"), SnowMailClientApp.loadImageIcon("pics/delete.PNG"));
     GUIUtils.setSmallDimensions(removeBT);
     controlPanel.add(removeBT);
     removeBT.addActionListener(new ActionListener()                                                        
     {
       public void actionPerformed(ActionEvent e)
       {
         int[] sel = table.getSelectedRows();
         Vector<Address> addressesToRemove = new Vector<Address>();
         for(int i=0; i<sel.length; i++)
         {
           int pos = sortableTableModel.getIndexInUnsortedFromTablePos(sel[i]);
           Address address = addressBook.getAddressAt(pos);
           addressesToRemove.add(address);
         }

         int rep = JOptionPane.showConfirmDialog(AddressBookView.this,
            Language.translate("Do you want to delete the % selected addresses ?", ""+addressesToRemove.size()));
         if(rep!=JOptionPane.OK_OPTION) return;

         for(int i=0; i<addressesToRemove.size(); i++)
         {
            addressBook.removeAddress( (Address) addressesToRemove.elementAt(i) );
         }
         updateTitle();
       }
     });

     controlPanel.add(moveToSpamButton);
     GUIUtils.setSmallDimensions(moveToSpamButton);
     moveToSpamButton.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       { 
         int[] sel = table.getSelectedRows();
         Vector<Address> addressesToRemove = new Vector<Address>();
         for(int i=0; i<sel.length; i++)
         {
           int pos = sortableTableModel.getIndexInUnsortedFromTablePos(sel[i]);
           Address address = addressBook.getAddressAt(pos);
           addressesToRemove.add(address);
         }

         for(int i=0; i<addressesToRemove.size(); i++)
         {
            Address a = (Address) addressesToRemove.elementAt(i);
            SnowMailClientApp.getInstance().getSpamBook().addAddress(a);
            addressBook.removeAddress( a );                                                                        
         }             
         
         updateTitle();
       }
     });  
     
     controlPanel.add(Box.createHorizontalStrut(fontSize*5));
     controlPanel.add(spamListButton);          
     GUIUtils.setSmallDimensions(spamListButton);

     final JSenseButton closeBT = new JSenseButton(Language.translate("Close"), SnowMailClientApp.loadImageIcon("pics/ok.PNG"));
     GUIUtils.setSmallDimensions(closeBT);
     controlPanel.add(Box.createHorizontalGlue());
     controlPanel.add(closeBT);
     closeBT.setBackground(Color.orange);
     closeBT.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       {
         terminateFrame();
         setVisible(false);
       }
     });
        
      table.getSelectionModel().addListSelectionListener(new ListSelectionListener()
      {
        public void valueChanged(ListSelectionEvent e)
        {
          removeBT.setEnabled(table.getSelectedRowCount()>0); 
          updateSelectedText(); 
        }
      });        


     addWindowListener(new WindowAdapter()
     {                              
        @Override public void windowClosed(WindowEvent e)
        {
           terminateFrame();                
        }
        //  Invoked when a window has been closed.
        @Override public void windowClosing(WindowEvent e)
        {
           terminateFrame();
        }
        //  Invoked when a window is in the process of being closed.
     });

     ref.getProperties().setComponentSizeFromINIFile(this,
        "AddressBookEditor", fontSize*48,fontSize*50,200,100);
     
     updateTitle();                

     setVisible(true);     // modal

  } // Constructor

      


  private void updateTitle()
  {
     int total = addressBook.getRowCount();
     int found = this.sortableTableModel.getRowCount();
     if(sortableTableModel.isSearchActive())
     {
       setTitle(TITLE+" ["+total+" "+Language.translate("addresses")+", "+found+" "+Language.translate("matching search")+"]");
     }
     else
     {
       setTitle(TITLE+" ["+total+" "+Language.translate("addresses")+"]");
     }
  }

  private void updateSelectedText()
  {  
    this.selectedArea.setText("");
    int[] sel = table.getSelectedRows();
    for(int i=0;i<sel.length;i++)
    {
      int pos = this.sortableTableModel.getIndexInUnsortedFromTablePos(sel[i]);
      Address a = this.addressBook.getAddressAt(pos);
      selectedArea.append(a.getMailAddress());
      if(i<sel.length-1)
      {       
        selectedArea.append("; ");
        if(i%5==4) selectedArea.append("\n");
      }
    }
  }

  private void addAction()
  {
     JDialog dialog = new JDialog(this, Language.translate("Add a new address"), true);
     dialog.setContentPane(new SnowBackgroundPanel(new BorderLayout()));
     CloseControlPanel ccp = new CloseControlPanel(dialog, true, true, Language.translate("Validate"));
     dialog.getContentPane().add(ccp, BorderLayout.SOUTH);

     JPanel inputPanel = new JPanel();
     GridLayout3 gl = new GridLayout3(2, inputPanel);
     dialog.getContentPane().add(inputPanel, BorderLayout.CENTER);
     JTextField nameTF = new JTextField(25);
     gl.add(Language.translate("Name")+":");
     gl.add(nameTF, true);
     JTextField mailTF = new JTextField(25);
     gl.add(Language.translate("Mail address")+":");
     gl.add(mailTF, true);

     dialog.pack();
     this.centerComponentOnThis(dialog);
     dialog.setVisible(true);
     // modal closed
     if(!ccp.getWasCancelled())
     {
        Address a = new Address();
        a.setName(nameTF.getText());
        a.setMailAddress(mailTF.getText());
        addressBook.addAddress(a);
     }


  }                               

  public void centerComponentOnThis(JDialog comp)
  {
    int w = this.getWidth();
    int h = this.getHeight();
    int wc = comp.getWidth();
    int hc = comp.getHeight();

    int x = (int) this.getLocation().getX();
    int y = (int) this.getLocation().getY();

    comp.setLocation(x+w/2-wc/2,y+h/2-hc/2);
  }
  
  private void spamListAction()
  {                   
     new SpamBookView(this);
  }

                
  private void terminateFrame()
  {
     SnowMailClientApp.getInstance().getProperties().saveComponentSizeInINIFile(
        this, "AddressBookEditor");
  }




} // AddressBookView
