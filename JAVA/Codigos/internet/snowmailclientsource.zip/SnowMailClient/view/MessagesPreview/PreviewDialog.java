package SnowMailClient.view.MessagesPreview;

import SnowMailClient.SnowMailClientApp;
import SnowMailClient.model.*;
import SnowMailClient.model.accounts.*;
import SnowMailClient.MailEngine.*;
import SnowMailClient.utils.storage.*;
import SnowMailClient.utils.*;
import snow.utils.gui.*;                                       
import snow.concurrent.*;

import snow.SortableTable.*;
import SnowMailClient.Language.Language;

import java.util.*;
import java.util.concurrent.*;                                              
import java.text.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.beans.PropertyVetoException; 
        
/** Preview message headers and allow to delete them/download.                                                   
    also displays a spam category evaluation based only on header.
    Useful to fetch some mails in great quantity of spam.                       
*/              
public final class PreviewDialog extends JDialog implements ListSelectionListener
{                                 
  final private JTable table = new JTable();
  private final PreviewModel previewModel;
  private SortableTableModel stm;
  private boolean hasBeenClosed = false;              
  private final JLabel statusLabel = new JLabel();
  private final JSenseButton deleteBT = new JSenseButton(Language.translate("Delete selected"),
     SnowMailClientApp.loadImageIcon("pics/delete.PNG"));
  private final JSenseButton deleteSpamBT = new JSenseButton(Language.translate("Delete and add to blacklist"),
     SnowMailClientApp.loadImageIcon("pics/addtospam.PNG"));
  private final JSenseButton downloadBT = new JSenseButton(Language.translate("Download selected"),
     SnowMailClientApp.loadImageIcon("pics/receivemail.PNG"));

  private final JCheckBox leaveACopyOnTheServerButton = new JCheckBox(Language.translate("Leave a copy on the server"));

  private final int fontSize = UIManager.getFont("Label.font").getSize();
  private final JProgressBar messagesProgress = new JProgressBar();
  
  private JSplitPane mainSplit;
  private final JTextPane previewPane = new JTextPane();

  final private SnowBackgroundPanel backgroundPanel = new SnowBackgroundPanel(new BorderLayout(0,0));
                                    
  /** called from the accounts editor
  */       
  public PreviewDialog(JDialog ref, PreviewModel previewModel, boolean modal)
  {
     super(ref, Language.translate("Preview (advanced options are available in the context menu)"), modal);
     this.previewModel = previewModel;
     init();
  }

  /** called from the preview action
  */
  public PreviewDialog(JFrame ref, PreviewModel previewModel, boolean modal)
  {               
     super(ref, Language.translate("Preview"), modal);
     this.previewModel = previewModel;
     init();
  }

  private void init()
  {
     this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);  // the window listener call terminate if accepted !

     this.setContentPane(backgroundPanel); //new JPanel(new BorderLayout()));

     // North
     //
     JPanel northPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
     this.getContentPane().add(northPanel, BorderLayout.NORTH);
     northPanel.add(messagesProgress);
     northPanel.add(statusLabel);
     messagesProgress.setVisible(true);
     messagesProgress.setIndeterminate(true);


     // Center
     //
     stm = new SortableTableModel(previewModel, 4, false);  // latest date on top
     table.setModel( stm );
     stm.installGUI(table);  
     
     
     mainSplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
       new JScrollPane(table),
       new JScrollPane(this.previewPane));
     mainSplit.setOneTouchExpandable(true);
     previewPane.setEditable(false);
     

     this.getContentPane().add(mainSplit, BorderLayout.CENTER);
     table.setDefaultRenderer(Object.class, new PreviewCellRenderer(previewModel, stm));
//     table.getColumnModel().getColumn(4).setMaxWidth(fontSize*12);  // subject
//     table.getColumnModel().getColumn(5).setMaxWidth(fontSize*6);  // Size
//     table.getColumnModel().getColumn(6).setMaxWidth(fontSize*4);  // Spam

     // South
     //
     JPanel controlPanelMain = new JPanel();
     controlPanelMain.setLayout(new BoxLayout(controlPanelMain, BoxLayout.Y_AXIS));

     this.getContentPane().add(controlPanelMain, BorderLayout.SOUTH);
                       
     JPanel controlPanel = new JPanel();
     controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.X_AXIS));
     controlPanel.setBorder(BorderFactory.createEmptyBorder(2,2,2,2));
     controlPanelMain.add(controlPanel);

controlPanel.add(leaveACopyOnTheServerButton);

controlPanel.add(Box.createHorizontalStrut(10));


     GUIUtils.setSmallDimensions(deleteBT);
     deleteBT.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       {
          deleteSelectedMails(false);
       }
     });


     //controlPanel.add(deleteSpamBT);  
     GUIUtils.setSmallDimensions(deleteSpamBT);
     deleteSpamBT.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       {
          deleteSelectedMails(true);
       }
     });

     controlPanel.add(downloadBT);

     controlPanel.add(Box.createHorizontalGlue());
     controlPanel.add(Box.createHorizontalStrut(30));

     GUIUtils.setSmallDimensions(downloadBT);
     downloadBT.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       {
          Thread t = new Thread()
          {
            public void run()
            {
              downloadSelectedMails();
            }
          };
          t.start();
       }
     });
                       
     JSenseButton closeBT = new JSenseButton(
           Language.translate("Close"),
           SnowMailClientApp.loadImageIcon("pics/cancel.PNG"));
     GUIUtils.setSmallDimensions(closeBT);
     controlPanel.add(closeBT);                 
     closeBT.setBackground(Color.orange);
     closeBT.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       {
         //System.out.println("a");
         closeDialogIfPossible() ;
         //System.out.println("b");
       }
     });

     this.addWindowListener(new WindowAdapter()
     {
       @Override public void windowClosing(WindowEvent we)
       {
         closeDialogIfPossible();
       }
       @Override public void windowClosed(WindowEvent we)
       {
         //closeDialogIfPossible();
       }
     });
                             

     table.addMouseListener(new MouseAdapter()
     {
        @Override public void mousePressed(MouseEvent me)
        {
          if(me.isPopupTrigger())
          {
             displayTablePopup(me);
          }
        }                          

        @Override public void mouseReleased(MouseEvent me)
        {
          if(me.isPopupTrigger())
          {
             displayTablePopup(me);
          }
        }

     });
                            
     table.getSelectionModel().addListSelectionListener(this);
     mainSplit.setDividerLocation(0.8);                                                                        
     mainSplit.setDividerLocation(300);

  } // Constructor
  
  
  private boolean getMailsBeingDownloaded()                                                                          
  {
     for(int i=0; i<this.previewModel.getRowCount(); i++)
     {
       PreviewHeader ph0 = this.previewModel.getMessageHeaderAt(i);
       if(ph0.state==PreviewHeader.State.DownloadingMessage)
       {
         return true;
       }
     }
     return false;                  
  }
  
  boolean acceptedClose = false;
  private void closeDialogIfPossible()
  {
     if(acceptedClose) return;

     //new Throwable().printStackTrace();

     Vector<PreviewHeader> downloading = this.previewModel.getMailsBeingDownloaded();
     if(downloading.size()>0)
     {
       //new PropertyVetoException("Do not close", null);
       int rep = JOptionPane.showConfirmDialog(this,
          Language.translate("Some mails are still downloading.\nClosing this dialog will cancel the downloads.\nDo you want to close the dialog ?"),
          Language.translate("Confirm Closing"), JOptionPane.OK_CANCEL_OPTION);
       if(rep==JOptionPane.OK_OPTION)
       {
         acceptedClose = true;
         this.stopDownload( downloading );

         if(this.isVisible())
         {  
           SnowMailClientApp.getInstance().getProperties().saveComponentSizeInINIFile(
              this, "MailPreviewDialog");                
           setVisible(false);
         }
         dispose();
       }
       else
       {
         //System.out.println("continue download !");
         if(!this.isVisible())
         {        
           this.setVisible(true);
           if(this.getWidth()<100 || this.getHeight()<100)
           {
              this.setSize(500,400);
           }
         }
       }
     }
     else
     {  
       acceptedClose = true;
       if(this.isVisible())
       {                
         SnowMailClientApp.getInstance().getProperties().saveComponentSizeInINIFile(
           this, "MailPreviewDialog");  
         setVisible(false);
       }
       dispose(); 
     }      
  }

  private void displayTablePopup(MouseEvent me)
  {
     JPopupMenu popup = new JPopupMenu("Preview table popup");
     int[] viewSel = table.getSelectedRows();
     if(viewSel.length==0) return;

     int posMod0 = this.stm.getIndexInUnsortedFromTablePos(viewSel[0]);
     PreviewHeader ph0 = this.previewModel.getMessageHeaderAt(posMod0);
     PreviewHeader.State uniformState = ph0.state;
     final Vector<PreviewHeader> selected = new Vector<PreviewHeader>();
     for(int i=0;i<viewSel.length;i++)
     {
        int posMod = this.stm.getIndexInUnsortedFromTablePos(viewSel[i]);
        PreviewHeader ph = this.previewModel.getMessageHeaderAt(posMod);
        if(uniformState != ph.state)
        {
           popup.add(Language.translate("States of selected messages are not uniform"));
           popup.show(table,me.getX(),me.getY());
           return;
        }
        selected.addElement(ph);
     }

     if( uniformState!=PreviewHeader.State.MessageDownloaded
      && uniformState!=PreviewHeader.State.DownloadingMessage)
     {
       // start download
       JMenuItem download = new JMenuItem(Language.translate("Download"), SnowMailClientApp.loadImageIcon("pics/receivemail.PNG"));
       popup.add(download);
       download.addActionListener(new ActionListener()
       {
          public void actionPerformed(ActionEvent ae)
          {
              download(selected);
          }   
       });
     }

     if(uniformState==PreviewHeader.State.DownloadingMessage)
     {
       // stop download
       JMenuItem stop = new JMenuItem(Language.translate("Stop download"), SnowMailClientApp.loadImageIcon("pics/cancel.PNG"));
       popup.add(stop);
       stop.addActionListener(new ActionListener()
       {
          public void actionPerformed(ActionEvent ae)
          {        
             stopDownload(selected); 
          }
       });
     } 

     if(selected.size()==1)
     {
       JMenuItem viewBeg = new JMenuItem(Language.translate("Download top"));
       //popup.add(viewBeg);
       viewBeg.addActionListener(new ActionListener()
       {
          public void actionPerformed(ActionEvent ae)
          {
             //
          }
       });

       JMenuItem viewhead = new JMenuItem(Language.translate("View header"));
       //popup.add(viewhead);
       viewhead.addActionListener(new ActionListener()
       {
          public void actionPerformed(ActionEvent ae)
          {
             //
          }
       });

     }

     if(uniformState!=PreviewHeader.State.DownloadingMessage)
     {
        JMenuItem del = new JMenuItem(Language.translate("Delete"), SnowMailClientApp.loadImageIcon("pics/delete.PNG"));
        popup.add(del);
        del.addActionListener(new ActionListener()
        {
           public void actionPerformed(ActionEvent ae)
           {
              delete(selected, false);
           }
        });
        
        JMenuItem del2 = new JMenuItem(Language.translate("Delete and Blacklist"), SnowMailClientApp.loadImageIcon("pics/addtospam.PNG"));
        popup.add(del2);
        del2.addActionListener(new ActionListener()
        {
           public void actionPerformed(ActionEvent ae)
           {
              delete(selected, true);
           }
        });
     }


     popup.show(table, me.getX(), me.getY());
  }

  private void stopDownload(final Vector<PreviewHeader> headers)
  {                
     for(PreviewHeader ph : headers)
     {
        //  
        final MailAccount account = ph.getAccount();
        InterruptableTask it = ph.downloadTask;
        if(it!=null)
        {
           // request stop (or kill if already requested
           System.out.println("Request stop");
           it.requestStop();
           ph.downloadTask = null;
        }
     }
  }

  private void delete(final Vector<PreviewHeader> headers, final boolean addToBlackListAndSPAM)
  {
     for(PreviewHeader aph : headers)
     {    
        final PreviewHeader ph = aph;               
        ph.state = PreviewHeader.State.Deleting;  
        InterruptableTask downloadTask = new InterruptableTask()
        {          
           public void run()
           {
              try
              {
                SecurePopConnection spop = ph.getAccount().getCheckedPopConnection();
                spop.deleteMessage(ph.getUIDL());
                ph.state = PreviewHeader.State.Deleted;
                EventQueue.invokeLater(new Runnable()
                { public void run() 
                  {
                    previewModel.removeMessageHeader(ph);
                    if(addToBlackListAndSPAM)
                    {
                      String from = ph.getEntryValue("from", "<NO FROM FIELD>");
                      Address fad = new Address(from);
                      SnowMailClientApp.getInstance().getSpamBook().incrementMailsReceivedFrom_AddIfNotFound(fad);
                    }
                  }
                });                   
              }
              catch(Exception ex)
              {
                ph.state = PreviewHeader.State.DownloadError;
                ph.error = ex;
                table.repaint();
              }
           }
        };
        
        ph.getAccount().messagesDownloadExecutor.execute(downloadTask);
        // Not a download => don't store the task! ph.downloadTask = downloadTask;


     }
  }


  private void download(final Vector<PreviewHeader> headers)
  {
     for(PreviewHeader pha : headers)
     {
        final PreviewHeader ph = pha;
        ph.state = PreviewHeader.State.DownloadingMessage;
        ph.alreadyDownloadedSize = 0;
        ph.error = null;

        InterruptableTask downloadTask = new InterruptableTask()
        {
           public void run()
           {
              try
              {                    
                 table.repaint();           
                 Counter counter = new Counter()
                 { 
                    public void increment(int count)
                    {
                       super.increment(count);
                       ph.alreadyDownloadedSize = counterValue;
                       table.repaint();
                    }   
                 };
                 String message = ph.getAccount().getCheckedPopConnection().getMessage(ph.getUIDL(), interrupter, counter);
                 addMessage(message, ph);
                 ph.state = PreviewHeader.State.MessageDownloaded;
              }
              catch(ManualInterruptedException e)
              {
                 ph.state = PreviewHeader.State.DownloadInterrupted;
                 ph.error = e;
              }
              catch(Exception e)
              {
                 ph.state = PreviewHeader.State.DownloadError;
                 ph.error = e;
              }
              finally
              {
                 table.repaint();
              }
           } 
        }; 

        ph.getAccount().messagesDownloadExecutor.execute(downloadTask);
        ph.downloadTask = downloadTask;

     }
  }

  public void setMaximalMessageNumber(final int max)
  {    
    EventQueue.invokeLater(new Runnable() { public void run()
    {
       messagesProgress.setVisible(true);
       messagesProgress.setIndeterminate(false);
       messagesProgress.setMaximum(max);
    }});
  }

  public void setMessageProgress(final int n)
  {
    EventQueue.invokeLater(new Runnable() { public void run()
    {          
       messagesProgress.setValue(n);
    }});
  }

  public void incrementMessageProgress(final int n)
  {
    EventQueue.invokeLater(new Runnable() { public void run()
    {
       messagesProgress.setValue( messagesProgress.getValue()+n );
    }});
  }

  public void setMessageProgressInvisible()
  {
    EventQueue.invokeLater(new Runnable() { public void run()
    {
       messagesProgress.setVisible(false);
    }});
  }

  /** the list selection listener
  */
  public void valueChanged(ListSelectionEvent e)
  {
     deleteBT.setEnabled(table.getSelectedRows().length>0);
     this.downloadBT.setEnabled(table.getSelectedRows().length>0);
     this.deleteSpamBT.setEnabled(table.getSelectedRows().length>0);
                         
     if(table.getSelectedRows().length==1)
     {                    
       int posMod0 = this.stm.getIndexInUnsortedFromTablePos(table.getSelectedRow());
       PreviewHeader ph0 = this.previewModel.getMessageHeaderAt(posMod0);
                                                                                                           
       StringBuffer sb = new StringBuffer(); 
       
       if(ph0.state == PreviewHeader.State.DownloadError)
       {
         sb.append(Language.translate("Error")+":"+ph0.error.getMessage());
         sb.append("\r\n\r\n"+Language.translate("Message Header")+":\r\n");
       }

       sb.append(ph0.toString());

       this.previewPane.setText(sb.toString());
       this.previewPane.setCaretPosition(0);
     }
     else
     {
       this.previewPane.setText("");
     }

  } 
  
  public PreviewModel getPreviewModel() { return previewModel; }                                                  

  public void setStatusLabelText(final String stlt)
  {
    EventQueue.invokeLater(new Runnable() { public void run()
    {
      statusLabel.setText(stlt);
    }});
  }
  
  /** add a downloaded message to the mail folder
  */
  private void addMessage(final String messTxt, final PreviewHeader header) throws Exception
  {
         final MailMessage mess = new MailMessage();
         mess.parse(messTxt);
         mess.setHasBeenReceived(true);

         try
         {
           double p = SnowMailClientApp.getInstance().getWordStatistic().calculateSpamProbability(mess).getProbability();
           mess.setSPAMProbability(p);            
         }
         catch(Exception es)
         {
           es.printStackTrace();
         }

         mess.setEditable(false);
         mess.selectedInView = false;


         EventQueue.invokeLater(new Runnable()
         {
           public void run()
           {
             try
             {
               SnowMailClientApp.getInstance().getFoldersModel()
                   .getInboxFolder()
                      .getMailFolder().addMessage(mess);
             } 
             catch(Exception e)
             {
               // ???
               e.printStackTrace();
             }
           }
         });

         if(!this.leaveACopyOnTheServerButton.isSelected())
         {                                     
           System.out.println("Delete message "+header.getUIDL());
           header.getAccount().getCheckedPopConnection().deleteMessage(header.getUIDL());
         }

         EventQueue.invokeLater(new Runnable()
         {  
           public void run()
           {
              previewModel.removeMessageHeader(header);
           }
         });

  } // addmessage
  

  private void downloadSelectedMails()
  {
    EventQueue.invokeLater(new Runnable() { public void run() 
    {
       // ### not nice: should be automatic :-)
       stm.storeTableSelection();

       Vector<PreviewHeader> h = previewModel.getAllMailsNotAlreadyDownloaded_(true);
       System.out.println("Download "+h.size()+" headers");
       download( h );
    }});
     
  }
  
  private void deleteSelectedMails(boolean markAsSpam)
  {
    Vector<PreviewHeader> selected = new Vector<PreviewHeader>();
    int[] sel = table.getSelectedRows();
    for(int i=0; i<sel.length; i++)
    {
       int pos = stm.getIndexInUnsortedFromTablePos(sel[i]);
       PreviewHeader h = previewModel.getMessageHeaderAt(pos);
       selected.add(h);
    }                                        

    delete(selected, markAsSpam);
   
  }


} // PreviewDialog
