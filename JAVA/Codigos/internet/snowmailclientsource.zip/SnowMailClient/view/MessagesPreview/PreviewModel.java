package SnowMailClient.view.MessagesPreview;

import SnowMailClient.SnowMailClientApp;
import SnowMailClient.model.*;
import SnowMailClient.utils.storage.*;
import SnowMailClient.utils.*;
import snow.utils.gui.*;
import snow.SortableTable.*;
import SnowMailClient.Language.Language;


import java.util.*;
import java.text.*;
import javax.swing.table.*;
import javax.swing.SwingUtilities;
import java.awt.EventQueue;

/** the preview only show downloaded headers
*/
public final class PreviewModel extends FineGrainTableModel
{
  private final Vector<PreviewHeader> headers = new Vector<PreviewHeader>();
  private boolean hasBeenChangedByUser = false;
  private static final String[] COLUMN_NAMES = new String[]{
    Language.translate("State"),  
    Language.translate("From"),
    Language.translate("To"),
    Language.translate("Subject"),
    Language.translate("Date"),
    Language.translate("Size"),
    Language.translate("SPAM")   };

  private int[] COLUMN_PREFERED_SIZES = new int[] { 8, 15, 12, 17, 7, 3, 2 };
  public int getPreferredColumnWidth(int column)
  {
    if(column>=0 && column<COLUMN_PREFERED_SIZES.length) return COLUMN_PREFERED_SIZES[column];
    return -1;
  }


  public PreviewModel()
  {
    super();
  } // Constructor

  /** add a downloaded header to the model
     here we set the white/spam list belowing
  */
  public void addMessageHeader(final PreviewHeader h)
  {
    if(!SwingUtilities.isEventDispatchThread())
    {
       new Throwable("Must be called in the EDT").printStackTrace();
    }

    // analysis (spam?, known, ...)
    AddressBook book = SnowMailClientApp.getInstance().getAddressBook();
    String from = h.getEntryValue("from", "<NO FROM FIELD>");
    String fromAddress = new Address(from).getMailAddress();
    if(book.getAddress(fromAddress)!=null)
    {
      h.setEntryOverwrite("PreviewModel_known_from", "true");
    }

    if(SnowMailClientApp.getInstance().getSpamBook().getAddress(fromAddress)!=null)
    {
      h.setEntryOverwrite("PreviewModel_spam_from", "true");
    }

    double p = SnowMailClientApp.getInstance().getWordStatistic().calculateSpamProbability(h).getProbability();
    if(p>=0 && p<=1)
    {
      h.setEntryOverwrite("PreviewModel_spam_prob", ""+p);
    }    


    fireTableModelWillChange();
    hasBeenChangedByUser = true;

    synchronized(this.headers)
    {
      headers.add(h);
    }

    fireTableStructureChanged();
    fireTableModelHasChanged();
  }
  
  /** must be called in the EDT => no need to sync...
  */
  public void removeMessageHeader(final PreviewHeader h)
  {
    if(!SwingUtilities.isEventDispatchThread())
    {
       new Throwable("Must be EDT").printStackTrace();
    }

    fireTableModelWillChange();
    hasBeenChangedByUser = true;

    synchronized(this.headers)
    {
      headers.remove(h);
    }

    fireTableStructureChanged();
    fireTableModelHasChanged();
  }

  public PreviewHeader getMessageHeaderAt(int pos)
  {      
    synchronized(this.headers)
    {
      return headers.elementAt(pos);
    }
  }

  public Vector<PreviewHeader> getMailsBeingDownloaded()
  {
    synchronized(this.headers)
    {
      Vector<PreviewHeader> h = new Vector<PreviewHeader>();
      for(int i=0; i<getRowCount(); i++)
      {
         PreviewHeader ph = getMessageHeaderAt(i);
         if(ph.state==PreviewHeader.State.DownloadingMessage)
         {
           h.addElement(ph);
         }
      }
      return h;
    }
  }

  /** ### not niec: the sortable model must first stores the selection 
      in order to let work this method correctly
  */
  public Vector<PreviewHeader> getAllMailsNotAlreadyDownloaded_(boolean selectedOnly)
  {
    synchronized(this.headers)
    {
      Vector<PreviewHeader> h = new Vector<PreviewHeader>();
      for(int i=0; i<getRowCount(); i++)
      {
         PreviewHeader ph = getMessageHeaderAt(i);
         if(selectedOnly && !this.isRowSelected(i)) 
         {        
           continue;
         }

         if(ph.state!=PreviewHeader.State.MessageDownloaded
         && ph.state!=PreviewHeader.State.DownloadingMessage)
         {
           h.addElement(ph);
         }
      }
      return h;
    }
  }


  //
  // Table model

  public int getRowCount()    
  {
    synchronized(this.headers)
    {
      return headers.size();
    }
  }
  
  public int getColumnCount() { return COLUMN_NAMES.length; }  
  SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy  HH':'mm", Locale.ENGLISH);
  DecimalFormat format0 = new DecimalFormat("0.0");
  public Object getValueAt(int row, int column)
  {
    PreviewHeader h = getMessageHeaderAt(row);
    if(column==0)
    {   
       if(h.state==PreviewHeader.State.DownloadError) 
       {
         return Language.translate("Error");
       }
       if(h.state==PreviewHeader.State.DownloadInterrupted)  return Language.translate("Interrupted");
       if(h.state==PreviewHeader.State.Deleted)              return Language.translate("Deleted");
       if(h.state==PreviewHeader.State.Deleted)              return Language.translate("Deleting")+"...";
       if(h.state==PreviewHeader.State.MessageNotDownloaded) return "";
       if(h.state==PreviewHeader.State.DownloadingMessage)
       {
         if(h.alreadyDownloadedSize==0)
         {
           return Language.translate("Downloading")+"...";
         }
         return ""+format0.format((h.alreadyDownloadedSize / ((double) h.getSizeInBytes())*100.0))+" %";

       }
       return "";
       
    }
    else if(column==1)
    {
       return h.getEntryValue("from", "<NO FROM FIELD>");
    }
    else if(column==2)
    {
       return h.getEntryValue("to", "<NO TO FIELD>");
    }
    else if(column==3)
    {
       return h.getEntryValue("subject", "<NO SUBJECT FIELD>");
    }                                
    else if(column==4)
    {
       String dateS = h.getEntryValue("date", "<NO DATE FIELD>");
       try
       {
          Date date = MailMessageUtils.parseDateFromString(dateS);
          return dateFormat.format(date);
       }
       catch(Exception e)
       {
          return dateS;
       }
    }
    else if(column==5)
    {
       return h.getSize();
    }
    else if(column==6)
    {
       return "";
    }
    return "?";
  }


  public String getColumnName(int col)
  {
    return COLUMN_NAMES[col];
  }

  public int compareForColumnSort(int pos1, int pos2, int col)
  {
    PreviewHeader h1 = getMessageHeaderAt(pos1);
    PreviewHeader h2 = getMessageHeaderAt(pos2);
    if(col==4)
    {    
       double p1 = h1.getParsedDate();
       double p2 = h2.getParsedDate();
       return this.compareDoubles(p1, p2);
    }
    else if(col==5)
    {
       double p1 = h1.getSizeInBytes();
       double p2 = h2.getSizeInBytes();
       return this.compareDoubles(p1,p2);
    }
    else if(col==6)
    {
       double p1 = Double.parseDouble(h1.getEntryValue("PreviewModel_spam_prob", "0.0"));
       double p2 = Double.parseDouble(h2.getEntryValue("PreviewModel_spam_prob", "0.0"));
       return this.compareDoubles(p1,p2);
    }
    else
    {
       return super.compareForColumnSort(pos1,pos2,col);
    }   
  }

  //
  //  Selection
  //
  
  public void setRowSelection(int row, boolean isSelected)
  {
    PreviewHeader h = getMessageHeaderAt(row);
    h.setEntryOverwrite("Preview_Selected", ""+isSelected);     
  }

  public boolean isRowSelected(int row)
  {
    PreviewHeader h = getMessageHeaderAt(row);
    return h.getEntryValue("Preview_Selected", "false").equals("true");
  }

  public void clearRowSelection()
  {
    for(int i=0; i<this.getRowCount(); i++)
    {
      setRowSelection(i, false);
    }           
  }


} // PreviewModel
