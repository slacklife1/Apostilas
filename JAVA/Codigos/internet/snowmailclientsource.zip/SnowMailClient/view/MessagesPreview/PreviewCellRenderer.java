package SnowMailClient.view.MessagesPreview;

import snow.SortableTable.*;
import snow.lookandfeel.*;
import SnowMailClient.model.*;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.SpamFilter.WordStatistic;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.beans.*;

/** DefaultTableCellRenderer seems not to like transparent bg ???
 ### can be optmized for performance...
*/                   
public class PreviewCellRenderer extends JLabel implements TableCellRenderer
{
  PreviewModel previewModel;
  SortableTableModel sortableTableModel;
                    
  public PreviewCellRenderer( PreviewModel previewModel,
                                     SortableTableModel sortableTableModel )
  {
    super();
    this.previewModel = previewModel;
    this.sortableTableModel = sortableTableModel;

    setup();
  } // Constructor

  /**
   * Notification from the <code>UIManager</code> that the look and feel
   * [L&F] has changed.
   * Replaces the current UI object with the latest version from the
   * <code>UIManager</code>.            
   */
  public void updateUI()
  {
     super.updateUI();
     setup();
  }

  private void setup()
  {
     int fontSize = UIManager.getFont("Label.font").getSize();
     Border emptyBorder = new EmptyBorder(fontSize/4, fontSize/2, fontSize/4, fontSize/2);
     this.setBorder(emptyBorder);
  }

  public Component getTableCellRendererComponent(
         JTable table, Object value, boolean isSelected, boolean hasFocus,
         int row, int column)
  {
     this.setText(value.toString());

     int ind = sortableTableModel.getIndexInUnsortedFromTablePos(row);
     PreviewHeader header = previewModel.getMessageHeaderAt(ind);

     this.setForeground(UIManager.getColor("Tree.selectionForeground"));
      
     // selection
     if(isSelected) // && (column!=1 && column!=6))
     {                                                                                                     
        setBackground(UIManager.getColor("Tree.selectionBackground"));
        setOpaque(true);
     }
     else
     {
        setOpaque(false);
     }
     
     if(true)
     {
        if(column==1) // from
        {
           boolean knownForm = header.getEntryValue("PreviewModel_known_from", "false").equals("true");
           boolean spamFrom = header.getEntryValue("PreviewModel_spam_from", "false").equals("true");
           if(knownForm)
           {
              if(isSelected)
              {
                setBackground(ThemesManager.getInstance().getGreen().darker());
              }
              else
              {
                setBackground(ThemesManager.getInstance().getGreen());
              }
              setOpaque(true);
           }
           else if(spamFrom)
           {
              if(isSelected)
              {
                setBackground(ThemesManager.getInstance().getRed().darker());
              }
              else
              {
                setBackground(ThemesManager.getInstance().getRed());
              }
              setOpaque(true);
           }
           else
           {
              if(isSelected)
              {
                setBackground(UIManager.getColor("Tree.selectionBackground"));
                setOpaque(true);
              }
              else
              {
                setOpaque(false);
              }
           }
        }
        else if (column==5)
        {
           if(header.getSizeInBytes()>500000)
           {
              this.setForeground(ThemesManager.getInstance().getRed().darker());
              //setOpaque(true);
           }
           else
           {
              this.setForeground(UIManager.getColor("Tree.selectionForeground"));
              //setOpaque(false);
           }
        }
        else if (column==6 && header.hasEntry("PreviewModel_spam_prob"))
        {
           double p = Double.parseDouble(header.getEntryValue("PreviewModel_spam_prob", "0.0"));
           if(WordStatistic.isSpam(p))
           {
              if(isSelected)
              {
                setBackground(ThemesManager.getInstance().getRed().darker());
              }
              else
              {
                setBackground(ThemesManager.getInstance().getRed());
              }
              setOpaque(true);
           }
           else
           {
              setOpaque(false);
           }
        }
        else
        {
        //   setOpaque(false);
        }
     }

     return this;
  }



}// PreviewCellRenderer
