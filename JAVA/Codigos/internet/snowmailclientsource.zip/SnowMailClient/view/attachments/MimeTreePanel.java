package SnowMailClient.view.attachments;

import SnowMailClient.utils.*;
import snow.utils.gui.*;
import snow.utils.storage.*;
import SnowMailClient.model.*;
import SnowMailClient.view.html.*;
import SnowMailClient.html.HTMLTextExtractor;
import SnowMailClient.*;
import SnowMailClient.model.multipart.*;
import SnowMailClient.view.*;
import SnowMailClient.Language.Language;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.io.*;     
import java.util.*;
                   
/** view modus:
     + see all mime parts
     + save as...
    edit modus:
     + add/remove attachements                    
*/
public class MimeTreePanel extends JPanel
{
  final private JSenseButton addBT     = new JSenseButton(Language.translate("Add"));
  final private JSenseButton removeBT  = new JSenseButton(Language.translate("Remove"));
  final private JSenseButton saveBT    = new JSenseButton(Language.translate("Save"));

  final private JTree tree = new JTree();
  final private JLabel statusLabel = new JLabel();

  private MailMessage message;
  private int fontSize = UIManager.getFont("Label.font").getSize();
                              
  private boolean hasChanged = false;

  public MimeTreePanel()
  {
    super(new BorderLayout(0,0));

    JPanel northPanel = new EFCNBackgroundPanel(new FlowLayout(FlowLayout.LEFT,0,0),
      EFCNBackgroundPanel.ApplyVerticalHighLight,
      EFCNBackgroundPanel.MediumGradientStrength,
      EFCNBackgroundPanel.PanelBackground
    );           
    northPanel.add(new JLabel(Language.translate("Attachments")));
    add(northPanel, BorderLayout.NORTH);
    northPanel.setBorder(BorderFactory.createEmptyBorder(fontSize/2,fontSize,fontSize/2,fontSize/2));

    JScrollPane jsp = new JScrollPane(tree);
    tree.setCellRenderer(new MimeTreeRenderer());
    jsp.setBorder(null);
    add(jsp, BorderLayout.CENTER);
    jsp.setOpaque(false);
    jsp.getViewport().setOpaque(false);
    tree.setOpaque(false);
     
    // control
    //
    JPanel controlPanel = new JPanel();
    add(controlPanel, BorderLayout.SOUTH);
    controlPanel.add(addBT);
    controlPanel.add(removeBT);
    controlPanel.add(saveBT); 
    
    GUIUtils.setSmallDimensions(addBT);
    GUIUtils.setSmallDimensions(removeBT);
    GUIUtils.setSmallDimensions(saveBT);


    addBT.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
         addAttachmentAction();
      }
    });

    removeBT.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
         removeSelectedAttachmentsAction();
      }
    });

    saveBT.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
         if(message==null) return;              
         if(tree.getSelectionPath()==null) return;
     
         MimePart selPart = (MimePart) tree.getSelectionPath().getLastPathComponent();

         saveMimePart(selPart);
      }
    });
    

    tree.addTreeSelectionListener(new TreeSelectionListener()
    {
      public void valueChanged(TreeSelectionEvent e)
      {  
         int nsel = tree.getSelectionCount();
         saveBT.setEnabled(nsel==1);
         removeBT.setEnabled(nsel==1);
      }
    }); 
    
    tree.addMouseListener(new MouseAdapter()
    {
      @Override public void mousePressed(MouseEvent e)
      {
         if(e.isPopupTrigger()) showTreePopup(e);  //linux
      }
      @Override public void mouseReleased(MouseEvent e)
      {
         if(e.isPopupTrigger()) showTreePopup(e);  //windows
      }

    });

    addBT.setEnabled(false);
    saveBT.setEnabled(false);
    removeBT.setEnabled(false);   
    
    tree.setVisible(false);                           
  } // initialize

  AttachmentBar attachmentsQuickPanel = null;
  public void setAttachementsQuickPanel(AttachmentBar panel)
  {
     attachmentsQuickPanel = panel;
  }

  private void updateQuickPanel()
  {  
     attachmentsQuickPanel.setMessage(this, message);
  }
  
  
  /** called from mail view
  */
  public void setMessage(MailMessage message)
  {       
     if(!SwingUtilities.isEventDispatchThread())
     {
       new Throwable("Must be called from the EDT").printStackTrace();
     }

     /*if(hasChanged && message!=null)
     {
       // do nothing, this is stored in MailView...
     }*/

     this.message = message;  
     
     updateQuickPanel();
                              
     //System.out.println("Set message in tree panel");

     if(message!=null)
     {          
        this.setIsEditable(message.isEditable());

        addBT.setEnabled(message.isEditable());
        tree.setVisible(true);        

        // mime tree
        MimeTreeModel treeModel = message.getMimeTree();
        tree.setModel( treeModel );
        
                               
        MimePart rootPart = treeModel.getRootPart();

        if(rootPart.getChildCount()>0)
        {
          // show the first level
          TreePath tp = new TreePath(rootPart.getPartAt(0).getPath());
          tree.makeVisible(tp);
        }  
        
        tree.updateUI();
     }
     else
     {
        setIsEditable(false);
        addBT.setEnabled(false);
        tree.setVisible(false);                                
     }
     hasChanged = false;
  }

  /** if yes, must be stored...
  */
  public boolean getHasChanged() { return hasChanged; }

      
  private void showTreePopup(MouseEvent e)
  {
    JPopupMenu popup = new JPopupMenu("Mime popup");
    TreePath path = tree.getPathForLocation(e.getX(),e.getY());
    if(path!=null)
    {                    
      final MimePart node = (MimePart) path.getLastPathComponent();
      String descr = node.getTextForTreeRepresentation();
      //ALREADY descr+=+" ("+MailMessageUtils.formatSize(node.getByteContent().length)+")";
      if(SnowMailClientApp.debug) descr+=" ["+node.getContentTYPE()+"]";
      popup.add(descr);
      popup.addSeparator();

      if(node.lookIfContentIsAnImage())
      {
        JMenuItem jmViewImage = new JMenuItem(Language.translate("View image"));
        popup.add(jmViewImage);
        jmViewImage.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent ee)
          {
            new ImageViewer(SnowMailClientApp.getInstance(), node);
          }
        });                   
      }

      if(node.getContentTYPE()==MimePart.ContentType.TEXT)
      {
                       
        JMenuItem jmViewText = new JMenuItem(Language.translate("View"));
        popup.add(jmViewText);
        jmViewText.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent ee)
          {
            HTMLSecureViewer hmv = new HTMLSecureViewer(SnowMailClientApp.getInstance(),
              ""+message.getFromAddress());
            
            if(node.lookIfContentIsHTML())
            {
              String cont ="";
              try
              {
                 HTMLFromMIME htmm = new HTMLFromMIME(message.getMimeTree());
                 cont = htmm.getHTMLCodeWithLocalizedLinks();
              }
              catch(Exception e)
              {
                 cont = Language.translate("Error")+": "+e.getMessage();
              }
              hmv.setHTMLSource(cont);
            }
            else
            {
              hmv.setText(node.getBodyAsText());
            }

            hmv.setSize(400, 500); 
            hmv.setLocationRelativeTo(SnowMailClientApp.getInstance());
            hmv.setVisible(true);
          }
        });  

/*        JMenuItem jmViewHTML = new JMenuItem("View HTML");
        popup.add(jmViewHTML);
        jmViewHTML.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent ee)
          {
            HTMLSecureViewer hmv = new HTMLSecureViewer(SnowMailClientApp.getInstance(),
              ""+message.getFromAddress());

            try
            {
              HTMLFromMIME hmm = new HTMLFromMIME(message.getMimeTree());
              hmv.setHTMLSource_(hmm.getHTMLCodeWithLocalizedLinks());
            }              
            catch(Exception eee)
            {              
              hmv.setHTMLSource_("<h1>Error</h1><br>"+eee.getMessage());
            }
                
            hmv.setSize(400, 500);
            hmv.setVisible(true);
          }
        });   */

      }
      
      if(node.getContentTYPE()==MimePart.ContentType.MESSAGE)
      {
        // ### create message???
        JMenuItem jmCreateAsNewMessage = new JMenuItem(Language.translate("Create as new message"));
        popup.add(jmCreateAsNewMessage);
        jmCreateAsNewMessage.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent ee)
          {
             MailMessage mess = new MailMessage();
             mess.parse(node.getBodyAsText());
             SnowMailClientApp.getInstance().getFolderView().getMailFolder().addMessage(mess);
          }
        });
      }
                                                                                         
      JMenuItem jmViewSendFormat = new JMenuItem(Language.translate("View as to be send"));
      if(SnowMailClientApp.debug)
      {
        popup.add(jmViewSendFormat);
      }
      jmViewSendFormat.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent ee)
        {   
          try
          {
            byte[] cont = node.getContent_For_Sending(1,12345,67890);
            String mess = new String(cont); // us-ascii => local charset also ok, first 128 chars identical
            
            ViewTextDialog vtd = new ViewTextDialog("MimeSendFormatView", Language.translate("Sent content"), false);
            vtd.setText(mess);           
            vtd.setVisible(true);
          }
          catch(Exception ex)
          {
            ex.printStackTrace();
          }
        }
      });

      // always present
      JMenuItem jmSave = new JMenuItem(Language.translate("Save to file"));
      popup.add(jmSave);
      jmSave.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent ee)
        {
          saveMimePart(node);
        }
      });

      popup.show(tree, e.getX(), e.getY());
    }
  }     


          
  private void setIsEditable(boolean is)
  {
     addBT.setVisible(   is);
     removeBT.setVisible(is);
     saveBT.setVisible( !is);
  }

  public void addAttachmentAction()
  {
     if(message==null) return;  // What else ??

     MimeTreeModel treeModel = message.getMimeTree();

     String last = SnowMailClientApp.getInstance().getProperties().getProperty(
        "Attachment_last_file", System.getProperty("user.home"));

     JFileChooser fileChooser = new JFileChooser(last);
     int rep = fileChooser.showOpenDialog(this);
     File file = fileChooser.getSelectedFile();
     if(file!=null)
     {
          SnowMailClientApp.getInstance().getProperties().put(
               "Attachment_last_file", file.getAbsolutePath());
          
          long size = file.length();
          if(size>1e5)
          {
             int conf = JOptionPane.showConfirmDialog(this,  
               Language.translate(
               "The file you're trying to send is of size %"
               +"\nSending big files is time consuming for you and for the recipient(s)."
               +"\nDo you want to continue adding this attachment ?", MailMessageUtils.formatSize(size)) );
             if(conf!=JOptionPane.OK_OPTION)
             {
               return;
             }
          }
          
          MimePart p = new MimePart();

          try
          {
            p.setContentAsAttachment(
               MimeUtils.guessContentType(file.getName()),
               MimeUtils.guessContentSubType(file.getName()),
               FileUtils.getFileContent(file),
               file.getName());

            treeModel.addAttachment(p);
            tree.updateUI();  // ###!!!???
            hasChanged = true;
            
            updateQuickPanel();
          }
          catch(Exception e)
          {
            e.printStackTrace();
          }
     }
  } 
  
  
  public void deleteMimePart(MimePart mp)
  {
    MimeTreeModel treeModel = message.getMimeTree();
    treeModel.removePart(mp);
    hasChanged = true;
    updateQuickPanel();
  }

  private void removeSelectedAttachmentsAction()
  {
    if(message==null) return;

    MimeTreeModel treeModel = message.getMimeTree();
    MimePart selPart = (MimePart) tree.getSelectionPath().getLastPathComponent();
              
    if(!selPart.isLeaf())
    {
      JOptionPane.showMessageDialog(
         this, "Only leafs can be stored", "Cannot store Mime part", JOptionPane.ERROR_MESSAGE);
      return;
    }

    if(selPart.isRoot())
    {
      JOptionPane.showMessageDialog(
         this, "Cannot remove the root", "Cannot remove Mime part", JOptionPane.ERROR_MESSAGE);
      return;   
    }
    
    treeModel.removePart(selPart);
    hasChanged = true;
    
    updateQuickPanel();
  }

  public void saveMimePart(MimePart selPart)
  {
                  
    if(!selPart.isLeaf())
    {
      JOptionPane.showMessageDialog(
         this, "Only leafs can be stored", "Cannot store Mime part", JOptionPane.ERROR_MESSAGE);
      return;
    }
                            
    if(selPart.getByteContent()==null)
    {
      JOptionPane.showMessageDialog(
         this, "Content is null", "Cannot store Mime part", JOptionPane.ERROR_MESSAGE);
      return;
    }


    String last = SnowMailClientApp.getInstance().getProperties().getProperty(
        "Attachment_save_file",
        System.getProperty("user.home"));
    
    JFileChooser fileChooser = new JFileChooser(last);
    fileChooser.setSelectedFile(new File(last, selPart.getName()));
    int rep = fileChooser.showSaveDialog(this);
    if(rep==JFileChooser.APPROVE_OPTION)
    {
      File file = fileChooser.getSelectedFile();
      if(file!=null)
      {
          SnowMailClientApp.getInstance().getProperties().put(
                "Attachment_save_file", file.getAbsolutePath());

          try
          {
            byte[] cont = selPart.getByteContent();
            FileUtils.saveToFile(cont, file);
          }
          catch(Exception e)
          {
            e.printStackTrace();
          }

      }
    }
  } 
  

} // AttachementsPanel
