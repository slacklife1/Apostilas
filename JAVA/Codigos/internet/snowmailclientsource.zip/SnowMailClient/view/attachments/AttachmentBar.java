package SnowMailClient.view.attachments;

import SnowMailClient.utils.*;
import snow.utils.gui.*;
import snow.utils.storage.*;
import SnowMailClient.model.*;
import SnowMailClient.view.html.*;
import SnowMailClient.html.HTMLTextExtractor;
import SnowMailClient.*;
import SnowMailClient.model.multipart.*;
import SnowMailClient.view.*;
import SnowMailClient.Language.Language;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.io.*;     
import java.util.*;

                          
public class AttachmentBar extends JPanel
{
  GridLayout3 gl3;    
  public AttachmentBar()
  {
     super();     
     gl3 = new GridLayout3(3, this);  // do better !
     //setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
     this.setOpaque(false);
     this.setBorder(null);

  } // Constructor



  public void setMessage(MimeTreePanel mtp, MailMessage message)
  {
     int availableW = 400;
     try
     {
        availableW = SnowMailClientApp.getInstance().getMailView().getWidth();
        if(availableW<=0) availableW = 500;
     } catch(Exception ignore) {}

     removeAll();
     gl3 = new GridLayout3(3, this);   // bug ??

     if(message==null) return;                                                                       
     
     

     MimeTreeModel mtm = message.getMimeTree();
     Vector<MimePart> atts = mtm.getAllAttachments();
     int totLineWidth = 0;
     for(MimePart mp : atts)
     {
        JButton attButton = createAttachmentButton(mtp, message, mp);
        if(attButton.getText().length()>20)
        {
           // jumpline
        }
        gl3.add(attButton, false, 0.5f);

        totLineWidth += (int) attButton.getPreferredSize().getWidth();
        if(totLineWidth>=availableW)
        {                                                                                                      
           totLineWidth = 0;
           // jump line. @todo !
        }                       
     }
     this.setPreferredSize(null);
     updateUI();
     
     //System.out.println("Message "+message.getSubject()+": "+atts.size()+" attachments");
  }
    


  private JButton createAttachmentButton(final MimeTreePanel mtp, final MailMessage message, final MimePart mp)
  {
     String attName = mp.getName();
     if(attName.length()>30) attName = attName.substring(0,30)+"...";
     final JButton attButton = new JButton(attName);
     GUIUtils.setSmallDimensions(attButton);
     attButton.setPreferredSize(
        new Dimension((int) attButton.getPreferredSize().getWidth(),
                      attButton.getFont().getSize()*3/2));

     // setup actions
     attButton.addActionListener(new ActionListener()
     {
        public void actionPerformed(ActionEvent ae)
        {
           JPopupMenu popup = new JPopupMenu("Attachment popup"); 

           if(mp.lookIfContentIsAnImage())
           {
             JMenuItem jmViewImage = new JMenuItem(Language.translate("View image"));
             popup.add(jmViewImage);
             jmViewImage.addActionListener(new ActionListener()
             {
               public void actionPerformed(ActionEvent ee)
               {                                                                                                    
                 new ImageViewer(SnowMailClientApp.getInstance(), mp);                                      
               }
             });
           }

           JMenuItem miSave = new JMenuItem(Language.translate("Save"));
           popup.add(miSave);
           miSave.addActionListener(new ActionListener()
           {
              public void actionPerformed(ActionEvent ae)
              {
                 mtp.saveMimePart( mp );
              }
           });  
           
           if(mp.getContentTYPE()==MimePart.ContentType.MESSAGE)
           {
             // ### create message???
             JMenuItem jmCreateAsNewMessage = new JMenuItem(Language.translate("Create as new message"));
             popup.add(jmCreateAsNewMessage);
             jmCreateAsNewMessage.addActionListener(new ActionListener()
             {
               public void actionPerformed(ActionEvent ee)
               {
                  MailMessage mess = new MailMessage();
                  mess.parse(mp.getBodyAsText());
                  SnowMailClientApp.getInstance().getFolderView().getMailFolder().addMessage(mess);
               }
             });
           }  
           
           if(message.isEditable())
           {
              JMenuItem miDelete = new JMenuItem(Language.translate("Delete"));
              popup.add(miDelete);
              miDelete.addActionListener(new ActionListener()
              {
                 public void actionPerformed(ActionEvent ae)
                 {
                    mtp.deleteMimePart( mp );
                 }
              });
             
           }

           popup.show(attButton, 0, attButton.getFont().getSize());

        }
     });

     return attButton;     
  }



} // AttachmentBar
