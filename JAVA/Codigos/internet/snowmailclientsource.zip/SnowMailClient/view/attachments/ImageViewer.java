package SnowMailClient.view.attachments;

import SnowMailClient.model.multipart.*;
import snow.utils.storage.*;
import snow.utils.gui.*;
import snow.Language.Language;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

/** extract image from the mime part in a temp file and show it.
*/
public class ImageViewer extends JDialog
{
  JLabel imageLabel = new JLabel();

  public ImageViewer(JFrame ref, MimePart part)
  {
    super(ref, "Image viewer (Mime part "+part.getName()+")", true);


    getContentPane().setLayout(new BorderLayout());
    getContentPane().add(new JScrollPane(imageLabel), BorderLayout.CENTER);

    JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    getContentPane().add(controlPanel, BorderLayout.SOUTH);

    JSenseButton okBt = new JSenseButton(Language.translate("Close"));
    controlPanel.add(okBt);
    okBt.setBackground(Color.orange);
    okBt.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
         setVisible(false);
         dispose();
      }
    });  

    int sizeX = 300;   
    int sizeY = 200;

    try
    {
      byte[] cont = part.getByteContent();
      File imageFile = File.createTempFile("ImageViewer_", part.getName());
      imageFile.deleteOnExit();
      FileUtils.saveToFile(cont, imageFile);
      ImageIcon imi = new ImageIcon(imageFile.getAbsolutePath());
      imageLabel.setIcon(imi);
      sizeX = imi.getIconWidth();
      sizeY = imi.getIconHeight();  
    }
    catch(Exception e)
    {
      e.printStackTrace();
      imageLabel.setText("Error: "+e.getMessage());
    }

    if(sizeX<200) sizeX = 200;
    if(sizeY<200) sizeY = 200;

    Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
    if(sizeX>screenDim.getWidth())  sizeX = (int)(screenDim.getWidth()*0.8);
    if(sizeY>screenDim.getHeight()) sizeY = (int)(screenDim.getHeight()*0.8);

    this.setSize(sizeX, sizeY);      
    // this centers on the screen
    this.setLocationRelativeTo(null);
    this.setVisible(true);

  } // Constructor





} // ImageViewer
