package SnowMailClient.view;

import SnowMailClient.SnowMailClientApp;
import snow.utils.gui.*;
import snow.text.*;
import SnowMailClient.Language.Language;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
                           
/** a simple dialog with a text pane and search function to view a text
    Used for the full mail content view or other debug views.
    This dialog is NOT turn to visible. Please do it yourself.
*/
public class ViewTextDialog extends JDialog
{
  final int fontSize = UIManager.getFont("Label.font").getSize();
  JTextPane textpane = new JTextPane();
  //SnowMailClientApp snowMail;
  private final JTextField searchTF = new JTextField(7);

  private DefaultStyledDocument doc = null;
  private final String propertiesKeyword;
  final JLabel lineLabel = new JLabel();

  public ViewTextDialog( String propertiesKeyword,  String dialogTitle, boolean modal)
  {
    super(SnowMailClientApp.getInstance(), dialogTitle, modal);
    this.propertiesKeyword = propertiesKeyword;

    // define the stale for the search
    doc = (DefaultStyledDocument) textpane.getDocument();
    Style defaultStyle = textpane.getStyle("default"); //StyleContext.getDefaultStyleContext().getStyle(StyleContext.DEFAULT_STYLE);

    Style searchHitStyle = doc.addStyle("SearchHit", defaultStyle);
    StyleConstants.setBackground(searchHitStyle, Color.yellow);
    StyleConstants.setBold(searchHitStyle, true);

    this.setContentPane(new SnowBackgroundPanel(new BorderLayout()));

    // Center
    //
    JScrollPane jsp = new JScrollPane(textpane);
    
    this.getContentPane().add(jsp, BorderLayout.CENTER);
    textpane.setEditable(false);
    jsp.setOpaque(false);
    jsp.getViewport().setOpaque(false);
    textpane.setOpaque(false);

    // North
    //                             
    JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    this.getContentPane().add(controlPanel, BorderLayout.NORTH);
    controlPanel.add(new JContrastLabel(Language.translate("Search")+": "));
    controlPanel.add(searchTF);
    searchTF.addKeyListener(new KeyAdapter()
     {
        @Override public void keyReleased(KeyEvent e)
        {
           if(e.getKeyCode()==KeyEvent.VK_ENTER)
           {
              //searchTF.selectAll();
              searchText(searchTF.getText(), true);    // search next
           }
           else
           {
              searchText(searchTF.getText(), false);  // initiate a new search
           }
        }
     });
    controlPanel.add(Box.createHorizontalGlue());
    controlPanel.add(lineLabel);


    searchTF.addFocusListener(new FocusListener()
    {
       public void focusGained(FocusEvent e)
       {
          searchTF.selectAll();
       }
       public void focusLost(FocusEvent e)
       {
       }
    });


    // South
    //
    CloseControlPanel closePanel = new CloseControlPanel(this, false, true, Language.translate("Close"));
    //closePanel.setOkButtonText(Language.translate("Close"));
    //closePanel.add

    

    this.getContentPane().add(closePanel, BorderLayout.SOUTH);


    SnowMailClientApp.getInstance().getProperties().setComponentSizeFromINIFile(
      this, propertiesKeyword, fontSize*40,fontSize*50, 300,150);

    this.addComponentListener(new ComponentListener()
    {
       public void componentShown(ComponentEvent ce)
       {
       }
       
       public void componentMoved(ComponentEvent ce)
       {
       }
       
       public void componentResized(ComponentEvent ce)
       {  
          saveSizeAndLocation();
       }

       public void componentHidden(ComponentEvent ce)
       {                                                     
       }
    }); 
                       
    textpane.addCaretListener(new CaretListener()
    {
       public void caretUpdate(javax.swing.event.CaretEvent ce)
       {
          int cp = textpane.getCaretPosition();
          try
          {
            DefaultStyledDocument sd = (DefaultStyledDocument) textpane.getDocument();
            Element elt = sd.getParagraphElement(cp);
            lineLabel.setText(Language.translate("Line")+" "+(TextUtils.getPositionInParent(elt)+1));
          }
          catch(Exception e)
          {
            e.printStackTrace();
          }
       }
    });

  } // Constructor

  public void saveSizeAndLocation()
  {
     //System.out.println("Save location and size of "+propertiesKeyword);
     SnowMailClientApp.getInstance().getProperties().saveComponentLocationInINIFile(                        
       this, propertiesKeyword);
  }
  
  

  public void setText(String cont)
  {
     textpane.setText(cont);
     textpane.setCaretPosition(0);   // scrolls...
  }

  int lastFoundPosition = -1;


  public void searchText(String text, boolean searchNext)
  {
     // important, don't use the textpane getText method() !!
     String textUp = "";
     try
     {
       textUp = doc.getText(0, doc.getLength()).toUpperCase();
     }
     catch(Exception e)
     {
       e.printStackTrace();
     }

     Style defaultStyle = StyleContext.getDefaultStyleContext().
                                     getStyle(StyleContext.DEFAULT_STYLE);

     // remove all old style settings
     doc.setCharacterAttributes(0, textUp.length(), defaultStyle, true);
                        
     if(text.length()==0)
     {
       // nothing to find !!
       return;
     }  

     lastFoundPosition = textUp.indexOf(text.toUpperCase(), lastFoundPosition+1);
     
     // search from beginning 
     if(lastFoundPosition==-1 && searchNext)
     {
        lastFoundPosition = textUp.indexOf(text.toUpperCase(), 0);
     }                             


     if(lastFoundPosition!=-1)               
     {
        try
        {          
          doc.setCharacterAttributes(lastFoundPosition, text.length(), doc.getStyle("SearchHit"), true);
          textpane.setCaretPosition(lastFoundPosition);
        }               
        catch(Exception e)
        {   
          e.printStackTrace();
        }
     }

  }


} // ViewTextDialog
