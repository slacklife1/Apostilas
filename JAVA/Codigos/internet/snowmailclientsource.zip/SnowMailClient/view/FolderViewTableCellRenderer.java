package SnowMailClient.view;

import snow.SortableTable.*;
import SnowMailClient.model.MailMessage;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.SpamFilter.*;
import snow.lookandfeel.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.beans.*;
                
/** DefaultTableCellRenderer seems not to like transparent bg ???
 ### can be optmized for performance...
*/                          
public final class FolderViewTableCellRenderer extends JLabel implements TableCellRenderer
{
  Font normalFont, boldFont;
  FolderView folderView;
  SortableTableModel sortableTableModel;


  /**
  */
  public FolderViewTableCellRenderer(FolderView folderView,       // basic fine grain table model 
                                     SortableTableModel sortableTableModel )  // sortable model (view)
  {
    super();
    this.folderView = folderView;
    this.sortableTableModel = sortableTableModel;

    setup();
  } // Constructor

  /**
   * Notification from the <code>UIManager</code> that the look and feel
   * [L&F] has changed.
   * Replaces the current UI object with the latest version from the
   * <code>UIManager</code>.
   */
  public void updateUI()
  {
     super.updateUI();
     setup();
  }                                                                                                              

  private void setup()
  {
     normalFont = UIManager.getFont("Table.font");
     int fontSize = normalFont.getSize();
     boldFont = //new Font(normalFont.getFontName(), Font.BOLD, fontSize);
                normalFont.deriveFont(Font.BOLD);
     Border emptyBorder = new EmptyBorder(fontSize/4, fontSize/2, fontSize/4, fontSize/2);
     this.setBorder(emptyBorder);

  }

  public Component getTableCellRendererComponent(
         JTable table, Object value, boolean isSelected, boolean hasFocus,
         int row, int viewColumn)
  {
     String text = value.toString();
     this.setText(text);
     setOpaque(false);

     int ind = sortableTableModel.getIndexInUnsortedFromTablePos(row);
     
     if(this.folderView.getMailFolder()==null) return this; // ###

     MailMessage mess = this.folderView.getMailFolder().getMessageAt(ind);
     boolean newMail = mess.getIsNew();
     if(newMail)
     {
       setFont(this.boldFont);
     }                        
     else
     {
       this.setFont(normalFont);
     }
     
     // reordering or visibility switch may have changed index maping !!
     int column = sortableTableModel.getColumnForViewIndex(viewColumn);
                    
     this.setForeground(UIManager.getColor("Tree.selectionForeground"));
     
     // selection
     if(isSelected) // && column!=0 && column!=5)
     {
        setBackground(UIManager.getColor("Tree.selectionBackground"));
        setOpaque(true);
     }
     else
     {
        setOpaque(false);
     }                                                                                                    

     if(true)
     {  
        if(column==0)
        {
          // from background => spam or white list info
          String from = mess.getFromAddress().getMailAddress();
          if(SnowMailClientApp.getInstance().getAddressBook().getAddress(from)!=null)
          {
             if(isSelected)
             {
               setBackground(ThemesManager.getInstance().getGreen().darker());
             }
             else
             {
               setBackground(ThemesManager.getInstance().getGreen());
             }
             setOpaque(true);
          }
          else if(SnowMailClientApp.getInstance().getSpamBook().getAddress(from)!=null)
          {
             if(isSelected)
             {
               setBackground(ThemesManager.getInstance().getRed().darker());
             }
             else
             {
               setBackground(ThemesManager.getInstance().getRed());
             }
             setOpaque(true);
          }                         
          else
          {
             if(isSelected)
             {
               setBackground(UIManager.getColor("Tree.selectionBackground"));
               setOpaque(true);
             }
             else
             {
               setOpaque(false);
             }
          }
        }
        
        else if(column==4)     // size
        {
           if(mess.getSize()>500000)
           {
             setForeground(ThemesManager.getInstance().getRed().darker());
           }
        }

        else if(column==5)     // spam filter
        {
          this.setFont(normalFont);
          double prob = mess.getSPAMProbability();
          if(WordStatistic.isSpam(prob))
          {
             setText("S");
          }
          else
          {
             setText("");
          }

          if(mess.getIsFalsePositive())
          {  
             // is HAM but spam prob great => false positive.
             //
             setOpaque(true);
             setText("F");
             //setForeground(Color.red);
             setBackground(  Color.RED );  // saturated red !
          }
          else if(mess.getIsSPAM())
          {
             setOpaque(true);
             if(isSelected)
             {
               setBackground(ThemesManager.getInstance().getRed().darker());
             }
             else
             {
               setBackground(ThemesManager.getInstance().getRed());
             }
          }
          else if(mess.getIsHAM())
          {
             setOpaque(true);
             if(isSelected)
             {
               setBackground(ThemesManager.getInstance().getGreen().darker());
             }
             else
             {
               setBackground(ThemesManager.getInstance().getGreen());
             }
          }
          else
          {
             setOpaque(false); // no background
          }

        }
     }

   
     return this;
  }



} // FolderViewTableCellRenderer
