package SnowMailClient.view;

import SnowMailClient.*;
import SnowMailClient.Language.Language;
import SnowMailClient.model.*;
//import SnowMailClient.utils.gui.*;
import snow.utils.gui.*;
import SnowMailClient.view.attachments.MimeTreeRenderer;
import snow.lookandfeel.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.util.*;

public class SearchTreePanel extends SnowBackgroundPanel
{
  final JTree tree = new JTree();
                     
  public SearchTreePanel(  )
  {
    super(new BorderLayout());
    JScrollPane jsp = new JScrollPane(tree);
    jsp.setOpaque(false);
    jsp.getViewport().setOpaque(false);  
    tree.setOpaque(false);

    add(jsp, BorderLayout.CENTER);
    tree.setFont(ThemesManager.getInstance().getSmallFont());
    tree.setCellRenderer(new MimeTreeRenderer());

    tree.addTreeSelectionListener(new TreeSelectionListener()
    {
       public void valueChanged(TreeSelectionEvent e)
       {
          if(tree.getSelectionCount()>0)
          {
             TreePath path = e.getPath();
             DefaultMutableTreeNode node = (DefaultMutableTreeNode) path.getLastPathComponent();
             Object uo = node.getUserObject();
             if(uo instanceof SearchHit)
             {
                SearchHit hit = (SearchHit) uo;
                select(hit);   
             }
          }
       }
    });      

    // default empty model
    setModel(new SearchResults());
  } // Constructor

  public void setModel(SearchResults sr)
  {
    tree.setModel(sr);  
  }

  private void select(final SearchHit hit)
  {
    EventQueue.invokeLater(new Runnable()
    {
      public void run()
      {                                                                                                                             
        SnowMailClientApp.getInstance().getFoldersView().setSelectedFolder(hit.getNode(), hit.getMessage());
        //SnowMailClientApp.getInstance().getFolderView().setMessage(hit.getMessage());
      }
    });
  }   
  
  /** call this at the end of the search
  */                            
  public void updateTree()
  {                 
     DefaultMutableTreeNode root = (DefaultMutableTreeNode) tree.getModel().getRoot();
     root.setUserObject(Language.translate("Search Results")
       +": ("+root.getChildCount()
       +" "+
       (root.getChildCount()==1 ? Language.translate("hit") : Language.translate("hits"))
       +")");   
       
     // ### ugly     
     EventQueue.invokeLater(new Runnable()
     {
       public void run()
       {
         tree.updateUI();
       }
     });
  }


} // searchTree
