package SnowMailClient.view;

/*
 * from ArrayListTransferHandler.java is used by the 1.4 DragListDemo.java example.
 */

import snow.utils.gui.VectorTransferable;

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.datatransfer.*;
import java.awt.dnd.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.tree.*;

/** for the originator JTables
      table.setDragEnabled(true);
      table.setTransferHandler(new TableExportTransferHandler());
*/
public final class MailDnDTransferHandler extends TransferHandler
{
    final String id;     
    final FolderView transferHandlerSource;

    Object source = null;
    int[] indices = null;
                 
    public MailDnDTransferHandler(String id, FolderView transferHandlerSource)
    {
       this.transferHandlerSource = transferHandlerSource;
       this.id = id;  
    }

    /** import on tree 
    */
    public boolean importData(JComponent c, Transferable t)
    {
        System.out.println("Import data on "+c);

        if(c instanceof JTable) return false;
        
        Vector<Object> transferedVector = null;
        if (!canImport(c, t.getTransferDataFlavors()))
        {
            return false;
        }
                                      
        try
        {

            if (hasLocalVectorFlavor(t.getTransferDataFlavors()))
            {
                transferedVector = (Vector) t.getTransferData(VectorTransferable.localVectorFlavor);
            }
            else if (hasSerialVectorFlavor(t.getTransferDataFlavors()))
            {
                transferedVector = (Vector) t.getTransferData(VectorTransferable.serialVectorFlavor);
            } 
            else 
            {
                return false;
            }

        } catch (UnsupportedFlavorException ufe) {
            System.out.println("importData: unsupported data flavor");
            return false;
        } catch (IOException ioe) {
            System.out.println("importData: I/O exception");
            return false;
        }
        

        if(c instanceof JTree)
        {
           return importData_to_JTree((JTree) c, transferedVector);
        }   

        return false;
   }  

   private boolean importData_to_JTree(JTree target, Vector<Object> transferedVector)
   {
        System.out.println("Import data to JTree");
        System.out.println("model = "+target.getModel().getClass().getName());

        System.out.println(""+this.transferHandlerSource.getSelectedMessages().length+" messages");

        /*if(!(target.getSelectionRows().length==1)) return false;
        TreePath selPath = target.getSelectionPath();
        DefaultTreeModel dtm = (DefaultTreeModel) target.getModel();
        MutableTreeNode mtn = new DefaultMutableTreeNode("Imported: "+transferedVector);
        MutableTreeNode  parent = (MutableTreeNode) selPath.getLastPathComponent();
        dtm.insertNodeInto(mtn, parent, parent.getChildCount());*/

        return true;
   }


    
    /** called when the export has been accepted and worked 
    */
    protected final void exportDone(JComponent c, Transferable data, int action)
    {
        
        if ((action == MOVE) && (indices != null))
        {
           if(source instanceof JTable)
           {
              JTable table = (JTable) source;
           }
           else if(source instanceof JTree)
           {
              JTree tree = (JTree) source;
           }
           else
           {
              System.out.println("not recognized source "+source); 
           }

        }
        indices = null;
    }

    private boolean hasLocalVectorFlavor(DataFlavor[] flavors) {
        if (VectorTransferable.localVectorFlavor == null) {
            return false;
        }

        for (int i = 0; i < flavors.length; i++) {
            if (flavors[i].equals(VectorTransferable.localVectorFlavor)) {
                return true;
            }
        }
        return false;
    }

    private boolean hasSerialVectorFlavor(DataFlavor[] flavors) {
        if (VectorTransferable.serialVectorFlavor == null) {
            return false;
        }

        for (int i = 0; i < flavors.length; i++) 
        {
            if (flavors[i].equals(VectorTransferable.serialVectorFlavor)) 
            {
                return true;
            }
        }             
        return false;   
    }

    /** this is called
    */
    public boolean canImport(JComponent c, DataFlavor[] flavors)
    {           
        // otherwise it destroys the selection on the table view (?)
        if(c instanceof JTable) return false;
        if (hasLocalVectorFlavor(flavors))  { return true; }
        if (hasSerialVectorFlavor(flavors)) { return true; }
        return false;
    }  

    /** Transfer the selected table source row indices
    */
    protected Transferable createTransferable(JComponent c)
    {
        if (c instanceof JTable)
        {
            JTable table = (JTable) c;
            source = table;
            indices = table.getSelectedRows();
            if(indices.length==0) return null;
                       
            Vector<Object> v = new Vector<Object>();
            v.addElement(id);
            v.addElement("JTable");
            v.addElement("selectedRows");
            v.addElement(indices);
            v.addElement(this);  // test
            return new VectorTransferable(v);
        }

        else if (c instanceof JTree)
        {
            JTree tree = (JTree) c;
            //source = (JTable) c;
            //indices = source.getSelectedRows();
            //if(indices.length==0) return null;

            Vector<Object> v = new Vector<Object>();
            v.addElement(id);
            v.addElement("JTree");
            v.addElement("selectionRows");
            v.addElement(tree.getSelectionRows());
            return new VectorTransferable(v);
        }
        else
        {

            return null;
        }
    }

    public int getSourceActions(JComponent c) 
    {
        return COPY_OR_MOVE;
    }


 /**  
  *  Static main method
  */ 
  public static void main( String[] arguments )
  {
     //DnDTest dt = new DnDTest();
  } // main  

}  // MailDnDTransferHandler
