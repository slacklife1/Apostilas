package SnowMailClient.view.html;

import SnowMailClient.model.multipart.MimePart;
import snow.utils.storage.*;
import java.io.*;

/** used to identify images embedded in a mime tree
*/
public class CIDLink
{               
  String CID = "";
  MimePart mimePart;
  File file;  

  // position in the source (used for replacement)
  public int posInSource;

  public CIDLink(String cid, int posInSource, MimePart mimePart) throws Exception
  {
     this.CID = cid;
     this.posInSource = posInSource;
     this.mimePart = mimePart;

     // create a random file
     file = File.createTempFile("CIDExtracted", ".jpg");
     file.deleteOnExit();
                     
     writeFile();
  }
  
  public String getCID() { return CID; }
  
  public int getPosInSource() { return posInSource; }
                                 
  public String getAbsolutePath() throws Exception
  {
    String path = file.getCanonicalPath();
    // now, convert \ to /
    //path = path.replace('\\', '/');

    return path;
  }

  private void writeFile() throws Exception
  {
     byte[] cont = mimePart.getByteContent();
     if(cont==null) throw new Exception("CID "+CID+" has null content");
     FileUtils.saveToFile(cont, file);
  }



} // CIDLink
