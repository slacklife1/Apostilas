package SnowMailClient.view.html;

import snow.utils.storage.*;
import snow.utils.gui.*;
import snow.text.*;
import SnowMailClient.html.*;
import SnowMailClient.utils.StringUtils;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.Language.Language;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.text.html.*;
import javax.swing.text.*;
import java.text.*;
import java.io.*;
import java.net.*;


/** An HTML viewer
    1) source view
    2) extracted text
    3) filtered HTML
    4) full HTML
*/
public class HTMLSecureViewer extends JDialog
{
  final static private boolean debug = false;

  final private StyledEditorKit styledEditorKit = new StyledEditorKit();
  final private HTMLEditorKit hTMLEditorKit = new HTMLEditorKit();

  final JTextPane textPane = new JTextPane();
  final JToggleButton sourceButton = new JToggleButton(Language.translate("Source"));
  final JToggleButton textButton   = new JToggleButton(Language.translate("Text"));
  final JToggleButton filteredHtmlButton = new JToggleButton(Language.translate("filtered HTML"));
  final JToggleButton htmlButton   = new JToggleButton(Language.translate("HTML"));
  final JToggleButton htmlFromText = new JToggleButton(Language.translate("HTML from text"));
  final JToggleButton closeButton  = new JToggleButton(Language.translate("Close"));

  final JTextField linkLabel = new JTextField("");
  final JTextField linkField = new JTextField();

  final static int fontSize = UIManager.getFont("Label.font").getSize();
                                  
  String htmlSourceContent = "";

  public HTMLSecureViewer(  JFrame owner,
                            String title  )
  {
     super(owner,title,true);


     textPane.setEditable(false);  // important for HTML
     if(debug) textPane.setEditable(true);
     
     JScrollPane jsp = new JScrollPane(textPane);
     getContentPane().add(jsp, BorderLayout.CENTER);
     textPane.setOpaque(false);
     jsp.setOpaque(false);
     jsp.getViewport().setOpaque(false);

     JPanel northPanel = new JPanel();
     northPanel.setLayout(new BoxLayout(northPanel, BoxLayout.X_AXIS));
     northPanel.setBorder(new EmptyBorder(2,4,2,4));
     getContentPane().add(northPanel, BorderLayout.NORTH);
     northPanel.add(closeButton);
     northPanel.add(Box.createHorizontalGlue());

     northPanel.add(sourceButton);
     northPanel.add(textButton);
     northPanel.add(filteredHtmlButton);
     northPanel.add(htmlButton);
     if(debug)                                                                                       
     {
       northPanel.add(htmlFromText);
     }

     ButtonGroup bg = new ButtonGroup();
     bg.add(sourceButton);
     bg.add(textButton);
     bg.add(filteredHtmlButton);
     bg.add(htmlButton);
     bg.add(htmlFromText);
            
     GUIUtils.setSmallDimensions(closeButton);  
     GUIUtils.setSmallDimensions(sourceButton);
     GUIUtils.setSmallDimensions(textButton);
     GUIUtils.setSmallDimensions(filteredHtmlButton);
     GUIUtils.setSmallDimensions(htmlButton);
     GUIUtils.setSmallDimensions(htmlFromText);


     closeButton.setBackground(Color.orange);        
     closeButton.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       {
          setVisible(false);
          dispose();
       }
     });

     
     
     this.sourceButton.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       {
         displaySourceTextAction();
       }
     });

     this.textButton.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       {
         displayTextAction();
       }
     });     
     
     filteredHtmlButton.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       {
         displayFilteredHTMLAction();
       }
     });

     this.htmlButton.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       {
         displayHTMLAction();
       }
     });

     htmlFromText.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       {
         displayHTMLFromTextAction();
       }
     });

     linkField.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       {
         try
         {
           URL url = new URL( linkField.getText());
           textPane.setPage(url); // Attention: SECURITY !!!
         }
         catch(Exception ee)
         {
           ee.printStackTrace();
           linkLabel.setText("Error: "+ee.getMessage());
         }            
       }              
     });


     //  south
     //
     JPanel southPanel = new JPanel();
     southPanel.setLayout(new BoxLayout(southPanel, BoxLayout.X_AXIS));
     getContentPane().add(southPanel, BorderLayout.SOUTH);

     final JLabel lineLabel = new JLabel();
     southPanel.add(lineLabel);
     southPanel.add(linkLabel);

     lineLabel.setBorder(BorderFactory.createCompoundBorder(
       new EtchedBorder(EtchedBorder.LOWERED),
       new EmptyBorder(1,1,1,1)));
     //lineLabel.setEditable(false);
     lineLabel.setBackground(getBackground());

     linkLabel.setBorder(BorderFactory.createCompoundBorder(
       new EtchedBorder(EtchedBorder.LOWERED),
       new EmptyBorder(1,1,1,1)));
     linkLabel.setEditable(false);
     linkLabel.setBackground(getBackground());


     textPane.addHyperlinkListener(new HyperlinkListener()
     {
       public void hyperlinkUpdate(HyperlinkEvent e)
       {
          linkLabel.setText(Language.translate("link")+": "+e.getURL());
          // System.out.println("descr="+e.getDescription());
          // System.out.println("elt="+e.getSourceElement());
       }
     });


     textPane.addCaretListener(new CaretListener()
     {
       public void caretUpdate(javax.swing.event.CaretEvent ce)
       {
          int cp = textPane.getCaretPosition();
          try
          {
            DefaultStyledDocument sd = (DefaultStyledDocument) textPane.getDocument();
            Element elt = sd.getParagraphElement(cp);

            lineLabel.setText(Language.translate("Line")+" "+(TextUtils.getPositionInParent(elt)+1));
            //Arrays sd.getRootElements()[0];
          }
          catch(Exception e)
          {
            e.printStackTrace();
          }
       }
     });

  } // Constructor
  
  public void setHTMLSource(String html)
  {
    this.htmlSourceContent = html;
    filteredHtmlButton.setSelected(true);
    displayFilteredHTMLAction();
  }
                  
  public void setText(String html)
  {
    this.htmlSourceContent = html;
    this.sourceButton.setSelected(true);
    displaySourceTextAction();
  }
  
  private void displaySourceTextAction()
  {
    textPane.setText("");
    this.textPane.setEditorKit(styledEditorKit);
    textPane.setText(htmlSourceContent);
    textPane.setCaretPosition(0);
  } 

  private void displayTextAction()
  {
    try
    {                
      HTMLTextExtractor he = new HTMLTextExtractor( htmlSourceContent, true);
                                     
      textPane.setText("");
      this.textPane.setEditorKit(styledEditorKit);
      textPane.setText(he.getTextOnly());
      textPane.setCaretPosition(0);
    }
    catch(Exception e)
    {
      this.textPane.setEditorKit(styledEditorKit);                      
      textPane.setText(Language.translate("Error")+": "+e.getMessage());
    }
  }

  /** problem... some tags cause a display crash !! (just a beep is emmitted, the panel remains empty).
                                                                                                       
  */
  private void displayHTMLAction()
  {                                
/*    textPane.setText("");  
    this.textPane.setEditorKit(this.hTMLEditorKit);
    String html = this.htmlSourceContent;
/    //int start = StringUtils.indexOfStartTagIgnoreCase(html, "html")+5;
    if(start>=0)
    {
      html = "`"+html.substring(start);
      //System.out.println("***"+html.substring(0,10));
    }*

    textPane.setText(html);
    textPane.setCaretPosition(0);  */

    try
    {
       HTMLCleaner hc = new HTMLCleaner(htmlSourceContent, false);
       String fContent = hc.getCleanHTMLText();
       //System.out.println(""+hc.getCleanHTMLText());

       textPane.setText("");
       this.textPane.setEditorKit(this.hTMLEditorKit);
       textPane.setText(fContent);
       textPane.setCaretPosition(0);
    }
    catch(Exception e)
    {
       this.textPane.setEditorKit(styledEditorKit);
       textPane.setText(Language.translate("Error")+": "+e.getMessage());
    }


  }

  private void displayHTMLFromTextAction()
  {
    String html = textPane.getText();
    this.textPane.setEditorKit(this.hTMLEditorKit);
    textPane.setText(html);
    textPane.setCaretPosition(0);

  }

   
  private void displayFilteredHTMLAction()
  {                                   
    try                               
    {
       HTMLCleaner hc = new HTMLCleaner(htmlSourceContent, true);
       String fContent = hc.getCleanHTMLText();
       //System.out.println(""+hc.getCleanHTMLText());

       textPane.setText("");
       this.textPane.setEditorKit(this.hTMLEditorKit);
       textPane.setText(fContent);
       textPane.setCaretPosition(0);
    }      
    catch(Exception e)
    {
       this.textPane.setEditorKit(styledEditorKit);
       textPane.setText(Language.translate("Error")+": "+e.getMessage());
    }  
  }
    

  public static void main(String[] aaa)
  {
    JFrame f = new JFrame("");
    HTMLSecureViewer hs = new HTMLSecureViewer(f, "test");
    hs.setHTMLSource("<h1>Hello</h1><br><h2>title2</h2>...");
    hs.setSize(400, 600);
    hs.setVisible(true);
       
  }
            
}  // HTMLSecureViewer
