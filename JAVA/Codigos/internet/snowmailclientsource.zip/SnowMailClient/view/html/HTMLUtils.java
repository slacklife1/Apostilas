package SnowMailClient.view.html;

import snow.utils.gui.*;

import snow.utils.storage.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.html.*;
import java.text.*;
import java.io.*;
        
                 
public class HTMLUtils
{

} // HTMLUtils

