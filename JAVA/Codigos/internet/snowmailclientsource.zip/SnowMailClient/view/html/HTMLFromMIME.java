package SnowMailClient.view.html;

import SnowMailClient.model.multipart.*;
import snow.utils.storage.*;
import SnowMailClient.*;
import SnowMailClient.html.*;

import java.util.*;
import java.io.*;

/** this class make it possible to view HTML files embedded in a mime tree, 
    with images referenced with "cid:" links

   1) extract the html content              
   2) remove the scripts, comments, meta, ...
   3) resolve the links
      the images are embedded as attachment, and references with content-id's  
   4) pack them out in a temp dir and replace links with absolute links.
*/
public class HTMLFromMIME 
{
  MimeTreeModel mimeTree;
  String htmlContent;

  public HTMLFromMIME(MimeTreeModel mimeTree) throws Exception
  {
    this.mimeTree = mimeTree;

    MimePart part = mimeTree.getFirstHTMLTextPart();
    if(part==null) throw new Exception("No HTML part !");
    htmlContent = part.getBodyAsText();

    String cont = htmlContent;
/*    HTMLCleaner hc = new HTMLCleaner(cont, false);
    htmlContent = hc.getCleanHTMLText();*/

    resolveLinks();

  } // Constructor


  public String getHTMLCodeWithLocalizedLinks()
  {
    return htmlContent;
  }


  /** 3) the links for images are in the following format
      <img ... src="cid:348240823-848289">

      A related mime parts has the content-id <cid:348240823-848289>
  */
  private void resolveLinks() throws Exception
  {
     Vector<CIDLink> cids = new Vector<CIDLink>();
     String contUP = this.htmlContent.toUpperCase();
     int pos = -5;
     while(true)
     {
        pos = contUP.indexOf("\"CID:", pos+5);
        if(pos==-1) break;   // END   

        int posEnd = contUP.indexOf("\"", pos+4);
        if(posEnd==-1)
        {
          throw new Exception("Bad content-id syntax, no closing \" found.");
        }

        String cid = contUP.substring(pos+5, posEnd);
        MimePart mp = mimeTree.getPartWithID("<"+cid+">");
        if(mp!=null)
        {
          CIDLink cl = new CIDLink(cid, pos, mp);
          cids.add(cl);
          //System.out.println("Part found, CID= "+cid);
        }
        else
        {
          // not fatal, simply not replaced...
          System.out.println("Part not found, CID= "+cid);
        }
     }

     // now, replace, from the end, all cids with absolute paths
     for(int i=cids.size()-1; i>=0; i--)
     {
        CIDLink cl = (CIDLink) cids.elementAt(i);
        int start = cl.getPosInSource()+1;
        int end = start+cl.CID.length()+4;
        htmlContent =
            htmlContent.substring(0,start)
          + "file:"+cl.getAbsolutePath()
          + htmlContent.substring(end);
     }

     //System.out.println(htmlContent);

  }


  // Utils
  //

  //private

} // HTMLFromMIME
