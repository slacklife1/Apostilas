package SnowMailClient.view.html;

import snow.utils.storage.*;
import snow.utils.gui.*;
import snow.utils.storage.*;
import snow.text.TextUtils;
import SnowMailClient.Language.Language;
import SnowMailClient.SnowMailClientApp;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.text.html.*;
import javax.swing.text.*;
import java.text.*;
import java.io.*;
import java.net.*;


/** An HTML viewer (just using the jdk editor pane).
*/
public class HTMLViewer extends JDialog
{
  final private StyledEditorKit styledEditorKit = new StyledEditorKit();
  final private HTMLEditorKit hTMLEditorKit = new HTMLEditorKit();

                             
  final JEditorPane jed = new JEditorPane();
  final JToggleButton tb = new JToggleButton("Html", true);
  JSenseButton closeBt = new JSenseButton(Language.translate("Close"));

  final JTextField linkLabel = new JTextField("");
  final JTextField linkField = new JTextField();
  final JLabel lineLabel = new JLabel();

  public static final int fontSize = UIManager.getFont("Label.font").getSize();

  final private SnowBackgroundPanel backgroundPanel = new SnowBackgroundPanel(new BorderLayout(0,0));

  public HTMLViewer(  JFrame owner,
                      String title,
                      boolean showToggleTextButton,
                      boolean modal, boolean ok
                   )                          
  {
     super(owner,title,modal); 
     
     
     getContentPane().add(backgroundPanel, BorderLayout.CENTER);

     jed.setEditable(false);  // important for HTML
     JScrollPane jsp = new JScrollPane(jed);

     backgroundPanel.add(jsp, BorderLayout.CENTER);
     jed.setOpaque(false);
     jsp.setOpaque(false);
     jsp.getViewport().setOpaque(false);

     JPanel northPanel = new JPanel();
     GridLayout3 grid = new GridLayout3(4, northPanel);
     getContentPane().add(northPanel, BorderLayout.NORTH);
     grid.add(closeBt, false);
     GUIUtils.setSmallDimensions(closeBt);
     if(showToggleTextButton)
     {
        grid.add(tb, false);  
        GUIUtils.setSmallDimensions(tb);
     }
     else
     {
        grid.add(new JLabel(""), false);
     }
     grid.add(new JLabel(" URL: "), false);
     grid.add(linkField, true);


     

     closeBt.setBackground(Color.orange);        
     closeBt.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       {
          setVisible(false);
          dispose();  
       }
     });
      
     
     
     tb.addActionListener(new ActionListener()
     {                     
       public void actionPerformed(ActionEvent e)
       {
         setContent(jed.getText());     
       }
     });
     
                      
                                                                            
     
     linkField.addActionListener(new ActionListener()
     {                     
       public void actionPerformed(ActionEvent e)
       {    
         try
         {
           URL url = new URL( linkField.getText());  
           setURL(url); 
         }
         catch(Exception ee)
         {
           //ee.printStackTrace();
           //linkLabel.setForeground(Color.red);
           linkLabel.setText("Error: "+ee.getMessage());
         }            
       }              
     });

     
     //  south
     //                                                                                         
     JPanel southPanel = new JPanel();
     southPanel.setLayout(new BoxLayout(southPanel, BoxLayout.X_AXIS));
     getContentPane().add(southPanel, BorderLayout.SOUTH);

     final JLabel lineLabel = new JLabel();
     southPanel.add(lineLabel);
     southPanel.add(linkLabel);

     lineLabel.setBorder(BorderFactory.createCompoundBorder(
       new EtchedBorder(EtchedBorder.LOWERED),
       new EmptyBorder(1,1,1,1)));
     //lineLabel.setEditable(false);
     lineLabel.setBackground(getBackground());

     linkLabel.setBorder(BorderFactory.createCompoundBorder(
       new EtchedBorder(EtchedBorder.LOWERED),
       new EmptyBorder(1,1,1,1)));
     linkLabel.setEditable(false);
     linkLabel.setBackground(getBackground());


     jed.addHyperlinkListener(new HyperlinkListener()
     {
       public void hyperlinkUpdate(HyperlinkEvent e)
       {
          linkLabel.setText(Language.translate("link")+": "+e.getURL());
         // System.out.println("descr="+e.getDescription());
         // System.out.println("elt="+e.getSourceElement());
       }
     });  
     
     jed.addCaretListener(new CaretListener()
     {  
       public void caretUpdate(javax.swing.event.CaretEvent ce)
       {
          int cp = jed.getCaretPosition();                 
          try
          {
            DefaultStyledDocument sd = (DefaultStyledDocument) jed.getDocument();
            Element elt = sd.getParagraphElement(cp);                                                           
            lineLabel.setText(Language.translate("Line")+" "+(TextUtils.getPositionInParent(elt)+1));
            //Arrays sd.getRootElements()[0];
          }
          catch(Exception e)
          {
            //e.printStackTrace();
          }
       }
     });


  } // Constructor
  
  public void animateBackground(boolean animate)
  {
    if(animate)
    {
      backgroundPanel.startAnimation();
    }
    else
    {
      backgroundPanel.stopAnimation();  
    }
  }

  public void setContentAsText(String cont)
  {
     if(tb.isSelected())
     {
       jed.setText(""); // avoid long display when toggling (better => detach listener...)
       tb.setSelected(false);
     }
     //jed.setContentType("text/plain");
     jed.setEditorKit(this.styledEditorKit);
     jed.setText(cont);
     jed.setCaretPosition(0);
  }

  public void setContent(String cont)
  {
     if(tb.isSelected())
     {
        //jed.setContentType("text/html");
        jed.setText("");
        jed.setEditorKit(this.hTMLEditorKit);
        try
        {
          jed.setText(cont);
          jed.setCaretPosition(0);
        }
        catch(Exception e)
        {
          //jed.setContentType("text/plain");
          jed.setEditorKit(this.styledEditorKit);
          jed.setText("HTML Error:"+e.getMessage()+"\n\n"+cont);
          jed.setCaretPosition(0);          
        } 
     }
     else
     {
        // jed.setContentType("text/plain");
        jed.setEditorKit(this.styledEditorKit);
        jed.setText(cont);   
        jed.setCaretPosition(0);            
     }      
  } 
  
  /** set a clicked URL
  */
  public void setURL(URL url) throws Exception
  {
    System.out.println("Clicked on "+url);
    try                  
    {      
      jed.setPage(url);
//      content
    }
    catch(Exception e)
    {
      linkLabel.setText("Error: "+e.getMessage());
    }
  }




} // HTMLViewer
