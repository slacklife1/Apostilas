package SnowMailClient.view.folders;

import SnowMailClient.model.folders.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.tree.*;
import java.awt.*;
import java.beans.*;

/** 
   ??? class DefaultTreeCellRenderer has some problems with non opaque
   backgrounds       
   ### can be optimized for performance...  see DefaultTreeCellRenderer
*/
public class FolderViewTreeRenderer extends JLabel implements TreeCellRenderer
{
  Border validDropTargetBorder = null;
  Border invalidDropTargetBorder = null;
  Border emptyBorder = null;
  int dropTargetRow = -1;    
  boolean isValid = true;
  Font normalFont, boldFont;
  

  public FolderViewTreeRenderer()
  {
    super();  
    
    setup();
    
    // recall after all themes change
    this.addPropertyChangeListener(
     new PropertyChangeListener()
     {
        public void propertyChange(PropertyChangeEvent e)
        {    
           // String name = e.getPropertyName();
            //if (name.equals("lookAndFeel"))
             {
              // SwingUtilities.invokeLater( new Runnable()
  //              {
                //   public void run()
                   {             
                     setup();
                   }
//                });
             }
        /*    else
            {
              System.out.println(">"+name);
            }*/
        }
     });

  } // Constructor

  /** must be called after each ui change
  */
  private void setup()
  {
    normalFont = UIManager.getFont("Tree.font");
    int fontSize = normalFont.getSize();
    boldFont = new  Font(normalFont.getFontName(), Font.BOLD, fontSize);

    
    emptyBorder = new EmptyBorder(fontSize/4, fontSize/2, fontSize/4, fontSize/2);
    Border emptyBorderM1 = new EmptyBorder(fontSize/4-1, fontSize/2-1, fontSize/4-1, fontSize/2-1);

    validDropTargetBorder = BorderFactory.createCompoundBorder(
           BorderFactory.createLineBorder(Color.green, 1), emptyBorderM1);

    invalidDropTargetBorder = BorderFactory.createCompoundBorder(
           BorderFactory.createLineBorder(Color.red, 1), emptyBorderM1);
  
  }  
  

    /**
     * Notification from the <code>UIManager</code> that the look and feel
     * [L&F] has changed.
     * Replaces the current UI object with the latest version from the 
     * <code>UIManager</code>.
     *
     * @see JComponent#updateUI
     */
    public void updateUI() 
    {
        super.updateUI();
        setup();
    }
  

  public void setDropTarget(int dropTargetRow, boolean isValid)
  {
    this.dropTargetRow = dropTargetRow;
    this.isValid = isValid;
  }

  public Component getTreeCellRendererComponent(
     JTree tree, Object value,
     boolean selected, boolean expanded,
     boolean leaf, int row, boolean hasFocus)
  {
    FolderTreeNode node = (FolderTreeNode) value;
   
    int n = 0;
    if(node.isSystemFolder())
    { 
      // ONLY READ SYSTEM FOLDERS, for memory reasons... 
      try
      {
        n = node.getMailFolder().getNumberOfNewMails();
      } catch(Exception e) {}
    }

    if(n>0)
    {
      this.setFont(boldFont);
    }
    else
    {
      this.setFont(normalFont);
    }

    if(row == dropTargetRow)
    {
       if(isValid) //node.getParent()!=null)
       {
         this.setBorder(this.validDropTargetBorder);
       }
       else
       {
         this.setBorder(this.invalidDropTargetBorder);
       }
    }
    else
    {                         
       this.setBorder(emptyBorder);
    }                 
    
    // background
    if(selected)
    {
       setBackground(UIManager.getColor("Tree.selectionBackground"));
       this.setOpaque(true);
    }
    else
    {
       setBackground(UIManager.getColor("Tree.textBackground"));     
       this.setOpaque(false);
    }

    this.setText(node.getFolderName()+(n>0?"  ("+n+")":""));
         
    // UGLY BUT NEcessary ??   
    this.setComponentOrientation(tree.getComponentOrientation());
//    setComponentOrientation(tree.getComponentOrientation());
  //  this.setPreferredSize( this.getPreferredSize() );

    return this;
  }



} // FolderViewTreeRenderer
