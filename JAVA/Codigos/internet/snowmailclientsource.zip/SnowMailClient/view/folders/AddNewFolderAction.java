package SnowMailClient.view.folders;

import SnowMailClient.model.folders.*;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.Language.Language;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;   
import javax.swing.tree.*;
                      
public class AddNewFolderAction extends AbstractAction implements TreeSelectionListener
{

  JTree tree; 
  FolderTreeNode parentNode;
                                
  public AddNewFolderAction( FolderTreeNode parentNode, JTree tree)
  {
    super(Language.translate("Create new folder in %",parentNode.getFolderName()));
    putValue(AbstractAction.SMALL_ICON, SnowMailClientApp.loadImageIcon("pics/createnewfolder.PNG"));
                                         
    this.tree = tree;
    this.parentNode = parentNode;
    
    tree.getSelectionModel().addTreeSelectionListener(this);
  } // Constructor

  public void valueChanged(TreeSelectionEvent e)
  {
    this.setEnabled( tree.getSelectionCount()==1 );
  }

  public void actionPerformed(ActionEvent e)
  {
    try    
    {
      TreePath selectionPath = tree.getSelectionPath();
      if(selectionPath!=null)
      {
        FolderTreeNode parentNode = (FolderTreeNode) selectionPath.getLastPathComponent();
                                           
        // ask for name
        String newFolderName = JOptionPane.showInputDialog(tree, Language.translate("Enter the new folder name"));
        if(newFolderName!=null && newFolderName.trim().length()>0)
        {        
          newFolderName = newFolderName.trim();
          if(parentNode.hasChild(newFolderName))
          {
             throw new Exception(Language.translate("Folder % alredy exists", newFolderName));
          }
          FolderTreeNode newNode = new FolderTreeNode(newFolderName, parentNode);
          tree.setSelectionPath(new TreePath(newNode.getPath()));
          // ### ugly
          tree.updateUI();
        }
      }
    }
    catch(Exception e2)
    {
      JOptionPane.showMessageDialog(tree, Language.translate("Error")+":"+e2.getMessage(), 
        Language.translate("Cannot create new folder"),
         JOptionPane.ERROR_MESSAGE);
    }
  }

} // AddNewFolderAction
