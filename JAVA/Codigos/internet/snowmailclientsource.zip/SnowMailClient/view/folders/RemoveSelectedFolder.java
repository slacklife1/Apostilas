package SnowMailClient.view.folders;

import SnowMailClient.model.folders.*;
import SnowMailClient.SnowMailClientApp;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;   
import javax.swing.tree.*;

public class RemoveSelectedFolder extends AbstractAction implements TreeSelectionListener
{

  JTree tree; 
  FolderTreeNode node;

  public RemoveSelectedFolder( FolderTreeNode node, JTree tree)
  {
    super("Remove folder"+(node!=null?" "+node.getFolderName():""));
    putValue(AbstractAction.SMALL_ICON, SnowMailClientApp.loadImageIcon("pics/delete.PNG"));
    this.tree = tree; 
    this.node = node; 
    tree.getSelectionModel().addTreeSelectionListener(this);
  } // Constructor

  public void valueChanged(TreeSelectionEvent e)
  {
    this.setEnabled( tree.getSelectionCount()==1 );
  }                            

  public void actionPerformed(ActionEvent e)
  {
     try     
     {
        //TreePath selectionPath = tree.getSelectionPath();
        if(node!=null)
        {
          //FolderTreeNode fileNode = (FolderTreeNode) selectionPath.getLastPathComponent();
          FolderTreeNode parent = node.getParentNode();  // first get parent...

          node.removeThisFolder();
                  
          
          tree.setSelectionPath(new TreePath(parent.getPath()));
                                                
          // ### ugly                
          tree.updateUI();
        }  
     }
     catch(Exception e2)
     {   
       // e2.printStackTrace();
       
       JOptionPane.showMessageDialog(tree, "Error: "+e2.getMessage(), "Cannot remove folder",
          JOptionPane.ERROR_MESSAGE);
     }
  }

} // RemoveSelectedFolder
