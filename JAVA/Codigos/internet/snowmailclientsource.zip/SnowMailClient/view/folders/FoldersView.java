package SnowMailClient.view.folders;

import SnowMailClient.SnowMailClientApp;
import SnowMailClient.model.folders.*;
import SnowMailClient.model.*;
import SnowMailClient.view.*;
import SnowMailClient.Language.Language;
import snow.utils.gui.*;
import snow.utils.storage.*;

import java.awt.*;
import java.awt.dnd.*;
import java.awt.datatransfer.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.io.*;            

/** The main folder view with Drag & Drop gesture implementation 
   to drag any mails from a folder to another mail folder
*/
public class FoldersView extends SnowBackgroundPanel
{                             
  private final JTree tree;   
  public int fontSize = UIManager.getFont("Label.font").getSize();
  // used for drag&drop
  private final SnowMailClientApp mailApp;
  final private StorageTreeModel model;
  FolderViewTreeRenderer folderViewTreeRenderer;
  // set from folderview constructor *later*
  FolderView folderView;

  final private JProgressBar loadProgress = new JProgressBar();
                    
                    
  public FoldersView(StorageTreeModel model, SnowMailClientApp mailApp)
  {
    super(new BorderLayout(0,0)); 
    this.mailApp = mailApp;
    this.model = model;
                       
    tree = new JTree(model);
    JScrollPane jsp = new JScrollPane(tree);
    add(jsp, BorderLayout.CENTER);
    jsp.getViewport().setOpaque(false);
    jsp.setOpaque(false);
    tree.setOpaque(false);


    tree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
    tree.setCellRenderer(folderViewTreeRenderer = new FolderViewTreeRenderer());
                      

    add(loadProgress, BorderLayout.SOUTH);
    loadProgress.setVisible(false);
       
    tree.setDropTarget(new TreeDropTarget());
    
                                                                                                                             
    tree.addMouseListener(new MouseAdapter()
    {  
      @Override public void mousePressed(MouseEvent e)
      {                                                                                                                                   
         if(e.isPopupTrigger()) showTreePopup(e);  //linux
      }
      @Override public void mouseReleased(MouseEvent e)
      {
         if(e.isPopupTrigger()) showTreePopup(e);  //windows
      }
    });

          
  } // Constructor
       

  

  /** listen to folder selection
      (this is called from folderView's constructor)
  */
  public void installFolderSelectionListener(FolderView folderView)
  {
    this.folderView = folderView;
    tree.addTreeSelectionListener(new TreeSelectionListener()
    {
       public void valueChanged(TreeSelectionEvent e)
       {                
          if(tree.getSelectionCount()>0)
          {    
             TreePath path = e.getPath();
             FolderTreeNode folderNode = (FolderTreeNode) path.getLastPathComponent();
             setSelectedMailFolder(folderNode);
          }                       
       }
    });
                                
    // set the initial selected folder
    String[] ps = SnowMailClientApp.getInstance().getProperties().getArrayProperty("FoldersView_selection", new String[]{});
    if(ps.length>0)                     
    {        
      final FolderTreeNode node = model.getNodeForPath(ps);
      EventQueue.invokeLater(new Runnable(){ public void run() 
      {
        tree.setSelectionPath(new TreePath(node.getPath()));
      }});
    }
  }

  /** to be called in the EDT !
      is called from the search results...
      @param selectedMess can be null. If not (when called from searchTree...)
       it select this message 
  */
  public void setSelectedFolder(final FolderTreeNode node, final MailMessage selectedMess)
  {                  
    messageToSelect = selectedMess;
    // this produces an event that will cause the call of
    // setSelectedMailFolder below later ...
    // but only if the selection has changed !!
    tree.setSelectionPath(new TreePath(node.getPath()));
    
    // to force message selection when the folder is already open... 
    // ###                                   
    setSelectedMailFolder(node);
  }

  private MailMessage messageToSelect = null;

  
  /** this install a new selected mail folder, showing a progress for long process time
      it leaves the EDT and is synchronized with this class.
  */           
  private void setSelectedMailFolder(final FolderTreeNode folderNode)
  {                             
    Thread t = new Thread()  
    {
       public void run()  
       {  
          synchronized(FoldersView.this)    
          {
             // close the old folder ?
             

             try
             {     
                if(!folderNode.isMailFolderOpened())
                {
                  EventQueue.invokeLater(new Runnable() { public void run()
                  {
                    loadProgress.setVisible(true);
                    loadProgress.setStringPainted(true);
                    loadProgress.setString(Language.translate("Opening %",folderNode.getFolderFile().getName()));
                    loadProgress.setIndeterminate(true);
                  }});
                }

                final MailFolder mf = folderNode.getMailFolder();

                EventQueue.invokeLater(new Runnable() { public void run()
                {
                  folderView.setMailFolder(folderNode, mf);
                  if(messageToSelect!=null)
                  {
                    
                    mf.setSelectedMessage( messageToSelect );
                    mf.fireTableModelHasChanged();
                  }
                }});
             }
             catch(Exception ex)   
             {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(tree, ""+ex.getMessage(),
                     Language.translate("Cannot open folder %",folderNode.getFolderName()),
                     JOptionPane.ERROR_MESSAGE);
             }
             finally         
             {     
                EventQueue.invokeLater(new Runnable() { public void run()
                {
                  loadProgress.setIndeterminate(false);
                  loadProgress.setVisible(false);
                }});    
             }
          }
       }
    };
    t.start();

  }             


  public void terminateViewAndSaveSelection(AppProperties props)
  {
     // save the selected folder
     TreePath path = tree.getSelectionPath();
     if(path!=null)
     {                          
        FolderTreeNode node = (FolderTreeNode) path.getLastPathComponent();
        String[] ps = model.getPathForNode(node);
        props.setArrayProperty("FoldersView_selection", ps);
     }
     else
     {
        props.setArrayProperty("FoldersView_selection", new String[]{});
     }
  }
   
  
  private void showTreePopup(MouseEvent e)
  {
    JPopupMenu popup = new JPopupMenu("Folders popup");
    TreePath path = tree.getPathForLocation(e.getX(),e.getY());
    if(path!=null)
    {
      FolderTreeNode node = (FolderTreeNode) path.getLastPathComponent();
      popup.add(new AddNewFolderAction(node, tree));
      try  
      {    
        if(node.getMailFolder().getRowCount()>0)
        {  
           popup.addSeparator();
           popup.add(new EmptyFolderAction(node, tree, model.getDeletedFolder()));
        }  
      }
      catch(Exception ee)
      {
        ee.printStackTrace();
      }

      if(!node.isSystemFolder())
      {        
         popup.addSeparator();
         popup.add(new RenameSelectedFolder(node, tree));
         popup.add(new RemoveSelectedFolder(node, tree));
      }

      // search in folder
      popup.addSeparator();
      popup.add(new SearchInSelectedFolder(node, tree));

      popup.show(tree, e.getX(), e.getY());
    }
  }

  // used to locate drop
  int dropX, dropY;
  boolean dropLocationValid = false;

  private void mailMessagesWereJustDroppenOnTree(int actionCopyOrMove)
  {
     folderView.isDragGestureStartedFromTable = false;

     TreePath path = tree.getClosestPathForLocation(dropX, dropY);
     if(path!=null && this.dropLocationValid)
     {
        FolderTreeNode destinationNode = (FolderTreeNode) path.getLastPathComponent();
        try
        {                       
          MailFolder destinationFolder = destinationNode.getMailFolder();
  
          FolderView folder = mailApp.getFolderView();
          if(folder!=null)
          {                          
             MailMessage[] messs = folder.getSelectedMessages();
             for(int i=0; i<messs.length; i++)
             {
                destinationFolder.addMessage(messs[i]);
                messs[i].selectedInView = false;
                // on success and in move case, not copy
                if(actionCopyOrMove==DnDConstants.ACTION_MOVE)
                {
                  folder.getMailFolder().removeMessage(messs[i]);
                }
             }
          }                
        }
        catch(Exception e)
        {
          JOptionPane.showMessageDialog(this,
              ""+e.getMessage(), 
              Language.translate("Cannot drop mail"), JOptionPane.ERROR_MESSAGE);
          //e.printStackTrace();
        }
     }
  }

  /** this is the drop target for receiving messages dragged
      at destination of the tree and initiated from the folderView.
  */
  class TreeDropTarget extends DropTarget
  {
      int oldClosestRow = -1;       

      public TreeDropTarget()
      {
        super();
        setDefaultActions(DnDConstants.ACTION_COPY_OR_MOVE);
      }

      public void dropActionChanged(DropTargetDragEvent dtde)
      {
         // remove preselection highlight
         folderViewTreeRenderer.setDropTarget(-1, false);
         oldClosestRow = -1;
         tree.repaint();
      }                    

      public void dragExit(DropTargetEvent dte)
      {
         // remove preselection highlight
         folderViewTreeRenderer.setDropTarget(-1, false);
         oldClosestRow = -1;
         tree.repaint();

         folderView.isDragGestureStartedFromTable = false;
      }


      /** show the target with a red box around
      */
      public void dragOver(DropTargetDragEvent dtde)
      {
        Point pt = dtde.getLocation();
        dropX = (int) pt.getX();
        dropY = (int) pt.getY();

        int closestRow = tree.getClosestRowForLocation(dropX, dropY);

        if(closestRow>=0)
        {                                               
           FolderTreeNode node = (FolderTreeNode) tree.getClosestPathForLocation(dropX, dropY).getLastPathComponent();
           // now, we just avoid dragging in root
           if(node.getParentNode()==null)
           {
              dropLocationValid = false;
           }              
           else
           {        
              dropLocationValid = true;
           }

           //NOT GOOD: this would load the folder !!! if(folderView.getMailFolder()==node.getMailFolder())
           // also avoid droping on the source itself
           if(node.equals(folderView.getFolderNode()))
           {
             dropLocationValid = false;
           }
        }
        
        folderViewTreeRenderer.setDropTarget(closestRow, dropLocationValid);

        if(oldClosestRow!=closestRow)
        {
          tree.repaint();
          oldClosestRow = closestRow;
        }   
        
      }
       
      public void drop(DropTargetDropEvent dtde)
      {    
        Transferable transferable = dtde.getTransferable();
        Point pt = dtde.getLocation();
        dropX = (int) pt.getX();
        dropY = (int) pt.getY();

                            
        DataFlavor[] flavors = transferable.getTransferDataFlavors();
        for(int i=0; i<flavors.length; i++)
        {
          DataFlavor flavour = flavors[i];

          if(flavour.isMimeTypeEqual("application/x-java-jvm-local-objectref; class=java.lang.String"))
          {
             if(dtde.getDropAction()==DnDConstants.ACTION_COPY
             || dtde.getDropAction()==DnDConstants.ACTION_MOVE)
             {
                dtde.acceptDrop(dtde.getDropAction());
                // only after accept, we can get the transfer data
                try
                {
                    if(folderView.isDragGestureStartedFromTable)
                    {
                       mailMessagesWereJustDroppenOnTree(dtde.getDropAction());
                    }
                }
                catch(Exception ee)
                { //??
                  ee.printStackTrace();
                }
             }
          }
        } // loop on flavors

        // suppress preselection
        folderViewTreeRenderer.setDropTarget(-1, false);
        oldClosestRow = -1;
        tree.repaint();
     }               
     
  } // TreeDropTarget

} // FoldersView
