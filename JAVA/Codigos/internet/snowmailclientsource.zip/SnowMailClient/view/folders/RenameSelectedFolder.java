package SnowMailClient.view.folders;

import SnowMailClient.model.folders.*;
import SnowMailClient.SnowMailClientApp;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;   
import javax.swing.tree.*;

public class RenameSelectedFolder extends AbstractAction implements TreeSelectionListener
{
                   
  JTree tree;  
  FolderTreeNode node;

  public RenameSelectedFolder( FolderTreeNode node, JTree tree)
  {
    super("Rename folder"+(node!=null?" "+node.getFolderName():""));
    putValue(AbstractAction.SMALL_ICON, SnowMailClientApp.loadImageIcon("pics/renamefolder.PNG"));
    this.tree = tree;
    this.node = node;                                                     
    tree.getSelectionModel().addTreeSelectionListener(this);
  } // Constructor

  public void valueChanged(TreeSelectionEvent e)
  {                        
    this.setEnabled( tree.getSelectionCount()==1 );
  }                                  

  public void actionPerformed(ActionEvent e)
  {    
     String newName = JOptionPane.showInputDialog(tree,
       "Enter the new folder name",
       "Rename folder"+(node!=null?" "+node.getFolderName():""),
       JOptionPane.QUESTION_MESSAGE);

     if(newName==null) return;


     try
     {
        if(node!=null)
        {
          FolderTreeNode parent = node.getParentNode();  // first get parent...

          node.rename(newName);

          // ### ugly                
          tree.updateUI();
        }  
     }
     catch(Exception e2)
     {   
       // e2.printStackTrace();
       
       JOptionPane.showMessageDialog(tree, "Error: "+e2.getMessage(), "Cannot rename folder",
          JOptionPane.ERROR_MESSAGE);    
     }
  }

}  // RenameSelectedFolder
