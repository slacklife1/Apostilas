package SnowMailClient.view.folders;

import SnowMailClient.model.folders.*;
import SnowMailClient.model.*;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.Language.Language;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;   
import javax.swing.tree.*;

public class EmptyFolderAction extends AbstractAction
{                      

  FolderTreeNode node;
  JTree tree;
  FolderTreeNode deletedMailsNode;
                               
  public EmptyFolderAction( FolderTreeNode node, JTree tree, FolderTreeNode deletedMailsNode )
  {
    super(Language.translate("Delete all mails in folder %",node.getFolderName()));
    putValue(AbstractAction.SMALL_ICON, SnowMailClientApp.loadImageIcon("pics/delete.PNG"));
    
    this.node = node;                                                                                                    
    this.tree = tree;
    this.deletedMailsNode = deletedMailsNode;
  } // Constructor


  public void actionPerformed(ActionEvent e)
  {                                     
     
       try
       {
         MailFolder folder = node.getMailFolder();  
         
         int reply = JOptionPane.showConfirmDialog(tree, 
            Language.translate("Are you sure you want to delete the % mails in the folder ?", ""+folder.getRowCount()),
            Language.translate("Confirm deletion"), JOptionPane.YES_NO_OPTION);
    
         if(reply==JOptionPane.OK_OPTION) 
         {
            // not working on the vector of messages but on a copy is important here !
            for(MailMessage mess: folder.getAllMessages())
            {
               if(folder.equals(deletedMailsNode.getMailFolder()))
               {
                 // definitely destroy
               }                      
               else
               {
                 // move in deleted folder
                 deletedMailsNode.getMailFolder().addMessage(mess);
               }

               folder.removeMessage(mess);
            }
         }
       }
       catch(Exception e2)
       {                                        
         JOptionPane.showMessageDialog(tree, Language.translate("Error")+": "+e2.getMessage(), 
          Language.translate("Cannot delete all mails in folder"),
            JOptionPane.ERROR_MESSAGE);

       }
     
  }

} // EmptyFolderAction
