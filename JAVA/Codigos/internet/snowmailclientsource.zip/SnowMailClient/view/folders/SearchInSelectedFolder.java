package SnowMailClient.view.folders;

import SnowMailClient.model.folders.*;
import SnowMailClient.model.*;
import snow.utils.gui.*;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.Language.Language;
import SnowMailClient.SnowMailClientApp;
                            
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;

public class SearchInSelectedFolder extends AbstractAction implements TreeSelectionListener
{
                   
  JTree tree;  
  FolderTreeNode node;

  public SearchInSelectedFolder( FolderTreeNode node, JTree tree)
  {
    super(Language.translate("Search in folder %",(node!=null?" "+node.getFolderName():"")));
    putValue(AbstractAction.SMALL_ICON,
              SnowMailClientApp.loadImageIcon("pics/find.PNG") );
    this.tree = tree;         
    this.node = node;
    tree.getSelectionModel().addTreeSelectionListener(this);
  } // Constructor                              

  public void valueChanged(TreeSelectionEvent e)
  {
    this.setEnabled( tree.getSelectionCount()==1 );
  }                                  

  public void actionPerformed(ActionEvent e)
  {
    Thread t = new Thread()
    {
      public void run()
      {
         search();
      }
    }; 
    t.setPriority(Thread.NORM_PRIORITY-1);   
    t.start();

  }
  
  /** Should be called in a separate thread !
  */
  private void search()
  {                                 
     String searchText = JOptionPane.showInputDialog(tree,
       Language.translate("Enter the text to search in the folder"),
       Language.translate("Text search in folder")+(node!=null?" "+node.getFolderName():""),
       JOptionPane.QUESTION_MESSAGE);

     if(searchText==null) return;

     ProgressModalDialog progressDialog = new ProgressModalDialog(
         SnowMailClientApp.getInstance(), 
         Language.translate("Searching")+"...", false);
     progressDialog.start();

     try
     {
        final SearchResults sr = new SearchResults();  
        SnowMailClientApp.getInstance().getSearchPanel().setModel(sr);  
        EventQueue.invokeLater(new Runnable() { public void run() {
          SnowMailClientApp.getInstance().makeSearchTreeVisible(); 
        }});

        node.searchMailMessagesContaining(searchText, sr, true);

     }
     catch(Exception e2)
     {
       e2.printStackTrace();
       JOptionPane.showMessageDialog(tree,
         Language.translate("Error")+": "+e2.getMessage(),
         Language.translate("Error occured during folder text search"),
          JOptionPane.ERROR_MESSAGE);
     }
     finally
     {
       progressDialog.closeDialog();
     }
  }

}  // SearchInSelectedFolder
