package SnowMailClient.view;

import SnowMailClient.view.folders.*;
import SnowMailClient.view.actions.*;         
import snow.SortableTable.*;
import snow.utils.storage.*;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.model.*;
import SnowMailClient.model.events.*;
import SnowMailClient.model.folders.*;
import snow.utils.gui.*;
import SnowMailClient.model.folders.*;
import SnowMailClient.Language.Language;
                       
import java.awt.*;
import java.awt.dnd.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.beans.*;

                   
/** view one folder (inbox, ...)
  + search feature
*/
public class FolderView extends SnowBackgroundPanel implements
     ListSelectionListener,
     MailFolderListener
{
  private final JTable table = new JTable();
  private final JLabel northLabel = new JLabel("");
  MailFolder folder;
  FolderTreeNode folderNode;

  FoldersView foldersView;
  MailView mailView;

  SortableTableModel sortableTableModel;
  AdvancedSearchPanel searchPanel;

  AppProperties props;

  public int fontSize = UIManager.getFont("Label.font").getSize();
  final private DeleteMailAction deleteMailAction;

  public FolderView(AppProperties props, final FoldersView foldersView, MailView mailView)
  {
    super(new BorderLayout(0,0));

    this.props = props;
    this.foldersView = foldersView;
    this.mailView = mailView;

    deleteMailAction = new DeleteMailAction(FolderView.this, SnowMailClientApp.getInstance().getFoldersModel().getDeletedFolder());
    this.registerKeyboardAction( deleteMailAction,
                                 KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0, true),
                                 JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT );


    JScrollPane jsp = new JScrollPane(table);


    jsp.getViewport().setOpaque(false);
    jsp.setOpaque(false);
    table.setOpaque(false);
    add(jsp, BorderLayout.CENTER);

    // North
    //
    JPanel northPanel = new EFCNBackgroundPanel(new BorderLayout(),
      EFCNBackgroundPanel.ApplyVerticalHighLight,
      EFCNBackgroundPanel.MediumGradientStrength,
      EFCNBackgroundPanel.PanelBackground   
    );  
      
    northPanel.add(northLabel, BorderLayout.WEST);
    northLabel.setFont(new Font("Dialog", Font.BOLD, fontSize+2));

    add(northPanel, BorderLayout.NORTH);
    northPanel.setBorder(BorderFactory.createEmptyBorder(fontSize/2,fontSize,fontSize/2,fontSize/2));
    northLabel.setOpaque(false);


    searchPanel = new AdvancedSearchPanel(Language.translate("Search: "), null, sortableTableModel, false);
    northPanel.add(searchPanel, BorderLayout.EAST);
    
    searchPanel.addSearchChangeListener(new ChangeListener()
    {
      public void stateChanged(ChangeEvent ce)
      {
          updateTitleLabel();

          // select the first if no selection
          if(getTableSelectionCount()==0 && table.getRowCount()>0)
          {
            table.getSelectionModel().setSelectionInterval(0,0);
          }
      }
    });

    // listen to tree selections
    foldersView.installFolderSelectionListener(this);
                  

    table.getSelectionModel().addListSelectionListener(this);

    installDragAndPopup();

    this.addPropertyChangeListener(
     new PropertyChangeListener()
     {
        public void propertyChange(PropertyChangeEvent e)
        {
            String name = e.getPropertyName();
            if (name.equals("ancestor"))
             {
               SwingUtilities.invokeLater( new Runnable()
                {                      
                   public void run()
                   {
                     updateSpecialUI();
                   }
                });
             }
        }
     });
    

  } // Constructor
  
  
  private void updateSpecialUI()
  {   
     fontSize = UIManager.getFont("Label.font").getSize();
     northLabel.setFont(new Font("Dialog", Font.BOLD, fontSize+2));
  }
  
  /** and the mouse listener
  */
  private void installDragAndPopup()
  {

    MouseListener ml = new MouseAdapter()
    {
        @Override public void mousePressed(MouseEvent e)
        {
            if(e.isPopupTrigger())
            {
               displayPopup(e);
            }
        }

        @Override public void mouseReleased(MouseEvent e)
        {
            // important: deactivate the drag info used by the folders tree !
            isDragGestureStartedFromTable = false;
            if(e.isPopupTrigger())
            {
               displayPopup(e);
            }
        }         
         
        public void displayPopup(MouseEvent e)
        {
           JPopupMenu menu = new JPopupMenu("Mail folder table popup");
           if(getTableSelectionCount()>0)
           {
              menu.add(new AddToSpamAction(FolderView.this));
              menu.add(new AddToHAMAction(FolderView.this));
              menu.add(new RemoveSPAMCategory(FolderView.this));
              menu.addSeparator();
              menu.add(new CopyMessagesToClipboardAsText(FolderView.this));
              menu.addSeparator();
              menu.add(deleteMailAction);

              if(SnowMailClientApp.debug)
              {
                menu.addSeparator();
                JMenuItem parseDebug = new JMenuItem("Parse debug");
                menu.add(parseDebug);
                parseDebug.addActionListener(new ActionListener(){
                  public void actionPerformed(ActionEvent ae)
                  {
                    MailMessage[] mess = getSelectedMessages();
                    for(int i=0; i<mess.length; i++)
                    {
                      MailMessage mm = new MailMessage();
                      mm.debug = true;
                      mm.parse(mess[i].getCompleteContentAsString());
                    }

                  }
                });
              }      

           }

           menu.show(table, e.getX(), e.getY());
                       
        }         
    };  
    
    table.addMouseListener(ml);
                       
    table.setDragEnabled(true);

    MailDnDTransferHandler mdth = new MailDnDTransferHandler("FolderView", this);
    table.setTransferHandler(mdth);
    
    // This detects the drags initiated from the table
    //
    DragGestureRecognizer dr = DragSource.getDefaultDragSource().createDefaultDragGestureRecognizer(
      table,
      DnDConstants.ACTION_COPY_OR_MOVE,
      new DragGestureListener()
      {
         public void dragGestureRecognized(DragGestureEvent dge)
         {
            //System.out.println("Drag gesture started on table");
            isDragGestureStartedFromTable = true;
            // ### draw
         }
      }); 
       
    
      
    // Global
    /*DragSource.getDefaultDragSource().addDragSourceListener(new DragSourceListener()
    {
        public void dragDropEnd(DragSourceDropEvent dsde)
        {
          System.out.println("End");
        }
        public void dragEnter(DragSourceDragEvent dsde)
        {
          System.out.println("Enter "+dsde.getSource().getClass());
        }
        public void dragExit(DragSourceEvent dse)
        {
          //System.out.println("Exit");
        }
        public void dragOver(DragSourceDragEvent dsde)
        {
          //System.out.println("Over");
        }
        public void dropActionChanged(DragSourceDragEvent dsde)
        {
          //System.out.println("ActionChanged "+dsde);
        }
    }); */  

  }
  
  public boolean isDragGestureStartedFromTable = false;
   

  /** used to to enable/disable actions
  */
  public synchronized ListSelectionModel getTableSelectionModel() 
  {
    return table.getSelectionModel();
  }
  public synchronized int getTableSelectionCount() { return table.getSelectedRowCount(); }
  public synchronized int getTableRowCount() { return table.getRowCount(); }
                          

  /** Set the displayed mail folder
  */
  public synchronized void setMailFolder(FolderTreeNode newFolderNode, MailFolder newFolder)
  {       
    if(!SwingUtilities.isEventDispatchThread()) new Throwable("must be EDT").printStackTrace();

    if(newFolder!=null)
    {          
      //System.out.println("FolderView: set mail folder "+newFolder.getFolderName());
    }
    else
    {
      //System.out.println("FolderView: set mail folder null.");
    }

    // deinstall old listeners on the old folder
    if(this.folder!=null)
    {
       folder.removeMailFolderListener(this);
       if(sortableTableModel!=null)
       { 
         // store the sorted column in the model
         folder.saveSortedColumnFromView(
                  sortableTableModel.getSortedColumn(),
                  sortableTableModel.getSortOrderIsAscending());
       }
    }
    
    boolean isNewFolder = ( this.folder != newFolder );

    // install the new folder
    this.folder = newFolder;
    this.folderNode = newFolderNode;
                                      
    if(folder!=null)
    {
      folder.addMailFolderListener(this);


      if(this.sortableTableModel!=null)
      {
         // subsequent folder changes only the basic model. 
         sortableTableModel.setBasicTableModel(folder,
                folder.getSortedColumn(),
                folder.getIsSortingAscendingOrder()
         );
      }
      else
      {
         // only created once, for the first folder
         sortableTableModel = new SortableTableModel(folder,
                folder.getSortedColumn(), folder.getIsSortingAscendingOrder());
         table.setModel(sortableTableModel);
         sortableTableModel.installGUI(table);
         searchPanel.setSortableTableModel(sortableTableModel);

         table.setDefaultRenderer(Object.class, new FolderViewTableCellRenderer(this, sortableTableModel));
         table.getColumnModel().getColumn(3).setMaxWidth(fontSize*12);
         table.getColumnModel().getColumn(3).setMinWidth(fontSize*12);
         table.getColumnModel().getColumn(4).setMaxWidth(fontSize*7);  // size
         table.getColumnModel().getColumn(5).setMaxWidth(fontSize*2);  // Spam
      }
      
      
      setVisible(true);
    }
    else      
    {
      setVisible(false);                       
    }     
                          
    // select the first if no selection
    if(getTableSelectionCount()==0 || isNewFolder )
    {      
      if(table.getRowCount()>0)
      {
        //System.out.println("Select the first message");
        // select the first message   
        table.getSelectionModel().setSelectionInterval(0,0);
      } 
    }

    updateTitleLabel();
  }                   
                 

  public synchronized MailFolder getMailFolder() 
  {           
    return folder; 
  }  
            
  
  public synchronized FolderTreeNode getFolderNode() 
  { 
    return folderNode; 
  }

  
  /** contain the number of mails, of new mails and of filtered mails.
  */
  private synchronized void updateTitleLabel()
  {        
    if(folder!=null)
    {
       String name = folder.getFolderName(); 
       int numberOfMails = folder.getRowCount();
       int nn = folder.getNumberOfNewMails();
       name += "   ["+numberOfMails+" "+Language.translate("mail")+(numberOfMails==1?"":"s");
       if(nn>0)
       {
         name += ", "+nn+" "+Language.translate("new");
       }

       int found = this.sortableTableModel.getRowCount();
       if(sortableTableModel.isSearchActive())
       {                               
         name += ", "+found+" "+Language.translate("matching search");
       }

       name+="]"; 
       
       if(folder.hasContentChanged()) name += "  (*)";
       northLabel.setText(name);
    }                         
    else
    {
       northLabel.setText(Language.translate("No folder selected"));
    }
  }                          
                               
  private MailMessage selectedMessage = null;


  //
  // MailFolderListener
  //
  
  public void folderSizeChanged()
  {
    //System.out.println("Folder size changed");
    updateTitleLabel();
  }

  public void folderStored()
  {
    //System.out.println("Folder stored");
    updateTitleLabel();
  }    
  
  /** the folder was closed from outside !
      maybe to free memory.
  */
  public void folderClosed()
  {
    // We must close the view too !!
    // deinstall old listeners on the old folder
/*    if(this.folder!=null)
    {
       folder.removeMailFolderListener(this);   // CONCURENT MODIFICATION !!! => BAD BAD BAD
       if(sortableTableModel!=null)
       {
         // store the sorted column in the model
         folder.saveSortedColumnFromView(
                  sortableTableModel.getSortedColumn(),
                  sortableTableModel.getSortOrderIsAscending());
       } 
       folder = null;
       this.folderNode = null;

       //setVisible(false);
    }*/
  }
  
  /**  called when one of the messages i nthis folder has been edited
  */
  public void folderContentEdited(MailMessageChangeListener.MailMessageChangeType change)
  {                      
    if(change == MailMessageChangeListener.MailMessageChangeType.IN_EDITION)
    {
      // DO nothing
      System.out.println("FolderView: in edition");
    }
    else
    {
       // update the table data (from, to , subject, date !)
       //table.invalidate();
       table.repaint();
    }
    updateTitleLabel();
  }


  /** called from the search results selection
      should be called in the EDT
  */
  public synchronized void setMessageToView(MailMessage mess)
  {
    new Throwable().printStackTrace();
    
    // ok, already selected
    if(this.selectedMessage==mess) return;
    if(this.folder==null) return;  // nothing to search
    
    for(MailMessage mi: folder.getAllMessages())
    {
       //MailMessage mi = folder.getMessageAt(i);
       if(mi==mess)
       {
         mi.selectedInView = true;
       }
       else
       {
         mi.selectedInView = false;
       }
    }
    folder.fireTableRowsUpdated(0, folder.getRowCount()-1);
  }                  


  /** selection listener, multiple selection is allowed,
      this looks if the message is already selected, it doesn't change
  */
  public synchronized void valueChanged(ListSelectionEvent eBof)
  {  
    // ? 
    //if(this.isDragGestureStartedFromTable) return;
    
    
    int[] tableSelection = table.getSelectedRows();
    // 1: look if the selected message is in the list
    for(int i=0; i<tableSelection.length; i++)
    {
      int modelPos = this.sortableTableModel.getIndexInUnsortedFromTablePos(tableSelection[i]);
      MailMessage message = folder.getMessageAt(modelPos);
      if(message==selectedMessage && message!=null)
      {
        return;  // do nothing, it is already selected !!
      }
    }                        

    // it is not in the list => show the first
    if(tableSelection.length>0)
    {
      int modelPos = this.sortableTableModel.getIndexInUnsortedFromTablePos(tableSelection[0]);      
      MailMessage message = folder.getMessageAt(modelPos);
      mailView.setMessage( message );
      selectedMessage = message;
    }         
    else
    {
      // or nothing if no selection         
      mailView.setMessage(null);
      selectedMessage = null;
    }
  }
  
  /** return the selected messages        
  */
  public synchronized MailMessage[] getSelectedMessages()
  {
    int[] rowTable = table.getSelectedRows();
    MailMessage[] selMess = new MailMessage[rowTable.length];
    for(int i=0; i<selMess.length; i++)
    {
      int modelPos = this.sortableTableModel.getIndexInUnsortedFromTablePos(rowTable[i]);
      selMess[i] = folder.getMessageAt(modelPos);
    }
    return selMess;
  }
  
  /** called from the remove selected mail action
    ### problem, when the table event come (because remove),
      the table is re-sorted and the sel-1 is sometimes bad positioned
  */
  public void removeMail(MailMessage mess) throws Exception
  {
    int sel = table.getSelectedRow();

    this.getMailFolder().removeMessage(mess);
     
    // select next mail
    if( table.getRowCount()==0) 
    {
      return;  // no chance !
    }

    if(sel>=0 && sel<table.getRowCount())
    {
      table.setRowSelectionInterval(sel,sel);
    }                                                                              
    else if(sel-1>=0 && sel-1<table.getRowCount())
    {
      table.setRowSelectionInterval(sel-1,sel-1);
    }
  }

} // FolderView
