package SnowMailClient.view;

import SnowMailClient.SnowMailClientApp;
import SnowMailClient.Language.Language;
import SnowMailClient.SpamFilter.*;
import SnowMailClient.model.*;
import SnowMailClient.model.multipart.*;
import SnowMailClient.model.accounts.*;
import SnowMailClient.model.events.*;
import snow.utils.gui.*;                
import snow.SortableTable.*;
import snow.lookandfeel.*;
import SnowMailClient.html.*;
import SnowMailClient.html.HTMLTextExtractor;
import SnowMailClient.view.html.*;
import SnowMailClient.view.traceView.*;
import SnowMailClient.view.attachments.*;
import SnowMailClient.GnuPG.GnuPGLink;
import SnowMailClient.GnuPG.model.*;
import SnowMailClient.GnuPG.Main.GnuPGCommands;
import SnowMailClient.keyboard.*;    
                    
import java.awt.*;
import java.awt.event.*;
import java.text.*;
import javax.swing.*;
import javax.swing.undo.*;
import javax.swing.event.*;
import javax.swing.text.*;        
import javax.swing.border.*;
import javax.swing.plaf.basic.BasicComboBoxEditor;

import java.util.*;
import java.io.ByteArrayInputStream;
import java.beans.*;

                                           
/** Displays or Edits a Single Mail Message.
*   
*/                     
public final class MailView extends SnowBackgroundPanel     
                      implements UndoableEditListener, MailMessageChangeListener
{                   
  // parameters                                        
  private final static int TimeToMarkAsRead = 1000*5;

  // a single instance is made and kept for the whole time
  private final ViewTextDialog fullMailContentView;
  private final HTMLSecureViewer hTMLViewer;

  private int fontSize = UIManager.getFont("Label.font").getSize();

  private MailMessage message;
  private final JTextPane textPane = new JTextPane();
  private JPanel headerPanel = null;
  private JScrollPane jsp;
  private final UndoManager undoManager = new UndoManager();
  private boolean undoEnabled = true;

  private final JComboBox  fromFieldCB  = new JComboBox();
  private final JTextField toField      = new JTextField(12);  // recipients

  private final JCheckBox encryptCB = new JCheckBox(Language.translate("encrypt"));
  private final JCheckBox signCB = new JCheckBox(Language.translate("sign"));

  private final JPanel encryptCBPanel = new JPanel();
  private final JPanel signCBPanel = new JPanel();


  private final JTextField subjectField = new JTextField(25);
  private final JTextField searchTF = new JTextField(4);

  private final JTextArea errorLabel = new JTextArea();
  private final JTextArea mailStatusLabel = new JTextArea();  // sent, received, not sent, encrypted

  private final JSplitPane multipartSlit;
  private final MimeTreePanel mimeTreePanel;

  final private JSenseButton optionsButton = new JSenseButton(Language.translate("Options"));
  final private JSenseButton decryptButton = new JSenseButton(Language.translate("Decrypt"));
  final private JSenseButton verifyButton  = new JSenseButton(Language.translate("Verify signature"));
  final private JSenseButton browseAddressButton = new  JSenseButton(Language.translate("To")+": ");

  final private JSenseButton attachmentsButton = new  JSenseButton(Language.translate("Attachments")+": ");
  final private AttachmentBar attachementsPanel = new AttachmentBar();

                         
  // add to spam, remove, add to address...
  final private JSenseButton fromOptionsButton = new  JSenseButton(Language.translate("From")+": ");

  private boolean contentHasChanged = false;
           
  private final JSenseButton fromCategoryButton = new JSenseButton("   ");

  // used to decide if message has been read...
  private long setMessageTime = 0;

  // #### problem with actionListener : a set of the value when message changes call the listener !!
  // so we activate/deactivate it manually
  private final ItemListener fromFieldItemListener;
                           
  // created on first call 
  private KeyboardDialog keyboardDialog;
                      
  

  public MailView( MailAccounts accounts)
  {
    super(new BorderLayout(0,0));

    fullMailContentView = new ViewTextDialog("fullMailContentView", 
         Language.translate("Full mail message content"), false);


    hTMLViewer = new HTMLSecureViewer(SnowMailClientApp.getInstance(),
       Language.translate("HTML Viewer"));
    SnowMailClientApp.getInstance().getProperties().setComponentSizeFromINIFile(
       hTMLViewer, "hTMLViewer", fontSize*55,fontSize*65, 50,50);

    jsp = new JScrollPane(textPane);
    jsp.setBorder(null);

    // header
    //             
    headerPanel = new EFCNBackgroundPanel(new BorderLayout(0,0),
      EFCNBackgroundPanel.ApplyVerticalHighLight,
      EFCNBackgroundPanel.MediumGradientStrength,
      EFCNBackgroundPanel.PanelBackground
    );
              
    add(headerPanel, BorderLayout.NORTH);
    headerPanel.setOpaque(false);
    //Color bg = headerPanel.getBackground();
    //headerPanel.setBackground(new Color(bg.getRed(), bg.getGreen(), bg.getBlue(), 240));

    mimeTreePanel = new MimeTreePanel();
    mimeTreePanel.setAttachementsQuickPanel(this.attachementsPanel);

    multipartSlit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
       mimeTreePanel,
       jsp);
    add(multipartSlit, BorderLayout.CENTER);
    multipartSlit.setDividerLocation(0);
    multipartSlit.setOneTouchExpandable(true);
    multipartSlit.setOpaque(false);

    jsp.setOpaque(false);
    jsp.getViewport().setOpaque(false);
    textPane.setOpaque(false);


    JPanel fromToSubjPanel = new JPanel( );
    GridLayout3 gl = new GridLayout3(3,fromToSubjPanel);

    fromToSubjPanel.setOpaque(false);
    fromToSubjPanel.setBorder(new EmptyBorder(fontSize/2,fontSize/2,fontSize/2,fontSize/2));
    headerPanel.add(fromToSubjPanel, BorderLayout.CENTER);

    // From

    gl.add(fromOptionsButton, false);
    setButtonSmallHeight(fromOptionsButton);
    gl.add(fromFieldCB, true);
    signCBPanel.add(this.signCB);
    signCBPanel.setOpaque(false);
    signCBPanel.setBorder(null);
    signCB.setBorder(null);
    gl.add(this.signCBPanel,false);
    fromFieldCB.setOpaque(false);
    signCB.setOpaque(false);
    fromOptionsButton.addActionListener(new ActionListener()
      { public void actionPerformed(ActionEvent e)
        {
           addressMenuPressed();
        }
      });
    signCB.addActionListener(new ActionListener()
      { public void actionPerformed(ActionEvent e)
        {
           //
           if(message!=null)
           {
              message.setMustBeSigned(signCB.isSelected());
           }
        }
      });

    // To

    gl.add( browseAddressButton, false);
    setButtonSmallHeight(browseAddressButton);
    gl.add( toField, true);
    this.encryptCBPanel.add(this.encryptCB);
    encryptCB.setBorder(null);
    this.encryptCBPanel.setOpaque(false);
    encryptCBPanel.setBorder(null);
    gl.add(encryptCBPanel,false);
    toField.setOpaque(false);
    encryptCB.setOpaque(false);
    encryptCB.addActionListener(new ActionListener()
      { public void actionPerformed(ActionEvent e)
        {
           //
           if(message!=null)
           {
              message.setMustBeEncrypted(encryptCB.isSelected());
           }
        }
      });        

    // Subject             

    gl.add(new JContrastLabel(Language.translate("Subject")+": "), false);
    gl.add(subjectField, true);  
    JLabel la = new JLabel("");
    la.setBorder(null);
    gl.add(la,false);
    subjectField.setOpaque(false);
    

    // Map tab to focus on the text  ### not working
    subjectField.addKeyListener(new KeyAdapter()
    {
      @Override public void keyTyped(KeyEvent ee)
      {                   
         if(ee.getKeyCode()==KeyEvent.VK_TAB)
         {
            textPane.requestFocus();
         }
      }
    });

    // Attachments 
    gl.add(attachmentsButton, false);
    setButtonSmallHeight(attachmentsButton);
    gl.add(attachementsPanel, true);
    attachementsPanel.setLayout(new BoxLayout(attachementsPanel, BoxLayout.X_AXIS));
    attachmentsButton.addActionListener(new ActionListener()
    {         
       public void actionPerformed(ActionEvent ae)
       {  
         attachmentButtonPressed();
       }
    });




    // Options

    JPanel optionsPanel = new JPanel();
    optionsPanel.setBorder(new EmptyBorder(2,0,0,2));
    optionsPanel.setLayout(new BoxLayout(optionsPanel, BoxLayout.Y_AXIS));
    optionsPanel.setOpaque(false);
    headerPanel.add(optionsPanel, BorderLayout.EAST);


    optionsButton.setEnabled(false);
    optionsButton.setFont(ThemesManager.getInstance().getSmallFont());
    optionsPanel.add(SnowMailClientApp.wrapRight(optionsButton));
    this.setButtonSmallHeight(optionsButton);
    optionsButton.addActionListener(new ActionListener()                                                        
      { public void actionPerformed(ActionEvent e)
        {                      
          optionsButtonPressed();
        }                                                                                                    
      });
        
    optionsPanel.add(SnowMailClientApp.wrapRight(decryptButton));
    decryptButton.setFont(ThemesManager.getInstance().getSmallFont());
    decryptButton.setBackground(Color.orange);
    this.setButtonSmallHeight(decryptButton);        
    decryptButton.addActionListener(new ActionListener()                                                        
      { public void actionPerformed(ActionEvent e)
        {  
          decryptButtonPressed();
        }
      });    

    optionsPanel.add(SnowMailClientApp.wrapRight(verifyButton));
    verifyButton.setFont(ThemesManager.getInstance().getSmallFont());
    verifyButton.setBackground(Color.orange);
    this.setButtonSmallHeight(verifyButton);              
    verifyButton.addActionListener(new ActionListener()
      { public void actionPerformed(ActionEvent e)
        {
          verifyButtonPressed();
        }                      
      });
          
    JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT,0,0));
    searchPanel.setOpaque(false);
    optionsPanel.add(searchPanel);
    searchPanel.add(new JContrastLabel(Language.translate("Search")+": "));
    searchPanel.add(searchTF);
    searchTF.addKeyListener(new KeyAdapter()
    {
      @Override public void keyReleased(KeyEvent ee)
      {
         if(ee.getKeyCode()==KeyEvent.VK_ENTER)
         {
            searchText(searchTF.getText(), true);
         }                                       
         else
         {
            searchText(searchTF.getText(), false);
         }
      }             
    });  
    searchTF.addFocusListener(new FocusListener()
    { 
       public void focusGained(FocusEvent e)
       {
          searchTF.selectAll();
       }
       public void focusLost(FocusEvent e)
       {
       }       
    });          

    Vector<String> accountNamesToSend = new Vector<String>();
    String[] accNames = new String[accounts.getRowCount()];
    for(int i=0; i<accNames.length; i++)
    {
       MailAccount ma = accounts.getAccount(i);
       if(ma.getUseToSendMails())                                                               
       {                                      
          accountNamesToSend.addElement("\""+ma.getName()+"\" <"+ma.getAddress()+">");
       }
    }

    fromFieldCB.setModel(new DefaultComboBoxModel(accountNamesToSend));
    fromFieldCB.setEditable(true);

    // focus cycle and edit notify

    if(fromFieldCB.getEditor().getEditorComponent() instanceof JComponent)
    {
      ((JComponent) fromFieldCB.getEditor().getEditorComponent()).setOpaque(false);
    }

    fromFieldCB.getEditor().addActionListener(new ActionListener()
      { public void actionPerformed(ActionEvent e)
        {
          toField.requestFocus();
        }
      });

    toField.addActionListener(new ActionListener()
      { public void actionPerformed(ActionEvent e)
        { 
          setBrowseAddressesButtonText();  // TODO: also in the keylistener !
          subjectField.requestFocus();
        }
      });

    browseAddressButton.addActionListener(new ActionListener()
      { public void actionPerformed(ActionEvent e)
        {
          browseToAddressAction();
        }
      });

    subjectField.addActionListener(new ActionListener()
      { public void actionPerformed(ActionEvent e)
        {
          textPane.requestFocus();
        }       
      });                        
      
    JPanel statusPanel = new JPanel();
    statusPanel.setLayout(new BoxLayout(statusPanel, BoxLayout.Y_AXIS));
    statusPanel.add(this.mailStatusLabel);

    statusPanel.add(this.errorLabel);

    mailStatusLabel.setVisible(false);
    mailStatusLabel.setOpaque(false);
    mailStatusLabel.setBorder(new EmptyBorder(1,3,1,1));
    mailStatusLabel.setEditable(false);

    headerPanel.add(statusPanel, BorderLayout.SOUTH);
    errorLabel.setVisible(false);
    errorLabel.setOpaque(false);
    errorLabel.setBorder(new EmptyBorder(1,3,1,1));
    errorLabel.setForeground(Color.red);
    errorLabel.setEditable(false);


    KeyAdapter headerEditionKeyAdapter = new KeyAdapter()
    {
      @Override public void keyReleased(KeyEvent e)
      {
         saveActualEditedHeader();
      }
    };     
    
    // message textPane
    //
    textPane.addKeyListener(new KeyAdapter()
    {
      @Override public void keyReleased(KeyEvent e)
      {   
         // through the message's change event mechanism
         notifyContentEditionListeners();
      }
    });
    DefaultStyledDocument doc = (DefaultStyledDocument) textPane.getStyledDocument();
    doc.addUndoableEditListener(this);


    this.registerKeyboardAction( new ActionListener(){ public void actionPerformed(ActionEvent e){ undo(); }},
                                               KeyStroke.getKeyStroke(KeyEvent.VK_Z, KeyEvent.CTRL_MASK, true),
                                               JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT );

    this.registerKeyboardAction( new ActionListener(){ public void actionPerformed(ActionEvent e){ redo(); }},
                                               KeyStroke.getKeyStroke(KeyEvent.VK_R, KeyEvent.CTRL_MASK, true),
                                               JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT );

    this.registerKeyboardAction( new ActionListener()
       {
         public void actionPerformed(ActionEvent e)
         {
             searchTF.requestFocus();
             searchTF.selectAll();       
         }
       },
       KeyStroke.getKeyStroke(KeyEvent.VK_F, KeyEvent.CTRL_MASK, true),
                                               JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT );


    Style defaultStyle = //StyleContext.getDefaultStyleContext().getStyle(StyleContext.DEFAULT_STYLE);
                           textPane.getStyle("default");

    Style searchHitStyle = doc.addStyle("SearchHit", defaultStyle);
    StyleConstants.setBackground(searchHitStyle, Color.yellow);
    StyleConstants.setBold(searchHitStyle, true);


                                                                                                                 
    toField.addKeyListener(headerEditionKeyAdapter);
    subjectField.addKeyListener(headerEditionKeyAdapter);
    BasicComboBoxEditor cbeditor = (BasicComboBoxEditor) fromFieldCB.getEditor();
    cbeditor.getEditorComponent().addKeyListener(headerEditionKeyAdapter);
                                          
    // #### problem with actionListener : a set of the value when message changes call the listener !!
    // so we activate/deactivate it manually         
    fromFieldItemListener = new ItemListener()
    {
      public void itemStateChanged(ItemEvent e)
      {
         if(e.getStateChange()==ItemEvent.SELECTED)
         {
           saveActualEditedHeader();
         }
      }
    };
    fromFieldCB.addItemListener(fromFieldItemListener);


    this.textPane.addPropertyChangeListener(
     new PropertyChangeListener()
     {
        public void propertyChange(PropertyChangeEvent e)
        {
            String name = e.getPropertyName();
            if (name.equals("UI"))
             {
               SwingUtilities.invokeLater( new Runnable()
                {
                   public void run()
                   {
                     updateSpecialUI();
                   }
                });
             }
        /*    else   
            {
              System.out.println(">"+name);
            }*/  
        }
     });

     // init
     EventQueue.invokeLater(new Runnable()
     {
       public void run()
       {         
         setMessage(message); // normally null at startup, but not always !!!!
       }
     });
  } // initialize
  
  
  

  public void hideAttachmentSplit()
  { 
     multipartSlit.setDividerLocation(0);
  }
  
  public void mailMessageChanged(MailMessage source, MailMessageChangeListener.MailMessageChangeType type, String detail )
  {
     if(type==MailMessageChangeListener.MailMessageChangeType.DECRYPTED)
     {  
        // enforce repaint, everything have changed!
        MailMessage actual = this.message;
        this.setMessage(null);
        this.setMessage(actual);
     }
  }


  //
  // UNDO
  //     

  /** called at each changes of the edited document (insert, delete).
     are added to the undo manager to be redoed.
     also notifies the edition listeners.
  */
  public void undoableEditHappened(UndoableEditEvent e)
  {
    if(undoEnabled)
    {
      undoManager.addEdit(e.getEdit());
    }

    // used this occasion to notify the edition listeners
    this.notifyContentEditionListeners();
  } 
  
  /** for the undo manager or CTRL + Z
  */
  public void undo()
  {
     try
     {
        if(undoManager.canUndo())
        {  
          undoManager.undo();
        }
     }
     catch(Exception cue)
     {
        // not only UndoExceptions....
        cue.printStackTrace();
     }
  }


  public void redo()
  {
     try
     {
        if(undoManager.canRedo())
        {
          undoManager.redo();
        }
     }
     catch(Exception cue)
     {
        // not only UndoExceptions....
        cue.printStackTrace();
     }
  } 
             
  private void attachmentButtonPressed()
  { 
    if(message==null) return;
    JPopupMenu popup = new JPopupMenu("Attachment popup");
    if(message.isEditable())
    {
      JMenuItem miAddAttachment = new JMenuItem(Language.translate("Add attachment"));
      popup.add(miAddAttachment);
      miAddAttachment.addActionListener(new ActionListener()
      {                                                                                                            
        public void actionPerformed(ActionEvent ae)
        {                                                                                                       
           mimeTreePanel.addAttachmentAction();
        }
      });                          
    }

    JMenuItem miShowMimeTree = new JMenuItem(Language.translate("Show mime tree"));
    popup.add(miShowMimeTree);
    miShowMimeTree.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent ae)
      {
        if(multipartSlit.getDividerLocation()<120)
        {
          multipartSlit.setDividerLocation(120);
        }
      }
    }); 
                            
    

    popup.show( this.attachmentsButton, 0, 20);

  }
  
  private void verifyButtonPressed()
  {
    if(message==null) return;
    if(!message.lookIfContentIsPGPSigned())
    {
      JOptionPane.showMessageDialog(SnowMailClientApp.getInstance(),
        Language.translate("The message is not in GPG format"),
        Language.translate("Cannot decrypt mail"), JOptionPane.ERROR_MESSAGE);
    }   

    try
    {
      System.out.println("Verify signature of:\n" + message.getMessageBody());

      GnuPGLink gpg = SnowMailClientApp.getInstance().getGnuPGLink();
      ByteArrayInputStream bin = new ByteArrayInputStream(message.getMessageBody().getBytes());
      Vector<SignatureVerificationResult> sigs = GnuPGCommands.verifySignature(gpg.getPathToGPG(), bin, null);
      //for(SignatureVerificationResult
      message.setSignatureVerification(sigs);

    }                                                
    catch(Exception er)
    {
      JOptionPane.showMessageDialog(SnowMailClientApp.getInstance(),
        er.getMessage(),
        Language.translate("Cannot verify signature"), JOptionPane.ERROR_MESSAGE);
    }
  }   

  private void decryptButtonPressed()
  {
    if(message==null) return;
    if(!message.lookIfContentIsPGPEncrypted())
    {
      JOptionPane.showMessageDialog(SnowMailClientApp.getInstance(),
        Language.translate("The message is not in GPG format"),
        Language.translate("Cannot decrypt mail"), JOptionPane.ERROR_MESSAGE);
    }

    try
    {
      // ensure that the call to the message function will be successful !
      
      GnuPGLink gpg = SnowMailClientApp.getInstance().getGnuPGLink();
      String[] uk =  GnuPGCommands.determineUsedKey(gpg.getPathToGPG(), message.getMessageBody(),null);
      //System.out.println("uk=" + uk[0] + "," + uk[1]);
      
      Address ad = new Address(uk[1]);
      GnuPGKeyID[] keys = gpg.getSecretKeyIDForAddress(ad.getMailAddress());
      if(keys.length==0)
      {
         throw new Exception(Language.translate("No GPG key found for %",uk[1]));
      }
      
      byte[] pass = gpg.getPasswordForKeyAskIfNotFoundOrNotValid(
                           keys[0], true, SnowMailClientApp.getInstance());
      
      String decryptedMessage = GnuPGCommands.decryptBufferForRecipient(
                           gpg.getPathToGPG(), message.getMessageBody(), keys[0], pass, null);

      //System.out.println("dec="+dec);
                               
      message.setDecryptedMessage(decryptedMessage);


    }                                                
    catch(Exception er)
    {
      JOptionPane.showMessageDialog(SnowMailClientApp.getInstance(),
        er.getMessage(),
        Language.translate("Cannot decrypt mail"), JOptionPane.ERROR_MESSAGE);
    }  
  }

  private void optionsButtonPressed()
  {
      if(message==null) return;

      JPopupMenu popup = new JPopupMenu("Options");

      JMenuItem keyboardItem = new  JMenuItem(Language.translate("Keyboard"));
                                                                                         
      if(message.isEditable())
      {
        popup.add(keyboardItem);
        popup.addSeparator();
      }

      keyboardItem.addActionListener(new ActionListener()
      {
          public void actionPerformed(ActionEvent e)
          {
              //DefaultStyledDocument doc = (DefaultStyledDocument) textPane.getStyledDocument();

              if(keyboardDialog==null)
              {
                keyboardDialog = new KeyboardDialog(SnowMailClientApp.getInstance());
                keyboardDialog.setTarget(textPane);
                SnowMailClientApp.getInstance().getProperties().setComponentLocationFromINIFile(
                      keyboardDialog, "KeyboardDialog", 300,200);
                keyboardDialog.setKeyboard(new PolishMap());
                keyboardDialog.pack();
              }

              keyboardDialog.setVisible(true);

          }
      });


      JMenuItem fullViewItem = new JMenuItem(Language.translate("Full content"));
      
      popup.add(fullViewItem);
      fullViewItem.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            if(message!=null)
            {   
               saveActualMessage();
               // bof bof, for big mails, this is not especially good...
               if(message.getCompleteContentAsString().length()>100000)  // 100ko
               {
                 fullMailContentView.setText(
                         Language.translate( "The message is too big to be displayed, you see just the first 100kB here" )
                       + "\n\n"
                       + message.getCompleteContentAsString().substring(0, 50000)
                   );
               }
               else
               {
                 fullMailContentView.setText(message.getCompleteContentAsString());
               }
            }
            else
            {
               fullMailContentView.setText(Language.translate("No message selected."));
            }
            fullMailContentView.setVisible(true);
          }
      });
  
  
  
      JMenuItem fullSendViewItem = new JMenuItem(Language.translate("Content as to be sent"));
      if(SnowMailClientApp.debug)
      {
        popup.add(fullSendViewItem);
      }
      fullSendViewItem.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent ae)
         {
            if(message!=null)
            {
               saveActualMessage();
               try
               {
                 byte[] cc = message.getCompleteContentToSend(null,null, null, null);
                 fullMailContentView.setText(new String(cc));
               }
               catch(Exception ex)
               {
                 fullMailContentView.setText("Error getting sent content: "+ex.getMessage());
               }
            }
            else
            {
               fullMailContentView.setText(Language.translate("No message selected."));
            }
            fullMailContentView.setVisible(true);
          }
      });
  
  
      JMenuItem viewHTMLBT = new  JMenuItem(Language.translate("View HTML"));
      if(message.lookIfContentIsHTML())
      {
        popup.add(viewHTMLBT);
      }
      else
      {
        //System.out.println("not HTML");
      }
      viewHTMLBT.addActionListener(new ActionListener()
        { public void actionPerformed(ActionEvent e)
          {       
            viewHTMLAction();
          }
        });
  
  
  
      if(message.getHeader().hasEntry("Received") )
      {

        JMenuItem viewTrace = new  JMenuItem(Language.translate("Trace"));
        SnowMailClientApp.getInstance().addAdvancedComponent(viewTrace);
        popup.addSeparator();
        popup.add(viewTrace);
  
        viewTrace.addActionListener(new ActionListener()
          { public void actionPerformed(ActionEvent e)
            {
              viewTraceAction();
            }
          });
      } 

      JMenuItem viewSPAMStat = new  JMenuItem(Language.translate("Spam Stat"));
      
      JComponent sep =  new JPopupMenu.Separator();
      SnowMailClientApp.getInstance().addAdvancedComponent(sep);
      popup.add(sep);

      popup.add(viewSPAMStat);
      SnowMailClientApp.getInstance().addAdvancedComponent(viewSPAMStat);

      viewSPAMStat.addActionListener(new ActionListener()
      { public void actionPerformed(ActionEvent e)
          {
            SpamResult spamResult = SnowMailClientApp.getInstance().getWordStatistic().calculateSpamProbability(message);
            SpamResult spamResultHeader = SnowMailClientApp.getInstance().getWordStatistic().calculateSpamProbability(message.getHeader());

            StringBuffer sb = new StringBuffer(Language.translate("SPAM probability")+" = "+spamResult.getProbability()+"\n");
            sb.append(Language.translate("Header SPAM probability")+" = "+spamResultHeader.getProbability()+"\n");

            sb.append("\r\n\r\n"+Language.translate("Message most relevant words")+"\r\n");
            for(int i=0; i<spamResult.getMostSignificantWords().size(); i++)
            {
              Word wi = (Word)spamResult.getMostSignificantWords().elementAt(i);
              sb.append("\r\n  "+wi.toString());
            }

            sb.append("\r\n\r\n" + Language.translate("Header most relevant words")+"\r\n");
            for(int i=0; i<spamResultHeader.getMostSignificantWords().size(); i++)
            {
              Word wi = (Word)spamResultHeader.getMostSignificantWords().elementAt(i);
              sb.append("\r\n  "+wi.toString());
            }

            sb.append("\r\n\r\n" + Language.translate("All message words") + "\r\n");
            for(int i=0; i<spamResultHeader.getAllWords().size(); i++)
            {
              Word wi = (Word)spamResultHeader.getAllWords().elementAt(i);
              sb.append("\r\n  "+wi.toString());
            }

            fullMailContentView.setText(sb.toString());
            fullMailContentView.setVisible(true);
          }
      });



      popup.show( this.optionsButton, 0, fontSize*3/2);
  }  
  
  
  public void callBeforeTerminating()
  {
     if(keyboardDialog!=null)
     {
       SnowMailClientApp.getInstance().getProperties().saveComponentLocationInINIFile(keyboardDialog, "KeyboardDialog");
     }      
  }
  


  /** called when UI changes
  */
  private void updateSpecialUI()
  {
    //System.out.println("MailView.updateSpecialUI()");
    if(jsp!=null)
    {               
      fontSize = UIManager.getFont("Label.font").getSize();
      jsp.setOpaque(false);
      jsp.getViewport().setOpaque(false);
    }   

    textPane.setOpaque(false);
    textPane.setFont(UIManager.getFont("TextPane.font"));
  }
  
  
  /** this is used to reflect in real times the changes in header data
      in the table view during edit in the mailview...
  */
  private void saveActualEditedHeader()
  {
    if(message!=null)
    {                    
       message.setMessageHeader(
           new Address((String) this.fromFieldCB.getSelectedItem()),
           Address.parseAddressList(this.toField.getText()),
           this.subjectField.getText()
       );
    }
  }              

  /** only call in special cases (backup, termination, ...)
      otherwise, this is managed from the view itself,
      
      Called:
      1) when the selection changes, when one click on another message...
  */    
  public void saveActualMessage()
  {
    // reset new flag
    //        
    if( message!=null && message.getIsNew() )
    {
       // only if it has been read => has been show for at least 5 secs
       long now = System.currentTimeMillis();
       if(now-setMessageTime>TimeToMarkAsRead)                                
       {                       
          message.setIsNoMoreNew();
       }
    }

    // save actual message if editable
    //
    if(message!=null && message.isEditable()
      && (contentHasChanged || this.mimeTreePanel.getHasChanged()))
    {
       // always call this ...
       // mime or flat are treated there (text is either stored as plain in the mime tree) or as raw body
       message.setMessage(   
           new Address((String) this.fromFieldCB.getSelectedItem()),
           Address.parseAddressList(this.toField.getText()),
           this.subjectField.getText(),
           this.textPane.getText()
       );       
                                       
       message.setActualDate();
    }
    
    //fullMailContentView.saveSizeAndLocation();
    SnowMailClientApp.getInstance().getProperties().saveComponentSizeInINIFile(
      this.hTMLViewer, "hTMLViewer");

    // reset the change detector
    contentHasChanged = false;
  }   

  private int lastFoundPosition = -1;   

  /** cause the highlight of the selected text
  */
  public synchronized void searchText(String text, boolean searchNext)
  {
     DefaultStyledDocument doc = (DefaultStyledDocument) textPane.getStyledDocument();

     // important, don't use the textpane getText method(), line feeds doesn't have the same length !!
     String textUp = "";
     try
     {
       textUp = doc.getText(0, doc.getLength()).toUpperCase();
     }
     catch(Exception e)
     {
       e.printStackTrace();
     }

     // reset the style for the whole document
     Style defaultStyle = textPane.getStyle("default");
     doc.setCharacterAttributes(0, textUp.length(), defaultStyle, true);

     if(text.length()==0)
     {
        // nothing to find !!
        return;
     }

     if(searchNext)
     {
        lastFoundPosition = textUp.indexOf(text.toUpperCase(), lastFoundPosition+1);
     }
     else
     {
        lastFoundPosition = -1;
     }


     // search from beginning if either not found from now or not search next
     if(lastFoundPosition==-1)
     {
        lastFoundPosition = textUp.indexOf(text.toUpperCase(), 0);
     }

     if(lastFoundPosition!=-1)
     {
        try
        {
           Style highlightStyle = doc.getStyle("SearchHit");
           if(highlightStyle==null)
           {
             System.out.println("MailView textsearch highlightStyle is null !");
           }
           else
           {
             doc.setCharacterAttributes(lastFoundPosition, text.length(), highlightStyle, true);
             textPane.setCaretPosition(lastFoundPosition);
           }
        }
        catch(Exception e)
        {             
           e.printStackTrace();
        }
     }


  }


  /** set the message to view, save the actual,...
    @param folderView is used to refresh the view when subject or other fields are edited
  */       
  public void setMessage(MailMessage newMessage)
  {
    

    // do nothing if the message is the same
    // this occurs if the header is clicked for sorting
    if(newMessage!=null && message == newMessage)
    {                                                                                                               
       return;
    }
    
    //new Throwable().printStackTrace();
    
    // save old message (only done if necessary)
    saveActualMessage();     
    
    // used to decide when a message has been read               
    setMessageTime = System.currentTimeMillis();

    // remove listener
    if(message!=null) message.removeChangeListener(this);

    // set the message
    this.message = newMessage;
    if(message!=null) message.addChangeListener(this);
    this.mimeTreePanel.setMessage(message);
    
    multipartSlit.setDividerLocation(0);

    if(message!=null)    
    {
      
/*      double p = SnowMailClientApp.getInstance().getWordStatistic().calculateSpamProbability(message);
      System.out.println("SPAM Probability calculated = "+p);
      p = SnowMailClientApp.getInstance().getWordStatistic().calculateSpamProbability(message.getHeader());
      System.out.println("Header SPAM Probability     = "+p);
*/
                      
      // sets the text
      // for non editable messages (received) maybe HTML
      //
      setTextAreaContent_from_Message(message);

      setVisible(true);       
      headerPanel.setEnabled(true);
      textPane.setEnabled(true);
      optionsButton.setEnabled(true);
      fromOptionsButton.setEnabled(true);

      // from                 
      // BE Careful here
      fromFieldCB.removeItemListener(fromFieldItemListener);
      fromFieldCB.setSelectedItem( message.getFromAddress().toString() );
      fromFieldCB.addItemListener(fromFieldItemListener);

      if(SnowMailClientApp.getInstance().getAddressBook().getAddress(message.getFromAddress().getMailAddress())!=null)
      {                                               
        fromFieldCB.setBackground(ThemesManager.getInstance().getGreen());
        fromFieldCB.setOpaque(true);
      }
      else if(SnowMailClientApp.getInstance().getSpamBook().getAddress(message.getFromAddress().getMailAddress())!=null)
      {
        fromFieldCB.setBackground(ThemesManager.getInstance().getRed());        //
        fromFieldCB.setOpaque(true);
      }
      else
      {
        fromFieldCB.setOpaque(false);
      }


      toField.setText( message.getToAddressesText() ); 
      setBrowseAddressesButtonText();
      subjectField.setText( message.getSubject() );

      toField.setEditable(message.isEditable());
      browseAddressButton.setEnabled(message.isEditable());
      fromFieldCB.setEnabled(message.isEditable());   // not edit !
      subjectField.setEditable(message.isEditable());
      
      this.signCB.setVisible(message.isEditable());
      this.encryptCB.setVisible(message.isEditable());
          
      this.signCB.setSelected(message.getMustBeSigned());
      this.encryptCB.setSelected(message.getMustBeEncrypted());

      if(message.hasParseError())
      {
        this.setMailErrorRemark(message.getErrorMessage());         
      }
      else                      
      {     
        this.setMailErrorRemark("");
      }       
      
      this.setMailStatusRemark( message.getStatusRemark() );
      
      this.decryptButton.setVisible(message.lookIfContentIsPGPEncrypted());
      this.verifyButton.setVisible(message.lookIfContentIsPGPSigned());
                                           
      boolean viewAtt = message.isEditable() 
            || (message.getMimeTree()!=null && message.getMimeTree().isMimeMessageFormat());
      this.attachementsPanel.setVisible( viewAtt );
      attachmentsButton.setVisible( viewAtt );
    }
    else
    {
      // message is null
      browseAddressButton.setEnabled(false);

      errorLabel.setVisible(false);
                                            
      setMessageTextPaneText("");
                    
      toField.setText("");    
      setBrowseAddressesButtonText();
      subjectField.setText("");
      fromFieldCB.setSelectedIndex(-1);
      fromFieldCB.setOpaque(false);
                          
      textPane.setEnabled(false);
      headerPanel.setEnabled(false);
      optionsButton.setEnabled(false);
      fromOptionsButton.setEnabled(false);

      toField.setEditable(false);
      fromFieldCB.setEnabled(false);    
      subjectField.setEditable(false);
      textPane.setEditable(false);
           
      this.signCB.setVisible(false);
      this.encryptCB.setVisible(false);
      verifyButton.setVisible(false);
           
                                      
      fullMailContentView.setText("");
                                 
      setMailStatusRemark("");
      setMailErrorRemark("");
      
      this.decryptButton.setVisible(false);
      
      this.attachementsPanel.setVisible(false);
      attachmentsButton.setVisible( false );
    }

  }

  private void setMailStatusRemark(String text)
  {
    mailStatusLabel.setText(text);
    mailStatusLabel.setVisible(text.length()>0);
  }
  
  private void setMailErrorRemark(String text)
  {
    this.errorLabel.setText(text);
    errorLabel.setVisible(text.length()>0);
  }  
                
  private void setMessageTextPaneText(String text)
  {
       // make no sense otherwise !
      this.undoManager.discardAllEdits();
      this.undoEnabled = false;
      textPane.setText(text);   
      textPane.setCaretPosition(0);
      this.undoEnabled = true;
  }
  
  private void setButtonSmallHeight(JButton comp)
  {   
  //   GUIUtils.setNarrowInsets(comp);
     GUIUtils.setSmallDimensions(comp);
       
    /* comp.setPreferredSize(new Dimension(
      (int) comp.getPreferredSize().getWidth(),
      (int) this.subjectField.getPreferredSize().getHeight()));*/
  }

  
  /** null if no message actually edited
  */
  public MailMessage getMessage() 
  { 
    return message; 
  }


  /** this set the content of the mail to view in the text area

     1) if the message is editable (composed), it is always pure text and
        the plain/text of multipart content is shown.

     2) if the message is not editable (received, sent)
        if it is in HTML format, display a secure html (without images)
        ...
  */                                 
  private void setTextAreaContent_from_Message(MailMessage mess)
  {
      textPane.setEditable(mess.isEditable());

      if(MimeUtils.isMultipart(mess))
      {         
           MimeTreeModel treeModel = mess.getMimeTree();
           MimePart textPart = treeModel.getFirstPlainTextPart();
           if(textPart!=null)      
           {
              String cont = textPart.getBodyAsText();
              this.setMessageTextPaneText(cont);

           }
           else
           {
              
              // TODO:
              //  show the parsed html !!
              MimePart mpH = treeModel.getFirstHTMLTextPart();
              if(mpH!=null)
              {
                String cont = mpH.getBodyAsText();
                try
                {
                  HTMLTextExtractor he = new HTMLTextExtractor(cont, true);
                  setMessageTextPaneText("No text part in the mail, here is the first extracted html\n"+he.getTextOnly());
                }
                catch(Exception e)
                {
                  setMessageTextPaneText("No text part in the mail, here is the first html part\n"+cont);
                }
              }
              else
              {                                                                                                           
                setMessageTextPaneText("No text part in the mail");
              }
           }
      }
      else
      {
        // not multipart
        
        if(mess.isEditable())
        {
          // always only text in the editable messages...
          
          setMessageTextPaneText(mess.getMessageBody());
        }
        else
        {
          if(mess.lookIfContentIsHTML())
          {
            try
            {
              HTMLTextExtractor he = new HTMLTextExtractor(mess.getMessageBody(), true);
              setMessageTextPaneText(
                Language.translate("The message content is in HTML format. Here is the extracted text. Use options to see the original.")
                  +"\n\n"
                  +he.getTextOnly());
            }
            catch(Exception e)   
            {
              setMessageTextPaneText(mess.getMessageBody());
            }
          }
          else
          {
            setMessageTextPaneText(mess.getMessageBody());
          }
        }  
      }
  }



  private void viewHTMLAction()
  {
     if(message==null) return;

     MimeTreeModel treeModel = message.getMimeTree();
     MimePart htmlPart = treeModel.getFirstHTMLTextPart();
     String cont = "";
     if(htmlPart!=null)
     {
        try           
        {
           HTMLFromMIME htmm = new HTMLFromMIME(treeModel);
           cont = htmm.getHTMLCodeWithLocalizedLinks();
        }
        catch(Exception e)
        {
           cont = Language.translate("Error")+": "+e.getMessage();
        }
     }  
     else
     {
        cont = message.getMessageBody();
        try
        {
          HTMLCleaner hc = new HTMLCleaner(cont, false);
          cont = hc.getCleanHTMLText();
        }
        catch(Exception ee)
        {
          cont = ee.getMessage();
        }
     }
     hTMLViewer.setHTMLSource(cont);
     hTMLViewer.setVisible(true);
  }

  private void viewTraceAction()
  {
     if(message==null) return;
     new TraceViewDialog(SnowMailClientApp.getInstance(), message.getHeader());
  }     
  
  private void addressMenuPressed()
  {
    final AddressBook addressBook = SnowMailClientApp.getInstance().getAddressBook();
    final AddressBook spamBook    = SnowMailClientApp.getInstance().getSpamBook();
                          
    JPopupMenu addressMenu = new JPopupMenu(Language.translate("Address"));


    if( !addressBook.hasAddress(message.getFromAddress().getMailAddress()) )
    {
      JMenuItem addAdd = new JMenuItem(Language.translate("Add to addressbook"));
      addressMenu.add(addAdd);
      addAdd.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        { 
          if( message!=null)
          {
            Address a = message.getFromAddress();
            addressBook.addAddress( a );
          }
        }  
      });
    }

    if( !spamBook.hasAddress(message.getFromAddress().getMailAddress()) )
    {                                                                                            
      JMenuItem addSPAM = new JMenuItem(Language.translate("Add to SPAM list"));
      addressMenu.add(addSPAM);
      addSPAM.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          if( message!=null)
          {
            Address a = message.getFromAddress();
            spamBook.addAddress( a );
          }
        }
      });
    }

    addressMenu.show(this.fromOptionsButton, 0, fontSize*3/2);

  }
  
  private boolean browseToAddressAction_add = false;

  /** select the mail recipients To from the address book
  */
  private void browseToAddressAction()
  {
     AddressBook adb = SnowMailClientApp.getInstance().getAddressBook();
     Vector<Address> addresses = Address.parseAddressList(toField.getText());
     adb.setSelectedAddresses(addresses);

     final JDialog browseAddress = new JDialog(SnowMailClientApp.getInstance(),
                         Language.translate("Select receipient(s) to send the mail"), true);
     browseAddress.getContentPane().setLayout(new BorderLayout());
     CloseControlPanel ccp = new CloseControlPanel(browseAddress, true, true, Language.translate("Use only selected"));
     JButton addSelectedButton = new JButton(Language.translate("Add selected"));
     ccp.add(addSelectedButton);
     browseToAddressAction_add = false;
     addSelectedButton.setBackground( ccp.getOkButton().getBackground() );
     addSelectedButton.addActionListener(new ActionListener()
     {                             
       public void actionPerformed(ActionEvent ae)
       {
         browseToAddressAction_add = true;
         browseAddress.setVisible(false);
         browseAddress.dispose();
       }
     });

     browseAddress.getContentPane().add(ccp, BorderLayout.SOUTH);                                          
     final SortableTableModel stm = new SortableTableModel(adb,0,true);
     JTable table = new JTable(stm);
     stm.installGUI(table);
     browseAddress.getContentPane().add(new JScrollPane(table), BorderLayout.CENTER);
     table.getColumnModel().getColumn(0).setPreferredWidth(200);
     table.getColumnModel().getColumn(1).setPreferredWidth(300);

     // north
     //
     final JTextField searchTF = new JTextField(8);
     final JTextField searchTF2 = new JTextField(8);                                                          
     JPanel northPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
     browseAddress.getContentPane().add(northPanel, BorderLayout.NORTH);
     northPanel.add(new JLabel(Language.translate("Search")+":"));
     northPanel.add(searchTF);
     northPanel.add(new JLabel(" & "));
     northPanel.add(searchTF2);
     KeyAdapter ska = new KeyAdapter()
     {
        @Override public void keyReleased(KeyEvent e)
        {
           stm.search(searchTF.getText(), searchTF2.getText(), false);
        }
     };
     searchTF.addKeyListener(ska);
     searchTF2.addKeyListener(ska);

     SnowMailClientApp.getInstance().getProperties().setComponentSizeFromINIFile(
       browseAddress, "browseAddressDialog", 600,400,100,20);

     // MODAL
     browseAddress.setVisible(true);
     SnowMailClientApp.getInstance().getProperties().saveComponentSizeInINIFile(
       browseAddress, "browseAddressDialog");
                      
     if(ccp.getWasCancelled()) return;

     // force a key event to update the selection store in the stm
     ska.keyReleased(null);
     int[] sel = adb.getSelectedRows();
     StringBuffer sb = new StringBuffer();
     for(int i=0; i<sel.length; i++)
     {
        Address ad = adb.getAddressAt(sel[i]);
        sb.append(ad.toString());
        if(i<sel.length-1) sb.append("; ");
     }
     
     if(browseToAddressAction_add)
     {
       if(toField.getText().trim().length()>0)
       {
         toField.setText(toField.getText().trim()+"; "+sb.toString());
       }
       else
       {
         toField.setText(sb.toString());
       }
     }
     else         
     {  
       // replace the existing address !
       toField.setText(sb.toString());
     }

     saveActualEditedHeader();               
     
     setBrowseAddressesButtonText();
  }

  /**
  */
  private void setBrowseAddressesButtonText()
  {
    Vector<Address> adds = Address.parseAddressList(this.toField.getText());
                 
    if(adds.size()<=1)        
    {
      this.browseAddressButton.setText(Language.translate("To")+":");
    }
    else
    {
      this.browseAddressButton.setText(Language.translate("% Tos", ""+adds.size())+":");
    }
  }

 
                    
  // edition listeners (FolderView)
  //  


  /** the view does no edit during the content edition.
     This just changes the state of the folder to "changed" to ensure later saving.
  */
  private void notifyContentEditionListeners()
  {
    contentHasChanged = true;
    
    if(message!=null)
    {
      message.notifyThatThisMessageIsBeingEditedNow("content edited in the view");
    }
  }


} // MailView
