package SnowMailClient.view.actions;

import SnowMailClient.model.accounts.*;
import snow.utils.storage.*;
import SnowMailClient.view.accounts.*;
import SnowMailClient.SnowMailClientApp;  
import SnowMailClient.Language.Language;
                                  
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;          
                   
public class EditAccountsAction extends AbstractAction
{
  JFrame parent;
  MailAccounts accounts;  
  AppProperties properties;

  public EditAccountsAction(JFrame parent, MailAccounts accounts, AppProperties properties)
  {                            
    super(Language.translate("Mail Accounts"));
    this.parent = parent;
    this.accounts = accounts;
    this.properties = properties;  

    putValue(AbstractAction.SMALL_ICON,
              SnowMailClientApp.loadImageIcon("pics/mailAccounts.PNG") );

    
  } // Constructor

  public void actionPerformed(ActionEvent e)
  {  
    new AccountsEditor(parent, accounts, properties); 
  }


} // EditAccountsAction
