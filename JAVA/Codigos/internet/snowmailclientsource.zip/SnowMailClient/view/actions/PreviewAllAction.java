package SnowMailClient.view.actions;

import SnowMailClient.MailEngine.*;
import SnowMailClient.*;
import SnowMailClient.model.*;
import SnowMailClient.model.accounts.*;
import SnowMailClient.view.*;
import SnowMailClient.view.dialogs.*;
import SnowMailClient.Language.Language;
import SnowMailClient.utils.*;
import snow.utils.gui.*;
import SnowMailClient.view.MessagesPreview.*;
import snow.lookandfeel.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.event.*;  
import java.util.*;
import java.text.*;          
import java.io.*;
          
/** Action to preview all mails (retrieve all mail headers).
   Display them in a table overview and allow selected to be downloaded.
   Show spam probability based on header.
   Very useful to clean mailboxes and reduce traffic.  
   
   TODO: absolute ugly things here: redesign all
*/                                          
public final class PreviewAllAction extends AbstractAction implements Runnable
{
       
  // when non null, a preview exists and is already active.
  private PreviewDialog previewDialog;
               
  public PreviewAllAction()
  {
       super(Language.translate("Preview"));

       putValue(AbstractAction.SMALL_ICON, SnowMailClientApp.loadImageIcon("pics/messagespreview.PNG"));
       putValue(AbstractAction.ACCELERATOR_KEY, KeyStroke.getKeyStroke( KeyEvent.VK_E, KeyEvent.CTRL_MASK ) );
  }

   /** when the button is pressed or the ctrl+E pressed.
       Only active one time.
       Always called from EDT
   */
   public synchronized void actionPerformed(ActionEvent actionEvent)
   {
     // previewDialog nullity is used to detect if a window is already active.
     System.out.println("PreviewAllAction.actionPerformed");
     if(previewDialog!=null)
     {
        System.out.println("preview dialog already exists");
        previewDialog.setVisible(true);
        return;
     }

     // no already existing => create
     final PreviewModel previewModel = new PreviewModel();
     previewDialog = new PreviewDialog( SnowMailClientApp.getInstance(), previewModel, true ); // modal ?

     Thread t = new Thread(this);
     t.start();
   }


   private final void onClosingPreviewDialog(final Vector<MailAccount> accounts)
   {   
      if(previewDialog==null) return;

      //SnowMailClientApp.getInstance().getProperties().saveComponentSizeInINIFile(previewDialog, "AllMailPreviewDialog");
      previewDialog = null;

      // terminate  
      closeConnections(accounts);
   }
   
   private void terminatePreview(final Vector<MailAccount> accounts)
   {
      previewDialog = null;        

      // terminate
      closeConnections(accounts);
   }
                                  
   private final void closeConnections(final Vector<MailAccount> accounts)
   {    
      if(accounts==null) return;
      for(MailAccount ma : accounts)
      {
         ma.closePOPConnection();
      }
   }
    
   boolean hasErrors = false; 
   
   /** run in a thread. Fills the preview model with the messages
   */
   public void run()
   {
      // 1) Collect all accounts to read

      MailAccounts accounts = SnowMailClientApp.getInstance().getAccounts();
      final Vector<MailAccount> accountsToRead = new Vector<MailAccount>();
      for(int i=0; i<accounts.getRowCount(); i++)
      {
        MailAccount ma = accounts.getAccount(i);     
        if(ma.getUseToReadMails())
        {
          accountsToRead.add(ma);
        }               
      }

      // 2) Look on all for the number of new mails (this will pop up the password dialogs...)

      final JDialog dialog = new JDialog(SnowMailClientApp.getInstance(),
          Language.translate("Preview of all accounts"), 
          false);   // [Oct2005] no more modal

      dialog.getContentPane().setLayout(new BorderLayout());

      final AccountLog doc = new AccountLog();

      SimpleAttributeSet set = new SimpleAttributeSet();
      TabSet ts = new TabSet(new TabStop[]{ new TabStop(250,TabStop.ALIGN_LEFT,TabStop.LEAD_NONE)});
      set.addAttribute( StyleConstants.TabSet, ts);
      doc.doc.setParagraphAttributes(0, doc.doc.getLength(), set, true);

      JTextPane textPane = new JTextPane(doc.doc);
      JScrollPane jsp = new JScrollPane(textPane);
      jsp.setOpaque(false);       
      jsp.getViewport().setOpaque(false);
      textPane.setOpaque(false);
      dialog.getContentPane().add(jsp, BorderLayout.CENTER);
                          
      final CloseControlPanel ccp = new CloseControlPanel(dialog, true, true, 
                 Language.translate("View headers"));
      ccp.getOkButton().setVisible(false);
      dialog.getContentPane().add(ccp, BorderLayout.SOUTH);

      dialog.setSize(650, 350);
      SnowMailClientApp.centerComponentOnMainFrame(dialog);
      EventQueue.invokeLater(new Runnable()
      {
         public void run()
         {
            dialog.setVisible(true);
         }
      });

      final Vector<MailAccount> accountsWithNewMails = new Vector<MailAccount>();
      final long[] totLength = new long[1];
      final int[] totMails = new int[1];
      
      Vector<Thread> readThreads = new Vector<Thread>();
      
      hasErrors = false;
      
   rl:for(MailAccount _ma: accountsToRead)
      {  
         if(ccp.getWasCancelled()) break rl;

         final MailAccount ma = _ma;

         Thread rt = new Thread() { public void run() 
         {                       
           try
           {
             int[] count = ma.getCheckedPopConnection().getNumberOfMessages();
             doc.append(  "\r\n" + ma.getAddress() + ":\t" +
               (count[0]!=1 ?
                  Language.translate("% new messages", ""+count[0])
                : Language.translate("1 new message"))
             );
             
             doc.append( "\t("+MailMessageUtils.formatSize(count[1])+")" );
  
             totMails[0] += count[0];
             totLength[0] += count[1];
  
             if(count[0]>0)
             {
               accountsWithNewMails.add(ma);
             }
           }
           catch(Exception e)
           {                       
             //e.printStackTrace();
             doc.append("\r\n" + ma.getAddress() + ":\t");
             doc.appendError(e.getMessage());
             hasErrors = true;               
           }
         }};        
         rt.setPriority(Thread.NORM_PRIORITY-1);
         rt.start();                            
         readThreads.add(rt);
      }
      
      // wait for all completed
      for(Thread t : readThreads)
      {           
         try{
           t.join();
         } catch(Exception ex) {}
      }


      if(ccp.getWasCancelled())
      {
         doc.appendError("\nOperation cancelled.");
         dialog.setVisible(false);
         terminatePreview(accountsToRead);
      }
      else if(totMails[0]>0)
      {
         if(!hasErrors)
         {
           dialog.setVisible(false);
           launchPreview(totMails[0], totLength[0], accountsWithNewMails);
         }
         else
         {
           ccp.getOkButton().setVisible(true);
           // has errors => wait on close
           dialog.addWindowListener(new WindowAdapter()
           {
               boolean closed = false;
               @Override public void windowClosed(WindowEvent we)
               {
                 if(closed) return;
                 closed=true;
                 launch();
               }
               @Override public void windowClosing(WindowEvent we)
               {
                 if(closed) return;
                 closed=true;
                 launch();
               }

               void launch()
               {
                 if(ccp.getWasCancelled())
                 {
                    terminatePreview(accountsToRead);
                    return;
                 }
                 launchPreview(totMails[0], totLength[0], accountsWithNewMails);
               }
           });
         }
      }
      else
      {
         // no mails...
         // nothing, let the dialog run
         System.out.println("no mails");                   
         // Feb2005: added this missing close op !
           dialog.addWindowListener(new WindowAdapter()
           {
               boolean closed = false;
               @Override public void windowClosed(WindowEvent we)
               {
                 if(closed) return;
                 close();
               }
               @Override public void windowClosing(WindowEvent we)
               {
                 if(closed) return;
                 close();
               }

               void close()
               {
                 terminatePreview(accountsToRead);
               }
           });         
      }
   }


   private void launchPreview(int totalNumberOfMails, long totSize, final Vector<MailAccount> accounts)
   {
      Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
      SnowMailClientApp.getInstance().getProperties().setComponentSizeFromINIFile(
          previewDialog, "AllMailPreviewDialog",
          (int) Math.min(ThemesManager.getLabelFontSize()*80, screen.getWidth()),
          (int) Math.min(ThemesManager.getLabelFontSize()*55, screen.getHeight()),
          ThemesManager.getLabelFontSize()*5,
          ThemesManager.getLabelFontSize()*5    
      );   
      
      if(previewDialog.getWidth()<100 || previewDialog.getHeight()<100)
      {
         previewDialog.setSize( 
           (int) Math.min(ThemesManager.getLabelFontSize()*80, screen.getWidth()),
           (int) Math.min(ThemesManager.getLabelFontSize()*55, screen.getHeight()));
         previewDialog.setLocationRelativeTo(null);
      }   
 
      previewDialog.addWindowListener(new WindowAdapter()
      {
         @Override public void windowClosed(WindowEvent e)
         {
            onClosingPreviewDialog(accounts);
         }
 
         @Override public void windowClosing(WindowEvent e)
         {
            onClosingPreviewDialog(accounts);
         }
      });


      EventQueue.invokeLater(new Runnable() { public void run()
      {
        // no more modal !!
        previewDialog.setVisible(true);

        // on closing, the action onClosingPreviewDialog() will be called
      }});

      previewDialog.setMaximalMessageNumber(totalNumberOfMails);
      previewDialog.setStatusLabelText(
               Language.translate("You have % new messages", ""+totalNumberOfMails)
             + (totalNumberOfMails>0?" ("+MailMessageUtils.formatSize(totSize) + ")":"")
      );
      
      final Vector<Thread> readThreads = new Vector<Thread>();
      for(MailAccount _ma : accounts)
      {
        // each in his own thread
        final MailAccount ma = _ma;                                                                       
        Thread tr = new Thread() { public void run() 
        {
          try                                           
          {
            downloadHeaders(ma, previewDialog);
          }
          catch(Exception e)
          {
            e.printStackTrace();
          }
        }};
        tr.setPriority(Thread.NORM_PRIORITY-1);                                       
        readThreads.add(tr);
        tr.start();
      }
      
      // wait for completion (but don't block the EDT !
      Thread t = new Thread() { public void run() {
        for(Thread tr: readThreads)                  
        {
           try
           {                      
              tr.join();
           }
           catch(Exception ex) {}
        }
  
        // can have been closed !
        if(previewDialog==null) return;
  
        previewDialog.setMessageProgressInvisible();
      }};
      t.setPriority(Thread.NORM_PRIORITY-1);
      t.start();            
   }              



   private void downloadHeaders(MailAccount account, final PreviewDialog previewDialog) throws Exception
   {                  
        SecurePopConnection spop = account.getCheckedPopConnection();
        String[] messUIDLS = spop.getMessagesUIDLs();
        int[] messSizes = spop.getSizes_from_MessagesLIST(spop.getMessagesLIST_());

        for(int i=0; i<messSizes.length; i++)
        {
           previewDialog.incrementMessageProgress(1);
           String messHeaderText = spop.getMessageTop(messUIDLS[i], 0);
           try
           {
             String uidl = messUIDLS[i];
             long size = messSizes[i];

             final PreviewHeader header = new PreviewHeader(account, uidl, size);
             
             Header.parseHeader(new NumberedLineReader(messHeaderText), header);
                                 
             EventQueue.invokeLater(new Runnable()
             { public void run()
               {
                 previewDialog.getPreviewModel().addMessageHeader(header);
               }       
             });
           }
           catch(Exception e)
           {
             e.printStackTrace();    
           }        
        }      
   }

} // PreviewAllAction
