package SnowMailClient.view.actions;

import SnowMailClient.MailEngine.*;
import SnowMailClient.*;
import SnowMailClient.model.*;
import SnowMailClient.model.accounts.*;
import SnowMailClient.view.*;
import snow.utils.gui.*;

import SnowMailClient.view.dialogs.*;
import SnowMailClient.Language.Language;
import snow.lookandfeel.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import java.util.Vector;


/** 
*/
public class ViewAccountLog extends AbstractAction
{  
   MailAccount account;
   JDialog ref;
                         
   public ViewAccountLog(JDialog ref, MailAccount account)
   {
       super(Language.translate("View account log"));
       this.account = account;
       this.ref= ref;

       putValue(AbstractAction.SMALL_ICON, SnowMailClientApp.loadImageIcon("pics/log.PNG"));
       putValue(AbstractAction.ACCELERATOR_KEY,
                 KeyStroke.getKeyStroke( KeyEvent.VK_L,
                                         KeyEvent.CTRL_MASK ) );
   }

   public void actionPerformed(ActionEvent actionEvent)
   {
      JDialog dialog = new JDialog( ref, 
        Language.translate("Log of account %",account.getAddress()), false);
      dialog.getContentPane().setLayout(new BorderLayout());
      JTextPane textPane= new JTextPane();
      textPane.setDocument(account.getAccountLog().doc);
      dialog.getContentPane().add(new JScrollPane(textPane), BorderLayout.CENTER);

      CloseControlPanel ccp = new CloseControlPanel(dialog, false, true, Language.translate("Close"));
      dialog.getContentPane().add(ccp, BorderLayout.SOUTH);

      dialog.setSize(ThemesManager.getLabelFontSize()*40, ThemesManager.getLabelFontSize()*35);
      SnowMailClientApp.centerComponentOnMainFrame(dialog);                               

      dialog.setVisible(true);
   }

}
 // ViewAccountLog
