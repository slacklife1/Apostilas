package SnowMailClient.view.actions;

import SnowMailClient.model.folders.*;
import SnowMailClient.model.accounts.*;
import SnowMailClient.model.*;
import snow.utils.gui.*;

import SnowMailClient.utils.*;
import SnowMailClient.MailEngine.*;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.view.folders.*;    
import SnowMailClient.Language.Language;

import java.awt.*;      
import java.util.*;
import java.awt.event.*;        
import javax.swing.*;
import javax.swing.event.*;        
import javax.swing.tree.*;         
import java.io.*;    

public final class ReceiveAction extends AbstractAction
{
  final private FolderTreeNode inbox, outbox;
  private MailFolder inboxFolder, outboxFolder;
  final private MailAccounts accounts;
  final private SnowMailClientApp ref;

  private ReceiveAction(
     SnowMailClientApp ref,
     MailAccounts accounts,
     FolderTreeNode inbox,
     FolderTreeNode outbox)            
  {
     super(Language.translate("(Old) Receive"));
               
     this.accounts = accounts;
     this.inbox = inbox;       
     this.outbox = outbox;          
     this.ref = ref;

     putValue(AbstractAction.SMALL_ICON, SnowMailClientApp.loadImageIcon("pics/receivemail2.PNG") );

/*     putValue(AbstractAction.ACCELERATOR_KEY, KeyStroke.getKeyStroke( KeyEvent.VK_R, KeyEvent.CTRL_MASK ) );  */

     putValue(AbstractAction.SHORT_DESCRIPTION, Language.translate("Receive new mail from all accounts"));

     try
     {
       inboxFolder  = inbox.getMailFolder();
       outboxFolder = outbox.getMailFolder();
     }
     catch(Exception ex)
     {
       ex.printStackTrace();
     }
  } // Constructor

  public void actionPerformed(ActionEvent e)
  {
     // here we're in the EDT
     Thread t = new Thread()
     {
       public void run()            
       {
         final ProgressModalDialog progressDialog = new ProgressModalDialog(ref, "Retrieving new mails", true);
         progressDialog.start();
         
         receiveAction(progressDialog);
                   
         progressDialog.closeDialog();
                                    
       }
     };  
     t.setPriority(Thread.NORM_PRIORITY-1);
     t.start();
  }

                                         
  /** Must be called in a thread !
  */
  public void receiveAction(final ProgressModalDialog progressDialog)
  {
    if( SwingUtilities.isEventDispatchThread())
    {
      throw new RuntimeException("Must be called from another thread than EDT");
    }
    SnowMailClientApp.getInstance().saveAllMails(false);

    EventQueue.invokeLater(new Runnable() { public void run() {
      progressDialog.setTitle(Language.translate("Receiving mails"));
    }});

    if(accounts.getRowCount()==0)
    {
      JOptionPane.showMessageDialog(progressDialog,
         Language.translate("There are no accounts to read mail from.\nDefine the account(s) in the Account Editor."),
         Language.translate("No mail account defined"),
         JOptionPane.INFORMATION_MESSAGE);

      return;
    } 

    try
    {
      Vector<MailAccount> accountsToRead = new Vector<MailAccount>();
      for(int i=0; i<accounts.getRowCount(); i++)
      {
         if(progressDialog.wasCancelled()) break;

         MailAccount ma = accounts.getAccount(i);
         if(ma.getUseToReadMails())
         {
            accountsToRead.add(ma);
         }
      }

      if(accountsToRead.size()==0)
      {                                                                                        
         JOptionPane.showMessageDialog(progressDialog,
           Language.translate("There are no accounts to read mail from.\nActivate the checkbox read in the accounts editor."),
           Language.translate("No accounts to check"), JOptionPane.INFORMATION_MESSAGE);
                                                              
         return;
      }
      
      int numberRead = 0;
      for(MailAccount ma: accountsToRead)
      {
         if(progressDialog.wasCancelled()) break;         
         numberRead += readMails(ma, progressDialog);
      }                  
      
/*      SnowMailClientApp.getInstance().getGlobalConsole().appendLine(
           "You have "+numberRead+" new mail"
           +(numberRead==1?"":"s"));*/
    }
    catch(Exception ex)
    {
      ex.printStackTrace();
    }
  }


  /** @return the number of mails read
  */                                                                 
  private int readMails(MailAccount ma, final ProgressModalDialog progressDialog)
  {                          
    progressDialog.setMessageProgressValue(0);

    int numberRead = 0; 
    SecurePopConnection sp = null;  
    try
    {
       sp = ma.getCheckedPopConnection();
       int[] nm = sp.getNumberOfMessages();
       int numberOfMessages = nm[0];  
                                        
       progressDialog.setProgressBounds(numberOfMessages);
       progressDialog.setProgressValue(0, "");
       progressDialog.setCommentLabel(Language.translate("Account : %",ma.getAddress()));
                           
       String[] uidls = sp.getMessagesUIDLs();
       int[] messSizes = sp.getSizes_from_MessagesLIST(sp.getMessagesLIST_());
                               
    ml:for(int i=0; i<messSizes.length; i++)
       {   
          if(progressDialog.wasCancelled()) break;
          
          // test & ask for big messages
          if(messSizes[i] > 100000) // 100k
          {   
             // get header...
             Header header = new Header();
             try
             {
               String str = sp.getMessageTop(uidls[i], 0);
               Header.parseHeader(new NumberedLineReader(str), header);             
             }
             catch(Exception ignored)
             {
               // not so important...
             }
             
             String from    = header.getEntryValue("from",    "?");
             String to      = header.getEntryValue("to",      "?");
             String subject = header.getEntryValue("subject", "?");

             int rep = JOptionPane.showConfirmDialog(progressDialog,
                Language.translate("The message")
                +"\n"+Language.translate("  from: %",from)
                +"\n"+Language.translate("  to: %",to)
                +"\n"+Language.translate("  subject: %",subject)
                +"\n"+Language.translate("has a size of %.\nDo you want to download it ?", MailMessageUtils.formatSize(messSizes[i])),
                Language.translate("Big message warning"),
                JOptionPane.YES_NO_OPTION);     
                
             if(!(rep==JOptionPane.OK_OPTION)) 
             {
               continue ml;  // go to the next message 
             }          
          }

          progressDialog.setProgressValue(i, Language.translate("message %1 / %2", ""+(i+1), ""+numberOfMessages));  
          progressDialog.setMessageProgressActive(messSizes[i]);

          try                         
          {
            String messContent = sp.getMessage(uidls[i], progressDialog.interrupter, null);
            final MailMessage mess = new MailMessage();
            mess.parse(messContent);  

            try
            {
              double p = SnowMailClientApp.getInstance().getWordStatistic().calculateSpamProbability(mess).getProbability();
              mess.setSPAMProbability(p);
            }
            catch(Exception es)
            {
              es.printStackTrace();
            }
            
            mess.setHasBeenReceived(true);
            mess.setEditable(false);


            EventQueue.invokeLater(new Runnable()
            {
              public void run()
              {
                inboxFolder.addMessage(mess);
              }   
            });

            numberRead++;
            
            // increment the number of mails received from IF the address is in the book
            SnowMailClientApp.getInstance().getAddressBook().incrementMailsReceivedFromIfPresent( mess.getFromAddress() );
            SnowMailClientApp.getInstance().getSpamBook().incrementMailsReceivedFromIfPresent( mess.getFromAddress() );

            // read was successful => delete from server
            sp.deleteMessage(uidls[i]);
          }
          catch(Exception ex)
          {
            ex.printStackTrace();
          }
       }

    }
    catch(Exception e)
    {
/*      SnowMailClientApp.getInstance().getGlobalConsole().appendSmallLine(
        "Cannot receive mail: "+e.getMessage());*/

      JOptionPane.showMessageDialog(ref.getContentPane(),
        ""+e.getMessage(),
        Language.translate("Cannot receive mail"), JOptionPane.ERROR_MESSAGE);
      //e.printStackTrace();
    }
    finally
    {
      if(sp!=null)
      {
        try{
          sp.terminateSession();
        } catch(Exception bof) {}
      }
    }                 
    
    return numberRead;
  }


} // ReceiveAction
