package SnowMailClient.view.actions;

import SnowMailClient.model.folders.*;
import SnowMailClient.model.MailMessage;
import SnowMailClient.model.accounts.*;
import SnowMailClient.model.Address;
import SnowMailClient.view.folders.*;
import SnowMailClient.view.*;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.Language.Language;

import java.awt.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
                   
public class ReplyAction extends AbstractAction
{
  private FolderTreeNode inbox;
  private MailAccounts accounts;
  private FolderView folderView;
  private boolean copyContent = true;
  private final boolean replyToAll;


  public ReplyAction(FolderView _folderView, MailAccounts accounts, FolderTreeNode inbox, boolean replyToAll)
  {
     super((replyToAll ? Language.translate("Reply All") : Language.translate("Reply")));

     this.replyToAll = replyToAll;
     this.inbox = inbox;
     this.accounts = accounts;
     this.folderView = _folderView;

     putValue(AbstractAction.SMALL_ICON,
              SnowMailClientApp.loadImageIcon("pics/reply.PNG") );

     putValue(AbstractAction.ACCELERATOR_KEY,
              KeyStroke.getKeyStroke( KeyEvent.VK_L, KeyEvent.CTRL_MASK ) );

     putValue(AbstractAction.SHORT_DESCRIPTION,
              Language.translate("Reply to the actual message"));

     folderView.getTableSelectionModel().addListSelectionListener(  new ListSelectionListener()
     {
        public void valueChanged(ListSelectionEvent e)
        {                  
           setEnabled(folderView.getTableSelectionCount()==1);
        }
     });
     setEnabled(folderView.getTableSelectionCount()==1);
     
  } // Constructor

  public void actionPerformed(ActionEvent e)
  {
    MailMessage[] messs = folderView.getSelectedMessages();
    if(messs.length==1)
    {
       MailMessage mess = messs[0];

       Address to = mess.getFromAddress();

       // ### use the same send account as in the message if possible  (look in mess.to)
       Address from = new Address();
       MailAccount ma = accounts.getSendMailAccount();
       if(ma!=null)
       {
         from.setMailAddress( ma.getAddress() );
         from.setName( ma.getName() );
       }

       MailMessage replyMessage = new MailMessage();
       replyMessage.setIsReplyMessage(mess.getMessageID());
       String body = "";
       if(this.copyContent)
       {
         body = Language.translate("In reply to:")+"\n\n"+mess.getMessageBody();                            
       }
       Vector<Address> tos =new Vector<Address>();
       tos.add(to);
       if(replyToAll)
       {
         tos.addAll(mess.getToAddresses());
       }
       replyMessage.setMessage(from,
           tos,
           "Re: "+mess.getHeader().getEntryValue("subject", "?"), 
           body);
       replyMessage.setEditable(true);


       try
       {
         inbox.getMailFolder().addMessage(replyMessage);
         inbox.saveMailFolder(false); // don't close
       }
       catch(Exception ex)
       {
         ex.printStackTrace();
       }
    }               
  }



} // ReplyAction
