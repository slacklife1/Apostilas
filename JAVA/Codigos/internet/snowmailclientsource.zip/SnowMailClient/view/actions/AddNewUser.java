package SnowMailClient.view.actions;

import SnowMailClient.MailEngine.*;
import SnowMailClient.*;
import SnowMailClient.model.*;
import SnowMailClient.model.accounts.*;
import SnowMailClient.view.*;
import SnowMailClient.view.dialogs.*; 
import SnowMailClient.Language.Language;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import java.util.Vector;


/** this command is only avaiable for admin users
*/
public final class AddNewUser extends AbstractAction
{  
   MailAccount admin;
   JDialog ref;

   public AddNewUser(JDialog ref, MailAccount admin)
   {
       super(Language.translate("Add new user"));
       this.admin = admin;
       this.ref= ref;

       putValue(AbstractAction.SMALL_ICON, SnowMailClientApp.loadImageIcon("pics/createnewuser.PNG"));
       putValue(AbstractAction.ACCELERATOR_KEY,
                 KeyStroke.getKeyStroke( KeyEvent.VK_U,
                                         KeyEvent.CTRL_MASK ) );
   }

   public void actionPerformed(ActionEvent actionEvent)
   {
/*       MailAccount admin = accounts.getSnowraverAdministratorMailAccount();
       if(admin==null)
       {
          JOptionPane.showMessageDialog(
             ref, "ERROR: No account has administrator privileges");
          return;
       }  */  

       AddNewUserDialog dialog = new AddNewUserDialog(ref, admin.getPop());
       dialog.pack();
       SnowMailClientApp.centerComponentOnMainFrame(dialog);
       dialog.show();

       if(dialog.addNewUserOnExit)
       {
          try
          {
             SecurePopConnection sp = admin.getCheckedPopConnection();
             sp.addNewUser( dialog.getUserName(), dialog.getPassword() );
             sp.terminateSession();
          }
          catch(Exception ex)
          {
             // ### shit, the message is not nice
             ex.printStackTrace();
             JOptionPane.showMessageDialog(
               ref, "Error: \n"+ex.getMessage(), 
               "Failed to add new user",
               JOptionPane.ERROR_MESSAGE);
          }
       }

   }

}
