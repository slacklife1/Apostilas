package SnowMailClient.view.actions;

import SnowMailClient.SnowMailClientApp;
import SnowMailClient.model.folders.*;
import SnowMailClient.model.*;
import SnowMailClient.view.folders.*;
import SnowMailClient.view.*;
import SnowMailClient.Language.Language;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.awt.dnd.*;

           

/** delete the selected mail (move in the deleted folder)
*/
public final class CopyMessagesToClipboardAsText extends AbstractAction
{
  final private FolderView folderView;     

  public CopyMessagesToClipboardAsText(FolderView _folderView)
  {
     super(Language.translate("Copy Messages Content To Clipboard"));
     this.folderView  = _folderView;

     //putValue(AbstractAction.SMALL_ICON, SnowMailClientApp.loadImageIcon("pics/addtospam.PNG"));


     folderView.getTableSelectionModel().addListSelectionListener(  new ListSelectionListener()
     {                                 
        public void valueChanged(ListSelectionEvent e)
        {
           setEnabled(folderView.getTableSelectionCount()>0);
        }
     });
     setEnabled(folderView.getTableSelectionCount()>0);

  } // Constructor

  public void actionPerformed(ActionEvent e)
  {
     StringBuffer sb = new StringBuffer();
     MailMessage[] messs = folderView.getSelectedMessages();
     for(int i=0; i<messs.length; i++)
     {
        MailMessage mess = messs[i];
        sb.append(mess.getTextRepresentationForPrinting());
        if(i<messs.length-1) sb.append("\n\n\n");
     }
     SnowMailClientApp.getInstance().copyToClipboard(sb.toString());
  }   
}
 // CopyMessagesToClipboardAsText
