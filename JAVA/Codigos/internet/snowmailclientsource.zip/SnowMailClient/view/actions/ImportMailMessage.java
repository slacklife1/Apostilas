package SnowMailClient.view.actions;

import SnowMailClient.model.*;
import SnowMailClient.model.MailMessage;
import SnowMailClient.model.accounts.*;
import snow.utils.storage.*;
import SnowMailClient.view.*;
import SnowMailClient.SnowMailClientApp; 
import SnowMailClient.Language.Language;

import java.awt.*;
import java.io.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;

/**
*/
public class ImportMailMessage extends AbstractAction
{
  FolderView folderView;
                               
  public ImportMailMessage(FolderView folderView)
  {                             
     super(Language.translate("Import Mail message"));
     this.folderView = folderView;

/*     putValue(AbstractAction.SMALL_ICON,
              SnowMailClientApp.loadImageIcon("pics/new.PNG") );

     putValue(AbstractAction.ACCELERATOR_KEY,
              KeyStroke.getKeyStroke( KeyEvent.VK_N, KeyEvent.CTRL_MASK ) );
              */

     putValue(AbstractAction.SHORT_DESCRIPTION,
               Language.translate("Import a mail message from a file in the current mail folder"));

  } // Constructor

  public void actionPerformed(ActionEvent e)
  {
    String defDir = SnowMailClientApp.getInstance().getProperties().getProperty("ImportMailMessage_dir", System.getProperty("user.home", ""));
    JFileChooser fileLoad = new JFileChooser(defDir);
    fileLoad.setDialogTitle("Select the mail file(s) to import");
    fileLoad.setMultiSelectionEnabled(true);
    
    int rep = fileLoad.showOpenDialog(SnowMailClientApp.getInstance());
    if(rep==JFileChooser.APPROVE_OPTION)
    {
       File[] files = fileLoad.getSelectedFiles();
       for(int i=0; i<files.length; i++)
       {
          if(i==0)
          {
            SnowMailClientApp.getInstance().getProperties().setProperty("ImportMailMessage_dir", 
               files[0].getParent());
          }   
          try
          {
             byte[] content = FileUtils.getFileContent(files[i]);
             MailMessage mess = new MailMessage();
             mess.parse(new String(content));
             mess.setEditable(true);

             folderView.getMailFolder().addMessage(mess);
          }
          catch(Exception ex)
          {
             JOptionPane.showMessageDialog(
                 SnowMailClientApp.getInstance(),
                 "Error: "+ex.getMessage(),
                 "Error importing message",
                 JOptionPane.ERROR_MESSAGE);
          }

       }
    }



  }



} // ImportMailMessage
