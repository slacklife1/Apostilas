 package SnowMailClient.view.actions;

import SnowMailClient.MailEngine.*;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.model.*;
import SnowMailClient.model.accounts.*;
import SnowMailClient.view.*;
import SnowMailClient.view.MessagesPreview.*;
import SnowMailClient.view.accounts.AccountsEditor;
import SnowMailClient.utils.NumberedLineReader;
import snow.utils.gui.*;

import SnowMailClient.utils.*;
import SnowMailClient.view.dialogs.*;
import SnowMailClient.Language.Language;
import snow.lookandfeel.*;

import java.awt.*;                    
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import java.util.Vector;            
import java.io.*;          
import java.text.*;          

/** 
*/
public final class MessagesPreviewAction extends AbstractAction implements Runnable
{
   final private MailAccount account;
   final private AccountsEditor ref;

   private PreviewDialog previewDialog = null;
   private SecurePopConnection spop = null;

   public MessagesPreviewAction(AccountsEditor ref, MailAccount account)
   {
       super(Language.translate("Messages preview"));

       this.account = account;
       this.ref= ref;

       putValue(AbstractAction.SMALL_ICON, SnowMailClientApp.loadImageIcon("pics/messagespreview.PNG"));
/*       putValue(AbstractAction.ACCELERATOR_KEY,
                 KeyStroke.getKeyStroke( KeyEvent.VK_T,
                                         KeyEvent.CTRL_MASK ) );
                                         */
   }


   public void actionPerformed(ActionEvent actionEvent)
   {
      ref.saveSelectedMailAccount();

      final PreviewModel previewModel = new PreviewModel();
      previewDialog = new PreviewDialog(ref, previewModel, false);  // [Oct2005] no more modal

      Thread t = new Thread(this);
      t.start();
   }


   public void run()
   {
      // look at screen size...
      Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
      SnowMailClientApp.getInstance().getProperties().setComponentSizeFromINIFile(
        previewDialog, "MailPreviewDialog",
          (int) Math.min(ThemesManager.getLabelFontSize()*80, screen.getWidth()),
          (int) Math.min(ThemesManager.getLabelFontSize()*55, screen.getHeight()),
         ThemesManager.getLabelFontSize()*5,
         ThemesManager.getLabelFontSize()*5    
      );
      //SnowMailClientApp.CenterComponentOnMainFrame(previewDialog);

      EventQueue.invokeLater(new Runnable() { public void run()
      {
        // modal !!
        previewDialog.setVisible(true);
                             

        // terminate
        if(spop!=null)
        {
          try
          {    
            spop.terminateSession();
          }
          catch(Exception e)
          {
            //Ok, when stopped e.printStackTrace();
          }
        }
      }});  
          
          
      // 1: get connection
      //
      try
      {
        spop = account.getCheckedPopConnection();
      }
      catch(Exception e)
      {
        JOptionPane.showMessageDialog(ref.getContentPane(),
          "Cannot open connection to "+account.getPop()
          +"\n Error="+e.getMessage(),
          "Error opening connection", JOptionPane.ERROR_MESSAGE);

        // don't go
        return;
      }

      
      try                  
      {
        int[] nms = spop.getNumberOfMessages();
        
        if(nms[0]==0)
        {
          previewDialog.setStatusLabelText("You have no new messages.");
        }
        else
        {
          previewDialog.setMaximalMessageNumber(nms[0]);
          previewDialog.setStatusLabelText(
            Language.translate("You have % new messages", ""+nms[0])
             +" ("+MailMessageUtils.formatSize(nms[1])+")");             
        }

        String[] messUIDLS = spop.getMessagesUIDLs();
        int[] messSizes = spop.getSizes_from_MessagesLIST(spop.getMessagesLIST_());
                   
        for(int i=0; i<messSizes.length; i++)
        {    
           previewDialog.setMessageProgress(i);   
           String messHeaderText = spop.getMessageTop(messUIDLS[i], 0);
           try        
           {                                    
             final PreviewHeader header = new PreviewHeader(account, messUIDLS[i], messSizes[i]);
             Header.parseHeader(new NumberedLineReader(messHeaderText), header);

             EventQueue.invokeLater(new Runnable()
             { public void run()
               {
                 previewDialog.getPreviewModel().addMessageHeader(header);
               }
             });
           }
           catch(Exception e)
           {
             e.printStackTrace();
           }
        }
        previewDialog.setMessageProgressInvisible();
      }
      catch(Exception e)
      {
        e.printStackTrace();
        //doc.appendError(" Failed: "+e.getMessage());
        previewDialog.setStatusLabelText("ERROR: "+e.getMessage());
      }
      finally
      {    
        // connection terminated on close...
      }
      
      

    }

} // MessagesPreviewAction
