    package SnowMailClient.view.actions;

import SnowMailClient.model.AddressBook;
import snow.utils.storage.*;
import SnowMailClient.view.addresses.AddressBookView;
import SnowMailClient.SnowMailClientApp;    
import SnowMailClient.Language.Language;

                                  
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;          
                         
public class EditAddressBookAction extends AbstractAction
{                                    
  JFrame parent;
  AddressBook addressBook;  
  AppProperties properties;
                                  
  public EditAddressBookAction(JFrame parent, AddressBook addressBook, AppProperties properties)
  {
    super(Language.translate("Address Book"));

    putValue(AbstractAction.SMALL_ICON,
              SnowMailClientApp.loadImageIcon("pics/addressbook.PNG") );

    this.parent = parent;
    this.addressBook = addressBook;
    this.properties = properties;
    
  } // Constructor

  public void actionPerformed(ActionEvent e)
  { 
     new AddressBookView(SnowMailClientApp.getInstance());
  }


} //  EditAddressBookAction
