package SnowMailClient.view.actions;

import SnowMailClient.MailEngine.transfer.*;
import SnowMailClient.model.folders.*;
import SnowMailClient.model.accounts.*;
import SnowMailClient.model.*;
import snow.utils.gui.*;

import SnowMailClient.utils.*;
import SnowMailClient.MailEngine.*;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.view.folders.*;    
import SnowMailClient.Language.Language;

import java.awt.*;      
import java.util.*;
import java.awt.event.*;        
import javax.swing.*;
import javax.swing.event.*;        
import javax.swing.tree.*;         
import java.io.*; 

/** send and/or receive mails
*/
public class MailTransferAction extends AbstractAction
{  
  final MailTransferModel.TransferType type;

  public MailTransferAction(MailTransferModel.TransferType type)
  {
     super();
     this.type = type;

     if(type == MailTransferModel.TransferType.Receive)
     {                                                                                                       
       putValue(Action.NAME, Language.translate("Receive"));
       putValue(AbstractAction.SMALL_ICON, SnowMailClientApp.loadImageIcon("pics/receivemail2.PNG") );
       putValue(AbstractAction.SHORT_DESCRIPTION, Language.translate("Receive new mails from all accounts"));
     }   
     else if(type == MailTransferModel.TransferType.Send)
     {
       putValue(Action.NAME, Language.translate("Send"));
       putValue(AbstractAction.SMALL_ICON, SnowMailClientApp.loadImageIcon("pics/sendmail2.PNG") );
       putValue(AbstractAction.SHORT_DESCRIPTION, Language.translate("Send selected mails and outbox content"));
     } 
     else if(type == MailTransferModel.TransferType.SendAndReceive)
     {
       putValue(Action.NAME, Language.translate("Send / Receive"));
       //putValue(AbstractAction.SMALL_ICON, SnowMailClientApp.loadImageIcon("pics/sendmail2.PNG") );
       putValue(AbstractAction.SHORT_DESCRIPTION, Language.translate("Send mails in outbox and receive new mails"));
     }          
  } // Constructor
  
  // static => one for all actions
  static MailTransferDialog downloadDialog = null;

  public void actionPerformed(ActionEvent e)
  {                                                                                              
     // here we're in the EDT
     if(downloadDialog!=null)
     {
        if(downloadDialog.downloadTerminated) downloadDialog = null;
        else if(!downloadDialog.isVisible())  downloadDialog = null;
        else return;
     }
     
     if(type == MailTransferModel.TransferType.Send || type == MailTransferModel.TransferType.SendAndReceive)
     {
       // 1) put the selected message in the outbox
       // (but only if we are not already in the outbox)
       //          
       
       try
       {
          MailFolder outboxFolder = SnowMailClientApp.getInstance().getFoldersModel().getOutboxFolder().getMailFolder();
          if(SnowMailClientApp.getInstance().getFolderView().getMailFolder() != outboxFolder)
          {
             MailMessage[] messs = SnowMailClientApp.getInstance().getFolderView().getSelectedMessages();
             for(MailMessage m: messs)
             {
                try
                {
                  outboxFolder.addMessage(m);   // ok, we're in the EDT !!
                  SnowMailClientApp.getInstance().getFolderView().removeMail(m);
                  m.selectedInView = false;
                }
                catch(Exception ee)
                {
                  ee.printStackTrace();
                }
             }
          }
       }
       catch(Exception ee)
       {
         ee.printStackTrace();
       }
     }

     downloadDialog = new MailTransferDialog(SnowMailClientApp.getInstance(), type);
  }

} // ReceiveAllAction
