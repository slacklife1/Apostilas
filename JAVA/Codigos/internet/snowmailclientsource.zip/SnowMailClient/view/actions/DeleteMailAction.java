package SnowMailClient.view.actions;

import SnowMailClient.SnowMailClientApp;
import SnowMailClient.model.folders.*;
import SnowMailClient.model.*;
import SnowMailClient.view.folders.*;
import SnowMailClient.view.*;     
import SnowMailClient.Language.Language;     

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;  

/** delete the selected mail (move in the deleted folder)
*/                      
public class DeleteMailAction extends AbstractAction
{
  FolderView folderView;              
  FolderTreeNode deletedNode;
  
  public DeleteMailAction(FolderView _folderView, FolderTreeNode deletedNode)
  {
     super(Language.translate("Delete selected mail"));
     this.folderView  = _folderView;   
     this.deletedNode = deletedNode;
     
     putValue(AbstractAction.ACCELERATOR_KEY,                        
              KeyStroke.getKeyStroke( KeyEvent.VK_D, KeyEvent.CTRL_MASK ) );
              
     putValue(AbstractAction.SMALL_ICON, SnowMailClientApp.loadImageIcon("pics/delete.PNG"));
     
     folderView.getTableSelectionModel().addListSelectionListener(  new ListSelectionListener()
     {
        public void valueChanged(ListSelectionEvent e)
        {                       
           setEnabled(folderView.getTableSelectionCount()>0);
        }
     });                             
     setEnabled(folderView.getTableSelectionCount()>0);
     
  } // Constructor

  public void actionPerformed(ActionEvent e)
  {  
    MailMessage[] messs = folderView.getSelectedMessages();
    for(MailMessage mess : messs)
    {
       try         
       {  
         if( folderView.getMailFolder().equals(deletedNode.getMailFolder()))
         {
           // definitively destroy...
         }
         else
         { 
           // put in deleted
           mess.setIsNoMoreNew();
           mess.selectedInView = false;  // desselect
           deletedNode.getMailFolder().addMessage(mess);
         }   
         
         folderView.removeMail(mess);
       }
       catch(Exception ex)
       {
         ex.printStackTrace();
       }
    }
  }



} // DeleteMailAction
