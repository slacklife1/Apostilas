package SnowMailClient.view.actions;

import SnowMailClient.SnowMailClientApp;
import SnowMailClient.model.folders.*;
import SnowMailClient.model.*;
import SnowMailClient.view.folders.*;
import SnowMailClient.view.*;
import SnowMailClient.Language.Language;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
           

/** delete the selected mail (move in the deleted folder)
*/
public class RemoveSPAMCategory extends AbstractAction
{
  FolderView folderView;
                                   
  public RemoveSPAMCategory(FolderView _folderView)
  {
     super(Language.translate("Remove SPAM or HAM definition"));
     this.folderView  = _folderView;

     //putValue(AbstractAction.SMALL_ICON, SnowMailClientApp.loadImageIcon("pics/addtospam.PNG"));


     folderView.getTableSelectionModel().addListSelectionListener(  new ListSelectionListener()
     {
        public void valueChanged(ListSelectionEvent e)
        {
           setEnabled(folderView.getTableSelectionCount()>0);
        }
     });
     setEnabled(folderView.getTableSelectionCount()>0);

  } // Constructor

  public void actionPerformed(ActionEvent e)
  {
     MailMessage[] messs = folderView.getSelectedMessages();
     for(MailMessage mess: messs)
     {
        mess.setHAM(false);
        mess.setSPAM(false);

        // ### should update here the stat
  /*      SnowMailClientApp.getInstance().getWordStatistic().addText(
          mess.getMessageBody(), true); */
     }
    // folderView.getMailFolder().notifyMailFolderListener_of_ContentEdited();
  }
                         


} // RemoveSPAMCategory
