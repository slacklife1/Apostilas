package SnowMailClient.view.actions;

import SnowMailClient.MailEngine.*;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.model.*;
import SnowMailClient.model.accounts.*;
import SnowMailClient.view.*;
import SnowMailClient.view.accounts.AccountsEditor;
import snow.utils.gui.*;

import SnowMailClient.utils.*;
import SnowMailClient.view.dialogs.*;
import SnowMailClient.Language.Language;
import snow.lookandfeel.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import java.util.Vector;
import java.io.*;
import java.text.*;

/** 
*/
public class TestAccountSettings extends AbstractAction                            
{                                     
   MailAccount account;
   AccountsEditor ref;

   public TestAccountSettings(AccountsEditor ref, MailAccount account)
   {           
       super(Language.translate("Test account settings"));
       this.account = account;
       this.ref= ref;

       putValue(AbstractAction.SMALL_ICON, SnowMailClientApp.loadImageIcon("pics/ok.PNG"));
       putValue(AbstractAction.ACCELERATOR_KEY,
                 KeyStroke.getKeyStroke( KeyEvent.VK_T,
                                         KeyEvent.CTRL_MASK ) );
   }

   public synchronized void actionPerformed(ActionEvent actionEvent)
   {  
      ref.saveSelectedMailAccount();

      Thread t = new Thread()      
      { 
        public void run()
        {
          performTest();
        }
      };
      t.start();                       
   }
   
         
   private void performTest()
   {
      final JDialog dialog = new JDialog( ref, 
         Language.translate("Test settings for %",account.getAddress()), false);
      dialog.setContentPane(new SnowBackgroundPanel(new BorderLayout()));
      StyledTextDocument doc = new StyledTextDocument();
      JTextPane textPane = new JTextPane(doc.doc);
      JScrollPane jsp = new JScrollPane(textPane);
      jsp.setOpaque(false);
      jsp.getViewport().setOpaque(false);
      textPane.setOpaque(false);

      dialog.getContentPane().add(jsp, BorderLayout.CENTER);
      final CloseControlPanel ccp = new CloseControlPanel(dialog, true, false, Language.translate("Close"));
      ccp.setOkEnabled(false); // later
      dialog.getContentPane().add(ccp, BorderLayout.SOUTH);

      dialog.setSize(ThemesManager.getLabelFontSize()*50, ThemesManager.getLabelFontSize()*55);
      SnowMailClientApp.centerComponentOnMainFrame(dialog);
      EventQueue.invokeLater(new Runnable() { public void run()
      { 
        // modal !!
        dialog.setVisible(true);
      }});

      SecurePopConnection spop = null;
      try
      {   
        doc.appendStyled("1) Connecting to pop server at "+account.getPop()+"\n", "bold");
        Thread.sleep(500);
        spop = account.getCheckedPopConnection();
        doc.append("  OK.");  
        doc.appendComment(spop.getConnectionStatusExplanation()+"\n");

        if(ccp.getWasCancelled())
        {
          doc.append("\n  Test cancelled.");
          EventQueue.invokeLater(new Runnable() { public void run()
          {
            ccp.setOkEnabled(true);
          }});
          return;
        }

        doc.appendStyled("\n2) Retrieving the number of new messages\n", "bold");
        Thread.sleep(500);
        int[] nms = spop.getNumberOfMessages();
        doc.append("\n  OK, you have "+nms[0]+" new messages ("+nms[1]+" bytes)");

        String[] messUIDLS = spop.getMessagesUIDLs();
        for(int i=0; i<messUIDLS.length; i++)
        {
           doc.append("\nMess "+(i+1)+": \t");

           String messHeaderText = spop.getMessageTop(messUIDLS[i], 0);
           try           
           {
             Header header = new Header();
             Header.parseHeader(new NumberedLineReader(messHeaderText), header);
             HeaderEntry he = header.getEntry("From");
             if(he!=null)
             {  
               Address ad = new Address(he.getValue());
               doc.append("  "+ad.getMailAddress());
             }
             else
             {
               doc.append("  NO FROM ");
             }

             he = header.getEntry("Subject");
             if(he!=null)
             {
               doc.append("\t"+he.getValue());
             }
             else
             {                   
               doc.append("\t NO Subject ");
             }

           }
           catch(Exception e)
           {
             doc.append("\tHEADER ERROR "+e.getMessage());
             e.printStackTrace();
           }

        }
      }
      catch(Exception e)
      {
        //e.printStackTrace();
        doc.appendError(" Failed: "+e.getMessage());
      }
      finally
      {
        if(spop!=null)
        {
          try {spop.terminateSession();}
          catch(Exception ee){}
        }
      }

      if(ccp.getWasCancelled())
      {
        doc.append("\n  Test cancelled.");
          EventQueue.invokeLater(new Runnable() { public void run()
          {
            ccp.setOkEnabled(true);
          }});
        
        return;
      }

      if(account.getUseToSendMails())
      {
        SecureSmtpConnection ssmtp = null;
        try
        {
          Thread.sleep(500);
          doc.appendStyled("\n3) Connecting to smtp server at "+account.getSMTP()+"\n", "bold");
          ssmtp = account.getSMTPConnection();
          doc.append("\n  OK.");
          doc.appendComment(ssmtp.getConnectionStatusExplanation()+"\n");
  
          if(ccp.getWasCancelled())
          {
            doc.append("\n  Test cancelled.");
            EventQueue.invokeLater(new Runnable() { public void run()
            {
              ccp.setOkEnabled(true);
            }});

            return;
          }


          doc.appendStyled("\n4) Sending a test mail\n", "bold");

          Address from = new Address(""+account.getName()+" <"+account.getAddress()+">") ;

          MailMessage mess = new MailMessage(); 
          Vector<Address> tos =new Vector<Address>();
          tos.addElement(from);
          mess.setMessage(
            from,
            tos,
            Language.translate("Test message from SnowMailClient."),
            Language.translate("This is a test message sent from SnowMailClient to test the account settings.")+"\r\n");

  /*        mess.parse("from:"+from+"\nto:"+from
             +"\nsubject: Test message from SnowMailClient."
             +"\n\nThis is a test message sent from SnowMailClient to test the account settings.");*/

          mess.setEditable(false);
          ssmtp.sendMessage(mess, null, null);
                       
          doc.append("  OK.");
        }
        catch(Exception e)
        {
          //e.printStackTrace();
          doc.appendError("\n Failed: "+e.getMessage());
        }
        finally
        {
          if(ssmtp!=null)
          {
            try {ssmtp.terminateSession();}
            catch(Exception ee){}
          }
        }
      }

      EventQueue.invokeLater(new Runnable() { public void run()
      {
        ccp.setOkEnabled(true);
      }});  
    }

}
 // TestAccountSettings
