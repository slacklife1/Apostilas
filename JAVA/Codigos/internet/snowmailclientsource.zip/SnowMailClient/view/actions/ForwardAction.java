package SnowMailClient.view.actions;

import SnowMailClient.model.folders.*;
import SnowMailClient.model.MailMessage;
import SnowMailClient.model.accounts.*;
import SnowMailClient.model.Address;
import SnowMailClient.view.folders.*;
import SnowMailClient.view.*;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.Language.Language;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;

public class ForwardAction extends AbstractAction
{
  FolderTreeNode inbox;
  MailAccounts accounts;
  FolderView folderView;

  boolean copyContent = true;         

  public ForwardAction(FolderView _folderView, MailAccounts accounts, FolderTreeNode inbox)
  {                          
     super(Language.translate("Forward"));

     this.inbox = inbox;
     this.accounts = accounts;
     this.folderView = _folderView;

     putValue(AbstractAction.SMALL_ICON,
              SnowMailClientApp.loadImageIcon("pics/forward.PNG") );

     putValue(AbstractAction.ACCELERATOR_KEY,
              KeyStroke.getKeyStroke( KeyEvent.VK_F, KeyEvent.CTRL_MASK ) );

     putValue(AbstractAction.SHORT_DESCRIPTION,
              Language.translate("Forward the actual message"));

     folderView.getTableSelectionModel().addListSelectionListener(  new ListSelectionListener()
     {
        public void valueChanged(ListSelectionEvent e)
        {                  
           setEnabled(folderView.getTableSelectionCount()==1);
        }
     });
     setEnabled(folderView.getTableSelectionCount()==1);
     
  } // Constructor

  public void actionPerformed(ActionEvent e)
  {
    MailMessage[] messs = folderView.getSelectedMessages();
    if(messs.length==1)
    {
       MailMessage mess = messs[0];

       Address to = mess.getFromAddress();

       // ### use the same send account as in the message if possible  (look in mess.to)
       Address from = new Address();
       MailAccount ma = accounts.getSendMailAccount();
       if(ma!=null)
       {
         from.setMailAddress( ma.getAddress() );
         from.setName( ma.getName() );
       }                     



/*       //replyMessage.setIsReplyMessage(mess.getMessageID());                      
       replyMessage.setMessage(from, new Address[]{to},
               Language.translate("Forward")+": "+mess.getHeader().getEntryValue("subject", "?"),
               mess.getMessageBody());
       replyMessage.setEditable(true);*/


       try
       {
         MailMessage replyMessage = new MailMessage();
         replyMessage.createFromVectorRepresentation(mess.getVectorRepresentation());
         //replyMessage.setMessageHeader(;
         // ###
         replyMessage.setMessageHeader(null, null, 
             Language.translate("Forward")+": "+mess.getHeader().getEntryValue("subject", "?"));
         replyMessage.setEditable(true);


         inbox.getMailFolder().addMessage(replyMessage);
         inbox.saveMailFolder(false); // don't close
       }
       catch(Exception ex)
       {
         ex.printStackTrace();
       }
    }
  }

} // ForwardAction
