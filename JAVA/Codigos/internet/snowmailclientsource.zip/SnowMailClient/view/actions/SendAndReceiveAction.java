package SnowMailClient.view.actions;

import SnowMailClient.model.folders.*;
import SnowMailClient.model.*;
import SnowMailClient.SnowMailClientApp;
import snow.utils.gui.*;

import SnowMailClient.view.folders.*;
import SnowMailClient.Language.Language;
                                  
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
                          
public class SendAndReceiveAction// extends AbstractAction
{                            
/*          
  SendAction sendAction;
  ReceiveAllAction receiveAction;   
            
                                            
  public SendAndReceiveAction(SendAction sendAction, ReceiveAllAction receiveAction)
  {
     super(Language.translate("Send / Receive"));
     this.sendAction = sendAction;
     this.receiveAction = receiveAction;
                
     putValue(AbstractAction.SHORT_DESCRIPTION,
              Language.translate("Send mails in outbox and receive new mails"));


  } // Constructor


  public void actionPerformed(ActionEvent e)
  {
     // here we're in the EDT
     Thread t = new Thread()
     {
       public void run()
       {     
         final ProgressModalDialog progressDialog = new ProgressModalDialog(       
                   SnowMailClientApp.getInstance(),
                   Language.translate("Sending / Receiving mails"), true);
         try
         {
           
           progressDialog.start();

           sendAction.sendAction(progressDialog);
         }
         finally
         {
           progressDialog.closeDialog();
         }

         receiveAction.actionPerformed(null);         
       }       
     };       
     t.start();

  }
    */


}// SendAndReceiveAction
