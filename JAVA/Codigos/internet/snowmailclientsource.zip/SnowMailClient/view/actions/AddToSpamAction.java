package SnowMailClient.view.actions;

import SnowMailClient.SnowMailClientApp;
import SnowMailClient.model.folders.*;
import SnowMailClient.model.*;
import SnowMailClient.view.folders.*;
import SnowMailClient.view.*;     
import SnowMailClient.Language.Language;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;  
                

/** delete the selected mail (move in the deleted folder)
*/
public final class AddToSpamAction extends AbstractAction
{
  FolderView folderView;      
                                  
  public AddToSpamAction(FolderView _folderView)
  {
     super(Language.translate("Set selected messages as Spam"));
     this.folderView  = _folderView;

/*     putValue(AbstractAction.ACCELERATOR_KEY,
                KeyStroke.getKeyStroke( KeyEvent.VK_D, KeyEvent.CTRL_MASK ) );*/

     putValue(AbstractAction.SMALL_ICON, SnowMailClientApp.loadImageIcon("pics/addtospam.PNG"));


     folderView.getTableSelectionModel().addListSelectionListener(  new ListSelectionListener()
     {
        public void valueChanged(ListSelectionEvent e)
        {
           setEnabled(folderView.getTableSelectionCount()>0);
        }
     });
     setEnabled(folderView.getTableSelectionCount()>0);

  } // Constructor

  public void actionPerformed(ActionEvent e)
  {
     MailMessage[] messs = folderView.getSelectedMessages();
     for(MailMessage mess: messs)
     {
        mess.setSPAM(true);     

        // NO, don't fill the address book with that...
        //AddressBook spamBook = SnowMailClientApp.getInstance().getSpamBook();
        //spamBook.addAddress( mess.getFromAddress() );

        // ### should update here the stat
  /*      SnowMailClientApp.getInstance().getWordStatistic().addText(
          mess.getMessageBody(), true); */
     }
    // folderView.getMailFolder().notifyMailFolderListener_of_ContentEdited();
  }



} // AddToSpamAction

