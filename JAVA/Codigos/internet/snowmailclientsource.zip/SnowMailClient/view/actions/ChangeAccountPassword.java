package SnowMailClient.view.actions;

import SnowMailClient.MailEngine.*;   
import SnowMailClient.*;
import SnowMailClient.model.*;
import SnowMailClient.model.accounts.*;
import SnowMailClient.view.*;
import SnowMailClient.view.dialogs.*;
import SnowMailClient.Language.Language;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import java.util.Vector;


/** this command is only avaiable for admin users
*/
public final class ChangeAccountPassword extends AbstractAction
{
   final private MailAccount ma;
   final private JDialog parent;   
                                           
   public ChangeAccountPassword(MailAccount ma, JDialog parent)
   {
       super(Language.translate("Change password"));
       
       this.ma = ma;
       this.parent = parent;
       
       putValue(AbstractAction.SMALL_ICON, SnowMailClientApp.loadImageIcon("pics/key.PNG"));
       
       putValue(AbstractAction.ACCELERATOR_KEY,
                 KeyStroke.getKeyStroke( KeyEvent.VK_P,
                                         KeyEvent.CTRL_MASK ) );
   }

   public void actionPerformed(ActionEvent actionEvent)
   {
       ChangePasswordDialog dialog = new ChangePasswordDialog(ma, parent);
       dialog.pack();
       SnowMailClientApp.centerComponentOnMainFrame(dialog);
       dialog.setVisible(true);
   }

}                                  
