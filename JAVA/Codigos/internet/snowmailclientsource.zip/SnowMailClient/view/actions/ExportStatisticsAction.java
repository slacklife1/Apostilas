package SnowMailClient.view.actions;

import SnowMailClient.model.accounts.*;
import SnowMailClient.utils.storage.*;
import snow.utils.gui.*;

import SnowMailClient.view.accounts.*;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.Language.Language;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import javax.swing.border.*;
import java.io.*;
                           
public class ExportStatisticsAction extends AbstractAction
{             

  public ExportStatisticsAction()      
  {                    
     super(Language.translate("Export SPAM word statistics to file"));

/*     putValue(AbstractAction.SMALL_ICON,
              SnowMailClientApp.loadImageIcon("pics/exportstat.PNG") );

     putValue(AbstractAction.ACCELERATOR_KEY,
              KeyStroke.getKeyStroke( KeyEvent.VK_R, KeyEvent.CTRL_MASK ) );

     putValue(AbstractAction.SHORT_DESCRIPTION,
              Language.Translatse("Export the stats"));*/
                                
  } // Constructor                  


  public void actionPerformed(ActionEvent e)
  {
     FileField destinationDir = new FileField("c:/data/SnowMailWordStatExport.txt",
        true,
        Language.translate("Select the file to export the statistics"), false);
                                           
     JDialog dialog = new JDialog(SnowMailClientApp.getInstance(), Language.translate("Statistics file export"), true);
     dialog.getContentPane().setLayout(new BorderLayout());

     // south
     //
     CloseControlPanel ccp = new CloseControlPanel(dialog, true, true, Language.translate("Close"));
     dialog.getContentPane().add(ccp, BorderLayout.SOUTH);

     // center
     //                             

     JPanel inputPanel = new JPanel();
     GridLayout3 gl = new GridLayout3(2,inputPanel);
     inputPanel.setBorder(new EmptyBorder(5,5,5,5));
     dialog.getContentPane().add(SnowMailClientApp.wrapLeft(inputPanel), BorderLayout.CENTER);
     gl.add(new JContrastLabel(Language.translate("Destination file")+" "), false);
     gl.add(destinationDir, true);


     dialog.pack();
     SnowMailClientApp.centerComponentOnMainFrame(dialog);
     dialog.setVisible(true);

     if(!ccp.getWasCancelled())
     {
       final File file = destinationDir.getPath();
       if(file!=null)
       {
          Thread t = new Thread()
          {
            public void run()
            {
              try
              {
                 SnowMailClientApp.getInstance().getWordStatistic().exportStatToFile(file);
              }
              catch(Exception e)
              {
                 e.printStackTrace();
              }
            }
          };
          t.setPriority(Thread.NORM_PRIORITY-1);
          t.start();


       }
     }

  }   
  

} // ExportStatisticsAction
