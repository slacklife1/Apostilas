package SnowMailClient.view.actions;

import SnowMailClient.model.folders.*;
import SnowMailClient.model.MailMessage;
import SnowMailClient.model.accounts.*;
import SnowMailClient.model.Address;
import SnowMailClient.view.folders.*;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.Language.Language;

import java.awt.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;

public class CreateNewMail extends AbstractAction
{
  FolderTreeNode inbox;  
  MailAccounts accounts;                                                                                                      

  public CreateNewMail(MailAccounts accounts, FolderTreeNode inbox)
  {
     super(Language.translate("New mail message"));
     this.inbox = inbox;
     this.accounts = accounts;

     putValue(AbstractAction.SMALL_ICON,
              SnowMailClientApp.loadImageIcon("pics/composemail.PNG") );
                           
     putValue(AbstractAction.ACCELERATOR_KEY,
              KeyStroke.getKeyStroke( KeyEvent.VK_N, KeyEvent.CTRL_MASK ) );
               
     putValue(AbstractAction.SHORT_DESCRIPTION,  
              Language.translate("Create a new empty mail"));

  } // Constructor

  public void actionPerformed(ActionEvent e)
  {                                    
    Address from = new Address();
    MailAccount ma = accounts.getSendMailAccount();
    if(ma!=null)
    {
      from.setMailAddress( ma.getAddress() );
      from.setName( ma.getName() );
    }

    MailMessage mess = new MailMessage();
    mess.setMessage(from, new Vector<Address>(), "?", "new message");
    mess.setEditable(true);

    try
    {
      inbox.getMailFolder().addMessage(mess);
      inbox.saveMailFolder(false); // don't close
    }
    catch(Exception ex)
    {
      ex.printStackTrace();
    }
  }



} // CreateNewMail
