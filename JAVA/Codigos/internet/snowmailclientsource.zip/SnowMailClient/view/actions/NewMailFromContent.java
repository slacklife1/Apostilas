package SnowMailClient.view.actions;

import SnowMailClient.model.folders.*;
import SnowMailClient.model.MailMessage;
import SnowMailClient.model.accounts.*;
import SnowMailClient.view.folders.*;
import SnowMailClient.SnowMailClientApp;  
import SnowMailClient.Language.Language;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;          
import javax.swing.event.*;
import javax.swing.tree.*;
          
/** DEBUG UTILITY
*/
public class NewMailFromContent extends AbstractAction
{
  FolderTreeNode inbox;
  MailAccounts accounts;

  public NewMailFromContent(MailAccounts accounts, FolderTreeNode inbox)
  {
     super(Language.translate("New mail message from content"));
     this.inbox = inbox;
     this.accounts = accounts;

/*     putValue(AbstractAction.SMALL_ICON,
              SnowMailClientApp.loadImageIcon("pics/composemail.PNG") );

     putValue(AbstractAction.ACCELERATOR_KEY,
              KeyStroke.getKeyStroke( KeyEvent.VK_N, KeyEvent.CTRL_MASK ) );
              */

     putValue(AbstractAction.SHORT_DESCRIPTION,
              "Create a new empty mail from a pasted content");

  } // Constructor

  public void actionPerformed(ActionEvent e)
  { 
    JDialog dialog = new JDialog(SnowMailClientApp.getInstance(), 
         "Paste the content here and press ALT-F4, and look in the compose folder", true);
    dialog.getContentPane().setLayout(new BorderLayout());
    JTextArea ta = new JTextArea(50,50);
    dialog.getContentPane().add(new JScrollPane(ta), BorderLayout.CENTER);
    dialog.setSize(500,500);
    dialog.setVisible(true);
       
    String from = "?";
    MailAccount ma = accounts.getSendMailAccount();
    if(ma!=null) from = ma.getAddress();

    MailMessage mess = new MailMessage();
    mess.parse(ta.getText());
    mess.setEditable(true);

    try
    {
             inbox.getMailFolder().addMessage(mess);
             inbox.saveMailFolder(false); // don't close
    }
    catch(Exception ex)
    {
             JOptionPane.showMessageDialog(
                 SnowMailClientApp.getInstance(),
                 "Error: "+ex.getMessage(),
                 "Error parsing message",
                 JOptionPane.ERROR_MESSAGE);
    }
  }



} // NewMailFromContent
                    
