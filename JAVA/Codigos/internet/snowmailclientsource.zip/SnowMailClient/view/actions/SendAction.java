package SnowMailClient.view.actions;

import SnowMailClient.model.folders.*;
import SnowMailClient.model.accounts.*;
import SnowMailClient.model.*;
import snow.utils.gui.*;

import SnowMailClient.MailEngine.*;
import SnowMailClient.MailEngine.transfer.TransferFunctions;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.view.folders.*;
import SnowMailClient.view.FolderView;
import SnowMailClient.Language.Language;
import SnowMailClient.GnuPG.*;
import SnowMailClient.GnuPG.model.GnuPGKeyID;

import java.awt.*;         
import java.util.*;
import java.awt.event.*;     
import javax.swing.*; 
import javax.swing.event.*;   
import javax.swing.tree.*; 
                                  
/** send mail action
*/
public class SendAction extends AbstractAction
{                              
  FolderTreeNode sent, outbox;          
  
  MailFolder sentFolder, outboxFolder;
  FolderView folderView;

  private SendAction( )
  {
     super(Language.translate("Send"));

     this.sent       = SnowMailClientApp.getInstance().getFoldersModel().getSentFolder();
     this.outbox     = SnowMailClientApp.getInstance().getFoldersModel().getOutboxFolder();
     this.folderView = SnowMailClientApp.getInstance().getFolderView();
                     
     putValue(AbstractAction.SMALL_ICON,
              SnowMailClientApp.loadImageIcon("pics/sendmail2.PNG") );

/*Dangerous, BETTER: user MUST press the send button
     putValue(AbstractAction.ACCELERATOR_KEY,
              KeyStroke.getKeyStroke( KeyEvent.VK_R, KeyEvent.CTRL_MASK ) );*/

     putValue(AbstractAction.SHORT_DESCRIPTION,
              Language.translate("Send selected mails and outbox content"));
                           
     folderView.getTableSelectionModel().addListSelectionListener(
       new ListSelectionListener()             
       {
          public void valueChanged(ListSelectionEvent e)
          {
            updateButtonVisibility();
          }
       }
     );  

     try
     {
       sentFolder  = sent.getMailFolder();
       outboxFolder = outbox.getMailFolder();
       outboxFolder.addTableModelListener(new TableModelListener()
       {
          public void tableChanged(TableModelEvent e)
          {
             updateButtonVisibility();                
          }
       });
     }
     catch(Exception ex)
     {
       ex.printStackTrace();
     }    
     
     updateButtonVisibility();
  } // Constructor

  
  /** action enable if either the outbox has items or messages are selected
      in another folder
  */
  private void updateButtonVisibility()
  {
      int n = outboxFolder.getRowCount() + folderView.getTableSelectionCount();
      this.setEnabled( n>0 );
  }

  public void actionPerformed(ActionEvent e)
  { 
     // EDT
     // 1) put the selected message in the outbox
     // (but only if we are not already in the outbox)
     //
     if(folderView.getMailFolder()!=this.outboxFolder)
     {        
        MailMessage[] messs = folderView.getSelectedMessages();
        for(MailMessage m: messs)
        {
          try              
          {
            outboxFolder.addMessage(m);   // ok, we're in the EDT !!
            folderView.removeMail(m);
            m.selectedInView = false;
          }
          catch(Exception ee)
          {
            ee.printStackTrace();
          }
        }
     }

     // 2) send all messages present in the outbox
     //
     // here we're in the EDT, do send (long task) in a thread
     Thread t = new Thread()
     {
       public void run()   
       {                  
         final ProgressModalDialog progressDialog = new ProgressModalDialog(
            SnowMailClientApp.getInstance(), "Sending mail", true);
         progressDialog.start();
         
         sendAction(progressDialog);
                   
         progressDialog.closeDialog();
         
       }
     };
     t.start();             
  }
  
  /** this long task occurs in a separate thread...
      method is public because it is called from the send/receive action
  */
  public void sendAction(final ProgressModalDialog progressDialog)
  {                                  
     if(outboxFolder.getRowCount()==0)
     {                       
        JOptionPane.showMessageDialog(progressDialog, 
          Language.translate("There are no messages to send in the outbox"),
          "No messages to send", JOptionPane.INFORMATION_MESSAGE);
        SnowMailClientApp.getInstance().getGlobalConsole().appendSmallLine(
          Language.translate("No messages to send."));
        return;
     }     

     progressDialog.setProgressBounds(outboxFolder.getRowCount());
     EventQueue.invokeLater(new Runnable() { public void run() {
        progressDialog.setTitle(Language.translate("Sending mail"));
     }});

     AddressBook addressBook = SnowMailClientApp.getInstance().getAddressBook();

     // be careful, the folder size will decrease as the mails are sent...
     int count = outboxFolder.getRowCount();

     // collect mails to send
     Vector<MailMessage> mailsToSend = new Vector<MailMessage>();
     mailsToSend.addAll(  outboxFolder.getAllMessages() );

     // send
     int counter = 0;
     for(MailMessage mess: mailsToSend)
     {
        counter++;
        String toAddress = mess.getToAddressesText();

        progressDialog.setProgressValue(counter, Language.translate("Message")+" "+counter+" / "+count);
        progressDialog.setCommentLabel(Language.translate("Sending mail to %",toAddress));

        if(progressDialog.wasCancelled()) break;
        
        try
        { 
          //TransferFunctions.sendMail( mess, progressDialog );
                     
          // add the address to the book                          
          Vector<Address> addresses = Address.parseAddressList(toAddress);
          for(Address a : addresses)
          {
            addressBook.incrementMailsSendedTo( a );
          }
        }
        catch(Exception e)
        {
          JOptionPane.showMessageDialog(SnowMailClientApp.getInstance().getContentPane(),
            ""+e.getMessage(),
            Language.translate("Cannot send mail"), JOptionPane.ERROR_MESSAGE);
          SnowMailClientApp.getInstance().getGlobalConsole().appendSmallLine(
               Language.translate("Cannot send mail")+":\n "+e.getMessage());
    
          e.printStackTrace();
        
        }
     }     
  }  
  
  
  
                      


}// SendAction
                                             
