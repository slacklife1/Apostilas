package SnowMailClient.view.actions;

import SnowMailClient.MailEngine.*;
import SnowMailClient.*;
import SnowMailClient.model.*;
import SnowMailClient.model.accounts.*;
import SnowMailClient.view.*;
import SnowMailClient.view.dialogs.*; 
import SnowMailClient.Language.Language;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.ChangeEvent;                                                     
import java.util.Vector;

                                          
/** this command is only avaiable for admin users
*/
public class SetUserPass extends AbstractAction
{  
   MailAccount account;
   JDialog ref;

   public SetUserPass(JDialog ref, MailAccount account)
   {                              
       super(Language.translate("Set a user pasword"));
       this.account = account;
       this.ref= ref;         

       putValue(AbstractAction.SMALL_ICON, SnowMailClientApp.loadImageIcon("pics/key.PNG"));
/*       putValue(AbstractAction.ACCELERATOR_KEY,
                 KeyStroke.getKeyStroke( KeyEvent.VK_U,
                                         KeyEvent.CTRL_MASK ) );    */
   }

   public void actionPerformed(ActionEvent actionEvent)
   {
/*       MailAccount admin = accounts.getSnowraverAdministratorMailAccount();
       if(admin==null)
       {
          JOptionPane.showMessageDialog(      
             ref, "ERROR: No account has administrator privileges");
          return;
       }   */

       AddNewUserDialog dialog = new AddNewUserDialog(ref, account.getPop());
       dialog.setTitle(
         Language.translate("Set a % user password", account.getPop()));
       dialog.pack();
       SnowMailClientApp.centerComponentOnMainFrame(dialog);
       dialog.setVisible(true);

       if(dialog.addNewUserOnExit)
       {
          try
          {                                       
             SecurePopConnection sp = account.getCheckedPopConnection();
             sp.setUserPassword( dialog.getUserName(), dialog.getPassword() );
             sp.terminateSession();
          }
          catch(Exception ex)
          {
             // ### shit, the message is not nice
             ex.printStackTrace();
             JOptionPane.showMessageDialog(
               ref, "Error: \n"+ex.getMessage(), 
               "Failed to add new user",
               JOptionPane.ERROR_MESSAGE);
          }
       }

   }

}// SetUserPass
