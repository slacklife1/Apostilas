package SnowMailClient.view.actions;

import SnowMailClient.model.accounts.*;
import snow.utils.storage.*;
import snow.utils.gui.*;

import SnowMailClient.utils.storage.Backup;
import SnowMailClient.view.accounts.*;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.Language.Language;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import javax.swing.border.*;
import java.io.*;

public final class BackupConfigurationAction extends AbstractAction
{

  public BackupConfigurationAction()
  {
     super(Language.translate("Backup Configuration"));

/*     putValue(AbstractAction.SMALL_ICON,
              SnowMailClientApp.loadImageIcon("pics/receivemail.PNG") );

     putValue(AbstractAction.ACCELERATOR_KEY,
              KeyStroke.getKeyStroke( KeyEvent.VK_R, KeyEvent.CTRL_MASK ) );*/

     putValue(AbstractAction.SHORT_DESCRIPTION,
              Language.translate("Configure the backup"));

  } // Constructor                  


  public void actionPerformed(ActionEvent e)
  {
     Backup backup = SnowMailClientApp.getInstance().getBackup();

     FileField destinationDir = new FileField(backup.getBackupDestinationDirectory(),
       true, Language.translate("Select the backup destination directory"), true);

     JCheckBox enableautomaticBackup = new JCheckBox(Language.translate("Enable automatic backups"), backup.isAutomaticBackupEnabled());

     JDialog dialog = new JDialog(SnowMailClientApp.getInstance(), Language.translate("Backup Configuration"), true);
     dialog.getContentPane().setLayout(new BorderLayout());
     
     // north
     //   
     JTextArea textarea = new JTextArea(
        Language.translate(
        "The backup makes a copy of all your snowmail data and put in"
        +"\nthe destination directory at each closing of snowmail."
        +"\nIt keeps only a clever set of older backups."
       +"\nAt most one per hour today, one per day for the last week,"
       +"\none per month for the last month..."
       +"\nNormally, you don't have to worry about backups,"
       +"\nthey are working silently in the background and we hope"
       +"\nyou'll never need one of them. Backups are useful for"
       +"\ntransferring snowmail from a computer to another."));
       
     textarea.setBorder(new EmptyBorder(5,5,5,5));
     textarea.setBackground( dialog.getBackground() );

     textarea.setEditable(false);
     dialog.getContentPane().add(textarea, BorderLayout.NORTH);

     // south
     //
     CloseControlPanel ccp = new CloseControlPanel(dialog, true, true, Language.translate("Validate"));
     dialog.getContentPane().add(ccp, BorderLayout.SOUTH);

     // center
     //
     JPanel inputPanel = new JPanel(new GridLayout(2,2));
     inputPanel.setBorder(new EmptyBorder(5,5,5,5));
     dialog.getContentPane().add(SnowMailClientApp.wrapLeft(inputPanel), BorderLayout.CENTER);
     inputPanel.add(enableautomaticBackup);
     inputPanel.add(new JPanel());
     inputPanel.add(new JContrastLabel(Language.translate("Destination Directory")+" "));
     inputPanel.add(destinationDir);  

       
     dialog.pack();
     SnowMailClientApp.centerComponentOnMainFrame(dialog);
     dialog.setVisible(true);

     if(!ccp.getWasCancelled())
     {   
       File file = destinationDir.getPath();
       if(file!=null)
       {
          backup.setBackupDestination(file.getAbsolutePath());
          backup.setIsAutomaticBackupEnabled(enableautomaticBackup.isSelected());
       }
     }

  }   
  

} // BackupConfigurationAction
