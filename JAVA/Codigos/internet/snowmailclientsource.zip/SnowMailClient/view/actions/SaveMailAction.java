package SnowMailClient.view.actions;

import SnowMailClient.model.folders.*;
import SnowMailClient.model.*;
import SnowMailClient.view.folders.*;
import SnowMailClient.view.*;       
import SnowMailClient.Language.Language;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.io.*;

/** save the selected mail (full mime header & content)
*/                      
public class SaveMailAction extends AbstractAction
{
  FolderView folderView;
  FolderTreeNode deletedNode;
  
  public SaveMailAction(final FolderView folderView_)
  {                                          
     super(Language.translate("Save mail As")+"...");
     this.folderView = folderView_;

     //no, already used to store opened mails
     //putValue(AbstractAction.ACCELERATOR_KEY, KeyStroke.getKeyStroke( KeyEvent.VK_S, KeyEvent.CTRL_MASK ) );

     folderView.getTableSelectionModel().addListSelectionListener(  new ListSelectionListener()
     {
        public void valueChanged(ListSelectionEvent e)
        {
           setEnabled(folderView.getTableSelectionCount()==1);
        }
     });
     
     setEnabled(folderView.getTableSelectionCount()==1);

  } // Constructor

  public void actionPerformed(ActionEvent e)
  {
    MailMessage[] messs = folderView.getSelectedMessages();
    if(messs.length==1)
    {
       MailMessage mess = messs[0];
       try
       {
         String cont = mess.getCompleteContentAsString();
         JFileChooser fileChooser = new JFileChooser();
         fileChooser.setDialogTitle("Choose the file to store the mail in");
         int rep = fileChooser.showSaveDialog(folderView);                                                                            
         if(rep==JFileChooser.APPROVE_OPTION)
         {
            File file = fileChooser.getSelectedFile();
            FileOutputStream fos = null;
            try
            {
              fos = new FileOutputStream(file, false);
              fos.write(cont.getBytes());
            }
            catch(Exception ee)
            {
              throw ee;
            }
            finally
            {
              if(fos!=null) fos.close();
            }
         }


       }
       catch(Exception ex)
       {
         ex.printStackTrace();
       }
    }
  }



} // SaveMailAction
