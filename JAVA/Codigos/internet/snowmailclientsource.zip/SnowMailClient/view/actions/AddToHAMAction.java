package SnowMailClient.view.actions;

import SnowMailClient.SnowMailClientApp;
import SnowMailClient.model.folders.*;
import SnowMailClient.model.*;
import SnowMailClient.view.folders.*;
import SnowMailClient.view.*;     
import SnowMailClient.Language.Language;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;  
                

/** delete the selected mail (move in the deleted folder)
*/
public final class AddToHAMAction extends AbstractAction
{
  FolderView folderView;
                                 
  public AddToHAMAction(FolderView _folderView)
  {
     super(Language.translate("Set selected messages as HAM"));
     this.folderView  = _folderView;

/*     putValue(AbstractAction.ACCELERATOR_KEY,
                KeyStroke.getKeyStroke( KeyEvent.VK_D, KeyEvent.CTRL_MASK ) );*/

     //putValue(AbstractAction.SMALL_ICON, SnowMailClientApp.loadImageIcon("pics/addtospam.PNG"));

                        
     folderView.getTableSelectionModel().addListSelectionListener(  new ListSelectionListener()
     {
        public void valueChanged(ListSelectionEvent e)
        {
           setEnabled(folderView.getTableSelectionCount()>0);
        }
     });
     setEnabled(folderView.getTableSelectionCount()>0);

  } // Constructor
  

  /** ActionListener
  */
  public void actionPerformed(ActionEvent e)
  {
     MailMessage[] messs = folderView.getSelectedMessages();
     for(MailMessage mess: messs)
     {
        mess.setHAM(true);

        // ### should update here the stat
  /*      SnowMailClientApp.getInstance().getWordStatistic().addText(
          mess.getMessageBody(), true); */
     }
     //folderView.getMailFolder().notifyMailFolderListener_of_ContentEdited();
  }



} // AddToHAMAction
