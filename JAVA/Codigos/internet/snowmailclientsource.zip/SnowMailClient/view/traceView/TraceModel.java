package SnowMailClient.view.traceView;

import SnowMailClient.utils.MailMessageUtils;
import javax.swing.table.*;
import java.util.*;
import java.text.SimpleDateFormat;

/** structured infos of the trace of a single message parsed from Received fields in the header
*/
public class TraceModel extends AbstractTableModel
{
  static final String[] COLUMN_NAMES = new String[]{ "From", "By", "For", "Date" };

  public final Vector<TraceItem> traceItems = new Vector<TraceItem>();
  SimpleDateFormat dateFormat = new SimpleDateFormat(" dd MM yyyy  hh:mm:ss");

  public TraceModel()
  {

  } // Constructor

  public void addItem(TraceItem ti)
  {
     traceItems.addElement(ti);
  }

  public TraceItem getItemAt(int pos)
  {                      
    return traceItems.elementAt(pos);
  }

  // Table model
  //

  public int getRowCount() { return traceItems.size(); }
  public int getColumnCount() { return COLUMN_NAMES.length; }
  public Object getValueAt(int row, int column)
  {
     TraceItem ti = getItemAt(row);
     if(column==0)
     {
       return ti.getFrom();
     }
     else if(column==1)
     {
       return ti.getBy();
     }
     else if(column==2)
     {
       return ti.getFor();
     }
     else if(column==3)
     {
       try
       {                                                                                          
          Date date = MailMessageUtils.parseDateFromString(ti.getDate());
          return dateFormat.format(date);
       }
       catch(Exception e){}

       return ti.getDate();
     }

     return "?";
  }

  


  public boolean isCellEditable(int rowIndex, int columnIndex)
  {
    return false;
  }

  public Class getColumnClass(int col)
  {
    return Object.class;
  }

  public String getColumnName(int column)
  {
    return this.COLUMN_NAMES[column];
  }



} // TraceModel
