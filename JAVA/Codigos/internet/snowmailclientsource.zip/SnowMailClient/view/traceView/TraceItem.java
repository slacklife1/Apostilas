    
package SnowMailClient.view.traceView;

public class TraceItem
{
  String content;
  String from = "";
  String by = "";
  String For = "";
  String date = "";

  public TraceItem(String content)
  {
     this.content = content;

     String contUP = content.toUpperCase();

     int posFrom = contUP.indexOf("FROM");
     if(posFrom!=-1)
     {
       from = content.substring(posFrom+4);
       int posEnd = from.indexOf("\n");
       if(posEnd!=-1) from = from.substring(0,posEnd);
     }  
           
     int posBy = contUP.indexOf("BY");
     if(posBy!=-1)
     {
       by = content.substring(posBy+2);
       int posEnd = by.indexOf("\n");
       if(posEnd!=-1) by = by.substring(0,posEnd);
     }

     int posFor = contUP.indexOf("FOR");
     if(posFor!=-1)  
     {
       For = content.substring(posFor+3);
       int posEnd = For.indexOf(";");
       if(posEnd!=-1)
       {
         For = For.substring(0,posEnd);
       }
     }
     
     int posDate = content.indexOf(";");
     if(posDate!=-1)
     {           
       date = content.substring(posDate+1).trim();
     }

  } // Constructor

  public String getContent() { return content; }
  public String getFrom()    { return from; }
  public String getBy()      { return by;   }
  public String getFor()     { return For;  }
  public String getDate()    { return date; }

          


} // TraceItem
