package SnowMailClient.view.traceView;

import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;

import SnowMailClient.model.*;
import snow.utils.gui.*;
import SnowMailClient.Language.Language;

/** display the parsed path from EXAMPLE:

Received: (qmail 11802 invoked by uid 65534); 26 Mar 2004 02:30:05 -0000
Received: from britney.music.ch (EHLO britney.music.ch) (213.189.140.132)
  by mx0.gmx.net (mx052) with SMTP; 26 Mar 2004 03:30:05 +0100
Received: from britney.music.ch (localhost [127.0.0.1])
	by britney.music.ch (8.12.7/8.12.7/SuSE Linux 0.6) with ESMTP id i2Q2U3Y7024637
	for <akimo@gmx.ch>; Fri, 26 Mar 2004 03:30:03 +0100
Received: (from music039@localhost)
	by britney.music.ch (8.12.7/8.12.7/Submit) id i2Q2U3LG024636;
	Fri, 26 Mar 2004 03:30:03 +0100  

*/
public class TraceViewDialog extends JDialog
{
  Header header;
  JTable table = new JTable();
  TraceModel traceModel = new TraceModel();
  
  public TraceViewDialog(JFrame ref, Header header)
  {                             
     super(ref, Language.translate("Trace"), true);
     this.header = header;
     this.getContentPane().setLayout(new BorderLayout());
     this.getContentPane().add(new JScrollPane(table), BorderLayout.CENTER);

     Vector<HeaderEntry> hes = header.getAllEntries("Received");
     for(HeaderEntry he: hes)
     {
        traceModel.addItem(new TraceItem(he.getValue()));
     }

     table.setModel(traceModel);

     CloseControlPanel ccp = new CloseControlPanel(this, false, false, Language.translate("Close"));
     this.getContentPane().add(ccp, BorderLayout.SOUTH);

     setSize(1000,300);
     setLocationRelativeTo(null);
     
     setVisible(true);
  } // Constructor





} // TraceViewDialog
