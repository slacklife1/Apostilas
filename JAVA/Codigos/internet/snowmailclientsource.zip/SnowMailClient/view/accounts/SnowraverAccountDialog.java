package SnowMailClient.view.accounts;

import SnowMailClient.SnowMailClientApp;
import SnowMailClient.model.accounts.*;
import SnowMailClient.view.actions.*;
import SnowMailClient.utils.storage.*;
import snow.utils.gui.*;

import SnowMailClient.view.dialogs.*;
import SnowMailClient.Language.Language;
import snow.lookandfeel.*;

import java.util.*;
import java.awt.*;                
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;


/** let access to the snowraver special functions
    (A) = only for admin users
     + change password
     + add new user (A)
     + set user password (A)
     + view server log (A)
*/
public class SnowraverAccountDialog extends JDialog
{
  private static String TITLE = Language.translate("Snowraver Account Functions");
  
  public SnowraverAccountDialog(AccountsEditor accountsEditor, MailAccount account)
  {
     super(accountsEditor, TITLE, true);
     this.getContentPane().setLayout(new BorderLayout());
     
     boolean admin = false;
     try
     {
       admin = account.getCheckedPopConnection().hasAdminPrivileges();
     }
     catch(Exception e) {}


     // south                                
     CloseControlPanel ccp = new CloseControlPanel(this, false, false, Language.translate("Close"));
     this.getContentPane().add(ccp, BorderLayout.SOUTH);
                              
     // center
     JPanel functionsPanel_ = new JPanel(); //new GridLayout((admin?4:1), 2, 5, 5));
     GridLayout3 grid = new GridLayout3(2,functionsPanel_);
     functionsPanel_.setBorder(new EmptyBorder(5,5,5,5));
     this.getContentPane().add(functionsPanel_, BorderLayout.CENTER);
     
     JSenseButton chu = new JSenseButton(new ChangeAccountPassword(account, this));
     chu.setFont(ThemesManager.getInstance().getSmallFont());
     grid.add(chu, true);
     grid.add(new JLabel(Language.translate("Change the password for %",account.getAddress())), false);

     if(admin)
     {
        setTitle(TITLE+Language.translate(" [Admin Mode]"));
        JSenseButton anu = new JSenseButton(new AddNewUser(this, account));
        anu.setFont(ThemesManager.getInstance().getSmallFont());
        grid.add(anu, true);
        grid.add(new JLabel(Language.translate("Add a new user@%",account.getPop())), false);

        JSenseButton sup = new JSenseButton(new SetUserPass(this, account));
        sup.setFont(ThemesManager.getInstance().getSmallFont());
        grid.add(sup, true);
        grid.add(new JLabel(Language.translate("Set a user password")), false);

        JSenseButton vsl = new JSenseButton(new ViewServerLog(this, account));
        vsl.setFont(ThemesManager.getInstance().getSmallFont());
        grid.add(vsl, true);
        grid.add(new JLabel(Language.translate("View the server log from %",account.getPop())), false);
     }
     pack();
     SnowMailClientApp.centerComponentOnMainFrame(this);
     setVisible(true);
  } // Constructor




                                                              
} // SnowraverAccountDialog
