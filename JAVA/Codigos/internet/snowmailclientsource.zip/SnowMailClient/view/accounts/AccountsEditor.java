package SnowMailClient.view.accounts;

import snow.utils.storage.*;
import snow.crypto.*;
import snow.lookandfeel.*;
import snow.utils.gui.*;

import SnowMailClient.SnowMailClientApp;
import SnowMailClient.model.accounts.*;
import SnowMailClient.model.Address;
import SnowMailClient.view.actions.*;
import SnowMailClient.view.dialogs.*;
import SnowMailClient.crypto.*;
import SnowMailClient.Language.Language;
                       
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;             
import java.io.*;               
import java.awt.event.*;
                                      
                              
                                                                     
public final class AccountsEditor extends JDialog implements ListSelectionListener
{                                        

   final int fontSize = UIManager.getFont("Label.font").getSize();

   private final JTable table;
   private final JPanel accountPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, fontSize, fontSize));

   private final MailAccounts accounts;
   private final AppProperties properties;

                                                   
                                  
   public AccountsEditor(Frame modalOwner, MailAccounts _accounts, AppProperties _properties)
   {
      super(modalOwner, Language.translate("Accounts Editor"), true);

      this.accounts = _accounts;
      this.properties = _properties;

      if(accounts.getRowCount()==0)
      {
        accounts.addNewAccount();
        accounts.getAccount(0).setAddress("??????@www.snowraver.org");
      }

      setContentPane(new SnowBackgroundPanel(new BorderLayout()));

      table = new JTable(accounts);
      table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
      table.getColumnModel().getColumn(1).setCellEditor(new DefaultCellEditor(new JCheckBox()));
      table.getColumnModel().getColumn(1).setMaxWidth(50);
      table.getColumnModel().getColumn(2).setCellEditor(new DefaultCellEditor(new JCheckBox()));
      table.getColumnModel().getColumn(2).setMaxWidth(37);

      final JPanel leftPanel = new JPanel(new BorderLayout());
      leftPanel.setOpaque(false);

      JScrollPane jsp = new JScrollPane(table);
      leftPanel.add(jsp, BorderLayout.CENTER);
      table.setOpaque(false);
      jsp.setOpaque(false);
      jsp.getViewport().setOpaque(false);


      JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
          leftPanel,     
          accountPanel );
      splitPane.setOpaque(false); 
      accountPanel.setOpaque(false);

      splitPane.setOneTouchExpandable(true);
      splitPane.setDividerLocation(ThemesManager.getLabelFontSize()*32);

      getContentPane().add(splitPane, BorderLayout.CENTER);
                                         


      final JPanel contrlpanel1 = new JPanel(new FlowLayout(FlowLayout.LEFT));

      final JPanel contrlpanel2 = new JPanel(new FlowLayout(FlowLayout.LEFT));

      leftPanel.add(contrlpanel2, BorderLayout.SOUTH);

      leftPanel.add(contrlpanel1, BorderLayout.NORTH);

      JButton addUser = new JSenseButton(Language.translate("New Account"), SnowMailClientApp.loadImageIcon("pics/mailAccounts.PNG"));
      GUIUtils.setSmallDimensions(addUser);
                                                    
      addUser.setOpaque(true);
      addUser.setBackground(Color.yellow);
      contrlpanel1.add(addUser);
      addUser.addActionListener(new ActionListener(  ){
         public void actionPerformed(ActionEvent e)
         {
            //accounts.addNewAccount();

            AddAccountWizzardDialog adw = new AddAccountWizzardDialog(AccountsEditor.this);
            if(!adw.wasDialogCancelled())
            {
              MailAccount ma = new MailAccount();
              Address address = adw.getMailAddress();
              ma.setAddress(address.getMailAddress());
              ma.setName(address.getName());
              ma.setAccountPassword(adw.getPassword());

              String mailAddress = address.getMailAddress();
              int posAt = mailAddress.indexOf("@");
              if(posAt>=0)
              {
                 ma.setAccountUserName( mailAddress.substring(0,posAt));
                 ma.setPop( mailAddress.substring(posAt+1));
                 ma.setSMTP( mailAddress.substring(posAt+1));

              }      
                  
              accounts.addAccount(ma);
            }
         }     
      });
      final JButton removeuser = new JSenseButton(Language.translate("Remove"),
         SnowMailClientApp.loadImageIcon("pics/delete.PNG"));
      GUIUtils.setSmallDimensions(removeuser);
      removeuser.setOpaque(true);
      contrlpanel1.add(removeuser);
      removeuser.addActionListener(new ActionListener()
      {
         public void actionPerformed(ActionEvent e)
         {
            int sel = table.getSelectedRow();
            if(sel!=-1)
            {           
              MailAccount ma = accounts.getAccount(sel); 
              
              int rep = JOptionPane.showConfirmDialog(leftPanel,
                Language.translate("Are you sure ?"),
                Language.translate("Removing %",ma.getAddress()),
                JOptionPane.OK_CANCEL_OPTION);

              if(rep==JOptionPane.OK_OPTION)   
              {
                accounts.remove(ma);
                valueChanged(null);
              }
            }
         }                     
      });  
/*                                      
      final JButton importBT = new JSenseButton(
         Language.translate("Import from OutlookExpress"), SnowMailClientApp.loadImageIcon("pics/outlookexpress.png"));
      SnowMailClientApp.MakeButtonNiceSize(importBT);
      importBT.setOpaque(true);
      importBT.setToolTipText(
        Language.translate("Import from an IAF file (outlook express account export)."));
      contrlpanel2.add(importBT);
      importBT.addActionListener(new ActionListener(  )
      {
         public void actionPerformed(ActionEvent e)
         {                                
             importIAFAction();
         }
      }); */  

      final JButton moveUp = new JSenseButton("", SnowMailClientApp.loadImageIcon("pics/up.PNG"));
      GUIUtils.setNarrowInsets(moveUp);
      moveUp.setToolTipText(Language.translate("Move account up in the list"));
      moveUp.setOpaque(true);
      contrlpanel2.add(Box.createHorizontalGlue());
      contrlpanel2.add(moveUp);
      moveUp.addActionListener(new ActionListener(  )
      {
         public void actionPerformed(ActionEvent e)
         {
            int sel = table.getSelectedRow();                                            
            if(sel>0)
            {
              saveSelectedMailAccount();
              MailAccount ma = accounts.getAccount(sel);
              accounts.remove(ma);
              accounts.insertAccountAt(ma, sel-1);
              table.setRowSelectionInterval(sel-1, sel-1);
            }                                                                     
         }
      });  
      final JButton moveDown = new JSenseButton("", SnowMailClientApp.loadImageIcon("pics/down.PNG"));
      GUIUtils.setNarrowInsets(moveDown);
      moveDown.setToolTipText(Language.translate("Move account down in the list"));
      moveDown.setOpaque(true);
      contrlpanel2.add(moveDown);                                               
      moveDown.addActionListener(new ActionListener(  )
      {
         public void actionPerformed(ActionEvent e)
         {
            int sel = table.getSelectedRow();
            if(sel<table.getRowCount()-1)
            {
              saveSelectedMailAccount();
              MailAccount ma = accounts.getAccount(sel);
              accounts.remove(ma);
              accounts.insertAccountAt(ma, sel+1);
              table.setRowSelectionInterval(sel+1, sel+1);
            }
         }
      });

      table.getSelectionModel().addListSelectionListener(new ListSelectionListener()
      {
        public void valueChanged(ListSelectionEvent e)
        {       
          removeuser.setEnabled(table.getSelectedRowCount()==1);  
          moveUp.setEnabled(table.getSelectedRowCount()==1);
          moveDown.setEnabled(table.getSelectedRowCount()==1);
        }
      });

      JPanel southPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
      southPanel.setOpaque(false);
      getContentPane().add(southPanel, BorderLayout.SOUTH);

      JButton close = new JSenseButton(Language.translate("Save and Close"),
        SnowMailClientApp.loadImageIcon("pics/ok.PNG"));
      GUIUtils.setSmallDimensions(close);
      close.setBackground(Color.orange);
      southPanel.add(close);   
      close.addActionListener(new ActionListener(  ){
         public void actionPerformed(ActionEvent e)
         {
            saveSelectedMailAccount();
            properties.saveComponentSizeInINIFile(AccountsEditor.this, "AccountsEditor");
            dispose();
         }
      });

      table.getSelectionModel().addListSelectionListener(this);
      int sel = properties.getInteger("AccountsEditor_table_sel_row", 0);
      if(sel>=0 && sel<table.getModel().getRowCount())
      {
         table.setRowSelectionInterval(sel, sel);
      }                                   

      pack();

      properties.setComponentSizeFromINIFile(AccountsEditor.this, "AccountsEditor", 
                        750, 480, 100, 100);
      setVisible(true);      
   }


   public void saveSelectedMailAccount()
   {
      if(accountPanel.getComponentCount()>0)
      {
         // save old
         AccountEditor ma = (AccountEditor) accountPanel.getComponent(0);
         ma.save();
      }
   }   
   /*
   private void importIAFAction()
   {                     
      JFileChooser fs = new JFileChooser();
      String startDir = properties.getProperty( "iaf_last", System.getProperty("user.home", "c:/"));
      fs.setCurrentDirectory(new File(startDir));
      fs.setDialogTitle(Language.translate("Select an IAF file to open"));
      fs.setFileFilter(new javax.swing.filechooser.FileFilter()
      {
         public boolean accept(File file)
         {
           if(file.isDirectory()) return true;
           String name = file.getName().toUpperCase();
           return name.endsWith(".IAF");
         }
         public String getDescription() { return Language.translate("Outlook mail account IAF file")+" [*.iaf]"; }
      });
      int rep = fs.showOpenDialog(this);
      if(rep==fs.APPROVE_OPTION)
      {
         File file = fs.getSelectedFile();
         File par = file.getParentFile();
         if(par!=null && par.exists())
         {
           properties.setProperty( "iaf_last", par.getAbsolutePath());
         }

         try
         {
           IAFReader iar = new IAFReader(file);
           MailAccount ma = new MailAccount();
           accounts.addAccount(ma);

           ma.setAccountUserName(iar.getUserName());
           ma.setAddress(iar.getMailAddress());
           ma.setPop( iar.getPOPHost());
           ma.setPopPort(iar.getPOPPort() );
           ma.setUseSSLPOP(iar.getUseSSLonPOP());
           ma.setSSLPOPPort(iar.getPOPPort() );

           ma.setSMTP( iar.getSMTPHost());
           ma.setSMTPPort(iar.getSMTPPort() );
           ma.setUseSSLSMTP(iar.getUseSSLonSMTP());
           ma.setSSLSMTPPort(iar.getSMTPPort() );

           char[] pass = iar.getPassword();
           if(pass!=null) ma.setAccountPassword(new String(pass));
         }
         catch(Exception e)
         {
           e.printStackTrace();
         }
      }
   } */


   /** list selection listener
   */
   public void valueChanged(ListSelectionEvent e)
   {              
      int ind = table.getSelectedRow();
      if(ind>=0)
      {
         saveSelectedMailAccount();
         accountPanel.removeAll();
         MailAccount ma = accounts.getAccount(ind);
         accountPanel.add(new AccountEditor(ma), 0);
         accountPanel.updateUI();    
      }       
      properties.setInteger("AccountsEditor_table_sel_row", ind);
   }

   /** test
   */
   public static void main(String[] aaa)
   {
      MailAccounts mailAccounts = new MailAccounts();
      new AccountsEditor(new JFrame(), mailAccounts, new AppProperties());
   }

   /** editor for ONE mail account.
   */
   final private class AccountEditor extends JPanel
   {
      final JTextField mailAddress, identity, userName,
                 pop, sslPopport, smtp, popport, smtpport, sslSMTPPort; //, name;
      final JPasswordField password;
      final JCheckBox sslPOPCB = new JCheckBox(Language.translate("Use SSL")+" (995)", false);
      final JCheckBox sslSMTPCB = new JCheckBox(Language.translate("Use SSL")+" (25)", false);
      final JSenseButton viewPass = new JSenseButton(Language.translate("View"));
      //JCheckBox signOutgoingMails = new JCheckBox(Language.translate("Sign outgoing mails with GnuPG")+"", false);
      final JCheckBox allowUnsecurePasswordProtocols = new JCheckBox(Language.translate("Allow unsecure password protocols")+"", false);

      public boolean dataHasChanged = false;
      final private MailAccount account;

      public AccountEditor(final MailAccount account)
      {
         super(new BorderLayout());
         setOpaque(false);

         JPanel cont_ = new JPanel();
         GridLayout3 gl = new GridLayout3(2, cont_);

         cont_.setOpaque(false);
         add(cont_, BorderLayout.CENTER);
         this.account = account;

         mailAddress = new JTextField(account.getAddress(),20);
         mailAddress.setOpaque(false);
         identity    = new JTextField(account.getName(),20);
         identity.setOpaque(false);
         pop         = new JTextField(account.getPop(), 20);
         pop.setOpaque(false);
         sslPopport  = new JTextField(""+account.getSSLPopPort(), 4);
         sslPopport.setOpaque(false);
         sslSMTPPort = new JTextField(""+account.getSSLSMTPPort(), 4);
         sslSMTPPort.setOpaque(false);
         smtp        = new JTextField(account.getSMTP(),20);
         smtp.setOpaque(false);
         userName    = new JTextField(account.getAccountUserName(),20);
         userName.setOpaque(false);
         password    = new JPasswordField(account.getAccountPassword(),20);
         password.setOpaque(false);
         popport     = new JTextField(""+account.getPopPort(),4);
         popport.setOpaque(false);
         smtpport    = new JTextField(""+account.getSMTPPort(),4);
         smtpport.setOpaque(false);
         sslPOPCB.setSelected( account.useSSLPOP());
         sslSMTPCB.setSelected( account.useSSLSMTP());
         sslPOPCB.setFocusPainted(false);
         sslSMTPCB.setFocusPainted(false);


         //signOutgoingMails.setSelected( account.doSignOutgoingMails());
//         signOutgoingMails.setFocusPainted(false);
//         signOutgoingMails.setOpaque(false);


         gl.add(new JLabel(Language.translate("E-Mail Address")), false);
         gl.add(mailAddress, true);

         gl.add(new JLabel(Language.translate("Username")), false);
         gl.add(userName, true);

         gl.add(new JLabel(Language.translate("Password")), false);
         JPanel panPass =new JPanel(new FlowLayout(FlowLayout.LEFT,0,0));
         panPass.add(password);  
         if(SecretKeyManager.getInstance().isUserKeySet())
         {
           panPass.add(viewPass);
         }
         viewPass.setPreferredSize(new Dimension(
             (int) viewPass.getPreferredSize().getWidth(), (int) password.getPreferredSize().getHeight()));
         viewPass.addActionListener(new ActionListener()
         {
           public void actionPerformed(ActionEvent ee)
           {
              SecretKeyID skid = SecretKeyUtilities.computeSignature(
                SecretKeyManager.getInstance().getUserKeyForEncryption());
              PassphraseDialog pd = new PassphraseDialog(AccountsEditor.this,
                 Language.translate("Enter the SnowMail password"), true, skid, Language.translate("Security Check"));

              if(pd.matchesID())
              {
                JOptionPane.showMessageDialog(
                  password, new String(password.getPassword()),
                  Language.translate("Password for")+" "+mailAddress.getText(),
                  JOptionPane.INFORMATION_MESSAGE
                );
              }
           }
         });

         gl.add(panPass, true);

         gl.add(new JLabel(""), false);
         gl.add(new JLabel(""), false);

         gl.add(new JLabel(Language.translate("User Identity (optional)")), false);
         gl.add(identity, true);
         gl.add(new JLabel(Language.translate("POP3 Host address")), false);
         gl.add(pop, true);
         gl.add(new JLabel(Language.translate("POP3 Port (110)")), false);
         gl.add(wrapLeft(popport), true);
         gl.add(sslPOPCB, false);

         sslPOPCB.setOpaque(false);
         gl.add(sslPopport, false);

         gl.add(new JLabel(Language.translate("SMTP Host address")), false);
         gl.add(smtp, true);
         gl.add(new JLabel(Language.translate("SMTP Port (25)")), false);
         gl.add(smtpport, false);
         gl.add(sslSMTPCB, false);
         sslSMTPCB.setOpaque(false);
         gl.add(sslSMTPPort, false);

         //gl.add(signOutgoingMails, false);

         gl.add("");
         gl.add(allowUnsecurePasswordProtocols);
         allowUnsecurePasswordProtocols.setSelected(account.getAllowUnsecurePasswordProtocols());
                
         allowUnsecurePasswordProtocols.addActionListener(new ActionListener()
         {
           public void actionPerformed(ActionEvent ee)
           {
             if(allowUnsecurePasswordProtocols.isSelected())
             {
               allowUnsecurePasswordProtocols.setForeground(ThemesManager.getInstance().getRed());
             }
             else
             {
               allowUnsecurePasswordProtocols.setForeground(UIManager.getColor("Label.foreground"));
             }
           }
         });
         if(allowUnsecurePasswordProtocols.isSelected())
         {
           allowUnsecurePasswordProtocols.setForeground(ThemesManager.getInstance().getRed());
         }


                

         sslPOPCB.addActionListener(new ActionListener()
         {
           public void actionPerformed(ActionEvent ee)
           {
              sslPopport.setEnabled(sslPOPCB.isSelected());
              popport.setEnabled(!sslPOPCB.isSelected());
           }
         });
         sslPopport.setEnabled(sslPOPCB.isSelected());
         popport.setEnabled(!sslPOPCB.isSelected());

         sslSMTPCB.addActionListener(new ActionListener()
         {
           public void actionPerformed(ActionEvent ee)
           {
              sslSMTPPort.setEnabled(sslSMTPCB.isSelected());
              smtpport.setEnabled(!sslSMTPCB.isSelected());
           }
         });
         sslSMTPPort.setEnabled(sslSMTPCB.isSelected());
         smtpport.setEnabled(!sslSMTPCB.isSelected());
           
         //  south panel
         //
         JPanel southPanel = new JPanel();
         southPanel.setOpaque(false);
         add(southPanel, BorderLayout.SOUTH);
         southPanel.setLayout(new BoxLayout(southPanel, BoxLayout.Y_AXIS));
         southPanel.add(Box.createVerticalStrut(fontSize*1));
         
         // general options
         //              
         JPanel genOptionsPanel_ = new JPanel();
         GridLayout3 glo = new GridLayout3(1, genOptionsPanel_);
         genOptionsPanel_.setOpaque(false);
         southPanel.add(wrapLeft(genOptionsPanel_));
                                                   
         JSenseButton testAccountBT = new JSenseButton(new TestAccountSettings(AccountsEditor.this, account));
         testAccountBT.setFont(ThemesManager.getInstance().getSmallFont());
         GUIUtils.setSmallDimensions(testAccountBT);
         glo.add(testAccountBT);

         JSenseButton logtBT = new JSenseButton(new ViewAccountLog(AccountsEditor.this, account));
         logtBT.setFont(ThemesManager.getInstance().getSmallFont());
         GUIUtils.setSmallDimensions(logtBT);
         glo.add(logtBT);

         JSenseButton previewBT = new JSenseButton(new MessagesPreviewAction(AccountsEditor.this, account));
         previewBT.setFont(ThemesManager.getInstance().getSmallFont());
         GUIUtils.setSmallDimensions(previewBT);
         glo.add(previewBT);


         // snowmail
         //

         if(account.isSnowraverAccount())
         {                        
            JSenseButton accessSnowraverFunctions = new JSenseButton(
                Language.translate("Snowraver special functions"),
                SnowMailClientApp.loadImageIcon("pics/snowraverlogo.PNG"));
            accessSnowraverFunctions.setFont(ThemesManager.getInstance().getSmallFont());
            glo.add(wrapLeft(accessSnowraverFunctions));
            GUIUtils.setSmallDimensions(accessSnowraverFunctions);
            accessSnowraverFunctions.addActionListener(new ActionListener()
            {                                                          
              public void actionPerformed(ActionEvent ee)
              {
                 new SnowraverAccountDialog(AccountsEditor.this, account);
              }   
            });            
         }
           
         mailAddress.addKeyListener(new KeyAdapter()
         {
            @Override public void keyReleased(KeyEvent e)
            {
               // set the name in the list of the accounts
               account.setAddress( mailAddress.getText());
               accounts.updateList();
            }         
         });
      }         

      

      public void save()
      {                        
         account.setAddress( mailAddress.getText());
         account.setName( identity.getText());                                                    
         account.setPop( pop.getText());
         account.setSMTP( smtp.getText());
         account.setAccountUserName( userName.getText());
         account.setAccountPassword( new String(password.getPassword()));
         try
         {
            int pp = Integer.parseInt( popport.getText() );
            account.setPopPort(pp);
         }
         catch(NumberFormatException e){e.printStackTrace(); }
         try
         {
            int pp = Integer.parseInt( smtpport.getText() );
            account.setSMTPPort(pp);
         }
         catch(NumberFormatException e){e.printStackTrace(); }
         try
         {
            int pp = Integer.parseInt( sslPopport.getText() );
            account.setSSLPOPPort(pp);
         }
         catch(NumberFormatException e){e.printStackTrace(); }
         try
         {
            int pp = Integer.parseInt( sslSMTPPort.getText() );
            account.setSSLSMTPPort(pp);
         }
         catch(NumberFormatException e){ e.printStackTrace(); }
         
         account.setUseSSLPOP(sslPOPCB.isSelected());
         account.setUseSSLSMTP(sslSMTPCB.isSelected());
         //account.setSignOutgoingMails(signOutgoingMails.isSelected());
         
         account.setAllowUnsecurePasswordProtocols(allowUnsecurePasswordProtocols.isSelected());
                                  
      }
   }
                                                                     
   public final static JPanel wrapLeft(JComponent c)
   {
      JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT,0,0));
      c.setOpaque(false);
      p.setOpaque(false);
      p.add(c);
      return p;
   }

}
