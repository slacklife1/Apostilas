package SnowMailClient.view.accounts;

import SnowMailClient.SnowMailClientApp;
import SnowMailClient.model.accounts.*;
import SnowMailClient.model.Address;
import SnowMailClient.view.actions.*;
import SnowMailClient.utils.storage.*;
import snow.utils.gui.*;
import SnowMailClient.view.dialogs.*;     
import SnowMailClient.Language.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class AddAccountWizzardDialog extends JDialog
{
  JTextField mailAddressTF = new JTextField("", 22);
  JPasswordField passwordTF = new JPasswordField(22);
  CloseControlPanel ccp;

  public AddAccountWizzardDialog(JDialog parent)
  {
     super(parent, "Add a mail account", true);
                                          


     getContentPane().setLayout(new BorderLayout());

     ccp = new CloseControlPanel(this, true, true, Language.translate("Add the new account"));
     getContentPane().add(ccp, BorderLayout.SOUTH);

     JPanel inputPanel = new JPanel(new GridLayout(2,2,3,3));
     getContentPane().add(inputPanel, BorderLayout.CENTER);
     inputPanel.setBorder(new EmptyBorder(5,5,5,5));

     inputPanel.add(new JLabel(Language.translate("Mail address")+": "));
     inputPanel.add(mailAddressTF);

     inputPanel.add(new JLabel(Language.translate("Password")+": "));
     inputPanel.add(passwordTF);

     this.pack();
     this.setLocationRelativeTo(this.getOwner());

     // modal
     this.setVisible(true);
                                             
  } // Constructor



  public Address getMailAddress()      { return new Address(mailAddressTF.getText()); }
  public boolean wasDialogCancelled() { return ccp.getWasCancelled();  }
  public String getPassword() { return new String(passwordTF.getPassword()); }

} // AddAccountWizzardDialog
