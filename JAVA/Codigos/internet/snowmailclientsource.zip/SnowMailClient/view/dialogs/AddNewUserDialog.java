package SnowMailClient.view.dialogs;

import SnowMailClient.model.accounts.*;
import SnowMailClient.crypto.Utilities;
import snow.Language.Language;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;


public class AddNewUserDialog extends JDialog {
    
    public boolean addNewUserOnExit = false;     

    private final JTextField name = new JTextField();
    private final JTextField pass = new JTextField("password");
    private final JTextField confirmPass = new JTextField();

    public AddNewUserDialog(JDialog owner, String servername)
    {
       super(owner, "Create a new user on "+servername, true);
                       
       getContentPane().setLayout(new BorderLayout());

       JPanel cpanel = new JPanel(new GridLayout(3,2));
       getContentPane().add(cpanel, BorderLayout.CENTER);
       cpanel.setBorder(new EmptyBorder(5,5,5,5));

       cpanel.add(new JLabel("User name "));
       cpanel.add(name);
       cpanel.add(new JLabel("Password (press ENTER to hash) "));
       cpanel.add(pass);
       cpanel.add(new JLabel("Confirm (press ENTER to hash)"));
       cpanel.add(confirmPass);

       JPanel contrlpanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
       getContentPane().add(contrlpanel, BorderLayout.SOUTH);

       JButton cancel = new JButton(Language.translate("Cancel"));
       contrlpanel.add(cancel);
       cancel.addActionListener(new ActionListener(  ){
       public void actionPerformed(ActionEvent e)
        {
           dispose();
        }
       });
       JButton changePass = new JButton(Language.translate("Add it"));
       changePass.setBackground(Color.orange);
       contrlpanel.add(changePass);
       final JDialog ref = this;
       changePass.addActionListener(new ActionListener(  ){
       public void actionPerformed(ActionEvent e)
        {
           // test
           if(!pass.getText().equals( confirmPass.getText()))
           {
               JOptionPane.showMessageDialog(ref, "ERROR : Bad password confirmation");
           }
           else if(name.getText().trim().length()<1)
           {
               JOptionPane.showMessageDialog(ref, "ERROR : Bad username, should have at least one character !");
           }
           else
           {
             addNewUserOnExit = true;
             dispose();
           }
        }
       });
       pass.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e)
          {
              String passw = pass.getText();
              if(!Utilities.isValidHashPasswordFormat(passw))
              {
                  pass.setText( Utilities.hashPassword(passw) );
              }
          }
       });
       confirmPass.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e)
          {
              String pass = confirmPass.getText();
              if(!Utilities.isValidHashPasswordFormat(pass))
              {
                  confirmPass.setText( Utilities.hashPassword(pass) );
              }
          }
       });
    }
    
    public final String getUserName()
    {
      return name.getText();
    }

    public final String getPassword()
    {
      return confirmPass.getText();
    }
    
}
