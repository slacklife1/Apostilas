package SnowMailClient.view.dialogs;

import SnowMailClient.MailEngine.*;
import SnowMailClient.model.*;
import SnowMailClient.model.accounts.*;
import SnowMailClient.crypto.Utilities;
import SnowMailClient.*;
import SnowMailClient.Language.Language;
import snow.utils.gui.*;


import java.awt.*;
import java.util.Arrays;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class ChangePasswordDialog extends JDialog {

    private final JPasswordField pass = new JPasswordField();
    private final JPasswordField newPass = new JPasswordField();
    private final JPasswordField confirmNewPass = new JPasswordField();
    // if the server only know the hash, we cannot log using APOP...
    public boolean doHash = false;
    private final MailAccount ma;   
                               
    public final int fontSize = UIManager.getFont("Label.font").getSize();


    public ChangePasswordDialog(MailAccount _ma, JDialog owner)
    {
       super(owner, true);
       this.ma = _ma;
       setTitle(Language.translate("Change Account Password for %",ma.getAddress()));

       getContentPane().setLayout(new BorderLayout());

       JPanel cpanel = new JPanel();
       GridLayout3 gl = new GridLayout3(2, cpanel);


       cpanel.setBorder(new EmptyBorder(fontSize/2,fontSize/2,fontSize/2,fontSize/2));
       getContentPane().add(cpanel, BorderLayout.CENTER);
       gl.add(new JLabel(Language.translate("New password")), false);
       gl.add(newPass, true);
       gl.add(new JLabel(Language.translate("Confirm")), false);
       gl.add(confirmNewPass, true);

       JPanel contrlpanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
       getContentPane().add(contrlpanel, BorderLayout.SOUTH);

       JButton cancel = new JButton(Language.translate("Cancel"));
       contrlpanel.add(cancel);
       cancel.addActionListener(new ActionListener(  ){
         public void actionPerformed(ActionEvent e)
         {
           dispose();
         }
       });

       JButton changePass = new JButton(Language.translate("Change Password"));
       changePass.setBackground(Color.orange);
       contrlpanel.add(changePass);
       final JDialog ref = this;
       changePass.addActionListener(new ActionListener(  ){
       public void actionPerformed(ActionEvent e)
        {
           // test
           if(!Arrays.equals(newPass.getPassword(), confirmNewPass.getPassword()))
           {
              // Bad
              JOptionPane.showMessageDialog(ref, Language.translate("ERROR : Bad confirmation"));
           }
           else
           {
              try
              {
                 SecurePopConnection sp = ma.getCheckedPopConnection();
                 sp.changePassword( getPassword() );
                 SnowMailClientApp.getInstance().getGlobalConsole().appendComment(Language.translate("Password changed"));
                 dispose();
              }
              catch(Exception ex)
              {
                 // ### shit, the message is not nice  
                 ex.printStackTrace();
                 JOptionPane.showMessageDialog(
                   ref, Language.translate("Secure POP connection error")
                          + ": \n"+ex.getMessage());
                 //SnowMailClient.getInstance().statusBar.displayStatus("Change password failed, double-click on the status to see details");
              }
           }
        }
       });
    }

    public final String getPassword()
    {            
      String p = new String(confirmNewPass.getPassword());
      if(doHash)
         return Utilities.hashPassword(p);
      else
         return p;
    }
               
}
