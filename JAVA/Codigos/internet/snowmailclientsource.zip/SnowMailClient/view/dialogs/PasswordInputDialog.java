package SnowMailClient.view.dialogs;

import SnowMailClient.crypto.Utilities;
import SnowMailClient.utils.*;
import snow.utils.gui.*;
import SnowMailClient.*;
import SnowMailClient.Language.Language;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Arrays;


/** a modal that ask for a password.
 *  when released, getPassword gives you a sha-1 of the password or null if no pass given.
 *  the signature sign of the password must accord...
 */
public class PasswordInputDialog extends JDialog
{
   private final JPasswordField pass1 = new JPasswordField(20);
   private boolean testPassed = false;
   Frame modalOwner;
   byte[] sign;


   public PasswordInputDialog(final Frame modalOwner,
                              String title,
                              String description,
                              final byte[] sign)
   {
      super(modalOwner, title, true);

      this.modalOwner = modalOwner;
      this.sign = (sign!=null? (byte[]) sign.clone(): null);


      
      JTextArea descrTA = new JTextArea(description);
      descrTA.setBorder(BorderFactory.createEmptyBorder(3,3,3,3));
      descrTA.setEditable(false);
      
      getContentPane().setLayout( new BorderLayout());

      JPanel centerPanel = new JPanel(new BorderLayout());
      JPanel passPanel = new JPanel(new GridLayout(1, 2));
      centerPanel.add(passPanel,BorderLayout.CENTER);
      getContentPane().add(centerPanel, BorderLayout.CENTER);
      getContentPane().add(descrTA, BorderLayout.NORTH);

      JPanel contrlpanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
      
      getContentPane().add(contrlpanel, BorderLayout.SOUTH);

      ActionListener disposeActionListener = new ActionListener()
      {
       public void actionPerformed(ActionEvent e)
        {
           dispose();
        }
      };
      ActionListener okActionListener = new ActionListener()
      {
       public void actionPerformed(ActionEvent e)
        {
          okAction();        }
      };                     


      JButton cancel = new JButton(Language.translate("Cancel"));
      cancel.setIcon(SnowMailClientApp.loadImageIcon("pics/cancel.PNG"));
      contrlpanel.add(cancel);
      cancel.addActionListener(disposeActionListener);

      JButton close = new JButton(Language.translate(" Ok "));
      close.setIcon(SnowMailClientApp.loadImageIcon("pics/ok.PNG"));
      contrlpanel.add(close);
//      final JDialog ref = this;
      close.addActionListener(okActionListener);

      passPanel.add(new JLabel("Password "));
      passPanel.add(pass1);

      pass1.addActionListener(okActionListener);



      this.getRootPane().registerKeyboardAction( disposeActionListener,
                                               KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false),
                                               JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT );

      this.getRootPane().registerKeyboardAction( okActionListener,
                                               KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0, false),
                                               JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT );


               
      // modality

      pack();     
      SnowMailClientApp.centerComponentOnMainFrame(this);
      pass1.requestFocus();
      show();
   }


   private void okAction()
   {

           // the hash is the password
           String hash = Utilities.hashPassword(new String(pass1.getPassword()));

           // the signatures are the first 4 bytes of the hash of the password,
           // also h(h(****))
           if(sign!=null && !Arrays.equals(sign, Utilities.hashPassword(hash).substring(0,4).getBytes() ))
           {
               JOptionPane.showMessageDialog( modalOwner, "Bad Password" );
               pass1.setSelectionStart(0);
               pass1.setSelectionEnd(pass1.getPassword().length);
               pass1.requestFocus();

           }
           else
           {
               // OK, but we are not 100% sure, only the four first bytes of the hash
               // match... each 256^4 random pass can pass through,
               // of course, it will result an exception later, the data cannot be deciphered...
              testPassed = true;
              dispose();
           }
   }


   public char[] getPassword() {return pass1.getPassword();}
   public boolean getPasswordOK() {return testPassed;}


}
