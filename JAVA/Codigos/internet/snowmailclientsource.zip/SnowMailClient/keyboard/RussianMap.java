package SnowMailClient.keyboard;

import java.util.*;

public final class RussianMap extends KeyboardMap
{

  public RussianMap()
  {
    super("Russian keys", 8);

    this.keys.add(new KeyboardKey( "CYRILLIC LETTER A",  0x0410, 0x0430, "A" ));
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER BE", 0x0411, 0x0431, "B" ));
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER VE", 0x0412, 0x0432, "V" ));

    this.keys.add(new KeyboardKey( "CYRILLIC LETTER GHE", 0x0413, 0x0433, "G" ));
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER DE",  0x0414, 0x0434, "D" ));
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER IE",  0x0415, 0x0435, "IE" ));

    this.keys.add(new KeyboardKey( "CYRILLIC LETTER IO",  0x0401, 0x0451, "IO" ));
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER ZHE", 0x0416, 0x0436, "J" ));
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER ZE",  0x0417, 0x0437, "Z" ));

    this.keys.add(new KeyboardKey( "CYRILLIC LETTER I",       0x0418, 0x0438, "I" )); 
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER SHORT I", 0x0419, 0x0439, "IS" ));
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER KA",      0x041A, 0x043A, "K" ));

    this.keys.add(new KeyboardKey( "CYRILLIC LETTER EL",  0x041B, 0x043B, "L" ));
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER EM",  0x041C, 0x043C, "M" ));
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER EN",  0x041D, 0x043D, "N" ));

    this.keys.add(new KeyboardKey( "CYRILLIC LETTER O",   0x041E, 0x043E, "O" ));
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER PE",  0x041F, 0x043F, "P" ));
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER ER",  0x0420, 0x0440, "R" )); 

    this.keys.add(new KeyboardKey( "CYRILLIC LETTER ES",  0x0421, 0x0441, "C" ));
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER TE",  0x0422, 0x0442, "T" ));
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER U",   0x0423, 0x0443, "U" ));

    this.keys.add(new KeyboardKey( "CYRILLIC LETTER EF",  0x0424, 0x0444, "F" ));
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER HA",  0x0425, 0x0445, "X" ));
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER TSE", 0x0426, 0x0446, "TS" ));

    this.keys.add(new KeyboardKey( "CYRILLIC LETTER CHE",  0x0427, 0x0447, "CH" ));
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER SHA",  0x0428, 0x0448, "SH" ));
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER SSH",  0x0429, 0x0449, "SSH" ));

    this.keys.add(new KeyboardKey( "CYRILLIC LETTER HARD SIGN",  0x042A, 0x044A ));
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER YERU",       0x042B, 0x044B ));
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER SOFT SIGH",  0x042C, 0x044C ));

    this.keys.add(new KeyboardKey( "CYRILLIC LETTER E",   0x042D, 0x044D, "E-" ));
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER YU",  0x042E, 0x044E, "OU" ));
    this.keys.add(new KeyboardKey( "CYRILLIC LETTER YA",  0x042F, 0x044F, "IA" ));

    //this.keys.add(new KeyboardKey( "SPACE",  0x0020, " " ));
    this.keys.add(new KeyboardKey( "COMBINING ACCUTE ACCENT",  0x0301, "'" ));
    
  } // Constructor


  public String getCharset() { return "iso-8859-1"; }

} // RussianMap
