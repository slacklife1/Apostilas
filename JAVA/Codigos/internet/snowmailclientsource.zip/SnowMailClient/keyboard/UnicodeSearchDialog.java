package SnowMailClient.keyboard;

import snow.SortableTable.*;
import snow.utils.gui.*;
import snow.Language.Language;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.nio.charset.*;
import java.nio.*;
import java.util.*;
import java.io.*;

/** dialog to search a key in the unicode chars
*/
public class UnicodeSearchDialog extends JDialog
{
  int charDisplayLimit = 8192;
  final private UnicodeTableModel basicTableModel = new UnicodeTableModel();
  final private SortableTableModel stm = new SortableTableModel(basicTableModel, 1, true);
  final private JTable table = new JTable(stm);
  final private CloseControlPanel closeControlPanel;


  public UnicodeSearchDialog(JDialog owner, int[] selCodes)
  {
     super(owner, "Unicode search", true);

     // south                                  
     closeControlPanel = new CloseControlPanel(this, true, true, Language.translate("Use selected characters"));
     getContentPane().add(closeControlPanel, BorderLayout.SOUTH);

     // center
     getContentPane().add( new JScrollPane(table), BorderLayout.CENTER );
     stm.installGUI(table);
     basicTableModel.clearRowSelection();
     for(int i=0; i<selCodes.length; i++)
     {
        basicTableModel.setRowSelection(selCodes[i], true);
     }
     stm.restoreTableSelections();
     
     if(selCodes.length>0)
     {          
       table.scrollRectToVisible( table.getCellRect(selCodes[0], 0, true) );
     }  


           
     // north
     AdvancedSearchPanel searchPanel = new AdvancedSearchPanel("Search: ", null, stm, true);
     //searchPanel.setAdvancedMode(true);     
     getContentPane().add(searchPanel, BorderLayout.NORTH);

     setSize(500, 500);
     setLocationRelativeTo(owner);
     setVisible(true);   

  } // Constructor


  public boolean wasCancelled() { return closeControlPanel.getWasCancelled(); }
  public int[] getSelectedCodes() 
  {
    stm.storeTableSelection();
    return basicTableModel.getSelectedRows(); 
  }

   
  class UnicodeTableModel extends FineGrainTableModel
  {
     private char[] representableCharsetChars = null;

     String[] COLUMN_NAMES = new String[]{
                 //"representable",
                 "intcode",
                 "char",
                 //"name",
                 "unicode block"
                 //"type"
     //            "lowercase", "uppercase", "titlecase"
     };

     int[] COLUMN_PREFERED_SIZES = new int[]{ 8,8, 16};
     public int getPreferredColumnWidth(int column)
     {
       if(column>=0 && column<COLUMN_PREFERED_SIZES.length) return COLUMN_PREFERED_SIZES[column];
       return -1;
     }

     public String getColumnName(int col) { return COLUMN_NAMES[col]; }

     public int getColumnAlignment(int column)
     {
       if( column==2) return JLabel.LEFT;
       return JLabel.CENTER;
     }



     public int getColumnCount() { return COLUMN_NAMES.length; }
     public int getRowCount()    { return charDisplayLimit; }
     
     public void setDisplayLimit(int lim)
     {
       //System.out.println("set limit to "+lim);
       fireTableModelWillChange();
       charDisplayLimit = lim;
       fireTableDataChanged();
       fireTableModelHasChanged();  
     }

     public void setCharset(Charset cs)
     {
      fireTableModelWillChange();
      byte[] bb = new byte[256];
      for(int i=0; i<256; i++)
      {
        bb[i] =  (byte) i;
      }

      representableCharsetChars = cs.decode(ByteBuffer.wrap(bb)).toString().toCharArray();
      Arrays.sort(representableCharsetChars);
        fireTableDataChanged();
        fireTableModelHasChanged();
     }


     public Object getValueAt(int row, int col)
     {   
       char c = (char) row;
       if(col==0) return row;
       if(col==1) return ""+c ;
       if(col==2)
       {
         Character.UnicodeBlock ub = Character.UnicodeBlock.of(c);  // in 1.5, can be applied to INT
         if(ub==null) return "" ;
         return ""+ub ;
       }           
       return "?";
     }          
  }
  


  public static void main(String[] a)
  {
     KeyboardDialog.main(null);                                                                    
  }                                                                              

} // UnicodeSearchDialog
