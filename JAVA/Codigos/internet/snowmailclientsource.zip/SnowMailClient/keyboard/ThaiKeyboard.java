package SnowMailClient.keyboard;
                         
public class ThaiKeyboard extends KeyboardMap
{                           
             
  public ThaiKeyboard()
  {
    super("Thai keys", 10);

    this.keys.add(new KeyboardKey( "KO KAI",     0x0e01, "KAI" ));
    this.keys.add(new KeyboardKey( "KHO KHAI",   0x0e02, "KHAI" ));
    this.keys.add(new KeyboardKey( "KHO KHUAT",  0x0e03, "KHUAT" ));
    this.keys.add(new KeyboardKey( "KHO KHWAI",  0x0e04, "KHWAI" ));
    this.keys.add(new KeyboardKey( "KHO KHON",   0x0e05, "KHON" ));
    this.keys.add(new KeyboardKey( "KHO RAKHANG", 0x0e06, "RAKHANG" ));
    this.keys.add(new KeyboardKey( "NGO NGU",    0x0e07, "NGU" ));
    this.keys.add(new KeyboardKey( "CHO CHAN",   0x0e08, "CHO CHAN" ));
    this.keys.add(new KeyboardKey( "CHO CHING",  0x0e09, "CHING" ));
    this.keys.add(new KeyboardKey( "CHO CHANG",  0x0e0a, "CHANG" ));

    this.keys.add(new KeyboardKey( "SO SO",      0x0e0b, "SOSO" ));
    this.keys.add(new KeyboardKey( "CHO CHOE",   0x0e0c, "CHOCHOE" ));
    this.keys.add(new KeyboardKey( "YO YING",    0x0e0d, "YOYING" ));
    this.keys.add(new KeyboardKey( "DO CHADA",   0x0e0e, "DOCHADA" ));
    this.keys.add(new KeyboardKey( "TO PATAK",   0x0e0f, "TOPATAK" ));
    this.keys.add(new KeyboardKey( "THO THAN",       0x0e10, "THOTHAN" ));
    this.keys.add(new KeyboardKey( "THO NANGMONTHO", 0x0e11, "THONANGMONTHO" ));
    this.keys.add(new KeyboardKey( "THO PHUTHAO",    0x0e12, "THOPHUTHAO" ));
    this.keys.add(new KeyboardKey( "NO NEN",   0x0e13, "NONEN" ));
    this.keys.add(new KeyboardKey( "DO DEK",   0x0e14, "DODEK" ));

    this.keys.add(new KeyboardKey( "TO TAO",      0x0e15, "TOTAO" ));
    this.keys.add(new KeyboardKey( "THO THUNG",   0x0e16, "THOTHUNG" ));
    this.keys.add(new KeyboardKey( "TTHO THAHAN", 0x0e17, "THOTHAHAN" ));
    this.keys.add(new KeyboardKey( "THO THONG",   0x0e18, "THOTHONG" ));
    this.keys.add(new KeyboardKey( "NO NU",       0x0e19, "NONU" ));

    this.keys.add(new KeyboardKey( "BO BAIMAI",  0x0e1a, "BOBAIMAI" ));
    this.keys.add(new KeyboardKey( "PO PLA",     0x0e1b, "POPLA" ));
    this.keys.add(new KeyboardKey( "PHO PHUNG",  0x0e1c, "PHOPHUNG" ));
    this.keys.add(new KeyboardKey( "FO FA",      0x0e1d, "FOFA" ));
    this.keys.add(new KeyboardKey( "PHO PHAN",   0x0e1e, "PHOPHAN" ));

    this.keys.add(new KeyboardKey( "FO FAN",      0x0e1f, "FOFAN" ));
    this.keys.add(new KeyboardKey( "PHO SAMPHAO", 0x0e20, "PHOSAMPHAO" ));
    this.keys.add(new KeyboardKey( "MO MA",       0x0e21, "MOMA" ));
    this.keys.add(new KeyboardKey( "YO YAK",      0x0e22, "YOYAK" ));
    this.keys.add(new KeyboardKey( "RO RUA",      0x0e23, "RORUA" ));

    this.keys.add(new KeyboardKey( "FO FAN",      0x0e1f, "FOFAN" ));
    this.keys.add(new KeyboardKey( "PHO SAMPHAO", 0x0e20, "PHOSAMPHAO" ));
    this.keys.add(new KeyboardKey( "MO MA",       0x0e21, "MOMA" ));
    this.keys.add(new KeyboardKey( "YO YAK",      0x0e22, "YOYAK" ));
    this.keys.add(new KeyboardKey( "RO RUA",      0x0e23, "RORUA" ));
    this.keys.add(new KeyboardKey( "RU",       0x0e24, "RU" ));
    this.keys.add(new KeyboardKey( "LO LING",  0x0e25, "LOLING" ));
    this.keys.add(new KeyboardKey( "LU",       0x0e26, "LU" ));
    this.keys.add(new KeyboardKey( "WO WAEN",  0x0e27, "WOWAEN" ));
    this.keys.add(new KeyboardKey( "SO SALA",  0x0e28, "SOSALA" ));
    this.keys.add(new KeyboardKey( "SO RUSI",  0x0e29, "SORUSI" ));
    this.keys.add(new KeyboardKey( "SO SUA",   0x0e2a, "SOSUA" ));
    this.keys.add(new KeyboardKey( "HO HIP",   0x0e2b, "HOHIP" ));
    this.keys.add(new KeyboardKey( "LO CHULA", 0x0e2c, "LOCHULA" ));
    this.keys.add(new KeyboardKey( "O ANG",    0x0e2d, "OANG" ));

    this.keys.add(new KeyboardKey( "HO NOKHUK",    0x0e2e, "HO NOKHUK" ));
    this.keys.add(new KeyboardKey( "PAIYANNOI",    0x0e2f, "PAIYANNOI" ));
    this.keys.add(new KeyboardKey( "SARA A",       0x0e30, "SARAA" ));
    this.keys.add(new KeyboardKey( "MAI HAN-AKAT", 0x0e31, "MAIHAN-" ));
    this.keys.add(new KeyboardKey( "SARA AA",      0x0e32, "SARAAA" ));

    this.keys.add(new KeyboardKey( "SARA AM",  0x0e33, "SARAAM" ));
    this.keys.add(new KeyboardKey( "SARA I",   0x0e34, "SARAI" ));
    this.keys.add(new KeyboardKey( "SARA II",  0x0e35, "SARAII" ));
    this.keys.add(new KeyboardKey( "SARA UE",  0x0e36, "SARAUE" ));
    this.keys.add(new KeyboardKey( "SARA UEE", 0x0e37, "SARAUEE" ));

    this.keys.add(new KeyboardKey( "SARA U",    0x0e38, "SARAU" ));
    this.keys.add(new KeyboardKey( "SARA UU",   0x0e39, "SARAUU" ));
    this.keys.add(new KeyboardKey( "PHINTHU",   0x0e3a, "PHINTHU" ));
    this.keys.add(new KeyboardKey( "CURRENCY SYMBOL BAHT",  0x0e3f, "$b" ));
    this.keys.add(new KeyboardKey( "SARA E",    0x0e40, "SARAE" ));

    this.keys.add(new KeyboardKey( "SARA AE",    0x0e41, "SARAAE" ));
    this.keys.add(new KeyboardKey( "SARA O",     0x0e42, "SARAO" ));
    this.keys.add(new KeyboardKey( "SARA AI MAIMUAN",   0x0e43, "SARAAI-" ));
    this.keys.add(new KeyboardKey( "SARA AI MAIMALAI",  0x0e44, "SARAAIm" ));
    this.keys.add(new KeyboardKey( "LAKKHANGYAO",    0x0e45, "LAKKHANGYAO" ));

    this.keys.add(new KeyboardKey( "MAIYAMOK",    0x0e46, "MAIYAMOK" ));
    this.keys.add(new KeyboardKey( "MAITAIKHU",   0x0e47, "MAITAIKHU" ));
    this.keys.add(new KeyboardKey( "MAI EK",      0x0e48, "MAIEK" ));
    this.keys.add(new KeyboardKey( "MAI THO",     0x0e49, "MAITHO" ));
    this.keys.add(new KeyboardKey( "MAI TRI",     0x0e4a, "MAITRI" ));

    this.keys.add(new KeyboardKey( "MAI CHATTAWA", 0x0e4b, "MAI CHATTAWA" ));
    this.keys.add(new KeyboardKey( "THANTHAKHAT",  0x0e4c, "THANTHAKHAT" ));
    this.keys.add(new KeyboardKey( "NIKHAHIT",     0x0e4d, "NIKHAHIT" ));                                
    this.keys.add(new KeyboardKey( "YAMAKKAN",     0x0e4e, "YAMAKKAN" ));
    this.keys.add(new KeyboardKey( "FONGMAN",      0x0e4f, "FONGMAN" ));

    this.keys.add(new KeyboardKey( "ANGKHANKHU",     0x0e5a, "ANGKHANKHU" ));
    this.keys.add(new KeyboardKey( "KHOMUT",      0x0e4b, "KHOMUT" ));

    this.keys.add(new KeyboardKey());
    this.keys.add(new KeyboardKey( "0",  0x0e50, "0t" ));
    this.keys.add(new KeyboardKey( "1",  0x0e51, "1t" ));
    this.keys.add(new KeyboardKey( "2",  0x0e52, "2t" ));
    this.keys.add(new KeyboardKey( "3",  0x0e53, "3t" ));
    this.keys.add(new KeyboardKey( "4",  0x0e54, "4t" ));
    this.keys.add(new KeyboardKey( "5",  0x0e55, "5t" ));
    this.keys.add(new KeyboardKey( "6",  0x0e56, "6t" ));
    this.keys.add(new KeyboardKey( "7",  0x0e57, "7t" ));
    this.keys.add(new KeyboardKey( "8",  0x0e58, "8t" ));
    this.keys.add(new KeyboardKey( "9",  0x0e59, "9t" ));


  }

  public String getCharset() { return "iso-8859-1"; }

  public static void main(String[] a)
  {
     KeyboardDialog.main(a);
  }

} // Keyboard
