package SnowMailClient.keyboard;

import java.util.*;

public final class CompletionBuffer
{
  final StringBuffer buffer = new StringBuffer();


  public CompletionBuffer()
  {

  } // Constructor

  /** add the chars to the buffer
  */
  public void addChars(String chars)
  {
    buffer.append(chars);
  }

  public int getBufferLength() { return buffer.length(); }

  public void resetBuffer() 
  {
    buffer.setLength(0);
  } 
  
  public String getChars() { return buffer.toString(); }
  public String toString() { return getChars(); }

} // CompletionBuffer
