package SnowMailClient.keyboard;

import javax.swing.*;
import java.awt.*;
import java.util.*;

public class KeyboardKey
{

  public String name;
  public int codeCAPITAL, codeSMALL;
  public String[] shortcuts;

  public JButton button;   // set by the view, used for highlights

  // if matching, tells if the capital is matching
  public boolean matchCapital = true;


  public Vector<Object> getVectorRepresentation()
  {
     Vector<Object> rep = new Vector<Object>();
     rep.addElement(1); // version
     rep.addElement(name);
     rep.addElement(codeCAPITAL);
     rep.addElement(codeSMALL);
     rep.addElement(shortcuts);
     return rep;
  }
  
                  
  public void createFromVectorRepresentation(Vector<Object> rep)
  {              
     int version = (Integer) rep.elementAt(0);
     name        = (String)  rep.elementAt(1);
     codeCAPITAL = (Integer) rep.elementAt(2);
     codeSMALL   = (Integer) rep.elementAt(3);
     shortcuts   = (String[]) rep.elementAt(4);
  }              
                         
  public KeyboardKey(Vector<Object> rep)
  {              
     createFromVectorRepresentation(rep);
  }              
  
                 
  /** Separator
  */
  public KeyboardKey()
  {
    name = "";
    shortcuts = new String[] {};
    codeCAPITAL = -1;
    codeSMALL = -1;
  }
                                                                                                                 

  public final boolean isSpacer()
  {
    return name.equals("");
  }


  /** represent a single CAPITAL letter
  */             
  public KeyboardKey(String name, int uniCode, String... shortcuts)
  {
    this.name = name;            
    this.shortcuts = shortcuts;   
    if(Character.isUpperCase(uniCode))
    {
      codeCAPITAL = uniCode;
      char small = Character.toLowerCase((char) uniCode);
      codeSMALL = (int) small;
    }
    else if(Character.isLowerCase(uniCode))
    {     
      codeSMALL = uniCode;
      char up = Character.toUpperCase((char) uniCode);
      codeCAPITAL = (int) up;
    }
    else
    {
      codeSMALL   = uniCode;
      codeCAPITAL = uniCode;
    }
  }
  
  /** represent a single CAPITAL letter
  */
  public KeyboardKey(String name, int uniCodeCAPITAL, int codeSmall, String... shortcuts)
  {
    this.name = name;
    this.shortcuts = shortcuts;
    codeCAPITAL = uniCodeCAPITAL;
    codeSMALL = codeSmall;
  }

  public void setIsCandidate(boolean is)
  {
    //isCandidate = is;
    if(button!=null)
    {
      if(is)
      {
        button.setBackground(Color.green);
      }
      else
      {
        button.setBackground(UIManager.getColor("Button.background"));
      }
    }
  }

  public String toString()
  {
    if(matchCapital) return toStringCAPITAL();
    return toStringSMALL();           
  }

  public String toStringCAPITAL()
  {
    //return ""+(char) codeCAPITAL;
    return toStringSMALL().toUpperCase();
  }

  public String toStringSMALL()
  {                          
    return ""+(char) codeSMALL;
  }

  public String[] getAllShortcuts() { return shortcuts; }
  

  public String toStringAllShortcuts()
  {
     if(shortcuts.length==0) return "";
     if(shortcuts.length==1) return shortcuts[0];

     StringBuffer completion = new StringBuffer("[");
     for(String s: getAllShortcuts())
     {
        completion.append(""+s+"    ");
     }
     completion.setLength(completion.length()-4);  // remove last separator
     completion.append("]");
     return completion.toString();                           
  }
  
  public static void main(String[] a)                                                                                                
  {
     KeyboardDialog.main(null);
  }             
  
} // KeyboardKey
