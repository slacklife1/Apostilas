package SnowMailClient.keyboard;

public interface KeyboardListener
{
   public void typed(String text);

} // KeyboardListener
