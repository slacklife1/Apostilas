package SnowMailClient.keyboard;

import java.util.*;

/** base for all keyboards maps
*/
public class KeyboardMap
{
   protected final Vector<KeyboardKey> keys = new Vector<KeyboardKey>();
   private String name = "";
   private int columnCount;

   public Vector<KeyboardKey> getKeys() { return keys; }
   public final int getColumnCount() { return columnCount; }
   public final String getName() { return name; }             
   
   /** overwrite if less keys are visible (hidden mappings)
   */
   public int getVisibleKeys() { return keys.size(); } //16; }
   
   /** overwrite if more specific, this allow to choose precisely available fonts...
   */
   public String getCharset()  { return "utf-8"; }

   public KeyboardMap(String name, int columnCount)
   {
     this.name = name;
     this.columnCount = columnCount;
   }

   public Vector<Object> getVectorRepresentation()
   {
      Vector<Object> rep = new Vector<Object>();
      rep.addElement(1);               // 0: version
      rep.addElement(name);            // 1
      rep.addElement(columnCount);     // 2
      Vector<Object> keysRep = new Vector<Object>();
      rep.addElement(keysRep);         // 3
      for(KeyboardKey key: keys)
      {
        keysRep.addElement(key.getVectorRepresentation());
      }
      return rep;
   }

   public void createFromVectorRepresentation(Vector<Object> rep)
   {
      int version    = (Integer) rep.elementAt(0);
      name = (String) rep.elementAt(1);
      columnCount = (Integer) rep.elementAt(2);
      Vector<Vector> keysRep = (Vector<Vector>) rep.elementAt(3);
      keys.clear();
      for(Vector krep: keysRep)
      {
        keys.add(new KeyboardKey(krep));
      }
   }

   
   public Vector<KeyboardKey> getKeyStartingWithShortcut(String _s)
   {               
      Vector<KeyboardKey> rep = new Vector<KeyboardKey>();
      if(_s.length()==0) return rep;

      // first char determine case
      String s = _s;
      if(Character.isUpperCase(_s.charAt(0)))
      {
        s = _s.toUpperCase();
        for(KeyboardKey k:keys)
        {       
           for(String sc: k.getAllShortcuts())
           {     
             if(sc.toUpperCase().startsWith(s))
             {
               rep.addElement(k);
               k.matchCapital = true;
               break; // only add one per key
             }
           }
        }
      }
      else
      {
        s = _s.toLowerCase();
        for(KeyboardKey k:keys)
        {
           for(String sc: k.getAllShortcuts())
           {
             if(sc.toLowerCase().startsWith(s))
             {
               rep.addElement(k);
               k.matchCapital = false;
               break; // only add one per key
             }
           }
        }
      }

      if(rep.size()>0) return rep;  // found

      return rep;
   }


   public KeyboardKey getKeyWithShortcut(String _s)
   {
      if(_s.length()==0) return null;

      // first char determine case
      String s = _s;
      if(Character.isUpperCase(_s.charAt(0)))
      {
         // search for upper matches
         String supper = _s.toUpperCase();

         for(KeyboardKey k:keys)
         {     
            for(String sc: k.getAllShortcuts())
            {
              if(sc.toUpperCase().equals(supper))
              {
                k.matchCapital = true;
                return k;
              }
            }
         }

      }
      else
      {
         // search for lower matches
         String slow = _s.toLowerCase();

         for(KeyboardKey k:keys)
         {
            for(String sc: k.getAllShortcuts())
            {
              if(sc.toLowerCase().equals(slow))
              {
                k.matchCapital = false;
                return k;
              }
            }      
         }
      }


      return null;
   }

   public String toString() { return this.getName(); }

} // KeyboardMap
