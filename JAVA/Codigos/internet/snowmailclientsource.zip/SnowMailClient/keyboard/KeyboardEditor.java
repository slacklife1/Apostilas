package SnowMailClient.keyboard;

import snow.SortableTable.*;
import snow.Language.*;
import snow.utils.gui.*;
import snow.utils.storage.*;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;

                     
public final class KeyboardEditor extends JDialog
{
  final KeyboardTableModel keyboardTableModel = new KeyboardTableModel();
  final JTable table = new JTable(keyboardTableModel);
  final KeyboardDialog keyboardDialog;

  public KeyboardEditor( KeyboardDialog owner )
  {
    super(owner, Language.translate("Keyboard editor"), false);
    keyboardDialog = owner;
    
    keyboardTableModel.setMap( owner.getActualKeyboardMap() );

    getContentPane().add(new JScrollPane(table), BorderLayout.CENTER);

    JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    getContentPane().add(controlPanel, BorderLayout.NORTH);
    JButton searchUnicode = new JButton(Language.translate("Edit / Add keys"));
    controlPanel.add(searchUnicode);
    searchUnicode.addActionListener(new ActionListener()
    {
        public void actionPerformed(ActionEvent ae)
        {
           int[] sel = table.getSelectedRows();
           int[] selCodes = new int[sel.length];
           for(int i=0; i<sel.length; i++)
           {   
              KeyboardKey key = keyboardTableModel.getKeyAt(sel[i]);
              selCodes[i] = key.codeSMALL;
           }   

           UnicodeSearchDialog uv = new UnicodeSearchDialog(KeyboardEditor.this, selCodes);
           if(!uv.wasCancelled())
           {
              int[] retCodes = uv.getSelectedCodes();
              Arrays.sort(retCodes);
              //System.out.println(""+retCodes.length);
              for(int i=0; i<retCodes.length; i++)
              {
                 KeyboardKey key = new KeyboardKey(
                    "", (int) Character.toUpperCase( (char) retCodes[i] ),
                    "" + (char) retCodes[i]);
                 keyboardTableModel.addKey(key);
              }
           }
        }
    });

    JButton removeSelected = new JButton(Language.translate("Remove Selected"));
    controlPanel.add(removeSelected);
    removeSelected.addActionListener(new ActionListener()
    {
        public void actionPerformed(ActionEvent ae)
        {    
           int[] sel = table.getSelectedRows();
           Arrays.sort(sel);
           for(int i=sel.length-1; i>=0; i--)
           {
              keyboardTableModel.removeKeyAt(sel[i]);
           }
        }
    });           

    setSize(400,400);
    this.setLocationRelativeTo(owner);
    setVisible(true);
  } // Constructor      
  

  class KeyboardTableModel extends AbstractTableModel
  {  
    KeyboardMap map;
    public KeyboardTableModel()
    {
    }
                        
    public void setMap(KeyboardMap map)
    {
      this.map = map;
    }

    public KeyboardKey getKeyAt(int row)
    {
      if(row<0 || row>=map.getKeys().size()) return null;
      return (KeyboardKey) map.getKeys().elementAt(row);
    }


    public Object getValueAt(int row, int col)
    {
      KeyboardKey key = getKeyAt(row);
      if(col==0) return ""+(row+1);
      if(col==1) return ""+key.codeSMALL;
      if(col==2) return ""+key.codeCAPITAL;
      if(col==3) return ""+key.toStringSMALL();
      if(col==4) return ""+key.toStringCAPITAL();
      if(col==5) return ""+key.toStringAllShortcuts();
      return "?";
    }

    public int getColumnCount()
    {

      return 6;
    }

    public String getColumnName(int col)
    {
      if(col==0) return "Number";
      if(col==1) return "Unicode small";
      if(col==2) return "Unicode capital";
      if(col==3) return "small key";
      if(col==4) return "capital key";
      if(col==5) return "shortcuts";
      return "";
    }

    public int getRowCount()
    {
      if(map==null) return 0;
      return map.getKeys().size();
    }

    public boolean isCellEditable(int row, int col)
    {
      if(col==5) return true;
      return false;
    }

    public void setValueAt(Object val, int row, int col)
    {
      if(col==5)
      {
         KeyboardKey key = getKeyAt(row);
         key.shortcuts = new String[]{ ""+val };                             
         // reload the map
         updatekeyboardView();
      }
    }

    public void updatekeyboardView()
    {
       keyboardDialog.setKeyboard( keyboardDialog.getActualKeyboardMap() );
       keyboardDialog.pack();
    }
    
    public void removeKeyAt(int row)
    {                                    
      if(row<0 || row>=map.getKeys().size()) return;
      
      map.getKeys().removeElementAt(row);
      updatekeyboardView();
      this.fireTableDataChanged();

    }

    public void addKey(KeyboardKey key)
    {
      map.getKeys().add(key);
      updatekeyboardView();
      this.fireTableDataChanged();
    }
  }

  public static void main(String[] a)                                                                                                
  {
     KeyboardDialog.main(null);
  }  

} // KeyboardEditor
