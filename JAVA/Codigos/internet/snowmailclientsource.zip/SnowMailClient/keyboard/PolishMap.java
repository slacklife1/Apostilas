package SnowMailClient.keyboard;

import java.util.*;
import java.nio.charset.*;

public final class PolishMap extends KeyboardMap
{

  public PolishMap()
  {
     super("Polish keys", 8);
     
     this.keys.add(new KeyboardKey("Polish A", 0x0104, 0x0105, "a,"));
     this.keys.add(new KeyboardKey("Polish C", 0x0106, 0x0107, "c'"));
     this.keys.add(new KeyboardKey("Polish E", 0x0118, 0x0119, "e,"));
     this.keys.add(new KeyboardKey("Polish L", 0x0141, 0x0142, "l-"));
     this.keys.add(new KeyboardKey("Polish N", 0x0143, 0x0144, "n'"));
     this.keys.add(new KeyboardKey("Polish O", 0x00D3, 0x00F3, "o'"));
     this.keys.add(new KeyboardKey("Polish S", 0x015A, 0x015B, "s'"));
     this.keys.add(new KeyboardKey("Polish Z", 0x0179, 0x017A, "z'"));

  } // Constructor


  public String getCharset()  { return "iso-8859-2"; }
 
}
