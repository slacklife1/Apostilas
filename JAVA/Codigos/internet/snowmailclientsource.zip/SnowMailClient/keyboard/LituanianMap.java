
package SnowMailClient.keyboard;

/*
1.  	�  �  	ALT+0244, ALT+0192  	   	6.  	� �  	ALT+ 0240, ALT+0208
2. 	�  � 	ALT+ 0232, ALT+0200 	  	7. 	� � 	ALT+0248, ALT+0216
3. 	�  � 	ALT+ 0230, ALT+0198 	  	8. 	� � 	ALT+0251, ALT+0219
4. 	� � 	ALT+ 0235, ALT+0203 	  	9. 	� � 	ALT+0254, ALT+0222
5. 	�  � 	ALT+ 0225, ALT+0193 	  	-  	-  	      ------
*/

public final class LituanianMap extends KeyboardMap
{

  public LituanianMap()
  {
     super("Lituanian keys", 8);
     
     this.keys.add(new KeyboardKey("Lituanian A GRAVE", 192, 244,  "a`"));
     this.keys.add(new KeyboardKey("Lituanian E GRAVE", 200, 232, "e`"));
     this.keys.add(new KeyboardKey("Lituanian AE",      198, 230, "ae"));
     this.keys.add(new KeyboardKey("Lituanian E UMLAUT", 203, 235, "e:"));

     this.keys.add(new KeyboardKey("Lituanian A AIGU",   193, 225,  "a'"));
     this.keys.add(new KeyboardKey("Lituanian D",        208, 240, "-d"));
     this.keys.add(new KeyboardKey("Lituanian 0",       216, 248, "0/"));
     this.keys.add(new KeyboardKey("Lituanian P",       222, 254, "lp"));

  } // Constructor


  public String getCharset()  { return "iso-8859-4"; }

  

} // LituanianMap
