package SnowMailClient.keyboard;

import SnowMailClient.Language.*;
import snow.lookandfeel.ThemesManager;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.util.*;
import javax.swing.text.*;

/** add a keyboard to enter text in a textpane.
    The textpane document inserts are filtered and matching typed keyboard shortcuts are replaced.
    IMPORTANT: The paste contents are not replaced. only types.
*/
public final class KeyboardDialog extends JDialog
{                            
  private final GridBagLayout gridBag = new GridBagLayout();
  private final GridBagConstraints constr = new GridBagConstraints();
  private int actualCol = 0;
  private int numberOfCols = 2;
  private int nButtons = 0;
  private KeyboardMap map;
  private final JLabel completionLabel = new JLabel(Language.translate("Completions: none"));
  private final JPanel keyboardPanel = new JPanel();
  private final JSpinner spinner = new JSpinner(new SpinnerNumberModel(11,1,99,1));                                        
                       
  private final JComboBox keyboardsCB = new JComboBox(new Object[]{
      new PolishMap(),
      new RussianMap(),
      new LituanianMap(),        
     // new HiraganaMap(),
      new ThaiKeyboard()
  });

  private final Vector<KeyboardListener> listeners = new Vector<KeyboardListener>();

  final String title;    

  public KeyboardDialog(JFrame parent)
  {
    super(parent, Language.translate("Keyboard"), false);
    this.title = getTitle();
    this.setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
    this.setDefaultLookAndFeelDecorated(true);
    this.setFocusableWindowState(false);

    this.getContentPane().setLayout(new BorderLayout());
    this.getContentPane().add(completionLabel, BorderLayout.SOUTH);
    this.getContentPane().add(keyboardPanel, BorderLayout.CENTER);

    JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.X_AXIS));
    controlPanel.setBorder(new EmptyBorder(3,2,3,2));

    this.getContentPane().add(controlPanel, BorderLayout.NORTH);
    controlPanel.add(keyboardsCB);
    controlPanel.add(Box.createHorizontalGlue());
    controlPanel.add(new JLabel(Language.translate("Size")+": "));
    controlPanel.add(spinner);
    
    keyboardsCB.setPreferredSize(new Dimension(
      (int) keyboardsCB.getPreferredSize().getWidth(),
      (int) UIManager.getFont("Label.font").getSize()));

    final JButton editButton = new JButton(Language.translate("Edit"));
    editButton.setFont(ThemesManager.getInstance().getSmallFont());
    controlPanel.add(Box.createHorizontalGlue());
    //NOT FINISHED !!!controlPanel.add(editButton);
    editButton.addActionListener(new ActionListener()
    {
       public void actionPerformed(ActionEvent ae)
       {
          JPopupMenu popup = new JPopupMenu("edit");
          JMenuItem miEdit = new JMenuItem( Language.translate("Edit keyboard") );
          popup.add(miEdit);
          miEdit.addActionListener(new ActionListener()
          {
            public void actionPerformed(ActionEvent ae)
            {
               KeyboardEditor ke = new KeyboardEditor(KeyboardDialog.this);
            }
          });

          JMenuItem miAdd = new JMenuItem( Language.translate("Add new keyboard") );
          popup.add(miAdd);
          miAdd.addActionListener(new ActionListener()
          {
            public void actionPerformed(ActionEvent ae)
            {
                String name = JOptionPane.showInputDialog(editButton, Language.translate("Keyboard name: "));
                if(name!=null)
                {
                    KeyboardMap kmap = new KeyboardMap(name, 8);
                    setKeyboard(kmap);
                }
            }
          });
          JMenuItem miRemove = new JMenuItem( Language.translate("Remove selected keyboard") );
          //popup.add(miRemove);
          miRemove.addActionListener(new ActionListener()
          {
            public void actionPerformed(ActionEvent ae)
            {
            }
          });

          popup.show(editButton,10,5);
       }
    });
        
    keyboardsCB.addActionListener(new ActionListener()
    {
       public void actionPerformed(ActionEvent ae)
       {
          setKeyboard( (KeyboardMap) keyboardsCB.getSelectedItem() );
          pack();
       }
    });

    spinner.addChangeListener(new ChangeListener()
    {
       public void stateChanged(ChangeEvent ce)
       {
          int fs = Integer.parseInt(""+spinner.getValue());
          Font font = new Font("LucidaSansRegular", Font.PLAIN, fs);
          for(KeyboardKey k : map.getKeys())
          {
             if(k.button!=null)
             {
               k.button.setFont(font);
             }
          }
          pack();
       }
    });

    spinner.setPreferredSize(new Dimension(
      (int) spinner.getPreferredSize().getWidth(),
      (int) keyboardsCB.getPreferredSize().getHeight()));
          

    // otherwise, we can make it to disapear !
    // ### NOT WORKING !!!
    this.setMinimumSize(new Dimension(30,30));

  } // Constructor                                                             
  
  public KeyboardMap getActualKeyboardMap() { return map; }

  public void setKeyboard(KeyboardMap map)
  {    
    this.map = map;
             
    numberOfCols = map.getColumnCount();
    nButtons = 0;  
    actualCol = 0;
    setTitle(map.getName());

    keyboardPanel.removeAll();
    keyboardPanel.setLayout(gridBag);

    for(KeyboardKey key: map.getKeys())
    {   
       addButton(key);
    }
  }
  
  public String getCharsetForDisplayedKeyboard()
  {
    return map.getCharset();
  }

  public void addListener(KeyboardListener kl)
  {
    listeners.add(kl);
  } 

  public void removeListener(KeyboardListener kl)
  {
    listeners.remove(kl);                                                                                                          
  }
  
  /** set the pane where this keyboard writes
  */
  public void setTarget(final JTextPane pane)
  {
    if(!pane.isEditable()) return;
    
    final DefaultStyledDocument doc = (DefaultStyledDocument) pane.getDocument();
    
    // add this keyboard hits and write them in the pane
    //
    this.addListener(new KeyboardListener()
    {
      public void typed(String text)
      {
        try
        {
          // keys inserts are also made with replace instead of insert
          //int lsel = pane.getSelectionEnd()-pane.getSelectionStart();
          //if(lsel<0) lsel=0;
          //doc.replace(pane.getCaretPosition(), lsel, text, null);

          doc.insertString(pane.getCaretPosition(), text, null);                                                         
        }                      
        catch(Exception ex)  
        {
          ex.printStackTrace();
        }
      }
    });                                                            
    
    // filter the key inserts in the pane...
    //
    doc.setDocumentFilter(new DocumentFilter()  
    {
       public void insertString(DocumentFilter.FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException
       {                                  
          //System.out.println("Filter insert: "+string+" at "+offset);            
          fb.insertString(offset, string, attr);
          resetHighlights();
       }

       public void remove(DocumentFilter.FilterBypass fb, int offset, int length) throws BadLocationException
       {
          //System.out.println("Filter remove: at "+offset+", l="+length);
          fb.remove(offset, length);
          resetHighlights();
       }

       public void replace(DocumentFilter.FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException
       {
          //System.out.println("Filter replace: "+text+" at "+offset+", l="+length);
          filterReplace(fb, offset, length, text, attrs);
       }

    }); 
    
    // listen to the ESC key hit
    //
    pane.addKeyListener(new KeyAdapter()
    {  
      @Override public void keyPressed(KeyEvent ke)
      {  
        if(ke.getKeyCode()==KeyEvent.VK_ESCAPE)
        {
          //System.out.println("ESCAPE PRESSED !");
          completionBuffer.resetBuffer();
          resetHighlights();
        }
      }
    });
  }



  /** this is the actual match buffer. These chars are to be treated
  */
  //final private StringBuffer matchBuffer = new StringBuffer();             
  final private CompletionBuffer completionBuffer = new CompletionBuffer();
                        
  int previousReplaceOffset=-1;

  /** the user types call this.
      the user CTRL+V call this
      the keyboard clicks DOESN't call this.     
      only replace matching shortcuts entered with single characters at once.
  */
  private void filterReplace(DocumentFilter.FilterBypass fb, int replaceOffset, int replaceLength, String text, AttributeSet attrs)  throws BadLocationException
  {
    //System.out.println("FR offset="+replaceOffset+", l="+replaceLength+", text="+text);
        
    // always write the actual typed text.
    // we make the eventual replacements later
    fb.replace(replaceOffset, replaceLength, text, attrs);
    
    // accept only single typed chars !!!
    // don't convert on pastes...
    if(text.length()>1) return;

    // the position where the blink NOW is
    int offset = replaceOffset+text.length();

    this.completionLabel.setText(Language.translate("Completions: none"));

    // replace ONLY if visible
    if(!this.isVisible()) return;
    
    resetHighlights();

           
    // reset the buffer if the actual insert is not next to previous
    if(previousReplaceOffset==-1)
    {
      previousReplaceOffset = offset-1;
    }

    if(  completionBuffer.getBufferLength()>0  // has precedent chars
      && previousReplaceOffset!=-1             // written at another place than
      && offset-previousReplaceOffset!=1)      // the last one
    {
      // reset the buffer, because we have disjoint char positions !
      System.out.println("Reset buffer because offset jump : "+previousReplaceOffset+"  "+offset);
      completionBuffer.resetBuffer();
      // ### complete the buffer ?
      // continue with the single new char
    }
    previousReplaceOffset = offset;


    // add the new typed text in the buffer
    //
    completionBuffer.addChars(text);

    // this is the complete shortcut
    String typedShortcut = completionBuffer.toString();

    // and the keys starting with it
    Vector<KeyboardKey> keys = map.getKeyStartingWithShortcut(typedShortcut);
        
     
    if(keys.size()==0)
    {     
      // no more candidates, bad shortcut {a,b,c} 
      completionBuffer.resetBuffer();

      // 1) look if {a,b} or {a} are matching
      for(int end=typedShortcut.length()-1; end>=1; end--)
      {
         String sub = typedShortcut.substring(0,end);
         //System.out.println("try "+sub);
         // is it an exact matching ?
         KeyboardKey matchingKey = map.getKeyWithShortcut(sub);
         if(matchingKey!=null)
         {
            String toRemove = sub;
            int pos = offset-toRemove.length() -typedShortcut.length() + end ;
            //System.out.println("Removing "+toRemove+" at pos "+pos);
            
            fb.remove(pos, toRemove.length());
            
            fb.replace(pos, 0, matchingKey.toString(), attrs);
            
            // we have a rest for a subsequent completion !
            completionBuffer.addChars(typedShortcut.substring(end));
            //System.out.println("Rest: "+typedShortcut.substring(end));
            // direct evaluate recursively for completion
            // ###    
            highlightKeysStartingWith(completionBuffer.toString());
            
            matchingKey = map.getKeyWithShortcut(completionBuffer.toString());
            if(matchingKey!=null)
            {
               System.out.println("match !");  
            }

            return;
         }
      }


      // 2) look if {b,c} or {c} are good candidates
      for(int start=1; start<typedShortcut.length(); start++)
      {
        String sub = typedShortcut.substring(start);
        //System.out.println("Trying "+sub);
        Vector<KeyboardKey> nkeys = map.getKeyStartingWithShortcut(sub);
        if(nkeys.size()>0)
        {
          completionBuffer.addChars(sub);
          // => highlight the candidate(s)
          setCandidates(nkeys);
          return;
        }
      }



    }
    else if(keys.size()==1)
    {
      // is it an exact matching ?
      KeyboardKey matchingKey = map.getKeyWithShortcut(typedShortcut);
      if(matchingKey!=null)
      {
        // we have a matching !
        // all the waiting keys are replaced with the key
        String key = matchingKey.toString();

        // remove all typed chars
        String toRemove = completionBuffer.toString();
        int pos = offset-toRemove.length();
        //System.out.println("Remove "+toRemove+" at "+pos);
        fb.remove(pos, toRemove.length());
         
        // add the key at pos and don't replace anything (l=0)
        fb.replace(pos, 0, key, attrs);
        completionBuffer.resetBuffer();
        return;
      }

      // => highlight the candidate
      setCandidates(keys);
    }
    else
    {
      // => highlight the candidates
      setCandidates(keys);
    }
  }


  private void highlightKeysStartingWith(String sub)
  {
     Vector<KeyboardKey> nkeys = map.getKeyStartingWithShortcut(sub);
     if(nkeys.size()>0)
     {
        setCandidates(nkeys);
     }
  }


  private void resetHighlights()
  {
     if(map!=null)
     {
          for(KeyboardKey key: map.getKeys())
          {
            key.setIsCandidate(false);
          }
     }
  }


  private void setCandidates(Vector<KeyboardKey> keys)
  {   
      StringBuffer completion = new StringBuffer();
      for(KeyboardKey k: keys)
      {               
        k.setIsCandidate(true);
        completion.append(""+k+" = [");
        for(String s: k.getAllShortcuts())
        {
          completion.append(""+s+"    ");
        }         
        completion.setLength(completion.length()-4);  // remove last separator

        completion.append("],     ");
      }
      completion.setLength(completion.length()-6);  // remove last separator
      this.completionLabel.setText(completion.toString());
  }


  private void addButton(final KeyboardKey key)
  {
    nButtons++;         
    
    JComponent toAdd = null;
    if(key.isSpacer())
    {
      toAdd = new JLabel("");
    }
    else
    {
      JButton button = new JButton(""+key.toStringCAPITAL());
      key.button = button;
      toAdd = button;  
      button.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent ae)
        {
           if((ae.getModifiers() & ae.SHIFT_MASK) == ae.SHIFT_MASK)
           {
             for(KeyboardListener kl: listeners)
             {
               kl.typed(""+key.toStringCAPITAL());
             }
           }
           else
           {
             for(KeyboardListener kl: listeners)
             {
               kl.typed(""+key.toStringSMALL());
             }
           }
        }
      });
      
      button.addMouseListener(new MouseAdapter()
      {
         @Override public void mouseEntered(MouseEvent me)
         {
            setTitle(title+"  "+key+" = "+key.toStringAllShortcuts());

         }

         @Override public void mouseExited(MouseEvent me)
         {
            setTitle(title);
         }
      });       

    }

    constr.fill = constr.BOTH;

    actualCol++;
    if(actualCol==numberOfCols)
    {
      constr.gridwidth = GridBagConstraints.REMAINDER;
      actualCol=0;
    }
    else
    {
      constr.gridwidth = 1;
    }

    if(nButtons<=map.getVisibleKeys())
    {                    
      gridBag.setConstraints(toAdd, constr);
      keyboardPanel.add(toAdd);
    }



  }
                                        
  public static void main(String[] a)                                                                                                
  {                            
    JFrame f = new JFrame();
    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    JTextPane pane = new JTextPane();
    f.setContentPane(new JScrollPane(pane));
    pane.setFont(new Font("LucidaSansRegular", Font.PLAIN, 18));

    f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);
    f.setSize (300, 100);         
    f.setVisible(true);

    KeyboardDialog kd = new KeyboardDialog(f);
    kd.setKeyboard(new PolishMap());
    kd.setTarget(pane);       
    kd.pack();
    kd.setLocation (200, 200);
    kd.setVisible(true);
  }

} // KeyboardDialog
