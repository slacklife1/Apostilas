package SnowMailClient.Language;


import java.io.*;
import java.util.*;
import java.util.zip.*;


import snow.utils.storage.*;


/** parse sentences to translate in the sourcecode   
 *  the method ParseWholeSourceAndSaveInFile should be runned at each new release
 *  to allow translations. It produce a file named english_sentences.vec
 *  used by the TranslationEditor.
 */
public final class SourceSentencesParser
{         
  public static final String START = "Language"+".translate(";    // split to avoid recognition by the parser !!

  /**                     
  */                
  private SourceSentencesParser()
  {
                               
  } // Constructor    
       
       
  
  /** this parse the whole source code for sentences and write them in a vector file   
    named  SnowMailClient/Language/english_sentences.vec

    @return a termination status message
  */
  public static String parseWholeSourceAndSaveInFile(File sourceDir, StringBuffer warningBuffer)
  {
     // works when running in the IDE
     SourceSentencesParser ssp = new SourceSentencesParser();
     Vector<Sentence> collected = ssp.collectStringsToTranslateRecurse(sourceDir, sourceDir.getAbsolutePath(), warningBuffer);

     System.out.println(""+collected.size()+" sentences found in source");

     if(collected.size()==0)
     {
       String msg = "Zero sentences to translate found in "+sourceDir.getAbsolutePath()+"\nStopping without saving.";
       //warningBuffer.append("\n"+msg);
       System.out.println(msg);
       return msg;
     }

     // save
     Vector<Object> v = new Vector<Object>();
     for(int i=0;i<collected.size(); i++)
     {
       try
       {
         Sentence se = collected.elementAt(i);
         v.add(se.getVectorRepresentation());
       }
       catch(Exception e)
       {
         e.printStackTrace();
       }
     }

     File out = new File("SnowMailClient/Language/english_sentences.vec");

     try
     {
       FileUtils.SaveVectorToFile(out, v);
       Vector<Sentence> test = readEnglishSourceCodeSentencesFromFile();
       if(test==null) throw new Exception("XXX");
     }
     catch(Exception e)
     {
       e.printStackTrace();
     }

     return ""+collected.size()+" sentences parsed and stored.";
  }


  /** if stored previously, read the sentences
  */
  public static Vector<Sentence> readEnglishSourceCodeSentencesFromFile()
  {
     Vector<Sentence> sentences = new Vector<Sentence>();

     File in = new File("SnowMailClient/Language/english_sentences.vec");
     if (!in.exists()) return sentences;

     try
     {
       Vector<Object> v = FileUtils.loadVectorFromFile(in);
       for(int i=0;i<v.size();i++)
       {
         Vector sv = (Vector) v.elementAt(i);
         Sentence se = new Sentence();
         se.createFromVectorRepresentation(sv);
         sentences.addElement(se);
       }
     }
     catch(Exception e)
     {
       e.printStackTrace();
     }

     return sentences;
  }

  /** is used to read the "english_sentences.vec" from the jarfile
    when the translation editor merge the language files with the
    sentences file.
  */
  public static Vector<Sentence> readEnglishSentencesVectorFromJarFile() throws Exception
  {
     Vector<Sentence> sentences = new Vector<Sentence>();
     ClassLoader cl = SentenceDictionary.class.getClassLoader();
     if(cl==null)
     {
       System.out.println("Class loader is null in ReadEnglishSentencesVectorFromJarFile ");
       // not found, maybe IDE mode ? not running from jar file
       return sentences; //ReadFromFile(language);
     }

     InputStream is = null;
     try
     {                 
        is = cl.getResourceAsStream("SnowMailClient/Language/english_sentences.vec");
        if(is==null)
        {
           System.out.println("ResourceAsStream is null for english_sentences.vec");
           return sentences;
        }
        Vector<Object> v = FileUtils.loadVector(is);


        for(int i=0;i<v.size();i++)
        {
          Vector sv = (Vector) v.elementAt(i);
          Sentence se = new Sentence();
          se.createFromVectorRepresentation(sv);
          sentences.addElement(se);
        }


        return sentences;
     }
     finally
     {
        if(is!=null)
        {
          try{is.close();} catch(Exception e){ e.printStackTrace();}
        }
     }
  }
  



  /** collect all strings called with Languge.Translate() in the sourcecode
      LIMITATION : actually not supported are:
      multiline ""+"" and comments in the sentence
      @return a vector of sentences
  */
  public Vector<Sentence> collectStringsToTranslateRecurse(File base, String baseString, StringBuffer warningBuffer)
  {
    Vector<Sentence> sentences = new Vector<Sentence>();

    //System.out.println("* "+base.getName());

    if(base.isFile())
    {
      if( base.getName().endsWith(".java"))
      {
        sentences.addAll(collectStringsToTranslate(base, baseString, warningBuffer));
      }
    }

    else if(base.isDirectory())
    {
      File[] files = base.listFiles();
      for(int i=0;i<files.length;i++)
      {
         sentences.addAll(collectStringsToTranslateRecurse(files[i], baseString, warningBuffer));
      }
    }
    return sentences;
  }


  /** @param sourceSentence is a sentence parsed in the sourcecode
    replace the \\n \\t and \\u codes found in the source code,
    but not double \ (\\\\)
    ### must also replace unicode chars... \u0000
  */
  private String interpretSourceStrings(final String sourceSentence)
  {
    String sent = sourceSentence;
    final char BS = '\\';

    int pos = -1;

    while(true)
    {
       pos = sent.indexOf(BS, pos+1);  // search for next single \, represented as \\ in string litteral (!)
       if(pos==-1) return sent; // no more command

       if(pos+1 >= sent.length()) return sent; // end of string reached

       // next char
       char cp1 = sent.charAt(pos+1);
       //System.out.println("pos="+pos+", cp1="+cp1);

          if(cp1=='"')       sent = sent.substring(0,pos)+"\""+sent.substring(pos+2);
          else if(cp1=='\'') sent = sent.substring(0,pos)+"'"+ sent.substring(pos+2);
          else if(cp1=='n')  sent = sent.substring(0,pos)+"\n"+sent.substring(pos+2);
          else if(cp1=='r')  sent = sent.substring(0,pos)+"\r"+sent.substring(pos+2);
          else if(cp1=='t')  sent = sent.substring(0,pos)+"\t"+sent.substring(pos+2);
          else if(cp1=='\\') sent = sent.substring(0,pos)+"\\"+sent.substring(pos+2);
          else if(cp1=='u')
          {
             // parse unicode

             //ensure we have four digits
             if(pos+6 >= sent.length()) return sent;
             String unic = sent.substring(pos+2, pos+6);
             try
             {
               //System.out.println(unic);
               int code = Integer.parseInt(unic);

               sent = sent.substring(0,pos)+((char) code)+sent.substring(pos+6);
             }                
             catch(NumberFormatException e)
             {
               // cannot parse unicode
               System.out.println("Cannot interpret unicode sequence in "+sent);
               return sent;
             }
          }
          else
          {
            System.out.println("Cannot interpret escape sequence in "+ sent);
          }
    }
  }

                             
  /** collect all strings called with Languge.Translate() in the sourcecode
      @return a vector of Sentence objects
  */
  public Vector<Sentence> collectStringsToTranslate(File file, String basePath, StringBuffer warningBuffer)
  {
    String relativeClassPath = file.getAbsolutePath().substring(basePath.length()+1);
    // avoid empty path
    if(relativeClassPath.length()==0) relativeClassPath = file.getAbsolutePath();
    

    Vector<Sentence> sentences = new Vector<Sentence>();
    FileInputStream fis = null;
    StringBuffer sb = new StringBuffer();
    try                    
    {                                
      fis = new FileInputStream(file);
      byte[] buffer = new byte[256];
      int read = 0;
      while((read=fis.read(buffer))!=-1)
      {
        sb.append(new String(buffer,0,read));
      }
    }
    catch(IOException e)     
    {
      e.printStackTrace();
    }
    finally
    {
      if(fis!=null) try{fis.close();} catch(Exception ee) { ee.printStackTrace();}
    }

    String text = sb.toString();
    int startLength = START.length();
    
    // Main loop !
    //

    int pos =  text.indexOf(START);
    while(pos!=-1)
    {  
      int linePos = getNumberOfReturnUpToPosition(text, pos);
      if(text.charAt( pos-1)=='"')
      {
         // This is the START string itself... appearing only once in this class !!
         System.out.println("*****************************************************   Found");
      }

      Sentence sent = this.parseSentence(text, pos+startLength, relativeClassPath, linePos);
      if(sent.getEndPosition()==-1)
      {
        // error !
        String relativeJavaPath = convertSystemPathToJavaPath(file.getAbsolutePath().substring(basePath.length()+1));

        // allow localisation from schmortopf output pane
        //
        String msg = "Language.Throwable: The sentence should be HARDCODED in Language.translate_() "
            + "\n\tat "+relativeJavaPath+" ("+file.getName()+":"+linePos+")\r\n";

        System.out.println(msg);
        warningBuffer.append("\n"+msg);

        // go to next sentence
        pos =  text.indexOf(START, pos+startLength);

      }
      else
      {

        sentences.addElement(sent);

        // test if number of arguments is OK.
        try
        {
           int na = Common.getNumberOfParametersInSentence(sent.getSentence());
        }
        catch(Exception exc)
        {
           String msg = "java.lang.Throwable: Bad parameter syntax "+exc.getMessage()
            + "\n\tat "+Common.convertPathToJavaClassPathSyntax(relativeClassPath)+" ("+file.getName()+":"+linePos+")\r\n";

           warningBuffer.append( "\nBad parameters in sentence="+sent.getSentence());
           warningBuffer.append( "\n"+msg);
        }

        // go to next sentence
        pos =  text.indexOf(START, sent.getEndPosition());

      }


    }
    return sentences;
  }


  /** parse the string in text at pos
      @return in the returned sentence, the position of the end is also present.
  */
  private Sentence parseSentence(String text, int from, String className, int line)
  {
     int start = text.indexOf("\"", from);
     if(start==-1)
     {
       return new Sentence("Error: no opening \" in sentence", className, line, -1);
     }     
     // find the end, ignore the \" 
     int end = start;   
     while(true)
     {
       end = text.indexOf("\"",end+1);
       if(end==-1)
       {
         return new Sentence("Error: no ending \" in sentence", className, line, -1);
       }  
       if(text.charAt(end-1)!='\\')
       {
         break;   
       } // else this is not a ", this is a \"
     }       
               
     String sent = text.substring(start+1, end);
     // convert the codes in characters (\n, \\...)
     sent = interpretSourceStrings(sent);
     
     // look if there is a + after the sentence
     int posPlus = text.indexOf('+', end);
     int posComa = text.indexOf(',', end);
     int posEndBracket = text.indexOf(')', end);
     int posEnd = posEndBracket;  // always present !
     if(posComa>=0 && posComa<posEndBracket) posEnd = posComa;

     if(posPlus>=0 && posPlus<posEnd)
     {
       //System.out.println(""+sent+" \t\t<" + text.substring(posPlus+1,posEnd ) + ">");
       // recurse
       Sentence s2 = parseSentence(text.substring(posPlus+1, text.length() ), 0, "", -1);
      // System.out.println("##########   Concatenation: <"+sent+"> + <"+s2.getSentence()+">   ##########");
       sent += s2.getSentence();     
       end  += s2.getEndPosition();

     }


     //System.out.println(sent);
     return new Sentence(sent, className, line, end);
  }   

  /** used to retrieve line number from absolute char position, needed for the dummy exception
     stacktrace      
  */
  public static int getNumberOfReturnUpToPosition(String content, int position)
  {
    int n = 1;  // first line has number 1;

    int retPos = -1;
    while( (retPos = content.indexOf("\n", retPos+1)) != -1)
    {
       if(retPos>position) break;
       n++;
    }       
    return n;                    
  }
                                
  /** replace / with .
  */
  public static String convertSystemPathToJavaPath(String sysPath)
  {                           
     String s = sysPath.replace('\\','.');
     s = s.replace('/','.');
     return s;
  }

                                                                                                                                     
  

  public static void main(String[] a)
  {
     StringBuffer warningBuffer = new StringBuffer();
                                                                                            
     System.out.println(                                                              
                        
       //parseWholeSourceAndSaveInFile(new File("c:/sources/other/mail/client"), warningBuffer)  // 811
       //parseWholeSourceAndSaveInFile(new File("E:/projects/mail/client/"), warningBuffer)        // home
       parseWholeSourceAndSaveInFile(new File("c:/proj/mail/client/"), warningBuffer)        // home
                             
     );                                      
     if(warningBuffer.length()>0)  
     {
       System.out.println("Warnings:"+warningBuffer.toString());
     }                 
                         
     // Tests        
     //Language.translate("ceci est un "+" test");
     Language.translate("ceci est un autre "
      +" test");                           
     //Leanguage.Translate("def %");
     //Leanguage.Translate("ghi %");
     //Leanguage.Translate("abc", "ppp"); 
     //new Throwable().printStackTrace();
  }   


} // SourceSentencesParser





















