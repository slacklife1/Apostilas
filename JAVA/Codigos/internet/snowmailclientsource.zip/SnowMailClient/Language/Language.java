package SnowMailClient.Language;


import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;

/** used to translate whole sentences appearing in the GUI.
   no intelligence here. The whole sentences must all be translated
   by a human beeing like you.
   All argument sentences are english sentences. They are normally
   available as french or deutsch translations.  
   
   Spaces at beginning and at end of phrases are ignored in the translations,
   they are generated at runtime.
   example   Translate("  Hello  ")  will translate "Hello" to "Bonjour" and
    return "   Bonjour   ".

   MAIN USAGE:

    + simply call  Language.TranslatE("Welcome in SnowMail") for every strings
    + there is a version with arguments.
        for a single argument, the string must contain a single %.
        for two arguments, the string must contain %1 and %2.

*/
public final class Language
{
  public static final String ENGLISH  = "English";
  public static final String FRANCAIS = "Francais";
  public static final String DEUTSCH  = "Deutsch";
  public static final String POLISH   = "Polish";

  //private static final String PropertyFile = "SnowMailClient/Language/Languages.properties";
  private static final String PropertyFile = "Languages.properties";
  
  //Data (not static)
  private SentenceDictionary dictionary = null;
  private String actualLanguage = ENGLISH; // default => no translation
  // this is the default
  private boolean readFromJar = true;
  
  // must be set prior to the first getInstance() !
  public static String baseDirectory = ".";

  // singleton
  private Language()  {  } // Constructor
  private static Language languageInstance = null;

  public Locale getLocale()     
  {
    if(actualLanguage==null) return Locale.ENGLISH;
    if(actualLanguage.equals(ENGLISH))  return Locale.ENGLISH;
    if(actualLanguage.equals(FRANCAIS)) return Locale.FRENCH;
    if(actualLanguage.equals(DEUTSCH))  return Locale.GERMAN;
    // default
    return Locale.ENGLISH;
  }

  private static String defaultLanguage = ENGLISH;
  public static void setDefaultLanguage(String language)
  {
     defaultLanguage = language;
  }

  /** get the single instance of this class
  */
  public static Language getInstance()
  {
    if(languageInstance==null)
    {
      // create a new instance and initialize it
      languageInstance = new Language();

      // used to read active language
      Properties prop = new Properties();
      File propFile = new File(baseDirectory, PropertyFile);
      System.out.println("Read language props in "+propFile+" ( base="+baseDirectory+")");
      if(propFile.exists())
      {
        FileInputStream fis = null;
        try        
        {
          prop.load(fis = new FileInputStream(propFile));
        }
        catch(Exception e)
        {
          e.printStackTrace(); 
        }                                                                               
        finally
        {
          if(fis!=null) try{ fis.close();} catch(Exception ee){}
        }
      }
      
      String lang = prop.getProperty("ActiveTranslationLanguage", defaultLanguage);
      // // so that it behaves as with Schmortopf version <= 1.2
      // per default, try to read language pack from jar first
      String readFromJarProp = prop.getProperty("ReadFromJar", "True");

      languageInstance.readFromJar = readFromJarProp.equals("True");
      languageInstance.setActualTranslation(lang, languageInstance.readFromJar);

      System.out.println("Read ini lang = "+lang);

    }
    return languageInstance;
  }

  /** return a list of the languages that are present in the jar file
    usually {French, deutsch}
  */
  public String[] getAvailableInternalLanguages()
  {                           
    return SentenceDictionary.getInternalAvailableTranslations();
  }

  public String[] getAvailableLanguages()
  {
    Vector<String> found = new Vector<String>();
    found.addElement(ENGLISH); // Always present, but never as file...

    File base = new File("SnowMailClient/Language");

    if(base.isDirectory() && base.exists())
    {
      File[] files = base.listFiles();
      for(int i=0; i<files.length; i++)
      {
        int pos = files[i].getName().toLowerCase().indexOf(".translation");
        if(pos!=-1)
        {
          found.addElement(files[i].getName().substring(0,pos));
        }
      }
    }
    return (String[])found.toArray(new String[found.size()]);
  }        
  
  public boolean getActualTranslationWasReadFromJarFile() { return readFromJar; }

  public String getActualTranslation() {return actualLanguage;}

                    
  /** set the language used from now to translate sentences
      and load the appropriate dictionary

      @param fromJarFile read it from jar file if true
  */
  public void setActualTranslation(String language, boolean fromJarFile)
  {
       

    actualLanguage = language;
    this.readFromJar = fromJarFile;

    // save properties
    saveProperties();


    if(actualLanguage.compareToIgnoreCase("english")==0)
    {
      dictionary = null;
    }
    else
    {
      try
      {
        if(fromJarFile)
        {
          dictionary = SentenceDictionary.readFromJarFile(language);
          if(dictionary==null)
          {
            dictionary = SentenceDictionary.readFromFile(language, true); // try to read embedded
          }
          //System.out.println("Language "+language+" read from jar file");
        }
        else
        {
          dictionary = SentenceDictionary.readFromFile(language, true); // try to read embedded
          System.out.println("Language "+language+" read from file");
        }
        //null if not found
      }
      catch(Exception e)
      {
        // occur in case of bad version
        JOptionPane.showMessageDialog(null, ""+e.getMessage()
          +"\nDelete the language file in Language/ or use a language file\ncompatible with the current Schmortopf version.", "Language pack error",
          JOptionPane.ERROR_MESSAGE);        
      }
    }
  }


  /** @return the ref of the actual dic of read it if it is not already loaded
   CAUTION: for english: return null becacuse english has no translation on english...
  */
  public SentenceDictionary getDictionaryFromFile(String language, boolean useEmbeddedInNotFound )
  {
    if(actualLanguage.equals(language)
     && readFromJar == false) return dictionary;

    try
    {
      SentenceDictionary dic = SentenceDictionary.readFromFile(language, useEmbeddedInNotFound);
      return dic;
    }
    catch(Exception e)
    {
      // not found...
      e.printStackTrace();
      return null;
    }
  }


  /** NO MORE NECESSARY, repaced with save properties
      Dictionaries are only stored from the language editor
  */
  public void save()
  {
  }


  /** save the actual settings and the sentence dictionary
      if not read from jar file
  */
  private void saveProperties()
  {
     // save properties
     //

     Properties prop = new Properties();
     prop.setProperty("ActiveTranslationLanguage", actualLanguage);
     prop.setProperty("ReadFromJar", (readFromJar?"True":"False"));
            
     File propFile = new File(baseDirectory, PropertyFile);
     System.out.println("Save language props in "+propFile);
     FileOutputStream fos = null;
     try
     {
       if(!propFile.getParentFile().exists())
       {
         propFile.getParentFile().mkdirs();
       }
       prop.store(fos = new FileOutputStream(propFile), "Schmortopf Language Settings");
     }
     catch(Exception e)
     {
       e.printStackTrace();
     }
     finally
     {
       if(fos!=null) try{ fos.close();} catch(Exception ee){}
     }

     
     /*
     // Save sentences
     //

     // DO NOT save english
     if(actualLanguage.compareToIgnoreCase("english")==0) return;

     // DO NOT SAVE when read in jar file
     if(!readFromJar )
     {
        // needs an Language directory...
        File path = new File("Language");
        if(!path.exists()) path.mkdirs();

        if(dictionary!=null)
        {
          try
          {
            dictionary.saveToFile();
          }
          catch(Exception e)
          {
            e.printStackTrace();
          }
        }

     }
     
     */


  }


  /** @return the sentence in the actual language.
      @param sentence is directly search in the english database
        and translated
      THIS IS THE BASIC TRANSLATION METHOD

      if not found, return the original string, but add
      a request for later translation
  */
  public static String translate(String sentence)
  {
     if(getInstance().actualLanguage.compareToIgnoreCase("english")==0) return sentence;
     if(getInstance().dictionary!=null)
     {                  
        return getInstance().dictionary.getTranslatedSentence(sentence);
     }
     else
     {
        return sentence;
     }
  }


  /** @param sentenceWithArgument the arg is a % somewhere in text that is replaced
        by the arg (typical example: a fileName)
  */
  public static String translate(String _sentenceWithArgument, String arg)
  {
    String sentenceWithArgument = translate(_sentenceWithArgument);

    StringBuffer sb = new StringBuffer(sentenceWithArgument);
    int pos = sentenceWithArgument.indexOf("%");
    if(pos==-1)
    {
      // allow us to correct this
      System.out.println("***************************************************");
      System.out.println("Invalid sentence for translation (should have a % for the replacement)");
      System.out.println(" sentence = "+_sentenceWithArgument);
      System.out.println(" arg = "+ arg);
      System.out.println("***************************************************");

      return sentenceWithArgument+" "+arg;
    }

    return sb.replace(pos,pos+1, arg).toString();
  }

  /** @param sentenceWithArgument the args are %1 and %2 somewhere in text that is replaced
        by the arg (typical example: a fileName)
  */
  public static String translate(String _sentenceWithArgument, String arg1, String arg2)
  {
    String sentenceWithArgument = translate(_sentenceWithArgument);
    StringBuffer sb = new StringBuffer(sentenceWithArgument);
    
    // first argument replacement
    int pos1 = sentenceWithArgument.indexOf("%1");
    if(pos1==-1)
    {
      System.out.println("***************************************************");
      System.out.println("Invalid sentence for translation (should have a %1 for the first replacement)");
      System.out.println(" sentence = "+_sentenceWithArgument);
      System.out.println(" arg1 = "+ arg1);
      System.out.println(" arg2 = "+ arg2);
      System.out.println("***************************************************");

      return sentenceWithArgument+" "+arg1+" "+arg2;
    }

    sb = sb.replace(pos1,pos1+2, arg1);

    // second argument replacement
    sentenceWithArgument = sb.toString();
    int pos2 = sentenceWithArgument.indexOf("%2");
    if(pos2==-1)
    {
      System.out.println("***************************************************");
      System.out.println("Invalid sentence for translation (should have a %2 for the first replacement)");
      System.out.println(" sentence = "+_sentenceWithArgument);       
      System.out.println(" arg1 = "+ arg1);
      System.out.println(" arg2 = "+ arg2);
      System.out.println("***************************************************");

      return sb.toString()+" "+arg2;
    }

    sb = sb.replace(pos2,pos2+2, arg2);

    return sb.toString();
  }

     
} // Language






























