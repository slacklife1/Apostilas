package SnowMailClient.Language;

import snow.utils.storage.*;
import java.util.*;


/** this is the model for a sentence,
    with his translation in a foreign language
    or "" if not already translated
*/
public final class Sentence implements Vectorizable
{
  private String sentence;   
  // the translation ("" if not made)
  private String translation = "";                                

  // where it was parsed ("" if not found during a parse operation)
  // useful to locate the translation and guess semantic
  // ### stores only the first occurence source...
  private String foundInClass = "";
  private int linePosition = -1;
  private int endPosition = -1; // used during parsing

  // number of times this string has been called, give a rough idea of its importance...
  // (bad)
  private int callCount = 0;


  // a flag to detect old unused sentences during merge operation
  public boolean visited = false;

/*  public Sentence(String sentence)
  {
     this.sentence = sentence;
  }*/

  public Sentence(String sentence, String _foundInClass, int linePosition, int endPosition)
  {
     this.sentence = sentence;
     this.foundInClass = _foundInClass;
     this.linePosition = linePosition;
     this.endPosition = endPosition;
  }

                      
  public String getSentence()      { return sentence;     }
  public String getTranslation()   { return translation;  }
  public String getLocationClass() { return foundInClass; }
  public int getCallCount()        { return callCount; }
  public int getLinePosition()     { return linePosition; }
  public int getEndPosition()     { return endPosition; }


  public void setTranslation(String translation) { this.translation = translation; }
  public void setLocationClass(String loc, int line)
  {
    foundInClass = loc;
    linePosition = line;
  }
  
  public boolean hasTranslation() { return !translation.equals(""); }
  public void incrementCallCount() { callCount++; }

  public boolean equals(String s)
  {
    return s.equals(sentence);
  }


  // Vectorization
  //
  public Sentence(){}
  public Vector<Object> getVectorRepresentation() //throws Exception
  {
     Vector<Object> v = new Vector<Object>();
     v.addElement(3);        // 0. version
     v.addElement(sentence);
     v.addElement(translation);
     v.addElement(foundInClass);
     v.addElement(linePosition);
     v.addElement(callCount);
     return v;
  }
                          
  public void createFromVectorRepresentation( Vector<Object> v )
  {          
    int version = (Integer) v.elementAt(0);

    if(version==3)
    {
      sentence = (String) v.elementAt(1);
      translation = (String) v.elementAt(2);
      foundInClass = (String) v.elementAt(3);
      linePosition = (Integer) v.elementAt(4);
      callCount = (Integer) v.elementAt(5);
    }   
    sentence=sentence.trim();
    translation=translation.trim(); 
  }
             
} // Sentence
