package SnowMailClient.Language.Editor;

import SnowMailClient.Language.*;
import snow.SortableTable.*;
import snow.utils.gui.*;

import SnowMailClient.SnowMailClientApp;

import java.awt.*;
import java.awt.event.*;
import javax.swing. *;
import javax.swing.event.*;
import javax.swing.table.*;
import java.util.*;
import java.io.*;
import java.net.*;           

              
/** To edit the application sentences                               
*/              
public class TranslationEditor extends JFrame implements ListSelectionListener
{
  private boolean standalone = false;
  
  private transient SentenceDictionary actualDictionary = null;          
  private transient SentenceDictionary helpTranslation = null;

  private final SentencesTableModel sentencesTableModel = new SentencesTableModel();
  SortableTableModel sortableTableModel;

  private final JTextArea textEnglish    = new JTextArea("", 4, 70);
  private final JTextArea textTranslated = new JTextArea("", 5, 70);

  private final JTable sentencesTable = new JTable();
  private final SearchStringTableCellRenderer searchStringTableCellRenderer = new SearchStringTableCellRenderer();

              
  public static final String TITLE = "Translator" + " 3.0 ";

  private final JLabel translationLabel = new JContrastLabel("Translation");
  private JButton saveTranslation;

  // another language                   
  private final JTextArea textAlternateTranslated = new JTextArea("", 4, 70);
  private final JLabel alternateTranslationLabel = new JContrastLabel("Translation in the help language");
  JPanel panAlternateText;

  TranslationEditor ref = null;

  String[] languagesNamesFoundOnDisk = null;
                                                                                                   
  public TranslationEditor()    
  {
    super();
    ref = this;
              
    // list of languages found on the disk in Language/
    languagesNamesFoundOnDisk = Language.getInstance().getAvailableLanguages();
    
    

    this.setTitle( TITLE );
    getContentPane().setLayout(new BorderLayout());

    JPanel trPanel = new JPanel();
    trPanel.setLayout(new BoxLayout(trPanel, BoxLayout.Y_AXIS));
                                             
    JScrollPane jsp = new JScrollPane(sentencesTable);

    JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
           jsp, trPanel);       
    splitPane.setOneTouchExpandable(true);



    getContentPane().add(splitPane, BorderLayout.CENTER);



    JPanel panText = new JPanel(new BorderLayout());
    trPanel.add(panText);
    panText.add(new JContrastLabel("English original sentence:"), BorderLayout.NORTH);
    panText.add(wrapLeft(new JScrollPane(textEnglish),20), BorderLayout.CENTER);
                          
    panAlternateText = new JPanel(new BorderLayout());

    trPanel.add(panAlternateText);
    panAlternateText.add(alternateTranslationLabel, BorderLayout.NORTH);
    panAlternateText.add(wrapLeft(new JScrollPane(textAlternateTranslated),20), BorderLayout.CENTER);
    textAlternateTranslated.setEditable(false);

    textEnglish.setBackground(UIManager.getColor("Label.background"));
    textAlternateTranslated.setBackground(UIManager.getColor("Label.background"));
  
    createMenu();

    textEnglish.setEditable(false);

    JPanel panTransl = new JPanel(new BorderLayout());
    trPanel.add(panTransl);                       
    panTransl.add(translationLabel, BorderLayout.NORTH);
    panTransl.add(wrapLeft(new JScrollPane(textTranslated),20), BorderLayout.CENTER);

    saveTranslation = new JButton( "Save Translation");
    saveTranslation.setBackground(Color.orange);
    JPanel btPanel = new JPanel();
    btPanel.add(saveTranslation);
    panTransl.add(btPanel, BorderLayout.SOUTH);
               
    saveTranslation.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
         saveActualTranslation();
      }
    });


    JPanel northPanel = new SnowBackgroundPanel(new FlowLayout(FlowLayout.LEFT,5,5));

    getContentPane().add(northPanel, BorderLayout.NORTH);  
                                                                 

    // load parsed sentences from the file in the language directory
    final Vector englishSentences = SourceSentencesParser.readEnglishSourceCodeSentencesFromFile();
    System.out.println("Found english sentences: "+englishSentences.size());

    if(englishSentences.size()==0)
    {
       System.out.println("No sentences found in SnowMail/Language/english_sentences.vec, trying to load from jar");

       // load parsed sentences from the jar file
       try
       {
         englishSentences.addAll( SourceSentencesParser.readEnglishSentencesVectorFromJarFile() );
       }
       catch(Exception e)
       {
       }

       if(englishSentences.size()==0)
       { 
         JOptionPane.showMessageDialog(ref,
           "The original english sentences to translate were not found on your system."
           +"\nPlease parse the source code with the utility SnowMailClient/Language/SourceSentencesParserEditor.java"
           +"\nand install the generated english_sentences.vec file in the directory SnowMailClient/Language/"
           +"\nlocated in the same directory as SnowMailClient.jar.",
           "The file english_sentences.vec is missing.", JOptionPane.ERROR_MESSAGE);
       }
    }            
                      

    Vector toShow = updateAllDictionaries(englishSentences);

    if(toShow.size()==0)
    {
       JOptionPane.showMessageDialog(ref,
          "There are no sentences to translate, in any language");
    }




    final JComboBox langCB = new JComboBox((String[]) toShow.toArray(new String[toShow.size()]));
    northPanel.add(new JContrastLabel("Language "));
    northPanel.add(langCB);              
    langCB.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        if(actualDictionary!=null)
        {
          try
          {
             System.out.println("saving...");
             actualDictionary.saveToFile();
          }
          catch(Exception ee)
          {
             ee.printStackTrace();
          }
        }
        else
        {
          System.out.println("actual dic = null");
        }


        actualDictionary = Language.getInstance().getDictionaryFromFile( (String) langCB.getSelectedItem(), false );



        if(actualDictionary==null)
        {
           sentencesTable.setEnabled(false);
           setTitle( TITLE + " [No dictionary loaded]");
        }
        else
        {
           boolean isEditable = actualDictionary.getIsEditable();
           textTranslated.setEditable(isEditable);
           saveTranslation.setVisible(isEditable);

           if(!isEditable)
           {
              File dicFile = new File("Language/"+ (String) langCB.getSelectedItem() +".translation");
              if(dicFile.exists() && !dicFile.canWrite())
              {
                JOptionPane.showMessageDialog(ref, "The language file "+dicFile.getAbsolutePath()+
                  "is not editable\nbecause the file flag is read-only.", "Warning", JOptionPane.WARNING_MESSAGE);
              }
              else
              {
                JOptionPane.showMessageDialog(ref, "The language is not editable",
                  "Warning", JOptionPane.WARNING_MESSAGE);
              }
           }

           setTitle(TITLE + " ["+actualDictionary.getFileName()+"] "+actualDictionary.getNumberOfTranslatedSentences()+" translated words");
           sentencesTable.setEnabled(true);

           sentencesTableModel.setDictionary(actualDictionary, isEditable);
        }
      }
    });

    sortableTableModel = new SortableTableModel(sentencesTableModel);
    sentencesTable.setModel(sortableTableModel);
    sortableTableModel.installGUI(sentencesTable);     
    int fontSize = UIManager.getFont("Label.font").getSize();
    sentencesTable.getColumnModel().getColumn(0).setPreferredWidth(fontSize*12);
    sentencesTable.getColumnModel().getColumn(1).setPreferredWidth(fontSize*12);
    
    
    AdvancedSearchPanel sp = new AdvancedSearchPanel("Search:", null, sortableTableModel, true);
    northPanel.add(sp);


    textEnglish.addFocusListener(new FocusAdapter()
    {
      @Override public void focusGained(FocusEvent e)
      {
         textEnglish.setSelectionStart(0);
         textEnglish.setSelectionEnd(textEnglish.getText().length());
      }
    });


    this.addWindowListener( new WindowAdapter()
     {
       @Override public void windowClosing(WindowEvent e)
       {
           terminateFrame();                     
       }
       @Override public void windowClosed(WindowEvent e)
       {
           terminateFrame();
       }
     }
    );


    sentencesTable.getSelectionModel().addListSelectionListener(this);
    sentencesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    //sentencesTable.setDefaultRenderer(String.class, searchStringTableCellRenderer);



    //final Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
    splitPane.setDividerLocation(300);

    this.setSize(900, 700);
    this.setLocationRelativeTo(null);
    this.setVisible(true);

    // select first avaiable language for traduction
    if(langCB.getModel().getSize()>0)
    {
      langCB.setSelectedIndex(0);
    }

  } // Constructor

  /** menubar
  */
  private void createMenu()
  {
     this.setJMenuBar(new JMenuBar());
     JMenu menuFile = new JMenu("File");
     this.getJMenuBar().add(menuFile);

     JMenuItem newLanguage = new JMenuItem("Create New Language Pack");
     menuFile.add(newLanguage);
     newLanguage.addActionListener(new ActionListener()
     {                  
      public void actionPerformed(ActionEvent e)
      {
        String rep = JOptionPane.showInputDialog(ref, "Enter the name of the new language");
        if(rep!=null)
        {
          Language.getInstance().setActualTranslation(rep, false);
          SentenceDictionary sd = Language.getInstance().getDictionaryFromFile(rep, false);
          try
          {
            sd.saveToFile();
            JOptionPane.showMessageDialog(ref, "You must restart the translation editor to see the new language");
          }
          catch(Exception ex)
          {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(ref, "Error: "+ex.getMessage());
          }
        }
      }             
     });


     JMenuItem importWords = new JMenuItem("Import translated words from another language pack");
     if(SnowMailClientApp.debug)
     {
       menuFile.addSeparator();
       menuFile.add(importWords);
     }
     importWords.addActionListener(new ActionListener()
     {                  
      public void actionPerformed(ActionEvent e)
      {
        JFileChooser fileChooser = new JFileChooser("c:/proj/mail/client");
        int rep = fileChooser.showOpenDialog(TranslationEditor.this);

        if(rep==JFileChooser.APPROVE_OPTION)
        {
          try
          {
             File file = fileChooser.getSelectedFile();                                                                         
             SentenceDictionary sd = SentenceDictionary.ReadFromFile_ZIPPED(file);
             System.out.println("Language read="+sd.getLanguage());
             System.out.println("#sentences=" + sd.getNumberOfSentences()
                             +", #translated=" +sd.getNumberOfTranslatedSentences());

             importSentencesFromAnotherTranslation(sd);
          }
          catch(Exception ex)
          {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(ref, "Error: "+ex.getMessage());
          }
        }
      }
     });         

     JMenuItem quit = new JMenuItem("Quit");
     menuFile.addSeparator();
     menuFile.add(quit);
     quit.addActionListener(new ActionListener()
     {
      public void actionPerformed(ActionEvent e)
      {
        terminateFrame();
      }
     });


     JMenu menuLang = new JMenu("Translation Help Language");
     this.getJMenuBar().add(menuLang);
     ButtonGroup bg = new ButtonGroup();

     int act=-1;
     for(int i=0; i<this.languagesNamesFoundOnDisk.length; i++)
     {
        String at = Language.getInstance().getActualTranslation();
        JRadioButtonMenuItem lmi = new JRadioButtonMenuItem(
           languagesNamesFoundOnDisk[i],
           at.equals(languagesNamesFoundOnDisk[i]));

        if(at.equals(languagesNamesFoundOnDisk[i])) act = i;

        bg.add(lmi);
        menuLang.add(lmi);
        final int ii=i;
        lmi.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
            helpTranslation = Language.getInstance().getDictionaryFromFile(languagesNamesFoundOnDisk[ii], true);
          }
        });                                             
     }

     if(act!=-1)
     {
        helpTranslation = Language.getInstance().getDictionaryFromFile(languagesNamesFoundOnDisk[act], true);
     }

     JMenu menuUtils = new JMenu("Utilities");
     this.getJMenuBar().add(menuUtils);
     
     JMenuItem viewTextOfAllSentences = new JMenuItem("View text of all translated sentences");
     menuUtils.add(viewTextOfAllSentences);
     viewTextOfAllSentences.addActionListener(new ActionListener()
     {
      public void actionPerformed(ActionEvent e)
      {
        JTextArea ta = new JTextArea();
        if(actualDictionary!=null)
        {
          ta.append(actualDictionary.getStringOfAllTranslatedSentences());
        }

        JDialog dialog = new JDialog(TranslationEditor.this, "All translated sentences", false);
        dialog.getContentPane().setLayout(new BorderLayout());
        dialog.getContentPane().add(new JScrollPane(ta), BorderLayout.CENTER);
        dialog.setSize(400,600);

        CloseControlPanel ccp = new CloseControlPanel(dialog, false, true, "Close");
        dialog.getContentPane().add(ccp, BorderLayout.SOUTH);

        dialog.setVisible(true);
      }
     });

  }


  private void importSentencesFromAnotherTranslation(SentenceDictionary importDic)
  {
     Vector<Sentence> allActualSentences = actualDictionary.getAllSentences();
     Vector<Sentence> sentencesThatHasTranslationsInImport = new Vector<Sentence>();
     for(int i=0; i<allActualSentences.size(); i++)
     {
        Sentence s = (Sentence) allActualSentences.elementAt(i);
        String sent = s.getSentence();
        if(   !actualDictionary.hasTranslatedSentence(sent)
           && importDic.hasTranslatedSentence(sent))
        {
           sentencesThatHasTranslationsInImport.add(s);
        }
     }

     for(int i=0; i<sentencesThatHasTranslationsInImport.size(); i++)
     {
        Sentence s = (Sentence) sentencesThatHasTranslationsInImport.elementAt(i);
        String sent = s.getSentence();
        actualDictionary.addTranslation(
           sent, importDic.getTranslatedSentence(sent));
     }
                  
  }


  /** update all the dictionaries with the new words and return a list of
     names of valid dictionaries
  */
  private Vector updateAllDictionaries(Vector<Sentence> englishSentences)
  {
    // only show languages for which a translation is required and ignore english
    // that don't require a translation
    Vector<String> languagesNames = new Vector<String>();
    for(int i=0; i<languagesNamesFoundOnDisk.length; i++)
    {
       String langName = languagesNamesFoundOnDisk[i];
       if(!langName.equals(Language.ENGLISH))
       {
          SentenceDictionary sd = Language.getInstance().getDictionaryFromFile(langName, false);
          if(sd!=null)
          {
             languagesNames.addElement(langName);

             if(sd.getIsEditable())
             {
                // only if the list is not empty
                if(englishSentences.size()>0)
                {
                  sd.updateSentencesFromSource(englishSentences);

                  // save
                  try
                  {
                    sd.saveToFile();
                  }
                  catch(Exception e)
                  {
                    e.printStackTrace();
                  }
                }
             }
             else
             {
                System.out.println("No updates performed for "+langName+", file not existing or not editable");
             }
          }
       }
    }
    return languagesNames;
  }


  /** list selection changed
  */           
  public void valueChanged(ListSelectionEvent e)
  {                   
    //### ask to save actual translation, if required
    int sel = sentencesTable.getSelectedRow();


    if(sel!=-1 && actualDictionary!=null)
    {
       int pos = sortableTableModel.getIndexInUnsortedFromTablePos(sel);
       Sentence sent = sentencesTableModel.getSentenceAt(pos); 

       String eng = sent.getSentence();
       String tra = sent.getTranslation();
       String classLocation = sent.getLocationClass();
       int linePos = sent.getLinePosition();

       try
       {
          int na = Common.getNumberOfParametersInSentence(eng);
       }
       catch(Exception ee)
       {
          JOptionPane.showMessageDialog(this, ee.getMessage(), "Bad arguments", JOptionPane.WARNING_MESSAGE);
       }

       textEnglish.setText(eng);

       //no influence... ???   
       textEnglish.setSelectionStart(0);
       textEnglish.setSelectionEnd(eng.length());
       //textEnglish.requestFocus();

       textTranslated.setText(tra);
       //textTranslated.requestFocus();

       if(helpTranslation!=null)
       {
         String helpTr = helpTranslation.getTranslatedSentence(eng);
         textAlternateTranslated.setText(helpTr);
       }
       else
       {
         textAlternateTranslated.setText("");
       }

    }
    else
    {    
       textEnglish.setText("");
       textTranslated.setText("");
       //locationTA.setText("");
       textAlternateTranslated.setText("");
    }
  }


  /** user pressed the save button
  */
  private void saveActualTranslation()
  {
      String to = textEnglish.getText();
      String tr = textTranslated.getText();

      // ignore if any is blank
      if(to.equals("") || tr.equals("")) return;

      if(actualDictionary!=null)
      {
         int ne=-1;
         try
         {
            ne = Common.getNumberOfParametersInSentence(to);
         }
         catch(Exception ee)
         {
            // already tested ...JOptionPane.showMessageDialog(ref, e.getMessage());
         }
         int nt=-1;
         try
         {
            nt = Common.getNumberOfParametersInSentence(tr);
            if(nt!=ne) throw new Exception(
                  "Translated sentence has not the same number of parameters as the original sentence."
                + "\nOrignal has "+ne+" and translated has "+nt
              );
         }
         catch(Exception ee)
         {
            JOptionPane.showMessageDialog(this,
               "Error: "+ ee.getMessage());

            return;
            //if(rep!= JOptionPane.OK_OPTION) return;
         }


         // ok,save
         System.out.println("add translation "+to+" => "+tr);
         final int sr = sentencesTable.getSelectedRow();     

         actualDictionary.addTranslation(to, tr);


         EventQueue.invokeLater(new Runnable()
         {
           public void run()
           {
              if(sr<sentencesTable.getRowCount())
              {
                sentencesTable.getSelectionModel().setSelectionInterval(sr, sr);                         
              }           
              
              if(actualDictionary!=null)
              {
                setTitle(TITLE + " ["+actualDictionary.getFileName()+"] "+actualDictionary.getNumberOfTranslatedSentences()+" translated words");
              }
           }
         });

         
      }
  }       
                       
                       



  
  
  private void terminateFrame()                                                                  
  {
     if(actualDictionary!=null)
     try
     {
       actualDictionary.saveToFile();
     }
     catch(Exception ee)
     {
       ee.printStackTrace();
     }
     

     //Language.GetInstance().saveActualLanguageSentences();

     if(standalone) 
     {
       System.exit(0);
     }
     else
     {
       setVisible(false);
     }
  }
                                                                             
                                                                             
  /** load an ImageIcon, either in the jar file (during the normal execution)            
  *   or in the source path, during the development.
  */
  public static synchronized ImageIcon loadImageIcon(String name)
  {
    ClassLoader cl = TranslationEditor.class.getClassLoader();

    if(cl==null)  
    {                                                    
       System.out.println("ERROR: class loader is null"); 
       return null;
    }
                  
    URL url = cl.getResource(name);
    if(url!=null)
    {
       // in the jar and with jnlp
       return new ImageIcon(url);
    }
    else
    {
       url = cl.getResource("Language/"+name);
       if(url!=null)
       {
          // works in the IDE mode
          return new ImageIcon(url);
       }
       else
       {
          System.out.println("URL is null, can't find image "+name);
          return null;
       }
    }

  }



  private JPanel wrapLeft(Component comp,int hgap)
  {
    JPanel pan= new JPanel(new FlowLayout(FlowLayout.LEFT,hgap,0));
    pan.add(comp);
    return pan;
  }


  public static void main(String[] a)
  {
     //Language.GetInstance().setActualTranslation("LuzernerSchwytzerdutch");
     EventQueue.invokeLater(new Runnable(){public void run(){
        TranslationEditor te = new TranslationEditor();                                                                         
        te.standalone = true;
     }});

  }


} // TranslationEditor












































