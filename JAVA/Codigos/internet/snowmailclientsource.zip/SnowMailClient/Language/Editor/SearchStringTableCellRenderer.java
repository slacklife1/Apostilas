package SnowMailClient.Language.Editor;

import java.util.*;
import javax.swing.table.*;
import javax.swing.*;
import java.awt.*;

public final class SearchStringTableCellRenderer extends DefaultTableCellRenderer
{

  public SearchStringTableCellRenderer()
  {
  } // Constructor


  String searchString = "";
  public void setSearchstring(String s)
  {
    searchString = s.toUpperCase();
  }                        
           
           
  public Component getTableCellRendererComponent(JTable table, Object value,
                                                 boolean isSelected, boolean hasFocus,
                                                 int row, int column)
  {
    int fs = UIManager.getFont("Label.font").getSize();
    setBorder( BorderFactory.createEmptyBorder(fs/10,fs/2,fs/10,fs/4) );
    String strValue = (String) value;

    setIcon(null);
    setText( (value != null) ? value.toString() : "");
    setHorizontalAlignment(JLabel.LEFT);


    if (isSelected)
    {
       super.setForeground(table.getSelectionForeground());
       super.setBackground(table.getSelectionBackground());
    }
    else
    {
       if(row%2==0)
       {
          setBackground(new Color(0,0,117, 10));
       }
       else
       {
          setBackground(Color.white);
       }
    }

    if(searchString.length() >0 && strValue.toUpperCase().indexOf(searchString)!=-1)
    {	
      if (isSelected)
      {
        setBackground(table.getSelectionBackground().brighter());
      }
      else
      {
        setBackground(new Color(220,220,70,150));
      }
    }

    return(this);
  }

} // DefaultTableCellRenderer










