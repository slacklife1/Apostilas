package SnowMailClient.Language.Editor;

import snow.SortableTable.*;
import SnowMailClient.Language.*;

import java.util.*;
import java.util.regex.*;
import java.awt.event.*;
import javax.swing.event.*;


/** used to display sentences for editing
*/                
public final class SentencesTableModel extends FineGrainTableModel implements ChangeListener 
{
  final static int COLUMN_SENTENCE    = 0;
  final static int COLUMN_TRANSLATION = 1;
  final static int COLUMN_SOURCEFILE  = 2;
  final static int COLUMN_SOURCELINE  = 3;

                                
  final private Vector<Sentence> sentences = new Vector<Sentence>();
  private transient SentenceDictionary  actualDic;
  
  boolean editable = true;

  public SentencesTableModel()
  {

  } // Constructor

  public void setDictionary(SentenceDictionary dic, boolean editable)
  { 
    this.editable = editable;
    if(actualDic!=null) actualDic.removeChangeListener(this);

    actualDic = dic;
    sentences.removeAllElements();
    //
    Vector<Sentence> v = dic.getAllSentences();
    for(int i=0; i<v.size(); i++)
    {
      sentences.addElement(v.elementAt(i));
    }

    this.fireTableDataChanged();

    dic.addChangeListener(this);

  }

  // called when actualDic changed
  public void stateChanged(ChangeEvent e)
  {
    fireTableDataChanged(); 
  }

  public String getColumnName(int col)
  {
     if(col==COLUMN_SENTENCE) return "English";
     if(col==COLUMN_TRANSLATION) return "Translation";
     if(col==COLUMN_SOURCEFILE) return "Found in source";     
     return "?";
  }

  public Sentence getSentenceAt(int pos)
  {
     return (Sentence) sentences.elementAt(pos);
  }

   public int getColumnCount() { return 3; }
   public int getRowCount() { return sentences.size(); }


   public boolean isCellEditable(int rowIndex, int columnIndex)
   {
      return false;
   }

   public Object getValueAt(int row, int col)
   {
      Sentence s = (Sentence) sentences.elementAt(row);

      if(col==COLUMN_SENTENCE)
      {
         return s.getSentence();
      }
      else if(col==COLUMN_TRANSLATION)
      {
         return s.getTranslation();
      }
      else if(col==COLUMN_SOURCEFILE)
      {
         int line=s.getLinePosition();
         String loc =s.getLocationClass();
         if(loc.equals("")) return "";
         return loc+" : "+(line==-1 ? "?" : ""+line);
      }
      else if(col==COLUMN_SOURCELINE)
      { 
         return ""+ s.getLinePosition();
      }
      return "?";
   }

   public void setValueAt(Object aValue, int rowIndex, int columnIndex)
   {  
    // not editable                           
   }


   public Class getColumnClass ( int column )
   {
      Object obj = getValueAt ( 0, column );
      return obj.getClass ();
   }

   public int compareForColumnSort(int pos1, int pos2, int col)
   {
      Sentence s1 = (Sentence) sentences.elementAt(pos1);
      Sentence s2 = (Sentence) sentences.elementAt(pos2);

      if(col==COLUMN_SENTENCE)
      {
         return s1.getSentence().compareToIgnoreCase(s2.getSentence());
      }
      else if(col==COLUMN_TRANSLATION)
      {
         return s1.getTranslation().compareToIgnoreCase(s2.getTranslation());
      }               
      else if(col==COLUMN_SOURCEFILE)
      {
         return s1.getLocationClass().compareToIgnoreCase(s2.getLocationClass());
      }
      else if(col==COLUMN_SOURCELINE)
      {
         int l1 = s1.getLinePosition();
         int l2 = s2.getLinePosition();
         if(l1==l2) return 0;
         if(l1<l2) return -1;
         return 1;
      }
      return 0;
   }

/*   public boolean hitForTextSearch(int row, String txt, Pattern p)
   {
      String upt = txt.toUpperCase();      
      Sentence s = (Sentence) sentences.elementAt(row);           
      
      if(s.getSentence().toUpperCase().indexOf(upt)!=-1) return true;
      if(s.getTranslation().toUpperCase().indexOf(upt)!=-1) return true;  
                                 
      return false;
   } */            



} // SentencesTableModel
