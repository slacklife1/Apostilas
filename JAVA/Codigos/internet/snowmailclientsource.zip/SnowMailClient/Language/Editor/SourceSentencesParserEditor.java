package SnowMailClient.Language.Editor;


import SnowMailClient.Language.*;
import SnowMailClient.utils.storage.*;
import snow.utils.gui.*;


import java.awt.*;
import java.awt.event.*;
import javax.swing. *;
import javax.swing.event.*;
import javax.swing.table.*;                                  
import java.util.*;
import java.io.*;
import java.net.*;

                                                   
public final class SourceSentencesParserEditor extends JFrame
{
  final JTextField sourcePathTF = new JTextField("c:/projects/mail/client", 28);
  final JButton parseButton;

  public SourceSentencesParserEditor()
  {
     super("Source Translation Parser 1.0");
     getContentPane().setLayout(new BorderLayout());

     JPanel inputPanel = new JPanel(new GridLayout(1,2));
     getContentPane().add(inputPanel, BorderLayout.CENTER);
     inputPanel.add(new JLabel("SnowMail source path:   "));
     inputPanel.add(sourcePathTF);
                              
     JPanel controlPanel = new JPanel(new FlowLayout());
     getContentPane().add(controlPanel, BorderLayout.SOUTH);
                                                    
     JButton closeButton = new JButton("Close");
     closeButton.setBackground(Color.orange);
     controlPanel.add(closeButton);
     closeButton.addActionListener(new ActionListener()                                      
     {
       public void actionPerformed(ActionEvent e)
       {
          terminateFrame();
       }
     });

     parseButton = new JButton("Parse");
     parseButton.setBackground(Color.orange);
     controlPanel.add(parseButton);
     parseButton.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       {
         Thread t = new Thread()
         {
           public void run()
           {
             parseSource();
           }
         };
         t.setPriority(Thread.MIN_PRIORITY);
         t.start();
       }
     });


     this.addWindowListener( new WindowAdapter()
      {
        @Override public void windowClosing(WindowEvent e)
        {
            terminateFrame();
        }
        @Override public void windowClosed(WindowEvent e)
        {
            terminateFrame();
        }
      }
     );


     pack();
     this.setLocationRelativeTo(null);
     setVisible(true);
                    
  } // Constructor    
  

  private void parseSource()
  {
    parseButton.setEnabled(false);
    ProgressModalDialog pw = new ProgressModalDialog(this, "Parsing source", false);
    pw.setLocationRelativeTo( this );
    pw.start();

    try
    {
      String sourcePath = sourcePathTF.getText();

      File sourceBase = new File(sourcePath);
      if(!sourceBase.exists()) throw new Exception("Source path "+sourceBase.getAbsolutePath()+" don't exist.");
      StringBuffer warningBuffer = new StringBuffer();
      String terminationMessage = SourceSentencesParser.parseWholeSourceAndSaveInFile(sourceBase, warningBuffer);
      // terminated...
      pw.setVisible(false);

      if(warningBuffer.length()>0)
      {                                    
         System.out.println("WARNING:"+warningBuffer.toString());
         JTextArea ta = new JTextArea(warningBuffer.toString().substring(1));
         JOptionPane.showMessageDialog(this, new JScrollPane(ta), "Warning", JOptionPane.WARNING_MESSAGE);
      }                        

      JOptionPane.showMessageDialog(this, terminationMessage, "Parse completed", JOptionPane.INFORMATION_MESSAGE);
      terminateFrame();
    }
    catch(Exception e)
    {
      //e.printStackTrace();
      JOptionPane.showMessageDialog(this, e.getMessage(), "Error occured while parsing", JOptionPane.ERROR_MESSAGE);
    }
    finally
    {
      parseButton.setEnabled(true);
      pw.closeDialog();
    }
  }                            


  private boolean standalone = false;
  private void terminateFrame()
  {
    if(standalone) System.exit(0);
  }


  public static void main(String[] a)
  {
     SourceSentencesParserEditor te = new SourceSentencesParserEditor();
     te.standalone = true;  // => exit with system.exit
  }


} // SourceSentencesParserFrame
