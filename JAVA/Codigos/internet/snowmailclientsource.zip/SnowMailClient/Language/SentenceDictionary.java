package SnowMailClient.Language;


import snow.utils.storage.*;

import java.util.*;
import java.util.zip.*;
import java.io.*;
import java.net.URL;
import javax.swing.table.*;
import javax.swing.event.*;
import java.awt.event.*;


/** @contain the sentences for a given language,
     and store the sentences that are not already translated
                  
*/
public final class SentenceDictionary implements Vectorizable
{               
  // STORED: ... contain All Sentences, also the untranslated
  final Vector<Sentence> allSentencesVector = new Vector<Sentence>();

  // contain sentences, key= english, value= translation in the language
  // this is used at SnowMail runtime for quick translation access
  final Hashtable<String, String> sentences = new Hashtable<String, String>();  // quick access

  // the language
  private String language;

  // true for dictionaries read from writable file
  // (i.e. false for dictionaries embedded in jar files and readonly external files)
  // is set during read from file...
  private boolean isEditable = true;



  public SentenceDictionary(String language)
  {
     this.language = language;
  } // Constructor


  public String getLanguage() {return language;}
  public Vector<Sentence> getAllSentences()
  {
    return allSentencesVector;
  }

  public boolean getIsEditable() { return isEditable; }


  /** try to translate the sentence.
      serch first for an exact mactch and then for a match
      ignoring spaces at the beginning and at the end.

      If not found, add a request and return the original english sentence
  */          
  public String getTranslatedSentence(String sentence)
  {
     String transl = (String) sentences.get(sentence);
     if(transl!=null)
     {
        return transl;
     }               
     else
     {                                     
        // not found... we try to find a similar string, just ignoring spaces
        String try2 = getTranslationIgnoringSpaces(sentence);
        if(try2!=null) 
        {
          // found a version without spaces !
          return try2;
        }

        // the sentence is not translated yet, we must request his translation
        Sentence sent = new Sentence(sentence, "Occured at runtime",-1, -1);
        allSentencesVector.add(sent);

        // return the original sentence
        return sentence;
     }
  }   
  
  public boolean hasTranslatedSentence(String sentence)
  {
     String transl = (String)sentences.get(sentence);
     if(transl!=null)
     {
        return true;
     }
     else
     {
        // not found... we try to find a similar string, just ignoring spaces
        String try2 = getTranslationIgnoringSpaces(sentence);
        if(try2!=null) return true;

        // the sentence is not translated yet, we must request his translation
        return false;
     }
  } 
                                                                   
  /** @return null if not found.
      try to search for the string, ignoring spaces.                                   
      The same number of spaces are then added at begining and end of the answer
  */
  private String getTranslationIgnoringSpaces(String sentence)
  {
        // not found... we try to find a similar string, just ignoring spaces
        String trimmed = sentence.trim();
        //int spaceBegin = Common.GetNumberOfSpacesAtBegining(sentence);
        //int spaceEnd = Common.GetNumberOfSpacesAtEnd(sentence);

        Enumeration enum2 = sentences.keys();
        while(enum2.hasMoreElements())
        {
          String elt = (String) enum2.nextElement();
          if(elt.trim().equals(trimmed))
          {
             // found a trimmed match...
             // => add the blanks (spaces, tabs, returns) before and after
             int pos = sentence.indexOf(trimmed);
             StringBuffer reply = new StringBuffer();
             reply.append( sentence.substring(0,pos) );
             reply.append(((String) sentences.get(elt)).trim());
             reply.append( sentence.substring(pos+trimmed.length()) );
             return reply.toString();
          }
        }
         
        return null;
  }


  /** this add the new sentences parsed in source and
      remove the old ones (no more used)
  */
  public void updateSentencesFromSource(Vector<Sentence> allEnglishSentencesFoundInSource)
  {
     System.out.println("Update dictionary with sentences parsed from source for language "+getLanguage());

     // 1. add all english sentences parsed
     for(int p=0; p<allEnglishSentencesFoundInSource.size(); p++)
     {
        Sentence sent = allEnglishSentencesFoundInSource.elementAt(p); 
        //if(sent.getSentence().equals("Yes")) System.out.println("* 1 *"); 
        // verify (or add) and mark as present                                
        verifyIfSentenceIsPresent(sent); 
     }
                
     // 2. remove the sentences that have not been found
     int removed = 0;    
     Vector<Sentence> toRemove = new Vector<Sentence>();
     for(int i=0; i<allSentencesVector.size(); i++)
     {
        Sentence s = allSentencesVector.elementAt(i);
        if(s.visited==false)  
        {
           removed++;      
           //if(s.getSentence().equals("Yes")) System.out.println("* 3 *");
           toRemove.addElement(s);
       /*   allSentencesVector.remove(s);    
           sentences.remove(s.getSentence());  */
        }
     }
     
     for(int i=0; i<toRemove.size();i++)
     {
         Sentence s = toRemove.elementAt(i);
         sentences.remove(s.getSentence());
         allSentencesVector.remove(s);
     }           

     fireChangeEvent();

     System.out.println("" +removed +" removed unused sentences");
  }          
  
  
  public String getStringOfAllTranslatedSentences()
  {   
     StringBuffer sb = new StringBuffer();
     for(int i=0; i<allSentencesVector.size();i++)
     {
       Sentence s = allSentencesVector.elementAt(i);
       if(s.hasTranslation())
       {
          sb.append("\n\n"+s.getTranslation());
       }
     }                                       
     return sb.toString();
  }

  /** look if a sentence is present. if not found, add it to the translation requests
  */
  private void verifyIfSentenceIsPresent(Sentence sent)
  {
     String sentence = sent.getSentence();
     
     int pos = positionInAllSentenceVector(sentence);  
     if(pos==-1)  
     {  
        //if(sent.getSentence().equals("Yes")) System.out.println("* 2 *");         
        allSentencesVector.addElement(sent);
        sent.visited = true; 
     }
     else      
     {  
        //if(sent.getSentence().equals("Yes")) System.out.println("* 2b *");
        Sentence s = allSentencesVector.elementAt(pos);
        s.visited = true;
        s.setLocationClass(sent.getLocationClass(), sent.getLinePosition());
     }   
          
     /*
     // 1. look if the translation is available
     String transl = (String) sentences.get(sentence);    
     if(transl==null)  
     {
       // 2. the translation is not present => look for a trimmed version
       String reply = getTranslationIgnoringSpaces(sentence);
       if(reply==null      {        
         // 3. the sentence is really not present => add it
         allSentencesVector.addElement(sent);  
         // mark it as visited
         sent.visited = true;
         fireChangeEvent();
       }
     }        
      
     // 2. mark the sentence as used 
     int pos = positionInAllSentenceVector(sentence);
     if(pos==-1)
     {           
        System.out.println("Problem: sentence not in all vector "+sentence);
     }
     else
     {
        Sentence s = (Sentence) allSentencesVector.elementAt(pos);
        s.visited = true;
     }   */
  }       

  /** @return the position of sent in allSentencesVector,
     using the trimmed strings 
  */
  private int positionInAllSentenceVector(String sent)
  {
    String st = sent.trim();

    for(int i=0; i<allSentencesVector.size(); i++)
    {                         
      Sentence s = (Sentence) allSentencesVector.elementAt(i);
      if(s.getSentence().trim().equals(st)) return i;
    }
    return -1;
  }

  
  
  public int getNumberOfTranslatedSentences() { return sentences.size(); }
  public int getNumberOfSentences() { return allSentencesVector.size(); }



  /** add a translation
  */
  public void addTranslation(String english, String translation)
  {                             
     // add /or update
     sentences.put(english, translation);
     int pos= this.positionInAllSentenceVector(english);
     if(pos==-1)       
     {
        Sentence se = new Sentence(english, "Added during runtime", 0, -1);
        se.setTranslation(translation);
                
        allSentencesVector.addElement(se);
        System.out.println("### sentence not in dic "+english);
     }
     else
     {
        Sentence se = (Sentence) allSentencesVector.elementAt(pos);
        se.setTranslation(translation);
     }

     // inform listeners
     fireChangeEvent();
  }                                    

  // Listeners
  //          
  Vector<ChangeListener> changeListeners = new Vector<ChangeListener>();
  public void addChangeListener(ChangeListener cl)
  {                             
    changeListeners.addElement(cl);
  }                                
  public void removeChangeListener(ChangeListener cl)
  {                             
    changeListeners.removeElement(cl);
  }                 
  private void fireChangeEvent()
  {                 
    for(ChangeListener cl: changeListeners)
    {
       cl.stateChanged(new ChangeEvent(this));
    }
  }


  // Vectorizable
  //
  public SentenceDictionary()
  {
  }

  public Vector<Object> getVectorRepresentation() 
  {
     Vector<Object> v = new Vector<Object>();        
     v.addElement(4);        // 0. version
     v.addElement(language);              // 1. language
     Vector<Object> sentv = new Vector<Object>();
     v.addElement(sentv);                 // 2. sentences
     for(Sentence s : allSentencesVector)
     {
       sentv.addElement(s.getVectorRepresentation());
     }

     return v;
  }

  public void createFromVectorRepresentation( Vector<Object> v )
  {
    int version = (Integer) v.elementAt(0);

    if(version==4)
    {
      language = (String) v.elementAt(1);
      sentences.clear();
      Vector<Vector> sentv = (Vector<Vector>)v.elementAt(2);
      for(Vector sv: sentv)
      {
         Sentence s = new Sentence();
         s.createFromVectorRepresentation(sv);
         allSentencesVector.addElement(s);                
         if(!s.getTranslation().equals(""))
         {
            sentences.put(s.getSentence(), s.getTranslation());
         }

         // sentences.put(key, val);
      }
    }

    else
    {
       throw new RuntimeException("Bad version "+version);
    }
  }



  public void saveToFile() throws Exception
  {
     // no english      
     if(language.compareToIgnoreCase("english")==0) return;
     
     if(!isEditable) return;

     File file = new File("SnowMailClient/Language/"+language+".translation");
     if(file.exists() && !file.canWrite())
     {
        throw new Exception("Language file "+language+" is read-only");
     }

     System.out.println("saving dic "+file.getAbsolutePath());
     FileUtils.SaveVectorToFile(file, this.getVectorRepresentation());
  }
  
  
  
                                                                                              
  /** look in the schmortopf jar file if french and deutsch are
      available
  */
  public static String[] getInternalAvailableTranslations()
  {
     String[] internalLanguagesToLookFor = new String[]
     {  
        Language.FRANCAIS, Language.DEUTSCH, Language.POLISH
     };
     ClassLoader cl = SentenceDictionary.class.getClassLoader();
     if(cl==null)
     {
       return new String[0];
     }

     Vector<String> foundLanguagesNames = new Vector<String>();
     for(int i=0; i<internalLanguagesToLookFor.length; i++)
     {
       InputStream is = null;
       try
       {
          is = cl.getResourceAsStream("SnowMailClient/Language/"
                         + internalLanguagesToLookFor[i] + ".translation");
          if(is!=null)
          {
             foundLanguagesNames.addElement(internalLanguagesToLookFor[i]);
             //System.out.println("Found language embedded in jar: "+languagesToLookFor[i]);
          }
       }
       finally
       {
          if(is!=null)
          {
            try{is.close();} catch(Exception e){ e.printStackTrace();}
          }
       }
     }
     return (String[]) foundLanguagesNames.toArray(new String[foundLanguagesNames.size()]);
  }



  public static SentenceDictionary readFromJarFile(String language) throws Exception
  {
     // no english
     if(language.compareToIgnoreCase("english")==0) return null;
     

     ClassLoader cl = SentenceDictionary.class.getClassLoader();
     if(cl==null)
     {
       System.out.println("Class loader is null for class SentenceDictionary.");
       // not found, maybe IDE mode ? not running from jar file
       return null;
     }

     SentenceDictionary sd = new SentenceDictionary(language);

     InputStream is = null;
     try
     {
        is = cl.getResourceAsStream("SnowMailClient/Language/"+language+".translation");
        if(is==null)   
        {
           System.out.println("ResourceAsStream is null for SnowMailClient/Language/"+language);
           return null;
        }
        Vector<Object> content = FileUtils.loadVector(is);
        sd.createFromVectorRepresentation(content);
        // read-only
        sd.isEditable = false;

        return sd;
     }
     finally
     {
        if(is!=null)
        {
          try{is.close();} catch(Exception e){ e.printStackTrace();}
        }
     }

  }                         
   

  public static SentenceDictionary ReadFromFile_ZIPPED(File file) throws Exception
  {

     SentenceDictionary sd = new SentenceDictionary("???");
                                                         
     // the read-only case
     if(!file.canWrite()) sd.isEditable = false;
                           
     Vector<Object> rep  = FileUtils.loadZippedVectorFromFile(file);
     if(rep.size()==0) throw new Exception("File "+file.getAbsolutePath()+" is empty");
     try
     {
       sd.createFromVectorRepresentation(rep);
     }
     catch(Exception e)
     {             
       throw e;
     }
     
     return sd;
  }

  /** try to read the dictionary from file.
      if not successful, try to use an internal embedded dictionary.
  */
  public static SentenceDictionary readFromFile(String language, boolean useEmbeddedIfFileNotFound) throws Exception
  {
     // no english
     if(language.compareToIgnoreCase("english")==0) return null;


     File file = new File("SnowMailClient/Language/"+language+".translation");
                                   
     System.out.println("loading dic "+file.getAbsolutePath());

     SentenceDictionary sd = new SentenceDictionary(language);

     if(file.exists())
     {
       // the read-only case
       if(!file.canWrite()) sd.isEditable = false;
                               
       Vector<Object> rep  = FileUtils.loadVectorFromFile(file);
       try
       {
         sd.createFromVectorRepresentation(rep);
       }
       catch(Exception e)
       {
         throw e;
       }
       //System.out.println(" Number of sentences = "+sd.getNumberOfTranslatedSentences());
       //System.out.println(" translation requests "+sd.getRowCount());
     }
     else
     {
       System.out.println("Language not found in file "+file.getAbsolutePath());
       // no file found, try to read from jar file
       if(useEmbeddedIfFileNotFound)
       {
         SentenceDictionary sdj =  readFromJarFile(language);
         if(sdj!=null)
         {                             
           return sdj;
         }
         else
         {

         }
       }
     }
     return sd;
  }

  public String getFileName()
  {
    File file = new File("SnowMailClient/Language/"+language+".translation");
    return file.getAbsolutePath();
  }

  

} // SentenceDictionary





                                              


















































