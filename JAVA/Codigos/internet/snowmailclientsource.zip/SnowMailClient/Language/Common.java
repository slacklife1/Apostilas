package SnowMailClient.Language;

import java.util.*;
import java.util.zip.*;
import java.io.*;
import javax.swing.table.*;

import snow.utils.storage.*;

public final class Common
{

  private Common()
  {                          

  } // Constructor

   /** @return the number of spaces at the begining of the string
     this is used to avoid translating "hello" and " hello "
   */
   public static int getNumberOfSpacesAtBegining(String s)
   {
      for(int i=0; i<s.length(); i++)
      {
        if(s.charAt(i)!=' ') return i;
      }
      return s.length();
   }

   /** @return the number of spaces at the end of the string
   */
   public static int getNumberOfSpacesAtEnd(String s)
   {
      for(int i=0; i<s.length(); i++)
      {
        if(s.charAt(s.length()-i-1)!=' ') return i;
      }
      return s.length();
   }


  /** @return 0 if no arguments are detected in the sentence (%)
       1 if one % is present
       2 if %1 and %2 are present
  */
   public static int getNumberOfParametersInSentence(String sentence) throws Exception
   {

     if(sentence.indexOf("%2")!=-1)
     {
        if(sentence.indexOf("%1")==-1)
        {
          throw new Exception("Sentence has only argument %2, %1 is missing ?");
        }
        return 2;
     }
     if(sentence.indexOf("%1")!=-1)
     {
        if(sentence.indexOf("%2")==-1)
        {
          throw new Exception("Sentence has only argument %1, %2 is missing ?");
        }
        return 2;
     }

     if(sentence.indexOf("%")!=-1)
     {
       return 1;
     }

     return 0;
   }

   /**  Language/hello.java =>  Language.hello
   */
   public static String convertPathToJavaClassPathSyntax(String _path)
   {
     String path = _path;
     // 1) supperss .java
     if(path.endsWith(".java")) path = path.substring(0, path.length()-5);
     
     // 2) convert \ to .
     int pos = -1;
     while((pos=path.indexOf("\\"))!=-1)
     {
       path = path.substring(0,pos)+"."+path.substring(pos+1);
     }
     
     return path;
   }
    




} // Common

