package SnowMailClient.crypto;

import snow.utils.storage.*;
import snow.crypto.*;
import snow.Language.Language;

import java.security.*;
import java.security.spec.*;
import javax.crypto.spec.*;
import javax.crypto.*;
import java.io.*;
import java.util.zip.*;
import java.util.*;
import javax.swing.*;


/** contain EncipherFile and DecipherFile
*/                         
public final class FileCipherManager
{
  private static FileCipherManager instance = null;
  
  private FileCipherManager()
  {
  }

  public static FileCipherManager getInstance()
  {
    if(instance==null)
    {
      instance = new FileCipherManager();            
    }  
    return instance; 
  }    
                               

  public void encipherVectorToFile(Vector<Object> v, File out, SecretKey key) throws Exception
  {
     encipherVectorWithHeadToFile(new Vector<Object>(), new Vector<Object>(), v, out, key);
  }

  /** the head, small should be used for performance reasons, for example
     to store an index describing the content.
  */
  public void encipherVectorWithHeadToFile(Vector<Object> uncipheredHead, Vector<Object> cipheredHead, Vector<Object> v, File out, SecretKey key) throws Exception
  {

    Cipher cipher = Cipher.getInstance("Blowfish/ECB/PKCS5Padding");
    cipher.init(Cipher.ENCRYPT_MODE, key);
                         
    FileOutputStream fos = null;
    DataOutputStream dos = null;
    GZIPOutputStream zos = null;
    CipherOutputStream cos = null;
    try
    {                                   
      fos = new FileOutputStream(out);
      dos = new DataOutputStream(fos);
      dos.writeInt(3);
      dos.writeUTF("Blowfish");
      dos.writeInt(key.getEncoded().length);
      SecretKeyID ski = SecretKeyUtilities.computeSignature(key);
      dos.write(ski.signature,0,4);
                      
      cos = new CipherOutputStream(dos, cipher);
      zos = new GZIPOutputStream(cos);

      DataOutputStream dos2 = new DataOutputStream(zos);
      VectorUtils.VectorToStream(dos2, cipheredHead);
      VectorUtils.VectorToStream(dos2, v);

      zos.close();
    }
    catch(Exception e)
    {
      throw e;
    }
    finally
    {
      if(fos!=null) fos.close();
    }
  }

   
  /** @return the keyID of the enciphered file
  */                  
  public SecretKeyID getKeyIDFromFile(File in) throws Exception
  {
    FileInputStream fis = null;
    DataInputStream dis = null;
    try       
    {                          
       fis = new FileInputStream(in);
       dis = new DataInputStream(fis);
       // header read
       int version = dis.readInt();    
       if(version==1)    
       {
          String algo = dis.readUTF();
          if(algo.equalsIgnoreCase("Blowfish"))
          {  
            throw new Exception(Language.translate("Bad encryption algorithm %",algo));
          }
          int keyLength = dis.readInt();
          byte[] sign = new byte[4];
          dis.readFully(sign,0,4);
          dis.close();

          SecretKeyID ski = new SecretKeyID(sign, keyLength);
          if( keyLength>20 )
          {
            throw new Exception(Language.translate("Bad key length found %",""+keyLength));
          }
          return ski;
       }
       else if(version>=2)
       {
          String algo = dis.readUTF();
          int keyLength = dis.readInt();
          byte[] sign = new byte[4];
          dis.readFully(sign,0,4);
          dis.close();

          SecretKeyID ski = new SecretKeyID(sign, keyLength);
          return ski;
       }
       else              
       {
         throw new Exception(Language.translate("Bad version %",""+version));
       }
    }
    catch(Exception e)
    {
      throw e;
    }
    finally
    {
       if(fis!=null) fis.close();
    }  

  }
                                                 

  /** simply decipher the file, asking for the key
  */
  public Vector<Object> decipherVectorFromFile_ASK_KEY_IF_NEEDED(
                    File file,  
                    Object frameOrDialog_owner,
                    String title, String explanation
                ) throws Exception
  {

      SecretKeyID keyID = null;
      try
      {                     
          keyID = this.getKeyIDFromFile(file);
      }
      catch(Exception e)
      {
         // no key ID in the file...
         // try the old version 0
         System.out.println("No key for "+file.getAbsolutePath()+" trying old version");
         Vector<Object> v = FileUtils.loadVectorFromFile(file);
         return v;
      }

      SecretKey sk = SecretKeyManager.getInstance().getKey(keyID);

      if(sk==null)
      {
         System.out.println("No keyID for "+file.getAbsolutePath());

         PassphraseDialog pd = null;
         if(frameOrDialog_owner instanceof JFrame)
         {
           pd = new PassphraseDialog((JFrame) frameOrDialog_owner, title, true, keyID, explanation);
         }
         else
         {
           pd = new PassphraseDialog((JDialog) frameOrDialog_owner, title, true, keyID, explanation);
         }

         if(pd.wasCancelled())       
         {
           throw new BadPasswordException(Language.translate("Password not entered"));
         }

         if(!pd.matchesID())
         {
           throw new BadPasswordException(Language.translate("Bad password"));
         }

         // read the key and add it to the collection
         sk = pd.getKey();
         SecretKeyManager.getInstance().addKey(sk);

      }

      try
      {
         Vector<Object> v = FileCipherManager.getInstance().decipherVectorFromFile(file,
                sk);
         //System.out.println(""+file.getAbsolutePath()+" read");
         return v;
      }
      catch(Exception ee)
      {
         throw ee;
      }
  }                        
  

  /** simply decipher the file with the given key
  */
  public Vector<Object> decipherVectorFromFile(File in, SecretKey key) throws Exception
  {                             
    final Vector<Object> v = new Vector<Object>();
    final Vector<Object> head = new Vector<Object>();

    FileInputStream fis = null;
    DataInputStream dis = null;
    CipherInputStream cis = null;
    GZIPInputStream zis = null;

    try
    {
      fis = new FileInputStream(in);
      //BufferedInputStream bis = new BufferedInputStream(fis, 65536*32);
      dis = new DataInputStream(fis);

      // (clear) header read
      //
      int version = dis.readInt();
      if(version==1)
      {
        // old version 1 was a static pass
        String algo = dis.readUTF();
        int keyLength = dis.readInt();
        byte[] sign = new byte[4];
        dis.readFully(sign,0,4);
        SecretKeyID ski = new SecretKeyID(sign, keyLength);
        key = SecretKeyManager.getInstance().getDefaultKeyVersion1_();
      }
      else if(version>=2)
      {
        // custom pass (or default, if not set...)
        String algo = dis.readUTF();
        int keyLength = dis.readInt();
        byte[] sign = new byte[4];
        dis.readFully(sign,0,4);
        SecretKeyID ski = new SecretKeyID(sign, keyLength);
        if(!SecretKeyUtilities.computeSignature(key).equals(ski))
        {                         
          throw new BadPasswordException(Language.translate("Bad key"));
        }
      }
      else
      {
        throw new Exception("Bad file version "+version);
      }

      // read cipher vector part
      //
                                                                                                     
      long t = System.currentTimeMillis();
      Cipher cipher = Cipher.getInstance("Blowfish/ECB/PKCS5Padding");
      cipher.init(Cipher.DECRYPT_MODE, key);

      cis = new CipherInputStream(dis, cipher);
      zis = new GZIPInputStream(cis);
      DataInputStream dis2 = new DataInputStream(zis);
      if(version>=3)
      {
        VectorUtils.StreamToVector(dis2, head);
        //System.out.println("Head read, length="+head.size());
      }
      VectorUtils.StreamToVector(dis2, v);

      long t2 = System.currentTimeMillis();
      //System.out.println("Read in "+(t2-t)/1000+" sec");


      zis.close();
    }
    catch(Exception e)
    {
      throw e;
    }
    finally
    {
      if(fis!=null) fis.close();
    }                                 
    return v;
  }


  /** Decipher the file with the given key, read only the header
  */
  public Vector<Object> decipherVectorHeaderFromFile(File in, SecretKey key) throws Exception
  {
    final Vector<Object> head = new Vector<Object>();

    FileInputStream fis = null;
    DataInputStream dis = null;
    CipherInputStream cis = null;
    GZIPInputStream zis = null;

    try
    {
      fis = new FileInputStream(in);
      dis = new DataInputStream(fis);

      // (clear) header read
      //
      int version = dis.readInt();
      if(version==1)
      {         
        // old version 1 was a static pass
        String algo = dis.readUTF();
        int keyLength = dis.readInt();
        byte[] sign = new byte[4];
        dis.readFully(sign,0,4);
        //not used... SecretKeyID ski = new SecretKeyID(sign, keyLength);
        key = SecretKeyManager.getInstance().getDefaultKeyVersion1_();
      }
      else if(version>=2)
      {
        // custom pass (or default, if not set...)
        String algo = dis.readUTF();
        int keyLength = dis.readInt();
        byte[] sign = new byte[4];
        dis.readFully(sign,0,4);
        SecretKeyID ski = new SecretKeyID(sign, keyLength);
        if(!SecretKeyUtilities.computeSignature(key).equals(ski))
        {
          throw new BadPasswordException(Language.translate("Bad key"));
        }
      }
      else
      {
        throw new Exception("Bad file version "+version);
      }

      // read cipher vector part
      //

      Cipher cipher = Cipher.getInstance("Blowfish/ECB/PKCS5Padding");
      cipher.init(Cipher.DECRYPT_MODE, key);

      cis = new CipherInputStream(dis, cipher);
      zis = new GZIPInputStream(cis);
      DataInputStream dis2 = new DataInputStream(zis);
      if(version>=3)
      {
        VectorUtils.StreamToVector(dis2, head);
        //System.out.println("Head read, length="+head.size());
      }
      zis.close();
    }
    catch(Exception e)
    {
      throw e;
    }
    finally
    {
      if(fis!=null) fis.close();
    }
    return head;
  }

} // FileCipherManager
