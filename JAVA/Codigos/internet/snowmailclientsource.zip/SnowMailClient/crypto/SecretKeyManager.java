package SnowMailClient.crypto;

import snow.utils.storage.*;
import snow.crypto.*;

import java.security.*;
import java.security.spec.*;
import javax.crypto.spec.*;
import javax.crypto.*;
import java.io.*;
import java.util.zip.*;
import java.util.*;

/** contain all the keys entered during this session and the key to be used for
  all cipherings
  must be stored only if the user has set a secret passphrase.
  Otherwise, it would be unsecure to save it with the default pass.

*/
public final class SecretKeyManager
{
  private SecretKey defaultStorageKey = null;

  // key = id, value = key
  private Hashtable<String, SecretKey> keys = new Hashtable<String, SecretKey>();
  private SecretKey defaultUserKeyForEncryption = null;
                                         

  // singleton class
  private static SecretKeyManager instance = null;
  private SecretKeyManager()
  {
    try     
    {
      defaultStorageKey = SecretKeyUtilities.generateKeyFromPassphrase("rz9r(i#*-.3)tyu89i".getBytes(), 8);
      this.addKey(defaultStorageKey);      
    }
    catch(Exception e)
    {
    }
  } // Constructor

  public static SecretKeyManager getInstance()
  {
     if(instance==null)
     {
       instance = new SecretKeyManager();
     }
     return instance;
  }

  public void addKey(SecretKey key)
  {
     SecretKeyID kid = SecretKeyUtilities.computeSignature( key );

     keys.put(
        new String(kid.signature),
        key);
                 
     Object o = keys.get(new String(kid.signature));
  }


  /** is used to make files not readable from system automatic tests...
      (antivirus, search engines, ...)
      give a good obfuscation security (as long as nobody use this sourcecode)
  */
  public SecretKey getDefaultKeyVersion1_()
  {
     return defaultStorageKey;
  }                     

  public SecretKey getUserKeyForEncryption()
  {
    return defaultUserKeyForEncryption;
  }


  public boolean isUserKeySet() { return this.defaultUserKeyForEncryption!=null; }

  public void setUserKeyForEncryption(SecretKey sk)
  {
    this.defaultUserKeyForEncryption = sk;
    if(sk!=null)
    {
      this.addKey(sk);
    }
  }
  
  public SecretKey getActualKey()
  {
    if(defaultUserKeyForEncryption!=null) return defaultUserKeyForEncryption;
    return this.defaultStorageKey;
  }


  /** look in the stored keys
  */
  public SecretKey getKey(SecretKeyID id)
  {
     byte[] sign = id.getKeySignature();
     Object key = keys.get(new String(id.signature));
     if(key==null)
     {
       //System.out.println("NO KEY FOUND");
       return null;
     }
     return (SecretKey) key;
  }



  // Storage
  //
                                                
  public Vector<Object> getVectorRepresentation()
  {
     Vector<Object> rep = new Vector<Object>();
     rep.addElement(1);   //0

     if(defaultUserKeyForEncryption!=null)
     {
       rep.addElement(defaultUserKeyForEncryption.getEncoded());  // 1
     }
     else
     {
       rep.addElement(new byte[0]);
     }

     Enumeration keyEnum = keys.elements();
     Vector<byte[]> keyIDs = new Vector<byte[]>();
     rep.addElement(keyIDs);     // 2
     while(keyEnum.hasMoreElements())
     {
       SecretKey key = (SecretKey) keyEnum.nextElement();
       keyIDs.addElement(key.getEncoded());
     }
     return rep;
  }

  public void createFromVectorRepresentation(Vector<Object> v)
  {
     int version = (Integer) v.elementAt(0);
     if(version==1)
     {

       byte[] nk2 = (byte[]) v.elementAt(1);    // 1
       if(nk2.length>0)
       {
          this.defaultUserKeyForEncryption = new SecretKeySpec(nk2, "Blowfish");
          this.addKey(this.defaultUserKeyForEncryption);
       }
       else
       {
          this.defaultUserKeyForEncryption = null;         
       }                              

       Vector<Object> kv = (Vector) v.elementAt(2); // 2
       for(int i=0; i<kv.size(); i++)
       {
         byte[] key = (byte[]) kv.elementAt(i);
         SecretKeySpec sks = new SecretKeySpec(key, "Blowfish");
         this.addKey(sks);
       }     
     }
     else             
     {
        throw new RuntimeException("Bad version "+version);
     }
  }

} // KeyManager                                 
