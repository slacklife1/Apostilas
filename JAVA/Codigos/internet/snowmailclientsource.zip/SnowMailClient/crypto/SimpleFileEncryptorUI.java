package SnowMailClient.crypto;

import javax.swing.*;
import javax.swing.filechooser.*;
import java.util.*;
import java.util.zip.*;

import java.security.*;
import java.security.spec.*;
import javax.crypto.spec.*;
import javax.crypto.*;


import SnowMailClient.crypto.*;
import snow.utils.gui.*;
import snow.utils.storage.*;
import snow.crypto.*;
import snow.FileEncryptor.*;

import snow.Language.Language;
import java.io.*; 

/** encrypt/decrypt dialog, just calls the methods of
     snow.FileEncryptor.SimpleFileEncryptor;
*/
public final class SimpleFileEncryptorUI
{

  private SimpleFileEncryptorUI()
  {

  } // Constructor


  public static void simpleDecryptFileUI(AppProperties props, JFrame parent)
  {
    String base = props.getProperty("FileDecrypt_last_base_dir", "");
    JFileChooser chooser = new JFileChooser(base);
    chooser.setDialogTitle(Language.translate("Chose a file to decrypt"));
    chooser.setDialogType(chooser.FILES_ONLY);

    int rep = chooser.showOpenDialog(parent);
    if(rep==chooser.APPROVE_OPTION)
    {
      File file = chooser.getSelectedFile();
      int bufferSize = 256;
      int progressToDo = (int) (file.length()/bufferSize);

      props.setProperty("FileDecrypt_last_base_dir", file.getParent());
      ProgressModalDialog progressDialog = null;
      try
      {
        SecretKeyID skid = SimpleFileEncryptor.getKeyIDFromFile(file);
        PassphraseDialog passDialog = new PassphraseDialog(parent,
          Language.translate("Enter the passphrase to decipher the file"), true, skid, Language.translate("Passphrase"));
        if(!passDialog.wasCancelled())
        {
          File decFile = null;
          if(file.getAbsolutePath().toLowerCase().endsWith(".snowenc"))
          {
            // remove the encoded extension
            String pa = file.getAbsolutePath();
            decFile = new File(pa.substring(0,pa.length()-8));
          }
          else
          {
            decFile = new File(file.getAbsolutePath()+".dec");
          }

          if(decFile.exists())
          {
            throw new Exception(
              Language.translate("Destination file \n %\nalready exist. Please delete it first.", decFile.getAbsolutePath()));
          }
          progressDialog = new ProgressModalDialog(
           parent, Language.translate("Decrypting file"), false);
          progressDialog.setProgressBounds(progressToDo);
          progressDialog.start();
          progressDialog.setProgressValue(0, Language.translate("Decrypting file")+"...");

          try
          {
            SimpleFileEncryptor.decryptFile(file, decFile, passDialog.getKey(), bufferSize, progressDialog);
          }
          catch(Exception ee)
          {
            throw ee;
          }
          finally
          {
            progressDialog.closeDialog();
            progressDialog = null;
          }
        }
      }
      catch(Exception e)
      {                                                                             
        JOptionPane.showMessageDialog(progressDialog,
          e.getMessage(), Language.translate("Error during file deciphering"), JOptionPane.ERROR_MESSAGE);
        //e.printStackTrace();
      }
    }
  } 
         
   
   
  /** must be called from a thread !
  */
  public static void simpleEncryptFileUI(AppProperties props, JFrame parent)
  {
    String base = props.getProperty("FileEncryptor_last_base_dir", "");
    JFileChooser chooser = new JFileChooser(base);
    chooser.setDialogTitle(Language.translate("Chose a file to encrypt"));
    chooser.setDialogType(chooser.FILES_ONLY);

    EncryptOptionsPanel optionsPanel = new EncryptOptionsPanel(
       props.getBoolean("WipeSourceAfterEncryption", false));
    chooser.setAccessory(optionsPanel);

    chooser.setFileSelectionMode(chooser.FILES_AND_DIRECTORIES);
    int rep = chooser.showOpenDialog(parent);
    if(rep==chooser.APPROVE_OPTION)
    {
      File file = chooser.getSelectedFile();

      File destinationFile = null;
      if(file.isFile())
      {
        destinationFile = new File(file.getAbsolutePath()+".snowEnc");
      }
      else
      {
        destinationFile = new File(file.getParentFile(), file.getName()+".snowEnc");
      }



      if(destinationFile.exists())
      {

          JOptionPane.showMessageDialog(parent,
            Language.translate("Cannot encrypt file"),
            Language.translate("Destination file \n %\nalready exist. Please delete it first.",
                               destinationFile.getAbsolutePath()),
            JOptionPane.ERROR_MESSAGE);

      }

      long fileSize = FileUtils.getSizeIncludingSubFiles(file);
      int bufferSize = 256;                                                                                

      props.setBoolean("WipeSourceAfterEncryption", optionsPanel.doWipeSource());
      props.setProperty("FileEncryptor_last_base_dir", file.getParent());

      PassphraseSettingDialog psd = new PassphraseSettingDialog(
          parent,
          Language.translate("Passphrase"),
          true,
          Language.translate("Please enter and confirm the passphrase to use to encipher the file"));

      if(!psd.wasCancelled())
      {
        ProgressModalDialog progressDialog = new ProgressModalDialog(
           parent, Language.translate("Encrypting file"), false);

        int progressToDo = (int) (fileSize/bufferSize);
        if(optionsPanel.doWipeSource())                                          
        {
          progressDialog.setProgressBounds(progressToDo*4);
        }
        else
        {
          progressDialog.setProgressBounds(progressToDo*3);
        }                  

                                         
        progressDialog.start();
        progressDialog.setProgressValue(0, Language.translate("Encrypting file")+"...");
        try
        {
          SecretKey key = psd.getKey();          
          
          if(file.isFile())
          {
             SimpleFileEncryptor.encryptFile(file, destinationFile, key, bufferSize, progressDialog);
             progressDialog.setProgressValue( progressToDo, "Testing encrypted file...");
   
             // test !!!
             try
             {
               String problem = SimpleFileEncryptor.verifyEncryptedFile(file, destinationFile, key, bufferSize, progressDialog);
               if(problem!=null)
               {
                  throw new Exception("Error during verify: "+problem);
               }

               if(optionsPanel.doWipeSource())
               {
                 progressDialog.setProgressValue( progressToDo*3, Language.translate("Wiping original")+"...");
                 SimpleFileEncryptor.wipeFile(file, bufferSize, progressDialog, 3);
               }
             }
             catch(Exception e2)
             {
               throw e2;
             }
          }
          else
          {
             // directory
             try
             {
                SimpleFileEncryptor.encryptDirectory(file, destinationFile, optionsPanel.doWipeSource(), key, bufferSize, progressDialog);
             }
             catch(Exception e2)
             {
               throw e2;
             }

          }

        }
        catch(Exception e)
        {
          JOptionPane.showMessageDialog(parent,
            e.getMessage(), Language.translate("Error during file ciphering"), JOptionPane.ERROR_MESSAGE);
        }
        finally
        {
          progressDialog.closeDialog();
        }

      }
    }
  }
   


} // SimpleFileEncryptorUI
