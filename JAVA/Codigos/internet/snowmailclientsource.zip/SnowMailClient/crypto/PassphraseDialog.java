package SnowMailClient.crypto;

import snow.utils.gui.*;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.Language.Language;
import snow.lookandfeel.*;
import snow.crypto.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import java.security.*;
import java.security.spec.*;
import javax.crypto.spec.*;
import javax.crypto.*;
import javax.swing.border.*;
import java.io.*;
import java.util.zip.*;
import java.util.*;

/** Ask for a passphrase.
    Important: call terminate !!
*/
public final class PassphraseDialog extends JDialog
{

  final int fontSize = UIManager.getFont("Label.font").getSize();
  final private JPasswordField passField = new JPasswordField(20);
  final private JTextArea explanationArea = new JTextArea();
  private CloseControlPanel ccp = null;
  final private SecretKeyID skid;
  private SecureInputKeyboardDialog keyboardDialog = null; // created at first call
  private boolean validateIfMatch = true;
                  
  /** @param skid null if no verification should be made here
  */
  public PassphraseDialog( JFrame owner, String title, boolean isModal, SecretKeyID skid, String explanation )
  {
    super(owner,title,isModal);
    this.skid = skid;
    explanationArea.setText(explanation);
    init();
  }
                    
  public PassphraseDialog( JDialog owner, String title, boolean isModal, SecretKeyID skid, String explanation )
  {
    super(owner,title,isModal);
    this.skid = skid;  
    explanationArea.setText(explanation);
    init();      
  }

  private void init()
  {
    final JPanel cp = new SnowBackgroundPanel(new BorderLayout());
    setContentPane(cp);
    cp.setBorder(new EmptyBorder(fontSize/2, fontSize/2, fontSize/2, fontSize/2));

    // South
    ccp = new CloseControlPanel(this, true, true, Language.translate("Validate"));
    
    if(validateIfMatch)
    {
      ccp.getOkButton().setVisible(false);
    }

    getContentPane().add(ccp, BorderLayout.SOUTH);

    // North
    getContentPane().add(this.explanationArea, BorderLayout.NORTH);
    explanationArea.setOpaque(false);
    explanationArea.setEditable(false);
    explanationArea.setBackground(cp.getBackground());

    // Center
    JPanel centerPanel_ = new JPanel();
    GridLayout3 grid = new GridLayout3(3, centerPanel_);
    //JPanel centerPanel = new JPanel(new GridLayout(1,2, fontSize/2, fontSize/2));
    centerPanel_.setOpaque(false);
    centerPanel_.setBorder(new EmptyBorder(fontSize/2, fontSize/2, fontSize/2, fontSize/2));
    getContentPane().add(centerPanel_, BorderLayout.CENTER);
    grid.add(new JContrastLabel(Language.translate("Passphrase"),
                  SnowMailClientApp.loadImageIcon("pics/key.PNG"), JLabel.LEFT), false);
    grid.add(passField, true);
    passField.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        terminate();
      }
    });

    JButton keyboard = new JButton("...");
    keyboard.setPreferredSize( new Dimension((int) keyboard.getPreferredSize().getWidth(),
      (int) passField.getPreferredSize().getHeight()));
    grid.add(keyboard, false);
    keyboard.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        if(keyboardDialog==null)
        {
          // create                                                                                                   
          keyboardDialog = new SecureInputKeyboardDialog(PassphraseDialog.this);
          keyboardDialog.addKeyListener(new SecureInputKeyboardDialog.HitListener()
          {
             public void keyTyped(char c)
             {
                if(shiftDown) 
                {
                  passField.setText( new String(passField.getPassword()) + Character.toUpperCase(c) );
                }
                else
                {
                  passField.setText( new String(passField.getPassword()) + c );
                }
                lookIfmatches();
             }
          });

        }

        if(keyboardDialog.isVisible())
        {
          keyboardDialog.setVisible(false);
          passField.requestFocus();
          return;
        }
        else
        {
          keyboardDialog.setVisible(true);
        }

      }
    });

    if(skid!=null)
    {
      passField.addKeyListener(new KeyAdapter()
      {
        @Override public void keyReleased(KeyEvent e)
        {
          lookIfmatches();
          
          shiftDown = e.isShiftDown();
        }

        @Override public void keyPressed(KeyEvent e)
        {
          shiftDown = e.isShiftDown();
        }

      });
      ccp.setOkEnabled(false);
      ccp.setOkBackground(ThemesManager.getInstance().getRed());
    }


    this.pack();
    this.setLocationRelativeTo(this.getOwner());

    this.addComponentListener(new ComponentAdapter()
    {
      @Override public void componentShown(ComponentEvent e)
      {
        passField.requestFocus();
      }
    });

    passField.requestDefaultFocus();
    passField.requestFocusInWindow();
        
        
    addWindowListener(new WindowAdapter()
    {
        @Override public void windowClosed(WindowEvent e)
        {
           terminate();
        }
        @Override public void windowClosing(WindowEvent e)
        {
           terminate();
        }
    });

    this.setVisible(true);
  } // initialize
  
  private boolean shiftDown = false;

  private final void lookIfmatches()
  {             
          if(matchesID())
          {
             ccp.setOkEnabled(true);
             ccp.setOkBackground(ThemesManager.getInstance().getGreen());
             if(validateIfMatch)
             {
                // quick accept without waiting for "enter"
                terminate();
             }
          }
          else
          {
             ccp.setOkEnabled(false);
             ccp.setOkBackground(ThemesManager.getInstance().getRed());
          }
  }

  public boolean wasCancelled()
  {
    return ccp.getWasCancelled();
  }
  
  public boolean matchesID()
  {
    if(this.skid==null) return false;
    try         
    {
      SecretKeyID skid2 = SecretKeyUtilities.computeSignature( getKey() );                           
      return skid2.equals(skid);  
    }
    catch(Exception e)  
    {      
      return false;
    }
  }

  public final SecretKey getKey() throws Exception
  {
    
    byte[] pass = new String(passField.getPassword()).getBytes();
    int len = 16;
    if(skid!=null) 
    {
      len = skid.getKeyLangth();
    }
    return SecretKeyUtilities.generateKeyFromPassphrase(pass, len);
  }


  private void terminate()
  {
    setVisible(false);
    if(keyboardDialog!=null)
    {
      this.keyboardDialog.terminate();                                                                 
    }
  }
 

} // PassphraseDialog
