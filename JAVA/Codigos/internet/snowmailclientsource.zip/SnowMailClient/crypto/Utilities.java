package SnowMailClient.crypto;

import snow.crypto.*;
import sun.misc.BASE64Encoder;
import sun.misc.BASE64Decoder;

import java.io.*;
import java.math.*;
import java.security.SecureRandom;
import java.util.Arrays;
import java.net.*;

import java.security.*;
import java.security.spec.*;
import javax.crypto.spec.*;
import javax.crypto.*;

/** specific to snowmail
*/
public final class Utilities
{
   public static final SecureRandom secureRandom = new SecureRandom();

   /** This create a SHA-1 160 bit hashcode (message digest) of the given password
       @return the hashed password, in base64 format or null if a the hash could not be performed
   */
   public static String hashPassword( String thePassword )
   {
      return encodeSingleLineBase64( CryptoUtilities.SHA1Hash(thePassword.getBytes()));
   }

   /** a base64 sha-1 hash is 28 chars long and ends with a '=',
    *  @return true if the passed string is in this "format",
    *  this condition is necesssary but not sufficient,
    *  we do not test that all chars are in the base64 base...
    *  this method is just here to avoid rehashing hashs in the
    *  gui password input fields...
    */
   public static boolean isValidHashPasswordFormat(String hash)
   {
      if(hash.length()!=28) return false;
      if(hash.charAt(27)!='=') return false;
      return true;
   }   
   

   /** BE CAREFUL, normally, Base64 make lines of 76 chars max and add
    *  cariage returns !, we remove them, because data is sent with
    *  println, 1 command per line and these \n here will break our
    *  commands
    */
    public static String encodeSingleLineBase64(byte bytes[])
    {
        BASE64Encoder enc = new BASE64Encoder();
        //System.out.println("BASE64 encoder bytes per line="+ enc.bytesPerLine());
        String base64 = enc.encode(bytes);
        return suppressLineFeeds(base64);
    }                 

    
   /** BE CAREFUL, normally, Base64 make lines of 76 chars max and add
    *  cariage returns ! here they are present...
    * use EncodeSingleLineBase64 to ensure sending single lines...
    */
    public static String encodeBase64(byte bytes[])
    {
        BASE64Encoder enc = new BASE64Encoder();
        //System.out.println("BASE64 encoder bytes per line="+ enc.bytesPerLine());
        String base64 = enc.encode(bytes);
        return base64;
    }
    
    
    public static String suppressLineFeeds(String in)
    {
        StringBuffer sb = new StringBuffer();
        for(int i=0; i<in.length(); i++)
        {
            char c = in.charAt(i);
            if(c !='\n' && c != '\r') sb.append(c);
        }
        return sb.toString();
    }
    
    public static byte[] decodeBase64(String coded)
        throws IOException
    {
        BASE64Decoder dec = new BASE64Decoder();
        byte original[] = null;
        original = dec.decodeBuffer(new ByteArrayInputStream(coded.getBytes()));
        return original;
    }


  public static String stringReplace(String s, String replace, String n)
  {
     StringBuffer str = new StringBuffer(s);
     int pos = -1;
     while( (pos=s.indexOf(replace,pos+1)) >= 0 )
     {   // Make your replace here
        str.replace(pos, pos+replace.length(), n);
        s = str.toString();
     }
     return s;
  }                     


  /**
   * encrypt a single line/message in
   * Base64encoder explicitely puts line feeds each 78 chars.
   * This is bad for our purpose here we just wand to encrypt a SINGLE line and
   * send it through a printWriter...
   * additional line feed would destroy our synchronous data handshake
   * with the server. So we removed the line feeds...
   */
  public static String encryptSingleLineBlowfishFormat64(String mess, byte[] pass) throws Exception
  {
      // free mode
      /*
      FreeCipher fc = new ECBCipher( new BlowfishBase(pass), new PKCS5Padding() );
      fc.setMode(FreeCipher.ENCRYPT_MODE);
      */
                    
      // JDK mode (requires unrestricted policy)
      Cipher fc = Cipher.getInstance("Blowfish/ECB/PKCS5Padding");
      SecretKeySpec skeySpec = new SecretKeySpec(pass, "Blowfish");
      fc.init(Cipher.ENCRYPT_MODE, skeySpec);

      return encodeSingleLineBase64(fc.doFinal(mess.getBytes()));
  }                    
          
  /**                                    
   * decrypt a single line/message in
   */
  public static String decryptSingleLineBlowfishFormat64(String mess, byte[] pass) throws Exception
  {
     /* free mode
      FreeCipher fc = new ECBCipher( new BlowfishBase(pass), new PKCS5Padding() );
      fc.setMode(FreeCipher.DECRYPT_MODE);
     */

      // JDK mode (requires unrestricted policy)
      Cipher fc = Cipher.getInstance("Blowfish/ECB/PKCS5Padding");
      SecretKeySpec skeySpec = new SecretKeySpec(pass, "Blowfish");
      fc.init(Cipher.DECRYPT_MODE, skeySpec);

      return new String(fc.doFinal(decodeBase64(mess)));
  }


    //
    // some byte array utils
    //

  /** @return {a0, a1, ..., an, b0, b1, ..., bm}
   *  the elements of the n length array a and m length array b.
   */
  public static byte[] concatenate(byte[] a, byte[] b)
  {
      byte[] c = new byte[a.length+b.length];
      // copy a
      for(int i=0; i<a.length; i++)
      {
          c[i]=a[i];
      }
      //copy b
      int lena = a.length;
      for(int i=0; i<b.length; i++)
      {
          c[i+lena] = b[i];
      }
      return c;
  }

 public static String printBytes(byte[] b)
 {
    StringBuffer sb = new StringBuffer();
    for(int i=0; i<b.length; i++)
    {
       sb.append(" ");
       int val = (int)b[i];
       if(Math.abs(val)<10) sb.append(" ");
       if(Math.abs(val)<100) sb.append(" ");
       if(val>=0) sb.append(" ");
       sb.append((int)b[i]);
       if(i%20==19) sb.append("\n");
    }
    return sb.toString();
 }  

 public static byte[] extract(byte[] b, int off, int len)
 {
    byte[] rep = new byte[len];
    for(int i=0; i<len; i++)
    {
       rep[i] = b[i+off];
    }
    return rep;
 }



    /** @return a random big number, not prime...
     *  very good for blowfish,
     *  but not for RSA that require quasi prime numbers.
     */ 
    public static BigInteger generateRandomBlowfishSecretKey(int bitlen)
    {
       return new BigInteger(bitlen, secureRandom);
    }


    /** CRAM-MD5 as described in rfc2195
      compute
         hash =  H( k XOR opad, H( k XOR ipad, b));
      return
         base64( username + " " + hash_hex )
    */
    public static String HMAC_KEYED_CRAM_MD5(byte[] _key, byte[] b, String username)
    {                                    
       byte[] key = _key;
       if(key.length>64) 
       {
         key = CryptoUtilities.MD5Hash(key);
       }

       byte[] ipad = new byte[64];
       byte[] opad = new byte[64];

       for(int i=0; i<64; i++)
       {                     
          ipad[i] = 0x36;
          opad[i] = 0x5C;
       }         
       byte[] hash = CryptoUtilities.MD5Hash(
                      concatenate( XOR(opad,key),
                                   CryptoUtilities.MD5Hash( concatenate( XOR(ipad,key), b ) )
                      ));  
                      
       return encodeSingleLineBase64((username+" "+asHex(hash)).getBytes());
    }
    


  /**
   */
  public static String asHex (byte[] bytes)
  {
    StringBuffer buf = new StringBuffer(2*bytes.length);
               
    for(int i = 0; i < bytes.length; i++)
    {
      if (((int) bytes[i] & 0xff) < 0x10)
      {    
        buf.append("0");
      }
      buf.append(Long.toString((int) bytes[i] & 0xff, 16));
    }
    return buf.toString();
  }


    /** a length should be greater then b length,
      if b length is smaller then a length, missing b elements are handled as zero bytes
      @return an a length byte array
    */
    public static byte[] XOR(byte[] a, byte[] b)
    {
       if(a.length < b.length) 
       {
         throw new RuntimeException("Bad lengths la<lb, a="+a.length+", b="+b.length);
       }
       
       byte[] rep = (byte[]) a.clone();
       for(int i=0; i<b.length; i++)
       {
          rep[i] = (byte) (a[i] ^ b[i]);
       }
       return rep;
    }    



}
