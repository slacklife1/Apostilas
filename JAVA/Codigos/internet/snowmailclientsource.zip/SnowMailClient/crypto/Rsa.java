package SnowMailClient.crypto;

import java.math.BigInteger;
import java.security.SecureRandom;


public final class Rsa
{
   private Rsa() {}
   

  /** generate the n, e, d big integers that define a rsa keypair.
   *  e and e makes the public key.
   *  d is the secret key
   */
  public static BigInteger[] generateRsaKeysNED(int bitlen)
  {
     SecureRandom r = Utilities.secureRandom;


     BigInteger   p = new BigInteger(bitlen / 2, 100, r);
     BigInteger   q = new BigInteger(bitlen / 2, 100, r);
     BigInteger   n = p.multiply(q);
     BigInteger   m = (p.subtract(BigInteger.ONE)).multiply(q.subtract(BigInteger.ONE));

     BigInteger   e = BigInteger.valueOf(65537L);  // fermat F4
     
     while(!m.gcd(e).equals(BigInteger.ONE))
     {
        e = e.add(new BigInteger("2"));
     }
     BigInteger d = e.modInverse(m);
     return new BigInteger[] {n,e,d};
  }
  
  
/*     

      // 1. Generate a prime p in the interval [2**(M-1), 2**M - 1], where
      // M = CEILING(L/2), and such that GCD(p, e) = 1
      int M = (L+1)/2;
      BigInteger lower = TWO.pow(M-1);
      BigInteger upper = TWO.pow(M).subtract(ONE);
      byte[] kb = new byte[(M+7)/8]; // enough bytes to frame M bits
      step1: while (true) {
         sr.nextRandomBytes(kb);
         p = new BigInteger(1, kb).setBit(0);
         if (     p.compareTo(lower) >= 0
               && p.compareTo(upper) <= 0
               && Prime.isProbablePrime(p)
               && p.gcd(e).equals(ONE)) {
            break step1;
         }
      }

      // 2. Generate a prime q such that the product of p and q is an L-bit
      // number, and such that GCD(q, e) = 1
      step2: while (true) 
      {
         nextRandomBytes(kb);
         q = new BigInteger(1, kb).setBit(0);
         n = p.multiply(q);
         if (     n.bitLength() == L
               && Prime.isProbablePrime(q)
               && q.gcd(e).equals(ONE)) {
            break step2;
         }
      }
   }
  */ 
  
  
  public static BigInteger encrypt(BigInteger e, BigInteger n, BigInteger message)
  {
    return message.modPow(e, n);
  }
  
  public static BigInteger decrypt(BigInteger n, BigInteger d, BigInteger message)
  {
    return message.modPow(d, n);
  }


  public static void main(String[] aa)
  {
     BigInteger[] keys = generateRsaKeysNED(1024);
     BigInteger bi = Utilities.generateRandomBlowfishSecretKey(448);
     System.out.println("secret="+bi);
     BigInteger enc = encrypt(keys[1], keys[0], bi);
     System.out.println("enc="+enc);
     BigInteger dec = decrypt(keys[0], keys[2], enc);
     System.out.println("dec="+dec);
     System.out.println("l="+dec.toByteArray().length);

  }

}
