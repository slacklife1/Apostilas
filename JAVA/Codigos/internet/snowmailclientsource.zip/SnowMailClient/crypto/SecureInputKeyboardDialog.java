package SnowMailClient.crypto;

import snow.utils.gui.*;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.Language.Language;
import snow.lookandfeel.*;
import snow.crypto.*;

import java.awt.*;
import java.awt.geom.*;
import java.awt.im.*;
import java.awt.image.*;
import java.awt.event.*;
import java.awt.font.*;
import javax.swing.*;

import java.security.*;
import java.security.spec.*;
import javax.crypto.spec.*;
import javax.crypto.*;
import javax.swing.border.*;
import java.io.*;
import java.util.zip.*;
import java.util.*;

/** call terminate() at the end !
*/
public final class SecureInputKeyboardDialog extends JWindow
{
  private final Vector<HitListener> keyListeners = new Vector<HitListener>();
  private final int NumberOfColumns = 13;
  private final GridLayout3 keysLayout;
  private final ActionListener keyActionListener;
  private boolean terminate = false;
  private final Thread animateThread;
  private final Font keyFont = new Font("SansSerif", Font.PLAIN, 12);
  private final FontRenderContext fontRenderContext = new FontRenderContext(new AffineTransform(1,0,0,1,0,0),false,true);
  

  public SecureInputKeyboardDialog(JDialog parent)
  {
      super(parent);
      setFocusable(false);
      setFocusableWindowState(false);

      getContentPane().setLayout(new BorderLayout());

      JTextArea kexplanationArea = new JTextArea(
        Language.translate("Entering some chars with the mouse will deceive keyloggers.\nHit Shift for uppercases.")
      );
      getContentPane().add(kexplanationArea, BorderLayout.NORTH);
      kexplanationArea.setOpaque(false);
      kexplanationArea.setEditable(false);
      kexplanationArea.setBackground(getBackground());
      kexplanationArea.setBorder(new EmptyBorder(5,5,5,5));

      JPanel keyPan = new JPanel();
      keyPan.setLayout(new GridLayout(4,13));
      keysLayout = new GridLayout3(NumberOfColumns,keyPan);
      getContentPane().add(keyPan, BorderLayout.CENTER);
      keyActionListener = new ActionListener()
      {
        public void actionPerformed(ActionEvent ae)
        {
           String str = ((SecureButton) ae.getSource()).getKey();
           notifyKeyTyped(str.charAt(0));
        }
      };
   //   addKeysLine("0");
      addKeysLine("0123456789");
      addKeysLine("abcdefghijklmnopqrstuvwxyz ");


      pack();
      this.setLocationRelativeTo(parent); // to center in X
      // and manually now in y
      setLocation( (int)  getX(),
                   (int) (parent.getLocation().getY() + parent.getHeight()+5) );

      animateThread = new Thread()                                                                   
      {
        public void run()
        {
          paintLoop();
        }
      };
      animateThread.setDaemon(true);
      animateThread.start();

      //launchDivertThread();
      //launchDivertThread();

      /*
      this.getGlassPane().addMouseListener(new MouseAdapter()
      {
         @Override public void mouseEntered(MouseEvent me)
         {
           mouseOnKeyboard = true;
           synchronized(animateThread)
           {
            // animateThread.notify();
           }
           repaint();
         }

         @Override public void mouseExited(MouseEvent me)
         {
           mouseOnKeyboard = false;
           animateThread.yield();
         }
      });*/
  } // Constructor
  
  private final void launchDivertThread()
  {
      Thread divertThread = new Thread()
      {
        public void run()
        {  
          double a = 0;       
          int i=0;
          while(!terminate)
          {                                                                                         
            a += Math.sqrt(i++);
          }
          System.out.println("a="+a);
        }
      };
      divertThread.setDaemon(true);
      divertThread.start();
  }


  private boolean hideKeys = false;
  private boolean mouseOnKeyboard= true;

  public final void terminate()
  {
    this.setVisible(false);                                                                         
    terminate = true;
    buttons.removeAllElements();
    synchronized(keyListeners)
    {
      this.keyListeners.removeAllElements();
    }
    this.getContentPane().removeAll();
  }
  
  private void paintLoop()
  {
     while(!terminate)
     {
        if(!this.isVisible())
        {
          Thread.yield();
        }  
        else
        {
          /*for(SecureButton sb:buttons)
          {
            sb.repaint();
          } */
  
  
          repaint();
          try
          {                           
            Thread.sleep(1);
          } catch(Exception ee) {}
        }
     }
  }

  int addedKeys = 0;
  private final Vector<SecureButton> buttons = new Vector<SecureButton>();
  private void addKeysLine(String keys)
  {
      Vector<Character> lchars = new Vector<Character>(); // NO NO NOArrays.asList(chars));
      for(char c : keys.toCharArray()) lchars.add(c);
      Collections.shuffle(lchars);
      for(Character c : lchars)
      {
         SecureButton bt = new SecureButton(""+c);
         keysLayout.add(bt);
         buttons.add(bt);
         bt.addActionListener(this.keyActionListener);
         addedKeys++;
      }

      // fill
      while(addedKeys%this.NumberOfColumns != 0)
      {
         addedKeys++;
         keysLayout.add("");

      }
  }

  class SecureButton extends JButton
  {
    private final String key;
    private int repaints = 0;
    BufferedImage bim = new BufferedImage(13,12,BufferedImage.TYPE_INT_ARGB);
    BufferedImage[] bimp;
    final private Vector<int[]> posBlack = new Vector<int[]>();

    public SecureButton(String key)
    {
      super("");
      this.key = key;
      this.setPreferredSize(new Dimension(30,20));

      Graphics gr = bim.createGraphics();
      gr.setColor(Color.white);
      //gr.fillRect(0,0,13,12);    // background
      gr.setColor(Color.black);
      TextLayout textLayout = new TextLayout(key, keyFont, fontRenderContext);
      int w = (int) textLayout.getBounds().getWidth();
      gr.setFont(keyFont);
      gr.drawString(key,6-w/2,10);
      gr.dispose();

      // RGB= 0 for transparent, 0 for white, -16777216 for black
      //System.out.println(bim.getRGB(0,0));
      // count black pixels       
      int bc = 0;
      for(int j=0;j<bim.getHeight();j++)
      {
         for(int i=0; i<bim.getWidth(); i++)
         {
           if(bim.getRGB(i,j)==-16777216) 
           {
             posBlack.add(new int[]{i,j});
           }
         }
      }  
      
      Collections.shuffle(posBlack);

      bimp = new BufferedImage[3];
      int n=posBlack.size()/bimp.length;
      int pos=0;
      for(int i=0; i<bimp.length; i++)
      {
                                           
             BufferedImage bi = new BufferedImage(bim.getWidth(), bim.getHeight(), bim.getType());
             bimp[i] = bi;
             Graphics gri = bi.createGraphics();
             gri.setColor(Color.white);
             //gri.fillRect(0,0,13,12);  // background

             gri.dispose();
             // set n next pixels
             int start = pos;
             int end = pos+n;
             int cnt = 0;
             for(;pos<end && pos<posBlack.size();pos++)
             {    
               int[] xy = posBlack.elementAt(pos);
               bi.setRGB(xy[0], xy[1], -16777216);
               cnt++; 
             }
      }

    }
                    
    public String getKey() {return key; }

    public void paintComponent(Graphics g)
    {

      super.paintComponent(g);
      if(!mouseOnKeyboard)
      {
        g.drawString("*",12,15);
        return;
      }
      
      /*if(Math.random()<0.01)
      {
        g.dispose();
        return;
      } */

      //g.setClip(12,5,10,10);
      //g.setColor(Color.white);
      //g.setColor(Color.blue);
                         
      //g.drawRect(10,4,13,12);

//      g.setColor(Color.black);
      if(bimp.length==0) return;


      g.drawImage(bimp[ repaints%bimp.length],5,5,this);

      //g.drawImage(bimp[ (int)(Math.random()*bimp.length)],5,5,this);

                            
      //setClip(g); //.setClip(10,10,20,20);
      //g.drawString(key,12,15);
      //g.dispose();
      /*g.drawImage(bim,
         12,5,this);*/
//         (int) (Math.random()*13),
//         (int) (Math.random()*12),
//         this);
      repaints++;
      g.dispose();
    }
  }


  /** not nice !
  */
  private void setRandomClip(Graphics g)
  {
    g.setClip(
      10+(int)(Math.random()*10.0),
      4+(int)(Math.random()*10.0),
      5,5);
  }



  /** used to listen to the clicked keys
  */
  interface HitListener
  {
     public void keyTyped(char c);
  }

  public final void addKeyListener(HitListener kl)
  {     
    synchronized(keyListeners)
    {
      this.keyListeners.add(kl);
    }
  }

  public final void removeKeyListener(HitListener kl)
  {
    synchronized(keyListeners)
    {
      this.keyListeners.remove(kl);
    }
  }

  private final void notifyKeyTyped(char c)
  {   
    // subtle: when closing, one receive a java.util.ConcurrentModificationException !
    // => must iterate "classically"
    synchronized(keyListeners)
    {
      for(int i=0; i<keyListeners.size(); i++)
      {               
        HitListener kl = keyListeners.elementAt(i);
        kl.keyTyped(c);
      }
    }
  }


  public static void main(String[] a)
  {
    JFrame fra = new JFrame("test key dialog");
    fra.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JDialog fr = new JDialog(fra, "test", false);
    fr.setDefaultCloseOperation(JDialog.EXIT_ON_CLOSE);  // no effect !!!
    final JTextField tf = new JTextField(20);
    fra.getContentPane().add(tf,BorderLayout.CENTER);

    fra.setSize(600,200);
    fra.setLocationRelativeTo(null);
    fra.setVisible(true);
    fr.setSize(600,200);
    fr.setLocationRelativeTo(null);
    //fr.setVisible(true);


    SecureInputKeyboardDialog sid = new SecureInputKeyboardDialog(fr);
    sid.setVisible(true); 
    
    sid.addKeyListener(new HitListener()
    {
       public void keyTyped(char c)
       {
         tf.setText(tf.getText()+c);
       }
    });
  }

} // SecureInputKeyboardDialog
