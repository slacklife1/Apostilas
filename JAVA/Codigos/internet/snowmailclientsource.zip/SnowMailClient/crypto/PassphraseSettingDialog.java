package SnowMailClient.crypto;

import snow.utils.gui.*;

import SnowMailClient.SnowMailClientApp;
import snow.Language.Language;
import snow.crypto.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
                     
import java.security.*;
import java.security.spec.*;
import javax.crypto.spec.*;
import javax.crypto.*;
import javax.swing.border.*;
import java.io.*;
import java.util.zip.*;
import java.util.*;

/** Ask for a passphrase
*/
public final class PassphraseSettingDialog extends JDialog
{                    

  final int fontSize = UIManager.getFont("Label.font").getSize();
  final private JPasswordField passField = new JPasswordField(20);
  final private JPasswordField passField2 = new JPasswordField(20);

  final private JTextArea explanationArea = new JTextArea();
  private CloseControlPanel ccp = null;
  private SecureInputKeyboardDialog keyboardDialog;


  /** @param skid null if no verification should be made here
  */
  public PassphraseSettingDialog( JFrame owner, String title, boolean isModal, String explanation )
  {
    super(owner,title,isModal);
    explanationArea.setText(explanation);
    init();
  }

  public PassphraseSettingDialog( JDialog owner, String title, boolean isModal, String explanation )
  {
    super(owner,title,isModal);
    explanationArea.setText(explanation);
    init();
  }

  private void init()
  {
    JPanel cp = new SnowBackgroundPanel(new BorderLayout());
    setContentPane(cp);
    cp.setBorder(new EmptyBorder(fontSize/2, fontSize/2, fontSize/2, fontSize/2));
                              
    // South                           
    ccp = new CloseControlPanel(this, true, true, Language.translate("Validate"));
    getContentPane().add(ccp, BorderLayout.SOUTH);

    // Center
    getContentPane().add(this.explanationArea, BorderLayout.NORTH);
    explanationArea.setEditable(false);
    explanationArea.setBackground(cp.getBackground());

    JPanel centerPanel_ = new JPanel(); //new GridLayout(2,2, fontSize/2, fontSize/2));
    GridLayout3 grid = new GridLayout3(2, centerPanel_);
    centerPanel_.setBorder(new EmptyBorder(fontSize/2, fontSize/2, fontSize/2, fontSize/2));
    getContentPane().add(centerPanel_, BorderLayout.CENTER);
    grid.add(new JContrastLabel(Language.translate("Passphrase"),
        SnowMailClientApp.loadImageIcon("pics/key.PNG"), JLabel.LEFT), false);
    grid.add(passField, true);
    passField.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        passField2.requestFocus();
      }           
    });

    KeyAdapter ka = new KeyAdapter()
    {
      @Override public void keyReleased(KeyEvent e)
      {
        ccp.setOkEnabled(confirmationMatches());
        shiftDown = e.isShiftDown();
      }

      @Override public void keyPressed(KeyEvent e)
      {
        shiftDown = e.isShiftDown();
      }                     
    };
    passField.addKeyListener(ka);
    passField2.addKeyListener(ka);
    ccp.setOkEnabled(false);

    grid.add(new JContrastLabel(Language.translate("Confirmation")), false);
    grid.add(passField2, true);
    passField2.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        terminate();
      }
    });
    passField2.addKeyListener(new KeyAdapter()
    {
      @Override public void keyReleased(KeyEvent e)
      {
        ccp.setOkEnabled(confirmationMatches());
      }
    });

    this.pack();

    this.setLocationRelativeTo(this.getOwner());

    this.addComponentListener(new ComponentAdapter()
    {
      @Override public void componentShown(ComponentEvent e)
      {
        passField.requestFocus();
      }
    });

    keyboardDialog = new SecureInputKeyboardDialog(this);
    keyboardDialog.addKeyListener(new SecureInputKeyboardDialog.HitListener()
    {
       public void keyTyped(char c)
       {     
          JPasswordField pf = (passField2.hasFocus() ? passField2 : passField);
          if(shiftDown)
          {
            pf.setText( new String(pf.getPassword()) + Character.toUpperCase(c) );
          }
          else
          {
            pf.setText( new String(pf.getPassword()) + c );
          }   
          ccp.setOkEnabled(confirmationMatches());
       }
    });
         
    keyboardDialog.setVisible(true);
         
    addWindowListener(new WindowAdapter()
    {
        public void windowClosed(WindowEvent e)
        {
           terminate();
        }
        public void windowClosing(WindowEvent e)
        {
           terminate();
        }
    });
         

    // MODAL !!!
    this.setVisible(true);

  } // initialize

  
  private boolean shiftDown = false;

  public boolean wasCancelled()
  {
    return ccp.getWasCancelled();
  }

  public boolean confirmationMatches()
  {
    return Arrays.equals(passField.getPassword(), passField2.getPassword());
  }

  public SecretKey getKey() throws Exception
  {
    byte[] pass = new String(passField.getPassword()).getBytes();
    return SecretKeyUtilities.generateKeyFromPassphrase(pass, 16);
  }

     
  private final void terminate()
  {
    setVisible(false);
    this.keyboardDialog.terminate();

  }

} // PassphraseSettingDialog                          
