package SnowMailClient.model.events;

/** used to listen to a mail folder
*/
public interface MailFolderListener
{

   /** something changed: mail added or removed
   */
   public void folderSizeChanged();
   
   /** the content was stored
   */
   public void folderStored();

   /** tThe folder has been closed.
      This can occur when we need memory...
      The view must react and CLOSE the displayed folder, if this occurs !
   */
   public void folderClosed();

   /** a mail was edited
   */            
   public void folderContentEdited(MailMessageChangeListener.MailMessageChangeType change);

                       


} // MailFolderListener
