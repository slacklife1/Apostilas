package SnowMailClient.model.events;

import SnowMailClient.model.*;

public interface MailMessageChangeListener
{ 
  public enum MailMessageChangeType { MESSAGE, HEADER, PROPERTY, ATTACHMENT, 
     IN_EDITION,  // Special case: the message is being edited but his content has not already changed (only when save or when change the message)
     DECRYPTED
  }


  public void mailMessageChanged(MailMessage source, MailMessageChangeType type, String detail );
  

} // MailMessageChangeListener                                                                                                    
