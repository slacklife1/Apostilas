package SnowMailClient.model;

import SnowMailClient.model.folders.*;

/** used in the folder search
*/
public final class SearchHit
{
  final private MailMessage mess;
  final private FolderTreeNode node;

  public SearchHit(MailMessage mess, FolderTreeNode node)
  {
    this.mess = mess;
    this.node = node;
  } // Constructor
           
  public MailMessage getMessage()
  {
    return mess;
  }
  
  public FolderTreeNode getNode() 
  {
    return node;
  } 

  
  public String toString()
  {
    return this.node.getFolderName()+" / "+this.mess.getFromAddress()+", "
      +mess.getSubject();
  }



} // SearchHit
