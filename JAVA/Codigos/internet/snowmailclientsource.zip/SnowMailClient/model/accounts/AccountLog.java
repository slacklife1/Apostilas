package SnowMailClient.model.accounts;

import SnowMailClient.utils.*;
import snow.utils.storage.*;

import java.util.*;
import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;


/** logs the sended/received on the account
 */
public final class AccountLog implements Vectorizable
{

   public DefaultStyledDocument doc = new DefaultStyledDocument();


   public int maxLength = 30000;  // some lines to debug


   public AccountLog()
   {
      //Create the styles we need.
      initStyles();
   }


   public void appendReadLine(String str, boolean wasEncrypted)
   {
       if(wasEncrypted)
       {
          appendStyled("R> "+str+"\n", "readEncrypted");
       }
       else
       {
          appendStyled("R> "+str+"\n", "readNotEncrypted");
       }
   }


   public void appendSendLine(String str, boolean wasEncrypted)
   {
       if(wasEncrypted)
       {
          appendStyled("S> "+str+"\n", "sendEncrypted");
       }
       else
       {
          appendStyled("S> "+str+"\n", "sendNotEncrypted");
       }
   }



   public void appendComment(String str)
   {
      appendStyled(str+"\n","comment");
   }


   public void appendError(String str)
   {
      appendStyled(str+"\n","error");
   }


   public void appendLine(String str)
   {
      appendStyled(str+"\n","regular");
   }

   public void append(String str)
   {
      appendStyled(str,"regular");
   }

   public void appendStyled(String str, String style)    
   {
      if (doc != null)
      {
         try
         {
            doc.insertString(doc.getLength(), str, doc.getStyle(style));
         }
         catch (BadLocationException e) { e.printStackTrace(); }
         checkLength();
      }
   }



   public void checkLength()
   {
      if(doc.getLength()>maxLength)
      {
         try
         {
            doc.remove(0, doc.getLength()-maxLength);
         }
         catch (BadLocationException e) { e.printStackTrace(); }
      }
   }



   protected void initStyles()
   {
      //Initialize some styles.
      Style def = StyleContext.getDefaultStyleContext().
                                     getStyle(StyleContext.DEFAULT_STYLE);

      StyleConstants.setFontSize(def, 11);

      Style regular = doc.addStyle("regular", def);
      StyleConstants.setFontFamily(def, "SansSerif");

      Style s = doc.addStyle("italic", regular);
      StyleConstants.setItalic(s, true);

      s = doc.addStyle("bold", regular);
      StyleConstants.setBold(s, true);

      s = doc.addStyle("small", regular);
      StyleConstants.setFontSize(s, 9);

      s = doc.addStyle("large", regular);
      StyleConstants.setFontSize(s, 16);

      s = doc.addStyle("readEncrypted", regular);
      StyleConstants.setForeground(s, new Color(0f,0.8f,0f));

      s = doc.addStyle("sendEncrypted", regular);
      StyleConstants.setForeground(s, new Color(0f,0.8f,0f));
      StyleConstants.setBold(s, true);
      StyleConstants.setItalic(s, true);

      s = doc.addStyle("comment", regular);
      StyleConstants.setForeground(s, new Color(0f,0.0f,0.8f));
      StyleConstants.setBold(s, true);
      StyleConstants.setItalic(s, true);

      s = doc.addStyle("error", regular);
      StyleConstants.setForeground(s, new Color(0.9f,0.0f,0.0f));
      StyleConstants.setBold(s, true);
      StyleConstants.setItalic(s, true);

      s = doc.addStyle("readNotEncrypted", regular);
      StyleConstants.setForeground(s, new Color(255,153,0));

      s = doc.addStyle("sendNotEncrypted", regular);
      StyleConstants.setForeground(s, new Color(255,153,0));
      StyleConstants.setBold(s, true);
      StyleConstants.setItalic(s, true);

   }



   // Vectorizable storage
   //

   public void createFromVectorRepresentation(Vector v) throws VectorizeException
   {
      try
      {
         // old text showed small
         doc.insertString(doc.getLength(), (String) v.elementAt(0), doc.getStyle("small"));
      }
      catch (BadLocationException e) { e.printStackTrace(); }
   }

   // save folders in a vector
   //
   public Vector<Object> getVectorRepresentation() throws VectorizeException
   {
      Vector<Object> v = new Vector<Object>();
      try
      {
        // ### store styles ???
        v.addElement(doc.getText(0,doc.getLength()));
      } 
      catch(Exception e)
      {
        e.printStackTrace();
      }
      return v;
   }


}


