package SnowMailClient.model.accounts;


import snow.utils.storage.*;
import SnowMailClient.Language.Language;

import java.util.*;
import javax.swing.*;
import javax.swing.table.TableModel;

import javax.swing.table.AbstractTableModel;


/** the mail accounts
*/
public final class MailAccounts extends AbstractTableModel implements Vectorizable
{                          
   // Data
   private final Vector<MailAccount> accounts = new Vector<MailAccount>();
                           

   public MailAccounts()
   {
   }

   public void addNewAccount()
   {              
      accounts.addElement(new MailAccount());
      updateList();
   } 
   
   public void addAccount(MailAccount a)
   {
      accounts.addElement(a);
      updateList();
   }

   public void remove(MailAccount ma)
   {
      accounts.removeElement(ma);
      updateList();
   }   

   public void insertAccountAt(MailAccount ma, int pos)
   {
      accounts.insertElementAt(ma, pos);
      updateList();
   }   

   public void updateList()
   {
      fireTableDataChanged();
   }
                        

   public MailAccount getAccount(int index)
   {
      return accounts.elementAt(index);
   }   
   

   /** @return the account of the given address or
       null if none found.
   */
   public MailAccount getMailAccount(String address)
   {
      for(MailAccount ma: accounts)
      {
          if(ma.getAddress().equalsIgnoreCase(address)) return ma;
      }
      return null;
   }


   /** @return the first account that have administrator privileges
       on the snowraver server,
       null if none found.
   */
   public MailAccount getFirstSnowraverAdministratorMailAccount()
   {
      for(MailAccount ma: accounts)
      {
          try
          {
             if(ma.getCheckedPopConnection().hasAdminPrivileges())
             {
                return ma;
             }
          }
          catch(Exception e) {}
      }
      return null;

   }


   /** @return the first account that have snowmail extensions,
       null if none found.
   */
   public MailAccount getFirstSnowMailAccount()
   {
      for(MailAccount ma: accounts)
      {
          // securemode is equivalent to snowmail account
          if(ma.isSnowraverAccount()) return ma;
      }
      return null;

   }


   /** @return the first account that is marked to send mails with
       null if none found.
   */
   public MailAccount getSendMailAccount()
   {
      for(MailAccount ma: accounts)
      {
          if(ma.getUseToSendMails()) return ma;
      }
      return null;
   }


   public Vector<String> getAllMailAddresses()
   {
      Vector<String> aa = new Vector<String>();
      for(MailAccount ma: accounts)
      {
        aa.addElement(ma.getAddress());
        //System.out.println("AA>"+ma.getAddress());
      }
      return aa;
   }

   
   /*
   public Vector<MailAccount> getAllOpenedPOPConnections()
   {
      for(MailAccount ma_: accounts)
      {
        final MailAccount ma = ma_;
        Thread t = new Thread() { public void run() {
          ma.closePOPConnection();
        }};
      }
   } */


   public void closeAllOpenedPOPConnections()
   {
      for(MailAccount ma_: accounts)
      {
        final MailAccount ma = ma_;
        Thread t = new Thread() { public void run() {
          ma.closePOPConnection();
        }};
      }
   }


   // Vectorizable storage
   //

   // load stored folders from a vector
   //
   public void createFromVectorRepresentation(Vector v) throws VectorizeException
   {
         int version = (Integer) v.elementAt(0);
         if(version==3)
         {

           synchronized(accounts)
           {
             Vector<Vector> acv = (Vector) v.elementAt(1);
             accounts.removeAllElements();
             for(Vector av : acv)
             {
                MailAccount ma = new MailAccount();
                ma.createFromVectorRepresentation(av);
                accounts.add( ma );
             }
           }
         }
         else
         {
           throw new VectorizeException("Bad version "+version);
         }
         updateList();
   }

   // save folders in a vector
   //
   public Vector<Object> getVectorRepresentation() throws VectorizeException
   {
       Vector<Object> cont = new Vector<Object>();
       cont.addElement(3); //version

       synchronized(accounts)
       {  
          Vector<Object> acv=new Vector<Object>();    
          cont.addElement(acv);

          for(MailAccount ma: accounts)
          {
             acv.addElement(ma.getVectorRepresentation());
          }
       }

       return cont;
   }


   // AbstractTableModel implementation
   //
   public Object getValueAt(int row, int col)
   {
       if(row>=0 || row<accounts.size())
       {                        
          MailAccount ma = (MailAccount)accounts.elementAt(row);
          switch(col)
          {
            case 0:
              return ma.getAddress();                                                                                                            
            case 1: return ma.getUseToReadMails();
            case 2: return ma.getUseToSendMails();
          }
          return "?";
       }
       else
       {                       
          return "?";
       }
   }

   public int getRowCount() {return accounts.size();}


   public int getColumnCount() { return 3; }
   
   public String getColumnName(int column)
   {
      if(column==0) return Language.translate("Address");
      if(column==1) return Language.translate("Receive");
      if(column==2) return Language.translate("Send");
      return "?";
   }



   public boolean isCellEditable(int rowIndex, int columnIndex)

   {
       return columnIndex>0;
   }

   public void setValueAt(Object aValue, int rowIndex, int columnIndex)
   {
         boolean val = true;
         if(aValue instanceof Boolean)
         {
            val = (Boolean) aValue;
         }
         else if(aValue instanceof String)
         {
            val = "true".equals((String) aValue);
         }
         MailAccount ma = accounts.elementAt(rowIndex);

         if(columnIndex==1) ma.setUseToReadMails(val);
         if(columnIndex==2) ma.setUseToSendMails(val);
   }


   public Class getColumnClass ( int column )                      
   {
      Object obj = getValueAt ( 0, column );
      return obj.getClass ();
   }


}
