package SnowMailClient.model.accounts;

import SnowMailClient.utils.*;
import SnowMailClient.view.*;
import SnowMailClient.view.dialogs.*;
import SnowMailClient.MailEngine.*;
import SnowMailClient.*;
import SnowMailClient.crypto.*;

import snow.utils.storage.*;
import snow.crypto.*;
import snow.concurrent.*;

import java.util.*;
import java.util.concurrent.*;
import java.net.*;                                                                                                                              


/** contains information about a mail account and his connection
*/
public final class MailAccount implements Vectorizable {

  private String address = "?";
  private String name = "?";
  private String smtp = "?";
  private String pop = "?";
  private String accountUserName = "?";
  private String accountPassword = "?";
  private boolean useToRead = true;
  private boolean useToSend = true;
  private int popPort  = 110;
  private int sslPopPort = 443;
  private int sslSMTPPort = 21;
  private int smtpPort =  25;
  private boolean signOutgoingMails = false;
  private boolean allowUnsecurePasswordProtocols = false;  // As AUTH LOGIN of Yahoo [2005]
         
         
  // Used for downloading messages. Used to parallelize downloads (one per account at a time)
  public final TaskManager messagesDownloadExecutor = new TaskManager(); 
         

  // used when sending accounts on the net to reduce data size
  public boolean storeAccountLogInVectorRepresentation = false;


  // log ALL traffic
  private final AccountLog accountLog = new AccountLog();

  private SecurePopConnection securePopConnection;
  private SecureSmtpConnection secureSmtpConnection;


  public MailAccount() { }


  public final AccountLog getAccountLog() { return accountLog; }

  public final String getAddress()       { return address;  }
  public void setAddress(String a) { address = a;     }

  public final String getName()       { return name; }
  public final void setName(String a) { name = a;    }

  public final String getAccountUserName()       { return accountUserName; }
  public final void setAccountUserName(String a) { accountUserName = a;    }

  public final String getAccountPassword()       { return accountPassword; }
  public final void setAccountPassword(String a) { accountPassword = a;    }

  public final String getPop()        { return pop; }
  public final void setPop(String a)  { pop = a;    }

  public final int getSSLPopPort()   { return sslPopPort; }
  public final int getSSLSMTPPort()  { return sslSMTPPort;}

  public final void setSSLPOPPort(int p)   { sslPopPort = p; }
  public final void setSSLSMTPPort(int p)  { sslSMTPPort = p;}

  public final int getPopPort()       { return popPort; }
  public final void setPopPort(int a) { popPort = a;    }

  public final String getSMTP()       { return smtp; }
  public final void setSMTP(String a) { smtp = a;    }

  public final int getSMTPPort()       { return smtpPort; }
  public final void setSMTPPort(int a) { smtpPort = a;    }

  public final boolean getUseToReadMails()          { return useToRead; }
  public final void setUseToReadMails(boolean doIt) { useToRead = doIt; }

  public final boolean getUseToSendMails()          { return useToSend; }
  public final void setUseToSendMails(boolean doIt) { useToSend = doIt; }

  public final boolean getAllowUnsecurePasswordProtocols()          { return this.allowUnsecurePasswordProtocols; }
  public final void setAllowUnsecurePasswordProtocols(boolean doIt) { this.allowUnsecurePasswordProtocols = doIt; }

  /** @return true if this address is a snowraver account
  */
  public final boolean isSnowraverAccount()
  {
    return address.toLowerCase().endsWith("snowraver.org");
   //     || address.toLowerCase().endsWith("localhost");      // for tests
  }


   //
   // RSA
   //
   private String rsan = "";
   private String rsad = "";
   private String rsae = "";
   private int rsalength = 0;


   public final String getRSA_n() { return rsan; }
   public final void setRSA_n(String n) { rsan=n; }
   public final String getRSA_e() { return rsae; }
   public final void setRSA_e(String e) { rsae=e; }
   public final String getRSA_d() { return rsad; }
   public final void setRSA_d(String d) { rsad=d; }
   public final int getRSA_Length() { return rsalength; }
   public final void setRSA_Length(int l) { rsalength=l; }

   /** secure close.
      Important Should be called at the end in order to delete the messages marked as delete.
   */
   public final synchronized void closePOPConnection()
   {
     try         
     {
       if( securePopConnection!=null && securePopConnection.isAlive())
       {
         securePopConnection.terminateSession();
       }
     }
     catch(Exception e)
     {
        e.printStackTrace();
     }
   }

   public final String toString() { return "Mail account "+this.getAddress(); }

   /** manages a POP connection.
      Caution: this looks if the connection is alive, sending a NOOP
        => retrieve this once
   */
   public final synchronized SecurePopConnection getCheckedPopConnection() throws Exception
   {
       if( securePopConnection!=null && securePopConnection.isAlive())
       {
           return securePopConnection;
       }
       else
       {
           try
           {
              securePopConnection = new SecurePopConnection(this);
              return securePopConnection;
           }
           catch(BadPasswordException e)
           {
              throw new Exception("Bad Password for "+this.address+"\n Error="+e.getMessage());
           }
       }
   }


   /** manages a secure SMTP connection
    */
   public final synchronized SecureSmtpConnection getSMTPConnection() throws Exception
   {
       if( secureSmtpConnection!=null && secureSmtpConnection.isAlive())
       {
           return secureSmtpConnection;
       }
       else
       {
           // host name required
           String hname = "?";
           try
           {
              InetAddress local = InetAddress.getLocalHost();
              hname = local.getHostName();
           }      
           catch(Exception ignored){}

           try
           {
              secureSmtpConnection = new SecureSmtpConnection(this,
                hname,
                false
              );
              return secureSmtpConnection;
           }
           catch(BadPasswordException ee)
           {
              throw new Exception("Bad Password for "+this.address
                 +"\n Error="+ee.getMessage());
           }
       }
   }


  /** load from a vector
   */
  public final void createFromVectorRepresentation(Vector v) throws VectorizeException
  {           
     int ver = (Integer) v.elementAt(0);
     
     if(ver==6)
     {
         address   = (String) v.elementAt(1);
         name      = (String) v.elementAt(2);
         pop       = (String) v.elementAt(3);
         smtp      = (String) v.elementAt(4);
         accountUserName = (String) v.elementAt(5);
         accountPassword = (String) v.elementAt(6);
         useToRead = (Boolean) v.elementAt(7);
         useToSend = (Boolean) v.elementAt(8);
         popPort  = (Integer) v.elementAt(9);
         smtpPort = (Integer) v.elementAt(10);
         rsan     = (String) v.elementAt(11);
         rsad     = (String) v.elementAt(12);
         rsae     = (String) v.elementAt(13);
         rsalength = (Integer) v.elementAt(14);
         accountLog.createFromVectorRepresentation((Vector) v.elementAt(15));
         this.sslPopPort = (Integer) v.elementAt(16);
         this.sslSMTPPort = (Integer) v.elementAt(17);
         useSSL_POP = (Boolean) v.elementAt(18);
         useSSL_SMTP = (Boolean) v.elementAt(19);
         if(v.size()>20)
         {
           signOutgoingMails = (Boolean) v.elementAt(20);
         }
         if(v.size()>21)
         {
           this.allowUnsecurePasswordProtocols = (Boolean) v.elementAt(21);
         }

     }
  }


  private boolean useSSL_POP = false;
  private boolean useSSL_SMTP = false;

  public final boolean useSSLPOP() { return useSSL_POP;}
  public final boolean useSSLSMTP() { return useSSL_SMTP;}

  public final void setUseSSLPOP(boolean b) { useSSL_POP = b; }
  public final void setUseSSLSMTP(boolean b) { useSSL_SMTP = b; }


  // save in a vector
  //
  public final Vector<Object> getVectorRepresentation() throws VectorizeException
  {
    Vector<Object> v = new Vector<Object>();
    v.addElement(6); // version
    v.addElement(address);
    v.addElement(name);
    v.addElement(pop);
    v.addElement(smtp);
    v.addElement(accountUserName);
    v.addElement(accountPassword);
    v.addElement(useToRead);
    v.addElement(useToSend);
    v.addElement(popPort);
    v.addElement(smtpPort);
    v.addElement(rsan);
    v.addElement(rsad);
    v.addElement(rsae);
    v.addElement(rsalength);
    if(storeAccountLogInVectorRepresentation==false)
    {
       accountLog.maxLength = 5000;
       accountLog.checkLength();
    }
    v.addElement(accountLog.getVectorRepresentation());  // 15

    v.addElement(this.sslPopPort);
    v.addElement(this.sslSMTPPort);
    v.addElement(this.useSSL_POP);
    v.addElement(this.useSSL_SMTP);
    v.addElement(signOutgoingMails);   // 20
    v.addElement(allowUnsecurePasswordProtocols);
    return v;
  }
}
