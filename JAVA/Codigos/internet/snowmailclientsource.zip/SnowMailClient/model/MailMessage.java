package SnowMailClient.model;

import snow.utils.storage.*;
import SnowMailClient.utils.*;
import snow.utils.gui.*;
import snow.concurrent.*;
import SnowMailClient.*;
import SnowMailClient.crypto.*;
import SnowMailClient.model.multipart.*;
import SnowMailClient.Language.Language;
import SnowMailClient.SpamFilter.WordStatistic;
import SnowMailClient.model.events.MailMessageChangeListener;
import SnowMailClient.GnuPG.GnuPGLink;
import SnowMailClient.GnuPG.model.*;

import java.util.*;
import java.text.*;
import java.io.*;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
                     
/** In the model, the message is as it was received: A STRING and nothing else
    this string contains the header, body and attachments, in mime format or whatever.
    At each recreation from vec rep, it is reparsed and restored.

      message = header + body     

    When edited, the body changes,
    after edition, one must call recomposeMessageFromParts()
*/              
public final class MailMessage implements Vectorizable
{           
  public boolean debug = false;

  // Only this part of the mail is stored, the rest is recomposed at each recreation
  //

  private String completeContent;

  // general props, snowmail specific, NOT in the header
  private AppProperties properties = new AppProperties();

  //
  // parsed from complete content
  //

  private String messageBody   = "";

  // from, to, subject, ... are in the header of received and sended mails.
  private Header header = new Header();

  // attachements, ...
  private MimeTreeModel mimeTreeModel = new MimeTreeModel(new MimePart());


  // Other non persistent data
  //

  private Vector<MailMessageChangeListener> changeListeners = new Vector<MailMessageChangeListener>();

  private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy  HH':'mm", Language.getInstance().getLocale());

  // PUBLIC: used in the view to keep selection
  public boolean selectedInView = false;

  /** create this mail as the parsed passed content
  */             
  public void parse(String completeContent)
  {
    if(debug) System.out.println("\nMailMessage Parse debug:");
    header.removeAllEntries();
                     
    this.completeContent = completeContent;
    this.parse(completeContent, true);
  } 

  // Header
  //

  public Header getHeader() { return header; }
                                    
  public Address getFromAddress()      { return new Address(header.getEntryValue("from","?")); }
  public Vector<Address> getToAddresses()    { return Address.parseAddressList(header.getEntryValue("to","?")); }
  public String getToAddressesText()   { return header.getEntryValue("to","?"); }

  public String getSubject()        { return header.getEntryValue("subject","?"); }
  public String getMessageID()      { return header.getEntryValue("message-id","?"); }
  public String getDateFieldFormHeader()  { return header.getEntryValue("date","?"); }
  public String getContentType()    { return header.getEntryValue("content-type", ""); }
  public int getSize()              { return completeContent.length(); }

  /** @return true if the content is pure HTML
     either if his content type is explicitely set to be text/html
     or if it starts with <html> or <!  
  */
  public boolean lookIfContentIsHTML()
  {
    String ct = header.getEntryValue("content-type", "").toUpperCase();
    if(ct.indexOf("TEXT/HTML")!=-1) return true;
                      
    // just a small test... show if the mails starts with <html>
    if(StringUtils.startsWithIgnoresCaseAndBlanks( this.getMessageBody(), "<HTML")) return true;
    if(StringUtils.startsWithIgnoresCaseAndBlanks( this.getMessageBody(), "<x-HTML")) return true;
    if(StringUtils.startsWithIgnoresCaseAndBlanks( this.getMessageBody(), "<!")) return true;

    // definitely not...
    return false;
  }
  
  /** only if the WHOLE content is encrypted !
  
  */
  public boolean lookIfContentIsPGPEncrypted()
  {  
    if( messageBody.length()<100) return false;

    if( this.messageBody.substring(0,80).toUpperCase().indexOf("-----BEGIN PGP MESSAGE-----")==-1) return false;
    if( this.messageBody.substring(messageBody.length()-80).toUpperCase().indexOf("-----END PGP MESSAGE-----")==-1) return false;
                        
    return true;
  }

  public boolean lookIfContentIsPGPSigned()
  {
    if( messageBody.length()<100) return false;

    if( this.messageBody.substring(0,80).toUpperCase().indexOf("-----BEGIN PGP SIGNED MESSAGE-----")==-1) return false;
    if( this.messageBody.substring(messageBody.length()-80).toUpperCase().indexOf("-----END PGP SIGNATURE-----")==-1) return false;

    return true;
  }

  // Properties
  //

  public boolean getIsNew()       { return properties.getBoolean("isNew", true); }

  public long getParsedMessageTime() { return properties.getLong( "parsedMessageTime", 0L); }

  public boolean getHasBeenSent()       { return properties.getBoolean( "hasBeenSent", false); }
  public void setHasBeenSent(boolean b)
  {                  
    properties.setBoolean( "hasBeenSent", b);
    this.notifyChangeListeners(MailMessageChangeListener.MailMessageChangeType.PROPERTY, "has been sent="+b);
  }
  public boolean getHasBeenReceived()       { return properties.getBoolean( "HasBeenReceived", false); }
  public void setHasBeenReceived(boolean b)
  {
    properties.setBoolean( "HasBeenReceived", b);
    this.notifyChangeListeners(MailMessageChangeListener.MailMessageChangeType.PROPERTY, "has been received="+b);
  }          

  public void setSPAM(boolean is)
  {
    properties.setBoolean( "isSpam", is);
    if(is) properties.setBoolean( "isHam", false);
    this.notifyChangeListeners(MailMessageChangeListener.MailMessageChangeType.PROPERTY, "is spam="+is);
  }                                  
  public boolean getIsSPAM()  {  return properties.getBoolean("isSpam", false); }

  public void setHAM(boolean is)
  {
    properties.setBoolean( "isHam", is);
    if(is) properties.setBoolean( "isSpam", false);
    this.notifyChangeListeners(MailMessageChangeListener.MailMessageChangeType.PROPERTY, "is ham="+is);
  }
  public boolean getIsHAM()
  {
    if( properties.getBoolean("isHam", false) ) return true;
    if(getIsSPAM()) return false;
    if( SnowMailClientApp.getInstance().getAddressBook().hasAddress(getFromAddress().getMailAddress()) )
    {     
      return true;
    }
    return false;
  }
  
  /** if the spam probability is great but the message is HAM, we have a false positive !!
      this must be displayed with a BIG warning !      
  */
  public boolean getIsFalsePositive()
  {
     double prob = this.getSPAMProbability();
     return WordStatistic.isSpam(prob) && getIsHAM();
  }

  public void setSPAMProbability(double p) 
  { 
    properties.setDouble( "SPAMProbability", p);
    this.notifyChangeListeners(MailMessageChangeListener.MailMessageChangeType.PROPERTY, "spam prob="+p);
  }  
  
  public double getSPAMProbability() 
  {                                                                                
    return properties.getDouble("SPAMProbability", -1);    
  }



  /** Reset the new state.
      This means either that the mail was send or read
  */                
  public void setIsNoMoreNew()
  { 
    properties.setBoolean("isNew", false);
    this.notifyChangeListeners(MailMessageChangeListener.MailMessageChangeType.PROPERTY, "is no more new");
  }  
  
  public void setMustBeSigned(boolean must)
  {
    System.out.println("Message must be signed");
    properties.setBoolean("mustBeSigned", must);
    this.notifyChangeListeners(MailMessageChangeListener.MailMessageChangeType.PROPERTY, "must be signed="+must);
  }             
  
  public boolean getMustBeSigned() 
  { 
    return properties.getBoolean("mustBeSigned", false); 
  }
  
  public void setMustBeEncrypted(boolean must)
  { 
    properties.setBoolean("mustBeEncrypted", must);
    this.notifyChangeListeners(MailMessageChangeListener.MailMessageChangeType.PROPERTY, "must be enctypted="+must);
  } 
  
  public boolean getMustBeEncrypted() { return properties.getBoolean("mustBeEncrypted", false); }         
  
  public void setHasBeenEncrypted(boolean was)  
  {
    properties.setBoolean("hasBeenEncrypted", was);
    this.notifyChangeListeners(MailMessageChangeListener.MailMessageChangeType.PROPERTY, "was enctypted="+was);
  }

  private void setHasBeenSigned(boolean was)                                                      
  {
    properties.setBoolean("hasBeenSigned", was);
    this.notifyChangeListeners(MailMessageChangeListener.MailMessageChangeType.PROPERTY, "was signed="+was);
  }


  public boolean getHasBeenEncrypted() { return properties.getBoolean("hasBeenEncrypted", false); }
  public boolean getHasBeenSigned(  )  { return properties.getBoolean("hasBeenSigned", false); }

  /** + has been sent and signed/encrypted
      + has been decrypted  
  */
  public String getStatusRemark()
  {    
      StringBuffer rem = new StringBuffer();
        
      // Show a message if the message has been sent
      if(getHasBeenSent())
      {
        
        if(this.getHasBeenEncrypted() && this.getHasBeenSigned())
        {                     
           rem.append( Language.translate("Message has been sent signed and encrypted")); 
        }
        else if(this.getHasBeenEncrypted())
        {
           rem.append( Language.translate("Message has been sent encrypted"));
        }
        else if(this.getHasBeenSigned())
        {
           rem.append( Language.translate("Message has been sent signed"));
        }
        else
        {
           rem.append("\n"+ Language.translate("Message has been sent"));
//             " on %", dateFormat.format(new Date(getParsedMessageTime()))));
        } 
      }
      else if(getHasBeenReceived())
      {
        if( this.getHasBeenDecrypted() )
        {
           rem.append( Language.translate("Message has been decrypted") );
        }
        //return "Message has been received";
        //return "";
      }
      else
      {
        rem.append( Language.translate("Message has not been sent yet") );
      }

      String signatureVerifications = properties.getStringLCK("signatureVerifications","");
      if(signatureVerifications.length()>0)
      {
         rem.append("\n"+signatureVerifications);
      }

      return rem.toString().trim();
  }

  /** set the actual date as the message date.
      should be reset each time when the message is edited
      and when it is send.
  */
  public void setActualDate()
  {
    header.setEntryOverwrite("date", MailMessageUtils.msgDateFormat(new Date()));
    recomposeMessageFromParts();
    this.notifyChangeListeners(MailMessageChangeListener.MailMessageChangeType.HEADER, "Date changed");
  }
                   
  /** add a read and a delivery receipt request
  */
  public void setRequestNotification_(Address address)
  {                        
    // Read receipt
    header.setEntryOverwrite("Disposition-Notification-To", address.toString());

    // Delivery receipt
    header.setEntryOverwrite("Return-Receipt-To", address.toString());
    recomposeMessageFromParts();
    this.notifyChangeListeners(MailMessageChangeListener.MailMessageChangeType.HEADER, "return address set to "+address);
  }


  public void setIsReplyMessage(String id_original)
  {
     header.setEntryOverwrite("In-Reply-To", id_original);
     header.setEntryOverwrite("References", id_original);
     this.notifyChangeListeners(MailMessageChangeListener.MailMessageChangeType.HEADER, "Reply to message id set = "+id_original);
  }
  
  
  /** this only sets the header.
      called from the view when only the header is edited, to reflect the changes in the 
      table view without to have to recompose the message !
  */
  public void setMessageHeader(Address from, Vector<Address> tos, String subject)
  {
      String fromString = "";
      if(from!=null) 
      { 
        fromString = from.toString();
      }              

      header.setEntryOverwrite("From",    fromString);
      StringBuffer toBuffer = new StringBuffer();
      if(tos!=null)
      {
        for(int i=0; i<tos.size(); i++)
        {
          toBuffer.append(tos.elementAt(i).getMailAddress());
          if(i<tos.size()-1) toBuffer.append("; ");
        }
      }
      header.setEntryOverwrite("To",      toBuffer.toString());
      header.setEntryOverwrite("Subject", subject);
      header.setEntryOverwrite("Date", MailMessageUtils.msgDateFormat(new Date()));
      properties.setLong("parsedMessageTime", new Date().getTime());

      if(from!=null)
      {
        header.setEntryOverwrite("Message-ID", MailMessageUtils.createMessageID(from));
      }         
      header.setEntryOverwrite("Reply-To", fromString);
      header.setEntryOverwrite("Return-Path", fromString);
      
      this.notifyChangeListeners(MailMessageChangeListener.MailMessageChangeType.HEADER, "header set");
  }

  /** Called from the editor.
      Cause a recomposition of the body or a reparsing in the mime case.

      @param charset to encode the string in 7 bit bytes        
  */              
  public void setMessage(Address from, Vector<Address> tos, String subject, String body)
  {
    if(this.mimeTreeModel.isMimeMessageFormat())
    {                   
      mimeTreeModel.setMessagePlainText(from, tos, subject, body);
      // ###  this object header is just ignored !!!
      // ### => getDate, from, to are to be reparsed...                                                     
      completeContent = mimeTreeModel.createMessageStringContent();
      this.parse(completeContent);
    }
    else
    {                        
      header.setEntryOverwrite("From",    from.toString());
      StringBuffer toBuffer = new StringBuffer();                                                 
      for(int i=0; i<tos.size(); i++)
      {
        toBuffer.append(tos.elementAt(i).getMailAddress());
        if(i<tos.size()-1) toBuffer.append("; ");
      }
      header.setEntryOverwrite("To",      toBuffer.toString());
      header.setEntryOverwrite("Subject", subject);                                                    
      header.setEntryOverwrite("Date", MailMessageUtils.msgDateFormat(new Date()));
      
      properties.setLong("parsedMessageTime", new Date().getTime());

      header.setEntryOverwrite("Message-ID", MailMessageUtils.createMessageID(from));
      header.setEntryOverwrite("MIME-Version", "1.0");       



      header.setEntryOverwrite("X-Mailer", "SnowMail 1.0");
      header.setEntryOverwrite("Reply-To", from.toString());
      header.setEntryOverwrite("Return-Path", from.toString());

/*
      // not necessary
      header.setEntryOverwrite("X-Priority", "3 (Normal)");
      header.setEntryOverwrite("X-MSMail-Priority", "Normal");
      header.setEntryOverwrite("Importance", "Normal");
 */


      // ### put in the UI
      // this CAUSE A NOTIFICATION SENT for each received mail (if destinee client support&activated  them)
      setRequestNotification_(from);

      // THE cencoding is only made at the transport level !!!

      //this.messageBody = MailMessageUtils.encodeMessageQuotedPrintable(body, charset);
      //header.setEntryOverwrite("Content-Type", "text/plain;\r\n\tcharset=\""+charset+"\"");
      //header.setEntryOverwrite("Content-Transfer-Encoding", "8bit");  // 8bit

      this.messageBody = body;

      recomposeMessageFromParts();
    }
                                                                                                              
    this.notifyChangeListeners(MailMessageChangeListener.MailMessageChangeType.MESSAGE, "message set");
  }
  

  /** call this when something changed, to save changes in the model
  */
  private void recomposeMessageFromParts()
  {      
      this.completeContent =
           header.toString()
         + "\r\n"
         + messageBody;
  }
                                                                 
  public boolean isEditable(){ return properties.getBoolean("isEditable", false); }
  public void setEditable(boolean is) 
  { 
    properties.setBoolean("isEditable", is);
    this.notifyChangeListeners(MailMessageChangeListener.MailMessageChangeType.PROPERTY, "is editable="+is);
  }
                                                                                      
  
  /** @return true if the text was found
  */
  public boolean searchText(String textUP)
  {
     MimePart[] partsFound = this.mimeTreeModel.searchInTextParts(textUP);
     if(partsFound.length>0)
     {
       return true;
     }                      

     if(this.messageBody.toUpperCase().indexOf(textUP)>=0)
     {
       return true;
     }

     // not found
     return false;
  }

  /** used to regenerate content
  *
  public String getHeaderText()
  {
     return header.toString();
  }*/
  

  /** @return the message body
  */
  public String getMessageBody()
  {
    return messageBody;
  }
  
  /** this is the complete content of the mail message (header + body)
      WITHOUT charset conversions... as it was received !
  */
  public String getCompleteContentAsString()
  {
    return completeContent;
  }  

                                                                                                               

  /** this is the complete content to send
      it is encoded for sending      
      these bytes can be safely recomposed in string and decoded using us-ascii (7bits).  
      they can be sent as is !
  */                                
  public byte[] getCompleteContentToSend(GnuPGLink gpg, GnuPGKeyID signingKid, byte[] signingPass, Interrupter interrupter) throws Exception
  {
    ByteArrayOutputStream buffer = new ByteArrayOutputStream(1024);
    if(this.getMimeTree().isMimeMessageFormat())
    {
      if(signingKid!=null)
      {
        throw new Exception("Signing is currently not supported for MIME messages");
      }
      
      buffer.write( mimeTreeModel.getContent_For_Sending() );

      /*
      buffer.write(this.header.to_ASCII_String().getBytes("us-ascii"));
      buffer.write("\r\n".getBytes("us-ascii"));
      // no charset, each part has already do the job
      buffer.write(this.messageBody.getBytes("us-ascii"));
      */

    }
    else
    {

      String encodingCharset = CharsetUtils.getMinimalEncodingCharset(messageBody);
      byte[] messageBodyBytes = messageBody.getBytes(encodingCharset);
      header.setEntryOverwrite("Content-Type", "text/plain;\r\n\tcharset=\""+encodingCharset+"\"");

      if(signingKid!=null)
      {
        //
        ByteArrayInputStream bin = new ByteArrayInputStream((byte[]) messageBodyBytes.clone());
        messageBodyBytes = gpg.sign(bin, signingKid, signingPass, interrupter);
        setHasBeenSigned(true);                
      }

      boolean useQuotedPrintable = !MailMessageUtils.is7Bits(messageBodyBytes);
      
      if(useQuotedPrintable)   
      {           
        header.setEntryOverwrite("Content-Transfer-Encoding", "quoted-printable");  // 8bit
        messageBodyBytes = MailMessageUtils.encodeMessageQuotedPrintable(messageBodyBytes);
      }
      else
      {
        header.setEntryOverwrite("Content-Transfer-Encoding", "8bit");  // 8bit
      }
                         
      buffer.write(this.header.to_ASCII_String().getBytes("us-ascii"));
      buffer.write("\r\n".getBytes("us-ascii"));
      buffer.write(messageBodyBytes);
    }
    return buffer.toByteArray();
  }

  /** non empty if this is a mime tree
  */
  public MimeTreeModel getMimeTree()             
  {
    return mimeTreeModel;
  }
  
  /** parse the header and (optional) the body and mime multiparts
      called at the creating of the message from its vector representation and
      when created the first time from the received content
  */
  private void parse(String mess, boolean parseBody)
  {              
     NumberedLineReader reader = new NumberedLineReader( mess );
                      
     try             
     {                 
        Header.parseHeader(reader, header);

        if(parseBody)
        {
           // message content
           StringBuffer sb = new StringBuffer();
           String fromLine = reader.readLine();
           while(fromLine!=null)
           {
              sb.append(fromLine);
              sb.append("\n");
              fromLine = reader.readLine();
           }
           
           messageBody = sb.toString();     

           // decode the content (byte => string)
           //  ( charset, quoted-printable, base64, 8bit, ...)
           messageBody = decodeContent(messageBody);

           if(debug)
           {
             System.out.println("================ Body part ("+messageBody.length()+") chars");
           }

           if(MimeUtils.isMultipart(this))
           {
              mimeTreeModel.clearMimeTree(); // delete whole tree...

              MimePart rootPart = mimeTreeModel.getRootPart();
              rootPart.debug = debug;
              rootPart.parseMimeTree(
                new NumberedLineReader(mess),
                "#no#boundary%&/?",  // [Jan2006]: not empty string ! because it will block when parsing 
                                    //mails whose full content is an attachme
                false, 0);
           }

        }
        reader.close();
     }
     catch(Exception e)
     {

        messageBody = mess;
        error = e.getMessage();
        System.out.println("Mail Parse Error: "+e.getMessage());
        System.out.println(" from    = "+this.getFromAddress());
        System.out.println(" to      = "+this.getToAddresses());
        System.out.println(" subject = "+this.getSubject());

        if(e.getMessage().length()==0)
        {
          // try to know a little bit more about the error
          e.printStackTrace();
          error = "Mail parse error";
          //new Throwable("Mail parse error trace").printStackTrace();  // see the caller...
        }
        else
        {
          // DEBUG !
          e.printStackTrace();
        }
     }

     // post analysis
     String dateString = this.getDateFieldFormHeader();
     if(dateString.equals("?"))
     {
        // set the actual date
        header.setEntryOverwrite("date", MailMessageUtils.msgDateFormat(new Date()));
        recomposeMessageFromParts();
     }

     try
     {
       properties.setLong("parsedMessageTime",
           MailMessageUtils.parseDateFromString(dateString).getTime());
     }
     catch(Exception e)
     {
       properties.setLong("parsedMessageTime", 0L);
       if(!dateString.equals("?"))
       {                      
         System.out.println("Cannot parse date from '"+dateString+"'");
       }
     }
  }  
  
  String error = null;  
  public String getErrorMessage() 
  {
    return error;
  }                                
  
  public boolean hasParseError() { return  error!=null; }
  



  /** decodes the base64 and quoted printable formats
  */                   
  private String decodeContent(String text) throws Exception
  {
    String contentTransferEncoding = header.getEntryValue("content-transfer-encoding", "").toUpperCase();
    String cs = HeaderUtils.getHeader_Charset_entry(header);
    if(debug)
    {
      System.out.println("MailMessage decode content ct="+contentTransferEncoding+", cs="+cs);
    }

    if(contentTransferEncoding.indexOf("QUOTED-PRINTABLE")>=0)
    {
      return MailMessageUtils.decodeQuotedPrintable(text, cs);
    }
    else if(contentTransferEncoding.indexOf("8BIT")>=0)
    {
      try
      {
        // the format of the default encoded bytes at reception from server "utf-8"
        //byte[] bytes = text.getBytes();  // use the same encoding ?
          
        if(!CharsetUtils.isEncodingSupported(text,"iso-8859-1"))
        {

          if(debug)   
          {
            System.out.print("===== Bad format iso-8859-1 for text =====");
            int pos = CharsetUtils.getFirstEncodingError(text, "iso-8859-1");
            if(pos>=0)
            {
              char errorChar = text.charAt(pos);
              System.out.print("   char= ' "+errorChar+" ', code="+((int) errorChar));
            }
            System.out.println(", from= " + this.getFromAddress()+", subj= "+this.getSubject());

            System.out.println(""+ text + "===== end =====");
          }

          //just return the text. It may already have been decoded !
          return text;
        }

        byte[] bytes = text.getBytes("iso-8859-1");  // Since [June2005]
        String dec = new String(bytes, cs);

        return dec;

      }
      catch(Exception e)
      {
        return text;
      }
    }
    else if(contentTransferEncoding.indexOf("BASE64")>=0)
    {
      try
      {                                                 
        return new String(Utilities.decodeBase64(text), cs);
      }
      catch(Exception e)
      {
        throw new Exception("Error decoding part base 64 content:\n "+e.getMessage());
      }
    }
    else
    {
      return text;
    }
  }



  /** this is used in CTRL+C or printing
  */
  public String getTextRepresentationForPrinting()
  {  
    StringBuffer sb = new StringBuffer();
    sb.append("From:    \t"+this.getFromAddress().toString());
    sb.append("\nTo:    \t"+this.getToAddressesText());
    sb.append("\nSubject:\t"+this.getSubject());
    sb.append("\nDate:   \t"+this.getDateFieldFormHeader());
    sb.append("\n\n");  

    if(this.getMimeTree().isMimeMessageFormat())
    {
      MimePart mp = getMimeTree().getFirstPlainTextPart();
      if(mp!=null)
      {
        sb.append(""+mp.getBodyAsText());
      }
      else
      {
        sb.append(this.getMessageBody());
      }
    }
    else
    {
      sb.append(this.getMessageBody());
    }

    return sb.toString();
  }

  //
  // Listeners (normally only the parent folder is interrested in changes...)
  //
  
  public void addChangeListener(MailMessageChangeListener mcl)
  {
    this.changeListeners.add(mcl);
  }
                     
  public void removeChangeListener(MailMessageChangeListener mcl)
  {
    this.changeListeners.remove(mcl);
  }
  
  private void notifyChangeListeners(MailMessageChangeListener.MailMessageChangeType type, String detail)
  {              
     // do a copy of the listeners to decouple them from the vector
     // because they may perform operation on the vector in the notify loop (remove listener)
     // and caus concurrent modification exceptions
     MailMessageChangeListener[] mcls = null;
     synchronized(changeListeners)
     {
       mcls = (MailMessageChangeListener[]) changeListeners.toArray(new MailMessageChangeListener[changeListeners.size()]);
     }
     for(MailMessageChangeListener mcl : mcls)
     {
        mcl.mailMessageChanged(this, type, detail);
     }
  }

  /** THIS IS CALLED FROM OUTSIDE to notify that this message is currently being edited.
     For performance reason, the message is NOT actual, its new conetnt is only set later,
     when the editor has another message or when save is called.

     This is called at each key entered in MailView...
  */
  public void notifyThatThisMessageIsBeingEditedNow(String detail)
  {
     // do a copy of the listeners to decouple them from the vector
     // because they may perform operation on the vector in the notify loop (remove listener)
     // and caus concurrent modification exceptions
     MailMessageChangeListener[] mcls = null;
     synchronized(changeListeners)
     {    
       mcls = (MailMessageChangeListener[]) changeListeners.toArray(new MailMessageChangeListener[changeListeners.size()]);
     }
     for(MailMessageChangeListener mcl : mcls)
     {
       mcl.mailMessageChanged(this, MailMessageChangeListener.MailMessageChangeType.IN_EDITION, detail);
     }
  } 

  // GPG operations
  //
   

  /** this reparse the decrypted message and set mark it as decrypted
  */
  public void setDecryptedMessage(String decryptedMessage)
  {
     this.parse(decryptedMessage);
     properties.setBoolean( "HasBeenDecrypted", true);
     this.notifyChangeListeners(MailMessageChangeListener.MailMessageChangeType.DECRYPTED, "decrypted message");  // for the mail view
     this.notifyChangeListeners(MailMessageChangeListener.MailMessageChangeType.HEADER, "decrypted message");    // for the folder view
  }

  /** @return true if this message has been received encrypted and has been decrypted
  */                                                                                 
  public boolean getHasBeenDecrypted()
  {
     return properties.getBoolean( "HasBeenDecrypted", false);
  }


  public void setSignatureVerification(Vector<SignatureVerificationResult> res)
  {
     StringBuffer signaturesText = new StringBuffer();
     if(res.size()==0)
     {
       signaturesText.append(Language.translate("NO SIGNATURES FOUND"));
     }

     for(SignatureVerificationResult sign: res)
     {
       signaturesText.append("\n"+sign.toString());
     }
     properties.setStringLCK("signatureVerifications", signaturesText.toString().trim());
     this.notifyChangeListeners(MailMessageChangeListener.MailMessageChangeType.DECRYPTED, "signature verification");  // for the mail view
  }
    
    
  //
  // Vectorizable
  //

  public MailMessage()
  {
  }
  
  public Vector<Object> getVectorRepresentation() throws VectorizeException
  {

    Vector<Object> rep = new Vector<Object>();
    rep.addElement(2);
    rep.addElement(completeContent);
    rep.addElement(properties.getVectorRepresentation());

    return rep;
  }
  
  /** don't notify change listeners...
  */
  public void createFromVectorRepresentation(Vector<Object> v) throws VectorizeException
  {
    int version = (Integer) v.elementAt(0);
    if(version>=1)                     
    {
      completeContent = (String) v.elementAt(1);
      properties.createFromVectorRepresentation((Vector) v.elementAt(2));
      this.parse(completeContent, true);

      if(version>=2)
      {
       // isNew = ((Boolean) v.elementAt(3)).booleanValue();
      }         
    }
    else
    {
      throw new VectorizeException(Language.translate("bad version %",""+version));
    }
  }



} // MailMessage
