package SnowMailClient.model;

import SnowMailClient.utils.*;

public final class HeaderEntry
{
  String key;
  String value;

  public HeaderEntry(String key, String value)
  {
    this.key   = key;
    this.value = value;
  } // Constructor
  
  public String getKey() { return key; }
  public String getValue() { return value; }
  
  public boolean isEquals(String _key)
  {
     return _key.equalsIgnoreCase(key);
  }
  
  public void setValue(String val)
  {
     this.value = val;
  }

  public String toString()
  {
     return key+": "+value;
  }

  public String to_ASCII_String()
  {  
     if(key.equalsIgnoreCase("subject"))
     {
        //CharsetUtils.getMinimalEncodingCharset(value);
        return key+": "+MailMessageUtils.encodeLine_QuotedPrintable(value);
     }
     return key+": "+value;
  }


} // HeaderEntry
