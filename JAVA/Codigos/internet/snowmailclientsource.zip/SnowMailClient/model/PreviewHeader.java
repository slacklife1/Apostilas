package SnowMailClient.model;

import SnowMailClient.model.accounts.MailAccount;
import SnowMailClient.utils.MailMessageUtils;
import snow.concurrent.*;
import java.util.concurrent.*;
import java.util.Date;

/** 
    Special: In the preview mode, only headers are downloaded from the server
    the associated mailAccount is stored as reference.
    TODO: preview n first lines...
    
    The folowing keys are always present:  date,from,to,subject 
    they ca be directly retrieved for exmample :

       getEntryValue("subject", "<NO SUBJECT FIELD>");
*/
public final class PreviewHeader extends Header
{
  final private MailAccount account;
  final private String uidl;
  final private String size;
  final private long intSize;
  
  public enum State { MessageNotDownloaded, DownloadingMessage, MessageDownloaded, 
                      DownloadInterrupted, DownloadError, Deleted, Deleting }
  public State state = State.MessageNotDownloaded;
  public Throwable error = null;
  public long alreadyDownloadedSize = 0;
  
  public InterruptableTask downloadTask = null;

  public PreviewHeader(MailAccount account, String uidl, long intSize)
  {
     this.account = account;
     this.uidl = uidl;
     this.size = MailMessageUtils.formatSize(intSize);
     this.intSize = intSize;
  } // Constructor


  public final MailAccount getAccount() { return account; }
  public final String getSize()         { return size; }
  public final long getSizeInBytes()    { return intSize; }
  public final String getUIDL()         { return uidl; } 
  
  /** -1 if not parsed successfully
  */
  public long getParsedDate()
  {                           
     try
     {
       Date d = MailMessageUtils.parseDateFromString( getEntryValue("date", "?") );
       if(d==null) return -1;
       return d.getTime();
     }
     catch(Exception e)
     {
       System.out.println("Invalid date in header : "+getEntryValue("date", "?"));
       return -1;
     }
  }

} // PreviewHeader
