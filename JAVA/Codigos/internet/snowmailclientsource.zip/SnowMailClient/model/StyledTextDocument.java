package SnowMailClient.model;

import snow.utils.storage.*;

import java.util.*;
import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;


/** a document container for styled textpanes.
    The document is the member variable doc.
    This is actually only used for outputs (logs) => no undo...
    See MailView for a document with undo function.                                              
*/
public final class StyledTextDocument
{

   public final DefaultStyledDocument doc = new DefaultStyledDocument();


   public int maxLength = 5000;  // some lines to debug


   public StyledTextDocument()            
   {                   
      //Create the styles we need.
      initializeStyles();
   }


   public void appendReadLine(String str, boolean wasEncrypted)        
   {
       if(wasEncrypted)
       {
          appendStyled("R> "+str+"\n", "readEncrypted");
       }
       else
       {
          appendStyled("R> "+str+"\n", "readNotEncrypted");
       }
   }


   public void appendSendLine(String str, boolean wasEncrypted)    
   {
       if(wasEncrypted)
       {
          appendStyled("S> "+str+"\n", "sendEncrypted");
       }
       else
       {
          appendStyled("S> "+str+"\n", "sendNotEncrypted");
       }
   }



   public void appendComment(String str)     
   {          
      appendStyled(str+"\n","comment");
   }


   public void appendError(String str)       
   {                
      appendStyled(str+"\n","error");
   }


   public void appendLine(String str)
   {          
      appendStyled(str+"\n","regular");
   }  
    
   public void appendSmallLine(String str)
   {          
      appendStyled(str+"\n","small");
   }  
       
   public void append(String str)
   {            
      appendStyled(str,"regular");
   }


   public void appendStyled(final String str, final String style)
   {
     EventQueue.invokeLater(new Runnable()
     {
      public void run()
      {
        if (doc != null)
        {
           try
           {
              doc.insertString(doc.getLength(), str, doc.getStyle(style));
           }
           catch (BadLocationException e) { e.printStackTrace(); }
           checkLength();
        }
      }
     });
   }



   public void checkLength()
   {
      if(doc.getLength()>maxLength)
      {
         try
         {
            doc.remove(0, doc.getLength()-maxLength);
         }
         catch (BadLocationException e) { e.printStackTrace();}
      }
   }



   /** recall this at each UI change. The best way is to add a property listener to the textpane and
       react on ui changes.   
       NO => this is not necessary, the styles are updated correctly !!
   */
   public void initializeStyles()
   {

      //Initialize some styles.
      Style def = StyleContext.getDefaultStyleContext().
                                     getStyle(StyleContext.DEFAULT_STYLE);

      StyleConstants.setFontSize(def, 11);

      Style regular = doc.addStyle("regular", def);
      StyleConstants.setFontFamily(def, "SansSerif");

      Style s = doc.addStyle("italic", regular);
      StyleConstants.setItalic(s, true);

      s = doc.addStyle("bold", regular);
      StyleConstants.setBold(s, true);

      s = doc.addStyle("small", regular);
      StyleConstants.setFontSize(s, 9);

      s = doc.addStyle("large", regular);
      StyleConstants.setFontSize(s, 16);

      s = doc.addStyle("readEncrypted", regular);                                                                                    
      StyleConstants.setForeground(s, new Color(0f,0.8f,0f));

      s = doc.addStyle("sendEncrypted", regular);
      StyleConstants.setForeground(s, new Color(0f,0.8f,0f));
      StyleConstants.setBold(s, true);
      StyleConstants.setItalic(s, true);

      s = doc.addStyle("comment", regular);
      StyleConstants.setForeground(s, new Color(0f,0.0f,0.8f));
      StyleConstants.setBold(s, true);
      StyleConstants.setItalic(s, true);

      s = doc.addStyle("error", regular);
      StyleConstants.setForeground(s, new Color(0.9f,0.0f,0.0f));
      StyleConstants.setBold(s, true);
      StyleConstants.setItalic(s, true);

      s = doc.addStyle("readNotEncrypted", regular);
      StyleConstants.setForeground(s, new Color(255,153,0));

      s = doc.addStyle("sendNotEncrypted", regular);
      StyleConstants.setForeground(s, new Color(255,153,0));
      StyleConstants.setBold(s, true);
      StyleConstants.setItalic(s, true);

/*      s = doc.addStyle("icon", regular);
      StyleConstants.setAlignment(s, StyleConstants.ALIGN_CENTER);
      StyleConstants.setIcon(s, new ImageIcon("images/Pig.PNG"));

      s = doc.addStyle("button", regular);
      StyleConstants.setAlignment(s, StyleConstants.ALIGN_CENTER);
      JButton button = new JButton(new ImageIcon("images/sound.PNG"));
      button.setMargin(new Insets(0,0,0,0));
      button.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
              Toolkit.getDefaultToolkit().beep();
          }
      });  
      StyleConstants.setComponent(s, button);*/
   }


}  // StyledTextDocument
