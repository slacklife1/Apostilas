package SnowMailClient.model;


import SnowMailClient.utils.MailMessageUtils;
import SnowMailClient.utils.NumberedLineReader;


import java.util.*;
import java.text.*;
import java.io.*;


/** A mail header  
*/
public class Header
{
  public static boolean debug = false;
  
  /** when a message is actually signed by XX but NOT VERIFIED !
  */
  public final static String GPG_IS_SIGNED_BY = "gpg-snowmail-is-signed-by";

  /** when a message has been signed by XX but the signature block has been removed and successfully checked
  */
  public final static String GPG_HAS_BEEN_SIGNED_BY = "gpg-snowmail-has-been-signed-by";

  private final Vector<HeaderEntry> entries = new Vector<HeaderEntry>();
  

  public Header()
  {           
  } // Constructor                                                                                                             
  
  public int getEntriesCount() { return entries.size(); }
  public HeaderEntry getEntryAt(int pos) { return entries.elementAt(pos); }
  
  public void removeAllEntries()
  {
    entries.clear();
  }     

  public void addEntry(HeaderEntry he)
  {
    entries.addElement(he);
  }
  
  public void removeEntry(HeaderEntry he)
  {
    entries.removeElement(he);
  }

  public void remove(String key)
  {
     HeaderEntry he = this.getEntry(key);
     if(he!=null) removeEntry(he);
  }



  /** do not overwrite (Received entries has multiple occurences)
  */
  public void addEntry(String key, String value)
  {
     HeaderEntry he = new HeaderEntry(key, value);
     this.addEntry(he);
  }      

  /** overwrite if existing...
  */
  public void setEntryOverwrite(String key, String value)
  {
     HeaderEntry he = getEntry(key);
     if(he!=null)
     {
       this.removeEntry(he);
     }        

     he = new HeaderEntry(key, value);
     this.addEntry(he);
  }

  /** null if not found
  */
  public HeaderEntry getEntry(String key)
  {
    for(HeaderEntry he: entries)
    {
       if(he.isEquals(key)) return he;
    }
    return null;
  }

  public boolean hasEntry(String key)
  {                 
    for(HeaderEntry he: entries)
    {
       if(he.isEquals(key)) return true;
    }
    return false;
  }   

  /** zero length if none found
  */
  public Vector<HeaderEntry> getAllEntries(String key)
  {
    Vector<HeaderEntry> found = new Vector<HeaderEntry>();
    for(HeaderEntry he: entries)
    {
       if(he.isEquals(key)) found.addElement(he);
    }
    return found;
  }

  public String getEntryValue(String key, String def)
  {
    for(HeaderEntry he: entries)
    {
       if(he.isEquals(key)) return he.getValue();
    }
    return def;
  }

  /** the header string representation. Use to_ASCII_String() for a correct sendeable representation !
  */
  public String toString()
  {            
    StringBuffer sb = new StringBuffer();
    for(HeaderEntry he: entries)
    {                        
       sb.append(he.toString()+"\r\n");
    }
    return sb.toString();
  } 

  public String to_ASCII_String()
  {
    StringBuffer sb = new StringBuffer();
    for(HeaderEntry he: entries)
    {
       sb.append(he.to_ASCII_String()+"\r\n");
    }
    return sb.toString();
  }
  
  
    /** reads the header.        
     *  stops when the first empty line occurs
     */                    
    public static void parseHeader(final NumberedLineReader in, final Header header) throws Exception
    {
      String actualTag = null;     // lowercased and trimmed!
      StringBuffer actualArgBuffer = new StringBuffer();
      boolean nextLineSameTag = false;
                                   
      String actualLine = in.readLine();
      // until end or empty line
      while(actualLine != null && !actualLine.trim().equals(""))
      {
          actualLine = actualLine.trim();
          if(debug) System.out.println("Header line = " + actualLine);

          // a tag cannot have spaces, we use this info
          //
          int pos = actualLine.indexOf(':');
          int posSp = actualLine.indexOf(' ');

          //System.out.println(actualLine);
          if(pos==-1 || (posSp>0 && posSp<pos))
          {
              if(actualTag == null)
              {
                  // [Sep2005]: accept empty headers without space after it
                  if(actualLine.startsWith("--"))
                  {
                     in.undoRead();  // LET THE NEXT PART READ THIS AS ITS FIRST LINE !!!
                     return;
                  }
                  throw new Exception("First tag empty '"+actualLine+"'");
              }
              else
              {
                 // same tag, new argument 
                 actualArgBuffer.append("\n     "+actualLine.trim());
              }
          }
          else
          {
              // new tag, store the old
              if( actualTag !=null)
              {
                  actualTag = actualTag.trim();
                  if(actualTag.equals("subject") || actualTag.equals("from") || actualTag.equals("to"))
                  {                              
                    String val = MailMessageUtils.decodeCharsetCodedArgumentFully(
                          actualArgBuffer.toString());
                    header.addEntry(actualTag, val);
                  }                 
                  else
                  {
                    header.addEntry(actualTag, actualArgBuffer.toString());
                  }
              }                    
              // the new one
              actualTag = actualLine.substring(0,pos).toLowerCase().trim();
              actualArgBuffer.delete(0, actualArgBuffer.length());
              actualArgBuffer.append(actualLine.substring(pos+1).trim());
          }                                              
                    
          // next line
          actualLine = in.readLine();
      }                                                                                   
      // don't forget to store the last
      if( actualTag !=null)                         
      {
         header.addEntry(actualTag, actualArgBuffer.toString());
      }    
    }      
  


} // Header
