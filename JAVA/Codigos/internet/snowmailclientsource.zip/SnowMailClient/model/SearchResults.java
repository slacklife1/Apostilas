package SnowMailClient.model;

import SnowMailClient.Language.Language;

import javax.swing.tree.*;
import javax.swing.*;
import java.util.*;

public final class SearchResults extends DefaultTreeModel
{

  final private DefaultMutableTreeNode root;

  public SearchResults()
  {
     super(new DefaultMutableTreeNode(
        Language.translate("Search (right-click in a folder)")));

     this.root = (DefaultMutableTreeNode) this.getRoot();
  } // Constructor


  public void addHit(final SearchHit hit)
  {                         
     this.insertNodeInto(new DefaultMutableTreeNode(hit), root, root.getChildCount());
  }                              



} // SearchResult
