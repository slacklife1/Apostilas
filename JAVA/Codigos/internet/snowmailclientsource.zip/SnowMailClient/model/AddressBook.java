package SnowMailClient.model;

import snow.utils.storage.*;
import snow.SortableTable.*;
import SnowMailClient.Language.Language;

import java.util.*;
import java.awt.EventQueue;
import java.text.*;
                            
public final class AddressBook extends FineGrainTableModel
{ 
  private final Vector<Address> addresses = new Vector<Address>();
  
  private static final String[] COLUMN_NAMES = new String[]{
     Language.translate("Name"),
     Language.translate("Address"),
     Language.translate("#Received from"), 
     Language.translate("#Sent to"), 
     Language.translate("Last use"), 
     Language.translate("Birthday"),
     Language.translate("Phone"),
     Language.translate("Street"),
     Language.translate("City") };  

  public static final SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.ENGLISH);
                          
  boolean spamlist = false;
  public AddressBook(boolean spamlist)
  {
    this.spamlist = spamlist;
  } // Constructor                                                                              
  
  /** don't add if the same is already existing 
  */
  public final void addAddress(final Address a)
  {
    addAddress(a, true);
  }

  /** @param matchMail if true, don't add the address if an address
       with the same mail is already present.
  */
  public final void addAddress(final Address a, final boolean matchMail)
  {                       
    if(matchMail 
      && a.getMailAddress().length()>0  // special case !
      && this.hasAddress(a.getMailAddress())) return;  // already in the list

    EventQueue.invokeLater(new Runnable() { public void run()
      {
        fireTableModelWillChange();
        addresses.addElement(a);
        fireTableStructureChanged();
        fireTableModelHasChanged();
      }});
  }

  public final void removeAddress(final Address a)
  {
    EventQueue.invokeLater(new Runnable() { public void run() 
    {
      fireTableModelWillChange();
      addresses.removeElement(a);
      fireTableStructureChanged();
      fireTableModelHasChanged();
    }});
  }

  public final int getNumberOfAddresses()
  {
    return addresses.size();
  }

  public final Address getAddressAt(int pos)
  {
    if(pos<0 || pos>=addresses.size()) return null;

    return addresses.elementAt(pos);
  }

  /** null if not found
  */
  public final Address getAddress(String mail)
  {
    for(Address a : addresses)
    {
       if(a.getMailAddress().equalsIgnoreCase(mail)) return a;
    }
    return null;
  }

  public final boolean hasAddress(String mail)
  {
    return getAddress(mail) != null;
  }

  /** only if found !
  */
  public final void incrementMailsReceivedFromIfPresent(Address address)
  {
    Address a = getAddress(address.getMailAddress());
    if(a==null) return;
    a.incrementMailsReceivedFrom_();
  }

  /** add the address if not found
  */
  public final void incrementMailsReceivedFrom_AddIfNotFound(Address address)
  {
    Address a = getAddress(address.getMailAddress());
    if(a==null)
    {
      a = address;
    }
    a.incrementMailsReceivedFrom_();
  }

  /** add if not found
      Sending a mail to X is a sufficient reason to put it in the addressbook
  */
  public void incrementMailsSendedTo(Address address)
  {
    Address a = getAddress(address.getMailAddress());
    if(a==null)
    {
      a = address;
    }
    a.incrementMailsSendedTo_();
  }

  // TableModel
  //

  public final int getRowCount() 
  {
    return addresses.size();
  }

  public final int getColumnCount()
  {
    if(spamlist) return 4;
    return COLUMN_NAMES.length;
  }

  public final Object getValueAt(int row, int column)
  {
     if(row<0 || row>=addresses.size()) return "??";

     Address address = this.getAddressAt(row);
     if(column==0) return address.getName();
     if(column==1) return address.getMailAddress();
     if(column==2) return address.getNumberOfMailsReceivedFrom();
     if(column==3) return address.getNumberOfMailsSendedTo();
     if(column==4)
     {
       if(address.getLastUse()==0) return "";
       return dateFormat.format(new Date(address.getLastUse()));
     }
     if(column==5)
     {                                                      
       if(address.getBirthday()==0) return "";
       return dateFormat.format(new Date(address.getBirthday()));
     }
     if(column==6) return address.getPhone();
     if(column==7) return address.getStreet();
     if(column==8) return address.getCity();
     
     return "?";
  }

  public String getColumnName(int col)
  {
    return COLUMN_NAMES[col];
  }

/*  public boolean hitForTextSearch(int row, String txt)
  {
    return true;
  }*/

  public int compareForColumnSort(int pos1, int pos2, int col)
  {
    Address address1 = this.getAddressAt(pos1);
    Address address2 = this.getAddressAt(pos2);

    if(col==0) return address1.getName().compareTo(address2.getName());
    if(col==1) return address1.getMailAddress().compareTo(address2.getMailAddress());
    if(col==2)
    {
      return compareInts(address1.getNumberOfMailsReceivedFrom(), address2.getNumberOfMailsReceivedFrom());
    }
    if(col==3)
    {
      return compareInts(address1.getNumberOfMailsSendedTo(), address2.getNumberOfMailsSendedTo());
    }
    if(col==4)
    {
      return this.compareDoubles(address1.getLastUse(), address2.getLastUse());
    }
    if(col==5)
    {
      return this.compareDoubles(address1.getBirthday(), address2.getBirthday());
    }       
    if(col==6) return address1.getPhone().compareTo(address2.getName());
    if(col==7) return address1.getStreet().compareTo(address2.getStreet());
    if(col==8) return address1.getCity().compareTo(address2.getCity());


    // should not occur
    return 0;
  }      
              
  public boolean isCellEditable(int row, int col)
  {
    return col<2 || col>=5;     
  }

  /** EDT
  */
  public void setValueAt(Object value, int row, int col)
  {
    this.fireTableModelWillChange();

    Address address = this.getAddressAt(row);
    if(col==0)
    {
      address.setName( (String) value );
    }
    else if(col==1)      
    {
      address.setMailAddress( (String) value );
    }
    else if(col==5)
    {
      try
      {
        if(value.toString().length()==0) 
        {
          address.setBirthday(0L);
        }
        else
        {
          Date date = dateFormat.parse( value.toString() );
          address.setBirthday(date.getTime());
        }                 
      }
      catch(Exception e) {}
    }
    else if(col==6)
    {
      address.setPhone( (String) value );
    }
    else if(col==7)
    {
      address.setStreet( (String) value );
    }
    else if(col==8)
    {
      address.setCity( (String) value );
    }



    this.fireTableDataChanged();
    this.fireTableModelHasChanged();
  }

                       

  public Class getColumnClass ( int column )
  {
    if(column==4) return String.class;
    if(column==5) return String.class;
    return Object.class;
  }

  /** used to select addresses in the to browser of the mail view
  */
  public void setSelectedAddresses(Vector<Address> ads)
  {
    clearRowSelection();
    for(Address ai: ads)
    {
      Address ad = this.getAddress(ai.getMailAddress());
      if(ad!=null)
      {
        ad.selected = true;
      }
    }
  }

  // Selection implementation
  //
        
  public void setRowSelection(int row, boolean isSelected)
  {
    Address item = this.getAddressAt(row);
    item.selected = isSelected;
  }

  public boolean isRowSelected(int row)
  {
    Address item = this.getAddressAt(row);
    return item.selected;
  }

  public void clearRowSelection()
  {
    for(Address a : addresses)
    {
       a.selected = false;
    }
  }

  /** sort according to the address
  */
  private void sortAddresses()
  {
    Collections.sort(addresses, new Comparator()
    {
       public int compare(Object o1, Object o2)
       {
         Address a1 = (Address) o1;
         Address a2 = (Address) o2;

         return a1.getMailAddress().compareToIgnoreCase(a2.getMailAddress());
       }
    });
  }


  // Vectorizable
  //

  public void createFromVectorRepresentation (Vector v) throws VectorizeException
  {
     int version = (Integer) v.elementAt(0);
     if(version==1)
     {
        Vector<Vector> adv = (Vector) v.elementAt(1);
        addresses.clear();
        for(Vector av: adv)
        {
           Address a = new Address(av);
           addresses.addElement( a );
        }
        sortAddresses();

        // remove double entries in the spamlist
        if(this.spamlist && addresses.size()>0)
        {
           String mad = this.getAddressAt(addresses.size()-1).getMailAddress();
           for(int i=addresses.size()-2; i>=0; i--)
           {
             String mad2 = this.getAddressAt(i).getMailAddress();
             if(mad2.equalsIgnoreCase(mad))
             {
               addresses.removeElementAt(i);
             }
             else
             {
               mad = mad2;
             }
           }
        }
     }
     else
     {
        throw new VectorizeException(Language.translate("Bad version %",""+version));
     }
  }

  public Vector<Object> getVectorRepresentation () throws VectorizeException
  {
     Vector<Object> v = new Vector<Object>();
     v.addElement(1);      // 0
     Vector<Object> adv = new Vector<Object>();
     v.addElement(adv);                 // 1
     for(Address a: addresses)
     {
       adv.add( a.getVectorRepresentation() );
     }

     return v;
  }


} // AddressBook
