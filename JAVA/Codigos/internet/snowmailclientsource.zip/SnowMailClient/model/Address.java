package SnowMailClient.model;

import snow.utils.storage.*;
import SnowMailClient.Language.Language;
import java.util.*;


/** a mail address
    parsed from a format like "Ugly snow" <ugly@snow>
*/
public final class Address implements Vectorizable, Comparable
{
    private String name;
    private String mailAddress;

    private int numberOfMailsSendedTo;
    private int numberOfMailsReceivedFrom;
    private long lastUse = 0;
    private long birthday = 0;

    private String phone = "";    
    private String street = "";
    private String city = "";

    
    // used for the view
    public boolean selected = false;
    
                                      
     
    public Address() {}
     
    /** parse the fromFieldText to get an address
    */
    public Address(String fromFieldText)
    { 
       this.parseFromField(fromFieldText);
    }
    
    
    public static Vector<Address> parseAddressList(String list)
    {
       Vector<Address> ads = new Vector<Address>();
       StringTokenizer st = new StringTokenizer(list, ";,");
       while(st.hasMoreTokens())        
       {
         ads.add(new Address(st.nextToken()));
       }
       return ads;
    }             
    
    /** usually, addresses are in the following format 
         "Sibylle Hello" <sib@befree.com>
        outlook in exports write them 
         Sibylle Hello [sib@befree.com]

    */
    private void parseFromField(String fromFieldText)
    {
      // kill white spaces
      String ad = (fromFieldText!=null ? fromFieldText.trim() : "");

      // check if the address contains a < if so then just use whats inside
      // otherwise use the address given
      int foundStart = ad.indexOf('<');
      if(foundStart==-1) {  foundStart = ad.indexOf('['); }

      if (foundStart != -1)
      {
         // found it strip everything from inside
         int foundEnd = ad.indexOf('>', foundStart);
         if(foundEnd==-1) { foundEnd = ad.indexOf(']', foundStart); }
         
         if (foundEnd != -1)
         {
            mailAddress = ad.substring(foundStart+1,foundEnd).trim();
            name = ad.substring(0,foundStart);
         }
         else
         {
            mailAddress = ad.substring(foundStart+1).trim();
            name = ad.substring(0,foundStart);
         }
         name = parseName(name);
      }
      else
      {
         // not found - use as is
         mailAddress = ad;  
         name = "?";
      }       
    }


    /** when the address is extracted, remains the name,
       we just trim and remove quotes
    */
    private String parseName(String _n)
    {
       String n = _n.trim();
       if(n.startsWith("'") || n.startsWith("\""))
       {
          n = n.substring(1);
       }
       if(n.endsWith("'") || n.endsWith("\""))
       {
          n = n.substring(0,n.length()-1);
       }
       return n;
    }

    public String toString()
    {
       return "\""+name+"\" <"+mailAddress+">";
    }

    public String getMailAddress() { return mailAddress;}
    public String getName() { return name;}
    public void setName(String n) { name = n;}
    public void setMailAddress(String a) { mailAddress = a;}

    public int getNumberOfMailsReceivedFrom() { return this.numberOfMailsReceivedFrom; }
    public int getNumberOfMailsSendedTo()     { return this.numberOfMailsSendedTo; }
    
    public long getBirthday() { return birthday; }
    public void setBirthday(long b) { birthday = b; }

    public String getPhone() { return phone; }
    public void setPhone(String p) { phone = p; }

    public String getStreet() { return street; }
    public void setStreet(String p) { street = p; }
                           
    public String getCity() { return city; }
    public void setCity(String p) { city = p; }

    public void incrementMailsReceivedFrom_()
    {
      this.numberOfMailsReceivedFrom++;
      lastUse = new Date().getTime();
    }
    public void incrementMailsSendedTo_()
    {
      this.numberOfMailsSendedTo++;
      lastUse = new Date().getTime();
    }
    
    public long getLastUse() { return lastUse; }
    
    // Comparable interface
    //

    public int compareTo(Object o)
    {
      if(o instanceof Address)
      {                               
        Address a2 = (Address) o;
        //if(this.equals(a2)) return 0;                
        return (this.mailAddress+this.getName()).compareTo(a2.getMailAddress()+a2.getName());
      }
      throw new RuntimeException("Bad Address compare, wrong class "+o);
    }    
    
     
    public boolean equals(Object o)
    {
      if(o instanceof Address)
      {
        Address a2 = (Address) o;
        if( a2.getName().equals(getName())
          &&a2.getMailAddress().equals(getMailAddress()))
        {
          return true;
        }
      }
      return false;
    }

    public int hashCode()
    {
      return getMailAddress().hashCode() + getName().hashCode();
    }

    //
    // Vectorizable
    //

    public Address(Vector v) throws VectorizeException
    {
       createFromVectorRepresentation(v);
    }

    public final void createFromVectorRepresentation (Vector v) throws VectorizeException
    {
       int version = (Integer) v.elementAt(0);
       if(version>=1)
       {
         mailAddress = (String) v.elementAt(1);
         name = (String) v.elementAt(2);
         this.numberOfMailsReceivedFrom = (Integer) v.elementAt(3);
         this.numberOfMailsSendedTo     = (Integer) v.elementAt(4);

         if(version>=3)
         {
           selected = (Boolean) v.elementAt(5);
         }
         if(version>=4)
         {
           lastUse = (Long) v.elementAt(6);
         }
         if(version>=5)
         {
           birthday = (Long) v.elementAt(7);
         }
         if(version>=6)
         {
           phone  = (String) v.elementAt(8);
           street = (String) v.elementAt(9);
           city   = (String) v.elementAt(10);
         }

       }
       else
       {
         throw new VectorizeException(Language.translate("Bad address version %",""+version));
       }
    }

    public final Vector<Object> getVectorRepresentation () throws VectorizeException
    {
       Vector<Object> v = new Vector<Object>();
       v.addElement(6);     //0
                   
       v.addElement(mailAddress);
       v.addElement(name);
       v.addElement(numberOfMailsReceivedFrom);
       v.addElement(numberOfMailsSendedTo);
       v.addElement(selected);
       v.addElement(lastUse);
       v.addElement(birthday);
       v.addElement(phone);
       v.addElement(street);
       v.addElement(city);
       
       return v;
    }

}

