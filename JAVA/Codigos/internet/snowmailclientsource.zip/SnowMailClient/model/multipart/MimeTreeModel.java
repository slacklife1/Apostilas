package SnowMailClient.model.multipart;

import SnowMailClient.model.*;
import SnowMailClient.utils.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.tree.*;
import java.io.File;
import java.util.*;

/** this should be used to deal with mime messages
    to create from a received content, use the parse method of the root part.
    To create a sendable message from tree content, ue createMessageStringContent()


*/
public final class MimeTreeModel extends DefaultTreeModel
{
  private MimePart rootPart;
  
  // used to generate a random boundary delimiter
  int i1 = (int)(Math.random()*1e8);
  int i2 = (int)(Math.random()*1e8);

  public MimeTreeModel(MimePart mp)
  {
    super(mp);
    rootPart = mp;
  }  

  public MimePart getRootPart() { return rootPart; }                                                   
            
  /** this delete all the tree
  */                
  public void clearMimeTree()
  { 
    rootPart = new MimePart();
    this.setRoot(rootPart);
  }
  
  /** @return the parts containing the given text
  */
  public MimePart[] searchInTextParts(String txtUP)
  {
    Vector<MimePart> foundParts = new Vector<MimePart>();
    searchTextRecurse(foundParts, this.rootPart, txtUP);
    return (MimePart[]) foundParts.toArray(new MimePart[foundParts.size()]);
  }

  private void searchTextRecurse(Vector<MimePart> found, MimePart node, String txtUP)
  {
     if(node.containText(txtUP))
     {
        found.addElement(node);
     }   

     for(int i=0; i<node.getChildCount(); i++)
     {
        searchTextRecurse(found, node.getPartAt(i), txtUP);
     }
  }
  
                                
  /** return true if this is a mime message format
     (i.e. if there are childs)
  */
  public boolean isMimeMessageFormat()
  {
     if(rootPart.getChildCount()>0) return true;
     if(rootPart.lookIfContentIsAnAttachment()) return true;  // [Jan2006]: occur when the content is made of a pure attachment!, for example outlook
     return false;         
  }  


  /** null if none, return the message part or the first plain text part
  */
  public MimePart getFirstPlainTextPart()
  { 
    return getFirstNodeOfType(this.rootPart, MimePart.ContentType.TEXT, "PLAIN");
  }

  /** null if none
  */
  public MimePart getFirstHTMLTextPart()
  {
    return getFirstNodeOfType(this.rootPart, MimePart.ContentType.TEXT, "HTML");
  } 
     
  /** called when editing a plain text message with attachments,
     this creates a text node and fill it with the text
  */
  public void setMessagePlainText(Address from, Vector<Address> tos, String subject, String text)
  {
    //System.out.println("setMessagePlainText("+text+")");
    MimePart partText = this.getFirstPlainTextPart();
    if(partText==null)
    {                     
       // create a text part and add it at the begining
       partText = new MimePart();
       //rootPart.addPart(partText);
       rootPart.insert(partText, 0);
    }

    try
    {
      partText.setContentAsPlainTextMailMessage(text);
      rootPart.setContentAsMIME_ROOT(from, tos, subject);
    }
    catch(Exception e)
    {
      // should not appear
      e.printStackTrace();
    }      
  }
  

  private MimePart getFirstNodeOfType(MimePart node, MimePart.ContentType type, String subtype)
  {
    if(node.getContentTYPE()==type && node.getContentSubType().equals(subtype))
    {
      return node;                                      
    }
    for(int i=0; i<node.getChildCount(); i++)
    {
      // depth first
      MimePart mp = getFirstNodeOfType(node.getPartAt(i), type, subtype);
      if(mp!=null) return mp;
    } 
    return null;
  } 
  
  public MimePart getPartWithID(String id)
  {
     return getNodeWithID(this.getRootPart(), id);
  }

  private MimePart getNodeWithID(MimePart node, String id)
  {
    if(node.getID().equalsIgnoreCase(id)) return node;

    for(int i=0; i<node.getChildCount(); i++)
    {
      // depth first
      MimePart mp = getNodeWithID(node.getPartAt(i), id);
      if(mp!=null) return mp;
    }
    return null;
  }

  /** tree bug ??
     events are made, but one need to updateUI the tree !!
  */
  public void addAttachment(MimePart mp)
  {
    this.insertNodeInto(mp, this.rootPart, rootPart.getChildCount());
    if(rootPart.getChildCount()>0)
    {
      rootPart.setContentType(MimePart.ContentType.MULTIPART, "Mixed");
    }
  }

  /** remove any part
   use this in preference to the MutableTree, because the events are here generated
  */
  public void removePart(MimePart mp)
  {
    this.removeNodeFromParent(mp);
  }
  
  
  public Vector<MimePart> getAllAttachments()
  {
    Vector<MimePart> allAtt = new Vector<MimePart>();
    getAllAttachmentsRecurse(allAtt, this.rootPart);
    return allAtt;
  }
                             
  private void getAllAttachmentsRecurse(Vector<MimePart> atts, MimePart node)
  {
    if(node.isLeaf())
    {     
       //System.out.println("Node "+node.getTextForTreeRepresentation()+": "+node.lookIfContentIsAnAttachment());
       if(node.lookIfContentIsAnAttachment())
       {
          atts.add(node);
          return;
       }
    }

    for(int i=0; i<node.getChildCount(); i++)
    {
       // depth first
       getAllAttachmentsRecurse(atts, node.getPartAt(i));
    }         
  }

  /** create the content of this mime tree that will be the body of the mail message
      this will be stored as string in the MailMessage model
  */
  public String createMessageStringContent()
  {
     return rootPart.createStringRepresentation(1, i1, i2);
  }


  public byte[] getContent_For_Sending()
  {
    try
    {
      return rootPart.getContent_For_Sending(1, i1, i2);
    }
    catch(Exception ex)
    {
      // should never occur
      ex.printStackTrace();
      // may help
      return createMessageStringContent().getBytes();
    }

  }
} // MimeTreeModel
