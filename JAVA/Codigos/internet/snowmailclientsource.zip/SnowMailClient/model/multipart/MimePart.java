package SnowMailClient.model.multipart;

import javax.swing.tree.DefaultMutableTreeNode;
import SnowMailClient.utils.*;
import snow.utils.storage.*;
import SnowMailClient.crypto.Utilities;
import SnowMailClient.utils.MailMessageUtils;
import SnowMailClient.model.*;

import java.util.*;
import java.text.*;
import java.io.*;
import java.nio.charset.*;                                                                           

/** Represent a MimePart
    (This is a tree node, because it can contain parts itself)
    nodes content are in leaves child are leafs            
*/                                                
public final class MimePart extends DefaultMutableTreeNode                                                       
{                          
  public boolean debug = true;  
                        
  // the content (DATA)
  private final Header header = new Header();
  private byte[] byteContent = new byte[0];


  // discrete types
  public enum ContentType {
     NO_TYPE, 
     MULTIPART, TEXT, IMAGE, VIDEO, AUDIO, APPLICATION,
     MESSAGE // contains a whole message
  };


  // attachment
  private boolean isAttachment = false;



  private ContentType contentType = ContentType.TEXT;  // default
  private String contentSubType = "";  // TEXT, HTML, ... (uppercase)

  private String boundary;
  private String name = "?";

  // when the content is text, this represent the charset used to convert between the byte content and the text.
  private String charset = "";


  private boolean isRoot = false;
  
  /** the constructor or a mime part.   
      call parseTree to parse the mime tree.
  */
  public MimePart()
  {
     super("???");
  } // Constructor
                          
  public int getPartsCount()
  {
     return this.getChildCount();
  }

  public MimePart getPartAt(int pos)
  {
     return (MimePart) this.getChildAt(pos);
  }
                              
  

  /** add a part at the end
  */
  public void addPart_if_valid(MimePart part)
  {
     if(debug)
     {  
        System.out.println("===> add part of size "+part.getContentTypeString().length()+"\n");
     }
     
     
     if(!part.isMultipart() && (part.byteContent==null || part.byteContent.length==0))
     {
       // avoid empty noon multipart mps
       return;
     }


     this.add(part);
  }    


  public byte[] getByteContent()
  {
    return byteContent;
  }
                                           
  /** this gives the unicode string corectly decoded, using the charset information
      found in the header.
      Should be used to display the message as plain text.
  */
  public String getBodyAsText()
  {      
    String cont = null;
    try
    {
      if(charset.equals(""))
      {                 
        //cont = new String(byteContent, "US-ASCII");
        cont = new String(byteContent, "iso-8859-1");  // better, also covers 7bits encoding
      }
      else
      {
        cont =new String(byteContent, charset);
      }
    }
    catch(Exception e)
    {
      System.out.println("MimePart: Bad charset decoding, error= "+e.getMessage());
      System.out.println("charset = "+charset);
      System.out.println("content length = "+byteContent.length);

      cont = new String(byteContent);
    }
    
    /*
    if(cont.startsWith("aaa"))
    {
      System.out.println("\nMimePart.getBodyAsText()=\n<cont>"+cont+"</cont>, charset="+charset);
      System.out.println("bytes="+StringUtils.toString(byteContent));
    }*/

    return cont;
  }

  public boolean containText(String txtUP)
  {
    if(this.contentType==ContentType.TEXT)
    {
       if(this.getBodyAsText().toUpperCase().indexOf(txtUP)>=0)
       {
          return true;
       }
    }             
    return false;    
  }                      

  
  public String getContentTypeString()  { return header.getEntryValue("Content-Type", ""); }


  /** used to render images embedded in the mime tree
  */
  public String getID()
  {              
    return header.getEntryValue("Content-Id", "?");
  }

  public boolean isMultipart()
  {
    return contentType == ContentType.MULTIPART;
  }                           
  
  public boolean isAttachment()                                                                               
  {                   
    return isAttachment;
  }     
  
  /** text / image / audio / video / application / message
  */                                                      
  public ContentType getContentTYPE()
  {
    return contentType;
  }

  /** for example html in text/html, ...
  */
  public String getContentSubType() { return contentSubType; }
     

  /** @return true if the content is pure HTML
     either if his content type is explicitely set to be text/html
     or if it starts with <html> or <!
  */
  public boolean lookIfContentIsHTML()
  {
    if(contentType!=ContentType.TEXT) return false;
    if(contentSubType.toLowerCase().indexOf("html")>=0) return true;
    if(this.byteContent == null) return false;

    String cont = this.getBodyAsText();
    // just a small test... show if the mails starts with <html>
    if(StringUtils.startsWithIgnoresCaseAndBlanks( cont, "<HTML>")) return true;
    if(StringUtils.startsWithIgnoresCaseAndBlanks( cont, "<!")) return true;

    // definitely not...
    return false;
  }


  /** @return true if the content is pure HTML
     either if his content type is explicitely set to be text/html
     or if it starts with <html> or <!
  */
  public boolean lookIfContentIsAnImage()
  {
    if(contentType==ContentType.IMAGE) return true;
    String name = this.getName().toLowerCase();
    if(name.endsWith(".bmp") || name.endsWith(".png") || name.endsWith(".jpg")
      ||name.endsWith("jpeg") || name.endsWith("wbmp") || name.endsWith(".gif")) return true;

    return false;
  }

  /** @return true if the content is an attachment 
      This is used to know if it will appear in the attachment bar.
      
  */
  public boolean lookIfContentIsAnAttachment()
  {
    if(isAttachment) return true;
    if(contentType==ContentType.APPLICATION) return true;
    if(contentType==ContentType.MESSAGE)     return true;

    return false;
  }

                

  /** set the content to be root
  */
  public void setContentAsMIME_ROOT(Address from, Vector<Address> tos, String subject) 
  {                        
    header.removeAllEntries();
    isAttachment = false;
    isRoot = true;      
    setContentType(ContentType.MULTIPART, "Mixed");
                                      
    header.setEntryOverwrite("From",    from.toString());
    StringBuffer toBuffer = new StringBuffer();                          
    for(int i=0; i<tos.size(); i++)
    {
      toBuffer.append(tos.elementAt(i).getMailAddress());
      if(i<tos.size()-1) toBuffer.append("; ");
    }

    header.setEntryOverwrite("To",      toBuffer.toString());
    header.setEntryOverwrite("Subject", subject);
    header.setEntryOverwrite("Date", MailMessageUtils.msgDateFormat(new Date()));


    header.setEntryOverwrite("Message-ID", MailMessageUtils.createMessageID(from));
    header.setEntryOverwrite("MIME-Version", "1.0");
    
    // FOR SENDING ONLY
    //header.setEntryOverwrite("Content-Type", "text/plain;\r\n\tcharset=\""+charset+"\"");
    //if(quotedPrintable)
    {
     // header.setEntryOverwrite("Content-Transfer-Encoding", "quoted-printable");
    }
/*    else
    {
      header.setEntryOverwrite("Content-Transfer-Encoding", "8bit");
    }*/


    header.setEntryOverwrite("X-Priority", "3 (Normal)");
    header.setEntryOverwrite("X-Mailer", "SnowMail 2.0"); 
    header.setEntryOverwrite("Importance", "Normal");
  }
        
        
        
  /** this is called to make this part the message plain text part
      no conversions here.
  */
  public void setContentAsPlainTextMailMessage(String text)
  {
/*    if(text.startsWith("aaa"))
    {
      System.out.println("\nMimePart.setContentAsPlainTextMailMessage()=\n<cont>"+text+"</cont>");
    }*/

    header.removeAllEntries();
    isAttachment = false;
    isRoot = false;
    setContentType(ContentType.TEXT, "PLAIN");

    isAttachment = false;
    this.charset = CharsetUtils.getMinimalEncodingCharset(text);;


    try
    {
      this.byteContent = text.getBytes(charset);
    }
    catch(Exception e)
    {
      this.byteContent = text.getBytes();    // iso-8859-1
      e.printStackTrace();
    }
    
    /*
    if(text.startsWith("aaa"))
    {
      System.out.println("   charset="+charset);
      System.out.println("   bytes="+StringUtils.toString(byteContent));
    }*/

  }

  /** this is called to make this an attachment
  */
  public void setContentAsAttachment(ContentType type, String subType,
      byte[] cont, String name)
  {
    setContentType(type, subType);
    this.isAttachment = true; // ###
    this.byteContent = cont;
    this.name = name;     
  }              
                 
  public void setContentType(ContentType type, String subType)
  {
    contentType = type;
    this.contentSubType = subType;
    if(this.isMultipart())  
    {                
      name = "Multipart";
    }  
  }
  
  /** write the header (create or overwrite)  
     called before creating string representation to produce a message
  */
  private void writeMIMEFlagsInHeader(boolean multipart, boolean needsQuotedPrintableFormat)
  {
     if(multipart)
     {
       // MULTIPART
       //          
       
       String mpt = "Multipart";
       if(!this.contentSubType.equals(""))
       {
          mpt += "/"+contentSubType;
       }
       header.setEntryOverwrite("Content-Type", ""+mpt+";\n\tboundary=\""+boundary+"\"");
       
       // no such tag
       header.remove("Content-Transfer-Encoding");
     }                                
     else
     {   
       // LEAFS
       //

       String ctt = "";
       if(     this.contentType==ContentType.TEXT)        ctt+="Text";
       else if(this.contentType==ContentType.VIDEO)       ctt+="Video";
       else if(this.contentType==ContentType.IMAGE)       ctt+="Image";
       else if(this.contentType==ContentType.AUDIO)       ctt+="Audio";
       else if(this.contentType==ContentType.APPLICATION) ctt+="Attachment";
       else if(this.contentType==ContentType.MESSAGE)     ctt+="Message";


       if(!this.contentSubType.equals(""))
       {                  
          ctt += "/"+contentSubType;
       }
                                                                                                 
       if(this.contentType==ContentType.TEXT)
       {
         if(!charset.equals(""))
         {
           ctt += ";\n\tcharset="+charset;
         }
       }

       if(isAttachment && !name.equals("?"))
       {
         ctt += ";\n\tname=\""+name+"\"";
       }

       header.setEntryOverwrite("Content-Type", ctt);
       if(this.contentType==ContentType.MULTIPART)
       {
         //System.out.println("NO!");

         // the multipart entry has NO Content-Transfer-Encoding
         header.remove("Content-Transfer-Encoding");
       }  
       else if(this.contentType==ContentType.TEXT)
       {
         if(needsQuotedPrintableFormat)
         {
           header.setEntryOverwrite("Content-Transfer-Encoding", "quoted-printable");
         }
         else
         {
           header.setEntryOverwrite("Content-Transfer-Encoding", "7bit");
         }
       }
       else
       {
         header.setEntryOverwrite("Content-Transfer-Encoding", "base64");
       }

       if(isAttachment)
       {
         // ###
         header.setEntryOverwrite("Content-Disposition", "attachment;\n\tfilename=\""+name+"\"");
       }
     }

     if(isRoot)
     {
       header.setEntryOverwrite("Mime-Version", "1.0 (SnowMmail admin@www.snowraver.org)");
     }
  }       
  

  /** used to send the mail.
  */
  public byte[] getContent_For_Sending(int level, int rand1, int rand2) throws Exception
  {
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    if(this.isMultipart())
    {
      // use the boundary given as parent
      this.boundary = MimeUtils.CreateUniqueBoundary(level,rand1,rand2);
    }
                              
    boolean needsQuotedPrintableFormat = !MailMessageUtils.is7Bits(this.byteContent);    
    writeMIMEFlagsInHeader(this.isMultipart(), needsQuotedPrintableFormat);

    bos.write((header.to_ASCII_String()+"\r\n").getBytes("us-ascii"));

    if(this.isMultipart())
    {
      if(level==1)
      {                        
        bos.write(("\r\nThis is a multi-part message in MIME format.\r\n").getBytes("us-ascii"));
      }

      for(int i=0; i<this.getChildCount(); i++)
      {
        bos.write(("\r\n--"+boundary+"\r\n").getBytes("us-ascii"));
        MimePart mp = this.getPartAt(i);
        bos.write(mp.getContent_For_Sending(level+1, rand1, rand2));
      }

      bos.write(("\r\n--"+boundary+"--\r\n").getBytes("us-ascii"));
    }
    else
    {
      if(contentType==ContentType.TEXT)
      {
         //System.out.println(""+StringUtils.toString(byteContent)+": "+needsQuotedPrintableFormat);
         if(needsQuotedPrintableFormat)
         {
           // encode
           bos.write( MailMessageUtils.encodeMessageQuotedPrintable(byteContent) );
         }
         else
         {  
           bos.write( byteContent );
         }                                 
      }
      else
      {
         bos.write( Utilities.encodeBase64(byteContent).getBytes("us-ascii") );
         bos.write("\n".getBytes("us-ascii"));
      }
    }
              

    return bos.toByteArray();
  }


  /** used to store this mime part in the Message.
      This is always performed after changes in the mime tree (edit/add/remove).
  */
  public String createStringRepresentation(int level, int rand1, int rand2)
  {                
    if(this.isMultipart())
    {
      // use the boundary given as parent
      this.boundary = MimeUtils.CreateUniqueBoundary(level,rand1,rand2);
    }

    writeMIMEFlagsInHeader(this.isMultipart(), 
                           false);   // NO quoted printable. Only on send.

    StringBuffer sb = new StringBuffer();
    sb.append(getHeaderText()+"\n");

    if(this.isMultipart())
    {               
      if(level==1)
      {                 
        sb.append("\nThis is a multi-part message in MIME format.\n");
      }              

      for(int i=0; i<this.getChildCount(); i++)
      {
        sb.append("\n--"+boundary+"\n");

        MimePart mp = this.getPartAt(i);    
        sb.append(mp.createStringRepresentation(level+1, rand1, rand2));

      }
      sb.append("\n--"+boundary+"--\n");
    }
    else
    { 
      if(contentType==ContentType.TEXT)
      {                 
        if(charset.equals(""))
        {
          sb.append(new String(byteContent)+"");
        }
        else
        {
          try           
          {
            sb.append(new String(byteContent, charset)+"");
          }
          catch(Exception e)
          {
            e.printStackTrace();   
            sb.append(new String(byteContent)+"");
          }
        }
      }
      else
      {
        sb.append( Utilities.encodeBase64(byteContent) );
        sb.append("\n");     
      }
    }

    return sb.toString();
  }
     
  /** used to regenerate content
  */
  public String getHeaderText()
  {   
     return header.toString();
  }
  
  
  /** used during the parse operation
  */
  boolean parse_boundary_end_reached = false;
  
  /*  PROBLEM: attachment as unique content
  
MIME-Version: 1.0
Content-Type: application/x-zip-compressed;
	name="moveproblem.zip"
Content-Transfer-Encoding: base64
Content-Description: moveproblem.zip
Content-Disposition: attachment;
	filename="moveproblem.zip"
    
    CCCCCCCCCCContent......

  */
  /** parse a mime tree (recursively) from a string content.

      @param boundaryToParse should be empty at the beginning and lineReader should read the whole
        content.
      @param jumpToNextBoundary cause ignoring lines up to next boundary.

      usage: call
         parseFrom(wholeContent, "", false, 0);

      the member variable parse_boundary_end_reached indicates if the end of boundaryToParse was reached or not
  */
  public void parseMimeTree(NumberedLineReader lineReader,
                        String boundaryToParse,
                        boolean jumpToNextBoundary,
                        int level) throws Exception
  {
     if(debug)
     {
       System.out.println("\nParsing "+boundaryToParse+", jump="+jumpToNextBoundary+", level="+level+", line="+lineReader.getLineNumber());
     }

     // we go to the next start
     if(jumpToNextBoundary)
     {
       String deadLine = null;
       while((deadLine=lineReader.readLine())!=null)
       {
         // [Nov2005]: very very strange behaviour by an amazon reply, the boundary was present
         // somewhere not at beginning:
         //   <ems-render-hash><hash name="EMS.mime-boundary">MuLtIpArT_BoUnDaRy</hash><hash name="EMS.info">log
         //   info </hash><hash name="EMS.status">OK</hash></ems-render-hash>
         // => only accept if at beginning
         int pos = deadLine.indexOf(boundaryToParse);
         if(pos>=0 && pos<10) break;  // we found it !            
       }
       if(deadLine==null)
       {
         throw new Exception("No start found for boundary "+boundaryToParse);
       }
     }  
                                                                                                    
     // read this part header
     //                                                                                               
     try
     {                    
       Header.parseHeader(lineReader, header);
       if(debug)
       {
         System.out.println(" Header read "+header.getEntriesCount()+"\n line="+lineReader.getLineNumber());
       } 
     }
     catch(Exception e)
     {
       // maybe, we have reached the end ???
       String ll = lineReader.getLastLineCached();
       contentType = ContentType.NO_TYPE;
       if(ll==null)
       {
         this.parse_boundary_end_reached = true;
         return ;
       }

       if(ll.trim().endsWith("--"))
       {
         this.parse_boundary_end_reached = true;
         return ;
       }

       // error
       System.out.println("MimePart parse error at level="+level+", Jump "+jumpToNextBoundary+", bound="+boundaryToParse
         +", line="+lineReader.getLineNumber());              
       throw new Exception("Cannot read mime part header", e);
     }                         

     // determine the content type    
     //                          
     String contentTypeStringUP = getContentTypeString().trim().toUpperCase();

     if(contentTypeStringUP.equals(""))
     {
        this.contentType = ContentType.NO_TYPE;
        name = "NO_type";
     }
     else if(contentTypeStringUP.indexOf("MULTIPART")>=0)
     {                                                                                                                                         
        this.contentType = ContentType.MULTIPART;
        name = "Multipart";
     }
     else if(contentTypeStringUP.indexOf("MESSAGE")>=0)
     {
        this.contentType =ContentType.MESSAGE;
        name = "Message";
     }
     else if(contentTypeStringUP.indexOf("TEXT")>=0)
     {
        this.contentType = ContentType.TEXT;
        name = "Text";
     }
     else if(contentTypeStringUP.indexOf("IMAGE")>=0)
     {
        this.contentType = ContentType.IMAGE;
        name = "Image";
     }
     else if(contentTypeStringUP.indexOf("VIDEO")>=0)
     {
        this.contentType = ContentType.VIDEO;
        name = "Video";
     }
     else if(contentTypeStringUP.indexOf("AUDIO")>=0)
     {
        this.contentType = ContentType.AUDIO;
        name = "Audio";
     }
     else if(contentTypeStringUP.indexOf("APPLICATION")>=0)
     {
        this.contentType = ContentType.APPLICATION;
        name = "Application";
     }
     else if(contentTypeStringUP.indexOf("ATTACHMENT")>=0)    // ???
     {                                        
        this.contentType = ContentType.APPLICATION;
        name = "Application";   
     }
     else                                    
     {
        throw new RuntimeException("Unknown mime content type: "+contentTypeStringUP);
     }  
     
     // subtype
     int posSlash = contentTypeStringUP.indexOf("/");
     if(posSlash==-1)
     {
       this.contentSubType = "";
     }
     else
     {
       this.contentSubType = contentTypeStringUP.substring(posSlash+1);
       int posSp = contentSubType.indexOf(";");
       if(posSp!=-1) contentSubType = contentSubType.substring(0, posSp);
       //System.out.println("'"+contentSubType+"'");
     }  


     // charset
     charset = HeaderUtils.getHeader_Charset_entry(header);

     // attachment ###
     String cd = header.getEntryValue("Content-Disposition","").toUpperCase();
     if(cd.indexOf("ATTACHMENT")!=-1)
     {
        this.isAttachment = true;
     }            
                
     //System.out.println("CT="+contentTypeStringUP+", type="+contentType);

     // Name
     //
     int posName = contentTypeStringUP.indexOf("NAME=\"");
     if(posName!=-1)
     {
       int endPos = contentTypeStringUP.indexOf("\"", posName+6);
       if(endPos>=0)
       {
         String ct = getContentTypeString().trim();
         name = ct.substring(posName+6, endPos);
         //System.out.println("NAME="+ct.substring(posName+6, endPos));
       }
     } 
     
     // [Aug2004]
     name = MailMessageUtils.decodeCharsetCodedArgumentFully(name);
     
                       
     if(debug)
     {
       System.out.println("  MimePart ct="+this.contentType+", "+contentSubType);
       System.out.println("  cs="+charset+" att="+isAttachment+" name="+name+" multi="+isMultipart());
     }              

     //  recursive types (multipart)
     //
     if(this.isMultipart())
     {
       // find boundary
       boolean boundaryWithoutQuotes = false;
       int bd = contentTypeStringUP.indexOf("BOUNDARY=\"");
       if(bd==-1)
       {
         // second chance: some newsletters and  ezmlm havn't quotes
         bd = contentTypeStringUP.indexOf("BOUNDARY=");
         boundaryWithoutQuotes = true;
       }

       if(bd==-1)
       {
          System.out.println("No boundary found for multipart="+contentTypeStringUP);
          throw new Exception("No boundary");     
       }                                

       String ct = getContentTypeString().trim();
       if(boundaryWithoutQuotes)
       {
         boundary = ct.substring(bd+9);
       }
       else 
       {
         boundary = ct.substring(bd+10);
       }

       int end = boundary.indexOf("\"");
       if(boundaryWithoutQuotes)
       {
         end = boundary.length();
         //System.out.println("Boundary without quotes found = >"+boundary.substring(0, end)+"<");
       }  

       if(end==-1) throw new Exception("No boundary end");
       boundary = boundary.substring(0, end).trim();
       
       if(boundary.length()==0) throw new Exception("Empty boundary !");

       if(debug) 
       {
         System.out.println("  parse multipart, boundary=" + boundary);
       }

       // ok, now we can parse the parts, defined with this boundary
       boolean first = true;  // first
       while(true)
       {
          MimePart mp = new MimePart();
          mp.debug = debug;
          
          mp.parseMimeTree(lineReader, boundary, first, level+1);
          if(mp.parse_boundary_end_reached)
          {
            if(debug)
            {
              System.out.println("end reached !");
            }

            // last part...
            if(contentType != ContentType.NO_TYPE)
            {
              this.addPart_if_valid(mp);
            }

            break; // END
          }

          first = false;

          if(contentType != ContentType.NO_TYPE)
          {
            this.addPart_if_valid(mp);
          }
       }

       // ###
       this.parse_boundary_end_reached = false;
       return; 
       
     }
     else
     {
       // this is not a multipart => read the content
       //
       StringBuffer content = new StringBuffer();
       String line = null;
       if(debug)
       {
         System.out.println("Parsing mimePart content from line "+lineReader.getLineNumber());
       }

       while((line=lineReader.readLine())!=null)
       {
          if(line.indexOf(boundaryToParse)!=-1)
          {                                                                                             
             // end boundary found.
             break;
          }
          content.append(line+"\n");
       }

       if(debug)
       {
         System.out.println(" ===== read content size = "+content.length());
         System.out.println(" ========== START ");
         System.out.println(content.toString());
         System.out.println(" *========== END ");

       }


       if(line==null)
       {
          // no end boundary found !!!
          //OLD throw new RuntimeException("Boundary end not found.");

          // [June2004] Accept incorectly finished messages...
          // just do as it would be finished
          // end
          this.parse_boundary_end_reached = true;
                                                     
          if(content.length()>0)
          {
            setByteContentFromParsed(content.substring(0,content.length()-1));  // forget the last return
          }            
          else                
          {
            setByteContentFromParsed(content.toString());
          }  

          return ;
       }

       // look how the last line ends
       this.parse_boundary_end_reached = line.trim().endsWith("--");

       if(content.length()>0)
       {              
         setByteContentFromParsed(content.substring(0,content.length()-1)); // forget the last return
       }
       else      
       {
         setByteContentFromParsed(content.toString());
       }

       return ;
     }
  } 
   
   
   
  /** this sets the byteContent, extracting the bytes 
  */             
  private void setByteContentFromParsed(String content) throws Exception
  {
     //byteContent = content.substring(0,content.length()-1).getBytes("utf-8");

/*     if(content.toString().startsWith("aaa"))
     {
        System.out.println("\nMimePart.parseTree()=<cont>"+content.substring(0,content.length()-1)+"</cont>, end reached= "+this.parse_boundary_end_reached);
        //System.out.println("  chars="+StringUtils.toString(this.byteContent));
        setByteContentFromParsed(content, true);
        System.out.println("  chard="+StringUtils.toString(this.byteContent));
     }
     else                        
     {
        setByteContentFromParsed(content, false);
     }*/
     if(debug) 
     {                                                                                                          
       System.out.println("setByteContentFromParsed false");
     }
     
     setByteContentFromParsed(content, debug);

  }
  

  public String getTextForTreeRepresentation()
  {                  
    if(byteContent!=null && byteContent.length>0)
    {
      return getName()+" ("+MailMessageUtils.formatSize(byteContent.length)+")";
    }
    else
    {
      return getName();
    }
  }       
  
  public String getName() 
  {
    // cause html content to be seen as HTML in the tree
    if(this.lookIfContentIsHTML()) return "HTML";
    return name;     
  }                                 
                 
  /** Possibilities: 7bits, 8bits, Base64, quoted-printable

  */
  private void setByteContentFromParsed(String scont, boolean debug) throws Exception                
  {                     
    // Encoding...                                                                                        
    //                       
    String contentTransferEncoding = header.getEntryValue("content-transfer-encoding", "").toUpperCase();
                   
    if(debug)
    {       
      System.out.println("setByteContentFromParsed enc = "+contentTransferEncoding);
      System.out.println(""+scont+"\n=============");     
    }
      
    String charsetToDecode = "iso-8859-1";
    if(charset.length()>0)             
    {                                                                                                            
      charsetToDecode = charset;   
    }    
    
    if(charsetToDecode.equalsIgnoreCase("us-ascii"))
    {        
      // well: how explain this ?
      //  we enforce here keeping the 8 bits, 
      //  iso contains us-ascii but don't cut the 8th bit !
      charsetToDecode = "iso-8859-1";
      charset = "iso-8859-1";
    }

    // look if the charset exists !
    //
    try
    {
      Charset cs = Charset.forName(charsetToDecode);
      "hello".getBytes(charsetToDecode);
    }
    catch(Exception e)
    {
      if(debug) 
      {
         System.out.println("MimePart unknown charset "+charsetToDecode+" using iso-8859-1");
      }
      charsetToDecode = "iso-8859-1";
      charset = "iso-8859-1";
    }

    if(contentTransferEncoding.equals(""))
    {                                 
      // [June2005] was missing !
      byteContent = scont.getBytes(charsetToDecode);
    }
    else if(contentTransferEncoding.indexOf("8BIT")!=-1)
    {
      byteContent = scont.getBytes(charsetToDecode);
    }
    else if(contentTransferEncoding.indexOf("7BIT")!=-1)
    {               
      byteContent = scont.getBytes(charsetToDecode);
    }
    else if(contentTransferEncoding.indexOf("QUOTED-PRINTABLE")!=-1)
    {
      try                  
      {
        byteContent = MailMessageUtils.decodeQuotedPrintable(scont, charsetToDecode).getBytes(charsetToDecode);
      }
      catch(Exception e)
      {
        System.out.println("Cannot decode charset '"+charsetToDecode+"'");
        charset = "iso-8859-1";
        byteContent = MailMessageUtils.decodeQuotedPrintable(scont, "iso-8859-1").getBytes("iso-8859-1");
      }
    }
    else if(contentTransferEncoding.indexOf("BASE64")!=-1)
    {
      try
      {                 
        byteContent = Utilities.decodeBase64( scont );
      }
      catch(Exception e)
      {
        throw new Exception("MimePart: error decoding base 64 content:\n "+e.getMessage());
      }
    }
    else
    {
       System.out.println("MimePart: unknown content-transfer-encoding: "+contentTransferEncoding);
       // [June2005] was missing !
       byteContent = scont.getBytes(charsetToDecode);       
    }
       
  }
                                                                                             


} // MimePart
