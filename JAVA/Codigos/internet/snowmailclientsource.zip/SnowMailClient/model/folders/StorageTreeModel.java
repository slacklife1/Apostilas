package SnowMailClient.model.folders;

import SnowMailClient.model.*;
import SnowMailClient.SnowMailClientApp;
import snow.utils.gui.*;
import SnowMailClient.SpamFilter.*;
                       
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.tree.*;
import java.io.File;
import java.util.*;

/** this is the main folder tree model, containing the folders structure
    it is used as the JTree model.
    Features:                     
      + maintain the 5 basic folders (always open)
    
    Remarks: 
      + always keep the references on the nodes and DO not cache the mailFolders, because
        their references may be cleaerd to free memory (weak ref)
*/
public final class StorageTreeModel extends DefaultTreeModel
{                   
  private final FolderTreeNode rootNode;

  // these folders are always existing and are open, these are default folders
  //
  private final FolderTreeNode inboxNode;
  private final FolderTreeNode sentNode;        
  private final FolderTreeNode outboxNode;  
  private final FolderTreeNode composeNode; 
  private final FolderTreeNode deletedNode;
  
  
  /** create the model, with the 5 basic folders
  */
  public StorageTreeModel(File rootFolder) throws Exception
  {
     super(new FolderTreeNode(rootFolder.getAbsolutePath(), null));
     rootNode = (FolderTreeNode) getRoot();
     //rootNode.setIsSystemFolder(true);                    

     // default nodes
     if(!rootNode.hasChild("Inbox"))
     {
        inboxNode = new FolderTreeNode("Inbox", rootNode);
        final MailMessage greetingMessage = new MailMessage();
        greetingMessage.parse(
           "from: SnowMail\r\n" 
          +"to: you, dear user\r\n"
          +"subject: Hello\r\n\r\nwelcome in Snowmail"
          +"\n\n"); 
        greetingMessage.setEditable(false);
        
        EventQueue.invokeLater(new Runnable(){ public void run() 
        {
          try
          {
            inboxNode.getMailFolder().addMessage(greetingMessage);
            inboxNode.saveMailFolder(false);  // don't close
          }
          catch(Exception e) { e.printStackTrace(); }
        }});
     }
     else
     {
        inboxNode = rootNode.getChild("Inbox");
     }
     inboxNode.setIsSystemFolder(true);



     if(!rootNode.hasChild("Sent"))
     {
        sentNode = new FolderTreeNode("Sent", rootNode);
     }
     else
     {
        sentNode = rootNode.getChild("Sent");
     }
     sentNode.setIsSystemFolder(true);



     if(!rootNode.hasChild("Outbox"))
     {
        outboxNode = new FolderTreeNode("Outbox", rootNode);
     }
     else
     {
        outboxNode = rootNode.getChild("Outbox");
     }
     outboxNode.setIsSystemFolder(true);



     if(!rootNode.hasChild("Compose"))
     {
        composeNode = new FolderTreeNode("Compose", rootNode);
     }
     else
     {
        composeNode = rootNode.getChild("Compose");
     }
     composeNode.setIsSystemFolder(true);

     if(!rootNode.hasChild("Deleted"))
     {
        deletedNode = new FolderTreeNode("Deleted", rootNode);
     }
     else
     {
        deletedNode = rootNode.getChild("Deleted");
     }
     deletedNode.setIsSystemFolder(true);


     if(!rootNode.hasChild("Personal Folders"))
     {
        new FolderTreeNode("Personal Folders", rootNode);
     }
     else                                   
     {
        // put it as last child
        FolderTreeNode node = rootNode.getChild("Personal Folders");
        rootNode.remove(node);
        rootNode.insert(node, rootNode.getChildCount());
     }
     
  } // Constructor

  
  public FolderTreeNode getInboxFolder()    { return inboxNode;   }
  public FolderTreeNode getSentFolder()     { return sentNode;    }
  public FolderTreeNode getOutboxFolder()   { return outboxNode;  }
  public FolderTreeNode getComposeFolder()  { return composeNode; }
  public FolderTreeNode getDeletedFolder()  { return deletedNode; }  
                                  
                                                   
  /** this stores all opened folders, 
      should be called prior to a backup or when closing
  */
  public void storeAllOpenedFolders(boolean close)
  {
     storeAllFoldersRecurse(rootNode, close);  
  }
  
  public int getTotalNumberOfFolders()
  {
     return rootNode.getTotalNumberOfFoldersIncludingThis();
  }

  public void analyseAllMailsToTrainSPAMFilter(ProgressModalDialog p) throws Exception
  {  
     rootNode.analyseAllMailsToTrainSPAMFilter(SnowMailClientApp.getInstance().getWordStatistic(), p, true);
  }
  
  /** Analyse all mails and place words either in SPAM or HAM category.  
  */
  public void filterAllMailsIntoSPAMCategory(ProgressModalDialog p) throws Exception
  {    
     WordStatistic stat = SnowMailClientApp.getInstance().getWordStatistic();
     stat.result_detected_spams  = 0;
     stat.result_false_positives = 0;
     
     rootNode.calculateSPAMNoteForEachMailRecurse(
       stat,
       p,  
       true);
  }
  
  /** Stores all the opened folders
     @param close if true, also close the folder
  */
  private void storeAllFoldersRecurse(FolderTreeNode folder, boolean close)
  {
    // store this
    try
    {
      folder.saveMailFolder(close);
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }

    // and all childs
    for(int i=0;i<folder.getChildCount(); i++)
    {
       FolderTreeNode child = folder.getFolderChildAt(i);
       storeAllFoldersRecurse(child, close);
    }
  }
  
  // used to store/restore the selection
  //

  public String[] getPathForNode( FolderTreeNode node)
  {
    Vector<String> v = new Vector<String>();
    getPathForNode(v,node);
    String[] path = new String[v.size()];
    return (String[]) v.toArray(path);
  }

  private void getPathForNode(Vector<String> path, FolderTreeNode node)
  {
    path.insertElementAt(node.getFolderName(),0);
    FolderTreeNode parent = (FolderTreeNode) node.getParent();
    if(parent!=null) getPathForNode(path, parent);
  }

  /** used in FolderView to restore old selected folder at startup
  */
  public FolderTreeNode getNodeForPath(String[] path)
  {
     if(path==null || path.length==0)
     {
       return this.rootNode;
     }       

     Vector<String> pathV = new Vector<String>(Arrays.asList(path));
     pathV.remove(0);  // root
     FolderTreeNode found = getNodeForPath(rootNode, pathV);
     if(found==null) return this.rootNode;
     return found;
  }

  private FolderTreeNode getNodeForPath(FolderTreeNode base, Vector<String> namesPath)
  {

     if(namesPath.size()==0) return base;

     String name =  namesPath.elementAt(0);
     namesPath.remove(0);

     //System.out.println("Looking for "+name+" in "+base.getFolderName());

     for(int i=0; i<base.getChildCount(); i++)
     {                           
        FolderTreeNode child = base.getFolderChildAt(i);
        if(child.getFolderName().equals(name))
        {
          return getNodeForPath(child, namesPath);
        }
     }         
     // not found
     return null;
  }


} // StorageTreeModel
