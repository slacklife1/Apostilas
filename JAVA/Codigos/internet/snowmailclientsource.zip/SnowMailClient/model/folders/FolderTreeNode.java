package SnowMailClient.model.folders;

import snow.utils.storage.*;
import snow.utils.gui.*;
import SnowMailClient.model.*;
import SnowMailClient.Language.Language;
import SnowMailClient.crypto.*;
import SnowMailClient.SnowMailClientApp;
import SnowMailClient.SpamFilter.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.tree.*;
import java.io.*;
import java.util.*;
import java.security.*;
import java.security.spec.*;
import javax.crypto.spec.*;
import javax.crypto.*;                                                                                                   
                           
/** This is a tree node representing a mail folder.
    Use only this to access a folder because this has a kind of weak reference allowing
    to save the folder and free memory if needed. 
    
*/                           
public final class FolderTreeNode extends DefaultMutableTreeNode //implements Iterable<FolderTreeNode>
{
  boolean systemFolder = false;         
                  
  // created or read from file on demand (for memory reasons)
  private MailFolder mailFolder;
                                   
  private static final String folder_File_Name = "content.mailFolder";
  
  
  public FolderTreeNode( String name, DefaultMutableTreeNode parent ) throws Exception 
  {                         
    super(name);
    if(parent!=null)
    {
      parent.add(this);   
    }    
    
    // make file
    File folderFile = new File( getFolderFullPath());
    if(folderFile.exists())
    {
       if(!folderFile.isDirectory())
       {
          throw new Exception(Language.translate("Folder % is not a directory", folderFile.getAbsolutePath()));
       }
    }
    else
    {
       if(!folderFile.mkdirs())   
       {
          throw new Exception(Language.translate("Cannot create folder %",folderFile.getAbsolutePath()));
       }
    }
    
    parseChilds();

  } // Constructor
        
        
  /** Iterator over first level childs
  *
  public Iterator<FolderTreeNode> iterator()
  {
    return new Iterator<FolderTreeNode>()
    {
        int i=0;
        public boolean hasNext()     { return i<getChildCount(); }
        public FolderTreeNode next() { return getFolderChildAt(i++); }
        public void remove()         { throw new UnsupportedOperationException(); }
    };
  }*/
  
  /** use them to iterate. Is a copy of the child list !
     remove on this vector has no influence !
     But references can be used to safely remove from childs from this node
  */
  public Vector<FolderTreeNode> getFirstlevelChilds()
  {
    Vector<FolderTreeNode> flc = new Vector<FolderTreeNode>();
    for(int i=0; i<getChildCount(); i++)
    {
      flc.addElement(getFolderChildAt(i));
    }
    return flc;               
  }


  private void parseChilds() throws Exception
  {
     File thisFolder = new File(getFolderFullPath());
     File[] dirs = thisFolder.listFiles( new FileFilter()
     {
       public boolean accept(File pathname)  
       {
         return pathname.isDirectory();
       }
     } );

     for(File ci: dirs)
     {
       new FolderTreeNode(ci.getName(), this);
     }
  }

  public boolean hasChild(String name)
  {  
    return new File(getFolderFullPath(), name).exists();
  }
                
  /** at first level
  */
  public FolderTreeNode getChild(String name)
  {
    File folderToSearch = new File(this.getFolderFile(), name);
    //for(int i=0; i<this.getChildCount(); i++)

    for(FolderTreeNode childNode: getFirstlevelChilds())
    {                                     
      //FolderTreeNode childNode = (FolderTreeNode) this.getChildAt(i);
      if(childNode.getFolderFile().equals(folderToSearch)) return childNode;
    }
    return null;
  } 
  
  public FolderTreeNode getFolderChildAt(int i)
  {                    
    return (FolderTreeNode) this.getChildAt(i);
  }                  

  public String getFolderName()
  {
    return (String) this.getUserObject();
  }  
  
  public FolderTreeNode getParentNode()
  {
    return (FolderTreeNode) this.getParent();
  }

  public String getFolderFullPath()
  {
    FolderTreeNode parent = (FolderTreeNode) getParent();
    if(parent!=null)
    {
      return parent.getFolderFullPath()
        + System.getProperty("file.separator","\\")
        + this.getFolderName();
    }
    return this.getFolderName();
  }  
  
  
  /** fill the search result with all hits
  */
  public void searchMailMessagesContaining(String search, final SearchResults result, boolean recurse) throws Exception
  {
    // Search in folder         
    //
    MailFolder folder = this.getMailFolder();
    for(int i=0; i<folder.getRowCount(); i++)    
    {
       final MailMessage mess = folder.getMessageAt(i);
       if(folder.hitForTextSearch(i, search, null))  // also looks in the message !
       {
         // already found in the table
         EventQueue.invokeLater(new Runnable()   // important: UI calls in the EDT !
         { public void run() {
            result.addHit(new SearchHit(mess, FolderTreeNode.this));
            SnowMailClientApp.getInstance().getSearchPanel().updateTree();
         }});
       }
/*       else
       {
         // look in message
         if(mess.searchText(search))
         {
           EventQueue.invokeLater(new Runnable()
           { public void run() {
              result.addHit(new SearchHit(mess, FolderTreeNode.this));
              SnowMailClientApp.getInstance().getSearchPanel().updateTree();
           }});
         } 
       }  */
    }

    // Recursion
    //
    if(recurse)
    {
       for(FolderTreeNode childNode: getFirstlevelChilds())
       {
         childNode.searchMailMessagesContaining(search, result, recurse);
       }
    }
  }
  
  public int getTotalNumberOfFoldersIncludingThis()
  {
    int n = 1;  // itself   
    for(FolderTreeNode childNode: getFirstlevelChilds())
    {
      n += childNode.getTotalNumberOfFoldersIncludingThis();
    }
    return n;
  }

  public void analyseAllMailsToTrainSPAMFilter(WordStatistic stat, ProgressModalDialog progress, boolean recurse) throws Exception
  {
    // analyse this folder
    MailFolder folder = this.getMailFolder();
                       
    progress.setProgressComment( ""+folder.getFolderName()
         +", "+Language.translate("Total words count")+"="+stat.getNumberOfWords());
    progress.incrementProgress(1);

    for(MailMessage mess: folder.getAllMessages())
    {
       if(progress.wasCancelled())
       {
         throw new Exception(Language.translate("Training cancelled"));
       }
       stat.addMessageToStat( mess );
    }                 

    // Recursion
    //
    if(recurse)    
    {
       for(FolderTreeNode childNode: getFirstlevelChilds())
       {
         childNode.analyseAllMailsToTrainSPAMFilter(stat, progress, recurse);
       }   
    }
  }
                            
  public void calculateSPAMNoteForEachMailRecurse(WordStatistic stat, ProgressModalDialog progress, boolean recurse) throws Exception
  {                                                           
    MailFolder folder = this.getMailFolder();
    //folder.setContentHasChanged(false);
                   
    progress.setProgressComment( ""+folder.getFolderName());
    progress.incrementProgress(1);

    for(MailMessage mess: folder.getAllMessages())
    {
       if(progress.wasCancelled())
       {
         throw new Exception(Language.translate("SPAM Analysis cancelled"));
       }

       // message analysis

       SpamResult sr = stat.calculateSpamProbability( mess );
       double p = sr.getProbability();
       mess.setSPAMProbability(p);

       boolean isSpam = stat.isSpam(p);
       if(isSpam && mess.getIsHAM())
       {
          stat.result_false_positives++;
          System.out.println("False positive in "+this.getFolderFullPath());
          stat.addFalsePositive(this.getFolderName()+ " "+mess.getFromAddress().toString());
       }
       if(isSpam && mess.getIsSPAM()) stat.result_detected_spams++;

       // header analysis
                                                
       Header header = mess.getHeader();
       p = stat.calculateSpamProbability(header).getProbability();

       isSpam = stat.isSpam(p);
       if(isSpam && mess.getIsHAM())
       {
          stat.result_false_positives_header++;
          stat.addFalsePositive(this.getFolderName()+ " "+mess.getFromAddress().toString()+" (Header detection only)");
       }
       if(isSpam && mess.getIsSPAM()) stat.result_detected_spams_header++;

    }

    // Recursion
    //
    if(recurse)
    {
       for(FolderTreeNode childNode: getFirstlevelChilds())
       {
         childNode.calculateSPAMNoteForEachMailRecurse(stat, progress, recurse);
       }
    }
  }

  /** @return the file where the folder is stored
  */                                                                            
  public File getFolderFile() { return new File( getFolderFullPath() ); }

  public void removeThisFolder() throws Exception
  {        
     if(this.getParent()==null) throw new Exception("Cannot remove root folder");
     if(systemFolder) throw new Exception("System folder "+getFolderName()+" cannot be removed");
     File thisFolder = getFolderFile();
     File[] files = thisFolder.listFiles();
     if(files.length>0)      
     {                    
       // look if mail folder file is present
       File mailFolderFile = new File(getFolderFile(), folder_File_Name);
       if(mailFolderFile.exists())
       {
         if(files.length>1)
         {
           throw new Exception("Folder "+thisFolder+" is not empty, it has extra files.");
         }
         else
         {
           MailFolder mf = this.getMailFolder();
           if(mf.getRowCount()>0)
           {
             throw new Exception("Folder "+getFolderName()+" is not empty.");
           }   
           else
           {
             // delete it
             mailFolderFile.delete();
           }
         }
       }
       else
       {
         throw new Exception("Folder "+thisFolder+" is not empty, it has extra files.");
       }
     }

     if(!thisFolder.delete())
     {
       throw new Exception("Folder "+getFolderName()+" was not deleted successfully");
     }

     removeAllChildren();
     removeFromParent();

  }
  
  /** rename the folder (copy the folder)
  */
  public void rename(String newName) throws Exception
  {
     if(this.getParent()==null) throw new Exception(Language.translate("Cannot rename root folder"));
     if(systemFolder) 
     {
       throw new Exception(Language.translate("System folder % cannot be renamed", getFolderName()));
     }
                 
     // Test files
     File thisFolderFile = getFolderFile();
     File parentFile = thisFolderFile.getParentFile();

     File newFolderParentFile = new File(parentFile, newName);
     File newFolderContentFile = new File(newFolderParentFile, folder_File_Name);

     if(newFolderContentFile.exists()) 
     {
       throw new Exception(Language.translate("Cannot rename folder, the destination folder already exists."));
     }

     if(!newFolderParentFile.exists())
     {
        if(!newFolderParentFile.mkdirs())
        {
           throw new Exception(Language.translate("Cannot create folder directory %",newFolderParentFile.getAbsolutePath()));
        }
     }

     // read the mail folder
     MailFolder mf = getMailFolder();
     mf.setContentHasChanged(false);  // force to ensure save !
     // the folder name is the user object
     this.setUserObject(newName);
     // save it in the new location
     saveMailFolder(false); // don't close

     // everything was ok => delete the old...
     File oldMailFolderFile = new File(thisFolderFile, "content.mailFolder");
     if(oldMailFolderFile.exists() && !oldMailFolderFile.delete())
     {
        throw new Exception("Cannot delete the old folder "+oldMailFolderFile.getAbsolutePath());
     }
  }

  public void setIsSystemFolder(boolean is)
  {
     systemFolder = is;
  }  
                    
  public boolean isSystemFolder() { return systemFolder; }

  // Folder
  //     

  public boolean isMailFolderOpened()
  {
     return (mailFolder!=null);
  }

  /** @return the mail folder associated with this node.
      At the first call (of the snowmail instance),
      the folder is read from the file.
      If the mail folder file doesn't exist (this is the case when
      it is newly created, the file is created.
  */
  public MailFolder getMailFolder() throws Exception
  {
     if(mailFolder!=null) return mailFolder;
                            
     mailFolder = new MailFolder(this);
        
     // is file existing ?
     File mailFolderFile = new File(getFolderFile(), "content.mailFolder");
     if(!mailFolderFile.exists())
     {
        // create it
        // version 0
        // FileUtils.saveVectorToFile(mailFolderFile, mailFolder.getVectorRepresentation());

        // version 1: static easy key, just to avoid easy mail read in the folder files
        // version 2: actual key used, if defined
        FileCipherManager.getInstance().encipherVectorWithHeadToFile(
                 new Vector<Object>(), new Vector<Object>(),
                 mailFolder.getVectorRepresentation(),
                 mailFolderFile,
                 SecretKeyManager.getInstance().getActualKey());
     }

     // read it
     try
     {
        try
        {
           Vector v = FileCipherManager.getInstance().decipherVectorFromFile_ASK_KEY_IF_NEEDED(
                  mailFolderFile,
                  SnowMailClientApp.getInstance(),
                  Language.translate("Folder Password"),
                  Language.translate("Enter the passphrase to decipher the folder %",this.getFolderName())
                  );
           mailFolder.createFromVectorRepresentation( v );
        }
        catch(Exception ee)
        {
           System.out.println("Error: cannot read "+mailFolderFile+"\n error="+ee.getMessage());
           System.out.println("Trying old version 0");
           // try old version 0
           try
           {
             Vector v = FileUtils.loadVectorFromFile(mailFolderFile);
             mailFolder.createFromVectorRepresentation( v );
           }
           catch(Exception eee)
           {
             throw eee;
           }
        }
     }
     catch(OutOfMemoryError e)
     {
        throw new Exception("Canot read mail folder from file "+mailFolderFile.getAbsolutePath()
          +"\nBecause of an out of memory error. Restart Snowmail with more memory (-Xmx512m).");
     }                                             
     catch(Exception e)
     {
        throw new Exception("Canot read mail folder from file "+mailFolderFile.getAbsolutePath()
          +"\nException message="+e.getMessage());
     }
     catch(Error e)
     {            
        throw new Exception("Canot read mail folder from file "+mailFolderFile.getAbsolutePath()
          +"\nError message="+e.getMessage());
     }

     return mailFolder;
  }
          
  /** Save if content has changed
      @boolean close if true, closes the folder (remove it from memory)
  */
  public void saveMailFolder(boolean close) throws Exception
  {
     if(mailFolder==null) return;
                                                                      
     // not null

     if(mailFolder.hasContentChanged())
     {
        File mailFolderFile = new File(getFolderFile(), "content.mailFolder");
        // version 2: custom key possible, default static used if no pass set
        FileCipherManager.getInstance().encipherVectorWithHeadToFile(
             new Vector<Object>(),
             new Vector<Object>(),
             mailFolder.getVectorRepresentation(),
             mailFolderFile, SecretKeyManager.getInstance().getActualKey());

        mailFolder.setContentWasStored();
     }

     if(close)
     {   
        
        mailFolder.notifyMailFolderListener_of_FolderClosed();
        mailFolder = null;
        // let GC close it...
     }
  }


} // FolderTreeNode                   
