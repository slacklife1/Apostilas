package SnowMailClient.model;


import SnowMailClient.SnowMailClientApp;
import SnowMailClient.model.folders.*;
import SnowMailClient.model.events.*;
import snow.utils.storage.*;
import SnowMailClient.utils.*;
import snow.utils.gui.*;

import snow.SortableTable.*;
import SnowMailClient.Language.Language;


import java.util.*;
import java.util.regex.*;
import java.text.*;
import javax.swing.table.*;
import javax.swing.SwingUtilities;
import java.awt.EventQueue;
           

/** Model of a mail folder, is stored in the directory tree maintained from storagetreemodel
    + this is a table model,
    + one can listen for changes (that forward all messages events !)
*/
public final class MailFolder extends FineGrainTableModel 
                        implements Vectorizable, MailMessageChangeListener//, Iterable<MailMessage>
{
  private final AppProperties properties = new AppProperties();
  private final Vector<MailMessage> messages = new Vector<MailMessage>();
  private static final String[] COLUMN_NAMES = new String[]{
     Language.translate("From"),
     Language.translate("To"),
     Language.translate("Subject"),
     Language.translate("Date"),
     Language.translate("Size"),
     Language.translate("SPAM")
  };
  
  
  int[] COLUMN_PREFERED_SIZES = new int[] { 12, 12, 12, 6, 6, 4 };
  public int getPreferredColumnWidth(int column)
  {
    if(column>=0 && column<COLUMN_PREFERED_SIZES.length) return COLUMN_PREFERED_SIZES[column];
    return -1;
  }
  

  // tells where is it...
  FolderTreeNode node;             
  
  // is used to decide if store is necessary ...
  private boolean contentHasChanged = false;
                             
  private SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yy  HH':'mm", Language.getInstance().getLocale());
       

  private int sortedColumnInView = 3;    // default sorted by date !!
  private boolean ascendingSortOrder = true;

  public MailFolder(FolderTreeNode node)
  {
    this.node = node;
  } // Constructor
  

  public String getFolderName()
  {
    return node.getFolderName();
  }
   
  public void addMessage(final MailMessage m)
  {                    
    if(!SwingUtilities.isEventDispatchThread())
    {        
       new Throwable("Must be EDT").printStackTrace();
    }

    fireTableModelWillChange();
    messages.addElement(m);
    m.addChangeListener(this);
    contentHasChanged = true;
    fireTableDataChanged();
    fireTableModelHasChanged();

    this.notifyMailFolderListener_of_FolderSizeChanged();
  }


  public void removeMessage(final MailMessage m)
  {
    if(!SwingUtilities.isEventDispatchThread())
    {
       new Throwable("Must be EDT").printStackTrace();
    }

    fireTableModelWillChange();
    messages.removeElement(m);
    m.removeChangeListener(this);
    contentHasChanged = true;
    fireTableDataChanged();
    fireTableModelHasChanged();

    this.notifyMailFolderListener_of_FolderSizeChanged();
  }  
                            
                    
  public MailMessage getMessageAt(int i)
  {                     
     return messages.elementAt(i);
  }

  /** new mails (unread) or just composed
  */
  public int getNumberOfNewMails()
  {
     int n=0;
     for(MailMessage mess: messages)
     {
        if(mess.getIsNew()) n+=1;
     }                                                                                              
     return n;
  }   
  

  // Iterator  (for the foreach loop)
  //
  
  /*
  public Iterator<MailMessage> iterator()
  {
    return new Iterator<MailMessage>()
    {
        int i=0;
        public boolean hasNext() { return i<messages.size(); }
        public MailMessage next() { return messages.elementAt(i++); }
        public void remove() { throw new UnsupportedOperationException(); }
    };
  }*/


  /** use this to iterate with a foreach loop. This is a copy of the references.
      Can be used to safely remove elements ! call this class remove message.
      the remove on the vector will have NO effect !
  */
  public Vector<MailMessage> getAllMessages()
  {
    Vector<MailMessage> vm = new Vector<MailMessage>();
    vm.addAll(messages);
    return vm;
  }


  // Table
  //

  public int getRowCount()    { return messages.size(); }
  public int getColumnCount() { return COLUMN_NAMES.length; }
  public Object getValueAt(int row, int column)
  {              
    MailMessage mess = messages.elementAt(row);
    if(column==0)
    {                               
      Address from = mess.getFromAddress();
      return from.getMailAddress();
    }
    else if(column==1)       
    {
      return mess.getToAddressesText();
    }
    else if(column==2)
    {
      return mess.getSubject();
    }
    else if(column==3)
    {
      long time = mess.getParsedMessageTime();
      if(time==0)
      {
        return mess.getDateFieldFormHeader();
      }
      else
      {       
        return dateFormat.format(new Date(time));
      }
    }
    else if(column==4)
    {                      
      return MailMessageUtils.formatSize(mess.getSize());
    }
    else if(column==5)
    {
      //double spam = mess.getSPAMProbability();
      //return "";  // the renderer does the work !!
      //if(mess.getIsSPAM()) return "S";
      //else if(mess.getIsHAM()) return "H";
      //else return "";
      return "";
    }

    return "?";
  }


  public String getColumnName(int col)
  {
    return COLUMN_NAMES[col];
  }

  public boolean hitForTextSearch(int row, String txt, Pattern p)
  {
    // look in the table strings
    boolean foundInTable = super.hitForTextSearch(row, txt, p);
    if(foundInTable==true) return true;

    // look in the message
    MailMessage mess = messages.elementAt(row);
    return mess.searchText(txt.toUpperCase());
  }

  public int compareForColumnSort(int pos1, int pos2, int col)
  {
     MailMessage mess1 = messages.elementAt(pos1);
     MailMessage mess2 = messages.elementAt(pos2);
           
     if(col==3) // Dates
     {
       return this.compareDoubles(mess1.getParsedMessageTime(), mess2.getParsedMessageTime());
     }

     if(col==4) // Sizes
     {
       return this.compareInts(mess1.getSize(), mess2.getSize());
     }

     if(col==5) // Spam prob
     {
       return this.compareDoubles(mess1.getSPAMProbability(), mess2.getSPAMProbability());
     }

     // for the other cols, use string compare
     String val1 = (String) getValueAt(pos1, col);
     String val2 = (String) getValueAt(pos2, col);
     return val1.compareTo(val2);
  }                             
                             
  /** Cause a save, later
    @param update if listeners should be notified. If true, the view will refresh...

    Called from this and the foldertreenode to force a save later...
  */
  public void setContentHasChanged(boolean notify)
  {
    //System.out.println("Folder content changed, notify="+notify);
    
    contentHasChanged = true;
    if(notify)        
    {
      this.notifyMailFolderListener_of_ContentEdited(null);
    }                
  }

  public void setContentWasStored()
  {
    contentHasChanged = false;
    this.notifyMailFolderListener_of_FolderStored();
  }                                  

  public boolean hasContentChanged()
  {
    return contentHasChanged;
  }


  public void saveSortedColumnFromView(  int sortedColumnInView,
                                         boolean ascendingSortOrder )
  {
    this.sortedColumnInView = sortedColumnInView;
    this.ascendingSortOrder = ascendingSortOrder;

  }   
  
  public int getSortedColumn()
  {
    return sortedColumnInView;
  }
  
  public boolean getIsSortingAscendingOrder()
  {
    return ascendingSortOrder;
  }

  // Vectorizable
  //
  public Vector<Object> getVectorRepresentation() throws VectorizeException
  {
    Vector<Object> rep = new Vector<Object>();
    rep.addElement(1);                        // 0
    rep.addElement(properties.getVectorRepresentation());  // 1

    Vector<Object> messagesVec = new Vector<Object>();
    rep.addElement(messagesVec);                           // 2
    for(MailMessage m: messages)
    {
       messagesVec.addElement( m.getVectorRepresentation() );
    }
    rep.addElement(this.sortedColumnInView);   // 3
    rep.addElement(this.ascendingSortOrder);   // 4
    return rep;
  }

  public void createFromVectorRepresentation(Vector<Object> v) throws VectorizeException
  {
    int version = (Integer) v.elementAt(0);     // 0
    if(version==1)
    {
      properties.createFromVectorRepresentation((Vector) v.elementAt(1)); // 1
      
      Vector<Vector> messVec = (Vector<Vector>) v.elementAt(2);              // 2
      messages.removeAllElements();
      for(Vector mv: messVec)
      {
         try
         {
           MailMessage mess = new MailMessage();
           mess.createFromVectorRepresentation(mv );
           messages.addElement(mess);
           mess.addChangeListener(this);
         }
         catch(Exception e)
         {
           System.out.println("Cannot read a mail in folder "+this.getFolderName()+" "+e.getMessage());
           //e.printStackTrace();
         }
      }
      if(v.size()>3)
      {
        this.sortedColumnInView = (Integer) v.elementAt(3);
        this.ascendingSortOrder = (Boolean) v.elementAt(4);
      }

    }
    else
    {
      throw new VectorizeException(Language.translate("bad version %", ""+version));
    }
  } 
  
  // Selection
  //
  public void setRowSelection(int row, boolean isSelected)
  {                  
    messages.elementAt(row).selectedInView = isSelected;
  }

  public boolean isRowSelected(int row)
  {
    return messages.elementAt(row).selectedInView;
  }

  public void setSelectedMessage(MailMessage mess)
  {
    if(mess==null) return;
    for(MailMessage mi : messages)
    {
       mi.selectedInView = (mi==mess);
    }
  }
  

  /** When one of the mails of this folder has changed.
      Edit Cases:
      1) in_edition: the message is being edited (key was pressed in the message textpane), 
         this must just set the folder flag to "changed".
      2) the header or the message changed => 
         refresh the view.
  */
  public void mailMessageChanged(MailMessage source, MailMessageChangeType type, String detail)
  {
    if(type == MailMessageChangeType.IN_EDITION)
    {
      //System.out.println("Message in edition");
      this.setContentHasChanged(false);
    }
    else                     
    {
      // type is one of {MESSAGE, HEADER, PROPERTY, ATTACHMENT}

      //System.out.println("Message changed: "+type+", detail="+detail+", src="+source.getSubject());
      this.setContentHasChanged(true);
    }
  }
                      
                                 
  // Listeners
  //
  Vector<MailFolderListener> mailFolderListener = new Vector<MailFolderListener>();
             
  /** this listen to all mails changes in this folder
  */
  public void addMailFolderListener(MailFolderListener mfn)
  {
    mailFolderListener.addElement(mfn);
  }
  
  
  public void removeMailFolderListener(MailFolderListener mfn)
  {
    mailFolderListener.removeElement(mfn);
  } 

  /** either added/removed mails
  */
  public void notifyMailFolderListener_of_FolderSizeChanged()
  {
     // do a copy of the listeners to decouple them from the vector
     // because they may perform operation on the vector in the notify loop (remove listener)
     // and caus concurrent modification exceptions
     MailFolderListener[] mfl = null;
     synchronized(mailFolderListener)
     {
       mfl = (MailFolderListener[]) mailFolderListener.toArray(new MailFolderListener[mailFolderListener.size()]);
     }                    

     for(MailFolderListener mfn : mfl)
     {
       mfn.folderSizeChanged();
     }
     // ## DO BETTER !
     if(SnowMailClientApp.getInstance().getFoldersView()!=null)
     {
       SnowMailClientApp.getInstance().getFoldersView().repaint();
     }
  }

  public void notifyMailFolderListener_of_FolderStored()
  {
     // do a copy of the listeners to decouple them from the vector
     // because they may perform operation on the vector in the notify loop (remove listener)
     // and caus concurrent modification exceptions
     MailFolderListener[] mfl = null;
     synchronized(mailFolderListener)
     {
       mfl = (MailFolderListener[]) mailFolderListener.toArray(new MailFolderListener[mailFolderListener.size()]);
     }

     for(MailFolderListener mfn : mfl)  
     {
       mfn.folderStored();
     }
     
     if(SnowMailClientApp.getInstance().getFoldersView()!=null)
     {
       SnowMailClientApp.getInstance().getFoldersView().repaint();
     }
  }

  public void notifyMailFolderListener_of_ContentEdited(MailMessageChangeListener.MailMessageChangeType change)
  {
     // do a copy of the listeners to decouple them from the vector
     // because they may perform operation on the vector in the notify loop (remove listener)
     // and caus concurrent modification exceptions
     MailFolderListener[] mfl = null;
     synchronized(mailFolderListener)
     {
       mfl = (MailFolderListener[]) mailFolderListener.toArray(new MailFolderListener[mailFolderListener.size()]);
     }

     for(MailFolderListener mfn : mfl)
     {
       mfn.folderContentEdited(change);
     }
     SnowMailClientApp.getInstance().getFoldersView().repaint();
  }
  
  public void notifyMailFolderListener_of_FolderClosed()
  {
     // do a copy of the listeners to decouple them from the vector
     // because they may perform operation on the vector in the notify loop (remove listener)
     // and caus concurrent modification exceptions
     MailFolderListener[] mfl = null;
     synchronized(mailFolderListener)
     {
       mfl = (MailFolderListener[]) mailFolderListener.toArray(new MailFolderListener[mailFolderListener.size()]);
     }

     for(MailFolderListener mfn : mfl)  
     {
       mfn.folderClosed();    
     }   
     SnowMailClientApp.getInstance().getFoldersView().repaint();
  }



} // MailFolder
