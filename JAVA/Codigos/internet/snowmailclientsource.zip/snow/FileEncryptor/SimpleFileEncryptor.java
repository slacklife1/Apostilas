package snow.FileEncryptor;

import javax.swing.*;
import javax.swing.filechooser.*;
import java.util.*;
import java.util.zip.*;

import java.security.*;
import java.security.spec.*;
import javax.crypto.spec.*;
import javax.crypto.*;

import snow.utils.gui.*;
import snow.utils.storage.*;
import snow.crypto.*;
import snow.Language.Language;

import java.io.*;   


/** encrypt/decrypt a file
*/
public final class SimpleFileEncryptor
{

  private SimpleFileEncryptor()
  {
                         
  } // Constructor

  
  
  /** overwrite the file content with a random buffer
  */                                            
  public static void wipeFile(File f, int bufferSize, ProgressModalDialog progressDialog, int passes)
  {
    long count = 0;  // for the progress
    RandomAccessFile raf = null;
    for(int p=0; p<passes; p++)
    {
       try
       {
           raf = new RandomAccessFile(f, "rw");                                                                                   

           raf.seek(0);          
           byte[] buffer = new byte[bufferSize];
           int blocks = (int)(raf.length()/bufferSize)+1;
           for(int i=0; i<blocks; i++)
           {
             fillRandom(buffer);
             raf.write(buffer);
             if(count%passes==1)
             {
               progressDialog.incrementProgress(1);
             }
             count++;
           }
       }
       catch(Exception e)
       {
         e.printStackTrace();
       }
       finally    
       {
         if(raf!=null)       
         {
           try                        
           {
             raf.close();
           }
           catch(Exception ee){ ee.printStackTrace(); }
         }
       }
    }

    f.delete(); 
    if(f.exists())
    {
      System.out.println("Cannot delete the file "+f);
      f.deleteOnExit();
    }
  }

  public static void fillRandom(byte[] buf)
  {
    for(int i=0; i<buf.length; i++)
    { 
      buf[i] = (byte) (Math.random()*256);
    }                                                                                  
  }
  
  
  public static void encryptDirectory(File in, File out, boolean delete, SecretKey key, int bufferSize, ProgressModalDialog progressDialog) throws Exception
  {  
     // 1) Collect all directory files and zip them
     //
     Vector<File> allFilesToZip = new Vector<File>();
     FileUtils.getAllFilesRecurse(in, allFilesToZip);

     ZipOutputStream zos = null;
     File tempZipFile = new File(in.getParentFile(), "tempZip.zip");
     tempZipFile.deleteOnExit();
     try
     {
       FileOutputStream fos = new FileOutputStream(tempZipFile);
       zos = new ZipOutputStream(fos);
       for(File f: allFilesToZip)
       {
         FileUtils.addToZip(zos,f,f.getAbsolutePath());
       }
     }
     catch(Exception ze)
     {
       throw ze;
     }
     finally
     {
       if(zos!=null) zos.close();
     }

     // 2) encrypt the zip
     //
     try
     {
       encryptFile(tempZipFile, out, key, bufferSize, progressDialog);
     }
     catch(Exception ex)
     {
       throw ex;
     }

     // 3) delete the zip file
     //
     wipeFile(tempZipFile, bufferSize, progressDialog, 2);

     if(delete)
     {
       for(File f: allFilesToZip)
       {
         wipeFile(f, bufferSize, progressDialog, 2);
       }
     }

     
     
                           
  }

  /** the progress must be set
  */
  public static void encryptFile(File in, File out, SecretKey key, int bufferSize, ProgressModalDialog progressDialog) throws Exception
  {
    Cipher cipher = Cipher.getInstance("Blowfish/ECB/PKCS5Padding");
    cipher.init(Cipher.ENCRYPT_MODE, key);

    FileInputStream fis = null;
    FileOutputStream fos = null;                      
    DataOutputStream dos = null;
    GZIPOutputStream zos = null;
    CipherOutputStream cos = null;
    try
    {
      fis = new FileInputStream(in);
      fos = new FileOutputStream(out);
      dos = new DataOutputStream(fos);
      dos.writeInt(2);
      dos.writeUTF("B");
      dos.writeInt(key.getEncoded().length);
      SecretKeyID ski = SecretKeyUtilities.computeSignature(key);
      dos.write(ski.signature,0,4);

      cos = new CipherOutputStream(dos, cipher);
      zos = new GZIPOutputStream(cos);
      
      byte[] buf = new byte[bufferSize];
      int read  =1;
      while((read=fis.read(buf))!=-1)
      {                            
        zos.write(buf,0,read); 
        //if(read!=bufferSize) System.out.println(""+read);
        progressDialog.incrementProgress(1);  
      }
                           

      zos.close();
    }
    catch(Exception e)
    {
      throw e;
    }
    finally
    {
      if(fos!=null) try { fos.close(); } catch(Exception ex) {ex.printStackTrace();}
      if(fis!=null) try { fis.close(); } catch(Exception ex) {ex.printStackTrace();}
      out.setLastModified( in.lastModified() );
    }                                                                                                                                          
  }

  public static void decryptFile(File in, File out, SecretKey key, int bufferSize, ProgressModalDialog progressDialog) throws Exception
  {
    FileOutputStream fos = null;
    FileInputStream fis = null;
    DataInputStream dis = null;
    CipherInputStream cis = null;    
    GZIPInputStream zis = null;

    try
    {  
      fos = new FileOutputStream(out);

      fis = new FileInputStream(in);      
      dis = new DataInputStream(fis);

      // (clear) header read
      //
      int version = dis.readInt();
      if(version==2)
      {
        // custom pass (or default, if not set...
        String algo = dis.readUTF();
        int keyLength = dis.readInt();
        byte[] sign = new byte[4];
        dis.readFully(sign,0,4);
        SecretKeyID ski = new SecretKeyID(sign, keyLength);
        if(!SecretKeyUtilities.computeSignature(key).equals(ski))
        {
          throw new BadPasswordException(Language.translate("Bad key"));
        }
      }

      else
      {
        throw new Exception("Bad file version "+version);
      }
                         
      // read cipher vector part
      //

      Cipher cipher = Cipher.getInstance("Blowfish/ECB/PKCS5Padding");
      cipher.init(Cipher.DECRYPT_MODE, key);

      cis = new CipherInputStream(dis, cipher);
      zis = new GZIPInputStream(cis);
      
      byte[] buf = new byte[bufferSize];
      int read = -1;
      while((read=zis.read(buf))!=-1)
      {
        fos.write(buf,0,read);
        progressDialog.incrementProgress(1);
      }


      zis.close();
    }
    catch(Exception e)
    {                  
      throw e;
    }
    finally
    {
      if(fis!=null) try{ fis.close(); } catch(Exception ex) {ex.printStackTrace();}
      if(fos!=null) try{ fos.close(); } catch(Exception ex) {ex.printStackTrace();}
      
      out.setLastModified( in.lastModified() );
    }
  } 
                 
   
  /** @return null if ok, an error message otherwise
  */
  public static String verifyEncryptedFile(File source, File encrypted, SecretKey key, int bufferSize, ProgressModalDialog progressDialog) throws Exception
  {
    FileInputStream fis = null;
    DataInputStream dis = null;
    CipherInputStream cis = null;
    GZIPInputStream zis = null;

    try                            
    {    
      fis = new FileInputStream(encrypted);
      dis = new DataInputStream(fis);

      // (clear) header read
      //
      int version = dis.readInt();
      if(version==2)
      {
        // custom pass (or default, if not set...)
        String algo = dis.readUTF();
        int keyLength = dis.readInt();
        byte[] sign = new byte[4];
        dis.readFully(sign,0,4);
        SecretKeyID ski = new SecretKeyID(sign, keyLength);
        if(!SecretKeyUtilities.computeSignature(key).equals(ski))
        {
          throw new BadPasswordException(Language.translate("Bad key"));
        }
      }

      else
      {
        throw new Exception("Bad file version "+version);
      }

      // read cipher vector part
      //

      Cipher cipher = Cipher.getInstance("Blowfish/ECB/PKCS5Padding");
      cipher.init(Cipher.DECRYPT_MODE, key);
         
      cis = new CipherInputStream(dis, cipher);
      zis = new GZIPInputStream(cis);

      byte[] buf = new byte[bufferSize];
      int read = -1;
      long decrypetdLength = 0;
      MessageDigest md = MessageDigest.getInstance("SHA1");
      while((read=zis.read(buf))!=-1)
      {
        progressDialog.incrementProgress(1);
        md.update(buf,0,read);
        decrypetdLength += read;
      }
      zis.close();

      // verif 1
      if(decrypetdLength!=source.length())
      {
        return "Decrpyted file has different length !";
      }

      // verif2
      byte[] md1 = md.digest();
      byte[] md2 = calculateSHA1Hash(source);

      if(!Arrays.equals(md1,md2))
      {
        return "Decrypted file has different checksum !";
      } 
    }
    catch(Exception e)
    {
      throw e;
    }
    finally
    {
      if(fis!=null) fis.close();
    }
    return null;
  }


  public static byte[] calculateSHA1Hash(File f) throws Exception
  {
    FileInputStream fis = null;
    MessageDigest md = MessageDigest.getInstance("SHA1");
    try
    {
      fis = new FileInputStream(f);
      byte[] buf = new byte[256];
      int read = 0;
      while((read=fis.read(buf))!=-1)
      {
        md.update(buf,0,read);
      }
      return md.digest();
    }
    catch(Exception e)
    {
      throw e;
    }
    finally
    {
     if(fis!=null) fis.close();
    }
  }



  /** @return the keyID of the enciphered file
  */
  public static SecretKeyID getKeyIDFromFile(File in) throws Exception
  {
    FileInputStream fis = null;
    DataInputStream dis = null;
    try            
    {
       fis = new FileInputStream(in);
       dis = new DataInputStream(fis);
       // header read  
       int version = dis.readInt();
       if(version>=2)
       {
          String algo = dis.readUTF(); // actually ignored
          int keyLength = dis.readInt();
          byte[] sign = new byte[4];
          dis.readFully(sign,0,4);
          dis.close();

          SecretKeyID ski = new SecretKeyID(sign, keyLength);
          return ski;
       }
       else
       {
         throw new Exception(Language.translate("Bad version %",""+version));
       }
    }
    catch(Exception e)
    {
      throw e;
    }
    finally
    {
       if(fis!=null) try { fis.close(); } catch(Exception ex) {ex.printStackTrace();}
    }

  }


} // SimpleFileEncryptor
