package snow.FileEncryptor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.filechooser.*;
import java.util.*;
import java.util.zip.*;

import java.security.*;
import java.security.spec.*;
import javax.crypto.spec.*;
import javax.crypto.*;     

import snow.utils.gui.*;
import snow.utils.storage.*;
import snow.crypto.*;
import snow.Language.Language;

import SnowMailClient.crypto.Utilities;

import java.io.*;   

public final class HashCodeDialog extends JDialog
{
  final AppProperties props;
  final FileField inputFileField;
  final JTextArea codeArea = new JTextArea(4,40);
  final JTextArea verificationArea = new JTextArea(
     //Language.translate("paste a hashcode to verify here"),
     "",
     4,40); 
  
  byte[] lastComputedHash = null;

  public HashCodeDialog(JFrame parent, final AppProperties props)
  {
     super(parent, Language.translate("Snowmail HashCode Utility"), false);
     this.props = props;
     
     getContentPane().setLayout(new BorderLayout());
     inputFileField = new FileField(
       props.getProperty("HashCodeDialog.File", ""),
       false,
       Language.translate("Choose a file for which to compute the hashcode"),
       false
     );

     ActionListener computeHashAction = new ActionListener()
     {                   
        public void actionPerformed(ActionEvent ae)
        { 
          computeHashCode();
        }
     };
     inputFileField.addActionListener(computeHashAction);

     // north
     //
     JPanel inputPanel = new JPanel();
     inputPanel.setBorder(new EmptyBorder(5,1,5,1));
     getContentPane().add(GUIUtils.wrapLeft(inputPanel), BorderLayout.NORTH);
     GridLayout3 gl3 = new GridLayout3(2,inputPanel);
     gl3.add(Language.translate("File to analyse"));
     gl3.add(inputFileField, true);
     inputFileField.setComponentWidth(265);
     JButton computeHash = new JButton(Language.translate("Compute HashCode"));
     gl3.add(computeHash);
     computeHash.addActionListener(computeHashAction);

     // Center
     //
     JPanel outputPanel = new JPanel();            
     getContentPane().add(outputPanel, BorderLayout.CENTER);
     GridLayout3 gl2 = new GridLayout3(1, outputPanel);
     gl2.add(Language.translate("Computed Hashcodes"));
     gl2.add(new JScrollPane(codeArea));
     codeArea.setEditable(false);
     gl2.add(Language.translate("Verification (Paste an external hashcode to verify)"));
     gl2.add(new JScrollPane(verificationArea));

     verificationArea.getDocument().addDocumentListener(new DocumentListener()
     {
        public void changedUpdate(javax.swing.event.DocumentEvent de)
        {
          verifyHashCode();
        }

        public void removeUpdate(javax.swing.event.DocumentEvent de)
        {
          verifyHashCode();
        }

        public void insertUpdate(javax.swing.event.DocumentEvent de)
        {
          verifyHashCode();
        }         
     });


     // South
     //
     CloseControlPanel ccp = new CloseControlPanel(this, false, false, Language.translate("Close"));
     getContentPane().add(ccp, BorderLayout.SOUTH);
     
     
     pack();
     this.setLocationRelativeTo(parent);
     setVisible(true);
  } // Constructor
      
      
              
  private void computeHashCode()
  {    
    Thread t = new Thread()                                             
    {
      public void run()
      {
        codeArea.setForeground(UIManager.getColor("TextArea.foreground"));
        final ProgressModalDialog pd = new ProgressModalDialog(HashCodeDialog.this, Language.translate("computing hashcode"), false);
        try
        {
          final File file = inputFileField.getPath();
          if(file.getName().trim().length()==0)
          {
            throw new Exception(Language.translate("No file given"));
          }
              
          if(!file.exists()) throw new Exception(Language.translate("File % dont exist", ""+file));

          props.setProperty("HashCodeDialog.File", file.getAbsolutePath());

          lastComputedHash = CryptoUtilities.SHA1Hash( file, pd );
          codeArea.setText("SHA-1: "+  Utilities.asHex(lastComputedHash) );
        }
        catch(Exception e)
        {
          codeArea.setText(Language.translate("Error: ")+e.getMessage());
          codeArea.setForeground(Color.red);
        }
        finally
        {
          pd.closeDialog(); 
          verifyHashCode(); 
        }
      }
    };        
    
    t.start();
  }  
  
  
  private void verifyHashCode()
  {
     String pasted = verificationArea.getText().trim();
     pasted = pasted.replaceAll("\\s", "");

     String computed = Utilities.asHex(lastComputedHash);

     if(pasted.equalsIgnoreCase(computed))
     {
        verificationArea.setForeground(UIManager.getColor("TextArea.foreground"));
     }                 
     else
     {
        verificationArea.setForeground(Color.red);
     }
  }



  public static void main(String[] aa)
  {
     JFrame parent = new JFrame("");
     parent.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

     AppProperties app = new AppProperties();
     HashCodeDialog hd = new HashCodeDialog(parent, app);
  }


} // HashCodeDialog
