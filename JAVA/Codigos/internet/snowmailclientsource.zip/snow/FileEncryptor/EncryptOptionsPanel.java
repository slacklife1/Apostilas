package snow.FileEncryptor;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.filechooser.*;
import java.util.*;
import java.util.zip.*;

import java.security.*;    
import java.security.spec.*;
import javax.crypto.spec.*;
import javax.crypto.*;


import snow.utils.gui.*;
import snow.crypto.*;
import snow.Language.Language;

import java.io.*;
            
/** an option panel used as accessory panel for the JFileChooser
*/
public final class EncryptOptionsPanel extends JPanel
{                                    
  JCheckBox wipeSourceCB = new JCheckBox("Delete source file");
  public EncryptOptionsPanel(boolean wipeSource)
  {
    super();
    setBorder(new CompoundBorder(new EmptyBorder(3,3,3,3),new TitledBorder("Options")));
    wipeSourceCB.setSelected(wipeSource);
    add(wipeSourceCB);  
  } // Constructor

  public boolean doWipeSource() { return wipeSourceCB.isSelected(); }

} // EncryptOptionsPanel
