package snow.crypto;

import snow.utils.gui.ProgressModalDialog;
import snow.Language.Language;

import sun.misc.BASE64Encoder;
import sun.misc.BASE64Decoder;

import java.io.*;
import java.math.*;
import java.security.SecureRandom;
import java.util.Arrays;
import java.net.*;

import java.security.*;
import java.security.spec.*;
import javax.crypto.spec.*;
import javax.crypto.*;

public final class CryptoUtilities
{

  private CryptoUtilities()
  {

  } // Constructor


    public static byte[] MD5Hash(byte[] input)
    {
       try
       {
          MessageDigest md5 = MessageDigest.getInstance("MD5");
          return md5.digest(input);
       }
       catch(Exception e)
       {
          throw new RuntimeException(""+e.getMessage());
       }
    }

    public static byte[] SHA1Hash(byte[] input)
    {
       try
       {
          MessageDigest md = MessageDigest.getInstance("SHA1");
          return md.digest(input);
       }
       catch(Exception e)
       {      
          throw new RuntimeException(""+e.getMessage());
       }
    }  
    
    /** call from another thread as the EDT
    */
    public static byte[] SHA1Hash(File file, ProgressModalDialog pd)  throws Exception
    {
       if(pd!=null)
       {
          pd.setProgressBounds( (int) (file.length() / 65536) );
          pd.start();
          
       }             

       FileInputStream fis = null;
       try
       {
          fis = new FileInputStream(file);
          BufferedInputStream bis = new BufferedInputStream(fis);
          byte[] buf = new byte[65536];
          MessageDigest md = MessageDigest.getInstance("SHA1");
          int read = -1;
          while((read=bis.read(buf))!=-1)
          {  
             if(pd!=null)
             {
               if(pd.wasCancelled()) throw new Exception(Language.translate("Hashcode computation cancelled"));
             }

             md.update(buf,0,read);

             if(pd!=null)
             {
               pd.incrementProgress(1);
             }
          }          
          return md.digest();
       }
       catch(Exception e)
       {
          //throw new RuntimeException(""+e.getMessage());
          throw e;
       }  
       finally
       {
          if(fis!=null) try{ fis.close(); } catch(Exception ignore) {}
       }
    }    

} // CryptoUtilities
