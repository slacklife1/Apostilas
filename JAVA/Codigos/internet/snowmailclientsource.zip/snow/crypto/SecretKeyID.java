package snow.crypto;


import java.util.*;

/** An identifier for a secret key.
*/
public final class SecretKeyID
{
   public byte[] signature;
   public int key_length;

   public SecretKeyID (byte[] signature, int key_length)
   {
     this.signature = (signature!=null ? (byte[]) signature.clone() : null);
     this.key_length = key_length;
   }

   public byte[] getKeySignature()
   {
     if(signature==null) return null;
     // pass a copy
     return (byte[]) signature.clone();
   }

   public int getKeyLangth()       { return key_length; }

   public boolean equals(Object o)
   {  
      if(!(o instanceof SecretKeyID)) 
      {
        System.out.println("Bad class, not SecretKeyID");
        return false;
      }
      SecretKeyID k2 = (SecretKeyID) o;
      if(k2.key_length != key_length)
      {
        return false;
      }
      if(!Arrays.equals( k2.signature, signature))
      {
        return false;
      }                 

      return true;
   }  
   
   public int hashCode()
   {
     return signature[0]+256*signature[1];
   }

   

   public String toString()
   {  
     return "l="+this.key_length+", sign={" + signature[0]+", "+signature[1]
                                        +", "+signature[2]+", "+signature[3] + "}";
   } 

} // SecretKeyID
