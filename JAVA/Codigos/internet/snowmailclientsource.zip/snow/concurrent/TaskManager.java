package snow.concurrent;

import java.util.concurrent.*;
import java.util.*;

/** an easy task manager fifo single threaded queue.
*/
public class TaskManager
{
  // only one task at time, one after each other
  final private ExecutorService executor = Executors.newFixedThreadPool(1);
  final private Vector<InterruptableTask> submitedTasks = new Vector<InterruptableTask>();  // all the tasks maybe actual, past and futures

  public TaskManager()
  {

  } // Constructor


  public Future execute(InterruptableTask task)
  {
     Future fut = executor.submit((Callable) task);
     task.future = fut;
     submitedTasks.add(task);
     cleanDoneTasks();
     return fut;
  }
  
  
  public void stopActualTask(long timeout)
  {
     synchronized(submitedTasks)
     {
        if(submitedTasks.size()==0) return;

        cleanDoneTasks();
        InterruptableTask at = getActualExecutedTask();
        if(at!=null)
        {
          if(at.interrupter.shouldStopEvaluation())
          {
            System.out.println("kill task");
            at.kill();
          }
          else
          {
            System.out.println("Request stop");
            at.requestStop();
          }
        }
     }
  }

  private void cleanDoneTasks()
  {
     synchronized(submitedTasks)
     {
        for(int i=submitedTasks.size()-1; i>=0; i--)
        {
          if(submitedTasks.elementAt(i).future.isDone())
          {
            submitedTasks.removeElementAt(i);
          }
        }
     }
  }
  
  public InterruptableTask getActualExecutedTask()
  {      
     synchronized(submitedTasks)
     {
        for(int i=0; i<submitedTasks.size(); i++)
        {
          if(submitedTasks.elementAt(i).isExecuting())
          {
            return submitedTasks.elementAt(i);
          }
        }
     }
     return null;          
  }

} // TaskManager
