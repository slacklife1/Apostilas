    
package snow.concurrent;

public class Counter
{
  public int counterValue = 0;
  public Counter()
  {
    
  } // Constructor


  public void increment(int count)
  {
    counterValue += count;
  }


} // Counter
