package snow.concurrent;

/** is thrown when an interrupter has requested some thread to stop
*/
public class ManualInterruptedException extends InterruptedException
{

  public ManualInterruptedException()
  {
    super();
  }

  public ManualInterruptedException(String s)
  {
    super(s);
  }



} // ManualInterruptedException
