package snow.concurrent;

/** this is part of an interrupatble task.
    It signal a task that it should stop the evaluation. 
    It is a safe and lazy method to stop a thread, but the thread must
    programmatically often check if it must stop !
*/
public class Interrupter
{
  private boolean shouldStop = false;

  public void stopEvaluation() { shouldStop = true; }
  public boolean shouldStopEvaluation() { return shouldStop; }
  
  public Process process = null;

  public void setProcessToOptionalKill(Process p){
    this.process = p;
  }

  /** use this to reset the interrupter.
  */
  public void reset()
  {
     shouldStop = false;
  }

} // Interrupter
