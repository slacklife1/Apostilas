package snow.concurrent;

import java.util.concurrent.*;
import java.util.*;

/** wraps a runnable into an interruptable task.
  I.e. creates a thread that can be interrupted.  
     should only be interrupted when not stopping itself correctely with the Interrupter
*/
public abstract class InterruptableTask implements Callable, Runnable
{
  Thread thread;
  final public Interrupter interrupter = new Interrupter();  // correct way to stop the thread
  Future future;  // set at submit
  private boolean isExecuting = false;


  public InterruptableTask()
  {              

  } // Constructor
  
  public boolean isExecuting() { return isExecuting; }

  public final Object call() throws Exception
  {      
     if(this.interrupter.shouldStopEvaluation()) 
     {
       // never evaluates !
       return null;
     }

     isExecuting = true;
     thread = new Thread(this);
     // wait until completion
     try
     {
       thread.start();
       thread.join();
     }
     catch(Exception e) 
     {  
       kill();
       throw e;
     }
     finally
     {
       isExecuting = false;
     }
     return null;
  }
  
  /** use only if request stop has not succeded.
     This kills the thread.
     BE CAREFUL: if the therad calls EventQueue.invokeAndWait, and catch Exception without throwing them 
      the thread continues !!
  */
  public void kill()
  {
     if(thread!=null && thread.isAlive())
     {
       thread.interrupt();  // throws an exception that may be catched => not 100% stops
     }
     
     // thread.stop()  // stops 100% but not safe ! deprecated !!
  }

  public void requestStop()
  {
     if(interrupter.shouldStopEvaluation())
     {
       // already cool stopped but still called => kill
       kill();
     }
     else
     {
       // first attempt : cool stop
       interrupter.stopEvaluation();
     }
  }


} // InterruptableTask
