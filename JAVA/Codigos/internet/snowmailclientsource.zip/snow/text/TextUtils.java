package snow.text;

import javax.swing.text.*;
import java.util.*;

public final class TextUtils
{

  private TextUtils()
  {

  } // Constructor


  public final static int getPositionInParent(Element elt)
  {
    Element parent = elt.getParentElement();
    for(int i=0; i<parent.getElementCount(); i++)
    {
      if(parent.getElement(i)==elt) return i;
    }         
    return -1;
  } 



} // TextUtils
