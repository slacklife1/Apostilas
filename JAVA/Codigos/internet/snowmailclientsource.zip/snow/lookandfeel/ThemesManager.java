package snow.lookandfeel;

import snow.utils.storage.AppProperties;
import snow.utils.gui.*;
import snow.SortableTable.*;
import snow.Language.Language;

import java.io.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import javax.swing.plaf.metal.*;
import javax.swing.plaf.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/** should be called prior to any UI creation
*/
public final class ThemesManager
{
  final private AppProperties props = new AppProperties();

  private CustomOceanTheme[] themes;
  private JMenu menu;

  private final File storage;

  // if customized, must be set prior to the first getInstance() call !
  public static String baseDirectory = ".";

  static ThemesManager instance = null;

  public static ThemesManager getInstance()
  {
    if(instance==null)
    {
     instance = new ThemesManager();
    }

    return instance;
  }

  private ThemesManager()
  { 
    storage = new File(baseDirectory, "ThemesManager.props");
    props.load_XML( storage );
    initialize();
  }

  public void saveThemes()
  {   
    props.save_XML( storage );
  } 

  /** should be called once only. INstall the menu
  */
  private void initialize()
  {
    themes = new CustomOceanTheme[]
    {
      new CustomOceanTheme("Ocean Theme", props, null),
      new CustomOceanTheme_Snow(props),
      new CustomOceanTheme_SnowEFCNSmall(props),
      new CustomOceanTheme_Forest(props)
    };
  
    JFrame.setDefaultLookAndFeelDecorated(true);
    installSelectedTheme(); // prior to anything else


    menu = new JMenu("Themes");
    ButtonGroup bg = new ButtonGroup();
    String selectedTheme = props.getProperty("SelectedTheme", "Ocean Theme");
    for(int i=0; i<themes.length; i++)
    {
      boolean isSelected = themes[i].getName().equals(selectedTheme);
      JCheckBoxMenuItem mi = new JCheckBoxMenuItem(themes[i].getName(), isSelected);
      menu.add(mi);
      bg.add(mi);

      final int ii = i;
      mi.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent ae)
        {
           props.setProperty("SelectedTheme", themes[ii].getName());
           props.save_XML( storage );

           installSelectedTheme();

           //MetalLookAndFeel.setCurrentTheme( themes[ii] );
        }
      });
    }

    menu.addSeparator();
    JMenuItem editItem = new JMenuItem(Language.translate("Edit selected theme"));
    menu.add(editItem);
    editItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent ae)
      {
        CustomOceanTheme ct = getSelectedTheme();
        if(ct!=null)
        {
          new CustomOceanEditor(frame, ct, props);
        }
      }
    });

  } // Constructor

  /** this is the main frame, used for dialogs in the menu
  */
  public static JFrame frame;

  /** install or reinstall the selected theme.
  */
  public void installSelectedTheme()
  {

    String selectedTheme = props.getProperty("SelectedTheme", "Ocean Theme");
    for(int i=0; i<themes.length; i++)
    {
      boolean isSelected = themes[i].getName().equals(selectedTheme);
      if(isSelected)
      {
         // important: gradients and all stuff is add here
         themes[i].addCustomEntriesToTable(UIManager.getDefaults());
         MetalLookAndFeel.setCurrentTheme( themes[i] );
         try
         {
           UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
         } catch(Exception e){}


         Frame[] frames = JFrame.getFrames();
         for(int f=0; f<frames.length; f++)
         {
           if(frames[f] instanceof JFrame)
           {
             JFrame ff = (JFrame) frames[f];
             SwingUtilities.updateComponentTreeUI(ff);
             ff.invalidate();
             ff.repaint();

             SwingUtilities.updateComponentTreeUI(ff.getContentPane());
             ff.getContentPane().invalidate();
             ff.getContentPane().repaint();
           }

         }
      }
    }
  } 
  

  public CustomOceanTheme getSelectedTheme()
  {
    String selectedTheme = props.getProperty("SelectedTheme", "Ocean Theme");
    for(int i=0; i<themes.length; i++)
    {
      boolean isSelected = themes[i].getName().equals(selectedTheme);
      if(isSelected) return themes[i];
    }
    return null;
  }


  public JMenu getThemesMenu()
  {
    return menu;
  }  
  
  public Color darkerColor(Color c)
  {
    return c.darker();
  }

  public Color brighterColor(Color c)
  {
    return c.brighter();
  }
                         
  private static final Color redBackground  = new Color(250,100,100);  // red
  private static final Color greenBackground = new Color(100,250,100);  // green
  private static Color falsePositiveBackground = Color.RED;
  private static Font smallFont = new Font("Dialog", Font.PLAIN, 9);



  public Color getGreen()
  {
     CustomOceanTheme cot = getSelectedTheme();
     if(cot==null) return greenBackground;
     return cot.getGreen();
  }

  public Color getRed()
  {
     CustomOceanTheme cot = getSelectedTheme();
     if(cot==null) return redBackground;
     return cot.getRed();
  }

  public Font getSmallFont()
  {
     CustomOceanTheme cot = getSelectedTheme();
     if(cot==null) return smallFont;
     return cot.getSubTextFont();
  }
  
  /** for convenience
  */
  public static int getLabelFontSize()
  {
    return UIManager.getFont("Label.font").getSize();
  }


  /** standalone test
  */
  public static void main(String[] aaa)
  {
     ThemesManager.getInstance();
     JFrame f =new JFrame("Test Theme");
     f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


     f.setJMenuBar(new JMenuBar());
     f.getJMenuBar().add( ThemesManager.getInstance().getThemesMenu() );

     JDesktopPane desktop = new JDesktopPane();
     f.setContentPane(desktop);

     JTree tt = new JTree();
     JInternalFrame ji1 = new JInternalFrame("Tree test", true, true, true, true);
     ji1.getContentPane().add(new JScrollPane(tt), BorderLayout.CENTER);
     ji1.setSize(200,200);
     desktop.add(ji1);
     ji1.setVisible(true);
     try{
       ji1.setSelected(true);
     } catch(Exception e) {}

     JTable ta = new JTable();
     ta.setModel(new TestModel());
     JInternalFrame ji2 = new JInternalFrame("Table test", true, true, true, true);
     ji2.getContentPane().add(new JScrollPane(ta), BorderLayout.CENTER);
     ji2.setSize(400,300);
     ji2.setLocation(220,10);
     desktop.add(ji2);
     ji2.setVisible(true);
     try{
       ji2.setSelected(true);
     } catch(Exception e) {}  


     JInternalFrame ji3 = new JInternalFrame("Some components", true, true, true, true);
     JPanel cont = new JPanel();
     GridLayout3 gl = new GridLayout3(2,cont);
     gl.add(new JLabel("Label"));
     gl.add(new JContrastLabel("Contrast Label"));
     gl.add(new JButton("Button"));
     gl.add(new JSenseButton("Sense button"));
     gl.add("TextField:");
     gl.add( new JTextField("Some text", 30));
                      
     gl.add("Checkbox:");                     
     gl.add( new JCheckBox("do you ?", true));
     gl.add("Combobox:");
     gl.add( new JComboBox(new String[]{"Hello", "This is a test !"}));

     ji3.setContentPane(cont);
     ji3.setSize(400,250);
     ji3.setLocation(20,320);
     desktop.add(ji3);
     ji3.setVisible(true);
     try{
       ji3.setSelected(true);
     } catch(Exception e) {}

     //f.getContentPane().add(new JScrollPane(tt), BorderLayout.CENTER);

/*     CloseControlPanel ccp = new CloseControlPanel(f, true, true, "close");
     f.getContentPane().add(ccp, BorderLayout.SOUTH);*/


     f.setSize(700, 700);
     f.setVisible(true);
  }


} // ThemesManager
