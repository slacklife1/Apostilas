package snow.lookandfeel;

import snow.utils.storage.AppProperties;
import snow.utils.gui.*;

import java.io.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.plaf.metal.*;
import javax.swing.plaf.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public final class CustomOceanTheme_Forest extends CustomOceanTheme
{

  public CustomOceanTheme_Forest(AppProperties props)   
  {
    super("Forest Theme", props, null); //new SnowIcon(200,200));
    writeDefaults();
  }

  /** writes the defaults in the inifile
  */
  public void writeDefaults()
  {
    this.setDefaultFont(this.FONT_ControlText, new FontUIResource("Dialog", Font.PLAIN, 10));
    this.setDefaultFont(this.FONT_System,      new FontUIResource("Dialog", Font.PLAIN, 10));
    this.setDefaultFont(this.FONT_WindowTitle, new FontUIResource("Dialog", Font.BOLD, 11));
    this.setDefaultFont(this.FONT_UserText,    new FontUIResource("SansSerif", Font.PLAIN, 10));
    this.setDefaultFont(this.FONT_SubText,     new FontUIResource("Dialog", Font.PLAIN, 9));

    // Colors
    //     

    // textfield background
    this.setDefaultColor(this.COLOR_White,      new ColorUIResource( 15, 120,  15));   // dark green
    this.setDefaultColor(this.COLOR_BLACK,      new ColorUIResource( 10,  00,  10 ));


    // Title back2, ext frame borders
    this.setDefaultColor(this.COLOR_Primary1,   new ColorUIResource( 84,  103, 83 ));
    // Combobox selections, table, tree selections
    this.setDefaultColor(this.COLOR_Primary2,   new ColorUIResource( 50,  67,  58 ));
    // title back, border of buttons when mouse over, tree selections
    this.setDefaultColor(this.COLOR_Primary3,   new ColorUIResource( 3,  165,  33 ));

    // all components border
    this.setDefaultColor(this.COLOR_Secondary1, new ColorUIResource( 15,  63,  15 ));
    // clicked background, focus checkbox, second button gradient
    this.setDefaultColor(this.COLOR_Secondary2, new ColorUIResource( 48,  63,  48 ));
    // panel background                             
    this.setDefaultColor(this.COLOR_Secondary3, new ColorUIResource( 40, 130, 55 ));

    this.setDefaultColor(this.COLOR_DesktopColor, new ColorUIResource(5, 55, 5));  // dark green

    this.setDefaultColor(this.COLOR_ControlText, new ColorUIResource(0, 0, 0));  // black

  }
    
  /*
  public void addCustomEntriesToTable(UIDefaults table)
  {
                       
    super.addCustomEntriesToTable(table);                                       
                                                                                                     
    java.util.List buttonGradient = Arrays.asList(
                 new Object[] { new Float(.3f), new Float(0f),
                   new ColorUIResource(0xDDE8F3),
                   this.getSecondary3(),                                                  
                   getSecondary2() });    // default: white & secondary2 !!!
                        
    UIManager.put("Button.gradient", buttonGradient);
    UIManager.put("CheckBox.gradient", buttonGradient);
    //UIManager.put("CheckBox.foreground", new ColorUIResource(Color.red));
    //UIManager.put("Tree.rightChildIndent", 15);

  }  */
  
        
  public static void main(String[] aaa)
  {
     ThemesManager.main(aaa);
  }   

         

} // CustomOceanTheme_Forest
