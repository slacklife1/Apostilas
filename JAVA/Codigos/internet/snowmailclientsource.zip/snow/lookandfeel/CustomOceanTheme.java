package snow.lookandfeel;

import snow.utils.storage.AppProperties;

import java.io.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.plaf.metal.*;
import javax.swing.plaf.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class CustomOceanTheme extends OceanTheme
{
  final private String customName;

  // the properties, maybe customized by the user
  final private AppProperties props;

  // each subclass may defins its own defaults (efcn => dark, cloud => bright)
  final private AppProperties themeDefaults = new AppProperties();


  public final static String COLOR_BLACK        = "Black";
  public final static String COLOR_White        = "White";

  public final static String COLOR_Green        = "Green";
  public final static String COLOR_Red          = "Red";

  public final static String COLOR_Primary1     = "Primary 1";
  public final static String COLOR_Primary2     = "Primary 2";
  public final static String COLOR_Primary3     = "Primary 3";

  public final static String COLOR_Secondary1   = "Secondary 1";
  public final static String COLOR_Secondary2   = "Secondary 2";
  public final static String COLOR_Secondary3   = "Secondary 3";

  public final static String COLOR_ControlText  = "ControlTextColor";
  public final static String COLOR_DesktopColor = "DesktopColor";
  public final static String COLOR_InactiveControlText    = "InactiveControlTextColor";
  public final static String COLOR_MenuDisabledForeground = "MenuDisabledForegroundColor";

  public final static String COLOR_TextHighlight = "TextHighlightColor";
  public final static String COLOR_UserText = "UserTextColor";

  public static final String FONT_SubText     = "SubTextFont";
  public static final String FONT_System      = "SystemFont";
  public static final String FONT_UserText    = "UserTextFont";
  public static final String FONT_WindowTitle = "WindowTitleFont";
  public static final String FONT_ControlText = "ControlTextFont";
  public static final String FONT_MenuText    = "MenuTextFont";


  private ImageIcon backgroundImage;

  public CustomOceanTheme(String customName, AppProperties props, ImageIcon backgroundImage)
  {
     super();
     this.customName = customName;
     this.props = props;
     this.backgroundImage = backgroundImage;
     
     this.setDefaultColor(this.COLOR_Green, new ColorUIResource(180,250,180));
     this.setDefaultColor(this.COLOR_Red,   new ColorUIResource(250,180,180));
  } // Constructor   
  
  /** overwrite this if you change something to the theme
  */
  public void writeDefaults()
  {
  }

  public String getName() { return customName; }
     
 /**
  *  Returns the background image for this theme if it exists,
  *  and null otherwise.
  */
  public ImageIcon getBackgroundImage()
  {
    return this.backgroundImage;
  }      

  //
  // COLORS
  //

  public ColorUIResource getBlack()                   { return getColor(COLOR_BLACK);        }
  public ColorUIResource getWhite()                   { return getColor(COLOR_White);        }
  public ColorUIResource getGreen()                   { return getColor(COLOR_Green);        }
  public ColorUIResource getRed()                     { return getColor(COLOR_Red);          }  
  protected ColorUIResource getPrimary1()             { return getColor(COLOR_Primary1);     }
  protected ColorUIResource getPrimary2()             { return getColor(COLOR_Primary2);     }
  protected ColorUIResource getPrimary3()             { return getColor(COLOR_Primary3);     }
  protected ColorUIResource getSecondary1()           { return getColor(COLOR_Secondary1);   }
  protected ColorUIResource getSecondary2()           { return getColor(COLOR_Secondary2);   }
  protected ColorUIResource getSecondary3()           { return getColor(COLOR_Secondary3);   }
  
  /** table text
  */
  public ColorUIResource getControlTextColor()        { return getColor(this.COLOR_ControlText);  }
  public ColorUIResource getDesktopColor()            { return getColor(this.COLOR_DesktopColor); }
  public ColorUIResource getInactiveControlTextColor() { return getColor(this.COLOR_InactiveControlText);  }
  public ColorUIResource getMenuDisabledForeground()  { return getColor(this.COLOR_MenuDisabledForeground); }
  public ColorUIResource getTextHighlightColor()      { return getColor(this.COLOR_TextHighlight); }
  public ColorUIResource getUserTextColor() { return getColor(this.COLOR_UserText); }


  /** retrieves a color for this theme
  */
  public ColorUIResource getColor(String key)
  {
    // first look in the user props
    Color found = props.getColor(customName+key, null);
    if(found!=null) return new ColorUIResource(found);

    // if not found, look in the defaults
    found = themeDefaults.getColor(customName+key, null);
    if(found!=null) return new ColorUIResource(found);

    // Not found => look in the default ocean
    if(key.equals(COLOR_BLACK))          return super.getBlack();
    if(key.equals(COLOR_White))          return super.getWhite();
    if(key.equals(COLOR_Primary1))       return super.getPrimary1();
    if(key.equals(COLOR_Primary2))       return super.getPrimary2();
    if(key.equals(COLOR_Primary3))       return super.getPrimary3();
    if(key.equals(COLOR_Secondary1))     return super.getSecondary1();
    if(key.equals(COLOR_Secondary2))     return super.getSecondary2();
    if(key.equals(COLOR_Secondary3))     return super.getSecondary3();  
    
    if(key.equals(COLOR_ControlText))    return super.getControlTextColor();
    if(key.equals(COLOR_DesktopColor))   return super.getDesktopColor();
    if(key.equals(COLOR_InactiveControlText))    return super.getInactiveControlTextColor();
    if(key.equals(COLOR_MenuDisabledForeground)) return super.getMenuDisabledForeground();
    if(key.equals(this.COLOR_TextHighlight)) return super.getTextHighlightColor();
    if(key.equals(COLOR_UserText)) return super.getUserTextColor();
                            
    return new ColorUIResource(Color.cyan);
  }  
  
  /** if null, is removed 
  */
  public void setDefaultColor(String key, Color c)                                                                                                      
  {
    if(c==null)
    {
       themeDefaults.remove(customName+key);
    }
    else
    {
       themeDefaults.setColor(customName+key, c);
    }
  }  
     
  


  
  //
  // Fonts
  //


  public FontUIResource getSubTextFont()      { return getFont(FONT_SubText);     }
  public FontUIResource getSystemTextFont()   { return getFont(FONT_System);      }
  public FontUIResource getUserTextFont()     { return getFont(FONT_UserText);    }
  public FontUIResource getWindowTitleFont()  { return getFont(FONT_WindowTitle); }
  public FontUIResource getControlTextFont()  { return getFont(FONT_ControlText); }
  public FontUIResource getMenuTextFont()     { return getFont(FONT_MenuText);    }

  public FontUIResource getFont(String key)
  {
    Font found = props.getFont(customName+key, null);
    if(found!=null) return new FontUIResource(found);

    found = this.themeDefaults.getFont(customName+key, null);
    if(found!=null) return new FontUIResource(found);

    // Maps defaults with parent
    if(key.equals(FONT_SubText))     return super.getSubTextFont();
    if(key.equals(FONT_System))      return super.getSystemTextFont();
    if(key.equals(FONT_UserText))    return super.getUserTextFont();
    if(key.equals(FONT_WindowTitle)) return super.getWindowTitleFont();
    if(key.equals(FONT_ControlText)) return super.getControlTextFont();
    if(key.equals(FONT_MenuText))    return super.getMenuTextFont();

    return null;
  }     

  public void setDefaultFont(String key, Font f)
  {                         
    if(f==null)
    {                  
       themeDefaults.remove(customName+key);
    }
    else
    {
       themeDefaults.setFont(customName+key, f);
    }
  }
  
  //
  // Edition
  //

  public Vector<String> getKeysForEdition()
  {
    Vector<String> keys = new Vector<String>();
    keys.add( COLOR_BLACK );
    keys.add( COLOR_White );

    keys.add( COLOR_Green );
    keys.add( COLOR_Red );

    keys.add( COLOR_Primary1   );
    keys.add( COLOR_Primary2   );
    keys.add( COLOR_Primary3   );
    keys.add( COLOR_Secondary1 );
    keys.add( COLOR_Secondary2 );
    keys.add( COLOR_Secondary3 );          

    keys.add( COLOR_ControlText );
    keys.add( COLOR_UserText );
    keys.add( COLOR_TextHighlight );
    keys.add( COLOR_DesktopColor );
    keys.add( COLOR_InactiveControlText );
    keys.add( COLOR_MenuDisabledForeground );

    keys.add( FONT_SubText );
    keys.add( FONT_System );
    keys.add( FONT_UserText );
    keys.add( FONT_WindowTitle );
    keys.add( FONT_ControlText );
    keys.add( FONT_MenuText  );
    return keys;
  }

  public Object getResource(String key)
  {
    FontUIResource f = this.getFont(key);
    if(f!=null) return f;
    ColorUIResource c = this.getColor(key);
    return c;
  }

  public void setResource(String key, Object res)
  {
    if(res instanceof Font)
    {
      this.props.setFont(customName+key, (Font) res);
    }
    else if(res instanceof Color)
    {
      this.props.setColor(customName+key, (Color) res);
    }

  }

  public void clearUserSettings()
  {
    for(String s: getKeysForEdition())
    {
      props.setColor(customName+s, null);
      props.setFont(customName+s, null);
    }
    writeDefaults();
  }

  public static void main(String[] aaa)
  {
     ThemesManager.main(aaa);
  }   
       

} // CustomOceanTheme
