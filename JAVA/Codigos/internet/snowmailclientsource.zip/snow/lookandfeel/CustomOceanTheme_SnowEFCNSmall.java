package snow.lookandfeel;

import snow.utils.storage.AppProperties;
import snow.utils.gui.*;

import java.io.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.plaf.metal.*;
import javax.swing.plaf.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public final class CustomOceanTheme_SnowEFCNSmall extends CustomOceanTheme
{
                       
  public CustomOceanTheme_SnowEFCNSmall(AppProperties props)
  {
    super("EFCNBlack Theme", props, null);
    writeDefaults();
  }

  /** writes the defaults in the inifile
  */
  public void writeDefaults()
  {
    this.setDefaultFont(this.FONT_ControlText, new FontUIResource("Dialog", Font.PLAIN, 11));
    this.setDefaultFont(this.FONT_System,      new FontUIResource("Dialog", Font.PLAIN, 11));
    this.setDefaultFont(this.FONT_WindowTitle, new FontUIResource("Dialog", Font.BOLD, 12));
    this.setDefaultFont(this.FONT_UserText,    new FontUIResource("SansSerif", Font.PLAIN, 11));
    this.setDefaultFont(this.FONT_SubText,     new FontUIResource("Dialog", Font.PLAIN, 10));

    // Colors
    //
    // menufont
    this.setDefaultColor(this.COLOR_BLACK,     new ColorUIResource(220, 220, 220 ));  // black is white
    this.setDefaultColor(this.COLOR_White,     new ColorUIResource( 20,  20,  20 ));  // and white is black, no ?

    // Title back, ext frame borders
    this.setDefaultColor(this.COLOR_Primary1,  new ColorUIResource( 98,  88, 112 ));
    // Combobox selections, table, tree selections
    this.setDefaultColor(this.COLOR_Primary2,  new ColorUIResource( 84,  78,  96 ));
    // border of buttons when mouse over, table, tree selections, text highlight
    this.setDefaultColor(this.COLOR_Primary3,  new ColorUIResource( 80,  75,  91 ));  // too dark

    // all components border
    this.setDefaultColor(this.COLOR_Secondary1, new ColorUIResource( 53,  58,  73 ));
    // clicked background, focus checkbox, second button gradient
    this.setDefaultColor(this.COLOR_Secondary2, new ColorUIResource( 80,  84,  80 ));
    // panel background
    this.setDefaultColor(this.COLOR_Secondary3, new ColorUIResource( 40, 40, 40));
       // too light new ColorUIResource(116, 122, 116 ));

    this.setDefaultColor(this.COLOR_Green,     new ColorUIResource(30, 120, 30));
    this.setDefaultColor(this.COLOR_Red,       new ColorUIResource(120, 30, 30));

    this.setDefaultColor(this.COLOR_DesktopColor, new ColorUIResource(55, 55, 55));  // drak gray

    // table text
    this.setDefaultColor(this.COLOR_ControlText, new ColorUIResource(220, 220, 220));


    //addCustomEntriesToTable(UIManager.getDefaults());
  }


  public void addCustomEntriesToTable(UIDefaults table)
  {                                          

    super.addCustomEntriesToTable(table);                                       
    
    //if(true) return;
    
    /*Original
    java.util.List buttonGradient = Arrays.asList(                
                 new Object[] {new Float(.3f), new Float(0f),
                 new ColorUIResource(0xDDE8F3), getWhite(), getSecondary2() }); */

    java.util.List buttonGradient = Arrays.asList(
                 new Object[] {new Float(0.3f), new Float(0.45f),
                 getBlack(), getWhite(), getBlack() });
                                                      

    UIManager.put("Button.gradient", buttonGradient);
    UIManager.put("CheckBox.gradient", buttonGradient);                
    UIManager.put("InternalFrame.activeTitleGradient", buttonGradient);

/*DEF    java.util.List menubGradient = Arrays.asList(new Object[] {
                     new Float(1f), new Float(0f),
                     getWhite(), dadada,
                     new ColorUIResource(dadada) });*/ 
                     
    Color dadada = new ColorUIResource(0xDADADA);
    java.util.List menubGradient = Arrays.asList(new Object[] {
                     new Float(2f), new Float(0f),
                     getWhite(), dadada,
                     new ColorUIResource(dadada) });

    UIManager.put("MenuBar.gradient", menubGradient);
  }       

  public static void main(String[] aaa)
  {
     ThemesManager.main(aaa);
  }   


} // CustomOceanTheme_SnowEFCNSmall
