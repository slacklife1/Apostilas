package snow.lookandfeel;

import snow.utils.storage.AppProperties;
import snow.utils.gui.*;
import snow.SortableTable.*;
import snow.Language.Language;

import java.io.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.plaf.metal.*;
import javax.swing.plaf.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public final class CustomOceanEditor extends JDialog
{
  final private CustomOceanTheme theme; 
  final private UIKeysTableModel tableModel;
  final private SortableTableModel sortableTableModel;
  final private JTable table;

  public CustomOceanEditor(JFrame parent, final CustomOceanTheme theme, final AppProperties props)
  {
    super(parent, "Theme editor", false);
    getContentPane().setLayout(new BorderLayout());
    
    this.theme = theme;

    tableModel = new UIKeysTableModel(theme.getKeysForEdition());
    sortableTableModel = new SortableTableModel(tableModel, 0, true);
    table = new JTable(sortableTableModel);
    sortableTableModel.installGUI(table);
      
    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    sortableTableModel.installGUI(table);
                                            
    table.setDefaultRenderer(Object.class, new UniversalTableCellRenderer(sortableTableModel));
    table.setDefaultEditor(Object.class, new UniversalTableEditor());

    AdvancedSearchPanel asp = new AdvancedSearchPanel(Language.translate("Search")+": ", null, sortableTableModel, true);
    getContentPane().add(asp, BorderLayout.NORTH);

    JSenseButton clearButton = new JSenseButton(Language.translate("Reset theme"));
    asp.add(clearButton);
    clearButton.addActionListener(new ActionListener()
    {  
      public void actionPerformed(ActionEvent ae)
      {
         theme.clearUserSettings();
         ThemesManager.getInstance().saveThemes();
         ThemesManager.getInstance().installSelectedTheme();
         tableModel.updateWholeTable();
      }
    });

    

    getContentPane().add(new JScrollPane(table), BorderLayout.CENTER);

    CloseControlPanel ccp = new CloseControlPanel(this, false, false, "Close");
    getContentPane().add(ccp, BorderLayout.SOUTH);

    this.setLocation(300,300);
    setSize(550, 550);  
    setVisible(true);                                                                                                

  } // Constructor



  class UIKeysTableModel extends FineGrainTableModel
  {  
     final private Vector<String> keys = new Vector<String>();
     public UIKeysTableModel(Vector<String> keys)
     {
        this.keys.addAll(keys);
     }


     private char[] representableCharsetChars = null;

     String[] COLUMN_NAMES = new String[]{"name", "value" };

     int[] COLUMN_PREFERED_SIZES = new int[]{20, 20, 25};
     public int getPreferredColumnWidth(int column)                
     {                        
       if(column>=0 && column<COLUMN_PREFERED_SIZES.length) return COLUMN_PREFERED_SIZES[column];
       return -1;
     }

     public String getColumnName(int col) { return COLUMN_NAMES[col]; }

     public int getColumnAlignment(int column)
     {
       return JLabel.LEFT;
     }
                         


     public int getColumnCount() { return COLUMN_NAMES.length; }
     public int getRowCount()    { return keys.size(); }


     public Object getValueAt(int row, int col)
     {
       String key = (String) keys.elementAt(row);
       Object val = theme.getResource(key);

       if(col==0) return key;
       if(col==1)
       {
         if(val==null) return "null value";
         return val;    
       }

       return "?";
     }
     
     public boolean isCellEditable(int row, int col)
     {
       return col==1;
     } 
     
     public void updateWholeTable()
     {
       this.fireTableModelWillChange();
       this.fireTableDataChanged();
       this.fireTableModelHasChanged();
     }
     
     
     public void setValueAt(Object value, int row, int col)
     {
       if(col!=1) return;
       
       boolean updateUI = false;
       if(value instanceof Color)
       {
         value = new ColorUIResource((Color) value);
         updateUI = true;
       }

       if(value instanceof Font)
       {
         value = new FontUIResource((Font) value);
         updateUI = true;
       }

       if(row>=keys.size())
       {
          System.out.println("Key position "+row+" son't exist, keys size is only "+keys.size());
          return;
       }

       String key = (String) keys.elementAt(row);
       Object old = theme.getResource(key);

       if(old!=null && value!=null && !(old.getClass() == value.getClass()))
       {
         System.out.println("Attemp to changing class type ! set value cancelled");
         System.out.println(old.getClass().getName()+" => "+value.getClass().getName());

        // return;
       }

       this.fireTableModelWillChange();

       theme.setResource(key, value);

       this.fireTableDataChanged();
       this.fireTableModelHasChanged();  
       
       ThemesManager.getInstance().saveThemes();  
       if(updateUI)
       {
         ThemesManager.getInstance().installSelectedTheme();  
       }
     }
  }         


} // CustomOceanEditor
