package snow.SortableTable;

public final class TestModelItem
{

  public TestModelItem()
  {             
     checked = Math.random()>0.5;
  } // Constructor
  
                    
  public double col1;
  public String col2;
  public int col3;
  public int col4;
  public int col5;                
  public boolean checked = false;

  // for selection only
  public boolean selected = false;

                     
} // TestModelItem
