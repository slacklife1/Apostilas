package snow.SortableTable;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

/** a small utility to add a search panel to a sortable table viewer
*/
public final class SearchPanel extends JPanel
{
  final private SortableTableModel stm;

  final protected JTextField searchFT = new JTextField(6);
  final protected JTextField searchFT2 = new JTextField(6);
  final protected JCheckBox useRegExCB = new JCheckBox("RegEx", false);

  /** @param secondSearch if true, two fields are shown, alowing an AND search
      @param searchLabelText is normally "Search: "
  */
  public SearchPanel(final String searchLabelText, final Icon searchIcon,
                     final SortableTableModel stm, final boolean secondSearch, final boolean allowRegEx)
  {
    super(new FlowLayout(FlowLayout.LEFT));
    this.stm = stm;

    // Components
    //
    add(new JLabel(searchLabelText, searchIcon, JLabel.LEFT));
    add(searchFT);                   

    if(secondSearch)
    {
      add(new JLabel(" & "));
      add(searchFT2);
    }   
    
    if(allowRegEx)
    {
      add(useRegExCB);
    }
                
    // key listener
    //
    KeyAdapter kad = new KeyAdapter()
    {
      @Override public void keyReleased(KeyEvent ee)
      {                         
        doSearch();
      }
    };  

    searchFT.addKeyListener(kad);
    searchFT2.addKeyListener(kad);
    
    // focus behaviour
    //

    searchFT.addFocusListener(new FocusAdapter()
    {
       @Override public void focusGained(FocusEvent e)
       {
          searchFT.selectAll();
       }
    });
    searchFT2.addFocusListener(new FocusAdapter()
    {
       @Override public void focusGained(FocusEvent e)
       {
          searchFT2.selectAll();
       }
    });  
    
    // CTRL+F mapping
    //

    this.registerKeyboardAction(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          searchFT.requestFocus();
        }
      },
      KeyStroke.getKeyStroke(KeyEvent.VK_F, KeyEvent.CTRL_DOWN_MASK),
      JComponent.WHEN_IN_FOCUSED_WINDOW
    );  // ### Maybe pass the parent as argument reference and register actions on it.
        // It makes sense if several internal frames have searches...


  } 
  
  
  public void doSearch()
  {
    stm.search(searchFT.getText(), searchFT2.getText(), useRegExCB.isSelected());
  }
  
  
  public void setSearchText(String t1, String t2)
  {
     searchFT.setText(t1);
     searchFT2.setText(t2);
  }

} // SearchPanel
