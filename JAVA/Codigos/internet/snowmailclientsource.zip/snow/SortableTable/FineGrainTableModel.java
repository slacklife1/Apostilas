package snow.SortableTable;

import javax.swing.table.*;
import java.util.*;
import javax.swing.JTable;
import javax.swing.event.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.regex.*;


                
/** this table model define a new TableModelChangeListener
   this model should be used with the SortableTableModel to allow
   keeping the selection when table model changes.
    
   HOWTO use:
    + by each modification of this model (i.e. in SetValue())
      First call before change :  fireModelWillChange()
      After change             :  fireTableDataChanged() and fireModelHasChanged() 
*/
public abstract class FineGrainTableModel extends AbstractTableModel
{                           
  final Vector<TableModelChangeListener> modelListeners = new Vector<TableModelChangeListener>();
  
     
  public FineGrainTableModel()
  {
                  
  } // Constructor  
  

 /** important, this allow the table to determine which renderer to use
     (checkbox for Boolean, ...)
  */
  public Class getColumnClass ( int column )
  {
     if(this.getColumnCount()==0 || this.getRowCount()==0)
     {                 
        return Object.class.getClass();
     }
     
     Object val = this.getValueAt(0,column);
     if(val==null) return String.class;
     return val.getClass();
  }  


  /** To sort columns... owerwrite if you need a better (or faster) sorting
  */
  public int compareForColumnSort(int pos1, int pos2, int col)
  {
    Object val1 = this.getValueAt(pos1,col);
    Object val2 = this.getValueAt(pos2,col);

    if(val1 instanceof Comparable)
    {  
       return ((Comparable) val1).compareTo(val2);
    }
    else if(val1 instanceof Boolean)
    {
       return compareBooleans((Boolean) val1, (Boolean) val2);
    }
    else
    {
       // compare as a String
       return (""+val1.toString()).compareTo(this.getValueAt(pos2,col).toString());
    }
  } 
  

  /** @return true if the txt appears in the given row
      overwrite it if you want a special search (Approximate, numerical, ...)
      @param if not null, regex search p should be used.
  */
  public boolean hitForTextSearch(int row, String txt, Pattern p)
  {                                                                                             
     if(txt==null || txt.equals("")) return true;
     String search = txt.toUpperCase();
                                                                                                
     for(int col=0; col<this.getColumnCount(); col++)
     {
        String val = this.getValueAt(row,col).toString();
        if(p!=null)
        {
          Matcher m = p.matcher(val);
          return m.matches();
        }
        else
        {
          if(val.toUpperCase().indexOf(search)>=0) return true;
        }
     }
     return false;
  } 
  
  /** @return true if the txt appears in the given row and column
      overwrite it if you want a special search (Approximate, numerical, ...)
      
      This is used in the advanced search
  */                                             
  public boolean hitForTextSearch(int row, int column, String txt, Pattern p)
  {
     //System.out.println("Search("+row+", "+column+")");
     if(column==-1) return hitForTextSearch(row, txt, p);
     
     if(txt==null || txt.equals("")) return true;
     String search = txt.toUpperCase();
     String val = this.getValueAt(row,column).toString();
     if(val.toUpperCase().indexOf(search)>=0) return true;
                                       
     return false;
  }   
  
  /** overwrite this is you want to specify a default width... (measured in Label.font size).
      -1 do nothing. Any positive value will be used as preferred width.
                                                                                       
      To be effective, the table must be set in
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
      before call installGUI()
  */
  public int getPreferredColumnWidth(int column)
  {
    return -1;    
  }     
  
  public int getColumnAlignment(int column)
  {
    return JLabel.LEFT;
  }  

/*  public final boolean hitForTextSearch(int row, String txt)
  {
   return true;
  }*/

  // Selection
  //
  // These four methods are not abstract,
  //     public void setRowSelection(int row, boolean isSelected)
  //     public boolean isRowSelected(int row)
  //     public void clearRowSelection()
  //     public int[] getSelectedRows()
  //
  // Here implemented is a non persistant selection mechanism.
  // overwrite it to provide a selection that is stored in your model
  //
  //
                                                                                  
  private HashSet<Integer> selectedRows = new HashSet<Integer>();


  /** used to select/deselect a given row.                                                       
      this method doesn't fire any events
      overwrite this AND THE TWO OTHERS selection method to provide your
      selection mechanism. (maybe storing it in the model items)

 public void setRowSelection(int row, boolean isSelected)            
 public boolean isRowSelected(int row)
 public void clearRowSelection()

                                                                    
      EACH model row deletion will destroy sense of this selection.
      => MUST NORMALLY BY OVERWRITTEN
  */                                                                    
  public void setRowSelection(int row, boolean isSelected)
  {
    if(isSelected)
    {
      selectedRows.add( row );
    }
    else
    {
      selectedRows.remove( row );
    }
  }

  /** tells if the row is selected
  */
  public boolean isRowSelected(int row)
  {
    return selectedRows.contains( row );
  }

  public void clearRowSelection()
  {
    for(int i=0; i<this.getRowCount(); i++)
    {
      this.setRowSelection(i, false);
    }
  }

  /** overwrite only if you want to boost.
     This method use isRowSelected(row) to detect which rows are selected.
  */
  public int[] getSelectedRows()
  {
    // slow but robust
    //
    Vector<Integer> sel = new Vector<Integer>();
    synchronized(this)
    {
      for(int i=0; i<getRowCount(); i++)
      {
        if(isRowSelected(i)) sel.add(i);
      }
      int[] rep = new int[sel.size()];  
      
      for(int i=0; i<rep.length; i++)
      {
        rep[i] = (Integer) sel.elementAt(i);
      }
      return rep;  
    }

  }
                 



  // Model Listener
  //
  public void addModelChangeListener(TableModelChangeListener listener)
  {            
     modelListeners.addElement(listener);
  }

  public void removeModelChangeListener(TableModelChangeListener listener)
  {
     modelListeners.removeElement(listener);
  }

  public void fireTableModelWillChange()
  {
    TableModelChangeListener[] tml = null;
    synchronized(modelListeners)
    {
       // do a copy of the listeners to decouple them from the vector
       // because they may perform operation on the vector in the notify loop (remove listener)
       // and caus concurrent modification exceptions
       tml = (TableModelChangeListener[]) modelListeners.toArray(new TableModelChangeListener[modelListeners.size()]);
    }
    for(int i=tml.length-1; i>=0; i--) // last added first
    {
       tml[i].tableModelWillChange(new ChangeEvent(this));
    }
  }

  public void fireTableModelHasChanged()
  {
    TableModelChangeListener[] tml = null;
    synchronized(modelListeners)
    {
       // do a copy of the listeners to decouple them from the vector
       // because they may perform operation on the vector in the notify loop (remove listener)
       // and caus concurrent modification exceptions
       tml = (TableModelChangeListener[]) modelListeners.toArray(new TableModelChangeListener[modelListeners.size()]);
    }
    for(int i=tml.length-1; i>=0; i--) // last added first
    {
       tml[i].tableModelHasChanged(new ChangeEvent(this));
    }
  }
                                          
  
  // Some utilities for comparaison
  //
  
  public static int compareInts(int i1, int i2)
  {
    if(i1==i2) return 0;
    if(i1>i2)  return 1;
    return -1;
  }


  public static int compareDoubles(double i1, double i2)
  {
    if(i1==i2) return 0;
    if(i1>i2)  return 1;
    return -1;
  }

  public static int compareBooleans(boolean b1, boolean b2)
  {
    if(b1==b2) return 0;
    if(b1)     return 1;
    return -1;
  }


} // FineGrainTableModel
