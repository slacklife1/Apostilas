package snow.SortableTable;


import java.awt.*;
import java.awt.event.*;        
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;           
                                                      
import java.util.*;


/** wraps around a table model to extract first column of rest
*/
public class RowHeaderExtractorWrapperTableModel extends FineGrainTableModel
{
  boolean first;
  FineGrainTableModel baseModel;
  int numberOfColumnHeaders;
             
  public RowHeaderExtractorWrapperTableModel(boolean first, FineGrainTableModel baseModel, int numberOfColumnHeaders)
  {
    this.first = first;
    this.baseModel = baseModel;
    this.numberOfColumnHeaders = numberOfColumnHeaders;

    // give the events of the bassModel to this
    baseModel.addTableModelListener(new TableModelListener()
    {
       public void tableChanged(TableModelEvent e)
       {
          fireTableDataChanged();
       }
    });
  } // Constructor


  private int getColumn(int col)
  {
    if(first) return col;
    return col + numberOfColumnHeaders;
  }

  // AbstractTableModel impl
  //



  public int getRowCount() {return baseModel.getRowCount();}

  public int getColumnCount() 
  {
    return (first?
       numberOfColumnHeaders
      :baseModel.getColumnCount()-numberOfColumnHeaders);
  }
                                                                               

  public Object getValueAt(int row, int column)
  {
     return baseModel.getValueAt(row,  getColumn(column));
  }       

  public boolean hitForTextSearch(int row, String str)
  {
     return baseModel.hitForTextSearch(row,  str, null);
  }

  public boolean isCellEditable(int row, int col)
  {
     return baseModel.isCellEditable(row, getColumn(col));
  }                        

  public void setValueAt(Object val, int row, int col)
  {
     super.setValueAt(val, row, getColumn(col));
  }

  public String getColumnName(int column)
  {
     return baseModel.getColumnName( getColumn(column) );

  }                                                                                               

  public Class getColumnClass(int col)
  {
     return baseModel.getColumnClass(getColumn(col));
  }

  public int compareForColumnSort(int pos1, int pos2, int col)
  {
    return baseModel.compareForColumnSort(pos1, pos2, getColumn(col) );
  }

  public int getPreferredColumnWidth(int col)
  {
    return baseModel.getPreferredColumnWidth( getColumn(col) );
  }



} // RowHeaderExtractorWrapperTableModel
