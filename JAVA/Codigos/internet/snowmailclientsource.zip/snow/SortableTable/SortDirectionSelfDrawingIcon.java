package snow.SortableTable;

 /**
  *  An Icon, which draws its content using awt/swing
  *  without connection to a file on disk.
  *
  *  This one is specialized for the views of filetree's.
  *  It draws file and directory icons.
  *
  *  On themechanges, best is to just recreate and set this renderer.
  *
  */

import java.util.Vector;
import java.awt.*;
import java.awt.event.*;
import java.awt.font.*;
import java.awt.geom.*;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.plaf.*;
import javax.swing.plaf.metal.*;





public class SortDirectionSelfDrawingIcon implements Icon
{

  // The icon file types, to be passed to the constructor :


  // types :
  public static final int Ascending = 1;
  public static final int Descending = 2;
  public static final int Left = 3;
  public static final int Right = 4;


  // Private color keys :
/*  private static final int ColorBlack   = 0; // Black -> black or white, depends on background
  private static final int ColorRed     = 1;
  private static final int ColorGreen   = 2;
  private static final int ColorBlue    = 3;     // All colors are set dependent on the background
  private static final int ColorYellow  = 4;     // so that a certain contrast is guaranteed.
  private static final int ColorGray    = 5;
  private static final int ColorOrange  = 6;     */

  // Member attributes :
  private Color shapeBorderColor = null;

  private int height = 0;
  private int width  = 0;


  private GradientShapeEntity[] shapeEntities = null;
  // The shape entities to be drawn. They are children

  private Font basisFont;  // Used for geometric size calculations.

  private int strokeThickness = 1;



 /**
  *  Creates a filetreeicon with the specified type.
  *  The available types are defined static in this class.
  */
  public SortDirectionSelfDrawingIcon( final int iconStyle )
  {
     //JTableHeader g;
    this.basisFont = UIManager.getFont("Tree.font");
    this.strokeThickness = 1 + this.basisFont.getSize()/16;
    this.defineIcon( iconStyle );
  } // Constructor







  private void defineIcon( final int iconStyle )
  {
    // Give directories constant UI independent signal colors :
//    this.textColor = new Color(60,90,140);

    final Color bg = UIManager.getColor("TextField.background");
    final Color fg = UIManager.getColor("TextField.foreground");

    // border color [UI dependant] :
    int r = ( bg.getRed()   + 4*fg.getRed()   ) / 5;
    int g = ( bg.getGreen() + 4*fg.getGreen() ) / 5;
    int b = ( bg.getBlue()  + 4*fg.getBlue()  ) / 5;
    this.shapeBorderColor = new Color(r,g,b);

    // Icon size :
    this.height = 0;
    this.width  = 0;

    // The font metrics has changed a bit since jdk 1.4, so adjust the sizes :
    String version = System.getProperty("java.version");
    if( version.compareTo("1.4") < 0 )
     {
       // jdk 1.3 or less :
       // Icon size :
       this.height = ( 4*this.basisFont.getSize() )/3;
       this.width = this.height/2;
     }
    else
     {
       // jdk 1.4 or later :
       // Icon size :
       this.height = (7*this.basisFont.getSize()/6);
       this.width = this.height/2;
     }

    // The shape entities :
    Vector<GradientShapeEntity> shapeVector = new Vector<GradientShapeEntity>();
    GradientShapeEntity shape = null; // a work attribute
    Color shapeInsideColor = null;
    Color shapeInsideSelectedColor = null;
    int verticalOffset = this.height/4;
    int h2 = this.height*3/4;

    int halfHeight = 0;
    // 1) main body : 3 cases :
    switch( iconStyle )
     {
       case Ascending :
            // inside colors [ UI independant : default green ]:
            shapeInsideColor = new Color(130,242,110);
            shapeInsideSelectedColor = new Color(190,250,170);
            shape = new GradientShapeEntity( this.shapeBorderColor,
                                             this.shapeBorderColor,
                                             shapeInsideColor,
                                             shapeInsideSelectedColor,
                                             1f * this.width,
                                             0f,
                                             this.strokeThickness );
            shape.moveTo(0,verticalOffset);
            shape.lineTo(this.width/2,h2);
            shape.lineTo(this.width,verticalOffset);
            shape.closePath();
            shapeVector.addElement( shape );
            break;

       case Descending :    
            // inside colors [ UI independant : default green ]:
            shapeInsideColor = new Color(130,242,110);
            shapeInsideSelectedColor = new Color(190,250,170);
            shape = new GradientShapeEntity( this.shapeBorderColor,
                                             this.shapeBorderColor,
                                             shapeInsideColor,
                                             shapeInsideSelectedColor,
                                             1f * this.width,
                                             0f,
                                             this.strokeThickness );
            shape.moveTo(0,h2);
            shape.lineTo(this.width/2,verticalOffset);
            shape.lineTo(this.width,h2);
            shape.closePath();
            shapeVector.addElement( shape );
            break;

       case Left :
            // inside colors [ UI independant : default green ]:
            shapeInsideColor = new Color(130,242,110);
            shapeInsideSelectedColor = new Color(190,250,170);
            shape = new GradientShapeEntity( this.shapeBorderColor,
                                             this.shapeBorderColor,
                                             shapeInsideColor,
                                             shapeInsideSelectedColor,
                                             1f * this.width,
                                             0f,
                                             this.strokeThickness );
            shape.moveTo(width,height);
            shape.lineTo(width/4, height/2);
            shape.lineTo(width,0);
            shape.closePath();  
            shapeVector.addElement( shape );
            break;

       case Right :
       
            // inside colors [ UI independant : default green ]:
            shapeInsideColor = new Color(130,242,110);
            shapeInsideSelectedColor = new Color(190,250,170);
            shape = new GradientShapeEntity(this.shapeBorderColor,
                                             this.shapeBorderColor,
                                             shapeInsideColor,
                                             shapeInsideSelectedColor,
                                             1f * this.width,
                                             0f,
                                             this.strokeThickness );
            shape.moveTo(0,height);
            shape.lineTo(width*3/4, height/2);
            shape.lineTo(0,0);
            shape.closePath();   
            shapeVector.addElement( shape );
            break;   

   
            
       default:
     } // switch  


    // Copy the entities into the shapeEntities member array :
    this.shapeEntities = new GradientShapeEntity[ shapeVector.size() ];
    shapeVector.copyInto( this.shapeEntities );
  } // defineIconForDirectory







 /**
  *   Draws the icon at the specified location.  Icon implementations
  *   may use the Component argument to get properties useful for
  *   painting, e.g. the foreground or background color.
  */
  public void paintIcon( Component c, Graphics g, int x, int y )
  {
    final Graphics2D graphics2D = (Graphics2D)g;
    // Backup:
    final Color saveColor = graphics2D.getColor();
    final AffineTransform backupTransform = graphics2D.getTransform();
    g.translate(x,y);
    final Stroke backupStroke = graphics2D.getStroke();
    final Paint savePaint = graphics2D.getPaint();

    final Object backupAntiAliasRendering = graphics2D.getRenderingHint( RenderingHints.KEY_ANTIALIASING );
    final Object backupQualityRendering = graphics2D.getRenderingHint( RenderingHints.KEY_RENDERING );

    // Reconfigure / draw:

    graphics2D.setRenderingHint( RenderingHints.KEY_ANTIALIASING,
                                 RenderingHints.VALUE_ANTIALIAS_ON );
    graphics2D.setRenderingHint( RenderingHints.KEY_RENDERING,
                                 RenderingHints.VALUE_RENDER_QUALITY );


    for( int i=0; i < this.shapeEntities.length; i++ )
     {
       this.shapeEntities[i].paint( graphics2D );
     }

    // Restore :
    graphics2D.setTransform( backupTransform );
    graphics2D.setColor(saveColor);
    graphics2D.setStroke(backupStroke);

    graphics2D.setRenderingHint( RenderingHints.KEY_ANTIALIASING,backupAntiAliasRendering );
    graphics2D.setRenderingHint( RenderingHints.KEY_RENDERING,backupQualityRendering );

    graphics2D.setPaint(savePaint);
  } // paintIcon





  /**
   * Returns the icon's width.
   *
   * @return an int specifying the fixed width of the icon.
   */
  public int getIconWidth()
  {
    return this.width + 1 + this.basisFont.getSize()/10; // always add a small offset
  }



  /**
   * Returns the icon's height.
   *
   * @return an int specifying the fixed height of the icon.
   */
  public int getIconHeight()
  {
    return this.height + 1 + this.basisFont.getSize()/10; // always add a small offset
  }






  /*
  private Color createColorWithContrastToBackground( final int textColorKey )
  {
    final Color background = UIManager.getColor("TextField.background");
    final int average = (background.getRed()+background.getGreen()+background.getBlue())/3;
    int contrast = 255-average;
    if( contrast < 50  ) contrast =  50; // dont saturate all
    if( contrast > 200 ) contrast = 200; // dont saturate all
    Color c = null;
    switch( textColorKey )
     {
       case ColorBlack :
            if( average > 122 )
             {
               c = new Color(0,0,0);
             } else
             {
               c = new Color(255,255,255);
             }
            break;
       case ColorRed :
               c = this.createColorFromFractions(0.850,0.075,0.075,contrast);
            break;
       case ColorOrange :
               c = this.createColorFromFractions(0.500,0.350,0.150,contrast);
            break;
       case ColorYellow :
               c = this.createColorFromFractions(0.450,0.450,0.100,contrast);
            break;
       case ColorGreen :
               c = this.createColorFromFractions(0.075,0.850,0.075,contrast);
            break;
       case ColorBlue :
               c = this.createColorFromFractions(0.075,0.075,0.850,contrast);
            break;
       case ColorGray :
               c = new Color( contrast,contrast,contrast );
            break;
       default :
            c = new Color(30,30,30); // should not happen
     } // case
    return c;
  }  */



 /**
  *  Creates a color with the passed color fractions, which
  *  has the passed average value.
  *  The sum of the fractions should equal one.
  *
  private Color createColorFromFractions(  final double rFraction,
                                           final double gFraction,
                                           final double bFraction,
                                           final int grayScaleAverage )
  {
    final double avInitial = ( rFraction + gFraction + bFraction ) / 3.0;
    double scalingFactor = 1.0;
    if( avInitial > 1e-10 )
     {
       scalingFactor = 1.0 * grayScaleAverage / avInitial;
     }
    double r = rFraction * scalingFactor;
    double g = gFraction * scalingFactor;
    double b = bFraction * scalingFactor;
    // If we can't reach the fractions, try to hold the average
    // by transferring from the biggest value. Its only
    // an approximative correction somehow, not more :
    if(  (rFraction > gFraction) && (rFraction > bFraction) )
     {
       if( r > 255.0 )
        {
          final double halfOver = (r-255.0)/2.0;
          r = 255.0;
          g += halfOver;
          b += halfOver;
        }
     }
    else
    if(  (gFraction > rFraction) && (gFraction > bFraction) )
     {
       if( g > 255.0 )
        {
          final double halfOver = (g-255.0)/2.0;
          g = 255.0;
          r += halfOver;
          b += halfOver;
        }
     }
    else
    if(  (bFraction > rFraction) && (bFraction > gFraction) )
     {
       if( b > 255.0 )
        {
          final double halfOver = (b-255.0)/2.0;
          b = 255.0;
          r += halfOver;
          g += halfOver;
        }
     }
    // chop:
    if( r > 255.0 ) r = 255;
    if( g > 255.0 ) g = 255;
    if( b > 255.0 ) b = 255;
    return new Color( (int)r, (int)g, (int)b );
  }*/





} // SelfDrawingFileTreeIcon





