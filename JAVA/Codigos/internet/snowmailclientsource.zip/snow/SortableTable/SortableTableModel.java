package snow.SortableTable;


import javax.swing.table.*;
import javax.swing.JTable;
import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.*;                                                           
import java.util.regex.*;


/** this model wraps a basic model and allow sorting of his columns
    the basic model remains unchanged. Only this model is sorted !
    Features :
      + The selection is maintained after table updates.
      + Can installGUI() without corrupting model/view separation      

    usage:
      1) make a FineGrain table model (like AbstractTableModel...)
      2) make this class, pass 1)
      3) make a table with this model 2)
      4) call installGUI() with the table 3) to allow sorting
                      
*/
public class SortableTableModel extends AbstractTableModel
{
  // these are the indices in the unsirted model corresponding to the position in this
  // sorted model. element i is for position i in this table
  // WITHOUT SEARCH HITS   
  final Vector<Integer> sortedRowIndices = new Vector<Integer>();

  // i-th element is the index in the basic model of the ith found element
  final Vector<Integer> foundBasicIndices = new Vector<Integer>();

  // this is the unsorted model
  private FineGrainTableModel basicTableModel;
  
  public final static Icon SORT_ASC  = new SortDirectionSelfDrawingIcon(SortDirectionSelfDrawingIcon.Ascending);
  public final static Icon SORT_DESC = new SortDirectionSelfDrawingIcon(SortDirectionSelfDrawingIcon.Descending);
                  


  // used to remember selection when table change
  JTable tableReference;
  JTable tableRowHeadersReference;
  int numberOfColumnAsRowHeaders = 0;


  // contain the basic model column indices to show (selected = visible)
  // 0, 1, 3, 4    for example if column2 is not visible
  final private TreeSet selectedColumns = new TreeSet();
                 
  private boolean columnVisibilitiesChangeEnable = true;

  /** wraps a sortable feature around your basic table model

    Easy usage:
      1) just create your model, pass it here
      2) use this model as tablemodel for your jtable.
      3) After that, call installGUI and pass your JTable as argument.
  */
  public SortableTableModel(FineGrainTableModel basicTableModel)
  {
     this(basicTableModel, 0, true);
  }     
  
  public FineGrainTableModel getBasicTableModel()
  {
    return basicTableModel; 
  }

  TableModelListener tableModelListener = null;
  TableModelChangeListener tableModelChangeListener = null;


  /** wraps a sortable feature around your basic table model

    Easy usage:
      1) just create your model, pass it here
      2) use this model as tablemodel for your jtable.
      3) After that, call installGUI and pass your JTable as argument.
  */
  public SortableTableModel(FineGrainTableModel basicTableModel,
                            int sortedColumn, boolean ascending)
  {
     setBasicTableModel(basicTableModel, sortedColumn, ascending);
  }                

                  
  public void setBasicTableModel(FineGrainTableModel basicTableModel,
                            int sortedColumn, boolean ascending)
  {  
     removeOldListeners();
     
     this.basicTableModel = basicTableModel;
     this.sortedColumnInBasicModel = sortedColumn;
     this.ascending       = ascending;

     basicTableModel.addTableModelListener(tableModelListener = new TableModelListener()
     {
        // called after the table has changed
        public void tableChanged(TableModelEvent e)
        {
           //System.out.println("received tableChanged event from unsortedModel");
           createRangeForSorting();   // range 0,...,n-1
           internalSort();
           internal_search();

           // pass the event in same EDT for this listener
           fireTableDataChanged();
           //tableChanged(e);  // index mismatch... should convert them... ###
        }
     });

     basicTableModel.addModelChangeListener(tableModelChangeListener = new TableModelChangeListener()
     {
         public void tableModelWillChange(ChangeEvent e)
         {       
           storeTableSelection();
         }

         public void tableModelHasChanged(ChangeEvent e)
         {
           restoreTableSelections();
         }
     });

     // all columns are selected
     for(int i=0; i<basicTableModel.getColumnCount(); i++)
     {
        selectedColumns.add(i);
     }

     // initial sort
     createRangeForSorting();
     sort(sortedColumn, ascending);
     internal_search();
            
            
     restoreTableSelections();  // ??? not now, but when table installed !!

  } // Constructor     
                                  

  public void removeOldListeners()
  {
     if(basicTableModel!=null)
     {
       basicTableModel.removeTableModelListener(tableModelListener);
       basicTableModel.removeModelChangeListener(tableModelChangeListener);
     }                   

     if(tableHeadClickMouseAdapter!=null)
     {
        tableRowHeadersReference.removeMouseListener(tableHeadClickMouseAdapter);
     }
     if(tableRefClickMouseAdapter!=null)
     {
        tableReference.removeMouseListener(tableRefClickMouseAdapter);
     }
  }  
  

  /** only call this when you terminate the table,
      to keep selection stored in model (if implemented)
  */
  public synchronized void storeTableSelection()
  {
      //System.out.println("Store sel");
      if(!SwingUtilities.isEventDispatchThread())
      {
         new Throwable("Must be called from EDT !").printStackTrace();
      }

      if(tableReference==null) return;

      // store the selection (store indices of the basic model
      int[] sel = tableReference.getSelectedRows();
      basicTableModel.clearRowSelection();
      for(int i=0; i<sel.length; i++)
      {
         int indexThis = sel[i];
         int indexBase = getIndexInUnsortedFromTablePos(indexThis);
         basicTableModel.setRowSelection(indexBase, true);            
      }
  }

  public synchronized void restoreTableSelections()
  {     
     if(tableReference==null) return;
     if(this.getRowCount()==0) return;

     if(!SwingUtilities.isEventDispatchThread())
     {
       new Throwable("Must be called from EDT !").printStackTrace();
     }

     // restore selection  
     tableReference.getSelectionModel().clearSelection();
     int[] sel = basicTableModel.getSelectedRows();
     for(int i=0; i<sel.length; i++)
     {
        int indexBase = sel[i];
        int pos = getIndexInFoundFromBasicIndex(indexBase);

        if(pos>=0 && pos<tableReference.getRowCount())
        {
          if(tableReference.getSelectionModel().getSelectionMode()==ListSelectionModel.SINGLE_SELECTION)
          {
            tableReference.setRowSelectionInterval(pos, pos);
          }
          else
          {
            tableReference.addRowSelectionInterval(pos, pos);
          }
        }
     }

     // ### needed to display correctly !!!
     if(tableReference!=null) tableReference.revalidate();   // .repaint();
     if(tableRowHeadersReference!=null) tableRowHeadersReference.revalidate();
  }


  /** this just create a range 0.. size-1 used to sort
  */
  private synchronized void createRangeForSorting()
  {
     // nothing to do if the size is ok
     if(sortedRowIndices.size()==basicTableModel.getRowCount()) return;

     synchronized(this)
     {
       sortedRowIndices.removeAllElements();
       for(int i=0; i<basicTableModel.getRowCount(); i++)
       {
          sortedRowIndices.addElement(i);
       }
     }
  }

  
  /** @return true if the search is active.
  */
  public synchronized boolean isSearchActive()
  {
     if(search1.length()>0) return true;
     if(search2!=null) return true;
     return false;                  
  }

  String search1 = "";
  String search2 = null;
  boolean useRegEx = false;
  Pattern p1 = null;
  Pattern p2 = null;
  int searchColumn = -1;  // -1 => all
  boolean andSearch = true;

  public synchronized void search(String str1, String str2, boolean useRegEx)
  {
    if(!SwingUtilities.isEventDispatchThread())
    {
      new Throwable("Must be called from EDT !").printStackTrace();
    }

    search1 = str1;    
    search2 = (str2!=null && str2.equals("") ? null : str2);
    this.useRegEx = useRegEx;
    p1=null;
    p2=null;
    searchColumn = -1;
    andSearch = true;
    
    if(useRegEx)
    {
      try
      {
        p1 = Pattern.compile(str1);
      }
      catch(Exception e){}

      try
      {
        p2 = Pattern.compile(str1);
      }
      catch(Exception e){}     
    }

    storeTableSelection();

    internal_search();
    fireTableDataChanged();
    
    restoreTableSelections();
  }  
  
  public synchronized void advancedSearch(String str1, String str2, boolean andSearch, boolean useRegEx, int column)
  {             
    //System.out.println(""+column);
    search1 = str1;    
    search2 = (str2!=null && str2.equals("") ? null : str2);
  
    this.andSearch = andSearch;
    this.searchColumn = column;
    this.andSearch = andSearch;
    this.useRegEx = useRegEx;
    
    if(column==-1)        
    {        
      search(str1, str2, useRegEx);
      return;
    }

    p1=null;
    p2=null;
    
    if(useRegEx)
    {
      try
      {
        p1 = Pattern.compile(str1);
      }
      catch(Exception e){}

      try
      {
        p2 = Pattern.compile(str1);
      }
      catch(Exception e){}
    }
    
    storeTableSelection();

    internal_search();
    fireTableDataChanged();
    
    restoreTableSelections();    
     
  }    

  /** search must be called after sort
  // construct a list where the i-th element is the position in the
  // unsorted element to be showed in the found table at i-th position
  */
  private synchronized void internal_search()
  {
    synchronized(this)
    {
      foundBasicIndices.removeAllElements();
      for(int i=0; i<basicTableModel.getRowCount();i++)
      {                                         
        int basicIndex = getIndexInUnsortedModel(i);
        
        boolean hit = basicTableModel.hitForTextSearch(basicIndex, searchColumn, search1, p1);

        if(!hit && andSearch) continue;   // not found

        if(search2!=null && !search2.equals(""))
        {
           boolean hit2 = basicTableModel.hitForTextSearch(basicIndex, searchColumn, search2, p2);
           if(!hit2 && andSearch) continue;  // not found
           
           hit = hit || hit2;
        }

        if(hit)
        {
           foundBasicIndices.addElement(basicIndex);
        }
      }
    }
  }


  /** SPECIAL CASE: Table with row index.
      the two tables have the same selection model.
  */
  public void installGUI(JTable tHead, JTable table)
  {                                                          
    // synchronize the selections => simply use the same models !!
    tHead.setSelectionModel( table.getSelectionModel() );

    this.tableReference = table;
    this.tableRowHeadersReference = tHead;

    numberOfColumnAsRowHeaders = tHead.getColumnCount();

    // we just install header renderers
    setHeaders();  
    installHeaderClickListeners();

  }


  /** used to render headers...
  */
  public void installGUI(JTable _tableReference)
  { 
    this.tableReference = _tableReference;
    setHeaders(); // calls setHeadersForIndexTable()
    
    installHeaderClickListeners();
                              
    // this is the first sel, from model, when the three methods 
    // are implemented                          
    restoreTableSelections();
    
    int fontSize = UIManager.getFont("Label.font").getSize();
    for(int i=0; i<tableReference.getColumnCount(); i++)
    {
      int w = this.basicTableModel.getPreferredColumnWidth(i);
      if(w>0)
      {
        tableReference.getColumnModel().getColumn(i).setPreferredWidth(w*fontSize);
      }
    }    
  }


  public void setColumnVisibilityToggle(boolean enable)
  {
    columnVisibilitiesChangeEnable = enable;
  }     
  
  
  /** actually only for tables without header
    Must be caled after installGUI !
  */
  public void setPreferredColumnSizesFromModel()
  {
    if(tableReference==null) return;

    int fontSize = UIManager.getFont("Label.font").getSize();
    for(int i=0; i<tableReference.getColumnCount(); i++)
    {
      int pos = this.getColumnForViewIndex(i);
      int w = this.basicTableModel.getPreferredColumnWidth(pos);
      if(w>0)
      {
        tableReference.getColumnModel().getColumn(i).setPreferredWidth(w*fontSize);
      }
    }

  }  


  MouseAdapter tableRefClickMouseAdapter = null;
  MouseAdapter tableHeadClickMouseAdapter = null;


  /** listen to click on the table headers used to toggle sorting
  */
  private void installHeaderClickListeners()
  {
    if(tableRefClickMouseAdapter!=null)
    {                  
       tableReference.removeMouseListener(tableRefClickMouseAdapter);
    }

    // listen to click on the table headers used to toggle sorting
    tableReference.getTableHeader().addMouseListener(tableRefClickMouseAdapter = new MouseAdapter()
    {

      @Override public void mouseReleased(MouseEvent e)
      {
        if(e.isPopupTrigger() && columnVisibilitiesChangeEnable)
        {
          // on windows
          showColumnSelectionPopup(e);
          //e.consume();
        }
      }                           


      public void mousePressed(MouseEvent e)
      {
        if(e.isPopupTrigger() && columnVisibilitiesChangeEnable)
        {                          
          // on linux
          showColumnSelectionPopup(e);
          //e.consume();
        }
      }

      public void mouseClicked(MouseEvent e)
      {
        // [EDT]

        int columnView = tableReference.getColumnModel().getColumnIndexAtX(e.getX());
        int columnModel = tableReference.convertColumnIndexToModel(columnView);

        if (columnModel >= 0)
        {
           //TableColumn tc = tableReference.getColumnModel().getColumn(columnModel);
           
           // convert to model taking in account the columns that are not visible
           int columnIndexInModel = getModelIndexForClickedColumn(columnModel);

           // if this is the column already selected, invert the order
           if (sortedColumnInBasicModel == columnIndexInModel + numberOfColumnAsRowHeaders)
           {
             ascending = !ascending;
           }
           else
           {
             ascending = true;
           }
           sortedColumnInBasicModel = columnIndexInModel + numberOfColumnAsRowHeaders;
           //System.out.println("Sorted column in basic model = " + sortedColumnInBasicModel);

           storeTableSelection();

           internalSort();
           internal_search();

           fireTableDataChanged();

           restoreTableSelections();

           setHeaders(); // calls setHeadersForIndexTable()
           // strange... when not invoked, is sometimes not repainted
           if(tableReference!=null)
           {
              tableReference.getTableHeader().repaint(); // we're in the EDT... ok
           }
           if(tableRowHeadersReference!=null) 
           {
              tableRowHeadersReference.getTableHeader().repaint(); // we're in the EDT... ok
           }
           //tableHeader.invalidate();
        }
      }
    });


    // index table
    //
    if(tableRowHeadersReference==null) return;
    
    if(tableHeadClickMouseAdapter!=null)
    {
       tableRowHeadersReference.removeMouseListener(tableHeadClickMouseAdapter);
    }


    tableRowHeadersReference.getTableHeader().addMouseListener(tableHeadClickMouseAdapter = new MouseAdapter()
    {
      @Override public void mouseClicked(MouseEvent e)
      {
        //final int column = tableReference.columnAtPoint(new Point(e.getX(), e.getY()));
        int columnView = tableRowHeadersReference.getColumnModel().getColumnIndexAtX(e.getX());
        int columnModel = tableRowHeadersReference.convertColumnIndexToModel(columnView);

        //System.out.println("Click column "+columnModel);

        if (columnModel >= 0)
        {
           //TableColumn tc = tableRowHeadersReference.getColumnModel().getColumn(columnModel);
           if (sortedColumnInBasicModel==columnModel)
           {
             ascending = !ascending;
           }
           else
           {
             ascending = true;
           }
           sortedColumnInBasicModel = columnModel;
           //System.out.println("Sort column "+sortedColumn);

           //setHeadersForMainTable();
           //tableHeader.repaint();

           storeTableSelection();

           internalSort();
           internal_search();

           fireTableDataChanged();

           restoreTableSelections();

           setHeaders();
           // strange... when not invoked, is sometimes not repainted
           if(tableReference!=null) tableReference.getTableHeader().repaint(); // we're in the EDT... ok
           if(tableRowHeadersReference!=null) tableRowHeadersReference.getTableHeader().repaint(); // we're in the EDT... ok
           //tableHeader.invalidate();
        }
      }
    });
  }    
  /** @return {0,1,3} for example if column 2 is not visible
  */
  public int[] getVisibleColumnsIndex()
  {
    synchronized(this)
    {
      int[] rep = new int[selectedColumns.size()];
      Integer[] sc = (Integer[]) selectedColumns.toArray(new Integer[selectedColumns.size()]);
      for(int i=0; i<selectedColumns.size(); i++)
      {
         rep[i] = sc[i].intValue();
      }    
      return rep;
    }
  }

  private int getModelIndexForClickedColumn(int col)
  {
    int[] visibleIndex = getVisibleColumnsIndex();
    return getVisibleColumnsIndex()[col];
  }

  public void setVisibleColumns(int[] cols)
  {
    synchronized(this)
    {               
      selectedColumns.clear();
      for(int i=0; i<cols.length; i++)
      {
        if(cols[i]<this.basicTableModel.getColumnCount())
        {
          selectedColumns.add(cols[i]);
        }
      }
    }
    storeTableSelection();
    fireTableStructureChanged(); // structure has changed, give a TableModelEvent with ROW_HEADERS row as argument
    restoreTableSelections();
    setHeaders();
    
              
  }
  
  public boolean isColumnVisible(int column)
  {
     return selectedColumns.contains(column);
  }

  /** @param column in the base model
  */
  public void setColumnVisible(int column, boolean visible)
  {
     if(visible)
     {
       selectedColumns.add(column);
     }
     else
     {
       // avoid zero columns !!!
       if(selectedColumns.size()>1)
       {
         selectedColumns.remove(column);
       }
     }

     storeTableSelection();
     fireTableStructureChanged(); // structure has changed, give a TableModelEvent with ROW_HEADERS row as argument
     restoreTableSelections();
     setHeaders();
  }

  private void showColumnSelectionPopup(MouseEvent e)
  {
      JPopupMenu popup = new JPopupMenu("View Columns");
      popup.add(new JLabel("View"));
      popup.addSeparator();

      // numberOfColumnAsRowHeaders first col are always visible
      for(int i=numberOfColumnAsRowHeaders; i<this.basicTableModel.getColumnCount(); i++)
      {
         String name = basicTableModel.getColumnName(i);
         final Integer index = new Integer(i);
         final JCheckBoxMenuItem cb = new JCheckBoxMenuItem(name, selectedColumns.contains(index));
         popup.add(cb);
         cb.addActionListener(new ActionListener()
         {
           public void actionPerformed(ActionEvent ae)
           {
              setColumnVisible(index.intValue(), cb.isSelected());
           }
         });
      }


      popup.show(tableReference.getTableHeader(), e.getX(), e.getY());
  }


  /** set the headers with sort icons.
    [Called from EDT]
  */                                                                                            
  protected void setHeaders()                                                                   
  {
    if(tableReference == null) return;

    setHeadersForIndexTable();

    //System.out.println("SC="+sortedColumn);

    // for the index table
    if (tableRowHeadersReference!=null)
    {
      for (int i=0; i<numberOfColumnAsRowHeaders; i++)
      {
        int indexModel = i;
        int indexView = tableRowHeadersReference.convertColumnIndexToView(i);
        TableColumn column = tableRowHeadersReference.getColumnModel().getColumn(indexView);
        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setBackground(UIManager.getColor("TableHeader.background"));
        if(indexModel==sortedColumnInBasicModel)
        {
          if (ascending) headerRenderer.setIcon(getAscIcon(indexModel));
          else           headerRenderer.setIcon(getDescIcon(indexModel));
        }
        else
        {
          headerRenderer.setIcon(getNoSortIcon(indexModel));
        }

        tableRowHeadersReference.getColumnModel().getColumn(indexView).setHeaderRenderer(headerRenderer);

        // ??? needed, otherwise, does not correctly display.
        tableRowHeadersReference.getTableHeader().repaint();
      }
    }

    // table

    for (int i=0; i<tableReference.getColumnCount(); i++)
    {
      int indexModel = i;
      int indexView  = tableReference.convertColumnIndexToView(i);
      TableColumn column = tableReference.getColumnModel().getColumn(indexView);

      DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
      headerRenderer.setBackground(UIManager.getColor("TableHeader.background"));

      int sortedColViewIndex = getColumnForViewIndex(i);

/*      System.out.println( "" + indexView + ",name= " + column.getIdentifier()
                             + ", "+sortedColViewIndex+", sc="+ sortedColumnInBasicModel
                             +"    "+numberOfColumnAsRowHeaders);

  */
      if(sortedColViewIndex+numberOfColumnAsRowHeaders == sortedColumnInBasicModel)
      {
/*         System.out.println("sortedColumnInBasicModel = "
            +sortedColumnInBasicModel+", view= "+sortedColViewIndex);
*/
         if (ascending)                                                          
         {
            headerRenderer.setIcon(getAscIcon(sortedColViewIndex));
         }
         else
         {
            headerRenderer.setIcon(getDescIcon(sortedColViewIndex));
         }
      }
      else
      {                                                                    
         headerRenderer.setIcon(getNoSortIcon(sortedColViewIndex));
      }

      tableReference.getColumnModel().getColumn(indexView).setHeaderRenderer(headerRenderer);
      // ??? needed, otherwise, does not correctly display.
      tableReference.getTableHeader().repaint();
    }
  }


  private void setHeadersForIndexTable()
  {
    if(tableRowHeadersReference == null) return;

    JTableHeader tableHeader = tableRowHeadersReference.getTableHeader();
    for (int i=0; i<tableRowHeadersReference.getColumnCount(); i++)
    {
      int indexModel = i;
      int indexView = tableRowHeadersReference.convertColumnIndexToView(i);

      TableColumn column = tableRowHeadersReference.getColumnModel().getColumn(indexView);
      DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
      headerRenderer.setBackground(UIManager.getColor("TableHeader.background"));

      if(indexModel==sortedColumnInBasicModel)
      {
        if (ascending)
        {
            headerRenderer.setIcon(getAscIcon(indexModel));
        }
        else                       
        {
            headerRenderer.setIcon(getDescIcon(indexModel));
        }
      }
      else                                                               
      {
        headerRenderer.setIcon(getNoSortIcon(indexModel));
      }

      tableRowHeadersReference.getColumnModel().getColumn(indexView).setHeaderRenderer(headerRenderer);
      //tableReference.repaint();
    }
  }

  // keep in mind what sorting is wanted, because each update must re-sort
  int sortedColumnInBasicModel  = 0;
  boolean ascending = true;
                    
  public void sort(int column, boolean ascending)
  {
    synchronized(this)
    {
      this.sortedColumnInBasicModel = column;
      this.ascending = ascending;
      internalSort();          
                         
      // pass the event in same EDT for this listener
      fireTableDataChanged();
    }               
  }

  /** return true if the actual sorting order is ascending (default).
  */
  public boolean getSortOrderIsAscending() { return ascending;}

  /** index in the basic tabel model
  */
  public int getSortedColumn()  { return sortedColumnInBasicModel; }

  public void setSortedColumnAndOrder(int col, boolean ascending)
  {
    this.sortedColumnInBasicModel = col;
    this.ascending = ascending;
  }

  private void internalSort()
  {
    Comparator<Integer> comp = new Comparator<Integer>()
    {
      public int compare(Integer ind1, Integer ind2)
      {
        if(ascending)
        {
          return basicTableModel.compareForColumnSort(ind1, ind2, sortedColumnInBasicModel);
        }                  
        else               
        {
          return basicTableModel.compareForColumnSort(ind2, ind1, sortedColumnInBasicModel);
        }
      }
    };
    //System.out.println("Sort start");
    Collections.sort(sortedRowIndices, comp);
    //System.out.println("Sort end");
  }

  //
  // TableModel
  //


  /** @param pos id the index in this table,
      @return the position of the element in the unsorted model
  */
  private int getIndexInUnsortedModel(int pos)
  {
     if(pos==-1) return -1;
     if(pos>=sortedRowIndices.size()) return -1;

     return ((Integer) sortedRowIndices.elementAt(pos)).intValue();
  }

  /** positions in unsorted
  */
  public int getIndexInUnsortedFromTablePos(int tablePos)
  {
     if(tablePos==-1) return -1;
     if(tablePos>=foundBasicIndices.size())
     {
//       System.out.println("tp="+tablePos+", fi="+foundBasicIndices.size());
       return -1;
     }

     return foundBasicIndices.elementAt(tablePos);
  }


  /** get the view index corresponding to the one in the basicIndex
  */
  public int getIndexInFoundFromBasicIndex(int basicIndex)
  {
    if(basicIndex==-1) return -1;
    if(basicIndex>=0 && basicIndex<basicTableModel.getRowCount())
    {
      int pos = foundBasicIndices.indexOf(basicIndex);
      return pos;
    }
    else
    {
      return -1;
    }
  }

   public Object getValueAt(int row, int col)
   {
       int pos = getIndexInUnsortedFromTablePos(row);
       return basicTableModel.getValueAt(pos, getColumnForViewIndex(col));
   }

   public int getRowCount()
   {
      //System.out.println("grc="+foundBasicIndices.size());
      return foundBasicIndices.size();
      //#  return unsortedTableModel.getRowCount();
   }  
                           

   public int getColumnCount()
   {
      return selectedColumns.size();
      //[Old] return basicTableModel.getColumnCount();
   }

   /** if visible columns are {0,1,3}, view=2, return 3
       BE CAREFUL: used in getColumName and getColumnClass !
   */
   public int getColumnForViewIndex(int viewCol)
   {
         synchronized(this)
         {
            int pos = -1;
            // iterate over all visible columns
            Iterator it = selectedColumns.iterator();
            while(it.hasNext())
            {
               Integer ind = (Integer) it.next();
               pos++;
               if(pos==viewCol)
               {
                  return ind.intValue();
               }
            }
            return -1;
         }

      /**
       new code [Feb2004]
       *

      String colName = this.tableReference.getColumnName(viewCol);
      for(int i=0; i<this.basicTableModel.getColumnCount(); i++)
      {
         if(basicTableModel.getColumnName(i).equals(colName)) return i;
      }
      return -1;
        */  
   } 
   
   


                                
   public boolean isCellEditable(int row, int col)         
   {
       int pos = getIndexInUnsortedFromTablePos(row);
       return basicTableModel.isCellEditable(pos, getColumnForViewIndex(col));
   }

   public void setValueAt(Object val, int row, int col)
   {
       int pos = getIndexInUnsortedFromTablePos(row);
       basicTableModel.setValueAt(val, pos, getColumnForViewIndex(col));
   }

   public Class getColumnClass ( int column )
   {
      return basicTableModel.getColumnClass(getColumnForViewIndex(column));
   }

   public String getColumnName(int column)
   {
      return basicTableModel.getColumnName(getColumnForViewIndex(column));
   }               

                               
   
  /**
   * returns the ascending/descending sort icons.
   * this method may be overwritten by subclasses
   * in order to provide their own icons
   */
  protected Icon getAscIcon(    final int column )  { return(SORT_ASC);  }
  protected Icon getDescIcon(   final int column )  { return(SORT_DESC); }
  protected Icon getNoSortIcon( final int column )  { return(null);      }
                 

                                                                        
} // SortableAbstractTableModel
