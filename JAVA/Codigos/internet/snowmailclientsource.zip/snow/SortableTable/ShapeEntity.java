package snow.SortableTable;

  /**
   *  Helper class for painting shapes with associated
   *  shape and inner colors or gradients.
   *  Abstract basis class.
   */

import java.awt.Graphics2D;

                     
public abstract class ShapeEntity
{         
             /*
   public abstract void paint( Graphics2D graphics2D);

   public abstract void moveTo( int x, int y );
   public abstract void lineTo( double x, double y );
   public abstract void closePath();
               */

} // ShapeEntity


