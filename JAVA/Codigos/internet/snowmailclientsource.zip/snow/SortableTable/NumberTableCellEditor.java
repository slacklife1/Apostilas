package snow.SortableTable;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.*;
import java.util.*;


/** our own table cell editor (based on DefaultCellEditor) using a textfield
    keeping the types passed (Integer, Float, Double)
    selet all when focused, nicer behaviour.
*/
public final class NumberTableCellEditor extends JTextField implements TableCellEditor, ActionListener
{       

  protected final Vector<CellEditorListener> listeners = new Vector<CellEditorListener>();

  // when a number is entered in a focused cell, it will be overwritten if true!
  boolean selectAllWhenFocused = true;
  
  // kept to test for class
  protected Object oldValue = null;
                  
  public NumberTableCellEditor()   
  {                  
     super();
     //this.setInputVerifier(InputVerifier
     
     // To stop cell editing
     this.addActionListener(this);
               
     if(selectAllWhenFocused)
     {
        this.addFocusListener(new FocusAdapter()
        {  
           @Override public void focusGained(FocusEvent e)
           {
              selectAll();
           }
        });
     }
  } // Constructor



  public Component getTableCellEditorComponent(JTable table,
                                      Object value,
                                      boolean isSelected,
                                      int row,       
                                      int column)
  {
     // terminate editing
     this.stopCellEditing();

     oldValue = value;        
     setText(value.toString());
     
     if(selectAllWhenFocused) this.selectAll();

     return this;          
  }

  /** called when enter is pressed
  */
  public void actionPerformed(ActionEvent e)
  {
     stopCellEditing();
  }                 



  //
  // Celleditor interface impl
  //

 /** Adds a listener to the list that's notified when the editor stops, or cancels editing.
 */
 public void addCellEditorListener(CellEditorListener l)
 {                                       
   listeners.addElement(l);
 }    

 /** Removes a listener from the list that's notified
 */
 public void removeCellEditorListener(CellEditorListener l)
 {
   listeners.removeElement(l);
 }    

 /** Tells the editor to cancel editing and not accept any partially edited value.
 */
 public void cancelCellEditing()
 {
    final ChangeEvent ce = new ChangeEvent(this);
    for(int i=0; i<listeners.size(); i++)
    {
      CellEditorListener listener = listeners.elementAt(i);
      listener.editingCanceled(ce);
    }  
 }

 /** Returns the value contained in the editor.
 */
 public Object getCellEditorValue()
 {
   if(oldValue==null)
   {
     return this.getText();
   }

   if(oldValue instanceof Integer)       
   {
     try
     {
        return  Integer.parseInt( this.getText() );
     }
     catch(Exception e)
     {

     }
   }
   if(oldValue instanceof Float)
   {
     try
     {
        return Float.parseFloat( this.getText() );
     }
     catch(Exception e)
     {

     }
   }
   if(oldValue instanceof Double)
   {
     try
     {              
        return Double.parseDouble( this.getText() );
     }
     catch(Exception e)   
     {
        System.out.println("NumberTableCellEditor.getCellEditorValue(): Bad double format: "+e.getMessage());
     }   
   }
   
   // IMPORTANT FOR ASE:                     
   return this.getText();
 }

 /** Asks the editor if it can start editing using anEvent.
     anEvent is in the invoking component coordinate system.
     The editor can not assume the Component returned by getCellEditorComponent
     is installed. This method is intended for the use of client to avoid
     the cost of setting up and installing the editor component if editing
     is not possible. If editing can be started this method returns true.
 */
 public boolean isCellEditable(EventObject anEvent)
 {
   return true;
 }




 /** Returns true if the editing cell should be selected, false otherwise.
    Typically, the return value is true, because is most cases the editing cell
    should be selected. However, it is useful to return false to keep the
    selection from changing for some types of edits. eg.
    A table that contains a column of check boxes, the user might want to
    be able to change those checkboxes without altering the selection.
    (See Netscape Communicator for just such an example) Of course, it is
    up to the client of the editor to use the return value, but it
    doesn't need to if it doesn't want to.
 */
 public boolean shouldSelectCell(EventObject anEvent)
 {
   return true;                                                                                                                   
 }

 /** Tells the editor to stop editing and accept any partially edited
     value as the value of the editor.
    @return true if editing was stopped; false otherwise
 */
 public boolean stopCellEditing()
 {
    final ChangeEvent ce = new ChangeEvent(this);
    for(int i=0; i<listeners.size(); i++)
    {
      CellEditorListener listener = (CellEditorListener) listeners.elementAt(i);
      listener.editingStopped(ce);
    }
    
    // ok, we always accept.. ###
    return true;
 }





} // NumberTableCellEditor
