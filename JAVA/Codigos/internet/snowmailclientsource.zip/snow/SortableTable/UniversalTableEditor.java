package snow.SortableTable;

import snow.utils.gui.FontSelector;

import javax.swing.table.*;
import javax.swing.*;        
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.text.*;
import javax.swing.text.*;
import java.awt.font.*;
import java.awt.event.*;      
import java.awt.geom.*;
import java.nio.*;
import java.nio.charset.*;
import java.text.*;
import java.util.*;                                                                                               


public final class UniversalTableEditor extends AbstractCellEditor implements TableCellEditor
{
  protected final ColorCellEditor   colorCellEditor           = new ColorCellEditor();
  protected final DefaultCellEditor textFieldDefaultCellEditor= new DefaultCellEditor(new JTextField());
  protected final DefaultCellEditor comboBoxDefaultCellEditor = new DefaultCellEditor(new JComboBox());
  protected final DefaultCellEditor checkBoxDefaultCellEditor = new DefaultCellEditor(new JCheckBox());
  protected final FontCellEditor    fontCellEditor            = new FontCellEditor();
  protected final NumberTableCellEditor numberTableCellEditor = new NumberTableCellEditor();
                                                                                                                                    
  private CellEditor selectedEditor = null;

  public UniversalTableEditor()
  {

  } // Constructor
  
  
  // CELL EDITOR INTERFACE
  //

  public void addCellEditorListener(CellEditorListener l)
  {    /*
    colorCellEditor.addCellEditorListener(l);
    textFieldDefaultCellEditor.addCellEditorListener(l);
    comboBoxDefaultCellEditor.addCellEditorListener(l);
    checkBoxDefaultCellEditor.addCellEditorListener(l);
    fontCellEditor.addCellEditorListener(l);
    numberTableCellEditor.addCellEditorListener(l);*/

    if(selectedEditor!=null)
    {
      selectedEditor.addCellEditorListener(l);
    }

  }

  public void removeCellEditorListener(CellEditorListener l)
  {   /*
    colorCellEditor.removeCellEditorListener(l);
    textFieldDefaultCellEditor.removeCellEditorListener(l);
    comboBoxDefaultCellEditor.removeCellEditorListener(l);
    checkBoxDefaultCellEditor.removeCellEditorListener(l);
    fontCellEditor.removeCellEditorListener(l);
    numberTableCellEditor.removeCellEditorListener(l);  */
    if(selectedEditor!=null)                   
    {
      selectedEditor.removeCellEditorListener(l);
    }

  }

  public void cancelCellEditing()     
  {    /*
    colorCellEditor.cancelCellEditing();
    textFieldDefaultCellEditor.cancelCellEditing();
    comboBoxDefaultCellEditor.cancelCellEditing();
    checkBoxDefaultCellEditor.cancelCellEditing();
    fontCellEditor.cancelCellEditing();
    numberTableCellEditor.cancelCellEditing();  */
    if(selectedEditor!=null)
    {
      selectedEditor.cancelCellEditing();
    }

  }

  public boolean stopCellEditing()
  {    
  /*
    colorCellEditor.stopCellEditing();
    textFieldDefaultCellEditor.stopCellEditing();
    comboBoxDefaultCellEditor.stopCellEditing();
    checkBoxDefaultCellEditor.stopCellEditing();
    fontCellEditor.stopCellEditing();
    numberTableCellEditor.stopCellEditing();
    return true;
    */
    if(selectedEditor!=null)
    {
      return selectedEditor.stopCellEditing();
    }
    return true;
  }


  public Object getCellEditorValue()
  { 
    if(selectedEditor!=null)
    {
      return selectedEditor.getCellEditorValue();
    }
    return null;
    //textFieldDefaultCellEditor.getCellEditorValue();
  }

  public boolean isCellEditable(EventObject anEvent)
  {
    //System.out.println(""+anEvent);
    if(selectedEditor!=null)
    {
      return selectedEditor.isCellEditable(anEvent);
    }
    // if false, nothing will be editable !!
    return true;
  }

  public boolean shouldSelectCell(EventObject anEvent)
  {
    if(selectedEditor!=null)
    {
      return selectedEditor.shouldSelectCell(anEvent);
    }
    return true;  // normally true, maybe no for checkboxes...
  }
  
  

                                                                                                                                              

  /** TableCellEditor interface impl
  */                                                                                                                          
  public Component getTableCellEditorComponent(JTable table,
                                               Object value,
                                               boolean isSelected,
                                               int row,
                                               int column)
  {  
     // is null allowed ?? yes, may be casted for example to color 
     // if(value==null) return new JLabel("No editor for null value");

     if(value instanceof Color)
     {                                      
       selectedEditor =  colorCellEditor;
       return colorCellEditor.getTableCellEditorComponent(table, (Color) value, isSelected, row, column);
     }
     else if(value instanceof Boolean)
     {
       selectedEditor = checkBoxDefaultCellEditor;
       return checkBoxDefaultCellEditor.getTableCellEditorComponent(table, value, isSelected, row, column);
     }
     else if(value instanceof Font)
     {
       selectedEditor = fontCellEditor;
       return fontCellEditor.getTableCellEditorComponent(table, value, isSelected, row, column);
     }
     else if(value instanceof Double
           ||value instanceof Float
           ||value instanceof Integer)
     {
       selectedEditor = numberTableCellEditor;
       return numberTableCellEditor.getTableCellEditorComponent(table, value, isSelected, row, column);
     }
     else
     {
       // default
       selectedEditor = textFieldDefaultCellEditor;
       return textFieldDefaultCellEditor.getTableCellEditorComponent(table, value, isSelected, row, column);
     }


    // return new JLabel("NO EDITOR FOR "+value.getClass().getName());
  }  
  
  
 class FontCellEditor extends AbstractCellEditor
                         implements TableCellEditor,
                                    ActionListener {
    Font currentFont;
    JButton button;                
    //FontSelector fontChooser;
    JDialog dialog;
    protected static final String EDIT = "edit";

    public FontCellEditor() {
        button = new JButton();
        button.setActionCommand(EDIT);
        button.addActionListener(this);
        button.setBorderPainted(false);

        //Set up the dialog that the button brings up.
        //fontChooser = new FontSelector.();
    }

    public void actionPerformed(ActionEvent e) {
        if (EDIT.equals(e.getActionCommand())) 
        {
            //The user has clicked the cell, so
            //bring up the dialog.
            //button.setBackground(currentColor);
            //colorChooser.setColor(currentColor);       
            //dialog.setVisible(true);

            //fontChooser.setFont(currentFont);
            currentFont = FontSelector.ChooseFont(button, currentFont);

            fireEditingStopped(); //Make the renderer reappear.

        } 
        else 
        { //User pressed dialog's "OK" button.
            //currentFont = fontChooser.getFont();
        }
    }

    //Implement the one CellEditor method that AbstractCellEditor doesn't.
    public Object getCellEditorValue() {
        return currentFont;
    }

    //Implement the one method defined by TableCellEditor.
    public Component getTableCellEditorComponent(JTable table,
                                                 Object value,
                                                 boolean isSelected,
                                                 int row,
                                                 int column)
    {
        if(value instanceof Font)
        {       
          currentFont = (Font) value;
        }         
        return button;
    }
}
  


} // UniversalTableEditor
 
