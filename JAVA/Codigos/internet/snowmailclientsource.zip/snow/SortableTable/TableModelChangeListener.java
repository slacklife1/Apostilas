package snow.SortableTable;

import javax.swing.event.*;
     
/**
 */
public interface TableModelChangeListener
{
    /** called before the change
    */
    public void tableModelWillChange(ChangeEvent e);

    /** called after the change
    */
    public void tableModelHasChanged(ChangeEvent e);
}
