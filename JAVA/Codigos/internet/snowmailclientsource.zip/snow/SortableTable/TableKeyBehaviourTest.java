package snow.SortableTable;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.*;
import java.util.*;
     

public class TableKeyBehaviourTest extends JFrame
{ 
  TestModel testModel = new TestModel();
  JTable table = new JTable();


  public TableKeyBehaviourTest()
  {
    super("Test");
    super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    getContentPane().setLayout(new BorderLayout());

    getContentPane().add(new JScrollPane(table), BorderLayout.CENTER);
    
    // not sortable
    //table.setModel(testModel);

    // sortable                                                                                                                                     
    SortableTableModel stm = new SortableTableModel(testModel,0,true);
    table.setModel(stm);
    stm.installGUI(table);
    
    //final JTextField textEditor = new JTextField();
    //table.setDefaultEditor(String.class, new CellEditor(textEditor));
    //table.setDefaultEditor(Double.class, new CellEditor(textEditor));
    //table.setCellEditor(new CellEditor());

    table.setDefaultEditor(Double.class, new NumberTableCellEditor());
    //table.setCellEditor(new NumberTableCellEditor());
    table.setDefaultRenderer(Object.class, new CellRenderer());

    table.setColumnSelectionAllowed(false);
    table.setRowSelectionAllowed(false);

    setSize(800,800);
    setVisible(true);
  } // Constructor
                                                                                                                                            
  public static void main(String[] ignored)
  {                 
    new TableKeyBehaviourTest();
  }
                                  
  class CellRenderer extends DefaultTableCellRenderer


  {
     //JTextField textField = new JTextField();
     public CellRenderer()
     {                          
     }

     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
     {
       Component sup = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
       //textField.setText(""+value);
                  
	if (hasFocus) {  
	   sup.setForeground(table.getSelectionForeground());
	   sup.setBackground(table.getSelectionBackground());
	}                      
	else {
	    sup.setForeground(table.getForeground());
	    sup.setBackground(table.getBackground());
	}  

       return sup;
     }                   

  }

} // TableKeyBehaviourTest
