package snow.SortableTable;

import snow.utils.gui.*;
import SnowMailClient.Language.Language;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.util.*;

/** a small utility to add a search panel to a sortable table viewer
*/
public final class AdvancedSearchPanel extends AnimatedColorPanel
{
  final protected JTextField searchFT = new JTextField(5);
  final protected JTextField searchFT2 = new JTextField(5);

  final protected JSenseButton activateAdvancedButton = new JSenseButton(new SortDirectionSelfDrawingIcon(SortDirectionSelfDrawingIcon.Right));
  final protected JSenseButton deactivateAdvancedButton = new JSenseButton(new SortDirectionSelfDrawingIcon(SortDirectionSelfDrawingIcon.Left));

  final protected JComboBox searchOperationCB = new JComboBox(new String[]{ "&", "||"});
  final protected JComboBox searchColumnCB = new JComboBox();
  final protected JCheckBox regExSearchCB = new JCheckBox(Language.translate("RegEx"), false);


                           
  protected SortableTableModel stm;
  
  boolean advancedMode = false;
  boolean allowRegEx = false;

  private Vector<ChangeListener> searchChangeListeners = new Vector<ChangeListener>();

  /** @param secondSearch if true, two fields are shown, alowing an AND search
      @param searchLabelText is normally "Search: "
  */
  public AdvancedSearchPanel(final String searchLabelText, final Icon searchIcon,
                     final SortableTableModel stm, boolean allowRegEx)
  {
    super(new FlowLayout(FlowLayout.LEFT), 100);
    this.setOpaque(false);
    this.stm = stm; 
    this.allowRegEx = allowRegEx;

    Vector<String> colNames = new Vector<String>();
    colNames.addElement(Language.translate("All Columns"));
    if(stm!=null)
    {
      for(int i=0; i<stm.getBasicTableModel().getColumnCount(); i++)
      {
        colNames.add( stm.getBasicTableModel().getColumnName(i));
      }
      searchColumnCB.setModel(new DefaultComboBoxModel(colNames));
    }

    // Components
    //
    add(new JLabel(searchLabelText, searchIcon, JLabel.LEFT));
    add(searchFT);

    add(activateAdvancedButton);
    activateAdvancedButton.setToolTipText(Language.translate("Advanced Search"));
    activateAdvancedButton.setFocusPainted(false);
    activateAdvancedButton.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          setAdvancedMode(true);
        }
      });

    add(searchOperationCB);
    add(searchFT2);

    add(searchColumnCB);
    searchColumnCB.setMaximumRowCount(35);  // see all, without scroll

    add(deactivateAdvancedButton);
    deactivateAdvancedButton.setToolTipText(Language.translate("Return to Simple Search"));
    deactivateAdvancedButton.setFocusPainted(false);
    deactivateAdvancedButton.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          setAdvancedMode(false);
        }
      });

    if(allowRegEx)
    {
      add(regExSearchCB);
      regExSearchCB.setOpaque(false);
    }
                
    // key listener
    //
    KeyAdapter kad = new KeyAdapter()
    {                      
      @Override public void keyReleased(KeyEvent ee)
      {
        doSearch();
      }
    };

    searchOperationCB.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          doSearch();
        }
      });   
      
    searchColumnCB.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          doSearch();               
        }
      });      

    searchFT.addKeyListener(kad);
    searchFT2.addKeyListener(kad);
    
    // focus behaviour
    //

    searchFT.addFocusListener(new FocusAdapter()
    {
       @Override public void focusGained(FocusEvent e)
       {
          searchFT.selectAll();
       }
    });
    searchFT2.addFocusListener(new FocusAdapter()
    {
       public void focusGained(FocusEvent e)
       {
          searchFT2.selectAll();
       }
    });  
    
    // CTRL+F mapping
    //
          
    this.registerKeyboardAction(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          searchFT.requestFocus();
        }
      },
      KeyStroke.getKeyStroke(KeyEvent.VK_F, KeyEvent.CTRL_DOWN_MASK),
      JComponent.WHEN_IN_FOCUSED_WINDOW
    );  // ### Maybe pass the parent as argument reference and register actions on it.
        // It makes sense if several internal frames have searches...


    // UI

    activateAdvancedButton.setPreferredSize(new Dimension(
         (int)searchFT2.getPreferredSize().getHeight()+0,
         (int)searchFT2.getPreferredSize().getHeight()+0));

    deactivateAdvancedButton.setPreferredSize(new Dimension(
         (int)searchFT2.getPreferredSize().getHeight()+0,
         (int)searchFT2.getPreferredSize().getHeight()+0));

    this.searchOperationCB.setPreferredSize(new Dimension(
         (int) searchOperationCB.getPreferredSize().getWidth()+0,
         (int)searchFT2.getPreferredSize().getHeight()+0));

    this.searchColumnCB.setPreferredSize(new Dimension(
         (int) searchColumnCB.getPreferredSize().getWidth()+0,
         (int)searchFT2.getPreferredSize().getHeight()+0));

    // initial state
    EventQueue.invokeLater(new Runnable(){public void run()
    {
      setAdvancedMode(advancedMode);
    }});


    //this.setBorder(new LineBorder(Color.red,1));
  }
     
  public void setSortableTableModel(SortableTableModel stm)
  {  
    int fontSize = searchColumnCB.getFont().getSize();
    int maxWidth = 0;

    this.stm = stm;
    if(stm!=null)
    {                             
      Vector<String> colNames = new Vector<String>();
      colNames.addElement(Language.translate("All Columns"));
      for(int i=0; i<stm.getBasicTableModel().getColumnCount(); i++)
      {
        String name = stm.getBasicTableModel().getColumnName(i);
        colNames.add( name );
        
        if(name.length()>maxWidth) maxWidth = name.length();
      }          
      searchColumnCB.setModel(new DefaultComboBoxModel(colNames));
    }
    else
    {
      searchColumnCB.setModel(new DefaultComboBoxModel(new Vector<String>()));
    }
    Dimension dim = new Dimension(fontSize*maxWidth, (int) searchColumnCB.getPreferredSize().getHeight());
    searchColumnCB.setSize(dim);
    searchColumnCB.setPreferredSize(dim);
    
    doSearch();
  }

  
  /** must be called in the EDT !
  */
  public void setAdvancedMode(boolean active)
  {
      advancedMode = active;
      searchFT2.setVisible(active);
      deactivateAdvancedButton.setVisible(active);
      searchOperationCB.setVisible(active);
      searchColumnCB.setVisible(active);
      
      this.regExSearchCB.setVisible( allowRegEx && active );

      activateAdvancedButton.setVisible(!active);

      doSearch();
  }


  /** Must be called in the EDT !
      All the searches are done from here. This also notify the listeners
  */
  public void doSearch()
  { 
    if(!SwingUtilities.isEventDispatchThread())
    {          
       new Throwable("Should be called from EDT !").printStackTrace();
    }


    if(searchFT.getText().length()>0 || (this.advancedMode && searchFT2.getText().length()>0) )
    { 
      this.activateAnimation(true);
      this.setOpaque(true);       
    }
    else
    {
      this.activateAnimation(false);
      this.setOpaque(false);
    }

    if(advancedMode)
    {
      boolean andSearch = searchOperationCB.getSelectedIndex()==0;
      int col = searchColumnCB.getSelectedIndex()-1;  // -1 => all
      if(stm!=null)     
      {
        stm.advancedSearch(searchFT.getText(), searchFT2.getText(), andSearch, regExSearchCB.isSelected(), col);
      }
    }
    else
    {
      // the second field is invisible => don't use it
      if(stm!=null)
      {
        stm.search(searchFT.getText(), "", regExSearchCB.isSelected());
      }
    } 
    
    notifySearchChanged();
  }

  public boolean hasSearchText() { return searchFT.getText().length()>0 || searchFT2.getText().length()>0; }


  /** must be called in the EDT !
  */
  public void setSearchText(String t1, String t2)
  {
     searchFT.setText(t1);
     searchFT2.setText(t2);
     // do the search
     doSearch();
  }
  
  //
  // Listeners
  //          
  
  public void addSearchChangeListener(ChangeListener cl )
  {
    searchChangeListeners.addElement(cl);
  }
  
  private void notifySearchChanged()
  {
    for(ChangeListener cl : searchChangeListeners)
    {
      cl.stateChanged(new ChangeEvent(this));
    }
  }

}  // AdvancedSearchPanel

