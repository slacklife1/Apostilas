package snow.SortableTable;

import javax.swing.table.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.text.*;
import javax.swing.text.*;
import java.awt.font.*;
import java.awt.geom.*;
import java.nio.*;
import java.nio.charset.*;
import java.text.*;
import java.util.*;

/** alternative to DefaultTableCellRenderer
*/
public final class UniversalTableCellRenderer implements TableCellRenderer                                                                 
{
  protected final DoubleRenderer doubleRenderer = new DoubleRenderer();
  protected final StringRenderer stringRenderer = new StringRenderer();
  protected final ColorRenderer colorRenderer = new ColorRenderer();
  protected final BooleanRenderer booleanRenderer = new BooleanRenderer();
                                                             
  protected Border noFocusBorder = new EmptyBorder(1, 1, 1, 1);

  protected final SortableTableModel sortableTableModel;


  int fontSize = 10;
  
  public UniversalTableCellRenderer()
  {  
     this.sortableTableModel = null;
  }               
  
  /** @param sortableTableModel is used to set column alignments (left, right)
  */
  public UniversalTableCellRenderer(SortableTableModel sortableTableModel)
  {
     setupUI();
     this.sortableTableModel = sortableTableModel;
  } // Constructor

  /** must be called after each L&F changes
  */
  private void setupUI()
  {
     fontSize = UIManager.getFont("Table.font").getSize();
     noFocusBorder = new EmptyBorder(fontSize/4, fontSize/4, fontSize/4, fontSize/4);
              
     doubleRenderer.setupUI();
     stringRenderer.setupUI();
  }  
  

  public Component getTableCellRendererComponent(JTable table, Object value,
     boolean isSelected, boolean hasFocus, int row, int column)
  {                            
    BasicRenderer comp = getRendererFor(value, column);
                                             

    if(value instanceof Font)
    {
       Font font = (Font) value;
       comp.setValue("Font "+font.getFontName()+", size="+font.getSize());
       comp.setFont(font);  
    }
    else
    {
       comp.setFont(table.getFont());
       //comp.setFont(UIManager.getFont("Table.font"));
       comp.setValue(value);
    }

    if(value instanceof Color)
    {
    }
    else
    {
      if (isSelected)
      {                                
         //comp.setForeground(table.getSelectionForeground());
         //comp.setBackground(table.getSelectionBackground());
         comp.setForeground(UIManager.getColor("Table.selectionForeground"));
         comp.setBackground(UIManager.getColor("Table.selectionBackground"));                                                                    
      }
      else
      {
         //comp.setForeground(table.getForeground());
         //comp.setBackground(table.getBackground());
         comp.setForeground(UIManager.getColor("Table.foreground"));
         comp.setBackground(UIManager.getColor("Table.background"));
      }
    }

    return (Component) comp;
  }


  private BasicRenderer getRendererFor(Object value, int viewColumn)
  {
    if(value==null) return doubleRenderer;
    if(value instanceof Double)
    {
      return doubleRenderer;
    }
    else if(value instanceof Color)
    {
      return this.colorRenderer;
    }
    else if(value instanceof Boolean)
    {
      return this.booleanRenderer;
    }
    else // String & defaults
    {
      if(sortableTableModel!=null)
      {
        int col = sortableTableModel.getColumnForViewIndex(viewColumn);
        stringRenderer.setHorizontalAlignment(sortableTableModel.getBasicTableModel().getColumnAlignment(col));
      }
      return stringRenderer;
    }
  }
  
  
  //
  // Renderers
  //

  interface BasicRenderer
  {
     public void setValue(Object value);
     public void setFont(Font f);
     public void setForeground(Color c);
     public void setBackground(Color c);
  }   
                       

  class DoubleRenderer extends JComponent implements BasicRenderer
  {
    String value = "";
    DecimalFormat format = new DecimalFormat("#.###");
    int posPoint = 80;
    AffineTransform identityTransform = new AffineTransform();
    FontRenderContext fontRenderContext = new FontRenderContext(identityTransform, false, false);
    int posX = 0;

    public DoubleRenderer()
    {
    }
        
    public void setupUI()
    {
      setBorder(noFocusBorder);
      setOpaque(true); 
    }

    public void paintComponent(Graphics g)
    {              
       // fill background and set foreground color.                                                                          
       Graphics2D g2 = (Graphics2D) g;
       g.setColor(this.getBackground());
       g2.fill(g.getClipBounds());
       g.setColor(this.getForeground());
                 

       int fs = g.getFont().getSize();
       int posY = (int) (this.getSize().getHeight()/2 + fs/2);

       //fontRenderContext
       //SwingUtilities.

       g.drawString(value, posX, posY);
    }

    public void setValue(Object o)
    {
       value = format.format((Double) o);

       int pos = value.indexOf(".");
       if(pos<0) pos = value.length();
       String beforePoint = value.substring(0,pos);
       //System.out.println(""+beforePoint+" "+value);


       TextLayout textLayout = new TextLayout(beforePoint, this.getFont(), fontRenderContext);
       Rectangle2D bounds = textLayout.getBounds();
       posX = posPoint - (int) bounds.getWidth();
       if(posX<4) posX=4;

    }                   
  }

/* DOESN'T WORK !!!
*
  class DoubleRenderer extends JTextField implements BasicRenderer
  {
     DecimalFormat format = new DecimalFormat("0.000");
     DefaultStyledDocument document = new DefaultStyledDocument();
     SimpleAttributeSet attributes;
     
     public DoubleRenderer()
     {
       super();     
       setOpaque(true);

       this.setEditable(false);
       this.setDocument(document);

       TabSet tabset = new TabSet(
             new TabStop[]{  
                new TabStop(160.2f, TabStop.ALIGN_DECIMAL, TabStop.LEAD_THICKLINE)
             });                            
       attributes = new SimpleAttributeSet();
       StyleConstants.setTabSet(attributes, tabset);
       StyleConstants.setForeground(attributes, Color.green);
           
     }

     public void setupUI()
     {
       setBorder(noFocusBorder);
       setOpaque(true);
     }

     public void setValue(Object o)
     {
       if(o==null)
       {
         setText("ERROR: null");
         //setText("");
         return;
       }    
       
       if(o instanceof Double)
       {
         double value = ((Double) o).doubleValue();
         try
         {
           document.remove(0, document.getLength());
           document.setParagraphAttributes(document.getLength(), 0, attributes, true);
           document.insertString(document.getLength(), "\t"+format.format(value), attributes);
         } catch(Exception e){ e.printStackTrace(); }
         //setText("\t"+format.format(value));
         return;  
       }

       try
       {
         document.replace(0,document.getLength(), "Bad class "+o.getClass(), attributes);
       } catch(Exception e){}

     }
  }  */
                                                                                                                                           
  class StringRenderer extends JLabel implements BasicRenderer
  {            
     public StringRenderer()
     {
       super();
       setOpaque(true);
     }

     public void setupUI()                                                                                              
     {
       setBorder(noFocusBorder);                                                                                       
       setOpaque(true);   
     }

     public void setValue(Object o)
     {
       setText(""+o);
     }
  }  
  
  class ColorRenderer extends JLabel implements BasicRenderer
  {
     public ColorRenderer()
     {
       super();
       setOpaque(true);
     }

     public void setupUI()
     {
       setBorder(noFocusBorder);
       setOpaque(true);
     }

     public void setValue(Object o)
     {
       this.setText("");
       if(o==null)
       {
         this.setText("null");
       }
       
       if(o instanceof Color)
       {
         this.setBackground((Color) o);
       }
       else
       { 
         this.setText("ERROR "+o.getClass().getName());
       }
     }
  } 
  
  class BooleanRenderer extends JCheckBox implements BasicRenderer
  {            
     public BooleanRenderer()
     {
       super();
       setOpaque(true);
     }

     public void setupUI()                                                                                              
     {
       setBorder(noFocusBorder);                                                                                       
       setOpaque(true);   
     }

     public void setValue(Object o)
     {
       if(o instanceof Boolean)
       {
         this.setSelected( (Boolean) o);
       }
     }
  }   


} // UniversalTableCellRenderer
