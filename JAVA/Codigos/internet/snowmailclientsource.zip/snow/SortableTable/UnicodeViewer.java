package snow.SortableTable;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.nio.charset.*;
import java.nio.*;
import java.util.*;
import java.io.*;

/**

  ftp://ftp.unicode.org/Public/UNIDATA/unicodeData.txt

*/

public final class UnicodeViewer extends JFrame
{  
  final private UnicodeTableModel basicTableModel = new UnicodeTableModel();
  final private SortableTableModel stm = new SortableTableModel(basicTableModel, 1, true);                                         
  final private JTable table = new JTable(stm);
  
  private final JComboBox charsetCB;
  private final JComboBox displayLimitCB = new JComboBox(new String[]{"32768", "256", "1024", "2048", "4096", "8192", "16384", "32768", "65536"});
  private int charDisplayLimit = 8192;
  StringBuffer allChars = new StringBuffer();  
  final private JDialog previewDialog;                                                                          
  final private JTextField previewLabel = new JTextField( 20 );

  public UnicodeViewer()
  {                                                                                                                                     
     super("");                                                                                   
     //this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

     table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
     stm.installGUI(table);
     getContentPane().add(new JScrollPane(table), BorderLayout.CENTER);

     table.setDefaultRenderer(Object.class, new UniversalTableCellRenderer(stm));
     table.setDefaultRenderer(Integer.class, new UniversalTableCellRenderer(stm));

     table.setFont(new Font("Dialog", Font.PLAIN, 16));
     table.setRowHeight(21);

     AdvancedSearchPanel searchPanel = new AdvancedSearchPanel("Search: ", null, stm, true);
     searchPanel.setAdvancedMode(true);
     getContentPane().add(searchPanel, BorderLayout.NORTH);

     // initialize combobox for charsets
     charsetCB = new JComboBox(collect_limited_Charsets());
     searchPanel.add(charsetCB);                                                                          
     charsetCB.setMaximumRowCount(30);
     charsetCB.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
         Charset cs = (Charset) charsetCB.getSelectedItem();                                                    
         basicTableModel.setCharset(cs);
       }
     });
                     
     searchPanel.add(new JLabel(" max showed element: "));
     searchPanel.add(displayLimitCB);
     displayLimitCB.setMaximumRowCount(20);
     displayLimitCB.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
         String limS = (String) displayLimitCB.getSelectedItem();
         basicTableModel.setDisplayLimit( Integer.parseInt(limS) );

       }
     });  
     
     // only few !
     //final JComboBox fontCB = new JComboBox(Toolkit.getDefaultToolkit().getFontList());
     final String[] allFonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
     final JComboBox fontCB = new JComboBox(allFonts);
                                                                                                                 
     searchPanel.add(fontCB);
     fontCB.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent ae)
       {
         String fn = (String) fontCB.getSelectedItem();
         table.setFont(new Font(fn, Font.PLAIN, 16));                                                           
         previewLabel.setFont(new Font(fn, Font.PLAIN, 64));
       }
     });                                                                                                     
              
     parseUnicodeData(new File("e:/projects/unicodedata.txt"));
     this.basicTableModel.setDisplayLimit(32768);
     charsetCB.setSelectedIndex(0);
     fontCB.setSelectedIndex(0);
                                                                                                                  
     setSize(800,600);
     setLocation(0,150);
     setVisible(true);

     previewDialog = new JDialog(this, "Preview", false);
     previewDialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
     previewDialog.getContentPane().setLayout(new BorderLayout());
     previewDialog.getContentPane().add(previewLabel, BorderLayout.CENTER);
     previewDialog.setSize(1000,150);
     previewDialog.setVisible(true);

     
     table.getSelectionModel().addListSelectionListener(new ListSelectionListener()
     { 
        public void valueChanged(ListSelectionEvent lse)
        {
           if(lse.getValueIsAdjusting()) return;
           
           int sel = table.getSelectedRow();
           if(sel==-1)
           { previewLabel.setText(""); return; }

           int pos = stm.getIndexInUnsortedFromTablePos(sel);
           if(pos==-1)
           { previewLabel.setText(""); return; }

           String nt = previewLabel.getText() + basicTableModel.getValueAt(pos,3);
           if(nt.length()>20) nt = nt.substring(nt.length()-20, nt.length());
           previewLabel.setText(nt);
        }
     });



     //System.out.println((int) Character.MAX_VALUE+" ");
  } // Constructor                                                                         

  
  private Vector<Charset> collect_limited_Charsets()
  {
     SortedMap sm = Charset.availableCharsets();
     Vector<Charset> items = new Vector<Charset>(sm.values());
     for(int i=items.size()-1; i>=0; i--)
     {
/*ACCEPT ALL 
       Charset cs = (Charset) items.elementAt(i);
       if(cs.newEncoder().averageBytesPerChar()!=1.0f)
       {
         items.remove(cs);
       }*/
     }  
     return items;
  }
  
  


  
  final private Hashtable<Integer,String> names = new Hashtable<Integer,String>();

  public void parseUnicodeData(File file)
  {
   FileReader fr = null;

   try
   {                                                                                                                                          
     fr = new FileReader(file);
     BufferedReader br = new BufferedReader(fr);
     String line = null;
     while( (line=br.readLine())!=null)
     { 
       try
       {
        // 0041 ; LATIN CAPITAL LETTER A ; Lu;0;L;;;;;N;;;;0061;
        StringTokenizer tokenizer = new StringTokenizer(line, ";");
        String n = tokenizer.nextToken(); //  0041
        String name = tokenizer.nextToken(); //  name
        
        int code = Integer.parseInt(n, 16);
        names.put(code, name);
       }
       catch(Exception e)
       {
         System.out.println("Cannot parse "+line);
       }         
     }
   }                                                                                            
   catch(Exception e)
   {                                                                                           
    //e.printStackTrace();
    System.out.println("Cannot read unicode data: "+e.getMessage());
   }           
   finally
   {
     try{fr.close();} catch(Exception e) {}
   }
  }


  public static void main(String[] a)
  {
     EventQueue.invokeLater(new Runnable()
     { public void run()
       {
         new UnicodeViewer();
       }
     });
  }


public static void mainTEST(String[] aaa)
{
   JFrame fr = new JFrame();
   fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   fr.setContentPane(
     new JLabel("  thai digit one :  \u0e51") );
   fr.pack();
   fr.setLocationRelativeTo(null);
   fr.setVisible(true);
}


                                                                                                                               
  class UnicodeTableModel extends FineGrainTableModel                                                                                 
  {  
     private char[] representableCharsetChars = null;

     String[] COLUMN_NAMES = new String[]{
                 "representable", "hexcode", "intcode", 
                 "char", "name", "unicode block", 
                 "type", "lowercase", "uppercase", "titlecase" };

     int[] COLUMN_PREFERED_SIZES = new int[]{4, 8,8,8, 28,16, 4,4,4,4};
     public int getPreferredColumnWidth(int column)                
     {
       if(column>=0 && column<COLUMN_PREFERED_SIZES.length) return COLUMN_PREFERED_SIZES[column];                                   
       return -1;
     }

     public String getColumnName(int col) { return COLUMN_NAMES[col]; }

     public int getColumnAlignment(int column)
     {
       if( column==3 || column==4) return JLabel.LEFT;
       return JLabel.CENTER;
     }
                         


     public int getColumnCount() { return COLUMN_NAMES.length; }
     public int getRowCount()    { return charDisplayLimit; }
     
     public void setDisplayLimit(int lim)
     {
       //System.out.println("set limit to "+lim);
       fireTableModelWillChange();
       charDisplayLimit = lim;
       fireTableDataChanged();
       fireTableModelHasChanged();  
     }

     public void setCharset(Charset cs)
     {
      fireTableModelWillChange();
      byte[] bb = new byte[256];
      for(int i=0; i<256; i++)
      {
        bb[i] =  (byte) i;
      }

      representableCharsetChars = cs.decode(ByteBuffer.wrap(bb)).toString().toCharArray();
      Arrays.sort(representableCharsetChars);
        fireTableDataChanged();
        fireTableModelHasChanged();
     }


     public Object getValueAt(int row, int col)
     {   
       char c = (char) row;

       if(col==0)
       {
        if(representableCharsetChars==null) return Boolean.TRUE;
        int pos = Arrays.binarySearch(representableCharsetChars, c);
        return  pos>=0 ; 
       }

       if(col==1)
       {
         String hexCode = "000"+Integer.toHexString(row);
         return hexCode.substring(hexCode.length()-4,hexCode.length());
       }

       if(col==2) return row;


       if(col==3) return ""+c ;
       if(col==4)
       {
         Object n = names.get(row); //Character.toString(c);
         if(n==null) return "";
         return ""+n;
       }
       if(col==5)
       {
         Character.UnicodeBlock ub = Character.UnicodeBlock.of(c);  // in 1.5, can be applied to INT
         if(ub==null) return "";
         return ""+ub;    
       }


       if(col==6) return Character.getType(c);
                                                 
       if(col==7) return Character.isLowerCase(c);
       if(col==8) return Character.isUpperCase(c);
       if(col==9) return Character.isTitleCase(c);

       

       return "?";
     }  

/*       
     public Class getColumnClass(int col)
     {
       if(col==0) return Integer.TYPE;
       return String.class;
     }  */
  }


} // UnicodeViewer
