package snow.SortableTable;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.plaf.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.nio.charset.*;
import java.nio.*;
import java.util.*;
import java.io.*;
           

public final class UIKeysViewer extends JFrame
{
  private final Vector<String> standardKeys = new Vector<String>();
  {
     standardKeys.add("Primary1");
  }

  final private UIKeysTableModel basicTableModel = new UIKeysTableModel();
  final private SortableTableModel sortableTableModel = new SortableTableModel(basicTableModel, 0, true);
  final private JTable table = new JTable(sortableTableModel);

  public UIKeysViewer()
  {
    super("Swing UI Keys explorer");                                                                            
    getContentPane().setLayout(new BorderLayout());
    getContentPane().add(new JScrollPane(table), BorderLayout.CENTER);
    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    sortableTableModel.installGUI(table);
                                                                    
    table.setDefaultRenderer(Object.class, new UniversalTableCellRenderer(sortableTableModel));
    table.setDefaultEditor(Object.class, new UniversalTableEditor());
                                                                       
    AdvancedSearchPanel asp = new AdvancedSearchPanel("Search: ", null, sortableTableModel, false);
    getContentPane().add(asp, BorderLayout.NORTH);
    
    
    this.setSize(850,800);
    this.setLocation(200,100);
    this.setVisible(true);   
    

  } // Constructor

                            

                           
  public static void main(String[] a)
  {       
     UIManager.put("Hello1", Boolean.TRUE);
     UIManager.put("Hello2", new Double(Math.PI));
     UIManager.put("Hello3", new Float((float) Math.PI));
              
     EventQueue.invokeLater(new Runnable()
     { public void run()
       {
         new UIKeysViewer();   
       }
     });
  }           
  
  
  

                                                                                                                               
  final private class UIKeysTableModel extends FineGrainTableModel
  {  
     final private Vector<String> keys = new Vector<String>();

     public UIKeysTableModel()
     {
        Enumeration enume = UIManager.getLookAndFeelDefaults().keys();
        while(enume.hasMoreElements())
        {
          keys.addElement("" + enume.nextElement());
        }  
        keys.addElement("Hello1");
        keys.addElement("Hello2");
        keys.addElement("Hello3");
     }

     public UIKeysTableModel(Vector keys)
     {
        this.keys.addAll(keys);
     }


     private char[] representableCharsetChars = null;

     String[] COLUMN_NAMES = new String[]{"name", "class", "value" };

     int[] COLUMN_PREFERED_SIZES = new int[]{20, 20, 25};
     public int getPreferredColumnWidth(int column)                
     {                        
       if(column>=0 && column<COLUMN_PREFERED_SIZES.length) return COLUMN_PREFERED_SIZES[column];
       return -1;
     }

     public String getColumnName(int col) { return COLUMN_NAMES[col]; }

     public int getColumnAlignment(int column)
     {
       return JLabel.LEFT;
     }
                         


     public int getColumnCount() { return COLUMN_NAMES.length; }
     public int getRowCount()    { return keys.size(); }


     public Object getValueAt(int row, int col)
     {
       String key = keys.elementAt(row);
       Object val = UIManager.get(key);
       if(col==0) return key;
       if(col==1) 
       {
         if(val==null) return "null value";
         return val.getClass().getName();
       }
       if(col==2)
       {
         if(val==null) return "null value";
         return val;    
       }

       return "?";
     }
     
     public boolean isCellEditable(int row, int col)
     {
       return col==2;
     }
     
     
     public void setValueAt(Object value, int row, int col)
     {
       if(col!=2) return;
       
       boolean updateUI = false;
       if(value instanceof Color)
       {
         value = new ColorUIResource((Color) value);
         updateUI = true;
       }

       if(value instanceof Font)
       {
         value = new FontUIResource((Font) value);
         updateUI = true;
       }

       if(row>=keys.size())
       {
          System.out.println("Key position "+row+" son't exist, keys size is only "+keys.size());
          return;
       }

       String key = (String) keys.elementAt(row);
       Object old = UIManager.get(key);
       
       if(old!=null && value!=null && !(old.getClass() == value.getClass()))
       {
         System.out.println("Attemp to changing class type ! set value cancelled");
         System.out.println(old.getClass().getName()+" => "+value.getClass().getName());

         return;
       }

       this.fireTableModelWillChange();

       UIManager.put(key, value);

       this.fireTableDataChanged();
       this.fireTableModelHasChanged();
       
       if(updateUI)
       {
         //updateUI(); //.repaint();
       }
     }
  } 


} // UIKeysViewer
