package snow.SortableTable;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

import java.util.*;


public final class TestModel extends FineGrainTableModel
{
  final Vector<TestModelItem> items = new Vector<TestModelItem>();
  String[] COLUMN_NAMES = new String[]{"Size", "Name", "Index", "Index2", "Index3", "check"};


  public TestModel()
  {
    for (int i=0; i<58; i++)
    {
      addRandom();
    }
  }

  int[] COLUMN_PREFERED_SIZES = new int[]{6,4,4,12,12,12};
  public int getPreferredColumnWidth(int column)
  {
    if(column>=0 && column<COLUMN_PREFERED_SIZES.length) return COLUMN_PREFERED_SIZES[column];
    return -1;
  }



  public void add(TestModelItem titm)
  {
      fireTableModelWillChange();

      items.addElement(titm);

      fireTableDataChanged();
      fireTableModelHasChanged();
  }

  public void remove(TestModelItem titm)
  {   
      fireTableModelWillChange();
      items.removeElement(titm);
      fireTableDataChanged();
      fireTableModelHasChanged();
  }     


  int n=0;             

  public void addRandom()
  {
     n++;

     TestModelItem titm = new TestModelItem();
     titm.col1 = Math.random()*1e6;
     if(Math.random()<0.1) titm.col1 = Math.random()*1e3;
     titm.col2 = ""+((char) ('a'+(n%26)));
     titm.col3 = n;
     titm.col4 = (int) (Math.random()*1000);
     titm.col5 = (int) (Math.random()*1000000);
     add(titm);
  }


  public void removeLast()
  {             
      if(items.size()==0) return;
                  
      fireTableModelWillChange();
      items.removeElementAt(items.size()-1);
      fireTableDataChanged();
      fireTableModelHasChanged();
  }                 
  

  public int getRowCount() {return items.size();}
  public int getColumnCount() {return 6;}

  public TestModelItem getItemAt(int pos)
  {                  
    return items.elementAt(pos);
  }

  public Object getValueAt(int row, int column)
  {
    TestModelItem item = getItemAt(row);
    if(column==0) return new Double(item.col1);
    if(column==1) return item.col2;
    if(column==2) return item.col3;
    if(column==3) return item.col4;
    if(column==4) return item.col5;
    if(column==5) return item.checked;
    return "??";
  }

  public boolean hitForTextSearch(int row, String str)
  {
    return super.hitForTextSearch(row, str, null);
  /*
    TestModelItem item = getItemAt(row);

    String s1 =""+item.col1;
    if(s1.indexOf(str)>=0) return true;
    String s2 =""+item.col2;
    if(s2.indexOf(str)>=0) return true;
    String s3 =""+item.col3;
    if(s3.indexOf(str)>=0) return true;
    String s4 =""+item.col4;
    if(s4.indexOf(str)>=0) return true;
    String s5 =""+item.col5;
    if(s5.indexOf(str)>=0) return true;
    return false;    */
  }                  

  public boolean isCellEditable(int row, int col)
  {                       
    return col<=2 || col==5;
  }

  public void setValueAt(Object val, int row, int col)
  {
    if(val==null) return;

    fireTableModelWillChange();
    TestModelItem item = getItemAt(row);
    if(col==0)
    {
      try
      {
        double vd = Double.parseDouble(""+val);
        item.col1 = vd;
      }
      catch(Exception e){}
    }
    else if(col==1)
    {
      item.col2 = (String) val;
    }
    else if(col==2)
    {
      item.col3 = (Integer) val;
    }
    else if(col==5)
    {
      item.checked = (Boolean) val;
    }


    // must notify table that data has changed
    fireTableDataChanged();
    fireTableModelHasChanged();
  }
  
  

  public String getColumnName(int column)
  {
    if(column>=0 && column<COLUMN_NAMES.length) return COLUMN_NAMES[column];
    return "Bad column "+column;
  }
     
     /*
  public int compareForColumnSort(int pos1, int pos2, int col)
  {
    if(col==0 || col>=2)
    {
      double v1 = Double.parseDouble(""+getValueAt(pos1, col));
      double v2 = Double.parseDouble(""+getValueAt(pos2, col));
      if(v1==v2) return 0;
      if(v1>v2) return 1;
      return -1;
    }
    else
    {
      String v1 = ""+getValueAt(pos1, col);
      String v2 = ""+getValueAt(pos2, col);
      return v1.compareTo(v2);
    }
   // return 0;        

  }*/

  // Selection implementation
  //

  public void setRowSelection(int row, boolean isSelected)
  {             
    TestModelItem item = getItemAt(row);
    item.selected = isSelected;
  }

  public boolean isRowSelected(int row)
  {        
    TestModelItem item = getItemAt(row);
    return item.selected;
  }
        
  public void clearRowSelection()
  { 
    synchronized(items)
    {
      for(int i=0; i<getRowCount(); i++)
      {
         TestModelItem item = getItemAt(i);
         item.selected = false;
      }    
    }
  }

}


