package snow.SortableTable;


import java.awt.*;
import java.awt.event.*;        
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;           
                                                      
import java.util.*;
           

/** wraps around a table model to extract first column of rest
    USE instanciate twice, one time with first=true for the headers
    one time with first=false for the rest
*/
public class RowHeaderExtractorWrapperSortableTableModel extends AbstractTableModel
{
  boolean first;
  SortableTableModel baseModel;
  int numberOfColumnHeaders;

  public RowHeaderExtractorWrapperSortableTableModel(
              boolean _first,
              SortableTableModel _baseModel,
              int _numberOfColumnHeaders)
  {
    super();
    this.first = _first;
    this.baseModel = _baseModel;
    this.numberOfColumnHeaders = _numberOfColumnHeaders;

    // give the events of the bassModel to this
    baseModel.addTableModelListener(new TableModelListener()
    {
       public void tableChanged(TableModelEvent e)
       {
         if(e.getFirstRow()==TableModelEvent.HEADER_ROW)
         {
           fireTableStructureChanged();
         }
         else
         {
           fireTableDataChanged();
         }
       }
    });
     
  } // Constructor



  private int getColumn(int col)
  {
    if(first) return col;
    return col + numberOfColumnHeaders;
  }


  // AbstractTableModel impl
  //

  public int getRowCount() {return baseModel.getRowCount();}

  public int getColumnCount()
  {
    return (first?
       numberOfColumnHeaders
      :baseModel.getColumnCount()-numberOfColumnHeaders);
  }


  public Object getValueAt(int row, int column)
  {
     return baseModel.getValueAt(row,  getColumn(column));
  }

  public boolean isCellEditable(int row, int col)
  {
     return baseModel.isCellEditable(row, getColumn(col));
  }

  public void setValueAt(Object val, int row, int col)
  {
     baseModel.setValueAt(val, row, getColumn(col));
  }

  public String getColumnName(int column)
  {
     return baseModel.getColumnName( getColumn(column) );

  }

  public Class getColumnClass(int col)
  {
     return baseModel.getColumnClass(getColumn(col));
  }

      
/*  public void setPreferredColumnSizesFromModel()
  {
    if(tableReference==null) return;

    int fontSize = UIManager.getFont("Label.font").getSize();
    for(int i=0; i<tableReference.getColumnCount(); i++)
    {
      int pos = this.getColumnForViewIndex(i);
      int w = this.basicTableModel.getPreferredColumnWidth(pos);
      if(w>0)
      {
        tableReference.getColumnModel().getColumn(i).setPreferredWidth(w*fontSize);
      }
    }

  }  */    

} // RowHeaderExtractorWrapperSortableTableModel    

