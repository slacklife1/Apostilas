package snow.utils;



import java.util.*;
import java.io.*;

public final class StreamGobbler extends Thread
{
    private InputStream  inputStream;
    private OutputStream outputStream;

    private String streamIdentifier = "";
    // Is just a text, which is repeated on each beginning of a line.



   /**
    *  Constructor 1.
    *  The outputStream can be null - then the input just will be
    *  read, but not forwarded.
    */
    public StreamGobbler( final InputStream inputStream,
                          final OutputStream outputStream )
    {                      
      this.inputStream = inputStream;
      this.outputStream = outputStream;
    }


    
   /**
    *  Constructor 2: An additional name is passed, which is
    *  written out on each beginning of a line.
    *  The outputStream can be null - then the input just will be
    *  read, but not forwarded.
    */
    public StreamGobbler( final InputStream inputStream,
                          final OutputStream outputStream,
                          final String theStreamIdentifier)
    {
      this(inputStream,outputStream);
      this.streamIdentifier = theStreamIdentifier + ">  ";
    }



    public void run()
    {                          
      try         
       {
         PrintWriter printWriter = null;
         if( this.outputStream != null ) printWriter = new PrintWriter(this.outputStream);
         final InputStreamReader isr = new InputStreamReader(this.inputStream);
         final BufferedReader br = new BufferedReader(isr);
         String line = null;
         while( (line = br.readLine()) != null)
         {
           if( printWriter != null )
           {
               printWriter.println( this.streamIdentifier + line );
               //System.out.println("Debug: "+line);
               printWriter.flush();
           } // else we do nothing
         }
       }
      catch( IOException ioe )
       {
         ioe.printStackTrace();
       }
    } //run



} // StreamGobbler




