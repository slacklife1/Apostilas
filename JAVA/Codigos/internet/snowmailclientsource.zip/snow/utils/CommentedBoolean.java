package snow.utils;

public final class CommentedBoolean
{       
  public boolean value ;
  public String comment;
  public CommentedBoolean(boolean value, String comment)
  {
    this.value = value;
    this.comment = comment;
  }

  public static CommentedBoolean trueC() {return new CommentedBoolean(true,null);}
  public static CommentedBoolean FalseC() {return new CommentedBoolean(false,null);}
//  public static CommentedBoolean True(String why) {return new CommentedBoolean(true,why);}
  public static CommentedBoolean FalseC(String why) {return new CommentedBoolean(false,why);}

} 
