package snow.utils;

import java.util.*;
import java.io.*;
         
         
/** the number is usually used a human-readable debug information
    this also stores the last line, allowing a kind of "undo"
    very useful in certain parse operations.
*/
public final class NumberedLineReader extends BufferedReader
{         
  int lineNumber = 0;
  String lastLine = null;
             
  public NumberedLineReader(String cont)
  {                          
     super( new StringReader( cont ) );     
  } // Constructor


  public String readLine() throws IOException
  {
     lineNumber++;
     lastLine = super.readLine();
     return lastLine;
  }
  
  public String getLastLineCached() { return lastLine; }
  
  public int getLineNumber() { return lineNumber; }         

} // NumberedLineReader
