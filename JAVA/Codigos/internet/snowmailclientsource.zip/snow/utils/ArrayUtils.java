    
package snow.utils;

public class ArrayUtils
{

  public ArrayUtils()
  {

  } // Constructor

  public static String toString(String[] a)
  {
    StringBuffer sb = new StringBuffer();
    for(int i=0; i<a.length; i++)
    {
      sb.append(""+a[i]);
      if(i<a.length-1) sb.append(", ");
    }
    return sb.toString();
  }

  public static String toString(int[] a)
  {
    StringBuffer sb = new StringBuffer();
    for(int i=0; i<a.length; i++)
    {
      sb.append(""+a[i]);
      if(i<a.length-1) sb.append(", ");
    }
    return sb.toString();
  }    

} // ArrayUtils
