package snow.utils.storage;

import java.util.*;
import java.io.*;
import java.awt.Component;
import java.awt.Font;
import java.awt.Color;
import java.awt.Toolkit;

public final class AppProperties extends Properties {

    public AppProperties()
    {
        super();
    }

    public void load_XML(File f)
    {
       if(!f.exists()) return;

       FileInputStream fis = null;
       try
       {
         fis = new FileInputStream(f);
         this.loadFromXML( fis );
       }
       catch(Exception e)
       {
         e.printStackTrace();
       }
       finally
       {
         if(fis!=null) try{ fis.close(); } catch(Exception ex) {}
       }
    }

    public void save_XML(File f)
    {
       FileOutputStream fos = null;
       try
       {
         fos = new FileOutputStream(f);
         this.storeToXML(fos, "AppProperties" );
       }
       catch(Exception e)
       {
         e.printStackTrace();
       }
       finally
       {
         if(fos!=null) try{ fos.close(); } catch(Exception ex) {}
       }
    }

    public void setArrayProperty(String key, String[] values)
    {
        setProperty(key+"length", ""+values.length);
        for(int i=0; i<values.length; i++)
        setProperty( key+(i), values[i]);
    }

    public String[] getArrayProperty(String key, String[] defaults)
    {
        String found = getProperty(key+"length", "no");
        if(found.equals("no")) return defaults;
        int n = Integer.parseInt(found);
        String[] props = new String[n];
        for(int i=0; i<n; i++)
        {
            props[i] = getProperty( key+(i), "oh la la la la");
        }
        return props;
    }  

    public void setInteger(String key, int val)
    {
        this.put(key, ""+val);
    }
    
    public void setLong(String key, long val)
    {
        this.put(key, ""+val);
    }
    
    public void setDouble(String key, double val)
    {
        this.put(key, ""+val);
    }
    
    public Font getFont(String key, Font def)
    {
       String name = this.getProperty(key+"_name", "?");
       if(name.equals("?")) return def;

       int style = this.getInteger(key+"_style", Font.PLAIN);
       int size = this.getInteger(key+"_size", 12);
                  
       return new Font(name, style, size);
    }

    public Color getColor(String key, Color def)
    {
       int r = this.getInteger(key+"_r", -1);
       if(r==-1) return def;
       int g = this.getInteger(key+"_g", 0);
       int b = this.getInteger(key+"_b", 0);
       int a = this.getInteger(key+"_a", 0);
       return new Color(r,g,b,a);
    }

    public void setColor(String key, Color val)
    {
       if(val==null)
       {
        this.remove(key+"_r");
        this.remove(key+"_g");
        this.remove(key+"_b");
        this.remove(key+"_a");

       }
       else
       {
        this.setInteger(key+"_r", val.getRed());
        this.setInteger(key+"_g", val.getGreen());
        this.setInteger(key+"_b", val.getBlue());
        this.setInteger(key+"_a", val.getAlpha());
       }
    }

    public void setFont(String key, Font font)
    {
       if(font==null)
       {
        this.remove(key+"_name");
        this.remove(key+"_style");
        this.remove(key+"_size");
       }
       else
       {
        this.put(key+"_name", font.getName());
        this.setInteger(key+"_style", font.getStyle());
        this.setInteger(key+"_size", font.getSize());
       }
    }

    /** this set the key
    */
    public void setStringLCK(String key, String val)
    {
        this.put(key.toLowerCase(), val);
    }

    public int getInteger(String key, int def)
    {
        String found = getProperty(key, "no");
        if(found.equals("no")) return def;
        try{
            int n = Integer.parseInt(found);
            return n;
        } catch(Exception e)
        {
          return def;
        }
    }
    
    public long getLong(String key, long def)
    {
        String found = getProperty(key, "no");
        if(found.equals("no")) return def;
        try{
            long n = Long.parseLong(found);
            return n;  
        } catch(Exception e)
        {
          return def;
        }
    }    
    
    public double getDouble(String key, double def)
    {
        String found = getProperty(key, "no");
        if(found.equals("no")) return def;
        try{
            double n = Double.parseDouble(found);
            return n;
        } catch(Exception e)
        {
          return def;
        }
    }

    public void setBoolean(String key, boolean val)
    {
        this.put(key, (val?"true":"false"));
    }

    public boolean getBoolean(String key, boolean def)
    {
        String found = getProperty(key, "no");
        if(found.equals("no")) return def;
        return (found.equals("true"));
    }

    /** lowercase key
    */
    public String getStringLCK(String key, String def)
    {
        String found = getProperty(key.toLowerCase(), "no");
        if(found.equals("no")) return def;
        return found;
    }


   /** set the component size and location
    */
    public synchronized void setComponentSizeFromINIFile( Component comp, String key,
         int defWidth, int defHeight, int defPosX, int defPosY)
    {          
        int w = getInteger(key+".width", defWidth);
        int h = getInteger(key+".height", defHeight);
        
        // ###
        if(w<=defWidth/10 || h<=defHeight/10) 
        {
          w=defWidth;
          h=defHeight;  
        }
        comp.setSize(w, h);
        
        setComponentLocationFromINIFile(comp, key, defPosX, defPosY);
    }

  /** save the component size and location
  */
    public synchronized void saveComponentSizeInINIFile(Component comp, String key)
    {
        this.setInteger(key+".width",  (int) comp.getSize().getWidth());
        this.setInteger(key+".height", (int) comp.getSize().getHeight());
        this.setInteger(key+".posx",   (int) comp.getLocation().getX());
        this.setInteger(key+".posy",   (int) comp.getLocation().getY());
    }

   /** set the component location
    */
    public synchronized void setComponentLocationFromINIFile( Component comp, String key,
         int defPosX, int defPosY)
    {
        int x = getInteger(key+".posx", defPosX);
        int y = getInteger(key+".posy", defPosY);

        if(x<0) x=0;
        if(y<0) y=0;
        
        int screenW = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        int screenH = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();

        if(x > screenW-20) x = screenW - 20;
        if(y > screenH-20) y = screenH - 20;
         
        comp.setLocation(x, y);
    }

  /** save the component location
  */
    public synchronized void saveComponentLocationInINIFile(Component comp, String key)
    {
        this.setInteger(key+".posx",   (int) comp.getLocation().getX());
        this.setInteger(key+".posy",   (int) comp.getLocation().getY());
    }

    public Vector<Object> getVectorRepresentation()
    {
        Vector<Object> v = new Vector<Object>();
        v.add(1); // version
        v.add(this.size());
        Enumeration enum2 = this.keys();
        while(enum2.hasMoreElements())
        {
            Object obj = enum2.nextElement();
            v.addElement(""+ obj);
            v.addElement(getProperty((String) obj));
        }
        return v;
    }

    public void createFromVectorRepresentation(Vector<Object> v)
    {
        int ver = (Integer) v.elementAt(0);
        if(ver!=1) throw new RuntimeException("version ="+ver+" not supported");
        int size = (Integer) v.elementAt(1);
        for(int i=0; i<size; i++)
        {
            this.setProperty((String) v.elementAt(2*i+2), (String) v.elementAt(2*i+3));
        }
    }


}
