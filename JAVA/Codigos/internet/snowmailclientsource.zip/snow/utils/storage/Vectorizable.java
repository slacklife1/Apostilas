package snow.utils.storage;

import java.util.Vector;

/**
 */
public interface Vectorizable {

    public Vector<Object> getVectorRepresentation() throws VectorizeException;
    public void createFromVectorRepresentation(Vector<Object> v) throws VectorizeException;
}
