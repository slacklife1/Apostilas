package snow.utils.storage;

import java.io.*;
import java.util.Vector;

public final class VectorUtils {

  // Constants used to map classnames into integers
  // used by the vectorrepresentation methods :
  // DO NOT CHANGE - or all designfiles saved cannot be read in anymore.
  public static final int IsVectorContent  = 1;
  public static final int IsIntegerContent = 2;
  public static final int IsBooleanContent = 3;
  public static final int IsDoubleContent  = 4;
  public static final int IsStringContent  = 5;
  public static final int IsbyteArrayContent   = 10;
  public static final int IsintArrayContent    = 11;
  public static final int IsfloatArrayContent  = 12;
  public static final int IsdoubleArrayContent = 13;
  public static final int IsStringArrayContent = 14;

  public static final int IsLongStringContent = 20;
  public static final int IsLongContent = 21;



 /**
  *  writes the vector (consisting of elementary types)
  *  inverse method is streamToVector
  */
  public static final void VectorToStream( final DataOutputStream out, final Vector<Object> theVector ) throws Exception
  {
    VectorToStreamRecurse(out, theVector);
  }






 /**
  *  Writes the vector (consisting of elementary types)
  *  inverse method is streamToVector
  */
  private static final void VectorToStreamRecurse( final DataOutputStream out ,
                                             final Vector<Object> theVector ) throws Exception
  {
      if (theVector == null)
      {
        System.out.println("VectorUtils vectorToStream:  null vector received!");
        out.writeInt( IsVectorContent );
        // and send its size right after this :
        Vector<Object> thisVector = new Vector<Object>();
        int thisSize = thisVector.size();
        out.writeInt(thisSize);
      }
      else
      {
        out.writeInt( IsVectorContent );
        // and send its size right after this :
        int thisSize = theVector.size();
        out.writeInt(thisSize);

        for( int i=0; i < thisSize; i++)
        {
          Object thisContent = theVector.elementAt(i);                                         
          if( thisContent instanceof Integer )
          {
            out.writeInt( IsIntegerContent );
            out.writeInt( (Integer) thisContent );
          }
          else if( thisContent instanceof Double )
          {
            out.writeInt( IsDoubleContent );
            out.writeDouble( (Double) thisContent );
          }
          else if( thisContent instanceof Long )
          {
            out.writeInt( IsLongContent );
            out.writeLong( (Long) thisContent );
          }          
          else if( thisContent instanceof String )
          {
            // UTF is limited to 65535 bytes !, we must check
            //
            String str = (String) thisContent;
            int len = calculateUTFLength(str);
            //System.out.println("len="+len);
            if(len<65535)
            {
              //if(len>10000) System.out.println("Writing a "+len+" String in utf-8");
              out.writeInt( IsStringContent );
              out.writeUTF( str );
            }
            else
            {
              //System.out.println("Writing a "+len+" String in utf-16");
              out.writeInt( IsLongStringContent );
              byte[] theArray = str.getBytes("UTF-16");
              out.writeInt( theArray.length  );
              for( int index=0; index < theArray.length; index++ )
              {
                 out.writeByte(theArray[index]);
              }
            }
          }
          else if( thisContent instanceof Boolean )
          {
            out.writeInt( IsBooleanContent );
            out.writeBoolean( (Boolean) thisContent );
          }
          else if( thisContent instanceof byte[] )
          {
            byte[] theArray = (byte[])thisContent;
            out.writeInt( IsbyteArrayContent  );
            out.writeInt( theArray.length  );
            for( int index=0; index < theArray.length; index++ )
             {
              out.writeByte(theArray[index]);
             }
          }
          else if( thisContent instanceof int[] )
          {
            int[] theArray = (int[])thisContent;
            out.writeInt( IsintArrayContent  );
            out.writeInt( theArray.length  );
            for( int index=0; index < theArray.length; index++ )
             {
              out.writeInt(theArray[index]);
             }
          }
          else if( thisContent instanceof double[] )                
          {
            double[] theArray = (double[])thisContent;
            out.writeInt( IsdoubleArrayContent  );
            out.writeInt( theArray.length  );
            for( int index=0; index < theArray.length; index++ )
             {
              out.writeDouble(theArray[index]);
             }
          }
          else if( thisContent instanceof float[] )
          {
            float[] theArray = (float[])thisContent;
            out.writeInt( IsfloatArrayContent  );
            out.writeInt( theArray.length  );
            for( int index=0; index < theArray.length; index++ )
             {
              out.writeFloat(theArray[index]);
             }
          }
          else if( thisContent instanceof String[] )
          {
            String[] theArray = (String[])thisContent;
            out.writeInt( IsStringArrayContent  );
            out.writeInt( theArray.length  );
            for( int index=0; index < theArray.length; index++ )
             {
              out.writeUTF(theArray[index]);
             }
          }
          else if( thisContent instanceof Vector )
          {
            // now dive one recursion level deeper and sent its elements :
            VectorToStream( out , (Vector)thisContent );
          }
          else if( thisContent == null )
          {
            // caution : this will be processed, if there are
            // null values in the frontend database. But this
            // can give troubles, when the same mechanism is
            // reversed and tries to write back a String, where
            // in the database there isnt defined anything.
            // One has to correct the database in this case.
            out.writeInt( IsStringContent );
            out.writeUTF( "<null value!>" );
          }
         else
          {
            System.out.println("**vectorToStream error: Only Integer, Double, Boolean, String, byte[], int[], double[], float[] and Vector types supported.");
            System.out.println("**The data had value :" + thisContent.toString());
            System.out.println("**The data had class : " + thisContent.getClass().toString() );
          }
        } // for
      }
  } // vectorToStream



 /**
  *  Reads the stream, which originates from a vectorToStream process
  *  and rebuilds theVector. theVector has initially to be a vector with zero length.
  *  Inverse method is vectorToStream.
  */
  public static void StreamToVector( final DataInputStream in ,
                                     final Vector<Object> theVector) throws Exception
  {
     StreamToVector(in, theVector, true);
  }


 /**
  *  Reads the stream, which originates from a vectorToStream process
  *  and rebuilds theVector. theVector has initially to be a vector with zero length.
  *  This method uses recursion.
  */
  private static void StreamToVector( final DataInputStream in ,
                                     final Vector<Object> theVector,
                                     final boolean recursionStart  ) throws Exception
  {                                           
      // Do NOT catch exceptions here. They must be propagated back to the callers,
      // for giving them a chance to react on error situations.

      // At the first run, we have to read the string "vector once",
      // but not in recursion :
      if( recursionStart ) // read the keynumber for "vector" only on the first call
       {
        int dummy = in.readInt();
       }
      // read the size :
      int numberOfElements = in.readInt();
      // System.out.println("Vector contains "+numberOfElements+" elements");

      for( int elementIndex = 0; elementIndex < numberOfElements; elementIndex++)
      {
        final int thisClassIndex = in.readInt(); // the data type keyword string
        if( thisClassIndex == IsIntegerContent )
        {
          int thisValue = in.readInt();
          theVector.addElement( thisValue );
        }
        else if( thisClassIndex == IsDoubleContent )
        {
          double thisValue = in.readDouble();
          theVector.addElement( thisValue );
        }
        else if( thisClassIndex == IsLongContent )
        {
          long thisValue = in.readLong();
          theVector.addElement( thisValue );
        }
        else if( thisClassIndex == IsStringContent )
        {
          String thisValue = in.readUTF();
          theVector.addElement( thisValue );
        }
        else if( thisClassIndex == IsBooleanContent )
        {
          boolean thisValue = in.readBoolean();
          theVector.addElement( thisValue );
        }
        else if( thisClassIndex == IsbyteArrayContent )
        {
          int arraySize = in.readInt();
          byte[] thisValue = new byte[arraySize];
          for( int index = 0; index < arraySize; index++ )
           {
            thisValue[index] = in.readByte();
           }
          theVector.addElement( thisValue );
        }
        else if( thisClassIndex == IsLongStringContent )
        {
          int arraySize = in.readInt();
          //System.out.println("Reading a "+arraySize+" String in utf-16");
          byte[] thisValue = new byte[arraySize];
          for( int index = 0; index < arraySize; index++ )
          {
            thisValue[index] = in.readByte();
          }
          theVector.addElement( new String(thisValue, "UTF-16") );
        }
        else if( thisClassIndex == IsintArrayContent )
        {
          int arraySize = in.readInt();
          int[] thisValue = new int[arraySize];
          for( int index = 0; index < arraySize; index++ )
          {
            thisValue[index] = in.readInt();
          }
          theVector.addElement( thisValue );
        }
        else if( thisClassIndex == IsdoubleArrayContent )
        {
          int arraySize = in.readInt();
          double[] thisValue = new double[arraySize];
          for( int index = 0; index < arraySize; index++ )
           {
             thisValue[index] = in.readDouble();
           }
          theVector.addElement( thisValue );
        }
        else if( thisClassIndex == IsfloatArrayContent )
        {
          int arraySize = in.readInt();
          float[] thisValue = new float[arraySize];
          for( int index = 0; index < arraySize; index++ )
           {
             thisValue[index] = in.readFloat();
           }
          theVector.addElement( thisValue );
        }
        else if( thisClassIndex == IsStringArrayContent )
        {
          int arraySize = in.readInt();
          String[] thisValue = new String[arraySize];
          for( int index = 0; index < arraySize; index++ )
           {
             thisValue[index] = in.readUTF();
           }
          theVector.addElement( thisValue );
        }
        else if( thisClassIndex == IsVectorContent )
        {
          // generate a new Vector and add it :
          Vector<Object> thisSubVector = new Vector<Object>();
          theVector.addElement(thisSubVector);                              
          // dive one recursion level deeper :
          StreamToVector( in , thisSubVector, false );
        }
        else
        {
          System.out.println("streamToVector error: Only Integer, Double Boolean and String types supported.");
          System.out.println("This class identifier index was : " + thisClassIndex );
        }
      } // for
  } // streamToVector



  /** an utf string has a 65535 bytes limited length.
    chars < 127 take one byte, greater chars take 2 or 3 bytes
    this routine returns the exact bytes that the string will take
  */
  public static final int calculateUTFLength(String str)
  {
    int strlen = str.length();
    int utflen = 0;
    char[] charr = new char[strlen];
    int c, count = 0;

    str.getChars(0, strlen, charr, 0);

    for (int i = 0; i < strlen; i++)
    {
       c = charr[i];
       if ((c >= 0x0001) && (c <= 0x007F))
       {
          utflen++;
	     }
       else if (c > 0x07FF)
       {
          utflen += 3;
       }
       else
       {
          utflen += 2;
       }
    }
    return utflen;
  }
  
  
  
  
  

 /**  FROM SCHMORTOPF
  *   Reads a Vector, which was written using SendVector() from
  *   the inputstream.    
  */
  public static Vector<Object> ReceiveVector( final DataInputStream in ) throws Exception
  {                                                   
    int vectorSize = 0;
    // First read its size :
    vectorSize = in.readInt();
    // Then use the recursive worker method for the rest :
    final Vector<Object> theVector = new Vector<Object>();
    ReceiveVectorCoded( in,theVector,vectorSize ); // works on theVector
    return theVector;
  }


                                                                    



 /** FROM SCHMORTOPF
  *  Recursive worker method for ReceiveVector()
  */     
  private static void ReceiveVectorCoded( final DataInputStream in ,
                                          final Vector<Object> theVector,
                                          final int numberOfElements ) throws Exception
  {
     for( int elementIndex = 0;
          elementIndex < numberOfElements;
          elementIndex++) 
      {
       final int thisClassIndex = in.readInt(); // the data type keyword string
       if( thisClassIndex == IsStringContent )
        {
         String thisValue = in.readUTF();
         theVector.addElement( thisValue );
        }
       else if( thisClassIndex == IsIntegerContent )
        {
         int thisValue = in.readInt();
         theVector.addElement( thisValue );
        }
       else if( thisClassIndex == IsLongContent )
        {
         long thisValue = in.readLong();
         theVector.addElement( thisValue );
        }
       else if( thisClassIndex == IsDoubleContent )
        {
         double thisValue = in.readDouble();
         theVector.addElement( thisValue );
        }
       else if( thisClassIndex == IsBooleanContent )
        {
          boolean thisValue = in.readBoolean();
          theVector.addElement( thisValue );
        }
       else if( thisClassIndex == IsbyteArrayContent )
        {
          int arraySize = in.readInt();
          byte[] thisValue = new byte[arraySize];
          for( int index = 0; index < arraySize; index++ )
           {
            thisValue[index] = in.readByte();
           }
          theVector.addElement( thisValue );
        }
       else if( thisClassIndex == IsintArrayContent )
        {
          int arraySize = in.readInt();
          int[] thisValue = new int[arraySize];
          for( int index = 0; index < arraySize; index++ )
           {
            thisValue[index] = in.readInt();
           }
          theVector.addElement( thisValue );
        }
       else if( thisClassIndex == IsdoubleArrayContent )
        {
          int arraySize = in.readInt();
          double[] thisValue = new double[arraySize];
          for( int index = 0; index < arraySize; index++ )
           {
            thisValue[index] = in.readDouble();
           }
          theVector.addElement( thisValue );
        }
       else if( thisClassIndex == IsfloatArrayContent )
        {
          int arraySize = in.readInt();
          float[] thisValue = new float[arraySize];
          for( int index = 0; index < arraySize; index++ )
           {
            thisValue[index] = in.readFloat();
           }
          theVector.addElement( thisValue );
        }
       else if( thisClassIndex == IsStringArrayContent )
        {
          int arraySize = in.readInt();
          String[] thisValue = new String[arraySize];
          for( int index = 0; index < arraySize; index++ )
           {
            thisValue[index] = in.readUTF();
           }
          theVector.addElement( thisValue );
        }
       else if( thisClassIndex == IsVectorContent )
        {
         int thisVectorSize = in.readInt();
         // generate a new Vector and add it :
         Vector<Object> thisSubVector = new Vector<Object>();
         theVector.addElement(thisSubVector);
         // dive one recursion level deeper :
         ReceiveVectorCoded( in ,
                             thisSubVector,
                             thisVectorSize );
        }
       else
        {
         System.out.println("*** FileUtilities.ReceiveVectorCoded error: Only Integer, Double and String types supported.");
         System.out.println("*** The data had classindex = " + thisClassIndex );
         throw new Exception("FileUtilities.ReceiveVectorCoded error");
        }
      } // for
  } // ReceiveVectorCoded
  








}
