package snow.utils.storage;


import java.io.*;
import java.util.*;
import java.util.zip.*;

/** all file access should be done from here
*/
public final class FileUtils
{
                                                 
  private FileUtils()
  {
  } // Constructor
                       
  public static Class getLockForFileAccess()
  {
    return FileUtils.class;       
  }

  public static Vector<Object> loadVectorFromFile(File file) throws Exception
  {  
    synchronized( FileUtils.getLockForFileAccess() )
    {                                
      if(!file.exists()) throw new Exception("File "+file.getAbsolutePath()+" doesn't exist");
      FileInputStream fis = null;
      DataInputStream dis = null;
      Vector<Object> v = new Vector<Object>();
      try    
      {
         fis = new FileInputStream(file);
         dis = new DataInputStream(fis);
         VectorUtils.StreamToVector(dis, v);
         dis.close();
         return v;
      }
      catch(Exception e)
      {
        throw e;
      }
      finally
      {
        if(fis!=null) fis.close();
      }   
    }                          
  }    
  
  public static Vector<Object> loadZippedVectorFromFile(File file) throws Exception
  {  
    synchronized( FileUtils.getLockForFileAccess() )
    {                                
      if(!file.exists()) throw new Exception(
        "File "+file.getAbsolutePath()+" doesn't exist");
      FileInputStream fis = null;
      GZIPInputStream zis = null;
      DataInputStream dis = null;
      Vector<Object> v = new Vector<Object>();
      try
      {                        
         fis = new FileInputStream(file);
         zis = new GZIPInputStream(fis);
         dis = new DataInputStream(zis);
         v = VectorUtils.ReceiveVector(dis);
         dis.close();
         return v;   
      }
      catch(Exception e)
      {
        throw e;
      }
      finally
      {
        if(fis!=null) fis.close();
      }   
    }                          
  }   
  
  /** load the vector from the inputstream.
    Caution: the stream is not closed, this allow you to read several vectory from the stream
    a header and a body, for example.
  */
  public static Vector<Object> loadVector(InputStream is) throws Exception
  {
    synchronized( FileUtils.getLockForFileAccess() )
    {
      DataInputStream dis = null;
      Vector<Object> v = new Vector<Object>();
      try
      {
         dis = new DataInputStream(is);
         VectorUtils.StreamToVector(dis, v);
         dis.close();
         return v;
      }
      catch(Exception e)
      {
        throw e;
      }
    }
  }

  public static void SaveVectorToFile(File file, Vector v) throws Exception
  {
    synchronized( FileUtils.getLockForFileAccess() )
    {
      if(file.exists())
      {        
        // delete
        if(!file.delete())
        {
           throw new Exception(
             "File "+file.getAbsolutePath()+" already exists and cannot be deleted"
               );
        }
      }
      FileOutputStream fos = null;
      DataOutputStream dos = null;
      try
      {
         fos = new FileOutputStream(file);
         dos = new DataOutputStream(fos);
         VectorUtils.VectorToStream(dos, v);
      }
      catch(Exception e)
      {
        throw e;
      }
      finally
      {
        if(fos!=null) fos.close();
      }  
    }
  }
  
  public static void addToZip(ZipOutputStream zos, File f, String relName) throws Exception
  {
    synchronized( FileUtils.getLockForFileAccess() )
    {                          
      FileInputStream fis = null;
      try
      {    
        ZipEntry ze = new ZipEntry(relName);
        ze.setTime(f.lastModified());
        zos.putNextEntry(ze);
        fis = new FileInputStream(f);
        byte[] buffer = new byte[256];
        int read = 0;
        while((read=fis.read(buffer))!=-1)
        {
          zos.write(buffer,0,read);
        }                        
        zos.closeEntry();
      }
      catch(Exception e)
      {
        throw e;
      }
      finally
      {  
        if(fis!=null) fis.close();
      }        
    }
  }  
  
  
  public static byte[] getFileContent(File file) throws Exception
  {  
   synchronized( FileUtils.getLockForFileAccess() )
   {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    FileInputStream fis = null;
    try
    {
      fis = new FileInputStream(file);
      byte[] buf = new byte[256];
      int read = -1;
      while((read=fis.read(buf))!=-1)
      {
         baos.write(buf,0,read);
      }
      baos.flush();
      baos.close();
      return baos.toByteArray();
    }
    catch(Exception e)
    {
      throw e;
    }
    finally
    {
     if(fis!=null) fis.close();
    }
   }
  }


  public static void saveToFile(byte[] cont, File file) throws Exception
  {
   synchronized( FileUtils.getLockForFileAccess() )                                                                                                   
   {
    FileOutputStream fos = null;
    try
    {
      fos = new FileOutputStream(file);
      fos.write(cont);
    }
    catch(Exception e)
    {
      throw e;
    }
    finally
    {
     if(fos!=null) fos.close();
    }
   }
  }
  
  
  public static long getSizeIncludingSubFiles(File root)
  {
    if(root.isFile()) return root.length();
    
    Vector<File> all = new Vector<File>();
    getAllFilesRecurse(root, all);

    long tot = 0;
    for(File f: all)
    {
      tot += f.length();
    }
    return tot;

  }
  
  public static void getAllFilesRecurse(File root, Vector<File> allFiles)
  {   
   synchronized( FileUtils.getLockForFileAccess() )
   {
     for(File fi: root.listFiles())
     {
       if(fi.isDirectory())
       {
          getAllFilesRecurse(fi, allFiles);
       }
       else
       {
          allFiles.addElement(fi);
       }
     }
   }                    
  } 
  
  
  public static int getNumerOfFiles(File root)
  {
     int count = 0;
     for(File f: root.listFiles())
     {
       if(f.isDirectory()) count += getNumerOfFiles(f);
       else if(f.isFile())
       {
         count++;
       }
     }
     return count;
  }      

} // FileUtils
