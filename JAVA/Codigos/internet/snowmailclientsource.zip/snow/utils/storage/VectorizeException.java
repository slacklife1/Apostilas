package snow.utils.storage;


public final class VectorizeException extends Exception {
    
    public VectorizeException(String mess) {
        super(mess);
    }
    
}
