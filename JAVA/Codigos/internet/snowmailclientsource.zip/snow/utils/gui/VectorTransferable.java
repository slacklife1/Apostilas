package snow.utils.gui;
                                            
import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.datatransfer.*;
import java.awt.dnd.*;
import javax.swing.*;

/** a transferable java Vector object. Useful in DnD operations.                           
*/
public class VectorTransferable implements Transferable
{
                       
    public static DataFlavor localVectorFlavor, serialVectorFlavor;
    public static String localVectorType = DataFlavor.javaJVMLocalObjectMimeType +  ";class=java.util.Vector";


    static
    {
        try {
            localVectorFlavor = new DataFlavor(localVectorType);
        } catch (ClassNotFoundException e) {
            System.out.println(
             "VectorTransferable: unable to create data flavor");
        }
        serialVectorFlavor = new DataFlavor(Vector.class, "Vector");

    }
            
    // transferred data
    public Vector v;
    public DataFlavor transferedDataFlavor;


    public VectorTransferable(Vector v)
    {
        this.v = v;
    }

    public Object getTransferData(DataFlavor flavor)
                             throws UnsupportedFlavorException {
        if (!isDataFlavorSupported(flavor)) 
        {
            throw new UnsupportedFlavorException(flavor);
        }

        // this allow transferring to a text area or to the native system !
        if( flavor.equals( DataFlavor.stringFlavor ))
        {
          transferedDataFlavor = DataFlavor.stringFlavor;
          return ""+v;
        }

        transferedDataFlavor = flavor;
        return v;
    }

    public DataFlavor[] getTransferDataFlavors() {
        return new DataFlavor[] { localVectorFlavor,
                                  serialVectorFlavor, 
                                  DataFlavor.stringFlavor
                                };
    }                  

    public boolean isDataFlavorSupported(DataFlavor flavor) {
        if (localVectorFlavor.equals(flavor)) return true;
        if (serialVectorFlavor.equals(flavor)) return true;
        if (DataFlavor.stringFlavor.equals(flavor)) return true;
        return false;
    }
        
        
  public static void main( String[] arguments )
  {              
//     DnDTest dt = new DnDTest();
  } // main
        

} // VectorTransferable
