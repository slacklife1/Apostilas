package snow.utils.gui;
              


 /**
  *   A JLabel, which has the same foreground color like a textfield,
  *   and which has a background color, which is the average
  *   of Label.background and TextField.background.
  *
  *   This means a better contrast, but still a small visual difference
  *   between TextFields and JContrastLabels, ..depending on the set theme.
  */

import java.awt.*;
import javax.swing.*;


public class JContrastLabel extends JLabel
{


  private boolean readyForSpecialUpdates = false;
  // Needed, as some updateUI() calls are too early
  // for the special UI updates, cause some components
  // could not be existing yet.


  public JContrastLabel(String text, Icon icon, int horizontalAlignment)
  {
    super(text,icon,horizontalAlignment);
    EventQueue.invokeLater( new Runnable()
     {
        public void run()
        {
          readyForSpecialUpdates = true;
        }
     });
    this.updateSpecialUI();
  }

  public JContrastLabel(String text, int horizontalAlignment)
  {
    super(text, null, horizontalAlignment);
    EventQueue.invokeLater( new Runnable()
     {
        public void run()
        {
          readyForSpecialUpdates = true;
        }
     });
    this.updateSpecialUI();
  }

  public JContrastLabel(String text)
  {
    super(text, null, LEADING);
    EventQueue.invokeLater( new Runnable()
     {
        public void run()
        {
          readyForSpecialUpdates = true;
        }
     });
    this.updateSpecialUI();
  }

  public JContrastLabel(Icon image, int horizontalAlignment)
  {
    super(null, image, horizontalAlignment);
    EventQueue.invokeLater( new Runnable()
     {
        public void run()
        {
          readyForSpecialUpdates = true;
        }
     });
    this.updateSpecialUI();
  }

  public JContrastLabel(Icon image)
  {
    super(null, image, CENTER);
    EventQueue.invokeLater( new Runnable()
     {
        public void run()
        {
          readyForSpecialUpdates = true;
        }
     });
    this.updateSpecialUI();
  }

  public JContrastLabel()
  {
    super("", null, LEADING);
    EventQueue.invokeLater( new Runnable()
     {
        public void run()
        {
          readyForSpecialUpdates = true;
        }
     });
    this.updateSpecialUI();
  }



  public void updateUI()
  {
    super.updateUI();
    if( readyForSpecialUpdates )
     {
       this.updateSpecialUI();
     }
  }



  public void updateSpecialUI()
  {
    this.setForeground( UIManager.getColor("TextField.foreground"));
    final Color bg1 = UIManager.getColor("TextField.background");
    final Color bg2 = UIManager.getColor("Label.background");
    final int r = (bg1.getRed() + bg2.getRed())/2;
    final int g = (bg1.getGreen() + bg2.getGreen())/2;
    final int b = (bg1.getBlue() + bg2.getBlue())/2;
    this.setBackground( new Color(r,g,b) );
  }



} // JContrastLabel
