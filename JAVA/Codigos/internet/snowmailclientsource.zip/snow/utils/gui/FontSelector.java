package snow.utils.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;


public class FontSelector extends JDialog
{

    private static Font DefaultFont = new Font("Dialog",Font.PLAIN,12);
    private static FontSelector dialog;
    private static String NameValue;
    private static int StyleValue;
    private static int SizeValue;
    private static String SaveNameValue;
    private static int SaveStyleValue;
    private static int SaveSizeValue;
    private static boolean FontChosen = false;


    private JList theFontNamesList;
    private JTextField SizeField;
    private JList styleList;
    private JCheckBox fontBold, fontItalic;
    private JLabel sampleTextLabel;
    private Container contentPane;
    final JSenseButton cancelButton = new JSenseButton("Cancel");
    final JSenseButton setButton = new JSenseButton("Set");





    private FontSelector(  Frame    frame,
                           String[] fontNames,
                           String   title )
    {
        super(frame, title, true);

        // Button Listeners :

        cancelButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                FontChosen = false;
                FontSelector.dialog.setVisible(false);
            }
        });

        setButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                // put the 3 font parms to the outer static parms :
                Object[] selected = theFontNamesList.getSelectedValues();
                if ( (selected != null) && (selected.length > 0) )
                {
                  boolean valid = true;
                  NameValue = selected[0].toString();
                  try
                  {
                    SizeValue = Integer.parseInt(SizeField.getText());
                    if ( (SizeValue > 0) && (SizeValue < 65) )
                    {
                      StyleValue = (fontBold.isSelected() ? Font.BOLD : 0) +
                                   (fontItalic.isSelected() ? Font.ITALIC : 0);
                      // and exit
                      FontChosen = true;
                      FontSelector.dialog.setVisible(false);
                    }
                    else
                    {
                      valid = false;
                    }
                  }
                  catch (Exception ex)
                  {
                    valid = false;
                  }
                  if (!valid)
                  {
                    JOptionPane.showMessageDialog(FontSelector.this, "Please enter valid values.", "Invalid Value", JOptionPane.INFORMATION_MESSAGE);
                    SizeField.requestFocus();
                    SizeField.selectAll();
                  }
                }
            }
        });
        getRootPane().setDefaultButton(setButton);


        // make the font face JList :
        theFontNamesList = new JList(fontNames);
        theFontNamesList.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);

        // look for the initial fontname and select it, if found :
        this.theFontNamesList.setSelectedValue(NameValue,true);

        theFontNamesList.addListSelectionListener( new MyNameListSelectionListener());
        JScrollPane listScroller = new JScrollPane(theFontNamesList);


        // set the size :
        Dimension listDim = new Dimension( SizeValue * 30, SizeValue * 10 );
        listScroller.setPreferredSize(listDim);
        listScroller.setMinimumSize(listDim);
        listScroller.setMaximumSize(listDim);

        //Create a container so that we can add a title around
        //the scroll pane.  Can't add a title directly to the
        //scroll pane because its background would be white.
        //Lay out the label and scroll pane from top to button.
        JPanel listPane = new JPanel();
        listPane.setLayout(new BoxLayout(listPane, BoxLayout.Y_AXIS));
        listPane.add(Box.createRigidArea(new Dimension(0,5)));
        listPane.add(listScroller);
        listPane.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        // FontSize/Style entry :

        Integer theValue = new Integer(SizeValue);
        SizeField = new JTextField(theValue.toString(), 4);
        SizeField.setHorizontalAlignment(SwingConstants.RIGHT);

        fontBold = new JCheckBox("Bold");
        if( (StyleValue & Font.BOLD) > 0)
         {
          fontBold.setSelected(true);
         } else
         {
          fontBold.setSelected(false);
         }

        fontItalic = new JCheckBox("Italic");
        if( (StyleValue & Font.ITALIC) > 0)
         {
          fontItalic.setSelected(true);
         } else
         {
          fontItalic.setSelected(false);
         }

        // define an actionlistener for all font change
        // events  triggered by the size field :
        ActionListener fontActionListener = new ActionListener()
        {
            public void actionPerformed(ActionEvent evt)
            {
              Object[] selected = theFontNamesList.getSelectedValues();
              if ( (selected != null) && (selected.length > 0) )
              {
                boolean valid = true;
                NameValue = selected[0].toString();
                try
                {
                  SizeValue = Integer.parseInt(SizeField.getText());

                  if ( (SizeValue > 0) && (SizeValue < 65) )
                  {
                    StyleValue = (fontBold.isSelected() ? Font.BOLD : 0) +
                                 (fontItalic.isSelected() ? Font.ITALIC : 0);
                    Font selectedFont = new Font(NameValue,StyleValue,SizeValue);
                    sampleTextLabel.setFont(selectedFont);
                    dialog.pack();
                    dialog.repaint();
                    sampleTextLabel.repaint();
                  }
                  else
                  {
                    valid = false;
                  }
                }
                catch (Exception ex)
                {
                  valid = false;
                }
                if (!valid)
                {
                  JOptionPane.showMessageDialog(FontSelector.this, "Please enter valid values.", "Invalid Value", JOptionPane.INFORMATION_MESSAGE);
                  SizeField.requestFocus();
                  SizeField.selectAll();
                }
              }
            }
        };
        SizeField.addActionListener(fontActionListener);
        fontBold.addActionListener(fontActionListener);
        fontItalic.addActionListener(fontActionListener);

        JPanel stylePane = new JPanel();
        stylePane.setLayout(new FlowLayout(FlowLayout.CENTER,20,20));
        JLabel txtlabel = new JLabel(" Font Size : ",JLabel.CENTER);
        txtlabel.setFont( new Font(NameValue,StyleValue,SizeValue) );
        txtlabel.setForeground(Color.black);
        stylePane.add(txtlabel);
        stylePane.add(SizeField);
        stylePane.add(fontBold);
        stylePane.add(fontItalic);

        // Cancel and Set Buttons :

        JPanel buttonPane = new JPanel();
        buttonPane.add(cancelButton);
        buttonPane.add(setButton);


        // sample text
        JPanel samplePane = new JPanel();
        samplePane.setLayout(new FlowLayout(FlowLayout.CENTER,10,10));
        sampleTextLabel = new JLabel("This is a sample text.",JLabel.CENTER);
        sampleTextLabel.setFont( new Font(NameValue,StyleValue,SizeValue) );
        sampleTextLabel.setForeground(Color.black);
        samplePane.add(sampleTextLabel);


        JPanel bottomPane = new JPanel();
        bottomPane.setLayout(new BorderLayout(5,5));
        bottomPane.add(samplePane,BorderLayout.NORTH );
        bottomPane.add(buttonPane,BorderLayout.SOUTH );


        this.getContentPane().setLayout(new BorderLayout(5,5));

        //Put everything together, using the content pane's BorderLayout.
        contentPane = getContentPane();
        contentPane.add(listPane   ,BorderLayout.NORTH );
        contentPane.add(stylePane  ,BorderLayout.CENTER);
        contentPane.add(bottomPane ,BorderLayout.SOUTH );

        pack();
    }


        class MyNameListSelectionListener implements ListSelectionListener
        {
         public void valueChanged(ListSelectionEvent evt)
          {
           if( !evt.getValueIsAdjusting())
           {
            JList thisList = (JList)evt.getSource();
            Object[] selected = thisList.getSelectedValues();

            if ( (selected != null) && (selected.length > 0) )
            {
              try
              {
                FontSelector.NameValue = selected[0].toString();
                FontSelector.SizeValue = Integer.parseInt(SizeField.getText());
                FontSelector.StyleValue = (fontBold.isSelected() ? Font.BOLD : 0) +
                                          (fontItalic.isSelected() ? Font.ITALIC : 0);

                Font selectedFont = new Font(NameValue,StyleValue,SizeValue);
                sampleTextLabel.setFont(selectedFont);
                dialog.pack();
                dialog.repaint();
                sampleTextLabel.repaint();
              }
              catch (Exception ex) {}
            }
           }
          }
        }



    public static Font showDialog(Component comp)
    {
        if (dialog != null)
        {
          dialog.setLocationRelativeTo(comp);
          int selIndex = dialog.theFontNamesList.getSelectedIndex();
          if( selIndex >= 0 )
           {
            Rectangle selRect = dialog.theFontNamesList.getCellBounds(selIndex,selIndex);
            dialog.theFontNamesList.scrollRectToVisible( selRect );
           }
          dialog.setVisible(true);
        } else
        {
            System.out.println("ListDialog requires you to call initialize "
                               + "before calling showDialog.");
        }
        if (FontChosen)
        {
          return new Font(NameValue,StyleValue,SizeValue);
        } else
        {
          return new Font(SaveNameValue,SaveStyleValue,SaveSizeValue);
        }
    }





    public static Font ChooseFont(Component parentFrame)
    // version with no passed default font, no buttonColor
    {
      return FontSelector.ChooseFont(parentFrame,DefaultFont);
    }



    public static Font ChooseFont( Component parentFrame,
                                   Font   defaultFont  )
    // version with passed defaultfont
    {
      DefaultFont = defaultFont; // used, if the cancelbutton is pressed
      NameValue  = DefaultFont.getName();  // static
      SizeValue  = DefaultFont.getSize();  // static
      if( SizeValue <   6 ) { SizeValue =   6; }
      if( SizeValue > 100 ) { SizeValue = 100; }
      StyleValue = DefaultFont.getStyle(); // static
      // backup, case cancel is pressed :
      SaveNameValue  = NameValue;  // static
      SaveSizeValue  = SizeValue;  // static
      SaveStyleValue = StyleValue; // static
      String[] fontNames = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
      Frame frame = JOptionPane.getFrameForComponent(parentFrame);
      dialog = new FontSelector( frame,
                                 fontNames,
                                 "Choose a Font");
      return FontSelector.showDialog(parentFrame);
    }


}
