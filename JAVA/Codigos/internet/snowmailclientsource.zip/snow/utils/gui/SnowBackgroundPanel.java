package snow.utils.gui;

import java.util.*;
import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;


public class SnowBackgroundPanel extends JPanel
{
  final SnowIcon snowIcon = new SnowIcon(55,55);  //not 1
  int numberOfFlocks = 5;
  double[] posX, posY, sizes;
  
  public boolean highContrast = false;
                  
                  

  public SnowBackgroundPanel()
  {
     this(new BorderLayout());
  } // Constructor

  public SnowBackgroundPanel(LayoutManager lm)
  {
     super(lm);
  } // Constructor
               
               
  // indicate for which width the flocks were computed
  int widthForFlocks = 0;

  private void createFlocksPositions()
  {                          
     posX = new double[numberOfFlocks];
     posY = new double[numberOfFlocks];
     sizes = new double[numberOfFlocks];
     widthForFlocks = this.getWidth();
                                       
     for(int i=0; i<this.numberOfFlocks; i++)
     {
       sizes[i] = Math.random() * Math.max(widthForFlocks, getHeight())/3.7+0.01;

       posX[i] = Math.random()*widthForFlocks-sizes[i]/2;
       posY[i] = Math.random()*getHeight()-sizes[i]/2;
     }

  }
  
  long calls = 0;

  /** call to shift flocks on y
    call this in the EDT !!
  */
  private void letSnowFall()
  { 
    if(!SwingUtilities.isEventDispatchThread())
    {  
      throw new RuntimeException("Must be called in the EDT");
    }
    calls++;
    
    widthForFlocks = this.getWidth();
    if(widthForFlocks != this.getWidth() || posX==null)
    {
       createFlocksPositions();
    }
    // so we're sure that the flocks are made
               
    for(int i=0; i<this.numberOfFlocks; i++)
    {
                          
       posX[i] += widthForFlocks*0.0008*Math.random();
       posY[i] += widthForFlocks*0.0009*Math.random();

       if(calls%500>250)
       {
         sizes[i] += (Math.random())*widthForFlocks/480.0;
       }
       else
       {
         sizes[i] -= (Math.random())*widthForFlocks/480.0;
       }                                    
                               
       if(sizes[i]<widthForFlocks/100)
       {
         sizes[i] = widthForFlocks/100;
       }                             
       
       if(sizes[i]>widthForFlocks/2)
       {
         sizes[i] = widthForFlocks/2;
       }


       if((posX[i]-sizes[i])>widthForFlocks)
       {
         posX[i] = -sizes[i];
       }

       if((posY[i]-sizes[i])>this.getHeight())
       {
         posY[i] = -sizes[i];
       }

    }


  }



 /**
  *  Overwritten paint method to have a slight color gradient.
  */
  public void paint( Graphics g )
  {  
    // cool animation when the mouse drag, ...
    // letSnowFall();   // not nice in transp trees and tables
                                 
    Graphics2D graphics2D = (Graphics2D)g;
    final Paint savePaint = graphics2D.getPaint();

    int width = getWidth();
    int height = getHeight();

    if(width==0) width=1;
    if(height==0) height=1;

    int max = (int) Math.max(width,height);

    Color bgColor = UIManager.getColor("Panel.background");
    Color destColor = null;

    if(this.highContrast)
    {
      destColor = SnowBackgroundPanel.CreateMediumLighterOrDarkerColor(bgColor);
    }
    else
    {
      destColor = SnowBackgroundPanel.CreateSmallLighterOrDarkerColor(bgColor);
    }

    GradientPaint upperLeftGradientPaint =
                    new GradientPaint( 0f,0f,
                                       bgColor,
                                       (float)max*3.2f, (float)max*3.2f,
                                       destColor);
    graphics2D.setPaint( upperLeftGradientPaint );
                              
    graphics2D.fill( graphics2D.getClip() );

    if(widthForFlocks != this.getWidth())
    {
       createFlocksPositions();
    }

    if(posX!=null)
    {
      for(int i=0; i<posX.length; i++)
      {
         snowIcon.paintSnowFlake(graphics2D, bgColor, destColor, posX[i], posY[i], sizes[i]);
      }
    }


    graphics2D.setPaint( savePaint );
    super.paintChildren(graphics2D);      
  } // paint




 /**
  *  Overwitten, so it doesnt clear all, but
  *  one has to call super, so children are properly rendered.
  */
  public void update( Graphics g )
  {
   //super.update(g);
   paint(g);
  }                        

  Animator animator = null;
  

  /** important: CALL stopAnimation() when you're disposing this... 
  */
  public void startAnimation()
  {
    if(animator==null)
    {
      animator = new Animator();
      animator.setPriority(Thread.MIN_PRIORITY);
      animator.start();
    }
  }

  public void stopAnimation()
  {
    if(animator!=null)
    {
      animator.stop = true;
      animator = null;
    }  
  }

  class Animator extends Thread
  { 
    public boolean stop;
    public void run()       
    {
      while(!stop)
      {
         try
         {
           Thread.sleep(150);
         }          
         catch(Exception e) {}

         EventQueue.invokeLater(new Runnable()
         {
            public void run()
            {
               letSnowFall();
               repaint();
            }
         });
      }
    }
  }
                   
                   
  public static Color CreateSmallLighterOrDarkerColor(Color bgColor)
  {
    int r = bgColor.getRed();
    int g = bgColor.getGreen();
    int b = bgColor.getBlue();

    if(r>245&&g>245&&b>245)
    {
      r -=20;
      g -=20;
      b -=15;     // keep blue
    }
    else
    {
      r +=15;
      g +=15;
      b +=20;     // give blue
    }                        
    if(r>255) r=255;
    if(g>255) g=255;
    if(b>255) b=255;

    if(r<0) r=0;
    if(g<0) g=0;
    if(b<0) b=0;

    return  new Color(r,g,b);
  }
  
  public static Color CreateMediumLighterOrDarkerColor(Color bgColor)
  {
    int r = bgColor.getRed();
    int g = bgColor.getGreen();
    int b = bgColor.getBlue();

    if(r>225&&g>225&&b>225)
    {
      r -=50;
      g -=50;
      b -=25;     // keep blue
    }
    else
    {
      r +=50;
      g +=50;
      b +=25;     // give blue
    }
    if(r>255) r=255;
    if(g>255) g=255;
    if(b>255) b=255;

    if(r<0) r=0;
    if(g<0) g=0;
    if(b<0) b=0;

    return  new Color(r,g,b);
  }                            
                   

  public static void main(String[] aa)
  {
    JFrame frame = new JFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.getContentPane().setLayout(new BorderLayout());
    SnowBackgroundPanel snowBack = new SnowBackgroundPanel();
    frame.getContentPane().add(snowBack, BorderLayout.CENTER);
    frame.setSize(200,200);
    frame.setVisible(true);

    snowBack.startAnimation();

  }


} // SnowBackgroundPanel
