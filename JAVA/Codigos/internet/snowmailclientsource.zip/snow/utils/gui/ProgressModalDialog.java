package snow.utils.gui;

import snow.concurrent.*;
import snow.utils.storage.AppProperties;
import snow.utils.StringUtils;
import snow.Language.Language;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;

/** A progress dialog
   should be used from another thread
   1) construct it
   2) start()
   3)  if wasCancelled => stop process and call closeDialog()...
   4) always call closeDialog() !

   [Feb2005]: newly process stop button
*/
public class ProgressModalDialog extends JDialog                                                                       
{
  final int fontSize = UIManager.getFont("Label.font").getSize();

  SnowBackgroundPanel contentPane = new SnowBackgroundPanel(new BorderLayout());
  final JProgressBar progress     = new JProgressBar();
  final JProgressBar messageProgress = new JProgressBar();

  final JLabel progressLabel = new JLabel(Language.translate("Please wait")+"...");
  final JLabel messageProgressLabel = new JLabel(Language.translate("Message progress")+": ");

  private boolean wasCanceled = false;

  final JSenseButton cancelBT = new JSenseButton(Language.translate("Cancel"));

  private boolean autoClose;

  // used to switch off the indeterminate progressbar
  boolean firstTimeCall = true;

  boolean withSecondProgress = false;

  private Process process = null;
  
  public final Interrupter interrupter = new Interrupter();

  // duration prevision based on old results
/*  final private AppProperties iniFile;
  final private String identifier;
  final private long startTime = System.currentTimeMillis();
  final private java.util.Timer timer = new java.util.Timer("ProgressModalDialog_Timer", true);*/

  public ProgressModalDialog( JFrame owner, String title, boolean withSecondProgress)
  {
    super(owner,title,true);
/*    this.iniFile = iniFile;
    this.identifier = identifier;   */
    this.withSecondProgress = withSecondProgress;
    this.initialize();
  } // Constructor


  public ProgressModalDialog( JDialog owner, String title, boolean withSecondProgress)
  {
    super(owner,title,true);
    this.withSecondProgress = withSecondProgress;
/*    this.iniFile = iniFile;
    this.identifier = identifier;*/
    this.initialize();
  } // Constructor

  public void setShowCancel(boolean show)
  {
     this.cancelBT.setVisible(show);
  }

  public void setProgressBounds(final int max)
  {
    EventQueue.invokeLater(new Runnable()
    {
      public void run() 
      {
        progress.setMaximum(max);
      }
    });
  }




  public void incrementProgress(final int n)
  {
    EventQueue.invokeLater(new Runnable()
    {
      public void run()
      {
        progress.setIndeterminate(false);
        progress.setValue( progress.getValue() + n );
      }
    });
  }

  public void setProgressValue(final int val, final String comment)
  {
    EventQueue.invokeLater(new Runnable()
    {
      public void run()
      {
        if(firstTimeCall)
        {
           firstTimeCall = false;
           progress.setIndeterminate(false);
        }
        progress.setValue(val);
        progress.setString(comment);
      }
    });
  }     
  

  public void setProgressComment(final String comment)
  {
    EventQueue.invokeLater(new Runnable()
    {
      public void run()
      {
        if(firstTimeCall)
        {
          firstTimeCall = false;
          progress.setIndeterminate(false);
        }
        progress.setString(comment);
      }
    });
  }

  public void setCommentLabel(final String comment)
  {
    EventQueue.invokeLater(new Runnable()
    {
      public void run()
      {
        progressLabel.setText(comment);
      }
    });  
  } 
  
  /** this process will be killed if the user press cancel
  */
  public void setProcessToOptionalKill(Process p)
  {
    cancelBT.setVisible(true);
    this.process = p;
  }
                       
  public boolean wasCancelled() { return this.wasCanceled; }
  
  public void start()
  {                  
    EventQueue.invokeLater(new Runnable()
    {
      public void run()
      {
        contentPane.startAnimation();
        setVisible(true);
      }
    });
  }
  
  /** must always be called at the end !
  */
  public void closeDialog()
  {
      SwingSafeRunnable ssr = new SwingSafeRunnable(new Runnable()
      {  
        public void run()
        {
          contentPane.stopAnimation();
          setVisible(false);
          dispose();                
        }
      }, true);
      ssr.run();
  }

  private void initialize()
  {
    setContentPane(contentPane);
    
    JPanel progressPanel = new JPanel();
    progressPanel.setOpaque(false);
    progressPanel.setLayout(new BoxLayout(progressPanel, BoxLayout.Y_AXIS));
    getContentPane().add(progressPanel, BorderLayout.CENTER); 
    progressPanel.setBorder(new EmptyBorder(1,2,1,2));

    progressPanel.add(progressLabel);
    progressPanel.add(progress);
    progressPanel.add(messageProgressLabel);
    progressPanel.add(messageProgress);


    progressLabel.setBorder(new EmptyBorder(fontSize/4, fontSize/2, fontSize/4, fontSize/2));
    messageProgressLabel.setBorder(new EmptyBorder(fontSize/4, fontSize/2, fontSize/4, fontSize/2));

    progress.setOpaque(false);
    messageProgress.setOpaque(false);
    progress.setIndeterminate(true);


    JPanel controlPanel = new JPanel();
    controlPanel.setOpaque(false);
    getContentPane().add(controlPanel, BorderLayout.SOUTH);
    controlPanel.add(cancelBT);

    //cancelBT.setFont(SnowMailClientApp.smallFont);
    cancelBT.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
         //System.out.println("Destroy "+process);
         interrupter.stopEvaluation();

         if(process!=null)
         {
           wasCanceled = true;
           try
           {
             process.destroy();
             closeDialog();

           } catch(Exception ex) {ex.printStackTrace();}
         }
         wasCanceled = true;
         // now the process to be canceled must check...
      }
    });               

    progress.setStringPainted(true);
    messageProgress.setStringPainted(true);
                         
    messageProgress.setVisible(false);
    messageProgressLabel.setVisible(false);
                             
    // fixed, but fontsize relative size :
    if(withSecondProgress)
    {
      this.setSize( fontSize*28 ,fontSize*15  );
    }
    else
    {
      this.setSize( fontSize*28 ,fontSize*11  );
    }

    // center it on the frame :
    final Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
    this.setLocation(  (screen.width  - this.getWidth())/2,
                       (screen.height - this.getHeight())/2  );
  

  } // initialize


  public void setMessageProgressActive(final int max)
  {
    EventQueue.invokeLater(new Runnable()
    {
      public void run()
      {

         messageProgress.setVisible(true);
         messageProgressLabel.setVisible(true);
         messageProgress.setMaximum(max);
         messageProgress.setValue(0);

         //setSize( fontSize*28 , fontSize*16  );
      }
    });
  }

  public void setMessageProgressValue(final int val)
  {                                 
    EventQueue.invokeLater(new Runnable()
    {
      public void run()
      {
         messageProgress.setValue(val);
      }
    });
  }

  public JProgressBar getMessageProgress() { return messageProgress; }

} // ProgressModalDialog
