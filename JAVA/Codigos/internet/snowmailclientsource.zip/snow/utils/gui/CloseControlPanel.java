package snow.utils.gui;

import snow.Language.Language;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** a simple utility to add a close button in your
   dialogs or frames.
*/
public final class CloseControlPanel extends JPanel
{
  private final JSenseButton cancelBT = new JSenseButton(Language.translate("Cancel"));

  private final JSenseButton okBT = new JSenseButton(Language.translate("Close"));

  private boolean accepted = false;                    
  private boolean cancelled = false;

  public JSenseButton getOkButton() {return okBT;}


  public boolean getWasAccepted() { return accepted; }
  public boolean getWasCancelled() { return cancelled; }
  
  public boolean shouldCancelCallClose = false;

  public CloseControlPanel( final Object frame, boolean showCancel,
              boolean shouldCancelCallClose_, final String okText )
  {
    super(new FlowLayout(FlowLayout.RIGHT));
    setOpaque(false);
    this.shouldCancelCallClose = shouldCancelCallClose_;

    add(cancelBT);
    if(!showCancel) cancelBT.setVisible(false);
                     
    okBT.setText(okText);
    add(okBT);
    okBT.setBackgroundColor(Color.orange);
    //okBT.maximizeForeGroundContrastToBackground();  // IMPORTANT !!!

    okBT.addActionListener(new ActionListener()
    {
       public void actionPerformed(ActionEvent e)
       {
         accepted = true;
         cancelled = false;
         if(frame instanceof JFrame)
         {
           ((JFrame) frame).setVisible(false);
           ((JFrame) frame).dispose();
         }
         else if(frame instanceof JDialog)
         {
           ((JDialog) frame).setVisible(false);
           ((JDialog) frame).dispose();
         }
       }
    });
    cancelBT.addActionListener(new ActionListener()
    {
       public void actionPerformed(ActionEvent e)
       {
         cancelled = true;
         accepted = false;
         if(shouldCancelCallClose)
         {
           if(frame instanceof JFrame)
           {
             ((JFrame) frame).setVisible(false);
             ((JFrame) frame).dispose();
           }
           else if(frame instanceof JDialog)
           {
             ((JDialog) frame).setVisible(false);
             ((JDialog) frame).dispose();
           }
         }
       }
    });

    /*
    okBT.setPreferredSize(new Dimension(
      (int) okBT.getPreferredSize().getWidth(),
      SnowMailClientApp.fontSize*9/4
    ));
    cancelBT.setPreferredSize(new Dimension(
      (int) cancelBT.getPreferredSize().getWidth(),
      SnowMailClientApp.fontSize*9/4
    ));*/

//    SnowMailClientApp.MakeButtonNiceSize(okBT);
//    SnowMailClientApp.MakeButtonNiceSize(cancelBT);

  } // Constructor


                  
  public void _setOkButtonText(String txt)
  {     
    okBT.setText(txt);
    /*
    okBT.setPreferredSize(new Dimension(
      (int) okBT.getPreferredSize().getWidth()+5,
      SnowMailClientApp.fontSize*9/4
    ));*/
  }
  
  public void setOkEnabled(boolean is)
  {
    okBT.setEnabled(is);
  }

  public void setOkBackground(Color c)
  {
    okBT.setBackground(c);
  }

} // CloseControlPanel
