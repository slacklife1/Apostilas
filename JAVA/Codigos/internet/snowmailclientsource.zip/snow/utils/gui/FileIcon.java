package snow.utils.gui;

import javax.swing.*;
import java.awt.*;

public class FileIcon implements Icon
{
  public final static int ReadOnly = 0;
  public final static int ReadWrite = 1;
  public final static int Other = 2;

  private int type;
  private int size;
  Polygon poly;

  public FileIcon(boolean directory, int type, int size)
  {
    this.type = type;
    this.size = size;

    if(directory)
    {
      initShapeDirectory();
    }
    else
    {
      initShapeFile();
    }
  }

  private void initShapeFile()
  {
    poly = new Polygon();
    poly.addPoint(size/8, 0);
    poly.addPoint(size*7/8, 0);
    poly.addPoint(size*7/8, size);
    poly.addPoint(size/8, size);
  }

  private void initShapeDirectory()
  {
    poly = new Polygon();
    poly.addPoint(0, size/6);
    poly.addPoint((int)(size*0.5), size/6);
    poly.addPoint((int)(size*0.65), size/11);
    poly.addPoint((int)(size*0.85), size/11);
    poly.addPoint(size, size/6);
    poly.addPoint(size, size*7/8);
    poly.addPoint(0, size*7/8);
  }

  public int getIconHeight() {
    return size;
  }

  public int getIconWidth() {
    return size;
  }

  public void paintIcon(
   Component c, Graphics g, int x, int y)
  {
    Graphics2D g2 = (Graphics2D) g;

    g.translate(x, y);  
    
    Color color1 = Color.white;
    Color color2 = Color.black;

    if (type==ReadWrite)
    {
      color1 = new Color(180,255,180);
      color1 = new Color(250,255,250);
    }
    else if (type==ReadOnly)
    {
      color1 = new Color(220,180,180);
      color1 = new Color(220,0,0);
    }
    else
    {
      g.setColor(Color.orange);
      g.setColor(Color.gray);
    }
    
    g2.setPaint(new GradientPaint(0,0,color1,size,size,color2,false));
    g.fillPolygon(poly);

    // border
    g.setColor(Color.black);
    g.drawPolygon(poly);

    g.translate(-x, -y);
  }
}
 // FileIcon
