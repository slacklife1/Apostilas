package snow.utils.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.io.File;
import java.util.*;
import java.text.*;

public final class DateEditorPanel extends JPanel
{
  private Calendar selectedDate = Calendar.getInstance();

  private final int fontSize = UIManager.getFont("Label.font").getSize();
  private final DaysPanel daysPanel;
  private final MonthPanel monthPanel;
  private final YearPanel yearPanel;

  private final Font boldFont;
  private final Font smallFont;

  public DateEditorPanel(Date date)
  {
     super(new BorderLayout());
     
     smallFont = new Font("Dialog", Font.PLAIN, (int) (Math.max(fontSize-2, 9)));
     boldFont = new Font("Dialog", Font.BOLD, (int) (Math.min(fontSize+2, 12)));

     selectedDate.setTime(date);
     selectedDate.setLenient(true);  // 32 = 1 of next month, ...

     monthPanel = new MonthPanel();
     daysPanel = new DaysPanel();
     yearPanel = new YearPanel();

     add(monthPanel, BorderLayout.NORTH);
     add(daysPanel, BorderLayout.CENTER);
     add(yearPanel, BorderLayout.SOUTH);


     monthPanel.updateLabel();
     yearPanel.updateLabel();
     daysPanel.update();
  } // Constructor
  
  public Date getSelectedDate()
  {
    return this.selectedDate.getTime();
  }
      
  class DaysPanel extends JPanel
  {  
     String[] days = new String[]{"Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"};
     public DaysPanel()
     {                         
       super(new GridLayout(7,7));
       //update();
     }                                    
     
     private void setColor(int dayInWeek, JComponent c)
     {
       c.setOpaque(true);                      
       if(dayInWeek==0 || dayInWeek==6)
       {
         c.setBackground(new Color(250,200,200,255));
       }
       else
       {
         c.setBackground(new Color(186,250,181,255));
       }
     }

     public void update()
     {
       this.removeAll();
       for(int i=0; i<7; i++) 
       {
          JLabel dayLabel = new JLabel(days[i]);
          add(dayLabel);
          dayLabel.setFont(smallFont);
          dayLabel.setHorizontalAlignment(JLabel.CENTER);
          dayLabel.setBorder(null);
       }

       // compute the first day of the month
       int selectedDayOfWeek = selectedDate.get(Calendar.DAY_OF_WEEK)-1; // 0=sunday 
       int selectedDay = selectedDate.get(Calendar.DAY_OF_MONTH);      //1,2,...,31

       System.out.println("day="+selectedDay+" in week="+selectedDayOfWeek);

       int weekDayOfMonthFirst =  (7+selectedDayOfWeek - (selectedDay-1)%7) % 7;    // <7
                                                          
       int numberOfDaysInMonth = selectedDate.getActualMaximum(Calendar.DAY_OF_MONTH);
       System.out.println(""+weekDayOfMonthFirst);

       int dayInWeek = 0;
       for(int i=0; i<weekDayOfMonthFirst; i++)
       {
         JLabel lab = new JLabel("");
         setColor(dayInWeek%7, lab);
         dayInWeek++;
         add(lab);         
       }          

       for(int i=1; i<=numberOfDaysInMonth; i++)
       {  
         final int ii = i;
         JButton jb = new JButton(""+(i));  
         jb.addActionListener(new ActionListener()
         {
          public void actionPerformed(ActionEvent e)
          {
             selectedDate.set(Calendar.DAY_OF_MONTH, ii);
             update();
          }
         });
         jb.setBorder(null);
         jb.setFocusPainted(false);
         if(i==selectedDay)
         {
           jb.setFont(boldFont);
         }
         else               
         {
           jb.setFont(smallFont);
         }
         add(jb);  
         setColor(dayInWeek%7, jb);
         dayInWeek++;          
       }                                
       
       int remains = 42-numberOfDaysInMonth-weekDayOfMonthFirst;
       for(int i=0; i<remains; i++)
       {
         JLabel lab = new JLabel("");
         setColor(dayInWeek%7, lab);
         dayInWeek++; 
         add(lab); 
       }
     }
  }

  class MonthPanel extends JPanel
  {
     JSenseButton shiftUpMonthBT = new JSenseButton("   >   ");
     JSenseButton shiftDownMonthBT = new JSenseButton("   <   ");
     JLabel monthLabel = new JLabel();
     SimpleDateFormat monthFormat = new SimpleDateFormat("MMMMMMMMMM");

     public MonthPanel()
     {
        super(new BorderLayout());
        monthLabel.setAlignmentX(JLabel.CENTER_ALIGNMENT);
        monthLabel.setHorizontalAlignment(JLabel.CENTER);
        monthLabel.setFont(boldFont);

        add(shiftDownMonthBT, BorderLayout.WEST);
        add(monthLabel, BorderLayout.CENTER);
        add(shiftUpMonthBT, BorderLayout.EAST);

        shiftUpMonthBT.setBorder(null);
        shiftDownMonthBT.setBorder(null);
        
        shiftUpMonthBT.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
             selectedDate.set(Calendar.MONTH,
                selectedDate.get(Calendar.MONTH)+1 );
             updateLabel();
             yearPanel.updateLabel();
             daysPanel.update();
          }       
        });

        shiftDownMonthBT.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
             selectedDate.set(Calendar.MONTH,
                selectedDate.get(Calendar.MONTH)-1 );
             updateLabel();   
             yearPanel.updateLabel();  
             daysPanel.update();
          }
        });  

        //updateLabel();
     }

     public void updateLabel()
     {
       monthLabel.setText( monthFormat.format( selectedDate.getTime() ));
     }
  }


  class YearPanel extends JPanel
  {        
     JSenseButton shiftUpMonthBT = new JSenseButton("   >   ");
     JSenseButton shiftDownMonthBT = new JSenseButton("   <   ");
     JLabel monthLabel = new JLabel();
     SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");

     public YearPanel()
     {
        super(new BorderLayout());
        monthLabel.setAlignmentX(JLabel.CENTER_ALIGNMENT);
        monthLabel.setHorizontalAlignment(JLabel.CENTER);
        monthLabel.setFont(boldFont);
        
        add(shiftDownMonthBT, BorderLayout.WEST);
        add(monthLabel, BorderLayout.CENTER);
        add(shiftUpMonthBT, BorderLayout.EAST);
        
        shiftUpMonthBT.setBorder(null);
        shiftDownMonthBT.setBorder(null);


        shiftUpMonthBT.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
             selectedDate.set(Calendar.YEAR,
                (selectedDate.get(Calendar.YEAR)+1) );
             updateLabel();     
             daysPanel.update();
          }
        });

        shiftDownMonthBT.addActionListener(new ActionListener()
        {
          public void actionPerformed(ActionEvent e)
          {
             selectedDate.set(Calendar.YEAR,
                (selectedDate.get(Calendar.YEAR)-1) );
             updateLabel();  
             daysPanel.update();
          }
        });  

        //updateLabel();
     }

     public void updateLabel()
     {
       monthLabel.setText( yearFormat.format( selectedDate.getTime() ));
     }
  }


  public static void main(String[] a)
  {
     JFrame jf = new JFrame("test");
     jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     DateEditorPanel dv = new DateEditorPanel(new Date());
                        
     jf.getContentPane().add(dv);
     //jf.pack();
     jf.setSize(200, 250);
     jf.setVisible(true);

     //dv.setComponentWidth(60);
  }
          


} // DateEditorPanel
 
