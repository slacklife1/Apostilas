package snow.utils.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GUIUtils extends JDialog
{

  public static JPanel wrapLeft(Component c)
  {               
    JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT,0,0));
    p.setOpaque(false);
    p.add(c);
    return p;
  }  

  public static JPanel wrapRight(Component c)
  {
    JPanel p = new JPanel(new FlowLayout(FlowLayout.RIGHT,0,0));
    p.setOpaque(false);
    p.add(c);
    return p;
  }
  
  /**
    small borders especially for buttons
  */
  public static void setNarrowInsets(JComponent b)
  {
    int fs = b.getFont().getSize(); 
    if(b instanceof JButton)
    {
      ((JButton) b).setMargin(new Insets(fs/8,fs/4,fs/8,fs/4));
    }
    else if(b instanceof JToggleButton)
    {
      ((JToggleButton) b).setMargin(new Insets(fs/8,fs/4,fs/8,fs/4));
    }
    else
    {  
      //### NOT WORKING !!!
      b.getInsets().set(fs/8,fs/4,fs/8,fs/4);
    }
  }
   /*  
  public static void setMediumInsets(JButton b)
  {
    int fs = b.getFont().getSize();
    b.setMargin(new Insets(fs/8,fs/2,fs/8,fs/2));
  } */ 
  
  /** small insets + small dim.
  */
  public static void setSmallDimensions(JComponent button)
  { 
    setNarrowInsets(button);
    button.invalidate(); 
    //button.setPreferredSize(button.getPreferredSize());
    button.setPreferredSize(new Dimension(
       (int) button.getPreferredSize().getWidth(),
       button.getFont().getSize()*8/4
    ));
  }    

} // GUIUtils
