package snow.utils.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.io.*;
import java.util.*;

/** a field to edit a file name
*/
public final class FileField extends JPanel
{                           
  final private JSenseButton editPathButton = new JSenseButton("...");
  final private JTextField pathField = new JTextField("");
  final private boolean saveMode;
  final private String dialogTitle;
  final private Vector<ActionListener> actionListeners = new Vector<ActionListener>();
  final private boolean directoriesOnly;


  public FileField(String path, boolean saveMode, String dialogTitle, boolean directoriesOnly)
  {
     super();  
     GridBagLayout gridbag = new GridBagLayout();
     GridBagConstraints constr = new GridBagConstraints();
     setLayout(gridbag);      

     this.saveMode = saveMode;
     this.dialogTitle = dialogTitle;
     this.directoriesOnly = directoriesOnly;
     
     constr.weightx=1;
     constr.fill = GridBagConstraints.HORIZONTAL;
     gridbag.setConstraints(pathField, constr);
     add(pathField);
     pathField.setText(path);

     constr.weightx=0;
     constr.fill = GridBagConstraints.REMAINDER;
     gridbag.setConstraints(editPathButton, constr);
     add(editPathButton);


     Dimension dim = new Dimension(                                                               
          (int) pathField.getPreferredSize().getHeight(),
          (int) pathField.getPreferredSize().getHeight());
     
     editPathButton.setPreferredSize(dim);
     editPathButton.setMaximumSize(dim);
     editPathButton.setMinimumSize(dim);


     editPathButton.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       {
          browseFileAction();
       }
     });
     
     pathField.addActionListener(new ActionListener()
     {
       public void actionPerformed(ActionEvent e)
       {
          notifyActionListeners();
       }        
     });
        
  } // Constructor
  

  public File getPath()
  {
    return new File( pathField.getText() );
  }
  
         
  public boolean isPathValid()
  {
     if(saveMode) return true;

     File file = getPath();
     if(file.exists()) return true;
     return false;
  }
                          
  private void browseFileAction()
  {
     JFileChooser fileChooser = new JFileChooser();
     File base = getPath();
     if(base.exists())
     {
       fileChooser.setCurrentDirectory(base);
     }
     else
     {
       // try with the parent
       if(base.getParentFile()!=null)
       {
         fileChooser.setCurrentDirectory(base.getParentFile());   
       }
     }

     fileChooser.setDialogTitle(dialogTitle);
     if(directoriesOnly) 
     {
       fileChooser.setFileSelectionMode(fileChooser.DIRECTORIES_ONLY);
     }
     else
     {
       fileChooser.setFileSelectionMode(fileChooser.FILES_AND_DIRECTORIES);
     }

     FileViewWithAttributes view = new FileViewWithAttributes();
     fileChooser.setFileView(view);


     if(saveMode)
     {
        int rep = fileChooser.showSaveDialog(this);
        if(rep==JFileChooser.APPROVE_OPTION)
        {
          File file = fileChooser.getSelectedFile();
          setPath(file.getAbsolutePath());
        }
     }
     else
     {
        int rep = fileChooser.showOpenDialog(this);
        if(rep==JFileChooser.APPROVE_OPTION)
        {
          File file = fileChooser.getSelectedFile();
          setPath(file.getAbsolutePath());
        }
     }

                            
  }
  
  public void setEditable(boolean editable)
  {
     pathField.setEditable(editable);
     editPathButton.setEnabled(editable);
  }

  public void setPath(String path)
  {
     pathField.setText(path);
     notifyActionListeners();
  }

  

  public void addActionListener(ActionListener al)
  {
     actionListeners.addElement(al);
  }

  public void removeActionListener(ActionListener al)
  {
     actionListeners.removeElement(al);
  }

  private void notifyActionListeners()
  {
    for(int i=0; i<actionListeners.size(); i++)
    {
      ActionListener al = actionListeners.elementAt(i);
      al.actionPerformed(new ActionEvent(this, ActionEvent.ACTION_FIRST, "File selected"));
    }
  }   
  
  public void setComponentWidth(int width)
  {
    Dimension dim = pathField.getPreferredSize();
    dim.width = width;
    pathField.setMinimumSize(dim);
    pathField.setPreferredSize(dim);
    pathField.setMaximumSize(dim);
  }


} // FileField
