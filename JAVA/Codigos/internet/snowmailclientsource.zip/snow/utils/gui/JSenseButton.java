package snow.utils.gui;

/**
 *   Behaves completely like an ordinary V1.22 JButton,
 *   but it will signalize mouseovers by slightly
 *   changing the fore/background contrast,
 *   like one is used from the internet.
 *
 *   To support change of constructors in future swing versions
 *   just change the constructors below accordingly.
 *
 */

import java.util.EventListener;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

import javax.swing.JButton;
import javax.swing.Icon;
import javax.swing.event.*;
import javax.swing.*;
                
import java.beans.*; // property change listener

//import java.awt.event.MouseMotionListener;


public class JSenseButton extends JButton
                          implements MouseListener,MouseMotionListener
{

   Color saveBackGround = null; // cache for original background color,
                                // on mouseovers
   Color saveForeGround = null; // cache for original background color,
                                // on mouseovers
   private boolean isSelected = false;
                      
   private ColorChangeThread colorChangeThread = null;
   public JSenseButton thisButton;

   private boolean doAnimate = true;



  /**
   * Creates a button with no set text or icon.
   */
  public JSenseButton()
  {
   super(null, null);
   this.thisButton = this;
   this.addMouseListener(this);
   this.addMouseMotionListener(this);
   install();
  }





  /**
   * Creates a button with an icon.
   *
   * @param icon  the Icon image to display on the button
   */
  public JSenseButton(Icon icon)
  {
   super(null, icon);
   this.addMouseListener(this);
   this.addMouseMotionListener(this);
   install();
  }




  /**
   * Creates a button with text.
   *
   * @param text  the text of the button
   */
  public JSenseButton(String text)
  {
   super(text, null);
   this.addMouseListener(this);
   this.addMouseMotionListener(this);
   install();
  }

  public JSenseButton(Action a)
  {
   super(a);
   this.addMouseListener(this);
   this.addMouseMotionListener(this);
   install();
  }

  public JSenseButton(String text, boolean doAnimate)
  {
   super(text, null);
   this.doAnimate = doAnimate;
   this.addMouseListener(this);
   this.addMouseMotionListener(this);
   install();
  }



  /**
   * Creates a button with initial text and an icon.
   *
   * @param text  the text of the button.
   * @param icon  the Icon image to display on the button
   */
  public JSenseButton(String text, Icon icon )
  {
   super(text,icon);
   this.addMouseListener(this);
   this.addMouseMotionListener(this);         
   install();
  }

  public JSenseButton(String text, Icon icon, boolean doAnimate)
  {
   super(text,icon);
   this.doAnimate = doAnimate;
   this.addMouseListener(this);
   this.addMouseMotionListener(this);         
   install();
  }
                     
  /** Changes foreground to ensure good contrast 
  */
  public void setBackgroundColor(Color c)
  {
    setBackground(c);
    this.maximizeForeGroundContrastToBackground();
  }


  private void install()
  {
   //no sense here ! maximizeForeGroundContrastToBackground();
   
   this.setFocusPainted(false);  // not nice !
   addPropertyChangeListener(
     new PropertyChangeListener()
     {
        public void propertyChange(PropertyChangeEvent e)
        {
            String name = e.getPropertyName();
            if (name.equals("UI"))
             {
               SwingUtilities.invokeLater( new Runnable()
                {
                   public void run()
                   {
                     maximizeForeGroundContrastToBackground();
                   }
                });
             }
        /*    else
            {
              System.out.println(">"+name);
            }*/
        }
     });
  }
  
/**
 *  Sets the foreground color so that it has
 *  a good contrast to the background color.
 */
 public void maximizeForeGroundContrastToBackground()
 {
   // Set it white or black, depending from background
   // grayscale average :
   int grayScaleAverage = ( this.getBackground().getRed() +
                            this.getBackground().getGreen() +
                            this.getBackground().getBlue() ) / 3;
   if( grayScaleAverage > 127 )
    {
      this.setForeground( new Color(0,0,0) );
    }
   else
    {
      this.setForeground( new Color(255,255,255) );
    }
 }         

  /**
   * enables/disables the JSense effect
   */
  public void enableJSenseEffect( boolean enable )
  {
    if (enable)
    {
      this.addMouseListener(this);
      this.addMouseMotionListener(this);
    }
    else
    {
      this.removeMouseListener(this);
      this.removeMouseMotionListener(this);
    }
  }                                           




 public void mouseEntered( MouseEvent e )
 {
  if( ( !isSelected ) && ( this.isVisible() ) && ( this.isEnabled() ) )
   {
     isSelected = true;
     saveForeGround = this.getForeground();
     saveBackGround = this.getBackground();
     int foreGroundGrayScale = saveForeGround.getRed() +
                               saveForeGround.getGreen() +
                               saveForeGround.getBlue() ;
     int backGroundGrayScale = saveBackGround.getRed() +
                               saveBackGround.getGreen() +
                               saveBackGround.getBlue() ;
     final int ColorDelta = 20;
     if( foreGroundGrayScale < backGroundGrayScale )
      {
        // we have dark text on light bg. Enlarger contrast :
        int newRed;
        newRed = saveBackGround.getRed() + ColorDelta;
        if(newRed > 255) { newRed = 255; }
        int newGreen;
        newGreen = saveBackGround.getGreen() + ColorDelta;
        if(newGreen > 255) { newGreen = 255; }
        int newBlue;
        newBlue = saveBackGround.getBlue() + ColorDelta;
        if(newBlue > 255) { newBlue = 255; }

        if( this.doAnimate )
        {
          if( this.colorChangeThread == null )
           {
            colorChangeThread = new ColorChangeThread(thisButton);
            colorChangeThread.setStartColor( getBackground() );
            colorChangeThread.setTargetColor( new Color(newRed,newGreen,newBlue) );
            colorChangeThread.start();
           }
        }
        else
        {
          this.setSuperBackground( new Color(newRed,newGreen,newBlue) );
        }
      } 
      else
      {
        // we have light text on dark bg. Enlarger contrast :
        int newRed;
        newRed = saveBackGround.getRed() - ColorDelta;
        if(newRed < 0 ) { newRed = 0; }
        int newGreen;
        newGreen = saveBackGround.getGreen() - ColorDelta;
        if(newGreen < 0 ) { newGreen = 0; }
        int newBlue;
        newBlue = saveBackGround.getBlue() - ColorDelta;
        if(newBlue < 0 ) { newBlue = 0; }
        if( this.doAnimate )
         {
          if( this.colorChangeThread == null )
           {
            colorChangeThread = new ColorChangeThread(thisButton);
            colorChangeThread.setStartColor( getBackground() );
            colorChangeThread.setTargetColor( new Color(newRed,newGreen,newBlue) );
            colorChangeThread.start();
           }
         } else
         {
           this.setSuperBackground( new Color(newRed,newGreen,newBlue) );
         }
      }
   } // if
 } // mouseEntered



 public void mouseExited( MouseEvent e )
 {
   if( this.isVisible() )
    {
     if( this.colorChangeThread != null )
      {
        this.colorChangeThread.doTerminate();
        this.colorChangeThread = null;
      }
     // reset original colors :
     if( saveBackGround != null) { super.setBackground(saveBackGround); }
     isSelected = false;
    }
 } // mouseExited



 public void mouseReleased( MouseEvent e )
 {
 }
 public void mousePressed( MouseEvent e )
 {
 }
 public void mouseClicked( MouseEvent e )
 {
 }
 public void mouseMoved( MouseEvent e )
 {
 }
 public void mouseDragged( MouseEvent e )
 {
 }

  

/**
 *   Used from the ColorChangeThread for setting
 *   the background using the super method.
 */
 public void setSuperBackground( Color bgColor )
 {
   super.setBackground(bgColor);
 }


 /**
  *  This thread performs the animated color change.
  */
  private class ColorChangeThread extends Thread
  {
     //private final JSenseButton parentButton;
     private Color startColor  = new Color(160,160,160);
     private Color targetColor = new Color(100,100,100);
     private boolean terminateThread = false;

     public ColorChangeThread( JSenseButton theButton )
     {
       //this.parentButton = theButton;
       this.setDaemon(true);
       // Give other threads more attention:
       this.setPriority( Thread.MIN_PRIORITY );
     }

     public void run()
     {
       try{ Thread.sleep(11); } catch(Exception wurscht00 ){}
       final int loops = 5;
       final float deltaRed   = 1f * (this.targetColor.getRed()   - this.startColor.getRed()   )/loops;
       final float deltaGreen = 1f * (this.targetColor.getGreen() - this.startColor.getGreen() )/loops;
       final float deltaBlue  = 1f * (this.targetColor.getBlue()  - this.startColor.getBlue()  )/loops;
       for( int i=1; i <= loops; i++ )
        {
           try{ Thread.sleep(49); } catch(Exception wurscht ){}
           final int iStep = i;
           EventQueue.invokeLater( new Runnable()
            {
              public void run()
              {
                if( !terminateThread )
                 {
                    int cRed   = (int)(startColor.getRed()   + iStep * deltaRed   );
                    int cGreen = (int)(startColor.getGreen() + iStep * deltaGreen );
                    int cBlue  = (int)(startColor.getBlue()  + iStep * deltaBlue  );
                    setSuperBackground(  new Color(cRed,cGreen,cBlue) );
                 }
              }
            });
           try{ Thread.yield(); } catch(Exception wurscht ){}
        }
     } // run



     public void setStartColor( final Color theStartColor )
     {
       this.startColor = theStartColor;
     }


     public void setTargetColor( final Color theTargetColor )
     {
       this.targetColor = theTargetColor;
     }


     public void doTerminate()
     {
       this.terminateThread = true;
     }

  } // class ColorChangeThread





} // JSenseButton






