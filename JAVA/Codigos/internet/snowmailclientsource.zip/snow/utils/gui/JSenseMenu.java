package snow.utils.gui;

/**
  *   Behaves completely like an ordinary V1.22 JMenu,
  *   but it will signalize mouseovers by slightly
  *   changing the fore/background contrast,
  *   like one is used from the internet.
  *
  *   To support change of constructors in future swing versions
  *   just change the constructors below accordingly.
  */

import java.util.EventListener;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

import javax.swing.JMenu;
import javax.swing.Icon;
import javax.swing.JInternalFrame;
import javax.swing.SwingUtilities;



public class JSenseMenu extends JMenu
                        implements MouseListener,MouseMotionListener
{

   Color saveBackGround = null; // cache for original background color,
                                // on mouseovers
   Color saveForeGround = null; // cache for original background color,
                                // on mouseovers
   private boolean isSelected = false;


  /**
   * Creates a new JMenu with no text.
4   */
  public JSenseMenu()
  {
   super("");
   this.addMouseListener(this);
   this.addMouseMotionListener(this);
   installFocusListener();
  }



  /**
   * Creates a new JMenu with the supplied string as its text
   *
   * @param s  The text for the menu label
   */
  public JSenseMenu(String s)
  {
   super(s);
   this.addMouseListener(this);
   this.addMouseMotionListener(this);
   installFocusListener();
  }


  /**
   * Creates a new JMenu with the supplied string as its text
   * and specified as a tear-off menu or not.
   *
   * @param s The text for the menu label
   * @param b can the menu be torn off (not yet implemented)
   */
  public JSenseMenu(String s, boolean b)
  {
   super(s);
   this.addMouseListener(this);
   this.addMouseMotionListener(this);
   installFocusListener();
  }



  /** install the focus Listener
  */
  private void installFocusListener()
  {
    final JSenseMenu thisMenu = this;
    /*
    addFocusListener
    (
       new  FocusAdapter()
       {
           @Override public void focusGained(FocusEvent e)
           {
           }


           @Override public void focusLost(FocusEvent e)
           {
             //getPopupMenu().setVisible(false);
             //setNextFocusableComponent(null);
           }

       }
    );*/
  }



 public void mouseEntered( MouseEvent e )
 {
  if( ( !isSelected ) && ( this.isVisible() ) )
   {
     // this line was inserted, because the menu always gave the focus
     // back to the component lastly having focus.
     // So if the menu gets focus only by roll over the problem is solved.
     // So this line is kind of work-around and can be "weggemacht" on demand.
     this.getParent().requestFocus();


     isSelected = true;
     saveForeGround = this.getForeground();
     saveBackGround = this.getBackground();
     int foreGroundGrayScale = saveForeGround.getRed() +
                               saveForeGround.getGreen() +
                               saveForeGround.getBlue() ;
     int backGroundGrayScale = saveBackGround.getRed() +
                               saveBackGround.getGreen() +
                               saveBackGround.getBlue() ;
     final int ColorDelta = 20;
     if( foreGroundGrayScale < backGroundGrayScale )
      {
        // we have dark text on light bg. Enlarger contrast :
        int newRed;
        newRed = saveBackGround.getRed() + ColorDelta;
        if(newRed > 255) { newRed = 255; }
        int newGreen;
        newGreen = saveBackGround.getGreen() + ColorDelta;
        if(newGreen > 255) { newGreen = 255; }
        int newBlue;
        newBlue = saveBackGround.getBlue() + ColorDelta;
        if(newBlue > 255) { newBlue = 255; }
        this.setBackground( new Color(newRed,newGreen,newBlue));
      } else
      {
        // we have light text on dark bg. Enlarger contrast :
        int newRed;
        newRed = saveBackGround.getRed() - ColorDelta;
        if(newRed < 0 ) { newRed = 0; }
        int newGreen;
        newGreen = saveBackGround.getGreen() - ColorDelta;
        if(newGreen < 0 ) { newGreen = 0; }
        int newBlue;
        newBlue = saveBackGround.getBlue() - ColorDelta;
        if(newBlue < 0 ) { newBlue = 0; }
        this.setBackground( new Color(newRed,newGreen,newBlue));
      }
   } // if
 } // mouseEntered



 public void mouseExited( MouseEvent e )
 {
   if( this.isVisible() )
    {
     // reset original colors :
     if( saveBackGround != null) { this.setBackground(saveBackGround); }
     isSelected = false;
    }
 } // mouseExited



 public void mouseReleased( MouseEvent e )
 {
 }
 public void mousePressed( MouseEvent e )
 {
 }
 public void mouseClicked( MouseEvent e )
 {
 }
 public void mouseMoved( MouseEvent e )
 {
 }
 public void mouseDragged( MouseEvent e )
 {
 }



} // JSenseButton
