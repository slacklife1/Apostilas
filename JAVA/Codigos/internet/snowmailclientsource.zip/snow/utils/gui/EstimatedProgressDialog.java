package snow.utils.gui;

import snow.utils.storage.AppProperties;
import snow.utils.StringUtils;
import snow.Language.Language;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;

/** Usage: after creation and before start, call setIndeterminate(time, false)
*/
public final class EstimatedProgressDialog extends ProgressModalDialog
{

  final private long startTime = System.currentTimeMillis();
  final private java.util.Timer timer = new java.util.Timer("ProgressModalDialog_Timer", true);

  public EstimatedProgressDialog( JFrame owner, String title)
  {
    super(owner,title,true);
    setSize(400,111);
  } // Constructor


  public EstimatedProgressDialog( JDialog owner, String title)
  {
    super(owner,title,true);
    setSize(400,111);
  } // Constructor


  /** simulate a progress of given duration
  */
  public void setIndeterminate(final long estimatedTime, boolean showRemaining)
  {
    if(!showRemaining)
    {
       EventQueue.invokeLater(new Runnable()
       {
         public void run()
         {
           progress.setIndeterminate(true);
           // show the time after 10 s
           TimerTask tt = new TimerTask()
           {
              public void run()
              {
                 EventQueue.invokeLater(new Runnable()
                 {
                   public void run()
                   {
                     long done = System.currentTimeMillis()-startTime;
                     progress.setString(
                       Language.translate("Duration = %",StringUtils.formatTime(done))+"");
                   }
                 });
              }
           };
           timer.scheduleAtFixedRate(tt, 10000, 1000);           
         }
       });                                 
    }
    else
    {
       EventQueue.invokeLater(new Runnable()
       {
         public void run()
         {
           progress.setIndeterminate(false);
           progress.setMaximum(1000);
         }
       });

       TimerTask tt = new TimerTask()
       {                      
          public void run()   
          {
             // which percent did we achieved ?
             double p = System.currentTimeMillis()-startTime;
             p = p/((double) estimatedTime)*1000.0;                    

             long doneMS = System.currentTimeMillis()-startTime;
             long remaining = estimatedTime-doneMS; 
                                      
             if(p>1000) p=990;
             setProgressValue((int) p, "Estimated remaining time = "+StringUtils.formatTime(remaining)+"");
          }
       };                                      
       timer.scheduleAtFixedRate(tt, 1000, 500);

    }
  }
                                   
  
  /** must always be called at the end !
  */
  public void closeDialog()
  {
/*      if(this.iniFile!=null && !wasCanceled)
      {
        long time = System.currentTimeMillis()-this.startTime;
        this.iniFile.setLong(this.identifier, time);
      }*/      
      timer.cancel();
      super.closeDialog();
  }
    


} // EstimatedProgressDialog
