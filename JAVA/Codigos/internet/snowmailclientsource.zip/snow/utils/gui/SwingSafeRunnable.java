package snow.utils.gui;

import javax.swing.SwingUtilities;


/** a runnable wrapper class which guaranties that
 *  the runnable given runs in the dispatch thread.
 *
 *  BE CAREFUL, the word "Safe" is excessive. It just assure
 *   that you don't become exceptions if you try to naively
 *   perform a SwingUtilities.invokeAndWait from the event dispatch thread.
 *
 *   It's always better if you exactely know in which thread
 *   you're running.
 */
public class SwingSafeRunnable implements Runnable {

    Runnable runnable;
    boolean wait;

    /** @param theRunnable is the runnable to execute
     * @param doWait true if we must
     */
    public SwingSafeRunnable(Runnable theRunnable, boolean doWait) {
        runnable = theRunnable;
        wait = doWait;
    }

    public void run()
    {
      try
      {
        if(SwingUtilities.isEventDispatchThread()) {
            runnable.run();
        }
        else
        {
            if(wait)
            {
                try {
                    SwingUtilities.invokeAndWait(runnable);
                }
                catch (InterruptedException iE)
                {
                  iE.printStackTrace();
                }
                catch (java.lang.reflect.InvocationTargetException iTE)
                {
                  iTE.printStackTrace();
                }
            }
            else
                SwingUtilities.invokeLater(runnable);
        }
      }
      catch(Exception e)
      {
         // ### test
         e.printStackTrace();
         throw new RuntimeException(e.getMessage());
      }
    }


}
