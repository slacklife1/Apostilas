package snow.utils.gui;

import java.util.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.geom.*;
import javax.swing.*;

public class SnowIcon implements Icon
{              
   int width, height;              
   
   double[][] kochCoord2 =
     {{0, 0}, {0.0555556, 0.096225}, {0, 0.19245}, {0.111111, 0.19245}, 
      {0.166667, 0.288675}, {0.166667, 0.288675}, {0.111111, 0.3849}, 
      {0, 0.3849}, {0.0555556, 0.481125}, {0, 0.57735}, {0, 0.57735}, 
      {0.111111, 0.57735}, {0.166667, 0.673575}, {0.222222, 0.57735}, 
      {0.333333, 0.57735}, {0.333333, 0.57735}, {0.388889, 0.673575}, 
      {0.333333, 0.7698}, {0.444444, 0.7698}, {0.5, 0.866025}, {0.5, 0.866025}, 
      {0.5, 0.866025}, {0.5, 0.866025}, {0.5, 0.866025}, {0.5, 0.866025}, 
      {0.5, 0.866025}, {0.555556, 0.7698}, {0.666667, 0.7698}, {0.611111, 0.673575}, 
      {0.666667, 0.57735}, {0.666667, 0.57735}, {0.777778, 0.57735}, 
      {0.833333, 0.673575}, {0.888889, 0.57735}, {1., 0.57735}, {1.,0.57735}, 
      {0.944444, 0.481125}, {1., 0.3849}, {0.888889, 0.3849},
      {0.833333, 0.288675}, {0.833333, 0.288675}, {0.888889, 0.19245}, 
      {1., 0.19245}, {0.944444, 0.096225}, {1, 0}, {1, 0}, {1, 0}, {1., 0}, 
      {1, 0}, {1, 0}, {1, 0}, {0.888889, 0}, {0.833333, -0.096225}, 
      {0.777778, 0}, {0.666667, 0}, {0.666667, 0}, {0.611111, -0.096225}, 
      {0.666667, -0.19245}, {0.555556, -0.19245}, {0.5, -0.288675}, 
      {0.5, -0.288675}, {0.444444, -0.19245}, {0.333333, -0.19245}, 
      {0.388889, -0.096225}, {0.333333, 0}, {0.333333, 0}, {0.222222, 0}, 
      {0.166667, -0.096225}, {0.111111, 0}, {0, 0}};  
  
  final GeneralPath flock;

  public SnowIcon(int w, int h)
  {
    width = w;
    height = h;

    flock = new GeneralPath();
    flock.moveTo(0,0);
    
    int step = (w<10 ? 5 : 1);
    for(int i=0; i<kochCoord2.length; i+=step)
    {
      flock.lineTo( (float)kochCoord2[i][0], (float)kochCoord2[i][1]);
    }
    flock.lineTo(0f, 0f);

    float sx = 0.2f;         
    float sy = 0.12f;
    float f = 0.61f;

    flock.moveTo((float)kochCoord2[0][0]*f+sx, (float)kochCoord2[0][1]*f+sy);
    for(int i=kochCoord2.length-1; i>=0; i-=step)
    {                           
      flock.lineTo( (float)kochCoord2[i][0]*f+sx, (float)kochCoord2[i][1]*f+sy);
    }
    flock.lineTo((float)kochCoord2[0][0]*f+sx, (float)kochCoord2[0][1]*f+sy);


  } // Constructor


  public int getIconHeight()
  {
    return height;
  }

  public int getIconWidth()
  {
    return width;
  }    
  
  public void paintSnowFlake(Graphics2D g2, double x, double y, double size)
  {
    Color bgColor = UIManager.getColor("Panel.background");
    if( bgColor == null )
    {
       bgColor = new Color(250,170,150); // give it a green color to show
    }                                 // that the key was invalid.
    Color col2 = SnowBackgroundPanel.CreateSmallLighterOrDarkerColor(bgColor);
    paintSnowFlake(g2, col2, bgColor, x,y,size);                        
  }                                                            

  public void paintSnowFlake(Graphics2D g2, Color c1, Color c2, double x, double y, double size)
  {
    AffineTransform oldTransform = g2.getTransform();
    RenderingHints oldHints = g2.getRenderingHints();
    Paint oldPaint = g2.getPaint();


    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    AffineTransform at = new AffineTransform(size,0,0,size,x,y);
    g2.transform(at);  

    g2.setColor(Color.black);
    //g2.setStroke(new BasicStroke( (float)(Math.sqrt(size)*0.002), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND ));

    g2.setPaint(new GradientPaint(
      0f, 0f,   c1,     // new Color(240,240,255,200),
      .9f, .9f, c2      // new Color(220,220,255,200)));
    ));
    g2.fill(flock);


    g2.setTransform(oldTransform);
    g2.setRenderingHints(oldHints);
    g2.setPaint(oldPaint);
  }


  public void paintIcon(Component c, Graphics g, int x, int y)
  {
    Graphics2D g2 = (Graphics2D) g;
    // back
    g2.setColor(Color.white);
    g2.fill( g2.getClip() );

    // flake
    paintSnowFlake(g2, x+width/10, y+width/3.7, width*0.8);
    g2.draw(new Rectangle2D.Double(x,y,width,height));
  } 
  
           
  public BufferedImage getIconAsImage()
  {
    BufferedImage bim = new BufferedImage(width,height,BufferedImage.TYPE_INT_ARGB);
    Graphics2D g2 = bim.createGraphics();
    this.paintSnowFlake(g2,Color.black,Color.white,0,5,width);
    return bim;
  }


  public static void main(String[] aa)
  {
    JFrame frame = new JFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.getContentPane().setLayout(new BorderLayout());
    frame.getContentPane().add(new JLabel(new SnowIcon(128, 128)), BorderLayout.CENTER);
    frame.setSize(122,122);
    frame.setVisible(true);                        
  }


} // SnowIcon

