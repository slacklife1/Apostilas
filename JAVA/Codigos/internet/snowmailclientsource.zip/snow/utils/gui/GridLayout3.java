package snow.utils.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
                                      
/** A grid layout using gridbag layout.                
    It has better resizes features than the GridLayout2
*/
public class GridLayout3 extends GridBagLayout
{
  int cols;
  JPanel target;
  final public GridBagConstraints constr = new GridBagConstraints();
                                        
  /** USAGE: add the component to this layout with
     add(comp), not with the panel add !
  */
  public GridLayout3(int cols, JPanel target)
  {
    super();

    this.cols = cols;
    this.target = target;

    constr.gridwidth = 1;
    constr.anchor = GridBagConstraints.WEST;
    constr.insets = new Insets(1,5,1,1);

    target.setLayout(this);
  } // Constructor


  int actualCol = 0;                  

  public void add(String comment)
  {
     add(new JLabel(comment), false);
  }

  public void add(JComponent comp)
  {
    add(comp, false);
  }
  
  public void add(JComponent comp, boolean fillHorizontally)
  {
    add(comp, fillHorizontally, (fillHorizontally?1f:0f));
  }

  public void add(JComponent comp, boolean fillHorizontally, float fillweight)
  {
     actualCol++;
     constr.fill = (fillHorizontally? constr.HORIZONTAL : constr.NONE);

     constr.weightx = fillweight;

     if(actualCol%cols==0)
     {
       constr.gridwidth = constr.REMAINDER;
       //constr.weightx = 0.8;
     }
     else
     {
       constr.gridwidth = 1;
       //constr.weightx = 0;
     }

     this.setConstraints(comp, constr);
     target.add(comp);
  }
                              

 /**
  *  Usage demo
  */        
  public static void main( String[] arguments )
  {              
    JPanel panel = new JPanel();
    GridLayout3 gl = new GridLayout3(2, panel);


    JFrame jf = new JFrame("test");

    jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    jf.setContentPane(panel);

    gl.add( new JLabel("a"), false);
    gl.add( new JTextField(), true);
    gl.add( new JLabel("b"), false);
    gl.add( new JTextField(12), false);
    gl.add( new JLabel("This is a label"), false);
    gl.add( new JTextField(), true);

    jf.setSize(400,400);
    jf.setVisible(true);      

  } // main


} // GridLayout3
