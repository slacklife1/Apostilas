package snow.utils.gui;

import java.io.File;
import java.awt.*;
import javax.swing.*;
import javax.swing.filechooser.*;

public class FileViewWithAttributes extends FileView
{
  final static int fontSize = UIManager.getFont("Label.font").getSize();
  
  Icon readOnlyFileIcon  = new FileIcon(false, FileIcon.ReadOnly, fontSize*3/2);
  Icon canReadWriteFileIcon = new FileIcon(false, FileIcon.ReadWrite, fontSize*3/2);
  Icon otherFileIcon = new FileIcon(false, FileIcon.Other, fontSize*3/2);
             
  Icon readOnlyDirectoryIcon  = new FileIcon(true, FileIcon.ReadOnly, fontSize*3/2);
  Icon canReadWriteDirectoryIcon = new FileIcon(true, FileIcon.ReadWrite, fontSize*3/2);
  Icon otherDirectoryIcon = new FileIcon(true, FileIcon.Other, fontSize*3/2);


  /**
   * If .java file, add length to name
   */
  public String getName(File file) 
  {
    String filename = file.getName();
    if (filename.endsWith(".java")) 
    {
       filename += " : " + file.length();
       return filename;
    }
    return null;
  }
             
  private boolean isRoot(File f)
  {
    File[] roots = File.listRoots();
    for(int i=0; i<roots.length; i++)
    {
      if(roots[i].equals(f)) return true;
    }
    return false;
  }             

  /**
   * Return special icons for .java and .class files
   */
  public Icon getIcon(File file) 
  {         
    // without this test, the floppy and removables devices are asked each time
    // from the system...
    if(isRoot(file)) return null;

    if (file.isDirectory())
    {
       if(file.canWrite() && file.canRead())  return canReadWriteDirectoryIcon;
       if(file.canRead()) return readOnlyDirectoryIcon;
       return otherDirectoryIcon;
    }

    if(file.canWrite() && file.canRead())  return canReadWriteFileIcon;
    if(file.canRead()) return readOnlyFileIcon;
    return otherFileIcon;

  }
  
  public static void main(String args[]) {
    SwingUtilities.invokeLater(new Runnable() 
    {
      public void run()
      {
        JFileChooser fileChooser = new JFileChooser(".");
        FileViewWithAttributes view = new FileViewWithAttributes();
        fileChooser.setFileView(view);
        
        int status = fileChooser.showOpenDialog(null);
        System.exit(0);
      }
    });
  }
} // FileViewWithAttributes
