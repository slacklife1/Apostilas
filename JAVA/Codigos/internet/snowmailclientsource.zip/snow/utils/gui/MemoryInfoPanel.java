package snow.utils.gui;

import javax.swing.*;
import java.awt.*;
import java.text.*;


public class MemoryInfoPanel extends JPanel
{
  final int gap = UIManager.getFont("Label.font").getSize();
  final JLabel jvmMemoryLabel;
  final JLabel appMemoryLabel;

  public MemoryInfoPanel()
  {
         super();
         setLayout( new FlowLayout( FlowLayout.RIGHT, gap,0) );
         setOpaque(false);
         jvmMemoryLabel = new JLabel("JVM")
           {
             public void updateUI()
             {
               super.updateUI();
               this.setForeground(UIManager.getColor("TextField.foreground"));
             }
           };
         jvmMemoryLabel.setForeground( UIManager.getColor("TextField.foreground") );
         appMemoryLabel = new JLabel("App")
           {
             public void updateUI()
             {
               super.updateUI();
               this.setForeground(UIManager.getColor("TextField.foreground"));
             }
           };
         appMemoryLabel.setForeground( UIManager.getColor("TextField.foreground") );
         add( jvmMemoryLabel );
         add( appMemoryLabel );

         start();
  }
  
  private void start()
  {
         // Attach the updatethread :
         final Thread memoryDisplayUpdater = new Thread()
          {
            public void run()
            {
              while( true )
               {
                 try
                  {
                    Thread.sleep(4000); // Veeery low CPU time consumption
                  }
                 catch( Exception e43874 )
                  {
                  }
                 final double jvmMemory = Runtime.getRuntime().totalMemory()/1.0e6;
                 final double appMemory = jvmMemory - Runtime.getRuntime().freeMemory()/1.0e6;
                 final DecimalFormat nf = new DecimalFormat( "#" );
                 EventQueue.invokeLater( new Runnable()
                  {
                    public void run()
                    {
                      jvmMemoryLabel.setText("JVM " + nf.format(jvmMemory) + " MB");
                      appMemoryLabel.setText("App " + nf.format(appMemory) + " MB");
                    }
                  });
               }
            }         
          };
          memoryDisplayUpdater.setDaemon(true);
          memoryDisplayUpdater.start();
  } // Constructor                





} // MemoryInfoPanel
