package snow.Language;

/** just map the snowmail Language class
*/
public final class Language
{

  public Language()
  {

  } // Constructor


  public static String translate(String sentence)
  {
    return SnowMailClient.Language.Language. translate(sentence);
  }
  
  /** sentence must contain %
  */
  public static String translate(String sentence, String arg1)
  {
    return SnowMailClient.Language.Language. translate(sentence, arg1);
  }


} // Language
