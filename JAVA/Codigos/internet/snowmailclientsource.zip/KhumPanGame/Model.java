package KhumPanGame;

import java.util.*;
import java.awt.Color;

/** the well known Khum Pan game
  [1] http://www.asiaspiel.ch/
*/
public class Model
{
  // the blocs positions zero = no piece.
  private final int[][] actualPositions;
  private final int[][] startPositions;  // used to reset
  private final int[][] endPositions;    // used in hasReachedEndPosition()

  public static final int[][] standardProblemStartPosition = new int[][] {  // line, col
    {1, 2, 2,  3},
    {1, 2, 2,  3},
    {0, 4, 4,  0},
    {5, 6, 7,  8},
    {5, 9, 10, 8} };

  public static final int[][] standardProblemEndPosition = new int[][] {  // line, col
    {1, 5, 8,  3},
    {1, 5, 8,  3},
    {6, 7, 4,  4},
    {0, 2, 2,  9},
    {0, 2, 2, 10} };
  
  public int numberOfMoves = 0;

  /** default model
  */
  public Model()
  {                                        
    this.startPositions  = copy( standardProblemStartPosition );
    this.endPositions    = copy( standardProblemEndPosition   );
    this.actualPositions = copy( standardProblemStartPosition );
  }
  

  /** allow building your own problem !
  */
  public Model(int[][] startPositions, int[][] endPositions)
  {                  
    this.startPositions  = copy( startPositions );
    this.endPositions    = copy( endPositions );
    this.actualPositions = copy( startPositions );
  }

  public int getNumberOfLines()   { return this.actualPositions.length; }
  public int getNumberOfColumns() { return this.actualPositions[0].length; }

  /** copy the array (deeper than clone !)
  */
  private int[][] copy(int[][] a)
  {
    //return (int[][]) a.clone();   // #### ERROR: this lead to the same reference !!!!!!!!!!

    int[][] copy = new int[a.length][a[0].length];
    for(int i=0; i<a.length; i++)
    {           
      for(int j=0; j<a[0].length; j++)
      {
        copy[i][j] = a[i][j];
      }
    }
    return copy;  
  }

  public void reset()
  {
    for(int line=0; line<this.getNumberOfLines(); line++)
    {
      for(int col=0; col<this.getNumberOfColumns(); col++)
      {
        this.actualPositions[line][col] = startPositions[line][col];
      }
    }
    this.numberOfMoves = 0;
  }
  
  public Color getColorForPiece(int piece)
  {
    if(piece==2) return Color.red;
    if(piece==1 || piece==3 || piece==4 || piece==5 || piece==8) return Color.blue;
    return Color.magenta;
  }   
        
  /** -1: out of bounds
  *  0: no piece.
  *  1+: piece
  */
  public synchronized int getPieceAt(int x, int y)
  {
     if(x<0) return -1;
     if(y<0) return -1;
     if(y>=this.getNumberOfLines()) return -1;
     if(x>=this.getNumberOfColumns()) return -1;

     return actualPositions[y][x];  // line, col
  }
  
  /** @param dx must be +1 or -1
  */
  public synchronized void moveX(int piece, int dx)
  {
    if(!canMoveX(piece, dx)) return;
    if(piece<=0) return;

    Vector<int[]> newPos = new Vector<int[]>();
    for(int line=0; line<this.getNumberOfLines(); line++)
    {
       for(int col=0; col<this.getNumberOfColumns(); col++)
       {
          if(actualPositions[line][col]==piece)
          {
             actualPositions[line][col] = 0;
             newPos.addElement(new int[]{line,col+dx});
          }
       }
    }
    
    for(int[] pos: newPos)
    {
      actualPositions[pos[0]][pos[1]] = piece;
    }

    numberOfMoves++;
  }

  public synchronized void moveY(int piece, int dy)
  {
    if(!canMoveY(piece, dy)) return;
    if(piece<=0) return;

    Vector<int[]> newPos = new Vector<int[]>();
    for(int line=0; line<this.getNumberOfLines(); line++)
    {
       for(int col=0; col<getNumberOfColumns(); col++)
       {
          if(actualPositions[line][col]==piece)
          {
             actualPositions[line][col] = 0;
             newPos.addElement(new int[]{line+dy, col});
          }
       }
    }

    for(int[] pos: newPos)
    {
      actualPositions[pos[0]][pos[1]] = piece;
    }

    numberOfMoves++;
  }


  /** @param dx must be +1 or -1
  */
  public synchronized boolean canMoveX(int piece, int dx)
  {
    if(Math.abs(dx)!=1) throw new IllegalArgumentException("dx must be +-1, not "+dx);

    for(int line=0; line<this.getNumberOfLines(); line++)
    {
      for(int col=0; col<this.getNumberOfColumns(); col++)
      {
         if(actualPositions[line][col]==piece)
         {
           int newCol = col+dx;
           // border bounds
           if(newCol<0) return false;
           if(newCol>=getNumberOfColumns()) return false;
           // not same piece and not empty
           if(actualPositions[line][newCol]!=0 && actualPositions[line][newCol]!=piece) return false;
         }
      }
    }
    // ok, can move
    return true;
  }

  /** @param dy is +-1
  */
  public synchronized boolean canMoveY(int piece, int dy)
  {
    if(Math.abs(dy)!=1) throw new IllegalArgumentException("dy must be +-1, not "+dy);

    for(int line=0; line<this.getNumberOfLines(); line++)
    {
      for(int col=0; col<this.getNumberOfColumns(); col++)
      {
         if(actualPositions[line][col]==piece)
         {
           int newLine = line+dy;
           // border bounds
           if(newLine<0) return false;
           if(newLine>=this.getNumberOfLines()) return false;
           // not same piece and not empty              
           if(actualPositions[newLine][col]!=0 && actualPositions[newLine][col]!=piece) return false;
         }
      }
    }
    // ok, can move
    return true;
  }
       
  /** @return true if the actualPositions is corresponding to the endPositions.
  */
  public boolean hasReachEndPosition()
  {
     // subtle: compare modulo reorderings of same looking pieces
     //  to achieve this, we must canonocalize the numberings
     
     int[][] conf1 = canonicalizePositions(this.actualPositions);
     int[][] conf2 = canonicalizePositions(this.endPositions);
     
     for(int i=0; i<conf1.length; i++)
     {
        if(!Arrays.equals( conf1[i], conf2[i])) return false;
     }

     return true;
  }

  /** in order to compare two positions modulo swap of same looking pieces, 
  * one can call this to make two configurations comparable.
  * This simply rename the pieces from left to right, top to botton, starting with 0
  */
  private int[][] canonicalizePositions(int[][] positions)
  {
    // Canonicalisation: Algorithm
    // Step 1: walk top-down, left-right and memorize the name of first occuring pieces
    //
    Vector<Integer> piecesIDs = new Vector<Integer>();
    for( int[] line: positions)
    {
      for(int piece: line)
      {
         if(!piecesIDs.contains(piece)) piecesIDs.add(piece);
      }
    }

    // Step 2: just reattribute the piece number
    //
    int[][] normalized = new int[getNumberOfLines()][getNumberOfColumns()];
    for(int line=0; line<this.getNumberOfLines(); line++)
    {                                           
      for(int col=0; col<this.getNumberOfColumns(); col++)
      {
         int piece = positions[line][col];
         // the indexof give 0 for the first appearing piece, 1 for the second
         // that's the key point of our canonicalisation
         normalized[line][col] = piecesIDs.indexOf( piece );
      }
    }

    return normalized;
  }

  public static void main(String[] args)
  {
    new MoveApp(true);
  }


} // Model
