    
package KhumPanGame;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

/** A transcription of the famous bloc moving game
*
* [1] http://www.asiaspiel.ch/
*/     
public class MoveApp extends JFrame
{
  private final Model model = new Model();
  private final MoveView view = new MoveView(model, 50, true);

  /** @param standalone if true, exit the JVM on close
  */
  public MoveApp(boolean standalone)
  {
    super("Khun Pan Game");
    this.setResizable(false);
    if(standalone)
    {
      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    // north: explain area
    JTextArea explainArea = new JTextArea("The goal is to move the blocs below\r\nto reach the end position\r\ndepicted on the right.");
    JPanel explainPanel = new JPanel(new BorderLayout());
    explainPanel.setBorder(new EmptyBorder(2,2,2,4));
    explainPanel.add(explainArea, BorderLayout.CENTER);
    explainArea.setBackground(this.getBackground());
    explainArea.setEditable(false);
    explainArea.setBorder(new EmptyBorder(5,5,5,5));
    Model endModel = new Model(Model.standardProblemEndPosition, Model.standardProblemEndPosition); // we just want a pure view of the end positions
    MoveView endView = new MoveView(endModel, 8, false);
    explainPanel.add(endView, BorderLayout.EAST);
    this.getContentPane().add(explainPanel, BorderLayout.NORTH);

    // center   
    view.setAlignmentX(JComponent.CENTER_ALIGNMENT);
    this.getContentPane().add(view, BorderLayout.CENTER);

    JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    this.getContentPane().add(controlPanel, BorderLayout.SOUTH);
    JButton reset = new JButton("Reset");
    controlPanel.add(reset);
    reset.addActionListener(new ActionListener()
    { 
      public void actionPerformed(ActionEvent ae)
      {
        model.reset();
        view.repaint();
      }
    });
         
    pack();
    this.setLocationRelativeTo(null);
    this.setVisible(true);
  } // Constructor
  
  

  public static void main(String[] args)
  {
    new MoveApp(true);   
  }

  

} // MoveApp
