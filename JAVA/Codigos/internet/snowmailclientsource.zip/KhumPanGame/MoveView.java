package KhumPanGame;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;

/** view and controller
*/
public class MoveView extends JPanel
{
  final private Model model;
  public int blocSize = 50;
  
  private int clickedPiece = -1;
  private int clickedX = -1;
  private int clickedY = -1;
                    
  public MoveView(final Model model, final int blocSize, boolean withController)
  {
    this.model = model;
    this.blocSize = blocSize;
    this.setPreferredSize( new Dimension(blocSize*model.getNumberOfColumns(), blocSize*model.getNumberOfLines()));

    // Controller
    //
    if(withController)
    {
      this.addMouseListener(new MouseAdapter()
      {
         @Override public void mousePressed(MouseEvent me)
         {
            clickedX = me.getX()/blocSize;
            clickedY = me.getY()/blocSize;
            clickedPiece = model.getPieceAt( clickedX, clickedY );
            update();
         }
      });
      this.addMouseMotionListener(new MouseMotionAdapter()
      {
         @Override public void mouseDragged(MouseEvent me)
         {
            int destX2 = me.getX()/blocSize;
            int destY2 = me.getY()/blocSize;

            if(clickedPiece>0 && Math.abs(destX2-clickedX)==1 && model.canMoveX(clickedPiece, destX2-clickedX))
            {
              model.moveX(clickedPiece, destX2-clickedX);
              clickedX = destX2;
            }
            if(clickedPiece>0 && Math.abs(destY2-clickedY)==1 && model.canMoveY(clickedPiece, destY2-clickedY))
            {
              model.moveY(clickedPiece, destY2-clickedY);
              clickedY = destY2;
            }

            update();
         }
      });
    }
  } // Constructor

  public void update()
  {
    repaint();
    
    if(model.hasReachEndPosition())
    {                      
       JOptionPane.showMessageDialog(this, "Congratulations, you solved the problem in "+model.numberOfMoves+" moves.");
    }
  }
  
  /** this is the way one customizes the rendering of a JPanel
  */
  public void paintComponent(Graphics g)
  {
    super.paintComponent(g);  // let the default method fills the background


    for(int i=0; i<model.getNumberOfLines(); i++)   // y
    {                                      
       for(int j=0; j<model.getNumberOfColumns(); j++)  // x
       {
           int piece = model.getPieceAt(j,i);
           if(piece>0)
           {                                                
              if(piece == clickedPiece) // highlight the clicked piece
              {             
                g.setColor( model.getColorForPiece( piece ).darker() );
              }
              else
              {
                g.setColor( model.getColorForPiece( piece ) );
              }

              int borderLeft  = (model.getPieceAt(j-1,i)!=piece ? 1 : 0);
              int borderRight = (model.getPieceAt(j+1,i)!=piece ? 1 : 0);

              int borderTop   = (model.getPieceAt(j,i-1)!=piece ? 1 : 0);
              int borderBelow = (model.getPieceAt(j,i+1)!=piece ? 1 : 0);


              g.fillRect( j*blocSize+borderLeft, i*blocSize+borderTop, blocSize-borderLeft-borderRight, blocSize-borderTop-borderBelow);
           }
       }
    }
  }
            

} // MoveView
