import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;                    

public final class ErrorPaster extends JFrame
{
  JTextArea descriptionArea = new JTextArea("Paste or drag an Exception stacktrace below \nand click on the button, the browsable is then present in the Schmortopf output tab.");
  JTextArea area = new JTextArea();

  public ErrorPaster()
  {
    super("Exception printer to schmortopf stack");

    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    getContentPane().setLayout(new BorderLayout());
    getContentPane().add(descriptionArea, BorderLayout.NORTH);
    descriptionArea.setEditable(false);
    descriptionArea.setBackground(this.getBackground());
    descriptionArea.setBorder(new EmptyBorder(5,5,5,5));

    getContentPane().add(new JScrollPane(area), BorderLayout.CENTER);

    JPanel controlPanel = new JPanel();
    getContentPane().add(controlPanel, BorderLayout.SOUTH);
    JButton pasteBT = new JButton("Print to schmortopf stack");
    controlPanel.add(pasteBT);
    pasteBT.setBackground(Color.orange);
    pasteBT.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
         System.out.println(area.getText());
      }
    });


    setSize(600,400);
    setLocation(100,50);
    setVisible(true);


  } // Constructor



 /**
  *  Static main method
  */
  public static void main( String[] arguments )
  {
      new ErrorPaster();
  } // main



} // ErrorPaster
