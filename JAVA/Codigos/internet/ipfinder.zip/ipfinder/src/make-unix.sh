#!/bin/sh



$JAVA_HOME/bin/javac IpFinder.java
