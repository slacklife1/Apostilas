import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.net.*;
import java.awt.datatransfer.*;

public class IpFinder extends JDialog {

JTextField yName, yIp, dName, dIp;
JButton clear, find, copy;
JPanel p1, p2, p3, p4;

public IpFinder(){
	getContentPane().setLayout(new GridLayout(6,1,5,5));
	setTitle("IP Finder");
	
	makeDialog();
	makeEvents();

	yName.setEditable(false);
	yIp.setEditable(false);

	getRootPane().setDefaultButton(find);
}

private void makeEvents(){
   try{
	String yAd = InetAddress.getLocalHost().toString();
	yName.setText(yAd.substring( 0,yAd.indexOf('/') ));
	yIp.setText(yAd.substring( yAd.indexOf('/')+1 ));
   }catch(UnknownHostException ex){
      yName.setText("Not available !");
      yIp.setText("Not available !");
   }

	clear.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			dName.setText("");
			dIp.setText("");
		}
	});
	
	find.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		   try{
			String address = InetAddress.getByName(dName.getText()).toString();
			dIp.setText(address.substring( address.indexOf('/')+1 ));
		   }catch(UnknownHostException ex){
			JOptionPane.showMessageDialog(null,ex.getClass().getName(),"Error",JOptionPane.ERROR_MESSAGE);
			dIp.setText("");
		   }
		}
	});

	copy.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			Clipboard cb = getToolkit().getSystemClipboard();
			StringSelection ss = new StringSelection(dIp.getText());
			dIp.selectAll();
			cb.setContents(ss,ss);
		}
	});

}

private void makeDialog(){
	p1 = new JPanel();
	p1.setLayout(new GridLayout(1,2));
	p1.add(new JLabel("Your Name:"));
	p1.add(yName = new JTextField());

	p2 = new JPanel();
	p2.setLayout(new GridLayout(1,2));
	p2.add(new JLabel("Your IP:"));
	p2.add(yIp = new JTextField());

	p3 = new JPanel();
	p3.setLayout(new GridLayout(1,2));
	p3.add(new JLabel("Domain's IP:"));
	p3.add(dIp = new JTextField());
	
	p4 = new JPanel();
	p4.setLayout(new GridLayout(1,4,3,3));
	p4.add(new JLabel());
	p4.add(clear = new JButton("Clear"));
	p4.add(copy = new JButton("Copy IP"));
	p4.add(find = new JButton("Find IP!"));

	getContentPane().add(p1);
	getContentPane().add(p2);
	getContentPane().add(new JLabel("Domain:"));
	getContentPane().add(dName = new JTextField("localhost"));
	getContentPane().add(p3);
	getContentPane().add(p4);
}

public static void main(String[] args){
	IpFinder ip = new IpFinder();
	ip.addWindowListener(new WindowAdapter(){
		public void windowClosing(WindowEvent e){
			System.exit(0);
		}
	});
	ip.pack();
	ip.show();
}

}