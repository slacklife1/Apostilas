#!/bin/sh



$JAVA_HOME/bin/java -jar ../ipfinder.jar
