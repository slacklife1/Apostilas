/*
 * DownloadMonitor.java
 *
 * Created on 05 Haziran 2004 Cumartesi, 18:03
 */

/**
 *
 * @author  �mer
 */
import javax.swing.*;
import java.awt.*;
public class DownloadMonitor extends JFrame{
    private JPanel panel;
    private JProgressBar pBar;
    private JButton cancelButton;
    private JLabel fileSizeLabel,timeLabel;
    
    /** Creates a new instance of DownloadMonitor */
    public DownloadMonitor() {
        super("NEOM - Download Progress");
        Container con=getContentPane();
        con.setLayout(new FlowLayout());
        panel=new JPanel();
        pBar=new JProgressBar();
        cancelButton=new JButton("Cancel");
        fileSizeLabel=new JLabel();
        timeLabel=new JLabel();
        
        con.add(panel);
        con.add(pBar);
        con.add(fileSizeLabel);
        con.add(timeLabel);
        con.add(cancelButton);
        
        setSize(250,150);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }
    public void update(long totalFileSize,long downloadedFileSize,long etime){
    	
        pBar.setMaximum((int)totalFileSize);
        pBar.setValue((int)downloadedFileSize);
        String elapsedTime=milliSecondsToString(System.currentTimeMillis()-etime);
        fileSizeLabel.setText((int)(downloadedFileSize/1024)+"Kb of "+(int)(totalFileSize/1024)+"Kb is downloaded.");
       	timeLabel.setText("Elapsed time: "+elapsedTime);
        validate();
    }
    public String milliSecondsToString(long time){
        int milliseconds = (int)(time % 1000);
        int seconds = (int)((time/1000) % 60);
        int minutes = (int)((time/60000) % 60);
        int hours = (int)((time/3600000) % 24);

        String millisecondsStr = (milliseconds<10 ? "00" : (milliseconds<100 ? "0" : ""))+milliseconds;
        String secondsStr = (seconds<10 ? "0" : "")+seconds;
        String minutesStr = (minutes<10 ? "0" : "")+minutes;
        String hoursStr = (hours<10 ? "0" : "")+hours;

        return new String(hoursStr+":"+minutesStr+":"+secondsStr);
    }
    public void finishDownload(){
        setVisible(false);
    }
}
