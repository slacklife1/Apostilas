/*
 * Download.java
 *
 * Created on 05 Haziran 2004 Cumartesi, 13:42
 */

/**
 *
 * @author  �mer
 */
import java.net.*;
import java.io.*;
public class Download extends Thread{
    private java.net.URL url;
    private String file;
    private long bytesDownloaded;
    private byte buffer[];
    private DownloadMonitor mon;
    /** Creates a new instance of Download */
    public Download(java.net.URL fUrl,String fileName) {
        url=fUrl;
        file=fileName;
    }
    public void run(){
		
        try{
        	
            URLConnection ucon=url.openConnection();
            BufferedInputStream instream;
            long fileSize=ucon.getContentLength();
            instream = new BufferedInputStream(ucon.getInputStream());
			
            int bytesRead;
            File f = new File(file);
            
            //bytes downloaded at each turn
            buffer = new byte[1024 * 1];
            long currentTime=System.currentTimeMillis();
			mon=new DownloadMonitor();
			mon.setVisible(true);
            RandomAccessFile raf = new RandomAccessFile(f, "rw");
            while(bytesDownloaded < fileSize)
            {
                    bytesRead = instream.read(buffer);
                    raf.write(buffer,0,bytesRead);
                    bytesDownloaded +=bytesRead;
                   	mon.update(fileSize, bytesDownloaded, currentTime);
            }
            
            //System.out.println("BytesDownloaded: " + BytesDownloaded);	
            instream.close();
            raf.close();
            mon.finishDownload();

            //Finished Downloading

        }catch(Exception e){System.out.println("Exception at download\n");System.out.println(e.getMessage());e.printStackTrace();}


        }
    
}
