/*
 * Start.java
 *
 * Created on 21 May�s 2004 Cuma, 18:14
 */

/**
 *
 * @author  �mer
 */
public class Start extends javax.swing.JFrame implements Runnable{
    Thread th;
    public Start() {
    	this.setIconImage(java.awt.Toolkit.getDefaultToolkit().getImage(this.getClass().getResource("icons/Title.gif")));
        th=new Thread(this);
        newPanel pan=new newPanel();
        getContentPane().setLayout(new java.awt.BorderLayout());
        getContentPane().add(pan,java.awt.BorderLayout.CENTER);
        th.start();
        setUndecorated(true);
        setResizable(false);
        setLocation(350,350);
        setSize(pan.getPreferredSize());
        setVisible(true);
        setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
    }
    public void run() {
        try{
            th.sleep(3000);
            setVisible(false);
        }catch(InterruptedException ax){javax.swing.JOptionPane.showMessageDialog(null,"Exception occured at thread","Error",javax.swing.JOptionPane.ERROR_MESSAGE);}
    }
}
class newPanel extends javax.swing.JPanel{
    javax.swing.ImageIcon im;
    public newPanel(){
        im=new javax.swing.ImageIcon("image/start2.png");
    }
    public void paintComponent(java.awt.Graphics g){
        super.paintComponent(g);
        im.paintIcon(this,g,0,0);
    } 
    public java.awt.Dimension getPreferredSize(){
        return new java.awt.Dimension(im.getIconWidth(),im.getIconHeight());
    }
}
