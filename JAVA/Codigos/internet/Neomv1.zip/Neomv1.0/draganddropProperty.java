/*
 * draganddropProperty.java
 *
 * Created on 19 May�s 2004 �ar�amba, 01:01
 */

/**
 *
 * @author  �mer
 */
public class draganddropProperty {
    
    
    public draganddropProperty(javax.swing.JEditorPane edPane) {
        edPane.setDropTarget(new java.awt.dnd.DropTarget(edPane, new editorListener(edPane)));
    }
    private class editorListener implements java.awt.dnd.DropTargetListener{
        javax.swing.JEditorPane edp;
        public editorListener(javax.swing.JEditorPane edP){edp=edP;}
        
        public void dragEnter(java.awt.dnd.DropTargetDragEvent dtde) {
        }
        
        public void dragExit(java.awt.dnd.DropTargetEvent dte) {
        }
        
        public void dragOver(java.awt.dnd.DropTargetDragEvent dtde) {
        }
        
        public void drop(java.awt.dnd.DropTargetDropEvent dtde) {
            try{
                dtde.acceptDrop(dtde.getDropAction());
                java.awt.datatransfer.DataFlavor[] flavors=dtde.getCurrentDataFlavors();
                java.awt.datatransfer.Transferable trans=dtde.getTransferable();
                if(flavors[flavors.length-1].isFlavorJavaFileListType()){
                    Object obj=trans.getTransferData(flavors[flavors.length-1]);
                    String filename=obj.toString();
                    filename=filename.substring(1,filename.length()-1);
                    if(filename.endsWith(".htm")||filename.endsWith(".html")||filename.endsWith(".txt"))
                        edp.setPage("file:\\"+filename);
                }
            }catch(java.awt.datatransfer.UnsupportedFlavorException excep){javax.swing.JOptionPane.showMessageDialog(null,"UnsupportedFloverException occured","Error",javax.swing.JOptionPane.ERROR_MESSAGE);}
            catch(java.io.IOException exc){javax.swing.JOptionPane.showMessageDialog(null,"IOException occured","Error",javax.swing.JOptionPane.ERROR_MESSAGE);}
        }
        
        public void dropActionChanged(java.awt.dnd.DropTargetDragEvent dtde) {
        }
        
    }
}
