/*
 * DownloadStart.java
 *
 * Created on 31 May�s 2004 Pazartesi, 18:39
 */

/**
 *
 * @author  �mer
 */
public class DownloadStart {
    private String fileName;
    private java.net.URL myUrl;
    private Download download;
    /** Creates a new instance of DownloadStart */
    public DownloadStart(java.net.URL url) {
	myUrl=url;
        int verify=javax.swing.JOptionPane.showConfirmDialog(null,"Do you want to save from the file:\n"+myUrl.getFile(),"Save?",javax.swing.JOptionPane.OK_CANCEL_OPTION);
        if(verify==javax.swing.JOptionPane.OK_OPTION){
            javax.swing.JFileChooser choose=new javax.swing.JFileChooser();
            choose.showSaveDialog(null);
            fileName=choose.getSelectedFile().toString();
            String extension=myUrl.getFile().substring((myUrl.getFile().lastIndexOf(".")),myUrl.getFile().length());
            if(fileName.lastIndexOf(".")==(-1)){
            	fileName+=extension;
            }
            download=new Download(getDownloadUrl(),getSavedFileName());
            download.start();
        }
        else
            return;
    }
    public String getSavedFileName(){
        return fileName;
    }
    public java.net.URL getDownloadUrl(){
        return myUrl;
    }
    
}
