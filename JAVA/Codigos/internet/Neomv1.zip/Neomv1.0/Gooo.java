/*
 * Gooo.java
 *
 * Created on 09 May�s 2004 Pazar, 15:32
 */

/**
 *
 * @author  �mer
 */
public class Gooo extends javax.swing.JFrame {
    
    // Constructor of Gooo 
    private java.lang.Runtime run;
    public Gooo() {
        try{
        	this.setIconImage(java.awt.Toolkit.getDefaultToolkit().getImage(this.getClass().getResource("icons/Title.gif")));
            initComponents();
            setSize(900,550);
            setLocation(160,150);
            favMaker();
            goHome();
        }catch(Exception exr){}
    }
    //initialize the gui components and allocate events
    private void initComponents() {//initComponents
    	favoritesReset=new javax.swing.JMenuItem("Reset Favourites");
    	historyReset=new javax.swing.JMenuItem("Reset History");
        jPopupMenu1 = new javax.swing.JPopupMenu();
        Cut3 = new javax.swing.JMenuItem();
        paste = new javax.swing.JMenuItem();
        lookgroup = new javax.swing.ButtonGroup();
        favdialog = new javax.swing.JDialog();
        jPanel1 = new javax.swing.JPanel();
        backward = new javax.swing.JButton();
        backwardBoxButton=new javax.swing.JButton();
        backBox=new javax.swing.JComboBox();
        backBox.setMaximumSize(new java.awt.Dimension(50,50));
        backBox.setPreferredSize(new java.awt.Dimension(150,30));
        backBox.setEditable(false);
        backBox.setBorder(null);
        backBox.addActionListener(
            new java.awt.event.ActionListener(){
                public void actionPerformed(java.awt.event.ActionEvent evt){
                    backBoxActionPerformed(evt);
                }
            }
        );
		
        backward.setLayout(new java.awt.BorderLayout());
        backwardBoxButton.setPreferredSize(new java.awt.Dimension(25,30));
        backwardBoxButton.setMaximumSize(new java.awt.Dimension(60,30));
        backwardBoxButton.setEnabled(true);
        backwardBoxButton.setBorder(null);
        backwardBoxButton.setLayout(new java.awt.BorderLayout());
        backwardBoxButton.add(backBox,java.awt.BorderLayout.EAST);
        backBox.setEnabled(false);
        
        jSeparator10 = new javax.swing.JSeparator();
        Forward = new javax.swing.JButton();
        frwBox=new javax.swing.JComboBox();
        frwBox.setPreferredSize(new java.awt.Dimension(150,30));
        frwBox.setEnabled(false);
        frwBoxButton=new javax.swing.JButton();
        frwBoxButton.setPreferredSize(new java.awt.Dimension(25,30));
        frwBoxButton.setMaximumSize(new java.awt.Dimension(60,30));
        frwBoxButton.setEnabled(true);
        frwBoxButton.setBorder(null);
        frwBoxButton.setLayout(new java.awt.BorderLayout());
        frwBoxButton.add(frwBox,java.awt.BorderLayout.EAST);
        
        frwBox.setEditable(false);
        frwBox.setSize(0,0);
        frwBox.addActionListener(
            new java.awt.event.ActionListener(){
                public void actionPerformed(java.awt.event.ActionEvent evt){
                    frwBoxActionPerformed(evt);
                }
            }
        );

        Forward.setLayout(new java.awt.BorderLayout());
        jSeparator11 = new javax.swing.JSeparator();
        Stop = new javax.swing.JButton();
        Refresh = new javax.swing.JButton();
        Home = new javax.swing.JButton();
        jSeparator4 = new javax.swing.JSeparator();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        NeomGifPanel = new javax.swing.JPanel();
    //    NeomGifPanel.setBorder(new javax.swing.border.EtchedBorder());
        NeomGifPanel.setLayout(new java.awt.BorderLayout());
        NeomGifPanel.setPreferredSize(new java.awt.Dimension(575,30));
        
        NeomGifButton = new javax.swing.JButton();
        NeomGifButton.setBorder(null);
        NeomGifButton.setPreferredSize(new java.awt.Dimension(30,30));
        NeomGifButton.setIcon(new javax.swing.ImageIcon("icons\\animation.gif"));
        jLabel2 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox();
        jButton1 = new javax.swing.JButton();
        jSeparator12 = new javax.swing.JSeparator();
        jPanel5 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        jProgressBar1 = new javax.swing.JProgressBar();
        jScrollPane1 = new javax.swing.JScrollPane();
        jEditorPane = new javax.swing.JEditorPane();


		favoritesReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt8) {
                favoritesResetActionPerformed(evt8);
            }
        });

        jMenuBar1 = new javax.swing.JMenuBar();
        file = new javax.swing.JMenu();
        newMenu = new javax.swing.JMenuItem();
        open = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JSeparator();
        save_as = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JSeparator();
        exit = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenuItem7 = new javax.swing.JMenuItem();
        jSeparator7 = new javax.swing.JSeparator();
        options = new javax.swing.JMenu();
        bview = new javax.swing.JMenu();
        winlook = new javax.swing.JRadioButtonMenuItem();
        javalook = new javax.swing.JRadioButtonMenuItem();
        unixlook = new javax.swing.JRadioButtonMenuItem();
        gtk_look = new javax.swing.JRadioButtonMenuItem();
        jSeparator8 = new javax.swing.JSeparator();
        source = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem8 = new javax.swing.JMenuItem();
        jMenuItem9 = new javax.swing.JMenuItem();
        jMenuItem10 = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        homePage = new javax.swing.JMenuItem();
        jSeparator6 = new javax.swing.JSeparator();
        marmara_university = new javax.swing.JMenuItem();
        google = new javax.swing.JMenuItem();
        programmersheaven = new javax.swing.JMenuItem();
        yahoo = new javax.swing.JMenuItem();
        jSeparator5 = new javax.swing.JSeparator();
        adding = new javax.swing.JMenuItem();
        jSeparator9 = new javax.swing.JSeparator();
        jMenu5 = new javax.swing.JMenu();
        jMenuItem11 = new javax.swing.JMenuItem();
        jMenuItem12 = new javax.swing.JMenuItem();

        Cut3.setText("Cut");
        jPopupMenu1.add(Cut3);

        paste.setText("Paste");
        jPopupMenu1.add(paste);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("NEOM");
        setFont(new java.awt.Font("Jurassic", 0, 10));
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                change(evt);
            }
        });
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });

        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 9, 4));

        jPanel1.setAlignmentY(1.0F);
        jPanel1.setPreferredSize(new java.awt.Dimension(377, 35));
        backward.setIcon(new javax.swing.ImageIcon("icons\\Left.gif"));
        backward.setToolTipText("Back");
        backward.setBorder(null);
        backward.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        backward.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        backward.setPreferredSize(new java.awt.Dimension(25, 30));
        backward.setRolloverEnabled(true);
        backward.setRolloverIcon(new javax.swing.ImageIcon("icons\\Left2.gif"));
        backward.setEnabled(false);
        backward.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backwardActionPerformed(evt);
            }
        });

        jPanel1.add(backward);
		jPanel1.add(backwardBoxButton);
		
        jSeparator10.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator10.setPreferredSize(new java.awt.Dimension(5, 30));
        jPanel1.add(jSeparator10);

        Forward.setIcon(new javax.swing.ImageIcon("icons\\Right.gif"));
        Forward.setToolTipText("Forward");
        Forward.setBorder(null);
        Forward.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Forward.setPreferredSize(new java.awt.Dimension(25, 30));
        Forward.setRolloverEnabled(true);
        Forward.setRolloverIcon(new javax.swing.ImageIcon("icons\\Right2.gif"));
        Forward.setEnabled(false);
        Forward.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ForwardActionPerformed(evt);
            }
        });

        jPanel1.add(Forward);
        jPanel1.add(frwBoxButton);

        jSeparator11.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator11.setPreferredSize(new java.awt.Dimension(5, 30));
        jPanel1.add(jSeparator11);

        Stop.setIcon(new javax.swing.ImageIcon("icons\\Stop.gif"));
        Stop.setToolTipText("Stop");
        Stop.setBorder(null);
        Stop.setPreferredSize(new java.awt.Dimension(30, 25));
        Stop.setRolloverEnabled(true);
        Stop.setRolloverIcon(new javax.swing.ImageIcon("icons\\Stop2.gif"));
        jPanel1.add(Stop);

        Refresh.setIcon(new javax.swing.ImageIcon("icons\\RotCWRight.gif"));
        Refresh.setToolTipText("Refresh");
        Refresh.setBorder(null);
        Refresh.setPreferredSize(new java.awt.Dimension(30, 25));
        Refresh.setRolloverIcon(new javax.swing.ImageIcon("icons\\RotCWRight2.gif"));
        Refresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RefreshActionPerformed(evt);
            }
        });

        jPanel1.add(Refresh);

        Home.setIcon(new javax.swing.ImageIcon("icons\\hom.gif"));
        Home.setToolTipText("Go to home page");
        Home.setBorder(null);
        Home.setPreferredSize(new java.awt.Dimension(35, 25));
        Home.setRolloverEnabled(true);
        Home.setRolloverIcon(new javax.swing.ImageIcon("icons\\hom2.gif"));
        Home.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HomeActionPerformed(evt);
            }
        });

        jPanel1.add(Home);

        jSeparator4.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator4.setPreferredSize(new java.awt.Dimension(2, 25));
        jPanel1.add(jSeparator4);

        getContentPane().add(jPanel1, java.awt.BorderLayout.NORTH);

        jPanel3.setLayout(new java.awt.BorderLayout());

        jPanel4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 2));

        jPanel4.setBorder(new javax.swing.border.EtchedBorder());
        jPanel4.setPreferredSize(new java.awt.Dimension(10, 33));
        jLabel2.setText("Adress");
        jLabel2.setAlignmentY(2.0F);
        jLabel2.setPreferredSize(new java.awt.Dimension(43, 20));
        jPanel4.add(jLabel2);

        jComboBox2.setEditable(true);
        jComboBox2.setFont(new java.awt.Font("Lucida Sans Unicode", 0, 11));
        jComboBox2.setPreferredSize(new java.awt.Dimension(775, 20));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        jPanel4.add(jComboBox2);

        jButton1.setIcon(new javax.swing.ImageIcon("icons\\Go.gif"));
        
        jButton1.setToolTipText("Go to the specified site");
        jButton1.setAlignmentY(2.0F);
        jButton1.setBorder(null);
        jButton1.setPreferredSize(new java.awt.Dimension(40, 27));
        jButton1.setRolloverEnabled(true);
        jButton1.setRolloverIcon(new javax.swing.ImageIcon("icons\\Right.gif"));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jPanel4.add(jButton1);

        jSeparator12.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator12.setPreferredSize(new java.awt.Dimension(2, 23));
        jPanel4.add(jSeparator12);
        jPanel1.add(NeomGifPanel);
        NeomGifPanel.add(NeomGifButton,java.awt.BorderLayout.EAST);

        jPanel3.add(jPanel4, java.awt.BorderLayout.NORTH);

        jPanel5.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 3));

        jPanel5.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel5.setFocusable(false);
        jPanel5.setMinimumSize(new java.awt.Dimension(63, 100));
        jPanel5.setPreferredSize(new java.awt.Dimension(10, 25));
        jLabel1.setBackground(new java.awt.Color(204, 204, 204));
        jLabel1.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel1.setAlignmentY(0.1F);
        jLabel1.setPreferredSize(new java.awt.Dimension(600, 16));
        jPanel5.add(jLabel1);

        jSeparator3.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator3.setPreferredSize(new java.awt.Dimension(5, 15));
        jPanel5.add(jSeparator3);

        jProgressBar1.setAlignmentY(0.7F);
        jProgressBar1.setPreferredSize(new java.awt.Dimension(150, 15));
        jPanel5.add(jProgressBar1);

        jPanel3.add(jPanel5, java.awt.BorderLayout.SOUTH);

        jEditorPane.setEditable(false);
        jEditorPane.setDoubleBuffered(true);
        jEditorPane.setMaximumSize(new java.awt.Dimension((int)getSize().getWidth(),500));
        jEditorPane.addHyperlinkListener(new javax.swing.event.HyperlinkListener() {
            public void hyperlinkUpdate(javax.swing.event.HyperlinkEvent evt) {
                jEditorPaneHyperlinkUpdate(evt);
            }
        });

        jScrollPane1.setViewportView(jEditorPane);

        jPanel3.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        getContentPane().add(jPanel3, java.awt.BorderLayout.CENTER);

        file.setText("File");
        newMenu.setIcon(new javax.swing.ImageIcon("icons\\New.gif"));
        newMenu.setText("New");
        newMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newMenuActionPerformed(evt);
            }
        });

        file.add(newMenu);

        open.setIcon(new javax.swing.ImageIcon("icons\\Open.gif"));
        open.setText("Open");
        open.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openActionPerformed(evt);
            }
        });

        file.add(open);

        file.add(jSeparator1);

        save_as.setIcon(new javax.swing.ImageIcon("icons\\Save.gif"));
        save_as.setText("Save as");
        save_as.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save_asActionPerformed(evt);
            }
        });

        file.add(save_as);

        file.add(jSeparator2);

        exit.setIcon(new javax.swing.ImageIcon("icons\\Exit.gif"));
        exit.setText("Exit");
        exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitActionPerformed(evt);
            }
        });

        file.add(exit);

        jMenuBar1.add(file);

        jMenu2.setText("Edit");
        jMenu2.setName("Edit");
        
        jMenuItem4.setIcon(new javax.swing.ImageIcon("icons\\Cut.gif"));
        jMenuItem4.setText("Cut");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });

        jMenu2.add(jMenuItem4);

        jMenuItem5.setIcon(new javax.swing.ImageIcon("icons\\Copy.gif"));
        jMenuItem5.setText("Copy");
        jMenuItem5.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });

        jMenu2.add(jMenuItem5);

        jMenuItem6.setIcon(new javax.swing.ImageIcon("icons\\Paste.gif"));
        jMenuItem6.setText("Paste");
        jMenuItem6.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });

        jMenu2.add(jMenuItem6);

        jMenuItem7.setText("Select all");
        jMenuItem7.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jMenuItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem7ActionPerformed(evt);
            }
        });

        jMenu2.add(jMenuItem7);

        jMenu2.add(jSeparator7);

        options.setText("Options");
        bview.setText("Browser view");
        winlook.setText("Windows look");
        lookgroup.add(winlook);
        winlook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                winlookActionPerformed(evt);
            }
        });

        bview.add(winlook);

        javalook.setSelected(true);
        javalook.setText("Java look");
        lookgroup.add(javalook);
        javalook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                javalookActionPerformed(evt);
            }
        });

        bview.add(javalook);

        unixlook.setText("Unix look");
        lookgroup.add(unixlook);
        unixlook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                unixlookActionPerformed(evt);
            }
        });

        bview.add(unixlook);

        gtk_look.setText("GTK look");
        lookgroup.add(gtk_look);
        gtk_look.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gtk_lookActionPerformed(evt);
            }
        });

        bview.add(gtk_look);

        options.add(bview);
        options.add(historyReset);
        historyReset.addActionListener(new java.awt.event.ActionListener(){
        	public void actionPerformed(java.awt.event.ActionEvent action){
        		historyResetActionPerformed(action);
        	}
        
        });

        jMenu2.add(options);

        jMenu2.add(jSeparator8);

        source.setText("Source");
        source.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sourceActionPerformed(evt);
            }
        });

        jMenu2.add(source);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("View");
        jMenuItem8.setText("Go");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem8ActionPerformed(evt);
            }
        });

        jMenu3.add(jMenuItem8);

        jMenuItem9.setText("Stop");
        jMenu3.add(jMenuItem9);

        jMenuItem10.setText("Refresh");
        jMenuItem10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem10ActionPerformed(evt);
            }
        });

        jMenu3.add(jMenuItem10);

        jMenuBar1.add(jMenu3);

        jMenu4.setText("Bookmarks");
        jMenu4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenu4ActionPerformed(evt);
            }
        });

        homePage.setText("Change HomePage");
        homePage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homePageActionPerformed(evt);
            }
        });
		
		options.add(favoritesReset);
		
        jMenu4.add(homePage);

        jMenu4.add(jSeparator6);

        marmara_university.setText("Marmara University");
        marmara_university.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                marmara_universityActionPerformed(evt);
            }
        });

        jMenu4.add(marmara_university);

        google.setText("Google");
        google.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                googleActionPerformed(evt);
            }
        });

        jMenu4.add(google);

        programmersheaven.setText("Programmer's Heaven");
        programmersheaven.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                programmersheavenActionPerformed(evt);
            }
        });

        jMenu4.add(programmersheaven);

        yahoo.setText("yahoo");
        yahoo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yahooActionPerformed(evt);
            }
        });

        jMenu4.add(yahoo);

        jMenu4.add(jSeparator5);

        adding.setIcon(new javax.swing.ImageIcon("icons\\NewFavorite.gif"));
        adding.setText("Add to Favourites");
        adding.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addingActionPerformed(evt);
            }
        });

        jMenu4.add(adding);

        jMenu4.add(jSeparator9);

        jMenuBar1.add(jMenu4);

        jMenu5.setText("Help");
        jMenuItem11.setText("About Authors");
        jMenuItem11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem11ActionPerformed(evt);
            }
        });

        jMenu5.add(jMenuItem11);

        jMenuItem12.setText("About Browser");
        jMenuItem12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem12ActionPerformed(evt);
            }
        });

        jMenu5.add(jMenuItem12);

        jMenuBar1.add(jMenu5);

        setJMenuBar(jMenuBar1);

        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((screenSize.width-649)/2, (screenSize.height-494)/2, 649, 494);
        
        jPopupMenu1=new javax.swing.JPopupMenu();
        cutMenuItem=new javax.swing.JMenuItem("Cut");
        copyMenuItem=new javax.swing.JMenuItem("Copy");
        pasteMenuItem=new javax.swing.JMenuItem("Paste");
        selectAllMenuItem=new javax.swing.JMenuItem("Select all");
        openMenuItem=new javax.swing.JMenuItem("Open url");
        menuSep=new javax.swing.JSeparator();
        
        jPopupMenu1.add(cutMenuItem);
        jPopupMenu1.add(copyMenuItem);
        jPopupMenu1.add(pasteMenuItem);
        jPopupMenu1.add(selectAllMenuItem);
        jPopupMenu1.add(menuSep);
        jPopupMenu1.add(openMenuItem);
        
        cutMenuItem.setEnabled(false);
        copyMenuItem.setEnabled(false);
        pasteMenuItem.setEnabled(true);
        openMenuItem.setEnabled(false);
        
        cutMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        copyMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        pasteMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        selectAllMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem7ActionPerformed(evt);
            }
        });
        java.awt.event.MouseListener popupListener = new PopupListener();
        jEditorPane.addMouseListener(popupListener);
        jComboBox2.addMouseListener(popupListener);
    }
    
    private void jMenuItem12ActionPerformed(java.awt.event.ActionEvent evt) {//event_jMenuItem12ActionPerformed
        try{
            String cmd = "C:/Windows/NOTEPAD.exe help/browser.txt";
            Runtime rt = Runtime.getRuntime();
            Process proc = rt.exec(cmd);
            
            // any error message?
            StreamGobbler errorGobbler = new 
            StreamGobbler(proc.getErrorStream(), "ERR");            

            // any output?
            StreamGobbler outputGobbler = new 
            StreamGobbler(proc.getInputStream(), "OUT");

            // kick them off
            errorGobbler.start();
            outputGobbler.start();

            // any error???
            int exitVal = proc.waitFor();
        } catch (Throwable t){javax.swing.JOptionPane.showMessageDialog(null,"Could not open browser.txt","Error",javax.swing.JOptionPane.ERROR_MESSAGE);}
    }//event_jMenuItem12ActionPerformed
	
	//delete pages in history
	private void historyResetActionPerformed(java.awt.event.ActionEvent action){
			java.io.File history=new java.io.File("C:/NEOM/History/pages.txt");
			history.delete();
			jComboBox2.removeAllItems();	
	}
	
    private void jMenuItem11ActionPerformed(java.awt.event.ActionEvent evt) {//event_jMenuItem11ActionPerformed
        javax.swing.JOptionPane.showMessageDialog(this,"�slam Mehmet Y�net    miy_mar@yahoo.com\n" +
        "�mer Sar�temur    osaritemur@eng.marmara.edu.tr\n\nMARMARA UNIVERSITY\nComputer Engineering\n"+
        "                                                                     9 June 2004","NEOM",javax.swing.JOptionPane.INFORMATION_MESSAGE);
    }//event_jMenuItem11ActionPerformed

    private void jMenuItem7ActionPerformed(java.awt.event.ActionEvent evt) {//event_jMenuItem7ActionPerformed
        jEditorPane.selectAll();
        selected=jEditorPane.getSelectedText();
    }//event_jMenuItem7ActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//event_jMenuItem6ActionPerformed
        jComboBox2.getEditor().setItem(selected);
    }//event_jMenuItem6ActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//event_jMenuItem5ActionPerformed
        jEditorPane.copy();
        selected=jEditorPane.getSelectedText();
    }//event_jMenuItem5ActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//event_jMenuItem4ActionPerformed
        jEditorPane.cut();
        selected=jEditorPane.getSelectedText();
    }//event_jMenuItem4ActionPerformed

    private void jMenuItem10ActionPerformed(java.awt.event.ActionEvent evt) {//event_jMenuItem10ActionPerformed
        connectPage((String)jComboBox2.getEditor().getItem());
    }//event_jMenuItem10ActionPerformed

    private void jMenuItem8ActionPerformed(java.awt.event.ActionEvent evt) {//event_jMenuItem8ActionPerformed
        connectPage((String)jComboBox2.getEditor().getItem());
    }//event_jMenuItem8ActionPerformed

    private void sourceActionPerformed(java.awt.event.ActionEvent evt) {//event_sourceActionPerformed
        java.io.BufferedReader br=null;
        try{
        	//to get the source of this page
            br=new java.io.BufferedReader(new java.io.InputStreamReader(jEditorPane.getPage().openConnection().getInputStream()));
            String inputLine;
            sourceName="c:\\NEOM\\"+((int)(Math.random()*500)+1)+".txt";
            java.io.File file=new java.io.File(sourceName);
            java.io.FileWriter filew=new java.io.FileWriter(file);
            java.io.BufferedWriter bw=new java.io.BufferedWriter(filew);
            while ((inputLine = br.readLine()) != null) {
                bw.write(inputLine);
                bw.newLine();
            }
            inputLine=null;
        	
        	//**********start notepad to view the source	**************
            String cmd = "c:/WINDOWS/NOTEPAD.EXE "+sourceName;
            Runtime rt = Runtime.getRuntime();
            Process proc = rt.exec(cmd);
            int exitValue =proc.waitFor();
            if(exitValue==proc.exitValue())
            	file.delete();
            // any error message?
            StreamGobbler errorGobbler = new 
            StreamGobbler(proc.getErrorStream(), "ERR");            

            // any output?
            StreamGobbler outputGobbler = new 
            StreamGobbler(proc.getInputStream(), "OUT");

            // kick them off
            errorGobbler.start();
            outputGobbler.start();

            // any error???
            int exitVal = proc.waitFor();
        } catch (Throwable t){t.printStackTrace();}
    }//event_sourceActionPerformed
    
    //when pressed home button
    private void HomeActionPerformed(java.awt.event.ActionEvent evt) {//event_HomeActionPerformed
        goHome();
    }//event_HomeActionPerformed
    
     private void favoritesResetActionPerformed(java.awt.event.ActionEvent evt8){
     	java.io.File fuo=new java.io.File("c:/Neom/Bookmarks.txt");
     	fuo.delete();
     	for(int i=1;i<=count;i++){
     		jMenu4.remove(bmenus[i]);
     	}
     }
    
    private void goHome(){
        try{
            java.io.File file=new java.io.File("C:/Neom/homepage.txt");
            java.io.FileReader raf=new java.io.FileReader(file);
            java.io.BufferedReader r=new java.io.BufferedReader(raf);
            char temp;
            int count=0;
            String s=r.readLine();
            connectPage(s);
            r.close();
        }catch(Exception e){javax.swing.JOptionPane.showMessageDialog(this,"An exception occured while accesing to homepage file","Error",javax.swing.JOptionPane.ERROR_MESSAGE);}
    }
    //home page change event
    private void homePageActionPerformed(java.awt.event.ActionEvent evt) {//event_homePageActionPerformed
        try{
            String home=javax.swing.JOptionPane.showInputDialog(this,"Change your homepage","NEOM",javax.swing.JOptionPane.QUESTION_MESSAGE);
            java.io.File file=new java.io.File("C:/Neom/homepage.txt");
            globalCounter=home.length();
            //writes the home page to a randomaccesfile
            java.io.FileWriter raf=new java.io.FileWriter(file);
            java.io.BufferedWriter wr=new java.io.BufferedWriter(raf);
            wr.write(home);
            wr.close();
        }catch(Exception e){}
    }//event_homePageActionPerformed
    //refresh button event
    private void RefreshActionPerformed(java.awt.event.ActionEvent evt) {//event_RefreshActionPerformed
        connectPage((String)jComboBox2.getEditor().getItem());
    }//event_RefreshActionPerformed
    //backward button event
    private void backwardActionPerformed(java.awt.event.ActionEvent evt) {//event_backwardActionPerformed
        if(backBox.getItemCount()!=0){
            connectPage((String)backBox.getItemAt(backBox.getItemCount()-1));
        }
    }//event_backwardActionPerformed
    //forward button event
    private void ForwardActionPerformed(java.awt.event.ActionEvent evt) {//event_ForwardActionPerformed
        if(frwBox.getItemCount()!=0)
            connectPage((String)frwBox.getItemAt(frwBox.getItemCount()-1));
    }//event_ForwardActionPerformed
    //sets combobox's location depending on the frame size
    private void change(java.awt.event.ComponentEvent evt) {//event_change      
        jComboBox2.setSize(new java.awt.Dimension((int)(this.getSize().getWidth())-117,21));
        NeomGifPanel.setSize(new java.awt.Dimension((int)(this.getSize().getWidth())-325,30));
        NeomGifPanel.validate();
        jComboBox2.validate();      
        jButton1.setLocation((int)(this.getSize().getWidth()-60), (int)jButton1.getLocation().getY());     
    }//event_change
    
    //adding to favourites
    private void addingActionPerformed(java.awt.event.ActionEvent evt) {//event_addingActionPerformed
        try{
            String st=javax.swing.JOptionPane.showInputDialog(this,"******Enter your favourite********","NEOM-New Favorite"/*,""*/,javax.swing.JOptionPane.QUESTION_MESSAGE);
            bmenus[++count]=new javax.swing.JMenuItem(st);
            jMenu4.add(bmenus[count]);
            //controls if specified file exists
            if(bookmarkFile==null){
                bookmarkFile=new java.io.File("c:/Neom/Bookmarks.txt");
            }
            java.io.FileWriter writer=new java.io.FileWriter(bookmarkFile,true);
            favSiteAdder(bmenus[count]);
            java.io.BufferedWriter buff=new java.io.BufferedWriter(writer);
            buff.write(st);
            buff.newLine();
            buff.close();
        }catch(java.io.IOException ex){javax.swing.JOptionPane.showMessageDialog(null,"An I/O error occured when accessing the bookmark file","Error",javax.swing.JOptionPane.ERROR_MESSAGE);}
        catch(NullPointerException e){}
    }//event_addingActionPerformed
    //creates new JMenuItems for favourites
    private void favMaker(){
        try{
        	
            bookmarkFile=new java.io.File("c:\\NEOM\\Bookmarks.txt");
            java.io.FileWriter fwr=new java.io.FileWriter(bookmarkFile,true);
            java.io.FileReader read=new java.io.FileReader(bookmarkFile);
            java.io.BufferedReader reader=new java.io.BufferedReader(read);
            reader.mark(8);
            bmenus=new javax.swing.JMenuItem[500];
            while(reader.readLine()!=null){
                reader.reset();
                bmenus[count]=new javax.swing.JMenuItem(reader.readLine());
                reader.mark(8);
                jMenu4.add(bmenus[count]);
                favSiteAdder(bmenus[count]);
                count++;
            }
            reader.close();
            fwr.close();
        }catch(Exception exce){javax.swing.JOptionPane.showMessageDialog(null,"An unhandled exception occured at favmaker","Error",javax.swing.JOptionPane.ERROR_MESSAGE);/*exce.printStackTrace();*/}
    }
    //when pressed to favourite site JMenuItems
    private void favSiteAdder(javax.swing.JMenuItem menu1){
        item=menu1;
        menu1.addActionListener(
            new java.awt.event.ActionListener(){
                public void actionPerformed(java.awt.event.ActionEvent e){
                    connectPage(item.getText());
                }
            }
        );
    }
    private void yahooActionPerformed(java.awt.event.ActionEvent evt) {//event_yahooActionPerformed
        connectPage("www.yahoo.com");
    }//event_yahooActionPerformed

    private void jMenu4ActionPerformed(java.awt.event.ActionEvent evt) {//event_jMenu4ActionPerformed
        // TODO add your handling code here:
    }//event_jMenu4ActionPerformed

    private void programmersheavenActionPerformed(java.awt.event.ActionEvent evt) {//event_programmersheavenActionPerformed
        connectPage("www.programmersheaven.com");
    }//event_programmersheavenActionPerformed

    private void googleActionPerformed(java.awt.event.ActionEvent evt) {//event_googleActionPerformed
       connectPage("www.google.com");
    }//event_googleActionPerformed

    private void marmara_universityActionPerformed(java.awt.event.ActionEvent evt) {//event_marmara_universityActionPerformed
        connectPage("www.marmara.edu.tr");
    }//event_marmara_universityActionPerformed
    //address bar action
    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//event_jComboBox2ActionPerformed
       if(evt.getActionCommand().equals("comboBoxEdited")){
            javax.swing.JComboBox cb = (javax.swing.JComboBox)evt.getSource();
            String pName = (String)cb.getSelectedItem();
            connectPage(pName);
            cont=1;
        }
            
    }
    //to open new browser window
    private void newMenuActionPerformed(java.awt.event.ActionEvent evt) {
        new Gooo().setVisible(true);
    }
    
    //to save the page
    private void save_asActionPerformed(java.awt.event.ActionEvent evt) {
			new DownloadStart(jEditorPane.getPage());    
    }
    
    //action for browser view to change L&F
    private void gtk_lookActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            String GTK="com.sun.java.swing.plaf.gtk.GtkLookAndFeel";
            javax.swing.UIManager.setLookAndFeel(GTK);
            javax.swing.UIManager.installLookAndFeel("GTK",GTK);
            updater();
       } catch (Exception e) {javax.swing.JOptionPane.showMessageDialog(null,"Could not install GTK LookAndFeel","Unsupported LookandFeel",javax.swing.JOptionPane.ERROR_MESSAGE);}
    }
    
    //action for browser view to change L&F
    private void unixlookActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            String Motif ="com.sun.java.swing.plaf.motif.MotifLookAndFeel";
            javax.swing.UIManager.setLookAndFeel(Motif);
            javax.swing.UIManager.installLookAndFeel("motif",Motif);
            updater();
       } catch (Exception e) {javax.swing.JOptionPane.showMessageDialog(null,"Could not install Motif(Unix) LookAndFeel","Unsupported LookandFeel",javax.swing.JOptionPane.ERROR_MESSAGE);}
    }//event_unixlookActionPerformed

    //action for browser view to change L&F
    private void javalookActionPerformed(java.awt.event.ActionEvent evt) {//event_javalookActionPerformed
        try {
            String Java ="javax.swing.plaf.metal.MetalLookAndFeel";
            javax.swing.UIManager.setLookAndFeel(Java);
            javax.swing.UIManager.installLookAndFeel("java", Java);
            updater();
       } catch (Exception e) {javax.swing.JOptionPane.showMessageDialog(null,"Could not install Java(Metal) LookAndFeel","Unsupported LookandFeel",javax.swing.JOptionPane.ERROR_MESSAGE);}
    }//event_javalookActionPerformed

    //action for browser view to change L&F
    private void winlookActionPerformed(java.awt.event.ActionEvent evt) {//event_winlookActionPerformed
       try {
            String WIN ="com.sun.java.swing.plaf.windows.WindowsLookAndFeel";
            javax.swing.UIManager.setLookAndFeel(WIN);
            javax.swing.UIManager.installLookAndFeel("Win", WIN);
            updater();
       } catch (Exception e) {javax.swing.JOptionPane.showMessageDialog(null,"Could not install Windows LookAndFeel","Unsupported LookandFeel",javax.swing.JOptionPane.ERROR_MESSAGE);}
    }//event_winlookActionPerformed
    //Make some changes on the url
    private java.net.URL myConnection(String thePage){
        
        try{
            //if http is already specified
            if(thePage.substring(0,4).equals("http")) 
                pageUrl=new java.net.URL(thePage);
                
            //if http not typed 
            else{
            	pageUrl=new java.net.URL("http://"+thePage);
            }
            urlConnection=pageUrl.openConnection();
 			setTitle("NEOM - "+urlConnection.getContentType());
            ((java.net.HttpURLConnection)urlConnection).disconnect();
        }catch(java.net.MalformedURLException ex){javax.swing.JOptionPane.showMessageDialog( this,"Error retrieving specified URL", "Malformed URL",javax.swing.JOptionPane.ERROR_MESSAGE );}
        catch(java.io.IOException ioex){}
        finally{return pageUrl;}
    }
    //for progressbar's activity
    private void progressBarUtils(java.net.URL urlOff,java.net.URLConnection uconOff){
        try{
        	Jp p=new Jp();
            int size=uconOff.getContentLength();
            jProgressBar1.setMaximum(size);
            byte buffer[]=new byte[1024];
            long bytesRead=0,bytesDownloaded=0;
            java.io.BufferedInputStream instream = new java.io.BufferedInputStream(p.getMyStream(urlOff));
            while(bytesDownloaded < size){
                //bytesRead = instream.read(buffer);
                bytesDownloaded +=bytesRead+1;
                jProgressBar1.setValue((int)bytesDownloaded);
            }
            jProgressBar1.setValue(0);
            instream.close();
        }catch(java.io.IOException ec){javax.swing.JOptionPane.showMessageDialog( this,"progressbar io exception", "IoExc",javax.swing.JOptionPane.ERROR_MESSAGE );}
    }
    
    //some modifications on JEditorPane to get inputstream of the page
    class Jp extends javax.swing.JEditorPane{
    	public java.io.InputStream getMyStream(java.net.URL url){
    		java.io.InputStream stream=null;
    		try{
    			stream=getStream(url);
    			return stream;
    		}catch(java.io.IOException e){}
    		finally{return stream;}
    	}
    }
    //returns the current navigated page
    private String getCurrentPageName(){
        return (String)jComboBox2.getSelectedItem();
    }
    
    //connects to page
    private void connectPage(String page){
        java.net.URL url=myConnection(page);
        i=0;
        try{
	        if(url.getFile().lastIndexOf(".htm")!=-1||url.getFile().lastIndexOf(".html")!=-1||url.getFile().lastIndexOf(".asp")!=-1||url.getFile().lastIndexOf(".aspx")!=-1||url.getFile().lastIndexOf(".php")!=-1||url.getFile().lastIndexOf(".")==-1){
	            String currentPage=getCurrentPageName();
	            jEditorPane.setPage(url);
	            progressBarUtils(url, url.openConnection());
	            //bacward and forward button actions
	            if(bool){
	                backward.setEnabled(true);
	                backBox.setEnabled(true);
	                for(int count=0;count<backBox.getItemCount();count++){
	                    if(page.equals((String)backBox.getItemAt(count))){
	                        backBox.removeItemAt(count);
	                        frwBox.addItem(currentPage);
	                        currentPage=null;
	                        Forward.setEnabled(true);
	                        frwBox.setEnabled(true);
	                        break;
	                    }
	                }
	                backBox.addItem(page);
	            }
	            bool=true;
	        }
	        else{
	        	new DownloadStart(url);
	        }
        }catch(java.io.IOException e){
            javax.swing.JOptionPane.showMessageDialog( this,"Error no connection for URL", "ERROR",javax.swing.JOptionPane.ERROR_MESSAGE );
            i=1;
    	}
        finally{
        	if(i!=0){
        	    controlSave(myConnection(page).toString());
        	}
    	}
    }
    //controls saves for history
    private void controlSave(String pag){
        int yolla=0;
        try{
           /* java.io.FileReader fr=new java.io.FileReader("c:\\NEOM\\History\\pages.txt");
            java.io.BufferedReader br=new java.io.BufferedReader(fr);*/
            int b=0;
            while (b<k/*!br.readLine().equals(null)*/){
                if(pag.equals(oldUrl[b])){
                    yolla=1;
                } 
                b++;
            }
        }catch(Exception e){}
        for(int i=0;i<j;i++){
            if(pag.equals(url[i])){
                yolla=1;
            }                
        }
        if(yolla==0)save(pag);
    }
    //saves to history
    private void save(String pg){
        url[j]=pg;
        if(pg.substring(0,4).equals("http")) {
       		jComboBox2.addItem(url[j]); 
       		java.io.File dir=new java.io.File("c:\\NEOM");
	        java.io.File dir1=new java.io.File("c:\\NEOM\\History");
	        dir.mkdir();
	        dir1.mkdir();
	        try{
	            java.io.FileWriter fw=new java.io.FileWriter("c:\\NEOM\\History\\pages.txt",true);
	            java.io.BufferedWriter bw=new java.io.BufferedWriter(fw);
	            bw.write(url[j]);
	            bw.newLine();
	            bw.close();
	        }catch(Exception exc){}
	
	        j++;         
       	}
    }
    
    ////editorpanes size
  /*  private void getEditorSize(){
        java.awt.Dimension dim=jEditorPane.getSize();
        width=jEditorPane.getSize().getWidth();
    }*/
    /*-------------------------------------------------------------------------------------------------------------------
    |***************************PLEASE DO NOT FORGET TO ENTER NEW GUI BASED VARIABLES HERE******************************|
    -------------------------------------------------------------------------------------------------------------------*/
    //updates gui components for L&F changes
    private void updater(){
        jPanel1.updateUI();
        jPanel3.updateUI();
        jPanel4.updateUI();
        jPanel5.updateUI();
        bview.updateUI();
        Cut3.updateUI();
        Forward.updateUI();
        backward.updateUI();
        Home.updateUI();
        Refresh.updateUI();
        Stop.updateUI();
        exit.updateUI();
        file.updateUI();
        gtk_look.updateUI();
        jButton1.updateUI();
        jComboBox2.updateUI();
        jEditorPane.updateUI();
        jLabel1.updateUI();
        jLabel2.updateUI();
        jMenu2.updateUI();
        jMenu3.updateUI();
        jMenu4.updateUI();
        jMenu5.updateUI();
        jMenuBar1.updateUI();
        jMenuItem10.updateUI();
        jMenuItem11.updateUI();
        jMenuItem12.updateUI();
        jMenuItem4.updateUI();
        jMenuItem5.updateUI();
        jMenuItem6.updateUI();
        jMenuItem7.updateUI();
        jMenuItem8.updateUI();
        jMenuItem9.updateUI();
        jPanel1.updateUI();
        jPanel3.updateUI();
        jPanel4.updateUI();
        jPanel5.updateUI();
        jPopupMenu1.updateUI();
        jProgressBar1.updateUI();
        jScrollPane1.updateUI();
        jScrollPane1.getHorizontalScrollBar().updateUI();
        jScrollPane1.getVerticalScrollBar().updateUI();
        jSeparator1.updateUI();
        jSeparator2.updateUI();
        jSeparator3.updateUI();
        javalook.updateUI();
        newMenu.updateUI();
        open.updateUI();
        paste.updateUI();
        save_as.updateUI();
        unixlook.updateUI();
        winlook.updateUI();
        options.updateUI();
         //birle�tirilecek
        item.updateUI();
        int counter=0;
        while(bmenus[counter]!=null){
            bmenus[counter].updateUI();
            counter++;
        }
        homePage.updateUI();
        jSeparator6.updateUI();
        jSeparator4.updateUI();
        jSeparator5.updateUI();
        marmara_university.updateUI();
        programmersheaven.updateUI();
        google.updateUI();
        yahoo.updateUI();
        source.updateUI();
        backBox.updateUI();
        frwBox.updateUI();
        adding.updateUI();
        cutMenuItem.updateUI();
        pasteMenuItem.updateUI();
        copyMenuItem.updateUI();
        openMenuItem.updateUI();
        selectAllMenuItem.updateUI();
        
    }
    //when exited
    private void exitActionPerformed(java.awt.event.ActionEvent evt) {
       setVisible(false);
    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
        connectPage((String)jComboBox2.getEditor().getItem());
    }
    
    // go to hyperlinks on the page
    private void jEditorPaneHyperlinkUpdate(javax.swing.event.HyperlinkEvent evt) {
    	evth=evt;
        try{
            if(evt instanceof javax.swing.event.HyperlinkEvent){
                if(evt.getEventType()==javax.swing.event.HyperlinkEvent.EventType.ACTIVATED){
                    if(evt.getURL().toString().startsWith("file")){
                        jEditorPane.setPage(evt.getURL());
                    }
                    else{
                    	urlConnection=evt.getURL().openConnection();
                        connectPage(evt.getURL().toString());
                    }
                }
                else if(evt.getEventType()==javax.swing.event.HyperlinkEvent.EventType.ENTERED){
                    jEditorPane.setToolTipText(evt.getURL().toString());
                    jLabel1.setText(evt.getURL().toString());
                    openMenuItem.setEnabled(true);
                    
	                openMenuItem.addActionListener(new java.awt.event.ActionListener() {
		    	    		public void actionPerformed(java.awt.event.ActionEvent evtk) {
		    	    			try{
			            			if(evth.getURL().toString().startsWith("file")){
			                    		jEditorPane.setPage(evth.getURL());
			                		}
			                		else{
			                			urlConnection=evth.getURL().openConnection();
			               	 	    	connectPage(evth.getURL().toString());
			                		}
			                	}catch(java.io.IOException io){}	
		        			}
	    			});
                }
                else if(evt.getEventType()==javax.swing.event.HyperlinkEvent.EventType.EXITED){
                    jEditorPane.setToolTipText(null);
                    jLabel1.setText(null);
                    openMenuItem.setEnabled(false);
                }
            }
            //for FrameHyperlink
      		if(evt instanceof javax.swing.text.html.HTMLFrameHyperlinkEvent){
		        if(evt.getEventType()==javax.swing.text.html.HTMLFrameHyperlinkEvent.EventType.ACTIVATED){
		                connectPage(evt.getURL().toString());
		        }
		        else if(evt.getEventType()==javax.swing.text.html.HTMLFrameHyperlinkEvent.EventType.ENTERED){
		            jEditorPane.setToolTipText(evt.getURL().toString());
	                    jLabel1.setText(evt.getURL().toString());
	                }
		        else if(evt.getEventType()==javax.swing.text.html.HTMLFrameHyperlinkEvent.EventType.EXITED){
		            jEditorPane.setToolTipText(null);
	                    jLabel1.setText(null);
	                }
		    	}
        }catch(java.io.IOException iex){javax.swing.JOptionPane.showMessageDialog(null,"Error retrieving URL(Probably no internet connection)","Error",javax.swing.JOptionPane.ERROR_MESSAGE);}
    }
    
    //to open a page locally
    private void openActionPerformed(java.awt.event.ActionEvent evt) {//event_openActionPerformed
        try{
            javax.swing.JFileChooser ch=new javax.swing.JFileChooser();
            ch.setFileSelectionMode(javax.swing.JFileChooser.FILES_ONLY);
            int i=ch.showOpenDialog(jEditorPane);
            java.io.File f=ch.getSelectedFile();
            jEditorPane.setPage("file://"+f.getAbsolutePath());
	}catch(Exception ec){}
    }
    
    /** Exit the Application */
    private void exitForm(java.awt.event.WindowEvent evt) {
        setVisible(false);
    }
    //backward buttons combobox action
    private void backBoxActionPerformed(java.awt.event.ActionEvent evt){
        connectPage((String)backBox.getEditor().getItem());
    }
    //forward button combobox action
    private void frwBoxActionPerformed(java.awt.event.ActionEvent evt){
        connectPage((String)frwBox.getSelectedItem());
    }
    /**main method***/
    public static void main(String args[]) {
        //Splash at the begining
        Start a=new Start();
        a.run();
        //Browser
        new Gooo().setVisible(true);
        //adds draganddrop property to the browser
        new draganddropProperty(jEditorPane);
        //************************************
         try {
            java.io.FileReader fr=new java.io.FileReader("c:\\NEOM\\History\\pages.txt");
            java.io.BufferedReader br=new java.io.BufferedReader(fr);
            notConnect=1;
            oldUrl[k]=br.readLine();
            jComboBox2.addItem(oldUrl[k]);
            while(!oldUrl[k].equals(null)){
                oldUrl[k+1]=br.readLine();
                if(oldUrl[k+1].equals(null))continue;
                jComboBox2.addItem(oldUrl[k+1]); 
                k++;
            }
            br.close();
            notConnect=0;
        }
        catch(Exception e){}
    }
    class PopupListener extends java.awt.event.MouseAdapter {
		public void mousePressed(java.awt.event.MouseEvent e) {
		    maybeShowPopup(e);
		}
		
		public void mouseReleased(java.awt.event.MouseEvent e) {
		    maybeShowPopup(e);
		}
		
		private void maybeShowPopup(java.awt.event.MouseEvent e) {
		    if (e.isPopupTrigger()) {
		    	if(jEditorPane.getSelectedText()!=null){
		    		cutMenuItem.setEnabled(true);
		    		copyMenuItem.setEnabled(true);
		    		pasteMenuItem.setEnabled(true);
		    	}
		    		
		        jPopupMenu1.show(e.getComponent(),
		                   e.getX(), e.getY());
		    }
		}
    }
    //global variables
    private javax.swing.JPanel NeomGifPanel;
    private javax.swing.JButton NeomGifButton;
    private javax.swing.JMenuItem historyReset;
    private javax.swing.JMenuItem favoritesReset;
    private javax.swing.JButton frwBoxButton;
    private javax.swing.JButton backwardBoxButton;
    private javax.swing.JMenuItem cutMenuItem;
    private javax.swing.JMenuItem copyMenuItem;
    private javax.swing.JMenuItem pasteMenuItem;
    private javax.swing.JMenuItem selectAllMenuItem;
    private javax.swing.JMenuItem openMenuItem;
    private javax.swing.JSeparator menuSep;
    private String url[]=new String[500],sourceName;
    private static String oldUrl[]=new String[500];
    private String selected;
    private int i,j,cont,globalCounter;
    private static int k,notConnect;
    private static int wth;
  //  private double width;
    private java.net.URL pageUrl;
    private java.net.URLConnection urlConnection;
    private java.io.File bookmarkFile;
    private javax.swing.JMenuItem bmenus[];
    private int count;
    private javax.swing.JMenuItem item;
    private javax.swing.JComboBox backBox;
    private javax.swing.JComboBox frwBox;
    private boolean bool=false;
    private javax.swing.event.HyperlinkEvent evth;
    private javax.swing.JMenuItem Cut3;
    private javax.swing.JButton Forward;
    private javax.swing.JButton Home;
    private javax.swing.JButton Refresh;
    private javax.swing.JButton Stop;
    private javax.swing.JMenuItem adding;
    private javax.swing.JButton backward;
    private javax.swing.JMenu bview;
    private javax.swing.JMenuItem exit;
    private javax.swing.JDialog favdialog;
    private javax.swing.JMenu file;
    private javax.swing.JMenuItem google;
    private javax.swing.JRadioButtonMenuItem gtk_look;
    private javax.swing.JMenuItem homePage;
    private javax.swing.JButton jButton1;
    private static javax.swing.JComboBox jComboBox2;
    public static javax.swing.JEditorPane jEditorPane;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem10;
    private javax.swing.JMenuItem jMenuItem11;
    private javax.swing.JMenuItem jMenuItem12;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JMenuItem jMenuItem9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator11;
    private javax.swing.JSeparator jSeparator12;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JRadioButtonMenuItem javalook;
    private javax.swing.ButtonGroup lookgroup;
    private javax.swing.JMenuItem marmara_university;
    private javax.swing.JMenuItem newMenu;
    private javax.swing.JMenuItem open;
    private javax.swing.JMenu options;
    private javax.swing.JMenuItem paste;
    private javax.swing.JMenuItem programmersheaven;
    private javax.swing.JMenuItem save_as;
    private javax.swing.JMenuItem source;
    private javax.swing.JRadioButtonMenuItem unixlook;
    private javax.swing.JRadioButtonMenuItem winlook;
    private javax.swing.JMenuItem yahoo;
    // End of variables declaration//variables
}