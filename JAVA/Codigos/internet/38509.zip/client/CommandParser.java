/*
	Class: CommandParser
	Project: XtremePC
	Version: 1.0.6

	Copyright � 2004-2005 Md. Tanzim Saqib
	Website: www.tanzimsaqib.tk
	Email: zimHere@gmail.com
	Cell: +88 011115701

	Use this project at your own risk and in educational purposes.
	However, feel free to disturb me! :)
	Feel free to distribute and re-distribute this project.
	Feel free to add new features.
	Suggestions are welcomed.
*/

import java.util.regex.*;
import java.net.*;
import java.io.*;

public class CommandParser implements Serializable
{
	public static InetAddress ia;
	public static Service service;
	public static DESECB d;
	public static String key;
	public static String path;		
	
	public CommandParser(InetAddress ia, Service service)
	{
		d = new DESECB();
		key = "Xtr3m3pc";
		path="c:\\";
		this.ia = ia;
		this.service = service;
	}
	
	public void cmd(String s) throws Exception
	{
		service.issuedCommand(d.desEncrypt(key, s));
		Pattern pat = Pattern.compile("[ ]");
		String[] c = pat.split(s);
		
		if(c[0].equals("exit"))
		{
			System.exit(0);
		}		
		else if(c[0].equals("echo"))
		{
			System.out.println(" # "+d.desDecrypt(key, service.echo(d.desEncrypt(key, s.substring(5)))));
		}
		else if(c[0].equals("say"))
		{
			service.say(d.desEncrypt(key, s.substring(4)));
		}
		else if(c[0].equals("stopserver"))
		{
			service.stopServer();
			System.exit(0);
		}
		else if(c[0].equals("shutdownpc") || c[0].equals("restartpc") || c[0].equals("logoffpc") || c[0].equals("lockpc"))
			service.pc(d.desEncrypt(key,c[0]));
		else if(c[0].equals("runningtasks"))
		{
			System.out.println(service.pc(d.desEncrypt(key, c[0])));
		}
		else if(c[0].equals("execute"))
			service.execute(d.desEncrypt(key, s.substring(8)));
		else if(c[0].equals("dir"))
		{
			service.dir(path);
			System.out.println("Directory listing is saved as: Dir.txt. Issue download Dir.txt.");
		}
		else if(c[0].equals("upload"))
		{			
			service.getFile(upload(c[1]), c[1]);
			System.out.println(" * Filename: "+c[1]+". Uploaded.");
		}
		else if(c[0].equals("download"))
		{
			int ch[] = service.dload(c[1]);
			if(ch.length<=0)
			{
				System.out.println(" * File NOT found.");
				return;
			}
			else
			{
				FileOutputStream to = new FileOutputStream(c[1]);
				for(int i=0; i<ch.length; ++i)
					to.write((char)ch[i]);
				to.close();
				System.out.println(" * Filename: "+c[1]+", Size: "+ch.length+" bytes. Downloaded.");
			}
		}
		else if(c[0].equals("dload"))
		{
			String tmp;
			if(path.length()>3)
				tmp = path+"\\"+c[1];
			else 
				tmp = path+c[1];
			int ch[] = service.dload(tmp);
			if(ch.length<=0)
			{
				System.out.println(" * File NOT found.");
				return;
			}
			else
			{
				FileOutputStream to = new FileOutputStream(c[1]);
				for(int i=0; i<ch.length; ++i)
					to.write((char)ch[i]);
				to.close();
				System.out.println(" * Filename: "+c[1]+", Size: "+ch.length+" bytes. Downloaded.");
			}
		}
		else if(c[0].equals("pwd"))		
		{
			System.out.println(" # Present working directory: "+path);
		}
		else if(c[0].equals("drive"))
		{
			if(service.chkPath(c[1]+":\\")==true)
			{
				path = c[1]+":\\";
				System.out.println(" * Drive changed to: "+path);
			}
			else
			{
				System.out.println(" ! Invalid drive: "+c[1]+":\\");
			}
		}
		else if(c[0].equals("cd"))
		{
			if(c[1].equals(".."))
			{
				if(path.length()>3)
				{
					String tmp;
					tmp = path.substring(0, path.lastIndexOf("\\"));
				
					if(service.chkPath(tmp)==true)
					{
						path = tmp;
						System.out.println(" * Directory changed to: "+tmp);
					}
					else
					{
						System.out.println(" ! Invalid drive: "+tmp);
					}
				}
			}
			else if(c[1].equals("\\"))
			{
				path=path.substring(0,1)+":\\";
				System.out.println(" * Directory changed to: "+path);
			}
			else
			{
				if(path.length()>3)				
				{
					if(service.chkPath(path+"\\"+c[1])==true)
					{
						path = path+"\\"+c[1];
						System.out.println(" * Directory changed to: "+path);
					}
					else
					{
						System.out.println(" ! Invalid path: "+path+"\\"+c[1]);
					}
				}
				else
				{
					if(service.chkPath(path+c[1])==true)
					{
						path = path+c[1];
						System.out.println(" * Directory changed to: "+path);
					}
					else
					{
						System.out.println(" ! Invalid path: "+path+c[1]);
					}					
				}
			}
		}
		else
			System.out.println(" @ Unknown command");
	}
	
	public int[] upload(String s) throws Exception
	{
		int str[] = new int[256];
		
		try
		{
			File f = new File(s);
			int size, ch;
			size = (int)f.length();
			str = new int[size];
			
			FileInputStream fr = new FileInputStream(s);
			ch = (int)fr.read();
			for(int i=0; i<size && ch!=-1; ++i)
			{
				str[i]=ch;
				ch = (int)fr.read();
			}
			fr.close();
		}
		catch(Exception e)
		{
			System.out.println(" ! Client(upoad): "+e.getMessage());			
		}
		return str;
	}
}