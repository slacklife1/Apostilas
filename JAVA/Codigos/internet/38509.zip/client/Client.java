/*
	Class: Client
	Project: XtremePC
	Version: 1.0.6

	Copyright � 2004-2005 Md. Tanzim Saqib
	Website: www.tanzimsaqib.tk
	Email: zimHere@gmail.com
	Cell: +88 011115701

	Use this project at your own risk and in educational purposes.
	However, feel free to disturb me! :)
	Feel free to distribute and re-distribute this project.
	Feel free to add new features.
	Suggestions are welcomed.
*/

/*
	Look up the object from the host using Naming.lookup, cast it to the appropriate type, then use it like a local object.
*/

import java.rmi.*;
import java.io.*;
import java.net.*;

public class Client
{
	public static CommandParser cp;
		
	public Client()
	{
	}

	public void actionPerformed(ActionEvent e)
	{
		String msg=e.getActionCommand();
		if(msg.equals("Exit"))
			System.exit(0);
		label1.setText(f.getText());
	}   

	public static void main(String args[]) throws Exception
	{
		System.out.println("\n[ Welcome to XtremePC (Client) ]\n\nDeveloped by: Md. Tanzim Saqib.\nID: 03-03666-1, Computer Science, AIUB\nwww.tanzimsaqib.tk\n");
		
		// init vars
		InetAddress ia = InetAddress.getLocalHost();
		DESECB d = new DESECB();
		String key = "Xtr3m3pc";
		
		// assign security manager
		if(System.getSecurityManager()==null)
			System.setSecurityManager(new RMISecurityManager());
		
		// lookup server
		String p = null;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		if(args.length==0)
		{
			System.out.print("Enter server IP: ");
			p = br.readLine();
		}
		Service service = (Service)Naming.lookup("rmi://"+p+"/Service");
		cp = new CommandParser(ia, service);

		// Authorize user
		System.out.print("Enter server password: ");
		p = br.readLine();
		if(service.connect(ia, d.desEncrypt(key, p)))	
			System.out.println(" * Server password accepted.\n");
		else
		{
			System.out.println(" * Incorrect password. Access denied. Exiting..\n");	
			System.exit(0);
		}

		// get commands
		System.out.print(" > ");
		while((p=br.readLine())!=null)
		{
			try
			{
				cp.cmd(p);
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			System.out.print(" > ");
		}
	}
}