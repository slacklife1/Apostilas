/*
	Class: RMIServer
	Project: XtremePC
	Version: 1.0.6

	Copyright � 2004-2005 Md. Tanzim Saqib
	Website: www.tanzimsaqib.tk
	Email: zimHere@gmail.com
	Cell: +88 011115701

	Use this project at your own risk and in educational purposes.
	However, feel free to disturb me! :)
	Feel free to distribute and re-distribute this project.
	Feel free to add new features.
	Suggestions are welcomed.
*/

/*
	The Remote Object Implementation. This class must extend UnicastRemoteObject and
	implement the remote object interface defined earlier. The constructor should throw RemoteException.
	The server builds an object and register it with a particular URL. Use Naming.rebind (replace any previous bindings) or
	Naming.bind(throw AlreadyBoundException if a previous binding exists)
*/

import java.rmi.*;
import java.rmi.server.*;
import java.net.*;
import java.io.*;

public class RMIServer extends UnicastRemoteObject implements Service
{
	public static String pwd;
	public static InetAddress ia;
	public static DESECB d;
	public static String key;

	public RMIServer() throws RemoteException
	{
		super();
		d = new DESECB();
		key = "Xtr3m3pc";
	}

	public void issuedCommand(String s) throws RemoteException
	{
		System.out.println(" # Client issued: "+d.desDecrypt(key, s));
	}

	public boolean connect(InetAddress a, String p) throws RemoteException
	{
		if(pwd.equals(d.desDecrypt(key, p)))
		{
			System.out.println(" * "+a+" connected.\n");
			return true;
		}
		return false;
	}

	public void say(String s) throws RemoteException
	{
		System.out.println(" * Client says: "+d.desDecrypt(key, s));
	}

	public String echo(String s) throws RemoteException
	{
		return d.desEncrypt(key, d.desDecrypt(key, s));
	}

	public boolean chkPath(String p) throws RemoteException
	{
		File f = new File(p);
		if(f.exists())
		{
			if (f.isDirectory())
				return true;
			return false;
		}
		return false;
	}

	public void getFile(int ch[], String name) throws RemoteException
	{
		try
		{
			if(ch.length<=0)
			{
				System.out.println(" * File NOT found.");
				return;
			}
			else
			{
				System.out.println(" * Filename: "+name+", Size: "+ch.length+" bytes. Downloaded.");
				FileOutputStream to = new FileOutputStream(name);
				for(int i=0; i<ch.length; ++i)
					to.write((char)ch[i]);
				to.close();
			}
		}
		catch(Exception e)
		{
			System.out.println(" ! Server(getFile): "+e);
		}
	}

	public void dir(String p) throws RemoteException
	{
		try
		{
			FileWriter fw = new FileWriter("dir.txt");
			String str = new String("Listing of "+p+"\r\n");
			File f = new File(p);
			String s[] = f.list();
			for(int i=0; i<s.length; ++i)
			{
				File n = new File(p+"/"+s[i]);
				if(n.isDirectory())
					str = str + "\r\n"+s[i]+" is a directory.";
				else
					str = str + "\r\n"+s[i]+" is a file ["+n.length()+"] bytes.";
			}
			fw.write(str);
			fw.close();
		}
		catch(Exception e)
		{
			System.out.println(" ! Server(dir): "+e);
		}
	}

	public int[] dload(String s) throws RemoteException
	{
		int str[] = new int[256];

		try
		{
			File f = new File(s);
			int size, ch;
			size = (int)f.length();
			str = new int[size];

			FileInputStream fr = new FileInputStream(s);
			ch = (int)fr.read();
			for(int i=0; i<size && ch!=-1; ++i)
			{
				str[i]=ch;
				ch = (int)fr.read();
			}
			fr.close();
			System.out.println(" * Filename: "+s+". Uploaded.");
		}
		catch(Exception e)
		{
			System.out.println(" ! Server(dload): "+e.getMessage());
		}
		return str;
	}

	public String pc(String c) throws RemoteException
	{
		try
		{
			c = d.desDecrypt(key, c);
			Runtime r = Runtime.getRuntime();
			Process p;
			if(c.equals("shutdownpc"))
			{
				p = r.exec("win.exe shutdownpc");
			}
			else if(c.equals("restartpc"))
			{
				p = r.exec("win.exe restartpc");
			}
			else if(c.equals("runningtasks"))
			{
				p = r.exec("win.exe runningtasks");
				p.waitFor();
				return "Running tasks saved as: RunTasks.txt. Issue download RunTasks.txt.";
			}
			else if(c.equals("lockpc"))
			{
				p = r.exec("win.exe lockpc");
				p.waitFor();
			}
			else
			{
				p = r.exec("win.exe logoffpc");
			}
		}
		catch(Exception e)
		{
			System.out.println(" ! Server(turnoffpc): "+e.getMessage());
		}
		return "";
	}

	public void execute(String c) throws RemoteException
	{
		try
		{
			c = d.desDecrypt(key, c);
			Runtime r = Runtime.getRuntime();
			Process p;
			p = r.exec(c);
		}
		catch(Exception e)
		{
			System.out.println(" ! Server(execute): "+e.getMessage());
		}
	}

	public void stopServer() throws RemoteException
	{
		System.exit(0);
	}

	public void exit(InetAddress s) throws RemoteException
	{
		System.out.println("\n * "+s+" disconnected.\n");
	}

	public static void main(String args[]) throws Exception
	{
		System.out.println("\n[ Welcome to XtremePC (Server) ]\n\nDeveloped by: Md. Tanzim Saqib.\nID: 03-03666-1, Computer Science, AIUB\nwww.tanzimsaqib.tk\n");

		// assign a security manager
		if(System.getSecurityManager()==null)
			System.setSecurityManager(new RMISecurityManager());

		// create and bind the server
		RMIServer server = new RMIServer();
		Naming.bind("Service", server);

		// Set Server password
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Enter server password: ");
		pwd = new String(br.readLine());

		// server is up
		ia = InetAddress.getLocalHost();
		System.out.println("\nRMIServer is running and up... ["+ia+"]\n");
	}
}