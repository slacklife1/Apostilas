/*
	Class: Service
	Project: XtremePC
	Version: 1.0.6

	Copyright � 2004-2005 Md. Tanzim Saqib
	Website: www.tanzimsaqib.tk
	Email: zimHere@gmail.com
	Cell: +88 011115701

	Use this project at your own risk and in educational purposes.
	However, feel free to disturb me! :)
	Feel free to distribute and re-distribute this project.
	Feel free to add new features.
	Suggestions are welcomed.
*/

/*
	The Display Interface for the Remote Object. The interface should extend java.rmi.Remote,
	and all its methods should throw java.rmi.RemoteException       
*/
import java.rmi.*;
import java.net.*;
import java.io.*;

/*
	The RMI Client will use this interface directly. The RMI Server will make a real remote object that
	implements this, then register an instance of it with some URL.
*/
public interface Service extends Remote
{
	public boolean connect(InetAddress ia, String p) throws RemoteException;
	public void issuedCommand(String s) throws RemoteException;
	public void say(String s) throws RemoteException;
	public String echo(String s) throws RemoteException;
	public int[] dload(String s) throws RemoteException;
	public void getFile(int ch[], String name) throws RemoteException;
	public boolean chkPath(String p) throws RemoteException;
	public void dir(String p) throws RemoteException;
	public String pc(String c) throws RemoteException;
	public void stopServer() throws RemoteException;
	public void execute(String c) throws RemoteException;
	public void exit(InetAddress s) throws RemoteException;
}