1.01	18 March 2005
	Added configuration trapinput e trapoutput parameter when
	set to yes any nopt handled input/output stop the emulator.
	Added preliminary support for speker emulator for spectrum
	48k/128k.

1.00	20 July 2004
	Added preliminary supportfor spectrum 128K.
	Added button to stop/resume/snapshot in Spectrum emulator.

0.00 Beta
	First public release.

