/**
 * $Id: MCB900.java,v 1.3 2005/12/07 08:41:19 mviara Exp $
 * $Name:  $
 *
 *
 * Keil MCB900 Evaluation board.
 *
 * The following application are tested :
 * 
 *  - Measure
 *  - Blinky
 *
 * $Log: MCB900.java,v $
 * Revision 1.3  2005/12/07 08:41:19  mviara
 * Removed unused code.
 *
 * Revision 1.2  2005/11/29 03:48:50  mviara
 * Added led name.
 *
 * Revision 1.1  2005/11/28 00:00:33  mviara
 * First version of MCB900
 *
 *
 */
package j51.keil;

import j51.intel.*;
import j51.util.Hex;
import j51.swing.*;
import j51.philips.*;

import java.awt.*;
import javax.swing.*;
import java.util.Vector;
import java.net.*;

class MCB900PCB extends JLabel
{
	private int led = 0;
	private Color on = new Color(0,255,0);
	private Color off = new Color(255,255,255);
	
	MCB900PCB()
	{
		URL url = ClassLoader.getSystemResource("j51/keil/images/mcb900.jpg");
		ImageIcon icon = new ImageIcon(url);
		setIcon(icon);
	}

	public void paint(Graphics g)
	{
		super.paint(g);
		for (int i = 0 ; i < 8 ; i++)
		{
			Color c = off;
			if ((led & (1 << i)) != 0)
				c = on;
			g.setColor(c);
			g.fill3DRect(185+(7-i)*13,5,8,12,false);
		}
	}

	void led(int led)
	{
		if (this.led != led)
		{
			this.led = led;
			repaint();
		}
	}
}

class MCB900Port extends JPanel implements MCS51Peripheral, SfrWriteListener
{
	JLed leds[];
	MCB900PCB pcb = new MCB900PCB();
			
	MCB900Port()
	{
		super(new GridBagLayout());

		JFactory.setTitle(this,"MCB900");

		GridBagConstraints g = new GridBagConstraints();
		g.gridx = 0; g.gridy = 0;g.gridwidth = 1;g.gridheight = 1;
		g.anchor = g.CENTER; g.fill = g.NONE; 
		g.insets = new Insets(1,1,1,1);

		add(pcb,g);
	}
	
	public void registerCpu(MCS51 cpu)
	{
		cpu.addSfrWriteListener(MCS51Constants.P2,this);
	}


	public void sfrWrite(int reg,int value)
	{
		pcb.led(value);
		
	}
	
}

public class MCB900 extends j51.philips.LPC900
{
	public MCB900() throws Exception
	{
		super("MCB900");
		addPeripheral(new MCB900Port());

		JPort port = (JPort)getPeripheralByClass("j51.intel.JPort");
		for (int i = 0 ; i < 8 ; i++)
			port.setPortName(2,i,"LED"+i);
	}
	
}


