/**
 * $Id: SfrReadListener.java,v 1.1.1.1 2004/08/22 06:46:25 mviara Exp $
 * $Name:  $
 *
 * $Log: SfrReadListener.java,v $
 * Revision 1.1.1.1  2004/08/22 06:46:25  mviara
 * 8051 emulator
 *
 */
package j51.intel;

/**
 * Interface to read one SFR register. Only one interface is available
 * for any SFR.
 */
public interface SfrReadListener
{
	public int sfrRead(int r);
}
