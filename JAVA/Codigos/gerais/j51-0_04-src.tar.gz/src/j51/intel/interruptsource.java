/**
 * $Id: InterruptSource.java,v 1.2 2005/11/11 06:33:36 mviara Exp $
 * $Name:  $
 *
 * Interface for implements one interrupt source, this interface is
 * used when a SFR coinvolted is written.
 * 
 * $Log: InterruptSource.java,v $
 * Revision 1.2  2005/11/11 06:33:36  mviara
 * Removed unused code and remark.
 *
 * Revision 1.1.1.1  2004/08/22 06:46:25  mviara
 *
 */
package j51.intel;

public interface InterruptSource
{
	/**
	 * Return true if the interrupt condition is true
	 */
	public boolean		interruptCondition();

	/**
	 * Return the address of the interrupt service.
	 */
	public int		getInterruptVector();

	/**
	 * Called before to execute the interrupt service.
	 */
	public void		interruptStart();

	/**
	 * Called after the interrupt service is terminated.
	 */
	public void		interruptStop();
}
