/**
 * $Id: FlashCode.java,v 1.2 2005/11/15 23:23:28 mviara Exp $
 * $Name:  $
 *
 * Implementation of code in flash memory.
 *
 * $Log: FlashCode.java,v $
 * Revision 1.2  2005/11/15 23:23:28  mviara
 * Added header.
 *
 */
package j51.intel;

import java.io.*;

public class FlashCode extends PersistentBuffer implements Code
{
	
	public FlashCode(String name,int size)
	{
		super(name,"flash",size);
	}

	public void setCodeSize(int size)
	{
	}

	public int getCodeSize()
	{
		return getSize();
	}

	public int getCode(int addr)
	{
		return get(addr);
	}

	public void setCode(int addr,int value)
	{
		set(addr,value);
	}

}
