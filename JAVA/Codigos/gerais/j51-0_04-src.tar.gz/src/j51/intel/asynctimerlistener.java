/**
 * $Id: AsyncTimerListener.java,v 1.2 2005/11/11 07:16:42 mviara Exp $
 * $Name:  $
 *
 * $Log: AsyncTimerListener.java,v $
 * Revision 1.2  2005/11/11 07:16:42  mviara
 * Fixed bug in reset.
 *
 * Revision 1.1.1.1  2004/08/22 06:46:24  mviara
 * 8051 emulator
 *
 */
package j51.intel;

/**
 *
 * Interface to call one asyncronous timer
 *
 */
public interface AsyncTimerListener
{
	public void expired(MCS51 cpu) throws Exception;
}
