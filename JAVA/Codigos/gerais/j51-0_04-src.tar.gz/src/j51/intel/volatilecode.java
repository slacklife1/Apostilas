package j51.intel;

class VolatileCode implements Code
{
	private byte code[] = new byte[64*1024];
	
	public void setCodeSize(int size)
	{
		code = new byte[size];
		for (int i = 0 ; i < size ; i++)
			code[i] = (byte)0xff;
	}
	
	public int  getCodeSize()
	{
		return code.length;
	}
	
	public void setCode(int addr,int value)
	{
		code[addr] = (byte)value;
	}
	
	public int  getCode(int addr)
	{
		return code[addr] & 0xff;
	}
	
}
