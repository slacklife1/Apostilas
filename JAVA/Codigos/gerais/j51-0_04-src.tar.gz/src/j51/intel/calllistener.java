/**
 * $Id: CallListener.java,v 1.2 2005/11/27 23:51:23 mviara Exp $
 * $Name:  $
 *
 * Interface to intercept one call.
 *
 * $Log: CallListener.java,v $
 * Revision 1.2  2005/11/27 23:51:23  mviara
 * Added exception handling.
 *
 * Revision 1.1  2005/11/15 23:25:39  mviara
 *
 */
package j51.intel;

public interface CallListener
{
	public void call(MCS51 cpu,int pc) throws Exception;
}
