/**
 * $Id: MCS51Peripheral.java,v 1.1.1.1 2004/08/22 06:46:25 mviara Exp $
 * $Name:  $
 *
 * $Log: MCS51Peripheral.java,v $
 * Revision 1.1.1.1  2004/08/22 06:46:25  mviara
 * 8051 emulator
 *
 */
package j51.intel;

/**
 * Interface for MCS51 peripheral
 */
public interface MCS51Peripheral
{
	/**
	 * Register the cpu to the peripheral
	 */
	public void registerCpu(MCS51 cpu);

}

