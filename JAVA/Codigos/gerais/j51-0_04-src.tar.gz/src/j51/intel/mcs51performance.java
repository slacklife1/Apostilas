package j51.intel;

public interface MCS51Performance
{
	public void cpuPerformance(int perc);
}

