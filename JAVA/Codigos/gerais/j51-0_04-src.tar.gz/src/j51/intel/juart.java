/**
 * $Id: JUart.java,v 1.9 2006/01/08 16:36:31 mviara Exp $
 * $Name:  $
 *
 * Standard 8051 uart implementation, no baud rate are used but only
 * the send and receive char from the SBUF register.
 *
 *
 *
 * Revision 1.5  2005/11/08 21:44:51  mviara
 * Added support for interrupt.
 *
 * Revision 1.4  2005/11/02 08:18:06  mviara
 * Added not proportional font.
 *
 * Revision 1.3  2005/10/23 20:41:44  mviara
 * Removed some remark error.
 *
 * Revision 1.2  2004/08/24 09:10:07  mviara
 * Added support for event in the run queue.
 * Added support for receiving char form the serial without interrupt.
 *
 * Revision 1.1.1.1  2004/08/22 06:46:25  mviara
 * 8051 emulator
 *
 */
package j51.intel;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Vector;

import j51.util.Hex;
import j51.swing.*;

class Uart implements MCS51Constants
{
	private byte rxBuffer[] = new byte[1024];
	private int rxPl,rxPs;
	private int scon = 0;
	private int sbuf = '?';
	private boolean rxRequest = false;
	private MCS51 cpu;

	synchronized void dequeue()
	{
		if (((scon & SCON_RI) == 0) && !rxRequest)
		{
			rxRequest = true;
			cpu.addRunQueue(new Runnable()
			{
				public void run()
				{
					sbuf = rxBuffer[rxPl];
					cpu.sfrSet(SCON,SCON_RI);
					rxRequest = false;
				}
			});
		}
	}
	
	void putchar(int c)
	{
		int newPs = (rxPs + 1) & (rxBuffer.length - 1);
		if (newPs != rxPl)
		{
			rxBuffer[rxPs] = (byte)c;
			rxPs = newPs;
		}
		dequeue();
	}
	
	void addChar(int c)
	{
	}
	

	public void sfrWrite(int r,int v)
	{
		switch (r)
		{
			case	SBUF:
				addChar(v);
				cpu.sfrSet(SCON,SCON_TI);
				break;
			case	SCON:
				scon = v;
				dequeue();
				break;
		}
	}
}

public class JUart extends JPanel implements MCS51Peripheral,
	SfrWriteListener,SfrReadListener,MCS51Constants,KeyListener,
	InterruptSource
{
	private JTextArea textArea = new JTextArea(1000,80);
	private int sbuf = '?';
	private MCS51 cpu;
	
	public JUart()
	{
		super(new BorderLayout());
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		screen.height /= 3;
		screen.width  /= 3;

		textArea.setLineWrap(true);
		setPreferredSize(screen);
		
		JFactory.setTitle(this,"Uart");
		textArea.setForeground(Color.green);
		textArea.setBackground(Color.black);
		
		add(new JScrollPane(textArea,
			  JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
			  JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS),BorderLayout.CENTER);
		Font font = textArea.getFont();
		font = new Font("Monospaced",font.PLAIN,font.getSize());
		textArea.setFont(font);
		textArea.addKeyListener(this);
	}


	public void keyTyped(KeyEvent e)
	{
		e.consume();
	}

	public void keyPressed(KeyEvent e)
	{
		char c = e.getKeyChar();

		/**
		 * Convert VK_ENTER,CTRL-J,CTRL-M in CR
		 */
		if (e.getKeyCode() == e.VK_ENTER)
			c = 13;

		if (c == 10)
			c = 13;
		
		if (c != e.CHAR_UNDEFINED)
		{
			sbuf = c;
			cpu.addRunQueue(new Runnable()
			{
				public void run()
				{
					cpu.sfrSet(SCON,SCON_RI);
				}
			});
		}
		e.consume();
	}

	public void keyReleased(KeyEvent e)
	{
		e.consume();
	}

	public void registerCpu(MCS51 cpu)
	{
		this.cpu = cpu;
		cpu.addSfrWriteListener(MCS51Constants.SBUF,this);
		cpu.addSfrReadListener(MCS51Constants.SBUF,this);
		cpu.addInterruptSource(MCS51Constants.IE,this);
		cpu.addInterruptSource(MCS51Constants.SCON,this);
	}

	public int sfrRead(int r)
	{
		switch (r)
		{
			case	SBUF:
					return sbuf;

		}
		
		return 0;
	}

	public void sfrWrite(int r,int v)
	{
		byte b[] = new byte[1];
		switch (r)
		{
			case	SBUF:
					b[0] = (byte)v;
					if ((v < 32 || v >= 127) && v != 13 && v != 10 && v != 9 && v != 8)
					{
						String s = "<"+j51.util.Hex.bin2byte(v)+">";
						textArea.append(s);
					}
					else
						textArea.append(new String(b));
					
					textArea.setCaretPosition(textArea.getDocument().getLength());

					// Keep the text area down to a certain character size
					int idealSize = 20 * 1024;
					int maxExcess = 500;
					int excess = textArea.getDocument().getLength() - idealSize;
					if (excess >= maxExcess) 
						textArea.replaceRange("", 0, excess);
					cpu.sfrSet(SCON,SCON_TI);
					break;
		}
	}

	public int getInterruptVector()
	{
		return 0x0023;
	}
	
	public void interruptStart()
	{
	}

	public void interruptStop()
	{
	}

	public boolean interruptCondition()
	{
		if ((cpu.sfr(IE) & IE_ES) != 0 && (((cpu.sfr(SCON) & SCON_RI) != 0) ||
						   ((cpu.sfr(SCON) & SCON_TI) != 0)))
			return true;

		return false;
	}

}

