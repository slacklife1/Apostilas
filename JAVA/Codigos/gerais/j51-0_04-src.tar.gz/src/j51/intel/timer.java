/**
 * $Id: Timer.java,v 1.4 2005/11/12 00:34:04 mviara Exp $
 * $Name:  $
 * 
 * Standard 8051 timer 0 and 1 implementation. Only mode 0,1,2 are
 * supported and only in the timer mode no counter or gate enable are
 * supported.
 *
 * $Log: Timer.java,v $
 * Revision 1.4  2005/11/12 00:34:04  mviara
 * Fixed bug in timer mode 2.
 *
 *
 */

package j51.intel;

import j51.util.Hex;

public class Timer implements MCS51Peripheral,MachineCyclesListener,MCS51Constants
{
	/**
	 * Implementation of sincle timer
	 */
	class SingleTimer extends AbstractInterruptSource implements MCS51Constants
	{
		private MCS51 cpu;
		private int tconShift;
		private int tmodShift;
		private int TH;
		private int TL;
		private int TF;
		private int ET;
		private int timer;

		SingleTimer(int timer)
		{
			super(0x0b + timer * 0x10);
			tconShift = 2 * timer;
			tmodShift = 4 * timer;
			TH = MCS51Constants.TH0 + timer;
			TL = MCS51Constants.TL0 + timer;
			TF = TCON_TF0 << tconShift;
			ET = timer == 0 ? IE_ET0 : IE_ET1;
			this.timer = timer;
		}


		void registerCpu(MCS51 cpu)
		{
			this.cpu = cpu;
			cpu.addInterruptSource(MCS51Constants.IE,this);
			cpu.addInterruptSource(MCS51Constants.TCON,this);

		}

		void cycle(int n)
		{
			int tl,th;

			// Do nothing if timer not running
			int tcon = cpu.sfr(MCS51Constants.TCON) >> tconShift;
			if ((tcon & TCON_TR0) == 0)
				return;

			int tmod = cpu.sfr(TMOD) >> tmodShift;

			switch (tmod & (TMOD_T0_M0 | TMOD_T0_M1))
			{
				case	0:	// 13 bit timer
					tl = (cpu.sfr(TL) + n);
					cpu.sfr(TL,tl & 0x1f);

					if (tl > 0x1f)
					{
						th = (cpu.sfr(TH) + 1) & 0xff;
						cpu.sfr(TH,th);
						if (th == 0)
						{
							cpu.sfrSet(TCON,TF);
							//System.out.println("Timer"+timer+" TF13");
						}
					}

					break;

					// Mode 1
				case	TMOD_T0_M0:
					tl = (cpu.sfr(TL) + n);
					cpu.sfr(TL,tl);
					if (tl > 255)
					{
						
						th = (cpu.sfr(TH) + 1) & 0xff;
						cpu.sfr(TH,th);
						if (th == 0)
						{

							cpu.sfrSet(TCON,TF);
						}
					}
					break;
					
					// Mode 2
				case	TMOD_T0_M1:
					while (n-- > 0)
					{
					tl = (cpu.sfr(TL) + 1) & 0xff;

					if (tl == 0)
					{
						cpu.sfr(TL,cpu.sfr(TH));
						cpu.sfrSet(TCON,TF << tconShift);

					}
					else
						cpu.sfr(TL,tl);
					}
					break;

			}

		}

		public void interruptStart()
		{
			cpu.sfrReset(TCON,TF);
		}


		public boolean interruptCondition()
		{
			if ((cpu.sfr(IE) & ET) != 0 && (cpu.sfr(TCON) & TF) != 0)
				return true;

			return false;
		}


		public String toString()
		{
			return "Timer"+timer+" at "+Hex.bin2word(vector);
		}
	}
	
	private MCS51 cpu;
	private SingleTimer timer0 = new SingleTimer(0);
	private SingleTimer timer1 = new SingleTimer(1);
	
	public void registerCpu(MCS51 cpu)
	{
		this.cpu = cpu;
		cpu.addMachineCycleListener(this);
		timer0.registerCpu(cpu);
		timer1.registerCpu(cpu);
	}
	
	public void cycles(int n)
	{
		timer0.cycle(n);
		timer1.cycle(n);
	}
}
