/*
 * $Id: SfrWriteListener.java,v 1.1.1.1 2004/08/22 06:46:25 mviara Exp $
 * $Name:  $
 *
 * $Log: SfrWriteListener.java,v $
 * Revision 1.1.1.1  2004/08/22 06:46:25  mviara
 * 8051 emulator
 *
 */
package j51.intel;

/*
 * Interface for write a SFR register. Many peripheral can implements
 * this interface.
 */
public interface SfrWriteListener
{
	public void sfrWrite(int r,int v);
}
