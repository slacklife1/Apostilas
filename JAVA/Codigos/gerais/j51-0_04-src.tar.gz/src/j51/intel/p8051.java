/**
 * $Id: P8051.java,v 1.2 2005/11/15 23:25:39 mviara Exp $
 * $Name:  $
 *
 * $Log: P8051.java,v $
 * Revision 1.2  2005/11/15 23:25:39  mviara
 * *** empty log message ***
 *
 * Revision 1.1.1.1  2004/08/22 06:46:25  mviara
 * 8051 emulator
 *
 *
 */

package j51.intel;

/**
 *
 * Standard 8051 microprocessor. With all peripheral.
 *
 */
public class P8051 extends MCS51
{
	public P8051() throws Exception
	{
		addPeripheral(new Timer());
		addPeripheral(new JPort(4));
		addPeripheral(new JUart());
	}

	public String toString()
	{
		return "Intel 8051  $Id: P8051.java,v 1.2 2005/11/15 23:25:39 mviara Exp $";
	}
}
