/**
 * $Id: Code.java,v 1.1 2005/10/23 20:10:46 mviara Exp $
 * $Name:  $
 *
 * Interface to code space
 *
 * $Log: Code.java,v $
 * Revision 1.1  2005/10/23 20:10:46  mviara
 * Added support for persistent data and input on port.
 *
 */
package j51.intel;

public interface Code
{
	public void setCodeSize(int size);
	public int  getCodeSize();
	public void setCode(int addr,int value);
	public int  getCode(int addr);
	
}
