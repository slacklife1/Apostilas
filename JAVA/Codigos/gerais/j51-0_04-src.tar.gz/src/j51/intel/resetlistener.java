package j51.intel;

/**
 * Interface for listener waiting reset cycle of the main cpu.
 */
public interface ResetListener
{
	/**
	 * Called when the main cpu is reset.
	 */
	public void reset(MCS51 cpu);
}
