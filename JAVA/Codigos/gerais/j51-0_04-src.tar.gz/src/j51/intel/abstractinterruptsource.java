/**
 * $Id: AbstractInterruptSource.java,v 1.1 2005/11/11 06:35:42 mviara Exp $
 * $Name:  $
 *
 * Abstract implementation of interrupt source.
 *
 * $Log: AbstractInterruptSource.java,v $
 * Revision 1.1  2005/11/11 06:35:42  mviara
 * *** empty log message ***
 *
 */
package j51.intel;

public abstract class AbstractInterruptSource implements InterruptSource
{
	protected int vector;

	public AbstractInterruptSource(int vector)
	{
		this.vector = vector;
	}

	public void interruptStart()
	{
	}

	public void interruptStop()
	{
	}


	public int getInterruptVector()
	{
		return vector;
	}

	
}
