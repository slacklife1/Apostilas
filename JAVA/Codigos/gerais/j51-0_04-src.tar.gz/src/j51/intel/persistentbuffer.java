/**
 * $Id: PersistentBuffer.java,v 1.4 2005/11/27 23:51:00 mviara Exp $
 * $Name:  $
 *
 * Class to implements persistend dato like eeprom or flash in u.
 *
 * $Log: PersistentBuffer.java,v $
 * Revision 1.4  2005/11/27 23:51:00  mviara
 * Added automatic save of changed date every second and not every
 * byte written.
 *
 * Revision 1.3  2005/11/08 21:45:13  mviara
 * Added support to initialize buffer.
 *
 * Revision 1.2  2005/10/28 15:32:14  mviara
 * Added header.
 *
 */
package j51.intel;

import java.io.*;
import javax.swing.Timer;

public class PersistentBuffer 
{
	private byte buffer[];
	private String filename;
	private boolean loaded = false;
	private Timer timer = null;
	
	public PersistentBuffer(String name,String suffix,int size)
	{
		buffer = new byte[size];
		filename = name+"."+size+"."+suffix;

		for (int i = 0 ; i < size ; i++)
			buffer[i] = (byte)0xff;

		try
		{
			FileInputStream is = new FileInputStream(new File(filename));
			is.read(buffer);
			is.close();
			loaded  = true;
			System.out.println(filename+" loaded");
		}
		catch (Exception ex)
		{
		}
	}

	public boolean isLoaded()
	{
		return loaded;
	}
	
	public int getSize()
	{
		return buffer.length;
	}

	public int get(int addr)
	{
		return buffer[addr] & 0xff;
	}

	public synchronized void set(int addr,int value)
	{
		byte b = (byte)(value & 0xff);

		if (buffer[addr] != b)
		{
			buffer[addr] = b;
			if (timer == null)
			{
				timer = new javax.swing.Timer(1000,new java.awt.event.ActionListener()
				{
					public void actionPerformed(java.awt.event.ActionEvent e)
					{
						timer.stop();
						save();
					}
				});
				timer.start();
			}
			else
				timer.restart();
						
		}
	}

	private synchronized void save()
	{
		try
		{
			FileOutputStream os = new FileOutputStream(new File(filename));
			os.write(buffer);
			os.close();
			System.out.println(filename+" saved");
		}
		catch (Exception ex)
		{
			System.out.println(ex);
		}
	}

}
