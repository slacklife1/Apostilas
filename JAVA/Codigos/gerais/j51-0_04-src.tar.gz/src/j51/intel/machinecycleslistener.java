/**
 * $Id: MachineCyclesListener.java,v 1.1.1.1 2004/08/22 06:46:25 mviara Exp $
 * $Name:  $
 *
 * $Log: MachineCyclesListener.java,v $
 * Revision 1.1.1.1  2004/08/22 06:46:25  mviara
 * 8051 emulator
 *
 */
package j51.intel;

/**
 * This listener must be implemented from the peripheral that must
 * 'polling' some event. The interface will be called from the cpu
 * after any instruction.
 */
public interface MachineCyclesListener
{
	/**
	 * Number of cpu cycles elapsed
	 */
	public void cycles(int cycles);
}
