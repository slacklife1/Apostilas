/**
 * $Id: J51.java,v 1.10 2005/11/28 00:02:57 mviara Exp $
 * $Name:  $
 *
 * $Log: J51.java,v $
 * Revision 1.10  2005/11/28 00:02:57  mviara
 * Changed label for debug.
 *
 * Revision 1.9  2005/11/13 09:18:36  mviara
 * Added support to edit clock.
 *
 * Revision 1.8  2005/11/11 07:16:42  mviara
 * Fixed bug in reset.
 *
 * Revision 1.7  2005/11/11 06:35:29  mviara
 * Improved statistics of cpu usage.
 *
 * Revision 1.6  2005/11/08 21:43:43  mviara
 * Improved statistics of cpu usage.
 *
 * Revision 1.5  2005/11/02 08:20:57  mviara
 * Added support for cpu statistics in mcs51.txt
 *
 * Revision 1.4  2005/10/28 15:34:47  mviara
 * Added support to dynamic change register.
 *
 * Revision 1.3  2005/10/23 20:07:35  mviara
 * Fixed bug in look and feel.
 *
 * Revision 1.2  2004/08/23 05:55:36  mviara
 * Removed message relative to interrupted exception.
 *
 * Revision 1.1.1.1  2004/08/22 06:46:24  mviara
 * 8051 emulator
 *
 */
package j51;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.text.*;
import java.util.*;
import java.io.*;

import j51.util.Hex;
import j51.intel.*;
import j51.swing.*;

/**
 * Base class for all the j51 panel.
 */
class J51Panel extends JPanel
{
	protected MCS51 cpu;
	
	J51Panel(String title)
	{
		super(new GridBagLayout());
		if (title == null)
			JFactory.setBox(this);
		else
			JFactory.setTitle(this,title);
	}

	public void setCpu(MCS51 cpu)
	{
		this.cpu = cpu;
	}

	public void setEmulation(boolean mode)
	{
	}

	public void update(boolean force)
	{
	}
}





class JInfo extends J51Panel
{
	JComboBox	cpus;
	JNumField oscillator;
	JNumField clock;
	JNumField cycle;
	
	public JInfo()
	{
		super("Setting");
		GridBagConstraints g = new GridBagConstraints();

		cpus		= new JComboBox();
		oscillator	= new JNumField(15);
		clock		= new JNumField(15);
		cycle		= new JNumField(3);
		
		JFactory.setBox(cpus);
		JFactory.setBox(oscillator);
		JFactory.setBox(clock);
		JFactory.setBox(cycle);

		cpus.setToolTipText("Cpu name and description");
		oscillator.setToolTipText("Selected oscillator in Hz");
		cycle.setToolTipText("Machina cycle in oscillator clock");
		clock.setToolTipText("Current clock counter");
		clock.setEditable(false);
		
		oscillator.setHorizontalAlignment(JFixedField.RIGHT);
		clock.setHorizontalAlignment(JFixedField.RIGHT);
		cycle.setHorizontalAlignment(JFixedField.RIGHT);

		g.gridx = 0;g.gridy = 0;g.gridwidth = 1;g.gridheight = 1;
		g.fill  = g.BOTH;g.insets = new Insets(1,1,1,1);


		g.anchor = g.WEST;
		add(new JLabel("CPU"),g);
		g.gridx++;g.anchor =g.EAST;
		g.gridwidth = 5;
		add(cpus,g);

		g.gridy++;g.gridx = 0;g.gridwidth = 1;
		g.anchor = g.WEST;
		add(new JLabel("Oscillator"),g);
		g.gridx++;g.anchor = g.EAST;
		add(oscillator,g);

		g.gridx++;
		g.anchor = g.WEST;
		add(new JLabel("Cycle"),g);
		g.gridx++;g.anchor = g.EAST;
		add(cycle,g);
		g.gridx++;
		g.anchor = g.WEST;
		add(new JLabel("Clock"),g);
		g.gridx++;g.anchor = g.EAST;
		add(clock,g);

		
		oscillator.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					cpu.oscillator((int)oscillator.getValue());
				}
				catch (Exception ex)
				{
				}
			}
			
		});

		cycle.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					cpu.machineCycle((int)cycle.getValue());
				}
				catch (Exception ex)
				{
				}
			}

		});
		

	}


	public void setEmulation(boolean mode)
	{
		cpus.setEnabled(!mode);
		oscillator.setEditable(!mode);
		cycle.setEditable(!mode);
	}

	public void update(boolean force)
	{
		oscillator.setValue(cpu.oscillator());
		clock.setValue(cpu.clock());
		cycle.setValue(cpu.machineCycle());
	}
	
}

class JRegister extends J51Panel
{
	private JLabel la,lb,lsp,lpc,ldpl,ldph,ldptr,lpsw;
	private JLabel lr[] = new JLabel[8];
	private JHexField a,b,pc,dpl,dph,dptr,sp,psw;
	private JHexField r[] = new JHexField[8];
	private ActionListener listener = null;
	
	JRegister()
	{
		super("Register");
		// Create the jlabel
		la		= new JLabel("A");
		lb		= new JLabel("B");
		lsp		= new JLabel("SP");
		lpc		= new JLabel("PC");
		ldpl	= new JLabel("DPL");
		ldph	= new JLabel("DPH");
		ldptr	= new JLabel("DPTR ");
		lpsw	= new JLabel("PSW");
		
		for (int i = 0 ; i < 8 ; i++)
		{
			lr[i] = new JLabel("R"+i);
		}

		
		// Create the text field
		a		= new JHexByte();
		b		= new JHexByte();
		sp		= new JHexByte();
		pc		= new JHexWord();
		dpl		= new JHexByte();
		dph		= new JHexByte();
		dptr		= new JHexWord();
		psw		= new JHexByte();

		
		for (int i = 0 ; i < 8 ; i++)
		{
			r[i] = new JHexByte();
		}

		GridBagConstraints g = new GridBagConstraints();
		//g.insets = new Insets(1,1,1,1);
		
		g.gridx = 0;g.gridy = 0;g.gridwidth = 1;g.gridheight = 1;
		g.fill  = g.NONE;

		addRegister(la,a,g);
		addRegister(lb,b,g);

		for (int i = 0 ; i < 8 ; i++)
		{
			addRegister(lr[i],r[i],g);
			r[i].addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					try
					{
						cpu.pc(pc.getValue());
						if (listener != null)
							listener.actionPerformed(new ActionEvent(this,0,"PC"));
					}
					catch (Exception ex)
					{
					}
				}
			});
		}				
				

		addRegister(lsp,sp,g);
		addRegister(lpsw,psw,g);
		addRegister(lpc,pc,g);
		addRegister(ldpl,dpl,g);
		addRegister(ldph,dph,g);
		addRegister(ldptr,dptr,g);


		/**
		 * Add action listener
		 */
		pc.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					cpu.pc(pc.getValue());
					if (listener != null)
						listener.actionPerformed(new ActionEvent(this,0,"PC"));
				}
				catch (Exception ex)
				{
				}
			}
		});

		sp.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					cpu.sp(sp.getValue());
					fireChangeSfr();
				}
				catch (Exception ex)
				{
				}
			}
		});

		a.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					cpu.acc(a.getValue());
					fireChangeSfr();
				}
				catch (Exception ex)
				{
				}
			}
		});
		
		b.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					cpu.b(b.getValue());
					fireChangeSfr();
				}
				catch (Exception ex)
				{
				}
			}
		});
		

		psw.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					cpu.psw(psw.getValue());
					fireChangeSfr();
				}
				catch (Exception ex)
				{
				}
			}
		});

		dpl.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					cpu.dpl(dpl.getValue());
					fireChangeSfr();
				}
				catch (Exception ex)
				{
				}
			}
		});

		dph.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					cpu.dph(dph.getValue());
					fireChangeSfr();
				}
				catch (Exception ex)
				{
				}
			}
		});


		dptr.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					cpu.dptr(dptr.getValue());
					fireChangeSfr();
				}
				catch (Exception ex)
				{
				}
			}
		});



	}


	private void fireChangeSfr()
	{
		if (listener != null)
			listener.actionPerformed(new ActionEvent(this,0,"SFR"));

	}
	
	public void setChangeListener(ActionListener l)
	{
		listener =l;
	}

	
	private void addRegister(JLabel label,JHexField field,GridBagConstraints g)
	{
		g.fill = g.HORIZONTAL;
		label.setBorder(BorderFactory.createEtchedBorder());
		field.setBorder(BorderFactory.createEtchedBorder());
		g.anchor = g.CENTER;g.gridx = 0;
		add(label,g);		g.anchor = g.EAST;g.gridx++;
		add(field,g);
		g.gridy++;
	}

	
	public void update(boolean force)
	{
		a.setValue(cpu.acc());
		b.setValue(cpu.b());
		sp.setValue(cpu.sp());
		pc.setValue(cpu.pc());
		dpl.setValue(cpu.dpl());
		dph.setValue(cpu.dph());
		dptr.setValue(cpu.dptr());
		psw.setValue(cpu.psw());
		
		for (int i = 0 ; i < 8 ; i++)
		{
			r[i].setValue(cpu.r(i));
		}
		
	}

	public void setEmulation(boolean mode)
	{
		a.setEditable(!mode);
		b.setEditable(!mode);
		sp.setEditable(!mode);
		pc.setEditable(!mode);
		dpl.setEditable(!mode);
		dph.setEditable(!mode);
		dptr.setEditable(!mode);
		psw.setEditable(!mode);
		
		for (int i = 0 ; i < 8 ; i++)
		{
			r[i].setEditable(!mode);
		}

	}
	
}

abstract class JData extends J51Panel
{
	private int top,bottom,base,row;
	protected JHexByte	bytes[] = new JHexByte[16*16];
	private JLabel	address[] = new JLabel[16];
	private JHexField	add;
	private boolean scrollable = false;
	
	JData(String title,int _bottom,int _top)
	{
		super(title);
		
		this.top = _top;
		this.bottom =  _bottom;
		
		for (int i = 0 ; i < 256 ; i++)
		{
			bytes[i] = new JHexByte();
			bytes[i].setToolTipText(Hex.bin2byte(i));
		}
		
		GridBagConstraints g = new GridBagConstraints();
		g.gridx = 0;g.gridy = 0;g.gridwidth = 1;g.gridheight = 1;
		g.fill  = g.NONE;g.insets = new Insets(1,1,1,1);
		g.anchor = g.WEST;

		row = (top - bottom) / 16;
		if (row > 16)
		{
			scrollable = true;
			row = 16;
			
			add = new JHexWord();
			add(new JLabel("Base"),g);
			g.gridx++;g.gridwidth = 3;
			add(add,g);
			g.gridx += 3;
			add(new JLabel("Bottom"),g);
			g.gridx += 3;
			add(new JHexWord(bottom),g);
			g.gridx += 3;
			add(new JLabel("Top"),g);
			g.gridx += 3;
			add(new JHexWord(top - 1),g);
					   
			g.gridy++;
			
			add.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					try
					{
						int address = add.getValue();
						if (address < bottom)
							address = bottom;
						if (address + 256 > top)
							address = top - 256;
						setAddress(address);
					}
					catch (Exception ex)
					{
					}
				}
			});

		}
		else
			add = null;

		g.gridx = 0;
		g.gridwidth = 1;
		for (int i = 0 ; i < 16 ; i++)
		{
			g.gridx++;
			JLabel l = new JLabel(Hex.bin2byte(i));
			JFactory.setBox(l);
			add(l,g);
			address[i] = new JLabel(Hex.bin2word(i*16));
			
			JFactory.setBox(address[i]);

		}
		
		g.gridy++;
		
		for (int i = 0 ; i < row ; i++)
		{
			g.gridx = 0;
			add(address[i],g);
			for (int j = 0 ; j < 16 ; j ++)
			{
				g.gridx++;
				add(bytes[i*16+j],g);
			}
			g.gridy++;
		}

		setAddress(bottom);
	}

	public void setEmulation(boolean mode)
	{
		if (add != null)
			add.setEditable(!mode);
	}

	void setAddress(int base)
	{
		this.base = base;
		for (int i = 0 ; i < row ; i++)
		{
			address[i].setText(Hex.bin2word(base+16*i));
		}
		
		update(false);
	}

	public void update(boolean force)
	{
		for (int i = 0 ; i < row ; i++)
			for (int j = 0 ; j < 16 ; j++)
				bytes[i*16+j].setValue(getByte(base+i*16+j));
	}
	
	abstract public int getByte(int address);
	
}

class JCode extends JData
{
	JCode()
	{
		super("Code",0,0x10000);
	}

	public int getByte(int address)
	{
		if (cpu == null)
			return 0;

		return cpu.code(address);
	}

}

class JXdata extends JData
{
	JXdata()
	{
		super("Xdata",0,0x10000);
	}

	public int getByte(int address)
	{
		if (cpu == null)
			return 0;

		return cpu.xdata(address);
	}

}

class JIdata extends JData
{
	JIdata()
	{
		super("Idata",0,256);
	}

	public int getByte(int address)
	{
		if (cpu == null)
			return 0;

		return cpu.idata(address);
	}

}

class JSfr extends JData
{
	JSfr()
	{
		super("SFR",128,256);

	}

	public void setCpu(MCS51 cpu)
	{
		
		super.setCpu(cpu);
		for (int i = 128 ; i < 256 ; i++)
		{
			bytes[i-128].setToolTipText(cpu.getSfrName(i));
		}
	}

	public int getByte(int address)
	{
		if (cpu == null)
			return 0;

		return cpu.sfr(address);
	}
}

class JAssembly extends J51Panel implements ChangeListener
{
	static public final int LINES = 16;
	JFixedField code[] = new JFixedField[LINES];
	JCheckBox breakPoint[] = new JCheckBox[LINES];
	int pcs[] = new int[LINES];
	int startPc,endPc,oldPc;
	private MCS51 myCpu = null;
	JHexWord start = new JHexWord();
	
	JAssembly()
	{
		super("Assembler");
		startPc = endPc = oldPc = -1;
		for (int i = 0 ; i < LINES ; i++)
		{
			code[i] = new JFixedField(40);
			breakPoint[i] = new JCheckBox();
			breakPoint[i].setToolTipText("Enable/disable break point");
			breakPoint[i].addChangeListener(this);
		}

		GridBagConstraints g = new GridBagConstraints();
		g.gridx = 0;g.gridy = 0;g.gridwidth = 1;g.gridheight = 1;
		g.fill  = g.NONE;g.insets = new Insets(1,1,1,1);
		g.anchor = g.WEST;

		add(new JLabel("Address"),g);
		g.gridx++;
		add(start,g);
		g.gridy++;
		
		for (int i = 0 ; i < LINES ; i++)
		{
			/*JPanel p = new JPanel();
			p.add(breakPoint[i]);
			p.add(code[i]);
			JFactory.setBox(p);*/

			g.anchor = g.CENTER;
			g.gridx = 0;
			add(breakPoint[i],g);
			g.gridx++;g.anchor = g.WEST;
			add(code[i],g);
			g.gridy++;
		}

		start.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					startPc = endPc = -1;
					int address = start.getValue();
					update(address);
				}
				catch (Exception ex)
				{
				}
			}
		});
		
	}


	public void stateChanged(ChangeEvent e)
	{
	
		if (myCpu == null)
			return;

		Object o = e.getSource();

		if (o instanceof JCheckBox)
		{
			JCheckBox j = (JCheckBox)o;
			for (int i = 0; i < LINES ; i++)
			{
				if (j == breakPoint[i])
				{
					myCpu.setBreakPoint(pcs[i],j.isSelected());
					break;
					
				}
			}
		}
	}

	public void update(boolean force)
	{
		if (force)
			startPc = endPc = oldPc = -1;
		update(cpu.pc());
	}
	
	public void update(int pc)
	{
		
		if (pc < startPc || pc >= endPc)
		{
			myCpu = null;

			startPc = pc;
			for (int i = 0; i < LINES ; i++)
			{
				pc &= 0xffff;

				code[i].setText(cpu.getDecodeAt(pc));
				pcs[i] = pc;
				code[i].setSelected(pc == cpu.pc());
				breakPoint[i].setSelected(cpu.getBreakPoint(pc));
				pc += cpu.getLengthAt(pc);
				pc &= 0xffff;
			}
			endPc = pc;
			//code[0].setSelected(true);
			oldPc = startPc;
			myCpu = cpu;
		}
		else
		{
			if (pc != oldPc)
			{
				for (int i = 0 ; i < LINES ; i++)
				{
					if (pcs[i] == oldPc)
						code[i].setSelected(false);
					if (pcs[i] == pc)
						code[i].setSelected(true);
				}

				oldPc = pc;
			}
		}
		start.setValue(startPc);

	}

	public void setEmulation(boolean mode)
	{
		for (int i = 0 ; i < LINES ; i++)
		{
			breakPoint[i].setEnabled(!mode);
		}
		start.setEditable(!mode);
	}
}

class JPeripheral extends J51Panel
{
	JPeripheral()
	{
		super("Peripheral");
	}

	
	public void setCpu(MCS51 cpu)
	{
		super.setCpu(cpu);
		removeAll();
		GridBagConstraints g = new GridBagConstraints();
		g.gridx = 0 ; g.gridy = 0;g.gridwidth = 1;g.gridheight=1;
		g.anchor = g.CENTER; g.fill = g.BOTH;
		for (int i = 0 ; i < cpu.getPeripheralsCount() ; i++)
		{
			MCS51Peripheral p = cpu.getPeripheralAt(i);
			
			if (p instanceof Component)
			{
				add((Component)p,g);
				g.gridy++;
			}
		}
	}
}


public class J51 extends JFrame implements MCS51Performance,ActionListener
{
	private J51Panel	peripheral;
	private JRegister	register;
	private JAssembly	assembly;
	private JSfr		sfr;
	private JIdata		idata;
	private JXdata		xdata;
	private JCode		code;
	private JInfo info;
	private JFixedField messages;
	private JToolBar toolBar = new JToolBar();
	private MCS51 cpu;
	private JFileChooser   fc = null;
	private JButton		   buttonStop;
	private AbstractAction actionDebugTrace;
	private AbstractAction actionDebugStep;
	private AbstractAction actionDebugGo;
	private AbstractAction actionDebugStop;
	private AbstractAction actionDebugReset;
	private AbstractAction actionToolsCounter;
	private AbstractAction actionFileLoad;
	private AbstractAction actionFileExit;
	private int minCpuUsage,maxCpuUsage,avgCpuUsage;
	private int cpuTime;
	private Thread thread;

	private java.util.Vector panels = new java.util.Vector();

	
	J51()
	{
		info	 = new JInfo();
		register = new JRegister();
		assembly = new JAssembly();
		sfr	 = new JSfr();
		idata	 = new JIdata();
		xdata	 = new JXdata();
		code	 = new JCode();
		peripheral= new JPeripheral();
		messages = new JFixedField(64);
		JFactory.setTitle(messages,"Messages");
		JPanel p = new JPanel(new GridBagLayout());
		createMenuBar();

		register.setChangeListener(this);
		
		GridBagConstraints g = new GridBagConstraints();
		g.insets = new Insets(1,1,1,1);
		g.gridx = 0;g.gridy = 0;g.gridwidth = 1;g.gridheight = 1;

		g.fill = g.NONE;
		g.anchor = g.WEST;
		g.gridwidth = 2;
		p.add(toolBar,g);
		
		g.gridy++;g.fill = g.BOTH;g.anchor = g.CENTER;
		
		g.gridwidth = 2;
		p.add(info,g);
		g.gridwidth = 1;g.gridy++;
		p.add(register,g);
		g.gridx++;
		
		JTabbedPane tp = new JTabbedPane();
		tp.add("Assembler",assembly);
		tp.add("SFR",sfr);
		tp.add("IDATA",idata);
		tp.add("XDATA",xdata);
		tp.add("CODE",code);
		
		p.add(tp,g)
				;
		g.gridx = 0;g.gridy++;g.gridwidth = 2;
		p.add(messages,g);

		g.gridx = 2;g.gridy = 0;
		g.gridheight = 4;g.gridwidth = 1;
		p.add(peripheral,g);
		
		setContentPane(p);

		panels.add(info);
		panels.add(assembly);
		panels.add(sfr);
		panels.add(idata);
		panels.add(xdata);
		panels.add(code);
		panels.add(register);
		panels.add(peripheral);

		// Add cpu selection item
		try
		{
			BufferedReader rd = new BufferedReader(new FileReader("j51.conf"));
			String line;

			while ((line = rd.readLine()) != null)
			{
				if (line.startsWith("#"))
					continue;
				if (line.length() < 3)
					continue;
				
				info.cpus.addItem(line);
			}
			rd.close();

		}
		catch (Exception ex)
		{
		}

		if (info.cpus.getItemCount() < 1)
			info.cpus.addItem("j51.intel.P8051");
		
		info.cpus.addItemListener(new ItemListener()
		{
			public void itemStateChanged(ItemEvent e)
			{
				if (e.getStateChange() == ItemEvent.SELECTED)
				{
					setCpu((String)info.cpus.getSelectedItem());
				}
			}

		});

		setCpu((String)info.cpus.getItemAt(0));

		setResizable(false);

		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
	}


	public void actionPerformed(ActionEvent e)
	{
		String source = e.getActionCommand();
		
		
		if (source.equals("PC"))
		{
			assembly.update(false);
		}

		if (source.equals("SFR"))
		{
			sfr.update(false);
		}
		
	}
	
	public void setCpu(String name)
	{
		
		try
		{
			Class c = Class.forName(name);
			MCS51 newCpu = (MCS51)c.newInstance();
			setCpu(newCpu);
		}
		catch (Exception ex)
		{
			messages(ex);
		}
	}

	private void reset()
	{

		cpu.reset();
		minCpuUsage = 100;
		maxCpuUsage = 0;
		cpuTime = 0;
		avgCpuUsage = 0;
		
	}
	
	public void setCpu(MCS51 cpu)
	{
		this.cpu = cpu;
		reset();
		
		for (int i = 0 ; i < panels.size() ; i++)
		{
			((J51Panel)panels.elementAt(i)).setCpu(cpu);
		}

		cpu.addPerformanceListener(this);
		invalidate();
		pack();
		updatePanel(true);
		emulation(false);
		messages(cpu.toString());
	}
	
	void addKey(JMenuItem item,char m)
	{
		item.setMnemonic(m);
		item.setAccelerator(KeyStroke.getKeyStroke(m, KeyEvent.ALT_MASK));
	}

	private void messages(Exception ex)
	{
		if (!(ex instanceof InterruptedException))
		{
			ex.printStackTrace();
		}
		
		String msg = ex.getMessage();
		if (msg == null)
			msg = ex.toString();
		messages(msg);
	}

	class UpdateMessage implements Runnable
	{
		private String msg;

		public UpdateMessage(String msg)
		{
			this.msg = msg;
			SwingUtilities.invokeLater(this);
		}

		public void run()
		{
			if (msg == null)
				msg = "";
			messages.setText(msg);
		}
	}

	private void messages(String msg)
	{
		new UpdateMessage(msg);
	}
	
	private void emulation(boolean mode)
	{
		actionDebugStop.setEnabled(mode);
		actionDebugReset.setEnabled(!mode);
		actionDebugGo.setEnabled(!mode);
		actionDebugTrace.setEnabled(!mode);
		actionDebugStep.setEnabled(!mode);
		actionFileLoad.setEnabled(!mode);
		actionFileExit.setEnabled(!mode);
		actionToolsCounter.setEnabled(!mode);
		
		for (int i = 0 ; i < panels.size() ; i++)
		{
			((J51Panel)panels.elementAt(i)).setEmulation(mode);
		}

		updatePanel(false);
	}

	JMenu createMenuLaf()
	{
		JMenu lnf = new JMenu("Look & Feel", true);
		ButtonGroup buttonGroup = new ButtonGroup();
		final UIManager.LookAndFeelInfo[] info = UIManager.getInstalledLookAndFeels();
		
		for (int i = 0; i < info.length; i++)
		{
			boolean set = false;

			
			JRadioButtonMenuItem item = new JRadioButtonMenuItem(info[i].getName(), set);
			final String className = info[i].getClassName();
			item.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent ae)
				{
					try
					{
						UIManager.setLookAndFeel(className);
					}
					catch (Exception e)
					{
						messages(e);
					}
					SwingUtilities.updateComponentTreeUI(J51.this);
					J51.this.pack();

				}
			});
			
			buttonGroup.add(item);
			lnf.add(item);
		}

		lnf.setMnemonic('K');

		return lnf;
		
	}
			
	void createMenuBar()
	{
		JMenuBar bar = new JMenuBar();
		bar.add(createMenuFile());
		bar.add(createMenuTools());
		bar.add(createMenuDebug());
		bar.add(createMenuLaf());
		setJMenuBar(bar);
		emulation(false);

		toolBar = new JToolBar();
		toolBar.add(actionDebugGo);
		toolBar.add(actionDebugTrace);
		toolBar.add(actionDebugStep);
		buttonStop = toolBar.add(actionDebugStop);
		toolBar.add(actionDebugReset);
		toolBar.add(actionFileLoad);

		cpuPerformance(0);
	}

	public void cpuPerformance(int cpu)
	{
		avgCpuUsage += cpu;
		if (cpuTime ++ > 1)
		{


			if (cpu < minCpuUsage)
				minCpuUsage = cpu;
			if (cpu > maxCpuUsage)
				maxCpuUsage = cpu;

			messages("CPU Usage "+cpu+"%, min "+minCpuUsage+"%, max "+maxCpuUsage+"%, avg "+(avgCpuUsage/cpuTime)+"%, run "+cpuTime+" sec.");
		}
	}


	private void load(String name) throws Exception
	{
		BufferedReader rd = new BufferedReader(new FileReader(name));
		String line;
		int start = 0x10000;
		int end = 0;
		
		while ((line = rd.readLine()) != null)
		{
			if (!line.startsWith(":"))
				throw new Exception(name+" is not a valid intel file");

			
			int lenData = Hex.getByte(line,1);
			int address	= Hex.getWord(line,3);
			int type	= Hex.getByte(line,7);

			int chksum = lenData + address/256+ address + type;
			
			for (int i = 0 ; i < lenData + 1; i++)
				chksum += Hex.getByte(line,9+i*2);
			chksum &= 0xff;

			if (chksum != 0)
				throw new Exception("Invalid chksum "+Hex.bin2byte(chksum)+" in "+line);

			if (type == 1)
				break;

			if (type != 0)
				throw new Exception("Unsupported record type "+type);

			if (address < start)
				start = address;
			if (address + lenData - 1 > end)
				end = address +lenData -1;
			for (int i = 0 ; i < lenData ; i++)
				cpu.code(address+i,Hex.getByte(line,9+i*2));
		}
		messages(" loaded at "+Hex.bin2word(start)+"-"+Hex.bin2word(end));
		
		rd.close();
	}
	
	JMenu createMenuFile()
	{
		actionFileLoad = new AbstractAction("Load")
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					if (fc == null)
					{
						fc = new JFileChooser();
						fc.setCurrentDirectory(new File("."));
					}
					if (fc.showOpenDialog(J51.this) == fc.APPROVE_OPTION)
					{
						load(fc.getSelectedFile().getCanonicalPath());
						updatePanel(true);
					}
				}
				catch (Exception ex)
				{
					messages(ex);
				}
			}
		};

		actionFileExit = new AbstractAction("Exit")
		{
			public void actionPerformed(ActionEvent e)
			{
				System.exit(0);
			}
		};

		JMenu menu = new JMenu("File");

		addKey(menu.add(actionFileLoad),'L');
		addKey(menu.add(actionFileExit),'X');

		menu.setMnemonic('F');
		
		return menu;
	}

	JMenu createMenuTools()
	{
		actionToolsCounter = new AbstractAction("Statistics")
		{
			class Opcodes implements Comparable
			{
				String desc;
				long count;
				
				Opcodes(long count,String desc)
				{
					this.count = count;
					this.desc  = desc;
				}

				public int compareTo(Object o2)
				{
					Opcodes op2;
					op2 = (Opcodes)o2;
					return (int)(op2.count-count);
				}

			}
			
			public void actionPerformed(ActionEvent e)
			{
				java.util.TreeSet set = new java.util.TreeSet();
				
				try
				{
					PrintStream ps = new PrintStream(new FileOutputStream("mcs51.txt"));
					
					for (int i = 0 ; i < 256 ; i++)
					{
						long l = cpu.getOpcodeCounter(i);
						MCS51Opcode o = cpu.getOpcode(i);
						
						if (l > 0)
						{
							set.add(new Opcodes(l,o.getDescription()));
						}
					}

					Iterator it = set.iterator();
					while (it.hasNext())
					{
						Opcodes o = (Opcodes)it.next();
						String l = ""+o.count;
						while (l.length() < 32)
							l = " "+l;
						ps.println(l+" " +o.desc);
						
					}
					
					ps.close();
				}
				catch (Exception ex)
				{
					messages(ex);
				}
				
			}
		};


		JMenu menu = new JMenu("Tools");

		addKey(menu.add(actionToolsCounter),'C');

		menu.setMnemonic('T');

		return menu;
	}

	JMenu createMenuDebug()
	{
		actionDebugReset = new AbstractAction("Reset")
		{
			public void actionPerformed(ActionEvent e)
			{
				reset();
				updatePanel(false);
			}
		};
		
		actionDebugStop = new AbstractAction("Stop")
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					thread.interrupt();
				}
				catch (Exception ex)
				{
			
				}
				
			}
		};

		actionDebugTrace = new AbstractAction("Step into")
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					cpu.step();
					updatePanel(false);
				}
				catch (Exception ex)
				{
					messages(ex);
				}
			}
		};

		actionDebugGo = new AbstractAction("Go")
		{
			public void actionPerformed(ActionEvent e)
			{
				thread = new Thread(new Runnable()
				{
					public void run()
					{
						messages("Emulating ....");
						try
						{
							cpu.go(-1);
						}
						catch (Exception ex)
						{
							
							messages(ex);
						}

						SwingUtilities.invokeLater(new Runnable()
						{
							public void run()
							{
								emulation(false);
							}
						});

					}
				});

				emulation(true);

				thread.start();
			}

			
		};

		actionDebugStep = new AbstractAction("Step over")
		{
			public void actionPerformed(ActionEvent e)
			{
				thread = new Thread(new Runnable()
				{
					public void run()
					{
						messages("Emulating ....");
						try
						{
							cpu.pass();
						}
						catch (Exception ex)
						{
							messages(ex);
						}

						SwingUtilities.invokeLater(new Runnable()
						{
							public void run()
							{
								emulation(false);
							}
						});

					}
				});

				emulation(true);

				thread.start();
			}


		};

		
		JMenu menu = new JMenu("Debug");
		
		addKey(menu.add(actionDebugTrace),'I');
		addKey(menu.add(actionDebugStep),'O');
		addKey(menu.add(actionDebugReset),'R');
		addKey(menu.add(actionDebugGo),'G');
		addKey(menu.add(actionDebugStop),'S');

		menu.setMnemonic('D');



		return menu;
	}
	
	static public void main(String argv[])
	{
		try
		{
			J51 j51 = new J51();
			j51.setTitle("J51 0.4 $Revision: 1.10 $ - Created by mario@viara.cn");
			j51.updatePanel(true);
			j51.pack();
			j51.show();
			j51.requestFocus();
		}
		catch (Exception ex)
		{
			System.out.println(ex);
			ex.printStackTrace();
			System.exit(1);
		}
	}

	public void updatePanel(boolean force)
	{
		if (cpu == null)
			return;
		
		for (int i = 0 ; i < panels.size() ; i++)
		{
			((J51Panel)panels.elementAt(i)).update(force);
		}

	}
}
