/**
 * $Id: AT89C51RD2.java,v 1.1 2005/11/27 23:58:42 mviara Exp $
 * $Name:  $
 *
 * Atmel 89C51Rxx cpu.
 * 
 * $Log: AT89C51RD2.java,v $
 * Revision 1.1  2005/11/27 23:58:42  mviara
 * Added preliminary support for ATMEL cpu.
 *
 */
package j51.atmel;

import j51.intel.*;
import j51.util.Hex;


public class AT89C51RD2 extends MCS51 implements AT89C51RD2Constants,
						SfrWriteListener,
						CallListener
{
	public AT89C51RD2() throws Exception
	{
/*		
		JPort.sfrPort[4] = P4;
		JPort.sfrM1[4] = -1;
		JPort.sfrM2[4] = -1;
		JPort.sfrPort[5] = P5;
		JPort.sfrM1[5] = -1;
		JPort.sfrM2[5] = -1;
	*/	
		setXdataSize(2*1024);
		
		
		setCode(new FlashCode("P89C51RD2",64*1024));
		addPeripheral(new Timer());
		addPeripheral(new Timer2());
		addSfrWriteListener(AUXR1,this);

		setCallListener(0xfff0,this);

		
	}

	/**
	 * EEPROM API
	 */
	public void call(MCS51 _cpu,int pc) throws Exception
	{

		switch (r(1))
		{
			case	9:
				int dest   = getDptr(0);
				int source = getDptr(1);

				for (int i = 0 ; i < acc() ; i++)
					code(dest+i,xdata(source+i));
				acc(0);
				break;
			default:
				throw new Exception("API R1 "+r(1)+" A = "+acc()+" DPTR0 = "+Hex.bin2word(getDptr(0))+" DPTR1 = "+Hex.bin2word(getDptr(1)));
				
		}
	}
	
	public void sfrWrite(int r,int v)
	{
		switch (r)
		{
			case	AUXR1:

				// Bit 1 is always 0
				v &= 0xfd;
				sfr(AUXR1,v);
				swapDptr(v & 1);
				break;
		}
	}
	
}
