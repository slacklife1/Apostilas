/**
 * $Id: AT89C51RD2Constants.java,v 1.1 2005/11/27 23:58:42 mviara Exp $
 * $Name:  $
 *
 * Constants for Atmel family
 *
 * $Log: AT89C51RD2Constants.java,v $
 * Revision 1.1  2005/11/27 23:58:42  mviara
 * Added preliminary support for ATMEL cpu.
 *
 */
package j51.atmel;

public interface AT89C51RD2Constants extends j51.intel.MCS51Constants
{
	static public final int P4		= 0xc0;
	static public final int P5		= 0xe8;
	static public final int AUXR1		= 0xa2;
}
