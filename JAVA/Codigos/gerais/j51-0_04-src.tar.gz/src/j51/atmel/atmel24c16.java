/**
 * $Id: Atmel24C16.java,v 1.5 2005/11/12 00:33:27 mviara Exp $
 * $Name:  $
 *
 * Atmel EEPROM.
 * 
 * $Log: Atmel24C16.java,v $
 * Revision 1.5  2005/11/12 00:33:27  mviara
 * Added support to read the eeprom.
 *
 * Revision 1.4  2005/11/11 06:31:07  mviara
 * Removed unused code.
 *
 * Revision 1.3  2005/11/02 08:16:40  mviara
 * Added support for persistent data.
 *
 * Revision 1.2  2004/08/23 05:50:40  mviara
 * Removed same unused variable.
 *
 * Revision 1.1.1.1  2004/08/22 06:46:24  mviara
 * 8051 emulator
 *
 */
package j51.atmel;

import j51.intel.*;

/**
 * Base class for ATMEL 24C16 EEPROM
 */
public abstract class Atmel24C16
{
	private boolean oldSCL,oldSDA;
	private PersistentBuffer eeprom = new PersistentBuffer("ATMEL24C16","eeprom",16*1024);
	private boolean read = false;
	private boolean ack = false;
	private int bitCount;
	private int byteCount;
	private int addr;
	private int cmd;
	private int value;

	public Atmel24C16()
	{
		stopCondition();
	}

	void stopCondition()
	{
		bitCount = 0;
		byteCount = 0;
		read = false;
		ack = false;

	}


	void startCondition()
	{
		stopCondition();
	}

	private void received(int v)
	{
		byteCount++;
		if (byteCount == 1)
		{
			cmd = v;
			if ((cmd & 1) != 0)
			{
				//System.out.println("Read "+Hex.bin2word(addr)+" = "+Hex.bin2byte(eeprom[addr]));
				read = true;
				value = eeprom.get(addr++);
			}

			return;
		}

		// Write
		if ((cmd & 1) == 0)
		{
			if (byteCount == 2)
			{
				addr = (((cmd << 7) & 0x700) | v) ;
				return;
			}

			//System.out.print("W "+Hex.bin2word(addr)+" = "+Hex.bin2byte(value)+" ");
			eeprom.set(addr++,v);
		}


	}

	/**
	 * Called when the clock or data are written.
	 */
	public final void writePort(boolean currentSCL,boolean currentSDA)
	{
		if (!currentSCL && ack)
		{
			ack = false;
		}

		if (ack)
		{
			SDA(false);
		}

		if (currentSCL && oldSCL && !oldSDA && currentSDA && !ack)
		{
			stopCondition();
			oldSDA = currentSDA;
			return;
		}

		if (currentSCL && oldSCL && oldSDA && !currentSDA)
		{
			startCondition();
			oldSDA = currentSDA;
			return;
		}


		// Check clock
		if (currentSCL && !oldSCL)
		{
			if (read)
			{
				if (++bitCount == 9)
				{
					//System.out.println("Read "+Hex.bin2word(addr)+" = "+Hex.bin2byte(eeprom[addr]));


					value = eeprom.get(addr++);
					bitCount = 0;
				}
				else
				{
					//System.out.println("Write bit "+bitCount+((value & 0x80) != 0));
					if ((value & 0x80) != 0)
					{
						SDA(true);
					}
					else
					{
						SDA(false);
					}
					value <<= 1;
				}
			}
			else
			{
				if (++bitCount == 9)
				{
					//System.out.println("start ack");
					received(value & 0xff);
					SDA(false);
					bitCount = 0;
					ack = true;
				}
				else
				{
					//System.out.println("read Bit "+bitCount+" "+ currentSDA);
					value <<= 1;
					if (currentSDA)
						value |= 1;
					else
						value &= ~1;
				}
			}


		}

		oldSDA = currentSDA;
		oldSCL = currentSCL;
	}

	/**
	 * Read one byte from the eeprom
	 */
	public int read(int add)
	{
		return eeprom.get(add);
	}

	/**
	 * Set the data line value, must be implemented from the child
	 * class.
	 */
	abstract protected void SDA(boolean value);


}


