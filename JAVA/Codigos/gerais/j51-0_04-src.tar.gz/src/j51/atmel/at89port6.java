/**
 * $Id: AT89Port6.java,v 1.1 2005/11/27 23:58:42 mviara Exp $
 * $Name:  $
 *
 * Atmel 89C51Rxx port
 * 
 * $Log: AT89Port6.java,v $
 * Revision 1.1  2005/11/27 23:58:42  mviara
 * Added preliminary support for ATMEL cpu.
 *
 */
package j51.atmel;

import j51.intel.*;
import j51.util.Hex;



public class AT89Port6 extends JPort implements AT89C51RD2Constants
{
	public AT89Port6()
	{
		super(6);
		setSfrP(4,P4);
		setSfrP(5,P5);
	}
}
