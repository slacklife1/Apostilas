/**
 * $Id: Hex.java,v 1.1.1.1 2004/08/22 06:46:26 mviara Exp $
 * $Name:  $
 * 
 * $Log: Hex.java,v $
 * Revision 1.1.1.1  2004/08/22 06:46:26  mviara
 * 8051 emulator
 *
 */
package j51.util;

/**
 *
 * Binary to ascii and ascii to binary conversion.
 * 
 */
public class Hex
{
	static public int getDigit(String line,int pos) throws Exception
	{
		int c = line.charAt(pos);

		if (c >= 'A' && c <= 'F')
			return c - 'A' + 10;
		if (c >= '0' && c <= '9')
			return c - '0';

		throw new Exception("Invalid digit '"+line.charAt(pos)+"'");
	}
	
	static public int getByte(String line,int pos) throws Exception
	{
		return (getDigit(line,pos+0) << 4) | getDigit(line,pos+1);
	}

	static public int getWord(String line,int pos) throws Exception
	{
		return (getByte(line,pos+0) << 8) | getByte(line,pos+2);
	}

	static public String bin2word(int value)
	{
		String s = Integer.toHexString(value & 0xffff);

		while (s.length() < 4)
			s = "0"+s;

		return s.toUpperCase();

	}
	
	static public String bin2byte(int value)
	{
		String s = Integer.toHexString(value & 0xff);

		while (s.length() < 2)
			s = "0"+s;

		return s.toUpperCase();
	}

	static public String bin2dword(long value)
	{
		String s = Integer.toHexString((int)value);

		while (s.length() < 8)
			s = "0"+s;

		return s.toUpperCase();

	}
}
