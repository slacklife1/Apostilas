package j51.swing;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.text.*;
import java.io.*;
import java.util.Vector;

public class JBitField extends JPanel implements ActionListener
{
	private JCheckBox bits[] = new JCheckBox[8];
	private Vector listeners = new Vector();
	private long lastTime;
	private boolean checkRate = false;
	
	public JBitField(String title)
	{
		this(title,true);
	}
	
	public JBitField(String title,boolean bit)
	{
		super(new GridBagLayout());
		GridBagConstraints g = new GridBagConstraints();
		g.gridx = 0; g.gridy = 0;g.gridwidth = 1;g.gridheight = 1;
		g.anchor = g.CENTER; g.fill = g.NONE; 

		for (int i = 0  ; i < 8 ; i ++)
		{
			g.gridy = 0;
			if (bit)
			{
				add(new JLabel(""+(7-i)),g);
				g.gridy = 1;
			}
			
			bits[i] = new JCheckBox();
			bits[i].addActionListener(this);
			bits[i].setToolTipText(""+(7-i));
			add(bits[i],g);
			g.gridx++;
		}

		JFactory.setTitle(this,title);
		setValue(0);

	}

	public void setCheckRate(boolean checkRate)
	{
		this.checkRate = checkRate;
	}
	public void actionPerformed(java.awt.event.ActionEvent e)
	{
		for (int i = 0  ;i < listeners.size() ; i++)
		{
			ActionListener l = (ActionListener)listeners.elementAt(i);
			l.actionPerformed(e);
		}
		
	}

	public void setBitName(int bit,String name)
	{
		bits[7 - bit].setToolTipText(name);

	}

	public void setDisabled(int bit,boolean mode)
	{
		bits[7-bit].setEnabled(!mode);
	}
	
	public void setValue(int value)
	{
		if (checkRate)
		{
			long now = System.currentTimeMillis();

			// Not more the 1 update / ms
			if (now == lastTime)
				return;
			lastTime = now;
		}
		
		for (int i = 0  ; i < 8 ; i ++)
		{
			if ((value & (1 << i)) != 0)
			{
				if (!bits[7-i].isSelected())
					bits[7-i].setSelected(true);
			}
			else
			{
				if (bits[7-i].isSelected())
					bits[7-i].setSelected(false);
			}
		}
		
	}

	
	public int getValue()
	{
		int value = 0;
		
		for (int i = 0  ; i < 8 ; i ++)
		{
			if (bits[7-i].isSelected())
				value |= 1 << i;
		}

		return value;
	}

	public void setEditable(boolean mode)
	{
		for (int i = 0  ; i < 8 ; i ++)
		{
			bits[i].setEnabled(mode);
		}
	}

	public void addActionListener(ActionListener l)
	{
		listeners.add(l);
	}
	
	
}
