package j51.swing;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.text.*;
import java.io.*;

import j51.util.Hex;

public class JHexWord extends JHexField
{
	public JHexWord()
	{
		super(4);

	}

	public JHexWord(int value)
	{
		this();
		setValue(value);
		setValue(value);
	}
}
