/**
 * $Id: JFactory.java,v 1.2 2005/11/11 06:30:37 mviara Exp $
 * $Name:  $
 *
 * Swing factory used to have one common 'skin' in the J51 swing
 * omponent.
 * 
 * $Log: JFactory.java,v $
 * Revision 1.2  2005/11/11 06:30:37  mviara
 * Removed unused code.
 *
 * Revision 1.1.1.1  2004/08/22 06:46:25  mviara
 * 8051 emulator
 *
 */
package j51.swing;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.text.*;
import java.io.*;

import j51.util.Hex;
import j51.intel.*;


/**
 * Swing factory class with all the constants for the 'skin' if j51.
 */
public class JFactory
{
	public static void setBox(JComponent j)
	{
		j.setBorder(BorderFactory.createEtchedBorder());

	}
	
	public static void setTitle(JComponent j,String title)
	{
		Border etched = BorderFactory.createEtchedBorder();
		Border titled = BorderFactory.createTitledBorder(etched," "+title+" ");
		j.setBorder(titled);
	}

	public static Color getColorNormal()
	{
		return Color.blue;
	}

	public static Color getColorSelected()
	{
		return Color.red;
	}
	
}
