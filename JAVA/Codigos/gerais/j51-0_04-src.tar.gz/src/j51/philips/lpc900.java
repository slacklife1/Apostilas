/**
 * $Id: LPC900.java,v 1.12 2005/11/29 03:45:48 mviara Exp $
 * $Name:  $
 *
 * LPC900 Family emulator.
 *
 * Emulated peripheral :
 *
 * - Flash memory
 * - Eeprom
 * - Double DPTR
 * - Watch Dog
 * 
 * $Log: LPC900.java,v $
 * Revision 1.12  2005/11/29 03:45:48  mviara
 * Added misc register using JBitField
 *
 * Revision 1.11  2005/11/28 00:01:55  mviara
 * Added constructor with base name for files.
 *
 * Revision 1.10  2005/11/15 23:28:06  mviara
 * Fixed bug in AUXR1
 *
 * Revision 1.9  2005/11/13 09:20:42  mviara
 * Update for new MCS51 class.
 *
 * Revision 1.8  2005/11/12 00:34:46  mviara
 * Fixed bug in WDCON default value after reset.
 *
 * Revision 1.7  2005/11/11 07:16:42  mviara
 * Fixed bug in reset.
 *
 * Revision 1.6  2005/11/11 06:35:04  mviara
 * Added support for watch dog and default initialization for p0-03 mode.
 *
 * Revision 1.5  2005/11/09 08:51:26  mviara
 * Added supporto for internal register UCFG1,BOOOTV, BOOTSTAT
 *
 * Revision 1.4  2005/11/08 21:46:28  mviara
 * Added support for AUXR1.
 *
 * Revision 1.3  2005/10/28 15:33:25  mviara
 * Added supporto for multiple DPTR.
 *
 * Revision 1.2  2005/10/23 20:11:21  mviara
 * First running version for LPC900.
 *
 */
package j51.philips;

import j51.intel.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import j51.util.Hex;
import j51.swing.*;

interface LPC900Constants
{
	static public final int FMCON	= 0xe4;
	static public final int FMDATA	= 0xe5;
	static public final int FMADRL	= 0xe6;
	static public final int FMADRH	= 0xe7;
	static public final int DEECON	= 0xf1;
	static public final int DEEDAT  = 0xf2;
	static public final int DEEADR  = 0xf3;
	static public final int AUXR1	= 0xa2;
	static public final int AUXR1_SRST = 0x08;
	
	static public final int WDCON	= 0xa7;
	static public final int IE_WD	=0x40;
	
	// 1 Clock 400Khz , 0 Clock CCLK
	static public final int WDCON_WDCLK	= 0x01; 
	static public final int WDCON_WDTOF	= 0x02;
	// 1 WD running
	static public final int WDCON_WDRUN	= 0x04;
	
	static public final int WDL	= 0xC1;
	static public final int WDFEED1 = 0xC2;
	static public final int WDFEED2 = 0xC3;
	
	static public final int FLASH_MISC = 0xfff0;
	
	static public final int UCFG1	= 0x00;
	// 1 Watch dog reset enable
	static public final int UCFG1_WDTE = 0x80;
	// 1 Watch dog safety enable
	static public final int UCFG1_WDSE = 0x10;
	
	static public final int BOOTV	= 0x02;
	static public final int BOOTSTAT= 0x03;
	static public final int SEC0	= 0x08;
	static public final int SEC1	= 0x09;
	static public final int SEC2	= 0x0A;
	static public final int SEC3	= 0x0B;
	static public final int SEC4	= 0x0C;
	static public final int SEC5	= 0x0D;
	static public final int SEC6	= 0x0E;
	static public final int SEC7	= 0x0F;
}

/**
 * Watch Dog for LPX9xx series.
 */
class LPC900WDT extends AbstractInterruptSource implements MCS51Peripheral,LPC900Constants,
				ResetListener,SfrWriteListener,AsyncTimerListener
{
	
	private int wdl;
	private LPC900 cpu;
	private boolean running = false;
	private boolean feed = false;
	private int wdClock;
	
	public LPC900WDT()
	{
		super(0x53);
	}
	
	public void registerCpu(MCS51 _cpu)
	{
		this.cpu = (LPC900)_cpu;
		
		cpu.setSfrName(WDCON,  "WDCON");
		cpu.setSfrName(WDFEED1,"WDFEED1");
		cpu.setSfrName(WDFEED2,"WDFEED2");
		cpu.setSfrName(WDL,    "WDL");

		cpu.addSfrWriteListener(WDCON,this);
		cpu.addSfrWriteListener(WDFEED1,this);
		cpu.addSfrWriteListener(WDFEED2,this);

		cpu.addInterruptSource(MCS51Constants.IE,this);
		cpu.addInterruptSource(WDCON,this);

		cpu.addResetListener(this);
	}

	public void reset(MCS51 _cpu)
	{
		running = feed = false;
		cpu.sfr(WDL,0xFF);
		cpu.sfr(WDCON,0xE7);
		wdl = 0xff;

		// Call the write listener because under reset is not
		// called but the WD must be enabled any way !!!
		sfrWrite(WDCON,0xE7);
	}
	
	public void sfrWrite(int r,int v)
	{
		switch (r)
		{
			case	LPC900Constants.WDFEED1:
				if (v == 0xA5)
					feed = true;
				else
					feed = false;
				break;
				
			case	LPC900Constants.WDFEED2:
				if (v == 0x5a && feed)
				{
					cpu.sfrReset(WDCON,WDCON_WDTOF);
					wdl = cpu.sfr(WDL);
				}
				feed = false;
				break;
				
			case	LPC900Constants.WDCON:
				// If WDTE and WDSE are enable
				// WDCLK = 1
				// WDL can be written a once
				// WDRUN is forced to 1
				if ((cpu.miscGet(UCFG1) & (UCFG1_WDTE|UCFG1_WDSE)) == (UCFG1_WDTE|UCFG1_WDSE))
				{
					v |= WDCON_WDRUN|WDCON_WDCLK;
					cpu.sfr(WDCON,v);
				}
				
				v &= 0xff;
				wdClock = v >> 5;
				wdClock = 32 << wdClock;
				addTimer();
				break;
		}
	}


	public boolean interruptCondition()
	{
		if ((cpu.sfr(MCS51Constants.IE) & IE_WD) != 0 && (cpu.sfr(WDCON) & WDCON_WDTOF) != 0)
			return true;
		
		return false;
	}

	
	private void addTimer()
	{
		int timer = 0;
		if (running)
			return;

		if ((cpu.sfr(WDCON) & WDCON_WDRUN) == 0)
			return;
		
		running = true;
		
		// Watch dog internal timer (400 Khz) ?
		if ((cpu.sfr(WDCON) & WDCON_WDCLK) != 0)
		{
			timer =  cpu.oscillator() / 400000;
			timer /= cpu.machineCycle();
		}
		else
			timer = 1;

		
		timer *= wdClock;


		cpu.addAsyncTimerListener(timer,this);
	}

	public void expired(MCS51 _cpu) throws Exception
	{
		running = false;

		wdl = (wdl - 1) & 0xff;
		
		if (wdl == 0)
		{
			cpu.sfrSet(WDCON,WDCON_WDTOF);
			
			wdl = cpu.sfr(WDL);

			if ((cpu.miscGet(UCFG1) & (UCFG1_WDTE)) == (UCFG1_WDTE))
			{
				throw new Exception("Watch Dog reset");
			}
			
		}
		
		addTimer();
	}
}


class LPC900Port extends JPort implements ResetListener
{
	LPC900Port() throws Exception
	{
		super(4);
		setDisableMask(3,0xFC);
		
	}

	public void registerCpu(MCS51 cpu)
	{
		super.registerCpu(cpu);
		cpu.addResetListener(this);
	}

	public void reset(MCS51 cpu)
	{
		// In the LPC900 default port is Input
		cpu.sfr(MCS51Constants.P0M1,0xff);
		cpu.sfr(MCS51Constants.P0M2,0x00);
		cpu.sfr(MCS51Constants.P1M1,0xff);
		cpu.sfr(MCS51Constants.P1M2,0x00);
		cpu.sfr(MCS51Constants.P2M1,0xff);
		cpu.sfr(MCS51Constants.P2M2,0x00);
	}
	
}

/**
 * LPC900 misc register
 **/
class LPC900Misc extends JPanel implements MCS51Peripheral
{
	LPC900 cpu;
	JBitField ucfg1 = new JBitField("UCFG1");
	JBitField bootv = new JBitField("BOOTV");
	JBitField boots = new JBitField("BOOTS");
	
	LPC900Misc()
	{
		super(new GridBagLayout());
		//JFactory.setTitle(this,"Misc");
		
		GridBagConstraints g = new GridBagConstraints();
		g.gridx = 0; g.gridy = 0;g.gridwidth = 1;g.gridheight = 1;
		g.anchor = g.CENTER; g.fill = g.NONE; 
		g.insets = new Insets(1,1,1,1);

		add(ucfg1,g);
		g.gridx++;
		add(bootv,g);
		g.gridx++;
		add(boots,g);
	}
	
	public void registerCpu(MCS51 _cpu)
	{
		this.cpu = (LPC900)_cpu;

		ucfg1.setValue(cpu.miscGet(cpu.UCFG1));
		bootv.setValue(cpu.miscGet(cpu.BOOTV));
		boots.setValue(cpu.miscGet(cpu.BOOTSTAT));

		ucfg1.setEditable(true);
		boots.setEditable(true);
		bootv.setEditable(true);
		
		ucfg1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					cpu.miscSet(cpu.UCFG1,ucfg1.getValue());
				}
				catch (Exception ex)
				{
				}
			}
			
		});

		bootv.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					cpu.miscSet(cpu.BOOTV,bootv.getValue());
				}
				catch (Exception ex)
				{
				}
			}

		});

		boots.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					cpu.miscSet(cpu.BOOTSTAT,boots.getValue());
				}
				catch (Exception ex)
				{
				}
			}

		});
		
	}

}

public class LPC900 extends MCS51 implements SfrWriteListener, LPC900Constants, Code
{
	private byte flashBuffer[];
	private int  flashSize,flashCounter;
	private PersistentBuffer eeprom,flash;
	private boolean eepromWrite = false;
	private PersistentBuffer misc;
	

	public LPC900() throws Exception
	{
		this("LPC900");
	}
	
	public LPC900(String name) throws Exception
	{
		eeprom  = new PersistentBuffer(name,"eeprom",	512);
		misc	= new PersistentBuffer(name,"misc",	32);
		flash	= new PersistentBuffer(name,"flash",	8192);
		flashBuffer = new byte[64];

		setCode(this);
		setXdataSize(512);
		
		if (misc.isLoaded() == false)
		{
			misc.set(UCFG1,0x63);
			misc.set(BOOTV,0x1F);
			misc.set(BOOTSTAT,0x01);
			
			for (int i = 0 ; i < 8 ; i++)
				misc.set(SEC0+i,0);
		}
		
		oscillator = 7372800;
		machineCycle = 2;

		
		addPeripheral(new j51.intel.Timer());
		addPeripheral(new LPC900Misc());
		addPeripheral(new LPC900Port());
		addPeripheral(new JUart());
		addPeripheral(new LPC900WDT());
		/**
		 * Flash interface
		 */
		addSfrWriteListener(LPC900Constants.FMCON,this);
		addSfrWriteListener(LPC900Constants.FMDATA,this);
		addSfrWriteListener(LPC900Constants.DEEDAT,this);
		addSfrWriteListener(LPC900Constants.DEEADR,this);
		addSfrWriteListener(LPC900Constants.AUXR1,this);



		setSfrName(LPC900Constants.FMDATA,	"FMDATA");
		setSfrName(LPC900Constants.FMCON,	"FMCON");
		setSfrName(LPC900Constants.FMADRL,	"FMADRL");
		setSfrName(LPC900Constants.FMADRH,	"FMADRH");
		setSfrName(LPC900Constants.DEECON,	"DEECON");
		setSfrName(LPC900Constants.DEEDAT,	"DEEDAT");
		setSfrName(LPC900Constants.DEEADR,	"DEEADR");
		setSfrName(LPC900Constants.AUXR1,	"AUXR1");
	}

	public void setCodeSize(int size)
	{
	}

	public int getCodeSize()
	{
		return flash.getSize();
	}

	public void setCode(int addr,int value)
	{
		
		if (addr >= FLASH_MISC)
		{
			miscSet(addr-FLASH_MISC,value);

		}
		else
			flash.set(addr,value);
	}

	public int getCode(int addr)
	{
		if (addr >= FLASH_MISC)
		{
			return miscGet(addr-FLASH_MISC);
		}
		else
			return flash.get(addr);

	}

	
	int miscGet(int add)
	{
		return misc.get(add);
	}

	void miscSet(int add,int value)
	{
		misc.set(add,value);
	}

	public void reset()
	{
		super.reset();
		
		if ((miscGet(BOOTSTAT) & 0x01) != 0)
		{
			pc(misc.get(BOOTV) << 8);
		}

		sfrWrite(FMCON,0x70);
	}
	
	
	public void sfrWrite(int r,int v)
	{
		switch (r)
		{
			case	LPC900Constants.AUXR1:
				
				// Bit 1 is always 0
				v &= 0xfd;
				sfr(LPC900Constants.AUXR1,v);
				swapDptr(v & 1);
				break;
				
			case	LPC900Constants.DEEDAT:
				eepromWrite = true;
				break;
				
			case	LPC900Constants.DEEADR:
				int addr = v + (sfr(LPC900Constants.DEECON) & 1) * 256;
				if (eepromWrite)
				{
					eeprom.set(addr,sfr(LPC900Constants.DEEDAT));
				}
				else
				{
					sfr(LPC900Constants.DEEDAT,eeprom.get(addr));
				}
				sfr(LPC900Constants.DEECON,sfr(LPC900Constants.DEECON)|0x80);
				eepromWrite = false;
				break;
				
			case	LPC900Constants.FMDATA:
				flashBuffer[flashCounter++] = (byte)v;
				break;
				
			case	LPC900Constants.FMCON:
				switch (v)
				{
					case	0x00:
						flashCounter = 0;
						break;
					case	0x68:
						int base = sfr(LPC900Constants.FMADRL) +
							   sfr(LPC900Constants.FMADRH) * 256;
						
						for (int i = 0 ; i < flashCounter ; i++)
							code(base+i,flashBuffer[i]);
						break;
						
				}
		}
			
	}
	
	public String toString()
	{
		return "Philips 89LPC900 $Id: LPC900.java,v 1.12 2005/11/29 03:45:48 mviara Exp $";
	}
}
