/**
 * $Id: LPC764.java,v 1.4 2005/11/29 03:46:08 mviara Exp $
 * $Name:  $
 *
 * LPC764 Emulator emulated peripheral :
 * 
 * I/O port
 * 
 * $Log: LPC764.java,v $
 * Revision 1.4  2005/11/29 03:46:08  mviara
 * Separated LPC764Port class.
 *
 * Revision 1.3  2005/11/15 23:28:20  mviara
 * Added support for new design.
 *
 * Revision 1.2  2005/11/02 08:15:48  mviara
 * Split LPC764 in LPC764Base
 *
 *
 */
package j51.philips;

import j51.intel.*;



public class LPC764 extends LPC764Base
{
	
	public LPC764() throws Exception
	{
		super("LPC764");
		
		addPeripheral(new LPC764Port());


	}

	public String toString()
	{
		return "Philips 87LPC764 $Id: LPC764.java,v 1.4 2005/11/29 03:46:08 mviara Exp $";
	}
}
