/**
 * $Id: LPC764Base.java,v 1.4 2005/11/13 09:20:42 mviara Exp $
 * $Name:  $
 *
 * LPC764 Emulator emulated peripheral :
 * 
 * 4KB OTP	Persistent
 * EEPROM	Persistent
 * JUART
 * TIMER
 * 
 * $Log: LPC764Base.java,v $
 * Revision 1.4  2005/11/13 09:20:42  mviara
 * Update for new MCS51 class.
 *
 * Revision 1.3  2005/11/08 21:46:28  mviara
 * Added support for AUXR1.
 *
 * Revision 1.2  2005/11/02 11:33:11  mviara
 * Removed some debug code.
 *
 * Revision 1.1  2005/11/02 08:20:25  mviara
 * Split LPC764 in LPC764Base.
 *
 *
 */
package j51.philips;

import j51.intel.*;

interface LPC764Constants
{
	static public final int AUXR1	= 0xa2;
}

public class LPC764Base extends MCS51 implements Code , LPC764Constants , SfrWriteListener
{
	private PersistentBuffer flash;
	private PersistentBuffer eeprom;

	static public final int EEPROM_START = 0xfc00;
	static public final int EEPROM_SIZE  = 0x0400;
	static public final int EEPROM_UCFG1 = 0xfd00;
	static public final int EEPROM_UCFG2 = 0xfd01;
	
	public LPC764Base(String name)
	{
		oscillator = 6000000;
		machineCycle = 6;

		addSfrWriteListener(AUXR1,this);


		flash = new PersistentBuffer(name,"flash",4096);
		eeprom= new PersistentBuffer(name,"eeprom",768);
		
		setCode(this);

		addPeripheral(new JUart());
		addPeripheral(new j51.intel.Timer());

		setSfrName(AUXR1,"AUXR1");

	}

	public void setCodeSize(int size)
	{
	}

	public int getCodeSize()
	{
		return 4096;
	}

	public void setCode(int addr,int value)
	{
		if (addr >= EEPROM_START)
		{
			//System.out.println("WRITE EEPROM "+j51.util.Hex.bin2word(addr)+" = "+j51.util.Hex.bin2byte(value));
			eeprom.set(addr-EEPROM_START,value);

		}
		else
			flash.set(addr,value);
	}

	public int getCode(int addr)
	{
		if (addr >= EEPROM_START)
		{
			return eeprom.get(addr-EEPROM_START);
			//System.out.println("READ EEPROM "+j51.util.Hex.bin2word(addr)+" = "+j51.util.Hex.bin2byte(value));
		}
		else
			return flash.get(addr);

	}



	public void sfrWrite(int r,int v)
	{
		switch (r)
		{
			case	AUXR1:
				// Bit 2 is always 0
				v &= 0xfb;
				sfr(AUXR1,v);
				swapDptr(v & 1);

				// Reset if bit 3 is set
				if ((v & 0x08) != 0)
					reset();
				break;
		}
	}
	public String toString()
	{
		return "LPC764 $Id: LPC764Base.java,v 1.4 2005/11/13 09:20:42 mviara Exp $";
	}
	
}
