/**
 * $Id: LPC764Port.java,v 1.1 2005/11/29 03:46:08 mviara Exp $
 * $Name:  $
 *
 * LPC764 Port
 *
 * $Log: LPC764Port.java,v $
 * Revision 1.1  2005/11/29 03:46:08  mviara
 * Separated LPC764Port class.
 *
 *
 */
package j51.philips;

import j51.intel.*;



public class LPC764Port extends JPort 
{
	public LPC764Port() throws Exception
	{
		super(3);
		setDisableMask(2,0xFC);
	}
}
