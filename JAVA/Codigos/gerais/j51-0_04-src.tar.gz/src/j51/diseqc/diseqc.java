/**
 * $Id: Diseqc.java,v 1.7 2005/11/29 03:47:25 mviara Exp $
 * $Name:  $
 *
 * Emulator for Diseqc 1.2 convertor for details see
 * http://www.viara.cn/diseqc
 * 
 * $Log: Diseqc.java,v $
 * Revision 1.7  2005/11/29 03:47:25  mviara
 * Added LPC764Port
 *
 * Revision 1.6  2005/11/12 00:36:24  mviara
 * Added support to get the motor position from the eeprom.
 *
 */
package j51.diseqc;

import java.awt.*;
import javax.swing.*;

import j51.intel.*;
import j51.philips.*;
import j51.swing.*;
import j51.util.Hex;


class DiseqcAtmel24C16 extends j51.atmel.Atmel24C16 implements
   SfrWriteListener,
   MCS51Peripheral
   
{
	private final int SCL = 0x40;
	private final int SDA = 0x80;
	private Diseqc cpu;
	
	public void registerCpu(MCS51 _cpu)
	{
		this.cpu = (Diseqc)_cpu;
		cpu.addSfrWriteListener(MCS51Constants.P0,this);
	}

	
	protected void SDA(boolean sda)
	{
		if (sda)
			cpu.sfrSet(MCS51Constants.P0,SDA);
		else
			cpu.sfrReset(MCS51Constants.P0,SDA);
	}

	public void sfrWrite(int reg,int value)
	{
		writePort((value & SCL) != 0,(value & SDA) != 0);
	}
}




class JMotor extends JPanel implements Runnable
{
	int value = -1;
	String stringValue;
	JTextField f;
	JMotor(int min,int max,int value)
	{
		f = new JTextField();
		Font font = f.getFont();
		font = new Font("Monospaced",font.BOLD,font.getSize()*4);
		f.setFont(font);
		f.setForeground(Color.green);
		f.setBackground(Color.black);
		f.setEditable(false);
		setValue(0);
		add(f);
		JFactory.setTitle(this,"Position");

	}

	public void setValue(int value)
	{
		value /= 10;

		
		if (value == this.value)
			return;
		this.value = value;
		String s;
		
		if (value == 0)
			s = "  000 ";
		else
		{
			String p;
			if (value < 0)
			{
				p = "E";
				value = - value;
			}
			else
			{
				p = "W";
			}
			s = value+p;
		}

		while (s.length() < 5)
			s = " "+s;

		stringValue = s;

		SwingUtilities.invokeLater(this);

	}

	public void run()
	{
		f.setText(stringValue);
	}
}

class DiseqcPeripheral extends JPanel implements MCS51Peripheral,
	  SfrWriteListener,SfrReadListener,AsyncTimerListener,ResetListener
{
	private final int MIN = -900;
	private final int MAX =  900;
	
	private MCS51 cpu;
	private JLed ledw = new JLed("West",Color.green);
	private JLed lede = new JLed("East",Color.green);
	private JLed led  = new JLed("Status",Color.blue);
	private JLed ledp = new JLed("Power",Color.red);
	private JToggleButton gow = new JToggleButton("GO WEST");
	private JToggleButton goe = new JToggleButton("GO EAST");
	private JMotor position = new JMotor(MIN,MAX,0);
	private int motorPosition = 0;
	private int pulseWidth,pulseTime;
	boolean motorPower = false;
	
	public DiseqcPeripheral()
	{
		super(new GridBagLayout());
		JFactory.setTitle(this,"Diseqc on LPC764");
		
		GridBagConstraints g = new GridBagConstraints();
		g.gridx = 0; g.gridy = 0;g.gridwidth = 1;g.gridheight = 1;
		g.anchor = g.CENTER; g.fill = g.NONE; g.insets=new Insets(2,2,2,2);

		
		/*position.setMinorTickSpacing(2);
		position.setMajorTickSpacing(30);
		position.setPaintTicks(true);
		position.setPaintLabels(true);*/
		
		g.gridx = 0;g.gridwidth = 4;
		add(position,g);
		
		g.gridy++;g.gridx=0;g.gridwidth = 1;
		add(ledw,g);
		g.gridx += 1;
		add(led,g);
		g.gridx += 1;
		add(ledp,g);
		g.gridx += 1;
		add(lede,g);

		g.gridy++;g.gridx = 0;g.gridwidth = 2;
		add(gow,g);
		g.gridx += 2;
		add(goe,g);
		
		
	}

	public void reset(MCS51 _cpu)
	{
		Diseqc cpu = (Diseqc)_cpu;
		
		// Check eeprom validity to move the motor on the
		// correct position from eeprom.

		// Signature ?
		if (cpu.eeprom(0) != 0x55AA)
			return;

		int pos = (cpu.eeprom(2) - 32768)  ;
		motorPosition = pos;
		if (motorPosition < MIN)
			motorPosition = MIN;
		if (motorPosition > MAX)
			motorPosition = MAX;
		position.setValue(motorPosition);
	}

	
	public int sfrRead(int reg)
	{
		int value = cpu.sfr(reg);
		value |= 3;

		if (goe.isSelected())
			value &= ~1;
		if (gow.isSelected())
			value &= ~2;

		return value;
	}

	public void writeP1(int value)
	{
		lede.set((value & 0x80) != 0);
		ledw.set((value & 0x40) != 0);
	}

	public void sfrWrite(int reg,int value)
	{
		if (reg == MCS51Constants.P0)
		{
			boolean newMotorPower = (value & 8) == 0;
			
			if (newMotorPower && !motorPower)
			{
				cpu.addAsyncTimerListenerMillis(pulseTime,DiseqcPeripheral.this);
			}
			
			motorPower = newMotorPower;
			
			led.set((value & 0x04) == 0);
			ledp.set(motorPower);


		}
		else
		{
			lede.set((value & 0x80) != 0);
			ledw.set((value & 0x40) != 0);
		}
			
	}

	
	public void expired(MCS51 c)
	{

		class EndPulse implements AsyncTimerListener
		{
			private int direction;

			EndPulse(int direction)
			{
				this.direction = direction;
			}
			
			public void expired(MCS51 c1)
			{
				motorPosition += direction;
				position.setValue(motorPosition);
				cpu.sfrReset(MCS51Constants.P1,0x10);
				if (motorPower)
					cpu.addAsyncTimerListenerMillis(pulseTime,DiseqcPeripheral.this);

			}
			
		}

		if (!motorPower)
			return;
		
		int direction = 0;

		if (lede.get())
		{
			if (motorPosition > MIN)
			{
				direction = -1;
			}
		}
		else
		{
			if (motorPosition < MAX)
			{
				direction = 1;
			}
		}

		if (direction != 0)
		{
			motorPosition += direction;
			position.setValue(motorPosition);
			cpu.sfrSet(MCS51Constants.P1,0x10);
			cpu.addAsyncTimerListenerMillis(pulseWidth,new EndPulse(direction));
		}
		
	}
	

	public void registerCpu(MCS51 cpu)
	{
		this.cpu = cpu;
		cpu.addSfrWriteListener(MCS51Constants.P0,this);
		cpu.addSfrWriteListener(MCS51Constants.P1,this);
		cpu.addSfrReadListener(MCS51Constants.P0,this);
		cpu.addResetListener(this);
		pulseWidth = 15;
		pulseTime  = 50;
		//pulseWidth *= (int)(cpu.oscillator() / cpu.cycles() / 1000) ;
		//pulseTime  *= (int)(cpu.oscillator() / cpu.cycles() / 1000) ;
		

	}
}

public class Diseqc extends LPC764Base
{
	DiseqcAtmel24C16 eeprom;
	
	public Diseqc() throws Exception
	{
		super("DISEQC");
		oscillator = 11059200;

		addPeripheral(new DiseqcPeripheral());
		addPeripheral(eeprom = new DiseqcAtmel24C16());
		addPeripheral(new LPC764Port());
	}

	public int eeprom(int add)
	{
		add *= 2;
		int value = eeprom.read(add) << 8;
		value |= eeprom.read(add+1);
		

		return value;
	}
	
	public String toString()
	{
		return "Diseqc 1.2 $Id: Diseqc.java,v 1.7 2005/11/29 03:47:25 mviara Exp $";
	}
				

}
