BETA TEST
=========
J51 a Java Intel 8051 family emulator.

run : java -jar j51.jar

A j51.conf must exist with the supported cpu class names.

FILES
=======

Structure of the 
CHANGES
=======
0.4		16 January 2006
		Improved Port emulation no more the 1 update / ms.
		Fixed bug in makefile for linux.
		Fixed bug in CJNE .... the CY was not correct.
		Improved performance of emulated port.
		Added support for Keil MCB900 board.
		Added support for Atmel 89C51 family.
		Added support for 8052 Timer2.
		Fixed bug in MOVX A,@DPTR (was MOVX A,@DPTR+A)
		Added support to edit Clock in the main.
		Fixed bug in DEC @Rx
		Fixed bug in CPL A and CPL DIRECT
		Fixed bug in ANL C,#BIT and ANL C,NOT #BIT
		Fixed bug in diseqc emulator the motor when the program
		startup do not go do the saved position.
		Fixed bug timer mode 1.
		Fixed bug in reset cpu, some SFR was not cleared.
		Added Watch Dog for LPC900 family.
		Improved statistics of cpu usage.
		Improved emulation for LPC900 family.
		Improved performance.

0.3		02 November 2005
		Added stack check in push/pop.
		Added menu Tools->Statistics to dump in mcs51.txt statistics
		about opcode executed.
		Added support to edit register in register window with
		automatic update of SFR and assembly.
		Added support for LPC900.
		Added support for persistent object like eeprom or flash.
		Added support for input in swing interface for port.
		Fixed bug in look and feel now the default look and feel
		is Metal.

0.2		13 October 2004
		Added support for decoding ACALL/AJMP.

0.1 Beta	24 August 2004
		Fixed many emulator bug.
		Added support for the received on the emulated serial.
		Added name for bit special function register.

0.0 Beta	04 August 2004
		First public beta

File extension
==============
.flash	- Is for flash memory
.eeprom	- Is for eeprom memory
.misc	- Is for special function memory
