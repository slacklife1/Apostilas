*************************************************
*  Thanks for downloading JNI Sample  *
*************************************************

-- About JNISample:
  This is a simple HelloWorld program and uses Java Native Interface (JNI)
  to call Native methods written in C.


-- How to Make and Run :
  To Run  (Linux):  go to MAKE/LINUX directory and type (in console) "sh run.sh" . 
  To Make (Linux):  go to SRC directory and type (in console) "sh make.sh" . 
  * You can run RUN.SH in SRC directory to run the program after compiling it, too *
 
  To Run (win32): go to MAKE/WIN32 directory and run RUN.BAT . * "java.exe" should find in PATH *


-- Requirement:
  JDK1.1 or higher
  -- if you wat to compile the program:
    CC / GCC or G++ compiler for Linux.
    any C/C++ compiler for Windows.
    

-- Content:

  src/hello.c  --> contains the native method witch writes this text: "Hello, World From C."
  src/Hello.h --> Generated header file with Machine (with JAVAH)
  src/Hello.java  --> main Java program. it calls that native method and Compare the speeds of  Native and Java methods.
  src/make.sh -->  for compiling
  src/run.sh  --> for running the program

  make/linux/Hello.class --> generated with JAVAC
  make/linux/hello.o   --> generateds with CC 
  make/linux/libhello.so  --> shared library, generated with CC
  make/linux/run.sh 

  make/win32/Hello.class --> generated with JAVAC
  make/win32/hello.dll  --> dynamic library, generated with Borland c++5
  make/win32/run.bat 

  include/*    --> header files , comes from $JAVA_HOME/include


-- By Ali heidari
   Please send bugs, questions and your suggestion to ali@3tar.com, thanx :-)
