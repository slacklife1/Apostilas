#!/bin/sh

# JNI Sample by Ali heidari
# Please send bugs and your suggestion to ali@3tar.com, thanx :-)

if [ ! "$JAVA_HOME" ]; then
 echo "* Could not find JAVA Compiler *"
 echo "Type your JAVA installation path: (ex: /home/username/jdk1.4.0_01)"
 read JAVA_HOME
 if [ ! -x "$JAVA_HOME/bin/javac" ]; then
   echo "could not find..."
   echo "Please set the JAVA_HOME environment variable."
   echo "Program will exit."
   exit 1
 fi
fi

jbin=$JAVA_HOME/bin

$jbin/javac Hello.java 
$jbin/javah Hello

cc -I../include -c hello.c 
cc -shared hello.o -o libhello.so

echo ""
echo "*        Compiling finished           *"
echo "*    run RUN.SH to see the program    *"
echo ""
