
public class Hello {

	public native void printHello();

	static {
		System.loadLibrary("hello");  // System will search for this file:
	 								  // "libhello.so"(linux) or "hello.dll"(win32)
	 								  // in LD_LIBRARY_PATH
		//System.load("apsolute/path/to/libhello.so");
	}

	public static void main(String args[]) {
		long t1, t2, tc, tj;
		Hello h = new Hello();

		t1 = System.currentTimeMillis();
		h.printHello();
		t2 = System.currentTimeMillis();
		tc = t2-t1;

		t1 = System.currentTimeMillis();
		for(int i=1 ; i<=1000; i++)
		   System.out.println(String.valueOf(i)+" : Hello, World from JAVA.");
		t2 = System.currentTimeMillis();
		tj = t2-t1;

		System.out.println("\n*** Speed of Native method:  "+ String.valueOf((float)1000/tc) + " (sentence / m.s)   ***");
		System.out.println("*** Speed of Java method:    "+ String.valueOf((float)1000/tj) + " (sentence / m.s)   ***\n");
	}

}