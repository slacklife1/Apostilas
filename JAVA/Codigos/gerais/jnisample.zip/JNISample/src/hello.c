#include <stdlib.h>

#include <jni.h>     // you can find this file in ../include
#include "Hello.h"   // not worry, this file will Generated with machine (javah)

JNIEXPORT void JNICALL Java_Hello_printHello (JNIEnv *env, jobject obj) {
 int i = 0;
 for(i=1 ; i<=1000; i++)
  printf("%i : Hello, World from C :-)\n",i);

 return;
}
