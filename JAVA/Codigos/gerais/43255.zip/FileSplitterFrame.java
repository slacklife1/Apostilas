import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class FileSplitterFrame extends JFrame implements ActionListener, KeyListener {
	private JButton btnBrowseFileDir, btnBrowseSplitDir, btnSplit, btnJoin, btnExit, btnHelp;
	private JTextField txtFileDir, txtSplitDir, txtSplitSize, txtFileSize, txtNumSplits;
	private JLabel lblFileSize, lblNumSplits, lblFileDir, lblSplitDir, lblSplitSize;
	private final JFileChooser fc;
	private final static String HELP_MSG = "File Splitter Instructions:\n\n"+
	"To Split A File:\n 1. Enter or browse path of file to split\n "+
	"2. Enter or browse directory/folder where the splits will be saved\n "+
	"3. Enter the size of the splits in bytes\n 4. Press Split\n\n"+
	"To Join A File:\n 1. Enter or browse the file to be joined (has a .sfl extension name)\n "+
	"   (joined file will be saved in the same folder)\n 2. Press Join";

	public FileSplitterFrame() {
		super("File Splitter");
		btnBrowseFileDir = new JButton("Browse");
		btnBrowseSplitDir = new JButton("Browse");
		btnSplit = new JButton("Split");
		btnJoin = new JButton("Join");
		btnExit = new JButton("Exit");
		btnHelp = new JButton("Help");
		txtFileDir = new JTextField();
		txtSplitDir = new JTextField();
		txtSplitSize = new JTextField();
		txtFileSize = new JTextField();
		txtNumSplits = new JTextField();
		lblFileSize = new JLabel("Size of file:");
		lblNumSplits = new JLabel("No. of splits:");
		lblFileDir = new JLabel("File to split/join:");
		lblSplitDir = new JLabel("Splits folder:");
		lblSplitSize = new JLabel("Size of splits:");
		fc = new JFileChooser();

		txtSplitSize.addKeyListener(this);

		txtFileDir.setPreferredSize(new Dimension(300, 28));
		txtSplitDir.setPreferredSize(new Dimension(300, 28));
		txtSplitSize.setPreferredSize(new Dimension(105, 28));
		txtFileSize.setPreferredSize(new Dimension(300, 28));
		txtNumSplits.setPreferredSize(new Dimension(300, 28));
		btnSplit.setPreferredSize(new Dimension(78, 28));
		btnJoin.setPreferredSize(new Dimension(78, 28));
		btnExit.setPreferredSize(new Dimension(78, 28));
		btnHelp.setPreferredSize(new Dimension(78, 28));

        txtFileDir.setEditable(false);
        txtSplitDir.setEditable(false);
        txtFileSize.setEditable(false);
        txtNumSplits.setEditable(false);
        lblFileSize.setHorizontalAlignment(JLabel.RIGHT);
        lblFileDir.setHorizontalAlignment(JLabel.RIGHT);
        lblSplitDir.setHorizontalAlignment(JLabel.RIGHT);
        lblSplitSize.setHorizontalAlignment(JLabel.RIGHT);
        lblNumSplits.setHorizontalAlignment(JLabel.RIGHT);

        txtFileSize.setBorder(BorderFactory.createEmptyBorder());
        txtNumSplits.setBorder(BorderFactory.createEmptyBorder());

        btnBrowseFileDir.addActionListener(this);
		btnBrowseSplitDir.addActionListener(this);
		btnSplit.addActionListener(this);
		btnJoin.addActionListener(this);
		btnHelp.addActionListener(this);
		btnExit.addActionListener(this);

		JPanel c = new JPanel();
		c.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();

		gbc.insets = new Insets(2, 2, 2, 2);
		gbc.gridwidth = 1;
		gbc.fill = gbc.NONE;
		gbc.anchor = gbc.EAST;
		c.add(lblFileDir, gbc);

		gbc.gridwidth = gbc.RELATIVE;
		c.add(txtFileDir, gbc);

		gbc.gridwidth = gbc.REMAINDER;
		c.add(btnBrowseFileDir, gbc);

		gbc.gridwidth = 1;
		c.add(lblSplitDir, gbc);

		gbc.gridwidth = gbc.RELATIVE;
		c.add(txtSplitDir, gbc);

		gbc.gridwidth = gbc.REMAINDER;
		c.add(btnBrowseSplitDir, gbc);

		gbc.gridwidth = 1;
		c.add(lblSplitSize, gbc);
		gbc.anchor = gbc.WEST;
		gbc.gridwidth = gbc.REMAINDER;
		c.add(txtSplitSize, gbc);

		gbc.gridwidth = 1;
		gbc.anchor = gbc.EAST;
        c.add(lblFileSize, gbc);
		gbc.anchor = gbc.WEST;
        gbc.gridwidth = gbc.REMAINDER;
        c.add(txtFileSize, gbc);

        gbc.gridwidth = 1;
		gbc.anchor = gbc.EAST;
        c.add(lblNumSplits, gbc);
		gbc.anchor = gbc.WEST;
        gbc.gridwidth = gbc.REMAINDER;
        c.add(txtNumSplits, gbc);

        gbc.anchor = gbc.CENTER;
        JPanel p = new JPanel();
		p.add(btnSplit);
		p.add(btnJoin);
		p.add(btnHelp);
		p.add(btnExit);
		c.add(p, gbc);

		getContentPane().setLayout(new FlowLayout());
		getContentPane().add(c);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		pack();
	}

	public void actionPerformed(ActionEvent evt) {
		JButton src = (JButton)evt.getSource();

		if (src == btnExit) {
			dispose();
			System.exit(0);
		} else if (src == btnBrowseFileDir) {
			// set directory of file chooser dialog to what is in txtFileDir
			fc.setCurrentDirectory(new File(txtFileDir.getText()));
			// show files and directories in file chooser
			fc.setFileSelectionMode(fc.FILES_AND_DIRECTORIES);
			int action = fc.showDialog(FileSplitterFrame.this, "Select");

			if (action == fc.APPROVE_OPTION) {
				String name = fc.getSelectedFile().getAbsolutePath();
				txtFileDir.setText(name);
				String path = fc.getCurrentDirectory().getPath();
				txtSplitDir.setText(path);
				txtFileSize.setText(fc.getSelectedFile().length()+" byte(s)");
				txtSplitSize.setText("1");
				computeNSplits();
				computeNSplits();
			}
		} else if (src == btnBrowseSplitDir) {
			// set directory of file chooser dialog to what is in txtSplitDir
			fc.setCurrentDirectory(new File(txtSplitDir.getText()));
			// show directories only in file chooser dialog
			fc.setFileSelectionMode(fc.DIRECTORIES_ONLY);
			int action = fc.showDialog(FileSplitterFrame.this, "Select");

			if (action == fc.APPROVE_OPTION) {
				String path = fc.getSelectedFile().getPath();
				txtSplitDir.setText(path);
			}
		} else if (src == btnJoin) {
        	long before = System.currentTimeMillis();
		    long retval = Splitter.join(txtFileDir.getText());
            long after = System.currentTimeMillis();
            System.out.println("Time elapsed: "+((after-before)/1000L));
			if (retval == -1) {
				msgbox("File is invalid. Must be a SFL file.",
				"Error", JOptionPane.ERROR_MESSAGE);
			} else if (retval == -2) {
			    msgbox("One of the split files is missing.",
			    "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                msgbox("Join Process Done!", "Join",
                JOptionPane.INFORMATION_MESSAGE);
            }
		} else if (src == btnSplit) {
			String s = txtSplitSize.getText();
			String f = txtFileDir.getText();
			String d = txtSplitDir.getText();
			long size = 0;
			boolean problem = false;
			try {
				size = Long.parseLong(s);
				if (size < 0L)
					problem = true;
			} catch (NumberFormatException nfx) {
                problem = true;
			}
			if (problem) { // was split size valid?
				msgbox("Invalid Split Size: "+s, "Error",
						JOptionPane.ERROR_MESSAGE);
				txtSplitSize.requestFocus();
				txtSplitSize.selectAll();
				return; // exit this method
            }
		    int retval = Splitter.split(f, d, size);
			if (retval == -1) {
				msgbox("File/Directory does not exist/is invalid.",
				"Error", JOptionPane.ERROR_MESSAGE);
			} else {
                msgbox("Split Process Done! Make sure not to lose"+
                " any of the files!", "Split",
                JOptionPane.INFORMATION_MESSAGE);
            }
		} else if (src == btnHelp) {
			msgbox(HELP_MSG, "Help", JOptionPane.INFORMATION_MESSAGE);
		}
	}

	public void keyPressed(KeyEvent e) {computeNSplits();}
	public void keyReleased(KeyEvent e) {computeNSplits();}
	public void keyTyped(KeyEvent e) { }

    private void computeNSplits() {
        File f = fc.getSelectedFile();
        if (f != null) {
            long fileSize = f.length();
            long splitSize = 0L;
            try {
                System.out.println(splitSize);
            	splitSize = Long.valueOf(txtSplitSize.getText()).longValue();
            } catch (NumberFormatException nfx) { splitSize = 1L; }
            txtNumSplits.setText(Splitter.computeNSplits(fileSize, splitSize)+"");
        }
    }
    
	public void msgbox(String msg, String title, int msgtype) {
		JOptionPane.showMessageDialog(FileSplitterFrame.this, msg, title,
			msgtype);
	}

	public static void main(String[] args) {
    	JFrame.setDefaultLookAndFeelDecorated(true);
		new FileSplitterFrame().setVisible(true);
	}
}