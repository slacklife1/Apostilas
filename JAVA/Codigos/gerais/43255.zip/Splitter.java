import java.io.*;

public class Splitter {
    // buffer size
    private static final int BUF_SIZE = 2048;
    // buffer - where bytes from read operations will be stored
    private static byte[] buffer = new byte[BUF_SIZE];

    public static long computeNSplits(long fileSize, long splitSize) {
        long nsplits = (long)Math.ceil((double)fileSize/splitSize);
        return nsplits;
    }
    
    public static int split(String file, String dir, long splitSize) {
        File f = new File(file);
        File d = new File(dir);
        // make sure file is a file and directory/folder is a
        //  directory/folder and both exists
        if (!f.isFile() || !d.isDirectory())
            return -1;

        RandomAccessFile in = null, out = null, zro = null;
        File f0, fn;
        long fileSize = f.length();
        // compute number of split files produced
        int nSplits = (int)computeNSplits(fileSize, splitSize);
        long acc = 0; // counts how many bytes have been written
        int ctr = 1; // file counter

        int n = (nSplits+"").length();
        String s0 = null;
        System.out.println(dir+" "+f.getName());
        if (dir.endsWith(File.separator))
            s0 = dir+f.getName();
        else
            s0 = dir+File.separator+f.getName();
        System.out.println(s0);
        f0 = new File(s0+".sfl");
        try {
            // create file (.sfl) containing list of split files
            f0.createNewFile();
            // open file for writing
            zro = new RandomAccessFile(f0, "rw");
            // open source file (to be split) for reading
            in = new RandomAccessFile(f, "r");
            // write source file's filename to .sfl file
            zro.writeUTF(s0);
            // write the source file's size
            zro.writeLong(fileSize);

            long bytesLeft = 0, // bytes left in buffer from last read
                bytesRead = 0, // bytes from last read to buffer
                offset, // index in buffer where writing start's from
                len, // bytes to be written to a file
                bytesToGo, // bytes left to be written to split file
                bytesWritten; // counts bytes written to split file
            while (acc < fileSize) {
                // create a file with a numbered extension name
                //  number depends on ctr variable
                String filename = s0+"."+padLeft(ctr+"", '0', n);
                // open this file
                out = new RandomAccessFile(filename, "rws");
                // write the name of this file to .sfl file
                zro.writeUTF(filename);
                bytesWritten = 0;
                while (bytesWritten < splitSize && acc < fileSize) {
                    if (bytesLeft <= 0) {
                        bytesRead = in.read(buffer);
                        bytesLeft = bytesRead;
                        offset = 0;
                    } else {
                        offset = bytesRead - bytesLeft;
                    }

                    bytesToGo = splitSize - bytesWritten;
                    if (bytesToGo > bytesLeft)
                        len = bytesLeft;
                    else
                        len = bytesToGo;
                    out.write(buffer, (int)offset, (int)len);
                    bytesLeft -= len;
                    bytesWritten += len;
                    acc += len;
                }
                // write the size of the split file
                zro.writeLong(bytesWritten);
                // close newly created file
                out.close();
                // increment file counter
                ctr++;
            }
        } catch (IOException iox) {
            iox.printStackTrace();
        } finally { // makes sure to do the ff:
            try {
                // close source file (the file to be split)
                if (in != null)
                    in.close();
                // close .sfl file
                if (zro != null)
                    zro.close();
                // close last split file opened
                if (out != null)
                    out.close();
            } catch (IOException iox) {
                iox.printStackTrace();
            }
        }
        // return how many files made
        return ctr;
    }

    public static long join(String src) {
        File f = new File(src);

        // did user enter a filename not a folder name or drive?
        if (!f.isFile())
            return -1;
        // does the file end with .sfl
        String name = f.getPath();
        int idx = name.lastIndexOf(".");
        String extname = name.substring(idx);
        System.out.println(extname);
        if (!extname.equalsIgnoreCase(".sfl"))
            return -1; // has no .sfl extension name

        RandomAccessFile zro = null, fn = null, out = null;
        File temp = null, orig = null;
        long fsctr = 0; // file size counter
        long fileSize = 0;
        try {
            zro = new RandomAccessFile(f, "r");
            // read the original filename of the split-ed files
            String fname = zro.readUTF();
            System.out.println("Filename: "+fname);
            // read the original file's size
            fileSize = zro.readLong();
            System.out.println("size: "+fileSize);
            // compare this filename to filename supplied to join()
            //  without the sfl extension name
            String f0 = name.substring(0, idx);
            System.out.println("f0 = "+f0);
            if (!f0.equals(fname))
                return -1; // invalid .sfl file
            // create File object for original file
            orig = new File(fname);
            // create and open temporary file
            String tmpname = src.substring(0, src.indexOf(File.separator)+1)+"split"+((int)(Math.random()*99999))+".tmp";
//            System.out.println(tmpname);
            temp = new File(tmpname);
            temp.createNewFile();
            out = new RandomAccessFile(temp, "rw");
            // read a filename of split file
            fname = zro.readUTF();

            while (fsctr < fileSize) {
                // read split file's size
                long fsize = zro.readLong();
                // check if file exists
                File file = new File(fname);
                if (!file.exists()) {
                    out.close(); // close temporary file
                    temp.delete(); // delete temporary file
                    return -2; // missing file
                }
                // open file
                fn = new RandomAccessFile(file, "r");
                long i = 0;
                int bytesRead = 0;
                while (i < fsize) {
                    // read from split file file
                    bytesRead = fn.read(buffer);
                    // write byte to original file
                    //  start constructing original file
                    out.write(buffer, 0, bytesRead);
                    // count bytes written to this file
                    fsctr+=bytesRead;
                    // count total bytes read from split file
                    i+=bytesRead;
                 }
                // close this split file
                fn.close();
                // see if we've completely constructed the file
                if (fsctr == fileSize)
                    break; // jump out off this loop
                // read another split file filename
                fname = zro.readUTF();
            }
        } catch (IOException iox) {
            iox.printStackTrace();
        } catch (Exception x) {
            x.printStackTrace();
        } finally { // make sure they're closed
            try {
                if (fn != null) fn.close();
                 // close zero file
                if (zro != null) zro.close();
                // close original file
                if (out != null) out.close();
            } catch (IOException iox) {
                iox.printStackTrace();
            }
        }
        // rename temporary file and rename to original file
        temp.renameTo(orig);
        return fsctr; // return file size
    }

    // pads a String with a character on its leftside
    private static String padLeft(String s, char pad, int len) {
        if (s.length() >= len)
            return s;
        StringBuffer ns = new StringBuffer(s);
        while (ns.length() < len)
            ns.insert(0, pad);
        return ns.toString();
    }
}