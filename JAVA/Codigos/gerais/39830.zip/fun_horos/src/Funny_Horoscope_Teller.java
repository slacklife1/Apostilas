/*
 * Program - Funny Horoscope Teller
 * File Name - Funny_Horoscope_Teller.java
 * Author - Shovon
 * Web site - http://www.shuvorim.tk
 * Email - ahsanul_haque_shovon@yahoo.com
 * (C) http://www.shuvorim.tk
 * All rights reserved.
 */


//importing java packages
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.net.*;

public class Funny_Horoscope_Teller extends Frame implements ActionListener, KeyListener, WindowListener
{
  //other class instances
  Logo_Canvas lcanv;
  About abt;
  Help hlp;
  Jokes jk;
  int rnd_joke;

  AudioClip error; //instance of the AudioClip class
  File fil; //instance of the File class
  URL direct; //instance of the URL class

  Toolkit tk; //for getting the toolkit
  Dimension dim; //for getting the screen resolution

  MenuBar mbar;
  Menu mnu_file;
  Menu mnu_help;
  MenuItem tell;
  MenuItem refresh;
  MenuItem exit;
  MenuItem help;
  MenuItem about;	

  Label your_name; //instance of Label class
  Label date_of_birth; //instance of Label class

  Choice date; //instance of Choice class
  Choice month; //instance of Choice class

  Button tell_me; //instance of Button class
  Button reset; //instance of Button class

  TextField name; //instance of TextField class
  TextField year; //instance of TextField class
  TextArea horoscope; //instance of TextArea class

  String get_year = ""; //String variable
  int check_year = 0; //integer variable
  Color back, front; //instances of Color class

  public Funny_Horoscope_Teller() //constructor
  {
    setTitle("Funny Horoscope Teller 1.1");
    setLayout(new FlowLayout());

    back = new Color(235,235,235); //creating window's background color
    front = new Color(0,0,130); //creating window's foreground color

    setBackground(back); //setting window's background color
    setForeground(front); //setting window's foreground color

    mbar = new MenuBar();
    setMenuBar(mbar);

    mnu_file = new Menu("File");
    tell = new MenuItem("Tell me");
    refresh = new MenuItem("Reset");
    exit = new MenuItem("Exit");

    mnu_file.add(tell);
    mnu_file.add(refresh);
    mnu_file.addSeparator();
    mnu_file.add(exit);
    mbar.add(mnu_file);

    mnu_help = new Menu("Help");
    help = new MenuItem("Help");
    about = new MenuItem("About");
    mnu_help.add(help);
    mnu_help.addSeparator();
    mnu_help.add(about);
    mbar.add(mnu_help);

    tell.addActionListener(this);
    refresh.addActionListener(this);
    exit.addActionListener(this);
    help.addActionListener(this);
    about.addActionListener(this);

    fil=new File("user.dir");

    try
    {
      direct=fil.toURL();
      error=Applet.newAudioClip(new URL(direct,"data/error.au"));
    }

    catch(MalformedURLException e)
    {
      //do nothiong!
    }

    //initializing Logo_Canvas
    lcanv = new Logo_Canvas();

    //initializing Jokes
    jk = new Jokes();

    //initializing Labels
    your_name = new Label("Enter your name here :");
    date_of_birth = new Label("Date of birth (mm/ dd/ yyyy)");

    //initializing TextFields
    name = new TextField(30);
    year = new TextField(3);

    //initializing and adding dates using for loop
    date = new Choice();

    for(int i = 1; i<=31; i++)
    {
      date.add(String.valueOf(i));
    }

    date.select(0); //selected by default

    //initializing and adding months
    month = new Choice();
    month.add("January");
    month.add("February");
    month.add("March");
    month.add("April");
    month.add("May");
    month.add("June");
    month.add("July");
    month.add("August");
    month.add("September");
    month.add("October");
    month.add("November");
    month.add("December");
    month.select(0); //selected by default

    //initializing and designing the Buttons
    tell_me = new Button("Tell me");
    tell_me.setFont(new Font("Courier",Font.BOLD,16));
    tell_me.setBackground(Color.orange);
    tell_me.setForeground(Color.white);

    reset = new Button("Reset");
    reset.setFont(new Font("Courier",Font.BOLD,16));
    reset.setBackground(Color.orange);
    reset.setForeground(Color.white);

    //initializing the TextArea
    horoscope = new TextArea(8,50);
    horoscope.setEditable(false);
    horoscope.setFont(new Font("Verdana",Font.BOLD,12));

    //adding all components to the window
    add(lcanv);
    add(your_name);
    add(name);
    add(date_of_birth);
    add(month);
    add(date);
    add(year);
    add(tell_me);
    add(reset);
    add(horoscope);

    //adding KeyListener to the TextFields
    name.addKeyListener(this);
    year.addKeyListener(this);

    //adding ActionListener to the buttons
    tell_me.addActionListener(this);
    reset.addActionListener(this);

    //adding WindowListener to the window
    addWindowListener(this);

    tk = this.getToolkit();
    dim = tk.getScreenSize();

    setBounds(dim.width/4, dim.height/4, 400, 340);
    setResizable(false);
    setVisible(true);
  }

  //a method to get the user name
  private String getUserName()
  {
    String temp = name.getText();

    //if the user leave the Name field blank,
    //then the default name 'Unknown' will be shown

    if(temp.equals(""))
     temp = "Unknown";

    return temp;
  }

  //a method to get the user's zodiac/star sign
  private String getZodiac()
  {
    String month_name = month.getSelectedItem();
    int date_index = date.getSelectedIndex();
    String zodiac = "";

    //1
    if(month_name.equals("March"))
    {
      if(date_index >= 20)
      zodiac = "Aries";

      else if(date_index <= 19)
      zodiac = "Pisces";
    }

    //2
    if(month_name.equals("April"))
    {
      if(date_index >= 20)
      zodiac = "Taurus";

      else if(date_index <= 19)
      zodiac = "Aries";
    }

    //3
    if(month_name.equals("May"))
    {
      if(date_index >= 21)
      zodiac = "Gemini";

      else if(date_index <= 20)
      zodiac = "Taurus";
    }

    //4
    if(month_name.equals("June"))
    {
      if(date_index >= 21)
      zodiac = "Cancer";

      else if(date_index <= 20)
      zodiac = "Gemini";
    }

    //5
    if(month_name.equals("July"))
    {
      if(date_index >= 22)
      zodiac = "Leo";

      else if(date_index <= 21)
      zodiac = "Cancer";
    }

    //6
    if(month_name.equals("August"))
    {
      if(date_index >= 23)
      zodiac = "Virgo";

      else if(date_index <= 22)
      zodiac = "Leo";
    }

    //7
    if(month_name.equals("September"))
    {
      if(date_index >= 23)
      zodiac = "Libra";

      else if(date_index <= 22)
      zodiac = "Virgo";
    }

    //8
    if(month_name.equals("October"))
    {
      if(date_index >= 23)
      zodiac = "Scorpio";

      else if(date_index <= 22)
      zodiac = "Libra";
    }

    //9
    if(month_name.equals("November"))
    {
      if(date_index >= 22)
      zodiac = "Sagittarius";

      else if(date_index <= 21)
      zodiac = "Scorpio";
    }

    //10
    if(month_name.equals("December"))
    {
      if(date_index >= 21)
      zodiac = "Capricorn";

      else if(date_index <= 20)
      zodiac = "Sagittarius";
    }

    //11
    if(month_name.equals("January"))
    {
      if(date_index >= 20)
      zodiac = "Aquarius";

      else if(date_index <= 19)
      zodiac = "Capricorn";
    }

    //12
    if(month_name.equals("February"))
    {
      if(date_index >= 18)
      zodiac = "Pisces";

      else if(date_index <= 17)
      zodiac = "Aquarius";
    }

    return zodiac;
  }

  //handling action events by actionPerformed() method
  public void actionPerformed(ActionEvent ae)
  {
    try
    {
      if((ae.getSource() == tell_me) || (ae.getSource() == tell))
      {
	check_year = Integer.parseInt(year.getText());
	get_year = year.getText();
	int len = year.getText().length();

	if(len<4)
	{
	  error.play();
	  horoscope.setText("Sorry " + getUserName() + ", that was an invalid year! Please enter a full\n year (e.g. 1980) to get your star sign now and a joke also!");
	  tell_me.setEnabled(false);
	  tell.setEnabled(false);
	}

	else
	{
	  rnd_joke = (int)(Math.random()*27)+1;
	  horoscope.setText(getUserName() + " you are " + getZodiac() + ". Here is todays joke for you :\n\n"+jk.sr[rnd_joke]);
	  tell_me.setEnabled(false);
	  tell.setEnabled(false);
	}
      }
    }

    catch(NumberFormatException e)
    {
      error.play();
      horoscope.setText("Sorry " + getUserName() + ", that was an invalid year! Please enter a full\n year (e.g. 1980) to get your star sign now and a joke also!");
      tell_me.setEnabled(false);
      tell.setEnabled(false);
    }

    if((ae.getSource() == reset) || (ae.getSource() == refresh))
    {
      name.setText("");
      month.select(0);
      date.select(0);
      year.setText("");
      horoscope.setText("");
      tell_me.setEnabled(true);
      tell.setEnabled(true);
    }

    if(ae.getSource() == exit)
    {
      dispose();
      setVisible(false);
      System.exit(0);
    }

    if(ae.getSource() == help)
     hlp = new Help();

    if(ae.getSource() == about)
    {
      abt = new About();
    }
  }

  //handling key events
  public void keyPressed(KeyEvent ke)
  {
    if(ke.getSource() == year)
    {
      String sr = year.getText();

      if(sr.length()>3)
      {
	error.play();
	year.setText("");
	horoscope.setText("Sorry " + getUserName() + ", that was an invalid year! Please enter a full\n year (e.g. 1980) to get your star sign now and a joke also!");
	tell_me.setEnabled(false);
	tell.setEnabled(false);
      }
    }
  }

  public void keyTyped(KeyEvent ke)
  {
    //do nothing!
  }

  public void keyReleased(KeyEvent ke)
  {
    //do nothing!
  }

  public void windowClosing(WindowEvent we)
  {
    dispose();
    setVisible(false);
    System.exit(0);
  }

  public void windowClosed(WindowEvent we)
  {
    //do nothing!
  }

  public void windowOpened(WindowEvent we)
  {
    //do nothing!
  }

  public void windowActivated(WindowEvent we)
  {
    //do nothing!
  }

  public void windowDeactivated(WindowEvent we)
  {
    //do nothing!
  }

  public void windowIconified(WindowEvent we)
  {
    //do nothing!
  }

  public void windowDeiconified(WindowEvent we)
  {
    //do nothing!
  }

  public static void main(String[] args)
  {
    new Funny_Horoscope_Teller();
  }
}

/******************************************************/

class Logo_Canvas extends Canvas
{
  Image logo; //instance of image class

  public Logo_Canvas() //constructor
  {
    //getting the image
    try
    {
      logo=Toolkit.getDefaultToolkit().getImage("data/funny_1.1.gif");
    }

    catch(Exception e)
    {
      //do nothing!
    }

    setSize(292,40); //setting size of the canvas
    setVisible(true); //set it visible
  }

  public void paint(Graphics g)
  {
    g.drawImage(logo,0,0,this); //drawing the image on the canvas
  }
}

/******************************************************/

class About extends Frame implements WindowListener
{
  Color back=new Color(235,235,235);
  Color front=new Color(0,0,130);
  Image mini_logo;

  Toolkit tk;
  Dimension dim;

  public About()
  {
    setTitle("About Us");
    setLayout(new FlowLayout());
    setBackground(back);
    addWindowListener(this);

    try
    {
      mini_logo=Toolkit.getDefaultToolkit().getImage("data/mini_logo.gif");
    }

    catch(Exception e)
    {
      //do nothing!
    }

    tk = this.getToolkit();
    dim = tk.getScreenSize();

    setBounds(dim.width/4, dim.height/4, 270, 170);
    setResizable(false);
    setVisible(true);
  }

  public void paint(Graphics g)
  {
    g.drawImage(mini_logo,10,30,this);
    Font normal=new Font("Default",Font.PLAIN,12);

    g.setFont(normal);
    g.setColor(front);
    g.drawString("Author: Shovon", 10, 75);
    g.drawString("Free for personal use only.", 10, 90);
    g.drawString("Email: ahsanul_haque_shovon@yahoo.com", 10, 105);
    g.drawString("Web Site: http://www.shuvorim.tk", 10, 120);
    g.drawString("(C) http://www.shuvorim.tk", 10, 135);
    g.drawString("All rights reserved.", 10, 150);
  }

  public void windowClosing(WindowEvent we)
  {
    dispose();
    setVisible(false);
  }

  public void windowClosed(WindowEvent we)
  {
    //do nothing!
  }

  public void windowOpened(WindowEvent we)
  {
    //do nothing!
  }

  public void windowActivated(WindowEvent we)
  {
    //do nothing!
  }

  public void windowDeactivated(WindowEvent we)
  {
    //do nothing!
  }

  public void windowIconified(WindowEvent we)
  {
    //do nothing!
  }

  public void windowDeiconified(WindowEvent we)
  {
    //do nothing!
  }
}

/******************************************************/

class Help extends Frame implements WindowListener
{
  TextArea ta = new TextArea();
  String str = "";

  Toolkit tk;
  Dimension dim;

  public Help()
  {
    setTitle("Help");
    setLayout(new BorderLayout());
    ta.setEditable(false);

    add(ta,BorderLayout.CENTER);
    addWindowListener(this);

    try
    {
      FileInputStream fis=new FileInputStream("data/Help_File");
      int iBytes=fis.available();
      byte b[]=new byte[iBytes];
      int iBytesRead=fis.read(b,0,iBytes);
      ta.setText(new String(b));
    }

    catch(Exception e)
    {
      //do nothing!
    }

    tk = this.getToolkit();
    dim = tk.getScreenSize();

    setBounds(dim.width/4, dim.height/4, 320, 300);
    setResizable(false);
    setVisible(true);
  }

  public void windowIconified(WindowEvent we)
  {
    //do nothing!
  }

  public void windowDeiconified(WindowEvent we)
  {
    //do nothing!
  }

  public void windowActivated(WindowEvent we)
  {
    //do nothing!
  }

  public void windowDeactivated(WindowEvent we)
  {
    //do nothing!
  }

  public void windowClosed(WindowEvent we)
  {
    //do nothing!
  }

  public void windowOpened(WindowEvent we)
  {
    //do nothing!
  }

  public void windowClosing(WindowEvent we)
  {
    dispose();
    setVisible(false);
  }
}
