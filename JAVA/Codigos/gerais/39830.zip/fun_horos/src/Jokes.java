/*
 * Program - Funny Horoscope Teller
 * File Name - Jokes.java
 * Author - Shovon
 * Web site - http://www.shuvorim.tk
 * Email - ahsanul_haque_shovon@yahoo.com
 * (C) http://www.shuvorim.tk
 * All rights reserved.
 */


//Collection of jokes
//This class file is the
//source for random jokes...

public class Jokes
{
  String sr[] =
  {
	"", //0

	"747 FULL OF LAWYERS...\n"+
	"Q: Hear about the terrorist that hijacked a 747 full of\n"+
	"lawyers?\n"+
	"A: He threatened to release one every hour if his demands\n"+
	"were not met.\n", //1

	"A STONER STUMBLES OUT OF A PARTY...\n"+
	"A stoner stumbles out of a party, and starts to walk home.\n"+
	"One the way he bumps into a guy who is all bloody and\n"+
	"mangled. The guy limps up to the stoner and says, Call me\n"+
	"an ambulance! The stoner looks at him for a second, smiles\n"+
	"and says, You are an ambulance!\n", //2

	"A FEW GOOD LAWYERS...\n"+
	"A lawyer is standing in a long line at the box office.\n"+
	"Suddenly, he feels a pair of hands kneading his shoulders,\n"+
	"back, and neck. The lawyer turns around.\n"+
	"What the hell do you think you are doing?\n"+
	"I am a chiropractor, and I am just keeping in practice\n"+
	"while I am waiting in the line.\n"+
	"Well, I am a lawyer, but you do not see me screwing the\n"+
	"guy in front of me, do you?\n", //3

	"ABC...\n"+
	"Wilfred had just learned his abc and was very scared of\n"+
	"doing them in front of the class. The teacher, though, told\n"+
	"him that the best way to conquer his fears would be to just\n"+
	"go ahead and do it. So, trembling, he stood in front of the\n"+
	"class and began.\n"+
	"ABCDEFGHIJLKMNOQRSTUVWXYZ.\n"+
	"Very good, Wilfred. But you forgot the P. Where is the P?\n"+
	"It is running down my leg.\n", //4

	"BEAUTIFUL...\n"+
	"There was a lawyer and he was just waking up from anesthesia\n"+
	"after surgery, and his wife was sitting by his side. His\n"+
	"eyes fluttered open and he said, You're beautiful! and then\n"+
	"he fell asleep again. His wife had never heard him say that\n"+
	"so she stayed by his side. A couple minutes later his eyes\n"+
	"fluttered open and he said You're cute! Well, the wife was\n"+
	"dissapointed because instead of beautiful it was cute.\n"+
	"She said, What happened to beautiful?\n"+
	"His reply was, The drugs are wearing off!\n", //5

	"BURIED LAWYERS...\n"+
	"Q: What do you have when 100 lawyers are buried up to their\n"+
	"neck in sand?\n"+
	"A: Not enough sand.\n", //6

	"CHRISTMAS BONUS...\n"+
	"Boss: Who said that just because I tried to kiss you at last\n"+
	"months Christmas party, you could neglect to do your work\n"+
	"around here?\n"+
	"Secretary: My lawyer.\n", //7 

	"DEFENSE LAWYERS GOOD NEWS...\n"+
	"I have good news and bad news, the defense lawyer says to his\n"+
	"client.\n"+
	"What is the bad news?\n"+
	"The lawyer says, Your blood matches the DNA found at the murder\n"+
	"scene.\n"+
	"Dammit! cries the client. What is the good news?\n"+
	"Well, the lawyer says, Your cholesterol is down to 140.\n", //8 

	"DEGREES OF THE LAW...\n"+
	"Q: What do you call a lawyer who does not know the law?\n"+
	"A: A judge.\n", //9

	"DO NOT MESS WITH THE JUDGE...\n"+
	"There were three men at a bar. One man got drunk and started a fight\n"+
	"with the other two men. The police came and took the drunk guy to\n"+
	"jail. The next day the man went before the judge.\n"+
	"The judge asked the man, Where do you work?\n"+
	"The man said, Here and there.\n"+
	"The judge asked the man, What do you do for a living?\n"+
	"The man said, This and that.\n"+
	"The judge then said, Take him away.\n"+
	"The man said, Wait, judge when will I get out?\n"+
	"The judge said to the man, Sooner or later.\n", //10

	"DROWNING LAWYER...\n"+
	"Q: How do you stop a lawyer from drowning?\n"+
	"A: Shoot him before he hits the water.\n", //11

	"FEMALE LAWYER VS. PITBULL...\n"+
	"Q: What is the difference between a female lawyer and a pitbull?\n"+
	"A: Lipstick.\n", //12

	"HARVARD, YALE AND URINAL ETIQUETTE...\n"+
	"A Harvard and Yale Law grad met in a washroom during a law convention.\n"+
	"The Harvard graduate said, Did not they teach you to wash your hands\n"+
	"at Yale?\n"+
	"The Yale grad responded, They taught us not to piss on our hands.\n", //13

	"HELLACIOUS...\n"+
	"Q: Why did the lawyer go to Heaven?\n"+
	"A: Hell was full.\n", //14

	"LAW SCHOOL FOR NUNS...\n"+
	"Q: What do you call a nun who just passed her bar exam?\n"+
	"A: A sister-in-law.\n", //15

	"LAWYER AND SPREM...\n"+
	"Q: What do a lawyer and a sperm have in common?\n"+
	"A: Both have about a one in 3 million chance of becoming a human being.\n", //16 

	"LAWYER AND VULTURE...\n"+
	"Q: What is the difference between a lawyer and a vulture?\n"+
	"A: Wings.\n", //17

	"LAWYER BRAINS...\n"+
	"A doctor notices a sidewalk stand that says BRAINS FOR SALE. He goes\n"+
	"over to investigate and sees a sign that says Doctor brains $8.00 a\n"+
	"pound and another sign that says Paramedic brains $12.00 a pound, Nurses\n"+
	"brains $30.00 a pound, truck driver $40.00 a pound and lawyers brains\n"+
	"$90.00 a pound.\n"+
	"So he asks the man behind the cashregister, how come his brains are only\n"+
	"worth 8.00 and a lawyers worth 90.00?\n"+
	"The man replies, do you know how many lawyers it takes to make a pound\n"+
	"of brains?\n", //18

	"LAWYER ON HIS DEATHBED...\n"+
	"A lawyer lies dying, his partner of 40 years by his bedside.\n"+
	"Jack, I have got to confess. I have been sleeping with your wife for 30\n"+
	"years and I am the father of your daughter, Hillary. On top of that, I\n"+
	"have been stealing from the firm for a decade.\n"+
	"Relax, says Jack, and don't think another thing about it. I am the one\n"+
	"who put arsenic in your martini.\n", //19

	"LAWYER OR ASS...\n"+
	"A man walks into a bar and he is really pissed. The bartender gives him\n"+
	"a drink and asks what the problem is. All he says is, All lawyers are\n"+
	"assholes.\n"+
	"A man sitting in the corner shouts, I take offense to that!\n"+
	"The pissed-off guy asks him, Why? Are you a lawyer?\n"+
	"He replies, No, I am an asshole.\n", //20

	"LAWYER STAMPS...\n"+
	"Q: Why did the post office recall the new lawyer stamps?\n"+
	"A: Because people could not tell which side to spit on.\n", //21

	"LAWYER VS. HOOKER...\n"+
	"Q: What is the difference between a lawyer and a hooker?\n"+
	"A: A hooker will stop trying to screw you once you are dead.\n", //22

	"LAWYER-CLIENT RELATIONS...\n"+
	"Q: Why does the bar association prohibit lawyers and clients from\n"+
	"having sex?\n"+
	"A: To prevent clients from being billed twice for essentially the\n"+
	"same service.\n", //23

	"LAWYERS N SHINGLES...\n"+
	"Q: How many lawyers does it take to roof a house?\n"+
	"A: Depends on how thin you slice them.\n", //24

	"LAWYERS AND GOD...\n"+
	"Q: What is the difference between a lawyer and God?\n"+
	"A: God does not think he is a lawyer.\n", //25

	"LAWYERS AND LIGHTBULBS...\n"+
	"Q: How many lawyers does it take to screw in a light bulb?\n"+
	"A: Four, one to climb the ladder, one to hold the ladder, one to\n"+
	"shake the ladder and one to sue the ladder company.\n", //26

	"LAWYERS IN LUST...\n"+
	"Two lawyers are walking down the street, when a beautiful woman\n"+
	"walks by.\n"+
	"Boy, I would like to screw her, says one lawyer.\n"+
	"I agree, says the other.\n"+
	"But out of what?\n", //27
  };
}
