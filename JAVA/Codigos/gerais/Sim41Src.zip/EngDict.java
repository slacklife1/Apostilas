/**
 * EngDict  - English Dictionary for Simredo.
 * Angla vortaro por Simredo.
 *
 * @version 1.0, 2004/08/17
 * @author Klivo
 * 
 */

import java.io.*;

public class EngDict extends EngDictFlags {

   private  char[]      dictionary_data;
   public   boolean     loaded = false;

   int      longestWord;
   int      numberOfChars;   // Number of chars of binary data for each word

   // Number of words according to length
   int[]    numberByLength  = new int[MAX_LENGTH + 1];

   // Base indices for searching dictionary data.
   // The end of each list is the following index minus one record.
   int[]    baseIndices     = new int[MAX_LENGTH + 1 + 1];

   int       size_of_dictionary;

   public EngDict (char[] dictionary_data) {
      this.dictionary_data = dictionary_data;
      checkDictionaryData();
   }


   /**
    * checkDictionaryData - Checks data consistency and initializes tables used 
    * by search method. Sets 'loaded' if successful.
    * Kontrolas gxustecon kaj plenigas la tabelojn uzatajn de la sercx-metodo. 
    * Starigas la flagon 'loaded' se sukcesa.
    */
   public void checkDictionaryData() {

      if (dictionary_data == null) return;   // bad

      if (dictionary_data.length < 3) {
         System.err.println("Dictionary too short> " + dictionary_data.length);
         return;
      }
      longestWord = (int)dictionary_data[0];
      if (longestWord > MAX_LENGTH) {
         System.err.println("Dictionary: longest word too long> " + longestWord);
         return;
      }
      if (dictionary_data.length < longestWord + 1) {
         System.err.println("Dictionary: too short> " + 
                             dictionary_data.length + "  " + longestWord);
         return;
      }

      numberOfChars = (int)dictionary_data[1];  // # of chars of flag-information
      if (numberOfChars > 5) {
         System.err.println("Dictionary: too many flag chars> " + numberOfChars);
         return;
      }
      for (int i = 2; i <= longestWord; i++) {
         numberByLength[i] = dictionary_data[i];
      }

      baseIndices[2] = longestWord + 1;
      // The base of a list is the end of the previous one.
      for (int i = 2; i <= longestWord; i++) {
         baseIndices[i+1] = baseIndices[i] + 
                            ((i + numberOfChars) * numberByLength[i]);
      }

      // Final check.
      int end = baseIndices[longestWord + 1];
      if (end != dictionary_data.length) {
         System.err.println("Dictionary corrupted> " + end + " != " + 
                             dictionary_data.length);
         return;
      }

      loaded = true;

   }  // end of "checkDictionaryData"



   /**
    * To search a word in the dictionary and return its flag information.
    * Por sercxi vorton en la vortaro kaj redoni ties flag-informojn.
    * @param the word to find / la sercxota vorto
    * @param start index of the word / komenco de la vorto
    * @param end index of the word / fino de la vorto
    * @param flags - to return suffix and prefix flags / redonas flagojn por sufiksoj kaj prefiksoj
    * @return true if found, false if not  / vera se trovita, falsa se netrovita
    */

   public boolean search(char[] theWord, int start, int end, char[] flags) {

      int    wordLength = end - start;

      int    base;
      int    bottom, top, middle;
      int    compareResult;
      int    index, i;

      if (loaded == false) return false;
      if (wordLength > longestWord) return false;

      int  wordLength2  = wordLength + numberOfChars; 

      base     = baseIndices[wordLength];
      bottom  = 0;
      top         = numberByLength[wordLength] - 1;

      while (bottom <= top) {
         middle = (top + bottom)/2;
         index = base + (middle * wordLength2);
         for (i = 0, compareResult = 0; 
             (i < wordLength) && (compareResult == 0); i++)
                 compareResult = (theWord[start + i] - dictionary_data[index + i]);
         //System.err.println("word " + new String(dictionary_data, index, wordLength));
         if (compareResult < 0) {
            top = middle -1;
         }
         else if (compareResult > 0) {
            bottom = middle+1;
         }
         else {
            // The word has been found. La vorto estas trovita.
            //i = 0;
            //while (i < numberOfChars && i < flags.length) {
            //   flags[i] = dictionary_data[index + wordLength + i];
            //   i++;
            //}
            // For English dictionary there is only one char of flags.
            // Por angla vortaro estas nur unu char de flagoj.
            flags[0] = dictionary_data[index + wordLength];
            return true;
         }

      }  // end of "while"

      return false;  // not found

   }  // end of search


}  // end of "EngDict"




