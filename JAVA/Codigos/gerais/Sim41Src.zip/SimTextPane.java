/*
 * I am subclassing JTextPane so that I can overwrite processKeyEvent. The 
 * main reason is that I want to implement a dead key (The user types two 
 * keys, eg. ^c, and a single accented letter appears). I previously tried 
 * to do this with a key map. I was able to cut out the dead key character 
 * and put in an accented letter, but the second letter always followed 
 * it (^ee). I tried to consume the second key event without success. 
 * Cleve 1999/01/12
 * I've changed the BasicTextUI, so that I can implement an Esperanto 
 * Spell-Checker.
 * Cleve 1999/02/10
 * I'm adding a timer to repaint the screen every 3 seconds, because Swing
 * doesn't always repaint correctly.
 * Cleve 1999/02/15
 * Correct linesInDocument(). Base calculation on size of text pane.
 * Cleve 1999/07/26
 * Add support for Persian (reverse text) and key maps.
 * Cleve 2000/12/05
 * Spell Check English. Expanded keymap functionality.
 * Cleve 2002/10/10
 * New English spellchecker
 * Cleve 2004/08/19
 * Don't reverse numbers for reversed text.
 * Cleve 2004/11/29
 *
 * Mi subklasigas JTextPane por superskribi la metodon processKeyEvent. La 
 * cxefa kialo estas ke mi volas krei senpasxan klavon. (La uzanto tajpas du 
 * klavojn, ekzemple ^c, kaj unu supersignita litero aperas.) Antauxe mi 
 * provis fari cxi tion per klavmapo. Mi sukcesis eltondi la senpasxan signon 
 * kaj enmeti supersignitan literon, sed la dua litero cxiam sekvis gxin (^cc). 
 * Mi provis "mangxi" la duan klaveventon sen sukceso.
 * Klivo 1999/01/12
 * Mi sxangxis la tekstan interfacon (BasicTextUI), por enmeti Esperantan
 * kontrolilon de literumado.
 * Klivo 1999/02/10
 * Mi enmetas horlogxon por repentri la ekranon cxiun trian sekundon, cxar "Sving"
 * ne cxiam repentras gxuste.
 * Korektu linesInDocument(). Kalkulu laux la grandeco de la tekstujo.
 * Klivo 1999/07/26
 * Subtenu Persan lingvon (inversigu tekston) kaj klavmapojn.
 * Klivo 2000/12/05
 * Kontrolu literumadon de la angla. Fortigu klavmapan funkcion.
 * Klivo 2002/10/10
 * Nova literumilo de anglolingvo
 * Klivo 2004/08/19
 * Ne inversigu numerojn dum inversigo de teksto.
 * Klivo 2004/11/29
 */

import java.awt.*;
import java.awt.im.*;
import java.awt.event.*;
import java.awt.print.*;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.plaf.*;
import javax.swing.plaf.basic.*;

public class SimTextPane extends JTextPane implements Printable, ActionListener {

   private String sim_dir;  // working directory / labordosierujo

   private String file_separator = "\\";  // \ for Windows, / for Linux
                                          // \ por Vindozo, / por Linukso

   // This is the view port which the text pane has been installed into.
   // Cxi tio estas la montrofenestro en kiu cxu tiu teksta kampo estas instalita.
   private JViewport      view_port;   

   private static char    typed_key = 0;          // tajpita klavo (signo)
   private static char    previously_typed = 0;   // antauxe tajpita signo

   private static Color   not_so_bright = new Color(235,235,235);   // ne tiom brila

   // first_action is used to request focus.
   // first_action (unua agevento) estas uzita por akiri fokuson.
   private boolean   first_action = true;
   private Timer the_timer;


   static boolean  is_gray = false;   // Background colour. Koloro de fono.

   static boolean  show_trans = false;  // For Esperanto - show trans/intrans
                                        // Por Esperanto - montru trans/netrans

   public SimTextPane () {
      super();
      startup();
   }

   public SimTextPane (String sim_dir) {
      super();
      this.sim_dir = sim_dir;
      startup();
   }

   private void startup() {

      file_separator = System.getProperty("file.separator");
      setUI(new SimTextUI());
      fontSize16();
      the_timer = new Timer(4000,this);  // four seconds  / kvar sekundoj
      the_timer.start();   // komencu
   }


   /*
    * fontSize16 - Set the font size to 16.
    * fontSize16 - Sxangxu la tiparan grandecon al 16.
    */
    private void fontSize16 () {
       Font font1 = getFont();
       setFont(font1.deriveFont(Font.PLAIN,16.0f));
    }



   /*
    * setTabs - Sets the tabs. This doesn't work.
    * - difinas tabpoziciojn. Cxi tio ne funkcias.
    */
   private void setTabs() {
      final int number_of_stops = 20;   // Nombro da taboj.
      TabStop[]  tabstops = new TabStop[number_of_stops];
      for (int i = 0; i < number_of_stops; i++) {
         tabstops[i] = new TabStop(40.0f * (i+1),
                     TabStop.ALIGN_LEFT,TabStop.LEAD_NONE);
      }
      TabSet tabset = new TabSet(tabstops);
      SimpleAttributeSet new_attribute = new SimpleAttributeSet();
      StyleConstants.setTabSet(new_attribute, tabset);
      StyleConstants.setLeftIndent(new_attribute, 10.0f);
      setParagraphAttributes(new_attribute,false);
      setCharacterAttributes(new_attribute,false);
   }  // setTabs



   public void actionPerformed(ActionEvent e) {

      // Must be timer. Devas esti horlogxo.
      if (first_action) {
         requestFocus();
         first_action = false;
      }
      repaint();
   }


   /* 
    * processKeyEvent - Capture key events and check whether dead 
    * key conversion is necessary.
    * processKeyEvent - Kaptu klaveventojn kaj kontrolu cxu konverto 
    * de senpasxa klavo necesas.
    */
   protected void processKeyEvent(KeyEvent e)  {

      int     pos;    // Position of caret. Pozicio de tekstomontrilo.
      String  previous_chars;
      char    accented_character;
      String  replacement;

      int  the_key_code   = e.getKeyCode();
      int  the_key_id     = e.getID();

      char[] typed_key_array = {0};
      typed_key_array[0] = e.getKeyChar();
      typed_key          = e.getKeyChar();

      //System.err.println("K " + typed_key + " " + (int)typed_key + 
      //                   " " + the_key_code + " " + the_key_id + "\n");


      // For debugging purposes. Por testaj celoj.
      if (the_key_code == KeyEvent.VK_F1 && the_key_id == KeyEvent.KEY_RELEASED) {
         // Get the text. Akiru la tekston.
         Document doc = getDocument();
         int length = doc.getLength();
         Segment text_segment = new Segment();
         try {
            doc.getText(0,length,text_segment);
         } catch (BadLocationException blx) { }
         int max = text_segment.count;
         int segoff = text_segment.offset;
         if (max > 20) max = 20;
         System.out.println("number " + max);
         System.out.println("caret position " + getCaretPosition());
         for (int i = 0; i < max; i++) {
            System.out.println("> " + text_segment.array[segoff + i] + " " +
                                    (int)text_segment.array[segoff + i] +
                 " " + Integer.toHexString((int)text_segment.array[segoff + i]));
         }
      } else


      // Set the flag to show transitivity. (Special Esperanto feature.)
      // Levu flagon por montri transitivecon.
      if (the_key_code == KeyEvent.VK_F2 && the_key_id == KeyEvent.KEY_RELEASED) {
         if (show_trans) show_trans = false;
         else show_trans = true;
      } else


      // Make background gray. Grizigu fonon.
      if (the_key_code == KeyEvent.VK_F3 && the_key_id == KeyEvent.KEY_RELEASED) {
         if (is_gray) {
            setBackground(Color.white);
            is_gray = false;
         }
         else {
            setBackground(not_so_bright);
            is_gray = true;
         }

      } else

      if (the_key_code == KeyEvent.VK_F4 && the_key_id == KeyEvent.KEY_RELEASED) {
      } else

      if (UserKeyMap.isEnabled()) {   
                // Key maps are such a bother...

         if (typed_key < '!'  || typed_key > '~') {
            super.processKeyEvent(e);
            if (the_key_code != KeyEvent.VK_SHIFT && 
                the_key_code != KeyEvent.VK_ALT) {
               previously_typed = ' ';
            }
            return;
         }

         if (the_key_id == KeyEvent.KEY_PRESSED || 
             the_key_id == KeyEvent.KEY_RELEASED) return;


         // Try to translate deadkey. Provu traduki senpasxan klavon.
         replacement = UserKeyMap.translate(previously_typed, typed_key);
         if (replacement != null) {
            //if (the_key_id == KeyEvent.KEY_TYPED) {
               pos = getCaretPosition();
               select(pos-1, pos);
               replaceSelection(replacement);
               previously_typed = replacement.charAt(0);
            //}
            return;
         }

         replacement = UserKeyMap.translate(typed_key, e.isControlDown(), e.isAltDown());
         if (replacement != null) {
            replaceSelection(replacement);
            previously_typed = replacement.charAt(0);
            return;
         }
         super.processKeyEvent(e);
            if (typed_key >= '!') previously_typed = typed_key;
      }
      else {   // user key map not active  /  Klavmapo neaktiva.
         super.processKeyEvent(e);
      }

   }  // processKeyEvent


   public void setViewport(JViewport view_port) {
      this.view_port = view_port;
   }

   Point      upper_left, bottom_right;  // coordinates of viewport  
                                         // koordinatoj de montrofenestro
   Dimension  port_size;                 // grandeco de montrofenestro
   Segment    text_segment = new Segment();
   Document   doc;                       // dokumento

   /* 
    * check_spelling  - Check the spelling of English words and draws a red 
    * underline under misspelled words.
    * - Kontrola literumadon de Anglaj vortoj kaj desegnas rugxan linion sub
    * misliterumitaj vortoj.
    */
   public void check_spelling (Graphics g) {

      int start_index, end_index;
      int y;  // For drawing underline. Por desegno de substreko.

      int  result;   // Result from spell-checker.  / Rezulto de literumilo

      Rectangle line_start;
      Rectangle line_end;

      if (view_port == null) return;

      if (speller == null || !speller.loader_OK) return;

      try {

         // Get upper left and lower right of view port.
         // Akiru supran maldekstron kaj malsupran dekstron de montrofenestro.
         upper_left = view_port.getViewPosition();
         port_size = view_port.getExtentSize();
         bottom_right  = new Point(port_size.width, upper_left.y + port_size.height);

         // Now get start and end indices from the interface.
         // Nun akiru komenco-kaj-fino-indeksojn de la interfaco.
         user_interface = getUI();
         start_index = user_interface.viewToModel(this, upper_left);
         end_index   = user_interface.viewToModel(this, bottom_right);

         // Get the text. Akiru la tekston.
         doc = getDocument();
         int length = doc.getLength();
         doc.getText(0,length,text_segment);
         int segoff = text_segment.offset;

         // Red underline for errors.   Rugxa substreko por eraroj.
         g.setColor(Color.red);

         for (int i = start_index; i < end_index; ) {
            if (isALatinLetter(text_segment.array, segoff + i)) {
               int word_start = i;
               while (i < end_index && isALatinLetter(text_segment.array, segoff + i)) i++;
               int word_end = i;
               if (word_end - word_start > 1) {
                  line_start = user_interface.modelToView(this, word_start);
                  line_end   = user_interface.modelToView(this, word_end);
                  y = line_start.y + line_start.height - 3;
                  result = speller.check(text_segment.array, segoff + word_start, segoff + word_end);
                  if (result == 0) {  // unknown word.   nekonata vorto
                     // draw a line  /  desegnu linion
                     g.drawLine(line_start.x, y, line_end.x, y);
                  }
                  else if (result == 2) {  // Word OK, capitalization problem.  Bona vorto, problemo de majuskleco.
                     g.drawLine(line_start.x, y, line_start.x + 10, y);
                  }
               }
            }
            else i++;  // Skip nonletters. Preteriru neliteroj.
         } // for

         g.setColor(Color.black);
      } catch (BadLocationException ble) {
         System.err.println("Error in check_spelling. Eraro en kontrolo de literumado.");
         return;
      }

   }  // check_spelling





   /* 
    * check_esp_spelling  - Check the spelling of Esperanto words and draws a red 
    * underline under misspelled words.
    * - Kontrolas literumadon de Esperantaj vortoj kaj desegnas rugxan linion sub
    * misliterumitaj vortoj.
    */
   VortInformoj  vi = new VortInformoj();
   TextUI        user_interface;

   public void check_esp_spelling (Graphics g) {

      int start_index, end_index;
      int y;  // For drawing underline. Por desegno de substreko.

      Rectangle line_start;
      Rectangle line_end;

      if (view_port == null) return;
      if (esp == null) return;

      try {

         // Get upper left and lower right of view port.
         // Akiru supran maldekstron kaj malsupran dekstron de montrofenestro.
         upper_left = view_port.getViewPosition();
         port_size = view_port.getExtentSize();
         bottom_right  = new Point(port_size.width, upper_left.y + port_size.height);

         // Now get start and end indices from the interface.
         // Nun akiru komenco-kaj-fino-indeksojn de la interfaco.
         user_interface = getUI();
         start_index = user_interface.viewToModel(this, upper_left);
         end_index   = user_interface.viewToModel(this, bottom_right);

         // Get the text. Akiru la tekston.
         doc = getDocument();
         int length = doc.getLength();
         doc.getText(0,length,text_segment);
         int segoff = text_segment.offset;

         // Red underline for errors.   Rugxa substreko por eraroj.
         g.setColor(Color.red);

         for (int i = start_index; i < end_index; ) {
            if (isALatinLetter(text_segment.array, segoff + i)) {
               int word_start = i;
               while (i < end_index && isALatinLetter(text_segment.array, segoff + i)) i++;
               int word_end = i;
               if (word_end - word_start > 1) {
                  checkEspWord(g, segoff, word_start, word_end);
               }
            }
            else i++;  // Skip nonletters. Preteriru neliteroj.
         } // for

         g.setColor(Color.black);
      } catch (BadLocationException ble) {
         System.err.println("Error in check_esp_spelling. Eraro en kontrolo de literumado.");
         return;
      }

   }  // check_esp_spelling



   /* 
    * checkEspWord  - Checks the spelling of an Esperanto word.
    * Draws a red underline under misspelled words.
    * - Kontrolas literumadon de unu Esperanta vorto.
    * Desegnas rugxan linion sub misliterumitaj vortoj.
    */

   public void checkEspWord(Graphics g, int segoff, int start, int end) {

      int ind;
      Rectangle line_start;
      Rectangle line_end;

      try {
         line_start = user_interface.modelToView(this, start);
         line_end   = user_interface.modelToView(this, end);
      } catch (BadLocationException ble) {
         System.err.println("Error in checkEspWord. Eraro en kontrolo de literumado.");
         return;
      }

      int y = line_start.y + line_start.height - 3;
      if (!esp.sercxu(text_segment.array, segoff + start, segoff + end, vi)) {
         // Perhaps there is a hyphen 'Esperanto-kongreso'
         // Eble estas streketo 'Esperanto-kongreso'
         ind = indexOfHyphen(segoff, start, end);
         if (ind > 0) {
            checkEspWord(g, segoff, start, ind);
            checkEspWord(g, segoff, ind + 1, end);
            return;
         }
         // It's bad. Draw a line  /  Gxi estas malbona. Desegnu linion.
         g.drawLine(line_start.x, y, line_end.x, y);
      }
      else if (!kontroluFinajxon(vi)) {
         g.drawLine(line_end.x - 10, y, line_end.x, y);
      }
      else if (!kontroluMajusklecon(vi)) {
         g.drawLine(line_start.x, y, line_start.x + 10, y);
      }
      //else trans_netrans(g, line_end.x - 1, y);
   }

   private int indexOfHyphen(int segoff, int start, int end) {
      for (int i = start; i < end; i++) {
         if (text_segment.array[segoff + i] == '-') return i;
      }
      return -1;
   }


   // kontroluMajusklecon (Check Case, for Esperanto)
   // Redonas 'vera' se la majuskleco estas bona.
   boolean kontroluMajusklecon(VortInformoj vi) {
      if (vi.majusklecoElVortaro > 0 && 
          vi.majusklecoElVortaro > vi.majuskleco &&
          ((vi.finajxomasko & EspVortaro.SUBSTANTIVA_GF) > 0 ||
            vi.kategorio1 == EspVortaro.MALLONGIGO)) {
         return false;
      }
      return true;
   }

   // kontroluFinajxon (Check Ending, for Esperanto)
   // Redonas 'vera' se la finajxo estas bona.
   boolean kontroluFinajxon(VortInformoj vi) {
      if (vi.finajxomasko == 0) return true;  // versxajne el malgranda vortaro
      if ((vi.finajxomaskoElVortaro & vi.finajxomasko) != 0) {
         return true; 
      }
      return false;
   }


   // trans_netrans - Indicates whether an Esperanto verb is
   // transitive or intransitive (netransitiva). Draw a small
   // T or N.
   // trans_netrans - Indikas cxu Esperanta verbo estas 
   // transitiva aux netransitiva. Desegnu malgrandan T aux N.
   private void trans_netrans (Graphics g, int x, int y) {
      if (!show_trans || spellcheck_language != CHECK_ESPERANTO) return;
      // Results of analysis are still available.
      // La rezultoj de analizo ankoraux haveblas.
/*
      if (analizo.akiru_kategorion() == Analizo.VERBO) {
         if (analizo.akiru_transitivecon() == Analizo.TRANS) {
            g.drawLine(x,y,x+4,y);   // Desegnu T
            g.drawLine(x+2,y,x+2,y+3);
         }
         else {
            g.drawLine(x,y,x,y+3);   // Desegnu N
            g.drawLine(x+3,y,x+3,y+3);
            g.drawLine(x,y,x+3,y+3);
         }
      }
*/
   }

   /*
    * print is part of the Printable interface.
    * print estas parto de la "Printable" interfaco.
    */
   public int print (Graphics g, PageFormat pf, int index) {
      // Remove caret while printing.
      // Forigu tekstomontrilon dum presado.
      Caret caret = getCaret();
      caret.setVisible(false);
      // Disable Spellcheck temporarily.
      // Malaktivigu Kontroladon portempe.
      int save_spellcheck = spellcheck_language;
      setSpellCheckLanguage(SPELLCHECK_OFF);

      double left_x = pf.getImageableX();
      double top_y  = pf.getImageableY() - (pf.getImageableHeight() * index) - 3.0;
      // Why -3? The pages were not dividing properly. -3 was decided by experiment.
      // Kial -3? La pagxoj ne dividigxis gxuste. -3 estis fiksita per eksperimento.
      g.translate((int)left_x, (int)top_y);
      printAll(g);
      caret.setVisible(true);
      setSpellCheckLanguage(save_spellcheck);
      return(Printable.PAGE_EXISTS);
   }  // print

   /* 
    * linesInDocument - Calculate the number of lines in the document.
    * linesInDocument - Kalkulu la nombron da linioj en la dokumento.
    */
   public int linesInDocument() {
      //return getDocument().getDefaultRootElement().getElementCount();
      // Korektita 1999/07/27
      Dimension dmn = new Dimension();
      dmn = getSize(dmn);
      Double fh;
      fh = new Double(heightOfFont());
      return (dmn.height / fh.intValue());
   }


   /* 
    * heightOfFont - Calculate the height of the current font from FontMetrics.
    * heightOfFont - Kalkulu la altecon de la nuna tiparo per FontMetrics.
    */
   public double heightOfFont() {
      // Getting the font size from the font object does not work.
      // For reasons which I don't understand, a font object's point size
      // does not reflect the actual size it will have on the screen
      // or page. The correct size must be acquired from FontMetrics.
      // Tipara grandeco akirita de la tipara objekto estas malgxusta.
      // Pro kialoj kiujn mi ne komprenas, la "punkto"-grandeco de tiparo
      // ne spegulas la efektivan grandecon kiun gxi havos sur ekrano aux
      // pagxo. La gxusta grandeco devas esti akirita de FontMetrics.
      // font_size = text_pane.getFont().getSize();
      return getGraphics().getFontMetrics().getHeight();
   }

   /* 
    * linesInPage - Calculate the number of lines in a page.
    * linesInPage - Kalkulu la nombron da linioj en pagxo.
    */
   public int linesInPage(PageFormat pf) {
      return (int)(pf.getImageableHeight() / heightOfFont());
   }

   /* 
    * numberOfPages - Calculate the number of pages in the current document.
    * numberOfPages - Kalkulu la nombron da pagxoj en la nuna dokumento.
    */
   public int numberOfPages(PageFormat pf) {
      int lines_in_doc  = linesInDocument();
      int lines_in_page = linesInPage(pf);
      int number_of_pages = (lines_in_doc / lines_in_page);
      if ((lines_in_doc % lines_in_page) > 0) number_of_pages++;
      return number_of_pages;
   }  // numberOfPages


   // SimTextUI - I've extended the user interface (view) in order to
   // overwrite the update method. Check_spelling needs to draw a red 
   // underline under misspelled words.
   // Mi etendis la uz-interfacon por superskribi la "update"-metodon. 
   // Check_spelling (kontrolu literumadon) devas desegni rugxan linion 
   // sub misliterumitaj vortoj.  - Klivo
   public class SimTextUI extends BasicTextPaneUI {
      public SimTextUI() {
         super();  
      }
      public void update (Graphics g, JComponent c) {
         paint(g,c);
         if (spellcheck_language == CHECK_ENGLISH) check_spelling(g);
         if (spellcheck_language == CHECK_ESPERANTO) check_esp_spelling(g);
      }
   } // SimTextUI


   /*
    * load_esperanto_dictionary 
    * Sxargu Esperantan Vortaron
    */ 
   EspVortaro  esp;         // new spellchecker, nova literumilo
   private boolean load_esperanto_dictionary () {
      String dictionaryName = "vortaro.zip";
      if (sim_dir != null) {
         dictionaryName = sim_dir + file_separator + "vortaro.zip";
      }
      if (esp == null) esp = new EspVortaro(dictionaryName);
      return esp.havasVortarojn;
   }  // load_esperanto_dictionary


   /*
    * load_english_dictionary 
    * Sxargu Anglan Vortaron
    */ 
   EngSpell  speller;
   private boolean load_english_dictionary () {
      String dictionaryName = "dictionary.zip";
      if (sim_dir != null) {
         dictionaryName = sim_dir + file_separator + "dictionary.zip";
      }
      if (speller == null) speller = new EngSpell(dictionaryName);
      return speller.loaded;
   }  // load_english_dictionary


   public  final static int SPELLCHECK_OFF = 0;
   public  final static int CHECK_ENGLISH = 1;
   public  final static int CHECK_ESPERANTO = 2;
   private int spellcheck_language = SPELLCHECK_OFF;

   public boolean setSpellCheckLanguage(int lang) {
      if (lang == CHECK_ENGLISH) {
         if (load_english_dictionary()) {
            spellcheck_language = CHECK_ENGLISH;
            return true;
         }
      }
      else if (lang == CHECK_ESPERANTO) {
         if (load_esperanto_dictionary()) {
            spellcheck_language = CHECK_ESPERANTO;
            return true;
         }
      }
      spellcheck_language = SPELLCHECK_OFF;
      return false;
   }

   public int getSpellCheckLanguage() {
      return spellcheck_language;
   }

   public String getSpellCheckLanguage2() {
      if (spellcheck_language == CHECK_ENGLISH) return "English"; 
      if (spellcheck_language == CHECK_ESPERANTO) return "Esperanto"; 
      return "---";
   }



   ////////////////////////////////////////////////////////////
   // Reverse text. (For Persian)
   // Inversigu tekston (por la persa).
   public void reverseText() {

      char  char1, prev, prevprev;

      try {

         Document doc = getDocument();
         int len      = doc.getLength();

         StringBuffer  sb = new StringBuffer(doc.getText(0, len));
         String        the_string = sb.toString();
         String        temp;
         int           temp_len;

         int           num_start, num_end;    // komenco kaj fino de numero

         int start = 0;
         int end;

         while (start < len) {
            end = the_string.indexOf('\n',start);
            if (end == -1) end = len;
            temp = the_string.substring(start, end);
            temp_len = temp.length();
            for (int i = 0; i < temp_len;) {

               // Must reverse text, but not numbers.
               // For example.  abc4.90def becomes fed4.90cba
               // Devas inversigi tekston, sed ne numerojn.
               // Ekzemple, abc4.90def farigxas fed4.90cba

               char1 = temp.charAt(temp_len - i - 1);
               if (char1 >= '0' && char1 <= '9') {
                  // Find start of number. Trovu komencon de numero.
                  num_end = temp_len - i - 1;
                  num_start = num_end;
                  while (num_start > 0) {
                     prev = temp.charAt(num_start - 1);
                     if (num_start > 1) prevprev = temp.charAt(num_start - 2);
                     else prevprev = '$';
                     if (prev == '.' || prev == ',') {
                        if (!(prevprev >= '0' && prevprev <= '9')) break;
                     }
                     else if (!(prev >= '0' && prev <= '9')) {
                        break;
                     }
                     num_start--;
                  }
                  for (int j = num_start; j <= num_end; j++) {
                     char1 = temp.charAt(j);
                     sb.setCharAt(start + i, char1); i++;
                  }
               }
               else {   // else not a number   // ne estas numero
                  sb.setCharAt(start + i, char1); i++;
               }
            }
            start = end + 1;
         }

         doc.remove(0, len);
         doc.insertString(0,sb.toString(), null);
         //parent.requestFocus();

      } catch (BadLocationException blx) {
         System.err.println("reverseText: bad location"); 
         System.err.println("reverseText: malbona loko\n" +
                             blx.toString());
      } catch (NullPointerException npx) {
         System.err.println("SimTextPane: Null pointer.");
         System.err.println("SimTextPane: Nula montrilo. 10\n"  +
                             npx.toString());
      }

   }  // end of reverseText()


   /*
    * isALatinLetter - returns true if the character is an accented or 
    * unaccented Latin letter, or hyphen, or apostrophe between letters.
    * a to z, ' or -, or above 127.
    * isALatinLetter - (estas Latina Litero) - redonas "vera" se la signo estas 
    * supersignita aux ne-supersignita litero, aux streketo, aux apostrofo
    * inter literoj.
    */
   public final static boolean isALatinLetter(char[] charbuffer, int index) {

      char char1 = charbuffer[index];
      char before;  // antaux
      char after;   // post

      if (char1 >= 'a' && char1 <= 'z') return true;
      if (char1 <= '&') return false;   // space ! " # $ % &
      if (char1 >= 'A' && char1 <= 'Z') return true;
      if (char1 >= 0xB0 && char1 <= 0x170) return true;
      if (char1 == '-' || char1 == 0xAD) return true;  // streketo kaj 'mola' streketo

      // If there is an apostrophe in the middle of a word, it
      // counts as a letter, eg. we've, but not 'this' .
      // Se estas apostrofo ene de vorto, gxi traktigxas kiel litero,
      // ekzemple: we've , sed ne 'this' .
      if (char1 == '\'') {
         before = ' ';
         after  = ' ';
         if (index > 0) before = charbuffer[index - 1];
         if (index < charbuffer.length - 1) after = charbuffer[index + 1];
         if (
             ((before >= 'a' && before <= 'z') || (before >= 'A' && before <= 'Z')) &&
             ((after >= 'a' && before <= 'z')  || (before >= 'A' && before <= 'Z'))
            ) return true;
      }

      if (char1 == 0x8a || char1 == 0x8c || char1 == 0x9a || char1 == 0x9c) return true;

      return false;
   }



   // To avoid problems with the input method (for Japanese), Simredo always puts a 
   // carriage return after a <br> element. Don't let the caret get between the 
   // <br> and CR.
   // Por eviti problemojn kun la eniga metodo (por la Japana), Simredo cxiam metas
   // reirokodon por <br> marko. Ne permesu ke la pozicio-markilo eniru inter la
   // <br> kaj reirokodo.

   /*
    * currentCharacter - returns the character under the caret
    *                  - redonas al signon cxe la pozicio-markilo
    */
   //public String currentCharacter () {
   //   int pos = getCaretPosition();
   //   String one_char = "";
   //   try {
   //      one_char = getText(pos,1);
   //   } catch (BadLocationException blx) { }
   //   return one_char;
   //}

   /*
    * moveCaret - move the caret left or right (past \r)
    *           - movu la markilon dekstren aux maldekstren, (preter \r)
    */
   //public void moveCaret (int plusminus) {
   //   int pos = getCaretPosition() + plusminus;
   //   if (pos >= 0 && pos < getDocument().getLength()) {
   //      setCaretPosition(pos);
   //   }
   //}


}  // SimTextPane

