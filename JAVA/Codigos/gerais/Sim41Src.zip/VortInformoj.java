/**
 * VortInformoj - Traktas informojn pri analizata vorto.
 *
 * @version 1.0, 2004/02/23
 * @author Klivo
 * 
 */


/**
 *
 * Notoj pri vort-informoj
 * En la vortaro, cxiu vorto aux radiko havas ses bitokojn da informoj 
 * (aux 3 char-elementoj).
 *
 * dividpozicioj > 4 * 4 bitoj = 2 bitokoj
 * sufiksoj (akt, pas, igx, ig, ad, eteg, ec, ajx) 1 bitoko
 * gramatika kategorio1 (4) + gramatika kategorio2 (4)= 1 bitoko
 * validaj finajxoj: o, a, i, en (4), + signifo (4) = 1 bitoko
 * majuskloj (2), transitiva (1), kunmetado (1), averto (1),  = 1 bitoko
 *
 * Se la flago senfinajxo = 1, tiam la lasta dividpozicio farigxas 
 */

//package vortaro;

class VortInformoj {

   public VortInformoj() { }

   public int      lingvo;

   public int      vortaro;        // MALGRANDA, GRANDA - por testado

   public int      sercxrezulto;   // TROVITA / NETROVITA

   public int      majuskleco;
   public int      majusklecoElVortaro;

   public int      finajxomasko;      // noma, adjektiva, verba, en-adverba
   public int      finajxomaskoElVortaro;

   public int      finajxolongeco;    // longeco de gramatika finajxo

   public boolean  plurala;      // valida nur por nomoj kaj adjektivoj
   public boolean  akuzativa;    // valida por nomoj, adjektivoj, kaj adverboj (hejmeN)
   public boolean  transitiva;   // valida nur por verboj

   public int[]    dividpozicio   = new int[20];
   public int      nombroDaDividpozicioj;

   public int      kategorio1;   // gramatika kategorio
   public int      kategorio2;   // alternativa gramatika kategorio


   ////////////////////////////////////////////////////////////////////
   // Variabloj por kontroli kunmetadon
   public int      kunmetado;   // 0 = Ne, 1 = LiMigita, 2 = NeLiMigita
   public int      radikkaraktero;
   public int      signifo;

   // Por marki la komencon kaj finon de radiko ene de kunmetita vorto.
   public int komenco, fino;

   // Cxi tiu flago indikas ke la vorto ne estis en la vortaro, sed analizo 
   // de radikoj indikas ke gxi probable validas.
   public boolean perAnalizo; 




}  // fino de VortInformoj



