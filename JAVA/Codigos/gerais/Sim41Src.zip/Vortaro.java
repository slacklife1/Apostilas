/**
 * Vortaro - Gxenerala vortaro-klaso, kun sercx-metodo.
 *
 * @version 1.0, 2004/03/03
 * @author Klivo
 *
 * Pri formato de vortaro.
 *
 * Cxi tiu vortaro-klaso traktas listojn de vortoj kaj vortinformoj. 
 * Por cxiu vorto, krom la literoj mem, la vortaro devas registri cxu 
 * la vorto estas kunmetita, noma/adjektiva/verba, transitiva, ktp.
 *
 * Vortinformoj estas kodigitaj je minimuma grandeco, por konservi 
 * spacon en datumaj dosieroj. Ekzemple, necesas nur unu bito por 
 * reprezenti transitivecon (N/T).
 *
 * La literoj de la vortoj estas tenataj en char-elementoj, kaj la 
 * vortinformoj ankaux estas en unu aux pli da char-elementoj, tuj 
 * post cxiu vorto. Kiam oni vokas la sercx-metodon de cxi tiu klaso, 
 * se la sercxita vorto estas trovita, la metodo redonas la char-
 * elementojn de vortinformoj. Malkompaktigo de la vortinformoj ne 
 * estas tasko de cxi tiu klaso, sed de subklaso. La nombro da vort-
 * informaj char-elementoj por cxiu vorto dependas de la bezonoj de 
 * la subklaso. 
 *
 * Vortaraj rikordoj (vorto + informo), estas ordigitaj unue laux 
 * longeco, kaj due laux alfabeta ordo*. Alivorte, cxiuj du-literaj 
 * vortoj estas kunaj en alfabete ordigita listo. Cxiuj tri-literaj
 * vortoj estas kunaj, ktp.
 *
 * Jen formato de la datumoj en vortaro (kaj en vortara dosiero):
 *
 * vortara kapo
 * listo de 2-literaj vortoj (du literoj plus N inform-elementoj)
 * listo de 3-literaj vortoj (tri literoj plus N inform-elementoj)
 * listo de 4-literaj vortoj (kvar literoj plus N inform-elementoj)
 * listo de 5-literaj vortoj
 * listo de 6-literaj vortoj
 * ktp...
 *
 * La vortara kapo enhavas sekvantajn informojn:
 *
 * plej longa vorto (Por nombro da listoj, subtrahu 1)
 * longeco de informoj (aux nombro de char-elementoj por cxiu vorto)
 * nombro da vortoj en 2-litera listo
 * nombro da vortoj en 3-litera listo
 * nombro da vortoj en 4-litera listo
 * ktp.
 *
 * Kiam cxi tiu klaso konstruigxas, gxi kalkulas bazajn indeksojn por 
 * cxiu listo (2-litera, 3-litera, ktp) surbaze de la nombro da vortoj 
 * en cxiu listo.
 *
 * *Noto: La ordo de la vortoj en cxiu listo ne estas tute alfabeta. 
 * Supersignitaj literoj, cxar ili havas pli altajn unikodajn kodojn 
 * ol askiaj literoj, estas ordigitaj cxefine. Tamen, cxi tiu detalo 
 * havas neniun gravecon por uzantoj.
 * 
 */


//package vortaro;

class Vortaro {

   static final int MAKSIMUMA_VORTLONGECO = 30;

   public boolean  uzebla = false;  // Indikas ke la vortaro estas uzebla.

   char[]   vortarodatumoj; // Ordigitaj vortoj kaj informoj en char-oj.

   int      plejLongaVorto;
   int      longecoDeInformoj;  // nombro da char-elementoj por cxiu vorto

   // Nombro da vortoj por cxiu vortlongeco.
   int[]    nombroDaVortoj  = new int[MAKSIMUMA_VORTLONGECO + 1];

   // Bazindekso por sercxado en vortarodatumoj.
   // La fino de cxiu listo estas la posta indekso minus unu vortrikordo.
   int[]    bazindekso     = new int[MAKSIMUMA_VORTLONGECO + 1 + 1];

   public Vortaro(char[] vortarodatumoj) {

      if (vortarodatumoj == null) {
         System.err.println("Vortaro: null");
         return;
      }

      if (vortarodatumoj.length < 3) {
         System.err.println("Vortaro: tro mallonga> " + vortarodatumoj.length);
         return;
      }

      this.vortarodatumoj = vortarodatumoj;

      plejLongaVorto = (int)vortarodatumoj[0];
      if (plejLongaVorto > MAKSIMUMA_VORTLONGECO) {
         System.err.println("Vortaro: tro longaj vortoj> " + plejLongaVorto);
         return;
      }
      if (vortarodatumoj.length < plejLongaVorto + 1) {
         System.err.println("Vortaro: tro mallonga> " + 
                             vortarodatumoj.length + "  " + plejLongaVorto);
         return;
      }

      longecoDeInformoj = (int)vortarodatumoj[1];
      if (longecoDeInformoj > 5) {
         System.err.println("Vortaro: tro da informaj elementoj> " + 
                             longecoDeInformoj);
         return;
      }

      for (int i = 2; i <= plejLongaVorto; i++) {
         nombroDaVortoj[i] = vortarodatumoj[i];
      }

      bazindekso[2] = plejLongaVorto + 1;
      // La bazo de unu listo estas al fino de la antauxa.
      for (int i = 2; i <= plejLongaVorto; i++) {
         bazindekso[i+1] = bazindekso[i] + 
                            ((i + longecoDeInformoj) * nombroDaVortoj[i]);
      }

      // Lasta kontrolo.
      int fino = bazindekso[plejLongaVorto + 1];
      if (fino != vortarodatumoj.length) {
         System.err.println("Vortaro: koruptita vortaro> " + fino + " != " + 
                             vortarodatumoj.length);
         return;
      }

      uzebla = true;

   }  // fino de konstrumetodo


   /**
    * Por sercxi vorton en la vortaro kaj redoni ties informojn.
    * @param la sercxota vorto
    * @param komenco de la vorto
    * @param fino de la vorto
    * @param redonas la vortinformojn, se vorto trovita
    * @return vera se trovita, falsa se netrovita
    */

   public boolean sercxu(char[] la_vorto, int kom, int fin, char[] informoj) {

      int    longeco = fin - kom;

      int    bazo;
      int    malsupro, supro, mezo;
      int    komparrezulto;
      int    indekso, i;

      if (uzebla == false) return false;
      if (longeco > plejLongaVorto) return false;

      int v_longeco  = longeco + longecoDeInformoj; 

      bazo     = bazindekso[longeco];
      malsupro = 0;
      supro    = nombroDaVortoj[longeco] - 1;

      while (malsupro <= supro) {
         mezo = (supro + malsupro)/2;
         indekso = bazo + (mezo * v_longeco);
         for (i = 0, komparrezulto = 0; 
             (i < longeco) && (komparrezulto == 0); i++)
             komparrezulto = (la_vorto[kom + i] - vortarodatumoj[indekso + i]);
         //System.err.println("vorto " + new String(vortarodatumoj,indekso, longeco));
         if (komparrezulto < 0) {
            supro = mezo-1;
         }
         else if (komparrezulto > 0) {
            malsupro = mezo+1;
         }
         else {
            // La algoritmo trovis la radikon.
            i = 0;
            while (i < longecoDeInformoj && i < informoj.length) {
               informoj[i] = vortarodatumoj[indekso + longeco + i];
               i++;
            }
            return true;
         }

      }  // fino de "while"

      return false;  // netrovita

   }  // fino de sercxu

}  // fino de Vortaro



