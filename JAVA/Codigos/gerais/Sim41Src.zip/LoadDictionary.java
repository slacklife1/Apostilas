/**
 * LoadDictionary - This class reads dictionary information
 * from a zip-file. It's based on SxarguVortarojn.java.
 *
 * Klaso por legi vortarajn informojn el zip-formataj dosieroj.
 * Gxi bazigxas sur SxarguVortarojn.java.
 *
 * @version 1.0, 2004/08/17
 * @author Klivo
 * 
 */

import java.io.*;
import java.util.zip.*;

class LoadDictionary {

   static final int MAX_DICTIONARIES = 5;  // maximum number of dictionaries in zip-file.

   String[] dictionaryName  = new String[MAX_DICTIONARIES];
   char[][] dictionary      = new char[MAX_DICTIONARIES][];

   public LoadDictionary() {
   }

   public LoadDictionary(String zipfile) {
      load(zipfile);
   }


   /**
    * getDictionary - returns the character array for the named dictionary.
    * Redonas la char-matricon por la nomita vortaro.
    * @param name of dictionary / nomo de vortaro
    * @return char-array of dictionary data, or null
    */
   public char[] getDictionary(String nameOfDictionary) {
      for (int i = 0; i < MAX_DICTIONARIES; i++) {
         if (dictionaryName[i] != null && 
             dictionaryName[i].equals(nameOfDictionary)) {
            return dictionary[i];
         }
      }
      return null;
   }



   /**
    * load - Loads dictionaries from a zip archive.
    * Sxargas vortarojn el zip-dosiero (arkivo).
    * @param name of zip-file / nomo de la zip-dosiero
    */
   public void load(String name) {

      int       size;
      ZipEntry  zipInfo;

      byte      hi, lo;    // peza kaj malpeza

      ZipInputStream zip = openZipFile(name);
      if (zip == null) {
         return;
      }

      try {

         for (int i = 0; i < MAX_DICTIONARIES; i++) {
            int numberRead = 0;
            zipInfo = zip.getNextEntry();
            if (zipInfo != null) {
               dictionaryName[i] = zipInfo.getName();
               size = (int)(zipInfo.getSize() / 2);
               dictionary[i] = new char[size];
               for (int j = 0; j < size; j++) {
                  hi = (byte)zip.read(); lo = (byte)zip.read();
                  dictionary[i][j] = (char)(((hi << 8) & 0xFF00) + (lo & 0xFF));
                  numberRead++;
               }
               //System.out.println("Number of characters read from " +
               //                   dictionaryName[i] + ": "+ numberRead);
            }
         } // end of 'for'

         zip.close();

      }
      catch (Exception e) {
         System.err.println("LoadDictionary: Error while reading dictionary.");
         return;
      }
   }


   /*
    * openZipFile - Opens a zip file for input.
    * Malfermas zip-dosieron por legado.
    * @param name of file/ nomo de dosiero
    * @return InputStreamReader
    */

   ZipInputStream openZipFile(String name) {
      try {
         return new ZipInputStream(new FileInputStream(name));
      }
      catch (Exception e) {
         System.err.println("LoadDictionary: Cannot open " + name + " .");
         return null;
      }
   }


}  // end of LoadDictionary



