/**
 * VortKonstantoj - Komunaj konstantoj por la Esperanta Vortaro
 *
 * @version 1.0, 2004/03/31
 * @author Klivo
 * 
 */



class VortKonstantoj {

   public VortKonstantoj() {
   }

//------------- Komenco de konstantoj generitaj de Access -------------


   // Signifoj - Konstantoj uzataj por kontroli kunmetadon.
   // Necesas forigi '?' kaj 'RAD_?' 

   public static final int  ACX = 1;
   public static final int  AD = 2;
   public static final int  AJX = 3;
   public static final int  AKTPART = 4;
   public static final int  AL = 5;
   public static final int  AMFIBIO = 6;
   public static final int  AN = 7;
   public static final int  ANIMALIDO = 8;
   public static final int  ANIMALO = 9;
   public static final int  ANSTATAUX = 10;
   public static final int  ANTAUX = 11;
   public static final int  AR = 12;
   public static final int  ARBO = 13;
   public static final int  BIRDO = 14;
   public static final int  CXE = 15;
   public static final int  CXIRKAUX = 16;
   public static final int  DUM = 17;
   public static final int  DUON = 18;
   public static final int  EBL = 19;
   public static final int  EC = 20;
   public static final int  EG = 21;
   public static final int  EJ = 22;
   public static final int  EKS = 23;
   public static final int  EKSTER = 24;
   public static final int  EM = 25;
   public static final int  EN = 26;
   public static final int  END = 27;
   public static final int  ER = 28;
   public static final int  ESTR = 29;
   public static final int  ET = 30;
   public static final int  ETNO = 31;
   public static final int  FI = 32;
   public static final int  FISXO = 33;
   public static final int  FOR = 34;
   public static final int  GXIS = 35;
   public static final int  HOMNOMO = 36;
   public static final int  ID = 37;
   public static final int  IG = 38;
   public static final int  IGX = 39;
   public static final int  IL = 40;
   public static final int  ILO = 41;
   public static final int  IN = 42;
   public static final int  IND = 43;
   public static final int  ING = 44;
   public static final int  INSEKTO = 45;
   public static final int  INSULO = 46;
   public static final int  ISM = 47;
   public static final int  KONTINENTO = 48;
   public static final int  KONTRAUX = 49;
   public static final int  KROM = 50;
   public static final int  KUN = 51;
   public static final int  LAND = 52;
   public static final int  LANDO = 53;
   public static final int  LAUX = 54;
   public static final int  M = 55;
   public static final int  MAL = 56;
   public static final int  MAMULO = 57;
   public static final int  MIS = 58;
   public static final int  MOLUSKO = 59;
   public static final int  N = 60;
   public static final int  NE = 61;
   public static final int  NUMERO0 = 62;
   public static final int  NUMERO1 = 63;
   public static final int  NUMERO2 = 64;
   public static final int  NUMERO3 = 65;
   public static final int  OKUP = 66;
   public static final int  OKUPO = 67;
   public static final int  ONOPOBL = 68;
   public static final int  OV = 69;
   public static final int  PARENCO = 70;
   public static final int  PASPART = 71;
   public static final int  PERSONIDO = 72;
   public static final int  PERSONINO = 73;
   public static final int  PERSONO = 74;
   public static final int  PLANTO = 75;
   public static final int  POST = 76;
   public static final int  PRA = 77;
   public static final int  PRETER = 78;
   public static final int  PRI = 79;
   public static final int  PROVINCO = 80;
   public static final int  RE = 81;
   public static final int  REGIONO = 82;
   public static final int  REPTILIO = 83;
   public static final int  SEZONO = 84;
   public static final int  STIL = 85;
   public static final int  SUB = 86;
   public static final int  SUPER = 87;
   public static final int  SUR = 88;
   public static final int  SXTATO = 89;
   public static final int  T = 90;
   public static final int  TEMPO = 91;
   public static final int  TRANS = 92;
   public static final int  UJ = 93;
   public static final int  UL = 94;
   public static final int  URBO = 95;
   public static final int  VIR = 96;


   public static String[] signifoj = {
      "?", "ACX", "AD", "AJX", "AKTPART", "AL", "AMFIBIO", "AN", 
      "ANIMALIDO", "ANIMALO", "ANSTATAUX", "ANTAUX", "AR", "ARBO", 
      "BIRDO", "CXE", "CXIRKAUX", "DUM", "DUON", "EBL", "EC", 
      "EG", "EJ", "EKS", "EKSTER", "EM", "EN", "END", "ER", 
      "ESTR", "ET", "ETNO", "FI", "FISXO", "FOR", "GXIS", "HOMNOMO", 
      "ID", "IG", "IGX", "IL", "ILO", "IN", "IND", "ING", "INSEKTO", 
      "INSULO", "ISM", "KONTINENTO", "KONTRAUX", "KROM", "KUN", 
      "LAND", "LANDO", "LAUX", "M", "MAL", "MAMULO", "MIS", 
      "MOLUSKO", "N", "NE", "NUMERO0", "NUMERO1", "NUMERO2", 
      "NUMERO3", "OKUP", "OKUPO", "ONOPOBL", "OV", "PARENCO", 
      "PASPART", "PERSONIDO", "PERSONINO", "PERSONO", "PLANTO", 
      "POST", "PRA", "PRETER", "PRI", "PROVINCO", "RE", "REGIONO", 
      "REPTILIO", "SEZONO", "STIL", "SUB", "SUPER", "SUR", "SXTATO", 
      "T", "TEMPO", "TRANS", "UJ", "UL", "URBO", "VIR", 
   };


   // Karakteroj de radikoj kaj vortoj, por kontroli kunmetadon.
   // Ne konfuzu kun gramatikaj kategorioj.

   public static final int  RAD_ADJEKTIVO = 1;
   public static final int  RAD_ADVERBO = 2;
   public static final int  RAD_NUMERO = 3;
   public static final int  RAD_PREFIKSO = 4;
   public static final int  RAD_PREPOZICIO = 5;
   public static final int  RAD_SUBST = 6;
   public static final int  RAD_SUBSTVERBO = 7;
   public static final int  RAD_SUFIKSO = 8;
   public static final int  RAD_VERBO = 9;


   public static String[] karakteroj = {
      "RAD_?", "RAD_ADJEKTIVO", "RAD_ADVERBO", "RAD_NUMERO", 
      "RAD_PREFIKSO", "RAD_PREPOZICIO", "RAD_SUBST", "RAD_SUBSTVERBO", 
      "RAD_SUFIKSO", "RAD_VERBO", 
   };




//-------------- Fino de konstantoj generitaj de Access ---------------



   /**
    * Gramatika kategorio de vorto/radiko. Ordo devas esti alfabeta.
    * En la programo, ne konfuzu kun la radikkarakteroj. 
    * (RAD_VERBO != VERBO)
    */

   /** blua, rapidan, homaj */
   public final static int  ADJEKTIVO   = 0; 
   /** tie, ne, almenaux, rapide */
   public final static int  ADVERBO     = 1;
   /** la */
   public final static int  ARTIKOLO    = 2;
   /** ho, ve */
   public final static int  INTERJEKCIO = 3;
   /** tamen, sed, ol */
   public final static int  KONJUNKCIO  = 4;
   /** UEA, UK */
   public final static int  MALLONGIGO  = 5;
   /** nekonata */
   public final static int  NEKONATA    = 6;
   /** dek, tri, unu */
   public final static int  NUMERO      = 7; 
   /** ridanta, amata */
   public final static int  PARTICIPO   = 8;
   /** al, kun, en, por */
   public final static int  PREPOZICIO  = 9;
   /** tiu, tio, kiuj, tiajn */
   public final static int  PRONOMADJ   = 10;
   /** mi, sxin, ili */
   public final static int  PRONOMO     = 11;
   /** kvankam, ke */
   public final static int  SUBJUNKCIO  = 12;
   /** elefantoj, monon, patrino */
   public final static int  SUBSTANTIVO = 13;
   /** dancas, vivu, lernos */
   public final static int  VERBO       = 14;

   public final static String[] kategorioj = {
         "ADJEKTIVO","ADVERBO","ARTIKOLO","INTERJEKCIO","KONJUNKCIO",
         "MALLONGIGO","N","NUMERO","PARTICIPO","PREPOZICIO",
         "PRONOMADJ","PRONOMO","SUBJUNKCIO","SUBSTANTIVO","VERBO"
   };

   /**
    * akiruKonstanton - por konverti signocxenon al entjera konstanto.
    * @param envorto - por konverti
    * @param listo de signocxenoj
    * @return redonas entjeran valoron de envorto
    */
   public static int akiruKonstanton(String envorto, String[] listo) {

      int  malsupro,supro,mezo;
      int  komparrezulto;

      malsupro = 0;
      supro = listo.length - 1;

      while (malsupro <= supro) {
         mezo = (supro + malsupro)/2;
         komparrezulto = envorto.compareTo(listo[mezo]);
         if (komparrezulto < 0)
            supro = mezo-1;
         else if (komparrezulto > 0)
            malsupro = mezo + 1;
         else {
            return (mezo);  // Trovita
         }
      }
      return (0);  // Netrovita

   }  // fino de akiruKonstanton



   /**
    * akiruCxenon - por konverti entjeran konstanton al signocxeno.
    * @param i - la konstanto
    * @param listo de signocxenoj
    * @return redonas signocxenon kiu respondas al la konstanto
    */
   public static String akiruCxenon(int i, String[] listo) {
      if (i < listo.length) return listo[i];
      else return "?";
   }


   // Maskoj por gramatikaj finajxoj
   static final byte SUBSTANTIVA_GF = 8;    // substantivaj: -o, -on, -oj, -ojn
   static final byte ADJEKTIVA_GF   = 4;    // adjektivaj: -a, -an, -aj, -ajn, -e
   static final byte VERBA_GF       = 2;    // verbaj: -os, -as, -is, -i, -u
   static final byte ENADVERBA_GF   = 1;    // en-adverbo: -en
   static final byte SEN_GF = 1;   // sen gramatika finajxo
   // Noto: Mi uzos SEN_GF nur en la suplementa vortaro. La suplementa
   // vortaro ne uzos ENADVERBA_GF.

   // Lingvoj
   public static final int   ESPERANTO = 1;
   public static final int   ANGLA = 2;

   // Sercxrezultoj
   public static final int   NETROVITA = 0;
   public static final int   TROVITA = 1;

   // La vortaro en kiu la vorto trovigxis (por testado).
   public static final int   MALGRANDA = 0;
   public static final int   GRANDA    = 1;
   public static final int   SUPLEMENTA = 2;

}


