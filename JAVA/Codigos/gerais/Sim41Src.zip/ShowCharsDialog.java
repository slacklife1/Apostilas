/*
 * ShowCharsDialog
 * This class displays all characters in the current font.
 * Cxi tiu dialogo montras cxiujn signojn en la aktiva tiparo.
 *
 * Cleve Lendon (Klivo)   2000/12/14
 * indriko@yahoo.com
 * http://purl.oclc.org/net/klivo/
 *
 */

/*
 * Changes for version 4.
 * 
 * Adjust size of window properly.
 * Add text field to type in page number.
 * Gxustigu grandecon de la fenestro.
 * Aldonu tekstokampon por entajpi pagxnumeron.
 *
 */


import java.awt.*;
import java.awt.FontMetrics;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;


public class ShowCharsDialog extends JDialog implements ActionListener {

   JFrame       parent;

   Rectangle p_rect;    // Bounds of parent

   private final static int d_width  = 350;   // dialog width   -  dialoga largxeco
   private final static int d_height = 400;   // dialog height  -  dialoga alteco

   JLabel   page_label;
   JLabel   current_font_label;    // Por montri aktivan tiparon.

   JPanel   arrow_button_panel;
   JPanel   page_panel;

   static int      current_page = 0;      // 01 al FF
   String          current_page_str;

   Font              last_font;
   FontMetrics   fm;

   JButton  up_button;          // supren
   JButton  fast_up_button;     // rapide supren
   JButton  down_button;        // malsupren
   JButton  fast_down_button;   // rapide malsupren
   JButton  exit_button;
   JButton  go_button;

   JTextField  page_field;

   SimTextArea     character_window; // Fenestro por montri signojn.
   SimTextArea     row_number_window; // Shows hex codes for each row.
                              // Montras deksesumajn kodojn por cxiu vico.

   GridBagConstraints gbc;
   Container cp;

   public ShowCharsDialog (JFrame parent, String[] labels) {

      super(parent, labels[0]);
      this.parent = parent;

      p_rect = parent.getBounds();

      setSize(d_width, d_height);

      page_label = new JLabel(labels[3]);
      page_field = new JTextField("0000",4);
      go_button   = new JButton(labels[4]);
      go_button.setActionCommand("go");
      go_button.addActionListener(this);

      up_button   = new JButton(">");
      up_button.setActionCommand("up");
      up_button.addActionListener(this);

      fast_up_button   = new JButton(">>");
      fast_up_button.setActionCommand("fast up");
      fast_up_button.addActionListener(this);

      down_button   = new JButton("<");
      down_button.setActionCommand("down");
      down_button.addActionListener(this);

      fast_down_button   = new JButton("<<");
      fast_down_button.setActionCommand("fast down");
      fast_down_button.addActionListener(this);

      character_window  = new SimTextArea(16*2,16); // Fenestro por montri signojn.
      character_window.setEditable(false);

      row_number_window        = new SimTextArea(4,16);
      row_number_window.setEditable(false);

      current_font_label = new JLabel("");

      exit_button = new JButton(labels[1]);
      exit_button.setActionCommand("exit");
      exit_button.addActionListener(this);

      page_field.setActionCommand("go");
      page_field.addActionListener(this);

      cp = getContentPane();
      cp.setLayout(new GridBagLayout());
      arrow_button_panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
      page_panel = new JPanel(new FlowLayout(FlowLayout.LEFT));

      // Arrange components. Arangxu butonojn.
      gbc = new GridBagConstraints();
      gbc.insets = new Insets(5,5,5,5);

      page_panel.add(page_label);
      page_panel.add(page_field);
      page_panel.add(go_button);
      page_panel.add(current_font_label);

      gbc.fill = GridBagConstraints.BOTH;
      gbc.gridx = 0;  gbc.gridy = 0; gbc.gridwidth = 5;
      cp.add(page_panel,gbc);

      arrow_button_panel.add(fast_down_button);
      arrow_button_panel.add(down_button);
      arrow_button_panel.add(up_button);
      arrow_button_panel.add(fast_up_button);
      arrow_button_panel.add(exit_button);

      gbc.gridy = 1; gbc.gridwidth = 5;
      gbc.gridx = 0; 
      cp.add(arrow_button_panel,gbc);

      gbc.gridy = 2; gbc.gridx = 0; gbc.gridwidth = 1; 
      cp.add(row_number_window,gbc);

      gbc.gridy = 2; gbc.gridx = 1; gbc.gridwidth = 4; 
      cp.add(character_window,gbc);

      sizeIt();

   }  // end of constructor


   public void actionPerformed(ActionEvent e) {

      String the_command = e.getActionCommand();

      if (the_command.equals("exit")) {
         setVisible(false);
         return;
      }
      else
      if (the_command.equals("up")) {
         next_page();
      }
      else
      if (the_command.equals("fast up")) {
         next_16();
      } 
      else
      if (the_command.equals("down")) {
         prev_page();
      }
      else
      if (the_command.equals("fast down")) {
         prev_16();
      }
      else 
      if (the_command.equals("go")) {
         new_page();
      }
      current_page_str = "000" + Integer.toHexString((current_page*256)).toUpperCase();
      page_field.setText(current_page_str.substring(current_page_str.length() - 4));

   }  // actionPerformed


   /*
    * showIt - Display this dialog.
    * showIt - Montru cxi tiun dialogon.
    */

   public void showIt(String fontName) {
      setVisible(true);  // Set visible before sizing, becaaaaaause, the text areas can't
                         // get a graphics object otherwise.
                         // Faru videblan antaux ol fiksi la grandecon, cxar la tekst-areoj ne
                         // povas akiri grafikan objekton antaux ol ili estas videblaj.
      newFont2(fontName);
      sizeIt();
      validate();
   }  // showIt



   /*
    * newFont - Set a new font and refill the character window.
    * newFont - Aktivigu novan tiparon kaj replenigu la signofenestron.
    */

   public void newFont(String fontName) {
      newFont2(fontName);
      resizeIt();
      validate();
   }  // newFont

   private void newFont2(String fontName) {
      Font font1 = Font.decode(fontName);
      last_font = font1.deriveFont(Font.PLAIN,18.0f);
      row_number_window.setFont(last_font);
      remakeCharacterWindow();
      current_font_label.setText("        " + fontName);
   }


   /*
    * sizeIt - Adjust size.
    * sizeIt - Gxustigu grandecon.
    */
   void sizeIt() {
      //p_rect = parent.getBounds();
      Rectangle d_rect = new Rectangle(460, 170, newWidth(), newHeight());
      setBounds(d_rect);
      validate();
   }


   /*
    * resizeIt - Readjust size. Don't change location.
    * resizeIt - Regxustigu grandecon. Ne sxangxu lokon.
    */
   public void resizeIt() {
      Rectangle old_rect     = getBounds();
      Rectangle d_rect = new Rectangle(old_rect.x, old_rect.y, newWidth(), newHeight());
      setBounds(d_rect);
      validate();
   }


   private int newWidth() {
      int new_width  = longest_char_row_width + row_number_width + 55;
      if (new_width < d_width) new_width = d_width;
      return new_width;
   }

   private int newHeight() {
      int new_height = (font_height * 16) + (up_button.getHeight() * 4) + 30; 
      if (new_height < d_height) new_height = d_height;
      return new_height;
   }


   private void next_page() {
      if (current_page < 0xFF) current_page++;
      remakeCharacterWindow();
      resizeIt();
      validate();
   }

   private void next_16() {
      if (current_page + 16 < 0xFF) current_page = current_page + 16;
      else current_page = 0xFF;
      remakeCharacterWindow();
      resizeIt();
      validate();
   }

   private void prev_page() {
      if (current_page > 0) current_page--;
      remakeCharacterWindow();
      resizeIt();
      validate();
   }

   private void prev_16() {
      if (current_page - 16 > 0) current_page = current_page - 16;
      else current_page = 0;
      remakeCharacterWindow();
      resizeIt();
      validate();
   }


   // Get the hex page number, decode it, and jump to new page.
   // Akiru la sesdekuman pagxnumeron, konvertu al entjero, kaj saltu al nova pagxo.
   private void new_page() {
      int the_code;
      try {
         the_code = Integer.decode("0x" + page_field.getText()).intValue();
         current_page = the_code / 256;
         remakeCharacterWindow();
         resizeIt();
         validate();
      }
      catch (NumberFormatException nfx) { return; }
   }

   // Rekreu la SignoFenestron.
   private void remakeCharacterWindow() {
      cp.remove(character_window);
      character_window  = new SimTextArea(16*2,16);
      character_window.setFont(last_font);
      character_window.setEditable(false);
      gbc.gridy = 2; gbc.gridx = 1; gbc.gridwidth = 4; 
      cp.add(character_window,gbc);
      fm = character_window.getGraphics().getFontMetrics();
      fillCharacterWindow(current_page, fm);
      doLayout();
   }

   /*
    * fillCharacterWindow - Writes 256 characters to the character window. 
    * This method also calculates with height and widths strings to be displayed.
    * fillCharacterWindow - Skribas 256 signojn al la signofenestro.
    * Cxi tiu metodo ankaux kalkulas la altecon kaj largxecojn de montrotaj cxenoj.
    */

   private char[]  character_row = new char[16*2];
   private int longest_char_row_width;
   private int row_number_width;
   private int font_height;

   private void fillCharacterWindow (int page, FontMetrics fm) {

      int j;
      int za_page = page * 256;

      character_window.setText("");
      row_number_window.setText("");

      font_height = fm.getHeight();
      longest_char_row_width = 0;

      String  character_row_string;
      String  row_number_string;

      for (int row=0; row < 16; row++) {

         row_number_string = "0000" + Integer.toHexString((page*256) + (row*16)).toUpperCase();
         row_number_string = row_number_string.substring(row_number_string.length() - 4);
         row_number_window.append(row_number_string);
         if (row != 15) row_number_window.append("\n");
         else row_number_width = fm.stringWidth(row_number_string);
         j = 0;
         for (int col= 0; col < 16; col++) {
            // I don't know why I can't display the first three rows of page 
            // 32, but it causes nasty errors.
            // Mi ne scias kial mi ni povas montri la unuajn tri vicojn de
            // pagxo 32, sed tio kauxzas erarojn.
            if ((row < 2 && page == 0) || (row < 3 && page == 32)) {
               character_row[j] = ' '; j++;
               character_row[j] = ' '; j++;
            }
            else {
               character_row[j] = (char)(za_page + (row * 16) + col); j++;
               character_row[j] = ' '; j++;
            }
         }
         character_row_string = new String(character_row);

         character_window.append(character_row_string);
         if (row != 15) character_window.append("\n");

         int char_row_length = fm.stringWidth(character_row_string);
         if (char_row_length > longest_char_row_width) longest_char_row_width = char_row_length;

      }

   }  // fillCharacterWindow


}  // ShowCharsDialog



