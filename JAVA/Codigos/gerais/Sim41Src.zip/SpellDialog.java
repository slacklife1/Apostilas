/*
 * SpellDialog - To select English or Esperanto spell checking.
 * SpellDialog - Por selekti anglan au Esperantan literumadon.
 *
 * Cleve Lendon (Klivo)
 * indriko@yahoo.com
 * http://purl.oclc.org/net/klivo/
 *
 */

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class SpellDialog extends JDialog implements ActionListener {

   JFrame           parent;
   SimTextPane      text_pane;
   TimedMessage     timed_message;

   private final static int d_width  = 190;   // dialog width   -  dialoga largxeco
   private final static int d_height = 200;   // dialog height  -  dialoga alteco

   JButton   exit_button;

   JRadioButton  spell_off;
   JRadioButton  spell_english;
   JRadioButton  spell_esperanto;
   ButtonGroup   radio_group;

   JLabel      top_label;

   public SpellDialog (JFrame parent, TimedMessage timed_message, String[] labels) {

      super(parent, "  " + labels[0]);
      //super(parent, "  " );
      this.parent = parent;
      this.timed_message = timed_message;
      setSize(d_width, d_height);
      Container cp = getContentPane();
      cp.setLayout(new GridBagLayout());

      exit_button = new JButton(labels[1]);
      exit_button.setActionCommand("exit");
      exit_button.addActionListener(this);

      spell_off = new JRadioButton(labels[2]);
      spell_off.setActionCommand("spell_off");
      spell_off.addActionListener(this);

      spell_english = new JRadioButton(labels[3]);
      spell_english.setActionCommand("spell_english");
      spell_english.addActionListener(this);

      spell_esperanto = new JRadioButton(labels[4]);
      spell_esperanto.setActionCommand("spell_esperanto");
      spell_esperanto.addActionListener(this);

      radio_group = new ButtonGroup();
      radio_group.add(spell_off);
      radio_group.add(spell_english);
      radio_group.add(spell_esperanto);

      // Arrange components. Arangxu butonojn.
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.anchor = GridBagConstraints.WEST;
      gbc.insets = new Insets(5,10,5,10);
      gbc.gridx = 0;  gbc.gridy = 0;
      cp.add(spell_off,gbc);
      gbc.gridy = 1;
      cp.add(spell_english,gbc);
      gbc.gridy = 2;
      cp.add(spell_esperanto,gbc);
      gbc.gridy = 3;
      gbc.anchor = GridBagConstraints.CENTER;
      cp.add(exit_button,gbc);

   }  // end of constructor


   public void actionPerformed(ActionEvent e) {
      String command = e.getActionCommand();

      boolean  sukceso = true;

      if (command.equals("exit")) {
         setVisible(false);
         return;
      }

      if (text_pane == null) return;

      if (command.equals("spell_off")) {
         text_pane.setSpellCheckLanguage(SimTextPane.SPELLCHECK_OFF);
      }
      else if (command.equals("spell_english")) {
         sukceso = text_pane.setSpellCheckLanguage(SimTextPane.CHECK_ENGLISH);
         if (!sukceso) {
            timed_message.showIt(TimedMessage.DICT_NOT_FOUND);
         }
      }
      else if (command.equals("spell_esperanto")) {
         sukceso = text_pane.setSpellCheckLanguage(SimTextPane.CHECK_ESPERANTO);
         if (!sukceso) {
            timed_message.showIt(TimedMessage.DICT_NOT_FOUND);
         }
      }
   }  // actionPerformed


   /*
    * showIt - Display this dialog.
    * showIt - Montru cxi tiun dialogon.
    */
   public void showIt(SimTextPane text_pane) {

      this.text_pane = text_pane;

      int language = text_pane.getSpellCheckLanguage();
      if (language == SimTextPane.SPELLCHECK_OFF)       spell_off.setSelected(true);
      else if (language == SimTextPane.CHECK_ENGLISH)   spell_english.setSelected(true);
      else if (language == SimTextPane.CHECK_ESPERANTO) spell_esperanto.setSelected(true);

      // Position the dialog in the center of the main frame.
      // Metu la dialogon en la mezon de la cxefa kadro.

      Rectangle p_rect = parent.getBounds();
      Rectangle d_rect = 
           new Rectangle(p_rect.x + Math.abs(p_rect.width - d_width)/2,
                         p_rect.y + Math.abs(p_rect.height - d_height)/2 + 20,
                         d_width, d_height);
      setBounds(d_rect);

      setVisible(true);
      validate();

   }  // showIt

}  // SpellDialog



