/*
 * SearchDialog
 * This class implements a search dialogue. It must listen for "new font" 
 * events from the font_list.
 * Cxi tiu klaso kreas sercx-dialogon. Gxi devas auxskulti "new font" (nova tiparo) 
 * eventojn de la tipara listo.
 *
 * Cleve Lendon (Klivo)
 * indriko@yahoo.com
 * http://purl.oclc.org/net/klivo/
 *
 * Versio 3.1  1999/06/24
 * - showIt - Don't position in center. Move to top right
 *            Ne montru en mezo. Montre supre maldekstre.
 * - Don't display up, down and close buttons. Up and down are
 *   now on the tool bar. Make search dialogue smaller.
 *   Ne montru "supren", "malsupren" kaj "fermu" butonojn. "Supren"
 *   kaj "malsupren" estas sur la il-trabo. Malpligrandigu la 
 *   sercxodialogon.
 */

/*
 * Changes for 3.2  Sxangxoj por 3.2    1999/08
 *
 * Calculate size of dialogue.
 * Kalkulu grandecon de dialogujo.
 *
 */

/*
 * Changes for 3.4  Sxangxoj por 3.4    2002/10
 *
 * Search_up and search_down adapted from find_next in ChangeDialog.
 *
 * Search_up kaj search_down adaptitaj de find_next in ChangeDialog.
 *
 */


/*
 * Changes for 4.0  Sxangxoj por 4.0    2004/06
 *
 * Add function to change text direction, for Arabic etc.
 *
 * Enmetu funkcion por sxangxi la tekstdirekton, por la araba, ktp.
 *
 */


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;


public class SearchDialog extends JDialog implements ActionListener {

   JFrame       parent;
   Simredo4     editor;

   private final static int d_width  = 360;   // dialog width   -  dialoga largxeco
   private final static int d_height = 105;   // dialog height  -  dialoga alteco

   JButton  up_button;
   JButton  down_button;
   JButton  exit_button;

   JCheckBox   distinguish_box;   // Distinguish between upper and lower case.
                                  // Distingu inter majuskloj kaj minuskloj.

   SimTextField   search_text;    // sercxota teksto

   SimTextPane  text_pane;
   Segment      the_text = new Segment();
   Document     doc;

   public SearchDialog (JFrame parent, Simredo4 editor, String[] labels) {

      //super(parent, "  " + labels[0]);  // Ne povas montri Unikodon en kadro.
      super(parent, "  ");  
      this.parent = parent;
      this.editor = editor;
      this.text_pane = editor.text_pane;

      setSize(d_width, d_height);

      up_button   = new JButton(labels[2]);
      up_button.setActionCommand("up");
      up_button.addActionListener(this);

      down_button = new JButton(labels[3]);
      down_button.setActionCommand("down");
      down_button.addActionListener(this);

      exit_button = new JButton(labels[4]);
      exit_button.setActionCommand("exit");
      exit_button.addActionListener(this);

      distinguish_box = new JCheckBox(labels[1]);
      distinguish_box.setActionCommand("distinguish");
      distinguish_box.addActionListener(this);

      search_text     = new SimTextField("",30);

      Container cp = getContentPane();
      cp.setLayout(new GridBagLayout());

      // Arrange components. Arangxu butonojn.
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.anchor = GridBagConstraints.NORTH;
      gbc.insets = new Insets(5,5,5,5);

      gbc.gridwidth = 3;
      gbc.gridx = 0; gbc.gridy = 0;
      gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.fill = GridBagConstraints.BOTH;
      cp.add(search_text,gbc);

      gbc.gridx = 0;  gbc.gridy = 1;
      gbc.gridwidth = 3;
      gbc.anchor = GridBagConstraints.NORTH;
      cp.add(distinguish_box,gbc);


      //////////////////////////////////////////////////
      // Set key bindings.  Pretigu klav-ligojn.
      // ctrl-n >> Search down / Sercxu malsupren
      // ctrl-b >> Search up   / Sercxu supren

      Action search_down   = new SearchDown("search-down");
      Action search_up     = new SearchUp("search-up");

      JTextComponent.KeyBinding[] bindings = {

         new JTextComponent.KeyBinding(KeyStroke.getKeyStroke(
                        KeyEvent.VK_N, 
                        InputEvent.CTRL_MASK),
                        "search-down"),
         new JTextComponent.KeyBinding(KeyStroke.getKeyStroke(
                        KeyEvent.VK_B, 
                        InputEvent.CTRL_MASK),
                        "search-up"),
      };
      Keymap parentmap = search_text.getKeymap();
      Keymap searchkeymap = JTextComponent.addKeymap("searchkeymap", parentmap);
      Action[] short_action_list = {  search_down, search_up };
      JTextComponent.loadKeymap(searchkeymap, bindings, short_action_list);
      search_text.setKeymap(searchkeymap);

   }  // end of constructor


   public void actionPerformed(ActionEvent e) {

      String the_command = e.getActionCommand();

      if (the_command.equals("exit")) {
         setVisible(false);
         return;
      }
      else
      if (the_command.equals("up")) {
         search_up();
      } 

      else
      if (the_command.equals("down")) {
         search_down();
      }  

      else
      if (the_command.equals("new font")) {
          newFont();
      }

   }  // actionPerformed


   /*
    * showIt - Display this dialog.
    * showIt - Montru cxi tiun dialogon.
    */
   public void showIt(SimTextPane text_pane) {

      setVisible(false);

      // Position the dialog in at bottom right.
      // Metu la dialogon cxe malsupra dektro.

      int new_width = search_text.getWidth() + 30;
      int new_height = search_text.getHeight() * 2 + 40;
      if (new_width < d_width) new_width = d_width;
      if (new_height < d_height) new_height = d_height;

      Rectangle p_rect = parent.getBounds();
      Rectangle d_rect = new Rectangle(p_rect.x + 450, p_rect.y,new_width,new_height);
      setBounds(d_rect);

      this.text_pane = text_pane;
      setVisible(true);
      search_text.requestFocus();
      validate();

   }  // showIt

   /*
    * get_text_to_find - Gets the text to find from the text field and 
    * converts to lower case if necesary.
    * get_text_to_fine - Akiras sercxotan tekston de la tekst-kampo kaj
    * konvertas gxin al minuskloj, se necese.
    */
   private String get_text_to_find() {

      String  from_field = search_text.getText();

      if (from_field == null) return "";

      // Convert \n and \t to new line and tab.
      // Konvertu \n kaj \t al novlinio kaj horizontala salto.
      String converted_string = SimCon.convertBackslash(from_field);

      String  temp1,temp2;
      if (distinguish_box.isSelected()) {
         return converted_string;
      }
      else {
         // Must convert to lower case. Devas minuskligi.
         return SimCon.toLower(converted_string);
      }
   }  // get_text_to_find




   /*
    * search_down  
    * sercxu malsupren
    */
    public boolean search_down () {

      StringBuffer sb;

      String to_find       = get_text_to_find();   // sercxota teksto
      int find_length = to_find.length();          // nombro por kompari

      // Distinguish between capitals and miniscules?
      // Distingu inter majuskloj kaj minuskloj?
      boolean distinguish  = distinguish_box.isSelected();
 
      // get the text
      // akiru la tekston
      try {
         doc = text_pane.getDocument();
         if (find_length > doc.getLength()) return false;
         sb = new StringBuffer(doc.getText(0,doc.getLength()));
      } catch (BadLocationException blx) {
         System.err.println("Search Dialog: bad location"); 
         System.err.println("Sercxdialogo: malbona loko\n" + blx.toString());
         return false;
      }

      int start_position = text_pane.getCaretPosition();   // komenca pozicio
      int end = doc.getLength() - find_length + 1;

      if (distinguish) {  // if case matters / se majuskleco gravas

         int j, k;
         for (j = start_position; j < end; j++) {
            for (k = 0; k < find_length; k++) {
               if (to_find.charAt(k) != sb.charAt(j + k)) break; 
            }
            if (k == find_length) {   // if found / se trovita
               try {
                  text_pane.setCaretPosition(j);
                  text_pane.moveCaretPosition(j + find_length);
               } catch (NullPointerException npx) {
                  // I don't know why this happens, but I'll report it.
                  // Mi ne scias kial cxi tio okazas, sed mi raportos gxin.
                  System.err.println("Null pointer.");
                  System.err.println("Nula montrilo. 2\n" + npx.toString());
                  return false;
               }
               return true;
            }
         }  // for
         return false;
      }
      else {   // if case doesn't matter / se majuskleco ne gravas

         int j, k;
         for (j = start_position; j < end; j++) {
            for (k = 0; k < find_length; k++) {
               if (to_find.charAt(k) != 
                   SimCon.toLower(sb.charAt(j + k))) break; 
            }
            if (k == find_length) {   // if found / se trovita
               try {
                  text_pane.setCaretPosition(j);
                  text_pane.moveCaretPosition(j + find_length);
               } catch (NullPointerException npx) {
                  // I don't know why this happens, but I'll report it.
                  // Mi ne scias kial cxi tio okazas, sed mi raportos gxin.
                  System.err.println("Null pointer.");
                  System.err.println("Nula montrilo. 2\n" + npx.toString());
                  return false;
               }
               return true;
            }
         }  // for
         return false;

      }  // else

    }  // end of search_down


   /*
    * search_up  
    * sercxu supren
    */
    public boolean search_up () {

      StringBuffer sb;

      String to_find       = get_text_to_find();   // sercxota teksto
      int find_length      = to_find.length();     // nombro por kompari

      // Distinguish between capitals and miniscules?
      // Distingu inter majuskloj kaj minuskloj?
      boolean distinguish  = distinguish_box.isSelected();
 
      // get the text
      // akiru la tekston
      try {
         doc = text_pane.getDocument();
         if (find_length > doc.getLength()) return false;
         sb = new StringBuffer(doc.getText(0,doc.getLength()));
      } catch (BadLocationException blx) {
         System.err.println("Search Dialog: bad location"); 
         System.err.println("Sercxdialogo: malbona loko\n" + blx.toString());
         return false;
      }

      int start_position = text_pane.getCaretPosition() 
                           - find_length - 1; // komenca pozicio

      if (distinguish) {  // if case matters / se majuskleco gravas

         int j, k;
         for (j = start_position; j >= 0; j--) {
            for (k = 0; k < find_length; k++) {
               if (to_find.charAt(k) != sb.charAt(j + k)) break; 
            }
            if (k == find_length) {   // if found / se trovita
               try {
                  text_pane.setCaretPosition(j);
                  text_pane.moveCaretPosition(j + find_length);
               } catch (NullPointerException npx) {
                  // I don't know why this happens, but I'll report it.
                  // Mi ne scias kial cxi tio okazas, sed mi raportos gxin.
                  System.err.println("Null pointer.\n");
                  System.err.println("Nula montrilo. 2\n" + npx.toString());
                  return false;
               }
               return true;
            }
         }  // for
         return false;
      }
      else {   // if case doesn't matter / se majuskleco ne gravas

         int j, k;
         for (j = start_position; j >= 0; j--) {
            for (k = 0; k < find_length; k++) {
               if (to_find.charAt(k) != 
                   SimCon.toLower(sb.charAt(j + k))) break; 
            }
            if (k == find_length) {   // if found / se trovita
               try {
                  text_pane.setCaretPosition(j);
                  text_pane.moveCaretPosition(j + find_length);
               } catch (NullPointerException npx) {
                  // I don't know why this happens, but I'll report it.
                  // Mi ne scias kial cxi tio okazas, sed mi raportos gxin.
                  System.err.println("Null pointer.\n");
                  System.err.println("Nula montrilo. 2\n" + npx.toString());
                  return false;
               }
               return true;
            }
         }  // for
         return false;

      }  // else
    }

   public void newFont() {
         // Change the font.  Sxangxu la tiparon.
         String font_name = editor.getSelectedFontName();
         Font font1 = Font.decode(font_name);
         Font font2 = font1.deriveFont(Font.PLAIN,16.0f);
         search_text.setFont(font2);
         search_text.repaint();
         validate();
   }


   public void changeDirection(boolean left_to_right) {
         if (left_to_right) {
            search_text.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
         }
         else {
            search_text.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
         }
         validate();
   }


   /**
    * SearchUp - Action class to search upward.
    * SearchUp - Agoklaso por sercxi supren.
    */
   public class SearchUp extends AbstractAction {

      SearchUp(String default_label) {
         super(default_label);
      }

      public void actionPerformed(ActionEvent e) {
         search_up();
         editor.text_pane.requestFocus();
      }  // actionPerformed

   }  // SearchUp



   /**
    * SearchDown - Action class to search downward.
    * SearchDown - Agoklaso por sercxi malsupren.
    */
   public class SearchDown extends AbstractAction {

      SearchDown(String default_label) {
         super(default_label);
      }

      public void actionPerformed(ActionEvent e) {
         search_down();
         editor.text_pane.requestFocus();
      }  // actionPerformed

   }  // SearchDown


}  // SearchDialog



