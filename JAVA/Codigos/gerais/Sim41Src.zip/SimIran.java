/*
 * SimIran - Support for Persian language.
 * - Contains routines to convert between Unicode and Iran System.
 * SimIran - Subtenas Persan lingvon.
 * - Enhavas rutinojn por konverti inter Unikodo kaj Iran-Sistemo.
 *
 * Cleve Lendon (Klivo)
 * indriko@yahoo.com
 * http://purl.oclc.org/net/klivo/
 * 2000/12/01
 *
 * 2002/10
 * It seems that 649 is not a farsi yeh, even though it looks the same.
 * Use 6CC as yeh.
 * Sxajnas ke 649 ne estas persa 'je', kvankam gxi aspektas same.
 * Uzu 6CC kiel 'je'-on.
 */

import java.awt.*;
import java.util.*;

public class SimIran {


   /*
    * Convert Unicode code to Iran System
    * Konvertu de Unikodo al IranSistemo
    */
   public final static int convertUniIran(char before, char uni, char after) {

      boolean isolated = false;      /* izolita litero */
      boolean finall = false;        /* litero cxe fino de vorto */
      boolean medial = false;        /* litero en mezo de vorto */
      boolean initial = false;       /* litero cxe komenco de vorto */
      boolean before_is_letter = false;  /* antauxa signo estas (persa) litero */
      boolean after_is_letter = false;    /* posta signo estas (persa) litero */

      if (uni < 0x0600) return uni;
      /* Arab numbers / Arabaj ciferoj */
      if (uni >= 0x6F0 && uni <= 0x6F9) return (uni - 0x6f0 + 0x80);

      /* Assume that a Persian letter is between the codes 0x0620 and 0x06D0 */
      /* Supozu ke Persa litero havas kodon inter 0x0620 kaj 0x06D0. */
      if (before >= 0x0620 && before <= 0x06D0) before_is_letter = true;
      if (after >= 0x0620 && after <= 0x06D0) after_is_letter = true;

      if (before_is_letter && after_is_letter) medial = true;
      else if (before_is_letter && !after_is_letter) finall = true;
      else if (!before_is_letter && after_is_letter) initial = true;
      else isolated = true;

      /* I can't see any systematic relationship between Unicode and 
         Iran System, so I'll just test the letters individually. */
      /* Mi ne rimarkas sisteman rilaton inter Unikodo kaj Iransistemo,
         tial mi simple testos literojn individue. */

      /* arabic comma */
      if (uni == 0x060C) return 0x8A;
      /* tatweel */
      if (uni == 0x0640) return 0x8B;
      /* arabic question mark / demando signo */
      if (uni == 0x061F) return 0x8C;

      /* alef with madda */
      if (uni == 0x0622) return 0x8D;
      /* yeh with hamza */
      if (uni == 0x0626) return 0x8E;  /* ??? */
      /* arabic letter with hamza */
      if (uni == 0x0621) return 0x8f;

      /* alef */
      if (uni == 0x0627 && (isolated || initial)) return 0x90;
      if (uni == 0x0627 && (medial || finall)) return 0x91;

      /* alef with hamza above */
      if (uni == 0x0623 && (isolated || initial)) return 0x90;
      if (uni == 0x0623 && (medial || finall)) return 0x91;

      /* alef with hamza below */
      if (uni == 0x0625 && (isolated || initial)) return 0x90;
      if (uni == 0x0625 && (medial || finall)) return 0x91;

      /* beh */
      if (uni == 0x0628 && (finall || isolated)) return 0x92;
      if (uni == 0x0628 && (initial || medial)) return 0x93;
      /* peh */
      if (uni == 0x067E && (finall || isolated)) return 0x94;
      if (uni == 0x067E && (initial || medial)) return 0x95;
      /* teh */
      if (uni == 0x062A && (finall || isolated)) return 0x96;
      if (uni == 0x062A && (initial || medial)) return 0x97;
      /* theh */
      if (uni == 0x062B && (finall || isolated)) return 0x98;
      if (uni == 0x062B && (initial || medial)) return 0x99;
      /* jeem */
      if (uni == 0x062C && (finall || isolated)) return 0x9A;
      if (uni == 0x062C && (initial || medial)) return 0x9B;
      /* cheh */
      if (uni == 0x0686 && (finall || isolated)) return 0x9C;
      if (uni == 0x0686 && (initial || medial)) return 0x9D;
      /* hah */
      if (uni == 0x062D && (finall || isolated)) return 0x9E;
      if (uni == 0x062D && (initial || medial)) return 0x9F;
      /* khah */
      if (uni == 0x062E && (finall || isolated)) return 0xA0;
      if (uni == 0x062E && (initial || medial)) return 0xA1;

      /* dal */
      if (uni == 0x062F) return 0xA2;
      /* thal */
      if (uni == 0x0630) return 0xA3;
      /* reh */
      if (uni == 0x0631) return 0xA4;
      /* zain */
      if (uni == 0x0632) return 0xA5;
      /* jeh */
      if (uni == 0x0698) return 0xA6;

      /* seen */
      if (uni == 0x0633 && (finall || isolated)) return 0xA7;
      if (uni == 0x0633 && (initial || medial)) return 0xA8;
      /* sheen */
      if (uni == 0x0634 && (finall || isolated)) return 0xA9;
      if (uni == 0x0634 && (initial || medial)) return 0xAA;
      /* sad */
      if (uni == 0x0635 && (finall || isolated)) return 0xAB;
      if (uni == 0x0635 && (initial || medial)) return 0xAC;
      /* dad */
      if (uni == 0x0636 && (finall || isolated)) return 0xAD;
      if (uni == 0x0636 && (initial || medial)) return 0xAE;

      /* arabic letter tah */
      if (uni == 0x0637) return 0xAF;

      /* arabic letter zah */
      if (uni == 0x0638) return 0xE0;

      /* ain */ 
      if (uni == 0x0639 && isolated) return 0xE1;
      if (uni == 0x0639 && finall) return 0xE2;
      if (uni == 0x0639 && medial) return 0xE3;
      if (uni == 0x0639 && initial) return 0xE4;
      /* ghain */ 
      if (uni == 0x063A && isolated) return 0xE5;
      if (uni == 0x063A && finall) return 0xE6;
      if (uni == 0x063A && medial) return 0xE7;
      if (uni == 0x063A && initial) return 0xE8;

      /* feh */
      if (uni == 0x0641 && (finall || isolated)) return 0xE9;
      if (uni == 0x0641 && (initial || medial)) return 0xEA;
      /* qah */
      if (uni == 0x0642 && (finall || isolated)) return 0xEB;
      if (uni == 0x0642 && (initial || medial)) return 0xEC;

      /* keheh = kaf  6A9 is probably wrong / 6A9 probable estas malgxusta */
      if (uni == 0x06A9 && (finall || isolated)) return 0xED;
      if (uni == 0x06A9 && (initial || medial)) return 0xEE;
      /* keheh = kaf */
      if (uni == 0x0643 && (finall || isolated)) return 0xED;
      if (uni == 0x0643 && (initial || medial)) return 0xEE;

      /* gaf */
      if (uni == 0x06AF && (finall || isolated)) return 0xEF;
      if (uni == 0x06AF && (initial || medial)) return 0xF0;
      /* lam */
      if (uni == 0x0644 && (finall || isolated)) return 0xF1;
      if (uni == 0x0644 && after == 0x0627) return 0xF2; /* ligature with alef */
      if (uni == 0x0644 && (initial || medial)) return 0xF3;

      /* meem */
      if (uni == 0x0645 && (finall || isolated)) return 0xF4;
      if (uni == 0x0645 && (initial || medial)) return 0xF5;
      /* noon */
      if (uni == 0x0646 && (finall || isolated)) return 0xF6;
      if (uni == 0x0646 && (initial || medial)) return 0xF7;

      /* waw */
      if (uni == 0x0648) return 0xF8;

      /* heh */
      if (uni == 0x0647 && (finall || isolated)) return 0xF9;
      if (uni == 0x0647 && medial) return 0xFA;
      if (uni == 0x0647 && initial) return 0xFB;

      /* farsi yeh */
      /*  Kial estas du kodoj por sama litero ??? */
      /*  Why are there two codes for the same leter? */
      if (uni == 0x06CC && finall) return 0xFC;
      if (uni == 0x06CC && isolated) return 0xFD;
      if (uni == 0x06CC && (initial || medial)) return 0xFE;

      /* NOT farsi yeh, but seems to look the same */
      if (uni == 0x0649 && finall) return 0xFC;
      if (uni == 0x0649 && isolated) return 0xFD;
      if (uni == 0x0649 && (initial || medial)) return 0xFE;


      /* farsi yeh - two dots underneath */
      if (uni == 0x064A && finall) return 0xFC;
      if (uni == 0x064A && isolated) return 0xFD;
      if (uni == 0x064A && (initial || medial)) return 0xFE;


      /* no-break space */
      if (uni == 0xA0) return 0xFF;

      System.out.println("Ne povis konverti: >  " + uni + " " + Integer.toHexString((int)uni));

      return uni;

   }  // convertUniIran




   /*
    * Convert Iran System to Unicode, one letter
    * Konvertu de Iransistemo al Unikodo, unu litero
    */
   public final static int convertIranUni(byte iransystem) {

      int iransys = iransystem & 0x00FF;

      if (iransys < 0x7F) return iransys;
      /* Arab numbers / Arabaj ciferoj */
      if (iransys >= 0x80 && iransys <= 0x89) return (iransys - 0x80 + 0x6f0);

      /* arabic comma */
      if (iransys == 0x8a) return 0x060C;

      /* arabic tatweel */
      if (iransys == 0x8B) return 0x0640;

      /* arabic question mark / demandosigno */
      if (iransys == 0x8C) return 0x061F;

      /* alef with madda */
      if (iransys == 0x8D) return 0x0622;

      /* yeh with hamza */
      if (iransys == 0x8E) return 0x0626;

      /* hamza */
      if (iransys == 0x8F) return 0x0621;

      /* alef */ 
      if (iransys == 0x90 || iransys == 0x91) return 0x0627;

      /* beh */ 
      if (iransys == 0x92 || iransys == 0x93) return 0x0628;

      /* peh */ 
      if (iransys == 0x94 || iransys == 0x95) return 0x067E;

      /* teh */ 
      if (iransys == 0x96 || iransys == 0x97) return 0x062A;

      /* theh */ 
      if (iransys == 0x98 || iransys == 0x99) return 0x062B;

      /* jeem */ 
      if (iransys == 0x9A || iransys == 0x9B) return 0x062C;

      /* tcheh */ 
      if (iransys == 0x9C || iransys == 0x9D) return 0x0686;

      /* hah */ 
      if (iransys == 0x9E || iransys == 0x9F) return 0x062D;

      /* khah */ 
      if (iransys == 0xA0 || iransys == 0xA1) return 0x062E;

      /* dal */ 
      if (iransys == 0xA2) return 0x062F;

      /* thal */ 
      if (iransys == 0xA3) return 0x0630;

      /* re */ 
      if (iransys == 0xA4) return 0x0631;

      /* zain */ 
      if (iransys == 0xA5) return 0x0632;

      /* je */ 
      if (iransys == 0xA6) return 0x0698;

      /* seen */ 
      if (iransys == 0xA7 || iransys == 0xA8) return 0x0633;

      /* sheen */ 
      if (iransys == 0xA9 || iransys == 0xAA) return 0x0634;

      /* sad */ 
      if (iransys == 0xAB || iransys == 0xAC) return 0x0635;

      /* dad */ 
      if (iransys == 0xAD || iransys == 0xAE) return 0x0636;

      /* ta */ 
      if (iransys == 0xAF) return 0x0637;

      /* za */ 
      if (iransys == 0xE0) return 0x0638;

      /* ain */ 
      if (iransys >= 0xE1 && iransys <= 0xE4) return 0x0639;

      /* ghain */ 
      if (iransys >= 0xE5 && iransys <= 0xE8) return 0x063A;

      /* feh */ 
      if (iransys == 0xE9 || iransys == 0xEA) return 0x0641;

      /* qaf */ 
      if (iransys == 0xEB || iransys == 0xEC) return 0x0642;

      /* keheh (kaf?) */ 
      if (iransys == 0xED || iransys == 0xEE) return 0x0643;   /* 6A9 is probably wrong, 6A9 probable malgxustas */

      /* gaf */ 
      if (iransys == 0xEF || iransys == 0xF0) return 0x06AF;

      /* lam */ 
      if (iransys >= 0xF1 && iransys <= 0xF3) return 0x0644;

      /* meem */ 
      if (iransys == 0xF4 || iransys == 0xF5) return 0x0645;

      /* noon */ 
      if (iransys == 0xF6 || iransys == 0xF7) return 0x0646;

      /* waw / vav */ 
      if (iransys == 0xF8) return 0x0648;

      /* heh */ 
      if (iransys >= 0xF9 && iransys <= 0xFB) return 0x0647;

      /* farsi yeh */ 
      if (iransys >= 0xFC && iransys <= 0xFE) return 0x06CC;

      /* no break space */ 
      if (iransys == 0xFF) return 0xA0;

      return iransys;

   }

   /*
    * Convert Iran System to Unicode
    * Konvertu de Iransistemo al Unikodo
    */
   public final static String convertIranUni(byte[] byte_array) {

      int    len = byte_array.length;
      char[] unicode_chars = new char[len];
      
      for (int i = 0; i < len; i++) {
         unicode_chars[i] = (char)convertIranUni(byte_array[i]);
      }
      return new String(unicode_chars);
   }


}  // SimIran



