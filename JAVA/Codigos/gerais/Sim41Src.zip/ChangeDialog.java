/*
 * ChangeDialog
 * This class implements a search and replace dialogue. It's based on SearchDialog.
 * It must listen for "new font" events from the font_list.
 * Cxi tiu klaso kreas sercx-kaj-sxangx-dialogon. Gxi bazigxas sur SearchDialog.
 * Gxi devas auxskulti "new font" (nova tiparo) eventojn de la tipara listo.
 *
 * Cleve Lendon (Klivo)
 * indriko@yahoo.com
 * http://purl.oclc.org/net/klivo/
 *
 */


/*
 * Changes for 3.2  Sxangxoj por 3.2    1999/08
 *
 * Calculate size of dialogue.
 * Kalkulu grandecon de dialogujo.
 *
 */

/*
 * Changes for 3.4  Sxangxoj por 3.4    2002/10
 *
 * Rewritten. To change all, get a StringBuffer, make
 * changes there, and copy the result back into the 
 * document. Now Change All is lightning fast.
 * Reverkis. Por sxangxi cxion, akiru StringBuffer, faru
 * sxangxojn tie, kaj kopiu la rezulton en la dokumenton.
 * Nun la Sxangxu-cxion-funkcio estas fulmrapida.
 *
 */

/*
 * Changes for 4.0  Sxangxoj por 4.0    2004/05
 *
 * Rewritten again. Because Simredo now supports styled
 * text, I can't make changes in a StringBuffer and copy
 * it back. All style information would be lost.
 *
 * Add a status bar for change all.
 *
 * Add function to change text direction, for Arabic etc.
 *
 * Reverkita denove. Cxar Simredo nun subtenas kunstilan
 * tekston, mi ne povas fari sxangxojn en StringBuffer kaj
 * rekopiu gxin en la documenton. Stilinformoj perdigxus.
 *
 * Montru statustrabon por 'sxangxu cxion'
 *
 * Enmetu funkcion por sxangxi la tekstdirekton, por la araba, ktp.
 *
 */


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;


public class ChangeDialog extends JDialog implements ActionListener {

   JFrame       parent;
   Simredo4     editor;

   private final static int d_width  = 400;   // dialog width   -  dialoga largxeco
   private final static int d_height = 240;   // dialog height  -  dialoga alteco

   JLabel   old_label;
   JLabel   new_label;
   JLabel   number_changed_label;
   String   number_changed_text;

   JButton  next_button;
   JButton  change_one_button;
   JButton  change_all_button;
   JButton  exit_button;

   JCheckBox   distinguish_box;   // Distinguish between upper and lower case.
                                  // Distingu inter majuskloj kaj minuskloj.

   SimTextField   old_text;    // sercxota teksto (malnova teksto)
   SimTextField   new_text;    // nova teksto

   SimTextPane  text_pane;
   Document     doc;

   JPanel       status_bar;
   Graphics   status_bar_g;
   int               status_bar_length;

   int          count;

   public ChangeDialog (JFrame parent, Simredo4 editor, String[] labels) {

      //super(parent, "  " + labels[0]); // Ne povas montri Unikodon en kadro.
      super(parent, "  ");
      this.parent = parent;
      this.editor = editor;

      setSize(d_width, d_height);

      next_button   = new JButton(labels[1]);
      next_button.setActionCommand("next");
      next_button.addActionListener(this);

      change_one_button = new JButton(labels[2]);
      change_one_button.setActionCommand("change one");
      change_one_button.addActionListener(this);

      distinguish_box = new JCheckBox(labels[3]);
      distinguish_box.setActionCommand("distinguish");
      distinguish_box.addActionListener(this);

      old_label = new JLabel(labels[4]);
      old_text  = new SimTextField("", 36);
      new_label = new JLabel(labels[5]);
      new_text  = new SimTextField("", 36);

      change_all_button = new JButton(labels[6]);
      change_all_button.setActionCommand("change all");
      change_all_button.addActionListener(this);

      exit_button = new JButton(labels[7]);
      exit_button.setActionCommand("exit");
      exit_button.addActionListener(this);

      number_changed_label = new JLabel("");
      number_changed_text  = labels[8];

      status_bar = new JPanel();

      Container cp = getContentPane();
      cp.setLayout(new GridBagLayout());

      // Arrange components. Arangxu butonojn.
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.insets = new Insets(5,10,5,10);

      gbc.fill = GridBagConstraints.NONE;
      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 0;  gbc.gridy = 0; gbc.gridwidth = 2;
      cp.add(next_button,gbc);
      gbc.gridx = 2;
      cp.add(change_one_button,gbc);
      gbc.gridx = 5;
      gbc.anchor = GridBagConstraints.EAST;
      cp.add(exit_button,gbc);
      gbc.anchor = GridBagConstraints.CENTER;
      gbc.gridx = 0;  gbc.gridy = 1; gbc.gridwidth = GridBagConstraints.REMAINDER;
      cp.add(distinguish_box,gbc);

      gbc.anchor = GridBagConstraints.NORTHWEST;
      gbc.gridx = 0;  gbc.gridy = 2; gbc.gridwidth = 1;
       cp.add(old_label,gbc);
      gbc.gridx = 1;  gbc.gridy = 2; gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.fill = GridBagConstraints.BOTH;
      cp.add(old_text,gbc);
      gbc.fill = GridBagConstraints.NONE;
      gbc.gridx = 0;  gbc.gridy = 3; gbc.gridwidth = 1;
      cp.add(new_label,gbc);
      gbc.gridx = 1;  gbc.gridy = 3; gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.fill = GridBagConstraints.BOTH;
      cp.add(new_text,gbc);
      gbc.fill = GridBagConstraints.NONE;

      gbc.gridx = 0;  gbc.gridy = 4; gbc.gridwidth = 3;
      cp.add(change_all_button, gbc);
      gbc.anchor = GridBagConstraints.CENTER;
      gbc.gridx = 2; gbc.gridwidth = GridBagConstraints.REMAINDER;
      cp.add(number_changed_label, gbc);

      gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = GridBagConstraints.REMAINDER;
      gbc.fill = GridBagConstraints.BOTH;
      cp.add(status_bar, gbc);

   }  // end of constructor


   public void actionPerformed(ActionEvent e) {

      String the_command = e.getActionCommand();
      boolean  distinguish = distinguish_box.isSelected();

      String replacement_text = SimCon.convertBackslash(new_text.getText());

      number_changed_label.setText("");
      number_changed_label.repaint();

      if (the_command.equals("exit")) {
         setVisible(false);
         return;
      }
      else
      if (the_command.equals("next")) {   // Trovu sekvantan lokon.
         doc = text_pane.getDocument();
         findNext(getTextToFind(), distinguish);
         text_pane.requestFocus();
      }  // if next (sekvanta)
      else
      if (the_command.equals("change one")) {    // Sxangxu unu.
         doc = text_pane.getDocument();
         if (text_pane.getSelectionStart() != text_pane.getSelectionEnd()) {
            text_pane.replaceSelection(replacement_text);
         }
         findNext(getTextToFind(), distinguish);  // al la sekvanta
         text_pane.requestFocus();
      }
      else
      if (the_command.equals("change all")) {    // Sxangxu cxiujn.
         doc = text_pane.getDocument();
         changeAll(getTextToFind(), replacement_text, distinguish);
         text_pane.requestFocus();
         validate();
      }
      else
      if (the_command.equals("new font")) {
         newFont();
      }

   }  // actionPerformed


   public void newFont() {
         // Change the font.  Sxangxu la tiparon.
         String font_name = editor.getSelectedFontName();
         Font font1 = Font.decode(font_name);
         Font font2 = font1.deriveFont(Font.PLAIN,16.0f);
         old_text.setFont(font2);
         old_text.repaint();
         new_text.setFont(font2);
         new_text.repaint();
         validate();
   }

   public void changeDirection(boolean left_to_right) {
         if (left_to_right) {
            old_text.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
            new_text.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
         }
         else {
            old_text.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
            new_text.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
         }
         validate();
   }


   /*
    * showIt - Display this dialog.
    * showIt - Montru cxi tiun dialogon.
    */
   public void showIt(SimTextPane text_pane) {

      this.text_pane = text_pane;
      setVisible(true);

      // Position the dialog in the center of the main frame.
      // Metu la dialogon en la mezon de la cxefa kadro.

      int new_width = old_label.getWidth() + old_text.getWidth() + 80;
      int new_height = old_text.getHeight() * 7 + 60;
      if (new_width < d_width) new_width = d_width;
      if (new_height < d_height) new_height = d_height;

      Rectangle p_rect = parent.getBounds();
      Rectangle d_rect = new Rectangle(p_rect.x + Math.abs(p_rect.width - new_width)/2,
                                       p_rect.y + Math.abs(p_rect.height - new_height)/2,
                                       new_width, new_height);
      setBounds(d_rect);

      parent.requestFocus();
      validate();

   }  // showIt


   /*
    * getTextToFind - Gets the text to find from the text field and 
    * converts to lower case if necesary.
    * getTextToFind - Akiras sercxotan tekston de la tekst-kampo kaj
    * konvertas gxin al minuskloj, se necese.
    */
   private String getTextToFind() {
      String  from_field = old_text.getText();

      // Convert \n and \t to new line and tab.
      // Konvertu \n kaj \t al novlinio kaj horizontala salto.
      String converted_string = SimCon.convertBackslash(from_field);

      String  temp1,temp2;
      if (distinguish_box.isSelected()) {
         return converted_string;
      }
      else {
         // Must convert to lower case. Devas minuskligi.
         return SimCon.toLower(converted_string);
      }

   }  // getTextToFind




   /*
    * findNext - Find the next string. This method searches down from the 
    * current position. If the text is found, it is selected.
    * findNext - Trovu la sekvantan litercxenon. CXi tiu metodo sercxas malsupren 
    * de la nuna pozicio. Se gxi trovas la tekston, gxi selektas gxin.
    */
   private boolean findNext(String to_find, boolean distinguish) {
 
      String str, str2;

      // get the text
      // akiru la tekston

      try {
         if (to_find.length() > doc.getLength()) return false;
         str = doc.getText(0, doc.getLength());
      } catch (BadLocationException blx) {
         System.err.println("Change Dialog: bad location\n"); 
         System.err.println("Sxanghodialogo: malbona loko\n" + blx.toString());
         return false;
      }

      int start_position = text_pane.getCaretPosition();   // komenca pozicio

      if (text_pane.getSelectionStart() != text_pane.getSelectionEnd()) {
         start_position = text_pane.getSelectionEnd();
      }

      int index;

      if (distinguish) {
         str2 = str;
      }
      else {      // Se majuskleco ne gravas.
         str2     = SimCon.toLower(str);
         // to_find has already been converted to lower case
         // to_find jam estas minuskligita
      }

     index = str2.indexOf(to_find, start_position);

     if (index >= 0) {
         try {
            text_pane.setCaretPosition(index);
            text_pane.moveCaretPosition(index + to_find.length());
         } catch (NullPointerException npx) {
            // I don't know why this happens, but I'll report it.
            // Mi ne scias kial cxi tio okazas, sed mi raportos gxin.
            System.err.println("Null pointer.");
            System.err.println("Nula montrilo. 2\n" + npx.toString());
            return false;
         }
         return true;
     }
     else {
        return false;
     }

   }  // findNext




   ////////////////////////////////////////////////////////////////
   // Change all occurances in the file
   // Sxangxu cxiun tekson en la dosiero.
   void changeAll(String to_find, String replacement, boolean distinguish) {

      int   find_length         = to_find.length();
      int   replacement_length  = replacement.length();
      int   doc_length          = doc.getLength();

      String str, str2;

      // get the text
      // akiru la tekston

      if (find_length == 0) return;
      if (find_length > doc_length) return;

      try {
         str = doc.getText(0, doc_length);
      } catch (BadLocationException blx) {
         System.err.println("ChangeAll: bad location\n"); 
         System.err.println("ChangeAll: malbona loko\n" + blx.toString());
         return;
      }

      if (distinguish) {
         str2 = str;
      }
      else {      // Se majuskleco ne gravas.
         str2     = SimCon.toLower(str);
         // to_find has already been converted to lower case
         // to_find jam estas minuskligita
      }

      count = 0;
      int str_index      = 0;   // index to str
      int doc_index      = 0;   // index to doc
      int adjustment     = 0;   // length of doc may change
                                // longeco de doc eble sxangxigxos
      int difference_in_length  = replacement_length - find_length;

      // Paint status bar. Pentru statustrabon.
      statusStart();

      while (str_index < str.length()) {
         str_index = str2.indexOf(to_find, str_index);
         if (str_index >= 0) {
            doc_index = str_index + adjustment;
            try {
               text_pane.setCaretPosition(doc_index);
               text_pane.moveCaretPosition(doc_index + find_length);
               text_pane.replaceSelection(replacement);
            } catch (NullPointerException npx) {
               System.err.println("ChangeAll: Null pointer.\n");
               System.err.println("ChangeAll: Nula montrilo. \n" + npx.toString());
               return;
            }
            count++;
            if (count % 40 == 0) drawStatus(str_index, doc_length);
            adjustment = adjustment + difference_in_length;
            str_index = str_index + find_length;
         }
         else {
            break;
         }
      }

      // Display the number of changes.  Montru la nombron da sxangxoj.
      number_changed_label.setText(number_changed_text + "  " + String.valueOf(count));
      number_changed_label.repaint();
      statusClear();

   }  // end of changeAll()


   private void statusStart() {
      status_bar_g = status_bar.getGraphics();
      status_bar_length = status_bar.getWidth();
      statusClear();
      status_bar_g.setColor(Color.blue);
   }

   private void drawStatus(int ind, int total) {
      float  percent = (float)ind / (float)total;
      int length = (int)(percent * status_bar_length);
      status_bar_g.fillRect(0, 0, length, 10);
   }

   private void statusClear() {
      status_bar_g.clearRect(0, 0, status_bar_length, 10);
      status_bar.repaint();
   }

}  // ChangeDialog



