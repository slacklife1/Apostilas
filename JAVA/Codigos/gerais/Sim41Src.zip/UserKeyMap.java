/*
 * UserKeyMap
 *
 * This class has methods for implementing user key maps.
 * It receives a file object from the class Simredo3, reads the
 * file, and uses it to create a translation table. Keymap files 
 * have an extention of kmp, eg., Persian.kmp
 *
 * Lines that begin with a space in the keymap file are
 * ignored (treated as comments). Other lines are treated
 * as a key assignment, one per line. The translated codes 
 * can be indicated with their real unicode character or by 
 * their hex value. It is possible to translate to more than 
 * one character.
 * For example:
 *
 * QSx
 * qsx
 * 0\u06F0
 * 1\u06F1
 * altaThis text will appear when the user types Alt-a.
 * altbThis text will appear when the user types Alt-b.
 *
 * As the above examples show, Alt-key sequences can be
 * redefined. I originally designed this class to allow
 * redefinition of Ctrl-keys also, but this is difficult
 * because many Ctrl-key have key-bindings (swing keymaps).
 * Rather than unbinding already bound ctrl-keys, I've 
 * decided not to allow redefinition of ctrl-keys.
 *
 * I've decided to add dead-key definitions:
 * 2keys^A�
 * 2keys"A�
 * When the user types two consecutive keys, for example,
 * circumflex and the letter A, as in the above example, it will
 * be replaced with the following letter (�).
 *
 * ------------------------------------------------------------
 *
 * Cxi tiu klaso havas metodojn por funkciigi klavmapojn por 
 * uzantoj. La klaso Simredo3 donas dosieran objekton (File).
 * Cxi tiu klaso legas la dosieron kaj kreas traduktabelon.
 * Klavmapaj dosieroj havas sufikson de kmp, ekzemple: 
 * Persian.kmp
 *
 * Linioj kiuj komencigxas per spaco en la klavmapa dosiero 
 * estas malatentataj (traktataj kiel komentoj). Aliaj linioj
 * estas traktataj kiel klavdifinoj: unu po linio. La traduk-
 * kodoj povas esti indikitaj per siaj veraj unikodaj signoj,
 * aux per deksesuma cifero. Eblas traduki klavon al pli ol unu
 * litero. Ekzemploj:
 *
 * QSx
 * qsx
 * 0\u06F0
 * 1\u06F1
 * altaCxi tiu teksto aperos kiam la uzanto tajpas Alt-a.
 * altbCxi tiu teksto aperos kiam la uzanto tajpas Alt-b.
 *
 * Kiel la supraj ekzemploj montras, eblas redifini Alt-klavojn.
 * Mi originale desegnis cxi tiun klason pro permesi la redifinon
 * de ctrl-klavoj ankaux, sed cxi tio estas malfacila cxar multaj
 * ctrl-klavoj estas ligitaj (vidu: Swing keymaps, bindings). 
 * Anstataux ol malligi jam ligitajn ctrl-klavojn, mi decidis ne
 * permesi redifinon de ctrl-klavojn.
 *
 *
 * Mi decidis subteni la difinon de senpasxaj klavoj, ekzemple:
 * 2keys^A�
 * 2keys"A�
 * Kiam uzanto tajpos du sinsekvajn klavoj, ekzemple,
 * cirkumflekson kaj literon A, kiel supre, ili estos anstatauxitaj
 * per la sekvanta litero, (�).
 *
 * Cleve Lendon (Klivo)
 * indriko@yahoo.com
 * http://purl.oclc.org/net/klivo/
 * 2000/12/19
 *
 * 2001/01/11 fix for 3.31  Alas :-(
 * 2001/01/11 korekto por 3.31  Ho Ve :-(
 * Fix alt functionality (forgot else in loadUserKeyMap)
 * Korektu Alt-klav-funkcion (forgeis 'else' en loadUserKeyMap)
 *
 * 2002/10
 * Rewrite deadkey (2keys) functionality for more flexibility.
 * Reverku funkciojn de senpasxaj klavoj por pli da flekseblo.
 *
 */

import java.awt.*;
import java.io.*;
import java.util.*;

public class UserKeyMap {

   private static boolean enabled;

   public static String[] key_table;   // No control keys. Sen regklavoj.
   public static String[] ctrl_table;  // control  - provizore ne uzu.
   public static String[] alt_table;   // alternative


   // Chars are two bytes long. Integers are 4. To speed
   // up searching, two characters will be stored as a
   // single integer in the keypairs table.
   // 'char' estas dubitoka. Entjeroj estas 4. Por rapidigi
   // sercxadon, du signoj (char) estos konservitaj kiel
   // unu entjero en la keypairs-tabelo.

   private final static int MAX_KEYPAIRS = 500;
   public  static int number_of_keypairs;
   private static int keypair_index;

   public static int[]     keypairs;
   public static String[]  keypair_translation;


   public final static int table_size = ('~' - '!') + 1;

   public UserKeyMap () {
      key_table   = new String[table_size]; 
      ctrl_table  = new String[table_size];
      alt_table   = new String[table_size];
      keypairs    = new int[MAX_KEYPAIRS];
      keypair_translation = new String[MAX_KEYPAIRS];
      number_of_keypairs = 0;
      keypair_index = 0;
      enabled = false;
   }


   public static boolean isEnabled() {
      return enabled;
   }

   public static void setEnabled(boolean b) {
      if (b == true) enabled = true;
      else enabled = false;
   }


   public static void loadUserKeyMap(File keymap_file) {

      // Clear out the translation tables.
      // Visxu la traduktabelojn.
      key_table   = new String[table_size]; 
      ctrl_table  = new String[table_size];
      alt_table   = new String[table_size];
      keypairs    = new int[MAX_KEYPAIRS];
      keypair_translation = new String[MAX_KEYPAIRS];
      number_of_keypairs = 0;
      keypair_index = 0;

      // If the keymap file was null, just exit.
      // Se la klavmapa dosiero estis nula, nur cxesu.
      enabled = false;
      if (keymap_file == null) return;

      int   table_index;

      String   the_line;      // Linio de la klavmapa dosiero.
      char     the_char;      // key to convert   /  konvertota klavo
      char     second_char;   // for deadkeys  / por senpasxaj klavoj (2keys)
      String   rest_of_line;  // restajxo de la linio

      if (keymap_file != null) {
         try {
            FileInputStream   fis   = new FileInputStream(keymap_file);
            InputStreamReader isr   = new InputStreamReader(fis,"UnicodeBig");
            BufferedReader    in    = new BufferedReader(isr);
            while (in.ready()) {
               the_line = in.readLine();
               if (the_line.length() > 1 && the_line.charAt(0) != ' ') {
                  rest_of_line = "";
                  if (the_line.toLowerCase().startsWith("alt")) {
                     if (the_line.length() >= 5) {
                        the_char = the_line.charAt(3);
                        rest_of_line = the_line.substring(4);
                        if (the_char >= '!' && the_char <= '~') {
                           table_index = (int)(the_char - '!');
                           alt_table[table_index] = convert_slash_u(rest_of_line);
                        }
                     }
                  } else  
                  if (the_line.toLowerCase().startsWith("2keys")) {
                     the_line = convert_slash_u(the_line);
                     if (the_line.length() >= 8 && 
                         keypair_index < MAX_KEYPAIRS) {
                        the_char = the_line.charAt(5);
                        second_char = the_line.charAt(6);
                        rest_of_line = the_line.substring(7);
                        keypairs[keypair_index] =
                           (int)((the_char * 0x10000) + second_char);
                        keypair_translation[keypair_index] = rest_of_line;
                        keypair_index++;
                     }
                  }
                  else {
                     the_char = the_line.charAt(0);
                     rest_of_line = the_line.substring(1);
                     if (the_char >= '!' && the_char <= '~' && 
                         rest_of_line.length() > 0) {
                        table_index = (int)(the_char - '!');
                        key_table[table_index] = convert_slash_u(rest_of_line);
                     }
                  }
               }
            }  // while

         } catch (IOException ioe) {
            System.err.println("Couldn't read keymap. Ne povis legi klavmapon.");
         }
         number_of_keypairs = keypair_index;
         enabled = true;
      }
   } // end of "loadUserKeyMap"


   // Translate dead key. Traduku senpasxajn klavojn.
   public static String translate(char prev_key, char the_key) {

      //System.out.println(">> " + prev_key + " " + the_key);

      int index;
      int key_int = (int)((prev_key * 0x10000) + the_key);

      for (index = 0; index < number_of_keypairs; index++) {
         if (keypairs[index] == key_int) {
            return keypair_translation[index];
         }
      }

      return null;

   }  // translate



   // Translations for single key presses. 
   // Tradukoj pro unuopaj klav-premoj.
   public static String translate(char the_key, boolean ctrl_down, 
                                                boolean alt_down) {
      String[] table;
      int index;
      //System.out.println(">> " + the_key + " " + ctrl_down);

      if (the_key < '!' || the_key > '~') return null;
      index = the_key - '!';

      if (alt_down) {
         return alt_table[index];
      }
      else {
         return key_table[index];
      }

   }  // translate



   // This method converts unicode escape sequences (\u06F0) in a 
   // string to their equivalent codes.
   // Cxi tiu metodo convertas unikodajn eskap-tekstojn (\u06F0) en 
   // signocxeno al gxiaj ekvivalentaj kodoj.
   private static String convert_slash_u(String to_convert) {

      String  converting = to_convert;
      String  front, uni, end;
      int     the_index;

      the_index = converting.indexOf("\\u");

      while (the_index != -1 && (the_index + 6 <= converting.length())) {
         front = converting.substring(0,the_index);
         uni   = convert_uni_escape(converting.substring(the_index+2,the_index+6));
         if (the_index+6 < converting.length()) 
                         end  = converting.substring(the_index+6);
         else end = "";
         converting = front + uni + end;
         the_index = converting.indexOf("\\u");
      }  // while

      the_index = converting.indexOf("\\U");

      while (the_index != -1 && (the_index + 6 <= converting.length())) {
         front = converting.substring(0,the_index);
         uni   = convert_uni_escape(converting.substring(the_index+2,the_index+6));
         if (the_index+6 < converting.length()) 
                         end   = converting.substring(the_index+6);
         else end = "";
         converting = front + uni + end;
         the_index = converting.indexOf("\\U");
      }  // while
      return converting;

   }  // convert_slash_u



   private static String convert_uni_escape(String uni) {
      char[] the_unicode_char = new char[1];
      try {
         the_unicode_char[0] = (char)Integer.parseInt(uni,16);
      } catch (NumberFormatException nfe) {
         return uni;
      }
      return new String(the_unicode_char);
   }

}  // UserKeyMap



