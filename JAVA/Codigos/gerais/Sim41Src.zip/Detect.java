/*
 * Detect - This class holds methods which detect the encoding of data in
 * an input stream or buffer: rtf, unicode, utf8, etc.
 * (Determinu) - Cxi tiu klaso entenas metodojn por determini la enkodigon 
 * de datumo en enstrio aux bufro: rtf, unikodo, utf8, ktp.
 *
 * Cleve Lendon (Klivo)     1999/02/19
 * indriko@yahoo.com
 * http://purl.oclc.org/net/klivo/
 */

/*
 * Changes for Simredo 4. / Sxangxoj por Simredo 4    
 * 2004/05 - Detect RTF, Shift-JIS, EUC-JP   /   Detektu RTF, Shift-JIS, EUC-JP .
 *
 */

import java.awt.*;
import java.io.*;

public class Detect {


   public static final int MAX                = 1000;  // Maksimuma nombro por kontroli

   // Marker to identify encrypted files. The codes are random.
   // Markilo por identigi kriptaj dosieroj. La kodoj estas hazardaj.

   public static final byte[] ENCRYPTION_MARKER  
                      = {(byte)249, (byte)162, (byte)48, (byte)93, (byte)11, (byte)129}; 

   // Strings to detect Japanese encodings: Shift-JIS and EUC-JP
   // Signocxenoj por rekoni japanajn kodarojn: Shift-JIS kaj EUC-JP
   static final byte[]  sjis_desu = {(byte)0x82, (byte)0xc5, (byte)0x82, (byte)0xb7};
   static final String sjis_desu_str = new String(sjis_desu);
   static final byte[]  sjis_aru = {(byte)0x82, (byte)0xa0, (byte)0x82, (byte)0xe9};
   static final String sjis_aru_str = new String(sjis_aru);
   static final byte[]  sjis_iru = {(byte)0x82, (byte)0xa2, (byte)0x82, (byte)0xe9};
   static final String sjis_iru_str = new String(sjis_iru);
   static final byte[]  sjis_suru = {(byte)0x82, (byte)0xb7, (byte)0x82, (byte)0xe9};
   static final String sjis_suru_str = new String(sjis_suru);
   static final byte[]  sjis_masu = {(byte)0x82, (byte)0xdc, (byte)0x82, (byte)0xb7};
   static final String sjis_masu_str = new String(sjis_masu);

   static final byte[]  eucjp_desu = {(byte)0xa4, (byte)0xc7, (byte)0xa4, (byte)0xb9};
   static final String eucjp_desu_str = new String(eucjp_desu);
   static final byte[]  eucjp_aru = {(byte)0xa4, (byte)0xa2, (byte)0xa4, (byte)0xeb};
   static final String eucjp_aru_str = new String(eucjp_aru);
   static final byte[]  eucjp_iru = {(byte)0xa4, (byte)0xa4, (byte)0xa4, (byte)0xeb};
   static final String eucjp_iru_str = new String(eucjp_iru);
   static final byte[]  eucjp_suru = {(byte)0xa4, (byte)0xb9, (byte)0xa4, (byte)0xeb};
   static final String eucjp_suru_str = new String(eucjp_suru);
   static final byte[]  eucjp_masu = {(byte)0xa4, (byte)0xde, (byte)0xa4, (byte)0xb9};
   static final String eucjp_masu_str = new String(eucjp_masu);


   public Detect () {}

   public static FileInformation whatIsIt(File file_to_test) {

      int  ind1, ind2, ind3;   // Indices

      FileInformation fi = new FileInformation();

      int    first_code = 0;
      int    second_code = 0;

      byte[]   byte_buffer = new byte[MAX];
      String  str_buffer;

      if (file_to_test.exists()) {       // Se la dosiero ekzistas...

         try {

            // Read bytes to determine the file encoding.
            // Legu bajtojn por determini la enkodigon de la dosiero.

            FileInputStream fin = new FileInputStream(file_to_test);
            int number_read = fin.read(byte_buffer, 0, MAX);
            fin.close();

            fi.status   = FileInformation.UNKNOWN;   // Nesciata

            // Encrypted. Cxu kriptigita?
            if (isEncryptedFile(byte_buffer, number_read)) {
               fi.status = FileInformation.KNOWN;
               fi.encoding = "Encrypted";
               return fi;
            }

            // Check for double byte standards (UTF-16, big or little endian)
            // Kontrolu dubajtajn normojn (UTF-16, pezkomenca aux pezfina)
            if (number_read > 2) {
               first_code = (int)(byte_buffer[0]) & 0xFF;
               second_code = (int)(byte_buffer[1]) & 0xFF;
            }
            else {
               return fi;  // Unknown / Nesciata
            }

            if (first_code == 255 && second_code == 254) {
               // this is a little endian unicode file
               // cxi tio estas pezfina unikodo
               fi.status = FileInformation.KNOWN;
               fi.encoding = "UTF-16LE";
               return fi;
            }

            if (first_code == 254 && second_code == 255) {
               // this is a big endian unicode file
               // cxi tio estas pezkomenca unikodo
               fi.status = FileInformation.KNOWN;
               fi.encoding = "UTF-16BE";
               return fi;
            }

            if (isRTF(byte_buffer, number_read)) {
               fi.status = FileInformation.KNOWN;
               fi.encoding = "RTF";
               return fi;
            }

            if (isUTF8(byte_buffer)) {
               fi.status = FileInformation.KNOWN;
               fi.encoding = "UTF8";
               return fi;
            }

            str_buffer = new String(byte_buffer, 0, number_read);

            if (isSJIS(str_buffer)) {
               fi.status = FileInformation.KNOWN;
               fi.encoding = "SJIS";
               return fi;
            }

            if (isEUCJP(str_buffer)) {
               fi.status = FileInformation.KNOWN;
               fi.encoding = "EUC_JP";
               return fi;
            }

            fi.encoding = "";  // Default

         } catch (IOException io) {
            System.err.println("I/O error in Detect. En/El-eraro en Detect. " + io.getMessage());
            fi.status = FileInformation.CANT_LOAD;
         } 

      } // if
      else {
         fi.status = FileInformation.CANT_LOAD;
      }

      return fi;

   }  // whatIsIt





// Cxi tiu tabelo montras la rilaton inter Unikodo kaj UTF8.
//
// This table shows the relationship between Unicode and UTF8. 
//--------------------------------------------------------
//    Unikodo                 UTF8
//--------------------------------------------------------
//    00000000 0xxxxxxx       0xxxxxxx         
//    00000xxx xxyyyyyy       110xxxxx 10yyyyyy
//    xxxxyyyy yyzzzzzz       1110xxxx 10yyyyyy 10zzzzzz
//--------------------------------------------------------
//
// De la supra tabelo, ni povas determini la sekvantajn regulojn.
// (komprenu ke cxiuj intervaloj estas inkluzivaj):
// - Kodoj inter 0 kaj 127 estas validaj en UTF8.
// - se kodo estas super 127, gxi devas esti inter 192 kaj 239.
// - se la kodo estas inter 192 kaj 223, la sekvanta kodo devas
//   estis inter 128 kaj 191.
// - se la kodo estas inter 224 kaj 239, la sekvanta kodo devas 
//   esti inter 128 kaj 191, kaj la sekvanta ankaux devas esti
//   inter 128 kaj 191.
// 
// From the above table, we can determine the following (assume 
// all ranges are inclusive):
// - Codes from 0 to 127 are valid in UTF8.
// - if a code is above 127, it must be between 192 and 239
// - if the code is between 192 and 223, the next code must be
//   between 128 and 191.
// - if the code is between 224 and 239, the next code must be 
//   between 128 and 191, and the next one must also be between 
//   128 and 191.

   /*
    * isUTF8 - Determine if the text is in UTF8 format. True means
    * that it could be. False means that it is definitely not.
    * isUTF8 - Determinu cxu la teksto estas en UTF8-formato. Vera 
    * signifas ke gxi eble estas. Falsa signifas ke gxi certe ne estas.
    */
   public static boolean isUTF8(byte[] the_text) {

      boolean all_7_bit_codes = true;      // cxiuj kodoj estas 7-bitaj
      int  the_char; 
      int length = the_text.length;

      if (length > MAX) length = MAX;

      for (int i = 0; i < length - 4; i++) {
         the_char = (int)the_text[i] & 0xFF;
         if (the_char > 127) {
            all_7_bit_codes = false;
            if (the_char >= 192 && the_char <= 223) {
               // Get next code. Akiru sekvantan kodon.
               i++;
               the_char = (int)the_text[i] & 0xFF;
               if (the_char < 128 || the_char > 191) {
                  return false;
               }
            }
            else if (the_char >= 224 && the_char <= 239) {
               // Get next code. Akiru sekvantan kodon.
               i++;
               the_char = (int)the_text[i] & 0xFF;
               if (the_char < 128 || the_char > 191) {
                  return false;
               }
               // Get next code. Akiru sekvantan kodon.
               i++;
               the_char = (int)the_text[i] & 0xFF;
               if (the_char < 128 || the_char > 191) {
                  return false;
               }
            }
            else {
               return false;
            }
         }  // if (the_char > 127)
      }  // for
      if (all_7_bit_codes) return false;
      return true;
   }  // isUTF8



   /*
    * isEncryptedFile - Determine if the text is and encrypted file.
    * isEncryptedFile - Determinu cxu la teksto estas en kripta.
    */
   public static boolean isEncryptedFile(byte[] the_text, int number) {

      if (number < ENCRYPTION_MARKER.length + 3) return false;
      for (int i = 0; i < ENCRYPTION_MARKER.length; i++) {
         if (ENCRYPTION_MARKER[i] != the_text[i]) return false;
      }  // for

      return true;

   }  // isEncrypted


   /*
    * isRTF - Determine if file is RTF.
    * isRTF - Determinu cxu dosiero estas RTF.
    */
   public static boolean isRTF(byte[] buffer, int number_read) {
      if (number_read < 7) return false;
      if (buffer[0] != '{') return false;
      if (buffer[1] != '\\') return false;
      if (buffer[2] != 'r') return false;
      if (buffer[3] != 't') return false;
      if (buffer[4] != 'f') return false;
      return true;
   }  // isRTF

   /*
    * isSJIS - Determine if file is Shift-JIS (Japanese).
    * isSJIS - Determinu cxu dosiero estas Shift-JIS (Japana).
    */
   public static boolean isSJIS(String the_text) {
      if (the_text.indexOf(sjis_desu_str) >= 0) return true;
      if (the_text.indexOf(sjis_aru_str) >= 0) return true;
      if (the_text.indexOf(sjis_iru_str) >= 0) return true;
      if (the_text.indexOf(sjis_suru_str) >= 0) return true;
      if (the_text.indexOf(sjis_masu_str) >= 0) return true;
      return false;
   }  // isSJIS

   /*
    * isEUCJP - Determine if file is EUC-JP (Japanese).
    * isEUCJP - Determinu cxu dosiero estas EUC-JP (Japana).
    */
   public static boolean isEUCJP(String the_text) {
      if (the_text.indexOf(eucjp_desu_str) >= 0) return true;
      if (the_text.indexOf(eucjp_aru_str) >= 0) return true;
      if (the_text.indexOf(eucjp_iru_str) >= 0) return true;
      if (the_text.indexOf(eucjp_suru_str) >= 0) return true;
      if (the_text.indexOf(eucjp_masu_str) >= 0) return true;
      return false;
   }  // isEUCJP

}  // Detect

