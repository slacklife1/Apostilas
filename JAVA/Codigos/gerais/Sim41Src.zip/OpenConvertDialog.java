/*
 * OpenConvertDialog - This dialogue gives the user a list of file formats when
 * he or she selects a file to open. Simredo tries to detect the format of
 * the file to open. If Simredo detects UTF8 codes, it will make the listbox 
 * default to UTF8. The user may select another format for opening.
 *
 * MalfermoKonvertoDialogo - Cxi tiu dialogo montras al la uzanto liston de 
 * dosiero-formatoj kiam li aux sxi selektas dosieron por malfermi. Simredo 
 * provas determini la formaton de la malfermota dosiero. Se Simredo vidas 
 * UTF8-kodojn, gxi defauxltigos la selektoliston al UTF8. La uzanto povas 
 * selekti alian formaton por malfermado. 
 *
 * Cleve Lendon (Klivo)     1999/02/19
 * klivo@infotrans.or.jp
 * http://www.infotrans.or.jp/~klivo/
 *
 * Changes / Sxangxoj
 * Don't put "Encrypted" into the list box.
 * Ne metu "Kriptigita" en la selektoskatolon.
 */


/*
 * Changes for 3.2  Sxangxoj por 3.2    1999/08
 *
 * Calculate size of dialogue.
 * Kalkulu grandecon de dialogujo.
 *
 */

/*
 * Changes for 4.0  Sxangxoj por 4.0    2004/06
 *
 * Don't show first 4 items: rtf unibe, unile, crypt
 * Use only one button, 'OK'.
 *
 * Ne montru unuajn 4 formatojn: rtf, uni pk, uni pf, kript
 * Uzu nur unu butonon, 'Bone'.
 *
 */


import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;


public class OpenConvertDialog extends JDialog implements ActionListener {

   JFrame  parent;

   private final static int d_width  = 300;   // dialog width   -  dialoga largxeco
   private final static int d_height = 130;   // dialog height  -  dialoga alteco


   String[]     encoding_names;          // Names of the encodings, eg. SJIS, UTF8
                                         // Nomoj de la kodaroj, ekz. SJIS, UTF8

   String[]     encoding_descriptions;   // Descriptions on the encodings, eg. Shift-JIS Japanese.
                                         // Priskriboj de la kodaroj, ekz. Shift-JIS Japanese.
   int          number_of_encodings;

   Hashtable    long_to_short;           // Associate long description to short internal name.
                                         // Asociigu longan priskribon al mallonga interna nomo.

   Hashtable    short_to_long;           // Associate short internal name to long description.
                                         // Asociigu mallongan internan nomon al longa priskribo.

   private JLabel         line1;
   private JButton        ok_button;

   private JComboBox      format;          // Listo de dosieroformatoj.

   String decision = "ISO8859_1";    // ISO8859_1 - Latin 1. Same as no conversion.
                                     // Egalas al neniu konverto.
   String selected;

   public OpenConvertDialog (JFrame owner, String[] labels, String encodings) {

      super(owner, true);   // Modal dialogue. Deviga dialogo.
      setSize(d_width, d_height);
      parent = owner;

      Container cp = getContentPane();
      cp.setLayout(new GridBagLayout());

      String[] tokens       = SimCon.tokenize(encodings);
      number_of_encodings   = (tokens.length / 2) - 4;   // Skip the first 4 (rtf,big,little,encrypted).
                                    // Ne inkluzivu la unuajn kvar (rtf,pezkomenca,pezfina,kriptigita).
      encoding_names        = new String[number_of_encodings];
      encoding_descriptions = new String[number_of_encodings];

      int i,j;
      // j = 8, Skip the first 4 (RTF, UTF16 big and little, encrypted).
      // j = 8, Ne inkluzivu la unuajn kvar (RTF, UTF16 pezkomenca kaj pezfina, kriptigita).
      for (i = 0, j = 8; j < tokens.length; i++, j = j + 2) {
         encoding_names[i]        = tokens[j];
         encoding_descriptions[i] = tokens[j+1];
      }

      long_to_short = new Hashtable();
      for (i = 0; i < number_of_encodings; i++) {
         long_to_short.put(encoding_descriptions[i], encoding_names[i]);
      }

      short_to_long = new Hashtable();
      for (i = 0; i < number_of_encodings; i++) {
         short_to_long.put(encoding_names[i], encoding_descriptions[i]);
      }

      // Create and fill the format list.  Kreu kaj plenigu la formatliston.
      format = new JComboBox();

      for (i = 0; i < number_of_encodings; i++) {
         format.addItem(encoding_descriptions[i]);
      }

      line1           = new JLabel(labels[0]);
      ok_button  = new JButton(labels[1]);

      ok_button.setActionCommand("ok");
      ok_button.addActionListener(this);


      GridBagConstraints gbc = new GridBagConstraints();
      gbc.insets = new Insets(5,10,5,10);

      gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 1;
      cp.add(line1, gbc);
      gbc.gridx = 1;
      gbc.anchor = GridBagConstraints.WEST;
      cp.add(ok_button,gbc);

      gbc.gridx = 0; gbc.gridy = 1; 
      gbc.gridwidth = 2; gbc.fill = GridBagConstraints.BOTH;
      gbc.anchor = GridBagConstraints.EAST;
      cp.add(format, gbc);

   }  // end of constructor


   public void actionPerformed(ActionEvent e) {
      String command = e.getActionCommand();
      if (command.equals("ok")) {
         selected = (String)format.getSelectedItem();
         if (selected != null) {
            decision = (String)long_to_short.get(selected);
         }
         else decision = "ISO8859_1";
         setVisible(false);
         return;
      }

   }  // actionPerformed


   /*
    * getDecision - Get the encoding name to convert from.
    * getDecision - Akiru la kodaran nomo por elkonverto.
    */
   public String getDecision() {
      return decision;
   }  // getDecision


   /*
    * showIt - Display this dialog.
    * showIt - Montru cxi tiun dialogon.
    */
   public void showIt() {
      showIt(null);
   }


   /*
    * showIt - Display this dialog. Set format box to the default value.
    * showIt - Montru cxi tiun dialogon. Metu defauxltan formaton en la selektolisto.
    */
   public void showIt(String default_format) {

      // Position the dialog in the center of the main frame.
      // Metu la dialogon en la mezon de la cxefa kadro.

      int new_width = d_width;
      int new_height = d_height;

      Rectangle p_rect = parent.getBounds();
      Rectangle d_rect = new Rectangle(p_rect.x + Math.abs(p_rect.width - new_width)/2,
                                       p_rect.y + Math.abs(p_rect.height - new_height)/2 + 20,
                                       new_width, new_height);

      setBounds(d_rect);

      if (default_format != null) {
         format.setSelectedItem(short_to_long.get(default_format));
      }

      setVisible(true);
      validate();


   }  // showIt


}  // OpenConvertDialog


