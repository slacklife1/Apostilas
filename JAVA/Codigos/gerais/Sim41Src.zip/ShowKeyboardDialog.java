/*
 * ShowKeyboardDialog
 * This class displays the keyboard arrangement.
 * Cxi tiu dialogo montras la klavarangxon.
 *
 * Written by VS Rawat 2004/06
 * Verkita de VS Rawat 2004/06
 *
 */

/*
 * 2004/06 Changes by Cleve / Sxangxoj de Klivo
 * Replace buttons with labels. Adjust sizes to look like keyboard.
 * Anstatauxigu butonojn per etikedojn. Gxustigu grandecojn por imiti klavaron.
 *
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class ShowKeyboardDialog extends JFrame implements ActionListener {
   
    JFrame    parent;
    Rectangle p_rect;    // Bounds of parent

    Font   currentFont;

    private static boolean   keyboardIsEnabled;
    private static final int d_height  = 340;   // dialog height  -  dialoga alteco
    private static final int d_width   = 755;   // dialog width   -  dialoga largxeco
    private static final int d_rows    = 8;
    private static final int d_columns = 14;
    private static int       new_height, new_width;

    private static final int   width1    = 48;        // width of a button   // largxeco de butono
    private static final int   width15  = (int)(width1 * 1.5); 
    private static final int   width2    = (int)(width1 * 2); 
    private static final int   width25  = (int)(width1 * 2.5); 
    private static final int   height1 = 28;         // height of a buton  // alteco de butono
    private static final int   height2 = (int)(height1 * 2);

    String      dispKeymapText, dispFontText, currentKeymapText, currentFontText, exitText,
                backspaceText, tabText, capslockText, enterText, shiftText, altText, keypairText;
    
    JLabel            currentKeymapLabel;   // aktuala klavmapo
    JLabel            currentFontLabel;     // aktuala tiparo
    JComboBox         altComboBox, keypairComboBox;  // por alt-klavoj kaj klavparoj (senpasxaj klavoj)
    JButton           exitButton;
    JLabel[][]        button;
    Border            border;

    GridBagLayout      gridBagL;
    GridBagConstraints gridBagC;
    Container          cPane;

    private static final String[][] all_KeyboardChars = {
            {"~", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "_", "+", " "},  //with shift
            {"`", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "=", " "},  //without shift
            {" ", "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "{", "}", "|"},  //with shift
            {" ", "q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "[", "]", "\\"}, //without shift
            {" ", "A", "S", "D", "F", "G", "H", "J", "K", "L", ":", "\"", " ", " "},   //with shift
            {" ", "a", "s", "d", "f", "g", "h", "j", "k", "l", ";", "\'", " ", " "},    //without shift
            {" ", " ", "Z", "X", "C", "V", "B", "N", "M", "<", ">", "?", " ", " "},     //with shift
            {" ", " ", "z", "x", "c", "v", "b", "n", "m", ",", ".", "/", " ", " "}      //without shift
         };

   
    public ShowKeyboardDialog (JFrame parent, String[] labels) {

        super("   " + labels[0]);
        this.parent = parent;

        p_rect = parent.getBounds();
        setSize(d_width, d_height);
        
        setKeyboardEnabled(false);
        setVisible(false);

        dispKeymapText     = labels[1];
        currentKeymapText  = "";
        dispFontText       = labels[2];
        currentFontText    = "";
        exitText           = labels[3];

        backspaceText      = labels[4];
        tabText            = labels[5];
        capslockText       = labels[6];
        enterText          = labels[7];
        shiftText          = labels[8];
        altText            = labels[9];
        keypairText        = labels[10];

        border = new SoftBevelBorder(SoftBevelBorder.RAISED);
 
        currentKeymapLabel = new JLabel(dispKeymapText + ": " + currentKeymapText);
        currentFontLabel = new JLabel(dispFontText + ": " + currentFontText);

        altComboBox        = new JComboBox();
        altComboBox.setFocusable(false);
        keypairComboBox    = new JComboBox();
        keypairComboBox.setFocusable(false);

        exitButton         = new JButton(exitText);
        exitButton.setActionCommand("exit");
        exitButton.addActionListener(this);
        exitButton.setFocusable(false);

        gridBagL = new GridBagLayout();
        gridBagC = new GridBagConstraints();
        cPane    = getContentPane();
        cPane.setLayout(gridBagL);
      
        gridBagC.insets = new Insets(0,10,0,10);
        gridBagC.gridheight = 1;
        gridBagC.fill = GridBagConstraints.NONE;

        gridBagC.gridy = 0;
        gridBagC.gridx = 0;
        gridBagC.gridwidth = 1;
        cPane.add(currentKeymapLabel, gridBagC);

        gridBagC.gridx = 1;
        cPane.add(currentFontLabel, gridBagC);

        gridBagC.gridx = 2;
        cPane.add(altComboBox, gridBagC);

        gridBagC.gridx = 3;
        cPane.add(keypairComboBox, gridBagC);


        gridBagC.gridx = 4;
        cPane.add(exitButton, gridBagC);
      
        createKeyboardWindow2();

    } // ShowKeyboardDialog


    public void actionPerformed(ActionEvent e) {
        String the_command = e.getActionCommand();
      
        if (the_command.equals("exit")) {
            setVisible(false);
            setKeyboardEnabled(false);
            return;
        }
    } // actionPerformed



/* createKeyboardWindow2
*/
    private void createKeyboardWindow2 () {

        button = new JLabel[d_rows][d_columns];
        gridBagC.anchor = GridBagConstraints.NORTHWEST;

        JPanel  p1    = makeRow(0, 12, 0, 1);
        JLabel bs    = makeKey(13, 0, backspaceText);
        bs.setPreferredSize(new Dimension(width15, height2));
        JPanel r1 = new JPanel();
        r1.add(p1); r1.add(bs);

        JLabel tab   = makeKey(0, 2, tabText);
        tab.setPreferredSize(new Dimension(width15, height2));
        JPanel  p2    = makeRow(1, 13, 2, 3);
        JPanel r2 = new JPanel();
        r2.add(tab); r2.add(p2);

        JLabel caps  = makeKey(0, 4, capslockText);
        caps.setPreferredSize(new Dimension(width2, height2));
        JPanel  p3    = makeRow(1, 11, 4, 5);
        JLabel enter = makeKey(12, 4, enterText);
        enter.setPreferredSize(new Dimension(width15 - 4, height2));
        JPanel r3= new JPanel();
        r3.add(caps); r3.add(p3); r3.add(enter);


        JLabel sh_l  = makeKey(0, 6, shiftText);
        sh_l.setPreferredSize(new Dimension(width25, height2));
        JPanel  p4    = makeRow(2, 11, 6, 7);
        JLabel sh_r  = makeKey(12, 6, shiftText);
        sh_r.setPreferredSize(new Dimension(width2 -4, height2));
        JPanel r4= new JPanel();
        r4.add(sh_l); r4.add(p4); r4.add(sh_r);

        gridBagC.gridheight = 1;
        gridBagC.insets = new Insets(0,0,0,0);

        gridBagC.gridx = 0; 
        gridBagC.gridy = 1; 
        gridBagC.gridwidth  = 5;
        cPane.add(r1, gridBagC);

        gridBagC.gridy = 2; 
        cPane.add(r2, gridBagC);

        gridBagC.gridy = 3; 
        cPane.add(r3, gridBagC);

        gridBagC.gridy = 4; 
        cPane.add(r4, gridBagC);

    } // createKeyboardWindow2


  private JPanel makeRow(int startX, int endX, int startY, int endY) {

      String text;
      String button_char;

      int rows = endY - startY + 1;
      int cols = endX - startY + 1;
      JPanel p = new JPanel(new GridLayout(rows, cols));

      for (int j = startY; j <= endY; j++) {
         for (int i = startX; i <= endX; i++) {
            button[j][i] = getButton("");
            p.add(button[j][i]);
         }
      }
      return p;
   }



   private JLabel makeKey(int X, int Y, String t) {
      JLabel b = getButton(t);
      button[Y][X]  = b;
      return b;
   }

   private JLabel getButton(String t) {
      JLabel b = new JLabel(t);
      b.setHorizontalAlignment(JLabel.CENTER);
      b.setBorder(border);
      b.setPreferredSize(new Dimension(width1, height1));
      return b;
   }



/*
 * fillKeyboardWindow - Write original key and translated key to each label.
 */
    public void fillKeyboardWindow(Font font, boolean wideCharacters) {

        JLabel b;
        String button_text, button_char;
        String strLetter, s;
        char    chLetter, c1, c2;
        String[] key_table = UserKeyMap.key_table;

        for (int gridY1 = 0; gridY1 < d_rows; gridY1++) {
            for (int gridX1 = 0; gridX1 < d_columns; gridX1++) {
               strLetter = all_KeyboardChars[gridY1][gridX1];
               chLetter = strLetter.charAt(0);
               if (chLetter >= '!' && chLetter <= '~' ) {
                   button_text = strLetter;
                   button_char = key_table[chLetter - '!'];
                   if (button_char != null ) {
                      if (wideCharacters) {
                          button_text = button_char;
                      }
                      else {
                          button_text = button_text + "  " + button_char;
                      }
                   }
                   b = button[gridY1][gridX1];
                   //System.err.print(".");
                   if (b != null) {
                      b.setFont(font);
                      b.setText(button_text);
                   }
                   //System.err.print("|");
                }
            }
        }


        //  Add alt keys definitions in its ComboBox
        //  Metu alt-klav-difinojn en list-skatolon.

        altComboBox.removeAllItems();
        altComboBox.setFont(font);
        for (int i = 0; i < UserKeyMap.table_size; i++) {
            if (UserKeyMap.alt_table[i] != null ) {
                s = UserKeyMap.alt_table[i];
                if (s.length() > 6) s = s.substring(6);
                altComboBox.addItem("alt-" + ( (char) ('!' + i) ) + "   " + s);
            }
        }
        if ( altComboBox.getItemCount() == 0) {
            altComboBox.addItem(altText);
        }
        altComboBox.setSelectedIndex(0);

        //  Add 2keys definitions in its ComboBox
        //  Skribu klavparajn difinojn al listskatolo.
        //  (int)((the_char * 0x10000) + second_char);
        keypairComboBox.removeAllItems();
        keypairComboBox.setFont(font);
         for (int i = 0; i < UserKeyMap.number_of_keypairs; i++) {
             c2 = (char) ( UserKeyMap.keypairs[i] & 0xFFFF );
             c1 = (char) ( UserKeyMap.keypairs[i] / 0x10000 );
             keypairComboBox.addItem( " " + c1 + c2 + "     " + UserKeyMap.keypair_translation[i]);
        }

        if ( keypairComboBox.getItemCount() == 0) {
            keypairComboBox.addItem(keypairText);
        }
        keypairComboBox.setSelectedIndex(0);


    } // fillKeyboardWindow



/*
 * showIt - Display this dialog.
 * showIt - Montru cxi tiun dialogon.
 */
    public void showIt(String fontName, String keymapName) {
        newFont2(fontName, keymapName);
        sizeIt();
        setVisible(true);
    }  // showIt
   
/*
 * newFont - Set a new font and refill the character window.
 * newFont - Aktivigu novan tiparon kaj replenigu la signofenestron.
 */
    public void newFont(String fontName, String keymapName) {
        newFont2(fontName, keymapName);
        resizeIt();
        validate();
    } // newFont
   
    public void newFont2(String fontName, String keymapName) {
        boolean wideCharacters = false;
        String keymapLow = keymapName.toLowerCase();
        currentKeymapText = keymapName;
        currentFontText = fontName;
        if (keymapLow.indexOf("viet") >= 0) {
           if (!fontName.equals("Arial") && 
               !fontName.equals("Tahoma") && 
               !fontName.equals("Verdana")) {
              currentFontText = "Arial";
           }
        }
        if (keymapLow.indexOf("tamil") >= 0 ||
            keymapLow.indexOf("malayalam") >= 0 ||
            keymapLow.indexOf("kannada") >= 0) {
            wideCharacters = true;
        }

        currentKeymapLabel.setText(dispKeymapText + ": " + currentKeymapText);
        currentFontLabel.setText(dispFontText + ": " + currentFontText);
        currentFont = new Font(currentFontText, Font.PLAIN, 14);
        fillKeyboardWindow(currentFont, wideCharacters);
        setKeyboardEnabled(true);
    } // newFont2
   

    void sizeIt() {
        p_rect         = parent.getBounds();
        int width = d_width;
        //int tb_width = toolBarWidth();
        //if (tb_width > width) width = tb_width;
        Rectangle d_rect = new Rectangle(p_rect.x + 200, p_rect.y + 300,  width, d_height);
        setBounds(d_rect);
        validate();
    }

   /*
    * resizeIt - Readjust size.
    * resizeIt - Regxustigu grandecon.
    */
    public void resizeIt() {
        Rectangle old_rect = getBounds();
        int width = d_width;
        //int tb_width = toolBarWidth();
        //if (tb_width > width) width = tb_width;
        Rectangle d_rect = new Rectangle(old_rect.x, old_rect.y, width, d_height);
        setBounds(d_rect);
        validate();
    } // resizeIt


   // private int toolBarWidth() {
   //     int w = currentKeymapLabel.getWidth() + currentFontLabel.getWidth() + 
   //             altComboBox.getWidth() + keypairComboBox.getWidth() + 
   //             exitButton.getWidth() + 150;
   //     return w;
   // }

    
    public static boolean keyboardIsEnabled() {
        return keyboardIsEnabled;
    }
   
    public static void setKeyboardEnabled(boolean b) {
        if (b) keyboardIsEnabled = true;
        else keyboardIsEnabled = false;
    }

   // For the MouseListener Interface.  
   // Auxskultu la muson.
   //public void mouseClicked(MouseEvent evt) { 
   //   toFront();
   //   repaint();
   //}
   //public void mouseEntered(MouseEvent evt) { }
   //public void mouseExited(MouseEvent evt) { }
   //public void mousePressed(MouseEvent evt) { }
   //public void mouseReleased(MouseEvent evt) { }

   
} // ShowKeyboardDialog
