/*
 * ConvertDialog - This dialogue allows users to convert character codes,
 * or strings. The conversion tables are UTF-16 files (extension .kon) 
 * which the users creates.
 * ConvertDialog = Cxi tiu dialogo ebligas al uzantoj konverti signokodojn,
 * aux cxenojn. La konvert-tabeloj estas UTF-16aj dosieroj (sufikso .kon)
 * kiujn la uzanto eventuale kreas.
 *
 * Cleve Lendon (Klivo)
 * indriko@yahoo.com
 * http://purl.oclc.org/net/klivo/
 * 2002/10
 * 
 * 2004/06 Changes for version 4.
 * Simredo now supports styled text. Some adjustments to the conversion
 * routines were necessary.
 * Added status bar.
 * New actions 'new to list' and 'new from list' added by Rawat
 *
 * 2004/06 Sxangxoj por versio 4.
 * Simredo nun subtenas kunstilan tekston. Iuj gxustigoj al la konvert-metodoj 
 * estis necesaj.
 * Enmetis statustrabon.
 * Novaj agoj 'new to list' kaj 'new from list', verkitaj de Rawat
 *
 */

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.text.*;
import java.io.*;

public class ConvertDialog extends JDialog implements ActionListener {

   JFrame     parent;

   String     class_path;       

   private final static int d_width  = 400;   // dialog width   -  dialoga largxeco
   private final static int d_height = 190;   // dialog height  -  dialoga alteco

   SimTextPane  text_pane;

   JButton      exit_button;
   JButton      convert_button;

   JLabel       table_label;
   JLabel       from_label;
   JLabel       to_label;
   String       blank = "                         ";

   JComboBox    table_list  = new JComboBox();   // listo de konvert-tabeloj
   JComboBox    from_list   = new JComboBox();   // convert from / konvertu de
   JComboBox    to_list     = new JComboBox();   // convert to   / konvertu al

   JPanel       table_panel;
   JPanel       to_panel;
   JPanel       from_panel;

   JPanel       status_bar;
   Graphics     status_bar_g;
   int          status_bar_length;

   String       no_tables_text;  // neniuj konvert-tabeloj

   private final static int MAX_TABLES = 20;
   String[][]    conversion_tables = new String[MAX_TABLES][];
   private int   number_of_tables;

   public ConvertDialog (JFrame parent, String class_path, String[] labels) {

      super(parent, "  " + labels[0]);
      //super(parent, "  " );
      this.parent = parent;
      this.class_path = class_path;

      setSize(d_width, d_height);
      Container cp = getContentPane();
      cp.setLayout(new GridBagLayout());

      convert_button = new JButton(labels[1]);
      convert_button.setActionCommand("convert");
      convert_button.addActionListener(this);

      exit_button = new JButton(labels[2]);
      exit_button.setActionCommand("exit");
      exit_button.addActionListener(this);

      from_list.setActionCommand("new from list");
      from_list.addActionListener(this);

      to_list.setActionCommand("new to list");
      to_list.addActionListener(this);

      table_label = new JLabel(labels[3] + "   ");
      from_label  = new JLabel(labels[4]);
      to_label    = new JLabel(labels[5]);

      no_tables_text = labels[6];

      status_bar = new JPanel();
      table_panel = new JPanel();
      to_panel = new JPanel();
      from_panel = new JPanel();

      // Arrange components. Arangxu butonojn.
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.anchor = GridBagConstraints.NORTHWEST;
      gbc.insets = new Insets(5,10,5,10);

      table_panel.add(table_label);
      table_panel.add(table_list);

      to_list.addItem(blank);
      from_list.addItem(blank);
      to_panel.add(to_label);
      to_panel.add(to_list);
      from_panel.add(from_label);
      from_panel.add(from_list);

      gbc.gridx = 0;  gbc.gridy = 0; gbc.gridwidth = 2;
      cp.add(table_panel, gbc);

      gbc.gridy = 1;

      gbc.fill = GridBagConstraints.BOTH;
      gbc.gridx = 0; gbc.gridwidth = 1;
      cp.add(from_panel,gbc);

      gbc.gridx = 1;
      cp.add(to_panel,gbc);

      gbc.fill = GridBagConstraints.NONE;
      gbc.gridy = 2;
      gbc.gridx = 0;
      cp.add(convert_button,gbc);
      gbc.anchor = GridBagConstraints.NORTHEAST;
      gbc.gridx = 1;
      cp.add(exit_button,gbc);

      gbc.fill = GridBagConstraints.BOTH;
      gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 8;
      cp.add(status_bar, gbc);

      initializeTableList();

   }  // end of constructor


   public void actionPerformed(ActionEvent e) {

      int ind, num;

      String command = e.getActionCommand();
      if (command.equals("exit")) {
         setVisible(false);
      }
      else
      if (command.equals("convert")) {
         convertAll();
      }
      if (command.equals("new table")) {
         loadToAndFromLists();
         validate();
         resizeIt();
      }
      if (command.equals("new from list")) {
         // don't use number_of_tables!!
         // ne uzu number_of_tables!!
         num = to_list.getItemCount();
         if (num >= 2) {
            ind = to_list.getSelectedIndex();
            if (ind == from_list.getSelectedIndex()) {
               ind++;
               if (ind >= num) ind = 0;
               to_list.setSelectedIndex(ind);
            }
         }
      }
      if (command.equals("new to list")) {
         // don't use number_of_tables!!
         // ne uzu number_of_tables!!
         num = from_list.getItemCount();
         if (num >= 2) {
            ind = from_list.getSelectedIndex();
            if (ind == to_list.getSelectedIndex()) {
               ind++;
               if (ind >= num) ind = 0;
               from_list.setSelectedIndex(ind);
            }
         }
      }


   }  // actionPerformed


   /*
    * showIt - Display this dialog.
    * showIt - Montru cxi tiun dialogon.
    */
   public void showIt(SimTextPane text_pane) {

      this.text_pane = text_pane;

      // Position the dialog in the center of the main frame.
      // Metu la dialogon en la mezon de la cxefa kadro.

      int new_width = (from_label.getWidth() + from_list.getWidth() +  50) * 2;
      int new_height = from_list.getHeight() * 6 + 60;
      if (new_width < d_width) new_width = d_width;
      if (new_height < d_height) new_height = d_height;

      Rectangle p_rect = parent.getBounds();
      Rectangle d_rect = 
           new Rectangle(p_rect.x + Math.abs(p_rect.width - d_width)/2,
                         p_rect.y + Math.abs(p_rect.height - d_height)/2 + 20,
                         new_width, new_height);
      setBounds(d_rect);
      setVisible(true);
      validate();

   }  // showIt

   /*
    * resizeIt - Adjust the size of the dialog.
    * resizeIt - Gxustigu la grandecon de la dialogo.
    */
   public void resizeIt() {

      // Position the dialog in the center of the main frame.
      // Metu la dialogon en la mezon de la cxefa kadro.

      int new_width = (from_label.getWidth() + from_list.getWidth() +  50) * 2;
      int new_height = from_list.getHeight() * 6 + 60;
      if (new_width < d_width) new_width = d_width;
      if (new_height < d_height) new_height = d_height;

      Rectangle rect = getBounds();
      rect = new Rectangle(rect.x, rect.y, new_width, new_height);
      setBounds(rect);
      validate();

   }  // resizeIt



   ////////////////////////////////////////////////////////////
   // Load To and From Lists   // Sxargu la de- kaj al- listojn.
   void loadToAndFromLists() {

      from_list.removeAllItems();
      to_list.removeAllItems();
      if (table_list.getSelectedIndex() == 0) {
         from_list.addItem(blank);
         to_list.addItem(blank);
         return;
      }
      // akiru nomon de konvert-dosiero
      String conversion_file_name = (String)table_list.getSelectedItem();
      if (conversion_file_name.toLowerCase().equals("esperanto")) {
         loadEspTables();
      }
      else {
         File conversion_file = new File(class_path, 
                                         conversion_file_name + ".kon");
         loadTables(conversion_file);
      }
      for (int i = 0; i < number_of_tables; i++) {
         from_list.addItem(conversion_tables[i][0]);
         to_list.addItem(conversion_tables[i][0]);
      }
      if (to_list.getItemCount() > 1) {
         to_list.setSelectedIndex(1);
      }
   }


   //////////////////////////////////////////////////////////////
   // Load the conversion tables from a file.
   // Sxargu la konvert-tabelojn de dosiero.
   void loadTables(File con_table_file) {

      if (con_table_file == null) return;

      String   the_line;      // Linio de la dosiero.

      number_of_tables = 0;

      try {

         FileInputStream   fis   = new FileInputStream(con_table_file);
         InputStreamReader isr   = new InputStreamReader(fis,"UnicodeBig");
         BufferedReader    in    = new BufferedReader(isr);

         while (in.ready()) {
            the_line = in.readLine();
            if (the_line.length() > 1 && the_line.charAt(0) != ' ') {
               conversion_tables[number_of_tables] = splitString(the_line);
               number_of_tables++;
            }
         }  // while

      } catch (IOException ioe) {
         System.err.println("Couldn't read conversion table.");
         System.err.println("Ne povis legi konvert-tablon.");
      }

   } // end of "loadTables"



   ///////////////////////////////////////////////////////
   // Load the conversion tables for Esperanto.
   // These are hardcoded, not loaded from the kon-file.
   // Sxargu la konvert-tabelojn por Esperanto.
   // Cxi tiuj estas fiksitaj, ne sxargitaj de dosiero.

   void loadEspTables() {

      conversion_tables[0] = UNIstrings;
      conversion_tables[1] = LATIN3strings;
      conversion_tables[2] = Xstrings;
      conversion_tables[3] = Hstrings;
      conversion_tables[4] = CIRstrings;
      number_of_tables = 5;

   } // end of "loadEspTables"



   // splitString - divide a comma separated list.
   // Dividu komo-apartigitan liston.
   private String[] splitString(String the_string) {

      final int MAX_STRINGS = 500;
      String[] string_list = new String[MAX_STRINGS];
      String[] return_list;

      int front = 0;  // indeksoj, antauxa kaj posta
      int end;

      int i;
      for (i = 0; i < MAX_STRINGS && front < the_string.length();) {
         end = the_string.indexOf(",",front);
         if (end > 0) {
            if (end - front > 0) {
               string_list[i] = convert_slash_u(the_string.substring(front, end));
               i++;
            }
            else {
               string_list[i] = "";
               i++;
            }
            front = end + 1;
         }
         else {
            end = the_string.length();
            if (end - front > 0) {
               string_list[i] = convert_slash_u(the_string.substring(front, end));
               i++;
            }
            break;
         }
      }  // end of 'for'

      return_list = new String[i];
      for (int j = 0; j < i; j++) {
         return_list[j] = string_list[j];
      }

      return return_list;
   }


   /**
    * Initialize table_list.
    * Pretigu liston de konvert-tabeloj.
    */
   protected  void  initializeTableList() {

      String   table_name;
      int      dot_index;

      File conversion_table_files = new File(class_path);

      table_list.removeAllItems();
      table_list.addItem(no_tables_text);
      String[] table_names = 
                conversion_table_files.list(new ConversionTableFilter());

      if (table_names != null) {
         for (int i = 0; i < table_names.length; i++) {
            table_name = table_names[i];
            dot_index   = table_name.lastIndexOf(".");
            table_list.addItem(table_name.substring(0, dot_index));
         }
      }

      table_list.setActionCommand("new table");
      table_list.addActionListener(this);

   }  // initializeTableList


   // Filter for conversion table files. (.kon)
   // Filtrilo por konvert-tablo-dosieroj.  (.kon)
   class ConversionTableFilter implements FilenameFilter {

      ConversionTableFilter() {
      }

      public boolean accept(File dir, String name) {
         if (name.toLowerCase().endsWith("kon")) return true;
         return false;
      }
   }


   /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Convert all, according to the selected to and from tables.
   // Konvertu cxion, laux la de- kaj al-tabeloj.

   void convertAll() {

      String the_table = ((String)table_list.getSelectedItem()).toLowerCase();

      int from_index = from_list.getSelectedIndex();  // de-tabelo
      int to_index   = to_list.getSelectedIndex();    // al-tabelo
      if (to_index == from_index) return;

      String[]  from_strings = conversion_tables[from_index];
      String[]  to_strings   = conversion_tables[to_index];

      char from_code = from_strings[0].toLowerCase().charAt(0);  // Just the first letter. Nur la unua litero.
      char to_code   = to_strings[0].toLowerCase().charAt(0);

      // Call special conversion methods for Esperanto.
      // Voku specialajn konvert-metodojn por Esperanto.

      if (the_table.equals("esperanto")) {
         if (from_code  == 'h') {
            hToUnicode(getString());
            convertAll2(UNIstrings, to_strings);
            text_pane.requestFocus();
            return;
         }
         else if (from_code  == 'x') {
            convertAll2(Xstrings, to_strings);
            convertAll2(Xstrings2, to_strings);
            text_pane.requestFocus();
            return;
         }
      }
      else if (the_table.equals("esccodes")) {
         convertEscapeCodes(getString(), getFormatCode(from_code), getFormatCode(to_code));
         text_pane.requestFocus();
         return;
      }
      
      // Continue with normal conversions. Dauxrigu per normalaj konvertoj.
      convertAll2(from_strings, to_strings);
      text_pane.requestFocus();

   }  // end of convertAll()


   void convertAll2(String[] from_strings, String[] to_strings) {

      int number_of_conversions = from_strings.length; 
      if (to_strings.length < number_of_conversions)
            number_of_conversions = to_strings.length;

      statusStart();    // Status bar. Statustrabo.

      // Note: the first string is the name of conversion table.
      // Notu: la unua litercxeno estas la nomo de la konvert-tabelo.
      for (int i = 1; i < number_of_conversions; i++) {
         drawStatus(i, number_of_conversions);
         convertAll3(getString(), from_strings[i], to_strings[i]);
      } // for

      statusClear();

   }  // end of convertAll2()


   void convertAll3(String str, String to_find, String replacement) {

      int     find_length = to_find.length();
      int     rep_length = replacement.length();

      if (find_length > str.length()) return;
      if (to_find.length() == 0) return;
      if (replacement.length() == 0) return;

      int str_index = 0;
      int doc_index = 0;
      int adjustment = 0;    // The length of doc may change during conversion.
                                         // La longeco de doc eble sxangxigxos dum konvertado.
      int difference_in_length = rep_length - find_length;
      int count = 0;

      str_index = str.indexOf(to_find, 0);

      while (str_index >= 0) {
         doc_index = str_index + adjustment;
         text_pane.setCaretPosition(doc_index);
         text_pane.moveCaretPosition(doc_index + find_length);
         text_pane.replaceSelection(replacement);
         count++;
         adjustment = adjustment + difference_in_length;
         str_index = str.indexOf(to_find, str_index + find_length);
      }

   }  // end of convertAll3()



   // This method converts unicode escape sequences (\\u06F0) in a 
   // string to their equivalent codes.
   // Cxi tiu metodo convertas unikodajn eskap-tekstojn (\\u06F0) en 
   // signocxeno al gxiaj ekvivalentaj kodoj.

   private static String convert_slash_u(String to_convert) {

      String  converting = to_convert;
      String  front, uni, end;
      int     the_index;

      the_index = converting.indexOf("\\u");

      while (the_index != -1 && (the_index + 6 <= converting.length())) {
         front = converting.substring(0,the_index);
         uni   = convertHexUni(converting.substring(the_index+2,the_index+6));
         if (the_index+6 < converting.length()) 
                         end  = converting.substring(the_index+6);
         else end = "";
         converting = front + uni + end;
         the_index  = converting.indexOf("\\u", the_index + 1);
      }  // while

      the_index = converting.indexOf("\\U");

      while (the_index != -1 && (the_index + 6 <= converting.length())) {
         front = converting.substring(0,the_index);
         uni   = convertHexUni(converting.substring(the_index+2,the_index+6));
         if (the_index+6 < converting.length()) 
                         end   = converting.substring(the_index+6);
         else end = "";
         converting = front + uni + end;
         the_index = converting.indexOf("\\U", the_index + 1);
      }  // while
      return converting;

   }  // convert_slash_u




   int       WORD_MAX = 40;
   char[]    the_word = new char[WORD_MAX];
   int       word_start;
   int       word_length;
   int       original_length;

   ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Convert letter pairs, ch, gh etc, to accented Esperanto letters.
   // This method converts an entire word, if the resulting word is valid.
   // Validity is checked with the dictionary.
   // Konvertu literparojn, ch, gh, ktp, al supersignitaj Esperantaj literoj.
   // Cxi tiu metodo konvertas tutan vorton, se la rezulta vorto estas valida.
   // Valideco estas kontrolata per vortaro.

   //Analizo   analizo;
   EspVortaro   esp;
   VortInformoj  vi = new VortInformoj();

   private void hToUnicode(String str) {

      // Try to load the Esperanto dictionary. 
      // Provu sxargi la Esperantan vortaron. 
      if (esp == null) esp = new EspVortaro("vortaro.zip");
      //if (!analizo.vortaro_shargita) {
      //   return;
      //}

      int count = 0;

      int adjustment = 0;
      int doc_index;
      int str_length = str.length();

      statusStart();    // Status bar. Statustrabo.

      for (int i = 0; i < str_length;) {

         if (count % 20 == 0) drawStatus(i, str_length);

         while (i < str.length() && !Character.isLetter(str.charAt(i))) i++;
         word_start  = i;
         word_length = 0;
         while (i < str.length() && Character.isLetter(str.charAt(i)) &&   word_length < WORD_MAX) {
            the_word[word_length] = str.charAt(i);
            i++; word_length++;
         }

         if (word_length > 1) {
            original_length = word_length;
            //if (!analizo.kontrolu_vorton(the_word, 0, word_length)) {  
            if (!esp.sercxu(the_word, 0, word_length,vi)) {  
               // Provu konverti h-ojn kaj u-ojn al supersignoj
               if (trovu_bonan_vorton()) {
                  doc_index = word_start + adjustment;
                   text_pane.setCaretPosition(doc_index);
                   text_pane.moveCaretPosition(doc_index + original_length);
                   text_pane.replaceSelection(new String(the_word, 0, word_length));
                  // The fixed word may be shorter. Adjust index i.
                  // La gxustigita vorto eble estas malpli longa. 
                  // Gxustigu indekson.
                  adjustment = adjustment + (word_length  - original_length);
                  count++;
               }
            }
         }
      } // end of 'for'

      statusClear();

   } // hToUnicode



   ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // trovu_bonan_vorton - (Find a Good Word). This method uses the
   // Esperanto spellchecker to convert ch, sh, etc to proper accented 
   // letters.
   // trovu_bonan_vorton sxangxas hojn kaj uojn al supersignitaj literoj,
   // por provi trovi gxustan literumadon. Ekzemple, 'chirkau' farigxas
   // ^cirkau kaj poste ^cirka^u.

   boolean trovu_bonan_vorton () {

      char      litero;
      char      antauxa_litero;
      char      antauxa_min;       // minuskla
      char      converted_letter;

      for (int i = 1; i < word_length; i++) {

         litero = the_word[i];
         antauxa_litero = the_word[i - 1];
         antauxa_min    = (char)(antauxa_litero | 0x40);  // minuskligu

         if (antauxa_min == 'a' || antauxa_min == 'e') {
            if (litero == 'u') {
               the_word[i] = (char)0x16d;
               //if (analizo.kontrolu_vorton(the_word, 0, word_length)) {
               if (esp.sercxu(the_word, 0, word_length, vi)) {
                  return true;
               }
            }
            else if (litero == 'U') {
               the_word[i] = (char)0x16c;
               //if (analizo.kontrolu_vorton(the_word, 0, word_length)) {
               if (esp.sercxu(the_word, 0, word_length, vi)) {
                  return true;
               }
            }
         }
         else if (litero == 'h' || litero == 'H') {
            converted_letter = aski_al_Unikodo(antauxa_litero);
            if (converted_letter != '*') {
               the_word[i - 1] = converted_letter;
               // forigu la h-on
               word_length--;
               for (int j = i; j < word_length; j++) {
                  the_word[j] = the_word[j+1];
               }
               //if (analizo.kontrolu_vorton(the_word, 0, word_length)) {
               if (esp.sercxu(the_word, 0, word_length, vi)) {
                  return true;
               }
            }
         }
      }  // fino de 'for'

      return false;  // ne povis konverti supersignojn

   }  // fino de 'trovu_bonan_vorton





   //----------------------------------------------
   // Convert and ASCII letter to its accented equivalent,
   // or return * . (For Esperanto)
   // Konvertu aski-literon al gxia responda supersignita litero,
   // aux redonu * .
   // Ekzemple: C --> ^C

   static char[] supersignoj = {'*','*','\u0108','*','*','*','\u011c','\u0124',
                                '*','\u0134','*','*','*','*','*','*','*','*',
                                '\u015c','*','\u016c','*','*','*','*','*','*',
                                '*','*','*','*','*','*','*','\u0109','*','*',
                                '*','\u011d','\u0125','*','\u0135','*','*','*',
                                '*','*','*','*','*','\u015d','*','\u016d','*',
                                '*','*','*','*'};

   public static char aski_al_Unikodo (char litero) {
      if (litero >= 'A' && litero <= 'z') {
         return supersignoj[(int)(litero - 'A')];
      }
      return '*';
   }   // fino de aski_al_Unikodo


   boolean is_a_digit(char letter) {
      if (letter >= '0' && letter <= '9') return true;
      return false;
   }

   boolean is_a_hex_digit(char letter) {
      if (letter >= '0' && letter <= '9') return true;
      if (letter >= 'a' && letter <= 'f') return true;
      if (letter >= 'A' && letter <= 'F') return true;
      return false;
   }

   private String getString() {
      try {
         Document doc = text_pane.getDocument();
         return doc.getText(0,doc.getLength());
      } catch (BadLocationException blx) {
         System.err.println("Failure in Convert Dialog."); 
         System.err.println("Fusxo en Konvertdialogo.\n" + blx.toString());
         return "";
      }
      catch (NullPointerException npx) {
            System.err.println("Failure in Convert Dialog: Null pointer.\n");
            System.err.println("Fusxo en Konvertdialogo: Nula montrilo. \n" + npx.toString());
            return "";
      }
   }


   ///////////////////////////////////////////////////////////////////////////////////
   // Strings for converting between the x-method, h-method, the circumflex method, 
   // Latin 3 and Unicode.
   // Litercxenoj por konverti inter la x-metodo, h-metodo, cirkumfleks-metodo,
   // Latino 3 kaj Unikodo.

   public final static String[]  Xstrings
   = {"X-metodo","cx","gx","sx","ux","jx","hx","Cx","Gx","Sx","Ux","Jx","Hx",};

   public final static String[]  Xstrings2
   = {"X-metodo","cX","gX","sX","uX","jX","hX","CX","GX","SX","UX","JX","HX",};

   public final static String[]  Hstrings
   = {"H-metodo","ch","gh","sh","u","jh","hh","Ch","Gh","Sh","U","Jh","Hh",};

   public final static String[]  CIRstrings
   = {"Cirkum: ^","^c","^g","^s","^u","^j","^h","^C","^G","^S","^U","^J","^H",};

   public final static String[]  LATIN3strings 
   = {"Latin-3",
      "\u00e6","\u00f8","\u00fe","\u00fd","\u00bc","\u00b6",  
      "\u00c6","\u00d8","\u00de","\u00dd","\u00ac","\u00a6",
      "\u00a1","\u00b1","\u00a2","\u00a9","\u00b9","\u00aa",
      "\u00ba","\u00ab","\u00bb","\u00af","\u00bf","\u00c5",
      "\u00e5","\u00d5","\u00f5","\u00ff"};


   public final static String[]   UNIstrings
   = {"Unikodo",
      "\u0109","\u011d","\u015d","\u016d","\u0135","\u0125", 
      "\u0108","\u011c","\u015c","\u016c","\u0134","\u0124",
      "\u0126","\u0127","\u02d8","\u0130","\u0131","\u015e",
      "\u015f","\u011e","\u011f","\u017b","\u017c","\u010a",
      "\u010b","\u0120","\u0121","\u02d9"};


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// The following routines are used to convert between Unicode, 
// backslash-u (\\uxxxx), and html-format (&#xxxx;).
//
// La cxi-subaj routinoj estas uzataj por konverti inter Unikodo, 
// retroklino-u (\\uxxxx) kaj html-formato (&#xxxx;).



   ///////////////////////////////////////////////////////////////////////////////////////
   // Convert escape codes. This method converts between unicode, backslash u,
   // hex and decimal HTML escape formats.
   // Konvertu eskap-kodojn. Cxi tiu metodo konvertas inter unikodo, retroklina u, 
   // deksesuma kaj dekuma HTML-eskap-formatoj.

   private void convertEscapeCodes(String str, int from_format, int to_format) {

      int    escapeValue;
      String escapeString;

      int str_index = 0;
      int str_length = str.length();
      int end_index;
      int adjustment = 0;    // The length of doc may change during conversion.
                             // La longeco de doc eble sxangxigxos dum konvertado.
      int difference;

      int count = 0;
      statusStart();    // Status bar. Statustrabo.

      str_index = findEscape(str, 0, from_format);
      while (str_index >= 0) {
         if (count % 20 == 0) drawStatus(str_index, str_length);
         end_index = endIndex(str, str_index, from_format);
         escapeValue = getIntValue(str, str_index, end_index, from_format);
         text_pane.setCaretPosition(str_index + adjustment);
         text_pane.moveCaretPosition(end_index + adjustment);
         escapeString = makeEscapeString(escapeValue, to_format);
         text_pane.replaceSelection(escapeString);
         count++;
         adjustment = adjustment - (end_index - str_index) + escapeString.length();
         str_index = findEscape(str, str_index + 1, from_format);
      }

      statusClear();

   } // convertEscapeCodes


   static final int  UNICODE   = 0;
   static final int  BACKSLASH = 1;
   static final int  DECHTML   = 2;    //  &#284;
   static final int  HEXHTML   = 3;    //  &#x011c;

   private int getFormatCode(char c) {
      if (c == 'u') return UNICODE;
      if (c == 'b') return BACKSLASH;
      if (c == 'd') return DECHTML;
      if (c == 'h') return HEXHTML;
      return 0;
   }


   /////////////////////////////////////////////////////////////////////////////////////////
   // Find escape code \\unnnn &#nnn; etc.
   // Trovu eskap-kodon, \\unnnn &#nnn; ktp.

   private int findEscape(String str, int index, int format) {
      if (format == UNICODE) {
         return findGT128(str, index);
      }
      else if (format == BACKSLASH) {
         return findBackslashU(str, index);
      } 
      else if (format == DECHTML) {
         return findHTMLCodes(str, index);
      } 
      else if (format == HEXHTML) {
         return findHexHTMLCodes(str, index);
      }
      return -1;
   }

   /////////////////////////////////////////////////////////////
   // Find the index which is just past the escape code.
   // Trovu la indekson kiu estas unu preter la eskap-kodon.
   private int endIndex(String str, int start, int format) {
      if (format == UNICODE) {
         return start + 1;
      }
      else if (format == BACKSLASH) {
         return start + 6;
      } 
      else {  // HTML dec, hex
         return str.indexOf(";", start) + 1;
      } 
   }


   /////////////////////////////////////////////////////////////
   // Find the integer value of an escape code.
   // Trovu la entjeran valoron de eskap-kodo.
   private int getIntValue(String str, int start, int end, int format) {
      if (format == UNICODE) {
         return (int)str.charAt(start);
      }
      try {
         if (format == BACKSLASH) {
            return (int)Integer.parseInt(str.substring(start+2, end),16);
         } 
         else if (format == DECHTML) {
            return (int)Integer.parseInt(str.substring(start+2, end - 1));
         } 
         else if (format == HEXHTML) {
            return (int)Integer.parseInt(str.substring(start+3, end - 1),16);
         }
      } catch (NumberFormatException nfx) { }
      return 0;
   }


   /////////////////////////////////////////////////////////////
   // makeEscapeString
   // Make an escape code string.
   // Kreu cxenon por eskap-kodo.
   char[] the_unicode_char = new char[1];
   String estr;
   private String makeEscapeString(int val, int format) {
      if (format == UNICODE) {
         the_unicode_char[0] = (char)val;
         return new String(the_unicode_char);
      }
      else if (format == BACKSLASH) {
         estr = "0000" + Integer.toHexString(val);
         return "\\u" + estr.substring(estr.length() - 4);
      } 
      else if (format == DECHTML) {
         return "&#" + Integer.toString(val) + ";";
      } 
      else if (format == HEXHTML) {
         estr = "0000" + Integer.toHexString(val);
         return "&#x" + estr.substring(estr.length() - 4) + ";";
      }
      return "???";
   }


   /////////////////////////////////////////////////////////////////////////////////////////
   // Find letters which have a code of 128 or higher.
   // Trovu literojn kiuj havas kodon de 128 aux pli.

   private int findGT128(String str, int index) {
      int   theChar;
      for (int i = index; i < str.length(); i++) {
         theChar = (int)(str.charAt(i));
         if (theChar >= 128) return i;
      }
      return -1;
   }

   ////////////////////////////////////////////////////////////////////////////////////////
   // Find \\uxxxx  (or \\Uxxxx)
   // Trovu \\uxxxx (aux \\Uxxxx)

   private int findBackslashU(String str, int index) {
      char nextChar;
      index = str.indexOf("\\", index);
      while (index >= 0 && index <= (str.length() - 6)) {
         nextChar = str.charAt(index+1);
         if ((nextChar == 'u' || nextChar == 'U') &&
             is_a_hex_digit(str.charAt(index+2)) &&
             is_a_hex_digit(str.charAt(index+3)) &&
             is_a_hex_digit(str.charAt(index+4)) &&
             is_a_hex_digit(str.charAt(index+5))) return index;
         index = str.indexOf("\\",index + 2);
      }
      return -1;
   }

   ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Find HTML codes (&#nn;)
   // Trovu HTML-kodojn (&#nn;)

   private int findHTMLCodes(String str, int index) {
      index = str.indexOf("&#", index);
      int index2 = str.indexOf(";", index);
      int diff = index2 - index;
      while (index >= 0 && (diff > 2) && (diff <= 7)) {
         if (is_a_digit(str.charAt(index+2))) return index;
         index = index+3;
         index = str.indexOf("&#", index);
         index2 = str.indexOf(";", index);
      }
      return -1;
   }

   ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   // Find hex HTML codes (&#xnn;)
   // Trovu hex HTML-kodojn (&#xnn;)

   private int findHexHTMLCodes(String str, int index) {
      char char1;
      index = str.indexOf("&#", index);
      int index2 = str.indexOf(";", index);
      int diff = index2 - index;
      while (index >= 0 && (diff > 3) && (diff <= 7)) {
         char1 = str.charAt(index+2);
         if ((char1 == 'x' || char1 == 'X') && is_a_hex_digit(str.charAt(index+3))) return index;
         index = index+4;
         index = str.indexOf("&#", index);
         index2 = str.indexOf(";", index);
      }
      return -1;
   }



   // Convert a hexadecimal string ("7fd1") to a single unicode letter.
   // Konvertu deksesuman cxenon ("7fd1") al unu unikoda litero.

   private static String convertHexUni(String theNumber) {
      char[] the_unicode_char = new char[1];
      try {
         the_unicode_char[0] = (char)Integer.parseInt(theNumber,16);
      } catch (NumberFormatException nfe) {
         return theNumber;
      }
      return new String(the_unicode_char);
   }

   // Convert a decimal string ("47382") to a single unicode letter.
   // Konvertu deksesuman cxenon ("47382") al unu unikoda litero.

   private static String convertDecUni(String theNumber) {
      char[] the_unicode_char = new char[1];
      try {
         the_unicode_char[0] = (char)Integer.parseInt(theNumber);
      } catch (NumberFormatException nfe) {
         return theNumber;
      }
      return new String(the_unicode_char);
   }


   // Convert a Unicode character to a hex value, String format.
   // Konvertu Unikodan signon al deksesuma numero, String formato.
   //private static String convertUniHex(char uniChar) {
   //   String theNumber = "0000" + Integer.toHexString((int)uniChar);
   //   return theNumber.substring(theNumber.length() - 4);
   //}

   // Convert a Unicode character to a decimal value, String format.
   // Konvertu Unikodan signon al dekuma numero, String formato.
   //private static String convertUniDec(char uniChar) {
   //   return Integer.toString((int)uniChar);
   //}


   private void statusStart() {
      status_bar_g = status_bar.getGraphics();
      status_bar_length = status_bar.getWidth();
      statusClear();
      status_bar_g.setColor(Color.blue);
   }

   private void drawStatus(int ind, int total) {
      float  percent = (float)ind / (float)total;
      int length = (int)(percent * status_bar_length);
      status_bar_g.fillRect(0, 0, length, 10);
   }

   private void statusClear() {
      status_bar_g.clearRect(0, 0, status_bar_length, 10);
      status_bar.repaint();
   }


}  // ConvertDialog




