/**
 * EngSpell  - This class checks English spelling.
 * Cxi tiu klaso kontrolas anglan literumadon.
 *
 * @version 1.0, 2004/08/18
 * @author Klivo
 * 
 */

class EngSpell extends EngDictFlags {

   private  LoadDictionary loader;
   public   boolean  loader_OK = false;
   public   boolean  loaded = false;

   private  char[] dictionaryData;

   private  EngDict      english_dictionary;
   private  EngDict      user_dictionary;
 
   char[]  theWordLowerCase = new char[MAX_LENGTH];

   boolean   capital;  // Indicates that the first letter was capitalized.

   public EngSpell (String zipFileName) {

      loader = new LoadDictionary(zipFileName);
      if (loader != null) {
         loader_OK = true;
         english_dictionary  = new EngDict(loader.getDictionary("english"));
         user_dictionary     = new EngDict(loader.getDictionary("userdict"));
      }
      loaded = english_dictionary.loaded;

   }



   /**
    * check - Checks the spelling of an English word.
    * Kontrolas literumadon de angla vorto
    * @param the word to check / la kontrolota vorto
    * @param start index of word / komenc-indekso de vorto
    * @param end index of word / fin-indekso de vorto
    * @return 0 = unknown, 1 = OK, 2 = OK but check capitalization
    *                0 = nekonata, 1 = bona, 2 = bona sed kontrolu majusklecon
    */

   public int check(char[] theWord, int start, int end) {
      if (!loader_OK) return 0;
      int result = check(english_dictionary, theWord, start, end);
      if (result == 0) {
         result = check(user_dictionary, theWord, start, end);
      }
      return result;
   }





   /**
    * check - Checks the spelling of an English word.
    * Kontrolas literumadon de angla vorto
    * @param the dictionary to search / la kontrolota vortaro
    * @param the word to check / la kontrolota vorto
    * @param start index of word / komenc-indekso de vorto
    * @param end index of word / fin-indekso de vorto
    * @return 0 = unknown, 1 = OK, 2 = OK but check capitalization
    *                0 = nekonata, 1 = bona, 2 = bona sed kontrolu majusklecon
    */
   private int check(EngDict dictionary, char[] theWord, int start, int end) {

      if (!dictionary.loaded) return 0;

      char[]        flags = new char[1];    // To get suffix-prefix info from the dictionary.
      boolean   startsWithCapital = false;

      int wordLength = end - start;

      if (wordLength < 1 || wordLength > MAX_LENGTH) return 1;
      if (wordLength == 1) return 1;

      if (Character.isUpperCase(theWord[start])) startsWithCapital = true;

      // Make the word lower case. // Nun minuskligu la vorton.
      for (int i = 0; i < wordLength; i++) {
         theWordLowerCase[i] = Character.toLowerCase(theWord[start+i]);
      }

      if (dictionary.search(theWordLowerCase, 0, wordLength, flags)) {
         // Check capitalization.
         if ((flags[0] & c_flag) != 0 && !startsWithCapital) return 2;
         return  1;
      }
      else {
         if (removeSuffixAndCheck(dictionary, theWordLowerCase, 0, wordLength, flags)) {
            // Check capitalization.
            if ((flags[0] & c_flag) != 0 && !startsWithCapital) return 2;
            return  1;
         }
         else if (removePrefixAndCheck(dictionary, theWordLowerCase, 0, wordLength, flags)) {
            // Check capitalization.
            if ((flags[0] & c_flag) != 0 && !startsWithCapital) return 2;
            return  1;
         }
      }

      return 0;   // not found

   }  // end of "check"




   /**
    * removeSuffixAndCheck - Remove a suffix (s, es, d, ed, etc.) and search in the dictionary.
    * Eltondu sufikson (s, es, d, ed, ktp.) kaj sercxu en la vortaro.
    * @param the dictionary to search / la kontrolota vortaro
    * @param the word to check, lower case / la kontrolota vorto, minuskla
    * @param start index of word / komenc-indekso de vorto
    * @param end index of word / fin-indekso de vorto
    * @param flags - suffix flags / sufiksaj flagoj
    */

   private boolean removeSuffixAndCheck(EngDict dictionary, char[] theWordLC, int start, int end, char[] flags) {

      int       len = end - start;

      char   last                 = 0;
      char   second_last  = 0;
      char   third_last       = 0;
      char   fourth_last     = 0;

      if (len > 1) last                 = theWordLC[end-1];
      if (len > 2) second_last  = theWordLC[end-2];
      if (len > 3) third_last       = theWordLC[end-3];
      if (len > 4) fourth_last     = theWordLC[end-4];

      if (last == 's') {
         if (dictionary.search(theWordLC, start, end -1, flags) && ((flags[0] & s_flag) != 0)) {
            return true;
         }
         else if (second_last == 'e') {  // es
            if (dictionary.search(theWordLC, start, end - 2, flags) &&  ((flags[0] & es_flag) != 0)) {
                return true;
            }
         }
         else if (second_last == '\'') {  // 's
            if (dictionary.search(theWordLC, start, end - 2, flags)) return true;
         }
         else if (third_last == 'e' && second_last == 'r') {  // ers
            if (dictionary.search(theWordLC, start, end - 3, flags) &&  ((flags[0] & ers_flag) != 0)) {
                return true;
            }
         }
         else if (fourth_last == 'i' && third_last == 'n' && second_last == 'g') {
            if (dictionary.search(theWordLC, start, end - 4, flags) &&  ((flags[0] & ings_flag) != 0)) {
                return true;
            }
         }
      }
      else if (last == 'd') {
         if (dictionary.search(theWordLC, start, end - 1, flags) &&  ((flags[0] & d_flag) != 0)) {
            return true;
         }
         else if (second_last == 'e') {  // ed
            if (dictionary.search(theWordLC, start, end - 2, flags) &&  ((flags[0] & ed_flag) != 0)) {
               return true;
            }
         }
      }
      else if (third_last == 'i' && second_last == 'n' && last == 'g') {
         if (dictionary.search(theWordLC, start, end - 3, flags) &&  ((flags[0] & ing_flag) != 0)) {
            return true;
         }
      }
      else if (second_last == 'l' && last == 'y') {
         if (dictionary.search(theWordLC, start, end - 2, flags) &&  ((flags[0] & ly_flag) != 0)) {
            return true;
         }
      }
      else if (second_last == 'e' && last == 'r') {
         if (dictionary.search(theWordLC, start, end - 2, flags) &&  ((flags[0] & er_flag) != 0)) {
            return true;
         }
      }
      else if (third_last == 'e' && second_last == 's' && last == 't') {
         if (dictionary.search(theWordLC, start, end - 3, flags) &&  ((flags[0] & est_flag) != 0)) {
            return true;
         }
      }
      else if (fourth_last == 'a' && third_last == 'b' && second_last == 'l' && last == 'e') {
         if (dictionary.search(theWordLC, start, end - 4, flags) &&  ((flags[0] & able_flag) != 0)) {
            return true;
         }
      }
      return false;

   } // end of "removeSuffixAndCheck"




   /**
    * removePrefixAndCheck - Remove a prefix (un, dis, mis) and search in the dictionary.
    * Eltondu prefikson (un, dis, mis) kaj sercxu en la vortaro.
    * @param the dictionary to search / la kontrolota vortaro
    * @param the word to check, lower case / la kontrolota vorto, minuskla
    * @param start index of word / komenc-indekso de vorto
    * @param end index of word / fin-indekso de vorto
    * @param flags - prefix flags / prefiksaj flagoj
    */

   private boolean removePrefixAndCheck(EngDict dictionary, char[] theWordLC, int start, int end, char[] flags) {

      int       len = end - start;

      char   first  = 0;
      char   second = 0;
      char   third  = 0;

      if (len > 4) {
         first          = theWordLC[0];
         second   = theWordLC[1];
         third        = theWordLC[2];
      }
      else return false;

      if (first == 'u' && second == 'n') {
         if (dictionary.search(theWordLC, start + 2, end, flags) &&  ((flags[0] & un_flag) != 0)) {
             return true;
         }
         else if (removeSuffixAndCheck(dictionary, theWordLC, start + 2, end, flags) && ((flags[0] & un_flag) != 0)) {
            return true;
         }
      }
      else if (first == 'd' && second == 'i' && third == 's') {
         if (dictionary.search(theWordLC, start + 3, end, flags) &&  ((flags[0] & dis_flag) != 0)) {
             return true;
         }
         else if (removeSuffixAndCheck(dictionary, theWordLC, start + 3, end, flags) && ((flags[0] & dis_flag) != 0)) {
            return true;
         }
      }
      else if (first == 'm' && second == 'i' && third == 's') {
         if (dictionary.search(theWordLC, start + 3, end, flags) &&  ((flags[0] & mis_flag) != 0)) {
             return true;
         }
         else if (removeSuffixAndCheck(dictionary, theWordLC, start + 3, end, flags) && ((flags[0] & mis_flag) != 0)) {
            return true;
         }
      }

      return false;

   }  // end of "removePrefixAndCheck"




}  // end of EngSpell

