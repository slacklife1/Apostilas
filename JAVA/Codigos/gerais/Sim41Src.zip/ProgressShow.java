/*
 * Created on 17 ��� 2005
 * This class creates ProgressShow objects that actually do nothing than represent a progress bar...
 * Progresindikilo
 */

/**
 * @author Alex Haros
 * 
 *
 *  
 * */


import javax.swing.*;

public class ProgressShow extends JFrame {

   static JProgressBar current;
   JLabel out;
   Thread runner;
   private static int num = 0;
   static JPanel pane = new JPanel();
   
   
   public ProgressShow(int numb) {
      
      super("Simredo 4.1");
      
      setSize(200,80);
      out = new JLabel("Simredo 4.1 is Loading...");
      current = new JProgressBar(0,numb);
      current.setValue(num);
      current.setStringPainted(true);
      pane.add(current);
      pane.add(out);
      setContentPane(pane);
      setBounds(400,400, 200,80);
      
      setVisible(true);
      setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
   }

   public  void stop() { setVisible(false); }
 
   public  void iterate(int numm) {

         current.setValue(numm);
         try {
            Thread.sleep(1000);
            //current.setValue(num);
         } catch (Exception e ) { 
           // TODO Auto-generated method stub
         }
   }

}
