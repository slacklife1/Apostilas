/*
 * SaveConvertDialog - This dialogue gives the user a list of file formats 
 * to choose from when saving a file to disk.
 *
 * KonservoKonvertoDialogo - Cxi tiu dialogo montras al la uzanto liston de 
 * dosiero-formatoj kiujn li povas elekti por konservi la dokumenton sur disko.
 *
 * Cleve Lendon (Klivo)     1999/02/22
 * indriko@yahoo.com
 * http://purl.oclc.org/net/klivo/
 *
 */

/*
 * Changes for 3.2  Sxangxoj por 3.2    1999/08
 *
 * Calculate size of dialogue.
 * Kalkulu grandecon de dialogujo.
 *
 */

/*
 * Changes for 3.3  Sxangxoj por 3.3    2002/11
 *
 * Make smaller and change colour.
 * Faru pli malgranda kaj sxangxu koloron.
 *
 */

/*
 * Changes for 4.0  Sxangxoj por 4.0    2004/06
 *
 * Use only one button, 'OK'.
 * Uzu nur unu butonon, 'Bone'.
 *
 */


import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class SaveConvertDialog extends JDialog implements ActionListener {


   JFrame  parent;

   private final static int d_width  = 330;   // dialog width   -  dialoga largxeco
   private final static int d_height = 170;   // dialog height  -  dialoga alteco


   String[]     encoding_names;          // Names of the encodings, eg. SJIS, UTF8
                                         // Nomoj de la kodaroj, ekz. SJIS, UTF8

   String[]     encoding_descriptions;   // Descriptions on the encodings, eg. Shift-JIS Japanese.
                                         // Priskriboj de la kodaroj, ekz. Shift-JIS Japanese.
   int          number_of_encodings;

   Hashtable    long_to_short;           // Associate long description to short internal name.
                                         // Asociigu longan priskribon al mallonga interna nomo.

   Hashtable    short_to_long;           // Associate short internal name to long description.
                                         // Asociigu mallongan internan nomon al longa priskribo.

   private JLabel         line1;
   private JLabel         line2;
   private JButton        ok_button;

   private JComboBox      format;          // Listo de dosieroformatoj.

   String decision = "ISO8859_1";    // ISO8859_1 - Latin 1. Same as no conversion.
                                     // Egalas al neniu konverto.

   Color blue = new Color(0x7777ff);   // blua
   Color black  = new Color(0x000000);   // nigra 

   private JPanel  background;

   public SaveConvertDialog (JFrame owner, String[] labels, String encodings) {

      super(owner, true);   // Modal dialogue. Deviga dialogo.

      parent = owner;

      setSize(d_width, d_height);

      Container cp = getContentPane();

      background = new JPanel(new GridBagLayout());
      background.setBackground(blue);

      //cp.setLayout(new GridBagLayout());

      String[] tokens       = SimCon.tokenize(encodings);
      number_of_encodings   = tokens.length / 2; 
      encoding_names        = new String[number_of_encodings];
      encoding_descriptions = new String[number_of_encodings];

      int i,j;
      for (i = 0, j = 0; j < tokens.length; i++, j = j + 2) {
         encoding_names[i]        = tokens[j];
         encoding_descriptions[i] = tokens[j+1];
      }

      long_to_short = new Hashtable();
      for (i = 0; i < number_of_encodings; i++) {
         long_to_short.put(encoding_descriptions[i], encoding_names[i]);
      }

      short_to_long = new Hashtable();
      for (i = 0; i < number_of_encodings; i++) {
         short_to_long.put(encoding_names[i], encoding_descriptions[i]);
      }

      // Create and fill the format list.  Kreu kaj plenigu la formatliston.
      format = new JComboBox();
      for (i = 0; i < number_of_encodings; i++) {
         format.addItem(encoding_descriptions[i]);
      }

      setBackground(blue);

      line1           = new JLabel(labels[0]);
      line1.setForeground(black);
      line2           = new JLabel(labels[1]);
      line2.setForeground(black);
      ok_button  = new JButton(labels[2]);

      ok_button.setActionCommand("ok");
      ok_button.addActionListener(this);

      GridBagConstraints gbc = new GridBagConstraints();
      gbc.insets = new Insets(5,10,5,10);
      gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 1;
      background.add(line1, gbc);
      gbc.anchor = GridBagConstraints.EAST;
      gbc.gridx = 1;
      background.add(ok_button,gbc);

      gbc.anchor = GridBagConstraints.WEST;
      gbc.gridx = 0; gbc.gridy = 1;
      gbc.gridwidth = 2;
      background.add(line2, gbc);

      gbc.gridx = 0; gbc.gridy = 2;
      gbc.gridwidth = 2; gbc.fill = GridBagConstraints.BOTH;
      background.add(format, gbc);

      cp.add(background);

   }  // end of constructor


   public void actionPerformed(ActionEvent e) {
      String command = e.getActionCommand();
      if (command.equals("ok")) {
         decision = (String)long_to_short.get((String)format.getSelectedItem());
         setVisible(false);
         return;
      }
   }  // actionPerformed


   /*
    * getDecision - Get the encoding name to convert from.
    * getDecision - Akiru la kodaran nomo por elkonverto.
    */
   public String getDecision() {
      return decision;
   }  // getDecision


   /*
    * showIt - Display this dialog. Set format box to the default value.
    * showIt - Montru cxi tiun dialogon. Metu defauxltan formaton en la selektolisto.
    */
   public void showIt(String default_format) {


      if (default_format != null) {
         format.setSelectedItem(short_to_long.get(default_format));
      }

      // Position the dialog in the center of the main frame.
      // Metu la dialogon en la mezon de la cxefa kadro.

      int new_width = d_width;
      int new_height = d_height;

      Rectangle p_rect = parent.getBounds();
      Rectangle d_rect = new Rectangle(p_rect.x + Math.abs(p_rect.width - new_width)/2,
                                       p_rect.y + Math.abs(p_rect.height - new_height)/2 + 20,
                                       new_width,new_height);
      setBounds(d_rect);

      setVisible(true);
      validate();

   }  // showIt

}  // SaveConvertDialog


