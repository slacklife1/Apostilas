/**
 * EngDictFlags  - Some flags common to EngDict and EngSpell
 * Flagoj komunaj al EngDict kaj EngSpell (klasoj de angla vortaro).
 *
 * @version 1.0, 2004/08/18
 * @author Klivo
 * 
 */

public class EngDictFlags {

   public EngDictFlags () { }

   public static final int MAX_LENGTH = 40;    // Maximum length of a word.  Maksimuma vortlongeco.

   public  int flags;

   // Masks for suffix and prefix flags.   /   Maskoj por sufiksoj kaj prefiksoj
   public final static int  able_flag = 1;
   public final static int  c_flag = 2;             // capitalized word  /  vorto kun majusklo
   public final static int  d_flag = 4;
   public final static int  dis_flag = 8;
   public final static int  ed_flag = 16;
   public final static int  er_flag = 32;
   public final static int  ers_flag = 64;
   public final static int  es_flag = 128;
   public final static int  est_flag = 256;
   public final static int  ing_flag = 512;
   public final static int  ings_flag = 1024;
   public final static int  ly_flag = 2048;
   public final static int  mis_flag = 4096;
   public final static int  s_flag = 8192;
   public final static int  un_flag = 16384;

   // Must be in alphabetical order.   /   Devas estis en alfabeta ordo.
   public final static String[] suffixesAndPrefixes = {
         "able","c","d","dis","ed","er","ers","es","est","ing","ings","ly","mis","s","un"
   };


   /**
    * setFlag - Set flag for corresponding suffix or prefix.
    * Starigas flagon por responda sufikso aux prefikso.
    * @param flag - target integer, contains previously set flags
    * @param suffix - the suffix or prefix (un, mis, ing ed)
    */
   public static int setFlag(int flag, String suffix) {

      int  bottom, top;
      int  middle = 0;
      int  compareResult;
      boolean  found = false;

      bottom = 0;
      top = suffixesAndPrefixes.length - 1;

      while (bottom <= top) {
         middle = (top + bottom)/2;
         compareResult = suffix.compareTo(suffixesAndPrefixes[middle]);
         if (compareResult < 0)
            top = middle -1;
         else if (compareResult > 0)
            bottom = middle + 1;
         else {
            found = true;
            break;
         }
      }

      if (found) {
         return flag | (1 << middle);
      }
      else return flag;

   }  // fino de setFlag


}  // end of "EngDictFlags"




