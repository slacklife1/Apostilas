/*
 * FileInformation - This class is used for holding and transfering information 
 * about files, such as the encoding. The information is collected by the class
 * Detect.
 *
 * (DosieroInformoj) - Cxi tiu klaso estas uzata por teni kaj transferi informojn
 * pri dosieroj, kiel ekzemple la kodigon. La informoj estas kolektataj per la
 * klaso Detect (Detektu).
 *
 * Cleve Lendon (Klivo)     2004/05/05
 * indriko@yahoo.com
 * http://purl.oclc.org/net/klivo/
 */

import java.net.*;

public class FileInformation  {

   public FileInformation () {}

   public String     fileName;

   public static final int CANT_LOAD   = -1;  // ne povas sxargi
   public static final int UNKNOWN     = 0;
   public static final int KNOWN       = 1;

   public int        status = UNKNOWN;
   public String     encoding;

}  // FileInformation

