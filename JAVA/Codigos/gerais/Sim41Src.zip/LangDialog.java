/*
 * LangDialog - To select the language, English Esperanto, French, Hindi.
 * LangDialog - Por selekti la lingvon: angla, Esperanto, franca, hinda.
 * 2004/07
 *
 * 2005/08  - Greek added (Alexandros Charos)
 *          - La greka aldonita (Alexandros Charos)
 *
 * Cleve Lendon (Klivo)
 * indriko@yahoo.com
 * http://purl.oclc.org/net/klivo/
 *
 */

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;

public class LangDialog extends JDialog implements ActionListener {

   JFrame  parent;
   
   private final static int d_width  = 135;   // dialog width   -  dialoga largxeco
   private final static int d_height = 130;   // dialog height  -  dialoga alteco

   private JComboBox    select_language = new JComboBox();    // selektu lingvon

   private String[]    languages  = {"English","Esperanto","Fran\u00e7ais","Greek", "Hindi"};

   JButton       ok_button;

   JLabel      top_label;

   String language = "English";

   File simlang;
 
   public LangDialog (JFrame owner, File simlang, String current_language) {

      super(owner, "  Simredo", true);   // Modal dialog. Deviga dialogo.

      parent = owner;
      this.simlang = simlang;

      setSize(d_width, d_height);
      Container cp = getContentPane();
      cp.setLayout(new GridBagLayout());

      ok_button = new JButton("OK");
      ok_button.setActionCommand("ok");
      ok_button.addActionListener(this);

      for (int i = 0; i < languages.length; i++) {
         select_language.addItem(languages[i]);
      }

      select_language.setActionCommand("select-language");
      select_language.addActionListener(this);

      // Arrange components. Arangxu butonojn.
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.anchor = GridBagConstraints.CENTER;
      gbc.insets = new Insets(5,10,5,10);
      gbc.gridx = 0;  gbc.gridy = 0;
      cp.add(select_language, gbc);
      gbc.gridy = 1;
      cp.add(ok_button,gbc);

      if (current_language.startsWith("eng")) {
         select_language.setSelectedItem("English");
      }
      else if (current_language.startsWith("esper")) {
         select_language.setSelectedItem("Esperanto");
      }
      else if (current_language.startsWith("fran")) {
         select_language.setSelectedItem("Fran\u00e7ais");
      }
      else if (current_language.startsWith("hin")) {
         select_language.setSelectedItem("Hindi");
      }
      else if (current_language.startsWith("gr")) {
        select_language.setSelectedItem("Greek");
      }

      showIt();

   }  // end of constructor


   public void actionPerformed(ActionEvent e) {

      String command = e.getActionCommand();

      if (command.equals("ok")) {
         try {
            RandomAccessFile outfile = new RandomAccessFile(simlang,"rw");
            outfile.writeBytes(language + "\r\n");
            outfile.close();
         } catch (IOException iox) {    }
         setVisible(false);
         return;
      }

      if (command.equals("select-language")) {
         language = (String)select_language.getSelectedItem();
      }

   }  // actionPerformed


   /*
    * showIt - Display this dialog.
    * showIt - Montru cxi tiun dialogon.
    */
   public void showIt() {

      Rectangle d_rect = 
           new Rectangle(150, 180, d_width, d_height);
      setBounds(d_rect);

      setVisible(true);
      validate();

   }  // showIt

   /*
    * getLanguage - returns the chosen language.
    * getLanguage - redonas la elektitan lingvon.
    */

   String getLanguage() {
      return language.toLowerCase();
   }


}  // LangDialog

