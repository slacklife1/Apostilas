/**
 * EspVortaro - Esperanta Vortaro
 * Cxi tiu klaso sercxas kaj analizas Esperantajn vortojn, redonante
 * informojn pri literumado, dividado de radikoj, kaj gramatika funkcio.
 *
 * @version 1.0, 2004/03/08
 * @author Klivo
 * 
 */


class EspVortaro extends VortKonstantoj {

   SxarguVortarojn    sxarguVortarojn;

   Vortaro                  grandaVortaro;
   Vortaro                  malgrandaVortaro;
   Vortaro                  suplementaVortaro;

   public boolean           havasVortarojn = false;        // granda kaj malgranda
   boolean                  havasSuplementanVortaron = false;

   char[]  minuskloj    = new char[50];
   char[]  senstreketoj = new char[50];   // dis-sendi -> dissendi

   /////////////////////////////////////////////////////////////
   // Por analizi la validecon de kunmetita vorto, oni dividas gxin 
   // lauxradike. Cxisube estas matrico kaj indekso por subteni radikan 
   // analizon. Oni konsciu, ke elemento en la matrico 'radiko' 
   // povas enhavi informojn pri radiko aux kunmetajxo. Ekzemple, 
   // la vorto 'militkrimtribunalo' konsistas de la radikoj 'milit', 
   // 'krim' kaj 'tribunal'. Sed la vortanaliza algoritmo trovos 
   // la kunmetajxon 'militkrim' en la vortaro antaux ol trovi 
   // 'milit'. Tiel, la unua elemento en la matrico 'radiko' estos 
   // 'militkrim' (kun dividpozicio inter 'milit' kaj 'krim').

   int        maksNombroDaRadikoj = 9;
   VortInformoj[]  radiko = new VortInformoj[maksNombroDaRadikoj+1];
   int        nombroDaRadikoj;
   int        finoDeVorto;


   public EspVortaro(String zipdosiero) {

      sxarguVortarojn = new SxarguVortarojn(zipdosiero);

      if (sxarguVortarojn != null) {
         grandaVortaro     
            = new Vortaro(sxarguVortarojn.akiruVortaron("granda"));
         malgrandaVortaro  
            = new Vortaro(sxarguVortarojn.akiruVortaron("malgranda"));
         suplementaVortaro  
            = new Vortaro(sxarguVortarojn.akiruVortaron("suplemento"));

      }
      else return;

      if (grandaVortaro.uzebla && malgrandaVortaro.uzebla) havasVortarojn = true;
      if (suplementaVortaro.uzebla) havasSuplementanVortaron = true;

      for (int i = 0; i < maksNombroDaRadikoj; i++) {
         radiko[i] = new VortInformoj();
      }

   }

   /**
    * sercxu - Por sercxi kaj analizi Esperantajn vortojn. 
    *
    * Unue, la metodo sercxas la malgrandan vortaron, kiu enhavas cxefe 
    * senfinajxajn vortojn kaj pronomojn (ke, dum, mi/n, neniu/jn). Se
    * gxi ne trovas la vorton en tiu vortaro, gxi fortondas gramatikan 
    * finajxon kaj sercxas en la granda vortaro. Ekzemple, se la vorto
    * estus 'forflugis', la metodo sercxus kaj trovus 'forflug' en la
    * granda vortaro. Kiam la unua sercxo en la granda vortaro ne trovas
    * sercxatan vorton, la metodo provas fortondi sufikson kaj sercxi
    * denove. Ekzemple, se la vorto estus 'forflugante', la sercxmetodo 
    * ne trovus 'forflugant' en la vortaro. Gxi eltondus 'ant' kaj sercxus 
    * 'forflug'. 'forflug' estas en la vortaro, kun flago kiu indikas ke 
    * aktivaj participaj finajxoj estas validaj. Tiel la programo agnoskus 
    * 'forflugant' kiel validan vorton. Kiam cxi tia sercxo ne trovas vorton,
    * la sercxmetodo provas analizi la vorton kiel kunmetajxon. Gxi dividas
    * la vorton je pecoj (radikoj), kaj sercxas la vortpecojn en la vortaro. 
    * Post dispecigo de la vorto, la sercxmetodo kontrolas cxu cxiu peco
    * estas valida en gxia pozicio. Ekzemple, se la sercxmetodo analizus 
    * la vorton 'mastr.ul', gxi malagnoskus la vorton, cxar oni kutime ne
    * metas la radikon 'ul' kun radiko kiu jam signifas 'PERSONO'-n. Sed
    * la vorto 'mastr.in' estus valida, cxar oni ja aldonas 'in' al radiko
    * kiu signifas 'PERSONO'-n.
    *
    * @param la_vorto - Signocxeno en unikoda formato.
    * @param kom - Komenca indekso de vorto en 'la_vorto'.
    * @param fin - Fina indekso (pozicio de lasta litero + 1).
    * @param vortinformoj (vi)- Por redoni informojn pri dividado 
    * de radikoj gramatika funkcio, majuskleco ktp.
    * @return Redonas 'vera' se al metodo sukcesis trovi aux 
    * analizi la vorton.
    */

   public boolean sercxu(char[] la_vorto, int kom, int fin, VortInformoj vi) {

      if (!havasVortarojn) {
         vi.sercxrezulto = NETROVITA;
         return false;
      }

      char char1;

      int  longeco = fin - kom;

      vi.transitiva = false;
      vi.plurala     = false;
      vi.akuzativa = false;

      vi.majuskleco = 0;
      vi.finajxolongeco = 0;
      vi.nombroDaDividpozicioj = 0;

      vi.sercxrezulto = NETROVITA;

      // perAnalizo indikas ke la programo agnoskis la vorton kiel
      // kunmetajxon de du aux pli da elementoj el la vortaro. Unue,
      // supozu ke la vorto troveblas sen analizo de elementoj.
      // (Tio estas, la tuta vorto aux radiko trovigxas en la vortaro.)
      vi.perAnalizo = false;

      char[]  informoj1    = new char[1];  // por teni informojn el malgranda vortaro
      char[]  informoj2    = new char[2];  // por teni informojn el suplementa vortaro

      // Ne sercxu la vortaron por individuaj literoj.
      if (longeco < 2) {
         return false;
      }

      if (longeco > minuskloj.length) {
         return false; // vorto tro longa
      }

      // Determinu majusklecon de vorto, por kompari kun tiu en la vortaro.
      // Ekz: kanada -> 0, Kanado -> 1, KEA -> 2
      if (Character.isLowerCase(la_vorto[kom])) vi.majuskleco = 0;
      else if (Character.isLowerCase(la_vorto[kom+1])) vi.majuskleco = 1;
      else vi.majuskleco = 2;

      // Nun minuskligu la vorton.
      for (int i = 0; i < longeco; i++) {
         minuskloj[i] = Character.toLowerCase(la_vorto[kom+i]);
      }


      // Sercxu malgrandan vortaron unue (pronomoj kaj senfinajxaj vortoj).

      if (malgrandaVortaro.sercxu(minuskloj, 0, longeco, informoj1)) {
         akiruVortInformojn(informoj1, vi, (byte)0, 0);
         vi.sercxrezulto = TROVITA;
         vi.vortaro = MALGRANDA;
         // Kolektu gramatikajn informojn.
         if (vi.finajxolongeco >= 1) {
            if (minuskloj[longeco-1] == 'j') {
               vi.plurala   = true;
            }
            else if (minuskloj[longeco-1] == 'n') {
               vi.akuzativa = true;
               if (minuskloj[longeco-2] == 'j') {
                  vi.plurala   = true;
               }
            }
         }
         return true;
      }

      if (havasSuplementanVortaron) {
         if (suplementaVortaro.sercxu(minuskloj, 0, longeco, informoj2)) {
            if ((informoj2[1] & SEN_GF) != 0) {
               akiruVortInformojn(informoj2, vi, (byte)0, 0);
               vi.sercxrezulto = TROVITA;
               vi.vortaro = SUPLEMENTA;
               vi.kategorio1 = MALLONGIGO;
               vi.kategorio2 = MALLONGIGO;
               vi.finajxomasko = 0;
               vi.finajxolongeco = 0;
               return true;
            }
        }
      }

      // Forigu streketojn, se estas.
      int j = 0;
      for (int i = 0; i < longeco; i++) {
         char1 = minuskloj[i];
         if (char1 != '-' && char1 != 0xAD) {  // 0xAD = soft hyphen / 'mola' streketo
            senstreketoj[j] = char1;
            j++;
         }
      }
      longeco = j;

      // Fortrancxu la finajxon kaj sercxu la grandan vortaron.
      fortrancxuFinajxon(senstreketoj, 0, longeco, vi);
      if (vi.finajxolongeco != 0) {
         if (sercxuGrandanVortaron(senstreketoj, 0, longeco - vi.finajxolongeco, vi)) {
            vi.sercxrezulto = TROVITA;
            return true;
         }
         else if (havasSuplementanVortaron && 
                     suplementaVortaro.sercxu(senstreketoj, 0, longeco - vi.finajxolongeco, informoj2)) {
               akiruVortInformojn(informoj2, vi, (byte)0, 0);
               vi.sercxrezulto = TROVITA;
               vi.vortaro = SUPLEMENTA;
               return true;
         }
         // Netrovita. Finfine provu analizi la vorton.
         else if (analizu(senstreketoj, 0, longeco - vi.finajxolongeco, vi)) {
            vi.sercxrezulto = TROVITA;
            return true;
         }
      }  // finajxolongeco != 0

      vi.sercxrezulto = NETROVITA;
      return false;

   }



   // Kolektu vortinformojn. Ne kontrolu.
   boolean sercxuGrandanVortaron(char[] minuskloj, int kom, int fin, VortInformoj vi) {

      int longeco = fin - kom;
      int sufiksolongeco;

      char[]  informoj3 = new char[3];  // 3 char-elementoj da informoj el granda vortaro

      // sufikso-masko - la sercxata vorto eble havas sufikson: int igx et ad
      byte sufiksomasko, suf;
      byte sufiksomaskoDeVortaro;

      if (grandaVortaro.sercxu(minuskloj, kom, fin, informoj3)) {
         akiruVortInformojn(informoj3, vi, (byte)0, 0);
         vi.vortaro = GRANDA;
         vi.sercxrezulto = TROVITA;
         return true;
      }
      else  {  // Eble la vorto havas sufikson: 
               // (ont, int, ant, ot, it, at, igx, ig, ad, et, eg, ec, ajx)
         sufiksomasko = akiruSufiksoMaskon(minuskloj, kom, fin);

         if (sufiksomasko != 0) {

            if ((sufiksomasko & IG_MASKO) != 0) {
               if ((sufiksomasko & AKT_MASKO) != 0) sufiksolongeco = 5;       // ig.ant
               else if ((sufiksomasko & PAS_MASKO) != 0) sufiksolongeco = 4;   // ig.it
               else if ((sufiksomasko & AD_MASKO) != 0) sufiksolongeco = 4;    // ig.ad
               else sufiksolongeco = 2;          // ig
            }
            else if ((sufiksomasko & IGX_MASKO) != 0) {
               if ((sufiksomasko & AKT_MASKO) != 0) sufiksolongeco = 5;      // igx.ant
               else if ((sufiksomasko & AD_MASKO) != 0) sufiksolongeco = 4;   // igx.ad
               else sufiksolongeco = 2;         // igx
            }
            else if ((sufiksomasko & AKT_MASKO) != 0) {
               sufiksolongeco = 3;             // ant
            }
            else sufiksolongeco = 2;     // ad, ec et ktp

            // Sercxu denove, sen sufikso
            if (grandaVortaro.sercxu(minuskloj, kom, fin - sufiksolongeco, informoj3)) {

               sufiksomaskoDeVortaro = (byte)(informoj3[1] >> 8);
               // En iuj kazoj, vorto havas du sufiksojn (lim/ig/it-a). Por tiaj kazoj, 
               // kio gravas estas la ig aux igx. Ekzemple 'fin' povas akcepti 'it', sed
               // ne 'ig' (fin/ig/it-a estas malgxusta). Se la sufikso havas ig aux igx,
               // la vortaro nepre devas ankaux havi respondan flagon.
               suf = sufiksomasko;
               if ((suf & IGIGX_MASKO) != 0) suf = (byte)(suf & IGIGX_MASKO);  // Malatentu AKT, PAS, AD
                   
               if ((suf & sufiksomaskoDeVortaro) != 0) {

                  akiruVortInformojn(informoj3, vi, sufiksomasko, fin - kom);
                  // Gxustigu la finajxomaskon.
                  if ((sufiksomasko & (AKT_MASKO + PAS_MASKO + EC_MASKO + AJX_MASKO) ) != 0) {
                     vi.finajxomaskoElVortaro = SUBSTANTIVA_GF + ADJEKTIVA_GF;
                  }
                  else if ((sufiksomasko & (IGX_MASKO + IG_MASKO + AD_MASKO) ) != 0) {
                     vi.finajxomaskoElVortaro = SUBSTANTIVA_GF + ADJEKTIVA_GF + VERBA_GF;
                  }
                  // Gxustigu la transitivecon. Noto: la sufiksoj et, eg, kaj ad ne 
                  // sxangxas la transitivecon.
                  if ((sufiksomasko & (AKT_MASKO + PAS_MASKO + IGX_MASKO 
                                       + EC_MASKO + AJX_MASKO)) != 0) {
                     vi.transitiva = false;
                  }
                  else if ((sufiksomasko & (IG_MASKO)) != 0) {
                     vi.transitiva = true;
                  }
                  // Gxustigu la signifon, ant -> AKTPART, it -> PASPART
                  if ((sufiksomasko & (AKT_MASKO)) != 0) {
                     vi.signifo = AKTPART;
                     vi.kunmetado = 1;   // Devas uzi simbolon cxi tie.
                  }
                  else if ((sufiksomasko & (PAS_MASKO)) != 0) {
                     vi.signifo = PASPART;
                     vi.kunmetado = 1;   // Devas uzi simbolon cxi tie.
                  }
                  vi.vortaro = GRANDA;
                  vi.sercxrezulto = TROVITA;
                  return true;
               }
            }
         }  // sufiksomasko != 0
      }
      return false;

   }  // fino de 'sercxuGrandanVortaron'



   /**
    * fortrancxuFinajxon - Cxi tiu metodo determinas la longecon de 
    * la gramatika finajxo (se estas), kaj registras gramatikajn 
    * informojn pri tiu finajxo. 
    * @param la_vorto - Signocxeno en unikoda formato.
    * @param kom - Komenca indekso de vorto en 'la_vorto'.
    * @param fin - Fina indekso (pozicio de lasta litero + 1).
    * @param vortinformoj (vi)- Ricevas informojn pri gramatika 
    * kategorio, pluraleco, akuzativeco, finajxolongeco, ktp.
    * @return Nenio.
    */

   void fortrancxuFinajxon(char[] vorto, int kom, int fin, VortInformoj vi) {

      int lon = fin - kom;
      char lit1, lit2, lit3;  // tri lastaj literoj

      vi.kategorio1 = NEKONATA;
      vi.kategorio2 = NEKONATA;

      if (lon < 3) {
         vi.finajxomasko = 0;
         vi.finajxolongeco = 0;
         return;
      }

      lit1 = vorto[fin-1];
      if (lit1 == 'o') {
         vi.kategorio1 = SUBSTANTIVO;
         vi.plurala   = false;
         vi.akuzativa = false;
         vi.finajxomasko = SUBSTANTIVA_GF;
         vi.finajxolongeco = 1;
         return;
      }
      if (lit1 == 'a') {
         vi.kategorio1 = ADJEKTIVO;
         vi.plurala   = false;
         vi.akuzativa = false;
         vi.finajxomasko = ADJEKTIVA_GF;
         vi.finajxolongeco = 1;
         return;
      }
      if (lit1 == 'i') {
         vi.kategorio1 = VERBO;
         vi.finajxomasko = VERBA_GF;
         vi.finajxolongeco = 1;
         return;
      }
      if (lit1 == 'e') {
         vi.kategorio1 = ADVERBO;
         vi.finajxomasko = ADJEKTIVA_GF;
         vi.finajxolongeco = 1;
         return;
      }
      if (lit1 == 'u') {
         vi.kategorio1 = VERBO;
         vi.finajxomasko = VERBA_GF;
         vi.finajxolongeco = 1;
         return;
      }

      if (lon < 4) {
         vi.finajxomasko = 0;
         vi.finajxolongeco = 0;
         return;
      }

      lit2 = vorto[fin-2];
      if (lit2 == 'o' && lit1 == 'n') {
         vi.kategorio1 = SUBSTANTIVO;
         vi.plurala   = false;
         vi.akuzativa = true;
         vi.finajxomasko = SUBSTANTIVA_GF;
         vi.finajxolongeco = 2;
         return;
      }
      if (lit2 == 'o' && lit1 == 'j') {
         vi.kategorio1 = SUBSTANTIVO;
         vi.plurala   = true;
         vi.akuzativa = false;
         vi.finajxomasko = SUBSTANTIVA_GF;
         vi.finajxolongeco = 2;
         return;
      }
      if (lit2 == 'a' && lit1 == 'n') {
         vi.kategorio1 = ADJEKTIVO;
         vi.plurala   = false;
         vi.akuzativa = true;
         vi.finajxomasko = ADJEKTIVA_GF;
         vi.finajxolongeco = 2;
         return;
      }
      if (lit2 == 'a' && lit1 == 'j') {
         vi.kategorio1 = ADJEKTIVO;
         vi.plurala   = true;
         vi.akuzativa = false;
         vi.finajxomasko = ADJEKTIVA_GF;
         vi.finajxolongeco = 2;
         return;
      }
      if (lit2 == 'i' && lit1 == 's') {
         vi.kategorio1 = VERBO;
         vi.finajxomasko = VERBA_GF;
         vi.finajxolongeco = 2;
         return;
      }
      if (lit2 == 'a' && lit1 == 's') {
         vi.kategorio1 = VERBO;
         vi.finajxomasko = VERBA_GF;
         vi.finajxolongeco = 2;
         return;
      }
      if (lit2 == 'o' && lit1 == 's') {
         vi.kategorio1 = VERBO;
         vi.finajxomasko = VERBA_GF;
         vi.finajxolongeco = 2;
         return;
      }
      if (lit2 == 'u' && lit1 == 's') {
         vi.kategorio1 = VERBO;
         vi.finajxomasko = VERBA_GF;
         vi.finajxolongeco = 2;
         return;
      }
      if (lit2 == 'e' && lit1 == 'n') {
         vi.kategorio1 = ADVERBO;
         vi.akuzativa = true;
         vi.finajxomasko = ENADVERBA_GF;
         vi.finajxolongeco = 2;
         return;
      }

      if (lon < 5) {
         vi.finajxomasko = 0;
         vi.finajxolongeco = 0;
         return;
      }

      lit3 = vorto[fin-3];
      if (lit3 == 'o' && lit2 == 'j' && lit1 == 'n') {
         vi.kategorio1 = SUBSTANTIVO;
         vi.plurala   = true;
         vi.akuzativa = true;
         vi.finajxomasko = SUBSTANTIVA_GF;
         vi.finajxolongeco = 3;
         return;
      }
      if (lit3 == 'a' && lit2 == 'j' && lit1 == 'n') {
         vi.kategorio1 = ADJEKTIVO;
         vi.plurala   = true;
         vi.akuzativa = true;
         vi.finajxomasko = ADJEKTIVA_GF;
         vi.finajxolongeco = 3;
         return;
      }

      vi.finajxomasko = 0;
      vi.finajxolongeco = 0;
      return;
   }


   // Maskoj por sufiksoj (unu bitoko)
   static final byte AKT_MASKO  = (byte)(128);  // aktivaj participoj
   static final byte PAS_MASKO  = 64;           // pasivaj participoj
   static final byte IGX_MASKO  = 32;
   static final byte IG_MASKO   = 16;
   static final byte AD_MASKO   = 8;
   static final byte ETEG_MASKO = 4;            // et aux eg
   static final byte EC_MASKO   = 2;
   static final byte AJX_MASKO  = 1;

   static final byte IGIGX_MASKO = IG_MASKO | IGX_MASKO;
   
   /**
    * akiruSufiksoMaskon - Kontrolas cxu estas sufikso, (int, at,
    * igx, ig, ad, ktp.) kaj redonas maskon por kompari kun masko 
    * de validaj sufiksoj el la vortaro.
    * @param la_vorto - Signocxeno en unikoda formato.
    * @param kom - Komenca indekso de vorto en 'la_vorto'.
    * @param fin - Fina indekso (pozicio de lasta litero + 1).
    * @return Redonas la maskon, unu bitoko.
    */

   private byte akiruSufiksoMaskon(char[] vorto, int kom, int fin) {

      if (fin - kom < 4) return 0;

      char lit1, lit2, lit3;  // tri lastaj literoj

      lit1 = vorto[fin-1];
      lit2 = vorto[fin-2];
      lit3 = vorto[fin-3];

      // Participa finajxo?
      if (lit1 == 't') {
         // Aktiva?
         if (lit2 == 'n') {
            if (lit3 == 'a' || lit3 == 'i' || lit3 == 'o')  {
               // Estas finajxo de aktiva participo (ant), sed eble
               // ankaux estas ig au igx: ig-int, igx-ant.
               if ((fin - kom > 6) && vorto[fin-5] == 'i') {
                  if (vorto[fin-4] == '\u011d') return (IGX_MASKO | AKT_MASKO);
                  if (vorto[fin-4] == 'g') return (IG_MASKO | AKT_MASKO);
               }
               // Ne estis igx nek ig.
               return AKT_MASKO;
            }
         }
         // Pasiva?
         if (lit2 == 'a' || lit2 == 'i' || lit2 == 'o') {
            // Estas finajxo de pasiva participo (it), sed eble
            // ankaux estas ig: ig-it, ig-at.
            if ((fin - kom > 5) && vorto[fin-4] == 'i') {
               if (lit3 == 'g') return (IG_MASKO | PAS_MASKO);
            }
            // Ne estis ig.
            return PAS_MASKO;
         }
      }
      if (lit2 == 'i') {
         // igx?
         if (lit1 == '\u011d') return IGX_MASKO;
         // ig?
         if (lit1 == 'g') return IG_MASKO;
      }
      if (lit2 == 'a') {
         // ad?
         if (lit1 == 'd') {
            // Estas finajxo 'ad', sed eble ankaux ig aux igx (ig.ad, igx.ad)
            if ((fin - kom > 5) && vorto[fin-4] == 'i') {
               if (lit3 == 'g') return (IG_MASKO | AD_MASKO);
               if (lit3 == '\u011d') return (IGX_MASKO | AD_MASKO);
            }
            // Ne estis ig nek igx.
            return AD_MASKO;
         }
         // ajx?
         if (lit1 == '\u0135') return AJX_MASKO;
      }
      if (lit2 == 'e') {
         // et?
         if (lit1 == 't') return ETEG_MASKO;
         // eg?
         if (lit1 == 'g') return ETEG_MASKO;
         // ec?
         if (lit1 == 'c') return EC_MASKO;
      }
      return 0;
   }


   void akiruVortInformojn(char[] informoj, VortInformoj vi, byte sufiksomasko, int longeco) {
       if (informoj.length == 1) {  // informoj de malgranda vortaro
         vi.kategorio1 = (informoj[0] >> 12) & 0xF;
         vi.kategorio2 = (informoj[0] >> 8) & 0xF;
         vi.dividpozicio[0] = (informoj[0] >> 4) & 0xF;
         if (vi.dividpozicio[0] == 0) vi.nombroDaDividpozicioj = 0;
         else vi.nombroDaDividpozicioj = 1;
         vi.finajxolongeco = (informoj[0] >> 2) & 3;
         vi.finajxomasko = 0;
         vi.finajxomaskoElVortaro = 0;
         vi.majusklecoElVortaro = informoj[0] & 3;
         vi.signifo = 0;
         vi.transitiva = false;
      }
      else if (informoj.length == 2) {   // estas suplementa vortaro
         int lastaDividpozicio = 0;
         vi.nombroDaDividpozicioj = 0;
         vi.dividpozicio[0] = (informoj[0] >> 12) & 0xF;
         vi.dividpozicio[1] = (informoj[0] >> 8) & 0xF;
         vi.dividpozicio[2] = (informoj[0] >> 4) & 0xF;
         vi.dividpozicio[3] =  informoj[0] & 0xF;
         for (int i = 0; i < 4; i++) {
            if (vi.dividpozicio[i] == 0) break;
            vi.nombroDaDividpozicioj++;
            lastaDividpozicio += vi.dividpozicio[i];
         }
         vi.finajxomaskoElVortaro = informoj[1] & 0xF;
         vi.majusklecoElVortaro = (informoj[1] >> 4) & 3;

      }
      else {  // informoj de granda vortaro
         int lastaDividpozicio = 0;
         vi.nombroDaDividpozicioj = 0;
         vi.dividpozicio[0] = (informoj[0] >> 12) & 0xF;
         vi.dividpozicio[1] = (informoj[0] >> 8) & 0xF;
         vi.dividpozicio[2] = (informoj[0] >> 4) & 0xF;
         vi.dividpozicio[3] =  informoj[0] & 0xF;
         for (int i = 0; i < 4; i++) {
            if (vi.dividpozicio[i] == 0) break;
            vi.nombroDaDividpozicioj++;
            lastaDividpozicio += vi.dividpozicio[i];
         }
         // Se la trovita vorto havas sufikson, necesas marki la pozicion
         // de tiu sufikso en la matrico de dividpozicioj. Ekzemple, la
         // vorto 'forirante' trovigxas en la vortaro kiel 'forir', kun 
         // unu dividpozicio je 3, kaj flago kiu indikas ke la vorto rajtas
         // havi sufikson de aktiva participo. Por gxuste marki la dividojn 
         // de la vorto, necesas aldoni dividpozicion je la fino de forir. 
         // Tiel, 'forirante' havos du dividpoziciojn, 3 kaj 2, por doni 
         // 'for.ir.ant/e'.
         if (sufiksomasko != 0) {
            if ((sufiksomasko == (IG_MASKO | AKT_MASKO)) ||
                (sufiksomasko == (IGX_MASKO | AKT_MASKO))) {
               vi.dividpozicio[vi.nombroDaDividpozicioj] = longeco - 5 - lastaDividpozicio;
               vi.nombroDaDividpozicioj++;
               vi.dividpozicio[vi.nombroDaDividpozicioj] = 2;
               vi.nombroDaDividpozicioj++;
            }
            else if (sufiksomasko == (IG_MASKO | PAS_MASKO)) {
               vi.dividpozicio[vi.nombroDaDividpozicioj] = longeco - 4 - lastaDividpozicio;
               vi.nombroDaDividpozicioj++;
               vi.dividpozicio[vi.nombroDaDividpozicioj] = 2;
               vi.nombroDaDividpozicioj++;
            }
            else if (sufiksomasko == AKT_MASKO) {
               vi.dividpozicio[vi.nombroDaDividpozicioj] = longeco - 3 - lastaDividpozicio;
               vi.nombroDaDividpozicioj++;
            }
            else  {
               vi.dividpozicio[vi.nombroDaDividpozicioj] = longeco - 2 - lastaDividpozicio;
               vi.nombroDaDividpozicioj++;
            }
         }
         vi.finajxomaskoElVortaro = (informoj[1] >> 4) & 0xF;
         vi.majusklecoElVortaro = (informoj[1] >> 2) & 3;
         vi.kunmetado = (informoj[1] & 3);
         if (((informoj[2] >> 15) & 1) != 0) vi.transitiva = true;
         else vi.transitiva = false;
         vi.radikkaraktero = (informoj[2] >> 8) & 0x7F;
         vi.signifo = informoj[2] & 0xFF;
      }
   }



   boolean analizu(char[] la_vorto, int kom, int fin, VortInformoj vi) {

      int    divInd;            // indekso de dividpozicioj
      int    antauxa;           // antauxa dividpozicio

      radiko[0].komenco  = kom;
      radiko[0].fino     = fin;
      finoDeVorto        = fin;

      if (analizu2(la_vorto, 0)) {
         divInd  = 0;
         antauxa = 0;

         // Prenu la finajxomaskon de la lasta radiko.
         vi.finajxomaskoElVortaro = radiko[nombroDaRadikoj - 1].finajxomaskoElVortaro;

         // Kolektu dividpoziciojn.
         for (int i = 0; i < nombroDaRadikoj; i++) {
            for (int j = 0; j < radiko[i].nombroDaDividpozicioj; j++) {
               antauxa += radiko[i].dividpozicio[j];
               vi.dividpozicio[divInd] = radiko[i].dividpozicio[j];
               divInd++;
            }
            if (i < nombroDaRadikoj - 1) {
               vi.dividpozicio[divInd] = radiko[i].fino - antauxa;
               antauxa = radiko[i].fino;
               divInd++;
            }
         }
         vi.perAnalizo = true;
         vi.nombroDaDividpozicioj = divInd;
         return true;
      }

      return false;
      
   }


   boolean analizu2(char[] la_vorto, int nivelo) {

      if (nivelo == maksNombroDaRadikoj) return false;

      int           kom = radiko[nivelo].komenco;
      int           fin = radiko[nivelo].fino;
      VortInformoj  inf = radiko[nivelo];
      int           lon = fin - kom;

      // diagnozo(la_vorto, nivelo, false);                         // por diagnozado

      // Cxu la restajxo estas valida?
      if (nivelo > 0 && sercxuGrandanVortaron(la_vorto, kom, fin, inf)) {
         // diagnozo(la_vorto, nivelo, true);                       // por diagnozado
         if (radikoValida(nivelo)) {
            nombroDaRadikoj = nivelo + 1;
            // System.err.println("--------------------- OK");      // por diagnozado
            return true;
         }
         // System.err.println("--------------------- nebona");     // por diagnozado
      }

      for (int i = lon - 2; i >= 2; i--) {
         if (sercxuGrandanVortaron(la_vorto, kom, kom + i, inf)) {
            radiko[nivelo].fino = kom + i;
            radiko[nivelo + 1].fino = finoDeVorto;
            radiko[nivelo + 1].komenco  = kom + i;
            if (analizu2(la_vorto, nivelo + 1) == true) return true;
         }
      }

      return false;
   }


   boolean radikoValida(int lastaRadiko) {

      int karak;
      int signifo;
      int antauxa_karak = 0;
      int antauxa_signifo = 0;
      int posta_karak = 0;
      int posta_signifo = 0;

      for (int i = 0; i <= lastaRadiko; i++) {

         if (radiko[i].kunmetado == N) {  // se kunmetado ne permesata
            return false;
         }

         karak   = radiko[i].radikkaraktero;
         signifo = radiko[i].signifo;

         // System.err.println("karak = " + karak);  // For debugging  // Por diagnozado
         // System.err.println("signifo = " + signifo);

         if (i > 0) {
            antauxa_karak   = radiko[i-1].radikkaraktero;
            antauxa_signifo = radiko[i-1].signifo;
         }

         if (i < lastaRadiko) {
            posta_karak   = radiko[i+1].radikkaraktero;
            posta_signifo = radiko[i+1].signifo;
         }

//----------------------------------------------------------------------------------------------------

         if (karak == RAD_NUMERO) {
            if (i == 0) {
               continue;
            }
            else {  // cxi tiu numero estas dua aux tria radiko
               if (antauxa_karak == RAD_NUMERO) {
                   if (signifo == NUMERO3) {  // dumil, trimil, ktp
                      // ducent.trimil ktp estas valida
                      continue;
                   }
                   else if (antauxa_signifo > signifo) {
                      // du.tridek (NUMERO0, NUMERO1) estas malgxusta
                      // sep.ok (NUMERO0, NUMERO0) ankaux estas malgxusta
                      // sed tridek.du (NUMERO1, NUMERO0) validas
                      continue;
                   }
                   return false;
               }
               else return false;
            } 
         }  // RAD_NUMERO

//----------------------------------------------------------------------------------------------------

         else if (karak == RAD_SUFIKSO) {

            if (i == 0) return false;  // kutime, sufiksoj sekvas ion
            if (signifo == ONOPOBL) {  // du.on/o, du.op/o, du.obl/a
               if (antauxa_karak == RAD_NUMERO) continue;
               return false;
            }
            else if (signifo == UL) {
               // Sxajnas ke UL plej ofte sekvas adjektivan radikon (verd.ul/o, lauxt.ul/o). 
               // Gxi ankaux sekvas nomajn radikojn (stel.ul/o) kaj prefiksojn (kun.ul/o),
               // sed eble malpli ofte. Cxar gxi estas mallonga, mi provizore limigos gxin 
               // al adjektivoj. La aliajn kunmetajxojn oni metu en la vortaron.
               // Se mi estonte permesos gxin sekvi nomajn radikojn, mi devos kontroli 
               // cxu la antauxa radiko signifas PERSONO-n.
               if (antauxa_karak == RAD_ADJEKTIVO) {
                      continue;
               }
               else return false;
            }
            else if (signifo == IN) {
               if (antauxa_signifo == UL || antauxa_signifo == ETNO || 
                   antauxa_signifo == PERSONO || antauxa_signifo == OKUPO ||
                   antauxa_signifo == MAMULO || antauxa_signifo == FISXO || 
                   antauxa_signifo == BIRDO || antauxa_signifo == AN) {
                  continue;
               }
               else return false;
            }
            else if (signifo == AN) {
               if (antauxa_signifo == URBO || antauxa_signifo == LANDO || 
                   antauxa_signifo == SXTATO || antauxa_signifo == REGIONO ||
                   antauxa_signifo == KONTINENTO || antauxa_signifo == PROVINCO ||
                   antauxa_signifo == INSULO) {
                  continue;
               }
               else return false;
            }
            else if (signifo == ID) {
               if (antauxa_signifo == ANIMALO || antauxa_signifo == MAMULO || 
                   antauxa_signifo == FISXO || antauxa_signifo == BIRDO) {
                  continue;
               }
               else return false;
            }
            // OV ne vere estas sufikso, sed por faciligi la algoritmon,
            // mi indikis ke gxi estas en la vortaro.
            else if (signifo == OV) {
               if (antauxa_signifo == ANIMALO || antauxa_signifo == FISXO || 
                   antauxa_signifo == REPTILIO || antauxa_signifo == AMFIBIO ||
                   antauxa_signifo == BIRDO) {
                  continue;
               }
               else return false;
            }
            else if (signifo == AR) {
               if (antauxa_signifo == UL ||
                   antauxa_signifo == PERSONO || 
                   antauxa_signifo == OKUPO || 
                   antauxa_signifo == AN || 
                   antauxa_signifo == AKTPART ||
                   antauxa_signifo == MAMULO || 
                   antauxa_signifo == ANIMALO ||
                   antauxa_signifo == BIRDO) {
                  continue;
               }
               else return false;
            }
            else {
               return false;
            }

         }  // SUFIKSO

//----------------------------------------------------------------------------------------------------

         else if (karak == RAD_PREFIKSO) {
            if (signifo == NE) {
               if (posta_signifo == EBL || posta_signifo == IND || 
                   posta_signifo == AKTPART || posta_signifo == PASPART) {
                  // Laux mia opinio, 'videblas' estas bona, sed ne 'nevideblas'
                  // Oni ne rekte ligu adverbon kun gxia verbo. (* Ili tretimis.)
                  radiko[i+1].finajxomaskoElVortaro = ADJEKTIVA_GF;
                  continue;
               }
            }
            else if (signifo == DUM) {
               if (posta_signifo == TEMPO || posta_signifo == SEZONO) {
                  radiko[i+1].radikkaraktero = RAD_ADJEKTIVO;
                  radiko[i+1].finajxomaskoElVortaro = ADJEKTIVA_GF;
                  continue;
               }
            }
            else if (signifo == PRA) {
               if (posta_signifo == ETNO) continue;
            }
            else if (signifo == RE && i == 0) {
               if (posta_karak == RAD_VERBO || 
                   posta_karak == RAD_SUBSTVERBO) continue;
            }
            return false;
         }

//----------------------------------------------------------------------------------------------------

         else if (karak == RAD_SUBST) {
            if (antauxa_karak == RAD_NUMERO) {
               radiko[i].radikkaraktero = RAD_ADJEKTIVO;
               radiko[i].finajxomaskoElVortaro = ADJEKTIVA_GF;
               continue;
            }
            if (antauxa_karak == RAD_PREFIKSO) {
               continue;
            }
            if (posta_karak == RAD_SUFIKSO) {
               continue;
            }
            else return false;
         }  // RAD_SUBST

//----------------------------------------------------------------------------------------------------

         else if (karak == RAD_VERBO) {
            if (antauxa_karak == RAD_PREFIKSO || posta_karak == RAD_SUFIKSO) {
               continue;
            }
            else return false;
         }  // RAD_VERBO

//----------------------------------------------------------------------------------------------------

         else if (karak == RAD_SUBSTVERBO) {
            if (i > 0 && antauxa_karak == RAD_NUMERO) {
               radiko[i].radikkaraktero = RAD_ADJEKTIVO;
               radiko[i].finajxomaskoElVortaro = ADJEKTIVA_GF;
               continue;
            }
            else if (antauxa_karak == RAD_PREFIKSO) {
               continue;
            }
            if (posta_karak == RAD_SUFIKSO) {
               continue;
            }
            else return false;
         }  // RAD_SUBSTVERBO

//----------------------------------------------------------------------------------------------------

         else if (karak == RAD_ADJEKTIVO) {
            if (antauxa_karak == RAD_PREFIKSO) {
               continue;
            }
            else return false;
         }  // RAD_ADJEKTIVO

//----------------------------------------------------------------------------------------------------
         else return false;

      } // fino de "for"

      return true;

   }




   /////////////////////////////////////////////////////////////////
   // Cxi tiu metodo estas uzata por diagnozado. Gxi montras la 
   // vorterojn en la matrico 'radikoj', kaj iliajn radikkarakterojn.

   void diagnozo (char[] la_vorto, int nivelo, boolean montruKarak) {
      for (int k = 0; k <= nivelo; k++) {
         for (int j = radiko[k].komenco; j < radiko[k].fino; j++) {
            if (la_vorto[j] > 127) {
               System.err.print(konvertu_uni_aski(la_vorto[j]));
               System.err.print('x');
            }
            else {
               System.err.print(la_vorto[j]);
            }
         }
         System.err.print(" ");
      }
      System.err.print("   ");

      if (montruKarak) {
         for (int k = 0; k <= nivelo; k++) {
            System.err.print(" " + 
                 akiruCxenon(radiko[k].radikkaraktero,karakteroj));
         }
      }
      System.err.println("");
   }


   // Konvertu unikodan literon al askio.
   final char konvertu_uni_aski(char litero) {
      if (litero == 0x109 || litero == 0x108) return 'c';
      if (litero == 0x11d || litero == 0x11c) return 'g';
      if (litero == 0x15d || litero == 0x15c) return 's';
      if (litero == 0x16d || litero == 0x16c) return 'u';
      if (litero == 0x135 || litero == 0x134) return 'j';
      if (litero == 0x125 || litero == 0x124) return 'h';
      return '?';
   }  // fino de "konvertu_literon"


}  // fino de "EspVortaro"

