/*
 * @(#) Simredo 4
 * @author  Klivo
 * @version 4.1    2005/08
 *
 * Simredo is a Java Unicode editor.
 * Version 4 is based on Simredo 3.4. I'm adding support for RTF.
 *
 * Simredo estas Gxava Unikoda redaktilo.
 * Versio 4 estas bazita sur Simredo 3.4. Cxi tiu versio subtenas RTF-on.
 *
 * Cleve Lendon (Klivo)
 * indriko@yahoo.com
 * http://purl.oclc.org/net/klivo/
 *
 */

/*
 * Changes in 3.1  Sxangxoj en 3.1  1999/06/24
 *
 * Don't set default directory to a: on startup. Program freezes.
 * Ne montrigu komencan dosierujon al a: dum vekigxo. Programo glaciigxas.
 *
 * Put in keymap functions 
 * (ctrl-f = show search (find), ctrl-n = search next, ctrl-b = search back).
 * Enmetu klavomap-funkciojn 
 * (ctrl-f = montru sercxodialogon, ctrl-n = sercxu malsupren, ctrl-b sercxu supren).
 * 
 * Put in tool bar: new, open, save, search, up, down, cut, copy, paste
 * Enmetu ikontrabon: nova, malfermu, konservu, sercxu, supren, malsupren, 
 * eltondu, kopiu, intergluu
 * 
 */

/*
 * Changes in 3.2 (for Linux)    Sxangxoj en 3.2 (por Linukso) 1999/08/30
 * 
 * On startup, put top left at 40, 40.
 * Metu la komencan pozicion cxe 40,40.
 *
 */

/* Changes in 3.3 / sxangxoj en 3.3   2000/12/01
 *
 * Convert Unicode to Iran System
 * Add new menu to support right to left languages (Persian, Hebrew).
 * Implement user key maps.
 * Deadkeys will be implemented using keymaps. Remove old classes.
 * Add dialogue to inform the user that a file already exists (exists_dialog) and
 * a message to confirm when a file is saved (saved_message).
 *
 * Konvertu de Unikodo al Irana Sistemo
 * Aldonu novan menuon por subteni lingvoj kiuj fluas maldekstren (la persa, hebrea).
 * Aldonu klavmapoj difineblaj per uzantoj. 
 * Senpasxaj klavoj estos subtenataj per klavmapoj. Forigu malnovajn klasojn.
 * Kreu dialogon por informi la uzanton ke dosiero jam ekzistas (exists_dialog) kaj
 * mesagxon por konfirmi kiam dosiero estas konservita (saved_message).
 *
 * 2001/01/11
 * Fix alt-keys in UserKeyMaps
 * Korektu alt-klavojn en UserKeyMaps
 */

/*
 * Changes in 3.4 
 * 
 * Added English Spellcheck
 * Kontrolu literumadon de la angla.
 *
 * Changed saved_message to timed_message.
 * Anstatauxigis saved_message per timed_message.
 *
 * Replace Esperanto conversion dialog with
 * a general conversion dialog (ConvertDialog).
 * Anstatauxigis Esperanto-konvert-dialogon per
 * gxeneralan konvert-dialogon (ConvertDialog).
 *
 * Added new control-keys ctrl-o, ctrl-s, ctrl-p.
 * Aldonis novajn reg-klavajxojn, ctrl-o, ctrl-s, ctrl-p.
 *
 */

/*
 * Changes for version 4.
 * 
 * Add support for styled text (RTF format).
 * Font size, colour, bold, italic, underlined, left, middle, right
 * Better support for right-to-left languages.
 * New feature to show the keyboard arrangement (Written by VS Rawat)
 * Hindi Translation (by VS Rawat)
 * Undo/ Redo feature (by Navaneetha Krishnan)
 * ISCII and WX conversion (by Surekha Sastry and Srinivasa Raghavan)
 * Save simfont, simlist and simlang in user's subdirectory.
 * Receive Simredo's directory, sim_dir, as a parameter.
 *
 * Subtenu kunstilan tekston (RTF-formato).
 * Tipara grandeco, koloro, forteco, itala, substrekita, maldekstra, meza, dekstra
 * Pli bona subteno por lingvoj kiuj kuras maldekstren.
 * Nova funkcio por montri la klavarangxon (Verkita de VS Rawat)
 * Traduko al la Hinda. (de VS Rawat)
 * Malfaru/ Refaru funkcio (de Navaneetha Krishnan)
 * Konvertado de ISCII kaj WX (de Surekha Sastry kaj Srinivasa Raghavan)
 * Konservu simfont, simlist kaj simlang en subdosierujo de uzanto.
 * Akiru la dosierujon de Simredo, sim_dir, kiel parametron.
 *
 */


/*
 * Changes for version 4.1
 * 
 * Greek translation by Alex Haros.
 * Progress bar for loading, Alex Haros.
 *
 * Greka traduko de Alex Haros.
 * Progresindikilo por program-sxargado, Alex Haros.
 *
 */

import java.awt.*;
import java.io.*;
import java.util.*;
import java.net.*;
import java.awt.event.*;
import java.awt.print.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import javax.swing.text.rtf.*;
import javax.swing.undo.*;

class Simredo4 extends JPanel implements ActionListener, 
                                         DocumentListener,
                                         MouseListener, KeyListener, PopupMenuListener {

   private static ResourceBundle menu_resources;           // Rimedoj por internaciigo.
   private static ResourceBundle encoding_resources;       // Listo de kodaroj.
   private static ResourceBundle epo_encoding_resources;   // Listo de kodaroj, en Esperanto
   private static ResourceBundle fra_encoding_resources;   // En Francais
   private static ResourceBundle hin_encoding_resources;   // Hindi

   // undo, redo
   private UndoAction undoAction;
   private RedoAction redoAction;
   private UndoManager undo;


   static {
      try {
         menu_resources = ResourceBundle.getBundle("Simredo4",Locale.getDefault());
      } catch (MissingResourceException mre) {
         System.err.println("Can't find Simredo4.properties");
         System.err.println("Ne povas trovi Simredo4.properties");
         System.exit(1);
      }
      try {
         encoding_resources = ResourceBundle.getBundle("Kodaroj_eng",Locale.getDefault());
      } catch (MissingResourceException mre) {
         System.err.println("Can't find Kodaroj_eng.properties");
         System.err.println("Ne povas trovi Kodaroj_eng.properties");
         System.exit(1);
      }
      try {
         epo_encoding_resources = ResourceBundle.getBundle("Kodaroj_epo",Locale.getDefault());
      } catch (MissingResourceException mre) {
         System.err.println("Can't find Kodaroj_epo.properties");
         System.err.println("Ne povas trovi Kodaroj_epo.properties");
         System.exit(1);
      }
      try {
         fra_encoding_resources = ResourceBundle.getBundle("Kodaroj_fra",Locale.getDefault());
      } catch (MissingResourceException mre) {
         System.err.println("Ne peut pas trouver Kodaroj_fra.properties");
         System.err.println("Ne povas trovi Kodaroj_fra.properties");
         System.exit(1);
      }
      try {
         hin_encoding_resources = ResourceBundle.getBundle("Kodaroj_hin",Locale.getDefault());
      } catch (MissingResourceException mre) {
         System.err.println("Can't find Kodaroj_hin.properties");
         System.err.println("Ne povas trovi Kodaroj_hin.properties");
         System.exit(1);
      }
   }


   static JFrame   frame;    // kadro por la programo
   static Simredo4 simredo4;
   static String   current_language = "english";   // aktiva lingvo
   static String   sim_dir = ".";     // location of class or jar files  
                                      // loko de klas- aux jar- dosieroj
   static String   home_dir;          // User's home dir     // Hejma dosierujo de uzanto.
   static String   mainTitle = "Simredo 4.1";
   static boolean left_to_right  = true;  // direction, false = right to left 
                                          // direkto, falsa = dekstro al mal.
   static ChangeDirection   left2Right, right2Left;


   public static void main (String[] args) {
      System.out.println("Jen Simredo 4.1");
      System.out.println("This is Simredo 4.1");
      System.out.println("Voici Simredo 4.1");
      frame = new JFrame();      // kreu kadron
      frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

      home_dir = getHomeDirectory();

      // The directory which Simredo4.jar is installed in, sim_dir, may
      // be passed as a parameter. It's difficult to determine otherwise.
      // La dosierujo en kiu Simredo4.jar estas instalita, sim_dir, eble
      // estas ricevita kiel parametro. Estas malfacile determini alie.
      if (args.length > 0) {
         sim_dir = args[0];
      }
      current_language = getLanguage();
      simredo4 = new Simredo4();
      frame.setTitle("    " + mainTitle);
      frame.getContentPane().add(simredo4);
      frame.addWindowListener(simredo4.simcloser);
      frame.pack();
      frame.setBounds(50,50,680,500);   // pozicio kaj grandeco de la kadro
      simredo4.text_pane.requestFocusInWindow();
      frame.setVisible(true);             // montru la kadron
      //System.out.println("java.home " + System.getProperty("java.home"));
      //System.out.println("java.class.path " + System.getProperty("java.class.path"));
      //System.out.println("user.name " + System.getProperty("user.name"));
      //System.out.println("user.home " + System.getProperty("user.home"));
      //System.out.println("user.dir " + System.getProperty("user.dir"));
   } // main 


   //////////////////////////////////////////
   // Program status.


   // Added by Surekha on Jan27'04
   // Create an instance of IsciiConverter which deals with ISCII-UNICODE conversion and vice-versa.
   private IsciiConverter   isciiConverterObject;
   // end


   private static Stack   file_list = new Stack();   // list of previously edited files
                                                  // listo de antauxe redaktitaj dosieroj

   private Action[]          action_list;        // listo de agoklasoj
   private Hashtable         action_hash;        // asocia tabelo por agoklasoj - nomo -> klaso

   private JFileChooser        file_chooser;         // dosiero-dialogo
   private FileInformation     fi;

   private char[]              encryption_key = null;         // kriptiga sxlosilo

   private SearchDialog        search_dialog;        // dialogo por sercxi tekston
   private ChangeDialog        change_dialog;        // dialogo por sercxi kaj sxangxi tekston
   private ConvertDialog       convert_dialog;       // dialogo por konverti supersignojn
   private OpenConvertDialog   open_convert_dialog;  // demandas cxu la uzanto volas konverti dum malfermo
   private SaveConvertDialog   save_convert_dialog;  // demandas kiel la uzanto volas konverti dum 
                                                     // konservo al disko
   private FileChangedDialog   file_changed_dialog;  // demandas cxu la uzanto volas konservi sxangxojn
   private SaveKeyDialog       save_key_dialog;      // dialogo por peti sxlosilon dum konservado de dosiero
                                                     // this dialog asks for an encryption key for saving 
                                                     // a file
   private OpenKeyDialog       open_key_dialog;      // dialogo por peti sxlosilon dum malfermo de dosiero
                                                     // this dialog asks for an encryption key for opening 
                                                     // a file
   private ErrorDialog         error_dialog;         // montras erarmesagxon

   private ShowCharsDialog     show_chars_dialog;

   // ShowKeyboardDialog added by rawat 2004/06/06 for keyboard display
   private ShowKeyboardDialog show_keyboard_dialog;  // Show Keyboard

   private JDialog             colour_selector_dialog;    // Por montri kolor-selektilon. 
   private JColorChooser       colour_selector = new JColorChooser();

   private ExistsDialog        exists_dialog;  // File exists. Overwrite? / Surskribu?
   private TimedMessage        timed_message;  // Various timed messages (File Saved, etc)
                                               // Diversaj portempaj mesagxoj 
                                               // (Dosiero konservita, ktp)

   private SpellDialog         spell_dialog;   // Choose spell checker. Elektu literumilon.
   private static LangDialog         langdialog;   // For chosing interface language. Por elekti lingvon de interfaco.

   public  SimTextPane       text_pane;        // tekstujo
   private JScrollPane       scroll_pane;      // ujo kun glisbutonoj
   private JViewport         view_port; 

   /////////////////////////////////////
   // Fonts. Tiparoj.
   private static       GraphicsEnvironment  local_graphics;
   private String[]     font_families;          // nomoj de tiparaj familioj
   private JComboBox    font_list = new JComboBox();     // listo de tiparoj
   private JComboBox    font_sizes = new JComboBox();    // grandecoj de tiparoj
   private JPanel       font_panel = new JPanel();


   /////////////////////////////////////
   // User Keyboard Maps. Klavaraj Mapoj de Uzantoj

   private JComboBox    keymap_list   = new JComboBox();   // listo de klavaraj mapoj
   private JLabel       keymap_label  = new JLabel("");    // grandecoj de tiparoj

   private String current_keymap = "";
   private String saved_keymap = "";

   /////////////////////////////////////
   // Strings for creating menus and dialogs.
   // Cxenoj por krei menuojn kaj dialogojn.
   private String[]   menu_and_dialog_strings;           // tekstoj por menuoj kaj dialogoj
   private String[]   menus;         // menuoj
   private String[]   menu_labels;   // menu-etikedoj
   private String[]   menu_items;    // menuelektoj
   private String[]   commands;      // ordonoj

   // For the file chooser. Por la dosiero-selektilo
   private String     open_text    = "";
   private String     save_text    = "";
   private String     approve_text = "";
   private String     cancel_text  = "";

   // Miscellaneous  / Diversaj
   private String     new_document_text = "";
   private String     unicode_text = "";
   private String     keymap_text = "";
   private String     nokeymap_text = "";

   private TabSet     tabset;

   // Tool Panel - for menubar and toobar.
   // Panelo por menutrabo kaj ikontrabo.
   private JPanel  tool_panel = new JPanel(new BorderLayout());

   ////////////////////////////////////////
   // tool bar and icons / ikon-trabo kaj ikonoj

   private  JToolBar  toolbar  =  new JToolBar();
   //private  JToolBar  toptoolbar  =  new JToolBar();

   private ImageIcon newicon = getJarImage("nova.gif");
   private ImageIcon openicon = getJarImage("dos.gif");
   private ImageIcon saveicon = getJarImage("disketo.gif");
   //private ImageIcon printicon = getJarImage();
   private ImageIcon searchicon = getJarImage("binoklo.gif");
   private ImageIcon upicon = getJarImage("supren.gif");
   private ImageIcon downicon = getJarImage("malsup.gif");
   private ImageIcon cuticon = getJarImage("tondilo.gif"); 
   private ImageIcon copyicon = getJarImage("kopio.gif");
   private ImageIcon pasteicon = getJarImage("gluo.gif");
   private ImageIcon colouricon = getJarImage("koloroj.gif");
   private ImageIcon boldicon   = getJarImage("grasa.gif");
   private ImageIcon italicicon  = getJarImage("itala.gif");
   private ImageIcon underlineicon = getJarImage("sublinio.gif");
   private ImageIcon ljustifyicon = getJarImage("maldeks.gif");
   private ImageIcon rjustifyicon = getJarImage("deks.gif");
   private ImageIcon cjustifyicon = getJarImage("mezo.gif");
   private ImageIcon selectallicon = getJarImage("chio.gif");
   private ImageIcon ltricon = getJarImage("ltr.gif");   // left to right    /   maldekstro al dekstro
   private ImageIcon rtlicon = getJarImage("rtl.gif");    // right to left   /   dekstro al maldekstro
   //private ImageIcon languageicon = getJarImage("lingvo.gif");  // to select the language / por elekti lingvon


   ////////////////////////////////////////
   // Strings for encodings. Used for conversions.
   // Cxenoj por kodaroj. Uzitaj por konvertado.
   private String[]  encoding_names;          // nomoj de kodaroj
   private String[]  encoding_descriptions;   // priskriboj de kodaroj
  

   StyledDocument     doc;    // dokumento

   // Attributes, left and right alignment.
   // Atribuoj, maldekstra kaj dekstra flankoj 
   SimpleAttributeSet current_attributes;

   // Attributes, margins.
   // Atribuoj, maldekstra kaj dekstra flankoj 

   SimpleAttributeSet right_side    = new SimpleAttributeSet();
   SimpleAttributeSet left_side    = new SimpleAttributeSet();

   boolean      document_has_changed;   // dokumento estas sxangxita

   RTFEditorKit          the_editor_kit;

   private Properties  my_properties;

   static Closer simcloser;   // Closer listens for window events.
                              // "Closer" atentas fenestro-eventojn.

   static Color simpurple = new Color(0xcacaff);   // Purpura koloro

   ProgressShow  psh;    // progresindikilo 

   public Simredo4 () {

      super(true);

      psh = new ProgressShow(800);

      setLayout(new BorderLayout());

      // Instantiate IsciiConverter Object for ISCII-UNICODE conversion and vice-versa. 
      // Added by Surekha on Jan27 2004
      isciiConverterObject = new IsciiConverter(); 

      simcloser = new Closer();

      my_properties = new Properties();

      final int number_of_stops = 20;   // Nombro da taboj.
      TabStop[]  tabstops = new TabStop[number_of_stops];
      for (int i = 0; i < number_of_stops; i++) {
         //tabstops[i] = new TabStop(40.0f * i,TabStop.ALIGN_LEFT,TabStop.LEAD_NONE);
         tabstops[i] = new TabStop(40.0f * i);
      }
      TabSet tabset = new TabSet(tabstops);

      text_pane = new SimTextPane(sim_dir);
      text_pane.addMouseListener(this);
      text_pane.addKeyListener(this);
      text_pane.setContentType("text/rtf");

      the_editor_kit = new RTFEditorKit();
      text_pane.setEditorKit(the_editor_kit);


      //////////////////////////////////////////////////////////////
      // Get list of action classes and save them in a hash table.
      // Akiru liston de agoklasoj kaj konservu ilin en asocia tabelo.
      action_list = the_editor_kit.getActions();
      action_hash = new Hashtable();
      for (int i = 0; i < action_list.length; i++) {
         Action action = action_list[i];
         //System.out.print(" " + action.getValue(Action.NAME) + "\n");
         action_hash.put(action.getValue(Action.NAME), action);
      }

      //////////////////////////////////////////////////////////////////////////
      // Put inner classes into the hash table.
      // In the code below, open-file is the name used in the hash table to 
      // refer to the OpenFile action class. The NAME in the class will probably
      // be changed, according to the language specified in the resource file, 
      // but the name in the hash table will remain the same.
      //////////////////////////////////////////////////////////////////////////
      // Metu internajn klasojn en la asocian tabelon.
      // En la malsupraj instrukcioj, open-file estas la nomo uzata en la asocia
      // tabelo (action_hash) por referenci la OpenFile-agklason. La nomo de la
      // klaso probable sxangxigxos, laux la lingvo en la rimeda dosiero, sed la nomo 
      // en la asocia tabelo ne sxangxigxos.
      action_hash.put("open-file", new OpenFile("open-file"));
      action_hash.put("save-file", new SaveFile("save-file"));
      action_hash.put("save-file-as", new SaveFileAs("save-file-as"));
      action_hash.put("new-file", new NewFile("new-file"));
      action_hash.put("exit", new Exit("exit"));
      action_hash.put("show-search", new ShowSearch("show-search"));
      action_hash.put("search-down", new SearchDownx("search-down"));
      action_hash.put("search-up", new SearchUpx("search-up"));
      action_hash.put("show-change", new ShowChange("show-change"));
      action_hash.put("show-conversion-dialog", 
                       new ShowConvertDialog("show-conversion-dialog"));
      action_hash.put("print-file", new PrintIt("print-file"));
      action_hash.put("reverse-text", new ReverseText("reverse-text"));
      action_hash.put("show-chars", new ShowChars("show-chars"));
      action_hash.put("show-spell-dialog", new ShowSpellDialog("show-spell-dialog"));
      action_hash.put("show-colour-selector", new ShowColourSelectorDialog("show-colour-selector"));
      action_hash.put("change-direction", new ChangeDirection("change-direction"));  // l2r, r2l
      action_hash.put("show-keyboard", new ShowKeyboard("show-keyboard"));
      action_hash.put("change-language", new ChangeLanguage("change-language")); 

      // undo, redo
      undoAction = new UndoAction("undo-edit");
      redoAction = new RedoAction("redo-edit");
      undo = new UndoManager();
      action_hash.put("undo-edit", undoAction);
      action_hash.put("redo-edit", redoAction);



      // Check to make sure the language parameter is valid.
      // Kontrolu ke la lingva parametro estas valida.
      String languages = SimCon.toLower(menu_resources.getString("languages"));

      // Is the current language in the list? If not, set to English.
      // Cxu la aktiva lingvo estas en la listo? Se ne, faru gxin English.
      if (languages.indexOf(current_language) < 0) {
         current_language = "english"; 
      }
      menu_and_dialog_strings = SimCon.tokenize(menu_resources.getString(current_language));

      String dialog_resource = menu_and_dialog_strings[18];
      String[] dialog_labels = SimCon.tokenize(menu_resources.getString(dialog_resource));
      mainTitle = dialog_labels[0];

      getMiscellaneousTexts();

      initializeToolBar();
      initializeMenuBar(menu_and_dialog_strings[0]);

      tool_panel.add("North",menubar);
      tool_panel.add("South",toolbar);
      add("North",tool_panel);

      System.out.println("1");
      psh.iterate(100);
      // Create dialogs. Kreu dialogajn fenestrojn.
      createFileChooser();        // Kreu dosierodialogon.
      System.out.println("2");
      psh.iterate(200);
      createConvertDialog();      // Kreu konvertdialogon por supersignoj.
      createOpenConvertDialog();  // Kreu malfermokonvertodialogon.
      System.out.println("3");
      psh.iterate(300);
      createSaveConvertDialog();  // Kreu konservokonvertodialogon.
      createFileChangedDialog();  // Kreu "dosiero-sxangxita" -dialogon.
      createSearchAndChange();    // Kreu dialogojn por sercxado kaj sxangxado.
      createKeyDialogs();         // Kreu dialogojn por peti kriptosxlosilon.
      psh.iterate(400);
      createErrorDialog();        // Kreu erarodialogon.
      createShowCharsDialog();
      createShowKeyboardDialog();
      createExistsDialog();
      psh.iterate(500);
      createTimedMessage();
      createSpellDialog();
      createColourSelectorDialog();

      System.out.println("4");
      psh.iterate(600);
      initializeFontBoxes();      // The font names and sizes will be in the menubar,
                                  // instead of a separate dialogue.
                                  // La tiparaj nomoj kaj grandecoj estos en la menutrabo,
                                  // anstataux en aparta dialogfenestro. 


      keymap_label.setText("   " + keymap_text);

      text_pane.setSelectionColor(simpurple);
      scroll_pane = new JScrollPane();
      view_port = scroll_pane.getViewport();
      view_port.add(text_pane);
      text_pane.setViewport(view_port);

      System.out.println("5");

      psh.iterate(700);

      getDefaultFont();    // Get default font and other information
                           // Akiru la kutiman tiparon kaj aliajn informojn.

      psh.out.setText("Simredo is Ready");
      psh.iterate(700);
      psh.stop();

      add("Center",scroll_pane);

      font_list.setActionCommand("set-font");
      font_sizes.setActionCommand("set-font-size");

      document_has_changed = false;

      //////////////////////////////////////////////////
      // Set key bindings.  Pretigu klav-ligojn.
      // ctrl-f >> Show search dialogue.  Montru sercx-dialogon.

      Action search_dia     = new ShowSearch("show-search");
      Action search_down    = new SearchDownx("search-down");
      Action search_up      = new SearchUpx("search-up");
      Action open_ctrl      = new OpenFile("open-file");
      Action save_ctrl      = new SaveFile("save-file");
      Action print_ctrl     = new PrintIt("print-file");
      Action toggle_keymap  = new ToggleKeyMap("toggle-keymap");
      Action undo_action    = new UndoAction("undo-edit1");
      Action redo_action    = new RedoAction("redo-edit1");

      JTextComponent.KeyBinding[] bindings = {
         new JTextComponent.KeyBinding(KeyStroke.getKeyStroke(
                        KeyEvent.VK_Q,
                        InputEvent.CTRL_MASK),
                        "toggle-keymap"),
         new JTextComponent.KeyBinding(KeyStroke.getKeyStroke(
                        KeyEvent.VK_F, 
                        InputEvent.CTRL_MASK),
                        "show-search"),
         new JTextComponent.KeyBinding(KeyStroke.getKeyStroke(
                        KeyEvent.VK_N, 
                        InputEvent.CTRL_MASK),
                        "search-down"),
         new JTextComponent.KeyBinding(KeyStroke.getKeyStroke(
                        KeyEvent.VK_B, 
                        InputEvent.CTRL_MASK),
                        "search-up"),
         new JTextComponent.KeyBinding(KeyStroke.getKeyStroke(
                        KeyEvent.VK_O, 
                        InputEvent.CTRL_MASK),
                        "open-file"),
         new JTextComponent.KeyBinding(KeyStroke.getKeyStroke(
                        KeyEvent.VK_S, 
                        InputEvent.CTRL_MASK),
                        "save-file"),
         new JTextComponent.KeyBinding(KeyStroke.getKeyStroke(
                        KeyEvent.VK_P, 
                        InputEvent.CTRL_MASK),
                        "print-file"),
         new JTextComponent.KeyBinding(KeyStroke.getKeyStroke(
                        KeyEvent.VK_Z,
                        InputEvent.CTRL_MASK),
                        "undo-edit1"),
         new JTextComponent.KeyBinding(KeyStroke.getKeyStroke(
                        KeyEvent.VK_Y,
                        InputEvent.CTRL_MASK),
                        "redo-edit1"),
      };

      Keymap parentmap = text_pane.getKeymap();
      Keymap simkeymap = JTextComponent.addKeymap("simkeymap", parentmap);
      Action[] short_action_list = { search_dia, search_down, search_up, 
                                     open_ctrl, save_ctrl, print_ctrl,
                                     toggle_keymap, undo_action, redo_action};
      JTextComponent.loadKeymap(simkeymap, bindings, short_action_list);
      text_pane.setKeymap(simkeymap);

      newDoc();          // Akiru novan dokumentan objekton.

   } // end of constructor


   // getHomeDirectory - User specific information should be stored in a 
   // subdirectory (/simredo) of the user's home directory. This directory
   // will hold simfont, simlist and simlang.
   // (akiruHejmanDosierujon) - informoj por cxiu uzanto estus konservata
   // en subdosierujon  (/simredo) de la hejmdosierujo de la uzanto. Cxi
   // tiu dosierujo entenos simfont, simlist kaj simlang.

   private static String getHomeDirectory() {
      String  subdirectory;
      boolean success;
      String user_home = System.getProperty("user.home");
      try {
         File home_sub = new File(user_home, "simredo");
         if (!home_sub.exists() || !home_sub.isDirectory()) {
            success = home_sub.mkdirs();
            if (!success) return user_home;
         }
         subdirectory = home_sub.getCanonicalPath();
      } 
      catch (IOException iox) { subdirectory = user_home; }
      catch (SecurityException  sx) { subdirectory = user_home; }
      return subdirectory;
   }


   // Create file chooser dialog. Kreu dosieroselektilon.
   private void createFileChooser () {
      String fc_resource = menu_and_dialog_strings[7];
      String[] fc_labels = SimCon.tokenize(menu_resources.getString(fc_resource));
      open_text    = fc_labels[0];
      save_text    = fc_labels[1];
      approve_text = fc_labels[2];
      //cancel_text  = fc_labels[3];
      file_chooser = new JFileChooser();  // Kreu dosierodialogon.
      // For convenience, set the current directory to the directory
      // of the last file read.
      // version 3.1 - Do not set current directory to the A drive. 
      // That seems to kill the program when there is no floppy disk.
      // Por oportuneco, sxangxu la nunan dosierujon al la dosierujo
      // de la lasta sxargita dosiero.
      // versio 3.1 - Ne sxangxu la komencan dosierujon al la A-drajvo.
      // Tio mortigas la programon kiam ne estas fleksebla disko en 
      // la drajvo (pelilo?).
      try {
         String last_file = (String)file_list.peek();
         File last_directory = new File(last_file);
         last_file.toLowerCase();
         if (last_directory != null && !(last_file.startsWith("a:")))
                file_chooser.setCurrentDirectory(last_directory);
      } catch (EmptyStackException esx) {}  // Doesn't matter. Ne gravas.

   }  // createFileChooser



   // Get texts. Akiru tekstojn.
   private void getMiscellaneousTexts () {
      String mt_resource = menu_and_dialog_strings[8];
      String[] mt_labels = SimCon.tokenize(menu_resources.getString(mt_resource));
      new_document_text = mt_labels[0];
      unicode_text  = mt_labels[1];
      keymap_text   = mt_labels[2];
      nokeymap_text = mt_labels[3];
   }  // getMiscellaneousText


   // Create the search and change dialogues. Kreu la sercxodialogon kaj sxangxodialogon.
   private void createSearchAndChange () {
      String resource = menu_and_dialog_strings[5];
      String[] labels = SimCon.tokenize(menu_resources.getString(resource));
      search_dialog = new SearchDialog(frame, this, labels);
      resource = menu_and_dialog_strings[6];
      labels = SimCon.tokenize(menu_resources.getString(resource));
      change_dialog = new ChangeDialog(frame, this, labels);
   }  // createSearchAndChange


   ///////////////////////////////////////////////////////////////
   // Create menus. Kreu menuojn.

   private String[]  menubar_info;
   private JMenuBar  menubar = new JMenuBar();
   private JMenu     file_menu = new JMenu();       
   private JMenu     edit_menu = new JMenu();
   private JMenu     other_menu = new JMenu();

   /**
    * Initialize a menu bar. 
    * Pretigu menutrabon.
    */
   protected void initializeMenuBar(String menubar_name) {

      getFileList();  // Read list of previously edited files for file menu. 
                      // Legu liston de antauxe redaktitaj dosieroj por dokumentmenuo.
      menubar_info = SimCon.tokenize(menu_resources.getString(menubar_name));
      initializeFileMenu(file_menu);
      initializeMenu(edit_menu, menubar_info[2], menubar_info[3]);
      initializeMenu(other_menu, menubar_info[4], menubar_info[5]);
      initializeKeyMapList();

      menubar.add(file_menu);
      menubar.add(edit_menu);
      menubar.add(other_menu);

      font_panel.setLayout(new FlowLayout(FlowLayout.LEFT,5,6));
      font_panel.add(font_list);
      font_panel.add(font_sizes);
      font_panel.add(keymap_label);
      font_panel.add(keymap_list);

      //toptoolbar.setFloatable(false);
      //toptoolbar.setMargin(new Insets(0,0,0,0));
      //toptoolbar.add(new SimIconAction("change-language",languageicon));
      //font_panel.add(toptoolbar);

      menubar.add(font_panel);

      return;

   }  // initializeMenuBar

   /**
    * Initialize tool bar.
    * Pretigu ikon-trabon.
    */
   protected void initializeToolBar() {

      toolbar.setFloatable(false);
           // Why not float? I can't keep the toolbar above the main frame.
           // Kial ne flosi? Mi ne povas restigi la il-trabon super la cxefa kadro.
      toolbar.add(new NewFile("new",newicon));
      toolbar.add(new OpenFile("open",openicon));
      toolbar.add(new SaveFile("save",saveicon));
      toolbar.add(new ShowSearch("search",searchicon));
      toolbar.add(new SearchUpx("up",upicon));
      toolbar.add(new SearchDownx("down",downicon));

      toolbar.add(new SimIconAction("select-all",selectallicon));
      toolbar.add(new SimIconAction("cut-to-clipboard",cuticon));
      toolbar.add(new SimIconAction("copy-to-clipboard",copyicon));
      toolbar.add(new SimIconAction("paste-from-clipboard",pasteicon));

      toolbar.add(new SimIconAction("left-justify",ljustifyicon));
      toolbar.add(new SimIconAction("right-justify",rjustifyicon));
      toolbar.add(new SimIconAction("center-justify",cjustifyicon));

      toolbar.add(new ShowColourSelectorDialog("colour",colouricon));
      toolbar.add(new SimIconAction("font-bold",boldicon));
      toolbar.add(new SimIconAction("font-italic",italicicon));
      toolbar.add(new SimIconAction("font-underline",underlineicon));

      left2Right = new ChangeDirection("change-direction",ltricon);
      right2Left = new ChangeDirection("change-direction",rtlicon);
      toolbar.add(right2Left);

   }


   /**
    * Initialize a menu.
    * Pretigu menuon.
    */
   protected  void  initializeMenu(JMenu menu, String resource_name, String menu_name) {
      menu.setText(menu_name);
      String[] menu_tokens = SimCon.tokenize(menu_resources.getString(resource_name));
      String   action_name;
      Action   the_action;
      int  len = menu_tokens.length;
      for (int i = 0; i < len; i=i+2) {
         action_name = menu_tokens[i];
         if (action_name.startsWith("separator")) {
            menu.addSeparator();
         }
         else {
            the_action = (Action)action_hash.get(action_name);
            if (the_action != null) {
               // Get a new label from the resource file and 
               // change the name of the action class.
               // Akiru novan etikedon de la rimeda dosiero kaj 
               // sxangxu la nomon de la agklaso.
               the_action.putValue(Action.NAME, menu_tokens[i+1]);
               menu.add(the_action);
            }
            else menu.add(createMenuItem(menu_tokens[i+1],action_name));
         }
      }
      return;
   }  // initializeMenu


   /**
    * Initialize the file menu. This method adds a list of recently edited
    * files to the regular items.
    * Pretigu la dokument-menuon. Cxi tiu metodo metas liston de laste redaktitaj
    * dokumentoj post la kutimaj menuelektoj.
    */
   protected  void  initializeFileMenu(JMenu menu) {
      // First, put in the regular menu items with initializeMenu.
      // Unue, enmetu la kutimajn menu-elektojn per initializeMenu.
      initializeMenu(menu, menubar_info[0], menubar_info[1]);
      // Next, put in the list of recently edited files.
      // Sekve, enmetu liston de laste redaktitaj dosieroj.
      if (file_list.size() > 0) {
         menu.addSeparator();
         String   the_file_name;
         for (int i = file_list.size() -1; i >= 0; i--) {
            try {
               the_file_name = (String)file_list.elementAt(i);
               menu.add(createMenuItem(the_file_name, "open " + the_file_name));
            } catch (ArrayIndexOutOfBoundsException e) {}
         }
      }
      return;
   }  // initializeFileMenu


   /**
    * Initialize keymap_list. (user keymaps)
    * Pretigu liston de klavmapoj.  (klavmapoj de uzantoj)
    */
   protected  void  initializeKeyMapList() {
      String   map_name;
      String   temp;
      int        dot_index;
      File keymap_files = new File(sim_dir);
      keymap_list.addItem(nokeymap_text);
      String[] list_of_maps = keymap_files.list(new KeyMapFilter());
      if (list_of_maps != null) {
         // Sort this. Ordigu
         for (int i = 0; i < list_of_maps.length - 1; i++) {
            for (int j = 0; j < list_of_maps.length - i - 1; j++) {
               if (list_of_maps[j].compareTo(list_of_maps[j + 1]) > 0) {
                  // Must move it down. Devas movi gxin malsupren.
                  temp = list_of_maps[j + 1];
                  list_of_maps[j + 1] = list_of_maps[j];
                  list_of_maps[j] = temp;
               }
            }
         }
         for (int i = 0; i < list_of_maps.length; i++) {
            map_name = list_of_maps[i];
            dot_index   = map_name.lastIndexOf(".");
            keymap_list.addItem(map_name.substring(0, dot_index));
         }
      }
      keymap_list.setActionCommand("new keymap");
      keymap_list.addActionListener(this);
      keymap_list.addPopupMenuListener(this);

   }  // initializeKeyMapList



   /**
    * Create a menu item.
    * Kreu menu-elekton.
    */
   protected JMenuItem createMenuItem(String the_item_name, String the_action_name) {
      JMenuItem mi = new JMenuItem(the_item_name);
      mi.setActionCommand(the_action_name);
      mi.addActionListener(this);
      return mi;
   }  // createMenuItem


   /**
    * createConvertDialog - Creates dialogue for converting characters and strings.
    * createConvertDialog - Kreas dialogon por konverti literojn kaj litercxenojn.
    */
   protected void createConvertDialog() {
      String dialog_resource = menu_and_dialog_strings[16];
      String[] dialog_labels = SimCon.tokenize(menu_resources.getString(dialog_resource));
      convert_dialog = new ConvertDialog(frame, sim_dir, dialog_labels);
   }  // createConvertDialog


    /**
    * createOpenConvertDialog - Create a dialogue which asks the user whether he or 
    * she wants to convert the file to be opened to unicode.
    * createOpenconvertDialog - Kreu dialogon kiu demandas al la uzanto cxu li aux sxi 
    * volas konverti malfermotan dokumenton al unikodo.
    */

   protected void createOpenConvertDialog() {

      String   encodings;
      String   dialog_resource = menu_and_dialog_strings[2];
      String[] dialog_labels = SimCon.tokenize(menu_resources.getString(dialog_resource));
      if (current_language.startsWith("esper")) {
         encodings = epo_encoding_resources.getString("encodings");
      }
      else if (current_language.startsWith("fran")) {
         encodings = fra_encoding_resources.getString("encodings");
      }
      else if (current_language.startsWith("hin")) {
         encodings = hin_encoding_resources.getString("encodings");
      }
      else {
         encodings = encoding_resources.getString("encodings");
      }
      open_convert_dialog = new OpenConvertDialog(frame, dialog_labels, encodings);

   }  // createOpenConvertDialog


    /**
    * createSaveConvertDialog - Create a dialogue which asks the user how he or 
    * she wants to convert the file to be saved.
    * createSaveConvertDialog - Kreu dialogon kiu demandas al la uzanto kiel li aux sxi 
    * volas konverti konservotan dokumenton.
    */

   protected void createSaveConvertDialog() {

      String   encodings;
      String   dialog_resource = menu_and_dialog_strings[3];
      String[] dialog_labels = SimCon.tokenize(menu_resources.getString(dialog_resource));
      if (current_language.startsWith("esper")) {
         encodings = epo_encoding_resources.getString("encodings");
      }
      else if (current_language.startsWith("fran")) {
         encodings = fra_encoding_resources.getString("encodings");
      }
      else if (current_language.startsWith("hind")) {
         encodings = hin_encoding_resources.getString("encodings");
      }
      else {
         encodings = encoding_resources.getString("encodings");
      }
      save_convert_dialog = new SaveConvertDialog(frame, dialog_labels, encodings);

   }  // createSaveConvertDialog




   /**
    * createFileChangedDialog - Create a dialog which ask the user whether he or she wants to
    * save changes to the current file.
    * createFileChangedDialog - Kreu dialogon kiu demandas al la uzanto cxu li aux sxi volas 
    * konservi sxangxojn en la nuna dokumento.
    */
   protected void createFileChangedDialog() {
      String dialog_resource = menu_and_dialog_strings[4];
      String[] dialog_labels = SimCon.tokenize(menu_resources.getString(dialog_resource));
      file_changed_dialog = new FileChangedDialog(frame, dialog_labels);
   }  // createFileChangedDialog



    /**
    * createKeyDialogs - Create dialogues which asks for an encryption key
    * before opening or saving a file.
    * createKeyDialogs - Kreu dialogojn kiu petas kriptosxlosilon antaux ol
    * malfermi aux konservi dokumenton.
    */

   protected void createKeyDialogs() {

      String   encodings;
      String   dialog_resource = menu_and_dialog_strings[9];
      String[] dialog_labels = SimCon.tokenize(menu_resources.getString(dialog_resource));
      save_key_dialog = new SaveKeyDialog(frame, dialog_labels);

      dialog_resource = menu_and_dialog_strings[10];
      dialog_labels = SimCon.tokenize(menu_resources.getString(dialog_resource));
      open_key_dialog = new OpenKeyDialog(frame, dialog_labels);

   }  // createKeyDialogs

   /**
    * createErrorDialog - Does just what the name says.
    * createErrorDialog - Kreas erardialogujon.
    */
   String  cant_save_message = "";
   String  invalid_key_message = "";
   protected void createErrorDialog() {
      String   dialog_resource = menu_and_dialog_strings[11];
      String[] dialog_labels = SimCon.tokenize(menu_resources.getString(dialog_resource));
      error_dialog = new ErrorDialog(frame, dialog_labels);
      cant_save_message = dialog_labels[1];
      invalid_key_message = dialog_labels[2];
   }


   /**
    * createShowCharsDialog - Creates dialogue to show all characters.
    * createShowCharsDialog - Kreas dialogon por montri cxiujn signojn.
    */
   protected void createShowCharsDialog() {
      String dialog_resource = menu_and_dialog_strings[12];
      String[] dialog_labels = SimCon.tokenize(menu_resources.getString(dialog_resource));
      show_chars_dialog = new ShowCharsDialog(frame, dialog_labels);
   }  // createShowCharsDialog


   /*
    * createShowKeyboardDialog - Creates dialogue to show keyboard
    * createShowKeyboardDialog - Kreas dialogon por montri keyboard
    * added by rawat 2004/06/06 for keyboard display
    */
    protected void createShowKeyboardDialog() {
        String dialog_resource = menu_and_dialog_strings[17];
        String[] dialog_labels = SimCon.tokenize(menu_resources.getString(dialog_resource));
        show_keyboard_dialog = new ShowKeyboardDialog(frame, dialog_labels);
    } // createShowKeyboardDialog



   /**
    * createExistsDialog - Create dialogue which asks 'File already exists. Overwrite?'
    * createExistsDialog - Kreas dialogon kiu demandas 'Dosiero jam ekzistas. Surskribu?'
    */
   protected void createExistsDialog() {
      String   dialog_resource = menu_and_dialog_strings[13];
      String[] dialog_labels = SimCon.tokenize(menu_resources.getString(dialog_resource));
      exists_dialog = new ExistsDialog(frame, dialog_labels);
   }


   /**
    * createTimedMessage - Create message which appears for a short time.
    * createTimedMessage - Kreas mesagxon kiu aperas nur mallongtempe.
    */
   protected void createTimedMessage() {
      String   dialog_resource = menu_and_dialog_strings[14];
      String[] dialog_labels = SimCon.tokenize(menu_resources.getString(dialog_resource));
      timed_message = new TimedMessage(frame, dialog_labels);
   }

   /**
    * createSpellDialog - Creates the spell check dialogue.
    * createSpellDialog - Kreas dialogon por selekti literumadon.
    */
   protected void createSpellDialog() {
      String dialog_resource = menu_and_dialog_strings[15];
      String[] dialog_labels = SimCon.tokenize(menu_resources.getString(dialog_resource));
      spell_dialog = new SpellDialog(frame, timed_message, dialog_labels);
   }  // createSpellDialog


   /**
    * createColourSelectorDialog - Creates dialogue to display the colour selector.
    * createColourSelectorDialog - Kreas dialogon por montri kolor-selektilon.
    */

   protected void createColourSelectorDialog() {

      String dialog_resource = menu_and_dialog_strings[19];

      String[] dialog_labels = SimCon.tokenize(menu_resources.getString(dialog_resource));

      colour_selector_dialog = JColorChooser.createDialog(this, dialog_labels[0], false,
                                 colour_selector, this, this);

   }  // createColourSelectorDialog




   /*
    * initializeFontBoxes - Initialize the comboboxes for the font name and size.
    * initializeFontBoxes - Pretigu la selektlistojn por tipara nomo kaj grandeco.
    */
   protected void initializeFontBoxes () {

      // Get available fonts. Akiru uzeblajn tiparojn.
      local_graphics  = GraphicsEnvironment.getLocalGraphicsEnvironment();

      // Note: I tried to get a list of all available fonts using the following command:
      // Font[] all_fonts       = local_graphics.getAllFonts();
      // It worked fine in Windows 98, but not in Windows 95 (Japanese version). It caused
      // Java to die silently. To avoid the problem, I'll send font family names to the 
      // font chooser.
      // Noto: Mi provis akiri liston de cxiuj uzeblaj tiparoj uzante la sekvantan ordonon:
      // Font[] all_fonts       = local_graphics.getAllFonts();
      // Gxi bone funkciis en Vindozo 98, sed ne en Vindozo 95 (Japana versio). Gxi mortigis
      // Gxavon silente. Por eviti la problemon, mi sendos liston de tiparaj familiaj nomo al 
      // la tipara dialogo.
      font_families   = local_graphics.getAvailableFontFamilyNames();

      // Initialize combobox for font names. Pretigu selektliston por tiparaj nomoj.
      for (int i = 0; i < font_families.length; i++) {
         //System.out.println(font_families[i]);
         font_list.addItem(font_families[i]);

         // New for versian 4. Nova por versio 4.
         String action_name = "set-font-" + font_families[i];
         action_hash.put(action_name,
                new RTFEditorKit.FontFamilyAction(action_name,font_families[i]));
      }

      // Initialize combobox for font sizes. Pretigu selektliston por tiparaj grandecoj.
      font_sizes.addItem("8"); font_sizes.addItem("9"); font_sizes.addItem("10"); 
      font_sizes.addItem("11"); font_sizes.addItem("12"); font_sizes.addItem("14");
      font_sizes.addItem("16"); font_sizes.addItem("18"); font_sizes.addItem("20");
      font_sizes.addItem("22"); font_sizes.addItem("24"); font_sizes.addItem("26");
      font_sizes.addItem("28"); font_sizes.addItem("36"); font_sizes.addItem("48");
      font_sizes.addItem("72"); font_sizes.addItem("144");

      action_hash.put("set-font-size-8",new RTFEditorKit.FontSizeAction("8",8));
      action_hash.put("set-font-size-9",new RTFEditorKit.FontSizeAction("9",9));
      action_hash.put("set-font-size-10",new RTFEditorKit.FontSizeAction("10",10));
      action_hash.put("set-font-size-11",new RTFEditorKit.FontSizeAction("11",11));
      action_hash.put("set-font-size-12",new RTFEditorKit.FontSizeAction("12",12));
      action_hash.put("set-font-size-14",new RTFEditorKit.FontSizeAction("14",14));
      action_hash.put("set-font-size-16",new RTFEditorKit.FontSizeAction("16",16));
      action_hash.put("set-font-size-18",new RTFEditorKit.FontSizeAction("18",18));
      action_hash.put("set-font-size-20",new RTFEditorKit.FontSizeAction("20",20));
      action_hash.put("set-font-size-22",new RTFEditorKit.FontSizeAction("22",22));
      action_hash.put("set-font-size-24",new RTFEditorKit.FontSizeAction("24",24));
      action_hash.put("set-font-size-26",new RTFEditorKit.FontSizeAction("26",26));
      action_hash.put("set-font-size-28",new RTFEditorKit.FontSizeAction("28",28));
      action_hash.put("set-font-size-36",new RTFEditorKit.FontSizeAction("36",36));
      action_hash.put("set-font-size-48",new RTFEditorKit.FontSizeAction("48",48));
      action_hash.put("set-font-size-72",new RTFEditorKit.FontSizeAction("72",72));
      action_hash.put("set-font-size-144",new RTFEditorKit.FontSizeAction("144",144));

      font_list.addActionListener(this);
      font_list.addActionListener(search_dialog);
      font_list.addActionListener(change_dialog);
      font_list.addActionListener(show_chars_dialog);
      font_list.addPopupMenuListener(this);

      font_sizes.addActionListener(this);
      font_sizes.addPopupMenuListener(this);

   } // initializeFontBoxes



   /*
    *  Returns the selected font.
    *  Redonas la elektitan tiparon.
    */


   /*
    *  Returns a file object for the selected user keymap file.
    *  Redonas la dosieran objekton por la elektita klavara mapo de uzantoj.
    */
   public File getSelectedKeyMapFile() {
      // First item in keymap list is invalid (no keymap).
      // La unua elektajxo en la klavmapo estas nevalida (Neaktiva klavmapo).
      if (keymap_list.getSelectedIndex() < 1) return null;
      return new File(sim_dir,(String)(keymap_list.getSelectedItem() + ".kmp"));
   }  // getSelectedKeyMapFile


   public File getKeyMapFile(String keymap_file_name) {
      return new File(sim_dir, keymap_file_name + ".kmp");
   }  // getKeyMapFile




   /*
    * putIntoFileList - Save the file name in the list of previously edited files
    * putIntoFileList - Konservu la dosieronomon en la liston de antauxe redaktitaj dosieroj.
    */
   private static final int file_list_max_size = 16;
   private void putIntoFileList(String file_name) {
      int number_of_elements = file_list.size();
      // First, remove the file name, if it is already in the list.
      // Unue, forigu la dosieronomon, se gxi jam estas en la listo.
      int index = file_list.search((String)file_name);
      if (index > 0) {
         file_list.removeElementAt(number_of_elements - index);
      }
      // Remove the last name, if the list is full.
      // Forigu la lastan nomon, se la listo estas plena.
      if (file_list.size() == file_list_max_size) {
         file_list.removeElementAt(0);
      }
      // Put in the new file name.
      // Enmetu la novan dosieronomon.
      file_list.push(file_name);

   }  // putIntoFileList


   /*
    * saveFileList - Writes out the list of recently edited files.
    * saveFileList - Elskribas la liston de laste redaktitaj dosieroj.
    */
   private void saveFileList () {

      OutputStreamWriter w;
      String  line;

      if (file_list != null && simlist != null) {
         try {
            if (simlist.exists()) simlist.delete();
            w = new OutputStreamWriter(new FileOutputStream(simlist),"UTF-16BE");
            w.write((char)0xFEFF);
            for (int i = 0; i < file_list.size(); i++) {
               line = (String)file_list.elementAt(i);
               w.write(line, 0, line.length());
               w.write("\r\n");
            }
            w.close();
         } catch (IOException e) {
            System.err.println("Error writing out simlist.txt. " + 
                               "Eraro dum elskribado de simlist.txt");
         }
      }
   } // saveFileList



   /*
    * getFileList - Reads in the list of recently edited files.
    * getFileList - Legas la liston de laste redaktitaj dosieroj.
    */
   File simlist;
   private void getFileList () {

      InputStreamReader fin;
      BufferedReader    bin;
      String            line;
      int               firstChar;

      if (file_list == null) file_list = new Stack();

      try {
         simlist = new File(home_dir,"simlist.txt");
      }
      catch (NullPointerException e) {
         return;
      }

      try {

         fin = new InputStreamReader(new FileInputStream(simlist), "UTF-16BE");
         bin = new BufferedReader(fin);
         firstChar = bin.read();   // The first char is FEFF. La unua char estas FEFF
         if (firstChar == 0xFEFF) {
           for (int i = 0; i < file_list_max_size; i++) {
               line = bin.readLine();
               if (line == null) break;
               file_list.push(line);
            }
         }
         bin.close();
      }
      catch (IOException e) {
         // System.err.println("Could not read simlist.txt. Ne povis legi simlist.txt.");
      }
      return;

   } // getFileList



   /*
    * getDefaultFont (was getLastFont) - Reads in the name and size of the 
    * default font from the file simfont.txt .
    * For 3.3, read in last key map used.
    * For 3.4, read in last spellchecker used.
    * For 4.0, read and set default font
    * getDefaultFont (estis getLastFont) - Legas la nomon kaj grandecon de 
    * la kutima (defauxlta?) tiparo el la dosiero simfont.txt .
    * Por 3.3, legu nomon pri lasta klavmapo.
    * Por 3.4, legu nomon de lasta kontrolilo de literumado.
    * Por 4.0, legu kaj difinu kutiman tiparon.
    */
   File simfont;
   private void getDefaultFont () {

      String             font_name = "";
      String             font_size = "";
      String             keymap_name = "";
      String             spellchecker = "";
      String             direction = "";

      String  action_name;   // For changing the font. Por sxangxi la tiparon.
      Action  the_action;

      try {
         simfont = new File(home_dir,"simfont.txt");
      }
      catch (NullPointerException e) {
         //System.err.println("Couldn't find simfont.txt / " +
         //                    "Ne trovis simfont.txt .\n");
      }

      if (simfont != null && simfont.exists()) {

         InputStreamReader fin;
         BufferedReader bin;

         try {

            fin = new InputStreamReader(new FileInputStream(simfont), "UTF-16BE");
            bin = new BufferedReader(fin);

            bin.read();   // The first char is FEFF. La unua char estas FEFF
            font_name    = bin.readLine();
            font_size    = bin.readLine();
            keymap_name  = bin.readLine();
            spellchecker = bin.readLine();
            direction = bin.readLine();
            bin.close();

         } catch (IOException e) {    // The file simfont.txt does not exist. 
                                      // Simfont.txt ne ekzistas.
            System.err.println("Couldn't open simfont.txt \n" +
                               "Ne povis malfermi simfont.txt .\n" + e.toString());
         }

         if (keymap_name != null && !keymap_name.equals("")) {
            current_keymap = keymap_name;
            File the_keymap_file = getKeyMapFile(keymap_name);
            if (the_keymap_file.exists()) {
               UserKeyMap.loadUserKeyMap(the_keymap_file);
               keymap_list.setSelectedItem(current_keymap);
            }
         }
         if (spellchecker != null && !spellchecker.equals("")) {
            if (spellchecker.toLowerCase().equals("english")) {
               text_pane.setSpellCheckLanguage(SimTextPane.CHECK_ENGLISH);
            }
            else if (spellchecker.toLowerCase().equals("esperanto")) {
               text_pane.setSpellCheckLanguage(SimTextPane.CHECK_ESPERANTO);
            }
            else {
               text_pane.setSpellCheckLanguage(SimTextPane.SPELLCHECK_OFF);
            }
         }
         if (direction != null && direction.length() > 0 && 
            direction.charAt(0) == '<') {
            left_to_right = false;
            rightToLeft();
         }
         else {
            left_to_right = true;
            leftToRight();
         }

      }   // if simfont exists


      if (font_name == null || font_name.length() == 0) { font_name = "Times New Roman"; }
      font_list.setSelectedItem(font_name);

      if (font_size == null || font_size.length() == 0) { font_size = "18"; }
      font_sizes.setSelectedItem(font_size);  

      if (search_dialog != null) search_dialog.newFont();
      if (change_dialog != null) change_dialog.newFont();

      return;

   } // getDefaultFont


   /*
    * saveDefaultFont (was saveLastFont) - Writes out the name and size of the 
    * default font to a file, simfont.txt . Also saves the current keymap and spellchecker
    * For version 4: save direction.
    *
    * saveDefaultFont (estis saveLastFont) - Elskribas la nomon kaj grandecon de la 
    * kutima tiparo al dosiero, simfont.txt . Ankaux konservas la aktivan klavmapon 
    * kaj literumilon.
    * Por versio 4: konservu la direkton.
    */
   private void saveDefaultFont () {

      OutputStreamWriter  w;
      String list  = (String)font_list.getSelectedItem() + "\r\n";
      String size  = (String)font_sizes.getSelectedItem() + "\r\n";
      String key   = current_keymap + "\r\n";
      String spell = text_pane.getSpellCheckLanguage2() + "\r\n";
      String direction;  // left to right or right to left  / direkto: dekstren aux maldekstren

      if (left_to_right) direction = ">\r\n";
      else direction = "<\r\n";

      if (simfont != null) {
         try {
            if (simfont.exists()) simfont.delete();
            w = new OutputStreamWriter(new FileOutputStream(simfont),"UTF-16BE");
            w.write((char)0xFEFF);
            w.write(list, 0, list.length());
            w.write(size, 0, size.length());
            w.write(key, 0, key.length());
            w.write(spell, 0, spell.length());
            w.write(direction, 0, direction.length());
            w.close();
         } catch (IOException e) {
            System.err.println("Error writing out simfont.txt. " +
                               "Eraro dum elskribado de simfont.txt");
         }
      }
   } // saveDefaultFont


   /*
    * getLanguage - Reads the menu-language from simlang.txt .
    * getLanguage - Legas la menu-lingvon de simlang.txt .
    */

   private static String getLanguage () {

      File simlang;
      RandomAccessFile   infile;      // en-dosiero
      String             line;

      try {
         simlang = new File(home_dir,"simlang.txt");

         if (simlang != null && simlang.exists()) {
            infile = new RandomAccessFile(simlang,"rw");
            line = infile.readLine().toLowerCase();
            infile.close();
         }
         else {
            langdialog = new LangDialog(frame, simlang, "");
            line = langdialog.getLanguage();
            langdialog = null;
         }
         // Francais = French
         if (line.startsWith("fren") || line.startsWith("fran")) return "francais";
         // Greek
         if (line.startsWith("gr") || line.startsWith("gre")) return "greek";
         return line;
      }
      catch (NullPointerException e) {
         return "english";
      }
      catch (IOException e) {
         return "english";
      }

   } // getLanguage



//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>





   public void actionPerformed(ActionEvent e) {
      String  the_command = e.getActionCommand();
      String  action_name;
      Action  the_action;

      if (the_command.equals("OK")) {
         // Must be the colour selector, but how do I confirm that?
         // Versxajne estas la kolorselektilo, sed kiel konfirmi?
         // Create an action class to change the foreground colour.
         // Kreu agklason por sxangxi la supran koloron.

         the_action = new StyledEditorKit.ForegroundAction
                                 ("change-colour", colour_selector.getColor());
         the_action.actionPerformed(e);
         text_pane.validate();

      } else
      if (the_command.equals("set-font")) {
         String theFont = (String)font_list.getSelectedItem();
         // Don't update dialog boxes when we click the mouse or use arrow keys.
         // Ne gxustigu dialogskatolojn kiam oni musklakas aux uzas sagklavojn.
         if (changeDialogFonts) {
            if (show_chars_dialog != null && show_chars_dialog.isVisible()) 
                  show_chars_dialog.newFont(theFont);
            if (show_keyboard_dialog != null && show_keyboard_dialog.isVisible())
                  show_keyboard_dialog.newFont(theFont, current_keymap);
         }
         action_name = "set-font-" + theFont;
         the_action = (Action)action_hash.get(action_name);
         the_action.actionPerformed(e);
         text_pane.validate();
      }
      else
      if (the_command.equals("set-font-size")) {
         action_name = "set-font-size-" + (String)font_sizes.getSelectedItem();
         the_action = (Action)action_hash.get(action_name);
         the_action.actionPerformed(e);
         text_pane.validate();
      }
      else
      if (the_command.equals("new keymap")) {
         current_keymap = (String)keymap_list.getSelectedItem();
         File keymap_file = getSelectedKeyMapFile();
         UserKeyMap.loadUserKeyMap(keymap_file);
         if (changeDialogFonts && show_keyboard_dialog.isVisible()) {
             show_keyboard_dialog.newFont((String)font_list.getSelectedItem(), current_keymap);
         }
      }
      else
      if (the_command.startsWith("open ")) {

         if (document_has_changed) {     // se dokumento estas sxangxita
            file_changed_dialog.showIt();
            String decision = file_changed_dialog.getDecision();
            if (decision.equals("yes")) {
               save_to_disk(false);  // Konservu gxin.
            }
            if (decision.equals("cancel")) {
               return;
            }
         }

         String file_name = the_command.substring(5);
         File file_to_get = new File(file_name);
         load_file_to_doc(file_to_get);
      }

   }  // actionPerformed



   // For the MouseListener Interface.  
   // Auxskultu la muson.
   public void mouseClicked(MouseEvent evt) {
      adjustFontLists();
      validate();
   }
   public void mouseEntered(MouseEvent evt) { }
   public void mouseExited(MouseEvent evt) { }
   public void mousePressed(MouseEvent evt) { }
   public void mouseReleased(MouseEvent evt) { }

   // For the KeyListener Interface.
   // Auxskultu la klavaron.
   public void keyTyped(KeyEvent ke) {}
   public void keyPressed(KeyEvent ke) {}
   public void keyReleased(KeyEvent ke) {
      int key_code = ke.getKeyCode();
      if (key_code == KeyEvent.VK_LEFT ||
          key_code == KeyEvent.VK_RIGHT ||
          key_code == KeyEvent.VK_UP ||
          key_code == KeyEvent.VK_DOWN) {
         adjustFontLists();
      }
   }


   // For the PopupMenuListener Interface.  
   // Auxskultu la listmenuojn (?).
   public void popupMenuCanceled(PopupMenuEvent e)  {  }
   public void popupMenuWillBecomeVisible(PopupMenuEvent e)  {  }
   public void popupMenuWillBecomeInvisible(PopupMenuEvent e)  {
         text_pane.requestFocusInWindow();
   }



   ////////////////////////////////////////////////////////////////////////////
   // Methods related to document events. The goal is to detect when a document
   // changes, in order to decide if it needs to be saved.
   // Metodoj kiuj rilatas al dokument-eventoj. La celo estas determini kiam
   // dokumento sxangxigxas, por decidi cxu necesas konservi gxin. 
   //


   /*
    * newDoc - Make a new document. 
    * newDoc - Kreu novan dokumenton. 
    */

   void newDoc () {
      int fontSize;
      fi = new FileInformation();   
      doc = (StyledDocument)the_editor_kit.createDefaultDocument();
      SimpleAttributeSet font_attr = new SimpleAttributeSet();
      StyleConstants.setFontFamily(font_attr, (String)font_list.getSelectedItem());
      try {
         fontSize = Integer.parseInt((String)font_sizes.getSelectedItem());
      } catch (NumberFormatException nfx) { fontSize = 14; }
      if (fontSize > 28) fontSize = 28;
      StyleConstants.setFontSize(font_attr, fontSize);
      StyleConstants.setBold(font_attr, false);
      StyleConstants.setItalic(font_attr, false);
      StyleConstants.setUnderline(font_attr, false);
      //StyleConstants.setLeftIndent(font_attr,10.0f);
      //StyleConstants.setRightIndent(font_attr,10.0f);
      doc.setParagraphAttributes(0,doc.getLength(), font_attr, false);
      text_pane.setStyledDocument(doc);
      text_pane.requestFocusInWindow();
      text_pane.validate();
      document_has_changed = false;
      createFileChooser();
      setDocListener();
   }

   /*
    * setDocListener - Set the document listener. 
    * setDocListener - Initu la dokument-auxskultanton. 
    */
   private void setDocListener() {
      doc.addDocumentListener(this);
      doc.addUndoableEditListener(new SimUndoableEditListener());
   }  // set_doc_listener


   /*
    * loadDocFromString - For loading simple text. 
    * loadDocFromString - Por sxargi simplan tekston.
    */

   void loadDocFromString (String the_text) {

      int  fontSize;

      doc = (StyledDocument)the_editor_kit.createDefaultDocument();
      SimpleAttributeSet font_attr = new SimpleAttributeSet();
      StyleConstants.setFontFamily(font_attr, (String)font_list.getSelectedItem());
      try {
         fontSize = Integer.parseInt((String)font_sizes.getSelectedItem());
      } catch (NumberFormatException nfx) { fontSize = 14; }
      StyleConstants.setFontSize(font_attr, fontSize);
      StyleConstants.setBold(font_attr, false);
      StyleConstants.setItalic(font_attr, false);
      StyleConstants.setUnderline(font_attr, false);
      doc.setParagraphAttributes(0,doc.getLength(), font_attr, false);

      try {
          doc.insertString(0, the_text, font_attr);
      } catch (BadLocationException ble) {
         System.err.println("loadDocFromString: Bad Location. / Malbona pozicio. " + 
                             ble.getMessage());
      }

      text_pane.setStyledDocument(doc);
      text_pane.requestFocusInWindow();
      text_pane.validate();
      document_has_changed = false;
      createFileChooser();
      setDocListener();
   }


   /*
    * loadRTF - For loading RTF files. 
    * loadRTF - Por sxargi RTF-dosierojn.
    */

   void loadRTF (File file_to_open) {

      // Nova dokumento.
      doc = (StyledDocument)the_editor_kit.createDefaultDocument();
      text_pane.setStyledDocument(doc);

      try {
         FileInputStream fin;
         fin = new FileInputStream(file_to_open);
         the_editor_kit.read(fin, text_pane.getDocument(), 0);
         fin.close();
      } catch (BadLocationException ble) {
         System.err.println("loadRTF: Bad Location. / Malbona pozicio. \n" + ble.getMessage());
      } catch (IOException io) {
         System.err.println("loadRTF: I/O error. Eraro dum legado. \n" + io.getMessage());
      }

      text_pane.requestFocusInWindow();
      text_pane.validate();
      document_has_changed = false;
      createFileChooser();
      setDocListener();

  }  // loadRTF


   // The following 3 methods are part of the DocumentListener Interface.
   // La sekvantaj 3 metodoj plenumas la dokument-auxskultan interfacon.

   public void changedUpdate(DocumentEvent de) {
      // Empty document events are generated when a file is loaded.
      // Don't set document changed.
      // Malplenaj dokumentaj eventoj estas senditaj kiam dosieroj estas malfermataj.
      // Ne sxangxu la dokument-sxangxita-flagon.
      if (!de.toString().equals("[]")) {
         document_has_changed = true;
      }
       //System.err.println("this is change" + de.toString());
   }

   public void insertUpdate(DocumentEvent de) {
      // System.err.println("this is insert" + de.toString());
      document_has_changed = true;
   }

   public void removeUpdate(DocumentEvent de) {
      // System.err.println("this is remove" + de.toString());
      document_has_changed = true;
   }


////////////////////////////////////////////////////////////
// Action Classes   / Agklasoj


   /**
    * NewFile - Action class to create a new document.
    * NewFile - Agoklaso por krei novan dokumenton.
    */
   class NewFile extends AbstractAction {

      NewFile(String default_label) {
         super(default_label);
      }

      NewFile(String default_label, Icon the_icon) {
         super(default_label, the_icon);
      }

      public void actionPerformed(ActionEvent e) {

         if (document_has_changed) {     // se dokumento estas sxangxita
            file_changed_dialog.showIt();
            String decision = file_changed_dialog.getDecision();
            if (decision.equals("yes")) {
               save_to_disk(false);  // Konservu gxin.
            }
            if (decision.equals("cancel")) {
               return;
            }
         }

         newDoc();

         // Show the file name in the frame.
         // Montru nomon en supra trabo de kadro.
         set_title(new_document_text);          // New Document  / Nova Dokumento
         validate();
         text_pane.requestFocusInWindow();

      }  // actionPerformed

   }  // class NewFile


   /**
    * OpenFile - Action class to open a file.
    * OpenFile - Agoklaso por malfermi dosieron.
    */
   class OpenFile extends AbstractAction {

      OpenFile(String default_label) {
         super(default_label);
      }

      OpenFile(String default_label, Icon the_icon) {
         super(default_label, the_icon);
      }

      public void actionPerformed(ActionEvent e) {

         File  file_to_open;   // malfermota dosiero

         if (document_has_changed) {     // se dokumento estas sxangxita
            file_changed_dialog.showIt();
            String decision = file_changed_dialog.getDecision();
            if (decision.equals("yes")) {
               save_to_disk(false);  // Konservu gxin.
            }
            if (decision.equals("cancel")) {
               text_pane.requestFocusInWindow();
               return;
            }
         }

         // Create a file dialog, if it doesn't already exist.
         // Kreu dosierodialogon, se gxi ne jam ekzistas.
         if (file_chooser == null) {
            createFileChooser();
         } 
         file_chooser.rescanCurrentDirectory();

         // Choose the file. Elektu la dosieron.
         file_chooser.setDialogTitle(open_text);
         file_chooser.setApproveButtonText(approve_text);
         int returnVal = file_chooser.showOpenDialog(frame);
         if(returnVal == JFileChooser.APPROVE_OPTION) { 
            file_to_open = file_chooser.getSelectedFile();
         }
         else {
            text_pane.requestFocusInWindow();
            return;
         }
         load_file_to_doc(file_to_open);
         text_pane.requestFocusInWindow();

      }  // actionPerformed

   }  // class OpenFile



   /*
    * set_title - Write the file name and current mode on the frame bar.
    * set_title - Skribu la dosieronomon kaj nunan regximon sur la kadrotrabo.
    */
   protected void set_title (String file_name) {
      String field1 = file_name;
      if (field1 == null) field1 = "";
      frame.setTitle("  " + field1);
   } // set_title


   /**
    * load_file_to_doc - This method reads a file and puts it into a document
    * object. It sets the text_pane, writes to the list of previously edited files
    * (file_list), and recreates the file menu.
    *
    * load_file_to_doc - Cxi tiu metodo legas dosieron kaj metas gxin en dokument-
    * objekton. Gxi plenigas la tekst-objekton (text_pane), skribas al la listo de
    * antauxe redaktitaj dosieroj (file_list), kaj rekreas la dokument-menuon. 
    */

   protected void load_file_to_doc (File file_to_open) {

      FileInformation     fi_temporary;   // portempa

      String  decoded_contents;    // from file / de dosiero
      String  temp;
      String  script;

      String  decision = "";  

      // Detect creates a FileInformation object.
      // 'Detect' kreas novan FileInformation objekton.
      fi_temporary = Detect.whatIsIt(file_to_open);

      if (fi_temporary == null || fi_temporary.status == FileInformation.CANT_LOAD) {
         timed_message.showIt(TimedMessage.CANT_OPEN_FILE);
         System.err.println("Could not open file. " + 
                            "Ne povis malfermi dosieron. -FI- ");
         return;
      }

      fi_temporary.fileName = file_to_open.getPath();

      if (fi_temporary.encoding.equals("RTF")) {
         loadRTF(file_to_open);
      }
      else {
         if (fi_temporary.encoding.equals("Encrypted")) {
            decoded_contents = readEncrypted(file_to_open);
         }
         else if (fi_temporary.encoding.startsWith("UTF-16")) {
            decoded_contents = readChars(file_to_open, fi_temporary.encoding);
         }
         else {
            open_convert_dialog.showIt(fi_temporary.encoding);
            fi_temporary.encoding = open_convert_dialog.getDecision();
            if (fi_temporary.encoding.equals("")) fi_temporary.encoding = "ISO8859_1";
            if (fi_temporary.encoding.equals("Iran")) {
               decoded_contents = SimIran.convertIranUni(getByteBuffer(file_to_open));
            }
            else if (fi_temporary.encoding.startsWith("ISCII")) {
		  /* Added to Open the file in ISCII - Surekha Jan'27'04 */
               temp = readChars(file_to_open, "ISO8859_1");
               decoded_contents = isciiConverterObject.convertIsciiToUnicode(temp, getLang(fi_temporary.encoding));
            }
            else if (fi_temporary.encoding.startsWith("WX")) {
		  /* Added to Open the file in ISCII - Surekha Jan'27'04 */
               temp = readChars(file_to_open, "ISO8859_1");
               decoded_contents = isciiConverterObject.convertWxToUnicode(temp, getLang(fi_temporary.encoding));
            }
            else {
               decoded_contents = readChars(file_to_open, fi_temporary.encoding);
            }
         }

         if (decoded_contents == null) {
            timed_message.showIt(TimedMessage.CANT_OPEN_FILE);
            System.err.println("Could not open file. / " + 
                            "Ne povis malfermi dosieron.");
            return;   // Quit if no success. Eliru se ne sukcesis.
         }

         loadDocFromString(decoded_contents);
      }

      fi = fi_temporary;
      set_title(fi.fileName + "   " + fi.encoding);
      putIntoFileList(fi.fileName); 

      // Recreate the file menu. Rekreu la dokument-menuon.
      file_menu.removeAll();
      initializeFileMenu(file_menu);
      validate();

      document_has_changed = false;

   }  // load_file_to_doc


   /**
    * readChars - Read the contents of a file into a string.
    * readChars - Metu la enhavon de dosieron en cxenon.
    */
   private String readChars(File file_to_open, String encoding) {

      char[]  buffer;
      int     maxSize = (int)file_to_open.length();
      long    numberRead;

      InputStreamReader fin;

      try {
         fin = new InputStreamReader(new FileInputStream(file_to_open), encoding);
      }
      catch (FileNotFoundException fnf) {
         timed_message.showIt(TimedMessage.CANT_OPEN_FILE);
         System.err.println("readChars: File not found. " + 
                            "Ne povis trovi dosieron. \n" + fnf.toString());
         return "";
      }
      catch (UnsupportedEncodingException uex) {
         timed_message.showIt(TimedMessage.CANT_OPEN_FILE);
         System.err.println("readChars: Unknown encoding. " + 
                            "Nekonata kodaro. \n" + uex.toString());
         return "";
      }

      try {
         buffer = new char[maxSize];
         numberRead = fin.read(buffer, 0, maxSize);
         System.out.println("Number read / nombro legitaj: " + numberRead);
      }
      catch (Exception e) {
         timed_message.showIt(TimedMessage.CANT_OPEN_FILE);
         System.err.println("readChars: Error while reading. Eraro dum legado.\n" +
                             e.toString());
         return "";
      }
      if (numberRead == 0) return "";

      // Remove first character for UTF-16
      // Forigu unuan signon se UTF-16
      if (numberRead > 1 && buffer[0] == 0xFEFF && encoding.startsWith("UTF-16",0)) {
         return new String(buffer, 1, (int)numberRead - 1);
      }
      else {
         return new String(buffer, 0, (int)numberRead);
      }
   }
   

   /**
    * getByteBuffer - Read the contents of a file into an array of bytes.
    * getByteBuffer - Metu la enhavon de dosieron en matricon de bitokoj.
    */
   private byte[] getByteBuffer(File file_to_open) {

      byte[]   byte_buffer;
      int      file_length;

      if (!file_to_open.exists()) {       // Se la dosiero ne ekzistas...
          System.err.println("Ooops, file not found. Ho ve, dosiero netrovita. " 
                              + file_to_open.getPath());
          return null;
      }
      try {
         file_length = (int)file_to_open.length();
         byte_buffer = new byte[file_length];
         FileInputStream fin = new FileInputStream(file_to_open);
         fin.read(byte_buffer);
         fin.close();
         return byte_buffer;
      } catch (IOException io) {
         System.err.println("I/O error. Eraro dum legado. " + io.getMessage());
         return null;
      } 

   } // end of getByteBuffer



   /**
    * readEncrypted - Read and decrypt an encrypted file.
    * readEncrypted - Legu kaj malkriptigu kriptigitan dosieron.
    */
   private String readEncrypted (File file_to_open) {

      String decrypted;
      char[] encryption_key;

      // Get encryption key. Akiru kriptigan sxlosilon.
      open_key_dialog.showIt();
      encryption_key = open_key_dialog.getKey();

      decrypted = Encrypt.decrypt2(getByteBuffer(file_to_open), encryption_key);
      if (decrypted != null) {  // sukceso
         this.encryption_key = encryption_key;
         return decrypted;
      }
      // If encryption key was bad.    Se sxlosilo estas malgxusta.
      return null;
   }


/////////////////////////////////////////////////////////////////////////////////////


   /**
    * SaveFile - Action class to save a file.
    * SaveFile - Agoklaso por konservi dosieron.
    */
   class SaveFile extends AbstractAction {

      SaveFile(String default_label) {
         super(default_label);
      }

      SaveFile(String default_label, Icon the_icon) {
         super(default_label, the_icon);
      }

      public void actionPerformed(ActionEvent e) {
         save_to_disk(false);
         text_pane.requestFocusInWindow();
      }  // actionPerformed

   }  // SaveFile


   /**
    * SaveFileAs - Action class to save a file. This Action shows the file dialogue.
    * SaveFileAs - Agoklaso por konservi dosieron. Cxi tiu Agklaso montras la dosiero-dialogon.
    */
   class SaveFileAs extends AbstractAction {

      SaveFileAs(String default_label) {
         super(default_label);
      }

      public void actionPerformed(ActionEvent e) {
         save_to_disk(true);  // Show the file dialogue. Montru la dosiero-dialogon.
      }  // actionPerformed

   }  // SaveFileAs



   /**
    * save_to_disk - This method writes the current document out to the disk.
    * The parameter must_ask_for_filename forces the method to show the file 
    * chooser dialog.
    *
    * save_to_disk - Cxi tiu metodo skribas la nunan dokumenton al la disko. 
    * La parametro must_ask_for_filename (devas demandi dosieronomon) devigas la
    * metodon montri la dosiero-dialogon.
    */
   protected void save_to_disk (boolean must_ask_for_filename) {

      String  decision = fi.encoding;  // Which format to use. Kiun formaton por uzi.

      Document  doc = text_pane.getDocument();
      Segment   segment;    // Segment of text from doc.   Segmento de teksto el doc.

      File  file_to_save;   // konservota dosiero

      // Create a file dialog.
      // Kreu dosierodialogon.
      createFileChooser();

      // If the current document doesn't have a name, or the must_ask_for_filename
      // flag is set, show the file chooser to select a name (and location).
      // Otherwise, just use the fileName.
      // Se la nuna dokumento ne havas nomon, aux la "devas-demandi-nomon"-flagon
      // estas aktiva, montru la dosiero-dialogon por selekti nomon (kaj dosierujon).
      // Alie, uzu la nomon en "fileName".
      if (fi.fileName == null || must_ask_for_filename || fi.encoding == null) {

         // First, ask for the conversion format for the output file.
         // Unue, demandu la konvert-formaton por la konservota dokumento.
         if (fi.encoding == null) save_convert_dialog.showIt("RTF");
         else save_convert_dialog.showIt(fi.encoding);
         decision = save_convert_dialog.getDecision();

         // If user chooses "encrypted" display a dialogue to ask for the encryption key.
         // Se uzanto elektas "kripta" montru dialogon por peti la sxlosilon.
         if (decision.equals("Encrypted")) {
               save_key_dialog.showIt(encryption_key);
               encryption_key = save_key_dialog.getKey();
            if (encryption_key == null) {
               error_dialog.showIt(invalid_key_message + " -E-");
               return;
            }
         }
         // Choose a file name. Elektu dosieronomon.
         file_chooser.setDialogTitle(save_text);
         file_chooser.setApproveButtonText(approve_text);
         int returnVal = file_chooser.showSaveDialog(frame);
         if(returnVal == JFileChooser.APPROVE_OPTION) { 
            file_to_save = file_chooser.getSelectedFile();
            // If the file already exists, ask the user if he/she wants to overwrite.
            // Se la dosiero jam ekzistas, demandu al la uzanto cxu li/sxi volas surskribi.
            if (file_to_save.exists()) {
               exists_dialog.showIt();
               if (exists_dialog.getDecision().equals("no")) return;
            }
         }
         else {
            return;
         }
      }
      else {
         file_to_save = new File(fi.fileName);
      } 

      System.out.println("Save file. Konservu dosieron. " + fi.fileName); 

      try {

         FileOutputStream fout = new FileOutputStream(file_to_save);
         OutputStreamWriter w;

         if (decision.equals("RTF")) {
            try {
               the_editor_kit.write(fout, doc, 0, doc.getLength());
               timed_message.showIt(TimedMessage.FILE_SAVED);
            } catch (BadLocationException blx) {
               error_dialog.showIt(cant_save_message + " -blx-");
               System.err.println("Could not save file. Ne povis konservi dosieron. -blx-\n" + 
                          blx.getMessage());
               return;
            } catch (IOException iox) {
               error_dialog.showIt(cant_save_message + " -iox-");
               System.err.println("Could not save file. Ne povis konservi dosieron. -iox-\n" + 
                          iox.getMessage());
               return;
            }
         }
         else 
         if (decision.equals("Encrypted")) {
            // At this point there should be an encryption key.
            // Cxi tie devas ekzisti kriptosxlosilo.
            if (encryption_key != null) {
               // Get the text into a segment. Metu la tekston en "segment"
               try {
                  segment = getSegment(doc);
                  Encrypt.writeEncrypted(fout, segment, encryption_key);
                  timed_message.showIt(TimedMessage.FILE_SAVED);
               } catch ( IOException s ) {
                  error_dialog.showIt(cant_save_message + " -G-");
                  System.err.println("Could not save file. Ne povis konservi dosieron. -G- \n" + 
                             s.getMessage());
                  return;
               }  // try/catch
            }
            else {
               error_dialog.showIt(cant_save_message + " -K-");
               System.err.println
                 ("Did not save encrypted file. Ne konservis kriptigitan dosieron. -K- ");
               return;
            }
         }
         else
	   /* Code to save a file in ISCII encoding. Call the conversion routine from Unicode to ISCII. Added by Surekha on Jan27'04 */	 
         if (decision.startsWith("ISCII") || decision.startsWith("WX")) { 
            String indString = "";
            int length = doc.getLength();
            try {
               String text = doc.getText(0, length);
               if (decision.startsWith("ISCII")) {
                  indString = isciiConverterObject.convertUnicodeToIscii(text, getLang(decision));
               }
               else {
                  indString = isciiConverterObject.convertUnicodeToWx(text, getLang(decision));
               }
               w = new OutputStreamWriter(fout,"ISO-8859-1");
               w.write(indString, 0, indString.length());
               w.close();
            }
            catch(IOException iox) {
               error_dialog.showIt(cant_save_message + " -F-");
               System.err.print("Could not save file, ISCII or WX. \n");
               System.err.println("Ne povas konservi dosieron, ISCII aux WX. " + iox.getMessage());
               return;
            }
            catch(BadLocationException blx) {
               error_dialog.showIt(cant_save_message + " -F-");
               System.err.print("Bad Location, ISCII or WX. \n");
               System.err.println("Malbona pozicio, ISCII aux WX. " + blx.getMessage());
               return;
            }
            timed_message.showIt(TimedMessage.FILE_SAVED);
	      //end of code -- surekha.
         }
         else   /* convert to Iran System  / konvertu al Irana Sistemo */
         if (decision.equals("Iran")) { 
               // Get the text into a segment. Metu la tekston en "segment"
               segment = getSegment(doc);
               try {
                  int i;
                  // Convert first letter. Konvertu unuan literon.
                  fout.write( 
                     SimIran.convertUniIran('a',segment.array[segment.offset + 0],
                                                segment.array[segment.offset + 1])
                  );

                  for (i = 1; i < segment.count - 1; i++) {
                     fout.write( 
                        SimIran.convertUniIran(segment.array[segment.offset + i - 1], 
                                               segment.array[segment.offset + i], 
                                               segment.array[segment.offset + i + 1]
                        )
                     );
                  }
                  // Convert last letter. Konvertu lastan literon.
                  fout.write( 
                     SimIran.convertUniIran(segment.array[segment.offset + i - 1], 
                                            segment.array[segment.offset + i],'a')
                  );
                  timed_message.showIt(TimedMessage.FILE_SAVED);
               } catch ( IOException r ) {
                  error_dialog.showIt(cant_save_message + " -C-");
                  System.err.println("Could not save file. Ne povis konservi dosieron. -C- \n" + 
                             r.getMessage());
                  return;
               }  // try/catch
         }
         else {
            try {
               segment = getSegment(doc);
               w = new OutputStreamWriter(fout, decision);
               if (decision.startsWith("UTF-16")) w.write(0xFEFF);
               w.write(segment.array, segment.offset, segment.count);
               w.close();
               timed_message.showIt(TimedMessage.FILE_SAVED);
            } catch (IOException iox) {
               error_dialog.showIt(cant_save_message + " -iox-");
               System.err.println("Could not save file. Ne povis konservi dosieron. -iox-\n" + 
                          iox.getMessage());
               return;
            } 
         }
         
         fout.close();
         document_has_changed = false;

         // Show the file name in the frame.
         // Montru nomon en supra trabo de kadro.
         fi.fileName = file_to_save.getPath();
         // Don't use getName. It doesn't return the full path.
         // Ne uzu getName. Gxi ne redonas la kompletan nomon.
         fi.encoding = decision;
         set_title(fi.fileName + "    " + fi.encoding); 
         putIntoFileList(fi.fileName); 
         // Recreate the file menu.     Rekreu la dokument-menuon.
         file_menu.removeAll();
         initializeFileMenu(file_menu);
         System.out.println("Number of bytes/ Nombro da bitokoj: " + 
                             (int)(file_to_save.length()));
      } catch (IOException io) {
         error_dialog.showIt(cant_save_message + " -D-");
         System.err.println
           ("Could not save file. Ne povis konservi dosieron. -D- \n" + io.getMessage());
         return;
      }

      file_chooser.rescanCurrentDirectory();

   }  // save_to_disk


   // getScript - For Indian conversions. Gets the language from between brackets.
   // eg. WX (Devanagari)  -> Devanagari
   // Por Hindaj konvertoj. Akiras la lingvon inter krampoj.
   // ekz: WX (Devanagari) -> Devanagari

   private String getLang(String str) {
      int s = str.indexOf("(") + 1;
      int e = str.lastIndexOf(")");
      return str.substring(s, e);
   }

   /////////////////////////////////////
   // Get an image from the JAR file.
   // Akiru bildon de la JAR-dosiero.
   private ImageIcon getJarImage(String name) {
      InputStream in = null; 
      byte[] b = null; 
      int size = 0; 
      in = getClass().getResourceAsStream("/" + name); 
      try { 
          size = in.available(); 
          b = new byte[size]; 
          in.read(b); 
      } catch(IOException e) {
          System.err.println("Problem getting icons. Problemo dum legado de ikonoj.");
      } 
      return new ImageIcon(b); 
   } 


   /*
    *  Returns the selected font name.
    *  Redonas la nomon de la selektita tiparo.
    */
   public String getSelectedFontName() {
      String the_name;
      the_name = (String)font_list.getSelectedItem();
      return the_name;
   }  // getSelectedFontName



   /*
    * adjustFontLists()
    * Adjusts the font family and font size lists according to the
    * current position of the caret.
    * Gxustigas la tiparfamilian kaj tipargrandecan listojn laux
    * la aktuala pozicio de la tekstmarkilo.
    */

   boolean  changeDialogFonts = true;
   public void adjustFontLists() {
      String fontName;
      String strSize;
      changeDialogFonts = false;
      AttributeSet atset = the_editor_kit.getCharacterAttributeRun().getAttributes();
      Enumeration enu    = atset.getAttributeNames();
      for (; enu.hasMoreElements() ;) {
         Object o = enu.nextElement();
         if (o.toString().equals("family")) {
            fontName = atset.getAttribute(o).toString();
            font_list.setSelectedItem(fontName);
         }
         else if (o.toString().equals("size")) {
            strSize = atset.getAttribute(o).toString();
            font_sizes.setSelectedItem(strSize);
         }
         // System.out.println(atset.getAttribute(o).toString());
      }
      changeDialogFonts = true;
      return;
   }  // adjustFontLists


//////////////////////////////////////////////////////////////



   Segment getSegment(Document doc) {
      Segment segment = new Segment();
      try {
         if (doc != null) doc.getText(0, doc.getLength(), segment);
      } catch (BadLocationException bad) {
         error_dialog.showIt(cant_save_message + " -E-");
         System.err.println("Segment error. Eraro de segmento. -E- \n" 
                             + bad.getMessage());
      }

      // For some strange reason, there are two spaces and a return code at the
      // front of the an HTMLDocument. Remove them.
      // Ial, estas du spacoj kaj reirokodo cxe la komenco de HTMLDocument. Forigu ilin.
//      if (segment.count > 3) {
//         String junk = new String(segment.array, segment.offset, 3);
//         if (junk.equals("  \n")) {
//            segment.count = segment.count - 3;
//            segment.offset = segment.offset + 3;
//         }
//      }
      return segment;
   }



   /**
    * Exit - Action class to exit the program.
    * Exit - Agklaso por fermi la programon.
    */
   class Exit extends AbstractAction {

      Exit(String default_label) {
         super(default_label);
      }

      public void actionPerformed(ActionEvent e) {

         if (document_has_changed) {     // se dokumento estas sxangxita
            file_changed_dialog.showIt();
            String decision = file_changed_dialog.getDecision();
            if (decision.equals("yes")) {
               save_to_disk(false);  // Konservu gxin.
            }
            if (decision.equals("cancel")) {
               return;
            }
         }

         saveFileList();
         saveDefaultFont();
         System.exit(0);

      }  // actionPerformed

   }  // Exit



   /**
    * ShowSearch - Action class show the search dialogue.
    * ShowSearch - Agklaso por montri sercxodialogon.
    */
   class ShowSearch extends AbstractAction {

      ShowSearch(String default_label) {
         super(default_label);
      }

      ShowSearch(String default_label, Icon the_icon) {
         super(default_label, the_icon);
      }

      public void actionPerformed(ActionEvent e) {
         search_dialog.showIt(text_pane);
      }  // actionPerformed

   }  // ShowSearch





   /**
    * SearchUpx - Action class to search upward.
    * SearchUpx - Agoklaso por sercxi supren.
    */
   public class SearchUpx extends AbstractAction {

      SearchUpx(String default_label) {
         super(default_label);
      }

      SearchUpx(String default_label, Icon the_icon) {
         super(default_label, the_icon);
      }

      public void actionPerformed(ActionEvent e) {
         search_dialog.search_up();
         text_pane.requestFocusInWindow();
      }  // actionPerformed

   }  // SearchUpx



   /**
    * SearchDownx - Action class to search downward.
    * SearchDownx - Agoklaso por sercxi malsupren.
    */
   public class SearchDownx extends AbstractAction {

      SearchDownx(String default_label) {
         super(default_label);
      }


      SearchDownx(String default_label, Icon the_icon) {
         super(default_label, the_icon);
      }

      public void actionPerformed(ActionEvent e) {
         search_dialog.search_down();
         text_pane.requestFocusInWindow();
      }  // actionPerformed

   }  // SearchDownx



   /**
    * ShowChange - Action class show the change dialogue.
    * ShowChange - Agklaso por montri sxangxodialogon.
    */
   class ShowChange extends AbstractAction {

      ShowChange(String default_label) {
         super(default_label);
      }
      public void actionPerformed(ActionEvent e) {
         change_dialog.showIt(text_pane);
      }  // actionPerformed

   }  // ShowChange



   /**
    * ShowConvertDialog - Action class show the convert dialog.
    * ShowConvertDialog - Agklaso por montri konvert-dialogon.
    */
   class ShowConvertDialog extends AbstractAction {

      ShowConvertDialog(String default_label) {
         super(default_label);
      }
      public void actionPerformed(ActionEvent e) {
         convert_dialog.showIt(text_pane);
      }  // actionPerformed

   }  // ShowConvertDialog



   /**
    * PrintIt - Action class to print the document.
    * PrintIt - Agklaso por presi la dokumenton.
    */
   class PrintIt extends AbstractAction {

      PrintIt(String default_label) {
         super(default_label);
      }

      public void actionPerformed(ActionEvent e) {

/*
         I couldn't get the following code to work. (Japanese Windows 95, Java 1.2)
         Mi ne sukcesis presi per la sekvantaj instrukcioj. (Japana Vindozo 95, Gxavo 1.2)
         PrintJob print_job = my_toolkit.getPrintJob(frame,"Simredo Print Job",my_properties);
         if (print_job != null) {
            Graphics g = print_job.getGraphics();
            if (g != null) {
               g.translate(0,0);
               text_pane.printAll(g);
               g.dispose();
               print_job.end();
            }
         }
*/
         // This works. Cxi tio funkcias.
         PrinterJob  job = PrinterJob.getPrinterJob(); 
         Paper       paper = new Paper();
         // The imageable height must be a multiple of the font size, less than 720.
         // La desegnebla alteco devas esti oblo de la tipara grandeco, malpli ol 720.
         double font_height = text_pane.heightOfFont();
         int lines_per_page = (int)(720.0 / font_height);
         paper.setImageableArea(36.0,36.0,540.0,(double)lines_per_page * font_height);
         double paperh = paper.getHeight(); 
         double paperw = paper.getWidth(); 
         double imagex = paper.getImageableX(); 
         double imagey = paper.getImageableY(); 
         double imagewidth = paper.getImageableWidth(); 
         double imageheight = paper.getImageableHeight(); 
         System.out.println("Font height. Tipara alteco.  " + font_height);
         System.out.println("Page  w " + paperw + "  h " + paperh);
         System.out.println("Image   x " + imagex + "  y " + imagey + 
                            "  w " + imagewidth + "  h " + imageheight);
         PageFormat  pf = new PageFormat();
         pf.setPaper(paper);
         job.setPrintable(text_pane,pf);
         PageDivider pd = new PageDivider(text_pane, pf);
         job.setPageable(pd);
         text_pane.repaint();
         if (job.printDialog()) {
            try {
               job.print();
            } catch (Exception ex) { 
               System.err.println("Print Error. Presada Eraro. " + ex.toString()); 
            }
         } // if

      }  // actionPerformed

   }  // PrintIt


   /**
    * ShowSpellDialog - Action class to display the Spell Dialogue.
    * Agklaso por montri dialogon de literumado.
    */
   class ShowSpellDialog extends AbstractAction {

      ShowSpellDialog(String default_label) {
         super(default_label);
      }

      public void actionPerformed(ActionEvent e) {
         spell_dialog.showIt(text_pane);
      }

   }  // ShowSpellDialog


   /**
    * ReverseText - Reverses the order of letters on each line.
    * This is useful for making Persian homepages for browsers which
    * cannot display right to left text.
    * ReverseText - Inversigas la ordon de literoj en cxiu linio.
    * Cxi tio utilas por krei html-pagxojn por foliumiloj kiuj ne kapablas
    * montri tekston kiu fluas de la dekstro.
    */
   class ReverseText extends AbstractAction {

      ReverseText(String default_label) {
         super(default_label);
      }

      public void actionPerformed(ActionEvent e) {
         text_pane.reverseText();
      }  // actionPerformed

   }  // ReverseText


   /**
    * ShowChars - Show the complete Unicode character set for the current font.
    * ShowChars - Montru la tutan Unikodan kodaron por la aktiva tiparo.
    */
   class ShowChars extends AbstractAction {

      ShowChars(String default_label) {
         super(default_label);
      }

      public void actionPerformed(ActionEvent e) {
         show_chars_dialog.showIt((String)font_list.getSelectedItem());
      }  // actionPerformed

   }  // ShowChars


   /**
    * ShowColourSelectorDialog - Action class show the colour selector.
    * ShowColourSelectorDialog - Agklaso por montri kolorselektilon.
    */

    class ShowColourSelectorDialog extends AbstractAction {

      ShowColourSelectorDialog(String default_label) {
         super(default_label);
      }

      ShowColourSelectorDialog(String default_label, Icon the_icon) {
         super(default_label, the_icon);
      }

      public void actionPerformed(ActionEvent e) {
         colour_selector_dialog.setVisible(true);
      }  // actionPerformed

   }  // ShowColourSelectorDialog


   /**
    * Closer - This class closes the program.
    * Closer - Cxi tiu klaso fermas la programon.
    */
   class Closer extends WindowAdapter {

      public Closer() {
         super();
      }

      public void windowClosing(WindowEvent e) {
         if (document_has_changed) {     // se dokumento estas sxangxita
            file_changed_dialog.showIt();
            String decision = file_changed_dialog.getDecision();
            if (decision.equals("yes")) {
               save_to_disk(false);  // Konservu gxin.
            }
            if (decision.equals("cancel")) {  
               return;   // Ne fermu la programon.
            }
         }
         saveFileList();
         saveDefaultFont();
         System.exit(0);
      }
   }  // Closer



   /**
    * SimIconAction - This action class is used to display an icon. 
    *                 It calls action classes defined in the hash table.
    * SimIconAction - Cxi tiu klaso estas uzata por afisxi ikonon.
    *                 Gxi vokas agklasoj difinitaj en la agklasa tabelo.  
    */

   class SimIconAction extends AbstractAction {

      Action  the_action;

      SimIconAction(String default_label) {
         super(default_label);
      }

      SimIconAction(String default_label, Icon the_icon) {
         super(default_label, the_icon);
      }

      public void actionPerformed(ActionEvent e) {
         the_action = (Action)action_hash.get(getValue(NAME));
         if (the_action != null) the_action.actionPerformed(e);
         text_pane.requestFocusInWindow();
      }  // actionPerformed

   }  // SimIconAction



   /**
    * ToggleKeyMap - Turn the keymap on or off.
    * ToggleKeyMap - Sxaltu aux malsxaltu la klavmapon.
    */
   class ToggleKeyMap extends AbstractAction {

      ToggleKeyMap(String default_label) {
         super(default_label);
      }

      public void actionPerformed(ActionEvent e) {
         changeDialogFonts = false;
         if (UserKeyMap.isEnabled()) {
            saved_keymap = current_keymap;
            UserKeyMap.setEnabled(false);
            keymap_list.setSelectedIndex(0);
         }
         else 
         if (!UserKeyMap.isEnabled() && !saved_keymap.equals("")) {
            UserKeyMap.setEnabled(true);
            current_keymap = saved_keymap;
            keymap_list.setSelectedItem(current_keymap);
            saved_keymap = "";
         }
         changeDialogFonts = true;
      }  // actionPerformed

   }  // ToggleKeyMap


   /*
    * ShowKeyboard - Show the keyboard arrangement.
    * ShowKeyboard - Montru la Klavarangxon.
    * Added by rawat 2004/06/06 for keyboard display
    */
   class ShowKeyboard extends AbstractAction {

      ShowKeyboard(String default_label) {
         super(default_label);
      }

      public void actionPerformed(ActionEvent e) {
         if (UserKeyMap.key_table == null) UserKeyMap.loadUserKeyMap(null);  // initialize tables
         show_keyboard_dialog.showIt((String)font_list.getSelectedItem(), current_keymap);
         text_pane.requestFocusInWindow();
      }

   }  // ShowKeyboard


   /**
    * ChangeDirection - Action class to change the typing direction:
    * left to right or right to left. (For Arabic, Hebrew, etc.)
    *
    * ChangeDirection - Agklaso por sxangxi la direkton de tajpado:
    * maldekstro al dekstro aux dekstro al maldekstro. (Por la araba, hebrea, ktp.)
    */

    class ChangeDirection  extends AbstractAction {

      ChangeDirection (String default_label) {
         super(default_label);
      }

      ChangeDirection (String default_label, Icon the_icon) {
         super(default_label, the_icon);
      }

      public void actionPerformed(ActionEvent e) {
         if (left_to_right) {
            rightToLeft();
            left_to_right = false;
         }
         else {
            leftToRight();
            left_to_right = true;
         }
         text_pane.requestFocusInWindow();
      }  // actionPerformed

   }  // ChangeDirection


   private void leftToRight () {
         text_pane.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
         toolbar.remove(17);
         toolbar.add(right2Left);
         search_dialog.changeDirection(true);
         change_dialog.changeDirection(true);
   }

   private void rightToLeft () {
         text_pane.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
         toolbar.remove(17);
         toolbar.add(left2Right);
         search_dialog.changeDirection(false);
         change_dialog.changeDirection(false);
   }


   // This little class filters file names that end in kmp (keymap)
   // Cxi tiu eta klaso filtras dosieronomojn kiuj finigxas per kmp (klavmapo)
   class KeyMapFilter implements FilenameFilter {

      KeyMapFilter() {
      }

      public boolean accept(File dir, String name) {
         if (name.toLowerCase().endsWith("kmp")) return true;
         return false;
      }
   }




   /**
    * ChangeLanguage - Action class to change the interface language
    * ChangeLanguage - (SxangxuLingvon) Agklaso por sxangxi la interfacan lingvon.
    */

    class ChangeLanguage  extends AbstractAction {

      ChangeLanguage (String default_label) {
         super(default_label);
      }

      ChangeLanguage (String default_label, Icon the_icon) {
         super(default_label, the_icon);
      }

      public void actionPerformed(ActionEvent e) {

         File simlang = new File(home_dir,"simlang.txt");

         if (simlang != null && simlang.exists()) {
            langdialog = new LangDialog(frame, simlang, current_language);
            langdialog = null;
         }

      }  // actionPerformed

   }  // ChangeLanguage





   /**
    * UndoAction - Action class to undo an editing change. Contributed by Navaneetha Krishnan.
    * UndoAction - (Malfaru) Agklaso por malfari redaktan sxangxon. Kontribuo de Navaneetha Krishnan.
    */

   class UndoAction extends AbstractAction {

      public UndoAction(String default_label) {
         super(default_label);
         setEnabled(true);
      }
          
      public void actionPerformed(ActionEvent e) {
         try {
            undo.undo();
         } catch (CannotUndoException cnudx) {
            System.err.print("Can't undo. / ");
            System.err.println("Ne povas malfari: " + cnudx.toString());
         }
         updateUndoState();
         redoAction.updateRedoState();
      }
          
      protected void updateUndoState() {
         if (undo.canUndo()) {
            setEnabled(true);
         } else {
             setEnabled(false);
         }
      } 

   }  // fino de UndoAction


   /**
    * RedoAction - Action class to redo an editing change.
    * RedoAction - (Refaru) Agklaso por refari redaktan sxangxon.
    */

   class RedoAction extends AbstractAction {

      public RedoAction(String default_label) {
         super(default_label);
         setEnabled(true);
      }

      public void actionPerformed(ActionEvent e) {

         try {
           undo.redo();
         } catch (CannotRedoException cnrdx) {
            System.err.print("Cannot redo. / ");
            System.err.println("Ne povas refari: " + cnrdx.toString());
         }
         updateRedoState();
         undoAction.updateUndoState();
      }

      protected void updateRedoState() {
         if (undo.canRedo()) {
            setEnabled(true);
         } else {
            setEnabled(false);
         }
      }

   }  // fino de RedoAction

   /**
    * SimUndoableEditListener - Listens for Undoable edits.
    * SimUndoableEditListener - Auxskultas malfareblajn redaktajn sxangxojn.
    */
   protected class SimUndoableEditListener implements UndoableEditListener {

      public SimUndoableEditListener () {
         undoAction.updateUndoState();
         redoAction.updateRedoState();
      }

      public void undoableEditHappened(UndoableEditEvent uned) {
         undo.addEdit(uned.getEdit());
         undoAction.updateUndoState();
         redoAction.updateRedoState();
      }
   }

} // Simredo4
