/**
 * ISCII Converter
 * @author  Surekha Sastry and Srinivasa Raghavan
 *
 * This module converts between ISCII and Unicode.
 * Many thanks to the authors, Surekha Sastry and Srinivasa Raghavan.
 *
 * Cleve Lendon (Klivo)
 * indriko@yahoo.com
 * http://purl.oclc.org/net/klivo/
 *
 */


import java.io.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;

/* Algorithm for converting WX to UNICODE (Alphabetic)
   -------------------------------------
   1. Initialize CONSONANT-FLAG= false
   2. Repeat Steps[3-4] till the entire input string is processed.
   3. Extract a character from input string.
   4. If the character is in the range [65-91] or [97-122] or [48-57]
      a) Check the character-type 
        Case 'CONSONANT':
         i) Check CONSONANT-FLAG
             Case 'true' :
                   Write 'halant' and then the character.
            Case 'false' :
                    Write the character and set the CONSONANT-FLAG=true
         ii) If MATRA-FLAG = true then MATRA-FLAG = false
      Case 'VOWEL':
         i) check CONSONANT-FLAG
            Case 'true' :
               i)Check the Input Character
                 Case 'a': 
                  If matraFlag= true then MATRA-FLAG= false
                 Case 'A/e/E/i/I/u/U/q/Q/o/O': 
                  Write the Matra corresponding to this Vowel.
                  Set MATRA-FLAG=true
               ii) Set CONSONANT-FLAG=false
            Case 'false':
                     Write the Vowel corresponding to the Input Character.
      Case 'SPECIAL': (For Chandra Bindu/Anuswar/Visargah)
         i) Check CONSONANT-FLAG
            Case 'true':
               Print Error Message 'Chandra-Bindu/Anuswar/Visarga' cannot be preceeded by Consonant+Halant combination  
            Case 'false':
                Write the corresponding Character.
         ii) If MATRA-FLAG=true then MATRA-FLAG=false
        Case 'NUKTA':
              Write the corresponding character
       Case 'Default':
            i)Check the current Input Character
            Case 'V':
               i) Get the ISCII Code of the WX Character 
               ii) Decrement the ISCII code by 1
               iii)Check MATRA-FLAG
                  Case 'true':
                     Write the unicode Matra Corresponding to the ISCII Char Code.
                     Set MATRA-FLAG=false
                  Case 'false':
                     Write unicode corresponding to the ISCII Char Code.
            Case 'Y':
               i) Get the ISCII Code of the WX Character 
               ii) Increment the ISCII code by 1
               iii)Check MATRA-FLAG
                  Case 'true':
                     Write the unicode Matra Corresponding to the ISCII Char Code.
                     Set MATRA-FLAG=false
                  Case 'false':
                     Write unicode corresponding to the ISCII Char Code.
            Case '@':
                i) Extract characters till the next white space or New Line and write them as it is
                ii) Set MATRA-FLAG=false

   b) Write the Character(Roman).

  5. Exit



 Algorithm for converting UNICODE to WX
 -----------------------------------------
   1. Initialize CONSONANT-FLAG= false
   2. Repeat Steps[3-4] till the entire input string is processed.
   3. Extract a character from input string.
   4. 
      a) If the character is in the Unicode Character Range of the Specified Script (Devanagari Starts @ 2304,
           Telugu @3072)
          Check the character-type 
           Case 'CONSONANT':
            i) Check CONSONANT-FLAG
                Case 'true' :
                      Write 'a' and then the corresponding wx character.
               Case 'false' :
                       Write the corresponding wx character and set the CONSONANT-FLAG=true
            ii) If MATRA-FLAG = true then MATRA-FLAG = false
         Case 'VOWEL':
             i)  Set the CONSONANT-FLAG=false
            ii) write the corresponding wx character
         Case 'MATRA':
             i)  Set the CONSONANT-FLAG=false
            ii) write the wx Matra corresponding to Unicode character
         Case 'Halant': 
            Set CONSONANT-FLAG=false
         Case 'NUKTA': (Only for Devanagari - at present)
            write 'Z'
         Case 'CONSONANT WITH NUKTA':
            Write the wx corresponding to the Unicode Character
      b) If CONSONANT-FLAG=true then CONSONANT-FLAG=false and write input character as it is 
   
   5. Exit
*/

/**
   Class Converts wx String to a Unicode String
 */
public class IsciiConverter {

   public static final int DEVANAGARI = 1;
   public static final int TELUGU     = 2;
   int   intScript;


    // CodeMappings class reference
   IsciiMappings codeMappingsObject;
   
   /**
    *Flag to keep track of Halant
    */
    // This flag is used in wx to Unicode Conversion.
   private boolean consonantFlag;

   /**
    *Flag to keep track of Matra
    */
    // This flag is used in wx to Unicode Conversion.
   private boolean matraFlag;

   /**
    * Flag to indicate the start of English Alphabets while converting from Unicode to Wx.
    */
    // This flag is used in wx to Unicode Conversion.
   private boolean alphabetStarted;

   /**
    * Flag to indicate that the current Character read is an extended ISCII character.
    */
    // This flag is used in ISCII to Unicode Conversion.
   private boolean extendedIsciiCharacter;

   private static final boolean DEBUG=false;

   /**
    * Constructor 
    */

   public IsciiConverter() {
      
      codeMappingsObject = new IsciiMappings();
   }

   /** Returns the Unicode String given wxString and the Indian Language Script
    *  Presently, only Devanagari and Telugu support is available.
    */

   public String convertWxToUnicode(String wxString, String script) {

                    if (script.equalsIgnoreCase("Devanagari")) intScript = DEVANAGARI;
                    else if (script.equalsIgnoreCase("Telugu")) intScript = TELUGU;
                    else return "Problem";

      String unicodeString="";
      consonantFlag=false;
      matraFlag=false;
      int charIndex=0;
      while(true) {
         char[] currChar = wxString.substring(charIndex,charIndex+1).toCharArray();
         int currCharCode = (int)currChar[0];
         //if the character is a valid alphabet
         if((currCharCode >=65 && currCharCode <=91) || (currCharCode >=97 && currCharCode <=122) ||
            (currCharCode >=48 && currCharCode <=57) ) {
            char currCharType = codeMappingsObject.getCharType(currChar[0], intScript);
            //switch on the CurrrentCharacterType
            switch(currCharType) {
               case 'C' : {
                  if(consonantFlag) {
                     if (intScript == DEVANAGARI) {
                        unicodeString = unicodeString + "\u094D" + codeMappingsObject.getUnicode(currChar[0], intScript);
                     }
                     else if (intScript == TELUGU) {
                        unicodeString = unicodeString + "\u0C4D" + codeMappingsObject.getUnicode(currChar[0], intScript);
                     }
                  }
                  else {
                     unicodeString = unicodeString + codeMappingsObject.getUnicode(currChar[0], intScript);
                     consonantFlag=true;
                  }
                  if(matraFlag) {
                     matraFlag=false;
                  }
                  break;
               }
               case 'V' : {
                  //if the previous character processed is a Consonant
                  if(consonantFlag) {
                     switch(currChar[0]) {
                        case 'a' : {
                           if(matraFlag) {
                              matraFlag=false;
                           }
                           break;
                        }
                        default : {
                           unicodeString = unicodeString + 
                           codeMappingsObject.getMatraFromVowel(currChar[0], intScript);
                           matraFlag=true;
                           break;
                        }
                     }//switch
                     consonantFlag=false;
                  }
                  //if the previous character processed is not a Consonant
                  else {
                     unicodeString = unicodeString + codeMappingsObject.getUnicode(currChar[0], intScript);
                  }
                  break;
               }
               //if the current character to be processed is either anuswar/chandra-bindu/visarga
               case 'S' : {
                  //if the previous character is a Consonant .. Flag Error
                  if(consonantFlag) {
                     System.out.println("Error...");
                     System.out.println("Violated the code specification");
                     System.out.println(currChar[0] + "Cannot be preceeded by a Consonant");
                     System.out.println("Error at character index "+charIndex);
                     unicodeString = unicodeString + new String(currChar);
                  }
                  else {
                     unicodeString = unicodeString + codeMappingsObject.getUnicode(currChar[0], intScript);
                  }
                  if(matraFlag) {
                     matraFlag=false;
                  }
                  break;
               }
               case 'N' : {
                  unicodeString = unicodeString + codeMappingsObject.getUnicode(currChar[0], intScript);
                  break;
               }
               default : {
                  //switch on the currCharacter
                  switch(currChar[0]) {
                     case 'V' : {
                           String unicodeChar = unicodeString.substring(
                           unicodeString.length()-1,unicodeString.length());
                        // if the previous character is a Matra
                        if(matraFlag) {
                           int matraIsciiCode = codeMappingsObject.getIsciiFromUnicodeMatra(unicodeChar, intScript);
                           int newCharIsciiCode = matraIsciiCode-1;
                           unicodeString = unicodeString.substring(0,unicodeString.length()-1) + 
                           codeMappingsObject.getUnicodeFromIsciiMap(newCharIsciiCode, intScript);
                           matraFlag=false;
                        }
                        else {
                           int charIsciiCode = codeMappingsObject.getIsciiFromUnicodeMap(unicodeChar, intScript);
                           int newCharIsciiCode = charIsciiCode-1;
                           unicodeString = unicodeString.substring(0,unicodeString.length()-2) + 
                           codeMappingsObject.getUnicodeFromIsciiMap(newCharIsciiCode, intScript);
                        }
                        break;
                     }//case 'V'
                     case 'Y' : {
                           String unicodeChar = unicodeString.substring(
                           unicodeString.length()-1,unicodeString.length());
                           // if the previous character is a Matra
                           if(matraFlag) {
                              int matraIsciiCode = codeMappingsObject.getIsciiFromUnicodeMatra(unicodeChar, intScript);
                              int newCharIsciiCode = matraIsciiCode + 1;
                              unicodeString = unicodeString.substring(0,unicodeString.length()-1) + 
                              codeMappingsObject.getUnicodeFromIsciiMap(newCharIsciiCode, intScript);
                              matraFlag=false;
                           }
                           else {
                              int charIsciiCode = codeMappingsObject.getIsciiFromUnicodeMap(unicodeChar, intScript);
                              int newCharIsciiCode = charIsciiCode + 1;
                              unicodeString = unicodeString.substring(0,unicodeString.length()-2) + 
                              codeMappingsObject.getUnicodeFromIsciiMap(newCharIsciiCode, intScript);
                           }
                           break;
                     }//case 'Y'
                     /*case '@' : {
                        String tmp = wxString.substring(charIndex+1,wxString.length());
                        String engString="";
                        if(tmp.indexOf(" ")!=-1) {
                            engString = tmp.substring(0,tmp.indexOf(" "));
                        }
                        else if(tmp.indexOf("\n")!=-1) {
                           engString = tmp.substring(0,tmp.indexOf("\n"));
                        }
                        else {
                           engString = tmp;
                        }
                        unicodeString = unicodeString + engString;
                        if(matraFlag) {
                           matraFlag=false;
                        }
                        break;
                     }*/
                  }//switch
                  break;
               }//default
            }//switch
         }//if
         else {
            switch(currChar[0]) {
               case '@': {
                  String tmp = wxString.substring(charIndex+1,wxString.length());
                  String engString="";
                  if(tmp.indexOf(" ")!=-1) {
                     engString = tmp.substring(0,tmp.indexOf(" "));
                  }
                  else if(tmp.indexOf("\n")!=-1) {
                     engString = tmp.substring(0,tmp.indexOf("\n"));
                  }
                  else {
                     engString = tmp;
                  }
                  charIndex = charIndex + engString.length();
                  unicodeString = unicodeString + engString;
                  if(matraFlag) {
                     matraFlag=false;
                  }
                  break;
               }
              default :{
                 unicodeString = unicodeString + currChar[0];
              }
            }
         }
            charIndex = charIndex + 1;
            // If charIndex reaches the length of the InputString stop.
            if(charIndex == wxString.length()) {
               break;
            }
      
      }
      /*char[] ch = unicodeString.toCharArray();
      for(int i=0;i<ch.length;i++) {
         System.out.println((int)ch[i]);
      }*/
      return unicodeString;
   }

   // Unicode Devanagari 
   //    Vowels Range : 2309-2324 (decimal)
   //    Consonants Range : 2325 - 2361
   //    Matra Range : 2366 - 2380
   //    Consonant with Nukta : 2392 - 2399 (consonant+nukta(Z))
   
   /**  Returns the wxString given unicodeString and Indian Language Script as input.
     *  Presently, supports Telugu and Devanagari scripts
    */
   public String convertUnicodeToWx(String unicodeString, String script) {

             if (script.equalsIgnoreCase("Devanagari")) intScript = DEVANAGARI;
             else if (script.equalsIgnoreCase("Telugu")) intScript = TELUGU;
             else return "Problem";

      String wxString="";
      consonantFlag=false;
      matraFlag=false;
      alphabetStarted = false;
      char[] unicodeChars = unicodeString.toCharArray();
      for(int i=0;i<unicodeChars.length;i++) {
         //if the unicodeCharacter is in Devanagari Range
         int charCode = (int)unicodeChars[i];
         if(intScript == DEVANAGARI) {
            if(charCode  > 2304 ) {
               // if the character is a Proper Consonant
               if(charCode >= 2325 && charCode <= 2361) {
                  if(consonantFlag) {
                     wxString = wxString + "a"+ 
                     codeMappingsObject.getWxFromUnicode(unicodeChars[i], intScript);
                  }
                  else {
                     consonantFlag=true;
                     wxString = wxString + 
                     codeMappingsObject.getWxFromUnicode(unicodeChars[i], intScript);
                  }
                  matraFlag=false;
               }
               // if the Character is a Vowel
               else if(charCode >= 2309 && charCode <= 2324) {
                  consonantFlag=false;
                  matraFlag=false;
                  wxString = wxString + 
                  codeMappingsObject.getWxFromUnicode(unicodeChars[i], intScript);
               }
               // if the Character is a Matra
               else if(charCode >= 2366 && charCode <= 2380) {
                  consonantFlag=false;
                  matraFlag=true;
                  wxString = wxString + 
                  codeMappingsObject.getWxFromUnicode(unicodeChars[i], intScript);
               }
               // If the Character is a Halant
               else if(charCode == 2381 ) {
                  matraFlag=false;
                  consonantFlag=false;
               }
               // If the Character is a Nukta 
               else if(charCode == 2364 ) {
                  matraFlag=false;
                  wxString = wxString + "Z" ;
               }
               // If the Character is either 'chandrabindu','visarg' or 'anuswar'
               else if(charCode >= 2305 && charCode <= 2307) {
                  if(!matraFlag) {
                     wxString = wxString + "a";  //added on 24th Jan.
                  }
                  wxString = wxString + 
                  codeMappingsObject.getWxFromUnicode(unicodeChars[i], intScript);
                  matraFlag=false;
                  consonantFlag=false;
               }
            }
            else {
               if(matraFlag) {
                  wxString = wxString + new Character((char)charCode).toString();
                  consonantFlag = false;
                  matraFlag = false;
               }
               else if(consonantFlag) {
                  wxString = wxString + "a" + new Character((char)charCode).toString();
                  consonantFlag=false;
               }
               else {
                  // if the Character is not a whitespace or a newLine
                  if( (charCode !=32) && (charCode != 10) ) {
                     // If this is the first Alphabet after a whitespace or a newLine.
                     // The alphabetStarted flag is false indicating that the english 
                     // Alphabet sequence has not yet started and this is the first 
                     // Character of the english Alphabet sequence and hence prefix '@'
                     // to this Character.
                     // The alphabetStarted flag true indicates that the english alphabet
                     // sequence has already started and continues till a whitespace or
                     // a newLine which ever occurs first.
                     if(!alphabetStarted) {
                        alphabetStarted = true;
                        wxString = wxString + "@" + 
                        new Character((char)charCode).toString();
                        continue;
                     }
                  }
                  // if the character is a whitespace or a newLine  
                  else {
                     // If the previous word till this Character(either a whitespace 
                     // or a newLine) is a sequence of english alphabets then this 
                     // character indicates the end of 
                     // the sequence.So, make the alphabetStarted flag false so that 
                     // the next occurance of any english alphabet will be the first 
                     //character of that sequence.
                     if(alphabetStarted) {
                        alphabetStarted = false;
                     }
                  }
                  // The control comes here if the alphabetStarted flag is when true or
                  // if the inputcharacter is a whitespace or newline.
                  wxString = wxString + new Character((char)charCode).toString();
               }
            }
            // Added on 24Jan  
            // If the last character is a Consonant 
            if(i==(unicodeChars.length-1) && consonantFlag) {
               wxString = wxString + "a";
            }
         }
         else if (intScript == TELUGU) {
            if(charCode  > 3072 ) {
               // if the character is a Proper Consonant
               if(charCode >= 3093 && charCode <= 3129) {
                  if(consonantFlag) {
                     wxString = wxString + "a"+ 
                     codeMappingsObject.getWxFromUnicode(unicodeChars[i], intScript);
                  }
                  else {
                     consonantFlag=true;
                     wxString = wxString + 
                     codeMappingsObject.getWxFromUnicode(unicodeChars[i], intScript);
                  }
                  matraFlag=false;
               }
               // if the Character is a Vowel
               else if(charCode >= 3077 && charCode <= 3092) {
                  consonantFlag=false;
                  matraFlag=false;
                  wxString = wxString + 
                  codeMappingsObject.getWxFromUnicode(unicodeChars[i], intScript);
               }
               // If the Character is either 'chandrabindu','visarg' or 'anuswar'
               else if(charCode >= 3073 && charCode <= 3075) {
                  if(!matraFlag) {
                     wxString = wxString + "a"; // 'a' is added on 24 Jan.
                  }
                  wxString = wxString  + 
                  codeMappingsObject.getWxFromUnicode(unicodeChars[i], intScript);
                  consonantFlag=false;
                  matraFlag=false;
               }
               // if the Character is a Matra
               else if(charCode >= 3134 && charCode <= 3148) {
                  consonantFlag=false;
                  matraFlag=true;
                  wxString = wxString + 
                  codeMappingsObject.getWxFromUnicode(unicodeChars[i], intScript);
               }
               // if the character is a Halant
               else if(charCode == 3149) {
                  matraFlag=false;
                  consonantFlag=false;
               }
            }
            else {
               if(matraFlag) {
                   wxString = wxString + new Character((char)charCode).toString();
                   consonantFlag = false;
                   matraFlag = false;
               }
               else if(consonantFlag) {
                  wxString = wxString + "a" + new Character((char)charCode).toString();
                  consonantFlag=false;
               }
               /*else {
                  wxString = wxString + new Character((char)charCode).toString();
               }*/
               else {
                  // if the Character is not a whitespace or a newLine
                  if( (charCode !=32) && (charCode != 10) ) {
                     // If this is the first Alphabet after a whitespace or a newLine.
                     // The alphabetStarted flag is false indicating that the english 
                     // Alphabet sequence has not yet started and this is the first 
                     // Character of the english Alphabet sequence and hence prefix '@'
                     // to this Character.
                     // The alphabetStarted flag true indicates that the english 
                     // alphabet sequence has already started and continues till a 
                     // whitespace or a newLine which ever occurs first.
                     if(!alphabetStarted) {
                        alphabetStarted = true;
                        wxString = wxString + "@" + 
                        new Character((char)charCode).toString();
                        continue;
                     }
                  }
                  // if the character is a whitespace or a newLine  
                  else {
                     // If the previous word till this Character(either a whitespace 
                     // or a newLine) is a sequence of english alphabets then this 
                     // character indicates the end of the sequence.So, make the 
                     // alphabetStarted flag false so that the next occurance 
                     // of any english alphabet will be the first character of that sequence.
                     if(alphabetStarted) {
                        alphabetStarted = false;
                     }
                  }
                  // The control comes here if the alphabetStarted flag is when true or
                  // if the inputcharacter is a whitespace or newline.
                  wxString = wxString + new Character((char)charCode).toString();
               }
            }
            // Added on 24Jan  
            // If the last character is a Consonant 
            if(i==(unicodeChars.length-1) && consonantFlag) {
               wxString = wxString + "a";
            }
         }
      }
      return wxString;
   }

   /* 
      ALGORITHM TO CONVERT ISCII TO UNICODE 
      -------------------------------------
      1. Repeat the steps [2-3] till the entire String is completely processed.

      2. Get the character code(ASCII) of the current Character.

      3. (a) If the Code is in ISCII Range (-95 to -6) then    [ (256 + (-95)) = 161  (256 + (-6)) = 250 ]
            Get the Corresponding Unicode for the ISCII character for the specified script
           
        (b) If the Code is not in ISCII Range (ASCII Characters)
             Add this ASCII Character to the resulting String irrespective of the specified script.
      4. Exit.
   
   */

   /**
     * Returns the unicode string given iscii byte-array as input for a particular script(Devanagari/Telugu)
     */

   public String convertIsciiToUnicode(String isciiString, String script) {

             if (script.equalsIgnoreCase("Devanagari")) intScript = DEVANAGARI;
             else if (script.equalsIgnoreCase("Telugu")) intScript = TELUGU;
             else return "Problem";

      char[] ch;
      ch = isciiString.toCharArray();
      if(DEBUG) {
      //   ch = isciiString.toCharArray();
         for(int i=0;i<ch.length;i++) {
            System.out.println("Iscii Chars:" + (int)ch[i]);
         }
         System.out.println("Output...................");
      }
      int prevCharCode=0;
      extendedIsciiCharacter = false;
      String unicodeString = new String();
      byte b[] = isciiString.getBytes();
      //for(int i=0;i<b.length;i++) 
      for(int i=0;i<ch.length;i++) {
         //int code = (int)b[i];
         int code = (int)ch[i];   
         //if(code >= -95 && code <= -6)    
         if(code >= 161 && code <= 254) {   
           // code = 256+code;
            if(DEBUG) System.out.println(code);
            // NUKTA character is not present in any of the South Indian scripts.
            if (intScript == DEVANAGARI) {
               // Is this Character code matches with any of the Character Codes in the Extended ISCII.
               // and the previous
               if(codeMappingsObject.isExtendedIsciiChar(code, intScript) ) {
                  if(DEBUG) System.out.println("matched iscii extended ");
                  // If this is the last Character in the String.
                  if(i == (b.length-1) ) {
                     unicodeString = unicodeString + codeMappingsObject.getUnicodeFromIscii(code, intScript);
                     continue;
                  }
                  // If the Previous character is also an Extended Iscii Character
                  if(extendedIsciiCharacter) {
                     unicodeString = unicodeString + codeMappingsObject.getUnicodeFromIscii(prevCharCode, intScript);
                  }
                  extendedIsciiCharacter = true;
                  prevCharCode = code;
                  continue;
               }
               // If the previous character was a ISCII extended Character 
               if(extendedIsciiCharacter) {
                  // If the current Character is NUKTA.
                  if(code == 233) {
                     if(DEBUG) System.out.println("current char nukta");
                     unicodeString = unicodeString + 
                     codeMappingsObject.getUnicodeFromExtendedIscii(prevCharCode, intScript);
                     extendedIsciiCharacter = false;
                     continue;
                  }
                  else {
                     // If the current Character is not NUKTA .
                     if(DEBUG) System.out.println(" Current Character not Nukta");
                     unicodeString = unicodeString + codeMappingsObject.getUnicodeFromIscii(prevCharCode, intScript) +
                     codeMappingsObject.getUnicodeFromIscii(code, intScript);
                     extendedIsciiCharacter = false;
                     continue;
                  }
               }
            }
            if(DEBUG) System.out.println("Writing from here");
            unicodeString = unicodeString + codeMappingsObject.getUnicodeFromIscii(code, intScript);
         }
         else {
            // If a ASCII Character follows an Extended Iscii Character 
            if(intScript == DEVANAGARI && extendedIsciiCharacter) {
               unicodeString = unicodeString + codeMappingsObject.getUnicodeFromIscii(prevCharCode, intScript) +
               (char)code;
               extendedIsciiCharacter = false;
            }
            else {
               unicodeString = unicodeString + (char)code;
            }
         }
      }
      if(DEBUG) {
         ch = unicodeString.toCharArray();
         for(int i=0;i<ch.length;i++) {
            System.out.println("Unicode Chars:" + (int)ch[i]);
         }
      }
      return unicodeString;
   }

   /* 
      ALGORITHM TO CONVERT UNICODE TO ISCII
      -------------------------------------
      1. Repeat the steps [2-3] till the entire String is completely processed.

      2. Get the character code(Decimal Equivalent of Unicode) of the current Character.

      3. (a) If the Code is in Devanagari Range (2304 to 2416) then  
             Get the Corresponding ISCII code for the Unicode character for the specified script
           
        (b) If the Code is not in Unicode Range (ASCII Characters)
             Add this ASCII Character to the resulting String.
      4. Exit.
   
   */
   /**
     * Returns the ISCII string given unicode String as input for a particular script(Devanagari/Telugu)
     */ 
   public String convertUnicodeToIscii(String unicodeString, String script) {

             if (script.equalsIgnoreCase("Devanagari")) intScript = DEVANAGARI;
             else if (script.equalsIgnoreCase("Telugu")) intScript = TELUGU;
             else return "Problem";

      char[] ch;
      if(DEBUG) {
         ch = unicodeString.toCharArray();
         for(int i=0;i<ch.length;i++) {
            System.out.println((int)ch[i]);
         }
         System.out.println("Output..................................................");
      }
      String isciiString = new String();
      char unicode[] = new char[unicodeString.length()];
      char iscii[] = new char[2*unicodeString.length()];
      unicodeString.getChars(0,unicodeString.length(),unicode,0);
      ch = new char[1];
      int outputArrayIndex=0;
      for(int i=0;i<unicode.length;i++) {
         ch[0] = unicode[i];
         int code = (int)ch[0];
         // Unicode for Telugu starts at 3073 which is > 2304.
         if(code >= 2304) {
            if(DEBUG) System.out.print(code);
            if(codeMappingsObject.isExtendedIsciiChar(new String(ch), intScript)) {
               if(DEBUG) System.out.println("\t Inside if");
               iscii[outputArrayIndex++] = (char)codeMappingsObject.getIsciiCodeFromExtendedIscii(new String(ch), intScript);
               iscii[outputArrayIndex++] = (char)233;
            }
            else {
               if(DEBUG) System.out.println("\t Inside Else");
               iscii[outputArrayIndex++] = (char)codeMappingsObject.getIsciiFromUnicode(new String(ch), intScript);
            }
         }
         else {
            iscii[outputArrayIndex++] = (char)unicode[i];
         }
      }
      if(DEBUG) { 
         System.out.println("Start of Output.........................");
         for(int i=0;i<iscii.length;i++) {
            System.out.println((int)iscii[i]);
         }
         System.out.println("End of the Output.........................");
      }
      return new String(iscii).trim();
   }

   public static void main(String a[]) {
      if(a.length != 4) {
         System.out.println("Usage:");
         System.out.println("      java -jar IsciiConverter.jar wx-Unicode/Unicode-wx/ISCII-Unicode/Unicode-ISCII IndianLanguageScript InputFile OutputFile");
         System.out.println("Eg:\n      1. java -jar IsciiConverter.jar wx-Unicode Devanagari wxFile unicodeFile"); 
         System.out.println("      2. java -jar IsciiConverter.jar wx-Unicode Telugu wxFile UnicodeFile");
         System.out.println("      3. java -jar IsciiConverter.jar Unicode-wx Devanagari UnicodeFile wxFile");
         System.out.println("      4. java -jar IsciiConverter.jar Unicode-wx Telugu UnicodeFile wxFile");
         System.out.println("      5. java -jar IsciiConverter.jar ISCII-Unicode Telugu isciiFile UnicodeFile");
         System.out.println("      6. java -jar IsciiConverter.jar Unicode-ISCII Devanagari UnicodeFile isciiFile");
         System.out.println("Exiting...");
         System.exit(0);
      }
      IsciiConverter cc = new IsciiConverter();
      String input="",output="",unicodeString="",isciiString="";
      if(a[0].equalsIgnoreCase("wx-Unicode")) {
         try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(a[2])));
            while((input=br.readLine())!=null) {
               output += input +"\n";
            }
            unicodeString = cc.convertWxToUnicode(output,a[1]);
            OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream(a[3]),"UNICODE");
            out.write(unicodeString,0,unicodeString.length());
            out.close();
         }
         catch(Exception e) {
            e.printStackTrace();
         }
      }
      else if(a[0].equalsIgnoreCase("Unicode-wx")) {
         try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(a[2]),"UNICODE"));
            while((input=br.readLine())!=null) {
               output += input +"\n";
            }
            unicodeString = cc.convertUnicodeToWx(output,a[1]);
            OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream(a[3]));
            out.write(unicodeString,0,unicodeString.length());
            out.close();
         }
         catch(Exception e) {
            e.printStackTrace();
         }
      }
      else if(a[0].equalsIgnoreCase("Unicode-ISCII")) {
         try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(a[2]),"UNICODE"));
            while((input=br.readLine())!=null) {
               output += input +"\n";
            }
            isciiString = cc.convertUnicodeToIscii(output,a[1]);
            OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream(a[3]));
            out.write(isciiString,0,isciiString.length());
            out.close();
         }
         catch(Exception e) {
            e.printStackTrace();
         }
      }
      else if(a[0].equalsIgnoreCase("ISCII-Unicode")) {
         try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(a[2])));
            while((input=br.readLine())!=null) {
               output += input +"\n";
            }
            unicodeString = cc.convertIsciiToUnicode(output,a[1]);
            OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream(a[3]),"UNICODE");
            out.write(unicodeString,0,unicodeString.length());
            out.close();
         }
         catch(Exception e) {
            e.printStackTrace();
         }
      }
      
   }
   
}
