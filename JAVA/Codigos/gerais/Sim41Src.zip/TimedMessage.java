/*
 * TimedMessage - This class briefly display a message. A timer is 
 * used to hide the message.
 *
 * TimedMessage - Cxi tiu klaso mallonge montras mesagxon. Horlogxo
 * estas uzata por kasxi la  mesagxon.
 *
 * Cleve Lendon (Klivo)     2002/10
 * indriko@yahoo.com
 * http://purl.oclc.org/net/klivo/
 *
 */


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class TimedMessage extends JDialog implements ActionListener {

   JFrame  parent;

   private final static int d_width  = 250;   // dialog width   -  dialoga largxeco
   private final static int d_height = 80;   // dialog height  -  dialoga alteco

   private Timer the_timer;

   private JLabel         the_label;

   public static final int  FILE_SAVED          = 0;         // Dosiero konservita.
   public static final int  DICT_NOT_FOUND      = 1;         // Ne povas trovi vortaron.
   public static final int  CANT_OPEN_FILE      = 2;         // Ne povas malfermi dosieron.

   private String[]  messages;

   public TimedMessage (JFrame owner, String[] messages) {

      super(owner, true);   // Modal dialogue. Deviga dialogo.

      this.messages = messages;

      setSize(d_width, d_height);
      parent = owner;

      Container cp = getContentPane();
      cp.setLayout(new GridBagLayout());

      the_label      = new JLabel("    ");

      GridBagConstraints gbc = new GridBagConstraints();
      gbc.insets = new Insets(5,10,5,10);
      //gbc.anchor = GridBagConstraints.NORTH;
      gbc.gridx = 0; gbc.gridy = 0;
      cp.add(the_label,gbc);

   }  // end of constructor


   public void actionPerformed(ActionEvent e) {
      // Must be timer. Devas esti horlogxo.
      the_timer.stop();
      the_timer = null;
      setVisible(false);
   }


   /*
    * showIt - Display message for limited time. 
    * showIt - Montru mesagxon dum limigita tempo. 
    */
   public void showIt(int message_number, int milliseconds) {

      if (message_number >= messages.length) return;
      if (milliseconds > 10000) return;

      the_timer = new Timer(milliseconds, this);
      the_timer.start();   // komencu

      the_label.setText(messages[message_number]);

      // Position the message box in the center of the main frame.
      // Metu mesagx-kvadraton en la mezon de la cxefa kadro.

      int new_width = the_label.getWidth() + 40;
      int new_height = the_label.getHeight() * 2 + 40;
      if (new_width < d_width) new_width = d_width;
      if (new_height < d_height) new_height = d_height;

      Rectangle p_rect = parent.getBounds();
      Rectangle d_rect = new Rectangle(p_rect.x + Math.abs(p_rect.width - new_width)/2,
                                       p_rect.y + Math.abs(p_rect.height - new_height)/2,
                                       new_width,new_height);

      setBounds(d_rect);
      setVisible(true);
      validate();

   }  // showIt


   public void showIt(int message_number) {
      showIt(message_number, 1800);     // 1.8 seconds
   }


}  // TimedMessage


