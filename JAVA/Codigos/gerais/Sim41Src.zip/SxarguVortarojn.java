/**
 * SxarguVortarojn - Klaso por legi vortarajn informojn el 
 * zip-formataj dosieroj.
 *
 * @version 1.0, 2004/03/04
 * @author Klivo
 * 
 */

//package vortaro;

import java.io.*;
import java.util.zip.*;

class SxarguVortarojn {

   static final int MAKS_VORTAROJ = 5;  // maksimuma nombro da vortaroj

   String[] vortaronomo  = new String[MAKS_VORTAROJ];
   char[][] vortaro      = new char[MAKS_VORTAROJ][];

   public SxarguVortarojn() {
   }

   public SxarguVortarojn(String zipdosiero) {
      sxargu(zipdosiero);
   }


   /**
    * Redonas la datumojn de vortaro.
    * @param nomo de vortaro
    * @return la char-elementoj de la vortaro, null se ne troveblas
    */
   public char[] akiruVortaron(String nomoDeVortaro) {
      for (int i = 0; i < MAKS_VORTAROJ; i++) {
         if (vortaronomo[i] != null && 
             vortaronomo[i].equals(nomoDeVortaro)) {
            return vortaro[i];
         }
      }
      return null;
   }



   /**
    * Sxargas vortarojn el zip-dosiero (arkivo).
    * Povas esti pluraj vortaroj ene de la arkivo. (Gxis 5.)
    * @param nomo de la zip-dosiero
    */
   public void sxargu(String nomo) {

      int       grandeco;
      ZipEntry  zipinformoj;

      byte      hi, lo;    // peza kaj malpeza

      ZipInputStream zip = malfermuZipDosieron(nomo);

      if (zip == null) {
         return;
      }

      try {

         for (int i = 0; i < MAKS_VORTAROJ; i++) {
            int nombroLegitaj = 0;
            zipinformoj = zip.getNextEntry();
            if (zipinformoj != null) {
               vortaronomo[i] = zipinformoj.getName();
               grandeco = (int)(zipinformoj.getSize() / 2);
               vortaro[i] = new char[grandeco];
               for (int j = 0; j < grandeco; j++) {
                  hi = (byte)zip.read(); lo = (byte)zip.read();
                  vortaro[i][j] = (char)(((hi << 8) & 0xFF00) + (lo & 0xFF));
                  nombroLegitaj++;
               }
               System.out.println("Nombro da char-elementoj legitaj de " +
                                  vortaronomo[i] + ": "+ nombroLegitaj);
            }
         } // fino de 'for'

         zip.close();

      }
      catch (Exception e) {
         System.out.println("SxarguVortarojn: Eraro dum legado de vortaroj.");
         return;
      }
   }


   /*
    * Malfermas zip-dosieron por legado.
    * @param nomo de dosiero
    * @return InputStreamReader
    */

   ZipInputStream malfermuZipDosieron(String nomo) {

      try {
         return new ZipInputStream(new FileInputStream(nomo));
      }
      catch (Exception e) {
         System.out.println("SxarguVortarojn: Ne povis malfermi " + nomo + " .");
         return null;
      }
   }

}  // fino de SxarguVortarojn



