import java.awt.*;
import java.awt.event.*;

public class Dialogo extends WindowAdapter implements ActionListener {

    static Frame frame = new Frame("");
    static Label lErro = new Label();
    static Panel p = new Panel();
    static Button bOk = new Button("Ok");
    
    public Dialogo(String mensagem) {
        bOk.setBounds(60,40,30,20);
        bOk.addActionListener(this);
        frame.addWindowListener(this);
        frame.setTitle(mensagem);
        lErro.setBounds(10,10,130,20);
        p.setLayout(null);
        p.add(bOk);
        p.add(lErro);
        frame.add(p);
        frame.setBounds(300,200,150,90);
    }
    
    public void actionPerformed(ActionEvent e) {
        if (frame.isVisible()) {
            frame.setVisible(false);
        }
    }
    
    public static void show() {
        if (!frame.isVisible()) {
            frame.setVisible(true);
        }
    }
    
    public static void setText(String text) {
        lErro.setText(text);
    }
    
    public void windowClosing(WindowEvent e) {
        frame.setVisible(false);
    }
}