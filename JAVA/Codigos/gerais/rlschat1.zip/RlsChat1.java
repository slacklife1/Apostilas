/*
    Um chat ponto a ponto
    Por Rafael Luiz: rls@cin.ufpe.br

*/
import java.io.*;
import java.net.InetAddress;
import java.net.*;
import java.awt.*;
import java.awt.event.*;

public class RlsChat1 extends WindowAdapter implements ActionListener, Runnable {
    
    
    private static final int PORTA_PADRAO = 4000;
    
    //private Panel p;
    private Panel p;
    private TextArea tCliente;
    private TextField tNome, tHost, tPort, tLine;
    private Label lCliente, lNome, lHost, lServidor;
    
    private Frame nick, escolha, infoS, infoC,geral;
    
    private int port;
    private String line = null, line1 = null;
    
    private Socket s;
    
    private ServerSocket escuta_socket;
    
    private DataInputStream in;
    private PrintStream out;
    
    static CheckboxGroup cbg = new CheckboxGroup();
    static Checkbox c1 = new Checkbox("Servidor",cbg,true),
        c2 = new Checkbox("Cliente",cbg,false);
        
    private Button bOk;
    
    private String nome, nome2, host;
    
    private boolean ehCliente = false;
    
    private Dialogo msg = new Dialogo("Erro");
    
    public RlsChat1() {
        p = new Panel();
        tLine = new TextField();
        tNome = new TextField();
        tHost = new TextField();
        tPort = new TextField();
        tCliente = new TextArea();
        lCliente = new Label("");
        lNome = new Label("");
        lHost = new Label("");
        lServidor = new Label("");
        line = null;
        s = null;
        escolha = new Frame("Choice");
        nick = new Frame("NickName");
        geral = new Frame("Main");
        infoS = new Frame("Info");
        infoC = new Frame("Info");
        this.iniciar();
    }
    
    public void conectarCliente() {
        
        try {
            InetAddress ip = InetAddress.getByName(host);
            
            // Create a socket to communicate to the specified host and port
            s = new Socket(ip, port);
            tCliente.append("\n" + ip.getByName(null));
            // Create streams for reading and writing lines of text
            // from and to this socket.
            in = new DataInputStream(s.getInputStream());
            out = new PrintStream(s.getOutputStream());
            
            // Tell the user that we've connected
            tCliente.append("\nConectado a " + s.getInetAddress()
                       + ":"+ s.getPort());
                       
            out.println(nome);
            nome2 = in.readLine();
            tCliente.append("\n Conexao com " + nome2 + " estabelecida");
            this.conectar();
        }
        catch (IOException e) { tCliente.append("\n" + e); }
        // Always be sure to close the socket
        finally {
            try { if (s != null) s.close(); } catch (IOException e2) { ; }
        }
    }
    
    public void conectarServidor() {
        
        try {
            escuta_socket = new ServerSocket(port);
            }
        catch (IOException e) {
            erro(e, "Erro criando socket servidor");
            }
        tCliente.append("\nServidor: escutando na porta " + port);
    
        try {
            s = escuta_socket.accept();
            
            try { 
                in = new DataInputStream(s.getInputStream());
                out = new PrintStream(s.getOutputStream());
                
                if (s != null) {
                    nome2 = in.readLine();
                    tCliente.append("\n" + nome2 + " se conectou");
                    out.println(nome);
                }
                this.conectar();
            }
            catch (IOException e) {
                try {
                    s.close();
                    }
                catch (IOException e2) {
                     ;
                    }
                erro(e, "Erro enquanto recebendo dados da conexao");
            }
        }
        catch (IOException e) { 
            erro(e, "Erro enquanto na escuta da conexao");
        }
    }
    
    public void conectar() {
        
        try {
            while (true) {
                line = in.readLine();
                
                if (line == null) {
                } else {
                    tCliente.append("\n" + nome2 + ":" + line);
                    if (line.equals("bye")) {
                        tCliente.append("\n" + nome2 + " se desconectou");
                        break;
                    }
                }
            }
        }
        catch (IOException e) {
            ;
        }
        finally {
            try {
                if (!ehCliente) {
                    s.close();
                }
            }
            catch (IOException e2) {
                ;
            }
        }
    }

    public void run() {
        if (this.ehCliente) {
            this.conectarCliente();
        } else {
            this.conectarServidor();
        }
    }
    
    public void erro(Exception e, String m) {
        msg.setText(m + ":" + e);
        msg.show();
    }
    
    public void sessao() {
        p.removeAll();
        bOk = new Button("Desconectar");
        bOk.setBounds(80,250,90,30);
        bOk.addActionListener(this);
        geral.addWindowListener(this);
        p.setLayout(null);
        lCliente.setBounds(80,10,80,20);
        lCliente.setText(nome);
        tCliente.setBounds(10,40,190,100);
        tLine.setBounds(10,180,190,30);
        tLine.addActionListener(this);
        p.add(lCliente);
        p.add(tLine);
        p.add(bOk);
        p.add(tCliente);
        geral.add(p);
        geral.setBounds(300,300,250,400);
        geral.setVisible(true);
        
        new Thread(this).start();
        
    }
    
    public void iniciar() {
        nick.addWindowListener(this);
        p.setLayout(null);
        lNome.setBounds(80,10,80,20);
        lNome.setText("Nick Name");
        tNome.setBounds(50,50,100,30);
        tNome.addActionListener(this);
        p.add(lNome);
        p.add(tNome);
        nick.add(p);
        nick.setBounds(300,300,200,150);
        nick.setVisible(true);
    }
    
    public void escolher() {
        p.removeAll();
        escolha.addWindowListener(this);
        bOk = new Button("Ok");
        bOk.setBounds(80,90,40,30);
        bOk.addActionListener(this);
        p.setLayout(null);
        c1.setBounds(40,30,80,30);
        c2.setBounds(120,30,80,30);
        p.add(c1);
        p.add(c2);
        p.add(bOk);
        escolha.add(p);
        escolha.setBounds(300,300,200,150);
        escolha.setVisible(true);
    }
    
    public void infoServidor() {
        p.removeAll();
        infoS.addWindowListener(this);
        bOk = new Button("Ok");
        bOk.setBounds(80,140,40,30);
        bOk.addActionListener(this);
        lServidor.setBounds(80,10,80,20);
        lServidor.setText("Host name");
        tPort.setBounds(50,50,100,30);
        p.setLayout(null);
        p.add(tPort);
        p.add(bOk);
        infoS.add(p);
        infoS.setBounds(300,300,200,200);
        infoS.setVisible(true);
    }
    
    public void infoCliente() {
        p.removeAll();
        infoC.addWindowListener(this);
        bOk = new Button("Ok");
        bOk.setBounds(80,160,40,30);
        bOk.addActionListener(this);
        lServidor.setBounds(80,10,80,20);
        lServidor.setText("Host name");
        tHost.setBounds(50,50,100,30);
        lCliente.setBounds(80,90,80,20);
        lCliente.setText("Port number");
        tPort.setBounds(50,130,100,30);
        p.setLayout(null);
        p.add(lServidor);
        p.add(tHost);
        p.add(lCliente);
        p.add(tPort);
        p.add(bOk);
        infoC.add(p);
        infoC.setBounds(300,300,200,210);
        infoC.setVisible(true);
    }
    
    public void actionPerformed(ActionEvent e) {
        
        if (geral.isVisible()) {
            if (e.getSource() == bOk) {
                this.out.println("bye");
                this.exit();
            } else {
                line1 = tLine.getText();
                tCliente.append("\n" + nome + ":" + line1);
                this.out.println(line1);
                out.flush();
                tLine.setText("");
            }
        } else if (nick.isVisible()) {
            this.nome = e.getActionCommand();
            this.nick.setVisible(false);
            this.escolher();
        } else if (escolha.isVisible()) {
            this.escolha.setVisible(false);
            if (c1.getState()) {
                this.infoServidor();
            } else {
                this.ehCliente = true;
                this.infoCliente();
            }
        } else if (infoS.isVisible()) {
            try{
                this.port = Integer.parseInt(tPort.getText());
                this.infoS.setVisible(false);
                this.sessao();
            }catch (Exception e2) {
                this.port = PORTA_PADRAO;
                this.infoS.setVisible(false);
                this.sessao();
            }
        } else if (infoC.isVisible()) {
            this.host = tHost.getText();
            try{
                this.port = Integer.parseInt(tPort.getText());
                this.infoC.setVisible(false);
                this.ehCliente = true;
                this.sessao();
            }catch (Exception e2) {
                this.port = PORTA_PADRAO;
                this.infoC.setVisible(false);
                this.ehCliente = true;
                this.sessao();
            }
        }
    }

    public void windowClosing(WindowEvent e) {
        this.exit();
    }
    
    public void exit() {
        System.exit(0);
    }
    
    public static void main(String[] args) {
        RlsChat1 chat = new RlsChat1();
    }
}