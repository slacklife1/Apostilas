
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.event.*;
import javax.swing.border.*; 
import java.sql.*;
import java.util.Vector;
/*@author Mr. Sachin Teke sssteke@yahoo.co.uk
 *
 */

class SearchDialog extends JFrame{
   Vector BookCardEntries = new Vector();
   Disable1TableModel model = new Disable1TableModel();
   
   SearchDialog(Vector BookCardEntries1){
   BookCardEntries =BookCardEntries1;  
        try 
   {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
   }
   catch ( ClassNotFoundException e ) 
   {
   }
   catch ( InstantiationException e ) 
   {
   }
   catch ( IllegalAccessException e ) 
   {
   }
   catch ( UnsupportedLookAndFeelException e ) 
   {
   }
   	    model.addColumn("Book ID");
   	    model.addColumn("Title");
        model.addColumn("Author");
        model.addColumn("Edition");
        model.addColumn("ISBN");
        model.addColumn("Price");
        model.addColumn("Copies");
        model.addColumn("Category");
        //BookCardEntries = Clerk.getInstance().search(BookName,Author, ISBN,ID, Category, BookNameboolean,Authorboolean, ISBNboolean, IDboolean, Categoryboolean);
        showTable();                                                 
  }
       
 void showTable(){      

       int i=0; 
       String tempid=new String();        
       BookCard  BookCardtemp=new  BookCard();        
       for(i=0;i<BookCardEntries.size();i++){
         BookCardtemp=(BookCard)BookCardEntries.elementAt(i);
         tempid=""+BookCardtemp.getID()+"";
         model.addRow(new String[]{ tempid,
           	                          BookCardtemp.getBookName(),
           	                          BookCardtemp.getAuthor(),
           	                          BookCardtemp.getEdition(),
           	                          BookCardtemp.getISBN(),
           	                          BookCardtemp.getPrice(),
           	                          BookCardtemp.getCopies(),
           	                          BookCardtemp.getCategory()
                     });
      }                
       
       
        GUI();
        
    }
   //functions start
     public static void p(String st){
 	   System.out.println(st);
     }
     
    //GUI Function
    void GUI(){

        
        
        JFrame frame1=new JFrame();
        frame1.setDefaultLookAndFeelDecorated(true);
        String temp="ggggg";
        
        JTable table = new JTable(model);
        table.getTableHeader().setReorderingAllowed(false);
        table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(400,100));

        

        JPanel panel1 = new JPanel(new BorderLayout());
        panel1.add(scrollPane, BorderLayout.CENTER);
        panel1.setBorder(BorderFactory.createTitledBorder(""));
        
        JPanel panel2 = new JPanel(new BorderLayout());
        JLabel DotsLabel = new JLabel("......................................................................................................................................................................................................................................");
        panel2.add(DotsLabel, BorderLayout.NORTH);
 
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(panel2,BorderLayout.NORTH);
        panel.add(panel1,BorderLayout.CENTER);
        
        
        getContentPane().add(panel);
        JPanel MainPanel=new JPanel();     
        MainPanel.setBorder(new CompoundBorder(new TitledBorder(null,"Result of search" ,
							  TitledBorder.CENTER, TitledBorder.TOP),new CompoundBorder() ));
       
        MainPanel.setBounds(5, 30, 600, 600);
        MainPanel.add(getContentPane());
             String[] OptionNames = { "Close" };
             String   OptionTitle = "Search Dialog";
        JOptionPane.showOptionDialog( null, MainPanel,OptionTitle ,
	               JOptionPane.CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE,
                   null,OptionNames,OptionNames[0]) ;
    
       

  }
    
    

 public static void main(String args[]){
 
 //SearchDialog a=new SearchDialog();
 	
 }   

}//End of class  

 class Disable1TableModel extends DefaultTableModel /*implements Serializable*/{
     public boolean isCellEditable(int rowIndex, int columnIndex) {
  	   return false;
     }
 } 