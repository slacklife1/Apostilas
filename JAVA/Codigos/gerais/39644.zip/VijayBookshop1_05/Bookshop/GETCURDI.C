/*author: Sachin Teke   ssteke@yahoo.com
 *This file is required for installation .
 *It creates file Bookshop.bat
 */
#include<dir.h>
#include <stdio.h>
#include <string.h>
#include<errno.h>

char *current_directory(char *path)
{
   strcpy(path, "X:\\");      /* fill string with form of response: X:\ */
   path[0] = 'A' + getdisk();    /* replace X with current drive letter */
   getcurdir(0, path+3);  /* fill rest of string with current directory */
   return(path);
}

void  main()
{
   FILE *f1;
   char curdir[MAXPATH];
   char cmd[100]="java -classpath ";
   char classname[15]=" Bookshop";
   current_directory(curdir);
   //printf("The current directory is %s\n", curdir);
   f1=fopen("JavaShop.bat","w");
   strcat(cmd,curdir);
   strcat(cmd,classname);
   printf("\n %s \n",cmd);
   fputs(cmd,f1);
   fclose(f1);
   exit(1);
}
