import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import javax.swing.border.*;
import javax.swing.colorchooser.*;
import javax.swing.filechooser.*;
import javax.accessibility.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import java.applet.*;
import java.net.*;
import java.util.Date;
import java.text.DateFormat;
import javax.swing.Icon;
import javax.swing.SwingConstants;
import java.sql.*;
/*@author Mr. Sachin Teke sssteke@yahoo.co.uk
 *
 */
public class AddDialog extends JFrame// implements ItemListener
{
    private PreparedStatement insert;     
    private Statement statement;
    private Connection connection;
    String sql;
    
    
    JLabel AddNewBook;
    JLabel ID;
    JLabel Title;
    JLabel Author;
    JLabel Edition;
    JLabel ISBN;
    JLabel Price;
    JLabel Copies;
    JLabel Category;
    JComboBox combobox_1;
    JTextField textfield_1;
    JTextField textfield_2;
    JTextField textfield_3;
    JTextField textfield_4;
    JTextField textfield_5;
    JTextField textfield_6;
    JTextField textfield_7;
    JButton Add;
    JButton Clear;
    public AddDialog() {
                        
        try 
   {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
   }
   catch ( ClassNotFoundException e ) 
   {
   }
   catch ( InstantiationException e ) 
   {
   }
   catch ( IllegalAccessException e ) 
   {
   }
   catch ( UnsupportedLookAndFeelException e ) 
   {
   }
        AddDialogLayout customLayout = new AddDialogLayout();

        getContentPane().setFont(new Font("Helvetica", Font.PLAIN, 12));
        getContentPane().setLayout(customLayout);

        AddNewBook = new JLabel("Add New Book");
        getContentPane().add(AddNewBook);

        ID = new JLabel("ID");
        getContentPane().add(ID);
        ID.setVisible(false);
        
        Title = new JLabel("Title");
        getContentPane().add(Title);

        Author = new JLabel("Author");
        getContentPane().add(Author);

        Edition = new JLabel("Edition");
        getContentPane().add(Edition);

        ISBN = new JLabel("ISBN");
        getContentPane().add(ISBN);

        Price = new JLabel("Price");
        getContentPane().add(Price);

        Copies = new JLabel("Copies (no.)");
        getContentPane().add(Copies);

        Category = new JLabel("Category");
        getContentPane().add(Category);

        combobox_1 = new JComboBox();
        combobox_1.addItem("Science");
        combobox_1.addItem("Commerce");
        combobox_1.addItem("Arts");
        combobox_1.addItem("Engineering");
        combobox_1.addItem("Medical");
        combobox_1.addItemListener(new ItemListener(){
        public void itemStateChanged(ItemEvent e){
      	     combobox_1ActionPerformed(e);
           }  
        });         
        

        getContentPane().add(combobox_1);

        textfield_1 = new JTextField("");
        getContentPane().add(textfield_1);
        textfield_1.setVisible(false);
        
        textfield_2 = new JTextField("");
        getContentPane().add(textfield_2);

        textfield_3 = new JTextField("");
        getContentPane().add(textfield_3);

        textfield_4 = new JTextField("");
        getContentPane().add(textfield_4);

        textfield_5 = new JTextField("");
        getContentPane().add(textfield_5);

        textfield_6 = new JTextField("");
        getContentPane().add(textfield_6);

        textfield_7 = new JTextField("");
        getContentPane().add(textfield_7);

        Add = new JButton("Add");//name is later chaged
        getContentPane().add(Add);
        Add.addActionListener(new ActionListener(){//////////////
            public void actionPerformed(ActionEvent e){
                 AddActionPerformed(e);
            }
        });

        Clear = new JButton("Clear");//name is later chaged
        getContentPane().add(Clear);
        Clear.addActionListener(new ActionListener(){//////////////
            public void actionPerformed(ActionEvent e){
                 ClearActionPerformed(e);
            }
        });
        
        
        
        setSize(getPreferredSize());
        JPanel MainPanel=new JPanel();     
        MainPanel.setBorder(new CompoundBorder(new TitledBorder(null,"Add New Book" ,
							  TitledBorder.CENTER, TitledBorder.TOP),new CompoundBorder() ));
        MainPanel.setBounds(5, 30, 600, 600);
        MainPanel.add(getContentPane());
             String[] OptionNames = { "Finish" };//
             String   OptionTitle = "Add Book Wizard (AddDialog)";//
        JOptionPane.showOptionDialog( null, MainPanel,OptionTitle ,
	               JOptionPane.CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE,
                   null,OptionNames,OptionNames[0]) ;
    
       // nameCardList.setBounds(5, 30, 160, 229);
        
     }

 

   public void AddActionPerformed(ActionEvent e){
	       // click of hButton
        BookCard BookCard =new BookCard(0,textfield_2.getText(),textfield_3.getText(),textfield_4.getText(),textfield_5.getText(),textfield_6.getText(),textfield_7.getText(),(String)combobox_1.getSelectedItem() );
        boolean added=Clerk.getInstance().addNewBook(BookCard);   
        if(added){
           JOptionPane.showConfirmDialog(null, "New book added to database!", "Confirmation", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE);
        }else{
           JOptionPane.showConfirmDialog(null, "New book not added to database! Wrong entries!", "Error !", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE);
         }
    }
        //end of Addaction performed       
        
        
      
        
     public void ClearActionPerformed(ActionEvent e){
	       // click of ClearButton
       
        textfield_2.setText(""); 
        textfield_3.setText(""); 
        textfield_4.setText(""); 
        textfield_5.setText(""); 
        textfield_6.setText(""); 
        textfield_7.setText("");       
       } 
        
        
        public void combobox_1ActionPerformed(ItemEvent e){
           // Category1=(String)combobox_1.getSelectedItem();//gets selected item from category
           // System.out.println(Category1);
        }

       public static void main(String args[]){
       AddDialog GUI41111=new AddDialog();	
       	
       }



}//end of class

class AddDialogLayout implements LayoutManager {

    public AddDialogLayout() {
    }

    public void addLayoutComponent(String name, Component comp) {
    }

    public void removeLayoutComponent(Component comp) {
    }

    public Dimension preferredLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);

        Insets insets = parent.getInsets();
        dim.width = 413 + insets.left + insets.right;
        dim.height = 422 + insets.top + insets.bottom;

        return dim;
    }

    public Dimension minimumLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);
        return dim;
    }

    public void layoutContainer(Container parent) {
        Insets insets = parent.getInsets();

        Component c;
        //c = parent.getComponent(0);
        //if (c.isVisible()) {c.setBounds(insets.left+152,insets.top+8,176,24);}
        c = parent.getComponent(1);
        if (c.isVisible()) {c.setBounds(insets.left+24,insets.top+56,80,24);}
        c = parent.getComponent(2);
        if (c.isVisible()) {c.setBounds(insets.left+24,insets.top+88,80,24);}
        c = parent.getComponent(3);
        if (c.isVisible()) {c.setBounds(insets.left+24,insets.top+120,80,24);}
        c = parent.getComponent(4);
        if (c.isVisible()) {c.setBounds(insets.left+24,insets.top+152,80,24);}
        c = parent.getComponent(5);
        if (c.isVisible()) {c.setBounds(insets.left+24,insets.top+184,80,24);}
        c = parent.getComponent(6);
        if (c.isVisible()) {c.setBounds(insets.left+24,insets.top+216,80,24);}
        c = parent.getComponent(7);
        if (c.isVisible()) {c.setBounds(insets.left+24,insets.top+248,80,24);}
        c = parent.getComponent(8);
        if (c.isVisible()) {c.setBounds(insets.left+24,insets.top+280,80,24);}
        c = parent.getComponent(9);
        if (c.isVisible()) {c.setBounds(insets.left+120,insets.top+280,128,24);}
        c = parent.getComponent(10);
        if (c.isVisible()) {c.setBounds(insets.left+120,insets.top+56,272,24);}
        c = parent.getComponent(11);
        if (c.isVisible()) {c.setBounds(insets.left+120,insets.top+88,272,24);}
        c = parent.getComponent(12);
        if (c.isVisible()) {c.setBounds(insets.left+120,insets.top+120,272,24);}
        c = parent.getComponent(13);
        if (c.isVisible()) {c.setBounds(insets.left+120,insets.top+152,272,24);}
        c = parent.getComponent(14);
        if (c.isVisible()) {c.setBounds(insets.left+120,insets.top+184,272,24);}
        c = parent.getComponent(15);
        if (c.isVisible()) {c.setBounds(insets.left+120,insets.top+216,272,24);}
        c = parent.getComponent(16);
        if (c.isVisible()) {c.setBounds(insets.left+120,insets.top+248,272,24);}
        c = parent.getComponent(17);
        if (c.isVisible()) {c.setBounds(insets.left+184,insets.top+328,72,24);}
        c = parent.getComponent(18);
        if (c.isVisible()) {c.setBounds(insets.left+280,insets.top+328,90,24);}
    }
}