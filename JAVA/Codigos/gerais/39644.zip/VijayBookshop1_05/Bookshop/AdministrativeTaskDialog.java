
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.table.*;
import javax.swing.event.*;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.event.*;
import javax.swing.border.*; 
import java.sql.*;  
import java.util.*;   
import javax.swing.event.*;   
import java.awt.event.KeyEvent;
import java.awt.event.InputEvent;
/*@author Mr. Sachin Teke sssteke@yahoo.co.uk
 *
 */

class AdministrativeTaskDialog extends JFrame implements TableModelListener{
   
   public Disable2TableModel model = new Disable2TableModel();
   JTextField SelectedIDTextField=new JTextField();
   int ROW;
   boolean ban=false;
   
   AdministrativeTaskDialog(){
   	                    
        try 
   {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
   }
   catch ( ClassNotFoundException e ) 
   {
   }
   catch ( InstantiationException e ) 
   {
   }
   catch ( IllegalAccessException e ) 
   {
   }
   catch ( UnsupportedLookAndFeelException e ) 
   {
   }
   	    
   	    model.addColumn("ID");
        model.addColumn("Book Name...");
        model.addColumn("Author....");
        model.addColumn("Edition");
        model.addColumn("ISBN...");
        model.addColumn("Price");
        model.addColumn("Copies");
        model.addColumn("Category");
        GUI();
   }
    
    
    public static void main(String args[]){
     AdministrativeTaskDialog g=new AdministrativeTaskDialog();
     
     } 
    
    
   //functions start
     public static void p(String st){
 	   System.out.println(st);
     }
     
    //GUI Function
    void GUI(){
    
        JTable table = new JTable(model);
        table.getTableHeader().setReorderingAllowed(false);
        table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(400,100));

        GridBagConstraints gridConstraints = new GridBagConstraints(); /*****/ 
        JPanel panel1 = new JPanel(new BorderLayout());
        panel1.add(scrollPane, BorderLayout.CENTER);
        panel1.setBorder(BorderFactory.createTitledBorder("Available Books"));
        
        JPanel panel2 = new JPanel(new GridBagLayout());/*****Panel3******/
        JLabel Garbage1Label=new JLabel();
        Garbage1Label.setText(".........................");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        panel2.add(Garbage1Label,gridConstraints);
        
        JButton AddButton = new JButton();/***Add Button****/
        AddButton.setText("Add new book");
        AddButton.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e){
      	    AddButtonActionPerformed(e);
          }
        });
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 0;
        panel2.add(AddButton,gridConstraints);
       
        JButton EditButton = new JButton(); ////Edit Button/////
        EditButton.setText("Edit");
        EditButton.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e){
      	    EditButtonActionPerformed(e);
          }
        });
        gridConstraints.gridx = 3;
        gridConstraints.gridy = 0;
        panel2.add(EditButton,gridConstraints);
        
        
        JButton DeleteButton = new JButton(); ////Delete Button////
        DeleteButton.setText("Delete");
        DeleteButton.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e){
      	    DeleteButtonActionPerformed(e);
          }
        });
        gridConstraints.gridx = 4;
        gridConstraints.gridy = 0;        
        panel2.add(DeleteButton,gridConstraints);

        JButton EditBookshopNameButton = new JButton(); ////EditBookshopName Button////
        EditBookshopNameButton.setText("Edit Bookshop Name");
        EditBookshopNameButton.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e){
      	    EditBookshopNameButtonActionPerformed(e);
          }
        });
        gridConstraints.gridx = 5;
        gridConstraints.gridy = 0; 
        panel2.add(EditBookshopNameButton,gridConstraints);
        
        JLabel SelectedIDLabel=new JLabel();
        SelectedIDLabel.setText("Selected ID");
        gridConstraints.gridx = 6;
        gridConstraints.gridy = 0;
        panel2.add(SelectedIDLabel,gridConstraints); 
         
        
        SelectedIDTextField.setColumns(8);
        SelectedIDTextField.setDisabledTextColor(Color.red);
        SelectedIDTextField.setEditable(false);
        gridConstraints.gridx =7 ;
        gridConstraints.gridy =0 ;
        panel2.add( SelectedIDTextField, gridConstraints);
 
        
        
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(panel2,BorderLayout.NORTH);
        panel.add(panel1,BorderLayout.CENTER);
        
        
        JLabel Garbage2Label=new JLabel();
        Garbage2Label.setText("............................");
        gridConstraints.gridx = 8;
        gridConstraints.gridy = 0;
        panel2.add(Garbage2Label,gridConstraints);
        Insets insets ;
        getContentPane().add(panel); 
        
        JPanel MainPanel=new JPanel();     
        MainPanel.setBorder(new CompoundBorder(new TitledBorder(null,"Tasks" ,
							  TitledBorder.CENTER, TitledBorder.TOP),new CompoundBorder() ));
        MainPanel.add(getContentPane());
        String[] OptionNames = { "Close" };//
        String   OptionTitle = "Administrative tasks";//
   
        receiveTable();
        table.getModel().addTableModelListener(this);
        JOptionPane Pane =new JOptionPane();
        Pane.showOptionDialog( null, MainPanel,OptionTitle ,
	    Pane.CANCEL_OPTION, Pane.PLAIN_MESSAGE,
        null,OptionNames,OptionNames[0]);
        table.getModel().removeTableModelListener(this);
        
        

    
    }
    
    
 //Action performer

 //for Add Button
 private void AddButtonActionPerformed(ActionEvent e){
	// click of SearchButton
    p("AddButton");
    Clerk.getInstance().getAddDialogFromRegister();
   //  adddialog = new AddDialog();
    receiveTable();
 }    


//for Edit Button
  private void EditButtonActionPerformed(ActionEvent e){
	// click of Edit Button
    p("EditButton");
        
        BookCard  BookCardtemp=new  BookCard();    
        
        int intID=stringToInt((String)model.getValueAt(ROW,0));
       // System.out.println(""+intID  +(String)model.getValueAt(ROW,1) );
        BookCardtemp.setID(intID);
        BookCardtemp.setBookName((String)model.getValueAt(ROW,1));
        BookCardtemp.setAuthor((String)model.getValueAt(ROW,2));
        BookCardtemp.setEdition((String)model.getValueAt(ROW,3));
        BookCardtemp.setISBN((String)model.getValueAt(ROW,4));
        BookCardtemp.setPrice((String)model.getValueAt(ROW,5));
        BookCardtemp.setCopies((String)model.getValueAt(ROW,6));
        BookCardtemp.setCategory((String)model.getValueAt(ROW,7));
        Clerk.getInstance().editBookCard(BookCardtemp);
        receiveTable();
   
   
  }    

//for  DeleteButton
  private void DeleteButtonActionPerformed(ActionEvent e){
	// click of SearchButton
    int Confirmdelete;
    p("DeleteButton");
    BookCard  BookCardtemp=new  BookCard();    
    int intID=stringToInt((String)model.getValueAt(ROW,0));
    BookCardtemp.setID(intID);
    Confirmdelete=JOptionPane.showConfirmDialog(null, "       Confirm delete Book ID "+intID, "Confirmation", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
    if(Confirmdelete==0){
        Clerk.getInstance().deleteBookCard(BookCardtemp);
        receiveTable();
    }
 }   



//for  EditBookshopNameButton
  private void EditBookshopNameButtonActionPerformed(ActionEvent e){
	// click of EditBookshopName Button
    p("EditBookshopNameButton");
    Clerk.getInstance().getEditBookshopNameDialogFromRegister();
  }   

   public void receiveTable(){	
   	   ban=true;
   	   model.setRowCount(0);
       System.out.println("receiveing table");
       String ID=new String();
       String BookName=new String();
       String Author=new String();
       String Edition=new String();
       String ISBN=new String();
       String Price=new String();
       String Copies=new String();
       String Category=new String(); 
       int i=0; 
       String tempid=new String();        
       Vector BookCardEntries=Clerk.getInstance().getAllBookCard();
       BookCard  BookCardtemp=new  BookCard();        
       for(i=0;i<BookCardEntries.size();i++){
         BookCardtemp=(BookCard)BookCardEntries.elementAt(i);
         tempid=""+BookCardtemp.getID()+"";
         model.addRow(new String[]{ tempid,
           	                          BookCardtemp.getBookName(),
           	                          BookCardtemp.getAuthor(),
           	                          BookCardtemp.getEdition(),
           	                          BookCardtemp.getISBN(),
           	                          BookCardtemp.getPrice(),
           	                          BookCardtemp.getCopies(),
           	                          BookCardtemp.getCategory()
                     });
      }   
     ban=false;
  }      

  public void tableChanged(TableModelEvent e) {
        int ID;
        int row = e.getFirstRow();
        int column = e.getColumn();
        TableModel model = (TableModel)e.getSource();
        //System.out.println("Table changed column="+column+" row="+row);
        
        //make BookCard Object and send to Edit to Clerk
        ROW=row;
        if(!ban){
         SelectedIDTextField.setText((String)model.getValueAt(ROW,0));
        }
       }

   public int stringToInt(String st){
		int temp1=1,temp2=0;
		char ww='y'; 
		int con=1;
		int y=0;
		y=st.length();
		for(int i=(y-1);i>=0;i--){
			
			ww=st.charAt(i);
			temp1=ww-48;
			temp2=temp2+con*temp1;
			con=con*10;
			}
	
	    return(temp2);
	}   

}//End of class 

 class Disable2TableModel extends DefaultTableModel /*implements Serializable*/{
   public boolean isCellEditable(int row, int col) {
    //Note that the data/cell address is constant,
    //no matter where the cell appears onscreen.
    if (col < 1) {
        return false;
    } else {
        return true;
      }
   } 
 }