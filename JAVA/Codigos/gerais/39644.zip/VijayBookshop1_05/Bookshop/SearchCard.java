/*@author Mr. Sachin Teke sssteke@yahoo.co.uk
 *
 */

class SearchCard{
	
  String BookName=new String();
  String Author=new String();
  String ISBN=new String();
  String ID=new String();
  String Category=new String();
  boolean BookNameboolean;
  boolean Authorboolean;
  boolean ISBNboolean;
  boolean IDboolean;
  boolean Categoryboolean;	
  
 SearchCard(String BookName1,
                  String Author1,
                  String ISBN1,
                  String ID1,
                  String Category1,
                  boolean BookNameboolean1,
                  boolean Authorboolean1,
                  boolean ISBNboolean1,
                  boolean IDboolean1,
                  boolean Categoryboolean1	
                  ){
 
  BookName=BookName1;
  Author=Author1;
  ISBN=ISBN1;
  ID=ID1;
  Category=Category1;
  BookNameboolean=BookNameboolean1;
  Authorboolean=Authorboolean1;
  ISBNboolean=ISBNboolean1;
  IDboolean=IDboolean1;
  Categoryboolean=Categoryboolean1;	

 
 } 
	
   public String getBookName(){
     return BookName;
   }
   
   public String getAuthor(){
     return Author;
   }
   
   public String getISBN(){
     return ISBN;
   }
   
   public String getID(){
     return ID;
   }
   
   public String getCategory(){
     return Category;
   }
   
   public boolean getBookNameboolean(){
     return BookNameboolean;
   }
   
   public boolean getAuthorboolean(){
     return Authorboolean;
   }
   
   public boolean getISBNboolean(){
     return ISBNboolean ;
   }
   
   public boolean getIDboolean(){
     return IDboolean;
   }
   
   public boolean getCategoryboolean(){
     return Categoryboolean;
   }
    
}

 /* BookName1;
  Author1;
  ISBN1;
  ID1;
  Category1;
  BookName1;
  Author1;
  ISBN1;
  ID1;
  Category1;	
*/