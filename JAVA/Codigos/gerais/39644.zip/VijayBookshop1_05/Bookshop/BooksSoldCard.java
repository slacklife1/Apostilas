
/*@author Mr. Sachin Teke sssteke@yahoo.co.uk
 *
 */


  public class BooksSoldCard{
    
    private int     SrNo;
    private int     CustomerID;
    private String  CustomerName;
    private String  DateTime;
    private int     BookID;
    private String  Title;
    private String  Author;
    private float   Price;
    private int     CopiesSold;

    // Constructors
    public  BooksSoldCard(){
        
  }

  public BooksSoldCard(int SrNo,
                       int CustomerID,
                       String CustomerName,
                       String  DateTime,
                       int BookID,
                       String Title,
                       String  Author,
                       float Price,
                       int CopiesSold ) {
   
    this.SrNo         = SrNo ;
    this.CustomerID   = CustomerID ;
    this.CustomerName = CustomerName;
    this.DateTime     = DateTime ;
    this.BookID       = BookID;
    this.Title        = Title;
    this.Author       = Author;
    this.Price        = Price;
    this.CopiesSold   = CopiesSold;
    
  }



    // Methods
    public int getSrNo() {
        return SrNo;
    }

    public void setSrNo(int SrNo) {
        this.SrNo = SrNo;
    }

    public int getCustomerID() {
        return CustomerID;
    }

    public void setCustomerID(int CustomerID) {
        this.CustomerID = CustomerID;
    }

    public String getCustomerName() {
        return CustomerName;
    }

    public void setCustomerName(String CustomerName) {
        this.CustomerName = CustomerName;
    }

    public String getDateTime() {
        return DateTime;
    }

    public void setDateTime(String DateTime) {
        this.DateTime = DateTime;
    }
    
    public int getBookID() {
        return BookID;
    }

    public void setBookID( int BookID) {
        this.BookID = BookID;
    }
    
    public String getTitle() {
        return Title;
    }

    public void setTitle(String Title) {
        this.Title = Title;
    }

    public String getAuthor() {
        return Author;
    }

    public void setAuthor(String Author) {
        this.Author = Author;
    }

    public float getPrice() {
        return Price;
    }

    public void setPrice(float Price) {
        this.Price = Price;
    }
    
    public int getCopiesSold() {
        return CopiesSold;
    }

    public void setCopiesSold(int CopiesSold) {
        this.CopiesSold = CopiesSold;
    }

}
