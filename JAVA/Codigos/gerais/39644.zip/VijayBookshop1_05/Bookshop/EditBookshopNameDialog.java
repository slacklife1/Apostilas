import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*; 
/*@author Mr. Sachin Teke sssteke@yahoo.co.uk
 *
 */
public class EditBookshopNameDialog extends JFrame {
   JLabel CurrentBookshopName;
   JTextField textfield_1;
   JLabel NewName;
   JTextField textfield_2;
   JButton OK;

    public EditBookshopNameDialog() {
                
        try 
   {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
   }
   catch ( ClassNotFoundException e ) 
   {
   }
   catch ( InstantiationException e ) 
   {
   }
   catch ( IllegalAccessException e ) 
   {
   }
   catch ( UnsupportedLookAndFeelException e ) 
   {
   }
        
        EditBookshopNameDialogLayout customLayout = new EditBookshopNameDialogLayout();

        getContentPane().setFont(new Font("Helvetica", Font.PLAIN, 12));
        getContentPane().setLayout(customLayout);

        CurrentBookshopName = new JLabel("Current Bookshop  Name");
        getContentPane().add(CurrentBookshopName);

        textfield_1 = new JTextField("");
        getContentPane().add(textfield_1);

        NewName = new JLabel("New Name");
        getContentPane().add(NewName);

        textfield_2 = new JTextField("");
        getContentPane().add(textfield_2);

       // OK = new JButton("OK");
       // getContentPane().add(OK);

        textfield_1.setText(Clerk.getInstance().getBookshopName());
        textfield_1.setEditable(false);
        setSize(getPreferredSize());
        JPanel MainPanel=new JPanel();     
        MainPanel.setBorder(new CompoundBorder(new TitledBorder(null,"Edit bookshop name" ,
							  TitledBorder.CENTER, TitledBorder.TOP),new CompoundBorder() ));
        MainPanel.add(getContentPane());
             String[] OptionNames = { "OK","Cancel" };
             String   OptionTitle = "Edit bookshop name Wizard";
        int select=JOptionPane.showOptionDialog( null, MainPanel,OptionTitle ,
	               JOptionPane.CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE,
                   null,OptionNames,OptionNames[0]) ;
    
        System.out.println(""+select);
        if(select==0){
          System.out.println(textfield_2.getText());
          Clerk.getInstance().changeBookshopName(textfield_2.getText());
        }
        



        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
              //  System.exit(0);
            }
        });
    }

    public static void main(String args[]) {

       EditBookshopNameDialog window = new EditBookshopNameDialog();

        window.setTitle("EditBookshopNameDialog");
        window.pack();
        //window.show();
    }
}

class EditBookshopNameDialogLayout implements LayoutManager {

    public EditBookshopNameDialogLayout() {
    }

    public void addLayoutComponent(String name, Component comp) {
    }

    public void removeLayoutComponent(Component comp) {
    }

    public Dimension preferredLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);

        Insets insets = parent.getInsets();
        dim.width = 465 + insets.left + insets.right;
        dim.height = 149 + insets.top + insets.bottom;

        return dim;
    }

    public Dimension minimumLayoutSize(Container parent) {
        Dimension dim = new Dimension(0, 0);
        return dim;
    }

    public void layoutContainer(Container parent) {
        Insets insets = parent.getInsets();

        Component c;
        c = parent.getComponent(0);
        if (c.isVisible()) {c.setBounds(insets.left+24,insets.top+40,160,24);}
        c = parent.getComponent(1);
        if (c.isVisible()) {c.setBounds(insets.left+184,insets.top+40,264,24);}
        c = parent.getComponent(2);
        if (c.isVisible()) {c.setBounds(insets.left+24,insets.top+72,160,24);}
        c = parent.getComponent(3);
        if (c.isVisible()) {c.setBounds(insets.left+184,insets.top+72,264,24);}
        //c = parent.getComponent(4);
        //if (c.isVisible()) {c.setBounds(insets.left+192,insets.top+104,72,24);}
    }
}
