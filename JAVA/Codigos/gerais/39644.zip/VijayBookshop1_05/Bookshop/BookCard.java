
import java.awt.*;
/*@author Mr. Sachin Teke sssteke@yahoo.co.uk
 *
 */
public class BookCard
{
    // Fields//ID, BookName, Author, Edition, ISBN, Price, Copies, Category
    private int     ID;
    private String  BookName;
    private String  Author;
    private String  Edition;
    private String  ISBN;
    private String  Price;
    private String  Copies;
    private String  Category;
    

    // Constructors
    public  BookCard(){
        
    }

    public BookCard(int ID, String  BookName, String Author, String Edition,
    String ISBN, String Price, String Copies, String Category) {
        this.ID       = ID;
        this.BookName = BookName;
        this.Author   = Author;
        this.Edition  = Edition;
        this.ISBN     = ISBN;
        this.Price    = Price;
        this.Copies   = Copies;
        this.Category = Category;
        
    }



    // Methods
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getBookName() {
        return BookName;
    }

    public void setBookName(String BookName) {
        this.BookName = BookName;
    }

    public String getAuthor() {
        return Author;
    }

    public void setAuthor(String Author) {
        this.Author = Author;
    }

    public String getEdition() {
        return Edition;
    }

    public void setEdition(String Edition) {
        this.Edition = Edition;
    }
    
    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }
    
    public String getPrice() {
        return Price;
    }

    public void setPrice(String Price) {
        this.Price = Price;
    }

    public String getCopies() {
        return Copies;
    }

    public void setCopies(String Copies) {
        this.Copies = Copies;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String Category) {
        this.Category = Category;
    }

}
