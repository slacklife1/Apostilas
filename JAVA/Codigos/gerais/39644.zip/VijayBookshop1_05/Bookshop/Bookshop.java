
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import javax.swing.border.*;
import javax.swing.colorchooser.*;
import javax.swing.filechooser.*;
import javax.accessibility.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.util.*;
import java.io.*;
import java.applet.*;
import java.net.*;
import java.util.Date;
import java.text.DateFormat;
import javax.swing.Icon;
import javax.swing.SwingConstants;
import java.sql.*; 
import java.awt.image.*;
/*@author Mr. Sachin Teke sssteke@yahoo.co.uk
 *
 */

public class Bookshop extends JFrame 
{
  Administrator Admin=new Administrator();
  Clerk clerk1;
  //1
  static JLabel BookshopNameLabel = new JLabel();
  
  //2(1)
  static JCheckBox BookNameCheckBox = new JCheckBox();
  static JCheckBox AuthorCheckBox = new JCheckBox();
  static JCheckBox ISBNCheckBox = new JCheckBox();
  static JCheckBox CategoryCheckBox = new JCheckBox();    
  static JCheckBox IDCheckBox = new JCheckBox();
  
  //2(2)
  static JTextField BookNameTextField = new JTextField();
  static JTextField AuthorTextField = new JTextField();
  static JTextField ISBNTextField = new JTextField();
  static JTextField IDTextField = new JTextField(); 

  static JComboBox  CategoryComboBox= new JComboBox();
  static JButton SearchButton = new JButton();
  
  //3
  static JButton BuyBookButton = new JButton();
  
  
  //4
  static JButton ReportButton = new JButton();
  
  //5
  static JLabel DateLabel = new JLabel();
  static JLabel TimeLabel = new JLabel();
  static JTextField DateTextField = new JTextField();
  static JTextField TimeTextField = new JTextField();
  
  //6
  static JLabel UserNameLabel = new JLabel();
  static JLabel PasswordLabel = new JLabel();
  static JButton OKButton = new JButton();
  static JTextField UserNameTextField = new JTextField();
  static JPasswordField inputPasswordField = new JPasswordField();
  
  
  //7
  static javax.swing.Timer myTimer;
  
  boolean BookNameCheckBoxboolean;
  boolean AuthorCheckBoxboolean;
  boolean ISBNCheckBoxboolean;
  boolean IDCheckBoxboolean;
  boolean CategoryCheckBoxboolean;
  
  
  //main Method
  public static void main(String args[]){
    new Bookshop().show();
    myTimer.start();
  }
  
  
  //VijayBookshop constructor
  public Bookshop(){
                    
        try 
   {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
   }
   catch ( ClassNotFoundException e ) 
   {
   }
   catch ( InstantiationException e ) 
   {
   }
   catch ( IllegalAccessException e ) 
   {
   }
   catch ( UnsupportedLookAndFeelException e ) 
   {
   }
    //Panels 
    JPanel p0 = new JPanel(new GridBagLayout());
    p0.setBorder(new CompoundBorder(new TitledBorder(null,clerk1.getInstance().getBookshopName() ,
							  TitledBorder.CENTER, TitledBorder.TOP),new CompoundBorder() ));
    p0.setBackground(new Color(205,231,255));
       
    
    JPanel p1 = new JPanel(new GridBagLayout());
    p1.setBorder(new CompoundBorder(new TitledBorder(null,"" ,
							  TitledBorder.LEFT, TitledBorder.TOP),new CompoundBorder() ));
    p1.setBackground(new Color(205,231,255));
    
    JPanel p2 = new JPanel(new GridBagLayout());
    p2.setBorder(new CompoundBorder(new TitledBorder(null,"" ,
							  TitledBorder.CENTER, TitledBorder.TOP),new CompoundBorder() ));
    p2.setBackground(new Color(205,231,255));  							  
	
	JPanel p1_2 = new JPanel(new GridBagLayout());
    p1_2.setBorder(new CompoundBorder(new TitledBorder(null,"" ,
							  TitledBorder.CENTER, TitledBorder.TOP),new CompoundBorder() ));
	p1_2.setBackground(new Color(255,216,39));
	
	JPanel p2_1 = new JPanel(new GridBagLayout());
    p2_1.setBorder(new CompoundBorder(new TitledBorder(null,"Search Options" ,
							  TitledBorder.CENTER, TitledBorder.TOP),new CompoundBorder() ));
	p2_1.setBackground(new Color(205,231,255));			  
    
    JPanel p2_2 = new JPanel(new GridBagLayout());
    p2_2.setBorder(new CompoundBorder(new TitledBorder(null,"" ,
							  TitledBorder.CENTER, TitledBorder.TOP),new CompoundBorder() ));
    p2_2.setBackground(new Color(205,231,255));			  
    
    JPanel p2_3 = new JPanel(new GridBagLayout());
    p2_3.setBorder(new CompoundBorder(new TitledBorder(null,"" ,
	     TitledBorder.CENTER, TitledBorder.TOP),new CompoundBorder() ));
	p2_3.setBackground(new Color(205,231,255));	     
	     
    JPanel p2_4 = new JPanel(new GridBagLayout());
    p2_4.setBorder(new CompoundBorder(new TitledBorder(null,"Administrator" ,
							  TitledBorder.CENTER, TitledBorder.TOP),new CompoundBorder() ));
    p2_4.setBackground(new Color(205,231,255));			  
    
    // Frame constructor
    setSize(1000,1000);
    setTitle("VijayBookshop Application");
    getContentPane().setBackground(Color.GRAY);
    getContentPane().setForeground( Color.GREEN);
    addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
    		exitForm(e);
      }
    });
    getContentPane().setLayout(new GridBagLayout());

    // add controls
    GridBagConstraints gridConstraints = new GridBagConstraints(); 
    

    ////new Chekbox option   
    BookNameCheckBox.setText("Book Name");
    BookNameCheckBox.setBackground(new Color(205,231,255));
    gridConstraints.gridx = 0;
    gridConstraints.gridy = 1;
    p2_1.add(BookNameCheckBox, gridConstraints);
    BookNameCheckBox.addItemListener(new ItemListener(){
      public void itemStateChanged(ItemEvent e){
      	 BookNameCheckBoxActionPerformed(e);
      }
    }); 
    
    
    
    AuthorCheckBox.setText("Author");
    AuthorCheckBox.setAlignmentX(SwingConstants.LEFT);
    AuthorCheckBox.setBackground(new Color(205,231,255));
    gridConstraints.gridx =0;
    gridConstraints.gridy =2;
    p2_1.add( AuthorCheckBox, gridConstraints);
    AuthorCheckBox.addItemListener(new ItemListener(){
      public void itemStateChanged(ItemEvent e){
      	 AuthorCheckBoxActionPerformed(e);
      }
    }); 
    
    
    ISBNCheckBox.setText("ISBN");
    ISBNCheckBox.setBackground(new Color(205,231,255));
    gridConstraints.gridx =0 ;
    gridConstraints.gridy =3 ;
    p2_1.add(ISBNCheckBox , gridConstraints);
    ISBNCheckBox.addItemListener(new ItemListener(){
      public void itemStateChanged(ItemEvent e){
      	 ISBNCheckBoxActionPerformed(e);
      }
    }); 
    
    IDCheckBox.setText("ID");
    IDCheckBox.setBackground(new Color(205,231,255));
    gridConstraints.gridx =0 ;
    gridConstraints.gridy =4 ;
    p2_1.add(IDCheckBox , gridConstraints);
    IDCheckBox.addItemListener(new ItemListener(){
      public void itemStateChanged(ItemEvent e){
      	 IDCheckBoxActionPerformed(e);
      }
    }); 
    
    
    CategoryCheckBox.setText("Category");
    CategoryCheckBox.setBackground(new Color(205,231,255));
    gridConstraints.gridx =0 ;
    gridConstraints.gridy =5 ;
    p2_1.add(CategoryCheckBox , gridConstraints); 
    CategoryCheckBox.addItemListener(new ItemListener(){
      public void itemStateChanged(ItemEvent e){
      	 CategoryCheckBoxActionPerformed(e);
      }
    }); 
    
    
    //2(2)    
    BookNameTextField.setText("");
    BookNameTextField.setColumns(15);
    gridConstraints.gridx =1 ;
    gridConstraints.gridy =1 ;
    p2_1.add( BookNameTextField, gridConstraints);
    
    AuthorTextField.setText("");
    AuthorTextField.setColumns(15);
    gridConstraints.gridx =1 ;
    gridConstraints.gridy =2 ;
    p2_1.add( AuthorTextField, gridConstraints);    
    
    ISBNTextField.setText("");
    ISBNTextField.setColumns(15);
    gridConstraints.gridx =1 ;
    gridConstraints.gridy =3 ;
    p2_1.add( ISBNTextField, gridConstraints);
    
    IDTextField.setText("");
    IDTextField.setColumns(15);
    gridConstraints.gridx =1 ;
    gridConstraints.gridy =4 ;
    p2_1.add( IDTextField, gridConstraints);
    
    CategoryComboBox.addItem("Science");
    CategoryComboBox.addItem("Commerce");
    CategoryComboBox.addItem("Arts");
    CategoryComboBox.addItem("Engineering");
    CategoryComboBox.addItem("Medical");
    gridConstraints.gridx =1 ;
    gridConstraints.gridy =5 ;
    p2_1.add( CategoryComboBox, gridConstraints);
    CategoryComboBox.addItemListener(new ItemListener(){
      public void itemStateChanged(ItemEvent e){
      	 CategoryComboBoxActionPerformed(e);
      }
    }); 
    
    
    SearchButton.setText("Search");
    gridConstraints.gridx =0 ;
    gridConstraints.gridy =6 ;
    p2_1.add(SearchButton, gridConstraints);
    SearchButton.setBackground(new Color(15,0,116));
    SearchButton.setForeground(Color.WHITE);
    SearchButton.addActionListener(new ActionListener() 
    {
      public void actionPerformed(ActionEvent e) 
      {
      	SearchButtonActionPerformed(e);
      }
    });
    
    //3
    BuyBookButton.setText("Buy Book");
    gridConstraints.gridx =0 ;
    gridConstraints.gridy =0 ;
    p2_2.add(BuyBookButton, gridConstraints);
    BuyBookButton.setBackground(new Color(15,0,116));
    BuyBookButton.setForeground(Color.WHITE);   
    BuyBookButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e){
      	 BuyBookButtonActionPerformed(e);
      }
    });
    
    //4
    ReportButton.setText("Report");
    gridConstraints.gridx =0 ;
    gridConstraints.gridy =0 ;
    p2_3.add(ReportButton, gridConstraints);
    ReportButton.setBackground(new Color(15,0,116));
    ReportButton.setForeground(Color.WHITE);
    ReportButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
      	 ReportButtonActionPerformed(e);
      }
    });
    
    
    //5
    DateLabel.setText("Date");
    gridConstraints.gridx =0 ;
    gridConstraints.gridy =0 ;
    p1_2.add(DateLabel , gridConstraints);
    DateTextField.setText("");
    DateTextField.setColumns(15);
    gridConstraints.gridx =1 ;
    gridConstraints.gridy =0 ;
    p1_2.add( DateTextField, gridConstraints);

    TimeLabel.setText("Time");
    gridConstraints.gridx =0 ;
    gridConstraints.gridy =1 ;
    p1_2.add( TimeLabel, gridConstraints);
    TimeTextField.setText("");
    TimeTextField.setColumns(15);
    gridConstraints.gridx =1 ;
    gridConstraints.gridy =1 ;
    p1_2.add( TimeTextField, gridConstraints);

    //6    
    UserNameLabel.setText("User Name");
    gridConstraints.gridx =0 ;
    gridConstraints.gridy =1 ;
    p2_4.add( UserNameLabel, gridConstraints);
    UserNameTextField.setText("");
    UserNameTextField.setColumns(15);
    gridConstraints.gridx =1 ;
    gridConstraints.gridy =1 ;
    p2_4.add( UserNameTextField, gridConstraints);
    
    PasswordLabel.setText("Password");
    gridConstraints.gridx =0 ;
    gridConstraints.gridy =2 ;
    p2_4.add( PasswordLabel, gridConstraints);
    inputPasswordField.setText("");
    inputPasswordField.setColumns(15);
    gridConstraints.gridx =1 ;
    gridConstraints.gridy =2 ;
    p2_4.add( inputPasswordField, gridConstraints);
    
    
    OKButton.setText("OK");
    gridConstraints.gridx =1 ;
    gridConstraints.gridy =3 ;
    p2_4.add(OKButton, gridConstraints);
    OKButton.setBackground(new Color(15,0,116));
    OKButton.setForeground(Color.WHITE);
    OKButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
      	 OKButtonActionPerformed(e);
      }
    });
    
    //7
    myTimer = new javax.swing.Timer(1000, new ActionListener(){
       public void actionPerformed(ActionEvent e){
    		myTimerActionPerformed(e);
       }
    });
    
    //panel operations
    p1.add(p1_2);
    gridConstraints.gridx =0 ;
    gridConstraints.gridy =0 ;
    p0.add(p1,gridConstraints);    
    
    p2.add(p2_1);
    p2.add(p2_2);
    p2.add(p2_3);
    p2.add(p2_4);
    gridConstraints.gridx =0 ;
    gridConstraints.gridy =1 ;
    p0.add(p2,gridConstraints);
    
    getContentPane().add( p0);    
    
 }//constructor end
 
 //functions start
 public void p(String st){
 	System.out.println(st);
 }
 
 private void exitForm(WindowEvent e){
    System.exit(0);
 }
 
 //for ComboBox
 
 public void CategoryComboBoxActionPerformed(ItemEvent e){
    
    String Category=(String)CategoryComboBox.getSelectedItem();//gets selected item from category
    p(Category);
 }	
 
 
 //for SearchButton
 private void SearchButtonActionPerformed(ActionEvent e){
	// click of SearchButton
    p("SearchButton");
    System.out.println(""+ BookNameCheckBoxboolean + AuthorCheckBoxboolean + ISBNCheckBoxboolean + IDCheckBoxboolean + CategoryCheckBoxboolean);
    SearchCard SearchCard1=new  SearchCard(BookNameTextField.getText(),
                                                             AuthorTextField.getText(),
                                                             ISBNTextField.getText(),
                                                             IDTextField.getText(),
                                                             (String)CategoryComboBox.getSelectedItem(),
                                                             BookNameCheckBoxboolean,
                                                             AuthorCheckBoxboolean,
                                                             ISBNCheckBoxboolean,
                                                             IDCheckBoxboolean,
                                                             CategoryCheckBoxboolean
                                                             );
    
    //System.out.println("**********boo****** "+SearchCard1.getBookNameboolean());
    Clerk.getInstance().getSearchDialogFromRegister(SearchCard1 );      
                     
 }
 
 //for BuyBookButton
 private void BuyBookButtonActionPerformed(ActionEvent e){
	// click of BuyBookButton
    p("BuyBookButton");
    Clerk.getInstance().getBuyDialogFromRegister();	
   
 } 

 //for ReportButton
 private void ReportButtonActionPerformed(ActionEvent e){
	// click of ReportButton
    p("ReportButton");
    Clerk.getInstance().getBooksSoldDialogFromRegister();	
  
 }
 
  //for Administrator's OKButton
 private void OKButtonActionPerformed(ActionEvent e){
	// click of Button
    p("OKButton");
    boolean temp;
    Admin.setUserName(UserNameTextField.getText());
    Admin.setPassword(inputPasswordField.getText());
    temp=Clerk.getInstance().getValidAdministrator(Admin);
    if(temp){
       JOptionPane.showConfirmDialog(null,"Welcome "+UserNameTextField.getText()+ ",You've passed security!", "Access Granted", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE);
       Clerk.getInstance().getAdministrativeTaskDialogFromRegister();	 
      
    }else{
       JOptionPane.showConfirmDialog(null, "Incorrect username/password - Try Again!", "Access Denied", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE);
     }
    inputPasswordField.setText("");
    
 }
 

 //for CheckBoxes
     /** Listens to the check boxes. */
     

     
 
 void BookNameCheckBoxActionPerformed(ItemEvent e){
    BookNameCheckBoxboolean =!(BookNameCheckBoxboolean);
 }
 
 void AuthorCheckBoxActionPerformed(ItemEvent e){
    AuthorCheckBoxboolean = !(AuthorCheckBoxboolean);
 } 

 void ISBNCheckBoxActionPerformed(ItemEvent e){
    ISBNCheckBoxboolean = !(ISBNCheckBoxboolean);
 }  
 
 void IDCheckBoxActionPerformed(ItemEvent e){
    IDCheckBoxboolean = !(IDCheckBoxboolean);
 } 
 
 void CategoryCheckBoxActionPerformed(ItemEvent e){
    CategoryCheckBoxboolean = !(CategoryCheckBoxboolean);
 } 
 
 //for myTimer
 private void myTimerActionPerformed(ActionEvent e){
		// display date and time
	Date today = new Date();
	DateTextField.setText(DateFormat.getDateInstance(DateFormat.FULL).format(today));
	TimeTextField.setText(DateFormat.getTimeInstance().format(today));
 }

}//class VijayBookshop end

 