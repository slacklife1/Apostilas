import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.table.*;
import javax.swing.event.*;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.event.*;
import javax.swing.border.*; 
import java.sql.*;  
import java.util.*;   
import javax.swing.event.*;   
import java.awt.event.KeyEvent;
import java.awt.event.InputEvent;

/*@author Mr. Sachin Teke sssteke@yahoo.co.uk
 *
 */

class Administrator extends BookshopStaff{

 private String UserName=new String();
 private String Password=new String();
 
 public String getUserName(){
  return UserName;
 }
 
 public String getPassword(){
  return Password;
 }
 public void setUserName(String UName){
  UserName=UName;
 }
 
 public void setPassword(String PName){
  Password= PName;
 }
 

}