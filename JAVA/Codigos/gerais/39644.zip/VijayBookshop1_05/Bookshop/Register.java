
import java.util.Vector;
/*@author Mr. Sachin Teke sssteke@yahoo.co.uk
 *
 */
class Register{
 
 private AdministrativeTaskDialog AdministrativeTaskDialog1; 
 private BooksSoldDialog BooksSoldDialog1;
 private BuyDialog BuyDialog1;
 private SearchDialog SearchDialog1;
 private AddDialog AddDialog1;	
 private EditBookshopNameDialog EditBookshopNameDialog1;	
  
 public void getAdministrativeTaskDialog(){
  AdministrativeTaskDialog1=new AdministrativeTaskDialog();
 }	
 
 public void getAddDialog(){
  AddDialog1=new AddDialog();
 }	

  public void getEditBookshopNameDialog(){
  EditBookshopNameDialog1=new EditBookshopNameDialog();
 }	
 
 
  public void getBooksSoldDialog(){
  BooksSoldDialog1=new BooksSoldDialog();
 }	
 
  public void getBuyDialog(){
  BuyDialog1=new BuyDialog();
 }	

 public void getSearchDialog(Vector BookCardEntries){
  SearchDialog1=new SearchDialog(BookCardEntries);
 }	
 

 public static void main(String args[]){
   Register r=new Register();
  // r.getAdministrativeTaskDialog();
 }	
}