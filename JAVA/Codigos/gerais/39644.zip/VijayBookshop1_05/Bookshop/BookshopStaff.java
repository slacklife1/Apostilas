/*@author Mr. Sachin Teke sssteke@yahoo.co.uk
 *
 */
class BookshopStaff{
 private String Name1=new String();	
	
}