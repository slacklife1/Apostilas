
import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.util.*;
import java.awt.*;
import java.lang.StringBuffer;
import javax.swing.JOptionPane;

/*@author Mr. Sachin Teke sssteke@yahoo.co.uk
 *
 */
class Clerk extends BookshopStaff {
    private static Clerk instance; // for Singleton Pattern
    private Register Register1=new Register();
   
    private String driver;
    private String url;
    private String user;
    private String password;
    private boolean delay;
    private Connection connection;
    private Statement statement;
    private PreparedStatement addNewBook;
    private PreparedStatement delete;
    private PreparedStatement edit;
    private PreparedStatement seeDatabaseAvailableBooks;
    private PreparedStatement seeDatabaseBooksSold;
    private PreparedStatement updateCopies;
    
    static Clerk getInstance() {
        if (instance == null) {
            instance = new Clerk();
        }
        return instance;
    }

    
 /*   //Mysql
        Clerk() {
        // get parameters
        Properties properties = new Properties();
        driver =
            properties.getProperty("driver","com.mysql.jdbc.Driver");
        url =
            properties.getProperty("url", "jdbc:mysql://localhost,localhost/vijaybookshop");
        user =
            properties.getProperty("user", "");
        password =
            properties.getProperty("password", "");
        delay =
            properties.getProperty("delayread","true").equals("true");
        connect();
    } */
    
    
    
   ////MicrosoftAcesss  
     Clerk() {
        // get parameters
        //if database lies  in directory where .class files of vijay bookshop are located
        File f1=new File("vijaybookshop.mdb");  ////////////////////////////
 	    StringBuffer DatabaseFilePath=new StringBuffer();
 	    try{ 
 	        DatabaseFilePath =new StringBuffer(f1.getCanonicalPath());//gets current directory path
 	        System.out.println(f1.getCanonicalPath() );
           }catch(IOException e){
     	    }  	
 	    char ch;
        for(int i=0;i<DatabaseFilePath.length();i++){ 
 	       ch=DatabaseFilePath.charAt(i);
 	       if(ch=='\\'){
 	         DatabaseFilePath.setCharAt(i,'/');//convert path to java style path
 	       }
 	    }
        String DatabaseFilePath1=DatabaseFilePath.toString();
        System.out.println(DatabaseFilePath1);///////////////////////////////
        
        Properties properties =new Properties() ;
        driver =
            properties.getProperty("driver","sun.jdbc.odbc.JdbcOdbcDriver");
        
        String filename = DatabaseFilePath1;
        
       // String filename = "C:/mysql/vijaybookshop.mdb";//remove this statement and get upper statement if database is in class's Directory
        url =
            properties.getProperty("url", "jdbc:odbc:Driver={Microsoft Access Driver (*.mdb)};DBQ="+filename.trim() + ";DriverID=22;READONLY=true}");
            properties.getProperty("user", "");
        password =
            properties.getProperty("password", "");
        delay =
            properties.getProperty("delayread","true").equals("true");
        connect();
    }

    private void connect() {
        try {
            System.out.println("Connecting to the database...");
            Class.forName(driver);
            connection = DriverManager.getConnection(url, user, password);
            statement = connection.createStatement();
            System.out.println("Initializing the database...");
            boolean newdb=initDatabase();
            System.out.println("Creating prepared statements...");
            createStatement();

            

        } catch (Exception e) {
            System.out.println("Error connecting to database");
            e.printStackTrace();
            System.exit(1);
        }
    }

    void disconnect() {
        try {
            System.out.println("Closing the database...");
            connection.commit();
            statement.close();
            addNewBook.close();
            delete.close();
            seeDatabaseAvailableBooks.close();
            connection.close();
            System.exit(0);
        } catch (Exception e) {
            System.out.println("Problem in closing database");
            e.printStackTrace();
            System.exit(1);
        }
    }



   private boolean initDatabase() {
        try {
            String sql = "CREATE TABLE availablebooks(ID int primary key,BookName char(15),Author char(15),Edition int,ISBN char(15),Price int,Copies int,Category char(15))";
            // if the table already exists, this will throw an exception
            statement.executeUpdate(sql);
            // this means the database already exists
            return true;
        } catch (SQLException e) {
            // ignore the error - the table already exists, which is good
            // so we don't need to add demo data later on
            // in productive systems, it would be better to see in the metadata
            // if the table already exists
            return false;
        }
    }
    
    
    private void createStatement() {
        try {
           
             addNewBook=connection.prepareStatement(
            	  "INSERT INTO availablebooks (ID,BookName,Author,Edition,ISBN,Price,Copies,Category)VALUES(?,?,?,?,?,?,?,?)");  
             updateCopies=connection.prepareStatement(        
                "UPDATE availablebooks SET Copies=?  WHERE ID=? ");   
             delete = connection.prepareStatement(
                "DELETE FROM availablebooks WHERE ID = ?");        
             edit=connection.prepareStatement(        
                "UPDATE availablebooks SET BookName=? ,Author=? ,Edition=? ,ISBN=? ,Price=? ,Copies=? ,Category=? WHERE ID=? ");   
             seeDatabaseAvailableBooks=connection.prepareStatement(
            	"SELECT ID, BookName, Author, Edition, ISBN, Price, Copies, Category FROM availablebooks");   
             seeDatabaseBooksSold=connection.prepareStatement(
            	"SELECT SrNo, CustomerID, CustomerName, DateTime, BookID, Title, Author, Price, CopiesSold FROM BooksSold");   
                               
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

 
boolean addNewBook(BookCard BookCard) {
        BookCard.setID(getNewID());
        try {
            addNewBook.setInt(1, BookCard.getID());
            addNewBook.setString(2, BookCard.getBookName());
            addNewBook.setString(3, BookCard.getAuthor());
            addNewBook.setString(4, BookCard.getEdition());
            addNewBook.setString(5, BookCard.getISBN());
            addNewBook.setString(6, BookCard.getPrice());
            addNewBook.setString(7, BookCard.getCopies());
            addNewBook.setString(8, BookCard.getCategory());
            addNewBook.executeUpdate();
            System.out.println("new book added ");
            return true;
        } catch (SQLException e) {
            System.out.println("new book not added ");
            e.printStackTrace();
            return false;
        }
        
    }


    void deleteBookCard(BookCard BookCard) {
        try {
            delete.setInt(1, BookCard.getID());
            delete.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    Vector getAllBookCard() {
        Vector BookCardEntries = new Vector();
        try {
            ResultSet resultSet = seeDatabaseAvailableBooks.executeQuery();
            while (resultSet.next()) {
                BookCard BookCard = new BookCard(resultSet.getInt(1),
                        resultSet.getString(2), resultSet.getString(3),
                        resultSet.getString(4), resultSet.getString(5),
                        resultSet.getString(6),
                        resultSet.getString(7), resultSet.getString(8));
                
                BookCardEntries.addElement(BookCard);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return BookCardEntries;
    }



    private int getNewID() {
        try {

            ResultSet resultSet = statement.executeQuery(
                "SELECT MAX(ID)+1 FROM availablebooks");
            if (resultSet.next()) {
                return resultSet.getInt(1);
            } else {
                return 0;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    void center(Window window) {
        int w=window.getSize().width;
        int h=window.getSize().height;
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        window.setBounds((d.width - w) / 2, (d.height - h) / 2, w, h);
    }


    public  boolean getValidAdministrator(Administrator Admin){
	  System.out.println("getValidAdministrator");
	  try{
	     
	     ResultSet resultset = statement.executeQuery("Select * from users where UserName = '"+Admin.getUserName()+"' and Password='"+Admin.getPassword()+"'");
	     if(resultset.next()) {return true;}
	  } catch(Exception e){
          e.printStackTrace();
        }
      
         return false; 
    }

    
    public  boolean ifIDExists(String ID){
	  System.out.println("ifIDExists");
	  try{
	     
	     ResultSet resultset = statement.executeQuery("SELECT Copies FROM AvailableBooks WHERE ID ="+ID+";");
	     if(resultset.next()) {return true;}
	  } catch(Exception e){
          e.printStackTrace();
        }
      
       return false;
     }    
   
    public  int getCopies(String ID){
	  System.out.println("getCopies");
	  try{
	     
	     ResultSet resultset = statement.executeQuery("SELECT Copies FROM AvailableBooks WHERE ID ="+ID+";");
	     if (resultset.next()) {
                return resultset.getInt(1);
            } else {
                return 0;
            }
	     } catch(Exception e){
              e.printStackTrace();
           }
      
       return 0;     
   }
   
 /*   void updateCopiesBookCard(int Copies1,int ID1) {
        try {
          statement.executeUpdate("UPDATE availablebooks SET Copies='"+Copies1+"'  WHERE ID="+ID1+" "); 
        } catch (SQLException e) {
            e.printStackTrace();
          }
    } */    

    void editBookCard(BookCard BookCard) {
        try {
            if( (stringToInt(BookCard.getPrice())<0)  || (stringToInt(BookCard.getCopies()) <0) ){
              JOptionPane.showConfirmDialog(null, "Wrong entries entered in book ID "+ BookCard.getID()+"!", "Error !", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE);	
            }
            else{ 
             statement.executeUpdate("UPDATE availablebooks SET BookName='"+BookCard.getBookName()+"' ,Author='"+BookCard.getAuthor()+"' ,Edition='"+BookCard.getEdition()+"' ,ISBN='"+BookCard.getISBN()+"' ,Price='"+BookCard.getPrice()+"' ,Copies='"+BookCard.getCopies()+"' ,Category='"+BookCard.getCategory()+"' WHERE ID="+BookCard.getID());  
            }        
        } catch (SQLException e) {
            System.out.println("Book ID"+BookCard.getID()+" not Edited ");
            e.printStackTrace();
          }
    }     

    int getLastCustomerID(){
      int max=0;
      int temp;
      try { 
        ResultSet resultset= statement.executeQuery("SELECT CustomerID FROM BooksSold ");
        while(resultset.next()){
          temp=resultset.getInt(1); 
          if(temp>max){
           max=temp;
          } 
        }
      }catch (SQLException e) {
            e.printStackTrace();
       }
       System.out.println(""+ max);
       return max;
    }
    

    private int getNewSrNo() {
        try {

            ResultSet resultSet = statement.executeQuery(
                "SELECT MAX(SrNo)+1 FROM BooksSold");
            if (resultSet.next()) {
                return resultSet.getInt(1);
            } else {
                return 0;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }  
    
    
    
    boolean setBuyBooksEntry(BooksSoldCard BooksSoldCardTemp){
       
       int NewSrNo;
       int CustomerID=BooksSoldCardTemp.getCustomerID(); 
       String CustomerName=BooksSoldCardTemp.getCustomerName();
       int BookID=BooksSoldCardTemp.getBookID();
       String BookName=BooksSoldCardTemp.getTitle(); 
       String Author=BooksSoldCardTemp.getAuthor(); 
       float Price=BooksSoldCardTemp.getPrice();
       int CopiesSold=BooksSoldCardTemp.getCopiesSold();
       
       int OldCopies=0;
       try {   
          ResultSet resultSet =statement.executeQuery("SELECT Copies FROM availablebooks WHERE ID="+BookID);
          while(resultSet.next()){
          	 OldCopies=resultSet.getInt(1);
          }
          statement.executeUpdate("UPDATE availablebooks SET Copies="+(OldCopies-CopiesSold)+" WHERE ID="+BookID);  
          NewSrNo= getNewSrNo();
          statement.executeUpdate("INSERT INTO BooksSold values("+NewSrNo+","+CustomerID+",'"+ CustomerName+"', now(),"+ BookID+",'"+BookName+"','"+ Author+"',"+ Price+","+ CopiesSold+")");  
         
          return true;
          
       }catch (SQLException e) {
            JOptionPane.showConfirmDialog(null,"       SQL Exception !", "Alert !", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE);
            e.printStackTrace();
            return false; 
       }
    }

   Vector getAllBooksSoldCard() {
        Vector BooksSoldCardEntries = new Vector();
        try {
            ResultSet resultSet = seeDatabaseBooksSold.executeQuery();
            while (resultSet.next()) {
                BooksSoldCard bookssoldcard = new BooksSoldCard(resultSet.getInt(1),
                        resultSet.getInt(2),    resultSet.getString(3),
                        resultSet.getString(4), resultSet.getInt(5),
                        resultSet.getString(6), resultSet.getString(7),
                        resultSet.getFloat(8),    resultSet.getInt(9));
                
                BooksSoldCardEntries.addElement(bookssoldcard);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return BooksSoldCardEntries;
   }
  
  
 private Vector search(SearchCard SearchCard1){
   System.out.println(SearchCard1.getBookName());
   String BookName=SearchCard1.getBookName();
   String Author=SearchCard1.getAuthor();
   String ISBN=SearchCard1.getISBN();
   String ID=SearchCard1.getID();
   String Category=SearchCard1.getCategory();
   boolean BookNameboolean=SearchCard1.getBookNameboolean();
   boolean Authorboolean=SearchCard1.getAuthorboolean();
   boolean ISBNboolean=SearchCard1.getISBNboolean();
   boolean IDboolean=SearchCard1.getIDboolean();
   boolean Categoryboolean=SearchCard1.getCategoryboolean();	    
   	            
   Vector BookCardEntries= new Vector(); 
   boolean temp=false;
   String match=new String("'%%'");
    System.out.println("*************nn"+BookNameboolean);
  
   if(BookNameboolean==true){
       if(temp==false){
          temp=true;
          match=""; 
        }else{ match= match + " AND ";
         }	
      
        match= match + "BookName LIKE '%"+BookName+"%'" ;                      
   } 
   
   
   if(Authorboolean==true){
      if(temp==false){
        temp=true;
        match=""; 
      }else{ match= match + " AND ";
       }	
      match= match + "Author LIKE '%"+Author+"%'" ;                      
   }                       
                       
   if(ISBNboolean==true){
       if(temp==false){
         temp=true;
         match=""; 
       }else{ match= match + " AND ";
        }	
       match= match + "ISBN LIKE '%"+ISBN+"%'" ;                      
   }                       
                       
   if(IDboolean==true){
      if(temp==false){
         temp=true;
         match=""; 
      }else{ match= match + " AND ";
       }	
      match= match + "ID= "+ID+"" ;                      
    }                       
                       
    if(Categoryboolean==true){
       if(temp==false){
          temp=true;
          match=""; 
        }else{ match= match + " AND ";
         }	
        match= match + "Category LIKE '%"+Category+"%'" ;                      
   	}                       
                      
    System.out.println("SELECT * FROM availablebooks WHERE "+match);
    ResultSet resultSet=null;
    try {   
       resultSet=statement.executeQuery("SELECT * FROM availablebooks WHERE "+match);	
       while (resultSet.next()) {
         BookCard BookCard = new BookCard(resultSet.getInt(1),
         resultSet.getString(2), resultSet.getString(3),
         resultSet.getString(4), resultSet.getString(5),
         resultSet.getString(6),resultSet.getString(7),
         resultSet.getString(8));
         BookCardEntries.addElement(BookCard);
       }
   }catch (SQLException e) {
       e.printStackTrace();
    }     
    return BookCardEntries;
 }
  
  
  
 
 
 void changeBookshopName(String NewBookshopName){
    System.out.println("changeBookshopName");
    try {     
      statement.executeUpdate("UPDATE BookshopNameTable SET BookshopName='"+NewBookshopName+"'  WHERE ID=1");
    } catch (SQLException e) {
            e.printStackTrace();
      }
 } 
 
  
  
  String getBookshopName(){
       String OldBookshopName=new String();
       try {   
          ResultSet resultSet =statement.executeQuery("SELECT BookshopName FROM BookshopNameTable WHERE ID=1");
          while(resultSet.next()){
          	OldBookshopName =resultSet.getString(1);
          }
       }catch (SQLException e) {
            e.printStackTrace();
      }
      return OldBookshopName;
    
    }
    
 
 /*int stringToInt(String st){
	    int temp1=1,temp2=0;
		char ww='y'; 
		int con=1;
		int y=0;
		y=st.length();
		for(int i=(y-1);i>=0;i--){
			ww=st.charAt(i);
			//this is for precaution//
			if((ww!='.')&&(ww!='0')&&(ww!='1')&&(ww!='2')&&(ww!='3')&&(ww!='4')&&(ww!='5')&&(ww!='6')&&(ww!='7')&&(ww!='8')&&(ww!='9')){
	     	 System.out.println("Wrong input not a digit"); 
	     	 return -1;
	     	}
			temp1=ww-48;
			temp2=temp2+con*temp1;
			con=con*10;
	    }
	    return(temp2);
 } */
 
   	int stringToInt(String st){

	    Double dg=new Double(0);
	    try{
	     dg=new Double(st);
	    }catch(Exception e){
	       e.printStackTrace();
	     }
	    return(dg.intValue()); 
	} 
	   	
 public void getAdministrativeTaskDialogFromRegister(){
   Register1.getAdministrativeTaskDialog();
 }

 public void getAddDialogFromRegister(){
   Register1.getAddDialog();
 }

 public void getEditBookshopNameDialogFromRegister(){
   Register1.getEditBookshopNameDialog();
 }
 
 public void getBooksSoldDialogFromRegister(){
   Register1.getBooksSoldDialog();
 }

 public void getBuyDialogFromRegister(){
   Register1.getBuyDialog();
 }
 
 public void getSearchDialogFromRegister(SearchCard SearchCard1){
   Vector BookCardEntries= search(SearchCard1);
   Register1.getSearchDialog(BookCardEntries);
 }
 

 

}
