import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.table.*;
import javax.swing.event.*;
import javax.swing.table.TableModel;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*; 
import javax.swing.event.*;   
import java.util.Vector;
/*@author Mr. Sachin Teke sssteke@yahoo.co.uk
 *
 */
class BuyDialog extends JFrame implements TableModelListener{
  
 // BooksSoldCard BooksSoldCardtemp=new BooksSoldCard();
  private boolean DEBUG = true;	//always keep it true, don't change it
  JTable table;
  JTable table2 ;
  JTextField TotalCostTextField = new JTextField();
  Object[][] SelectedItems=new Object[100][9];
  JPanel panel3=new JPanel(new FlowLayout()); 
  JButton BuyButton = new JButton();
  JButton PrintBillButton = new JButton();
  JLabel TotalCostLabel = new JLabel();
  JLabel CustomerNameLabel= new JLabel();
  JTextField CustomerNameTextField=new JTextField();     
  LowerTableModel model2 = new LowerTableModel();
  MyTableModel Mt=new MyTableModel();
  
  BuyDialog(){
   	                    
        try 
   {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
   }
   catch ( ClassNotFoundException e ) 
   {
   }
   catch ( InstantiationException e ) 
   {
   }
   catch ( IllegalAccessException e ) 
   {
   }
   catch ( UnsupportedLookAndFeelException e ) 
   {
   }
   	    table = new JTable(Mt);
   	    model2.addColumn("ID");
        model2.addColumn("Book Name...");
        model2.addColumn("Author....");
        model2.addColumn("Edition");
        model2.addColumn("ISBN...");
        model2.addColumn("Price");
        model2.addColumn("Buy Copies");
        model2.addColumn("Available copies");
        table2=new JTable(model2);
        table2.removeEditor();

        GUI2();
   }
   
   //main Method
   public static void main(String args[]){
        BuyDialog BuyDialog =new BuyDialog();
     
   } 	

   //GUI2 Function
   void GUI2(){
        
        
       
        GridBagConstraints gridConstraints = new GridBagConstraints(); // 
        JScrollPane scrollPane1 = new JScrollPane(table);
        scrollPane1.setPreferredSize(new Dimension(700,80));
        
        table2.getTableHeader().setReorderingAllowed(false);
        table2.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        table2.getModel().addTableModelListener(this);
       
        JScrollPane scrollPane2 = new JScrollPane(table2);
        scrollPane2.setPreferredSize(new Dimension(700,100));

        
       //////////////////////////panel3//////////////////////////////// 

        
        
        JLabel GarbageLabel1=new JLabel();
        GarbageLabel1.setText("................");
        panel3.add(GarbageLabel1);
       	
       	//Button Buy
        BuyButton.setText("Buy");
        panel3.add(BuyButton);
        BuyButton.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e){
      	      BuyButtonActionPerformed(e);
          }
        });	

    	//Button Print Bill
        PrintBillButton.setText("Print Bill");
        panel3.add(PrintBillButton);
        PrintBillButton.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent e){
      	     PrintBillButtonActionPerformed(e);
          }
        });
 
        //Lable Total Cost
        TotalCostLabel.setText("Total Cost");
        panel3.add( TotalCostLabel);
 
        //TotalCost TextField
        TotalCostTextField.setText("0");
        TotalCostTextField.setColumns(8);
        panel3.add( TotalCostTextField);
       
        //Lable CustomerName
        CustomerNameLabel.setText("Customer Name");
        panel3.add( CustomerNameLabel);
 
        //CustomerNameTextField
        CustomerNameTextField.setText("");
        CustomerNameTextField.setColumns(15);
        panel3.add( CustomerNameTextField);
       
        JLabel GarbageLabel2=new JLabel();
        GarbageLabel2.setText("................");
        panel3.add(GarbageLabel2); 
       
       /******************************************************************************************/        
       
        JPanel panel = new JPanel(new GridBagLayout());
        gridConstraints.gridx=0;
		gridConstraints.gridy=0;
        panel.add(scrollPane1, gridConstraints);
        
        gridConstraints.gridx=0;
		gridConstraints.gridy=1;
        panel.add(scrollPane2, gridConstraints);
        panel.setBorder(BorderFactory.createTitledBorder(""));
        
        gridConstraints.gridx=0;
		gridConstraints.gridy=2;
        panel.add(panel3, gridConstraints);
        panel.setBorder(BorderFactory.createTitledBorder(""));
        
        JPanel MainPanel=new JPanel(new GridBagLayout());     
        MainPanel.setBorder(new CompoundBorder(new TitledBorder(null,"Buy Books" ,
						  TitledBorder.CENTER, TitledBorder.TOP),new CompoundBorder() ));
		MainPanel.add(panel);				  
       
        //MainPanel.add(panel3);
        String[] OptionNames = { "Close" };//
        String   OptionTitle = "Buy books wizard";
        
        setTitle("Buy book wizard");
        setSize(800,800);
        table2.getModel().removeTableModelListener(this);
       
        JOptionPane Pane =new JOptionPane();
        Pane.showOptionDialog( null, MainPanel,OptionTitle ,
	    Pane.CANCEL_OPTION, Pane.PLAIN_MESSAGE,
        null,OptionNames,OptionNames[0]) ;
        
        

    }//end of function GUI2()


   public void tableChanged(TableModelEvent e) {   	   	

   }
  

   //////////////////panel3 methods/////////////////////////////
  
   //method of button Buy
   void BuyButtonActionPerformed(ActionEvent e){
   // click of Button
   BooksSoldCard BooksSoldCardTemp;
   int BuyConfirmed;
   int TotalBookCopies=model2.getRowCount() ;
   for(int i=0;i<TotalBookCopies;i++){// checks whether valid no.of copies entered
     if(( ((Integer)model2.getValueAt(i,6)).intValue() < 0) || ( ((Integer)model2.getValueAt(i,6)).intValue() > ((Integer)model2.getValueAt(i,7)).intValue())   ){
       JOptionPane.showConfirmDialog(null,"       Wrong no. of copies entered .", "Alert!", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE); 
       Mt.receiveTableForMytable();
       return;
     }
   }	
   
   System.out.println("BuyButton");
   BuyConfirmed=JOptionPane.showConfirmDialog(null,"             Buy confirmed", "Confirmation", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
   if(BuyConfirmed==0){
      //GUI for customer Name
      int NewCustomerID= Clerk.getInstance().getLastCustomerID() + 1;
      String CustomerName= "XXXX";
      int BookID=0;
      String BookName=new String();
      String Author=new String();
      float Price;
      int CopiesSold;
      boolean success=false;
      System.out.println(""+NewCustomerID);
      System.out.println("TotalBookCopies="+TotalBookCopies);
      for(int i=0;i<TotalBookCopies;i++){
         BookID=((Integer)model2.getValueAt(i,0)).intValue();
         BookName=(String)model2.getValueAt(i,1);
         CustomerName=CustomerNameTextField.getText();
         Author= (String)model2.getValueAt(i,2);
         Price= ((Float)model2.getValueAt(i,5)).floatValue();
         CopiesSold=((Integer)model2.getValueAt(i,6)).intValue(); 
         BooksSoldCardTemp=new BooksSoldCard(0,NewCustomerID, CustomerName,"null" ,BookID, BookName, Author, Price, CopiesSold);
         success=Clerk.getInstance().setBuyBooksEntry(BooksSoldCardTemp);
         //success=Clerk.getInstance().setBuyBooksEntry( NewCustomerID, CustomerName, BookID, BookName, Author, Price, CopiesSold);
      }
     if(success){
        int printb=JOptionPane.showConfirmDialog(null,"              Print Bill", "Confirmation", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if(printb ==0){
         JOptionPane.showConfirmDialog(null,"This Facility is under construction", "Alert !", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE);
        }
     }   
     Mt.receiveTableForMytable();
     CustomerNameTextField.setText("");
    } 	
  }
 
  //method of Button Print Bill
  void PrintBillButtonActionPerformed(ActionEvent e){
	// click of Button
    System.out.println("PrintBillButton");
    JOptionPane.showConfirmDialog(null,"This Facility is under construction.", "Important notice", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE);
  }

 class MyTableModel extends AbstractTableModel {
    public MyTableModel instance;   
     private String[] columnNames = {"ID",
                                        "Book Name",
                                        "Author",
                                        "Edition",
	                                    "ISBN",
                                        "Price",
                                        "Copies",
                                        "Select",
                                        "Buy Copies"
                                       };  
                                        
                                        
     Object[][] data=new Object[getDatabaseSize()][9];                                  
     Object value1;
        
     MyTableModel(){
      	receiveTableForMytable();
     } 

     public int getColumnCount() {
        return columnNames.length;
     }

     public int getRowCount() {
        return data.length;
     }

     public String getColumnName(int col) {
         return columnNames[col];
     }

     public Object getValueAt(int row, int col) {
         return data[row][col];
     }

     public Class getColumnClass(int c) {
         return getValueAt(0, c).getClass();
     }

     MyTableModel getInstance() {
        if (instance == null) {
            instance = new MyTableModel();
        }
        return instance;
    }   /*
         * Don't need to implement this method unless your table's
         * editable.
         */
        public boolean isCellEditable(int row, int col) {
            //Note that the data/cell address is constant,
            //no matter where the cell appears onscreen.
            if (col < 7) {
                return false;
            } else {
                return true;
            }
            
        }

        /*
         * Don't need to implement this method unless your table's
         * data can change.
         */
        public void setValueAt(Object value, int row, int col) {
            if (DEBUG) {
             /* System.out.println("Setting value at " + row + "," + col
                                   + " to " + value
                                   + " (an instance of "
                                  + value.getClass() + ")");
             */                     
            }

            data[row][col] = value;
            fireTableCellUpdated(row, col);

            if (DEBUG) {
              //  System.out.println("New value of data:");
                printDebugData();
            }
        }

        private void printDebugData() {
            String temp;
            int selectedcount=0; 
            float totalcost=0;
            int cl;
            int numRows = getRowCount();
            int numCols = getColumnCount();
            model2.setRowCount(0);///////////////**********************/
            //System.out.println("    columns= " + numCols + ":"); 
            for (int i=0; i < numRows; i++) {
                //System.out.print("    row " + i + ":");
                for (int j=0; j < numCols; j++) {
                   // System.out.print("  " + data[i][j]);
                    if(j==7){//i.e tick option is at column index 7
                      temp=""+data[i][j];
                      if(temp.equals("true")){
                      	//System.out.println("*******"+i);
                        for(cl=0;cl<9 ;cl++){  
                          SelectedItems[selectedcount][cl]=data[i][cl];
                        } 
                        //if available copies are Zero then do not add that row
                        if( (((Integer)data[i][6]).intValue())!=0 ){
                             model2.addRow(new Object[]{
                             	                        data[i][0],
                                                        data[i][1],
                                                        data[i][2],
                                                        data[i][3],
                                                        data[i][4],
                                                        data[i][5],
                                                        data[i][8],
                                                        data[i][6]
                                                    });
                         
                        // System.out.print( SelectedItems[i][6]); 
                         totalcost= totalcost + ((Integer)data[i][8]).intValue()*((Float)data[i][5]).floatValue();
                         selectedcount++; 
                       }
                      }
                      temp="false";
                    }
                }
                // System.out.println(""+totalcost);
                String totalcoststring=""+totalcost;
                TotalCostTextField.setText(totalcoststring);
            }
            for(int k=0;k<selectedcount;k++){
                for(int m=0;m<9;m++){
               // System.out.print("  "+SelectedItems[k][m]);
                }
             // System.out.println("");
            }
            //System.out.println("--------------------------");
            
        }
        
    
    public void receiveTableForMytable(){
       int tempid;        
       Vector BookCardEntries=Clerk.getInstance().getAllBookCard();
       BookCard  BookCardtemp=new  BookCard();        
       for(int i=0;i<BookCardEntries.size();i++){
         BookCardtemp=(BookCard)BookCardEntries.elementAt(i);
         tempid=BookCardtemp.getID();
                      value1=new Integer(tempid);
           	          setValueAt(value1,i,0);
           	          value1= BookCardtemp.getBookName();
           	          setValueAt(value1,i,1);
           	          value1= BookCardtemp.getAuthor();
           	          setValueAt(value1,i,2);
           	          value1= BookCardtemp.getEdition();
           	          setValueAt(value1,i,3);
           	          value1= BookCardtemp.getISBN();
           	          setValueAt(value1,i,4);
           	          value1= new Float(stringToFloat(BookCardtemp.getPrice() ) );
           	          setValueAt(value1,i,5);
           	          value1= new Integer (stringToInt(BookCardtemp.getCopies()) );//BookCardtemp.getCopies();
           	          setValueAt(value1,i,6);
           	          value1= new Boolean(false); 
           	          setValueAt(value1,i,7);
           	          value1= new Integer(1);
           	          setValueAt(value1,i,8);               //BookCardtemp.getCategory()
      }           
    }
    
    int getDatabaseSize(){
       Vector BookCardEntries=Clerk.getInstance().getAllBookCard();
       return BookCardEntries.size();
    }
    
   	
   	int stringToInt(String st){

	    Double dg=new Double(0);
	    try{
	     dg=new Double(st);
	    }catch(Exception e){
	       e.printStackTrace();
	     }
        
	   return(dg.intValue()); 
	   
	} 
   
   	float stringToFloat(String st){

	    Double dg=new Double(0);
	    try{
	     dg=new Double(st);
	    }catch(Exception e){
	       e.printStackTrace();
	     }
        
	   return(dg.floatValue()); 
	   
	}    
   
   
   } //end of class MyTableModel 
   



 }//end of class   
    
    
 //Class LowertableModel
 
     class LowerTableModel extends DefaultTableModel{
    
       public boolean isCellEditable(int rowIndex, int columnIndex) {
     	return false;
       }


    }
    
    
    
 
    
    
    