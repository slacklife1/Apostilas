
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.event.*;
import javax.swing.border.*; 
import java.sql.*;
import java.util.Vector;
/*@author Mr. Sachin Teke sssteke@yahoo.co.uk
 *
 */
class BooksSoldDialog extends JFrame{
    
    Disable3TableModel model = new Disable3TableModel();
    BooksSoldDialog(){
   	                    
        try 
   {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
   }
   catch ( ClassNotFoundException e ) 
   {
   }
   catch ( InstantiationException e ) 
   {
   }
   catch ( IllegalAccessException e ) 
   {
   }
   catch ( UnsupportedLookAndFeelException e ) 
   {
   }
   	    model.addColumn("Sr.No.");
   	    model.addColumn("Customer ID");
   	    model.addColumn("Customer Name");
        model.addColumn("Date/Time");
        model.addColumn("Book ID");
        model.addColumn("Title");
        model.addColumn("Author");
        model.addColumn("Price");
        model.addColumn("Copies Sold");
        showTable();
      }
       
   void showTable(){      
       int i; 
       BooksSoldCard BooksSoldCardtemp=new BooksSoldCard();
       model.setRowCount(0);
       String tempid=new String();        
       Vector BooksSoldCardEntries=Clerk.getInstance().getAllBooksSoldCard();
       BooksSoldCardtemp=new  BooksSoldCard();        
       for(i=0;i<BooksSoldCardEntries.size();i++){
        BooksSoldCardtemp=(BooksSoldCard)BooksSoldCardEntries.elementAt(i);
 
        String tempSrNo = ""+ BooksSoldCardtemp.getSrNo();
        String tempCustomerID= ""+ BooksSoldCardtemp.getCustomerID();
        String tempBookID= ""+BooksSoldCardtemp.getBookID();
        String tempPrice= ""+BooksSoldCardtemp.getPrice(); 
        String tempCopiesSold= ""+BooksSoldCardtemp.getCopiesSold();
        model.addRow(new String[]{ tempSrNo,
           	                    tempCustomerID,
           	                    BooksSoldCardtemp.getCustomerName(),
           	                    BooksSoldCardtemp.getDateTime(),
           	                    tempBookID,
           	                    BooksSoldCardtemp.getTitle(),
           	                    BooksSoldCardtemp.getAuthor(),
           	                    tempPrice,
                                tempCopiesSold
                     });              
      }	
     GUI();
  }      
       
           
    //GUI Function
  void GUI(){
        JFrame frame1=new JFrame();
        frame1.setDefaultLookAndFeelDecorated(true);
        String temp="ggggg";
        
        JTable table = new JTable(model);
        table.getTableHeader().setReorderingAllowed(false);
        table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(400,100));

        JPanel panel1 = new JPanel(new BorderLayout());
        panel1.add(scrollPane, BorderLayout.CENTER);
        panel1.setBorder(BorderFactory.createTitledBorder(""));
        
        JPanel panel2 = new JPanel(new BorderLayout());
        JLabel dotsLabel=new JLabel();
        dotsLabel.setText("............................................................................................................................................................................................................................");
        panel2.add(dotsLabel);
        
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(panel2,BorderLayout.NORTH);
        panel.add(panel1,BorderLayout.CENTER);
        
        
        getContentPane().add(panel);
        JPanel MainPanel=new JPanel();     
        MainPanel.setBorder(new CompoundBorder(new TitledBorder(null,"Books sold" ,
							  TitledBorder.CENTER, TitledBorder.TOP),new CompoundBorder() ));
        MainPanel.add(getContentPane());
             String[] OptionNames = { "Cancel" };/**********************/
             String   OptionTitle = "Report of books sold";/*****************/

        
        JOptionPane.showOptionDialog(null, MainPanel,OptionTitle ,
	               JOptionPane.CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE,
                   null,OptionNames,OptionNames[0]);//.setPreferredSize(new Dimension(300,300)) ;
    }
    
    
 //Action performer
 
 public static void main(String args[]){
   BooksSoldDialog booksolddialog=new BooksSoldDialog(); 	
 }   

}//End of class


  class Disable3TableModel extends DefaultTableModel {
     public boolean isCellEditable(int rowIndex, int columnIndex) {
  	   return false;
     }
 }    