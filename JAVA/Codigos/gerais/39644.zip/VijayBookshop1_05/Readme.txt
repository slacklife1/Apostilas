{\rtf1\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil\fprq2\fcharset134 SimSun;}{\f1\fmodern\fprq1\fcharset0 Courier New;}{\f2\fswiss\fcharset0 Arial;}}
\viewkind4\uc1\pard\f0\fs20\par
\f1                                         Be free  \par
\par
===========================================================================================\par
                                       Vijay Bookshop          Author: Mr. Sachin Teke\par
                                                                       sssteke@yahoo.co.uk      \par
===========================================================================================\par
User manual\par
\par
You are welcome for using free software " Vijay Bookshop".\par
\par
Introduction :\par
\par
Vijay Bookshop is a bookshop automation system developed in java1.4 and \par
uses Microsoft Access database as backend.\par
It provides facilities which are commonly required for bookshop in a simple way\par
but through extraordinary mechanism such as,\par
1. keeping record of books available in bookshop\par
2. keeping record of books sold along with date and time\par
3. it provides administrator account to limit access of  database by unknown  person.\par
4. it provides facility of searching books according to Book title, author, ISBN, category. \par
5. it also provides facility of changing "Bookshop Name".\par
6. it is provided with calendar and clock at front panel.  \par
\par
System requirements:\par
JRE1.4 or higher, Windows operating system(98 or above),Microsoft Access( installed )\par
\par
Installation & running:\f0\par
\f1 1. Unzipped folder VijayBookshop\par
2. Doubleclick file BOOKSHOP.bat\par
Note:  \par
  For Administrator account\par
  UserName :  a\par
  Password :  a \par
\par
Final words :\par
If you have question about software, would like to make comment or have found a bug please\par
send me an email at ssteke@yahoo.com\par
\f0\par
\f2\par
}
 