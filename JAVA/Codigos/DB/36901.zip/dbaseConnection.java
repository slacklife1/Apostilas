/***************************************************************************************
####################### Read First Installation Instructions ########################### 
* SIMPLIFIED VERSION OF MY PROGRAM dbaseConnection.java //							   *
* (part 1) Poweful code for JDBC Application										   *
* Code By : Rakesh Halder															   *
* My Email : rakesh_halder@india.com												   *
* Updated Date : Oct26, 2004 														   *
* Version: 1.00 																	   *
* ================== ODBC Settings ==================================================  *
* step 1  : click control panel														   *
* step 2  : ODBC Data Sources														   *
* step 3  : click UserDSN Tab														   *
* step 4  : click ADD Button , Select Any Database Driver , Finish 					   *
* step 5  : Give Datasource Name 													   *
* click ok , ok finish																   *
* ================== Compile ========================================================  *
* step 7  : javac dbaseConnection.java												   *
* ================= Run ============================================================   *
* step 8  : java dbaseConnection													   *
* 																					   *
* Semicolon is not necessary after end of the query                     			   *
* contact me with greetings, comments, (sensible) questions: rakesh_halder@india.com   *
############################## End Installation Instructions ##########################*
***************************************************************************************/
import java.io.*;
import java.sql.*;
/*********************************************Start Main Class*************************/
class dbaseConnection
{
	
/*******************************************Start Main Function************************/	
 public static void main(String arg[]) throws IOException
 {
//=========================================== Start Variables ==========================
////////////////////////////////////////////////////////////////////////////////////////
	
 	Connection con;
 	ResultSet rs;
 	Statement st;
 	String name ;
 	String pwd;
 	String query;
 	String dsn;
//============================================ End Variables=========================== 
 	System.out.println("###########################################################");
 	System.out.println("*****************Code by: RAKESH HALDER********************");
 	System.out.println("Contact me with greetings, comments rakesh_halder@india.com");
 	System.out.println("###########################################################");
 	System.out.println();
 	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
 	System.out.print("Enter the DSN name: ");
 	dsn=br.readLine();
 	//connection to database
 	String url="jdbc:odbc:"+dsn; 	
 	System.out.println(url);
 	
 	System.out.print("Enter the User name: ");
 	name=br.readLine();
 	System.out.print("Enter the password : ");
 	pwd=br.readLine();
 	
 	try {
//==========================Connection Part to Database===================================	
 	Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");//loading of driver
 	System.out.println("Opening db connection");
 	
 	con=DriverManager.getConnection(url,name,pwd);//connecting to the database
 	st=con.createStatement();
 	System.out.println("Success (You can write your query now)");
    System.out.println();
//=====================End Of Connection Part to Database=================================	    

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Start of Execution of Query~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    do{
 	System.out.print("SQL> ");
 	query=br.readLine();
 	 	
 	if(query.equals("exit")){System.exit(0);}
 	/*Will Execute Data manipulation language */ 
 	else if(query.toUpperCase().indexOf("SELECT")==0)
 	   {
 		rs=st.executeQuery(query);
 		int coln=rs.getMetaData().getColumnCount();
 	
 		/* Will show the column name of the database */
 		for(int i=0;i<coln;i++)
 			{
 			System.out.print(rs.getMetaData().getColumnName(i+1)+" ");	
 			}
 		System.out.println();	
 		/*Will show the row of the database */
 		while(rs.next())
 		{ String rowData[]=new String[coln];
 	  
 			for(int i=0;i<coln;i++)
 			{
 		 	System.out.print(rs.getString(i+1)+"   ");	
 			}//end for
 			System.out.println();	
 		} //end while
 	   }//end if for select query execution
 	   else 
 	   {
 	   	st.execute(query);
 	   	/*for message showing*/	
 	   if( (query.toUpperCase().indexOf("CREATE")==0) || (query.toUpperCase().indexOf("DROP")==0))	
 		System.out.println("The command(s) completed successfully.");
 	   else if( (query.toUpperCase().indexOf("INSERT")==0) || (query.toUpperCase().indexOf("UPDATE")==0)||(query.toUpperCase().indexOf("DELETE")==0))	
 	    System.out.println("(1 row(s) affected)");
 	   	}
    
 		
 		}while(query!="exit");	

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~End of Execution of Query~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 		
 	}//ene try
 	catch(ClassNotFoundException e){  
 	  System.out.println("Class not found : "+e);	
 			}
 	catch(SQLException ex){
 	  System.out.println("Sql error: "+ex); 	 		
 		}	
 	 	 			
 	}	//end main
	
	}//end class