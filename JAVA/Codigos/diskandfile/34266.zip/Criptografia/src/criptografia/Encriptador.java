package criptografia;
import java.util.*;
import java.math.*;
import java.text.*;

public class Encriptador {

    private String texto;
    private Chave chave;

    Encriptador(String texto, Chave chave) {
        this.texto = texto;
        this.chave = chave;
    }

    public String encriptar() {
//        Character car = new Character(' ');

        // transforma todo o texto para inteiro
/*        int[] textoInt = new int[this.texto.length()];
        for(int j = 0; j < this.texto.length(); j++) {
            if (this.texto.charAt(j) == '\n') {
                textoInt[j] = 37;
            } else {
                textoInt[j] = car.digit(this.texto.charAt(j), 36);
            }
        }

        "deprecated"

*/

        int[] textoInt = new int[this.texto.length()];
        for(int j = 0; j < this.texto.length(); j++) {
            textoInt[j] = ((int) this.texto.charAt(j));
        }

        String encriptada = "";
        char charEncriptado;
        int variavel = 0;
        int tamanhoChave = chave.getTamanho();
        int[] key = this.chave.getChaveInt();
//        int digitoEncrip = 0;

        for (int i = 0; i < this.texto.length(); i++) {
            if (variavel > tamanhoChave - 1) variavel = 0;
            //teste
            System.out.print(variavel+" "+tamanhoChave+" " +(int)key[variavel] + " " +textoInt[i]);

            charEncriptado = (char)((key[variavel] + textoInt[i]) % 256);
            //teste
            System.out.println(" " + (int) charEncriptado);
            encriptada = encriptada + charEncriptado;
            variavel = variavel + 1;
        }
        return encriptada;

    }

}