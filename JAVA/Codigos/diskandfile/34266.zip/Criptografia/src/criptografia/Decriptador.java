package criptografia;

public class Decriptador {

    private String texto;
    private Chave chave;

    Decriptador(String texto, Chave chave) {
        this.texto = texto;
        this.chave = chave;
    }


    public String decriptar() {
 //       Character car = new Character(' ');

        // transforma todo o texto ENCRIPTADO para inteiro
        int[] textoInt = new int[this.texto.length()];
        for(int j = 0; j < this.texto.length(); j++) {
               textoInt[j] = (int)(this.texto.charAt(j));
        }

        String decriptada = "";
        char charDecrip;
        int variavel = 0;
        int tamanhoChave = chave.getTamanho();
        int[] key = this.chave.getChaveInt();
//        int digitoDecrip = 0;

        for (int i = 0; i < this.texto.length(); i++) {
            if (variavel > tamanhoChave - 1) variavel = 0;
            //teste
            System.out.print(" " +variavel+" " + tamanhoChave + " " + key[variavel] + " " + textoInt[i]);
            charDecrip = (char)((textoInt[i] + 256 - key[variavel]) %256);

            //teste
            System.out.println(" " + ((int)charDecrip));
            decriptada = decriptada + charDecrip;
            variavel = variavel + 1;
        }
        return decriptada;

    }

}