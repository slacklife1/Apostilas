package criptografia;
import java.io.*;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.math.*;
import java.text.*;

public class Criptografia {

  public static void main(String[] args) {
      Console c = new Console();
      int respostaa = 0;
      while (respostaa!=3) {
        System.out.println("\t####  Welcome to Cipher and Text extractor  #### \n\t\t (eccsport@hotmail.com)");
        System.out.println ("\n1 - Cypher ");
        System.out.println ("2 - Extract the text from a file ");
        System.out.println ("3 - Exit");
        System.out.print("Input: ");
        respostaa = c.readInt();
        switch(respostaa) {
          case 1:
            System.out.print("Input the key(ignoreCase): ");
            String chaveDig = c.readString();
            Chave chave = new Chave(chaveDig);
            int resposta = 0;

            while (resposta!=4) {
              System.out.println ("\n1 - Encript a file or String ");
              System.out.println ("2 - Decript a file ");
              System.out.println ("3 - Change the key ");
              System.out.println ("4 - Back ");
              System.out.print("Input: ");
              resposta = c.readInt();
              switch(resposta) {
                case 1:
                  int resposta2 = 0;
                  while (resposta2!=3) {
                    System.out.println ("1 - Encript a String ");
                    System.out.println ("2 - Encript a File ");
                    System.out.println ("3 - Back ");
                    System.out.print("Input: ");
                    resposta2 = c.readInt();
                    switch(resposta2) {
                      case 1:
                        System.out.print  ("Input the text to encript: ");
                        String texto2 = c.readString();
                        encriptar (texto2,chave);
                      break;

                      case 2:
                        System.out.print  ("Type the name of the file: ");
                        String arq = c.readString();
                        String textoDoArquivo = "";
                        try {
                            textoDoArquivo = ler(arq);
                            encriptar (textoDoArquivo, chave);
                        } catch(IOException ioe) {
                            System.out.println("FILE ERROR");
                        }
                        break;
                    }
                  }
                  break;
                case 2:
                  System.out.print ("Input the file of decription: ");
                  String arquivo1 = c.readString();
                  String texto = "";
                  try {
                      texto = ler(arquivo1);
                      Decriptador decrip = new Decriptador(texto, chave);
                      String decriptada = decrip.decriptar();
                      System.out.println(" = " + decriptada);
                      System.out.print ("Save the decripted file(y/n)? ");
                      char resposta3 = c.readChar();
                      if(resposta3 == 'y') {
                          try {
                              salvar("saida.txt",decriptada);
                              System.out.println("The file was saved 'saida.txt'");
                          } catch (IOException ioe) {
                              System.out.println("FILE ERROR");
                          }
                      }
                  } catch (IOException ioe) {
                      System.out.println("FILE ERROR");
                  }
                  break;
                case 3:
                  System.out.print("Input the key: ");
                  chave.setChave(c.readString());
                  System.out.println("Key changed");
                  break;
                }
            }
          break;
          case 2:                                           //extracao de texto
            System.out.print("Input the name of the file: ");
            String arquivoAserExtraido = c.readString();
            try {
                String texto11 = lerTexto(arquivoAserExtraido);
//                System.out.println("lertexto");
                salvar("saidaTexto.txt", texto11);
                System.out.println("the file was saved saidaTexto.txt ");
            } catch (IOException ioe) {
                System.out.println("FILE ERROR");
            }
            break;
        }
      }

  }

  public static void salvar(String arquivo, String texto) throws FileNotFoundException, IOException  {
      FileOutputStream  out = new FileOutputStream (arquivo);
      DataOutputStream bufferedOut = new DataOutputStream(out);

      for(int i = 0; i < texto.length(); i++) {
          bufferedOut.writeByte((byte)texto.charAt(i));
      }

      bufferedOut.close();
  }

  public static String ler(String arquivo) throws FileNotFoundException, IOException  {
      String retorno = "";
      File f = new File(arquivo);
      long a = f.length();
      FileInputStream in = new FileInputStream(arquivo);
      DataInputStream bufferedIn = new DataInputStream(in);
      while(a != (long)retorno.length()) {
          retorno = retorno + (char)bufferedIn.readByte();
      }
      bufferedIn.close();
      return retorno;
  }

  public static String lerTexto(String arquivo) throws FileNotFoundException, IOException  {
      String retorno = "";
      File f1 = new File(arquivo);
      long tamanhoArquivo = f1.length();
      Character a = new Character(' ');
      FileInputStream in1 = new FileInputStream(arquivo);
      DataInputStream bufferedIn1 = new DataInputStream(in1);

      char caracter;
      long variavel = 0;

      while(tamanhoArquivo > variavel) {
          caracter = (char)bufferedIn1.readByte();
          if (a.isLetterOrDigit(caracter) || caracter == ' ' || (int)caracter==13) {
            retorno = retorno + caracter;
            if((int)caracter==13) retorno += ((char)10);
          }
          variavel++;
      }

      bufferedIn1.close();
      return retorno;
  }


  //metodo auxiliar
  public static void encriptar(String textoASerEncrip, Chave chave) {
      Console c = new Console();
      Encriptador encriptador = new Encriptador (textoASerEncrip, chave);
      String textoEncrip  = encriptador.encriptar();
      System.out.println ("\n = " + textoEncrip);
      System.out.print ("Enter the output file: ");
      String arquivo = c.readString();
      try {
          salvar(arquivo,textoEncrip);
      } catch (IOException ioe) {
      }
  }

}
