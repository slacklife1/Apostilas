                               Cipher 1.2

- Contact information
   Eduardo Carrazzone Cavalcanti
   Email: eccsport@hotmail.com
          eduardo_carrazzone@yahoo.com.br  
   Home Page: Http://www.cin.ufpe.br/~ecc

- Title or the file/product
   Cipher 1.1

- Main File
   Criptografia.java

- Command Line
   javac src\*.java
   java src\Criptografia

- A description of the file or product
   Cipher and Text Extractor 1.1 This program made in Java to encript and decript files using a Key. The program also extract text from files. It's very simple and usefull. 