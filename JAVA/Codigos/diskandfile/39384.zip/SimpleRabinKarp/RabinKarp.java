/*
	Written On: 28/03/2005, Monday

	Written By: Sunil Dhummi (sdhummi@tataelxsi.co.in)

	Description:
		The program uses Rabin Karp algorithm to find a text Pattern in a text file.
		It returns the no. of such text patterns found in the String.

		APOLOGIES for the inadequate commenting. 
		Will rectify this soon and upload a newer version of Rabin Karp program.
*/

import java.io.*;

public class RabinKarp
{
	private StringBuffer textToMatch = null;
	private StringBuffer textBeingRead = null;
	private FileReader in = null;

	private String fileName = null;

	private int textMatchCount = 0;
	private int hashValueOfTextToMatch = -1;
	private int hashValueOfTextBeingRead = -1;

	private static final int HASH_CAPACITY = 101;

	/*
		Invoke this method. Pass the File Name and Text Pattern to be searched in the file.
	*/
	public String RabinKarpMain(String tmpFileName, String tmpTextToMatch)
	{
		fileName = tmpFileName;
		textToMatch = new StringBuffer(tmpTextToMatch);

		validateInput();

		hashValueOfTextToMatch = developHashValue(textToMatch);

		if(hashValueOfTextToMatch == -1)
		{
			error("Unable to develop Hash Value!", -2);
		}

		openFile();
	
		int ch;
		while((ch = traverseFile()) != -1)
		{
			if(textBeingRead == null)
			{
				textBeingRead = new StringBuffer("");
			}

			if(textBeingRead.length() < textToMatch.length())
			{
				textBeingRead.append((char)ch);

				if(textBeingRead.length() != textToMatch.length())
				{
					continue;
				}
			}

			if(hashValueOfTextBeingRead == -1)
			{
				hashValueOfTextBeingRead =	developHashValue(textBeingRead);
			}
			else
			{
				hashValueOfTextBeingRead -= (int)textBeingRead.charAt(0);
				hashValueOfTextBeingRead += ch;

				hashValueOfTextBeingRead = hashValueOfTextBeingRead % HASH_CAPACITY;

				textBeingRead.deleteCharAt(0);
				textBeingRead.append((char)ch);
			}

			if(hashValueOfTextBeingRead == hashValueOfTextToMatch)
			{
				if(compare(textToMatch, textBeingRead) == 0)
				{
					textMatchCount++;
				}
			}
		}

		closeFile();

		return "Number of " + textToMatch + " encountered were: " + textMatchCount;
	}

	private int compare(StringBuffer one, StringBuffer two)
	{
		if(one.length() == two.length())
		{
			for(int i = 0; i < one.length(); i++)
			{
				if(one.charAt(i) != two.charAt(i))
				{
					return -1;
				}
			}

			return 0;
		}
		else
		{
			return -1;
		}
	}

	private int validateInput()
	{
		return 1;
	}

	private int developHashValue(StringBuffer textPattern)
	{
		int sum = 0;

		for(int i = 0; i < textPattern.length(); i++)
		{
			sum += (int) textPattern.charAt(i);
		}	

		return sum % HASH_CAPACITY;
	}

	private int openFile()
	{
		try
		{
			in = new FileReader(fileName);

			return 1;
		}
		catch(Exception e)
		{
			return -1;
		}
	}

	private int closeFile()
	{
		try
		{
			in.close();
			return 1;
		}
		catch(Exception e)
		{
			return -1;
		}
	}
	
	/*
		Responsible for traversing a file - character by character
	*/
	private int traverseFile()
	{
		try
		{
			return in.read();
		}
		catch(IOException e)
		{
			return -1;
		}
	}

	private void error(String errorMessage, int errorValue)
	{
		System.out.println(errorMessage + " : " + errorValue);

		//exit(errorValue);
	}

	public static void main(String[] args) 
	{
		RabinKarp rk = new RabinKarp();
		System.out.println(rk.RabinKarpMain(args[0],args[1]));
	}
}
