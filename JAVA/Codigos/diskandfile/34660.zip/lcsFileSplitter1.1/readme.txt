LCS File Splitter history

LCS File Splitter 1.0
- allows user to split file into many files which can be store in many diskettes
- merge files by double click the batch files inside the folder created during split time. (filename.bat)

LCS File Splitter 1.1
- allows user to split file into several devices (floppy, 32mb flash drive, 64mb flash drive, 128mb flash drive)
- busy cursor added while waiting for the "split time" and "file chosser window"