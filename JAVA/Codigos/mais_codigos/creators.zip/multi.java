/*By: Chad Marson
Date Started: May 15
Latest Revised: June 16, 2002
Purpose: To play out Creaton's Quest multiplayer game
*/
import java.io.*;
public class multi{
	
	public static int multi () throws Exception{
		int[] player=new int[2];//array to store player 1 and 2's damage
		int[] playerheal=new int[2];//array to store play 1 and 2's heal
		int i=0;//counter
		String name="";
		String name2="";//stores player 2'sa name
		String nametemp="";//stores player 1's name + txt
		String name2temp="";//stores player 2's name + txt
		String txt=".txt";
		boolean error=true;
		int S=0;
		int M=0;
		int dmg=0;
		int Heal=0;
		int x=0;
		double heal=0;
		double ran=0;
		double a=0;
		int lvl=0;
		int str=0;
		int def=0;
		int mag=0;
		int lvl_2=0;//stores player 2's level
		int str_2=0;//sores player 2's strength
		int def_2=0;//store player 2's defence
		int mag_2=0;//stores player 2's magic
		System.out.println("Welcome to Creaton's Quest Multiplayer");
		System.out.println("--------------------------------------");
		
		while(error){
			x=0;
			System.out.print("Please enter player 1's character name: ");
			name=key.readString(name);
			System.out.print("Please enter player 2's character name: ");
			name2=key.readString(name2);
		
			nametemp=name+txt;
			name2temp=name2+txt;
			try{
				FileReader File1=new FileReader(nametemp);
				BufferedReader reader=new BufferedReader(File1);
			}
			catch(IOException FileNotFoundException){
				System.out.println(name+" is not a valid character name");
				x=1;
			}
			
			try{
				FileReader File2=new FileReader(name2temp);
				BufferedReader reader2=new BufferedReader(File2);
			}
			catch(IOException FileNotFoundException){
				System.out.println(name2+" is not a valid character name");
				x=1;
			}
			if(x==0){
				error=false;
			}
		}
		FileReader File1=new FileReader(nametemp);
		BufferedReader reader=new BufferedReader(File1);
		lvl=Integer.parseInt(reader.readLine());
		str=Integer.parseInt(reader.readLine());
		def=Integer.parseInt(reader.readLine());
		mag=Integer.parseInt(reader.readLine());
	
		FileReader File2=new FileReader(name2temp);
		BufferedReader reader2=new BufferedReader(File2);
		lvl_2=Integer.parseInt(reader2.readLine());
		str_2=Integer.parseInt(reader2.readLine());
		def_2=Integer.parseInt(reader2.readLine());
		mag_2=Integer.parseInt(reader2.readLine());
		
		error=true;
		while((def>=0)&&(def_2>=0)){//loop to run combat while both players are alive
			i=0;
			while(i<2){
				if(i==0){
					System.out.println("");
					System.out.println("Player "+name+" choose your attack");
				}
				if(i==1){
					System.out.println("");
					System.out.println("Player "+name2+" choose your attack");
				}
				while(error){
					dmg=0;
					Heal=0;
					x=0;
					System.out.println("");
					System.out.println("");
					System.out.println("1.) Melee Attack");
					System.out.println("2.) Magic Attack");
					System.out.print("Which type of attack do you wish to use? ");
					try{
						x=key.readInt(x);
					}
					catch(NumberFormatException e){
					}
					if((x<=2)&&(x>0)){
						error=false;
					}
				}
				error=true;
				if(x==1){
					while(error){
						S=0;
						M=0;
						System.out.println("");
						System.out.println("");
						System.out.println("1.) Punch");
						System.out.println("2.) Slash");
						System.out.println("3.) Kick");
						System.out.println("4.) Range Attack");
						System.out.println("5.) Double Attack");
						System.out.println("6.) Eagle Strike");
						System.out.println("7.) Critical Hit");
						System.out.println("8.) Triple Attack");
						System.out.println("9.) Flying Kick");
						System.out.println("10.) Berserk of Rage");
						System.out.print("Which Attack Do you wish to use? ");
						try{
							M=key.readInt(M);
						}
						catch(NumberFormatException e){
						}
						if((M<=10)&&(M>0)){
							error=false;
						}
					}
				}
				error=true;
				if(x==2){
					while(error){
						M=0;
						S=0;
						System.out.println("");
						System.out.println("");
						System.out.println("1.) Minor Heal");
						System.out.println("2.) Flame Bolt");
						System.out.println("3.) Wind Strike");
						System.out.println("4.) Poison Arrow");
						System.out.println("5.) Heal");
						System.out.println("6.) Serpent Strike");
						System.out.println("7.) Meteor Shower");
						System.out.println("8.) Holy Healing");
						System.out.println("9.) Holy Light");
						System.out.println("10.) Devastate");
						try{
							S=key.readInt(S);
						}
						catch(NumberFormatException e){
						}
						if ((S<=10)&&(S>0)){
							error=false;
						}
					}
				}
				error=true;
				dmg=0;
				Heal=0;
				ran=0;
				heal=0;
				if(M==1){
					a=Math.random()*lvl+1;
					if(a>=1.1){
						ran=(Math.random()*(lvl))*(Math.random()*(str));
					}
					dmg=(int)ran;
					if(dmg>1000){
						dmg=1000;
					}
				}
				if((M==2)&&(!(lvl<5))){
					a=Math.random()*lvl+1;
					a=Math.round(a);
					if(a>=4){
						ran=(Math.random()*(lvl+1))*(Math.random()*(str+1))+50;
						dmg=(int)ran;
						if(dmg>1000){
							dmg=10000;
						}
					}
				}
				if((M==3)&&(!(lvl<=10))){
					a=Math.random()*lvl+1;
					a=Math.round(a);
					if(a>=5){
						ran=(Math.random()*(lvl+2))*(Math.random()*(str+2))+75;
						dmg=(int)ran;
						if(dmg>30000){
							dmg=30000;
						}
					}
				}
				if((M==4)&&(!(lvl<=15))){
					a=Math.random()*lvl+1;
					a=Math.round(a);
					if(a>=8){
						ran=(Math.random()*(lvl+3))*(Math.random()*(str+3))+100;
						dmg=(int)ran;
						if(dmg>50000){
							dmg=50000;
						}
					}
				}
				if((M==5)&&(!(lvl<=25))){
					a=Math.random()*lvl+1;
					a=Math.round(a);
					if(a>=13){
						ran=(Math.random()*(lvl+4))*(Math.random()*(str+4))+125;
						dmg=(int)ran;
						if(dmg>80000){
							dmg=80000;
						}
					}
				}
				if((M==6)&&(!(lvl>=35))){
					a=Math.random()*lvl+1;
					a=Math.round(a);
					if(a>=18){
						ran=(Math.random()*(lvl+5))*(Math.random()*(str+5))+175;
						dmg=(int)ran;
						if(dmg>110000){
							dmg=110000;
						}
					}
				}
				if((M==7)&&(!(lvl>=50))){
					a=Math.random()*lvl+1;
					a=Math.round(a);
					if(a>=25){
						ran=(Math.random()*(lvl+6))*(Math.random()*(str+6))+250;
						dmg=(int)ran;
						if(dmg>160000){
						dmg=160000;
						}
					}
				}
				if((M==8)&&(!(lvl<=65))){
					a=Math.random()*lvl+1;
					a=Math.round(a);
					if(a>=32){
						ran=(Math.random()*(lvl+7))*(Math.random()*(str+7))+500;
						dmg=(int)ran;
						if(dmg>200000){
							dmg=200000;
						}
					}
				}
				if((M==9)&&(!(lvl>=80))){
					a=Math.random()*lvl+1;
					a=Math.round(a);
					if(a>=40){
						ran=(Math.random()*(lvl+8))*(Math.random()*(str+8))+750;
						dmg=(int)ran;
						if(dmg>300000){
							dmg=300000;
						}
					}
				}
				if((M==10)&&(!(lvl>=100))){
					a=Math.random()*lvl+1;
					a=Math.round(a);
					if(a>=50){
						ran=(Math.random()*(lvl+8))*(Math.random()*(str+8))+1000;
						dmg=(int)ran;
						if(dmg>600000){
							dmg=600000;
						}
					}
				}
				if(S==1){
					a=Math.random()*lvl+1;
					if(a>=1.1){
						heal=(Math.random()*(lvl))*(Math.random()*(mag))+lvl+mag+25;
					}
					Heal=(int)heal;
					if(Heal>10000){
						Heal=10000;
					}
				}
				if((S==2)&&(!(lvl<5))){
					a=Math.random()*lvl+1;
					a=Math.round(a);
					if(a>=4){
						ran=(Math.random()*(lvl+1))*(Math.random()*(mag+1))+lvl+mag+50;
						dmg=(int)ran;
						if(dmg>9000){
							dmg=9000;
						}
					}
				}
				if((S==3)&&(!(lvl<=10))){
					a=Math.random()*lvl+1;
					a=Math.round(a);
					if(a>=5){
						ran=(Math.random()*(lvl+2))*(Math.random()*(mag+2))+lvl+mag+75;
						dmg=(int)ran;
						if(dmg>28000){
							dmg=28000;
						}
					}
				}
				if((S==4)&&(!(lvl<=15))){
					a=Math.random()*lvl+1;
					a=Math.round(a);
					if(a>=8){
						ran=(Math.random()*(lvl+3))*(Math.random()*(mag+3))+lvl+mag+100;
						dmg=(int)ran;
						if(dmg>48000){
							dmg=48000;
						}
					}
				}
				if((S==5)&&(!(lvl<=25))){
					a=Math.random()*lvl+1;
					a=Math.round(a);
					dmg=0;
					if(a>=13){
						heal=(Math.random()*(lvl+4))*(Math.random()*(mag+4))+lvl+mag+125;
						Heal=(int)heal;
					}
					if(Heal>100000){
						Heal=100000;
					}
				}
				if((S==6)&&(!(lvl<=35))){
					a=Math.random()*lvl+1;
					a=Math.round(a);
					if(a>=18){
						ran=(Math.random()*(lvl+5))*(Math.random()*(mag+5))+lvl+mag+175;
						dmg=(int)ran;
						if(dmg>108000){
							dmg=108000;
						}
					}
				}
				if((S==7)&&(!(lvl<=50))){
					a=Math.random()*lvl+1;
					a=Math.round(a);
					if(a>=25){
						ran=(Math.random()*(lvl+6))*(Math.random()*(mag+6))+lvl+mag+250;
						dmg=(int)ran;
					}
				}
				if((S==8)&&(!(lvl<=65))){
					a=Math.random()*lvl+1;
					a=Math.round(a);
					if(a>=32){
						heal=(Math.random()*(lvl+7))*(Math.random()*(mag+7))+lvl+mag+500;
						Heal=(int)heal;
						dmg=1000;
						if(heal>200000){
							heal=200000;
						}
					}
				}
				if((S==9)&&(!(lvl<=80))){
					a=Math.random()*lvl+1;
					a=Math.round(a);
					if(a>=40){
						ran=(Math.random()*(lvl+8))*(Math.random()*(mag+8))+lvl+mag+750;
						dmg=(int)ran;
						if(dmg>295000){
							dmg=295000;
						}				
					}
				}
				if((S==10)&&(!(lvl<=100))){
					a=Math.random()*lvl+1;
					a=Math.round(a);
					if(a>=50){
						ran=(Math.random()*(lvl+8))*(Math.random()*(mag+8))+lvl+mag+1000;
						dmg=(int)ran;
						if(dmg>598000){
							dmg=598000;
						}
					}
				}
		player[i]=dmg;
		playerheal[i]=Heal;
		i++;
	}
	def=def-player[1];
	def_2=def_2-player[0];
	def=def+playerheal[0];
	def_2=def_2+playerheal[1];
	System.out.println("");
		System.out.println("");
		System.out.println("---------------------------------------------------------------------");
		System.out.println(name+" has healed for "+playerheal[0]+" points of life");
		System.out.println(name+" has dealt "+player[0]+" points of damage to "+name2);
		System.out.println(name2+" has "+(def_2)+" Hitpoints remaining");
		System.out.println(name2+" has healed for "+playerheal[1]+" points of life");
		System.out.println(name2+" has dealt "+player[1]+" points of damage to "+name);
		System.out.println(name+" has "+(def)+" Hitpoints remaining");
		System.out.println("---------------------------------------------------------------------");
	}
	if((def<=0)&&((!(def<=0)&&(def_2<=0)))){
		System.out.println("----------------------------------------");
		System.out.println(name2+" has emerged victorious!");
		System.out.println("----------------------------------------");
	}
	if((def_2<=0)&&((!(def<=0)&&(def_2<=0)))){
		System.out.println("----------------------------------------");
		System.out.println(name+" has emerged victorious!");
		System.out.println("----------------------------------------");
	}
	if((def<=0)&&(def_2<=0)){
		System.out.println("----------------------------------------");
		System.out.println("Your battle has ended in a bloody tie!");
		System.out.println("----------------------------------------");
	}
		return lvl;
	}//end of multi method
}//end of multi class
		
		
