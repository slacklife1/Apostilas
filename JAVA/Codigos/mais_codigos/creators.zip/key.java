/*By: Chad Marson
Date Started: May 15
Latest Revised: June 16, 2002
Purpose: converts input types
*/
import java.io.*;
public class key{//class to convert input types
	
	public static String readString (String x) throws Exception{//method to convert input to string
		BufferedReader keyboard=new 
		BufferedReader(new InputStreamReader(System.in),1);
		x=keyboard.readLine();
		return x;
	}//end of readString method
	public static int readInt (int x) throws Exception{//method to convert input to an integer
		BufferedReader keyboard=new 
		BufferedReader(new InputStreamReader(System.in),1);
		x=Integer.parseInt(keyboard.readLine());
		return x;
	}//end of readInt method
	public static double readDouble (double x) throws Exception{//method to convert input to a double
		BufferedReader keyboard=new 
		BufferedReader(new InputStreamReader(System.in),1);
		x=Double.parseDouble(keyboard.readLine());
		return x;
	}//end of readDouble
	public static float readFloat (float x) throws Exception{//method to convert input to a float
		BufferedReader keyboard=new 
		BufferedReader(new InputStreamReader(System.in),1);
		x=Float.parseFloat(keyboard.readLine());
		return x;
	}//end of readFloat
	
}//end of key class	