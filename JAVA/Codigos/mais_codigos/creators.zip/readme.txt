Chad Marson
chadman@rogers.com
Creaton's Quest
A fun role playing game written in java