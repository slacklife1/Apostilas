/*By: Chad Marson
Date Started: May 15
Latest Revised: June 16, 2002
Purpose: A role playing game
*/
import java.io.*;

public class CreatonsQuest {//main class
	
	public static void main (String[] args) throws Exception{//main method		
		int x=0;//stores user choices
		int a=0;//stores user choice to exit game
		int z=0;//stores the monster user fights
		int tem_lvl=0;//stores user level when the begin the game
		double ran;//stores random number
		boolean error=true;//stores wether the user has choosen a valid option
		String enter="";//stores any value in the press enter to continue prompt
		String monster="";//stores monster name
		String name="";//stores users name
		String filehandle="";//stores user name
		String txt=".txt";//stores ".txt" and adds it to user name to access file
		String line="";//stores line from the story
		int points=20;//stores user skill points
		int str=0;//stores users strength
		int def=0;//stores users defence
		int mag=0;//stores users magic
		int lvl=0;//stores user level
		int exp=0;//stoes user exp
		int skill=0;//stores user skills
		while(a==0){//loop to continue game until exit option is selected
		x=0;
		while(error){//loop to ensure a valid option is choosen
			System.out.println("Welcome To Creaton's Quest");
			System.out.println("--------------------------");
			System.out.println("");
			System.out.println("1.) Create new Character");
			System.out.println("2.) Play existing Character");
			System.out.println("3.) Read the Tale");
			System.out.println("4.) Multiplayer Game");
			System.out.print("What do you wish to do? ");
			try{
			x=key.readInt(x);//stores users choice
		}
			catch(NumberFormatException e){//catches invalid option
				System.out.println("Please Choose an option from 1-4");
			}
			if((x==1)||(x==2)||(x==3)||(x==4)){
			error=false;
		}
	}
		if(x==4){
			multi.multi();
		}
		error=true;
		if (x==1){
			newchar();
		}
			
		error=true;
		if(x==2){
			while(error){//loop to ensure valid option is selected
				x=0;
				System.out.print("Please Select Which character you wish to Play: ");
				name=key.readString(name);
				name=name+txt;
				try{
					FileReader File1=new FileReader(name);
					BufferedReader reader=new BufferedReader(File1);
				}
				catch(IOException FileNotFoundException){
					System.out.println("Sorry Character does not exist. Please Select Another Character");
					x=1;
				}
				if(x==0){
				error=false;
				}
				FileReader File1=new FileReader(name);
				BufferedReader reader=new BufferedReader(File1);
				lvl=Integer.parseInt(reader.readLine());
				str=Integer.parseInt(reader.readLine());
				def=Integer.parseInt(reader.readLine());
				mag=Integer.parseInt(reader.readLine());
				exp=Integer.parseInt(reader.readLine());
				skill=Integer.parseInt(reader.readLine());
			}
		}
		if(x==3){
			FileReader file1=new FileReader("story.txt");
			BufferedReader reader5=new BufferedReader(file1);
			x=0;
			while(x<2){//loop to bring in and display story
				line=reader5.readLine();
				System.out.println(line);
				x++;
			}
			System.out.println("Press enter to continue the Tale");
			txt=key.readString(txt);
			x=0;
			while(reader5.ready()){//loop to bring in and display story
				line=reader5.readLine();
				System.out.println(line);
						
			}
		}
			while((!(a==1)&&(lvl>=1))){//loop to play the main game
				FileReader File1=new FileReader(name);
				BufferedReader reader=new BufferedReader(File1);
				lvl=Integer.parseInt(reader.readLine());
				str=Integer.parseInt(reader.readLine());
				def=Integer.parseInt(reader.readLine());
				mag=Integer.parseInt(reader.readLine());
				exp=Integer.parseInt(reader.readLine());
				skill=Integer.parseInt(reader.readLine());
				tem_lvl=lvl;
				lvl=experience.experience(exp,lvl);
				if(!(tem_lvl==lvl)){
					exp=0;
					def=def+50;
				}
				if(exp<0){
					exp=0;
				}
				if(mag<0){
					mag=0;
				}
				if(def<50){
					def=50;
				}
				if(str<0){
					str=0;
				}
				error=true;
				while(error){//loop to ensure user choices valid option
					x=0;
					System.out.println("");
					System.out.println("");
					System.out.println("1.) Training Grounds");
					System.out.println("2.) Snake Pit");
					System.out.println("3.) Goblin Grotto");
					System.out.println("4.) Dragon's Lair");
					System.out.println("5.) Creaton's Castle");
					System.out.println("6.) View Inventory");
					System.out.println("7.) View Abilities");
					System.out.println("8.) Save and Exit");
					System.out.println("9.) Allocate Points");
					System.out.println("Where do you wish to venture?");
					try{
						x=key.readInt(x);
					}
					catch(NumberFormatException e){
					}
					if((x<=9)&&(x>0)){
						error=false;
					}
				}
				error=true;
				if(x==1){
					while(error){
						System.out.println("");
						System.out.println("");
						System.out.println("Welcome to the Training Grounds");
						System.out.println("");
						System.out.println("1.) Butterfly");
						System.out.println("2.) Worm");
						System.out.println("3.) Hornet");
						System.out.println("4.) Scorpion");
						System.out.println("5.) Tyrant Tyranus");
						System.out.print("Choose which monster you wish to test your might against: ");
						try{
							z=key.readInt(z);
						}
						catch(NumberFormatException e){
						}
						if((z<=5)&&(z>0)){
							error=false;
						}
					}
					if(z==1){
						monster="butterfly";
					}
					if(z==2){
						monster="worm";
					}
					if(z==3){
						monster="hornet";
					}
					if(z==4){
						monster="scorpion";
					}
					if(z==5){
						monster="tyrant tyranus";
					}
					combat(skill,exp,lvl,str,def,mag,name,monster);
					z=0;	
				}
				error=true;
				if(x==2){
					while(error){
						System.out.println("");
						System.out.println("");
						System.out.println("Welcome to the Snake Pit");
						System.out.println("");
						System.out.println("1.) RattleSnake");
						System.out.println("2.) Salamander");
						System.out.println("3.) Chameleon");
						System.out.println("4.) asp");
						System.out.println("5.) King Slytheryn");
						System.out.print("Choose which monster you wish to test your might againist: ");
						try{
							z=key.readInt(z);
						}
						catch(NumberFormatException e){
						}
						if((z<=5)&&(z>0)){
							error=false;
						}
					}
					if(z==1){
						monster="rattlesnake";
					}
					if(z==2){
						monster="salamander";
					}
					if(z==3){
						monster="chameleon";
					}
					if(z==4){
						monster="asp";
					}
					if(z==5){
						monster="King Slytheryn";
					}
					combat(skill,exp,lvl,str,def,mag,name,monster);
					z=0;
				}
				
				error=true;
				if(x==3){
					while(error){
						System.out.println("");
						System.out.println("");
						System.out.println("Welcome to the Goblin Grotto");
						System.out.println("");
						System.out.println("1.) Green Goblin");
						System.out.println("2.) Hobgoblin");
						System.out.println("3.) Hemogoblin");
						System.out.println("4.) Elite goblin");
						System.out.println("5.) Hailton");
						System.out.print("Choose which monster you wish to test your might againist: ");
						try{
							z=key.readInt(z);
						}
						catch(NumberFormatException e){
						}
						if((z<=5)&&(z>0)){
							error=false;
						}
					}
					if(z==1){
						monster="green goblin";
					}
					if(z==2){
						monster="hobogoblin";
					}
					if(z==3){
						monster="hemogoblin";
					}
					if(z==4){
						monster="elite goblin";
					}
					if(z==5){
						monster="hailton";
					}
					combat(skill,exp,lvl,str,def,mag,name,monster);
					z=0;
				}
				error=true;
				if(x==4){
					while(error){
						System.out.println("");
						System.out.println("");
						System.out.println("Welcome to the Dragon Castle");
						System.out.println("");
						System.out.println("1.) Dragon Whelp");
						System.out.println("2.) Drake");
						System.out.println("3.) Red Dragon ");
						System.out.println("4.) Singe");
						System.out.println("5.) Hroth'Gar");
						System.out.print("Choose which monster you wish to test your might againist: ");
						try{
							z=key.readInt(z);
						}
						catch(NumberFormatException e){
						}
						if((z<=5)&&(z>0)){
							error=false;
						}
					}
					if(z==1){
						monster="dragon whelp";
					}
					if(z==2){
						monster="drake";
					}
					if(z==3){
						monster="red dragon";
					}
					if(z==4){
						monster="singe";
					}
					if(z==5){
						monster="hroth'gar";
					}
					combat(skill,exp,lvl,str,def,mag,name,monster);
					z=0;
				}
				error=true;
				if(x==5){
					while(error){
						System.out.println("");
						System.out.println("");
						System.out.println("Welcome to Creaton's Castle");
						System.out.println("");
						System.out.println("1.) Black Knight");
						System.out.println("2.) Stone Sentry");
						System.out.println("3.) Balrog");
						System.out.println("4.) Prince Damien Creaton");
						System.out.println("5.) Sir Lucifer Creaton");
						System.out.print("Choose which monster you wish to test your might againist: ");
						try{
							z=key.readInt(z);
						}
						catch(NumberFormatException e){
						}
						if((z<=5)&&(z>0)){
							error=false;
						}
					}
					if(z==1){
						monster="black knight";
					}
					if(z==2){
						monster="stone sentry";
					}
					if(z==3){
						monster="balrog";
					}
					if(z==4){
						monster="prince damien creaton";
					}
					if(z==5){
						monster="sir lucifer creaton";
					}
					combat(skill,exp,lvl,str,def,mag,name,monster);
					z=0;
				
			}
			if(x==6){
				inventory(lvl,str,def,mag,skill);
			}
			if(x==7){
				ability(lvl);
			}
			if(x==8){
				save(lvl,str,def,mag,exp,skill,name);
				a=1;
			}
			if(x==9){
				points(lvl,str,def,mag,exp,skill,name);
			}
		}
	}
}//end of main method
		public static int inventory(int lvl, int str, int def, int mag,int skill)throws Exception{//method to display users inventory
				int b=1;
				System.out.println("---------------------------------------");
				System.out.println("Your level is "+lvl);
				System.out.println("Your strength level is "+str);
				System.out.println("Your defence level is "+def);
				System.out.println("Your magic level is "+mag);
				System.out.println("You have "+skill+" skill points left to place");
				System.out.println("---------------------------------------");
				return b;
			}//end of inventory method
			public static int ability(int lvl){//dispalys the abilities the user is capable of
				System.out.println("At your level you have the ability to do the following:");
				System.out.println("Punch and Minor Heal");
				if(lvl>=5){
					System.out.println("Slash and Flame Bolt");
				}
				if(lvl>=10){
					System.out.println("Kick and Wind Strike");
				}
				if(lvl>=15){
					System.out.println("Range Attack and Poison Arrow");
				}
				if(lvl>=25){
					System.out.println("Double Attack and Heal");
				}
				if(lvl>=35){
					System.out.println("Eagle Strike and Serpent Strike");
				}
				if(lvl>=50){
					System.out.println("Critical Hit and Meteor Shower");
				}
				if(lvl>=65){
					System.out.println("Triple Attack and Holy Healing");
				}
				if(lvl>=80){
					System.out.println("Flying Kick and Holy Light");
				}
				if(lvl>=100){
					System.out.println("Berserk of Rage and Devastate");
				}
			int b=1;
			return b;
			}//end of ability method
			public static int save(int lvl,int str,int def,int mag,int exp,int skill,String name)throws Exception{//method to output and save all user details
				
				FileOutputStream file=new FileOutputStream(name);
				PrintWriter file2=new PrintWriter(file);
				file2.println(lvl);
				file2.println(str);
				file2.println(def);
				file2.println(mag);
				file2.println(exp);
				file2.println(skill);
				file2.close();
				int b=1;
				return b;
			}
			public static int points(int lvl,int str,int def,int mag, int exp, int skill,String name)throws Exception{//method to allocate skill points
				int a=0;
				int tem_str=0;
				int tem_def=0;
				int tem_mag=0;
				boolean error=true;
				while(error){
				System.out.print("How many points do you wish to place in Strength 0-"+skill+"?");
				try{
					tem_str=key.readInt(tem_str);
					str=tem_str+str;
					if((tem_str<=skill)&&(tem_str>=0)){
						error=false;
					}
				}
				catch(NumberFormatException e){
					System.out.println("Invalid Number");
				}
			}
			error=true;
			skill=skill-tem_str;
			while(error){
				System.out.println("You have "+skill+" remaining");
				System.out.print("How many points do you wish to place in Defence 0-"+skill+"?");	
				try{
					tem_def=key.readInt(tem_def);
					def=tem_def+def;
					if((tem_def<=skill)&&(tem_def>=0)){
						error=false;
					}
				}
				catch(NumberFormatException e){
					System.out.println("Invalid Number");
				}	
			}
			error=true;
			skill=skill-tem_def;
			while(error){
				System.out.println("You have "+skill+" remaining");
				System.out.print("How many points do you wish to place in Magic 0-"+skill+"?");	
				try{
					tem_mag=key.readInt(mag);
					mag=mag+tem_mag;
					if((tem_mag<=skill)&&(tem_mag>=0)){
						error=false;
					}
				}
				catch(NumberFormatException e){
					System.out.println("Invalid Number");
				}
			}
			skill=0;
			FileOutputStream file=new FileOutputStream(name);
			PrintWriter file2=new PrintWriter(file);
			file2.println(lvl);
			file2.println(str);
			file2.println(def);
			file2.println(mag);
			file2.println(exp);
			file2.println(skill);
			file2.close();
			return skill;
		}//end of points method
		public static int newchar()throws Exception{//method that create's a new character
			String name="";
			String txt=".txt";
			String filehandle="";
			int str=0;
			int def=0;
			int mag=0;
			int lvl=0;
			boolean error=true;
			int points=20;
			int exp=0;
			int skill=0;
			String enter="";
			System.out.print("Please enter your Character's name: ");
			name=key.readString(name);
			filehandle=name+txt;
			FileOutputStream file=new FileOutputStream(filehandle);
			PrintWriter file1=new PrintWriter(file);
			lvl=1;
			System.out.println("You may now choose to place ability points");
			System.out.println("You have 20 points to place over 3 categories");
			System.out.println("Strength, Defence, Magic");
			while(error){
				System.out.print("How many points do you wish to place in Strength 0-20?");
				try{
					str=key.readInt(str);
				
					if((str<=points)&&(str>=0)){
						error=false;
					}
				}
				catch(NumberFormatException e){
					System.out.println("Invalid Number");
				}
			}
			error=true;
			points=points-str;
			while(error){
				System.out.println("You have "+points+" remaining");
				System.out.println("How many points do you wish to place in Defence 0-"+points+"?");	
				try{
					def=key.readInt(def);
					if((def<=points)&&(def>=0)){
						error=false;
					}
				}
				catch(NumberFormatException e){
					System.out.println("Invalid Number");
				}	
			}
			error=true;
			points=points-def;
			while(error){
				System.out.println("You have "+points+" remaining");
				System.out.println("How many points do you wish to place in Magic 0-"+points+"?");	
				try{
					mag=key.readInt(mag);
					if((mag<=points)&&(mag>=0)){
						error=false;
					}
				}
				catch(NumberFormatException e){
					System.out.println("Invalid Number");
				}
			}
			
				System.out.println("You have created a your new character");
				System.out.println("Please return to the main menu and select play existing character");
				System.out.println("Have safe journey's with "+name);
				
				file1.println(lvl);
				file1.println(str);
				file1.println(def+50);
				file1.println(mag);
				file1.println(exp+100);
				file1.println(skill);
				file1.close();
				System.out.println("Press Enter to return to main menu");
				enter=key.readString(enter);
			int b=0;
			return b;
		}//end of newchar method		
	
			
		
	
	public static int combat (int skill, int exp, int lvl, int str, int def, int mag, String name, String monster) throws Exception{//combat method
	int x=0;
	double a=0;//stores random number
	int b=0;
	double heal=0;//stores the value of a players heal
	int monster_lvl=0;//stores monster level
	int monster_str=0;//stores monster strength
	int monster_def=0;//stores monster defence
	int monster_mag=0;//stores monster magic
	int monster_exp=0;//stores monster experience
	int monster_skill=0;//stores monster skill
	double mexp=0;//stores random experience
	double mskill=0;//stores random skill
	double mlvl=0;//stores random level
	String monster_name="";//stores monster name
	int M=0;//stores users melee attack choice
	int S=0;//stores users magic attack choice
	int lvlgap=lvl-monster_lvl;//stores the difference of the level of the user compared to the monster
	double ran=0;//stores random number
	double hint;//stores random number
	int dmg=0;//stores user damage
	int monster_dmg=0;//monster damage
	String txt=".txt";
	String message="";//stores hint message
	int realdef=0;//stores user defence
	int Heal=0;//stores heal value
	boolean error=true;
	realdef=def;
	monster_name=monster;
	monster=monster+txt;
	FileReader File2=new FileReader(monster);
	BufferedReader reader2=new BufferedReader(File2);
	mlvl=(Integer.parseInt(reader2.readLine())*Math.random()*5)+1;
	monster_lvl=(int)mlvl;
	monster_str=Integer.parseInt(reader2.readLine());
	monster_def=Integer.parseInt(reader2.readLine())+50;
	monster_mag=Integer.parseInt(reader2.readLine());
	mexp=(Integer.parseInt(reader2.readLine()))*(Math.random()*5)+1;
	monster_exp=(int)mexp;
	mskill=(Integer.parseInt(reader2.readLine()))*(Math.random()*3)+1;
	monster_skill=(int)mskill;
	while((monster_def>=1)&&(def>1)){//loop to run combat while fighters are alive
		lvlgap=lvl-monster_lvl;
		while(error){
			System.out.println("");
			System.out.println("");
			System.out.println("1.) Melee Attack");
			System.out.println("2.) Magic Attack");
			System.out.print("Which type of attack do you wish to use? ");
			try{
				x=key.readInt(x);
			}
			catch(NumberFormatException e){
			}
			if((x<=2)&&(x>0)){
				error=false;
			}
		}
		error=true;
		if(x==1){
			while(error){
				S=0;
				System.out.println("");
				System.out.println("");
				System.out.println("1.) Punch");
				System.out.println("2.) Slash");
				System.out.println("3.) Kick");
				System.out.println("4.) Range Attack");
				System.out.println("5.) Double Attack");
				System.out.println("6.) Eagle Strike");
				System.out.println("7.) Critical Hit");
				System.out.println("8.) Triple Attack");
				System.out.println("9.) Flying Kick");
				System.out.println("10.) Berserk of Rage");
				System.out.print("Which Attack Do you wish to use? ");
				try{
					M=key.readInt(M);
				}
				catch(NumberFormatException e){
				}
				if((M<=10)&&(M>0)){
					error=false;
				}
			}
		}
		error=true;
		if(x==2){
			while(error){
				M=0;
				System.out.println("");
				System.out.println("");
				System.out.println("1.) Minor Heal");
				System.out.println("2.) Flame Bolt");
				System.out.println("3.) Wind Strike");
				System.out.println("4.) Poison Arrow");
				System.out.println("5.) Heal");
				System.out.println("6.) Serpent Strike");
				System.out.println("7.) Meteor Shower");
				System.out.println("8.) Holy Healing");
				System.out.println("9.) Holy Light");
				System.out.println("10.) Devastate");
				try{
					S=key.readInt(S);
				}
				catch(NumberFormatException e){
				}
				if ((S<=10)&&(S>0)){
					error=false;
				}
			}
		}
		error=true;
		dmg=0;
		Heal=0;
		ran=0;
		heal=0;
		if(M==1){
			a=Math.random()*lvl+1;
			if(a>=1.1){
				ran=(Math.random()*(lvl))*(Math.random()*(str));
				
			}
			dmg=(int)ran;
			if(dmg>500){
				dmg=1000;
			}
		}
		if((M==2)&&(!(lvl<5))){
			a=Math.random()*lvl+1;
			a=Math.round(a);
			if(a>=2){
				ran=(Math.random()*(lvl+1))*(Math.random()*(str+1))+50;
				dmg=(int)ran;
				if(dmg>1000){
					dmg=10000;
				}
			}
		}
		if((M==3)&&(!(lvl<=10))){
			a=Math.random()*lvl+1;
			a=Math.round(a);
			if(a>=3){
				ran=(Math.random()*(lvl+2))*(Math.random()*(str+2))+75;
				dmg=(int)ran;
				if(dmg>30000){
					dmg=30000;
				}
			}
		}
		if((M==4)&&(!(lvl<=15))){
			a=Math.random()*lvl+1;
			a=Math.round(a);
			if(a>=4){
				ran=(Math.random()*(lvl+3))*(Math.random()*(str+3))+100;
				dmg=(int)ran;
				if(dmg>50000){
					dmg=50000;
				}
			}
		}
		if((M==5)&&(!(lvl<=25))){
			a=Math.random()*lvl+1;
			a=Math.round(a);
			if(a>=5){
				ran=(Math.random()*(lvl+4))*(Math.random()*(str+4))+125;
				dmg=(int)ran;
				if(dmg>80000){
					dmg=80000;
				}
			}
		}
		if((M==6)&&(!(lvl<=35))){
			a=Math.random()*lvl+1;
			a=Math.round(a);
			if(a>=9){
				ran=(Math.random()*(lvl+5))*(Math.random()*(str+5))+175;
				dmg=(int)ran;
				if(dmg>110000){
					dmg=110000;
				}
			}
		}
		if((M==7)&&(!(lvl<=50))){
			a=Math.random()*lvl+1;
			a=Math.round(a);
			if(a>=14){
				ran=(Math.random()*(lvl+6))*(Math.random()*(str+6))+250;
				dmg=(int)ran;
				if(dmg>160000){
				dmg=160000;
				}
			}
		}
		if((M==8)&&(!(lvl<=65))){
			a=Math.random()*lvl+1;
			a=Math.round(a);
			if(a>=18){
				ran=(Math.random()*(lvl+7))*(Math.random()*(str+7))+500;
				dmg=(int)ran;
				if(dmg>200000){
					dmg=200000;
				}
			}
		}
		if((M==9)&&(!(lvl<=80))){
			a=Math.random()*lvl+1;
			a=Math.round(a);
			if(a>=23){
				ran=(Math.random()*(lvl+8))*(Math.random()*(str+8))+750;
				dmg=(int)ran;
				if(dmg>300000){
					dmg=300000;
				}
			}
		}
		if((M==10)&&(!(lvl<=100))){
			a=Math.random()*lvl+1;
			a=Math.round(a);
			if(a>=28){
				ran=(Math.random()*(lvl+8))*(Math.random()*(str+8))+1000;
				dmg=(int)ran;
				if(dmg>600000){
					dmg=600000;
				}
			}
		}
		if(S==1){
			a=Math.random()*lvl+1;
			lvlgap=0;
			if(a>=1.1){
				heal=(Math.random()*(lvl))*(Math.random()*(mag))+lvl+mag+25;
			}
			Heal=(int)heal;
			if(Heal>10000){
				Heal=10000;
			}
		}
		if((S==2)&&(!(lvl<5))){
			a=Math.random()*lvl+1;
			a=Math.round(a);
			if(a>=2){
				ran=(Math.random()*(lvl+1))*(Math.random()*(mag+1))+lvl+mag+50;
				dmg=(int)ran;
				if(dmg>9000){
					dmg=9000;
				}
			}
		}
		if((S==3)&&(!(lvl<=10))){
			a=Math.random()*lvl+1;
			a=Math.round(a);
			if(a>=3){
				ran=(Math.random()*(lvl+2))*(Math.random()*(mag+2))+lvl+mag+75;
				dmg=(int)ran;
				if(dmg>28000){
					dmg=28000;
				}
			}
		}
		if((S==4)&&(!(lvl<=15))){
			a=Math.random()*lvl+1;
			a=Math.round(a);
			if(a>=4){
				ran=(Math.random()*(lvl+3))*(Math.random()*(mag+3))+lvl+mag+100;
				dmg=(int)ran;
				if(dmg>48000){
					dmg=48000;
				}
			}
		}
		if((S==5)&&(!(lvl<=25))){
			a=Math.random()*lvl+1;
			a=Math.round(a);
			lvlgap=0;
			dmg=0;
			if(a>=5){
				heal=(Math.random()*(lvl+4))*(Math.random()*(mag+4))+lvl+mag+125;
				Heal=(int)heal;
			}
			if(Heal>100000){
				Heal=100000;
			}
			
		}
		if((S==6)&&(!(lvl<=35))){
			a=Math.random()*lvl+1;
			a=Math.round(a);
			if(a>=7){
				ran=(Math.random()*(lvl+5))*(Math.random()*(mag+5))+lvl+mag+175;
				dmg=(int)ran;
				if(dmg>108000){
					dmg=108000;
				}
			}
		}
		if((S==7)&&(!(lvl<=50))){
			a=Math.random()*lvl+1;
			a=Math.round(a);
			if(a>=10){
				ran=(Math.random()*(lvl+6))*(Math.random()*(mag+6))+lvl+mag+250;
				dmg=(int)ran;
			}
		}
		if((S==8)&&(!(lvl<=65))){
			a=Math.random()*lvl+1;
			a=Math.round(a);
			lvlgap=0;
			if(a>=13){
				heal=(Math.random()*(lvl+7))*(Math.random()*(mag+7))+lvl+mag+500;
				Heal=(int)heal;
				dmg=1000;
				if(heal>200000){
					heal=200000;
				}
			}
		}
		if((S==9)&&(!(lvl<=80))){
			a=Math.random()*lvl+1;
			a=Math.round(a);
			if(a>=16){
				ran=(Math.random()*(lvl+8))*(Math.random()*(mag+8))+lvl+mag+750;
				dmg=(int)ran;
				if(dmg>295000){
					dmg=295000;
				}				
			}
		}
		if((S==10)&&(!(lvl<=100))){
			a=Math.random()*lvl+1;
			a=Math.round(a);
			if(a>=20){
				ran=(Math.random()*(lvl+8))*(Math.random()*(mag+8))+lvl+mag+1000;
				dmg=(int)ran;
				if(dmg>598000){
					dmg=598000;
				}
			}
		}
		if(M==0){
			lvlgap=0;
		}
		if(lvlgap<=3){
			dmg=dmg;
	
		}
		if((lvlgap>=4)&&(lvlgap<=8)){
			dmg=dmg+(lvl*2)+str;  
		}
		if((lvlgap>=9)&&(lvlgap<=15)){
			dmg=dmg+(lvl*3)+str;  
		}
		if(lvlgap>16){
			dmg=dmg+(lvl*4)+str;  
		}
		
		ran=(Math.random()*(monster_lvl))*(Math.random()*(monster_str))+monster_lvl+(2*monster_str);
		monster_dmg=(int)ran;
		lvlgap=monster_lvl-lvl;
		if(lvlgap<=3){
			monster_dmg=monster_dmg;
	
		}
		if((lvlgap>=4)&&(lvlgap<=8)){
			monster_dmg=monster_dmg+(lvl*2)+monster_str;  
		}
		if((lvlgap>=9)&&(lvlgap<=15)){
			monster_dmg=monster_dmg+(lvl*3)+monster_str;  
		}
		if(lvlgap>16){
			monster_dmg=monster_dmg+(lvl*4)+monster_str;
		}	
		monster_def=monster_def-dmg;
		def=def-monster_dmg;
		def=def+Heal;
		System.out.println("");
		System.out.println("");
		System.out.println("---------------------------------------------------------------------");
		System.out.println("You have healed yourself for "+Heal+" points of life");
		System.out.println("You have dealt "+dmg+" points of damage to "+(monster_name));
		System.out.println(monster_name+" has "+(monster_def)+" Hitpoints remaining");
		System.out.println(monster_name+" has dealt "+monster_dmg+" points of damage to you");
		System.out.println("You have "+(def)+" Hitpoints remaining");
		System.out.println("---------------------------------------------------------------------");
	}
	if((def<1)&&(!(((monster_def<1)&&(def<1))))){
		System.out.println("---------------------------------------------------");
		System.out.println("You have been killed by "+monster_name);
		System.out.println("You have lost "+(monster_exp*2)+" experience points");
		System.out.println("---------------------------------------------------");
		exp=exp-(monster_exp*2);
		FileOutputStream file=new FileOutputStream(name);
		PrintWriter file1=new PrintWriter(file);
		file1.println(lvl);
		file1.println(str);
		file1.println(realdef);
		file1.println(mag);
		file1.println(exp);
		file1.println(skill);
		file1.close();
	}
	x=0;
	if((monster_def<1)&&(!(((monster_def<1)&&(def<1))))){
		System.out.println("---------------------------------------------------");
		System.out.println("You have killed "+monster_name);
		System.out.println("You have gained "+(monster_exp)+" experience points");
		System.out.println("You have gained "+(monster_skill)+" skill points");
		System.out.println("---------------------------------------------------");
		exp=(monster_exp)+exp;
		skill=skill+monster_skill;
		FileOutputStream file=new FileOutputStream(name);
		PrintWriter file1=new PrintWriter(file);
		file1.println(lvl);
		file1.println(str);
		file1.println(realdef);
		file1.println(mag);
		file1.println(exp);
		file1.println(skill);
		file1.close();
		x=1;
	}
	if((monster_def<1)&&(def<1)){
		System.out.println("-------------------------------------");
		System.out.println("Your bloody battle has ended in a tie");
		System.out.println("You have lost "+(monster_exp/2)+" experience");
		System.out.println("-------------------------------------");
		exp=(monster_exp/2)+exp;
	}
				
		System.out.println("Press Enter to continue");
		txt=key.readString(txt);
			if(x==1){
				hint=Math.random()*150;
				hint=Math.round(hint);
				System.out.println("------------------------------------------------------------------------------");
				if(hint==1){
					System.out.println("You have found a magical sword. It's presence gives you the ability to have 10 more strength and 10 more magically skill. Use it wisely!");
					mag=mag+10;
					str=str+10;
					hint=0;
				}
				if((hint>=5)&&(hint<=10)){
					System.out.println("Creaton has poisoned the village food which you eat to gain strength. You have lost 5 strength");
					str=str-5;
					hint=0;
				}
				if((hint>=11)&&(hint<=20)){
					System.out.println("The village brewer has supplied you with some alcohol. You gain 10 strength but lose 5 magic skill");
					str=str+10;
					mag=mag-5;
					hint=0;
				}
				if((hint>=21)&&(hint<=25)){
					System.out.println("You have spent the night with a village maiden she has given you the confidence to do anything! You gain 25 defence!");
					realdef=realdef+25;
					hint=0;
				}
				if((hint>=26)&&(hint<=30)){
					System.out.println("You have found a mithril steel chestplate it being with you increases your defence by 50!");
					realdef=realdef+50;
					hint=0;
				}
				if((hint>=31)&&(hint<=40)){
					System.out.println("Hint: Killing an easy monster may be fast but to kill creaton you must develope your skills by fighting difficult enemies!");
					hint=0;
				}
				if((hint>=41)&&(hint<=70)){
					System.out.println("Hint: You can only deal damage with attacks you have the ability to execute. Go to view abilities to see what skills you are able to execute!");
					hint=0;
				}
				if((hint>=71)&&(hint<=90)){
					System.out.println("Hint: Rumour has it Creaton is more than level 100 practice hard so one day you may defeat him with confidence!");
					hint=0;
				}
				if((hint>=91)&&(hint<=96)){
					System.out.println("You were charmed by the village enchantress you gain 25 magical skill");
					mag=mag+25;
					hint=0;
				}
				if((hint>=97)&&(hint<=99)){
					System.out.println("You have looted the breastplate of Vignt! You gain 20 strength 20 magic and 20 defence");
					mag=mag+20;
					str=str+20;
					realdef=realdef+20;
					hint=0;
				}
				if(hint==100){
					System.out.println("You have looted The Breastplate of the Righteous. You gain 100 Strength 100 Defence and 100 Magic");
					mag=mag+100;
					str=str+100;
					realdef=realdef+100;
					hint=0;
				}
				if((hint>100)&&(hint<=110)){
					System.out.println("Hint: The greater your level the easier it will be for you to execute harder attacks. Work hard to gain levels to make your attacks more reliable");
				}
				if((hint>=111)&&(hint<=120)){
					System.out.println("Hint: The greater your strength the harder you hit! Kill monsters to increase your skill strength to hit harder.");
				}
				if((hint>=121)&&(hint<=130)){
					System.out.println("After the battle you do your happy dance. Unfortunatly you trip and lose 50 hitpoints");
					realdef=realdef-50;
				}
				if((hint>=131)&&(hint<=140)){
					System.out.println("Hint: The greater your magic the greater you can heal and do damage with magical attacks.");
				}
				if((hint>=141)&&(hint<=148)){
					System.out.println("You have looted the breastplate of "+monster_name+" you gain 100 defence!");
					realdef=realdef+100;
				}
				if((hint>148)&&(hint<=151)){
					System.out.println("You have looted the Great Breastplate. You gain 100 strength 100 defence and 100 magic!");
					realdef=realdef+100;
					str=str+100;
					mag=mag+100;
				}
				System.out.println("--------------------------------------------------------------------------------");
				FileOutputStream file=new FileOutputStream(name);
				PrintWriter file2=new PrintWriter(file);
				file2.println(lvl);
				file2.println(str);
				file2.println(realdef);
				file2.println(mag);
				file2.println(exp);
				file2.println(skill);
				file2.close();
			}
	b=1;
	return b;	
	}//end of combat method
		
}//end of main class
		
