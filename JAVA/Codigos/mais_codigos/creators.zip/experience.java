/*By: Chad Marson
Date Started: May 15
Latest Revised: June 16, 2002
Purpose: To check users experience and evalutate wether they deserve another level
*/
import java.io.*;
public class experience{//class to check users experience
	
	public static int experience (int exp,int lvl) throws Exception{//method to check user experience
		double expneeded=0;//stores amount of experience needed
		int Expneeded=0;//stores amount of experience needed
		expneeded=Math.pow(lvl,2)+10;
		Expneeded=(int)expneeded;
		if(exp>=Expneeded){
			lvl=lvl+1;
			System.out.println("Congrats You Are now Level "+(lvl));
		exp=0;
		}
		return lvl;
	}//end of experince method
}//end of experince class