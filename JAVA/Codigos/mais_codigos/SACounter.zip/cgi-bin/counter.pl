#!/usr/bin/perl

#change $counter_file according to your configuration
$counter_file = '../counter/realcounter.txt';

open (COUNT, "<$counter_file") or die "Could not open counter file";
$count = <COUNT>;
close COUNT;

$count++;

open (COUNT, ">$counter_file") or die "Could not open counter file to write";
print COUNT $count;
close COUNT;

print "Content-type: text/html\n\n";
print "OK";
