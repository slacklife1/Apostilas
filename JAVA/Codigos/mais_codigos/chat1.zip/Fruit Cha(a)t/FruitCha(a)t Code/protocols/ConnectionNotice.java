package protocols;

import java.io.*;

public class ConnectionNotice implements Serializable
{
	public boolean status; //false=reject, true=accept
}