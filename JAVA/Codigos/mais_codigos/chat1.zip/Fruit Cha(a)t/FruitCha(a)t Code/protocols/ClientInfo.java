package protocols;

import java.io.*;

public class ClientInfo implements Serializable
{
	public int clientId;
	public String clientName;
}