package protocols;

import java.io.*;

public class UpdateList implements Serializable
{
	public boolean requestType;
	public String newClient;
}
