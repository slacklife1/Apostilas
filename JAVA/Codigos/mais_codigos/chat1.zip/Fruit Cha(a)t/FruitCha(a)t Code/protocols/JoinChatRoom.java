package protocols;

import java.io.*;

public class JoinChatRoom implements Serializable
{
	public boolean requestType;
	public int roomNumber;
}
