package protocols;

import java.io.*;

public class ChatRequest implements Serializable
{
	public int senderId;
	public int recieverId;
}
