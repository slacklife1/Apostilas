package protocols;

import java.io.*;

public class ServerShutDown implements Serializable
{}