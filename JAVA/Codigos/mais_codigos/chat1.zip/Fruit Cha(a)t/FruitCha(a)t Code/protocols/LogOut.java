package protocols;

import java.io.*;

public class LogOut implements Serializable
{}
