package protocols;

import java.io.*;

public class KickedOutNotice implements Serializable
{
	public int roomNumber;
}
