Project Name : Fruit Cha(a)t
Project Team : Mohammad Ali Akbani    1665
	       Faraz Younus Bandukda  1672 
   	       Farhan Ali             1676



Project Components : Fruit Cha(a)t Plate  ( Client )
		     Fruit Cha(a)t Piyala ( Server )

USING THE APPLICATION

You have been provided with the executables and the code. The executable folder and zip file contains two jar files, two batch files to run the batch files and two folders containing unzipped class files and batch files to run the code

The code has been tested with j2sdk1.4.1_02
The path to java bin directory should be in the path environment variable

To Run Jar Files
1.To execute server run RunServerJar
2.To execute client run RunClientJar
3.You may be able to run the jar files directly by double clicking them
OR
1.Go to Server folder and run RunServer
2.Go to Client folder and run RunClient

To open the source code please use JCreator (Java IDE)
You can download JCreator from www.jcreator.com
Then open the JCW file to open the project source code.
