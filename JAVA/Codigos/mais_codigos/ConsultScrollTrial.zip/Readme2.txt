/* this is a comment ************************
/* this is a comment ************************
ConsultScroll v2.1, Copyright (c) 1998-99, consulting.com, Inc.
<br>
<br>
-User Disclaimer
<BR>
<BR>This software is provided "as is" without warranty of any kind,
either express or implied, including without limitation warranties
of merchantability, fitness for a particular purpose, or
noninfringement. consulting.com, Inc. makes reasonable efforts to
develop and produce useful software as well as accurate and up-to-date
documentation regarding the use of such software, it does not,
however, make any warranties or representations as to its
usability, accuracy or completeness. Under no circumstances and
under no legal theory shall consulting.com, Inc., or any other
party involved in distributing consulting.com, Inc.'s software be
liable to you or any other person for damages resulting from your
use of this software and its documentation.
<BR>
<BR>

-Licence Terms
<BR>
<BR>This software may be used for evaluation purposes only.
The evaluation version does not expire and may be used on
multiple domains, however the applet displays the consulting.com
url in the browser's status bar. It is a violation of this license
agreement to intentionally overwrite this message. The purchased
version does not display the consulting.com url. All associated
applets may be displayed on the internet and local intranet systems
under the terms of the evaluation licence agreement.
<br>
<BR>The Software is made available for downloading solely for use by
end users according to the License Agreement. Any reproduction or
redistribution of the Software not in accordance with the License
Agreement is expressly prohibited by law, and may result in severe
civil and criminal penalties. Violators will be prosecuted to the
maximum extent possible.
<BR>
<BR>
consulting.com, Inc. makes no warranties regarding usability,
accuracy or completeness of any product, including beta release
software. Beta release software is, in general, incomplete and
likely to have coding errors and bugs.

