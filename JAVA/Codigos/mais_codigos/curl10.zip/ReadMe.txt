CacheURL Version 1.0
Copyright (c) 2000 Waqas Shafiq.
All Rights Reserved.


Table of contents
-----------------
Introduction 
Main Features 
Demo 
Usage Tips 
Software Requirements 
Licensing and Distribution
Registration
Download 
Contact Me 


Introduction
------------
CacheURL applet exploits the caching ability of  browsers to pre-fetch 
several web pages and images in parallel, with or without the interaction
of the user.

A visitor may spend from under a minute to five or more minutes on a 
single web page. During this time his internet connection may stay idle. 
Wouldn't it be better if  it was possible to pre-fetch some links ahead 
of time with a simple mouse click without opening a separate browser
window. 

The CacheURL applet is designed to achieve this objective.

Often we come across more than one 'interesting' link on a web page. In 
such a case CacheURL applet can be used to pre-fetch the desired web 
pages in the background while we are viewing the current page. The cached
page can later be viewed in a separate window by clicking CacheURL applet
or within the same window by clicking the appropriate link.

Once the visitor on your site has clicked the applet button and the URL 
associated with it is either completely or partially cached, it is very 
likely that he will checkout the link. 

The applet provides two different modes of operation:
 
  Silent Mode - In this mode the applet can be used to cache several web 
  pages and/or images. The URL of a text file containing the list of URLs
  that are to be fetched is provided as a parameter. In this case the 
  applet works in the background without a user interface. This mode of 
  operation can be used in conjunction with the interactive mode. It uses
  the following parameters:

  Name         Description
  urlList      URL of the text file containing the list of HTTP URLs to 
               be cached. 

  Example
  <PARAM NAME = "urlList" VALUE = "http://www.domain.com/urllist.txt">

  A sample text file is avaiable at 
  http://wshafiq.webjump.com/urllist.txt
 
 Interactive Mode - In this mode the applets takes the appearance of a 
 button and it can be associated with a URL on the web page. 
 Alternatively the applets can also be used as a standalone link. This 
 mode makes use of the following parameters:

  Name         Description
  linkText     The text of the hyperlink the applet is to be associated 
               with. You may skip this parameter if you want to use the 
               applet in silent mode.
  linkURL      The URL of the hyperlink the applet is associated with. 
               This is required only in the interactive mode of operation.
  buttonText   Text you want to appear on the button. You may leave this
               parameter if you would like to create a button without any
               text on it.
  fontSize     Used to set the size of text that appears on the button. 
               Default is 8.
  cacheImages  Used to enable/disable image caching. Default is no. 

  Example
  <PARAM NAME = "linkText" VALUE = "Waqas Shafiq's GuestBook">
  <PARAM NAME = "linkURL" VALUE = "index.html#GuestBook">
  <PARAM NAME = "buttonText" VALUE = "GuestBook">
  <PARAM NAME = "fontSize" VALUE = "12">
  <PARAM NAME = "cacheImages" VALUE = "yes">


The applet uses several colors to indicate the progress of caching 
operation.

  Example      Meaning
  blue         The applet has not been activated yet.
  yellow       The caching process has started. 
  orange       The web page has been cached but the images have not been 
               either fetched completely or image caching is disabled. 
               The URL can be viewed by clicking the button.
  green        Both web page and the images have been cached completely. 
               The URL can be viewed by clicking the button.
  red          The URL could not be cached either because the server was 
               down, the file was not found or because some internal 
               exception occured.

       
Main Features
-------------
* Caches web pages (.htm, .html & .txt) and images (.jpg and .gif). 
* Compatible with Netscape Navigator and Microsoft Internet Explorer. 
* Supports HTTP URLs. 
* It can be associated with a hyperlink on the web page. 
* May be used as an standalone button. 
* Uses several color to indicate the progress.  
* Can be customized with the help of few simple parameters. 
* Opens cached URLs in a new window. 
* Image caching can be disabled.  
* Can be used to silently download specified URLs without user
  interaction. 
* Pre-fetches several web pages and images simultaneously. 
* Increases the time a visitor stays on a particular web page. 
* To a certain degree it ensures that a visitor will checkout all the 
  links that he find interesting on a web page. 
    
   
Demo
----
Checkout http://wshafiq.webjump.com/CacheURL.html for a demo.


Usage Tips
----------
* The applet can be used in silent mode to cache images that are common 
  to several pages and web pages that most of the visitors are likely to
  visit.  

* Keep the size of the text file containing URLs to be cached to a 
  minimum. 

* The number of instances of the applet in interactive mode must be 
  limited otherwise the it might slowdown the system. 

* Although the use of applet does not require any significant changes in 
  the existing web pages but you might consider some modifications in 
  order to utilize the applet to its full potential. 

* If you run into some problem or need slightly modified version of the 
  applet to fulfill your requirement, feel free to contact me. 
       

Software Requirements
---------------------
Any browser with Java 1.1 support and caching ability. 


Licensing and Distribution
--------------------------
The term "CacheURL" identifies release version 1.0 of CacheURL series.

The term "SHAREWARE version" identifies the complete package which 
include CacheURL's jar (class) file, readme file and other files 
included in the distribution package.

The term "SHAREWARE copy" identifies an instance of the SHAREWARE version.

The term "REGISTERED version" identifies a SHAREWARE version of CacheURL,
together with registered user information.

The term "REGISTERED copy" identifies an instance of the REGISTERED 
version.

No component part of CacheURL may be distributed individually, 
disassembled, copied, reverse engineered, or altered in any form. This
includes all elements in the CacheURL package.

1. SHAREWARE copies may be freely distributed by individual users for 
   trial and evaluation.

2. SHAREWARE copies may be uploaded to Bulletin Board Systems, FTP sites,
   Usenet newsgroups and any network sites providing its users with 
   access to download it for trial and evaluation purposes. 

3. SHAREWARE copies may NOT be distributed in CD-ROM disks, diskettes or 
   any other media, without express authorization of the author. 

4. SHAREWARE copies may NOT be distributed with any software package,
   or be systematically recommended to users of any software system
   or service, without express authorization of the author.

5. REGISTERED copies may only be distributed by the author of CacheURL.

6. The use of REGISTERED version must be restricted to the web site
   authorized by the author. 

6. Separate copies of the REGISTERED version must be obtained from the 
   author if CacheURL is intended to be used on several different web 
   sites.
   
The software remains the sole and exclusive property of the copyright 
holder.

This software has not undergone complete testing and may contain 
errors. It may not function properly and is subject to change or 
withdrawal at any time.

The author of this program accepts no responsibility for damages 
resulting from the use of this product and makes no warranty or 
representation, either express or implied, including but not limited 
to, any implied warranty of merchantability or fitness for a particular
purpose. This software is provided "AS IS", and you, its user, assume 
all risks when using it. 


Registration
------------
The shareware version of CacheURL is available for a 30 day evaluation 
period. If you decide to continue using the program after 30 days, you 
need to register the program by using one of the methods described below.
By registering the software, you are able to continue using it legally, 
and are supporting my efforts to continually develop innovative products 
to best serve your needs.

Registration can be performed in the following ways: 

* Register CacheURL (Product ID: 30676) online at RegSoft.net
  http://www.regsoft.net/purchase.php3?productid=30676 

* By sending 30 U.S. dollars by check. Payments must be made to "Waqas 
  Shafiq" and mailed together with Your E-mail Address, Company Name, Web 
  Site and Contact Name to: 
  
  Waqas Shafiq 
  B-119 Gulshan-E-Hadeed Phase I 
  Karachi - 75010 
  Pakistan 

  Your E-mail Address, Company Name, Web Site and Contact Name are
  required to provide the registered version of the applet. It is 
  imperative that I receive your E-mail address in order to fulfill 
  your order. 

  The registered version of the applet will be sent to you as an e-mail 
  attachment. 
        

Download
--------
You can download the latest version of CacheURL at the following URL:
http://wshafiq.webjump.com/CacheURL.html#Download

Also you can obtain CacheURL by sending an email to the author indicating
the web site where you intend to use the applet. 
       

Contact Me
----------
Send email to wshafiq@bigfoot.com 
Visit home page at: http://wshafiq.webjump.com/