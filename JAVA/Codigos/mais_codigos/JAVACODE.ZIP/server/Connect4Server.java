// Connect4Server Class
// Connect4Server.java

// All code graciously developed by Greg Turner. You have the right
// to reuse this code however you choose. Thanks Greg!

// Imports
class Connect4Server {
  public static void main(String args[]) {
    System.out.println("NetConnect4 server up and running...");
    new Connect4Daemon().start();
  }
}
