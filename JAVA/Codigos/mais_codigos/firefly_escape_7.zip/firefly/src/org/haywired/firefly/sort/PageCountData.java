package org.haywired.firefly.sort;

public class PageCountData {
  public int page;
  public int count;
  public PageCountData(int a, int b) { page = a; count = b; }
}
