var currTheme=0;
/*
*
*/
function setTool(tool){

var map=top.mapwindow.document.applets['mapApplet'].map;
map.setTool(tool);
}
/*
*
*/
function setApplet(){
top.mapwindow.document.mapApplet.width=100;
top.mapwindow.document.mapApplet.height=300;
}
/*
*
*/
function setVisible(lyrName){
var map=top.mapwindow.document.applets['mapApplet'].map;
var lyr=map.getLayer(lyrName);
lyr.visible=!lyr.visible;
map.repaintMap();
}
/*
*
*/
function setTheme(){
currTheme=(currTheme==0)?1:0;
top.mapwindow.document.mapApplet.map.setThematicMap(currTheme);
top.mapwindow.document.mapApplet.map.repaintMap();
}
/*
*
*/
function setLayer(t){

ind=t.selectedIndex;
lyrName=t.options[ind].text;

var map=top.mapwindow.document.mapApplet.map;
var lyr=map.getLayer(lyrName);
map.setActiveLayer(lyr);
}
/*
*
*/
function startSearch(bSearch){
                           
   var sQuery=top.attrib.controls.document.toolbar.srch.value;

   if((sQuery=="")&&(bSearch)){
       return false;
   }

   var map=top.mapwindow.document.mapApplet.map;

//get current layer
   ind=top.attrib.controls.document.toolbar.layers.selectedIndex;
   lyrName=top.attrib.controls.document.toolbar.layers.options[ind].text;
   var lyr=map.getLayer(lyrName);


   var recs=(bSearch)?lyr.doSearch('%'+ sQuery+'%'):lyr.getSelection();

   var recCount=(recs==null)?0:recs.size();

/*
  if (recCount==1){
       var rec = recs.elementAt(0);
       var s=lyr.getWebLink(rec);
       if(s!=""){
             window.open(s, "");
       }
  }else
*/

 if (recCount>0) {

 var mw=this.open("", "adata");

 mw.document.close();
 mw.document.open();

 mw.document.write('<HTML><HEAD>');

 mw.document.write(
  '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">'+
  '<LINK href="main.css" rel=STYLESHEET type=text/css></HEAD><BODY>');
// mw.document.writeln('<SCRIPT SRC="syd_main.js"></SCRIPT></HEAD><BODY><p>ddd</p>');


 mw.document.write(
  '<TABLE align=center cellspacing=0 cellpadding=5 border=1 class=remar>'+
  '<TBODY><TR>');

    var fieldCount = lyr.getFieldDefCount();

    for(var j=0; j<fieldCount; j++){
     s=lyr.getFieldDef(j).name;
     if ((s=="NAME")||(s=="URL")){
       mw.document.write('<TD>'+s+'</TD>');
     }
    }
       mw.document.write('</TR>');

    var s1='"'+lyr.getName()+'"';

    for(var i=0; i<recCount; i++) {
       var rec = recs.elementAt(i);
       mw.document.write('<TR>');

       for(var j=0; j<fieldCount; j++){
         //mw.document.write('<TD>tst</TD>');
         s=lyr.getFieldDef(j).name;
         if (s=="NAME"){
           s=rec.getField(j).toString();
           if (s==""){
             s='&nbsp;';
           }
             mw.document.write(
"<TD><A HREF='javascript:top.mapwindow.document.mapApplet.selectObject("+s1+","+rec.getId()+")'>"+s+"</A></TD>");

         }else if (s=="URL"){
           s=rec.getField(j).toString();

           mw.document.write('<TD>');

           if (s!=""){
              mw.document.write('<A HREF="'+s+'" TARGET="_blank">'+s+'&nbsp;</A>');
           }

           mw.document.write('&nbsp;</TD>');

         }
       }

       mw.document.write('</TR>');

     } //for

 mw.document.write('</TBODY></TABLE>');
 
 mw.document.write('</BODY></HTML>');
 mw.document.close;
 mw.focus();

  }

return false;
}