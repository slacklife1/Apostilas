/*
 * HasProperty.java
 *
 * Created on 12. August 2003, 17:22
 ***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************
 */

/**
 * for defining a filter, for SetListModel
 * @author  Peter Karich
 */
abstract public class HasProperty
{  protected String str,ID;
      
   abstract public boolean hasProperty(Object o);  
   
   public boolean equals(Object obj)
   { return ID.equals( ((HasProperty)obj).ID);
   }
}
