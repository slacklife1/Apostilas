/*
 * ListElement.java
 *
 * Created on 7. August 2003, 14:16
 ***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************
 */

/**
 * an List Element of ListPanels List for "Link Support";
 * it means that you can click an a list element and then set a special
 * object as link to this element
 *
 * @author  peter karich
 */
public interface ListElement extends java.io.Serializable
{
    
    /** set some new linkName to the data
     */
  //  public void setName(Object link);        
   // public Object getName();
    
    /** set some new data to the link
     */
    public void setLinkData(Object data);
    public Object getLinkData();        
    
    public String getLinkDataAsString();        
    public void setMarkedIndicies(int obj[]);
    
    /** for list model you have to overload String toString()
     */
    public String toString();
    
    /** for list model you have to overload boolean equals(Object o)
      */
    public boolean equals(Object o);
    
}
