/*
 * Leks.java
 *
 * Created on 5. August 2003, 14:15
 ***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************
 */

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import javax.swing.text.html.*;
import java.net.*;
import java.io.*;

/** its a little lexicon where you have keys and values
 *  mail: peat_hal@yahoo.de
 * @author  peter karich
 */
public class Leks extends JFrame implements ActionListener, KeyListener
{
    JSplitPane splitPane;
    Connection connection;
    LeksListPanel listPanel;
    JTextArea text;
    JButton button;
    
    /** Creates a new instance of Leks */
    public Leks() 
    {        
       text=new JTextArea();
       button=new JButton("save text");
   
        JMenuBar menuBar=new JMenuBar();
        JMenu menu=new JMenu("Datei");
       menu.setMnemonic('D');
        JMenuItem exit=new JMenuItem("exit"), save=new JMenuItem("save"),
                open=new JMenuItem("open"), print=new JMenuItem("print");
        exit.addActionListener(this);
        save.addActionListener(this);
        open.addActionListener(this);
        print.addActionListener(this);
        menu.add(open);
        menu.add(save);
        menu.add(print);        
        menu.add(exit);
        menuBar.add(menu);
        setJMenuBar(menuBar);
        
        setTitle("LEKS the best of it all");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Container cp=getContentPane();
        
        connection=new Connection();
        
        //init with textPanel
        connection.setOutput(new Consumer(text));
        
        listPanel=new LeksListPanel(connection);
       
        button.addActionListener(this);
        
        text.setEditable(true);
        text.addKeyListener(this);
        JPanel textPanel=new JPanel()
        {  public Insets getInsets()
           { return new Insets(10,10,10,10);
           }
        };
        textPanel.setLayout(new BorderLayout(5,5));
        textPanel.add(new JScrollPane(text),BorderLayout.CENTER);
        textPanel.add(button,BorderLayout.SOUTH);                
        
        splitPane=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,listPanel,textPanel);
        
        cp.add(splitPane);
        
        pack();
        setVisible(true);        
    }
    
    public static void main(String arg[])
    { try
      { new Leks();
      }
      catch(Exception exc)
      { exc.printStackTrace();       
      }
    }
 
    public void saveText()
    {  connection.refreshLinkData();
       button.setEnabled(false);
    }       
    
    /** Invoked when an action occurs.
     */
    public void actionPerformed(ActionEvent e)
    {  Object obj=e.getSource();
       
       if(obj instanceof JButton)
       { if( ((JButton)obj).getText().equals("save text"))
         { saveText();
         }         
       }       
       else if(obj instanceof JMenuItem)
       { JFileChooser fc=new JFileChooser();
         fc.setCurrentDirectory(new File(System.getProperty("user.dir")));
         String tmp;
           
         if( ((JMenuItem)obj).getText().equals("print"))
         { fc.showSaveDialog(this);
           
           File file=fc.getSelectedFile();
           if(file==null) return;
           if( (tmp=file.getAbsolutePath())!=null) listPanel.print(tmp);
         }
         if( ((JMenuItem)obj).getText().equals("save"))
         { fc.showSaveDialog(this);
           
           File file=fc.getSelectedFile();
           if(file==null) return;
           if( (tmp=file.getAbsolutePath())!=null) 
               listPanel.save(tmp);
         }
         else if( ((JMenuItem)obj).getText().equals("exit"))
         { exit();
         }
         else if( ((JMenuItem)obj).getText().equals("open"))
         { 
           fc.showOpenDialog(this);   
           File file=fc.getSelectedFile();   
           if(file==null) return;
           try
           { if( (tmp=file.getAbsolutePath())!=null) 
                 listPanel.open(tmp);
           }
           catch(FileNotFoundException exc)
           { listPanel.out("sorry there is no file "+file.getAbsolutePath());
           }
         }
         
       }//MenuItem
       
    }//actionPerformed
                
    
    public void exit()
    { System.exit(0);
    }
    
    /** Invoked when a key has been pressed.
     */
    public void keyPressed(KeyEvent e) 
    { if(e.isControlDown() && KeyEvent.getKeyText(e.getKeyCode()).equals("S"))
      { saveText();
      }
    }
    
    /** Invoked when a key has been released.
     */
    public void keyReleased(KeyEvent e)
    { button.setEnabled(true);
    }
    
    /** Invoked when a key has been typed.
     */
    public void keyTyped(KeyEvent e)    {      }
    
}

class Consumer implements ConsumerInterface
{
    JTextArea text;
    
    /** Creates a new instance of Consumer */
    public Consumer(JTextArea tex)
    { text=tex;
    }

    public Object getData()
    { return text.getText();
    }    
    
    public void setData(Object obj) 
    { String str;
      if(obj==null) str="";
      else str=(String)obj;
      text.setText(str);
    }
    
}

/*
 * try
       {  UIManager.setLookAndFeel(UIManager.getInstalledLookAndFeels()[1].getClassName());
          //"com.sun.java.swing.plaf.metal.MetalLookAndFeel");
       }  
       catch(Exception exc)
       { exc.printStackTrace();
         exit();
       }
 *
 *
 *
       System.out.println("hier");
       
       try
       { URL url=new URL("file://localhost/home/pet/test.html");
         //JEditorPane text=new JEditorPane();
         text.setPage(url);           
       }
       catch(Exception exc)
       { exc.printStackTrace();        
       }
       
 class DefaultHTMLListener implements HyperlinkListener 
    {
        
        //** Called when a hypertext link is updated.         *         * @param e the event responsible for the update         *         *
        public void hyperlinkUpdate(HyperlinkEvent e)
        { System.out.println(" now hyperlinked");
          
          String str= text.getText();
           int index=0;
           
           if( (index=str.indexOf("@see ")) >=0 )
           {  StringTokenizer st=new StringTokenizer(str.substring(index+4)," ", false);
              
              if(st.countTokens()==2)
              {  st.nextToken();
                 String tmp=st.nextToken();
                 if(tmp.endsWith(" ")) System.out.println("true");
                 System.out.println("/"+tmp+"/");
              }
              
           }
        }//h-update
        
    }
    
    */