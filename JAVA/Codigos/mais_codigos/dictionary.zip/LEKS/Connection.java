/*
 * Connection.java
 *
 * Created on 5. August 2003, 14:26
 ***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************
 */

//import javax.swing.JTextArea;

/** is a simple implementation of ConnectionInterface
 * it implements the communication between a JList and a JTextArea
 *
 * @author  peter karich
 */

public class Connection
{ //Object data, link;
    ListElement pElem;
    ConsumerInterface output;
   
    /** Creates a new instance of DefaultListCondition */
    public Connection()     
    { 
    }    
    
    public Connection(ListElement dat, ConsumerInterface lin)     
    { pElem=dat;
      output=lin;      
    }    
    
    public void setOutput(ConsumerInterface ou)
    { output=ou;
    }
    
    /** selecting element in the list, called if clicked (or other)
     *  and actualize the linked panel
     */
    public void setListElement(ListElement pEle)
    {  pElem=pEle;    
       if(output!=null) output.setData( pElem.getLinkData() );
    }  
    
    /** if you want to associate data in the linked panel with Listelement     
     */
    public void refreshLinkData()
    { if(pElem!=null)  pElem.setLinkData(output.getData() );
    }
    
    //public Object getData
    //public void setLinkData(ConsumerInterface lin)
    //{ output=lin;   if(pElem!=null)  pElem.setLinkData(output.getData() ); } 
    
}
