/*
 * Leksement.java
 *
 * Created on 26. August 2003, 09:46
 ***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************
 */

/** a single element of the list in leks
 *
 * @author  peter karich
 */
public class Eleksment implements ListElement
{     
    /** the link contains linkData
      */
    protected String linkData;
    //protected String dataText;
    protected String name;
    
    public Eleksment() 
    {
    }
    
   public Eleksment(String nam) 
    { name=nam;
    }
   
   public Eleksment(String nam, Object dat) 
    { name=nam;
      linkData=(String)dat;
    } 
    
    public void setName(Object nam)
    { nam=(String)nam;
    }  
    
    public void setLinkData(Object dat)
    { linkData=(String)dat;
    }    
    
    public String getLinkDataAsString() 
    { if(linkData==null) return "";
      return linkData;
    }
    
    public void setMarkedIndicies(int[] obj)
    { //implementation for highlighting the searchresults
    }
  
    public Object getName()
    { return name;
    }  
    
    public Object getLinkData()
    { return linkData;
    }
    
    public String toString()
    { return name;
    }
    
    public boolean equals(Object o)
    { if(o==this) return true;
      else if(o==null) return false;
      return name.equals( ((Eleksment)o).toString());    
    } 
        
}