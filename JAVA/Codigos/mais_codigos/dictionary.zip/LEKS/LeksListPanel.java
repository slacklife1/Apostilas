/*
 * LeksListPanel.java
 *
 * Created on 11. August 2003, 14:03
 ***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************
 */


import java.util.*;
import java.io.*; 
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.text.html.*;
import java.net.*;


/**
 * extends the ListPanel for the Leks application 
 * 
 * @author  peter karich
 */
public class LeksListPanel extends ListPanel
{  
    
    /** Creates a new instance of LeksListPanel */
    public LeksListPanel() 
    { this(new Connection());
    }
    
    public LeksListPanel(Connection c)
    { super(c); 
      setSize(300,200);
      setAutoScroll(true);
    }
    
    protected ListElement createInstance(String str)
    { return new Eleksment(str);
    }    
   
   public void print(String fileName)
  { try
    { FileWriter fos=new FileWriter(fileName);
      BufferedWriter oos=new BufferedWriter(fos);
      StringBuffer str=new StringBuffer();
      
      Iterator iter=lm.getElements().iterator();
      while(iter.hasNext())
      { ListElement obj=(ListElement)iter.next();
      
        str.setLength(0);      
        str.append(obj.toString());
        str.append("- ");
        str.append(obj.getLinkDataAsString().replace('\n',' '));
        str.append("## ");
        
        oos.write(str.toString());        
      }
      oos.flush();
      oos.close();         
    }
    catch(Exception exc)
    { out("fehler bei speicherung");
      exc.printStackTrace();
    }
  }
  
 
   protected void setLayout()
   {/* UIManager.LookAndFeelInfo lInfo[]=UIManager.getInstalledLookAndFeels();
    out(""+lInfo.length+" "+lInfo[0]+" "+lInfo[1]);*/
    buttonPanel.setLayout(new GridLayout(2,1));    
    radioPanel.setLayout(new GridLayout(4,1));
    radioPanel.setBorder(BorderFactory.createTitledBorder("filter"));
    //output.setEditable(false);
    
    addToButtonPanel("DEL",this);
    addToButtonPanel("SIZE",this);
    
    addButtonToRadioPanel("<RESET>", this);
    addButtonToRadioPanel("<FIND>", this);
    //addButtonToRadioPanel("<FIND >", this);
    addToRadioPanel("ignore case", this);
    addToRadioPanel("both sides", this);
     
    setLayout(new EasyGridLayout(300, 300));
    EasyGridConstraints egc=new EasyGridConstraints();
    Insets insets=new Insets(5,5,5,5);
    
    egc.x=0;
    egc.y=0;
    egc.width=210;
    egc.height=50;
    egc.fill=EasyGridConstraints.HORIZONTAL;
    egc.setInsets(insets);
    add(input,egc);
    
    egc.x=0;
    egc.y=50;
    egc.width=210;
    egc.height=200;
    egc.fill=EasyGridConstraints.BOTH;    
    egc.setInsets(insets);    
    add(scrollPanel,egc);  
    
    egc.x=210;
    egc.y=0;
    egc.width=90;
    egc.height=100;
    egc.fill=EasyGridConstraints.VERTICAL;    
    egc.setInsets(insets);
    add(radioPanel,egc);
    
    //there is a gap between radioPanel and buttonPanel
    
    egc.x=210;
    egc.y=250;
    egc.width=90;
    egc.height=50;
    egc.fill=EasyGridConstraints.VERTICAL;    
    egc.setInsets(insets);
    add(buttonPanel,egc);      
    
    egc.x=0;
    egc.y=250;
    egc.width=210;
    egc.height=50;
    egc.fill=EasyGridConstraints.HORIZONTAL;
    egc.setInsets(insets);
    add(output,egc);
  }
    
    
  /** Invoked when an action occurs.         
    */
  public void actionPerformed(ActionEvent e) 
  { Object obj=e.getSource();

    //insertation in the JList
    if(obj instanceof JTextField) 
    {   JTextField field=(JTextField)obj;
        String str=field.getText();             
    
       if( lm.add(createInstance(str))==false) 
       { out("konnte nicht hinzugef�gt werden");    
         return;
       }
       field.selectAll();
      /**this won't work cause str.equals(linkedobject) will call:
        * list.setSelectedValue(str,true);                  
        * the next line works cause instancelink.equals() is called:
        */
       setSelectedValue(createInstance(str));  
    }
    //remove an entry of JList
    else if(obj instanceof JButton)
    {  JButton tmpButton=(JButton)obj;
       String str=tmpButton.getText();
         
      if(str.equals("DEL"))
      {  int index=list.getSelectedIndex(); 
         
        if(index<0 || index>=lm.getSize()) return;
        lm.remove(index);
        //new selection
        setSelectedIndex(index);
      }        
      else if(str.equals("<FIND>"))
      { JRadioButton ignoreRadio=(JRadioButton)radioButtonMap.get("ignore case");
        JRadioButton bothRadio=(JRadioButton)radioButtonMap.get("both sides");
        
        lm.addFilter(new Search(input.getText(), ignoreRadio.isSelected(),
                                bothRadio.isSelected()));        
      
        lm.filter();
      }
      else if(str.equals("SIZE"))
      { out(" the size of the list: "+Integer.toString(lm.getSize()));
      }      
      else if(str.equals("<RESET>")) lm.removeAllFilter();   
       
      //now the code is neccessary cause the selected index will
      //exist also if the new filtered elements are less than the index position
      int sel=list.getSelectedIndex();
      //if(sel>=lm.getSize())  
      list.removeSelectionInterval(sel,sel);
    }
   
    
  }//actionPerformed

  
 /** this methode will called twice times, why??
  */
  public void valueChanged(ListSelectionEvent me)
  { int index=list.getSelectedIndex();
    JButton delButton=(JButton)buttonMap.get("DEL");
   // System.out.println(lm.getSize());
    
    if(index<0)
    { if(lm.getSize()<=0)
       { delButton.setEnabled(false);       
         return;
       }
       setSelectedIndex(0);
     }
     else if(index<lm.getSize())  
     { delButton.setEnabled(true);           
       setSelectedIndex(index);
     }
  }
  
class MyFilter extends HasProperty
{ 
    
     public MyFilter(String s, String id)  
     { str=s;
       ID=id;
     }
    
     public MyFilter(String s)  
     { str=s;
       ID=s;
     }
     
     public boolean hasProperty(Object obj)
     { if( obj.toString().startsWith(str)) return true;
       else return false;
     }
     
     public String toString()
     { return "filterString: "+str;
     }
     
}

class Search extends HasProperty
{
    boolean ignoreCase, both;
    
  /** if both ==true then it seaches the names and the linkdata
   *  if false it searches only the linkData
   */
    public Search(String s,boolean ignore, boolean bot)  
     { 
       ID="filter1@# "+s;
       ignoreCase=ignore;
       both=bot;
       if(ignoreCase) s=s.toLowerCase();
       
       str=s;
     }
    
     public boolean hasProperty(Object obj)
     { ListElement elem=(ListElement)obj;
       if(ignoreCase)
       { if(both && elem.toString().toLowerCase().indexOf(str)>=0) return true;
       
         if( elem.getLinkDataAsString().toLowerCase().indexOf(str)>=0) return true;        
       }
       else 
       { if( both && elem.toString().indexOf(str)>=0) return true;
         if( elem.getLinkDataAsString().indexOf(str)>=0) return true;
       }
       
       return false;
     }
          
     public String toString()
     { return " searchFilter with searchString: "+str;
     }
     
}


}

 /* in actionPerformed
    else if(obj instanceof JRadioButton)   
    {   //if one of the type radio button was changed
       Iterator iter=radioButtonMap.entrySet().iterator();
       
       while(iter.hasNext())
       { JRadioButton tmpRadio=(JRadioButton)obj;
         Map.Entry entry=(Map.Entry)iter.next();
        
         if( tmpRadio.getText().equals((String)entry.getKey()) ) 
         {  if(tmpRadio.isSelected()) lm.addFilter((MyFilter)entry.getValue());    
            else lm.removeFilter((MyFilter)entry.getValue());
            break;
         }        
      }       
      //now show all filtered elements
      lm.filter();
    }//else if
    */

/*  
    public void save(String fileName)
    { try
      {  FileWriter fw=new FileWriter(fileName);
         lm.removeAllFilter();
         fw.write( LeksLink.save(lm.getElements()));
    
         fw.flush();
         fw.close();    
      }
      catch(IOException exc)
      { exc.printStackTrace();
        System.exit(-1);
      }
    }
    
    public void open(String fileName) throws FileNotFoundException
    { try
      {  FileReader fr=new FileReader(fileName);
         BufferedReader br=new BufferedReader(fr);
         boolean newEntry=false;
         StringBuffer strBuf=new StringBuffer();
         String key="";
        
         boolean read=false;
         
         while(true)
         { String str=br.readLine();
           
           if(str==null) 
           { System.out.println(" sorry it doesn't look like a lekslink file");
             break;//the end of the stream is reached
           }
           System.out.println(str);
             
           if(str.startsWith(LeksLink.startFile))
           { read=true;
             lm.removeAllElements();
             lm.removeAllFilter();
             
             break;
           }          
         }
          
         while(read)
         { String str=br.readLine();
          
           if(str==null) 
           {
             if(key.length()>1) addEntry(key.substring(1), strBuf.toString());
             break;//the end of the stream is reached
           }
             
           if(str.startsWith(LeksLink.startKey) )
           { //System.out.println(strBuf.toString());
               int size=LeksLink.startKey.length();
             if(key.length()>size) addEntry(key.substring(size), strBuf.toString());
              
             strBuf.delete(0,  strBuf.length());
             key=str;               
           }
           else strBuf.append(str);                                   
         }         
         br.close();    
      }
      catch(IOException exc)
      { exc.printStackTrace();
        System.exit(-1);
      }
    }
 
    public boolean addEntry(String key,String text)
    { LeksLink ll=new LeksLink(key);
      ll.setText(text);
      return lm.add(ll);       
    }
     
    public Object getEntry(int index)
    { return lm.get(index);
    }
    
    */
