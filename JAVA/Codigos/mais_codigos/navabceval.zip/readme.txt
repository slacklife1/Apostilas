
FIRST READ AND ACCEPT THE LICENSE BEFORE USING THIS SOFTWARE.

--------------------------------

VISIT http://www.wyka-warzecha.com for the latest information about
other great products!

***********************************************************************************
These are some of the extra features you will be able to use with the full version!
Order the full version from our website at http://www.wyka-warzecha.com!

- Ability to set frame targets for links (so you can use frames)
- Ability to set the number of start animations (when the menu hilights back
  and forth as soon as it loads)
- Removal of the 'pausing' message
***********************************************************************************


Quick Docs:
-----------

To 'Install' this, simply unzip all the contents to a directory, and then 
open the 'index.htm' file in a browser, such as Internet Explorer.

You then will be able add menu items, by clicking on 'Add Menu Item'.

Once you have finished adding the menu items, click on 'main features'
to enter such information as the loading colors, text colors and more!

Advanced Features:
------------------

Advanced features include: adjusting the number of GIF animations and
menu item height. If you wish to change the menu animation (for example,
the 'fading' effect) use a graphics editor such as Paint Shop PRO 
to add extra menu items, and adjust the menu item height.

Sample HTML code:
-----------------

This is a sample of the HTML code that will be generated with the
software.

<APPLET CODE=NavABC.class width=375 height=24>
<PARAM NAME=copyright VALUE="http://www.wyka-warzecha.com">
<PARAM NAME=title1 VALUE="Item 1">
<PARAM NAME=title2 VALUE="Item 2">
<PARAM NAME=title3 VALUE="Item 3">
<PARAM NAME=title4 VALUE="Item 4">
<PARAM NAME=title5 VALUE="Item 5">
<PARAM NAME=link1 VALUE="http://">
<PARAM NAME=link2 VALUE="http://">
<PARAM NAME=link3 VALUE="http://">
<PARAM NAME=link4 VALUE="http://">
<PARAM NAME=link5 VALUE="http://">
<PARAM NAME=framelink1 VALUE="_self">
<PARAM NAME=framelink2 VALUE="_self">
<PARAM NAME=framelink3 VALUE="_self">
<PARAM NAME=framelink4 VALUE="_self">
<PARAM NAME=framelink5 VALUE="_self">
<PARAM NAME=numItems VALUE="5">
<PARAM NAME=aniMenu VALUE="menu.gif">
<PARAM NAME=background_color VALUE="8,0,49">
<PARAM NAME=loading_color VALUE="255,255,255">
<PARAM NAME=hiLiteColor VALUE="255,255,255">
<PARAM NAME=normalColor VALUE="200,200,200">
<PARAM NAME=mainFont VALUE="Arial,Bold,11">
<PARAM NAME=maxMenuItemWidth VALUE="75">
<PARAM NAME=playSound VALUE="click.au">
<PARAM NAME=timingValue VALUE="45">
<PARAM NAME=centerAdjustment VALUE="0">
<PARAM NAME=numFrames VALUE="8">
<PARAM NAME=menuItemHeight VALUE="24">
<PARAM NAME=noTimes VALUE="5">
<PARAM NAME=licensekey VALUE="DEMO KEY">
<B>Please enable Java in your browser. See <a href=http://www.wyka-warzecha.com>http://www.wyka-warzecha.com</a> for more details.</B>
</APPLET>