// File Sample1.java
// A simple example of how to use the MiniTemplator class.

import java.io.*;
import biz.source_code.miniTemplator.*;

public class Sample1 {

static final String TemplateFileName = "Sample1_template.htm";
static final String OutputFileName   = "Sample1_out.htm";

private static void generatePage() throws Exception {
   MiniTemplator t = new MiniTemplator(new File(TemplateFileName));
   t.setVariable ("animal1","fox");
   t.setVariable ("animal2","dog");
   t.addBlock ("block1");
   t.setVariable ("animal1","horse");
   t.setVariable ("animal2","cow");
   t.addBlock ("block1");
   t.generateOutput (new File(OutputFileName)); }

public static void main (String args[]) {
   try {
      generatePage(); }
    catch (Exception e) {
      e.printStackTrace(); }}

};
