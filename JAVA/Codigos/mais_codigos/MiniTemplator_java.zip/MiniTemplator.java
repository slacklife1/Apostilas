package biz.source_code.miniTemplator;

import java.io.*;
import java.util.*;

/**
* A compact template engine for HTML files.
*
* <p>
* Template syntax:<br>
* &nbsp;&nbsp;&nbsp;Variables:<br>
* &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<code>${VariableName}</code><br>
* &nbsp;&nbsp;&nbsp;Blocks:<br>
* &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<code>&lt;!-- $BeginBlock BlockName --&gt;</code><br>
* &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<code>&lt;!-- $EndBlock BlockName --&gt;</code><br>
*
* <p>
* Home page: <a href="http://www.source-code.biz/MiniTemplator" target="_top">www.source-code.biz/MiniTemplator</a><br>
* Copyright 2003: Christian d'Heureuse, Inventec Informatik AG, Switzerland. All rights reserved.<br>
* License: This module is released under the <a href="http://www.gnu.org/licenses/lgpl.html" target="_top">GNU/LGPL</a> license.
* This product is provided "as is" without warranty of any kind.<br>
*
* <p>
* Version history:<br>
* 2001-10-24 Christian d'Heureuse (chdh): VBasic version created.<br>
* 2003-03-25 chdh: Converted from VB to Java.<br>
* 2003-07-08 chdh: Method variableExists added.<br>
* 2003-07-16 chdh: Method setVariable changed to throw an exception when the variable does not exist (instead of returning false).<br>
* 2004-04-07 chdh: Parameter isOptional added to method setVariable.
*    Licensing changed from GPL to LGPL.<br>
* 2004-04-19 chdh: Methods blockExists, setVariableEsc and escapeHtml added.<br>
*/

public class MiniTemplator {

//--- exceptions -----------------------------------------------------

/**
* Thrown when a syntax error is encountered within the template.
*/
public static class TemplateSyntaxException extends Exception {
   public TemplateSyntaxException (String msg) {
      super ("Syntax error in template: " + msg); }};

/**
* Thrown when {@link MiniTemplator#setVariable(String,String,boolean) Minitemplator.setVariable}
* is called with a <code>variableName</code> that is not defined
* within the template and the <code>isOptional</code> parameter is <code>false</code>.
*/
public static class VariableNotDefinedException extends Exception {
   public VariableNotDefinedException (String variableName) {
      super ("Variable \"" + variableName + "\" not defined in template."); }};

/**
* Thrown when {@link MiniTemplator#addBlock Minitemplator.addBlock}
* is called with a <code>blockName</code> that is not defined
* within the template.
*/
public static class BlockNotDefinedException extends Exception {
   public BlockNotDefinedException (String blockName) {
      super ("Block \"" + blockName + "\" not defined in template."); }};

/**
* Thrown when an internal program logic error is detected.
* This should never happen.
*/
private static class ProgramLogicError extends Error {
   public ProgramLogicError (int errorId) {
      super ("Program logic error " + errorId + " in MiniTemplator class."); }};

//--- private constants ----------------------------------------------

private static final int maxNestingLevel = 50;   // maximum number of block nestings

//--- private nested classes -----------------------------------------

private static class VarTabRec {                 // variables table record structure
   String                varName;                // variable name
   String                varValue; };            // variable value, may be null
private static class VarRefTabRec {              // variable references table record structure
   int                   varNr;                  // variable nr
   int                   tPosBegin;              // template position of begin of variable reference
   int                   tPosEnd;                // template position of end of variable reference
   int                   blockNr;                // block nr of the (innermost) block that contains this variable reference
   int                   blockVarNr; };          // block variable nr. Index into BlockInstTab.BlockVarTab
private static class BlockTabRec {               // blocks table record structure
   String                blockName;              // block name
   int                   tPosBegin;              // template position of begin of block
   int                   tPosContentsBegin;      // template pos of begin of block contents
   int                   tPosContentsEnd;        // template pos of end of block contents
   int                   tPosEnd;                // template position of end of block
   int                   nestingLevel;           // block nesting level
   int                   parentBlockNr;          // block nr of parent block
   boolean               definitionIsOpen;       // true while $BeginBlock processed but no $EndBlock
   int                   instances;              // number of instances of this block
   int                   firstBlockInstNr;       // block instance nr of first instance of this block or -1
   int                   lastBlockInstNr;        // block instance nr of last instance of this block or -1
   int                   currBlockInstNr;        // current block instance nr, used during generation of output file
   int                   blockVarCnt;            // nr of variables in block
   int[]                 blockVarNrToVarNrMap;   // maps block variable numbers to variable numbers
   int                   firstVarRefNr; };       // variable reference nr of first variable of this block or -1
private static class BlockInstTabRec {           // block instances table record structure
   int                   blockNr;                // block number
   int                   instanceLevel;          // instance level of this block
      // InstanceLevel is an instance counter per block.
      // (In contrast to blockInstNr, which is an instance counter over the instances of all blocks)
   int                   parentInstLevel;        // instance level of parent block
   int                   nextBlockInstNr;        // pointer to next instance of this block or -1
      // Forward chain for instances of same block.
   String[]              blockVarTab; };         // block instance variables

//--- private variables ----------------------------------------------

private String           template;               // contents of the template file
private VarTabRec[]      varTab;                 // variables table, array index is variable nr
private int              varTabCnt;              // nr of entries used in VarTab
private HashMap          varNameToNrMap;         // maps variable names to variable numbers
private VarRefTabRec[]   varRefTab;              // variable references table
   // Contains an entry for each variable reference in the template. Ordered by templatePos.
private int              varRefTabCnt;           // nr of entries used in VarRefTab
private BlockTabRec[]    blockTab;               // Blocks table, array index is block nr
   // Contains an entry for each block in the template. Ordered by tPosBegin.
private int              blockTabCnt;            // nr of entries used in BlockTab
private HashMap          blockNameToNrMap;       // maps block names to block numbers
private int[]            openBlocksTab;
   // During parsing, this table contains the block numbers of the open parent blocks (nested outer blocks).
   // Indexed by the block nesting level.
private BlockInstTabRec[] blockInstTab;          // block instances table
   // This table contains an entry for each block instance that has been added.
   // Indexed by BlockInstNr.
private int              blockInstTabCnt;        // nr of entries used in BlockInstTab

private int              currentNestingLevel;    // current block nesting level during parsing

//--- constructors ---------------------------------------------------

/**
* Constructs a MiniTemplator object and reads the template from a file.
* @param templateFile a <code>file</code> that contains the template.
* @throws TemplateSyntaxException when a syntax error is detected within the template.
* @throws IOException when an i/o error occurs while reading the template.
*/
public MiniTemplator (File templateFile)
      throws IOException, TemplateSyntaxException {
   setTemplate (templateFile); }

/**
* Constructs a MiniTemplator object and reads the template from a
* character stream.
* @param templateReader a character stream (<code>reader</code>) that
*    contains the template.
* @throws TemplateSyntaxException when a syntax error is detected within the template.
* @throws IOException when an i/o error occurs while reading the template.
*/
public MiniTemplator (Reader templateReader)
      throws IOException, TemplateSyntaxException {
   setTemplate (templateReader); }

/**
* Constructs a MiniTemplator object; the template is passed as a
* string.
* @param template a <code>String</code> that contains the template.
* @throws TemplateSyntaxException when a syntax error is detected within the template.
*/
public MiniTemplator (String template)
      throws TemplateSyntaxException {
   setTemplate (template); }

//--- setTemplate ----------------------------------------------------

private void setTemplate (File templateFile)
      throws IOException, TemplateSyntaxException {
   Reader templateReader = null;
   try {
      templateReader = new FileReader(templateFile);
      setTemplate (templateReader); }
    finally {
      if (templateReader!=null) templateReader.close(); }}

private void setTemplate (Reader templateReader)
      throws IOException, TemplateSyntaxException {
   String s = readStreamIntoString(templateReader);
   setTemplate (s); }

private void setTemplate (String template)
      throws TemplateSyntaxException {
   this.template = template;
   parseTemplate();
   reset(); }

//--- template parsing -----------------------------------------------

private void parseTemplate()
      throws TemplateSyntaxException {
   initParsing();
   registerMainBlock();
   parseTemplateVariables();
   parseTemplateCommands();
   checkBlockDefinitionsComplete();
   associateVariablesWithBlocks(); }

private void initParsing() {
   varTab = new VarTabRec[256];
   varTabCnt = 0;
   varNameToNrMap = new HashMap();
   varRefTab = new VarRefTabRec[256];
   varRefTabCnt = 0;
   blockTab = new BlockTabRec[256];
   blockTabCnt = 0;
   blockNameToNrMap = new HashMap();
   openBlocksTab = new int[maxNestingLevel+1]; }

// Registers the main block.
// The main block is an implicitly defined block that covers the whole template.
private void registerMainBlock() {
   int blockNr = registerBlock("$InternalMainBlock$");
   BlockTabRec btr = blockTab[blockNr];
   btr.tPosBegin = 0;
   btr.tPosContentsBegin = 0;
   btr.tPosContentsEnd = template.length();
   btr.tPosEnd = template.length();
   btr.nestingLevel = 0;
   btr.parentBlockNr = -1;
   btr.definitionIsOpen = false;
   openBlocksTab[0] = blockNr;
   currentNestingLevel = 1; }

// Parses variable references within the template in the format "${VarName}" .
private void parseTemplateVariables()
      throws TemplateSyntaxException {
   int p = 0;
   while (true) {
      p = template.indexOf("${",p);
      if (p == -1) break;
      int p0 = p;
      p = template.indexOf("}",p);
      if (p == -1) throw new TemplateSyntaxException("Invalid variable reference in template at offset " + p0 + ".");
      p++;
      String varName = template.substring(p0+2,p-1).trim();
      if (varName.length() == 0) throw new TemplateSyntaxException("Empty variable name in template at offset " + p0 + ".");
      registerVariableReference (varName, p0, p); }}

private void registerVariableReference (String varName, int tPosBegin, int tPosEnd) {
   int varNr;
   varNr = lookupVariableName(varName);
   if (varNr == -1)
      varNr = registerVariable(varName);
   int varRefNr = varRefTabCnt++;
   if (varRefTabCnt > varRefTab.length)
      varRefTab = (VarRefTabRec[])resizeArray(varRefTab,2*varRefTabCnt);
   VarRefTabRec vrtr = new VarRefTabRec();
   varRefTab[varRefNr] = vrtr;
   vrtr.tPosBegin = tPosBegin;
   vrtr.tPosEnd = tPosEnd;
   vrtr.varNr = varNr; }

// Returns the variable number of the newly registered variable.
private int registerVariable (String varName) {
   int varNr = varTabCnt++;
   if (varTabCnt > varTab.length)
      varTab = (VarTabRec[])resizeArray(varTab,2*varTabCnt);
   VarTabRec vtr = new VarTabRec();
   varTab[varNr] = vtr;
   vtr.varName = varName;
   vtr.varValue = null;
   varNameToNrMap.put (varName.toUpperCase(), new Integer(varNr));
   return varNr; }

// Parses commands within the template in the format "<!-- $command parameters -->".
private void parseTemplateCommands()
      throws TemplateSyntaxException {
   int p = 0;
   while (true) {
      p = template.indexOf("<!--",p);
      if (p == -1) break;
      int p0 = p;
      p = template.indexOf("-->",p);
      if (p == -1) throw new TemplateSyntaxException("Invalid HTML comment in template at offset " + p0 + ".");
      p += 3;
      String cmdL = template.substring(p0+4,p-3);
      processTemplateCommand (cmdL, p0, p); }}

private void processTemplateCommand (String cmdL, int cmdTPosBegin, int cmdTPosEnd)
      throws TemplateSyntaxException {
   IntWrapper pW = new IntWrapper(0);
   StringWrapper cmdW = new StringWrapper();
   if (!parseWord(cmdL, pW, cmdW)) return;
   String cmd = cmdW.v;
   String parms = cmdL.substring(pW.v);
   /* select */
      if (cmd.equalsIgnoreCase("$BeginBlock"))
         processBeginBlockCmd (parms, cmdTPosBegin, cmdTPosEnd);
      else if (cmd.equalsIgnoreCase("$EndBlock"))
         processEndBlockCmd (parms, cmdTPosBegin, cmdTPosEnd);
      else {
         if (cmd.startsWith("$"))
            throw new TemplateSyntaxException("Unknown command \"" + cmd + "\" in template at offset " + cmdTPosBegin + "."); }}

// Processes the $BeginBlock command.
private void processBeginBlockCmd (String parms, int cmdTPosBegin, int cmdTPosEnd)
      throws TemplateSyntaxException {
   IntWrapper pW = new IntWrapper(0);
   StringWrapper blockNameW = new StringWrapper();
   if (!parseWord(parms,pW,blockNameW))
      throw new TemplateSyntaxException("Missing block name in $BeginBlock command in template at offset " + cmdTPosBegin + ".");
   if (parms.substring(pW.v).trim().length() != 0)
      throw new TemplateSyntaxException("Extra parameter in $BeginBlock command in template at offset " + cmdTPosBegin + ".");
   if (lookupBlockName(blockNameW.v) != -1)
      throw new TemplateSyntaxException("Multiple use of same block name in template at offset " + cmdTPosBegin + ".");
   int blockNr = registerBlock(blockNameW.v);
   BlockTabRec btr = blockTab[blockNr];
   btr.tPosBegin = cmdTPosBegin;
   btr.tPosContentsBegin = cmdTPosEnd;
   btr.nestingLevel = currentNestingLevel;
   btr.parentBlockNr = openBlocksTab[currentNestingLevel-1];
   openBlocksTab[currentNestingLevel] = blockNr;
   currentNestingLevel++;
   if (currentNestingLevel > maxNestingLevel)
      throw new TemplateSyntaxException("Block nesting overflow in template at offset " + cmdTPosBegin + "."); }

// Processes the $EndBlock command.
private void processEndBlockCmd (String parms, int cmdTPosBegin, int cmdTPosEnd)
      throws TemplateSyntaxException {
   IntWrapper pW = new IntWrapper(0);
   StringWrapper blockNameW = new StringWrapper();
   if (!parseWord(parms,pW,blockNameW))
      throw new TemplateSyntaxException("Missing block name in $EndBlock command in template at offset " + cmdTPosBegin + ".");
   if (parms.substring(pW.v).trim().length() != 0)
      throw new TemplateSyntaxException("Extra parameter in $EndBlock command in template at offset " + cmdTPosBegin + ".");
   int blockNr = lookupBlockName(blockNameW.v);
   if (blockNr == -1)
      throw new TemplateSyntaxException("Undefined block name \"" + blockNameW.v + "\" in $EndBlock command in template at offset " + cmdTPosBegin + ".");
   currentNestingLevel--;
   BlockTabRec btr = blockTab[blockNr];
   if (!btr.definitionIsOpen) throw new TemplateSyntaxException("Multiple $EndBlock command for block \"" + blockNameW.v + "\" in template at offset " + cmdTPosBegin + ".");
   if (btr.nestingLevel != currentNestingLevel) throw new TemplateSyntaxException("Block nesting level mismatch at $EndBlock command for block \"" + blockNameW.v + "\" in template at offset " + cmdTPosBegin + ".");
   btr.tPosContentsEnd = cmdTPosBegin;
   btr.tPosEnd = cmdTPosEnd;
   btr.definitionIsOpen = false; }

// Returns the block number of the newly registered block.
private int registerBlock (String blockName) {
   int blockNr = blockTabCnt++;
   if (blockTabCnt > blockTab.length)
      blockTab = (BlockTabRec[])resizeArray(blockTab,2*blockTabCnt);
   BlockTabRec btr = new BlockTabRec();
   blockTab[blockNr] = btr;
   btr.blockName = blockName;
   btr.definitionIsOpen = true;
   btr.instances = 0;
   btr.firstBlockInstNr = -1;
   btr.lastBlockInstNr = -1;
   btr.blockVarCnt = 0;
   btr.firstVarRefNr = -1;
   btr.blockVarNrToVarNrMap = new int[32];
   blockNameToNrMap.put (blockName.toUpperCase(), new Integer(blockNr));
   return blockNr; }

// Checks that all block definitions are closed.
private void checkBlockDefinitionsComplete()
      throws TemplateSyntaxException {
   for (int blockNr=0; blockNr<blockTabCnt; blockNr++) {
      BlockTabRec btr = blockTab[blockNr];
      if (btr.definitionIsOpen)
         throw new TemplateSyntaxException("Missing $EndBlock command in template for block \"" + btr.blockName + "\"."); }
   if (currentNestingLevel != 1)
      throw new TemplateSyntaxException("Block nesting level error at end of template."); }

// Associates variable references with blocks.
private void associateVariablesWithBlocks() {
   int varRefNr = 0;
   int activeBlockNr = 0;
   int nextBlockNr = 1;
   while (varRefNr < varRefTabCnt) {
      VarRefTabRec vrtr = varRefTab[varRefNr];
      int varRefTPos = vrtr.tPosBegin;
      int varNr = vrtr.varNr;
      if (varRefTPos >= blockTab[activeBlockNr].tPosEnd) {
         activeBlockNr = blockTab[activeBlockNr].parentBlockNr;
         continue; }
      if (nextBlockNr < blockTabCnt && varRefTPos >= blockTab[nextBlockNr].tPosBegin) {
         activeBlockNr = nextBlockNr;
         nextBlockNr++;
         continue; }
      BlockTabRec btr = blockTab[activeBlockNr];
      if (varRefTPos < btr.tPosBegin) throw new ProgramLogicError(1);
      int blockVarNr = btr.blockVarCnt++;
      if (btr.blockVarCnt > btr.blockVarNrToVarNrMap.length)
         btr.blockVarNrToVarNrMap = (int[])resizeArray(btr.blockVarNrToVarNrMap,2*btr.blockVarCnt);
      btr.blockVarNrToVarNrMap[blockVarNr] = varNr;
      if (btr.firstVarRefNr == -1) btr.firstVarRefNr = varRefNr;
      vrtr.blockNr = activeBlockNr;
      vrtr.blockVarNr = blockVarNr;
      varRefNr++; }}

//--- build up (template variables and blocks) ------------------------

/**
* Resets the MiniTemplator object to the initial state.
* All variable values are cleared and all added block instances are deleted.
* This method can be used to produce another HTML page with the same
* template. It is faster than creating another MiniTemplator object,
* because the template does not have to be parsed again.
*/
public void reset() {
   for (int varNr=0; varNr<varTabCnt; varNr++)
      varTab[varNr].varValue = null;
   for (int blockNr=0; blockNr<blockTabCnt; blockNr++) {
      BlockTabRec btr = blockTab[blockNr];
      btr.instances = 0;
      btr.firstBlockInstNr = -1;
      btr.lastBlockInstNr = -1; }
   if (blockInstTab == null)
      blockInstTab = new BlockInstTabRec[256];
   blockInstTabCnt = 0; }

/**
* Sets a template variable.
* For variables that are used in blocks, the variable value
* must be set before <code>addBlock</code> is called.
* @param variableName the name of the variable to be set.
* @param variableValue the new value of the variable. May be <code>null</code>.
* @throws VariableNotDefinedException when no variable with the
*    specified name exists in the template.
* @see MiniTemplator#setVariable(String,String,boolean)
*/
public void setVariable (String variableName, String variableValue)
      throws VariableNotDefinedException {
   setVariable (variableName, variableValue, false); }

/**
* Sets a template variable.
* For variables that are used in blocks, the variable value
* must be set before <code>addBlock</code> is called.
* @param variableName the name of the variable to be set.
* @param variableValue the new value of the variable. May be <code>null</code>.
* @param isOptional Specifies whether an exception should be thrown when the
*    variable does not exist in the template. If <code>isOptional</code> is
*    <code>false</code> and the variable does not exist, an exception is thrown.
* @throws VariableNotDefinedException when no variable with the
*    specified name exists in the template and <code>isOptional</code> is <code>false</code>.
*/
public void setVariable (String variableName, String variableValue, boolean isOptional)
      throws VariableNotDefinedException {
   int varNr = lookupVariableName(variableName);
   if (varNr == -1) {
      if (isOptional) return;
      throw new VariableNotDefinedException(variableName); }
   varTab[varNr].varValue = variableValue; }

/**
* Sets a template variable to an escaped string value.
* This method is identical to {@link #setVariable(String,String)}, except
* that the characters &lt;, &gt;, &amp;, ' and " of <code>variableValue</code> are
* replaced by their corresponding HTML/XML character entity codes.<br><br>
* For variables that are used in blocks, the variable value
* must be set before <code>addBlock</code> is called.
* @param variableName the name of the variable to be set.
* @param variableValue the new value of the variable. May be <code>null</code>.
*    Special HTML/XML characters are escaped.
* @throws VariableNotDefinedException when no variable with the
*    specified name exists in the template.
*/
public void setVariableEsc (String variableName, String variableValue)
      throws VariableNotDefinedException {
   setVariable (variableName, escapeHtml(variableValue), false); }

/**
* Sets a template variable to an escaped string value.
* This method is identical to {@link #setVariable(String,String,boolean)}, except
* that the characters &lt;, &gt;, &amp;, ' and " of <code>variableValue</code> are
* replaced by their corresponding HTML/XML character entity codes.<br><br>
* For variables that are used in blocks, the variable value
* must be set before <code>addBlock</code> is called.
* @param variableName the name of the variable to be set.
* @param variableValue the new value of the variable. May be <code>null</code>.
*    Special HTML/XML characters are escaped.
* @param isOptional Specifies whether an exception should be thrown when the
*    variable does not exist in the template. If <code>isOptional</code> is
*    <code>false</code> and the variable does not exist, an exception is thrown.
* @throws VariableNotDefinedException when no variable with the
*    specified name exists in the template and <code>isOptional</code> is <code>false</code>.
*/
public void setVariableEsc (String variableName, String variableValue, boolean isOptional)
      throws VariableNotDefinedException {
   setVariable (variableName, escapeHtml(variableValue), isOptional); }

/**
* Checks whether a variable with the specified name exists within the template.
* @param variableName the name of the variable.
* @return <code>true</code> if the variable exists.<br>
*    <code>false</code> if no variable with the specified name exists in the template.
*/
public boolean variableExists (String variableName) {
   return lookupVariableName(variableName) != -1; }

/**
* Adds an instance of a template block.
* If the block contains variables, these variables must be set
* before the block is added.
* If the block contains subblocks (nested blocks), the subblocks
* must be added before this block is added.
* @param blockName the name of the block to be added.
* @throws BlockNotDefinedException when no block with the specified name
*    exists in the template.
*/
public void addBlock (String blockName)
      throws BlockNotDefinedException {
   int blockNr = lookupBlockName(blockName);
   if(blockNr == -1)
      throw new BlockNotDefinedException(blockName);
   addBlockByNr (blockNr); }

private void addBlockByNr (int blockNr) {
   BlockTabRec btr = blockTab[blockNr];
   int blockInstNr = registerBlockInstance();
   BlockInstTabRec bitr = blockInstTab[blockInstNr];
   if (btr.firstBlockInstNr == -1)
      btr.firstBlockInstNr = blockInstNr;
   if (btr.lastBlockInstNr != -1)
      blockInstTab[btr.lastBlockInstNr].nextBlockInstNr = blockInstNr; // set forward pointer of chain
   btr.lastBlockInstNr = blockInstNr;
   bitr.blockNr = blockNr;
   bitr.instanceLevel = btr.instances++;
   if (btr.parentBlockNr == -1)
      bitr.parentInstLevel = -1;
    else
      bitr.parentInstLevel = blockTab[btr.parentBlockNr].instances;
   bitr.nextBlockInstNr = -1;
   if (btr.blockVarCnt > 0)
      bitr.blockVarTab = new String[btr.blockVarCnt];
   for (int blockVarNr=0; blockVarNr<btr.blockVarCnt; blockVarNr++) {  // copy instance variables for this block
      int varNr = btr.blockVarNrToVarNrMap[blockVarNr];
      bitr.blockVarTab[blockVarNr] = varTab[varNr].varValue; }}

// Returns the block instance number.
private int registerBlockInstance() {
   int blockInstNr = blockInstTabCnt++;
   if (blockInstTabCnt > blockInstTab.length)
      blockInstTab = (BlockInstTabRec[])resizeArray(blockInstTab,2*blockInstTabCnt);
   blockInstTab[blockInstNr] = new BlockInstTabRec();
   return blockInstNr; }

/**
* Checks whether a block with the specified name exists within the template.
* @param blockName the name of the block.
* @return <code>true</code> if the block exists.<br>
*    <code>false</code> if no block with the specified name exists in the template.
*/
public boolean blockExists (String blockName) {
   return lookupBlockName(blockName) != -1; }

//--- output generation ----------------------------------------------

/**
* Generates the HTML page and writes it into a file.
* @param outputFile a File to which the HTML page will be written.
* @throws IOException when an i/o error occurs while writing to the file.
*/
public void generateOutput (File outputFile)
      throws IOException {
   Writer outputWriter = null;
   try {
      outputWriter = new FileWriter(outputFile);
      generateOutput (outputWriter); }
    finally {
      if (outputWriter!=null) outputWriter.close(); }}

/**
* Generates the HTML page and writes it to a character stream.
* @param outputWriter a character stream (<code>writer</code>) to which
* the HTML page will be written.
* @throws IOException when an i/o error occurs while writing to the stream.
*/
public void generateOutput (Writer outputWriter)
      throws IOException {
   String s = generateOutput();
   outputWriter.write (s); }

/**
* Generates the HTML page and returns it as a string.
* @return A string that contains the generated HTML page.
*/
public String generateOutput() {
   if (blockTab[0].instances == 0)
      addBlockByNr (0);                          // add main block
   for (int blockNr=0; blockNr<blockTabCnt; blockNr++) {
      BlockTabRec btr = blockTab[blockNr];
      btr.currBlockInstNr = btr.firstBlockInstNr; }
   StringBuffer out = new StringBuffer();
   writeBlockInstances (out, 0, -1);
   return out.toString(); }

// Writes all instances of a block that are contained within a specific
// parent block instance.
// Called recursively.
private void writeBlockInstances (StringBuffer out, int blockNr, int parentInstLevel) {
   BlockTabRec btr = blockTab[blockNr];
   while (true) {
      int blockInstNr = btr.currBlockInstNr;
      if (blockInstNr == -1) break;
      BlockInstTabRec bitr = blockInstTab[blockInstNr];
      if (bitr.parentInstLevel < parentInstLevel)
         throw new ProgramLogicError(2);
      if (bitr.parentInstLevel > parentInstLevel) break;
      writeBlockInstance (out, blockInstNr);
      btr.currBlockInstNr = bitr.nextBlockInstNr; }}

private void writeBlockInstance (StringBuffer out, int blockInstNr) {
   BlockInstTabRec bitr = blockInstTab[blockInstNr];
   int blockNr = bitr.blockNr;
   BlockTabRec btr = blockTab[blockNr];
   int tPos = btr.tPosContentsBegin;
   int subBlockNr = blockNr + 1;
   int varRefNr = btr.firstVarRefNr;
   while (true) {
      int tPos2 = btr.tPosContentsEnd;
      int kind = 0;                              // assume end-of-block
      if (varRefNr != -1 && varRefNr < varRefTabCnt) { // check for variable reference
         VarRefTabRec vrtr = varRefTab[varRefNr];
         if (vrtr.tPosBegin < tPos) {
            varRefNr++;
            continue; }
         if (vrtr.tPosBegin < tPos2) {
            tPos2 = vrtr.tPosBegin;
            kind = 1; }}
      if (subBlockNr < blockTabCnt) {            // check for subblock
         BlockTabRec subBtr = blockTab[subBlockNr];
         if (subBtr.tPosBegin < tPos) {
            subBlockNr++;
            continue; }
         if (subBtr.tPosBegin < tPos2) {
            tPos2 = subBtr.tPosBegin;
            kind = 2; }}
      if (tPos2 > tPos)
         out.append (template.substring(tPos, tPos2));
      switch (kind) {
         case 0:                                 // end of block
            return;
         case 1: {                               // variable
            VarRefTabRec vrtr = varRefTab[varRefNr];
            if (vrtr.blockNr != blockNr)
               throw new ProgramLogicError(4);
            String variableValue = bitr.blockVarTab[vrtr.blockVarNr];
            if (variableValue != null)
               out.append (variableValue);
            tPos = vrtr.tPosEnd;
            varRefNr++;
            break; }
         case 2: {                               // sub block
            BlockTabRec subBtr = blockTab[subBlockNr];
            if (subBtr.parentBlockNr != blockNr)
               throw new ProgramLogicError(3);
            writeBlockInstances (out, subBlockNr, bitr.instanceLevel);  // recursive call
            tPos = subBtr.tPosEnd;
            subBlockNr++;
            break; }}}}

//--- name lookup routines -------------------------------------------

// Maps variable name to variable number.
// Returns -1 if the variable name is not found.
private int lookupVariableName (String varName) {
   Integer varNrWrapper = (Integer)varNameToNrMap.get(varName.toUpperCase());
   if (varNrWrapper == null) return -1;
   int varNr = varNrWrapper.intValue();
   return varNr; }

// Maps block name to block number.
// Returns -1 if the block name is not found.
private int lookupBlockName (String blockName) {
   Integer blockNrWrapper = (Integer)blockNameToNrMap.get(blockName.toUpperCase());
   if (blockNrWrapper == null) return -1;
   int blockNr = blockNrWrapper.intValue();
   return blockNr; }

//--- wrapper classes ------------------------------------------------

private static class IntWrapper {
   int v;
   IntWrapper() {}
   IntWrapper (int i) {v = i; }};

private static class StringWrapper {
   String v;
   StringWrapper() {};
   StringWrapper (String s) {v = s; }};

//--- general utility routines ---------------------------------------

// Reads the contents of a stream into a string.
private static String readStreamIntoString (Reader reader)
      throws IOException {
   StringBuffer s = new StringBuffer();
   char a[] = new char[0x10000];
   while (true) {
      int l = reader.read(a);
      if (l == -1) break;
      if (l <= 0) throw new IOException();
      s.append (a,0,l); }
   return s.toString(); }

// Reallocates an array with a new size and copies the contents
// of the old array to the new array.
private static Object resizeArray (Object oldArray, int newSize) {
   int oldSize = java.lang.reflect.Array.getLength(oldArray);
   Class elementType = oldArray.getClass().getComponentType();
   Object newArray = java.lang.reflect.Array.newInstance(
         elementType,newSize);
   int preserveLength = Math.min(oldSize,newSize);
   if (preserveLength > 0)
      System.arraycopy (oldArray,0,newArray,0,preserveLength);
   return newArray; }

// Parses the next word wW within the string s starting at position pW.
// Returns false when the end of the string is reached.
private static boolean parseWord (String s, IntWrapper pW, StringWrapper wW) {
   int p = pW.v;
   int sLen = s.length();
   while (p < sLen && Character.isWhitespace(s.charAt(p))) p++;
   if (p >= sLen) {pW.v = p; return false; }
   int p0 = p;
   while (p < sLen && !Character.isWhitespace(s.charAt(p))) p++;
   wW.v = s.substring(p0,p);
   pW.v = p;
   return true; }

/**
* Escapes special HTML characters.
* Replaces the characters &lt;, &gt;, &amp;, ' and " by their corresponding
* HTML/XML character entity codes.
* @param s the input string.
* @return the escaped output string.
*/
public static String escapeHtml (String s) {
   // (The code of this method is a bit redundant in order to optimize speed)
   if (s == null) return null;
   int sLength = s.length();
   boolean found = false;
   int p;
loop1:
   for (p=0; p<sLength; p++) {
      switch (s.charAt(p)) {
         case '<': case '>': case '&': case '\'': case '"': found = true; break loop1; }}
   if (!found) return s;
   StringBuffer sb = new StringBuffer(sLength+16);
   sb.append (s.substring(0,p));
   for (; p<sLength; p++) {
      char c = s.charAt(p);
      switch (c) {
         case '<':  sb.append ("&lt;"); break;
         case '>':  sb.append ("&gt;"); break;
         case '&':  sb.append ("&amp;"); break;
         case '\'': sb.append ("&#39;"); break;
         case '"':  sb.append ("&#34;"); break;
         default:   sb.append (c); }}
   return sb.toString(); }

};
