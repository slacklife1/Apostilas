package baklava;

public interface GlobalTimerObserver
{
	public void globalTimer(int timerId);
};

