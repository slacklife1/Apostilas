package sconeApplet;
import baklava.*;
import sconeApplet.*;
import java.awt.Event;

public class Player extends Sprite
{
	int bullets = 0;
	final int maxBullets = 3;
	SconeApplet game;	
	Sprite boom;

	public Player(SconeApplet gameArg) 
	{
		super(gameArg.p);
		game = gameArg;
		setImage(game.playerImage);
		setX(getPlayfield().getWidth() / 2);
		setY(getPlayfield().getHeight() - getHeight());
	}

	public void keyDown(Event evt, int key)
	{
		if (key == Event.LEFT) {
			setDirection(180);
			setSpeed(40);
		} else if (key == Event.RIGHT) {
			setDirection(0);
			setSpeed(40);
		} else if (key == ((int) ' ')) {
			if (bullets < maxBullets) {
				new Bullet(
					game, this, 
					getX() + getWidth() / 2 - 
						game.bulletImage.
						getWidth(getPlayfield()) / 2, 
					getY() - game.bulletImage.
						getHeight(getPlayfield()));
				bullets++;
			}
		}
	}
        public void onStep(int elapsed) {
                // The explosion tracks the scone.
                if (boom != null) {
                        boom.setX(getX());
                        boom.setY(getY());
                }
        }
	public void keyUp(Event evt, int key)
	{
		if ((key == Event.LEFT) || (key == Event.RIGHT)) {
			setSpeed(0);
		}
	}

	public void bulletLost()
	{
		bullets--;
	}
	public final int timerBoom = 0;
	public final int timerDie = 5;
	public void onGoodbye() {
		if (boom != null) {
			boom.goodbye();
		}	
	}
	public void timer(int timerId) {
		if (timerId == timerDie) {
			goodbye();	
			game.playerLost();
		} else if (timerId >= timerBoom) {
			int stage = timerId - timerBoom;
			if (stage == 0) {
				boom = new Sprite(getPlayfield());
				boom.setX(getX());
				boom.setY(getX());
			}
			boom.setImage(game.boomImages[stage]);
			stage++;
			setTimer(100, timerBoom + stage);	
		}
	}
	public void bombed() {
		setTimer(0, timerBoom);
	}
}

