package sconeApplet;
import baklava.*;
import sconeApplet.*;

public class Shield extends Sprite
{
	SconeApplet game;	
	Player player;	

	// For comparison purposes.
	Class sconeClass;
	Class bulletClass;
	Class bombClass;
	
	public Shield(SconeApplet gameArg,
			int x, int y) 
	{
		super(gameArg.p);

		game = gameArg;

		try {
			sconeClass = Class.forName("sconeApplet.Scone");
			bulletClass = Class.forName("sconeApplet.Bullet");
			bombClass = Class.forName("sconeApplet.Bomb");
		} catch (Exception e) { };
		setX(x);
		setY(y);
		setImage(game.shieldImage);
	}
	
	public void collisionWith(Sprite s) {
		if (s.getClass() == sconeClass) {
			// All shields disappear.
			getPlayfield().goodbyeAll(getClass());
		} else if (s.getClass() == bombClass) {
			// Disappear.
			goodbye();	
			s.goodbye();
		} else if (s.getClass() == bulletClass) {
			// Disappear.
			goodbye();	
			s.goodbye();
		}
	}	
	
	public void collisionEdge(int edge) {
		goodbye();
	}
};

