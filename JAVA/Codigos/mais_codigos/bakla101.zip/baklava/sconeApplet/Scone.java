package sconeApplet;
import baklava.*;
import sconeApplet.*;

public class Scone extends Sprite
{
	Thread engine = null;
	SconeApplet game;
	boolean dying = false;
	// A timer we set to drop the next bomb.
	static final int timerBomb = 0;
	// Timers we set to swing our feet. 
	static final int timerSwingRight = 1;
	static final int timerSwingLeft = 2;
	// A timer we set to move down for a while, then right.
	static final int timerDownRight = 3;
	// A timer we set to turn right.
	static final int timerRight = 4;
	// A timer we set to move down for a while, then left.
	static final int timerDownLeft = 5;
	// A timer we set to turn left after moving down for a while.
	static final int timerLeft = 6;
	// A timer the game sets to ask the scone to change its speed.
	// public so the game object can see it.
	public static final int timerSpeed = 7;
	// A timer we set to begin an explosion sequence.
	// Actually this one keeps on incrementing until...
	static final int timerBoom = 8;
	// ... we get to this, and then it's all over.
	static final int timerDie = timerBoom + 5;

	// A sprite we use for the explosion when hit.
	Sprite boom;

	public Scone(SconeApplet gameArg, 
		int xArg, 
		int yArg)
	{
		super(gameArg.p);
		game = gameArg;
		setX(xArg);
		setY(yArg);
		setImage(game.sconeImages[0]);
		setDirection(0);
		setSpeed(20);
		setBombTimer();
		setTimer(1000, timerSwingLeft);
	}
	public void collisionEdge(int edge) {
		// All of the scones need to change direction together,
		// so we'll invoke methods in the game object to do that.
		if (edge == edgeLeft) {
			// Back off.
			setX(0);
			// Let the game know that a scone has hit the edge.
			game.contactLeft();
		} else if (edge == edgeRight) {
			// Back off.
			setX(getPlayfield().getWidth() - getWidth());
			// Let the game know that a scone has hit the edge.
			game.contactRight();
		} else if (edge == edgeBottom) {
			game.landing();
		}
	}
	public void shot() {
		if (!dying) {
			dying = true;
			// ASAP
			setTimer(0, timerBoom);
		}
	}
	public void setBombTimer()
	{
		setTimer(game.getBombDelay(), timerBomb);
	}
	public void onGoodbye()
	{
		if (boom != null) {
			// Dismiss the explosion, too.
			boom.goodbye();	
		}
	}
	public void onStep(int elapsed) {
		// The explosion tracks the scone.
		if (boom != null) {
			boom.setX(getX());
			boom.setY(getY());
		}
	}
	public void timer(int timerId) {
		if (timerId == timerSwingLeft) {
			setImage(game.sconeImages[1]);
			setTimer(1000, timerSwingRight);
		} else if (timerId == timerSwingRight) {
			setImage(game.sconeImages[0]);
			setTimer(1000, timerSwingLeft);
		} else if (timerId == timerDownLeft) {
			setDirection(90);
			setTimer(500, timerLeft);
		} else if (timerId == timerLeft) {
			setDirection(180);
		} else if (timerId == timerDownRight) {
			setDirection(90);
			setTimer(500, timerRight);
		} else if (timerId == timerRight) {
			setDirection(0);
		} else if (timerId == timerBomb) {
			new Bomb(game, 
				getX() + getWidth() / 2 -
					game.bombImage.getWidth(getPlayfield()) / 2, 
				getY() + game.bombImage.getHeight(getPlayfield()));
			setBombTimer();		
		} else if (timerId == timerSpeed) {
			setSpeed(game.getSconeSpeed());
		} else if (timerId == timerDie) {
			goodbye();	
			game.sconeLost();
		} else if (timerId >= timerBoom) {
			int stage = timerId - timerBoom;
			if (stage == 0) {
				boom = new Sprite(getPlayfield());
				// The explosion covers the scone (partially)
				boom.setX(getX());
				boom.setY(getY());
			}
			boom.setImage(game.boomImages[stage]);	
			stage++;
			setTimer(200, timerBoom + stage);	
		}
	}
}

