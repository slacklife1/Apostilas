package sconeApplet;
import baklava.*;
import sconeApplet.*;

public class Ufo extends Sprite
{
	Thread engine = null;
	SconeApplet game;
	boolean dying = false;
	// A timer we set to begin an explosion sequence.
	// Actually this one keeps on incrementing until...
	static final int timerBoom = 0;
	// ... we get to this, and then it's all over.
	static final int timerDie = timerBoom + 5;

	// A sprite we use for the explosion when hit.
	Sprite boom;

	public Ufo(SconeApplet gameArg)
	{
		super(gameArg.p);
		game = gameArg;
		setX(0);
		setY(0);
		setImage(game.ufoImage);
		setDirection(0);
		if (Math.random() > .5) {
			setSpeed(60);
		} else {
			setSpeed(40);
		}
	}
	public void collisionEdge(int edge) {
		if (edge == edgeRight) {
			// Time to go away.
			goodbye();
		}
	}
	public void shot() {
		if (!dying) {
			dying = true;
			game.score(500);
			// ASAP
			setTimer(0, timerBoom);
		}
	}
	public void onGoodbye()
	{
		if (boom != null) {
			// Dismiss the explosion, too.
			boom.goodbye();	
		}
	}
	public void onStep(int elapsed) {
		// The explosion tracks the ufo.
		if (boom != null) {
			boom.setX(getX());
			boom.setY(getY());
		}
	}
	public void timer(int timerId) {
		if (timerId == timerDie) {
			goodbye();	
		} else if (timerId >= timerBoom) {
			int stage = timerId - timerBoom;
			if (stage == 0) {
				boom = new Sprite(getPlayfield());
				// The explosion covers the UFO (partially)
				boom.setX(getX());
				boom.setY(getY());
			}
			boom.setImage(game.boomImages[stage]);	
			stage++;
			setTimer(200, timerBoom + stage);	
		}
	}
}

