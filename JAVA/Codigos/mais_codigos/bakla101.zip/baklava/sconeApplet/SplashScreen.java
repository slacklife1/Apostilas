package sconeApplet;
import baklava.*;
import java.awt.*;
import sconeApplet.*;

public class SplashScreen extends Sprite
{
	private SconeApplet game;
	public SplashScreen(SconeApplet gameArg, Image imageArg)
	{
		super(gameArg.p);
		game = gameArg;
		// Stop any global timers so UFOs don't appear
		getPlayfield().clearGlobalTimers();
		// Very important: let baklava know it doesn't have
		// to try to calculate non-square collisions with 
		// this large image
		setRectangular(true);
		// Now it's safe to call setImage()
		setImage(imageArg);
	}
	public void mouseDown(Event evt, int x, int y)
	{
		goodbye();
		game.startGame();
	}
};

