package sconeApplet;
import baklava.*;
import sconeApplet.*;

public class Bullet extends Sprite
{
	SconeApplet game;	
	Player player;	

	// For comparison purposes.
	Class sconeClass;
	Class ufoClass;
	
	public Bullet(SconeApplet gameArg, Player playerArg,
			int x, int y) 
	{
		super(gameArg.p);

		game = gameArg;
		player = playerArg;
		try {
			sconeClass = Class.forName("sconeApplet.Scone");
			ufoClass = Class.forName("sconeApplet.Ufo");
		} catch (Exception e) { };
		setX(x);
		setY(y);
		setImage(game.bulletImage);
		setDirection(270);
		setSpeed(80);
	}
	
	public void collisionWith(Sprite s) {
		// Make sure we hit a scone, not something else.
		if (s.getClass() == sconeClass) {
			// Cast the sprite to a scone...	
			Scone scone = (Scone) s;
			// and let the scone know the bad news
			scone.shot();
			// Now go away
			goodbye();
		} else if (s.getClass() == ufoClass) {
			// Cast the sprite to a ufo...	
			Ufo ufo = (Ufo) s;
			// and let the ufo know the bad news
			ufo.shot();
			// Now go away
			goodbye();
		}
	}	
	
	public void collisionEdge(int edge) {
		goodbye();
	}

	public void onGoodbye() {
		player.bulletLost();
	}
};

