package sconeApplet;
import baklava.*;
import sconeApplet.*;

public class Bomb extends Sprite
{
	SconeApplet game;
	
	// For comparison purposes.
	Class playerClass;

	public Bomb(SconeApplet gameArg, int x, int y) {
		super(gameArg.p);
		try {
			playerClass = Class.forName("sconeApplet.Player");
		} catch (Exception e) { };
		game = gameArg;
		setX(x);
		setY(y);
		setImage(game.bombImage);
		setDirection(90);
		setSpeed(40);
	}
	
	public void collisionWith(Sprite s) {
		// Make sure we hit a player, not something else.
		if (s.getClass() == playerClass) {
			// Cast the sprite to a player...	
			Player p = (Player) s;
			// and let the player know the bad news
			p.bombed();
			// Now go away
			goodbye();
		}
	}	
	
	public void collisionEdge(int edge) {
		goodbye();
	}
};

