/**
 *
 * @author  Rustam M. Bunyadov
 * Engineer Developer
 * R.I.S.K. Company
 * rustamb@risk.az
 */

import javax.swing.*;
import java.io.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.image.*;

public class FSTableCellRenderer extends JLabel implements TableCellRenderer {
    
    String iconsFolder = "icons/";
    Icon iconDIR = new ImageIcon(iconsFolder + "dir.png");
    Icon upDIR = new ImageIcon(iconsFolder + "up.png");
    Icon iconMP3 = new ImageIcon(iconsFolder + "sound.png");
    Icon iconWAV = new ImageIcon(iconsFolder + "sound.png");
    Icon iconTXT = new ImageIcon(iconsFolder + "unknown.png");
    Icon iconXLS = new ImageIcon(iconsFolder + "excel.png");
    Icon iconXLT = new ImageIcon(iconsFolder + "excelt.png");
    Icon iconZIP = new ImageIcon(iconsFolder + "zip.png");
    Icon iconRAR = new ImageIcon(iconsFolder + "unknown.png");
    Icon iconTARGZ = new ImageIcon(iconsFolder + "unknown.png");
    Icon iconSH = new ImageIcon(iconsFolder + "unknown.png");
    Icon iconDOC = new ImageIcon(iconsFolder + "word.png");
    Icon iconPDF = new ImageIcon(iconsFolder + "pdf.png");
    Icon iconBMP = new ImageIcon(iconsFolder + "unknown.png");
    Icon iconJPG = new ImageIcon(iconsFolder + "unknown.png");
    Icon iconHTML = new ImageIcon(iconsFolder + "htm.png");
    Icon iconHTM = new ImageIcon(iconsFolder + "htm.png");
    Icon iconRTF = new ImageIcon(iconsFolder + "unknown.png");
    Icon iconAVI = new ImageIcon(iconsFolder + "unknown.png");
    Icon iconMPEG = new ImageIcon(iconsFolder + "unknown.png");
    Icon iconMOV = new ImageIcon(iconsFolder + "unknown.png");
    Icon iconJAVA = new ImageIcon(iconsFolder + "unknown.png");
    Icon iconCLASS = new ImageIcon(iconsFolder + "unknown.png");
    Icon iconXML = new ImageIcon(iconsFolder + "unknown.png");
    Icon iconUNKNOWN = new ImageIcon(iconsFolder + "unknown.png");
    
    
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        File mf = (File)(table.getModel().getValueAt(row, 0));
        
        if (mf.isDirectory()) {
            this.setFont(new Font("Arial", Font.BOLD, 12));
            if (column == 0)
                if (!value.toString().equals(".."))
                    this.setIcon(iconDIR);
                else this.setIcon(upDIR);
            else this.setIcon(null);
        }
        else {
            String fileName  = mf.getName().toLowerCase();
            this.setFont(new Font("Arial", Font.PLAIN, 12));
            if (column == 0) {
                if (fileName.endsWith(".mp3")) this.setIcon(iconMP3);
                else if (fileName.endsWith(".wav")) this.setIcon(iconWAV);
                else if (fileName.endsWith(".txt")) this.setIcon(iconTXT);
                else if (fileName.endsWith(".xls")) this.setIcon(iconXLS);
                else if (fileName.endsWith(".xlt")) this.setIcon(iconXLT);
                else if (fileName.endsWith(".zip")) this.setIcon(iconZIP);
                else if (fileName.endsWith(".rar")) this.setIcon(iconRAR);
                else if (fileName.endsWith(".tar.gz")) this.setIcon(iconTARGZ);
                else if (fileName.endsWith(".sh")) this.setIcon(iconSH);
                else if (fileName.endsWith(".doc")) this.setIcon(iconDOC);
                else if (fileName.endsWith(".pdf")) this.setIcon(iconPDF);
                else if (fileName.endsWith(".bmp")) this.setIcon(iconBMP);
                else if (fileName.endsWith(".jpg")) this.setIcon(iconJPG);
                else if (fileName.endsWith(".html")) this.setIcon(iconHTML);
                else if (fileName.endsWith(".htm")) this.setIcon(iconHTM);
                else if (fileName.endsWith(".rtf")) this.setIcon(iconRTF);
                else if (fileName.endsWith(".avi")) this.setIcon(iconAVI);
                else if (fileName.endsWith(".mpeg")) this.setIcon(iconMPEG);
                else if (fileName.endsWith(".mov")) this.setIcon(iconMOV);
                else if (fileName.endsWith(".java")) this.setIcon(iconJAVA);
                else if (fileName.endsWith(".class")) this.setIcon(iconCLASS);
                else if (fileName.endsWith(".xml")) this.setIcon(iconXML);
                else this.setIcon(iconUNKNOWN);
            }
            else this.setIcon(null);
        }
        
        this.setText(value.toString());
        
        if (isSelected) {
            this.setBackground(new Color(120, 50, 200));
            this.setForeground(Color.WHITE);
        }
        else {
            if (row % 2 == 0) this.setBackground(Color.WHITE);
            else this.setBackground(new Color(240, 240, 240));
            this.setForeground(Color.BLACK);
        }
        
        if (column == 1) this.setHorizontalAlignment(JLabel.RIGHT);
        else this.setHorizontalAlignment(JLabel.LEFT);
        
        this.setOpaque(true);
        
        return this;
    }
    
}