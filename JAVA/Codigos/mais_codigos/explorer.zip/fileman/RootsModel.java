/**
 *
 * @author  Rustam M. Bunyadov
 * Engineer Developer
 * R.I.S.K. Company
 * rustamb@risk.az
 */

import java.io.*;
import javax.swing.*;
import javax.swing.event.*;

public class RootsModel implements ComboBoxModel {
    Object selectedItem;
    
    private File[] rootsList;
    
    public RootsModel() {
        rootsList = File.listRoots();
        selectedItem = rootsList[0];
    }
    
    public void addListDataListener(ListDataListener l) {
    }
    
    public Object getElementAt(int index) {
        return rootsList[index];
    }
    
    public Object getSelectedItem() {
        return selectedItem;
    }
    
    public int getSize() {
        return rootsList.length;
    }
    
    public void removeListDataListener(ListDataListener l) {
    }
    
    public void setSelectedItem(Object anItem) {
        selectedItem = anItem;
    }
    
}