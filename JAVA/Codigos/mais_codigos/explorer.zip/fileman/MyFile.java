/**
 *
 * @author  Rustam M. Bunyadov
 * Engineer Developer
 * R.I.S.K. Company
 * rustamb@risk.az
 */

import java.io.*;

public class MyFile extends File {
    boolean isParent = false;
    
    public MyFile(String s) {
        super(s);
    }
    
    public MyFile(File f) {
        super(f.getAbsolutePath());
    }

    public MyFile(File f, boolean isParent) {
        super(f.getAbsolutePath());
        this.isParent = isParent;
    }
    
    public String toString() {
        if (!isParent) return super.getName();
        else return "..";
    }
}