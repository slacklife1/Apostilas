Multiplatform file manager with all basic features
like copy, move, rename, delete, mkdir, create dir.
Two paned interface with detail file and folder view.
Tested on both windows and *nix platforms.
In feature releases FTP connect and file search
will be also available.