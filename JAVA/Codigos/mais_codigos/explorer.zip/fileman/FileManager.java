/**
 *
 * @author  Rustam M. Bunyadov
 * Engineer Developer
 * R.I.S.K. Company
 * rustamb@risk.az
 */

import util.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.io.*;
import java.util.*;
import javax.swing.border.*;

public class FileManager extends JFrame implements ActionListener {
    private JLabel leftPath = new JLabel("---");
    private JLabel rightPath = new JLabel("---");
    
    private CustomTable leftTable;
    private CustomTable rightTable;
    
    private JComboBox leftRoots;
    private JComboBox rightRoots;
    
    /** Creates a new instance of FileManager */
    public FileManager() {
        JFrame frame = new JFrame();
        frame.setUndecorated(true);
        
        JLabel lbl1 = new JLabel("JExplorer 3");
        lbl1.setOpaque(true);
        lbl1.setBackground(new Color(250, 220, 80));
        lbl1.setForeground(Color.BLUE);
        lbl1.setHorizontalAlignment(JLabel.CENTER);
        lbl1.setVerticalAlignment(JLabel.CENTER);
        lbl1.setFont(new Font("Arial", Font.BOLD, 36));
        
        JLabel lbl2 = new JLabel("loading...");
        lbl2.setOpaque(true);
        lbl2.setBackground(Color.WHITE);
        lbl2.setForeground(Color.BLUE);
        lbl2.setVerticalAlignment(JLabel.BOTTOM);
		lbl2.setHorizontalAlignment(JLabel.CENTER);
        
        JProgressBar pb = new JProgressBar(1, 44);
        pb.setForeground(new Color(120, 50, 200));
        
        Container preCont = frame.getContentPane();
        preCont.setLayout(new BorderLayout());
        
        JPanel jp = new JPanel();
        jp.setLayout(new BorderLayout());
        jp.add(lbl1, BorderLayout.CENTER);
        jp.add(lbl2, BorderLayout.SOUTH);
        
        preCont.add(jp, BorderLayout.CENTER);
        preCont.add(pb, BorderLayout.SOUTH);
        
        frame.setSize(new Dimension(300, 200));
        frame.setResizable(false);
        frame.setLocationRelativeTo(this);
        frame.show();
        
        pb.setValue(1);
        leftRoots = new JComboBox(new RootsModel());
        pb.setValue(2);
        leftRoots.addItemListener(new RootsListener());
        pb.setValue(3);
        rightRoots = new JComboBox(new RootsModel());
        pb.setValue(4);
        rightRoots.addItemListener(new RootsListener());
        pb.setValue(5);
        FSTableModel leftModel = new FSTableModel(new File("/"));
        pb.setValue(6);
        leftTable = new CustomTable(new TableSorter(leftModel));
        pb.setValue(7);
        FSTableModel rightModel = new FSTableModel(new File("/"));
        pb.setValue(8);
        rightTable = new CustomTable(new TableSorter(rightModel));
        pb.setValue(9);
        leftTable.setName("leftTable");
        pb.setValue(10);
        rightTable.setName("rightTable");
        
        pb.setValue(11);
        Container con = getContentPane();
        pb.setValue(12);
        con.setLayout(new BorderLayout());
        pb.setValue(13);
        JPanel topPane = new JPanel();
        pb.setValue(14);
        topPane.setLayout(new BorderLayout());
        pb.setValue(15);
        MainToolbar mt = new MainToolbar();
        pb.setValue(16);
        mt.addActionListener(this);
        pb.setValue(17);
        topPane.add(mt);
        pb.setValue(18);
        JPanel leftPane = new JPanel();
        pb.setValue(19);
        leftPane.setLayout(new BorderLayout());
        pb.setValue(20);
        JPanel leftTopPane = new JPanel();
        pb.setValue(21);
        leftTopPane.setLayout(new BorderLayout());
        pb.setValue(22);
        leftTopPane.add(leftRoots, BorderLayout.WEST);
        pb.setValue(23);
        leftTopPane.add(leftPath, BorderLayout.CENTER);
        pb.setValue(24);
        leftPane.add(leftTopPane, BorderLayout.NORTH);
        pb.setValue(25);
        leftPane.add(new JScrollPane(leftTable), BorderLayout.CENTER);
        pb.setValue(26);
        JPanel rightPane = new JPanel();
        pb.setValue(27);
        rightPane.setLayout(new BorderLayout());
        pb.setValue(28);
        JPanel rightTopPane = new JPanel();
        pb.setValue(29);
        rightTopPane.setLayout(new BorderLayout());
        pb.setValue(30);
        rightTopPane.add(rightRoots, BorderLayout.WEST);
        pb.setValue(31);
        rightTopPane.add(rightPath, BorderLayout.CENTER);
        
        pb.setValue(32);
        rightPane.add(rightTopPane, BorderLayout.NORTH);
        pb.setValue(33);
        rightPane.add(new JScrollPane(rightTable), BorderLayout.CENTER);
        pb.setValue(34);
        JPanel bottomPane = new JPanel();
        pb.setValue(35);
        bottomPane.setLayout(new BorderLayout());
        pb.setValue(36);
        JSplitPane middlePane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPane, rightPane);
        pb.setValue(37);
        middlePane.setOneTouchExpandable(true);
        pb.setValue(38);
        con.add(topPane, BorderLayout.NORTH);
        
        pb.setValue(39);
        con.add(middlePane, BorderLayout.CENTER);
        pb.setValue(40);
        con.add(bottomPane, BorderLayout.SOUTH);
        pb.setValue(41);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        pb.setValue(42);
        pack();
        pb.setValue(43);
        Runnable runner = new FrameShower(this);
        pb.setValue(44);
        frame.dispose();
        EventQueue.invokeLater(runner);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new FileManager();
    }
    
    public class TableKeyListener implements KeyListener {
        
        public void keyPressed(KeyEvent e) {
            JTable activeTable = ((JTable)(e.getSource()));
            int[] selectedRows;
            selectedRows = activeTable.getSelectedRows();
            int keyCode = e.getKeyCode();
            File root = (File)(activeTable.getModel().getValueAt(0,-1));
            File parent = root.getParentFile();
            
            JLabel activePath;
            if (activeTable.getName().equals("leftTable"))
                activePath = leftPath;
            else activePath = rightPath;
            
            if (keyCode == KeyEvent.VK_ENTER) {
                int selectedRow = activeTable.getSelectedRow();
                if (selectedRow != -1) {
                    Object mf = activeTable.getModel().getValueAt(selectedRow, 0);
                    if (((MyFile)mf).isDirectory()) {
                        TableSorter ts = new TableSorter(new FSTableModel((MyFile)mf));
                        activeTable.setModel(ts);
                        ts.addMouseListenerToHeaderInTable(activeTable);
                        ((CustomTable)activeTable).setTableRenderer(activeTable, new FSTableCellRenderer());
                    } else {
                        Runtime r = Runtime.getRuntime();
                        try {
                        r.exec(((MyFile)mf).getAbsolutePath());
                        } catch (IOException ioe) {
                            System.out.println(ioe);
                            ioe.printStackTrace();
                        }
                    }
                    activePath.setText(((MyFile)mf).getAbsolutePath());
                }
            } else if (keyCode == KeyEvent.VK_BACK_SPACE) {
                
                if (parent != null) {
                    TableSorter ts = new TableSorter(new FSTableModel(new MyFile(parent)));
                    activeTable.setModel(ts);
                    ts.addMouseListenerToHeaderInTable(activeTable);
                    ((CustomTable)activeTable).setTableRenderer(activeTable, new FSTableCellRenderer());
                    activePath.setText(parent.getAbsolutePath());
                }
                
            } else if (keyCode == KeyEvent.VK_F5) {
                File[] sourceFilesList;
                File targetPath = null;
                JTable targetTable = null;
                if (selectedRows != null) {
                    if (activeTable.getName().equals("leftTable")) {
                        targetTable = rightTable;
                    } else {
                        targetTable = leftTable;
                    }
                    targetPath = (File)(targetTable.getModel().getValueAt(0,-1));
                    sourceFilesList = new File[selectedRows.length];
                    for (int i = 0; i < selectedRows.length; i++) {
                        sourceFilesList[i] = (File)(activeTable.getValueAt(selectedRows[i], 0));
                    }
                    new FileCopy(sourceFilesList, targetPath, targetTable);
                }
                TableSorter ts = new TableSorter(new FSTableModel(targetPath));
                targetTable.setModel(ts);
                ts.addMouseListenerToHeaderInTable(targetTable);
                ((CustomTable)targetTable).setTableRenderer(targetTable, new FSTableCellRenderer());
            } else if (keyCode == KeyEvent.VK_F6) {
                File[] sourceFilesList;
                File targetPath = null;
                JTable targetTable = null;
                if (selectedRows != null) {
                    if (activeTable.getName().equals("leftTable")) {
                        targetTable = rightTable;
                    } else {
                        targetTable = leftTable;
                    }
                    targetPath = (File)(targetTable.getModel().getValueAt(0,-1));
                    sourceFilesList = new File[selectedRows.length];
                    for (int i = 0; i < selectedRows.length; i++) {
                        sourceFilesList[i] = (File)(activeTable.getValueAt(selectedRows[i], 0));
                    }
                    new FileMove(sourceFilesList, targetPath, targetTable);
                }
                TableSorter ts = new TableSorter(new FSTableModel(targetPath));
                targetTable.setModel(ts);
                ts.addMouseListenerToHeaderInTable(targetTable);
                ((CustomTable)targetTable).setTableRenderer(targetTable, new FSTableCellRenderer());
                
                TableSorter ts2 = new TableSorter(new FSTableModel(root));
                activeTable.setModel(ts2);
                ts2.addMouseListenerToHeaderInTable(activeTable);
                ((CustomTable)activeTable).setTableRenderer(activeTable, new FSTableCellRenderer());
            } else if (keyCode == KeyEvent.VK_F2) {
                File[] sourceFilesList;
                File targetPath;
                JTable targetTable = null;
                if (selectedRows != null) {
                    if (activeTable.getName().equals("leftTable")) {
                        targetTable = rightTable;
                    } else {
                        targetTable = leftTable;
                    }
                    sourceFilesList = new File[selectedRows.length];
                    for (int i = 0; i < selectedRows.length; i++) {
                        sourceFilesList[i] = (File)(activeTable.getValueAt(selectedRows[i], 0));
                    }
                    new FileRename(sourceFilesList);
                }
                TableSorter ts = new TableSorter(new FSTableModel(root));
                activeTable.setModel(ts);
                ts.addMouseListenerToHeaderInTable(activeTable);
                ((CustomTable)activeTable).setTableRenderer(activeTable, new FSTableCellRenderer());
            } else if (keyCode == KeyEvent.VK_F7) {
                new MakeDir(root);
                TableSorter ts = new TableSorter(new FSTableModel(root));
                activeTable.setModel(ts);
                ts.addMouseListenerToHeaderInTable(activeTable);
                ((CustomTable)activeTable).setTableRenderer(activeTable, new FSTableCellRenderer());
            } else if (keyCode == KeyEvent.VK_F8) {
                File[] sourceFilesList;
                if (selectedRows != null) {
                    sourceFilesList = new File[selectedRows.length];
                    for (int i = 0; i < selectedRows.length; i++) {
                        sourceFilesList[i] = (File)(activeTable.getValueAt(selectedRows[i], 0));
                    }
                    new FileDelete(sourceFilesList);
                    new FolderDelete(sourceFilesList);
                }
                TableSorter ts = new TableSorter(new FSTableModel(root));
                activeTable.setModel(ts);
                ts.addMouseListenerToHeaderInTable(activeTable);
                ((CustomTable)activeTable).setTableRenderer(activeTable, new FSTableCellRenderer());
                
            }
        }
        
        public void keyReleased(KeyEvent e) {
        }
        
        public void keyTyped(KeyEvent e) {
        }
        
    }
    
    public class RootsListener implements ItemListener {
        JComboBox activeComboBox;
        public void itemStateChanged(ItemEvent e) {
            activeComboBox = (JComboBox)(e.getSource());
                if (activeComboBox.equals(leftRoots)) {
                    TableSorter ts = new TableSorter(new FSTableModel((File)(leftRoots.getSelectedItem())));
                    leftTable.setModel(ts);
                    ts.addMouseListenerToHeaderInTable(leftTable);
                    ((CustomTable)leftTable).setTableRenderer(leftTable, new FSTableCellRenderer());
                    leftPath.setText("---");
                } else {
                    TableSorter ts = new TableSorter(new FSTableModel((File)(rightRoots.getSelectedItem())));
                    rightTable.setModel(ts);
                    ts.addMouseListenerToHeaderInTable(rightTable);
                    ((CustomTable)rightTable).setTableRenderer(rightTable, new FSTableCellRenderer());
                    rightPath.setText("---");
                }
        }
        
    }
    
    public class CustomTable extends JTable {
        
        public void setTableRenderer(JTable table, TableCellRenderer tcr) {
            int columnCount = table.getColumnCount();
            String columnName = "";
            for (int i = 0; i < columnCount; i++) {
                columnName = table.getColumnName(i);
                table.getColumn(columnName).setCellRenderer(tcr);
            }
        }
        
        public CustomTable(TableSorter ts) {
            super(ts);
            ts.addMouseListenerToHeaderInTable(this);
            this.addKeyListener(new TableKeyListener());
            this.setDoubleBuffered(true);
            this.setIntercellSpacing(new Dimension(0, 0));
            this.setShowGrid(false);
            setTableRenderer(this, new FSTableCellRenderer());
        }
        
    }
    
    public void actionPerformed(ActionEvent ae) {
    }
    
}