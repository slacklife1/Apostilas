/**
 *
 * @author  Rustam M. Bunyadov
 * Engineer Developer
 * R.I.S.K. Company
 * rustamb@risk.az
 */

import javax.swing.table.*;
import java.io.*;
import javax.swing.event.*;
import java.util.*;

public class FSTableModel implements TableModel {
    private String[] columns = {"File name", "Size", "Type", "Date modified", "Attributes"};
    private File[] filesList;
    private File parent;
    
    public FSTableModel(File parent) {
        this.parent = parent;
        filesList = parent.listFiles();
    }
    
    public void addTableModelListener(TableModelListener l) {
    }
    
    public Class getColumnClass(int columnIndex) {
        return getValueAt(0, columnIndex).getClass();
    }
    
    public int getColumnCount() {
        return columns.length;
    }
    
    public String getColumnName(int columnIndex) {
        return columns[columnIndex];
    }
    
    public int getRowCount() {
        if (filesList != null) return filesList.length + 1;
        else return 1;
    }
    
    public Object getValueAt(int rowIndex, int columnIndex) {
        MyFile mf = null;
        
        if (rowIndex != 0) {
            mf = new MyFile(filesList[rowIndex-1]);
            
            if (columnIndex == 0)
                return mf;
            else if (columnIndex == 1)
                return getFileSize(mf);
            else if (columnIndex == 2)
                return getFileType(mf);
            else if (columnIndex == 3)
                return getFileDate(mf);
            else if (columnIndex == 4)
                return getAttributes(mf);
            else
                return parent;
            
        } else {
            mf = new MyFile(parent, true);
            if (mf.getParentFile() != null) mf = new MyFile(mf.getParentFile(), true);
            
            if (columnIndex == 0)
                return mf;
            else if (columnIndex == -1)
                return parent;
            else return "";
        }
    }
    
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }
    
    public void removeTableModelListener(TableModelListener l) {
    }
    
    public void setValueAt(Object newFileName, int rowIndex, int columnIndex) {
    }
    
    public String getFileSize(File f) {
        long fileSize = 0;
        if (f.isFile()) {
            fileSize = f.length();
            int d = 1;
            String suffix = " B";
            if (fileSize > 1000 && fileSize < 1000000) {d = 1000; suffix = " KB";}
            else if (fileSize > 1000000) {d = 1000000; suffix = " MB";}
            return Long.toString(fileSize / d) + suffix;
        } else {
            File[] filesList = f.listFiles();
            int itemsCount = 0;
            if (filesList != null)
                itemsCount = filesList.length;
            return itemsCount + " items";
        }
    }
    
    public String getFileType(File f) {
        String fileName = f.getName().toLowerCase();
        if (f.isDirectory()) return " folder";
        else if (fileName.endsWith(".mp3")) return " MP3 audio";
        else if (fileName.endsWith(".wav")) return " wave audio";
        else if (fileName.endsWith(".txt")) return " text document";
        else if (fileName.endsWith(".xls")) return " MS Excel Document";
        else if (fileName.endsWith(".xlt")) return " MS Excel Template";
        else if (fileName.endsWith(".zip")) return " ZIP Archive";
        else if (fileName.endsWith(".rar")) return " RAR Archive";
        else if (fileName.endsWith(".tar.gz")) return " TARGZ Archive";
        else if (fileName.endsWith(".sh")) return " Shell Script";
        else if (fileName.endsWith(".doc")) return " MS Word Document";
        else if (fileName.endsWith(".pdf")) return " PDF Document";
        else if (fileName.endsWith(".bmp")) return " Bitmap Image";
        else if (fileName.endsWith(".jpg")) return " JPG Image";
        else if (fileName.endsWith(".html")) return " HTML Page";
        else if (fileName.endsWith(".htm")) return " HTM Page";
        else if (fileName.endsWith(".rtf")) return " RTF Document";
        else if (fileName.endsWith(".avi")) return " Video Movie";
        else if (fileName.endsWith(".mpeg")) return " MPEG Movie";
        else if (fileName.endsWith(".mov")) return " QuickTime Movie";
        else if (fileName.endsWith(".java")) return " Java Source File";
        else if (fileName.endsWith(".class")) return " Java Class File";
        else if (fileName.endsWith(".xml")) return " XML Document";
        else return " " + fileName.substring(fileName.indexOf(".")+1).toUpperCase() + " File";
    }
    
    public String getAttributes(File f) {
        String attr = "";
        if (f.canRead()) attr+= "-r";
        if (f.canWrite()) attr+= "-w";
        if (f.isHidden()) attr+= "-h";
        return attr;
    }
    
    public String getFileDate(File f) {
        Calendar cd = Calendar.getInstance();
        cd.setTimeInMillis(f.lastModified());
        return cd.getTime().toString();
    }
    
}
