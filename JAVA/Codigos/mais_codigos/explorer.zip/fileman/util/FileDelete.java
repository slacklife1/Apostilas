/**
 *
 * @author  Rustam M. Bunyadov
 * Engineer Developer
 * R.I.S.K. Company
 * rustamb@risk.az
 */

package util;

import java.io.*;

public class FileDelete {
    
    public FileDelete(File[] sourceFilesList) {
        int filesCount = sourceFilesList.length;
        for (int i = 0; i < filesCount; i++) {
            delete(sourceFilesList[i]);
        }
    }
    
    public void delete(File sourceFile) {
        try {
            if (!sourceFile.isDirectory()) {
                sourceFile.delete();
            } else {
                File[] filesList = sourceFile.listFiles();
                new FileDelete(filesList);
            }
        } catch (Exception e) {
            System.out.println(e);
            e.printStackTrace();
        }
    }
    
}