/**
 *
 * @author  Rustam M. Bunyadov
 * Engineer Developer
 * R.I.S.K. Company
 * rustamb@risk.az
 */

package util;

import java.io.*;
import javax.swing.*;
import java.awt.*;

public class FolderDelete {
    //File sourceFile;
    
    public FolderDelete(File[] sourceFilesList) {
        CustomDialog cd = new CustomDialog("Deleting folders", "");
        EventQueue.invokeLater((Runnable)cd);
        int filesCount = sourceFilesList.length;
        for (int i = 0; i < filesCount; i++) {
            cd.setMessage(sourceFilesList[i].getName());
            delete(sourceFilesList[i]);
        }
        cd.dispose();
        cd.hide();
    }
    
    public void delete(File sourceFile) {
        try {
            if (sourceFile.isDirectory() && sourceFile.exists()) {
                File thisFile = sourceFile;
                while (thisFile.listFiles().length > 0) {
                    thisFile = thisFile.listFiles()[0];
                }
                thisFile.delete();
                delete(sourceFile);
            }
        } catch (Exception e) {
            System.out.println(e);
            e.printStackTrace();
        }
    }
    
}