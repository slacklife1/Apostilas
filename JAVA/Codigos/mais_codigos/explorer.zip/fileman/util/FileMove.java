/**
 *
 * @author  Rustam M. Bunyadov
 * Engineer Developer
 * R.I.S.K. Company
 * rustamb@risk.az
 */

package util;

import java.io.*;
import javax.swing.*;

public class FileMove {
    
    public FileMove(File[] sourceFilesList, File targetPath, JTable targetTable) {
        int filesCount = sourceFilesList.length;
        for (int i = 0; i < filesCount; i++) {
            move(sourceFilesList[i], targetPath, targetTable);
        }
    }
    
    public void move(File sourceFile, File targetPath, JTable targetTable) {
        try {
            sourceFile.renameTo(new File(targetPath.getAbsolutePath() + "/" + sourceFile.getName()));
        } catch (Exception e) {
            System.out.println(e);
            e.printStackTrace();
        }
    }
    
}