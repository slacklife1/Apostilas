/**
 *
 * @author  Rustam M. Bunyadov
 * Engineer Developer
 * R.I.S.K. Company
 * rustamb@risk.az
 */

package util;

import java.io.*;
import javax.swing.*;
import java.awt.*;

public class FileCopy {
    
    public FileCopy(File[] sourceFilesList, File targetPath, JTable targetTable) {
        CustomDialog cd = new CustomDialog("Copying files", "");
        EventQueue.invokeLater((Runnable)cd);
        int filesCount = sourceFilesList.length;
        
        for (int i = 0; i < filesCount; i++) {
            cd.setMessage(sourceFilesList[i].getName());
            copy(sourceFilesList[i], targetPath, targetTable);
        }
        cd.dispose();
        cd.hide();
        
    }
    
    public void copy(File sourceFile, File targetPath, JTable targetTable) {
        try {
            if (!sourceFile.isDirectory()) {
                BufferedInputStream bis = new BufferedInputStream(new FileInputStream(sourceFile), 4096);
                File targetFile = new File(targetPath.getAbsolutePath() + "/" + sourceFile.getName());
                BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(targetFile), 4096);
                int theChar;
                while ((theChar = bis.read()) != -1) {
                    bos.write(theChar);
                }
                bos.close();
                bis.close();
            } else {
                targetPath = new File(targetPath.getAbsolutePath() + "/" + sourceFile.getName());
                if (targetPath.mkdir()) {
                    File[] filesList = sourceFile.listFiles();
                    int filesCount = filesList.length;
                    File thisFile;
                    
                    for (int i = 0; i < filesCount; i++) {
                        thisFile = filesList[i];
                        copy(thisFile, targetPath, targetTable);
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e);
            e.printStackTrace();
        }
    }
    
}