/**
 *
 * @author  Rustam M. Bunyadov
 * Engineer Developer
 * R.I.S.K. Company
 * rustamb@risk.az
 */

package util;

import javax.swing.*;

public class FrameShower implements Runnable {
    final JFrame frame;
    public FrameShower(JFrame frame) {
        this.frame = frame;
    }
    public void run() {
        frame.show();
    }
}