/**
 *
 * @author  Rustam M. Bunyadov
 * Engineer Developer
 * R.I.S.K. Company
 * rustamb@risk.az
 */

package util;

import javax.swing.*;
import java.awt.*;

public class CustomDialog extends JFrame implements Runnable {
    private JLabel lblMessage;
    /** Creates a new instance of CustomDialog */
    public CustomDialog(String title, String message) {
        super(title);
        this.setSize(new Dimension(200, 100));
        lblMessage = new JLabel(message);
        this.getContentPane().add(lblMessage);
    }
    
    public void setMessage(String s) {
        lblMessage.setText(s);
    }
    
    public void run() {
        this.show();
    }
    
}
