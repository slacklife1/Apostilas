/**
 *
 * @author  Rustam M. Bunyadov
 * Engineer Developer
 * R.I.S.K. Company
 * rustamb@risk.az
 */

package util;

import javax.swing.*;
import java.io.*;
import java.awt.event.*;
import java.awt.*;

public class FileRename extends JFrame implements ActionListener {
    JDialog jd;
    JTextField tfdNewFileName;
    File oldFile;
    
    public FileRename(File[] oldFilesList) {
        for (int i = 0; i < oldFilesList.length; i++) {
            new FileRename(oldFilesList[i]);
        }
    }
    
    public FileRename(File oldFile) {
        this.oldFile = oldFile;
        jd = new JDialog(this, "Enter new folder name", true);
        Container con = jd.getContentPane();
        con.setLayout(new GridLayout(3, 1));
        tfdNewFileName = new JTextField();
        tfdNewFileName.setPreferredSize(new Dimension(200, 0));
        con.add(new JLabel("renaming: " + oldFile.getName()));
        con.add(tfdNewFileName);
        
        JPanel btnPane = new JPanel();
        btnPane.setLayout(new GridLayout(1, 2));
        
        JButton btnOK = new JButton("OK");
        btnOK.setActionCommand("btnOK");
        btnPane.add(btnOK);
        
        JButton btnCancel = new JButton("Cancel");
        btnCancel.setActionCommand("btnCancel");
        btnPane.add(btnCancel);
        
        con.add(btnPane);
        
        btnOK.addActionListener(this);
        btnCancel.addActionListener(this);
        
        jd.pack();
        jd.setVisible(true);
    }
    
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("btnOK"))
            oldFile.renameTo(new File(oldFile.getParent() + "/" + tfdNewFileName.getText()));
        jd.dispose();
    }
}