/**
 *
 * @author  Rustam M. Bunyadov
 * Engineer Developer
 * R.I.S.K. Company
 * rustamb@risk.az
 */
package util;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;

public class MakeDir extends JFrame implements ActionListener {
    final JDialog jd;
    JTextField tfdNewFolderName;
    File parent;
    
    public MakeDir(File parent) {
        this.parent = parent;
        jd = new JDialog(this, "Enter new folder name", true);
        Container con = jd.getContentPane();
        con.setLayout(new GridLayout(2, 1));
        tfdNewFolderName = new JTextField();
        tfdNewFolderName.setPreferredSize(new Dimension(200, 0));
        con.add(tfdNewFolderName);
        
        JPanel btnPane = new JPanel();
        btnPane.setLayout(new GridLayout(1, 2));
        
        JButton btnOK = new JButton("OK");
        btnOK.setActionCommand("btnOK");
        btnPane.add(btnOK);
        
        JButton btnCancel = new JButton("Cancel");
        btnCancel.setActionCommand("btnCancel");
        btnPane.add(btnCancel);
        
        con.add(btnPane);
        
        btnOK.addActionListener(this);
        btnCancel.addActionListener(this);
        
        jd.pack();
        jd.setVisible(true);
    }
    
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("btnOK"))
            (new File(parent.getAbsolutePath() + "/" + tfdNewFolderName.getText())).mkdir();
        jd.dispose();
    }
    
}