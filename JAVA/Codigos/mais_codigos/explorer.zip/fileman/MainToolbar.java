/**
 *
 * @author  Rustam M. Bunyadov
 * Engineer Developer
 * R.I.S.K. Company
 * rustamb@risk.az
 */

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class MainToolbar extends JToolBar {
    JButton btnRename = new JButton("F2 Rename");
    JButton btnCopy = new JButton("F5 Copy");
    JButton btnMove = new JButton("F6 Move");
    JButton btnMakeDir = new JButton("F7 MakeDir");
    JButton btnDelete = new JButton("F8 Delete");
    
    /** Creates a new instance of MainToolbar */
    public MainToolbar() {
        super();
        setLayout(new GridLayout(1, 5));
        btnRename.setActionCommand("actRename");
        btnCopy.setActionCommand("actCopy");
        btnMove.setActionCommand("actMove");
        btnMakeDir.setActionCommand("actMakeDir");
        btnDelete.setActionCommand("actDelete");
        add(btnRename);
        add(btnCopy);
        add(btnMove);
        add(btnMakeDir);
        add(btnDelete);
    }
    
    public void addActionListener(ActionListener al) {
        btnRename.addActionListener(al);
        btnCopy.addActionListener(al);
        btnMove.addActionListener(al);
        btnMakeDir.addActionListener(al);
        btnDelete.addActionListener(al);
    }
    
}
