Applet: JavaGraph! v2.02
Author: Copyright (c) 1998, Robert Rugge
WWW   : http://www.infocalyptika.com/jg_index.html
E-Mail: javagraph@infocalyptika.com

---------------

Note: JavaGraph! 2.02 includes the following changes from v2.0

	a) There is now an "info" parameter (see JG201.TXT)
	b) Fixed a minor display bug during registered use.
	c) Changed the encryption method for the regCode
	d) Decreased file size by 3k!

PLEASE! Visit the JavaGraph! homepage and my company, Infocalyptika!  JavaGraph! is
provided free simply to show you what we can do, and to get you to visit the site!

JavaGraph!:	http://www.infocalyptika.com/jg_index.html
Infocalyptika:	http://www.infocalyptika.com/

---------------
This document any any other materials provided in the JavaGraph! v2.02 archive are 
copyright (c) 1998 by Robert Rugge (rrugge@infocalyptika.com).