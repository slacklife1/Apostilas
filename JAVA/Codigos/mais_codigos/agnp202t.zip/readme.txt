Applet Glide Navigation Pro Version 2.0 Readme File

1. PURPOSE

Applet Glide Navigation Pro is a powerful 
applet-producing design tool for creating
menu system on Web pages.

2. What's new!

New option Transparent was added to Item's 
Normal, Mouse Over and Clicked status. 

New option Scroll Auto was added to Vertical 
Scroll Bar. Now if user moves mouse over the 
vertical scroll bar, the scrol bar will be 
scrolled automatically. User don't need to 
click the mouse.

New option Open One Sub-Menu Only was added 
to applet. If this option be enabled, any 
previous opened menus will be closed before 
new sub-menu be opened.

Optimize aniamtion of the glide to be more 
smooth.

Optimize option Image Align -- Tile and 
Resize. In previous versions, users set 
option Image Align to Tile or Resize may 
cause the performance of applet down. Now 
this option was improved.

Fix bug. In previous versions, menus' 
position may be incorrect during the 
gliding. Now this bug was fixed.

Fix bug. In previous versions, if user 
presses the web browser's button such 
as Back, Prev or Refresh for many times, 
a exception may be caused. Now this bug 
was fixed.


3. FEATURES

Applet Glide Navigation Pro offers a fast,
simple way to create professional menu system
on your web page.  Applet can be customized
highly. You can specify a lot of properties 
such as text, font, color, link, background image, 
sound effect and more by clicking your mouse.
You don't need to learn and write any complex 
applet parameters by yourself. Applet Configuration
Program will do it for you. With this powerful 
applet-producing design tool, you can create a
professional menu system just in minutes!


4. System Requirement

Win 95/98/Me/NT/2000/XP, Web Browser that
support JAVA


5. LICENSE

This is SHAREWARE. The trial software may be
freely copied and distributed if no modification 
is made within the archive package. 

Check out the license.txt to get more detail.


6. CONTACT INFOMATION

Web Site:  http://www.usingit.com/

Technical Support: support@usingit.com

General Information:  info@usingit.com
Sale:  sales@usingit.com
Marketing:  marketing@usingit.com