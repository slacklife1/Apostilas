/*
 *  ====================================================================
 *  The Apache Software License, Version 1.1
 *
 *  Copyright (c) 2002 The Apache Software Foundation.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  3. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Apache Software Foundation (http://www.apache.org/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  4. The names "Apache" and "Apache Software Foundation" and
 *  "Apache Tapestry" must not be used to endorse or promote products
 *  derived from this software without prior written permission. For
 *  written permission, please contact apache@apache.org.
 *
 *  5. Products derived from this software may not be called "Apache",
 *  "Apache Tapestry", nor may "Apache" appear in their name, without
 *  prior written permission of the Apache Software Foundation.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 *  ====================================================================
 *
 *  This software consists of voluntary contributions made by many
 *  individuals on behalf of the Apache Software Foundation.  For more
 *  information on the Apache Software Foundation, please see
 *  <http://www.apache.org/>.
 */
package net.sf.tapestry;

import java.io.IOException;

import javax.servlet.ServletException;

import net.sf.tapestry.engine.*;

/**
 *  A service, provided by the {@link IEngine}, for its pages and/or components.  
 *  Services are
 *  responsible for constructing {@link EngineServiceLink}s (an encoding of URLs)
 *  to represent dynamic application behavior, and for
 *  parsing those URLs when a subsequent request involves them.
 *
 *  @see IEngine#getService(String)
 *
 *  @author Howard Lewis Ship
 *  @version $Id: IEngineService.java,v 1.15 2003/01/27 16:30:21 hlship Exp $
 * 
 **/

public interface IEngineService
{
    /**
     *  @deprecated To be removed in 2.5.  Use {@link Tapestry#ACTION_SERVICE} instead.
     *
     **/

    public final static String ACTION_SERVICE = Tapestry.ACTION_SERVICE;

    /**
     *  @deprecated To be removed in 2.5.  Use {@link Tapestry#DIRECT_SERVICE} instead.
     *
     **/

    public final static String DIRECT_SERVICE = Tapestry.DIRECT_SERVICE;

    /**
     *  @deprecated To be removed in 2.5.  Use {@link Tapestry#EXTERNAL_SERVICE} instead.
     *
     **/

    public final static String EXTERNAL_SERVICE = Tapestry.EXTERNAL_SERVICE;

    /**
     *  @deprecated To be removed in 2.5.  Use {@link Tapestry#PAGE_SERVICE} instead.
     *
     **/

    public final static String PAGE_SERVICE = Tapestry.PAGE_SERVICE;

    /**
     *  @deprecated To be removed in 2.5.  Use {@link Tapestry#HOME_SERVICE} instead.
     *
     **/

    public final static String HOME_SERVICE = Tapestry.HOME_SERVICE;

    /**
     *  @deprecated To be removed in 2.5.  Use {@link Tapestry#RESTART_SERVICE} instead.
     *
     **/

    public static final String RESTART_SERVICE = Tapestry.RESTART_SERVICE;

    /**
     *  @deprecated To be removed in 2.5.  Use {@link Tapestry#ASSET_SERVICE} instead.
     *
     **/

    public static final String ASSET_SERVICE = Tapestry.ASSET_SERVICE;

    /**
     *  @deprecated To be removed in 2.5.  Use {@link Tapestry#RESET_SERVICE} instead.
     *
     **/

    public static final String RESET_SERVICE = Tapestry.RESET_SERVICE;

    /**
     *  @deprecated To be removed in 2.5.  Use 
     *  {@link Tapestry#SERVICE_QUERY_PARAMETER_NAME} instead.
     *
     **/

    public static final String SERVICE_QUERY_PARAMETER_NAME = Tapestry.SERVICE_QUERY_PARAMETER_NAME;

    /**
     *  @deprecated To be removed in 2.5.  Use {@link Tapestry#CONTEXT_QUERY_PARMETER_NAME} instead.
     *
     **/

    public static final String CONTEXT_QUERY_PARMETER_NAME = Tapestry.CONTEXT_QUERY_PARMETER_NAME;

    /**
     *  @deprecated To be removed in 2.5.  Use 
     *  {@link Tapestry#PARAMETERS_QUERY_PARAMETER_NAME} instead.
     *
     **/

    public static final String PARAMETERS_QUERY_PARAMETER_NAME =
        Tapestry.PARAMETERS_QUERY_PARAMETER_NAME;

    /**
     *  Builds a URL for a service.  This is performed during the
     *  rendering phase of one request cycle and bulds URLs that will
     *  invoke activity in a subsequent request cycle.
     *
     *  @param cycle Defines the request cycle being processed.
     *  @param component The component requesting the URL.  Generally, the
     *  service context is established from the component.
     *  @param parameters Additional parameters specific to the
     *  component requesting the EngineServiceLink.
     *  @return The URL for the service.  The URL will have to be encoded
     *  via {@link HttpServletResponse#encodeURL(java.lang.String)}.
     *
     **/

    public ILink getLink(IRequestCycle cycle, IComponent component, Object[] parameters);

    /**
     *  Perform the service, interpreting the URL (from the
     *  {@link javax.servlet.http.HttpServletRequest}) 
     *  responding appropriately, and
     *  rendering a result page.
     *
     *  <p>The return value indicates whether processing of the request could, in any way,
     *  change the state of the {@link IEngine engine}.  Generally, this is true.
     *
     *  @see IEngine#service(RequestContext)
     *  @param engine a view of the {@link IEngine} with additional methods needed by services
     *  @param cycle the incoming request
     *  @param output stream to which output should ultimately be directed
     * 
     **/

    public boolean service(
        IEngineServiceView engine,
        IRequestCycle cycle,
        ResponseOutputStream output)
        throws RequestCycleException, ServletException, IOException;

    /**
     *  Returns the name of the service.
     *
     *  @since 1.0.1
     **/

    public String getName();
}