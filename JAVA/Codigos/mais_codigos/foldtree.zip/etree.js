//DHTML Expandable Web Folder 1.0
//Copyright (C) 1998  Munica Corporation
//Visit http://www.munica.com/dhtml for the latest version
//This program is free software and with no warranty; 
//You can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version;

var bV=parseInt(navigator.appVersion);
NS4=((document.layers)&&(bV>=4)) ? true : false;
IE4=((document.all)&&(bV>=4))?true:false;
ver4 = (NS4 || IE4) ? true : false;
arTreeImg=new Array();
firstInd=0;


function showTooltip(obj, boxname, e, tip)
{
	if (NS4)
	{
		var tooltip=eval("document."+boxname+"tooltip");
		tooltip.document.clear();
		tooltip.document.write('<layer bgColor="#ffffdd" style="border:1px solid black; font-size:10pt">'+tip+'</layer>');
		tooltip.document.close();
		tooltip.left=e.pageX+5;
		tooltip.top=e.pageY+5;
		tooltip.visibility="show";	
	}else
	if (IE4)
		obj.title=tip;
}

function hideTooltip(boxname)
{
	if (NS4)
	{
		var tooltip=eval("document."+boxname+"tooltip");
		tooltip.document.write('<layer bgColor="#ffffdd" style="border:1px solid black; font-size:10pt"> </layer>');
		tooltip.visibility="hide";
	}
}

function toggleToolbar(boxname)
{
var	whichOne;

	if (NS4)
	{
		whichOne=eval("document."+name+"toolbar");
		if (whichOne.visibility=="hide")
			whichOne.visibility="show";
		else
			whichOne.visibility="hide";	
	}else
	{
		whichOne=eval(boxname+"toolbar");
		if (whichOne.style.display=="none")
			whichOne.style.display="block";
		else
			whichOne.style.display="none";	
	}
	arrange();
}

function preloadImages(imbr, imbr_over, imbrex, imbrex_over, imlf, imlf_over, imblank)
{
	arTreeImg["imbrex"]= new Image();
	arTreeImg["imbrex"].src=imbrex;

	arTreeImg["imbrex_over"]= new Image();
	arTreeImg["imbrex_over"].src=imbrex_over;

	arTreeImg["imbr"]= new Image();
	arTreeImg["imbr"].src=imbr;

	arTreeImg["imbr_over"]= new Image();
	arTreeImg["imbr_over"].src=imbr_over;
	
	arTreeImg["imlf"]= new Image();
	arTreeImg["imlf"].src=imlf;

	arTreeImg["imlf_over"]= new Image();
	arTreeImg["imlf_over"].src=imlf_over;

	arTreeImg["imblank"]= new Image();
	arTreeImg["imblank"].src=imblank;

	arTreeImg["imblank_over"]= new Image();
	arTreeImg["imblank_over"].src=imblank;

}
	
function getIndex(item) 
{
var	whichItem;

	for (i=0; i < document.layers.length; i++)
	{
		whichItem = document.layers[i];
		if (whichItem.id == item) 
			return i;
	}
	return -1;
}

function arrange() 
{
var i=0;
var	whichItem;

        if (IE4) return;
        nextY = document.layers[firstInd].top + document.layers[firstInd].document.height;
        for ( i=firstInd+1; i < document.layers.length; i++)
	{
		whichItem = document.layers[i];
                if (whichItem.visibility == "show") 
		{
                        whichItem.top = nextY;
			nextY += whichItem.document.height;
		}

	}
}

function hideIt(level)
{
var i=1;
var whichLevel, whichValid;
var whichIm;
var child;
var childStr;
var clayeridx=0, layeridx=0;

	if (NS4)
	{
		layeridx=this.getIndex("L"+level+i);
		while  (layeridx!=-1)
		{
			whichLevel=eval("document."+"L"+level+i);
		        whichIm = eval("document." + "L"+ level + i + ".document.images['"+"I"+level+i+"']");

			if ((clayeridx=this.getIndex("L"+level+i+"_"+1))!=-1)
			{
				childstr=level+i+"_";
				hideIt(childstr);
				whichIm.src = arTreeImg["imbr"].src;			
			}else
				whichIm.src = arTreeImg["imlf"].src;			
			whichLevel.visibility = "hide";
			i++;
			layeridx=this.getIndex("L"+level+i);
		}
		arrange();
	}else
	{
		allDIVs=document.all.tags("DIV");
		whichValid=eval("allDIVs."+"L"+level+i);
		while  (eval(whichValid)=="[object]")
		{
			whichLevel=eval("L"+level+i);

			child=eval("allDIVs."+"L"+level+i+"_"+1);
			childstr=level+i+"_";
			if (child=="[object]")
				hideIt(childstr);

			whichLevel.style.display = "none";
			
			i++;	
			whichValid=eval("allDIVs."+"L"+level+i);
		}
	}
}

function focusIt(level)
{
var	upperLevel, upperIm, j=0, imgname;

	if (NS4)
	{
		if (level.length>0)
		{
			upperLevel=level.substring(0, (level.length-1));
			upperIm = eval("document." + "L"+upperLevel + ".document.images['"+"I"+upperLevel+"']");					
		}
	}else
	{
		if (level.length>0)
		{
			upperlevel=level.substring(0, (level.length-1));
			upperIm=eval("I"+upperlevel);
		}
	}
	j=upperIm.src.lastIndexOf('/', upperIm.src.length);
	if (j==-1) 
		j=upperIm.src.lastIndexOf('\\', upperIm.src.length);

	imgname=upperIm.src.substring(j+1, upperIm.src.length);

	j=imgname.indexOf('.', 0);
	if (j==-1) return;
	imgname=imgname.substring(0, j);

	j=imgname.indexOf('_');
	if (j!=-1)
		imgname=imgname.substring(0, j);

	imgname=imgname+"_over";
	upperIm.src=arTreeImg[imgname].src;
}

function outIt(level)
{
var	upperLevel, upperIm, j=0, imgname;

	if (NS4)
	{
		if (level.length>0)
		{
			upperLevel=level.substring(0, (level.length-1));
			upperIm = eval("document." + "L"+upperLevel + ".document.images['"+"I"+upperLevel+"']");					
		}
	}else
	{
		if (level.length>0)
		{
			upperlevel=level.substring(0, (level.length-1));
			upperIm=eval("I"+upperlevel);
		}
	}
	j=upperIm.src.lastIndexOf('/', upperIm.src.length);
	if (j==-1) 
		j=upperIm.src.lastIndexOf('\\', upperIm.src.length);

	imgname=upperIm.src.substring(j+1, upperIm.src.length);

	j=imgname.indexOf('.', 0);
	if (j==-1) return;
	imgname=imgname.substring(0, j);

	j=imgname.indexOf('_');
	if (j!=-1)
		imgname=imgname.substring(0, j);
	upperIm.src=arTreeImg[imgname].src;
}

function expandIt(level)
{
var i=1, j=1;
var whichLevel;
var whichIm, upperIm;
var child;
var childstr, upperLevel;
var layeridx=0, clayeridx=0;
	
	if (NS4)
	{
		if (level.length>0)
		{
			upperLevel=level.substring(0, (level.length-1));
			upperIm = eval("document." + "L"+upperLevel + ".document.images['"+"I"+upperLevel+"']");					
		}
		layeridx=this.getIndex("L"+level+i);
		while  (layeridx!=-1)
		{
		        whichLevel=eval("document."+"L"+level+i);
			whichIm = eval("document." + "L"+ level + i + ".document.images['"+"I"+level+i+"']");
			if (whichLevel.visibility=="hide")
			{
				whichLevel.visibility = "show";
				if ((clayeridx=this.getIndex("L"+level+i+"_"+1))!=-1)
					whichIm.src = arTreeImg["imbr"].src;			
				else
					whichIm.src = arTreeImg["imlf"].src;		
				if ((i==1)&&(level.length>1))
					upperIm.src=arTreeImg["imbrex"].src;
			}else
			{
				if ((clayeridx=this.getIndex("L"+level+i+"_"+1))!=-1)
				{
					childstr=level+i+"_";
					hideIt(childstr);
					whichIm.src = arTreeImg["imbr"].src;
				}else
					whichIm.src = arTreeImg["imlf"].src;		

				whichLevel.visibility = "hide";
				if ((i==1)&&(level.length>0))
					upperIm.src=arTreeImg["imbr"].src;
			}
			i++;
			layeridx=this.getIndex("L"+level+i);
		}
		arrange();
	}else
	{
		if (level.length>0)
		{
			upperlevel=level.substring(0, (level.length-1));
			upperIm=eval("I"+upperlevel);
		}
		
		allDIVs=document.all.tags("DIV");
		whichValid=eval("allDIVs."+"L"+level+i);
		while  (whichValid=="[object]")
		{
			whichIm=eval("I"+level+i);
			whichLevel=eval("L"+level+i);
			if ((whichLevel.style.display=="none")||(whichLevel.style.display==""))
			{
				whichLevel.style.display = "block";
				child=eval("allDIVs."+"L"+level+i+"_"+1);
				childstr=level+i+"_";
				if (child=="[object]")
					whichIm.src = arTreeImg["imbr"].src;			
				else
					whichIm.src = arTreeImg["imlf"].src;		

				if ((i==1)&&(level.length>0))
					upperIm.src=arTreeImg["imbrex"].src;
			}else
			{
				child=eval("allDIVs."+"L"+level+i+"_"+1);
				childstr=level+i+"_";
				if (child=="[object]")
				{
				        hideIt(childstr);
	                    whichIm.src = arTreeImg["imbr"].src;
				}else
						whichIm.src = arTreeImg["imlf"].src;		

                                whichLevel.style.display = "none";
				if ((i==1)&&(level.length>0))
					upperIm.src=arTreeImg["imbr"].src;
			}
			i++;	
			whichValid=eval("allDIVs."+"L"+level+i);
		}
	}
	return false;
}

function showIt(level)
{
var i=1, j=1;
var whichLevel;
var whichIm, upperIm;
var child;
var childstr, upperLevel;
var layeridx=0, clayeridx=0;
	if (NS4)
	{
		if (level.length>0)
		{
			upperLevel=level.substring(0, (level.length-1));
			upperIm = eval("document." + "L"+upperLevel + ".document.images['"+"I"+upperLevel+"']");					
		}
		layeridx=this.getIndex("L"+level+i);
		while  (layeridx!=-1)
		{
			whichLevel=eval("document."+"L"+level+i);
			whichIm = eval("document." + "L"+ level + i + ".document.images['"+"I"+level+i+"']");
			if (whichLevel.visibility=="hide")
			{
				childstr=level+i+"_";
				if ((clayeridx=this.getIndex("L"+level+i+"_"+1))!=-1)
				{
					hideIt(childstr);
					whichIm.src = arTreeImg["imbr"].src;
				}else
					whichIm.src = arTreeImg["imlf"].src;		

				if ((i==1)&&(level.length>0))
					upperIm.src=arTreeImg["imbr"].src;
			}else
			{
				childstr=level+i+"_";
				if ((clayeridx=this.getIndex("L"+level+i+"_"+1))!=-1)
					whichIm.src = arTreeImg["imbr"].src;			
				else
					whichIm.src = arTreeImg["imlf"].src;		
				if ((i==1)&&(level.length>1))
					upperIm.src=arTreeImg["imbrex"].src;
				showIt(childstr);
			}
			i++;
			layeridx=this.getIndex("L"+level+i);
		}
		arrange();
	}else
	{
		if (level.length>0)
		{
			upperlevel=level.substring(0, (level.length-1));
			upperIm=eval("I"+upperlevel);
		}
		
		allDIVs=document.all.tags("DIV");
		whichValid=eval("allDIVs."+"L"+level+i);
		while  (whichValid=="[object]")
		{
			whichIm=eval("I"+level+i);
			whichLevel=eval("L"+level+i);
			if ((whichLevel.style.display=="none")||(whichLevel.style.display==""))
			{
				child=eval("allDIVs."+"L"+level+i+"_"+1);
				childstr=level+i+"_";
				if (child=="[object]")
				{
				        hideIt(childstr);
	                    whichIm.src = arTreeImg["imbr"].src;
				}else
						whichIm.src = arTreeImg["imlf"].src;		

				if ((i==1)&&(level.length>0))
					upperIm.src=arTreeImg["imbr"].src;
			}else
			{
				child=eval("allDIVs."+"L"+level+i+"_"+1);
				childstr=level+i+"_";
				if (child=="[object]")
					whichIm.src = arTreeImg["imbr"].src;			
				else
					whichIm.src = arTreeImg["imlf"].src;		

				if ((i==1)&&(level.length>0))
					upperIm.src=arTreeImg["imbrex"].src;
			}
			i++;	
			whichValid=eval("allDIVs."+"L"+level+i);
		}
	}
	return false;
}

//function AddItem
//parent: The parent of this item. Use "1" to identify level one. Use "1_1" to identify
//        level one's first children. Use "2_2" to identify level two's second child, and so on.
//idx:   The index of this item starts from 1
//href:  Link to the item
//label: Label of the item
//last:  Not used in this version.

function addItem(parent, idx, href, label, last)
{
var	upperLevel, child, focstr, outstr, clickstr, prefix, upperIm, upperLevel;
var	blankimg;
var	i=0;
	blankimg=arTreeImg["imblank"].src;

	if (parent=="")
		child=idx;
	else
		child=parent+'_'+idx;

	//set parent image
	focstr="focusIt('"+child+"_')";
	outstr="outIt('"+child+"_')";
	clickstr="expandIt('"+child+"_')";

	href=((href==null)||(href==''))?'#':href;

	//pad with blank images
	prefix="";
	upperLevel=parent;	
	while (upperLevel!="")
	{	
		if (this.line=="noline")
			prefix='<img name="blank" src="'+blankimg+'" height=16 width=16 border=0>'+prefix;
		else
		{
			if (i==0)	
			{
				if (last=="last")
					prefix='<img name="blank" src="im_l.gif" height=16 width=16 border=0>'+prefix;
				else
					prefix='<img name="blank" src="im_t.gif" height=16 width=16 border=0>'+prefix;
			}else
				prefix='<img name="blank" src="im_i.gif" height=16 width=16 border=0>'+prefix;				
		}	
		lastmark=upperLevel.lastIndexOf('_', upperLevel.length);
		if (lastmark<=0)
			break;
		upperLevel=upperLevel.substring(0, lastmark);
		i++;
	}

	document.write('<DIV ID="L'+child+'" CLASS=levelone>');
	document.write('<a href="'+href+'" onmouseover="'+focstr+'" onmouseout="'+outstr+'" target="right" onclick="'+clickstr+';">');
	document.write(prefix);
	document.write('<img name="I'+child+'" src="'+blankimg+'" height=16 width=16 border=0>');
	document.write(label);
	document.write('</a>\n');
	document.write('</DIV>\n');
}

//function Create Tree
//name: The name of the tree. Use "mytree" for this version.
//line: Use "noline" for this version.

function createTree(name, line)
{
        document.write('<DIV ID="'+name+'title" CLASS=title>');
        document.write('<a href="#" onclick="toggleToolbar(\''+name+'\'); return false"><img src="et_title.gif" height=16 width=160 border=0 alt="Click to Turn Toolbar On/Off"></a>');
        document.write('</DIV>\n');

        document.write('<DIV ID="'+name+'toolbar" CLASS=toolbar>');
        document.write('<MAP name="ettoolbar">\n');
        document.write('<AREA shape="rect" coords="50,3,64,19" href="http://www.munica.com/dhtml" target="right" onmouseOver="showTooltip(this, \''+name+'\', event, \'DHTML Download\');" onmouseout="hideTooltip(\''+name+'\')">');
        document.write('<AREA shape="rect" coords="83,3,100,19" href="http://www.munica.com/folder-tree" target="right" onmouseOver="showTooltip(this, \''+name+'\', event, \'About DHTML Folder Tree\')" onmouseout="hideTooltip(\''+name+'\')">');
        document.write('</MAP>\n');      
        document.write('<img ISMAP USEMAP="#ettoolbar" src="et_toolbar.gif" height=24 width=160 border=0>\n');
        document.write('</DIV>\n');


	this.name=name;
	this.line=line;
	return this;
}

function closeTree()
{
        document.write('<DIV ID="'+this.name+'tooltip" STYLE="position:absolute; visibility:hide"> </DIV>');
}

function init()
{
        if (NS4)
                firstInd = this.getIndex(this.name);
        firstInd=0;
        this.expandIt('');
}

function resize()
{
        showIt('');
}

document.write("<STYLE TYPE='text/css'>");
if (NS4) 
{
        document.write(".title {position:absolute; visibility:show}");
        document.write(".toolbar {position:absolute; visibility:show}");
	document.write(".levelone {position:absolute; visibility:hide}");
}else 
{
        document.write(".title  {visibility:block}");
        document.write(".toolbar {visibility:block}");
	document.write(".levelone {display:none}");
}
document.write("</STYLE>");
preloadImages('imbr.gif', 'imbr_over.gif', 'imbrex.gif', 'imbrex_over.gif', 'imlf.gif', 'imlf_over.gif', 'imblank.gif');
