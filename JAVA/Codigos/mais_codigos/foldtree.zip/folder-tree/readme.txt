Product Name:   DHTML Expandable Web Folder
Version:        1.0
Description:
                A duo browser compatible expandable hierarchy folder that
                organizes your links and makes your web site easy to navigate.
                It has a built in browser sniffer that will automatically
                generate the right content for any kind of browser.
License:        Freeware
Platform:       Java Script
Requirements:   Netscape 4.0+ or IE 4.0+
Author: 	Munica Corporation
Address:	550 Landreville Suite 2D
City: 		Montreal
State: 		PQ
Country: 	CANADA
ZIP: 		H3E 1B4
Web:		http://www.munica.com
Product URL:    http://www.munica.com/dhtml 
Email:		1-514-362-1032
Fax:		1-514-362-8729

