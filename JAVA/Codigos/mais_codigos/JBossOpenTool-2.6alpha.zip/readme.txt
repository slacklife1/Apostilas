                      ############################
                      #  Voyager JBoss OpenTool  #
                      ############################


Version 2.6alpha : 2003-04-16
=============================

1) Move the file JBossOpenTool.jar to c:\jbuilder8\lib\ext
2) Start JBuilder
3) 
  - For JBuilder6 configure "JBoss 2.4.x" or "JBoss 3.x" from Enterprise Setup depending on which JBoss version you use
  - For JBuilder7/8 configure "JBoss 2.4.x" or "JBoss 3.x" from the Server Setup
4) Everything else should work like the other appserver now
5) You have to disable the 'Add project classpath' checkbox in the run configuration
   and also disable the EJB archives in the run configuration. You can deploy the
   beans using the deploy action in the context menu of the EJBGRP node.

Important:
==========
This OpenTool should work with JBuilder 6/7/8 Enterprise. If anybody is trying
to use the tool with another version of JBuilder it probably will not work.


Help wanted:
============

If you find any bugs or something that is not working the way it should
please contact me:

Marcus Redeker  (marcus.redeker@gedoplan.de)


If you want to get involved and help me, check out the
project page at sourceforge.net:

http://sourceforge.net/projects/jboss-opentool/