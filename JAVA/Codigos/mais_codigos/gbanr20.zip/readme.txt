Java applet to make a cool banner display.
Allows many images, each with it's own URL.
As the images change, they zoom into the screen.
Various options, including random display. 
Easy to use. Requires a Java enabled browser, 
such as Netscape or Internet Explorer.

Unzip the contents of this zip file into the directory of your choice.

Open up gbanner.html file for information on how to use the applet.

This applet is Shareware ($5 US Funds), and is freely distributable.

If there is a question or problem, contact Lawrence Goetz at:
goetz@lawrencegoetz.com
http://www.lawrencegoetz.com/