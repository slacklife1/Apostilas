FIRST READ AND ACCEPT THE LICENSE BEFORE USING THIS SOFTWARE.

Visit http://www.wyka-warzecha.com
for more information about this and other
great products, plus full version 
ordering information!

--------------------
Quick Docs to Start:
--------------------

To get started fast, simply extract all of the files to a folder
on your hard-drive, and then open it in your browser (I.e.,
Microsoft Internet Explorer or Netscape Navigator).

OPEN THE index.htm FILE INTO YOUR BROWSER.

-----------------------------
Using this Evaluation Version
-----------------------------

Cut and paste this code into your HTML page:

<applet CODE="ABCNavUltimateEval.class" HEIGHT="260" WIDTH="211">
  <param name="copyright"         value="http://www.wyka-warzecha.com">
  <param name="URL1"              value="no_url">
  <param name="URL2"              value="no_url">
  <param name="URL3"              value="no_url">
  <param name="URL4"              value="no_url">
  <param name="URL5"              value="no_url">
  <param name="imageMain"         value="new_menu.jpg">
  <param name="imageMouseOver"    value="new_menu_hilite.jpg">
</applet>

Make sure you have copied the image files as well.
The copyright parameter is a required parameter.
To change the URLs, simply change the link inside the URL. (If
you do not want it to link anywhere, simply put 'no_url').
You may also change the image names.

This evaluation version cycles through the various effect
defaults when you click on the 'Click Me!' button.

The other default settings are set as follows:
- You may have 5 menu items
- Each menu item is 52 pixels high
- The menu is 211 pixels wide
- The tree level expands as follows:

1 - First Menu Item  (Root Branch)
2 - Second Menu Item (Branches off First Menu Item)
2 - Third Menu Item  (Branches off First Menu Item)
3 - Fourth Menu Item (Branches off Third Menu Item)
1 - Fifth Menu Item  (Root Branch)

I.e., visually it looks like this: (you may need to view
this in a text viewer that has a 'fixed-size' font)

*** First Menu Item
|   |
|   |
|   *** Second Menu Item
|   |
|   |
|   *** Third Menu Item
|       |
|       |
|       *** Fourth Menu Item
|
*** Fifth Menu Item

----------------------
Full Version Features:
----------------------

In the full version, you can easily create customized menus,
to create the amazing effect that *you* want! This also 
includes:

- Ability to use frames
- Ability to use sounds for mouseovers
- Ability to set the default special effects however you want
- Ability to FULLY customize every special effect!
- Ability to easily set the tree nodes *exactly* how you want
- Ability to customize loading background color
- Ability to create sharp looking menus, in any size!
- Special FX such as slicer, rotation, rotation blur, and scroller!

If you want more details of how the full version works/what
features it includes, please refer to the full version documentation
included in this .zip file. (It is named: sample_full_version_dox.htm)

----------------
More Information
----------------

Visit http://www.wyka-warzecha.com
for more information about this and other
great products, plus full version 
ordering information!
