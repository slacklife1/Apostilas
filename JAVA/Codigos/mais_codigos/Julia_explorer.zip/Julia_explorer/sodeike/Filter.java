/*
allgemeine java grafik-routinen
*/

package sodeike;

/**
 * Filter abstract super class
 * 09.02.2001
*/
import java.awt.Dimension;

public abstract class Filter {
    //public ByteArray input,output;
    public int width, height;

    protected Filter() {
    }
    /**
    * input[] --> do sometihng with it -->> output[]
    */
	public abstract void calc();

}
