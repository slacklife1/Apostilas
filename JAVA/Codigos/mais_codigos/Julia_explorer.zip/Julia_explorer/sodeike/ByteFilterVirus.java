package sodeike;

public class ByteFilterVirus extends ByteFilterGameOfLife
{
 public ByteFilterVirus (ByteArray dataIn, byte color)
 { super(dataIn, color); }

  public void calc ()
  {
    int summe = 0;
    int width = pixelsIn.size().width;
    int height = pixelsIn.size().height;

     for(int y=1;y<height-1;y++)
      for(int x=1;x<width-1;x++)
      {
        summe = 0;
        for (int i=-1; i<2; i++)
         for (int j=-1; j<2; j++)
         {
          umgebung[j+1][i+1] = pixelsIn.source[ x+i + (y+j)*width ];
          summe += pixelsIn.source[ x+i + (y+j)*width ];
         }
         summe /=color;

         if (umgebung[1][1]==0)
          if (summe == 3)
          { pixelsOut.source[ y*width+x ] = color; }
         else
          if ( ((summe-1) >=4) || ((summe-1) <=1) )
          { pixelsOut.source[ y*width+x ] = 0; }
     }
  }
}