package sodeike;

public class XorFilter extends ByteFilter
 {
  public byte xorValue=64;

 //---------------CONSTRUcTOR------------------------------------------
  public XorFilter (ByteArray dataInput) {
   super(dataInput);
  }

 //---------------M-A-I-N--L-O-O-P--------------------------------------
 public void calc ()
 {
  int w = pixelsIn.size().width;
  int h = pixelsIn.size().height;
  byte summe;

  for(int offset=w+1; offset < w*(h-1)-1; offset++)
   {
    summe = (byte)((pixelsIn.source[offset-w] +
                  pixelsIn.source[offset+w] +
                  pixelsIn.source[offset-1] +
                  pixelsIn.source[offset+1] +
                  pixelsIn.source[offset-1-w] +
                  pixelsIn.source[offset+1-w] +
                  pixelsIn.source[offset-1+w] +
                  pixelsIn.source[offset+1+w]) ^ xorValue);
    pixelsOut.source[offset] = summe;
   }
 }

}