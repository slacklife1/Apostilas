/*
allgemeine java grafik-routinen
*/

package sodeike;

public abstract class NoByteFilter extends ByteFilter{
  public void calc() {}
}