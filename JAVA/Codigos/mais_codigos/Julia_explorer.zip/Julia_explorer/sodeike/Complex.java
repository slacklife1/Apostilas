package sodeike;

import java.lang.Math;

public class Complex {
 public double r,im;

 private Complex(){}

 public Complex (double r, double im)
 {
  this.r = r; this.im = im;
 }

 //betrag ner complexen zahl
 public double betrag () {
  return Math.sqrt(r*r + im*im);
 }

 /**
 * c = a.add(b);
 */
 public Complex add(Complex b)
 {
  return new Complex(r + b.r, im + b.im);
 }

 /**
 * this = this + b
 */
 public void add(double br, double bim)
 {
  r += br;
  im += bim;
 }

 /**
 * c = a.mul(b);
 */
 public Complex mul(Complex b)
 {
  return new Complex (r*b.r - im*b.im , r*b.im + im*b.r);
 }

 /**
 * thid = this * b;
 */
 public void mul(double br, double bim)
 {
  double nr = r*br - im*bim;
  im = r*bim + im*br;
  r = nr;
 }
 public String toString()
 {
  if (im >= 0.0)
   return new String(r+" + "+ im +"i");
  else
   return new String(r+" "+ im +"i");
 }

}