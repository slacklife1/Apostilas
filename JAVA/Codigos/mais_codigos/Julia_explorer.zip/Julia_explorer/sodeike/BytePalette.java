package sodeike;

import java.lang.Math;
import java.awt.image.*;
import java.awt.*;

/**
 * game of life, needs to know a special color (color of element of life)
 * 09.02.2001
*/
public class BytePalette {
        private IndexColorModel icm;
        private byte[][] palette;
    private int nrOfColors;

    /**
    * generate just a simple 256 color-table
    */
    public BytePalette() {
        nrOfColors = 256;
                palette = new byte[3][256];
        setPalette();
                icm = new IndexColorModel(8, nrOfColors, palette[0],
                                                      palette[1], palette[2]);
    }

    public BytePalette(int nrOfColors) {
        this.nrOfColors = nrOfColors;
                palette = new byte[3][nrOfColors];
        setPalette();
                icm = new IndexColorModel(8, nrOfColors, palette[0],
                                                      palette[1], palette[2]);
    }

    /**
    * generate just a simple 256 color-table
    * use a transparent color, maybe for paralax-scrolling or
    * something like that
    */
    public BytePalette(byte transparent) {
        nrOfColors = 256;
                palette = new byte[3][256];
        setPalette();
                icm = new IndexColorModel(8, nrOfColors, palette[0],
                                                      palette[1], palette[2], transparent);
    }

    public BytePalette(int nrOfColors, byte transparent) {
        this.nrOfColors = nrOfColors;
                palette = new byte[3][nrOfColors];
        setPalette();
                icm = new IndexColorModel(8, nrOfColors, palette[0],
                                                      palette[1], palette[2], transparent);
    }

    /**
    * override this one
    */
    public void setPalette () {
     for(int i=0;i<128;i++) {
        palette[1][i]=(byte)(FadeBetween(0,255,i));
        palette[2][i]=(byte)(FadeBetween(255,0,i));
        palette[0][i]=(byte)(0);
     }
     for(int i=0;i<128;i++) {
        palette[1][i+128]=(byte)(FadeBetween(255,0,i));
        palette[2][i+128]=(byte)(FadeBetween(0,255,i));
        palette[0][i+128]=(byte)(0);
     }
    /* for(int i=0;i<256;i++) {
        palette[0][i]=(byte)(i);
        palette[1][i]=(byte)(i);
        palette[2][i]=(byte)(i);
       }*/
    }

    /*public void setPalette (int n)
    {
     switch(n) {
     case 0: {
     }break;
     case 1: setPalette()
    } */

    /**
    * color skaling
    */
        public final int FadeBetween(int start,int end,int proportion) {
                return ((end-start)*proportion)/128+start;
        }

    /**
    * MyPalette = new MyPalette();
    * img=createImage(new MemoryImageSource(byteFeld.getWidth(),
    *                                                          byteFeld.getHeight(),
    *                 ----->>            pal.getIndexColorModel(),
    *                                   byteFeld.pixelsOut,
        *                                                                0, byteFeld.getWidth()));
    */
    public IndexColorModel getIndexColorModel () {
           return icm;
    }

    /**
    * if u wanna f.e. load a .jpg to u're project, but
    * byte[] allows only a number of 255 colors, so u can interpolate
    * for every pixel{int rgb} the nearest color in this colorModel!
    * rgb.alpha will be setted to 0xff
    * @return the color translated to this colormodel
    */
    public byte getNearestColor(int RGB) {
       //byte alpha = (byte)((RGB & 0xff000000)>>24);
       int red   = (RGB & 0x00ff0000)>>16;
       int green = (RGB & 0x0000ff00)>>8;
       int blue  = (RGB & 0x000000ff);

       for (int v=0 ; v < (nrOfColors >> 1);v++)
         for (int i=0; i < nrOfColors;i++) {
          if((Math.abs( red - (int)palette[0][i] ) <=v) &&
             (Math.abs( green - (int)palette[1][i] ) <=v) &&
               (Math.abs( blue - (int)palette[2][i] ) <=v))
               return (byte)i;
         }
       return (byte)0; //no color found.
   }

   /**
   * <br> transform a integer[] into @see ByteArray and also calculate for every
   * <br> interger-pixel the best bytecolor depending on current colotTable.
   */
   public ByteArray transformPalette(Image im) {
     int w = im.getWidth(null);
     int h = im.getHeight(null);
     System.out.print("grabbin' a ["+w+","+h+"] image...");
     int [] tmp = new int[w * h];
         PixelGrabber pg = new PixelGrabber(im, 0, 0, w, h, tmp, 0, w );
                try { pg.grabPixels(); }
         catch (InterruptedException e)
          {
           System.err.println("interrupted waiting for pixels!");
           return new ByteArray(w,h);
           }
                if ((pg.status() & ImageObserver.ABORT) != 0)
        {
                 System.err.println("image fetch aborted or errored.");
         return new ByteArray(w,h);
        }
    System.out.print("...ok.\ntransforming palette...");
    ByteArray out = new ByteArray(w,h);
    for (int i = 0; i < tmp.length; i++)
    {
     if ((tmp.length / (i+1)) % 8 == 0) System.out.print(".");
     out.source[i] = getNearestColor(tmp[i]);
    }
    System.out.println("ok.");
    return out;
   }
}