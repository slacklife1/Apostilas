package sodeike;
/*
 .class GrafikCanvas, used by GameOfLifeApplication
*/
import java.awt.*;
import java.awt.image.*;

public class GrafikPanel extends Panel implements Runnable {
        private boolean showFPS = true;
        private long firstFrame, frames, fps;
        public Thread running;
        public int sleep = 5;
        protected Image img;
        /**
        * this is the off screnn, @see ByteArray for more detail
        */
        public ByteArray offScreen;

        /**
        *Panel palette table
        */
        private BytePalette palette;

        protected GrafikPanel() {}

        /**
        * creating an x*y @see ByteArray
        * <br> set up palette, @see setPalette
        */
        public GrafikPanel(int x, int y) {
        try { offScreen = new ByteArray(x, y); }
        catch (Exception e) {
        System.out.println(e);
        System.exit(666);
        }
        setPalette();
        img=createImage(new MemoryImageSource(offScreen.width,
                                    offScreen.height,                                                                      palette.getIndexColorModel(),
                            offScreen.source,                                                                      0, offScreen.width));
        }

     /**
     * override this to use u're own @see BytePalette
     */
     public void setPalette()
     {
      palette = new BytePalette();
     }

     public void setPalette(BytePalette pal)
     {
      palette = pal;
     }

     public BytePalette getPalette()
     { return palette; }

     public void setFPS(boolean activate)
     { showFPS = activate; }

     /**
     * resizeing GrafikPanel and Parent to origin size
     */
     public void originSize()
     {
        Container par = getParent();
        Insets insets = par.getInsets();
        resize(offScreen.width, offScreen.height);
        par.resize(offScreen.width + insets.left + insets.right,
                  offScreen.height + insets.top + insets.bottom);
     }

    /**
    * called by thread automaticly
    */
    public final void update(Graphics g)
    {
       Rectangle r = getBounds();
       int sy = r.height;
       int sx = r.width;
       img.flush();
       g.drawImage(img,0,0,sx,sy,null);
       if (showFPS) {
         frames++;
         fps = (frames*10000) / (System.currentTimeMillis()-firstFrame);
         g.drawString(fps/10 + "." + fps%10 + " fps", 2, r.height - 2);
      }
    }

    public void stop()
    {
     if (running != null)
      { running.stop(); }
    }

    public void start()
    {
     if (running == null) {
        firstFrame=System.currentTimeMillis();
        frames = 0;
        running = new Thread(this);
        running.start();
       }
    }
    /**
    * will be frequently called in the main loop
    * override this to define ur'e draw-stuff
    * @see ByteArray
    */
    public void draw() {}

    /**
    * main loop, calls <code>draw()</code>
    *<br> @see draw
    */
    public final void run ()
    {
     running.setPriority(Thread.MIN_PRIORITY);
     while (running != null) {
      draw();
      repaint();
      try {running.sleep(sleep);}
      catch (Exception e) {System.out.println(e);}
     }
    }
    public Dimension getPreferredSize() {
        return offScreen.size();
    }

    public Dimension getMinimumSize() {
        return offScreen.size();
    }


    public Dimension getMaximumSize() {
        return offScreen.size();
    }

}