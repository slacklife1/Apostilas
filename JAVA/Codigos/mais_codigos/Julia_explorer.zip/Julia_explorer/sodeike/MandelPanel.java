package sodeike;

import java.lang.Math;
import java.awt.*;

public class MandelPanel extends GrafikPanel
 {

  public double skalX = 1.0/60.0;
  public double skalY = 1.0/60.0;
  public int iterationsTiefe = 128;
  public Complex c;
 //---------------CONSTRUcTOR------------------------------------------
 public MandelPanel ()
 {
  super(128,128);
  c=new Complex(0.0, -0.5);
 }
 public MandelPanel (int x, int y)
 {
  super (x,y);
  c = new Complex(-0.6, 0.6);
 }

 public MandelPanel (int x, int y, Complex c)
 {
  super (x,y);
  this.c = c;
 }

 public MandelPanel (int x, int y, Complex c, int it)
 {
  super (x,y);
  iterationsTiefe = it;
  this.c = c;
 }

 //---------------M-A-I-N--L-O-O-P--------------------------------------
 public void draw ()
 {
  Complex z = new Complex(0.0, 0.0);
  for (int y = 0; y < offScreen.width; y++)
   for (int x = 0; x < offScreen.height; x++)
   {
    double curX = skalX * (double)(x - (offScreen.width >> 1));
    double curY = skalY * (double)(y - (offScreen.height >> 1));
    z.r = curX;
    z.im = curY;
    byte color = nrOfIterations(z, c, 9.0);
    offScreen.putPixel(x,y, color);
   }
 }

 private byte nrOfIterations(Complex z, Complex c, double obergrenze)
 {
 int iter = 0;
  while ((iter++ < iterationsTiefe) && (z.betrag() < obergrenze))
  {
    z = z.mul(z).add(c);
    //z = z.mul(z.add(c)); mittelpkt verschiebt sicht
    //z = z.mul(z.mul(z)).add(c);
    //z = z.mul(z.mul(z.mul(z.mul(z)))).add(c);
  }
  if (iter == iterationsTiefe)
   return 0;
  else
   return (byte)(256.0 / (double)iterationsTiefe * (double)iter);
 }

}