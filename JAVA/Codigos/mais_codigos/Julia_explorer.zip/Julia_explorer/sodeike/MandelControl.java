package sodeike;

import java.awt.event.*;
import java.awt.Rectangle;

public class MandelControl extends MandelPanel {
  int mouseX, mouseY;

  class MouseMotionListener
  extends MouseMotionAdapter
  {
    private MandelControl par;
    public MouseMotionListener(MandelControl p)
    {
     super();
     par = p;
    }
    public void mouseDragged(MouseEvent event)
    {
      int x = event.getX();
      int y = event.getY();
      Rectangle r = par.getBounds();
      par.mouseX = (int)(((double)x / (double)r.width) * (double)par.offScreen.width);
      par.mouseY = (int)(((double)y / (double)r.height) * (double)par.offScreen.height);
      par.c = new Complex((double)(par.mouseX - (par.offScreen.width >> 1)) * par.skalX,
                     (double)(par.mouseY - (par.offScreen.height >> 1)) * par.skalX);
    }
  }

 class MyMouseAdapter extends MouseAdapter
 {
  private MandelControl par;
  public MyMouseAdapter (MandelControl p)
  {
   super();
   par = p;
  }
  public void mousePressed(MouseEvent event)
  {
   int _x = event.getX();
   int _y = event.getY();
   Rectangle r = par.getBounds();
   par.mouseX = (int)(((double)_x / (double)r.width) * (double)par.offScreen.width);
   par.mouseY = (int)(((double)_y / (double)r.height) * (double)par.offScreen.height);
   par.c = new Complex((double)(par.mouseX - (par.offScreen.width >> 1)) * par.skalX,
              (double)(par.mouseY - (par.offScreen.height >> 1)) * par.skalX);
  }
 }
 public void draw()
 {
  super.draw();
  offScreen.line(offScreen.width >> 1, 0, offScreen.width >> 1, offScreen.height-1, (byte)16);
  offScreen.line(0, offScreen.height >> 1, offScreen.width-1, offScreen.height >> 1, (byte)16);
  offScreen.line(mouseX, 0, mouseX, offScreen.height-1, (byte)32);
  offScreen.line(0, mouseY, offScreen.width-1, mouseY, (byte)32);
  offScreen.putPixel((offScreen.width >> 1) - (int)(1.0/skalX), offScreen.height >> 1,(byte)63);
  offScreen.putPixel((offScreen.width >> 1) + (int)(1.0/skalX), offScreen.height >> 1,(byte)63);
  offScreen.putPixel(offScreen.width >> 1, (offScreen.height >> 1) - (int)(1.0/skalY),(byte)63);
  offScreen.putPixel(offScreen.width >> 1, (offScreen.height >> 1) + (int)(1.0/skalY),(byte)63);
 }

 public MandelControl (int x, int y, Complex c, int it)
 {
  super (x,y,c,it);
  addMouseMotionListener(new MouseMotionListener(this));
  addMouseListener (new MyMouseAdapter(this));
 }
}