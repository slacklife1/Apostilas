package sodeike;

/**
 * ByteArray
 * a simple Byte[] - class including some basic pixel operations ()
 * such as put,-getPixel(), drawLine, draeCircle ect.
 * 14.02.01
*/

import java.awt.Dimension;

public class ByteArray {
   /**
   *<br> this is the Byte[], its public for more flexibility (f.e. u wanna get
   *<br> a faster access: <code>BytewArrayObj.source[y*width + x]=oolor</code>)
   *<br> but be careful manipulating it, width and height
   *<br> has to be changed correctly too
   */
   public byte [] source;
   public int width, height;

   /**
   * source.size().width, size.height
   */
   public Dimension size() {
    return new Dimension(width, height);
   }

  /**
  * to get a copy of any byte[] data
  */
  public static void copy(byte []src, byte []dest)
  {
          System.arraycopy(src,0, dest, 0, src.length);
  }

  public static void copy(ByteArray src, ByteArray dest)
  {
          System.arraycopy(src.source,0, dest.source, 0, src.source.length);
  }

   private byte[] getCopy()
   {
    byte []tmp = new byte[source.length];
    System.arraycopy(source, 0, tmp, 0, source.length);
    return tmp;
   }

   //-------------------------PIXEL-MANIPULATION----------------------------------
   /**
   * <br>set everz pixel to a single color
   * <br>note: java offers no possibility to do this
   * <br>      in a fast way like <code>setMem(scr, value, length)</code>.
   * <br>      <code>java.util.Array.fill(scr, value)</code> is doing this pixel by pixel!!
   * <br>      so if u frequently need a <code>setMem (value)</ode> do this:
   * <br>  <code>
   * <br>  ByteArray view = new ByteArray(width, hegiht);
   * <br>  ByteArray background = new ByteArray(width, height);
   * <br>  background.set(0);
   * <br>  ....
   * <br>  loop {
   * <br>    ByteArray.copy(background, view);
   * <br>    draw(view);
   * <br>  } </code>
   * <br>
   */
   public void set(byte color) {
    for (int i = 0; i < source.length; i++)
     source[i]=color;
   }

   /**
   * to calculate an offset, note: it also can be outside the value source.lenght!!
   */
   public int offset(int x, int y) {
        return (y * width) + x;
  }
  /**
  * thought for testing, because very slow - but secure
  * f.e. putPixel(pixelsIn[], offset(x,y), color)
  */
  public byte getPixel(int offset) {
          if (offset >= 0 && offset < source.length)
                  return source[offset];
          else return 0;
  }

  public byte getPixel(int x, int y) {
     int offset = (y * width) + x;
          if (offset >= 0 && offset < source.length)
                  return source[offset];
          else return 0;
  }

  public void putPixel(int x, int y, byte color) {
     int offset = (y * width) + x;
          if (offset >= 0 && offset < source.length) source[offset] = color;
  }

  public void putPixel(int offset, byte color) {
          if (offset >= 0 && offset < source.length) source[offset] = color;
  }

  public void line(int x,int y,int x1,int y1,byte c)
  {
   int LgDelta, ShDelta, Cycle, LgStep, ShStep, DTotal, hDelta;
   LgDelta = x1-x;
   ShDelta = y1-y;
   if (LgDelta < 0) {
    LgDelta=-LgDelta;
    LgStep=-1;
   }else LgStep=1;
   if (ShDelta < 0) {
    ShDelta=-ShDelta;
    ShStep=-1;
   }else ShStep=1;
   if (ShDelta < LgDelta) {
    Cycle=(LgDelta >> 1);
    while (x != x1) {
    putPixel(x, y, c);
    Cycle += ShDelta;
    if (Cycle > LgDelta) {
     Cycle -= LgDelta;
     y += ShStep;
    }
   x += LgStep;
  }
  putPixel(x,y,c);
 } else {
  Cycle = (ShDelta >> 2);
  hDelta = LgDelta; LgDelta = ShDelta; ShDelta = hDelta;
  hDelta = LgStep; LgStep = ShStep; ShStep = hDelta;
  while (y!=y1) {
   putPixel(x,y,c);
   Cycle += ShDelta;
   if (Cycle > LgDelta) {
    Cycle -= LgDelta;
    x += ShStep;
   }
  y += LgStep;
  }
  putPixel(x,y,c);
  }
 }
   protected ByteArray() {
   }

   /**
   * generate a source array width * height
   */
   public ByteArray(int width, int height) {
    this.width = width;
    this.height = height;
    source = new byte[width * height];
   }

   /**
   * usin' a <code>Dimension</code> object
   */
   public ByteArray(Dimension size) {
    this.width = size.width;
    this.height = size.height;
    source = new byte[width * height];
   }

   /**
   * <br>clone constructor
   * <br>copy every pixel
   */
   public ByteArray(ByteArray src) {
    source = src.getCopy();
    width = src.size().width;
    height = src.size().height;
   }
}