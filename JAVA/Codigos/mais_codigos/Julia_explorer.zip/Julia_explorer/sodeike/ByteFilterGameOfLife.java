package sodeike;

/**
 * <br>game of life, conway ruls needs to know a special color (color of element of life)
 * <br>09.02.2001
*/
public class ByteFilterGameOfLife extends ByteFilter {
        public byte color=1;
        public byte bgColor = 0;
        public byte [][] umgebung = new byte[3][3];
        public long nrCells = 0;

        public ByteFilterGameOfLife (ByteArray dataIn) {
                super(dataIn);
        }

        public ByteFilterGameOfLife (ByteArray dataIn, byte color) {
                super(dataIn);
                this.color = color;
        }

        public ByteFilterGameOfLife (ByteArray dataIn, byte color, byte bgColor) {
                super(dataIn);
                this.color = color;
        this.bgColor = bgColor;
        }

        /**
        * note: uses filter ruls from input[] to output[] !!
        */
        public void calc () {
                int summe = 0;
        int width = pixelsIn.size().width;
        int height = pixelsIn.size().height;

                for(int y=1;y<height-1;y++)
                        for(int x=1;x<width-1;x++)
                        {
                                summe = 0;
                                for (int i=-1; i<2; i++)
                                        for (int j=-1; j<2; j++)
                                        {
                                            umgebung[j+1][i+1] = pixelsIn.source[ x+i + (y+j)*width ];
                                                summe += pixelsIn.source[ x+i + (y+j)*width ];
                                        }

                                summe /= color;
                                if (umgebung[1][1]==bgColor)
                                {
                                        if (summe == 3) //set a lifeform??
                                        {
                                         pixelsOut.source[ y*width+x ] = color;
                                         nrCells++;
                                        }
                                }
                                else { if ( ((summe-1) >=4) || ((summe-1) <=1) ) //or kill one??
                                       {
                                        pixelsOut.source[ y*width+x ] = 0; //never forget these brackets!
                                        nrCells--;
                                       }
                                     }
                        }
        }

        public void preSetSquare(int a) {
            for(int y = ((height >> 1) - (a >> 1)); y < ((height >> 1) + (a >> 1)); y++)
              for(int x = ((width >> 1) - (a >> 1)); x < ((width >> 1) + (a >> 1)); x++)
              {
                        pixelsOut.source[y*width + x]=color;
                        pixelsIn.source[y*width + x]=color;
              }
        }

    /**
    *<br>      b
    *<br>   *-----*
    *<br> a |     |
    *<br>   |     |
    *<br>   |_____|
    *<br>
    */
        public void preSetRect(int w, int h) {
        preSetRect((width >> 1) - (w >> 1), (height >> 1) - (h >> 1), w,h);
        }

        public void preSetRect(int x0, int y0, int w, int h) {
            for(int y = y0; y < y0+h; y++)
              for(int x = x0; x < x0+w; x++)
                        pixelsIn.putPixel(x,y, color);
        }

    /**
    * call <code>obj.preStep(stepHeight, nrOfSteps)</code>
    * presetting a step :
    * <br>                o  -
    * <br>               oo   | -- stepHeight
    * <br>              ooo  -
    * <br>             ooo
    * <br>             oo
    * <br>             o
    * <br>             |__|
    * <br>           nrOfSteps
    */
        public void preSetSteps(int stepHeight, int nSteps) {
         int mx = width >> 1;
         int my = height >> 1;
         preSetSteps(mx, my, stepHeight, nSteps);
    }

        public void preSetSteps(int x0, int y0, int stepHeight, int nSteps) {
         y0 += (nSteps >> 1); //center it
         for(int i = - (nSteps >> 1); i < (nSteps >> 1); i++) {
            for(int j = - (stepHeight >> 1); j < (stepHeight >> 1); j++)
                   {
                        pixelsIn.putPixel(i + x0, y0 + j, color);
                        pixelsOut.putPixel(i + x0, y0 + j, color);
                   }
         y0--;
        }
    }

        public void preSetCross(int stepHeight, int nSteps) {
       preSetCross(width >> 1, height >> 1, stepHeight, nSteps);
    }

        public void preSetCross(int mx0, int my0, int stepHeight, int nSteps) {
         int y0 = my0 + (nSteps >> 1); //centerit
         int y1 = my0 - (nSteps >> 1); //centerit
         for(int i = - (nSteps >> 1); i < (nSteps >> 1); i++) {
            for(int j = - (stepHeight >> 1); j < (stepHeight >> 1); j++) {
                        pixelsIn.putPixel(i + mx0, y0 + j, color);
                        pixelsIn.putPixel(i + mx0, y1 + j, color);
                        pixelsOut.putPixel(i + mx0, y0 + j, color);
                        pixelsOut.putPixel(i + mx0, y1 + j, color);
            }
         y0--; y1++;
        }
    }

    /**
    * sets exactliy n random pixel
    */
    public void preSetRandom(int nr) {
       preSetRandom (3,3, width-3, height-3, nr);
    }

    /**
    * draw n pixels in the spec. rect
    *<br> screen:
    *<br>  |--------------------|
    *<br>  |                    |
    *<br>  |   (x0,y0)____      |
    *<br>  |       |pixel|      |
    *<br>  |       |     |height|
    *<br>  |       |_____|      |
    *<br>  |         width      |
    *<br>  |____________________|
    */
    public void preSetRandom(int x0, int y0, int width, int height, int nr) {
     int x,y;
     if (width*height < nr) {

     }
       while (nr > 0) {
          x = (int)(Math.random()*width);
          y = (int)(Math.random()*height);
          if ( pixelsOut.getPixel(x0 + x, y0 + y) == bgColor ){
            pixelsIn.putPixel(x0 + x, y0 + y, color);
            pixelsOut.putPixel(x0 + x, y0 + y, color);
            nr--;
          }
       }
    }

    public void preSetSechsEck (int a)
    {
     preSetSechsEck(width >> 1,height >> 1, a);
    }

    public void preSetSechsEck(int x, int y, int a)
    {
     pixelsIn.line (x - (a>>1), y - a, x + (a>>1), y - a, color);
     pixelsIn.line (x - (a>>1), y + a, x + (a>>1), y + a, color);
     pixelsIn.line (x - (a>>1), y - a, x - a, y, color);
     pixelsIn.line (x + (a>>1), y - a, x + a, y, color);
     pixelsIn.line (x - (a>>1), y + a, x - a, y, color);
     pixelsIn.line (x + (a>>1), y + a, x + a, y, color);
     pixelsOut.line (x - (a>>1), y - a, x + (a>>1), y - a, color);
     pixelsOut.line (x - (a>>1), y + a, x + (a>>1), y + a, color);
     pixelsOut.line (x - (a>>1), y - a, x - a, y, color);
     pixelsOut.line (x + (a>>1), y - a, x + a, y, color);
     pixelsOut.line (x - (a>>1), y + a, x - a, y, color);
     pixelsOut.line (x + (a>>1), y + a, x + a, y, color);
    }

    public void countCells()
    {
     nrCells = 0;
     int width = pixelsIn.size().width;
     int height = pixelsIn.size().height;
      for(int off=0;off<height*width;off++)
         if (pixelsOut.source[off] == color) nrCells++;
    }
}