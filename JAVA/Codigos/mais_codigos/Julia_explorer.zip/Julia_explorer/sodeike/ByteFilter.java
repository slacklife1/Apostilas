/*
allgemeine java grafik-routinen
*/

package sodeike;

/**
 * <br>ByteFilter to manipulate Byte-Data array
 * <br>avoid frequently creating a new FilterObject in a loop
 * <br>use Filter.calc()
 * <br>09.02.2001
 .
*/
public abstract class ByteFilter extends Filter{
  /**
  * <br> pixelsIn --&gt calc() --&gt pixelsOut
  * <br> pixelsIn --&gt calc() --&gt pixelsIn this way is also possible
  */
  public ByteArray pixelsIn, pixelsOut;

  protected ByteFilter () {
  }

  /**
  * <br>uses ByteArray to filter, need to know the width.
  * <br>height will be calculated automaticly
  * <br>
  * <br>-note: the intern data[] is not a copy of dataInput[]
  * <br>      it may have a strange effekt in opposit to
  * <br>      your intentions if u dont realize
  * <br>
  * <br>input[] --&gt Filter.calc() --&gt output[]
  */
  public ByteFilter (ByteArray dataInput) {
      width = dataInput.size().width;
      height = dataInput.size().height;
          pixelsIn = dataInput;
          pixelsOut = new ByteArray(dataInput.size());
  }

  /**
  * <br>generate a new ByteFilter object
  * <br>@see pixelsIn
  * <br>@see pixelsOut
  */
  public ByteFilter (int width, int height) {
      this.width = width;
      this.height = height;
             pixelsIn = new ByteArray(width, height);
          pixelsOut = new ByteArray(width, height);
  }

  public abstract void calc();
}