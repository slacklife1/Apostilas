import javax.swing.JFrame;
import sodeike.*;//using ver 0.04

public class MandelTest extends JFrame
{
 public MandelTest (int x, int y, Complex c, int iterationsTiefe)
 {
  setTitle ("Julia explorer - press mouse & move");

  MandelControl mPanel = new MandelControl (x,y, c, iterationsTiefe);
  mPanel.skalX = mPanel.skalY = 1.0/70;
  getContentPane().add (mPanel);
  mPanel.start();
 }

 public static void main(String a[]) {
  MandelTest app = new MandelTest(256, 256, new Complex(-0.4, 0.6),64);
  app.pack();
  app.setVisible (true);
  //www.cs.uni-magdeburg.de/~sodeike
 }
}