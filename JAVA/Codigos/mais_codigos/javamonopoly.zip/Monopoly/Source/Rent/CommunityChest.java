package Rent;

import Card.*;

public class CommunityChest extends Landlord
{

  public CommunityChest()
  {
    super();
  }

  public int calculateRent(Card aCard)
  {
      // Process the community chest card and return the amount of money owed or
      // received.
    return 0;
  }

}