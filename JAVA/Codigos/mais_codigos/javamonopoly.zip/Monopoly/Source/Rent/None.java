package Rent;

public class None extends Landlord
{

  public None()
  {
    super();
  }

  public int calculateRent()
  {
    return 0;
  }

}