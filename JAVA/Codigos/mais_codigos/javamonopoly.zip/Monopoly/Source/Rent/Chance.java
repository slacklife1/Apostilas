package Rent;

import Card.*;

public class Chance extends Landlord
{

  public Chance()
  {
    super();
  }

  public int calculateRent(Card aCard)
  {
      // Process the chance card and return the amount of money owed or
      // received.
    return 0;
  }

}