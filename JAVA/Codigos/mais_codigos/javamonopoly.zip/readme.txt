JavaMonopoly.zip

Version 1.4
Author: Tom Heagy

This zip file contains everything necessary to either run the JavaMonopoly program
or build it via the source files and included jar files (code libraries).

A set of user documentation is included in the form of html pages.  To access this
documentation, point your browser to the Monopoly\Docs\index.htm file.  There is
alternatively a Word doc that includes the same documentation.


=======================================================
*** Notes for JavaMonopoly ***

written by: Thomas R. Heagy Jr.
Copyright (c) 1998 Thomas R. Heagy Jr.
Monopoly is copyrighted by Parker Brothers (I think)

Brief History:
I was hearing really great things about this new programming language called Java.  Even though I'm not a coffee drinker I was still intrigued enough to want to learn the language.  My introduction into Object Oriented Programming was with Borland's Object Pascal and C++.  I also spent a lot of time writing code in PowerBuilder.

The way I've learned new languages over my 20 plus years in the software industry, is to write a game or two.  I first wrote "Monopoly" in Pascal back in 1986 for the Microsoft DOS platform (non-graphical).  I started to write it again in the early ninties with Visual Basic, but I abandoned it before finishing.  When Java came along, Monopoly was the perfect game to write because it lended itself very well towards a simple Object Oriented interface and it would require that I utilize a wide variety of language features.

Working primarily on weekends and some evenings, it took me about 2 months to write.  If it weren't for the very useful Java Community bulleting boards and forums, it would have taken me much longer.  My greatest disappointment is that I was never able to find source code for a completed program [that was more complex than "Hello Java World"].  This is exactly why I decided to make the program available for free.  My hope is that you and fellow Java colleagues will find it educational and entertaining.

Having said that- let me also point out that I was "learning" Java when I wrote this application.  Looking back now [years later], I would do quite a few things differently.  Unfortunately, I don't have time to go back and rewrite it now, not to mention that "it works" and I enjoy playing it more than the idea of rewriting it.  Maybe in another 10 years with the NEXT language...

I'm very curious how this little experiment of mine will be received so if you feel so inclined, you could "pay me for my efforts" by emailing me with some basic information.  Please include some or all of the following:

Your Name:
Location (City/State/Country):
Affiliation (Company or School):
Age:
Years spent in Software Development:
Years spent in Java Development:
Any questions or comments about my code/game:

Please e-mail me at tom.heagy@mindspring.com

Thanks for your attention.  Have fun playing JavaMonopoly!

-Tom


=======================================================
License Agreement for JavaMonopoly

This is the section that usually contains a bunch of legal mumbo-jumbo.  As I do not have the money to give to a lawyer (nor do I have the desire to), I'll put this as simply as possible.  For this piece of software that I call JavaMonopoly please...

1. Don't claim that you wrote it.
2. Don't sell it!

What can you do???
1. Use it for your own education.
2. Use it for your own entertainment and the entertainment of anyone you know.
3. Modify it as long as you don't distribute it after you change it.
4. Tell all your friends what a cool game it is.
5. Tell everyone that Java is a great programming language!
6. Don't sue me.

Credits:
The last time I checked- "Parker Brothers" held the copyright and trademark for the game of Monopoly.  All the images, cards, and game flow is credited to Parker Brothers (unless someone else owns the copyright).  All the program code is credited and copyrighted to me (Thomas R. Heagy Jr.).

Final Thoughts:
Just remember that you got this for free so don't abuse the opportunity to share in the Freeware industry.

Thanks,

-Tom Heagy
tom.heagy@mindspring.com



