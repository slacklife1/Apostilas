Link Scroller Applet V1.40
--------------------------
Date: 1st September 1998
Author: Adam Sheik
Company: Celerity Design
E-Mail: code@celerity.demon.co.uk
WWW: www.celerity.demon.co.uk


What does the program do?
-------------------------
The applet shows vertically scrolling messages on your web
pages.  Each message consists of a heading and body text.  Each
message may also have a URL linked to it, activated when the user
clicks on the applet.
The applet is ideal for advertising links, products or simply
to convey information in a visually appealing way.

How to view the program:
------------------------
Open the file LinkScroller.htm file in any Java enabled web browser.
View Bar.htm to see available HTML parameters

Important files
---------------
LinkScroller.class \	
TextReader4.class   |== need to be together in the same directory	
Shareware.class	    |
LinkScroller.txt   / *Please note the format of Linkscroller.txt below

LSReadme.txt        >======= this file, please include it if you are sending the program to someone!

LinkScroller.htm \ 
Page.htm 	  \ 
features.htm	   \ 	
limitations.htm     >======= sample HTML files
payment.htm        /
Bar.htm           /   

Usage notes
-----------

Storing the applet in a single shared directory:
	To use the applet when the class files are located in a sub-directory
	use the following HTML: <APPLET CODEBASE="YOURDIR" CODE="StarWords.clss"> 

Linkscroller.txt format (may be any filename, passed to the applet via
	the <PARAM NAME=FILENAME VALUE="linkscroller.txt"> tag.  The text file
	MUST be located within the same directory as the .class files!

	--top of file
	Title text 1 all on one line
	Body text 1 all on one line
	URL link for this message (optional)
	Target frame name for this message (optional)
	-repeat this block of 4 lines as many times as you like...
	-end of file

Using HTML tags within title and body text:
	Currently only <BR> is supported to force a new line.  This tag must have
	spaces either side -eg:  "Split <BR> this <BR> sentence <BR> up."

The sample Bar.htm source code shows all available
parameters for random message order, centre justification etc.

Usage Restrictions
------------------
Feel free to add this applet to your own non-commercial web pages.
For commercial sites, permission is NOT given to publish the applet
on your site - you may use the unregistered version for evaluation only
and then contact me to obtain the licensed version.

It would be appreciated if you would add the following
HTML next to the applet code:
<! AUTHOR=Adam Sheik>
<! E-MAIL = code@celerity.demon.co.uk>
<! WWW = http://www.celerity.demon.co.uk>

As this version is unregistered it is limited 
to 8 pages of messages - after showing those it will display
a page of copyright information and then loop round.

Please get in touch if you would like a licensed version!
