import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.text.DateFormat;
import java.util.*;


public class Client extends JPanel {

 JLabel theLabel;
 private static int ncon; //pokazuje da li je vec povezan na server
 private String s=new String();
 private String p=new String();
 public JTextArea htmlTextArea  = new JTextArea(10,20);
 public JTextField tfServer = new JTextField("localhost",15);
 public JTextField tfPort = new JTextField("9000",4);
 JEditorPane  serPreview = new JEditorPane();
 String server = new String();
 private Socket socket;
 private DataOutputStream dout;
 public void sendMessage() {
 DateFormat date;
 Date tmpdate=new Date();
 date= DateFormat.getDateTimeInstance();
 String sdate = date.format(tmpdate);
 String title = naslov.getText().trim();
 String body = htmlTextArea.getText().trim();
 String server = socket.getInetAddress().toString();
 System.out.println(server);
		//body.replaceAll("\n","<br>");
try {
	// Send it to the server
	//dout.writeUTF( date.toGMTString());
	
	dout.writeUTF( sdate );
	dout.writeUTF( server + tfPort.getText());
	dout.writeUTF( title );
	dout.writeUTF( body );
	} catch( IOException ie ) { System.out.println( ie ); }
	}
 
  

  public Client() {
        String initialText = "<html>\n<head>\n</head>\n<body>\nTelo vesti\n</body>\n</html>\n";
 
	//	htmlTextArea = new JTextArea(10, 20);
        htmlTextArea.setText(initialText);
        JScrollPane scrollPane = new JScrollPane(htmlTextArea);

        serPreview.setContentType("text/html");  //postavlja se tip za ucitavanje
        serPreview.setText(initialText); //postavlja se inicijalni text

	  // dugme prikaz vesti i akcija pridruzena njemu (izmena preview-a vesti)
		ImageIcon IcoPreview = new ImageIcon("prikazi.gif");
		JButton prikaziBTN = new JButton("Prikazi vest",IcoPreview);
        prikaziBTN.setMnemonic(KeyEvent.VK_C);
        prikaziBTN.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    serPreview.setText(htmlTextArea.getText());
                } catch (Throwable exc) {
                    JOptionPane.showMessageDialog(
                            Client.this,
                            "HTML koji ste uneli nevalja.");
                }
            }
        });
     //--- kraj dugmeta preview
     
  // dugme za slanje vesti
		ImageIcon IcoPosalji = new ImageIcon("posalji.gif");
		JButton posaljiBTN = new JButton("Posalji",IcoPosalji);
        posaljiBTN.setMnemonic(KeyEvent.VK_C);
        posaljiBTN.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               try {
					    sendMessage(); //u metodu mozda odakle da uzima
					// po mogucnosti prikazuje progress bar
                } catch (Exception exc) {
                    /*JOptionPane.showMessageDialog(
                            Client.this,
                            "Vest nije poslana.");*/
						exc.printStackTrace();
                }
            }
        });
     //--- kraj dugmeta slanje vesti




	  //rad na levom panelu - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
//        leftPanel.setLayout(new BorderLayout());
		leftPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(
                    "Unos vesti"),
                BorderFactory.createEmptyBorder(10,10,10,10)));
        JLabel Lnaslov = new JLabel("Naslov vesti:");
		leftPanel.add(Lnaslov);
		leftPanel.add(naslov);


  		 JLabel Ltelo= new JLabel("Telo vesti");
		leftPanel.add(Ltelo);
		leftPanel.add(scrollPane);
		leftPanel.add(Box.createRigidArea(new Dimension(0,10)));
        leftPanel.add(prikaziBTN);
	//- kraj rada
    
		
      //rad na desnom panelu - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createTitledBorder("Izgled vesti"),
                        BorderFactory.createEmptyBorder(10,10,10,10)));
        
		JScrollPane scrollPane2 = new JScrollPane(serPreview);
		rightPanel.add(scrollPane2);
		rightPanel.add(posaljiBTN);
	 //kraj rada na desnom panelu - - - - - - - - - - - - - - - - - -- -  -- -  -- -  -
		
		JPanel downPanel = new JPanel();
		downPanel.setLayout(new BorderLayout());
		downPanel.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createTitledBorder("Server za vesti"),
                        BorderFactory.createEmptyBorder(10,10,10,10)));
		downPanel.add(tfServer,BorderLayout.WEST);
		downPanel.add(tfPort,BorderLayout.CENTER);
		//dugme za konektovanje na server
		ImageIcon IcoServer = new ImageIcon("Server.gif");
		JButton serverBTN = new JButton("Konektuj",IcoServer);
     	serverBTN.setMnemonic(KeyEvent.VK_C);
        serverBTN.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               try {		if(ncon==0){
								s=tfServer.getText();
								p=tfPort.getText();
								ncon++;
					connect(tfServer.getText(),tfPort.getText());
							}else{
								JOptionPane.showMessageDialog(
                            Client.this,
                            "Vec ste povezani na server: "+ s+ " port "+p+"\n Molim startujte drugi News editor za drugi server");
							}
						} catch (Exception exc) { exc.printStackTrace();
                	}
            }
        });
     //--- kraj dugmeta konektovanje
		downPanel.add(serverBTN,BorderLayout.EAST);
		
		setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        add(downPanel,BorderLayout.PAGE_START);
		add(leftPanel,BorderLayout.WEST);
        add(Box.createRigidArea(new Dimension(10,0)));
        add(rightPanel,BorderLayout.EAST);
}
public void connect(String server, String port){
	Integer TCP_PORT = new Integer(port);
		int cport;
		cport=TCP_PORT.intValue();
	try {
		// Initiate the connection
		socket = new Socket( server, cport);
		// We got a connection! Tell the world
		System.out.println( "povezan na "+socket );
		// Let's grab the streams and create DataInput/Output streams
		// from them
		dout = new DataOutputStream( socket.getOutputStream() );
		// Start a background thread for receiving messages
		//new Thread( this ).start();
		} catch( IOException ie ) { System.out.println( ie ); }
	}
    public static void main(String args[]) {
        Client cc = new Client();
		JFrame f = new JFrame("News Editor");
		f.getContentPane().add(new Client());
		f.pack();
		f.setSize(480, 400);
		f.setVisible(true);
	   	
				
	}
	 
     JTextField naslov = new JTextField(10);

}
	
