import java.io.*;
import java.net.*;
public class ServerThread extends Thread {
	private Server server;
	private Socket socket;
	
	public ServerThread( Server server, Socket socket ) {
		this.server = server;
		this.socket = socket;
		start();
	}
	public void run() {
		try {
			DataInputStream din = new DataInputStream( socket.getInputStream() );
				while (true) {
					String date = din.readUTF();
					String nserver = din.readUTF();
					String title = din.readUTF();
					String body = din.readUTF();
					body.replaceAll("\n"," ");
					try {
					sleep(10 + Math.round((Math.random()+100) * 100));
					}catch (InterruptedException ie) {ie.printStackTrace();}
					synchronized (server) {
					server.updateNews(date,nserver,title,body);
					}
				}
		} catch( EOFException ie ) {
		} catch( IOException ie ) { ie.printStackTrace(); }
		finally {
			server.removeConnection( socket );
		}
	}
}
