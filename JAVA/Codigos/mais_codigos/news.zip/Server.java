import java.io.*;
import java.net.*;
import java.util.*;
public class Server
{
	private ServerSocket ss;
	private boolean invalidate;
	private Hashtable outputStreams = new Hashtable();
	public static RandomAccessFile xmlfile;
	private String n[][]=new String [50][4]; //lista vesti
	private int i; //popunjeno vesti
	private String tmp=new String();
	public Server( int port ) throws IOException {
		int tmp=readFromFile(xmlfile);
		new ServerThread2( this );
		listen( port );
	}
	private void listen( int port ) throws IOException {
		ss = new ServerSocket( port );
		System.out.println( "Server aktivan na "+ss );
		while (true) {
			Socket s = ss.accept();
			System.out.println( "Konekcija od "+s );
			DataOutputStream dout = new DataOutputStream( s.getOutputStream() );
			outputStreams.put( s, dout );
			new ServerThread( this, s );
		}
	}
	public Enumeration getOutputStreams() {
		return outputStreams.elements(); //ovde cuva listu konektovanih klijenata
	}
public void removeConnection( Socket s ) {
		synchronized( outputStreams ) {
			System.out.println( "Uklanjam" + s );
			outputStreams.remove( s );
			try {
				s.close();
			} catch( IOException ie ) { System.out.println( "Error closing "+s ); ie.printStackTrace();	}
		}
	}
public void sendNews(){ //salje kompletne vesti svim klijentima
		int j;
		j=i;
		j--;
		synchronized( outputStreams ) {
			for (Enumeration e = getOutputStreams(); e.hasMoreElements(); ) {
				DataOutputStream dout = (DataOutputStream)e.nextElement();
				try {
						int k=0;
							while(j>=0){
								tmp=tmp.valueOf(i);
								dout.writeUTF(tmp);
								while(k<4){
									dout.writeUTF( n[j][k] ); //loop za slanje periodicno vesti
									k++;
									
							}
							if(j==0 && invalidate) {
								dout.writeUTF("invalidate");
								invalidate=false;
							}
							else{
								dout.writeUTF("valid");
							}
							k=0;
							j--;
						}
				} catch( IOException ie ) { System.out.println( ie ); ie.printStackTrace(); }
			}
		
			
		 }
	}
public int readFromFile(RandomAccessFile file) {
	String line,tmp;
	i=0;
	try {
	line=file.readLine(); //ucitan prvi red XML - oznaka
	line=file.readLine(); //komentar
	line=file.readLine(); //ucita <news application>
	while (true) {
		line=file.readLine().trim();
		if(line.matches("</news application>")){return 0;}
			while(!line.matches("</news>")) {
		line=file.readLine().trim(); //<date>
		line=file.readLine().trim(); //vrednost datuma
		this.n[i][0]=line;
		line=file.readLine().trim(); //</datum>
		line=file.readLine().trim(); //<server>
		line=file.readLine().trim(); //value
		this.n[i][1]=line; //value;
		line=file.readLine().trim();//</server>
		line=file.readLine().trim(); //<title>
		line=file.readLine().trim(); //value
		this.n[i][2]=line; //value;
		line=file.readLine().trim();//</title>
		line=file.readLine().trim();//<body>
		line=file.readLine().trim(); //zbog </body>
			tmp="";
			while(!line.matches("</nbody>")) {
				tmp+=line;
				line=file.readLine().trim(); //value
			}
		this.n[i][3]=tmp;
		line=file.readLine().trim(); //news
		i++;
			System.out.println(i);
		}
	  }
	} catch (IOException io) { System.out.println( io);}
return 1;
}
public void saveToFile(RandomAccessFile file){
	synchronized (n){
		String line;
		int j;
		j=i;
		try{
		file.seek(0);
		while(file.getFilePointer()<file.length()){
		file.writeBytes(" ");
		}
		}catch(IOException io) {System.out.println(io);}
		j--;
		line="<?xml version=\"1.0\"?>"+"\n";
		line.trim();
		try{
		file.seek(0);
		file.writeBytes(line);
		line="<!-- xml fajl je ogranicen na po 1 red unosa -->"+"\n";
		line.trim();
		file.writeBytes(line);
		line="<news application>"+"\n";
		line.trim();
		file.writeBytes(line);
		while(j>=0){
		line="<news>"+"\n";
		line.trim();
		file.writeBytes(line);
		line="<date>"+"\n";
			line.trim();
			file.writeBytes(line);
			line=n[j][0];
			line+="\n";
			line.trim();
			file.writeBytes(line);
			line="</date>"+"\n";
			line.trim();
			file.writeBytes(line);
		line="<nserver>"+"\n";
			line.trim();
			file.writeBytes(line);
			line=n[j][1];
			line+="\n";
			line.trim();
			file.writeBytes(line);
			line="</nserver>"+"\n";
			line.trim();
			file.writeBytes(line);
		line="<ntitle>"+"\n";
			line.trim();
			file.writeBytes(line);
			line=n[j][2];
			line+="\n";
			line.trim();
			file.writeBytes(line);
			line="</ntitle>"+"\n";
			line.trim();
			file.writeBytes(line);
		line="<nbody>"+"\n";
			line.trim();
			file.writeBytes(line);
			line=n[j][3];
			line+="\n";
			line.trim();
			file.writeBytes(line);
			line="</nbody>"+"\n";
			line.trim();
			file.writeBytes(line);
		line="</news>"+"\n";
		line.trim();
		file.writeBytes(line);
		j--;
		}
		line="</news application>";
		line.trim();
		file.writeBytes(line);
		} catch(IOException io) { System.out.println(io);}
	}
}
public void updateNews(String date, String server, String title, String body){
		//System.out.println(i);
		n[i][0]=date;
		//System.out.println("1-"+date);
		n[i][1]=server;
		//System.out.println("1-"+n[i][1]);
		n[i][2]=title;
		//System.out.println("1-"+title);
		n[i][3]=body;
		//System.out.println("1-"+body);
		i++;
		invalidate = true;
		saveToFile(xmlfile);
		
	}
// Upotreba: java Server <port>
 static public void main( String args[] ) throws Exception {
		int port = Integer.parseInt( args[0] );
		String fname;
		fname="ServerNews"+args[0]+".xml";
		try {
			xmlfile = new RandomAccessFile(fname, "rwd");
	    } catch(FileNotFoundException nf) { System.out.println(nf); }
		new Server( port );
	}
}
