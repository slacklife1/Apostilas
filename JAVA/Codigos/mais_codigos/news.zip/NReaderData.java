import java.io.*;
import java.text.DateFormat;
import java.util.*;

public final class NReaderData {
	private String n[][]=new String[50][4]; /*prvi element niza je dimenzija, drugi
 ima 3 polja, date, title, body*/
	private int i,up;
	private static RandomAccessFile file;

public int readFromFile() {
	String line,tmp;
	i=0;
	try {
		file = new RandomAccessFile("News.xml", "rwd");
		//readFromFile(xmlfile);
	    } catch(FileNotFoundException nf) { System.out.println(nf); }
	try {
	line=file.readLine(); //ucitan prvi red XML - oznaka
	line=file.readLine(); //komentar
	line=file.readLine(); //ucita <news application>
	while (true) {
		line=file.readLine().trim();
		if(line.matches("</news application>")){
			try{
				file.close();
			}catch(IOException io) {io.printStackTrace();}
			return 0;
		}
	while(!line.matches("</news>")) {
		line=file.readLine().trim(); //<date>
		line=file.readLine().trim(); //vrednost datuma
		this.n[i][0]=line;
		line=file.readLine().trim(); //</datum>
		line=file.readLine().trim(); //<server>
		line=file.readLine().trim(); //value
		this.n[i][1]=line; //value;
		line=file.readLine().trim();//</server>
		line=file.readLine().trim(); //<title>
		line=file.readLine().trim(); //value
		this.n[i][2]=line; //value;
		line=file.readLine().trim();//</title>
		line=file.readLine().trim();//<body>
		line=file.readLine().trim(); //zbog </body>
			tmp="";
			while(!line.matches("</nbody>")) {
				tmp+=line;
				line=file.readLine().trim(); //value
			}
		this.n[i][3]=tmp;
		line=file.readLine().trim(); //news
		i++;
		}
	  }
	} catch (IOException io) { System.out.println( io);}
	try{
		file.close();
	}catch(IOException io) {io.printStackTrace();}
return 1;
}
public void saveToFile(){
		String line;
		try {
			file = new RandomAccessFile("News.xml", "rwd");
			//readFromFile(xmlfile);
	    } catch(FileNotFoundException nf) { System.out.println(nf); }
		try{
			file.seek(0);
			while(file.getFilePointer()<file.length()){
			file.writeBytes(" ");
			}
		}catch(IOException io) {System.out.println(io);}
		i--;
		line="<?xml version=\"1.0\"?>"+"\n";
		line.trim();
	try{
		file.seek(0);
		file.writeBytes(line);
		line="<!-- xml fajl je ogranicen na po 1 red unosa -->"+"\n";
		line.trim();
		file.writeBytes(line);
		line="<news application>"+"\n";
		line.trim();
		file.writeBytes(line);
		while(i>=0){
		line="<news>"+"\n";
		line.trim();
		file.writeBytes(line);
		line="<date>"+"\n";
			line.trim();
			file.writeBytes(line);
			line=n[i][0];
			line+="\n";
			line.trim();
			file.writeBytes(line);
			line="</date>"+"\n";
			line.trim();
			file.writeBytes(line);
		line="<nserver>"+"\n";
			line.trim();
			file.writeBytes(line);
			line=n[i][1];
			line+="\n";
			line.trim();
			file.writeBytes(line);
			line="</nserver>"+"\n";
			line.trim();
			file.writeBytes(line);
		line="<ntitle>"+"\n";
			line.trim();
			file.writeBytes(line);
			line=n[i][2];
			line+="\n";
			line.trim();
			file.writeBytes(line);
			line="</ntitle>"+"\n";
			line.trim();
			file.writeBytes(line);
		line="<nbody>"+"\n";
			line.trim();
			file.writeBytes(line);
			line=n[i][3];
			line+="\n";
			line.trim();
			file.writeBytes(line);
			line="</nbody>"+"\n";
			line.trim();
			file.writeBytes(line);
		line="</news>"+"\n";
		line.trim();
		file.writeBytes(line);
		i--;
		}
		line="</news application>";
		line.trim();
		file.writeBytes(line);
		file.close();
	} catch(IOException io) { System.out.println(io);}
	}
public void tSortiraj(){
	if(up==1){
		this.tSortirajDown();
		up=0;
	}
	else {
		this.tSortirajUp();
		up=1;
	}
}
public void sSortiraj(){
	if(up==1){
		this.sSortirajDown();
		up=0;
	}
	else {
		this.sSortirajUp();
		up=1;
	}
}
public synchronized void tSortirajUp(){
	String tmp[][]=new String[1][4];
	System.out.println("up in");
	Date dtmp1,dtmp2;
	DateFormat dftmp1,dftmp2;
	long ltmp1,ltmp2;
	int j,k=3,l;
		j=i;
		i=i-2;
		for(l=j;l>=0;l--){
		while(i>=0){
		dftmp1=DateFormat.getDateTimeInstance();
		dftmp2=DateFormat.getDateTimeInstance();
		dtmp1 = new Date();
	    dtmp2 = new Date();
			try{
	    dtmp1=dftmp1.parse(n[i][0]);
		dtmp2=dftmp2.parse(n[i+1][0]);
			}
				catch(java.text.ParseException pe) {System.out.println(pe);}
		if(dtmp2.compareTo(dtmp1)<0){
		  while(k>=0){
			 tmp[0][k]=n[i][k];
			 k--;
		  }
		  k=3;
		  while(k>=0){
			n[i][k]=n[i+1][k];
			k--;
		  }
		  k=3;
		  while(k>=0){
			n[i+1][k]=tmp[0][k];
			k--;
		  }
		  k=3;
		}
		i--;
	}
	i=j-2;
	}
	i=j;
}
public synchronized void tSortirajDown(){
	String tmp[][]=new String[1][4];
	System.out.println("down in");
	Date dtmp1,dtmp2;
	DateFormat dftmp1,dftmp2;
	long ltmp1,ltmp2;
	int j,k=3,l;
		j=i;
		i=i-2;
		for(l=j;l>=0;l--){
		while(i>=0){
		dftmp1=DateFormat.getDateTimeInstance();
		dftmp2=DateFormat.getDateTimeInstance();
		dtmp1 = new Date();
	    dtmp2 = new Date();
			try{
	    dtmp1=dftmp1.parse(n[i][0]);
		dtmp2=dftmp2.parse(n[i+1][0]);
			}
				catch(java.text.ParseException pe) {System.out.println(pe);}
		if(dtmp2.compareTo(dtmp1)>0){
		  while(k>=0){
			 tmp[0][k]=n[i][k];
			 k--;
		  }
		  k=3;
		  while(k>=0){
			n[i][k]=n[i+1][k];
			k--;
		  }
		  k=3;
		  while(k>=0){
			n[i+1][k]=tmp[0][k];
			k--;
		  }
		  k=3;
		}
		i--;
	}
	i=j-2;
	}
	i=j;
}
public void sSortirajDown(){
	String tmp[][]=new String[1][4];
	int j,k=3,l;
		j=i;
		i=i-2;
		for(l=j;l>=0;l--){
		while(i>=0){
		if(n[i][1].compareTo(n[i+1][1])<0){
		  while(k>=0){
			 tmp[0][k]=n[i][k];
			 k--;
		  }
		  k=3;
		  while(k>=0){
			n[i][k]=n[i+1][k];
			k--;
		  }
		  k=3;
		  while(k>=0){
			n[i+1][k]=tmp[0][k];
			k--;
		  }
		  k=3;
		}
		i--;
	}
	i=j-2;
	}
	i=j;
}
public void sSortirajUp(){
	String tmp[][]=new String[1][4];
	int j,k=3,l;
		j=i;
		i=i-2;
		for(l=j;l>=0;l--){
		while(i>=0){
		if(n[i][1].compareTo(n[i+1][1])>0){
		  while(k>=0){
			 tmp[0][k]=n[i][k];
			 k--;
		  }
		  k=3;
		  while(k>=0){
			n[i][k]=n[i+1][k];
			k--;
		  }
		  k=3;
		  while(k>=0){
			n[i+1][k]=tmp[0][k];
			k--;
		  }
		  k=3;
		}
		i--;
	}
	i=j-2;
	}
	i=j;
}
public synchronized void setN(String date, String server, String title, String body){
		n[i][0]=date;
		System.out.println("1-"+date);
		n[i][1]=server;
		System.out.println("1-"+server);
		n[i][2]=title;
		System.out.println("1-"+title);
		n[i][3]=body;
		System.out.println("1-"+body);
		i++;
}
public synchronized String[][] getN(){
	return n;
}
public synchronized void invalidate(){
	i=0;
}
}
