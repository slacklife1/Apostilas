import javax.swing.*;
import javax.swing.DefaultListSelectionModel;
import javax.swing.table.*;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import com.borland.jbcl.layout.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.text.DateFormat;
import java.lang.Integer;

public class NReader extends JPanel implements Runnable {

 public String n[][]=new String[50][4]; /*prvi element niza je dimenzija, drugi
 ima 3 polja, date, title, body*/

 private String kolone[]={"Datum vesti","Server","Naslov"};
 private String initialText = "Cekam da se vesti skinu sa servera";
 private String nhost;
 private boolean ALLOW_ROW_SELECTION = true;
 private JLabel theLabel;
 private JEditorPane  serPreview = new JEditorPane();
 private JTextField tfrhost = new JTextField("localhost",15);
 private JTextField tfrsocket = new JTextField("9000");
 private JTable table;
 private Socket socket;
 private int i; //globalna promenljiva za kretanje kroz niz vesti
 //private DataOutputStream dout;
 public DataInputStream din;
 public NReaderData nd = new NReaderData();
 
 public NReader() {
        serPreview.setContentType("text/html");  //postavlja se tip za ucitavanje
        serPreview.setText(initialText); //postavlja se inicijalni text

  // dugme za slanje vesti
		ImageIcon IcoSnimi = new ImageIcon("Snimi.gif");
		JButton snimiBTN = new JButton("Snimi",IcoSnimi);
		// dugme prikaz vesti i akcija pridruzena njemu (izmena preview-a vesti)
		snimiBTN.setMnemonic(KeyEvent.VK_C);
        snimiBTN.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
					nd.saveToFile();
                } catch (Throwable exc) {
                    JOptionPane.showMessageDialog(NReader.this,"neuspelo snimanje u datoteku.");
                }
            }
        });
        ImageIcon IcoSortiraj = new ImageIcon("TSortiraj.gif");
		JButton sortirajBTN = new JButton("Sortiraj po vremenu",IcoSortiraj);
     	sortirajBTN.setMnemonic(KeyEvent.VK_C);
        sortirajBTN.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               try { 		nd.tSortiraj();
							table.repaint(150);
					} catch (Exception exc) { exc.printStackTrace();
                }
            }
        });
	 
	    ImageIcon icoSSortiraj = new ImageIcon("SSortiraj.gif");
		JButton sortirajSBTN = new JButton("Sortiraj po serveru",icoSSortiraj);
     	sortirajSBTN.setMnemonic(KeyEvent.VK_C);
        sortirajSBTN.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent d) {
               try {   nd.sSortiraj();
					   table.repaint(150);
					} catch (Exception exc3) { exc3.printStackTrace();
                }
            }
        });
     //--- kraj dugmeta slanje vesti


	 //dugme za konektovanje na server
		ImageIcon IcoServer = new ImageIcon("Server.gif");
		JButton serverBTN = new JButton("Konektuj",IcoServer);
     	serverBTN.setMnemonic(KeyEvent.VK_C);
        serverBTN.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               try {
					
					connect(tfrhost.getText(),tfrsocket.getText());
					} catch (Exception exc) { exc.printStackTrace();
                	}
            }
        });
     //--- kraj dugmeta konektovanje



	  //rad na levom panelu - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
		leftPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Vesti koje su pristigle"),
                BorderFactory.createEmptyBorder(10,10,10,10)));
		table = new JTable(nd.getN(),kolone);
		table.repaint(150);
		/*listener za kad se klikne mishom na row tabele*/
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	    if (ALLOW_ROW_SELECTION) { // true navedeno
            ListSelectionModel rowSM = table.getSelectionModel();
            rowSM.addListSelectionListener(new ListSelectionListener() {
                public void valueChanged(ListSelectionEvent e) {
                    
                    if (e.getValueIsAdjusting()) return;
                    
                    ListSelectionModel lsm = (ListSelectionModel)e.getSource();
                    if (lsm.isSelectionEmpty()) {
                        //System.out.println("No rows are selected.");
                    } else {
                        int selectedRow = lsm.getMinSelectionIndex();
                        n=nd.getN();
						serPreview.setText(n[selectedRow][3]);
                                           
                    }
                }
            });
        } else {
            table.setRowSelectionAllowed(false);
        }
		/*gotov listener za tabelu*/
		
		TableColumn column;
		column = table.getColumnModel().getColumn(1);
		column.setPreferredWidth(10);
		column = table.getColumnModel().getColumn(1);
		column.setPreferredWidth(180);
		JScrollPane scrollPane = new JScrollPane(table);
		leftPanel.add(scrollPane);
		//- kraj rada
    
		
      //rad na desnom panelu - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setPreferredSize(new Dimension(300,150));
		rightPanel.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createTitledBorder("Sadrzaj vesti"),
                        BorderFactory.createEmptyBorder(10,10,10,10)));
        
		JScrollPane scrollPane2 = new JScrollPane(serPreview);
		rightPanel.add(scrollPane2);
		//sortirajBTN.setAlignmentX(133);
		sortirajBTN.setAlignmentY(150);
		//snimiBTN.setAlignmentX(50);
		snimiBTN.setAlignmentY(110);
		rightPanel.add(sortirajBTN);
		rightPanel.add(sortirajSBTN);
		rightPanel.add(snimiBTN);
		//kraj rada na desnom panelu - - - - - - - - - - - - - - - - - -- -  -- -  -- -  -
		
		//donji panel------------------------------------
		JPanel downPanel = new JPanel();
		downPanel.setLayout(new FlowLayout());
		downPanel.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createTitledBorder("Server za vesti"),
                        BorderFactory.createEmptyBorder(10,10,10,10)));
		
	 	tfrhost.setSize(90,10);
		downPanel.add(tfrhost);
		downPanel.add(tfrsocket);
		downPanel.add(serverBTN);
		//-----------------------------------------------
		//container panel, for better layout
		JPanel containerPanel = new JPanel();
		containerPanel.setLayout(new BorderLayout());
		containerPanel.add(downPanel,BorderLayout.NORTH);
		leftPanel.setMaximumSize(new Dimension (10,10));
		containerPanel.add(leftPanel,BorderLayout.CENTER);
		//-----------------------------------------------
		setLayout(new BorderLayout());
		add(containerPanel,BorderLayout.WEST);
        add(rightPanel,BorderLayout.CENTER);
}
public static void main(String args[]) {
        NReader cc = new NReader();
	    JFrame f = new JFrame("News Reader");
		f.getContentPane().add(cc);
		f.pack();
		f.setSize(800, 580);
		f.setVisible(true);
	//	cc.run();
	//int g = cc.readFromFile(cc.xmlfile);
    	//cc.SaveToFile(cc.xmlfile);
	}
public void run() {
int j,ibrvesti;
ibrvesti=0;
String m[][]=new String[50][4];
System.out.println("Thread created with i value of"+i);
		j=i;
	try {
		while (true) {
			String sbrvesti = din.readUTF();
            String date = din.readUTF();
			String server = din.readUTF();
			String title = din.readUTF();
			String body = din.readUTF();
			Integer TMP = new Integer(sbrvesti);
			ibrvesti=TMP.intValue();
				if(j<ibrvesti){
				m[j][0]=date;
				m[j][1]=server;
				m[j][2]=title;
				m[j][3]=body;
				j++;
				nd.setN(date, server, title, body);
				}
			String invalidate = din.readUTF();
				if(invalidate.matches("invalidate"))
				   {
					System.out.println("invalidated");
					nd.invalidate();
					j=0;
					}
			}
	} catch( IOException ie ) { System.out.println( ie ); }
}
public void connect(String chost, String cport) {
		Integer TCP_PORT = new Integer(cport);
		int port;
		port=TCP_PORT.intValue();
		try {
		socket = new Socket( chost, port);
		System.out.println( "connected to "+socket );
		din = new DataInputStream( socket.getInputStream() );
		new Thread( this ).start();
		//dout = new DataOutputStream( socket.getOutputStream() );
		// Start a background thread for receiving messages
	} catch (IOException io) { System.out.println(io); io.printStackTrace();}
}}
