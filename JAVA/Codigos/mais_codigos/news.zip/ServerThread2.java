import java.io.*;
import java.net.*;
public class ServerThread2 extends Thread {
	private Server server;
	
	public ServerThread2( Server server) {
		this.server = server;
		start();
	}
	
	public void run() {
	//implementirati random vremenski period (5 sekundi)
		while(true){
			try{
			sleep(10 + Math.round((Math.random()+100) * 10));
			}catch (InterruptedException ie) { ie.printStackTrace();}
			server.sendNews();
		}
	}
}
