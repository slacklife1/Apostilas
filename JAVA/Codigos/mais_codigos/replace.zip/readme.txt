Search.java
---------------------------------------------------------------------------------
The class Search is a utility to search or manipulate files based on their text content. 
This class can either be used as a component (nested in an application), or as a stand alone utility program, run from command line (for more info on how to use, type java Search in cmd window). The following basic functionalities can be perfomred with this single java class file: 
-Search for files or folders according to their name, and list the results.
-Search for files according to their name and/or content.
-Replace a given string pattern with another string pattern within one or more files that satisfy some criterias given (listed previously).
-Perform any of the previously mentioned tasks with files compressed into a zip (compatible) file found within the path. In other words, it acts as it would (of course it works more effectively) first unpack all files from all compressed files found in the path, then perform the given task, then repack all files.
Although it could have been broken into smaller classes, the primary goal was to create a single file utility application. The idea of component use came later 

How to use:
1. jdk 1.3 or greater must be installed.
2. If you have the source code only, compile.
3. Either put the .class file in a directory that is in the classpath, or run from the current directory by typing "java Search" in your command line window.
If everything is ok, a brief description must come up on how to use.