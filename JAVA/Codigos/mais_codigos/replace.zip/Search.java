////////////////////////////////////////
// Search v085                        //
//                                    //
// This single class is a file search //
// engine and a string replace engine //
// with an ability to search and      //
// replace in files compressed into   //
// zip (jar, ...) file                //
//                                    //
// for more desc., run:               //
// >javac Search.java                 //
// >java Search                       //
//                                    //
// ...                                //
// due to a bug in                    //
// java.util.zip.ZipInputStream       //
// (Bug Id  4244499), check this URL: //
// "http://developer.java.sun.com/    //
// developer/bugParade/bugs/          //
// 4244499.html"                      //
// winzip 8.0 compressed entries      //
// using unicode chars throw an       //
// IllegalArgumentException           //
//                                    //
// of course there is no warranty on  //
// the functionality or behaviour of  //
// this application:                  //
// use it at your own risk...         //
//                                    //
// -----------------------a:zoltankesz//
//              zoltankesz@hotmail.com//
////////////////////////////////////////
////////////////////////////////////////
import java.io.*;///////////////////////
import java.util.*;/////////////////////
import java.util.zip.*;/////////////////
////////////////////////////////////////
/**
 * The class <code>Search</code> is a utility to search or manipulate files
 * based on their text content.
 * <p>
 * This class can either be used as a component (nested in an application), or
 * as a stand alone utility program, run from command line (for more info on how
 * to use, type java Search in cmd window). The following basic functionalities
 * can be perfomred with this single java class file:
 * <ul>
 * <li>Search for files or folders according to their name, and list the results
 * <li>Search for files according to their name and/or content
 * <li>Replace a given string pattern with another string pattern within one or more files
 * that satisfy some criterias given (listed previously)
 * <li>Perform any of the previously mentioned tasks with files compressed into a
 * zip (compatible) file found within the path. In other words, it acts as
 * it would (of course it works more effectively) first unpack all files from all 
 * compressed files found in the path, then perform the given task, then repack all files.
 * </ul>
 * <p>
 * Although it could have been broken into smaller classes, the primary goal
 * was to create a single file utility application. The idea of component use came
 * later
 *
 * @author  Zoltan Keszthelyi
 * @version 085, Oct/15/2002
 */
public class Search extends java.lang.Thread{

    // wild card char in filename
    public static final char WC = '?';

    // wild card char in content search
    public static final char WCC = '#';

    // file extensions than ZipInputStream can handle
    public static final String[] KNOWN_ARCHIVES = new String[]{"jar","zip","war","ear"/*, "gz", "gzip", "tar"*/};

    // if true, the main func listens for 'e' + enter (and cancels scan if pressed)
    public static final boolean CAN_EXIT_WHILE_SCANNING = true;

    // debug info and errors are written to System.out
    boolean debug = false;

    // how many results to display before 'hit enter' text is displayed
    public final static int PAGE_SIZE = 20;

    //--------------------------------------------------------------------------

    public final static String KNOWN_ARCHIVES_LIST;
    public final static String SEP;
    public static final int RUN_AS_THREAD = 1;
    public static final int RUN_AS_APP = 2;

    public final int DEFAULT_BUFFER_SIZE = 8 * 1024; // 8k
    public static final int LINE_LENGTH = 80;

    public static final int MUST_CONTAIN = 0;
    public static final int MUST_NOT_CONTAIN = 65500;
    public static final int CAN_CONTAIN = -1;

    public int run_type = RUN_AS_APP;
    
    private long filenameNo = 0;

    private ZipInputStream zip = null;
    private ZipEntry zEntry= null;

    private final boolean runStandAlone = true;
    private final String ws = "*";
    public volatile boolean isScanning = true;
    private Search fserver = null;
    private char[][] trans = new char[1][];
    private char[][] knownArchivesL = null;
    private char[][] knownArchivesU = null;
    private String startPath = null;
    private String queryString = null;
    private String fileString = null;
    private String toFile = null;
    private String oldString = null;
    private char[] oldArr;
    private int oldLen;
    private String newString = null;
    private char[] newArr;
    private int newLen;
    private int tempFileName = 0;

    protected ArrayList resultFileNames = new ArrayList(100);
    protected ArrayList fileValue = new ArrayList(100);
    private ArrayList list1 = null;
    private ArrayList list2 = null;
    private ArrayList changedFiles = new ArrayList();
    private ArrayList entryNames = new ArrayList();
    private ArrayList positions;
    private ArrayList zipEntriesToChange = new ArrayList();
    private String[] queries = null;
    private int[] states = null;

    private long dataQuant = 0;
    private ArrayList parts = new ArrayList(10);
    private boolean show;
    private boolean noStar;
    private boolean starts = false;
    private boolean ends = false;
    private volatile boolean repackInProgress = false;
    private int resultNo = 0;
    private int noOfFiles = 0;

    // cg ChanGe flag indicates there is a change job to do
     private boolean cg = false;
    // Realtime Result display: write hits to screen during scan process
    private boolean rr = false;
    // descending order sort;
    private boolean de = false;
    // ascending order sort; (if nor as, nor de, then sort by hitcount)
    private boolean as = false;
    // indicates multiple query
    private boolean mc = false;
    // content search flag
    private boolean ct = false;
    // no recurse flag
    private boolean nr = true;
    // count hit flag (only if one expression query, count occurance of exp.)
    private boolean ch = false;
    // case sensitive filename filter flag
    private boolean cs = false;
    // case sensitive in Content search flag
    private boolean cc = false;
    // filename filter flag
    private boolean fs = false;
    // expressions must be found in order specified in parameter line
    private boolean io = false;
    // write search result to file
    private boolean tf = false;
    // search compressed file's content
    private boolean sc = false;

// constructors  ---------------------------------------------------------------
    static{
        
        SEP = System.getProperty("line.separator");
        String archs = "";
        for (int i = 0; i < KNOWN_ARCHIVES.length; i++){
            archs = archs + "'" + KNOWN_ARCHIVES[i] + "', ";
        }
        if (archs.length() > 1 ){
            archs = archs.substring(0, archs.length() - 2);
        }
        KNOWN_ARCHIVES_LIST = archs;
        
    }
    
//------------------------------------------------------------------------------
    /**
     * This blank construcor is to be used when used as component. 
     * <code>initialize()</code> has to be called before each job is started.
     */
    public Search(){
        // 
    }
    
//------------------------------------------------------------------------------    
    /**
     * This method has to be called between each search or replace job
     * is executed. How and what is performed afterwards depends on
     * the params passed to this method.
     * <p>
     * These are the recomended steps to follow when Search is used as component:
     * 1. Create new instance with no arguments passed, 2. call <code>initialize()</code>
     * with the parameters set to the job to be performed, 3. call <code>runAsComp()</code>
     * which actually performs the job according to the params and flags set
     * with <code>initialize</code> arguments. 4. retrieve result of the job with
     * <code>getFiles</code> and <code>getValues</code>. When a different task is
     * to be carried out, simply call <code>initialize()</code> again and set the 
     * instance of Search for the new constrains.
     *
     * @param   fileString    File name, can note a single file or can mask more files
     *                          with '*' and '?' wildcards (as used in windows)
     * @param   queries       one or more strings (starting with '+', '-' or as is) that will
     *                          be searched within a file or files
     * @param   startPath    the directory that holds files to be searched or replaced (if none
     *                          than property 'user.dir' is used)
     * @param   toFile        if a file name is specified here (existing or not), the results
     *                          of any activity will be written to that file instead of System.out
     * @param   oldString   if the job involves changing content of a file or files, than
     *                          oldString is what will be replaced.
     * @param   newString   same as above but this is what will be inserted in place of oldString
     *
     * @param   nr  flag: Not Recursive, if set to false, than all files in all 
     *                          subdirectories of startPath will also be searched
     * @param   ch flag: Count hits, if the job is content search and only <code>queries.length</code>
     *                          is one, than the result ArraList obtained from <code>getValues()</code>
     *                          will hold how many times string queries[0] was found in each file
     * @param   cs  flag: Case Sensitive, fileString is case sensitive
     *
     * @param   cc  flag: Case sensitive Content, conten search is case sensitive
     *
     * @param   io  flag: In Order, if queries holds multiple strings, than those that started with '+'
     *                      has to be found in a file in the order they are listed in queries
     * @param   sc  flag: Search Archive, if true, archives supported by java.util.zip.ZipInputStream
     *                      will be opened and files within will be searched (either by file name, or content).
     *                      Careful with this flag! It is also used when the job is string replace.
     * @param   de  flag: Descending Order, sort results in than way.
     *
     * @param   as  flag: Ascending Order, ... (if de || as == false, than results are sorted by hit count)
     *
     * @param   rr  flag: Realtime Results, used only in app mode, when a file is found satisfying criterias
     *                      it is written to System.out even though search might run for another minute. If
     *                      false, results are sorted and displayed at the end of the job. Does not have effect
     *                      when used as component.
     */
    public void initialize(String fileString,
                                    String[] queries,
                                    String startPath,
                                    String toFile,
                                    String oldString,
                                    String newString,
                                    boolean nr,
                                    boolean ch,
                                    boolean cs,
                                    boolean cc,
                                    boolean io,
                                    boolean sc,
                                    boolean de,
                                    boolean as,
                                    boolean rr) {

        this.resultFileNames.clear();
        this.fileValue.clear();

        this.nr = nr;
        this.ch = ch;
        this.cs = cs;
        this.cc = cc;
        this.io = io;
        this.sc = sc;
        this.de = de;
        this.as = as;
        this.rr = rr;

        // filename filter
        if (fileString != null && fileString.length() > 0){
            this.fileString = fileString;
            prepareQuery();
            this.fs = true;
        }else{
            this.fileString = "";
        }
        // multiple queries / single query
        if (queries != null && queries.length > 0){
            this.queries = new String[queries.length];
            this.states = new int[queries.length];
            setQueriesFlags(queries, this.queries, this.states);
            if (queries.length == 1){
                if (queries[0].length() > 0){
                    this.queryString = this.queries[0];
                    this.ct = true;
                    this.mc = false;
                }
            }else{
                this.ct = true;
                this.mc = true;
                this.ch = false;
            }
        }else{
            this.queryString = null;
        }
        // output file
        if (toFile != null && toFile.length() > 0){
            this.tf = true;
            this.toFile = toFile;
        }

        if (startPath != null && startPath.length() > 0){
            this.startPath = startPath;
        }else{
            this.startPath = System.getProperty("user.dir");
        }
        // change - old / new text
        if (oldString != null &&
            oldString.length() > 0 &&
            newString != null &&
            newString.length() > 0){

            this.oldString = oldString;
            this.oldLen = oldString.length();
            this.oldArr = oldString.toCharArray();
            this.newString = newString;
            this.newArr = newString.toCharArray();
            this.newLen = newString.length();
            this.cg = true;
            if (!ct){
                ct = true;
                queryString = oldString;
            }else if (ct && !mc){
                if ((!cc && queryString.equalsIgnoreCase(oldString)) ||
                        (cc && queryString.equals(oldString))){
                    //
                }else{
                    mc = true;
                    queries = new String[]{oldString, queryString};
                    states = new int[]{Search.MUST_CONTAIN, Search.MUST_CONTAIN};
                }
            }else if (mc){
                boolean queriesContOld = false;
                for (int i = 0; i < queries.length; i++){
                    if (queries[i].equals(oldString) || (!cc && queries[i].equalsIgnoreCase(oldString))){
                        queriesContOld = true;
                        break;
                    }
                }
                if (!queriesContOld){
                    String[] queries2 = new String[queries.length + 1];
                    int[] states2 = new int[states.length + 1];
                    for (int i = 0; i < queries.length; i++){
                        queries2[i] = queries[i];
                        states2[i] = states[i];
                    }
                    queries2[queries.length] = oldString;
                    states2[states.length] = Search.MUST_CONTAIN;
                    queries = queries2;
                    states = states2;
                }
            }
        }

        this.knownArchivesU = new char[KNOWN_ARCHIVES.length][];
        this.knownArchivesL = new char[KNOWN_ARCHIVES.length][];
        for (int i = 0; i < KNOWN_ARCHIVES.length; i++){
            this.knownArchivesU[i] = KNOWN_ARCHIVES[i].toUpperCase().toCharArray();
            this.knownArchivesL[i] = KNOWN_ARCHIVES[i].toLowerCase().toCharArray();
        }

    }
    
//------------------------------------------------------------------------------
    /**
     * Use this constructor when one instance of Search will performe only one job.
     * See <code>initialize()</code> for info on params
     */
    public Search (     String fileString,
                        String[] queries,
                        String startPath,
                        String toFile,
                        String oldString,
                        String newString,
                        boolean nr,
                        boolean ch,
                        boolean cs,
                        boolean cc,
                        boolean io,
                        boolean sc,
                        boolean de,
                        boolean as,
                        boolean rr) {
                            
        this.initialize (     fileString,
                                queries,
                                startPath,
                                toFile,
                                oldString,
                                newString,
                                nr,
                                ch,
                                cs,
                                cc,
                                io,
                                sc,
                                de,
                                as,
                                rr);
    }
//.. constructor  ==============================================================

// main  -----------------------------------------------------------------------
    public static void main(String[] args) throws Exception {

        if (args == null || args.length < 2){
            showHowTo();
        }

        String queryString = null;
        String fileString = null;
        String startPath = null;
        String toFile = null;
        String oldString = null;
        String newString = null;
        String[] queries = null;
        int[] states = null;
        boolean nr = true;
        boolean ch = false;
        boolean cs = false;
        boolean sc = false;
        boolean cc = false;
        boolean io = false;
        boolean de = false;
        boolean rr = false;
        boolean cg = false;
        boolean as = false;
        boolean debug = false;

        fr:
        for (int i = 0; i < args.length; i++){

            if (args[i].equalsIgnoreCase("-d")){
                if(args.length > i + 1){
                    startPath = args[i + 1];
                    File f = new File(startPath);
                    if (fileString == null && f.isFile()){
                        fileString = f.getName();
                        startPath = f.getParentFile().getAbsolutePath();
                    }
                }
            }
            if (args[i].equalsIgnoreCase("-f") || args[i].equalsIgnoreCase("-cf")){
                if (args[i].equalsIgnoreCase("-cf")){
                    cs = true;
                }else{
                    cs = false;
                }
                if (args.length > i){
                    fileString = args[i + 1];
                    File f = new File(fileString);
                    if (startPath == null && f.isFile()){
                        startPath = f.getParentFile().getAbsolutePath();
                        fileString = f.getName();
                    }
                }
            }
            if (args[i].equalsIgnoreCase("-c") || args[i].equalsIgnoreCase("-cc")){
                if (args[i].equalsIgnoreCase("-cc")){
                    cc = true;
                }else{
                    cc = false;
                }
                if (i + 1 >= args.length){
                    continue fr;
                }
                queries = new String[args.length - i - 1];
                states = new int[args.length - i - 1];
                String[] temp = new String[queries.length];
                System.arraycopy(args, i + 1, temp, 0, temp.length);
                queries = temp;
                break fr;
            }
            if (args[i].equalsIgnoreCase("-cg")){
                if (args.length > i + 2){
                    oldString = args[i + 1];
                    newString = args[i + 2];
                    cg = true;
                }
            }
            if (args[i].equalsIgnoreCase("-r")){
                nr = false;
            }
            if (args[i].equalsIgnoreCase("-ch")){
                ch = true;
            }
            if (args[i].equalsIgnoreCase("-or")){
                io = true;
            }
            if (args[i].equalsIgnoreCase("-sc")){
                sc = true;
            }
            if (args[i].equalsIgnoreCase("-as")){
                as = true;
                de = false;
            }
            if (args[i].equalsIgnoreCase("-de")){
                de = true;
                as = false;
            }
            if (args[i].equalsIgnoreCase("-rr")){
                rr = true;
            }
            if (args[i].equals("-debug")){
                debug = true;
            }
            if (args[i].equalsIgnoreCase("-tf")){
                if(args.length > i + 1){
                    toFile = args[i + 1];
                }
            }
        }

        Search search = new Search(fileString, queries, startPath, toFile, oldString, newString, nr, ch, cs, cc, io, sc, de, as, rr);
        search.setPriority(Thread.MIN_PRIORITY);
        search.debug = debug;
        Thread th = new Thread(search);
        
        // verify user's change request
        if (cg){
            System.out.println(SEP + "  WARNING, you have selected to change the content of one or more files");
            System.out.println("  with the above conditions:" + SEP);
            if (fileString != null){
                System.out.println("  - files: " + fileString);
            }
            if (startPath != null){
                System.out.print("  - in directory: " + startPath);
                if (!nr){
                    System.out.println(" (recursively)");
                }else{
                    System.out.println("");
                }
            }
            if (sc){
                System.out.print("  - within compressed files (" + KNOWN_ARCHIVES_LIST + ")" );
            }
            if (queries != null && queries.length > 0){
                System.out.println(SEP + "  - where file contains string(s):");
                for (int i = 0 ; i < queries.length; i++){
                    System.out.println("    '" + queries[i] + "'");
                }
            }
            System.out.println("  - change '" + oldString + "' to '" + newString + "'");
            // bla...
            System.out.print(SEP + SEP + "  Are you shure? ('y' + [enter] = yes) :");
            byte[] ver = new byte[10];
            System.in.read(ver);
            if (ver[0] != 'y' && ver[0] != 'Y'){
                System.exit(0);
            }
        }
        //..

        if (CAN_EXIT_WHILE_SCANNING){
            th.start();
            byte[] b = new byte[3];
            int avail;
            while(search.isScanning){
                try{Thread.sleep(500);}catch(Exception e){}
                if ((avail = System.in.available()) > 0){
                    System.in.read(b);
                    if (b[0] == 'e'){
                        while(search.repackInProgress){
                            System.out.print(".");
                        }
                        System.exit(0); /////////////////////////////   HERE: when exited, delete all temporary files
                    }
                }
            }
            System.exit(0);
        }else{
            search.runAsApp();
            System.exit(0);
        }

    }
    
    private void setQueriesFlags(String[] originalStrings, String[] queries, int[] states){

        int q = 0;
        if (originalStrings.length < 1){
            return;
        }
        for (int z = 0; z < originalStrings.length; z++){
            if (originalStrings[z].startsWith("+")){
                if (originalStrings[z].length() > 2){
                    String t = originalStrings[z].substring(1, originalStrings[z].length());
                    int index;
                    while((index = t.indexOf(WCC)) == 0){
                        t = t.substring(1, t.length());
                    }
                    while((index = t.lastIndexOf(WCC)) > -1){
                        t = t.substring(0, t.length() - 1);
                    }
                    queries[q] = t;
                    states[q] = Search.MUST_CONTAIN;
                    q++;
                }
            }else if (originalStrings[z].startsWith("-")){
                if (originalStrings[z].length() > 2){
                    String t = originalStrings[z].substring(1, originalStrings[z].length());
                    int index;
                    while((index = t.indexOf(WCC)) == 0){
                        t = t.substring(1, t.length());
                    }
                    while((index = t.lastIndexOf(WCC)) > -1){
                        t = t.substring(0, t.length() - 1);
                    }
                    queries[q] = t;
                    states[q] = Search.MUST_NOT_CONTAIN;
                    q++;
                }
            }else{
                String t = originalStrings[z];
                int index;
                while((index = t.indexOf(WCC)) == 0){
                    t = t.substring(1, t.length());
                }
                while((index = t.lastIndexOf(WCC)) > -1){
                    t = t.substring(0, t.length() - 1);
                }
                queries[q] = t;
                states[q] = Search.CAN_CONTAIN;
                q++;
            }
        }
    }

//------------------------------------------------------------------------------
    private static void showHowTo(){

        System.out.print(   SEP +
                            "file search utility v085 beta" + SEP +
                            SEP +
                            "  usage:" + SEP +
                            SEP +
                            "      >java Search [-opt1 -opt2 -...] [-tf \"to_file\"] [-f/-cf \"filename_filter\"]" + SEP +
                            "      [-d \"start dir\"] [-cg \"old\" \"new\"] [-c/-cc text1 [text2 text3 ...]]" + SEP +
                            SEP +
                            "    example 1:" + SEP +
                            SEP +
                            "      I want to search for a file named 'bambi.txt' within the current dir:" + SEP +
                            SEP +
                            "      >java Search -f \"bambi.txt\"" + SEP +
                            SEP +
                            SEP +
                            "    example 2:" + SEP +
                            SEP +
                            "      I want to search for files that contains the word 'Bambi', sort in hit" + SEP +
                            "      count order, start from 'c:\\somedir' recursively, and write the result" + SEP +
                            "      list into a file named 'kukika.txt' in a dir 'c:\\another_dir':" + SEP +
                            SEP +
                            "     >java Search -r -ch -tf \"c:\\another_dir\\kukika.txt\" -d c:\\somedir c Bambi" + SEP +
                            SEP +
                            "    example 3:" + SEP +
                            SEP +
                            "      I want to find files that contain any of the strings 'Zoli', 'Kati'," + SEP +
                            "      'fos' only those count that shure contain 'FileOutputStream', and shure" + SEP +
                            "      do not contain 'InputStream'. String comparison should be case sensitive" + SEP +
                            "      for both filename and query strings. I want to filter filenames to" + SEP +
                            "      '*.java'. I want to search recursively, and within all compressed files" + SEP +
                            "      found within the path (" + KNOWN_ARCHIVES_LIST + ")" + SEP +
                            SEP +
                            "      >java Search -sc -r -cf \"*.java\" -d \"somedir\" -cc zoli kati fos" + SEP +
                            "       +FileOutputStream -InputStream" + SEP +
                            SEP +
                            "  parameters:" + SEP +
                            SEP +
                            "      -f(-cf) \"filename\": file name filter (-cf for case sensitive)." + SEP +
                            "         '*' and '?' can be used." + SEP +
                            SEP +
                            "      -tf \"walid_path\\filename\" : write results to the specified file" + SEP +
                            SEP +
                            "      -d \"start dir\" : start searching from this directory" + SEP +
                            SEP +
                            "      -c(-cc) \"text1\" \"+text2\" \"-text3\" ... : (-cc for case sensitive) content" + SEP +
                            "         of files are searched for the strings specified after 'c'. " + SEP +
                            "         +text: text that must be in a file" + SEP +
                            "         -text: text that must not be in a file" + SEP +
                            "         text : text that ranks a file higher if found" + SEP +
                            "         Wildcard is '" + WCC + "' for 1 char." + SEP +
                            SEP +
                            "      -cg \"old_text\" \"new_text\" : ChanGes old_text to new_text in each files" + SEP +
                            "         that satisfy the other requirements (eg: filename filter, contains" + SEP +
                            "         other strings specified, etc...). If case sensitivity is required, " + SEP +
                            "         simply put a -cc (with or without more params) at the end of the " + SEP +
                            "         command." + SEP +
                            SEP +
                            "      careful! : -f, -dd and -tf takes the param that follows each " + SEP +
                            "      (ex: -f \"*.txt\"). All parameters after '-c' or '-cc' are taken as query" + SEP +
                            "      strings, therefore '-c' or '-cc' and its parameters must be at the end of" + SEP + 
                            "      the command." + SEP +
                            SEP +
                            "  options:" + SEP +
                            SEP +
                            "      -r  : Recursive directory search (default : not recursive)" + SEP +
                            "      -ch : Count (Hit) occurance of \"containing_txt\" in file (default : off)" + SEP +
                            "      -sc : Search in Compressed files(" + KNOWN_ARCHIVES_LIST + ")" + SEP +
                            "      -or : (if multiple query strings) must find them in specified ORder" + SEP +
                            "      -de : sort results in DEscending order" + SEP +
                            "      -rr : Real time Result (results are written to screen when found)" + SEP +
                            "      (-debug: debug info is written to screen when error found)" + SEP +
                            SEP +
                            SEP +
                            "                            please write your comments to zoltankesz@hotmail.com");
        System.exit(0);
    }

//------------------------------------------------------------------------------
    // runs through path specified and builds an array of files
    private void runThrough(File directory) throws Exception{

        try{

            int hit = 0;
            char[] arr = null;

            File[] itemNames = directory.listFiles();
            File file = null;

            if (itemNames == null){
                return;
            }
            for (int i = 0 ; i < itemNames.length ; i++){

                file = itemNames[i];

                if (sc && file.isFile() && isKnownArchive(file)){

                    processArchiveFile(file);

                }else if (file.isFile() && ct){

                    if (!fs || (fs && this.scanFileName(file))){

                        if (mc){
                            hit = this.scanFileMultipleContent(file, null);
                        }else{
                            hit = this.scanFile(file, null);
                        }
                        if (hit > 0){
                            if (cg){
                                hit = changeFile(file, null);
                                if (hit > 0){
                                    this.addToList(file, hit);
                                }
                            }else{
                                this.addToList(file, hit);
                            }
                        }

                    }

                }else if (file.isFile()){
                    if (fs){
                        noOfFiles++;
                        if (this.scanFileName(file)){
                            this.addToList(file, 1);
                        }
                    }
                }else{
                    if (fs){
                        boolean b = this.scanFileName(file);
                        if (b && !ct){
                            this.addToList(file, 1);
                        }
                    }
                    if (!nr){
                        runThrough(file);
                    }

                }

            }
        }catch (Exception e){
            if (debug){
                System.out.println("shit happens...");
                e.printStackTrace();
            }
            throw e;
        }
    }
    
//------------------------------------------------------------------------------
    private void repackArchive(File zf) throws Exception{
        
        this.repackInProgress = true;
        File f = null;
        ZipOutputStream zos = null;
        FileOutputStream fos = null;
        FileInputStream fis = null;
        ZipEntry z = null;
        ArrayList repackFiles = new ArrayList();
        ArrayList entries = new ArrayList();
        String tempEntry = null;

        try{
            zip = new ZipInputStream(new FileInputStream(zf));
            byte[] buf = new byte[DEFAULT_BUFFER_SIZE];
            int read = -1;
            // unzip all entries from zip
            wh:
            while((z = zip.getNextEntry()) != null){
                if (z.isDirectory()){
                    entries.add(z.getName());
                    repackFiles.add(null);
                }else{
                    for (int i = 0; i < entryNames.size(); i++){
                        if (z.getName().equals((String)entryNames.get(i))){
                            // skip
                            zip.closeEntry();
                            continue wh;
                        }
                    }
                    f = new File("_" + filenameNo++ + "_unchanged_archive_temp.search");
                    f.createNewFile();
                    fos = new FileOutputStream(f);
                    while((read = zip.read(buf)) > -1){
                        fos.write(buf, 0, read);
                    }
                    fos.close();
                    repackFiles.add(f);
                    entries.add(z.getName());
                }
                zip.closeEntry();
            }
            zip.close();
            zip = null;
            
            // repack changed files
            zos = new ZipOutputStream(new FileOutputStream(zf));
            for (int i = 0; i < changedFiles.size(); i++){
                
                f = (File)changedFiles.get(i);
                fis = new FileInputStream(f);
                zos.putNextEntry(new ZipEntry((String)entryNames.get(i)));
                
                while((read = fis.read(buf)) > -1){
                    zos.write(buf, 0, read);
                }
                fis.close();
                zos.closeEntry();
                f.delete();
            }
            // repack other files
            fr:
            for (int i = 0; i < repackFiles.size(); i++){
                
                f = (File)repackFiles.get(i);
                tempEntry = (String)entries.get(i);
                if (f == null){
                    zos.putNextEntry(new ZipEntry(tempEntry));
                    zos.closeEntry();
                    continue fr;
                }else{
                    fis = new FileInputStream(f);
                    zos.putNextEntry(new ZipEntry(tempEntry));

                    while((read = fis.read(buf)) > -1){
                        zos.write(buf, 0, read);
                    }
                    fis.close();
                    zos.closeEntry();
                    f.delete();
                }
            }
            zos.close();
            
        }catch (Exception e){
            if (changedFiles.size() > 0){
                for (int i = 0; i < changedFiles.size(); i++){
                    ((File)changedFiles.get(i)).delete();
                }
            }
            if (repackFiles.size() > 0){
                for (int i = 0; i < repackFiles.size(); i++){
                    f = (File)repackFiles.get(i);
                    if (f != null){
                        f.delete();
                    }
                }
            }
            try{
                if (fis != null){
                    fis.close();
                }
            }catch(Exception ex){}
            try{
                if (zip != null){
                    zip.closeEntry();
                    zip.close();
                }
            }catch(Exception ex){}
            try{
                if (zos != null){
                    zos.closeEntry();
                    zos.close();
                }
            }catch(Exception ex){}
            if (debug) e.printStackTrace();
            this.repackInProgress = false;
            throw new Exception("error in repackArchive(), " + e.getMessage());

        }
        this.repackInProgress = false;
        
    }
//------------------------------------------------------------------------------
    private void processArchiveFile(File file){

        int hit;
        int[] hits;
        Object[] zobj;
        try{

            zip = new ZipInputStream(new FileInputStream(file));
            changedFiles.clear();
            entryNames.clear();
            zipEntriesToChange.clear();
            while ((zEntry = zip.getNextEntry()) != null){

                if (ct && !zEntry.isDirectory()){

                    if (!fs || (fs && scanFileNameFromZip(zEntry))){
                        if (mc){
                            hit = this.scanFileMultipleContent(null, zEntry);
                        }else{
                            hit = this.scanFile(null, zEntry);
                        }
                        if (hit > 0){
                            if (cg){
                                zipEntriesToChange.add(zEntry.getName());
                            }else{
                                this.addArchToList(file, zEntry, hit);
                            }
                        }

                    }

                }else{
                    if (fs && !ct){
                        if (scanFileNameFromZip(zEntry)){
                            addArchToList(file, zEntry, 1);
                        }
                    }
                }
                //?
                zip.closeEntry();
            }
            zip.close();
            
            if (cg && zipEntriesToChange.size() > 0){
                
                zip = new ZipInputStream(new FileInputStream(file));
                Object[] array = this.zipEntriesToChange.toArray();
                zobj = new Object[array.length];
                hits = new int[array.length];
                while ((zEntry = zip.getNextEntry()) != null){
                    for (int i = 0; i < array.length; i++){
                        if (zEntry.getName().equals((String)array[i])){
                            hits[i] = changeFile(null, zEntry);
                            zobj[i] = zEntry;
                            zip.closeEntry();
                        }
                    }
                }
                zip.close();
                if (changedFiles != null && changedFiles.size() > 0){
                    // repack changed files to the original zip (or whatever) file
                    this.repackArchive(file);
                    for (int i = 0; i < array.length; i++){
                        if (hits[i] > 0){
                            this.addArchToList(file, (ZipEntry)zobj[i], hits[i]);
                        }
                    }
                }
                
            }
            
        }catch(Exception e){
            if (changedFiles.size() > 0){
                for (int i = 0; i < changedFiles.size(); i++){
                    ((File)changedFiles.get(i)).delete();
                }
            }
            try{
              zip.close();
            }catch(Exception e2){}
            if (debug){
                e.printStackTrace();
                System.out.println("->zip compression error in '" + file.getName() + "' :" + e.getMessage());
            }
            
        }catch(InternalError e){
            if (changedFiles.size() > 0){
                for (int i = 0; i < changedFiles.size(); i++){
                    ((File)changedFiles.get(i)).delete();
                }
            }
            try{
              zip.close();
            }catch(Exception e2){}
            if (debug) System.out.println("->zip compression error (InternalError) in '" + file.getName() + "' :" + e.getMessage());
        }
    }

//------------------------------------------------------------------------------
    private void addArchToList(File file, ZipEntry zEntry, int value){

        if (rr && !tf){
            System.out.println(value +
                        "      ".substring(0, 4 - String.valueOf(value).length()) +
                        file.getAbsolutePath() + "!" + zEntry.getName());
            if (resultFileNames.size() == 0){
                resultFileNames.add(0, " file(s) found");
                fileValue.add(0, String.valueOf(++resultNo));
            }else{
                resultFileNames.set(0, " file(s) found");
                fileValue.set(0, String.valueOf(++resultNo));
            }
        }else{
            this.resultFileNames.add("" + file.getAbsolutePath() + "!" + zEntry.getName());
            this.fileValue.add(String.valueOf(value));
        }

    }

//------------------------------------------------------------------------------
    private void addToList(File file, int value){

        if (rr && !tf){
            System.out.println(value +
                        "      ".substring(0, 4 - String.valueOf(value).length()) +
                        file.getAbsolutePath());
            if (resultFileNames.size() == 0){
                resultFileNames.add(0, " files(s) found");
                fileValue.add(0, String.valueOf(++resultNo));
            }else{
                resultFileNames.set(0, " file(s) found");
                fileValue.set(0, String.valueOf(++resultNo));
            }
        }else{
            this.resultFileNames.add(file.getAbsolutePath());
            this.fileValue.add(String.valueOf(value));
        }

    }

//------------------------------------------------------------------------------
    private int changeFile(File f, ZipEntry ze) throws Exception{

        boolean zr = false;
        FileReader r = null;
        FileWriter w = null;
        RandomAccessFile tw = null;
        FileReader tr = null;
        File tempf = null;
        long posTo = -1;
        long filePos = 0;
        int firstPos = 0;
        
        byte[] zbuf = new byte[DEFAULT_BUFFER_SIZE];
        char[] buf = new char[DEFAULT_BUFFER_SIZE];
        int read = -1;
        boolean hit = false;
        boolean continued = false;
        char[] oquery = oldString.toCharArray();
        char[] query = oldString.toUpperCase().toCharArray();
        char[] lquery = oldString.toLowerCase().toCharArray();
        if (oquery.length < 1){
            return 0;
        }
        char ofirstChar = oquery[0];
        char firstChar = query[0];
        char lfirstChar = lquery[0];
        int localCount = 0;
        int hitCount = 0;
        int queryLen = query.length;
        int u = 0;

        try{
            if (f == null && ze != null){
                zr = true;
                dataQuant += ze.getSize();
                noOfFiles++;
                tempf = new File ("_" + filenameNo++ + "_temp.search");
                tempf.createNewFile();
                tw = new RandomAccessFile(tempf, "rw");
            }else if (f != null && ze == null){
                zr = false;
                dataQuant += f.length();
                noOfFiles++;
                tempf = new File("_" + filenameNo++ + "_changed_archive_temp.search");
                tempf.createNewFile();
                tw = new RandomAccessFile(tempf, "rw");
            }else{
                if (debug) System.out.println("--this should never happen in changeFile (f, ze)");
                return -1;
            }
            if (zr){
                read = zip.read(zbuf);
                if (read > -1){
                    buf = new String(zbuf, 0, read).toCharArray();
                    read = buf.length;
                }
            }else{
                r = new FileReader(f);
                read = r.read(buf);
            }

            wh:
            while(read != -1){
                
                firstPos = 0;
                
                id2: for (int i = 0; i < read; i++){
                    // the scan code comes here
                    if (continued){
                        int count = 0;
                        if (read < queryLen - u){
                            break wh;
                        }
                        id4: for (; u < queryLen; u++){

                            if (read < u + i + 1){
                                break id4;
                            }
                            if ( (buf[i + u] == oquery[u]) || (query[u] == WCC) ||
                                ((buf[i + u] == query[u] || buf[i + u] == lquery[u]) && !cc)){
                                count++;
                                localCount++;
                            }else{
                                localCount = 0;
                                continued = false;
                                i--;
                                continue id2;
                            }
                            if (localCount == queryLen){
                                filePos += changeToTemp(tw, buf, filePos - (queryLen - count), firstPos, i + count);
                                firstPos = i + count;
                                localCount = 0;
                                hitCount++;
                            }
                        }
                        continued = false;

                    }else if ((buf[i] == ofirstChar) || (buf[i] == WCC) ||
                            ((buf[i] == firstChar || buf[i] == lfirstChar) && !cc)){
                        localCount++;
                        id3: for (u = 1; u < queryLen; u++){
                            if (read < u + i + 1){
                                continued = true;
                                if (zr){
                                    filePos += writeRestToTemp(tw, buf, filePos, firstPos, read);
                                    read = zip.read(zbuf);
                                    if (read > -1){
                                        buf = new String(zbuf, 0, read).toCharArray();
                                        read = buf.length;
                                    }
                                    firstPos = 0;
                                }else{
                                    filePos += writeRestToTemp(tw, buf, filePos, firstPos, read);
                                    read = r.read(buf);
                                    firstPos = 0;
                                }
                                continue wh;
                            }
                            if ((buf[u + i] == oquery[u]) || (oquery[u] == WCC) ||
                                ((buf[u + i] == query[u] || buf[u + i] == lquery[u]) && !cc)){
                                localCount++;
                            }else{
                                localCount = 0;
                                continue id2;
                            }
                            if (localCount == queryLen){
                                filePos += changeToTemp(tw, buf, filePos, firstPos, i + queryLen);
                                firstPos = i + queryLen;
                                hitCount++;
                                localCount = 0;
                                i += (u - 1);
                                continue id2; 
                            }
                          }
                    }
                }

                if (zr){
                    filePos += writeRestToTemp(tw, buf, filePos, firstPos, read);
                    read = zip.read(zbuf);
                    if (read > -1){
                        buf = new String(zbuf, 0, read).toCharArray();
                        read = buf.length;
                    }
                    firstPos = 0;
                }else{
                    filePos += writeRestToTemp(tw, buf, filePos, firstPos, read);
                    read = r.read(buf);
                    firstPos = 0;
                }

            }
            
            if (zr){
                this.changedFiles.add(tempf);
                this.entryNames.add(zEntry.getName());
                tw.close();
            }else{
                if(tempf != null){
                    r.close();
                    tw.close();
                    r = new FileReader(tempf);
                    w = new FileWriter(f);
                    if (f.canWrite() && tempf.length() > 0 && tempf.canRead()){
                        int got;
                        while((got = r.read(buf)) > -1){
                            w.write(buf, 0, got);
                        }
                        w.close();
                        r.close();
                        tempf.delete(); //yeye
                    }else{
                        if (debug) System.out.println("cannot write to origin file '" + f.getName() + "'");
                        tempf.delete(); //yeye
                    }
                }
            }

        }catch(Exception e){
            if (tempf != null){
                tempf.delete();
            }
            if (tw != null){
                try{tw.close();}catch(Exception ex){}
            }
            if (debug) e.printStackTrace();
            if (zr){
                // if there is an exception while processing a file from a compressed source,
                // throw an exception so that no other entries are processed since there might
                // be a compression error that does not come handy when repacking the file
                throw new Exception(e.getMessage() + "// error during extraction of file '" + ze.getName() + "'");
            }
            throw e;
        }

        return hitCount;

    }

//------------------------------------------------------------------------------
    private int writeRestToTemp(RandomAccessFile t, 
                                        char[] buf,
                                        long filePos,
                                        int firstPos,
                                        int lastPos) throws Exception{

        char[] arr;
        byte[] bytes;
        arr = new char[lastPos - firstPos];
        int pos = 0;
        for (int i = firstPos; i < lastPos; i++){
            arr[pos++] = buf[i];
        }
        t.setLength(filePos + arr.length);
        t.seek(filePos);
        bytes = new String(arr).getBytes();
        t.write(bytes);
        return bytes.length;
        
    }

//------------------------------------------------------------------------------
    private int changeToTemp(RandomAccessFile t, 
                                     char[] buf, 
                                   long filePos, 
                                   int firstPos, 
                                    int lastPos) throws Exception{
        char[] arr;
        byte[] bytes;
        int i;
        int pos = 0;
        long newLength;
        
        if (lastPos - newLen <= 0){

            arr = newArr;
            bytes = newString.getBytes();
            t.setLength(filePos + bytes.length);
            t.seek(filePos);
            t.write(bytes);
            return bytes.length;
           
        }else{
            
            arr = new char[(lastPos - oldLen + newLen) - firstPos];
            newLength = arr.length;
            for (i = firstPos; i < lastPos - oldLen; i++){
                arr[pos++] = buf[i];
            }
            for (i = 0; i < newLen; i++){
                arr[pos++] = newArr[i];
            }
            t.setLength(filePos + arr.length);
            t.seek(filePos);
            bytes = new String(arr).getBytes();
            t.write(bytes);
            return bytes.length;
            
        }
        
    }
//------------------------------------------------------------------------------
   // scans a File for the String query, adds the file's name to an array if found
    private int scanFile(File f, ZipEntry ze){

        boolean zr = false;

        if (f == null && ze != null){
            zr = true;
            dataQuant += ze.getSize();
            noOfFiles++;
        }else if (f != null && ze == null){
            zr = false;
            dataQuant += f.length();
            noOfFiles++;
        }else{
            if (debug) System.out.println("--error in scanFile (f, ze)");
        }

        FileReader r = null;
        byte[] zbuf = new byte[DEFAULT_BUFFER_SIZE];
        char[] buf = new char[DEFAULT_BUFFER_SIZE];
        int read = -1;
        boolean hit = false;
        boolean continued = false;
        char[] oquery = queryString.toCharArray();
        char[] query = queryString.toUpperCase().toCharArray();
        char[] lquery = queryString.toLowerCase().toCharArray();
        if (oquery.length < 1){
            return 0;
        }
        char ofirstChar = oquery[0];
        char firstChar = query[0];
        char lfirstChar = lquery[0];
        int localCount = 0;
        int hitCount = 0;
        int queryLen = query.length;
        int u = 0;

        try{
            if (zr){
                read = zip.read(zbuf);
                buf = new String(zbuf).toCharArray();
            }else{
                r = new FileReader(f);
                read = r.read(buf);
            }

            wh:
            while(read > -1){

                id2: for (int i = 0; i < read; i++){
                    // the scan code comes here
                    if (continued){
                        if (read < queryLen - u){
                            break wh;
                        }
                        id4: for (; u < queryLen; u++){

                            if (read < u + i + 1){
                                break id4;
                            }
                            if ( (buf[i + u] == oquery[u]) || (query[u] == WCC) ||
                                ((buf[i + u] == query[u] || buf[i + u] == lquery[u]) && !cc)){
                                localCount++;
                            }else{
                                //i += (u - 1);
                                localCount = 0;
                                continued = false;
                                continue id2;
                            }
                            if (localCount == queryLen){
                                hitCount++;
                                localCount = 0;
                                if (!ch){
                                    break wh;
                                }
                            }
                        }
                        continued = false;

                    }else if ((buf[i] == ofirstChar) || (buf[i] == WCC) ||
                            ((buf[i] == firstChar || buf[i] == lfirstChar) && !cc)){
                        localCount++;
                        id3: for (u = 1; u < queryLen; u++){
                            if (read < u + i + 1){
                                continued = true;
                                if (zr){
                                    read = zip.read(zbuf);
                                    buf = new String(zbuf).toCharArray();
                                }else{
                                    read = r.read(buf);
                                }
                                continue wh;
                            }
                            if ((buf[u + i] == oquery[u]) || (oquery[u] == WCC) ||
                                ((buf[u + i] == query[u] || buf[u + i] == lquery[u]) && !cc)){
                                localCount++;
                            }else{
                                localCount = 0;
                                continue id2;
                            }
                            if (localCount == queryLen){
                                hitCount++;
                                if (!ch){ // -ch : count hits, otherwise quit parsing and proceed to next file on first hit
                                    break wh;
                                }
                                localCount = 0;
                                i += (u - 1);
                                continue id2;
                            }
                        }
                    }
                }

                if (zr){
                    read = zip.read(zbuf);
                    buf = new String(zbuf).toCharArray();
                }else{
                    read = r.read(buf);
                }

            }

        }catch(Exception e){
            if (debug) e.printStackTrace();
        }
        
        return hitCount;

    }

 //------------------------------------------------------------------------------
    private int scanFileMultipleContent(File f, ZipEntry ze){

        boolean zr = false;
        byte[] zbuf = new byte[DEFAULT_BUFFER_SIZE];
        if (f == null && ze != null){
            zr = true;
            dataQuant += ze.getSize();
            noOfFiles++;
        }else if (f != null && ze == null){
            dataQuant += f.length();
            noOfFiles++;
            zr = false;
        }else{
            if (debug) System.out.println("--error in scanFile (f, ze)");
        }

        long hitPos = 0;
        long lastHitPos = -1;
        int readRound = 0;
        int elementNoInOrder = 0;
        id16: for (int i = 0; i < states.length; i++){
            if (states[i] == this.MUST_CONTAIN){
                elementNoInOrder = i;
                break id16;
            }
        }
        boolean[] gotHit = new boolean[states.length];
        int[] localStates = new int[states.length];
        char[][] overflowBuf = new char[states.length][];
        char[][] overflowBufL = new char[states.length][];
        char[][] overflowBufU = new char[states.length][];
        for (int i = 0; i < gotHit.length; i++){
            gotHit[i] = false;
            localStates[i] = states[i];
            overflowBuf[i] = null;
            overflowBufL[i] = null;
            overflowBufU[i] = null;
        }

        FileReader fr = null;
        char[] buf = new char[DEFAULT_BUFFER_SIZE];
        char[] buf2 = new char[DEFAULT_BUFFER_SIZE];
        int read = -1;
        int read2 = -1;
        boolean buf2Used = false;
        char[] oquery;
        char[] query;
        char[] lquery;
        int localCount = 0;
        int hitCount = 0;
        int queryLen;
        int u = 0;
        int i_localTemp = 0;

        try{
            if (zr){
                read = zip.read(zbuf);
                buf = new String(zbuf).toCharArray();
                readRound++;
            }else{
                fr = new FileReader(f);
                read = fr.read(buf);
                readRound++;
            }

            wh:
            while(read != -1){
                fr:
                for (int z = 0; z < queries.length; z++){
                    if (gotHit[z]){
                        continue fr;
                    }
                    if (overflowBuf[z] != null){
                        oquery = overflowBuf[z];
                        query = overflowBufU[z];
                        lquery = overflowBufL[z];
                        queryLen = overflowBuf[z].length;
                    //.. when overflow in last buf -----------------------------
                            id3: for (u = 1; u < queryLen; u++){
                                if (read < u + 1){
                                    overflowBuf[z] = null;
                                    z--;
                                    continue fr;
                                }
                                if ((buf[u] == oquery[u]) || (oquery[u] == WCC) ||
                                    ((buf[u] == query[u] || buf[u] == lquery[u]) && !cc)){
                                    localCount++;
                                }else{
                                    localCount = 0;
                                    overflowBuf[z] = null;
                                    z--;
                                    continue fr;
                                }
                                // evaluate a hit in overflow handle------------
                                if (localCount == queryLen){
                                    if (localStates[z] == this.MUST_NOT_CONTAIN){
                                        return 0;
                                    }

                                    if (io){
                                        if(localStates[z] == this.CAN_CONTAIN){
                                                localStates[z] += 2;
                                                gotHit[z] = true;
                                                overflowBuf[z] = null;
                                                z--;
                                                continue fr;
                                        }

                                        if (localStates[z] == this.MUST_CONTAIN){
                                            hitPos = (long)readRound * (long)this.DEFAULT_BUFFER_SIZE + u + queries[z].length();
                                            if (elementNoInOrder == z &&  hitPos > lastHitPos){
                                                elementNoInOrder++;
                                                localStates[z]++;
                                                gotHit[z] = true;
                                                lastHitPos = hitPos;
                                                overflowBuf[z] = null;
                                                z--;
                                                continue fr;
                                            }else{
                                                localCount = 0;
                                                overflowBuf[z] = null;
                                                z--;
                                                continue fr;
                                            }
                                        }else{
                                            if (debug) System.out.println("---- shit, this else should never run");
                                            localCount = 0;
                                            overflowBuf[z] = null;
                                            z--;
                                            continue fr;
                                        }
                                    }else{
                                        if (localStates[z] == this.CAN_CONTAIN ){
                                            localStates[z] += 2;
                                            gotHit[z] = true;
                                            overflowBuf[z] = null;
                                            z--;
                                            continue fr;
                                        }else if (localStates[z] == this.MUST_CONTAIN){
                                            localStates[z]++;
                                            gotHit[z] = true;
                                            overflowBuf[z] = null;
                                            z--;
                                            continue fr;
                                        }
                                    }
                                    // evaluate a hit in overflow handle--------
                                }//.. if (localCount == queryLen)
                            }//.. id3: for

                        overflowBuf[z] = null;
                        z--;
                        continue fr;
                    //.. when overflow in last buf -----------------------------

                    }else{
                        if (queries[z].length() < 1){
                            continue fr;
                        }
                        oquery = queries[z].toCharArray();
                        query = queries[z].toUpperCase().toCharArray();
                        lquery = queries[z].toLowerCase().toCharArray();
                        queryLen = queries[z].length();

                        localCount = 0;
                        u = 0;

                        id2: for (int i = 0; i < read; i++){

                            if ( (buf[i] == oquery[0]) || oquery[0] == WCC ||
                                ((buf[i] == query[0] || buf[i] == lquery[0]) && !cc)){
                                localCount++;
                                id3: for (u = 1; u < queryLen; u++){

                                    // if during comparison, buffer end is reached
                                    if (read < u + i + 1){
                                        i_localTemp = query.length - u;
                                        overflowBuf[z] = new char[i_localTemp];
                                        overflowBufU[z] = new char[i_localTemp];
                                        overflowBufL[z] = new char[i_localTemp];
                                        for(int g = 0; g < overflowBuf[z].length; g++){
                                            i_localTemp = u + g;
                                            overflowBuf[z][g] = oquery[i_localTemp];
                                            overflowBufU[z][g] = query[i_localTemp];
                                            overflowBufL[z][g] = lquery[i_localTemp];
                                        }
                                        continue fr;
                                    }
                                    if ((buf[u + i] == oquery[u]) || (oquery[u] == WCC) ||
                                        ((buf[u + i] == query[u] || buf[u + i] == lquery[u]) && !cc)){
                                        localCount++;
                                    }else{
                                        //i += (u - 1);
                                        localCount = 0;
                                        continue id2;
                                    }

                                    if (localCount == queryLen){
                                        // evaluate a hit --------------------------
                                        if (localStates[z] == this.MUST_NOT_CONTAIN){
                                            return 0;
                                        }

                                        if (io){
                                            if(localStates[z] == this.CAN_CONTAIN){
                                                    localStates[z] += 2;
                                                    gotHit[z] = true;
                                                    continue fr;
                                            }

                                            if (localStates[z] == this.MUST_CONTAIN){
                                                hitPos = (long)readRound * (long)this.DEFAULT_BUFFER_SIZE + i + queries[z].length();
                                                if (elementNoInOrder == z &&  hitPos > lastHitPos){
                                                    if (z < states.length){
                                                        id33:
                                                        for (int n = z + 1; n < states.length; n++){
                                                            if (states[n] == this.MUST_CONTAIN){
                                                                elementNoInOrder = n;
                                                                break id33;
                                                            }
                                                        }
                                                    }
                                                    localStates[z]++;
                                                    gotHit[z] = true;
                                                    lastHitPos = hitPos;
                                                    continue fr;
                                                }else{
                                                    localCount = 0;
                                                    i += (u - 1);
                                                    continue id2;
                                                }
                                            }else{
                                                if (debug) System.out.println("---- shit, this should never run");
                                                localCount = 0;
                                                i += (u -1);
                                                continue id2;
                                            }
                                        }else{
                                            if (localStates[z] == this.CAN_CONTAIN ){
                                                localStates[z] += 2;
                                                gotHit[z] = true;
                                                continue fr;
                                            }else if (localStates[z] == this.MUST_CONTAIN){
                                                localStates[z]++;
                                                gotHit[z] = true;
                                                continue fr;
                                            }
                                        }
                                        // .. --------------------------------------
                                    }//.. if (localCount == queryLen)
                                }//.. id3: for
                            }//.. if (
                        }//.. id2: for

                    }// .. for
                }
                                                    ////////////////////////////
                if (zr){
                    read = zip.read(zbuf);
                    buf = new String(zbuf).toCharArray();
                    readRound++;
                }else{
                    read = fr.read(buf);
                    readRound++;
                }                                   ////////////////////////////

            }// .. while

        }catch(Exception e){
            if (debug){
                System.out.println("!! caught Exception at scanFileMultipleContent(), " + e.getMessage());
                e.printStackTrace();
            }
            return 0;
        }
        // verify multiple queries result --------------------------------------
        // verify if all MUST_CONTAINs are found, else return a 0 hit
        for(int i = 0; i < localStates.length; i++){
            if(localStates[i] == 0){
                return 0;
            }
            if (localStates[i] > 0 && localStates[i] != this.MUST_NOT_CONTAIN){
                hitCount++;
            }
        }
        //..  ------------------------------------------------------------------
        return hitCount;

    }

//------------------------------------------------------------------------------
    // prepares the filename query string into an array called 'parts'
    private void prepareQuery(){

      String ltemp = fileString;
      int index = ltemp.indexOf("*");
      int index2 = ltemp.lastIndexOf("*");
      if (index == -1){
          parts.add(ltemp.toCharArray());
          noStar = true;
      }else{
        noStar = false;
        if (index == 0){
            starts = true;
        }

        if (index2 == ltemp.length() - 1){
            ends = true;
        }
        while ((index = ltemp.indexOf("*")) > -1){
            String t2 = ltemp.substring(0, index);
            ltemp = ltemp.substring(index + 1, ltemp.length());
            if (t2.length() > 0){
                parts.add(t2.toCharArray());
            }
        }
        if (ltemp.length() > 0){
            parts.add(ltemp.toCharArray());
        }
      }
    }

//------------------------------------------------------------------------------
    private boolean scanFileNameFromZip(ZipEntry file){

        String t = file.getName();
        int index = t.lastIndexOf("/");

        if(index > 0){
            if (index == t.length() - 1){
                t = t.substring(0, t.length() -1);
                index = t.lastIndexOf("/");
                if (index > 0){
                    t = t.substring(index + 1, t.length());
                }
            }else{
                t = t.substring(index + 1, t.length());
            }
        }
        return this.scanName(t);

    }

//------------------------------------------------------------------------------
    private boolean isKnownArchive(File file){
        String t = file.getName();
        int index = t.lastIndexOf('.');
        if (index > 0 && !(index == t.length() - 1)){
            t = t.substring(index + 1, t.length());
        }else{
            return false;
        }
        char[] tarr = t.toCharArray();
        id2:
        for (int i = 0; i < knownArchivesU.length; i++){
            if (tarr.length != knownArchivesU[i].length){
                continue id2;
            }else{
                for (int u = 0; u < knownArchivesU[i].length; u++){
                    if (tarr[u] != knownArchivesU[i][u] && tarr[u] != knownArchivesL[i][u]){
                        continue id2;
                    }
                }
                return true;
            }
        }
        return false;
    }

//------------------------------------------------------------------------------
    private boolean scanFileName(File file){
        return this.scanName(file.getName());
    }

//------------------------------------------------------------------------------
    private boolean scanName(String  file){

      // *bambi*.*tm
      int localCount = 0;
      char[] t = file.toCharArray();
      // NO '*' (query String does not contain '*')
      if (noStar){
        char[] array = (char[])parts.get(0);
        if (cs){// cs = Case sensitive filename search
            if (array.length == t.length){
                for (int i = 0; i < array.length; i++){
                    if (array[i] == WC || array[i] == t[i]){
                        localCount++;
                    }else{
                        return false;
                    }
                }
                if (localCount == t.length){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }else{            // not case sensitive filename search
            if (array.length == t.length){
                char[] lcase = new String(array).toLowerCase().toCharArray();
                char[] ucase = new String(array).toUpperCase().toCharArray();
                for (int i = 0; i < lcase.length; i++){
                    if (lcase[i] == WC || lcase[i] == t[i] || ucase[i] == t[i]){
                        localCount++;
                    }else{
                        return false;
                    }
                }
                if (localCount == t.length){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }

      // QUERY STRING CONTAINS '*'
      }else{

            String temp = file;
            int partCount = parts.size();
            int lCount = 0;
            int ccount = 0;

            id21: for(int i = 0; i < parts.size(); i++){

                char[] arr = (char[])parts.get(i);
                char[] fname = temp.toCharArray();
                char[] lfname = temp.toLowerCase().toCharArray();
                char[] ufname = temp.toUpperCase().toCharArray();

                // if queryString does not start with '*', has to match first part, otherwise no hit
                if (i == 0 && !starts){
                    for (int u = 0; u < arr.length; u++){
                        if ( arr[u] != WC && ((cs && arr[u] != fname[u]) ||
                            (!cs && arr[u] != ufname[u] && arr[u] != lfname[u]))){ // CHAR COMPARISON
                            return false;
                        }
                    }
                    lCount++;
                    continue id21;
                }
                // if queryString does not end with '*', has to end with last part, otherwise no hit
                if (i + 1 == partCount && !ends){
                    if (fname.length < arr.length){
                        return false;
                    }
                    for (int u = 0; u < arr.length; u++){
                        if ( arr[u] != WC && ((cs && arr[u] != fname[u + fname.length - arr.length]) ||
                            (!cs && arr[u] != ufname[u + ufname.length - arr.length] && arr[u] != lfname[u + lfname.length - arr.length]))){
                            return false;
                        }
                    }
                    lCount++;
                    continue id21;
                }

                id33: for (int u = 0; u < fname.length; u++){

                    if (arr[0] == WC || (cs && fname[u] == arr[0]) ||
                        (!cs && ufname[u] == arr[0] || lfname[u] == arr[0])){
                        if (u + arr.length > fname.length){
                            return false;
                        }
                        for (int q = 0; q < arr.length; q++){
                            if (arr[q] != WC && ((cs && arr[q] != fname[u + q]) ||
                                (!cs && arr[q] != ufname[u + q] && arr[q] != lfname[u + q]))){
                                continue id33;
                            }
                        }

                        lCount++;
                        if (u + arr.length == fname.length){
                            temp = "";
                            fname = temp.toCharArray();
                        }else{
                            temp = temp.substring(u + arr.length, temp.length());
                            fname = temp.toCharArray();
                        }
                    }

                }

            }
            if (lCount == partCount){
                return true;
            }

        }

        return false;

    }
    
//------------------------------------------------------------------------------
    private void sortResult(){

        if (this.resultFileNames == null || this.resultFileNames.size() < 1){
            return;
        }

        String t = "";
        String vt = "";
        int temp = 0;
        int index = 0;
        int b;
        list1 = new ArrayList(resultFileNames.size());
        list2 = new ArrayList(resultFileNames.size());

        fr:
        for (int q = 0; q < resultFileNames.size(); q++){
            t = (String)resultFileNames.get(q);
            vt = (String)fileValue.get(q);
            if (de){
                for (b = 0; b < list1.size(); b++){
                    if(t.compareTo((String)list1.get(b)) > 0){
                        list1.add(b, t);
                        list2.add(b, vt);
                        continue fr;
                    }
                }
                list1.add(b, t);
                list2.add(b, vt);
            }else{
                for (b = 0; b < list1.size(); b++){
                    if(t.compareToIgnoreCase((String)list1.get(b)) < 0){
                        list1.add(b, t);
                        list2.add(b, vt);
                        continue fr;
                    }
                }
                list1.add(b, t);
                list2.add(b, vt);
            }
        }
        this.resultFileNames = list1;
        this.fileValue = list2;

        // sort by hit count
        if (!as && !de){
            list1 = new ArrayList(resultFileNames.size());
            list2 = new ArrayList (resultFileNames.size());
            int outSize = fileValue.size();
            for (int i = 0; i < outSize; i++){
                temp = 0;
                index = 0;
                for (b = 0; b < fileValue.size(); b++) {
                    if (temp <= Integer.parseInt((String)fileValue.get(b))) {
                        temp = Integer.parseInt((String)fileValue.get(b));
                        index = b;
                    }
                }
                list1.add(resultFileNames.get(index));
                list2.add(fileValue.get(index));
                fileValue.remove(index);
                resultFileNames.remove(index);
            }
            this.resultFileNames = list1;
            this.fileValue = list2;
        }
    }
//------------------------------------------------------------------------------
    public void run(){

        
        if (run_type == this.RUN_AS_APP){
            runAsApp();
        }else if (run_type == this.RUN_AS_THREAD){
            try{
                runAsComp();
            }catch (Exception e){}
        }else{
            if (debug) System.out.println("-- bad, realy bad (else{ of run())");
        }


    }
//------------------------------------------------------------------------------
    /**
     * Call this method to start performing search/replace job after parameters
     * and flags are set apropriately through constructor or initialize().
     */
    public void runAsComp() throws Exception{

        isScanning = true;
        runThrough(new File(this.startPath));
        sortResult();
        isScanning = false;

  }

//------------------------------------------------------------------------------

    private void runAsApp(){

        try{
            
            isScanning = true;
            Date end = null;
            Date start = new Date();
            File f = new File(this.startPath);
            System.out.print(SEP + "... " + f.toString());
            if (!nr){System.out.print("(and subdirectories) ");}
            System.out.println(" [e + enter to cancel]");
            if (!f.exists()){
                System.out.println("!ERROR: wrong startDir, can only start search from existing directory");
                isScanning = false;
                return;
            }
            this.runThrough(f);
            end = new Date();
            sortResult();
            PrintStream out = null;
            boolean writingToFile = false;
            if (tf){
                try{
                    out = new PrintStream(new FileOutputStream(toFile));
                    writingToFile = true;
                }catch(Exception e){
                    System.out.println("can not create output file '" + toFile + "'");
                }
            }
            if (out == null){
                out = System.out;
            }

            long lstart = start.getTime();
            long lend = end.getTime();

            out.println(SEP + "************  RESULT *************");
            if (cg){
                out.println("changed|filename");
                out.println("items  |        ");
            }else{
                out.println("hit     filename");
            }
            out.println("**********************************");
            String val = null;
            String name = null;
            int page = 10;
            if (list1 == null || list1.size() < 1){
                if (cg){
                    out.println("NO FILES CHANGED:");
                }else{
                    out.println("NO FILES MATCHING CRITERIA:");
                }
                if(fs){
                    out.println("filename           '" + this.fileString + "'");
                }
                if (cg){
                    out.println("change '" + oldString + "' to '" + newString + "'");
                }
                if(queries != null && this.queries.length > 0){
                    for (int p = 0; p < queries.length; p++){
                        out.print("containing string  '" + queries[p] + "'");
                        if (states[p] == this.MUST_CONTAIN){
                            out.println(" (+)");
                        }else if(states[p] == this.CAN_CONTAIN){
                            out.println(" ()");
                        }else{
                            out.println(" (-)");
                        }
                    }
                }else if (this.queryString != null){
                    out.println("containing string  '" + queryString + "'");
                }
            }else{
                for (int i = 0; i < resultFileNames.size();i++){
                    if (!writingToFile && (page % PAGE_SIZE == 0 || (page + 1) % PAGE_SIZE == 0)){
                        if (!(page % PAGE_SIZE == 0)){page++;}
                        try{
                            out.println(SEP + " hit enter to continue (e + enter to exit)");
                            byte[] b = new byte[10];
                            int q = System.in.read(b);
                            for (int u = 0; u < b.length; u++){
                                if (b[u] == (byte)'e' || b[u] == (byte)'E'){
                                    System.exit(0);
                                }
                            }

                        }catch(Exception e){}
                    }
                    val = (String)fileValue.get(i);
                    name = (String)resultFileNames.get(i);
                    out.println(val + "        ".substring(0, 6 - val.length()) + "  " + name);
                    if (name.length() > LINE_LENGTH - 6){
                        page++;
                    }
                    page++;
                }
            }
            out.println("************  scanned ************");
            out.println("# of files scanned   : " + noOfFiles);
            out.println(SEP + "********* Process Time ***********");
            out.println("elapsed time  : " + String.valueOf(lend - lstart) + "(ms), " + String.valueOf((lend - lstart)/1000)+ "(sec)");
            if (ct){
                out.println("data processed: " + dataQuant / 1024 + "(kb)" + ", " + dataQuant / 1024 / 1024 + "(Mb)");
            }
            out.close();
        }catch(Exception e){
            if (debug){
                e.printStackTrace();
            }
            System.out.println("possible error with output file '" + toFile + "'");
        }
        this.isScanning = false;
        //if(this.runStandAlone)System.exit(0);
    }

//==============================================================================
    
    // -------------------------------------------------------------------------
    /**
     * If the job was search, the list of files found can be retrieved with this
     * method. In case of replace, it returns the files that have been changed.
     * The returned ArrayList contains String objects with the absolute path 
     * of each File. If Search Compressed was set to true, and some results were
     * found whithin a compressed file, then the string holds that compressed file's
     * absolute path and the fully qualified entry name that represents the internal
     * file, separated with a '!'.
     * Example: 'c:\somedir\somefile.zip!otherdir/zipped_file.txt'
     */
    public ArrayList getFiles(){
        while(this.isScanning){
            try{wait();}catch(Exception e){}
        }
        return this.resultFileNames;
    }

    //--------------------------------------------------------------------------
    /**
     * Holds a list of the values of each file retrieved by <code>getFiles()</code>
     * (values are stored in String form for displaying purposes). Of course the same
     * index has to be used to get file name and file value from the to lists.
     * <p>
     * Some explanation on values:
     * bla
     */
    public ArrayList getValues(){
        while(this.isScanning){
            try{wait();}catch(Exception e){}
        }
        return this.fileValue;
    }
    
    //--------------------------------------------------------------------------
    /**
     * replace a string (oldString) to another string (newString) within a single
     * file (file) where it is found in it. The replace is only carried out if
     * all the strings passed with queries are found (or not if a string has a '-'
     * at the beginning) within the file.
     * This method can be called repeatedly without calling <code>initialize()</code>.
     * It performs any initialization required.
     * 
     * @param   file    the file to be changed
     * @param   oldString   this will be removed
     * @param   newString   this will be inserted
     * @param   queries strings that the file will be searched with before change is
     *                  started
     *
     * @return  int number of strings changed in the file
     */
    public int replaceFileContent(File file, String oldString, String newString, String[] queries) throws Exception{

        if (!file.exists()){
            throw new Exception("file does not exist '" + file.getName() + "'");
        }else if(!file.canRead()){
            throw new Exception("cannot read file '" + file.getName() + "'");
        }else if(!file.canWrite()){
            throw new Exception("cannot write to file '" + file.getName() + "'");
        }
        String[] q = new String[queries.length];
        int[] s = new int[queries.length];
        if (queries != null && queries.length > 0){
            initialize(file.getName(), queries, file.getParentFile().getAbsolutePath(), null, oldString, newString, false, false, false, false, false, false, false, false, false);
        }else{
            initialize(file.getName(), null, file.getParentFile().getAbsolutePath(), null, oldString, newString, false, false, false, false, false, false, false, false, false);
        }
        this.run_type = Search.RUN_AS_THREAD;
        this.run();
        if (this.getFiles() != null && this.getFiles().size() == 1){
            return (Integer.valueOf((String)this.getValues().get(0))).intValue();
        }else{
            return 0;
        }

    }
    
    //--------------------------------------------------------------------------
    /**
     * Same as <code>replaceFileContent(File file, String oldString, String newString, String[] queries)</code>
     * except that there is no queries additional query strings specified, change will be made
     * on the file if oldString is found in it.
     * Can be called repeatedly without calling <code>initialize()</code>.
     */
    public int replaceFileContent(File file, String oldString, String newString) throws Exception{

        return replaceFileContent(file, oldString, newString, null);
        
    }
    
    //--------------------------------------------------------------------------
    /**
     * Searches the content of a single file for Strings in queries.
     *
     * @param   f   File to be scanned
     * @param   queries Strings that the content of the file will be searched for
     *
     * @return  if queries.length > 1, how many of the strings specified in queries array where found.;
     * if queries.length == 1, how many times the string was found in the file
     */
    public int checkFileContent(File f, String[] queries) throws Exception{

        String[] q = new String[queries.length];
        int[] s = new int[queries.length];
        this.initialize(    f.getName(),
                            queries,
                            f.getParentFile().getAbsolutePath(),
                            null,
                            null,
                            null,
                            true,
                            true,
                            false,
                            false,
                            false,
                            false,
                            false,
                            false,
                            false);
                            
        this.run_type = Search.RUN_AS_THREAD;
        this.debug = true;
        this.runAsComp();
        if (this.getFiles() != null && this.getFiles().size() > 0){
            return (Integer.valueOf((String)this.getValues().get(0))).intValue();
        }else{
            return 0;
        }
        
    }
    //--------------------------------------------------------------------------
    // more methods here for component use
    // some times later

}
