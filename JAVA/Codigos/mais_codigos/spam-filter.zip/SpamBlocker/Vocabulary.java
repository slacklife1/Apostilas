/* 
@Author : Alifiya.Patrawala
@Data Mining  Student
Date : 7/4/2003*/



import java.lang.*;
import java.io.*;
import java.util.*;

public class Vocabulary 
{
	public static Vector getVocabList(Vector v,Vector d)
	{
		 for(int k=0;k<d.size();k++)
                 {

                           if(v.contains(d.elementAt(k)));
                           else v.addElement(d.elementAt(k));
		 }
		 return(v);
	}
}
