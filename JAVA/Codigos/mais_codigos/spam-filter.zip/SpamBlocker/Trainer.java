/* Used for training your emails
@Author : Alifiya.Patrawala
@Data Mining  Student 
Date : 7/4/2003*/


import java.lang.*;
import java.util.*;
import java.io.*;

class Trainer 
{
	public static void main(String args[])
	{
		//learn ur mails
		if(args[0].equals("-T"))
		{
			Train.TrainEmail(args[1],args[2],args[3],args[4]);
			FileSaver fs=new FileSaver();
			fs.Create("confirm_train.dat");
			fs.Save("Y");
			fs.CloseFile();
		}
		else 
		{
			if(args[0].equals("-Block")) //Block email Addr
			{
				Blacklist.Add(args[1]);
			}
			if(args[0].equals("-Insert")) //Insert into Addr LIst
			{
				WhiteList.Add(args[1]);
			}
		}
	}





}
