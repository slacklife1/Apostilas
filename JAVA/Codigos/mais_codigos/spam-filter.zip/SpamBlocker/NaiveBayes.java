/* 
@Author : Alifiya.Patrawala
@Data Mining  Student
Date : 7/4/2003*/



import java.lang.*;
import java.util.*;
import java.io.*;
public class NaiveBayes
{


static Vector ClassName=new Vector();
	
public static void train(DataRepository DR)
{

	ProbofClass();
	ProbWord_Class(DR);
	ProbWords(DR);
	//try{
	//PrintWriter fp=new PrintWriter(new BufferedWriter(new FileWriter("learnNB.out")));
	//fp.println("data is already trained");
	//}catch(Exception e){e.printStackTrace();}
}
	
public static void ProbofClass()
{	
	
	
	BufferedReader in;
	String str;
	double totdocs=0.0;
	HashMap hm =new HashMap();

	try{
	in=new BufferedReader(new FileReader(new String("VocabList.out")));
	str=in.readLine();
	totdocs=Double.parseDouble(str);
	in.close();
	}catch(Exception e){e.printStackTrace();}
	
	try{
	in=new BufferedReader(new FileReader(new String("Class.out")));
	 str=in.readLine();
        while(str!=null)
        {
         ClassName.addElement(str);
	 double d=Double.parseDouble(in.readLine());
	 d=d/totdocs;
	 hm.put(str,new Double(d));
	 str=in.readLine();
        }
        in.close();
        }catch(Exception e){e.printStackTrace();}
	 Set set1=hm.entrySet();
         Iterator it1=set1.iterator();
	 FileSaver fs=new FileSaver();
         fs.Create("Class.out");
         while(it1.hasNext())
         {
         	Map.Entry me=(Map.Entry)it1.next();
	         fs.Save(me.getKey());
	         fs.Save(me.getValue());
         }
        fs.CloseFile();
	
	
}	

public static void ProbWord_Class(DataRepository DR)
{
BufferedReader in;
String str;
for(int m=0;m<DR.hm.length;m++)
{
	HashMap hm =new HashMap();
	hm=findProbW_C(DR.hm[m],DR.totClassWords[m]);

	String filename=(ClassName.elementAt(m)).toString();
	filename=filename.concat(".out");
	Set set1=hm.entrySet();
        Iterator it1=set1.iterator();
	FileSaver fs=new FileSaver();
	fs.Create(filename);
        while(it1.hasNext())
         {
                Map.Entry me=(Map.Entry)it1.next();
                 fs.Save(me.getKey());
                 fs.Save(me.getValue());
         }
	fs.CloseFile();
}
}



public static void ProbWords(DataRepository DR)
{
String str;
Set set=DR.vm.entrySet();
Iterator it=set.iterator();
FileSaver fs=new FileSaver();
fs.Create("VocabList.out");
while(it.hasNext())
{
	Map.Entry me=(Map.Entry)it.next();
	fs.Save(me.getKey());
	double d=Double.parseDouble(me.getValue().toString())/DR.totwords;
	fs.Save(new Double(d));
}
fs.CloseFile();
	
}//end ProbWords



public static HashMap findProbW_C(HashMap hm,double totCwords)
{
                Set set=hm.entrySet();
                Iterator it=set.iterator();
                double Pwc=0;
                HashMap probhm=new HashMap();
                while(it.hasNext())
                {
                        Map.Entry me=(Map.Entry)it.next();
                         Pwc= Double.parseDouble((me.getValue()).toString())/totCwords;
                        probhm.put(me.getKey(),new Double(Pwc));
			System.out.println(me.getKey());
			System.out.println(me.getValue());
                }
		
                return(probhm);

}

public static Result classifyInput(String testdoc)
{
	 String[] sep=TokenSeperator.getSeperators();
         Vector test=new Vector();
         Vector testVocab=new Vector();
         HashMap testMap=new HashMap();
         HashMap vm=new HashMap();
         test=TextTokeniser.tokenize(testdoc,sep);
         test=Stopwords.removeSW(test);
         testMap=WordMap.Create(testMap,test);
         testVocab=Vocabulary.getVocabList(testVocab,test);
         System.out.println("TestVocab Size"+testVocab.size());
	 System.out.println("I am in classify text");
        BufferedReader in;
	Vector Pc =new Vector();
	/////////////////////////////////////////////////
	
	 try{
         in= new BufferedReader(new FileReader(new String("Class.out")));
         String str=in.readLine();
        while(str!=null)
        {
        
         ClassName.addElement(str);
	 str=in.readLine();
         str=in.readLine();
        }
        in.close();
        }catch(Exception e){e.printStackTrace();}

	double []PCk=new double[ClassName.size()];
	 String str;
	 try{
         in= new BufferedReader(new FileReader(new String("Class.out")));
         str=in.readLine();
        while(str!=null)
        {
         str=in.readLine();
         Pc.addElement(str);
         str=in.readLine();
        }
        in.close();
        }catch(Exception e){e.printStackTrace();}
        try{
        in=new BufferedReader(new FileReader(new String("VocabList.out")));
        str=in.readLine();
        while(str!=null)
        {
                vm.put(str,new String(in.readLine()));
                str=in.readLine();
        }
        in.close();
        }catch(Exception e){e.printStackTrace();}
	HashMap PW=new HashMap();
	 for(int j=0;j<testVocab.size();j++)
         {
	         if(vm.containsKey(testVocab.elementAt(j)))
        	 {
			PW.put(testVocab.elementAt(j),vm.get(testVocab.elementAt(j)));

                }
         }
	double max =0;
	int maxI=0;
	for(int i=0;i<ClassName.size();i++)
	{	
		double Pcwk=1.0;
		try{
                str=(ClassName.elementAt(i).toString()).concat(".out");
                in=new BufferedReader(new FileReader(new String(str)));
		str=in.readLine();
		while(str!=null)
		{
			if(testVocab.contains(str))
			{
			double tmpPwc=Double.parseDouble(in.readLine());
			double tmpPc=Double.parseDouble(Pc.elementAt(i).toString());
			double tmpPw=Double.parseDouble(PW.get(str).toString());
			double tmpPcwk=tmpPwc*tmpPc/tmpPw;
			Pcwk=Pcwk*tmpPcwk;
			}
			str=in.readLine();
		}
		
		}catch(Exception e){e.printStackTrace();}
		PCk[i]=Pcwk;
		System.out.println("ClassName is :  "+ClassName.elementAt(i));
		System.out.println("prob of class is : "+PCk[i]);
		if(max<PCk[i])
		{
			max=PCk[i];
			maxI=i;
		}
		
	}
        System.out.println("the document belongs to  : "+ClassName.elementAt(maxI));
	Result r=new Result();
	//r.classname=ClassName.elementAt(maxI);
	//r.probval=PCk[maxI];
	System.out.println("probability is : "+PCk[maxI]);	
	r.put(ClassName.elementAt(maxI),PCk[maxI]);
	return(r);
}
}
