/* 
@Author : Alifiya.Patrawala
@Data Mining  Student
Date : 7/4/2003*/



import java.lang.*;
import java.util.*;
import java.io.*;
import javax.mail.*;
import javax.mail.internet.*;

class Classify
{
	public void IsSpam(String arg)
	{
		Vector head=new Vector();
		head=extractheader(arg);
		boolean bs=false;//spam to test whether in Blocked List
		boolean bh=false;//ham to test whether in Addr list
		for(int i=0;i<head.size();i++)
		{
			if(head.elementAt(i).toString().startsWith("From:"))
			{
				 bs=checkList(head.elementAt(i).toString(),"BlockedList.dat");
				 bh=checkList(head.elementAt(i).toString(),"AddrList.dat"); 	
			}
		}
		if(!bs & !bh)
		{
				String fp=extractbody(arg);
				IsSpamBody(fp);
		}
		else
		{	if(bs)
			{
				System.out.println("this mail is spam  :  "+arg);
				System.out.println("No need to further proceed");
				System.out.println("the user is blocked");
				System.exit(0);
			}
			else
			{
				System.out.println("this mail is ham  :  "+arg);
				System.out.println("No need to Proceed further ");
				System.out.println("the user is in your address list");
				System.exit(0);
			}


		}
		
		//return result;

	}

	public boolean checkList(String from_addr,String Listname)
	{	
		//System.out.println(from_addr);
		try{
                	BufferedReader in=new BufferedReader(new FileReader(new String(Listname)));
			String str=in.readLine();
			while(str!=null)
			{
			 if((from_addr.indexOf(str))>0)
			 {
				return true;
			 }
			 str=in.readLine();
			}
		}catch(Exception e){e.printStackTrace();}
		return false;
	}



	public void IsSpamBody(String arg)
	{
		Result r=new Result();
		r=NaiveBayes.classifyInput(arg);
		FileSaver fs=new FileSaver();
		fs.Create("NBResult.dat");
		fs.Save(arg);
		fs.Save(r.classname);
		fs.Save(new Double(r.probval));
		fs.CloseFile();
		//return 
	}

	public String  extractbody(String arg)
	{	
		String msg=new String();
		String newarg=new String();
		try{
		InputStream io= new FileInputStream(arg);
                BodyPart bp=new MimeBodyPart(io);
                BodyPart mbp=new MimeBodyPart(io);
                        String content=bp.getContentType();
                        System.out.println("content"+content);
                        if(content.startsWith("multipart"))
                        {
                         Multipart multipart = (Multipart)bp.getContent();
                         int z=multipart.getCount();
                         mbp=multipart.getBodyPart(0);
                         msg=mbp.getContent().toString();
                        }
                        else
                         msg= bp.getContent().toString();

		}catch(Exception e){System.out.println("File does not exist");System.exit(0);}
		newarg=arg.concat(".Body");
		FileSaver fs=new FileSaver();
		fs.Create(newarg);
		fs.Save(msg);
		fs.CloseFile();
		return newarg;
	}

	public Vector  extractheader(String arg)
	{	
		
		Vector head=new Vector();
		try{
		InputStream io= new FileInputStream(arg);
                MimeBodyPart bp=new MimeBodyPart(io);
		Enumeration e;
		for(e = bp.getAllHeaderLines() ; e.hasMoreElements() ;) 		 	   {
	             head.addElement(e.nextElement());
     		}
		}catch(Exception e){e.printStackTrace();}
		return head;
	}
}
