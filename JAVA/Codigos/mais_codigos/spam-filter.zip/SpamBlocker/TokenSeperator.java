/* 
@Author : Alifiya.Patrawala
@Data Mining  Student
Date : 7/4/2003*/


import java.lang.*;
public class TokenSeperator
{
static String[] sep={"[","]","{","}","(",")",",",";",":",".","?","!","\"","\'","-","/","\\","%","#","*","+",">","<"};
public static String[] getSeperators()
{
	return(sep);
}


}
