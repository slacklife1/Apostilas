
/* 
@Author : Alifiya.Patrawala
@Data Mining  Student
Date : 7/4/2003*/



import java.lang.*;
import java.io.*;

public class FileSaver {

 PrintWriter fw;

public  void Create(String outputfile)
{
		
	try{
	 fw= new PrintWriter(new BufferedWriter(new FileWriter(outputfile)));		
	}catch(Exception e){e.printStackTrace();}
}

public  void Save(Object i)
{
	fw.println(i);

}

public  void CloseFile()
{
	fw.close();
}

public  void OpenFile(String filename)
{

}

}

	



