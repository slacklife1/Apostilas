				SPAM BLOCKER
				------------

INTRODUCTION:
-------------
SpamBlocker is a mail filter which attempts to identify spam using text
analysis and maintaining  blacklists and Whitelists.

Using its rule base, it uses a  heuristic tests on mail
headers and body text to identify "spam".
It basically uses a Naive bayes method 
on the body part of the emails to distinguish whether the mail is spam or ham.

SpamBlocker typically differentiates successfully between spam and
non-spam(ham) in between 95% and above cases, depending on what kind
of mail you get.

Training of emails:
-------------------

SpamBlocker  uses a Bayesian learning filter 
It also uses Lempelzive Coding (gzip) to identify the mail is spam or ham.
Do this using the "Trainer" tool, 
	usage:
	------

        Java Trainer -T -spam ~/saved-spam-folder -ham ~/saved-ham-folder
        java Trainer -Block email-addr
        java Trainer -Insert email-addr

The SpamBlocker learns using the Trainer tool and places the trained data
 in "./TrainDir" folder


Training data that I have used is placed in the following folders..Which I downloaded from
 http://www.spamassassin.org/publiccorpus/
"./spam_2"
"./easy_ham"

Maintains WhiteList :
---------------------
usage :
-------
	java Trainer -Insert email-addr

The email addr of the sender gets added to the "./AddrList.dat" file 
Any emails from this sender will always be classified as ham(non-spam).

Maintains BlackList :
---------------------
usage :
-------
	java Trainer -Block email-addr

The sender with this email addr gets added to "./BlockedList.dat" file
Any emails from this sender will always be classified as spam.



Classification :
-----------------

usage :
-------
	java MailClassifier testmail

This program does a bayesian classification and gives out 
the result whether the testmail is a spam or ham.
The Bayesian algorithm result is stored in "./NBResult.dat" file

	./zipResult

On running this script it gives the result using the gzip compression algo.



Tests
------
The tests that I have performed on this application are placed
 in the following forders

./testham   
./testspam 


Sample Results of this application:
-----------------------------------
example 1:
----------
	java MailClassifier ./testspam/spam2

output:
-------
	this mail is spam  :  ./testspam/spam2
	No need to further proceed
	the sender is Blocked.


Here in the above case spam2 is a mail whoes sender's  email addr is 
entered in "BlockedList.dat"


example 2:
----------

	java MailClassifier ./testspam/spam3
	
output:
-------	
	contenttext/plain
	TestVocab Size26
	I am in classify text
	ClassName is :  ./trainDir/train-spam
	prob of class is : 2.552793728090457E-7
	ClassName is :  ./trainDir/train-ham
	prob of class is : 1.208052206906059E-17
	the document belongs to  : ./trainDir/train-spam
	probability is : 2.552793728090457E-7

	
This is the   Bayesian Classification result.


	./zipResult

output:
-------
	
	./testspam/spam3.Body
	./trainDir/train-spam
	2.552793728090457E-7
	 739684
	 740018
	hamdiff
	334
	1405121
	1405418
	spamdiff
	297
	./testspam/spam3.Body is spam



example 3:
-----------

	java MailClassifier ./testham/hardham

output:
-------
	contentmultipart/signed;
    	boundary="==_Exmh_-199405358P";
	    micalg=pgp-sha1;
	    protocol="application/pgp-signature"
	TestVocab Size53
	I am in classify text
	ClassName is :  ./trainDir/train-spam
	prob of class is : 2.8567884282796773E-26
	ClassName is :  ./trainDir/train-ham
	prob of class is : 5.912203655031741E-4
	the document belongs to  : ./trainDir/train-ham
	probability is : 5.912203655031741E-4


Bayesian classification result



Gzip Result:
------------

	./zipResult

output:
-------
	
	./testham/hardham.Body
	./trainDir/train-ham
	5.912203655031741E-4
	 739684
	 740024
	hamdiff
	340
	1405121
	1405650
	spamdiff
	529
	./testham/hardham.Body  is ham




NOTE : U need to have the javamail api installed on your system. 
 
You could download the javaMAil Api along
with Java Beans Activation Framework from 
http://java.sun.com/products/javamail/
http://java.sun.com/products/javabeans/glasgow/jaf.html

The Spam emails & ham emails corpus I downloaded from

http://www.spamassassin.org/publiccorpus/

I have some IIT spam and ham emails too in a file named as iitspam and iitham.




Please feel free to comment on this application so i could improve more on it.
I am a data mining student.
