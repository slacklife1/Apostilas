/* 
@Author : Alifiya.Patrawala
@Data Mining  Student
Date : 7/4/2003*/



import java.lang.*;
import java.util.*;
import java.io.*;

class DataRepository
{

	public HashMap [] hm;
	public double [] totClassWords;
        public HashMap vm=new HashMap();
	public Vector C=new Vector();
	
        double totwords=0;

public   Vector  getClassList(String BaseDir)
{
               File f=new File(BaseDir);
                Vector v=new Vector();
                if(f.isDirectory())
                {
                        File []flist;
                        flist=f.listFiles();
                        for(int i=0;i<flist.length;i++)
                        {
                                if(flist[i].isDirectory())
                                {
                                        // System.out.println(flist[i]);
                                        v.addElement(flist[i].toString());
                                        //dir++;
                                }
                        }
                }
                return(v);
}

public void display()
{
for(int i=0;i<C.size();i++)
{
		
		System.out.println("i am in class : "+C.elementAt(i));
		Set set=hm[i].entrySet();
                Iterator it=set.iterator();
                //display elements
                int totCwords=0;
                while(it.hasNext())
                {
                        Map.Entry me=(Map.Entry)it.next();
                       // totCwords=totCwords+(Integer.parseInt((me.getValue()).toString()));
			System.out.print(me.getKey()+"  :  ");
			System.out.println(me.getValue());
			
                }
}
}

public  String[] getDocumentList(String Classname)
{
        File f=new File(Classname);
        String [] filelist;
        filelist=f.list();
        return(filelist);
}


public  void get(String BaseDir)
{

	//Vector C=new Vector();
        Vector Vocab=new Vector();
        //HashMap vm=new HashMap();
        double TotalDocuments=0;
        //double totwords=0;
        String[] sep=TokenSeperator.getSeperators();
        C=getClassList(BaseDir);

        double [] Pc=new double[C.size()];
        //HashMap [] hm=new HashMap[C.size()];
	 hm=new HashMap[C.size()];
	totClassWords=new double[C.size()];
        for(int i=0;i<C.size();i++)
        {       String [] D;
		
                System.out.println(C.elementAt(i));
                String save_filename=new String(C.elementAt(i).toString());
                save_filename=save_filename.concat(".out");
                D=getDocumentList((C.elementAt(i)).toString());
                TotalDocuments=TotalDocuments+D.length;

                hm[i]=new HashMap();
                for(int j=0;j<D.length;j++)
                {
                        Vector d=new Vector();
                        String pathname=new String();
                        pathname=pathname.concat((C.elementAt(i)).toString());
                        pathname=pathname.concat("/");
                        pathname=pathname.concat(D[j]);
                        System.out.println("pathname  :  "+pathname);
                        d=TextTokeniser.tokenize(pathname,sep);
                        d=Stopwords.removeSW(d);
                        hm[i]=WordMap.Create(hm[i],d);
                        vm=WordMap.Create(vm,d);
                        Vocab=Vocabulary.getVocabList(Vocab,d);
                }//end for D.length//
                Set set=hm[i].entrySet();
                Iterator it=set.iterator();
                //display elements
                int totCwords=0;
                while(it.hasNext())
                {
                        Map.Entry me=(Map.Entry)it.next();
                        totCwords=totCwords+(Integer.parseInt((me.getValue()).toString()));
                }
		//totClassWords.addElement(totCwords);
		totClassWords[i]=totCwords;
                totwords=totwords+totCwords;

                //find probability  P(Wi|Ck)

		 //hm[i]=findProbW_C(hm[i],totCwords);
                //Save probabilities to file
		FileSaver fs=new FileSaver();
                fs.Create(save_filename);
		fs.Save(new Double(D.length));
                fs.Save(new Integer(totCwords));
                set=hm[i].entrySet();
                it=set.iterator();
                while(it.hasNext())
                {
                        Map.Entry me=(Map.Entry)it.next();
                        fs.Save(me.getKey());
                       // FileSaver.Save(" ");
                        fs.Save(me.getValue());
                }
                //FileSaver.Save(hm[i]);
                fs.CloseFile();

        }

        System.out.println("vocab count = "+Vocab.size());
        System.out.println("totwords overall  = "+totwords);
	FileSaver f=new FileSaver();
        f.Create("VocabList.out");
	f.Save(new Double(TotalDocuments));
        f.Save(new Double(totwords));
        Set set=vm.entrySet();
        Iterator it=set.iterator();
        while(it.hasNext())
        {
        Map.Entry me=(Map.Entry)it.next();
        f.Save(me.getKey());
        f.Save(me.getValue());
        }
        //FileSaver.Save(Vocab);
        f.CloseFile();
        System.out.println("total documents = "+TotalDocuments);
	
	FileSaver fs=new FileSaver();
        fs.Create("Class.out");
        for(int m=0;m<C.size();m++)
        {       String [] D;
                D=getDocumentList(C.elementAt(m).toString());
                fs.Save(C.elementAt(m));
                fs.Save(new Double(D.length));
                //System.out.println("Pc["+m+"]"+Pc[m]);
        }
        fs.CloseFile();

}


}//end class
