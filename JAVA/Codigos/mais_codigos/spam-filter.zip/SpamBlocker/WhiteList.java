/* 
@Author : Alifiya.Patrawala
@Data Mining  Student
Date : 7/4/2003*/



import java.lang.*;
import java.io.*;
public class WhiteList
{
	public static void Add(String user)
	{
		BufferedReader in;
			
		    try{	
		    in=new BufferedReader(new FileReader(new String("BlockedList.dat")));
			String str=in.readLine();
			while(str!=null)
			{
				if(str.equalsIgnoreCase(user))
				{
					System.out.println("This user is already blocked. U cant add to Addrlist");
					System.exit(0);
				}
				str=in.readLine();
			}

		    }catch(Exception e){;}
		try{
                    in=new BufferedReader(new FileReader(new String("AddrList.dat")));
                    in.close();
                    PrintWriter out= new PrintWriter(new BufferedWriter(new FileWriter(new File("AddrList.dat"),true)));
                    out.println(user);
                    out.close();
                }catch(Exception e){FileSaver fs=new FileSaver();
			fs.Create("AddrList.dat");
                        fs.Save(user);
                        fs.CloseFile();
                }

	}
}
