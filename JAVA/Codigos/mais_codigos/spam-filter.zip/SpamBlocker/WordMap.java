/* 
@Author : Alifiya.Patrawala
@Data Mining  Student
Date : 7/4/2003*/




import java.lang.*;
import java.io.*;
import java.util.*;

public class WordMap
{
	public static HashMap Create(HashMap hm,Vector d)
	{
		 //  HashMap hm=new HashMap();
		   for(int k=0;k<d.size();k++)
                   {

                           //if(uniqueWords.contains(d.elementAt(k)));
                           //else uniqueWords.addElement(d.elementAt(k));

                           if(hm.containsKey(d.elementAt(k)))
                           {
                                int cnt=Integer.parseInt(hm.get(d.elementAt(k)).toString());
                                cnt=cnt+1;
                                hm.put((d.elementAt(k)),new Integer(cnt));
                                //totwords++;
                           }
                           else
                           {
                                hm.put((d.elementAt(k)),new Integer(1));
                                //totwords++;
                           }
                   }
		   return(hm);
	}
}
