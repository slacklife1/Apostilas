/* Used for Classifying  your emails
@Author : Alifiya.Patrawala
@Data Mining  Student
Date : 7/4/2003*/

import java.lang.*;
import java.io.*;
public class MailClassifier
{
	public static void main(String args[])
	{
		try{
                        BufferedReader in=new BufferedReader(new FileReader(new String("confirm_train.dat")));
                        if(in.readLine().equals("Y"))
                        {
                                Classify C=new Classify();
                                C.IsSpam(args[0]);
                        }

                        }catch(Exception e){e.printStackTrace();System.out.println("Get ur data trained first");}



		
	}
}
