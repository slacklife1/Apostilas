/* 
@Author : Alifiya.Patrawala
@Data Mining  Student
Date : 7/4/2003*/



import java.lang.*;
public class Result
{
	double probval;
	String classname;
	public void put(Object name,double val)
	{
		classname=name.toString();
		probval=val;
	}
}
