/* 
@Author : Alifiya.Patrawala
@Data Mining  Student
Date : 7/4/2003*/





import java.lang.*;
import java.util.*;
import java.io.*;
import javax.mail.*;
import javax.mail.internet.*;
class Train{
	
	public static void TrainEmail(Object arg1, Object arg2,Object arg3,Object arg4)
	{
		String obname=new String(arg2.toString());
		System.out.println("obname"+obname);
                File f=new File(obname);
                if(f.isDirectory())
                {
                        String[] filelist;
                        filelist=f.list();
			extractbody(new String(arg1.toString()),new String(arg2.toString()));
			extractbody(new String(arg3.toString()),new String(arg4.toString()));
                }
		trainbody();
		

	}

	public static void trainbody()
	{
		
			DataRepository DR=new DataRepository();
		        DR.get("./trainDir");
			NaiveBayes.train(DR);
	}
	public static void extractbody(String arg1,String arg2)
	{
		
			//extract body from emails 
			File trainDir=new File("trainDir");
			trainDir.mkdir();
		/*trained data will be stored in folder trainDir*/	
			String filename=new String("trainDir/train");
			String obname=new String(arg2.toString());
	                File f=new File(obname);
	                if(f.isDirectory())
        	        {
                        String[] filelist=f.list();
			System.out.println("filelist length "+filelist.length);
			filename=filename.concat(arg1);
			File fp=new File(filename);
			boolean b=fp.mkdir();
			System.out.println("B : "+b);
			String test=new String("gzip");
			test=test.concat(arg1);
			FileSaver gzip=new FileSaver();
			gzip.Create(test);
			for(int i=0;i<filelist.length;i++)
			{
			try{
			String pathname=fp.toString();
			pathname=pathname.concat("/");
			pathname=pathname.concat(filelist[i]);
			String str=obname.concat("/");
			str=str.concat(filelist[i]);
			
			InputStream io= new FileInputStream(str);
			MimeBodyPart bp=new MimeBodyPart(io);
			BodyPart mbp=new MimeBodyPart(io);
			String msg;
			String content=bp.getContentType();
			System.out.println("content"+content);
         		if(content.startsWith("multipart"))
			{
			 Multipart multipart = (Multipart)bp.getContent();
			 int z=multipart.getCount();
			 System.out.println("filename : "+str);
			 System.out.println("MULTIPART COUNT"+z);
			 mbp=multipart.getBodyPart(0);	
			 msg=mbp.getContent().toString();
			}	
         		else
			 msg= bp.getContent().toString();
			gzip.Save(msg);
			///////copy messg here to a file //////
			FileSaver fs=new FileSaver();
			fs.Create(pathname);
			fs.Save(msg);
			fs.CloseFile();
			
			}catch(Exception e){e.printStackTrace();}
			}
			gzip.CloseFile();
			}
						
	}


	


}

