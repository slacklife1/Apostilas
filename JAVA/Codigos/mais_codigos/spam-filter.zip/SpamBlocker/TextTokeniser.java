
/* 
@Author : Alifiya.Patrawala
@Data Mining  Student
Date : 7/4/2003*/


import java.lang.*;
import java.io.*;
import java.util.*;


public class TextTokeniser
{


 public static Vector tokenize(String filename,String [] sep)
        {
                        String str;
                        Vector vm=new Vector();
                        try{
                        BufferedReader in= new BufferedReader(new FileReader(new String(filename)));
                        str=in.readLine();
                        while(str!=null)
                        {

                              StringTokenizer s = new StringTokenizer(str);
                              while (s.hasMoreTokens())
                              {
                                        String token;
                                        token=s.nextToken();
                                        token=token.toLowerCase();


                                         for(int q=0;q<sep.length;q++)
                                         {
                                                StringTokenizer subs=new StringTokenizer(token,sep[q]);
                                                while (subs.hasMoreTokens())
                                                {
                                                        token=subs.nextToken();
                                                }
                                        }
					 vm.addElement(token);

                             }
                                str=in.readLine();
                        }
                        }catch(Exception e){e.printStackTrace();}
                        return(vm);
        }



}
