/* 
@Author : Alifiya.Patrawala
@Data Mining  Student
Date : 7/4/2003*/



import java.util.*;
import java.lang.*;
import java.io.*;

public class Stopwords
{

	public static  Vector removeSW(Vector vm)
	{
		List sw;
		sw=Arrays.asList(stopList.getStopWordList());
		Vector v=new Vector();
		for(int i=0;i<vm.size();i++)
		{
			if((sw.contains(vm.elementAt(i))) |((vm.elementAt(i)).toString()).matches("[0-9]+"))
			{
			}
			else
			{
				v.addElement(vm.elementAt(i));
			}
		}
		return(v);
	}

}
