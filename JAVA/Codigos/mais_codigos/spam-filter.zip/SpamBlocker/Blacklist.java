/* 
@Author : Alifiya.Patrawala
@Data Mining  Student
Date : 7/4/2003*/



import java.lang.*;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;
import java.io.*;
public class Blacklist
{
	public static void Add(String user)
	{
		FileSaver fs=new FileSaver();
		try{
                    BufferedReader in=new BufferedReader(new FileReader(new String("BlockedList.dat")));
		    in.close();
   		    PrintWriter out= new PrintWriter(new BufferedWriter(new FileWriter(new File("BlockedList.dat"),true)));
 		    out.println(user);
		    out.close();
		}catch(Exception e){fs.Create("BlockedList.dat");
			fs.Create("BlockedList.dat");
			fs.Save(user);
			fs.CloseFile();
		}		
	}
}
