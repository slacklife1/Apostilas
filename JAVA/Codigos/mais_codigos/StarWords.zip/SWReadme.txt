Star Words Applet
--------------------
Date: 21st November 1998
Author: Adam Sheik
Company: Celerity Design
E-Mail: code@celerity.demon.co.uk
WWW: www.celerity.demon.co.uk


What does the program do?
-------------------------
The applet is designed to be used as an eye-catching and original
heading for use on your web pages.  User defined messages fly towards
the viewer atop a rotating 3D starfield.  Each message is in a
different colour which gets brighter as it grows larger - the message
then fades away to make room for the next one.

How to view the program:
------------------------
Open the file StarWords.htm file in any Java enabled web browser.
View StarWords.htm to see available HTML parameters

Important files
---------------
StarWords.class	  \	
ColorUtils.class    |
Shareware.class	  |
Point3D.class       |== need to be together in the same directory	
Point2D.class       |
TrigFunctions.class |
TextReader1.class   |
Star.class         /

SWReadme.txt   >======= this file, please include it if you are sending the program to someone!
StarWords.htm  >======= sample HTML file

 			sample text file for the applet to read from.
starwords.txt  >======= Please remember that you are limited to 10 lines
			in the unregistered version.


Usage notes
-----------
To use the applet when the class files are located in a sub-directory
use the following HTML: <APPLET CODEBASE="YOURDIR" CODE="StarWords.clss"> 



Usage Restrictions
------------------
Feel free to add this applet to your own non-commercial web pages.
For commercial sites, permission is NOT given to publish the applet
on your site - you may use the unregistered version for evaluation only
and then contact me to obtain the licensed version.

It would be appreciated if you would add the following
HTML next to the applet code:
<! AUTHOR=Adam Sheik>
<! E-MAIL = code@celerity.demon.co.uk>
<! WWW = http://www.celerity.demon.co.uk>

As this version is unregistered it is limited 
to 10 lines of text - after showing those it will display
4 lines of copyright information and then loop round.

Please get in touch if you would like a licensed version!


History
-------
V1.60 -  -*New Parameter*: "BUILDSTARS" - means stars will be drawn gradually, each 
	 frame will add another star.  By default is set to TRUE.  To turn it
          off set it to FALSE. ie: <param name="BUILDSTARS" value=FALSE>
	-*New Parameter*: "STARTYPE" - graphic to use for stars. 0=dot 1=cross 
	 2=circle, 10=random (mostly crosses), 11= random (mostly circles) default
	 is 11.
	-applet now draws background colour and displays a "please wait" message
	 whilst words are loading in.  This makes your web pages look nicer when a 
 	 user has a slow connection (before an ugly grey box would be displayed)
	-can now display no stars by passing MAXSTARS=0 parameter.
	-applet has also had code optimised for speed and size.

V1.57 -  stars drawn properly (instead of just dots)
	random course changes implemented
	random star colours possible
	all star colours now subtly different
	starting default star colour definable
		
V1.53 -  flying text fully functional
	background colour now definable


Possible Future Plans!
----------------------
-Greater degree of movement in rotational axis
-Allow user input to control flight through the starfield
-Add enemy space vehicles to hunt and destroy
-Realistically map known universe
-Model thousands of alien civilisations within the universe
-Allow trading and adventuring with new universe's inhabitants
-Use my billions of new sentient lifeforms as a massively powerful 
 parallel computer to work out how to fix my Windows 95 registry 
 since I installed Internet Explorer 4




