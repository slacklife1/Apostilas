Description: 
Write to a port and read from a port in Java
Compiled in JCreator Pro 2.5 and Visual C++ 6.0 

Usage:
Work with PortIo.java and PortIO.dll

There are 4 functions in PortIO.java for Port I/O

void outportb(int,int) : write 8-bit value to the port 
void outport(int,int)  : write 16-bit value to the port  
byte inportb(int)      : read 8-bit value from the port
int inport(int)        : read 16-bit value from the port

Warning:
This Program is for Win9x/Me; for NT based Windows I/O Port should be opened first, so if you use this program 
in Win2000 or WinXP, you will get an Error.
 
Contact:
cxmatrix@yahoo.com (Mete Kart)