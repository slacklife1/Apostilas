
/* Title: I/O Port Programming in Java
   Written in September 01, 2003
   Written by cxmatrix@yahoo.com (Mete Kart)
   PortIO.dll written in Visual C++ 6.0
   JCreator Pro 2.5  
 */
 
class PortIO
{
	/*
   	   void outportb(int,int) : write 8-bit value to the port 
   	   void outport(int,int)  : write 16-bit value to the port  
   	   byte inportb(int)      : read 8-bit value from the port
   	   int inport(int)        : read 16-bit value from the port
 	 */
 	 
	public native void outportb(int port,int value);
	public native void outport(int port,int value);
	public native byte inportb(int port);
	public native int  inport(int port);
	
	public PortIO()
	{
		System.loadLibrary("PortIO");
	}
}
