
/* Title: Hexadecimal Converter
   Written in September 01, 2003
   Written by cxmatrix@yahoo.com (Mete Kart)
   JCreator Pro 2.5  
 */
 
class Hex
{
	public String Int2Hex(int val)
	{
		String hex = "";
		int val2 = val;
		
		while(val>0)
		{
			switch((int) val%16)
			{
				case 10:
					hex += "A";
					break;
				case 11:
					hex += "B";
					break;
				case 12:
					hex += "C";
					break;
				case 13:
					hex += "D";
					break;
				case 14:
					hex += "E";
					break;
				case 15:
					hex += "F";
					break;			
				default:
					hex = hex + (val%16) + "";
			}	
			val /= 16;		
		}	 
		
		if(val2<16)
		{
			hex += "0";
			if(val2 == 0)
				hex += "0";
		}
		
		return(reverse(hex));
	}
	
	private String reverse(String str)
	{
		String rev = new String();
		int len = str.length();
		
		for(int i=0;i<len;i++)
			rev = rev + str.charAt(len-i-1) + "";
		
		return rev; 
	}
}