
/* Title: Test Program for PortIO
   Written in September 01, 2003
   Written by cxmatrix@yahoo.com (Mete Kart)
   JCreator Pro 2.5  
 */

import java.io.*;

class Test
{
	public static void main(String args[])
	{
		PortIO port = new PortIO(); 
		Hex hex = new Hex();
		
		//Get System Date
		port.outportb(0x70,7);
		System.out.print("Date: " + hex.Int2Hex(port.inportb(0x71)));
		port.outportb(0x70,8);
		System.out.print("/" + hex.Int2Hex(port.inportb(0x71)));
		port.outportb(0x70,9);
		System.out.println("/" + hex.Int2Hex(port.inportb(0x71)));
		 
		//Get System Time
		port.outportb(0x70,4);
		System.out.print("Time: " + hex.Int2Hex(port.inportb(0x71)));
		port.outportb(0x70,2);
		System.out.print(":" + hex.Int2Hex(port.inportb(0x71)));
		port.outportb(0x70,0);
		System.out.println(":" + hex.Int2Hex(port.inportb(0x71)));
		
		/*
		//Bios Password Reset
		port.outportb(0x70,0x2E);
		port.outportb(0x71,0xFF);
		*/
	}
}
