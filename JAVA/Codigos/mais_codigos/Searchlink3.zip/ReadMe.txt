//////////////////////////////////////////////////////////////
Please Load the file SeaDemo1.html into your web browser!
You may redistribute these shareware files. 
Searchlink Demo V 3.0 This is a Demonstration Version Only!
////////////////////////////////////////////////////////////// 
PLEASE READ THE HTML VERSION OF THIS DOCUMENT!!
                                SearchlinkV3
      �Searchlink Search Engine description and instructions
Working Demonstration
Part1 General Description
Part2 Creating the Search links file
Part3 Setting Up Searchlink on your page
Part4 Common problems and solutions




     Part1 General Description
     Searchlink can be included on any html webpage and does not require a Java server. Web site guests use Searchlink in
     a similar way to other Internet search engines, once a list is returned the links can then be followed with a single click
     over the appropriate link name. The links themselves are stored and formatted in a text file, this allows easy editing and
     fast access. Like many other search engines Searchlink allows for �all word� or �any word� searches. These keywords
     are compared with the keywords you supply when creating the links text file. (The links text file will be discussed in
     much greater detail later) 

     Part2 Creating the Search links file
     Before setting up Searchlink on your page it is advised that you are familiar with the example Search2.txt links file.
     Creating your own links file is as easy as creating an html file. 
     1: Open a new text file in your favorite text editor "word processor". 
     2: Each link must occur on it�s own line within the links file. 

     <Full Url><Name to appear as link>any keywords which may be appropriate 

     3: Use one line per link and format as follows. ( you must start from the very first line of the file) 
     Example of a links file Search2.txt 

     <http://www.microsoft.com><Microsoft>windows 95 office excel 
     <http://www.yahoo.com><Yahoo >Search engine find lookup 
     <http://silk.webware.co.nz/><Silk Webware>java programming webpage graphics applets 


     Note that the URL and the Name are included within < > each respectively and the keywords follow afterwards. It is
     very important that the links are formatted in this way, Search link will not understand any other format. 
     <http://silk.webware.co.nz><Silk Webware>applets java webpage design 

     4: When selecting your keywords forget about case, it is irrelevant. Try to use the longest version of the words.
     Example, rather than using the word "design" use "designing" or "designer" these words still contain the word "design"
     which Searchlink will find, as well as the longer words if required. 
     5: Continue to fill each line with a new link in the format discussed. Note:Searchlink searches from the top of the list of
     links first so when your adding new links add them to the top of the list so they will show first in the search. 
     6: You can now name and save this file as a text (.txt) file, the name you give it must be used later in the applet
     parameters (More about that later). 

     Part3 Setting Up Searchlink on your page
     Searchlink is easy to set up and use, if you have any trouble please do not hesitate to email us at
     support@silk.webware.co.nz. Without a RegistrationID, Searchlink will display "unregistered version", this message is
     not displayed if you have a correct RegistrationID. 
     1: Simple setup: RegistrationID and the links file Note sample files afSearchlink.html and Search2.txt are included
     SearchDemo.html 

     <applet
     code=afSearchlink.class
     width=300
     height=200 >
     <param name=RegistrationID value="Q7182">
     <param name=ListName value="Search2.txt">
     </applet> 

     In the simplest setup these html tags are included on the page that you wish Searchlink to be on. Within the same
     directory as this html file you must include the two files afSearchlink.class and afSearch2.class and the links file (ie
     Search2.txt) which contains the link names, urls and keywords; (A full description of how to construct this file was given
     earlier, you may wish to open the search2.txt file in a text editor �word processor� to get a general idea of its format) 

     Once you have purchased your RegistrationID enter it in as a parameter; Note: Each RegistrationID is unique and is to
     be used in accordance with the Single site License Searchlink will display Unregistered version if the incorrect
     RegistrationID is used, when on the internet

     "if your RegistrationID is du8765 then the following will work" 
     <param name=RegistrationID value="du8765"> 


     2: Simple setup: Height Width parameters The height of searchlink must always be set to 200, however if you wish
     to increase or decrease the width you can. 

     <applet
     code=afSearchlink.class
     width=500
     height=200 >
     <param name=RegistrationID value="RegistrationID">
     <param name=ListName value="Search2.txt">
     </applet>


     3:Optional setup: Frame parameter With this version of Searchlink we have included the option of allowing the
     �Linked� page to be opened in the frame of your choice. If you decide to ignore this option, Searchlink will open the
     page in the current frame . The following are the values which are currently accepted. Searchlink follows the current
     standard HTML conventions with respect to frames. 

     "_self" ---show in the current frame <default> 
     "_parent" -----show in the parent frame 
     "_top" -----show in the top most frame 
     "_blank" ------show in a new unnamed top-level window 
     <other> -----show in new top-level window named <other> 

     Example:

     This will cause Searchlink to open the "linked" page in a new unnamed top-level window. 

     <applet
     code=afSearchlink.class
     width=300
     height=200 >
     <param name=RegistrationID value="RegistrationID">
     <param name=ListName value="Search2.txt">
     <param name=Frame value="_blank"> </applet>

     4:Optional setup: BackImage parameter Some designers have asked that we include a background image, this
     allows you to improve the general appearance of Searchlink. You may wish to set this parameter to the current
     background of the page. Please experiment with BackImage as certain colors and patterns can enhance the general look
     dramatically. Please note that only .jpg and .gif formats are acceptable. Hint: keep the patterns and colors within the
     graphics files as soft as possible. Searchlink will automatically "wallpaper" the Search Engine, so the size of the image is
     not important, however larger images take longer to load. 

     <applet
     code=afSearchlink.class
     width=300
     height=200 >
     <param name=RegistrationID value="RegistrationID">
     <param name=ListName value="Search2.txt">
     <param name=Frame value="_self">
     <param name=BackImage value="marble2.gif">
     </applet>

     5:Optional setup: GreenList parameter 

     If you set GreenList to true the displayed list will be green, if set to false it will be red. The default color is green. 

     <applet
     code=afSearchlink.class
     width=300
     height=200 >
     <param name=RegistrationID value="RegistrationID">
     <param name=ListName value="Search2.txt">
     <param name=Frame value="_self">
     <param name=BackImage value="marble2.gif">

     <param name=GreenList value="true">

     </applet>

     6:Full Setup Example This sample setup shows all the HTML tags required show the marble2.gif both as the
     background of the the html page and as the background of Searchlink. 

     <html>
     <head>
     <title>Searchlink Search Engine</title>
     </head>
     <body background="marble2.gif">
     <br><br><br><br><br>
     <center>

     <applet
     code=afSearchlink.class
     width=300
     height=200 >
     <param name=RegistrationID value="RegistrationID">
     <param name=ListName value="Search2.txt">
     <param name=Frame value="_self">
     <param name=BackImage value="marble2.gif">
     <param name=GreenList value="true">

     </applet>

     </center>
     </body>
     </html> 

     Part4 Common Questions and Remedies; 
     The most Common mistake webpage designers make when using Searchlink is incorrect "case". Follow the
     sample html files using uppercase and lowercase respectively. 


     Q1: Why can�t I see the Searchlink on my page? 
     a: You may have made a mistake in the HTML tags used to embed Searchlink on your page. Check both the Spelling
     and the Case. 
     b: Have you included the appropriate .class files in the same directory as the page containing Searchlink The following
     are both required.

     afSearchlink.class
     afSearch2.class

     c: Are you using a Java enabled browser? Find out how to get one. Most browsers released today are Java enabled. 

     Q2: Why won�t my �linked� page open? 
     a:Have you referred to your links text file with the exact same name in your parameters? ie.If your links file is called
     Search2.txt then the following is correct 

     <param name=ListName value="Search2.txt"> 

     b: Does the formatting of the links file follow these strict rules?......1 link per line....... ......<> around both the URL
     �address of the link� and the name of the link...........the keywords should not be surrounded by any �brackets�.....there
     should be no lines left blank. 
     c Is the link still valid? 
     Q3: Why does Searchlink display "Unregistered version!"
     a:Do you have a correct RegistrationID, check the sequence and case.
     b:Is the Version of Searchlink afSearchlink "Searchlinkv3" this is the only version that accepts RegistrationID, "Older
     versions that accept UserCodes will not accept RegistrationID" 
     c: If you have a RegistrationID and Searchlink still displays Unregistered version!, Email us at
     support@silk.webware.co.nz, we will check out the problem for you. 

     Q4: Why is there no background image? 
     a: Check your Html parameters, spelling and case 
     b: The image you are referring to may be a .gif not a .jpg (vs/vs) 
     c: Is the image file in the same directory? 

     Q5: I have just changed the parameters of the Searchlink, Search engine but it appears the same as before. 
     a: You must reload the page in a new browser window, and completely clear the cache.


               If you have any questions regarding the correct setup of Searchlink, please email us at
          support@silk.webware.co.nz For more exciting webpage enhancements please visit Silk Webware
                                            at Silk Webware

