JDBMan is a database management tool.
At the moment you can connect to the database, browse
database objects in the tree (tables, views), view and
modify table contents. I tested it on Oracle server
via Oracle jdbc thin driver. You can use it on any DB
if you make some changes in source.