//author: Rustam M. Bunyadov
//release date: 09-01-2003
//e-mail: rustamb@risk.az
//feel free to contact me if you have any questions

package JavaDBManager;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.sql.*;
import javax.swing.tree.*;

public class JDBMan extends JPanel {
    private Connection conn = null;
    private ResultSet rs = null;
    private JTextField HostPortSid = null;
    private JTextField username = null;
    private JTextField password = null;
    private MyTableModel tableModel = null;
    private JTable table = null;
    private MyTreeModel treeModel = null;
    private JTree tree = null;
    private Statement stmt = null;
    private DatabaseMetaData dbmd = null;
    private ResultSet temprs = null;
    
    private String[] typeTable = {"TABLE"};
    private String[] typeView = {"VIEW"};
    private String[] typeSystemTable = {"SYSTEM TABLE"};
    private String[] typeGlobalTemporary = {"GLOBAL TEMPORARY"};
    private String[] typeLocalTemporary = {"LOCAL TEMPORARY"};
    private String[] typeAlias = {"ALIAS"};
    private String[] typeSynonym = {"SYNONYM"};
    
    private String[] typeTableRS = null;
    private String[] typeViewRS = null;
    private String[] typeSystemTableRS = null;
    private String[] typeGlobalTemporaryRS = null;
    private String[] typeLocalTemporaryRS = null;
    private String[] typeAliasRS = null;
    private String[] typeSynonymRS = null;
    
    public static void main(String[] args) {
        JFrame frame = new JFrame("JDBMan alpha");
        Container contentPane = frame.getContentPane();
        
        contentPane.add(new JDBMan());
        
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        frame.pack();
        frame.setVisible(true);
    }
    
    void init() {
        try {
            //by changing this fragment of code you can use JDBMan for any DB
            Class.forName("oracle.jdbc.driver.OracleDriver");
            conn = DriverManager.getConnection("jdbc:oracle:thin:@" + HostPortSid.getText(), username.getText(), password.getText());
            //////////////////////////////////////////////////
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            dbmd = conn.getMetaData();
            
            typeTableRS = getTableNames(typeTable);
            typeViewRS = getTableNames(typeView);
            typeSystemTableRS = getTableNames(typeSystemTable);
            typeGlobalTemporaryRS = getTableNames(typeGlobalTemporary);
            typeLocalTemporaryRS = getTableNames(typeLocalTemporary);
            typeAliasRS = getTableNames(typeAlias);
            typeSynonymRS = getTableNames(typeSynonym);
            
            treeModel = new MyTreeModel();
            tree.setModel(treeModel);
            tree.addTreeSelectionListener(new MyTreeSelectionListener());
        } catch(ClassNotFoundException cnfe) {
            System.out.println("init() failed");
            System.out.println(cnfe.getMessage());
            System.exit(0);
        } catch(SQLException sqle) {
            System.out.println("init() failed");
            System.out.println(sqle.getMessage());
            System.exit(0);
        }
    }
    
    String[] getTableNames(String[] type) {
        String[] typeRS = null;
        int rowsCount = 0;
        try {
            temprs = dbmd.getTables(null, "FIRE", "%", type);
            while (temprs.next()) {
                rowsCount++;
            }
            temprs.close();
            typeRS = new String[rowsCount];
            temprs = dbmd.getTables(null, "FIRE", "%", type);
            while (temprs.next()) {
                java.lang.reflect.Array.set(typeRS, temprs.getRow()-1, temprs.getString(3));
            }
            return typeRS;
        }
        catch (SQLException sqle) {
            System.out.println("getTableNames failed");
            System.out.println(sqle.getMessage());
        }
        return typeRS;
    }
    
    boolean connectionEstablished() {
        boolean b = true;
        try {
            if (tree.getSelectionPath() != null) {
                rs = stmt.executeQuery("select \u002A from " + tree.getSelectionPath().getLastPathComponent());
                b = true;
            } else b = false;
        } catch(SQLException sqle) {
            System.out.println("Connection was not established");
            System.out.println(sqle.getMessage());
            b = false;
        }
        return b;
    }
    
    class MyTreeSelectionListener implements TreeSelectionListener {
        
        public void valueChanged(javax.swing.event.TreeSelectionEvent treeSelectionEvent) {
            if(connectionEstablished()) {
                tableModel = new MyTableModel();
                table.setModel(tableModel);
            }
        }
        
    }
    
    class MyTreeModel implements TreeModel {
        
        String[] getTempRS(Object parent) {
            if (parent.equals(typeTable[0]))
                return typeTableRS;
            else if (parent.equals(typeView[0]))
                return typeViewRS;
            else if (parent.equals(typeSystemTable[0]))
                return typeSystemTableRS;
            else if (parent.equals(typeGlobalTemporary[0]))
                return typeGlobalTemporaryRS;
            else if (parent.equals(typeLocalTemporary[0]))
                return typeLocalTemporaryRS;
            else if (parent.equals(typeAlias[0]))
                return typeAliasRS;
            else return typeSynonymRS;
        }
        
        public void addTreeModelListener(javax.swing.event.TreeModelListener treeModelListener) {
        }
        
        public Object getChild(Object parent, int childIndex) {
            if (parent.equals("FIRE")) {
                switch (childIndex) {
                    case 0:
                        return typeTable[0];
                    case 1:
                        return typeView[0];
                    case 2:
                        return typeSystemTable[0];
                    case 3:
                        return typeGlobalTemporary[0];
                    case 4:
                        return typeLocalTemporary[0];
                    case 5:
                        return typeAlias[0];
                    default :
                        return typeSynonym[0];
                }
            } else {
                return getTempRS(parent)[childIndex];
            }
        }
        
        public int getChildCount(Object parent) {
            if (parent.equals("FIRE")) {
                return 7;
            } else {
                return getTempRS(parent).length;
            }
        }
        
        public int getIndexOfChild(Object parent, Object childNode) {
            if (parent.equals("FIRE")) {
                if (childNode.equals(typeTable[0]))  return 0;
                else if (childNode.equals(typeView[0])) return 1;
                else if (childNode.equals(typeSystemTable[0])) return 2;
                else if (childNode.equals(typeGlobalTemporary[0])) return 3;
                else if (childNode.equals(typeLocalTemporary[0])) return 4;
                else if (childNode.equals(typeAlias[0])) return 5;
                else return 6;
            } else {
                for (int i = 0; i < getTempRS(parent).length; i++) {
                    if (getTempRS(parent)[i].equals(childNode))
                        return i;
                }
            }
            return 0;
        }
        
        public Object getRoot() {
            return "FIRE";
        }
        
        public boolean isLeaf(Object obj) {
            if (obj.equals(getRoot()) || obj.equals(typeTable[0]) || obj.equals(typeView[0])
             || obj.equals(typeSystemTable[0]) || obj.equals(typeGlobalTemporary[0])
             || obj.equals(typeLocalTemporary[0]) || obj.equals(typeAlias[0]) 
             || obj.equals(typeSynonym[0])) return false;
            return true;
        }
        
        public void removeTreeModelListener(javax.swing.event.TreeModelListener treeModelListener) {
        }
        
        public void valueForPathChanged(javax.swing.tree.TreePath treePath, Object obj) {
        }
        
    }
    
    class MyTableModel implements TableModel {
        
        public void addTableModelListener(TableModelListener l) {
        }
        
        public Class getColumnClass(int columnIndex) {
            Object obj = null;
            try {
                rs.first();
                do {
                    if (getValueAt(rs.getRow()-1, columnIndex) != null){
                        obj = getValueAt(rs.getRow()-1, columnIndex);
                        break;
                    }
                } while (rs.next());
            } catch (SQLException sqle) {
                System.out.println(sqle.getMessage());
            }
            return obj.getClass();
        }
        
        public int getColumnCount() {
            int i = 0;
            try {
                i = rs.getMetaData().getColumnCount();
            } catch(SQLException sqle) {
                System.out.println(sqle.getMessage());
            }
            return i;
        }
        
        public String getColumnName(int columnIndex) {
            String s = "";
            try {
                s = rs.getMetaData().getColumnName(columnIndex+1);
            } catch(SQLException sqle) {
                System.out.println(sqle.getMessage());
            }
            return s;
        }
        
        public int getRowCount() {
            int i = 0;
            try {
                rs.last();
                i = rs.getRow();
            } catch(SQLException sqle) {
                System.out.println(sqle.getMessage());
            }
            return i;
        }
        
        public Object getValueAt(int rowIndex, int columnIndex) {
            Object obj = null;
            try {
                rs.first();
                do  {
                    if (rs.getRow() == rowIndex + 1) {
                        obj = rs.getObject(columnIndex + 1);
                        break;
                    }
                } while (rs.next());
            } catch (SQLException sqle) {
                System.out.println(sqle.getMessage());
            }
            return obj;
        }
        
        public boolean isCellEditable(int rowIndex, int columnIndex) {
            return true;
        }
        
        public void removeTableModelListener(TableModelListener l) {
        }
        
        public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
            String updateQuery = "";
            String updateConditions = "";
            try {
                rs.first();
                do {
                    if (rs.getRow() == rowIndex + 1) {
                        updateQuery = " set " + rs.getMetaData().getColumnName(columnIndex+1) + "='" + aValue + "'";
                        for (int i = 0; i < rs.getMetaData().getColumnCount(); i++) {
                            if (i != columnIndex && getValueAt(rowIndex, i) != null) {
                                updateConditions += rs.getMetaData().getColumnName(i+1) + "='" + getValueAt(rowIndex, i) + "' and ";
                            }
                        }
                        updateConditions = updateConditions.substring(0, updateConditions.length() - 4);
                        try {
                            stmt.executeUpdate("update " + tree.getSelectionPath().getLastPathComponent() + updateQuery + " where " + updateConditions);
                        } catch(Exception e) {
                            System.out.println(e.getMessage());
                        }
                        connectionEstablished();
                        updateQuery = "";
                        updateConditions = "";
                        break;
                    }
                } while (rs.next());
            } catch (SQLException sqle) {
                System.out.println(sqle.getMessage());
            }
        }
        
    }
    
    JDBMan() {
        HostPortSid = new JTextField("dbserver:1521:absrs");
        username = new JTextField("fire");
        password = new JTextField("f");
        
        JPanel jp1 = new JPanel();
        jp1.setLayout(new GridLayout(2, 3));
        
        jp1.add(new JLabel("Host:Port:Sid"));
        jp1.add(new JLabel("User name"));
        jp1.add(new JLabel("Password"));
        jp1.add(HostPortSid);
        jp1.add(username);
        jp1.add(password);
        
        table = new JTable();
        
        tree = new JTree(new DefaultMutableTreeNode("FIRE"));
        //tree.setPreferredSize(new Dimension(200, 0));
        JPanel jp2 = new JPanel();
        jp2.setLayout(new BorderLayout());
        jp2.add(jp1, BorderLayout.NORTH);
        jp2.add(new JScrollPane(tree), BorderLayout.WEST);
        jp2.add(new JScrollPane(table), BorderLayout.CENTER);
        
        jp2.setPreferredSize(new Dimension(800, 400));
        
        add(jp2);
        init();
    }
    
}