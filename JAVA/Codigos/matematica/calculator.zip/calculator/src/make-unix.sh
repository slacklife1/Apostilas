#!/bin/sh

$JAVA_HOME/bin/javac main/Cal.java
