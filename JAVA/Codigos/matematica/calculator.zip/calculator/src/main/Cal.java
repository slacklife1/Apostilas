package main;

import java.awt.*;
import java.util.Vector;
import tools.*;

public class Cal extends Frame {

 Button edit,par1,par2,jam,menha,taghsim,zarb,moma,iconi;
 TextField tf = new TextField("Welcome Here !");
 String[] s1 = {"7","8","9","4","5","6","1","2","3","0","+/-"};
 StringBuffer buff = new StringBuffer("");

 public Cal(){
	super("Calculator");
	setLayout(new BorderLayout(3,3));
	Panel pp = new Panel();
	pp.setLayout(new GridLayout(1,1));
	pp.add(tf);
	add("North",pp);
	tf.setEditable(false);
	tf.setFont(new Font("Fixedsys",1,14));
	this.setFont(new Font("Comic Sans MS",1,12));
	setBackground(Color.lightGray);

	Panel cp = new Panel();
	cp.setLayout(new GridLayout(4,4,3,3));
	for(int i=0 ; i<=2 ; i++)
		cp.add(new Button(s1[i]));
	cp.add(taghsim = new Button("/"));
	for(int i=3 ; i<=5 ; i++)
		cp.add(new Button(s1[i]));
	cp.add(zarb = new Button("*"));
	for(int i=6 ; i<=8 ; i++)
		cp.add(new Button(s1[i]));
	cp.add(menha = new Button("_"));
	cp.add(moma = new Button("."));
	cp.add(new Button(s1[9]));
	cp.add(new Button(s1[10]));
	cp.add(jam = new Button("+"));
	add("Center",cp);

	Panel sp = new Panel();
	sp.setLayout(new GridLayout(1,3,3,3));
	sp.add(edit = new Button("Edit"));
	sp.add(par1 = new Button("("));
	sp.add(par2 = new Button(")"));
	par2.disable();
	sp.add(new Button("="));
	add("South",sp);

	Panel wp = new Panel();
	wp.setLayout(new GridLayout(4,1,3,3));
	wp.add(new Button("C"));
	Button mb1,mb2,mb3;
	wp.add(mb1 = new Button("MC"));
	wp.add(mb2 = new Button("MR"));
	wp.add(mb3 = new Button("M+"));
	mb1.setEnabled(false); 	mb2.setEnabled(false);
	mb3.setEnabled(false);
	add("West",wp);
 }

 public boolean action(Event evt,Object arg){

   if(evt.target instanceof Button){
	char amal;
	if(buff.toString().length() > 0)
	     amal = buff.toString().charAt(buff.toString().length()-1);
	else amal = '-';

	if(arg.equals("/")){
		setAmal(false);
		buff.append(buff.toString().length() > 0 ? arg : "0"+arg);
	}
	else if(arg.equals("*")){
		setAmal(false);
		buff.append(buff.toString().length() > 0 ? arg : "0"+arg);
	}
	else if(arg.equals("+")){
		setAmal(false);
		buff.append(buff.toString().length() > 0 ? arg : "0"+arg);
	}
	else if(arg.equals("_")){
		setAmal(false);
		buff.append(buff.toString().length() > 0 ? "-" : "0-");
	}
	else if(arg.equals(".")){
		setAmal(false);
		buff.append(buff.toString().length() > 0 ? arg : "0"+arg);
	}
	else if(arg.equals("+/-")){
          if(buff.toString().length() > 0){
           Validate vl = new Validate(buff.toString());
	   double d1 = Double.parseDouble(vl.getHasel());
	   d1 *= -1;
	   String st = String.valueOf(d1);

	   if(st.charAt(0) == '-') buff = new StringBuffer("_"+st.substring(1));
	   else buff = new StringBuffer(st);
	  }
 	  else if(buff.toString().length() ==0)
		buff = new StringBuffer("_0");
	}
	else if(arg.equals("=")){
		String sd = buff.toString();
		Validate valid = sd.length() > 0 ? new Validate(sd) : new Validate("0");
		tf.setText(valid.getHasel().charAt(0)=='-' ? "_"+valid.getHasel().substring(1) : valid.getHasel());
	}
	else if(arg.equals("C")){
		buff = new StringBuffer("");
		setAmal(true);
	}
	else if(arg.equals("(")){
		setAmal(true);
		Dialog2 d2 = new Dialog2(this);
		d2.show();
		int l = buff.toString().length();
            try {
		if(d2.getHasel().charAt(0) == '-'){
			if(buff.toString().charAt(l-1) == '+'){
				 buff = new StringBuffer(buff.toString().substring(0,l-1));
			         buff.append(d2.getHasel());
			}
			else if(buff.toString().charAt(l-1) == '-'){
				 buff = new StringBuffer(buff.toString().substring(0,l-1)+"+");
			         buff.append(d2.getHasel().substring(1));
			}
			else if(buff.toString().charAt(l-1) == '/' || buff.toString().charAt(l-1) == '*'){
			  buff.append(d2.getHasel().substring(1));
		          if(buff.toString().length() > 0){
        		   Validate vl = new Validate(buff.toString());
			   double d1 = Double.parseDouble(vl.getHasel());
			   d1 *= -1;
			   String st = String.valueOf(d1);
			   if(st.charAt(0) == '-') buff = new StringBuffer("_"+st.substring(1));
			   else buff = new StringBuffer(st);
			  }
		 	  else if(buff.toString().length() ==0)
				buff = new StringBuffer("_0");

			}
		}
		else buff.append(d2.getHasel());
	    }catch(StringIndexOutOfBoundsException e){ par1.enable();}
	}
	else if(arg.equals(")")){
	}
	else if(arg.equals("MR")){

	}
	else if(arg.equals("MC")){
	}
	else if(arg.equals("M+")){
	}
	else if(arg.equals("Edit")){
		tf.setText(buff.toString());
		if(!tf.isEditable()) tf.setEditable(true);
		edit.setLabel(" OK ");
	}
	else if(arg.equals("Iconify")){
		this.setSize(280,35);
		iconi.setLabel("Deiconify");
	}
	else if(arg.equals("Deiconify")){
		this.setSize(280,200);
		doLayout();
		iconi.setLabel("Iconify");
	}
	else if(arg.equals(" OK ")){
		edit.setLabel("Edit");
		if(tf.isEditable()) tf.setEditable(false);
		buff = new StringBuffer(tf.getText());
		tf.setText(buff.toString());
	}
	else {    // adad ha
		buff.append(arg);
		setAmal(true);
	}
   } // end of Button
   else if(evt.target instanceof TextField){
		edit.setLabel("Edit");
		if(tf.isEditable()) tf.setEditable(false);
		buff = new StringBuffer(tf.getText());
		tf.setText(buff.toString());
   }
   if(!arg.equals("=")) tf.setText(buff.toString());
   return true;
 } // end of action

 private void setAmal(boolean stat){
   Button[] m = {jam,menha,taghsim,zarb};
	if(stat){
	for(int i=0 ; i<m.length ; i++)
		m[i].enable();
	par1.disable();
	}

	else {
	for(int i=0 ; i<m.length ; i++)
		m[i].disable();
	par1.enable();
	}
 }

 public static void main(String args[]){
	Frame calc = new Cal(){
		public boolean handleEvent(Event evt){
		    if(evt.id == Event.WINDOW_DESTROY){ System.exit(0); return true;}
		    else return super.handleEvent(evt);
		}
	};
	calc.setSize(280,0);
	for(int i=0 ; i<=520 ; i+=5){
		calc.move(i,0);
		calc.show();
	try{Thread.sleep(3);}catch(InterruptedException e){}
	}
	calc.setSize(280,200);
	calc.show();
 }

}