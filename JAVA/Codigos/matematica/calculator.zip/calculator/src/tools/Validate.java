package tools;

import java.util.Vector;

public class Validate {

private String adad0 = "";
private double hasel;
private Vector amal,adad;

 public Validate(String str){
	int len = str.length();
	amal = new Vector(5,2);
	adad = new Vector(3,2);

// analyzing.....
	for(int i=0 ; i<len ; i++){
		if(noAdad(str.charAt(i)) && str.charAt(i)!='.' && str.charAt(i)!='_'){
			adad.addElement(adad0);
			amal.addElement(str.charAt(i)+"");
			adad0 = new String("");
		}
        	else{
		  if(str.charAt(i)=='_') str = new String("-" + str.substring(1));
	     	  adad0 = new String(adad0+str.charAt(i));
		}
	}
	adad.addElement(adad0);
	adad.trimToSize();
	amal.trimToSize();

// Caculating.......
	int size = amal.size();
	double a1,a2;
	a1 = Double.parseDouble(adad.elementAt(0).toString());
	for(int k=0 ; k<size ; k++){
		a2 = Double.parseDouble(adad.elementAt(k+1).toString());
		String amal0 = amal.elementAt(k).toString();
		if(amal0.equals("+")){
			a1 += a2;
		}
		else if(amal0.equals("-")){
			a1 -= a2;
		}
		else if(amal0.equals("*")){
			a1 *= a2;
		}
		else if(amal0.equals("/")){
			a1 /= a2;
		}
	}  // for
     hasel = a1;
 }

 public String getHasel(){
	return (String.valueOf(hasel));
 }

 private boolean noAdad(char arg) {
	for(int j=0 ; j<=9 ; j++){
		if( (String.valueOf(j)).equals(arg+"") || (String.valueOf(j)).equals(".") )
			return false;
	}
  return true;
 }

}