#!/bin/sh

$JAVA_HOME/bin/java -jar ../calculator.jar
