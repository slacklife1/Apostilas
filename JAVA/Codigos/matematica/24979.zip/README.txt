-------------------------------------------------
4x4 Karnaugh Map Minimizer v1.0 - 12/2002
-------------------------------------------------

Author: 
	name:	Edans Sandes
	email:  snade@ig.com.br
	icq: 	77759408
	




Description:

	It creates the Karnaugh map of a function and calculates 
the minimum expression using the McCluskey algorithm. This program 
is also useful for people who want screen shots of Karnough maps.

	To run just extract the zip file to a folder and type: 
		java -jar Karnaugh.zip




How to use:

	Given some miniterms (ex. m(0,2,8) -> that means the function 
!A!B!C!D + !A!BC!D + A!B!C!D) and some don't cares (ex. dc(10)), it is 
possible to find a minimal function (in this case !B!D). (!B means not B)
	In the program there is 2 columns of check boxes. The first is
the miniterms, and the second one the don't cares. It is also possible
to change the value of a term if you click directly in the map.
	Every time you change anything in the map, the minimum expression
is automaticaly updated.
	You can make a screen shot of the map and past it in your document.

