The Millionaire Game (Client/Server via TCP/IP).
 v1.0

Author: Alexander Popov
Date  : Saturday, July 20, 2002
Homepage: http://www.geocities.com/emu8086/vb/

Screen-shot: million.gif

------ General Description and Assumptions --------

The mission of the game is to answer 15 questions and to
get 1,000,000. Wrong answer burns all the earned money until
last money stop station (stop stations are: 1,000 and 32,000).

Player can use these wheels:
   1. Help of a Friend - 3 times.
   2. Fifty-Fifty - 4 times (limited to 2 for a single question).
   3. Help of the Public (pseudo-random) - 5 times.

Server supports running several games at the same time.

Game is not started until both Player and his Friend are connected.
First Server waits for a Player then for a Friend.
Friend is rejected if Player is not connected yet, another Player is
also rejected if Friend for previous Player is not connected yet.

In case of loosing connections with the Player or Friend the game
is terminated by the Server (even if Friend's help isn't required
anymore for current game, this is done to prevent checks when
new game is started with the same Player).

Friends window is always visible. The question is shown only
when Player requested the help, and Server sends it to Friend.
When Friend is in idle state a message "Waiting for player's request...".
is shown.

Reliable TCP/IP connection is required!
In case of TCP/IP error game could be terminated
(to prevent someone to earn 1,000,000 without answering
all questions - and making us bankrupt).



------ Folders --------

To make some order, files are placed in separate folders!

"Friend"  - contains Friend station files.

"GameServer" - contains Server files.

"Player" - contains Player station files.



------ Important Remarks --------

Because of problematical setup of Java Virtual Machine on some
computers, it may be required to execute this command
before running anything:

    set classpath=.

(no quotation marks!)



------ Running --------

To start Server:
                 1. set current directory to "GameServer".
                 2. type "java Server <player_port> <friend_port>",
                    example: java Server 1234 5678
                 
To start Player station:
                 1. set current directory to "Player".
                 2. type "java GameClient <host> <friend_port>",
                    example: java GameClient localhost 1234
                 (Server should be running!).

To start Friend station:
                 1. set current directory to "Friend".
                 2. type "java FriendClient <host> <friend_port>",
                    example: java FriendClient localhost 5678
                 (Server should be running, and Player connected!).
                    


------ Classes --------

"Friend" folder (1 class):
    FriendClient:
        Description:  This class represents a friend client
                      for Millionaire Game.
        Mission:      1. Show question and 4 answers when player of
                         the game calls for friend's help.
                      2. Allow user to send an answer or "don't know".
                      3. Show the timer (30 to 0 seconds).
                      4. Allow user to send the reply until Server
                         says that time is up (timer gets to zero).
                      5. When in idle state show: "Waiting for
                         player's request...".
        Notes:        Timer is running on the server, and server will
                      not accept any answer from friend when time is up.
                      This is more reliable, since this way friend station
                      cannot make server to hang up, and wait for ever.
                      Friend's window is always visible (showing the state).

"GameServer" folder (3 classes):
    QnA:
        Description:  Questions & Answers for all games, based on 
                      Exercise #3 (Dictionary).
        Mission:      1. Load questions and answers from a given file
                         (Server uses "Questions.txt" when it creates QnA).
                      2. When asked return the required question or answer.
    Server:
        Description:  Represents a server that runs Millionaire Game(s).
        Mission:      1. Gets the connections and starts the game
                         by creating new game handlers (TheGame) for each
                         game that run inside independent threads.
                      2. Showing information about each game in GUI mode.
                      3. Allows to terminate games (even without reason).
                      4. Does not allow a Friend to be connected
                         before Player, or another Player to be connected
                         before previous Friend is connected.
    TheGame:
        Description:  Represents a single server side Millionaire Game.
        Mission:      1. Communicates with the player & his friend.
                      2. When Player is ready to receive, sends
                         a random question.
                      3. Makes sure the same question will not be asked
                         twice in the same game (probability 1:1000).
                      4. When Player answers, checks his/her answer.
                      5. Keeps all data about the game (wheels & money).
                      6. Calculates 50:50 and "The Public".
                      7. Is a communication link between Player & Friend.

"Player" folder (4 classes):
    AnswerBox:
        Description:  Represents a JCheckBox with some extended properties.
        Mission:      1. Show an answer with caption to current question.
                      2. Change colors and answer when asked.
    Chart:
        Description:  Represents a component that provides the graphical
                      representation of some values (a chart).
        Mission:      1. Show the public response in a graphical way.
                      2. Validate passed data.
    GameClient:
        Description:  Represents a client side Millionaire Game station.
        Mission:      1. Receive question from Server and show it.
                      2. Receive 4 possible answers from Server and
                         show them. (only 1 can be selected at a time).
                      3. Show wheels number (gets this info from Server).
                      4. Show how much money user has earned.
                      5. Shows friend's answer and response of the public.
                      6. Allows to send to the Server these requests:
                         a. Confirmation of the answer.
                         b. Friend's help.
                         c. Get res ponce of the public.
                         d. Remove 2 wrong answers (50:50).
                         e. Wants to retire.
    MoneyBox:
        Description:  Represents a label with some extended properties.
        Mission:      1. Show money label.
                      2. Show stop stations in different colors.
                      3. Change colors when player gets to current sum.
                      
                      
                      
------ BAT files --------

"*.bat" files can be used to run and compile the files
(only under Windows 9x/2K/XP) without typing long expressions.

If you are running under Linux or some other OS, you can look
into the "r.bat" files for parameters that are required to
run compiled classes.

("Command Prompt Here" tool from Microsoft maybe useful to open
 separate DOS prompts for each folder).

c.bat  - deletes all *.class files and 
         re-compiles all *.java files.
         (if files do not exist just compiles - DOS prompt
          error message is ignored).

p.bat  - sets the PATH for working version of JVM to run
         "java" and "javac". There is such a file in every folder
         since every station is required to be run in separate prompt.
         (not required to run this file where JDK is installed properly).
	
r.bat  - runs current station assuming that we are running
         all stations on the same machine (localhost) with default ports.
         Default player port: 1234
         Default friend port: 5678
         (there are 3 such files, one for each folder). 
         
------ Web Info --------   

http://www.geocities.com/emu8086/vb/
         


    Copyright 2002 Alexander Popov Emulation Soft.
               All rights reserved.
        http://www.geocities.com/emu8086/


All trademarks and other registered names contained in the
package are the property of their respective owners.
  
