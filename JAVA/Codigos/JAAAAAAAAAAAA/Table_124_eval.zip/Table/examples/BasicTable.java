////////////////////////////////////////////////////////////////
// BasicTable.java
////////////////////////////////////////////////////////////////

package com.objectplanet.gui.examples;

import com.objectplanet.gui.*;
import java.awt.*;


/**
 * This demonstrates a basic table.
 * @author Bjorn J. Kvande.
 */
public class BasicTable {

	/**
	 * Starts the demo.
	 */
	public static void main(String[] argv) {
		Table table = new Table(2);
		table.setHeader(new String[] {"this is a", "table header"});
		table.setRow(0, new String[] {"this is 0", "a table 0"});
		table.setRow(1, new String[] {"this is 1", "a table 1"});
		table.setRow(2, new String[] {"this is 2", "a table 2"});
		
		Frame f = new Frame();
		f.add("Center", table);
		f.setSize(300,200);
		f.show();
	}
}
