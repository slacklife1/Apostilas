////////////////////////////////////////////////////////////////
// TableAndTextBox.java
////////////////////////////////////////////////////////////////

package com.objectplanet.gui.examples;

import com.objectplanet.gui.*;
import java.awt.*;
import java.applet.*;


/**
 * This demonstrates how to use the table events.
 * @author Bjorn J. Kvande.
 */
public class TableAndTextBox extends Applet implements TableListener {

	private Table table;
	private TextField text;
	
	
	/**
	 * Creates the table events demo.
	 */
	public TableAndTextBox() {
		// create the table
		int columns = 3;
		table = new Table(columns);
		table.setHeader(new String[] {"one", "two", "three"});
		table.setSelectionMode(Table.SELECT_SINGLE);
		
		// add the data
		for (int row = 0; row < 10; row++) {
			String[] data = new String[columns];
			for (int col = 0; col < data.length; col++) {
				data[col] = "row" + row + " col" + col;
			}
			table.setRow(row, data);
		}
		
		// the text field is used to set the text of the selected cell
		text = new TextField();

		// place the table and text field underneath each other
		setBackground(Color.lightGray);
		setLayout(new BorderLayout());
		add("Center", table);
		add("South", text);
		
		// register our event listener
		table.addTableListener(this);
	}
	
	
	/**
	 * Handles the table events.
	 */
	public void tableSelection(TableEvent event) {
		if (event.getSelectionType() == TableEvent.SELECTED) {
			text.setText((String) event.getSelectedCell());
		}
	}
	

	/**
	 * Starts the demo.
	 */
	public static void main(String[] argv) {
		TableAndTextBox t = new TableAndTextBox();
		Frame f = new Frame();
		f.add("Center", t);
		f.setSize(350,300);
		f.show();
	}
}
