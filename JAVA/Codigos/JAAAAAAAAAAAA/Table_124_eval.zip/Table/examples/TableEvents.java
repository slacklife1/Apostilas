////////////////////////////////////////////////////////////////
// TableEvents.java
////////////////////////////////////////////////////////////////

package com.objectplanet.gui.examples;

import com.objectplanet.gui.*;
import java.awt.*;


/**
 * This demonstrates how to use the table events.
 * @author Bjorn J. Kvande.
 */
public class TableEvents extends Panel implements TableListener {

	private Table leftTable;
	private Table rightTable;
	
	
	/**
	 * Creates the table events demo.
	 */
	public TableEvents() {
		// create the tables
		int col_count = 3;
		leftTable = new Table(col_count);
		leftTable.setHeader(new String[] {"one", "two", "three", "four"});
		rightTable = new Table(col_count);
		rightTable.setHeader(leftTable.getHeader());
		leftTable.setSelectionMode(Table.SELECT_SINGLE);
		rightTable.setSelectionMode(Table.SELECT_SINGLE);
		
		// add the data
		for (int row = 0; row < 10; row++) {
			String[] data = new String[col_count];
			for (int col = 0; col < data.length; col++) {
				data[col] = "row" + row + " col" + col;
			}
			leftTable.setRow(row, data);
		}
		
		// place the tables
		setBackground(Color.lightGray);
		setLayout(new GridLayout(1,2, 20, 20));
		add(leftTable);
		add(rightTable);
		
		// register our event listener
		leftTable.addTableListener(this);
		rightTable.addTableListener(this);
	}
	
	
	/**
	 * Handles the table events.
	 */
	public void tableSelection(TableEvent event) {
		if (event.getSelectionType() == TableEvent.DOUBLE_CLICK) {
			int index = event.getRowIndex();
			if (event.getSource() == leftTable) {
				String[] row = (String[]) leftTable.getRow(index);
				rightTable.setRow(-1, row);
				leftTable.removeRow(index);
			} else {
				String[] row = (String[]) rightTable.getRow(index);
				leftTable.setRow(-1, row);
				rightTable.removeRow(index);
			}
		}
	}
	

	/**
	 * Starts the demo.
	 */
	public static void main(String[] argv) {
		TableEvents t = new TableEvents();
		Frame f = new Frame();
		f.add("Center", t);
		f.setSize(650,300);
		f.show();
	}
}
