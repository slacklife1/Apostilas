package criptografia;

public class Chave {

    private String chave;

    public Chave(String c) {
        this.chave = c;
    }

    public Chave() {
    }

    public String getChave() {
        return chave;
    }

    public int getTamanho() {
        return this.chave.length();
    }

    public int[] getChaveInt() {
//        Character c = new Character(' ');
        int[] chaveInt = new int[this.chave.length()];
        for(int i = 0; i < this.chave.length(); i++) {
            chaveInt[i] = (int)this.chave.charAt(i);
        }
        return chaveInt;
    }

    public void setChave(String c) {
        this.chave = c;
    }

    public static void main(String[] args) {
    }

}

