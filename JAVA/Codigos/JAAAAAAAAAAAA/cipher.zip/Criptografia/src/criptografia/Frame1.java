package criptografia;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Frame1 extends JFrame {
  JTextArea jTextArea1 = new JTextArea();
  JButton jButton1 = new JButton();

  public Frame1() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  public static void main(String[] args) {
    Frame1 frame1 = new Frame1();
  }
  private void jbInit() throws Exception {
    jTextArea1.setText("jTextArea1");
    jTextArea1.setBounds(new Rectangle(92, 79, 265, 234));
    this.getContentPane().setLayout(null);
    jButton1.setBounds(new Rectangle(40, 28, 76, 29));
    jButton1.setText("jButton1");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    this.getContentPane().add(jTextArea1, null);
    this.getContentPane().add(jButton1, null);
    this.setBounds(50,50,100,100);
  }

  void jButton1_actionPerformed(ActionEvent e) {
    this.notifyAll();
  }
}