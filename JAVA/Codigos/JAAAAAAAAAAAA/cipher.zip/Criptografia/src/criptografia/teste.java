package criptografia;

public class teste extends Thread {
  private int numero;
  teste(String nome, int n) {
    super(nome);
    this.numero = n;

  }
  public void run() {
    Console c = new Console();
    while(true) {
        this.merda();
    }
  }
  public synchronized void merda() {
      Console c = new Console();
      for(int i=0; i<10; i++)
      c.print(" "+this.numero+" ");
      try {
        this.wait();
      } catch (InterruptedException ie) {
      }
  }

}
/*
  public static void main(String[] args) {
      Console c = new Console();
      Character car = new Character('\n');
      System.out.println((int)'u');
      System.out.println((char)((int)149));
  }
*/
