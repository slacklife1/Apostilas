Contact information

 eduardo carrazzone cavalcanti
 email: eccsport@hotmail.com
        eduardo_carrazzone@yahoo.com.br  



Title or the file/product

  Cipher 1.1




A description of the file or product

 Cipher and Text Extractor 1.1 This program encript and decript files using a Key. The program also extract text from files. It's very simple and usefull. 