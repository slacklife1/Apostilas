You may contact me at kc2keo@yahoo.com

My AIM SN = kc2keo

My MSN Messanger SN = kc2keo@yahoo.com

This program is bacicly a file conversion program

If anyone plans to modify it or make changes please credit me as the creater.  Thanks

Usage of program:

Open up commmand prompt(windows only)

java Asc2Uni input.txt output.txt