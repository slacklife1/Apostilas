import java.io.* ;

public class Asc2Uni
{
	public static void main( String [] args )
	{
		File infile = null ;
		File outfile = null ;
		FileInputStream source = null ;
		FileOutputStream dest = null ;
		String infilename = null ;
		String outfilename = null ;
		try
		{
			if (args.length<2)
			{
				System.err.println( "\nUsage: java Asc2Uni <source file> <destination file>\n" ) ;
				return ;
			}
			infilename = args[0] ;
			outfilename = args[1] ;
			infile = new File( infilename ) ;
			outfile = new File( outfilename ) ;
			if (!infile.exists())
			{
				System.err.println( "Invalid input file" ) ;
				return ;
			}
			else if (!infile.canRead())
			{
				System.err.println( "Can't read input file" ) ;
				return ;
			}
			else if (outfile.isDirectory())
			{
				outfile = new File( outfile.getParent() + "\\" + infile.getName() ) ;
				System.out.println( "Output file corrected to '" + outfile.getPath() + "'" ) ;
			}
			else if (!outfile.canWrite())
			{
				System.err.println( "Can't write output file" ) ;
				return ;
			}
			else if (!infile.canRead())
			{
				System.err.println( "Can't read input file" ) ;
				return ;
			}
			try
			{
				source = new FileInputStream( infile ) ;
				dest = new FileOutputStream( outfile ) ;
                                for(int p = source.read(); p != -1; source.read())
                                {
				byte[] b = new byte[p];
				//int i = 0 ;
				long l = 0 ;
				//while (true)
				//{
                                  //i = source.read( b ) ;		// read some bytes
                                  //if ( i == -1 ) { break ; } ;	// if there were no bytes then break
                                  l += p ;
                                  for (int j = 0; j != p; j++) {
                                    dest.write(0); // save the zero byte
                                    dest.write( (int) (b[j])); // and the ascii byte to make a unicode char
                                    //System.exit(0);
                                  }

                                }//end for()


			}
			finally
			{
				if (source!=null)
				{
					try
					{
						source.close() ;
					}
					catch (IOException e)
					{
						System.err.println( e.toString() ) ;
					}
				}
                                else if (dest!=null)
				{
					try
					{
						dest.close() ;
					}
					catch (IOException e)
					{
						System.err.println( e.toString() ) ;
					}
				}
			}
		}
		catch (IOException e)
		{
			System.err.println( e.toString() ) ;
		}
	}
}
