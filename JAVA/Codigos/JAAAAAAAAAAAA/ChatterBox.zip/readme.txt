ChatterBox v1.0

This a a basic chat application written in Java.
ChatterBox has a swing GUI so you would need an up-to-date java plug in to run it.
As far as I know ChatterBox will not run behind a firewall (I tried it on a system with zonealarm installed and the 
client application would not open a socket - not even to the internal loopback address 127.0.0.1but then again - this 
system won't run ftp either so feel free to experiment and if you come up with useful informationplease let me know).

The application has been written as a final project for school, so the source code is thoroughly documented.

Operation is pretty straight forward;
First of all the server must be run. You can set up the port and maximum allowed connections.
The local I/P address is displayed on the status bar in the lower right corner. The connect/disconnect button is used
to run/shut down the service.
Once the server is up and running clients can log on into it. Of course the client needs to know the host I/P and port number.
Client and server settings are stored in a file so next time you load the client/server the last used settings are used as default.
Nick-names can be password protected - but the password is optional. When a user logs in he will be required to enter a 
username (nick name) and password. These fields are case sensitive.
If this is the first time the server has detected and allowed access to a user, the user's name and password are stored in a file.
ChatterBox is a single "channel" chat, but private conversations can be held in private windows : double clicking a user name in 
the user name list will open a private chat window.

I have "ripped" the button icons from mIRC. Should there be any problem with this of course I am willing to to supplement them with 
other icons. Anyway ChatterBox client will not connect to an IRC server.

You will file 4 included files - two zips and two executable jars. The zip files contain source code. 

This is it. I can be contacted by email. Please feel free to contact me should you encounter any bugs
or problems with it. You have my permission to use, modify and re-distribute this application. However, you do not have my 
permission to take credit or use it commercially  -   Please keep it clean.

Jonathan Benshaul
write_yoni@yahoo.com