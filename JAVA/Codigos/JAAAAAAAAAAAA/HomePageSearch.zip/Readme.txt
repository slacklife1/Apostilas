HomePageSearch applet
==================

The Home Page Search Applet is a Java applet written to search the pages of a Web site.
As Demon Internet (my ISP) do not allow the use of CGI scripts this applet is one way to
implement search functionality on Home Pages.

The applet starts searching at a specified page (defaults to "index.html" or "index.htm") and then follows all 
local links (i.e all HTML pages on your site) performing the search. Any matches are displayed and then simply
double click on a match to jump to that page.

This ZIP file should contain the following files:

o  readme.txt - this file
o  search.html - example of how to use the applet
o  HomePageSearch.class - applet file 1
o  SearchPages.class - applet file 2

Features
-----------

o  Searches all HTML files on the web site;
o  Searches can be case-sensitive or case-insensitive;
o  Searches can be restricted to matching whole words;
o  Once a match has been found it can be "jumped" to;
o  Number of pages to be searched can be limited;
o  HTML tags are automatically stripped before searching the text;
o  Source code available;
o  Applet colours can be specified;
o  Some localisation support; 
o  Can be used to search a local PC hard drive;
o  Can be set up for use behind a proxy server/firewall.

How to Use the applet
----------------------------

This example is for a home page of "www.myisp.co.uk/~fred" with an index page of "home.htm".

A sample page "search.html" is contained in this ZIP file showing an example search page 
using the applet.

------------------------------- cut here ---------------------------------------------------
<HTML>

<HEAD>
<TITLE>Home Page Search </TITLE>
</HEAD>

<H1>Home Page Search </H1>
Please use this applet to search the site. Enter a search phrase and then press
the "Search" button. If any matches are found they will be displayed. Double click on a
match to jump to the page.
<P>

<APPLET CODE="HomePageSearch.class>" WIDTH=650 HEIGHT=400>
<PARAM NAME="server" VALUE="http://www.myisp.co.uk/~fred/">
<PARAM NAME="indexName" VALUE="home.htm">
<EM>Sorry but the search applet requires a java aware browser.</EM>
</APPLET>

</HTML>
------------------------------- cut here -----------------------------------------------

Note: 1. The URL of the web site (in this example "http://www.myisp.co.uk/~fred/") is
              passed as a parameter to the applet. Note that the URL is terminated with 
              a "/" character (important!).

          2. The name of the first page to be loaded ("home.htm" in this example) is passed 
              as a parameter to the applet. If this parameter is omitted the first page is 
              assumed to be "index.html" or "index.htm".

Next upload the files to your site. The filenames are case sensitive and should all be transferred in 
binary mode. 

All three files should be in the same directory on your site.
	o search.html
	o HomePageSearch.class
	o SearchPages.class

Comments, bugs, suggestions to richard@babbage.demon.co.uk