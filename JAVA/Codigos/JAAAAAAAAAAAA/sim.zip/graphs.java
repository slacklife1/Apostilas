/*
Graphs 1.04
Includes BFT,DFT,Kruskal MST,Dijkistra SL
Deepak
<deepak-p@eth.net>
http://www.geocities.com/acmesofties/
28-June-2002
*/

import java.io.*;

class stack
{
    public int arr[],ac;
    stack()
    {
	arr=new int[100];
	ac=0;
    }
    stack(int num)
    {
	arr=new int[num];
	ac=0;
    }
    void push(int key)
    {
	if(ac==arr.length)return;
	arr[ac++]=key;
	return;
    }
    int pop()
    {
	if(ac==0)return -1;
	return arr[--ac];
    }
    int instack(int key)
    {
	for(int i=0;i<ac;i++)
	{
	    if(arr[i]==key)return 1;
	}
	return 0;
    }
    boolean isempty()
    {
	return ac==0;
    }
}

class queue
{
    public int arr[],front,rear,count;
    queue()
    {
	arr=new int[100];
	front=0;
	rear=0;
	count=0;
    }
    queue(int num)
    {
	arr=new int[num];
	front=0;
	rear=0;
	count=0;
    }
    void insert(int key)
    {
	if(rear==arr.length)return;
	arr[rear++]=key;
	count++;
    }
    int get()
    {
	if(front==rear)return -1;
	count--;
	return arr[front++];
    }
    int inqueue(int key)
    {
	for(int i=front;i<rear;i++)
	{
	    if(arr[i]==key)
		return 1;
	}
	return 0;
    }
    boolean isempty()
    {
	return count==0;
    }
}

class edge
{
    int v1,v2,wt;
    edge(int u,int v,int w)
    {
	v1=u;
	v2=v;
	wt=w;
    }
    edge()
    {
	v1=0;
	v2=0;
	wt=0;
    }
}

class vertex
{
    int adj[],ac;
    int wt[];    
    boolean visit;
    vertex()
    {
	adj=new int[100];
	ac=0;
	wt=new int[100];
	visit=false;
    }
    void addedge(int v,int w)
    {
	adj[ac++]=v;
	wt[ac-1]=w;
	return;
    }
    void display(int num)
    {
	System.out.println(num);
    }
    void flag()
    {
	visit=true;
    }
    void clear()
    {
	visit=false;
    }
    int isadj(int v)
    {
	for(int i=0;i<ac;i++)
	{
	    if(adj[i]==v)return wt[i];
	}
	return 0;
    }
}

class graph
{
    vertex vert[];
    edge edges[];
    int vc,ec;
    int set[][],sc[],num; /*For Kruskal*/
    graph(int vt)
    {
	vert=new vertex[vt];
	vc=vt;
	for(int i=0;i<vc;i++)
	    vert[i]=new vertex();
	edges=new edge[100];
	ec=0;
	/*For Kruskal*/
	set=new int[vc][vc];
	sc=new int[100];
	num=0;
	/*End of Kruskal initialization*/
    }
    int Kfind(int a)/*For Kruskal*/
    {
	for(int i=0;i<num;i++)
	{
	    for(int j=0;j<sc[i];j++)
	    {
		if(set[i][j]==a)return i;
	    }
	}
	return -1;
    }
    void Kmerge(int a,int b)/*For Kruskal*/
    {
	for(int i=0;i<sc[b];i++)
	{
	    set[a][sc[a]+i]=set[b][i];
	}
	sc[a]+=sc[b];
	for(int i=b+1;i<num;i++)
	{
	    for(int j=0;j<sc[i];j++)
	    {
		set[i-1][j]=set[i][j];
	    }
	    sc[i-1]=sc[i];
	}
	num--;
	return;
    }
    int getedgelength(int u,int v)
    {
	if(u==v)return 0;
	for(int i=0;i<ec;i++)
	{
	    if(edges[i].v1==u && edges[i].v2==v)
		return edges[i].wt;
	    else if(edges[i].v2==u && edges[i].v1==v)
		return edges[i].wt;
	}
	return 9999;
    }
    void sortedges()
    {
	for(int i=0;i<ec;i++)
	{
	    for(int j=i+1;j<ec;j++)
	    {
		if(edges[i].wt>edges[j].wt)
		{
		    edge temp;
		    temp=edges[i];
		    edges[i]=edges[j];
		    edges[j]=temp;
		}
	    }
	}
	return;
    }
    graph Kruskal()/*Kruskal main function*/
    {
	for(int i=0;i<vc;i++)
	{
	    set[i][0]=i;
	    sc[i]=1;
	}
	num=vc;
	sortedges();
	graph g=new graph(vc);
	for(int i=0;i<ec;i++)
	{
	    int a=Kfind(edges[i].v1);
	    int b=Kfind(edges[i].v2);
	    if(a!=b)
	    {
		g.addedge(edges[i].v1,edges[i].v2,edges[i].wt);
		Kmerge(a,b);
		if(g.getedgecount()>=(vc-1))break;
	    }	    
	}
	return g;
    }		
    boolean present(int[] a,int ac,int b)/*if b is present in a[0] thru a[ac-1]*/
    {
	for(int i=0;i<ac;i++)
	{
	    if(a[i]==b)return true;
	}
	return false;
    }
    int Dijkistra(int u,int v)/*Returs shortest length between u and v*/
    {
	int label[]=new int[vc];	
	int found[]=new int[vc];
	int ver[]=new int[vc];
	int fc=1;
	found[0]=u;
	for(int i=0;i<vc;i++)
	{
	    label[i]=getedgelength(u,i);
	    ver[i]=i;
	}
	while(fc<vc)
	{
	    for(int i=0;i<vc;i++)
	    {
		for(int j=i+1;j<vc;j++)
		{
		    if(label[i]>label[j])
		    {
			int temp=label[i];
			label[i]=label[j];
			label[j]=temp;
			temp=ver[i];
			ver[i]=ver[j];
			ver[j]=temp;
		    }
		}
	    }
	    int i;
	    for(i=0;present(found,fc,ver[i]);i++);
	    found[fc++]=ver[i];
	    int vs=i;
	    for(i=0;i<vc;i++)
	    {
		if(label[i]>(label[vs]+getedgelength(found[fc-1],ver[i])))
		    label[i]=label[vs]+getedgelength(found[fc-1],ver[i]);
	    }
	}
	for(int i=0;i<vc;i++)
	{
	    if(ver[i]==v)return label[i];
	}
	return 9999;
    }
    void dft(int v)/*DFT main*/
    {
	clearvisit();
	stack st=new stack(100);
	int c=v;
	int count;
	while(true)
	{
	    vert[c].flag();
	    vert[c].display(c);
	    count=0;
	    for(int i=0;i<vert[c].ac;i++)
	    {
		if(vert[vert[c].adj[i]].visit==false)
		    count++;
	    }
	    if(count==0 && st.isempty())
		break;
	    else if(count==0)
	    {
		c=st.pop();
	    }
	    else
	    {
		int y=-1;
		for(int i=0;i<vert[c].ac;i++)
		{
		    if(vert[vert[c].adj[i]].visit==false && y==-1)
			y=vert[c].adj[i];
		    else if(vert[vert[c].adj[i]].visit==false)
		    {
			st.push(vert[c].adj[i]);
			vert[vert[c].adj[i]].flag();
		    }
		}
		c=y;
	    }
	}
    }
    void bft(int v)/*BFT main*/
    {
	clearvisit();
	queue q=new queue(100);
	int c=v;
	int count;
	while(true)
	{
	    vert[c].flag();
	    vert[c].display(c);
	    for(int i=0;i<vert[c].ac;i++)
	    {
		if(vert[vert[c].adj[i]].visit==false)
		{
		    q.insert(vert[c].adj[i]);
		    vert[vert[c].adj[i]].flag();
		}
	    }
	    if(q.isempty())
		break;
	    c=q.get();
	}
    }
    void addedge(int u,int v,int wt)
    {
	edges[ec++]=new edge(u,v,wt);
	vert[u].addedge(v,wt);
	vert[v].addedge(u,wt);
    }
    int getedgecount()
    {
	return ec;
    }
    void clearvisit()
    {
	for(int i=0;i<vc;i++)
	    vert[i].clear();
    }
    void displayedges()
    {
	for(int i=0;i<ec;i++)
	{
	    System.out.println("Edge "+i+" between "+edges[i].v1+" & "+edges[i].v2+" of wt:"+edges[i].wt);	
	}
    }
    int isadj(int u,int v)
    {
	return vert[u].isadj(v);
    }	    
}

class graphs
{
    public static void main(String args[])throws IOException
    {
	int ch;
	DataInputStream in=new DataInputStream(System.in);
      System.out.println("Graphs 1.04\nDeepak\n<deepak-p@eth.net");
      System.out.println("Release Date: 28-June-2002");
      System.out.println("http://www.geocities.com/acmesofties/");
	System.out.println("Enter number of vertices:");
	ch=Integer.parseInt(in.readLine());
	graph gr=new graph(ch);
	ch=1;
	while(ch!=20)
	{
	    System.out.println("\n1.Add Edge\n2.Display\n3.DFT\n4.BFT\n5.Kruskal MST\n6.Dijkistra SL\n10.Exit");
	    ch=Integer.parseInt(in.readLine());
	    switch(ch)
	    {
		case 1:
		{
                System.out.println("Vertices are numbered 1 thru'"+gr.vc-1);
		    System.out.println("Enter 1st vertex:");
		    int i=Integer.parseInt(in.readLine());
		    System.out.println("Enter 2nd vertex:");
		    int j=Integer.parseInt(in.readLine());
		    System.out.println("Enter weight:");
		    int w=Integer.parseInt(in.readLine());
		    gr.addedge(i,j,w);
		    System.out.println("Added Edge");
		    break;
		}
		case 2:
		{
		    System.out.println("Vertices:"+gr.vc);
		    gr.displayedges();
		    break;
		}
		case 3:
		{
		    System.out.println("Enter vertex for search to begin:");
		    int j=Integer.parseInt(in.readLine());
		    gr.dft(j);
		    break;
		}
		case 4:
		{
		    System.out.println("Enter vertex to begin search:");
		    int j=Integer.parseInt(in.readLine());
		    gr.bft(j);
		    break;
		}
		case 5:
		{
		    System.out.println("Processing MST...");
		    graph g=gr.Kruskal();
		    System.out.println("Vertices:"+g.vc);
		    g.displayedges();
		    break;
		}
		case 6:
		{
		    System.out.println("Enter starting vertex:");
		    int i=Integer.parseInt(in.readLine());
		    System.out.println("Enter ending vertex:");
		    int j=Integer.parseInt(in.readLine());
		    int path=gr.Dijkistra(i,j);
		    System.out.println("Shortest path length:"+path);
		    break;
		}
		default:
		    ch=20;
	    }
	}
    }
}	    
		    