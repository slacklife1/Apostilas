(Last updated 1st Jan 2002)
Contents:
1.Introduction.
2.Requirements
3.How to use
4.FAQ
5.Author


INTRODUCTION: I tried searching the net for a handy customizable
calendar but did not find anything suitable, so I decided to make my own
calendar with little personal touches!

REQUIRMENTS: any java enabled web browser like Netscape(4.2) or Internet
Explorer 4.0 or above will work. There are no requirements for operating system
however the final display of calendar will also depend upon your monitor
resolution and display card settings but printing should work fine.

HOW TO USE:First unzip the archive into a folder say c:/calendar, now go to this
folder from file browser like windows explorer and doule click on the file
"main.html". Or alternatively you can point the browser to location of
"main.html" file. Thats just about all- the applet will load and a form will
come up prompting user for some basic data which are explained below:

        a)Year : year for which you wan the calendar (default is current year)

        b)Title: Text that you want to appear on top. Remember that whatever you
        type in this will be appended with "Year 200x" and if your text is too
        long then it will be automatically truncated. If you type nothing then
        only "Year 200x" will appear on top.

        c)Color of font: this is not yet functional so you will have to settle
        for the default i,e, blue color.

        d)Fading: this is the % representation of the fading out for the
        background picture, you may need to experiment with this value
        depending upon the background picture selected. Default is 60%
        but if your picture is too light then you might decrease this to
        a lower value or alternatively if your picture is too dark then you may
        need to fade out more i.e. increase the value to a higher figure.

        e)Picture file: the file that you wan to appear in the background should
        be first copied to the "images" folder of the calendar directory. Just
        type the name of the file in this box like "your_file.jpg" or whatever.
        File extension supported are jpg, jpeg, gif - there may be more but I
        have tried, let me know if there are more.

        f)Buttons: are labelled appropriately and I assume that it needs no more
        expanantion.

FAQ: Here are some FAQ's to help sort out common issues:
        1)The applet is not loading?
        Maybe java is not enabled in your browser see the settings of your
        browser. Visit http://java.sun.com or your browser website for more for
        more details.

        2)My monitor is very small so the applet keeps going out of the monitor
        screen?
        The applet needs a screen area of 700x900 but while printing it will
        print on a single A4 sheet (portrait orientation). Presently, there is
        no functionality to reduce the screen area.

        3)The calendar dates do not appear properly and appears to get lost in
        the background picture?
        You need to fade out the picture more i.e increase the value for fading
        out. Because of this constraints certain pictures may not be a good
        choice for the calendar particulalry the one with lot of blue color
        which is the font color of calendar.

        4)My background picture is appearing very hazy and is hardly visible?
        See question no. 3 except decrease the fading out parameter to darken
        your background picture.

        5)How do I change the input parameters - the form disappeared after I
        pressed "make calendar"?
        Press "SHIFT+Reload", the Reload button is on your browser window
        (usually on top).

        6)I want to use the my picture as default background and not the one
        supplied with the archive to save time in inputting picture file name?
        Copy your picture to the "images" folder and rename the file to
        "pic.jpg". The applet looks at "images" folder for file named "pic.jpg"
        as default for background (in case none is specified in the form).

        7)Can I sell this software for money?
        You are free to do anything with the software or its source code as long
        as you abide by the GNU License agreement provided with this software.

        8)Can I get the source of this applet for modifications?
        The source code is supplied alongwith the software, if you manage to add
        more features then please send me a copy.

AUTHOR: to email author please visit http://www.pratyush.net or send mail to
pankaj@pratyush.net . For anything else not covered in this document you are
free to write to me, I cannot ensure a prompt response but I will try to get
back to you.