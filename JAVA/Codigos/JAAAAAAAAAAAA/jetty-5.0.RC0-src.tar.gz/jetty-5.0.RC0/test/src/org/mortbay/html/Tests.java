// ========================================================================
// Copyright (c) 1997 Mort Bay Consulting (Australia) Pty. Ltd.
// $Id: Tests.java,v 1.4 2003/02/09 16:40:28 bretts Exp $
// ========================================================================

package org.mortbay.html;

import junit.framework.TestSuite;


/* ------------------------------------------------------------ */
/** Util meta JUnitTestHarness.
 * @version $Id: Tests.java,v 1.4 2003/02/09 16:40:28 bretts Exp $
 * @author Juancarlo A�ez <juancarlo@modelistica.com>
 */
public class Tests extends junit.framework.TestCase
{
    public Tests(String name)
    {
      super(name);
    }

    public static junit.framework.Test suite() {
      return new TestSuite(Tests.class);
    }

    /* ------------------------------------------------------------ */
    /** main.
     */
    public static void main(String[] args)
    {
      junit.textui.TestRunner.run(suite());
    }

    public void testPlaceHolder()
    {
      assertTrue(true);
    }
}
