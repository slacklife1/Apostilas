// ========================================================================
// Copyright (c) 1997 Mort Bay Consulting (Australia) Pty. Ltd.
// $Id: Tests.java,v 1.2 2003/02/09 16:40:30 bretts Exp $
// ========================================================================

package org.mortbay.jetty;


import junit.framework.TestSuite;


public class Tests extends junit.framework.TestCase
{
    public Tests(String name) 
    {
      super(name);
    }
    
    public static junit.framework.Test suite()
    {
        TestSuite suite = new TestSuite();
        suite.addTest(TestServer.suite());
        return suite;                  
    }
    
    public static void main(String[] args)
    {
      junit.textui.TestRunner.run(suite());
    }    
    
}
