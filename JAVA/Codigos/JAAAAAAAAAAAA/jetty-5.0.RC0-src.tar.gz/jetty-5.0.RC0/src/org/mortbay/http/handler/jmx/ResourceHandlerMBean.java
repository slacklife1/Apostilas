// ========================================================================
// Copyright (c) 2002 Mort Bay Consulting (Australia) Pty. Ltd.
// $Id: ResourceHandlerMBean.java,v 1.2 2003/09/18 13:29:23 gregwilkins Exp $
// ========================================================================

package org.mortbay.http.handler.jmx;

import javax.management.MBeanException;

import org.mortbay.http.jmx.HttpHandlerMBean;

/* ------------------------------------------------------------ */
/** 
 *
 * @version $Revision: 1.2 $
 * @author Greg Wilkins (gregw)
 */
public class ResourceHandlerMBean extends HttpHandlerMBean  
{
    /* ------------------------------------------------------------ */
    /** Constructor. 
     * @exception MBeanException 
     */
    public ResourceHandlerMBean()
        throws MBeanException
    {}
    
    /* ------------------------------------------------------------ */
    protected void defineManagedResource()
    {
        super.defineManagedResource();
        defineAttribute("allowedMethods"); 
        defineAttribute("dirAllowed"); 
        defineAttribute("acceptRanges"); 
        defineAttribute("redirectWelcome"); 
        defineAttribute("minGzipLength"); 
    }    
}
