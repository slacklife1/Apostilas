// ========================================================================
// Copyright (c) 1999 Mort Bay Consulting (Australia) Pty. Ltd.
// $Id: Primitive.java,v 1.4 2003/02/09 16:46:47 bretts Exp $
// ========================================================================

package org.mortbay.util;



/* ------------------------------------------------------------ */
/** Utility handling of primitive types 
 *
 * @version $Revision: 1.4 $
 * @author Greg Wilkins (gregw)
 * @deprecated Use TypeUtil
 */
public class Primitive extends TypeUtil
{
}

        
