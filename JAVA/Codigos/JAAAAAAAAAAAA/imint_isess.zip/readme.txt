1. Installation

Ensure that when you unzip this file, the sub-directories
are correctly set up. Otherwise the software will not work
correctly.

2. Starting

Start the file START.htm in a web browser. It contains a
hyperlinked index of all the demonstrations.

3. Licence

See the file "licence.txt".

4. Differences between trial and release versions

Trial versions display indications that the software
is an unregistered trial version at certain intervals 
during operation. The release version contains no
copyright information that is visible during normal
operation.



We hope you enjoy trying this software.

The programming team at IMINT.COM
info@imint.com
6th November 2001