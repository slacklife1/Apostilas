/*
     Coding by : R A M
     Coding Level : Beginners
     Email        : Rizwan1217@hotmail.com
 */
import java.io.*;
import java.util.*;
 
   
    public class FileInputs
	   {
	   	  
		  
		  Vector urlList = new Vector();
		  
		  public Vector textToList(File fileN)
		     {
			 
			 try{
			 
			  SafeBufferedReader fileInput = new SafeBufferedReader(new InputStreamReader(new FileInputStream(fileN)));
			  
			  String txt = new String();
			  
			  while ((txt = fileInput.readLine()) != null)
			   	 urlList.add(txt);
			 } 
			 catch(IOException e)
			    {
			    
				 //Malik
				}
			 return urlList;
			 }
        }