
//     Coding by : R A M
  //   Coding Level : Beginners
   //  Email        : Rizwan1217@hotmail.com
import java.net.*;
import java.io.*;
   
     
	  public class LookupHost
	     {
		 
		  String host;
		  String returnHostName;
		  LookupHost(String host)
		   {
		   
		      this.host = host;
			  
		   }
		 
		  String returnHost()
		    {
			
			 try{
				URL url = new URL(host);
				URLConnection connection = url.openConnection();
			//	connection.setDoOutput(true);
			
				
				BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				String inputLine= "";

				if  ((inputLine = in.readLine()) != null)
				    return "Valid" ;
        			else return "Invalid"	;
                             }    
			          catch(MalformedURLException e)
				   {
				   
				    return "Invalid Url";
				   }
		 		catch(UnknownHostException e)
				   {
				   
				    return "Invalid Url";
				   }
				catch(IOException e)
				   {
				   
				    return "Invalid Url";
				   }
		 		
		 			
		    }
		 }


