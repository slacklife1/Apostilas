/*
     Coding by : R A M
     Coding Level : Beginners
     Email        : Rizwan1217@hotmail.com
 */
import java.io.*;
  
  
     public class SafeBufferedReader extends BufferedReader
	   {
	   	  public SafeBufferedReader(Reader in)
		  {
		  
		   this (in,1024);
		  
		  }

          public SafeBufferedReader(Reader in,int bSize)
		  {
		  
		   super(in,bSize);
		  
		  }


          private boolean lookingForFeed = false;
		  
		  public String readLine() throws IOException
		  {
		  
		   StringBuffer sb = new StringBuffer("");
		   while (true)
		     {
		   
		       int c = this.read();
			   if (c == -1)
			    {
			   
			      return null;
			     }

				else if (c == '\n')
				{
				  if (lookingForFeed)
				  {
				    lookingForFeed = false;
					continue;
				  }
	               else 
				    {
				    return sb.toString();
					}
				}		   
   			   
			   else if (c == '\r')
			   {
			    lookingForFeed = true;
				return sb.toString();
			   
			   }		
		      else 
			  {
			   lookingForFeed = false;
			   sb.append((char) c);
			  
			  }
			 }

		  
		  
		  }


   }