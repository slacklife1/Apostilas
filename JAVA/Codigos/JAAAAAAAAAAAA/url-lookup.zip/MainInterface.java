/*
     Coding by : R A M
     Coding Level : Beginners
     Email        : Rizwan1217@hotmail.com
 */
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.*;
 public class MainInterface extends JFrame implements ActionListener //main interface class
  {
  
    JComboBox urlList;
	JButton browseButton = new JButton("Browse");
	JTextField browseField = new JTextField();
	JTextField selectedField = new JTextField();
	JTextField ipField = new JTextField();
	JTextField statusField = new JTextField();
	
	MainInterface()
	//constructor
	{
    	 super ("IP Lookup Host");
 	     Toolkit tool = getToolkit();
	     //getting the toolkit
	 
	     Dimension size = tool.getScreenSize();
	     // getting total size of screen
	     setBounds(size.width/4,size.height/4,size.width/2,size.height/2);
	 
	     //making the window to display in center of screen
	     Dimension winSize = new Dimension (400,200);
	     setSize(winSize);
	     setDefaultCloseOperation(EXIT_ON_CLOSE);
	     // adding font to view and setting shortcut with event to perform
	     urlList = new JComboBox();
		 urlList.setPreferredSize(new Dimension(190,20));
		 urlList.addItem("List of Url");
		 JPanel listBox = new JPanel();
		 listBox.setLayout(new FlowLayout(FlowLayout.LEFT,20,20));
		 Box browseBox = Box.createHorizontalBox();
		 browseButton.addActionListener(this);
		 browseField.setPreferredSize(new Dimension(200,20)); 
		 JLabel browseLabel = new JLabel("Browse Files :   ");
		 browseBox.add(browseLabel);
		 browseBox.add(browseField);
		 browseBox.add(browseButton);
		 listBox.add(browseBox);
         urlList.addActionListener(this);
		 selectedField.setPreferredSize(new Dimension(200,20));
		 Box selectLabelBox = Box.createHorizontalBox();
		 JLabel select = new JLabel(  "Select a  File  :   ");
		 selectLabelBox.add(select);
		 selectLabelBox.add(urlList);
		 JLabel selected = new JLabel("IP  of  URL       :   ");
		 
		 Box labelBox = Box.createHorizontalBox();
		 
		 labelBox.add(selected);
		 labelBox.add(selectedField);
		 Box selectBox = Box.createVerticalBox();
		 selectBox.add(selectLabelBox);
		 selectBox.createVerticalStrut(100);
		 selectBox.add(labelBox);
		 JPanel selectPanel = new JPanel();
		 selectPanel.setLayout(new FlowLayout(FlowLayout.LEFT,20,20));
		 selectPanel.add(selectBox);
		 getContentPane().add(listBox,BorderLayout.NORTH);
		 //getContentPane().add(urlList,BorderLayout.SOUTH);
		 getContentPane().add(selectPanel,BorderLayout.CENTER);
		 
		 setResizable(false);
	     setVisible(true); 
	     repaint();
    }
   
     // the real work
    public void actionPerformed(ActionEvent event) // this function handles all the events on menubar
	  {
	     JFileChooser fileChooser = new JFileChooser();
		 
		 if (event.getSource() == browseButton)
		 {
		 fileChooser.showOpenDialog(this);
		 FileInputs fileInputs = new FileInputs();
		 Vector vec = fileInputs.textToList(fileChooser.getSelectedFile());
		 int size = vec.size();
		 urlList.removeAllItems();
		  for (int i =0 ; i < size ; i++)
		 urlList.addItem(vec.elementAt(i));
	     browseField.setText(fileChooser.getSelectedFile().toString());
		 repaint();
		 }
		 else
		 {
		 Object ob = urlList.getSelectedItem();
		 LookupHost host = new LookupHost(ob.toString());
		 
		 selectedField.setText(host.returnHost());
		 
		 }

	  }
  
  public static void main (String arg[])
    {
	
	 MainInterface object = new MainInterface();
	
	}
  }