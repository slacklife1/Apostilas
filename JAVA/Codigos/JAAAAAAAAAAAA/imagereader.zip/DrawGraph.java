//import java packages
import java.awt.*;
import javax.swing.*;
import java.net.*;

public class DrawGraph
  {
  public static void main(String[] arg) throws Exception
    {
      JFrame frame = new JFrame("ShowImage");
      URL url = new URL("http://www.animationusa.com/picts/srpict/mickeyred.jpg");
      frame.getContentPane().add(new JLabel(new ImageIcon(url))); // or just use a JLabel
      frame.pack();
      frame.show();
    }
  class ImagePanel extends JComponent
    {
     Image img;
     ImagePanel(ImageIcon ii)
      {
       img = ii.getImage();
      }

    public void paintComponent(Graphics g)
     {
       g.drawImage(img, 0, 0, null);
     }
   }//end class ImagePane1
 }//end class DrawGraph
