This program is just random methods for starting my solitare applet game project.  The code here is supposed to read the image from either the HDD or a URL.  The source code is provided and anyone could do anything with it as long as they credit me please : )

Program is made entirly in java.

any questions email me at kc2keo@yahoo.com

OR

if anyone has aim my screename is kc2keo

If anyone has msn messanger my contacting information is kc2keo@yahoo.com

NOTE:  This is the first code I ever posted.