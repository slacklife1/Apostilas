
-----------------------------------------------------------------------
TabTreeApplet 1.0, manual
-----------------------------------------------------------------------


Copyright (c) 2002 XLReader Project, contact@xlreader.com
All Rights Reserved.

This release contains the following directories:

. manual/
. demo/

Description of contents:
  (i)  manual - contains the reference manual, including link to demo.
  (ii) demo   - contains sample codes, and the (jarred & signed) java applet.


Start off:
----------
Open the start.html file in a browser. This contains
links to most of the above and setup instructions.


Technical Support:
------------
techsupp@xlreader.com


Order:
------------
sales@xlreader.com


-----------------------------------------------------------------------
www.xlreader.com
-----------------------------------------------------------------------

-----------------------------------------------------------------------
created: may 15, 2002
modified: 
-----------------------------------------------------------------------
