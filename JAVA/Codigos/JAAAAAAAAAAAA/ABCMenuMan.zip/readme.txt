
FIRST READ AND ACCEPT THE LICENSE BEFORE USING THIS SOFTWARE.

--------------------------------------
Overview of extra FULL version features
--------------------------------------

Visit http://www.wyka-warzecha.com for more great software!

The full version of this software also:
- Supports Frames
- Removes the 1 second pause
- Removes our website in the status bar/also while loading.
- Great control of colors, (background, highlight)
- Sound FX support
- You can specify font type
- Create your own animations with different sizes!
- Plus a small construction kit is included! 
- EXTENSIVE easy to use documentation!

--------------------------------------
Example of DEMO version:
--------------------------------------

Simply cut and paste (or type in) the following code into your HTML page.

<applet code=ABCMenuMan.class width=150 height=192>
<param name=copyright   value="http://www.wyka-warzecha.com">
Visit <a href=http://www.wyka-warzecha.com>www.wyka-warzecha.com</a> for information about this software.
<param name=timingValue value=50>
<param name=noItems     value=8>
<param name=aniMenu     value="menu.gif">
<param name=title1      value="______Visit our website">
<param name=title2      value="____Wyka-Warzecha at">
<param name=title3      value="_www.wyka-warzecha.com">
<param name=title4      value="*">
<param name=title5      value="______Easily add as many">
<param name=title6      value="___menu items as you want">
<param name=title7      value="___and it loads just as fast">
<param name=title8      value="_______as one menu item!">
<param name=link1       value="http://www.wyka-warzecha.com">
<param name=link2       value="http://www.wyka-warzecha.com">
<param name=link3       value="http://www.wyka-warzecha.com">
<param name=link4       value="http://www.wyka-warzecha.com">
<param name=link5       value="http://www.wyka-warzecha.com">
<param name=link6       value="http://www.wyka-warzecha.com">
<param name=link7       value="http://www.wyka-warzecha.com">
<param name=link8       value="http://www.wyka-warzecha.com">
</applet>

To add extra 'titles', simply add in an extra title in the
numbering. Be sure to change the 'height' variable (such
that it is 24*the number of items you want displayed).
Be sure to also change the 'noitems' parameter, to how many
titles you want displayed.

To add extra links, simply add extra links following the
numbering style.

To change the time that something is paused for, simply
change the 'timingvalue' parameter.

An asterisk (*) allows you to insert a blank line, and
an underscore (_) allows you to easily space out your menu
item!


The full version supports extra special fx!
