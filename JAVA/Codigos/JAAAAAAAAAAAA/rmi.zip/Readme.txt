
Compile the java file first and then 
	compile the TomcatRemoteServer file using rmic
Systax:
rmic TomcatRemoteServer


The class file that are need at client side:
--------------------------------------------------
TomcatRemoteServer_Stub.class
TomcatRemoteClient.class
TomcatRemote.class

The class file that are need at Server side:
--------------------------------------------------
TomcatRemoteServer_Skel.class
TomcatRemoteServer.class
TomcatRemote.class


Contact Me at :

ganesh_82in@rediffmail.com
