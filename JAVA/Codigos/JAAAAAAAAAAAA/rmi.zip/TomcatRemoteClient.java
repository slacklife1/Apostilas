import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.Naming;

public class TomcatRemoteClient
{
	public static void main(String args[])
	{
		TomcatRemote trObj = null;

		if(args.length !=3)
		{
			System.err.println("Syntax: <host or Flip Remote Object> <port> <s-start | h-shutdowm | r-restart>");
			System.exit(-1);
		}

		try
		{
			String tm = "rmi://"+args[0]+":"+args[1]+"/TomcatRemoteServer";

			Remote ro = null;

			try
			{
				ro = Naming.lookup(tm);
			}
			catch(Exception e)
			{
				System.err.println("Error: Look up Error"+e);
				System.exit(-1);
			}
			if(ro instanceof TomcatRemote)
			{
				trObj = (TomcatRemote) ro;
			}
			else
			{
				System.err.println("Error: Bad Object Returned");
				System.exit(-1);
			}
		}
		catch(Exception e)
		{
			System.err.println("Error: "+e);
			System.exit(-1);
		}

		try
		{
			if (args[2].equals("s"))
			{
				trObj.start();
			}
			else if (args[2].equals("h"))
			{
				trObj.shutdown();
			}
			else if (args[2].equals("r"))
			{
				trObj.restart();
			}	
		}
		catch(RemoteException re)
		{
			System.err.println("Error: Remote Exception");
			System.exit(-1);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}