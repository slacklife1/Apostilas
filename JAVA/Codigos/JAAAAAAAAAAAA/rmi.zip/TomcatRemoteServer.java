import java.rmi.*;
import java.rmi.registry.*;
import java.rmi.server.*;
import java.io.*;
import java.util.*;

public class TomcatRemoteServer extends UnicastRemoteObject implements TomcatRemote
{
	private String CATALINA_HOME="";
	public TomcatRemoteServer (Registry reg) throws Exception, RemoteException
	{
		super();
		reg.bind("TomcatRemoteServer",this);
			String[] cmd ={"cmd","/c","echo %CATALINA_HOME%"};
			Process p=Runtime.getRuntime().exec(cmd);
			BufferedReader b =new BufferedReader(new InputStreamReader(p.getInputStream()));
			String line=null;
			while( (line=b.readLine())!=null)
			{
				System.out.println(line);
				CATALINA_HOME=line;
			}
	}
	public static void main(String args[]) throws Exception
	{
		if(args.length !=2)
		{
			System.err.println("Syntax: <true|false> <port>");
			System.exit(-1);
		}

		int 		port	= 1099;
		Registry 	reg 	= null;

		try
		{
			port = Integer.parseInt(args[1]);
		}
		catch (NumberFormatException ne)
		{
			System.err.println("Syntax: <true|false> <port>");
			System.exit(-1);
		}
		try
		{
			if(args[0].equals("true"))
			{
				reg = LocateRegistry.createRegistry(port);
			}
			else
			{
				reg = LocateRegistry.getRegistry(port);
			}
			TomcatRemoteServer trsObj = new TomcatRemoteServer(reg);
		}
		catch(RemoteException re)
		{
			System.err.println("Error: Remote Exception");
			System.exit(-1);
		}
	}

	public void start () throws RemoteException
	{
		try
		{
			String[] cmd ={"cmd","/c","\""+CATALINA_HOME+"/bin/startup.bat\""};
			Process p=Runtime.getRuntime().exec(cmd);
			Date currDate=new Date();
			System.out.println("Started at " + currDate.toLocaleString());
			currDate=null;
			p=null;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void shutdown () throws RemoteException
	{
		try
		{		
			String[] cmd ={"cmd","/c","\""+CATALINA_HOME+"/bin/shutdown.bat\""};
			Process p=Runtime.getRuntime().exec(cmd);
			p.waitFor();
			Date currDate=new Date();
			System.out.println("Shutdowned at " + currDate.toLocaleString());
			currDate=null;
			p=null;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void restart () throws RemoteException
	{
		try
		{		
			shutdown();
			start();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}	
}


