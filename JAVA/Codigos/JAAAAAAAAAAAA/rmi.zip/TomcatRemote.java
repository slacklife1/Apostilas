import java.rmi.Remote;
import java.rmi.RemoteException;

public interface TomcatRemote extends Remote
{
	public void start () throws RemoteException;
	public void shutdown () throws RemoteException;
	public void restart () throws RemoteException;
}
