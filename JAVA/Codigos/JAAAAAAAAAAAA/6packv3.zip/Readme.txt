
Thankyou for downloading 6 pack V 3.0

///////////////////////////////////////////////////////////////////
  Unzip each to find an applet, simple setup instructions and
demonstration setups. For each, load the Readme.html file into your
browsers first. Please note that these applets are evaluation
copies and will always display unregistered version, you must read
and agree with the License.txt before using them. For information
on purchasing a full version of any product please go to Silk Webware
http://silk.webware.co.nz/ .
////////////////////////////////////////////////////////////////////

 Download file contains 6 next generation applets, fully compatible
 with all java enabled browsers. Files are Shareware.

Contact Silk Webware sales@silkwebware.com if you have any questions

Codelink4.zip New Version
1)Codelink V 4.0 Codelink appears on your web page as a burglar alarm
 keypad. Users enter a seven character password and are taken to a 
 secret page. See demo at http://silk.webware.co.nz/Products/Codelink
 *New version makes a sound when the key are pressed, for added realism.

Searchlink3.zip New Version
2)Searchlink V 3.0 Searchlink search engine allows users to keyword
  search link from or within your web site. You create a text file
  with the links, descriptions and keywords. No server programing
  or cgi required. Searchlink is easy to setup.
              See demo at http://silk.webware.co.nz/Products/Searchlink

BnFactory11.zip New Version
3)Banner Factory V 1.1 
  Banner Factory is a Java Applet Web site banner development
  tool. You can create professional 3D banners without any knowledge of
  Java programming or HTML. Include metallic/glowing titles, scrolling
  messages, background images, and 3D effects.  After you have created a
  banner to suit your needs, Banner Factory will generate all the
  necessary HTML code required to include it on your Web page. 
  See demo at http://silk.webware.co.nz/Products/BannerFactory/
  *New Version allows you to control scroll and glow speed.
  
Spinalink3.zip
4)Spinalink V 3.0 Spinalink links selector organises your website links
  into an attractive animated selector.
              See demo at http://silk.webware.co.nz/Products/Spinalink

Iconbar1.zip
5)Iconbar V 1.0 Create clickable buttons for your website. Iconbar 
  is fully HTML frames compatible and can be setup to appear like the
  toolbars on the latest web browsers.
              See demo at http://silk.webware.co.nz/Products/IconBar

Mailme3.zip
6)MailMe V 3.0 Automatically sends email to your web site guests at their
 request. MailMe can include a link back to your site. Perfect for
 sending product information etc. 
              See demo at http://silk.webware.co.nz/Products/Remindme

All six applets can be purchased together at a discounted rate!

Silk Webware http://silk.webware.co.nz "The New Internet is Here!"