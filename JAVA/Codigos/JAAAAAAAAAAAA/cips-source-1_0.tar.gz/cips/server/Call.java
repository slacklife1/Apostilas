/*
 * Copyright (C) 2000 by Mikael Hallendal
 */

package cips.server;

/**
 ** Class:
 **   Call
 ** 
 ** Description:
 **
 ** @author Mikael Hallendal (micke@hallendal.net)
 ** @version $Id: Call.java,v 1.4 2000/08/01 23:05:01 hallski Exp $
 **/

import java.util.Date;
import java.text.DateFormat;

public class Call 
{

  /*************
   * Variables *
   *************/
  
  int cId;
  int pId;
  int phone;
  String name;
  String showPhone;
  String time;
  boolean answered;
  boolean newCall;

  /****************
   * Constructors *
   ****************/

  public Call(int cId, int pId, int phone, String name, String showPhone, 
              String time, String answ, String newCall)
    {
      this.cId = cId;
      this.pId = pId;
      this.phone = phone;
      this.name = name;
      this.showPhone = showPhone;
      this.time = time;
      this.answered = answ.equals ("yes")   ? true : false;
      this.newCall = newCall.equals ("yes") ? true : false;
    }

  /***********
   * Methods *
   ***********/
  
  public String toString ()
    {
      // CALL: [cid][pid][phone][name][showphone][time][answered][newcall]
      return 
        "CALL: CID["+cId+"] PID["+pId+"] PHONE["+phone+"] "+
        "NAME["+name+"] SHOWPHONE["+showPhone+"] TIME["+time+"] " +
        "ANSWERED["+answered+"] NEWCALL["+newCall+"]";
    }

  /*******************
   * Private Methods *
   *******************/

} // End of Call 

