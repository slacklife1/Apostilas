CREATE DATABASE cips;
USE cips;

CREATE TABLE calls (
  callId int(11) NOT NULL auto_increment,
  phone tinyint(4) DEFAULT '0' NOT NULL,
  personId int(11) DEFAULT '0' NOT NULL,
  time DATETIME,
  answered set('yes','no') DEFAULT '' NOT NULL,
  new set('yes','no') DEFAULT 'yes' NOT NULL,
  PRIMARY KEY (callId)
);

CREATE TABLE persons (
  personId int(11) NOT NULL auto_increment,
  name tinytext DEFAULT '' NOT NULL,
  email tinytext,
  incPhone tinytext DEFAULT '' NOT NULL,
  showPhone tinytext DEFAULT '' NOT NULL,
  PRIMARY KEY (personId)
);

