/*
 * Copyright (C) 2000 by Mikael Hallendal
 */

package cips.server;

/**
 ** Class:
 **   Mailer
 ** 
 ** Description:
 **
 ** @author Mikael Hallendal (micke@hallendal.net)
 ** @version $Id: Mailer.java,v 1.2 2000/08/04 11:30:58 hallski Exp $
 **/

import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;

public class Mailer 
{

  /*************
   * Variables *
   *************/

  private String from;
  private String to;
  private String subject;
  private String message;
  private String smtphost;
  
  private Properties props= new Properties();
  private Session session;
  

  /****************
   * Constructors *
   ****************/

  public Mailer(String from, String to, String subject, String smtphost) 
    {
      this.from = from;
      this.to = to;
      this.subject = subject;
      this.smtphost = smtphost;
      
      props.put ("mail.smtp.host", smtphost);
    }

  /***********
   * Methods *
   ***********/

  public void setMessage (String message)
    {
      this.message = message;
    }

  public boolean send()
    {
      session = Session.getDefaultInstance (props, null);
      
      try {
        Message msg = new MimeMessage (session);
        
        InternetAddress[] address = {new InternetAddress (to)};
        msg.setRecipients (Message.RecipientType.TO, address);
        msg.setSubject (subject);
        
        msg.setContent (message, "text/plain");
        
        Transport.send(msg);
      }
      catch (MessagingException mex)
        {
          return false;
        }
      System.out.println ("Mailer.send(): Message sent to: " + to);

      return true;
    }

} // End of Mailer 

