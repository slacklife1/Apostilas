/*
 * Copyright (C) 2000 by Mikael Hallendal
 */

package cips.server;

/**
 ** Class:
 **   Person
 ** 
 ** Description:
 **
 ** @author Mikael Hallendal (micke@hallendal.net)
 ** @version $Id: Person.java,v 1.1 2000/08/01 23:05:01 hallski Exp $
 **/

public class Person 
{

  /*************
   * Variables *
   *************/
  
  int pId;
  String name;
  String email;
  String incPhone;
  String showPhone;
  int nrOfCalls;
  
  /****************
   * Constructors *
   ****************/

  public Person(int pId, String name, String email, String incPhone,
                String showPhone, int nrOfCalls) 
    {
      this.pId = pId;
      this.name = name;
      this.email = email;
      this.incPhone = incPhone;
      this.showPhone = showPhone;
      this.nrOfCalls = nrOfCalls;
    }

  /***********
   * Methods *
   ***********/
  
  public String toString ()
    {
      String str =
        "PERSON: PID[" + pId + "] NAME[" + name + "] EMAIL[" + email + "] " +
        "INCPHONE[" + incPhone + "] SHOWPHONE[" + showPhone + "] " +
        "NROFCALLS[" + nrOfCalls + "]";
      
      return str;
    }

  /*******************
   * Private Methods *
   *******************/

} // End of Person 

