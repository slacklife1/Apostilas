/*
 * Copyright (C) 2000 by Mikael Hallendal
 */

package cips.server.phone;

/**
 ** Class:
 **   ZyxelISDN
 ** 
 ** Description:
 **
 ** @author Mikael Hallendal (micke@hallendal.net)
 ** @version $Id: ZyxelISDN.java,v 1.1 2000/08/08 17:33:15 hallski Exp $
 **/

import java.io.*;
import java.util.Enumeration;

public class ZyxelISDN 
extends RouterEngine
{

  /*************
   * Variables *
   *************/

  /****************
   * Constructors *
   ****************/

  public ZyxelISDN(int portNr) 
    {
      super (portNr);
      
    }

  public ZyxelISDN(File logFile)
    {
      super (logFile);
      
    }

  /***********
   * Methods *
   ***********/

  /*********************
   * Protected Methods *
   *********************/

  protected void processIncoming(String s)
  {
    // FIX
    // CHANGE TO ADD SUPPORT FOR OTHER ROUTERS!
    if (s.indexOf("ZyXEL Communications Corp") > 0) {
      s = s.trim();
      System.out.println("RouterEngine (incoming): ["+s+"]");
      if (s.indexOf("RING") > 0) {
        processCall(s);
      }
      else if (s.indexOf("ONHOOK") > 0) {
        processOnHook(s);
      }
      else if (s.indexOf("OFFHOOK") > 0) {
        processOffHook(s);
      }
      else {
        System.out.println(s);
      }
    }
  }

  private void processCall(String s)
  {
    int nr = s.indexOf("CLID") + 5;
    String number = "Hidden";
    if (nr < s.length())
      number = s.substring(nr, s.length());
      
    int iPhone = this.getPhone(s);
    
    for (Enumeration e = listenerList.elements(); e.hasMoreElements();){
      ((PhoneListener)e.nextElement()).incomingCall(iPhone, number);
    }
  }  

  protected void processOnHook(String s)
    {
      int iPhone = this.getPhone(s);
      
      for (Enumeration e = listenerList.elements(); e.hasMoreElements();){
        ((PhoneListener)e.nextElement()).onHook(iPhone);
      }
    }
  protected void processOffHook(String s)
    {
      int iPhone = this.getPhone(s);
      
      for (Enumeration e = listenerList.elements(); e.hasMoreElements();){
        ((PhoneListener)e.nextElement()).offHook(iPhone);
      }
    }
  
  private int getPhone(String s)
  {
    int nr = s.indexOf("PHONE") + 5;
    String phone = s.substring(nr, nr+1);
    int iPhone;
    try {
      iPhone = Integer.parseInt(phone);
    }
    catch (NumberFormatException nfE){
      iPhone = 0;
    }
    return iPhone;
  }


} // End of ZyxelISDN 

