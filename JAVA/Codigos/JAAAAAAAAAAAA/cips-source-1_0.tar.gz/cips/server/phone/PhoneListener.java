/*
 * Copyright (C) 2000 by Mikael Hallendal
 */

package cips.server.phone;

/**
 * Class RouterListener
 * -----------------
 * 
 * 
 * 
 * @author  Mikael Hallendal (micke@hallendal.net)
 * @version $Id: PhoneListener.java,v 1.1.1.1 2000/07/30 22:45:28 hallski Exp $
 */

public class PhoneListener
implements java.util.EventListener
{

  /*************
   * Variables *
   *************/

  /****************
   * Constructors *
   ****************/
  public PhoneListener() 
    {
    }

  /***********
   * Methods *
   ***********/
  
  /**
   * incomingCall
   *
   * Called when an incoming call is detected.
   *
   * @param phone The phone ringing, could be 1 or 2
   * @param number The number of the incoming caller (CLID)
   */
  public void incomingCall(int phone, String number)
  {
  }

  /**
   * onHook
   *
   * Called when the phone goes on hook.
   * e.g. Putting the phone back on the hook
   *
   * @param phone The phone going onhook
   */
  public void onHook(int phone)
  {
  }
  
  /**
   * offHook
   *
   * Called when a phone goes off hook
   * e.g. When someone lifting it off it's hook
   *
   * @param phone The phone going off hook.
   */
  public void offHook(int phone)
  {
  }

  /**
   * answerConnected
   *
   * @param speed a value of type 'String'
   * @param number a value of type 'String'
   */
  public void answerConnected(String speed, String number)
  {
  }
  
  /**
   * incCallTerminated
   *
   * Not yet implemented!
   *
   * @param nil a value of type ''
   */
  public void incCallTerminated()
  {
  }
  
  /**
   * callRefuse
   *
   * Not yet implemented!
   *
   * @param nil a value of type ''
   */
  public void callRefuse()
  {
  }
  
  /**
   * ipAdressMissmatch
   *
   * Not yet implemented!
   *
   * @param nil a value of type ''
   */
  public void ipAdressMissmatch()
  {
  }
  
  /**
   * ipcpUp
   *
   * Not yet implemented!
   *
   * @param unknown a value of type 'String'
   */
  public void ipcpUp(String unknown)
  {
  }
  
  /**
   * ipcpDown
   *
   * Not yet implemented!
   *
   * @param unknown a value of type 'String'
   */
  public void ipcpDown(String unknown)
  {
  }

  /**
   * other
   *
   * Not yet implemented!
   *
   * @param paket a value of type 'String'
   */
  public void other(String paket)
  {
  }
  
} // End of PhoneListener 

