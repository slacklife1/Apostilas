/*
 * Copyright (C) 1999 by Mikael Hallendal
 */

package cips.server.phone;

import java.io.*;
import java.net.*;
import java.util.Vector;
import java.util.Enumeration;

/**
 * Class RouterEngine
 * -----------------
 * 
 * This is the engine that listens for incoming messages from the router.
 * 
 * @author  Mikael Hallendal (e95_mih@e.kth.se)
 * @version $Id: RouterEngine.java,v 1.3 2000/08/08 17:33:15 hallski Exp $
 */

public class RouterEngine 
extends Thread 
{
  /*************
   * Variables *
   *************/

  private byte[] buffer;
  private DatagramSocket ds;
  private DatagramPacket dp;

  private File logFile;

  protected Vector listenerList = new Vector();

  /****************
   * Constructors *
   ****************/

  /**
   * Describe constructor here.
   *
   * @param portNr a value of type 'int'
   */
  public RouterEngine(int portNr) 
  {
    try {
      ds = new DatagramSocket(portNr);
      this.start();
    }
    catch (SocketException sE) {
      System.err.println("RouterEngine() (SocketException): " + sE.getMessage());
    }
  }

  public RouterEngine(File logFile)
    {
      this.logFile = logFile;
      this.start();
    }

  /***********
   * Methods *
   ***********/

  /**
   * run
   *
   * @param nil a value of type ''
   */
  public void run()
    {
      if (logFile != null)
        runLf();
      else if (ds != null)
        runDs();
    }
  

  private void runLf()
    {
      long iRead;
      FileInputStream fis;
      String read;
      BufferedReader reader;
      
      try {
        iRead = logFile.length();
        while (true) {
          fis = new FileInputStream(logFile);
          reader = new BufferedReader(new InputStreamReader(fis));
          reader.skip((iRead));
          while((read = reader.readLine()) != null) {
            if (read.length() > 0) {
              iRead += read.length() + 1;
              processIncoming(read);
            }
          }
          Thread.sleep(100);
        }
      }
      catch (FileNotFoundException fnfE){
        System.err.println("RouterEngine.runLf() (FileNotFoundException): " + fnfE.getMessage());
      }
      catch (IOException ioE){
        System.err.println("RouterEngine.runLf() (IOException): " + ioE.getMessage());
      }
      catch (InterruptedException iE){
      }
    }

  private void runDs()
    {
      while(true) {
        try {
          buffer = new byte[65507];
          dp = new DatagramPacket(buffer, buffer.length);
          ds.receive(dp);
          String s = new String(dp.getData());
          this.processIncoming(s);
        }
        catch (IOException ioE) {
          System.err.println("RouterEngine.runDs() (IOException): " + ioE.getMessage());
        }
      }
    }

  /**
   * addListener
   *
   * @param rl a value of type 'PhoneListener'
   */
  public void addListener(PhoneListener rl)
    {
      listenerList.addElement(rl);
    }
  
  /**
   * removeListener
   *
   * @param rl a value of type 'PhoneListener'
   */
  public void removeListener(PhoneListener rl)
  {
    listenerList.removeElement(rl);
  }
  
  protected void processIncoming(String s) { };
} // End of RouterEngine 

