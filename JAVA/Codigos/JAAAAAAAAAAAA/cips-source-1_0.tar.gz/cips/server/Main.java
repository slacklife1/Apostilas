/*
 * Copyright (C) 2000 by Mikael Hallendal
 */

package cips.server;

import cips.server.phone.*;

import java.net.*;
import java.io.*;
import java.util.Hashtable;

/**
 * Class Main
 * -----------------
 * 
 * @author  Mikael Hallendal (micke@hallendal.net)
 * @version $Id: Main.java,v 1.3 2000/08/08 17:33:15 hallski Exp $
 */

public class Main 
{

  /***************
   * Definitions *                
   ***************/
  
  private static int DEF_PORT = 5656;
  private static int DEF_LPORT = 514;
  private static String DEF_CONFIG_FILE = "cips.server.cfg";
  private static boolean READ_FILE = false;
  
  /*************
   * Variables *
   *************/

  private int serverPort = DEF_PORT;
  private int routerPort = DEF_LPORT;
  private String configFile;

  private ServerSocket server;
  
  private MainListener mainListener;
  
  private PBaseConnection database;
  private RouterEngine rEngine;

  private Hashtable settings = new Hashtable ();

  /****************
   * Constructors *
   ****************/
  
  public Main(String configFile)
    {
      this.configFile = configFile;
      this.readConfig ();
      this.startUpServer(null);
    }

  public Main(String configFile, String fileName)
    {
      this.configFile = configFile;
      this.readConfig ();
      this.startUpServer(fileName);
    }

  /***********
   * Methods *
   ***********/

  public static void main(String[] args)
  {
    String fileName = null;
    String confFile = DEF_CONFIG_FILE;
    String sqlS = "localhost";
    String sqlL = "";
    String sqlP = "";
    
    Main program;

    for (int i = 0; i < args.length; ++i) {
      if (args[i].equals("-f") && ++i < args.length) {
        confFile = args[i];
      }
      if (args[i].equals("-s") && ++i < args.length) {
        fileName = args[i];
      }
    }
    
    if (fileName != null)
      program = new Main(confFile, fileName);
    else 
      program = new Main(confFile);
  }

  protected void addListener(PhoneListener pl) 
    {
      rEngine.addListener(pl);
    }
  
  protected void removeListener(PhoneListener pl)
    {
      rEngine.removeListener(pl);
    }
  
  private void startUpServer(String fileName)
    {
      System.out.println("Starting CIPS Server...");
      database = new PBaseConnection("org.gjt.mm.mysql.Driver", 
                                     "jdbc:mysql://" + settings.get ("SQL_SERVER") + 
                                     "/cips?user=" + settings.get ("SQL_LOGIN") + 
                                     "&password=" + settings.get ("SQL_PASSWORD"));
      mainListener = new MainListener(this, database, settings);  
      try {
        server = new ServerSocket(serverPort);
        if (fileName != null){
          File f = new File(fileName);
          if (((String)settings.get ("ROUTER_VENDOR")).equalsIgnoreCase ("Zyxel"))
            rEngine = new ZyxelISDN(f);
        }
        else
          if (((String)settings.get ("ROUTER_VENDOR")).equalsIgnoreCase ("Zyxel"))
            rEngine = new ZyxelISDN(routerPort);
        rEngine.addListener(mainListener);
        ClientConnection c;
        while (true) {
          System.out.println("\nWaiting for Client");
          Socket client = server.accept();
          c = new ClientConnection (client, rEngine, database);
          System.out.println("Got Client: "+client.getInetAddress().getHostAddress());
          c.start();
        }
      }
      catch (IOException ioE){
        System.err.println("Main.startUpServer () (IOExceptionion): "+ ioE.getMessage());
      }
    }
  
  private void readConfig ()
    {  
      String line;
      int offset;
      String key;
      String value;

      System.out.println ("Reading configs from : " + configFile);
      try {
        InputStream in = getClass().getResourceAsStream(configFile);
        
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        while ((line = reader.readLine()) != null) {
          if (!line.startsWith ("#")) {
            if ((offset = line.indexOf("=")) > 0) {
              key = line.substring(0,offset);
              value = line.substring(offset+1).trim();
              settings.put(key, value);
            }
          }
        }
      }
      catch (Exception e){
        System.err.println ("Main.readConfig (Exception): " + e.getMessage ());
      }      
      try {
        System.err.println ("Trying to get server port");
        int pNr = Integer.parseInt ((String)settings.get ("SERVER_PORT"));
        serverPort = pNr;
        System.err.println ("Trying to get router port");
        pNr = Integer.parseInt ((String)settings.get ("ROUTER_PORT"));
        System.err.println ("Done");

        routerPort = pNr;
      }
      catch (NumberFormatException nfE){
        System.err.println("Main.readConfig (NumberFormatException): "+nfE.getMessage());
      }
    }
} // End of Watcher 

