/*
 * Copyright (C) 2000 by Mikael Hallendal
 */

package cips.server;

import java.sql.*;
import java.util.Date;
import java.util.*;
import java.text.DateFormat;

/**
 * Class PBaseConnection
 * -----------------
 * 
 * @author  Mikael Hallendal (micke@hallendal.net)
 * @version $Id: PBaseConnection.java,v 1.10 2000/08/08 11:06:19 hallski Exp $
 */

public class PBaseConnection 
{

  /*************
   * Variables *
   *************/
  
  private static String CALL_TABLE = "calls";
  private static String PERSON_TABLE = "persons";
  
  private String dBaseDriver;
  private String connectString;

  private Connection dBaseConnection;

  /****************
   * Constructors *
   ****************/
  public PBaseConnection(String dBaseDriver, String connectString) 
    {
      this.dBaseDriver = dBaseDriver;
      this.connectString = connectString;
      
      this.connect ();
    }
  
  /***********
   * Methods *
   ***********/
  
  public synchronized boolean addCall(int phone, String phoneNr, boolean answered)
    {
      Statement statement = getStatement ();
      
      int pId;
      
      try 
        {
          ResultSet rs = statement.executeQuery("SELECT personId FROM persons "+
                                                "WHERE incPhone = '"+phoneNr+"'");
          
          if (!rs.next ()) {
            statement.executeUpdate("INSERT INTO " + PERSON_TABLE + 
                                    " (name, incPhone, showPhone) VALUES ("+
                                    "'Unknown', '"+phoneNr+"', '"+phoneNr+"')");
            rs = statement.executeQuery ("SELECT LAST_INSERT_ID ()");
            rs.next ();
            pId = rs.getInt (1);
          }
          else {
            pId = rs.getInt ("personId");
          }
          statement.executeUpdate("INSERT INTO "+CALL_TABLE+
                                  " (phone, personId, time, answered) VALUES (" +
                                  phone+",'"+pId+"', NOW()," +
                                  (answered ? "'yes'" : "'no'") + ")");
          
          this.closeStatement(statement);
        }
      catch (SQLException sqlE)
        {
          System.err.println ("===========================================");
          System.err.println ("SQLException: " + sqlE.getMessage());
          System.err.println ("SQLState:     " + sqlE.getSQLState());
          System.err.println ("VendorError:  " + sqlE.getErrorCode());    
          System.err.println ("===========================================");
          return false;
        }
      return true;
    }

  public String getShowNr (String incPhone) 
    {
      Statement statement = getStatement ();
      String showNr = "";
      
      try 
        {
          ResultSet rs = statement.executeQuery("SELECT showPhone FROM persons "+
                                                "WHERE incPhone = '"+incPhone+"'");
          
          if (!rs.next ()) 
            showNr = incPhone;
          else
            showNr = rs.getString ("showPhone");

          this.closeStatement (statement);
        }
      catch (SQLException sqlE)
        {
          System.err.println ("===========================================");
          System.err.println ("SQLException: " + sqlE.getMessage());
          System.err.println ("SQLState:     " + sqlE.getSQLState());
          System.err.println ("VendorError:  " + sqlE.getErrorCode());    
          System.err.println ("===========================================");
          return "Error connecting to SQL, please contact server admin";
        }
      return showNr;
    }
  
  public String getName (String incPhone)
    {
      Statement statement = getStatement ();
      String name = "";
      
      try 
        {
          ResultSet rs = statement.executeQuery("SELECT name FROM persons "+
                                                "WHERE incPhone = '"+incPhone+"'");
          
          if (!rs.next ()) 
            name = "Unknown";
          else
            name = rs.getString ("name");

          this.closeStatement (statement);
        }
      catch (SQLException sqlE)
        {
          System.err.println ("===========================================");
          System.err.println ("SQLException: " + sqlE.getMessage());
          System.err.println ("SQLState:     " + sqlE.getSQLState());
          System.err.println ("VendorError:  " + sqlE.getErrorCode());    
          System.err.println ("===========================================");
          return "Error connecting to SQL, please contact server admin";
        }
      return name;
    }
  
  public Vector getAllCalls() 
    {
      return getCalls ("");
    }

  public Vector getNewCalls()
    {
      return getCalls ("AND a.new = 'yes'");
    }

  public Vector getUnansweredCalls()
    {
      return getCalls ("AND a.answered = 'no'");
    }

  public Vector getCalls (int personId) 
    {
      return getCalls ("AND a.personId = " + personId);
    }
  
  public Person getPerson (int personId)
    {
      Person p = null;
      String qString1 = 
        "SELECT name, email, incPhone, showPhone " +
        "FROM persons WHERE personId = " + personId;
      String qString2 =
        "SELECT count(*) FROM calls where personId = " + personId;
      
      Statement statement = getStatement ();
      
      try {
        ResultSet rs = statement.executeQuery (qString1);
        
        if (!rs.next ()) 
          return null;
        
        String name = rs.getString ("name");
        String email = rs.getString ("email");
        String incPhone = rs.getString ("incPhone");
        String showPhone = rs.getString ("showPhone");
        int nrOfCalls = 0;

        rs = statement.executeQuery (qString2);
        
        if (rs.next ())
          nrOfCalls = rs.getInt (1);
        
        p = new Person (personId, name, email, incPhone, showPhone, nrOfCalls);
        this.closeStatement (statement);
      }
      catch (SQLException sqlE) {
        System.err.println ("===========================================");
        System.err.println ("SQLException: " + sqlE.getMessage());
        System.err.println ("SQLState:     " + sqlE.getSQLState());
        System.err.println ("VendorError:  " + sqlE.getErrorCode());    
        System.err.println ("===========================================");
        return null;
      }
      
      return p;
    }

  public Vector getPersons ()
    {
      return getPersons ("");
    }

  public Vector getUnknownPersons ()
    {
      return getPersons ("WHERE name='Unknown'");
    }

  private Vector getPersons (String qStr)
    {
      String qString1 =
        "SELECT personId, name, email, incPhone, showPhone FROM persons " + qStr;
      
      Statement statement = getStatement ();
      Statement statement2 = getStatement ();
      
      Vector v = new Vector (10);

      try {
        ResultSet rs = statement.executeQuery (qString1);
        
        while (rs.next ()) {
          int pId = rs.getInt ("personId");
          String name = rs.getString ("name");
          String email = rs.getString ("email");
          String incPhone = rs.getString ("incPhone");
          String showPhone = rs.getString ("showPhone");
          int nrOfCalls = -1;

          // Uncomment to show number of calls for each person. 
          // Commented this because it takes longer time to collect the answers.

//           String qString2 =
//             "SELECT count(*) FROM calls where personId = " + pId;
      
//           ResultSet rs2 = statement2.executeQuery (qString2);
          
//           if (rs2.next ())
//             nrOfCalls = rs2.getInt (1);
          
          Person p = new Person (pId, name, email, incPhone, showPhone, nrOfCalls);
          v.addElement (p);
        }
        statement.close ();
      }
      catch (SQLException sqlE) {
        System.err.println ("===========================================");
        System.err.println ("SQLException: " + sqlE.getMessage());
        System.err.println ("SQLState:     " + sqlE.getSQLState());
        System.err.println ("VendorError:  " + sqlE.getErrorCode());    
        System.err.println ("===========================================");
        return null;
      }
      System.err.println (".");
      
      return v;
    }
  
  private Vector getCalls (String qStr)
    {
      String qString = 
        "SELECT a.callId, a.personId, a.phone, b.name, b.showPhone, " +
        "DATE_FORMAT(a.time, '%d %M %Y %H:%i:%s'), a.answered, a.new " + 
        "FROM calls a, persons b WHERE a.personId = b.personId " + qStr + 
        " ORDER BY a.time DESC";
      
      Statement statement = getStatement ();
      
      Vector v = new Vector (10);

      try {
        ResultSet rs = statement.executeQuery (qString);

        while (rs.next ()) {
          int cId = rs.getInt ("callId");
          int pId = rs.getInt ("personId");
          int phone = rs.getInt ("phone");
          String name = rs.getString ("name");
          String showPhone = rs.getString ("showPhone");
          String time = rs.getString ("time");
          String answered = rs.getString ("answered");
          String newCall = rs.getString ("new");
          
          Call call = new Call (cId, pId, phone, name, showPhone, time, 
                                answered, newCall);
          v.addElement (call);
        }
        this.closeStatement (statement);
      }
      catch (SQLException sqlE) {
        System.err.println ("===========================================");
        System.err.println ("SQLException: " + sqlE.getMessage());
        System.err.println ("SQLState:     " + sqlE.getSQLState());
        System.err.println ("VendorError:  " + sqlE.getErrorCode());    
        System.err.println ("===========================================");
        return null;
      }
      System.err.println (".");
      
      return v;
    }

  private boolean closeStatement (Statement statement)
    {
      try {
        statement.close ();
//         dBaseConnection.close ();
//         statement = dBaseConnection = null;
        statement = null;
      }
      catch (SQLException sqlE){
        System.err.println ("===========================================");
        System.err.println ("SQLException: " + sqlE.getMessage());
        System.err.println ("SQLState:     " + sqlE.getSQLState());
        System.err.println ("VendorError:  " + sqlE.getErrorCode());    
        System.err.println ("===========================================");
        return false;
      }
      return true;
    }

  private boolean connect ()
    {
      try {
        Class.forName(dBaseDriver).newInstance();
        if (dBaseConnection != null && !dBaseConnection.isClosed ())
          return true;
        dBaseConnection = DriverManager.getConnection(connectString);
      }
      catch (SQLException sqlE){
        System.err.println ("===========================================");
        System.err.println ("SQLException: " + sqlE.getMessage());
        System.err.println ("SQLState:     " + sqlE.getSQLState());
        System.err.println ("VendorError:  " + sqlE.getErrorCode());    
        System.err.println ("===========================================");
        return false;
      }
      catch (Exception e)
        {
          System.err.println ("PBaseConnection.connect() (Exception): " + e.getMessage ());
          return false;
        }
      return true;
    }
  
  private Statement getStatement ()
    {
      Statement statement = null;
      
      try {
        this.connect ();
        statement = dBaseConnection.createStatement ();
      }
      catch (SQLException sqlE) {
        System.err.println ("PBaseConnection.getStatement () (SQLException): " + sqlE.getMessage ());
        try {
          dBaseConnection.close ();
          dBaseConnection = null;
          this.connect ();
          statement = dBaseConnection.createStatement ();
        }
        catch (SQLException sqlE2) {
          System.err.println ("PBaseConnection.getStatement() (SQLException2): " + sqlE2.getMessage ());
          return null;
        }
        return null;
      }
      return statement;
    }
} // End of PBaseConnection 

