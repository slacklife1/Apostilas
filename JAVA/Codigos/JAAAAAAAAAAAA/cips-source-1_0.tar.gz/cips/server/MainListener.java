/*
 * Copyright (C) 2000 by Mikael Hallendal
 */

package cips.server;

import cips.server.phone.PhoneListener;

import java.util.Hashtable;

/**
 * Class MainListener
 * -----------------
 * 
 * Testar en sak!
 * 
 * @author  Mikael Hallendal (micke@hallendal.net)
 * @version $Id: MainListener.java,v 1.2 2000/08/01 23:51:40 hallski Exp $
 */

public class MainListener
extends PhoneListener
{
  /*************
   * Variables *
   *************/
  
  private PBaseConnection database;
  private Main main;

  private Hashtable settings;

  /****************
   * Constructors *
   ****************/
  public MainListener(Main main, PBaseConnection database, Hashtable settings) 
    {
      this.database = database;
      this.main = main;
      this.settings = settings;
    }
  
  /***********
   * Methods *
   ***********/
  
  public void incomingCall(int phone, String number)
    {
      AnswerListener al = new AnswerListener(main, phone, number, database);
      main.addListener(al);
    }
  
  private class AnswerListener extends PhoneListener 
  {
    int phone;
    String number;
    PBaseConnection dBase;
    Main main;
    
    public AnswerListener(Main main, int phone, String number, PBaseConnection dBase)
      {
        this.phone = phone;
        this.number = number;
        this.dBase = dBase;
        this.main = main;
      }
    
    public void onHook(int ph)
      {
        if (ph == phone) {
          dBase.addCall(phone, number, false);
          // FIX before any release !!!
          if (number != "" && 
              !(dBase.getName(number)).equalsIgnoreCase((String)settings.get ("NO_MAIL_IF_CALLER")))
            {
              System.err.println ("Mailing number with inc. call from: [" + dBase.getName (number) + "]");
              Mailer mail = new Mailer ((String)settings.get ("MAIL_FROM"), 
                                        (String)settings.get ("MAIL_TO"),
                                        "Unanswered call", "localhost");
              mail.setMessage ("\nPh: "+phone+"\nName: "+dBase.getName(number)+
                               "\nNr: "+dBase.getShowNr(number)+"\n");
              mail.send ();
            }
          main.removeListener(this);
        }
      }
    
    public void offHook(int ph) 
      {
        if (ph == phone) {
          dBase.addCall(phone, number, true);
          main.removeListener(this);
        }
      }
  } // End of innerclass AnswerListener
} // End of MainListener 

