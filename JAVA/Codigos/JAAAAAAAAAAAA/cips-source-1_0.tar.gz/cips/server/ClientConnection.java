/*
 * Copyright (C) 2000 by Mikael Hallendal
 */

package cips.server;

import java.net.*;
import java.io.*;
import java.util.*;

import cips.server.phone.*;

/**
 * Class ClientConnection
 * -----------------
 * 
 * @author  Mikael Hallendal (micke@hallendal.net)
 * @version $Id: ClientConnection.java,v 1.7 2000/08/04 11:30:58 hallski Exp $
 */

public class ClientConnection
extends Thread
{
  /*************
   * Variables *
   *************/

  private Socket socket;
  private RouterEngine rEngine;
  private PrintWriter client;
  private BufferedReader clientIn;
  private StatusListener rListen;
  private String hostAddress;
  private PBaseConnection database;
    
  /****************
   * Constructors *
   ****************/
  public ClientConnection(Socket socket, RouterEngine rEngine, PBaseConnection database) 
    {
      this.socket = socket;
      this.rEngine = rEngine;
      this.hostAddress = socket.getInetAddress().getHostAddress();
      this.database = database;
      
      try {
        client = new PrintWriter(socket.getOutputStream(), true);
        clientIn = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        
        rListen = new StatusListener(this, database);
        rEngine.addListener(rListen);
      }
      catch (IOException ioE){
      }
    }

  /***********
   * Methods *
   ***********/

  public void run()
  {
    boolean finished = false;
    try {
      while(!finished) {
        String s = clientIn.readLine();
        s = s.toUpperCase ();
        if (s.equals ("GET_ALL_CALLS")) {
          Vector calls = database.getAllCalls (); 
          this.sendCalls (calls);
        }
        else if (s.equals ("GET_NEW_CALLS")) {
          Vector calls = database.getNewCalls ();
          this.sendCalls (calls);
        }
        else if (s.equals ("GET_UNANSWERED_CALLS")) {
          Vector calls = database.getUnansweredCalls ();
          this.sendCalls (calls);
        }
        else if (s.startsWith ("GET_CALLS_FROM[")) {
          int pId = -1;
          int index1 = 15;
          int index2 = s.indexOf ("]", index1);
          if (index2 > index1) {
            String pidStr = s.substring (index1, index2);
            try {
              pId = Integer.parseInt (pidStr);
            }
            catch (NumberFormatException nfE) {
              System.err.println ("ClientConnection.run() (NumberFormatExcepton): " + nfE.getMessage ());
            }
            if (pId != -1) {
              Vector calls = database.getCalls (pId);
              this.sendCalls (calls);
            }
            else
              this.sendCalls (null);
          }
          else {
            this.println ("[ERROR]");
          }

        }
        else if (s.startsWith ("GET_PERSON[")) {
          int pId = -1;
          int index1 = 11;
          int index2 = s.indexOf ("]", index1);
          if (index2 > index1) {
            String pidStr = s.substring (index1, index2);
            try {
              pId = Integer.parseInt (pidStr);
            }
            catch (NumberFormatException nfE) {
              System.err.println ("ClientConnection.run() (NumberFormatExcepton): " + nfE.getMessage ());
            }
            if (pId != -1) {
              Person p = database.getPerson (pId);
              if (p != null)
                this.println (p.toString ());
            }
            else {
              this.println ("[No Person]");
            }
          }
          else {
            this.println ("[ERROR]");
          }
        }
        else if (s.equals ("GET_ALL_PERSONS")) {
          Vector persons = database.getPersons ();
          this.sendPersons (persons);
        }
        else if (s.equals ("GET_UNKNOWN_PERSONS")) {
          Vector persons = database.getUnknownPersons ();
          this.sendPersons (persons);
        }
        else if (s.equals ("QUIT")){
          rEngine.removeListener(rListen);
          finished = true;
          socket.close();
        }
        else {
          System.out.println(s);
        }
      }
      System.out.println("Client left: "+hostAddress);
      socket.close ();
    }
    catch (IOException ioE) {
      System.err.println ("ClientConnection.run() (IOException): " + ioE.getMessage ());
      finished = true;
    }
    catch (NullPointerException npE) {
      System.err.println ("ClientConnection.runt() (NullpointerException): " + npE.getMessage ());
      finished = true;
    }
  }

  public String toString()
    {
      return "";
    }

  public synchronized void println (String str)
    {
      client.println (str);
    }
  
  private void sendCalls (Vector calls)
    {
      if (calls != null || calls.size () != 0) {
        this.println ("[CallList Start][" + calls.size () + "]");

        for (Enumeration e = calls.elements (); e.hasMoreElements ();) {
          Call c = (Call)e.nextElement ();
          this.println (c.toString ());
        }
        
        this.println ("[CallList End]");
      }
      else
        this.println ("[No Calls]");
    }

  private void sendPersons (Vector persons)
    {
      if (persons.size () != 0) {
        this.println ("[PersonList Start][" + persons.size () + "]");

        for (Enumeration e = persons.elements (); e.hasMoreElements ();) {
          Person p = (Person)e.nextElement ();
          this.println (p.toString ());
        }
        
        this.println ("[PersonList End]");
      }
      else
        this.println ("[No Persons]");
    }

  private class StatusListener extends PhoneListener
  {
    
    /*************
     * Variables *
     *************/

    private ClientConnection client;
    private PBaseConnection database;
  
    /****************
     * Constructors *
     ****************/

    public StatusListener()
      {
        client = null;
      }
  
    
    public StatusListener(ClientConnection client, PBaseConnection database) 
      {
        this.client = client;
        this.database = database;
      }
  
    /***********
     * Methods *
     ***********/
  
    public void incomingCall(int phone, String number)
      {
        String name = database.getName (number);
        String showNr = database.getShowNr (number);
        client.println("INC CALL: PHONE["+phone+"] NUMBER["+showNr+
                       "] NAME["+name+"]");
      }
  
    public void onHook(int phone)
      {
        client.println("ONHOOK: PHONE["+phone+"]");
      }
  
    public void offHook(int phone)
      {
        client.println("OFFHOOK: PHONE["+phone+"]");
      }
  } // End of StatusListener 



} // End of ClientConnection 

