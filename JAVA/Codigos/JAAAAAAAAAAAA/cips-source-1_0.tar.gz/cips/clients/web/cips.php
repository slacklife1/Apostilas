<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<?php
 
  mysql_connect ("mysql_server_host", "mysql_login", "mysql_passwd");
  mysql_select_db ("cips");
  include ("cips_pages.php3");
?>
<html>
  <head>  
    <style type="text/css">
      h1 { color:white }
      address { color:white }
    </style>
    <title>Caller Id Presentation System</title>
  </head>

  <body bgcolor="white">

<?php
if (!$page or $page == "call") {
  $pageObj = new ViewCalls ($arg);
}
elseif ($page == "person") {
  if ($arg == "all" || $arg == "unknown") {
    $pageObj = new ViewPersons ($arg); 
  }
  elseif ($arg == "person" && $arg2) {
    $pageObj = new ViewPerson ($arg2);
  }
}
elseif ($page == "update_calls") {
  $i = 0;
  while (list($key, $val) = each($HTTP_POST_VARS)) {
    if (preg_match ("/^nn_(.*)$/", $key, $match)) {
      $notnew_array[$i] = $match[1];
      ++$i;
    }
  }
  $pageObj = new UpdateCalls ($notnew_array);
}
elseif ($page == "update_person") {
  $pageObj = new UpdatePerson ($pers_id, $pers_name, $pers_showphone, $pers_incphone, $pers_email);
}
?>

    <table width="100%" cellpadding="0" cellspacing="1">
      <tr>
	<td colspan="2">    
	  
	  <table width="100%" cellspacing="0" cellpadding="1" border="0" bgcolor="black">
	    <tr>
	      <td colspan="2">
		
		<table WIDTH="100%" BORDER="0" CELLSPACING="1" CELLPADDING="1">
		  <tr>
		    <td colspan="2" bgcolor="#6e7b8b" align="center">
		      <br>
		      <h1>Caller Id Presentation System</h1>
		    </td>
		  </tr>
		</table>
	      </td>
	    </tr>
	  </table>
	</td>
      </tr>
      <tr>
	<td width="20%" rowspan="2" valign="top">
	  <table width="100%" cellspacing="0" cellpadding="1" border="0" bgcolor="black">
	    <tr>
	      <td>
		<table width="100%" border="0" cellspacing="1" cellpadding="1">
		  <tr>
		    <td bgcolor="#838b8b" align="center" valign="center">
		      <font size="+2" color="white">Menu</font>
		    </td>
		  </tr>
		  <tr>
		    <td bgcolor="#c1cdcd" valign="top">
		      <!-- Menu -->
		      <a href="cips.php3">New Unanswered Calls</a><br>
		      <a href="cips.php3?page=call&arg=new">All New Calls</a><br>
		      <a href="cips.php3?page=call&arg=unanswered">All Unanswered Calls</a><br>
		      <a href="cips.php3?page=call&arg=answered">All Answered Calls</a><br>
		      <a href="cips.php3?page=call&arg=unknown">All Unknown Calls</a><br>
		      <a href="cips.php3?page=call&arg=all">All Calls</a><br>
		      <hr>
		      <a href="cips.php3?page=person&arg=all">List/Edit Persons</a><br>
		      <a href="cips.php3?page=person&arg=unknown">All Unknown Persons</a><br>
		    </td>
		  </tr>
		</table>
	      </td>
	    </tr>
	  </table>
	</td>
	<td width="80%" valign="top">
	  <table width="100%" cellspacing="0" cellpadding="1" border="0" bgcolor="black">
	    <tr>
	      <td>
		<table width="100%" border="0" cellspacing="1" cellpadding="1">
		  <tr>
		    <td bgcolor="#757575" align="center">
		      <font size="+2" color="white">Misc Statistics</font>
		    </td>
		  </tr>
		  <tr>
		    <td bgcolor="#c9c9c9" valign="top">
		      <table border="0" width="100%">
                        <?php include ("cips_misc_stats.php3") ?>
		      </table>
		    </td>
		  </tr>
		</table>
	      </td>
	    </tr>
	  </table>
	</td>
      </tr>
      <tr>
	<td valign="top">
	  <table width="100%" cellspacing="0" cellpadding="1" border="0" bgcolor="black">
	    <tr>
	      <td>
		<table width="100%" border="0" cellspacing="1" cellpadding="1">
		  <tr>
		    <td bgcolor="#737b9c">
		      <font size="+2" color="#ffffff">
			<center>
			  <?php $pageObj->print_title() ?>
			</center>
		      </font>
		    </td>
		  </tr>
		  <tr>
		    <td bgcolor="#EEEEF8">
		      <?php $pageObj->print_page () ?>
		    </td>
		  </tr>
		</table>
	      </td>
	    </tr>
	  </table>
	</td>
      </tr>
    </table>
    
    <hr>
    <address>Mikael Hallendal &lt;micke@hallendal.net&gt;</address>
    <!-- Created: Wed Aug  2 16:29:02 CEST 2000 -->
    <!-- hhmts start -->
Last modified: Tue Aug  8 01:06:51 CEST 2000
<!-- hhmts end -->
  </body>
</html>
