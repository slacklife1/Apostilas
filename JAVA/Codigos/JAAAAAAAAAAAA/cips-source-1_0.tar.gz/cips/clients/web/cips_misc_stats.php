<?php 
  $new_calls_result = mysql_query ("SELECT count(*) FROM calls WHERE new='yes'");
  $row = mysql_fetch_row ($new_calls_result);		     
  echo "<tr><td><a href=\"cips.php?page=call&arg=new\"><b>Total New Calls</b></a></td><td>$row[0]</td>\n";

  $unans_calls_result = mysql_query ("SELECT count(*) FROM calls WHERE answered='no'");
  $row = mysql_fetch_row ($unans_calls_result);		     
  echo "<td><a href=\"cips.php?page=call&arg=unanswered\"><b>Total Unanswered Calls</b></a></td><td>$row[0]</td></tr>\n";

  $nr_calls_result = mysql_query ("SELECT count(*) FROM calls");
  $row = mysql_fetch_row ($nr_calls_result);
  echo "<tr><td><a href=\"cips.php?page=call&arg=all\"><b>Total Calls</b></a></td><td>$row[0]</td>\n";		      
		  
  $nr_unknown_calls_result = 
    mysql_query ("SELECT count(*) FROM calls a, persons b WHERE a.personId = b.personId AND b.name = 'Unknown'");
  $row = mysql_fetch_row ($nr_unknown_calls_result);
  echo "<td><a href=\"cips.php?page=call&arg=unknown\"><b>Total Unknown Calls</b></a></td><td>$row[0]</td></tr>\n";		      
		  
  echo "<tr><td colspan=\"4\"><hr></td></tr>\n";

  $total_p_result = mysql_query ("SELECT count(*) FROM persons");
  $row = mysql_fetch_row ($total_p_result);
  echo "<tr><td><a href=\"cips.php?page=person&arg=all\"><b>Total Persons</b></a></td><td>$row[0]</td>\n";

  $unknown_p_result = mysql_query ("SELECT count(*) FROM persons WHERE name='Unknown'");
  $row = mysql_fetch_row ($unknown_p_result);
  echo "<td><a href=\"cips.php?page=person&arg=unknown\"><b>Total Unknown Persons</b></a></td><td>$row[0]</td></tr>\n";

?>
