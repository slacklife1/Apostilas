<?php

class Page {
  var $title = "Hmm";
  var $subpage;

  function print_title() {
    echo $this->title;
  }

  function print_page () {
    echo "Unknown";
  }
}

class ViewCalls extends Page {
  var $new = 0;
  var $qString = "";

  function ViewCalls ($arg) {
    $this->subpage = $arg;
    if ($arg == "new") {
      $this->new = 1;
      $this->title = "New Calls";
      $this->qString = "AND a.new='yes'";
    }
    elseif ($arg == "unanswered") {
      $this->title = "Unanswered Calls";
      $this->qString = "AND a.answered='no'";
    }
    elseif ($arg == "answered") {
      $this->title = "Answered Calls";
      $this->qString = "AND a.answered='yes'";
    }
    elseif ($arg == "unknown") {
      $this->title = "Calls From Unknown Persons";
      $this->qString = "AND b.name = 'Unknown'";
    }
    elseif ($arg == "all")  {
      $this->title = "All Calls";
    }
    else {
      $this->new = 1;
      $this->subpage = "new_unanswered";
      $this->title = "All New Unanswered Calls";
      $this->qString = "AND a.new = 'yes' AND a.answered='no'";
    }
  }

  function print_phone ($phone) {
    echo "<tr align=\"left\"><th>Phone $phone</th></tr>\n";
    echo "<tr>\n";
    echo "<th>Name</th><th>Show Phone</th><th>Time</th>\n";

    if ($this->new) {
      echo "<th>Not new</th>\n";
    }

    echo "</tr>\n";

  
    $call_result = mysql_query ("SELECT a.callId, b.name, b.showPhone, DATE_FORMAT(a.time, '%d %M %Y %H:%i:%s'), a.personId FROM calls a, persons b WHERE a.personId = b.personId AND a.phone=$phone $this->qString ORDER BY a.time DESC");
 
    while ($row = mysql_fetch_row ($call_result)) {
      echo "<tr align=\"right\"><td><a href=\"cips.php?page=person&arg=person&arg2=$row[4]\"><b>$row[1]</b></a></td><td>$row[2]</td><td>$row[3]</td>";
      
      if ($this->new) {
        echo "<td align=\"center\"><input type=\"checkbox\" name=\"nn_$row[0]\" label=\"\"></td>";
      }
      echo "</tr>\n"; 
    }

    if ($this->new) {
      echo "<tr><td colspan=\"4\"><hr></td></tr>\n";
    }
    else {
      echo "<tr><td colspan=\"3\"><hr></td></tr>\n";
    }
  }

  function print_page () {
    if ($this->new) {
      echo "<form action=\"cips.php?page=update_calls\" method=\"post\">";
    }

    echo "<table width=\"100%\">\n";

    $this->print_phone (1);
    $this->print_phone (2);

    if ($this->new) {
      echo "<tr align=\"center\"><td></td><td></td><td></td><td><input type=\"submit\" value=\"Update\"></td></tr>\n";
      echo "</form>\n";
    }

    echo "</table>\n";
  }

} # End of ViewCalls

class ViewPersons extends Page {
  var $qString = "";
  
  function ViewPersons ($arg) {
    $this->subpage = $arg;

    if ($arg == "all") {
      $this->title = "All Persons";
    } 
    elseif ($arg == "unknown") {
      $this->title = "Unknown Persons";
      $this->qString = "WHERE name = 'Unknown'";
    }
    else {
      $this->title = "$arg";
    }
  }

  function print_page () {
    echo "<table width=\"100%\" border=\"0\">\n";
    echo "<tr><th>Name</th><th>Show Phone</th><th>Inc Phone</th><th>Email</th></tr>\n";
    $person_result = mysql_query ("SELECT personId, name, showPhone, incPhone, email FROM persons $this->qString ORDER BY name");
    while ($row = mysql_fetch_row ($person_result)) {
      echo "<tr><td><a href=\"cips.php?page=person&arg=person&arg2=$row[0]\"><b>$row[1]</b></a></td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td></tr>\n"; 
    }
    echo "</table>\n";       
  } 
}

class Person {
  var $id;
  var $name;
  var $showPhone;
  var $incPhone;
  var $email;

  function Person ($p_id, $p_name, $p_showphone, $p_incphone, $p_email) {
    $this->id = $p_id;
    $this->name = $p_name;
    $this->showPhone = $p_showphone;
    $this->incPhone = $p_incphone;
    $this->email = $p_email;
  }
  
  function getId () {
    return $this->id;
  }
  function getName () {
    return $this->name;
  }
  function getShowPhone () {
    return $this->showPhone;
  }
  function getIncPhone () {
    return $this->incPhone;
  }
  function getEmail () {
    return $this->email;
  }
}

class ViewPerson extends Page {
  var $person;

  function ViewPerson ($arg) {
    $usr_result = mysql_query ("SELECT name, showPhone, incPhone, email  FROM persons WHERE personId = $arg");
    $row = mysql_fetch_row ($usr_result);
    $this->person = new Person ($arg, $row[0], $row[1], $row[2], $row[3]);
    $this->title = $row[0];;
  }

  function print_page () {
    echo "<form action=\"cips.php?page=update_person\" method=\"post\">\n";
    echo "  <input type=\"hidden\" name=\"pers_id\" value=\"";
    echo $this->person->getId();
    echo "\">\n";
    echo "  <table width=\"100%\" border=\"0\">\n";
    echo "    <tr align=\"left\">\n";
    echo "      <th>Name: </th>\n";
    echo "      <td><input type=\"text\" name=\"pers_name\" value=\"";
    echo $this->person->getName();
    echo "\" size=\"40\"></td></tr>\n";
    echo "    <tr align=\"left\">\n";
    echo "      <th>Email: </th>\n";
    echo "      <td><input type=\"text\" name=\"pers_email\" value=\"";
    echo $this->person->getEmail();
    echo "\" size=\"40\"></td></tr>\n";
    echo "    <tr align=\"left\">\n";
    echo "      <th>Incoming Number: </th>\n";
    echo "      <td><input type=\"text\" name=\"pers_incphone\" value=\"";
    echo $this->person->getIncPhone();
    echo "\" size=\"40\"></td></tr>\n";
    echo "    <tr align=\"left\">\n";
    echo "      <th>Show Number:</th>\n";
    echo "      <td><input type=\"text\" name=\"pers_showphone\" value=\"";
    echo $this->person->getShowPhone();
    echo "\" size=\"40\"></td></tr>\n";
    echo "  </table>\n";
    echo "  <input type=\"submit\" name=\".submit\" value=\"Update\">\n";
    echo "</form>\n";
    echo "<hr>\n";

    $id = $this->person->getId ();
    $person_result = mysql_query ("SELECT count(*) FROM calls WHERE personId=$id");
    $row = mysql_fetch_row ($person_result);
    echo "<table width=\"100%\" border=\"0\">\n";
    echo "  <tr align=\"left\">\n";
    echo "    <th>Called: </th><td colspan=\"2\">$row[0] time(s)</td></tr>\n";
    echo "  <tr><td colspan=\"3\"><hr></td></tr>\n";
    echo "  <tr align=\"left\"><th>Phone</th><th>Time</th><th>Answered</th></tr>\n";
    $call_result = mysql_query ("SELECT a.phone, a.answered, DATE_FORMAT(a.time, '%d %M %Y %H:%i:%s') FROM calls a WHERE a.personId = $id ORDER BY a.time DESC");
 
    while ($row = mysql_fetch_row ($call_result)) {
      echo "<tr align=\"left\"><td><td>$row[0]</td><td>$row[2]</td><td>$row[1]</td></tr>";
    }
    
    echo "</table>\n";
  }    
}

class UpdateCalls extends Page {
  var $notnew_array;

  function UpdateCalls ($notnew_array) {
    $nr_of_upd = count ($notnew_array);
    $this->title = "Updated $nr_of_upd Calls";
    $this->notnew_array = $notnew_array;
    while (list($i, $cid) = each ($notnew_array)) {
      mysql_query ("UPDATE calls SET new='no' WHERE callId=$cid");
    }
  }
  
  function print_page () {
    echo "<h3>The following calls has been marked as <b>NOT</b> new</h3>\n";
    echo "<table border=0 width=\"100%\">\n";
    echo "<tr align=\"right\"><th>Phone</th><th>Caller</th><th>Phone Number</th><th>Time</th></tr>\n";
    while (list ($i, $cid) = each($this->notnew_array)) {
      $call_update_result = mysql_query ("SELECT a.phone, b.name, b.showPhone, DATE_FORMAT(a.time, '%d %M %Y %H:%i:%s'), b.personId FROM calls a, persons b WHERE a.personId = b.personId AND a.callId=$cid");
      $row = mysql_fetch_row ($call_update_result);
      echo "<tr align=\"right\"><td>$row[0]</td><td><a href=\"cips.php?page=person&arg=person&arg2=$row[4]\"><b>$row[1]</b></a></td><td>$row[2]</td><td>$row[3]</td></tr>\n";
    }
    echo "</table>\n";
  }
}

class UpdatePerson extends Page {
  var $person;

  function UpdatePerson ($p_id, $p_name, $p_showP, $p_incP, $p_email) {
    $this->person = new Person ($p_id, $p_name, $p_showP, $p_incP, $p_email);
    $this->title = "Updating: $p_name ($p_id)";

    mysql_query ("UPDATE persons SET name='$p_name', showPhone='$p_showP', incPhone='$p_incP', email='$p_email' WHERE personId=$p_id");
  }
  
  function print_page () {
    echo "  <table width=\"100%\" border=\"0\">\n";
    echo "    <tr align=\"left\">\n";
    echo "      <th>Name: </th>\n";
    echo "      <td><a href=\"cips.php?page=person&arg=person&arg2=";
    echo $this->person->getId ();
    echo "\"><b>";
    echo $this->person->getName();
    echo "</b></a>";
    echo "</td></tr>\n";
    echo "    <tr align=\"left\">\n";
    echo "      <th>Email: </th>\n";
    echo "      <td>";
    echo $this->person->getEmail();
    echo "</td></tr>\n";
    echo "    <tr align=\"left\">\n";
    echo "      <th>Incoming Number: </th>\n";
    echo "      <td>";
    echo $this->person->getIncPhone();
    echo "</td></tr>\n";
    echo "    <tr align=\"left\">\n";
    echo "      <th>Show Number:</th>\n";
    echo "      <td>";
    echo $this->person->getShowPhone();
    echo "</td></tr>\n";
    echo "</table>\n";
  }
}

?>
