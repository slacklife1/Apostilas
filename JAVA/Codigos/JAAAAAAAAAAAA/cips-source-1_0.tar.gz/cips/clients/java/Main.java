/*
 * Copyright (C) 2000 by Mikael Hallendal
 */

package cips.clients.java;

/**
 * Class Main
 * -----------------
 * 
 * 
 * @author  Mikael Hallendal (micke@hallendal.net)
 * @version $Id: Main.java,v 1.3 2000/07/31 00:35:04 hallski Exp $
 */

public class Main 
{

  /*************
   * Variables *
   *************/
  
  private static int SERVER_PORT = 5656;
  private static String SERVER_HOST = "localhost";

  private ServerConnection serverConn;
  
  /****************
   * Constructors *
   ****************/
  public Main(String serverHost, int serverPort) 
    {
      //       gui = new Gui(dBase);
      serverConn = new ServerConnection(serverHost, serverPort, this);
      serverConn.run();
    }
  
  /***********
   * Methods *
   ***********/

  public void incCall(int phone, String number, String name)
    {
      IncCallFrame icF = new IncCallFrame(phone, number, name);
      icF.setVisible(true);
      icF.setLocation(300,300);
    }

  public static void main(String[] args) 
    {
      String serverHost = SERVER_HOST;
      int serverPort = SERVER_PORT;
      for (int i = 0; i < args.length; ++i) {
        if (args[i].equals ("-s") && ++i < args.length) {
          serverHost = args[i];
        }
        else if (args[i].equals ("-p") && ++i < args.length) {
          try {
            int pNr = Integer.parseInt(args[i]);
            serverPort = pNr;
          }
          catch (NumberFormatException nfE){
            System.err.println("NumberFormat Exception: "+nfE.getMessage());
          }
        }
        else if (args[i].equals ("--help")) {
          System.out.println ("Usage: cips.clients.java.Main -s serverhost -p serverport");
          System.exit (1);
        }
        
      }
      Main program = new Main(serverHost, serverPort);
    }
} // End of Main 

