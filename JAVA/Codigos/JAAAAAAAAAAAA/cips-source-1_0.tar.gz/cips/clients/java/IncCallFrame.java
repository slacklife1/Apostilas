/*
 * Copyright (C) 2000 by Mikael Hallendal
 */

package cips.clients.java;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;


/**
 * Class IncCallFrame
 * -----------------
 * 
 * 
 * 
 * @author  Mikael Hallendal (micke@hallendal.net)
 * @version $Id: IncCallFrame.java,v 1.2 2000/08/07 23:34:44 hallski Exp $
 */

public class IncCallFrame 
extends JFrame
implements MouseListener, ActionListener
{

  /*************
   * Variables *
   *************/

  private int             phone;
  private String          phoneNr;
  private String          name;

  // Frame components

  private JPanel          incPanel;
  private JLabel          infoString;

  /****************
   * Constructors *
   ****************/
  public IncCallFrame(int phone, String phoneNr, String name)
    {
      this.phone        = phone;
      this.phoneNr      = phoneNr;
      this.name         = name;
      
      this.initFrame();
    }

  /***********
   * Methods *
   ***********/

  public void actionPerformed(ActionEvent aE)
    {
    }

  public void mouseClicked(MouseEvent mE)
    {
      this.dispose();
    }
  //     Invoked when the mouse enters a component. 
  public void mouseEntered(MouseEvent mE) 
    {
    }
    //   Invoked when the mouse exits a component. 
  public void mouseExited(MouseEvent mE) 
    {
    }

    //   Invoked when a mouse button has been pressed on a component. 
  public void mousePressed(MouseEvent mE) 
    {
    }
    //   Invoked when a mouse button has been released on a component.   
  public void mouseReleased(MouseEvent mE) 
    {
    }

  private void initFrame()
  {
    this.setSize(400, 45);
    this.setLocation(300, 300);
    this.setTitle("Incoming Call on "+phone);
    infoString = new JLabel(" " + name + " [ " + phoneNr + " ]");
    infoString.setForeground(Color.blue);
    incPanel = new JPanel();
    incPanel.setBackground (Color.white);
    incPanel.add(infoString, "Center");
    this.getContentPane().add(incPanel);
    this.addMouseListener(this);
  }
} // End of IncCallFrame 

