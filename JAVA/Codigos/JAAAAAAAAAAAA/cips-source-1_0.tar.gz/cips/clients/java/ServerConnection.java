/*
 * Copyright (C) 2000 by Mikael Hallendal
 */

package cips.clients.java;

// import showPhone.database.*;

import java.net.*;
import java.io.*;
/**
 * Class ServerConnection
 * -----------------
 * 
 * 
 * 
 * @author  Mikael Hallendal (micke@hallendal.net)
 * @version $Id: ServerConnection.java,v 1.2 2000/08/01 23:51:40 hallski Exp $
 */

public class ServerConnection 
extends Thread
{

  /*************
   * Variables *
   *************/

  private int            sPort;
  private String         sHost;
  private Socket         sSocket;
  private PrintWriter    serverOut;
  private BufferedReader serverIn;

  
  // TEMP
  
  private Main program;

  /****************
   * Constructors *
   ****************/
  public ServerConnection(String sHost, int sPort, Main program)
    {
      this.sPort = sPort;
      this.sHost = sHost;
      this.program = program;
      
      try {
        sSocket = new Socket(sHost, sPort);
        serverOut = new PrintWriter(sSocket.getOutputStream(), true);
        serverIn = new BufferedReader(new InputStreamReader(sSocket.getInputStream()));
      }
      catch (IOException ioE){
        System.err.println("IOERROR server.ServerConnection: \n"+ioE.getMessage());
      }
    }

  /***********
   * Methods *
   ***********/

  public void run()
  {
    String s;
    try {
      while (!(s = serverIn.readLine()).equals("quit")) {
        this.processIncoming(s);
      }
    } catch (IOException ioE){
      System.err.println("IOERROR server.ServerConnection: \n"+ioE.getMessage());
    }
  }

  private void processIncoming(String s)
    {
      if (s.indexOf("INC CALL:") >= 0) {
        String number = this.getNumber(s);
        int phone = this.getPhone(s);
        String name = this.getName (s);

        program.incCall(phone, number, name);
      }
      else if (s.indexOf("OFFHOOK:") >= 0) {
        //       int phone = this.getPhone(s);
        //       gui.offHook(phone);
      }
      else if (s.indexOf("ONHOOK:") >= 0) {
        //       int phone = this.getPhone(s);
        //       gui.onHook(phone);
      }
    }
  
  private int getPhone(String s)
  {
    // PHONE[1]
    int index1, index2;
    index1 = s.indexOf("PHONE[") + 6;
    index2 = s.indexOf("]", index1);
    int phone;
    try {
      phone = Integer.parseInt(s.substring(index1, index2));
    }
    catch (NumberFormatException nfE){
      phone = 0;
    }
    return phone;
  }
  
  private String getNumber(String s)
  {
    // NUMBER[XX-XXXXXXXX]
    int index1, index2;
    index1 = s.indexOf("NUMBER[") + 7;
    index2 = s.indexOf("]", index1);
    String number;
    number = s.substring(index1, index2);
    if (number.equals("")) {
      return "Unknown";
    }
    return number;
  }

  private String getName(String s)
  {
    // NAME[XXXXXX XXXXXXXX]
    int index1, index2;
    index1 = s.indexOf("NAME[") + 5;
    index2 = s.indexOf("]", index1);
    String number;
    number = s.substring(index1, index2);
    if (number.equals("")) {
      return "Unknown";
    }
    return number;
  }
} // End of ServerConnection 

