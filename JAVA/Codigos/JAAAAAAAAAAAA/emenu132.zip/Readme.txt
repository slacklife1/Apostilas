============================
Expandable Menu Applet v1.32
============================

This archive contains:
 -ExpandMenu.exe (Menu designer program file)
 -ExpandMenu.class (main class file)
 -TreeNode.class (helper class file)

Use "ExpandMenu.exe" to design your menu.

The applet requires both class files to run.

Run "ExpandMenu.html" to watch a demo.

Make sure the 2 class files are in the same directory
as the HTML document that contains the reference
to the applet. If you want to place the class
files in another directory, you must make a direct
reference to this directory in your <applet> tag.

For example, if you place the class files in a 
directory called "applets", then your HTML document
should make the following reference:

<applet code="applets/ExpandMenu.class" width=300 height=400>

(height and width are arbitrary but necessary)



What is Expandable Menu Applet all about?
=========================================

It is a Java applet that adds an expandable menu to your 
homepage. The menu consists of two types of nodes:
 -parent nodes
 -child nodes

Parent nodes can contain child nodes and if they do, they
have the ability to expand and collapse upon the user's
mouse click. Child nodes respond to user clicks by opening
an HTML document in a target frame in the browser. Parent
nodes act as child nodes if they do not have children.


Cool Site Navigation System
===========================

Expandable Menu applet allows you to create a cool site 
navigation system that allows visitors to your web site 
to move to areas of interest quickly without having to 
surf page by page and follow many links. Of course the 
site design is entirely up to you but this applet gives 
visitors a quick overview of the site.


Target Frames and Source
========================

For each node that you want to act as a link, you have to
specify the associated target frame and source document you
want to open in that frame. The name of the frame is the same
as the name defined in the HTNL document that displays the
frames. Here's an example:

<frameset cols="30%,*">
 <frame name="leftframe" src="appletdoc.html">
 <frame name="rightframe" src="empty.html">
</frameset>

The HTML code above splits the browser window into two frames,
"leftframe" and "rightframe", and their relative widths are
30% and 70% respectively. "appletdoc" is the document containing
the ExpandableMenu applet reference. 

Initially "appletdoc.html" will be loaded in "leftframe" and 
"empty.html" in "rightframe". If you want one of the nodes to 
open a document "sample.html" in "rightframe", you need to type 
"rightframe" in the node's TARGET FRAME field and "sample.html" 
in the SOURCE URL field.

Note that the SOURCE URL field accepts absolute or relative URLs.
So you can either type "sample.html" or "http://hostname/sample.html"


The Menu Designer
=======================

The Menu Designer generates all the HTML code required for the
applet to run. Instead of inserting parameters yourself, the 
designer does all the work for you. All you have to do is fill
in the necessary information such as the background color, node
color, node captions, and bullet types. Once the code is compiled,
you can copy it to the clipboard and paste it into the HTML document
you want to hold the applet in.


============================================================
What's New
============================================================

Expandable Menu Applet now allows you to insert a background image 
inside the applet window.

Version 1.32 also accepts relative URLs in the  SOURCE URL field 
under NODE PROPERTIES. So instead of having to type "http://hostname/ 
sample.html", you now only have to type "sample.html" assuming your 
applet is in the same directory.

Version 1.32 has new features that display active menu items 
in 3D. There are two types of 3D effects:
 -3D button
 -3D text

 3D button
 =========
 This effect causes active nodes to appear as 3D buttons.
 There are no settings for this effect.

 3D Text
 =======
 This effect causes the active node's text to be displayed 
 in 3D. Parameters for the 3D efects:

  bevelheight
  -----------
  The degree of protrusion of the 3D text.

  beveldirection
  --------------
  Determines the direction of protrusion.
  "0" - 3D text shears to the left
  "1" - 3D text shears to the right

  bevelcolordifference
  --------------------
  This indicates how much darker is the side of the 3D text 
  compared to the front of the text. Measured in shades of gray. 
  For example, if the active node color is RGB(100,200,100), a 
  bevelcolordifference of 30 would cause the side of the 3D text 
  to be RGB(70,170,70) while the front of the text will still 
  be RGB(100,200,100).


============================================================
Note
============================================================
Netscape Navigator 4.0 and IE 4.0 and above may not be able 
to view the demo files on disk due to the Java security console. 
The best way to overcome this is to use Navigator 3.0 or 
Sun's appletviewer for previewing. Another way is to upload 
the files onto the server and view the files directly.


============================================================
Known Problems
============================================================
If your applet doesn't run, it may be due to:
-you have not inserted any menu items
-java security violation (see note above)


============================================================

Bug reports
===========
If you have a bug to report or any comments or questions, 
please forward your messages to the following e-mail 
addresses:
isc70450@leonis.nus.sg
cfc123@tm.net.my



 