/***************************************************************************
    Copyright          : (C) 2002 by Neoworks Limited. All rights reserved
    URL                : http://www.neoworks.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/*
 * JukeXExpressionHelper.java
 *
 * Created on 19 April 2002, 14:09
 */

package com.neoworks.jukex.query;

import java.util.List;
import java.util.LinkedList;

/**
 * Holds all the metadata used to make a pass through the expression making SQL.
 *
 * Do not reuse these objects as they are altered by the SQL construction process.
 *
 * @author Nick Vincent (<a href="mailto:nick@neoworks.com">nick@neoworks.com</a>)
 */
public class JukeXExpressionHelper
{
	/**
	 * Public constructor
	 */
	public JukeXExpressionHelper()
	{ }
}
