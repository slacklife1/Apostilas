/***************************************************************************
    Copyright          : (C) 2002 by Neoworks Limited. All rights reserved
    URL                : http://www.neoworks.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/*
 * DatabaseObject.java
 *
 * Created on 28 March 2002, 17:09
 */

package com.neoworks.jukex;
import java.io.Serializable;

/**
 * Interface for classes that may be stored in a database.
 *
 * @author Nick Vincent (<a href="mailto:nick@neoworks.com">nick@neoworks.com</a>)
 */
public interface DatabaseObject extends Serializable
{
	/**
	 * Return the database ID of this object
	 * 
	 * @return The database ID of this object
	 */
	public long getId();
}
