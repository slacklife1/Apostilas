/***************************************************************************
    Copyright          : (C) 2002 by Neoworks Limited. All rights reserved
    URL                : http://www.neoworks.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/*
 * TrackStoreFactory.java
 *
 * Created on 10 April 2002, 15:46
 */

package com.neoworks.jukex;

import com.neoworks.jukex.sqlimpl.JukeXTrackStore;

/**
 * The TrackStoreFactory manages access to insatnces of the TrackStore.
 *
 * @author Nick Vincent (<a href="mailto:nick@neoworks.com">nick@neoworks.com</a>)
 */
public class TrackStoreFactory
{
	/** 
	 * Public constructor
	 */
	private TrackStoreFactory()
	{
	}

	/**
	 * Get an instance of the TrackStore
	 * 
	 * @return An instance of the TrackStore
	 */
	public static TrackStore getTrackStore()
	{
		return JukeXTrackStore.getInstance();
	}
}
