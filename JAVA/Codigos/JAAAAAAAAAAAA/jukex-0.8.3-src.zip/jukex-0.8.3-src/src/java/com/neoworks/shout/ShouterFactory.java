/***************************************************************************
    Copyright          : (C) 2002 by Neoworks Limited. All rights reserved
    URL                : http://www.neoworks.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

package com.neoworks.shout;

/**
 * Factory class for Shouter instances
 *
 * @author Nigel Atkinson (<a href="mailto:nigel@neoworks.com">nigel@neoworks.com</a>)
 */
public class ShouterFactory
{
	private static Shouter instance;

	/**
	 * Static initialiser
	 */
	static
	{
		instance = new Shouter();
	}

	/**
	 * Get the Shouter instance
	 *
	 * @return The Shouter
	 */
	public static Shouter getShouter()
	{
		return instance;
	}
}
