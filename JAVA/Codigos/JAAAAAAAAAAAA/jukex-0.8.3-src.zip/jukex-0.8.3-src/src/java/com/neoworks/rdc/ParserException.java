/***************************************************************************
    Copyright          : (C) 2002 by Neoworks Limited. All rights reserved
    URL                : http://www.neoworks.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

package com.neoworks.rdc;



/**
 * This class represents exceptions which have occured while
 * parsing something. Basicaly done so that we can use the
 * strong type checking.
 */
public class ParserException extends Exception
{
  /**
   * Make a new parser exception object with the given string.
   *
   * @param str The error string to display
   */
  public ParserException(String str)
  {
    super(str);
  }

}