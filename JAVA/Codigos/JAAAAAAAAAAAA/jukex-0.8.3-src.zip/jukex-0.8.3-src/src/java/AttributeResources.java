/***************************************************************************
    Copyright          : (C) 2002 by Neoworks Limited. All rights reserved
    URL                : http://www.neoworks.com
 ***************************************************************************/
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

import java.util.ListResourceBundle;

public class AttributeResources extends ListResourceBundle
{
	static final Object [][] contents = {
		{"Artist", "Artist"},
		{"Album", "Album"},
		{"Title", "Title"},
		{"TrackNumber", "Track Number"},
		{"Genre", "Genre"},
		{"Played", "Played"},
		{"Bitrate", "Bit rate"},
		{"VBR", "VBR"},
		{"SampleRate", "Sample rate"},
		{"Length", "Length in frames"},
		{"Duration", "Duration in seconds"},
		{"borken", "Broken"}
	};

	public Object[][] getContents()
	{
		return contents;
	}
}
