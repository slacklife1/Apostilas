DS CubeMap v1.0
by Dario Sciacca
dario@dseffects.com
http://www.dseffects.com

Description

This applet can map any image over a cube.
Over the animation you can also insert an image and a scroll-text.
The applet is interactive and includes a HTML code generator that allows 
to change parameters without any knowledge of Java and HTML programming.
You can use freely the applet to enhance your web pages.
If you want to remove the credits message and enable additional
parameters you can register all the DS Applets for $20.

Registration

With $20 (US dollars) you can receive the registration key for a 
specified URL domain name, for example www.dseffects.com.
You must provide the URL name and you will receive the registration key
via e-mail. The registration key must be inserted in the regkey
parameter and it unlocks all the applets for registered URL domain name.
The applets will run on all the pages of the site and the new applets that
will be released in future will work too with the registration key you buy now.
Registered applets don't display the credits message and have enabled
additional parameters.
For registration instructions please go to: http://www.dseffects.com

Copyright

All copyrights to this software are exclusively owned by the author
- Dario Sciacca. You may not use, copy, emulate, clone, rent, lease,
sell, modify, decompile, disassemble, otherwise reverse engineer, or
transfer the licensed program, or any subset of the licensed program,
except as provided for in this agreement. Any such unauthorized
use shall result in immediate and automatic termination of this
license and may result in criminal and/or civil prosecution. All
rights not expressly granted in this license are reserved by the
author.

Redistribution

You can include this software on CD-ROMS or shareware collections
and shareware sites, but only if you leave the archive unchanged.
However I would like to be notified about the redistribution by
email to dario@dseffects.com if possible.

Warranty and limitation of liability

This software is provided "AS IS" without warranty of any kind.
Dario Sciacca is not liable for the any damages caused by the use,
misuse, or abuse of this software.
