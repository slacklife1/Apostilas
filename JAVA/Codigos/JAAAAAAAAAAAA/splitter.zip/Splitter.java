/* 
	Author   : Ganesh.K.V.
	Contacts : ganesh_82in@yahoo.com

*/
import java.io.RandomAccessFile;
import java.io.File;

public class Splitter
{
	public static void main(String args[])
	{
		//Checking the presents of argument.
		if(args.length==0)
		{
			System.out.println("Type -h for getting help on this splitter");
		}
		else if (args.length==1)
		{
			//if the paramenter is -h, the system displays the syntax for using this utility.
			if(args[0].equals("-h"))
			{
				System.out.println("-----------------------------------");
				System.out.println("Splitting.....");
				System.out.println("                  java Splitter -s <filepath> <Split file size in bytes>");
				System.out.println("-----------------------------------");
				System.out.println("Joining.....");
				System.out.println("                  java Splitter -j <filepath>");
				System.out.println("-----------------------------------");
			}
			// Displaying the error if parameter required are not given.
			else if(args[0].equals("-s") || args[0].equals("-j"))
			{
				System.out.println("Parameters missing, type -h for help.....");
			}
		}
		//if the parameter is -s then splitting of file happens.
		else if(args[0].equals("-s"))
		{
			if(args.length==3)
			{
				String FilePath="";
				FilePath=args[1];
				File filename=new File(FilePath);
				int splitFileSize=0;
				if(filename.exists())
				{
					try
					{
						splitFileSize=Integer.parseInt(args[2]);
						Splitter spObj=new Splitter();
						spObj.split(FilePath,splitFileSize);
						spObj=null;
					}
					catch(Exception e)
					{
						e.printStackTrace();
					}
				}
				else
				{
					System.out.println("File Not Found....");
				}
				filename=null;
				FilePath=null;
			}
			else
			{
				System.out.println("Parameters missing, type -h for help.....");
			}
		}
		//if the parameter is -s then joining of file happens.
		else if(args[0].equals("-j"))
		{
			String FilePath="";
			FilePath=args[1];
			File filename=new File(FilePath.trim());
			if(filename.exists())
			{
				FilePath=FilePath.substring(0,FilePath.length()-4);
				filename=new File(FilePath);
				if(filename.exists())
				{
					System.out.println("\""+ FilePath+ "\" File Already Exist....");
				}
				else
				{
					Splitter spObj=new Splitter();
					spObj.join(FilePath);
					spObj=null;
				}
			}
			else
			{
				System.out.println(FilePath+filename);
				System.out.println("File Not Found....");
			}
			filename=null;
			FilePath=null;
		}
		System.out.println();
		System.out.println();
		System.out.println("-------------------Coded By GANESH.K.V.-------------------");
	}

	public void join(String FilePath)
	{
		long leninfile=0,leng=0;
		int count=1,data=0;
		try
		{
			File filename=new File(FilePath);
			RandomAccessFile outfile = new RandomAccessFile(filename,"rw");
			while(true)
			{
				filename=new File(FilePath + count + ".sp");
				if (filename.exists())
				{
					RandomAccessFile infile = new RandomAccessFile(filename,"r");
					data=infile.read();
					while(data!=-1)
					{
						outfile.write(data);
						data=infile.read();
					}
					leng++;
					infile.close();
					count++;
				}
				else
				{
					break;
				}
			}
			outfile.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void split(String FilePath,int splitlen)
	{
		long leninfile=0,leng=0;
		int count=1,data;
		try
		{
			File filename=new File(FilePath);
			RandomAccessFile infile = new RandomAccessFile(filename,"r");
			data=infile.read();
			while(data!=-1)
			{
				filename=new File(FilePath + count + ".sp");
				RandomAccessFile outfile = new RandomAccessFile(filename,"rw");
				while( data!=-1 && leng<splitlen)
				{
					outfile.write(data);
					leng++;
					data=infile.read();
				}
				leninfile+=leng;
				leng=0;
				outfile.close();
				count++;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}