This is a small code for splitting and joining a file.

Syntax:

Splitting.....

java Splitter -s <filepath> <Split file size in bytes>


Joining.....

java Splitter -j <filepath>"
