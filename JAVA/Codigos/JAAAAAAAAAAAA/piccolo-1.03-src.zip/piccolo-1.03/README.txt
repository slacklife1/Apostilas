-------------------------------------------------------------------------
Piccolo XML Parser for Java
Version 1.03, released June 12, 2002
http://piccolo.sourceforge.net/

Please report bugs to yuval@bluecast.com. Thank you.

(C) Copyright 2002 by Yuval Oren. All rights reserved.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
-------------------------------------------------------------------------

Piccolo now supports the following specifications:

* SAX 1
* SAX 2 extensions 1.0
* JAXP 1.1 (SAX parsing only)

Note that, per the specifications, namespace handling is turned on by default
with SAX2; when using JAXP, namespace handling is off by default. Turning off
namespace handling will provide a performance gain.

Piccolo requires Java 1.2 or higher.

For usage information, please see the usage documentation available at
http://piccolo.sourceforge.net/using.html .

-------------------------------------------------------------------------
CHANGES from version 1.02:
-------------------------------------------------------------------------
This is a maintenance release, correcting the following bugs:

* Turning string interning off would throw the wrong exception
* The ValidatingSAXParserFactory property could not be specified in 
  jaxp.properties
* setLocale() did not throw an exception when set to non-English
* Setting the default namespace within an element already declaring
  a default namespace would cause errors.

-------------------------------------------------------------------------
CHANGES from version 1.01:
-------------------------------------------------------------------------
This is a maintenance release, correcting bugs mostly related to 
error handling:

* If an EntityResolver is registered, it is now correctly called.
* ContentHandler.skippedEntity() is no longer called within attribute values.
* ContentHandler.endDocument() is now called when a fatal error occurs.
* If an error handler is not registered, fatal errors will throw 
  a SAXParseException.
* LexicalHandler.startEntity() is called before the entity is resolved.
* A bug that caused root-level attributes to be ignored sometimes was fixed.
* Very large CDATA sections are now handled efficiently.
* Build and packaging scripts have been enhanced.


-------------------------------------------------------------------------
CHANGES from version 1.0:
-------------------------------------------------------------------------
* A bug causing parsing of "Reader" input sources to fail was fixed.

-------------------------------------------------------------------------
CHANGES from version 0.5:
-------------------------------------------------------------------------

* Detects many more conformance errors
* Namespace processing is faster
* Now supports SAX2 extensions and JAXP
* Bug fixes


