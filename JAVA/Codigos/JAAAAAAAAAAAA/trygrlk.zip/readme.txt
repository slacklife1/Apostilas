*********************************************************************
*                       GridLock 2.0                                *
*                                                                   *
*                EVALUATION COPY - TRIALWARE(UNREGISTERED)          *
*                                                                   *
*********************************************************************

LATEST : GridLock Keypad is also included in this package.
	 Upzip the file "grlkkey.zip" into ANOTHER directory so
	 as not to confuse the readme.txt and login.htm files 
 	 intended for the GridLock Keypad with the GridLock Text.

You can read the QUICK START Guide (quicksta.txt) first if you wish
to quickly set up the program on your site.
	 

It is advisable to read through the entire readme 
file to get a better understanding on how GridLock works.

All instructions contained herein are relevant only to the Gridlock
text version. 

IMPORTANT : MUST READ
            This copy of GridLock is for evaluation purposes ONLY.
            End-users would be able to test out the primary functions of
            this password program.
            However, there are a few features not found in this evaluation
            copy but are present in the registered copy. They are,

            i) An Encryption Facility 
(AN ABSOLUTE NECCESSITY TO ENSURE A SECURE WAY OF TRANSMITTING PASSWORD
 INFORMATION. WHAT IS THE USE OF A PASSWORD PROGRAM WITHOUT ENCRYPTION)

           ii) Limitless usernames' data. 
(THIS EVALUATION COPY ONLY ALLOWS YOU TO READ A MAXIMUM OF 2 USERNAMES 
 AND PASSWORDS)

          iii) No Label 
(THIS EVALUATION COPY CONTAINS THE TEXT "EVALUATION COPY, UNREGISTERED" 
 IN THE DISPLAY)

           iv) Customisable Background/Foreground color and font style and
               size, button and label text
(THIS EVALUATION COPY DOES NOT ALLOW THE CUSTOMISATION OF THE PRECEDENT 
 FEATURES)
            v) Display Format 
(THIS EVALUATION COPY DOES NOT ALLOW YOU TO DISPLAY THE PROTECTED PAGE IN 
 EITHER A NEW BROWSER WINDOW,SAME WINDOW etc..)

	   vi) Bookmark Prevention 
(THIS EVALUATION COPY DO NOT CONTAIN A SOLUTION THAT WILL PREVENT USERS 
 FROM ACCESSING YOUR PROTECTED PAGE DIRECTLY BY PRIOR BOOKMARKING OF YOUR 
 PROTECTED PAGE. WITH THE REGISTERED VERSION, THE ONLY WAY TO GET TO YOUR 
 PROTECTED PAGE WOULD BE TO LOGIN VIA GRIDLOCK!!!)

	  vii) Logging Facility 
(THIS EVALUATION COPY DOES NOT ALLOW YOU TO LOG THOSE VALID ACCESSES BY USERS
 TO YOUR PROTECTED PAGE)
	
	 viii) Expiration Facility
(THIS EVALUATION COPY DOES NOT ALLOW YOU TO SPECIFY THE EXPIRATION DATE
 FOR EACH USER RECORD)


TO PURCHASE THE REGISTERED VERSION :
Visit "http://web.singnet.com.sg/~chrissam/multi.htm" to purchase via
credit card,cash or check.

All registered version comes complete with GridLock Text and GridLock Keypad
as well as a FREE GridLock UserManager program, to make your editing
and maintaining of the password file effortless!!

REGISTERED COPY WOULD BE ABLE TO CUSTOMISE THE NAME OF THE PASSWORD FILE.

Author/Programmer : Christopher Low T.S

Instructions :

1. Upload these files to your WWW directory on your WWW server which
   contains the page, eg "index.html", where the applet is to be displayed.
   - "password.class"
   - "okbutton.class"
   - "mytextfield.class"
   - "passframe.class"
   - "d1ata5e.txt" - the records of user/password file
   - "login.htm" - sample html file to load GridLock 2.0.

   When uploading using FTP, please ensure that you are using BINARY mode
   transfer for the class files (eg.password.class etc.) and ASCII mode
   transfer for "d1ata5e.txt" (the password file) and login.htm.

       If the applet is to be displayed in the file "index.html"
       located under the "public_html" WWW directory, then the above
       mentioned files - password.class and so on - should be copied to
       the "public_html" directory.

   A Frequently Asked Questions file ("faq.txt") is attached to the 
   archive to help you in any difficulties you may face.

2. Paste the following text onto the portion of your html file, 
   eg. "index.html", where you want to display the password 
   applet. CHANGE THE APPLET PARAMETERS WHERE APPLICABLE. A sample HTML file
   has been provided for you called "login.htm".
   
<!-- begin copy of GridLock Text Version to your html file-->
   <table border="4" cellpadding="0" cellspacing="0" width="40%">
   <tr><td align="center" width="100%"> 
   <applet code="password.class" width=120 height=32 align=center>                             
   <param name="invalidurl" value="http://yourhost/yourdir/error.htm">
   <param name="receiver" value="youremail@yourdomain.domain">
   <param name="max" value="4"> 
   <param name="max2" value="3">
   <param name="entrytext" value="Member Click Here!"> 
   <param name="invalidurl2" value="http://yourhost/yourdir/error.htm">
   <param name="invalidurl3" value="http://yourhost/yourdir/error.htm">
   <param name="popup" value="yes">
   <param name="gotoerror" value="1">
   </applet>    
   </td></tr></table>                                                                 
<!-- end copy of applet   -->


invalidurl : the absolute URL of the error page which would be displayed if
	     a user enters an invalid password. This would work only if the
	     parameter "gotoerror" has the value of "1".
	     Eg. Suppose you want to display an error page,"error.html", if the user enters an invalid
		 password i.e. a file not found in your base URL, then the invalidurl should be
		 "http://yourhost/yourdir/error.html". 
	     An error page can also be the page where the applet resides. In this case, the applet 
	     will just return the user to the same page when an invalid password
	     is typed.

gotoerror: States if you wish to load the error page as specified by
	   invalidurl when a wrong username or password could not be found.
	   "1" - Load the error page.
	   "0" - Just display the text "Login Failed" in the status display.

entrytext : The text that is displayed for the login button before GridLock
		pops up.

receiver : The email address where you would want to receive warning emails when a user
           tries to hack into your page more than a certain number of times as
           specified by the parameter "max".

           For a warning mail to be sent to you, your local host must support
           SMTP on port 25.

max : The maximum number of times a user can type in his password without a
      warning mail being sent to you. In this case, you suspect the user
      might be a hacker.


max2 : The maximum number of times a user can type in his password before a page
       is displayed to assist him. In this case, you suspect the user has forgotten his password.

invalidurl2 : The URL of the page which would be displayed after the user have
                attempted "max" number of times in logging in. This is different from the
              error page(invalidurl) which is shown after each wrong attempt.
              This is the page which would display warning to "hackers".

invalidurl3 : The URL of the page which would be displayed after the user have
                attempted "max2" number of times in logging in.
              This is the page which would be displayed to give assistance
              to the user in case he/she forgot his/her password.

              IMPORTANT : max2 < max

popup : State whether you wish to popup the password window or have it 
	embedded into your webpage.

	yes : POPUP version
 	no  : EMBEDDED version

	NOTE: Adjust the width and height of the applet accordingly with
	      the version in use.

************************************************************

  The instructions that follow below teaches you how to manually 
  edit the password file.

************************************************************


SETTING UP YOUR USER/PASSWORD FILE :
	This premium password applet reads in from the file with name
"d1ata5e.txt" for the list of usernames,passwords and links.

The format of the file is :
Username
User Password
User Link(in absolute URL)

Example : If you have a user "Peter" and would like to give him the password 
"qwerty" and point him to the page "http://www.yourcompany.com/yourdir/welcome.html"

then the file format is :
Peter  
qwerty
http://www.yourcompany.com/yourdir/welcome.html

This follows for multiple users.
Example: 
Peter
qwerty
http://www.yourcompany.com/yourdir/welcome.html
Jane
dfrts
http://www.yourcompany.com/yourdir/welcome.html

IMPORTANT : Make sure the there is no white space character after the
            values in each line else the program will not work properly.
            Example, supposing in your data file the following constitute a line
            Jane \t   ( a hidden tab character is present )
            Jane\s\s  ( 2 space character is present)

            To ensure that there is no white space character, hit return after
            finishing the entry for that line.
            Example,
            Jane(hit return)

            You can check to see if there is any white space character.
            place your cursor at the end of the line and press the right arrow
            key. if the cursor do not move to the next line, then a white space
            character is present. Press backspace to delete the white space character(s).
            Check again with your right arrow key.

The file data are NOT ENCRYPTED. This is present only in
this evaluation copy only. Non-encrypted data is dangerous as "seasoned"
hackers can just "obtain" the password file and find out the password
and the secret page URL.

ENCRYPTION PROVIDES A SECOND LINE OF DEFENCE.

Do not change the data filename else this program could not find the file.

NOTE: If your applet does not appear as normal, you may want to 
adjust the height and width of the applet accordingly.

TO PURCHASE THE REGISTERED VERSION :
Visit "http://web.singnet.com.sg/~chrissam/multi.htm" to purchase via
credit card,phone,cash or check.


******  LIMIED TECHNICAL HELP *********************

Any comments, suggestions or questions, please feel free to email 
to chrissam@mbox2.singnet.com.sg
