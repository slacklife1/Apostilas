Free for Java Developers of Java Swing Applets.
Needed: VB6 runtime file - MSVBVM60.DLL and Java PlugIn for your Browser.

Instead of typing or cutting and pasteing all the object plugin code, this little utility does it for you.

Creates an Html file that contains all the plug in code for your Java Swing Applet. Just set the applets height and width and where you what to place your html file. The default plugin version is 1.3 . 

All comments and suggestions are welcome.
spurkus@hotmail.com

Thank you and Enjoy!