/*

Date Started: September 16, 2005
Author: Josh Greig


*/
import gui.*;
import java.io.*; // FileOutputStream, PrintStream
import org.w3c.dom.*;


/** for editing an index page */
public class IndexPageEditor extends PDAEditor
{
  /** Purpose of the index page or documentation system */
  protected gui.TextManipulator Purpose;

  /** Links to the major documents */
  protected gui.HyperLinkList MajorDocs;

  /** Links to more information */
  protected gui.HyperLinkList MoreInformation;

   public IndexPageEditor(PDAApplication app)
   {
      super(app);
      DisableRestrictedOptions();

      MajorDocs = new gui.HyperLinkList();
      MoreInformation = new gui.HyperLinkList();
      Purpose = new gui.TextManipulator();

      pages.add("Purpose",Purpose);
      pages.add("More Information",MoreInformation);
      pages.add("Major Documents",MajorDocs);
   }

  /**
  Saves document to file
  */
  public void SaveToFile(File f) throws IOException
  {
      FileOutputStream F = new FileOutputStream(f);
      PrintStream ps = new PrintStream(F);

       ps.println("<?xml version=\"1.0\"?>");
       ps.println();
       ps.println("<?xml-stylesheet type=\"text/xsl\" href=\"index_to_html.xsl\"?>");
       ps.println();
       ps.println("<index>");
       // write purpose
       ps.println("  <purpose>");
       Purpose.WriteToStream(F);
       ps.println("  </purpose>");
       ps.println();
       // write top documents links
       ps.println("  <majortopics>");
       MajorDocs.WriteToStream(F);
       ps.println("  </majortopics>");
       ps.println();
       // write more information
       ps.println("  <moreinformation>");
       MoreInformation.WriteToStream(F);
       ps.println("  </moreinformation>");

       WriteQuickLinksToStream(F);
       ps.println();
       ps.println("</index>");
       F.close(); // close the stream
  }

  /** Loads document from XML structure */
  public void LoadFrom(Document d) throws IOException
  {
    NodeList PurposeL = d.getElementsByTagName("purpose");
    NodeList MajorTopicsL = d.getElementsByTagName("majortopics");
    NodeList MoreInformationL = d.getElementsByTagName("moreinformation");


    if (PurposeL.getLength()>0)
    {
      // load purpose
      Purpose.LoadFrom((Element)PurposeL.item(0));
    }

    if (MajorTopicsL.getLength()>0)
    {
      // load majortopics
      MajorDocs.LoadFrom((Element)MajorTopicsL.item(0));
    }

    if (MoreInformationL.getLength()>0)
    {
      MoreInformation.LoadFrom((Element)MoreInformationL.item(0));
      // load more information
    }
  }

  public String getShortTitle()
  {
     return "Index Page Editor";
  }
}
