/*

Date Started: September 16, 2005
Author: Josh Greig


*/
import gui.*; // DefinitionList
import java.io.*; // FileOutputStream, PrintStream
import javax.xml.parsers.*;
import org.w3c.dom.*; // Document


/** for editing an index page */
public class GlossaryEditor extends PDAEditor
{
 /** List of definitions */
 protected gui.DefinitionList definitions;

  public GlossaryEditor(PDAApplication app)
  {
      super(app);
      DisableRestrictedOptions();
      definitions = new gui.DefinitionList();

      pages.add("Definitions",definitions);
  }

  /**
  Saves document to file
  */
  public void SaveToFile(File f) throws IOException
  {
      FileOutputStream F = new FileOutputStream(f);
      PrintStream ps = new PrintStream(F);
       ps.println("<?xml version=\"1.0\"?>\n");
       ps.println();
       ps.println("<?xml-stylesheet type=\"text/xsl\" href=\"glossary_to_html.xsl\"?>");
       ps.println();
       ps.println("<glossary>");
       ps.println(" <definitions>");
        // write definitions

       definitions.WriteToStream(F);

       ps.println(" </definitions>");
       super.WriteQuickLinksToStream(F);
       ps.println();
       ps.println("</glossary>");

       F.close(); // close the stream/file so it can be opened again
  }


  /** Loads from XML structure */
  public void LoadFrom(Document d) throws IOException
  {
     NodeList DefinitionsL = d.getElementsByTagName("definitions"); 
      if (DefinitionsL==null) throw new IOException("null list of definition elements");      
      if (DefinitionsL.getLength()>0)
      {
        definitions.LoadFrom((Element)DefinitionsL.item(0));
         // load the definitions
      }
  }

  public String getShortTitle()
  {
     return "Glossary Page Editor";
  }

}
