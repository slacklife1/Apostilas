import gui.*;
import javax.swing.*; // JOptionPane
import java.io.*;
import org.w3c.dom.*; // Document


/** for editing process documents */

public class ProcessEditor extends PDAEditor
{
  /** Purpose of the process document */
  protected gui.TextManipulator Purpose;

  /** Method of the process */
  protected gui.MethodManipulator TheMethod;

  public ProcessEditor(PDAApplication app)
  {
      super(app);
      Purpose = new gui.TextManipulator();
      TheMethod = new gui.MethodManipulator();

      pages.add("Method",TheMethod);
      pages.add("Purpose",Purpose);
  }

  /** Prepares for working on a new document */
  public void StartNewDocument()
  {
    // may want to prompt the user if he or she wants to save changes

    // clear purpose
    Purpose.Clear();

    // clear quick links, reset file name...
    super.Clear();

    // clear method
    TheMethod.Clear();
    
  }

  /**
  Saves document to file
  */
  public void SaveToFile(File f) throws IOException
  {
      FileOutputStream F = new FileOutputStream(f);
      PrintStream ps = new PrintStream(F);
       ps.println("<?xml version=\"1.0\"?>\n");
       ps.println("<?xml-stylesheet type=\"text/xsl\" href=\"pcs_to_html.xsl\"?>");
       ps.println("<process>");

       ps.println(" <purpose>");
       // write purpose
       Purpose.WriteToStream(F);
       ps.println(" </purpose>");

       // write method
       ps.println(" <method>");
       TheMethod.WriteToStream(F);
       ps.println(" </method>");


       // write more information


       WriteQuickLinksToStream(F);
       ps.println("\n</process>\n");
       F.close();
  }

  public void LoadFrom(Document d) throws IOException
  {
    // put code here
    Node n = d.getDocumentElement();
    NodeList purposelist = d.getElementsByTagName("purpose");
    NodeList methodlist = d.getElementsByTagName("method");  
  
      if (purposelist.getLength()!=1)
         throw new IOException("invalid # of purpose definitions");

      if (methodlist.getLength()!=1)
         throw new IOException("invalid # of method definitions");
   try
   {
    Element purpose = (Element)purposelist.item(0);
    Element method = (Element)methodlist.item(0);

      Purpose.LoadFrom(purpose);
      TheMethod.LoadFrom(method);
   }
   catch (Exception e)
   {
      System.err.println("ProcessEditor::LoadFrom: "+e);
   }
  }

  public String getShortTitle()
  {
     return "Process Editor";
  }
} // end class
