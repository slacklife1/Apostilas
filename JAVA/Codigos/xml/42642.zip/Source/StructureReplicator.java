/*

Some code from:
http://www.rgagnon.com/javadetails/java-0407.html

*/

import gui.*; // StringManipulator, ActiveButton
import javax.swing.*; // JFrame and gui components for the user interface
import java.awt.*; // Dimension, Container...
import java.awt.event.*; // ActionListener, ActionEvent...
import javax.xml.transform.*;
import java.net.*;
import java.io.*;

public class StructureReplicator 
{
 /** The application this is a part of(referred to for getting source and destination paths) */
 protected PDAApplication appl;

 /** A user interface for interacting with the replication features */
 protected StructureReplicatorGUI frame;

  /**
  Initializes this replicator to be part of app
  */
  public StructureReplicator(PDAApplication app)
  {
     appl = app;
     frame = new StructureReplicatorGUI(this,app.getInitSourcePath(),app.getInitDestinationPath());     
  }

 /**
 Transforms an XML document using contained XSL reference
 @param XMLPath is the path to the XML file being transformed. 
 @param DestinationPath is the path to store the resulting HTML file in.
 */
 public void TransformXML(String XMLPath, String DestinationPath) throws Exception
 {
  DestinationPath = 
    gui.FileNameManipulator.getFileNameWithExtention(DestinationPath,"html");
  DestinationPath =   DestinationPath.replace('/','\\');

  try 
  {
   String pathToXSL=getPathToXSL(XMLPath); // the path to the XSL file used in tranformation
      
   // get pathToXSL by loading file (XMLPath) and extracting the XSL reference
   
  // System.err.println(getOutputProperty());  

   // do the transformation
    TransformerFactory tFactory = 
      TransformerFactory.newInstance();

    Transformer transformer = 
      tFactory.newTransformer
         (new javax.xml.transform.stream.StreamSource
            (pathToXSL));

    transformer.transform
      (new javax.xml.transform.stream.StreamSource
            (XMLPath),
       new javax.xml.transform.stream.StreamResult
            ( new FileOutputStream(DestinationPath)));
    }
    catch (Exception e) 
    {
      System.err.println("StructureReplicator::TransformXML: "+e);
      throw e;
    }
  }

  /**
   Returns path to the XSL file referred to by the file at XMLPath
  */
  private String getPathToXSL(String XMLPath)
  {
     // get XSL file referred to from xml-stylesheet tag in the xml file
     String nm = gui.FileNameManipulator.getFileName(XMLPath);
     
     if (nm.equalsIgnoreCase("index.xml"))
        return appl.getInitSourcePath()+"/index_to_html.xsl";
        
     if (nm.equalsIgnoreCase("glossary.xml"))
        return appl.getInitSourcePath()+"/glossary_to_html.xsl";
     
     return appl.getInitSourcePath()+"/pcs_to_html.xsl";
  }
  
  /**
  Loops through entire folder tree and copies all files over except XML and XSL files.
  XML files are transformed using the internally referenced XSL file.
  @param source is the path to the source folder
  @param destination is the path to the destination folder
  */
  public void ReplicateFolderToFolder(String source, String destination) throws Exception
  {
    try
    {
     { // start scope for DestinationFolder
      File DestinationFolder = new File(destination);
       if (! DestinationFolder.exists()) // if destination folder doesn't exist
          if (! DestinationFolder.mkdir()) // create it, but if attempt failed,
          {    // throw exception
             System.err.println("Failed to create destination folder("+destination+")");
             throw new Exception("Unable to create folder: "+destination);
          }
     }

     File dirFile = new File(source);
     File pathFiles[]  = dirFile.listFiles();
        // get array containing all files in this source directory
  
     // loop through files in this folder
     for (int i=0;i<pathFiles.length;i++)
     {
       File curFile = pathFiles[i];

         // check file type and file extention.

         // if file folder found, ReplicateFolderToFolder on that subfolder to the subfolder of the result
         if (curFile.isDirectory())
         {
           System.err.println("file is a directory");
           String subfoldername = gui.FileNameManipulator.getSubfolderFileName(destination,curFile);
            // create destination subfolder
           File subFolder = new File(subfoldername);

            if (! subFolder.exists()) // if folder does not already exist
            {
               if (subFolder.mkdir()==false) // if unable to create subdirectory
               {
                 System.err.println("Unable to create subfolder("+subfoldername+") in destination directory");
                 throw new Exception("Create subdirectory("+subfoldername+") failed");
               } 
            }
              
            // replicate subfolder
            ReplicateFolderToFolder(curFile.getName(), subfoldername);
         }
         else
         {
           // if xsl, do nothing.
           if (gui.FileNameManipulator.EqualExtention(curFile,"xsl") ||
              gui.FileNameManipulator.EqualExtention(curFile,"xslt"))
           {  }
           else if (gui.FileNameManipulator.EqualExtention(curFile,"xml"))
           {
             // if xml, call TransformXML specifying the destination path
             TransformXML(curFile.getPath(),gui.FileNameManipulator.getDestinationFileName(curFile,destination));
           }
           else // if any other file, simply copy it over to destination folder.
           {
            File DestinationFile = new File(gui.FileNameManipulator.getSubfolderFileName(destination,curFile));
              // copy file to destination directory

              gui.MiscUtils.CopyFile(curFile,DestinationFile);
           }

         } // end if-else curFile is a directory

     } // end for-loop through files
   }
   catch (Exception E)
   {
      if (appl.getPrintStackTracesForExceptions())
         E.printStackTrace();
      System.err.println("StructureReplicator::ReplicateFolderToFolder: "+E);
      throw E;
   }
  }

  /** Shows or hides the frame corresponding to this replicator */
  public void setVisible(boolean visible)
  {
     frame.setVisible(visible);
  }


} // end class StructureReplicator

/**
A Graphical User Interface for interacting with the replication features
*/
class StructureReplicatorGUI extends JFrame implements ActionListener
{
 /** The StructureReplicator this is a part of */
 protected StructureReplicator SR;

 /** panel for selecting Source and Destination */
 protected StructureReplicatorInputsPanel panel;

 /** Replication button */
 protected JButton ReplicateBtn; 

 /** Get Help on Document replication */
 protected JButton HelpBtn;

  public StructureReplicatorGUI(StructureReplicator SR, String source, String destination)
  {
    super("Documentation System Replication");
   
    this.SR = SR;

    ReplicateBtn = new gui.ActiveButton("Replicate");
    HelpBtn = new gui.ActiveButton("Help");
    panel = new StructureReplicatorInputsPanel(source,destination);    
        
    setResizable(false); // make it so no one can resize this frame
    
    addComponents();
    addListeners();
    UpdateDisplay();
    
    setSize(500,170);
    
    // centre the frame
    Dimension scrn = getToolkit().getScreenSize();
     setBounds( (scrn.width-getWidth())/2, (scrn.height-getHeight())/2, getWidth(), getHeight() );

  }

  /** Adds components to the frame */
  private void addComponents()
  {
    Container c = this.getContentPane();
     c.setLayout(null);
     c.add(panel);
     c.add(ReplicateBtn);
     c.add(HelpBtn);
  }

  /** Adds required listeners(ActionListener...) */
  protected void addListeners()
  {
    ReplicateBtn.addActionListener(this);
    HelpBtn.addActionListener(
       new ActionListener()
       {
         public void actionPerformed(ActionEvent AE)
         {
            gui.MiscUtils.ViewDocument(SR.appl.getHelpPath()+"/Document Replication.html");
         }
       }
     );
  }

  /** Updates positioning of all */
  public void UpdateDisplay()
  {
     panel.setBounds(5,5,485,90);
     ReplicateBtn.setBounds(5,100,414,35);
     HelpBtn.setBounds(422,100,68,35);

     repaint();
  }
  
  /** Called when the replicate button is clicked */
  public void actionPerformed(ActionEvent AE)
  {
    try
    {
      SR.ReplicateFolderToFolder(panel.SourcePathField.getText(),panel.DestinationPathField.getText());
    }
    catch (Exception e)
    {
      if (SR.appl.getPrintStackTracesForExceptions())
         e.printStackTrace();

      JOptionPane.showMessageDialog(null,"There was a problem while trying to replicate.  "
       +"Please check the console for more information.");
    }
  }

} // end class StructureReplicatorGUI

/** class for the input source and destination */
class StructureReplicatorInputsPanel extends JPanel
{
 /** Stores the source path */
 protected  JTextField SourcePathField;
 
 /** Label for Source */
 protected JLabel SourceLBL;
 
 /** Stores the destination path */
 protected JTextField DestinationPathField;

 /** Label for Source */
 protected JLabel DestinationLBL;

 /** Select Source button */
 protected JButton SourceBtn;
 
 /** Select Destination button */
 protected JButton DestinationBtn;

 /** For selecting source */
 protected JFileChooser SourceChooser;

 /** For selecting destination */
 protected JFileChooser DestinationChooser;

  public StructureReplicatorInputsPanel(String initSource, String initDestination)
  {
    CreateComponents(initSource,initDestination);
    addComponents();
    addListeners();
  }
  
  /** Creates the components for this */
  private void CreateComponents(String source, String destination)
  {
    SourceChooser = new JFileChooser(source);
    SourceChooser.setFileFilter(new gui.DirectoryFilter());
    SourceChooser.setDialogTitle("Select Source Directory");
    DestinationChooser = new JFileChooser(destination);
    DestinationChooser.setFileFilter(new gui.DirectoryFilter());
    DestinationChooser.setDialogTitle("Select Destination Directory");

    SourceLBL = new JLabel("Source");
    SourcePathField = new JTextField(source);
    SourceBtn = new gui.ActiveButton("Select");
     
    DestinationLBL = new JLabel("Destination");
    DestinationPathField = new JTextField(destination);  
    DestinationBtn = new gui.ActiveButton("Select");  
  }
  
  /** Adds components to this panel */
  private void addComponents()
  {
     add(SourceLBL);
     add(SourcePathField);
     add(SourceBtn);
     
     add(DestinationLBL);
     add(DestinationPathField);
     add(DestinationBtn);

  }
 
  /** Adds required listeners */
  private void addListeners()
  {
     SourceBtn.addActionListener(
        new ActionListener()
        {
          public void actionPerformed(ActionEvent AE)
          {
             // code executed when Source button is clicked
              int option = SourceChooser.showOpenDialog(null);
              if (option==JFileChooser.APPROVE_OPTION) 
              {
                 SourcePathField.setText(SourceChooser.getSelectedFile().getPath());
              }
          }
        }
      );
      
     DestinationBtn.addActionListener(
        new ActionListener()
        {
          public void actionPerformed(ActionEvent AE)
          {
              // code executed when Destination button is clicked
              int option = DestinationChooser.showOpenDialog(null);
              if (option==JFileChooser.APPROVE_OPTION) 
              {
                 DestinationPathField.setText(DestinationChooser.getSelectedFile().getPath());
              }
          }
        }
      );
      
     addComponentListener(
       new ComponentAdapter()
       {
         public void componentResized(ComponentEvent CE)
         {
            UpdateDisplay();
         }
       }
      ); 
  }
 
  /** Updates locations and sizes of components */
  public void UpdateDisplay()
  {
    final int fieldleft = 70;
    final int border = 2;
    final int buttonwidth = 70;
    final int labelwidth = fieldleft-border;
    final int vmiddle = (getHeight()-border*2)/2;
    final int height1 = vmiddle-5;
    final int selectleft = getWidth()-buttonwidth; // left side of select buttons
    final int fieldwidth = selectleft-fieldleft-border;

     setLayout(null);
     SourceLBL.setBounds(0,0,labelwidth,height1);
     SourcePathField.setBounds(fieldleft,0,fieldwidth,height1);
     SourceBtn.setBounds(selectleft,0,buttonwidth,height1);
    
     DestinationLBL.setBounds(0,vmiddle+border,labelwidth,height1);
     DestinationPathField.setBounds(fieldleft,vmiddle+border,fieldwidth,height1);
     DestinationBtn.setBounds(selectleft,vmiddle+border,buttonwidth,height1);
  }

} // end class StructureReplicatorInputsPanel


