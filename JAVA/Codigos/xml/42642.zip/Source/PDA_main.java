/*
author: Josh Greig
*/


/**
Starts execution of the Process Document Assistant application
*/
public class PDA_main
{
 /** The method that starts everything */
 public static void main(String a[])
 {
    new PDAApplication();
 }

}