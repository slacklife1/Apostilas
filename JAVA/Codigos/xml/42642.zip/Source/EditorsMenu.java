/**
author: Josh Greig

*/

import javax.swing.*;
import javax.swing.JCheckBox;
import java.awt.event.*; // ActionListener..

/**
Lists all Editor tools open at any time and allows more to be opened.
*/
public class EditorsMenu extends JMenu
{
  protected static final int ProcessItm=0, IndexPageItm=1, GlossaryItm=2;
  protected JCheckBox Items[];
  protected PDAApplication parentApp;

   public EditorsMenu(PDAApplication parentAp)
   {
     super("Editors");

     this.parentApp = parentAp;
     Items = new JCheckBox[PDAApplication.NUMEDITORS];
     Items[ProcessItm] = new JCheckBox("Process Page");
     Items[IndexPageItm] = new JCheckBox("Index Page");
     Items[GlossaryItm] = new JCheckBox("Glossary");

     Items[ProcessItm].addActionListener(
        new ActionListener()
        {
           public void actionPerformed(ActionEvent a)
           {
              parentApp.setProcessVisible(Items[ProcessItm].isSelected());
               
           }
        }
       );

      Items[IndexPageItm].addActionListener(
        new ActionListener()
        {
           public void actionPerformed(ActionEvent a)
           {
              parentApp.setIndexPageVisible(Items[IndexPageItm].isSelected());

           }
        }
       );

      Items[GlossaryItm].addActionListener(
        new ActionListener()
        {
           public void actionPerformed(ActionEvent a)
           {
              parentApp.setGlossaryVisible(Items[GlossaryItm].isSelected());
           }
        }
       );

     add(Items[ProcessItm]);
     add(Items[IndexPageItm]);
     add(Items[GlossaryItm]);
   } // end constructor

   
   public void UpdateSelections(boolean[] v)
   {
     for (int i=0;i<PDAApplication.NUMEDITORS;i++)
     {
        Items[i].setSelected(v[i]);
     }
   }

} // end class