/*

Date Started: September 15, 2005
Author: Josh Greig

*/

/**
Process Document Assistant Editor

Provides main GUI interface for user to edit documentation content

a superclass for all editing windows: IndexPageEditor, GlossaryEditor, ProcessEditor
*/
import gui.*;
import javax.swing.*; // JFrame...
import javax.swing.JMenuBar; 
import javax.swing.JTabbedPane;
import java.awt.*;
import java.awt.event.*;
import java.io.*; // FileOutputStream, PrintStream
import java.net.*; 

import org.w3c.dom.*; // Document
import org.xml.sax.SAXException;
import javax.xml.parsers.*;


public abstract class PDAEditor extends JFrame
{
  /** The application this is a part of */
  protected PDAApplication app;

  /** Menu for this editor */
  protected JMenuBar menu;

  /** File Menu */
  protected FileMenu FileMenu1;

  /** Editors Menu */
  protected EditorsMenu EditorsMenu1;

  /** Help Menu */
  protected HelpMenu HelpMenu1;

  /** For selecting files to open or save to */
  protected JFileChooser fchooser;

  /** the Tabbed notebook */
  protected JTabbedPane pages;
  
  /** Currently open file */
  protected String OpenFileName=null;

  /** The list of quick links */
  protected gui.HyperLinkList QuickLinks;

  public PDAEditor(PDAApplication app)  
  {

     this.app = app;

     CreateObjects(); // create components...

     Container C = getContentPane();

     setJMenuBar(menu); // set the frame's menubar
     C.add(pages);

     addListeners();
     setSize(500,500);

    // centre the frame on the screen
    Dimension scrn = getToolkit().getScreenSize();
     setBounds( (scrn.width-getWidth())/2, 
      (scrn.height-getHeight())/2-30, getWidth(), getHeight() );

     UpdateTitle();

  }

  /** Creates objects for this PDAEditor */
  private void CreateObjects()
  {
     menu = new JMenuBar();
     FileMenu1 = new FileMenu(this);
     EditorsMenu1 = new EditorsMenu(app);
     HelpMenu1 = new HelpMenu(app);

     // add menus to the menu bar
     menu.add(FileMenu1);
     menu.add(EditorsMenu1);
     menu.add(HelpMenu1);

     fchooser = new JFileChooser(app.getInitSourcePath());
     // get initial path from app object
     fchooser.setFileFilter(new gui.XMLFileFilter());

     QuickLinks = new gui.HyperLinkList();

     pages = new JTabbedPane();
     pages.addTab("Quick Links",QuickLinks);
  }

  /** Adds required listeners for this Editor */
  private void addListeners()
  {
    addWindowListener(
      new WindowAdapter()
     {
        public void windowClosing(WindowEvent WE)
        {
          app.Hide(PDAEditor.this);
        }
     } // end class
    );

    // listen for when this editor is hidden
    addComponentListener(
     new ComponentAdapter()
     {
       public void componentHidden(ComponentEvent e) 
       {
          app.Hide(PDAEditor.this);
       }
     }
    );
  }

  /** 
  Updates the Editors menus so they indicate which windows are visible/invisible 
  */
  public void UpdateEditorsMenu(boolean[] v)
  {
     EditorsMenu1.UpdateSelections(v);
  }

  /**
    Loads from a file filling all tabs
  */
  public void OpenFile()
  {
    fchooser.setDialogTitle("Open "+getTitle());
    // use file chooser
    if (fchooser.showOpenDialog(this)==JFileChooser.APPROVE_OPTION)
    {
      try
      {
        File f = fchooser.getSelectedFile();
        LoadFrom(f);
        setOpenFileName(f.getPath());
      }
      catch (Exception e)
      {
         System.err.println("PDAEditor::OpenFile: exception caught");
         System.err.println(e);
         OpenFileName = null;
      }
    }
    else
       JOptionPane.showMessageDialog(null,
       "The file was not opened because you chose to cancel.");
  }

  protected void setOpenFileName(String fn)
  {
     OpenFileName = fn;	
  	 UpdateTitle();
  }

  /**
   Saves to a user selected file
   */
  public void SaveAsFile()
  {
     fchooser.setDialogTitle("Save As "+getTitle());

      // use file chooser
      if (fchooser.showSaveDialog(this)==JFileChooser.APPROVE_OPTION)
      {
       try
       {
         File f = fchooser.getSelectedFile();
          OpenFileName = gui.FileNameManipulator.getFileNameWithExtention
            (f.getPath(),"xml");
          SaveToFile(new File(OpenFileName));
          UpdateTitle(); // update title to show file
       }
       catch (IOException io)
       {
          OpenFileName = null; // indicate no specific file is open
          System.err.println(io);
          JOptionPane.showMessageDialog(null,"Unable to save file");
       }
      }
      else
       JOptionPane.showMessageDialog(null,
       "The file was not saved because you chose to cancel.");
  }

  /**
   Disables restricted options
   */
  public void DisableRestrictedOptions()
  {
  	 FileMenu1.DisableRestrictedOptions();
  }


  /**
   Saves to a file from all tabs
  */
  public void SaveFile()
  {
  	if (OpenFileName==null)
  	{
      SaveAsFile();
    }
    else // OpenFileName is set
    {
      try
      {
      
       File f = new File(OpenFileName);
        SaveToFile(f);
      }
      catch (IOException IOE)
      { 
        System.err.println("unable to save to: "+OpenFileName);
        OpenFileName = null;
        SaveFile(); // recusive call but now user selects file
      }
    }
  }

  /** Updates this Editor's title */
  public void UpdateTitle()
  {
  	String newTitle = ""; 
  	if (OpenFileName!=null)
       newTitle += gui.FileNameManipulator.getFileName(OpenFileName)+" - ";
  	
     newTitle += getShortTitle()+" - Process Document Assistant";
         
     setTitle(newTitle);
  }

  /**
   Writes the Quick Links to stream in an XML format
  */
  protected void WriteQuickLinksToStream(OutputStream stream)
  {
     PrintStream ps = new PrintStream(stream);

      ps.println(" <quicklinks>");
      QuickLinks.WriteToStream(stream);
      ps.println(" </quicklinks>");
  }

  /**
  Loads Quick Links
  */
  protected void LoadQuickLinksFrom(Document d)
  {
    NodeList nl = d.getElementsByTagName("quicklinks");
    if (nl!=null)
    {
      int len = nl.getLength(); 
      if (len>0)
      {
        Node n = nl.item(0);
        if (n instanceof Element)
          QuickLinks.LoadFrom((Element)n);
        else
          System.err.println(
          	"PDAEditor::LoadQuickLinksFrom found Node not to be an Element");
        if (len>1)
           System.err.println(
           	"PDAEditor::LoadQuickLinksFrom found more than 1 quicklinks node in xml file");
      } // end if len>0
      else
        System.err.println("PDAEditor::LoadQuickLinksFrom found no quicklinks");
    } // end if not null
    else
        System.err.println("PDAEditor::LoadQuickLinksFrom found null quicklinks");
  }
  
  protected void Clear()
  {
     setOpenFileName(null);
     QuickLinks.Clear();	
  }

  /** Saves all document to XML file */
  public abstract void SaveToFile(File f) throws IOException;

  /** Loads from a Document */
  public abstract void LoadFrom(Document d) throws IOException;

  /** Returns title for specific window ie. "Process Editor" */
  public abstract String getShortTitle();

  public void LoadFrom(File f) throws IOException
    , org.xml.sax.SAXException, javax.xml.parsers.ParserConfigurationException
  {
    if (f==null) return;

    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
      Document doc = null;
      DocumentBuilder builder = factory.newDocumentBuilder();
      doc = builder.parse( f);
      LoadFrom(doc);
      // load quicklinks
      LoadQuickLinksFrom(doc);
  }

  /** Identifies document type */
  public static int getDocumentType(File f,PDAApplication app)
  {
    boolean matched=true;

      // try loading as process
     try
     {
        (new ProcessEditor(app)).LoadFrom(f);  
     }
     catch(Exception e)
     {
       matched = false;
     }
     if (matched)
       return 0;

     matched = true;
      // try loading as process
     try
     {
        (new IndexPageEditor(app)).LoadFrom(f);  
     }
     catch (Exception e)
     {
       matched = false;
     }
     if (matched)
       return 1;

     matched = true;
      // try loading as process
     try
     {
        (new GlossaryEditor(app)).LoadFrom(f);  
     }
     catch(Exception e)
     {
       matched = false;
     }
   
     if (matched)
       return 2;

     return -1; // indicate no match found

  }

} // end class PDAEditor





