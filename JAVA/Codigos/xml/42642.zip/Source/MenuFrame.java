/**
author: Josh Greig
*/

import gui.*;
import javax.swing.*; // JButton, JPanel...
import java.awt.event.*; // ActionEvent, ActionListener..
import java.awt.*; // Container, GridLayout

/**
Provides a menu of options on what to create or do
*/
public class MenuFrame extends JFrame
{
 private MenuPanel menu;
 private PDAApplication app;

  public MenuFrame(PDAApplication appl)
  {
     super("Menu");
     app = appl;
     menu = new MenuPanel(app);
    Container c = getContentPane();
     c.add(menu);  

     setDefaultLookAndFeelDecorated(true);
     setResizable(false);
     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      // exit the application when this menu closes

     setSize(200,200); // set dimensions of frame
    Dimension scrn = getToolkit().getScreenSize();
     setBounds( (scrn.width-getWidth())/2, (scrn.height-getHeight())/2, getWidth(), getHeight() );

     setVisible(true);  // show this frame
     for (;;) {}
  }

} // end class MenuFrame

class MenuPanel extends JPanel
{
/*
Options:
new process document
edit process document
edit index document
edit glossary document
*/

  /** The application this is a part of */
  private PDAApplication app;

  /** Option for new process document */
  private JButton NewProcessBtn; 

  /** Option for new process document */
  private JButton EditProcessBtn; 

  /** Option for new process document */
  private JButton EditIndexBtn; 

  /** Option for new process document */
  private JButton EditGlossaryBtn; 

  /** Option for replicating file structure */
  private JButton StructureReplicatorBtn;

  /** A component for letting the user select which file to open */
  private JFileChooser chooser;

  public MenuPanel(PDAApplication appl)
  {
    super(new GridLayout(5,1));
    app = appl;
    chooser = new JFileChooser(app.getInitSourcePath());
    chooser.setFileFilter(new gui.XMLFileFilter());

    NewProcessBtn = new gui.ActiveButton("Create New Process");
    EditProcessBtn = new gui.ActiveButton("Edit Document");
    EditIndexBtn = new gui.ActiveButton("Edit Index");
    EditGlossaryBtn = new gui.ActiveButton("Edit Glossary");
    StructureReplicatorBtn = new gui.ActiveButton("Replicate Documentation");

    addActionListeners();  

    // add components to display
    add(NewProcessBtn); 
    add(EditProcessBtn);
    add(EditIndexBtn); 
    add(EditGlossaryBtn); 
    add(StructureReplicatorBtn);
  }

  /**
   Adds the ActionListeners for the buttons
  */
  private void addActionListeners()
  {
     NewProcessBtn.addActionListener(
       new ActionListener() 
      {
         public void actionPerformed(ActionEvent AE)
         {
            // open a ProcessEditor           
            app.OpenNewProcessDocument();
         }
      }
     );

     EditProcessBtn.addActionListener(
       new ActionListener() 
      {
         public void actionPerformed(ActionEvent AE)
         {
            /* open a PDAEditor with a specified file loaded
            The specific descendent kind of PDAEditor is determined by the user's selected file.
            It may still not be a process document because another xml file like index.xml may be selected.
            */        
        int returnVal = chooser.showOpenDialog(null);
          if(returnVal == JFileChooser.APPROVE_OPTION) {
            app.LoadIntoEditor(chooser.getSelectedFile());
           }
         }
      }
     );

     EditIndexBtn.addActionListener(
       new ActionListener() 
      {
         public void actionPerformed(ActionEvent AE)
         {
            // open an IndexPageEditor with index page loaded           
            app.ShowIndexFrame();            
         }
      }
     );

     EditGlossaryBtn.addActionListener(
       new ActionListener() 
      {
         public void actionPerformed(ActionEvent AE)
         {
            // open an GlossaryEditor with glossary loaded 
            app.ShowGlossaryFrame();          
         }
      }
     );
     
     StructureReplicatorBtn.addActionListener(
       new ActionListener() 
      {
         public void actionPerformed(ActionEvent AE)
         {
            // open an GlossaryEditor with glossary loaded 
            app.ShowStructureReplicator();          
         }
      }
     
     );
  }
}
