
import gui.*; // MiscUtils
import javax.swing.*;
import java.awt.event.*; // ActionEvent
import java.net.URL;

/**
Help Menu

handles all events and creates all menu items required.
*/
public class HelpMenu extends JMenu
{
  /** For getting information about the software */
  protected JMenuItem About;

  /** For getting help on using the software */
  protected JMenuItem UsingPDA;

  /**
   <ul> 
    <li>Application this is a part of</li>
    <li>app is referenced to get absolute path to help documents</li>
   </ul>
  */
  protected PDAApplication app;  

   public HelpMenu(PDAApplication appl)
   { 
     super("Help");
      app = appl;
      About = new JMenuItem("About Process Document Assistant");
      UsingPDA = new JMenuItem("Using Process Document Assistant");      

      UsingPDA.addActionListener(
        new ActionListener()
        {
           public void actionPerformed(ActionEvent a)
           {
              gui.MiscUtils.ViewDocument(app.getHelpPath()+"/Using PDA.html");
           }
        }
       );

      About.addActionListener(
        new ActionListener()
        {
           public void actionPerformed(ActionEvent a)
           {
              gui.MiscUtils.ViewDocument(app.getHelpPath()+"/About PDA.html");
           }
        }
       );
      this.add(UsingPDA);
      this.add(About);
   }

} // end class





