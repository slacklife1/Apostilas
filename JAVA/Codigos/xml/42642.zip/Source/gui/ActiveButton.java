package gui;

import javax.swing.JButton;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.Color;


/**
 A button with a little more visual appeal than JButton
*/
public class ActiveButton extends JButton implements MouseListener
{
 /** States this button goes through */
 public static final int DEFAULT=0, ACTIVE=1;

 /** Colour of background when mouse is over */
 protected static final Color OverColour = new Color(245,245,255);

 /** Background colour when button is disabled */
 protected static final Color DisabledColour = new Color(0,0,60);

 /** Current state */
 protected int state;


  public ActiveButton(String title)
  {
     super(title);
     addMouseListener(this);
  }

  /** Updates after a state change */
  public void StateUpdate()
  {
   
    switch (state)
    {
       case DEFAULT: 
          setBackground(null);
          break;
       case ACTIVE:
          if (isEnabled())
             setBackground(OverColour);
          else
             setBackground(DisabledColour);
          break;
    }
    repaint(); // update display
  }

  /** sets state */
  private void setState(int newState)
  {
     state = newState;
     StateUpdate();     
  }


 /////**  MouseListener implementation **////
  public void mouseEntered(MouseEvent ME)
  {
     setState(ACTIVE);
  }

  public void mouseExited(MouseEvent ME)
  {
     setState(DEFAULT);
  }

  public void mouseReleased(MouseEvent ME)
  {
  }

  public void mousePressed(MouseEvent ME)
  {
  }

  public void mouseClicked(MouseEvent ME)
  {
  }
} // end class ActiveButton
