/**
author: Josh Greig
*/

package gui;
import java.io.File;
import javax.swing.filechooser.FileFilter;

/**
For Filtering out everything but XML files and directories
*/
public class XMLFileFilter extends FileFilter
{

  /** Returns true if f is an XML file or directory */
  public boolean accept(File f) 
  {
     return FileNameManipulator.EqualExtention(f,"xml") || f.isDirectory();
  }

  /** Gets description of filter */
  public String getDescription()
  {
    return "XML files";
  }

} // end class XMLFileFilter