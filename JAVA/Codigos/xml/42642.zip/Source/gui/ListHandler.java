package gui;

/**
For classes that handle responses from tools
*/
public interface ListHandler
{
  /** Deletes current element */
  public void DeleteElement();

  /** Inserts an element into the list */  
  public void InsertElement();

  /** Gets the index of currently active element */
  public int getCurrentIndex();
 
  /** Sets the Current Index */
  public void setCurrentIndex(int newIndex);

  /** Returns number of elements in the list */
  public int getLength();

  /** Clears the list */
  public void Clear();

} // end interface ListHandler 