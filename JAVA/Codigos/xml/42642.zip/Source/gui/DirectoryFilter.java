/**
author: Josh Greig
*/

package gui;
import java.io.File;
import javax.swing.filechooser.FileFilter;

/**
For Filtering out everything but directories
*/
public class DirectoryFilter extends FileFilter
{
  /** Returns true if f is a directory */
  public boolean accept(File f) 
  {
     return f.isDirectory();
  }

  /** Gets description of filter */
  public String getDescription()
  {
    return "Directories";
  }

} // end class DirectoryFilter