/*
Date Started: Sept. 17, 2005
author: Josh Greig

*/

package gui;

import javax.swing.*; // JPanel
import java.awt.*; // GridLayout
import java.io.*; // OutputStream
import java.util.*; // LinkedList, Iterator
import java.awt.event.*; // ActionListener

import org.w3c.dom.*;

/**
Manipulates, loads and saves a list of HyperLink's 

*/
public class HyperLinkList extends JPanel
{
 /** Panel for storing the toolbar */
 protected ListToolBar Toolbar;

 /** Panel for storing the HyperLinks */
 protected HyperLinkListPanel linksPanel;
 
  public HyperLinkList()
  {
    setLayout(null); // 1 row, 2 columns
    
     linksPanel = new HyperLinkListPanel(this);
     Toolbar = new ListToolBar(linksPanel);

    add(Toolbar);
    add(linksPanel);
    addListeners();
  }  

  private void addListeners()
  {
     addComponentListener(
      new ComponentAdapter()
      {
         public void componentResized(ComponentEvent e)
         {
           Toolbar.UpdateBounds(HyperLinkList.this);
           linksPanel.setBounds(110,0,getWidth()-110,getHeight());
         }
      }
     );
  }

  /**
  Writes data on this list to stream using XML format
  */
  public synchronized void WriteToStream(OutputStream stream)
  {
     linksPanel.WriteToStream(stream);
  } 

  /** Loads from XML Element */
  public synchronized void LoadFrom(Element e)
  {
    NodeList nl = e.getElementsByTagName("link");
    int len = nl.getLength();

    linksPanel.Clear();

    // loop through HyperLink nodes
    for (int i=0;i<len;i++)
    {
       Node n = nl.item(i);
       HyperLink HL = new HyperLink((Element)n);
        linksPanel.InsertLast(HL);
    }
    Toolbar.UpdateDeleteEnabled();
  }

  /** Inserts a new HyperLink into the list */
  public synchronized void InsertLink()
  {
   try{
  	
    HyperLink HL = new HyperLink();

    linksPanel.InsertLink(HL);
   }
   catch (Exception e)
   {
     System.err.println("HyperLinkList::InsertLink: "+e);	
   }    
  }

  /** Deletes currently selected HyperLink from the list */
  public void DeleteLink()
  {
    linksPanel.DeleteCurrentLink();
  }

  /** Clears list */
  public void Clear()
  {
     linksPanel.Clear();
  }

} // end class HyperLinkList


/** For listing all HyperLinks */
class HyperLinkListPanel extends JPanel implements ListHandler
{
 /** the component this list is for */
 protected HyperLinkList HLList;
 protected GridLayout layout;
  /** List of HyperLinks */
 protected LinkedList links;

 /** The link at the top of the display */
 protected HyperLink headLink; 

 /** Lists all HyperLink's */
 protected JPanel LinksListingPanel;

 /** Index in the list */
 protected int CurrentIndex=0; 

  public HyperLinkListPanel(HyperLinkList HLL)
  {
     setLayout(null); // don't use any LayoutManager
     links = new LinkedList();
     LinksListingPanel = new JPanel();
     HLList = HLL;
     headLink = new HyperLink(null,null);
     add(headLink);
     add(LinksListingPanel);
     addListeners();
     Reindex();     
  }

  /** adds listener to maintain layout */
  private void addListeners()
  {
     addComponentListener(
      new ComponentAdapter()
      {
         public void componentResized(ComponentEvent e)
         {
           headLink.setBounds(5,5,getWidth()-10,20);
           LinksListingPanel.setBounds(5,30,getWidth()-10,getHeight()-30);
         }
      }
     );
  }

  /** Reorders the list of links based on the links list */
  public void Reindex()
  {
    try
    {
    
    Iterator it = links.iterator();
    int len = links.size(); // get number of elements in list
 
      // clear GUI
     LinksListingPanel.removeAll();
     layout = new GridLayout(len,1);
     LinksListingPanel.setLayout(layout);
      
      // loop through list
      while (it.hasNext())
      {  
        // add each to the GUI
        HyperLink hl = (HyperLink)it.next();
        LinksListingPanel.add(hl);
      }

      // update display
      LinksListingPanel.updateUI();
      repaint();
    }
    catch (Exception e)
    {
       System.err.println("HyperLinkListPanel::Reindex: "+e);	
    }
  }

  /** Inserts a link into the panel */
  public synchronized void InsertLink(HyperLink HL)
  {
   try{
  	
  	if (CurrentIndex<0)
  	{
  	  links.addFirst(HL);
    }
    else if (CurrentIndex>links.size())
  	  links.add(HL);
  	else
      links.add(CurrentIndex,HL);
   }
   catch (Exception e)
   {
      System.err.println("HyperLinkListPanel::InsertLink: "+e);	
   }
    Reindex();
  }

  /** Inserts at end of list */
  public synchronized void InsertLast(HyperLink HL)
  {
    links.add(HL);
    CurrentIndex = links.size()-1;
    Reindex();
  }

  /** Writes Links to stream */
  public void WriteToStream(OutputStream stream)
  {
    Iterator it = links.iterator();

     // loop through links
     while (it.hasNext())
     {
        Object o = it.next();
         if (o instanceof HyperLink)
         {
            HyperLink hl = (HyperLink)o;
            hl.WriteToStream(stream);
         } 
         else
         {
            JOptionPane.showMessageDialog(this,
           "Invalid type found in list of HyperLink's while writing to stream");
            break; // break the while loop
         }
     } // end while
  }

  /** Deletes current link */
  public synchronized void DeleteCurrentLink()
  {
    links.remove(CurrentIndex);
    CurrentIndex--;

    Reindex();
  }


  public void InsertElement()
  {
  	try{
  	
    HyperLink HL = new HyperLink();
    InsertLink(HL);
    }
    catch (Exception e)
    {
      System.err.println("HyperLinkListPanel::InsertElement: "+e);	
    }
  }

  public synchronized int getLength()
  {
    return links.size();
  }

  public int getCurrentIndex()
  {
     return CurrentIndex;
  }

  public void setCurrentIndex(int newIndex)
  {
     CurrentIndex = newIndex;
  }

  public void DeleteElement()
  {
      DeleteCurrentLink();
  }

  /**
   Clears list of links
  */
  public void Clear()
  {
     links.clear();
     Reindex(); // update GUI to reflect changes
  }

  /*****************************************/

} // end class HyperLinkListPanel








