package gui;


import javax.swing.*; // JPanel
import java.awt.*; // GridLayout
import java.io.*; // PrintStream, OutputStream
import java.awt.event.*; // ActionListener

import org.w3c.dom.*;


/**
A single HyperLink
*/
public class HyperLink extends JPanel implements ActionListener
{
 /** Name to be displayed for the hyperlink */
 protected String name;

 /** Address link refers to */
 protected String href;

 /** For editing name */
 protected JTextField NameField;
 
 /** For editing href */
 protected JTextField HrefField;

  public HyperLink(String nm, String url)
  { 
     super(new GridLayout(1,2)); // 1 row, 2 columns
     href=url;
     name=nm;

     if ((nm!=null)&&(url!=null))
     {
        // create GUI components
        NameField = new JTextField(name);
        HrefField = new JTextField(href);

        NameField.addActionListener(this);
        HrefField.addActionListener(this); 

        // add components to this
        add(NameField);
        add(HrefField);
     }
     else
     {
        add(new JLabel("Name"));
        add(new JLabel("Address"));
     }
  }

  /** Creates a HyperLink and asks user for name and URL */
  public HyperLink()
  {
    this("","");
   try{
   
    // ask user for name and URL
    String n;
    do
    {   
       n = JOptionPane.showInputDialog(this,"What is the hyperlink's name?");
       setName(n);
       if (name==null)
       {
          JOptionPane.showMessageDialog(this,"The name you have given is either too short or invalid.");	          	
       }
    } while (name==null);
    
    href = null;
    String a;
    do
    {
       a = JOptionPane.showInputDialog(this,"What is the hyperlink's address?");
       setAddress(a);
       if (href==null)
       {
          JOptionPane.showMessageDialog(this,"The address you have given is either too short or invalid.");	
       }  
    } while (href==null);

   }
   catch (Exception e)
   {
      System.err.println("HyperLink::HyperLink(): "+e);	
   }
  }

  /** Initializes off Element e */
  public HyperLink(Element e)
  {
     this("",""); // initialize without name and address
     LoadFrom(e); // set name and address
  }

  /** Loads name and address from an XML element e */
  public void LoadFrom(Element e)
  {
    // get name, address
    String nm = e.getAttribute("name");
      setName(nm);
    String hf = e.getAttribute("href");
       setAddress(hf);
  }


  /** Sets name of this hyperlink */
  public void setName(String nm)
  {
    if (nm==null) return;
    if (nm.length()<2)
    {
       return;
    }
    name = nm;
    NameField.setText(nm);
  }

  /**
   Sets address of this link
  */
  public void setAddress(String a)
  {
    if (a==null) return;
    if (a.length()<2) return;
     a = CorrectURL(a);
     href=a;
     HrefField.setText(a);
  }

  /** Reacts to updates in the textfields */
  public void actionPerformed(ActionEvent AE)
  {
     name = NameField.getText();
     href = HrefField.getText();
  }

  /** Writes the state of this link to a stream using XML tags */
  public void WriteToStream(OutputStream stream)
  {
    PrintStream ps = new PrintStream(stream);
     ps.println("  <link name=\""+name+"\" href=\""+href+"\" />");

  }

  /**
   Corrects some common problems with invalid URL's
  */
  public static String CorrectURL(String url)
  { 
     if (url.substring(0,4).equals("www."))
        url = "http://"+url;
     return url;
  }

} // end class
