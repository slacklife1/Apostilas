/**
author: Josh Greig
*/
package gui;


import java.util.LinkedList;
import java.util.Iterator;


/**
 For storing listeners and dispatching events
*/
public class GUIEventDispatcher
{
  private LinkedList GUIListeners;

  public GUIEventDispatcher()
  {
    GUIListeners = new LinkedList();
  }

  /** Adds listener to list */
  public synchronized void add(GUIListener GUIL)
  {
     GUIListeners.add(GUIL);
  }

  /**
   Dispatches an event message to all listeners
  */
  public synchronized void DispatchEvent(Object source)
  {
    // loop through listeners
    Iterator it = GUIListeners.iterator();
    while (it.hasNext())
    {
      GUIListener GUIL = (GUIListener)it.next();
       GUIL.actionHappened(source); 

    } // end while
  }
}