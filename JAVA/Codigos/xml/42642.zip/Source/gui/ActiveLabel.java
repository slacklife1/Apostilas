package gui;

import java.awt.event.*;
import java.awt.*; // Color, Graphics...
import javax.swing.*;
import java.awt.geom.*; // Rectangle2D

public class ActiveLabel extends JLabel implements MouseListener
{
 /** States this label goes through */
 public static final int DEFAULT=0, ACTIVE=1;

 /** All listeners to this label */
 public GUIEventDispatcher GUIEvents;

 /** Current state */
 protected int state;

 /** Colour of the font */
 protected Color TextColour;

  /** Initializes with a title */
  public ActiveLabel()
  {
     super();
     state=DEFAULT;
     addMouseListener(this);
     GUIEvents = new GUIEventDispatcher();
  }     

  /** Initializes with a title */
  public ActiveLabel(String title)
  {
     this();
     setText(title);
  }     

  /** Updates after a state change */
  public void StateUpdate()
  {
    switch (state)
    {
       case DEFAULT: 
          TextColour = Color.BLACK;
          break;
       case ACTIVE:
          TextColour = Color.BLUE;
          break;
    }
    repaint(); // update display
  }

  public void paint(Graphics g)
  {
     Font normFont = g.getFont();

     FontMetrics fm = getFontMetrics(normFont);
     int height = fm.getHeight();
     String normString = getText();

     Rectangle2D bounds = fm.getStringBounds(normString, g);
     g.setColor(TextColour);
     g.drawString(normString,0,height);     
  }

  /** adds a listener for GUI events */
  public void addGUIListener(GUIListener GUIL)
  {
     GUIEvents.add(GUIL);
  }

  /** sets state */
  private void setState(int newState)
  {
     state = newState;
     StateUpdate();     
  }


 /////**  MouseListener implementation **////
  public void mouseEntered(MouseEvent ME)
  {
     setState(ACTIVE);
  }

  public void mouseExited(MouseEvent ME)
  {
     setState(DEFAULT);
  }

  public void mouseReleased(MouseEvent ME)
  {
  }

  public void mousePressed(MouseEvent ME)
  {
    GUIEvents.DispatchEvent(this);
  }

  public void mouseClicked(MouseEvent ME)
  {
  }

} // end class ActiveLabel
