/*

some code taken from:
http://javaalmanac.com/egs/java.io/File2ByteArray.html

*/

package gui;

import javax.swing.JOptionPane;
import java.io.*; // File, IOException, FileInputStream
import java.lang.reflect.*; // Method


/**
A collection of a few methods that don't belong to any other category
*/
public class MiscUtils
{
 /** Message to show user when can't be opened */
 private static final String errMsg = "Error attempting to launch web browser"; 

 public static void openURL(String url) 
 { 
  url = FormatURL(url);
  String osName = System.getProperty("os.name"); 
  try 
  { 
     if (osName.startsWith("Mac OS")) 
     { 
        Class macUtils = Class.forName("com.apple.mrj.MRJFileUtils"); 
        Method openURL = macUtils.getDeclaredMethod("openURL", 
            new Class[] {String.class}); 
        openURL.invoke(null, new Object[] {url}); 
     } 
     else if (osName.startsWith("Windows")) 
     { 
       Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + url); 
     } 
     else 
     { //assume Unix or Linux 
        String[] browsers = { 
            "firefox", "opera", "konqueror", "mozilla", "netscape"}; 
        String browser = null; 
         
         // loop through browsers
         for (int count = 0; count < browsers.length && browser == null; count++)
         { 
            if (Runtime.getRuntime().exec( 
              new String[] {"which", browsers[count]}).waitFor() == 0) 
            { 
               browser = browsers[count]; 
               break; // stop searching when browser found
            } 
         } 
         if (browser == null) 
         { 
           throw new Exception("Could not find web browser."); 
         } 
         else 
         {               
           Runtime.getRuntime().exec(new String[] {browser, url}); 
         } 
     } 
   } 
   catch (Exception e) 
   { 
       JOptionPane.showMessageDialog(null, 
         errMsg + ":\n" + e.getLocalizedMessage()); 
   } 
 } 

/** Formats a file name so it can function as a url */
private static String FormatURL(String fn)
{
   fn = fn.replace('/','\\');
  // fn = StringManipulator.replaceStrings(fn," ","%20");

   // if not absolute path, make absolute path relative to PDA directory
       

 //  if (! fn.startsWith("file://"))
   //   fn = "file://"+fn;

  // System.err.println("FormatURL returning "+fn);
   return fn;
}

 /**
  Copies File to File
 */
 public static void CopyFile(File source, File destination)
 {
   boolean copycomplete = true;
    try
    {
       Runtime.getRuntime().exec(new String[] {"copy", source.getPath(), destination.getPath()});
    }
    catch (Exception e)
    {
       copycomplete = false;
    //   System.err.println("CopyFile: "+e);
    }
    if (copycomplete==false)
    {
     try
     {
        byte buffer[] = getBytesFromFile(source);
  
        // buffer the file
        FileOutputStream FIO = new FileOutputStream(destination);

         FIO.write(buffer);

         FIO.close();
        // write the file
     }
     catch (Exception e)
     {
        System.err.println("Unable to copy file ["+source+"] to ["+destination+"]: "+e);
     }
    }
 }

   /** Returns the contents of the file in a byte array. */
    public static byte[] getBytesFromFile(File file) throws IOException {
        InputStream is = new FileInputStream(file);
    
        // Get the size of the file
        long length = file.length();
    
        // You cannot create an array using a long type.
        // It needs to be an int type.
        // Before converting to an int type, check
        // to ensure that file is not larger than Integer.MAX_VALUE.
        if (length > Integer.MAX_VALUE) {
            // File is too large
        }
    
        // Create the byte array to hold the data
        byte[] bytes = new byte[(int)length];
    
        // Read in the bytes
        int offset = 0;
        int numRead = 0;
        while (offset < bytes.length
               && (numRead=is.read(bytes, offset, bytes.length-offset)) >= 0) {
            offset += numRead;
        }
    
        // Ensure all the bytes have been read in
        if (offset < bytes.length) {
            throw new IOException("Could not completely read file "+file.getName());
        }
    
        // Close the input stream and return bytes
        is.close();
        return bytes;
    }

   /**
     Loads an HTML file fn
    @param fn is the name of the file to be loaded
   */
   public static void ViewDocument(String fn)
   {
      // load the specified file into a browser window
     try
     {
        openURL(fn);
     }
     catch (Error er)
     {
        System.err.println("error: "+er);
     }
     catch (Exception e)
     {
        System.out.println(e);
        JOptionPane.showMessageDialog(null,"The document("+fn+") was unable to load.");
     }
   }

} // end class MiscUtils





