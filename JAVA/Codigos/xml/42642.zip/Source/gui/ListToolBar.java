package gui;

import javax.swing.*; // JPanel, JButton...
import java.awt.event.*;

/**
A toolbar for manipulating a list.
This is used in MethodManipulator, HyperLinkList, DefinitionList
*/
class ListToolBar extends JPanel
{
  /** The ListHandler this is a toolbar for */
  protected ListHandler LHandler;

  /** For inserting new Element */
  protected JButton InsertElementBtn;

  /** For deleting current Step */
  protected JButton DeleteElementBtn;

  public ListToolBar(ListHandler LH)
  {
    setLayout(null); // don't use any LayoutManager
    LHandler = LH;
    InsertElementBtn = new ActiveButton("Insert");
    DeleteElementBtn = new ActiveButton("Delete");

     UpdateDeleteEnabled();

     addListeners();

     add(InsertElementBtn);
     add(DeleteElementBtn);
  }

  /** Adds required listeners */
  public void addListeners()
  {
    InsertElementBtn.addActionListener(
       new ActionListener()
      {
        public void actionPerformed(ActionEvent AE)
        {
         try{
          
          LHandler.InsertElement();
          UpdateDeleteEnabled();
          MoveIndexToLastElement();
         } 
         catch (Exception e)
         {
         	System.err.println("ListToolbar::addListeners(insert button): "+e);
         }
        }
      }
     );

    DeleteElementBtn.addActionListener(
       new ActionListener()
      {
        public void actionPerformed(ActionEvent AE)
        {
         try
         {
         
          LHandler.DeleteElement();
          UpdateDeleteEnabled();
          MoveIndexToLastElement();
         }
         catch (Exception e)
         {
         	System.err.println("ListToolbar::addListeners(delete button): "+e);	
         }
        }
      }
     );

  } // end method addListeners()

  /** Updates layout on screen */
  public void UpdateBounds(JComponent C)
  {
     setBounds(0,0,110,C.getHeight());
     InsertElementBtn.setBounds(5,5,100,30);
     DeleteElementBtn.setBounds(5,40,100,30);
     UpdateDeleteEnabled();
  }

  /** Enables and disables the button */
  public void setDeleteEnabled(boolean v)
  {
    DeleteElementBtn.setEnabled(v);
  }

  /**
   Updates whether or not the delete button should be enabled
  */
  public void UpdateDeleteEnabled()
  {
  	try{
  	
   int curIndex = LHandler.getCurrentIndex();
   int len = LHandler.getLength();
    if (curIndex>=0 && curIndex<len)
      setDeleteEnabled(true);
    else
       setDeleteEnabled(false);
      }catch (Exception e)
      {
        System.err.println("ListToolBar::UpdateDeleteEnabled: "+e);	
      } 
  }

  /**
  Moves index to last element
  */
  private void MoveIndexToLastElement()
  {
   try
   {
   
  	LHandler.setCurrentIndex(LHandler.getLength()-1);
   }
   catch (Exception e)
   {
     System.err.println("ListToolBar::MoveIndexToLastElement: "+e);	
   }
  }

} // end class ListToolBar