/*
Date: Sept. 20, 2005
author: Josh Greig
*/

package gui;


import javax.swing.*; // JPanel
import java.io.*; // OutputStream
import java.awt.*; // GridLayout
import java.awt.event.*; // ActionListener...
import java.util.LinkedList;
import java.util.Iterator;

import org.w3c.dom.*; // Document, Node

/**
For manipulating a sequence of steps
*/
public class MethodManipulator extends JPanel
{
  /** Component's toolbar */
  protected ListToolBar toolbar;

  /** */
  protected StepsListing steps;

  public MethodManipulator()
  {
     setLayout(null);
     steps = new StepsListing(this);
     toolbar = new ListToolBar(steps);

     add(toolbar);
     add(steps);
     addListeners();
  }

  /** Adds any listeners required for managing events */
  private void addListeners()
  {
     addComponentListener(
       new ComponentAdapter()
       {
         public void componentResized(ComponentEvent e)
         {
           toolbar.UpdateBounds(MethodManipulator.this);
           steps.setBounds(110,0,getWidth()-110,getHeight());
         }
       }
      );

  }

  /**
  Inserts new step just before the current location in the method
  */
  public void InsertElement()
  {
      steps.InsertElement();
      toolbar.setDeleteEnabled(true); // enable the delete step button
  }

  /** Writes method to a stream */
  public void WriteToStream(OutputStream stream)
  {
     steps.WriteToStream(stream);
  }

  /**
   Loads from an XML structure  
  */
  public void LoadFrom(Element e) throws IOException
  {
    NodeList stepNodes = e.getElementsByTagName("step");
    int len = stepNodes.getLength();
	 
     steps.Clear();
	 
     // loop through child nodes/steps
     for (int i=0;i<len;i++)
     {
       Node n = stepNodes.item(i);
       if (n instanceof Element)
       {
          Step s = new Step(i,(Element)n);

           steps.InsertStep(s);
       }
       else
           System.err.println("MethodManipulator::LoadFrom: Node not Element");
	 
     } // end loop through steps
     toolbar.UpdateDeleteEnabled();
  }

  /**
   Clears all methods out of the display and buffers
  */
  public void Clear()
  {
     steps.Clear();
  }

  /** Sets enabled/disabled for delete step button */
  public void setDeleteEnabled(boolean v)
  {
     toolbar.setDeleteEnabled(v);
  }

} // end class MethodManipulator


/**
The listing of indexed steps
*/
class StepsListing extends JPanel implements ListHandler
{
 /** MethodManipulator this is a part of */
 private MethodManipulator parent;

 /** Currently selected index for step */
 protected int CurrentIndex = 0;

 /** Panel to list steps */
 protected JPanel StepsListPanel;

 /** List of Step objects */
 private LinkedList steps;

 /** This panel's LayoutManager */
 private LayoutManager layout;

 /** Title */
 private JLabel title;

  public StepsListing(MethodManipulator mm)
  {
      setLayout(null); // no layout manager
      parent = mm;
      StepsListPanel = new JPanel();
      steps = new LinkedList();
      title = new JLabel("Sequence of Steps");
      add(title);
      add(StepsListPanel);
      addListeners();
  }

  private void addListeners()
  {
     addComponentListener(
      new ComponentAdapter()
      {
         public void componentResized(ComponentEvent e)
         {
           title.setBounds(5,5,150,25);
           StepsListPanel.setBounds(5,30,getWidth()-10,getHeight()-35);
         }
      }
     ); 
  }

  /**
   Reindexes all Step objects in the list and replaces some elements on the panel
  */
  private synchronized void Reindex()
  {
    layout = new GridLayout(steps.size(),1); 
    StepsListPanel.setLayout(layout);
    StepsListPanel.removeAll(); // remove all components

    // loop through all Step objects
    Iterator it = steps.iterator();
    int i = 0;

    // loop through all Step objects in the list
    while (it.hasNext())
    {
       try 
       {
          Step s = (Step)it.next();
           StepsListPanel.add(s);
           s.setIndex(i); // set index to be shown on side of step
           i++;
       }
       catch (Exception e)
       {
          JOptionPane.showMessageDialog(null,
           "Exception thrown in Reindex method: "+e);
       } // end catch 

    } // end while

    // update the display  
    updateUI();  
  }

 /***********************************/

  /**
   Adds a new step to the list at a specified location
  */
  public void InsertElement()
  {
    // add Step to sequence just before specified location
    Step s = new Step(CurrentIndex);
      InsertStep(s);

  }

  public int getCurrentIndex()
  {
     return CurrentIndex;
  }

  public synchronized int getLength()
  {
    return steps.size();
  }

  public void setCurrentIndex(int newIndex)
  {
     CurrentIndex = newIndex;
  }

  public void DeleteElement()
  {
    DeleteCurrentStep();
  }

  /** Clears all steps out of the sequence */
  public void Clear()
  {
     steps.clear(); // remove all elements
     CurrentIndex = 0;
  }

 /************************************/

  public synchronized void InsertStep(Step s)
  {
  	try{
  	
  	 if (CurrentIndex<0)
  	 {
  	    steps.addFirst(s);
  	    Reindex();
  	    return;	
  	 }
  	 if (CurrentIndex<steps.size())
        steps.add(CurrentIndex+1,s);
     else
        steps.add(s);
     // insert s to list
     
     CurrentIndex++;
     
     Reindex();
   }
   catch (Exception e)
   {
     System.err.println("StepsListing::InsertStep: "+e);	
   }
  }


  /**
   Deletes the current step
  */
  public synchronized void DeleteCurrentStep()
  {
    // delete the indexed step
    steps.remove(CurrentIndex);
     if (CurrentIndex>=steps.size())
     {
        if (CurrentIndex>0) 
          CurrentIndex--;
        else
            parent.setDeleteEnabled(false);
             // call parent to disable delete button
     }
    Reindex();
  }

  /** Writes list to stream */
  public synchronized void WriteToStream(OutputStream stream)
  {
    Iterator it = steps.iterator();
    try 
    {
     // loop through steps
     while (it.hasNext())
     {
       // on each, call WriteToStream
       Step s = (Step)it.next(); 
        s.WriteToStream(stream);

     } // end while
    }
    catch (Exception e)
    {
       JOptionPane.showMessageDialog(null,"Problem in StepsListing::WriteToStream: "+e);
    }
  }



} // end class





