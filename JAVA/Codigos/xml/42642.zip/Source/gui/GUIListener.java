package gui;

/**
 Listens and handles GUI events
*/
public interface GUIListener
{
  /** Signals that an event happened
   @param source is the source Object of the event
  */
  public void actionHappened(Object source);

}