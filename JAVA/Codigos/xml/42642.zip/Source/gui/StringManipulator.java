package gui;

public class StringManipulator
{
 /**
  Replaces all occurances of fromString with withString
  @param s1 is the string being processed
  @param fromString is the substring being replaced
  @param withString is the substring replacing fromString
  @return s1 with all occurances replaced  
 */
 public static String replaceStrings(String s1,String fromString,String withString)
 {
   if (withString.indexOf(fromString)>=0)
   {
      System.err.println("replaceStrings::"+fromString+" is in "+withString);
      return null;
   }
   int index;
   int lenfromString = fromString.length();
   int lenwithString = withString.length();
   
    do
    {
       index = s1.indexOf(fromString);
       int len = s1.length();
       String temp= ""+s1;
       if ((index>=0)&&(len>index))
       {
         try
         {
          s1 = temp.substring(0,index)+withString; // example s1 = "bla%20;"
         int startIndex = index+lenfromString;
          s1 += temp.substring(startIndex);
         }
         catch (Exception e)
         {
            System.out.println("StringManipulator::replaceStrings: "+e);
            index=-1; // exit outer loop
         }
       }
    }
    while (index>=0);

    return s1; 
 }

 /**
  Formats a String to avoid errors in XML
 */
 public static String formatForXML(String unformattedS)
 {
    unformattedS = replaceStrings(unformattedS,">","&gt;"); // replace > with &gt; 
    unformattedS = replaceStrings(unformattedS,"<","&lt;"); // replace < with &lt; 
    return unformattedS;
 }

 /**
  Formats XML text so it is more understandable in plain text.
  Basically, this is reversing formatForXML.
  @param xmlFormatted is formatted for storage in XML files(may contain codes like &gt;&lt;.. )
  @return a string formatted for display in a text component
 */
 public static String formatXMLToTXT(String xmlFormatted)
 {
    xmlFormatted = replaceStrings(xmlFormatted,"&gt;",">");  
    xmlFormatted = replaceStrings(xmlFormatted,"&lt;","<");  
    return xmlFormatted;    
 }

} // end class StringManipulator
