/*
author: Josh Greig

*/

package gui;
import java.io.*; // File

/**
A library of methods for manipulating file names
*/
public class FileNameManipulator
{

 /** Returns file extention of f */
 public static String getExtention(File f)
 {

   String nm = f.getName();
   int indexDot = nm.lastIndexOf(".");
   
   if (indexDot<0) // example getExtention(new File("bla"))
      return "";

   int indexSlash = nm.lastIndexOf("/");

     if (indexSlash>indexDot) // example getExtention(new File("do.do/bla"))
        return "";

   String result = nm.substring(indexDot+1);
   return result; // return substring after last dot
 }

 /**
  Returns the file name without any directory names
  @param path is an absolute or relative path for a file(ie. "c:\directory\bla.txt")
  @return Only the file name(ie. "bla.txt") 
 */
 public static String getFileName(String path)
 {
  path = path.replace('/','\\'); 
   // ensure only 1 type of slash is used so we can assume it.

  int slashIndex = path.lastIndexOf('\\');
  String result = path.substring(slashIndex+1);  

   if ( slashIndex>0 ) // if there is a \ somewhere
       return path.substring(slashIndex+1); 
       // return what is after that last slash
   else
       return path;
 }

 /** Checks if a file has the given extention 
  @param f is the file being checked
  @param ext is the extention being compared with
  @return true, if and only if ext matches the file extention of f ignoring case.
   For example, if f is EqualExtention(new File("bla.XML"),"xml") would return true.
 */
 public static boolean EqualExtention(File f, String ext)
 {
    return getExtention(f).equalsIgnoreCase(ext);

 }

 /**
  Returns a path using the deepest nested folder of f on the directory containing fn
  @param fn is the file name for destination path(ie. C:\My Documents\School\bla.txt)
  @param f is a source file (ie. C:\My Documents\cell)
  @return uses f to create a new file name in folder of fn(ie. C:\My Documents\School\cell)
 */
 public static String getSubfolderFileName(String fn, File f)
 {
  String nm = f.getName();
  // ie. nm = "bla.txt"   

   // get resulting folder from fn
   String sfolder = getFolder(fn);

     fn = sfolder + '/' + nm;

   return fn;
 }

 /** 
  Returns folder the file is within
 */
 public static String getFolder(String foldername)
 {
    int DotIndex = foldername.lastIndexOf('.');
    int SlashIndex = foldername.lastIndexOf('\\');
    String sfolder = "";

     // if . after \, remove everything after last \ 
     if ((DotIndex>0)&&(DotIndex>SlashIndex)&&(SlashIndex>0))
       sfolder = foldername.substring(0,SlashIndex);
     else
        sfolder = foldername;

     return sfolder;
 }

 /**
  Returns file name for curFile to be copied to
  @param curFile is an existing file in source directory
  @param destination is the name of the destination folder
  @return file name of destination
 */
 public static String getDestinationFileName(File curFile, String destination)
 {
   String destFolder = getFolder(destination);
   String nm = curFile.getName();

     return destFolder+'\\'+nm;
 }

 /**
  Returns file name using the given extention
  @param fn is the file name to be given the extention(ie. "bla")
  @param extention is the file(ie. "xml") 
  @return file name with given extention(ie. "bla.xml")
 */
 public static String getFileNameWithExtention(String fn,String extention)
 {
   int DotIndex = fn.lastIndexOf('.');
   
   // deal with potential mistake by programmer in using ".xml" instead of "xml"
   if (extention.charAt(0)=='.')
      extention = extention.substring(1); // remove first character
   
   if (DotIndex>0)
   {
   	  return fn.substring(0,DotIndex)+'.'+extention;
   }
   else
      return fn+'.'+extention;  	
 }

} // end class FileNameManipulator
