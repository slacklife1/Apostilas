package gui;

import javax.swing.*; // JPanel, 
import java.awt.*; // GridLayout
import java.util.*; // LinkedList, Iterator...
import java.io.*; // OutputStream
import java.awt.event.*; // ComponentListener...

import org.w3c.dom.*; // Element, NodeList...

/**
For storing and manipulating a list of definitions
*/
public class DefinitionList extends JPanel
{
  /** Panel listing the definitions */
  protected DefinitionsPanel DPanel;

  /** For manipulating the list of definitions */
  protected ListToolBar tool;

  public DefinitionList()
  {
     setLayout(null);
     DPanel = new DefinitionsPanel();
     tool = new ListToolBar(DPanel);

     add(tool);
     add(DPanel);

     addListeners();
  }

  /** Maintains layout */
  private void addListeners()
  {
     addComponentListener(
      new ComponentAdapter()
      {
         public void componentResized(ComponentEvent e)
         {
           DPanel.setBounds(110,5,getWidth()-10,getHeight()-10);
           tool.UpdateBounds(DefinitionList.this);
         }
      }
     );
  }

  /**
  Writes definitions to the stream
  */
  public void WriteToStream(OutputStream stream)
  {
    DPanel.WriteToStream(stream);
  }

  /** Loads from an XML Element */
  public void LoadFrom(Element e) throws IOException
  {
    if (e==null) throw new IOException(
       "null element sent to DefinitionList::LoadFrom");
    DPanel.LoadFrom(e);
    tool.UpdateDeleteEnabled();

  } // end LoadFrom method

  /** Clears the list of definitions */
  public void Clear()
  {
    DPanel.Clear();
  }

} // end class DefinitionList

class DefinitionsPanel extends JPanel implements ListHandler
{
 /** The definition objects */
 protected LinkedList definitions;

 /** The layout used by this panel */
 protected LayoutManager layout;

 /** For labeling the sections of each Definition */
 protected Definition DefHeader;

 protected JPanel DefinitionListPanel;

  /** Current Index being worked with */
 protected int CurrentIndex;

  public DefinitionsPanel()
  {
    setLayout(null);
    definitions = new LinkedList();
    DefHeader = new Definition(null,null);
    DefinitionListPanel = new JPanel();
    add(DefHeader);
    add(DefinitionListPanel);
    addListeners();
  }

  /** Maintains layout */
  private void addListeners()
  {
     addComponentListener(
      new ComponentAdapter()
      {
         public void componentResized(ComponentEvent e)
         {
           DefHeader.setBounds(5,5,getWidth()-10,20);
           DefinitionListPanel.setBounds(5,30,getWidth()-10,getHeight()-30);
         }
      }
     );
  }

  /** Update GUI to show all elements in definitions list */
  protected void Reindex()
  {
  	SortElements(); // sort the elements
  	
    Iterator it = definitions.iterator();

     layout = new GridLayout(definitions.size(),1);     
     DefinitionListPanel.setLayout(layout);
     DefinitionListPanel.removeAll(); // remove all components from panel


    // loop through each definition
    while (it.hasNext())
    {
      Definition d = (Definition)it.next();
      DefinitionListPanel.add(d);
    }
    repaint();
  }

  /**
   Sorts the list of definitions
  */
  protected synchronized void SortElements()
  {
    // sort definitions using bubblesort
    boolean sorted;
    int len = definitions.size();
    Object a[] = definitions.toArray();
    
   try
   {
     if (len>0) // no point in sorting an empty list
        SortDefinitionArray(a);
    }
    catch (Exception e)
    {
       System.err.println("DefinitionsPanel::SortElements: "+e);	
    }
    // move array into list
    MoveArrayIntoDefinitionsList(a);
  }

  /** Sorts an array of Definition objects */
  private synchronized void SortDefinitionArray(Object a[])
  {
     int index;
     int len = a.length;
     
     boolean sorted;
     do
     {
        sorted = true;

       // loop through elements
       for (index=1;index<len;index++)
       {       
         // if adjacent elements out of order
         if (((Definition)a[index-1]).GreaterThan((Definition)a[index]))
         {
           // swap
           Object t1 = a[index];

            a[index] = a[index-1];
            a[index-1] = t1;
            sorted = false;
            
         } // end if
       } // end for-loop through elements
      } 
      while (!sorted);	
  }

  /** Moves an array of Definitions into definitions list */
  private synchronized void MoveArrayIntoDefinitionsList(Object a[])
  {
     definitions.clear();
     for (int i=0;i<a.length;i++)
        definitions.add(a[i]);	
  }

  /**
  Writes definitions to the stream
  */
  public void WriteToStream(OutputStream stream)
  {
    PrintStream ps = new PrintStream(stream);
    Iterator it = definitions.iterator();

          
     // loop through definitions
     while (it.hasNext())
     {
        Definition d = (Definition)it.next();
        d.WriteToStream(stream);

     } // end while
  }

  /** Loads from an XML Element */
  public void LoadFrom(Element e) throws IOException
  {
    if (e==null) throw new IOException(
        "Null value sent to DefinitionList::LoadFrom");
    NodeList DefinitionL = e.getElementsByTagName("definition");
    if (DefinitionL==null) throw new IOException("Null list of definition elements");
    int len = DefinitionL.getLength();

     Clear(); // clean out all current definitions

     // loop through each Definition
     for (int i=0;i<len;i++)
     {
        Node n = DefinitionL.item(i);
        Definition d = new Definition((Element)n);
          definitions.add(d);

     } // end loop through definition elements

     Reindex(); // update GUI

  } // end LoadFrom method

 /****************************/

  public int getCurrentIndex()
  {
    return CurrentIndex;
  }

  public synchronized int getLength()
  {
    return definitions.size();
  }

  public void setCurrentIndex(int newIndex)
  {
     CurrentIndex = newIndex;
  }

  public void DeleteElement()
  {
    definitions.remove(CurrentIndex);
    CurrentIndex--;
    Reindex();    
  }

  public void InsertElement()
  {
     Definition d = new Definition();
      definitions.add(CurrentIndex,d);
      Reindex();
  }

  /** Clears the list of definitions */
  public void Clear()
  {
    definitions.clear();
    Reindex(); // update GUI to show changes
  }

 /************************************/

}
