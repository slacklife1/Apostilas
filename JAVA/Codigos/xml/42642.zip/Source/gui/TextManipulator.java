/*
Date: Sept. 18
author: Josh Greig


This class can be expanded later to support hyperlinks and other formatting
*/

package gui;


import javax.swing.*; // JTextArea
import java.io.*; // PrintStream, OutputStream

import org.w3c.dom.*; // Document, Node

/**
For manipulating text
*/

public class TextManipulator extends JTextArea
{
  public TextManipulator(String txt)
  {
     super(txt);
  }

  public TextManipulator()
  {
    this("");
  }

  /**
   Writes data into a stream of an XML document 
  */
  public void WriteToStream(OutputStream stream)
  {
     PrintStream ps = new PrintStream(stream);

      ps.println(" <text>");
      ps.println(StringManipulator.formatForXML(super.getText()));
       // replace any special symbols like '<' and '>' to avoid problems

      ps.println(" </text>");
   
  } 

  /** Loads some text from a text node in an XML Document structure */
  private void LoadTextNode(Node tn)
  {
     // loop through nodes
     NodeList nl = tn.getChildNodes();
     int numNodes = nl.getLength();
     String resultingText = super.getText();
     
      for (int i = 0; i<numNodes;i++)
      {
         Node n = nl.item(i);
	 String newTXT = ""+n;
          resultingText = resultingText+""+newTXT;
      }
      setText(StringManipulator.formatXMLToTXT(resultingText.trim()));
  }

  /** Clears everything out */
  public void Clear()
  {
     setText("");
  }

  /**
   Loads from a node
  */
  public void LoadFrom(Node n) throws IOException
  {
    NodeList txtList = n.getChildNodes(); // text nodes
    int len = txtList.getLength();
      
      setText(""); // empty all text from the TextArea
      
      for (int i=0;i<len;i++)
      {
        LoadTextNode(txtList.item(i));
      }

  }

} // end class TextManipulator

