/*
author: Josh Greig
*/
package gui;


import javax.swing.*; // JPanel, JTextField
import java.awt.*; // GridLayout, LayoutManager
import java.io.*; // PrintStream, OutputStream
import java.awt.event.*; // ComponentListener...

import org.w3c.dom.*; // Element, NodeList...

/**
For manipulating a single definition
*/
public class Definition extends JPanel
{
  /** The term being defined */
  protected JComponent term;

  /** The definition of the term */
  protected TextManipulator definition;

  /** label used if this is for a header */
  protected JLabel defLabel;

  /** Initializes with a specified term and definition */
  public Definition(String trm, String def)
  {
     setLayout(null); // don't use a LayoutManager
     if ((trm==null)||(def==null))
     {
        term = new JLabel("Term");
        defLabel = new JLabel("Definition");
        add(defLabel);
     }
     else
     {
        term = new JTextField(trm);
        definition = new TextManipulator(def);
        add(definition);
     }
     add(term);
     addListeners();
  }

  /***/
  private void addListeners()
  {
     addComponentListener(
      new ComponentAdapter()
      {
         public void componentResized(ComponentEvent e)
         {
           term.setBounds(5,3,80,24);
           if (definition!=null)  
              definition.setBounds(90,3,getWidth()-95,getHeight()-6);
           else
               defLabel.setBounds(90,3,getWidth()-95,getHeight()-6);
         }
      }
     );
  }

  /** Initializes prompting user for information */
  public Definition()
  {
    this("","");

     // prompt user for term and definition
    String trm = JOptionPane.showInputDialog(null,"What term?");
     setTerm(trm);

    String define = JOptionPane.showInputDialog(null,"What does it mean?");
     setDefinition(define);
  }

  /** Initializes using data from an XML structure */
  public Definition(Element e) throws IOException
  {
     this("","");
     LoadFrom(e);
  }

  /**
   Writes definition to stream in XML format
  */
  public void WriteToStream(OutputStream stream)
  {
    PrintStream ps = new PrintStream(stream);
    // write definition
    ps.println("  <definition term=\""+getTerm()+"\">");

    // write definition of term
    definition.WriteToStream(stream);

    ps.println("  </definition>");
  }

  /**
   Loads from an XML element
  */
  public void LoadFrom(Element e) throws IOException
  {
     String trm = e.getAttribute("term");
        setTerm(trm);

     // load definition
     definition.LoadFrom(e);

     // load reference links
 
  }

  /** Returns true if and only if this is greater than d( based on ) */
  public boolean GreaterThan(Definition d)
  {
     // compare terms
    return ( getTerm().compareToIgnoreCase(d.getTerm()) > 0 );
  }

  /**
   returns the term being defined
  */
  public String getTerm()
  {
     if (term==null) return "";
     if (term instanceof JLabel)
       return ((JLabel)term).getText();
     else
       return ((JTextField)term).getText();
  }

  /** Sets the term string */
  public void setTerm(String newTerm)
  {
    if (term instanceof JLabel)
      ((JLabel)term).setText(newTerm);
    else
      ((JTextField)term).setText(newTerm);
  }

  /** Sets definition */
  public void setDefinition(String define)
  {
    if (definition==null)
    {
      System.err.println("Definition::setDefinition: definition is null so can't be set");
      return;
    }
    definition.setText(define);
  }

} // end class Definition

