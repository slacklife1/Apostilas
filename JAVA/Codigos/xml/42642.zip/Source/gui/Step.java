/*

____________________________________________
|   |Here explains the step. | detail       |
| 1 |                        | troubleshoot |
=============================================

*/
package gui;


import java.awt.*; // GridLayout
import javax.swing.*;
import java.io.*; // PrintStream
import java.awt.event.*; // ActionListener...

import org.w3c.dom.*;

/**
For manipulating a single step 
*/
public class Step extends JPanel
{
  /** Description of step */
  protected TextManipulator Description;

  /** layout manager for this panel */
  protected LayoutManager layout;

  /** Label to show the index of this step */
  protected JLabel IndexLBL;

  /** For manipulating the links to other pages */
  protected LinksPanel links;

  public Step(int index)   
  {
    IndexLBL = new JLabel(""+index);
    Description = new TextManipulator();
    links = new LinksPanel();

    setLayout(null);
    add(IndexLBL);
    add(Description);
    add(links);
    addListeners();
  } // end Step constructor

  private void addListeners()
  {
     addComponentListener(
      new ComponentAdapter()
      {
         public void componentResized(ComponentEvent e)
         {
           IndexLBL.setBounds(5,5,20,getHeight()-10);
           Description.setBounds(30,3,getWidth()-130,getHeight()-6);
           links.setBounds(getWidth()-100,3,100,getHeight()-6);
         }
      }
     );
  }

  /**
  Initializes to specified index and data from a Node
  */
  public Step(int index,Element e) throws IOException
  {
    this(index);
    LoadFrom(e);
  }

  /**
   Sets index shown in this Step
  */
  public void setIndex(int i)
  {
     IndexLBL.setText(""+i);
  }  

  /**
   Writes this step to a stream in XML format
  */
  public void WriteToStream(OutputStream stream)
  {
    PrintStream ps = new PrintStream(stream);

     ps.println("  <step "+links.toString()+">");
     ps.println("  <explanation>");
     Description.WriteToStream(stream);
     ps.println("  </explanation>");
     ps.println("  </step>");
  }

  /** Loads this Step from a Node */
  public void LoadFrom(Element e) throws IOException
  {
     NodeList ExplanationNodes = e.getElementsByTagName("explanation");

     // set explanation based on explanation node
     if (ExplanationNodes!=null)
     {
       int len = ExplanationNodes.getLength(); 
       if (len>0)
       {
         Node ni = ExplanationNodes.item(0);
          Description.LoadFrom(ni);
       }
       // else no explanation of the step which is weird but not an error
     }
     else
        System.err.println("Step::LoadFrom: unable to get elements from Element");

     // set links based on attributes of this step.
     links.LoadFrom(e);
          
  }

} // end class Step

/**
A panel to store the links to 
*/
class LinksPanel extends JPanel
{
 /** Reference for more detail */
 protected String Details;

 protected ActiveLabel DetailsLBL;

 protected ActiveLabel ProblemsLBL;

 /** Reference for more troubleshooting */
 protected String Troubleshooting;

  public LinksPanel()
  {
     super(new GridLayout(2,1)); // 2 rows, 1 column
     DetailsLBL = new ActiveLabel();
     ProblemsLBL = new ActiveLabel();
     DetailsLBL.addGUIListener(
       new GUIListener()
      {
         public void actionHappened(Object source)
         {
          String newdetails = 
            JOptionPane.showInputDialog(null,"Where is more detail?",Details);
           setMoreDetail(newdetails);
        }
      }
 
      );

     ProblemsLBL.addGUIListener(
       new GUIListener()
      {
         public void actionHappened(Object source)
         {
          String newtroubleshooting = 
            JOptionPane.showInputDialog
          (null,"Where is the troubleshooting resource?",Troubleshooting);
           setProblemLink(newtroubleshooting);
        }
      }
 
      );


     ClearDetails();
     ClearProblems();

     add(DetailsLBL);
     add(ProblemsLBL);
  }    

  /** Loads links from attributes ("moredetail", "problemlink") */
  public void LoadFrom(Element e) throws IOException
  {
     String details = e.getAttribute("moredetail");
       setMoreDetail(details);
     String problem = e.getAttribute("problemlink");
       setProblemLink(problem);
  }

   /**
    Returns string defining the link attributes
   */
  public String toString()
  {
    String result="";
      if (Details!=null) // if detail link is defined
         result = "moredetail=\""+Details+"\"";
      if (Troubleshooting!=null)
         result = result+ "problemlink=\""+Troubleshooting+"\"";
     
     return result;    
  }
 
  /** Clears details address */ 
  private void ClearDetails()
  {
     Details = null;
     DetailsLBL.setText("Details");
  }

  private void ClearProblems()
  {
     Troubleshooting = null;
     ProblemsLBL.setText("Problems");
  }

  /** sets link for getting more detail on this step */
  private void setMoreDetail(String s)
  {
     if (s==null) 
     {
        ClearDetails(); 
        return;
     }
     if (s.length()<2) 
     {
        ClearDetails();
        return;
     }

     Details = s;
     DetailsLBL.setText(s);
  }

  /** Sets link for troubleshooting a problem in this step */
  private void setProblemLink(String problemLink)
  {
     if (problemLink==null) 
     {
       ClearProblems();
       return;
     }
     if (problemLink.length()<2)
     {
       ClearProblems();
       return;
     }
     Troubleshooting = problemLink;
     ProblemsLBL.setText(problemLink);
  }

} // end class LinksPanel
