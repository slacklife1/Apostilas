/**
author: Josh Greig

*/

import javax.swing.*;
import java.awt.event.*; // ActionListener..

public class FileMenu extends JMenu
{
  protected JMenuItem Open1;
  protected JMenuItem Save1;
  protected JMenuItem SaveAs1;  
  protected JMenuItem Exit1;
  protected PDAEditor pEditor;

   public FileMenu(PDAEditor parentEditor)
   {
     super("File");

     this.pEditor = parentEditor;
     Open1 = new JMenuItem("Open");
     Save1 = new JMenuItem("Save");
     SaveAs1 = new JMenuItem("Save As");
     Exit1 = new JMenuItem("Exit");

     addListeners();

     add(Open1);
     add(Save1);
     add(SaveAs1);
     add(Exit1);
   }
   
   /** Adds listeners */
   public void addListeners()
   {
     Open1.addActionListener(
        new ActionListener()
        {
           public void actionPerformed(ActionEvent a)
           {
               pEditor.OpenFile();
           }
        }
       );

      Save1.addActionListener(
        new ActionListener()
        {
           public void actionPerformed(ActionEvent a)
           {
              pEditor.SaveFile();
           }
        }
       );

      SaveAs1.addActionListener(
      	new ActionListener()
      	{
      	   public void actionPerformed(ActionEvent AE)	
      	   {
      	      pEditor.SaveAsFile();	
      	   }	
      	}
      	
      	);

      Exit1.addActionListener(
        new ActionListener()
        {
           public void actionPerformed(ActionEvent a)
           {
              pEditor.setVisible(false);
           }
        }
       );   	
   }
  
  /**
   Disable restricted features
   */ 
  public void DisableRestrictedOptions()
  {
  	Open1.setEnabled(false);
  	SaveAs1.setEnabled(false);
  }

}