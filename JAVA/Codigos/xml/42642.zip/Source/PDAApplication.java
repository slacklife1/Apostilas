/*
author: Josh Greig

*/

import gui.*; // TextManipulator, StringManipulator...
import java.net.*;
import java.io.*; // File...
import javax.swing.*; // JOptionPane...
import java.awt.*; // HeadlessException

/**
Executes the application
*/

public class PDAApplication
{
 /** Number of editors */
 public final static int NUMEDITORS = 3;
 
 /** The editors */
 protected PDAEditor[] Editors = new PDAEditor[NUMEDITORS];

 /** Indexes of an editor */
 protected static final int process=0,IndexPE=1,GlossaryE=2;

 /** The visibility of each frame visibleEditors[n] <=> Editors[n] is visible. */
 private boolean visibleEditors[] = new boolean[3];

 /** Updating flag used to prevent infinitely recursive loops while updating */
 private boolean UpdatingDisplay;

 /** 
 <ul><li>Determines whether or not to print stack traces on exception catching.</li>
  <li>This is true for debugging but usually false when in use.</li>
  <li>This helps with debugging to keep the console somewhat clean</li>
 </ul>
 */
 private boolean PrintStackTracesForExceptions;

 /** Initial Menu Frame */
 private MenuFrame menu;

  /** the frame for managing documentation system replication */
 private StructureReplicator replicator;

 public PDAApplication()
 {
    Editors = new PDAEditor[NUMEDITORS];
    Editors[process] = new ProcessEditor(this);
    Editors[IndexPE] = new IndexPageEditor(this);  
    Editors[GlossaryE] = new GlossaryEditor(this);
    replicator = new StructureReplicator(this);
    menu = new MenuFrame(this);

    PrintStackTracesForExceptions = false; 
 }

 /** Returns true if and only if stack traces are to be printed when Exception's are caught */
 public boolean getPrintStackTracesForExceptions()
 {
   return PrintStackTracesForExceptions;
 }

 /** Shows the StructureReplicator frame */
 public void ShowStructureReplicator()
 {
    replicator.setVisible(true);
 }

 /** Shows/Hides Glossary editor */
 public void setGlossaryVisible (boolean v)
 {
    setEditorVisible(GlossaryE,v);
 }

 /** Shows/Hides Index Page editor */
 public void setIndexPageVisible (boolean v)
 {
    setEditorVisible(IndexPE,v);
 }

 /** Shows/Hides Process editor */
 public void setProcessVisible ( boolean v)
 {
    setEditorVisible(process,v);
 }

 /** Updates visibility of various editors */
 public void UpdateVisibilities()
 {
   if (UpdatingDisplay) return; 
     // don't update anything

   UpdatingDisplay = true;
   // update here

   // loop through editors to update whether or not each is visible
   for (int x=0;x<NUMEDITORS;x++)
   {
      Editors[x].setVisible(visibleEditors[x]);
      Editors[x].UpdateEditorsMenu(visibleEditors);  
   }

   UpdatingDisplay = false;
 }
 
 private String cleanRelativePath(String subdir)
 {
    String result= ""+getClass().getResource("PDAApplication.class").getPath() ;
    int index;
    
    // this is to solve a weird error that was happening(leading '/' before path)
    if (result.charAt(0)=='/')
       result = result.substring(1); // remove first '/'

    result = gui.StringManipulator.replaceStrings(result,"%20", " ");
    index = result.lastIndexOf("/");
     result = result.substring(0,index); // cut last part of file name off

     result = result+"/"+subdir;

    return result;
 }

 /** Returns application path */
 public String getApplicationPath()
 {
    return cleanRelativePath("");
 } 

 /**
  Returns path to help document directory
 */
 public String getHelpPath()
 {
    return cleanRelativePath("Help");
 }

 /**
   Returns the initial path to start searching from
 */
 public String getInitSourcePath()
 {    
    return cleanRelativePath("Data");
 }

 /**
  Returns initial destination path for the replication process 
 */
 public String getInitDestinationPath()
 {
     return cleanRelativePath("Documentation");
 }

 /** Opens the ProcessEditor for creating a new document */
 public void OpenNewProcessDocument()
 {
  ProcessEditor PE = (ProcessEditor)Editors[process];
   PE.StartNewDocument();
   setProcessVisible(true);
 }

 /** Loads specified File into a PDAEditor frame */
 public void LoadIntoEditor(File f)
 {
    // load f
   int FType = PDAEditor.getDocumentType(f,this);

    if (FType<0)
       JOptionPane.showMessageDialog(null,
       "Unable to load because document type is not recognized");
    else
    {
      try
      {
         // load into specified editor
         Editors[FType].LoadFrom(f);
         setEditorVisible(FType,true);
      }
      catch (Exception e)
      {
        System.err.println("PDAApplication::LoadIntoEditor: "+e);
        if (getPrintStackTracesForExceptions())
           e.printStackTrace();
        JOptionPane.showMessageDialog(null,"There was a problem loading the file.  Check console for details");
      }
    } // end if-else
 } // end method LoadIntoEditor

 /** Loads index frame into editor */
 public void ShowIndexFrame()
 {
     ShowSpecifiedFrame(getInitSourcePath()+"/index.xml",IndexPE);
 }

  /** Loads glossary into editor */
  public void ShowGlossaryFrame()
  {
     ShowSpecifiedFrame(getInitSourcePath()+"/glossary.xml",GlossaryE);
  }

  /** Hides an editor specified by reference */
  public void Hide(PDAEditor PDAE)
  {
    // loop through editors
   int index;

    for (index=0;index<NUMEDITORS;index++)
    {
       if (Editors[index]==PDAE) // if found
       {
         setEditorVisible(index,false);
         break;
       } // end if

    } // end for
    if (index==NUMEDITORS) // if not found
    {
      JOptionPane.showMessageDialog(null,"PDAApplication::Hide: Editor not found");
    }
  }

  /**
   Shows a frame after loading the specified file into it.  If the load fails due to the throwing of an exception,
    the user is prompted to confirm continuing to view the frame 
   @param fn is the name of file being loaded
   @param frameNumber is the index into the Editors array of this application that is the frame being shown
  */
  private void ShowSpecifiedFrame(String fn,int frameNumber)
  {
    // load into frame
    File f = new File(fn);
    boolean showFrame=true;
    try
    {
      Editors[frameNumber].LoadFrom(f);
    }
    catch (Exception e)
    {
      System.err.println("PDAApplication::ShowSpecifiedFrame: file is "+fn);
      if (getPrintStackTracesForExceptions())
         e.printStackTrace();
      try
      {
      int result=JOptionPane.showConfirmDialog
        (null,"There was a problem loading the file.  Would you like to continue?");
       if (result!=JOptionPane.YES_OPTION )
          showFrame = false;
      }
      catch (HeadlessException HE)
      { // exception during confirm dialog showing
        System.err.println("PDAApplication: "+HE);
      }
    }
    if (showFrame)
    {
      Editors[frameNumber].setOpenFileName(fn);
      setEditorVisible(frameNumber,true);
    }
  }

 /** Sets visibility of a specified editor */
 private void setEditorVisible(int index, boolean v)
 {
    visibleEditors[index]=v;
    UpdateVisibilities();
 }

} // end class PDAApplication



