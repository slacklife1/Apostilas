<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<form name="form1" method="post" action="add-comment.php">
  <div align="center"><font face="Geneva, Arial, Helvetica, san-serif" size="2">Name: 
    <input type="text" name="name" value="Your Name Here">
    Comment: 
    <input type="text" name="comment" value="Your Comment">
    Url: 
    <input type="text" name="url" value="Your Web Site">
    <input type="submit" name="Submit" value="Submit">
    </font> </div>
</form>
</body>
</html>
