<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<frameset rows="65,*" frameborder="NO" border="0" framespacing="0" cols="*"> 
  <frame name="main" scrolling="NO" noresize src="form.php" >
  <frame name="centerFrame" src="1.php">
</frameset>
<noframes>
<body bgcolor="#FFFFFF" text="#000000">
</body>
</noframes> 
</html>
