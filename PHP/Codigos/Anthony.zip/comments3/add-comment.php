<html>
<head>
<title> Thanks You</title>
</head>
<body>
<?php 
function WriteToFile ($comment) {
$TheFile = "comments.txt";
$Open = fopen($TheFile, "a");
if ($Open) {
	fwrite ($Open, "$comment\n");
	fclose ($Open);
	return true;
} else { 		
	return false;
}
} 

$CallFunction = WriteToFile ("$name <BR><a href=\"$url\">My Site</a> <BR> $comment <HR>");
if ($CallFunction) { ?><a href="1.php" target="centerFrame"> Click Here to view your comment</a>
<?
}
?>
</body
</html>