<?php
header ("Cache-Control: no-cache, must-revalidate");  // HTTP/1.1
header ("Pragma: no-cache");                          // HTTP/1.0

########Begin Config############
include "connect.inc";
//$authorize=true;								//comment out if you don't want user 
												//to be logged in

$table="1";                                     //set this to 1 if you would
                                                //prefer that the list of
                                                //records appere in a table
                                                //instead of a listbox

$status = "New,Hold Off,Important,Priority 1,Priority 2,Priority 3,Done";
												//possible statuses list with
												//no spaces
$statusAbreviations = "N,H,I,P1,P2,P3,X";

//---Interface Settings----//
$tableborder=1;
$boldFontColor="000099";
$normalFontColor="666666";
$fontFace = "Arial, Helvetica";
$fontSize = "-1";
$background0="99ffcc";
$background1="00cccc";

$completedYes = "<img src=circleChecked.gif border=0>"; 							//can be any html syntax
$completedNo = "<img src=circle.gif border=0> ";

//---Interface Settings---//

/**************************************
Pasted this in top of all functions to get 
colors
global $tableborder;
global $boldFontColor;
global $normalFontColor;
global $fontFace;
global $fontSize;
global $background0;
global $background1;
**************************************/

########End Config##############
$debug=0;

if($authorize == true)
{
	include "authorize.inc";
}
else
{
	$userID="Single User";
}



//BEGIN FUNCTIONS
//---------------------------------------------------------------------------
function print_header()
{
	global $table;
	global $tableborder;
	global $boldFontColor;
	global $normalFontColor;
	global $background0;
	global $background1;
	global $fontFace;
	global $fontSize;
	global $table;
	global $userID;
	global $hideNotes;
	
	print "
	<html>
	<head>
	<title>To Do List</title>
	</head>
	<body bgcolor=\"#FFFFFF\" topmargin=0 leftmargin=0>
	";
	$sql="select * from notes where userid='$userID' order by name";
	$result=mysql_query($sql);
	print "	
	<font face=\"$fontFace\" size=$fontSize color=$normalFontColor>
	<table width=100 bgcolor=$background1 border=$tableborder align='left'>
	<tr><td colspan=6>
		<table width=100% border=0 bgcolor=$background0 cellpadding=0 cellspacing=0><tr>
		<td>
		<font face=\"$fontFace\" size=$fontSize color=$boldFontColor><b><img src=KeepinTrack.gif><br>
		User: $userID</b></font>
		</td>
		<td align=right valign=top>
	";
	
	if($hideNotes=="true")
		print "<font face=\"$fontFace\" size=$fontSize color=$boldFontColor><b><a href=$PHP_SELF?action=hideNotes><img src=downArrow.gif border=0></a></b></font>";
	else
		print"
			<font face=\"$fontFace\" size=$fontSize color=$boldFontColor><b><a href=$PHP_SELF?action=hideNotes><img src=upArrow.gif border=0></a></b></font>";

	print "
		</td>
		</tr></table>
		
	</td></tr>
	 ";

}

function print_footer()
{
	global $tableborder;
	global $boldFontColor;
	global $normalFontColor;
	global $fontFace;
	global $fontSize;
	global $PHP_SELF;
	
	print "</td></tr>
	<tr><td align=center>
	<font size=-2><a href=\"javascript: popUP()\">Popup</a></font>
	</td></tr>
	</table>
	<script language=javascript>
	function popUP()
	{
	this.open(\"$PHP_SELF\", \"CtrlWindow\", \"width=225,height=450,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=no\")
	}
	</script>
	<P>
	</font>
	</body>
	</html>

	";
}

function print_all_notes()
{
global $table;
global $tableborder;
global $boldFontColor;
global $normalFontColor;
global $fontFace;
global $fontSize;
global $PHP_SELF;
global $hideNotes;
global $userID;
global $completedYes;
global $completedNo;

$sql="select * from notes where userid='$userID' order by date";
$result=mysql_query($sql);
if ($table == "1") 
{
 
 if($hideNotes != "true")
 {
 	while($myrow=mysql_fetch_array($result))
 	{
		$userid=stripslashes($myrow["name"]);
		$id=$myrow["id"];
		$date = $myrow["date"];
		$abstract = substr($myrow["note"], 0, 50);

		if($myrow["expired"] == "Y")
			$completed = "<a href=$PHP_SELF?action=uncomplete&id=$id>$completedYes</a>";
		else
			$completed = "<a href=$PHP_SELF?action=complete&id=$id>$completedNo</a>";
			
		print "
		<tr><td>
			<table border=0 cellspadding=2>
			<tr>
			<td width=25>
				<font face=\"$fontFace\" size=$fontSize color=$normalFontColor><a href='$PHP_SELF?select=$id'>"  . formatShortDate($date,"/") . "</a>
			</td>
			<td>
				<font face=\"$fontFace\" size=$fontSize color=$normalFontColor>
				" . $abstract . "
			</td>
			<td width=10>
				<font face=\"$fontFace\" size=$fontSize color=$normalFontColor>
				" . statusAb($myrow["status"]) . "
			</td>
			<td width=25>
				<font face=\"$fontFace\" size=$fontSize color=$normalFontColor>
				<a href=$PHP_SELF?action=complete&id=$id>$completed</a>
			</td>
			</tr></table>
		</td></tr>";
  	}
  }
}

if ($table == "0") 
{ 
	print "</form>";  
}
print "<br><tr><td>";

}


function print_new_note() 
{
	global $edit;
	global $PHP_SELF;
	global $userID;
	global $tableborder;
	global $boldFontColor;
	global $normalFontColor;
	global $fontFace;
	global $fontSize;
	global $status;
	
	if($edit)
	{
		$result=mysql_query("Select * from notes where id='$edit'");
		$myrow=mysql_fetch_array($result);
		$note=stripslashes($myrow["note"]);
		$date=stripslashes($myrow["date"]);
		$id=stripslashes($myrow["id"]);
		$name=stripslashes($myrow["userid"]);
		$thisStatus = stripslashes($myrow["status"]);

		if($debug > 0) print "this status = $thisStatus";
		
	}
	//print the blank page to add a record
	print "
	<tr><td>
	<form name=newNote action=$PHP_SELF method=get>
	<font face=$fontFace size=$fontSize color=$normalFontColor>
	<input type=hidden name=userid value=$userID>
	<input type=hidden name=id value=$id>
	<center>
	<textarea name=message cols=20 rows=5	wrap=VIRTUAL>$note</textarea>
	<select name=selectedStatus>
	";

	$stats = explode(",", $status);

	$i=0;
	while($stats[$i])
	{
		if($thisStatus == $stats[$i])
			print "<option selected value=\"" . $stats[$i] . "\" >" . $stats[$i] . "</option>\n";
		else
			print "<option select value=\"" . $stats[$i] . "\" >" . $stats[$i] . "</option>\n";
		$i++;
	}
	
	print "
	</select>
	
	<input type=submit name=pleasedo value=Add></center>
	</form>
	</td></tr>
";

}

function print_note($sql,$PHP_SELF)
{
	global $tableborder;
	global $boldFontColor;
	global $normalFontColor;
	global $fontFace;
	global $fontSize;

	if ($table == "") 
	{ 
		$table="0"; 
	}

	//connect to the database
	$result=mysql_query($sql);
	$myrow=mysql_fetch_array($result);
	$note=stripslashes($myrow["note"]);
	$date=stripslashes($myrow["date"]);
	$id=stripslashes($myrow["id"]);
	$name=stripslashes($myrow["name"]);
	//print out note

	
	print "
	<tr><td>
	<font face=\"$fontFace\" size=$fontSize color=$boldFontColor><b>" . formatDate($date, "-") . "<br></B></FONT>
	<font face=\"$fontFace\" size=$fontSize color=$normalFontColor>
	$note<br>
	</font>
	<center>
	<font size=-2>
	<a href=$PHP_SELF?edit=$id>Edit</a> - <a href=$PHP_SELF?action=Delete&id=$id>Delete</a>
	</center>
	</td></tr>
	";
}

function save($message,$userid,$id, $status) 
{
	global $debug;
	
	if($userid == "")
		return -1;
	else
	{
		$day = date("Y-m-d");
		$time = date("H:i:s");
		$message=addslashes($message);
		$name=addslashes($userid);
		if($id == "")
			$sql="insert into notes (note, date, time, userid, status) VALUES ('$message','$day','$time', '$userid', '$status')";
		else
			$sql="update notes set note='$message', date='$day', time='$time', status='$status', userid='$userid' where id='$id'";

		if($debug > 0) print $sql . "<br>";

		$result=mysql_query($sql);
	}
}

function delete_record($id) 
{
	//delete a record
	if($id=="")
		return -1;
	else
	{
		$sql="delete from notes where id = '$id'";
		$result=mysql_query($sql);
	
	}
}

function formatDate($date, $delimiter)
{
	$day = explode("-", $date);
	
	return "" . $day[1] . "$delimiter" . $day[2] . "$delimiter" . $day[0];
}

function formatShortDate($date, $delimiter)
{
	$day = explode("-", $date);
	
	return "" . $day[1] . "$delimiter" . $day[2];
}

function statusAb($stat)
{
	$allStat = explode(",", $status);
	$allStatAb = explode(",", $statusAbreviations);
	
	for($i=0;$allState[$i] != "";$i++)
	{
		if($allState[$i] == $stat)
			return $allStatAb[$i];
	}
}

//END FUNCTIONS
//--------------------------------------------------------------
//--------------------------------------------------------------

if ($select != "")
{
    //fetch the record with the name passed
	print_header();
    print_note("select * from notes where id = '$select'",$PHP_SELF);
	print_all_notes();
	print_new_note();
	print_footer();
	return;
}

if($edit != "")
{
	print_header();
	print_new_note();
	print_footer();
	return;
}

if($action == "Delete")
{
	delete_record($id);
}

if ($pleasedo == "Add" || $message != "") 
{
	//assumes message, and userid have been passed in
	if($debug > 0) print "USER: $userid - $userID<br>";
	save($message,$userID,$id,$selectedStatus);
}

if($action == "Save")
{
	print "trying to save note<br>";
	save_note($message, $userid, $id, $selectedStatus);
	print_header();
	print_all_notes();
	print_new_note();
	print_footer();
	return;

}

if($action == "hideNotes")
{
	if($hideNotes == "true")
	{
		setcookie("hideNotes", "");
		$hideNotes="";
	}
	else
	{
		setcookie("hideNotes", "true");
		$hideNotes=true;
	}
}

if($action == "complete")
{
	$sql = "Update notes set expired = 'Y' where id='$id'";
	
	mysql_query($sql);
}

if($action == "uncomplete")
{
	$sql = "Update notes set expired = 'N' where id='$id'";
	
	mysql_query($sql);
}

//BUILD DEFAULT PAGE
print_header();

print_all_notes();
print_new_note();
print_footer();
//END DEFAULT PAGE
//---------------------------------------------------------------