*******************************************************
Created by Markus Beamer
www.mobeamer.com
GNU Licensed
*******************************************************

INSTALLATION
To install keeping track create a notes table with the following
specs:

create table notes(
id int not null auto_increment,
note blob not null,
date date,
userid varchar(50),
time time,
status varchar(50),
UNIQUE(id)
);

Open connect.inc and set the login variables at the top 
of the scripts to the correct values

Place todo.php and connect.inc in the same directory 
and your all done.

CHANGING COLORS
open todo.php and modify the interface settings, you can 
use any html colors or image tags

MULTIPLE USERS
To enable login module set authorize to false in the 
todo.php

Note you will have to follow instructions in loginreadme.




