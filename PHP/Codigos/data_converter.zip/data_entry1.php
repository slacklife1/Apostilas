<?
$datafile = fopen("data.txt","r");    //open data file in read mode

$colums=explode("\t",fgets($datafile,4096));    //split the first row on tabs

$table_fields[count($colums)][2]; //define a two dim. array of x rows and 3 col where x = total no. of cols

for($i=0; $i < (count($colums));$i++) //run the loop x no. of times
    {
      $temp_arr=explode(",",$colums[$i]); // split each splited value and store in temp array

    for($j=0 ; $j < 3 ; $j++) // run a loop 3 times
        {
        if ($j==0)
            {
            $table_fields[$i][0] = $i; //asign positional value to each row
            }
        else
            {
            $table_fields[$i][$j] = $temp_arr[$j-1]; // asign table name and colum names
            }
        }
    }

$temp_table_arr[count($colums)]; //create another array of size x

for($i = 0; $i < (count($colums));$i++)
    {
    $temp_table_arr[$i]=$table_fields[$i][1].",".$table_fields[$i][0];// put table name and positional values seprated by comma
    }

sort($temp_table_arr); //sort the latest array

/*
next for loop go through the sorted array and
create another array which store only one row per table
and all the positions associated with that table
seprated by commas
*/

for($i = 0; $i < (count($colums));$i++)
    {
    if (substr($temp_table_arr[$i],0,(strpos($temp_table_arr[$i],",")))!=substr($temp_table_arr[$i-1],0,(strpos($temp_table_arr[$i-1],","))))
        {
        if ($i != 0)
            {
            if ($count=="")
                {$count=0;}
            $table_arr[$count][0]=substr($temp_table_arr[$i-1],0,(strpos($temp_table_arr[$i-1],",")));
            $table_arr[$count][1]=$str;
            $count++;}
        $str=substr($temp_table_arr[$i],(strpos($temp_table_arr[$i],","))+1,strlen($temp_table_arr[$i]));
        }
    else
        {
        $str=$str.",".substr($temp_table_arr[$i],(strpos($temp_table_arr[$i],","))+1,strlen($temp_table_arr[$i]));
        }
    }
    $table_arr[$count][0]=substr($temp_table_arr[$i-1],0,(strpos($temp_table_arr[$i-1],",")));
    $table_arr[$count][1]=$str;

while (!feof($datafile))
    {
    $values=explode("\t",fgets($datafile,4096));

    for($i = 0; $i < (count($table_arr));$i++)
        {
        $str="Insert into ".$table_arr[$i][0]." (";

        $cols =explode(",",$table_arr[$i][1]);


        for ($j=0;$j < count($cols); $j++)
        {
        if ($j != 0)
            {$str=$str.",".$table_fields[$cols[$j]][2];}
        else
            {$str=$str.$table_fields[$cols[$j]][2];}
        }

        $str=$str.") values ('";

        for ($j=0;$j < count($cols); $j++)
            {
            if ($j != 0)
                {$str=$str."','".$values[$cols[$j]];}
            else
                {$str=$str.$values[$cols[$j]];}
            }
            $str=$str."')";
        echo $str."<br>";
        }

/*
        $sql = "Insert into testtable(".$colum_name .") values('";

        $colum_value=implode("','",$colums);

        $sql=$sql.$colum_value."')";
        odbc_exec($conn,$sql);
        echo $sql."<br>";
*/
    }

?>