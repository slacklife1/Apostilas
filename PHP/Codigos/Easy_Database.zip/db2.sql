
create database testbase;
use testbase;
create table Namen
(
    Nr             int  auto_increment  not null,
    Name           varchar( 30)                 ,
    Vorname        varchar( 30)                 ,
    EMAIL          varchar( 50)                 ,
    primary key    (Nr)
);

alter table Namen
add index l_msg_id (Nr);
