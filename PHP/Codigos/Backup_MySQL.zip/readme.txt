
		Code Submitted by: Keyur Itchhaporia.
		Date: 10th Sep, 2002
		Functionality of code:Backup Mysql Database (With Structure and Data)
		
		Tips:
		
		Replace following variables:
		
		databaseserver = The machine on which your database is residing.
		username = database username
		password = database password
		databasename = the name of database to backup.
		
		The Following code is taken from phpmyadmin and is altered for easy understanding.
		
		if you find any bug please mail me at itchhaporia@msn.com / keyur_i_1999@yahoo.com
		
		Suggestions most welcomed.
	
	
