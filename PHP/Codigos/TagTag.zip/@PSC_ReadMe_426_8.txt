Title: TagTag 1.1
Description: TagTag 1.1 gives various bug fixes and code improvements over the 1.0 edition. TagTag is a web graffiti toy, whereby users are able to 'tag' your website with their message.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=426&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
