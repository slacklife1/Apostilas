<?php

/*---------------------------------------------------
            	user to user messenger	             
            		version 2	             
            	   Copyright 2002 	             
            	   Cornelius Herzog	             
                cornelius.herzog@gmx.de	             
-----------------------------------------------------
       This script is free, as long its not in       
                     commercial use	             
          otherwise you have to pay for it           
-----------------------------------------------------
    Dieses Skript ist kostenlos, solange es	     
      	  nicht kommerziell benutzt wird	     
       	ansonsten muss daf�r bezahlt werden	     
---------------------------------------------------*/


include("include.inc.php");
$query = getenv("QUERY_STRING");
parse_url($query);

if($action == "showsmilies") {
$bodycontent='<table border=1>
<tr>
	<td><img src="smilies/s_lookup.gif" alt="" border="0"></td>
	<td><img src="smilies/s_smoke.gif" alt="" border="0"></td>
	<td><img src="smilies/s_blink.gif" alt="" border="0"></td>
	<td><img src="smilies/s_show.gif" alt="" border="0"></td>
	<td><img src="smilies/s_laugh.gif" alt="" border="0"></td>
	<td><img src="smilies/s_angryblink.gif" alt="" border="0"></td>
	<td><img src="smilies/s_flash.gif" alt="" border="0"></td>
</tr>
<tr>
	<td>'.message("s_lookup").'</td>
	<td>'.message("s_smoke").'</td>
	<td>'.message("s_blink").'</td>
	<td>'.message("s_show").'</td>
	<td>'.message("s_laugh").'</td>
	<td>'.message("s_angryblink").'</td>
	<td>'.message("s_flash").'</td>
</tr>
<tr>
	<td><img src="smilies/s_help.gif" alt="" border="0"></td>
	<td><img src="smilies/s_wave.gif" alt="" border="0"></td>
	<td><img src="smilies/s_sad.gif" alt="" border="0"></td>
	<td><img src="smilies/s_dance.gif" alt="" border="0"></td>
	<td><img src="smilies/s_oh.gif" alt="" border="0"></td>
	<td><img src="smilies/s_alien.gif" alt="" border="0"></td>
	<td><img src="smilies/s_love.gif" alt="" border="0"></td>
</tr>
<tr>
	<td>'.message("s_help").'</td>
	<td>'.message("s_wave").'</td>
	<td>'.message("s_sad").'</td>
	<td>'.message("s_dance").'</td>
	<td>'.message("s_oh").'</td>
	<td>'.message("s_alien").'</td>
	<td>'.message("s_love").'</td>
</tr>
<tr>
	<td><img src="smilies/s_ok.gif" alt="" border="0"></td>
	<td><img src="smilies/s_loveyou.gif" alt="" border="0"></td>
	<td><img src="smilies/s_cool.gif" alt="" border="0"></td>
	<td><img src="smilies/s_devil.gif" alt="" border="0"></td>
	<td><img src="smilies/s_smile.gif" alt="" border="0"></td>
	<td><img src="smilies/s_bad.gif" alt="" border="0"></td>
	<td><img src="smilies/s_good.gif" alt="" border="0"></td>
</tr>
<tr>
	<td>'.message("s_ok").'</td>
	<td>'.message("s_loveyou").'</td>
	<td>'.message("s_cool").'</td>
	<td>'.message("s_devil").'</td>
	<td>'.message("s_smile").'</td>
	<td>'.message("s_bad").'</td>
	<td>'.message("s_good").'</td>
</tr>
<tr>
	<td><img src="smilies/s_shy.gif" alt="" border="0"></td>
	<td><img src="smilies/s_danger.gif" alt="" border="0"></td>
	<td><img src="smilies/s_annoyed.gif" alt="" border="0"></td>
	<td><img src="smilies/s_question.gif" alt="" border="0"></td>
	<td><img src="smilies/s_laughtwo.gif" alt="" border="0"></td>
	<td><img src="smilies/s_grin.gif" alt="" border="0"></td>
</tr>
<tr>
	<td>'.message("s_shy").'</td>
	<td>'.message("s_danger").'</td>
	<td>'.message("s_annoyed").'</td>
	<td>'.message("s_question").'</td>
	<td>'.message("s_laughtwo").'</td>
	<td>'.message("s_grin").'</td>
</tr>
</table>
';
echo makepage("",$cssonline,"",$bodycontent,$sid);
}

if($action == "sendmsg") {
session_register("name");
	$db = connect_database();
	$erg = mysql_db_query($db_name,$cmd,$db);
	
	$subject = stripcslashes($subject);
	$message = stripcslashes($message);								
	$message = strip_tags($message,"<a><b><i><u><br><p><img><center><font><table><tr><td>");
	$message = str_replace(chr(10),"<br>",$message);
	$message = str_replace(chr(13),"<br>",$message);
	$message = str_replace("<br><br>","<br>",$message);
	
	if($sendbymail) {
		$cmd = "SELECT `email` FROM `user` WHERE `name`='$name' AND `sid`='$sid';";
		$erg = mysql_db_query($db_name,$cmd,$db);
		$result = mysql_fetch_row($erg);
		$header = "From:$name<$result[0]>\n";
		$header .= "X-Mailer: user 2 user messenger";
		$header .= "X-Sender-IP: $REMOTE_ADDR\n";	
		$header .= "Content-Type: text/html";
		$cmd = "SELECT `email` FROM `user` WHERE `name`='$to';";
		$erg = mysql_db_query($db_name,$cmd,$db);
		$result = mysql_fetch_row($erg);
		@mail($result[0], message("message") . " " . message("from"). " " . $name ,$message,$header);
	}
	if($readconfirm) {
	$readconfirm = "yes";
	}else{
	$readconfirm = "no";
	}
	$thislinkid = md5(microtime());
	$cmd = "INSERT INTO `message` (`id`, `read`, `show`, `from`, `to`, `subject`, `msg`, `time`, `readconfirm`, `sr`,`linkid`) VALUES ('', 'no', 'no', '$name', '$to', '$subject', '$message', NOW(NULL), 'no', 's','$thislinkid');";
	$erg = mysql_db_query($db_name,$cmd,$db);
	$cmd = "INSERT INTO `message` (`id`, `read`, `show`, `from`, `to`, `subject`, `msg`, `time`, `readconfirm`, `sr`,`linkid`) VALUES ('', 'no', 'no', '$name', '$to', '$subject', '$message', NOW(NULL), '$readconfirm', 'r','$thislinkid');";
	$bodycontent = '<script language="JavaScript" type="text/javascript">
									function closethis() {
								window.close();
							}
							window.setTimeout("closethis()",3000);

	</script>' . message("msgsent");
	echo makepage("",$cssonline,"",$bodycontent,"");
	$erg = mysql_db_query($db_name,$cmd,$db);
	mysql_close($db);
}


if($action == "writemsg") {
$bodycontent = "<h3>".message("sendmsgto")." $to</h3>";
$bodycontent.= '<form action="online.php?action=sendmsg&sid='.$sid.'" method="post" name="messageform" id="messageform">
'.message("subject").':<br><input type="Text" name="subject"><br>'.message("message").':<br>
					<textarea cols="40" rows="12" name="message"></textarea><br>
					<input type="checkbox" name="readconfirm" value="readconfirm">'.message("getreadconfirm").'</input><br>
					<input type="checkbox" name="sendbymail" value="sendbymail">'.message("sendbymail").'</input>
					<input type="hidden" name="to" value="'.$to.'"><br>
					<input type="submit" name="submit" value="'.message("send").'"><br>
					'.message("allowtags").'<br>'.message("usesmilies").'<a href="online.php?action=showsmilies" target="_blank"> '.message("here").'</a>
				</form>';
echo makepage("",$cssonline,"",$bodycontent,$sid);
}




if($action == "deletefriend") {
session_register("name");
$db = connect_database();
$cmd = "SELECT `friends` FROM `user` WHERE `name` ='$name' AND `sid` ='$sid';";
$erg = mysql_db_query($db_name,$cmd,$db);
$result = mysql_fetch_row($erg);
$friends = explode("|",$result[0]);
$where = array_search($friend,$friends);
$vorne = array_slice($friends,0,$where);
$a = $where +1;
$hinten =array_slice($friends,$a);
$newfriends = array_merge($hinten,$vorne);
$friends = join("|",$newfriends);
$cmd = "UPDATE `user` SET `friends`='$friends' WHERE `name`='$name' AND `sid`='$sid';";
$erg = mysql_db_query($db_name,$cmd,$db);
$bodycontent = message("frienddeleted") . "<br><a href='online.php?action=showmyfriends&sid=$sid'>".message("continue")."</a>";
echo makepage("",$cssonline,"",$bodycontent,$sid);
mysql_close($db);
}


if($action == "showmyfriends") {
session_register("name");
$db = connect_database();
$cmd = "SELECT `friends` FROM `user` WHERE `name` ='$name' AND `sid` ='$sid';";
$erg = mysql_db_query($db_name,$cmd,$db);
$result = mysql_fetch_row($erg);
$friends = explode("|",$result[0]);
$bodycontent = "<h3>".message("myfriends")."</h3>";
$bodycontent.="<table border=\"1\" style=\"border-collapse: collapse\" bordercolor=\"#c0c0c0\">
<tr>
	<td><b>".message("name")."</b></td>
	<td><b>".message("userstate")."</b></td>
	<td><b>".message("sendmsg")."</b></td>
	<td><b>".message("deletefriend")."</b></td>
</tr>
";
if($friends[0] == "") {
array_shift($friends);
}
for($x=0;$x<sizeof($friends);$x++) {
$cmd = "SELECT `status` FROM `user` WHERE `name` ='$friends[$x]';";
$erg = mysql_db_query($db_name,$cmd,$db);
$result = mysql_fetch_row($erg);
$bodycontent.="<tr>
	<td><a href=\"online.php?action=userstatus&sid=$sid&user=$friends[$x]\">$friends[$x]</a></td>
	<td>$result[0]</td>
	<td><a href=\"online.php?action=writemsg&to=$friends[$x]&sid=$sid\"><img src=\"letter.gif\" alt=\"Send message to this friend\" width=\"30\" height=\"20\" border=\"0\"></a></td>
	<td><a href=\"online.php?action=deletefriend&friend=$friends[$x]&sid=$sid\"><img src=\"delete.gif\" alt=\"Delete this friend\" width=\"18\" height=\"18\" border=\"0\"></a></td>
</tr>
";
}
$bodycontent.="</table>";
echo makepage("",$cssonline,"",$bodycontent,$sid);
mysql_close($db);
}

if($action == "addfriend") {
	session_register("name");
	$db = connect_database();
	$cmd = "SELECT `friends` FROM `user` WHERE `name` ='$name' AND `sid` ='$sid';";
	$erg = mysql_db_query($db_name,$cmd,$db);
	$result = mysql_fetch_row($erg);
	$friends = $result[0];
	if(stristr($friends,$friend)) {
		echo makepage("",$cssonline,"",message("alreadyyourfriend"),$sid);
	}else{
		$friends.="|$friend";
		$cmd = "UPDATE `user` SET `friends`='$friends' WHERE `name`='$name' AND `sid`='$sid';";
		$erg = mysql_db_query($db_name,$cmd,$db);
		echo makepage("",$cssonline,"",message("addedtocontactlist"),$sid);
	}
	mysql_close($db);
}

if($action == "deletemsg") {
	$db = connect_database();
	session_register("name");
	$cmd = "SELECT * FROM `message` WHERE `id` ='$id' AND `sr` ='$sr';";
	$name_s = strtolower($name);
	$erg = mysql_db_query($db_name,$cmd,$db);
	list($id,$read,$show,$from,$to,$subject,$msg,$time,$readconfirm,$sr)=mysql_fetch_row($erg);
	if($sr == "s") {
		if(strtolower($from) != $name_s) {
			echo makepage("",$cssonline,"",message("notforyou"),$sid);
			mysql_close();	
			die();
		}
		}else{
		if(strtolower($to) != $name_s) {
			echo makepage("",$cssonline,"",message("notforyou"),$sid);
			mysql_close();	
			die();
		}	
	}
	$cmd = "DELETE FROM `message` WHERE `id`='$id' AND `sr`='$sr';";
	$erg = mysql_db_query($db_name,$cmd,$db);
	if(!$erg) {
		$bodycontent.=message("error") . mysql_error();	
	}else{
		$bodycontent.=message("deleted");	
	}
	if($sr == "s") {
		$bodycontent.="<br><a href='online.php?action=showoutbox&sid=$sid&orderby=`time` asc'>".message("continue")."</a>";
	}else{
		$bodycontent.="<br><a href='online.php?action=showinbox&sid=$sid&orderby=`time` asc'>".message("continue")."</a>";
	}
	mysql_close();
	echo makepage("",$cssonline,"",$bodycontent,$sid);
}


if($action == "askdelete") {
	$bodycontent = message("wanttodelete"). "<br><a href=\"online.php?action=deletemsg&id=$id&sid=$sid&sr=$sr\">".message("yes")."</a>";
	$bodycontent.="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"#\" onclick=\"history.back();\">".message("no")."</a>";
	echo makepage("",$cssonline,"",$bodycontent,$sid);
}

if($action =="showoutbox") {
	$db = connect_database();
	session_register("name");
	$cmd = "SELECT * FROM `message` WHERE `from` ='$name' AND `sr` ='s' ORDER BY $orderby;";
	if(stristr($orderby,"asc")) {
		$thisorderdirection = "desc";
	}else{
		$thisorderdirection = "asc";
	}
	if(stristr($orderby,"to")) {
		$thisorderimg[to] = '<img src="'.$thisorderdirection.'_order.gif" alt="" width="7" height="7" border="0">';
	}
	if(stristr($orderby,"subject")) {
		$thisorderimg[subject] = '<img src="'.$thisorderdirection.'_order.gif" alt="" width="7" height="7" border="0">';
	}
	if(stristr($orderby,"time")) {
		$thisorderimg[timestamp] = '<img src="'.$thisorderdirection.'_order.gif" alt="" width="7" height="7" border="0">';
	}
	$bodycontent.= "<h3>".message("outbox")."</h3><table border=\"1\" style=\"border-collapse: collapse\" bordercolor=\"#c0c0c0\" width=\"100%\">
	<tr>
		<td><b>".message("readunreadfromr")."</b></td>
		<td><b><a href=\"online.php?action=showoutbox&sid=$sid&orderby=`to` $thisorderdirection\">".message("to")."$thisorderimg[to]</a></b></td>
		<td><b><a href=\"online.php?action=showoutbox&sid=$sid&orderby=`subject` $thisorderdirection\">".message("subject")."$thisorderimg[subject]</b></td>
		<td><b><a href=\"online.php?action=showoutbox&sid=$sid&orderby=`time` $thisorderdirection\">".message("timestamp")."$thisorderimg[timestamp]</b></td>
		<td><b>".message("delete")."</b></td>
	</tr>";
	$erg = mysql_db_query($db_name,$cmd,$db);
	echo mysql_error();
	while(list($id,$read,$show,$from,$to,$subject,$msg,$time,$readconfirm,$sr)=mysql_fetch_row($erg)) {
		$thistimestamp = datumwandler($time);
		if($read == "yes") {
			$thisread=message("yes");
		}else{
			$thisread=message("no");
		}
		$bodycontent.= "<tr>
			<td><a href=\"online.php?action=showmsg&idm=$id&sid=$sid\">$thisread</a></td>
			<td><a href=\"online.php?action=showuserstatus&user=$from&sid=$sid\">$to</a></td>
			<td>$subject</td>
			<td>$thistimestamp</td>
			<td><a href=\"online.php?action=askdelete&sid=$sid&id=$id&sr=$sr\"><img src=\"delete.gif\" alt=\"Deletes this message\" width=\"18\" height=\"18\" border=\"0\"></a></td>
		</tr>";
	}
	mysql_close($db);
	$bodycontent.="</table>";
	echo makepage("",$cssonline,'',$bodycontent,$sid);
}

if($action =="showinbox") {
	$db = connect_database();
	session_register("name");
	$cmd = "SELECT * FROM `message` WHERE `to` ='$name' AND `sr` ='r' ORDER BY $orderby;";
	if(stristr($orderby,"asc")) {
		$thisorderdirection = "desc";
	}else{
		$thisorderdirection = "asc";
	}
	if(stristr($orderby,"from")) {
		$thisorderimg[from] = '<img src="'.$thisorderdirection.'_order.gif" alt="" width="7" height="7" border="0">';
	}
	if(stristr($orderby,"subject")) {
		$thisorderimg[subject] = '<img src="'.$thisorderdirection.'_order.gif" alt="" width="7" height="7" border="0">';
	}
	if(stristr($orderby,"time")) {
		$thisorderimg[timestamp] = '<img src="'.$thisorderdirection.'_order.gif" alt="" width="7" height="7" border="0">';
	}
	$bodycontent.= "<h3>".message("inbox")."</h3><table border=\"1\" style=\"border-collapse: collapse\" bordercolor=\"#c0c0c0\" width=\"100%\">
	<tr>
		<td><b>".message("readunread")."</b></td>
		<td><b><a href=\"online.php?action=showinbox&sid=$sid&orderby=`from` $thisorderdirection\">".message("from")."$thisorderimg[from]</a></b></td>
		<td><b><a href=\"online.php?action=showinbox&sid=$sid&orderby=`subject` $thisorderdirection\">".message("subject")."$thisorderimg[subject]</b></td>
		<td><b><a href=\"online.php?action=showinbox&sid=$sid&orderby=`time` $thisorderdirection\">".message("timestamp")."$thisorderimg[timestamp]</b></td>
		<td><b>".message("delete")."</b></td>
	</tr>";
	$erg = mysql_db_query($db_name,$cmd,$db);
	echo mysql_error();
	while(list($id,$read,$show,$from,$to,$subject,$msg,$time,$readconfirm,$sr)=mysql_fetch_row($erg)) {
		$thistimestamp = datumwandler($time);
		if($read == "yes") {
			$thisread=message("yes");
		}else{
			$thisread=message("no");
		}
		$bodycontent.= "<tr>
			<td><a href=\"online.php?action=showmsg&idm=$id&sid=$sid\">$thisread</a></td>
			<td><a href=\"online.php?action=showuserstatus&user=$from&sid=$sid\">$from</a></td>
			<td>$subject</td>
			<td>$thistimestamp</td>
			<td><a href=\"online.php?action=askdelete&sid=$sid&id=$id&sr=$sr\"><img src=\"delete.gif\" alt=\"Deletes this message\" width=\"18\" height=\"18\" border=\"0\"></a></td>
		</tr>";
	}
	mysql_close($db);
	$bodycontent.="</table>";
	echo makepage("",$cssonline,'',$bodycontent,$sid);
}



if($action == "savesettings") {
	if($email == "") {
		$bodycontent = '<script language="JavaScript" type="text/javascript">
							function goback() {
								history.back();
							}
							window.setTimeout("goback()",3000);
						</script>';
		$bodycontent.=message("filloutall");
	
		echo makepage("",$cssonline,"",$bodycontent,$sid);
	}
	
	if($pw != $pwconfirm) {
		$bodycontent = '<script language="JavaScript" type="text/javascript">
							function goback() {
								history.back();
							}
							window.setTimeout("goback()",3000);
						</script>';
		$bodycontent.=message("samepassword");
		echo makepage("",$cssonline,"",$bodycontent,$sid);
	}
if($rememberpw) {
	setCookie("u2um2","username=$name|pw=$pw",time() + 3600 * 24 * 120);
}else{
	setCookie("u2um2","username=$name|pw=$pw",time() - 3600);
}
session_register("name");
$db = connect_database();
if(!$pw) {
$cmd = "UPDATE `user` SET `email`='$email', `language`='$selectlanguage' WHERE `name`='$name' AND `sid`='$sid';";
}else{
$cmd = "UPDATE `user` SET `email`='$email', `language`='$selectlanguage', `pw`='$pw' WHERE `name`='$name' AND `sid`='$sid';";
}
$erg = mysql_db_query($db_name,$cmd,$db);
$bodycontent = "<p>".message("settingssaved")."<br>".message("languagechanged")."<br><a href=\"online.php?action=personalcomcenter&sid=$sid\">".message("continue")."</a></p>";
echo makepage("",$cssonline,"",$bodycontent,$sid);
mysql_close($db);
}





if($action == "showmysettings") {
$db = connect_database();
$cmd = "SELECT * FROM `language`";
$erg = mysql_db_query($db_name,$cmd,$db);
$selectlg[0] = "";
while(list($id,$msgid,$lg) = mysql_fetch_row($erg)) {
	if(!in_array($lg,$selectlg)) {
		array_unshift($selectlg,$lg);
	}
}
array_pop($selectlg);
sort($selectlg);
session_register("name");
$cmd = "SELECT * FROM `user` WHERE `name`='$name' AND `sid`='$sid';";
$erg = mysql_db_query($db_name,$cmd,$db);
list($id,$name,$email,$pw,$status,$lasttime,$sid,$language,$friends) = mysql_fetch_row($erg);
mysql_close($db);
$bodycontent = "<h3>".message("mysettings")."</h3>";
$bodycontent.= "<table>
<form action=\"online.php?action=savesettings&sid=$sid\" method=\"post\" name=\"savesettings\" id=\"savesettings\">
<tr>
	<td>".message("email")."</td>
	<td><input type=\"text\" name=\"email\" value=\"$email\"></td>
</tr>
<tr>
	<td>".message("newpw")."</td>
	<td><input type=\"password\" name=\"pw\"></td>
</tr>
<tr>
	<td>".message("confirm")."</td>
	<td><input type=\"password\" name=\"pwconfirm\"></td>
</tr>
<tr>
	<td>".message("rememberpw")."</td>
	<td><input type=\"checkbox\" name=\"rememberpw\" value=\"rememberpw\"></td>
</tr>
<tr>
	<td>".message("language")."</td>
	<td>";
$bodycontent.="<select name=\"selectlanguage\">";
for($x=0;$x<sizeof($selectlg);$x++) {
	if($selectlg[$x] == $language) {
	$bodycontent.= "<option value=\"$selectlg[$x]\" selected>$selectlg[$x]</option>";
	}else{
	$bodycontent.= "<option value=\"$selectlg[$x]\">$selectlg[$x]</option>";
	}
}
$bodycontent.=  "</select>
	</td>
</tr>
<tr>
	<td><input type=\"submit\" name=\"submit\" value=\"".message("savesettings")."\"></td>
	<td><input type=\"button\" name=\"dontsave\" value=\"".message("dontsave")."\" onClick=\"document.location.href='online.php?action=personalcomcenter&sid=$sid';\"></td>
</tr>
</form>
</table>
";
echo makepage("",$cssonline,"",$bodycontent,$sid);
}

if($action == "personalcomcenter") {
	$bodycontent = "<h3>".message("pcomc")."</h3>" . message("pcomcmsg");
	$bodycontent.="<menu>
	<li><a href=\"online.php?action=showinbox&sid=$sid&orderby=`time` asc\">".message("inbox")."</a></li>
	<li><a href=\"online.php?action=showoutbox&sid=$sid&orderby=`time` asc\">".message("outbox")."</a></li>
	<li><a href=\"online.php?action=listuser&which=online&sid=$sid&orderby=`name` asc\">".message("showonlineuser")."</a></li>
		<li><a href=\"online.php?action=searchform&sid=$sid\">".message("searchuser")."</a></li>
	<li><a href=\"online.php?action=showmysettings&sid=$sid\">".message("mysettings")."</a></li>
	<li><a href=\"online.php?action=showmyfriends&sid=$sid\">".message("myfriends")."</a></li>
	</menu>";
	echo makepage("",$cssonline,"",$bodycontent,$sid);
}

if($action == "searchform") {
	$bodycontent = "<h3>".message("searchuser")."</h3>";
	$bodycontent.= message("searchformtext");
	$bodycontent.= '<form action="online.php?action=listuser&which=search&sid='.$sid.'&orderby=`name` desc" method="post" name="searchform" id="searchform"><input type="text" name="searchstr"><br><input type="submit" name="submit" value="'.message("search").'"></form>';
	echo makepage("",$cssonline,"",$bodycontent,$sid);
}

if($action == "listuser") {
	$db = connect_database();
	session_register("name");
	if($which == "online") {
	$cmd = "SELECT * FROM `user` WHERE `status`='online' ORDER BY $orderby;";
	$bodycontent.="<h3>".message("onlineuser")."</h3>";
	}
	if($which == "search") {
	$cmd = "SELECT * FROM `user` WHERE `name` LIKE '%$searchstr%' OR `email` LIKE '%$searchstr%' ORDER BY $orderby;";
	$thismsg = str_replace("<%&searchstr&%>","\"$searchstr\"",message("searchfor"));
	$bodycontent.="<h3>$thismsg</h3>";
	}
	$erg = mysql_db_query($db_name,$cmd,$db);
	if(stristr($orderby,"asc")) {
		$thisorderdirection = "desc";
	}else{
		$thisorderdirection = "asc";
	}
	$thisorderimg = '<img src="'.$thisorderdirection.'_order.gif" alt="" width="7" height="7" border="0">';

$thisquery = "action=listuser&which=$which&sid=$sid&orderby=`name` $thisorderdirection&searchstr=$searchstr";
	$bodycontent.="<table border=\"1\" style=\"border-collapse: collapse\" bordercolor=\"#c0c0c0\" width=\"100%\">
		<tr>
			<td><b><a href=\"online.php?$thisquery\">".message("name")."".$thisorderimg."</a></b></td>
			<td><b>".message("userstate")."</b></td>
			<td><b>".message("sendmsg")."</b></td>
			<td><b>".message("addfriend")."</b></td>			
		</tr>";
	$name_s = strtolower($name);
	while(list($id,$thisname)=mysql_fetch_row($erg)) {
		$thisname_s = strtolower($thisname);
		if($thisname_s != $name_s) {
			$bodycontent.="<tr>
				<td><p>$thisname</p></td>
				<td><a href=\"online.php?action=showuserstatus&sid=$sid&user=$thisname\"><img src=\"detail.gif\" alt=\"Show userstates\" width=\"20\" height=\"20\" border=\"0\"></a></td>
				<td><a href=\"online.php?action=writemsg&to=$thisname&sid=$sid\"><img src=\"letter.gif\" alt=\"Send message\" width=\"30\" height=\"20\" border=\"0\"></a></td>
				<td><a href=\"online.php?action=addfriend&friend=$thisname&sid=$sid\"><img src=\"friend.gif\" alt=\"Add friend\" width=\"19\" height=\"19\" border=\"0\"></a></td>
			</tr>";
		}else{
			$bodycontent.="<tr>
				<td><b><p title=\"Click here to get to your personal communication center\"><a href=\"online.php?action=personalcomcenter&sid=$sid\">$thisname</a></p></b></td>
				<td><a href=\"online.php?action=showuserstatus&sid=$sid&user=$thisname\"><img src=\"detail.gif\" alt=\"Show userstates\" width=\"20\" height=\"20\" border=\"0\"></a></td>
			</tr>";
		}
	}
	$bodycontent.="</table>";
	echo makepage("",$cssonline,"",$bodycontent,$sid);
	mysql_close($db);
}



if($action == "showuserstatus") {
$db = connect_database();
$cmd = "SELECT * FROM `user` WHERE `name`='$user';";
$erg = mysql_db_query($db_name,$cmd,$db);
$result = mysql_fetch_row($erg);
mysql_close($db);
$bodycontent = "<table cellspacing=\"5\">
<tr>
<td><h3>".message("userstate")."</h3></td>
</tr>
<tr>
	<td><b>".message("name").":</b></td>
	<td>$result[1]</td>
</tr>
<tr>
	<td><b>".message("state")."</b>:</td>
	<td>$result[4]</td>
</tr>
<tr>
	<td><p><a href=\"online.php?action=writemsg&to=$result[1]&sid=$sid\">".message("sendmsgto")."<br> $user</a></p></td>
	<td><p><a href=\"online.php?action=addfriend&friend=$result[1]&sid=$sid\">".message("addfriend")."</a></p></td>
</tr>
<tr>
	<td><p><a href=\"#\" onclick=\"window.close()\">".message("closewindow")."</a></p></td>
</tr>
</table>
";
echo makepage("",$cssonline,"",$bodycontent,$sid);
}


if($action == "showmsg") {
	$db = connect_database();
	$cmd = "SELECT * FROM `message` WHERE id='$idm';";
	$erg = mysql_db_query($db_name,$cmd,$db);
	session_register("name");
	list($id,$read,$show,$from,$to,$subject,$msg,$time,$readconfirm,$sr,$linkid)=mysql_fetch_row($erg);
	$name_s = strtolower($name);
	$to_s = strtolower($to);
	$from_s = strtolower($from);
	if($name_s == $to_s OR $name_s == $from_s) {
		$bodycontent = "<h3>".message("newmsg")."</h3>";
		if($sr == "r") {
		$cmd = "UPDATE `message` SET `read`='yes' WHERE `linkid`='$linkid';";
		$erg = mysql_db_query($db_name,$cmd,$db);
		$cmd = "UPDATE `message` SET `readconfirm`='no' WHERE `id`='$idm';";
		$erg = mysql_db_query($db_name,$cmd,$db);
		}
		if($readconfirm == "yes" AND $sr=="r") {
			$readconfirmmsg = str_replace("<%&receiver&%>",$to,message("readconfirmmsg"));
			$readconfirmsub = str_replace("<%&receiver&%>",$to,message("readconfirmsub"));
			$cmd = "INSERT INTO `message` (`id`, `read`,`show`, `from`, `to`, `subject`, `msg`, `time`, `readconfirm`,`sr`) VALUES ('', 'no','no', '$to', '$from', '$readconfirmsub', '$readconfirmmsg', NOW(NULL), 'no','r');";
			$erg = mysql_db_query($db_name,$cmd,$db);
		}
		$thismsg = preparemsg($msg);
		$thistimedate = datumwandler($time);
		$bodycontent.= "<table>
		<tr>
			<td><b>".message("from").":</b></td>
		</tr>
		<tr>
			<td><a href=\"online.php?action=showuserstatus&user=$from&sid=$sid\">$from</a></td>
		</tr>
		<tr>
			<td><b>".message("to").":</b></td>
		</tr>
		<tr>
			<td>$to</td>
		</tr>
		<tr>
			<td><b>".message("subject").":</b></td>
		</tr>
		<tr>
			<td>$subject</td>
		</tr>
		<tr>
			<td><b>".message("timestamp").":</b></td>
		</tr>
		<tr>
			<td>$thistimedate</td>
		</tr>
		<tr>
			<td><b>".message("message").":</b></td>
		</tr>
		<tr>
			<td>$thismsg</td>
		</tr>
		</table>
		<p><a href=\"online.php?action=writemsg&to=$from&sid=$sid\">".message("answer")."</a></p>
		<p><a href=\"#\" onclick=\"window.close()\">".message("closewindow")."</a></p>
		";
		echo makepage("",$cssonline,"",$bodycontent,$sid);
		}else{
		echo makepage("",$cssonline,"",message("notforyou"),$sid);
		}
	@mysql_close($db);
}




if($action == "signup") {
	if(!$pw OR !$email OR !$name) {
		$bodycontent = '<script language="JavaScript" type="text/javascript">
							function goback() {
								history.back();
							}
							window.setTimeout("goback()",3000);
						</script>';
		$bodycontent.=message("filloutall");
		echo makepage("",$cssonline,"",$bodycontent,$sid);
	}
	if($pw != $pwcheck) {
		$bodycontent = '<script language="JavaScript" type="text/javascript">
							function goback() {
								history.back();
							}
							window.setTimeout("goback()",3000);
						</script>';
		$bodycontent.=message("samepassword");
		echo makepage("",$cssonline,"",$bodycontent,$sid);
	}
	$db = connect_database();
	session_unregister("name");
	$name_s = $name;
	$email_s = $email;
	$cmd = "SELECT * FROM `user` WHERE `email`='$email' OR `name`='$name';";
	$erg = mysql_db_query($db_name,$cmd,$db);
	$result = mysql_fetch_row($erg);
	session_register("language");
	$language=$selectlanguage;
	if(mysql_fetch_row($erg)) {
		$bodycontent = '<script language="JavaScript" type="text/javascript">
							function goback() {
								history.back();
							}
							window.setTimeout("goback()",3000);
							</script>'. message("alreadyregistered");
		echo makepage("",$cssonline,"",$bodycontent,$sid);
		mysql_close($db);
		die;	
	}
	$pw = md5($pw);
	$cmd = "INSERT INTO `user` (`id`, `name`, `email`, `pw`, `status`, `lasttime`, `sid`, `language`, `friends`) VALUES ('', '$name_s', '$email_s', '$pw', 'online', '" .time() ."', '$sid', '$selectlanguage', '');";
	if($rememberpw) {
		setCookie("u2um2","username=$name|pw=$pw",time() + 3600 * 24 * 120);
}
	$erg = mysql_db_query($db_name,$cmd,$db);
	session_register("name");
	session_register("pw");
	$bodycontent = "<script language=\"JavaScript\" type=\"text/javascript\">
						function registered() {
							$windowhandler.location.href = \"index.php?action=login&sid=$sid\";
							window.close();
						}
						window.setTimeout(\"registered()\",3000);
					</script>";
	$bodycontent.= message("registered") . message("wait");
	echo makepage("",$cssonline,"",$bodycontent,$sid);
	mysql_close($db);
}

if($action == "dontjoin") {
	setCookie("u2um2","dontjoin",time() + 3600 * 24 * 120);
	@session_destroy();
	$script = '<script language="JavaScript" type="text/javascript">
					function dontjoin() {
						$windowhandler.document.location.reload();
						window.close();
					}
				</script>';
	echo makepage($script,$cssonline,"onload=\"dontjoin()\"",$bodycontent,$sid);
}




if($action == "login") {
	session_register("name");
	session_register("pw");
	$name = $login;
	$pw=md5($pw);
	if($rememberpw) {
		setCookie("u2um2","username=$name|pw=$pw",time() + 3600 * 24 * 120);
	}	
	$bodycontent = "<script language=\"JavaScript\" type=\"text/javascript\">
						function login() {
							$windowhandler.location.href = \"index.php?action=login&sid=$sid\";
							window.close();
						}
						window.setTimeout(\"login()\",3000);
					</script>";
	$bodycontent.= message("wait");
	echo makepage("",$cssonline,"",$bodycontent,$sid);
}

if($action == "join") {
	$db = connect_database();
	$cmd = "SELECT * FROM `language`";
	$erg = mysql_db_query($db_name,$cmd,$db);
	$selectlg[0] = "";
	while(list($id,$msgid,$lg) = mysql_fetch_row($erg)) {
		if(!in_array($lg,$selectlg)) {
			array_unshift($selectlg,$lg);
		}
	}
	array_pop($selectlg);
	sort($selectlg);
	mysql_close($db);
	$bodycontent = message("welcome");
	$bodycontent.= message("dontjointext");
	$bodycontent.= "<a href=\"online.php?action=dontjoin&sid=$sid\"> " . message("here") . ".</a></p>";
	$bodycontent.= "<h3>" . message("Login") ."</h3>
	<form name=\"login\" enctype=\"application/x-www-form-urlencoded\" method=\"post\" action=\"online.php?action=login&sid=$sid\">
	<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
	  <tr>
    	<td><p>".message("name")."</p></td>
	    <td><input type=\"text\" name=\"login\"></td>
	  </tr>
	  <tr>
	    <td><p>".message("password")."</p></td>
    	<td><input type=\"password\" name=\"pw\"></td>
	  </tr>
	  <tr>
	    <td><p>".message("rememberpw")."</p></td>
	    <td><input type=\"Checkbox\" value=\"rememberpw\" name=\"rememberpw\"></td>
	  </tr>
	  <tr>
	    <td>&nbsp;</td>
	    <td><p><input type=\"Submit\" name=\"go\" value=\"".message("dologin")."\"></p></td>
	  </tr>
	  </form>
	</table>
	<h3>".message("signup")."</h3>
	<form name=\"signup\" enctype=\"application/x-www-form-urlencoded\" method=\"post\" action=\"online.php?action=signup&sid=$sid\">
	  <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
	    <tr>
    	  <td><p>".message("name")."</p></td>
	      <td>
	        <input type=\"text\" name=\"name\">
	      </td>
	    </tr>
	    <tr>
	      <td><p>".message("email")."</p></td>
    	  <td>
	        <input type=\"text\" name=\"email\">
	      </td>
    	</tr>
	    <tr>
	      <td><p>".message("password")."</p></td>
	      <td>
	        <input type=\"password\" name=\"pw\">
    	  </td>
	    </tr>
	    <tr>
	      <td><p>".message("confirm")."</p></td>
	      <td>
	        <input type=\"password\" name=\"pwcheck\">
	      </td>
	    </tr>
		<tr>
		  <td>".message("language")."</td>
		  <td> <select name=\"selectlanguage\">";
	for($x=0;$x<sizeof($selectlg);$x++) {
		$bodycontent.= "<option value=\"$selectlg[$x]\">$selectlg[$x]</option>";
	}
	$bodycontent.=  "</select></td>
		</tr>
		<tr>
		    <td><p>".message("rememberpw")."</p></td>
		    <td><input type=\"Checkbox\" value=\"rememberpw\" name=\"rememberpw\"></td>
		</tr>
	    <tr>
    	  <td>&nbsp;</td>
	      <td>
    	    <input type=\"Submit\" name=\"go\" value=\"".message("dosignup")."\">
	      </td>
    	</tr>
	  </table>";
	echo makepage("",$cssonline,"",$bodycontent,$sid);
}




?>
