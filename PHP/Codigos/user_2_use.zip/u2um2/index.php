<?php 

/*---------------------------------------------------
            	user to user messenger	             
            		version 2	             
            	   Copyright 2002 	             
            	   Cornelius Herzog	             
                cornelius.herzog@gmx.de	             
-----------------------------------------------------
       This script is free, as long its not in       
                     commercial use	             
          otherwise you have to pay for it           
-----------------------------------------------------
    Dieses Skript ist kostenlos, solange es	     
      	  nicht kommerziell benutzt wird	     
       	ansonsten muss daf�r bezahlt werden	     
---------------------------------------------------*/



include("include.inc.php");
$query = getenv("QUERY_STRING");
parse_url($query);

if($action == "queue") {
	setoffline();
	session_register("name");
	$db = connect_database();
	$time = time();
	$cmd = "UPDATE `user` SET `status`='online',`lasttime`='$time' WHERE `sid`='$sid';";
	$erg = mysql_db_query($db_name,$cmd,$db);
	$cmd = "SELECT * FROM `message` WHERE `show`='no' AND `to`='$name' AND `sr` ='r';";
	$erg = mysql_db_query($db_name,$cmd,$db);
	$numbermsg = mysql_affected_rows();
	$result = mysql_fetch_row($erg);
	$msgid = $result[0];
	$cmd = "UPDATE `message` SET `show`='yes' WHERE `show`='no' AND `to`='$name' AND `sr` ='r';";
	$erg = mysql_db_query($db_name,$cmd,$db);
	$cmd = "SELECT * FROM `user` WHERE `status`='online';";
	$erg = mysql_db_query($db_name,$cmd,$db);
	$onlineuser = mysql_affected_rows();
	mysql_close($db);
	$scriptplace=makewinopenscript("pcomc","personalcomcenter",$sid,"");
	$scriptplace.=makewinopenscript("onlineuser","listuser",$sid,"&which=online&orderby=`name` asc");
	$bodycontent = "<p><a href=\"#\" onclick=\"pcomc()\">$name</a><br><a href=\"#\" onclick=\"onlineuser()\">$onlineuser ".message("useronline")."</a></p>";
	$bodycontent.= '<script language="JavaScript" type="text/javascript">
									function reloadthis() {
								document.location.reload();
							}
							window.setTimeout("reloadthis()",10000);
							</script>';
	
	if($msgid !="") {
		$scriptplace.=makewinopenscript("showmsg","showmsg",$sid,"&idm=$msgid&numbermsg=$numbermsg");
		echo makepage("$scriptplace",$cssindex,'onload="showmsg()"',$bodycontent,"");
	}else{
		echo makepage("$scriptplace",$cssindex,"",$bodycontent,"");
}





}

if($action == "login") {
	session_register("name");
	session_register("pw");
	$db = connect_database();
	$cmd = "SELECT * FROM `user` WHERE `name`='$name';";
	$erg = mysql_db_query($db_name,$cmd,$db);
	$result = mysql_fetch_row($erg);
	if(!$result OR $pw != $result[3]) {
		$bodycontent = '<script language="JavaScript" type="text/javascript">
							alert("'.message("errorlogin").'");
						</script>';
		session_unregister("name");
		session_unregister("pw");
		echo makepage(makewinopenscript("winopen","join",session_id(),""),$cssindex,"onload=\"winopen()\"",$bodycontent,"");
	}else{
		$cmd = "UPDATE `user` SET `status`='online', `lasttime`='".time()."', `sid`='$PHPSESSID'  WHERE `id` = '$result[0]';";
		$erg = mysql_db_query($db_name,$cmd,$db);
		$cmd = "SELECT `name` FROM `user` WHERE `friends` LIKE '%$name%' AND `status`='online';";
		$erg = mysql_db_query($db_name,$cmd,$db);
		while(list($name_f) = @mysql_fetch_row($erg)) {
		$cmd = "INSERT INTO `message` (`id`, `read`, `show`, `from`, `to`, `subject`, `msg`, `time`, `readconfirm`, `sr`,`linkid`) VALUES ('', 'no', 'no', '$name', '$name_f', '$name ".message("usercomeonline")."', '', NOW(NULL), 'no', 'r','');";
			$erg = mysql_db_query($db_name,$cmd,$db);
		}
			session_register("language");
		$language = $result[7];
	header("location:index.php?action=queue&sid=$PHPSESSID");
	}
	mysql_close($db);
}

if($action == "") {
	setoffline();
	session_start();
	session_destroy();
	session_start();
	session_unset();
	echo "<script language=\"JavaScript\" type=\"text/javascript\">
			if(!navigator.userLanguage) {
				var ulg = navigator.language;
			}else{
				var ulg = navigator.userLanguage;
			}
				document.location.href = 'index.php?action=go&ulg='+ulg+'&sid=$PHPSESSID';
			</script>";
			
}	

if($action == "go") {
	session_register("language");
	switch($ulg) {
		case "de":
			$language = "german";
			break;
		case "en":
			$language = "english";
			break;
		default:
			$language = $default_language;
			break;	
	}
	$cookie = $HTTP_COOKIE_VARS["u2um2"];
	if(!$cookie) {
		echo makepage(makewinopenscript("winopen","join",session_id(),""),$cssindex,"onload=\"winopen()\"",message("wait"),"");
	}else{
		$such = stristr($cookie,"dontjoin");
			if($such) {
				header("location: index.php?action=deactivated");
			}else{
				session_register("pw");
				session_register("name");
				$logindata = explode("|",$cookie);
				$name = explode("=",$logindata[0]);
				$name = $name[1];
				$pw = explode("=",$logindata[1]);
				$pw = $pw[1];
				header("location: index.php?action=login");
			}
	}
}





if($action == "deactivated") {
	$bodycontent = "<p><a href=\"index.php?action=unsetcookie\">".message("deactivated")."</a></p>";
	echo makepage("",$cssindex,"",$bodycontent,"");
}

if($action == "unsetcookie") {
	setCookie("u2um2","dontjoin",time() - 3600);
	header("location: index.php");
}



?>