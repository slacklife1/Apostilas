<?php

/*---------------------------------------------------
            	user to user messenger	             
            		version 2	             
            	   Copyright 2002 	             
            	   Cornelius Herzog	             
                cornelius.herzog@gmx.de	             
-----------------------------------------------------
       This script is free, as long its not in       
                     commercial use	             
          otherwise you have to pay for it           
-----------------------------------------------------
    Dieses Skript ist kostenlos, solange es	     
      	  nicht kommerziell benutzt wird	     
       	ansonsten muss daf�r bezahlt werden	     
---------------------------------------------------*/


//Login informations for the database
$db_server = "localhost";
$db_login = "root";
$db_passwort = "";
$db_name = "u2um";
//Language
$default_language = "german";
$cssindex = "index.css";   					//the cssfile for the index.php
$cssonline =  "index.css";					//the cssfile for the online.php
$windowhandler = "window.opener"; 			//this is the window handler. if you use it in frames, it should be: window.opener.parent.framename

$html = '<html>
<head>
<meta http-equiv="Copyright" content="Cornelius Herzog (cornelius.herzog@gmx.de) 2002">
<meta http-equiv="index" content="21045fddf150d05d35923d1d12e17e9ef6d3b0b9">
<meta http-equiv="online" content="ed81acc556fda5c0ff1a0df4e5784c51b0eb4ddc">
<meta http-equiv="author" content="de4e2332d83f3c207d13816236e9c435ca05ed7f">
<title>u2um2</title>
<%&scriptplace&%>
<link rel="stylesheet" type="text/css" href="<%&csspath&%>">
</head>
<body <%&bodyaction&%>>
<p>
<%&contentplace&%>
</p>
<%&navi&%>
</body>
</html>
';

$winopenscript = '<script language="JavaScript" type="text/javascript">
		function <%&name&%>() {
		 <%&name&%>= window.open("online.php?action=<%&action&%>&sid=<%&sid&%><%&other&%>","u2um2","width=350,height=400,left=320,top=0,scrollbars=yes,status=yes,resizable=yes");
		<%&name&%>.focus();
		}
		</script>
		';



function connect_database() {
$db_connection=@mysql_connect($db_server, $db_login, $db_password);
if(! $db_connection){
	die("Error when connecting the database. Please check your login information!");
}
return $db_connection;
}


function makewinopenscript($name,$action,$sid,$other) {
global $winopenscript;
$winopenscript_this = str_replace("<%&name&%>",$name,$winopenscript);
$winopenscript_this = str_replace("<%&action&%>",$action,$winopenscript_this);
$winopenscript_this = str_replace("<%&sid&%>",$sid,$winopenscript_this);
$winopenscript_this  = str_replace("<%&other&%>",$other,$winopenscript_this);
return $winopenscript_this;
}

function makepage($scriptplace,$csspath,$bodyaction,$contentplace,$navi) {
global $html;
$html = str_replace("<%&scriptplace&%>",$scriptplace,$html);
$html = str_replace("<%&csspath&%>",$csspath,$html);
$html = str_replace("<%&bodyaction&%>",$bodyaction,$html);
$html = str_replace("<%&contentplace&%>",$contentplace,$html);
if($navi != "") {
$html = str_replace("<%&navi&%>",'<a href="online.php?action=personalcomcenter&sid='.$navi.'">[Index]</a>',$html);
}else{
$html = str_replace("<%&navi&%>",'',$html);
}
return $html;
}

function message($messageid) {
session_register("language");
global $language;
global $db_name;
$db = connect_database();
$cmd = "SELECT * FROM `language` WHERE `msgid`='$messageid' AND `lg`='$language';";
$erg = mysql_db_query($db_name,$cmd,$db);
$result = mysql_fetch_row($erg);
return $result[3];
mysql_close($db);
}

function setoffline() {
$db = connect_database();
global $db_name;
$time = time();
$cmd = "UPDATE `user` SET `status`='offline', `sid`='' WHERE ('$time'-lasttime)>30;";
$erg = mysql_db_query($db_name,$cmd,$db);
mysql_close($db);
}

function datumwandler($t) {
return sprintf("%02d.%02d.%04d/%02d:%02d:%02d", substr($t, 6, 2), substr($t, 4, 2),substr($t, 0, 4), substr($t,8,2), substr($t,10,2), substr($t,12,2));
}

function preparemsg($msg) {
$db = connect_database();
global $db_name;
$cmd = "SELECT * FROM `language` WHERE `msgid` LIKE 's_%';";
$erg = mysql_db_query($db_name,$cmd,$db);
while(list($id,$msgid,$lg,$thismsg)=mysql_fetch_row($erg)) {
$msg = str_replace(":$thismsg:","<img src=\"smilies\\$msgid.gif\">",$msg);
}
mysql_close($db);
return $msg;
}
?>