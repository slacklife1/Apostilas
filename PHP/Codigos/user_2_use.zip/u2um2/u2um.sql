#Datenbank u2um - Tabelle language auf localhost
# u2um2 MySQL-Dump
# version 2.2.3
# Host: localhost
# Created: 22. Juli 2002 at 21:59
# Server Version: 3.23.43
# PHP Version: 4.0.6
# Database : `u2um`
# --------------------------------------------------------

#
# Tablestructure for table `language`
#

CREATE TABLE language (
  id int(11) NOT NULL auto_increment,
  msgid varchar(20) NOT NULL default '0',
  lg varchar(20) NOT NULL default '',
  msg text NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY id (id)
) TYPE=MyISAM;

#
# Data for table `language`
#

INSERT INTO language VALUES (1, 'wait', 'german', '<p>Bitte warten...</p>');
INSERT INTO language VALUES (3, 'welcome', 'german', '<p><b>Willkommen</b>,<br>\r\n  beim User to User Messenger. Dieses System erm�glicht Ihnen zu sehen wer gerade auf \r\n  der Seite ist.<br>\r\n  Sie m�chten Teilnehmen? Dann f�llen Sie dieses Formular aus.');
INSERT INTO language VALUES (4, 'dontjointext', 'german', '<br>Sie m�chten nicht teilnehmen? Klicken Sie');
INSERT INTO language VALUES (5, 'here', 'german', 'hier');
INSERT INTO language VALUES (6, 'login', 'german', 'Login');
INSERT INTO language VALUES (7, 'name', 'german', 'Name');
INSERT INTO language VALUES (8, 'password', 'german', 'Passwort');
INSERT INTO language VALUES (9, 'dologin', 'german', 'Einloggen');
INSERT INTO language VALUES (11, 'confirm', 'german', 'Best�tigen');
INSERT INTO language VALUES (12, 'email', 'german', 'eMail');
INSERT INTO language VALUES (13, 'rememberpw', 'german', 'Passwort merken');
INSERT INTO language VALUES (14, 'deactivated', 'german', 'Deaktiviert...');
INSERT INTO language VALUES (30, 'dosignup', 'german', 'Anmelden...');
INSERT INTO language VALUES (31, 'signup', 'german', 'Anmeldung');
INSERT INTO language VALUES (32, 'wait', 'english', '<p>Please wait...</p>');
INSERT INTO language VALUES (33, 'welcome', 'english', '<p><b>Welcome</b>,<br>\r\n  to User to User Messenger. This system allows you to see who \r\n is online on this page.<br>\r\n You want to join? Then fill out this form.');
INSERT INTO language VALUES (34, 'dontjointext', 'english', '<br>You don�t want to join? Press');
INSERT INTO language VALUES (35, 'here', 'english', 'here');
INSERT INTO language VALUES (36, 'login', 'english', 'Login');
INSERT INTO language VALUES (37, 'name', 'english', 'Name');
INSERT INTO language VALUES (38, 'password', 'english', 'Password');
INSERT INTO language VALUES (39, 'dologin', 'english', 'Login');
INSERT INTO language VALUES (40, 'confirm', 'english', 'Confirm');
INSERT INTO language VALUES (41, 'email', 'english', 'eMail');
INSERT INTO language VALUES (42, 'rememberpw', 'english', 'Remember password');
INSERT INTO language VALUES (43, 'deactivated', 'english', 'Deactivated...');
INSERT INTO language VALUES (44, 'dosignup', 'english', 'Signup...');
INSERT INTO language VALUES (45, 'signup', 'english', 'Signup');
INSERT INTO language VALUES (51, 'samepassword', 'german', 'Bitte in beide Felder das gleiche Passwort eingeben');
INSERT INTO language VALUES (52, 'samepassword', 'english', 'Please enter in both fields the same password');
INSERT INTO language VALUES (53, 'language', 'german', 'Sprache');
INSERT INTO language VALUES (54, 'language', 'english', 'Language');
INSERT INTO language VALUES (55, 'alreadyregistered', 'german', 'Sie sind bereits registriert. Bitte loggen Sie sich ein.');
INSERT INTO language VALUES (56, 'alreadyregistered', 'english', 'You are already registered. Please login.');
INSERT INTO language VALUES (57, 'registered', 'german', 'Sie wurden erfolgreich als Benutzer registriert.');
INSERT INTO language VALUES (58, 'registered', 'english', 'You were added successfully.');
INSERT INTO language VALUES (59, 'errorlogin', 'german', 'Fehler beim Einloggin. Bitte loggen Sie sich erneut ein.');
INSERT INTO language VALUES (60, 'errorlogin', 'english', 'Error when logging in. Please login again.');
INSERT INTO language VALUES (61, 'useronline', 'german', 'User online');
INSERT INTO language VALUES (62, 'useronline', 'english', 'User online');
INSERT INTO language VALUES (63, 'newmsg', 'german', 'Neue Nachrichten');
INSERT INTO language VALUES (64, 'newmsg', 'english', 'New messages.');
INSERT INTO language VALUES (65, 'from', 'german', 'Von');
INSERT INTO language VALUES (66, 'from', 'english', 'From');
INSERT INTO language VALUES (67, 'to', 'german', 'An');
INSERT INTO language VALUES (68, 'to', 'english', 'To');
INSERT INTO language VALUES (69, 'subject', 'german', 'Betreff');
INSERT INTO language VALUES (70, 'subject', 'english', 'Subject');
INSERT INTO language VALUES (71, 'message', 'german', 'Nachricht');
INSERT INTO language VALUES (72, 'message', 'english', 'Message');
INSERT INTO language VALUES (73, 'timestamp', 'german', 'Datum/Zeit');
INSERT INTO language VALUES (74, 'timestamp', 'english', 'Date/Time');
INSERT INTO language VALUES (75, 'notforyou', 'german', 'Diese Nachricht ist nicht f�r Sie bestimmt');
INSERT INTO language VALUES (76, 'notforyou', 'english', 'This message isn\'t for you');
INSERT INTO language VALUES (77, 'closewindow', 'german', 'Fenster schlie�en');
INSERT INTO language VALUES (78, 'closewindow', 'english', 'Close window');
INSERT INTO language VALUES (79, 'answer', 'german', 'Antworten');
INSERT INTO language VALUES (80, 'answer', 'english', 'Answer');
INSERT INTO language VALUES (91, 'userstate', 'german', 'Benutzerstatus');
INSERT INTO language VALUES (92, 'userstate', 'english', 'Userstate');
INSERT INTO language VALUES (93, 'state', 'german', 'Status');
INSERT INTO language VALUES (94, 'state', 'english', 'State');
INSERT INTO language VALUES (95, 'sendmsgto', 'german', 'Nachrich senden an');
INSERT INTO language VALUES (96, 'sendmsgto', 'english', 'Send message to');
INSERT INTO language VALUES (97, 'onlineuser', 'german', 'Folgende User sind gerade online');
INSERT INTO language VALUES (98, 'onlineuser', 'english', 'This users are at the moment online');
INSERT INTO language VALUES (99, 'sendmsg', 'german', 'Nachricht senden');
INSERT INTO language VALUES (100, 'sendmsg', 'english', 'Send message');
INSERT INTO language VALUES (101, 'pcomc', 'german', 'Pers�nlich Kommunikationszentrale');
INSERT INTO language VALUES (102, 'pcomc', 'english', 'Personal Communication Center');
INSERT INTO language VALUES (103, 'pcomcmsg', 'german', '<h4>Willkommen,</h4><p>in ihrer pers�nlichen Kommmunikationszentrale des u2um 2. Hier haben Sie Zugriff auf alle Funktionen.</p>');
INSERT INTO language VALUES (104, 'pcomcmsg', 'english', '<h4>Welcome,</h4><p>to the personal communication center of the u2um 2. Here you have full access to all functions.</p>');
INSERT INTO language VALUES (105, 'inbox', 'german', 'Posteingang');
INSERT INTO language VALUES (106, 'inbox', 'english', 'Inbox');
INSERT INTO language VALUES (107, 'outbox', 'german', 'Postausgang');
INSERT INTO language VALUES (108, 'outbox', 'english', 'Outbox');
INSERT INTO language VALUES (109, 'trash', 'german', 'Papierkorb');
INSERT INTO language VALUES (110, 'trash', 'english', 'Trash');
INSERT INTO language VALUES (111, 'mysettings', 'german', 'Meine Einstellungen');
INSERT INTO language VALUES (112, 'mysettings', 'english', 'My settings');
INSERT INTO language VALUES (113, 'myfriends', 'german', 'Meine Freunde');
INSERT INTO language VALUES (114, 'myfriends', 'english', 'My friends');
INSERT INTO language VALUES (115, 'newpw', 'german', 'Neues Passwort');
INSERT INTO language VALUES (116, 'newpw', 'english', 'New password');
INSERT INTO language VALUES (117, 'savesettings', 'german', 'Einstellungen speichern');
INSERT INTO language VALUES (118, 'savesettings', 'english', 'Save settings');
INSERT INTO language VALUES (119, 'dontsave', 'german', 'Abbrechen');
INSERT INTO language VALUES (120, 'dontsave', 'english', 'Cancel');
INSERT INTO language VALUES (121, 'filloutall', 'german', 'Bitte alle n�tigen Felder ausf�llen');
INSERT INTO language VALUES (122, 'filloutall', 'english', 'Please fill out all necesary fields');
INSERT INTO language VALUES (123, 'settingssaved', 'german', '�nderungen gespeichert');
INSERT INTO language VALUES (124, 'settingssaved', 'english', 'Settings saved');
INSERT INTO language VALUES (125, 'continue', 'german', 'Weiter');
INSERT INTO language VALUES (126, 'continue', 'english', 'Continue');
INSERT INTO language VALUES (127, 'readunread', 'german', 'Gelesen?');
INSERT INTO language VALUES (128, 'readunread', 'english', 'Read?');
INSERT INTO language VALUES (129, 'yes', 'german', 'ja');
INSERT INTO language VALUES (130, 'yes', 'english', 'yes');
INSERT INTO language VALUES (131, 'no', 'german', 'nein');
INSERT INTO language VALUES (132, 'no', 'english', 'no');
INSERT INTO language VALUES (133, 'delete', 'german', 'L�schen');
INSERT INTO language VALUES (134, 'delete', 'english', 'Delete');
INSERT INTO language VALUES (135, 'wanttodelete', 'german', 'M�chten Sie diese Nachricht wirklich l�schen?');
INSERT INTO language VALUES (136, 'wanttodelete', 'english', 'Do you really want to delete this message?');
INSERT INTO language VALUES (137, 'readunreadfromr', 'german', 'Gelesen(vom Empf�nger)?');
INSERT INTO language VALUES (138, 'readunreadfromr', 'english', 'Read(of receiver)?');
INSERT INTO language VALUES (139, 'error', 'german', 'Fehler');
INSERT INTO language VALUES (140, 'error', 'english', 'Error');
INSERT INTO language VALUES (141, 'deleted', 'german', 'Nachricht wurde gel�scht');
INSERT INTO language VALUES (142, 'deleted', 'english', 'Message has been deleted');
INSERT INTO language VALUES (143, 'addfriend', 'german', 'Zu Freunden hinzuf�gen');
INSERT INTO language VALUES (144, 'addfriend', 'english', 'Add to friends');
INSERT INTO language VALUES (145, 'showonlineuser', 'german', 'User die online sind anzeigen');
INSERT INTO language VALUES (146, 'showonlineuser', 'english', 'Show user which are online');
INSERT INTO language VALUES (147, 'searchuser', 'german', 'User suchen');
INSERT INTO language VALUES (148, 'searchuser', 'english', 'Search user');
INSERT INTO language VALUES (149, 'searchformtext', 'german', '<p>Hier k�nnen Sie User suchen. So k�nnen Sie auch Usern die offline sind Nachrichten zukommen lassen und Sie ihrer Kontaktliste hinzuf�gen. "%" ist Platzhalter. Wenn Sie nur "%" eingeben, werden alle User aufgelistet.</p>');
INSERT INTO language VALUES (150, 'searchformtext', 'english', '<p>Here you can search user. So you can send message to users who are offline and you can add them to your contactlist. "%" ist the wildcard. If you just enter "%", all users will be listed.</P>');
INSERT INTO language VALUES (151, 'search', 'german', 'Suchen...');
INSERT INTO language VALUES (152, 'search', 'english', 'Search...');
INSERT INTO language VALUES (153, 'searchfor', 'german', 'Suchen nach <%&searchstr&%>');
INSERT INTO language VALUES (154, 'searchfor', 'english', 'Search for <%&searchstr&%>');
INSERT INTO language VALUES (155, 'alreadyyourfriend', 'german', 'Dieser User ist bereits in der Kontaktliste.');
INSERT INTO language VALUES (156, 'alreadyyourfriend', 'english', 'This user is already in your contact list.');
INSERT INTO language VALUES (157, 'addedtocontactlist', 'german', 'Der User wurde der Kontaktliste hinzugef�gt');
INSERT INTO language VALUES (158, 'addedtocontactlist', 'english', 'The user has been added to the contact list');
INSERT INTO language VALUES (159, 'deletefriend', 'german', 'Aus Liste entfernen');
INSERT INTO language VALUES (160, 'deletefriend', 'english', 'Remove from list');
INSERT INTO language VALUES (161, 'languagechanged', 'german', 'Die Sprach�nderung wird erst beim Login aktiv.');
INSERT INTO language VALUES (162, 'languagechanged', 'english', 'The new language will be activated with the new login.');
INSERT INTO language VALUES (163, 'languagechanged', 'german', 'Die Sprach�nderung wird erst beim Login aktiv.');
INSERT INTO language VALUES (164, 'languagechanged', 'english', 'The new language will be activated with the new login.');
INSERT INTO language VALUES (165, 'frienddeleted', 'german', 'Der User wurde aus der Kontaktliste entfernt');
INSERT INTO language VALUES (166, 'frienddeleted', 'english', 'The user has been removed from the contact list');
INSERT INTO language VALUES (167, 'send', 'german', 'Senden...');
INSERT INTO language VALUES (168, 'send', 'english', 'Send...');
INSERT INTO language VALUES (169, 'allowtags', 'german', '�brigens: Erlaubt sind auch HTML Tags und zwar folgende:&lt;p&gt;, &lt;a href=""&gt;, &lt;b&gt;, &lt;i&gt;, &lt;u&gt;, &lt;br&gt;, &lt;img&gt;, &lt;center&gt;,&lt;font&gt;,&lt;table&gt;,&lt;tr&gt;,&lt;td&gt;. Viel Spass');
INSERT INTO language VALUES (170, 'allowtags', 'english', 'PS: HTML Tags are allowed:&lt;p&gt;, &lt;a href=""&gt;, &lt;b&gt;, &lt;i&gt;, &lt;u&gt;, &lt;br&gt;, &lt;img&gt;, &lt;center&gt;,&lt;font&gt;,&lt;table&gt;,&lt;tr&gt;,&lt;td&gt;.  Lot of fun.');
INSERT INTO language VALUES (171, 'lookup', 'german', 'schauhoch');
INSERT INTO language VALUES (172, 'lookup', 'english', 'lookup');
INSERT INTO language VALUES (173, 's_smoke', 'german', 'rauchen');
INSERT INTO language VALUES (174, 's_smoke', 'english', 'smoking');
INSERT INTO language VALUES (175, 's_lookup', 'german', 'schauhoch');
INSERT INTO language VALUES (176, 's_lookup', 'english', 'lookup');
INSERT INTO language VALUES (177, 's_blink', 'german', 'zwinkern');
INSERT INTO language VALUES (178, 's_blink', 'english', 'blink');
INSERT INTO language VALUES (179, 's_show', 'german', 'zeigen');
INSERT INTO language VALUES (180, 's_show', 'english', 'show');
INSERT INTO language VALUES (181, 's_laugh', 'german', 'lachen');
INSERT INTO language VALUES (182, 's_laugh', 'english', 'laugh');
INSERT INTO language VALUES (183, 's_angryblink', 'german', 'b�sezwinkern');
INSERT INTO language VALUES (184, 's_angryblink', 'english', 'angryblink');
INSERT INTO language VALUES (185, 's_flash', 'german', 'flash');
INSERT INTO language VALUES (186, 's_flash', 'english', 'flash');
INSERT INTO language VALUES (187, 's_help', 'german', 'hilfe');
INSERT INTO language VALUES (188, 's_help', 'english', 'help');
INSERT INTO language VALUES (189, 's_wave', 'german', 'winken');
INSERT INTO language VALUES (190, 's_wave', 'english', 'wave');
INSERT INTO language VALUES (191, 's_sad', 'german', 'traurig');
INSERT INTO language VALUES (192, 's_sad', 'english', 'sad');
INSERT INTO language VALUES (193, 's_dance', 'german', 'tanzen');
INSERT INTO language VALUES (194, 's_dance', 'english', 'dance');
INSERT INTO language VALUES (195, 's_oh', 'german', 'oh');
INSERT INTO language VALUES (196, 's_oh', 'english', 'oh');
INSERT INTO language VALUES (197, 's_alien', 'german', 'alien');
INSERT INTO language VALUES (198, 's_alien', 'english', 'alien');
INSERT INTO language VALUES (199, 's_love', 'german', 'liebe');
INSERT INTO language VALUES (200, 's_love', 'english', 'love');
INSERT INTO language VALUES (201, 's_ok', 'german', 'ok');
INSERT INTO language VALUES (202, 's_ok', 'english', 'ok');
INSERT INTO language VALUES (203, 's_loveyou', 'german', 'liebedich');
INSERT INTO language VALUES (204, 's_loveyou', 'english', 'loveyou');
INSERT INTO language VALUES (205, 's_cool', 'german', 'cool');
INSERT INTO language VALUES (206, 's_cool', 'english', 'cool');
INSERT INTO language VALUES (207, 's_devil', 'german', 'teufel');
INSERT INTO language VALUES (208, 's_devil', 'english', 'devil');
INSERT INTO language VALUES (209, 's_smile', 'german', 'l�cheln');
INSERT INTO language VALUES (210, 's_smile', 'english', 'smile');
INSERT INTO language VALUES (211, 's_bad', 'german', 'schlecht');
INSERT INTO language VALUES (212, 's_bad', 'english', 'bad');
INSERT INTO language VALUES (213, 's_good', 'german', 'gut');
INSERT INTO language VALUES (214, 's_good', 'english', 'good');
INSERT INTO language VALUES (215, 's_shy', 'german', 'sch�chtern');
INSERT INTO language VALUES (216, 's_shy', 'english', 'shy');
INSERT INTO language VALUES (217, 's_danger', 'german', 'gefahr');
INSERT INTO language VALUES (218, 's_danger', 'english', 'danger');
INSERT INTO language VALUES (219, 's_annoyed', 'german', 'ver�rgert');
INSERT INTO language VALUES (220, 's_annoyed', 'english', 'annoyed');
INSERT INTO language VALUES (221, 's_question', 'german', 'frage');
INSERT INTO language VALUES (222, 's_question', 'english', 'question');
INSERT INTO language VALUES (223, 's_laughtwo', 'german', 'lachenzwei');
INSERT INTO language VALUES (224, 's_laughtwo', 'english', 'laughtwo');
INSERT INTO language VALUES (225, 's_grin', 'german', 'grinsen');
INSERT INTO language VALUES (226, 's_grin', 'english', 'grin');
INSERT INTO language VALUES (227, 'usesmilies', 'german', 'Sie k�nnen in der Nachricht auch Smilies benutzen. Setzen Sie den Smilienamen einfach in 2 Doppelpunkte (zb :l�cheln:). Eine �bersicht aller Smilies gibt es');
INSERT INTO language VALUES (228, 'usesmilies', 'english', 'In your message you can use smilies. Just put the name of the smilie in 2 doublepoints (eg :smile:). A overview over all smilies is');
INSERT INTO language VALUES (229, 'getreadconfirm', 'german', 'Lesebest�tigung anfordern');
INSERT INTO language VALUES (230, 'getreadconfirm', 'english', 'Get a readconfirmation');
INSERT INTO language VALUES (231, 'sendbymail', 'german', 'Nachricht auch per eMail senden');
INSERT INTO language VALUES (232, 'sendbymail', 'english', 'Send message by mail, too');
INSERT INTO language VALUES (237, 'readconfirmsub', 'german', 'Lesebest�tigung');
INSERT INTO language VALUES (238, 'readconfirmsub', 'english', 'Readconfirmation');
INSERT INTO language VALUES (239, 'readconfirmmsg', 'german', 'Nachricht an <%&receiver&%> gelesen. Wann, siehe Zeitstempel');
INSERT INTO language VALUES (240, 'readconfirmmsg', 'english', 'Message to <%&receiver&%> read. When see on the timestamp');
INSERT INTO language VALUES (241, 'msgsent', 'german', 'Nachricht gesendet');
INSERT INTO language VALUES (242, 'msgsent', 'english', 'Message sent');
INSERT INTO language VALUES (243, 'usercomeonline', 'german', 'ist online');
INSERT INTO language VALUES (244, 'usercomeonline', 'english', 'is online');


#
# Tablestructure for table `message`
#

CREATE TABLE message (
  id int(11) NOT NULL auto_increment,
  read char(3) NOT NULL default '',
  show char(3) NOT NULL default '',
  from varchar(50) NOT NULL default '',
  to varchar(50) NOT NULL default '',
  subject varchar(50) NOT NULL default '',
  msg tinytext NOT NULL,
  time timestamp(14) NOT NULL,
  readconfirm char(3) NOT NULL default '',
  sr char(1) NOT NULL default '',
  linkid varchar(32) NOT NULL default '',
  PRIMARY KEY  (id),
  UNIQUE KEY id (id),
  KEY id_2 (id)
) TYPE=MyISAM;


#
# Tablestructure for table `user`
#

CREATE TABLE user (
  id int(11) NOT NULL auto_increment,
  name varchar(40) NOT NULL default '0',
  email varchar(40) NOT NULL default '',
  pw varchar(50) NOT NULL default '',
  status varchar(10) NOT NULL default '',
  lasttime int(10) NOT NULL default '0',
  sid varchar(35) NOT NULL default '',
  language varchar(12) NOT NULL default '',
  friends text NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY id (id)
) TYPE=MyISAM;

    