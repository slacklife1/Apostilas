<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>Untitled</title>
</head>

<body>


<form action="addmsg.php" method="post">
<p>MsgId<input type="text" name="msgid"></p>
<p>Msg german:<input type="text" name="msggerman" size="50"></p>
<p>Msg english:<input type="text" name="msgenglish" size="50"></p>
<p><input type="submit" name="Go" value="Go"></p>
</form>


<?php 
include("include.inc.php");
if($msgid != "") {
$db = connect_database();
$cmd = "INSERT INTO `language` (`id`, `msgid`, `lg`, `msg`) VALUES ('', '$msgid', 'german', '$msggerman');";
$erg = mysql_db_query($db_name,$cmd,$db);
if(!$erg) { echo "<p>Fehler</p>" . mysql_error(); }
$cmd = "INSERT INTO `language` (`id`, `msgid`, `lg`, `msg`) VALUES ('', '$msgid', 'english', '$msgenglish');";
$erg = mysql_db_query($db_name,$cmd,$db);
if(!$erg) { echo "<p>Fehler</p>" . mysql_error(); }
mysql_close($db);

}






?>


</body>
</html>
