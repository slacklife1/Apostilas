Title: user 2 user messenger 2
Description: With this code users can send among themselves messages on your homepage.<br>
Features:<br>
Multi language support (up to now just german, english)<br>
Everybody has an own in-/ and outbox<br>
Contact List<br>
Alerts when a friend comes online<br>
Smiliesupport (about 27 :-)<br>
Readcofirmation of a message<br>
Send message by u2um and email<br>
Send messages to user which are offline<br>
Works in Netscape (tested with version 7) and Internet Explorer (tested with version 6)<br>
All mysql based<br>
Password can be remembered in a cookie<br>
Needed on your webspace:<br>
mysql support (3 tables)<br>
PHP support<br>
and little space (about 150 kb)<br>

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=709&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
