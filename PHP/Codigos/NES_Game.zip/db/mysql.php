<?php
$host = "";
$database = "";
$username = "";
$password = "";

$query[]="DROP TABLE IF EXISTS `nes_forum`;
CREATE TABLE nes_forum (
  rootID INT NOT NULL,
  parentID INT NOT NULL DEFAULT '0',
  subject text NOT NULL,
  post text NOT NULL,
  posterid text NOT NULL,
  datetime int NOT NULL,
) TYPE=MyISAM;";

$query[]="DROP TABLE IF EXISTS `nes_confirm`;
CREATE TABLE nes_confirm (
  mdhash longtext,
  username text,
  password text,
  name text,
  email text,
  age int(3) default NULL,
  sex text,
  school longtext,
  date datetime NOT NULL default '0000-00-00 00:00:00',
  theme text,
  icq text default NULL,
  aim text default NULL,
  msn text default NULL,
  yahoo text default NULL,
  yabber text default NULL
) TYPE=MyISAM;";

$query[]="DROP TABLE IF EXISTS `nes_confirm_email`;
CREATE TABLE nes_confirm_email (
  id int(8) default NULL,
  email text,
  mdhash longtext,
  date datetime NOT NULL default '0000-00-00 00:00:00'
) TYPE=MyISAM;";

$query[]="DROP TABLE IF EXISTS `nes_data`;
CREATE TABLE nes_data (
  userid text NOT NULL,
  name text NOT NULL,
  email text NOT NULL,
  age int(3) NOT NULL default '0',
  sex text NOT NULL,
  school text NOT NULL,
  theme text,
  icq text default NULL,
  aim text default NULL,
  msn text default NULL,
  yahoo text default NULL,
  yabber text default NULL
) TYPE=MyISAM;";

$query[]="DROP TABLE IF EXISTS `nes_game_options`;
CREATE TABLE nes_game_options (
  game_name text NOT NULL,
  team_members int(11) default '5',
  a_team int(11) default '0',
  a_team_members int(11) default '5',
  min_chars int(11) default '50',
  max_chars int(11) default '150',
  allow_login int(11) default '1',
  starting_sentence text,
  version text
) TYPE=MyISAM;
INSERT INTO `nes_game_options` (`game_name`, `team_members`, `a_team`, `a_team_members`, `min_chars`, `max_chars`, `allow_login`, `starting_sentence`, `version`) VALUES ('Never Ending Story',5,0,5,50,150,1,'Sun in the cloud-less sky, birds singing on the trees, a day perfect for a walk through the park, nothing could go wrong when suddenly ','1.0');";

$query[]="DROP TABLE IF EXISTS `nes_login`;
CREATE TABLE nes_login (
  userid text NOT NULL,
  username text NOT NULL,
  password text NOT NULL,
  status text NOT NULL
) TYPE=MyISAM;";

$query[]="DROP TABLE IF EXISTS `nes_player`;
CREATE TABLE nes_player (
  userid text NOT NULL,
  teamnum int(3) default NULL,
  priority int(3) default NULL,
  posts int default '0',
  chars int default '0'
) TYPE=MyISAM;";

$query[]="DROP TABLE IF EXISTS `nes_team_data`;
CREATE TABLE nes_team_data (
  id int(16) default NULL auto_increment,
  team_number int(11) default '0',
  story text NOT NULL,
  posts int(11) default '0',
  last_post1 text,
  last_post2 text,
  last_post3 text,
  last_post4 text,
  last_post5 text,
  bold int(11) default '0',
  priority int(11) default '0',
  members int(11) default '0',
  PRIMARY KEY (id)
) TYPE=MyISAM;";

$query[]="DROP TABLE IF EXISTS `nes_pm_messages`;
CREATE TABLE nes_pm_messages (
  receiverid text NOT NULL,
  senderid text NOT NULL,
  message text NOT NULL,
  id int default '0',
  subject text,
  oldmsg int NOT NULL default '0',
  date datetime NOT NULL default '0000-00-00 00:00:00'
) TYPE=MyISAM;";

$query[]="DROP TABLE IF EXISTS `nes_news`;
CREATE TABLE nes_news (
  posterid text NOT NULL,
  message text NOT NULL,
  id int default '0',
  subject text,
  date datetime NOT NULL default '0000-00-00 00:00:00'
) TYPE=MyISAM;";

mysql_connect($host, $username, $password);
mysql_select_db($database);

?>
<html>
<head><title>Database creation</title></head>
<body>
<?

while ($each_query = each($query))
{
  $result = mysql_query($each_query[1]);
  if (!$result)
  {
    print("<br><b>WARNING! We've encountered an error. Please try to reinstall.  Error: ".mysql_error())."<p><br>";
    print $each_query[1];
  }
}
mysql_close();
?>
<BR>
<b>Done</b>
</body>
</html>
