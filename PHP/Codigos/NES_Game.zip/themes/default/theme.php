<html>

<head>
<title>{title}</title>
<META HTTP-EQUIV="Expires" CONTENT="Mon, 06 Jan 1990 00:00:01 GMT">
<script language="JavaScript" src="scripts/buttons.js"></script>
<script language="JavaScript" src="scripts/timer.js"></script>
<link rel="Stylesheet" href="themes/default/style.css" type="text/css">
</head>

<body text="#FFFFFF" bgcolor="dimgray">

<!-- <TABLE BORDER="1" align="center" cellspacing="0" cellpadding="0"><TD><IMG SRC="images/nes.jpg"></TD></TABLE><BR> -->
<div align="center">
  <table cellspacing="1" cellpadding="2" border="0" align="CENTER" bgcolor="#000000">
    <tr bgcolor="#272A2F">
      <td>
        <table border="0" width="100%" cellpadding="1" cellspacing="0">
          <tr>
            <td>
{small_title}
            </td>
          </tr>
        </table>
      </td>
    </tr><tr align="center" valign="middle" bgcolor="#444444" >
      <td></td>
    </tr>
  </table>
</div>
<br>

<div align="left">
  <table>
    <tr valign="top" width="100%">
      <td>
        <table cellspacing="1" cellpadding="2" border="0" align="CENTER" bgcolor="#000000">
          <tr bgcolor="#272A2F">
            <td>
              <table border="0" width="100%" cellpadding="1" cellspacing="0">
                <tr>
                  <td nowrap="nowrap">
{menu}
                  </td>
                </tr>
              </table>
            </td>
          </tr><tr align="center" valign="middle" bgcolor="#444444" >
            <td></td>
          </tr>
        </table>
<br>
        <table cellspacing="1" cellpadding="2" border="0" align="CENTER" bgcolor="#000000">
          <tr bgcolor="#272A2F">
            <td>
              <table border="0" width="100%" cellpadding="1" cellspacing="0">
                <tr>
                  <td nowrap="nowrap">
<script language="JavaScript">
show_timer();
</script>

{admin_menu}
</center>
                  </td>
                </tr>
              </table>
            </td>
          </tr><tr align="center" valign="middle" bgcolor="#444444" >
            <td></td>
          </tr>
        </table>
      </td>
      <td>
        <table width="100%" cellspacing="1" cellpadding="2" border="0" align="CENTER" bgcolor="#000000">
          <tr bgcolor="#272A2F">
            <td>
              <table border="0" width="100%" cellpadding="1" cellspacing="0">
                <tr>
                  <td>
{content}
                  </td>
                </tr>
              </table>
            </td>
          </tr><tr align="center" valign="middle" bgcolor="#444444" >
            <td></td>
          </tr>
        </table>
      </td>
    </tr>
  </table
</div>
<br>

<div align="center">
  <table cellspacing="1" cellpadding="2" border="0" align="CENTER" bgcolor="#000000">
    <tr bgcolor="#272A2F">
      <td>
        <table border="0" width="100%" cellpadding="1" cellspacing="0">
          <tr>
            <td>
{page_stats}
            </td>
          </tr>
        </table>
      </td>
    </tr><tr align="center" valign="middle" bgcolor="#444444" >
      <td></td>
    </tr>
  </table>
</div>
<br>

<div align="center">
  <table cellspacing="1" cellpadding="2" border="0" align="CENTER" bgcolor="#000000">
    <tr bgcolor="#272A2F">
      <td>
        <table border="0" width="100%" cellpadding="1" cellspacing="0">
          <tr>
            <td>
{powered_images}
            </td>
          </tr>
        </table>
      </td>
    </tr><tr align="center" valign="middle" bgcolor="#444444" >
      <td></td>
    </tr>
  </table>
</div>

</body>
</html>
