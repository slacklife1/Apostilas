<table>
  <tr>
    <td>Topic:</td>
    <td>{subject}</td>
  </tr>
  <tr>
    <td>Posted By:</td>
    <td>{from} at <small>{date}</small></td>
  </tr>
  <tr>
    <td>Message:</td>
    <td>{message}</td>
  </tr>
</table>
