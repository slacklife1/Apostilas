<script language = "javascript">
AddButton("{title}", "{url}", "0", "3", "flat", "0000FF", "#000000");
</script>
