<?php

require("backend.php");

$login_check = $authlib->is_logged();

if (!$login_check) {

  include("includes/content/nologin.php");

}
else
{
  if (!sset($name) || !sset($sex) || !sset($template))
  {
    list ($name, $age, $sex, $school, $email, $template, $icq, $aim, $msn, $yahoo, $yabber) = $authlib->edit_retrieve($login_check[1]);
    list ($teamnum, $ppriority, $pposts, $pchars) = $gamelib->player_retrieve($login_check[1], $authlib);
    list ($l, $l, $l, $l, $l, $l, $l, $story, $l, $l) = $gamelib->team_retrieve($teamnum, $authlib);

    if ($sex == "Male")
    {
      $st = "<option value=Male selected>Male</option><option value=Female>Female</option></select>";
    }
    else
    {
      $st = "<option value=Female selected>Female</option><option value=Male>Male</option></select>";
    }
    include("includes/content/edit.php");
  }
  else
  {
    $update = $authlib->edit($login_check[1], $name, $age, $sex, $school, $template, $icq, $aim, $msn, $yahoo, $yabber);
    if ($update != 2)
    {
      include("includes/content/edit_error.php");
    }
    else
    {
      include("includes/content/edit_done.php");
    }
  }
}
generate_template();

?>
