<?php

require("backend.php");

$login_check = $authlib->is_logged();

if (!$login_check)
{
  include("includes/content/nologin.php");
}
else
{
  if ($authlib->is_admin($login_check[0]) == TRUE)
  {
    if (!sset($id))
    {
      include("includes/content/delete_post.php");
    }
    else
    {
      $result = $forumlib->deletepost($id, $authlib);
      if ($result)
      {
        include("includes/content/delete_post_done.php");
      }
      else
      {
        include("includes/content/delete_post_error.php");
      }
    }
  }
  else
  {
    include("includes/content/member.php");
  }
}
generate_template();

?>
