<?php

require("backend.php");

$login_check = $authlib->is_logged();

if (!$login_check) {

  include("includes/content/nologin.php");

}

else {

  list ($max_chars, $min_chars, $p, $p, $p, $p, $p) = $gamelib->options_retrieve($authlib);

  if ((!sset($story_continue)) || (strlen($story_continue) > $max_chars) || (strlen($story_continue) < $min_chars))
  {
    list ($teamnum, $ppriority, $p, $p) = $gamelib->player_retrieve($login_check[1], $authlib);
    list ($p, $last_post1, $last_post2, $last_post3, $last_post4, $last_post5, $priority, $p, $p, $p) = $gamelib->team_retrieve($teamnum, $authlib);
    include("includes/content/story.php");
  }
  else
  {
    $all_ok = $gamelib->post_story($team_number, $story_continue, $authlib);
    if ($all_ok)
    {
      $all_ok = $gamelib->update_player($login_check[1], strlen($story_continue), $authlib);
    }
    list ($teamnum, $ppriority, $p, $p) = $gamelib->player_retrieve($login_check[1], $authlib);
    list ($p, $last_post1, $last_post2, $last_post3, $last_post4, $last_post5, $priority, $p, $p, $p) = $gamelib->team_retrieve($teamnum, $authlib);
    include("includes/content/story.php");
  }
}
generate_template();

?>
