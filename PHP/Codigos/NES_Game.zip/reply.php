<?php

require("backend.php");

$login_check = $authlib->is_logged();

if (!$login_check) {

  include("includes/content/nologin.php");

}

else {
  if (!isset($parent) || !sset($id) || !sset($topic))
  {
    include("includes/content/forum.php");
  }
  else
  {
    $parentid = $parent;
    $topicid = $topic;
    $rootid = $id;
    include("includes/content/reply.php");
  }
}
generate_template();

?>
