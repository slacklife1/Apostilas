<?php

require("backend.php");

$register = $authlib->register($username, $password, $password2, $name, $email, $age, $sex, $school, $template);

if ($register == 2) {

  include("includes/content/register_done.php");

}

else {

  include("includes/content/register_error.php");

}
generate_template();

?>
