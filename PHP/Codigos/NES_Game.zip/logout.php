<?php

require("backend.php");

$authlib->logout();
generate_template();

?>
