<?php

require("backend.php");

$login_check = $authlib->is_logged();

if (!$login_check)
{
  include("includes/content/nologin.php");
}
else
{
  if (!sset($username))
  {
    include("includes/content/members.php");
  }
  else
  {
    list($name, $age, $sex, $school, $email, $template, $icq, $aim, $msn, $yahoo, $yabber) = $authlib->edit_retrieve($authlib->username_to_userid($username));
    list ($teamnum, $ppriority, $pposts, $pchars) = $gamelib->player_retrieve($authlib->username_to_userid($username), $authlib);
    $priv = $authlib->get_priviledges($username);
    include("includes/content/viewprofile.php");
  }
}
generate_template();

?>
