<?php

require("backend.php");

if (!sset($username) || !sset($password)) {

  include("includes/content/login_notext.php");

}

$login = $authlib->login($username, $password, $gamelib);

if (!$login) {

  include("includes/content/login_error.php");

}

else {

  include("includes/content/login_done.php");

}
generate_template();

?>
