###########################################
# NES Game ver 1.08 & NES System ver 1.22 #
###########################################
|
|==============|
| Introduction |
+==============+---------------------------------------------------------------|
|  NES is a web game that I played a while ago while in irc. It features a new |
|  authentication system(not completelly new, but improved) and many functions |
|  easy to adapt to other applications.                                        |
+=================+------------------------------------------------------------|
| SYSTEM FEATURES |
+=================+------------------------------------------------------------|
|  * The phphtmllib library is used to remove html code from all the scripts   |
|    make it easier to use it independed of the layout and to make the output  |
|    code easier to understand.                                                |
|  * authentication routines(based on authlib but with some changes)           |
|  * improved fail-proof mysql database connection(it keeps trying till it     |
|    connects)                                                                 |
|  * Changes from authlib:                                                     |
|    - password are now ecrypted using custom encryption(rc4 compatible)       |
|    - logins & data aren't matched using auto assigned ids but using a hash   |
|      key                                                                     |
|    - when email isn't send(no server support) the link is displayed          |
|    - all templates are now php coded and not html(using phphtmllib)          |
|    - instead of md5 hashing, custom encryption is used(if md5 is hard to     |
|      break, this will make it impossible to break)                           |
|    - interface is a bit easier to use(links on the left and content on the   |
|      center/right)                                                           |
|    - create members with admin/moderator rank                                |
|  * theme usage                                                               |
|    - two files are used to specify the general page layout                   |
|      * one for the whole page                                                |
|      * one for the menu link format                                          |
|    - the themes included are optimized to work with all pages, if you want   |
|      to write any new themes just use that as a start                        |
|  * private message system                                                    |
|  * news system                                                               |
|    - admins/moderators post news items                                       |
|    - the first five are shown on the main screen                             |
|  * integrated forum                                                          |
+===============+--------------------------------------------------------------|
| GAME FEATURES |
+===============+--------------------------------------------------------------|
|  * based uppon the irc game(when I played it, it was called "Never Ending    |
|    Story")                                                                   |
|    - basically players are divided into teams(5 max players in each team)    |
|    - in each team every player has to wait for his turn to post some text    |
|      for the story to continue.                                              |
|    - this way the story never ends(theoretically) since a different player   |
|      continues it every time.                                                |
|    - min 50 chars, max 150 chars.                                            |
|    - max story length 65,535 chars, if I see it is not enough I will change  |
|      it to 4,294,967,295 which will propably be enough(!)                    |
|  * individual teams(created when new players sign and existing teams fill)   |
|  * all game options in mysql database to make it easier to modify game       |
|    options(max players per team, max/min characters per post,game title,game |
|    login lock)                                                               |
|  * game stats kept(posts, chars posted) for later rankings                   |
+======+-----------------------------------------------------------------------|
| BUGS |
+======+-----------------------------------------------------------------------|
|  * sometimes when refressing a page it shows crap on the screen              |
|    - only way to fix this is to go to the login page and re-login            |
+=========+--------------------------------------------------------------------|
| CREDITS |
+=========+--------------------------------------------------------------------|
|  * Death2All: code, design                                                   |
|  * LAGUNA: original game concept                                             |
|  * GraveDigger: moral support                                                |
+=========+--------------------------------------------------------------------|
| TESTING |
+=========+--------------------------------------------------------------------|
|  * Death2All                                                                 |
+================+-------------------------------------------------------------|
| Special Thanks |
+================+-------------------------------------------------------------|
|  * whoever wrote AuthLib(no name in the script)                              |
|  * Walt A. Boring IV, waboring@buildabetterweb.com                           |
|    - phphtmllib                                                              |
|  * whoever wrote the hcemd5,rc4 encryption classes(I think I got them from   |
|    some old pear release but not sure)                                       |
|  * the site from where I copied the table code(can't remeber which)          |
|  * Zend.com for their large code and application library that gave me a      |
|    start point                                                               |
|  * Sourceforge for giving me a place to keep updates                         |
|  * YABB Team for the YABB Gold 1 layout, which was used as a reference for   |
|    the two default themes                                                    |
|  * the timer code was taken(modified) from PhpMyExplorer                     |
|    - modified to perform less updates(checks if image should change)         |
|  * themes:                                                                   |
|    - PC Plus Magazine for a past article on html design(can't find which     |
|      issue)                                                                  |
|    - YABB Team for the layout of the default themes                          |
|    - XARA WebStyle 1.2 for the images in the graphic theme                   |
|  * anyone else whos code is found in here but wasn't mentioned               |
+------------------------------------------------------------------------------|
| please email any changes to: slayer@deadmail.every1.net                      |
|------------------------------------------------------------------------------|
|
#####################
# Author: Death2All #
#####################
