<?php

require("backend.php");

$login_check = $authlib->is_logged();

if (!$login_check)
{
  include("includes/content/nologin.php");
}
else
{
  if (!sset($mode))
    $mode = '';
  if ($mode == "read" && sset($id))
  {
    include("includes/content/pm_read.php");
  }
  else if ($mode == "delete" && sset($id))
  {
    $privmsg->delete($login_check[0], $id, $authlib);
    include("includes/content/pm_list.php");
  }
  else
  {
    if (!(!sset($receiver) || !sset($message) || !sset($subject)))
    {
      $privmsg->write($login_check[0], $receiver, $message, $subject, $authlib);
    }
    include("includes/content/pm_list.php");
  }
}
generate_template();

?>
