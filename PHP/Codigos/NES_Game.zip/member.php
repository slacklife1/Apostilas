<?php

require("backend.php");

$login_check = $authlib->is_logged();

if (!$login_check) {

  include("includes/content/nologin.php");

}

else {

  include("includes/content/member.php");

}
generate_template();

?>
