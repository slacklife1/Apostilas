<?php

require("backend.php");

$login_check = $authlib->is_logged();

if (!$login_check) {

  include("includes/content/nologin.php");
  exit;

}

if (!sset($email) || !sset($email2)) {

  include("includes/content/chemail.php");

}

else {

  $chemail = $authlib->chemail($login_check[1], $email, $email2);

  if ($chemail != 2) {

    include("includes/content/chemail_error.php");

  }

  else {

    include("includes/content/chemail_done.php");

  }

}
generate_template();

?>
