<?php

require("backend.php");

list($confirm, $is_success[new_team], $is_success[team_create], $is_success[game_update], $is_success[team_update], $is_success[player_create], $is_success[first], $is_success[second], $is_success[third]) = $authlib->confirm($hash, $username, $gamelib);

if ($confirm != 2) {

  include("includes/content/confirm_error.php");

}

else {

  include("includes/content/confirm_done.php");

}
generate_template();

?>
