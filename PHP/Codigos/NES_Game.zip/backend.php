<?php
include 'includes/globals/buildtime.php';
include_once('includes/globals/localinc.php');

include 'includes/functions/subs.php';
include 'includes/functions/mesql.php';
include 'includes/functions/themes.php';
include 'includes/functions/content.php';
include 'includes/functions/mathlib.php';

//Extra classes used - start
//Independed Classes - start
include 'includes/classes/mysql.php';
include 'includes/classes/c_hcemd5.php';
include 'includes/classes/c_rc4.php';
include 'includes/classes/files.php';
include 'includes/classes/theme.php';
//Independed Classes - end
//Non-Independed Classes - start
include 'includes/classes/game.php';
include 'includes/classes/privmsg.php';
include 'includes/classes/news.php';
include 'includes/classes/forum.php';
//Non-Independed Classes - end
//Extra classes used - end

class authlib {

  var $server = "theodore2";
  var $db_user = "death2all";
  var $db_pass = "lucifer";
  var $database = "nes";
  var $datab;
  var $secret = "A1r2E0y3O4u0A5f6R7a8I9d0O1f0T2h3E0d5A6r7K0b9O1y2?3";
  var $template ="default";
  var $default_template ="default";
  var $webmaster = "slayer@deadmail.every1.net";
  var $auto_confirm = "yes";

  function authlib()
  {
    $this->datab = new mysql_db($this->server, $this->db_user, $this->db_pass, $this->database, FALSE);
  }

  function userid_to_username($id)
  {
    $query = $this->datab->query("select username from nes_login where userid='$id'");
    list($user) = $this->datab->fetch_row($query);
    return $user;
  }

  function username_to_userid($id)
  {
    $query = $this->datab->query("select userid from nes_login where username='$id'");
    list($user) = $this->datab->fetch_row($query);
    return $user;
  }

  function get_member($num)
  {
    $query = $this->datab->query("select username,userid from nes_login");
    $a = 0;
	while (list($user,$id) = $this->datab->fetch_row($query))
    {
      $a = $a + 1;
      if ($a == $num)
      {
        return array($user, $id);
      }
    }
  }

  function get_member_count()
  {
    $query = $this->datab->query("select username,userid from nes_login");
    $result = $this->datab->num_rows($query);
    if ($result < 1)
    {
      return FALSE;
    }
    else
    {
      return $result;
    }
  }

  function is_admin($username)
  {
    $query = $this->datab->query("select isadmin from nes_login where username = '$username'");
    $result = $this->datab->num_rows($query);
    if ($result < 1)
    {
      return FALSE;
    }
    else
    {
      list($stat) = $this->datab->fetch_row($query);
      $admin = n_md5("admin", array("key"=>$this->secret, "type"=>"rc4","mode"=>"encrypt"));
      $moder = n_md5("moderator", array("key"=>$this->secret, "type"=>"rc4","mode"=>"encrypt"));
      if (($stat == $admin)||($stat == $moder))
      {
        return TRUE;
      }
      else
      {
        return FALSE;
      }
    }
  }

  function get_priviledges($username)
  {
    $query = $this->datab->query("select isadmin from nes_login where username = '$username'");
    $result = $this->datab->num_rows($query);
    if ($result < 1)
    {
      return FALSE;
    }
    else
    {
      list($stat) = $this->datab->fetch_row($query);
      $admin = n_md5("admin", array("key"=>$this->secret, "type"=>"rc4","mode"=>"encrypt"));
      $moder = n_md5("moderator", array("key"=>$this->secret, "type"=>"rc4","mode"=>"encrypt"));
      if ($stat == $admin)
      {
        return "administrator";
      }
      else if ($stat == $moder)
      {
        return "moderator";
      }
      else
      {
        return "user";
      }
    }
  }

  function register ($username, $password, $password2, $name, $email, $age, $sex, $school, $theme, $icq, $aim, $msn, $yahoo, $yabber)
  {
    if (!$username || !$password || !$password2 || !$name || !$email || !$theme)
    {
      return $this->error[14];
    }
    else
    {
      if (!eregi("^[a-z ]+$", $name))
      {
        return $this->error[8];
      }
      if (!eregi("^([a-z0-9]+)([._-]([a-z0-9]+))*[@]([a-z0-9]+)([._-]([a-z0-9]+))*[.]([a-z0-9]){2}([a-z0-9])?$", $email))
      {
        return $this->error[4];
      }
      if (ereg("[^0-9]", $age))
      {
        return $this->error[10];
      }
      if ($sex != "Male" && $sex != "Female")
      {
        return $this->error[11];
      }
      if (!eregi("^[a-z0-9 ]+$", $school))
      {
        return $this->error[9];
      }
      if (strlen($username) < 3)
      {
        return $this->error[1];
      }
      if (strlen($username) > 20)
      {
        return $this->error[2];
      }
      if (!ereg("^[[:alnum:]_-]+$", $username))
      {
        return $this->error[3];
      }
      if ($password != $password2)
      {
        return $this->error[0];
      }
      if (strlen($password) < 3)
      {
        return $this->error[5];
      }
      if (strlen($password) > 20)
      {
        return $this->error[6];
      }
      if (!ereg("^[[:alnum:]_-]+$", $password))
      {
        return $this->error[7];
      }

      $query = $this->datab->query("select id from nes_login where username = '$username'");
      $result = $this->datab->num_rows($query);

      if ($result > 0)
      {
        return $this->error[12];
      }

      $query = $this->datab->query("select id from nes_data where email = '$email'");
      $result = $this->datab->num_rows($query);

      if ($result > 0)
      {
        return $this->error[13];
      }

      $tex = $this->secret.":".$username;
      $hash = n_md5($tex);

      $is_success = $this->datab->query("insert into nes_confirm values ('$hash', '$username', '$password', '$name', '$email', '$age', '$sex', '$school', now(), '$theme', '$icq', '$aim', '$msn', '$yahoo', '$yabber')");

      if (!$is_success)
      {
        return $this->error[16];
      }

      $thh = @mail($email, "NES Registration", "Thank You, $name for registering to NES. Here is the information we recieved :\n\nName     : $name\nEmail    : $email\nAge      : $age\nSex      : $sex\nSchool   : $school\nICQ      : $icq\nAIM      : $aim\nMSN      : $msn\nYahoo    : $yahoo\nYabber   : $yabber\nUsername : $username\nPassword : $password\nYou need to confirm the account by pointing your browser at \nhttp://www.death2all.f2s.com/nes/confirm.php?hash=$hash&username=$username\nIf you did not apply for the account please ignore this message.", "From: AuthMan");
      $th = '<a href="confirm.php?hash='.$hash.'&username='.$username.'">here</a>';
      if ((!$thh) || ($this->auto_confirm == "yes"))
      {
        print $th;
      }
      return 2;
    }
  }

  function login ($username, $password, $game)
  {
    if (!$username || !$password)
    {
      return $this->error[14];
    }
    else
    {
      if (!eregi("^[[:alnum:]_-]+$", $username))
      {
        return $this->error[3];
      }
      if (!eregi("^[[:alnum:]_-]+$", $password))
      {
        return $this->error[7];
      }

      list ($l, $l, $l, $l, $l, $can_login, $l) = $game->options_retrieve($this);
      if (is_true($can_login) == 0)
      {
        return $this->error[24];
      }

      $pass = n_md5($password, array("key"=>$this->secret, "type"=>"rc4","mode"=>"encrypt"));
      $query = $this->datab->query("select userid from nes_login where username = '$username' and password = '$pass'");
      $result = $this->datab->num_rows($query);

      if ($result < 1)
      {
        return false;
      }
      else
      {
        list ($id) = $this->datab->fetch_row($query);
        $tex = $username.":".$this->secret;
        $hash = n_md5($tex);
        setcookie("hello", "$username:$hash:$id", time()+3600);
        return 2;
      }
    }
  }

  function get_template($username)
  {
    $this->template = $this->default_template;

    $query = $this->datab->query("select userid from nes_login where username = '$username'");
    if ($query >= 1)
    {
      list($id) = $this->datab->fetch_row($query);
      $query = $this->datab->query("select theme from nes_data where userid = '$id'");
      $result = $this->datab->num_rows($query);
      if ($result >= 1)
      {
        list($theme) = $this->datab->fetch_row($query);
        if (sset($theme))
        {
          $this->template = $theme;
        }
      }
    }
    return $this->template;
  }

  function is_logged ()
  {
    global $hello;

    $session_vars = explode(":", $hello);
    $tex = $session_vars[0].":".$this->secret;
    $hash = n_md5($tex);

    if ($hash != $session_vars[1])
    {
      return false;
    }
    else
    {
      return array($session_vars[0], $session_vars[2],$session_vars[3],$session_vars[4]);
    }
  }

  function logout ()
  {
    setcookie("hello");
    header("Location: $this->logout_url");
  }

  function edit_retrieve ($id)
  {
    $query = $this->datab->query("select * from nes_data where userid = '$id'");
    list ($id, $name, $email, $age, $sex, $school, $theme, $icq, $aim, $msn, $yahoo, $yabber) = $this->datab->fetch_row($query);
    return array($name, $age, $sex, $school, $email, $theme, $icq, $aim, $msn, $yahoo, $yabber);
  }

  function edit ($id, $name, $age, $sex, $school, $theme, $icq, $aim, $msn, $yahoo, $yabber)
  {
    if (!$name || !$sex || !$theme)
    {
      return $this->error[14];
    }
    else
    {
      if (!eregi("^[a-z ]+$", $name))
      {
        return $this->error[8];
      }
      if (!eregi("^[a-z0-9 ]+$", $school))
      {
        return $this->error[9];
      }
      if (ereg("[^0-9]", $age))
      {
        return $this->error[10];
      }
      if ($sex != "Male" && $sex != "Female")
      {
        return $this->error[11];
      }

      $query = $this->datab->query("update nes_data set name = '$name', age = '$age', sex = '$sex', school = '$school', theme='$theme', icq='$icq', aim='$aim', msn='$msn', yahoo='$yahoo', yabber='$yabber' where userid = '$id'");

      if (!$query)
      {
        $this->error[20];
      }
      return 2;
    }
  }

  function add_login($username,$pass, $hash,$stat)
  {
    $query = $this->datab->query("insert into nes_login (username, password, userid, isadmin) values ('$username', '$pass', '$hash', '$stat')");
    return $query;
  }

  function add_data($name, $email, $age, $sex, $school, $hash, $theme, $icq, $aim, $msn, $yahoo, $yabber)
  {
    $query = $this->datab->query("insert into nes_data (name, email, age, sex, school, userid, theme, icq, aim, msn, yahoo, yabber) values ('$name', '$email', '$age', '$sex', '$school', '$hash', '$theme', '$icq', '$aim', '$msn', '$yahoo', '$yabber')");
    return $query;
  }

  function clear_confirm($username)
  {
    $query = $this->datab->query("delete from nes_confirm where username = '$username'");
    return $query;
  }

  function confirm ($hash, $username, $game)
  {
    if (!$hash || !$username)
    {
      return array($this->error[14]);
    }
    else
    {
      $query = $this->datab->query("select * from nes_confirm where mdhash = '$hash' AND username = '$username'");
      $result = $this->datab->num_rows($query);

      if ($result < 1)
      {
        return array($this->error[15], $is_success[new_team], $is_success[team_create], $is_success[game_update], $is_success[team_update], $is_success[player_create], $is_success[first], $is_success[second], $is_success[third]);
      }

      list($hd,$username,$password,$name,$email,$age,$sex,$school,$dd,$theme, $icq, $aim, $msn, $yahoo, $yabber) = $this->datab->fetch_row($query);

      list($grow[a_team], $grow[a_team_members], $newteam) = $game->get_empty_position($this);

      list($m, $m, $m, $m, $m, $m, $grow[starting_sentence]) = $game->options_retrieve($this);
      if ($newteam == TRUE)
      {
        $is_success[new_team] = TRUE;
        $is_success[team_create] = $game->team_create($grow[a_team],$grow[starting_sentence],$this);
      }
      $is_success[game_update] = $game->game_update($grow[a_team], $grow[a_team_members], $this);
      $is_success[team_update] = $game->team_update($grow[a_team], $grow[a_team_members], "", $this);
      $pass = n_md5($password, array("key"=>$this->secret, "type"=>"rc4","mode"=>"encrypt"));
      $stat = n_md5("member", array("key"=>$this->secret, "type"=>"rc4","mode"=>"encrypt"));
      if (($grow[a_team] == 1) && ($grow[a_team_members] == 1))
      {
        $stat = n_md5("admin", array("key"=>$this->secret, "type"=>"rc4","mode"=>"encrypt"));
      }
      $is_success[first] = $this->add_login($username,$pass,$hash,$stat);
      $is_success[player_create] = $game->player_create($hash, $grow[a_team], $grow[a_team_members], $this);

      if ($is_success[first])
      {
        $is_success[second] = $this->add_data($name, $email, $age, $sex, $school, $hash, $theme, $icq, $aim, $msn, $yahoo, $yabber);

        if ($is_success[second])
        {
          $is_success[third] = $this->clear_confirm($username);
        }
      }

      if (!$is_success[first])
      {
        return array($this->error[16], $is_success[new_team], $is_success[team_create], $is_success[game_update], $is_success[team_update], $is_success[player_create], $is_success[first], $is_success[second], $is_success[third]);
      }
      if (!$is_success[second])
      {
        @mail($email, "Registration Error", "Thank You, $name for (trying to) register to NES. Unfortunately due to an unknown database fault\n
               we were unable to add your complete information to the database. So please login to your account and \n
        click on remove account. And then re-register for the account.", "From: AuthMan");
        return array($this->error[17], $is_success[new_team], $is_success[team_create], $is_success[game_update], $is_success[team_update], $is_success[player_create], $is_success[first], $is_success[second], $is_success[third]);
      }
      if (!$is_success[third])
      {
        @mail($this->webmaster, "Alert, Purge Account!!!", "Hey man, looks like your database sucked at the wrong moment, luckily he was able to stuff in his              info at the right time and place, but something happened and I wasn't able to remove his entry from the confirmation table.", "From: AuthMan");
        return array("2", $is_success[new_team], $is_success[team_create], $is_success[game_update], $is_success[team_update], $is_success[player_create], $is_success[first], $is_success[second], $is_success[third]);
      }
      @mail($email, "NES Registration Confirmation", "Thank You, $name for registering to NES. Here is the information we recieved :\n\nName     : $name\nEmail    : $email\nAge      : $age\nSex      : $sex\nSchool   : $school\nTheme    : $theme\nUsername : $username\nPassword : $password", "From: AuthMan");
      return array("2", $is_success[new_team], $is_success[team_create], $is_success[game_update], $is_success[team_update], $is_success[player_create], $is_success[first], $is_success[second], $is_success[third]);
    }
  }

  function conf_flush ()
  {
    $query = $this->datab->query("delete from nes_confirm where date_add(date, interval 2 day) < now()");
    if (!$query)
    {
      return $this->error[18];
    }
    return 2;
  }

  function lostpwd ($email)
  {
    if (!$email)
    {
      return $this->error[14];
    }
    $query = $this->datab->query("select nes_login.password, nes_login.username from nes_login, nes_data where nes_data.email = '$email' and nes_login.userid = nes_data.userid");
    $result = $this->datab->num_rows($query);

    if ($result < 1)
    {
      return $this->error[19];
    }

    list($password, $username) = $this->datab->fetch_row($query);
    $pass = n_md5($password, array("key"=>$this->secret, "type"=>"rc4","mode"=>"decrypt"));
    @mail($email, "Account Info", "Dear User,\nAs per your request here is your account information:\n\nUsername: $username\nPassword: $pass\nWe hope you remember your password next time!", "From: AuthMan");
    return 2;
  }

  function chemail ($id, $email, $email2)
  {
    if ($email != $email2)
    {
      return $this->error[14];
    }
    else
    {
      if (!eregi("^([a-z0-9]+)([._-]([a-z0-9]+))*[@]([a-z0-9]+)([._-]([a-z0-9]+))*[.]([a-z0-9]){2}([a-z0-9])?$", $email))
      {
        return $this->error[4];
      }
      $query = $this->datab->query("select userid from nes_data where email = '$email'");
      $result = $this->datab->num_rows($query);

      if ($result > 0)
      {
        list($id_from_db) = $this->datab->fetch_row($query);

        if ($id_from_db != $id)
        {
          return $this->error[13];
        }
        return $this->error[23];
      }
      $tex = $id.":".$email.":".$this->secret;
      $mdhash = n_md5($tex);

      $query = $this->datab->query("insert into nes_confirm_email values ('$id', '$email', '$mdhash', now())");
      if (!$query)
      {
        $this->error[20];
      }

      $thh = @mail($email, "NES Email Change", "Dear User, You have requested an email change \nin our database. We, to ensure authenticity of the email\nexpect you to goto http://www.death2all.net/nes/confirm_email.php?mdhash=$mdhash&id=$id&email=$email\n Thank You!");
      $th = '<a href="confirm_email.php?mdhash='.$mdhash.'&id='.$id.'&email='.$email.'">here</a>';
      if (!$thh)
        print $th;
      return 2;
    }
  }

  function confirm_email($id, $email, $mdhash)
  {
    if (!$id || !$email || !$mdhash)
    {
      return $this->error[14];
    }
    else
    {
      $query = $this->datab->query("select * from nes_confirm_email where id = '$id' AND email = '$email' AND mdhash = '$mdhash'");
      $result = $this->datab->num_rows($query);

      if ($result < 1)
      {
        return $this->error[15];
      }

      $update = $this->datab->query("update nes_data set email = '$email' where userid = '$id'");
      $delete = $this->datab->query("delete from nes_confirm_email where email = '$email'");
      return 2;
    }
  }

  function email_flush ()
  {
    $query = $this->datab->query("delete from nes_confirm_email where date_add(date, interval 2 day) < now()");
    if (!$query)
    {
      return $this->error[18];
    }
    return 2;
  }

  function chpass ($id, $password, $password2)
  {
    if ($password != $password2)
    {
      return $this->error[0];
    }
    else
    {
      if (strlen($password) < 5)
      {
        return $this->error[5];
      }

      if (strlen($password) > 20)
      {
        return $this->error[6];
      }
      if (!ereg("^[[:alnum:]_-]+$", $password))
      {
        return $this->error[7];
      }

      $pass = n_md5($password, array("key"=>$this->secret, "type"=>"rc4","mode"=>"encrypt"));
      $query = $this->datab->query("update nes_login set password = '$pass' where userid = '$id'");

      if (!$query)
      {
        return $this->error[21];
      }

      return 2;
    }
  }

  function delete_login($id)
  {
    $query = $this->datab->query("delete from nes_login where userid = '$id'");
    return $query;
  }

  function delete_data($id)
  {
    $query = $this->datab->query("delete from nes_data where userid = '$id'");
    return $query;
  }

  function delete($id, $game)
  {
    $game->delete_player($id, $this);
    $query = $this->delete_login($id);
    $query = $this->delete_data($id);
    setcookie("hello");
    return 2;
  }

  var $error = array
      (
        "Passwords do not match each other",
        "Username is too short. Minimum is 3 valid characters.",
        "Username is too long. Maximum is 11 valid characters.",
        "Username contains invalid characters.",
        "Email address format is invalid.",
        "Password is too short. Minimum is 3 valid characters.",
        "Password is too long. Maximum is 20 valid characters.",
        "Password contains invalid characters.",
        "Name contains invalid characters.",
        "School contains invalid characters.",
        "Age contains invalid characters.",
        "Sex can either be Male or Female.",
        "Username already exists.",
        "A user with that email already exists.",
        "Some fields were left empty.",
        "Temporary ID and Username combination incorrect, or account purged.",
        "Unknown database failure, please try later.",
        "Your login information was entered but due to an unknown error other details could not be filled in, so please <a href=\"login.php\">login</a> to your account and remove it immediately and then re-register.",
        "The flushing process was unsuccessful.",
        "No username corresponding to that email.",
        "Your reg. details couldnot be updated due to a database fault.",
        "Your password couldnot be updated due to a database fault.",
        "Your emails donot match.",
        "I think your current email and the email you entered for modification are same hence I can't change anything.",
        "Server closed for updates. Try again later."
      );
  var $unauth_links = array
      (
        "Main|index.php|1|index.gif",
        "Login|login.php|2|index.gif",
        "Register|register.php|3|index.gif"
      );

  var $member_links = array
      (
        "Main|member.php|1|member.gif",
        "Messages|messages.php|2|messages.gif",
        "Game Controls|story.php|2|story.gif",
        "Member List|members.php|2|members.gif",
        "Edit Profile|edit.php|2|edit.gif",
        "Forum|forum.php|2|forum.gif",
        "Logout|logout.php|3|logout.gif"
      );

  var $admin_links = array
      (
        "Manage News|news_post.php|1|news_post.gif",
        "Flush logins|flush.php|2|flush.gif",
        "Flush emails|flush_email.php|2|flush_email.gif",
        "Manage Forum|delete_post.php|3|delete_post.gif"
      );

  var $logout_url = "index.php";
}

$authlib = new authlib;

$login_check = '';
?>
