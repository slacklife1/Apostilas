<?php

require("backend.php");

$login_check = $authlib->is_logged();

if (!$login_check)
{
  include("includes/content/nologin.php");
}
else
{
  if (!sset($post) || !sset($subject) || !isset($parentid))
  {
    include("includes/content/".$page.".php");
  }
  else
  {
    $result = $forumlib->newpost($subject, $post, $login_check[0], $parentid, $authlib);
    if ($result)
    {
      include("includes/content/post_done.php");
    }
    else
    {
      include("includes/content/post_error.php");
    }
  }
}
generate_template();

?>
