<?php
require("backend.php");
include("includes/content/login.php");
generate_template();

?>
