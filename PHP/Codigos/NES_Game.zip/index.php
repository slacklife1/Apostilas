<?php
require("backend.php");
include("includes/content/index.php");
generate_template();

?>
