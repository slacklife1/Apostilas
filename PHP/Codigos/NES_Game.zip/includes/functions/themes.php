<?php

function template_select($default, $dirname = "themes")
{
  $dir = opendir($dirname);

  $template_select = "<select name=\"template\">\n";
  while($file = readdir($dir))
  {
    unset($selected);

    if($file != "." && $file != ".." && $file != "CVS")
    {
      if($file == $default)
      {
        $selected = " selected=\"selected\"";
      }
      $template_select .= "<option value=\"$file\"$selected>$file</option>\n";
    }
  }
  $template_select .= "</select>";

  closedir($dir);

  return($template_select);
}

function news_item($date, $subject, $message, $from)
{
  global $login_check, $authlib, $file_utils;

  $dir = "themes/".$authlib->get_template($login_check[0])."/";

  $theme_news_item = new Theme($dir."news_item.php");
  $theme_news_item->Assign("date", $date);
  $theme_news_item->Assign("subject", $subject);
  $theme_news_item->Assign("message", $message);
  $theme_news_item->Assign("from", $from);
  return $theme_news_item->Parse();
}

function privmsg_item($date, $subject, $message, $from)
{
  global $login_check, $authlib, $file_utils;

  $dir = "themes/".$authlib->get_template($login_check[0])."/";

  $theme_privmsg_item = new Theme($dir."privmsg_item.php");
  $theme_privmsg_item->Assign("date", $date);
  $theme_privmsg_item->Assign("subject", $subject);
  $theme_privmsg_item->Assign("message", $message);
  $theme_privmsg_item->Assign("from", $from);
  return $theme_privmsg_item->Parse();
}

function forum_item($date, $subject, $message, $from)
{
  global $login_check, $authlib, $file_utils;

  $dir = "themes/".$authlib->get_template($login_check[0])."/";

  $theme_forum_item = new Theme($dir."forum_item.php");
  $theme_forum_item->Assign("date", $date);
  $theme_forum_item->Assign("subject", $subject);
  $theme_forum_item->Assign("message", $message);
  $theme_forum_item->Assign("from", $from);
  return $theme_forum_item->Parse();
}

function forum_thread($subject, $from, $id)
{
  global $login_check, $authlib, $file_utils, $forumlib;

  $dir = "includes/special/";

  $theme_forum_thread = new Theme($dir."forum_thread.php");
  $theme_forum_thread->Assign("from", $from);
  $theme_forum_thread->Assign("subject", $subject);
  $theme_forum_thread->Assign("children", ''.(0+$forumlib->has_children($id, $authlib)).'');
  return $theme_forum_thread->Parse();
}

$ctu;

function forum_top($a="", $b="", $c="")
{
  $p = '<table width="100%" cellspacing="0" cellpadding="0" border="0"><tr>';
  if ($a != "")
    $p .= '<td class="forum_title_bg"><b>'.$a.'</b></td>';
  if ($b != "")
    $p .= '<td class="forum_title_bg"><b>'.$b.'</b></td>';
  if ($c != "")
    $p .= '<td class="forum_title_bg"><b>'.$c.'</b></td>';
  $p .= '</tr>';
  return $p;
}

function forum_child($date, $subject, $message, $from)
{
  global $login_check, $authlib, $file_utils, $ctu;

  if (!isset($ctu))
    $ctu = 1;
  if ($ctu == 1)
    $col = "forum_thread_bg1";
  if ($ctu == 2)
    $col = "forum_thread_bg2";
  $dir = "includes/special/";

  $theme_forum_item = new Theme($dir."forum_child.php");
  $theme_forum_item->Assign("date", $date);
  $theme_forum_item->Assign("subject", $subject);
  $theme_forum_item->Assign("message", $message);
  $theme_forum_item->Assign("from", $from);
  $theme_forum_item->Assign("color", $col);

  $ctu = $ctu + 1;
  if ($ctu == 3)
  {
    $ctu = 1;
  }
  return $theme_forum_item->Parse();
}

function generate_template()
{
  global $login_check, $authlib, $file_utils;

  $gzip = FALSE;
  $gzip = pre_mod_gzip();

  $dir = "themes/".$authlib->get_template($login_check[0])."/";

  $theme_main = new Theme($dir."theme.php");
  $theme_main->Assign("title", print_title());
  $theme_main->Assign("small_title", print_small_title());
  $theme_main->Assign("content", add_content());
  $theme_main->Assign("page_stats", print_page_stats());
  $theme_main->Assign("powered_images", add_powered_images($gzip));

  if (!$login_check)
  {
    $links = $authlib->unauth_links;
  }
  else
  {
    if ($authlib->is_admin($login_check[0]) == TRUE)
    {
      $links = $authlib->member_links;
      $alinks = $authlib->admin_links;
    }
    else
    {
      $links = $authlib->member_links;
    }
  }
  $theme_menu = new Theme($dir."menu_link.php");

  $mread = $file_utils->read($dir."menu_link.php");
  while ($each_link = each($links))
  {
    $result = explode("|", $each_link[1]);
    $menulink = $theme_menu;
    $menulink->Assign("title", $result[0]);
    $menulink->Assign("url", $result[1]);
    $menulink->Assign("position", $result[2]);
    $menulink->Assign("image", $result[3]);
    $menu .= $menulink->Parse();
  }
  if (sset($alinks))
  {
    while ($each_link = each($alinks))
    {
      $result = explode("|", $each_link[1]);
      $amenulink = $theme_menu;
      $amenulink->Assign("title", $result[0]);
      $amenulink->Assign("url", $result[1]);
      $amenulink->Assign("position", $result[2]);
      $amenulink->Assign("image", $result[3]);
      $amenu .= $amenulink->Parse();
    }
  }
  $theme_main->Assign("menu", $menu);
  $theme_main->Assign("admin_menu", $amenu);
  $read = $theme_main->Parse();

  header("Expires: Tue, 1 Jan 1980 12:00:00 GMT");
  header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
  header("Cache-Control: no-cache");
  header("Pragma: no-cache");
  echo $read;

  if ($gzip == TRUE)
  {
    post_mod_gzip(FALSE);
  }
}
?>
