<?php

$mesql_db;
function mesql_connect($db_host, $db_username, $db_password, $db_name) {
  global $mesql_db;
  $timeout = 15;
  if($fp = fsockopen($db_host, 3306, &$errno, &$errstr, $timeout)){
    fclose($fp);
  }
  $mesql_db = @mysql_connect($db_host, $db_username, $db_password);
  @mysql_select_db($db_name, $mesql_db);
  if ($errno) {
    @mysql_close($mesql_db);
    usleep(100);
    mesql_connect($db_host, $db_username, $db_password, $db_name);
  }
  $result = @mysql_query("SELECT 1");
  while(!$result) {
    @mysql_close($mesql_db);
    usleep(110);
    mesql_connect($db_host, $db_username, $db_password, $db_name);
    $result = @mysql_query("SELECT 1");
  }
  return $mesql_db;
}

function mesql_pconnect($db_host, $db_username, $db_password, $db_name) {
  global $mesql_db;
  $timeout = 15;
  if($fp = fsockopen($db_host, 3306, &$errno, &$errstr, $timeout)){
    fclose($fp);
  }
  $mesql_db = @mysql_pconnect($db_host, $db_username, $db_password);
  @mysql_select_db($db_name, $mesql_db);
  if ($errno) {
    @mysql_close($mesql_db);
    usleep(100);
    mesql_pconnect($db_host, $db_username, $db_password, $db_name);
  }
  $result = @mysql_query("SELECT 1");
  while(!$result) {
    @mysql_close($mesql_db);
    usleep(110);
    mesql_pconnect($db_host, $db_username, $db_password, $db_name);
    $result = @mysql_query("SELECT 1");
  }
  return $mesql_db;
}

?>
