<?php

function html_img_a( $attributes ) {
  return new IMGtag( $attributes );
}

function html_a_a($attributes, $content) {

  $a = new Atag( $attributes );
  $a->push( $content );
  return $a;
}

function html_img_href_a( $img, $aa) {
    $img = html_img_a($img);
    $img->newline_after_opentag = FALSE;
    $img->indent_flag = FALSE;
    $a = html_a_a($aa, $img);
    return $a;
}

function print_page_stats()
{
  global $nestable, $player, $dbs, $db, $starttime, $gzip_text;

  $mtime = microtime();
  $mtime = explode(" ",$mtime);
  $mtime = $mtime[1] + $mtime[0];
  $endtime = $mtime;
  $totaltime = ($endtime - $starttime);

  $page = new PTag;
  $contenta = new TABLEtag;
  $contenta->push(sprintf("<font size=\"-2\"><b>NES</b> Created this page in %f seconds</font>", $totaltime));
  $page->push($contenta);
  return $page->render();
}

function add_powered_images($gzipp=FALSE)
{
  global $nestable, $player, $dbs, $db, $starttime, $gzip_text;

  $page = new PTag;
  $contentb = new TABLEtag;

  $th = getenv("SERVER_SOFTWARE");
  if(strstr($th, 'Apache'))
    $contentb->push(html_img_href_a(array("src"=>"images/powered/apache.gif","alt"=>"Apache Web Server", "border"=>0, "hspace"=>10), array("href"=>"http://www.apache.org","target"=>"blank")));
  else if(strstr($th, 'Xitami'))
    $contentb->push(html_img_href_a(array("src"=>"images/powered/xitami.gif","alt"=>"Xitami Web Server", "border"=>0, "hspace"=>10), array("href"=>"http://www.imatix.com","target"=>"blank")));

  $th = getenv("HTTP_USER_AGENT");
  if(strstr($th, 'MSIE'))
    $contentb->push(html_img_href_a(array("src"=>"images/powered/msie.gif","alt"=>"Microsoft Internet Explorer", "border"=>0, "hspace"=>10), array("href"=>"http://www.microsoft.com","target"=>"blank")));
  else if(strstr($th, 'Netscape'))
    $contentb->push(html_img_href_a(array("src"=>"images/powered/netscape.gif","alt"=>"Microsoft Internet Explorer", "border"=>0, "hspace"=>10), array("href"=>"http://www.microsoft.com","target"=>"blank")));

  $contentb->push(html_img_href_a(array("src"=>"images/powered/php.gif","alt"=>"PHP Scripting Language", "border"=>0, "hspace"=>10), array("href"=>"http://www.php.net","target"=>"blank")));
  $contentb->push(html_img_href_a(array("src"=>"images/powered/mysql.gif","alt"=>"mySQL Database", "border"=>0, "hspace"=>10), array("href"=>"http://www.mysql.com","target"=>"blank")));

  $th = getenv("HTTP_ACCEPT_ENCODING");
  if(strstr($th, 'gzip'))
    $contentb->push(html_img_a(array("src"=>"images/powered/mod_gzip.gif","alt"=>"mod_gzip Compression", "border"=>0, "hspace"=>10)));

  $page->push($contentb);
  return $page->render();

}

?>
