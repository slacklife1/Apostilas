<?php

function arrayValuesToString( $ar, $nl="", $dolast=true )
{
  $str = "";
  reset($ar);
  $size = sizeof($ar);
  $i = 1;
  while(list($k, $v) = each($ar))
  {
    if($dolast == false)
    {
      if($i < $size)
      {
        $str .= $ar[$k].$nl;
      }
      else
      {
        $str .= $ar[$k];
      }
    }
    else
    {
      $str .= $ar[$k].$nl;
    }
    $i++;
  }
  return $str;
}

function include_all($ar)
{
  while ($e = each($ar))
  {
    $f = $e[1];
    include "$f";
  }
}

function is_true($value)
{
  if (sset($value))
  {
    return $value;
  }
  else
  {
    return FALSE;
  }
}

function show_true($value, $true_val, $false_val)
{
  $val = is_true($value);
  if ($val)
  {
    return $true_val;
  }
  else if ($val == FALSE)
  {
    return $false_val;
  }
  else
  {
    return FALSE;
  }
}

//Usage: n_md5("text to crypt", array("key"=>"yourkey","type"=>"md5/hcemd5/rc4",
//              "mode"=>"en/decrypt","cryptkey"=>"yes/no"))
//encryption is text and not binary(even though binary data is supported)
//
//NOTICE: without any options it is the same as:
// $text = "text to crypt";     \
// $s = md5($text);              > $result = n_md5("text to crypt");
// $result = md5($text.":".$s); /
//
function n_md5($text, $options = array())
{
  $tex = $text;
  if (sset($options['key']))
  {
      $key = $options['key'];
  }
  else
  {
    $key = $text;
  }
  if (sset($options['cryptkey']))
  {
    $cryptkey = $options['cryptkey'];
  }
  else
  {
    $cryptkey = "yes";
  }
  if (sset($options['type']))
  {
    $type = $options['type'];
  }
  else
  {
    $type = "md5";
  }
  if (sset($options['mode']))
  {
    $mode = $options['mode'];
  }
  else
  {
    $mode = "encrypt";
  }

  if ($cryptkey == "yes")
    $key = md5($key);

  if ($type == "md5")
  {
    $tex = $tex.":".$key;
    $tex = md5($tex);
  }
  else if ($type == "hcemd5")
  {
    srand((double)microtime()*32767);
    $rand = rand(1, 32767);
    $rand = pack('i*', $rand);
    if ($mode == "encrypt")
    {
      $t_hcemd5 = new Crypt_HCEMD5($key, $rand);
      $tex = $hcemd5->encodeMimeSelfRand($tex);
    }
    if ($mode == "decrypt")
    {
      $t_hcemd5 = new Crypt_HCEMD5($key, '');
      $tex = $t_hcemd5->DecodeMimeSelfRand($tex);
    }
  }
  else if ($type == "rc4")
  {
    $rc4 = new Crypt_RC4;
    if ($mode == "encrypt")
    {
      $rc4->crypt($tex, $key);
      $tex = base64_encode($tex);
    }
    if ($mode == "decrypt")
    {
      $tex = base64_decode($tex);
      $rc4->decrypt($tex, $key);
    }
  }
  else
    $tex = $text;

  return $tex;
}

function pre_mod_gzip()
{
  $do_gzip_compress = FALSE;

  $phpver = phpversion();

  if($phpver >= "4.0.4pl1")
  {
    if(extension_loaded("zlib"))
    {
      $do_gzip_compress = TRUE;
      ob_start("ob_gzhandler");
    }
  }
  else if($phpver > "4.0")
  {
    $t = getenv("HTTP_ACCEPT_ENCODING");
    if(strstr($t, 'gzip'))
    {
      if(extension_loaded("zlib"))
      {
        $do_gzip_compress = TRUE;
        ob_start();
        ob_implicit_flush(0);
        header("Content-Encoding: gzip");
      }
    }
  }
  return $do_gzip_compress;
}

function post_mod_gzip($deb)
{
  $gzip_contents = ob_get_contents();
  ob_end_clean();
  if($deb == TRUE)
  {
    $s = "<p>Not compress length: ".($u=strlen($gzip_contents));
    $s .= "<br>Compressed length: ".($c=strlen(gzcompress($gzip_contents)));
    $s .= "<br>Ratio: ".round($c/$u*100,2)."%";
    $gzip_contents .= $s;
  }

  $gzip_size = strlen($gzip_contents);
  $gzip_crc = crc32($gzip_contents);

  $gzip_contents = gzcompress($gzip_contents, 9);
  $gzip_contents = substr($gzip_contents, 0, strlen($gzip_contents) - 4);

  echo "\x1f\x8b\x08\x00\x00\x00\x00\x00";
  echo $gzip_contents;
  echo pack("V", $gzip_crc);
  echo pack("V", $gzip_size);
}

function o_iftrue ($val, $str)
{
  if (sset($val))
  {
    return(sprintf($str, $val));
  }
}

function p_iftrue ($val, $str)
{
  print o_iftrue($val, $str);
}

function o_1or2 ($val,$str1,$str2)
{
  if (sset($val))
  {
    if ($val == 1)
    {
      return(sprintf($str1,$val));
    }
    else
    {
      return(sprintf($str2,$val));
    }
  }
  else
  {
    return(false);
  }
}

function p_1or2 ($val,$str1,$str2)
{
  print o_1or2 ($val,$str1,$str2);
}

function o_0or1 ($val,$str1,$str2)
{
  if (empty($val) || !$val)
  {
    if (isset($val))
    {
      return(sprintf($str1,$val));
    }
    else
    {
      return($str1);
    }
  }
  else
  {
    return(sprintf($str2,$val));
  }
}

function p_0or1 ($val,$str1,$str2)
{
  print o_0or1 ($val,$str1,$str2);
}

function sset($val)
{
  if (isset($val) && $val)
  {
    return TRUE;
  }
  else
  {
    return FALSE;
  }
}

function random_string($le, $poss = "", $rr = "0")
{
  if (!isset($poss) || !$poss)
  {
    $poss = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890!@#$%^&*()";
  }
  if ($rr == "1")
  {
    srand((double)microtime() * 1000000);
  }
  else
  {
    srand(date("s"));
  }
  $str = "";
  while(strlen($str) < $le)
  {
    $str .= substr($poss, (rand() % (strlen($poss))), 1);
  }
  return($str);
}

?>
