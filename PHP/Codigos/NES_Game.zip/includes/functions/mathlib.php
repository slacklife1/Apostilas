<?php 

function roundoff($v)
{
  if ( $v - floor($v) >= 0.5)
  {
    return(ceil($v));
  }
  else
  {
    return(floor($v));
  }
} 

function deg2radb($degrees)
{
  return ((pi(void) * $degrees) / doubleval(180));
} 

function rad2degb($radians)
{ 
  return (($radians * doubleval(180)) / pi(void));
} 

function baselog($base,$val)
{
  return ((log10($val))/(log10($base)));
} 

function factorial($number)
{ 
  $a = $b = (int) $number;
  while ($b>1)
  {
    --$b;
    $a = $a * $b;
  }
  return $a;
} 

function gcd($x,$y)
{ 
  $x = abs($x);
  $y = abs($y);
  if ( $x + $y = 0 )
  {
    return "ERROR";
  }
  else
  {
    while ($x > 0)
    {
      $z = $x;
      $x = $y % $x;
      $y = $z;
    }
    return $z;
  }
} 

function eval_exp($inputExp="0")
{
  $resExp = "\$Result" . " = " . $inputExp . ";";
  eval("$resExp");
  return $Result;
 }
?>
