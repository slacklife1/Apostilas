<?php

class file_utils {

  function read($file)
  {
    $fp = fopen($file, "r");
    if ($fp)
    {
      $read = fread($fp, filesize($file));
      fclose($fp);
    }
    return $read;
  }

  function chmod_read($file)
  {
    $s = sprintf("%o", (fileperms($file)) & 0777);
    return $s;
  }

  function chmod_write($file, $owner, $group, $public)
  {
    $level = "0";
    $level .= $owner;
    $level .= $group;
    $level .= $public;
    $level = octdec($level);
    chmod($file, $level);
  }

  function get($dir, $ext="")
  {
    $dd = $dir . '/';
    $d = @opendir($dd);
    while ($f = @readdir($d))
    {
      if ($ext == "")
      {
        if (($f != ".") && ($f != ".."))
        {
          $ret[] = $dir . '/' . $f;
        }
      }
      else
      {
        if (substr($f, -3, 3) == $ext)
        {
          $ret[] = $dir . '/' . $f;
        }
      }
    }
    @closedir($d);
    return $ret;
  }

  function size_i($file)
  {
    $file_size = 0;
    if(is_dir($file))
    {
      $file = $file . '/';
      $d = opendir($file);
      while ($f = readdir($d))
      {
        if (($f != ".")&&($f != ".."))
        {
          $f = $file . $f;
          $file_size = $file_size + $this->size_i($f);
        }
      }
      closedir($d);
    }
    else
    {
      $file_size = $file_size + filesize($file);
    }
    return $file_size;
  }

  function count($dir)
  {
    $files = 0;
    if(is_dir($dir))
    {
      $dir = $dir . '/';
      $d = opendir($dir);
      while ($f = readdir($d))
      {
        if (($f != ".")&&($f != ".."))
        {
          $f = $dir . $f;
          $files = $files + $this->count($f);
        }
      }
      closedir($d);
    }
    else
    {
      $files = $files + 1;
    }
    return $files;
  }

  function size($file)
  {
    $file_size = $this->size_i($file);

    if ($file_size >= 1073741824)
    {
      $file_size = round($file_size / 1073741824 * 100) / 100 . "GB";
    }
    else if ($file_size >= 1048576)
    {
      $file_size = round($file_size / 1048576 * 100) / 100 . "MB";
    }
    else if ($file_size >= 1024)
    {
      $file_size = round($file_size / 1024 * 100) / 100 . "KB";
    }
    else
    {
      $file_size = $file_size . "";
    }

    return $file_size;
  }

  function delete($file)
  {
    if(is_dir($file))
    {
      rmdir($file);
    }
    else
    {
      unlink($file);
    }
  }

  function upload($from_file, $to_file)
  {
    copy($from_file, $to_file);
  }

  function edit($file, $contents)
  {
    $fp = fopen($file, "w");
    if ($fp)
    {
      fwrite($fp, $contents);
      fclose($fp);
    }
  }

  function move($from_file, $to_file)
  {
    if(!file_exists($to_file))
    {
      rename($from_file, $to_file);
    }
  }

  function get_root()
  {
    $tmp = getenv('DOCUMENT_ROOT');
    $tmp = str_replace('\\', '/', $tmp);
    return $tmp;
  }

  function download($file, $dir, $size, $root)
  {
    $Nfile = basename($file);

    @set_time_limit(600);

    header('Content-Type: application/force-download; name="' . $Nfile . '"');
    header('Content-Transfer-Encoding: binary');
    header('Content-Length: ' . $size);
    header('Content-Disposition: attachment; filename="' . $Nfile . '"');
    header('Expires: 0');
    header('Cache-Control: no-cache, must-revalidate');
    header('Pragma: no-cache');

    readfile($root."/".$dir."/".$file);
  }
  // Same as unix grep
  // Return 1 string not array
  function grepFileFirst($file, $regex)
  {
    $hdl = fopen($file, 'r');
    if ($hdl)
    {
      while (!feof($hdl))
      {
        $line = ereg_replace("\n\$", '', (fgets($hdl, 2048)));
        if (ereg($regex,$line))
        {
          return $line;
        }
      }
      fclose($hdl);
    }
    return '';
  }

  // Same as unix tail
  // returns array of strings w/o \n
  function tail($file, $num)
  {
    global $tail_start_buf;     // Global: max string length
    global $tail_record_lenght; // Global: approximate string length
    if ($tail_start_buf == 0)
    {
      $tail_start_buf = 80;
    }
    if ($tail_record_lenght == 0)
    {
      $tail_record_lenght = 4096;
    }
    $appxlen = $tail_start_buf;// approximate string length
    $flen = filesize($file);   // file length
    $out = array();            // $out is array to return
    $fp = @fopen($file, 'r');
    if ($fp)
    {
      do
      {
        if ($num * $appxlen > $flen)
        {
          $pos = 0;
        }
        else
        {
          $pos = $flen - ($num * $appxlen);
        }
        $out = $this->_readfile($fp, $pos, $num);
        $appxlen *= 2;
      } while (count($out) != $num && $pos != 0);
      fclose($fp);
    }
    return $out;
  }

  // Internal function for tail()
  function _readfile($fp,$pos,$num)
  {
    global $tail_record_lenght;
    fseek($fp, $pos);
    $tmp = array();
    for ($i = 0; !feof($fp); $i++)
    {
      $line = chop(fgets($fp, $tail_record_lenght));
      if (!$line)
      {
        break;
      }
      $tmp[$i] = $line;
    }
    $j = count($tmp) - $num;
    if ($pos != 0 && $j == 0)
    {
      $j++;
    }
    if ($j < 0)
    {
      $j = 0;
      $xnum = $num - 1;
    }
    else
    {
      $xnum = $num;
    }
    for ($i = 0; $i < $xnum && $j < count($tmp); $i++, $j++)
    {
      $out[$i] = $tmp[$j];
    }
    return $out;
  }

}

$file_utils = new file_utils();
?>
