<?php
class Linked_List
{
  var $next = "EMPTY";
  var $caption = "EMPTY";
  
  function Linked_List($cap="EMPTY")
  {
    $this->caption = $cap;
  }
  
  function ADD($cap="EMPTY")
  {
    $t = new Linked_List($cap);
    if ($this->next != "EMPTY")
    {
      $t->next = $this->next;
    }
    $this->next = $t;
  }
  
  function IS_EMPTY()
  {
    if ($this->next == "EMPTY")
    {
      return true;
    }
    else
    {
      return false;
    }
  }

  function INSERT($caption="EMPTY", &$position)
  {
    $t = new Linked_List($caption);
    if ($positon->next != "EMPTY")
    {
      $t->next = $position->next;
    }
    $position->next = $t;
  }

  function DELETE(&$position)
  {
    if ($position->caption != "EMPTY_X")
    {
      if ($positon->next != "EMPTY")
      {
        $position = $position->next;
      }
    }
  }

  function LOCATE($caption="EMPTY_X")
  {
    $p = new Linked_List("EMPTY");
    
    $p = $this->next;
    while ($p != "EMPTY" && $p->caption != $caption)
      $p = $p->next;
    return $p;
  }

  function MAKE_EMPTY()
  {
    $this->next = "EMPTY";
    $this->caption = "EMPTY";
  }
}

$theo1 = new Linked_List("theo1");

$theo1->ADD("theo2");
$theo1->ADD("theo3");
$theo1->ADD("theo4");

// Code to add element after 'theo' - START
$b = $theo1->LOCATE("theo");
// element 'theo' doesn't exist that's why this eval/switch block is here, to
// make sure that the element is inserted(even though it is not inserted in the
// list
eval("\$t = gettype(\$$b);");
switch ( $t )
{
  case "object":
  break;
  
  default:
  $b = new Linked_List("EMPTY");
}
$theo1->INSERT("theox", $b);
// Code to add element after 'theo' - END

// Code to show all emenents for theo1 - START
$theo2 = new Linked_List("theo1");
$theo2 = $theo1->next;
while($theo2 != "EMPTY")
{
  print $theo2->caption."<br>";
  $theo2 = $theo2->next;
}
// Code to show all emenents for theo1 - END
?>
