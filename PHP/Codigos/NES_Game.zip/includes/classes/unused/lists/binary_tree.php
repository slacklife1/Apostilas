<?php

Class Binary_Tree
{
  var $left = "EMPTY";
  var $right = "EMPTY";
  var $caption = "EMPTY";
  
  function Binary_Tree($caption="EMPTY")
  {
    $this->caption = $caption;
  }
  
  function INSERT($caption="EMPTY", &$l)
  {
    if ($caption < $l)
    {
      if ($l->left != "EMPTY")
      {
        $this->INSERT($l->left);
      }
      else
      {
        $t = new Binary_Tree($caption);
        $l->left = $t;
      }
    }
    else if ($caption > $l)
    {
      if ($l->right != "EMPTY")
      {
        $this->INSERT($l->right);
      }
      else
      {
        $t = new Binary_Tree($caption);
        $l->right = $t;
      }
    }

  }

  function Binarysearch ($X="EMPTY", $t="EMPTY")
  {
    if   ($t == "EMPTY")
    {
      return "EMPTY";
    }
    else
    {
      if ($x = $t->caption)
      {
        return $t;
      }
      else
      {
        if ($X < $t->caption)
        {
          return Binarysearch ($x, $t->left);
        }
        else
        {
          return Binarysearch ($X, $t->right);
        }
      }
    }
  }

  function SMALLEST($t = "EMPTY")
  {
    if ($t == "EMPTY")
    {
      return "EMPTY";
    }
    else
    {
      if ($t->left != "EMPTY")
      {
        return SMALLEST($t->left);
      }
      else
      {
        return $t;
      }
    }
  }

  function BIGEST($t = "EMPTY")
  {
    if ($t == "EMPTY")
    {
      return "EMPTY";
    }
    else
    {
      if ($t->right != "EMPTY")
      {
        return BIGEST($t->right);
      }
      else
      {
        return $t;
      }
    }
  }

  function DELETE(&$t)
  {
    if ($t->left == "EMPTY")
    {
      $t = $t->right;
    }
    else if ($t->right == "EMPTY")
    {
      $t = $t->left;
    }
    else if ($t->left != "EMPTY" && $t->right != "EMPTY")
    {
      $t = SMALLEST($t->right);
    }
  }

}
?>
