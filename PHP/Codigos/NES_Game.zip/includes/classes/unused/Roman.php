<?php
class Numbers_Romans
{
  function toNumber($roman)
  {
    $conv = array(
      array("letter" => 'I', "number" => 1),
      array("letter" => 'V', "number" => 5),
      array("letter" => 'X', "number" => 10),
      array("letter" => 'L', "number" => 50),
      array("letter" => 'C', "number" => 100),
      array("letter" => 'D', "number" => 500),
      array("letter" => 'M', "number" => 1000),
      array("letter" => 0,   "number" => 0)
    );
    $arabic = 0;
    $state  = 0;
    $sidx   = 0;
    $len    = strlen($roman);

    while ($len >= 0)
    {
      $i = 0;
      $sidx = $len;

      while ($conv[$i]['number'] > 0)
      {
        if (strtoupper($roman[$sidx]) == $conv[$i]['letter'])
        {
          if ($state > $conv[$i]['number'])
          {
            $arabic -= $conv[$i]['number'];
          }
          else
          {
            $arabic += $conv[$i]['number'];
            $state   = $conv[$i]['number'];
          }
        }
        $i++;
      }

      $len--;
    }

    return($arabic);
  }

  function toRoman($num)
  {
    $re = "";
    while ($num >= '1000')
    {
      $num = $num - 1000;
      $re .= "M";
    }
    while ($num >= '500')
    {
      $num = $num - 500;
      $re .= "D";
    }
    while ($num >= '100')
    {
      $num = $num - 100;
      $re .= "C";
    }
    while ($num >= '50')
    {
      $num = $num - 50;
      $re .= "L";
    }
    while ($num >= '10')
    {
      $num = $num - 10;
      $re .= "X";
    }
    while ($num >= '5')
    {
      $num = $num - 5;
      $re .= "V";
    }
    while ($num >= '1')
    {
      $num = $num - 1;
      $re .= "I";
    }
    return $re;
  }
}

$n = new Numbers_Romans;
print '1981 => '.$n->toRoman('1981')."<BR>";

print 'MLMXXXI => '.$n->toNumber("MLMXXXI");
?>
