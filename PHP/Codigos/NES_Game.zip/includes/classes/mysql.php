<?php

class mysql_db
{

  var $db_connect_id;
  var $query_result='';
  var $row;
  var $free_query = TRUE;
  var $free_query_res = FALSE;
  //
  // Constructor
  //
  function mysql_db($sqlserver, $sqluser, $sqlpassword, $database, $persistency = true)
  {

    $this->persistency = $persistency;
    $this->user = $sqluser;
    $this->password = $sqlpassword;
    $this->server = $sqlserver;
    $this->dbname = $database;

    if($this->persistency)
    {
      $this->db_connect_id = @mesql_pconnect($this->server, $this->user, $this->password, $database);
    }
    else
    {
      $this->db_connect_id = @mesql_connect($this->server, $this->user, $this->password, $database);
    }
    if($this->db_connect_id)
    {
      if($database != "")
      {
        $this->dbname = $database;
        $dbselect = @mysql_select_db($this->dbname);
        if(!$dbselect)
        {
          @mysql_close($this->db_connect_id);
          $this->db_connect_id = $dbselect;
        }
      }
      return $this->db_connect_id;
    }
    else
    {
      return false;
    }
  }

  //
  // Other base methods
  //
  function close()
  {
    if($this->db_connect_id)
    {
      if($this->query_result && $this->free_query)
      {
        @mysql_free_result($this->query_result);
      }
      $result = @mysql_close($this->db_connect_id);
      return $result;
    }
    else
    {
      return false;
    }
  }

  //
  // Base query method
  //
  function query($query = "")
  {
    // Remove any pre-existing queries
    if ($this->free_query_res == TRUE)
    {
      unset($this->query_result);
    }
    if($query != "")
    {
      $this->query_result = @mysql_query($query, $this->db_connect_id);
    }
    if($this->query_result)
    {
      if ($this->free_query_res == TRUE)
      {
        if (sset($this->row[$this->query_result]))
          unset($this->row[$this->query_result]);
      }
      return $this->query_result;
    }
    else
    {
      return false;
    }
  }

  function e_query($table="", $method="", $post="", $pre="", $whe="")
  {
    $query = "{method} {pre} {table} {post} {where}";
    if ($method == "delete")
    {
      $query = ereg_replace("{method}", "DELETE FROM", $query);
      $query = ereg_replace("{table}", $table, $query);
      $query = ereg_replace("{where}", "WHERE ".$whe, $query);
      $query = ereg_replace("{pre}", "", $query);
      $query = ereg_replace("{post}", "", $query);
    }
    else if($method == "select")
    {
      $query = ereg_replace("{method}", "SELECT", $query);
      $query = ereg_replace("{table}", "FROM ".$table, $query);
      $query = ereg_replace("{where}", "WHERE ".$whe, $query);
      $query = ereg_replace("{pre}", $pre, $query);
      $query = ereg_replace("{post}", "", $query);
    }
    else if($method == "insert")
    {
      $query = ereg_replace("{method}", "INSERT INTO", $query);
      $query = ereg_replace("{table}", $table, $query);
      $query = ereg_replace("{where}", "WHERE ".$whe, $query);
      $query = ereg_replace("{pre}", "", $query);
      $query = ereg_replace("{post}", "(".$pre.") VALUES (".$post.")", $query);
    }
    else if($method == "update")
    {
      $query = ereg_replace("{method}", "UPDATE", $query);
      $query = ereg_replace("{table}", $table, $query);
      $query = ereg_replace("{where}", "WHERE ".$whe, $query);
      $query = ereg_replace("{pre}", "", $query);
      $query = ereg_replace("{post}", "SET ".$post, $query);
    }
    $t = $this->query($query);
    return $t;
  }

  function fetch_row($query_id = 0)
  {
    if(!$query_id)
    {
      $query_id = $this->query_result;
    }
    if($query_id)
    {
      $this->row[$query_id] = @mysql_fetch_array($query_id);
      return $this->row[$query_id];
    }
    else
    {
      return false;
    }
  }
  function num_rows($query_id = 0)
  {
    if(!$query_id)
    {
      $query_id = $this->query_result;
    }
    if($query_id)
    {
      $result = @mysql_num_rows($query_id);
      return $result;
    }
    else
    {
      return false;
    }
  }
  function error($query_id = 0)
  {
    $result["message"] = @mysql_error($this->db_connect_id);
    $result["code"] = @mysql_errno($this->db_connect_id);

    return $result;
  }

  function errormsg($query_id = 0)
  {
    $result = @mysql_error($this->db_connect_id);

    return $result;
  }

  function free($query_id = 0){
    if(!$query_id)
    {
      $query_id = $this->query_result;
    }
    if($query_id)
    {
      $result = @mysql_free_result($query_id);
      return $result;
    }
    else
    {
      return false;
    }
  }
}

?>
