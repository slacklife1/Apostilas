<?php

class privmsg {

  function get_count($receiver, $auth)
  {
    $receiver = $auth->username_to_userid($receiver);
    $query = $auth->datab->query("select message from nes_pm_messages where receiverid = '$receiver'");
    $result = $auth->datab->num_rows($query);
    if ($result < 1)
    {
      return FALSE;
    }
    else
    {
      return $result;
    }
  }

  function get_new_count($receiver, $auth)
  {
    $count = $this->get_count($receiver, $auth);
    $coun = $count;
    $newmsg = 0;
    while ($coun > 0)
    {
      list($text, $from, $subject, $date, $oldmsg) = $this->get_info($receiver, $coun, $auth);
      if ($oldmsg == FALSE)
      {
        $newmsg = $nesmsg + 1;
      }
      $coun = $coun - 1;
    }
    return $newmsg;
  }

  function read($receiver, $id, $auth)
  {
    $receiver = $auth->username_to_userid($receiver);
    $query = $auth->datab->query("select message,senderid,subject from nes_pm_messages where (receiverid = '$receiver' and id='$id')");
    $result = $auth->datab->num_rows($query);
    if ($result < 1)
    {
      return FALSE;
    }
    else
    {
      list($text,$from, $subject) = $auth->datab->fetch_row($query);
      $query = $auth->datab->query("update nes_pm_messages set oldmsg='1' where (receiverid = '$receiver' and id = '$id')");
      $from = $auth->userid_to_username($from);
      return array($text, $from, $subject);
    }
  }

  function get_info($receiver, $id, $auth)
  {
    $receiver = $auth->username_to_userid($receiver);
    $query = $auth->datab->query("select message,senderid,subject,date,oldmsg from nes_pm_messages where (receiverid = '$receiver' and id='$id')");
    $result = $auth->datab->num_rows($query);
    if ($result < 1)
    {
      return FALSE;
    }
    else
    {
      list($text,$from, $subject, $date, $oldmsg) = $auth->datab->fetch_row($query);
      $from = $auth->userid_to_username($from);
      return array($text, $from, $subject, $date, $oldmsg);
    }
  }

  function delete($receiver, $id, $auth)
  {
    $receiver = $auth->username_to_userid($receiver);
    $query = $auth->datab->query("delete from nes_pm_messages where receiverid='$receiver' and id='$id'");
  }

  function write($sender="", $receiver="", $message="", $subject="", $auth)
  {
    $count =  $this->get_count($receiver, $auth);
    $count = $count + 1;

    $sender = $auth->username_to_userid($sender);
    $receiver = $auth->username_to_userid($receiver);
    $queryc = $auth->datab->query("insert into nes_pm_messages (subject, receiverid, senderid, id, message, oldmsg, date) values ('$subject', '$receiver', '$sender', '$count', '$message', '0', now())");
    return $queryc;
  }
}
$privmsg = new privmsg;

?>
