<?php

class news {

  function get_count($auth)
  {
    $query = $auth->datab->query("select message from nes_news");
    $result = $auth->datab->num_rows($query);
    if ($result < 1)
    {
      return FALSE;
    }
    else
    {
      return $result;
    }
  }

  function read($id, $auth)
  {
    $query = $auth->datab->query("select message,posterid,subject,date from nes_news where id='$id'");
    $result = $auth->datab->num_rows($query);
    if ($result < 1)
    {
      return FALSE;
    }
    else
    {
      list($text,$from, $subject,$date) = $auth->datab->fetch_row($query);
      $from = $auth->userid_to_username($from);
      return array($text, $from, $subject, $date);
    }
  }

  function delete($id, $auth)
  {
    $query = $auth->datab->query("delete from nes_news where id='$id'");
  }

  function write($poster="", $message="", $subject="", $auth)
  {
    $count =  $this->get_count($auth);
    $count = $count + 1;

    $poster = $auth->username_to_userid($poster);
    $queryc = $auth->datab->query("insert into nes_news (subject, posterid, id, message, date) values ('$subject', '$poster', '$count', '$message', now())");
    return $queryc;
  }
}
$news = new news;

?>
