<?php

class forumlib {

  function get_count($auth)
  {
    $query = $auth->datab->query("select * from nes_forum");
    $result = $auth->datab->num_rows($query);
    if ($result < 1)
    {
      return FALSE;
    }
    else
    {
      return $result;
    }
  }

  function newpost($subject="", $post="", $posterid="", $parentid="", $auth)
  {
    $rootid = $this->get_count($auth);
    $rootid = $rootid + 1;
    $posterid = $auth->username_to_userid($posterid);
    $time = time();
    $result = $auth->datab->query("insert into nes_forum (rootID, parentID, subject, post, posterid, datetime) values ('$rootid', '$parentid', '$subject', '$post', '$posterid', '$time')");
    if ($result < 1)
    {
      return FALSE;
    }
    else
    {
      return $result;
    }
  }

  function get_children($id, $auth)
  {
    $result = array();
    $query = $auth->datab->query("select rootID from nes_forum where parentID='$id'");
    $res = $auth->datab->num_rows($query);
    if ($res < 1)
    {
      return FALSE;
    }
    else
    {
      while (list($rootID) = $auth->datab->fetch_row($query))
      {
        $result[] = $rootID;
      }
      return $result;
    }
  }

  function has_children($id, $auth)
  {
    $query = $auth->datab->query("select * from nes_forum where parentID='$id'");
    $result = $auth->datab->num_rows($query);
    if ($result < 1)
    {
      return FALSE;
    }
    else
    {
      return $result;
    }
  }
  
  function readpost($id, $auth)
  {
    $query = $auth->datab->query("select parentID, subject, post, posterid, datetime from nes_forum where rootID='$id'");
    $result = $auth->datab->num_rows($query);
    if ($result < 1)
    {
      return FALSE;
    }
    else
    {
      list($parentID, $subject, $post, $posterid, $date) = $auth->datab->fetch_row($query);
      return array($parentID, $subject, $post, $posterid, $date);
    }
  }

  function deletepost($id, $auth)
  {
    $f_child_a = $this->get_children($id, $auth);
    if ($this->has_children($id, $auth))
    {
      while ($each_b = each($f_child_a))
      {
        $each_a = $each_b[1];
        if (sset($res))
        {
          unset($res);
        }
        $res = $auth->datab->query("DELETE from nes_forum where rootID='$each_a'");
      }
    }
    $result = $auth->datab->query("DELETE from nes_forum where rootID='$id'");
    if ($result < 1)
    {
      return FALSE;
    }
    else
    {
      return $result;
    }
  }

}

$forumlib = new forumlib;

?>
