<?php
class Theme
{
  var $keys = array();
  var $open_tag = "{";
  var $close_tag = "}";
  var $filename = "";

  function Theme($file)
  {
    $this->filename = $file;
  }

  function Assign($key="", $text="")
  {
    if (!empty($key))
    {
      $this->keys[$key] = $text;
    }
  }
  
  function Parse()
  {
    $fp = fopen($this->filename, "r");
    if ($fp)
    {
      $text = fread($fp, filesize($this->filename));
      fclose($fp);
    }
    while (list($key, $value) = each($this->keys))
    {
      $k = $this->open_tag . $key . $this->close_tag;
      $text = ereg_replace("$k", "$value", $text);
    }
    return $text;
  }
  
}
