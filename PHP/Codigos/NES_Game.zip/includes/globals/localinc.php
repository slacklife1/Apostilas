<?php

$phphtmllib = $DOCUMENT_ROOT . "/phphtmllib";
$phphtmllib = "phphtmllib";
include_once("$phphtmllib/includes.php");

?>
