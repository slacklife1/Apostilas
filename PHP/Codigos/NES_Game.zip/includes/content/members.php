<?php

  function print_title()
  {
    return "NES - Members List";
  }

  function print_small_title()
  {
    return "Members List";
  }

  function add_content()
  {
    global $login_check, $authlib, $privmsg, $news, $gamelib;

    $t_p = new PTag();
    $table = new TABLETag();

    $tcount = $gamelib->get_team_count($authlib);
    $tcoun = $tcount;
    $tr = new TRTag();
    $tr->push(html_td(html_b("Team")));
    $tr->push(html_td(html_b("Posts")));
    $tr->push(html_td(html_b("Chars")));
    $table->push($tr);
    while($tcoun > 0)
    {
      list ($p, $p, $p, $p, $p, $p, $priority, $story, $mcount, $posts) = $gamelib->team_retrieve($tcoun, $authlib);
      $tr = new TRTag();
      $tr->push(html_td($tcoun));
      $tr->push(html_td($posts));
      $tr->push(html_td(strlen($story)));
      $table->push($tr);
      $mcoun = $mcount;
      $tr = new TRTag();
      $tr->push(html_td(html_b("Username")));
      $tr->push(html_td(html_b("Priority")));
      $tr->push(html_td(html_b("Posts")));
      $tr->push(html_td(html_b("Chars")));
      $table->push($tr);
      while($mcoun > 0)
      {
        list($userid,$posts,$chars) = $gamelib->get_team_member($tcoun, $priority, $authlib);
        $user = $authlib->userid_to_username($userid);
        $tr = new TRTag();
        $tr->push(html_td(html_a("viewprofile.php?username=".$user,$user)));
        $tr->push(html_td($priority));
        $tr->push(html_td($posts));
        $tr->push(html_td($chars));
        $table->push($tr);
        $mcoun = $mcoun - 1;
      }
      $tr = new TRTag();
      $tr->push(html_br());
      $table->push($tr);
      $tcoun = $tcoun - 1;
    }
    $t_p->push($table);
    return $t_p->render();
  }
?>
