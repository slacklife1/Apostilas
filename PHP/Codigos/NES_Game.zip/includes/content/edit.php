<?php

  function print_title()
  {
    return "NES - Admin : Edit";
  }

  function print_small_title()
  {
    return "Edit Profile";
  }

  function add_content()
  {
    $t_p = new PTag();

    global $name,$st, $age, $school, $login_check, $email, $authlib, $ppriority,$pposts,$pchars,$teamnum,$story, $icq, $aim, $msn, $yahoo, $yabber;
    $form = new FORMTag(array("action"=>"edit.php","method"=>"POST"));
    $table = new TABLETag(array("border"=>"0","cellspacing"=>"0","cellpadding"=>"0"));

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("<B>Name</B> :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("name", $name));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Age :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("age",$age));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("<B>Sex</B> :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push('<select name="sex">',$st);
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("School :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("school", $school));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("<B>Theme</B> :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(template_select($authlib->get_template($login_check[0]), "themes"));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("ICQ :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("icq", $icq));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("AIM :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("aim", $aim));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("MSN :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("msn", $msn));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Yahoo :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("yahoo", $yahoo));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Yabber :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("yabber", $yabber));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Username :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push($login_check[0]);
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Team Number :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push($teamnum);
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Priority :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push($ppriority);
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Total Posts :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push($pposts);
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag(array("nowrap"=>"nowrap"));
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Total Characters :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push($pchars);
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Story :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push($story);
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Email :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push($email);
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $td = new TDTag();
    $td->push("&nbsp;");
    $table->push($td);
    $td = new TDTag();
    $td->push(form_submit("submit","Edit"));
    $table->push($td);
    $form->push($table);
    $t_p->push($form);

    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(html_a("chemail.php","Change Email"));
    $t_p->push($font, html_br());
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(html_a("chpass.php","Change Password"));
    $t_p->push($font, html_br());
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(html_a("delete.php","Delete Account"));
    $t_p->push($font);
    return $t_p->render();

  }
?>
