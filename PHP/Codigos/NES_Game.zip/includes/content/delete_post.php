<?php

  function print_title()
  {
    return "NES - Admin - Forum";
  }

  function print_small_title()
  {
    return "Admin - Forum";
  }

  function add_content()
  {
    global $login_check, $authlib, $forumlib;

    $t_p = new PTag();
    $t_p->push(html_br());

    $fcount = $forumlib->get_count($authlib);
    $fcoun = $fcount;
    while($fcoun > 0)
    {
      list($parentID, $subject, $post, $posterid, $date) = $forumlib->readpost($fcoun, $authlib);
      $a = " - " . $authlib->userid_to_username($posterid) . ", <small>" . date("H:i:s d-m-y", $date) . "</small>";
      $t_p->push(html_a("delete_post.php?id=".$fcoun, $subject), $a, html_br());
      $fcoun = $fcoun - 1;
    }
    return $t_p->render();
  }
?>
