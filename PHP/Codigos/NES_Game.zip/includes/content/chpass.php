<?php

  function print_title()
  {
    return "NES - Admin : Change Password";
  }

  function print_small_title()
  {
    return "Change Password";
  }

  function add_content()
  {
    $t_p = new PTag();
    $form = new FORMTag(array("action"=>"chemail.php","method"=>"POST"));
    $table = new TABLETag(array("width"=>"100%","border"=>"0","cellspacing"=>"0","cellpadding"=>"0"));
    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("New Password :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_password("password"));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);
    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Confirm New Password :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_password("password2"));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);
    $td = new TDTag();
    $td->push("&nbsp;");
    $table->push($td);
    $td = new TDTag();
    $td->push(form_submit("submit","Edit"));
    $table->push($td);
    $form->push($table);
    $t_p->push($form);
    $t_p->push("Note: After changing your password you will be logged out automatically and your new password will apply");
    return $t_p->render();

  }
?>
