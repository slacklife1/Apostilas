<?php

  function print_title()
  {
    return "NES - Forum";
  }

  function print_small_title()
  {
    return "Forum";
  }

  function add_content()
  {
    global $login_check, $authlib, $forumlib, $parentid, $topicid, $rootid;

    $t_p = new PTag();
    $t_p->push(html_br());

    list($parentID, $subject, $post, $posterid, $date) = $forumlib->readpost($rootid, $authlib);
//    $t_p->push(forum_item(date("H:i:s d-m-y", $date), $subject, $post, $authlib->userid_to_username($posterid)));
//    $t_p->push(print_children_tree($topicid, "", $rootid));
    $t_p->push(forum_top("Poster", "Message"));
    $t_p->push(print_children_flat($topicid, "", $rootid));
    $t_p->push("</table>");
    $form = new FORMTag(array("action"=>"post.php","method"=>"POST"));
    $table = new TABLETag(array("border"=>"0","cellspacing"=>"0","cellpadding"=>"0"));

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Subject :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("subject", "RE: ".$subject));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Message :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_textarea("post",array("ROWS"=>"3", "COLS"=>"40")));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $td = new TDTag();
    $td->push("&nbsp;");
    $table->push($td);
    $td = new TDTag();
    $td->push(form_submit("submit","Reply"));
    $table->push($td);
    $form->push($table);
//    $form->push(form_hidden("parentid",$rootid));
    $form->push(form_hidden("parentid",$topicid));
    $form->push(form_hidden("page","reply"));
    $t_p->push($form);

    return $t_p->render();
  }

  $topic;
  function print_children_tree($root, $parent, $initial)
  {
    global $login_check, $authlib, $forumlib, $topic;

    $t_p = new DIVTag();

    $f_child_a = $forumlib->get_children($root, $authlib);

    $t_p->push("<ul>");
    if($parent == "")
    {
      $each_a = $root;
      list($parentID, $subject, $post, $posterid, $date) = $forumlib->readpost($each_a, $authlib);
      $t_p->push("<li>");
      $a = " - " . $authlib->userid_to_username($posterid) . ", <small>" . date("H:i:s d-m-y", $date) . "</small>";
      if ($each_a == $initial)
      {
        $t_p->push(html_b($subject), $a);
      }
      else
      {
        $t_p->push(html_a("reply.php?parent=".$parentID."&id=".$each_a."&topic=".$topic, $subject), $a);
      }
      $t_p->push("</li>");
      $t_p->push("<ul>");
    }
    if ($f_child_a != FALSE)
    {
      while ($each_b = each($f_child_a))
      {
        $each_a = $each_b[1];
        list($parentID, $subject, $post, $posterid, $date) = $forumlib->readpost($each_a, $authlib);
        $t_p->push("<li>");
        $a = " - " . $authlib->userid_to_username($posterid) . ", <small>" . date("H:i:s d-m-y", $date) . "</small>";
        if ($each_a == $initial)
        {
          $t_p->push(html_b($subject), $a);
        }
        else
        {
          $t_p->push(html_a("reply.php?parent=".$parentID."&id=".$each_a."&topic=".$topic, $subject), $a);
        }
        $time = time();
        if( $time < $date + 60 * 60)
          $t_p->push('<img align=absmiddle height=12 width=23 border=0 src="images/new.gif">');

        $t_p->push("</li>");
        $t_p->push(print_children_tree($each_a, $parentID, $initial));
      }
      $t_p->push("</ul>");
    }
    if ($parent == "")
      $t_p->push("</ul>");
    return $t_p->render();
  }

  function print_children_flat($root, $parent, $initial)
  {
    global $login_check, $authlib, $forumlib, $topic;

    $t_p = new DIVTag();

    $f_child_a = $forumlib->get_children($root, $authlib);

    if($parent == "")
    {
      $each_a = $root;
      list($parentID, $subject, $post, $posterid, $date) = $forumlib->readpost($each_a, $authlib);
      $t_p->push(forum_child(date("H:i:s", $date)."<BR>".date("d-m-y", $date), $subject, $post, $authlib->userid_to_username($posterid)));
    }
    if ($f_child_a != FALSE)
    {
      while ($each_b = each($f_child_a))
      {
        $each_a = $each_b[1];
        list($parentID, $subject, $post, $posterid, $date) = $forumlib->readpost($each_a, $authlib);
        $t_p->push(forum_child(date("H:i:s", $date)."<BR>".date("d-m-y", $date), $subject, $post, $authlib->userid_to_username($posterid)));
        $t_p->push(print_children_flat($each_a, $parentID, $initial));
      }
    }
    return $t_p->render();
  }
?>
