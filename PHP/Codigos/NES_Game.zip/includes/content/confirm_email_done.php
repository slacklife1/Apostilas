<?php
  $no_menu = "yes";

  function print_title()
  {
    return "NES - Admin : Edit: Confirm Email";
  }

  function print_small_title()
  {
    return "Confirm Email";
  }

  function add_content()
  {
    global $email;
    $t_p = new PTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"4","color"=>"#999933"));
    $font->push("Your registartion has been confirmed.");
    $t_p->push($font);
    $t_p->push(html_br());
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("All the details have been sent again to your email which is ", $email, ".");
    $t_p->push($font);
    $t_p->push(html_br());
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(html_a("login.php", "Login"));
    $t_p->push($font);
    return $t_p->render();

  }
?>
