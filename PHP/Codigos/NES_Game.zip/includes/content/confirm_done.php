<?php

  $no_menu = "yes";
  function print_title()
  {
    return "NES - Register : Confirm";
  }

  function print_small_title()
  {
    return "Registration Confirm";
  }

  function add_content()
  {
    global $username, $is_success;
    $t_p = new PTag();

    $table = new TABLETag;
    $tr = new TRTag;
    if ($is_success[new_team])
    {
      $tr->push(html_td("Create New Team:"), html_td(show_true($is_success[team_create], "Ok", "Error")));
      $table->push($tr);
      $tr = new TRTag;
    }

    $tr->push(html_td("Update Game:"), html_td(show_true($is_success[game_update], "Ok", "Error")));
    $table->push($tr);
    $tr = new TRTag;
    $tr->push(html_td("Update Team:"), html_td(show_true($is_success[team_update], "Ok", "Error")));
    $table->push($tr);
    $tr = new TRTag;
    $tr->push(html_td("Create Login:"), html_td(show_true($is_success[first], "Ok", "Error")));
    $table->push($tr);
    $tr = new TRTag;
    $tr->push(html_td("Create Profile:"), html_td(show_true($is_success[second], "Ok", "Error")));
    $table->push($tr);
    $tr = new TRTag;
    $tr->push(html_td("Create Game Player:"), html_td(show_true($is_success[player_create], "Ok", "Error")));
    $table->push($tr);
    $tr = new TRTag;
    $tr->push(html_td("Erase Confirmation:"), html_td(show_true($is_success[third], "Ok", "Error")));
    $table->push($tr);

    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"4","color"=>"#999933"));
    $font->push("Your registartion has been confirmed.");
    $t_p->push($font);
    $t_p->push(html_br());
    $t_p->push($table);
    $t_p->push(html_br());
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("All the details have been sent again to your email, your username is", $username, ".");
    $t_p->push($font);
    $t_p->push(html_br());
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(html_a("login.php", "Login"));
    $t_p->push($font);
    return $t_p->render();

  }
?>
