<?php

  header("Location: forum.php");
  exit;

?>
