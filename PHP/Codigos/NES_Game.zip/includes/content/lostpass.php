<?php
  $no_menu = "yes";

  function print_title()
  {
    return "NES - Lost Password";
  }

  function print_small_title()
  {
    return "Lost Password";
  }

  function add_content()
  {
    $t_p = new PTag();

    $form = new FORMTag(array("action"=>"lostpass2.php","method"=>"POST"));
    $table = new TABLETag(array("width"=>"100%","border"=>"0","cellspacing"=>"0","cellpadding"=>"0"));
    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Email :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("email"));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);
    $td = new TDTag();
    $td->push("&nbsp;");
    $table->push($td);
    $td = new TDTag();
    $td->push(form_submit("submit","Find Password"));
    $table->push($td);
    $form->push($table);
    $t_p->push($form);
    return $t_p->render();

  }
?>
