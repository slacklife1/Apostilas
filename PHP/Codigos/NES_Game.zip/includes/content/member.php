<?php

  function print_title()
  {
    return "NES - Members Page";
  }

  function print_small_title()
  {
    return "Members Page";
  }

  function add_content()
  {
    global $login_check, $authlib, $privmsg, $news, $gamelib;

    $count = $privmsg->get_new_count($login_check[0], $authlib);
    $news_count = $news->get_count($authlib);

    $t_p = new PTag();
    $t_p->push("Welcome ",$login_check[0],", you have ", html_a("messages.php", $count), " new message(s)", html_br());
    $t_p->push(html_br());

    $ncoun = $news_count;

//    $top = '<table border="1"><tr><td><table border="0"><tr><td><strong>Date</strong></td><td><em><strong>';
//    $middle = '</strong></em></td></tr><tr><td><strong>Subject</strong></td><td><em><strong>';
//    $middlebottom='</strong></em></td></tr></table></td></tr><tr><td>';
//    $bottom = '</td></tr></table>';

    while($ncoun > 0 && ncount < 6)
    {
      list($message,$from,$subject,$date) = $news->read($ncoun,$authlib);
      $t_p->push(news_item($date, $subject, $message, $from), html_br());
//      $t_p->push($top,$date,$middle,$subject,$middlebottom,$message,$bottom);
      $ncount = $ncount + 1;
      $ncoun = $ncoun - 1;
    }

    return $t_p->render();

  }
?>
