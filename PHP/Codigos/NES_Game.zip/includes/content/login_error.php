<?php
  $no_menu = "yes";

  function print_title()
  {
    return "NES - Login";
  }

  function print_small_title()
  {
    return "Login";
  }

  function add_content()
  {
    $t_p = new PTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"4","color"=>"#999933"));
    $font->push("Error: Incorrect Login");
    $t_p->push($font);
    return $t_p->render();
  }
?>

