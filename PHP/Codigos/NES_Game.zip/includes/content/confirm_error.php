<?php
  $no_menu = "yes";

  function print_title()
  {
    return "NES - Register : Confirm";
  }

  function print_small_title()
  {
    return "Registration Confirm";
  }

  function add_content()
  {
    global $confirm, $is_success;
    $t_p = new PTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"4","color"=>"#999933"));
    $font->push("Error: ",$confirm);
    $t_p->push($font);

    $table = new TABLETag;
    $tr = new TRTag;
    if ($is_success[new_team])
    {
      $tr->push(html_td("Create New Team:"), html_td(show_true($is_success[team_create], "Ok", "Error")));
      $table->push($tr);
      $tr = new TRTag;
    }

    $tr->push(html_td("Update Game:"), html_td(show_true($is_success[game_update], "Ok", "Error")));
    $table->push($tr);
    $tr = new TRTag;
    $tr->push(html_td("Update Team:"), html_td(show_true($is_success[team_update], "Ok", "Error")));
    $table->push($tr);
    $tr = new TRTag;
    $tr->push(html_td("Create Login:"), html_td(show_true($is_success[first], "Ok", "Error")));
    $table->push($tr);
    $tr = new TRTag;
    $tr->push(html_td("Create Profile:"), html_td(show_true($is_success[second], "Ok", "Error")));
    $table->push($tr);
    $tr = new TRTag;
    $tr->push(html_td("Create Game Player:"), html_td(show_true($is_success[player_create], "Ok", "Error")));
    $table->push($tr);
    $tr = new TRTag;
    $tr->push(html_td("Erase Confirmation:"), html_td(show_true($is_success[third], "Ok", "Error")));
    $table->push($tr);

    $t_p->push($table);
    return $t_p->render();

  }
?>
