<?php

  header("Location: member.php");
  exit;

?>
