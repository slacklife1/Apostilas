<?php

  setcookie("nes");
  header("Location: login.php");
  exit;

?>
