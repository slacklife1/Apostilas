<?php
  $no_menu = "yes";

  function print_title()
  {
    return "NES - Admin : Delete";
  }

  function print_small_title()
  {
    return "Registration Delete";
  }

  function add_content()
  {
    $t_p = new PTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"4","color"=>"#999933"));
    $font->push("Your registration has been removed from the system.");
    $t_p->push($font);
    $t_p->push(html_br());
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("All the details have been lost and your username is now in public domain.");
    $t_p->push($font);
    $t_p->push(html_br());
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(html_a("login.php", "Login"));
    $t_p->push($font);
    return $t_p->render();

  }
?>
