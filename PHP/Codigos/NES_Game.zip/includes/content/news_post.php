<?php

  function print_title()
  {
    return "NES - Post News";
  }

  function print_small_title()
  {
    return "Post News";
  }

  function add_content()
  {
    global $login_check, $id, $authlib, $news;

    $t_p = new PTag();
    $count = $news->get_count($authlib);

    $coun = $count;
    while ($coun > 0)
    {
      list($pm_message, $pm_from, $pm_about, $pm_date) = $news->read($coun, $authlib);
      $t_p->push("Delete:", html_a('news_post.php?mode=delete&id='.$coun, $pm_about), " ", $pm_date);
      $t_p->push(html_br());
      $coun = $coun - 1;
    }

    $form = new FORMTag(array("action"=>"news_post.php","method"=>"POST"));
    $table = new TABLETag(array("border"=>"0","cellspacing"=>"0","cellpadding"=>"0"));

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Subject :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("subject", ""));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Message :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_textarea("message",array("ROWS"=>"3", "COLS"=>"40")));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $td = new TDTag();
    $td->push("&nbsp;");
    $table->push($td);
    $td = new TDTag();
    $td->push(form_submit("submit","Submit"));
    $table->push($td);
    $form->push($table);
    $t_p->push($form);

    return $t_p->render();

  }
?>
