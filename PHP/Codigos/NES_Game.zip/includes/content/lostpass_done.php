<?php
  $no_menu = "yes";

  function print_title()
  {
    return "NES - Lost Password";
  }

  function print_small_title()
  {
    return "Lost Password";
  }

  function add_content()
  {
    $t_p = new PTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"4","color"=>"#999933"));
    $font->push("The necessary information namely your username and password have been sent to your email, so please check your email and login.");
    $t_p->push($font);
    return $t_p->render();

  }
?>

