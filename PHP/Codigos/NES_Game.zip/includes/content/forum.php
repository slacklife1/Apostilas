<?php

  function print_title()
  {
    return "NES - Forum";
  }

  function print_small_title()
  {
    return "Forum";
  }

  function add_content()
  {
    global $login_check, $authlib, $forumlib;

    $t_p = new PTag();
    $t_p->push(html_br());

//    $t_p->push(print_threads_tree("0", ""));
    $t_p->push(forum_top("Subject", "Poster", "Replies"));
    $t_p->push(print_threads_flat("0", ""));
    $t_p->push("</table>");
    $form = new FORMTag(array("action"=>"post.php","method"=>"POST"));
    $table = new TABLETag(array("border"=>"0","cellspacing"=>"0","cellpadding"=>"0"));

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Subject :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("subject", ""));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Message :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_textarea("post",array("ROWS"=>"3", "COLS"=>"40")));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $td = new TDTag();
    $td->push("&nbsp;");
    $table->push($td);
    $td = new TDTag();
    $td->push(form_submit("submit","New Thread"));
    $table->push($td);
    $form->push($table);
    $form->push(form_hidden("parentid","0"));
    $form->push(form_hidden("page","forum"));
    $t_p->push($form);

    return $t_p->render();
  }

  $topic;
  function print_threads_tree($root, $parent)
  {
    global $login_check, $authlib, $forumlib,$topic;

    $t_p = new DIVTag();

    $f_child_a = $forumlib->get_children($root, $authlib);

    if ($f_child_a != FALSE)
    {
      $t_p->push("<ul>");
      while ($each_b = each($f_child_a))
      {
        $each_a = $each_b[1];
        if ($parent == "")
          $topic = $each_a;
        list($parentID, $subject, $post, $posterid, $date) = $forumlib->readpost($each_a, $authlib);
        $t_p->push("<li>");
        $a = " - " . $authlib->userid_to_username($posterid) . ", <small>" . date("H:i:s d-m-y", $date) . "</small>";
        $t_p->push(html_a("reply.php?parent=".$parentID."&id=".$each_a."&topic=".$topic, $subject), $a);
        $time = time();
        if( $time < $date + 60 * 60)
          $t_p->push('<img align=absmiddle height=12 width=23 border=0 src="images/new.gif">');
        $t_p->push("</li>");
        $t_p->push(print_threads_tree($each_a, $parentID));
      }
      $t_p->push("</ul>");
    }
    return $t_p->render();
  }

  function print_threads_flat($root, $parent)
  {
    global $login_check, $authlib, $forumlib,$topic;

    $t_p = new DIVTag();

    $f_child_a = $forumlib->get_children($root, $authlib);

    if ($f_child_a != FALSE)
    {
      while ($each_b = each($f_child_a))
      {
        $each_a = $each_b[1];
        if ($parent == "")
          $topic = $each_a;
        list($parentID, $subject, $post, $posterid, $date) = $forumlib->readpost($each_a, $authlib);
        $a = '<a href="reply.php?parent='.$parentID.'&id='.$each_a.'&topic='.$topic.'">'.$subject.'</a';
        $t_p->push(forum_thread($a, $authlib->userid_to_username($posterid), $each_a));
      }
    }
    return $t_p->render();
  }
?>
