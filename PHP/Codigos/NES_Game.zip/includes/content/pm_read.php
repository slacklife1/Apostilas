<?php

  function print_title()
  {
    return "NES - Private Messages - Read";
  }

  function print_small_title()
  {
    return "Read Message";
  }

  function add_content()
  {
    global $login_check, $id, $authlib, $privmsg;

    list($p, $p, $p, $pm_date, $p) = $privmsg->get_info($login_check[0], $id, $authlib);
    list($pm_message, $pm_from, $pm_about) = $privmsg->read($login_check[0], $id, $authlib);

    $t_p = new PTag();
    $t_p->push(privmsg_item($pm_date, $pm_about, $pm_message, $pm_from));

//    $t_p->push(html_b("Subject: ", $pm_about, html_br()));
//    $t_p->push(html_b("From: ", $pm_from, html_br()));
//    $t_p->push(html_i($pm_message));
    $t_p->push(html_br());
    $t_p->push(html_a('messages.php?mode=delete&id='.$id, "Delete"));
    return $t_p->render();

  }
?>
