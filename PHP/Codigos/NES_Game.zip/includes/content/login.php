<?php
  $no_menu = "yes";

  function print_title()
  {
    return "NES - Login";
  }

  function print_small_title()
  {
    return "Login";
  }

  function add_content()
  {
    $t_p = new PTag();

    $form = new FORMTag(array("action"=>"login2.php","method"=>"POST"));
    $table = new TABLETag(array("width"=>"100%","border"=>"0","cellspacing"=>"0","cellpadding"=>"0"));

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Username :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("username"));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Password :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_password("password"));
    $td->push($font);
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"1"));
    $font->push(html_a("lostpass.php","Lost Password"));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $td = new TDTag();
    $td->push("&nbsp;");
    $table->push($td);
    $td = new TDTag();
    $td->push(form_submit("submit","Login"));
    $table->push($td);
    $form->push($table);
    $t_p->push($form);
    return $t_p->render();

  }
?>
