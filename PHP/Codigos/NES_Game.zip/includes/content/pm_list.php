<?php

  function print_title()
  {
    return "NES - Private Messages - Read";
  }

  function print_small_title()
  {
    return "Read Message";
  }

  function add_content()
  {
    global $login_check, $id, $authlib, $privmsg;

    $t_p = new PTag();
    $count = $privmsg->get_count($login_check[0], $authlib);
    $select = new SELECTTag(array("name"=>"receiver"));
    $mcount = $authlib->get_member_count();
    $mcoun = $mcount;
    while($mcoun > 0)
    {
      list($user,$userid) = $authlib->get_member($mcoun);
      $op = new OPTIONTag(array("value"=>$user));
      $op->push($user);
      $select->push($op);
      $mcoun = $mcoun - 1;
    }
    $coun = $count;
    while ($coun > 0)
    {
      list($pm_message, $pm_from, $pm_about, $pm_date, $pm_read) = $privmsg->get_info($login_check[0], $coun, $authlib);
      if ($pm_read == TRUE)
      {
        $d = "";
      }
      if ($pm_read == FALSE)
      {
        $d = '<IMG SRC="images/new.gif">';
      }
      $t_p->push($d, html_a('messages.php?mode=read&id='.$coun, $pm_about), " ", $pm_date);
      $t_p->push(html_br());
      $coun = $coun - 1;
    }

    $form = new FORMTag(array("action"=>"messages.php","method"=>"POST"));
    $table = new TABLETag(array("border"=>"0","cellspacing"=>"0","cellpadding"=>"0"));

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("To :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
//    $font->push(form_text("receiver", ""));
    $font->push($select);
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Subject :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("subject", ""));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Message :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_textarea("message",array("ROWS"=>"3", "COLS"=>"40")));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $td = new TDTag();
    $td->push("&nbsp;");
    $table->push($td);
    $td = new TDTag();
    $td->push(form_submit("submit","Send"));
    $table->push($td);
    $form->push($table);
    $t_p->push($form);

    return $t_p->render();

  }
?>
