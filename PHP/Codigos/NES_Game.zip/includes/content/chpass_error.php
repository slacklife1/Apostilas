<?php

  function print_title()
  {
    return "NES - Admin : Change Password";
  }

  function print_small_title()
  {
    return "Change Password";
  }

  function add_content()
  {
    global $chpass;
    $t_p = new PTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"4","color"=>"#999933"));
    $font->push("Error: ",$chpass);
    $t_p->push($font);
    return $t_p->render();

  }
?>

