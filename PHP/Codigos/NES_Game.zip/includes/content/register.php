<?php
  $no_menu = "yes";

  function print_title()
  {
    return "NES - Register";
  }

  function print_small_title()
  {
    return "Register";
  }

  function add_content()
  {
    global $authlib, $login_check;
    $t_p = new PTag();

    $form = new FORMTag(array("action"=>"register2.php","method"=>"POST"));
    $table = new TABLETag(array("width"=>"100%","border"=>"0","cellspacing"=>"0","cellpadding"=>"0"));
    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("<B>Name</B> :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("name"));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("<B>Email</B> :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("email"));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Age :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("age"));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Sex :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_select("sex",array("Male"=>"Male","Female"=>"Female")));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("School :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("school"));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("<B>Theme</B> :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(template_select($authlib->get_template($login_check[0]), "themes"));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("ICQ :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("icq", $icq));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("AIM :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("aim", $aim));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("MSN :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("msn", $msn));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Yahoo :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("yahoo", $yahoo));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("Yabber :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("yabber", $yabber));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("<B>Username</B> :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_text("username"));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("<B>Password</B> :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_password("password"));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $tr = new TRTag();
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push("<B>Confirm Password</B> :");
    $td->push($font);
    $tr->push($td);
    $td = new TDTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
    $font->push(form_password("password2"));
    $td->push($font);
    $tr->push($td);
    $table->push($tr);

    $td = new TDTag();
    $td->push("&nbsp;");
    $table->push($td);
    $td = new TDTag();
    $td->push(form_submit("submit","Register"));
    $table->push($td);
    $form->push($table);
    $t_p->push($form);
    return $t_p->render();

  }
?>
