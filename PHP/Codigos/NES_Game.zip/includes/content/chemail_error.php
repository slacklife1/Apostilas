<?php

  function print_title()
  {
    return "NES - Admin : Change Email";
  }

  function print_small_title()
  {
    return "Change Email";
  }

  function add_content()
  {
    global $chemail;
    $t_p = new PTag();
    $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"4","color"=>"#999933"));
    $font->push("Error: ",$chemail);
    $t_p->push($font);
    return $t_p->render();

  }
?>
