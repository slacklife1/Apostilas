<?php
  $no_menu = "yes";

  function print_title()
  {
    return "NES - Main";
  }

  function print_small_title()
  {
    return "Main Index";
  }

  function add_content()
  {
    $t_p = new PTag();
    $t_p->push("Choose an option from the menu to be automatically transported there");
    $t_p->push(html_br());
    return $t_p->render();

  }
?>
