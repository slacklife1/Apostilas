<?php

header("Location: /");
exit;

?>