<?php

  function print_title()
  {
    return "NES - Admin : Game";
  }

  function print_small_title()
  {
    return "Game Controls";
  }

  function add_content()
  {
    $t_p = new PTag();

    global $last_post5, $last_post4, $last_post3, $last_post2, $last_post1, $login_check, $priority, $ppriority;

    $t_p->push(html_b("Last Five Posts:"),html_br());
    $t_p->push(html_p($last_post5));
    $t_p->push(html_p(html_b($last_post4)));
    $t_p->push(html_p($last_post3));
    $t_p->push(html_p(html_b($last_post2)));
    $t_p->push(html_p(html_i($last_post1)));

    if ($priority == $ppriority)
    {
      $form = new FORMTag(array("action"=>"story.php","method"=>"POST"));
      $table = new TABLETag(array("border"=>"0","cellspacing"=>"0","cellpadding"=>"0"));

      $tr = new TRTag();
      $td = new TDTag();
      $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
      $font->push("Enter Text :");
      $td->push($font);
      $tr->push($td);
      $td = new TDTag();
      $font = new FONTTag(array("face"=>"Arial, Helvetica, sans-serif","size"=>"2"));
      $font->push(form_textarea("story_continue",array("ROWS"=>"3", "COLS"=>"40")));
      $td->push($font);
      $tr->push($td);
      $table->push($tr);

      $td = new TDTag();
      $td->push("&nbsp;");
      $table->push($td);
      $td = new TDTag();
      $td->push(form_submit("submit","Post"));
      $table->push($td);
      $form->push($table);
      $t_p->push($form);

    }
    else
    {
      $t_p->push(html_br(),"Not your turn yet, please wait");
    }

    return $t_p->render();

  }
?>
