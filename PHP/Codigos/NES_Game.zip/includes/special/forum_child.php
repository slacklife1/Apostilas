<tr class="{color}">
  <td valign="top">
    <table border="0">
      <tr>
        <td valign="top" nowrap="nowrap">{from}<BR></td>
      </tr>
      <tr>
        <td valign="top" nowrap="nowrap">{date}</td>
      </tr>
    </table>
  </td>
  <td width="100%" valign="top">
    <table border="0">
      <tr>
        <td valign="top"><B>{subject}</B></td>
      </tr>
      <tr>
        <td valign="top">{message}</td>
      </tr>
    </table>
  </td>
</tr>
