<tr>
  <td class="forum_thread_bg1" width="100%">{subject}</td>
  <td class="forum_thread_bg2">&nbsp;{from}&nbsp;</td>
  <td class="forum_thread_bg1">&nbsp;{children}&nbsp;</td>
</tr>

