function AddButton(caption, linkto, brek, typa, param_a, param_b, param_c)
{
  if (brek == 1)
  {
    document.write('<table><tr>');
  }
  if ((brek == 2) || (brek == 1) || (brek == 3))
  {
    document.write('<td>');
  }

  if (typa == 1)
  {
    document.write('<table class="toolbar" border="0" width="'+param_b+'" background="'+param_a+'" cellspacing="0" cellpadding="8">');
    document.write('<tr class="toolbar">');
    document.write('<td class="toolbar"><p class="toolbar" align="left"><img src="images/clear.gif" width="4" height="'+param_c+'"');
    document.write('align="left"><a class="toolbar" href="'+linkto+'" ONMOUSEOVER="window.status='+"''"+';return true;" ONMOUSEOUT="window.status='+"''"+';return true;">'+caption+'</a></td>');
    document.write('</tr>');
    document.write('</table>');
  }
  else if (typa == 2)
  {
    document.write('<table><td>'+param_a+'<a href="'+linkto+'">'+caption+'</a>'+param_b+'</td></table>');
  }
  else if (typa == 3)
  {
    document.write('<table><td><OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"');
    document.write(' codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0"');
    document.write('WIDTH=104 HEIGHT=22>');
    document.write('<PARAM NAME=movie VALUE="flash/'+param_a+'.swf?tarframe=_self&exbackground='+param_b+'&makenavfield0='+caption+'&makenavurl0='+linkto+'">');
    document.write('<PARAM NAME=loop VALUE=false>');
    document.write('<PARAM NAME=menu VALUE=false>');
    document.write('<PARAM NAME=quality VALUE=high>');
    document.write('<PARAM NAME=scale VALUE=noborder>');
    document.write('<PARAM NAME=salign VALUE=LT>');
    document.write('<PARAM NAME=wmode VALUE=transparent>');
    document.write('<PARAM NAME=bgcolor VALUE='+param_c+'>');
    document.write('<EMBED src="flash/'+param_a+'.swf?tarframe=_self&exbackground='+param_b+'&makenavfield0='+caption+'&makenavurl0='+linkto+'" loop=false menu=false quality=high scale=noborder salign=LT wmode=transparent bgcolor='+param_c+'  WIDTH=104 HEIGHT=22 TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"></EMBED>');
    document.write('</OBJECT></td></table>');
  }
  else if (typa == 4)
  {
    document.write('<table><td><a href="'+linkto+'"><img src="'+param_a+'" alt="'+caption+'" border="0"></a></td></table');
  }

  if ((brek == 1) || (brek == 2) || (brek == 3))
  {
    document.write('</td>');
  }
  if (brek == 3)
  {
    document.write('</tr></table>');
  }
  if (brek==4)
  {
    document.write('<br>');
  }
}
