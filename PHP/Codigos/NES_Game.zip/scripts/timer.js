var tempdh ="";
var tempuh ="";
var tempdm ="";
var tempum ="";
var tempds ="";
var tempus ="";

newimage0 = new Image();
newimage0.src = "images/timer/0.gif";
newimage1 = new Image();
newimage1.src = "images/timer/1.gif";
newimage2 = new Image();
newimage2.src = "images/timer/2.gif";
newimage3 = new Image();
newimage3.src = "images/timer/3.gif";
newimage4 = new Image();
newimage4.src = "images/timer/4.gif";
newimage5 = new Image();
newimage5.src = "images/timer/5.gif";
newimage6 = new Image();
newimage6.src = "images/timer/6.gif";
newimage7 = new Image();
newimage7.src = "images/timer/7.gif";
newimage8 = new Image();
newimage8.src = "images/timer/8.gif";
newimage9 = new Image();
newimage9.src = "images/timer/9.gif";

function GetTimer()
{
  H = new Date();
  hour   = H.getHours();
  minute  = H.getMinutes();
  second = H.getSeconds();

  if(eval(hour) < 10)
  {
    dh = "0";
    uh = hour;
  }
  else
  {
    hour += " ";
    dh = hour.charAt(0);
    uh = hour.charAt(1);
  }

  if(eval(minute) < 10)
  {
    dm = "0";
    um = minute;
  }
  else
  {
    minute += " ";
    dm = minute.charAt(0);
    um = minute.charAt(1);
  }

  if(eval(second) < 10)
  {
    ds = "0";
    us = second;
  }
  else
  {
    second += " ";
    ds = second.charAt(0);
    us = second.charAt(1);
  }

  temp = "images/timer/" + dh + ".gif";
  if (tempdh != temp)
  {
    tempdh = temp;
    document.DH.src = temp;
  }
  temp = "images/timer/" + uh + ".gif";
  if (tempuh != temp)
  {
    tempuh = temp;
    document.UH.src = temp;
  }
  temp = "images/timer/" + dm + ".gif";
  if (tempdm != temp)
  {
    tempdm = temp;
    document.DM.src = temp;
  }
  temp = "images/timer/" + um + ".gif";
  if (tempum != temp)
  {
    tempum = temp;
    document.UM.src = temp;
  }
  temp = "images/timer/" + ds + ".gif";
  if (tempds != temp)
  {
    tempds = temp;
    document.DS.src = temp;
  }
  temp = "images/timer/" + us + ".gif";
  if (tempus != temp)
  {
    tempus = temp;
    document.US.src = temp;
  }

  fonction = "GetTimer()";
  ID = window.setTimeout(fonction,1000);
}

function show_timer()
{
  document.write('<TABLE BORDER=0 CELLPADDING=0 CELLSPACING=0><TR>');
  document.write('<TD ALIGN=center VALIGN="top">');
  document.write('<TABLE BORDER="1" CELLSPACING="0" CELLPADDING="0"><TR><TD>');
  document.write('<TABLE BORDER="0" CELLSPACING="0" CELLPADDING="0" BGCOLOR="white" BACKGROUND=""><TR>');
  document.write('<TD WIDTH="14" HEIGHT="19"><IMG NAME="DH" WIDTH="14" HEIGHT="19"></TD>');
  document.write('<TD WIDTH="14" HEIGHT="19"><IMG NAME="UH" WIDTH="14" HEIGHT="19"></TD>');
  document.write('<TD WIDTH="6"  HEIGHT="19"><IMG SRC="images/timer/sep.gif" WIDTH="6" HEIGHT="19"></TD>');
  document.write('<TD WIDTH="14" HEIGHT="19"><IMG NAME="DM" WIDTH="14" HEIGHT="19"></TD>');
  document.write('<TD WIDTH="14" HEIGHT="19"><IMG NAME="UM" WIDTH="14" HEIGHT="19"></TD>');
  document.write('<TD WIDTH="6"  HEIGHT="19"><IMG SRC="images/timer/sep.gif" WIDTH="6" HEIGHT="19"></TD>');
  document.write('<TD WIDTH="14" HEIGHT="19"><IMG NAME="DS" WIDTH="14" HEIGHT="19"></TD>');
  document.write('<TD WIDTH="14" HEIGHT="19"><IMG NAME="US" WIDTH="14" HEIGHT="19"></TD></TR></TABLE></TD></TR></TABLE>');
  GetTimer();
  document.write('</TD></TR></TABLE>');
}
