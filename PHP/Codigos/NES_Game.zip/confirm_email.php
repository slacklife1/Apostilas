<?php

require("backend.php");

$confirm = $authlib->confirm_email($id, $email, $mdhash);

if ($confirm != 2) {

  include("includes/content/confirm_email_error.php");

}

else {

  include("includes/content/confirm_email_done.php");

}
generate_template();

?>
