<?php


//this contains the current version define and some util functions
//related to the lib version.

define("PHPHTMLLIB_VERSION", "1.0.1");


/**
 * get the current version of
 * the phphtmllib libraries.
 *
 * @return string - the current version string
 */
function phphtmllib_get_version() {
    return PHPHTMLLIB_VERSION;
}


?>
