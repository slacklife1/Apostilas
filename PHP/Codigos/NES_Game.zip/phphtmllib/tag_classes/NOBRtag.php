<?php

/**
 * <NOBR> tag class
 */
class NOBRtag extends HTMLTagClass {

    /**
     * Tag definition for class.
     * subclass defines this value.
     * ie var $tag = "<TABLE>";
     * @var  string
     * @access   private
     */
    var $_tag = "<NOBR>";
}

?>
