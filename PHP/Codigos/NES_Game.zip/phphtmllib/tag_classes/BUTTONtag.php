<?php

/**
 * <BUTTON> tag class
 */
class BUTTONtag extends HTMLTagClass {

    /**
     * Tag definition for class.
     * subclass defines this value.
     * ie var $tag = "<TABLE>";
     * @var  string
     * @access   private
     */
    var $_tag = "<BUTTON>";

}

?>
