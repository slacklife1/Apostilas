<?php

//this file includes all of the utility function files.
//these files define utility functions that help 
//the creation of the tag objects.

include_once("$phphtmllib/tag_utils/divtag_utils.php");
include_once("$phphtmllib/tag_utils/form_utils.php");
include_once("$phphtmllib/tag_utils/html_utils.php");

?>
