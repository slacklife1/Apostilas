<?php

//this file includes all of the widgets
//that live in this dir.
//If you add a new widget, you should add it here.

include_once("$phphtmllib/widgets/FooterNav.php");
include_once("$phphtmllib/widgets/InfoTable.php");
include_once("$phphtmllib/widgets/NavTable.php");
include_once("$phphtmllib/widgets/TextNav.php");
include_once("$phphtmllib/widgets/HTMLPageClass.php");

?>
