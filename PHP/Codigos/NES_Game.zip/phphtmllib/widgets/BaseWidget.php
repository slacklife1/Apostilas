<?php

/**
 * this is the base widget class, that all widgets
 * are based off of.  It provides some basic 
 * members and methods
 */
class BaseWidget {

  /**
   * the indent level
   * @private
   */
  var $_indent_level=1;

  /**
   * The title of the table.
   * @public
   */
  var $title='';

  /**
   * the width of the widget
   * @public
   */
  var $width="100%";

  /**
   * hold the data for this
   * widget.  can be anything,
   * depends on the child class.
   * defaults to an array.
   * @private
   */
  var $data = array();

  /**
   * the root page to the images
   * dir.  This is used for any
   * refrences to images used
   * by this class.
   * namely spacer.gif.
   * @private
   */
  var $_image_dir = "/phphtmllib/widgets/images";

  /**
   * The path to the location of the css
   * needed to properly render this class
   * these are based off of the widget dir
   * from which the libs live in.
   * @private
   */
  var $_css_dir = "/phphtmllib/widgets/css/";


  /**
   * Constructor for the base widget.
   *
   */
  function BaseWidget() {
  }

  
  /**
   * get the widget's required css file.
   * 
   * @return string - path to css file.
   */
  function get_css_file() {
      
      if ($this->_css_file) {
          return $this->_css_dir . $this->_css_file;
      } else {
          return NULL;
      }      
  }

  //Utility functions for setting class members.
  function set_title( $title ) {
    $this->title = $title;
  }

  function set_width( $width ) {
    $this->width = $width;
  }

  /**
   * set the image directory root
   * where the images that this class
   * uses lives.
   * @param string  $dir - the path
   *
   */
  function set_image_dir( $dir ) {
      $this->_image_dir = $dir;
  }


  /**
   * function for adding content.
   * child class should override this.
   *
   */
  function push() {
      return NULL;
  }

  /**
   * function that will render the widget.
   * child class should override this.
   *
   */
  function render() {
      return NULL;
  }

    
}
?>
