<?php
require("backend.php");
include("includes/content/register.php");
generate_template();

?>

