<?php

require("backend.php");

$login_check = $authlib->is_logged();

if (!$login_check) {

  include("includes/content/nologin.php");
  exit;

}

$delete = $authlib->delete($login_check[1], $gamelib);

setcookie("nes");

include("includes/content/delete_done.php");
generate_template();

?>
