<?php

require("backend.php");

$login_check = $authlib->is_logged();

if (!$login_check) {

  include("includes/content/nologin.php");
  exit;

}

if (!sset($password) || !sset($password2)) {

  include("includes/content/chpass.php");

}

else {

  $chpass = $authlib->chpass($login_check[1], $password, $password2);

  if ($chpass != 2) {

    require("includes/content/chpass_error.php");

  }

  else {

    require("includes/content/chpass_done.php");

  }

}
generate_template();

?>
