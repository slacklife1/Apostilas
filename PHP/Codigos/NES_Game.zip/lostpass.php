<?php
require("backend.php");
include("includes/content/lostpass.php");
generate_template();

?>

