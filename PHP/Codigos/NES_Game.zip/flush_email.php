<?php

require("backend.php");
$login_check = $authlib->is_logged();

if (!$login_check)
{
  include("includes/content/nologin.php");
}
else
{
  if ($authlib->is_admin($login_check[0]) == TRUE)
  {
    if ($authlib->email_flush() == 2)
    {
      include("includes/content/flush_done.php");
    }
    else
    {
      include("includes/content/flush_error.php");
    }
  }
  else
  {
    include("includes/content/member.php");
  }
}
generate_template();

?>
