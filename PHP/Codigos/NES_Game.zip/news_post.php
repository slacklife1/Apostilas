<?php

require("backend.php");
$login_check = $authlib->is_logged();

if (!$login_check)
{
  include("includes/content/nologin.php");
}
else
{
  if ($authlib->is_admin($login_check[0]) == TRUE)
  {
    if (!sset($mode))
      $mode = '';
    if ($mode == "delete" && sset($id))
    {
      $news->delete($id, $authlib);
    }
    if (!(!sset($message) || !sset($subject)))
    {
      $news->write($login_check[0], $message, $subject, $authlib);
    }
    include("includes/content/news_post.php");
  }
  else
  {
    include("includes/content/member.php");
  }
}
generate_template();

?>
