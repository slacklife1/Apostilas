<?php

require("backend.php");

$lostpass = $authlib->lostpwd($email);

if ($lostpass == 2) {

  include("includes/content/lostpass_done.php");

}

else {

  include("includes/content/lostpass_error.php");

}
generate_template();

?>
