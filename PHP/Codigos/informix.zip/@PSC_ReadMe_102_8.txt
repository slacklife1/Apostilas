Title: Informix Recordset class
Description: A handy database and recordset class for the informix driver, for PHP3 and PHP4. Isolates your code from the Informix-specific driver syntax. Should be easily adaptable to other SQL databases. by Danny Heijl.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=102&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
