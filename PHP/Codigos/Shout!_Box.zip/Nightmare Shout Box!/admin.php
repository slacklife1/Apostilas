<?php
if ($user=="Nightmare11" and $pass=="Nightmare11"){
$cs = "cs.php?user=Nightmare11&pass=Nightmare11";
print "<font size=4><b>Admin Section For Shout! Box V 1.0</b></font>";
print "<br><br>";
print "<form action=$cs>";
print "Clear Shouts? <input type=submit value='Yes'><br>";
print "Current Shouts:<br><iframe src=shouts.html width=100 height=50></iframe>";
print "</form>";
}
else{
print "Sorry, incorrect password or username.";
}
?>