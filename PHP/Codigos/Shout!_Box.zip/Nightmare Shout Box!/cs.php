<?php
unlink("shouts.html");
touch("shouts.html");
$fp = fopen( "shouts.html", "a" );
fwrite( $fp, "<meta http-equiv=refresh content=15;URL=shouts.html>" );
print "Shouts Cleared!";
print "<meta http-equiv=refresh content=3;URL=shoutbox.php>";
?>