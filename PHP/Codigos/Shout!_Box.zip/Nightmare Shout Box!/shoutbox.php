<?php
print "<form action=submitshout.php>";
print "<iframe src=shouts.html width=175 height=150></iframe><br>";
print "<a href=login.php><font size=1>Goto Admin</a></font><br>";
print "<b>Name:<br></b><input type=text name=name><br>";
print "<b>Email Or Url:<br></b><input type=text name=email><br>";
print "<b>Message:<br></b><textarea name=message cols=20 columns rows=3 rows></textarea><br>";
print "<input type=submit value= 'Add Shout!'>";
print "</form>";
?>