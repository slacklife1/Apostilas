<?php
$add = fopen( "shouts.html", 'a' );
if($name=="<"){
print "One or more <b><a href=a>BANNED</b></a> tags were used, please send message not using these tags.";
}
elseif($email=="<"){
print "One or more <b><a href=a>BANNED</b></a> tags were used, please send message not using these tags.";
}
elseif($message=="<"){
print "One or more <b><a href=a>BANNED</b></a> tags were used, please send message not using these tags.";
}
elseif($name==""){
print "One or more fields where left empty, please fill them.";
}
elseif($message==""){
print "One or more fields where left empty, please fill them.";
}
elseif ($email==""){
$message = str_replace(":P", "<img src=smileytounge.GIF border=0>", $message);
$name = str_replace(":P", "<img src=smileytounge.GIF border=0>", $name);
$message = str_replace(":p", "<img src=smileytounge.GIF border=0>", $message);
$name = str_replace(":p", "<img src=smileytounge.GIF border=0>", $name);
$message = str_replace(":-P", "<img src=smileytounge.GIF border=0>", $message);
$name = str_replace(":-P", "<img src=smileytounge.GIF border=0>", $name);
$message = str_replace(":-P", "<img src=smileytounge.GIF border=0>", $message);
$name = str_replace(":-P", "<img src=smileytounge.GIF border=0>", $name);
$message = str_replace(":)", "<img src=smiley.GIF border=0>", $message);
$message = str_replace(":-)", "<img src=smiley.GIF border=0>", $message);
$name = str_replace(":)", "<img src=smiley.GIF border=0>", $name);
$name = str_replace(":-)", "<img src=smiley.GIF border=0>", $name);
$message = str_replace(":D", "<img src=smileybig.GIF border=0>", $message);
$message = str_replace(":d", "<img src=smileybig.GIF border=0>", $message);
$message = str_replace(":-D", "<img src=smileybig.GIF border=0>", $message);
$message = str_replace(":-d", "<img src=smileybig.GIF border=0>", $message);
$name = str_replace(":D", "<img src=smileybig.GIF border=0>", $name);
$name = str_replace(":d", "<img src=smileybig.GIF border=0>", $name);
$name = str_replace(":-D", "<img src=smileybig.GIF border=0>", $name);
$name = str_replace(":-d", "<img src=smileybig.GIF border=0>", $name);
$message = str_replace(":(", "<img src=smileysad.GIF border=0>", $message);
$message = str_replace(":-(", "<img src=smileysad.GIF border=0>", $message);
$name = str_replace(":(", "<img src=smileysad.GIF border=0>", $name);
$name = str_replace(":-(", "<img src=smileysad.GIF border=0>", $name);
$message = str_replace(":@", "<img src=smileyangry.GIF border=0>", $message);
$message = str_replace(":-@", "<img src=smileyangry.GIF border=0>", $message);
$name = str_replace(":@", "<img src=smileyangry.GIF border=0>", $name);
$name = str_replace(":-@", "<img src=smileyangry.GIF border=0>", $name);
$message = str_replace("(H)", "<img src=smileyhot.GIF border=0>", $message);
$message = str_replace("(h)", "<img src=smileyhot.GIF border=0>", $message);
$name = str_replace("(H)", "<img src=smileyhot.GIF border=0>", $name);
$name = str_replace("(h)", "<img src=smileyhot.GIF border=0>", $name);
$message = str_replace(";)", "<img src=smileywink.GIF border=0>", $message);
$message = str_replace(";-)", "<img src=smileywink.GIF border=0>", $message);
$name = str_replace(";)", "<img src=smileywink.GIF border=0>", $name);
$name = str_replace(";-)", "<img src=smileywink.GIF border=0>", $name);
$message = str_replace(":$", "<img src=smileyemb.GIF border=0>", $message);
$message = str_replace(":-$", "<img src=smileyemb.GIF border=0>", $message);
$name = str_replace(":$", "<img src=smileyemb.GIF border=0>", $name);
$name = str_replace(":-$", "<img src=smileyemb.GIF border=0>", $name);
$message = str_replace(":S", "<img src=smileyconfused.GIF border=0>", $message);
$message = str_replace(":-S", "<img src=smileyconfused.GIF border=0>", $message);
$name = str_replace(":S", "<img src=smileyconfused.GIF border=0>", $name);
$name = str_replace(":-S", "<img src=smileyconfused.GIF border=0>", $name);
$message = str_replace(":|", "<img src=smileystunned.GIF border=0>", $message);
$message = str_replace(":-|", "<img src=smileystunned.GIF border=0>", $message);
$name = str_replace(":|", "<img src=smileystunned.GIF border=0>", $name);
$name = str_replace(":-|", "<img src=smileystunned.GIF border=0>", $name);
$message = str_replace(":O", "<img src=smileyshock.GIF border=0>", $message);
$message = str_replace(":-O", "<img src=smileyshock.GIF border=0>", $message);
$name = str_replace(":O", "<img src=smileyshock.GIF border=0>", $name);
$name = str_replace(":-O", "<img src=smileyshock.GIF border=0>", $name);
fwrite ( $add, "<b>$name:</b> $message<br>" );
}
else{
$message = str_replace(":P", "<img src=smileytounge.GIF border=0>", $message);
$name = str_replace(":P", "<img src=smileytounge.GIF border=0>", $name);
$message = str_replace(":p", "<img src=smileytounge.GIF border=0>", $message);
$name = str_replace(":p", "<img src=smileytounge.GIF border=0>", $name);
$message = str_replace(":-P", "<img src=smileytounge.GIF border=0>", $message);
$name = str_replace(":-P", "<img src=smileytounge.GIF border=0>", $name);
$message = str_replace(":-P", "<img src=smileytounge.GIF border=0>", $message);
$name = str_replace(":-P", "<img src=smileytounge.GIF border=0>", $name);
$message = str_replace(":)", "<img src=smiley.GIF border=0>", $message);
$message = str_replace(":-)", "<img src=smiley.GIF border=0>", $message);
$name = str_replace(":)", "<img src=smiley.GIF border=0>", $name);
$name = str_replace(":-)", "<img src=smiley.GIF border=0>", $name);
$message = str_replace(":D", "<img src=smileybig.GIF border=0>", $message);
$message = str_replace(":d", "<img src=smileybig.GIF border=0>", $message);
$message = str_replace(":-D", "<img src=smileybig.GIF border=0>", $message);
$message = str_replace(":-d", "<img src=smileybig.GIF border=0>", $message);
$name = str_replace(":D", "<img src=smileybig.GIF border=0>", $name);
$name = str_replace(":d", "<img src=smileybig.GIF border=0>", $name);
$name = str_replace(":-D", "<img src=smileybig.GIF border=0>", $name);
$name = str_replace(":-d", "<img src=smileybig.GIF border=0>", $name);
$message = str_replace(":(", "<img src=smileysad.GIF border=0>", $message);
$message = str_replace(":-(", "<img src=smileysad.GIF border=0>", $message);
$name = str_replace(":(", "<img src=smileysad.GIF border=0>", $name);
$name = str_replace(":-(", "<img src=smileysad.GIF border=0>", $name);
$message = str_replace(":@", "<img src=smileyangry.GIF border=0>", $message);
$message = str_replace(":-@", "<img src=smileyangry.GIF border=0>", $message);
$name = str_replace(":@", "<img src=smileyangry.GIF border=0>", $name);
$name = str_replace(":-@", "<img src=smileyangry.GIF border=0>", $name);
$message = str_replace("(H)", "<img src=smileyhot.GIF border=0>", $message);
$message = str_replace("(h)", "<img src=smileyhot.GIF border=0>", $message);
$name = str_replace("(H)", "<img src=smileyhot.GIF border=0>", $name);
$name = str_replace("(h)", "<img src=smileyhot.GIF border=0>", $name);
$message = str_replace(";)", "<img src=smileywink.GIF border=0>", $message);
$message = str_replace(";-)", "<img src=smileywink.GIF border=0>", $message);
$name = str_replace(";)", "<img src=smileywink.GIF border=0>", $name);
$name = str_replace(";-)", "<img src=smileywink.GIF border=0>", $name);
$message = str_replace(":$", "<img src=smileyemb.GIF border=0>", $message);
$message = str_replace(":-$", "<img src=smileyemb.GIF border=0>", $message);
$name = str_replace(":$", "<img src=smileyemb.GIF border=0>", $name);
$name = str_replace(":-$", "<img src=smileyemb.GIF border=0>", $name);
$message = str_replace(":S", "<img src=smileyconfused.GIF border=0>", $message);
$message = str_replace(":-S", "<img src=smileyconfused.GIF border=0>", $message);
$name = str_replace(":S", "<img src=smileyconfused.GIF border=0>", $name);
$name = str_replace(":-S", "<img src=smileyconfused.GIF border=0>", $name);
$message = str_replace(":|", "<img src=smileystunned.GIF border=0>", $message);
$message = str_replace(":-|", "<img src=smileystunned.GIF border=0>", $message);
$name = str_replace(":|", "<img src=smileystunned.GIF border=0>", $name);
$name = str_replace(":-|", "<img src=smileystunned.GIF border=0>", $name);
$message = str_replace(":O", "<img src=smileyshock.GIF border=0>", $message);
$message = str_replace(":-O", "<img src=smileyshock.GIF border=0>", $message);
$name = str_replace(":O", "<img src=smileyshock.GIF border=0>", $name);
$name = str_replace(":-O", "<img src=smileyshock.GIF border=0>", $name);
fwrite ( $add, "<b><a href=$email target=_blank>$name:</b></a> $message<br>" );
}
print "<meta http-equiv=refresh content=0;URL=shoutbox.php>";
?>