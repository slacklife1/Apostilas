Title: Shout! Box
Description: A shout box, for users to leave messages, or chat on your web site.
This shout box is simple, with emoticon support. The default password and username for admin are, Nightmare11 and Nightmare11 to change these look in admin.php and look at line 2 [[ if ($user=="Nightmare11" and $pass=="Nightmare11") ]]
Simple, easy to add extra emoticons 100% ideal for begginer.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=781&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
