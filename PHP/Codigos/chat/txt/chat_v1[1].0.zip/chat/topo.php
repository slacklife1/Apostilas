<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script>
function Sair(){
	sala = '<?echo $sala?>';
	usuario = '<?echo $usuario?>';
	url = 'sair.php?sala=' + sala + '&usuario=' + usuario;
	parent.document.location = url;
}
</script>
</head>

<body bgcolor="#000066" onbeforeunload="Sair();">
<img src="images/logog.gif" width="210" height="42"> 
</body>
</html>
