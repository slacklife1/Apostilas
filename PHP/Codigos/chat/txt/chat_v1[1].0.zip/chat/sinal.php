<?
session_start();
require("chat.inc.php");

//cria o objeto e atribui as propriedades
$obj = new chat;
$obj->sala = $sala;
$obj->usuario = $usuario;

$obj->sinal(); //emite sinal ao servidor dizendo que o usuario esta online

//captura se existem novas mensagens
if($obj->existe_mensagens($qtdmsgs)) $imagem = "images/control_2.gif";
else $imagem = "images/control_1.gif";

//retorna a imagem para o browser
Header("Content-type: image/gif");
Header("Pragma: no-cache");
echo Imagem($imagem);
function Imagem($arquivo){
	$fd = fopen($arquivo, "r");
	$conteudo = fread($fd, filesize($arquivo));
	return $conteudo;
}
?>