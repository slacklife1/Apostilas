<?
require("chat.inc.php");

$obj = new chat;
$obj->sala = $sala;
$obj->remove_usuario($usuario);

header("Location: index.php");
?>