<?
function DropListAcoes($type){
	global $path_chat;
	$c = new chat;
	$c->path = $path_chat;
	$ar_acoes = $c->type;
	for($i=0;$i<count($ar_acoes);$i++)
		$ar_drop = add_array($ar_drop, $ar_acoes[$i], $i);
	return drop_down_array("tipo", $ar_drop, $type, 1);;
}

function DropListSounds(){
	global $path_chat;
	$c = new chat;
	$c->path = $path_chat;
	$ar_sounds = $c->Sound;
	$ar_drop = add_array($ar_drop, "enviar som: ", "", 0);
	for($i=0;$i<count($ar_sounds);$i++){
		$nome_som = strtoupper(substr($ar_sounds[$i], 0,1)) . substr($ar_sounds[$i], 1, strlen($ar_sounds[$i]) - 5);
		$ar_drop = add_array($ar_drop, $nome_som, $ar_sounds[$i]);
	}
	return drop_down_array("som", $ar_drop, "", 1);;	
}

function DropListImages(){
	$c = new chat;
	$ar_images = $c->FileImg;
	$ar_names = $c->DescImg;
	$ar_drop = add_array($ar_drop, "enviar imagem: ", "", 0);
	for($i=0;$i<count($ar_images);$i++)
		$ar_drop = add_array($ar_drop, $ar_names[$i], $ar_images[$i]);
	return drop_down_array("imagem", $ar_drop, "", 1);;	
}

function DropListUsuarios($sala, $to){
	$c = new chat;
	$c->sala = $sala;
	$ar_usuarios = $c->usuarios();
	$ar_drop = add_array($ar_drop, "TODOS(".count($ar_usuarios).")", "", 0);
	for($i=0;$i<count($ar_usuarios);$i++)
		$ar_drop = add_array($ar_drop, $ar_usuarios[$i]);
	return drop_down_array("para", $ar_drop, $to, 1);
}

function Formulario($sala){
	global $usuario, $private, $para, $sala, $tipo;

	if($private)
		$ckeck_private = '<input type="checkbox" name="private" value="1" checked>';
	else
		$ckeck_private = '<input type="checkbox" name="private" value="1">';

	$t = new template;
	$t->LoadTemplate("post.htm");
	$t->UpdateVar("drop_down_acoes", DropListAcoes($tipo));
	$t->UpdateVar("usuario", $usuario);
	$t->UpdateVar("sala", $sala);
	$t->UpdateVar("drop_down_usuarios", DropListUsuarios($sala, $para));
	$t->UpdateVar("drop_down_som", DropListSounds());
	$t->UpdateVar("drop_down_images", DropListImages());
	$t->UpdateVar("check_private"	, $ckeck_private);
	$t->UpdateVar("sala", $sala);
	return $t->GetCode();
}

function drop_down_array($nome_campo, $array, $selecionado="", $retorno=0){	
	$output.='<select name="'.$nome_campo.'" class="textbox">';
	for($i=0;$i<count($array);$i++)
	  $output.='<option value="'.$array[$i][0].'"'.igual($array[$i][0],$selecionado).'>'.$array[$i][1].'</option>';
    $output.='</select>';
	if($retorno)
		return $output;
	else
		echo $output;
}

function add_array($array, $vlr, $exibe="", $muda=1){
	if(!strlen($exibe)){
		if($muda)
			$exibe = $vlr;
	}
	$tamanho = count($array);
	$array[$tamanho][0] = $exibe;
	$array[$tamanho][1] = $vlr;
	return $array;
}

function igual($v1, $v2){
	if($v1==$v2)
		return " selected ";
}

/**************************************************************************/
function RetirarQuebraLinha($string){
	$ar = explode("\n", $string);
	for($i=0;$i<count($ar);$i++)
		$output.=$ar[$i];
	return $output;
}

function GetOutPutMessages($mensagens){
	for($i=0;$i<count($mensagens);$i++)
		$output.= GetMessage($mensagens[$i]);
	return $output;
}

function GetMessage($dados, $force=0){
	global $usuario;	

	$obj = new chat;

	/**********************************************************************************/
	/*caso a mensagem seja do proprio usuario, e nao for mensagem de saida ou entrada, retorno sem fazer nada*/
	if(!$force)
		if($dados["de"] == $usuario and !($dados["mensagem"]==$obj->MsgEntrada or $dados["mensagem"]==$obj->MsgSaida)) return;

	/**********************************************************************************/
	/*caso nao tenha conteudo na mensagem, imagem, ou som, saio retorno sem fazer nada*/
	if(!strlen($dados["mensagem"]) and !strlen($dados["imagem"]) and !strlen($dados["som"]))
		return;

	/**********************************************************************************/
	/*previne a exibicao de mensagens privadas para quem n�o � destinatario da mensagem*/
	if($dados["privativa"])
		if($dados["para"]!=$usuario and $dados["de"]!=$usuario and $dados["para"])
			return;
	/**********************************************************************************/

	$output = '<p>';
	if(($dados["para"]==$usuario or $dados["de"]==$usuario) and $dados["mensagem"]!="")
		$output.= H_Table();
	$output.= TimeMessage(date("H:m:i"));
	$output.= NomeFrom($dados["de"]);
	$output.= PrivateMessage($dados["privativa"]);
	$output.= TipoMessage($obj->type[$dados["tipo"]], $dados["para"], $dados["privativa"]);
	$output.= NomeTo($obj->type[$dados["tipo"]], $dados["para"], $dados["privativa"]);
	$output.= Message($dados["mensagem"], $obj->type[$dados["tipo"]]);
	if(($dados["para"]==$usuario or $dados["de"]==$usuario) and $dados["mensagem"]!="")
		$output.=F_Table();	
	$output.= '</p>';

	/*exibe a imagem caso enviada*/
	if($dados["imagem"])
		$output.='<p><blockquote>&nbsp;&nbsp;&nbsp;<img src="images/'.$dados["imagem"].'"></blockquote>';

	/*toca som caso enviado*/
	if($dados["som"])
		$output.='<script>parent.PlaySound("sounds/'.$dados["som"].'");</sc\'+\'ript>';

	return $output;
}

function H_Table(){
	return '<table bgcolor="#D8D8D8" cellspacing="0" cellpadding="3" border="0"><tr><td>';
}

function F_Table(){
	return '</td></tr></table>';
}

function NomeFrom($var){
	global $usuario;
	$output = '<b>' . $var . '</b>';
	return $output;
}

function PrivateMessage($private){
	if($private)
		return '<i> reservadamente </i>';
}

function TimeMessage($var){
	return '<small>('.$var.') </small>';
}

function TipoMessage($tipo, $to, $private){
	if($tipo=="fala para" and !$to and !$private)
			return;
	return " <i>" . $tipo . ' </i>';
}

function NomeTo($tipo, $to, $private){
	if(!$to){
		if($tipo=="fala para" and !$private)
			return ': ';
		else
			return 'TODOS: ';
	}
	return $to . ': ';
}

function Message($msg, $type){
	if($type=="grita com")
		return '<font size=+2>'.$msg.'</font>';
	else
		return $msg;
}

/**********************************************************************************************************************************/
class template{var $code;function template($caminho=""){if(strlen($caminho)>256){$this->PutCode($caminho);return;}if(strlen($caminho)!=0){if(!file_exists($caminho))$this-PutCode($caminho);else$this->LoadTemplate($caminho);}}function LoadTemplate($caminho){if(strlen($caminho)>256){$this->PutCode($caminho);$this->CleanTemplate();return;}if(!strlen($caminho))exit("N�o nformado o arquivo de template");if(!file_exists($caminho))exit("O arquivo de template <b>".$caminho."</b> n�o foi encontrado." );$fd=fopen($caminho,"r");$this->code=fread($fd,filesize($caminho));$this->CleanTemplate();fclose ($fd);}function CleanTemplate(){$this->code=str_replace("<!-- ","<!--",$this->code);$this->code=str_replace(" -->","-->",$this->code);$this->code=str_replace("&lt;!--","<!--",$this->code);$this->code=str_replace("--&gt;","-->",$this->code);}function UpdateVar($nome_var,$valor_var){$nome_var="<!--".$nome_var."-->";$this->code=str_replace($nome_var,$valor_var,$this->code);}function chaPosicao($str){return strpos($this->code,$str);}function LoadBlock($block){if(!strlen($this->code))exit("Template n�o carregado");$start_pos=$this->AchaPosicao("<!--inicio_".$block."-->")+14+strlen($block);$finish_pos=$this->AchaPosicao("<!--fim_".$block."-->");if(!$start_pos or !$finish_pos)exit("Bloco <b>" . $block . "</b> n�o encontrado");return substr($this->code,$start_pos,$finish_pos - $start_pos);}function UpdateBlock($block,$var){while(true){$start_pos=$this->AchaPosicao("<!--inicio_".$block."-->");$finish_pos=$this->AchaPosicao("<!--fim_".$block."-->")+11+strlen($block);if(!$start_pos or !$finish_pos)return;$header=substr($this->code,0,$start_pos);$footer=substr($this->code,+$finish_pos);$this->code=$header.$var.$footer;}}function RemoveBlock($block){$this->UpdateBlock($block,"");}function GetCode(){return $this->code;}function PutCode($codigo){$this->code=$codigo;}function Campos(){$codigo=$this->code;$pos_inicial=0;$i=0;$tamanho=strlen($codigo);while(true){$pos_ini_char=strpos($codigo,"<!--",$pos_inicial);if(!is_integer($pos_ini_char))break;$pos_ini_char+=4;$pos_fim_char=strpos($codigo,"-->",$pos_ini_char);if(!is_integer($pos_fim_char))exit("Template informado com sintaxe inv�lida,n�o foi poss�vel determinar os campos.");$elemento[$i]=substr($codigo,$pos_ini_char,$pos_fim_char - $pos_ini_char);$i++;$pos_inicial=$pos_fim_char+3;}return $elemento;}function ExisteVar($nome){$string="<--".$nome."-->";if(!strlen(strpos($this->codigo,$string)))return false;else return true;}function ExisteBlock($nome){$string1="<--inicio_".$nome."-->";$string2="<--fim_".$nome."-->";if(!strlen(strpos($this->codigo,$string1)) or !strlen(strpos($this->codigo,$string2)))return false;else return true;}function ResetVars(){$campos=$this->Campos();for($i=0;$i<count($campos);$i++)$this->UpdateVar($campos[$i],"");}}
?>