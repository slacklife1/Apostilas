<?
require("chat.inc.php");
require("func_inc.php");

$obj = new chat;
$salas = $obj->salas();

for($i=0;$i<count($salas);$i++){
	$obj->sala = $salas[$i];
	$obj->atualiza_status();
	$ar_salas = add_array($ar_salas, $salas[$i] . '('.count($obj->usuarios()).')', $salas[$i]);
}

$drop_salas = drop_down_array("sala", $ar_salas, "", 1);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>TXTChat</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<p align="center"><strong><font color="#000099" size="5" face="Verdana, Arial, Helvetica, sans-serif">TXTChat</font></strong></p>
<p align="center"><strong><font color="#000099" size="5" face="Verdana, Arial, Helvetica, sans-serif">O 
  chat para seu site</font></strong></p>
<p align="center"><font color="#FF0000"><strong><?echo $msg?></strong></font></p>
<p><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Digite 
  seu apelido para entrar no chat</font></strong></p>
<form name="form1" method="post" action="chat.php">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr> 
      <td width="8%"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Apelido:</font></td>
      <td width="92%"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
        <input name="usuario" type="text" id="usuario">
        Sala: <?echo $drop_salas?> 
        <input type="submit" name="Submit" value="Entrar">
        </font></td>
    </tr>
  </table>
</form>
<p align="center">&nbsp;</p>
<p align="center"><a href="http://txtchat.netfocus.com.br"><font face="Arial, Helvetica, sans-serif">P&aacute;gina 
  oficial do TXTChat</font></a></p>
</body>
</html>