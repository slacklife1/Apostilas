<?
/****************************************************************
Classe: Chat
Descricao: Utilizado para chat na internet
Desenvolvedor: Daniel Ribeiro (danielribeiro2001@yahoo.com.br)
Criado: 02/10/2002
Site: http://txtchat.netfocus.com.br
/****************************************************************/
class chat{
	function chat(){
		$this->path = "salas/";
		$this->timeout = 15;
		$this->MsgEntrada = "entrou na sala...";
		$this->MsgSaida = "saiu da sala.";

			/*Tipos de Mensagens*/
			$this->type[0] = "fala para";
			$this->type[1] = "pergunta para";
			$this->type[2] = "responde para";
			$this->type[3] = "concorda com";
			$this->type[4] = "discorda de";
			$this->type[5] = "desculpa-se com";
			$this->type[6] = "surpreende-se com";
			$this->type[7] = "murmura para";
			$this->type[8] = "sorri para";
			$this->type[9] = "suspira por";
			$this->type[10] = "flerta com";
			$this->type[11] = "ri de";
			$this->type[12] = "d� um fora em";
			$this->type[13] = "briga com";
			$this->type[14] = "grita com";
			$this->type[15] = "xinga";

			/*sons*/
			$this->Sound[0] = "acelera.wav";
			$this->Sound[1] = "aplausos.wav";
			$this->Sound[2] = "assobio.wav";
			$this->Sound[3] = "barulho.wav";
			$this->Sound[4] = "beijo.wav";
			$this->Sound[5] = "brinde.wav";
			$this->Sound[6] = "despertador.wav";
			$this->Sound[7] = "gritos.wav";
			$this->Sound[8] = "latido.wav";
			$this->Sound[9] = "miado.wav";
			$this->Sound[10] = "mugido.wav";
			$this->Sound[11] = "musica.wav";
			$this->Sound[12] = "risadas.wav";
			$this->Sound[13] = "vaias.wav";

			/*descricao das imagens*/
			$this->DescImg[0] = "Assustado";
			$this->DescImg[1] = "Bocejo";
			$this->DescImg[2] = "Careta";
			$this->DescImg[3] = "Dentu�o";
			$this->DescImg[4] = "Desejo";
			$this->DescImg[5] = "Eca!";
			$this->DescImg[6] = "Gargalhada";
			$this->DescImg[7] = "Indeciso";
			$this->DescImg[8] = "Louco";
			$this->DescImg[9] = "Na praia";
			$this->DescImg[10] = "Ohhh!";
			$this->DescImg[11] = "OK!";
			$this->DescImg[12] = "Piscada";
			$this->DescImg[13] = "Raiva";
			$this->DescImg[14] = "Smack!";
			$this->DescImg[15] = "Sorrizo";
			$this->DescImg[16] = "Zangado";

			/*arquivo de imagens*/
			$this->FileImg[0] = "i38.gif";
			$this->FileImg[1] = "i27.gif";
			$this->FileImg[2] = "i23.gif";
			$this->FileImg[3] = "i30.gif";
			$this->FileImg[4] = "i18.gif";
			$this->FileImg[5] = "i31.gif";
			$this->FileImg[6] = "i32.gif";
			$this->FileImg[7] = "i33.gif";
			$this->FileImg[8] = "i34.gif";
			$this->FileImg[9] = "i28.gif";
			$this->FileImg[10] = "i25.gif";
			$this->FileImg[11] = "i20.gif";
			$this->FileImg[12] = "i36.gif";
			$this->FileImg[13] = "i37.gif";
			$this->FileImg[14] = "i19.gif";
			$this->FileImg[15] = "i21.gif";
			$this->FileImg[16] = "i26.gif";
	}

	function sinal(){
		$fd = fopen($this->path . $this->sala . ".sts", "a+");
		fputs($fd, $this->usuario . "|" . time() . "\n");
		fclose($fd);
		$this->atualiza_status();
	}

	function atualiza_status(){
		$arquivo = $this->path . $this->sala . ".sts";
		$fd = fopen($arquivo, "r");
		$conteudo = fread($fd, filesize($arquivo));
		fclose($fd);
		$ar_lines = explode("\n", $conteudo);
		for($i=0;$i<count($ar_lines)-1;$i++){
			$dados = explode("|", $ar_lines[$i]);
			$nome = $dados[0];
			$time = $dados[1];			
			if($time + $this->timeout > time()){
				$n = count($usuarios);			
				$usuarios[$n]["nome"] = $nome;
				$usuarios[$n]["time"] = $time;
			}
			else
				$usuarios_fora[] = $nome;
		}
		$fd = fopen($arquivo, "w");
		for($i=0;$i<count($usuarios);$i++)
			fputs($fd, $usuarios[$i]["nome"] . "|" . $usuarios[$i]["time"] . "\n");
		fclose($fd);

		//verifico se os usuarios que estao fora, est�o tambem no array de usuario, se nao estiverem, � pq saiu mesmo.
		for($i=0;$i<count($usuarios);$i++){
			if(!$this->ContidoArray($usuarios[$i]["nome"], $n_usuarios))
				$n_usuarios[] = $usuarios[$i]["nome"];
		}
		$usuarios = $n_usuarios;
		unset($n_usuario);

		if(count($usuarios)) $usuarios = array_unique($usuarios);		
		if(count($usuarios_fora)) $usuario_fora = array_unique($usuarios_fora);
		if(count($usuarios) and count($usuarios_fora)){
			for($i=0;$i<count($usuarios_fora);$i++){
				if(!$this->ContidoArray($usuarios_fora[$i], $usuarios))
					$this->mensagem_saida_usuario($usuarios_fora[$i]);
			}
		}
	}

	function existe_usuario($usuario=""){
		if(!$usuario) $usuario = $this->usuario;
		$usuarios_online = $this->usuarios();
		for($i=0;$i<count($usuarios_online);$i++)
			$usuarios_online[$i] = strtolower($usuarios_online[$i]);
		if($this->ContidoArray(strtolower($usuario), $usuarios_online))
			return true;
		else
			return false;
	}
	
	function remove_usuario($usuario){
		$arquivo = $this->path . $this->sala . ".sts";
		$fd = fopen($arquivo, "r");
		$conteudo = fread($fd, filesize($arquivo));
		fclose($fd);
		$ar_lines = explode("\n", $conteudo);
		for($i=0;$i<count($ar_lines)-1;$i++){
			$dados = explode("|", $ar_lines[$i]);
			$nome = $dados[0];
			$time = $dados[1];			
			if($nome != $usuario){
				$n = count($usuarios);
				$usuarios[$n]["nome"] = $nome;
				$usuarios[$n]["time"] = $time;
			}
		}
		$fd = fopen($arquivo, "w");
		for($i=0;$i<count($usuarios);$i++)
			fputs($fd, $usuarios[$i]["nome"] . "|" . $usuarios[$i]["time"] . "\n");
		fclose($fd);
		$this->mensagem_saida_usuario($usuario);		
	}
	
	function mensagem_entrada_usuario($usuario){
		$dados["de"] = $usuario;
		$dados["para"] = "";
		$dados["mensagem"] = $this->MsgEntrada;
		$dados["privativa"] = "";
		$dados["tipo"] = 0;
		$dados["imagem"] = "";
		$dados["som"] = "";
		$this->postar_mensagem($dados);
	}
	
	function mensagem_saida_usuario($usuario){
		$dados["de"] = $usuario;
		$dados["para"] = "";
		$dados["mensagem"] = $this->MsgSaida;
		$dados["privativa"] = "";
		$dados["tipo"] = 0;
		$dados["imagem"] = "";
		$dados["som"] = "";
		$this->postar_mensagem($dados);
	}

	function usuarios(){
		$arquivo = $this->path . $this->sala . ".sts";
		$fd = fopen($arquivo, "r");
		$conteudo = fread($fd, filesize($arquivo));
		fclose($fd);
		$ar_lines = explode("\n", $conteudo);
		for($i=0;$i<count($ar_lines)-1;$i++){
			$dados = explode("|", $ar_lines[$i]);
			$nome = $dados[0];
			if(!$this->ContidoArray($nome, $usuarios))
				$usuarios[count($usuarios)] = $nome;
		}
		return $usuarios;
	}

	function existe_mensagens($qtdmsgs){
		if(!$qtdmsgs) return true;
		$qtd_linhas = $this->qtd_linhas();
		if($qtd_linhas > $qtdmsgs) return true;
		else return false;
	}

	function obter_mensagens($qtdmsgs){
		if(!$qtdmsgs) return;

		$chaves = "de,para,mensagem,privativa,tipo,imagem,som";
		$chaves = explode(",",$chaves);

		$arquivo = $this->path . $this->sala . ".cho";
		$fd = fopen($arquivo, "r");
		$conteudo = fread($fd, filesize($arquivo));
		$ar_lines = explode("\n", $conteudo);
		for($i=$qtdmsgs-1;$i<count($ar_lines)-1;$i++){
			$tmp_dados = explode("|", substr($ar_lines[$i], 0, -1));
			for($j=0;$j<count($chaves);$j++)
				$dados[$chaves[$j]] = $tmp_dados[$j];
			$ar[count($ar)] = $dados;
		}		

		return $ar;
	}
	
	function mensagem_propria($usuario){
		if($usuario == $this->usuario) return true;
		else return false;
	}
	
	function desconecta_usuario(){
		$arquivo = $this->path . $this->sala . ".sts";
		$fd = fopen($arquivo, "r");
		$conteudo = fread($fd, filesize($arquivo));
		fclose($fd);
		$ar_lines = explode("\n", $conteudo);
		for($i=0;$i<count($ar_lines)-1;$i++){
			$dados = explode("|", $ar_lines[$i]);
			$nome = $dados[0];
			$time = $dados[1];			
			if($this->usuario!=$nome){
				$n = count($usuarios);			
				$usuarios[$n]["nome"] = $nome;
				$usuarios[$n]["time"] = $time;
			}
		}
		$fd = fopen($arquivo, "w");
		for($i=0;$i<count($usuarios);$i++)
			fputs($fd, $usuarios[$i]["nome"] . "|" . $usuarios[$i]["time"] . "\n");
		fclose($fd);
		$this->cria_arquivo_usuarios();		
	}

	function postar_mensagem($dados){
		$chaves = array_keys($dados);
		for($i=0;$i<count($chaves);$i++){ $dados[$chaves[$i]] = $this->LimparBarras($dados[$chaves[$i]]);}
		for($i=0;$i<count($chaves);$i++)
			$msg.=$dados[$chaves[$i]]."|";
		$msg.="\n";
		$arquivo = $this->path . $this->sala . ".cho";
		$fd = fopen($arquivo, "a");
		fputs($fd, $msg);
		fclose($fd);
	}

	function qtd_linhas(){
		$arquivo = $this->path . $this->sala . ".cho";
		$fd = fopen($arquivo, "r");
		$conteudo = fread($fd, filesize($arquivo));
		$ar_lines = explode("\n", $conteudo);
		return count($ar_lines);
	}

	function salas(){
		$dir = opendir("salas");
		$i=0;
		while($files = readdir($dir))
			if(substr($files, strlen($files) - 3)=="cho"){
				$salas[$i] = substr($files, 0, strlen($files)-4);
				$i++;
			}
		if(count($salas)!=0) sort($salas);
		return $salas;
	}

	function ContidoArray($item, $array){
		for($i=0;$i<count($array);$i++){
			if($item==$array[$i])
				return true;
		}
		return false;
	}
	function LimparBarras($t){
		return str_replace("|", " ", $t);
	}
}
?>