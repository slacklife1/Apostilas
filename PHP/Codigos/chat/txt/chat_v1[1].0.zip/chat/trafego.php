<?
session_start();
require("chat.inc.php");
require("func_inc.php");

//carrego o conteudo html da pagina de mensagens (utilizo session, para ele fazer isso somente 1 vez)
if(!session_is_registered("html_carregado")){
	session_register("html_carregado");
	$fd = fopen("mensagens.htm", "r");
	$msgs = fread($fd, filesize("mensagens.htm"));
	$msgs = RetirarQuebraLinha($msgs);
	fclose($fd);
}

$obj = new chat;
$obj->sala = $sala;
$obj->usuario = $usuario;
$mensagens = $obj->obter_mensagens($qtdmsgs);
$qtdmsgs+=count($mensagens);

$msgs.= GetOutPutMessages($mensagens);

?>
<script>
msgs = '<?echo $msgs?>';
if(msgs.length>0) parent.Escreve(msgs);
</script>