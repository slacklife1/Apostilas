<?
session_start();
require("chat.inc.php");

//removo as vars registradas
session_unregister("html_carregado");
session_unregister("qtdmsgs");
session_register("qtdmsgs"); //registro a variavel q conta as mensagens

//crio o objeto e defino as configuracoes
$obj = new chat;
$obj->sala = $sala;
$obj->usuario = $usuario;
if($obj->existe_usuario()){
	header("Location: index.php?msg=" . urlencode("J� existe um usu�rio com este nome na sala, por favor, escolha outro nome."));
	exit();
}
$obj->sinal();
$obj->atualiza_status();

$qtdmsgs = $obj->qtd_linhas();

$obj->mensagem_entrada_usuario($usuario);
?>
<script language="Javascript" src="script_js.php?sala=<?echo $sala?>&usuario=<?echo $usuario?>"></script>
<title>TXTChat</title>
<frameset rows="0,70,*,80" cols="*" frameborder="no" border="0">
  <frame src="trafego.php?sala=<?echo $sala?>&usuario=<?echo $usuario?>" name="trafego" frameborder="no" scrolling="default" noresize border="0">  
  <frame src="topo.php?sala=<?echo $sala?>&usuario=<?echo $usuario?>" name="topo" frameborder="no" noresize scrolling="no" border="0">
  <frame src="mensagens.htm" name="mensagens" frameborder="no" scrolling="yes" noresize border="0">
  <frame src="post.php?sala=<?echo $sala?>&usuario=<?echo $usuario?>" frameborder="no" scrolling="no" noresize border="0">  
</frameset><noframes></noframes>