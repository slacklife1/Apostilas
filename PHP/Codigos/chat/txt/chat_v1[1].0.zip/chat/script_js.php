var Logado;
var ImagemMensagens;
var Usuario = '<?echo $usuario?>';
var Sala = '<?echo $sala?>';

function ChecarNovasMensagens(){
	Retorno = ImagemMensagens.width;
	if(Retorno==2) CarregaMensagens();
}

function CarregaMensagens(){
	trafego.location.reload();
}

function VerificaMensagens(){		
	ImagemMensagens = new Image;
	ImagemMensagens.src = "sinal.php?sala="+Sala+"&usuario="+Usuario+"&diferencial="+Diferencial();
	ImagemMensagens.onload = ChecarNovasMensagens;
}

function TimerSinal(){
	VerificaMensagens();
	setTimeout("TimerSinal()",5000); //5 segundos
}

function DesconectaUsuario(){
	Imagem = new Image;
	Imagem.src = "desconecta.php?usuario=" + Usuario;
}

function Diferencial(){
	date = new Date();
	return date.getTime() ;
}

function Escreve(mensagem){
	mensagens.document.write(mensagem);
	if (typeof(scrollBy) != 'undefined')	{
		mensagens.scrollBy(0, 6000);
		mensagens.scrollBy(0, 6000);
	}
	else if (typeof(scroll) != 'undefined'){
		mensagens.scroll(0, 6000);
		mensagens.scroll(0, 6000);
	};
}

function PlaySound(Sound){
//  if(parent.frames["superior"].document.f1.Som.checked)
	parent.mensagens.document.write('<BGSOUND SRC="'+Sound+'" HIDDEN="TRUE" AUTOSTART="TRUE" LOOP="FALSE" MASTERSOUND>');
}

setTimeout("TimerSinal()",5000);