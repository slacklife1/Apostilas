<?
require("chat.inc.php");
require("func_inc.php");

if($msg){
	$obj = new chat;
	$obj->sala = $sala;
	$obj->usuario = $usuario;

	//dados da mensagem
	$dados["de"] = $usuario;
	$dados["para"] = $para;
	$dados["mensagem"] = $msg;
	$dados["privativa"] = $private;
	$dados["tipo"] = $tipo;
	$dados["imagem"] = $imagem;
	$dados["som"] = $som;
	
	$obj->postar_mensagem($dados);
	
	$mensagem = GetMessage($dados, 1);

	$output.= '
		<script>
		msgs = \''.$mensagem.'\';
		if(msgs.length>0) parent.Escreve(msgs);
		</script>
	';
}
$output.= Formulario($sala);

echo $output;
?>