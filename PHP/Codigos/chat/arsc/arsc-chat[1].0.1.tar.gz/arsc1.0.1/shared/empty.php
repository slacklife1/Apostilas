<?php include("../config.inc.php"); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/REC-html40/loose.dtd">
<html>
 <head>
  <title>
   <?php echo $arsc_param["title"]; ?>
  </title>
 </head>
 <body bgcolor="<?php echo $arsc_color["msg_window_background"]; ?>"></body>
</html>
