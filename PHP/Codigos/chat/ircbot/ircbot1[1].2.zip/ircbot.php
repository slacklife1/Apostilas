<? /***************************************/
   /************* IRCbot 1.2 **************/
   /** por infos (infos@superig.com.br) ***/
   /**           Matheus Meira           **/
   /***************************************/
   /***** id�ia original por ShadowMan ****/
   /***************************************/
   /*          Futuras ades�es:           */
   /* Comando !ping                       */
   /* Tratamento aos CTCPs                */
   /* Comando !rehash                     */
   /***************************************/

/* Se voc� for alterar o c�digo, mantenha os cr�ditos ao Autor

   Ao utilizar o BOT voc� est� concordando em
   n�o editar o CTCP version Reply

   Se voc� for utilizar parte deste script em outro script
   mantenha os cr�ditos do Autor no c�digo fonte ou na p�gina
   e me comunique pelo e-mail informando o script e qual ser�
   o uso do mesmo. */

/* O bot foi Testado com o PHP 5.0, podendo n�o funcionar
   corretamente no PHP 4.x.x */

/*
			Mudan�as

	1.2
- Timer funcionando perfeitamente
- Corre��o do comando emote
- Eventos
- DCCs
- Party Line
- Sistema de usuarios
- Resposta ao CTCP Version

	1.1
- Feito comando timer (n�o ficou bom, mas foi o melhor que deu para fazer)
- Op��o para exibir log no browser ou n�o (se exibir log no browser o bot s� se mant�m conectado enquanto o browser estiver aberto, bom para ver erros, se n�o exibir o log, o bot fica conectado mesmo depois de feixar o browser)
- Melhorado o sistema visual (agora com cores)

	1.0
- Feito todos os sistemas b�sicos
- Feito comando para adicionar ativadores
- Adicionado fun��es b�sicas como op, deop, kick, etc.
- Feito sistema visual (tanto no navegador quanto nos logs)
*/

// os comandos prontos s�o para voces se familiarizarem com o bot e est�o perfeitos para serem utilizados

// Tirando timeout
set_time_limit(0); ?><font face="Verdana" size="2"><?
// Criando a classe e setando as variaveis
$bot=@new bot;
$bot->senha = "";					// Senha do nickserv. deixe vazio ("") para n�o identificar
$bot->server = "irc.servidor.com.br";			// Servidor
$bot->porta = 6667;					// porta
$bot->nickserv = "NickServ!services@rede.com.br";	// Nick!username@rede do NickServ da sua rede para a auto-identifica��o
$bot->owner = "Seu_Nick";				// nick do owner (somente 1 nick)
$bot->me = "PHPBot";					// nick do bot
$bot->ame = "PHPBot_away";				// nick alternativo do bot
$bot->username = "phpbot";				// username do bot (nick!username@end)
$bot->realname = "phpbot by infos";			// nome do bot
$bot->canais = "#canal1 #canal2";			// canais para entrar ao conectar
$bot->quitmsg = "Requisitado";				// mensagem padr�o de quit
$bot->modes = "+p";					// Modos postos pelo bot ao conectar.. deixe vazio ("") para n�o setar
$bot->reconectar = true;				// reconectar ao perder conex�o?
$bot->visual = false;					// Bot com visual?
	// quando true: o navegador mostrar� o log de tudo que o bot recebe do servidor/do que o bot envia para o servidor,
	// o bot s� permanece conectado enquanto o navegador estiver aberto. o bot tamb�m loga tudo no arquivo bot.log. 		Ideal para ser utilizado ao fazer altera��es no bot (ver erros).
	// quando false: o log das a��es enviadas para o servidor e recebidas pelo mesmo s� s�o postas no arquivo bot.log.
	// O bot � executado mesmo quando o navegador est� fechado.
class bot {
	function conectar() {
		// abre o socket, d� erro de falhar
		$this->fp=@stream_socket_client($this->server.":".$this->porta, $erro, $msg, 30) or die("Erro ao abrir o socket. Erro ".$erro.": ".$msg." ".$this->server.":".$this->porta."</font>");
		if ($this->visual) {
			echo "Conectado...";
			flush();
			ob_flush();
		}
	}
	function logar() {
		// seta o username, modo de usu�rio e realname
		$this->enviar("USER ".$this->username." 0 * :".$this->realname);
		// seta o nick
		$this->enviar("NICK ".$this->me);
		// identifica o nick
		if ($this->senha != "") $this->enviar("nickserv identify ".$this->senha, false);
		// se foi especificado algum modo, ele seta
		if ($this->modes != "") $this->enviar("MODE ".$this->me." ".$this->modes);
	}
	function desconectar() {
		// Fui desconectado
		// Tira a flags pra reconectar (?) exibe desconectar no log e no navegador
		$this->log("-> Desconectado", "","<br>");
		fclose($this->fp); fclose($this->log); fclose($this->usr);
	}
	function quit($q = null) {
		// idem ao de cima, por�m ele aqui solicita a desconex�o.. e exibe a mensagem de quit padr�o se n�o for especificada..
		$this->reconectar=false;
		if ($q != null) $this->enviar("QUIT :".$q);
		else $this->enviar("QUIT :".$this->quitmsg);
		sleep(1);
		fclose($this->fp); fclose($this->log); die("</font>");
	}
	function enviar($texto, $most = true) {
		// envia um comando ao servidor, e chama o comando pra logar a mensagem
		fputs($this->fp, $texto."\r\n");
		if ($most) $this->log("-> ".$texto);
	}
	function log($texto, $pre = "", $suf = "") {
		// exibe o parametro no log e no navegador
		// $pre eh para ser utilizado coisas como, cores, etc..
		// $suf para fechar as tags
		fwrite($this->log,$texto."\n");
		if ($this->visual) {
			echo "<br>".$pre."(".date("H:i:s").") ".$texto.$suf;
			flush();
			ob_flush();
		}
	}
	function rodar() {
		// enquanto tiver setado para permanecer o bot conectado
		while ($this->reconectar) {
			// abre o log
			$this->log=@fopen("Bot.log","a");
			$this->usr=@fopen("usuarios.usr","a");
			fclose($this->usr);
			$this->usr=@fopen("usuarios.usr","r");
			// conecta
			$this->conectar();
			sleep(1);
			// envia os parametros da conex�o
			$this->logar();
			// entra nos canais especificados automaticamente
			$this->join($this->canais);
			$timea=time(); // para o timer (leia sobre ele mais em baixo)

			// enquanto a conex�o estiver ativa, pega o texto recebido
			if (isset($this->fp)) {
			while (!feof($this->fp)) {

				// Se n�o receber nada em 0.4 segundos ele "pula" a linha que recebe os dados do servidor, evitando do php travar naquela linha esperando por algum dado
				stream_set_timeout($this->fp,0,40);
				// limpa a variavel e espera 0.4s para ver se o servidor enviou alguma coisa. (se n�o enviar nada em 0.1s ele pula a linha)
				$t=""; $t=fgetss($this->fp, 1024);
				// limpa as quebras de linha
				$t=trim($t);
				// divide ele num array para tratamento
				$q=explode(" ",$t);
				// pega o host do user (user!username@address)
				$host=substr($q[0],1);
				// pega o host
				$nick=explode("!",$host);
				$nick=$nick[0];
				// seta vazio para n�o pegar valores passados
				$msg="";
				// se o parametro for notice ou privmsg (mensagem)
				if (isset($q[1])) {
					if (($q[1] == "NOTICE") || ($q[1] == "PRIVMSG")) {
						// se for canal, seta o nome do canal
						if (substr($q[2],0,1) == "#") $onde=$q[2];
						// se for pvt, seta pvt
						else $onde="PVT";
					}
				// se nao for mensagem ou notice, seta NONE pra n�o chamar o evento que vai ver se tem algum comando "chamado"
					else $onde="NONE";
				}
				// limpa a string (?)
				if (isset($q[3])) $q[3]=trim($q[3]);
				// se a string tiver : no in�cio, ele tira (parametros com mais de 1 palavra vem precedidos de ":")
				if (isset($q[3])) {
					if (substr($q[3],0,1) == ":") $q[3]=substr($q[3],1);
				}
				// $q[3] no caso seria !join em "!join canal balblabla"

				// para x=4 (in�cio dos parametros) at� o fim dele, seta tudo numa variavel
				if (isset($q)) {
					for ($x=4;$x <= count($q)-1;$x++) {
						$msg .= " ".$q[$x];
					}
				}
				// limpa a mensagem de espa�os e quebras de linha (eles ocorrer�o)
				$msg=trim($msg);
				// mensagem total..
				if (isset($q[3]))
					$msgt = trim($q[3]." ".$msg);

				// IN�CIO DO TIMER
				// $timea � a ultima vez que eu passei por esse loop
				// entao eu vou testando segundo por segundo o $timea at� o time() atual
				// buscando ver todos os timers (inclusive os atrazados..)
				if (isset($this->vtimer)) {
					for($time=time(); $timea <= $time; $timea++) {
						// como todo array tem que come�ar com uma letra, a + tempo_procurado � o valor do array que eu vou buscar
						$timeb="a".$timea;
						// Para cada valor do array
						foreach($this->vtimer as $chave => $ok) {
							// se o nome da chave for igual ao tempo procurado
							if ($chave == $timeb) {
								// executamos os comandos pedidos...
								foreach ($ok as $comando)
									$this->$comando();
							}
						}
					}
					// apagamos a variavel para n�o gastar memoria..
					unset($this->vtimer[$timeb]);
				}

//				if (($timea == time()+8) && (isset($this->dcc)) {

				// tempo atual para usar no timer
				$timea=time();

				// Lendo os Chats
				if (isset($this->dcc)) {
					foreach ($this->dcc as $chave => $valor) {
						if (feof($valor["con"])) {
							fclose($valor["con"]);
							unset($this->portas[$this->dcc[$chave]["porta"]]);
							unset($this->dcc[$chave]["nick"]);
							unset($this->dcc[$chave]["con"]);
							unset($this->dcc[$chave]["ip"]);
							unset($this->dcc[$chave]["porta"]);
							unset($this->dcc[$chave]);
						}
						else {
							stream_set_timeout($valor["con"],0,25);
							$dcc="";
							$dcc=fgetss($valor["con"], 1024);
						}
						if (trim($dcc) != "") {
							fclose($valor["con"]);
							unset($this->portas[$this->dcc[$chave]["porta"]]);
							unset($this->dcc[$chave]["nick"]);
							unset($this->dcc[$chave]["con"]);
							unset($this->dcc[$chave]["ip"]);
							unset($this->dcc[$chave]["porta"]);
							unset($this->dcc[$chave]);
							$this->log("[".$valor["nick"]."\DCC] ".$dcc,"<b>","</b>");
							$dccm = explode(" ",$dcc);
							if (isset($this->comandos[strtoupper($dccm[0])])) {
								$array=$this->comandos[strtoupper($dccm[0])];
								$ondec=$this->comandos[strtoupper("onde".$dccm[0])];
								$msgd = "";
								for ($x=0;$x <= count($dccm)-1;$x++) $msgd .= " ".$dccm[$x];
								if ((("DCC" == strtoupper($ondec)) || (strtoupper($ondec) == "ALL")) && ($this->checa_flags($nick, $this->comandos["flags".strtoupper($dccm[0])]))) $this->$array($nick, $host, $msgd, $dcc, "DCC"); 
							}
						}
					}
				}
				// In�cio da parte de logs (no navegador e arquivo)
				// Se ele recebeu algum dado
				if ((!isset($q[1])) && ($q[0] != "")) $this->log("-SERVER- ".$q[0]);
				elseif ($t != "") {


					// INICIO DOS TESTES DCC
					if (((strtoupper(substr($msgt,0,14)) == strtoupper("DCC CHAT chat")) && (substr($msgt,strlen($msgt)-1,1) == "")) && ($this->checa_flags($nick,"p"))) {
						$ipp= long2ip(substr($msgt,15,10));
						$pporta=(int)substr($msgt,26,4);
						$conexx = @stream_socket_client($ipp.":".$pporta, $erro, $msg, 30) or $this->log("Erro ao abrir o DCC. Erro ".$erro.": ".$msg." ".$ipp.":".$pporta);
						stream_set_timeout($conexx,0,10);
						if ($conexx != false) {
							$this->dcc[$nick]["ip"] =$ipp;
							$this->dcc[$nick]["porta"] = $pporta;
							$this->dcc[$nick]["con"]=$conexx;
							$this->portas[$this->dcc[$nick]["porta"]]=true;
							$this->log("!!! DCC CHAT ".$nick."(".$this->dcc[$nick]["ip"].") ".$this->dcc[$nick]["porta"]);
							$this->dcc[$nick]["nick"] = $nick;
							$this->dcc($nick,"Digite sua senha");
						}
					}
					// FIM
					elseif(strtoupper(substr($msgt,0,9)) == "VERSION")
						$this->msg($nick,"VERSION PHP IRCBot por infos");
					

					// EVENTO JOIN
					elseif ($q[1] == "JOIN") { $this->log("--> Entrou ".substr($q[2],1).": ".$nick." (".$host.")","<font color=\"red\">","</font>"); $this->evento_quando_entrar($onde, $nick); }
					// EVENTO PART
					elseif ($q[1] == "PART") { $this->log("--> Saiu ".$q[2].": ".$nick." (".$host.")","<font color=\"red\">","</font>"); $this->evento_quando_sair($onde, $nick); }
					// O servidor manda eventos "NOTICE" simples.. como NOTICE :*** AUTH blablabla..
					// loga normalmente como vem do servidor
					elseif ($q[0] == "NOTICE") $this->log($t);
					// Se for setado algum modo
					elseif ($q[1] == "MODE") { $this->log("---> MODE ".$q[2]." ".$q[3]." ".$msg);
					$this->evento_quando_mudar_modos($q[2],$q[3]); }
					// Se algu�m muda de nick
					elseif ($q[1] == "NICK") $this->log("---> ".$nick." mudou o nick para: ".substr($q[2],1));
					// Se algu�m desconectou
					elseif ($q[1] == "QUIT") { $this->log("---> QUIT ".$nick.": ".substr($t,strpos($t,"QUIT")+6),"<font color=\"gray\">","</font>");
					$this->evento_quando_desconectar($nick); }
					// Se foi mudado o topico
					elseif ($q[1] == "TOPIC") { $this->log("---> ".$nick." mudou o topico de ".$q[2]." para: ".$msgt);
					$this->evento_quando_mudar_topico($q[2], $msgt); }

					// Se foi recebida alguma mensagem (sintaxe: [nick\onde] texto) onde "onde" � PVT ou o nome do canal
					elseif (substr($q[1],0,7) == "PRIVMSG") { $this->log("(".$nick."\\".$onde.") ".$msgt,"<font color=\"blue\">","</font>");
					$this->evento_quando_msg($nick, $onde, $msgt); }
					// Se foi recebido algum notice (sintaxe: [nick\onde] texto) onde "onde" � PVT ou o nome do canal
					elseif ($q[1] == "NOTICE") { $this->log("[".$nick."\\".$onde."] ".$msgt,"<font color=\"blue\">","</font>");
					$this->evento_quando_notice($nick, $onde, $msgt); }




					// Se mensagem total for vazia [lembrem-se que mensagemT � setado quando agente recebe uma mensagem ou notice, tendo a mensagem completa (e somente ela)] ele joga no log como uma fun��o do server n�o catalogada..
					elseif ((strtoupper($q[2]) == strtoupper($this->me)) || (strtoupper($q[2]) == strtoupper($this->ame))) $this->log("-SERVER- ".$msgt);
					else $this->log("-SERVER- ".$t);


					if (strtoupper($msgt) == strtoupper($this->me." :Nickname is already in use."))
						$this->enviar("NICK ".$this->ame);
					elseif (strtoupper($msgt) == strtoupper($this->ame." :Nickname is already in use.")) {
						fclose($this->fp);
						unset($this->fp);
					}
					// se recebi um PING (mensagem do servidor pra ver se o cliente esta ativo e n�o caiu) ele manda sua resposta
					if ($q[0] == "PING") $this->enviar("PONG ".$q[1]);
					// Identifique o nick, caso o nickserv pe�a
					if ((strtoupper($host) == strtoupper($this->nickserv)) && ($this->senha != "") && (strtoupper($msgt) == strtoupper("Este nick esta registrado e protegido.  Se o nick pertence"))) $this->enviar("nickserv identify ".$this->senha);
					// se $ONDE for diferente de none (onde eh none quando o texto recebido n�o � de mensagem ou notice)
					if (($onde != "NONE") && (isset($q[3]))) {
						// verifica aqui se o comando "pego" ($q[3]) existe na lista de comandos a executar uma fun��o..
						if (isset($this->comandos[strtoupper($q[3])])) {
							$array=$this->comandos[strtoupper($q[3])];
							$ondec=$this->comandos[strtoupper("onde".$q[3])];
							if (((strtoupper($onde) == strtoupper($ondec)) || (substr(strtoupper($onde),0,1) == strtoupper($ondec)) || (strtoupper($ondec) == "ALL")) && ($this->checa_flags($nick, $this->comandos[strtoupper("flags".$q[3])])))
								$this->$array($nick, $host, $msg, $msgt, $onde);
						}
						// (acima) se para o comando, existir uma fun��o, ela � chamada
					}
				}
			}
			}

			// Fui desconectado!
			$this->desconectar();
		}
	}
	function novocmd($cmd = null, $ativ = null, $flags="", $onde = "all") {
		// Fun��o que adiciona os comandos � "lista de comandos a executar uma fun��o"
		// se existir um comando E um ativador
		if (($cmd != null) && ($ativ != null)) {
			$x=array($this,$cmd);
			// se a fun��o existe (para evitar futuros erros..) ele adiciona no array da lista de fun��es
			if (is_callable($x,false)) {
				if (isset($this->comandos)) $this->comandos=array_merge($this->comandos, array(strtoupper($ativ) => strtoupper($cmd), strtoupper("onde".$ativ) => strtoupper($onde), strtoupper("flags".$ativ) => $flags));
				else $this->comandos=array_merge(array(strtoupper($ativ) => strtoupper($cmd), strtoupper("onde".$ativ) => strtoupper($onde)));
			}
			// Se n�o existir, ele cancela o processo pra evitar erros futuros
			else die("Voc� n�o pode definir um comando com uma fun��o inexistente! (fun��o: ".$cmd.")</font>");
		}
		else $this->log("Erro na adi��o de um novo comando! -COMANDO IGNORADO- Comando a ser executado: ".$cmd." Ativador: ".$ativ);
	}
	function timer($cmd = null, $tempo = null) {
		if (($cmd != null) && ($tempo != null) && (is_int($tempo))) {
			$x=array($this,$cmd);
			$tempo = (string) "a".intval($tempo+time());
			if (is_callable($x,false)) {
				$this->vtimer=array_merge($this->vtimer, array($tempo => array_merge($this->vtime[$tempo], array($cmd))));
			}
			else die("Voc� n�o pode definir um comando com uma fun��o inexistente! (fun��o: ".$cmd.")</font>");
		}
		else $this->log("Erro no timer! -TIMER IGNORADO- Comando a ser executado: ".$cmd);
	}

	// Comandos novos ser�o comentados linha-a-linha na proxima vers�o

	// gera senha randomica para quando algu�m se registrar
	function gera_senha() {
		do {
			$z = true;
			$x = rand(5,9);
			$string="1evxCz92RuDOZ0AQLkV7Js8Ung4TlGrFPboIpdqiHB3cyNaSYWw6jM5htXKmfE";
			$senha="";
			for($y=0;$y <= $x;$y++) {
				$k=substr($string,rand(0,strlen($string)-1),1);
				if ((intval($k) > 0) || ($k == "0")) $z = false;
				$senha.=$k;
			}
		} while ($z);
		return $senha;
	}
	// sintaxe: pega_senha("nick"), retorna a senha do nick criptografada em md5
	function pega_senha($usuario) {
		rewind($this->usr);
		while ($txt=fgets($this->usr,4096)) {
			if (substr($txt,0,strpos($txt,�))==$usuario) {
				$senha=substr($txt,strpos($txt,�)+1,strpos($txt,�,strpos($txt,�)+1)-1-strpos($txt,�));
				break;
			}
		}
		if (isset($senha)) return $senha;
		else return null;
	}
	// sintaxe: pega_flags("nick"), retorna as flags do nick
	function pega_flags($usuario) {
		rewind($this->usr);
		while ($txt=fgets($this->usr,4096)) {
			if (substr($txt,0,strpos($txt,�))==$usuario) {
			$flags=substr($txt,strpos($txt,�,strpos($txt,�,strpos($txt,�)+1))+1,strpos($txt,�,strpos($txt,�,strpos($txt,�)+1))-3-strpos($txt,�,strpos($txt,�)+1));
				break;
			}
		}
		if (isset($flags)) return $flags;
		else return null;
	}
	// sintaxe: cadastro_usuario("nick"), registra um nick
	function cadastro_usuario($usr, $flags = "") {
		if (!is_writeable("usuarios.usr")) die("O arquivo usuarios.usr precisa ter permiss�o para escrever!</font>");
		fclose($this->usr);
		$this->usr=@fopen("usuarios.usr","a");
		$senha=$this->gera_senha();
		fwrite($this->usr,$usr."�".md5($senha)."�".$flags."�\r\n");
		fclose($this->usr);
		$this->usr=@fopen("usuarios.usr","r");
		return $senha;
	}
	// sintaxe: checa_flags("nick", "flags"), retorna true se o usuario tiver TODAS AS FLAGS.
	// se flags for igual a "", sempre retorna true
	function checa_flags($usuario, $flags = "") {
		$flag=$this->pega_flags($usuario);
		if ($flags == "") return true;
		for($x=1;$x<=strlen($flags);$x++) {
			$k=false;
			$fs=substr($flags,$x-1,1);
			for($y=1;$y<=strlen($flag);$y++) {
				$f=substr($flag,$y-1,1);
				if (($fs == $f) || (($f == "n") && (($fs == "m") || ($fs = "o"))) || (($f == "m") && ($fs = "o"))) { $regs.=$fs; $k = true; }
			}
			if (!$k) break;
		}
		return $k;
	}
	// sintaxe: del_flags("nick"), retorna as flags do nick, excluindo as especificadas
	function del_flags($usuario, $flgs) {
		$flags=$this->pega_flags($usuario);
		for($x=1;$x<=strlen($flags);$x++) {
			$fs=substr($flags,$x-1,1);
			$z=true;
			for($y=1;$y<=strlen($flgs);$y++) {
				$f=substr($flgs,$y-1,1);
				if ($fs == $f) $z=false;
			}
			if ($z) $regs.=$fs;
		}
		if (empty($regs)) return null;
		else return $regs;
	}
	function merge_flags($flg, $flag) {
		$regs=$flg;
		for ($x=1;$x <= strlen($flag);$x++) {
			$k=true;
			$fs=substr($flag,$x-1,1);
			for($y=1;$y<=strlen($flg);$y++) {
				$f=substr($flg,$y-1,1);
				if ($fs == $f) { $k=false; }
			}
			if ($k) $regs.=$fs;
		}
		return $regs;
	}
	function checa_ends($host, $h) {
		$x=0; $y=0; $k=true;
		while ($k) {
			while(substr($host,$x,1) == "*") {
				$host=substr($host,$x+1,strlen($h)-$x);
				$h=substr($h,strpos($h,substr($host,0,1)),strlen($h));
				$x=0;
				$y=0;
			}
			while (substr($h,$y,1) == "*") {
				$h=substr($h,$y+1,strlen($h)-$y);
				$host=substr($host,strpos($host,substr($h,0,1)),strlen($host));
				$x=0;
				$y=0;
			}
			if ((substr($host,$x,1) == "") && (substr($h,$y,1) == "")) return true;
			elseif (substr($host,$x,1) != substr($h,$y,1)) return false;
			elseif ((substr($host,$x,1) == "") || (substr($h,$y,1) == "")) return false;
			$x++; $y++;
		}
		return false;
	}
	// sintaxe: atual_dados("nick","senha","flags"), atualiza os dados do usu�rio no arquivo de configuracao
	// se senha ou flags forem deixados em branco, ele pega as atuais
	function atual_dados($usuario, $pass = null, $flags = null) {
		if (($pass == null) && ($flags == null)) return null;
		if ($flags == null) $flags=$this->pega_flags($usuario);
		if ($pass == null) $pass=$this->pega_senha($usuario);
		else $pass=md5($pass);
		$narq=@fopen("usuarios.usr.bak","a");
		while ($txt=fgets($this->usr,4096)) {
			if (substr($txt,0,strpos($txt,�))==$usuario)
				fwrite($narq,$usuario."�".$pass."�".$flags."�\r\n");
			else
				fwrite($narq,$txt);
		}
		fclose($narq);
		fclose($this->usr);
		unlink("usuarios.usr");
		rename("usuarios.usr.bak","usuarios.usr");
		$this->usr=@fopen("usuarios.usr","r");
	}


	// fun��es b�sicas..
	// Sintaxe delas: $onde $quem/$msg/$host/$nick/$canais $modo $tipo
	// nem todas recebem todas as variaveis..
	function dcc($onde = null, $msg = null) {
		if (($onde != null) && ($msg != null)) {
			fputs($this->dcc[$onde]["con"], $msg."\r\n");
			$this->log("-> DCC ".$onde.": ".$texto);
		}

	}
	function msg($onde = null, $msg = null) {
		// se existir um lugar e existir uma mensagem
		// envia a mensagem para o lugar
		if (($onde != null) && ($msg != null)) $this->enviar("PRIVMSG ".$onde." :".$msg);
	}
	function emote($onde = null, $msg = null) {
		// se existir um lugar e existir uma mensagem
		// envia a a��o para o lugar
		if (($onde != null) && ($msg != null)) $this->enviar("PRIVMSG ".$onde." :ACTION ".$msg."");
	}
	function notice($onde = null, $msg = null) {
		// se existir um lugar e existir uma mensagem
		// envia a mensagem para o lugar
		if (($onde != null) && ($msg != null)) $this->enviar("NOTICE ".$onde." :".$msg);
	}
	function op($onde = null, $quem = null) {
		// se existir o lugar e algu�m
		// d� op para o usu�rio no canal especificado
		if (($onde != null) && ($quem != null)) $this->mode($onde, $quem, "-v");
	}
	function deop($onde = null, $quem = null) {
		// se existir o lugar e algu�m
		// tira o op do usuario no canal especificado
		if (($onde != null) && ($quem != null)) $this->mode($onde, $quem, "-v");
	}
	function voice($onde = null, $quem = null) {
		// se existir o lugar e algu�m
		// d� voice para o usu�rio no canal especificado
		if (($onde != null) && ($quem != null)) $this->mode($onde, $quem, "-v");
	}
	function devoice($onde = null, $quem = null) {
		// se existir o lugar e algu�m
		// tira o voice do usuario no canal especificado
		if (($onde != null) && ($quem != null)) $this->mode($onde, $quem, "-v");
	}
	function ban($onde = null, $host = null) {
		// se existir o lugar e algu�m
		// bane a !!MASCARA!! do canal
		if (($onde != null) && ($quem != null)) $this->mode($onde, $quem, "+b");
	}
	function nick($nick) {
		// se o nick desejado for diferente do atual, muda..
		if (($nick != null) && (strtoupper($nick) != strtoupper($this->me))) $this->enviar("NICK ".$nick);
	}
	function kick($onde = null, $quem = null, $motivo = "Requested") {
		// se existir o local e a pessoa
		// kicka ela do canal com o motivo solicitado (ou o padrao)
		if (($onde != null) && ($quem != null)) $this->enviar("KICK ".$onde." ".$quem." :".$motivo);
	}
	function join($canais = "") {
		// se existir os canais
		// entra em todos os canais separados por um " " (espa�o)
			if ($canais != "") {
				$canais=explode(" ",$canais);
				foreach($canais as $x) $this->enviar("JOIN ".$x);
			}
	}
	function part($canais = "") {
		// se existir os canais
		// sai de todos os canais separados por um " " (espa�o)
			if ($canais != "") {
				$canais=explode(" ",$canais);
				foreach($canais as $x) $this->enviar("PART ".$x);
			}
	}
	function mode($onde = null, $quem = null, $modo = null, $tipo = 0) {
		// $tipo = 0 quando eu vou setar todos os "+b-x+z" pela variavel $modo
		// $tipo = 1 (default) eu vou utilizar $modo = "+b"
		// e $quem = "eu1 eu2 eu3"
		// e a funcao vai, automaticamente, ir setando os outros "+b" para todos da lista.. (soh funciona pra setar um unico modo..)
		// se existir lugar, alguem e modo
		if (($onde != null) && ($quem != null) && ($modo != null)) {
			// se os modos ja estao setados pela variavel $modo, seta os modos
			if ($tipo == 0) $this->enviar("MODE ".$onde." ".$modo." ".$quem);
			// se nao, ele ve quantos usuarios sao, e executa o modo em todos..
			else {
				$qtd=explode(" ",$quem);
				$qtd=count($qtd);
				$this->enviar("MODE ".$onde." ".$modo.str_repeat(substr($modo,1,1), $qtd-1)." ".$quem);
			}
		}
	}
	// comandos pr�-definidos,  veja abaixo do que se trata
	function _mensagem($nick, $host, $msg, $msgt) {
		$this->msg("#aow_shard",$msg);
	}
	function _emote($nick, $host, $msg, $msgt) {
		$this->emote("#aow_shard",$msg);
	}
	function _op($nick, $host, $msg, $msgt, $onde) {
		$this->mode($onde, $nick, "+o");
	}
	function _part($nick, $host, $msg, $msgt) {
		$this->part($msg);
	}
	function _join($nick, $host, $msg, $msgt) {
		$this->join($msg);
	}
	function _nick($nick, $host, $msg, $msgt) {
		$this->nick($msg);
	}
	function _quit($nick, $host, $msg = null, $msgt) {
		if ($msg != "") $this->quit($msg);
		else $this->quit($this->quitmsg);
	}
	function __msg1() {
		return "msg1";
	}
	function __msg2() {
		return "msg2";
	}
	function __msg3() {
		return "msg3";
	}
	function __msg4() {
		return "msg4";
	}
	function __msg5() {
		return "msg5";
	}
	function __msg6() {
		return "msg6";
	}
	function __msg7() {
		return "msg7";
	}
	function _taow() {
		$cmd="__msg".rand(1,7);
		$bot->msg("#mircall", $this->$cmd());
		$bot->timer("_taow", 600);
	}
	function _oi($nick, $host, $msg, $msgt, $onde) {
		if ($nick == $this->owner) {
			$this->notice($nick,"Ol�! Voc� est� sendo registrado como owner do bot neste exato momento.");
			$senha=$this->cadastro_usuario($nick, "np");
			$this->notice($nick,"Registro efetuado com sucesso! Sua senha �: ".$senha);
			$this->notice($nick,"Para muda-la digite .senha <novasenha> na party line.");
		}

	}
	// Sintaxe: .adduser nick
	function _adduser($nick, $host, $msg, $msgt, $onde) {
		$this->dcc($nick, "Registrando ".$msg." no bot");
		$senha=$this->cadastro_usuario($msg);
		$this->atual_dados($msg, null, "p");
		$this->notice($msg,"Ol�! Voc� foi registrado no bot neste exato momento!");
		$this->notice($msg,"Sua senha �: ".$senha);
		$this->notice($msg,"Para muda-la digite .senha <novasenha> na party line.");
	}
	// Sintaxe: .flags nick flags
	// Para remover as flags digite somente: .flags nick
	function _cflag($nick, $host, $msg, $msgt, $onde) {
		$q=explode(" ",$msg);
		if (empty($q[1])) $q[1]="";
		$this->atual_dados($q[0], null, $q[1]);
		$this->dcc($nick, "Flags setadas com sucesso");
	}
	// Sintaxe .verflags nick
	function _vflag($nick, $host, $msg, $msgt, $onde) {
		$this->dcc($nick,"Flags de ".$msg.": ".$this->pega_flags($msg));
	}


	function evento_quando_entrar($canal, $nick) {
	}
	function evento_quando_sair($canal, $nick) {
	}
	function evento_quando_mudar_modos($canal, $modos) {
	}
	function evento_quando_desconectar($nick) {
	}
	function evento_quando_mudar_topico($canal, $novotopic) {
	}
	// $onde pode ser PVT nessas 2 alternativas abaixo
	function evento_quando_msg($nick, $onde, $msgt) {
	}
	function evento_quando_notice($nick, $onde, $msgt) {
	}
}

// Adiciona novos comandos
// sintaxe: novocmd(funcao a ser chamada, ativador, flags para ativar o comando, onde);
// se onde nao for especificado, � chamado em todos os lugares (canais e pvts)
// se onde = pvt, s� � chamado no pvt
// se onde = #canal, s� � chamado no canal em quest�o
// se onde = #, � chamado em qualquer canal
// se onde = dcc, � chamado em qualquer DCC CHAT
// se flags = "", todos podem utiliza-lo
// a funcao deve ser criada na classe BOT para que funcione corretamente
// e deve ser declarada antes da fun��o rodar()
// TODAS as funcoes devem receber como par�metros:
// $nick, $host, $msg, $msgt, $onde
// ex: function _funcao($nick, $host, $msg, $msgt, $onde)

$bot->novocmd("_mensagem","!msg","o","pvt");
$bot->novocmd("_emote","!me","o","#canal");
$bot->novocmd("_quit","!quit","o");
$bot->novocmd("_part","!part","o");
$bot->novocmd("_nick","!nick","o");
$bot->novocmd("_op","!op","o","#");
$bot->novocmd("_join","!join","o");
$bot->novocmd("_oi","oi");
// S� REGISTRE UM USUARIO QUE ESTEJA CONECTADO AO IRC NO MOMENTO!!
$bot->novocmd("_adduser",".adduser","m","dcc");
$bot->novocmd("_cflag",".flags","m","dcc");
$bot->novocmd("_vflag",".verflags","m","dcc");

// Breve descri��o (atualizada :) sobre o timer:
// Na vers�o passada hovue um equ�voco da minha parte
// Existia uma maneira de fazer com que o Php n�o ficasse
// esperando o servidor enviar algum comando para continuar
// o script. Ela foi usada nesta vers�o.
// Sintaxe: $bot->timer("comando_a_ser_Executado", x);
// Depois de x segundos o bot vai executar o comando especificado.
// Para fazer com que o timer fique num loop (de 2 em 2 segundos
// ele mande uma mensagem para um canal), use o exemplo.

// neste exemplo, depois de 60 segundos ele ativa um timer que fala
// algo aleatorio no canal a cada 5 minutos
//$bot->timer("_taow", 600);
$bot->rodar();
$bot->desconectar();
?></font>