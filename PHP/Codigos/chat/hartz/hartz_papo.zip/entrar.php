<?
###############################################
## Sistema de Bate-Papo Mundo Hartz Company  ##
## Ver. 1.0								     ##
###############################################
##  Criado por: Leonardo Rossel (mr. hartz)  ##
##  E-mail: leo@mondohartz.com               ##
###############################################

if($apelido) {

  require('config.php');

  sql();

  $sql = "select count(*) as total from usuario";
  $consulta = mysql_query($sql);
  $resultado = mysql_fetch_array($consulta);
  $total = $resultado[total];

  $sql2 = "select apelido from usuario where apelido = '$apelido'";
  $consulta2 = mysql_query($sql2);
  $resultado2 = mysql_fetch_array($consulta2);

  if($total < $sala && $resultado2[apelido] == "") {

    mysql_query("insert into usuario values('','$apelido','$cor')");
    $id = mysql_insert_id();
    mysql_query("insert into mensagem values('','$apelido','TODOS','','$cor','','','entra na sala...','','$hora')");

    $apelido = urlencode($apelido);

    header("Location: batepapo.php?id=$id&apelido=$apelido");

  }
  
  elseif($resultado2[apelido] == "$apelido") {

    echo "<html>\n";
    echo "<body bgcolor=\"$fundo\" text=\"$texto\">";
    echo "<center>";
    echo $fonte . "\n";
    echo "<font color=\"red\">";
    echo "O apelido seleciona j� est� em uso <BR>";
    echo "</font>\n";
    echo "<p>\n";
    echo "<a href=\"javascript:history.back()\">Voltar</a>\n";
    echo "</body>\n";
    echo "</html>\n";

  }

  elseif(! $total < $sala) {

    echo "<html>\n";
    echo "<body bgcolor=\"$fundo\" text=\"$texto\">";
    echo "<center>";
    echo $fonte . "\n";
    echo "<font color=\"red\">";
    echo "O n�mero m�ximo de usu�rios �: $sala <BR>";
    echo "</font>\n";
    echo "<p>\n";
    echo "<a href=\"javascript:history.back()\">Voltar</a>\n";
    echo "</body>\n";
    echo "</html>\n";

  }
  
}

else
  header('Location: index.php');

?>