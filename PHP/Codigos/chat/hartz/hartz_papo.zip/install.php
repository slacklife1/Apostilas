<?
###############################################
## Sistema de Bate-Papo Mundo Hartz Company  ##
## Ver. 1.0								     ##
###############################################
##  Criado por: Leonardo Rossel (mr. hartz)  ##
##  E-mail: leo@mondohartz.com               ##
###############################################
require('config.php');

sql();

function tabelas()
{
	$sql[] = <<<EOT
CREATE TABLE cor (
  id int(10) unsigned NOT NULL auto_increment,
  texto varchar(15) NOT NULL default '',
  cor varchar(7) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;
EOT;

$sql[] = <<<EOT
INSERT INTO cor VALUES (1,'Preto','000000');
EOT;
	$sql[] = <<<EOT
INSERT INTO cor VALUES (2,'Cinza','737373');
EOT;
	$sql[] = <<<EOT
INSERT INTO cor VALUES (3,'Vermelho','ff0000');
EOT;
	$sql[] = <<<EOT
INSERT INTO cor VALUES (4,'Verde','00b038');
EOT;
	$sql[] = <<<EOT
INSERT INTO cor VALUES (5,'Azul','324395');
EOT;
	$sql[] = <<<EOT
INSERT INTO cor VALUES (6,'Laranja','e7651a');
EOT;
	$sql[] = <<<EOT
INSERT INTO cor VALUES (7,'Roxo','993399');
EOT;

	$sql[] = <<<EOT
CREATE TABLE imagem (
  id int(10) unsigned NOT NULL auto_increment,
  texto varchar(15) NOT NULL default '',
  arquivo varchar(15) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;
EOT;

$sql[] = <<<EOT
INSERT INTO imagem VALUES (1,'Beijo','beijo.gif');
EOT;
	$sql[] = <<<EOT
INSERT INTO imagem VALUES (2,'Sorriso','sorriso.gif');
EOT;
	$sql[] = <<<EOT
INSERT INTO imagem VALUES (3,'Bravo','bravo.gif');
EOT;
	$sql[] = <<<EOT
INSERT INTO imagem VALUES (4,'Gargalhada','gargalhada.gif');
EOT;
	$sql[] = <<<EOT
INSERT INTO imagem VALUES (5,'Triste','triste.gif');
EOT;
	$sql[] = <<<EOT
INSERT INTO imagem VALUES (6,'Flerte','flerte.gif');
EOT;
	$sql[] = <<<EOT
INSERT INTO imagem VALUES (7,'Saco Cheio','sacocheio.gif');
EOT;
	$sql[] = <<<EOT
INSERT INTO imagem VALUES (8,'Lingua','lingua.gif');
EOT;
	$sql[] = <<<EOT
INSERT INTO imagem VALUES (9,'Espanto','espanto.gif');
EOT;
	$sql[] = <<<EOT
INSERT INTO imagem VALUES (10,'Dormindo','dormindo.gif');
EOT;

	$sql[] = <<<EOT
CREATE TABLE mensagem (
  id int(10) unsigned NOT NULL auto_increment,
  de varchar(20) NOT NULL default '',
  para varchar(20) NOT NULL default 'TODOS',
  acao tinyint(3) unsigned NOT NULL default '0',
  cor tinyint(3) unsigned NOT NULL default '0',
  imagem tinyint(3) unsigned default NULL,
  som tinyint(3) unsigned default NULL,
  msg text NOT NULL,
  reservado tinyint(1) NOT NULL default '0',
  hora time NOT NULL default '00:00:00',
  PRIMARY KEY  (id)
) TYPE=MyISAM;
EOT;

	$sql[] = <<<EOT
CREATE TABLE som (
  id int(10) unsigned NOT NULL auto_increment,
  texto varchar(15) NOT NULL default '',
  arquivo varchar(15) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;
EOT;

	$sql[] = <<<EOT
INSERT INTO som VALUES (1,'Ahh Choo','Ahh_choo.wav');
EOT;
	$sql[] = <<<EOT
INSERT INTO som VALUES (2,'Bullet','Bullet.wav');
EOT;
	$sql[] = <<<EOT
INSERT INTO som VALUES (3,'Bluup','Bluup.wav');
EOT;
	$sql[] = <<<EOT
INSERT INTO som VALUES (4,'Hahaha','Hahaha.wav');
EOT;
	$sql[] = <<<EOT
INSERT INTO som VALUES (5,'Sealion','Sealion.wav');
EOT;
	$sql[] = <<<EOT
INSERT INTO som VALUES (6,'Shiver','Shiver.wav');
EOT;
	$sql[] = <<<EOT
INSERT INTO som VALUES (7,'Wood','Wood.wav');
EOT;

	$sql[] = <<<EOT
CREATE TABLE usuario (
  id int(10) unsigned NOT NULL auto_increment,
  apelido varchar(20) NOT NULL default '',
  cor tinyint(3) unsigned default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;
EOT;

	return $sql;
}
function cria_tabelas()
{
	global $erros;
		
	$sql = tabelas();
	 
	 foreach( $sql as $q )
	 {
        if ( ! mysql_query($q) )
        {
        	$erros .= "mySQL Error: ".mysql_error()."<br><br>";
        }
		
	}
}

cria_tabelas();
echo "<font face=\"verdana\" size=\"2\"> Instala��o realizada com sucesso!";
?>