<?
###############################################
## Sistema de Bate-Papo Mundo Hartz Company  ##
## Ver. 1.0								     ##
###############################################
##  Criado por: Leonardo Rossel (mr. hartz)  ##
##  E-mail: leo@mondohartz.com               ##
###############################################

if(! $id && ! $apelido)
  header('Location: ../index.php');

require('config.php');

sql();

$cor = verificar($id, $apelido);

mysql_query("delete from usuario where id = '$id' and apelido = '$apelido'");
mysql_query("insert into mensagem values('','$apelido','TODOS','','$cor','','','Saiu da sala','','$hora')");

header('Location: ../index.php');

?>