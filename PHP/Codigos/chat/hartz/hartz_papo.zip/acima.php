<?
###############################################
## Sistema de Bate-Papo Mundo Hartz Company  ##
## Ver. 1.0								     ##
###############################################
##  Criado por: Leonardo Rossel (mr. hartz)  ##
##  E-mail: leo@mondohartz.com               ##
###############################################

require('config.php');

sql();

verificar($id, $apelido);

?>
<html>
<link rel="stylesheet" href="estilo.css" type="text/css">
<body bgcolor="<?php echo $acima_fundo; ?>" text="<?php echo $acima_texto; ?>" marginwidth="0" marginheight="0" topmargin="0" leftmargin="0" noresize>
<table width="99%" height="80" border="0" align="center">
  <tr valign="middle"> 
    <td align="center"><a href="http://www.mundohartz.com/" target="_blank"><img src="http://www.mundohartz.com/imagens/banner1.gif" width="468" height="60" border="0"></a></td>
    <form name="formulario">
      <td> <?php echo $fonte; ?> 
        <input type="checkbox" name="tocarsom" onclick="top.soundstatus(this)">
        Tocar som<br> <input type="checkbox" name="rolagem" onclick="top.mudarrolagem()">
        Rolagem autom&aacute;tica<br> </td>
    </form>
  </tr>
</table>
<script>

if(top.soundflag != null)
  document.formulario.tocarsom.checked = (top.soundflag == 1);
else
  document.formulario.tocarsom.checked = true;

document.formulario.rolagem.checked = top.rolagem;
</script>
</body>
</html>