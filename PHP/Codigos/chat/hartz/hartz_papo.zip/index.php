<?
###############################################
## Sistema de Bate-Papo Mundo Hartz Company  ##
## Ver. 1.0								     ##
###############################################
##  Criado por: Leonardo Rossel (mr. hartz)  ##
##  E-mail: leo@mondohartz.com               ##
###############################################

require('config.php');

sql();

$sql = "select count(*) as total from usuario";
$consulta = mysql_query($sql);
$resultado = mysql_fetch_array($consulta);
$total = $resultado[total];

?>
<html>
<head><title><? echo $titulo; ?></title><link rel="stylesheet" href="estilo.css" type="text/css"></head>
<script>

function foco() {
  if(document.formulario.apelido != null)
    document.formulario.apelido.focus();
}

</script>
<body bgcolor="<? echo $index_fundo; ?>" text="<? echo $index_texto ?>" onload="foco()">
<div align="center"><a href="http://www.mundohartz.com/" target="_blank"><img src="http://www.mundohartz.com/imagens/banner1.gif" width="468" height="60" border="0"></a> 
</div>
<form action="entrar.php" method="post" name="formulario">
  <table width="35%" border="0" align="center" cols="3">
    <?php

$sql = "select * from cor";
$consulta = mysql_query($sql);
while($resultado = mysql_fetch_array($consulta)) {
  $cor[id][]    = $resultado[id];
  $cor[texto][] = $resultado[texto];
  $cor[cor][]   = $resultado[cor];
}

if($cor) {

  echo "<tr>\n";
  echo "  <td colspan=\"3\">" . $fonte . "Selecione uma cor:</td>\n";
  echo "</tr>\n";
  echo "<tr>\n";
  echo "  <td colspan=\"3\">$fonte<input type=\"radio\" name=\"cor\" value=\"\" onclick=\"foco()\" checked>Sem cor</td>\n";
  echo "</tr>\n";
  for($i = 0; $i < sizeof($cor[id]);) {
    echo "<tr>\n";
    for($j = 0; $j < 3; $j++, $i++) {
      echo "  <td>";
      if($cor[id][$i])
        echo "$fonte<input type=\"radio\" name=\"cor\" value=\"" . $cor[id][$i] . "\" onclick=\"foco()\"><b><font color=\"" . $cor[cor][$i] . "\">" . $cor[texto][$i] . "</b>";
      echo "</td>\n";
    }
    echo "</tr>\n";
  }

  echo "<p>\n";

}

?>
    <tr> 
      <td colspan="3"><?php echo $fonte; ?>Digite um apelido:</td>
    </tr>
    <tr> 
      <td colspan="2"><input type="textbox" name="apelido" maxlength="20"></td>
      <td><input type="submit" value="Entrar"></td>
    </tr>
    <p> 
    <tr> 
      <td colspan="3"><?php echo $fonte; ?>N&uacute;mero de usu&aacute;rios na 
        sala: <?php echo $total; ?></td>
    </tr>
    <tr align="center"> 
      <td colspan="3"> 
        <hr size="1"> <font class="texto_simples"> <a href="mailto:contato@mundohartz.com">contato@mundohartz.com</a> 
        | <a href="mailto:webmaster@mundohartz.com">webmaster@mundohartz.com</a> 
        <br>
        Mundo Hartz Company 2003 Todos os direitos reservados</font></td>
    </tr>
  </table>
</form>
</body>
</html>
