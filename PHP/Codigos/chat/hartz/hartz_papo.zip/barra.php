<?
###############################################
## Sistema de Bate-Papo Mundo Hartz Company  ##
## Ver. 1.0								     ##
###############################################
##  Criado por: Leonardo Rossel (mr. hartz)  ##
##  E-mail: leo@mondohartz.com               ##
###############################################

if(! $id || ! $apelido)
  header('Location: index.php');

require('config.php');

sql();

$cor = verificar($id, $apelido);

if($para && $acao > 16) {
  $sql = "select apelido from usuario where apelido = '$para'";
  $consulta = mysql_query($sql);
  $resultado = mysql_fetch_array($consulta);
  if($resultado[apelido] != "")
    switch($acao) {

      case 17:
        mysql_query("insert into mensagem values('','$apelido','TODOS','$acao','$cor','','','Falando somente com $para','1','$hora')");
        break;
      case 18:
        mysql_query("insert into mensagem values('','$apelido','TODOS','$acao','$cor','','','Ignorando $para','1','$hora')");
        break;
      case 19:
        mysql_query("insert into mensagem values('','$apelido','TODOS','$acao','$cor','','','N&atilde;o mais ignorando $para','1','$hora')");
        break;
    }

}

elseif(! $para && $acao == 19)
  mysql_query("insert into mensagem values('','$apelido','TODOS','$acao','$cor','','','N&atilde;o mais ignorando TODOS','1','$hora')");

elseif($msg) {

  $msg = strip_tags($msg);

  if($para) {
    $sql = "select apelido from usuario where apelido = '$para'";
    $consulta = mysql_query($sql);
    $resultado = mysql_fetch_array($consulta);
    if($resultado[apelido] != "")
      mysql_query("insert into mensagem values('','$apelido','$para','$acao','$cor','$imagem','$som','$msg','$reservado','$hora')");
  }

  else
    mysql_query("insert into mensagem values('','$apelido','TODOS','$acao','$cor','$imagem','$som','$msg','','$hora')");

}

?>
<html>
<link rel="stylesheet" href="estilo.css" type="text/css">
<script>

function foco() {
  if(document.formulario.msg != null)
    document.formulario.msg.focus();
}

</script>
<body bgcolor="<?php echo $barra_fundo; ?>" text="<?php echo $barra_texto; ?>" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" onload="foco()" noresize>
<center>
<form action="barra.php" method="post" name="formulario">
<table cols="5" width="85%" border="0">
<tr align="center">
  <td><b><?php echo $fonte . $apelido; ?></b></td>
  <td>
    <select name="acao">
      <option value="">fala para</option>
      <option value="1">pergunta para</option>
      <option value="2">responde para</option>
      <option value="3">concorda com</option>
      <option value="4">discorda de</option>
      <option value="5">desculpa-se com</option>
      <option value="6">surpreende-se com</option>
      <option value="7">murmura para</option>
      <option value="8">sorri para</option>
      <option value="9">suspira por</option>
      <option value="10">flerta com</option>
      <option value="11">entusiasma-se com</option>
      <option value="12">ri de</option>
      <option value="13">d&aacute; um fora em</option>
      <option value="14">briga com</option>
      <option value="15">grita com</option>
      <option value="16">xinga</option>
      <option></option>
      <option value="17">falar somente com
      <option value="18">IGNORAR
      <option value="19">n&atilde;o mais IGNORAR
    </select>
  </td>
  <td>
    <select name="para">
      <option value="">TODOS</option>
<?php

$sql = "select * from usuario order by apelido";
$consulta = mysql_query($sql);
while($resultado = mysql_fetch_array($consulta))
  if($resultado[apelido] != $apelido) {
    echo "      <option value=\"$resultado[apelido]\"";
    if($para == $resultado[apelido])
      echo " selected";
    echo ">$resultado[apelido]</option>\n";
  }

?>
    </select>
  </td>
  <td>
    <select name="imagem">
      <option selected>enviar imagem:</option>
<?php

$sql = "select id, texto from imagem";
$consulta = mysql_query($sql);
while($resultado = mysql_fetch_array($consulta))
  echo "      <option value=\"$resultado[id]\">$resultado[texto]</option>\n";

?>
    </select>
  </td>
  <td>
    <select name="som">
      <option selected>enviar som:</option>
<?php

$sql = "select id, texto from som";
$consulta = mysql_query($sql);
while($resultado = mysql_fetch_array($consulta))
  echo "      <option value=\"$resultado[id]\">$resultado[texto]</option>\n";

?>
    </select>
  </td>
</tr>
<tr align="center">
  <td><input type="button" onclick="window.top.location='sair.php<?php echo "?id=$id&apelido=" . urlencode($apelido); ?>'" value="Sair"></td>
  <td><input type="checkbox" name="reservado" value="1"<?php if($reservado == 1) echo " checked"; ?>><?php echo $fonte; ?> reservadamente</td>
  <td colspan="2"><input type="textbox" name="msg" maxlength="500" size="50"></td>
  <td><input type="submit" value="Enviar"></td>
</tr>
</table>
<input type="hidden" name="id" value="<?php echo $id; ?>">
<input type="hidden" name="apelido" value="<?php echo $apelido; ?>">
</form>
</body>
</html>
