<?
###############################################
## Sistema de Bate-Papo Mundo Hartz Company  ##
## Ver. 1.0								     ##
###############################################
##  Criado por: Leonardo Rossel (mr. hartz)  ##
##  E-mail: leo@mondohartz.com               ##
###############################################

if(! $id || ! $apelido)
  header('Location: index.php');

ignore_user_abort(true);
set_time_limit(0);

require('config.php');

sql();

verificar($id, $apelido);

?>
<html>
<script language="Javascript1.1">

var frolagemOn;
var frolagemOff;

function rolarJanela() {
  if(top.rolagem) {
    this.scroll(0, 65000);
    setTimeout('rolarJanela()', 200);
  }
}

function ativarRolagem() {
  top.rolagem = true;
  rolarJanela();
}

function desativarRolagem() {
  top.rolagem = false;
}

function iniciarRolagem() {
  this.onblur  = frolagemOn;
  this.onfocus = frolagemOff;
  rolarJanela();
}

frolagemOn = new Function('ativarRolagem()');
frolagemOff = new Function('desativarRolagem()');

iniciarRolagem();

</script>
<link rel="stylesheet" href="estilo.css" type="text/css">
<body bgcolor="<?php echo $corpo_fundo; ?>" text="<?php echo $corpo_texto; ?>" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<?php

$sql = "select count(*) as total from mensagem where reservado = '0' or de = '$apelido' or para = '$apelido'";
$consulta = mysql_query($sql);
$resultado = mysql_fetch_array($consulta);
$total = $resultado[total];

if($total > $mostrar)
  $linha = $total - $mostrar;
else
  $linha = 0;

for($j = 0; $j < 10; $j++)
  echo "<!-- Isto � um coment�rio. -->\n";

while(! connection_aborted()) {

  $sql = "select mensagem.id as id, mensagem.de as de, mensagem.para as para, mensagem.acao as acao, mensagem.msg as msg, mensagem.reservado as reservado, mensagem.hora as hora, cor.cor as cor, imagem.arquivo as imagem, som.arquivo as som from mensagem left join cor on mensagem.cor = cor.id left join imagem on mensagem.imagem = imagem.id left join som on mensagem.som = som.id where (mensagem.reservado = '0' or mensagem.de = '$apelido' or mensagem.para = '$apelido') limit $linha, 5";

  $consulta = mysql_query($sql);
  while($resultado = mysql_fetch_array($consulta)) {

    $linha++;

    if($somente && strcmp($resultado[de], $apelido) && strcmp($resultado[de], $somente))
      continue 2;

    if($ignorar)
      for($l = 0; $l < sizeof($ignorar); $l++)
        if(strcmp($ignorar[$l], $resultado[de]) == 0)
          continue 3;

    if($resultado[de] == $apelido && $resultado[acao] > 16)
      switch($resultado[acao]) {
        case 17:
          $somente = substr($resultado[msg], 20);
          unset($ignorar);
          break;
        case 18:
          $ignorar[] = substr($resultado[msg], 10);
          break;
        case 19:
          if(strcmp($resultado[de], "TODOS"))
            unset($somente);
          else
            for($m = 0; $m < sizeof($ignorar); $m++)
              if(strstr($ignorar[$m], substr($resultado[msg], 26))) {
                array_splice($ignorar, $m, 1);
                break;
              }
          break;
      }

    if($resultado[de] == $apelido || $resultado[para] == $apelido)
      echo "<table bgcolor=\"$msg_fundo\" width=\"100%\" cellspacing=\"0\" border=\"0\"><tr><td>";

    echo $fonte;
 
    echo "&nbsp;<small>($resultado[hora])</small> ";

    if($resultado[cor] != "")
      echo "<b><font color=\"$resultado[cor]\">";

    echo $resultado[de];

    if($resultado[cor] != "")
      echo "</font></b>";

    if($resultado[reservado] == 1 && $resultado[acao] < 17)
      echo " reservadamente ";

    if(! ($resultado[acao] == 0 && strcmp($resultado[para], "TODOS") == 0) && $resultado[acao] < 17) {

      echo " ";
      switch($resultado[acao]) {
        case 0:
          echo "fala para";
          break;
        case 1:
          echo "pergunta para";
          break;
        case 2:
          echo "responde para";
          break;
        case 3:
          echo "concorda com";
          break;
        case 4:
          echo "discorda de";
          break;
        case 5:
          echo "desculpa-se com";
          break;
        case 6:
          echo "surpreende-se com";
          break;
        case 7:
          echo "murmura para";
          break;
        case 8:
          echo "sorri para";
          break;
        case 9:
          echo "suspira por";
          break;
        case 10:
          echo "flerta com";
          break;
        case 11:
          echo "entusiasma-se com";
          break;
        case 12:
          echo "ri de";
          break;
        case 13:
          echo "d&aacute; um fora em";
          break;
        case 14:
          echo "briga com";
          break;
        case 15:
          echo "grita com";
          break;
        case 16:
          echo "xinga";
          break;
      }

      echo " ";
      echo $resultado[para];

    }

    echo ": ";

    if($resultado[imagem] && $resultado[acao] < 17)
      echo "<img src=\"arquivo/imagem/$resultado[imagem]\"> ";

    echo $resultado[msg];

    if($resultado[som] && $resultado[acao] < 17)
      echo "<script>onerror=null; top.playsound('$resultado[som]')</script>";

    if($resultado[de] == $apelido || $resultado[para] == $apelido)
      echo "</td></tr></table>";

    echo "<p>\n";

  }

  flush();
  usleep(500000);
 
}

mysql_query("delete from usuario where id = '$id' and apelido = '$apelido'");

?>
