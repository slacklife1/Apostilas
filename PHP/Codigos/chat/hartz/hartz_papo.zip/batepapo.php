<?
###############################################
## Sistema de Bate-Papo Mundo Hartz Company  ##
## Ver. 1.0								     ##
###############################################
##  Criado por: Leonardo Rossel (mr. hartz)  ##
##  E-mail: leo@mondohartz.com               ##
###############################################

if(! $id || ! $apelido)
  header('Location: index.php');

require('config.php');

sql();

verificar($id, $apelido);

$apelido = urlencode($apelido);

?>
<html>
<script language="Javascript1.1">

var soundflag = false;
var rolagem = false;
var browser = navigator.userAgent.toLowerCase();
var bIe = (top.browser.indexOf("msie") != -1);

function soundstatus(tocarsom) {
  if(tocarsom.checked)
    soundflag = true;
  else
    soundflag = false;
}

function playsound(som) {
  if(top.soundflag) {
    hiddensound = 'arquivo/som/' + som;
    if(! top.bIe)
      top.corpo.document.write('<embed src=' + hiddensound  + 'autostart=true hidden=true>');
    else
      top.corpo.document.write('<bgsound src=' + hiddensound + '>');
  }
}

function playmid(mid) {
  if(top.soundflag && mid!='') {
    if(top.bIe)
      umid = '<embed height="25"';
    else
      umid = '<embed height="14"';
    umid += ' width="49" controls=smallconsole autostart=false src="';
    umid += mid;
    umid += '">';
    top.corpo.document.write(umid);
  }
}

function mudarrolagem() {
  if(rolagem == true) {
    rolagem = false;
    top.corpo.clearTimeout();
    top.corpo.usarrolagem = false;
    top.corpo.onblur = top.corpo.frolagemOff;
  }
  else {
    rolagem = true;
    top.corpo.usarrolagem = true;
    top.corpo.onblur = top.corpo.frolagemOn;
    top.corpo.scroll(0, 65000);
    top.corpo.setTimeout('rolarJanela()', 200);
  }
}

</script>
<head><title><?php echo $titulo; ?></title></head>
<frameset rows="*,70%,*" border="0" framespacing="10" frameborder="0">
<frame src="acima.php<?php echo "?id=$id&apelido=$apelido"; ?>" scrolling="no" name="acima" noresize>
<frame src="corpo.php<?php echo "?id=$id&apelido=$apelido"; ?>" scrolling="yes" name="corpo" noresize>
<frame src="barra.php<?php echo "?id=$id&apelido=$apelido"; ?>" scrolling="no" name="barra" noresize>
</frameset><noframes></noframes>
</html>
