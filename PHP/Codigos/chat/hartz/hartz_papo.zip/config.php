<?
###############################################
## Sistema de Bate-Papo Mundo Hartz Company  ##
## Ver. 1.0								     ##
###############################################
##  Criado por: Leonardo Rossel (mr. hartz)  ##
##  E-mail: leo@mondohartz.com               ##
###############################################

function sql($endereco = "localhost", $usuario = "", $senha = "", $banco = "") {

  mysql_pconnect($endereco, $usuario, $senha) or die ("N�o consegui conectar!");
  mysql_select_db($banco) or die ("N�o consegui conectar ao banco de dados!");

}

$titulo = "Bate-Papo Mundo Hartz Company";

$index_texto = "#000000"; // Cor do texto da p�gina inicial do sistema.
$index_fundo = "#EAE8E8"; // Cor de fundo da p�gina inicial do sistema.

$acima_texto = "#ffffff"; // Cor do texto do frame superior.
$acima_fundo = "#065db4"; // Cor de fundo do frame superior.

$corpo_texto = "#000000"; // Cor do texto do frame do centro.
$corpo_fundo = "#ffffff"; // Cor de fundo do frame do centro.

$msg_fundo = "#EAE8E8"; // Cor de fundo da mensagem que voc� escreve.

$barra_texto = "#ffffff"; // Cor do texto do frame inferior.
$barra_fundo = "#065db4"; // Cor de fundo do frame inferior.

$fonte = "<font class=\"verdana12\">"; // Fonte e tamanho padr�o.

$mostrar = 5; // Quantidade de mensagens que aparecem quando voc� entra na sala.
$sala = 20; // N�mero m�ximo de pessoas na sala.

$hora = date('H:i:s'); // Formato da hora.

function verificar($id, $apelido) {

  $sql = "select apelido, cor from usuario where id = '$id' and apelido = '$apelido'";
  $consulta = mysql_query($sql);
  $resultado = mysql_fetch_array($consulta);
  if($resultado[apelido] == "")
    header('Location: index.php');
  else
    return($cor = $resultado[cor]);

}
?>