<?php

	// -- O caminho do banco de dados 

	$site = "lab";
	$nomeSite = "LAB on Line";
	
	$urlSite = "http://www.labdesign.d2g.com";
	$SMTPserver = "smtp.seuservidor.com.br";
	$webmaster = "seu.email@seuservidor.com.br";
	
	$host = "192.168.0.3";
	$dataBase = "lab";
	$userDB = "lab";
	$pwdDB = "lab089200";
	
	$dirImages = "$urlSite/images/";
		
	$dirRaiz = "c:\\apache\htdocs";
	$edit=2;
	$insert=1;	

?>