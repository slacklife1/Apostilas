<?
include("global.php");
$grupo = $HTTP_GET_VARS["grupo"];
if ($grupo == "") {
	$grupo = $HTTP_POST_VARS["grupo"];
}
$acao = $HTTP_GET_VARS["acao"];
$id = $HTTP_GET_VARS["id"];
?>
<head>
<title></title>
<link rel="stylesheet" href="style.css" type="text/css">
</head>

<body topmargin="0" leftmargin="0">
<table width="775" cellspacing="0" cellpadding="0">
	<tr>
		<td class="tdMenu" valign="top">
			<? include("menu.html") ?>
		</td>
		<td width="460" valign="top">
			<? if ($acao != "") {
					if ($acao=="red") {
						include("red.php"); }
					else
						{ include("insert.php"); }
					}
				elseif ($grupo != "") {
					include("forum.php"); }
				else {
					include("home.html"); }
			?>
		</td>
	</tr>
</table>
</body>
</html>