<?
// Pagina Prepara email de resposta do forum

include("global.php");
// Pagina Resposta de Anuncios
$id = $HTTP_GET_VARS["id"];

$acao = $HTTP_GET_VARS["acao"];

// Abre conexao com banco de dados. Alterar a string de conexao em global.asa
$sql = "SELECT email, nome, data FROM forum where id_forum=$id";

// Conexao com o banco de dados atrav�s da API mysql.php

$conn = mysql_connect($host, $userDB, $pwdDB);
mysql_select_db($dataBase);

// Abre tabela de forum usando a conexao aberta acima.
$query = mysql_query($sql,$conn);
$result = mysql_fetch_array($query);

$ano = substr($result["data"],0, 4);
$mes = substr($result["data"],4, 2);
$dia = substr($result["data"],6, 2);
$data = "$dia/$mes/$ano";
$nameto = $result["nome"];
$mailto = $result["email"];

$mailfrom = trim(strtolower($mailfrom));
$namefrom = trim($namefrom);
$subject = trim($subject);

if (isset($submit)) {
	// formulario foi submetido entao prepara o e-mail para envio
	
	error_reporting(E_ALL);
	include("mail/htmlMimeMail.php");
	
	// prepara o corpo da mensagem e chama a funcao sendmail()
	
	$mes = date("m");
	$dia = substr(date("0d/"), -3);	
	$ano = date("/Y");
	$fdata = "$dia$mes$ano";

	
	$body = "<table border=0 cellspacing=5 cellpadding=5 width=565 class=menu>";
	$body .= "<tr><td align=center colspan=2><b>LAB - F�RUM DE DEBATES</b></td></tr>";	
	$body .= "<tr><td colspan=2>Ol� <b>$nameto</b>, $namefrom entrou em nosso portal e enviou uma mensagem referente � sua opini�o postada em nosso de F�rum de Debates.<br>Caso queira respond�-lo, clique no campo <b>e-mail</b> abaixo!</td></td></tr>";
	
	$body .= "<tr><td class=boxborder align=right>Data:</td><td bgcolor=#ffffff class=boxborder><b>$fdata</b></td></tr>";

	$body .= "<tr><td class=boxborder align=right>De:</td><td bgcolor=#ffffff class=boxborder><b>$namefrom</td></tr>";

	$body .= "<tr><td class=boxborder align=right>E-mail:</td><td bgcolor=#ffffff class=boxborder><a href=\"mailto:$mailfrom\">$mailfrom</a></td></tr>";

	$body .= "<tr><td valign=top class=boxborder align=right>Assunto:</td><td bgcolor=#ffffff class=boxborder>$subject</td></tr>";	
	$body .= "</table>";
	
	$mailsend = sendMail($mailto, $namefrom, $mailfrom, 'LAB - F�rum de Debates', $body);

?>
<head>
<title></title>
<link rel="stylesheet" href="style.css" type="text/css">
</head>
<body topmargin=0 leftmargin=0>
	<table border="0" cellpadding="2" width="100%" class="boxborder">
		<tr>
			<td bgcolor="#000050" width=60>
				<img src="../includes/images/logolab_topo.gif" border="0" width="60"></td>
			<td align"center" class="tmenu"><?= $mailsend ?></td></tr>
	</table><br>
	<table border="0" width="100%" class="boxborder" bgcolor="#efefef">
		<tr height="50">
			<td align="center">Caro(a) <font color=indigo size=+1><b><?= $namefrom ?></b></font>,<br><br>
			 	Seu E-mail foi enviado com sucesso.</b></font></td></tr>		
		<tr height="50">
			<td align="center"><font size="2"><b>Obrigado por utilizar nossos servi�os!</b></font></td></tr>
		<tr height="30"><td align="center">Se ficou satisfeito, indique-nos para seus amigos.</td></tr>
	</table><?
	}
else { ?>

	<!-- entrada do formulario -->
	<script language="JavaScript">

	<!--//
		function Validator(theForm) {

			if (theForm.namefrom.value == "") {
				alert("Preencha o campo NOME:");
				theForm.namefrom.focus();
				return (false); }

			if (theForm.mailfrom.value == "") {
				alert("Preencha o campo E-MAIL");
				theForm.mailfrom.focus();
				return (false); }

			if (theForm.subject.value == "") {
				alert("Preencha o campo ASSUNTO");
				theForm.subject.focus();
				return (false); }

		  return (true); }
	// -->
	</script>
<head>
<title></title>
<link rel="stylesheet" href="style.css" type="text/css">
</head>
<body topmargin=0 leftmargin=0>
	<table border="0" cellpadding="2" width="95%" class="boxborder" align="center">
		<tr>
			<td bgcolor="#000050" width="60" border="0" width="60" rowspan="2">
				<img src=" ../includes/images/logolab_topo.gif" width=60></td>
			<td align"center" class="tmenu">F�rum de Debates</td>
		<tr bgcolor="#efefef">
			<td align"center" align="center">Preencha o formul�rio abaixo e pressione enviar. Obrigado!</td>
	</table>
	

	<form action="#" method="POST" name="contato" onsubmit="return Validator(this)">
		<table border="0" cellpadding="2" width=95%" align="center" class=boxborder>
			<tr bgcolor="#efefef"><td align="right">Nome:</td>
				<td><input type="text" size="30" name="namefrom" class="box"></td></tr>

			<tr bgcolor="#efefef"><td align="right">E-Mail:</td>
				<td><input type="text" size="30" maxlength="255" name="mailfrom" class="box"></td></tr>

			<tr bgcolor="#efefef"><td align="right" valign="top">Assunto:</td>
				<td><textarea name="subject" rows="5" cols="50" class="box"></textarea></td></tr>

			<tr height="35" bgcolor="#efefef"><td align="center" valign="middle" colspan="2">
				<input type="submit" name="submit" value="Enviar" class="but"></td></tr>

		</table>
	</form><?
	}
?>	