<?

// Pagina de Forum




// Checa numero da pagina
$pagesize = 15;

$pagAtual = $HTTP_POST_VARS["pagAtual"];

if ($pagAtual == "") {
	$pagAtual = 0; }
	
$dir = $HTTP_POST_VARS["dir"];	

if ($grupo != "") {
    $sql = "SELECT * FROM forum WHERE id_grupo=$grupo and id_resposta=0 order by data desc";
    }
else  {
    $sql = "SELECT * FROM forum where id_resposta=0 order by data desc";
    }

// Conexao com o banco de dados atrav�s da API mysql.php
$conn = mysql_connect($host,$userDB, $pwdDB);
mysql_select_db($dataBase);
$query = mysql_query($sql,$conn);
$maxRec = mysql_num_rows($query);
$maxPage = $maxRec / $pagesize;
$maxPage = (int)$maxPage;

// Fim da conexao
?>

<script language="JavaScript">

  function ler_Anuncio(idx){
        newWin = window.open("ver_anuncio.php?id="+idx,"winNew","toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,left=0,top=0,width=400,height=250");
        newWin.location.href = "ver_anuncio.php?id="+idx;
  }
</script>

<table border="0" width="465">
    <tr>
        <td align="center" width="100%" class="tmenu">Grupo de Discuss�es</td>
    </tr>
    <tr>
        <td align="center"><font class="normal">Clique na quest�o para mais detalhes <b>[Total de: <?= $maxRec ?> registros]</b></td>
    </tr>
</table> 
<table border="0" cellpadding="1" width="465" bgcolor="#ffffff">
    <tr>
        <td class="menu" align="center" width=100><b>Data:</b></td>
        <td class="menu" align="center"><b>T�tulo:</b</td>
        <td class="menu" align="center" width=20><b>Resp.:</b></td>
    </tr>
   <?
// Checa se existem Piadas no banco de dados

if (!$maxRec) {
?>
    <tr>
        <td colspan="3" align="center"><b>Ainda n�o h� Perguntas para esse tema<br>
        	<a href="index.php?acao=insert&grupo=<?= $grupo ?>">Insira voc� a sua!</b></a></td>
    </tr>
    <?	}
else	{

	 if ($dir=="Pr�ximo") {
		  if ($pagAtual < $maxRec) {
				 $pagAtual++; }
		 }
	  elseif ($dir =="Anterior") {
		  if ($pagAtual > 0) {
				$pagAtual = $pagAtual - 1;	}
		}
		
		$counter = 0;
		$offset = $pagAtual*$pagesize;
	
		mysql_data_seek($query, $offset);
		
	While ($counter < $pagesize && $counter+$offset < $maxRec)  {
		if (is_int($counter/2))
			echo "<tr>";
		else
			echo"<tr bgcolor=#efefef>";
		$result = mysql_fetch_array($query);
		$data = "";
		$data = substr($result["data"], 0, 8);		
		if (strlen($data) > 0)				
			$data = substr($data, -2) . "/" . substr($data, 4, 2) . "/" . substr($data, 0, 4);
		else	$data ="&nbsp;";
		$id_forum = $result["id_forum"];
		
		echo "<td align=center>$data</td>\n";
		echo "<td><a href=\"index.php?id=$id_forum&acao=red&grupo=$grupo\">" . $result["titulo"] . "</a></td>\n";
      echo "<td align=center>" . $result["hits"] . "</td>\n";
      echo "</tr>\n";        
      $counter ++;
		}	// while
?>
	</table>
	<table width="465">
		<tr>
			<td align="center" valign="middle" width="50%"><a href="index.php?acao=insert&grupo=<?= $grupo ?>">Inserir Pergunta</a></td>
<?		
				echo "<form action=\"index.php\" method=\"POST\">\n";
				echo "<td valign=middle width=\"25%\">";
				if ($pagAtual > 0) {
				  echo "<INPUT type=\"submit\" value=\"Anterior\" name=dir class=but>"; }

				  echo "</td>";
				echo"<td valign=middle width=\"25%\">";
				if ($pagAtual < $maxPage) {
				  echo "<INPUT type=\"submit\" value=\"Pr�ximo\" name=dir class=but>"; }
				 echo"</td></td>";

				echo "<INPUT type=hidden name=\"pagAtual\" value=\"$pagAtual\">\n";
				echo "<INPUT type=hidden name=\"grupo\" value=$grupo>\n";
				echo "</form>";   }
?>
	</td>
    </tr>
</table>
<?
	mysql_free_result($query);
	mysql_close($conn);
?>	