** Este forum esta funcionamento em meu portal www.labdesign.d2g.com
*	Ele foi adaptdado por mim de um outro forum em ASP
*  Sofreu v�rias altera��es at� chegar neste formato que acredito ser o mais adequado
*  em se tratando de portais.
*  Em anexo inclui a pasta mail com scripts para envio de e-mail
*  Sua implementa��o � bastante simples.
*  Copie a pasta phpforum para dentro do seu site
*  Caso deseje utilizar o sistema mail em outras paginas,
*  mova a pasta para o mesmo nivel da pasta phpforum
*  e ajuste os script que fazem uso desse m�dulo
*
*  Modifique o arquivo global.php apontado para o seu servidor e a base de dados
*
*  Crie a tabela Forum na sua base de dados
*
*  crie os campos da tabela forum:
*  id_forum		mediumint(9)				PRI  auto_increment
*  id_grupo		mediumint(9)	not null
*  id_resposta	mediumint(9)	not null
*  titulo		varchar(255)	not null
*	comentario	text				not null
*  data			timestamp(14)	not null
*  nome			varchar(50)		not null
*  email			varchar(255)	not null
*  hits			mediumint(9)	not null
*
*  este arquivo zip cont�m:
*  \images: imagens utilizadas pelo forum
*  \mail: scripts para envio de e-mail formatado em html
*  forum.frm: tabela de dados (� so arrastar para a sua base de dados se for mysql)
*  forum.myd: tabela de dados (� so arrastar para a sua base de dados se for mysql)
*  forum.myi: tabela de dados (� so arrastar para a sua base de dados se for mysql)
*  forum.php: script que mostra as mensagens postadas
*  global.php: configuracoes globais para o forum e o site
*  home.html: pagina inicial do forum. Voce deve montar uma capa de acordo com seu gosto
*  index.php: monta o forum com menus e principal
*  insert.php: script que insere nova mensagem no forum
*  menu.html: as mensagens sao divididas em grupos
*  pre_mail.php: formulario e envio de e-mail formatado em html
*  readme.txt: este arquivo
*  red.php: script que mostra a mensagem selecionada
*  style.css: tabela de estilo para a pagina
*
*
*  o script pre-mail envia um e-mail formatado em html de quem esta vendo a mensagem
*  para quem postou a mensagem.
*	Nele ha varias referencias de imagens para topo das paginas que voc� deve redefinir
*  Caso tenha alguma dificuldade na instala��o deste m�dulo
*  Passe um e-mail para mim lauro_lab@yahoo.com.br descrevendo o problema.
**