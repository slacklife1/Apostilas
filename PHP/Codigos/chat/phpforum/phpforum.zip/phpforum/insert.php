<?
// Pagina de RS_Forum
// Abre conexao com banco de dados. Alterar a string de conexao em global.asa

$id = $HTTP_GET_VARS["id"];
if ($id == "") {
	$id = 0;
}

$conn = mysql_connect($host, $userDB, $pwdDB);
mysql_select_db($dataBase);

if ($id > 0) {
	// foi passado o id o usuario esta respondendo
	$query = mysql_query("select titulo, id_grupo from forum where id_forum=$id",$conn);
	$questao = mysql_fetch_array($query);
	$grupo = $questao["id_grupo"];
	mysql_free_result($query);
	mysql_close($conn); }

// pagina veio do insere comentario ou resposta
if ($acao=="gravar") {
// o botao enviar foi pressionado
// 	captura dados do formulario

	$conn = mysql_connect($host, $userDB, $pwdDB);
	mysql_select_db($dataBase);

	$nome	= strtoupper(trim($nome));
	$titulo	= trim($titulo);
	$email	= strtolower(trim($email));
	$comentario	= trim($comentario);
	
	$sql="select max(id_forum) as max_id from forum";
	$query = mysql_query($sql, $conn);
	$result = mysql_fetch_array($query);
	
		
	$sql = "insert into forum(nome, email, titulo, comentario, id_resposta, id_grupo, data, hits)";
	$sql .= " values ('$nome','$email','$titulo','$comentario',$id,$grupo,now(), 0)";;
	
	mysql_query($sql, $conn);
	
	if ($id != "") {
		$sql="update forum set hits=hits+1 where id_forum=$id";
		mysql_query($sql, $conn);
	}		

	mysql_close($conn);
	$acao ="";
	include("forum.php");
}

elseif ($acao=="insert") { ?>

	<script language="JavaScript">
	<!--
	////

	function valid_resp_form() {

		var form
		form = document.comentario;

		if (form.nome.value == "") {
			alert("Por digite o seu nome !");
			form.nome.focus();
			return false;	}

		if (form.email.value == "") {
			alert("Por digite o seu email !");
			form.email.focus();
			return false;	}

		if (form.titulo.value == "") {
			alert("Por digite um t�tulo para o seu coment�rio!");
			form.titulo.focus();
			return false; }

		if (form.comentario.value == "") {
			alert("Por digite o seu coment�rio !");
			form.comentario.focus();
			return false; }

	  return true;
	}

	// -->
	</script>

	<form action="index.php?acao=gravar&id=<?= $id ?>" method="POST" name="comentario" onsubmit="return valid_resp_form();">
	<input type="hidden" name="grupo" value="<?= $grupo ?>">
	<table border="0" cellpadding="0" cellspacing="0" width="450">
		<tr>
			<td align="center">
			<b>ATEN��O:</b><br>
				As mensagens postadas neste F�rum s�o de responsabilidade<br>
				do pr�prios usu�rios. Isentamo-nos de quaisquer responsabilidades<br>
				sobre as mensagens aqui postadas.
			</td>
		</tr>
	</table>
	<table border="0" cellpadding="2" cellspacing="1" width="100" bgcolor="c0c0c0">
		<tr class="tr1">
			<td class="tdfield"><b>Quest�o:&nbsp;</b></td>
			<td><font color=red><b><?= $questao["titulo"] ?>&nbsp;</b></font></b></td>
			</tr>	
		<tr class="tr1">
			<td class="tdfield"><b>Nome:&nbsp;</b></td>
			<td>
				<input type="text" size=50 name="nome" value="<?= $nome ?>" class="box"></td>
			</tr>
		<tr class="tr1">
			<td class="tdfield"><b>E-Mail:&nbsp;</b></td>
			<td>
				<input type="text" size=50 name="email" value="<?= $email ?>" class="box"></td>
			</tr>
		<tr class="tr1">
			<td class="tdfield"><b>T�tulo:&nbsp;</b></td>
			<td>
				<input type="text" size=50 name="titulo" value="<?= $titulo ?>" class="box"></td>
			</tr>
		<tr class="tr1">
			<td class="tdfield" valign="top"><b>Coment�rio:&nbsp;</b></td>
			<td valign="top">
				<textarea name="comentario" cols="55" rows="5" class="box" value="<?= $comentario ?>"></textarea></td>
			</tr>
		<tr class="tr1">
			<td></td>
			<td align="center"><input type="submit" value="Enviar Coment�rio" name="enviar" class="but"></td>
		</tr>
	</table><? 
}
?>