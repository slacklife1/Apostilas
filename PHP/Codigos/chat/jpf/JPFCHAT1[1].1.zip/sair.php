<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>SAIR</title>
</head>

<body>
	
	<script>
		top.location.href="index.php"
	</script>


</body>
</html>
