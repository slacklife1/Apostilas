<? include ("config.inc"); ?>
<body bgcolor="<? echo $bgcolor ?>">

	