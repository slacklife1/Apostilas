
<html>
	<head>
		<title>:: JPFCHAT ::</title>
	
	</head>

	<body bgcolor="white">
		<form action="index2.php" method="post">
		<font color=black size=2 face=arial><b>NICK</b></font>: <input type=TEXT size=10 name=cods maxlength="10">
		<input type=submit value=ENTRAR>
		</form>
	</body>
	</html>

	