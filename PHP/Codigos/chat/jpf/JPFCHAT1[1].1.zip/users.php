<? session_start("CHAT") ?>
<? include ("config.inc"); ?>
<html>
<body>
	<head>
<html>
<head>
<title></title>
<meta http-equiv="REFRESH" content="10" >
</head>
<body bgcolor="gray">

<? $d = dir("$dir/online/"); ?>

<? touch ("$dir/online/$cod") ?>
<table border=0 cellpadding="1" cellspacing="1" width="100%">
<? $num = 0; ?>
<? while($entry=$d->read()) { ?>
    <? if ($entry != "." and $entry != ".."){ ?>
		<? $num = $num + 1; ?>
		<? if ($entry==$cod) { ?>
			<? $fontcolor = "red"; ?>
		<? }else{ ?>
			<? $fontcolor = "black"; ?>
		<? } ?>
		<script>
			function para<? echo $num ?>(){
				top.f.teste.para.value = "<? echo $entry ?>";
				top.f.MM_setTextOfLayer("p","","<? echo $entry ?>&nbsp;&nbsp;<a href='javascript:todos()'>TODOS</a>");
			}	
		</script>
		<tr>
			<td bgcolor="silver">
				<font color=<? echo $fontcolor ?> face=arial size=2><b><? echo "$entry";?></b> <? if ($entry!=$cod){ ?><font size=1><a href="javascript:para<? echo $num ?>()">RES</a></font><? } ?></font><br>
			</td>
		</tr>
	<? } ?>
<? } ?>
</table>
</body>
</html>
