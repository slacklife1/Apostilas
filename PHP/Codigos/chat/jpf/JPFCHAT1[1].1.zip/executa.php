<? while(!connection_aborted()){ ?>
	<? include ("config.inc"); ?>
	<? touch ("$dir/online/$cod") ?>
	<? ignore_user_abort(1); ?>
	<? $size = filesize("$dir/awmchatmsg.tmp"); ?>
	<? if ($sizev==FALSE){ ?>
		<? $sizev = 0 ?>
	<? } ?>
	<? if ($sizev < $size) { ?> 
		<? $linha = file ("$dir/awmchatmsg.tmp"); ?>
	    <? $sizev = $size; ?>
		<? $conta = count($linha);?>
		<? for($i=0;$i<$conta;$i++) {  ?>
		   	<? $campo = explode(':*:#',$linha[$i]); ?>
			<? if ($num==FALSE){ ?>
				<? $campo2 = explode(':*:#',$linha[$conta-2]); ?>
				<? $num = $campo2[6]; ?>
			<? } ?>	
			<? if ($num<$campo[6]){ ?>
				<? $num = $campo[6]; ?>
				<script>
				<? if ($campo[7] == "$cod" AND $campo[0] == "1" AND $campo[8] == "ALL"){ ?>
					top.c.document.write("<body bgcolor='<? echo $bgcolor ?>'><font color=<? echo $fontcolor1 ?> face=<? echo $fontface1 ?> size=1>(<b><? echo $campo[2] ?></b>:<b><? echo $campo[3] ?></b>:<b><? echo $campo[4] ?></b>) <font color=<? echo $fontcolor1 ?> face=<? echo $fontface1 ?> size=<? echo $fontcolor1 ?>><b><? echo $campo[1] ?></b> : <? echo $campo[5] ?></font><p>") ;
				<? }else if ($campo[7] == "$cod" AND $campo[0] == "1"){ ?>
					top.c.document.write("<body bgcolor='<? echo $bgcolor ?>'><font color=<? echo $fontcolor1 ?> face=<? echo $fontface1 ?> size=1>(<b><? echo $campo[2] ?></b>:<b><? echo $campo[3] ?></b>:<b><? echo $campo[4] ?></b>) <font color=<? echo $fontcolor1 ?> face=<? echo $fontface1 ?> size=<? echo $fontcolor1 ?>><b><? echo $campo[1] ?></b> <font color=<? echo $fontcolor1 ?> face=<? echo $fontface1 ?> size=<? echo $fontcolor1 ?>>para <b><i><? echo $campo[8] ?></i></b></font> : <b><? echo $campo[5] ?></b></font><p>") ;
				<? }else if ($campo[0] == "1" AND $campo[7] != "$cod" AND $campo[8] == "ALL"){?>
					top.c.document.write("<body bgcolor='<? echo $bgcolor ?>'><font color=<? echo $fontcolor2 ?> face=<? echo $fontface2 ?> size=1>(<b><? echo $campo[2] ?></b>:<b><? echo $campo[3] ?></b>:<b><? echo $campo[4] ?></b>) <font color=<? echo $fontcolor2 ?> face=<? echo $fontface2 ?> size=<? echo $fontcolor2 ?>><b><? echo $campo[1] ?></b> : <? echo $campo[5] ?></font><p>") ;
				<? }else if ($campo[0] == "1" AND $campo[8] == "$cod"){?>
					top.c.document.write("<body bgcolor='<? echo $bgcolor ?>'><font color=<? echo $fontcolor2 ?> face=<? echo $fontface2 ?> size=1>(<b><? echo $campo[2] ?></b>:<b><? echo $campo[3] ?></b>:<b><? echo $campo[4] ?></b>) <font color=<? echo $fontcolor2 ?> face=<? echo $fontface2 ?> size=<? echo $fontcolor2 ?>><b><? echo $campo[1] ?></b> <font color=<? echo $fontcolor2 ?> face=<? echo $fontface2 ?> size=<? echo $fontcolor2 ?>>para <b><i><? echo $campo[8] ?></i></b></font> : <b><? echo $campo[5] ?></b></font><p>") ;
				<? }else if ($campo[0] == "2"){ ?>
					top.c.document.write("<body bgcolor='<? echo $bgcolor ?>'><font color=<? echo $fontcolor3 ?> face=<? echo $fontface3 ?> size=1>(<b><? echo $campo[2] ?></b>:<b><? echo $campo[3] ?></b>:<b><? echo $campo[4] ?></b>) <font color=<? echo $fontcolor3 ?> face=<? echo $fontface3 ?> size=<? echo $fontcolor3 ?>><b><? echo $campo[1] ?></b> : <? echo $campo[5] ?></font><p>") ;
				<? } ?>
				</script>
			<? } ?>
		<? }  ?> 
		
	<? } ?>
<? clearstatcache(); ?>
<? flush(); ?>	
<?
if (connection_aborted()){
	$arq = fopen("$dir/awmchatmsg.tmp","a+");
	$dia = date("d",time());
	$mes = date("m",time());
	$ano = date("Y",time());
	$hora = date("H", time());
	$minuto = date("i", time());
	$segundo = date("s", time());
	$linha = file ("$dir/awmchatmsg.tmp");
	$conta = count($linha);
	$campo = explode(':*:#',$linha[$conta-1]);
	$ID = $campo[6] + 1;
	fputs($arq,"2:*:#$cod:*:#$hora:*:#$minuto:*:#$segundo:*:#Saiu da sala...:*:#$ID:*:#ALL:*:#ALL:*:#\n");
	exec("rm -r $dir/online/$cod");
	fclose($arq);
	exit();
}
?>
<script>
top.c.window.scrollBy(0,1000000);
</script>
<? usleep(0); ?>	
<? } ?>