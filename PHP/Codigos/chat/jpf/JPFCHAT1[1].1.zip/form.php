<html>
<head>
<title></title>
</head>
<script>
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);

function MM_findObj(n, d) { 
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document); return x;
}

function MM_setTextOfLayer(objName,x,newText) { //v3.0
  if ((obj=MM_findObj(objName))!=null) with (obj)
    if (navigator.appName=='Netscape') {document.write(unescape(newText)); document.close();}
    else innerHTML = unescape(newText);
}
function sair(){
	top.location.href="index.php"
}

</script>

<body bgcolor="Black">
<form target="e" action="envia.php" method="post" name="teste">
<table border="0" cellpadding="2" cellspacing="2" width="100%">
	<tr>
		<td width="50%"><font color=white face=arial size=2>Enviando mensagem para:<b><div id="p">TODOS</div></b></font></td>
		<td><input type="text" size="25" name="teste" align="middle"></td>
		<td><input type="submit" value="enviar"></td>
		<td width="50%" align="right"><input type="button" value="Sair" onclick="sair()"></td>
	</tr>
</table>
<input type="hidden" name="func" value="1">
<input type="hidden" name="para" value="ALL">
</form>
<script>
	function todos(){
		document.teste.para.value = "ALL";
		MM_setTextOfLayer("p","","TODOS");
	}	
</script>
</body>
</html>


