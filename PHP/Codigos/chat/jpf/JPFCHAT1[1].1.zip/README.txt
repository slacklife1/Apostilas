------------------------------------------
AUTOR
------------------------------------------

NOME: JO�O PAULO DE OLIVEIRA FARIA
EMAIL: JOAOPAULO@DEOLIVEIRAFARIA.COM.BR
ICQ: 13041300


------------------------------------------
SOBRE
------------------------------------------

O JPFCHAT ESTA SENDO DESENVOLVIDO A FINS 
DE ESTUDO, QUALQUER UM PODE USA-LO DESDE 
QUE MANTENHA O NOME DO AUTOR NO CHAT.



------------------------------------------
CONFIGURANDO
------------------------------------------

=NO UNIX+APACHE=

1) DESCOMPACTE O ARQUIVO JPFCHATX.X.ZIP.

2) COLOQUE AS DEVIDAS PERMISS�ES .

chown nobody:nobody online/
chown nobody:nobody awmchatmsg.tmp

3) ALTERAR O CONFIG.INC

$dir = "/raiz/path/chat"
$url = "http://www.meudominio.com.br/chat"

4) ALTERAR O HTTPD.CONF DO APACHE.

KeepAlive on


=NO WINDOWS+APACHE=

1) DESCOMPACTE O ARQUIVO JPFCHATX.X.ZIP.

3) ALTERAR O CONFIG.INC

$dir = "C:/raiz/path/chat"
$url = "http://www.meudominio.com.br/chat"

4) ALTERAR O HTTPD.CONF DO APACHE.

KeepAlive on



------------------------------------------
report bugs
------------------------------------------

joaopaulo@deoliveirafaria.com.br
