<? session_start("CHAT") ?>
<? include ("config.inc"); ?>
<html>
<head>
<title></title>
</head>
<body>
<?
	$arq = fopen("$dir/awmchatmsg.tmp","a+");
	$dia = date("d",time());
	$mes = date("m",time());
	$ano = date("Y",time());
	$hora = date("H", time());
	$minuto = date("i", time());
	$segundo = date("s", time());
	$msg = strip_tags($teste);
	if ($msg!=""){
	$linha = file ("$dir/awmchatmsg.tmp");
	$conta = count($linha);
	$campo = explode(':*:#',$linha[$conta-1]);
	$ID = $campo[6] + 1;
	fputs($arq,"1:*:#$cod:*:#$hora:*:#$minuto:*:#$segundo:*:#$msg:*:#$ID:*:#$cod:*:#$para:*:#\n");
	fclose($arq);
	}
?>
<script>
	top.f.document.teste.teste.value = "" ;
</script>
</body>
</html>

