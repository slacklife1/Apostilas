<? session_start("CHAT")?>
<? include ("config.inc"); ?>
	<? $cod = $cods ?>
	<? session_register("cod") ?>
	<? $d = dir("$dir/online/"); ?>
	<? while($entry=$d->read()) { ?>
	    <? if ($entry == $cod or $cod == ""){ ?>
			<script>
				alert("Esse nick j� esta sendo usado");
				location.href("index.php");
			</script>
			<? exit (); ?>
		<? } ?>
	<? } ?>
	<?
			$arq = fopen("$dir/awmchatmsg.tmp","a+");
			$dia = date("d",time());
			$mes = date("m",time());
			$ano = date("Y",time());
			$hora = date("H", time());
			$minuto = date("i", time());
			$segundo = date("s", time());
			$linha = file ("$dir/awmchatmsg.tmp");
			$conta = count($linha);
			$campo = explode(':*:#',$linha[$conta-1]);
			$ID = $campo[6] + 1;
			fputs($arq,"2:*:#$cod:*:#$hora:*:#$minuto:*:#$segundo:*:#Entra na sala...:*:#$ID:*:#\n");
			touch("$dir/online/$cod");
			fclose($arq);
			?>
	<html>
	<head>
		<title><? echo $tit ?></title>
	
	</head>
	<frameset rows="*,50,0,0" border="0" framespacing="0">
	        <frameset cols="*,180" border="0" framespacing="0">
					<frame src="chat.php" name="c" id="c" frameborder="0" scrolling="Auto" noresize marginwidth="0" marginheight="0">
					<frame src="users.php" name="u" id="u" frameborder="0" scrolling="Auto" noresize marginwidth="0" marginheight="0">
			</frameset>		
	        <frame src="form.php" name="f" id="f" frameborder="0" scrolling="no" noresize marginwidth="0" marginheight="0" >
			<frame src="blank.htm" name="e" id="e" frameborder="0" scrolling="no" noresize marginwidth="0" marginheight="0">
			<frame src="executa.php?cod=<? echo $cod ?>" name="x" id="x" frameborder="0" scrolling="no" noresize marginwidth="0" marginheight="0">
	</frameset>
	</body>
	</html>
