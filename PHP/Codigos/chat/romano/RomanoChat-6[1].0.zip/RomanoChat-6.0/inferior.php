<?php
############################ ROMANO CHAT - MySQL #################################
#  Arquivo: inferior.php                                                         #
#  Cria��o: 05/Abril/2004 - 06:36 PM                                             #
#  Vers�o:  6.0 ALPHA 1(?)                                                       #
#  Autores: Comunidade Romano Chat - (Id�ia Original: Rodrigo Romano)            #
##################################################################################
#  Software Distribui��o: http://www.phpbrasil.com                               #
#  Suporte, N�ticias, Atualiza��es em: http://www.phpbrasil.com                  #
#  Software Comunidade: romanochat@yahoogrupos.com.br                            #
##################################################################################
# - Este � um programa gr�tis; podendo ser redistribuido e modificado, desde de  #
#  que n�o se retire os cr�ditos iniciais dos autores.                           #
# - Este programa tamb�m vem SEM NENHUMA GARANTIA, e tudo � por sua conta e      #
#  risco ao usa-lo voc� ficara respons�vel por tudo; insentado os autores.       #
# - Para mais informa��es leia o arquivo "licenca.txt", no diret�rio principal.  #
##################################################################################

/**
 * @@@ Arquivo de Templante: 'inferior.htm' @@@@
 * Inclui os arquivos iniciais nesses�rios.
**/
include_once("./config.php");
include_once("./global.php");
include_once("./biblioteca/fasttemplate.php");

/**
 * Inicia o banco de dados.
 * Seleciona os dados do usu�rio.
 * Bani o Usu�rio se for indevido.
**/
$banco = new chat;
$banco->dados($uid);
$banco->block($uid);

/**
 * Verifica as datas para exibi��es.
 * Verifica se � o primeio acesso � p�gina.
 * Enviando o Cabe�alho da p�gina 'principal.htm'
 * Para ficar tudo nos comformes ....
**/
if (empty($date_session)) {
 $date_session = date("Y-m-d H:i:s", $tempo-350);
 session_register("date_session");
}

if (empty($header_session) OR $header_session != $uid) {
 $arquivo = "./templates/$modelo/principal.htm";
 $header = fopen($arquivo, "r");
 $lido = fread($header, filesize($arquivo));
 fclose($header);
 $limpa = addslashes($lido)."\n\n";
 $limpa = str_replace("\t", "", $limpa);
 $limpa = str_replace("\r", "", $limpa);
 $limpa = str_replace("\n", "\\n", $limpa);
 $inicio = $limpa;
 $header_session = $uid;
 session_register("header_session");
}

/**
 * Inicia o sistema de templantes.
 * Carrega o arquivo solicitado
**/
$model = new FastTemplate("./templates/$modelo");
$model->define(array("pagina" => "inferior.htm"));

/**
 * Lista as Mensagens e Envia ao JavaScript do Sistema
 * Atuliza a p�gina e conta tudo...
**/
$msgs  = $banco->msgs();
$total = count($msgs);
$cont  = $banco->cont("TODOS");
$str   = $ext = "";
$str  .= (!empty($inicio)) ? $inicio : "";
for ($i = "0"; $i < $total; $i++) {
 $rem  = $msgs[$i]["rem"];
 $dest = $msgs[$i]["dest"];
 $mensagem = addslashes($msgs[$i]["msg"]);
 $som = $msgs[$i]["som"];
 if (empty($ignora[$rem]) && empty($ignora[$dest])) {
  $para = ($dest == $banco->nome) ? ' bgcolor=\"#D0D0D0\"' : "";
  $codigo = '<table width=\"100%\" border=\"0\" cellspacing=\"5\" cellpadding=\"2\"><tr><td'.$para.'>'.$mensagem.'"+PlaySound("'.$som.'")+"</td></tr></table>'."\n";
  $codigo = str_replace("\t", "", $codigo);
  $codigo = str_replace("\r", "", $codigo);
  $codigo = str_replace("\n", "\\n", $codigo);
  $str .= $codigo;
 }
 if (empty($inicio) && ($som == "entra" OR $som == "saida" OR $cont != $cont_session)) {
  $ext .= "window.parent.nomes.location.reload();\n";
  $cont_session = $cont;
  session_register("cont_session");
 }
}
$model->assign(array("{MSGS}" => $str, "{EXTRA}" => $ext));
$banco->atualiza();

/**
 * Troca as tags simples que sobrar�o.
 * E exibe o templante mudado.
**/
$model->assign("{UID}", $uid);
$model->assign("{TIME}", $tempo);
$model->assign("{REFRESH}", (1000*$refresh));
$model->parse("OUTPUT", "pagina");
$model->FastPrint("OUTPUT");
?>