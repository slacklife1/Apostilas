<?php
############################ ROMANO CHAT - MySQL #################################
#  Arquivo: principal.php                                                        #
#  Cria��o: 05/Abril/2004 - 06:16 PM                                             #
#  Vers�o:  6.0 ALPHA 1(?)                                                       #
#  Autores: Comunidade Romano Chat - (Id�ia Original: Rodrigo Romano)            #
##################################################################################
#  Software Distribui��o: http://www.phpbrasil.com                               #
#  Suporte, N�ticias, Atualiza��es em: http://www.phpbrasil.com                  #
#  Software Comunidade: romanochat@yahoogrupos.com.br                            #
##################################################################################
# - Este � um programa gr�tis; podendo ser redistribuido e modificado, desde de  #
#  que n�o se retire os cr�ditos iniciais dos autores.                           #
# - Este programa tamb�m vem SEM NENHUMA GARANTIA, e tudo � por sua conta e      #
#  risco ao usa-lo voc� ficara respons�vel por tudo; insentado os autores.       #
# - Para mais informa��es leia o arquivo "licenca.txt", no diret�rio principal.  #
##################################################################################

/**
 * Est� p�gina foi desabilitada do sistema s� n�o foi tirada por refer�ncia ...
 * Agora quem faz o papel de puxar essa parte e imprimir o header do arquivo 'principal.htm' ...
 * � o arquivo 'inferior.htm'(JavaScripts) e 'inferior.php', para que tudo seje mostrado OK...
**/
?>