<?php
############################ ROMANO CHAT - MySQL #################################
#  Arquivo: titulo.php                                                           #
#  Cria��o: 05/Abril/2004 - 05:14 PM                                             #
#  Vers�o:  6.0 ALPHA 1(?)                                                       #
#  Autores: Comunidade Romano Chat - (Id�ia Original: Rodrigo Romano)            #
##################################################################################
#  Software Distribui��o: http://www.phpbrasil.com                               #
#  Suporte, N�ticias, Atualiza��es em: http://www.phpbrasil.com                  #
#  Software Comunidade: romanochat@yahoogrupos.com.br                            #
##################################################################################
# - Este � um programa gr�tis; podendo ser redistribuido e modificado, desde de  #
#  que n�o se retire os cr�ditos iniciais dos autores.                           #
# - Este programa tamb�m vem SEM NENHUMA GARANTIA, e tudo � por sua conta e      #
#  risco ao usa-lo voc� ficara respons�vel por tudo; insentado os autores.       #
# - Para mais informa��es leia o arquivo "licenca.txt", no diret�rio principal.  #
##################################################################################

/**
 * @@@ Arquivo de Templante: 'titulo.htm' @@@@
 * Inclui os arquivos iniciais nesses�rios.
**/
include_once("./config.php");
include_once("./global.php");
include_once("./biblioteca/fasttemplate.php");

/**
 * Inicia o banco de dados.
 * Pega os dados do usu�rio.
**/
$banco = new chat;
$banco->dados($uid);

/**
 * Troca o usu�rio de sala
 * Se ele desejar...
**/
if (isset($sala)) {
 $banco->trocasala($uid);
}

/**
 * Inicia o sistema de templantes.
 * Carrega o templante solicitado.
 * Lista as Salas para serem trocadas.
**/
$model = new FastTemplate("./templates/$modelo");
$model->define(array("pagina" => "titulo.htm"));

$lista = $banco->salas();
$total = count($lista);
$model->define_dynamic("salas", "pagina");
if ($total == "0") {
 $model->assign(array("{COD}"  => "", "{NOME}" => "Nenhuma Sala"));
} else {
 for ($i = "0"; $i < $total; $i++) {
  $atual = $lista[$i];
  $model->assign(array("{COD}" => $atual["cod"], "{NOME}" => $lista[$i]["nome"]));
  $model->parse("SALAS", ".salas");
 }
}

/**
 * Lista os banners da pasta de banners.
 * E indica um arquivo ao sistema.
 * By Sandro[SK15] - sk15@msn.com
**/
$arquivos = array();
$dir_banners = opendir("./images/banners");
while ($imagens = readdir($dir_banners)) {
 if ($imagens != "." && $imagens != ".." && !is_dir($imagens)) {
  $arquivos[] = $imagens;
 }
}
closedir($dir_banners);
$total_banners = count($arquivos);
$array_menos = ($total_banners <= "1") ? "0" : "1";
srand((double)$tempo*1000000);
$banner = $arquivos[rand("0", ($total_banners-$array_menos))];
$model->assign("{BANNER}", $banner);

/**
 * Troca as tags simples que sobrar�o.
 * E exibe o templante mudado.
**/
$model->assign("{UID}", $uid);
$model->assign("{TIME}", $tempo);
$model->parse("OUTPUT", "pagina");
$model->FastPrint("OUTPUT");
?>