<?php
############################ ROMANO CHAT - MySQL #################################
#  Arquivo: mudarconfig.php                                                      #
#  Cria��o: 11/Abril/2004 - 10:14 PM                                             #
#  Vers�o:  6.0 ALPHA 1(?)                                                       #
#  Autores: Comunidade Romano Chat - (Id�ia Original: Rodrigo Romano)            #
##################################################################################
#  Software Distribui��o: http://www.phpbrasil.com                               #
#  Suporte, N�ticias, Atualiza��es em: http://www.phpbrasil.com                  #
#  Software Comunidade: romanochat@yahoogrupos.com.br                            #
##################################################################################
# - Este � um programa gr�tis; podendo ser redistribuido e modificado, desde de  #
#  que n�o se retire os cr�ditos iniciais dos autores.                           #
# - Este programa tamb�m vem SEM NENHUMA GARANTIA, e tudo � por sua conta e      #
#  risco ao usa-lo voc� ficara respons�vel por tudo; insentado os autores.       #
# - Para mais informa��es leia o arquivo "licenca.txt", no diret�rio principal.  #
##################################################################################

/**
 * @@@ Arquivo de Templante: 'admin/mudarconfig.htm' @@@@
 * Inclui os arquivos iniciais nesses�rios.
**/
include_once("../config.php");
include_once("../global.php");
include_once("../biblioteca/authentikate.php");
include_once("../biblioteca/fasttemplate.php");

/**
 * Inicia o banco de dados.
 * Inicia o Sistema de Autentifica��o.
 * Verifica o usu�rio online.
**/
$banco      = new chat;
$auth       = new AuthentiKate;
$url_root   = $banco->localizaurl();
$url_folder = $banco->localizaurl("1");
$auth->loginAuth("master", "$url_root/templates/$modelo/redirect.html", "$url_folder/index.php");

/**
 * Retira a Sala no banco de dados.
 * Verifica o tipo de templante que esta sendo usado (se possui descri��es).
 * Envia que foi retirada.
**/
if (isset($submit)) {
 $configs = file("../config.php");
 $totalf = count($configs);
 for ($i = "0"; $i < $totalf; $i++) {
  $config[$i] = trim($configs[$i]);
 }
 $config["23"] = "\$host = \"$cf_host\";   // Host do MySQL";
 $config["24"] = "\$user = \"$cf_user\";   // Usu�rio do MySQL";
 $config["25"] = "\$pass = \"$cf_pass\";   // Senha do MySQL";
 $config["26"] = "\$db = \"$cf_db\";   // Banco de Dados";
//---------------------------------
 $config["29"] = "\$refresh = \"$cf_refresh\";   // Tempo da atualiza��o do chat em segundos.";
 $config["30"] = "\$purge = \"$cf_purge\";   // Tempo limite dos usu�rios e mensagens em segundos.";
 $config["31"] = "\$limite = \"$cf_limite\";   // Limite de pessoas por sala.";
 $config["32"] = "\$assistente = \"$cf_assistente\";   // Tempo do assistente inserir mensagens em minutos.";
 $config["33"] = "\$ajuste_time = \"$cf_ajuste_time\";   // Diferen�a de seu tempo para o do servidor em horas +/- (exemplo: +5).";
 $config["34"] = "\$modelo = \"$cf_modelo\";   // Pasta do template utilizado.";
 $corescf = explode("\n", $cf_cores);
 $cor = array();
 foreach ($corescf as $valores) {
  $valores = trim($valores);
  if ($valores != "") {
   $nomecor = explode("=", $valores);
   $cor[] = '"'.trim($nomecor["0"]).'" => "'.trim($nomecor["1"]).'"';
  }
 }
 $arraycor = implode(", ", $cor);
 $config["35"] = "\$cores = array($arraycor);   // Cores ultilizada pelos usu�rios.";
 $banco->gravaconfig($config);
 $mudado = "1";
}

/**
 * Inicia o sistema de templantes.
 * Carrega o templante solicitado.
 * Lista os valores do sistema
 * Troca as tags que sobrar�o.
 * E exibe o templante mudado.
**/
$local = "../templates";
$model = new FastTemplate("$local/$modelo");
$model->define(array("pagina" => "admin/mudarconfig.htm"));
$model->assign("{TIME}", $tempo);
$model->assign(array("{HOST}" => $host, "{USER}" => $user, "{PASS}" => $pass, "{DB}"  => $db));
$model->assign(array("{REFRESH}" => $refresh, "{PURGE}" => $purge, "{LIMITE}" => $limite, "{ASSISTENTE}"  => $assistente, "{AJUSTETIME}" => $ajuste_time));

$model->define_dynamic("linhas", "pagina");
$dir_templantes = opendir($local);
while ($templante = readdir($dir_templantes)) {
 if ($templante != "." && $templante != ".." && is_dir("$local/$templante")) {
  $sel = ($templante == $modelo) ? " selected" : "";
  $model->assign(array("{SELECTED}" => $sel, "{COD}" => $templante));
  $model->parse("LINHAS", ".linhas");
 }
}

$model->define_dynamic("cores", "pagina");
foreach ($cores as $key => $value) {
 $model->assign(array("{NAME}" => $key, "{COR}" => $value));
 $model->parse("CORES", ".cores");
}

$model->assign("{ALTERADO}", ((isset($mudado)) ? "1" : "0"));
$model->parse("OUTPUT", "pagina");
$model->FastPrint("OUTPUT");
?>