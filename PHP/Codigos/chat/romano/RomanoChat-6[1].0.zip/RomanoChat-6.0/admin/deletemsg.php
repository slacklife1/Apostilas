<?php
############################ ROMANO CHAT - MySQL #################################
#  Arquivo: deletemsg.php                                                        #
#  Cria��o: 10/Abril/2004 - 12:38 AM                                             #
#  Vers�o:  6.0 ALPHA 1(?)                                                       #
#  Autores: Comunidade Romano Chat - (Id�ia Original: Rodrigo Romano)            #
##################################################################################
#  Software Distribui��o: http://www.phpbrasil.com                               #
#  Suporte, N�ticias, Atualiza��es em: http://www.phpbrasil.com                  #
#  Software Comunidade: romanochat@yahoogrupos.com.br                            #
##################################################################################
# - Este � um programa gr�tis; podendo ser redistribuido e modificado, desde de  #
#  que n�o se retire os cr�ditos iniciais dos autores.                           #
# - Este programa tamb�m vem SEM NENHUMA GARANTIA, e tudo � por sua conta e      #
#  risco ao usa-lo voc� ficara respons�vel por tudo; insentado os autores.       #
# - Para mais informa��es leia o arquivo "licenca.txt", no diret�rio principal.  #
##################################################################################

/**
 * @@@ Arquivo de Templante: 'admin/deletemsg.htm' @@@@
 * Inclui os arquivos iniciais nesses�rios.
**/
include_once("../config.php");
include_once("../global.php");
include_once("../biblioteca/authentikate.php");
include_once("../biblioteca/fasttemplate.php");

/**
 * Inicia o banco de dados.
 * Inicia o Sistema de Autentifica��o.
 * Verifica o usu�rio online.
**/
$banco      = new chat;
$auth       = new AuthentiKate;
$url_root   = $banco->localizaurl();
$url_folder = $banco->localizaurl("1");
$auth->loginAuth("master", "$url_root/templates/$modelo/redirect.html", "$url_folder/index.php");


/**
 * Deleta a mensagem do banco de dados.
 * Envia que foi criada.
**/
if (isset($cod)) {
 while (list(, $valor) = @each($cod)) {
  $banco->removeadv($valor);
 }
 $retirada = "1";
}

/**
 * Inicia o sistema de templantes.
 * Carrega o templante solicitado.
 * Lista as mensagens do banco.
 * Troca as tags que sobrar�o.
 * E exibe o templante mudado.
**/
$model = new FastTemplate("../templates/$modelo");
$model->define(array("pagina" => "admin/deletemsg.htm"));

$lista = $banco->listaadv();
$total = count($lista);
$model->define_dynamic("linhas", "pagina");
if ($total == "0") {
 $mgs = "S/M";
 $model->assign(array("{COD}" => "S/C", "{MSGINT}" => $mgs, "{MSGSUB}" => $mgs));
} else {
 for ($i = "0"; $i < $total; $i++) {
  $atual = $lista[$i];
  $sub = substr($atual["msg"], "0", "37")."...";
  $msgs = str_replace("\n", "\\n", $atual["msg"]);
  $model->assign(array("{COD}" => $atual["cod"], "{MSGINT}" => $msgs, "{MSGSUB}" => $sub));
  $model->parse("LINHAS", ".linhas");
 }
}

$model->assign("{TIME}", $tempo);
$model->assign("{RETIRADA}", ((isset($retirada)) ? "1" : "0"));
$model->parse("OUTPUT", "pagina");
$model->FastPrint("OUTPUT");
?>