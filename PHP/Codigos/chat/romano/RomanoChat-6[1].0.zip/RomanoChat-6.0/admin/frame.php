<?php
############################ ROMANO CHAT - MySQL #################################
#  Arquivo: index.php                                                            #
#  Cria��o: 03/Abril/2004 - 12:05 PM                                             #
#  Vers�o:  6.0 ALPHA 1(?)                                                       #
#  Autores: Comunidade Romano Chat - (Id�ia Original: Rodrigo Romano)            #
##################################################################################
#  Software Distribui��o: http://www.phpbrasil.com                               #
#  Suporte, N�ticias, Atualiza��es em: http://www.phpbrasil.com                  #
#  Software Comunidade: romanochat@yahoogrupos.com.br                            #
##################################################################################
# - Este � um programa gr�tis; podendo ser redistribuido e modificado, desde de  #
#  que n�o se retire os cr�ditos iniciais dos autores.                           #
# - Este programa tamb�m vem SEM NENHUMA GARANTIA, e tudo � por sua conta e      #
#  risco ao usa-lo voc� ficara respons�vel por tudo; insentado os autores.       #
# - Para mais informa��es leia o arquivo "licenca.txt", no diret�rio principal.  #
##################################################################################

/**
 * @@@ Arquivo de Templante: 'admin/frame.htm' @@@@
 * Inclui os arquivos iniciais nesses�rios.
**/
include_once("../config.php");
include_once("../global.php");
include_once("../biblioteca/authentikate.php");
include_once("../biblioteca/fasttemplate.php");

/**
 * Inicia o banco de dados.
 * Inicia o Sistema de Autentifica��o.
 * Verifica o usu�rio online.
**/
$banco      = new chat;
$auth       = new AuthentiKate;
$url_root   = $banco->localizaurl();
$url_folder = $banco->localizaurl("1");
$auth->loginAuth("master", "$url_root/templates/$modelo/redirect.html", "$url_folder/index.php");

/**
 * Inicia o sistema de templantes.
 * Carrega o templante solicitado.
 * Troca as tags que sobrar�o.
 * E exibe o templante mudado.
**/
$model = new FastTemplate("../templates/$modelo");
$model->define(array("pagina" => "admin/frame.htm"));
$model->assign("{TIME}", $tempo);
$model->parse("OUTPUT", "pagina");
$model->FastPrint("OUTPUT");
?>