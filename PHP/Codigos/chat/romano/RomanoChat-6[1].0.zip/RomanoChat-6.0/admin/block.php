<?php
############################ ROMANO CHAT - MySQL #################################
#  Arquivo: block.php                                                            #
#  Cria��o: 04/Abril/2004 - 18:05 PM                                             #
#  Vers�o:  6.0 ALPHA 1(?)                                                       #
#  Autores: Comunidade Romano Chat - (Id�ia Original: Rodrigo Romano)            #
##################################################################################
#  Software Distribui��o: http://www.phpbrasil.com                               #
#  Suporte, N�ticias, Atualiza��es em: http://www.phpbrasil.com                  #
#  Software Comunidade: romanochat@yahoogrupos.com.br                            #
##################################################################################
# - Este � um programa gr�tis; podendo ser redistribuido e modificado, desde de  #
#  que n�o se retire os cr�ditos iniciais dos autores.                           #
# - Este programa tamb�m vem SEM NENHUMA GARANTIA, e tudo � por sua conta e      #
#  risco ao usa-lo voc� ficara respons�vel por tudo; insentado os autores.       #
# - Para mais informa��es leia o arquivo "licenca.txt", no diret�rio principal.  #
##################################################################################

/**
 * @@@ Arquivo de Templante: 'admin/block.htm' @@@@
 * Inclui os arquivos iniciais nesses�rios.
**/
include_once("../config.php");
include_once("../global.php");
include_once("../biblioteca/authentikate.php");
include_once("../biblioteca/fasttemplate.php");

/**
 * Inicia o banco de dados.
 * Inicia o Sistema de Autentifica��o.
 * Verifica o usu�rio online.
**/
$banco      = new chat;
$auth       = new AuthentiKate;
$url_root   = $banco->localizaurl();
$url_folder = $banco->localizaurl("1");
$auth->loginAuth("master", "$url_root/templates/$modelo/redirect.html", "$url_folder/index.php");

/**
 * Mostra os Usu�rios da Sala.
 * Ou Bani o Usu�rio do Sistema.
**/
if (isset($cod) && $cod != "") {
 $banco->sala = $cod;
 $usuarios = "1";
}

if (isset($users) && $users != "") {
 $banco->blockuser($users);
 $banido = "1";
}

/**
 * Inicia o sistema de templantes.
 * Carrega o templante solicitado.
 * Listando Usu�rios e Salas.
 * Troca as tags que sobrar�o.
 * E exibe o templante mudado.
**/
$model = new FastTemplate("../templates/$modelo");
$model->define(array("pagina" => "admin/block.htm"));

$lista = $banco->salas();
$total = count($lista);
$model->define_dynamic("linhas", "pagina");
if ($total == "0") {
 $model->assign(array("{COD}" => "", "{OPT}" => "Nenhuma Sala Dispon�vel"));
} else {
 for ($i = "0"; $i < $total; $i++) {
  $atual = $lista[$i];
  $model->assign(array("{COD}" => $atual["cod"], "{OPT}" => $atual["nome"]));
  $model->parse("LINHAS", ".linhas");
 }
}

$model->define_dynamic("users", "pagina");
if (isset($usuarios)) {
 $lista = $banco->codlista();
 $total = count($lista);
 if ($total == "0") {
  $model->assign(array("{VALUE}" => "", "{NOME}" => "Nenhum Usu�rio"));
 } else {
  for ($i = "0"; $i < $total; $i++) {
   $atual = $lista[$i];
   $model->assign(array("{VALUE}" => $atual["cod"], "{NOME}" => $atual["nome"]));
   $model->parse("USERS", ".users");
  }
 }
} else {
 $model->assign(array("{VALUE}" => "", "{NOME}" => "Escolha uma Sala para Ver os Usu�rios"));
}

$model->assign("{TIME}", $tempo);
$model->assign("{SALA}", ((isset($usuarios)) ? "1" : "0"));
$model->assign("{RETIRADO}", ((isset($banido)) ? "1" : "0"));
$model->parse("OUTPUT", "pagina");
$model->FastPrint("OUTPUT");
?>