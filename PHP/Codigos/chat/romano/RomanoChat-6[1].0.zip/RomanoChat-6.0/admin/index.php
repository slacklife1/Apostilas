<?php
############################ ROMANO CHAT - MySQL #################################
#  Arquivo: index.php                                                            #
#  Cria��o: 03/Abril/2004 - 12:05 PM                                             #
#  Vers�o:  6.0 ALPHA 1(?)                                                       #
#  Autores: Comunidade Romano Chat - (Id�ia Original: Rodrigo Romano)            #
##################################################################################
#  Software Distribui��o: http://www.phpbrasil.com                               #
#  Suporte, N�ticias, Atualiza��es em: http://www.phpbrasil.com                  #
#  Software Comunidade: romanochat@yahoogrupos.com.br                            #
##################################################################################
# - Este � um programa gr�tis; podendo ser redistribuido e modificado, desde de  #
#  que n�o se retire os cr�ditos iniciais dos autores.                           #
# - Este programa tamb�m vem SEM NENHUMA GARANTIA, e tudo � por sua conta e      #
#  risco ao usa-lo voc� ficara respons�vel por tudo; insentado os autores.       #
# - Para mais informa��es leia o arquivo "licenca.txt", no diret�rio principal.  #
##################################################################################

/**
 * @@@ Arquivo de Templante: 'admin/index.htm' @@@@
 * Inclui os arquivos iniciais nesses�rios.
**/
include_once("../config.php");
include_once("../global.php");
include_once("../biblioteca/authentikate.php");
include_once("../biblioteca/fasttemplate.php");

/**
 * Inicia o banco de dados.
 * Inicia o Sistema de Autentifica��o.
**/
$banco = new chat;
$auth  = new AuthentiKate;

/**
 * Verifica se foi enviado os dados.
 * Redirecionando o usu�rio a p�gina correta.
 * loginAuth("1�", "2�", "3�", "4�", "5�");
 * 1� = N�vel do Usu�rio para o Acesso.
 * 2� = P�gina de redire��o se estiver tudo errado.
 * 3� = P�gina de login, os formul�rios.
 * 4� = P�gina de redire��o se tudo estiver ok.
 * 5� = Tipo de verifica��o, rediecionamento ou setando tudo OK.
**/
if (isset($login) && isset($senha)) {
 $url_root   = $banco->localizaurl();
 $url_folder = $banco->localizaurl("1");
 $auth->loginAuth("master", "$url_root/templates/$modelo/redirect.html", "$url_folder/index.php", "$url_folder/frame.php?time=$tempo", false);
}

/**
 * Inicia o sistema de templantes.
 * Carrega o templante solicitado.
 * Troca as tags que sobrar�o.
 * E exibe o templante mudado.
**/
$model = new FastTemplate("../templates/$modelo");
$model->define(array("pagina" => "admin/index.htm"));
$model->assign("{TIME}", $tempo);
$model->parse("OUTPUT", "pagina");
$model->FastPrint("OUTPUT");
?>