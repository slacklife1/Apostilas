<?php
############################ ROMANO CHAT - MySQL #################################
#  Arquivo: config.php                                                           #
#  Cria��o: 02/Abril/2004 - 07:06 PM                                             #
#  Vers�o:  6.0 ALPHA 1(?)                                                       #
#  Autores: Comunidade Romano Chat - (Id�ia Original: Rodrigo Romano)            #
##################################################################################
#  Software Distribui��o: http://www.phpbrasil.com                               #
#  Suporte, N�ticias, Atualiza��es em: http://www.phpbrasil.com                  #
#  Software Comunidade: romanochat@yahoogrupos.com.br                            #
##################################################################################
# - Este � um programa gr�tis; podendo ser redistribuido e modificado, desde de  #
#  que n�o se retire os cr�ditos iniciais dos autores.                           #
# - Este programa tamb�m vem SEM NENHUMA GARANTIA, e tudo � por sua conta e      #
#  risco ao usa-lo voc� ficara respons�vel por tudo; insentado os autores.       #
# - Para mais informa��es leia o arquivo "licenca.txt", no diret�rio principal.  #
##################################################################################

###### Informa��es ######
# N�O ALTERE AS LINHA DE POSI��O PARA O PHP PODER ALTERAR ONLINE ESSE ARQUIVO.
# AJUSTE ESSAS VARIAV�IS CORRETAMENTE, � CRUCIAL PARA O FUNCIONAMENTO DO SISTEMA.

## Banco de Dados - MySQL ##
$host = "localhost";  // Host do MySQL
$user = "root";       // Usu�rio do MySQL
$pass = "";           // Senha do MySQL
$db = "test";         // Banco de Dados

## Configura��es do Chat ##
$refresh = "5";       // Tempo da atualiza��o do chat em segundos.
$purge = "60";        // Tempo limite dos usu�rios e mensagens em segundos.
$limite = "30";       // Limite de pessoas por sala.
$assistente = "10";   // Tempo do assistente inserir mensagens em minutos.
$ajuste_time = "0";   // Diferen�a de seu tempo para o do servidor em horas +/- (exemplo: +5/-5).
$modelo = "sk15_purple";   // Pasta do template utilizado.
$cores = array("Preto" => "#000000", "Vermelho" => "#FF0000", "Verde" => "#008000", "Azul" => "#0000FF", "Laranja" => "#FF8040", "Cinza" => "#808080", "Roxo" => "#FF00FF");   // Cores ultilizada pelos usu�rios.
?>