<?php
############################ ROMANO CHAT - MySQL #################################
#  Arquivo: global.php                                                           #
#  Cria��o: 02/Abril/2004 - 00:50 AM                                             #
#  Vers�o:  6.0 ALPHA 1(?)                                                       #
#  Autores: Comunidade Romano Chat - (Id�ia Original: Rodrigo Romano)            #
##################################################################################
#  Software Distribui��o: http://www.phpbrasil.com                               #
#  Suporte, N�ticias, Atualiza��es em: http://www.phpbrasil.com                  #
#  Software Comunidade: romanochat@yahoogrupos.com.br                            #
##################################################################################
# - Este � um programa gr�tis; podendo ser redistribuido e modificado, desde de  #
#  que n�o se retire os cr�ditos iniciais dos autores.                           #
# - Este programa tamb�m vem SEM NENHUMA GARANTIA, e tudo � por sua conta e      #
#  risco ao usa-lo voc� ficara respons�vel por tudo; insentado os autores.       #
# - Para mais informa��es leia o arquivo "licenca.txt", no diret�rio principal.  #
##################################################################################

/**
 * Inicia a sess�o para todo o script.
 * E o tempo para todo o script.
**/
session_start();
$tempo = time()+($ajuste_time*3600);

/**
 * Retira todas as vavi�veis dos poss�veis metodos de envio.
 * Verificando a vers�o do PHP em quest�o para servir em todos.
 * By Sandro[SK15] - sk15@msn.com
**/
$tipos_registros = array("GET", "POST", "SESSION", "SERVER");
foreach ($tipos_registros as $tipos) {
 $arr = (phpversion() < "4.1.0") ? @${"HTTP_".$tipos."_VARS"} : @${"_".$tipos};
 if (@count($arr) > "0") {
  foreach ($arr as $chave => $valor) {
   $array = (is_array($valor)) ? "[$chave][]" : "[$chave]";
   $GLOBALS.$array = htmlspecialchars(trim($valor));
  }
 }
}

class chat {
/**
 * Vari�veis dos Sistema:
 * $dbh = Vari�vel de conex�o do banco de dados.
 * $nome = Nome do usu�rio.
 * $careta = N�mero da careta.
 * $sala = C�digo da sala.
 * $cor = N�mero da cor em hexadecimal.
 * $nomesala = Nome da sala.
**/
 var $dbh, $nome, $careta, $sala, $cor, $nomesala;

/**
 * Conecta ao banco de dados.
**/
function chat() {
 global $host, $user, $pass, $db;
 $this->dbh = mysql_connect($host, $user, $pass) or die ("ERRO ao se conectar a base de dados");
 mysql_select_db($db, $this->dbh) or die ("ERRO ao se selecionar a base de dados");
}

/**
 * Localiza��o do Script
 * Fun��o que fixa Bugs de servidores que n�o iniciam os Headers com URLs sem HTTP://.
 * OBS: S� funciona perfeitamente na pasta RAIZ e 2 acimas ....
 * By Sandro[SK15] - sk15@msn.com
**/
function localizaurl($pasta = '0') {
 global $PHP_SELF, $HTTPS, $SERVER_NAME, $SERVER_PORT;
 $arquivo = substr($PHP_SELF, "0", strrpos($PHP_SELF, "/"));
 $pastas = ($pasta == '0') ? substr($arquivo, "0", strrpos($arquivo, "/")) : $arquivo;
 $local = "http".(($HTTPS) ? "s" : "")."://".$SERVER_NAME.":".$SERVER_PORT.$pastas;
return $local;
}

/**
 * Extrai todas as informa��es do usu�rio do chat.
**/
function dados($uid) {
 $consulta = mysql_query("SELECT S.nome AS nomesala, U.nome, U.sala, U.careta, U.cor FROM users U, salas S WHERE (S.cod=U.sala && U.uid='$uid') LIMIT 1;", $this->dbh);
 $row = mysql_fetch_array($consulta);
 mysql_free_result($consulta);
 $this->sala     = $row["sala"];
 $this->nome     = $row["nome"];
 $this->careta   = $row["careta"];
 $this->cor      = $row["cor"];
 $this->nomesala = $row["nomesala"];
}

/**
 * Bloqueia determinado usu�rio.
**/
function block($uid) {
 global $modelo;
 $consulta = mysql_query("SELECT COUNT(*) AS total FROM users WHERE uid='$uid';", $this->dbh);
 $row = mysql_fetch_array($consulta);
 mysql_free_result($consulta);
 $ip = getenv("REMOTE_ADDR");
 $consulta2 = mysql_query("SELECT COUNT(*) AS total FROM block WHERE (ip='$ip' OR name='".$this->nome."';", $this->dbh);
 $row2 = mysql_fetch_array($consulta2);
 mysql_free_result($consulta2);
 if ($row["total"] == "0" OR $row2["total"] > "0") {
  $url = $this->localizaurl("1");
  header("Location: $url/templates/$modelo/redirect.html");
  exit();
 }
}

/**
 * Conta quantos usu�rios existe na sala determinada.
**/
function cont($nome) {
 $sql = ($nome == "TODOS") ? "sala='".$this->sala."'" : "(nome='$nome' && sala='".$this->sala."')";
 $consulta = mysql_query("SELECT COUNT(*) AS total FROM users WHERE $sql;", $this->dbh);
 $row = mysql_fetch_array($consulta);
 mysql_free_result($consulta);
return $row["total"];
}

/**
 * Lista as salas do banco de dados.
**/
function salas() {
 $i = "0";
 $consulta = mysql_query("SELECT * FROM salas WHERE (cod != '".$this->sala."') ORDER BY nome ASC;", $this->dbh);
 while ($row = mysql_fetch_array($consulta)) {
  $this->sala         = $row["cod"];
  $lista[$i]["cont"]  = $this->cont("TODOS");
  $lista[$i]["cod"]   = $row["cod"];
  $lista[$i]["desc"]  = $row["descr"];
  $lista[$i]["nome"]  = $row["nome"];
  $i++;
 }
 mysql_free_result($consulta);
return $lista;
}

/**
 * Retira um usu�rio da sala.
**/
function removeuser() {
 $str = $this->perfil($this->nome)." sai da sala ...";
 $this->addmsgs($str, $this->nome, "TODOS", "saida", "pub");
 mysql_query("DELETE FROM users WHERE (nome='".$this->nome."' && sala='".$this->sala."') LIMIT 1;", $this->dbh);
}

/**
 * Extrai o perfil de um usu�rio.
**/
function perfil($nome, $tipo = "este") {
 if ($nome != "TODOS" && $this->cont($nome) > "0") {
  $consulta = mysql_query("SELECT nome, careta, cor FROM users WHERE (nome='$nome' && sala='".$this->sala."') LIMIT 1;", $this->dbh);
  $row = mysql_fetch_array($consulta);
  mysql_free_result($consulta);
  if ($tipo == 'este') {
   $imagem = "./images/caretas/".(($row["careta"] != "69") ? $row["careta"] : "0").".gif";
   $tamanho = @GetImageSize($imagem);
   $perfil = '<img src="'.$imagem.'" align="middle" '.$tamanho['3'].' border="0" hspace="1"><font color="'.$row["cor"].'"><b>'.$row["nome"].'</b></font>';
  } else {
   $perfil = $row["nome"];
  }
 } else {
  $perfil = "TODOS";
 }
return $perfil;
}

/**
 * Lista os usu�rios da sala (nomes e uid).
**/
function codlista() {
 $i = "0";
 $consulta = mysql_query("SELECT nome, uid FROM users WHERE sala='".$this->sala."';", $this->dbh);
 while ($row = mysql_fetch_array($consulta)) {
  $nomes[$i]["nome"] = $row["nome"];
  $nomes[$i]["cod"]  = $row["uid"];
  $i++;
 }
 mysql_free_result($consulta);
return $nomes;
}

/**
 * Adiciona um usu�rio a sala de batepapo.
**/
function adduser($uid){
 global $apelido_session, $cor_session, $careta_session, $sala, $limite;
 $ip           = getenv("REMOTE_ADDR");
 $this->sala   = $sala;
 $this->cor    = (empty($cor_session)) ? "#000000" : $cor_session;
 $this->nome   = (empty($apelido_session)) ? "An�nimo" : $apelido_session;
 $this->careta = (empty($careta_session)) ? "69" : $careta_session;
 if ($this->sala == ""){
  $msg = "Coloque uma Sala v�lida";
  $voltar = false;
 } else if ($this->cont($this->nome) > "0") {
  $msg = "J� existe esse Nome na Sala";
  $voltar = false;
 } else if ($this->cont("TODOS") >= $limite) {
  $msg = "Essa Sala est� Lotada - M�ximo: $limite";
  $voltar = false;
 } else {
  mysql_query("INSERT INTO users (nome, careta, cor, date, sala, uid, ip) VALUES ('".$this->nome."', ".$this->careta.", '".$this->cor."', NOW(), '".$this->sala."', '$uid', '$ip');", $this->dbh);
  $this->dados($uid);
  $str = $this->perfil($this->nome)." entra na sala <b>".$this->nomesala."</b>";
  $this->addmsgs($str, $this->nome, "TODOS", "entra", "pub");
  $voltar = true;
 }
 if (isset($msg)) {
  $url = $this->localizaurl('1');
  header("Location: $url/index.php?msg=".urlencode($msg));
  exit();
 }
return $voltar;
}

/**
 * Troca o perfil de um usu�rio.
**/
function troca($uid) {
 global $apelido, $careta, $cor;
 if ($this->nome != $apelido && $this->cont($apelido) == "0") {
  $antigo = $this->perfil($this->nome);
  mysql_query("UPDATE users SET nome='$apelido', careta='$careta', cor='$cor' WHERE uid='$uid' LIMIT 1;", $this->dbh);
  $str = $antigo." troca o perfil para ".$this->perfil($apelido);
  $this->addmsgs($str, $apelido, "TODOS", "entra", "pub");
  $voltar = true;
 } else {
  $voltar = false;
 }
return $voltar;
}

/**
 * Troca o usu�rio de sala.
**/
function trocasala($uid) {
 global $sala, $limite;
 $old        = $this->sala;
 $this->sala = $sala;
 $cont       = $this->cont("TODOS");
 if (($cont < $limite) && ($this->cont($this->nome) == "0")) {
  mysql_query("UPDATE users SET sala='".$this->sala."' WHERE uid='$uid' LIMIT 1;", $this->dbh);
  $this->dados($uid);
  $str = $this->perfil($this->nome)." entra na sala <b>".$this->nomesala."</b>";
  $this->addmsgs($str, $this->nome, "TODOS", "entra", "pub");
  $str = $this->perfil($this->nome)." sai da sala...";
  $this->sala = $old;
  $this->addmsgs($str, $this->nome, "TODOS", "saida", "pub");
  $this->sala = $sala;
 } else {
  $this->sala = $old;
  $str = "<b>Mensagem do sitema:</b> A sala est� Lotada ou o Nome j� existe.";
  $this->addmsgs($str, $this->nome, $this->nome, "nada", "res");
 }
}

/**
 * Adiciona mensagens ao chat.
**/
function addmsgs($str, $rem, $dest, $som, $tipo) {
 mysql_query("INSERT INTO msg (msg, date, rem, dest, som, tipo, sala) VALUES ('$str', NOW(), '$rem', '$dest','$som','$tipo', '".$this->sala."');", $this->dbh);
 mysql_query("INSERT INTO logmsg (msg, date, rem, dest, som, tipo, sala) VALUES ('$str', NOW(), '$rem', '$dest', '$som', '$tipo', '".$this->sala."');", $this->dbh);
}

/**
 * Lista as mensagens da sala.
**/
function msgs() {
 global $date_session;
 $i = "0";
 $consulta = mysql_query("SELECT * FROM msg WHERE ((rem='".$this->nome."' OR dest='".$this->nome."' OR tipo='pub') && date > '$date_session' && sala='".$this->sala."') ORDER BY date ASC;", $this->dbh);
 while ($row = mysql_fetch_array($consulta)) {
  $msgs[$i]["msg"]  = $row["msg"];
  $msgs[$i]["som"]  = $row["som"];
  $msgs[$i]["dest"] = $row["dest"];
  $msgs[$i]["rem"]  = $row["rem"];
  $date_session     = $row["date"];
  $i++;
 }
 mysql_free_result($consulta);
return $msgs;
}

/**
 * Lista as mensagens de log da sala.
**/
function logmsgs() {
 $i = "0";
 $consulta = mysql_query("SELECT * FROM logmsg WHERE sala='".$this->sala."' ORDER BY date DESC;", $this->dbh);
 while ($row = mysql_fetch_array($consulta)) {
  $msgs[$i]["msg"]  = $row["msg"];
  $msgs[$i]["dest"] = $row["dest"];
  $msgs[$i]["rem"]  = $row["rem"];
  $msgs[$i]["data"] = $row["date"];
  $i++;
 }
 mysql_free_result($consulta);
return $msgs;
}

/**
 * Atualiza o banco de dados.
**/
function atualiza() {
 global $purge;
 mysql_query("DELETE FROM msg WHERE (date < DATE_SUB(NOW(), INTERVAL $purge SECOND));", $this->dbh);
 mysql_query("DELETE FROM users WHERE (date < DATE_SUB(NOW(), INTERVAL $purge SECOND));", $this->dbh);
 mysql_query("UPDATE users SET date=NOW() WHERE (nome='".$this->nome."' && sala='".$this->sala."');", $this->dbh);
}

/**
 * Cria uma nova sala
**/
function criasala($nome, $desc) {
 global $tempo;
 srand((double)$tempo*1000000);
 $uid = md5(uniqid(rand(), true));
 mysql_query("INSERT INTO salas (nome, descr, cod, date) VALUES ('$nome', '$desc', '$uid', NOW())", $this->dbh);
}

/**
 * Remove uma sala.
**/
function removesala($cod) {
 mysql_query("DELETE FROM salas WHERE cod='$cod' LIMIT 1;", $this->dbh);
}

/**
 * Limpa o log de uma sala.
**/
function removelogsala($cod) {
 mysql_query("DELETE FROM logmsg WHERE sala='$cod';", $this->dbh);
}

/**
 * Insere um usu�rio a bloquear.
 * Pelo IP ou Nome do usu�rio.
**/
function blockuser($uid) {
 $consulta = mysql_query("SELECT nome, ip FROM users WHERE uid='$uid' LIMIT 1;", $this->dbh);
 $row = mysql_fetch_array($consulta);
 mysql_free_result($consulta);
 mysql_query("INSERT INTO block (name, ip, data) VALUES ('$row[nome]', '$row[ip]', NOW());", $this->dbh);
}

/**
 * Insere mensagens do assistente na sala de batepapo
**/
function adv() {
 global $assistente;
 $consulta = mysql_query("SELECT COUNT(*) AS total FROM adv;", $this->dbh);
 $row = mysql_fetch_array($consulta);
 mysql_free_result($consulta);
 if ($assistente != "0" && $row["total"] > "0") {
  $consulta2 = mysql_query("SELECT COUNT(*) AS total FROM salas WHERE (cod='".$this->sala."' && date < DATE_SUB(NOW(), INTERVAL ".($assistente*60)." SECOND));", $this->dbh);
  $row2 = mysql_fetch_array($consulta2);
  mysql_free_result($consulta2);
  if ($row2["valor"] != "0") {
   $consulta3 = mysql_query("SELECT * FROM adv ORDER BY RAND() LIMIT 1;", $this->dbh);
   $row3 = mysql_fetch_array($consulta3);
   mysql_free_result($consulta3);
   $str = $row3["msg"];
   $this->addmsgs($str, "sistema", "TODOS", "nada", "pub");
   mysql_query("UPDATE salas SET date=NOW() WHERE cod='".$this->sala."' LIMIT 1;", $this->dbh);
  }
 }
}

/**
 * Insere mensagens no assistente
**/
function addadv($msg) {
 mysql_query("INSERT INTO adv (msg) VALUES ('$msg');", $this->dbh);
}

/**
 * Lista as mensagens do assistente
**/
function listaadv(){
 $i = "0";
 $consulta = mysql_query("SELECT * FROM adv ORDER BY cod DESC;", $this->dbh);
 while ($row = mysql_fetch_array($consulta)) {
  $msgs[$i]["cod"] = $row["cod"];
  $msgs[$i]["msg"] = $row["msg"];
  $i++;
 }
 mysql_free_result($consulta);
return $msgs;
}

/**
 * Remove �s mensagens do assistente.
**/
function removeadv($cod) {
 mysql_query("DELETE FROM adv WHERE cod='$cod' LIMIT 1;", $this->dbh);
}

/**
 * Lista os ips bloqueados/nomes.
**/
function ip() {
 $i = "0";
 $consulta = mysql_query("SELECT * FROM block ORDER BY data ASC;", $this->dbh);
 while ($row = mysql_fetch_array($consulta)) {
  $ip[$i]["name"] = $row["name"];
  $ip[$i]["ip"]   = $row["ip"];
  $ip[$i]["date"] = $row["data"];
  $i++;
 }
 mysql_free_result($consulta);
return $ip;
}

/**
 * Remove ip bloqueado.
**/
function removeip($cod) {
 mysql_query("DELETE FROM block WHERE ip='$cod' LIMIT 1;", $this->dbh);
}

/**
 * Insere um Novo administra no Sistema.
 * O Padr�o do sistema � "master"...
**/
function criaradmin($nome, $login, $senha) {
 $senha_encode = md5($senha);
 mysql_query("INSERT INTO auth (login, pwd, name) VALUES ('$login', '$senha_encode', '$nome');", $this->dbh);
 mysql_query("INSERT INTO privs (login, priv) VALUES ('$login', 'master');", $this->dbh);
}

/**
 * Lista os administradores.
**/
function admins() {
 $i = "0";
 $consulta = mysql_query("SELECT * FROM auth ORDER BY name ASC;", $this->dbh);
 while ($row = mysql_fetch_array($consulta)) {
  $adm[$i]["name"]  = $row["name"];
  $adm[$i]["login"] = $row["login"];
  //$adm[$i]["senha"] = $row["pwd"];
  $i++;
 }
 mysql_free_result($consulta);
return $adm;
}

/**
 * Remove um adminsitrador.
**/
function removeadmin($cod) {
 mysql_query("DELETE FROM auth WHERE login='$cod' LIMIT 1;", $this->dbh);
 mysql_query("DELETE FROM privs WHERE login='$cod' LIMIT 1;", $this->dbh);
}

/**
 * Altera o arquivo "config.php"
**/
function gravaconfig($configs) {
 $fp = fopen("../config.php", "w");
 foreach ($configs as $colunas){
  fwrite($fp, "$colunas\n");
 }
 fclose($fp);
}
//--------------------------------------------------------
} // End class.chat
?>