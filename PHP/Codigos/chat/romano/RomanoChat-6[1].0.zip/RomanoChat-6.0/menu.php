<?php
############################ ROMANO CHAT - MySQL #################################
#  Arquivo: menu.php                                                             #
#  Cria��o: 05/Abril/2004 - 01:43 AM                                             #
#  Vers�o:  6.0 ALPHA 1(?)                                                       #
#  Autores: Comunidade Romano Chat - (Id�ia Original: Rodrigo Romano)            #
##################################################################################
#  Software Distribui��o: http://www.phpbrasil.com                               #
#  Suporte, N�ticias, Atualiza��es em: http://www.phpbrasil.com                  #
#  Software Comunidade: romanochat@yahoogrupos.com.br                            #
##################################################################################
# - Este � um programa gr�tis; podendo ser redistribuido e modificado, desde de  #
#  que n�o se retire os cr�ditos iniciais dos autores.                           #
# - Este programa tamb�m vem SEM NENHUMA GARANTIA, e tudo � por sua conta e      #
#  risco ao usa-lo voc� ficara respons�vel por tudo; insentado os autores.       #
# - Para mais informa��es leia o arquivo "licenca.txt", no diret�rio principal.  #
##################################################################################

/**
 * @@@ Arquivo de Templante: 'menu.htm' @@@@
 * Inclui os arquivos iniciais nesses�rios.
**/
include_once("./config.php");
include_once("./global.php");
include_once("./biblioteca/fasttemplate.php");

/**
 * Inicia o banco de dados.
 * Pega os dados do usu�rio.
**/
$banco   = new chat;
$banco->dados($uid);
$banco->adv();
$perfila = $banco->perfil($banco->nome);

/**
 * Verifica todos os dados da mensagem.
 * E grava no Banco de Dados.
**/
if (isset($mensagem) && $mensagem != "") {
 $res  = (isset($sigilo) && $sigilo == "1") ? "reservadamente " : "";
 $img  = (isset($imagem) && $imagem != "vazio") ? '<img src="./images/exp/'.$imagem.'.gif" align="middle" border="0" hspace="8"></center>' : "";
 $hora = "<b>".date("(H:i:s)", $tempo)."</b>";
/**
 * Faz as trocas de tags aos sistema.
 * Primeiro Troca as Imagems.
 * Depois as URLS, se poss�vel, pois se a URL for reconhecida como uma imagem ela ser� trocada.
 * E logo depois ela iria ser reconhecida como uma tag HTML, e o resultado seria algo desastroso.
 * Exemplo: <a href="<img src="http://site.com/img.gif">"><img src="http://site.com/img.gif"></a>
 * OBS: as v�viaveis que usam aspas simples serve para poder usar HTMLS com aspas duplas se for preciso.
**/
 $mensagem = trim($mensagem);
 $mensagem = htmlentities($mensagem);
 $mensagem = eregi_replace("\[http://([^]]+)\.(gif|jpg|jpeg|png|bmp|tif|tiff)\]",'<img src="http://\\1.\\2" border="0">{IMAGE}', $mensagem);
 $mensagem = eregi_replace("\[www\.([^]]+)\.(gif|jpg|jpeg|png|bmp|tif|tiff)\]",'<img src="http://www.\\1.\\2" border="0">{IMAGE}', $mensagem);
 if (!eregi("{IMAGE}", $mensagem)) {
  $mensagem = eregi_replace("([ \\t]|^)www."," http://www.", $mensagem);
  $mensagem = eregi_replace("([ \\t]|^)ftp\\."," ftp://ftp.", $mensagem);
  $mensagem = eregi_replace("(http://[^ )\r\n]+)",'<a href="\\1" target="_blank">\\1</a>', $mensagem);
  $mensagem = eregi_replace("(https://[^ )\r\n]+)",'<A href="\\1\\" target="_blank">\\1</a>', $mensagem);
  $mensagem = eregi_replace("(ftp://[^ )\r\n]+)",'<a href="\\1" target="_blank">\\1</a>', $mensagem);
  $mensagem = eregi_replace("([-a-z0-9_]+(\\.[_a-z0-9-]+)*@([a-z0-9-]+(\\.[a-z0-9-]+)+))",'<a href="mailto:\\1">\\1</a>', $mensagem);
 }
 $mensagem = str_replace("{IMAGE}", "", $mensagem);
/**
 * Grava, Proibe e Exibe.
 * As mensagens para os usu�rios.
**/
 $mensage  = ($falas == "grita com" OR $falas == "murmura para") ? '<font size="'.(($falas == "grita com") ? "5" : "1").'">'.$mensagem.'</font>' : $mensagem;
 $perfilb  = $banco->perfil($users, "aquele");
 $mensagem = '<small>'.$hora.'</small> '.$perfila.' <i>'.$res.$falas.'</i> '.$perfilb.': '.$mensage.$img;
 $ignora   = array();
 unset($ignora[$users]);
 if ($falas == "ignora") {
  $ignora[$users] = "1";
  session_register("ignora");
  $str = '<b>Mensagem do sitema:</b> Voc� est� ignorando todas as mensagens de '.$users.'. Caso deseje conversar com ele novamente basta enviar uma nova mensagem. Ele ser� desbloqueado.';
  $banco->addmsgs($str, $banco->nome, $banco->nome, $som, "res");
  unset($users);
 } else {
  $str = addslashes($mensagem);
  $banco->addmsgs($str, $banco->nome, $users, $som, (($res == "") ? "pub" : "res"));
 }
}
$marca  = ($banco->cont($users) == "1") ? $users : "TODOS";
$sigilo = ($sigilo == "1") ? " checked" : "";

/**
 * Troca as tags simples que sobrar�o.
 * E exibe o templante mudado.
**/
$model = new FastTemplate("./templates/$modelo");
$model->define(array("pagina" => "menu.htm"));
$model->assign("{SALA}", $banco->nomesala);
$model->assign("{UID}", $uid);
$model->assign("{TIME}", $tempo);
$model->assign("{MARCA}", $marca);
$model->assign("{CARETA}", $perfila);
$model->assign("{SIGILO}", $sigilo);
$model->parse("OUTPUT", "pagina");
$model->FastPrint("OUTPUT");
?>