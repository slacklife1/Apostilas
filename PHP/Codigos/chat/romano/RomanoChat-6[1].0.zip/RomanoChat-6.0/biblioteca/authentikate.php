<?php
############################ ROMANO CHAT - MySQL #################################
#  Arquivo: authentikate.php                                                     #
#  Cria��o: 03/Abril/2004 - 12:14 PM                                             #
#  Vers�o:  6.0 ALPHA 1(?)                                                       #
#  Autores: ??? - (Melhoramentos: Comunidade Romano Chat)                        #
##################################################################################
#  Software Distribui��o: http://www.phpbrasil.com                               #
#  Suporte, N�ticias, Atualiza��es em: http://www.phpbrasil.com                  #
#  Software Comunidade: romanochat@yahoogrupos.com.br                            #
##################################################################################
# - Este � um programa gr�tis; podendo ser redistribuido e modificado, desde de  #
#  que n�o se retire os cr�ditos iniciais dos autores.                           #
# - Este programa tamb�m vem SEM NENHUMA GARANTIA, e tudo � por sua conta e      #
#  risco ao usa-lo voc� ficara respons�vel por tudo; insentado os autores.       #
# - Para mais informa��es leia o arquivo "licenca.txt", no diret�rio principal.  #
##################################################################################

class AuthentiKate {
/**
 * Vari�veis dos Sistema:
 * $dbh = Vari�vel de conex�o do banco de dados.
**/
 var $dbh;

/**
 * Trasfere a conex�o da class "chat" do arquivo "global.php".
 * Para essa classe dimunindo tempo e tags.
**/
function AuthentiKate() {
 global $banco;
 $this->dbh = $banco->dbh;
}

/**
 * Verifica o login do usu�rio
 * Redireciona o usu�rio as p�gina de destino.
**/
function loginAuth($priv, $on_failure, $login_page, $login_true = null, $protect = true) {
 global $login, $senha, $nome_session, $login_session, $senha_session;
 if (($login_session != "" && $senha_session != "") OR ($login != "" && $senha != "")) {
  $login_db = ($login_session != "") ? $login_session : $login;
  $senha_db = ($senha_session != "") ? $senha_session : md5($senha);
  $consulta = mysql_query("SELECT A.login, A.pwd, A.name FROM auth A, privs P WHERE ((A.login='$login_db' && A.pwd='$senha_db') && (P.priv='$priv' OR P.priv='master') && A.login=P.login) LIMIT 1;", $this->dbh);
  if (mysql_num_rows($consulta) == "0") {
   $redireciona = $on_failure;
   $voltar = false;
  } else {
   if (!$protect && $login_true != null) {
    $row = mysql_fetch_array($consulta);
    $nome_session  = $row["name"];
    $login_session = $row["login"];
    $senha_session = $row["pwd"];
    session_register("nome_session", "login_session", "senha_session");
    $redireciona = $login_true;
   }
   $voltar = true;
  }
  mysql_free_result($consulta);
 } else {
  $redireciona = $login_page;
  $voltar = false;
 }
 if (isset($redireciona)) {
  header("Location: $redireciona");
  exit();
 }
return $voltar;
}
//--------------------------------------------------------
} // End class.AuthentiKate
?>