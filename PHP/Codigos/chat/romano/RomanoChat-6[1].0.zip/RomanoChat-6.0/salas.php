<?php
############################ ROMANO CHAT - MySQL #################################
#  Arquivo: salas.php                                                            #
#  Cria��o: 02/Abril/2004 - 01:00 AM                                             #
#  Vers�o:  6.0 ALPHA 1(?)                                                       #
#  Autores: Comunidade Romano Chat - (Id�ia Original: Rodrigo Romano)            #
##################################################################################
#  Software Distribui��o: http://www.phpbrasil.com                               #
#  Suporte, N�ticias, Atualiza��es em: http://www.phpbrasil.com                  #
#  Software Comunidade: romanochat@yahoogrupos.com.br                            #
##################################################################################
# - Este � um programa gr�tis; podendo ser redistribuido e modificado, desde de  #
#  que n�o se retire os cr�ditos iniciais dos autores.                           #
# - Este programa tamb�m vem SEM NENHUMA GARANTIA, e tudo � por sua conta e      #
#  risco ao usa-lo voc� ficara respons�vel por tudo; insentado os autores.       #
# - Para mais informa��es leia o arquivo "licenca.txt", no diret�rio principal.  #
##################################################################################

/**
 * @@@ Arquivo de Templante: 'sala.htm' @@@@
 * Inclui os arquivos iniciais nesses�rios.
**/
include_once("./config.php");
include_once("./global.php");
include_once("./biblioteca/fasttemplate.php");

/**
 * Limpa a sess�o para um novo usu�rio.
 * Grava dos dados na sess�o.
**/
$apelido_session = $apelido;
$cor_session     = $cor;
$careta_session  = $careta;
session_register("apelido_session", "cor_session", "careta_session");

/**
 * Inicia o sistema de templantes.
 * Carrega o templante solicitado.
**/
$model = new FastTemplate("./templates/$modelo");
$model->define(array("pagina" => "sala.htm"));

/**
 * Carrega o Banco de Dados e as Salas.
 * Lista as salas trocando as tags de sistema.
 * E exibindo o N�mero de Pessoas Online.
**/
$banco = new chat;
$lista = $banco->salas();
$total = count($lista);
$model->define_dynamic("salas", "pagina");
if ($total == "0") {
 $model->assign(array("{NOME}" => "S/S", "{DESC}" => "S/D", "{NUM}"  => "S/P", "{COD}"  => ""));
} else {
 for ($i = "0"; $i < $total; $i++) {
  $atual = $lista[$i];
  $model->assign(array("{NOME}" => $atual["nome"], "{DESC}" => ((empty($atual["desc"])) ? "S/D" : $atual["desc"]), "{NUM}" => $atual["cont"], "{COD}" => $atual["cod"]));
  $model->parse("SALAS", ".salas");
 }
}

/**
 * Troca as tags simples que sobrar�o.
 * E exibe o templante mudado.
**/
$model->assign("{TIME}", $tempo);
$model->parse("OUTPUT", "pagina");
$model->FastPrint("OUTPUT");
?>