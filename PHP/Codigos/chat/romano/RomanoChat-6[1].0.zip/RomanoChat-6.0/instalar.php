<?php
############################ ROMANO CHAT - MySQL #################################
#  Arquivo: instalar.php                                                         #
#  Cria��o: 02/Abril/2004 - 06:58 PM                                             #
#  Vers�o:  6.0 ALPHA 1(?)                                                       #
#  Autores: Comunidade Romano Chat - (Id�ia Original: Rodrigo Romano)            #
##################################################################################
#  Software Distribui��o: http://www.phpbrasil.com                               #
#  Suporte, N�ticias, Atualiza��es em: http://www.phpbrasil.com                  #
#  Software Comunidade: romanochat@yahoogrupos.com.br                            #
##################################################################################
# - Este � um programa gr�tis; podendo ser redistribuido e modificado, desde de  #
#  que n�o se retire os cr�ditos iniciais dos autores.                           #
# - Este programa tamb�m vem SEM NENHUMA GARANTIA, e tudo � por sua conta e      #
#  risco ao usa-lo voc� ficara respons�vel por tudo; insentado os autores.       #
# - Para mais informa��es leia o arquivo "licenca.txt", no diret�rio principal.  #
##################################################################################

/**
 * Inclui os arquivos iniciais nesses�rios.
**/
include_once("./config.php");
include_once("./global.php");

/**
 * Verifica todos as informa��es.
 * Seta os dados do arquivo "config.php".
 * Cria as Tabelas do sistema.
 * Envia as mensagens de erro.
**/
if (isset($submit)) {
 $conexao = @mysql_connect($in_host, $in_user, $in_pass);
 if (!$conexao) {
  $error = "Imposs�vel Conectar no Banco de Dados";
 } else if (!mysql_select_db($in_db, $conexao)) {
  $error = "Imposs�vel Selecionar Banco de Dados";
 } else if ($nome == "" OR $login == "" OR $senha == "") {
  $error = "Deve-se Insirir um Usu�rio Administrador";
 } else {
  $file_config = "./config.php";
  $configs = file($file_config);
  $totalf = count($configs);
  for ($i = "0"; $i < $totalf; $i++) {
   $config[$i] = trim($configs[$i]);
  }
  $config["23"] = "\$host = \"$in_host\";  // Host do MySQL";
  $config["24"] = "\$user = \"$in_user\";  // Usu�rio do MySQL";
  $config["25"] = "\$pass = \"$in_pass\";  // Senha do MySQL";
  $config["26"] = "\$db   = \"$in_db\";    // Banco de Dados";
  @chmod($file_config, 0777);
  $fp = fopen($file_config, "w");
  foreach ($config as $colunas){
   fwrite($fp, "$colunas\n");
  }
  fclose($fp);
  $file_sql = file("./tabelas.sql");
  $querys = explode(";", join("", $file_sql));
  $senha_encode = md5($senha);
  $querys[] = "INSERT INTO auth (login, pwd, name) VALUES ('$login', '$senha_encode', '$nome');";
  $querys[] = "INSERT INTO privs (login, priv) VALUES ('$login', 'master');";
  $total = count($querys);
  for ($i = "0"; $i < $total; $i++) {
   mysql_query($querys[$i], $conexao);
  }
  mysql_close($conexao);
  $concluido = "1";
 }
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Romano Chat</title>
<link rel="stylesheet" href="./templates/default/main.css" type="text/css">
</head>
<body bgcolor="#CFCFC1" text="#000000" topmargin="15" leftmargin="0" rightmargin="0" bottommargin="0">

 <form action="<?php echo $PHP_SELF; ?>" name="chat" method="post">
 <table width="55%" border="2" bordercolor="#996633" cellpadding="2" cellspacing="6" align="center" bgcolor="#919148">
  <tr bgcolor="#B9B391"><td valign="middle" align="right"><font size="4"><b><i>ROMANO CHAT + Instala��o +</i></b></font>&nbsp;</td></tr>
  <tr>
   <td align="center" valign="middle">
   <table width="99%" border="1" bordercolor="#996633" align="center" cellspacing="0" cellpadding="4">
<?php if (!isset($concluido)) { ?>
   <?php if (isset($error)) { ?>
    <tr bgcolor="#A0996B"><td align="center" colspan="2"><font color="#FFFF00" size="2" face="Verdana"><b><?php echo $error; ?></b></font></td></tr>
   <?php } ?>
    <tr bgcolor="#A0996B"><td align="right" colspan="2"><font size="2"><b>Configura��o do banco de dados (MySQL)</b></font>&nbsp;</td></tr>
    <tr bgcolor="#B9B391">
     <td align="center"><b>Host:</b></td>
     <td align="left"><input type="text" name="in_host" value="<?php echo $host;?>" size="30"></td>
    </tr><tr bgcolor="#B9B391">
     <td align="center"><b>Usu�rio:</b></td>
     <td align="left"><input type="text" name="in_user" value="<?php echo $user;?>" size="28"></td>
    </tr><tr bgcolor="#B9B391">
     <td align="center"><b>Senha:</b></td>
     <td align="left"><input type="password" name="in_pass" value="<?php echo $pass;?>" size="28"></td>
    </tr><tr bgcolor="#B9B391">
     <td align="center"><b>Banco:</b></td>
     <td align="left"><input type="text" name="in_db" value="<?php echo $db;?>" size="28"></td>
    </tr>
    <tr bgcolor="#A0996B"><td align="right" colspan="2"><font size="2"><b>Configura��es administrativas do Chat</b></font>&nbsp;</td></tr>
    <tr bgcolor="#B9B391">
     <td align="center"><b>Nome:</b></td>
     <td align="left"><input type="text" name="nome" value="<?php echo $nome;?>" size="25"></td>
    </tr><tr bgcolor="#B9B391">
     <td align="center"><b>Login:</b></td>
     <td align="left"><input type="text" name="login" value="<?php echo $login;?>" size="25"></td>
    </tr><tr bgcolor="#B9B391">
     <td align="center"><b>Senha:</b></td>
     <td align="left"><input type="password" name="senha" value="<?php echo $senha;?>" size="25"></td>
    </tr>
    <tr bgcolor="#B9B391"><td colspan="2" align="center"><input type="submit" name="submit" value=" Instalar "></td></tr>
<?php } else { ?>
    <tr bgcolor="#A0996B"><td align="right" colspan="2"><font size="2"><b>Instalado com Sucesso!!!</b></font>&nbsp;</td></tr>
    <tr bgcolor="#B9B391"><td align="left" colspan="2"><b>&gt; Sistema instalado com sucesso, as configura��es for�o alteradas, e o usu�rio criado.<br><br>
    &gt; Remova este aquivo <i>(instalar.php)</i>, para sua seguran�a e do seu servidor.<br><br>
    &gt; Para poder criar ou remover salas, bloquear usu�rios, entre na pasta <a href="./admin" class="A-Interno">admin</a> e utilize seu login e senha gerados nessa instala��o.<br><br><i>Boa Sorte!</i></b></td>
    </tr>
<?php } ?>
    </table></td>
   <tr align="left" valign="middle" bgcolor="#B9B391"><td height="25">&nbsp;<font size="2"><b>&copy; Rodrigo Romano - 2003</b></font></td></tr>
  </table>
 </form>

</body>
</html>