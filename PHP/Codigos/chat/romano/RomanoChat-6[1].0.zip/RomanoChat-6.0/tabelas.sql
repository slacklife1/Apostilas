# MySQL-Dump para ROMANO CHAT 6.0
# Tipo: Estrutura das Tabelas. 
# Data: 02/Abril/2004 - 11:40 PM
# --------------------------------------------------------

DROP TABLE IF EXISTS `adv`;
CREATE TABLE `adv` (
  `cod` int(11) NOT NULL auto_increment,
  `msg` mediumtext NOT NULL,
 PRIMARY KEY (`cod`)
) TYPE=MyISAM;
# --------------------------------------------------------

DROP TABLE IF EXISTS `auth`;
CREATE TABLE `auth` (
  `login` varchar(20) NOT NULL default '',
  `pwd` text NOT NULL default '',
  `name` varchar(75) NOT NULL default '',
 PRIMARY KEY (`login`)
) TYPE=MyISAM;
# --------------------------------------------------------

DROP TABLE IF EXISTS `block`;
CREATE TABLE block (
  `name` varchar(20) default NULL,
  `ip` varchar(32) default NULL,
  `data` datetime default NULL
) TYPE=MyISAM;
# --------------------------------------------------------

DROP TABLE IF EXISTS `logmsg`;
CREATE TABLE `logmsg` (
  `msg` mediumtext,
  `date` datetime default NULL,
  `rem` varchar(30) default NULL,
  `dest` varchar(30) default NULL,
  `som` varchar(20) default NULL,
  `tipo` varchar(10) default NULL,
  `sala` varchar(255) default NULL
) TYPE=MyISAM;
# --------------------------------------------------------

DROP TABLE IF EXISTS `msg`;
CREATE TABLE `msg` (
  `msg` mediumtext,
  `date` datetime default NULL,
  `rem` varchar(30) default NULL,
  `dest` varchar(30) default NULL,
  `som` varchar(20) default NULL,
  `tipo` varchar(10) default NULL,
  `sala` varchar(255) default NULL
) TYPE=MyISAM;
# --------------------------------------------------------

DROP TABLE IF EXISTS `privs`;
CREATE TABLE `privs` (
  `login` varchar(20) NOT NULL default '',
  `priv` varchar(20) NOT NULL default '',
 KEY login (`login`, `priv`)
) TYPE=MyISAM;
# --------------------------------------------------------

DROP TABLE IF EXISTS `salas`;
CREATE TABLE `salas` (
  `nome` varchar(25) default NULL,
  `descr` varchar(255) default NULL,
  `cod` varchar(32) default NULL,
  `date` datetime default NULL
) TYPE=MyISAM;
# --------------------------------------------------------

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `nome` varchar(20) default NULL,
  `careta` tinyint(2) NOT NULL default '0',
  `cor` varchar(7) default NULL,
  `date` datetime default NULL,
  `sala` varchar(255) default NULL,
  `uid` varchar(32) default NULL,
  `ip` varchar(32) default NULL
) TYPE=MyISAM;
# --------------------------------------------------------