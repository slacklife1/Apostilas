<?php

   /**********************************************************************
   * global.conf.php													 *
   * This is the main configuration file for the smileTAG                *
   * All configuration goes here except the smilies configuration        *
   **********************************************************************/
   
   //the username and password for admin page, the password is md5 encrypted
   //the default user is 'root' and the password is 'root'
   //you MUST change this after your first login !!
   $ADMIN_USERNAME = "root";
   $ADMIN_PASSWORD = "63a9f0ea7bb98050796b649e85481845";
   
   // set the maximum lenght for each message ( in character )  
   $MAX_LENGTH = 255; // default, each message allowed up to 255 characters
   
   // set the maximum number of message printed in the smiletag frame
   $MAX_MESSAGE = 20;
   
   //the file name which is used to store all the messages
   //make sure to include the full path if you change it to other place 
   //example $MESSAGE_FILE = "/home/john/secret/mymessage.txt";
   $MESSAGE_FILE = 'messages.dat';

   
   //if you want ip/nick banning feature change the value to 'ON'
   $BOARD_PROTECTION = 'ON';
   
   //banned ip adresses will stored into this file
   $HOSTS_BANNED_FILE = 'hosts.banned';

   //banned nicknames will stored into this file
   $NICKS_BANNED_FILE = 'nicks.banned';

   //set the interval for autoresh ( in seconds )
   $AUTOREFRESH_INTERVAL = 60; // default, autorefresh every 60 seconds

   //below is the background color setting for messages
   $MSG_BGCOLOR_1 = '#EFEFEF';
   $MSG_BGCOLOR_2 = '#FFFFFF';
?>