<?php

  /***********************************************************************
  * smiley.conf.php														 *
  * This is the configuration file for all smilies			             *
  ************************************************************************/

  //To add a new smiley you should add the pattern ($PATTERN[]) and the image ($IMAGE[]) for that pattern
  //Put all smiley images file to the 'images' directory
  //The PATTERN is case insensitive
  
  $PATTERN[0]	= ':)';
  $IMAGE[0]		= 'smile.gif';
  
  $PATTERN[1]	= ':\(';  //need backslash for character '('
  $IMAGE[1]		= 'sad.gif';

  $PATTERN[2]	= ';)';
  $IMAGE[2]		= 'wink.gif';	

  $PATTERN[3]	= ':O';
  $IMAGE[3]		= 'shock.gif';

  $PATTERN[4]	= ':D';
  $IMAGE[4]		= 'laugh.gif';

  $PATTERN[5]	= ':P';
  $IMAGE[5]		= 'tongue.gif';

  $PATTERN[6]   = ':\|';
  $IMAGE[6]		= 'blah.gif';

?>