<?php
	session_start();
	require '../conf/global.conf.php';
	require 'functions.inc.php';
	
	if(authenticated()){
		if(isset($_POST['submit'])){
		
			// add banned nicks to nicks.banned
			if(!empty($_POST['nick'])){
				
				global $NICKS_BANNED_FILE;
				if(!file_exists($NICKS_BANNED_FILE)){
					$NICKS_BANNED_FILE = "../".$NICKS_BANNED_FILE;
				}
				
				$file = @fopen($NICKS_BANNED_FILE,'a') or  die("Could not open file $NICKS_BANNED_FILE or permission denied");
				flock($file,2);
				for($i=0;$i<count($_POST['nick']);$i++){
					fputs($file, $_POST['nick'][$i]."\n");
				}
				flock($file,3);
				fclose($file);
				
			}
			
			// add banned ip addresses to hosts.banned
			if(!empty($_POST['address'])){
				
				global $HOSTS_BANNED_FILE;
				if(!file_exists($HOSTS_BANNED_FILE)){
					$HOSTS_BANNED_FILE = "../".$HOSTS_BANNED_FILE;
				}
				
				$file = @fopen($HOSTS_BANNED_FILE,'a') or  die("Could not open file $NICKS_BANNED_FILE or permission denied");
				flock($file,2);
				for($i=0;$i<count($_POST['address']);$i++){
					fputs($file, $_POST['address'][$i]."\n");
				}
				flock($file,3);
				fclose($file);
			}
			// delete selected messages from $MESSAGE_FILE
			if(!empty($_POST['delete'])){
				
				if(!file_exists($MESSAGE_FILE)){
					$MESSAGE_FILE = "../".$MESSAGE_FILE;
				}
				$file = @fopen($MESSAGE_FILE,'r') or die("Could not open file $MESSAGE_FILE or permission denied");
				
				
				flock($file,1);
				$i=0;
				while(!feof($file)){
					$raw_data[$i] = fgets($file,4096);
				$i++;
				}
				flock($file,3);
				fclose($file);
				
				
							
				$file = @fopen($MESSAGE_FILE,'w') or die("Could not open file $MESSAGE_FILE or permission denied");
				$raw_data_index = count($raw_data) - 1;	
				flock($file,2);
				for($i=0;$i<$raw_data_index;$i++){
					if( ! is_in_array($i,$_POST['delete'])){
						fputs($file,$raw_data[$i]);
					}
				}
				flock($file,3);
				fclose($file);
	
			}
	
		}
		display_messages();
	}else{
		echo '<br /><center><b>Unauthorized access attempt detected! Please Log In</b></center>';
	}

?>