<?php
	session_start();
	unset($_SESSION);
	session_destroy();
	echo "<br /><br /><center><b>Logged Out</b></center>";
	
	
?>