<?php
####################################################################################	
	//this function simply display login page
	function display_login(){
?>
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <title>SmileTAG Admin Page</title>
    <meta http-equiv="Content-Type"
    content="text/html; charset=iso-8859-1" />
  </head>

  <body bgcolor="#FFFFFF" text="#000000">
    <p>&#160;</p>

    <p>&#160;</p>

    <p>&#160;</p>

    <form name="form1" method="post"
    action="<?php echo $_SERVER['PHP_SELF']; ?>">
      <table cellspacing="1" cellpadding="0"
      width="46%" bgcolor="#CCCCCC" border="0" align="center">
        <tbody>
          <tr>
            <td valign="top" 
            bgcolor="#EFEFEF" height="12">
              <center>
                <font
                face="Arial, Helvetica, sans-serif"><b>Login</b></font>
              </center>
            </td>
          </tr>

          <tr>
            <td valign="top" height="142">
              <table cellspacing="0" cellpadding="5" width="100%"
              bgcolor="#ffffff" border="0" height="143">
                <tr>
                  <td valign="middle" align="left" height="73"
                  width="30%"><font
                  face="Arial, Helvetica, sans-serif">Username</font></td>

                  <td valign="middle" align="left" height="73"
                  width="70%"><input type="text" name="username"
                  size="25" /></td>
                </tr>

                <tbody>
                  <tr>
                    <td valign="middle" align="left" height="65"
                    width="30%"><font
                    face="Arial, Helvetica, sans-serif">Password</font></td>

                    <td valign="middle" align="left" height="65"
                    width="70%">
                      <p align="left"><input type="password"
                      name="password" size="25" /></p>
                    </td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
        </tbody>
      </table>

      <p align="center"><input type="submit" name="submit"
      value="Log in" /></p>
    </form>
  </body>
</html>
<?php
	}

####################################################################################
function display_menu(){
?>
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <title>SmileTAG Admin Page</title>
    <meta http-equiv="Content-Type"
    content="text/html; charset=iso-8859-1" />
  </head>

  <body bgcolor="#FFFFFF" text="#000000">
    <p>&#160;</p>

    <p>&#160;</p>

    <p>&#160;</p>

    <table  cellspacing="1" cellpadding="0"
    width="46%" bgcolor="#CCCCCC" border="0" align="center">
      <tbody>
        <tr>
          <td valign="top"  bgcolor="#EFEFEF"
          height="12">
            <center>
              <font face="Arial, Helvetica, sans-serif"><b>Admin Menu</b></font>
            </center>
          </td>
        </tr>

        <tr>
          <td valign="top" height="142">
            <table cellspacing="0" cellpadding="5" width="100%"
            bgcolor="#ffffff" border="0" height="143">
              <tr>
                <td valign="middle" align="left" height="44">
                  <div align="center">
                    <a href="configure.php"><font
                    face="Arial, Helvetica, sans-serif"
                    size="2">Board Settings</font></a>
                  </div>
                </td>
              </tr>

              <tr>
                <td valign="middle" align="left" height="48">
                  <div align="center">
                    <a href="mmanager.php"><font size="2"
                    face="Arial, Helvetica, sans-serif">Manage Messages</font></a>
                  </div>
                </td>
              </tr>

              <tbody>
                <tr>
                  <td valign="middle" align="left" height="51">
                    <p align="center"><a href="logout.php"><font
                    face="Arial, Helvetica, sans-serif"
                    size="2">Log Out</font></a></p>
                  </td>
                </tr>
              </tbody>
            </table>
          </td>
        </tr>
      </tbody>
    </table>

    <p align="center">&#160;</p>
  </body>
</html>
<?php
}

################################################################################
//this function checks whether the user already login before
//if yes, return TRUE
function authenticated(){
	global $ADMIN_PASSWORD;
	if(isset($_SESSION['admin']) && ($_SESSION['admin'] === $ADMIN_PASSWORD)){
		return TRUE;
	}else{
		return FALSE;
	}

}

################################################################################
// display messages for admin page
function display_messages(){
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
  <head>
    
    <style type="text/css">
/*<![CDATA[*/
body {
        font: 8pt Verdana,Arial,Helvetica,sans-serif; scrollbar-base-color: #efefef; background:#ffffff;color: #000000;
}
table{
        width:100%;border:0px;table-layout:fixed}
td{
        padding:0px 0px 0px 0px;font:8pt Verdana,Arial,Helvetica,sans-serif;word-wrap: break-word;
}
.name {
        font-weight: bold; color: #6699ff; font-size: 8pt; text-decoration: none
}
 /*]]>*/
    </style>

    <title>SmileTAG Admin Page</title>
    <meta http-equiv="Content-Type"
    content="text/html; charset=iso-8859-1" />
  </head>

  <body bgcolor="#FFFFFF" text="#000000">
    <p align="left"><a href="index.php">[ Admin Menu ]</a> <a
    href="logout.php">[ Log Out ]</a>&nbsp;</p>

    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
      <table cellspacing="1" cellpadding="0" width="100%"
      bgcolor="#CCCCCC" border="0" align="center">
        <tbody>
          <tr>
            <td valign="top" bgcolor="#EFEFEF" height="19">
              <center>
                <font face="Arial, Helvetica, sans-serif"><b><font
                size="2">Messages Manager</font></b></font>
              </center>
            </td>
          </tr>

          <tr>
            <td valign="top">
             <table cellspacing="10" cellpadding="5" width="100%"
             bgcolor="#ffffff" border="0">
        	  <tr>
                  <td valign="middle" align="left" width="12%">
                  <b><font face="Arial, Helvetica, sans-serif"
                  size="2">Nick</font></b></td>

                  <td valign="middle" align="left" width="57%">
                  <b><font face="Arial, Helvetica, sans-serif"
                  size="2">Message</font></b></td>

                  <td valign="middle" align="left" width="10%">
                  <b><font face="Arial, Helvetica, sans-serif"
                  size="2">Ban Nick</font></b></td>

                  <td valign="middle" align="left" width="13%">
                  <b><font face="Arial, Helvetica, sans-serif"
                  size="2">Ban Address</font></b></td>

                  <td valign="middle" align="left" width="8%">
                    <div align="left">
                      <b><font face="Arial, Helvetica, sans-serif"
                      size="2">Delete</font></b>
                    </div>
                 </td>
               </tr>

<?php
	global $MESSAGE_FILE;
	if(!file_exists($MESSAGE_FILE)){
		$MESSAGE_FILE = "../".$MESSAGE_FILE;
	}
	$file = fopen($MESSAGE_FILE,'r') or die("Could not open file $MESSAGE_FILE or permission denied");
	$line = 0;
	while(!feof($file)){
	
	   flock($file,1);
       $buffer = fgets($file,4096);
	   flock($file,3);

	   if(!$buffer) break;
	   //data[0] <= nickname ,data[4] <= ipaddress, data[5] <= message
	   $data = explode('||',$buffer);
		
	   echo	 '<tr>
                 <td bgcolor="#EFEFEF" valign="middle" align="left" width="12%" class="name">'.$data[0].'</td>
			     <td bgcolor="#EFEFEF" valign="middle" align="left" width="57%">'.$data[5].'</td>
                 <td bgcolor="#EFEFEF" valign="middle" align="left" width="10%">
                    <div align="center">
                      <input type="checkbox" name="nick[]"
                      value="'.$data[0].'" />
                    </div>
                  </td>

                  <td bgcolor="#EFEFEF" valign="middle" align="left" width="13%">
                    <div align="center">
                      <input type="checkbox" name="address[]"
                      value="'.$data[4].'" />
                    </div>
                  </td>

                  <td bgcolor="#EFEFEF" valign="middle" align="left" width="8%">
                    <div align="center">
                      <input type="checkbox" name="delete[]"
                      value="'.$line.'" />
                    </div>
                  </td>
                </tr>';		   
	$line++;  
	}
	fclose($file);

?>
			</table>
            </td>
          </tr>
        </tbody>
      </table>

      <p align="center"><input type="submit" name="submit"
      value="Update" /></p>
    </form>
  </body>
</html>

<?php	
}

####################################################################################
function display_settings(){
	global $ADMIN_USERNAME,$ADMIN_PASSWORD,$MAX_LENGTH,$MAX_MESSAGE,$MESSAGE_FILE,
		   $BOARD_PROTECTION,$HOSTS_BANNED_FILE,$NICKS_BANNED_FILE,
		   $AUTOREFRESH_INTERVAL,$MSG_BGCOLOR_1,$MSG_BGCOLOR_2; 
	



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <style type="text/css">
/*<![CDATA[*/
body {
        font: 8pt Verdana,Arial,Helvetica,sans-serif; scrollbar-base-color: #efefef; background:#ffffff;color: #000000;
}
table{
        width:100%;border:0px;table-layout:fixed}
td{
        padding:0px 0px 0px 0px;font:8pt Verdana,Arial,Helvetica,sans-serif;word-wrap: break-word;
}
.name {
        font-weight: bold; color: #6699ff; font-size: 8pt; text-decoration: none
}
 /*]]>*/
        </style>

    <title>SmileTAG Admin Page</title>
    <meta http-equiv="Content-Type"
    content="text/html; charset=iso-8859-1" />
  </head>

  <body bgcolor="#FFFFFF" text="#000000">
    <p align="left"><a href="index.php">[ Admin Menu ]</a> <a
    href="logout.php">[ Log Out ]</a>&nbsp;</p>

    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
      <table cellspacing="1" cellpadding="0" width="100%"
      bgcolor="#CCCCCC" border="0" align="center">
        <tbody>
          <tr>
            <td valign="top" bgcolor="#EFEFEF" height="19">
              <center>
                <font face="Arial, Helvetica, sans-serif"><b><font
                size="2">SmileTAG Settings</font></b></font>
              </center>
            </td>
          </tr>

          <tr>
            <td valign="top" >
              <table cellspacing="10" cellpadding="5" width="100%"
              bgcolor="#ffffff" border="0">
                <!-- Tabel mulai disini ===-->

                <tr>
                  <td valign="middle" align="left" width="34%">
                  <b><font face="Arial, Helvetica, sans-serif"
                  size="2">Properties</font></b></td>

                  <td valign="middle" align="left" width="66%">
                  <b><font face="Arial, Helvetica, sans-serif"
                  size="2">Settings</font></b></td>
                </tr>

                <tr>
                  <td valign="middle" align="left" width="34%"
                  class="name">Admin username</td>

                  <td valign="middle" align="left" width="66%">
                  <input type="text" name="ADMIN_USERNAME"
                  size="30" maxlength="50" value="<?php echo $ADMIN_USERNAME; ?>" /></td>
                </tr>

                <tr>
                  <td valign="middle" align="left" width="34%"
                  class="name">Admin password</td>

                  <td valign="middle" align="left" width="66%">
                  <input type="text" name="ADMIN_PASSWORD"
                  size="20" maxlength="50" /> (left blank or type a new one to change password )</td>
                </tr>

                <tr>
                  <td valign="middle" align="left" width="34%"
                  class="name">Maximum characters in a message</td>

                  <td valign="middle" align="left" width="66%">
                  <input type="text" name="MAX_LENGTH"
                  size="10" value="<?php echo $MAX_LENGTH; ?>" /></td>
                </tr>

                <tr>
                  <td valign="middle" align="left" width="34%"
                  class="name">Total messages allowed</td>

                  <td valign="middle" align="left" width="66%">
                  <input type="text" name="MAX_MESSAGE"
                  size="10" value="<?php echo $MAX_MESSAGE; ?>"/></td>
                </tr>

                <tr>
                  <td valign="middle" align="left" width="34%"
                  class="name">Message file name</td>

                  <td valign="middle" align="left" width="66%">
                  <input type="text" name="MESSAGE_FILE" size="35"
                  maxlength="150" value="<?php echo $MESSAGE_FILE; ?>" /> ( always use full path if
                  possible )</td>
                </tr>

                <tr>
                  <td valign="middle" align="left" width="34%"
                  class="name">IP/ Nick Banning feature
                  (ON/OFF)</td>

                  <td valign="middle" align="left" width="66%">
                  <input type="text" name="BOARD_PROTECTION"
                  size="5" maxlength="3" value="<?php echo $BOARD_PROTECTION; ?>"/>
				  </td>
                </tr>

                <tr>
                  <td valign="middle" align="left" width="34%"
                  class="name">Hosts banned file name</td>

                  <td valign="middle" align="left" width="66%">
                  <input type="text" name="HOSTS_BANNED_FILE"
                  size="35" maxlength="100" value="<?php echo $HOSTS_BANNED_FILE; ?>" /> ( always use full
                  path if possible )</td>
                </tr>

                <tr>
                  <td valign="middle" align="left" width="34%"
                  class="name">Nicks banned file name</td>

                  <td valign="middle" align="left" width="66%">
                  <input type="text" name="NICKS_BANNED_FILE"
                  size="35" maxlength="100" value="<?php echo $NICKS_BANNED_FILE; ?>" /></td>
                </tr>

                <tr>
                  <td valign="middle" align="left" width="34%"
                  class="name">Autorefresh interval ( in seconds
                  )</td>

                  <td valign="middle" align="left" width="66%">
                  <input type="text" name="AUTOREFRESH_INTERVAL"
                  size="10" maxlength="20" value="<?php echo $AUTOREFRESH_INTERVAL; ?>"/></td>
                </tr>

                <tr>
                  <td valign="middle" align="left" width="34%"
                  class="name">Message background color 1</td>

                  <td valign="middle" align="left" width="66%">
                  <input type="text" name="MSG_BGCOLOR_1" size="10"
                  maxlength="7" value="<?php echo $MSG_BGCOLOR_1; ?>"/></td>
                </tr>

                <tr>
                  <td valign="middle" align="left" width="34%"
                  class="name">Message background color 2</td>

                  <td valign="middle" align="left" width="66%">
                  <input type="text" name="MSG_BGCOLOR_2" size="10"
                  maxlength="7" value="<?php echo $MSG_BGCOLOR_2; ?>" /></td>
                </tr>
              </table>
            </td>
          </tr>
        </tbody>
      </table>

      <p align="center"><input type="submit" name="submit"
      value="Update" /></p>
    </form>
  </body>
</html>

<?php
}


###########################################################################

//This function is almost similar with array_search
//Searches haystack for needle and returns TRUE if it is found in the array,
//FALSE otherwise. 


function is_in_array($needle,$haystack)
{
	$return_value = FALSE;

	for($i=0;$i<count($haystack);$i++){
		if($needle == $haystack[$i]){
			$return_value = TRUE;
		}
	}
	return $return_value;
	
}
?>