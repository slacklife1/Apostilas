<?php
	session_start();
	require '../conf/global.conf.php';
	require 'functions.inc.php';
	
	if(authenticated()){
		if(isset($_POST['submit'])){
			
			if(!empty($_POST['ADMIN_USERNAME'])){ 
				$ADMIN_USERNAME = trim($_POST['ADMIN_USERNAME']);

			}
			
			if(!empty($_POST['ADMIN_PASSWORD'])){ 
				$ADMIN_PASSWORD = md5(trim($_POST['ADMIN_PASSWORD']));
			}
			if(!empty($_POST['MAX_LENGTH'])){ 
				$MAX_LENGTH = trim($_POST['MAX_LENGTH']);
			}	
			if(!empty($_POST['MAX_MESSAGE'])){ 
				$MAX_MESSAGE = trim($_POST['MAX_MESSAGE']);
			}
			if(!empty($_POST['MESSAGE_FILE'])){ 
				$MESSAGE_FILE = trim($_POST['MESSAGE_FILE']);
			}
			if(!empty($_POST['BOARD_PROTECTION'])){ 
				$BOARD_PROTECTION = trim($_POST['BOARD_PROTECTION']);
			}
			if(!empty($_POST['HOSTS_BANNED_FILE'])){ 
				$HOSTS_BANNED_FILE = trim($_POST['HOSTS_BANNED_FILE']);
			}
			if(!empty($_POST['NICKS_BANNED_FILE'])){ 
				$NICKS_BANNED_FILE = trim($_POST['NICKS_BANNED_FILE']);
			}
			if(!empty($_POST['AUTOREFRESH_INTERVAL'])){ 
				$AUTOREFRESH_INTERVAL = trim($_POST['AUTOREFRESH_INTERVAL']);
			}
			if(!empty($_POST['MSG_BGCOLOR_1'])){ 
				$MSG_BGCOLOR_1 = trim($_POST['MSG_BGCOLOR_1']);
			}
			if(!empty($_POST['MSG_BGCOLOR_2'])){ 
				$MSG_BGCOLOR_2 = trim($_POST['MSG_BGCOLOR_2']);
			}
			
			$file = @fopen('../conf/global.conf.php','w') or die('Could not open global.conf.php file or permission denied!');
			flock($file,2);
			fputs($file,"<?php\n");
			fputs($file,"# global.conf.php\n");
			fputs($file,"# This is the main configuration file for the smileTAG\n");
			fputs($file,"# All configuration goes here except the smilies configuration \n\n\n");
			fputs($file,'$ADMIN_USERNAME="'.$ADMIN_USERNAME."\";\n");
			fputs($file,'$ADMIN_PASSWORD="'.$ADMIN_PASSWORD."\";\n");
			fputs($file,'$MAX_LENGTH="'.$MAX_LENGTH."\";\n");
			fputs($file,'$MAX_MESSAGE="'.$MAX_MESSAGE."\";\n");
			fputs($file,'$MESSAGE_FILE="'.$MESSAGE_FILE."\";\n");
			fputs($file,'$BOARD_PROTECTION="'.$BOARD_PROTECTION."\";\n");
			fputs($file,'$HOSTS_BANNED_FILE="'.$HOSTS_BANNED_FILE."\";\n");
			fputs($file,'$NICKS_BANNED_FILE="'.$NICKS_BANNED_FILE."\";\n");
			fputs($file,'$AUTOREFRESH_INTERVAL="'.$AUTOREFRESH_INTERVAL."\";\n");
			fputs($file,'$MSG_BGCOLOR_1="'.$MSG_BGCOLOR_1."\";\n");
			fputs($file,'$MSG_BGCOLOR_2="'.$MSG_BGCOLOR_2."\";\n");
			fputs($file,'?>');
			flock($file,3);
			fclose($file);

		}
	
		display_settings();
	}
	else{
		echo '<br /><center><b>Unauthorized access attempt detected! Please Log In</b></center>';
	}
?>