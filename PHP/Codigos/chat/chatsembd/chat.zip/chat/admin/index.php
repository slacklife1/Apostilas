<?php
	session_start();

	require '../conf/global.conf.php';
	require 'functions.inc.php';
	
	
	if(authenticated()){
		display_menu();
	}
	else{
		if(!isset($_POST['username'])){
			display_login();
		}
		else if(md5($_POST['password']) === $ADMIN_PASSWORD){
			$_SESSION['admin'] = $ADMIN_PASSWORD;
			display_menu();
		}
		else{
		display_login();
		}
	}


?>
