<?php
    /****************************************************************************
	*																			*
	*	Copyright (C) 2002  SmileTAG Development Team							*
	*	http://smiletag.netstat.org/											*
	*																			*
	*	SmileTAG is free software; you can redistribute it and/or modify		*
	*	it under the terms of the GNU General Public License as published by	*
	*	the Free Software Foundation; either version 2 of the License, or		*
	*	(at your option) any later version.										*
	*																			*
	*	SmileTAG is distributed in the hope that it will be useful,				*
	*	but WITHOUT ANY WARRANTY; without even the implied warranty of			*
	*	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the			*
	*	GNU General Public License for more details.							*
	*																			*
	****************************************************************************/
	
	//get user input and remove the whitespaces
	$name		 = trim($_POST['name']);
	$mail_or_url = trim($_POST['mail_or_url']);
	$message	 = trim($_POST['message']);	
	$message_box = trim($_POST['message_box']);

	//if the browser doesn't support javascript, $message will empty 
	//so we have to get the message from $message_box
	if(!empty($message_box))
	   $message=$message_box;
	
	require './conf/global.conf.php';
	require './include/functions.inc.php';
	
	//make sure that user fill the name and the message,also check the length of the message 
	if( (!empty($name)) && (!empty($message)) && (strlen($message)<$MAX_LENGTH) ){ 
        
		//replace all newline with space
		$name		 = str_replace("\n"," ",$name);
		$message	 = str_replace("\n"," ",$message); 
        $mail_or_url = str_replace("\n"," ",$mail_or_url);
		
		//replace '||'  with space
		//cause we use '||' as delimiter when storing all data to the file
		$name		 = str_replace('||',' ',$name);
		$message	 = str_replace('||',' ',$message); 
        $mail_or_url = str_replace('||',' ',$mail_or_url);

		//filter all slashes and html tags
		$name		 = htmlspecialchars(stripslashes($name));
		$message     = htmlspecialchars(stripslashes($message));
		$mail_or_url = htmlspecialchars($mail_or_url);
		
		
		$hour	     = date ('g:i:s A');
		$date		 = date ('F d, Y');
		$ipaddress	 = $_SERVER["REMOTE_ADDR"];
		
			
		if(strtoupper($BOARD_PROTECTION) == 'ON'){
			if(host_banned($ipaddress) or nick_banned($name)){
				die("Your nick or IP address is banned from this board!");
			}
		
		}

		//concat all data  before saved to file with '||' as delimiter
		$buffer[0] = $name.'||'.$mail_or_url.'||'.$hour.'||'.$date.'||'.$ipaddress.'||'.$message."\n"; 
        $file = @fopen($MESSAGE_FILE,'r') or die("Could not open file $MESSAGE_FILE or permission denied"); 
        $line = 1; 

        flock($file,1);
		while( (!feof($file)) && ($line < $MAX_MESSAGE) ){  
            $buffer[$line] = fgets($file,4096);
            $line++;
        }
        flock($file,3);
		fclose($file);

        $file = @fopen($MESSAGE_FILE,'w') or die("Could not open file $MESSAGE_FILE or permission denied");       
		flock($file,2);
		for($i=0; $i<count($buffer);$i++){
            fputs($file,$buffer[$i]);
        }
		flock($file,3);
        fclose($file);
   	}
   
	header('Location: http://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']).'/view.php');
	

?>