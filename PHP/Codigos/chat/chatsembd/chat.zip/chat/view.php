<?php
    /****************************************************************************
	*																			*
	*	Copyright (C) 2002  SmileTAG Development Team							*
	*	http://smiletag.netstat.org/											*
	*																			*
	*	SmileTAG is free software; you can redistribute it and/or modify		*
	*	it under the terms of the GNU General Public License as published by	*
	*	the Free Software Foundation; either version 2 of the License, or		*
	*	(at your option) any later version.										*
	*																			*
	*	SmileTAG is distributed in the hope that it will be useful,				*
	*	but WITHOUT ANY WARRANTY; without even the implied warranty of			*
	*	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the			*
	*	GNU General Public License for more details.							*
	*																			*
	****************************************************************************/

   require './conf/global.conf.php';
   require './conf/smiley.conf.php';
   require './include/header.inc.php';
   
   //prepare the IMG tag for each smiley pattern
   for($i=0;$i<count($PATTERN);$i++)
      $IMAGE_TAG[$i]   = '<img alt="'.stripslashes($PATTERN[$i]).'" border="0" src="images/'.$IMAGE[$i].'" />';
    
   $file = @fopen($MESSAGE_FILE,'r') or die("Could not open file $MESSAGE_FILE or permission denied");
   $background = $MSG_BGCOLOR_1;
   
   while(!feof($file)){
	   flock($file,1);
       $buffer = fgets($file,4096);
	   flock($file,3);

	   if(!$buffer) break;
       
	   //data[0] <= name ,data[1] <= mail_or_url ,data[2] <= hour ,data[3] <= date
	   //data[4] <= ipaddress ,data[5] <= message
	   $data = explode('||',$buffer); 
       
	   //replace all smilies pattern into their IMG tag
	   for($i=0;$i<count($PATTERN);$i++)
	     $data[5] = eregi_replace($PATTERN[$i],$IMAGE_TAG[$i],$data[5]);
               
	   if($background == $MSG_BGCOLOR_1) 
		    $background = $MSG_BGCOLOR_2;		  
       else
		    $background = $MSG_BGCOLOR_1;

	   if(ereg("@",$data[1]))
	      echo '<tr><td bgcolor="'.$background.'"><span class="name" title="'.$data[3].' - '. $data[4].'"><a href="mailto:'.$data[1].'"><span class="name">'.$data[0].'</span></a>['.$data[2].']</span><br />'.$data[5].'</td></tr>';
	   else{
		  if(substr($data[1],0,7) != 'http://')
			 $data[1] = 'http://'.$data[1];	
		  echo '<tr><td bgcolor="'.$background.'"><span class="name" title="'.$data[3].' - '. $data[4].'"><a target="_blank" href="'.$data[1].'/"><span class="name">'.$data[0].'</span></a>['.$data[2].']</span><br />'.$data[5].'</td></tr>'; 
	   } 

   }
   fclose($file);

   echo '</table></body></html>';
?>
