<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="Refresh" content="<?php echo $AUTOREFRESH_INTERVAL; ?>" /> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
/*<![CDATA[*/
body {
	font: 8pt Verdana,Arial,Helvetica,sans-serif; scrollbar-base-color: #efefef; background:#ffffff;color: #000000;
}
table{
	width:100%;border:0px;table-layout:fixed}
td{
	padding:0px 0px 0px 0px;font:8pt Verdana,Arial,Helvetica,sans-serif;word-wrap: break-word;
}
.name {
	font-weight: bold; color: #6699ff; font-size: 8pt; text-decoration: none
}
 /*]]>*/
</style>
<title>SmileTAG</title>
</head>
<body>
<br />
<table cellspacing="0" cellpadding="0">