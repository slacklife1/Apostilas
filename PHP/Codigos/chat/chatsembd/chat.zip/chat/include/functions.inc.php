<?php
    /****************************************************************************
	*																			*
	*	Copyright (C) 2002  SmileTAG Development Team							*
	*	http://smiletag.netstat.org/											*
	*																			*
	*	SmileTAG is free software; you can redistribute it and/or modify		*
	*	it under the terms of the GNU General Public License as published by	*
	*	the Free Software Foundation; either version 2 of the License, or		*
	*	(at your option) any later version.										*
	*																			*
	*	SmileTAG is distributed in the hope that it will be useful,				*
	*	but WITHOUT ANY WARRANTY; without even the implied warranty of			*
	*	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the			*
	*	GNU General Public License for more details.							*
	*																			*
	****************************************************************************/

	
	//this function is used to check wheter an ip adress is listed in the hosts.banned file
	//if it does it will return true
	function host_banned($ip)
	{
		global $HOSTS_BANNED_FILE;
		
		$fp = @fopen($HOSTS_BANNED_FILE,'r') or die("Could not open $HOSTS_BANNED_FILE file or permission denied");
		
		flock($fp,1);
		while(!feof($fp)){
			if( $ip == trim(fgets($fp,4096)) ){
			flock($fp,3);
			fclose($fp);
			return true;
			}
		}
		flock($fp,3);
		fclose($fp);
		return false;
	}
	
	//this function is used to check wheter a nickname is listed in the nicks.banned file
	//if it does it will return true
	function nick_banned($nick)
	{
		global $NICKS_BANNED_FILE;
		
		$fp = @fopen($NICKS_BANNED_FILE,'r') or die("Could not open $NICKS_BANNED_FILE file or permission denied");
		
		flock($fp,1);
		while(!feof($fp)){
			if( strtoupper($nick) == strtoupper(trim(fgets($fp,4096))) ){
			flock($fp,3);
			fclose($fp);
			return true;
			}
		}
		flock($fp,3);
		fclose($fp);
		return false;
	}


?>