<?
include('config.conf');
$file_existe = file_exists('$file_msg');
if ($file_existe==null) {
$fd = @fopen( "$file_msg", 'a' ) or die( "Ocorreu um erro ao abrir o arquivo!!!");
$filesize= filesize("$file_msg");
fwrite($fd, $name_script, 1024);
fclose($fd);
}
else {

}
echo "<html>";
echo "<frameset rows=\"70%,*\" border=\"0\">";
echo "<frame src=\"$view\">";
echo "<frame src=\"$msg_box\">";
echo "</frameset>";

?>