<?
// esse script faz a mesma coisa que o anterior
$texto="huAUHAHUAUHAUHAUHAUH";
$fd = @fopen( 'teste.txt', 'w+' ) or die( "ops, avise o webmaster, tem arquivo faltando no servidor");
$filesize= filesize('config.conf');
$novidades = fread($fd ,$filesize);
fwrite($fd, $texto, 1024);
print $novidades;
fclose($fd);

?>
