<html>

<head>
<title>
chat cyber911
</title>
</head>
<body bgcolor="000000" text="808080" link="ffffff" alink="ffffff" vlink="808080">
<?
include('config.conf');
$msg_num=$msg_num + 1;
if ($nick!=null) {
if (($msg==null)&&($msg_num>1)) {
echo "Nick: $nick <form name=msg action=$msg_box>Msg:<input type=text name=msg><input type=hidden name=nick value=$nick><input type=hidden name=msg_num value=$msg_num><input type=submit value=OK></form><font color=\"red\">naum a mensagem a ser inviada!</font>";
}
else {
if ($msg_num > 1) {
$fd = @fopen( "$file_msg", 'a' ) or die( "Ocorreu um erro ao abrir o arquivo!!!");
$filesize= filesize("$file_msg");
fwrite($fd,$sysmsg, 1024);
fclose($fd);
}
echo "Nick: $nick <form name=msg action=$msg_box>Msg:<input type=text name=msg><input type=hidden name=nick value=$nick><input type=hidden name=msg_num value=$msg_num><input type=submit value=OK></form>";

  }
}
else {
if ($nick==null) {

echo "<form name=msg action=$msg_box>Nick:<input type=text name=nick><input type=submit value=OK></form>";
}
else {

echo "Nick: $nick <form name=msg action=$msg_box>Msg:<input type=text name=msg><input type=hidden name=nick value=$nick><input type=hidden name=msg_num value=$msg_num><input type=submit value=OK></form>";



  }

}
?>

</body>


</html>