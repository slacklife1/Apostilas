<?
include('config.conf'); 
$id = fopen($file_msg, "r"); 
$msg = fread($id,filesize($file_msg));
echo "$msg";
?>