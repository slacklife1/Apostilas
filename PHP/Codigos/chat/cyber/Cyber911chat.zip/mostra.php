<html>
<head>
<title>
</title>
</head>
<body bgcolor="000000" text="808080" link="ffffff" vlink="808080" alink="ffffff">

<?
include('config.conf'); 
$id = fopen("$file_msg", "r"); 
$msg = fread($id,filesize("$file_msg"));
echo "$msg";
?>

<script>
<!--




var limit="0:03"

if (document.images){
var parselimit=limit.split(":")
parselimit=parselimit[0]*60+parselimit[1]*1
}
function beginrefresh(){
if (!document.images)
return
if (parselimit==1)
window.location.reload()
else{ 
parselimit-=1
curmin=Math.floor(parselimit/60)
cursec=parselimit%60
if (curmin!=0)
curtime=curmin+" minutos e "+cursec+" segundos para dar refresh!"
else
curtime=cursec+" segundos para dar refresh!"
window.status=curtime
setTimeout("beginrefresh()",1000)
}
}

window.onload=beginrefresh
//-->
</script>

</body>

</html>