<?php

############################################################
#                                                          #
# T�tulo               : Forum 1.2                         #
# Criado por           : Lauro Assis Lima de Brito         #
# Data da Cria��o      : 01/09/2002                        #
# �ltima Atualiza��o   : 16/12/2002			#
# atualizado em 18/12/200 simplificando o sistema de email #
# que antes utilizava o mail() agora chama o programa de   #
#  correio do proprio usuario.				   #		   				  #
# E-mail	       : lab.design@uol.com.br  	   				  #
# Home Page            : http://www.labdesign.d2g.com      #
# ymessenger  ID	     : lauro_lab			   				  #
#                                                          #
############################################################

############################################################
#                                                          #
#     Esse script foi criado e distribu�do livremente por  #
# 		www.phpbrasil.com,  pode ser modificado de modo	     #
# 		que seja respeitado o coment�rio acima.              #
#     Caso tenha gostado desse script me mande um e-mail!  #
#     Bugs e coment�rios - lab.design@uol.com.br 	        #
#      * Se alterar este script para melhor me avise!	     #
#                                                          #
############################################################
// voce deve alterar o host para apontar para o ip onde esta o mysql, caso nao seja localhost.
// voce deve alterar o nome da database conforme o nome no banco de dados mySQL
// Caso o seu Banco de dados exija senha, altera o $pwdDB sen�o deixe em branco ("")


include('global.php');

//N�o precisa editar ap�s essa linha//

$action=$QUERY_STRING;
$pagename=$PHP_SELF;

/* fazendo conex�o com o banco de dados */
mysql_connect($host, $userDB, $pwdDB) or die (mysql_error());
@mysql_select_db( "$dataBase") or die( "database n�o pode ser selecionada");
?>

<html>
	<head>
		<meta http-equiv=\"Content-Language\" content=\"en-us\">
		<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">
		<title>LAB-Forum 1.2 - criado por Lauro A Lima de Brito</title>
		<style>
			<!--
				textarea     { font-family: Tahoma; font-size: 8pt; padding: 3 }
				input        { font-family: Tahoma; font-size: 8pt;  }
				select        { font-family: Tahoma; font-size: 8pt; }
				a {text-decoration: none}
				A:hover {color: #003399; text-decoration: underline}
				-->
		</style>
	</head>

	<body bgcolor=#ffffff text=#006699 link=#808080 vlink=#808080 alink=#006699 style=font-family: Verdana>
		<font face=Arial size=2><center>
			<p><a href="http://www.labdesign.d2g.com" target="_blank">
				<img border="0" src="images/logolab_topo.gif" alt=""></a></p>
				<b>Forum 1.2 - Instalar</b></center>		
<?
	if($action == 'criar') {
	$create= "CREATE TABLE $tablename (
		id_forum MEDIUMINT(9) AUTO_INCREMENT NOT NULL,
		id_grupo MEDIUMINT(9),
		id_resposta MEDIUMINT(9),
		titulo VARCHAR(255),
		comentario text,
		data TIMESTAMP(14),
		nome VARCHAR(50),
		email VARCHAR(100),
		hits MEDIUMINT(9) DEFAULT '0' NOT NULL,
		PRIMARY KEY (id_forum))";		
		
	$exec = MYSQL_QUERY($create) or die(mysql_error());
 	if($exec == 1) {
 		echo "<br><br><center>Tabela criada com sucesso, Utilize o arquivo <b><a href=\"index.php\">index.php</b></a><br>para verificar se o forum est� em funcionamento!<br>A seguir delete este arquivo <b>install.php</b> por motivo de seguran�a</center>";
 		}
 	else {
 		echo "<br><br><center><font color=\"#FF0000\">Ocorreu um erro. Ou j� existe uma tabela com esse nome. Tente novamente</font></center>";
 	}
 } 
else {
	echo "<center>";
	echo "<br><br><a href=\"$pagename?criar\">Clique aqui para instalar</a><br><br>";
	echo "</center>";
}

echo "<br><br><center>Desenvolvido por <a href=\"mailto:lab.design@uol.com.br\">Lauro</a></font></center>\n</body>\n</html>";

MYSQL_CLOSE();
?>