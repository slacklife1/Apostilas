<?
include("global.php");

// Pagina de Forum

// Conexao com o banco de dados atrav�s da API mysql.php
$conn = mysql_connect($host,$userDB, $pwdDB);
mysql_select_db($dataBase);

// Checa numero da pagina
$id=$HTTP_GET_VARS["id"];
if ($id=="") {
	$id=$HTTP_POST_VARS["id"]; }

$pagAtual = $HTTP_POST_VARS["pagAtual"];

if ($pagAtual == "") {
	$pagAtual = 0; }
	
$dir = $HTTP_POST_VARS["dir"];	

$sql = "select * from forum where id_forum=$id";
$query = mysql_query($sql, $conn);
$question = mysql_fetch_array($query);


$sql = "select * from forum where id_resposta=$id order by id_forum desc";
$query = mysql_query($sql,$conn);
$pagesize = 3;
$maxRec = mysql_num_rows($query);
$maxPage = $maxRec / $pagesize;
$maxPage = (int)$maxPage;

// Fim da conexao
?>

<table border="0" width="465">
	<tr>
		<td align="center" class="tmenu" colspan="2">Grupo de Discuss�es</td>
	</tr>
	<tr>
		<td><a href="index.php?todo=insert&grupo=<?= $question["id_grupo"] ?>">Inserir Quest�o</a></td>
		<td align="right"><font class="normal"><a href="index.php?id=<?= $id ?>&todo=insert">
			Inserir Coment�rio</a></b></td>
	</tr>
</table>

<table border="0" width="465">
	<tr><td class="menu" width=50>Quest�o:</td>
		<td bgcolor="#efefef"><font color=#006699><b><?= $question["titulo"] ?></b</font></td></tr>

	<tr><td class="menu" width=50>Coment.:</td>
		<td bgcolor="#efefef"><font color=#006699><b><?= $question["comentario"] ?></b</font></td></tr>

	<tr>
	<? $data = substr($question["data"], 0, 8);		
		if (strlen($data) > 0)				
			$data = substr($data, -2) . "/" . substr($data, 4, 2) . "/" . substr($data, 0, 4); 
		$email = $question["email"];
		?>
		<td align="center"><?= $data ?></td>
		<td bgcolor="#efefef"><a href="mailto:<?= $question["email"] ?>">
			<img src="images/email.gif" border=0>&nbsp;&nbsp;<?= $question["nome"] ?></a></td></tr>
	<tr><td colspan="2"><hr size="1"></td>
	</tr>
</table>
   <?	
// Checa se existem dados no banco de dados

if ($maxRec)	{
	 if ($dir=="Pr�ximo >>") {
		  if ($pagAtual < $maxRec) {
				 $pagAtual++; }
		 }
	  elseif ($dir =="<< Anterior") {
		  if ($pagAtual > 0) {
				$pagAtual = $pagAtual - 1;	}
		}
		
		$counter = 0;
		$offset = $pagAtual*$pagesize;
	
		mysql_data_seek($query, $offset);
		
		echo "<table border=0 cellpadding=1 width=465>";
		
	While ($counter < $pagesize && $counter+$offset < $maxRec)  {
		
		$result = mysql_fetch_array($query);
		$data = substr($result["data"], 0, 8);
		$email = $result["email"];
		$data = substr($data, -2) . "/" . substr($data, 4, 2) . "/" . substr($data, 0, 4);
		$email = $result["email"];
		?>
			<tr><td class="menu" width=50>Titulo:</td>
				<td bgcolor="#efefef"><?= $result["titulo"] ?></td></tr>
				
			<tr><td class="menu" width=50>Coment.:</td>
				<td bgcolor="#efefef"><?= $result["comentario"] ?></td></tr>
				
			<tr><td align="center" width=50><?= $data ?></td>
				<td bgcolor="#efefef"><a href="mailto:<?= $email ?>">
					<img src="images/email.gif" border=0>&nbsp;&nbsp;<?= $result["nome"] ?></a></td></tr>

			<tr><td colspan="2"><hr size="1"></td></tr>
<?       
      $counter ++;
		}	// while
?>			</table>
			<form action="index.php?todo=red&grupo=$grupo" method="POST">
				<table width="465">
					<tr><td align=right">
			<?
						if ($pagAtual > 0) {
							echo "<INPUT type=\"submit\" value=\"<< Anterior\" name=dir class=but>"; }

						echo "</td>";
						echo"<td align=right width=\"50%\">";
						if ($pagAtual < $maxPage) {
							echo "<INPUT type=\"submit\" value=\"Pr�ximo >>\" name=dir class=but>"; }

						echo"</td>";

						echo "<INPUT type=hidden name=\"pagAtual\" value=\"$pagAtual\">\n";
						echo "<INPUT type=hidden name=\"id\" value=$id>\n"; }
			?>
					</td></tr>
				</table></form>
<?
	mysql_free_result($query);
	mysql_close($conn);
?>	