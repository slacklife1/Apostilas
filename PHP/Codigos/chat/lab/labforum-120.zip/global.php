<?php

	// -- O caminho do banco de dados
	
	// altere os dados abaixo conforme sua base de dados mySQL

	$host = "localhost";
	$dataBase = "lab";
	$userDB = "lab";
	$pwdDB = "lab089200";
	
	$tablename = "forum";

?>