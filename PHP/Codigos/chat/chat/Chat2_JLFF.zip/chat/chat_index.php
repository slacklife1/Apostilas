<?
  if($arquivo = fopen("chat.txt", "a")){
    $horas = date("H") . ":" . date("i") . ":" . date("s");
    $frase = "<b>" . $nick . "</b> entra na sala �s " . $horas;
    fputs($arquivo, $frase . "\n");
    fclose($arquivo);
  }
  else{
    echo "Ops! Algo saiu errado";
  }
?>

<html>
<head>
<title>Sala de Bate-Papo PHP</title>
</head>

<frameset rows="100,299,61" cols="*" frameborder="no"> 
  <frame src="chat_topo.htm" scrolling="NO">
  <frame src="chat_mensagens.php">
  <frame src="chat_baixo.php?usuario=<? echo $nick; ?>">
</frameset>
<noframes><body bgcolor="white" text="black">

</body></noframes>
</html>
