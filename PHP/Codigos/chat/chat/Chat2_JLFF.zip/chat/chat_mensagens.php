<html>
<head>
<title>Sala de Bate-Papo PHP</title>
<meta http-equiv="refresh" content="5">

<style type="text/css">
<!--
  body {font: 80% verdana}
//-->
</style>

</head>
<body bgColor="white" onload="document.body.scrollTop='7000'">

<?
  if($arquivo = fopen("chat.txt", "r")){
    while(!feof($arquivo)){
      $linhas[] = fgets($arquivo, 300);
    }
    fclose($arquivo);
  }
  else{
    echo "Ops! Algo saiu errado";
  }
  
  if($arquivo = fopen("chat.txt", "w")){
    $quant = count($linhas) - 2;
    $exibir = 20;
    for($i = 0; $i < count($linhas); $i++){
      $linhas[$i] = eregi_replace("\n", "", $linhas[$i]);
      $linhas[$i] = eregi_replace("\r", "", $linhas[$i]);
      echo "<br>"  . $linhas[$i];
      if($i > ($quant - $exibir)){
        if(strlen($linhas[$i]) > 2){
          fputs($arquivo, $linhas[$i] . "\n");
        }
      }      
    } 
    fclose($arquivo); 
  }
  else{
    echo "Ops! Algo saiu errado";
  }
?>

</body>
</html>
