<?
  if($controle){
    if($arquivo = fopen("chat.txt", "a")){
      $frase = "<b>" . $usuario . "</b>: " . $fala;
      fputs($arquivo, $frase . "\n");
      fclose($arquivo);
    }
    else{
      echo "Ops! Algo saiu errado";
    }
  }
?>

<html>
<head>

<style type="text/css">
<!--
  body {font: 80% verdana}
//-->
</style>

</head>
<body bgcolor="yellow" onload="document.chat.fala.focus()">

<form name="chat" action="<? echo $PHP_SELF ?>" method="post">
  <label>Mensagem:</label>
  <input type="text" name="fala" size="50">
  <input type="submit" value="Enviar!">
  <input type="hidden" name="controle" value="gravar">
  <input type="hidden" name="usuario" value="<? echo $usuario; ?>">
</form>

</body>
</html>
