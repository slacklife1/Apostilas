<?php
/* 
   BFCTemplate-PHP Version 1
   CREATED BY: Christopher Brown-Floyd
   Email: chris@bfworld.com
   DATE CREATED: May 25, 2001
*/
class template {
 var $thistemplate=""; //The current template is stored in this variable

 // This function loads a file into the template object
 function usetemplate($pathfilename) {
  $this->thistemplate = $this->gettemplate($pathfilename,false);
 }
 
 // This function returns a template file; however, it's not loaded into the object
 function gettemplate($pathfilename,$encodetohtml) {
  $temptemplate = "";
  if (file_exists($pathfilename)) {
   $templatefp = fopen($pathfilename, "r");
   if (!feof($templatefp)) {
    $temptemplate = fread($templatefp,filesize($pathfilename));
   }
   fclose($templatefp);
  }
  if ($encodetohtml) {
   $temptemplate = $this->tohtml($temptemplate);
  }
  return $temptemplate;
 }

 // This function replaces tags with the specified text
 function tag($tagname,$uservalue) {
  $tagstart = 0;
  $tagend = 0;
  $divstart = "";
  $divend = "";
  $tagparams = "";
  $ld = "<tag:" . $tagname;
  $rd = "/>";
  $starttagend = 0;
  $starttaglen = strlen($ld);
  $temptemplate = $this->thistemplate;

  while (($tagstart<=strlen($temptemplate)) && ($tagstart>=0)) {
   $tagstart = strpos($temptemplate,$ld,$tagstart);
   if (!$tagstart) {break;}
   if ($tagstart>=0) {
    $tagend = strpos($temptemplate,$rd,$tagstart);
    $starttagend = $tagstart + $starttaglen;

    if ($tagend>$starttaglen) {
     $tagparams = trim(substr($temptemplate,$tagstart+$starttaglen,$tagend-$starttagend));
     if ($tagparams) {
      $divstart = "<div " . $tagparams . ">";
      $divend = "</div>";
     }
     $temptemplate = substr($temptemplate,0,$tagstart) . $divstart . $uservalue . $divend . substr($temptemplate,$tagend+2);
     $tagstart = $tagend+2;
    }
   }
  }
  $this->thistemplate = $temptemplate;
 }

 // This function saves the current state of the loaded template
 function saveas($pathfilename) {
  if (file_exists($pathfilename)) {
   rename($pathfilename,$pathfilename . ".bak");
  }
  $templatefp = fopen($pathfilename, "w");
  $fout = fwrite($templatefp,$this->thistemplate);
  fclose($templatefp);
 }

 // Displays the template to the browser
 function display() {
  echo($this->thistemplate);
 }


 // Encodes the template into HTML
 function htmlencode() {
  $this->thistemplate = $this->tohtml($this->thistemplate);
 }


 // Encodes text to HTML
 function tohtml($temptemplate) {
  $phpcrlf = chr(13).chr(10);
  $temptemplate = str_replace("&","&amp;",$temptemplate);
  $temptemplate = str_replace("<","&lt;",$temptemplate);
  $temptemplate = str_replace(" ","&nbsp;",$temptemplate);
  $temptemplate = str_replace($phpcrlf,"<br />",$temptemplate);
  return $temptemplate;
 }


 // Removes any remaining tags in the template
 function removetags() {
   $tagstart = 0;
   $tagend = 0;
   $ld = "<tag:";
   $rd = "/>";
   $starttaglen = strlen($ld);
   $temptemplate = $this->thistemplate;

   while (($tagstart<=strlen($temptemplate)) && ($tagstart>=0)) {
    $tagstart = strpos($temptemplate,$ld,$tagstart);
    if (!$tagstart) {break;}
    if ($tagstart>=0) {
     $tagend = strpos($temptemplate,$rd,$tagstart);

     if ($tagend>$starttaglen) {
      $temptemplate = substr($temptemplate,0,$tagstart) . substr($temptemplate,$tagend+2);
      $tagstart = $tagend+2;
     }
    }
   }
   $this->thistemplate = $temptemplate;
 }
}
?>