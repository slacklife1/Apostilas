     The following php code is fairly simple to implement on your site and can make
web page creation very easy if you use a standard format and only change the content
of the page. I use a very similar code on my site at http://www.netlocity.net including
the FAQ section in this code. I will try and explain how it works to give you a
better understanding of how to use it. You are free to use this code and change it any
way you like. Enjoy :-)

     Site setup:
   
   Before you upload this code to your site, you will need to do some simple setup of 
the db_api.php file found in the main directory of the site. This file holds the database 
information for connecting to the database. It also holds a variable to limit the number 
of faq questions that will show up per page. By default, its set at 3. Adjust the db_api.php 
file as needed, then upload the code to your site. Be sure to keep the structure intact.

   Hint for coders: try and stay away from using none php extensions when creating files 
                    that hold password and connection information. I have noticed some 
                    coders using a .inc file to hold their information, unfortunately most 
                    web servers do not know what to do if this file is called by itself from 
                    a web browser and will normally spew it out as text. This can be a security
                    issue for people holding private information in a database. Giving the file 
                    a .php extensions will cause the file to spew out an error or blank 
                    when called on its own by a web browser protecting the information in the file.

    Once you have uploaded the code, open your web browser and goto:

        http://{your web site}/{code you uploaded directory}/admin/create_faq_table.php 

   This will autocreate the database tables into the database specified in the db_api.php file. 
(this may not always work, some database admins do not allow the creation of tables from a web 
inteface, you will have to create it manually, if this is the case, the structure is listed below.)

Create TABLE faq_table (
id INT(10) NOT NULL AUTO_INCREMENT,
question VARCHAR(255) NOT NULL,
answer TEXT NOT NULL,
PRIMARY KEY(id)
);

     Now that you have a database structure, you need to fill it up with information. If the create_faq_table.php
file worked, you should have been forwarded to the admin interface index.php file. Here you can add, update
and delete FAQ files as needed. Load up the database with some FAQs, then goto:

        http://{your web site}/{code you uploaded directory}/

To see the script work. 


     There are other aspects of this code that can help make website creation much easier. If you open the
index.php file, you will notice there is no html code in it, instead I am using "include" to grab information
from 3 txt files to create the site. This is excellent if you have a webiste with a standard template where only
the content changes. With the if statement in the index file, you can call other txt files into the template using
the URL which can change the content, but cut down the coding time and make it easier to update a site. If no
variables are passed to the if statement in the form of "PG=", the script will grab the main index file. EX:
(index.php?PG=faq    <-- replaces index.txt with faq.txt which incases the faq.txt content inside the header.txt
and footer.txt html code which basically creates the site on the fly.)

     The admin interface uses "Header("Location: index.php");" to redirect the surfer to another page. This is
nice for submission forms. (note that this action only works if no html code is passed to the browser first, if a
site is half way loaded, passing this to the browser will yield an error)

   I have attempted to comment the faq.txt file with more information on how the code works and what is going on
behind the scenes. I am sure there are other ways to make this same process work, but this is the easiest that I
can come up with. Hope this code helps, if you happen to make any cool changes to the code, let me know so I can
check it out, send me an e-mail to fletch@netlocity.net

Enjoy :)




