<?

include("header.txt"); //simple include statement to spew out the information in the header.txt file

if ($PG != "") {
include("$PG.txt"); //an if statement that will throw back the index.txt file if there is on PG variable passed.
} else {
include("index.txt");
}


include("footer.txt"); //simple include statement to spew out the information in the footer.txt file

// This is pretty simplistic, but can make is much easier for creating a site. Check the readme.txt for more info.
?>