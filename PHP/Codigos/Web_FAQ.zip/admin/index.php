<Head>
<Title>FAQ Admin Interface</Title>
</Head>
<Body>
<?
echo "<ul>";
echo "<li><a href='add.php'>Add an FAQ</a></li>";
echo "<li><a href='update.php'>Update an FAQ</a></li>";
echo "<li><a href='remove.php'>Delete an FAQ</a></li>";
echo "</ul>";
?>
</body>

