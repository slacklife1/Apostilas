<?
require("../db_api.php");

echo "Select the FAQ to update, and then SUBMIT!<br><br>";
echo "<TABLE BORDER=\"0\" CELLPADDING=\"10\" CELLSPACING=\"10\"><TR>";
echo "<FORM ACTION=\"./update2.php\" METHOD=\"POST\">";

echo "<tr><td>";
echo "<select name=\"id\" size=\"1\">";
mysql_connect("$DataHost","$DataUser","$DataPass");
$result=mysql("$DataName","SELECT * FROM faq_table ORDER BY question");
while ($row = mysql_fetch_row($result)) {
echo "<option value='$row[0]'> $row[1] </option>";
}
echo "</select></td></tr>";
echo "<tr><td align=\"center\"><INPUT TYPE=\"submit\" NAME=\"Submit\" VALUE=\"Submit\"></form></TABLE>";

?>
