<?
require("../db_api.php");

mysql_connect("$DataHost","$DataUser","$DataPass");
mysql("$DataName","UPDATE faq_table
SET question='$question',
answer='$answer'
WHERE id='$id'");

Header("Location: index.php");
?>
