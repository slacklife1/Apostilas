<?
require("../db_api.php");

mysql_connect("$DataHost","$DataUser","$DataPass");

mysql("$DataName","DELETE FROM faq_table WHERE id='$id'");


Header("Location: index.php");
?>
