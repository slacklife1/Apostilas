<?
require("../db_api.php");


mysql_connect("$DataHost","$DataUser","$DataPass");
mysql("$DataName","INSERT INTO faq_table VALUES(
'$id',
'$question',
'$answer')");

Header("Location: index.php"); //forward the connection back to the index.php file.

?>
