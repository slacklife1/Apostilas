<?
require("../db_api.php");

mysql_connect("$DataHost","$DataUser","$DataPass");
$result=mysql("$DataName","SELECT * FROM faq_table WHERE id = '$id'");
while($row=mysql_fetch_row($result)) {
$id=$row[0];
$qa=$row[1];
$an=$row[2];
}
echo "Type the new data into the boxes, and then SUBMIT!<br><br>";
echo "<TABLE BORDER=\"0\" CELLPADDING=\"10\" CELLSPACING=\"10\"><TR>";
echo "<FORM ACTION=\"updatefaq.php\" METHOD=\"POST\">";

echo "<textarea name=\"question\" rows=\"10\" cols=\"50\" wrap>$qa</textarea></td></tr><br><tr><td>";
echo "<textarea name=\"answer\" rows=\"10\" cols=\"50\" wrap>$an</textarea></td></tr>";
echo "<input type=\"hidden\" name=\"id\" value=\"$id\">";
echo "<tr><td colspan=\"2\" align=\"center\"><INPUT TYPE=\"submit\" NAME=\"Submit\" VALUE=\"Submit\"></form></TABLE>";
?>
