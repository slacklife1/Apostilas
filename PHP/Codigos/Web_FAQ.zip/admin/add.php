<?

echo "Type your new FAQ into the boxes, and then SUBMIT!<br><br>";
echo  "<TABLE BORDER=\"0\" CELLPADDING=\"10\" CELLSPACING=\"10\"><TR>";
echo "<FORM ACTION=\"addfaq.php\" METHOD=\"POST\">";

echo "<tr><td>FAQ Question<br>";
echo "<textarea name=\"question\" rows=\"10\" cols=\"50\" wrap></textarea></td></tr><Br><br>";

echo "<tr><td>FAQ Answer<br>";
echo "<textarea name=\"answer\" rows=\"10\" cols=\"50\" wrap></textarea></td></tr>";

echo "<input type=\"hidden\" name=\"id\" value=\"\">";

echo "<tr><td colspan=\"2\" align=\"center\"><INPUT TYPE=\"submit\" NAME=\"Add\" VALUE=\"Submit\"></form></TABLE>";

?>
