<?
              require("../db_api.php");

		$db = mysql_connect( $DataHost, $DataUser, $DataPass );
		mysql_select_db( $DataName );
	
		$query1 = "CREATE TABLE faq_table (
                           id INT(10) NOT NULL AUTO_INCREMENT,
                           question VARCHAR(255) NOT NULL,
                           answer TEXT NOT NULL,
                           PRIMARY KEY (id)
                           )";

		
		mysql_query( $query1 ) or error( mysql_error() );
		mysql_close( $db );

Header("Location: index.php");

?>