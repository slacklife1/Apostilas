<?
        
// Database server information
$DataHost="Change Me"; // Database server host
$DataUser="and Me"; // Database Username
$DataPass="Me to"; //Database Password
$DataName="don't forget about me"; //Database Name

$li = "3"; //how many FAQs per page.


?>
