Title: Web FAQ from a MySql DB
Description: This is a fairly simplistic script to allow web masters to add an FAQ section to their website using a MySql database. (might be good for those offering software). Portions of the code are heavily commented along with an auto table creation script for faster setup. Also shows how to use simple if statements, includes and template driven websites using PHP. If you want to see this script in action, goto http://www.netlocity.net and click on FAQ.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=542&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
