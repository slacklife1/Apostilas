<?php

#
# Webagentur web4.hm
# Pyrmonterstr. 42
# D-31789 Hameln
# Internet: www.web4.hm, EMail: contact@web4.hm
# Tel: +49 (0) 5151 / 60 99 700
# Fax: +49 (0) 5151 / 60 99 701
# 
# phpMySearch
# Internet: http://web4.hm/phpMySearch, Email: phpMySearch@web4.hm
#
# Diese Software und Dokumentation, darf frei genutzt werden, solange diese Lizenz und der Copyright-Hinweis, in der Software,
# Dokumentation und am Ende der Ausgabe erhalten bleibt.
#
# �nderungen am HTML-Code d�rfen uneingeschr�nkt vorgenommen werden.
# �nderungen am Source-Code d�rfen ebenfalls vorgenommen werden,
# wenn der ver�nderte Code an phpMySearch@web4.hm zugemailt wird.
#
#
# Copyright (c) 2001 Webagentur web4.hm.
# Es wird die Erlaubnis gegeben dieses Dokument zu kopieren, verteilen und/oder
# zu ver�ndern unter den Bedingungen der GNU Free Documentation License,
# Version 1.1 oder einer sp�teren, von der Free Software Foundation
# ver�ffentlichten Version. Eine Kopie dieser Lizenz ist in
# dem Abschnitt enthalten, der mit "GNU Free Documentation License"
# betitelt ist.
#
#
# Copyright (c) 2001 Webagentur web4.hm.
# Permission is granted to copy, distribute and/or modify this document
# under the terms of the GNU Free Documentation License, Version 1.1
# or any later version published by the Free Software Foundation.
# A copy of the license is included in the section entitled "GNU
# Free Documentation License".
#
#

include_once("./Template/class.FastTemplate.php");
include_once("./GutLibs/class.SessionManager.inc.php");
include_once("./GutLibs/class.Log.inc.php");
include_once("Src/class.AdminConfig.inc.php");
include_once("Src/class.SpiderState.inc.php");
include_once("Src/class.SpiderEngine.inc.php");

global   $HTTP_POST_VARS;



$adminConfig = &AdminConfigInstance();
$log = &LogInstance($adminConfig->param("adminConfigLogFileName"));
$errMess = "";

$tpl = new FastTemplate($adminConfig->param("templatesPath"));
$tpl->define
 (array
  (
   'adm_checkblock'       => "adm_checkblock.tpl",
   'adm_checkitem'        => "adm_checkitem.tpl",
   'adm_main'             => "adm_main.tpl",
   'adm_login'            => "adm_login.tpl",
   'adm_empty_checkblock' => "adm_empty_checkblock.tpl",
   'body_error'           => "body_error.tpl"
  ));

// Creation of session controller copy

$manager  = new SessionManager
                ($adminConfig->param("DBName"),
                 $adminConfig->param("DBHost"),
                 $adminConfig->param("DBUser"),
                 $adminConfig->param("DBPassword"));

$newSessionFlag = false;

if     (isset($HTTP_POST_VARS["clearTable"]))
 {
  $engine = new SpiderEngine
                 ($adminConfig->param("DBName"),
                  $adminConfig->param("DBHost"),
                  $adminConfig->param("DBUser"),
                  $adminConfig->param("DBPassword"));

  $engine->clearTable();

  $engine->deInit();
 }

if (isset($HTTP_POST_VARS["logout"]))
 {
  if (isset($HTTP_POST_VARS["sid"]))
   {
    $session = $manager->get($HTTP_POST_VARS["sid"]);
    $session->invalidate();
   }
 }

// Check if session exists

if (isset($HTTP_POST_VARS["sid"]))
 {
  $session = $manager->get($HTTP_POST_VARS["sid"]);

  if (!$session->valid())
   {
    $errMess = "Session is invalid or expired";
    $log->error($errMess);
   }
 }
// Or creating of a new session

elseif ((isset($HTTP_POST_VARS["name"])) &&
        (isset($HTTP_POST_VARS["pswd"])))
 {
  if (($adminConfig->param("adminLogin")    == $HTTP_POST_VARS["name"]) &&
      ($adminConfig->param("adminPassword") == $HTTP_POST_VARS["pswd"]))
   {
    $newSessionFlag = true;
    $session = $manager->create($HTTP_POST_VARS["name"],$adminConfig->param("adminSessionLong"));
    $log->notice("Login: ID = ".$session->getID());
   }
  else
   {
    $errMess = "Login incorrect";
    $log->error("Login incorrect: login=$HTTP_POST_VARS[name], password=$HTTP_POST_VARS[pswd]");
   }
 }

// if session is valid

if (isset($session) &&
    $session->valid())
 {
  // Filling parameters from form

  $arr = $adminConfig->paramNames();
  $needReSave = false; // Flag which says whether it is required to save settings


  while (list(,$name) = each($arr))
   {
    $type = gettype($adminConfig->param($name));

    switch ($type)
     {
      // For arrays

      case ("array"):
       {
        if (isset($HTTP_POST_VARS[$name]) &&
            (trim($HTTP_POST_VARS[$name] != "")))
         {
          execArrayOperation
           ($adminConfig,
            $name,
            $HTTP_POST_VARS,
            $errMess);

          $needReSave = true;
         }
       } break;
      // For other types

      case ("integer") :
      case ("double")  :
      case ("string")  :
       {
        if (isset($HTTP_POST_VARS[$name]) &&
            (trim($HTTP_POST_VARS[$name]) != "") &&
            isset($HTTP_POST_VARS["submit"]))
         {
          if ($name == "adminPassword")
           {
            if ($HTTP_POST_VARS["confirmPassword"] == $HTTP_POST_VARS[$name])
             {
              $adminConfig->setParam($name,$HTTP_POST_VARS[$name]);
              $needReSave = true;
             }
           }
          else
           {
            $val = $HTTP_POST_VARS[$name];


            if (($name == "searchDeep")           ||
                ($name == "outRefsToPage")        ||
                ($name == "maxPageRef")           ||
                ($name == "adminSessionLong")     ||
                ($name == "spiderStartDaysPeriod"))
             {

              validValues($HTTP_POST_VARS[$name],'int',$val);
             }

            $adminConfig->setParam($name,$val);
            $needReSave = true;
           }
         } break;
       }
      case ("boolean") :
       {
        if (!$newSessionFlag)
         {
          if (isset($HTTP_POST_VARS[$name]))
           {
            if (!$adminConfig->param($name))
             {
              $adminConfig->setParam($name,true);
              $needReSave = true;

              if ($name == "spiderAutoRestart")
               {
                $spiderState = new SpiderState();
                $spiderState->updateStateWithCurrDate();
                $spiderState->done();
               }
             }
           }
          else
           {
            if ($adminConfig->param($name))
             {
              $adminConfig->setParam($name,false);
              $needReSave = true;
             }
           }
         }
       } break;
     }
   }

  if ($needReSave)    { $adminConfig->selfSave();
                        $errMess = $adminConfig->errMess(); }

  if ($errMess == "")
   {
    if (isset($HTTP_POST_VARS["SpiderStart"]))
     {
      restartSpider();
     }
   }

  // Error message printout

  if ($errMess == "") { $tpl->assign('ERROR_MESSAGE',"");          }
  else                { $tpl->assign('ERROR',$errMess);
                        $tpl->parse('ERROR_MESSAGE',"body_error"); }

  $tpl->assign('sid',$session->getID());
  fillTplVariables($tpl,$adminConfig);
  $tpl->parse('CONTENT',"adm_main");
 }
else
 {
  // Error message printout

  if ($errMess == "") { $tpl->assign('ERROR_MESSAGE',"");          }
  else                { $tpl->assign('ERROR',$errMess);
                        $tpl->parse('ERROR_MESSAGE',"body_error"); }

  $tpl->parse('CONTENT',"adm_login");

 }

$tpl->FastPrint('CONTENT');



// ==========================================
              // Parsing settings from $adminConfig to $tpl

function      fillTplVariables   (&$tpl,
                                  &$adminConfig)
 {
  $keys = $adminConfig->paramNames();

  while (list(,$key) = each($keys))
   {
    $type = gettype($adminConfig->param($key));


    switch ($type)
     {
      case ("integer") :
      case ("double")  :
      case ("string")  :
       {
        $tpl->assign($key,$adminConfig->param($key));
       } break;

      case ("array")   :
       {
        parseTplArrayVariables($tpl,$key,$adminConfig->param($key));
       } break;

      case ("boolean") :
       {




        if ($adminConfig->param($key)) { $tpl->assign($key."_checked","checked"); }
        else                           { $tpl->assign($key."_checked",""); }
       } break;

      default:
       {
       }
     }
   }
 }
              // Parse arrays to template

function      parseTplArrayVariables
                               (&$tpl,
                                 $arrName,
                                 $arr)
 {


  $tpl->clear("CHECK_ITEM");

  $tpl->assign('LIST_NAME',$arrName);

  if (count($arr) > 0)
   {
    while (list($key,$val) = each($arr))
     {
      $tpl->assign('NAME' ,$key);
      $tpl->assign('VALUE',$val);

      $tpl->parse("CHECK_ITEM",".adm_checkitem");
     }

    $tpl->parse($arrName,"adm_checkblock");
   }
  else
   {
    $tpl->parse($arrName,"adm_empty_checkblock");
   }
 }

              
               /*
                * Perform $arrName array operation which is contained
                * in settings $adminConfig (class AdminConfig)
                *
                * $addElem - element which should be added to array
                * $removeElem - element which should be excluded from array
                */
              


function      execArrayOperation (&$adminConfig,
                                   $arrName,
                                   $params,
                                  &$errMess)
 {
  $errMess = "";

  $arr = $adminConfig->param($arrName);

  if     ($params[$arrName] == "Add")
   {
    if (isset($params[$arrName."Editor"]) &&
        ($params[$arrName."Editor"] != ""))
     {
      $val = $params[$arrName."Editor"];

      if (($arrName == "startURLs") ||
          ($arrName == "blackList"))
       {
        if (!validValues($params[$arrName."Editor"],"url",$val))
         {
          $errMess = "Bad URL";
         }
       }

      if ($arrName == "parsingExtArr")
       {
        if (!validValues($params[$arrName."Editor"],"extension",$val))
         {
          $errMess = "Bad Extension";
         }
       }

      if ($errMess == "")
       {
        array_push($arr,$val);
        $arr = array_unique($arr);
        $adminConfig->setParam($arrName,$arr);
       }
     }
   }
  elseif ($params[$arrName] == "Remove")
   {
    $retArr = array();

    $old = $arr;
    $arr = array();

    while (list($key,$val) = each($old))
     {
      if (!isset($params[$key."Check"])) { array_push($arr,$val); }
     }

    $adminConfig->setParam($arrName,$arr);
   }
 }

              // get array of all arrays' names from administrator's settings

function      getAllArrayName    (&$adminConfig)
 {
  $keys = $adminConfig->paramNames();
  $retArr = array();

  while (list(,$key) = each($keys))
   {
    $type = gettype($adminConfig->param($key));
    if ($type == "array") { $retArr[] = $key; }
   }

  return($retArr);
 }

              // get array of all simple types parameters' names from administrator's settings

function      getAllSimpleName   (&$adminConfig)
 {
  $keys = $adminConfig->paramNames();
  $retArr = array();

  while (list(,$key) = each($keys))
   {
    $type = gettype($adminConfig->param($key));

    if (($type == "integer") ||
        ($type == "double")  ||
        ($type == "string")  ||
        ($type == "boolean"))
     {
      $retArr[] = $key;
     }
   }

  return($retArr);
 }

              
               /*
                * Check if the value $val is valid
                * $type = 'int'
                *         'url'
                *         'boolean'
                */
              


function      validValues        ( $val,
                                   $type,
                                  &$convertedVal)
 {
  switch ($type)
   {
    case ('url')     :
     {
      if (preg_match("!^(?:http|ftp)://!",$val))
       {
        $convertedVal = $val;
        return(true);
       }
      else
       {
        if ($val != "") { $convertedVal = "http://".$val;
                          return(true);  }
        else            { return(false); }
       }
     } break;

    case ('int')     :
     {
      $convertedVal = $val + 0;
      return(true);
     } break;

    case ('boolean') :
     {
      if     (strcasecmp($val,'true') == 0)      { $convertedVal = true;
                                                   return(true);  }
      elseif (strcasecmp($val,'false') == 0)     { $convertedVal = false;
                                                   return(true);  }
      else                                       { return(false); }
     } break;

    case ("extension") :
     {
      $convertedVal = preg_replace("/^\s*\.+/","",$val);
      return(true);
     } break;

    default          :
     {
      return(false);
     }
   }


 }


function      restartSpider      ()
 {
  $spiderState = new SpiderState();
  $spiderState->restart();
  $spiderState->updateStateWithCurrDate();
  $spiderState->done();
 }

?>