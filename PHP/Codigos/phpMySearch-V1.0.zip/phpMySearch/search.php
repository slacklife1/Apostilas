<?php
#
# Webagentur web4.hm
# Pyrmonterstr. 42
# D-31789 Hameln
# Internet: www.web4.hm, EMail: contact@web4.hm
# Tel: +49 (0) 5151 / 60 99 700
# Fax: +49 (0) 5151 / 60 99 701
# 
# phpMySearch
# Internet: http://web4.hm/phpMySearch, Email: phpMySearch@web4.hm
#
# Diese Software und Dokumentation, darf frei genutzt werden, solange diese Lizenz und der Copyright-Hinweis, in der Software,
# Dokumentation und am Ende der Ausgabe erhalten bleibt.
#
# �nderungen am HTML-Code d�rfen uneingeschr�nkt vorgenommen werden.
# �nderungen am Source-Code d�rfen ebenfalls vorgenommen werden,
# wenn der ver�nderte Code an phpMySearch@web4.hm zugemailt wird.
#
#
# Copyright (c) 2001 Webagentur web4.hm.
# Es wird die Erlaubnis gegeben dieses Dokument zu kopieren, verteilen und/oder
# zu ver�ndern unter den Bedingungen der GNU Free Documentation License,
# Version 1.1 oder einer sp�teren, von der Free Software Foundation
# ver�ffentlichten Version. Eine Kopie dieser Lizenz ist in
# dem Abschnitt enthalten, der mit "GNU Free Documentation License"
# betitelt ist.
#
#
# Copyright (c) 2001 Webagentur web4.hm.
# Permission is granted to copy, distribute and/or modify this document
# under the terms of the GNU Free Documentation License, Version 1.1
# or any later version published by the Free Software Foundation.
# A copy of the license is included in the section entitled "GNU
# Free Documentation License".
#
#

include_once("Src/class.SearchVisualizer.inc.php");

set_time_limit(300000);



$vis = new SearchVisualizer();

$vis->start("syntax");
?>