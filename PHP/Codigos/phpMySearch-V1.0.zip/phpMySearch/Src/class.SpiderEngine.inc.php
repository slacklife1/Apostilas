<?php

include_once("Src/class.AdminConfig.inc.php");

include_once("Src/class.Const.inc.php");

include_once("Src/language.inc.php");


$UserAgentStr = "phpMySearch-Crawler (V1.0, http://web4.hm/phpMySearch)";

$outInfoWeb = false; 
                      /*
                       * if script outputs messages to the browser $outInfoWeb = true;
                       * it case it is run from the command line than $outInfoWeb = false;
                       *
                       */
                     


         
          /*
           * Class contains only one open method, which starts spider
           * for crawling & indexing documents
           *
           * Work with class is performed in the following way
           *
           *     // Creating a copy of class
           *     $spider = new SpiderEngine("SearchEngine",
           *                                 "10.0.0.1",
           *                                 "root",
           *                                 "psw");
           *
           *     // Starting the spider
           *     $spider->start();
           *
           *      //Calling destructor
           *     $spider->deInit();
           *
           *
           */
         



class    SpiderEngine
 {
  var    $link;
  var    $config;
  var    $DBTableName;
  var    $structTableName;
  var    $errMess;
  var    $log;

  // === public ===

              // Constructor

  function    SpiderEngine       ($DBName,
                                  $host,
                                  $user,
                                  $password = "")
   {
    global         $SpidrEngineConst;

    $this->config = &AdminConfigInstance();
    $this->DBTableName     = $this->config->param("DBMainTableName");
    $this->structTableName = $this->config->param("DBStructTableName");

    $this->log = &LogInstance($this->config->param("spiderEngineLogFileName"));
    $this->log->start($SpidrEngineConst['SpiderStartingInfoMsg']);

    $this->DBName = $DBName;
    $this->link = mysql_connect($host,$user,$password);

    if ($this->link > 0)
     {
      $this->log->notice($SpidrEngineConst['DBConnectOkMsg']);


      if (!mysql_select_db($DBName,$this->link))
       {
        $this->setErrMess(sprintf($SpidrEngineConst['DBSelectErrMsg'],$DBName));
        $this->log->error($this->errMess());

       }

      if ($this->errMess() == "")
       {
        $this->createTables();
       }
     }
    else
     {
      // trap DataBase connection opening error
      $this->setErrMess($SpidrEngineConst['DBConnectionErrMsg']);
      $this->log->error($this->errMess());
      //die ($this->errMess());
     }
   }
              // Destructor. Should be called in any case

  function    deInit             ()
   {
    mysql_close($this->link);
   }
              // Start Spider Engine

  function    start              ()
   {
    global         $SpidrEngineConst;

    $startURLs = $this->config->param("startURLs");
    $deep      = $this->config->param("searchDeep");

    if (count($startURLs) == 0)
     {
      $this->log->warning($SpidrEngineConst['NoStartURLsWrnMsg']);
      outMessage("Warning: ".$SpidrEngineConst['NoStartURLsWrnMsg']);
     }

    while (($this->errMess() == "") &&
           (list(,$url) = each($startURLs)))
     {
      $this->log->notice(sprintf($SpidrEngineConst['StartURLInfoMsg'],$url));
      outMessage(sprintf($SpidrEngineConst['StartURLInfoMsg'],$url));
      $this->parseWithDeep($url,$deep);
     }
   }


  function    errMess            ()
   {
    return($this->errMess);
   }


  function    setErrMess         ($errMess)
   {
    $this->errMess = $errMess;
   }


  // === private ===

              
               /*
                * Parse page by $url taking in consideration $deep
                * if $deep= 0 then don't parse any links
                *
                */
              


  function    parseWithDeep      ($url,
                                  $deep)
   {
    global         $SpidrEngineConst;

    $this->log->notice(sprintf($SpidrEngineConst['URLInfoMsg'],$url));
    outMessage(sprintf($SpidrEngineConst['URLInfoMsg'],$url));

    if ($this->needParse($url))
     {
      if ($this->errMess() == "")
       {
        $hesh = $this->parseHTML($url);
       }

      if ($this->errMess() == "")
       {


        if ($this->errMess() == "")
         {
          if ($deep > 0)
           {


            while (($this->errMess() == "") &&
                   (list(,$ref) = each($hesh["refs"])))
             {
              $this->parseWithDeep($ref,$deep - 1);
             }
           }
         }
       }
     }
   }

              
               /*
                * Parse page by $url and store it in database and returns hash
                * with information about page
                */
              

  function    parseHTML          ($url)
   {
    global         $SpidrEngineConst;

    $hesh = array
     (
      "url"          => "",
      "pageDate"     => date("Y-m-d H:i:s"),
      "expireDate"   => date("Y-m-d H:i:s"),
      "title"        => "no title",
      "description"  => "no description",
      "keywords"     => "no keywords",
      "author"       => "no author",
      "body"         => "no body",
      "expiresFlag"  => 0,
      "refs"         => array()
     );

    $expires = "";

    // Remove / from the end of $url

    if (substr($url,-1) == '/') { $url = substr($url,0,strlen($url)); }

    outMessage($SpidrEngineConst['PageLoadStartMsg']);
    $this->log->notice($SpidrEngineConst['PageLoadStartMsg']);

    if ($this->getPage($url,&$urlContent,$header))
     {
      outMessage($SpidrEngineConst['PageLoadedMsg']);
      $this->log->notice($SpidrEngineConst['PageLoadedMsg']);

      $title = $description = $keywords = $author       = "";
      $name = $content = $body = $paragraph = $pagesize = "";

      $this->removeEntities($urlContent);
      $pagesize = strlen($urlContent);

      if (preg_match("|<title>([^<>]+?)</title>|im",$urlContent,$arr))
       {
        $title = &trim($arr[1]);
       }

      if (preg_match_all("!<meta\s+name=(?:\"|')(.*?)(?:\"|')\s+content=(?:\"|')(.*?)(?:\"|')!im",
                         $urlContent,
                         $arr))
       {
        for ($i = 0;$i < count($arr[1]); $i++)
         {
          $name    = $arr[1][$i];
          $content = $arr[2][$i];

          if (strcasecmp($name,"description") == 0) { $description  = $content; }
          if (strcasecmp($name,"keywords")    == 0) { $keywords     = $content; }
          if (strcasecmp($name,"author")      == 0) { $author       = $content; }
          if (strcasecmp($name,"expires")     == 0)
           {
            list($day,$month,$year) = sscanf($content,"%2d%2d%4d");
            $expires = date("Y-m-d H:i:s",mktime(0,0,0,$month,$day,$year));
           }
         }
       }

      $urlContent = preg_replace("'\n'","",$urlContent);

      if (preg_match("'<body.*?>(.*?)</body>'is",$urlContent,$arr))

       {
        $body = $arr[1];
        $this->stripTags($body);
       }

      if ($description == "")
       {
        $description = substr($body,0,250);
        $description = $description."...";
       }

      if ($author == "") { $author = "(author unknown)"; }
      if ($title == "")  { $title  = "(no title)"; }

      $hesh = array
       (
        "url"          => urldecode($url),
        "pageDate"     => $header["Last-Modified"],
        "expireDate"   => ($expires == "") ? date("Y-m-d H:i:s") : $expires,
        "title"        => $this->removeDoubleSpaces(addslashes($title)),
        "description"  => $this->removeDoubleSpaces(addslashes($description)),
        "keywords"     => $this->removeDoubleSpaces(addslashes($keywords)),
        "author"       => $this->removeDoubleSpaces(addslashes($author)),
        "body"         => $this->removeDoubleSpaces(addslashes($body)),
        "expiresFlag"  => ($expires == "") ? 0 : 1,
        "refs"         => $this->getRefsFromPage($url,&$urlContent)
       );

      $this->saveData($hesh);


     }
    else
     {

     }

    return($hesh);
   }


  function    saveData           ($hesh)
   {
    global         $SpidrEngineConst;

    $this->divideToParts($hesh["body"],200,&$body_1,&$body_2);

    $hesh[url] = addslashes($hesh[url]);



     {
      $query = <<<EOD
      REPLACE INTO $this->DBTableName SET
          URL          = "$hesh[url]",
          pageDate     = "$hesh[pageDate]",
          expiresDate  = "$hesh[expireDate]",
          title        = "$hesh[title]",
          description  = "$hesh[description]",
          keywords     = "$hesh[keywords]",
          author       = "$hesh[author]",
          body_1       = "$body_1",
          body_2       = "$body_2",
          expiresFlag  = $hesh[expiresFlag];
EOD;
      if (!mysql_query($query,$this->link))
       {
        $this->setErrMess(sprintf($SpidrEngineConst['BadQueryErrMsg'],$query,mysql_error($this->link)));
        outMessage($this->errMess());
        $this->log->error($this->errMess());

       }
      else
       {
        $this->addURLtoStruct($hesh[url]);
       }
     }
   }
             
              /*
               * Helper function for splitting string in two parts
               * It is required for utilizing MySQL full text serach by $str
               *
               */
             



  function    divideToParts      ( $str,
                                   $firstPartLength,
                                  &$part1,
                                  &$part2)
   {
    $part2 = "";

    if (strlen($str) > $firstPartLength)
     {
      $part1 = substr($str,0,$firstPartLength);

      if (preg_match("/\s(\S+)$/",$part1,$arr))
       {
        $part2 = $arr[1];
        $part1 = preg_replace("/(\S+)$/","",$part1);
       }

      $part2 .= substr($str,$firstPartLength);
     }
    else
     {
      $part1 = $str;
     }
   }

              // Retunrns an array of links found at page $url

  function    getRefsFromPage    ( $url,
                                  &$urlContent)
   {
    global         $SpidrEngineConst;

    $base    = '';
    $thisDir = '';
    $refsArray = array();

    $base    = $this->getBase($url,$urlContent);
    $thisDir = $this->getDir($url);


    if (preg_match_all("/<frame.+?src\s*=\s*(?:\"|'|)(.+?)(?:\"|'|\s|>)/im",$urlContent,$arr))
     {
      foreach ($arr[1] as $val)
       {
        if (preg_match("/^mailto:/i",$val) ||
            preg_match("/^javascript:/i",$val))
         {
          continue;
         }

        $val = $this->findHref($val,$thisDir,$base);

        $refsArray[] = $val;
       }
     }

    if (preg_match_all("/<(?:a|area).+?href\s*=\s*(?:\"|'|)(.+?)(?:\"|'|\s|>)/im",$urlContent,$arr))
     {
      foreach ($arr[1] as $val)
       {
        if (preg_match("/^mailto:/i",$val) ||
            preg_match("/^javascript:/i",$val))
         {
          continue;
         }

        $val = $this->findHref($val,$thisDir,$base);
        $refsArray[] = $val;
       }
     }
    else
     {
      outMessage($SpidrEngineConst['PageRefNotFoundInfo']);
      $this->log->notice($SpidrEngineConst['PageRefNotFoundInfo']);
     }

    return $refsArray;
   }


  function    getBase            ($url,
                                  &$urlContent)
   {


    if (preg_match("/<base\s+href\s*?=\s*?(?:\"|'|)([^\"']*?)(?:\"|'|\s|>)/im",$urlContent,$arr))
     {
      $base = $arr[1];

     }

    if     (!isset($base))
     {
      $base = $this->getDomain($url);
     }
    elseif ($this->getDomain($base) != "")
     {
      if (preg_match("'^/'",$base))
       {
        $base = $this->getDomain($url).$base;
       }
      else
       {
        $base = $this->getDir($url).'/'.$base;
       }
     }

    if (substr($base,-1) == '/') { $base = substr($base,0,strlen($base)); }


    return($base);
   }


  function    getDomain          ($url)
   {
    $domain = '';

    if (preg_match("'^((?:http|ftp)://[^/]+)(?:/|$)'i",$url,$arr))
     {
      $domain = $arr[1];
     }
    else
     {
      return '';
     }


    return $domain;
   }


  function    getDir             ($url)
   {
    $dir = '';

    if ($this->getDomain($url) == $url)
     {
      return $url;
     }
    elseif (preg_match("'^(.+?)/[^/]*$'i",$url,$arr))
     {
      $dir = $arr[1];
     }

    return $dir;
   }


             
              /*
               * returns full $url in the form
               * "http://trata.com/ttt.htm"
               * parameters are $base - value od the <BASE> tag from HTML
               * $thisDir path to the page relatively web space
               *
               */
             


  function    findHref           ($href,
                                  $thisDir,
                                  $base)
   {
    if (preg_match("!^(?:http|ftp)://!",$href))
     {
      return $href;
     }

    if (preg_match("!\.\./!",$href))
     {
      $href    = preg_replace("|\.\./|","",$href);
      $thisDir = preg_replace("|/\w+$|","",$thisDir);
     }

    $href = preg_replace("|\./|","",$href);

    if (substr($href,0,1) == '/')
     {
      $href = $base.$href;
     }
    elseif (preg_match("|$base|",$thisDir))
     {
      $href = $thisDir.'/'.$href;
     }
    else
     {
      $href = $base.'/'.$href;
     }

    $href = preg_replace("/#.*$/","",$href);

    return $href;
   }



              // loads page $url to the buffer $buf

  function    getPage            ( $url,
                                  &$buf,
                                  &$header)
   {
    global         $SpidrEngineConst;
    global         $UserAgentStr;

    $retFlag = false;

    $header = array("Last-Modified"  => date("Y-m-d H:i:s"),
                    "Content-Length" => 0);

    $fileName       = "log/php_homepage.txt";
    $headerFileName = "log/_header.txt";

    $fp = fopen($fileName,"w");
    $headerFl = fopen($headerFileName,"w");


    if (preg_match("/^pdf$/i",$this->pageExtension($url)))
     {

      $url =  $this->config->param("PDFConverterURL")
             ."?"
             .$this->config->param("PDFConverterVarName")
             ."="
             .urlencode($url);

     }

    if (($fp) && ($headerFl))
     {

      $ch = curl_init($url);

      curl_setopt($ch,CURLOPT_FILE,$fp);
      curl_setopt($ch,CURLOPT_HEADER,0);

      curl_setopt($ch,CURLOPT_FOLLOWLOCATION,1);
      curl_setopt($ch,CURLOPT_WRITEHEADER,$headerFl);
      curl_setopt($ch,CURLOPT_USERAGENT,$UserAgentStr);

      if (curl_exec($ch))
       {
        $retFlag = true;
       }
      else
       {

        $this->log->error($SpidrEngineConst['PageLoadingErrMsg']);
        outMessage($SpidrEngineConst['PageLoadingErrMsg']);
       }

      fclose($headerFl);
      fclose($fp);

      if ($retFlag)
       {
        $buf = join('',file($fileName));

        $lines = file($headerFileName);

        while (list(,$val) = each($lines))
         {
          if      (preg_match("/^Content-Length: (.*)/",$val,$arr))
           {
            $header["Content-Length"] = $arr[1];
           }
          elseif (preg_match("/^Last-Modified: (.*)/",$val,$arr))
           {
            $header["Last-Modified"] = date("Y-m-d H:i:s",strtotime($arr[1]));
            $date_ = $header["Last-Modified"];
           }
          elseif (preg_match_all("/HTTP\/(?:.+?)\s+(.+?)\s+/si",$val,$arr,PREG_SET_ORDER))
           {
            $c = count($arr);
            $heder["RetCode"] = $arr[$c - 1][1];

            $outStr = "http code> ".$heder["RetCode"]." - ";

            if ((substr($heder["RetCode"],0,1) != "2") &&
                ($heder["RetCode"] != "301"))
             {
              $retFlag = false;
             }

            if ($retFlag) { $outStr .= "Ok";         }
            else          { $outStr .= "Error code"; }

            outMessage($outStr);
            $this->log->notice($outStr);
           }
         }
       }

      curl_close($ch);
     }

    if ($retFlag)
     {
      $outStr = "Page date: ".$header["Last-Modified"];
      outMessage($outStr);
      $this->log->notice($outStr);
     }

    return $retFlag;
   }

              // Strips tags from $body

  function    stripTags          (&$body)
   {
    $body = preg_replace("'<script(.*?)/script>'im"," ",$body);
    $body = preg_replace("'<style(.*?)/style>'im"  ," ",$body);
    $body = preg_replace("'<!--(.*?)-->?'im"       ," ",$body);
    $body = preg_replace("'<(.*?)>'im"             ," ",$body);
   }

              // replace special charackters with ASCII equivalents

  function    removeEntities     (&$body)
   {
    $body = preg_replace("/&nbsp;/im"," " ,$body);
    $body = preg_replace("/&quot;/im","\"",$body);
    $body = preg_replace("/&amp;/im" ,"&" ,$body);
   }

              // Strips multiple spaces and replaces it with one space

  function    removeDoubleSpaces (&$str)
   {
    $str = preg_replace("/(\s{2,})/"," ",$str);
    return($str);
   }

              
               /*
                * Checks for required tables in database and creates them if they
                * don't exist. You should connect to database prior to calling it.
                */
               

  function    createTables       ()
   {
    global         $SpidrEngineConst;

    $result = mysql_list_tables($this->DBName);//,$this->link);

    $i = 0;
    $foundFlag = false;

    $DBTableName = $this->config->param("DBMainTableName");

    while (($i < mysql_num_rows($result)) &&
           (!$foundFlag))
     {
      if (mysql_tablename($result,$i) == $DBTableName) { $foundFlag = true; }

      $tbl = mysql_tablename($result,$i);

      $i++;
     }

    if (!$foundFlag)
     {


      $const = &ConstInstance();
      $tableStruct = $const->mainTableStruct();

      $query = "create table $this->DBTableName ($tableStruct)";

      if (!mysql_query($query,$this->link))
       {
        $this->setErrMess(sprintf($SpidrEngineConst['BadQueryErrMsg'],$query,mysql_error($this->link)));
        $this->log->error($this->errMess());

       }
     }
    else
     {

     }

    if ($this->errMess() == "")
     {
      $const = &ConstInstance();
      $tableStruct = $const->structTableStruct();

      $query = "CREATE TABLE if not exists $this->structTableName ($tableStruct)";

      if (!mysql_query($query,$this->link))
       {
        $this->setErrMess(sprintf($SpidrEngineConst['BadQueryErrMsg'],$query,mysql_error($this->link)));
        $this->log->error($this->errMess());

       }
     }
   }


  function    clearTable         ()
   {
    global         $SpidrEngineConst;


    $query =<<<END
     DELETE from $this->DBTableName;
END;
    if (!mysql_query($query,$this->link))
     {
      $this->setErrMess(sprintf($SpidrEngineConst['BadQueryErrMsg'],$query,mysql_error($this->link)));
      $this->log->error($this->errMess());
     }

    $query =<<<END
     DELETE from $this->structTableName;
END;

    if (!mysql_query($query,$this->link))
     {
      $this->setErrMess(sprintf($SpidrEngineConst['BadQueryErrMsg'],$query,mysql_error($this->link)));
      $this->log->error($this->errMess());
     }
   }


             
              /*
               * Returns false if for some reasons page in $url should not be parsed and
               * stored to database
               */
             


  function    needParse          ($url)
   {
    global         $SpidrEngineConst;

    $retFlag = true;

    // Should $url be parsed ?

    $retFlag = $this->validURL($url);

    if ($retFlag)
     {
      if ($this->config->param("spiderOnlySetUpDomain"))
       {
        $domain    = $this->getDomain($url);
        $startUrls = $this->config->param("startURLs");

        $retFlag = false;

        while ((!$retFlag) && (list(,$startUrl) = each($startUrls)))
         {
          $startDomain = $this->getDomain($startUrl);

          if (preg_match("'^$startDomain$'i",$domain)) { $retFlag = true; }
         }
       }


      
       /*
        * If all pages are not be reparsed then skip those documents which are stored
        *  in database and have not yet expired.
        */
      


      if (($retFlag) && (!$this->config->param("spiderEngineReparseAll")))
       {
      
       /*
        * If the document is not in the Black list then check whether should this page
        * be updated and stored in database
        */
      


        $parsedURL = addslashes($url);

        $query = <<<EOD
        SELECT * FROM $this->DBTableName
                WHERE url = "$parsedURL" AND
                      ((expiresFlag = 1 AND expiresDate < now()) OR
                       (expiresFlag = 0))
EOD;

        $result = mysql_query($query,$this->link);

        if (!$result)
         {
          $this->setErrMess(sprintf($SpidrEngineConst['BadQueryErrMsg'],$query,mysql_error($this->link)));
          $this->log->error($this->errMess());

         }

        if (mysql_num_rows($result) > 0)
         {
          $retFlag = false;
         }

        mysql_free_result($result);
       }
     }

    if ($retFlag) { $this->log->notice($SpidrEngineConst['PageNeedParseInfoMsg']);
                    outMessage($SpidrEngineConst['PageNeedParseInfoMsg']); }
    else          { $this->log->notice($SpidrEngineConst['PageNotNeedParseInfoMsg']);
                    outMessage($SpidrEngineConst['PageNotNeedParseInfoMsg']); }

    return($retFlag);
   }

              
               /*
                * Return true, if $url is conained in black list otherwise false
                */
              


  function    inBlackList        ($url)
   {
    global         $SpidrEngineConst;

    $blackList = $this->config->param("blackList");

    while (list(,$val) = each($blackList))
     {
      if (preg_match("|^$val|i",$url))
       {
        $this->log->notice(sprintf($SpidrEngineConst['URLInBlackListInfoMsg'],$url));
        outMessage(sprintf($SpidrEngineConst['URLInBlackListInfoMsg'],$url));
        return(true);
       }
     }

    return(false);
   }


  function    inExtensionList    ($url)
   {
    $retFlag = false;

    $ext = $this->pageExtension($url);

    if ($ext != "")
     {
      $extArr = $this->config->param("parsingExtArr");

      while (list(,$val) = each($extArr))
       {
        if (preg_match("'^$val$'i",$ext))
         {
          return(true);
         }
       }
     }
    else
     {
      return(true);
     }

    return($retFlag);
   }


  function    pageExtension      ($url)
   {
    $ext = "";
    $domain = $this->getDomain($url);

    $onlyURL = preg_replace("|^$domain|","",$url);
    $onlyURL = preg_replace("/\?.+/","",$onlyURL);

    if (preg_match("/.+\.(.*)$/",$onlyURL,$arr)) { $ext = $arr[1]; }

    return($ext);
   }


  function    validURL           ($url)
   {
    $retFlag = false;

    if ((!$this->inBlackList($url))    &&
        ($this->inExtensionList($url)) &&
        (!$this->isDirectoryIndexSorting($url)))
     {
      $retFlag = true;
     }

    return($retFlag);
   }


  function    isDirectoryIndexSorting
                                 ($url)
   {
    if (preg_match("/\/\?N=A$/",$url)) { return(true); }
    if (preg_match("/\/\?N=D$/",$url)) { return(true); }
    if (preg_match("/\/\?M=A$/",$url)) { return(true); }
    if (preg_match("/\/\?M=D$/",$url)) { return(true); }
    if (preg_match("/\/\?S=A$/",$url)) { return(true); }
    if (preg_match("/\/\?S=D$/",$url)) { return(true); }
    if (preg_match("/\/\?D=A$/",$url)) { return(true); }
    if (preg_match("/\/\?D=D$/",$url)) { return(true); }

    return(false);
   }


              // Update path structur basing on $url

  function    addURLtoStruct     ($url)
   {
    global         $SpidrEngineConst;

    $parts = parse_url($url);
    $arr = array();

    $elem = $parts["scheme"]."://".$parts["host"];
    if (isset($parts["port"])) { $elem.= ":".$parts[port]; }
    $arr[] = $elem;

    $pathes = split("/",$parts["path"]);

    while (list(,$val) = each($pathes))
     {
      if ($val != "") { $arr[] = $val; }
     }

    array_pop($arr);

    $pairs = $this->getAllStructPairs($arr);

    while (list(,$val) = each($pairs))
     {
      $query =<<<END
         REPLACE into $this->structTableName SET
                   own   = '$val[0]',
                   child = '$val[1]'
END;

      if (!mysql_query($query,$this->link))
       {
        $this->setErrMess(sprintf($SpidrEngineConst['BadQueryErrMsg'],$query,mysql_error($this->link)));
        $this->log->error($this->errMess());

       }
     }
   }

              
               /* Input is an array of elements (let it be as follows:
                *                                       [0] =>'first',
                *                                      [1] =>'second',
                *                                      [3] => 'third')
                * The output will be:
                * [0] => array(''     , 'first')
                * [1] => array('first', 'second')
                * [2] => array('second','third')
                */
              


  function    getAllStructPairs  ($arr)
   {
    $retArr = array();

    if (count($arr) >= 1) { $retArr[] = array('',$arr[0]); }

    if (count($arr) >= 2)
     {
      $prefix = "";

      for ($i = 1;$i < count($arr);$i++)
       {
        $retArr[$i] = array($arr[$i - 1],$arr[$i]);

        if ($prefix != "") { $retArr[$i][0] = $prefix.$retArr[$i][0]; }

        $prefix .= $arr[$i - 1]."/";
       }
     }



    return($retArr);
   }
 }


function      outMessage         ($mess = "")
 {
  global      $outInfoWeb;

  if ($outInfoWeb) { $mess .= "<br>"; }
  else             { $mess .= "\n";   }

  echo "$mess";
 }

?>