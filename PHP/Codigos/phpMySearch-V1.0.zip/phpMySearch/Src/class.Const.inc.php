<?php

function     &ConstInstance      ()
 {
  static           $fSingleton;

  if (!isset($fSingleton))
   {
    $fSingleton = new Constants();
    register_shutdown_function("ConstInstanceDone");
   }

  return($fSingleton);
 }


function      ConstInstanceDone  ()
 {
  $inst = &ConstInstance();
  $inst->done();
 }


class    Constants
 {
  // ==== Methods which returns values of constants  ====


  function    mainTableStruct    ()
   {
    return($this->fMainTableStruct);
   }


  function    structTableStruct  ()
   {
    return($this->fStructTableStruct);
   }


  function    tmpTableStruct     ()
   {
    return($this->fTmpTableStruct);
   }


  function    settingsTableStruct()
   {
    return($this->fSettingsTableStruct);
   }


  function    spiderTableStruct  ()
   {
    return($this->fSpiderTableStruct);
   }


  function    outTmpTableStruct  ()
   {
    return($this->fOutTmpTableStruct);
   }


  function    mainTmpTableName   ()
   {
    return($this->fMainTmpTableName);
   }


  function    outTmpTableName    ()
   {
    return($this->fOutTmpTableName);
   }


  // ====================================================
  function    Constants          ()
   {
    $this->init();
   }

  function    done               ()
   {
   }

  function    init               ()
   {
    $this->fCommonTableStructure =<<<END
        URL                  CHAR(255) NOT NULL,
        pageDate             DATETIME,
        expiresDate          DATETIME,
        title                TINYTEXT,
        description          TINYTEXT,
        keywords             VARCHAR(255),
        author               TINYTEXT,
        body_1               VARCHAR(200),
        body_2               TEXT,
        expiresFlag          TINYINT DEFAULT 0,

        FULLTEXT            (body_1,
                             body_2),

        UNIQUE KEY          (URL)
END;

    // Main table structure

    $this->fMainTableStruct =<<<END
        $this->fCommonTableStructure
END;

    // Temporary tables structure

    $this->fTmpTableStruct =<<<END
        $this->fCommonTableStructure,
        relevance            FLOAT   DEFAULT 0.0,
        inKeywordsFlag       TINYINT DEFAULT 0
END;

    // Structure of the table which used for results output

    $this->fOutTmpTableStruct =<<<END
        inKeywordsFlag       TINYINT DEFAULT 0,
        relevance            FLOAT   DEFAULT 0.0,
        URL                  CHAR(255),
        pageDate             DATE,
        title                TINYTEXT,
        description          TINYTEXT,
        author               TINYTEXT,

        UNIQUE KEY          (inKeywordsFlag,
                             relevance,
                             URL)
END;

    $this->fSettingsTableStruct =<<<END
      recNo                       INT NOT NULL DEFAULT 1,
      DBName                      VARCHAR(64),
      DBUser                      VARCHAR(64),
      DBPassword                  VARCHAR(64),
      DBHost                      VARCHAR(64),

      DBMainTableName             VARCHAR(64),
      DBSettingsTableName         VARCHAR(64),
      DBStructTableName           VARCHAR(64),
      DBSpiderStateTableName      VARCHAR(64),

      adminLogin                  VARCHAR(64),
      adminPassword               VARCHAR(64),

      parsingExtArr               TEXT,

      startURLs                   TEXT,
      blackList                   TEXT,

      searchDeep                  INT,

      outRefsToPage               INT,
      maxPageRef                  INT,

      searchEngineLogFileName     VARCHAR(255),
      spiderEngineLogFileName     VARCHAR(255),
      adminConfigLogFileName      VARCHAR(255),
      adminSessionLong            INT,

      templatesPath               VARCHAR(255),

      PDFConverterURL             VARCHAR(255),
      PDFConverterVarName         VARCHAR(32),
      PDFConverterVarTransMethod  CHAR(4),

      spiderEngineReparseAll      TINYINT,
      spiderAutoRestart           TINYINT,
      spiderOnlySetUpDomain       TINYINT,

      spiderTimeStart             TIME,
      spiderStartDaysPeriod       INT,

      UNIQUE KEY                 (recNo)
END;

    $this->fStructTableStruct =<<<END
      own                         CHAR(255),
      child                       VARCHAR(200),

      UNIQUE KEY                 (own,
                                  child)
END;


    $this->fSpiderTableStruct =<<<END
      recNo                       INT NOT NULL DEFAULT 1,
      nextDateTime                DATETIME,

      UNIQUE KEY                 (recNo)
END;

    // The name of main temporary table

    $this->fMainTmpTableName  = "MainTmp";
    // The name of temporary table containing output information

    $this->fOutTmpTableName   = "OutTmp";
   }

  var              $fMainTableStruct;
  var              $fTmpTableStruct;
  var              $fOutTmpTableStruct;
  var              $fCommonTableStruct;
  var              $fMainTmpTableName;
  var              $fOutTmpTableName;
  var              $fSettingsTableStruct;
  var              $fStructTableStruct;
  var              $fSpiderTableStruct;
 }

?>