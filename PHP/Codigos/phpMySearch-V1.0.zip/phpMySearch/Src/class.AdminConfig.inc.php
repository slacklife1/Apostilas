<?php

include_once("Src/class.Config.inc.php");
include_once("Src/class.Const.inc.php");
include_once("GutLibs/class.Log.inc.php");


include_once("Src/DataBaseSettings.inc.php");
              // Returns a copy of AdminConfig class

function     &AdminConfigInstance($extSource = "DATABASE")
 {
  static $fSingleton;

  if (!isset($fSingleton))
   {
    $fSingleton = new AdminConfig($extSource);

    register_shutdown_function("AdminConfigDone");
   }

  return($fSingleton);
 }
              // Automatically calls destructor

function      AdminConfigDone    ()
 {
  $inst = &AdminConfigInstance();
  $inst->done();
 }
         
          /*
           * Copy of this class should be only obtained by invoking
           * AdminConfigInstance() function
           *
           *  $instance = &AdminConfigInstance();
           *  $prm = $instance->param("param");
           */
         


class    AdminConfig extends Config
 {
              // Constructor

  function    AdminConfig        ($extSource = "")
   {
    Config::Config($extSource);
    $this->logReplaceOutFlag = true;
   }

         
          /*
           * Load setting from outer soure
           * !!! Invoked by constructor
           */
         


  function    selfLoad           ($extSource = "")
   {
    global         $DBName;
    global         $DBUser;
    global         $DBPassword;
    global         $DBHost;

    $this->hash = array
     (
      
       /*
        * Database setting
        * All this settings are required
        */
      


      "DBName"               => $DBName,
      "DBUser"               => $DBUser,
      "DBPassword"           => $DBPassword,
      "DBHost"               => $DBHost,


      "DBMainTableName"        => "_Pages",
      "DBSettingsTableName"    => "settings",
      "DBStructTableName"      => "struct",
      "DBSpiderStateTableName" => "spider",

      "adminLogin"           => "admin",
      "adminPassword"        => "admin",

      "adminSessionLong"     => 20, // Not in base

      "parsingExtArr"        => array("htm",
                                      "html",
                                      "php",
                                      "php3",
                                      "cgi",
                                      "pl",
                                      "cfm",
                                      "pdf"),

      // List of URLs


      "startURLs"            => array(),
      "blackList"            => array(),

      "searchDeep"    => 3, 
                             /*
                              * Search depth
                              *
                              * 0 - don't follow any links
                              * 1 - follow links only from the first page
                              */
                            


      "outRefsToPage" => 3, 
                             /*
                              * Number of found links per page
                              */
                            


      "maxPageRef"    => 4, 
                             /*
                              * Maximum number of pages allowed for direct access
                              * if 5 the output will be
                              * (<< 1 2 3 4 5 >>>)
                              * (<< 6 7 8 9 10 >>>) ...
                              */
                            


      "searchEngineLogFileName"    => "log/search.log",
      "spiderEngineLogFileName"    => "log/spider.log",
      "adminConfigLogFileName"     => "log/admin.log",

      "templatesPath"              => "./templates",


      "PDFConverterURL"            => "http://access.adobe.com/perl/convertPDF.pl",
      "PDFConverterVarName"        => "url",
      "PDFConverterVarTransMethod" => "POST",

      
       /*
        * When spider is started parse all pages regardless of expiration date
        * of the page (true)
        * Parse only expired pages (false)
        */
      

      "spiderEngineReparseAll"     => true,
      "spiderAutoRestart"          => true,

      "spiderOnlySetUpDomain"      => true,

      "spiderTimeStart"            => "21:00:00",
      "spiderStartDaysPeriod"      => 10
     );



    $this->log = &LogInstance($this->param("adminConfigLogFileName"));

    if ($extSource != "")
     {
      if ($extSource == "DATABASE")
       {
        $this->loadFromDB();
       }
      else
       {
        $this->setErrMess("This external source ('$extSource') not supported");

        $this->log->error($this->errMess());
       }
     }
   }


  function    setParam           ($key,
                                  $value)
   {
    $old = $this->param($key);
    $new = $value;

    if (gettype($old) == "array") { $old = join(',',$old); }
    if (gettype($new) == "array") { $new = join(',',$new); }

    Config::setParam($key,$value);

    if (($old != $new) && ($this->logReplaceOutFlag))
     {
      $this->log->notice("Parameter ($key) is replaced from '$old' to '$new'");
     }
   }


  function    selfSave           ($extSource = "DATABASE")
   {
    $this->setErrMess("");

    $this->log->notice("settings selfSave to '$extSource' executed");

    if ($extSource != "")
     {
      if ($extSource == "DATABASE")
       {
        $this->DBSetDefault($this->param("DBSettingsTableName"));
       }
      else
       {
        $this->setErrMess("This external source ('$extSource') not supported");

        $this->log->error($this->errMess());
       }
     }
   }


  function    loadFromDB         ()
   {
    $this->logReplaceOutFlag = false;

    $this->setErrMess("");
    $errMessPrefix = "DB Error: ";
    $host   = $this->param("DBHost");
    $user   = $this->param("DBUser");
    $pswd   = $this->param("DBPassword");
    $DBName = $this->param("DBName");

    $const = &ConstInstance();
    $tableStruct = $const->settingsTableStruct();
    $tableName   = $this->param("DBSettingsTableName");

    $this->link = mysql_connect($host,$user,$pswd);

    if ($this->link > 0)
     {
      if (!mysql_select_db($DBName,$this->link))
       {
        $this->setErrMess($errMessPrefix."Select DB error: $DBName");
        $this->log->error($this->errMess());

       }
     }
    else
     {

      $this->setErrMess($errMessPrefix."Could not connect to DataBase: $DBName");

      $this->log->error($this->errMess());
     }

    if ($this->errMess() == "")
     {
      $this->DBTableCreate($tableName,$tableStruct);
     }

    if ($this->errMess() == "")
     {
      $query = "SELECT * from $tableName;";
      $result = mysql_query($query,$this->link);

      if (!$result)
       {

        $this->setErrMess("Table selection data error");
        $this->log->error("Bad query: $query => (".mysql_error($this->link).")");
       }
      else
       {
        // If record is selected, put data in properties

        if ($arr = mysql_fetch_assoc($result))
         {
          while (list($key,$val) = each($arr))
           {
            if ($key != "recNo")
             {
              $type = gettype($this->param($key));


              switch ($type)
               {
                case ("array"):
                 {
                  if (trim($val) != "")
                   {
                    $this->setParam($key,split(",",$val));
                   }
                  else
                   {
                    $this->setParam($key,array());
                   }
                 } break;

                case ("boolean"):
                 {
                  if ($val == 0) { $this->setParam($key,false); }
                  else           { $this->setParam($key,true);  }
                 } break;

                default:
                 {
                  $this->setParam($key,$val);
                 }
               }
             }
           }


         }
        // Otherwise store default settings to the table

        else
         {
          $this->DBSetDefault($tableName);
         }
       }
     }

    $this->logReplaceOutFlag = true;
   }


  function    DBSetDefault       ($tableName)
   {
    $this->setErrMess("");

    $query = "REPLACE INTO $tableName SET recNo = 1,";

    $paramNames = $this->paramNames();

    while (list(,$key) = each($paramNames))
     {
      $val = $this->param($key);
      $type = gettype($val);

      if     (($type == "integer") ||
              ($type == "double"))
       {
        $query .= "$key = $val,";
       }
      elseif ($type == "array")
       {
        $query .= "$key = \"".join(',',$val)."\",";
       }
      elseif ($type == "boolean")
       {
        if   ($val) { $query .= "$key = 1,"; }
        else        { $query .= "$key = 0,"; }
       }
      else
       {
        $query .= "$key = \"$val\",";
       }
     }

    $query = preg_replace("/,$/","",$query);

    if (!mysql_query($query,$this->link))
     {

      $this->setErrMess("Table creation error");
      $this->log->error("Bad query: $query => (".mysql_error($this->link).")");
     }
   }


  function    DBTableCreate      ( $tableName,
                                   $tableStruct)
   {
    $this->setErrMess("");

    $query =<<<END
       CREATE TABLE IF NOT EXISTS $tableName ($tableStruct)
END;

    if (!mysql_query($query,$this->link))
     {

      $this->setErrMess("Table creation error");
      $this->log->error("Bad query: $query => (".mysql_error($this->link).")");
     }
   }


  function    done               ()
   {
   }

  var    $link;
  var    $log;
  var    $logReplaceOutFlag;
 }
?>
