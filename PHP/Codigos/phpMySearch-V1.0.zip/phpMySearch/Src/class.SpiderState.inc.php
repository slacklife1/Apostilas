<?php

include_once("Src/class.AdminConfig.inc.php");

include_once("Src/language.inc.php");

class    SpiderState
 {            // Constructor

  function    SpiderState        ()
   {
    global         $SpidrEngineConst;

    $this->setErrMess("");

    $this->adminConfig = &AdminConfigInstance();
    $this->DBTableName = $this->adminConfig->param("DBSpiderStateTableName");

    $this->log = &LogInstance($this->adminConfig->param("spiderEngineLogFileName"));

    $this->DBName = $this->adminConfig->param("DBName");
    $this->link = mysql_connect
                   ($this->adminConfig->param("DBHost"),
                    $this->adminConfig->param("DBUser"),
                    $this->adminConfig->param("DBPassword"));

    if ($this->link > 0)
     {
      $this->log->notice($SpidrEngineConst['DBConnectOkMsg']);

      if (!mysql_select_db($this->DBName,$this->link))
       {
        $this->setErrMess(sprintf($SpidrEngineConst['DBSelectErrMsg'],$this->DBName));
        $this->log->error($this->errMess());

       }

      if ($this->errMess() == "")
       {
        $this->createTables();
       }
     }
    else
     {

      $this->setErrMess("SpiderState: ".$SpidrEngineConst['DBConnectionErrMsg']);
      $this->log->error($this->errMess());

     }
   }
              // Destructor

  function    done               ()
   {
    mysql_close($this->link);
   }


  function    needRestartSpider  ()
   {
    global         $SpidrEngineConst;

    $query =<<<END
         SELECT count(nextDateTime) from $this->DBTableName
                   WHERE nextDateTime < NOW()
END;

    $result = mysql_query($query,$this->link);




    if (!$result)
     {
      $this->setErrMess(sprintf($SpidrEngineConst['BadQueryErrMsg'],$query,mysql_error($this->link)));
      $this->log->error($this->errMess());
     }
    else
     {
      $this->log->notice(sprintf($SpidrEngineConst['LogQueryInfoMsg'],$query));
      $this->log->notice(sprintf($SpidrEngineConst['LogRowCountInfoMsg'],mysql_num_rows($result)));

      $arr = mysql_fetch_row($result);

      if ((mysql_num_rows($result) > 0) &&
          ($arr[0] > 0))
       {
        $this->updateStateWithCurrDate();

        if ($this->errMess() == "") { return(true); }
       }
     }

    return(false);
   }
              
               /*
                * Function should be called after strting the spider
                * it refreshes spider state for its next automatic calls
                */
              


  function    updateStateWithCurrDate
                                 ()
   {
    global         $SpidrEngineConst;

    echo "updateStateWithCurrDate <br>";

    $time       = $this->adminConfig->param("spiderTimeStart");
    $daysPeriod = $this->adminConfig->param("spiderStartDaysPeriod");

    $query =<<<END
          REPLACE INTO $this->DBTableName SET
            recNo        = 1,
            nextDateTime = DATE_ADD(CURDATE(),INTERVAL $daysPeriod DAY) + INTERVAL TIME_TO_SEC("$time") SECOND;
END;
    if (!mysql_query($query,$this->link))
     {
      $this->setErrMess(sprintf($SpidrEngineConst['BadQueryErrMsg'],$query,mysql_error($this->link)));
      $this->log->error($this->errMess());
      echo "!Error<br> ";
     }
   }


  function    setErrMess         ($errMess)
   {
    $this->errMess = $errMess;
   }


  function    errMess            ()
   {

    return($this->errMess);
   }


  function    createTables       ()
   {
    global         $SpidrEngineConst;

    $const = &ConstInstance();
    $tableStruct = $const->spiderTableStruct();

    $query =<<<END
              CREATE TABLE IF NOT EXISTS $this->DBTableName ($tableStruct);
END;

    if (!mysql_query($query,$this->link))
     {
      $this->setErrMess(sprintf($SpidrEngineConst['BadQueryErrMsg'],$query,mysql_error($this->link)));
      $this->log->error($this->errMess());
     }

    $query =<<<END
              REPLACE INTO $this->DBTableName SET
                recNo        = 1,
                nextDateTime = NOW();
END;

    if (!mysql_query($query,$this->link))
     {
      $this->setErrMess(sprintf($SpidrEngineConst['BadQueryErrMsg'],$query,mysql_error($this->link)));
      $this->log->error($this->errMess());
     }
   }


  function    restart            ()
   {
    echo "Spider starting<br>";

    exec("/usr/local/bin/php -q spider.php > /dev/null 2>&1 &");
   }

  var    $link;
  var    $adminConfig;
  var    $DBTableName;
  var    $log;
  var    $DBName;
  var    $errMess;
 }
?>