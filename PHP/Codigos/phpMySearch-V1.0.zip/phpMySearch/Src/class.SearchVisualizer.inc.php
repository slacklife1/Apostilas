<?php

include_once("Src/class.SearchEngine.inc.php");
include_once("./Template/class.FastTemplate.php");

include_once("./GutLibs/class.Log.inc.php");

include_once("Src/class.AdminConfig.inc.php");

include_once("Src/language.inc.php");


if (preg_match("/php\.exe$/i",$SCRIPT_NAME)) { $SCRIPT_NAME = "./search.php"; }

$extVars = $HTTP_GET_VARS;
$emptyListValue = "..";
$inThisDir      = "current folder";

class    SearchVisualizer
 {
  // === public ===

  function    SearchVisualizer   ()
   {
    global         $SearchVisualizerConst;
    global         $extVars;

    $this->adminConfig = &AdminConfigInstance();

    $this->log = &LogInstance($this->adminConfig->param("searchEngineLogFileName"));
    $this->log->start($SearchVisualizerConst['StartSearchEngineMsg']);
    $this->log->notice($SearchVisualizerConst['SearchEngineConstructedMsg']);

    $this->tpl = new FastTemplate($this->adminConfig->param("templatesPath"));
    $this->tpl->define
     (array
      (
       'main'          => "main.tpl",
       'body'          => "body.tpl",
       'body_ok'       => "body_ok.tpl",
       'body_error'    => "body_error.tpl",
       '_prev_href'    => "prev_href.tpl",
       '_page_href'    => "page_href.tpl",
       '_page_'        => "page_.tpl",
       '_next_href'    => "next_href.tpl",
       'empty_search'  => "empty_search.tpl",
       'refs'          => "refs.tpl",
       'selectDir'     => "selectDir.tpl",
       'selectOption'  => "selectOption.tpl"
      ));

    $this->needSearch = true;
    if (!isset($extVars["page"])) { $this->needSearch = false; }
    $this->varPage = isset($extVars["page"]) ? $extVars["page"] : 1;
    if (isset($extVars["search"])) { $this->varRequestStr = stripslashes($extVars["search"]); }
    else                           { $this->varRequestStr = ""; }
    $this->log->notice(sprintf($SearchVisualizerConst['PageInfoMsg'],$this->varPage));
    $this->log->notice(sprintf($SearchVisualizerConst['SearchRequestStrInfoMsg'],$this->varRequestStr));
   }


  function    done               ()
   {
   }

  // === private ===

  function    start              ()
   {
    global         $SearchVisualizerConst;
    global         $SCRIPT_NAME;
    global         $extVars;
    global         $emptyListValue;
    global         $inThisDir;

    $errMess = "";

    $search = &SearchEngineInstance
               ( $this->adminConfig->param("DBName"),
                 $this->adminConfig->param("DBHost"),
                 $this->adminConfig->param("DBUser"),
                 $this->adminConfig->param("DBPassword"),
                &$errMess);

    $currPath = "";

    if (isset($extVars["currPath"])) { $currPath = $extVars["currPath"];  }

    if (isset($extVars["path"]) &&
        ($extVars["path"] == $emptyListValue))
     {
      $extVars["path"] = "";

      if (preg_match("/\/\w+$/",$currPath))
       {
        $currPath = preg_replace("/\/\w+$/","",$currPath);
       }
      else
       {
        $currPath = "";
       }
     }

    if (isset($extVars["path"]) &&
        ($extVars["path"] == $inThisDir)) { $extVars["path"] = ""; }

    if (isset($extVars["path"]) &&
       ($extVars["path"] != ""))
     {
      if ($currPath != "") { $currPath .= "/"; }
      $currPath .= $extVars["path"];
     }

    $this->tpl->assign('CURR_PATH',$currPath);


    if ($this->needSearch)
     {
      if ($errMess == "")
       {
        
         /*
          * Number of found URLs, which will
          * be output on one page
          */
        


        $outRefsToPage = $this->adminConfig->param("outRefsToPage");

        $arr = $search->parseExpression
                         ( $this->varRequestStr,
                           $currPath,
                          &$addInfo,
                          &$errMess,
                           ($this->varPage - 1) * $outRefsToPage,
                           $outRefsToPage);
       }
     }

    $startRef = ($this->varPage - 1) * $outRefsToPage + 1;
    $endRef   = $startRef + $outRefsToPage - 1;
    if ($endRef > $addInfo["pages"]) { $endRef = $addInfo["pages"]; }
    $this->tpl->assign("START_REF",$startRef);
    $this->tpl->assign("END_REF"  ,$endRef);

    $this->tpl->assign('QUERY',$this->varRequestStr);


    $this->tpl->assign('PREV_HREF',"");
    $this->tpl->assign('PAGE_HREF',"");
    $this->tpl->assign('NEXT_HREF',"");

    $subDirArr = array_merge(array($inThisDir,$emptyListValue),$search->getSubDirs($currPath,$errMess));

    while (list(,$val) = each($subDirArr))
     {
      if ($val == $inThisDir) { $this->tpl->assign('selected','selected'); }
      else                    { $this->tpl->assign('selected','');         }
      $this->tpl->assign('option',$val);
      $this->tpl->parse('OPTIONS',".selectOption");
     }

    $this->tpl->parse('SELECT_DIR',"selectDir");

    if ($errMess == "")
     {
      $this->log->notice(sprintf($SearchVisualizerConst['RequestStringInfoMsg'],$this->varRequestStr));
      if (isset($arr)) { $this->log->notice(sprintf($SearchVisualizerConst['ArrayLengthInfoMsg'],count($arr))); }

      if ($this->needSearch)
       {
        // Add values to variables for template parsing

        $this->tpl->assign('PAGES',$addInfo["pages"]);

        // Number of pages with links by $outRefsToPage per page

        $allPagesNum = ceil($addInfo["pages"] / $outRefsToPage);
        $this->log->notice(sprintf($SearchVisualizerConst['AllPagesNumInfoMsg'],$allPagesNum));

        if (($addInfo["pages"] > 0) &&
            ($this->varPage <= $allPagesNum))
         {
          // What page should be output now

          if ($this->varPage > $allPagesNum) { $this->varPage = $allPagesNum; }
          $needOutPage = $this->varPage - 1;
          $this->log->notice(sprintf($SearchVisualizerConst['NeedOutPageInfoMsg'],$needOutPage));

          
           /*
            * from what page link start pages menu printout
            * (for example with 6-th) << 6 7 8 9 10>>
            */
          


          $beginPageNumInSq = floor($needOutPage / $this->adminConfig->param("maxPageRef")) * $this->adminConfig->param("maxPageRef") + 1;
          $this->log->notice(sprintf($SearchVisualizerConst['BeginPageNumInSqMsg'],$beginPageNumInSq));

          // what page link should be the last for 5 <<1 2 3 4 5>>

          $endPageNumInSq = $beginPageNumInSq + $this->adminConfig->param("maxPageRef") - 1;
          if ($endPageNumInSq > $allPagesNum) { $endPageNumInSq = $allPagesNum; }
          $this->log->notice(sprintf($SearchVisualizerConst['EndPageNumInSqInfoMsg'],$endPageNumInSq));

          // should mark "<<" be printed

          $prevPagesRefFlag = ($beginPageNumInSq == 1) ? false : true;

          // should mark ">>" be printed

          $nextPagesRefFlag = ($endPageNumInSq   == $allPagesNum) ? false : true;

          $this->log->notice(sprintf($SearchVisualizerConst['PrevPagesRefFlagInfoMsg'],$prevPagesRefFlag));
          $this->log->notice(sprintf($SearchVisualizerConst['NextPagesRefFlagInfoMsg'],$nextPagesRefFlag));

          if ($prevPagesRefFlag)
           {
            $page = $beginPageNumInSq - 1;
            $this->tpl->assign("href_url",$this->getFullUrl($SCRIPT_NAME,$page,$this->varRequestStr,$currPath));
            $this->tpl->parse('PREV_HREF',"_prev_href");
           }
          else
           {
            $this->tpl->assign('PREV_HREF',"");
           }

          if ($nextPagesRefFlag)
           {
            $page = $endPageNumInSq + 1;
            $this->tpl->assign("href_url",$this->getFullUrl($SCRIPT_NAME,$page,$this->varRequestStr,$currPath));
            $this->tpl->parse('NEXT_HREF',"_next_href");
           }
          else
           {
            $this->tpl->assign('NEXT_HREF',"");
           }

          if ($allPagesNum > 1)
           {
            for ($page = $beginPageNumInSq;$page <= $endPageNumInSq;$page++)
             {
              $this->tpl->assign("PAGENUM",$page);

              if ($page != $needOutPage + 1)
               {
                $this->tpl->assign("href_url",$this->getFullUrl($SCRIPT_NAME,$page,$this->varRequestStr,$currPath));
                $this->tpl->parse('PAGE_HREF',"._page_href");
               }
              else
               {
                $this->tpl->parse('PAGE_HREF',"._page_");
               }
             }
           }

          // Parsing links to found pages

          while (list(,$val) = each($arr))
           {
            $this->tpl->assign(array('URL'         => $val["URL"],
                                     'TITLE'       => $val["title"],
                                     'DESCRIPTION' => $val["description"],
                                     'AUTHOR'      => $val["author"],
                                     'PAGE_DATE'   => $val["pageDate"]));

            $this->tpl->parse('REFS',".refs");
           }
         }
        else
         {
          $this->tpl->parse(REFS,"empty_search");



         }

        $this->tpl->parse('SEARCH_BODY',"body_ok");
       }
      else
       {
        $this->tpl->assign('SEARCH_BODY',"");
       }
     }
    else
     {
      $this->tpl->assign('ERROR',$errMess);
      $this->tpl->parse('SEARCH_BODY',"body_error");
     }

    $this->tpl->parse('BODY',"body");
    $this->tpl->parse('CONTENT',"main");
    $this->tpl->FastPrint('CONTENT');


   }

  function    getFullUrl         ($scriptName,
                                  $page,
                                  $searchQuery,
                                  $currPath)
   {
    return("$scriptName?"
           ."page=".urlencode($page)
           ."&"."search=".urlencode($searchQuery)
           ."&"."currPath=".urlencode($currPath));
   }

  var              $tpl;
  var              $varPage;
  var              $varRequestStr;
  var              $adminConfig;
  var              $log;
 }

?>