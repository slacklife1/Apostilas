<?php
$DBName     = "database";
$DBUser     = "user";
$DBPassword = "password";
$DBHost     = "localhost";
?>