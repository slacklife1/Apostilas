<?php

//Formata a data em Portugu�s


$dia_num = date("w");// Dia da semana em n�mero. Ex.: 0 => Sunday, 1 => Monday
$dia_port = $dia_num;// Atribui��o de vari�veis
if($dia_port == 0){
	print("Domingo");
}elseif($dia_port == 1){
	print("Segunda");
}elseif($dia_port == 2){
	print("Ter�a");
}elseif($dia_port == 3){
	print("Quarta");
}elseif($dia_port == 4){
	print("Quinta");
}elseif($dia_port == 5){
	print("Sexta");
}else{
	print("S�bado");
}

$dia_mes = date("d");// Coleta o dia do m�s
print(", $dia_mes de ");// Imprime a variavel $dia_mes

$mes_num = date("m");// Nome do m�s em n�mero. Ex.: 01 => January, 02 =>
February
$mes_port = $mes_num;// Atribui��o de vari�veis
if($mes_port == 01){
	print("Janeiro");
}elseif($mes_port == 02){
	print("Fevereiro");
}elseif($mes_port == 03){
	print("Mar�o");
}elseif($mes_port == 04){
	print("Abril");
}elseif($mes_port == 05){
	print("Maio");
}elseif($mes_port == 06){
	print("Junho");
}elseif($mes_port == 07){
	print("Julho");
}elseif($mes_port == 08){
	print("Agosto");
}elseif($mes_port == 09){
	print("Setembro");
}elseif($mes_port == 10){
	print("Outubro");
}elseif($mes_port == 11){
	print("Novembro");
}else{
	print("Dezembro");
}
$ano = date("Y");// Coleta o ano corrente
print(" de $ano");// Imprime a vari�vel $ano
?>

