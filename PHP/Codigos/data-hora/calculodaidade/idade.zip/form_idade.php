<?
    require("func_idade.php");
    
	if ($data_nasc<>'') {
	
       $d1 = strtotime($data_nasc);   // formato mm/dd/aaaa
       $d2 = strtotime($data_comp);   // formato mm/dd/aaaa

       $a = idade($d1,$d2);

       echo($a);
	   
	}

?>
<html>
<head>
<title>C�lculo da Idade</title>
</head>  
<body>

<form name="form1" method="post" action="">
  <p>Data de nascimento 
    <input type="text" name="data_nasc">
    mm/dd/aaaa </p>
  <p>Data de compara&ccedil;&atilde;o 
    <input type="text" name="data_comp">
    mm/dd/aaaa </p>
  <p>
    <input type="submit" name="Submit" value="Calcula">
  </p>
</form>
</body>
</html>