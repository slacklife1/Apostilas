<?
include "./class_datas";
	 
	$dt = new datas();
	echo "Data de hoje(br) : -> ". $dt->data_br;
	echo "<br>Mes he : -> ". $dt->mes_nome();
	echo "<br>Ano he : -> ". $dt->ano;
	echo "<br>Dia do ano :-> ". $dt->dia_ano;
	echo "<br>nome do dia da semana : -> ". $dt->dia_da_semana();
	echo "<br>nome do mes : ->". $dt->mes_nome();
	echo "<br>Converter essa data 2003-02-20 p/ 20 | 02 | 2003 : -> ". $dt->convdata("2003-02-20","amd","dma"," | ");
	echo "<br>Diferen�a de dias entre 19/02/2003 a 27/02/2003: ->". $dt->difdata("19/02/2003","27/02/2003"); 
	echo "<br>Validar essa data 29/02/2003: ->". $dt->valida("29/02/2003");
?>