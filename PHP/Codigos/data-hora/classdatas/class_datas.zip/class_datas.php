<?
/*
Tipo : classe
Nome : datas
Data : 10/08/2003
Autor: Wonder Alexandre Luz Alves
Desc : Esta classes tem a maioria das fun��es mais utilizadas para
 	   manipular datas
*/
class datas{
	
	var $data_br;
	var $data_us;
	var $dia;
	var $mes;
	var $ano;
	var $hora;
	var $minuto;
	var $segundo;
	var $horas;
	var $dia_semana;
	var $dia_ano;
	var $mes_dia_final;
	var $mes_string;
	/* construtor da class */
	function datas(){
		$this->data_br = date("d-m-Y");
		$this->data_us = date("Y-m-d");
		$this->dia = date("d");
		$this->mes = date("m");
		$this->ano = date("Y");
		$this->hora = date("H");
		$this->minuto = date("i");
		$this->segundo = date("s");
		$this->dia_semana = $this->dia_da_semana();
		$this->dia_ano = date("z");
		$this->mes_dia_final = date("t");
		$this->mes_string = $this->mes_nome();	
	}
	/** 
	 * @return string
	 * @param data='' null  	
	 * @desc retorna o dia da semano por de uma data especifica ou da data atual
	*/
	function dia_da_semana($data=''){
		if(!$data) $dia = date("w");
		else $dia = $this->data_inf($data,"w");
		switch($dia){
			case 0: return "Domingo";break;
			case 1: return "Sengunda-Feira";break;
			case 2: return "Ter�a-Feira";break;
			case 3: return "Quarta-Feira";break;
			case 4: return "Quinta-Feira";break;
			case 5: return "Sexta-Feira";break;
			case 6: return "Sabado";break;
			default : return 0;
		}
	}
	/**
	 * @return string
	 * @param data = '' null
	 * @desc retorna o nome do mes de uma determinada data ou da data atual
	 */
	function mes_nome($data=''){
		if(!$data) $mes = date("m");
		else $mes = $this->data_inf($data,"m");
		switch($mes){
			case 1: return "Janeiro";break;
			case 2: return "Fevereiro";break;
			case 3: return "Mar�o";break;
			case 4: return "Abril";break;
			case 5: return "Maio";break;
			case 6: return "Junho";break;
			case 7: return "Julho";break;
			case 8: return "Agosto";break;
			case 9: return "Setembro";break;
			case 10: return "Outubro";break;
			case 11: return "Novembro";break;
			case 12: return "Dezembro";break;
			default : return 0;
		}
	}		
	/**
	 * @return date
	 * @param data date
	 * @param especifico = '' null
	 * @desc Informa��es de uma data tipo ano, mes, dia e outros valores especificos de acordo com a funcao date()
	 */
	function data_inf($data,$especifico=''){
		$data = $this->convdata($data,"dma","amd","-");
		$dataentra =strtotime($data);
		if($especifico) return date($especifico,$dataentra);
		$xdata = array(dia => date("d",$dataentra), mes => date("m",$dataentra), ano => date("Y",$dataentra));   
		return $xdata;
		   
	}
		
		
		
	/**
	Metodo p/ converter datas dd/mm/aa <-> aaaa/mm/dd 
	Utiliza��o $data = $this->convdata("data","tipo") 
	Saida -> tipo = "dma" => dd/mm/aa
	Saida -> tipo = "amd" => aaaa-mm-dd
	 * @return date
	 * @param dataentra date
	 * @param tipo string
	 * @desc retorna da data com tipo especifico
	 */
	function convdata($dataentra='',$dataTipo,$tipo,$separador){ 
	   //se data n�o especificada vai ficar a data atual
	   
	   
	   if(!$dataentra){
	   		switch ($dataTipo){
	   			case "dma" : $dataentra = $this->data_br;break;
	   			case "amd" : $dataentra = $this->data_us;break;
	   			default : return 0;
	   		}
	   }
	   else{
	   		if(strlen($dataentra) != 10) return 0;
	   }
	   switch($dataTipo){
	   		case "dma" : if(!$this->valida($dataentra,"dma")) return 0; break;
	   		case "amd" : if(!$this->valida($dataentra,"amd")) return 0; break;
		}
	   $ano1="";
	   $dia1="";
	   $mes1="";
	   if($tipo=="dma" && $dataTipo=="amd"){
	   		for($i=0;$i<=10;$i++)
	   		{
				if($i<=3)
					$ano1 .= $dataentra[$i];
				if($i > 4 && $i <= 6)
					$mes1 .= $dataentra[$i];
				if($i > 7)
					$dia1 .= $dataentra[$i];
		   }
		   $datasaida = $dia1 . $separador . $mes1 . $separador . $ano1;
		  	
	  	}
	  	elseif($tipo=="amd" && $dataTipo=="dma"){
	  		for($i=0;$i<=10;$i++)
	   		{
				if($i>5)
					$ano1 .= $dataentra[$i];
				if($i >= 3 && $i <= 4)
					$mes1 .= $dataentra[$i];
				if($i <= 1)
					$dia1 .= $dataentra[$i];
		   }
		   $datasaida = $ano1 . $separador . $mes1 . $separador . $dia1;
		   
	  	}
	  	elseif($tipo=="dma" && $dataTipo=="dma"){
	  		for($i=0;$i<=10;$i++)
	   		{
				if($i>5)
					$ano1 .= $dataentra[$i];
				if($i >= 3 && $i <= 4)
					$mes1 .= $dataentra[$i];
				if($i <= 1)
					$dia1 .= $dataentra[$i];
		   }
		   $datasaida = $dia1 . $separador . $mes1 . $separador . $ano1;
	  	}
	  	elseif($tipo=="amd" && $dataTipo=="dma"){
	  		for($i=0;$i<=10;$i++)
	   		{
				if($i>5)
					$ano1 .= $dataentra[$i];
				if($i >= 3 && $i <= 4)
					$mes1 .= $dataentra[$i];
				if($i <= 1)
					$dia1 .= $dataentra[$i];
		   }
		   $datasaida = $ano1 . $separador . $mes1 . $separador . $dia1;
	  	}
	  	else  return 0;
	  	return $datasaida; 
	}
	 
	/**
	Metodo verificar a diferen�a entre duas datas
	 * @return date
	 * @param datainicio date
	 * @param datafinal date
	 * @desc retorna a diferen�a entre duas datas em dias
	 */
	function difdata($valor1,$valor2) {
		
		// Aten��o para o formato da data ("AAAA/MM/DD")
		$this->convdata($valor1,"dma","amd","/");
		$this->convdata($valor2,"dma","amd","/");
		$datai = $valor1;
		$dataf = $valor2;
		
		// Armazena nas vari�veis $DataInicial e $DataFinal
		// os valores de $DataI e $DataF no formato 'timestamp'
		$datainicial = getdate(strtotime($datai));
		$datafinal = getdate(strtotime($dataf));
		
		// Calcula a Diferen�a
		$dif = ($datafinal[0] - $datainicial[0]) / 86400;
		
		return $dif;
		/*
		   $DataFinal[0] mostra o valor em segundos do timestamp
		   a partir da data e hora m�nima do PHP.
		   1 dia possui 86400 segundos.
		   O script acima retorna quantos dias h� de diferen�a
		   entre as duas datas (nesse caso 52) */
   }
   
   function valida($data,$tipo='dma'){			
	   	switch($tipo){
	   			case "amd":$dDefault = substr($data, 8, 2); $mDefault = substr($data, 5, 2); $aDefault = substr($data, 0, 4);break;
			   	case "dma":$dDefault = substr($data, 0, 2); $mDefault = substr($data, 3, 2); $aDefault = substr($data, 6, 4);break;
	   	}
		if (checkdate($mDefault, $dDefault, $aDefault))
			return 1;
		else
			return 0;
	   
   }

	
}

?>