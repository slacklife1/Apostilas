<?php
	require_once('timestamp.php');
	$data = new timestamp;
	echo $data->pegadata("2003-12-27 16:25:13",1);
	echo "<br>";
	echo $data->pegames("2003-12-27 16:25:13",2);
	echo "<br>";
	echo $data->pegadia("2003-12-27 16:25:13");
	echo "<br>";
	echo $data->pegaano("2003-12-27 16:25:13");	
	echo "<br>";
	echo $data->pegatempo("2003-12-27 16:25:13","T");
	echo "<br>";
	echo $data->subtraidata("28/12/2004","28/11/2002");	
	echo "<br>";
	echo $data->bisexto(2000);

	echo "<br>";
	echo "<br>";	
	echo "M�todos da classe timestamp.php";
	echo "<br>";	
	$class_methods = get_class_methods(get_class($data));
	foreach ($class_methods as $method_name) {
		echo "$method_name<br>";
	}
?>