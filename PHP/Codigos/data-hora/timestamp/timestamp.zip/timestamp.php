<?php
	/*
		Implementa m�todos para tratar datas no formato timestamp.
	*/
	class timestamp {
		function pegadata($var,$tipo) {
			/*
				Tipos: (1 - pt_BR, 2 - US, 3 - ISO)
			*/
			$data = split(" ",$var);
			list ($ano,$mes,$dia) = split("-",$data[0]);
			switch($tipo) {
				case 1:
					$retorno = $dia."/".$mes."/".$ano;
					break;
				case 2:
					$retorno = $mes."/".$dia."/".$ano;
					break;			
				case 3:
					$retorno = $ano."-".$mes."-".$dia;
					break;				
			}
			return $retorno;
		}
		
		function pegames($var,$tipo) {
			/*
				Tipos: (1 - N�mero, 2 - Extenso)
			*/
			$data = split("/",$this->pegadata($var,1));
			$mes = $data[1];			
			if ($tipo == 2) {
				switch($mes) {
					case 1:
						$mes = "Janeiro";
						break;
					case 2:
						$mes = "Fevereiro";
						break;			
					case 3:
						$mes = "Mar�o";
						break;				
					case 4:
						$mes = "Abril";
						break;				
					case 5:
						$mes = "Maio";
						break;				
					case 6:
						$mes = "Junho";
						break;				
					case 7:
						$mes = "Julho";
						break;				
					case 8:
						$mes = "Agosto";
						break;				
					case 9:
						$mes = "Setembro";
						break;				
					case 10:
						$mes = "Outubro";
						break;				
					case 11:
						$mes = "Novembro";
						break;				
					case 12:
						$mes = "Dezembro";
						break;				
				}
			}
			return $mes;	
		}
		
		function pegadia($var) {
			$data = split("/",$this->pegadata($var,1));
			return $data[0];
		}
		
		function pegaano($var) {
			$data = split("/",$this->pegadata($var,1));
			return $data[2];
		}

		function pegatempo($var,$tipo) {
			/*
				tipos: (T - Tudo, H - Hora, M - Minuto, S - Segundo)
			*/
			$data = split(" ",$var);
			list($hora,$minuto,$segundo) = split(":",$data[1]);
			switch($tipo) {
				case 'T':
					$retorno = $data[1];
					break;
				case 'H':
					$retorno = $hora;
					break;			
				case 'M':
					$retorno = $minuto;
					break;				
				case 'S':
					$retorno = $segundo;
					break;				
			}		
			return $retorno;
		}
		
		function bisexto($var) {
			if ((($var % 4) == 0) and ((($var % 100) != 0) or (($var % 400) == 0))) {
				$retorno = true;
			}
			else {
				$retorno = false;
			}
			return $retorno;
		}
		
		function subtraidata($data1,$data2) {
			/*
				Subtrair datas no formato pt_BR retonando o intervalo em dias excluindo a data inicial e a final do resultado.
			*/
			list($dia1,$mes1,$ano1) = split("/",$data1);
			list($dia2,$mes2,$ano2) = split("/",$data2);			
			$seg1 = getdate(mktime(0,0,0,$mes1,$dia1,$ano1));
			$seg2 = getdate(mktime(0,0,0,$mes2,$dia2,$ano2));
			$res = $seg1[0] - $seg2[0];
			$retorno = $res/86400;
			return abs($retorno);
		}


	}
?>