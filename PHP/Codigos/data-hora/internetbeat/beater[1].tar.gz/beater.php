<?

//--------------------------------------------
// Script traduzido e modificado por Mauricio Maciel
// http://www.brasildata.net
// Original por:                                                         
// Heruntergeladen von http://www.sutum.de                 
//---------------------------------------------            

// Extens�o dos gr�ficos 
$ext = ".gif";

// Tamanho dos gr�ficos :
$width = "15";
$height= "21";

$tempo = time();
$data = getdate($tempo); 

$horas = $data[hours] * 3600; //Horas em segundos
$minutos = $data[minutes] * 60; //Minutos em segundos
$segundos = $data[seconds];
$gmt = -3 ; // Diferen�a do Hor�rio de GMT de Bras�lia
$diferen = ((-$gmt * 60) + 60) * 60 ;

$segundos_total = ($segundos + $minutos + $horas + $diferen);

$netbeat = $segundos_total / 86.4; //Netbeat
$netbeat = floor($netbeat);

if ($netbeat > 1000) { $netbeat -= 1000; }
if ($netbeat < 0) { $netbeat += 1000; }

$tamanho = strlen($netbeat); // tamanho em caracteres da vari�vel

// Dependendo do tamanho acrescenta 0 ou 00 na vari�vel netbeat
if ($tamanho == "1") 
{
$netbeat = "00".$netbeat;
}
if ($tamanho == "2")
{
$netbeat = "0".$netbeat;
}

//Divide a variavel em peda�os para fazer a sa�da em modo gr�fico
$parte1 = substr ($netbeat, 0 , 1);
$parte2 = substr ($netbeat, 1 , 1);
$parte3 = substr ($netbeat, 2 , 3);

// Sa�da em modo gr�fico
echo ("<table border=0 cellpadding=0 cellspacing=0><tr><td><a href=\"http://www.brasildata.net\" target=\"_blank\"><img src=\"netbeat/a$ext\" width=\"$width\" height=\"$height\" border=\"0\" alt=\"At\"><img src=\"netbeat/$parte1$ext\" width=\"$width\" height=\"$height\" border=\"0\" alt=\"$parte1\"><img src=\"netbeat/$parte2$ext\" width=\"$width\" height=\"$height\" border=\"0\" alt=\"$parte2\"><img src=\"netbeat/$parte3$ext\"width=\"$width\" height=\"$height\" border=\"0\" alt=\"$parte3\"></a></td></tr></table>");

// Sa�da em modo texto

echo ("Netbeat : @$parte1$parte2$parte3"); 

?>
