<?php
include "conexao.php";
$sql="select id, nome, email, cidade, DAYOFMONTH(data) as dia,  MONTH(data) as mes, YEAR(data) as ano, mensagem FROM mensagem WHERE id=10 ORDER BY data" or die (mysql_error());
$resultado=mysql_query($sql);
$registro=mysql_fetch_array($resultado);
$dia=$registro['dia'];
$mes=$registro['mes'];
$ano=$registro['ano'];
$meses = array(1=> 'Janeiro', 'Fevereiro', 'Marco','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro');
echo $dia." de ".$meses[$mes]." de ".$ano;
?>





