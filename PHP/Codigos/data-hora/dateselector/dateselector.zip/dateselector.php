<? 
################################################################## 
##                    re-Autor Vipmaster                        ## 
##                email vipmaster@ewdesign.com.br               ## 
##  Copyright VIPMASTER, todos os direitos reservados ao autor. ## 
################################################################## 
?>
<? 
    function DateSelector($inName, $useDate=0) 
    { 
        //cr�a a disposi��o assim que n�s podemos nomear meses 
        $nomemes = array(1=> "Janeiro",  "Fevereiro",  "Mar�o", 
            "Abril",  "Maio",  "Junho",  "Julho",  "Agosto", 
            "Setembro",  "Outubro",  "Novembro",  "Dezembro"); 

        //data inv�lida ou n�o fornecida, use o tempo atual 
        if($useDate == 0) 
        { 
            $useDate = Time(); 
        } 

        /* 
        ** fa�a o seletor do m�s 
        */ 
        print("<select name=" . $inName .  "M�s>\n"); 
        for($currentMes = 1; $currentMes <= 12; $currentMes++) 
        { 
            print("<option value=\""); 
            print(intval($currentMes)); 
            print("\""); 
            if(intval(date( "m", $useDate))==$currentMes) 
            { 
                print(" selected"); 
            } 
            print(">" . $nomemes[$currentMes] .  "\n"); 
        } 
        print("</select>"); 


        /* 
        ** fa�a o seletor do dia 
        */ 
        print("<select name=" . $inName .  "Dia>\n"); 
        for($currentDia=1; $currentDia <= 31; $currentDia++) 
        { 
            print("<option value=\"$currentDia\""); 
            if(intval(date( "d", $useDate))==$currentDia) 
            { 
                print(" selected"); 
            } 
            print(">$currentDia\n"); 
        } 
        print("</select>"); 


        /* 
        ** fa�a o seletor do ano 
        */ 
        print("<select name=" . $inName .  "Ano>\n"); 
        $startAno = date( "Y", $useDate); 
        for($currentAno = $startAno - 5; $currentAno <= $startAno+5;$currentAno++) 
        { 
            print("<option value=\"$currentAno\""); 
            if(date( "Y", $useDate)==$currentAno) 
            { 
                print(" selected"); 
            } 
            print(">$currentAno\n"); 
        } 
        print("</select>"); 
    } 
?> 

<html> 
<head> 
<title>DateSelector</title> 
</head> 
<body> 
<form>
  Escolha uma data:
  <?php DateSelector("Exemplo"); ?>
</form> 
</body> 
</html> 