<?  
################################################################## 
##                    re-Autor Vipmaster                        ## 
##                email vipmaster@ewdesign.com.br               ## 
##  Copyright VIPMASTER, todos os direitos reservados ao autor. ## 
################################################################## 
?>
<? 

// Paramentos:
// $mm   - mes de aniversario 
// $dd   - dia de aniversario 
// $yyyy - Ano de aniversario

function getAgeByDate($iMonth, $iDay, $iYear) { 
    $iTimeStamp = (mktime() - 86400) - mktime(0, 0, 0, $iMonth, $iDay, $iYear); 
    $iDays = $iTimeStamp / 86400; 
    $iYears = floor($iDays / 365.25); 
    return $iYears; 

} 

?>

Exemplo:

<?
print getAgeByDate(04, 17, 1980); 

O resultado indicar� "20" 

Ou, se voc� quiser se certificar algu�m n�o � um menor, � aqui um exemplo de como validar uma data do nascimento: 

if (getAgeByDate("04", "17", "1983") > 18) { 
    print "A pessoa � um menor!"; 
} 
?> 