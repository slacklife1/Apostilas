<? 
### Este script � de livre distribui�ao 
### de acordo com a licen�a publica GNU
###
### Programador: Renato Coutinho de Rezende Dominiqueli


function countdown(){

	$dia_lanca = 3;
	$mes_lanca = 11;

	$dia_atual = date("d");
	$mes_atual = date("m");

	if ( $mes_lanca == $mes_atual ) {
		
		$dia_lancamento = $dia_lanca - $dia_atual;
		echo $dia_lancamento;

	} else {
		
		$meses = $mes_lanca - $mes_atual;

		$i = 0;
		$dias = 0;

		while ( $i != $meses+1 ) {
			
			$dias_mes = mktime(0,0,0,$mes_atual+$i+1,0,2003);
			@$dias = @$dias + strftime("%d",$dias_mes);
			$i++;
			
		}

			$dias_ultimo_mes = strftime("%d",mktime(0,0,0,$mes_lanca+1,0,2003) );	
			$ddd = $dias_ultimo_mes - $dia_lanca;

			$dia = $dias - $dia_atual;		
			$dia = $dia - $ddd;

			echo $dia;
	}

}
?>