<?php

/* 
class mydate() -> Simples classe para manipular 
                  datas atrav�s do MySQL

-----------------------------
copyleft � 2003 Cau Guanabara
e-mail: caugb@netflash.com.br
-----------------------------

Veja exemplos de utiliza��o no arquivo 'mydate_test.php', em anexo.
 */
 
class mydate {

var $conn;

	function mydate ($host = 'localhost', $user = '', $pass = '') {
	$this->conn = mysql_connect($host,$user,$pass) or 
		die('Sem conex�o, veja a mensagem de erro do sistema:<br />'.mysql_error());
	}
	
	function dat_op ($op = '+',$num = 1,$unit = 'DAY',$tstp = '') {
	$unit_types = array("YEAR","MONTH","DAY","HOUR","MINUTE","SECOND");
	$tstper = "/^(\d{4})-(\d{2})-(\d{2})(\s(\d{2}):(\d{2}):(\d{2}))*$/";
		if(($op != '+' and $op != '-')) {
		die('dat_op() -> ERRO: operador desconhecido ("'.$op.'", par�metro 1)<br />');
		}
		if(!($num > 0)) {
		die('dat_op() -> ERRO: o quantificador deve ser maior que zero ("'.$num.'", par�metro 2)<br />');
		}
		if(!in_array($unit,$unit_types)) {
		die('dat_op() -> ERRO: unidade desconhecida ("'.$unit.'", par�metro 3)<br />');
		}
		if(!preg_match($tstper,$tstp)) {
		die('dat_op() -> ERRO: timestamp inconsistente ("'.$tstp.'", par�metro 4)<br />');
		}
	return $this->_query("SELECT '$tstp' $op INTERVAL $num $unit");
	}
	
	function convert ($time, $type = 'to_days') {
		if($type == 'to_days') {
			if(!preg_match("/^(\d{4})-(\d{2})-(\d{2})$/",$time)) 
				die('convert() -> ERRO: data inconsistente ("'.$time.'", par�metro 1)<br />');
		}
		elseif($type == 'to_date') {
			if(!preg_match("/^\d+$/",$time)) 
				die('convert() -> ERRO: data inconsistente ("'.$time.'", par�metro 1)<br />');
		}
		else {
		die('convert() -> ERRO: tipo de convers�o desconhecido ("'.$type.'", par�metro 2)<br />');		
		}
		switch($type) {
		case "to_days": $sql = "SELECT TO_DAYS('$time')"; break;
		case "to_date": $sql = "SELECT FROM_DAYS('$time')"; break;
		}
	return $this->_query($sql);
	}	

	function _query ($query) {
	$res = @mysql_query($query,$this->conn) or 
		die("_query() -> ERRO: query n�o aceita ($query): ".mysql_error()."<br />");
	$rtrn = mysql_fetch_row($res);
	return $rtrn[0];
	}

}

?>
