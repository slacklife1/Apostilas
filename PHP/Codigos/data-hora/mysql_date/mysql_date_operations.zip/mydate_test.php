<?php 

/* 
class mydate() -> Simples classe para manipular 
                  datas atrav�s do MySQL

-----------------------------
copyleft � 2003 Cau Guanabara
e-mail: caugb@netflash.com.br
-----------------------------
 */

include "mysql_date.php";

/* 
  Para instanciar a classe, dependendo das configura��es do seu servidor MySQL,
  pode n�o ser preciso mandar as informa��es HOST, USER e PASS
  */
$MD = new mydate(); 
// se isso n�o funcionar, use assim: 
// $MD = new mydate("localhost","_usuario_","_senha_");

/* 
 S�o duas fun��es apenas: dat_op() e convert().

 >> A dat_op() serve para somar ou subtrair anos, meses, dias, horas, minutos ou segundos 
 a determinado momento no tempo. Esse momento deve ser representado no formato timestamp, 
 assim: 'ano-mes-dia hora:minuto:segundo' - 4 d�gitos para o ano e 2 para os outros.
 N�o � pss�vel, por exemplo, somar 2 dias e cinco horas em uma �nica opera��o. 
 � perciso ma chamada para cada tipo de unidade a ser utilizada.
 */
 
 //exemplo:
$operador = "+"; // opera��o desejada ('+' ou '-')
$numero = 10; // n�mero de unidades a ser somada ou subtra�da
$unidade = "HOUR"; // unidade para a opera��o ("YEAR","MONTH","DAY","HOUR","MINUTE" ou "SECOND")
$timestamp = "2003-11-28 21:38:04"; // timestamp base para os calculos (yyyy-mm-dd hh:mm:ss)
print "dat_op() -> '$timestamp' $operador $numero $unidade = '";
print $MD->dat_op ($operador, $numero, $unidade, $timestamp)."' <br />";
//Isso somou 10 horas ao momento "2003-11-28 21:38:04". Retorna: "2003-11-29 07:38:04 <br />"

/*  
 >> A convert() serve para converter datas em dias (a partir do ano zero) e vice-versa.
 Muito �til para calcular a diferen�a em dias entre duas datas 
 ou converter um grande per�odo de dias em anos, meses e dias.
 */
 
 //Por exemplo, quantos dias viveu uma pessoa que nasceu em 13 de abril de 1970?
$mydate = "1970-04-13"; // data do nascimento
$type = "to_days"; // tipo de opera��o ("to_days" ou "to_date")
$mydate_days = $MD->convert($mydate,$type);
$mydate2 = date("Y-m-d"); // data atual
$mydate2_days = $MD->convert($mydate2,$type);
$idade_dias = ($mydate2_days - $mydate_days);
$dt = $MD->convert($idade_dias, "to_date");
list($an,$me,$di) = explode("-",$dt);
$an = preg_replace("/^0+/","",$an);
$me = preg_replace("/^0+/","",$me);
$di = preg_replace("/^0+/","",$di);
print 'convert() -> Se voc� nasceu em '.implode("/",array_reverse(explode("-",$mydate))).",
		agora voc� est� vivo h� $idade_dias dias ($an anos, $me meses e $di dias) <br />\n";

?>
