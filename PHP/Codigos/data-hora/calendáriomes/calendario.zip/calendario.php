<?

if (empty($mes)) {
$mes = date("m");
$ano = date(Y);
}
switch($mes)
{
case "01" : $mesext = "Janeiro";	 break;
case "02" : $mesext = "Fevereiro";	 break;
case "03" : $mesext = "Mar�o";		 break;
case "04" : $mesext = "Abril";		 break;
case "05" : $mesext = "Maio";		 break;
case "06" : $mesext = "Junho";		 break;
case "07" : $mesext = "Julho";		 break;
case "08" : $mesext = "Agosto";		 break;
case "09" : $mesext = "Setembro";	 break;
case "10" : $mesext = "Outubro";	 break;
case "11" : $mesext = "Novembro";	 break;
case "12" : $mesext = "Dezembro";	 break;
}

$next = mktime(0,0,0,$mes + 1,1,$ano);
$nextano = date("Y",$next);
$nextmes = date("m",$next);

$prev = mktime(0,0,0,$mes - 1,1,$ano);
$prevano = date("Y",$prev);
$prevmes = date("m",$prev);

$d = mktime(0,0,0,$mes,1,$ano);
$diaSem = date('w',$d);
?>

<table bgcolor="#CCFFCC" width="245" border="0" align="center" cellpadding="0" cellspacing="0">
<tr> 
    <td width="35"><div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="../calendario1.php?mes=<? echo $prevmes; ?>&ano=<? echo $prevano; ?>">&lt;=</a></font></div></td>
    <td colspan="5"><div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><? echo $mesext." / ". $ano?></font></div></td>
    <td width="35"><div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><a href="../calendario1.php?mes=<? echo $nextmes; ?>&ano=<? echo $nextano; ?>">=&gt;</a></font></div></td>
  </tr>
  <tr> 
    <td width="35"><div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Dom</font></div></td>
    <td width="35"><div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Seg</font></div></td>
    <td width="35"><div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Ter</font></div></td>
    <td width="35"><div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Qua</font></div></td>
    <td width="35"><div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Qui</font></div></td>
    <td width="35"><div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Sex</font></div></td>
    <td width="35"><div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">S&aacute;b</font></div></td>
  </tr>
  <?  
//Enquanto hover dias 
	echo "<tr>";
// Coloca os dias em Branco
for($i = 0; $i < $diaSem; $i++)
{
	echo "<td width=35>&nbsp;</td>";
}	
for($i = 2; $i < 33; $i++)
{
	$linha = date('d',$d);
	if($i > 3) {
}
	echo "<td><div align=center><font size=2 face=Verdana><a href=inseredata.php?data=".$linha."/".$mes."/".$ano.">".$linha."</a></font></div></td>";
	
// Se S�bado desce uma linha
	
if (date('w',$d) == 6){	echo "</tr>"; }

	$d = mktime(0,0,0,$mes ,$i, $ano);
	if(date('d',$d) == "01") { break; }
}
?>
  <tr> 
    <td width="35">&nbsp;</td>
    <td width="35">&nbsp;</td>
    <td width="35">&nbsp;</td>
    <td width="35">&nbsp;</td>
    <td width="35">&nbsp;</td>
    <td width="35">&nbsp;</td>
    <td width="35">&nbsp;</td>
  </tr>
</table>
