--------------------------------------
* Trumedia PHP counter by Galen Grover
--------------------------------------

1. Upload library.lib, counter.dat and images folder. Example.php is just an example.
2. Edit the 2 defined variables in library.lib to suit your needs.
3. CHMOD counter.dat to 666.
4. At the top of the PHP file in which you wish to display the counter add: include("library.lib"); 
5. Type: counter("image"); or: counter("text"); or: counter("invisible"); 
   where you want your counter to be displayed [or not if invisible].

NOTE: If you wish to change the images just be sure to name them 0.gif, 1.gif, 2.gif etc...
      Other image formats are fine but will take longer to load.

-----------------------------------------------
* Any questions email me at galengrover@msn.com
-----------------------------------------------
------------------------------------------------
* Visit my website at http://trumedia.gyrate.org
------------------------------------------------
