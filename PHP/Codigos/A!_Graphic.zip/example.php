<?php

include("library.lib");
counter("image");

?>