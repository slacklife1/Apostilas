miniScript v1.0 Installation
============================

Requirements :
1) PHP4
2) MySQL


Installation steps :
1) Copy the install.php into your web root directory and run it from the web 
   browser. It will guide you through the installation process.
2) After running this file, copy create a direcory call banner in your web root
   and copy all files into that directory.
3) You are now ready to use miniBanner.


Note:
1) miniScript.com will cannot be held responsible for any damage or whatsoever
   inconviniences caused by installing this script.
2) If you are not comfortable with this, please consult someone who knows PHP.


Contact Information:
1) Our website is http://www.miniscript.com
2) Our email is ykf2000@yahoo.com


THANK YOU FOR USING miniBanner!!!