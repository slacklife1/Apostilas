<?php

	header("Content-type: application/x-javascript"); 
	include('conn.php');
	include('banner.php');
	new Banner($id);
?>

