<!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title> Banner Manager</title>
<meta name="Author" content="Yip Kwai Fong">
<meta name="Keywords" content="Banner Manager, Ad Rotator">
<meta name="Description" content="Banner Manager">
</head>
<body bgcolor="white">
<font face="arial" size="2">
Copy and Paste this code to your page where you want the banner to appear:
<br><br>
<i>
&lt;SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript" SRC="http://www.miniscript.com/banner/java.php?id=<?php echo $cid; ?>"&gt; 
&lt;/SCRIPT&gt;
</i>
</font>
<br>
<br>
<center><form><input type="button" value="Close" onClick="javascript: self.close();"></center>

</body>
</html>
