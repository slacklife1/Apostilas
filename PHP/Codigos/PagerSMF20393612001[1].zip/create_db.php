<?
require("config.php");
error_reporting(15);

$connect_db=mysql_connect($server,$user,$pass);
$create_db=mysql_create_db($dbname);
mysql_query($create_db);

mysql_select_db($dbname);
$create_tbl=("CREATE TABLE fm (id INT (3) not null AUTO_INCREMENT,
             name VARCHAR (35) not null ,
             msg VARCHAR(42) not null ,
             PRIMARY KEY (id))");

$rezult=mysql_query($create_tbl);
$insert_data="INSERT INTO fm (name,msg)
VALUES ('bogomil','Enjoy!')";
mysql_query($insert_data);
echo("Done");
?>
