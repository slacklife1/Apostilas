<html>
<META HTTP-EQUIV="Refresh" CONTENT="0;URL=view.php">

<body>
<?
require("config.php");
mysql_connect($server,$user,$pass);
mysql_select_db($dbname);
$insert_data="INSERT INTO fm (name,msg)
VALUES ('$name','$message')";
mysql_query($insert_data);

    ?>
 </html>
