<?

$server="DBServer";
$user="DB user";
$pass="DB password";
$dbname="DB name";

?>


