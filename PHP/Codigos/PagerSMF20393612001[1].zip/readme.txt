++++++++++++++
first configure config.php
then run create_db.php

and start index.html
=======================
For bugs repport please e-mail me
contact_bogomil@dir.bg

Thank's!