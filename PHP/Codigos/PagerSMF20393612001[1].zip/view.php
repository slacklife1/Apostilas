<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head>
       <title>View</title>
</head>
<body>

         <?php
require("config.php");
mysql_connect ($server, $user, $pass);
mysql_select_db($dbname);

 $select_data=("SELECT name,msg  FROM fm  WHERE msg is NOT NULL");
 $ver=mysql_query($select_data);


   while ($row = mysql_fetch_array ($ver))
        {
      echo "<table width=100% border=0 background=bg1.gif ><tr><td></font><font color=black> ".$row[0]." &nbsp<br><font color=blue><b>say:</b></font><br></font></td></tr></table>";
      echo "<table width=100% border=1 bordercolor=green background=bg2.gif ><tr><td><font color=black></b> ".$row[1]."<br>\n</font></tr></td></table>";
         }

?>


 <p>

<table width=10% border=1 align=center background=tblbgr.gif><tr><td>
  <form name = pager method=post action=get2.php>
<input type=text size=10 name=name  maxlength="12" value=name><br>
<input type=text size=10 name=message maxlength="12" value=message><br>
<input type=image src=btn.gif name=action value=Heat><br><a href=view.php><img src=rld.gif border=0></a>
</form>
</tr></td></table>
 </p>

</body>
</html>
