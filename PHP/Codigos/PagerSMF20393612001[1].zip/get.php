<html>
<head>
<title>Pager</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<script language="JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
</script>
</head>

<body bgcolor="#FFFFFF" text="#000000">
<div id="Layer1" style="position:absolute; width:156px; height:545px; z-index:1; left: 824px; top: 23px">

<table width="87%" border="1" height="529" bordercolor="#000099">
<tr>
<td><?
require("config.php");
mysql_connect($server,$user,$pass);
mysql_select_db($dbname);
$insert_data="INSERT INTO fm (name,msg)
VALUES ('$name','$message')";
mysql_query($insert_data);
// responce

mysql_connect ($server, $user, $pass);
mysql_select_db($dbname);

 $select_data=("SELECT id,name,msg  FROM fm");
 $ver=mysql_query($select_data);

   while ($row = mysql_fetch_array ($ver))
        {
            if($row[0] > 2){

           $runer=("DELETE FROM fm WHERE id=1");
           mysql_query($runner);


      echo "<table width=20% border=0 bgcolor=lightblue align=center><tr><td><font color=white><b>From:</b></font></font><font color=green> ".$row[1]."<br></font></td></tr></table>";
      echo "<table width=10% border=1 bordercolor=white bgcolor=blue align=center><tr><td><font color=yellow><b>Message:</b> ".$row[2]."<br>\n</font></tr></td></table>";
         }
     }

?>
<table width=10% border=0 align=center><tr><td>
  <form name = pager method=post action=get.php>
<input type=text size=10 name=name><br>
<input type=text size=10 name=message><br>
<input type=submit name=action value=Heat>
</form>
</tr></table>
</td>
</tr>
</table>
</div>

</body>
</html>
