MyOrgBook  Version 1.0 -----> bkesten@it-firm.com


************************************LICENSE************************************
This version, version 1.0 is free for non-commercial and commercial use. You may modify this product for your own use, but you may not redistibute it without written aknowlengde from the copyright holder, Brian Kestenholz. Changes, bugfixes and so on is welcome, and we will include this in upgrades and later packages. 

Brian Kestenholz reserve the right to charge money for this program in later realeases.

Please read the license terms at the buttom of this document! Basically, use this product at your OWN RISK. This product is in development, and errors of any kind may accur.

Live use of this product is at:  http://www.it-firm.com

 

*********************************CURRENT FEATURES*********************************

1. Multi-User Login:  

MyOrgBook allows multiple users to sign up for accounts.  I tested it with over 50 accounts without a problem, and I'm sure it will work with many more.  It is password protected using MySql as the backend... How secure is it you ask????  I think it is secure but since I'm not a professional programmer you will have to get back to me with any security holes.... If you find any please email me at bkesten@it-firm.com, and check back on www.it-firm.com for any updates in the future.

2. Email Account Verification
	
When a user signs up it automatically emails their account information to them.  

3. Search, Update, Delete, Add

MyOrgBook allows you to ADD, SEARCH, UPDATE and DELETE any contacts or tasks that are associated with your account.

4.  Calendar

MyOrgBook has a calendar and task scheduler.  This will be improved in later versions but it is very functional in Version 1.

5.  Emailer

MyOrgBook has a built in emailer that allows you to quickly email any contacts within your online organizer

6. Lost Password Emailer

MyOrgBook has a PHP script that a user with a lost password to enter the email address and it will email their password to their email account.


***********************************INSTALLATION********************************

Step 1. 

First you must create the database and the tables.  You need permissions to create databases in MySql... If you have the adequate permissions 
 	
	1. Open the createdatabase.txt file 
	2. Edit the set_password on the last line to reflect the password you would like to 	use for the database.  
	3. Then create the database in that file.  

If you don't have the permission to create the database email your ISP or Webhost the createdatabase.txt file and ask them to please create the database with the username and password found in that file.

Step 2.  
Edit the variables found in the following files to reflect your information.

  	1.  security.php3-  Set $cookdomain variable to the domain of your web site. An 		                    example is .it-firm.com
	2   database.inc-   set $mypassword variable to the password you setup for the database.
	



Step 3.  

FTP or Copy the files onto the server with PHP3 & MySql support. Keep everything in the same file structure as found in the zip file.  Go to the index.php3 page and test it out.  Everything should work.  If you encounter problems email bkesten@it-firm.com.  
   

__________________________________________________________________


AUTHOR: Brian Kestenholz  

Feel free to email with any problems\suggestions or concerns.... briankestenholz@hotmail.com  In the near future or if not already it-firm.com will have a project signup if you want to join and help improve MyOrgBoook.  Check out www.it-firm.com.
