<?php
/******************************************************************************
Power Banner Manager Beta 2 !
(footer.php file)

This is file that is included in every file, it displays navigation links
at the end of the file and copyright informations.

Copyright Armin Kalajdzija, 2002.
E-mail: kalajdzija@hotmail.com
WebSite: http://www.ak85.tk
******************************************************************************/


print "<table width='950' border='0' cellpadding='0' cellspacing='0'><tr><td height='30'>";   // adding navigation links table
print "<div align='right'><font face='Verdana' size='2'><a href='admin.php?action=add'>Add banner</a> | ";

if (isset($action)) {                     // site check
    if ($action == "gfx") {
       print "<a href='admin.php'>Switch to text mode</a> | ";
    }else{
       print "<a href='admin.php'>Back to Admin Panel</a> | ";
    }

}else{
    print "<a href='admin.php?action=gfx'>Switch to graphic mode</a> | ";
}
print "<a href='admin.php?action=chpass'>Change password</a> | ";
print "<a href='http://www.ak85.tk'>www.ak85.tk</a></font></div></td></tr></table>";    // link to my site :)
print "<br><div align='center'><font face='Verdana' size='1'><a href='mailto:kalajdzija@hotmail.com'>Copyright Armin Kalajdzija, 2002.</a></div></font>"; // copyright info

?>
