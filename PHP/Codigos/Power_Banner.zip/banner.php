<?php

include "config.php";
$bancount = 0;
$varcount = 0;


if (isset($hostname) and isset($database) and isset($db_login) and isset($db_pass)) {
    $dbconn = mysql_connect($hostname, $db_login, $db_pass) or die("Could not connect");
    
    mysql_select_db($database) or die("Could not select database");
    
    $query = "SELECT * FROM powerban";
    $result = mysql_query($query) or die("Query failed");
    $numrows = mysql_num_rows ($result);

    while ($rows = mysql_fetch_row($result)) {
    $bancount = $bancount + 1;
    $banner[$bancount] = "$rows[0]|$rows[1]|$rows[2]|$rows[3]|$rows[4]";
    }

}
$display_banner = rand(1,$bancount);      //generates the randome number from 1 to the number of banners :)

list($src,$alt,$link,,$vlink) = split('[|]',$banner[$display_banner]);

echo "<a href='visit.php?id=$vlink'><img src='$src' alt='$alt' border=0></a>";   //displays the image on site

?>

