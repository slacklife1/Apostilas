Power Banner Manager Beta 2
---------------------------

1. What is new
2. Instalation
3. Description
4. About Author

1. WHAT IS NEW

   This beta 2 version is not so diferent from beta 1 except that authentification
   part of admin.php script is now based on sessions (not on cookie like beta 1).
   This is very important change on script becose I have recaved many mails from
   people that didn't have cookies enabled in there browser. There is just one more
   change and it is in visit.php redirection script, it was using javascript to
   redirect visitor, now, it is using header() function :)

2. INSTALATION

   All you need to do is enter you data in config.php before running
   install.php script. If you have enter all data, run install.php and
   chose your admin login and password. After that, two tables will be
   created in your MySQL database (powerban, powerban_auth).

   When you finish installing the Power Banner, goto to admin.php and
   login in with your new login and password.

3. DESCRIPTION

   This is my new banner script that uses MySQL, you can add as many
   banners as you wany, and it counts every visit.
   This is the list of files:

   Admin.php - Administration Panel Script

   Banner.php - Banner Display Script (this is the file that needs to
   be included in your index page)

   Config.php - Configuration scripts that includes variables for you
   MySQL database

   Install.php - This is the instalation script, creates tables and admin
   account.

   Footer.php - File that displays navigation bar and copyright info
   in admin.php script.

   Visit.php - This script redirects visitor to a site that he has clicked
   but it counts the visit number.

4. ABOUT AUTHOR

   My name is Armin Kalajdzija and I am young developer form Bosnia and Herzegovina.
   I am 17 years old and this is my first time coding in PHP, before this I
   was coding in VisualBasic and Delphi and I still do :)

   If you have any questions or sugestions please send it to:
   kalajdzija@hotmail.com 
   or visit my home page:
   http://www.ak85.tk

Copyright Armin Kalajdzija, 2002.