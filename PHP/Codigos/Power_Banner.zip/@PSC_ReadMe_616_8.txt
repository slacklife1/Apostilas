Title: Power Banner Manager Beta 2
Description: This is my new banner script that uses MySQL, it counts every visit and have administration panel. This version comes with administration panel that doesn't use cookies :)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=616&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
