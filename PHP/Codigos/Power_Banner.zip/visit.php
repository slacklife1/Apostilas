<?php

include "config.php";

if (isset($hostname) and isset($database) and isset($db_login) and isset($db_pass)) {
    $dbconn = mysql_connect($hostname, $db_login, $db_pass) or die("Could not connect");

    mysql_select_db($database) or die("Could not select database");

    $query = "SELECT url,visits FROM powerban WHERE id=$id";
    $result = mysql_query($query) or die("Query failed");
    
    $rows = mysql_fetch_row($result);
    
    $visits = $rows[1] + 1;
    $query = "UPDATE powerban SET visits=$visits WHERE id=$id";
    $result = mysql_query($query) or die("Query failed");
    header("Location:$rows[0]");
}

?>
