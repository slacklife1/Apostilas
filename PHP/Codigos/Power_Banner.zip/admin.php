<?php
/******************************************************************************
Power Banner Manager beta 2 !
(admin.php file)

Administration Panel is the main part of the script. It also uses conifg.php
variables for MySQL connection. When you login, script is setting a cookie
called PBAPCookie and stores login and crypted password. Script is using this
cookie for an hour and then deletes it (you can do it if you logout too).

Copyright Armin Kalajdzija, 2002.
E-mail: kalajdzija@hotmail.com
WebSite: http://www.ak85.tk
******************************************************************************/

session_start();
include "config.php";
$varcount = 0;
$auth = false;   // setting auth var to false

if (!session_is_registered('user_login')) {

   if (isset($user_login) and ($user_login <> "") and isset($user_pass) and ($user_pass <> "")) {     // connection to MySQL
    if (isset($hostname) and isset($database) and isset($db_login) and isset($db_pass)) {
    $dbconn = mysql_connect($hostname, $db_login, $db_pass) or die("Could not connect");

    mysql_select_db($database) or die("Could not select database");
    
    $query = "SELECT login,password FROM powerban_auth";        // selecting login and pass from database
    $result = mysql_query($query) or die("Query failed");
    
    $line = mysql_fetch_array($result);

    if ($line[0] == $user_login) {          // login check
        if ($line[1] == (crypt($user_pass,$line[1]))) {      // pass check
            $auth = true;        // setting to true
            session_register('user_login');
            session_register('user_pass');
            $date = date("Y-m-d h:i:s");
            $query = "UPDATE powerban_auth SET ip='$REMOTE_ADDR', date='$date'";   //updating IP and date when last logged
            $result = mysql_query($query) or die("Query failed");
        }
    }
}
}
}else{
    $auth = true;
}

if (!$auth) {
// login and password display
print "<br><br><br><form name='forma' method='post' action='admin.php'>";
print "<table width='350' border='0' align='center' cellpadding='0' cellspacing='0'>";
print "<tr bgcolor='#003366'>";
print "<td colspan='2'>";
print "<div align='center'><font face='Verdana' size='2'><b><font color='#FFFFFF'>Power Banner Beta 1</font></b></font></div>";
print "</td>";
print "</tr>";
print "<tr><td width='118'><font face='Verdana' size='2'>Login:</font></td>";
print "<td width='232'><font face='Verdana' size='2'><input type='text' name='user_login'></font></td></tr>";
print "<tr><td width='118'><font face='Verdana' size='2'>Password:</font></td>";
print "<td width='232'><font face='Verdana' size='2'><input type='password' name='user_pass'></font></td></tr>";
print "<tr><td colspan='2'><div align='center'><input type='submit' name='btnlogin' value='Login'><input type='reset' name='Submit2' value='Reset'>";
print "</div></td></tr></table>";
}

if ($auth) {

    $dbconn = mysql_connect($hostname, $db_login, $db_pass) or die("Could not connect");

    mysql_select_db($database) or die("Could not select database");

      if (isset($action) and ($action == "logout")) {        // action logout
          session_destroy();
          Print "<div align='center'><font face='Verdana' size='3'>You are logged out !</font>";
          Print "<br><font face='Verdana' size='2'><a href='admin.php'>Click here to login again</a></font></div>";
          die;
      }
      print "<title>Power Banner Manager Beta 2 !</title>";
      Print "<font face='Verdana' size='5'>Power Bannner Administration Panel !</font><br>";

      print "<font face='Verdana' size='2'>MySQL Ver: ";
      print mysql_get_server_info($dbconn);
      print " | User Logged: $db_login  <a href='admin.php?action=logout'>Logout</a> | Host: ";
      print mysql_get_host_info($dbconn);
      print "</font><br><br>";

    if (isset($action)) {
      if ($action == "gfx") {            // graphic mode display

         $query = "SELECT src,id FROM powerban";
         $result = mysql_query($query) or die("Query failed");

         print "<table border='1' cellpadding='0' cellspacing='0'>\n";
         print "<tr bgcolor='#000066'>";
         print "<td width='950'><font face='Verdana' size='2' color='#FFFFFF'>Banners</font></td>";
         print "</tr>";
         
         while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
             foreach ($line as $col_value[$varcount]) {
                 $varcount = $varcount + 1;
             }
         // display picture from database
         print "\t\t<td><div align='center'><font face='Verdana' size='2'><a href='admin.php?action=view&id=$col_value[1]'><img src='$col_value[0]' border='0'></a></div></td>\n";
         $varcount = 0;
         
         print "\t</tr>\n";
         }
         print "</table>\n";



        }else if ($action == "view") {          // when banner is clicked in graphic mode

           $query = "SELECT * FROM powerban WHERE id=$id";
           $result = mysql_query($query) or die("Query failed");

           print "<table border='1' cellpadding='0' cellspacing='0'>\n";
           print "<tr bgcolor='#000066'>";
           print "<td width='350'><font face='Verdana' size='2' color='#FFFFFF'>Source</font></td>";
           print "<td width='200'><font face='Verdana' size='2' color='#FFFFFF'>Alt Text</font></td>";
           print "<td width='200'><font face='Verdana' size='2' color='#FFFFFF'>Link</font></td>";
           print "<td width='50'><font face='Verdana' size='2' color='#FFFFFF'>Visits</font></td>";
           print "<td width='50'><font face='Verdana' size='2' color='#FFFFFF'>ID</font></td>";
           print "<td width='50'><font face='Verdana' size='2' color='#FFFFFF'>Edit</font></td>";
           print "<td width='50'><font face='Verdana' size='2' color='#FFFFFF'>Delete</font></td>";
           print "</tr>";
           
           while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
           print "\t<tr>\n";
              foreach ($line as $col_value) {
                 print "\t\t<td><font face='Verdana' size='2'>$col_value</font></td>\n";
              }
           print "<td width='50'><font face='Verdana' size='2'><a href='admin.php?action=edit&id=$id'>Edit</a></font></td>";
           print "<td width='50'><font face='Verdana' size='2'><a href='admin.php?action=del&id=$id'>Delete</a></font></td>";
           print "\t</tr>\n";
           }
           print "</table>\n";

         }else if (($action == "del") and ((!isset($sure)) or ($sure <> 1))) {      // delete action sure?
             print "<br><font face='Verdana' size='2'>Are you sure to delete the $id banner ?</font>";
             print "<br><font face='Verdana' size='2'><a href='admin.php?action=del&id=$id&sure=1'>YES</a></font>";

         }else if (($action == "del") and (isset($sure)) and ($sure == 1)) {        // delete action yes
             $query = "DELETE FROM powerban WHERE id=$id";
             $result = mysql_query($query) or die("Query failed");
             
             print "<br><font face='Verdana' size='2'>Banner $id deleted !</font>";

         }else if (($action == "edit") and (!isset($change))) {      // edit action

             $query = "SELECT src,alt,url FROM powerban WHERE id=$id";
             $result = mysql_query($query) or die("Query failed");

             print "<table border='1' cellpadding='0' cellspacing='0'>\n";
             print "<tr bgcolor='#000066'>";
             print "<td width='320'><font face='Verdana' size='2' color='#FFFFFF'>Source</font></td>";
             print "<td width='320'><font face='Verdana' size='2' color='#FFFFFF'>Alt Text</font></td>";
             print "<td width='320'><font face='Verdana' size='2' color='#FFFFFF'>Link</font></td>";
             print "</tr>";
             print "</table>";
             print "<form name='change' method='post' action='admin.php'>";

             while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
                 foreach ($line as $col_value[$varcount]) {

                     $fname = mysql_field_name($result,$varcount);
                     print "<input type=text name=$fname value='$col_value[$varcount]' size='50'>";
                     $varcount = $varcount + 1;
                 }
             $varcount = 0;
             }
             print "<input type='hidden' name='id' value=$id>";
             print "<input type='hidden' name='action' value='edit'>";
             print "<input type='hidden' name='change' value=1>";
             print "<br><br><input type='submit' name='sub' value='Change'></form>";

         }else if (($action == "add") and (!isset($doadd))) {           // add action

             print "<form name='add' method='post' action='admin.php'>";
             print "<table border='1' cellpadding='0' cellspacing='0'>\n";
             print "<tr bgcolor='#000066'>";
             print "<td width='320'><font face='Verdana' size='2' color='#FFFFFF'>Source</font></td>";
             print "<td width='320'><font face='Verdana' size='2' color='#FFFFFF'>Alt Text</font></td>";
             print "<td width='320'><font face='Verdana' size='2' color='#FFFFFF'>Link</font></td>";
             print "</tr>";
             print "</table>";

             print "<input type=text name=src size='50'>";
             print "<input type=text name=alt size='50'>";
             print "<input type=text name=url size='50'>";
             print "<input type='hidden' name='action' value='add'>";
             print "<input type='hidden' name='doadd' value=1>";
             print "<br><br><input type='submit' name='sub' value='Add banner'></form>";

         }else if (isset($change) and ($change == 1)) {               //change action .. goes after edit :)
                  $query = "UPDATE powerban SET src='$src' , alt='$alt', url='$url' WHERE id=$id";
                  $result = mysql_query($query) or die("Query failed");

                  print "<br><font face='Verdana' size='2'>Change on $id banner is done !</font>";

    }else if (isset($doadd) and ($doadd == 1)) {     // do add action .. goes after add :)
          $id = rand(1,999);

          $query = "SELECT url FROM powerban WHERE id=$id";
          $result = mysql_query($query) or die("Query failed");

          $line = mysql_fetch_array($result);

          while ($line[0] <> "") {
          $id = rand(1,999);

          $query = "SELECT url FROM powerban WHERE id=$id";
          $result = mysql_query($query) or die("Query failed");

          $line = mysql_fetch_array($result);
          }

          $query = "INSERT INTO powerban (src, alt, url, visits, id) VALUES ('$src','$alt','$url','0','$id')";
          $result = mysql_query($query) or die("Query failed");

          print "<br><font face='Verdana' size='2'>New banner addedd ! (Banner's ID: $id)</font>";

    }else if (($action == "chpass") and (!isset($chpass))) {             // input new pass action
          print "<form name='chpass' method='post' action='admin.php'>";
          print "<font face='Verdana' size='2'>New Password: <input type='password' name='new_user_pass'><br>";
          print "New Password (again): </font><input type='password' name='new_user_pass2'><br>";
          print "<input type='hidden' name='action' value='chpass'>";
          print "<input type='hidden' name='chpass' value='1'>";
          print "<input type='submit' name='chpassw' value='Change Password'>";

    }else if ((isset($chpass) and ($chpass == 1) and ($action == "chpass"))) {    //change password action
        if ($new_user_pass == $new_user_pass2) {           //password and password(again) match
            $new_user_pass3 = crypt($new_user_pass);        //crypte new one

        $query = "UPDATE powerban_auth SET password='$new_user_pass3' WHERE login='$user_login'";   //store new one
        $result = mysql_query($query) or die("Query failed");
        print "<font face='Verdana' size='2'>Password has been changed !</font><br>";
        print "<font face='Verdana' size='2'><a href='admin.php'>Click here to login again</a></font>";
        }else{
           print "<font face='Verdana' size='2'>Password doesn't match with confirmed one !</font>";
       }
    }
          
    }else{

    $query = "SELECT * FROM powerban";                 // standard banner text display
    $result = mysql_query($query) or die("Query failed");
    
    print "<table border='1' cellpadding='0' cellspacing='0'>\n";
    print "<tr bgcolor='#000066'>";
    print "<td width='350'><font face='Verdana' size='2' color='#FFFFFF'>Source</font></td>";
    print "<td width='200'><font face='Verdana' size='2' color='#FFFFFF'>Alt Text</font></td>";
    print "<td width='200'><font face='Verdana' size='2' color='#FFFFFF'>Link</font></td>";
    print "<td width='50'><font face='Verdana' size='2' color='#FFFFFF'>Visits</font></td>";
    print "<td width='50'><font face='Verdana' size='2' color='#FFFFFF'>ID</font></td>";
    print "<td width='50'><font face='Verdana' size='2' color='#FFFFFF'>Edit</font></td>";
    print "<td width='50'><font face='Verdana' size='2' color='#FFFFFF'>Delete</font></td>";
    print "</tr>";
    
    while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
     print "\t<tr>\n";
     foreach ($line as $col_value[$varcount]) {

         print "\t\t<td><font face='Verdana' size='2'>$col_value[$varcount]</font></td>\n";
         $varcount = $varcount + 1;
     }
     print "<td width='50'><font face='Verdana' size='2'><a href='admin.php?action=edit&id=$col_value[4]'>Edit</a></font></td>";
     print "<td width='50'><font face='Verdana' size='2'><a href='admin.php?action=del&id=$col_value[4]'>Delete</a></font></td>";
     print "\t</tr>\n";
     $varcount = 0;
    }
    print "</table>\n";

    mysql_close($dbconn);                  //closing connection to database
    }
    include "footer.php";
}




?>
