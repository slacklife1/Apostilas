<?php
/*****************************************************************************
Power Banner Manager beta 2 !
(config.php file)

This is the main file, it is included in every php file of Power Banner
Manager. It is important to change data before running install.php, and if
you change your MySQL Database, you will need to install Power Banner Manager
again.
Here is four variables that needs to be changed:

$hostname <- input hostname of your MySQL database
$database <- name of your database

$db_login <- login name for your MySQL database
$dd_pass <- password of your login name

After you change these variables, run install.php and
setup Power Banner Manager !

Copyright Armin Kalajdzija, 2002.
E-mail: kalajdzija@hotmail.com
WebSite: http://www.ak85.tk
*****************************************************************************/

$hostname = "your.host.com";      // example $hostname = "db.host.sk";
$database = "database";      // example $database = "armin";
$db_login = "db_login";         // $db_login = "armin";
$db_pass = "db_pass";       // $db_pass = "temp123";

?>
