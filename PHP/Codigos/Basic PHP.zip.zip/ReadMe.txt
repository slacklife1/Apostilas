Project Name: Basic PHP Pages
Description:
I have written some basic PHP pages to show and help people better
Understand PHP. Use index.html as the main menu to run all the PHP Pages.
*Note (You must have a PHP enabled webserver to test these scripts.


All the code here is in zipped and unzipped format...
The zip file contains all of the files in the directory
to enable you to download the whole project...The other
files enable you to look at each individual file seperately...

This program was Written by CMI and Updated by George
Interactive PsyberTechnology Developers Group
Developing Products to fit all your computer needs...
ALL Developed Products Are Y2K Compliant...
Giving you the tools to build future business today...
For more information please visit our website for details...
www.ipdg3.com - info@ipdg3.com - Voice: 630.236.5584
Aurora, IL. USA

Source Code page www.ipdg3.com/sourcecode.html
Online Chat www.ipdg3.com/chatroom.html
Forums http://pub52.ezboard.com/binteractivepsybertechnologydevelopersgroup

See gwvb01.txt for more info on the Original Author...

Disclaimer:

This example program is provided "as is" with no warranty of any kind. It is
intended for demonstration purposes only. In particular, it does not error
handling. You can use the example in any form, but please mention
www.ipdg3.com