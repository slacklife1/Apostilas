<HTML>
<HEAD>
   <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
   <META NAME="Author" CONTENT="Interactive PsyberTechnology Developers Group">
   <META NAME="GENERATOR" CONTENT="Mozilla/4.04 [en] (Win95; I) [Netscape]">
   <META NAME="Description" CONTENT="Programming knowledgebase with source code, tips, tricks, how to, and faq as well as consulting available.">
   <META NAME="KeyWords" CONTENT="network, networks, novel, windows, nt, networking, interactive, cgi, html, design, web site, search engines, forum, animation, sound, java, message, form, crystal reports, virtual, visual basic, vb, digital, chat, scripting, perl, business, password, protection, office, graphics, source code, code, tricks, tips, how, samples, help, faq, IPDG3">
   <TITLE>Calculation</TITLE>
</HEAD>

<BODY BGCOLOR="000000" TOPMARGIN="0" LEFTMARGIN="0" MARGINWIDTH="0" MARGINHEIGHT="0" TEXT="#000000" LINK="#0914A8" ALINK="#0914A8" VLINK="#0914A8">


<!- - - END BODY TAG AREA - - - - - - - - - - - - - - - - - - - - - >

<CENTER>

<!- - - MENU TABLE - - - - - - - - - - - - - - - - - - - - - - - >

<TABLE BORDER="1" CELLSPACING="0" CELLPADDING="0" WIDTH="760" TABLE BGCOLOR="#99CCFF">
<TD WIDTH="760" HEIGHT="120" VALIGN="CENTER" ALIGN="CENTER">
<FONT FACE="Verdana, Arial, Helvetica" SIZE="2" COLOR="#000000">

<A HREF="index.html">
<IMG SRC="graphics/titles/title2.gif" Width="750" Height="120" BORDER="0" HSPACE="3" VSPACE="0">
</A>

</FONT></TD>

<!- - - MENU TABLE - - - - - - - - - - - - - - - - - - - - - - - >

</TR></TABLE>

<!- - - END MENU TABLE - - - - - - - - - - - - - - - - - - - - - >


<!- - - MAIN PAGE TABLE - - - - - - - - - - - - - - - - - - - - - - >

<TABLE BORDER="0" CELLSPACING="0" CELLPADDING="0" WIDTH="760" HEIGHT=100%>
<TR>

<!- - - LEFT COLUMN CONTENT - - - - - - - - - - - - - - - - - - - - >

<TD WIDTH="10" ALIGN="Left" VALIGN="TOP" TABLE BGCOLOR="#FFFFFF">

<FONT FACE="Verdana, Arial, Helvetica" SIZE="2" COLOR="#000000">

<BR>
<BR>

</FONT></TD>

<!- - - END LEFT COLUMN CONTENT - - - - - - - - - - - - - - - - - - >


<!- - - CONTENT #1a COLUMN TABLE  - - - - - - - - - - - - - - - - - >

<TD WIDTH="600" ALIGN="CENTER" VALIGN="TOP" TABLE BGCOLOR="#FFFFFF">

<FONT FACE="Verdana, Arial, Helvetica" SIZE="2" COLOR="#000000">

<BR>
<BR>

<H4>Calculation</A>

<?PHP
print ("<CENTER>\n<BR>\n");

/* $Quantity must be passed to this page from a form or via the url. $Discount is optional. */

$Cost = 20.00;
$Tax = 0.06;
If ($Quantity) {
  $Quantity = abs($Quantity);
  $Discount = abs($Discount);
  $Tax++; //$Tax is now worth 1.06
  $TotalCost = ($Cost * $Quantity);

  if(($TotalCost < 50) AND ($Discount)) {
		  print ("Your \$$Discount will not apply becuase the total value of the sale is under $50!\n<P>");
  } 

  if ($TotalCost >= 50) {
    $TotalCost = $TotalCost - $Discount;
  }

  $TotalCost =$TotalCost * $Tax;
  
  $Payments = round($TotalCost, 2) / 12;

  // Print Payment
  print ("You requested to purchase $Quantity widget(s) at \$$Cost each.\n");	 

  print ("<BR><BR>\nThe total with tax, minus your discount of \$$Discount, comes to $");
  printf ("%01.2f", $TotalCost);

	 print (".<BR><BR>\nYou may purchase the widget(s) in 12 monthy installments of $");
	 printf ("%01.2f", $Payments);
  print (" each.\n");

} Else {
	 print ("Please use <B>Back</B> button the make sure that you have entered in both a quantity and an applicable discount and then resubmit.\n");  

}

print ("</CENTER>\n");
?>

<BR>
<BR>

</FONT></TD>

<!- - - END CONTENT #1a COLUMN TABLE  - - - - - - - - - - - - - - - >


<!- - - CONTENT #1 RIGHT COLUMN TABLE - - - - - - - - - - - - - - - >

<TD WIDTH="150" ALIGN="CENTER" VALIGN="TOP" TABLE BGCOLOR="#FEFDC7">

<FONT FACE="Verdana, Arial, Helvetica" SIZE="2" COLOR="#000000">

<BR>
<BR>

<H4><FONT COLOR="#000080">Related sites:</FONT></H4>

<SCRIPT language="javascript">

<!--
function picR1() 
  {
  holderWindow=window.open("http://www.php.net", "picR1",  
    "resizable=yes,toolbar=1,location=1,directories=0,status=0,menubar=0,scrollbars=1,copyhistory=0,width=800,height=600"); 
  holderWindow.location="http://www.php.net";
  } 
// -->


</SCRIPT>

<A HREF="javascript:picR1()"><FONT SIZE="2" COLOR="#0000FF">PHP Homepage</FONT></A>

<BR>
<BR>

<SCRIPT language="javascript">

<!--
function picR2() 
  {
  holderWindow=window.open("http://www.apache.org/", "picR2",  
    "resizable=yes,toolbar=1,location=1,directories=0,status=0,menubar=0,scrollbars=1,copyhistory=0,width=800,height=600"); 
  holderWindow.location="http://www.apache.org/";
  } 
// -->


</SCRIPT>

<A HREF="javascript:picR2()"><FONT SIZE="2" COLOR="#0000FF">Apache Software Foundation</FONT></A>

<BR>
<BR>

<SCRIPT language="javascript">

<!--
function picR3() 
  {
  holderWindow=window.open("http://www.mysql.com/", "picR3",  
    "resizable=yes,toolbar=1,location=1,directories=0,status=0,menubar=0,scrollbars=1,copyhistory=0,width=800,height=600"); 
  holderWindow.location="http://www.mysql.com/";
  } 
// -->


</SCRIPT>

<A HREF="javascript:picR3()"><FONT SIZE="2" COLOR="#0000FF">mySQL</FONT></A>

<BR>
<BR>

<SCRIPT language="javascript">

<!--
function picR4() 
  {
  holderWindow=window.open("http://www.postgresql.org/", "picR4",  
    "resizable=yes,toolbar=1,location=1,directories=0,status=0,menubar=0,scrollbars=1,copyhistory=0,width=800,height=600"); 
  holderWindow.location="http://www.postgresql.org/";
  } 
// -->


</SCRIPT>

<A HREF="javascript:picR4()"><FONT SIZE="2" COLOR="#0000FF">PostgreSQL</FONT></A>

<BR>
<BR>

<SCRIPT language="javascript">

<!--
function picR5() 
  {
  holderWindow=window.open("http://www.zend.com/", "picR5",  
    "resizable=yes,toolbar=1,location=1,directories=0,status=0,menubar=0,scrollbars=1,copyhistory=0,width=800,height=600"); 
  holderWindow.location="http://www.zend.com/";
  } 
// -->


</SCRIPT>

<A HREF="javascript:picR5()"><FONT SIZE="2" COLOR="#0000FF">Zend Technologies</FONT></A>

<BR>
<BR>

</FONT></TD>

<!- - - END CONTENT #1 RIGHT COLUMN TABLE - - - - - - - - - - - - - >


<!- - - END MAIN PAGE TABLE - - - - - - - - - - - - - - - - - - - - >

</TR></TABLE>

<!- - - END MAIN PAGE TABLE - - - - - - - - - - - - - - - - - - - - >


<!- - - BOTTOM TABLE  - - - - - - - - - - - - - - - - - - - - - - - >

<TABLE BORDER="1" CELLSPACING="0" CELLPADDING="0" WIDTH="760">


<TD WIDTH="760" HEIGHT="50" VALIGN="CENTER" ALIGN="CENTER" TABLE BGCOLOR="#99CCFF">
<FONT FACE="Verdana, Arial, Helvetica" SIZE="2" COLOR="#000000">

<BR>

<P>
<FONT SIZE=-1>&copy; 1997 Interactive PsyberTechnology</FONT>
</P>

<BR>

</FONT></TD>

<!- - - BOTTOM TABLE  - - - - - - - - - - - - - - - - - - - - - - - >

</TR></TABLE>

<!- - - END BOTTOM TABLE  - - - - - - - - - - - - - - - - - - - - - >

</CENTER>
</BODY>
</HTML>