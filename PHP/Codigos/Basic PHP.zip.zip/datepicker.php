<HTML>
<HEAD>
   <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
   <META NAME="Author" CONTENT="Interactive PsyberTechnology Developers Group">
   <META NAME="GENERATOR" CONTENT="Mozilla/4.04 [en] (Win95; I) [Netscape]">
   <META NAME="Description" CONTENT="Programming knowledgebase with source code, tips, tricks, how to, and faq as well as consulting available.">
   <META NAME="KeyWords" CONTENT="network, networks, novel, windows, nt, networking, interactive, cgi, html, design, web site, search engines, forum, animation, sound, java, message, form, crystal reports, virtual, visual basic, vb, digital, chat, scripting, perl, business, password, protection, office, graphics, source code, code, tricks, tips, how, samples, help, faq, IPDG3">
   <TITLE>Feedback Form</TITLE>
</HEAD>

<BODY BGCOLOR="000000" TOPMARGIN="0" LEFTMARGIN="0" MARGINWIDTH="0" MARGINHEIGHT="0" TEXT="#000000" LINK="#0914A8" ALINK="#0914A8" VLINK="#0914A8">


<!- - - END BODY TAG AREA - - - - - - - - - - - - - - - - - - - - - >

<CENTER>

<!- - - MENU TABLE - - - - - - - - - - - - - - - - - - - - - - - >

<TABLE BORDER="1" CELLSPACING="0" CELLPADDING="0" WIDTH="760" TABLE BGCOLOR="#99CCFF">
<TD WIDTH="760" HEIGHT="120" VALIGN="CENTER" ALIGN="CENTER">
<FONT FACE="Verdana, Arial, Helvetica" SIZE="2" COLOR="#000000">

<A HREF="index.html">
<IMG SRC="graphics/titles/title2.gif" Width="750" Height="120" BORDER="0" HSPACE="3" VSPACE="0">
</A>

</FONT></TD>

<!- - - MENU TABLE - - - - - - - - - - - - - - - - - - - - - - - >

</TR></TABLE>

<!- - - END MENU TABLE - - - - - - - - - - - - - - - - - - - - - >


<!- - - MAIN PAGE TABLE - - - - - - - - - - - - - - - - - - - - - - >

<TABLE BORDER="0" CELLSPACING="0" CELLPADDING="0" WIDTH="760" HEIGHT=100%>
<TR>

<!- - - LEFT COLUMN CONTENT - - - - - - - - - - - - - - - - - - - - >

<TD WIDTH="10" ALIGN="Left" VALIGN="TOP" TABLE BGCOLOR="#FFFFFF">

<FONT FACE="Verdana, Arial, Helvetica" SIZE="2" COLOR="#000000">

<BR>
<BR>

</FONT></TD>

<!- - - END LEFT COLUMN CONTENT - - - - - - - - - - - - - - - - - - >


<!- - - CONTENT #1a COLUMN TABLE  - - - - - - - - - - - - - - - - - >

<TD WIDTH="600" ALIGN="CENTER" VALIGN="TOP" TABLE BGCOLOR="#FFFFFF">

<FONT FACE="Verdana, Arial, Helvetica" SIZE="2" COLOR="#000000">

<BR>
<BR>

<H4>Date Picker</H4>

<?PHP
print ("<CENTER>\n<BR>\n");

$Year = date("Y");

//Create the form
print ("<FORM ACTION=\"$PHP_SELF\" METHOD=POST>");

//Create the month pull-down menu
print ("Select a month:<BR>\n");

print ("<SELECT NAME=Month><OPTION>Choose One</OPTION>\n");
print ("<OPTION VALUE=January>January</OPTION>\n");
print ("<OPTION VALUE=February>February</OPTION>\n");
print ("<OPTION VALUE=March>March</OPTION>\n");
print ("<OPTION VALUE=April>April</OPTION>\n");
print ("<OPTION VALUE=May>May</OPTION>\n");
print ("<OPTION VALUE=June>June</OPTION>\n");
print ("<OPTION VALUE=July>July</OPTION>\n");
print ("<OPTION VALUE=August>August</OPTION>\n");
print ("<OPTION VALUE=September>September</OPTION>\n");
print ("<OPTION VALUE=October>October</OPTION>\n");
print ("<OPTION VALUE=November>November</OPTION>\n");
print ("<OPTION VALUE=December>December</OPTION>\n");
print ("</SELECT>\n");

//Create the day pull-down menu.
print ("<P>Select a day:<BR>\n");

print ("<SELECT NAME=Day><OPTION>Choose One</OPTION>\n");

$Day = 1;

while ($Day <= 31) {
  print ("<OPTION VALUE=$Day>$Day</OPTION>\n");
		$Day++;
}

print ("</SELECT>\n");

//Create the year pull-down menu.
print ("<P>Select a year:<BR>\n");

print ("<SELECT NAME=Year><OPTION>Choose One</OPTION>\n");

$EndYear = $Year + 10;

while ($Year <= $EndYear) {
  print ("<OPTION VALUE=$Year>$Year</OPTION>\n");
  $Year++;
}

print ("</SELECT>\n");

print ("<BR><BR><BR>");
print ("<INPUT TYPE=\"SUBMIT\" NAME=\"Submit\" VALUE=\"Submit\">");
print ("<INPUT TYPE=\"RESET\" VALUE=\"Start Over\">");



print ("</CENTER>\n");
?>

<BR>
<BR>

</FONT></TD>

<!- - - END CONTENT #1a COLUMN TABLE  - - - - - - - - - - - - - - - >


<!- - - CONTENT #1 RIGHT COLUMN TABLE - - - - - - - - - - - - - - - >

<TD WIDTH="150" ALIGN="CENTER" VALIGN="TOP" TABLE BGCOLOR="#FEFDC7">

<FONT FACE="Verdana, Arial, Helvetica" SIZE="2" COLOR="#000000">

<BR>
<BR>

<H4><FONT COLOR="#000080">Related sites:</FONT></H4>

<SCRIPT language="javascript">

<!--
function picR1() 
  {
  holderWindow=window.open("http://www.php.net", "picR1",  
    "resizable=yes,toolbar=1,location=1,directories=0,status=0,menubar=0,scrollbars=1,copyhistory=0,width=800,height=600"); 
  holderWindow.location="http://www.php.net";
  } 
// -->


</SCRIPT>

<A HREF="javascript:picR1()"><FONT SIZE="2" COLOR="#0000FF">PHP Homepage</FONT></A>

<BR>
<BR>

<SCRIPT language="javascript">

<!--
function picR2() 
  {
  holderWindow=window.open("http://www.apache.org/", "picR2",  
    "resizable=yes,toolbar=1,location=1,directories=0,status=0,menubar=0,scrollbars=1,copyhistory=0,width=800,height=600"); 
  holderWindow.location="http://www.apache.org/";
  } 
// -->


</SCRIPT>

<A HREF="javascript:picR2()"><FONT SIZE="2" COLOR="#0000FF">Apache Software Foundation</FONT></A>

<BR>
<BR>

<SCRIPT language="javascript">

<!--
function picR3() 
  {
  holderWindow=window.open("http://www.mysql.com/", "picR3",  
    "resizable=yes,toolbar=1,location=1,directories=0,status=0,menubar=0,scrollbars=1,copyhistory=0,width=800,height=600"); 
  holderWindow.location="http://www.mysql.com/";
  } 
// -->


</SCRIPT>

<A HREF="javascript:picR3()"><FONT SIZE="2" COLOR="#0000FF">mySQL</FONT></A>

<BR>
<BR>

<SCRIPT language="javascript">

<!--
function picR4() 
  {
  holderWindow=window.open("http://www.postgresql.org/", "picR4",  
    "resizable=yes,toolbar=1,location=1,directories=0,status=0,menubar=0,scrollbars=1,copyhistory=0,width=800,height=600"); 
  holderWindow.location="http://www.postgresql.org/";
  } 
// -->


</SCRIPT>

<A HREF="javascript:picR4()"><FONT SIZE="2" COLOR="#0000FF">PostgreSQL</FONT></A>

<BR>
<BR>

<SCRIPT language="javascript">

<!--
function picR5() 
  {
  holderWindow=window.open("http://www.zend.com/", "picR5",  
    "resizable=yes,toolbar=1,location=1,directories=0,status=0,menubar=0,scrollbars=1,copyhistory=0,width=800,height=600"); 
  holderWindow.location="http://www.zend.com/";
  } 
// -->


</SCRIPT>

<A HREF="javascript:picR5()"><FONT SIZE="2" COLOR="#0000FF">Zend Technologies</FONT></A>

<BR>
<BR>

</FONT></TD>

<!- - - END CONTENT #1 RIGHT COLUMN TABLE - - - - - - - - - - - - - >


<!- - - END MAIN PAGE TABLE - - - - - - - - - - - - - - - - - - - - >

</TR></TABLE>

<!- - - END MAIN PAGE TABLE - - - - - - - - - - - - - - - - - - - - >


<!- - - BOTTOM TABLE  - - - - - - - - - - - - - - - - - - - - - - - >

<TABLE BORDER="1" CELLSPACING="0" CELLPADDING="0" WIDTH="760">


<TD WIDTH="760" HEIGHT="50" VALIGN="CENTER" ALIGN="CENTER" TABLE BGCOLOR="#99CCFF">
<FONT FACE="Verdana, Arial, Helvetica" SIZE="2" COLOR="#000000">

<BR>

<P>
<FONT SIZE=-1>&copy; 1997 Interactive PsyberTechnology</FONT>
</P>

<BR>

</FONT></TD>

<!- - - BOTTOM TABLE  - - - - - - - - - - - - - - - - - - - - - - - >

</TR></TABLE>

<!- - - END BOTTOM TABLE  - - - - - - - - - - - - - - - - - - - - - >

</CENTER>
</BODY>
</HTML>