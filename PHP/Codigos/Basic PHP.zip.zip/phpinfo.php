<HTML>
<HEAD>
   <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
   <META NAME="Author" CONTENT="Interactive PsyberTechnology Developers Group">
   <META NAME="GENERATOR" CONTENT="Mozilla/4.04 [en] (Win95; I) [Netscape]">
   <META NAME="Description" CONTENT="Programming knowledgebase with source code, tips, tricks, how to, and faq as well as consulting available.">
   <META NAME="KeyWords" CONTENT="network, networks, novel, windows, nt, networking, interactive, cgi, html, design, web site, search engines, forum, animation, sound, java, message, form, crystal reports, virtual, visual basic, vb, digital, chat, scripting, perl, business, password, protection, office, graphics, source code, code, tricks, tips, how, samples, help, faq, IPDG3">
   <TITLE>PHP Info</TITLE>
</HEAD>

<BODY BGCOLOR="000000" TOPMARGIN="0" LEFTMARGIN="0" MARGINWIDTH="0" MARGINHEIGHT="0" TEXT="#000000" LINK="#0914A8" ALINK="#0914A8" VLINK="#0914A8">


<!- - - END BODY TAG AREA - - - - - - - - - - - - - - - - - - - - - >

<CENTER>

<!- - - MENU TABLE - - - - - - - - - - - - - - - - - - - - - - - >

<TABLE BORDER="1" CELLSPACING="0" CELLPADDING="0" WIDTH="760" TABLE BGCOLOR="#99CCFF">
<TD WIDTH="760" HEIGHT="120" VALIGN="CENTER" ALIGN="CENTER">
<FONT FACE="Verdana, Arial, Helvetica" SIZE="2" COLOR="#000000">

<A HREF="index.html">
<IMG SRC="graphics/titles/title2.gif" Width="750" Height="120" BORDER="0" HSPACE="3" VSPACE="0">
</A>

[ <A HREF="http://www.ipdg3.com/index.html">Home</A> |
<A HREF="http://www.ipdg3.com/about.html">About IPDG</A> |
<A HREF="http://www.ipdg3.com/ourwork.html"> Our Work</A> |
<A HREF="http://www.ipdg3.com/inquiry.html"> Inquiry</A> |
<A HREF="http://www.ipdg3.com/contactus.html"> Contact Us</A> |
<A HREF="http://www.ipdg3.com/search.html"> Search</A> |
<A HREF="http://www.ipdg3.com/chatroom.html"> Live Chat</A> |
<A HREF="http://pub52.ezboard.com/binteractivepsybertechnologydevelopersgroup">IPDG3 Forums</A> ]

<BR>

[<A HREF="http://www.ipdg3.com/demo.html"> Product Demo</A> |
<A HREF="http://www.ipdg3.com/members.html"> Members Area</A> |
<A HREF="http://www.ipdg3.com/games.html"> On-Line Games</A> |
<A HREF="http://www.ipdg3.com/links.html"> Links</A> |
<A HREF="http://www.ipdg3.com/sourcecode.html"> Source Code</A> ]

</FONT></TD>

<!- - - MENU TABLE - - - - - - - - - - - - - - - - - - - - - - - >

</TR></TABLE>

<!- - - END MENU TABLE - - - - - - - - - - - - - - - - - - - - - >


<!- - - MAIN PAGE TABLE - - - - - - - - - - - - - - - - - - - - - - >

<TABLE BORDER="0" CELLSPACING="0" CELLPADDING="0" WIDTH="760" HEIGHT=100%>
<TR>

<!- - - LEFT COLUMN CONTENT - - - - - - - - - - - - - - - - - - - - >

<TD WIDTH="10" ALIGN="Left" VALIGN="TOP" TABLE BGCOLOR="#FFFFFF">

<FONT FACE="Verdana, Arial, Helvetica" SIZE="2" COLOR="#000000">

<BR>
<BR>

</FONT></TD>

<!- - - END LEFT COLUMN CONTENT - - - - - - - - - - - - - - - - - - >


<!- - - CONTENT #1a COLUMN TABLE  - - - - - - - - - - - - - - - - - >

<TD WIDTH="750" ALIGN="Left" VALIGN="TOP" TABLE BGCOLOR="#FFFFFF">

<FONT FACE="Verdana, Arial, Helvetica" SIZE="2" COLOR="#000000">

<BR>
<BR>

<? phpinfo(); ?>

<BR>
<BR>

</FONT></TD>

<!- - - END CONTENT #1a COLUMN TABLE  - - - - - - - - - - - - - - - >


<!- - - END MAIN PAGE TABLE - - - - - - - - - - - - - - - - - - - - >

</TR></TABLE>

<!- - - END MAIN PAGE TABLE - - - - - - - - - - - - - - - - - - - - >


<!- - - BOTTOM TABLE  - - - - - - - - - - - - - - - - - - - - - - - >

<TABLE BORDER="1" CELLSPACING="0" CELLPADDING="0" WIDTH="760">


<TD WIDTH="760" HEIGHT="50" VALIGN="CENTER" ALIGN="CENTER" TABLE BGCOLOR="#99CCFF">
<FONT FACE="Verdana, Arial, Helvetica" SIZE="2" COLOR="#000000">

<BR>

<P>
<FONT SIZE=-1>&copy; 1997 Interactive PsyberTechnology</FONT>
</P>

<BR>

</FONT></TD>

<!- - - BOTTOM TABLE  - - - - - - - - - - - - - - - - - - - - - - - >

</TR></TABLE>

<!- - - END BOTTOM TABLE  - - - - - - - - - - - - - - - - - - - - - >

</CENTER>
</BODY>
</HTML>