<?php

 $NumHits = "hits.txt";
    if (file_exists($NumHits))
    {
    $fp = fopen($NumHits,"r+");
    $count = fgets($fp,5);
    $count += 1;
    rewind($fp);
    fputs($fp,$count,5);
    fclose($fp);
    
    }
    else
    {
    $fp = fopen($NumHits,"w");
    $count = "1";
    fputs($fp,$count,5);
    fclose($fp);
   
    }
$date = date("H:i:s d M, Y");
$open = fopen("hitinfo.php","a+");

fputs($open,"<b>Screen Name</b> $sn<br>
<b>Browser:</b> $HTTP_USER_AGENT<br>
<b>IP Address:</b> $REMOTE_ADDR<br>
<b>Date and Time: $date</b><br><br>");

?>