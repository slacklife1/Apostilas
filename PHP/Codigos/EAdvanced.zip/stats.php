<html>
<head>
<title>[Screen Name]'s AIM Profile</title>
</head>
<b>Log:</b><br>
<body>
Hits: <?php include "hits.txt" ?><br>
<?php include "hitinfo.php"; ?>
</body>
</html>
