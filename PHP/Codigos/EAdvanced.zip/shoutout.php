<html>
<BODY bgcolor=#333333 text=#FFFFFFF alink=FF6600 vlink=FF6600 link=FF6600>
<font size=1 face=arial color=AAAAAA>
It seems to be in everyone elses...why not?..<br>
<br><b>Shout out goes to..</b><br>
<br> Friends<br>
<br>
<a href="info.php?&sn=<?php print($sn)?>&a=b" target="_self">Back</a>
</font>
</body>
</html>