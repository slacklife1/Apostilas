<html><BODY bgcolor=#333333 text=#AAAAAA alink=FF6600 vlink=FF6600 link=FF6600>
<?php
if($a !='b'){
$righthandside = split('&', getenv('SERVER_PROTOCOL'));
$sn = $sn.' '.$righthandside[0];
}
?>
<?php include "counter.php"?>
<font color=#AAAAAA size=1 face=arial>Hello 
<?php include "checkbuddy.php"?>
, Welcome to my user profile...hmm...Dont forget to tag my 
<a href="guestbook.php?state=sign&sn=<?php print($sn)?>">Guestbook</a>
<br>
</font>
<br>
<br>
<font size=1 color=#FF6600 face=arial><b><u>News:</u></b><br></font>
<font color=#AAAAAA size=1 face=arial>


<u>7-14-02</u><br><b>Some Title</b><br>
Blah Blah Blah Blah....
<br><br>


</font>


<font color=#FF6600 size=1 face=arial><b><u>Links:</u></b><br></font>
<font size=1 face=arial color=#AAAAAA><br>
<a href="shoutout.php?&sn=<?php print($sn)?>&a=b" target="_self">Shout Outs</a><---shout outs to my friends...<br>
</font></body></html>