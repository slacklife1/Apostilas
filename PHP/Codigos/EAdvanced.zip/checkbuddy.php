<?php 
$sn2=$sn;

function FormatSn ($str)
{
$str=trim($str);
$str=strtolower($str);
$str=str_replace ( " ", "", $str );
return $str;
}

$sn=FormatSn ($sn);

  switch ($sn) {
     case "screenname1":
        $sn="NameToReplace1";
        echo "<u>$sn</u>";
	break;
     case "screenname2":
        $sn="NameToReplace2";
        echo "<u>$sn</u>";
	break;

     default:
        $sn=$sn2;
	echo "$sn";
        break;
               }
?>