<html>
<head>
<title>[Screen Name]'s Guestbook</title>
</head>
<body bgcolor="#333333" text="#AAAAAA" alink=FF6600 vlink=FF6600 link=FF6600>
<?php
  $Top = "<p><font face=\"Verdana, Arial, Helvetica, sans-serif\" 
         size=\"1\" color=\"#AAAAAA\">Tag<br>
         <font size=\"1\">[<a href=\"guestbook.php?state=sign&sn=$sn\">Tag</a>][<a href=\"guestbook.php?state=view&sn=$sn\">View</a>]</font> 
	 </font></p>";
    	
    	if( $state == "" )
    	{
    		echo"$Top";
    	}
    	if( $state == "view" )
    	{
    		echo"$Top";
    		include("guestbook.txt");
    	}
    	if( $state == "show")
    	{
    		$fp_1 = fopen("guestbook.txt", 'r');
    		
    		$old_comments = fread ($fp_1, filesize("guestbook.txt"));
    		
    		fclose( $fp_1 );
    		
    		$fp = fopen("guestbook.txt", 'w');
    		fwrite( $fp, "<font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\"><b>Name:</b> $name<br><b>Tag:</b> $message<p></font> $old_comments" );
    		echo"<font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"2\">The Following Information has been added...</font><br>";
    		echo"<font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">Name: <i>$name</i></font><br>";
    		echo"<font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\">Message: <i>$message</i></font>";
    		
    		fclose( $fp );
    	
    		echo"<p><a href=\"guestbook.php?state=view&sn=$sn\">Continue</a>";
    	}
    	if( $state == "sign" )
    	{
    		echo"$Top";
    	echo"<form name=\"form1\" method=\"post\" action=\"guestbook.php?state=show&sn=$sn\">
<font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\" color=\"#AAAAAA\">Name: $sn</font>
<input type=\"hidden\" name=\"name\" value=\"$sn\"><br>
<font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"1\" color=\"#AAAAAA\">Message:</font><br>
<TEXTAREA NAME=\"message\" ROWS=6 COLS=25></TEXTAREA><br>    
<p> 
<input type=\"submit\" name=\"ok\" value=\"Tag\">
<input type=\"reset\" name=\"Reset\" value=\"Reset\">
</p>
</form>";
}
?>
</body>
</html>

