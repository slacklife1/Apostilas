<?php include("templateclass.php"); ?>
<?php
 $template = new template();
 $template->usetemplate("message.tpl");
 $template->tag("message","\"This is from a string.\"");
 $template->tag("self",$template->gettemplate("message.tpl",true));
 $template->tag("phpcode",$template->gettemplate("index.php",false));
 $template->tag("howtouse",$template->gettemplate("howtouse.tpl",false));
 $template->tag("templateclass.php",$template->gettemplate("templateclass.php",true));
 $template->display();
?>