Title: A better BFCTemplate (PHP version) version 1
Description: Here's a little gift for you PHP scripters. This is my template class that was originally created in ASP. It allows you to separate the HTML from your PHP code. The tags allow you to use any parameter that can be used with the "&nbsp;div>" tag. Check it out. You'll like it. I'm working on another version that'll allow you to specify the tag to emulate and allow blocks of HTML to be repeated.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=329&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
