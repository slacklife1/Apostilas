<?
if (!$logged) {
  die ("This is for sending devotionals, and is for use only through the web interface.\nVariable \$logged not set");
} else {
  if ((!$uname == "refadmin") || (!$pword == "4gzus")) {
    die ("This is for sending devotionals, and is for use only through the web interface.\nIncorrect username and/or password");
  }
}
?>
<html>
<head>
<title>Sending Devotional Mails</title>
<link rel="stylesheet" type="text/css" href="../global.css">
</head>
<body>
<?
$msg = wordwrap($msg);
$msg = notHTML($msg);

$fp = fopen("members.txt", "r")
  or die ("Could not open members.txt for reading");
?>
<h1 align="center">Sending Status</h1>
<?
while (!feof($fp)) {
  $parts = explode("|", trim(fgets($fp, 1024)));
  $tmp_msg = "Dear $parts[0],\n";
  $headers = "From: \"Andrew\"<amk4gzus@hotmail.com>\n";
  $headers .= "Date: " .date("L, F d, Y"). "\n";
  $headers .= "Reply-To: devotions@youthrefuge.f2s.com\n";
  $headers .= "Return-Path: <joshh@f2ssdt.f2s.com>\n";
  $mGoodSend = mail("\"$parts[0]\" <$parts[1]>", "The Refuge Youth Group Weekly Devotional", $tmp_msg, $headers);
  if ($mGoodSend) {
?>
Devotional was <b>sent</b> to <?=$parts[0]?>, <?=$parts[1]?><br>
<?
  } else {
?>
Devotional was <b>not sent</b> to <?=$parts[0]?>, <?=$parts[1]?><br>
<?
  }
}

function notHTML($myString) {
  return strip_tags($myString);
}
?>