<?
if (!isset($reging)) {
?>
<html>
<head>
<title>The Youth Refuge Online Devotional Manager - Register</title>
<link rel="stylesheet" type="text/css" href="../global.css">
</head>
<body>
<div align="center"><center>
<h1>The Youth Refuge</h1>
<h2>Register Your Email</h2>
<br><br>
<p>Please enter the following information. Although HTML mail is not yet implemented, it soon should be.
This devotional is published weekly, so you may not receive one for a few days.<br>
After you register, you will receive a confirmation letter. If you do not receive this, please e-mail
<a href="mailto:joshh@f2ssdt.f2s.com">joshh@f2ssdt.f2s.com</a>.</p>
<form action="register.php" method="post">
<input type="hidden" name="reging" value="true">
<table width=0 height=0 border=0 cellpadding=0 cellspacing=0>
<tr>
  <td align="right">
Name:
  </td>
  <td align="left">
<input type="text" name="name">
  </td>
</tr>
<tr>
  <td align="right">
E-Mail:
  </td>
  <td align="left">
<input type="text" name="email">
  </td>
</tr>
<tr>
  <td align="right">
Can You Receive HTML?
  </td>
  <td align="left">
Yes<input type="radio" name="html" value="y" checked>&nbsp;&nbsp;No<input type="radio" name="html" value="n">
  </td>
</tr>
<tr>
  <td align="center">
<input type="submit" value="Register">
  </td>
  <td align="center">
<input type="reset" value="Clear Form">
  </td>
</tr>
</table>
</form>
</center></div>
</body>
</html>
<?
exit;
} else {
$fp = fopen("members.txt", "a")
  or die("Could not open members.txt for appending");

$name = trim($name);
$email = trim($email);
$html = trim($html);

$mStr = $name."|".$email."|".$html."\n";

fputs($fp, $mStr);
fclose($fp);

$msg = "This is a confirmation message for The Refuge Youth Group Email Devotional.\n".
$msg .= "If you did not sign up for this, please reply to this message with unsubscribe as the subject.\n";
$headers = "From: devotionals@youthrefuge.f2s.com\n";
$headers .= "Date: ";
$headers .= date("L, F d, Y");
$header .= "\n";
$headers .= "Reply-To: joshh@f2ssdt.f2s.com\n";
$headers .= "Return-Path: joshh@f2ssdt.f2s.com\n";
$subject = "Devotional Confirmation";

mail ("\"$name\" <$email>", $subject, $msg, $headers);
echo ("Confirmation message sent. Please check your email in 5 minutes.");
}
?>