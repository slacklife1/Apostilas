<?
if ($action == "logout") {
  header ("Location: http://www.youthrefuge.f2s.com/devotional/index.php");
  echo ("You have been logged out of the system. Transferring you home.");
  exit;
}
?>
<html>
<head>
<title>The Refuge Youth Group - Online Devotional Manager</title>
<link rel="stylesheet" type="text/css" href="../global.css">
</head>
<body>
<table width="100%" height="100%" border=0 cellpadding=0 cellspacing=0>
  <tr>
    <td width="20%">
<font size="2">
<ul>
<?
if (!isset($uname)) {
?>
  <li>
<form action="index.php" method="POST">
<input type="hidden" name="uname" value="<?=$uname?>">
<input type="hidden" name="pword" value="<?=$pword?>">
<input type="hidden" name="action" value="login">
<input type="hidden" name="logged" value="false">
<input type="submit" value="   Log In   ">
</form>
  </li>
<?
}
if ($logged == "true") {
if (($uname == "refadmin") && ($pword == "4gzus")) {
?>
  <li>
<form action="index.php" method="POST">
<input type="hidden" name="action" value="logout">
<input type="submit" value="   Log Out  ">
</form>
  </li>
  <li>
<form action="index.php" method="POST">
<input type="hidden" name="uname" value="<?=$uname?>">
<input type="hidden" name="pword" value="<?=$pword?>">
<input type="hidden" name="action" value="sendmail">
<input type="hidden" name="logged" value="true">
<input type="submit" value="Send Message">
</form>
  </li>
<?
}
}
?>
  <li>
<form action="register.php" method="POST">
<input type="submit" value="  Register  ">
</form>
  </li>
</ul>
</font>
    </td>
    <td>
<h1 align="center">The Refuge Youth Group</h1>
<h2 align="center">Online Devotional Manager</h2>
<? if ($action == "login") { ?>
<p align="center">Please enter your user information below</p>
<form action="index.php" method="POST">
<input type="hidden" name="action" value="logging">
<input type="hidden" name="logged" value="true">
<center>
<table width=0 height=0 border=1 cellpadding=1 cellspacing=0>
<tr>
  <td align="right">User Name:</td>
  <td align="left"><input type="text" name="uname"></td>
</tr>
<tr>
  <td align="right">Password:</td>
  <td align="left"><input type="password" name="pword"></td>
</tr>
<tr>
  <td align="center"></td>
  <td align="center"><input type="submit" value="   Log In   "></td>
</tr>
</table>
</center>
</form>
<? } if ($action == "logging") { ?>
<p align="center">Please use the menu to the left to manage this online devotional.
When you are done, please log out.</p>
<h4 align="center">Do not share your username or password with anyone who isn't highly trusted.</h4>
<? } if ($action == "sendmail") { ?>
<h3 align="left">Tips On Writing Your Message</h3>
<p align="left">During sending, your message in auto-wrapped at 75 columns. This means it will appear as close as
possible to what your write below.
<hr width=20 align="left">
When each message is sent, it begins with "Dear &lt;name&gt;,". Keep this is mind when composing your message.
<hr width=20 align="left">
Be sure to sign your name on the end of the letter.
</p>
<p align="center">Please enter your message below</p>
<form action="sendmail.php" method="POST">
<input type="hidden" name="logged" value="true">
<input type="hidden" name="uname" value="<?=$uname?>">
<input type="hidden" name="pword" value="<?=$pword?>">
<p align="center">Enter Your Message Here</p>
<p align="center">
<textarea rows="10" cols="75" name="msg">
</textarea><br>
<input type="submit" value="Send Message">
</p>
</form>
<? } ?>
    </td>
  </tr>
</table>