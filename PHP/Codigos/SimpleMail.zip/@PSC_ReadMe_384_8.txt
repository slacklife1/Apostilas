Title: Simple Mailing List Program
Description: Provides a simple mailing list to send mail to members. Uses a text file to store the member list. Contains four files:
 index.php (main interface)
 sendmail.php (sends the message to all members)
 register.php (adds a user to members.txt)
 members.txt (a list of members)
Before you start posting comments, here are some possible improvments:
 automated e-mail subscribe/unsubscribe
 email address vailidation
 custom salutations
 using a database
 and much more
But I just made this for me. So, it doesnt have all that. If you don't do much editing to it, all your members will receive "The Refuge Email Devotional". So, EDIT THIS CODE
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=384&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
