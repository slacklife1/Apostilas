<?php
/****************************************************************************************/
/*Copyright (C) 2001  name of Robert Ward @ UCWebDesigns.com                            */
/*Updates for this program are availible @ www.ucwebdesigns.com                         */
/*         UCWebDesigns    GuestBook Version 1.0  Release                               */
/*This program is free software; you can redistribute it and/or                         */
/*modify it under the terms of the GNU General Public License                           */
/*as published by the Free Software Foundation; either version 2                        */
/*of the License.                                                                       */
/*                                                                                      */
/*This program is distributed in the hope that it will be useful,                       */
/*but WITHOUT ANY WARRANTY; without even the implied warranty of                        */
/*MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                         */
/*GNU General Public License http://www.gnu.org for more details.                       */
/*                                                                                      */
/****************************************************************************************/
//Settings
       $html_setting = 0;   // Set to 0 to turn html option off (REMOVES TAGS)- set to 1 to turn on(LET PEOPLE ENTER TAGS)
       $email_setting = 1;  // Set to 0 to turn email option off Set to 1 to turn on
       $smile_setting = 1;  // Set to 0 to turn smiles off and set to 1 to turn on
       $rating_setting = 1;  // Set to 0 to turn rating off and set to 1 to turn on
       $display_value = 2;  // Number of Entries to View Per Page - Must be greater than 0
       $nav_page_cutoff = 20;  // Top and Bottom Navigation links limit before new line
       $password = "PassWord";
       $title = "UCWeb GuestBook";
       $border_size = 1;
       $border_color = "#999999";
       $table_width = "500px";
       $font_size = 1;
       $font_size1 = 2;
       $font_face = "Arial";
       $font_color = "BLACK";
       $table_bgcolor = "#666666";
       $table_bgcolor1 = "#999999";
       $table_bgcolor2 = "#cccccc";
       $entries_dir = "./entries";
       $body_tag = "\n</head>\n<BODY BGCOLOR=#99ccff TEXT=#000000 LINK=#003399 VLINK=#800080 ALINK=#FF00FF";//Closing ">" is inserted in print command
       $start_html = "<HTML>\n<!--Insert Meta Tags Here-->\n<Head><title>$title</title>\n";//Insert META Tags Here
       $end_html = "\n</body>\n</html>\n";

/*-------------------------------------------------------------------------------------------------------------------------------------------*/
       if ($opt == view){  view($next_stop, $from);
       }elseif($opt == sign){ sign();
       }elseif($opt == enter){ entry($name, $email, $location, $url_title, $url, $message, $rating);
       }elseif($opt == admin){ admin($guess, $next_stop, $from);
       }elseif($opt == delete){ delete($HTTP_POST_VARS);
       }else{ main(); }
//End Settings
/*-------------------------------------------------------------------------------------------------------------------------------------------*/
//Begin main(){
function main(){
      global $html_setting, $email_setting, $smile_setting, $display_value, $nav_page_cutoff, $title, $border_size, $border_color, $border_width, $table_width,
             $font_size, $font_size1, $font_face, $font_color, $table_bgcolor, $table_bgcolor1, $table_bgcolor2, $entries_dir, $body_tag, $start_html, $end_html;
      echo("".$start_html.$body_tag.">\n<center><a href='guestbook.php?opt=view'>view</a> || <a href='guestbook.php?opt=sign'>sign</a>".$end_html."");
}
//End Main
/*-------------------------------------------------------------------------------------------------------------------------------------------*/
//Begin Sign Function
function sign(){

       global $html_setting, $email_setting, $smile_setting, $display_value, $nav_page_cutoff, $title, $border_size, $border_color, $border_width, $table_width, $rating_setting,
              $font_size, $font_size1, $font_face, $font_color, $table_bgcolor, $table_bgcolor1, $table_bgcolor2, $entries_dir, $body_tag, $start_html, $end_html;
       echo(" ".$start_html."
             <SCRIPT LANGUAGE='JavaScript'>
             <!--
             function GetSmile(Which) {
                      document.newentry.message.value = document.newentry.message.value + Which;
             }
             function ClearText() {
                   document.newentry.location.value = '';
                   document.newentry.rating.value = '5';
                   document.newentry.name.value = '';
                   document.newentry.email.value = '';
                   document.newentry.url.value = 'http://';
                   document.newentry.message.value = '';
                   document.newentry.url_title.value = '';
             }
             function CheckLength(max) {
                      if (document.newentry.message.value.length > max) {
                      alert('Maximal input characters reached!');
                      document.newentry.message.value = document.newentry.message.value.substring(0, max);
                      }
                      window.setTimeout('CheckLength(250)', 500);
             }
             //-->
             </SCRIPT>

             ".$body_tag." onLoad='javascript:CheckLength(250);'>");
       echo("<BR><div align='center'>
                   <TABLE  bgcolor='".$table_bgcolor."' border='".$border_size."' width='".$table_width."' bordercolor='".$border_color."'>
                    <TR>
                       <TD width='50%' align='center' bgcolor='".$table_bgcolor1."'>
                          <font size='".$font_size1."' face='".$font_face."' color='".$font_color."'>
                          <B>".$title."</B>
                          </font>
                       </TD>
                       <TD width='50%' align='right' bgcolor='".$table_bgcolor1."'>
                          <font size='".$font_size."' face='".$font_face."' color='".$font_color."'>
                          ".date("l dS of F Y")." &nbsp;
                          </font>
                       </TD>
                    </TR>
                    <TR>
                       <TD  colspan='2' align='left' bgcolor='".$table_bgcolor2."'>
                          <font size='".$font_size."' face='".$font_face."' color='".$font_color."'>");
       echo("<FORM name='newentry' action='guestbook.php?opt=enter' method='POST' target='_self'>&nbsp;\n
             Name:<BR>\n<INPUT TYPE='TEXT'  name='name' size='40' maxlength='50'>\n<BR>&nbsp;\n");
       //Email Option
       if ($email_setting == 1){ echo("Email:<BR>\n<INPUT TYPE='TEXT' name='email' size='40' maxlength='50'>&nbsp;\n<BR>\n");}
       echo("Location:<BR>\n<INPUT TYPE='TEXT'  name='location' size='40' maxlength='50'>&nbsp;\n<BR>\n
             HomePage Title:<BR>\n<INPUT TYPE='TEXT'  name='url_title' size='40' maxlength='50'>&nbsp;\n<BR>\n
             Website:<BR>\n<INPUT TYPE='TEXT'  name='url' size='60' maxlength='100' value='http://'>&nbsp;\n<BR>\n
             Message:<BR>\n<TEXTAREA  name='message' rows='5' cols='50'></TEXTAREA>\n<BR>&nbsp;\n");
       //Smiles Option
       if($smile_setting){echo("<A HREF='javascript:GetSmile(\":)\")' ONFOCUS='filter:blur()'><IMG SRC='images/lustig.gif' BORDER='0' WIDTH='15' HEIGHT='15'></A>
                                <A HREF='javascript:GetSmile(\";)\")' ONFOCUS='filter:blur()'><IMG SRC='images/wink.gif' BORDER='0' WIDTH='15' HEIGHT='15'></A>
                                <A HREF='javascript:GetSmile(\":sad:\")' ONFOCUS='filter:blur()'><IMG SRC='images/traurig.gif' BORDER='0' WIDTH='15' HEIGHT='15'></A>
                                <A HREF='javascript:GetSmile(\":p\")' ONFOCUS='filter:blur()'><IMG SRC='images/tongue.gif' BORDER='0' WIDTH='15' HEIGHT='15'></A>
                                <A HREF='javascript:GetSmile(\":o\")' ONFOCUS='filter:blur()'><IMG SRC='images/redface.gif' BORDER='0' WIDTH='15' HEIGHT='15'></A>
                                <A HREF='javascript:GetSmile(\":cool:\")' ONFOCUS='filter:blur()'><IMG SRC='images/cool.gif' BORDER='0' WIDTH='15' HEIGHT='15'></A>
                                <A HREF='javascript:GetSmile(\":D\")' ONFOCUS='filter:blur()'><IMG SRC='images/biggrin.gif' BORDER='0' WIDTH='15' HEIGHT='15'></A>
                                <A HREF='javascript:GetSmile(\":confused:\")' ONFOCUS='filter:blur()'><IMG SRC='images/confused.gif' BORDER='0' WIDTH='15' HEIGHT='22'></A>
                                <A HREF='javascript:GetSmile(\":eek:\")' ONFOCUS='filter:blur()'><IMG SRC='images/eek.gif' BORDER='0' WIDTH='15' HEIGHT='15'></A>
                                <A HREF='javascript:GetSmile(\":mad:\")' ONFOCUS='filter:blur()'><IMG SRC='images/mad.gif' BORDER='0' WIDTH='15' HEIGHT='15'></A>
                                <A HREF='javascript:GetSmile(\":rolleyes:\")' ONFOCUS='filter:blur()'><IMG SRC='images/rolleyes.gif' BORDER='0' WIDTH='15' HEIGHT='15'></A>");}
       else{echo("<IMG SRC='images/lustig.gif' BORDER='0' WIDTH='15' HEIGHT='15'><font size='1'>Smiles are Turned off</font><BR>");}
       //Rating Option
       if ($rating_setting){
           echo("&nbsp;<BR>Rate My Site: (5 is Best)<BR>&nbsp;<SELECT  name='rating' size='1'>");
           for ( $rating_option_value = 5 ; $rating_option_value > 0 ; $rating_option_value-- ){
                 echo("<OPTION value=".$rating_option_value.">".$rating_option_value."</OPTION>");
           }
       }
       if(!($dp = opendir($entries_dir))) die ("Failed");
       while($file = readdir($dp)){ $filenames[] = $file; }
       closedir($dp);
       echo("</SELECT><BR><BR>
             <div align='center'><INPUT TYPE='SUBMIT' name='Submit' value='Submit'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             <INPUT TYPE='reset' VALUE='Reset' ONFOCUS='filter:blur()'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             <INPUT TYPE='button' VALUE='Clear' ONCLICK='javascript:ClearText()'></div>
                      </TD>
                    </TR>
                    <TR>
                       <TD width='50%' align='center' bgcolor='".$table_bgcolor1."'>
                          <font size='".$font_size."' face='".$font_face."' color='".$font_color."'>
                          <B><a href='guestbook?opt=view'>View GuestBook</a></B>
                          </font>
                       </TD>
                       <TD width='50%' align='right' bgcolor='".$table_bgcolor1."'>
                          <font size='".$font_size."' face='".$font_face."' color='".$font_color."'>
                          Total Entries = ".(count($filenames) - 2)." &nbsp;
                          </font>
                       </TD>
                    </TR>
                    </TABLE>
                    </div>
             </FORM>
             ".$end_html." ");
}
//End Sign Function
/*-------------------------------------------------------------------------------------------------------------------------------------------*/
//Begin View Function
function view($next_stop, $from){

       global $html_setting, $email_setting, $smile_setting, $display_value, $nav_page_cutoff, $title, $border_size, $border_color, $border_width, $table_width,
              $font_size, $font_size1, $font_face, $font_color, $table_bgcolor, $table_bgcolor1, $table_bgcolor2, $entries_dir, $body_tag, $start_html, $end_html;
         echo("".$start_html."".$body_tag.">");
         //Creat Top Navigation
         nav($next_stop, $from);
         //Open entries Directory
         if(!($dp = opendir($entries_dir))) die ("Failed");
                  while($file = readdir($dp)){ $filenames[] = $file; }
         closedir($dp);
         if (!$next_stop){   $next_stop = $display_value;   }else{  }
         if (!$from){ $from = 0;  }else{  }
         //Sort Entries by Time Stamp
         rsort($filenames);
         //Get Entry Count
         $file_count = (count($filenames) - 2);
         //Create Boxes for Requested Page
         for(  ; $from < $next_stop ; $from++){
                 if($filenames[$from] != '.' && $filenames[$from] != '..' && $filenames[$from] != '' && $filenames[$from] != 'ips' ) {
                    $current_entry = file("./entries/$filenames[$from]");
                    echo("<!--".$filenames[$from]."-->");
                    draw_table("$current_entry[0]","$current_entry[1]","$current_entry[2]","$current_entry[3]","$current_entry[4]","$current_entry[5]","$current_entry[6]","$current_entry[7]");
                   }
         }
         //Bottom of Page Navigation
         echo('<BR><div align="center">
                   <TABLE  bgcolor="'.$table_bgcolor.'" border="'.$border_size.'" width="'.$table_width.'" bordercolor="'.$border_color.'">
                    <TR>
                       <TD width="50%" align="right" bgcolor="'.$table_bgcolor1.'">
                          <font size="'.$font_size.'" face="'.$font_face.'" color="'.$font_color.'"><BR>
                          </font>
                       </TD>
                       <TD width="50%" align="right" bgcolor="'.$table_bgcolor1.'">
                          <font size="'.$font_size.'" face="'.$font_face.'" color="'.$font_color.'">
                          Total Entries = '.(count($filenames) - 2).' &nbsp;
                          </font>
                       </TD>
                    </TR>
                    <TR>
                       <TD  colspan="2" align="center" bgcolor="'.$table_bgcolor2.'">
                          <font size="'.$font_size.'" face="'.$font_face.'" color="'.$font_color.'">');
         for( $nav = 0,$page = 1  ; $nav < (count($filenames) - 2) ; $nav = $nav + $display_value ){
              if(!($page == ($from / $display_value)) ){ echo("[<a href='guestbook.php?opt=view&next_stop=".( ($page) * $display_value)."&from=".( ($page - 1) * $display_value)."'>"); } else{ echo("["); }
                   echo("$page");
                   if(!($page == ($from / $display_value)) ){ echo("</a>]"); }else{ echo("]"); }
                        echo("&nbsp;&nbsp;");
                        if( $page % $nav_page_cutoff == 0   ){ echo("<BR>"); }
                            $page++;
                }
         echo("        </TD>
                    </TR>
                    </TABLE>
                    </div>".$end_html."");
}
//End View Function
/*-------------------------------------------------------------------------------------------------------------------------------------------*/
//Begin Enter Function
function entry($name, $email, $location, $url_title, $url, $message, $rating){

       global $html_setting, $email_setting, $smile_setting, $display_value, $nav_page_cutoff, $title, $border_size, $border_color, $border_width, $table_width,
              $font_size, $font_size1, $font_face, $font_color, $table_bgcolor, $table_bgcolor1, $table_bgcolor2, $entries_dir, $body_tag, $start_html, $end_html;
        //Refresh Javascript
        echo("".$start_html." <script language='javascript'>\n function refresh() { window.location='guestbook.php?opt=view'   } </script>");
        echo("".$body_tag." onload='window.setTimeout(\"refresh()\", 5000)'>");
        //IP Checker
        $current_ip = getenv("REMOTE_ADDR");
        if (!($ips_file = fopen("./ips", "r"))){echo("Failed to open IP File!");}
              $past_ip = fread($ips_file,20);
        fclose($ips_file);
        //Start Entry
        if($current_ip != $past_ip){
           global $smile_setting, $html_setting;
           echo('<div align="center"><B><Font size="4">Thank You for Signing my GuestBook</font></B><BR>Page will Refresh in 5 secs</div>');
           $new_record = time();
           if (!($file = fopen("$entries_dir/$new_record", "w+"))){echo("Failed to Create Entry File!");
                 }else{
                       $time_signed = date("l dS of F Y @h:i:s A");
                       $name = ereg_replace ("<[^>]*>", "", $name);                                 //Removes HTML Tags from Name
                       if (!(ereg("^[^@ ]+@[^@ ]+\.[^@ \.]+$", $email, $trashed))) { $email = ""; } //Validates Email and voids if not valid
                       $location = ereg_replace ("<[^>]*>", "", $location);                         //Removes HTML Tags from Location
                       $url_title = ereg_replace ("<[^>]*>", "", $url_title);                       //Removes HTML Tags from URL Title
                       if ($url == "http://") { $url = ""; }
                       if ($url != "") {
                           if (ereg ("^[^http://]",$url)) {$url=(("http://").$url);}
                       }
                       $message = eregi_replace("(fuck|shit|ass|bitch|suck|dick|pussy)", "****", $message);  //Check for bad words
                       $message = eregi_replace("(\n)", ":NL:", $message);                                   //Replace New Lines
                       if(!$html_setting){
                           $message = ereg_replace ("<[^>]*>", "", $message);  //Removes HTML Tags that are put in if turned on
                       }
                       if($smile_setting){
                          $message = eregi_replace("(:))", "<img src='images/lustig.gif' border='0'>", $message);    //check for smiles
                          $message = eregi_replace("(;))", "<img src='images/wink.gif' border='0'>", $message);
                          $message = eregi_replace("(:sad:)", "<img src='images/traurig.gif' border='0'>", $message);
                          $message = eregi_replace("(:p)", "<img src='images/tongue.gif' border='0'>", $message);
                          $message = eregi_replace("(:o)", "<img src='images/redface.gif' border='0'>", $message);
                          $message = eregi_replace("(:cool:)", "<img src='images/cool.gif' border='0'>", $message);
                          $message = eregi_replace("(:D)", "<img src='images/biggrin.gif' border='0'>", $message);
                          $message = eregi_replace("(:confused:)", "<img src='images/confused.gif' border='0'>", $message);
                          $message = eregi_replace("(:eek:)", "<img src='images/eek.gif' border='0'>", $message);
                          $message = eregi_replace("(:mad:)", "<img src='images/mad.gif' border='0'>", $message);
                          $message = eregi_replace("(:rolleyes:)", "<img src='images/rolleyes.gif' border='0'>", $message);
                       }
                       fwrite($file, "$name\n$email\n$location\n$url_title\n$url\n$message\n$rating\n$time_signed");
                       fclose($file);
                       if (!($ips_file = fopen("./ips", "w"))){echo("Failed to open IP File!");
                             }else{
                                    fwrite($ips_file, "$current_ip");
                                    fclose($ips_file);
                       }
           }
        }else{ echo( "<div align='center'><B><Font size='4'>You have already Signed my GuestBook</font></B><BR>Page will Refresh in 5 secs</div>"); }
        echo(" ".$end_html." ");
}
// End Enter Function
/*-------------------------------------------------------------------------------------------------------------------------------------------*/
//Begin Navigation Function
function nav($next_stop, $from){

       global $html_setting, $email_setting, $smile_setting, $display_value, $nav_page_cutoff, $title, $border_size, $border_color, $border_width, $table_width,
              $font_size, $font_size1, $font_face, $font_color, $table_bgcolor, $table_bgcolor1, $table_bgcolor2, $entries_dir, $body_tag, $start_html, $end_html;
         if(!($stats_dp = opendir($entries_dir))) die ("Failed to open entries Directory");
         while($stats_file = readdir($stats_dp)){ $filenames[] = $stats_file; }
         closedir($stats_dp);
         echo('<div align="center">
                    <TABLE  bgcolor="'.$table_bgcolor.'" border="'.$border_size.'" width="'.$table_width.'" bordercolor="'.$border_color.'">
                       <TR>
                          <TD width="50%" align="center" bgcolor="'.$table_bgcolor1.'">
                              <font size="'.$font_size1.'" face="'.$font_face.'" color="'.$font_color.'">
                              &nbsp;<B>'.$title.'</B>
                              </font>
                          </TD>
                          <TD width="50%" align="right" bgcolor="'.$table_bgcolor1.'">
                              <font size="'.$font_size.'" face="'.$font_face.'" color="'.$font_color.'">
                              &nbsp;Today is:  '.date("l dS of F Y").'
                              </font>
                          </TD>
                       </TR>
                       <TR>
                          <TD width="50%" align="center" bgcolor="'.$table_bgcolor2.'">
                              <font size="'.$font_size.'" face="'.$font_face.'" color="'.$font_color.'">
                              &nbsp;<a href="guestbook.php?opt=sign">Sign GuestBook</a>
                              </font>
                          </TD>
                          <TD width="50%" align="right" bgcolor="'.$table_bgcolor2.'">
                              <font size="'.$font_size.'" face="'.$font_face.'" color="'. $font_color.'">
                              Total Entries = '.(count($filenames)- 2 ).' &nbsp;
                              </font>
                          </TD>
                       </TR>
                       <TR>
                          <TD  colspan="2"  align="right" bgcolor="'.$table_bgcolor1.'">
                               <font size="'.$font_size.'" face="'.$font_face.'" color="'.$font_color.'"><div align="center">');
         for( $x = 0,$page = 1  ; $x < (count($filenames) - 2) ; $x = $x + $display_value ){
              if(!($page == ( ($from + $display_value)  / $display_value)) ){ echo("[<a href='guestbook.php?opt=view&next_stop=".( ($page) * $display_value)."&from=".( ($page - 1) * $display_value)."'>");
                   }else{ echo("["); }
              echo("$page");
              if(!($page == ( ($from + $display_value) / $display_value)) ){ echo("</a>]"); } else{ echo("]"); }
              echo("&nbsp;&nbsp;");
              if( $page % $nav_page_cutoff == 0   ){ echo("<BR>"); }
              $page++;
         }
         echo('</div></font>
                          </TD>
                       </TR>
                    </TABLE>
               </div>');
}
//End Navigation Function
/*-------------------------------------------------------------------------------------------------------------------------------------------*/
//Begin Draw_Table Function
function draw_table($name, $email, $location, $url_title, $url, $message, $rating, $date){

       global $html_setting, $email_setting, $smile_setting, $display_value, $nav_page_cutoff, $title, $border_size, $border_color, $border_width, $table_width,
              $font_size, $font_size1, $font_face, $font_color, $table_bgcolor, $table_bgcolor1, $table_bgcolor2, $entries_dir, $body_tag, $start_html, $end_html;
         //Refresh Javascript

         //Replace New Lines
         $message = eregi_replace("(:NL:)", "<BR>", $message);
         echo("<BR><div align='center'>
                  <TABLE bgcolor='".$table_bgcolor."' border=".$border_size." width=".$table_width." bordercolor='".$border_color."'>
                     <TR>
                        <TD width='50%' bgcolor='".$table_bgcolor1."'>");
         /*if Email is defined*/
         if($email != "\n"){ echo("<a href='mailto:".$email."'><img src='./images/email.gif' border='0'></a> "); }
         echo("<font size='".$font_size."' face='".$font_face."' color='".$font_color."'>
                  ".$name."
                  <BR>From: ".$location."
                  </font>
                        </TD>
                        <TD width='50%' align='right' bgcolor='".$table_bgcolor1."'>
                           <font size='".$font_size."' face='".$font_face."' color='".$font_color."'>
                           ".$date."
                           </font>
                        </TD>
                     </TR>
                     <TR>
                        <TD colspan='2' valign='top' bgcolor='".$table_bgcolor2."'>
                           <font size='".$font_size."' face='".$font_face."' color='".$font_color."'>
                           ".$message."<BR><BR>
                           </font>
                        </TD>
                      </TR>
                      <TR>
                        <TD width='50%' bgcolor='".$table_bgcolor1."'>");
         /*if url is defined*/
         if($url_title != "\n" && $url != "\n"){ echo("<a href='".$url."'><img src='./images/home.gif' border='0'></a>&nbsp;"); }else{ echo("<BR>"); }
         echo("<font size='".$font_size."' face='".$font_face."' color='".$font_color."'>");
         /*if url is defined*/
         if($url_title != "\n" && $url != "\n"){ echo("<a href='".$url."' target='_blank'>".$url_title."</a>&nbsp;"); }
         echo("</font>
                        </TD>
                        <TD width='50%' align='right' bgcolor='".$table_bgcolor1."'>
                           <font size='".$font_size."' face='".$font_face."' color='".$font_color."'>");
         /*Star Rating Print Out*/
         if($rating != "\n"){
              for($x = 1 ; $x <= 5 ; $x++ ){
                   if($rating >= $x){ echo("<img src='./images/star_full.gif' border='0'> ");
                   }else{ echo("<img src='./images/star_empty.gif' border='0'> "); }
               }
         }else{ echo("<BR>"); }
         echo("         </font>
                        </TD>
                     </TR>
                  </TABLE></div>");
      }
// End Draw_Table Function
/*-------------------------------------------------------------------------------------------------------------------------------------------*/
//Begin Admin Function
function admin($guess, $next_stop, $from){

       global $html_setting, $email_setting, $smile_setting, $display_value, $nav_page_cutoff, $title, $border_size, $border_color, $border_width, $table_width,
              $font_size, $font_size1, $font_face, $font_color, $table_bgcolor, $table_bgcolor1, $table_bgcolor2, $entries_dir, $body_tag, $start_html, $end_html;
       global $password;

       echo("".$start_html."".$body_tag.">");

       if($guess == $password){ admin_view($guess, $next_stop, $from);
       }else{
       echo("<BR><div align='center'>
                  <TABLE bgcolor='".$table_bgcolor."' border=".$border_size." width=".$table_width." bordercolor='".$border_color."'>
                     <TR>
                        <TD width='50%' align='center' bgcolor='".$table_bgcolor1."'>");
       echo("<font size='".$font_size1."' face='".$font_face."' color='".$font_color."'>
                  <B>Admin Login</B>
                  </font>
                        </TD>
                        <TD width='50%' align='right' bgcolor='".$table_bgcolor1."'>
                           <font size='".$font_size."' face='".$font_face."' color='".$font_color."'>
                           ".date("l dS of F Y")."
                           </font>
                        </TD>
                     </TR>
                     <TR>
                        <TD colspan='2' valign='top align='center' bgcolor='".$table_bgcolor2."'>
                           <font size='".$font_size."' face='".$font_face."' color='".$font_color."'>
                           <BR><div align='center'>
                           <FORM  method='POST' target='_self'>
                           Password<BR><INPUT TYPE='TEXT'  name='guess' maxlength='40'>
                           <BR><BR>
                           <INPUT TYPE='SUBMIT'  name='Submit' value='Login'>
                           </div>
                           </FORM>
                           </font>
                        </TD>
                      </TR>
                      <TR>
                        <TD width='50%' align='center' bgcolor='".$table_bgcolor1."'>");
       echo("<font size='".$font_size."' face='".$font_face."' color='".$font_color."'>");
       echo("<a href='guestbook.php?opt=view'>View GuestBook</a></font>
                        </TD>
                        <TD width='50%' align='right' bgcolor='".$table_bgcolor1."'>
                           <font size='".$font_size."' face='".$font_face."' color='".$font_color."'>");

       if(!($dp = opendir($entries_dir))) die ("Failed");
       while($file = readdir($dp)){ $filenames[] = $file; }
       closedir($dp);
       //Sort Entries by Time Stamp
       rsort($filenames);
       //Get Entry Count
       echo ( "Entries = ".(count($filenames) - 2))."";
       echo("         </font>
                        </TD>
                     </TR>
                  </TABLE></div>");
       }

       echo("$end_html");
}
//End Admin Function
/*-------------------------------------------------------------------------------------------------------------------------------------------*/
//Begin Admin View Function
function admin_view($guess, $next_stop, $from){

       global $html_setting, $email_setting, $smile_setting, $display_value, $nav_page_cutoff, $title, $border_size, $border_color, $border_width, $table_width,
              $font_size, $font_size1, $font_face, $font_color, $table_bgcolor, $table_bgcolor1, $table_bgcolor2, $entries_dir, $body_tag, $start_html, $end_html;
       echo("".$start_html."".$body_tag.">");
       //Creat Top Navigation
       if(!($stats_dp = opendir($entries_dir))) die ("Failed to open entries Directory");
       while($stats_file = readdir($stats_dp)){ $filenames[] = $stats_file; }
       closedir($stats_dp);

       echo('<div align="center">
             <TABLE  bgcolor="'.$table_bgcolor.'" border="'.$border_size.'" width="'.$table_width.'" bordercolor="'.$border_color.'">
                     <TR>
                         <TD width="50%" align="center" bgcolor="'.$table_bgcolor1.'">
                             <font size="'.$font_size1.'" face="'.$font_face.'" color="'.$font_color.'">
                             &nbsp;<B>Admin Page</B>
                             </font>
                         </TD>
                         <TD width="50%" align="right" bgcolor="'.$table_bgcolor1.'">
                             <font size="'.$font_size.'" face="'.$font_face.'" color="'.$font_color.'">
                             &nbsp;Today is:  '.date("l dS of F Y").'
                             </font>
                         </TD>
                     </TR>
                     <TR>
                         <TD width="50%" align="center" bgcolor="'.$table_bgcolor2.'">
                             <font size="'.$font_size.'" face="'.$font_face.'" color="'.$font_color.'">
                             &nbsp;<a href="guestbook.php?opt=view">View GuestBook</a>
                             </font>
                         </TD>
                         <TD width="50%" align="right" bgcolor="'.$table_bgcolor2.'">
                             <font size="'.$font_size.'" face="'.$font_face.'" color="'. $font_color.'">
                             Total Entries = '.(count($filenames)- 2 ).' &nbsp;
                             </font>
                         </TD>
                     </TR>
                     <TR>
                         <TD colspan="2"  align="right" bgcolor="'.$table_bgcolor1.'">
                             <font size="'.$font_size.'" face="'.$font_face.'" color="'.$font_color.'">
                             </font>
                          </TD>
                       </TR>
                    </TABLE>
               </div> ');



       if (!$next_stop){   $next_stop = $display_value;   }else{  }
       if (!$from){ $from = 0;  }else{  }
       //Sort Entries by Time Stamp
       rsort($filenames);
       //Get Entry Count
       $file_count = (count($filenames) - 2);
       //Create Boxes for Requested Page
       echo("<INPUT TYPE='HIDDEN'  name='guess' value='$guess'>");
       echo("<FORM name='newentry' action='guestbook.php?opt=delete' method='POST' target='_self'>&nbsp;\n");
       for(  ; $from < $next_stop ; $from++){
               if($filenames[$from] != '.' && $filenames[$from] != '..' && $filenames[$from] != '' && $filenames[$from] != 'ips' ) {
                  $current_entry = file("./entries/$filenames[$from]");
                  echo("<!--".$filenames[$from]."-->");
                  draw_table("$current_entry[0]","$current_entry[1]","$current_entry[2]","$current_entry[3]","$current_entry[4]","$current_entry[5]","$current_entry[6]","$current_entry[7]");
                  echo("<div align='center'><font size='".$font_size."' face='".$font_face."' color='".$font_color."'>Delete: <INPUT TYPE='CHECKBOX'  name='");
                  echo("file_".$filenames[$from]."");
                  echo("' value='");
                  echo("".$filenames[$from]."'> </font></div>");
                 }
          }
       //Bottom of Page Navigation
       echo('<BR><div align="center"><INPUT TYPE="SUBMIT"  name="Submit" value="Submit"></FORM>
                   <TABLE  bgcolor="'.$table_bgcolor.'" border="'.$border_size.'" width="'.$table_width.'" bordercolor="'.$border_color.'">
                    <TR>
                       <TD width="50%" align="right" bgcolor="'.$table_bgcolor1.'">
                          <font size="'.$font_size.'" face="'.$font_face.'" color="'.$font_color.'"><BR>
                          </font>
                       </TD>
                       <TD width="50%" align="right" bgcolor="'.$table_bgcolor1.'">
                          <font size="'.$font_size.'" face="'.$font_face.'" color="'.$font_color.'">
                          Total Entries = '.(count($filenames) - 2).' &nbsp;
                          </font>
                       </TD>
                    </TR>
                    <TR>
                       <TD  colspan="2" align="center" bgcolor="'.$table_bgcolor2.'">
                          <font size="'.$font_size.'" face="'.$font_face.'" color="'.$font_color.'">');
       $from = $from - $display_value;
       for( $x = 0,$page = 1  ; $x < (count($filenames) - 2) ; $x = $x + $display_value ){
            if(!($page == ( ($from + $display_value)  / $display_value)) ){ echo("[<a href='guestbook.php?opt=admin&guess=".$guess."&next_stop=".( ($page) * $display_value)."&from=".( ($page - 1) * $display_value)."'>");
            }else{ echo("["); }
            echo("$page");
            if(!($page == ( ($from + $display_value) / $display_value)) ){ echo("</a>]"); } else{ echo("]"); }
            echo("&nbsp;&nbsp;");
            if( $page % $nav_page_cutoff == 0   ){ echo("<BR>"); }
            $page++;
          }
       echo("        </TD>
                    </TR>
                    </TABLE>
                    </div>".$end_html."");
}
//End Admin View Function
/*-------------------------------------------------------------------------------------------------------------------------------------------*/
//Begin Delete Function
function delete($HTTP_POST_VARS){

       global $html_setting, $email_setting, $smile_setting, $display_value, $nav_page_cutoff, $title, $border_size, $border_color, $border_width, $table_width,
              $font_size, $font_size1, $font_face, $font_color, $table_bgcolor, $table_bgcolor1, $table_bgcolor2, $entries_dir, $body_tag, $start_html, $end_html;

       echo("".$start_html." <script language='javascript'>\n function refresh() { window.location='guestbook.php?opt=view'   } </script>");
       echo("".$body_tag." onload='window.setTimeout(\"refresh()\", 5000)'>");
       if(!($dp = opendir($entries_dir))) die ("Failed");
       while($file = readdir($dp)){ $filenames[] = $file; }
       closedir($dp);
       echo('<div align="center">
             <TABLE  bgcolor="'.$table_bgcolor.'" border="'.$border_size.'" width="'.$table_width.'" bordercolor="'.$border_color.'">
                   <TR>
                       <TD width="50%" align="center" bgcolor="'.$table_bgcolor1.'">
                           <font size="'.$font_size1.'" face="'.$font_face.'" color="'.$font_color.'">
                           &nbsp;<B>Entry Deletion</B>
                           </font>
                       </TD>
                       <TD width="50%" align="right" bgcolor="'.$table_bgcolor1.'">
                           <font size="'.$font_size.'" face="'.$font_face.'" color="'.$font_color.'">
                           &nbsp;Today is:  '.date("l dS of F Y").'
                           </font>
                       </TD>
                   </TR>
                   <TR>
                       <TD colspan="2" align="center" bgcolor="'.$table_bgcolor2.'">
                           <font size="'.$font_size.'" face="'.$font_face.'" color="'.$font_color.'">');
       while( list($key, $value) = each($HTTP_POST_VARS) )
       {
            if ($value != "Submit"){ unlink("$entries_dir/$value"); echo("<BR>Entry # ".$value." was deleted"); }
       }
       echo('              <BR>Page will refresh in 5 secs</font>
                       </TD>
                   </TR>
                   <TR>
                       <TD align="right" bgcolor="'.$table_bgcolor1.'">
                           <font size="'.$font_size.'" face="'.$font_face.'" color="'.$font_color.'"><div align="center">
                       </TD>
                       <TD width="50%" align="right" bgcolor="'.$table_bgcolor2.'">
                           <font size="'.$font_size.'" face="'.$font_face.'" color="'. $font_color.'">
                           Total Entries = '.(count($filenames)- 2 ).' &nbsp;
                           </font>
                       </TD>
                   </TR>
              </TABLE>
              </div>'.$end_html.'');
}
//End Delete Function
?>