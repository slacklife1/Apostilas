Title: UCWeb GuestBook Lite
Description: 
A PHP guestbook that doesn't require a database backend. Fully customizable, includes smiles, bad word filter, html filter, validates good and bad emails and urls, password protected admin area to delete unwanted entries, ip tracking to prevent multilple post, ability to turn filters on and off
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=421&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
