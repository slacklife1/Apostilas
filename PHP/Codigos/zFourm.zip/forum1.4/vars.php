<?
	$forumTitle = "XGraphic's Forum";                            // Forum title
	$homeTitle = "XGraphic";                                     // Homepage name
	$homeURL = "http://www.xgra.com";                            // Homepage URL
	$replyURL = "http://www.xgra.com/home/forum/reply.php";      // URL to 'reply.php' file

	$dbHost = "";                // MySql host name
	$dbName = "forum";           // Database name
	$dbUser = "";                // User name
	$dbPasswd = "";              // Password

	$adminName = "name";        // Admin name
	$adminPasswd = "pass";      // Password, please change them

	$badWordFilter = 1;         // allow bad words checking? 1=yes, 0=no
	$banIP = 1;		            // ban ip? 1=yes, 0=no
	$emailAdmin = 1;            // sent new posting to admin? 1=yes, 0=no
	$adminEmail = "admin@domain.com"; // email address where new posting sent to

	$maxThread = "20";           // Thread number per page
	$fontFamily = "Verdana";
	$fontSize = "9pt";
	$linkColor = "#0080C0";
	$visitedColor = "#0080C0";
	$hoverColor = "#0080C0";
	$bgColor = "#FFFFFF";      // background color
	$bgImage = "";		   // background image
?>