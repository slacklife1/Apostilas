<HTML>
<BODY>
<?
require("global.php");
$forum->query("INSERT INTO forum VALUES(NULL, 'Visual Basic', 'Get help with Visual Basic programming', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'C & C++', 'Get help with C/C++ programming', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'PHP', 'Get help with PHP programming', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'HTML & JS', 'Get help with HTML and JavaScript programming', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'Java', 'Get help with Java programming', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'ASP & ColdFusion', 'Get help with Active Server Pages and ColdFusion', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'JSP', 'Get help with Java Server Pages', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'Perl', 'Get help with Perl programming', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'Delphi', 'Get help with Delphi programming', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'API', 'Get help with the API', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'Database', 'Get help with Database programming', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'COM', 'Get help with COM and ActiveX programming', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'Basic', 'Get help with Basic programming', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'Network Development', 'Get help with Network Development', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'SQL', 'Get help with SQL', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'Flash', 'Get help with Flash', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'XML', 'Get help with XML programming', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'Games and Graphics', 'Get help with Game programming', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'Assembler & Epsilon', 'Get help with Assembler and Epsilon programming', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'Math', 'Get help with Math', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'Science', 'Get help with Science', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'Chit Chat', 'Have Fun!!', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'Complaints', 'Anonymously complain about other users', 0, 0, 0, 0, 0, 0)");
$forum->query("INSERT INTO forum VALUES(NULL, 'Feedback', 'Report bugs', 0, 0, 0, 0, 0, 0)");
?>
</BODY>
</HTML>