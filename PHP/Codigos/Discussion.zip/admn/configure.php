<?
$servername="localhost";
$dbusername="root";
$dbpassword="";
$dbname="forum11";

$cppassword="forum";

?>