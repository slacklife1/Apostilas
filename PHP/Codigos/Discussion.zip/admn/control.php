<HTML>
<HEAD><TITLE>Control Panel</TITLE></HEAD>
<BODY>
<A HREF="cp/admin.php">Set new Administrator</A> <BR>
<A HREF="cp/admin.php">Remove Administrator</A> <BR>
<A HREF="cp/user.php">Create User</A> <BR>
<A HREF="cp/user.php">Delete User</A> <BR>
<A HREF="cp/forum.php">Add Forum</A> <BR>
<A HREF="cp/forum.php">Delete Forum</A> <BR>
</BODY>
</HTML>