<?
function img($name){
echo "<IMG SRC=\"$name.gif\">";
}
img("smile");
img("biggrin");
img("drunk");
img("eek");
img("redface");
img("tounge");
img("sad");
img("evil");
img("confused");
img("mad");
img("rolleyes");
img("cool");
img("wink");
img("tired");

?>