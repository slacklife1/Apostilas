<HTML>
<BODY>
<?
echo "$pagename source: <BR>";
show_source($pagename);
?>
</BODY>
</HTML>