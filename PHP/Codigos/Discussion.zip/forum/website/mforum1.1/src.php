<HTML>
<BODY>
<?
showsource("newthread.php");
?>
</BODY>
</HTML>