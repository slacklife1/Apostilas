first start up your web server, start up MySQL, 
and point your browser in the direction of

http://localhost/sub-dir-where-forum-is-located/admn/install.php

Then, register your username, then, go to
http://localhost/..../admn/control.php
login as

Username: Admin
Password: you

and set your new username as the administrator.
after that, add the forums you would like, and thats it.

I haven't written the Create/Delete user page yet, because that is not
completely necesary.

Hope you enjoy this,

Dennis Wrenn
denniswrenn@yahoo.com