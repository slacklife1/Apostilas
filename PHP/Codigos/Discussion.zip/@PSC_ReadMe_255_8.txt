Title: Complete Discussion Forum using MySQL
Description: This is a free discussion forum that uses the MySQL relational database. updated: now has administrator options, add/delete forums, and set/disable administrators. soon I will add more. current version is 1.1
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=255&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
