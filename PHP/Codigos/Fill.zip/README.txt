You must create a table named "TestTable" and add two fields "ID" and "Name"
if you don't know how to do that see CreateTheTables.txt

Chris Christodoulou
tolisc@codeauction.com
http://www.codeauction.com