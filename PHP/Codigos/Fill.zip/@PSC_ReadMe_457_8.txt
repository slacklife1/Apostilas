Title: ^Fill a select Box From database (mysql database)
Description: This is an example of how you can fill a select box with values and text from a mysql database.
It shows how to connect to the database and loop through the fields and add the data in a select box
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=457&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
