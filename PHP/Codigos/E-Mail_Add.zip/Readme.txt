          //////////////////////////////
          //                          //
          //   E-Mail Address Munge   //
          //    By Richard Silvers    //
          //                          //
          //////////////////////////////


	E-Mail Address Munge is a fully-commented PHP script
that will open a file, search it for e-mail addresses, and
munge them to protect them from e-mail address harvesters.

	The script searches through the file by opening it
and looping through the string one character at a time.
Once it has found a possible match, it will issue two more
loops and try to find the beginning and end of the address.
Once the loops complete, the script compares the possible
e-mail address to a regual expression and munges the address
if it fits the regexp string. In addition to this, the script
includes two functions: a function to test a character against
a string of delimiter characters, and a function to track the
execution time of the script.
