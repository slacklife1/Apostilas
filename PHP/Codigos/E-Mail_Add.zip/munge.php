<HTML>
<HEAD><TITLE>E-Mail Address Munge</TITLE></HEAD>

<?

  function test_delim($test_char, $test_string) {
  // Function: test_delim
  // Description: Tests for the character $test_char in the string
  // $test_string and returns whether or not it was found.

    // Set current array index $index to zero.
    $index = 0;
    // Loop while $index is less than the length of $test_string.
    while ($index < strlen($test_string)) {
      // If $test_char matches the current character $test_string[$index], return TRUE.
      if ($test_string[$index] == $test_char) {
        return TRUE;
      }
      // Increment $index by one.
      $index++;
    }
    // If loop completes, obviously nothing was found, return FALSE.
    return FALSE;
  }

  function execution_time() {
    // Function: execution_time
    // Description: Returns the current execution time.

    // Explode string returned from microtime() into $mictime array.
    $mictime = explode(" ", microtime());
    // Set $msec to first entry in array.
    $msec = (double)$mictime[0];
    // Set $sec to second entry in array.
    $sec = (double)$mictime[1];
    // Return sum of $sec + $msec.
    return $sec + $msec;
  }


  // Make sure $filename is set, and that it doesn't contain an empty value.
  if (isset($filename) && $filename != "") {

    // Check if file $filename exists.
    if (!file_exists("$filename")) {
      // If not, end the script execution.
      die ("Can't open file: $filename");
    }

    // Create a counter of e-mail addresses that were munged.
    $mungecount = 0;
    // Set $start_script_time the execution time at the beginning of the script.
    $start_script_time = execution_time();


    // Create a file descriptor for $filename, and open it as read only.
    $fd = fopen($filename, "r");
    // Read the entire contents of $filename into $fstring.
    $fstring = fread($fd, filesize($filename));
    // Close the file descriptor.
    fclose($fd);    

    // Check for @'s in $fstring, if there aren't any we aren't going to loop through it looking for them.
    if (is_int(strpos($fstring, "@"))) {

      // Set current array index $index to zero.
      $index = 0;
      // Loop while $index is less than the length of $fstring.
      while ($index <= strlen($fstring)) {
        // Test if character $fstring[$index] is @.
        if ($fstring[$index] == "@") {

          // Start a reverse index going backwards from @.
          $revindex = $index - 1;
          // Loop while $revindex is greater than position 0 in $fstring.
          while ($revindex >= 0) {
            // Test if the character $fstring[$revindex] is a delimiter character.
            if (test_delim($fstring[$revindex], " '\",:;<>?/{}[]|\\!@#$%^&*()+-.\n\r")) {
              // If it is, break the loop, we hopefully have the first half of the address.
              break;
            }
            // Decrement $revindex.
            $revindex--;
          }        

          // Start a forward index going forwards from @.
          $fwdindex = $index + 1;
          // Loop while $fwdindex is less than the length of $fstring.
          while ($fwdindex <= strlen($fstring)) {
            // Test if the character $fstring[$fwdindex] is a delimiter character.
            if (test_delim($fstring[$fwdindex], " '\",:;<>?/{}[]|\\!@#$%^&*()+-\n\r")) {
              // If it is, break the loop, we hopefully have the second half of the address.
              break;
            }
            // Increment $fwdindex.
            $fwdindex++;
          }

          // Parse the address using $revindex and $fwdindex.
          $addr = substr($fstring, $revindex + 1, ($fwdindex - $revindex) - 1);

          // If the address in $fstring was at the end of the sentence and was followed by a period,
          // it wil still remain on the end of $addr. This is because I did not want to parse out periods
          // and lose the last half of the domain name.
          // Test if the last character in $addr is a period.
          if ($addr[strlen($addr) - 1] == ".") {
            // If so, replace it with an empty string.
            $addr = substr_replace($addr, "", strlen($addr) - 1, 1);
          }

          // Match $addr against an e-mail address regular expression.
          if (ereg('^[a-zA-Z0-9\-\.\_]+\@(\[?)[a-zA-Z0-9\-\.]+\.([a-zA-Z]{2,3}|[0-9]{1,3})(\]?)$', $addr)) {
            // If it fits, we have a valid e-mail address. Munge it.
            $fstring = substr_replace($fstring, "#", $index, 1);
            // Increment $mungecount.
            $mungecount++;
          }
        }
        // Increment $index.
        $index++;
      }
    } 

    // Create a file descriptor for $filename, and open it as write only.
    $fd = fopen($filename, "w");
    // Write the entire contents of $fstring to the $fd.
    $fstring = fwrite($fd, $fstring);
    // Close the file descriptor.
    fclose($fd);

    // Set the $end_script_time the execution time at the end of the script.
    $end_script_time = execution_time();
    // Set $runtime by subtracting $start_script_time from $end_script_time.
    $runtime =  $end_script_time - $start_script_time;
    // Print out information about the script.
    print ("File: $filename has been updated.<BR>");
    print ("Filesize: " . filesize($filename) . " bytes<BR>");
    print ("$mungecount addresses were munged.<BR>");
    print ("Script execution took $runtime seconds.");

    // Script is done, return so it won't send the HTML below.
    return;
  }

?>

<p align="center">
Type in a (local) filename below with e-mail addresses to munge:
</p>

<p align="center">
<FORM METHOD="POST" ACTION="<?$PHP_SELF?>">
<INPUT TYPE="TEXT" NAME="filename" SIZE="30">
<INPUT TYPE="Submit" NAME="Submit" VALUE="Submit">
</FORM>
</p>

</HTML>