Title: Dynamic Calendar
Description: This class can draw a universal small calendar,
that has dynamic background color for each day depending of the monthly data passed as argument, and either raises a popup to give details upon the data or links to another page calculated upon the day and month.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=785&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
