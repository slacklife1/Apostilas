<?php
/*This script displays a calendar of the month m, year y,
with a monthly distribution set in the array monthlydata.

For instance, if the data represent downtime of a production server,
the background color of a day will be even more closer to the color red that the
downtime for that day is high, and closer to the color green otherwise.

Tip: use styles/CSS to adapt the fonts used in the calendar with the overall style of your website.

by F. HADDADI, Sept.-Oct. 2002
*/

/*get arguments from the URL*/
$m=$_GET["m"];
$y=$_GET["y"];
$monthlydata=$_GET["monthlydata"];

require("lib/cls/calendar.cls");
$myCal = new Calendar;
?>
<html>

<head>
<script language=JavaScript>
<!-- 
/*This function is called by the calendar class,
it has to be named popup() */
function popup(adate,data) {
	var msg= adate + ":\n\nTotal downtime for that day: ";
	var h = Math.floor(data/60);
	data-= 60*h;
	data+= " min"
	if(h > 0) {
		msg+= h + " h " + data; }
	else {
		msg+= data; }
		
	alert(msg);
	return;
}
//-->
</script>
</head>
  
<body bgcolor=#FFFF80 marginheight=0 marginwidth=0>

<?php 
/*if this page is used like a demo, loop back with arguments*/

//$myCal->showprevnext=false; (default behavior is true)

//comment the following 2 lines to check MONTHLYDATA
//$myCal->mode="DAYLINK";
//$myCal->daylink="links/%Y/%m/%d.htm";

//comment the following 3 lines to test DAYLINK
$myCal->mode="MONTHLYDATA";
$monthlydata = "1,20,64,0,0,5,7,9,12,22,33,187,128,97,32,16,7,3,0,0,0,273,0,0,0,0,0,0,31,0,0";
$myCal->monthlydata = explode(",",$monthlydata);

//other settings
$myCal->lang="en";

/*if month+date are defined, set them, otherwise defined later in the class*/
$myCal->m=$m;
$myCal->y=$y;


$myCal->PrintMonth();

print "<p>Underlined days can vary from <font color=#00FF00>green</font> to vivid <font color=#FF0000>red</font> depending on the downtime length for a day.</p>\n";

print "<table border=0 cellpadding=0 cellspacing=0>\n  <tr>\n";

//legend
for($i=0;$i<20;$i++) {
	print"\t\t    <td width=10 align=center>";
	if($i%5 == 0) 
		print$i;
	else
		print"&nbsp;";
		
	print"</td>\n";
}
print "<td width=10 align=center>20+</td>\n";
print"\t  </tr>\n\t  <tr>\n";

//spectrum
for($i=0;$i<=20;$i++) {
	print "\t\t    <td width=2 bgcolor=#".$myCal->pc2color($i).">&nbsp;</td>\n";	
}
print "</table>\n";
?>

</body>
</html>