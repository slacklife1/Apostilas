<?
 /* This is MLChat 0.4b by Major Lockup
  * 
  * A Web-Based Chat System. Was made to be a simple way to chat
  * in the web when only being able to see HTML. No need to
  * connect anywhere, so it works behind firewalls etc..
  * How ever since developement reached it's limits, I decided
  * to make it more flexible and make it work as an add-on for
  * PHPNuke and phpBB.
  *
  * This is GNU software
  */
?>
<? include "mlchat.conf"; ?>
<HTML>
<BODY BGCOLOR="<? echo $ROUND_COL; ?>" TEXT="<? echo $ROUND_TEXT; ?>" VLINK="<? echo $ROUND_VLINK; ?>" LINK="<? echo $ROUND_LINK; ?>">
<TABLE ALIGN=CENTER BORDER=0 WIDTH="100%">
<TR>
<TD><A HREF="mlchatmain.php" TARGET=MLCHATMAIN><FONT SIZE=2>Refresh!</FONT></A></TD><TD ALIGN=CENTER><CENTER><H1><? echo $TiTLE; ?></H1></CENTER></TD><TD ALIGN=right><A HREF="http://mlockup.insane.gr/mlchat" TARGET="_new"><FONT SIZE=2>MLChat Home</FONT></A></TD>
</TR>
</TABLE>
</BODY>
</HTML>
