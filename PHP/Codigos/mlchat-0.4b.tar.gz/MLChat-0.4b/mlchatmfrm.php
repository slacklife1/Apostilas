<?
 /* This is MLChat 0.4b by Major Lockup
  * 
  * A Web-Based Chat System. Was made to be a simple way to chat
  * in the web when only being able to see HTML. No need to
  * connect anywhere, so it works behind firewalls etc..
  * How ever since developement reached it's limits, I decided
  * to make it more flexible and make it work as an add-on for
  * PHPNuke and phpBB.
  *
  * This is GNU software
  */
?>
<HTML>
<FRAMESET FRAMESPACING="0" BORDER="FALSE" FRAMEBORDER="0" COLS="35,*,35">
<FRAME NAME="MLCHATLEFT" SRC="mlchatleft.php" SCROLLING="NO" NORESIZE MARGINWIDTH="0" MARGINHEIGHT="0" FRAMEBORDER="NO">
<FRAME NAME="MLCHATMAIN" SRC="mlchatmain.php" SCROLLING="AUTO" NORESIZE MARGINWIDTH="0" MARGINHEIGHT="0" FRAMEBORDER="NO">
<FRAME NAME="MLCHATACTION" SRC="mlchatact.php" SCROLLING="NO" NORESIZE MARGINWIDTH="0" MARGINHEIGHT="0" FRAMEBORDER="NO">
</FRAMESET>
</HTML>
