<?
 /* This is MLChat 0.4b by Major Lockup
  * 
  * A Web-Based Chat System. Was made to be a simple way to chat
  * in the web when only being able to see HTML. No need to
  * connect anywhere, so it works behind firewalls etc..
  * How ever since developement reached it's limits, I decided
  * to make it more flexible and make it work as an add-on for
  * PHPNuke and phpBB.
  *
  * This is GNU software
  */
?>
<? include "mlchat.conf" ?>
<? if($CLINES > 0 && $CLINES < 50) 
   {setcookie(MLChatAMMOUNT,$CLINES,time()+30*3600);}
?>
<HTML>
<BODY BGCOLOR="<? echo $ROUND_COL; ?>" TEXT="<? echo $ROUND_TEXT; ?>">
<FORM ACTION="mlchatleft.php">
<CENTER><INPUT TYPE=TEXT NAME=CLINES SIZE=2 VALUE=<? echo $MLChatAMMOUNT; ?>></CENTER><BR>
<CENTER><INPUT TYPE=SUBMIT VALUE="OK"></CENTER>
</BODY>
</HTML>
