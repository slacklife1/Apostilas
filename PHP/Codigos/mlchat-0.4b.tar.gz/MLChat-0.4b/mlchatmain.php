<?
 /* This is MLChat 0.4b by Major Lockup
  * 
  * A Web-Based Chat System. Was made to be a simple way to chat
  * in the web when only being able to see HTML. No need to
  * connect anywhere, so it works behind firewalls etc..
  * How ever since developement reached it's limits, I decided
  * to make it more flexible and make it work as an add-on for
  * PHPNuke and phpBB.
  *
  * This is GNU software
  */
?>
<? include "mlchat.conf" ?>
<? 
	if ($MLMODE == 0) {
		$XUiD = $MLChatVISITOR;
	}
	else {
		$XUiD = getmlchatuid();
	}
	if ($XUiD) {
		include "mlchatmain.inc";
	}
	else {
		include "mlchat.nologin";
	}
?>
