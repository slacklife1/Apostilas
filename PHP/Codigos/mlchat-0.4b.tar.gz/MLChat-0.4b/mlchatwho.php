<?
 /* This is MLChat 0.4b by Major Lockup
  * 
  * A Web-Based Chat System. Was made to be a simple way to chat
  * in the web when only being able to see HTML. No need to
  * connect anywhere, so it works behind firewalls etc..
  * How ever since developement reached it's limits, I decided
  * to make it more flexible and make it work as an add-on for
  * PHPNuke and phpBB.
  *
  * This is GNU software
  */
?>
<? include "mlchat.conf"; ?>
<HTML>
<HEAD>
<TITLE>MLChat <? echo $VeRSION; ?></TITLE>
</HEAD>
<BODY BGCOLOR="<? echo $INTRO_BG; ?>" TEXT="<? echo $INTRO_TEXT; ?>">
<CENTER><H1><? echo $TiTLE; ?></H1></CENTER>
<BR><BR>
<?
$ID=2;
if ($MLMODE == 0) {
	$VUiD = $MLChatVISITOR;
	if(!$VUiD) {
	echo "<CENTER>Please tell me your name below</CENTER><BR><BR>";
	echo "<FORM ACTION=mlchat.php method=post>";
	echo "<CENTER><INPUT TYPE=TEXT NAME=NNM></CENTER><BR><BR>";
	echo "<CENTER><INPUT TYPE=SUBMIT VALUE=Okay!></CENTER>";
	echo "</FORM>";
	}
	if($VUiD) {
	echo "<CENTER>You are $VUiD</CENTER><BR>";
	echo "<CENTER><FORM ACTION=mlchat.php method=post><INPUT TYPE=HIDDEN NAME=NNM VALUE=$VUiD><BR><BR><INPUT TYPE=SUBMIT VALUE=Okay!></FORM>";
	}
}
else {
	echo "<CENTER>YOU CAN'T LOGIN HERE!</CENTER>";
}
?>
<BR><CENTER><H5><A HREF="http://mlockup.insane.gr/mlchat">MLChat HomePage</A></H5></CENTER>
</BODY>
</HTML>
