<?
 /* This is MLChat 0.4b by Major Lockup
  * 
  * A Web-Based Chat System. Was made to be a simple way to chat
  * in the web when only being able to see HTML. No need to
  * connect anywhere, so it works behind firewalls etc..
  * How ever since developement reached it's limits, I decided
  * to make it more flexible and make it work as an add-on for
  * PHPNuke and phpBB.
  *
  * This is GNU software
  */
?>
<? include "mlchat.conf" ?>
<?
   if ($MLMODE != 0) {
	$UiD = getmlchatuid();
   }
   else {
	$UiD = $MLChatVISITOR;
   }
   if($REQ) {
        $DT=date("H:i", time());
        if ($UiD!="" && $UiD!=0) system("$EcHO '<FONT COLOR=\"$TEXT_TIME\" SIZE=1>($DT)</FONT> <FONT COLOR=\"$TEXT_RNICK\">*</FONT> <FONT COLOR=\"$TEXT_NICK\">$UiD</FONT> <FONT COLOR=\"$TEXT_COL\"> $REQ </FONT><BR>' >> $MLPATH");
   }
?>
<HTML>
<BODY BGCOLOR="<? echo $ROUND_COL; ?>" TEXT="<? echo $ROUND_TEXT; ?>">
<CENTER>
<FORM ACTION="mlchatact.php">
<INPUT TYPE=HIDDEN NAME=REQ VALUE="<? echo $SM1; ?>"> <INPUT TYPE=SUBMIT VALUE=":)">
</FORM>
<FORM ACTION="mlchatact.php">
<INPUT TYPE=HIDDEN NAME=REQ VALUE="<? echo $SM2; ?>"> <INPUT TYPE=SUBMIT VALUE=":(">
</FORM>
<FORM ACTION="mlchatact.php">
<INPUT TYPE=HIDDEN NAME=REQ VALUE="<? echo $SM3; ?>"> <INPUT TYPE=SUBMIT VALUE=":*">
</FORM>
<FORM ACTION="mlchatact.php">
<INPUT TYPE=HIDDEN NAME=REQ VALUE="<? echo $SM4; ?>"> <INPUT TYPE=SUBMIT VALUE="Y">
</FORM>
<FORM ACTION="mlchatact.php">
<INPUT TYPE=HIDDEN NAME=REQ VALUE="<? echo $SM5; ?>"> <INPUT TYPE=SUBMIT VALUE="N">
</FORM>
<FORM ACTION="mlchatact.php">
<INPUT TYPE=HIDDEN NAME=REQ VALUE="<? echo $SM6; ?>"> <INPUT TYPE=SUBMIT VALUE=".!">
</FORM>
</CENTER>
</BODY>
</HTML>
