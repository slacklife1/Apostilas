<?
 /* This is MLChat 0.4b by Major Lockup
  *
  * A Web-Based Chat System. Was made to be a simple way to chat
  * in the web when only being able to see HTML. No need to
  * connect anywhere, so it works behind firewalls etc..
  * How ever since developement reached it's limits, I decided
  * to make it more flexible and make it work as an add-on for
  * PHPNuke and phpBB.
  *
  * This is GNU software
  */
?>
<? 
   include "mlchat.conf"
?>
<?
   if($REQ) {
   if ($MLMODE != 0) {
        $UiD = getmlchatuid();
   }
   else {
        $UiD = $MLChatVISITOR;
   }
	$DT=date("H:i", time());
	if (!$ALLOWHTML) {
		$REQQ=str_replace("<", "", $REQ);
		$REQQ=str_replace(">", "", $REQQ);
		$REQQ=str_replace("'", "`", $REQQ);
		$REQQ=str_replace("\\", "", $REQQ);
	}
	if ($ALLOWHTML) {
		$REQQ=str_replace("'", "`", $REQ);
                $REQQ=str_replace("\\", "", $REQQ);
	}
	if ($UiD) system("$EcHO '<FONT COLOR=\"$TEXT_TIME\" SIZE=1>($DT)</FONT> <FONT COLOR=\"$TEXT_RNICK\">[</FONT><FONT COLOR=\"$TEXT_NICK\">$UiD</FONT><FONT COLOR=\"$TEXT_RNICK\">] </FONT><FONT COLOR=\"$TEXT_COL\"> $REQQ </FONT><BR>' >> $MLPATH"); 
   }
?>
<HTML>
<BODY BGCOLOR="<? echo $ROUND_COL; ?>" TEXT="<? echo $ROUND_TEXT; ?>">
<BR><CENTER><FORM ACTION="mlchatreq.php">
<INPUT TYPE=TEXT NAME=REQ size=<? echo $BOX_SIZE; ?> maxlength=400> <INPUT TYPE=SUBMIT VALUE="Say it!">
</FORM>
</CENTER>
</BODY>
</HTML>
