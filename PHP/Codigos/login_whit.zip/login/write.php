<html>
<head>
	<title>writing to the ducument....</title>
<META NAME="Author" CONTENT="Michael Torp Kaalund">
<META HTTP-EQUIV="Refresh" CONTENT="5; URL=index.php">
<META NAME="Title" CONTENT="gbook login">
<META NAME="Generator" CONTENT="Stone's WebWriter 3.5">
</head>	
<body>

<?
if($email == "line@ishot.dk"){
	$kode = md5("line");
	$name = "Line is hot";
}elseif($email == "shorty@ishot.dk"){
	$kode = md5("shorty");
	$name = "shorty";
}elseif($email == "user@user.dk"){
	$kode = md5("user");
	$name = "user";
}

$password = md5($password);

if($password == $kode){

	$fil = fopen("gbook.txt","r"); //open gbook.txt to read
	$tmp = fopen("temp.tmp","w"); //open temp.tmp to write

	while(!feof($fil)){
		$streng = fgets($fil, 10000); //opener the first 10.000 byte of gbook.txt
		fwrite($tmp, $streng); //writes all what there is standing in gbook.txt to temp.tmp
	}
	fclose($fil); //lukker $fil
	fclose($tmp); //lukker $tmp
	
	$file = fopen("gbook.txt","w"); //open gbook.txt to write
	$temp = fopen("temp.tmp","r"); //open temp.tmp to read

  fwrite($file, "Url: <a href=\"http:\\\\".$link."</a><br>E-Mail: <a href=\"mailto:".$email."\">".$name."</a><br>".$text."<br><br>\n"); //skrive i gbook.txt det lige har skrivet

	while(!feof($temp)){
		$streng = fgets($temp, 10000); //gets the first 10.000 byte of temp.tmp
		fwrite($file, $streng); // writer the first 10.000 byte or to "End Of Line" in gbook.txt
	}  

	fclose($file); //close $file
	fclose($temp); //close $temp

}else{
echo "You have writen the wrong password or e-mail"; // error
}
?>
</body>
</html>