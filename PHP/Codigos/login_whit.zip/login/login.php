<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
	<TITLE>[Login-script]</TITLE>
<META NAME="Author" CONTENT="Michael Torp Kaalund">
<META NAME="Title" CONTENT="gbook login script ">
<META NAME="Generator" CONTENT="Stone's WebWriter 3.5">
</HEAD>
<BODY>
<center>
<FORM ACTION="write.php" METHOD="post" NAME="gbook">
E-Mail:<BR>
<INPUT TYPE="text" MAXLENGTH="64" NAME="email"><BR>
PassWord:<BR>
<INPUT TYPE="password" NAME="password"><BR>
Link:<BR>
<INPUT TYPE="text" NAME="link"><BR>
msg:<BR>
<TEXTAREA WRAP="physical" ROWS="10" COLS="33" NAME="text"></TEXTAREA><BR>
<INPUT TYPE="submit" VALUE="Send"><BR>
</FORM>

<? include "gbook.txt"; ?>
<font size="1px">Made by <a href="mailto:torp_k@mail.tele.dk'">Michael Torp Kaalund</a> write in <a href="http://www.stoneware.dk" target="_blank">Stone's WebWriter 3.5</a></font>
</center>
</BODY>
</HTML>