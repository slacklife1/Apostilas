Files:
	login.php is the main file and the file you have to link to for your gbook
	write.php is the write file
	temp.tmp is a Temporary file
	gbook.txt is the who hold the text that have ben writen
	readme.txt is this file

~~~~~~~~~~~~~~||Made by Michael Torp Kaalund||~~~~~~~~~~~~~~
WARRANTY:
There is no warranty on this script what so ever.
The Author cannot be held responsible for any damaged.



README:

if($email == "line@ishot.dk"){ //here you write your e-mail.
	$kode = md5("line"); //the password is "line" you can just cange it "md5("your password");
	$name = "Line is hot";
}elseif($email == "shorty@ishot.dk"){ //if you are more that one person you can just change this
	$kode = md5("shorty");
	$name = "Shorty is hot";
}elseif($email == "user@user.dk"){ // this is just a user
	$kode = md5("user");
	$name = "user"
}




Temp.tmp and gbook.txt is all the time being overwriten....



~~~~~~~~~~~~~~||Version Beta 1.2||~~~~~~~~~~~~~~
some errors was change

~~~~~~~~~~~~~~||Version Beta 1.0||~~~~~~~~~~~~~~

This was made