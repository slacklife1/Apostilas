<HTML>
<BODY>
<?
require("function.php");
$txt = nl2br("Name: $name\nEmail: $email\nWebsite: <A HREF=\"$url\">$url</A>\nMessage: $message\n");
$num = openfile("inc.inc");
writetofile("$num.txt", $txt);
$num++;
$filenum = fopen("inc.inc","w");
fwrite($filenum, $num);
//flose($filenum);
?>
<P>

Please push your browsers back button, and click refresh to view
your entry.
</BODY>
</HTML>