<HTML>
<BODY>
<FORM NAME="gb" ACTION="add.php" METHOD="post">
Name: <INPUT TYPE="text" NAME="name"><BR>
Email: <INPUT TYPE="text" NAME="email"><BR>
Website: <INPUT TYPE="text" NAME="url"><BR>
Message: <BR>
<TEXTAREA NAME="message" COLS=20 ROWS=10></TEXTAREA><BR>
<INPUT TYPE="SUBMIT"> <P>
</FORM>
<?php
require("function.php");

$d = dir(".");
$i = 0;
while($entry=$d->read()) {
$f = substr($entry, strlen($entry) - 3);
if ($f == txt)
$arr[$i] = $entry;
$i++;
}
rsort($arr, SORT_NUMERIC);

for($j = 0; $j <= $i; $j++)
{
echo openfile($arr[$j]) . "<P>";
}
$d->close();
      

?>
</BODY>
</HTML>