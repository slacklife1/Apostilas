<?
function writetofile($file, $texttowrite) {
	$filenum = fopen($file,"a");
	fwrite($filenum,$texttowrite);
	fclose($filenum);
}

function openfile($path) {
    if(file_exists($path) == 0) {
        return "";
    }
    else
    {
        $thefilesize = filesize($path);
        $filenum = fopen($path,"r");
        $filecontent = fread($filenum, $thefilesize+1);
        fclose($filenum);
        return $filecontent;
    }
}
?>