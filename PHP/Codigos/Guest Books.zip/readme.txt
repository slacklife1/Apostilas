inc.inc is the file that keeps the current filenumber.
add.php adds the entry to the guesbook, index shows the entries,
and it also has the submit form.  function.php has the file i/o functions.


-Dennis Wrenn