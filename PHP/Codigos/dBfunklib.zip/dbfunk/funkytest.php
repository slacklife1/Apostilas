<?

// config
$dbhost = "localhost";
$db = $dbuser;
$dlbg = "yellow";
$adminsc = "dbfunctest.php";
$welcome = "<tr><td align=center width=276><b>Welcome to dBfuk(lib)</b>
 <p align=left>This is a simple database administration script written to demonstrate dBfunk(lib) functions.
 <p align=left>To use it , you need a valid MySQL server connection string (username, password, hostname, database).
 </p><p>&nbsp;</p></td></tr>";

// end config

if (!$dbuser) {
	
	if (isset($PHP_AUTH_USER)) {
		if (isset($PHP_AUTH_PW)) {
		$dbuser = $PHP_AUTH_USER;
		$dbpass = $PHP_AUTH_PW;
		$testid = @mysql_connect($dbhost, $PHP_AUTH_USER, $PHP_AUTH_PW);
		}
		else {
		$dbuser = $PHP_AUTH_USER;
		$testid = @mysql_connect($dbhost, $PHP_AUTH_USER);
		}
	}
	
		if ($testid) {
		setcookie("dbuser", "$dbuser");
		setcookie("dbpass", "$dbpass");
		Header("Location: $PHP_SELF\n\r");
		exit;
		}
		
else {
	Header("status: 401 Unauthorized");
    Header("HTTP/1.0 401 Unauthorized");
    Header("WWW-authenticate: basic realm=\"dBfunk(lib)\"");
    echo "<HTML><HEAD><TITLE>dBfunk() test script</TITLE></HEAD>\n";
    echo "<HTML><head><style>
A:hover
{
	color: brown;
	TEXT-DECORATION:underline
}
A
{
    COLOR: #000000;
    TEXT-DECORATION: none
}
td {     COLOR: #FFFFFF;
font-size: 12px;
font-family: arial;
}
th {     COLOR: #EEEEEE;
font-size: 11px;
font-family: verdana;
}
BODY { font-family: arial,helvetica; 
color: #FFFFFF ;
font-size: 12px;
}
</style>
</head><body bgcolor=#AAAAAA text=#FFFFFF link=#000000 vlink=#000000 alink=red><center><h1><i><font color=brown>dBfunk(<font color=$dlbg>lib</font>)</font></i>
</h1>Basic MySQL database function library<br><p><b>$today &nbsp; &nbsp; $thetime</b><h2>MySQL server access denied</H2>
    <h3>Bad login or password</h3>$welcome\n";
    echo "</CENTER></BODY></HTML>";
    exit;
}

}

include("dbfunk.php");

echo "<HTML><head><style>
A:hover
{
	color: brown;
	TEXT-DECORATION:underline
}
A
{
    COLOR: #000000;
    TEXT-DECORATION: none
}
td {     COLOR: #FFFFFF;
font-size: 12px;
font-family: arial;
}
th {     COLOR: #EEEEEE;
font-size: 11px;
font-family: verdana;
}
BODY { font-family: arial,helvetica; 
color: #FFFFFF ;
font-size: 12px;
}
</style>
</head><body bgcolor=#AAAAAA text=#FFFFFF link=#000000 vlink=#000000 alink=red><center><h1><i><font color=brown>dBfunk(<font color=$dlbg>lib</font>)</font></i>
</h1>Basic MySQL database function library<br><p><b>$today &nbsp; &nbsp; $thetime</b><p>";

echo "<p><hr size=1 color=$dlbg width=276><table border=0 cellspacing=0 cellpadding=0 align=center bordercolor=$dlbg width=600>
<tr><td><table border=0 cellspacing=0 cellpadding=2 align=center bordercolor=$dlbg width=276>";
echo "<tr><th align=left bgcolor=brown><font color=#dddddd>$db@$dbhost</font></th><td bgcolor=#dddddd align=right><a href=$PHP_SELF?act=list>List tables</a>&nbsp;</td></tr></table><hr size=1 color=$dlbg width=276><p align=center>";
echo "<form action=$PHP_SELF method=post><b>MetaSearch</b>: <input type=text name=search> <input type=submit value=Go></form>

<table border=1 cellspacing=0 cellpadding=2 align=center bordercolor=$dlbg>\n";
$copyr = "<font face=verdana size=-1>copyright &copy; 2001 <a href=mailto:wizekat@mac.com>Wizekat</A></font>";
 
 if ($act == "view") {
 $result = db_view($table);			// view table content
 }
 elseif ($act == "insfrm") {
 $result = db_add($table);			// insert form
 }
 elseif ($act == "Insert") {
 $result = db_ins($table,R);			// insert action
 }
 elseif ($act == "modif") {
 $result = db_form($table,$finame,$record);			// update form
 }
 elseif ($act == "Update") {
 $result = db_update($table,R);		// update action
 }
 elseif ($act == "del") {
 $result = db_del($table,$finame,$record);			// delete action
 }
 elseif($search) {
 $result = db_meta_search($search);					// search all tables
 }	
 elseif ($act == "list") {
 $result = db_list();					// list tables
 }
 elseif ($rawq && $sqlquery != "") {
 $result = db_rawq($sqlquery);					// run raw query
 }
 else {
$result = $welcome;
 }	
echo "$result";
echo "</table>";
echo "</td></tr></table><p align=center><form action=$PHP_SELF method=post><b>Type in a valid SQL query:</b><br>
<textarea name=sqlquery rows=3 cols=50></textarea>
<p align=center><input type=submit name=rawq value=\"Submit SQL query\"></form><hr size=1 color=$dlbg width=276><p>
<table border=1 cellspacing=0 cellpadding=2 align=center bordercolor=$dlbg>
<tr><td align=center width=276>$copyr</td></tr></table>";
echo "</center>";	

?>
