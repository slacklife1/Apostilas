<?
// dBfunk(lib)
// author: Jean-Marc Lelièvre
// wizekat@mac.com
//
// db functions 

function db_rawq($sqlquery) {
global $sid;
global $dbhost;
global $dbuser;
global $dbpass;
global $db;

if (!$sid) {
$sid = mysql_connect($dbhost, $dbuser,$dbpass);
mysql_select_db($db, $sid);
}

if ($reponse = mysql_query($sqlquery)) {
$fields = mysql_num_fields($reponse);

	while ($row = mysql_fetch_row($reponse)) {
	$sqlresult.= "<tr>";
		for ($i=0; $i < $fields; $i++) {
		$sqlresult.= "<td>$row[$i]</td>";
		}
	$sqlresult.= "</tr>";		
	}
$tbody = "<table>$sqlresult</table>";
}
else {
$tbody = "<p>&nbsp;</p><p><font size=+1>Query returned no result or bad query syntax.</font><p>&nbsp;</p>";
}
return $tbody;	
}	

function db_ins($table,$mode) {
// insert data, action
global $sid;
global $dbhost;
global $dbuser;
global $dbpass;
global $db;
global $table;
global $record;
global $adminsc;

if (!$sid) {
$sid = mysql_connect($dbhost, $dbuser,$dbpass);
mysql_select_db($db, $sid);
}
$query = "SELECT * FROM $table ";
$reponse = mysql_query($query);
$fields = mysql_num_fields($reponse);
$iqry.= "INSERT INTO $table VALUES ( ";
	for ($i=0; $i < $fields; $i++) {
	$finame = mysql_field_name($reponse, $i);
	$finame.= "F";
	global $$finame;
	eval ('$nvalue = $$finame;');
	$iqry.= "\"$nvalue\"";
	
		if ($i < ($fields-1)) {
		$iqry.= ", ";
		}
	}
$iqry.= ") ";

	if ($mode == "R") {
	$reponse = mysql_query($iqry, $sid);
		if ($reponse == 0) {
		$ins = "ERROR: no item added";
		}
		else {
		$ins = "New item added ! ";
		}
	}
	else {
	$ins = $iquery;
	}

	$tbody = "<tr><th width=276>$ins</td></tr>";

return $tbody;
}

function db_del($table,$finame,$record) {
// edit record content
global $sid;
global $dbhost;
global $dbuser;
global $dbpass;
global $db;
global $adminsc;
global $conf;
global $dlbg;

if (!$sid) {
$sid = mysql_connect($dbhost, $dbuser,$dbpass);
mysql_select_db($db, $sid);
}
eval ('$fld = $finame;');
$query = "DELETE FROM $table ";
$query.= "WHERE $fld = \"$record\" ";

if ($conf == 1) {
	$reponse = mysql_query($query);
		if ($reponse == 0) {
		$ins = "<p>&nbsp;</p><p><font size=+1>No item deleted !<br>
		<font size=+1>ERROR</font><hr size=16 width=100 color=red>";
		}
		else {
		$ins = "<p>&nbsp;</p><p><font size=+1>Item $record deleted !</font><p>&nbsp;</p>";
		}
	}
	else {
	$ins = "<p>&nbsp;</p><p><font size=+1>Delete record $record ?</font>
	<h3><a href=$adminsc?act=del&table=$table&finame=$finame&record=$record&conf=1>YES</A> &nbsp; &nbsp; <a href=javascript:history.back()>NO</A>
	<hr size=16 width=100 color=red></h3>";
	}

	$tbody = "<tr><th width=276>$ins</td></tr>";

return $tbody;
}

function db_update($table,$mode) {
// update data, action
global $sid;
global $dbhost;
global $dbuser;
global $dbpass;
global $db;
global $record;

if (!$sid) {
$sid = mysql_connect($dbhost, $dbuser,$dbpass);
mysql_select_db($db, $sid);
}

$query = "SELECT * FROM $table ";
$reponse = mysql_query($query);
$fields = mysql_num_fields($reponse);
$iqry.= "UPDATE $table SET ";
	for ($i=0; $i < $fields; $i++) {
	$finame = mysql_field_name($reponse, $i);
	$iqry.= "$finame = ";
	$finame = "F".$finame;
	global $$finame;
	eval ('$nvalue = $$finame;');
	$iqry.= "\"$nvalue\"";
	
		if ($i < ($fields-1)) {
		$iqry.= ", ";
		}
	}
$recid = mysql_field_name($reponse, 0);	
$iqry.= " WHERE $recid = \"$record\" ";

	if ($mode == "R") {
	$reponse = mysql_query($iqry, $sid);
		if ($reponse == 0) {
		$ins = "<p>&nbsp;</p><p><font size=+1>No item updated !<br>
		<font size=+1>ERROR</font><hr size=16 width=100 color=red>";
		}
		else {
		$ins = "<p>&nbsp;</p><p><font size=+1>Item $record updated !</font><p>&nbsp;</p>";
		}
	}
	else {
	$ins = $iquery;
	}
	$tbody = "<tr><th width=276>$ins</td></tr>";

return $tbody;
}

function db_view($table) {
// brows table content
global $sid;
global $dbhost;
global $dbuser;
global $dbpass;
global $db;
global $record;

if (!$sid) {
$sid = mysql_connect($dbhost, $dbuser,$dbpass);
mysql_select_db($db, $sid);
}

$query = "SELECT * FROM $table ";
$reponse = mysql_query($query);
$brd =1;
$vfrm ="";
$vfhd = "";
$fields = mysql_num_fields($reponse);
	while ($row = mysql_fetch_row($reponse)) {
	$vfrm.= "<tr>";
		for ($i=0; $i < $fields; $i++) {
		$vfrm.= "<td>$row[$i]&nbsp;</td>\n";
		}
	$fin = mysql_field_name($reponse, 0);
	$row[0] = urlencode($row[0]);
	$vfrm.= "<td align=center b><a href=$adminsc?tman=1&act=modif&table=$table&finame=$fin&record=$row[0]>Edit</A></td>
	<td align=center ><a href=$adminsc?tman=1&act=del&table=$table&finame=$fin&record=$row[0]>Delete</A></td>
	</tr>";
	}

// end browse content	
	
$tbody = "<form action=$adminsc method=post>
	<input type=hidden name=table value=$table>\n
	<input type=hidden name=tman value=1>
	<tr>$vfhd</tr>\n$vfrm";

return $tbody;	
}

function db_form($table,$finame,$record) {
// edit record content
global $sid;
global $dbhost;
global $dbuser;
global $dbpass;
global $db;
global $adminsc;
if (!$sid) {
$sid = mysql_connect($dbhost, $dbuser,$dbpass);
mysql_select_db($db, $sid);
}
eval ('$fld = $finame;');
$query = "SELECT * FROM $table ";
$query.= "WHERE $fld = \"$record\" ";
$brd =0;
$tbody ="<form action=$adminsc method=post>
	<input type=hidden name=table value=$table>\n
	<input type=hidden name=tman value=1>
	<input type=hidden name=record value=$record>";

$reponse = mysql_query($query);
	while ($row = mysql_fetch_row($reponse)) {
	$fields = mysql_num_fields($reponse);
	$tbody.= "<tr><td colspan=$fields>";
		for ($i=0; $i < $fields; $i++) {
		$fin = mysql_field_name($reponse, $i);
		$tbody.= "$fin: ";
		$fin = "F$fin";
		$tbody.= "<input type=text name=$fin value=\"$row[$i]\"><br>\n";
		}
	$tbody.= "<p><input type=submit name=act value=Update></td></tr>";
	}
return $tbody;	
}

function db_add($table) {
// add new record
global $sid;
global $dbhost;
global $dbuser;
global $dbpass;
global $db;
global $record;
global $adminsc;

if (!$sid) {
$sid = mysql_connect($dbhost, $dbuser,$dbpass);
mysql_select_db($db, $sid);
}

$query = "SELECT * FROM $table ";
$reponse = mysql_query($query);
$fields = mysql_num_fields($reponse);
$tbody.= "<tr><th align=left >$tablename</th>";
$i = 0;
$edtform = "<form action=$adminsc method=post>
	<input type=hidden name=table value=$table>\n
	<input type=hidden name=tman value=1>";
	
			while ($i < ($fields)) {
			$finame = mysql_field_name($reponse, $i);
			$fin = $finame;
			$fin.= "F";
			$edtform.= "$finame: <input type=text name=$fin><br>\n";
			$i++;
			}
	
// insert data, form
$tbody = "<tr><td colspan=3>$edtform
<p><input type=submit name=act value=Insert></td></tr>\n";	

return $tbody;	
}

function db_list() {
// list tables 
global $sid;
global $dbhost;
global $dbuser;
global $dbpass;
global $db;

if (!$sid) {
$sid = mysql_connect($dbhost, $dbuser,$dbpass);
mysql_select_db($db, $sid);
}

$tables = mysql_list_tables($db, $sid);
	while ($tbl = mysql_fetch_row($tables)) {
		$tablename = $tbl[0];
		$query = "SELECT * FROM $tbl[0] ";
		$reponse = mysql_query($query);
	
	$fields = mysql_num_fields($reponse);
	$tbody.= "<tr><th align=left >$tablename</th>";
	$i = 0;
	
	$select = "";
	$edtform = "<form action=$adminsc method=post>
	<input type=hidden name=table value=$table>\n
	<input type=hidden name=tman value=1>";
	
			while ($i < ($fields)) {
			$finame = mysql_field_name($reponse, $i);
			$fin = $finame;
			$fin.= "F";

			$select.= "<option value=$finame>$finame</option>\n";
			$edtform.= "$finame: <input type=text name=$fin><br>\n";
			$vfhd.= "<th><font size=-1>$finame</font></th>";
			$i++;
			}
	$vfhd.= "<th colspan=2><font size=-1>Action</font></th>";		
	$tbody.= "<td ><select name=search>$select</select></td>
	<th width=30 ><a href=$adminsc?tman=1&act=insfrm&table=$tbl[0]>Insert</A></th>
	<th width=30 ><a href=$adminsc?tman=1&act=view&table=$tbl[0]>View/edit</A></th>";
	$tbody.= "</tr>\n";
	
	}	// end while
	
	$tbody = "<tr><th align=left bgcolor=$dlbg><font size=-1>Tables</font></th>
	<th align=left bgcolor=$dlbg><font size=-1>Fields</font></th>
	<th colspan=2 bgcolor=$dlbg><font size=-1>Action</font></th></tr>$tbody";	

return $tbody;

}

function db_meta_search($search) {
// search all tables 
global $sid;
global $dbhost;
global $dbuser;
global $dbpass;
global $db;
global $dlbg;

if (!$sid) {
$sid = mysql_connect($dbhost, $dbuser,$dbpass);
mysql_select_db($db, $sid);
}

$tables = mysql_list_tables($db, $sid);
	while ($tbl = mysql_fetch_row($tables)) {
	$tablename = $tbl[0];
	$query = "SELECT * FROM $tbl[0] ";
	$reponse = mysql_query($query);
	$tbody.= "<li><b>$tablename</b><ul>";
	$fields = mysql_num_fields($reponse);
	$sname = mysql_field_name($reponse, 0);
	
	$qry = "SELECT $sname FROM $tablename ";
	$qry.= "WHERE $sname like \"%$search%\" ";

		for ($s=1; $s < $fields; $s++) {
		$finame = mysql_field_name($reponse, $s);
		$qry.= "OR $finame like \"%$search%\" ";
		}
		
	$sres = mysql_query($qry);
		while ($row = mysql_fetch_row($sres)) {
		$hits++;
			for ($i=0; $i < $fields; $i++) {
				if (eregi("$search", $row[$i], $match)) {
				$found = mysql_field_name($reponse, $i);
				}
				else {
					$found = $row[0];
				}
			}
			
			$row[0] = urlencode($row[0]);
		$tbody.= "<li>$hits <a href=$adminsc?table=$tablename&act=modif&finame=$sname&record=$row[0]>$found</a>";
		}


 $tbody.= "</ul><hr size=1 color=$dlbg>";
	}	// end while
	
	$tbody = "<tr><th align=left><font size=-1>MetaSearch Results for <i>$search</i></font></th></tr><tr>
	<td align=left valign=top><font size=-1><ul>$tbody</ul></font></td></tr>";	

return $tbody;

}

$today = date("D");
$today.= "  ";
$today.= date("F");
$today.= "  ";
$today.= date("d");
$today.= "  ";
$today.= date("Y");

$thetime = date("H");
$thetime.= ":";
$thetime.= date("i");
$thetime.= ":";
$thetime.= date("s");
$thetime.= " CET";

?>

