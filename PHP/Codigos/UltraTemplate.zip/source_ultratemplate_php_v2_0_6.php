<?php
/*
  NAME:	ULTRATEMPLATE CLASS 2.0.6
  BY:	CHRISTOPHER BROWN-FLOYD
  DATE:	March 24, 2002
  SITE: http://www.ultratemplate.com/
  EMAIL LIST: ultratemplate-list@bfworld.com
*/
class UltraTemplate
{
	var $lefttag = Array("<tag:","<template:");
	var $righttag = Array("/","</template:");
	var $_TEMPLATES_ = Array("");
	var $global_vars = "";
	var $global_var_list = "";
	var $currenttagname = "";
	var $processingtemplate = false;

	function UltraTemplate()
	{
		if (!defined("DATATAG"))
		{
			define("DATATAG",0);
			define("TEMPLATETAG",1);
			define("NEWLINE","\r\n");
			define("TABCHAR",chr(9));
			define("HIDDENCHAR",chr(1));
			define("NOTAG",3);
			define("NORMALTAG",2);
			define("COMPOUNDTAG",1);
		}
	}




	function tag($tagname,$tagvalue)
	{
		$templatepointer = &$this->currenttemplate;
		$lefttag = $this->lefttag[DATATAG].$tagname;
		$lefttaglen = strlen($lefttag);
		$templates = &$this->_TEMPLATES_;
		$lefttagend = 0;
		$this->currenttagname = &$tagname;
		eval($this->global_vars);

		while ($lefttagend >=0 && is_integer(strpos($templatepointer,$lefttag,$lefttagend)))
		{
			$tagstart = strpos($templatepointer,$lefttag,$lefttagend);
			$lefttagend = $this->get_tag_end($tagstart+$lefttaglen);
			$tnstart = strpos($templatepointer,":",$tagstart)+1;
			$tntest = $this->get_tag_name(&$tnstart);
			
			if ($tntest == $tagname)
			{
				$condition = $this->get_condition(&$tagstart,&$lefttagend);
				if ($condition)
				{
					$as = $this->get_parameter("as",&$tagstart,&$lefttagend);
					$template = $this->get_parameter("template",&$tagstart,&$lefttagend);
					$falseValue = $this->get_parameter("falseValue",&$tagstart,&$lefttagend);
					$defaultValue = $this->get_parameter("defaultValue",&$tagstart,&$lefttagend);
					$label = $this->get_parameter("label",&$tagstart,&$lefttagend);
					$src = $this->get_parameter("src",&$tagstart,&$lefttagend);
					if (substr($template,0,4)=="tpl:")
					{
						if (!IsSet($templates[substr($template,4)]))
						{
							if (!$this->parse_subtemplate(substr($template,4)))
								die("<b>Error: No template.</b><br />(Tag: $tagname)");
						}
						$template = &$templates[substr($template,4)];
					}
					else if (!is_null($template))
					{
						$template = $this->fetch($template);
					}
					switch($as)
					{
					case "img":
					case "hr":
					case "br":
					case "input":
						$tagtype = COMPOUNDTAG;
						break;
					case "label":
						$as="span";
						break;
					case "panel":
						$as="div";
						break;
					case "link":
						$as="a";
						break;
					case "banner":
						$as=null;
						$this->get_current_banner(&$tagvalue);
						break;
					case "repeater":
						$as=null;
						$repeater = new UltraRepeater();
						$repeater->id = $tagname;
						$repeater->template = $template;
						$repeater->saveDataStore(&$tagvalue);
						$repeater->execute();
						$tagvalue = &$repeater->output;
						
					}
					if (!IsSet($tagtype))
						$tagtype = (is_null($as))?(NOTAG):(NORMALTAG);
					$tag = substr($templatepointer,$tagstart+$lefttaglen,$lefttagend-($tagstart+$lefttaglen));
					$this->remove_whitespace(&$tag);
					
					switch($tagtype)
					{
					case COMPOUNDTAG:
						switch ($as)
						{
						case "img":
							$output = "<$as src=\"$tagvalue".trim("\" $tag")." />";
							break 2;
						case "input":
							$output = "<$as onClick=\"$tagvalue\" value=\"$label".trim("\" $tag")." />";
							break 2;
						default:
							$output = "<".trim("$as $tag")." />";
							break 2;
						}
					case NORMALTAG:
						switch($as)
						{
						case "a":
							$output = "<$as href=\"$tagvalue".trim("\" $tag").">$label</a>";
							break 2;
						case "jsbutton":
							$output = "<input type=\"button\" value=\"$label\" onClick=\"$tagvalue".trim("\" $tag").">";
							break 2;
						case "imgbutton":
							$output = "<a href=\"$tagvalue\"><img src=\"$src".trim("\" $tag")."></a>";
							break 2;
						case "jsimgbutton":
							$output = "<a href=\"javascript:$tagvalue\"><img src=\"$src".trim("\" $tag")."></a>";
							break 2;
						default:
							$output = "<".trim("$as $tag").">$tagvalue</$as>";
							break 2;
						}
					case NOTAG:
						if (!IsSet($repeater) && !is_null($template))
						{
							$output = str_replace("\$field(0)",$tagvalue,$template);
						}
						else
						{
							$output = $tagvalue;
						}
						break;
					}
				$this->remove_tag(&$tagstart,&$lefttagend,&$output);
				$repeater = null;
				}
			}
		}
	}




	function parse_subtemplate($templatename)
	{
		$templatepointer = &$this->currenttemplate;
		$lefttag = $this->lefttag[TEMPLATETAG].$templatename;
		$righttag = $this->righttag[TEMPLATETAG].$templatename.">";
		$lefttaglen = strlen($lefttag);
		$templates = &$this->_TEMPLATES_;
		$gottemplate = false;
		$righttagend = 0;
		$this->processingtemplate = true;
		
		while ($righttagend >= 0 && $righttagend <= strlen($templatepointer) && is_integer(strpos($templatepointer,$lefttag,$righttagend)))
		{
			$templatestart = strpos($templatepointer,$lefttag,$righttagend);
			$templateend = strpos($templatepointer,$righttag,$templatestart);
			if (is_bool($templateend))
				break;
			$righttagend = strpos($templatepointer,">",$templateend);
			$lefttagend = $this->get_tag_end($templatestart+$lefttaglen);
			$tntest = strpos($templatepointer,":",$templatestart)+1;
			$tnname = $this->get_tag_name($tntest);
			if ($tnname == $templatename)
			{
				$righttagrem = $righttagend;
				$condition = $this->get_condition(&$templatestart,&$lefttagend);
				$templateend -= ($righttagrem-$righttagend);
				$lefttagend -= ($righttagrem-$righttagend);
				if (!$condition)
				{
					$this->remove_tag(&$templatestart,&$righttagend);
				}
				else
				{
					$templates[$templatename] = ($lefttagend != ($templateend-1))?(substr($templatepointer,$lefttagend+1,$templateend-$lefttagend-1)):("");
					$this->remove_tag(&$templatestart,&$righttagend);
					$gottemplate = true;
				}
			}
		}
		return $gottemplate;
	}




	function get_condition($start,$end)
	{
		eval($this->global_vars);
		$condition = $this->get_parameter("if",&$start,&$end);
		if (is_null($condition))
			return true;
		$condition = "\$condition = ($condition);";
		eval($condition);
		return $condition;
	}




	function get_parameter($paramname,$start,$end)
	{
		$templatepointer = &$this->currenttemplate;
		$ppos = strpos($templatepointer,$paramname."=",$start);
		if ($ppos>=$end || is_bool($ppos))
			return null;
		$vpos = strpos($templatepointer,"\"",$ppos)+1;
		for ($counter = $vpos;$counter <= $end;$counter++)
		{
			$char = substr($templatepointer,$counter,1);
			switch($char)
			{
			case "\"":
				break 2;
			case "\\":
				$counter++;
				break;
			}
		}
		$parameter = substr($templatepointer,$vpos,$counter-$vpos);
		$templatepointer = substr_replace($templatepointer,"",$ppos,($counter-$ppos)+1);
		$end -= ($counter-$ppos)+1;
		return stripslashes($parameter);
	}




	function exec_parameter($paramname,$start,$end)
	{
		$paramValue = $this->get_parameter(&$paramname,&$start,&$end);
		$templates = &$this->_TEMPLATES_;

		eval($this->global_vars);
		if (substr($paramValue,0,5)=="file:")
			$paramValue = $this->fetch(substr($paramValue,5));
		if (substr($paramValue,0,1)=="$")
		{
			eval("\$paramValue = &$".substr($paramValue,1).";");
		}
		else if (substr($paramValue,0,1)=="!")
		{
			eval("\$paramValue = ".substr($paramValue,1).";");
		}
		else if (substr($paramValue,0,1)=="#")
		{
			eval("\$paramValue = &$".substr($paramValue,1).";");
			$setarray=false;
			while ($row=mysql_fetch_row($paramValue)) {
				$atagvalue[] = $row;
				$setarray=true;
			}
			$paramValue = ($setarray)?($atagvalue):(null);
		}
		else if (substr($paramValue,0,4)=="tpl:")
		{
			if (!IsSet($templates[substr($paramValue,4)]))
			{
				if (!$this->parse_subtemplate(substr($paramValue,4)))
					die("<b>Error: No inline template \"".substr($paramValue,4)."\" for parameter \"$paramname\" to include.</b><br />(Tag: ".$this->currenttagname.")");
			}
			$osubtemplate = new UltraTemplate();
			$osubtemplate->currenttemplate=&$templates[substr($paramValue,4)];
			$osubtemplate->setGlobalVars($this->global_var_list);
			$osubtemplate->bind();
			$templates[substr($paramValue,4)] = $osubtemplate->currenttemplate;
			$paramValue = &$templates[substr($paramValue,4)];
		}
		return $paramValue;
	}




	function get_tag_end($startpos)
	{
		$in_parameter = false;
		$templatepointer = &$this->currenttemplate;
		$templatelen = strlen($templatepointer);
		
		for ($counter = $startpos;$counter <= $templatelen;$counter++)
		{
			$char = substr($templatepointer,$counter,1);
			switch($char)
			{
			case ">":
				if ($in_parameter)
					break;
				return $counter;
			case "\"":
				$in_parameter = !$in_parameter;
				break;
			case "\\":
				$counter++;
				break;
			}
		}
		return false;
	}




	function remove_tag($start,$end,$output="")
	{
		$templatepointer = &$this->currenttemplate;
		$templatepointer = substr_replace($templatepointer,$output,$start,($end-$start)+1);
		$end -= ($end-$start)+1;
	}




	function remove_templates()
	{
		$templatepointer = &$this->currenttemplate;
		
		while (!is_bool(strpos($templatepointer,$this->lefttag[TEMPLATETAG])))
		{
			$leftpos = strpos($templatepointer,$this->lefttag[TEMPLATETAG]);
			$templatename = $this->get_tag_name($leftpos+strlen($this->lefttag[TEMPLATETAG]));
			
			$rightpos = strpos($templatepointer,$this->righttag[TEMPLATETAG].$templatename.">");
			if (!is_bool($rightpos))
				$rightpos = $rightpos+strlen($this->righttag[TEMPLATETAG].$templatename.">");
			$templatepointer = substr_replace($templatepointer,"",$leftpos,($rightpos-$leftpos)+1);
		}
	}




	function remove_whitespace($tagpointer)
	{
		$tagpointer = str_replace(NEWLINE,HIDDENCHAR,$tagpointer);
		$tagpointer = str_replace(TABCHAR,HIDDENCHAR,$tagpointer);
		$tagpointer = ereg_replace(HIDDENCHAR."+"," ",$tagpointer);
		$tagpointer = trim($tagpointer);
		
		$tagpointer = preg_replace("/\/$/","",$tagpointer);
	}




	function bind()
	{
		eval($this->global_vars);
		$templatepointer = &$this->currenttemplate;
		$lefttag = $this->lefttag[DATATAG];
		$lefttaglen = strlen($lefttag);
		$lefttagend = 0;
		
		while (is_integer(strpos($templatepointer,$lefttag,$lefttagend)))
		{
			$tagstart = strpos($templatepointer,$lefttag);
			$lefttagend = $this->get_tag_end($tagstart+$lefttaglen);
			$tagname = $this->get_tag_name($tagstart+$lefttaglen);
			$this->currenttagname = &$tagname;
			$condition = $this->get_condition(&$tagstart,&$lefttagend);
			if (!$condition)
			{
				$falseValue = $this->exec_parameter("falseValue",&$tagstart,&$lefttagend);
				if (is_null($falseValue))
					$this->remove_tag(&$tagstart,&$lefttagend);
				$tagvalue = &$falseValue;
				$this->tag(&$tagname,&$tagvalue);
			}
			else
			{
				$defaultValue = $this->exec_parameter("defaultValue",&$tagstart,&$lefttagend);
				$tagvalue = &$defaultValue;
				$this->tag(&$tagname,&$tagvalue);
			}
		}
		$this->remove_templates();
	}




	function get_tag_name($start)
	{
		$templatepointer = &$this->currenttemplate;
		$end = $start;
		$asc = ord(substr($templatepointer,$start,1));
		while (($asc >= 65 && $asc <= 90) || ($asc >= 97 && $asc <= 122) || ($asc >= 48 && $asc <= 57) || $asc == 95 || $asc == 45 || $asc == 46)
		{
			$end++;
			$asc = ord(substr($templatepointer,$end,1));
		}
		$tagname = substr($templatepointer,$start,$end-$start);
		return $tagname;
	}




 	//Loads a file into the template processor
	function load($path)
 	{
  		$this->currenttemplate = $this->fetch($path);
 	}




 	//Returns a file as a string
 	function fetch($path)
 	{
  		$template = "";
  		$READFILE = "r";
  		if (file_exists($path))
  		{
   			$fp = fopen($path,$READFILE);
   			if (!feof($fp))
   			{
    				$template = fread($fp,filesize($path));
   			}
   			fclose($fp);
  		}
  		return $template;
 	}




	 //display the template
	 function display()
	 {
	 	echo($this->currenttemplate);
	 }




	//Saves the current template
	function saveas($path)
	{
		$WRITEFILE = "w";
		$fp = fopen($path,$WRITEFILE);
		$fout = fwrite($fp,$this->currenttemplate);
		fclose($fp);
	}




	//Append the current template to the specified file
	function appendto($path)
	{
		$APPENDFILE = "a";
		$fp = fopen($path,$APPENDFILE);
		$fout = fwrite($fp,$this->currenttemplate);
		fclose($fp);
	}




	//Sets global variables for use in the template
	function setGlobalVars($vars)
	{
		$this->global_vars = "global \$" . str_replace(",",",\$",$vars) . ";";
		$this->global_var_list = $vars;
	}




	function get_current_banner($banners)
	{
		$banners = trim($banners);
		if ($banners == "")
			return;
		$banners = str_replace("\r\n","\r",$banners);
		$banners = preg_replace("/<\/banner>[^<>]*<banner>/s","</banner>",$banners);
		$banners = preg_replace("/<banner>[^a-z]*/si","",$banners);
		$banners = preg_replace("/<\/banner>$/s","",$banners);
		$bannerarray = explode("</banner>",$banners);
		$current = 0;
		if (sizeof($bannerarray)>1)
			(int) $current = rand(0,sizeof($bannerarray)-1);
		$currentbanner = trim($bannerarray[$current]);
		$banneroptions = explode("\r",$currentbanner);
		$href = trim($banneroptions[0]);
		$image = trim($banneroptions[1]);
		$alt = trim($banneroptions[2]);
		$banners = "<a href=\"$href\"><img src=\"$image\" alt=\"$alt\" border=\"0\" /></a>";
	}
}




class UltraRepeater {

 var $id="table1";
 var $output="";
 var $template="";
 var $columndelimiter=",";
 var $rowdelimiter="\r\n";
 var $rows=0;
 var $columns=0;
 var $pagesize=0;
 var $page=0;
 var $datastore="";
 var $rowselect=0;
 var $columnselect=0;

 function saveDataStore($data) {
  if ($data==null || $data=="") {$this->datastore=null;return;}
  if (!is_array($data)) {
   $data = explode($this->rowdelimiter,$data);
   $atempdata = explode($this->columndelimiter,$data[0]);
   $ub2 = (is_array($atempdata))?(sizeof($atempdata)):(0);
   while ($row=each($data)) {
    $tempdata[] = explode($this->columndelimiter,$row[1]);
   }
  } else {
   $tempdata = $data;
  }
  $this->rows = sizeof($tempdata);
  $this->columns = sizeof($tempdata[0]);

  $this->datastore = $tempdata;
 }

 function mergeData() {
  $i=0;
  $j=0;
  $temptemplate="";
  $tempdata="";
  $rowcount=0;
  $rowselect=0;
  $rowtype[0]="evenrow";
  $rowtype[1]="oddrow";

  if (($this->datastore==null) || ($this->datastore=="")) {return "";}

  if ($this->template=="") {
   $tempdata = $this->makeTable();
  } else {
   $rowselect = 0;
   $columnselect = 0;
   if ($this->pagesize<1) {
    $this->pagesize=$this->rows;
    $top=0;
   } else {
    $top=($this->page>1)?(($this->page*$this->pagesize)-$this->pagesize):(0);
    $top=($top<0)?(0):($top);
   }
   for ($i=$top;$i<=$top+$this->pagesize-1;$i++) {
    $temptemplate = $this->template;
    for ($j=0;$j<=$this->columns-1;$j++) {
     $temptemplate = str_replace("\$field($j)",$this->datastore[$i][$j],$temptemplate);
    }
    $temptemplate = str_replace("\$rowtype",$this->id."_".$rowtype[$rowselect],$temptemplate);
    $temptemplate = str_replace("\$rownumber",$rowcount,$temptemplate);

    $tempdata .= $temptemplate;
    $rowselect = 1 ^ $rowselect;
    $rowcount++;
    if (($rowcount==$this->pagesize) || ($top+$rowcount==$this->rows)) {break;}
   }
  }
  return $tempdata;
 }

 function makeTable() {
  $rowcount=0;
  $rowselect=0;
  $rowtype[0]="evenrow";
  $rowtype[1]="oddrow";
  $columnselect=0;
  $columntype[0]="evencolumn";
  $columntype[1]="oddcolumn";

  if ($this->pagesize<1) {
   $this->pagesize=$this->rows;
   $top=0;
  } else {
   $top=($this->page>1)?(($this->page*$this->pagesize)-$this->pagesize):(0);
   $top=($top<0)?(0):($top);
  }

  $tempdata = "<table id=\"$this->id\">";

  for ($i=$top;$i<=$top+$this->pagesize-1;$i++) {
   $tempdata .= "<tr id=\"$this->id"."_row$i\" class=\"$this->id"."_"."$rowtype[$rowselect]\">";
   for ($j=0;$j<=$this->columns-1;$j++) {
    $tempdata .= "<td id=\"$this->id"."_column$j\" class=\"$this->id"."_$columntype[$rowselect]\">" . $this->datastore[$i][$j] . "</td>";
   }
   $tempdata.="</tr>";
   $rowselect = 1 ^ $rowselect;
   $rowcount++;
   if (($rowcount==$this->pagesize) || ($top+$rowcount==$this->rows)) {break;}
  }
  return $tempdata."</table>";
 }

 function execute() {
  $this->output = $this->mergeData();
 }
}
?>
