Title: UltraTemplate 2.0.6
Description: UltraTemplate (www.ultratemplate.com) is a class that allows you to separate your code (PHP or ASP) from your html content.
Unlike most other template processors, UltraTemplate has built-in dynamic functionality. Too often with
other template processors you'll find yourself writing loop code to build <option> tags or even
worse, having to specify every single tag that you need to update in your code. With UltraTemplate tags, you can specify a default value, what type of HTML tag you want the tag to be rendered as, a false value if a certain condition is not true, and using the built-in repeater, UltraTemplate can build you tables or repeat blocks of HTML code for each row from an array or row from data return from mySQL.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=591&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
