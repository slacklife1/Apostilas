<HTML>

<HEAD>
  <TITLE></TITLE>
  <META name="description" content="">
  <META name="keywords" content="">
  <META name="revisit-after" content="7days">
  <META name="robots" content="index, follow"> 

  <style type="text/css">
<!--
     A:link {text-decoration: none;}
     A:visited {text-decoration: none;}
     A:hover {text-decoration: underline;}
-->
</style>


</HEAD>

<BODY BGCOLOR="FFFFFF" TEXT="000000" LINK="0000FF" VLINK="0000FF">



<TABLE BORDER=0 WIDTH=98% CELLPADDING=2 CELLSPACING=2 ALIGN=CENTER BGCOLOR="#000000">
<TR BGCOLOR=#0A0089 Height=60><TD colspan=7>
<CENTER>

</cENTER>
</TD></TR>

<TR BGCOLOR=#000000>

<TD BGCOLOR=5B5C5C align="center">
<a HREF="index.htm"><font size="2" face="verdana,arial,helvetica" color="white"><b>Home</b></font></a>
</TD>
<TD BGCOLOR=5B5C5C align="center">
<a HREF="examples.htm"><font size="2" face="verdana,arial,helvetica" color="white"><b>Examples</b></font></a>
</TD>
<TD BGCOLOR=5B5C5C align="center">
<a HREF="tutorials.htm"><font size="2" face="verdana,arial,helvetica" color="white"><b>Tutorials</b></font></a>
</TD>
<TD BGCOLOR=5B5C5C align="center">
<a HREF="downloads.htm"><font size="2" face="verdana,arial,helvetica" color="white"><b>Download</b></font></a>
</TD>
<TD BGCOLOR=5B5C5C align="center">
<a HREF="books.htm"><font size="2" face="verdana,arial,helvetica" color="white"><b>Books</b></font></a>
</TD>
<TD BGCOLOR=5B5C5C align="center">
<CENTER><a HREF="links.htm"><FONT SIZE=2 FACE="verdana,arial,helvetica" color=white><B>Links</B></FONT></a> </cENTER>
</TD>
<TD BGCOLOR=5B5C5C align="center">
<a HREF="mailto:iainhendry@lineone.net"><font size="2" face="verdana,arial,helvetica" color="white"><b>contact</b></font></a>
</TD>
</TR>

<TR BGCOLOR=#000000 Height=25><TD colspan=7>
<CENTER>&nbsp;</cENTER>
</TD></TABLE>






<TABLE BORDER=0 WIDTH=98% ALIGN=CENTER>
<TR>

    <TD VALIGN=top Width=75%> <BR>
      <BR>
     <?php
	 //open our file
	 $fp = fopen("ffalinks.txt" , "a+");
	 //add details from form
	 fputs($fp ,"<b><a href=\"$url\" target=\"_blank\">$url</a></b><br>$desc<br>");
	 //close file
	 fclose($fp);  
	 //display message and link
	 echo ("Thanks for adding your link ");
	 echo ("<a href='ffalinksshow.php'>View FFA links</a>");
	 ?>
	 
      <BR>
  	 
	  <BR>



</TD>

<TD VALIGN=top width=20%>
<p align="center">
<CENTER><FONT><B>Sponsors</B></FONT></CENTER></p>
<p align="center"><BR>

<FONT SIZE=2>

<BR><BR>

</FONT>


</p>


</TD>

</TABLE>



<CENTER>
<FONT SIZE=2>
� 2001 http://www.myscripting.com</FONT></cENTER>
</BODY>
</HTML> 

