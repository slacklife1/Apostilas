---------------------------------------------
* Trumedia free for all links by Galen Grover
---------------------------------------------

1. Upload all files.
2. CHMOD links.dat to 666.
3. Open index.php in your browser.

NOTE: Edit the CSS to change the look of the page

-------------------
* File Descriptions
-------------------
confirm.php - HTML template to confirm the link
form.tpl    - HTML template of the add link form
header.tpl  - HTML template of the header
index.php   - Main file
library.inc - Functions and defines
links.dat   - File to hold the links

-----------------------------------------------
* Any questions email me at galengrover@msn.com
-----------------------------------------------
------------------------------------------------
* Visit my website at http://trumedia.gyrate.org
------------------------------------------------
