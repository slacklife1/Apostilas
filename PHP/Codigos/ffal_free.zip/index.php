<?php

//** Include library
include("library.inc");

//** Shorten names
$name = $website_name;
$url = $website_url;

//** If confirmed from confirm.php then write to file
if ($confirm)
{

	//** Create website link
	$website_link = " <a href=\"" . $confirm_website_url . "\">" . $confirm_website_name . "</a> ";

	//** Append link to file
	$file_pointer = fopen(DATA_FILE, "a");
	fwrite($file_pointer, $website_link . "<br>\n");
	fclose($file_pointer);
	
}

//** Both variables are empty so show main page
if ($name == "" && $url == "")
{

	include("header.tpl");
	include("form.tpl");

	//** Display links and exit
	$file_pointer = fopen(DATA_FILE, "r");
	$file_contents = fread($file_pointer, filesize(DATA_FILE));
	fclose($file_pointer);
	link_table($file_contents);
	exit;

}

//** If name field not filled out
elseif ($name == "" && $url !== "")

	error("You must enter a website name.");

//** If url field not filled out
elseif ($url == "" && $name !== "")

	error("You enter a website URL.");

//** If < or > found in name
elseif (check_for_html($name))

	error("Invalid character < or > in website name.");

//** If < or > found in url
elseif (check_for_html($name))

	error("Invalid character < or > in website URL.");

//** If invalid url
elseif (strrpos($url, "http://") !== 0 || !strstr($url, "."))

	error("Invalid website URL");

//** Check for long url
elseif (strlen($url) > 100)

	error("Website Url contains too many characters. 99 characters max.");

//** Check for long name
elseif (strlen($name) > 35)

	error("Website name contains too many characters. 35 characters max.");

//** If show confirm from form.tpl
elseif($show_confirm)
{

	//** Check for existance of link in data file if so give error
	$file_pointer = fopen(DATA_FILE, "r");
	$file_contents = fread($file_pointer, DATA_FILE);
	fclose($file_pointer);
	
	if (strrpos($file_contents, $url) > 0 || strrpos($file_contents, $name) > 0)
	{

		error("That link already in the data file");
		exit;

	}
	
	include("header.tpl");
	include ("confirm.php");
	exit;

}

?>