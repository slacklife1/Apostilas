<center>
<table cellspacing="1" cellpadding="3" bgcolor="#000000">
	<tr>
		<td class="header">
		
			<b>Confirm Link...</b>
			
		</td>
	</tr>
		<td class="content">
			<table cellpadding="0">
				<tr>
					<td class="content" align="right">
					
						<b>Website Name: </b>
						
					</td>
					<td class="content">
					
						<?php echo $name ?>
						
					</td>
				</tr>
				<tr>
					<td class="content" align="right">
					
						<b>Website URL: </b>
						
					</td>
					<td class="content">
					
						<?php echo $url ?>
						
					</td>
				</tr>
				<tr>
					<td class="content">
					</td>
					<td align="right">

						<form action="" method="post">
						<input type="hidden" name="confirm" value="TRUE">
						<input type="hidden" name="confirm_website_name" value="<?php echo $name ?>">
						<input type="hidden" name="confirm_website_url" value="<?php echo $url ?>">
						<input type="submit" value="Confirm Link" class="submit">
						
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>









