<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	footer.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	Closes off remaining, open HTML tags.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/
?>
			<table border="1" cellspacing="1" cellpadding="1" width="90%">
				<tr>
					<td width="100%" align="center" valign="center">
						<font size="1">
							<!-- This copyright MUST remain //-->
							Powered by <a href="http://www.fubonis.com/fubook" target="fubook">FuBook</a>
						</font>
					</td>
				</tr>
			</table>
		</center>
	</body>
</html>