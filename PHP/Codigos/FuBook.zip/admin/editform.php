<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	editform.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	The HTML form for editing the specified entry.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/

require("auth.php");

if(!$HTTP_GET_VARS[id]){
	$title = "No Edit ID";
	include("header.php");
	echo "\n		$title\n";
	include("footer.php");
	exit;
}
$title = "Editing Entry ID:  $id";
include("header.php");
$HTTP_GET_VARS[id] = intval($HTTP_GET_VARS[id]);
include("../config.php");
mysql_connect($sqlhost,$sqluser,$sqlpass);
mysql_select_db($sqldb);
$sql = "SELECT * FROM fubook_entries WHERE eid=$HTTP_GET_VARS[id]";
$result = mysql_query($sql);
$r = mysql_fetch_row($result);
?>
		<form action="editentry.php" method="post">
		<table border="1" cellspacing="1" cellpadding="1" width="90%">
			<tr>
				<td width="25%" align="left" valign="top">
					ID #:
				</td>
				<td width="75%" align="left" valign="top">
					<?=$r[0]?>
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="top">
					Name:
				</td>
				<td width="75%" align="left" valign="top">
					<input type="text" name="name" value="<?=$r[1]?>">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="top">
					Message:
				</td>
				<td width="75%" align="left" valign="top">
					<textarea name="msg" rows="5" cols="51"><?=$r[2]?></textarea>
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="top">
					Date/Time:
				</td>
				<td width="75%" align="left" valign="top">
					<?=$r[3]?>
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="top">
					IP:
				</td>
				<td width="75%" align="left" valign="top">
					<?=$r[4]?>
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="top">
					E-Mail:
				</td>
				<td width="75%" align="left" valign="top">
					<input type="text" name="email" value="<?=$r[5]?>">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="top">
					Link:
				</td>
				<td width="75%" align="left" valign="top">
					<input type="text" name="www" value="<?=$r[6]?>">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="top">
					AIM:
				</td>
				<td width="75%" align="left" valign="top">
					<input type="text" name="aim" value="<?=$r[7]?>">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="top">
					ICQ:
				</td>
				<td width="75%" align="left" valign="top">
					<input type="text" name="icq" value="<?=$r[8]?>">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="top">
					MSN:
				</td>
				<td width="75%" align="left" valign="top">
					<input type="text" name="msn" value="<?=$r[9]?>">
				</td>
			</tr>
			<tr>
				<td colspan="2" align="center" valign="center">
					<input type="submit" name="submit" value="Edit"> | 
					<input type="reset" value="Restore">
					<input type="hidden" name="eid" value="<?=$r[0]?>">
				</td>
			</tr>
		</table>
		</form>
<?php
include("footer.php");
mysql_close();
?>