<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	editadminform.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	The HTML form for editing the specified admin's info.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/

if((!$PHP_AUTH_USER) || (!$PHP_AUTH_PW)){
	$title = "No Username and/or";
	include("header.php");
	echo "\n		$title\n";
	include("footer.php");
	exit;
}
include("../config.php");
mysql_connect($sqlhost,$sqluser,$sqlpass);
mysql_select_db($sqldb);
$sql = "SELECT * FROM fubook_admin WHERE (user='$PHP_AUTH_USER') AND (pass='$PHP_AUTH_PW')";
$result = mysql_query($sql) or die(mysql_error() . "<br>Could not query the database.");
$r = mysql_fetch_row($result) or die(mysql_error() . "<br>Could not fetch the row.");
?>
		<form action="editadmin.php" method="post">
		<table border="1" cellspacing="1" cellpadding="1" width="90%">
			<tr>
				<td width="25%" align="left" valign="top">
					ID #:
				</td>
				<td width="75%" align="left" valign="top">
					<?=$r[0]?>
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="top">
					Username:
				</td>
				<td width="75%" align="left" valign="top">
					<?=$r[1]?>
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="top">
					Password:
				</td>
				<td width="75%" align="left" valign="top">
					<input type="password" name="pass" maxlength="20">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="top">
					E-Mail:
				</td>
				<td width="75%" align="left" valign="top">
					<input type="text" name="email" value="<?=$r[3]?>" maxlength="100">
				</td>
			</tr>
			<tr>
				<td colspan="2" align="center" valign="center">
					<input type="submit" name="submit" value="Edit Your Information"> | 
					<input type="reset" value="Restore">
					<input type="hidden" name="aid" value="<?=$r[0]?>">
				</td>
			</tr>
		</table>
		</form>
<?php
mysql_close();
?>