<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	addadminform.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	The HTML form for adding a new admin.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/
?>
		<form action="addadmin.php" method="post">
		<table border="1" cellspacing="1" cellpadding="1" width="90%">
			<tr>
				<td width="25%" align="left" valign="top">
					Username:
				</td>
				<td width="75%" align="left" valign="top">
					<input type="text" name="user">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="top">
					Password:
				</td>
				<td width="75%" align="left" valign="top">
					<input type="password" name="pass">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="top">
					E-Mail:
				</td>
				<td width="75%" align="left" valign="top">
					<input type="text" name="email">
				</td>
			</tr>
			<tr>
				<td colspan="2" align="center" valign="middle">
					<input type="submit" value="Add"> | 
					<input type="reset" value="Clear">
				</td>
			</tr>
		</table>
		</form>