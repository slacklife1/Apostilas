<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	editconfigform.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	The HTML form for editing the configuration.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/
?>
		<form action="editconfig.php" method="post">
		<table border="1" cellspacing="1" cellpadding="1" width="90%">
			<tr>
				<td width="25%" align="left" valign="top">
					Default Style:
				</td>
				<td width="75%" align="left" valign="top">
					<select name="style">
						<?php
						include("config.php");
						mysql_connect($sqlhost,$sqluser,$sqlpass) or die(mysql_error() . "<br>Could not connect to the database.");
						mysql_select_db($sqldb) or die(mysql_error() . "<br>Could not select the database.");
						$sql = "SELECT style FROM fubook_config";
						$result = mysql_query($sql);
						$stylenum = mysql_result($result,0);
						$sql = "SELECT sid,style FROM fubook_style";
						$result = mysql_query($sql);
						while($r = mysql_fetch_array($result)){
							if($r[sid] == $stylenum){
								echo "\n						<option value=\"$r[sid]\" selected>$r[style]</option>\n";
							}
							else{
								echo "\n						<option value=\"$r[sid]\">$r[style]</option>\n";
							}
						}
						?>
					</select>
				</td>
			</tr>
			<tr>
				<td colspan="2" align="center" valign="middle">
					<input type="submit" value="Update Configuration"> | 
					<input type="reset" value="Restore">
				</td>
			</tr>
		</table>
		</form>