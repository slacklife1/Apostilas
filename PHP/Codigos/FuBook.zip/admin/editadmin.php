<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	editadmin.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	Edits the specified admin's info.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/

require("auth.php");

if((!$HTTP_POST_VARS[pass]) || (!$HTTP_POST_VARS[email]) || (!$HTTP_POST_VARS[aid])){
	$title = "Missing Fields";
	include("header.php");
	echo "\n		$title.  Please go back and correct your mistake(s).\n";
	include("footer.php");
	exit;
}
else{
	include("../config.php");
	mysql_connect($sqlhost,$sqluser,$sqlpass);
	mysql_select_db($sqldb);
	$HTTP_POST_VARS[aid] = intval($HTTP_POST_VARS[aid]);
	$HTTP_POST_VARS[pass] = md5($HTTP_POST_VARS[pass]);
	$sql = "UPDATE fubook_admin SET pass='$HTTP_POST_VARS[pass]',email='$HTTP_POST_VARS[email]' WHERE (user='$PHP_AUTH_USER') AND (pass='$PHP_AUTH_PW')";
	if(mysql_query($sql)){
		$title = "Admin Edited Successfully";
		include("header.php");
		echo "\n		$title<br>
		<a href=\"index.php\">Index</a>\n";
		include("footer.php");
	}
	elseif(!mysql_query($sql)){
		$title = "Admin Couldn't be Edited";
		include("header.php");
		echo "\n		$title<br>" . mysql_error();
		include("footer.php");
		mysql_close();
		exit;
	}
	mysql_close();
}
?>