<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	editstylemenu.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	The HTML menu to editing a style.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/

echo <<<ENDIT
\n		<table border="1" cellspacing="1" cellpadding="1" width="90%">
			<tr>
				<td width="33%" align="center" valign="middle">
					ID #:
				</td>
				<td width="33%" align="center" valign="middle">
					Style Name:
				</td>
				<td width="33%" align="center" valign="middle">
					Edit?:
				</td>
			</tr>\n
ENDIT;
include("../config.php");
mysql_connect($sqlhost,$sqluser,$sqlpass) or die(mysql_error() . "<br>Could not connect to the database.");
mysql_select_db($sqldb) or die(mysql_error() . "<br>Could not select the database.");
$sql = "SELECT sid,style FROM fubook_style";
$result = mysql_query($sql);
while($r = mysql_fetch_array($result)){
	echo <<<ENDIT
\n			<tr>
				<td width="33%" align="center" valign="middle">
					$r[sid]
				</td>
				<td width="33%" align="center" valign="middle">
					$r[style]
				</td>
				<td width="33%" align="center" valign="middle">
					<a href="editstyleform.php?id=$r[sid]">Edit</a>
				</td>
			</tr>\n
ENDIT;
}
$sql = "SELECT style FROM fubook_config";
$result = mysql_query($sql);
$result = mysql_result($result,0);
$stylenum = intval($result);
echo "\n			<tr>
				<td colspan=\"3\" align=\"center\" valign=\"middle\">
					Current Style ID #:  $stylenum
				</td>
			</tr>
		</table>\n";
mysql_close();
?>