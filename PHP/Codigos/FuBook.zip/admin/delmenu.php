<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	delmenu.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	The HTML menu for deleting an entry.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/

echo <<<ENDIT
\n			<table border="1" cellspacing="1" cellpadding="1" width="90%">
				<tr>
					<td width="5%" align="center" valign="middle">
						ID #:
					</td>
					<td width="15%" align="center" valign="middle">
						Name:
					</td>
					<td width="60%" align="center" valign="middle">
						Message:
					</td>
					<td width="10%" align="center" valign="middle">
						IP:
					</td>
					<td width="10%" align="center" valign="middle">
						Delete?:
					</td>
				</tr>\n
ENDIT;
include("../config.php");
mysql_connect($sqlhost,$sqluser,$sqlpass) or die(mysql_error() . "<br>Could not connect to the database.");
mysql_select_db($sqldb) or die(mysql_error() . "<br>Could not select the database.");
$sql = "SELECT eid,name,msg,ip FROM fubook_entries";
$result = mysql_query($sql);
while($r = mysql_fetch_array($result)){
	$r[msg] = htmlspecialchars($r[msg],ENT_NOQUOTES);
	$r[msg] = substr($r[msg],0,97) . "...";
	echo <<<ENDIT
\n				<tr>
					<td width="5%" align="center" valign="middle">
						$r[eid]
					</td>
					<td width="15%" align="center" valign="middle">
						$r[name]
					</td>
					<td width="60%" align="center" valign="middle">
						$r[msg]
					</td>
					<td width="10%" align="center" valign="middle">
						$r[ip]
					</td>
					<td width="10%" align="center" valign="middle">
						<a href="javascript:sure('$r[eid]','delentry.php?id=$r[eid]')">Delete</a>
					</td>
				</tr>\n
ENDIT;
}
mysql_close();
?>
			</table>