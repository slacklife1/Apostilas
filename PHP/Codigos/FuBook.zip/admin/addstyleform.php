<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	addstyleform.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	The HTML form for adding a new style.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/
?>
		<form action="addstyle.php" method="post">
		<table border="1" cellspacing="1" cellpadding="1" width="90%">
			<tr>
				<td width="25%" align="left" valign="middle">
					Style Name:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="style" maxlength="50">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Background Color:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="bgcolor" maxlength="10">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Table Background Color 1:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="table1" maxlength="10">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Table Background Color 2:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="table2" maxlength="10">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Font Face:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="fontface" maxlength="20">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Font Size:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="fontsize" maxlength="1">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Font Color:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="fontcolor" maxlength="10">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Link Color:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="link" maxlength="10">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Visited Link Color:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="vlink" maxlength="10">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Active Link Color:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="alink" maxlength="10">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Cascading Style Sheet:
				</td>
				<td width="25%" align="left" valign="middle">
					<input type="text" name="css" maxlength="100">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Admin Image:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="adminimg" maxlength="100">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					E-Mail Image:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="emailimg" maxlength="100">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Link Image:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="wwwimg" maxlength="100">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					AIM Image:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="aimimg" maxlength="100">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					ICQ Image:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="icqimg" maxlength="100">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					MSN Image:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="msnimg" maxlength="100">
				</td>
			</tr>
			<tr>
				<td colspan="2" align="center" valign="middle">
					<input type="submit" value="Add Style"> | 
					<input type="reset" value="Clear">
				</td>
			</tr>
		</table>
		</form>