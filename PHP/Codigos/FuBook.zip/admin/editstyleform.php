<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	editstyleform.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	The HTML form for editing the specified style.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/

require("auth.php");

if(!$HTTP_GET_VARS[id]){
	$title = "No Style ID";
	echo "\n		$title\n";
	include("footer.php");
	exit;
}
include("../config.php");
$HTTP_GET_VARS[id] = intval($HTTP_GET_VARS[id]);
$sql = "SELECT * FROM fubook_style WHERE sid=$HTTP_GET_VARS[id]";
$result = mysql_query($sql);
$r = mysql_fetch_row($result);
$r[1] = htmlspecialchars($r[1]);
$title = "Editing Style ID #:  $HTTP_GET_VARS[id]";
include("header.php");
echo <<<ENDIT
\n		<form action="editstyle.php" method="post">
		<table border="1" cellspacing="1" cellpadding="1" width="90%">
			<tr>
				<td width="25%" align="left" valign="middle">
					Style ID #:
				</td>
				<td width="75%" align="left" valign="middle">
					$r[0]
					<input type="hidden" name="sid" value="$r[0]">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Style Name:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="style" value="$r[1]" maxlength="50">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Background Color:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="bgcolor" value="$r[2]" maxlength="10">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Table Background Color 1:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="table1" value="$r[3]" maxlength="10">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Table Background Color 2:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="table2" value="$r[4]" maxlength="10">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Font Face:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="fontface" value="$r[5]" maxlength="20">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Font Size:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="fontsize" value="$r[6]" maxlength="1">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Font Color:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="fontcolor" value="$r[7]" maxlength="10">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Link Color:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="link" value="$r[8]" maxlength="10">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Visited Link Color:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="vlink" value="$r[9]" maxlength="10">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Active Link Color:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="alink" value="$r[10]" maxlength="10">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Cascading Style Sheet:
				</td>
				<td width="25%" align="left" valign="middle">
					<input type="text" name="css" value="$r[11]" maxlength="100">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Admin Image:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="adminimg" value="$r[12]" maxlength="100">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					E-Mail Image:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="emailimg" value="$r[13]" maxlength="100">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					Link Image:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="wwwimg" value="$r[14]" maxlength="100">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					AIM Image:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="aimimg" value="$r[15]" maxlength="100">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					ICQ Image:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="icqimg" value="$r[16]" maxlength="100">
				</td>
			</tr>
			<tr>
				<td width="25%" align="left" valign="middle">
					MSN Image:
				</td>
				<td width="75%" align="left" valign="middle">
					<input type="text" name="msnimg" value="$r[17]" maxlength="100">
				</td>
			</tr>
			<tr>
				<td colspan="2" align="center" valign="middle">
					<input type="submit" value="Edit Style"> | 
					<input type="reset" value="Restore">
				</td>
			</tr>
		</table>
		</form>\n
ENDIT;
include("footer.php");
mysql_close();
?>