<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	auth.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	Authenticates the user to keep baddies outs.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/

if(!$PHP_AUTH_USER || !$PHP_AUTH_PW){
	header("WWW-Authenticate: Basic Realm=\"FuBook Admin\"");
	header("HTTP/1.0 401 Unauthorized");
	$title = "Authorization Required";
	include("header.php");
	echo "		Authorization is required.";
	include("footer.php");
	exit;
}
else{
	$PHP_AUTH_PW = md5($PHP_AUTH_PW);
	include("../config.php");
	mysql_connect($sqlhost,$sqluser,$sqlpass) or die(mysql_error() . "<br>Could not connect to the database.");
	mysql_select_db($sqldb) or die(mysql_error() . "<br>Could not select the database.");
	$sql = "SELECT user,pass FROM fubook_admin WHERE user='$PHP_AUTH_USER' AND pass='$PHP_AUTH_PW'";
	$result = mysql_query($sql);
	if(mysql_num_rows($result) >= 2 || mysql_num_rows($result) <= 0){
		$title = "User Authentication Error";
		include("header.php");
		echo "\n			$title\n";
		include("footer.php");
		mysql_close();
		exit;
	}
}
?>