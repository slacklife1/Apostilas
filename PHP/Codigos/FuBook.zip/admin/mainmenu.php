<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	mainmenu.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	Controls the menu on index.php.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/
?>
			<table border="1" cellspacing="1" cellpadding="1" width="90%">
				<tr>
					<td width="33%" align="center" valign="middle">
						<a href="?action=addentry">Add Entry</a>
					</td>
					<td width="33%" align="center" valign="middle">
						<a href="?action=editentry">Edit Entry</a>
					</td>
					<td width="33%" align="center" valign="middle">
						<a href="?action=delentry">Delete Entry</a>
					</td>
				</tr>
				<tr>
					<td width="33%" align="center" valign="middle">
						<a href="?action=addadmin">Add Administrator</a>
					</td>
					<td width="33%" align="center" valign="middle">
						<a href="?action=editadmin">Edit Your Information</a>
					</td>
					<td width="33%" align="center" valign="middle">
						<a href="?action=deladmin">Delete Administrator</a>
					</td>
				</tr>
				<tr>
					<td width="33%" align="center" valign="middle">
						<a href="?action=addstyle">Add Style</a>
					</td>
					<td width="33%" align="center" valign="middle">
						<a href="?action=editstyle">Edit Style
					</td>
					<td width="33%" align="center" valign="middle">
						<a href="?action=delstyle">Delete Style</a>
					</td>
				</tr>
				<tr>
					<td colspan="3" align="center" valign="middle">
						<a href="?action=config">Configuration</a>
					</td>
				</tr>
			</table>