<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	editstyle.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	Edits the specified style.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/

require("auth.php");

if((!$HTTP_POST_VARS[sid]) || (!$HTTP_POST_VARS[style]) || (!$HTTP_POST_VARS[bgcolor]) || (!$HTTP_POST_VARS[table1]) || (!$HTTP_POST_VARS[table2]) || (!$HTTP_POST_VARS[fontface]) || (!$HTTP_POST_VARS[fontsize]) || (!$HTTP_POST_VARS[fontcolor]) || (!$HTTP_POST_VARS[link]) || (!$HTTP_POST_VARS[vlink]) || (!$HTTP_POST_VARS[alink]) || (!$HTTP_POST_VARS[css]) || (!$HTTP_POST_VARS[adminimg]) || (!$HTTP_POST_VARS[emailimg]) || (!$HTTP_POST_VARS[wwwimg]) || (!$HTTP_POST_VARS[aimimg]) || (!$HTTP_POST_VARS[icqimg]) || (!$HTTP_POST_VARS[msnimg])){
	$title = "Missing Fields";
	include("header.php");
	echo "\n		$title.  Please go back and correct your mistake(s).\n";
	include("footer.php");
	exit;
}
else{
	include("../config.php");
	mysql_connect($sqlhost,$sqluser,$sqlpass);
	mysql_select_db($sqldb);
	$HTTP_POST_VARS[sid] = intval($HTTP_POST_VARS[sid]);
	$HTTP_POST_VARS[fontsize] = intval($HTTP_POST_VARS[fontsize]);
	$sql = "UPDATE fubook_style SET style='$HTTP_POST_VARS[style]',bgcolor='$HTTP_POST_VARS[bgcolor]',table1='$HTTP_POST_VARS[table1]',table2='$HTTP_POST_VARS[table2]',fontface='$HTTP_POST_VARS[fontface]',fontsize='$HTTP_POST_VARS[fontsize]',fontcolor='$HTTP_POST_VARS[fontcolor]',link='$HTTP_POST_VARS[link]',vlink='$HTTP_POST_VARS[vlink]',alink='$HTTP_POST_VARS[alink]',css='$HTTP_POST_VARS[css]',adminimg='$HTTP_POST_VARS[adminimg]',emailimg='$HTTP_POST_VARS[emailimg]',wwwimg='$HTTP_POST_VARS[wwwimg]',aimimg='$HTTP_POST_VARS[aimimg]',icqimg='$HTTP_POST_VARS[icqimg]',msnimg='$HTTP_POST_VARS[msnimg]' WHERE sid=$HTTP_POST_VARS[sid]";
	if(mysql_query($sql)){
		$title = "Style Edited Successfully";
		include("header.php");
		echo "\n		$title<br>
		<a href=\"index.php\">Index</a>\n";
		include("footer.php");
	}
	elseif(!mysql_query($sql)){
		$title = "Style Couldn't be Edited";
		include("header.php");
		echo "\n		$title<br>" . mysql_error();
		include("footer.php");
		mysql_close();
		exit;
	}
	mysql_close();
}
?>