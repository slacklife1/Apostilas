<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	addadmin.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	Actually adds the new admin info. to the database.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/

require("auth.php");

if((!$HTTP_POST_VARS[user]) || (!$HTTP_POST_VARS[pass]) || (!$HTTP_POST_VARS[email])){
	$title = "Missing Fields";
	include("header.php");
	echo "\n		$title.\n";
	include("footer.php");
	exit;
}
else{
	$HTTP_POST_VARS[user] = addslashes($HTTP_POST_VARS[user]);
	$HTTP_POST_VARS[pass] = md5($HTTP_POST_VARS[pass]);
	$emailPat = "^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*$";
	if(!eregi($emailPat,$HTTP_POST_VARS[email])){
		$title = "Invalid E-Mail Address";
		include("header.php");
		echo "\n		$title\n";
		include("footer.php");
		exit;
	}
	include("../config.php");
	mysql_connect($sqlhost,$sqluser,$sqlpass);
	mysql_select_db($sqldb);
	$sql = "INSERT INTO fubook_admin VALUES(0,'$HTTP_POST_VARS[user]','$HTTP_POST_VARS[pass]','$HTTP_POST_VARS[email]')";
	if(mysql_query($sql)){
		$title = "Admin Added Successfully";
		include("header.php");
		echo "\n		$title<br>
		<a href=\"index.php\">Index</a>\n";
		include("footer.php");
	}
	elseif(!mysql_query($sql)){
		$title = "Added Added Unsuccessfully";
		include("header.php");
		echo "\n		$title<br>
		mysql_error()\n";
		include("footer.php");
		mysql_close();
		exit;
	}
	mysql_close();
}
?>