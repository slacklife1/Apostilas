<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	editconfig.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	Edits the currect configuration.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/

require("auth.php");

if(!$HTTP_POST_VARS[style]){
	$title = "Missing Fields";
	include("header.php");
	echo "\n		$title.  Please go back and correct your mistake(s).\n";
	include("footer.php");
	exit;
}
else{
	include("../config.php");
	mysql_connect($sqlhost,$sqluser,$sqlpass);
	mysql_select_db($sqldb);
	$HTTP_POST_VARS[style] = intval($HTTP_POST_VARS[style]);
	$sql = "UPDATE fubook_config SET style=$HTTP_POST_VARS[style]";
	if(mysql_query($sql)){
		$title = "Configuration Edited Successfully";
		include("header.php");
		echo "\n		$title<br>
		<a href=\"index.php\">Index</a>\n";
		include("footer.php");
	}
	elseif(!mysql_query($sql)){
		$title = "Configuration Couldn't be Edited";
		include("header.php");
		echo "\n		$title<br>" . mysql_error();
		include("footer.php");
		mysql_close();
		exit;
	}
	mysql_close();
}
?>