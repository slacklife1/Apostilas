<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	delentry.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	Deletes the specified entry from the database.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/

require("auth.php");

if(!$HTTP_GET_VARS[id]){
	$title = "No Entry ID";
	include("header.php");
	echo "\n		$title\n";
	include("footer.php");
	exit;
}
else{
	include("../config.php");
	mysql_connect($sqlhost,$sqluser,$sqlpass);
	mysql_select_db($sqldb);
	$HTTP_GET_VARS[id] = intval($HTTP_GET_VARS[id]);
	$sql = "DELETE FROM fubook_entries WHERE eid=$HTTP_GET_VARS[id]";
	if(mysql_query($sql)){
		$title = "Deletion of Entry Successful";
		include("header.php");
		echo "\n		$title.<br>
		<a href=\"index.php\">Index</a>\n";
		include("footer.php");
	}
	elseif(!mysql_query($sql)){
		$title = "Deletion of Entry Unsuccessful";
		include("header.php");
		echo "\n		$title.\n";
		include("footer.php");
		mysql_close();
		exit;
	}
	mysql_close();
}
?>