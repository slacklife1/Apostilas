<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	index.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	Super duper main menu/index.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/

require("auth.php");

switch($action){
	case 'addentry':
		header("Location: ../index.php#sign");
		break;
	case 'editentry':
		$title = "Edit Entries";
		include("header.php");
		include("editmenu.php");
		include("footer.php");
		break;
	case 'delentry':
		$title = "Delete Entries";
		$optinc = "javascriptentries.inc";
		include("header.php");
		include("delmenu.php");
		include("footer.php");
		break;
	case 'addadmin':
		$title = "Add Admin";
		include("header.php");
		include("addadminform.php");
		include("footer.php");
		break;
	case 'editadmin':
		$title = "Edit Your Information";
		include("header.php");
		include("editadminform.php");
		include("footer.php");
		break;
	case 'deladmin':
		$title = "Delete Admin";
		$optinc = "javascriptadmin.inc";
		include("header.php");
		include("deladminmenu.php");
		include("footer.php");
		break;
	case 'addstyle':
		$title = "Add Style";
		include("header.php");
		include("addstyleform.php");
		include("footer.php");
		break;
	case 'editstyle':
		$title = "Edit Style";
		include("header.php");
		include("editstylemenu.php");
		include("footer.php");
		break;
	case 'delstyle':
		$title = "Delete Style";
		$optinc = "javascriptstyle.inc";
		include("header.php");
		include("delstylemenu.php");
		include("footer.php");
		break;
	case 'config':
		$title = "Configuration";
		include("header.php");
		include("editconfigform.php");
		include("footer.php");
		break;
	default:
		$title = "FuBook Administration";
		include("header.php");
		include("mainmenu.php");
		include("footer.php");
		break;
}
?>