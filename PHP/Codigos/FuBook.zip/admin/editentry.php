<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	editentry.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	Edits the specified entry.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/

require("auth.php");

if((!$HTTP_POST_VARS[name]) || (!$HTTP_POST_VARS[msg]) || (!$HTTP_POST_VARS[email]) || (!$HTTP_POST_VARS[eid])){
	$title = "Missing Fields";
	include("header.php");
	echo "\n		$title.  Please go back and correct your mistake(s).\n";
	include("footer.php");
	exit;
}
else{
	include("../config.php");
	mysql_connect($sqlhost,$sqluser,$sqlpass);
	mysql_select_db($sqldb);
	$HTTP_POST_VARS[eid] = intval($HTTP_POST_VARS[eid]);
	$HTTP_POST_VARS[icq] = intval($HTTP_POST_VARS[icq]);
	$sql = "UPDATE fubook_entries SET name='$HTTP_POST_VARS[name]',msg='$HTTP_POST_VARS[msg]',email='$HTTP_POST_VARS[email]',www='$HTTP_POST_VARS[www]',aim='$HTTP_POST_VARS[aim]',icq=$HTTP_POST_VARS[icq],msn='$HTTP_POST_VARS[msn]' WHERE eid=$HTTP_POST_VARS[eid]";
	if(mysql_query($sql)){
		$title = "Entry Edited Successfully";
		include("header.php");
		echo "\n		$title<br>
		<a href=\"index.php\">Index</a>\n";
		include("footer.php");
	}
	elseif(!mysql_query($sql)){
		$title = "Entry Couldn't be Edited";
		include("header.php");
		echo "\n		$title<br>" . mysql_error();
		include("footer.php");
		mysql_close();
		exit;
	}
	mysql_close();
}
?>