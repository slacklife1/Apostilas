<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	addentry.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	Actually adds the new entry to the database.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/

function bbcode($msg){
	$msg = str_replace("8]","<img src=\"images/alien.gif\">",$msg);
	$msg = str_replace(":evil","<img src=\"images/devil.gif\">",$msg);
	$msg = str_replace(":whoa","<img src=\"images/eek.gif\">",$msg);
	$msg = str_replace(":o","<img src=\"images/embarassed.gif\">",$msg);
	$msg = str_replace(":whatever","<img src=\"images/eyes.gif\">",$msg);
	$msg = str_replace(":(","<img src=\"images/frown.gif\">",$msg);
	$msg = str_replace("8D","<img src=\"images/glasses.gif\">",$msg);
	$msg = str_replace(":scheme","<img src=\"images/grin.gif\">",$msg);
	$msg = str_replace(":D","<img src=\"images/happy.gif\">",$msg);
	$msg = str_replace(":|","<img src=\"images/indifferent.gif\">",$msg);
	$msg = str_replace(":lol","<img src=\"images/laugh.gif\">",$msg);
	$msg = str_replace(">:","<img src=\"images/mad.gif\">",$msg);
	$msg = str_replace("8o","<img src=\"images/nerd.gif\">",$msg);
	$msg = str_replace(":\\","<img src=\"images/ohwell.gif\">",$msg);
	$msg = str_replace(":slick","<img src=\"images/pimp.gif\">",$msg);
	$msg = str_replace(":hyper","<img src=\"images/roll.gif\">",$msg);
	$msg = str_replace("XO","<img src=\"images/sick.gif\">",$msg);
	$msg = str_replace(":)","<img src=\"images/smile.gif\">",$msg);
	$msg = str_replace(":hotbox","<img src=\"images/smokin.gif\">",$msg);
	$msg = str_replace("-.-","<img src=\"images/tired.gif\">",$msg);
	$msg = str_replace(":p","<img src=\"images/tongue.gif\">",$msg);
	$msg = preg_replace("/\[b\](.*?)\[\/b\]/si","<b>\\1</b>",$msg);
	$msg = preg_replace("/\[i\](.*?)\[\/i\]/si","<i>\\1</i>",$msg);
	$msg = preg_replace("/\[u\](.*?)\[\/u\]/si","<u>\\1</u>",$msg);
	$msg = preg_replace("/\[img\](.*?)\[\/img\]/si","<img src=\"\\1\" border=\"0\">",$msg);
	$msg = nl2br($msg);
	return $msg;
}

if(!$HTTP_POST_VARS[name] || !$HTTP_POST_VARS[email]){
	echo <<<ENDIT
<html>
	<head>
		<title>
			Missing Fields
		</title>
	</head>
	<body>
		One or more required fields were empty.
	</body>
</html>
ENDIT;
exit;
}

else{
	include("config.php");
	mysql_connect($sqlhost,$sqluser,$sqlpass) or die(mysql_error() . "<br>Could not connect to the database.");
	mysql_select_db($sqldb) or die(mysql_error() . "<br>Could not select the database.");
	$name = $HTTP_POST_VARS[name];
	$name = htmlspecialchars($name,ENT_NOQUOTES);
	$msg = $HTTP_POST_VARS[msg];
	$msg = htmlspecialchars($msg,ENT_NOQUOTES);
	$msg = bbcode($msg);
	$email = $HTTP_POST_VARS[email];
	$email = htmlspecialchars($email,ENT_NOQUOTES);
	$emailPat = "^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*$";
	if(!eregi($emailPat,$email)){
		$title = "Invalid E-Mail Address";
		echo $title;
		mysql_close();
		exit;
	}
	$www = $HTTP_POST_VARS[www];
	$www = htmlspecialchars($www,ENT_NOQUOTES);
	$aim = $HTTP_POST_VARS[aim];
	$aim = htmlspecialchars($aim,ENT_NOQUOTES);
	$icq = $HTTP_POST_VARS[icq];
	$icq = htmlspecialchars($icq,ENT_NOQUOTES);
	$msn = $HTTP_POST_VARS[msn];
	$msn = htmlspecialchars($msn,ENT_NOQUOTES);
	$datetime = date("m/d/y h:i a");
	$ip = $REMOTE_ADDR;
	$sql = "INSERT INTO fubook_entries VALUES(0,'$name','$msg','$datetime','$ip','$email','$www','$aim','$icq','$msn')";
	if(mysql_query($sql)){
		header("Location: index.php");
	}
	elseif(!mysql_query($sql)){
		echo mysql_error() . "<br>Could not insert entry.";
	}
	mysql_close();
}
?>