<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	install.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	Installs FuBook from the web.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/

require("config.php");
mysql_connect($sqlhost,$sqluser,$sqlpass) or die(mysql_error() . "<br>Could not connect to the database.");
mysql_select_db($sqldb) or die(mysql_error() . "<br>Could not select the database.");

$entries1 = "CREATE TABLE fubook_entries(
		eid INT UNSIGNED NOT NULL AUTO_INCREMENT,
		PRIMARY KEY(eid),
		name VARCHAR(20) NOT NULL,
		msg TEXT NOT NULL,
		datetime VARCHAR(30) NOT NULL,
		ip VARCHAR(20) NOT NULL,
		email VARCHAR(100) NOT NULL,
		www VARCHAR(255),
		aim VARCHAR(16),
		icq INT(20) UNSIGNED,
		msn VARCHAR(100))";
mysql_query($entries1) or die(mysql_error() . "<br>Could not make entries table.");

$entries2 = "INSERT INTO fubook_entries SET
		eid = 1,
		name = 'John Doe',
		msg = 'Love the site.',
		datetime = '00/00/00 00:00 am',
		ip = '127.0.0.1',
		email = 'doej@doej.com',
		www = 'http://www.doej.com',
		aim = 'John Doe',
		icq = '000000',
		msn = 'doej@hotmail.com'";
mysql_query($entries2) or die(mysql_error() . "<br>Could not insert entry data.");

$admin1 = "CREATE TABLE fubook_admin(
	aid INT UNSIGNED NOT NULL AUTO_INCREMENT,
	PRIMARY KEY(aid),
	user VARCHAR(10) NOT NULL,
	pass VARCHAR(255) NOT NULL,
	email VARCHAR(100) NOT NULL)";
mysql_query($admin1) or die(mysql_error() . "<br>Could not make admin table.");

$admin2 = "INSERT INTO fubook_admin SET
		aid = 1,
		user = 'admin',
		pass = '5f4dcc3b5aa765d61d8327deb882cf99',
		email = 'you@email.ext'";
mysql_query($admin2) or die(mysql_error() . "<br>Could not insert admin data.");

$style1 = "CREATE TABLE fubook_style(
		sid INT UNSIGNED NOT NULL AUTO_INCREMENT, 
		PRIMARY KEY(sid),
		style VARCHAR(50) NOT NULL,
		bgcolor VARCHAR(10) NOT NULL,
		table1 VARCHAR(10) NOT NULL,
		table2 VARCHAR(10) NOT NULL,
		fontface VARCHAR(20) NOT NULL,
		fontsize INT(1) NOT NULL,
		fontcolor VARCHAR(10) NOT NULL,
		link VARCHAR(10) NOT NULL,
		vlink VARCHAR(10) NOT NULL,
		alink VARCHAR(10) NOT NULL,
		css VARCHAR(100) NOT NULL,
		adminimg VARCHAR(100) NOT NULL,
		emailimg VARCHAR(100) NOT NULL,
		wwwimg VARCHAR(100) NOT NULL,
		aimimg VARCHAR(100) NOT NULL,
		icqimg VARCHAR(100) NOT NULL,
		msnimg VARCHAR(100) NOT NULL)";
mysql_query($style1) or die(mysql_error() . "<br>Could not make style table.");

$style2 = "INSERT INTO fubook_style SET
		sid = 1,
		style = 'Default',
		bgcolor = '#000000',
		table1 = '#c0c0c0',
		table2 = '#000000',
		fontface = 'Arial',
		fontsize = 2,
		fontcolor = '#ffffff',
		link = '#0000ff',
		vlink = '#660066',
		alink = '#ff0000',
		css = 'style.css',
		adminimg = 'adminimg.gif',
		emailimg = 'emailimg.gif',
		wwwimg = 'wwwimg.gif',
		aimimg = 'aimimg.gif',
		icqimg = 'icqimg.gif',
		msnimg = 'msnimg.gif'";
mysql_query($style2) or die(mysql_error() . "<br>Could not insert style data.");

$config1 = "CREATE TABLE fubook_config(
		style INT(1) UNSIGNED NOT NULL DEFAULT 1)";
mysql_query($config1) or die(mysql_error() . "<br>Could not make config table.");

$config2 = "INSERT INTO fubook_config SET
		style = 1";
mysql_query($config2) or die(mysql_error() . "<br>Could not insert config data.");
mysql_close();
?>