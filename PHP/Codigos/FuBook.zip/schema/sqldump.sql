# Create the entries table
CREATE TABLE fubook_entries(
eid INT UNSIGNED NOT NULL AUTO_INCREMENT,
PRIMARY KEY(eid),
name VARCHAR(20) NOT NULL,
msg TEXT NOT NULL,
datetime VARCHAR(30) NOT NULL,
ip VARCHAR(20) NOT NULL,
email VARCHAR(100) NOT NULL,
www VARCHAR(255),
aim VARCHAR(16),
icq INT(20) UNSIGNED,
msn VARCHAR(100));

# Insert a test entry
INSERT INTO fubook_entries SET
eid = 1,
name = "John Doe",
msg = "Love the site.",
datetime = "00/00/00 00:00 am",
ip = "127.0.0.1",
email = "doej@doej.com",
www = "http://www.doej.com",
aim = "John Doe",
icq = "000000",
msn = "doej@hotmail.com";

# Create the admin table
CREATE TABLE fubook_admin(
aid INT UNSIGNED NOT NULL AUTO_INCREMENT,
PRIMARY KEY(aid),
user VARCHAR(10) NOT NULL,
pass VARCHAR(255) NOT NULL,
email VARCHAR(100) NOT NULL);

# Insert a temporary admin
# The pass is MD5 for password
INSERT INTO fubook_admin SET
aid = 1,
user = "admin",
pass = "5f4dcc3b5aa765d61d8327deb882cf99",
email = "you@email.ext";

# Create the style table
CREATE TABLE fubook_style(
sid INT UNSIGNED NOT NULL AUTO_INCREMENT, 
PRIMARY KEY(sid),
style VARCHAR(50) NOT NULL,
bgcolor VARCHAR(10) NOT NULL,
table1 VARCHAR(10) NOT NULL,
table2 VARCHAR(10) NOT NULL,
fontface VARCHAR(20) NOT NULL,
fontsize INT(1) NOT NULL,
fontcolor VARCHAR(10) NOT NULL,
link VARCHAR(10) NOT NULL,
vlink VARCHAR(10) NOT NULL,
alink VARCHAR(10) NOT NULL,
css VARCHAR(100) NOT NULL,
adminimg VARCHAR(100) NOT NULL,
emailimg VARCHAR(100) NOT NULL,
wwwimg VARCHAR(100) NOT NULL,
aimimg VARCHAR(100) NOT NULL,
icqimg VARCHAR(100) NOT NULL,
msnimg VARCHAR(100) NOT NULL);

# Default style
# Yeah, I know my design sucks.  :P
INSERT INTO fubook_style SET
sid = 1,
style = "Default",
bgcolor = "#000000",
table1 = "#c0c0c0",
table2 = "#000000",
fontface = "Arial",
fontsize = 2,
fontcolor = "#ffffff",
link = "#0000ff",
vlink = "#660066",
alink = "#ff0000",
css = "style.css",
adminimg = "adminimg.gif",
emailimg = "emailimg.gif",
wwwimg = "wwwimg.gif",
aimimg = "aimimg.gif",
icqimg = "icqimg.gif",
msnimg = "msnimg.gif";

# Create the config table
CREATE TABLE fubook_config(
style INT(1) UNSIGNED NOT NULL DEFAULT 1);

# Insert default config
INSERT INTO fubook_config SET
style = 1;