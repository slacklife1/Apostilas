<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	index.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	Displays the guestbook entries.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/

include("config.php");
mysql_connect($sqlhost,$sqluser,$sqlpass);
mysql_select_db($sqldb);
$sql = "SELECT style FROM fubook_config";
$result = mysql_query($sql);
$style_num = mysql_result($result,0);
$style_num = intval($style_num);
$sql = "SELECT * FROM fubook_style WHERE sid=$style_num";
$style = mysql_query($sql);
while($r = mysql_fetch_array($style)){
	$bgcolor = $r[bgcolor];
	$table1 = $r[table1];
	$table2 = $r[table2];
	$fontface = $r[fontface];
	$fontsize = intval($r[fontsize]);
	$fontcolor = $r[fontcolor];
	$link = $r[link];
	$vlink = $r[vlink];
	$alink = $r[alink];
	$css = $r[css];
	$adminimg = $r[adminimg];
	$emailimg = $r[emailimg];
	$wwwimg = $r[wwwimg];
	$aimimg = $r[aimimg];
	$icqimg = $r[icqimg];
	$msnimg = $r[msnimg];
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
	<head>
		<title>
			FuBook
		</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<link rel="stylesheet" href="<?=$css?>" type="text/html">
		<?php include("javascript.inc"); ?>
	</head>
	<body bgcolor="<?=$bgcolor?>" text="<?=$fontcolor?>" link="<?=$link?>" vlink="<?=$vlink?>" alink="<?=$alink?>">
		<center>
		<font face="<?=$fontface?>">
		<table border="1" bordercolor="<?=$table1?>" cellspacing="1" cellpadding="1" width="90%">
			<tr>
				<td colspan="7" bgcolor="<?=$bgcolor?>" align="center" valign="middle">
					<font size="<?=$fontsize?>">
						<a href="#sign">Sign It</a>
					</font>
				</tr>
			</tr>
			<?php
			$sql = "SELECT * FROM fubook_entries ORDER BY eid DESC";
			$a = mysql_query($sql);
			while($r = mysql_fetch_array($a)){
				$r[aim] = urlencode($r[aim]);
				echo "			<tr>
				<td width=\"25%\" align=\"left\" valign=\"top\" bgcolor=\"$table1\" rowspan=\"2\">
					<font size=\"$fontsize\">
						$r[name]<br>
						Posted at<br>
						$r[datetime]
					</font>
				</td>
				<td align=\"left\" valign=\"top\" bgcolor=\"$table2\" colspan=\"6\">
        				<font size=\"$fontsize\">
						$r[msg]
					</font>
				</td>
			</tr>
			<tr>
				<td align=\"center\" valign=\"top\" bgcolor=\"$table2\">
					<a href=\"mailto:$r[email]\"><img src=\"$emailimg\" border=\"0\"></a>
				</td>
				<td align=\"center\" valign=\"middle\" bgcolor=\"$table2\">
					<a href=\"$r[www]\" target=\"$r[name]\"><img src=\"$wwwimg\" border=\"0\"></a>
				</td>
				<td align=\"center\" valign=\"middle\" bgcolor=\"$table2\">
					<a href=\"aim:goim?screenname=$r[aim]&message=Hello.\"><img src=\"$aimimg\" border=\"0\"></a>
				</td>
				<td align=\"center\" valign=\"middle\" bgcolor=\"$table2\">
					<a href=\"javascript:alert('ICQ: $r[icq]');\"><img src=\"$icqimg\" border=\"0\"></a>
				</td>
				<td align=\"center\" valign=\"middle\" bgcolor=\"$table2\">
					<a href=\"javascript:alert('MSN: $r[msn]');\"><img src=\"$msnimg\" border=\"0\"></a>
				</td>
				<td align=\"center\" valign=\"middle\" bgcolor=\"$table2\">
					<a href=\"javascript:admin($r[eid]);\"><img src=\"$adminimg\" border=\"0\"></a>
				</td>
			</tr>";
			}
			?>
			<a name="sign"></a>
			<form action="addentry.php" method="post" name="entry" onsubmit="return validate()">
			<tr>
				<td bgcolor="<?=$table2?>" align="left" valign="top">
					<font size="<?=$fontsize?>">
						Name: *
					</font>
				</td>
				<td bgcolor="<?=$table1?>" align="left" valign="top" colspan="6">
					<input type="text" name="name" maxlength="20" size="100%">
				</td>
			</tr>
			<tr>
				<td bgcolor="<?=$table2?>" align="left" valign="top">
					<font size="<?=$fontsize?>">


						E-Mail: *
					</font>
				</td>
				<td bgcolor="<?=$table1?>" align="left" valing="top" colspan="6">
					<input type="text" name="email" maxlength="100" size="100%">
				</td>
			</tr>
			<tr>
				<td bgcolor="<?=$table2?>" align="left" valign="top">
					<font size="<?=$fontsize?>">
						Link:
					</font>
				</td>
				<td bgcolor="<?=$table1?>" align="left" valign="top" colspan="6">
					<input type="text" name="www" value="http://" maxlength="255" size="100%">
				</td>
			</tr>
			<tr>
				<td bgcolor="<?=$table2?>" align="left" valign="top">
					<font size="<?=$fontsize?>">
        					AIM:
        				</font>
				</td>
				<td bgcolor="<?=$table1?>" align="left" valign="top" colspan="6">
					<input type="text" name="aim" maxlenght="16" size="100%">
				</td>
			</tr>
			<tr>
				<td bgcolor="<?=$table2?>" align="left" valign="top">
					<font size="<?=$fontsize?>">
						ICQ:
					</font>
				</td>
				<td bgcolor="<?=$table1?>" align="left" valign="top" colspan="6">
					<input type="text" name="icq" maxlength="20" size="100%">
				</td>
			</tr>
			<tr>
				<td bgcolor="<?=$table2?>" align="left" valign="top">
					<font size="<?=$fontsize?>">
						MSN:
					</font>
				</td>
				<td bgcolor="<?=$table1?>" align="left" valign="top" colspan="6">
					<input type="text" name="msn" maxlength="100" size="100%">
				</td>
			</tr>
			<tr>
				<td bgcolor="<?=$table2?>" align="left" valign="top">
					<font size="<?=$fontsize?>">
						Message:
					</font>
				</td>
				<td bgcolor="<?=$table1?>" align="left" valign="top" colspan="6">
					<textarea name="msg" rows="5" cols="102" style="background:<?=$bgcolor?>;font-family:<?=$fontface?>;color:<?=$fontcolor?>;style="border style:solid"></textarea>
				</td>
			</tr>
			<tr>
				<td bgcolor="<?=$bgcolor?>" align="center" valign="center" colspan="7">
					<input type="submit" name="submit" value="Submit"> | 
					<input type="reset" name="reset" value="Clear">
				</td>
			</tr>
			</form>
			<tr>
				<td colspan="7" bgcolor="<?=$bgcolor?>" align="center" valign="top">
					<font size="1">
						<!-- This copyright MUST remain //-->
						Powered by <a href="http://www.fubonis.com" target="fubook">FuBook</a>
					</font>
				</td>
			</tr>
		</table>
		</font>
		</center>
	</body>
</html>
<?php
mysql_close();
?>