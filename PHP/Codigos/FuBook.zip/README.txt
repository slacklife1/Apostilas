FuBook
------
READ ME

File		|	Location
----		|	--------
Copyrights	|	DOCS/GPL.txt
FAQ		|	DOCS/FAQ.txt
Installation	|	DOCS/INSTALL.txt
Problems	|	DOCS/PROBLEMS.txt
Requirements	|	DOCS/REQUIREMENTS.txt