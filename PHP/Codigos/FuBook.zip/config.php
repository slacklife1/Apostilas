<?php
/*
	Script Name:	FuBook (http://www.fubonis.com/fubook)
	Script Version:	1.0
	File Name:	config.php
	Author:		Fubonis (http://www.fubonis.com)
	Purpose:	Stores the login info. for the database.
	Copyright:	GNU GPL (http://www.gnu.org)
	Request(s):	Don't rip.  Give credit where credit is due.  Feel free to edit, modify and learn from my code,
			but don't pass off as ONLY your own work.  Make sure the original README.txt and everything in
			the DOCS folder are included.
*/

$sqlserver = "";	# MySQL server/host.  Usually "localhost"
$sqluser = "";	# MySQL username.
$sqlpass = "";	# MySQL password.
$sqldb = "";	# MySQL database.
?>