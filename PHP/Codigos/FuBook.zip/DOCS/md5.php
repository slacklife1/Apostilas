<?php
echo "Your encrypted password is:<br>" . md5($password);
?>