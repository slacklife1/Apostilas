<?PHP
    /*
        TagTag v1.0
        Copyright (c)2000 Ed Farrow, all rights reserved.
        
        Description:
            TagTag is a 'live' messaging system, similar
            to having user graffiti on your website. It
            allows the user to interact with the webpage.
        
        Disclaimer:
            Use at your own risk, there will be no
            responsibility held by the author or any
            other party should something negative and/or
            detrimental happen due to the (mis)use of
            this script.

        Bug Reports:            
            Please send bug reports to ed@er33t.co.uk.
            The latest official release can always be
            found at: http://er33t.co.uk/tagtag/

        Installation and configuration instructions can be
        found in the README file that should have accompanied
        this script.
    */
    global $sql,$admin,$display,$sql_sock;
    // Global Configuration
    $sql = array(
		1=>"localhost",
		   3306,
		   "yoursqlusername",
		   "yoursqlpassword",
		   "yoursqldatabase",
		   "tagtag");
  $admin = array(
		1=>"Yourname",
		   "you@yourdomain",
		   "tagtag/bans.txt");
$display = array(
                1=>15,
                   64,
                   2,
                   30,
                   "tagtag/tag.html",
                   "tagtag graffiti",
                   "add tagtag",
                   "http://yourhost/",
                   "http://tag/t.php",
                   "&gt;",
		   2);
    // Global Configuration

    if($tagchk=="add"){
        addTagTag();
    }else{
        showTagTag();
    }
    // addTagTag() - Add a TagTag to the database.
    function addTagTag() {
        global $sql,$admin,$display,$sql_sock,$taginput,$REMOTE_ADDR,$HTTP_USER_AGENT;
        $isBan=banCheck($REMOTE_ADDR);
        if($isBan=="2"){
            header("Location: $display[9]");
            exit;
        }
        $isFlood=checkTagTag();
        if($isFlood=="2"){
            header("Location: $display[9]");
            exit;
        }
        $taginput=strip_tags($taginput);
        if($display[11]<>1){
            $taginput = eregi_replace("(([a-z0-9_]|\\-|\\.)+@([^[:space:]]*)([[:alnum:]-]))","",$taginput);
            $taginput = eregi_replace("([[:alnum:]]+)://([^[:space:]]*)([[:alnum:]#?/&=])","",$taginput);
        }
        if((!($taginput))||(strlen($taginput)<3)||(strlen($taginput)>$display[2])){
            header("Location: $display[9]");
            exit;
        }
        $nowdate=Date("Y-m-d H:i:s");
        $sql_q="INSERT INTO $sql[6] (tagid,visible,tagsent,userip,browser,tagmsg) VALUES ('','1','$nowdate','$REMOTE_ADDR','$HTTP_USER_AGENT','$taginput');";
        openSQL();
        $sql_r=mysql_query($sql_q,$sql_sock);
        closeSQL();
        header("Location: $display[9]");
        exit;
    }
    // showTagTag() - Display the TagTag page, w00p.
    function showTagTag() {
        global $sql,$admin,$display,$sql_sock,$taginput,$REMOTE_ADDR;
        $fRead=fopen($display[5],"r");
            if(!($fRead)) die("[an error occurred while opening template]\n");
            $tagBuffer=fread($fRead,filesize($display[5]));
        fclose($fRead);
        $tagBuffer=str_replace("[%maxchar%]","$display[2]",$tagBuffer);
        $tagBuffer=str_replace("[%refresh%]","$display[4]",$tagBuffer);
        $tagBuffer=str_replace("[%taghead%]","$display[6]",$tagBuffer);
        $tagBuffer=str_replace("[%tagpost%]","$display[7]",$tagBuffer);
        $tagBuffer=str_replace("[%homeurl%]","$display[8]",$tagBuffer);
        $tagBuffer=str_replace("[%tagpage%]","$display[9]",$tagBuffer);
        $tagData=grabTagTag();
        $tagBuffer=str_replace("[%tagdata%]","$tagData",$tagBuffer);
        print($tagBuffer);
        exit;
    }
    // openSQL() - Open a socket to the mySQL database.
    function openSQL() {
        global $sql,$admin,$display,$sql_sock,$taginput,$REMOTE_ADDR;
        $sql_sock=mysql_connect("$sql[1]:$sql[2]",$sql[3],$sql[4]) or
            die("[an error occured while connecting to the sql server]");
        mysql_select_db($sql[5]) or
            die("[an error occured while opening the database]");
    }
    // closeSQL() - Close a currently open mySQL socket.
    function closeSQL() {
        global $sql,$admin,$display,$sql_sock,$taginput,$REMOTE_ADDR;
        mysql_close($sql_sock);
    }
    // grabTagTag() - Grab the TagTag's from our database.
    function grabTagTag() {
        global $sql,$admin,$display,$sql_sock,$taginput,$REMOTE_ADDR;
        openSQL();
        $sql_s="SELECT * FROM $sql[6] WHERE visible='1' ORDER BY tagsent DESC LIMIT 0,$display[1];";
        $sql_r=mysql_query($sql_s,$sql_sock);
        $sql_n=mysql_num_rows($sql_r);
        for($i=1;$i<=$sql_n;$i++) {
            $sqldata=mysql_fetch_row($sql_r);
             $tagmsg=$sqldata[5];
             $tagOut="$tagOut$display[10] $tagmsg\n";
        }
        closeSQL();
        return($tagOut);
    }
    // checkTagTag() - Check the time stamp of the previous tagtag for flood protect.
    function checkTagTag() {
        global $sql,$admin,$display,$sql_sock,$taginput,$REMOTE_ADDR;
        openSQL();
        $sql_s="SELECT * FROM $sql[6] WHERE visible='1' ORDER BY tagsent DESC LIMIT 0,$display[3];";
        $sql_r=mysql_query($sql_s,$sql_sock);
        $sql_n=mysql_num_rows($sql_r);
        $c=0;
        for($i=1;$i<=$sql_n;$i++) {
            $sqldata=mysql_fetch_row($sql_r);
                $tagip=$sqldata[3];
            if($tagip==$REMOTE_ADDR){ $c++; }
            if($c==$display[3]){
                return("2");
                break;
            }
        }
        closeSQL();
        return("1");
    }    
    // banCheck($checkip) - Check for banned IP address.
    function banCheck($checkip) {
        global $sql,$admin,$display,$sql_sock,$taginput,$REMOTE_ADDR;
        $fRead=fopen($admin[3],"r");
            if(!($fRead)) return("1");
            $banBuffer=fread($fRead,filesize($admin[3]));
        fclose($fRead);
        $fRead = chop($banBuffer);
         $bans = explode("\n",$fRead);
        for($i=0;$i<=$tBans;$i++) {
            if($bans[$i]==$checkip) {
                return("2");
                break;
            }
        }
        reset($bans);
        return("1");
    }
?>