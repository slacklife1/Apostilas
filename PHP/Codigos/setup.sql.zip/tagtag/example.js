<SCRIPT LANGUAGE="JavaScript">
	var browser=navigator.appName;
	var version=navigator.appVersion;
	if(browser=="Microsoft Internet Explorer" && version>="4") {
		document.write('<IFRAME NAME="tagtag" SRC="http://er33t.co.uk/tagtag.php" WIDTH="120" HEIGHT="190" MARGINWIDTH="0" MARGINHEIGHT="0" SCROLLING="NO" FRAMEBORDER="0"></IFRAME>');
	}
</SCRIPT>