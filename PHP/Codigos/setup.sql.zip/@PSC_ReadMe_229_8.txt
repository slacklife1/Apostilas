Title: TagTag 1.0
Description: TagTag is a neato little web toy for webmasters who can run PHP4 and have a mySQL table. It allows you to have a 'live' graffiti window on your website, and is fully customisable including features to ban people by IP.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=229&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
