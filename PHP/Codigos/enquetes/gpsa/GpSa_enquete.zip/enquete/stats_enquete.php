<?

/*
Vers�o: 1.0.0
  Enquete Simples
  criada por Guilherme Pereira da Silva ALves
  guilhermepsa@ibestvip.com.br
  http://www.gpsa.togetherhost.com

Este script pode ser utilizado para qualquer fim desde
que nenhum nome, e-mail e/ou URL sejam omitidos e/ou alterados.

Est� proibida a venda e/ou qualquer outro tipo de comercializa��o
deste script.

A altera��o deste script deve ser feita livremente desde
que nenhum nome, e-mail e/ou URL sejam omitidos e/ou alterados.

O mau uso e/ou uso mau intencionado deste script � de inteira
responsabilidade do usu�rio.

Este script � distribuido livremente sem qualquer tipo de garantia,
portanto use-o por sua pr�pria conta e risco.


D�vidas, cr�ticas e sugest�es: guilhermepsa@ibestvip.com.br

Atencionamente
Guilherme Pereira da Silva ALves
*/

include "vars/var_textos.inc";
include "vars/var_dir_imgs.inc";
include "vars/var_formats.inc";
include "html/cabecalho.inc";
include "mysql/conexao_mysql.inc";
include ("html/enq_perg.inc");

echo"
<html>
<head>
<title>
$titulo_do_site
  </title>
<link type='text/css' rel='stylesheet' href='estilo.css'>
<script language='javascript' src='script.js'>
</script>
</head>
<body leftMargin='5' topMargin='5' marginheight='5' marginwidth='5' onload=\"window.status='$barra_de_status'; return true\">";

mysql_connect($host,  $usuario_mysql, $senha_mysql) or die ("Erro ao Tentar Conectar ao Banco de Dados"); 
mysql_select_db($db);

echo"
<table bordercolor='#707d95' width='100%' valign='top' border='1' cellpadding='0' cellspacing='1' style='border: 0px solid;' bgcolor='#ffffff'> 
<tr>
<td align='center' background='$fundo_de_tabela_1' valign='top'>
<font face='$face_1' size='$tam_2' color='$cor_2'>
<b>:: Resultados De Nossa Enquete ::</b>
</td>
</tr>
<tr>
<td valign='top' height='1' bgcolor='#707d95' width='50%'>
</td>
</tr>

<tr>
<td valign='top'>
<font face='$face_1' size='$tam_2' color='$cor_1'>
<b>Pergunta:</b> $perg_enqt
</td>
</tr>

<tr>
<td height='1' bgcolor='#707d95'>
</td>
</tr>
";
$sql = "SELECT * FROM enquete Order by id limit 0,30";
$query = mysql_query($sql);

while($row = mysql_fetch_array($query)){
$opcao = $row[opcao];
$votos = $row[votos];
$total+=$votos;
$tam=$votos + 2;
echo"
<table bordercolor='#707d95' width='100%' valign='top' border='0' cellpadding='0' cellspacing='0' style='border: 0px solid;' bgcolor='#ffffff'> 
<tr>
<td valign='bottom'>
<font face='$face_1' size='$tam_1' color='$cor_1'>
<b>*$opcao:</b> <img src='$fundo_de_tabela_1'  height='12' width='$tam'> $votos\n";
if($votos<=1){
echo"Voto";
}

if($votos>1){
echo"Votos";
}
echo"
</td>
</tr>
<tr>
<td valign='top' height='1' bgcolor='#707d95' width='50%'>
</td>
</tr>";
}

echo"
<tr>
<td valign='top' align='center'>
<font face='$face_1' size='$tam_1' color='$cor_1'>
Total de Votos Computados: <b>$total</td>
</tr>

<tr>
<td valign='bottom' background='$fundo_de_tabela' align='center'>
<font face='$font_face' color='$cor_txt' size='$tam_2'>
<input type='submit' value='Fechar Janela' class='botao_2' onclick='window.close()'>
</td>
</tr>
<tr>
<td valign='top' height='1' bgcolor='#707d95' width='50%'>
</td>
</tr>

<tr>
<td valign='top'>
GpSa - Todos os Direitos Reservados
</td>
</tr>
</table>";