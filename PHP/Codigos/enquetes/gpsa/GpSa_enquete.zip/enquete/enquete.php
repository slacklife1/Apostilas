<?

/*
Vers�o: 1.0.0
  Enquete Simples
  criada por Guilherme Pereira da Silva ALves
  guilhermepsa@ibestvip.com.br
  http://www.gpsa.togetherhost.com

Este script pode ser utilizado para qualquer fim desde
que nenhum nome, e-mail e/ou URL sejam omitidos e/ou alterados.

Est� proibida a venda e/ou qualquer outro tipo de comercializa��o
deste script.

A altera��o deste script deve ser feita livremente desde
que nenhum nome, e-mail e/ou URL sejam omitidos e/ou alterados.

O mau uso e/ou uso mau intencionado deste script � de inteira
responsabilidade do usu�rio.

Este script � distribuido livremente sem qualquer tipo de garantia,
portanto use-o por sua pr�pria conta e risco.


D�vidas, cr�ticas e sugest�es: guilhermepsa@ibestvip.com.br

Atencionamente
Guilherme Pereira da Silva ALves
*/


include ("html/enq_perg.inc");

echo"
<form action='' method='POST'>
<b>Pergunta:</b>
$perg_enqt
<hr size='1' color='#707d95'>";

$sql = "SELECT * FROM enquete";
$query = mysql_query($sql);
while($row = mysql_fetch_array($query)){
$id = $row[id];
$opcao = $row[opcao];
$votos = $row[votos];

echo"
<INPUT TYPE='hidden' name='voto' value='1'>
<input type='radio' name='opcao' value='$opcao'>$opcao<br>";
}
echo"
<div align='center'>
<br><input type='submit' name='vota' value=':: Votar ::' class='botao'>
</form><a href=\"javascript: resultados()\"> Ver Resultados</a>";

if(isset($_POST[opcao])){
$opcao_post = $_POST[opcao];
$vota_post = $_POST[voto];

$sql2 = "SELECT votos FROM enquete where opcao='$opcao_post'";
$query2 = mysql_query($sql2);
$row2 = mysql_fetch_array($query2);
$votos2 = $row2[votos];

$votar = $vota_post + $votos2;
$sql3 = "UPDATE enquete SET votos='$votar' WHERE opcao='$opcao_post'";
mysql_query($sql3) or die("sdaf");
echo"
<meta HTTP-EQUIV=refresh Content='0; url=index.php?canais=default'>
<font face='$font_face' color='$cor_txt' size='$tam_2'>";
echo"<b>Voto Processado";
}
?>