#Execute esses comandos no phpMyAdmin
#� So Colar

CREATE TABLE enquete (
  id int(11) NOT NULL auto_increment,
  opcao varchar(50) NOT NULL default '',
  votos varchar(10) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Extraindo dados da tabela `enquete`
#

INSERT INTO enquete VALUES (1, '�timo', '0');
INSERT INTO enquete VALUES (2, 'Legal', '0');
INSERT INTO enquete VALUES (3, 'Mais ou Menos', '0');
INSERT INTO enquete VALUES (4, 'Ruim', '0');
INSERT INTO enquete VALUES (5, 'P�ssimo', '0');
INSERT INTO enquete VALUES (6, 'Sem Opini�o', '0');

