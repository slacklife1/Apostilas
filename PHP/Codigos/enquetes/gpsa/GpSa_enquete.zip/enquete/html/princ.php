<?
echo"
<br><table width='90%' border='0' cellspacing='1' cellPadding='0' bgcolor='#666666' style='border: 1px' bordercolor='#ffffff' align='center'>
<tr>
<td bodercolor='#ffffff' valign='top' align='center' background='$fundo_de_tabela_2' width='50%'>
<font face='$face_1' size='$tam_2' color='$cor_1'>
<b>:: Novidades ::
</td>

<td bodercolor='#ffffff' valign='top' align='center' background='$fundo_de_tabela_2' width='50%'>
<font face='$face_1' size='$tam_2' color='$cor_1'>
<b>:: Enquete ::
</td>
</tr>

<tr>
<td bgcolor='#ffffff' valign='top'>
<font face='$face_1' size='$tam_2' color='$cor_1'>
";
$sql_novid="Select * from novidades";
$query_novid=mysql_query($sql_novid);

echo"
</td>

<td bgcolor='#ffffff' valign='top'>
<font face='$face_1' size='$tam_2' color='$cor_1'>";
include "enquete.php";
echo"
</td>
</tr>
</table><br>";