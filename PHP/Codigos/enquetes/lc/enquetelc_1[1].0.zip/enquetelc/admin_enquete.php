<?php

 /*Recupera o valor do arquivo dados.txt para escrev�-los no formul�rio de enquete*/
 $id = fopen("dados.txt", "r+");
 $dados = fread($id,filesize("dados.txt"));
 $array_dados = split("/", $dados);
 list($pergunta, $opcao1, $opcao2, $opcao3, $opcao4, $opcao5, $r1, $r2, $r3, $r4, $r5) = $array_dados;
 fclose($id);


echo('<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>EDITAR ENQU�TE</title>
</head>

<body>

<p align="center"><span style="color: #3366FF; font-family: Verdana; font-size: 18pt">EDITAR
ENQUETE</span></p>
<p align="center"><span style="color: #3366FF; font-family: Verdana; font-size: 18pt">Crie
e modifique aqui sua enq�ete:&nbsp;</span></p>
<p align="center">&nbsp;</p>
<form method="POST" action="cria_enquete.php">

  <p align="left"><span style="font-family: Verdana; font-size: 10.0pt"><b>Pergunta:
  <input type="text" name="pergunta" size="90" value="'.$pergunta.'"></b></span></p>
  <table border="0" cellpadding="0" cellspacing="0" width="638" bordercolor="#FFFFFF" bordercolorlight="#FFFFFF" bordercolordark="#FFFFFF">
    <tr>
      <td width="503">
        <p align="left"><span style="font-family: Verdana; font-size: 10.0pt"><b>Op��o
        1: <input type="text" name="opcao1" size="62" value="'.$opcao1.'"></b></span></td>
      <td width="131"><span style="font-family: Verdana; font-size: 10.0pt"><b>votos:
        <input type="text" name="r1" size="10" value='.$r1.'></b></span></td>
    </tr>
    <tr>
      <td width="503">
        <p align="left"><span style="font-family: Verdana; font-size: 10.0pt"><b>Op��o
        2: <input type="text" name="opcao2" size="62" value="'.$opcao2.'"></b></span></td>
      <td width="131"><span style="font-family: Verdana; font-size: 10.0pt"><b>votos:
        <input type="text" name="r2" size="10" value='.$r2.'></b></span></td>
    </tr>
    <tr>
      <td width="503">
        <p align="left"><span style="font-family: Verdana; font-size: 10.0pt"><b>Op��o
        3: <input type="text" name="opcao3" size="62" value="'.$opcao3.'"></b></span></td>
      <td width="131"><span style="font-family: Verdana; font-size: 10.0pt"><b>votos:
        <input type="text" name="r3" size="10" value='.$r3.'></b></span></td>
    </tr>
    <tr>
      <td width="503">
        <p align="left"><span style="font-family: Verdana; font-size: 10.0pt"><b>Op��o
        4: <input type="text" name="opcao4" size="62" value="'.$opcao4.'"></b></span></td>
      <td width="131"><span style="font-family: Verdana; font-size: 10.0pt"><b>votos:
        <input type="text" name="r4" size="10" value='.$r4.'></b></span></td>
    </tr>
    <tr>
      <td width="503">
        <p align="left"><span style="font-family: Verdana; font-size: 10.0pt"><b>Op��o
        5: <input type="text" name="opcao5" size="62" value="'.$opcao5.'"></b></span></td>
      <td width="131"><span style="font-family: Verdana; font-size: 10.0pt"><b>votos:
        <input type="text" name="r5" size="10" value='.$r5.'></b></span></td>
    </tr>
  </table>
  <p align="center"><input type="submit" value="Salvar " name="B1"></p>
</form>

</body>
');
?>
