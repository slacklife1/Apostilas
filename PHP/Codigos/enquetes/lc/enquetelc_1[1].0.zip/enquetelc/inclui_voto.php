<?php

/*Recupera o valor da vari�vel global voto do formul�rio enquete.php*/
global $voto;

 if ($voto == "")
 {
  echo('<p align="center"><span style="color: #3366FF; font-family: Verdana; font-size: 18pt">VOC� N�O FEZ SUA ESCOLHA !</span></p>');
  echo('<p align="center"><a href="enquete.php"><< voltar</a></p>');
  die;
 }

 /*Recupera o valor do arquivo dados.txt para escrev�-los no formul�rio de enquete*/
 $id = fopen("dados.txt", "r+");
 $dados = fread($id,filesize("dados.txt"));
 $array_dados = split("/", $dados);
 list($pergunta, $opcao1, $opcao2, $opcao3, $opcao4, $opcao5, $r1, $r2, $r3, $r4, $r5) = $array_dados;
 fclose($id);
 
 if ($voto == "1") $r1 = $r1 + 1;
 if ($voto == "2") $r2 = $r2 + 1;
 if ($voto == "3") $r3 = $r3 + 1;
 if ($voto == "4") $r4 = $r4 + 1;
 if ($voto == "5") $r5 = $r5 + 1;
 
 /*Inclui um separador entre os dados do array*/
 $pergunta = $pergunta.'/';
 $opcao1 = $opcao1.'/';
 $opcao2 = $opcao2.'/';
 $opcao3 = $opcao3.'/';
 $opcao4 = $opcao4.'/';
 $opcao5 = $opcao5.'/';
 $r1 = $r1.'/';
 $r2 = $r2.'/';
 $r3 = $r3.'/';
 $r4 = $r4.'/';
 
 $dados = ($pergunta.$opcao1.$opcao2.$opcao3.$opcao4.$opcao5.$r1.$r2.$r3.$r4.$r5);

 /*Abre o arquivo dados.txt e insere os novos dados*/
 $id = fopen("dados.txt", "w+");
 fputs($id,$dados);
 fclose($id);
 
 echo('<p align="center"><span style="color: #3366FF; font-family: Verdana; font-size: 18pt">VOTO COMPUTADO COM SUCESSO !</span></p>');
 echo('<p align="center"><a href="ver_votos.php">ver votos >></a></p>');
?>
