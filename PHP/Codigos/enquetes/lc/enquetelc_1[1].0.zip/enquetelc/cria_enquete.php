<?php

/*Recupera as vari�veis globais do formul�rio admin.php*/
global $pergunta;
global $opcao1;
global $opcao2;
global $opcao3;
global $opcao4;
global $opcao5;
global $r1;
global $r2;
global $r3;
global $r4;
global $r5;

 /*Insere um separador entre os dados do array*/
 $pergunta = $pergunta.'/';
 $opcao1 = $opcao1.'/';
 $opcao2 = $opcao2.'/';
 $opcao3 = $opcao3.'/';
 $opcao4 = $opcao4.'/';
 $opcao5 = $opcao5.'/';
 $r1 = $r1.'/';
 $r2 = $r2.'/';
 $r3 = $r3.'/';
 $r4 = $r4.'/';

 $dados = ($pergunta.$opcao1.$opcao2.$opcao3.$opcao4.$opcao5.$r1.$r2.$r3.$r4.$r5);

 /*Abre o arquivo dados.txt e insere os novos dados*/
 $id = fopen("dados.txt", "w+");
 fputs($id,$dados);
 fclose($id);
 
 echo('<p align="center"><span style="color: #3366FF; font-family: Verdana; font-size: 18pt">ENQUETE CRIADA COM SUCESSO !</span></p>');
 echo('<p align="center"><a href="enquete.php">ver enquete >></a></p>');
?>
