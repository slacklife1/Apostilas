<?php

 /*Recupera o valor do arquivo dados.txt para escrev�-los no formul�rio de enquete*/
 $id = fopen("dados.txt", "r+");
 $dados = fread($id,filesize("dados.txt"));
 $array_dados = split("/", $dados);
 list($pergunta, $opcao1, $opcao2, $opcao3, $opcao4, $opcao5, $r1, $r2, $r3, $r4, $r5) = $array_dados;
 fclose($id);

echo('<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>ENQU�TE LC</title>
</head>

<body>

<p align="center"><span style="color: #3366FF; font-family: Verdana; font-size: 18pt">ENQUETE
LC</span></p>

<table border="1" cellpadding="0" cellspacing="0" width="100%" bordercolor="#0099CC" bordercolorlight="#FFFFFF" bordercolordark="#0099CC"
 height="203">
  <tr>
    <td width="80%" height="43" valign="middle">&nbsp;<b><span style="font-family: Verdana; font-size: 10.0pt"><i>&nbsp; </i>'.$pergunta.'
    </span></b></td>
    <td width="20%" height="43" valign="middle">
      <p align="center"><b><span style="font-family: Verdana; font-size: 10.0pt">N�
      de votos</span></b>
    </td>
  </tr>
  <tr>
    <td width="80%" height="19" valign="middle"><b><span style="font-family: Verdana; font-size: 10.0pt">&nbsp; '.$opcao1.'</span></b></td>
    <td width="20%" align="center" height="19" valign="middle"><b>'.$r1.'</b></td>
  </tr>
  <tr>
    <td width="80%" height="19" valign="middle"><b><span style="font-family: Verdana; font-size: 10.0pt">&nbsp; '.$opcao2.'</span></b></td>
    <td width="20%" align="center" height="19" valign="middle"><b>'.$r2.'</b></td>
  </tr>
  <tr>
    <td width="80%" height="19" valign="middle"><b><span style="font-family: Verdana; font-size: 10.0pt">&nbsp; '.$opcao3.'</span></b></td>
    <td width="20%" align="center" height="19" valign="middle"><b>'.$r3.'</b></td>
  </tr>
  <tr>
    <td width="80%" height="19" valign="middle"><b><span style="font-family: Verdana; font-size: 10.0pt">&nbsp; '.$opcao4.'</span></b></td>
    <td width="20%" align="center" height="19" valign="middle"><b>'.$r4.'</b></td>
  </tr>
  <tr>
    <td width="80%" height="19" valign="middle"><b><span style="font-family: Verdana; font-size: 10.0pt">&nbsp; '.$opcao5.'</span></b></td>
    <td width="20%" align="center" height="19" valign="middle"><b>'.$r5.'</b></td>
  </tr>
</table>

</body>
');
?>
