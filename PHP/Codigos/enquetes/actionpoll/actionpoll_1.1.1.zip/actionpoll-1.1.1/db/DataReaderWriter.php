<?php

include($CONFIG_DB);

class DataReaderWriter extends Db {

  var $internalTitle;

  function DataReaderWriter($internalTitle) {
    $this->Db();
    $this->internalTitle = $internalTitle;
    $this->classname .= "::DataReaderWriter";
  }

  function get_Poll() {
    $this->sql = sprintf("select id,summary,title,startValue,maxValue,action,ipBan,cookies from Poll where InternalTitle = '%s'",$this->internalTitle);
    $tmp = $this->get_array();
    return $tmp[0];
  }

  function get_PollData($pollId) {
    $this->sql = sprintf("select itemText as item, counter from PollData where pollId = '%s'",$pollId);
    return $this->get_objects();
  }

  function get_PollBan($pollId,$itemId) {
    $this->sql = sprintf("select ip from PollBan where pollId = '%s' and itemId = '%s'",
			 $pollId,
			 $itemId);
    //    printf("<h1>%s</h1>",$this->sql);
    $tmp = $this->get_array();
    // FIXXMEE HACK BEGIN (not proud of that one)
				// problem is that I don't know how to 
				// convert arrays to objects
    for ($i=0;$i<count($tmp);$i++) {
      $tmpQuickHack[] = $tmp[$i][0];
    }
    
    if (count($tmp) == 0) {
      return array(); // if there are no previous polls, return empty array
    } else {
      return $tmpQuickHack;
    }
    // FIXXMEE HACK END
  }

  function riseCounterAtElement($pollId,$itemId) {
    $this->sql = sprintf("update PollData set counter = counter+1 where pollId = '%s' and itemId = '%s'",
			 $pollId,
			 $itemId);
    $this->db_query();
  }

  function writeIP($pollId,$itemId,$ip) {

    $this->sql = sprintf("insert into PollBan values ('','%s','%s','%s',now())",
			 $pollId,
			 $itemId,
			 $ip);
    $this->db_query();
    
  }
}	

?>
