<?php

// connects to the database

class Db { 
  
  var $config_debug = $CONFIG_DEBUGMODE;   
  var $classname = "Db"; 

  var $host      = $CONFIG_DBHOST;
  var $database  = $CONFIG_DBNAME;
  var $username  = $CONFIG_DBUSER;
  var $password  = $CONFIG_DBPASS;

  var $dbh;    // database handle

  function Db () {
    $this->dbh = mysql_pconnect($this->host,$this->username,$this->password);
  }

  function handle_error($result) {
    if($result == 0) {
      if ($this->config_debug) printf ("<br><b>%s ERROR: '%s' has caused following error: <br> %s %s<br>\n",
					$this->classname,
				        $this->sql,
					mysql_errno(),
					mysql_error());
    }
  }

  function get_objects() {
    $result = mysql_db_query($this->database,$this->sql,$this->dbh);
    $this->handle_error($result);
    while($row = mysql_fetch_object($result)) {
      $objects[] = $row;
    }
    mysql_free_result($result);
    return $objects;
  }

  function get_array() {
    $result = mysql_db_query($this->database,$this->sql,$this->dbh);
    $this->handle_error($result);
    while($row = mysql_fetch_array($result)) {
      $array[] = $row;
    }
    mysql_free_result($result);
    return $array;
  }

  // for update operations
  function db_query() { 
    $result = mysql_db_query($this->database,$this->sql,$this->dbh);
    $this->handle_error($result);
  }

}

?>
