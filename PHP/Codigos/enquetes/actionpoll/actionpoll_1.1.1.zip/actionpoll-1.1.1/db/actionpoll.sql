# MySQL dump 6.0
#
# Host: localhost    Database: actionpoll
#--------------------------------------------------------
# Server version	3.22.25
create database actionpoll;
connect actionpoll;

#
# Table structure for table 'Poll'
#
CREATE TABLE Poll (
  id int(11) DEFAULT '0' NOT NULL auto_increment,
  InternalTitle varchar(255) DEFAULT '' NOT NULL,
  summary varchar(255),
  title varchar(255),
  startValue tinyint(4),
  maxValue int(11),
  action tinyint(4),
  ipBan tinyint(4),
  cookies tinyint(4),
  date timestamp(14),
  UNIQUE InternalTitle (InternalTitle),
  PRIMARY KEY (id)
);

#
# Dumping data for table 'Poll'
#

INSERT INTO Poll VALUES (1,'ExamplePollEntry','Number of votes:','Title of poll',0,50,1,0,0,20000825150001);
INSERT INTO Poll VALUES (2,'secondexample','Number of votings:','This is the Title of the second example',0,10,0,0,0,20000825130309);
INSERT INTO Poll VALUES (3,'PollThing','Number of votes:','How do you rate this script?',0,100,0,0,0,20000825170623);

#
# Table structure for table 'PollBan'
#
CREATE TABLE PollBan (
  id int(11) DEFAULT '0' NOT NULL auto_increment,
  pollId int(11),
  itemId int(11) DEFAULT '0' NOT NULL,
  ip varchar(100),
  datum timestamp(14),
  PRIMARY KEY (id)
);

#
# Dumping data for table 'PollBan'
#

INSERT INTO PollBan VALUES (1,2,4,'ppc464.joanneum.ac.at',20000825154752);
INSERT INTO PollBan VALUES (2,2,4,'localhost',20000825154835);
INSERT INTO PollBan VALUES (3,2,4,'localhost',20000825155404);
INSERT INTO PollBan VALUES (4,2,4,'localhost',20000825155521);
INSERT INTO PollBan VALUES (5,2,4,'localhost',20000825155542);
INSERT INTO PollBan VALUES (6,2,4,'localhost',20000825155717);
INSERT INTO PollBan VALUES (7,2,1,'localhost',20000825155832);
INSERT INTO PollBan VALUES (8,2,0,'ppc464.joanneum.ac.at',20000825161118);
INSERT INTO PollBan VALUES (9,2,0,'ppc464.joanneum.ac.at',20000825161122);
INSERT INTO PollBan VALUES (10,2,0,'ppc464.joanneum.ac.at',20000825161123);
INSERT INTO PollBan VALUES (11,2,0,'ppc464.joanneum.ac.at',20000825161123);
INSERT INTO PollBan VALUES (12,2,0,'ppc464.joanneum.ac.at',20000825161124);
INSERT INTO PollBan VALUES (13,2,2,'localhost',20000825161319);
INSERT INTO PollBan VALUES (14,2,1,'localhost',20000825161502);
INSERT INTO PollBan VALUES (15,2,3,'localhost',20000825161634);
INSERT INTO PollBan VALUES (16,2,2,'localhost',20000825162531);
INSERT INTO PollBan VALUES (17,2,1,'ppc464.joanneum.ac.at',20000825163350);
INSERT INTO PollBan VALUES (18,2,3,'ppc464.joanneum.ac.at',20000825163407);
INSERT INTO PollBan VALUES (19,3,0,'localhost',20000825171251);
INSERT INTO PollBan VALUES (20,3,5,'ppc464.joanneum.ac.at',20000825171322);
INSERT INTO PollBan VALUES (21,3,5,'ppc464.joanneum.ac.at',20000825171359);
INSERT INTO PollBan VALUES (22,3,0,'localhost',20000825171548);
INSERT INTO PollBan VALUES (23,3,0,'localhost',20000825171614);
INSERT INTO PollBan VALUES (24,3,0,'localhost',20000825171628);
INSERT INTO PollBan VALUES (25,3,0,'localhost',20000825171641);
INSERT INTO PollBan VALUES (26,3,5,'ppc464.joanneum.ac.at',20000825171645);

#
# Table structure for table 'PollData'
#
CREATE TABLE PollData (
  id int(11) DEFAULT '0' NOT NULL auto_increment,
  pollId int(11) DEFAULT '0' NOT NULL,
  itemId int(11) DEFAULT '0' NOT NULL,
  counter int(11) DEFAULT '0' NOT NULL,
  itemText varchar(255),
  datum timestamp(14),
  KEY id (id),
  PRIMARY KEY (pollId,itemId)
);

#
# Dumping data for table 'PollData'
#

INSERT INTO PollData VALUES (1,1,0,4,'first item',20000825145754);
INSERT INTO PollData VALUES (2,1,1,4,'second item',20000825145744);
INSERT INTO PollData VALUES (3,1,2,3,'third item',20000825145832);
INSERT INTO PollData VALUES (4,1,3,4,'fourth item',20000825145917);
INSERT INTO PollData VALUES (5,2,0,6,'text of second poll first option',20000825161124);
INSERT INTO PollData VALUES (6,2,1,6,'text of second poll second option',20000825163350);
INSERT INTO PollData VALUES (7,2,2,3,'text of second poll third option',20000825162531);
INSERT INTO PollData VALUES (8,2,3,4,'text of second poll fourth option',20000825163407);
INSERT INTO PollData VALUES (9,2,4,8,'text of second poll fifth option',20000825155717);
INSERT INTO PollData VALUES (10,3,0,5,'Excellent',20000825171641);
INSERT INTO PollData VALUES (11,3,1,0,'Very good',20000825170710);
INSERT INTO PollData VALUES (12,3,2,0,'Good',20000825170723);
INSERT INTO PollData VALUES (13,3,3,0,'Average',20000825170728);
INSERT INTO PollData VALUES (14,3,4,0,'Poor',20000825170739);
INSERT INTO PollData VALUES (15,3,5,3,'Lousy',20000825171645);
INSERT INTO PollData VALUES (16,3,6,0,'rot in hell',20000825170843);

