<?php

include($CONFIG_DATAREADERWRITER);

class PollDB { 
 
  var $polldata;

  var $pollInternalTitle;
  var $pollId;     // number of poll
  var $pollSummaryText = "Number of votes: ";
  var $pollTitle = "Polltitle";
  var $pollStartValue = 0;
  var $pollMaxValue   = 10;
  var $performAction  = 1;
  var $performIPBan   = 0;
  var $cookies; // not yet implemented

  var $dr; //datareader

  function PollDB($pollInternalTitle) {
    $this->pollInternalTitle = $pollInternalTitle;
    $this->dr = new DataReaderWriter($pollInternalTitle);
    // initalize static variables
    list($this->pollId,
	 $this->pollSummaryText,
	 $this->pollTitle,
	 $this->pollStartValue,
	 $this->pollMaxValue,
	 $this->performAction,
	 $this->performIPBan,
	 $this->cookies) = $this->dr->get_Poll();
    // now read the pollData and put it in an array
    
    $pData = $this->dr->get_PollData($this->pollId);

    for ($i=0; $i<count($pData); $i++) {
      $this->polldata[] = array (
				 "item" => $pData[$i]->item,
				 "counter" => $pData[$i]->counter,
				 "ips" => $this->dr->get_PollBan($this->pollId,$i)
				 );

    }

  }

  function riseCounter($itemId) {
    $this->dr->riseCounterAtElement($this->pollId,$itemId);
  }
  
  function writeIP($itemId,$ip) {
    $this->dr->writeIP($this->pollId,$itemId,$ip);
  }
}
?>
