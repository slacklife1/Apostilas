<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<html>
  <head>
    <LINK rel=stylesheet type="text/css" href="pollstyle.css">
    <title>Actionpoll by ladstaetter robert</title>
  </head>

  <body bgcolor=white>
    <h1>Actionpoll</h1>

    <p>
      Actionpoll implements an ordinary voting system in 
      <a href="http://www.php.net">PHP</a>.
    </p>

    <h2>Features</h2>

    <ul>
      <li>written in PHP</li>
      <li>mysql database support</li>
      <li>
	for those who don't have access to a mysql database,
	there is an opinional <b>text configuration</b>
      </li>
      <li>unlimited options</li>
      <li>easy configurable for your site through css</li>
      <li>no multiple votes through ip tracking</li>
      <li>
	if a certain number of votes for one option is reached, 
	an arbitrary action takes place.
      </li>
      <li>
        more polls on one html site
      </li>
      <li>logging of domain names of voters</li>
      <li>...</li>
    </ul>

    <h2>Missing features</h2>

    <ul>
      <li>cookies support (next thing to do)</li>
      <li>remote administration via web</li>
      <li>grouping of polls</li>
      <li>statistics of past polls</li>
      <li>xml support</li>
    </ul>

    <h2>Yeah, but how does it look like?</h2>
    <p>
      At the bottom of the page you will find a poll.<br><br>
    <a href="./example.php">Here</a> is an <a href="./example.php">example</a> of multiple polls on
    one website. (a feature which is quite handy if you have to make a survey)
    </p>



    <h2>WML Output</h2>

    <p>
      This poll includes also an output for WML - if you look at the sources
      you will realize that other output can be added without rewriting the
      whole script. I've tested the output with a Nokia 7110, but since WAP
      is rather unstable (or the implementations of the browsers) you almost
      certainly have to make some minor changes.
    </p>

    <h2>License</h2>

    <p>
      The program is licensed under GPL, but it would be nice if you
      would send me the address of your site so that I could track how
      many sites use it. It is common practice however to leave the
      copyright notice untouched ;-).
    </p>

    <h2>Bugs</h2>
    <p>
      Almost certainly there are some, I tested it with Linux/Apache/PHP4 and
      Netscape & Mickeymouse Exploder (>=V4). Opera/Konqueror/Mozilla shouldn't
      have problems with it.
    </p>

    <h2>Download</h2>

    <p>
      Actionpoll in tar.gz Format: <a href="./actionpollV1_1_0.tar.gz">actionpollV1_1_0.tar.gz</a>. (latest version)<br>
      Actionpoll in zip Format: <a href="./actionpollV1_1_0.zip">actionpollV1_1_0.zip</a>.
    </p>

    <p>
      Actionpoll in tar.gz Format: <a href="./actionpollV1_0_0.tar.gz">actionpollV1_0_0.tar.gz</a>.<br>
      Actionpoll in zip Format: <a href="./actionpollV1_0_0.zip">actionpollV1_0_0.zip</a>.
    </p>

    <h2>Sites that use actionpoll</h2>

    <ul>
      <!-- <li><a href="http://burglift.stmk.gv.at">http://burglift.stmk.gv.at</a> coming soon ... </li> -->
<!--    <li><a href="http://"></a></li> -->
    <li><a href="http://www.rtbf.be/capitale/">http://www.rtbf.be/capitale/</a></li>
    <li><a href="http://tintinabar.gameseek.com">http://tintinabar.gameseek.com</a></li>
	<li>If you use, like, dislike the script _please_ mail me your www - address, so I can put it up here. I'm happy with the feedback, and will release a new version soon (mysql/xml/cookies support planned).</li>
    </ul>

  </body>
</html>
