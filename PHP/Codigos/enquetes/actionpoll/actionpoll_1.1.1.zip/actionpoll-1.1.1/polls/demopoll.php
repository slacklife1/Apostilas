<?php
// This is a generated file by actionpoll V1.2.0
class PollData { 
 var $polldata = array (
		array(
			"item" => "Zweiter Stock",
			"counter" => 3,
			"ips" => array("","cacheserv.univ-lille1.fr","cacheserv.univ-lille1.fr","cacheserv.univ-lille1.fr"),
			"timestamp" => array("","980506943","980506968","980506990")
		),
		array(
			"item" => "Erster Stock",
			"counter" => 0,
			"ips" => array(""),
			"timestamp" => array("")
		),
		array(
			"item" => "Zwischenstock",
			"counter" => 0,
			"ips" => array(""),
			"timestamp" => array("")
		),
		array(
			"item" => "Paterre",
			"counter" => 0,
			"ips" => array(""),
			"timestamp" => array("")
		));
  var $pollSummaryText = "Sooft wurde gew&auml;hlt: ";
  var $pollTitle = "Lift in Stockwerk schicken";
  var $pollDenyMessage = "Already voted! Come back later!";
  var $pollInternalTitle = "burgvote";
  var $pollStartValue = 0;
  var $pollMaxValue   = 4;
  var $pollTimeGap    = 20;
  var $performAction  = 1;
  var $performIPBan   = 1;
}
?>
