<?php 

include("./actionpoll.php");
// include("./data/demopoll.php");
// you should place the following code into your web site:

// ... at some convenient point ...
print("<LINK rel=stylesheet type=\"text/css\" href=\"" . $CONFIG_STYLESHEET . "\">");
//
// include("/path/to/actionpoll.php");
//
// [.. garbage ..]
//   $myPolltxt = new HTMLActionPoll(new PollData());
//   if (strlen($pollVotedItem) != 0) {
//     $myPolltxt->process($pollVotedItem);
//   } else {
//      printf("<table cellspacing=10 align=center><tr><td valign=top>%s</td><td valign=top>%s</td></tr></table>",
//  	   $myPolltxt->showPoll(),
//  	   $myPolltxt->showVote());
//   }
// [.. garbage ..]
//

// or, use the DBHTMLActionPoll Class :)

$data = new PollData();

$myPoll = new HTMLActionPoll($data);

// printf("vorher"); 
// printf($myPoll->showVote());
// printf("nachher");
// printf($myPoll->getDebugHTML());
 
if (strlen($burgvote) != 0) {
   $myPoll->process($burgvote);
 } else {
  printf($myPoll->getShowHTMLMessage());
  printf($myPoll->getVoteHTMLMessage());
 }
                                                                                                                        
//   $myPoll = new DBHTMLActionPoll(new PollDB("ExamplePollEntry"));
//   if (strlen($ExamplePollEntry) != 0) {
//     $myPoll->process($ExamplePollEntry);
//   } else {
//     printf("<table cellspacing=10 align=center><tr><td valign=top>%s</td><td valign=top>%s</td></tr></table>",
// 	   $myPoll->showPoll(),
// 	   $myPoll->showVote());
//   }

//  $Polltwo = new DBHTMLActionPoll(new PollDB("secondexample"));
//  if (strlen($secondexample) != 0) {
//    $Polltwo->process($secondexample);
//  } else {
//    printf("<table cellspacing=10 align=center><tr><td valign=top>%s</td><td valign=top>%s</td></tr><tr><td colspan=2 align=center><form><textarea rows=20 cols=50>%s</textarea></td></tr></table>",
//	   $Polltwo->showPoll(),
//	   $Polltwo->showVote(),
//	   $Polltwo->generateConfigFile_());
//  }

?>
