<?php 

// this file is responsible for the main configuration of actionpoll 

// root path of actionpoll package
$CONFIG_BASEROOT = "/home/lad/public_html/tmp/actionpoll-1.1.1";

// www root path
$CONFIG_WWWROOT = "/~lad/tmp/actionpoll-1.1.1";
$CONFIG_STYLESHEET = $CONFIG_WWWROOT . "/pollstyle.css";

$CONFIG_PIXEL = $CONFIG_WWWROOT . "/gifs/grpx.gif";
$CONFIG_IMAGEHEIGHT = 10;
$CONFIG_IMAGESCALE = 3;

// paths for text mode
$CONFIG_TEXTCONFIG = $CONFIG_BASEROOT . "/polls/demopoll.php";

// paths for database mode
$CONFIG_POLLDB = $CONFIG_BASEROOT . "/db/PollDB.php";
$CONFIG_DATAREADERWRITER = $CONFIG_BASEROOT . "/db/DataReaderWriter.php";
$CONFIG_DB = $CONFIG_BASEROOT . "/db/Db.php";

// configuration for database
$CONFIG_DBHOST = "localhost";
$CONFIG_DBNAME = "actionpoll";
$CONFIG_DBUSER = "actionpoll";
$CONFIG_DBPASS = "";

// show debug messages
$CONFIG_DEBUGMODE = true;

// for bar graphics
?>
