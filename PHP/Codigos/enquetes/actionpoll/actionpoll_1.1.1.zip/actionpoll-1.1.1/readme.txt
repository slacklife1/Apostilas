                     _   _                         _ _
           __ _  ___| |_(_) ___  _ __  _ __   ___ | | |
          / _` |/ __| __| |/ _ \| '_ \| '_ \ / _ \| | |
         | (_| | (__| |_| | (_) | | | | |_) | (_) | | |
          \__,_|\___|\__|_|\___/|_| |_| .__/ \___/|_|_|
                                      |_|
                                      
ActionPoll V1.1.1 (c) robert ladstaetter <ladi@sbox.tugraz.at>

This software implements a poll system based on PHP. Documentation is
available directly in the source example.php  and actionpoll.php.

THIS SOFTWARE IS ONLY BETA. 	

I wrote this some time ago, but I never released it. It contains many 
bugs and is incomplete. It contains some new features compared to
actionpoll V1.1.0, and cleaner code. It does not have support for mySQL
yet, but it would be easy to include it and it will be in V1.2.0 
if I have time.

You have to make sure that the paths and the ownerrights are correct.
