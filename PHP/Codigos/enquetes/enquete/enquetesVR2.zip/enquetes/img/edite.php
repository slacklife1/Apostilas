<?
include "config.php";
echo "<form name='form1' method='post' action='montaenquete.php'>";
echo "        <br>Pergunta da enquete:";
echo "        <br>";
echo "        <input type='text' name='pergunta' value='$questao'>";
echo "        <br>Quantidade m�xima de op��es de reposta:";
echo "        <br>";
echo "        <input type='text' name='qtdrespostas' value='$qtdperguntas'>";
echo "        <br>Zerar banco de dados?<br>";
echo "        <input type='radio' name='resetarbancodedados' value='sim' >SIM";
echo "        <input type='radio' name='resetarbancodedados' value='nao' >N�O";
echo "        <br>";
echo "        <input type='submit' name='btgravar' value='Avan�ar >>'>";
echo "        <input type='reset' name='btresetar' value='Cancelar'>";
echo "</form>";
include "parametros.php";
echo "<form name='form2' method='post' action='gravaparametros.php'>";
echo "        <br>Quantidade m�xima de votos por pessoa:";
echo "        <br>";
echo "        <input type='text' name='qtd' value='$qtd'>";
echo "        <br>Quantidade de casas decimais:";
echo "        <br>";
echo "        <input type='text' name='dcm' value='$dcm'>";
echo "        <br>Deseja bot�es de submiss�o como imagens?<br>";
if ($botao_imagem==true)
{
  echo "        <input type='radio' name='botao_imagem' value='true' checked onclick=\"alert('N�o esque�a de certificar-se de que as imagens votar.jpg e resultados.jpg contidas na pasta img foram trocadas pela imagens de sua prefer�ncia!')\">SIM";
  echo "        <input type='radio' name='botao_imagem' value='false' >N�O";
}
else
{
  echo "        <input type='radio' name='botao_imagem' value='true' onclick=\"alert('N�o esque�a de certificar-se de que as imagens votar.jpg e resultados.jpg contidas na pasta img foram trocadas pela imagens de sua prefer�ncia!')\">SIM";
  echo "        <input type='radio' name='botao_imagem' value='false' checked >N�O";
};
echo "        <br>";
echo "        <br>Extens�o das imagens dos bot�es";
echo "        <br>";
echo "        <input type='text' name='extensao_dos_botoes' value='$extensao_dos_botoes'>";
echo "        <br>R�tulo do bot�o votar (caso na seja imagem)";
echo "        <br>";
echo "        <input type='text' name='rotulo_botao_votar' value='$rotulo_botao_votar'>";
echo "        <br>R�tulo do bot�o resultados (caso na seja imagem)";
echo "        <br>";
echo "        <input type='text' name='rotulo_botao_resultados' value='$rotulo_botao_resultados'>";
echo "        <br>Path do BD:";
echo "        <br>";
echo "        <input type='text' name='arq' value='$arq'>";
echo "        <br>Pasta onde est�o as 'Barras' de porcentagens:";
echo "        <br>";
echo "        <input type='text' name='img' value='$img'>";
echo "        <br>Altura das 'Barras' de portecentagens:";
echo "        <br>";
echo "        <input type='text' name='alt' value='$alt'>pixels";
echo "        <br>Deseja barras de porcentagem diferenciadas por cor?<br>";
if ($dif=='sim')
{
  echo "        <input type='radio' name='dif' value='sim' checked >SIM";
  echo "        <input type='radio' name='dif' value='nao' >N�O";
}
else
{
  echo "        <input type='radio' name='dif' value='sim'>SIM";
  echo "        <input type='radio' name='dif' value='nao' checked >N�O";
};
echo "        <br>";
echo "        <br>";
echo "        <br>";
echo "        <input type='submit' name='btgravar' value='Gravar'>";
echo "        <input type='reset' name='btresetar' value='Cancelar'>";
echo "</form>";
?>