<?
include "parametros.php";
include "config.php";
$zero="0\n";
$parametros="";
for ($x=1; $x<=$qtdrespostas; $x++)
{
  $parametros="$parametros$zero";
};
if ($resetarbancodedados=='sim')
{
  unlink("database.dtb");
  $arquivo = fopen ("database.dtb", "a+");
  fwrite($arquivo,$parametros);
  fclose($arquivo);
};
echo "$pergunta";
echo "<form name='form1' method='post' action='gravaenquete.php'>";
if ($qtdrespostas==count($opcoes))
{ 
  $i=0;
  while(list($key,$val)=each($opcoes))
  { $i++;
    echo "        <br>Op��o $i:";
    echo "        <br>";
    echo "<input type='text' name='resposta[$i]' value='$val'>";
  };
}
else
{
  for ($i=1; $i<=$qtdrespostas; $i++)
  {
    echo "        <br>Op��o $i:";
    echo "        <br>";
    echo "<input type='text' name='resposta[$i]' value='$key'>$val";
  };
};
echo "<input type='hidden' name='qtdopcoes' value='$qtdrespostas'>";
echo "<input type='hidden' name='pergunta' value='$pergunta'>";
echo "        <br>";
echo "<input type='submit' name='btgravar' value='Gravar'>";
echo "<input type='reset' name='btresetar' value='Cancelar'>";
echo "</form>";
echo "<form name='form2' method='post' action='gravaparametros.php'>";
echo "        <br>Quantidade m�xima de votos por pessoa:";
echo "        <br>";
echo "        <input type='text' name='qtd' value='$qtd'>";
echo "        <br>Quantidade de casas decimais:";
echo "        <br>";
echo "        <input type='text' name='dcm' value='$dcm'>";
echo "        <br>Path do BD:";
echo "        <br>";
echo "        <input type='text' name='arq' value='$arq'>";
echo "        <br>Pasta onde est�o as 'Barras' de porcentagens:";
echo "        <br>";
echo "        <input type='text' name='img' value='$img'>";
echo "        <br>Altura das 'Barras' de portecentagens:";
echo "        <br>";
echo "        <input type='text' name='alt' value='$alt'>pixels";
echo "        <br>Deseja barras de porcentagem diferenciadas por cor?<br>";
if ($dif=='sim')
{
  echo "        <input type='radio' name='dif' value='sim' checked >SIM";
  echo "        <input type='radio' name='dif' value='nao' >N�O";
}
else
{
  echo "        <input type='radio' name='dif' value='sim'>SIM";
  echo "        <input type='radio' name='dif' value='nao' checked >N�O";
};
echo "        <br>";
echo "        <br>";
echo "        <br>";
echo "        <input type='submit' name='btgravar' value='Gravar'>";
echo "        <input type='reset' name='btresetar' value='Cancelar'>";
echo "</form>";
?>