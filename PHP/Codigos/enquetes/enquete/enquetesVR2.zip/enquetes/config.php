<?
 include "parametros.php";
$qtd_maxima_de_votos=$qtd;
$casas_decimais=$dcm;
 if ($arq=='')
{
  $arquivo_texto="database.dtb";
}
 else
{
  $arquivo_texto="$arq/database.dtb";
};
$img_porc=$img;
$altura_da_barra=$alt;
$diferenciar_por_cores=$dif;
$opcoes=array('�timo','Maravilhoso');
$questao='O que voc� acha de hospedar seu site na Mensad?';
$qtdperguntas='2';
 ?>