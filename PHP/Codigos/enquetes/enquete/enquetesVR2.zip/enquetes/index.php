<html>
<body>

<?php

include "config.php";


// PROCESSAMENTO DOS VOTOS E EXIBI��O DA ENQUETE AP�S VOTOS PROCESSADOS
if ($processa==1)
{

  // LE O ARQUIVO ARMAZENANDO-O EM UMA ARRAY
  $arquivo_array = file($arquivo_texto); 

  if($resposta < count($opcoes))
  {
    $veia_resp = $arquivo_array[$resposta];
    // EXECUTA UMA BUSCA
    $veia_resp = preg_replace("/\n\r*/","",$veia_resp);
    // ACRESCENTA O VOTO +1 AOS VOTOS EXISTENTES PARA A OP��O ESCOLHIA
    $arquivo_array[$resposta] = ($veia_resp + 1)."\n";
    // AGRUPA ELEMENTOS DE UMA ARRAY EM UMA STRING
    $arquivo = join('',$arquivo_array);
    //ABRE O ARQUIVO
    $fp = fopen($arquivo_texto,"w");
    // EXECUTA UM BLOQUEIO MANUAL NO ARQUIVO
    flock($fp,1);
    // GRAVA NO ARQUIVO
    fputs($fp,$arquivo);
    // DESBLOQUEIA O ARQUIVO
    flock($fp,3);
    // FECHA O ARQUIVO
    fclose($fp);
  };
  
  // ABRE LOOP DE SOMAT�RIA DOS VOTOS
  while(list($key,$val) = each($arquivo_array))
  { 
    $total += $val;
  // FECHA LOOP DE SOMAT�RIA DOS VOTOS
  };

  // EXIBE A PERGUNTA EM QUEST�O
  echo "<p align='center'>$questao</p>";

  // ROTULA A TABELA DE RESULTADOS
  echo "<p align='center'><b>Resultados:</b></p>";

  // ABRE UMA TABELA EM HTML
  echo "<table cellpading=1 cellspacing=2 border=0>";

  // DEFINE CABE�ALHO DA TABELA
  echo "<tr><th>Respostas</th><th>Porcentagem</th><th>Votos</th></tr>";

  // ABRE LOOP DE LISTAGEM DE RESULTADOS
  while(list($key,$val)=each($opcoes))
  { 
    if ($total==0)
    {
      $porc = $arquivo_array[$key] * 100;
    }
    else
    {
      $porc = $arquivo_array[$key] * 100 / $total;
    };
    $porc_int = floor($porc);

    // FORMATA O N�MERO
    $porc_float = number_format($porc,$casas_decimais);

    $tp += $porc_float;

    if ($diferenciar_por_cores=='sim')
    {
      if ($porc_float<=33)
      {
        $barra='barra_0_33.gif';
      }
      else
      {
        if ($porc_float<=66)
        {
          $barra='barra_33_66.gif';
        }
        else
        {
          if ($porc_float<=100)
          {
            $barra='barra_66_100.gif';
          };
        };
      };
    }
    else
    {
      $barra='barra_0_100.gif';
    };

    echo "<tr><td>$opcoes[$key]</td>";
    echo "<td><img height='$altura_da_barra' width='$porc_int' src='$img_porc/$barra'>";
    echo "<div align='center'><b>$porc_float%</b></div></td>";
    echo "<td><div align='center'><b>$arquivo_array[$key]</b></div></td></tr>";

  // FECHA LOOP DE LISTAGEM DE RESULTADOS
  };

  // FECHA UMA TABELA EM HTML
  echo "</table>";

}

// PROCESSAMENTO DA EXIBI��O DOS RESULTADOS DA ENQUETE
else if ($processa==2)
{

  // LE O ARQUIVO ARMAZENANDO-O EM UMA ARRAY
  $arquivo_array = file($arquivo_texto); 

  // ABRE LOOP DE SOMAT�RIA DOS VOTOS
  while(list($key,$val) = each($arquivo_array))
  { 
    $total += $val;
  // FECHA LOOP DE SOMAT�RIA DOS VOTOS
  };

  // EXIBE A PERGUNTA EM QUEST�O
  echo "<p align='center'>$questao</p>";

  // ROTULA A TABELA DE RESULTADOS
  echo "<p align='center'><b>Resultados:</b></p>";

  // ABRE UMA TABELA EM HTML
  echo "<table cellpading=1 cellspacing=2 border=0>";

  // DEFINE CABE�ALHO DA TABELA
  echo "<tr><th>Respostas</th><th>Porcentagem</th><th>Votos</th></tr>";

  // ABRE LOOP DE LISTAGEM DE RESULTADOS
  while(list($key,$val)=each($opcoes))
  { 
    if ($total==0)
    {
      $porc = $arquivo_array[$key] * 100;
    }
    else
    {
      $porc = $arquivo_array[$key] * 100 / $total;
    };
    $porc_int = floor($porc);

    // FORMATA O N�MERO
    $porc_float = number_format($porc,$casas_decimais);

    $tp += $porc_float;

    if ($diferenciar_por_cores=='sim')
    {
      if ($porc_float<=33)
      {
        $barra='barra_0_33.gif';
      }
      else
      {
        if ($porc_float<=66)
        {
          $barra='barra_33_66.gif';
        }
        else
        {
          if ($porc_float<=100)
          {
            $barra='barra_66_100.gif';
          };
        };
      };
    }
    else
    {
      $barra='barra_0_100.gif';
    };

    echo "<tr><td>$opcoes[$key]</td>";
    echo "<td><img height='$altura_da_barra' width='$porc_int' src='$img_porc/$barra'>";
    echo "<div align='center'><b>$porc_float%</b></div></td>";
    echo "<td><div align='center'><b>$arquivo_array[$key]</b></div></td></tr>";

  // FECHA LOOP DE LISTAGEM DE RESULTADOS
  };

  // FECHA UMA TABELA EM HTML
  echo "</table>";

}

// PROCESSAMENTO DA EXIBI��O DA ENQUETE
else
{
  //DEFINE FUN��ES UTILIZADA NO PROCESSAMENTO DA ENQUETE
  echo "<script>function verifica(){ ";
  echo "if (document.enquete.selecionado.value=='false')";
  echo "{ ";
  echo "  document.enquete.selecionado.value='false'; ";
  echo "  alert('� preciso escolher uma das op��es!'); ";
  echo "  return false; ";
  echo "} ";
  echo "else ";
  echo "{ ";
  echo "  document.enquete.selecionado.value='false'; ";
  echo "  if (document.enquete.processa.value==1) ";
  echo "  { ";
  echo "    return DisplayInfo(); ";
  echo "  } ";
  echo "  else ";
  echo "  { ";
  echo "    return true; ";
  echo "  }; ";
  echo "}; ";
  echo "};</script>";

  echo "<script>function seleciona(){ ";
  echo "  document.enquete.selecionado.value='true'; ";
  echo "}; </script>";

  echo "<script>function processo(tipo){ ";
  echo "  document.enquete.processa.value=tipo; ";
  echo "  if (tipo==2)";
  echo "  {";
  echo "    document.enquete.selecionado.value='true'; ";
  echo "  };";
  echo "}; </script>";
  
  // INICIA MONTAGEM DA ESTRUTURA E EXIBI�AO DA ENQUETE
  echo "<form name='enquete' method='post' onSubmit='return verifica()'>";
  echo "<INPUT TYPE='hidden' name='processa' value='nenhum processo'>";
  echo "<INPUT TYPE='hidden' name='selecionado' value='false'>";
  echo "<table width='100%' border='0'>";

  //EXIBE A PERGUNTA EM QUEST�O
  echo "<tr><td><p align='center'>$questao</p></td></tr>";

  // ABRE LOOP QUE EXIBE OPCOES DE RESPOSTA
  while(list($key,$val)=each($opcoes))
  {
    echo "<tr><td>";
    echo "<input type='radio' name='resposta' value='$key' onClick='seleciona()'>$val";
    echo "</td></tr>";
  }
  //FECHA LOOP QUE EXIBE OPCOES DE RESPOSTA

  // VERIFICA E EXIBE TIPO DE BOT�O DE SUBMISS�O ESCOLHIDO PELO WEBMASTER
  if ($botao_imagem==true)
  {
    echo "<tr><td>";
    echo "<p align='center'>";
    echo "<input type='image' border='0' src='img/votar.$extensao_dos_botoes' onclick='processo(1)'>";
    echo "</p>";
    echo "</td></tr>";
    echo "<tr><td>";
    echo "<p align='center'>";
    echo "<input type='image' border='0' src='img/resultados.$extensao_dos_botoes' onclick='processo(2)'>";
    echo "</p>";
    echo "</td></tr>";
    echo "</form>";
  };
  if ($botao_imagem!=true)
  {
    echo "<tr><td>";
    echo "<p align='center'>";
    echo "<input type='submit' name='votar' value='$rotulo_botao_votar' onClick='processo(1)'>";
    echo "</p>";
    echo "</td></tr>";
    echo "<tr><td>";
    echo "<p align='center'>";
    echo "<input type='submit' name='resultados' value='$rotulo_botao_resultados' onClick='processo(2)'>";
    echo "</p>";
    echo "</td></tr>";
    echo "</form>";
  };

};

?>

<Script>
<!-- Activate Cloaking
function getCookieVal (offset)
   {
   var endstr = document.cookie.indexOf (";", offset);
   if (endstr == -1)
      endstr = document.cookie.length;
   return unescape(document.cookie.substring(offset, endstr));
   }
function GetCookie (name)
   {
   var arg = name + "=";
   var alen = arg.length;
   var clen = document.cookie.length;
   var i = 0;
   while (i < clen)
      {
      var j = i + alen;
      if (document.cookie.substring(i, j) == arg)
         return getCookieVal (j);
      i = document.cookie.indexOf(" ", i) + 1;
      if (i == 0)
         break;
      }
   return null;
   }
function SetCookie (name, value)
   {
   var argv = SetCookie.arguments;
   var argc = SetCookie.arguments.length;
   var expires = (2 < argc) ? argv[2] : null;
   var path = (3 < argc) ? argv[3] : null;
   var domain = (4 < argc) ? argv[4] : null;
   var secure = (5 < argc) ? argv[5] : false;
   document.cookie = name + "=" + escape (value) +
     ((expires == null) ? "" : ("; expires=" + expires.toGMTString())) +
     ((path == null) ? "" : ("; path=" + path)) +
     ((domain == null) ? "" : ("; domain=" + domain)) +
	((secure == true) ? "; secure" : "");
   }
function DisplayInfo()
   {
   var expdate = new Date();
   var visit;
   // Set expiration date to a year from now.
   expdate.setTime(expdate.getTime() +  (24 * 60 * 60 * 1000 * 365));
   if(!(visit = <?php include "config.php"; echo "GetCookie('$questao')))"; ?>
      visit = 0;
   visit++;
   <?php include "config.php"; echo " SetCookie('$questao', visit, expdate, '/', null, false);"; ?>
   var message;
   <?php include "config.php"; echo "if(visit > $qtd_maxima_de_votos ){"; ?>
      alert("Agradecemos sua aten��o mas voc� j� realizou seu(s) voto(s)!");
      return false;
   }
   else {
      return true;
   };

  }
function ResetCounts()
   {
   var expdate = new Date();
   expdate.setTime(expdate.getTime() +  (24 * 60 * 60 * 1000 * 365));
   visit = 0;
   SetCookie("visit", visit, expdate , "/", null, false);
   leapto();
   }
// De-activate Cloaking -->
</Script>

</body>
</html>
