<?php 
// configure conforme seu banco 
// Este arquivos far� a conex�o nos arquivos
// apgresu, apgvota, apgincluirresposta e apgindex
$link = mysql_pconnect("localhost","root",""); 
mysql_select_db("enquete", $link); 
?>