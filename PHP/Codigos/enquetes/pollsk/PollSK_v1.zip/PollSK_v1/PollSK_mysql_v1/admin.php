<?php
/////////////////////////////////////////////////////////
//                                                     //
//  Poll SK - Vers�o MYSQL 1.0.0 (2004)                //
//                                                     //
//  Autor   : Sandro [SK15]                            //
//  E-mail  : sk15@skscripts.com                       //
//  Site    : http://www.skscripts.com                 //
// --------------------------------------------------- //
//  Licen�a : GNU/GPL - http://www.gnu.org             //
//  PHP     : http://www.php.net                       //
//  MySQL   : http://www.mysql.org                     //
//                                                     //
/////////////////////////////////////////////////////////

include_once('./config.php');

function Vai(){
 global $url_sistema,$PHP_SELF;
Header("Location: ".$url_sistema."/".substr($PHP_SELF,strrpos($PHP_SELF,'/')+1));
Exit();
}

function MudarConfig(){
 global $path_sistema,$CF_HOST,$CF_USER,$CF_SENHA,$CF_BANCO,$CF_PREFIXO,$CF_URL,$CF_PATH,$CF_IPS;
 global $CF_DADOS,$CF_COOKIE,$CF_TEMPO,$CF_OPCOES;
$config = "<?php
/////////////////////////////////////////////////////////
//                                                     //
//  Poll SK - Vers�o MYSQL 1.0.0 (2004)                //
//                                                     //
//  Autor   : Sandro [SK15]                            //
//  E-mail  : sk15@skscripts.com                       //
//  Site    : http://www.skscripts.com                 //
// --------------------------------------------------- //
//  Licen�a : GNU/GPL - http://www.gnu.org             //
//  PHP     : http://www.php.net                       //
//  MySQL   : http://www.mysql.org                     //
//                                                     //
/////////////////////////////////////////////////////////

// Host do MYSQL para conex�o
\$mysql_host    = '$CF_HOST';
// Usu�rio dessa conex�o
\$mysql_usuario = '$CF_USER';
// Senha desse Usu�rio
\$mysql_senha   = '$CF_SENHA';
// Banco de Dados a ser Usado
\$mysql_banco   = '$CF_BANCO';
// Nome inicial das tabelas
\$mysql_prefixo = '$CF_PREFIXO';
// URL do sistema (sem '/' no final)
\$url_sistema   = '$CF_URL';
// Path do sistema (sem '/' no final)
\$path_sistema  = '$CF_PATH';
// Cookie de seguran�a do voto
\$cookie_nome   = '$CF_COOKIE';
// Tempo em horas para votar novamente
\$tempo_voto    = '$CF_TEMPO';
// N�mero de op��es para votar
\$numero_opcoes = '$CF_OPCOES';
?>";
$fp = fopen($path_sistema.'/config.php','w+');
fwrite($fp,$config);
fclose($fp);
Vai();
}

function MudarDados(){
 global $mysql_prefixo,$numero_opcoes,$QUT,$OPC,$IMG,$VTS;
$total_votos = '0';
mysql_query("DELETE FROM ".$mysql_prefixo."dados;");
for($i = '1'; $i <= $numero_opcoes; $i++){
if ($OPC[$i] != '' && $IMG[$i] != '' && is_numeric($VTS[$i])){
mysql_query("INSERT INTO ".$mysql_prefixo."dados VALUES('$OPC[$i]','$IMG[$i]','$VTS[$i]');");
$total_votos += $VTS[$i];
}}
mysql_query("UPDATE ".$mysql_prefixo."pergunta SET pergunta='$QUT',votos='$total_votos' LIMIT 1;");
mysql_query("DELETE FROM ".$mysql_prefixo."ips;");
Vai();
}

function Images($numero,$selecionada=''){
 global $path_sistema;
$option = '<select name="IMG['.$numero.']" size="1">';
$dirimg = dir($path_sistema.'/images');
while ($imgs = $dirimg->read()){
$nome = substr($imgs,'0',(strlen($imgs)-4));
$exte = substr($imgs,(strlen($imgs)-4),'4');
if ($exte == '.gif' OR $exte == '.jpg' OR $exte == '.jpeg' OR $exte == '.png' OR $exte == '.bmp'){
$option .= '<option value="'.$imgs.'"'.(($imgs == $selecionada) ? ' selected' : '').'>'.(str_replace('_',' ',$nome)).'</option>';
}}
$dirimg->close();
$option .= '</select>';
return $option;
}

function Principal(){
 global $mysql_host,$mysql_usuario,$mysql_senha,$mysql_banco,$mysql_prefixo,$path_sistema,$url_sistema;
 global $cookie_nome,$tempo_voto,$numero_opcoes,$PHP_SELF;
$mysql1 = mysql_query("SELECT * FROM ".$mysql_prefixo."pergunta;");
$dados1 = mysql_fetch_array($mysql1);
print '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html><head><title>PollSK MYSQL v1.0.0</title><style type="text/css">
A {text-decoration:none;font-family:Verdana;color:#000000;font-size:10pt;}
A:hover {text-decoration:none;color:#FF0000;}
input {font-family:Verdana;font-size:10pt;color:#000000;border:1 solid #000000;}
td {font-family:Verdana;color:#000000;font-size:10pt;}
select {font-family:Verdana;font-size:10pt;color:#000000;width:140;}
</style></head><body bgcolor="#FFFFFF" text="#000000">
<table width="100%" border="0" align="center" cellspacing="1" cellpadding="3" bgcolor="#000000">
<tr bgcolor="#4E4E4E"><td colspan="4" align="right"><font face="Verdana,Arial" size="4" color="#FFFFFF"><b><i>+ Enquete +</i></b></font>&nbsp;</td></tr>
<form action="'.$PHP_SELF.'?PollSK=Dados" method="POST">
<tr bgcolor="#909090"><td><b>Pergunta:</b></td><td colspan="3"><input type="text" name="QUT" size="87" value="'.$dados1['pergunta'].'"></td></tr>
<tr bgcolor="#6A6A6A"><td><b>N�:</b></td><td><b>Op��o:</b></td><td><b>Image:</b></td><td><b>Votos:</b></td></tr>';
$mysql2 = mysql_query("SELECT * FROM ".$mysql_prefixo."dados;");
for ($i = '1'; $i <= $numero_opcoes ; $i++){
$dados2 = mysql_fetch_array($mysql2);
print '<tr bgcolor="#909090">
<td width="15%"><font face="Verdana,Arial" size="2"><b>Op��o '.$i.'</b></font></td>
<td width="50%"><input type="text" name="OPC['.$i.']" size="50" value="'.$dados2['opcao'].'"></td>
<td width="20%">'.Images($i,$dados2['cor']).'</td>
<td width="15%"><input type="text" name="VTS['.$i.']" size="12" value="'.(($dados2['votos'] == '') ? '0' : $dados2['votos']).'"></td>
</tr>';
}
print '<tr bgcolor="#6E6E6E"><td colspan="4" align="center"><input type="submit" value=" Mudar "> <input type="reset" value="Resetar"></td></tr>
</form><tr bgcolor="#4E4E4E"><td colspan="4" align="right"><font face="Verdana,Arial" size="4" color="#FFFFFF"><b><i>+ Configura��es +</i></b></font>&nbsp;</td></tr>
<form action="'.$PHP_SELF.'?PollSK=Configs" method="POST">
<tr bgcolor="#909090">
<td><font face="Verdana,Arial" size="2"><b>Host:</b></font></td>
<td colspan="3"><input type="text" name="CF_HOST" size="70" value="'.$mysql_host.'"></td>
</tr><tr bgcolor="#909090">
<td><font face="Verdana,Arial" size="2"><b>Usu�rio:</b></font></td>
<td colspan="3"><input type="text" name="CF_USER" size="70" value="'.$mysql_usuario.'"></td>
</tr><tr bgcolor="#909090">
<td><font face="Verdana,Arial" size="2"><b>Senha:</b></font></td>
<td colspan="3"><input type="text" name="CF_SENHA" size="70" value="'.$mysql_senha.'"></td>
</tr><tr bgcolor="#909090">
<td><font face="Verdana,Arial" size="2"><b>Banco:</b></font></td>
<td colspan="3"><input type="text" name="CF_BANCO" size="70" value="'.$mysql_banco.'"></td>
</tr><tr bgcolor="#909090">
<td><font face="Verdana,Arial" size="2"><b>Prefixo:</b></font></td>
<td colspan="3"><input type="text" name="CF_PREFIXO" size="70" value="'.$mysql_prefixo.'"></td>
</tr><tr bgcolor="#909090">
<td><font face="Verdana,Arial" size="2"><b>URL:</b></font></td>
<td colspan="3"><input type="text" name="CF_URL" size="70" value="'.$url_sistema.'"></td>
</tr><tr bgcolor="#909090">
<td><font face="Verdana,Arial" size="2"><b>Path:</b></font></td>
<td colspan="3"><input type="text" name="CF_PATH" size="70" value="'.$path_sistema.'"></td>
</tr><tr bgcolor="#909090">
<td><font face="Verdana,Arial" size="2"><b>Cookie:</b></font></td>
<td colspan="3"><input type="text" name="CF_COOKIE" size="70" value="'.$cookie_nome.'"></td>
</tr><tr bgcolor="#909090">
<td><font face="Verdana,Arial" size="2"><b>Horas Voto:</b></font></td>
<td colspan="3"><input type="text" name="CF_TEMPO" size="70" value="'.$tempo_voto.'"></td>
</tr><tr bgcolor="#909090">
<td><font face="Verdana,Arial" size="2"><b>Op��es:</b></font></td>
<td colspan="3"><input type="text" name="CF_OPCOES" size="70" value="'.$numero_opcoes.'"></td>
</tr><tr bgcolor="#6E6E6E"><td colspan="4" align="center"><input type="submit" value=" Mudar "> <input type="reset" value="Resetar"></td></tr>
</table></form></body></html>';
}

########################### Execu��o ################################
mysql_connect($mysql_host,$mysql_usuario,$mysql_senha);
mysql_select_db($mysql_banco);

if (!$PollSK){ Principal(); }
else if ($PollSK == 'Limpar'){ Limpar(); }
else if ($PollSK == 'Configs'){ MudarConfig(); }
else if ($PollSK == 'Dados'){ MudarDados(); }
else { Principal(); }

mysql_close();
?>