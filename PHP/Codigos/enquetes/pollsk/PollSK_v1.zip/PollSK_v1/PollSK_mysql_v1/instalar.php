<?php
/////////////////////////////////////////////////////////
//                                                     //
//  Poll SK - Vers�o MYSQL 1.0.0 (2004)                //
//                                                     //
//  Autor   : Sandro [SK15]                            //
//  E-mail  : sk15@skscripts.com                       //
//  Site    : http://www.skscripts.com                 //
// --------------------------------------------------- //
//  Licen�a : GNU/GPL - http://www.gnu.org             //
//  PHP     : http://www.php.net                       //
//  MySQL   : http://www.mysql.org                     //
//                                                     //
/////////////////////////////////////////////////////////

include_once('./config.php');

mysql_connect($mysql_host,$mysql_usuario,$mysql_senha);
mysql_select_db($mysql_banco);

$tabelas = array(
"CREATE TABLE ".$mysql_prefixo."dados (opcao text NOT NULL, cor text NOT NULL, votos int(25) NOT NULL default '0') TYPE=MyISAM;",
"INSERT INTO ".$mysql_prefixo."dados (opcao, cor, votos) VALUES ('PHP', 'ouro.gif', '0'), ('ASP', 'amarelo.gif', '0'), ('CGI', 'cinza.gif', '0'), ('CFM', 'verde.gif', '0');",
"CREATE TABLE ".$mysql_prefixo."ips (tempo text NOT NULL, ip text NOT NULL) TYPE=MyISAM;",
"CREATE TABLE ".$mysql_prefixo."pergunta (pergunta text NOT NULL, votos int(25) NOT NULL default '0') TYPE=MyISAM;",
"INSERT INTO ".$mysql_prefixo."pergunta (pergunta, votos) VALUES ('Qual L�ngua Voc� Prefere ?', '0');"
);

print '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html><head><title>PollSK MYSQL v1.0.0 - Instala��o</title><style type="text/css">
td {font-family:Verdana;color:#000000;font-size:10pt;}
</style></head><body bgcolor="#FFFFFF" text="#000000">
<table width="100%" border="0" align="center" cellspacing="1" cellpadding="3" bgcolor="#000000">
<tr bgcolor="#4E4E4E"><td align="right"><font face="Verdana,Arial" size="4" color="#FFFFFF"><b><i>+ Tabelas +</i></b></font>&nbsp;</td></tr>
<tr bgcolor="#909090"><td>';
for ($i = '0' ; $i < count($tabelas) ; $i++){
print (mysql_query($tabelas[$i])) ? '<font color="#00FF00" size="1"><b>Tabela criada com Sucesso !!!<br>Query: '.$tabelas[$i].'</b></font><br><br>'."\n" : '<font color="#FF0000" size="1"><b>Erro ao criar Tabela !!!<br>Query: '.$tabelas[$i].'<br>Erro: '.mysql_error().'</b></font><br><br>'."\n";
}
print '</td></tr>
<tr bgcolor="#6E6E6E"><td align="center">&nbsp;</td></tr>
</table></body></html>';

mysql_close();
?>