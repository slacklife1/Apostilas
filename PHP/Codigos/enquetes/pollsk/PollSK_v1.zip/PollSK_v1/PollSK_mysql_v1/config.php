<?php
/////////////////////////////////////////////////////////
//                                                     //
//  Poll SK - Vers�o MYSQL 1.0.0 (2004)                //
//                                                     //
//  Autor   : Sandro [SK15]                            //
//  E-mail  : sk15@skscripts.com                       //
//  Site    : http://www.skscripts.com                 //
// --------------------------------------------------- //
//  Licen�a : GNU/GPL - http://www.gnu.org             //
//  PHP     : http://www.php.net                       //
//  MySQL   : http://www.mysql.org                     //
//                                                     //
/////////////////////////////////////////////////////////

// Host do MYSQL para conex�o
$mysql_host    = 'localhost';
// Usu�rio dessa conex�o
$mysql_usuario = 'root';
// Senha desse Usu�rio
$mysql_senha   = '';
// Banco de Dados a ser Usado
$mysql_banco   = '';
// Nome inicial das tabelas
$mysql_prefixo = 'pollsk_';
// URL do sistema (sem '/' no final)
$url_sistema   = 'http://www.seusite.com.br/pollsk';
// Path do sistema (sem '/' no final)
$path_sistema  = 'C:\\seusite.com.br\\pollsk';
// Cookie de seguran�a do voto
$cookie_nome   = 'PollSK-Voto';
// Tempo em horas para votar novamente
$tempo_voto    = '24';
// N�mero de op��es para votar
$numero_opcoes = '4';
?>