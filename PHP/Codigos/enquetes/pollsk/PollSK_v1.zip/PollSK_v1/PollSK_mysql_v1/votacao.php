<?php
/////////////////////////////////////////////////////////
//                                                     //
//  Poll SK - Vers�o MYSQL 1.0.0 (2004)                //
//                                                     //
//  Autor   : Sandro [SK15]                            //
//  E-mail  : sk15@skscripts.com                       //
//  Site    : http://www.skscripts.com                 //
// --------------------------------------------------- //
//  Licen�a : GNU/GPL - http://www.gnu.org             //
//  PHP     : http://www.php.net                       //
//  MySQL   : http://www.mysql.org                     //
//                                                     //
/////////////////////////////////////////////////////////

include_once('./config.php');

// Verifica(): Fun��o que Verifica se o Usu�rio j� Votou
// O Cookie s� funciona a partir do PHP 4.1.0
function Verifica(){
 global $mysql_prefixo,$cookie_nome,$_COOKIE,$REMOTE_ADDR;
$tempo = time();
if ($_COOKIE[$cookie_nome] > $tempo){
$valida = TRUE;
} else {
$mysql = mysql_query("SELECT ip FROM ".$mysql_prefixo."ips WHERE tempo > '$tempo';");
while ($ips = mysql_fetch_array($mysql)){
if ($ips['ip'] == $REMOTE_ADDR){ $valida = TRUE; break; }
}}
return ($valida) ? TRUE : FALSE;
}

// Resultados(): Fun��o que exibe os resultados
function Resultados(){
 global $mysql_prefixo,$url_sistema;
$mysql1 = mysql_query("SELECT * FROM ".$mysql_prefixo."pergunta;");
$dados1 = mysql_fetch_array($mysql1);
$rateio = ($dados1['votos'] > '0') ? (100/$dados1['votos']) : '0';
print '<table width="100%" border="0" cellspacing="1" cellpadding="2" bgcolor="#000000">
<tr align="center"><td bgcolor="#808080"><font face="Verdana,Arial" size="2" color="#000000"><b>'.$dados1['pergunta'].'</b></font></td></tr>'."\n";
$mysql2 = mysql_query("SELECT * FROM ".$mysql_prefixo."dados;");
while ($dados2 = mysql_fetch_array($mysql2)){
$barra = $dados2['votos']*$rateio;
print '<tr align="left"><td bgcolor="#909090"><font face="Verdana,Arial" size="2" color="#000000"><b>'.$dados2['opcao'].'</b> - <i>'.$dados2['votos'].' voto'.(($dados2['votos'] > '1') ? 's' : '').'</i></font></td></tr><tr align="left"><td bgcolor="#B0B0B0"><img src="'.$url_sistema.'/images/'.$dados2['cor'].'" border="0" width="'.(ceil($barra)).'" height="10"> <font face="Verdana,Arial" size="1" color="#000000">'.(sprintf('%01.2f',$barra)).'%</font></td></tr>'."\n";
}
print ((Verifica()) ? '<tr align="center"><td bgcolor="#6C6C6C">&nbsp;<font face="Verdana,Arial" size="2" color="#000000"><b><i>&raquo; Voc� j� votou hoje &laquo;</i></b></font></td></tr>' : '').
'<tr align="left"><td bgcolor="#6C6C6C">&nbsp;<font face="Verdana,Arial" size="2" color="#000000">&raquo; Total de votos: <b>'.$dados1['votos'].'</b></font></td></tr>
</table>';
}

// FormVotar(): Fun�ao qye mostra o HTML para votar
function FormVotar(){
 global $mysql_prefixo,$PHP_SELF,$QUERY_STRING;
$mysql1 = mysql_query("SELECT * FROM ".$mysql_prefixo."pergunta;");
$dados1 = mysql_fetch_array($mysql1);
$strings = ($QUERY_STRING == '') ? '' : $QUERY_STRING.'&';
print '<form action="'.$PHP_SELF.'?'.$strings.'PollSK=Votar" method="POST">
<table width="100%" border="0" cellspacing="1" cellpadding="2" bgcolor="#000000">
<tr align="center"><td colspan="2" bgcolor="#808080"><font face="Verdana,Arial" size="2" color="#000000"><b>'.$dados1['pergunta'].'</b></font></td></tr>'."\n";
$mysql2 = mysql_query("SELECT * FROM ".$mysql_prefixo."dados;");
while ($dados2 = mysql_fetch_array($mysql2)){
print '<tr align="left" bgcolor="#909090"><td align="center"><input type="radio" name="OPC" value="'.$dados2['opcao'].'"></td><td width="97%">&nbsp;<font face="Verdana,Arial" size="2" color="#000000">'.$dados2['opcao'].'</font></td></tr>'."\n";
}
print '<tr align="center" bgcolor="#6C6C6C"><td colspan="2"><input type="submit" value="     Votar     "> <input type="button" value="Resultados" onClick="javascript:window.self.location.href=\''.$PHP_SELF.'?'.$strings.'PollSK=Resultados\';"></td></tr>
</table></form>';
}

// Votar(): Fun��o que computa o voto e exibe os Resultados
function Votar(){
 global $mysql_prefixo,$cookie_nome,$tempo_voto,$OPC,$REMOTE_ADDR;
if ($OPC != ''){
$tempo = time()+($tempo_voto*3600);
mysql_query("UPDATE ".$mysql_prefixo."pergunta SET votos=votos+1 LIMIT 1;");
mysql_query("UPDATE ".$mysql_prefixo."dados SET votos=votos+1 WHERE opcao='$OPC' LIMIT 1;");
mysql_query("INSERT INTO ".$mysql_prefixo."ips VALUES('$tempo','$REMOTE_ADDR');");
setcookie($cookie_nome,$tempo,$tempo+60);
}
Resultados();
}

########################### Execu��o ################################
mysql_connect($mysql_host,$mysql_usuario,$mysql_senha);
mysql_select_db($mysql_banco);

if (Verifica() OR $PollSK == 'Resultados'){ Resultados(); }
else if (!$PollSK && !Verifica()){ FormVotar(); }
else if ($PollSK == 'Votar' && !Verifica()){ Votar(); }
else { Resultados(); }

mysql_close();
?>