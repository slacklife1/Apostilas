<?php
/////////////////////////////////////////////////////////
//                                                     //
//  Poll SK - Vers�o TXT 1.0.0 (2003)                  //
//                                                     //
//  Autor   : Sandro [SK15]                            //
//  E-mail  : sk15@skscripts.com                       //
//  Site    : http://www.skscripts.com                 //
// --------------------------------------------------- //
//  Licen�a : GNU/GPL - http://www.gnu.org             //
//  PHP     : http://www.php.net                       //
//                                                     //
/////////////////////////////////////////////////////////

include_once('./config.php');

// Verifica(): Fun��o que Verifica se o Usu�rio j� Votou
// O Cookie s� funciona a partir do PHP 4.1.0
function Verifica(){
 global $path_sistema,$arquivo_ips,$cookie_nome,$_COOKIE,$REMOTE_ADDR;
$tempo = time();
$dados = file($path_sistema.'/'.$arquivo_ips);
$dados = str_replace("\n", '', $dados);
if ($_COOKIE[$cookie_nome] > $tempo){
$valida = TRUE;
} else {
for ($i = '0' ; $i < count($dados) ; $i++){
list($IPtxt,$tempotxt) = explode('|',$dados[$i]);
if ($tempotxt > $tempo && $IPtxt == $REMOTE_ADDR){ $valida = TRUE; break; }
}}
return ($valida) ? TRUE : FALSE;
}

// Resultados(): Fun��o que exibe os resultados
function Resultados(){
 global $path_sistema,$url_sistema,$arquivo_dados;
$dados = file($path_sistema.'/'.$arquivo_dados);
$dados = str_replace("\n", '', $dados);
$total = count($dados);
$total_votos = '0';
for ($i = '1' ; $i < $total ; $i++){
$votos = explode('|',$dados[$i]);
$total_votos += $votos['2'];
}
$rateio = ($total_votos > '0') ? (100/$total_votos) : '0';
print '<table width="100%" border="0" cellspacing="1" cellpadding="2" bgcolor="#000000">
<tr align="center"><td bgcolor="#808080"><font face="Verdana,Arial" size="2" color="#000000"><b>'.$dados['0'].'</b></font></td></tr>'."\n";
for ($i = '1' ; $i < $total ; $i++){
list($opcao,$image,$votos) = explode('|',$dados[$i]);
$barra = $votos*$rateio;
print '<tr align="left"><td bgcolor="#909090"><font face="Verdana,Arial" size="2" color="#000000"><b>'.$opcao.'</b> - <i>'.$votos.' voto'.(($votos > '1') ? 's' : '').'</i></font></td></tr><tr align="left"><td bgcolor="#B0B0B0"><img src="'.$url_sistema.'/images/'.$image.'" border="0" width="'.(ceil($barra)).'" height="10"> <font face="Verdana,Arial" size="1" color="#000000">'.(sprintf('%01.2f',$barra)).'%</font></td></tr>'."\n";
}
print ((Verifica()) ? '<tr align="center"><td bgcolor="#6C6C6C">&nbsp;<font face="Verdana,Arial" size="2" color="#000000"><b><i>&raquo; Voc� j� votou hoje &laquo;</i></b></font></td></tr>' : '').
'<tr align="left"><td bgcolor="#6C6C6C">&nbsp;<font face="Verdana,Arial" size="2" color="#000000">&raquo; Total de votos: <b>'.$total_votos.'</b></font></td></tr>
</table>';
}

// FormVotar(): Fun�ao que mostra o HTML para votar
function FormVotar(){
 global $path_sistema,$arquivo_dados,$PHP_SELF,$QUERY_STRING;
$dados = file($path_sistema.'/'.$arquivo_dados);
$dados = str_replace("\n", '', $dados);
$strings = ($QUERY_STRING == '') ? '' : $QUERY_STRING.'&';
print '<form action="'.$PHP_SELF.'?'.$strings.'PollSK=Votar" method="POST">
<table width="100%" border="0" cellspacing="1" cellpadding="2" bgcolor="#000000">
<tr align="center"><td colspan="2" bgcolor="#808080"><font face="Verdana,Arial" size="2" color="#000000"><b>'.$dados['0'].'</b></font></td></tr>'."\n";
for ($i = '1' ; $i < count($dados) ; $i++){
$opcao = explode('|',$dados[$i]);
print '<tr align="left" bgcolor="#909090"><td align="center"><input type="radio" name="OPC" value="'.$i.'"></td><td width="97%">&nbsp;<font face="Verdana,Arial" size="2" color="#000000">'.$opcao[0].'</font></td></tr>'."\n";
}
print '<tr align="center" bgcolor="#6C6C6C"><td colspan="2"><input type="submit" value="     Votar     "> <input type="button" value="Resultados" onClick="javascript:window.self.location.href=\''.$PHP_SELF.'?'.$strings.'PollSK=Resultados\';"></td></tr>
</table></form>';
}

// Votar(): Fun��o que computa o voto e exibe os Resultados
function Votar(){
 global $path_sistema,$arquivo_ips,$arquivo_dados,$cookie_nome,$tempo_voto,$OPC,$REMOTE_ADDR;
$dados = file($path_sistema.'/'.$arquivo_dados);
$total = count($dados);
if ($OPC != '' && is_numeric($OPC) && $OPC < $total){
$fp = fopen($path_sistema.'/'.$arquivo_dados,'w+');
fwrite($fp,$dados['0']);
for ($i = '1' ; $i < $total ; $i++){
list($opcao,$image,$votos) = explode('|',$dados[$i]);
if ($OPC == $i){
fwrite($fp,$opcao.'|'.$image.'|'.($votos+1)."\n");
} else {
fwrite($fp,$opcao.'|'.$image.'|'.$votos);
}}
fclose($fp);
$tempo = time()+($tempo_voto*3600);
$fp = fopen($path_sistema.'/'.$arquivo_ips,'a+');
fwrite($fp,$REMOTE_ADDR.'|'.$tempo."\n");
fclose($fp);
setcookie($cookie_nome,$tempo,$tempo+60);
}
Resultados();
}

########################### Execu��o ################################
if (Verifica() OR $PollSK == 'Resultados'){ Resultados(); }
else if (!$PollSK && !Verifica()){ FormVotar(); }
else if ($PollSK == 'Votar' && !Verifica()){ Votar(); }
else { Resultados(); }
?>