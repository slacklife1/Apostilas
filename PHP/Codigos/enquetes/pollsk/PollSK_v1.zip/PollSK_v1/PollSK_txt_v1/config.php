<?php
/////////////////////////////////////////////////////////
//                                                     //
//  Poll SK - Vers�o TXT 1.0.0 (2003)                  //
//                                                     //
//  Autor   : Sandro [SK15]                            //
//  E-mail  : sk15@skscripts.com                       //
//  Site    : http://www.skscripts.com                 //
// --------------------------------------------------- //
//  Licen�a : GNU/GPL - http://www.gnu.org             //
//  PHP     : http://www.php.net                       //
//                                                     //
/////////////////////////////////////////////////////////

// URL do sistema (sem '/' no final)
$url_sistema   = 'http://www.seusite.com.br/pollsk';
// Path do sistema (sem '/' no final)
$path_sistema  = 'C:\\seusite.com.br\\pollsk';
// Arquivo onde ser�o guardados os 'ips'
$arquivo_ips   = 'ips.txt';
// Arquivo onde ser�o guardados os 'dados'
$arquivo_dados = 'dados.txt';
// Cookie de seguran�a do voto
$cookie_nome   = 'PollSK-Voto';
// Tempo em horas para votar novamente
$tempo_voto    = '24';
// N�mero de op��es para votar
$numero_opcoes = '4';
?>