<html>

<head>
<title>[kL/enquete] by Ricardo Maranh�o - fIrECooL on BRASnet</title>
</head>
<body vlink="#0000FF" alink="#0000FF">
<?php
include("config.inc");
?>

</b></font></p>
<p><font face="Verdana" size="1">+--><font face="Verdana" size="2"> <b>"Criar nova enquete"</b></font></p>
<form method="POST" action="admin.php?acao=criar" name="criarenquete">
  <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="63%" id="AutoNumber1">
    <tr>
      <td width="30%"><font face="Verdana" size="1">Pergunta:</font></td>
      <td width="70%"><font size="1">
      <input type="text" name="pergunta" size="54" style="font-family: Verdana"></font></td>
    </tr>
    <tr>
      <td width="30%"><font face="Verdana" size="1">Op��o 1:</font></td>
      <td width="70%"><font size="1">
      <input type="text" name="opcao1" size="23" style="font-family: Verdana"></font></td>
    </tr>
    <tr>
      <td width="30%"><font face="Verdana" size="1">Op��o 2:</font></td>
      <td width="70%"><font size="1">
      <input type="text" name="opcao2" size="23" style="font-family: Verdana"></font></td>
    </tr>
    <tr>
      <td width="30%"><font face="Verdana" size="1">Op��o 3:</font></td>
      <td width="70%"><font size="1">
      <input type="text" name="opcao3" size="23" style="font-family: Verdana"></font></td>
    </tr>
    <tr>
      <td width="30%"><font face="Verdana" size="1">Op��o 4:</font></td>
      <td width="70%"><font size="1">
      <input type="text" name="opcao4" size="23" style="font-family: Verdana"></font></td>
    </tr>
    <tr>
      <td width="30%"><font face="Verdana" size="1">Op��o 5:</font></td>
      <td width="70%"><font size="1">
      <input type="text" name="opcao5" size="23" style="font-family: Verdana"></font></td>
    </tr>
  </table>
  <p><font size="1" face="Verdana">OBS: ao adicionar essa enquete ela se tornar� 
  a enquete ativa e a atualmente ativa ser� desativa e arquiva na sess�o de 
  enquetes anteriores.</font></p>
  &nbsp;
    <button name="roots" value="criar" type="submit" style="width: 50; height: 20">
Criar!</button>&nbsp;
    <button name="hj" type="reset" style="width: 62; height: 20">
Limpar</button>

</body>
<?php
include("kl.txt");
?>

<?php
if($acao=="criar") {
$idativo = mysql_query("SELECT id FROM enquete WHERE status='1'");
$arr = mysql_fetch_array($idativo);
$id = $arr['id'];
$update = mysql_query("UPDATE enquete SET status='0' WHERE id='$id'");
$criarnova = mysql_query("INSERT INTO enquete VALUES ('', '1', '$pergunta', '$opcao1', '1', '$opcao2', '1', '$opcao3', '1', '$opcao4', '1', '$opcao5', '1')"); 
echo "<br><br><font size=2 face=Verdana color=red>A sua enquete(<b>$pergunta</b>) foi criada com sucesso!";
echo "<br><a href=enquete.php>Clique aqui para ve-l�!!</a>";
} else {
echo "<br>";
}
?>