<html>

<head>
<title>[kL/enquete] by Ricardo Maranh�o - fIrECooL on BRASnet</title>
</head>
<body vlink="#0000FF" alink="#0000FF">
<?php
include("config.inc");
$resultado = mysql_query("SELECT * FROM enquete WHERE status='0' ORDER by id DESC");
$num = mysql_num_rows($resultado);
$numero = 1;
?>

<p><font size=1 face=Verdana>+--&gt; </font><font face=Verdana size=2><b>
&quot;Enquetes Anteriores&quot;</b></font><font size=2 face=Verdana><br>|<br>
<?php
while(list($id, $status, $pergunta, $opcao1, $votos1, $opcao2, $votos2, $opcao3, $votos3, $opcao4, $votos4, $opcao5, $votos5) = mysql_fetch_row($resultado)) {
$totalvotos = $votos1 + $votos2 + $votos3 + $votos4 + $votos5 ;
echo "| $numero. <a href=resultadoant.php?id=$id>$pergunta</a> - <b>$totalvotos</b> votos.<br>";
$numero++;
}
echo "<br>";
include("kl.txt");
?>