<html>

<head>
<title>[kL/enquete] by Ricardo Maranh�o - fIrECooL on BRASnet</title>
</head>
<body vlink="#0000FF" alink="#0000FF">
<?php
include("config.inc");

$pegarid = mysql_query("SELECT id FROM enquete WHERE status='1'");
$arrid = mysql_fetch_array($pegarid);
$id = $arrid['id'];

if ($acao=="votar" && !isset($cookieenquete)) {
$resultado = mysql_query("SELECT $opcao FROM enquete WHERE status='1'");
$arr = mysql_fetch_array($resultado);
$voto = $arr['$opcao'];
$voto++;
$inserirvoto = mysql_query("UPDATE enquete SET $opcao='$voto' WHERE status='1'");
setcookie("cookieenquete", "Votou");
echo("<script language='javascript'>
window.location = 'enquete.php';
window.open('resultado.php?votou=sim', 'resultado', 'toolbar=no,location=no,directories=no,status=no,scrollbars=no,menubar=no,resizable=no,width=400,height=260');
</script>");
} else {
$resultado = mysql_query("SELECT * FROM enquete WHERE status='1'");
$arr = mysql_fetch_array($resultado);
$pergunta = $arr['pergunta'];
$opcao1 = $arr['opcao1'];
$opcao2 = $arr['opcao2'];
$opcao3 = $arr['opcao3'];
$opcao4 = $arr['opcao4'];
$opcao5 = $arr['opcao5'];

?>
<form method="POST" name="enquete" action="enquete.php?acao=votar">
  <p><font face="Verdana" size="1">+--&gt; &quot;</font><b><font face="Verdana" size="2"><?php echo "$pergunta"; ?>&quot;</font></b><font face="Verdana" size="1"><br>
  |<input type="radio" value="votos1" name="opcao" style="font-family: Verdana; color: #000000"></font><font face="Verdana" size="2"><font face="Verdana" size="1"> 
  <?php echo "$opcao1"; ?><br>
  |<input type="radio" value="votos2" name="opcao" style="font-family: Verdana; color: #000000"> 
  <?php echo "$opcao2"; ?><br>
  |<input type="radio" value="votos3" name="opcao" style="font-family: Verdana; color: #000000"> 
  <?php echo "$opcao3"; ?><br>
  |<input type="radio" value="votos4" name="opcao" style="font-family: Verdana; color: #000000"> 
  <?php echo "$opcao4"; ?><br>
  |<input type="radio" value="votos5" name="opcao" style="font-family: Verdana; color: #000000"> 
  <?php echo "$opcao5"; ?></font><br>
  |<br>
  |
  <button name="roots" value="votar" type="submit" style="width: 50; height: 20">
  <font face="Verdana" size="1">Votar</font></button>&nbsp;
  <button value="resultado" style="width: 65; height: 20" onClick="window.open('resultado.php', 'resultado', 'toolbar=no,location=no,directories=no,status=no,scrollbars=no,menubar=no,resizable=no,width=450,height=260')">
  <font face="Verdana" size="1">Resultado</font></button></font>
  <br><font face="Verdana" size="1">| <a href="enquetesant.php">Enquetes Anteriores</a></font>
  <br><font face="Verdana" size="1">| <a href="admin.php">Administrar Enquetes</a></font>
  <p>&nbsp;</p>
</form>
<?php
}
include("kl.txt");
?>
</html>
