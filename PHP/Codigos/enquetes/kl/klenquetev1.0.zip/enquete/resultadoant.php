<html>

<head>
<title>[kL/enquete] by Ricardo Maranh�o - fIrECooL on BRASnet</title>
</head>
<body vlink="#0000FF" alink="#0000FF">
<?php
include("config.inc");

$resultado = mysql_query("SELECT * FROM enquete WHERE id='$id'");
$arr = mysql_fetch_array($resultado);
$pergunta = $arr['pergunta'];
$opcao1 = $arr['opcao1'];
$opcao2 = $arr['opcao2'];
$opcao3 = $arr['opcao3'];
$opcao4 = $arr['opcao4'];
$opcao5 = $arr['opcao5'];
$votos1 = $arr['votos1'];
$votos2 = $arr['votos2'];
$votos3 = $arr['votos3'];
$votos4 = $arr['votos4'];
$votos5 = $arr['votos5'];
$totalvotos = $votos1 + $votos2 + $votos3 + $votos4 + $votos5 ;
$por1 = number_format(($votos1/$totalvotos) * 100, 2, '.', ' ');
$por2 = number_format(($votos2/$totalvotos) * 100, 2, '.', ' ');
$por3 = number_format(($votos3/$totalvotos) * 100, 2, '.', ' ');
$por4 = number_format(($votos4/$totalvotos) * 100, 2, '.', ' ');
$por5 = number_format(($votos5/$totalvotos) * 100, 2, '.', ' ');

?>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1">
  <tr>
    <td width="33%"><font size="2" face="Verdana"><b>Resultado da Enquete:</b><br>
    <?php echo "$pergunta"; ?></font><p>&nbsp;</p>
    <p><font size="2" face="Verdana"><b>Total de Votos:</b><?php echo "<br>$totalvotos"; ?></font></p>
    <p>&nbsp;</td>
    <td width="77%"><font size="2" face="Verdana">| <b><?php echo "$opcao1"; ?></b><br>
    `-
    <img border="0" src="barra1.gif" width="<?php echo "$por1"; ?>" height="10"> 
    <?php echo "($por1%)"; ?><br>
    | <b><?php echo "$opcao2"; ?></b> <br>
    `-
    <img border="0" src="barra4.gif" width="<?php echo "$por2"; ?>" height="10"> 
    <?php echo "($por2%)"; ?><br>
    | <b><?php echo "$opcao3"; ?></b> <br>
    `-
    <img border="0" src="barra3.gif" width="<?php echo "$por3"; ?>" height="10"> 
    <?php echo "($por3%)"; ?><br>
    | <b><?php echo "$opcao4"; ?></b><br>
    `-
    <img border="0" src="barra2.gif" width="<?php echo "$por4"; ?>" height="10"> 
    <?php echo "($por4%)"; ?><br>
    | <b><?php echo "$opcao5"; ?></b><br>
    `-
    <img border="0" src="barra5.gif" width="<?php echo "$por5"; ?>" height="10"> 
    <?php echo "($por5%)"; ?></font></td>
  </tr>
</table><p><font face="Verdana" size="2"><a href="javascript:self.print();">[imprimir enquete]</a></font></p>

<?php
include("kl.txt");
?>
</html>
