+--> [kL/enquete] v1.0
| A [kL] � a favor do OPEN SOURCE, desde que seja mantido os cr�ditos.
**********************************************************************

+-> Changelog
vers�o 1.0
1. Administra��o via WWW
2. Enquetes anteriores
3. Resultados com:
3.1. Quantidade de votos
3.2. Porcentagem dos votos
3.3. Barra da porcentagem
3.4. Possibilidade de impress�o


+-> Instala��o
1. Execute o arquivo "mysql.inc" no MySQL.
2. Configure os dados de conex�o ao MySQL no arquivo "config.inc" e pronto!


+-> Agradecimentos
www.phpbrasil.com
www.superphp.com.br
www.wmonline.com.br


+-> Cr�ditos
Este script foi totalmente feito por:
Ricardo Maranh�o - firecool@brasnet.org
irc.hotlink.com.br (Rede BRASnet)


+-> Outros
Entre em contato e sugira novos scripts a serem feitos.
Fa�o Website para empresas/pessoais, entrem em contato para maiores detalhes.


?!? Achou bugs, tem sugest�o ?!? Entre em contato, e tenha seu nome no agradecimento
e ainda usufrir� de um script melhor!