<?
#################################################################################################                      
#                                                                                                                      
#  Project           	: phpEnquete                                                                                        
#  File name         	: votes.php                                                                                    
#  Last Modified By  	: Barbara Tavora / e-Desenvolvedor                                                                                     
#  e-mail            	: barbara.tavora@e-desenvolvedor.com.br                                                                           
#  Purpose           	: Voting's                                                                                  
#  Version	     	    : 1.20
#
#################################################################################################                      


#################################################################################################                      
#  Configuration                                                                                                                    

// mySQL Stuff
$server			= "localhost";		// Your Host, most cases localhost
$db_user		= "username";		// Your mySql Username
$db_pass		= "password";		// Your mySql Password
$database		= "phpEnquete";		// Your phpEnquete-Database

// Size Stuff
$vote_width		= "200";
$votebar_width		= "80%";
$votebar_height		= "10";

// Language Stuff
$vote_question		= "Aqui est� a pergunta!?!";
$vote_answer		= "Respostas";		
$vote_vote		= "Votar";
$vote_button		= "Votar";

// Optical Stuff
$htmlheader="
  <title>phpEnquete</title>                                                                                     
  <style type=text/css>
    body 		{ background:#E2E2E2; margin: 10px; font-family: Verdana; }                 
    a:link 		{ color:#333333; font-weight:bold; text-decoration:underline; font-family: Verdana; }                  
    a:visited 		{ color:#555555; font-weight:bold; text-decoration:underline; font-family: Verdana; }               
    a:active 		{ color:#FFCC00; font-weight:bold; text-decoration:underline; font-family: Verdana; }                
    a:hover 		{ color:#FF9900; font-weight:bold; text-decoration:none; font-family: Verdana; }                      
    td.votebarout 	{ background: #EEEEEE; border:0px; }                                                    
    td.votebarin 	{ background: #FFCC00; border:0px; }                                                     
    td.votetext 	{ font-size:8pt; }                                                                               
    td.votequest 	{ font-size:10pt; font-weight:bold; text-align:center;}                                                                               
    td.votefooter	{ font-size:8pt; text-align:center; }
    div.votespace	{ font-size:4pt; text-align:center; }
  </style>
";

// Some Stuff
$cookie_time		= 12;			// Vote Timeout in hours (set with Cookies)
$ver			= "1.20";


#  DO NOT CHANGE ANYTHING BEHIND THIS LINE !!!                                                                                                                      
#################################################################################################                      


if ($vote && !$HelloCheater) {                                                                                  
    mysql_connect($server,$db_user,$db_pass) or die("Database Connect Error");                              
    $query = mysql_db_query($database,"update votes set votes=votes+1 where name='$vote'") or die("Database Query Error");
    mysql_close();
    setcookie("HelloCheater", "1", time()+(3600*$cookie_time));
    header("Location: $PHP_SELF");                                                     
    exit;                                                                                                    
}
?>

<DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">                                                 
                                                                                                              
<html>                                                                                                        
 <head>                                                                                                       
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">                                  
  <meta name="robots" content="index, nofollow">                                                              
  <meta name="revisit-after" content="20 days">                                                               
<?
echo $htmlheader;
echo"</head><body>";	    

echo "<form action=\"$PHP_SELF\" method=\"POST\">";
    mysql_connect($server,$db_user,$db_pass) or die("Database Connect Error");
    $result=mysql_db_query($database,"select sum(votes) as sum from votes") or die("Database Query Error");;
    if($result) {
        $sum = (int) mysql_result($result,0,"sum");
        mysql_free_result($result);
    }

    $result=mysql_db_query($database,"select * from votes order by votes DESC") or die("Database Query Error");;
    echo "<table border=0 width=$vote_width><tr><td class=\"votequest\" colspan=\"3\">$vote_question<br><br></td></tr><tr><td class=\"votetext\">$vote_vote</td><td class=\"votetext\">$vote_answer</td><td class=\"votetext\">%</td></tr>\n";
    while($row=mysql_fetch_row($result)) {
	echo "<tr><td align=center><input type=radio name=vote value=\"$row[0]\"></td>";                   
    	echo "<td class=\"votetext\" colspan=\"2\">" .$row[0]."</td></tr><tr>
	<td class=\"votetext\" align=\"center\">".$row[1]."</td><td class=\"votetext\">";                                              

        if($sum && (int)$row[1]) {
    	    $per = (int)(100 * $row[1]/$sum);

	    echo "<table align=center border=0 cellspacing=0 cellpadding=1 width=\"$votebar_width\" height=\"$votebar_height\">\n"; 
            echo " <tr>\n";                                                                                                 
	    echo "  <td class=\"votebarout\">\n";                                                     
    	    echo "   <table align=left border=0 cellspacing=0 cellpadding=0 width=\"$per%\" height=\"100%\">\n";
    	    echo "    <tr>\n";                                                                                              
	    echo "     <td class=\"votebarin\">\n";                                                    
    	    echo "        <div class=\"votespace\">&nbsp;</div>\n";
	    echo "     </td>\n";                                                                                            
	    echo "    </tr>\n";                                                                                             
	    echo "   </table>\n";                                                                                           
	    echo "  </td>\n";                                                                                               
	    echo " </tr>\n";                                                                                                
    	    echo "</table>\n";                                                                                              
  	      
	    echo"</td><td class=\"votetext\">$per</td>";
      	    }
        echo "</tr>\n";
        }
    mysql_free_result($result);
    mysql_close();
echo "<tr><td class=\"votetext\" colspan=\"3\"><input type=submit value=\"$vote_button\"></form></td></tr>";
#  PLEASE DO NOT REMOVE OR EDIT THIS COPYRIGHT-NOTICE !!! THANKS !!! #########################################
echo"<tr><td class=\"votefooter\" colspan=\"3\">phpEnquete $ver<br>&copy 2004-".date("Y")." by <a href=\"http://www.e-desenvolvedor.com.br\" target=\"_blank\">e-Desenvolvedor</a></td></tr>";
##############################################################################################################
echo "</table>\n";
echo "</body></html>";
?>