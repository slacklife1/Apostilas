#
# Table structure for table 'phpEnquete'
#

CREATE TABLE votes (
   name varchar(30) DEFAULT '0' NOT NULL,
   votes int(5),
   PRIMARY KEY (name)
);

#
# Dumping data for table 'phpVote'
#

INSERT INTO votes VALUES ( 'Muito Bom', '1');
INSERT INTO votes VALUES ( 'Bom', '2');
INSERT INTO votes VALUES ( 'Razo�vel', '3');
INSERT INTO votes VALUES ( 'Ruim', '4');
