<? 
include "./inc/iniFile.inc";
if (!(isset($iniFileName))) { $iniFileName = ""; };
if ($iniFileName != "") {
  $sections = GetINISections($iniFileName);
	if (!(isset($section))) { $section = ""; };
	if ($section != "") {
	  $fields = GetINIFields($iniFileName, $section);
		if (!(isset($field))) { $field = ""; };
		if ($field !="") {
		  $value = GetINIValue($iniFileName, $section, $field);
		}
	}
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
<title>INI File Manager</title>
<style type="text/css">
<!--
body {
  margin: 0px;
}

.explain {
	margin-left: 10pt;
  font-family: arial;
	font-size: 10pt;
	font-weight: bold;
}

.title {
  font-family: arial;
	font-size: 10pt;
	font-weight: bold;
	color: blue;
}
-->
</style>

</head>

<body>
<? if ($iniFileName != "") { ?>
<div class="title" align="center">File Name: <? echo stripslashes($iniFileName); ?></div>
<br>
<? if ($value != "") { ?>
<div class="title">
&nbsp;&nbsp;&nbsp;&nbsp;Section:<? echo $section; ?><br>
&nbsp;&nbsp;&nbsp;&nbsp;Field:  <? echo $field; ?><br>
&nbsp;&nbsp;&nbsp;&nbsp;Value:  <? echo $value; ?>
</div>
<? } ?>
<br>
<table border="1" align="center" width="95%" cellpadding="0" cellspacing="0">
  <tr>
    <td class="explain" width="30%">INI file Sections:</td>
    <td class="explain" width="70%"><? echo $section ?> Section</td>
  </tr>
  <tr>
    <td valign="top">
      <? for ($i=0; $i<count($sections); $i++) { ?>
      &nbsp;&nbsp;&nbsp;&nbsp;<a class="explain" href="main.php?iniFileName=<? echo stripslashes($iniFileName); ?>&section=<? echo $sections[$i]; ?>"><? echo $sections[$i]; ?></a><br>
      <? } ?>
		</td>
    <td valign="top">
		  <? if ($section != "") { ?>
      <? for ($i=0; $i<count($fields); $i++) { ?>
      &nbsp;&nbsp;&nbsp;&nbsp;<a class="explain" href="main.php?iniFileName=<? echo stripslashes($iniFileName); ?>&section=<? echo $section; ?>&field=<? echo $fields[$i]; ?>"><? echo $fields[$i]; ?></a><br>
      <? } ?>
			<? } ?>
		</td>
  </tr>
</table>
<? } ?>
<br>
<pre>
  1. <b>GetINISections($iniFileName)</b>
  This function returns <b>Sections</b> of "$iniFileName" file in an array 
	
  2. <b>GetINIFields($iniFileName, $section)</b>
  This Function returns <b>Fields</b> of "$section" section of "$iniFileName" file in an array 

  3. <b>GetINIValue($iniFileName, $section, $field)</b>
  This Function returns <b>Value</b> of "$field" field of "$section" section of "$iniFileName" file 
</pre>
<br>
</body>

</html>
