<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

<head>
<title>INI File Manager</title>
<style type="text/css">
<!--
body {
  margin: 5px;
  font-family: arial;
	font-size: 8pt;
	font-weight: bold;
}

.menu {
  font-family: arial;
	font-size: 8pt;
	font-weight: bold;
}
-->
</style>
<base target="main">
</head>

<body>
<div align="center">
<form action="main.php" method="post">
INI FIle: <input type="file" name="iniFileName" class="menu">
<input type="submit" class="menu" value="Open">
</form>
</div>
</body>

</html>
