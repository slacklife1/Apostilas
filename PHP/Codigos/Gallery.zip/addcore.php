<META HTTP-EQUIV=REFRESH CONTENT="0; URL=add.htm">  

<?php

require ("connect.php");

if ($name != "" and $location !="") {

  $sql = "INSERT INTO data (name,location,phone,picture,email,info) VALUES ('$name','$location','$phone','$picture','$email','$info')";

  $result = mysql_query($sql);

}
?>