<?php
echo"<html><LINK REL=stylesheet HREF='include.css' TYPE='text/css'><body bgcolor='e5e5e5' topmargin='4'>";
echo"<b><div align='right'><a href='list.php?char=number' target='mainFrame'>#</a>";
echo"<a href='list.php?char=a' target='mainFrame'>a</a>";
echo"<a href='list.php?char=b' target='mainFrame'>b</a>";
echo"<a href='list.php?char=c' target='mainFrame'>c</a>";
echo"<a href='list.php?char=d' target='mainFrame'>d</a>";
echo"<a href='list.php?char=e' target='mainFrame'>e</a>";
echo"<a href='list.php?char=f' target='mainFrame'>f</a>";
echo"<a href='list.php?char=g' target='mainFrame'>g</a>";
echo"<a href='list.php?char=h' target='mainFrame'>h</a>";
echo"<a href='list.php?char=i' target='mainFrame'>i</a>";
echo"<a href='list.php?char=j' target='mainFrame'>j</a>";
echo"<a href='list.php?char=k' target='mainFrame'>k</a>";
echo"<a href='list.php?char=l' target='mainFrame'>l</a>";
echo"<a href='list.php?char=m' target='mainFrame'>m</a>";
echo"<a href='list.php?char=n' target='mainFrame'>n</a>";
echo"<a href='list.php?char=p' target='mainFrame'>p</a>";
echo"<a href='list.php?char=q' target='mainFrame'>q</a>";
echo"<a href='list.php?char=r' target='mainFrame'>r</a>";
echo"<a href='list.php?char=s' target='mainFrame'>s</a>";
echo"<a href='list.php?char=t' target='mainFrame'>t</a>";
echo"<a href='list.php?char=u' target='mainFrame'>u</a>";
echo"<a href='list.php?char=v' target='mainFrame'>v</a>";
echo"<a href='list.php?char=w' target='mainFrame'>w</a>";
echo"<a href='list.php?char=x' target='mainFrame'>x</a>";
echo"<a href='list.php?char=y' target='mainFrame'>y</a>";
echo"<a href='list.php?char=z' target='mainFrame'>z</a></div></body></html>";
?>