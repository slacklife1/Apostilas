 <html><LINK REL=stylesheet HREF='include.css' TYPE='text/css'><title>info</title><body bgcolor='#f7f7f7' leftmargin="3" topmargin="0">
<table border="0" cellspacing="0" cellpadding="0" width="300" height="100%">
<tr>
<td>
<table border="0" cellspacing="0" cellpadding="0" width="100%">
<?php

require ("connect.php");


global $id;

$result = mysql_query("SELECT * FROM data WHERE id=$id",$db);

if ($result != "") {

if ($myrow = mysql_fetch_array($result)) {

   printf("<tr><td><FONT SIZE='1' FACE='Verdana'><b>Name:</b> %s\n</a></td>", $myrow["name"]);
   printf("</tr><tr><td><FONT SIZE='1' FACE='Verdana'><b>Location:</b> %s\n</td>", $myrow["location"]);
   printf("</tr><tr><td><FONT SIZE='1' FACE='Verdana'><b>Phone:</b> %s\n</td>", $myrow["phone"]);

if ($myrow["picture"]) {

if ($myrow["picture"] != "http://") {

 printf("</tr><tr><td><FONT SIZE='1' FACE='Verdana'><b>Picture:</b> <a href='%s' target='_blank'>%s</a>\n</td>", $myrow["picture"], $myrow["picture"]);

} else {

  printf("</tr><tr><td><FONT SIZE='1' FACE='Verdana'><b>Picture:</b> <font color='#999999'>none</font></td>");

}

} else {
  
   printf("</tr><tr><td><FONT SIZE='1' FACE='Verdana'><b>Picture:</b> <font color='#999999'>none</font></td>");

}
 
if ($myrow["email"]) {

  printf("</tr><tr><td><FONT SIZE='1' FACE='Verdana'><b>E-mail:</b> <a href='mailto:%s'>%s</a>\n</td>", $myrow["email"], $myrow["email"]);

} else {

  printf("</tr><tr><td><FONT SIZE='1' FACE='Verdana'><b>E-mail:</b> <font color='#999999'>none</font>\n</td>");

}

   printf("</tr><tr><td><FONT SIZE='1' FACE='Verdana'><b>Info:</b> %s\n</td>", $myrow["info"]);

} 

}



echo "</tr></table></td></tr></table>\n";







?>



</body>



</html>
