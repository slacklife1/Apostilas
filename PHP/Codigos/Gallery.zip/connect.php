<?php

$serv = "localhost";  // Hostname
$uname = "root";      // Username
$pass = "das8stan";   // Password

// Connection string

$db = mysql_pconnect($serv, $uname, $pass);
mysql_select_db("wipe",$db);

?>