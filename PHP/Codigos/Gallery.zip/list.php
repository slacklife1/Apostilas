<html>
<LINK REL=stylesheet HREF="include.css" TYPE="text/css">
<body bgcolor="f5f5f5">
<?php


require ("connect.php");

global $char;

if ($char == "number") {

  $result = mysql_query("SELECT * FROM data WHERE name like '3%' or name like '2%' or name like '3%' or name like '4%' or name like '5%' or name like '6%' or name like '7%' or name like '8%' or name like '9%' or name like '0%' order by name ",$db);

} else {

  if ($char != "") {

           $result = mysql_query("SELECT * FROM data WHERE name like '$char%' order by name ",$db);


  } else {



$result = mysql_query("SELECT * FROM data order by name ",$db);

}
}


echo "<html><body topmargin='0' leftmargin='2'><table width='100%' border='0' cellspacing='0' cellpadding='0'>\n";

if ($myrow = mysql_fetch_array($result)) {

do {



	printf("<tr><td>&nbsp;&nbsp;&nbsp;<FONT SIZE='1' FACE='Tahoma'><b>� <a href='info.php?id=%s' target='info'>%s\n</a></b></td></tr><tr><td></td></tr>", $myrow["id"], $myrow["name"]);



} while ($myrow = mysql_fetch_array($result));
} else {

echo "<br><br><p align='right'><FONT SIZE='1' FACE='Tahoma'><u>There is no name beginning with that character.</u></p>";

}



echo "</table>\n";







?>



</body>



</html>
