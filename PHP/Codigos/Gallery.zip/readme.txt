1. Set host, username and password in file connect.php
2. Create database "wipe" and that table:

CREATE TABLE data (
  id int(11) NOT NULL auto_increment,
  name varchar(100) default NULL,
  location varchar(255) default NULL,
  phone varchar(20) default NULL,
  picture varchar(255) default NULL,
  email varchar(100) default NULL,
  info text,
  PRIMARY KEY  (id)
) TYPE=MyISAM;


Any questions email me: 3bic@hot.ee