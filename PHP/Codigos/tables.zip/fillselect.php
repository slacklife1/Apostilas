//See CreateTheTables.txt first






//change the following variables with the appropriate
$host = "yourhostname"
$dbname = "youdatabasename"
$dbpass = "yourdatabasepassword"

$connection = mysql_connect("$host","$dbname","$dbpass");
$db = mysql_select_db("$dbname",$connection);

echo" <select name=\"category\">  ";                      //start the select box 

$results= mysql_query("SELECT ID, Name from TestTable Order by Cat asc",$connection); 
$id = "ID";
$idname = "Name"; 
echo mysql_error(); 

if (mysql_Numrows($results)>0)                            //if there are records in the fields
{ 
  $numrows=mysql_NumRows($results);                       //count them
  $x=0; 
  while ($x<$numrows){   //loop through the records
    $theId=mysql_result($results,$x,$id);                 //place each record in the variable everytime we loop
    $theName=mysql_result($results,$x,$idname);
    echo "<option value=\"$theId\">$theName</option>\n";  //and place it in the select
    $x++;
  }
}
echo "</select>";  //close the select

//DONE