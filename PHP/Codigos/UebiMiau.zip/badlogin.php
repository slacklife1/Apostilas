<?
// load the configurations
include("config.php");
include("commom_functions.php");
error_reporting (E_ALL ^ E_NOTICE); 
// load the specified file
$tcontent = read_file($bad_login_template);
// show it :)
echo($tcontent);
?>