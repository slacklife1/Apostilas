<?
/********************************************************
Defaults:
1 - Yes/On/True
0 - No/Off/False

********************************************************
_ Please attention _:
The temporary files will be stored on this folder
For security reasons, do not use web-shared folders

** The Web Server needs write-permission on this folder

* Unix/Linux users use.
/tmp/uebimiau
* Win32 users
c:/winnt/temp/uebimiau
** Note: Under Win32, use "right bars";
********************************************************/
$temporary_directory = "temporary_files/";

/********************************************************
Your local SMTP Server (alias or IP) like as "smtp.yourdomain.com"
eg. server1;server2;server3   -> specify main and backup server
********************************************************/
$smtp_server = "SMTP.YOUR-SMTP.SERVER.COM";  //YOU NEED CHANGE IT !! 


/********************************************************
The maximum size for stored files
********************************************************/
$quota_limit = 2048;  //in KB, eg. 2048 Kb = 2MB

/********************************************************
Your local POP3 Servers, ____ OPTIONAL ___
********************************************************/
// 1st
//$pop3_servers[0]["domain"] = "1stDomain.com";
//$pop3_servers[0]["server"] = "pop3.1stDomain.com";

// 2nd
//$pop3_servers[1]["domain"] = "2ndDomain.com";
//$pop3_servers[1]["server"] = "pop3.2ndDomain.com";

// Nnd
//$pop3_servers[2]["domain"] = "NndDomain.com";
//$pop3_servers[2]["server"] = "pop3.NndDomain.com";

/********************************************************
Language settings
********************************************************/
$default_language     = 1;
$allow_user_change    = 1; //allow users select language

$languages[0]["name"] = "Portugu�s Brasileiro";
$languages[0]["path"] = "themes/pt-brasil"; // folder that is stored the theme

$languages[1]["name"] = "English";
$languages[1]["path"] = "themes/english"; // folder that is stored the theme


/********************************************************
Date format for non-portuguese systems
********************************************************/
$date_format = "d/m/y h:m"; // d = day, m = month, y = year, h = hour, m = minutes


/********************************************************
In some POP3 servers, if you send a "RETR" command, your
message will be automatically deleted :(
This option prevents this inconvenience
********************************************************/
$pop_use_top = 1;

/********************************************************
Enable HTML messages (recommended)
********************************************************/
$mime_show_html = 1;

/********************************************************
Use SMTP password (AUTH LOGIN type)
********************************************************/
$use_password_for_smtp = 0;


/********************************************************
Name and Version, it's used in many places, like as 
"X-Mailer" field,  footer
********************************************************/
$appversion = "2.0";
$appname = "UebiMiau";


/********************************************************
Add an "footer" to sent mails
********************************************************/

$footer = "
 
________________________________________________
This mail was sent by $appname $appversion
";

/********************************************************
Enable debug :)
********************************************************/
$enable_debug = 0 ;

/********************************************************
Session timeout for inactivity
********************************************************/
$idle_timeout = 10; //minutes

/********************************************************
Order setting
********************************************************/
$default_sortby = "date";
$default_sortorder = "DESC";

/********************************************************
Default preferences...
********************************************************/
$send_to_trash_default = 1; //send deleted messages to trash
$st_only_ready_default = 1; //only read messages, otherwise, delete it
$save_to_sent_default  = 1; //send sent messages to sent
$empty_trash_default   = 1; //empty trash on logout
$sortby_default        = "date"; //alowed: "attach","subject","fromname","date","size"
$sortorder_default     = "DESC"; //alowed: "ASC","DESC"
$rpp_default           = 10; // records per page (messages), alowed: 10,20,30,40,50
$add_signature_default = 0; //add the signature by default
$signature_default     = ""; // an default signature for all users
?>
