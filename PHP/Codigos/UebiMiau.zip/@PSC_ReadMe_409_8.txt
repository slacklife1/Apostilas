Title: UebiMiau - POP3 WebMail
Description: UebiMiau is a simple, yet efficient cross-plataform POP3 mail reader written in PHP. Features: Folders, View and Send Attachments, Preferences, Search, Quota Limit, etc. UebiMiau does not require database or IMAP.
HomePage:
http://www.mycgiserver.com/~active/
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=409&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
