<?
Header("Location: ../");
?>