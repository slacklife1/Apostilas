<?
// load configs
include("config.php");
include("commom_functions.php");
error_reporting (E_ALL ^ E_NOTICE); 

// load template
$tcontent = read_file($error_template);
// replace the vars in template
$tcontent = eregi_replace("<!--%UM_SID%-->",$sid,$tcontent);
$tcontent = eregi_replace("<!--%UM_ERROR%-->",$msg,$tcontent);
// show result
echo($tcontent);
?>