<?
// load session management
include("session_management.php");
// keep cache clean
echo($nocache);

// use the char 149 as columm separator
$sp = chr(149);

$filename = $userfolder."_infos/addressbook.ucf";

// if the file does not exists, create it
if(!file_exists($filename)) { $tmp = fopen($filename,"wb+"); fclose($tmp); }
// load the file in an array
$addressbook = file($filename);

asort ($addressbook);
reset ($addressbook);

// clean spaces
for($i=0;$i<count($addressbook);$i++) $addressbook[$i] = trim($addressbook[$i]);

switch($opt) {
	// save an edited contact
	case "save":
		$line = "$name$sp$email$sp$street$sp$city$sp$state$sp$work";
		$addressbook[$id] = $line;

		$tmp = fopen($filename,"wb+"); 
		fwrite($tmp,join("\r\n",$addressbook));
		fclose($tmp);

		$tcontent = file($address_results_template);
		$tcontent = join("",$tcontent);

		$tcontent = eregi_replace("<!--%UM_GOBACK%-->","addressbook.php?sid=$sid&lid=$lid",$tcontent);
		$tcontent = eregi_replace("<!--%UM_MESSAGE%-->",sprintf($addr_saved,$email),$tcontent);
		break;

	// add a new contact
	case "add":
		$line = "$name$sp$email$sp$street$sp$city$sp$state$sp$work";
		$addressbook[] = $line;

		$tmp = fopen($filename,"wb+"); 
		fwrite($tmp,join("\r\n",$addressbook));
		fclose($tmp);

		$tcontent = file($address_results_template);
		$tcontent = join("",$tcontent);

		$tcontent = eregi_replace("<!--%UM_GOBACK%-->","addressbook.php?sid=$sid&lid=$lid",$tcontent);
		$tcontent = eregi_replace("<!--%UM_MESSAGE%-->",sprintf($addr_added,$email),$tcontent);

		break;
		
	//delete an existing contact
	case "dele":
		unset($addressbook[$id]);
		reset($addressbook);
		$tmp = fopen($filename,"wb+"); 
		fwrite($tmp,join("\r\n",$addressbook));
		fclose($tmp);
		$myfile = fopen($address_results_template,"r");
		$tcontent = fread($myfile,filesize($address_results_template));
		fclose($myfile);
		$tcontent = eregi_replace("<!--%UM_GOBACK%-->","addressbook.php?sid=$sid&lid=$lid",$tcontent);
		$tcontent = eregi_replace("<!--%UM_MESSAGE%-->",$addr_deleted,$tcontent);
		break;

	// show the form to edit
	case "edit":
		$myfile = fopen($address_form_template,"r");
		$tcontent = fread($myfile,filesize($address_form_template));
		fclose($myfile);

		$tcontent = eregi_replace("<!--%UM_SID%-->",$sid,$tcontent);
		$tcontent = eregi_replace("<!--%UM_GOBACK%-->","addressbook.php?sid=$sid&lid=$lid",$tcontent);

		$line = $addressbook[$id];
		$line = explode($sp,$line);

		$name = trim($line[0]);
		$email = trim($line[1]);
		$street = trim($line[2]);
		$city = trim($line[3]);
		$state = trim($line[4]);
		$work = trim($line[5]);

		$tcontent = eregi_replace("<!--%UM_OPT%-->","save",$tcontent);
		$tcontent = eregi_replace("<!--%UM_ADDR_ID%-->",$id,$tcontent);
		$tcontent = eregi_replace("<!--%UM_ADDR_NAME%-->",htmlspecialchars($name),$tcontent);
		$tcontent = eregi_replace("<!--%UM_ADDR_EMAIL%-->",htmlspecialchars($email),$tcontent);
		$tcontent = eregi_replace("<!--%UM_ADDR_STREET%-->",htmlspecialchars($street),$tcontent);
		$tcontent = eregi_replace("<!--%UM_ADDR_CITY%-->",htmlspecialchars($city),$tcontent);
		$tcontent = eregi_replace("<!--%UM_ADDR_STATE%-->",htmlspecialchars($state),$tcontent);
		$tcontent = eregi_replace("<!--%UM_ADDR_WORK%-->",htmlspecialchars($work),$tcontent);

		break;

	// display the details for an especified contact
	case "display":
		$myfile = fopen($address_display_template,"r");
		$tcontent = fread($myfile,filesize($address_display_template));
		fclose($myfile);

		$tcontent = eregi_replace("<!--%UM_GOBACK%-->","addressbook.php?sid=$sid&lid=$lid",$tcontent);

		$line = $addressbook[$id];
		$line = explode($sp,$line);

		$name = trim($line[0]);
		$email = trim($line[1]);
		$street = trim($line[2]);
		$city = trim($line[3]);
		$state = trim($line[4]);
		$work = trim($line[5]);

		$tcontent = eregi_replace("<!--%UM_ADDR_ID%-->",$id,$tcontent);
		$tcontent = eregi_replace("<!--%UM_ADDR_NAME%-->",htmlspecialchars($name),$tcontent);
		$tcontent = eregi_replace("<!--%UM_ADDR_EMAIL%-->",htmlspecialchars($email),$tcontent);
		$tcontent = eregi_replace("<!--%UM_ADDR_STREET%-->",htmlspecialchars($street),$tcontent);
		$tcontent = eregi_replace("<!--%UM_ADDR_CITY%-->",htmlspecialchars($city),$tcontent);
		$tcontent = eregi_replace("<!--%UM_ADDR_STATE%-->",htmlspecialchars($state),$tcontent);
		$tcontent = eregi_replace("<!--%UM_ADDR_WORK%-->",htmlspecialchars($work),$tcontent);

		break;

	// show the form to a new contact
	case "new":

		$myfile = fopen($address_form_template,"r");
		$tcontent = fread($myfile,filesize($address_form_template));
		fclose($myfile);
		$tcontent = eregi_replace("<!--%UM_GOBACK%-->","addressbook.php?sid=$sid&lid=$lid",$tcontent);

		$tcontent = eregi_replace("<!--%UM_SID%-->",$sid,$tcontent);
		$tcontent = eregi_replace("<!--%UM_OPT%-->","add",$tcontent);
		$tcontent = eregi_replace("<!--%UM_ADDR_ID%-->","N",$tcontent);
		$tcontent = eregi_replace("<!--%UM_ADDR_NAME%-->","",$tcontent);
		$tcontent = eregi_replace("<!--%UM_ADDR_EMAIL%-->","",$tcontent);
		$tcontent = eregi_replace("<!--%UM_ADDR_STREET%-->","",$tcontent);
		$tcontent = eregi_replace("<!--%UM_ADDR_CITY%-->","",$tcontent);
		$tcontent = eregi_replace("<!--%UM_ADDR_STATE%-->","",$tcontent);
		$tcontent = eregi_replace("<!--%UM_ADDR_WORK%-->","",$tcontent);

		break;
		
	// default is list
	default:

		$myfile = fopen($address_list_template,"r");
		$tcontent = fread($myfile,filesize($address_list_template));
		fclose($myfile);
		$tcontent = eregi_replace("<!--%UM_NEW_CONT%-->","addressbook.php?opt=new&sid=$sid&lid=$lid",$tcontent);
		$startpos = strpos($tcontent,"<!--%UM_LOOP_BEGIN%-->");
		$endpos = strpos($tcontent,"<!--%UM_LOOP_END%-->")+21;
		$cleanline = substr($tcontent,$startpos+22,$endpos-$startpos-43);

		while (list($line_num, $line) = each($addressbook)) {
			$line = explode(chr(149),$line);
			$name = trim($line[0]);
			$email = trim($line[1]);
			$thisline = $cleanline;
			$thisline = eregi_replace("<!--%UM_VIEW_LINK%-->","addressbook.php?opt=display&id=$line_num&sid=$sid&lid=$lid",$thisline);
			$thisline = eregi_replace("<!--%UM_NOME%-->",htmlspecialchars($name),$thisline);
			$thisline = eregi_replace("<!--%UM_EMAIL%-->",$email,$thisline);
			$thisline = eregi_replace("<!--%UM_EDIT_LINK%-->","addressbook.php?opt=edit&id=$line_num&sid=$sid&lid=$lid",$thisline);
			$thisline = eregi_replace("<!--%UM_DEL_LINK%-->","addressbook.php?opt=dele&id=$line_num&sid=$sid&lid=$lid",$thisline);
			$buffer .= $thisline;
		}
		$tcontent = substr($tcontent,0,$startpos).$buffer.substr($tcontent,$endpos);
}
$jssource = "
<script language=\"JavaScript\">
function goinbox() { location = 'msglist.php?folder=inbox&sid=$sid&lid=$lid'; }
function newmsg() { location = 'newmsg.php?pag=$pag&folder=".urlencode($folder)."&sid=$sid&lid=$lid'; }
function refreshlist() { location = 'addressbook.php?sid=$sid&lid=$lid' }
function folderlist() { location = 'folders.php?folder=".urlencode($folder)."&sid=$sid&lid=$lid'}
function search() { location = 'search.php?sid=$sid&lid=$lid'; }
function addresses() { location = 'addressbook.php?sid=$sid&lid=$lid'; }
function emptytrash() {	location = 'folders.php?empty=trash&folder=".urlencode($folder)."&goback=true&sid=$sid&lid=$lid';}
function goend() { location = 'logout.php?sid=$sid&lid=$lid'; }
function prefs() { location = 'preferences.php?sid=$sid&lid=$lid'; }
</script>
";
$tcontent = eregi_replace("<!--%UM_LID%-->",$lid,$tcontent);
$tcontent = eregi_replace("<!--%UM_JS%-->",$jssource,$tcontent);
echo($tcontent);
?>
