<?
include("session_management.php");

$sp = chr(149);
$filename = $userfolder."_infos/addressbook.ucf";
if(!file_exists($filename)) { $tmp = fopen($filename,"wb+"); fclose($tmp); }
$addressbook = file($filename);

asort ($addressbook);
reset ($addressbook);

$listbox = "<select name=contacts size=10>\r\n";
for($i=0;$i<count($addressbook);$i++) {
	$line = $addressbook[$i];
	$line = explode($sp,$line);
	$name = htmlspecialchars(trim($line[0]));
	$email = htmlspecialchars(trim($line[1]));
	$listbox .= "<option value=\"&quot;$name&quot; &lt;$email&gt;\"> &quot;$name&quot; &lt;$email&gt;";
}
$listbox .= "</select>";


$tcontent = read_file($quick_address_template);

$tcontent = eregi_replace("<!--%UM_CONTACTS%-->",$listbox,$tcontent);
echo($tcontent);

?>