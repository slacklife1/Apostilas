<?php
/* 
	Printversion for EasyCMS
	written by Christian Heilmann 
*/
echo "<link rel=\"StyleSheet\" href=\"styles.css\" type=\"text/css\">";
$chunks=explode("/",$HTTP_REFERER);
if ($chunks[count($chunks)-1]==""){$chunks[count($chunks)-1]="index.html";}

if ($chunks[count($chunks)-1] != "index.html"){$phile="../html/".$chunks[count($chunks)-1];}
else{$phile="../index.html";}
echo "<hr /><strong>This is the print version of ".$chunks[count($chunks)-1]." click <a href=\"$phile\" class=\"content\">here</a> to go back.</strong><hr />";
$HTML=load($phile);
preg_match_all("/<!--start:ecmscontent-->(.*?)<!--end:ecmscontent-->/si",$HTML,$d);
$HTML=$d[1][0];
$HTML=preg_replace("/<a.*?href=\"(.*?)\".*?>(.*?)<\/a>/m","&#187;\\2[URL: \\1] ",$HTML);
$HTML=preg_replace("/<img.*?alt=\"(.*?)\".*?>/m","&#187;Image[\\1] ",$HTML);
echo $HTML;
function load($filelocation){
	if (file_exists($filelocation)){
		$newfile = fopen($filelocation,"r");
		$file_content = fread($newfile, filesize($filelocation));
		fclose($newfile);
		return $file_content;
		}
	}
?>