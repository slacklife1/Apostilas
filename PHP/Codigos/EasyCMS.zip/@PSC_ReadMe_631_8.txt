Title: EasyCMS
Description: EasyCMS is a complete Content management system and site generator. It works with flat files and generates flat files, the live site does not need php or EasyCMS to run.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=631&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
