<?php
/*
	EasyCMS
	written by Christian Heilmann (info@onlinetools.org)
	Version 1.0
	Do not edit without consent of the author.
*/
echo "<link rel=\"STYLESHEET\" type=\"text/css\" href=\"ecms.css\">";
echo "
<form method=\"post\">
<div class=\"ecms\">
<div class=\"ecmslogo\"><img src=\"logo.gif\" alt=\"EasyCMS\" /></div>
<div class=\"ecmsnavitem\"><a href=\"index.php\" class=\"ecmslink\">Editor</a></div>
<div class=\"ecmsnavitem\">&#160;|&#160;</div>
<div class=\"ecmsnavitem\"><a href=\"index.php?help=commands\" class=\"ecmslink\">List Commands</a></div>
<div class=\"ecmsnavitem\">&#160;&#160;&#160;Editing Page:&#160;</div>&#160;&#160;&#160;";

if (!$page or preg_match("/index.html/",$page)){$page="home_home";}
$page=str_replace(".html","",$page);
$page=preg_replace("/.*\//","",$page);
$ispage=$page;
$page=explode("_",$page);
$HTML=load("template.html");
$navigation=load("navigation.xml");
$display=load("display.xml");
$navitems=untag($navigation,"mainitem",1);
$meta=untag($navigation,"meta",1);
$homedata=untag($navigation,"home",0);
$crumbs="<a class=\"crumbs\" href=\"../index.html\">Home</a>";
foreach ($navitems as $key=>$m){
	$mains[$key]=untag($m,"name",0);
	$subs["".$mains[$key].""]=untag($m,"subitem",1);
}
echo "<select name=\"page\" class=\"ecmsselect\">";
$mainsurl="home_".strtolower(str_replace(" ","",$homedata));
echo "<option value=\"$mainsurl\"";
if ($ispage==$mainsurl){echo " selected";}
echo ">$homedata</option>";
foreach ($meta as $m){
	$mainsurl=strtolower(str_replace(" ","",$m));
	echo "<option value=\"$mainsurl\"";
	if ($ispage==$mainsurl){echo " selected";}
	echo ">$m</option>";
	if ($ispage==$mainsurl){$crumbs.="&#160;&#62;&#160;<strong>$m</strong>";}
}
foreach ($mains as $m){
	$mainsurl=strtolower(str_replace(" ","",$m));
	echo "<option value=\"$mainsurl\"";
	if ($ispage==$mainsurl){echo " selected";}
	echo ">$mainsurl</option>";
	if($subs[$m][0]!=""){
		foreach ($subs[$m] as $s){
			$lefturl=urlize($s);
			echo "<option value=\"".$mainsurl."_".$lefturl."\"";
			if ($ispage==$mainsurl."_".$lefturl){echo " selected";}
			echo ">".$mainsurl."_".$lefturl."</option>";
		}
	}
}
echo "</select>&nbsp;<input type=\"submit\" name=\"action\" value=\"go\" class=\"ecmsbutton\" /></div></form>";

if ($help=="commands"){
	$commands=untag(load("commands.xml"),"command",1);
	echo "<div class=\"ecms\"><div class=\"ecmsheadline\">Easy CMS commands:</div><br />";
	foreach ($commands as $c){
		echo "<div class=\"ecmscommand\">".nl2br(untag($c,"syntax",0))."</div>";
		echo "<div class=\"ecmsinfo\">".untag($c,"info",0)."</div>";
		echo "<br clear=\"all\" class=\"ecmsbr\" />";
	}
	echo "<div align=\"right\" class=\"ecmscopy\"><a href=\"javascript:history.back()\" class=\"ecmslink\" >Back to Editor</a></div>";
	echo "</div>";
}



if (!$help){
	preg_match("/<!-- start:mainnav -->(.*?)<!-- end:mainnav -->/si",$HTML,$mainnav);
	preg_match("/<!-- start:active -->(.*?)<!-- end:active -->/si",$mainnav[0],$mainactive);
	preg_match("/<!-- start:inactive -->(.*?)<!-- end:inactive -->/si",$mainnav[0],$maininactive);
	foreach ($mains as $m){
		$inactive=$maininactive[0];
		$active=$mainactive[0];
		$mainsurl=urlize($m);
		if (preg_match("/^home_/",$ispage)){$addon="html/";}
		$active=str_replace("item",$m,$active);
		$active=str_replace("url",$addon.$mainsurl,$active);
		$inactive=str_replace("item",$m,$inactive);
		$inactive=str_replace("url",$addon.$mainsurl,$inactive);
		if ($page[0] != $mainsurl){$inc.=$inactive;}
		else {
			if ($page[1]!=""){
				$crumbs.="&#160;&#62;&#160;<a class=\"crumbs\" href=\"$mainsurl.html\">$m</a>";
			}
			else{
				$crumbs.="&#160;&#62;&#160;<strong>$m</strong>";
			}
			$inc.=$active;
		}
	}
	$HTML=preg_replace("/<!-- start:mainnav -->(.*?)<!-- end:mainnav -->/si",$inc,$HTML);
	$inc="";
	preg_match("/<!-- start:leftnav -->(.*?)<!-- end:leftnav -->/si",$HTML,$leftnav);
	preg_match("/<!-- start:active -->(.*?)<!-- end:active -->/si",$leftnav[0],$leftactive);
	preg_match("/<!-- start:inactive -->(.*?)<!-- end:inactive -->/si",$leftnav[0],$leftinactive);
	foreach ($mains as $m){
		$mainsurl=urlize($m);
		if ($page[0]==$mainsurl){
			if($subs[$m][0]!=""){
				foreach ($subs[$m] as $s){
					$inactive=$leftinactive[0];
					$active=$leftactive[0];
					$lefturl=urlize($s);
					if (preg_match("/^home_/",$ispage)){$addon="html/";}
					$active=str_replace("item",$s,$active);
					$active=str_replace("url",$addon.$mainsurl."_".$lefturl,$active);
					$inactive=str_replace("item",$s,$inactive);
					$inactive=str_replace("url",$addon.$mainsurl."_".$lefturl,$inactive);
					if ($page[1] != $lefturl){
						$inc.=$inactive;
					}
					else {
						$inc.=$active;
						$crumbs.="&#160;&#62;&#160;<strong>$s</strong>";
					}
				}
			}
		}
	}
	$HTML=preg_replace("/<!-- start:leftnav -->(.*?)<!-- end:leftnav -->/si",$inc,$HTML);
	if (!$content){$content=load("../data/$ispage.html");}
	$form="<form method=\"post\"><input type=\"hidden\" name=\"page\" value=\"$ispage\" /><textarea name=\"content\" cols=\"40\" rows=\"10\" class=\"ecmsarea\">".stripslashes($content)."</textarea><div align=\"right\"><input type=\"submit\" name=\"action\" value=\"save\" class=\"ecmsbutton\"></div></form>";
	
	if ($action=="generate"){
		if ($content!=""){
			$HTML=preg_replace("/<!-- content -->/si","<!--start:ecmscontent-->".stripslashes(deeasycms($content))."<!--end:ecmscontent-->",$HTML);
		}
		// avoid error with needle being nothing
		else {$HTML=preg_replace("/<!-- content -->/si","!!!content!!!",$HTML);}
		$HTML=preg_replace("/<!-- breadcrumbs -->/si",$crumbs,$HTML);
		$HTML=preg_replace("/<!-- .*? -->/si","",$HTML);
		$easycmsbranding="
<!-- 
	Document: $ispage
	Generated by EasyCMS (http://www.onlinetools.org/easycms/)
	Last change: ".date ("M d Y H:i:s")."
 -->";
		$HTML=preg_replace("/<body(.*?)>/si","<body\\1>$easycmsbranding\n",$HTML);
		$easycmsbranding="<br /><br /><div align=\"right\" style=\"color:#cccccc;font-family:verdana,arial,sans serif;font-size:10px\">Powered by <a href=\"http://easycms.onlinetools.org\" style=\"color:#ccccff;font-family:verdana,arial,sans serif;font-size:10px\">EasyCMS</a></div>";
		$HTML=preg_replace("/<\/body>/si","\n$easycmsbranding\n</body>",$HTML);
		// Adding page title and meta keywords.
		if (preg_match("/\[pagetitle:.*?]/si",$HTML)){
			preg_match_all("/\[pagetitle:(.*?)\]/si",$HTML,$pagetitle);
			$HTML=preg_replace("/<title>.*?<\/title>/si","<title>".$pagetitle[1][0]."</title>",$HTML);
			$HTML=preg_replace("/\[pagetitle:.*?\][\r|\n]<br \/>/si","",$HTML);
		}			
		if (preg_match("/\[pagekeywords:.*?]/si",$HTML)){
			preg_match_all("/\[pagekeywords:(.*?)\]/si",$HTML,$pagetitle);
			$HTML=preg_replace("/<\/title>/si","</title>\n<meta name=\"keywords\" content=\"".$pagetitle[1][0]."\" />",$HTML);
			$HTML=preg_replace("/\[pagekeywords:.*?\][\r|\n]<br \/>/si","",$HTML);
		}			
		if (preg_match("/\[pagedescription:.*?]/si",$HTML)){
			preg_match_all("/\[pagedescription:(.*?)\]/si",$HTML,$pagetitle);
			$HTML=preg_replace("/<\/title>/si","</title>\n<meta name=\"description\" content=\"".$pagetitle[1][0]."\" />",$HTML);
			$HTML=preg_replace("/\[pagedescription:.*?\][\r|\n]<br \/>/si","",$HTML);
		}			
		
		if (preg_match("/^home_/",$ispage)){
			$indexHTML=preg_replace("/\.\.\//","",$HTML);
			$indexHTML=preg_replace("/%%%site%%%/","html/",$indexHTML);
			$fileerror=save("../index.html",$indexHTML);
		} 
		else {
			$HTML=preg_replace("/%%%site%%%/","",$HTML);
			$fileerror=save("../html/$ispage.html",$HTML);
		}
		if ($content==""){$needle="!!!content!!!";} 
		else {$needle=stripslashes(deeasycms($content));}
		if ($fileerror==0){$savedthefilemessage="<div class=\"headline\">Success!</div>This page was generated.";}
		else{$savedthefilemessage="<div class=\"headline\">OOPS!</div>There was an error saving this file! Did you set correct file permissions?";}
		$HTML=str_replace($needle,$savedthefilemessage,$HTML);
	}
	if ($action=="save"){
		$content=str_replace("$","&#36;",$content);
		$fileerror=save("../data/$ispage.html",$content);
		if ($fileerror==0){
		$content.="<form method=\"post\"><input type=\"hidden\" name=\"page\" value=\"$ispage\" /><div align=\"right\"><input type=\"submit\" value=\"re-edit\" name=\"action\"  class=\"ecmsbutton\" />&#160;<input type=\"submit\" name=\"action\" value=\"generate\" class=\"ecmsbutton\" /></div></form>";
		}
		else {
		$content.="<div class=\"headline\">OOPS!</div>There was an error saving this file! Did you set correct file permissions?";
		}
		$HTML=preg_replace("/<!-- content -->/si",stripslashes(deeasycms($content)),$HTML);
		$HTML=preg_replace("/<!-- breadcrumbs -->/si",$crumbs,$HTML);
	}
	else{
		$HTML=preg_replace("/<!-- content -->/si",$form,$HTML);
		$HTML=preg_replace("/<!-- breadcrumbs -->/si",$crumbs,$HTML);
	}
	$HTML=preg_replace("/<a(.*?)href=\"/si","<a \\1 href=\"index.php?page=",$HTML);
	$HTML=preg_replace("/\[page.*?:.*?\][\r|\n]<br \/>/si","",$HTML);
	echo $HTML;
}

/*------------------------------------------------------------------------------
	Reused functions
------------------------------------------------------------------------------*/

/*
	Function deeasycms($content)
	takes the content and replaces each EasyCMS command with it's HTML equivalent.
*/
function deeasycms($content){
		$content=preg_replace("/\[headline:(.*?)\]/","<div class=\"headline\">\\1</div>",$content);	
		$content=preg_replace("/\[subheadline:(.*?)\]/","<div class=\"subheadline\">\\1</div>",$content);	
		$content=preg_replace("/\[bold:(.*?)\]/","<strong>\\1</strong>",$content);	
		$content=preg_replace("/\[sitelink:(.*?)\]/e","'<a href=\"%%%site%%%'.urlize('\\1').'.html\" class=\"content\">'.preg_replace('/.*_/','','\\1').'</a>'",$content);	
		$content=preg_replace("/\[email:(.*?)\]/","<a href=\"mailto:\\1\" class=\"content\">\\1</a>",$content);	
		$content=preg_replace("/\[textlink:(.*?)\|(.*?)\]/","<a href=\"http://\\1\" target=\"_blank\" class=\"content\">\\2</a>",$content);	
		$content=preg_replace("/\[image:(.*?)\|(.*?)\|(.*?)\]/","<img src=\"\\1\" alt=\"\\2\" align=\"\\3\" border=\"0\" />",$content);	
		$content=preg_replace("/\[startlink:(.*?)]/","<a class=\"content\" href=\"\\1\">",$content);	
		$content=preg_replace("/\[endlink]/","</a>",$content);	
		$content=preg_replace("/\[startpagelink:(.*?)]/","<a href=\"#\\1\" class=\"content\">",$content);	
		$content=preg_replace("/\[endpagelink]/","</a>",$content);	
		$content=preg_replace("/\[pagetarget:(.*?)]/","<a name=\"\\1\"></a>",$content);	
		$content=preg_replace("/\[start:list]/","<ul>",$content);	
		$content=preg_replace("/\[end:list]/","</ul>",$content);	
		$content=preg_replace("/\[startparagraph:(.*?)]/","<p align=\"\\1\">",$content);	
		$content=preg_replace("/\[endparagraph]/","</p>",$content);	
		$content=preg_replace("/\[item:(.*?)\]/","<li>\\1</li>",$content);	
		$content=preg_replace("/\[break\]/","<br clear=\"all\" />",$content);	
		$content=preg_replace("/\[start:html\](.*?)\[end:html\]/esi","'[start:html]'.preg_replace('/\n/','*NEWLINE*','\\1').'[end:html]'",$content);	
$content=preg_replace("/\[start:html\](.*?)\[end:html\]/esi","''.stripslashes('\\1').''",$content);	
$content=preg_replace("/\[start:code\](.*?)\[end:code\]/esi","'[start:code]'.preg_replace('/\n/','*NEWLINE*','\\1').'[end:code]'",$content);	
$content=preg_replace("/\[start:code\](.*?)\[end:code\]/esi","'<pre>'.stripslashes(htmlentities('\\1')).'</pre>'",$content);	

		$content=nl2br($content);
		$content=str_replace("*NEWLINE*","",$content);
		$content=preg_replace("/<\/li>[\r|\n]<br>/si","</li>",$content);	
		$content=preg_replace("/<ul>[\r|\n]<br>/si","<ul>",$content);	
		$content=preg_replace("/<p>[\r|\n]<br>/si","<p>",$content);	
		$content=preg_replace("/<\/p>[\r|\n]<br>/si","</p>",$content);	
		$content=preg_replace("/<td>[\r|\n]<br>/si","<td>",$content);	
		$content=preg_replace("/<tr>[\r|\n]<br>/si","<tr>",$content);	
		$content=preg_replace("/<\/td>[\r|\n]<br>/si","</td>",$content);	
		$content=preg_replace("/<\/tr>[\r|\n]<br>/si","</tr>",$content);	
		$content=preg_replace("/<br>/si","<br />",$content);
		return $content;	
}

/*
	Function urlize($name)
	converts an item name into a url na,e
*/
function urlize($name){
	return strtolower(preg_replace("/[^\w\.]/","",$name));
}

/*
	Function load($file)
	reads the content of the file that you send and returns it
*/
function load($filelocation){
	if (file_exists($filelocation)){
		$newfile = fopen($filelocation,"r");
		$file_content = fread($newfile, filesize($filelocation));
		fclose($newfile);
		return $file_content;
		}
	}

/*
	Function save($file,$content)
	writes the content to the file and generates it if needed
*/
function save($filelocation,$newdatas){
	$newfile = @fopen($filelocation,"w+");
	@fwrite($newfile, $newdatas);
	@fclose($newfile);
	if($newfile!=""){$fileerror=0;}
	else {$fileerror=1;}
	return $fileerror;
	}

/*
	Function untag($string,$tag,mode){
	written by Chris Heilmann (info@onlinetools.org)
	filters the content of tag $tag from $string 
	when mode is 1 the content gets returned as an array
	otherwise as a string
*/
function untag($string,$tag,$mode){
	$tmpval="";
	$preg="/<".$tag.">(.*?)<\/".$tag.">/si";
	preg_match_all($preg,$string,$tags); 
	foreach ($tags[1] as $tmpcont){
		if ($mode==1){$tmpval[]=$tmpcont;}
		else {$tmpval.=$tmpcont;}
		}
	return $tmpval;
}	

?>