<?php
//Read the file, specified here
$fcontents = file ('newsfile.txt');
$fNews = "";
$HeadFont = "<font face='Arial, Helvetica, sans-serif' color='black' size='3'><B>";
$DateFont = "<font face='Arial, Helvetica, sans-serif' color='black' size='1'><B>";
$BodyFont = "<small><font face='Arial, Helvetica, sans-serif' color='black' size='2'>";
$NewsArticles = 0;
//Set this value to the number of  max news entries
$MaxNewsArticles = 3;

while (list ($line_num, $line) = each ($fcontents)) {
	//HEADER  
	if (preg_match ("/<HEAD>/", $line)) {

		//News article limiter. Default set for 3
		$NewsArticles ++;
		if ($NewsArticles > $MaxNewsArticles) {
			break;
	
		}

		$fNews .= $HeadFont;

		do {
			list ($line_num, $line) = each ($fcontents);		
			$fNews .= $line .= "<BR>";

			if (preg_match ("<xHEAD>", $line)) {
				break;
			}
		} while (0);
		$fNews .= "</B></FONT>";
	}
	//END HEADER

	//DATE
	if (preg_match ("<Date>", $line)) {
		$fNews .= $DateFont;

		while (list ($line_num, $line) = each ($fcontents)) {		
			$fNews .= $line .= "<BR>";

			if (preg_match ("<xDate>", $line)) {
				break;
			}
		}
 		$fNews .= "</B></FONT>";
	}
	//END DATE

	//BODY
	if (preg_match ("<BODY>", $line)) {
		$fNews .= $BodyFont;

		while (list ($line_num, $line) = each ($fcontents)) {
			$fNews .= $line .= "<BR>";

			if (preg_match ("<xBODY>", $line)) {
				break;
			}
		}
 		$fNews .= "</B></FONT>";
	}
	//END BODY
}
//Write the news to the page
echo $fNews
?>      
