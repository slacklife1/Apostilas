Title: PHP Newsscript
Description: On my website I've got lots of tables. Normally updating the news just by editing the HTML/PHP file would be lots of work. That's why I normally used my ASP newsscript. But since my new provider does not have ASP, I've converted it to PHP. 
This script will read a textfile (no MySQL required!), and parse some command that define the subject,date, and the body. Makes your website far easier to maintain and to update.
It's also possible to set a maximum of News items to show. For a working example, check my website: <A HREF="http://www.quadrantwars.com">http://www.quadrantwars.com"</A>
Please note this is my first "venture" in PHP after all those years of ASP. If something could be better, please tell me. (also, don't forget to read the readme.txt)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=305&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
