Newsscript V1.0
By Almar Joling
E-Mail: quadrantwars@quadrantwars.com
Website: www.quadrantwars.com
-My ASP Newsscript converted to PHP

I've included a sample news file, to show how the system works. Unfortunatly,
I don't know how to create a "\" correctly in PHP, so that's why I'm using <xDate> for example as "terminator string"
Please note that for some strange reason, PHP doesn't accept DATE, you've got to use Date instead.
Also note that you can change the font colors and stuff just by chaning the 3 specified fonts.
Please note that this is my first PHP script, if anything could be optimized please tell me...

If you want to see a complete working example, goto www.quadrantwars.com

Almar Joling