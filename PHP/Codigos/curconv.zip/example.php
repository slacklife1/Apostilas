<?
include "curconv2.php";

$d = new curconv();
$money=$d -> uang("SGD","IDR");
echo $money;
?>