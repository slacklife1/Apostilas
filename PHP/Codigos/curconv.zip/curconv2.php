<?
/* Dadan Ramdan
 CurConv release 2.0
 License : Free
 thenewhiking@yahoo.com
 goto www.xe.com to see symbol your currency
 USD for USA
 IDR for Indonesian
 -- history Software --
 release 2.0
 Modification from v1.0 becoming class
 release 1.0
 modification from METEO live v1.0 by Martin Bolduc
*/
//USA
class curconv {

function uang($from,$to) {

$fa = fsockopen("www.xe.com", 80, &$num_erreur, &$str_erreur, 30);
if(!$fa)
   { print ""; }
else
{
  fputs($fa,"GET /ucc/convert.cgi?Amount=1&From=$from&To=$to HTTP/1.0\n\n");
  $answer=fgets($fa,128);

  while (!feof($fa))
     {
     $hal = fgets($fa, 4096);
     $hal= trim($hal) . "\n";
     if (substr($hal,0,5) == "1 $from")    { $v_cur    = substr($hal,7,10); break; }
     //print $hal . "\n";
    }
  fclose($fa);
}
return $v_cur;
}

}
?>
