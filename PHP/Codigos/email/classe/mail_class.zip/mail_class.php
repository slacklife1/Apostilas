<?php

/*----------------------------------------------*\

email -> classe para envio de emails com arquivos em anexo

	Autor: Cau Guanabara <cau@mplink.com.br>
	Data:  julho/agosto de 2003

Como usar a classe:
-----------------------------
Leia o arquivo 'leia.txt'.

Este sistema utiliza vari�veis de sess�o para preservar os atachados
entre as chamadas ao programa, portanto se pretende mandar atachados,
inicialize a sess�o no seu documento antes de qualquer coisa:
session_start();

Instanciando a classe:
-----------------------------
A fun��o construtora da classe recebe um array associativo que deve conter
no m�nimo os elementos "from" => "email_from" e "to" => "email_to".
Se o elemento "reply_to" for omitido, assumir� o valor de "from".
Os elementos "to", "cc", e "cco" aceitam valores de string ou arrays contendo 
os endere�os para o envio.
$eml = array(
             "from" => "from@domain",
             "to" => "to@domain", // ou array("to1@domain","to2@domain","'to3' <to3@domain>")
             "reply_to" => "reply_to@domain", // *par�metro opcional
             "cc" => "cc@domain", // ou array("cc1@domain","'cc2' <cc2@domain>") *par�metro opcional
             "cco" => "cco@domain", // ou array("cco1@domain","'cco2' <cco2@domain>") *par�metro opcional
             "subject" => "Message subject", *par�metro opcional
             "body" => "Message body", *par�metro opcional
             );
$mail = new email($eml);

Manipulando atachados:
-----------------------------
Preparar um arquivo para ser atachado
$att = $mail->prepare_att($uploaddir,$_FILES['file_field_name']);
	A fun��o prepare_att() devolve um array com os 3 elementos 
	nescess�rios � fun��o attach(). Recebe 2 par�metros:
	a url do diret�rio aonde ser� criado (e deletado) o arquivo tempor�rio,
	e o array $_FILES['file_field_name'], que cont�m o arquivo enviado.

Incluir um arquivo no array de atachados
$mail->attach($att[name],$att[contents],$att[type]);
	A fun��o attach() recebe 3 par�metros: o nome do arquivo,
	o conte�do do arquivo e o tipo do conte�do.
	Pode-se preparar esses par�meros manualmente, ou utilizar
	a fun��o prepare_att(). Retorna um valor boleano.

Remover um arquivo do array de atachados
$mail->unattach($att_name);
	A fun��o unattach() recebe apenas o nome do atachado a ser exclu�do.
	Retorna um valor boleano.

Recuperar os nomes dos atachados atuais
$mail->attnames();
	Devolve um array com os nomes dos arquivos atachados no momento.

Enviar o email
-----------------------------
$mail->send();
	Retorna um valor boleano.

M�todos privados
-----------------------------
$mail->_head();
	Monta o cabe�alho da mensagem.

$mail->_body();
	Monta o corpo da mensagem.

\*----------------------------------------------*/

#
#// Classe para enviar emails com atachados
#
class email {

	var $from = "";
	var $reply_to = "";
	var $to = "";
	var $cc = "";
	var $cco = "";
	var $subject = "";
	var $headers = "";
	var $body = "";
	var $htmlbody = "";
	var $boundary = "";
	var $attachs = array();
	var $attached = array();

	#
	#// contrutora da classe (apenas seta as variaveis)
	#
	function email($eml = array()) {
	
	mt_srand((double)microtime()*1000000);
	$bndry = "----=PHP_email_Class_ATT_000";
	preg_match_all("/.{4}/", uniqid(mt_rand()), $sbo);
		for($i=0;$i<3;$i++) 
			$bndry .= "_".$sbo[0][$i];
	
		if (session_is_registered("PHP_email_Class_atts")){ 
		$this->attachs = $_SESSION['PHP_email_Class_atts'];
			foreach($this->attachs as $att) 
				$this->attached[] = $att['filename'];
		}
		
	$this->boundary = $bndry;
	$this->from = $eml['from'];
	$this->reply_to = empty($eml['reply_to']) ? $eml['from'] : $eml['reply_to'];
	$this->to = is_array($eml['to']) ? join(",",$eml['to']) : $eml['to'];
	$this->cc = is_array($eml['cc']) ? join(",",$eml['cc']) : $eml['cc'];
	$this->cco = is_array($eml['cco']) ? join(",",$eml['cco']) : $eml['cco'];
	$this->subject = $eml['subject'];
	$this->body = $eml['body'];
	}
	
	#
	#// interna - cria o cabe�alho da mensagem
	#
	function _head() {
	$head .= "From: ".$this->from."\r\n";
	$head .= "Reply-to: ".$this->reply_to."\r\n";
	$head .= "To: ".$this->to."\r\n";
	if(!empty($this->cc)) $head .= "Cc: ".$this->cc."\r\n";
	if(!empty($this->cco)) $head .= "Cco: ".$this->cco."\r\n";
	$head .= "MIME-Version: 1.0\r\n";
	$head .= "Content-Type: multipart/mixed; \r\n\t".
			"boundary = \"".$this->boundary."\"\r\n";
	$head .= "X-Mailer: PHP_email_Class 1.0\r\n\r\n";
	return $head;
	}
	
	#
	#// interna - cria o cabe�alho da mensagem HTML
	#
	function _html_head() {
	$head .= "From: ".$this->from."\r\n";
	$head .= "Reply-to: ".$this->reply_to."\r\n";
	$head .= "To: ".$this->to."\r\n";
	if(!empty($this->cc)) $head .= "Cc: ".$this->cc."\r\n";
	if(!empty($this->cco)) $head .= "Cco: ".$this->cco."\r\n";
	$head .= "MIME-Version: 1.0\r\n";
	$head .= "Content-Type: text/html\r\n\tcharset=\"iso-8859-1\"\r\n";
	$head .= "X-Mailer: PHP_email_Class 1.0\r\n\r\n";
	return $head;
	}
	
	#
	#// interna - cria o corpo da mensagem
	#
	function _html_body($body) {
	return $this->htmlbody = $body;
	}
	
	#
	#// interna - cria o corpo da mensagem
	#
	function _body() {
	
	$newbound = preg_replace('/ATT_000/','ATT_001',$this->boundary);
	
	$msg = "This is a multi-part message in MIME format.\r\n\r\n";
	$msg .= "--".$this->boundary."\r\n";
	$msg .= "Content-Type: multipart/alternative;\r\n\t".
			"boundary=\"$newbound\"\r\n\r\n";
	
	preg_match_all("/<[^>]+>/", $this->body, $tags);
	
		if(count($tags[0]) < 4) { // n�o � html
		$this->htmlbody = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n".
		"<html>\n\t<head>\n\t\t<title>email_Class - Mensagem recebida</title>\n\t\t".
		"<meta name=\"generator\" content=\"PHP_email_Class 0.1\">\n\t</head>\n\t<body>\n\t\t".
		"<font face=\"Verdana,Arial\" size=\"2\">\r\n".nl2br($this->body).
		"\n\t\t</font>\n\t</body>\n</html>\n";
		} else { // � html
		$this->htmlbody = $this->body;
		$this->body = "";
		}	
	
	$msg .= "--$newbound\r\n";
	$msg .= "Content-type: text/plain\r\n\tcharset=\"iso-8859-1\"\r\n";
	$msg .= "Content-Transfer-Encoding: quoted-printable\r\n\r\n";
	$msg .= $this->body."\r\n\r\n";
	$msg .= "--$newbound\r\n";
	$msg .= "Content-type: text/html\r\n\tcharset=\"iso-8859-1\"\r\n";
	$msg .= "Content-Transfer-Encoding: quoted-printable\r\n\r\n";
	$msg .= $this->htmlbody."\r\n\r\n";
	$msg .= "--$newbound--\r\n\r\n";
		if(count($this->attachs) > 0) {
			foreach($this->attachs as $attachment) {
				if($attachment[encoding] == "base64") 
					$attachment[data] = chunk_split(base64_encode($attachment[data]));
			$data = "--".$this->boundary."\r\n";
			$data .= "Content-type: ".$attachment[type].";\r\n\t";
			$data .= "name = \"".$attachment[filename]."\"\r\n";
			$data .= "Content-Transfer-Encoding: ".$attachment[encoding]."\r\n";
			$data .= "Content-Disposition: attachment;\r\n\t";
			$data .= "filename=\"".$attachment[filename]."\"\r\n\r\n";
			$data .= $attachment[data]."\r\n\r\n";
			
			$msg .= $data;
			}
		}
	$msg .= "--".$this->boundary."--\r\n\r\n";
	
	return $msg;
	}
	
	#
	#// prepara um arquivo enviado por formul�rio para $this->attach().
	#
	function prepare_att($uploaddir,$att) {
	is_dir($uploaddir) or 
		die("prepare_att: A URL '$uploaddir' n�o se refere a um diret�rio\n");
	
	move_uploaded_file($att['tmp_name'], $uploaddir.$att['name']) 
		or die("prepare_att: N�o movi o arquivo\n");
	
	$arq = fopen($uploaddir.$att['name'],"r") or die("prepare_att: Nao abri o arquivo\n");
	$readfile = fread($arq, filesize($uploaddir.$att['name']));
	fclose($arq);
	
	unlink($uploaddir.$att['name']) 
		or die("prepare_att: N�o deletei o arquivo\n");
	
	return array(
				"name" => $att['name'],
				"contents" => $readfile,
				"type" => $att['type']
				);
	} 

	#
	#// insere um arquivo no array de atachados
	#
	function attach($name,$contents,$type) {
		
	if(preg_match("/^text/",$type)) $encoding = "quoted-printable";
	!empty($encoding) or $encoding = "base64";
				
		if($this->attachs[] = array(
							"filename" => $name,
							"type" => $type,
							"encoding" => $encoding,
							"data" => $contents
							) and !empty($name) and !empty($contents)) {

			if (!session_is_registered("PHP_email_Class_atts")){ 
			session_register("PHP_email_Class_atts"); 
			}
			
		$_SESSION['PHP_email_Class_atts'] = $this->attachs;
		$this->attached = array();
		foreach($this->attachs as $att) 
			$this->attached[] = $att['filename'];
		return true; 
		}
	}
	
	#
	#// retira um arquivo do array de atachados
	#
	function unattach($arq) {
	$rtrn = false;
		if(count($this->attachs) == 1) {
		$one = 1;
		$this->attachs = array();
		$this->attached = array();
		$rtrn = true;
		} else {
			for($i=0;$i<count($this->attachs);$i++) {
				if($this->attachs[$i]['filename'] == trim($arq)) {
				unset($this->attachs[$i]);
					if(!isset($this->attachs[$i])) {
					$rtrn = true;
					}
				}
			}	
			if($rtrn == true) {
			$this->attached	= array();
				foreach($this->attachs as $att) 
					$this->attached[] = $att['filename'];
			}
		}
		
		if(!empty($this->attachs)) { 
		unset($_SESSION['PHP_email_Class_atts']);
			foreach($this->attachs as $at)
				$_SESSION['PHP_email_Class_atts'][] = $at;
		} else {
			if($one == 1) {
			unset($_SESSION['PHP_email_Class_atts']);
			session_destroy();
			$rtrn = true;
			}
		}
	return $rtrn;
	}
	
	#
	#// devolve um array com os nomes dos arquivos atachados
	#
	function attnames() {
		if(session_is_registered("PHP_email_Class_atts")){ 
		$this->attachs = $_SESSION['PHP_email_Class_atts'];
		$this->attached = array();
		foreach($this->attachs as $att) $this->attached[] = $att['filename'];
		}
	return $this->attached;
	}
	
	#
	#// manda a mensagem 
	#
	function send($type = '') {
	
		if($type == 'html') {
		return mail($this->to,$this->subject,$this->_html_body($this->body),$this->_html_head());
		} else {
			if (session_is_registered("PHP_email_Class_atts")){ 
			unset($_SESSION['PHP_email_Class_atts']);
			session_destroy();
			}
		return mail($this->to,$this->subject,$this->_body(),$this->_head());
		}
	}

}

?>