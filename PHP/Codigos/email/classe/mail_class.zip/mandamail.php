<?php

/* ------------------------------------------- *\
     Exemplo de utiliza��o da classe email()     
\* ------------------------------------------- */

// se n�o h� atachados, isso � desnecess�rio...
session_start();

// se o usuario j� preencheu o formul�rio de envio
if(!empty($_POST)) {
	// setando as variaveis
	while (list($nome,$valor) = each($_POST)) {
		$$nome = $valor;
	}
	// validando
	if($enviar == 'true') {
	($from and $to) or die("Falta de par�metros");
	}
require "mail_class.php";
$eml = array("from" => $from, "to" => $to, "subject" => $subject, "body" => $body);
$mail = new email($eml); 
} else {
entra();
}

/* Form para compor a mensagem */
function entra($dados= array()) {
global $mail;

?>
<html>
<head>
<title>Compor mensagem</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="javascript">
function confmail() {
	
	if(document.mail.to.value == '') {
	alert('� preciso especificar um destinat�rio');
	return false;
	}
	
	if(document.mail.subject.value == '') {
	alert('� preciso especificar um assunto para o email');
	return false;
	}
		
	if(document.mail.to.value != "") {
		if(confere(document.mail.to.value) == false) {
		return false;
		} 
	}
	
}
function confere(mai) {
count=0;

	for(i=0;i<mai.length;i++){
	if(mai.charAt(i)=="@") { count++; 	}
	}
ma = /^(\w+)(\.|-|\w)*@/;
if(!ma.test(mai)) { count++; }
ma = /@(\w+)(\.|-|\w)*\.(\w{2,3})$/;
if(!ma.test(mai)) { count++; }
	if(count != 1){
	alert('E-mail inv�lido');
	return false;
	} else { return true; }
}
</script>
</head>

<body text="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" bgcolor="#CCCCCC" >
<form enctype="multipart/form-data" name="mail" action="http://<?php print getenv('HTTP_HOST').getenv('SCRIPT_NAME'); ?>" method="post" onSubmit="return confmail()">
<?php /*
 Para conseguirmos atachar v�rios arquivos ao email, precisamos de dois campos
hidden, o campo 'enviar', setado como "true" e o campo 'anexo', com valor em branco.
O primeiro serve para informar ao script se o usuario quer enviar o email ou incluir/excluir
um arquivo da rela��o de atachados. No momento em que o usuario clica em 'anexar' ou clica no
arquivo para exclu�-lo, o campo 'enviar' � setado para "false", ent�o o m�todo send() n�o �
executado, apenas o attach() ou o unattach(). 
*/?>
<input type="hidden" name="anexo" value="">
<input type="hidden" name="enviar" value="true">
  <table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#cccccc">
  <tr> 
    <td colspan="2"><font size="2" face="verdana, arial">
	 &nbsp; &raquo; Compor nova mensagem
	 </font></td>
  </tr>
  <tr bgcolor="#e9e9e9"> 
    <td colspan="2">&nbsp;</td>
  </tr>

  <tr bgcolor="#e9e9e9">
      <td width="10%" align="right"><font face="verdana, arial" size="2">De:</font></td>
      <td width="90%"> <input type="text" name="from" size="43" value="<?php print $dados[from]; ?>">&nbsp;</td>
  </tr>
  <tr bgcolor="#e9e9e9"> 
      <td width="10%" align="right"><font face="verdana, arial" size="2">
	  Para: 
        </font></td>
      <td width="90%"><font face="verdana, arial" size="2"> 
        <input type="text" name="to" size="43" value="<?php print $dados[to]; ?>">
      </font></td>
  </tr>
   <tr bgcolor="#e9e9e9"> 
      <td width="10%" align="right"><font face="verdana, arial" size="2">Anexar:</font></td>
      <td width="90%"> <font face="verdana, arial" size="2">
    <input type="file" name="attachment" title="Clique para procurar o arquivo a ser anexado">
	<input type="button" name="anex" value="Anexar" onClick="if(document.mail.attachment.value==''){alert('N�o h� nada para anexar');return false;}else{document.mail.enviar.value='false';document.mail.submit()}" title="Clique anexar o arquivo">
	<input type="hidden" name="MAX_FILE_SIZE" value="1024000">
   </font> </td>
  </tr>
<?php 
/* Verificando se j� h� atachados */
if(!empty($_POST)) {
// se $_POST n�o est� vazio, a classe j� foi instanciada
$_attnames = $mail->attnames();
}
if(count($_attnames) > 0) {
// se j� h� atachados, crio os links para a op��o de desanexar 
$attlinks = '';
	for($i=0;$i<count($_attnames);$i++) {
	$attlinks .= "<a href=\"javascript:document.mail.enviar.value='false';".
					"document.mail.anexo.value='".$_attnames[$i].
					"';document.mail.submit()\" title=\"Clique para excluir ".
					"da lista de atachados\">".$_attnames[$i]."</a>";
	if($i < count($_attnames) - 1) $attlinks .= " | ";
	}
$attnames = join(", ",$_attnames);
}
/* Se existem atachados, mostra ao usuario, permitindo a exclus�o */
if(!empty($attnames)) { ?>
  <tr bgcolor="#e9e9e9"> 
      <td width="10%" align="right"><font face="verdana, arial" size="2">
		Anexos:</font></td>
    <td width="90%"> 
	  <table width="350"><tr><td><font face="verdana, arial" size="2">
	  <?php print $attlinks; ?></font></td></tr></table>
   </td>
  </tr>
<?php } ?>
  <tr bgcolor="#e9e9e9"> 
      <td width="10%" align="right"><font face="verdana, arial" size="2">T&iacute;tulo:</font></td>
      <td width="90%"> 
        <input type="text" name="subject" size="43" value="<?php print $dados[subject]; ?>">
    </td>
  </tr>
    <tr bgcolor="#e9e9e9"> 
      <td colspan="2"><font face="verdana, arial" size="2"> &nbsp; 
        &nbsp; &nbsp; 
        <textarea name="body" cols="50" rows="10"><?php print $dados[body]; ?></textarea>
        </font></td>
  </tr>
    <tr bgcolor="#CCCCCC"> 
      <td colspan="2" valign="top" align="right"><font face="verdana, arial" size="2"> 
        <input type="button" value="Cancelar" onClick="window.close()">
      <input type="submit" value="Enviar">
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></td>
  </tr>
</table>
</form>
</body>
</html>
<?php
exit;
}

/* Se enviar � false, trata-se de anexar ou exculir um arquivo */
if($enviar == 'false') { 
$_attnames = $mail->attnames();	

	// incluir anexo
	if(!empty($_FILES[attachment]) and !$anexo) {	
		if(!in_array($_FILES[attachment][name],$_attnames)) {
		$att = $mail->prepare_att('/tmp/',$_FILES[attachment]);
		$mail->attach($att[name],$att[contents],$att[type])
			or die("erro em attach\n");
		}
	}
	
	// excluir anexo
	if(!empty($anexo)) { 
		if(in_array($anexo,$_attnames)) {
		$mail->unattach($anexo)
			or die("erro em unattach\n");
		}
	}

$dados = array(
               'from'    => $from,     // remetente
               'to'       => $to,      // destinatario
               'subject'  => $subject, // titulo do email
               'body'     => $body,    // corpo do email
               );
entra($dados);
}

/* Se enviar � true, manda a mensagem */
if($enviar == 'true') {
print $mail->send() ? "envio ok!\n" : "houve um erro...\n";
}

exit;
?>
