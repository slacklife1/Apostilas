<?php 

require "mail_class.php";
$from = '...@.....com.br';
$to = '...@....com.br';
$subject = 'teste mail';
$body = '
<html>
........
</html>
';
$eml = array("from" => $from, "to" => $to, "subject" => $subject, "body" => $body);
$mail = new email($eml);

$mail->send('html');


?>