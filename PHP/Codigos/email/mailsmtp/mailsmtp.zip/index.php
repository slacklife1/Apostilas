<title>MailSmtp - Formul�rio de Contato</title>
<form name="form1" method="post" action="mailsmtp.php">
  <table width="100" border="0" cellspacing="0" cellpadding="0" align="center">
    <caption><b><font color="#000080" size="5">Formul�rio de Contato...</font></b></caption>
    <tr bgcolor="#F4F4F4"> 
      <td valign="top" width="100" nowrap><font class="texto" color="#000080">Nome:</font></td>
      <td> 
        <input class="form_campos" type="text" name="nome" size="34">
      </td>
    </tr>
    <tr bgcolor="#EFEFEF"> 
      <td valign="top" width="100" nowrap><font class="texto" color="#000080">Cidade</font></td>
      <td> 
        <input class="form_campos" type="text" name="cidade" size="20">
      </td>
    </tr>
    <tr bgcolor="#F4F4F4"> 
      <td valign="top" width="100" nowrap><font class="texto" color="#000080">Estado:</font></td>
      <td> 
        <input class="form_campos" type="text" name="estado" size="11">
      </td>
    </tr>
    <tr bgcolor="#EFEFEF"> 
      <td valign="top" width="100" nowrap><font class="texto" color="#000080">E-mail:</font></td>
      <td> 
        <input class="form_campos" type="text" name="email" size="34">
      </td>
    </tr>
    <tr bgcolor="#F4F4F4"> 
      <td valign="top" width="100" nowrap><font class="texto" color="#000080">Assunto:</font></td>
      <td> 
        <select class="form_campos" name="assunto">
          <option class="form_campos" value="Opini�o" selected>Opini�o</option>
          <option class="form_campos" value="Sugest�o">Sugest�o</option>
          <option class="form_campos" value="Parceria">Parceria</option>
          <option class="form_campos" value="Reclama��o">Reclama��o</option>
          <option class="form_campos" value="Sem assunto">Outros</option>
        </select>
      </td>
    </tr>
    <tr bgcolor="#EFEFEF"> 
      <td valign="top" width="100" nowrap><font class="texto" color="#000080">Mensagem:</font></td>
      <td> 
        <textarea class="form_campos" name="mensagem" cols="34" rows="4"></textarea>
      </td>
    </tr>
    <tr bgcolor="#F4F4F4"> 
      <td colspan="2" valign="middle"> 
	  	<br>
        <div align="center"> 
          <input class="form_botao" type="submit" name="Enviar" value="Enviar Mensagem" style="color: #000080; font-size: 8 pt; background-color: #EFEFEF">
          <input class="form_botao" type="reset" name="Limpar" value="Limpar" style="font-size: 8 pt; color: #000080; background-color: #EFEFEF">
        </div>
      </td>
    </tr>
  </table>
</form>
<p align="center"><font size="2" color="#000080">MailSmtp por Adailton 
Milhorini...</font></p>