/************************************
/  MailSmtp - Script para enviar email via smtp
/  tipo formmail com auto-resposta opcional...
/  
/  Arquivos necess�rios
/  mailsmtp.php 
/  class.smtp.inc
/  config.php
/
/  Como Utilizar
/  Criar Formul�rio e em action colocar action="mailsmtp.php"
/  ex: 
/  <form name="form1" method="post" action="mailsmtp.php">
/
/  Se quiser que tenha um e-mail de auto resposta defina
/  um campo em seu formul�rio com o nome de email ou com
/  o nome configurado em $autoresposta dentro do config.php
/  
/  Importante...
/  Configure o config.php conforme os dados de seu servidor
/  e tamb�m com suas personaliza��es...
/
/
/  Vers�o 1.0 
/  Desenvolvido por: Adailton Milhorini
/  E-mail: adailtonof@ig.com.br
/  Linux User# 134234
**************************************/
