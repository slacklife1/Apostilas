<?
/************************************
/  MailSmtp - Script para enviar email via smtp
/  tipo formmail com auto-resposta opcional...
/  
/  Arquivos necess�rios
/  mailsmtp.php 
/  class.smtp.inc
/  config.php
/
/  Como Utilizar
/  Criar Formul�rio e em action action="mailsmtp.php"
/  ex: 
/  <form name="form1" method="post" action="mailsmtp.php">
/
/  Se quiser que tenha um e-mail de auto resposta defina
/  um campo em seu formul�rio com o nome de email ou com
/  o nome configurado em $autoresposta dentro do config.php
/
/  Vers�o 1.0 
/  Desenvolvido por: Adailton Milhorini
/  E-mail: adailtonof@ig.com.br
/  Linux User# 134234
**************************************/

include('class.smtp.inc');


// formata��o da mensagem com campos do formul�rio
if (isset($HTTP_POST_VARS))
		$msg .= "IP : " . getenv ("REMOTE_ADDR") ."\r\n";
           while (list($key, $value) = each($HTTP_POST_VARS)){ 
		$msg .= strtoupper($key) . ' : ' . $value . "\r\n"; 
            } 


include("config.php");


//verifica se existe campo para auto resposta
 reset($HTTP_POST_VARS);
  if (isset($HTTP_POST_VARS)) 
 	while (list($key, $value) = each($HTTP_POST_VARS)){ 
    	    if (($key == $autoresposta) and (!email_ok($value))) {
	
	echo ("<body bgcolor=$background text=$texto link=$link vlink=$link alink=$link><title>$erro_titulo</title>
      <center><h2>$erro_msg</h2></center><br><center>
    <a href=\"javascript:window.history.go(-1)\">Clique aqui para Voltar...</a></center>
<br><center><h4>MailSmtp por Adailton Milhorini...</h4></center></font></body>");
			exit;
		}
	}



//verifica se o email � valido

	if(is_object($smtp = smtp::connect($params)) AND $smtp->send($send_params)){  
		
		//redireciona para p�gina ok
		Header ("Location: $pagina_ok");

		// verifica se tem o campo de auto-resposta
   	  	 reset($HTTP_POST_VARS);
         	if (isset($HTTP_POST_VARS)){ 
 			while (list($key, $value) = each($HTTP_POST_VARS)){ 
            	    if ($key == $autoresposta) {
				//configuracoes de auto-resposta
				$send_params['recipients']	= explode(",",$$autoresposta);
		     	 $send_params['headers']		= array("From: $msg_para","To: " . $$autoresposta,"Subject: $msg_assuntoresposta");
				$send_params['from']		= $msg_para;	
				$send_params['body']		= $msg_resposta;	
         			@ is_object($smtp = smtp::connect($params)) AND $smtp->send($send_params);
				}
			}
		}
	}else 		
	// redireciona para pagina com erro
	Header ("Location: $pagina_erro");



?>

