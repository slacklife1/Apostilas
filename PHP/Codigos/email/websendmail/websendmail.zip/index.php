<?PHP

if (!$lang){
require("lang/br.php");
}
else{
$lang_file="lang/$lang.php";
require($lang_file);
}
?>

<html>
<head>
<title>Envia e-mail KMEducation</title>
<style type="text/css">
.onLoad	     {

         color:#109EBD;
         background:white;
         scrollbar-face-color:#109EBD;
             }
             
.Email {
        color:blue;
        text-decoration:underline;
    }
	
.Menu	 {

         color:darkblue;
         background:#FFFFFF;
             }
.black {

         color:white;
         background:black;
      }
.red {

         color:white;
         background:red;
      }

.blue {

         color:white;
         background:blue;
      }

.yellow {

         color:darkblue;
         background:yellow;
      }

.silver {

         color:darkblue;
         background:silver;
      }

.aqua {

         color:darkblue;
         background:aqua;
      }
 
    </style>
    


<meta http-equiv="Content-Type" content="text/html; charset=<?PHP echo $charset;?>">
<script language="JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->
</script>
</head>

<body bgcolor="#FFFFFF" text="#000000">
<form name=formname action="send.php" method=post>


<input type=hidden name =charset value=<?PHP echo $charset;?>>
<input type=hidden name =name_user value=<?PHP echo $name_user;?>>
<input type=hidden name =subject_user value=<?PHP echo $subject_user;?>>
<input type=hidden name =message_user value=<?PHP echo $message_user;?>>
  <div id="Layer1" style="position:absolute; width:766px; height:340px; z-index:1; left: 92px; top: 30px"> 
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr> 
        <td align="right"> 
          <p><font face="Verdana, Arial, Helvetica, sans-serif" size="5"><b><font size="6">WEB 
            SEND MAIL</font><br>
            </b></font><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#004080">Por: 
            Thiago Alves Goulart<br>
            e-mail: thiago_algo@brturbo.com</font></b></p>
          </td>
      </tr>
    </table>
    <table width="100%" border="0" cellspacing="0" cellpadding="0" height="1" bgcolor="#004080" >
      <tr>
        <td><font color=white face=Verdana size=2><b><?PHP echo $language_string;?></b></font></td>
      </tr>
    </table>
    <table width="100%" border="0" cellspacing="0" cellpadding="0" height="68">
    <tr> 
      <td width="9%"><font color=darkblue face=Verdana size=2><?PHP echo $name_user;?></font></td>
        <td width="91%"> 
          <select name="sender">
            <option selected>---- Selecione o usu&aacute;rio ----</option>
            <option value="thiago_algo@hotmail.com">Thiago</option>
          </select>
        </td>
    </tr>
    <tr> 
      <td width="9%"><font color=darkblue face=Verdana size=2><?PHP echo $email_user;?></font></td>
        <td width="91%"> 
          <input type="text" name="receiver" size="100%">
        </td>
    </tr>
    <tr> 
        <td width="9%">
          <font color=darkblue face=Verdana size=2><?PHP echo $subject_user;?></font>
        </td>
      <td width="91%">
          <input type="text" name="subject" size="100%">
        </td>
    </tr>
  </table>
  <table width="100%" border="0" cellspacing="0" cellpadding="0" height="1" bgcolor="#004080">
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr> 
        <td width="28%"> 
          <div align="center"><font size="1" face="Verdana" color="#004080"><?echo $font_color;?></font></div>
        </td>
        <td width="20%"> 
          <div align="center"><font size="1" face="Verdana" color="#004080"><?echo $back_color;?></font></div>
        </td>
        <td width="21%"> 
          <div align="center"><font size="1" face="Verdana" color="#004080"><?echo $font_face;?></font></div>
        </td>
        <td width="21%"> 
          <div align="center"><font size="1" face="Verdana" color="#004080"><?echo $font_size;?></font></div>
        </td>
        <td width="10%"> 
          <div align="center"><font size="1" face="Verdana" color="#004080"><?echo $priority;?></font></div>
        </td>
      </tr>
      <tr> 
        <td width="28%"><font color="#148FB8"> 
          <center>
            <select name="fontcolor" class="Menu">
              <?
			  $qtd_font_color=count($font_color_value);
			  for($i=0; $i<$qtd_font_color; $i++){
			  ?>
			  <option value="<?echo $font_color_value[$i];?>"><?echo $font_color_name[$i];?></option>
              <?}?>
            </select>
          </center>
          </font></td>
        <td width="20%"><font color="#148FB8"> 
		<center>
          <select name="bgcolor" class="Menu">
              <?
			  $qtd_back_color=count($back_color_value);
			  for($i=0; $i<$qtd_back_color; $i++){
			  ?>
			  <option value="<?echo $back_color_value[$i];?>"><?echo $back_color_name[$i];?></option>
              <?}?>
            </select>
		  </center>
          </font></td>
        <td width="21%"><font color="#148FB8">
		<center>
          <select name="fontface" class="Menu">
            <option value="Verdana" >Verdana</option>
            <option value="Times New Roman" >Times New Roman</option>
            <option value="Times" >Times</option>
            <option value="Helvetica" >Helvetica</option>
            <option value="Courier" >Courier</option>
            
          </select>
		  </center>
          </font></td>
        <td width="21%">
		<font color="#148FB8">
		<center>
          <select name ="fontsize" class="Menu">
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
			<option value="+1">+1</option>
			<option value="+2">+2</option>
			<option value="+3">+3</option>
          </select>
		  </center>
          </font></td>
        <td width="10%"><font color="#148FB8"> 
		<center>
          <select name ="prio" class="Menu">
              <option value="5"><?echo $priority_low;?></option>
              <option value="3"><?echo $priority_normal;?></option>
              <option value="1"><?echo $priority_hight;?></option>
            </select>
		  </center>
          </font></td>
      </tr>
    </table>
	<table width="100%" border="0" cellspacing="0" cellpadding="0" height="1" bgcolor="#004080">
      <tr>
        <td height="1">&nbsp;</td>
      </tr>
    </table>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><font color=darkblue face=Verdana size=3><?PHP echo $message_user?></font><p>
            <textarea name="message" cols="93%" rows="15" wrap="VIRTUAL"></textarea>
          </p></td>
      </tr>
    </table>
    <p>
      <input type="submit" name="Submit" value="<?PHP echo $submit_button;?>">
    </p>
</div>
</form>
</body>
</html>
