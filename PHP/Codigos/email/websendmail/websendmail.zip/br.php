<?PHP
$name_user="De: ";
$email_user="Para: ";
$subject_user="Assunto: ";
$message_user="Messagem: ";
$submit_button=":: Enviar ::";
$date_user="Data: ";
$font_color="Cor da Fonte";

$font_color_value[0]="black";
$font_color_value[1]="white";
$font_color_value[2]="red";
$font_color_value[3]="blue";
$font_color_value[4]="yellow";
$font_color_value[5]="silver";
$font_color_value[6]="aqua";

$font_color_name[0]="Preta";
$font_color_name[1]="Branca";
$font_color_name[2]="Vermelha";
$font_color_name[3]="Azul";
$font_color_name[4]="Amarela";
$font_color_name[5]="Cinza";
$font_color_name[6]="Ciano";


$back_color="Cor do Fundo";

$back_color_value[0]="white";
$back_color_value[1]="black";
$back_color_value[2]="red";
$back_color_value[3]="blue";
$back_color_value[4]="yellow";
$back_color_value[5]="silver";
$back_color_value[6]="aqua";

$back_color_name[0]="Branco";
$back_color_name[1]="Preto";
$back_color_name[2]="Vermelho";
$back_color_name[3]="Azul";
$back_color_name[4]="Amarelo";
$back_color_name[5]="Cinza";
$back_color_name[6]="Ciano";

$font_face="Fonte";
$font_size="Tamanho";
$priority="Prioridade";
$priority_low="Baixa";
$priority_normal="M�dia";
$priority_hight="Alta";
$msg_error="Erro ao tentar enviar email";
$language_string="Portugu�s-Brasileiro";
$charset="iso-8859-1";
?>
