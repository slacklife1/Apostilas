<?
if (!$lang){
require("lang/br.php");
}
else{
$lang_file="lang/$lang.php";
require($lang_file);
}
$headers .="MIME-Version: 1.0 \n";
$headers .="From:$sender \n";
$headers .="X-Mailer: WEbMailer \n";
$headers .="X-Priority:$prio  \n";
$headers .="Content-Type: text/html; charset=$charset \n";
$date=date("d/m/Y");
$message_new="<html><head>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=$charset\">
</head>
<body bgcolor=$bgcolor>

<font face=Verdana size=1><b><font face=Verdana size=1>$date_user</b>:$date<br></font>
<font face=Verdana size=1><b><font face=Verdana size=1>$name_user</b>:$sender<br></font>
<font face=Verdana size=1><b><font face=Verdana size=1>$subject_user</b>:$subject<br> </font>
<p><font color=$fontcolor size=$fontsize face=$fontface>$message</font></p>";

 $status= mail($receiver,$subject,$message_new,$headers);
    if ($status==1){
      echo"<META HTTP-EQUIV=\"Refresh\" CONTENT=\"0;URL=index.php?lang=$lang\">";
       }
    else{
    echo"<font face=Verdana size=1>".$msg_error."</font>";
    echo"<META HTTP-EQUIV=\"Refresh\" CONTENT=\"2;URL=index.php\">";

       }
?>
