<? 

// Este script foi criado por M�rcio Rocco
// N�o retire meus cr�ditos, voc� n�o gostaria que tirassem os seus !!!

$host = getHostByAddr($REMOTE_ADDR);
    $headers = "Content-Type: text/html; charset=iso-8859-1\n"; 
    $headers.="From: $mail\n"; 
    mail("$destino", "$nome te mandou uma mensagem", "<body> <font color=\"blue\"><b> $nome </b></font> te mandou a seguinte mensagem:<br><br><b>$mensagem <b><br><br><font color=\"red\"><b>IP: $REMOTE_ADDR <BR>Provedor: $host </b></font><br><br><font color=\"blue\"><b><a href=\"mailto:marciorocco@terra.com.br\">M�rcio Rocco</a></b></font> ", "$headers"); 
    header("Location:resposta.htm");
?> 