<? 
################################################################## 
##                    re-Autor Vipmaster                        ## 
##                email vipmaster@ewdesign.com.br               ## 
##  Copyright VIPMASTER, todos os direitos reservados ao autor. ## 
################################################################## 
?>
<HTML><BODY BGCOLOR=FFFFFF> 
    <?php 
      $to = 'seu-email@seusite.com.br'; 
      $from = 'seu-email-resposta@seusite.com.br'; 
       
        //Verifique se n�s tivermos algo afixados pelo formul�rio. 
        if (isset($HTTP_POST_VARS)){ 
            //Comece com um body vazio para a mensagem do e-mail
            $body = ''; 
            //Itere com todas as vari�veis afixadas, e adicione-as ao body de mensagem. 
            while (list($key, $value) = each($HTTP_POST_VARS)){ 
                $body .= $key . ' = ' . $value . "\r\n"; 
            } 
            //Configuracao do enviar e resposta 
            $headers = "From: $from\r\n"; 
            $headers .= "Reply-To: $from\r\n"; 
            //Envie a mensagem para fora.
            //Requer o ajuste do trajeto do sendmail de php3.ini como por instru��es
            $success = mail($to, "Posted " . date("m/d/Y"), $body, $headers); 
            //Verifique sempre os c�digos do retorno das fun��es.
            if ($success){ 
                echo "<B><CENTER>Obrigado para sua entrada</CENTER></B>\n"; 
            } 
            else{ 
                echo "<CENTER><B>Erro Interno</B>:  Sua entrada � negada.<BR>Contato $from</CENTER>\n"; 
            } 
        } 
    ?> 
    <FORM ACTION=formmail.php METHOD=POST> 
        <INPUT NAME=exemplo><BR> 
        
  <INPUT TYPE=SUBMIT value="Enviar"> 
    </FORM> 
</BODY></HTML>