<html>
<head>
       <title>LK Mail</title>
</head>
<body>
<?php
############################################################
#                  SCRIPT DESENVOLVIDO POR                 #
#             NOME = Luiz J. Pires da Silva Jr.            #
#                     NICK = Kandrus                       #
#                     ICQ = 145696926                      #
#             E-MAIL = aluzdeavalon@bol.com.br             #
#               SITE = www.aluzdeavalon.cjb.net            #
# ESTE SCRIPT � FREE DESDE QUE SEJA MANTIDO ESTE CABE�ALHO #
############################################################
$site = ""; #nome do site
$url_site = ""; #Endere�o do seu site
$email_site = ""; #e-mail do site
#############################
# N�o mexa nestas variaveis #
#############################
$html = "Content-Type: text/html; charset=iso-8859-1\n";
$html.="From: Origem\n";
####################################
# $mem = Mensagem de agradecimento #
####################################
$men = "<div align=center><br>
  <table width=100% border=0>
    <tr>
      <td>
        <div align=center><font color=#999999><b><font size=2>OBRIGADO PELA
          SUA MENSAGEM!!!!</font></b></font></div>
      </td>
    </tr>
  </table>
  <table width=100% border=0>
    <tr>
      <td>
        <div align=center>
          <p>Caso sua mensagem n&atilde;o seja respondida dentro de 3 dias entre
            em contato via e-mail <a href=mailto:$email_site>clicando aqui</a>.</p>
          <p>Atenciosamente: Equipe $site<br>
            <a href=$url_site>$site</a> <br>
          </p>
        </div>
      </td>
    </tr>
  </table>
</div>";
if (!(ereg ("^.[a-zA-Z0-9]+@.+\\..+$", $email)))
print "<div align=center>
  <table width=500 border=0 bgcolor=#0099CC>
    <tr>
      <td>
        <div align=center><b><font color=#000000>E-mail inv�lido!!!</font></b></div>
      </td>
    </tr>
  </table>
  <a href=javascript:window.history.go(-1) target=_self><b><font color=#0066CC>VOLTAR</font></b></a>
</div>";
else
     if ($nome == "" || $assunto == "" || $mensagem == "")
    echo "campos em bramco";
     else
     echo "E-mail enviado com sucesso";
     mail($email_site, $assunto, "<div align=center>
  <table width=100% border=0>
    <tr>
      <td>
        <div align=center><b><font color=#999999>Mensagem:</font></b></div>
      </td>
    </tr>
    <tr>
      <td>
        <div align=left>Nome: $nome</div>
      </td>
    </tr>
    <tr>
      <td>
        <div align=left>E-mail: $email</div>
      </td>
    </tr>
    <tr>
      <td>
        <div align=left>Mensagem: $mensagem</div>
      </td>
    </tr>
  </table>
</div>", $html);
mail($email, $assunto, $men, $html);
?>
</body>
</html>
