<?
include "config.php";
if ( ($username == $useradmin) && ($password == $passadmin)) {
	setcookie("UserAdmin","$useradmin",time()+1800);
	setcookie("PassAdmin","$passadmin",time()+1800);
	echo "<script>setTimeout(\"window.location='$default_add=admin'\",100)</script>";
}
else {
	include "header.inc.php";
	echo "<tr><td colspan=\"2\" class=\"fontalert\"><b>Se voc� n�o � o administrador deste site, v� para outra sess�o! Obrigado!</td></tr>";
	echo "<script>setTimeout(\"history.go(-1)\",3000)</script>";
	include "footer.inc.php";
}

?>
