<?
include "header.inc.php";
if ( ($UserAdmin != $useradmin) || ($PassAdmin != $passadmin)):
?>
	  <tr>
		<td colspan="2" class="fontalert"><b>Se voc� n�o � o administrador deste site, v� para outra sess�o! Obrigado!</td>
	  </tr>
<?
      echo "<script>setTimeout(\"window.location='$default_add=admin'\",3000)</script>";
else:
?>

	<?
	if($send!="okay"):
	?>
<form method=post>
  <input type="hidden" name="send" value="okay">
  <tr> 
    <td class="font" width="15%">Assunto: </td><td class="font" width="85%"><input type="text" size="65" name="subject" class="fields"></td>
    </td>
  </tr>
  <tr> 
    <td colspan="2" class="font">Conte�do:</td>
    </td>
  </tr>
  <tr> 
    <td colspan="2" class="font"><textarea cols="90" rows="50" name="message" wrap="physical" style="border:1px solid #7C8184; font-size: 8pt; font-family: Verdana" size="50"></textarea></td>
    </td>
  </tr>
  <tr> 
    <td colspan="2" class="font"><input type="submit" value="Enviar" class="buttons"> <input type="reset" value="Limpar" class="buttons"></td>
    </td>
  </tr>
</form>
	<?
	else:
		if(empty($subject) || empty($message)):
		?>
  <tr> 
    <td class="fontalert"><b>Por favor entre o assunto e a mensagem!</b></td>
    </td>
  </tr>
  <script language="JavaScript">setTimeout("history.go(-1)",3000)</script>
		<?

		else:

			$subject = str_replace("\\","",$subject);
			$message = str_replace("\\","",$message);

			$openfile = file("$default_dir/newsletter.db.php");			
			$total = count($openfile);

			$emailto = true;
			$emailaddhost= "$default_emailhost";
			$hostname = "$default_hostname";

			$idvolfile = "$default_dir/idvol.txt";

			$idvol = file($idvolfile);
			$idvol = $idvol[0]+1;

			$openidvolfile = fopen($idvolfile,"w");
			fwrite($openidvolfile, $idvol);
			fclose($openidvolfile);
			
			if ($emailto == true):

			for ($i=0; $i<$total; $i++):
				list($UNEMPOWERED,$ID,$EMAIL,$DATE) = explode('|',chop($openfile[$i]));
			
				$content = $emailsend_template;
                                $headers  = "MIME-Version: 1.0\r\n";
                                $headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
                                $headers .= "From: ".$hostname." <".$emailaddhost.">";

				$template = mail($EMAIL, $subjectsend_template, $content, $headers);

			endfor;

			endif;
			?>
  <tr> 
    <td class="fontalert"><b>Enviado para todos os cadastrados!</b></td>
    </td>
  </tr>
  <script language="JavaScript">setTimeout("window.location='<?echo $default_add?>=admin'",3000)</script>
			<?
		endif;
	endif;
	?>

<?

endif;
include "footer.inc.php";
?>

