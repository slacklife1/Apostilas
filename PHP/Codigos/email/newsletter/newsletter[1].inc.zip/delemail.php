<?
include "header.inc.php";
if ( ($UserAdmin != $useradmin) || ($PassAdmin != $passadmin)):
?>
	  <tr>
		<td colspan="2" class="fontalert"><b>Se voc� n�o � administrador deste site, por favor v� para outra sess�o! Obrigado!</td>
	  </tr>
<?
      echo "<script>setTimeout(\"window.location='$default_add=admin'\",3000)</script>";
else:

	if(isset($id)):

		if (isset($id)):

			$openfile = file("$default_dir/newsletter.db.php");

			$fd = fopen("$default_dir/newsletter.db.php","w");

			for ($i=0; $i<count($openfile); $i++):
				list($UNEMPOWERED,$ID,$EMAIL,$DATE) = explode('|',$openfile[$i]);
				
				if ($ID!=$id) {
					fputs($fd,$openfile[$i]);
				}

			endfor;
			fclose($fd);
		endif;
		?>
  <tr> 
    <td class="fontalert"><b>Newsletter apagada n�mero <?echo $id?></b></td>
    </td>
  </tr>
  <script language="JavaScript">setTimeout("window.location='<?echo $default_add?>=admin'",3000)</script>
		<?
	endif;
endif;

include "footer.inc.php";
?>
