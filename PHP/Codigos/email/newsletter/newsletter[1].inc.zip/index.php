<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title> Newsletter Brasildata </title>

<script language="JavaScript">
<!--
function adminlogfields() {
   // Begin check user and pass field.
   var useradmincheck = new String(document.tknladmin.username.value);
   var passadmincheck = new String(document.tknladmin.password.value);
   
   if (  (useradmincheck.length > 0) && (passadmincheck.length > 0) ) {
	  document.tknladmin.submit();
	  return true;
   }
   else {
	  alert('Por favor, entre seu nome e senha!!');
	  return false;
   }

}

function forgotfields() {
   // Begin check user and email field.
   var useradmincheck = new String(document.forgotadmin.username.value);
   var emailadmincheck = new String(document.forgotadmin.email.value);
   var validemail = /^[_\.0-9a-z-]+@([0-9a-z][0-9a-z-]+\.)+[a-z]{2,4}$/;

   if (!validemail.test(document.forgotadmin.email.value)) {
      alert('Entre um email v�lido.');
	  return;
   }
   
   if (  (useradmincheck.length > 0) && (emailadmincheck.length > 0) ) {
	  document.forgotadmin.submit();
	  return true;
   }
   else {
	  alert('Por favor, entre seu nome e senha!!');
	  return false;
   }

}

function DelEmail(id) {
  cf = confirm("Voc� tem certeza que deseja apagar o email ("+id+")?");
  if (cf) {
    document.location = "delemail.php?id="+id+"";
  }
}
//-->
</script>
</head>

<body bgcolor=ffffff>
<?
include "newsletter.inc.php";
?>
</body>
</html>
