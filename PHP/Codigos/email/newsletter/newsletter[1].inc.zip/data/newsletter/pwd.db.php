<?die ('Access unempowered')?>|admin|101010|
