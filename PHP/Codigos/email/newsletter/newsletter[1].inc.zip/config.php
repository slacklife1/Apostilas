<?
// vers�o
$version = "vers�o 1.5a";

$default_add = "index.php?action";
// Configura o email principal. Quando algu�m se cadastrar uma mensagem ser� enviada para este email
$default_hostname = "Brasildata";
$default_emailhost = "maciel@brasildata.net";
$default_website = "http://www.brasildata.net";
// local onde fica o banco de dados
$default_dir = "data/newsletter";

// ajustar data para o newsletter
$date = date("d/m/Y");

// Quantidade de dados que ser�o salvos para o banco de dados
$data_amount = "400";


include "pwd.php";

// Enviar email para o visitando quando o cadastro � feito
// true: envia; false: n�o envia
$emailto = true;
$emailhost = true ;

// Email template
$emailhost_template = "
$default_hostname
$default_website
---------------------------------------------------------------------

Prezado(a) $default_hostname,

$date

Voc� tem um email em brasildata.net

Email: $email

---
Mauricio Maciel,
$default_hostname
";

$subjecthost_template = "Novidades sobre Brasildata $email";

$emailto_template = "
$default_hostname
$default_website
---------------------------------------------------------------------

Prezado(a) $email,

$date

Obrigado pelo seu cadastro no nosso newsletter!

T�o logo tenhamos alguma atualiza��o no site, voc� ser� notificado.

At� breve !
---
Mauricio Maciel,
$default_hostname
";

$subjectto_template = "Obrigado pelo seu cadastro no nosso newsletter!";

//Enviar a todos
$openfile = "$default_dir/idvol.txt";
$fp = fopen($openfile,"r");
$getidvol = fread($fp, filesize($openfile));
fclose($fp);

$emailsend_template = "
$default_hostname
$default_website
---------------------------------------------------------------------<br>
<br>
Newsletter volume $getidvol - $date<br>
<br>
Obrigado pela sua visita e cadastro no nosso newsletter!<br>
<br>
Assunto: $subject<br>
<br>
Novidades do site BRASILDATA.NET:<br>
---------------------------------------------------------------------<br>
$message<br>
---------------------------------------------------------------------<br>
Voce est� recebendo esta mensagem porque voc� est� cadastrado no site Brasildata.net e concordou em receber nosso newsletter, mas se voc� quiser tirar seu email da lista, por favor mande um email para vazio para cancelar@brasildata.net<br>
Obrigado!<br>
---<br>
Mauricio Maciel,<br>
$default_hostname
";

$subjectsend_template = "Novidades em $default_website";

//Email de senha perdida

$emailforgotpwd = "
$default_hostname
$default_website
--------------------------------------------------------------
			   
Dear $default_hostname,
 
 Parab�ns! Sua senha foi restaurada.
 username � $USERNAME
 senha � $PASSWORD
---
Mauricio Maciel,
$default_hostname
";

// Assunto do Email
$subject_forgot = "Sua senha aqui!";

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
?>
