<?
include "config.php";
setcookie("UserAdmin","$useradmin",time()-1800);
setcookie("PassAdmin","$passadmin",time()-1800);

echo "<script>setTimeout(\"window.location='$default_add=admin'\",100)</script>";
?>