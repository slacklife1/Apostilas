Newsletter
vers�o 1.5

Brasildata.net
maciel@brasildata.net
www.brasildata.net

�ndice
========
1. Introdu��o
2. Instala��o
3. Exemplo


1. Introdu��o
---------------
Este � um script em php que armazena dados em arquivos texto. Para inscrever usu�rios basta colocar o email, no link inscrever, e logo ser� enviado para ele uma mensagem de boas vindas, confirmando o cadastro.

Para cancelar a inscri��o basta clicar no link "Cancelar Inscri��o" e preencher com o email do usu�rio.

Se perder a senha de administra��o, entre no link "Admin" e preencha o forml�rio em baixo dos campos para login. Usu�rio � o nome do administrador (ex: admin) e o email � o que foi configurado no arquivo config.php ($default_emailhost)

2. Instala��o
---------------
Depois de copiar os arquivos para o servidor mude a permiss�o dos seguintes arquivos (chmod 666)

data/newsletter/newsletter.db.php
data/newsletter/pwd.db.php
data/newsletter/id.txt
data/newsletter/idvol.txt

Rodap�:     bottom.inc.php
Cabe�alho:  header.inc.php

Configura��es adcionais ver no arquivo : config.php


3. Exemplo
---------------
A senha e o login exemplo para administrar �: 
admin
101010
N�o esque�a de mudar !