<?
$opendata = file("$default_dir/pwd.db.php");
$countdata = count($opendata);

for ($i=0;$i<$countdata;$i++) {
	list($UNEMPOWERED,$USERNAME,$PASSWORD,$END) = explode('|',chop($opendata[$i]));
	$useradmin = $USERNAME;
	$passadmin = $PASSWORD;
}
?>