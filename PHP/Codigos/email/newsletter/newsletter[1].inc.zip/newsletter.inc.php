<?include "config.php";?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td class="font" colspan="2"><img src="imgs/title.gif" width="288" height="17" border=0 alt="Brasildata"></td>
  </tr>
  <tr> 
    <td class="font" colspan="2">&nbsp;</td>
    </td>
  </tr>
<?
if($action == "subscribe"):
?>
  <tr> 
    <td class="font">Inscrever | <a href="<?echo $default_add?>=unsubscribe">Cancelar Inscri��o</a> | <a href="<?echo $default_add?>=admin">Admin</a></td>
  </tr>
  <tr> 
    <td class="font"><hr size="2" color="black" noshade></td>
  </tr>
<?
	if ($agree!="okay"):
?>
  <tr> 
    <td class="font">* Por favor entre seu email, voc� receber� atualiza��es do site.</td>
  </tr>
  <tr> 
    <td class="font">&nbsp;</td>
    </td>
  </tr>
  <form method="post" name="Subscribe">
  <input type="hidden" name="agree" value="okay">
  <tr> 
    <td class="font">Seu email: <input type="text" size="30" name="email" class="fields"></td>
    </td>
  </tr>
  <tr> 
    <td class="font">&nbsp;</td>
    </td>
  </tr>
  <tr> 
    <td class="font"><input type="submit" value="Concordo" class="buttons"> <input type="button" value="Discordo" class="buttons" onClick="window.close()"></td>
    </td>
  </tr>
  </form>
<?
	else:

		if(isset($email)):

			$opendata = file("$default_dir/newsletter.db.php");
			$finish  = false;
			$author  = false;
			$found = false;
			$i = -1;
			while ((!$found) && ($i<count($opendata))):
				$i++;
				list($UNEMPOWERED,$ID,$EMAIL,$DATE) = explode('|',$opendata[$i]);
				$found = ($email==$EMAIL);
			endwhile;
		endif;

		if($email==$EMAIL):
		?>
  <tr> 
    <td class="fontalert"><b>Seu email j� foi cadastrado no nosso banco de dados. Por favor apague-o se quiser adicionar um novo email.</b></td>
    </td>
  </tr>
  <script language="JavaScript">setTimeout("history.go(-1)",5000)</script>
		<?
		elseif(empty($email)):
		?>
  <tr> 
    <td class="fontalert"><b>Por favor, entre um email v�lido!</b></td>
    </td>
  </tr>
  <script language="JavaScript">setTimeout("history.go(-1)",3000)</script>
		<?
		elseif(!eregi("^[_\.0-9a-z-]+@([0-9a-z][0-9a-z-]+\.)+[a-z]{2,4}$", $email)):
		?>
  <tr> 
    <td class="fontalert"><b>Seu endere�o de email � inv�lido.</b></td>
    </td>
  </tr>
  <script language="JavaScript">setTimeout("history.go(-1)",3000)</script>
		<?
		else:
			$emailaddhost= "$default_emailhost";
			$hostname = "$default_hostname";

			if ($emailto == true):
			$content = $emailto_template;
			$template = mail($email, $subjectto_template, $content, "From: ".$hostname." <".$emailaddhost.">");
			endif;

			if ($emailhost == true):
			$content = $emailhost_template;
			$template = mail($emailaddhost, $subjecthost_template, $content, "From: ".$email." <".$email.">");
			endif;

			$idfile = "$default_dir/id.txt";

			$id = file($idfile);
			$id = $id[0]+1;

			$openfile = fopen($idfile,"w");
			fwrite($openfile, $id);
			fclose($openfile);

			$savefile = "$default_dir/newsletter.db.php";

			if ( !file_exists($savefile) ) {
			$newfile = fopen($savefile,"w+");
			fclose($newfile);
			}

			$maxdata = $data_amount;

			$lines = file("$savefile");
			$add = "<?die ('Access unempowered')?>|$id|$email|$date";
			$openfile = fopen("$savefile","w");
			fwrite($openfile, "$add\n");
			for ($i = 0; $i < $maxdata; $i++){
			@fwrite($openfile, "$lines[$i]");
			}
			fclose($openfile);
			?>
  <tr> 
    <td class="fontalert"><b>Voc� foi cadastrado, por favor cheque seu email para confirmar !</b></td>
    </td>
  </tr>
  <script language="JavaScript">setTimeout("history.go(-1)",3000)</script>
			<?
		endif;
	endif;
elseif ($action == "unsubscribe"):
?>
  <tr> 
    <td class="font"><a href="<?echo $default_add?>=subscribe">Inscrever</a> | Cancelar inscri��o | <a href="<?echo $default_add?>=admin">Admin</a></td>
  </tr>
  <tr> 
    <td class="font"><hr size="2" color="black" noshade></td>
  </tr>
	<?
	if ($delete != "okay"):
	?>
  <tr> 
    <td class="font">* Para apagar seu email do nosso banco de dados, por favor entre com ele abaixo (seu Email usado na inscri��o):</td>
  </tr>
  <tr> 
    <td class="font">&nbsp;</td>
    </td>
  </tr>
  <form method="post">
  <input type="hidden" name="delete" value="okay">
  <tr> 
    <td class="font">Seu email: <input type="text" size="30" name="email" class="fields"></td>
    </td>
  </tr>
  <tr> 
    <td class="font">&nbsp;</td>
    </td>
  </tr>
  <tr> 
    <td class="font"><input type="submit" value="Cancelar" class="buttons"></td>
    </td>
  </tr>
  </form>
	<?
	else:

		if(isset($email)):

			$opendata = file("$default_dir/newsletter.db.php");
			$finish  = false;
			$author  = false;
			$found = false;
			$i = -1;
			while ((!$found) && ($i<count($opendata))):
				$i++;
				list($UNEMPOWERED,$ID,$EMAIL,$DATE) = explode('|',$opendata[$i]);
				$found = ($email==$EMAIL);
			endwhile;
		endif;
	?>
		
		<?
		if(empty($email)):
		?>
  <tr> 
    <td class="fontalert"><b>Por favor, entre seu email!</b></td>
    </td>
  </tr>
  <script language="JavaScript">setTimeout("history.go(-1)",3000)</script>
		<?
		elseif(!eregi("^[_\.0-9a-z-]+@([0-9a-z][0-9a-z-]+\.)+[a-z]{2,4}$", $email)):
		?>
  <tr> 
    <td class="fontalert"><b>Seu email � inv�lido.</b></td>
    </td>
  </tr>
  <script language="JavaScript">setTimeout("history.go(-1)",3000)</script>
		<?
		elseif($email!=$EMAIL):
		?>
  <tr> 
    <td class="fontalert"><b>Seu email � difirente da sua inscri��o.</b></td>
    </td>
  </tr>
  <script language="JavaScript">setTimeout("history.go(-1)",3000)</script>
	<?
		else:

			if ( isset($email) ):


				$opendata = file("$default_dir/newsletter.db.php");

				$openfile = fopen("$default_dir/newsletter.db.php","w");

				for ($i=0; $i<count($opendata); $i++):
					list($UNEMPOWERED,$ID,$EMAIL,$DATE) = explode('|',$opendata[$i]);

					if ( $EMAIL!=$email ):
						fputs($openfile,$opendata[$i]);
					endif;

				endfor;
				fclose($openfile);
			endif;
			?>
  <tr> 
    <td class="fontalert"><b>Seu email foi apagado do nosso banco de dados, voc� n�o receber� mais atualiza��es do site.</b></td>
    </td>
  </tr>
  <script language="JavaScript">setTimeout("history.go(-1)",5000)</script>
			<?
		endif;
	endif;
	?>
<?
elseif ($action == "admin"):
?>
  <tr> 
    <td class="font" colspan="2"><a href="<?echo $default_add?>=subscribe">Inscrever</a> | <a href="<?echo $default_add?>=unsubscribe">Cancelar Inscri��o</a> | Admin</td>
  </tr>
  <tr> 
    <td class="font" colspan="2"><hr size="2" color="black" noshade></td>
  </tr>
  <?
  if ( ($UserAdmin != $useradmin) || ($PassAdmin != $passadmin)):
  ?>
<form method=post action="login.php" name="tknladmin">
  <tr> 
    <td colspan="2" class="font">* Administrador, por favor entre seu login e senha abaixo:</td>
    </td>
  </tr>
  <tr> 
    <td colspan="2" class="font">&nbsp;</td>
    </td>
  </tr>
  <tr> 
    <td class="font" width="20%">Login: </td><td class="font" width="80%"><input type="text" size="30" name="username" class="fields"></td>
    </td>
  </tr>
  <tr> 
    <td class="font" width="20%">Senha: </td><td class="font" width="80%"><input type="password" size="30" name="password" class="fields"></td>
    </td>
  </tr>
  <tr> 
    <td colspan="2" class="font"><input type="button" value="Login" class="buttons" onClick="adminlogfields()"> <input type="reset" value="Limpar" class="buttons"></td>
    </td>
  </tr>
</form>
<tr> 
  <td colspan="2" class="font">&nbsp;</td>
</tr>
<form method="post" action="forgotpwd.php" name="forgotadmin">
<tr> 
  <td width="30%" class="font">Usu�rio:</td>
  <td width="70%" class="font"> 
	<input type="text" name="username" size="30" class="fields">
  </td>
</tr>
<tr> 
  <td width="30%" class="font">Email: [Host]</td>
  <td width="70%" class="font"> 
	<input type="text" name="email" size="30" class="fields">
  </td>
</tr>
<tr> 
  <td colspan="2" class="font"> 
	<input type="button" value="Enviar" class="buttons" onClick="forgotfields()">
	<input type="reset" value="Limpar" class="buttons">
  </td>
</tr>
<tr> 
  <td colspan="2" class="font">&nbsp;</td>
</tr>
</form>
	<?
	else:
		$openfile = file("$default_dir/newsletter.db.php");			
		$total = count($openfile);
		$max = "50";

		if (! $page > 0):
			$page = 1;
		endif;

		if (intval($total/$max)+1 < $page):
			$page=1;
		endif;

		if ($total >= $page*$max):
			$lastrec = $page*$max;
		else:
			$lastrec = (($page-1)*$max) + ($total % $max);
		endif;

		echo "
   </tr>
    </td colspan=\"2\" class=\"font\">
      <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		";

		echo "<tr><td colspan=\"3\" class=\"font\">| <a href=\"logout.php\">Admin logout</a> | <a href=\"sendmsg.php\">Enviar mensagem � todos</a> | <a href=\"changeuserpass.php\">Mudar login e senha</a></td></tr>\n";

		echo "<tr><td colspan=\"3\" class=\"font\">&nbsp;</td></td></tr>";

		echo "<tr><td bgcolor=\"#7C8184\" class=\"fontwhite\"><b>ID</b></td><td bgcolor=\"#7C8184\" class=\"fontwhite\"><b>Email</b></td><td bgcolor=\"#7C8184\" class=\"fontwhite\"><b>Data de Inscri��o</b></td></tr>\n";

		for ($i=($page-1)*$max; $i<$lastrec; $i++):
			list($UNEMPOWERED,$ID,$EMAIL,$DATE) = explode('|',chop($openfile[$i]));

			if ($i == "0" || $i == "1" || $i == "2" || $i == "3"):
				echo "<tr><td class=\"font\"><img src=\"imgs/newsletterimgs/new.gif\" width=\"19\" height=\"9\" border=0 alt=\"Novo\"><b>Email $ID</b></td><td class=\"font\">$EMAIL <a href=\"javascript:DelEmail('$ID')\">[Apagar]</a></td><td class=\"font\">$DATE</td></tr>";
			else:
				echo "<tr><td class=\"font\"><b>Email $ID</b></td><td class=\"font\">$EMAIL<a href=\"javascript:DelEmail('$ID')\">[Apagar]</a></td><td class=\"font\">$DATE</td></tr>";
			endif;
		endfor;

		echo "<tr><td class=\"font\" colspan=\"2\">&nbsp;</td></tr>";

		echo "<tr><td class=\"font\" colspan=\"2\">";

		echo "<font class=\"font\"><b>P�gina: </b> ";
		for ($i=1; $i<=intval($total/$max)+1; $i++):
			if ($i != $page):
				echo "<a href=\"$default_add=admin&page=$i\">$i</a>";
			else:
				echo "<b>$i</b>";
			endif;
			echo " ";
		endfor;
		echo "<br>\n";
		echo "<b>No Email: </b> ".(($page-1)*$max+1)." de $lastrec<br>\n";
		echo "<b>Total: </b> $total\n";
		echo "</font><br><br>\n";
		echo "</td></tr>";

	endif;

		echo "
	  </table>
    </td>
  </tr>
		";
	?>
<?
else:
?>
  <tr>
    <td class="font"><a href="<?echo $default_add?>=subscribe">Inscrever</a> | <a href="<?echo $default_add?>=unsubscribe">Cancelar Inscri��o</a> | <a href="<?echo $default_add?>=admin">Admin</a></td>
  </tr>
<?
endif
?>
  <tr>
    <td class="font">&nbsp;</td>
    </td>
  </tr>
</table>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
<?
include "bottom.inc.php";
?>
</table>

