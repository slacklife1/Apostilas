<?include "config.php";?>
<html><head>
<meta http-equiv=content-type content="text/html;charset=ISO-8859-1">
<TITLE>Bem-vindo a Brasil:Data --web design</TITLE>
</head><body bgcolor=ffffff >

<table bgcolor="white" width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    
  <td class="font" colspan="2">&nbsp;</td>
  </tr>
  <tr> 
    <td class="font" colspan="2">&nbsp;</td>
    </td>
  </tr>
  <tr> 
    <td class="font" colspan="2"><a href="<?echo $default_add?>=subscribe">Inscrever</a> | <a href="<?echo $default_add?>=unsubscribe">Cancelar inscri��o</a> | <a href="<?echo $default_add?>=admin">Admin</a></td>
  </tr>
  <tr> 
    <td class="font" colspan="2"><hr size="2" color="black" noshade></td>
  </tr>
