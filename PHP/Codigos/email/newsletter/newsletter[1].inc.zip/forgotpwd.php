<?
include "config.php";
include "header.inc.php";

if ($email != $default_emailhost) {
	echo "<tr><td colspan=\"2\" class=\"fontalert\"><b>Seu email n�o � verdadeiro!</b></td></tr>";
	echo "<script>setTimeout(\"window.location='$default_add=admin'\",3000)</script>";
}
else {

	$opendata = file("$default_dir/pwd.db.php");
	$found = false;
	$i = -1;
	while ((!$found) && ($i<count($opendata))) {
		$i++;
		list($UNEMPOWERED,$USERNAME,$PASSWORD,$END) = explode('|',$opendata[$i]);

		$found = ( $username==$USERNAME  );
	}
	if ($username!=$USERNAME) {
		echo "<tr><td colspan=\"2\" class=\"fontalert\"><b>Seu email n�o � verdadeiro!</b></td></tr>";
		echo "<script>setTimeout(\"window.location='$default_add=admin'\",3000)</script>";
	}
	else {

		$emailaddhost= "$default_emailhost";
		$hostname = "$default_hostname";

		$emailpwd = true;

		if ($emailpwd == true) {
		   $content = $emailforgotpwd ;
		   $template = mail($emailaddhost, $subject_forgot, $content, "De: ".$hostname." <".$emailaddhost.">");

			echo "<tr><td colspan=\"2\" class=\"font\"><b>Sua senha foi enviada para $emailaddhost.</b></td></tr>";
			echo "<script>setTimeout(\"window.location='$default_add=admin'\",3000)</script>";
		}
	}
}

include "footer.inc.php";
?>
