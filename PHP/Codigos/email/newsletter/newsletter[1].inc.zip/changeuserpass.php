<?
include "header.inc.php";
if ( ($UserAdmin != $useradmin) || ($PassAdmin != $passadmin)) {

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

?>
	  <tr>
		<td colspan="2" class="fontalert"><b>Se voc� n�o � o administrador deste site, por favor v� para outra sess�o! Obrigado!</b></td>
	  </tr>
<?
      echo "<script>setTimeout(\"window.location='$default_add=admin'\",3000)</script>";
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
}
else {

if($change != "executed") {
?>
	<form method="post">
	<input type="hidden" name="change" value="executed">
	  <tr>
		<td width="30%" class="font">Usu�rio:</td><td width="70%" class="font"><input type="text" name="username" class="fields"></td>
	  </tr>
	  <tr>
		<td width="30%" class="font">Nova senha:</td><td width="70%" class="font"><input type="password" name="newpass1" class="fields"></td>
	  </tr>
	  <tr>
		<td width="30%" class="font">Nova senha(Confirma):</td><td width="70%" class="font"><input type="password" name="newpass2" class="fields"></td>
	  </tr>
	  <tr>
		<td width="100%" colspan="2" class="font"><input type="submit" value="Mudar" class="buttons"> <input type="reset" value="Limpar" class="buttons"></td>
	  </tr>
	</form>
<?
}
else {
	if (empty($newpass1) || empty($newpass2)) {
?>
	  <tr>
		<td colspan="2" class="fontalert"><b>Preecha todos os campos.</td>
	  </tr>	
<?
      echo "<script>setTimeout(\"window.location='changepwd.php'\",3000)</script>";
	}
	elseif ($newpass1 != $newpass2) {
?>
	  <tr>
		<td colspan="2" class="fontalert"><b>As duas senhas est�o diferentes!</td>
	  </tr>	
<?
      echo "<script>setTimeout(\"window.location='changepwd.php'\",3000)</script>";
	}
	else {

		$opendata = file("$default_dir/pwd.db.php");
		$found = false;
		$i = -1;
		while ((!$found) && ($i<count($opendata))) {
			$i++;
			list($UNEMPOWERED,$USERNAME,$PASSWORD,$END) = explode('|',$opendata[$i]);
			$found = ( ($UserAdmin==$USERNAME) && ($PassAdmin==$PASSWORD) );
		}

		if ($username!="") $USERNAME = $username;
		if ($newpass1!="") $PASSWORD = $newpass1;

		$opendata[$i] = implode('|',array($UNEMPOWERED,$USERNAME,$PASSWORD,$END));
		$openfile = fopen("$default_dir/pwd.db.php","w");

		for ($i = 0; $i < count($opendata); $i++){
		   if ($ID==$IDGB) {
			  @fwrite($openfile,chop($opendata[$i])."\n");
		   }
		}
		fclose($openfile);
		echo "<tr><td colspan=\"2\" class=\"font\"><b>Sua senha (ou login) foi modificada.</b></td></tr>";
		echo "<script>setTimeout(\"window.location='$default_add=admin'\",3000)</script>";
	}
}


}
include "footer.inc.php";
?>
