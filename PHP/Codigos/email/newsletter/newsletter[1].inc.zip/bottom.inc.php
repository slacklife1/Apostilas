  <tr>
    
  <td align="center" class="font">       

          <font face="Verdana,Arial,Geneva,Helvetica" size=2 color=000000><span class=copyright>Copyright

          � 1999 / 2002 - <a href="http://www.brasildata.net" target="_blank">Brasil:Data - Web Design</a> � - Todos os direitos reservados</span></font></p>
</td>
</tr>
