<html>
<head>
<title>Newsletter ..::</title>
<META NAME="Leandro Maniezo" CONTENT="Sistema de envio Newsletter" RDX_TYPE="TITLE">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.caixas {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px; font-weight: normal; border: 1px #666666 groove; background-color: #FFFFCC;
     scrollbar-3d-light-color : #ffffff;
	   scrollbar-arrow-color : #000000;
	   scrollbar-base-color : #000000;
	   scrollbar-dark-shadow-color : #000000;
	   scrollbar-face-color : #c0c0c0;
	   scrollbar-highlight-color : #ffffff;
	   scrollbar-shadow-color : #00000c;
		 }
.caixa {scrollbar-3d-light-color : #ffffff;
	   scrollbar-arrow-color : #ffffff;
	   scrollbar-base-color : #ffffff;
	   scrollbar-dark-shadow-color : #ffffff;
	   scrollbar-face-color : #ffffff;
	   scrollbar-highlight-color : #ffffff;
	   scrollbar-shadow-color : #c0c0c0;
		 }
-->
</style>
</head>

<body bgcolor="#FFFFFF" text="#000000" class="caixa">
<form name="form1" method="post" action="envia.php">
    <b><u>Sistema de envio Newsletter</u></b><br><br>
		Nome remetente: <input type="text" name="nome" size="100" class="caixas"><br>
		Email remetente: <input type="text" name="mailre" size="101" class="caixas"><br><br>
		Email teste: <input type="text" name="mail" size="107" class="caixas"><br>
		Assunto: <input type="text" name="ass" size="110" class="caixas">
    <br><br><br><div align="left">
    <u>Cole seu html:</u><br><textarea name="texto" cols="120" rows="28" class="caixas"></textarea>
  </div>
	<input type="submit" value="Enviar">
</form>
</body>
</html>
