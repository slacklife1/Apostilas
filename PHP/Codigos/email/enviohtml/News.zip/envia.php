<?
$texto=str_replace('"','',$texto);
$texto=str_replace("'","",$texto);
$texto=str_replace('\\','',$texto);

if(!isset($aut)){
  
	$cabecalho= "Content-Type: text/html; charset=iso-8859-1";
	mail("$mail","$ass","$texto","$cabecalho\nFrom:$nome <$mailre>");
	
	echo "<br><center>Certifique-se que o e-mail teste enviado para \"$mail\" esta ok:</center><br><br>";
	echo "<table align=\"center\" width=\"80%\"><tr><td><a href=\"envia.php?mailre=$mailre&nome=$nome&mail=$mail&ass=$ass&aut=\"><b>OK</b> esta tudo certo e desejo enviar a news para toda lista</a></td><td><a href=\"news.php\">O e-mail n�o esta ok desejo refaze-lo</a></td></tr></table>"; 
	
	$fp = fopen("html.txt", "r+");
  fwrite($fp, "$texto");
	fclose ($fp);
	}else{
	
	$cabecalho= "Content-Type: text/html; charset=iso-8859-1";
  $fd = fopen ("html.txt", "r");
  $texto = fread ($fd, filesize ("html.txt"));
  fclose ($fd);
	
	$fp = fopen("log.txt", "w");
  fwrite($fp, "");
  fclose ($fp);
	
$handle = fopen ("emails_bd.txt", "r+");
while (!feof ($handle)) {
    
		$buffer = fgets($handle, 4096);
    mail("$buffer","$ass","$texto","$cabecalho\nFrom:$nome <$mailre>");
		
		$fp = fopen("log.txt", "a");
    fwrite($fp, "$buffer$somecontent");
		$cont++;
		if($cont==100){
		echo $cont." e-mail enviados...<br>";
		}
}
fclose ($handle);
fclose ($fp);

$fp = fopen("html.txt", "w");
fwrite($fp, "");
fclose ($fp);
  echo "Newsletter enviado com sucesso para $cont e-mails cadastrados, todos emails enviados est�o no arquivo log.txt";
	}
?>