<?
###########################################
#          Recomendar Site v2.0			  #
#           Por: Fabio Fedelix            #
#    email: fabiofedelix@yahoo.com.br     #
#   ao som de: Dope - Now Or Never =P     #
###########################################

$email_admin = "fabiofedelix@yahoo.com.br"; //email do admin do site
$nome_site = "Fabio Fedelix"; //nome do site ou admin do site

$assunto_recomendar = "$nome_recomende est� lhe indicando nosso site."; //assunto do email
$msg_recomendar = "<font face=\"verdana\" size=\"2\">Ol� $nome_a_recomende,<br><br>Seu amigo(a) <b>$nome_recomende</b> est� lhe recomendando o nosso site
que � dedicado totalmente ao PHP, com scripts prontos, tutoriais, downloads, servi�os gr�tis e muito mais!<br><br>Confira!<br><br>Obrigado,<br>Equipe <a href=\"http://www.reachandtouch.com\">Reach And Touch</a>.";
?>
