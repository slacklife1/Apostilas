<?
###########################################
#          Recomendar Site v2.0			  #
#           Por: Fabio Fedelix            #
#    email: fabiofedelix@yahoo.com.br     #
#   ao som de: Dope - Now Or Never =P     #
###########################################

$recomende = "<div align=\"center\"><br>
  <form method=\"post\" action=\"?act=recomendar\">
    <table width=\"100\" border=\"0\" cellspacing=\"0\">
      <tr>
        <td>Seu nome:</td>
      </tr>
      <tr>
        <td><input name=\"nome_recomende\" type=\"text\" id=\"nome_recomende\" size=\"18\"></td>
      </tr>
      <tr>
        <td>Seu email:</td>
      </tr>
      <tr>
        <td><input name=\"email_recomende\" type=\"text\" id=\"email_recomende\" size=\"18\"></td>
      </tr>
      <tr>
        <td>Nome do amigo(a):</td>
      </tr>
      <tr>
        <td><input name=\"nome_a_recomende\" type=\"text\" id=\"nome_a_recomende\" size=\"18\"></td>
      </tr>
      <tr>
        <td>Email do amigo(a):</td>
      </tr>
      <tr>
        <td><input name=\"email_a_recomende\" type=\"text\" id=\"email_a_recomende\" size=\"18\"></td>
      </tr>
      <tr>
        <td height=\"21\">
<div align=\"center\"><br>
            <input type=\"submit\" name=\"Submit\" value=\"Enviar\">&nbsp;
            <input type=\"reset\" name=\"limpar\" value=\"Limpar\">
          </div></td>
      </tr>
    </table>
  </form>
</div>";

if ($act == 'recomendar' && !empty($nome_recomende) && !empty($email_recomende) && !empty($nome_a_recomende) && !empty($email_a_recomende)) {
include("config.php");
$header = "From: $nome_site <$email_admin>\nContent-type: text/html\n";
mail($email_a_recomende, $assunto_recomendar, $msg_recomendar, $header);
$recomende = "<br>Recomenda��o enviada com sucesso!<br>";
}
echo $recomende;
?>
