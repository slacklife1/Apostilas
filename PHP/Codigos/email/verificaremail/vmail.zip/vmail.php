<?
/*
��Function verifica_mail
��Developer: Ledson Carvalho (tchuck@csti.ufjf.br)
��Date : 23/09/2001
��Last Update: 23/09/2001
��Version: 0.1

  Testar se o dom�nio �  v�lido  e se
  existe   algo   antes   do     arroba.
  Retorna true se email v�lido ou  false
  se inv�lido.

*/
function verifica_mail($mail) {
    if (strpos ($mail, "@") == 0) { return false; }
    list($user,$domain)=split("@",$mail,2);
    if (checkdnsrr($domain,"MX")) {
         return true;
    } else {
         return false;
    }
}

?>