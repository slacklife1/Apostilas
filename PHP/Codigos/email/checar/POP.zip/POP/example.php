<?
 require("errors.inc.php");//File with error msgs so it can be easily trnaslated
 require("pop3.class.php");
 $MyPop3 = new Pop3();//creating object
 $MyPop3->server = "localhost";//set the server
 if ($MyPop3->pop3_connect("user_name","password")){ //try to open the mailbox
    $aux = $MyPop3->pop3_check();//is there any mail?
    if ($aux){ // worked well?
      echo("<p>Date.......: ".$aux->Date."</p>");
      echo("<p>Driver.....: ".$aux->Driver."</p>");
      echo("<p>Mailbox....: ".$aux->Mailbox."</p>");
      echo("<p>No of msgs.: ".$aux->Nmsgs."</p>");
      echo("<p>Recents....: ".$aux->Recent."<i> //Does not work on POP3 allways
      														return the number of msgs</i></p>");
    }else{
      echo($errormsgs[$MyPop3->error_num]);//if we had a trouble with check write it here
    }
 }else{
      echo($errormsgs[$MyPop3->error_num]);//if we had a trouble with conect
    }
?>