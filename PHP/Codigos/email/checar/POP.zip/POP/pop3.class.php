<?
  class Pop3 {
    var $error_msg = '';
    var $error_num =  0;
    var $server = '';
    var $port   = '110';
    var $connected = false;
    var $stream = '';

    function Pop3(){
       //Constructor
       $this->error_msg = '';
       $this->error_num =  0;
       $this->server = '';
       $this->port   = '110';
       $this->connected = false;
       $this->stream = false;
    }
    function pop3_connect($user,$pass){
      //try to connect return true on ok else return false
      //set the $this->stream to a conection to the pop mail-box
       if ($this->server == '') {
          $this->error_num = 1;//Server not set
          return false;
       }else{
          $this->stream = @imap_open ("{".$this->server.":".$this->port."/pop3}INBOX", $user , $pass);
          if (!$this->stream){
            $this->error_num = 2;//Impossible to connect
            return false;
          }else{
            $this->connected = true;
            return true;
          }
       }
    }
    function pop3_check(){
      //check for new email
      //return a object containing:
/*    ->Date      Return the date on the server
      ->Driver    *Unuseful* Return the type of protocol used to access the mail-box "POP"
      ->Mailbox   Return the name of the mailbox
      ->Nmsgs     Return the number of Msgs on the server
      ->Recent    *Unuseful* Return how many msgs are new(does not work on pop conections)*/
       if ($this->connected){
          return imap_check($this->stream);
       }else{
          $this->error_num = 3;//Not Connected
          return false;
       }
    }
  }
?>