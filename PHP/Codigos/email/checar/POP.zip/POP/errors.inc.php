<?
$errormsgs[0] = "";//dont change this it means no error
$errormsgs[1] = "Servidor n�o setado.";//server not set
$errormsgs[2] = "Impossivel conectar.";//impossible to connect
$errormsgs[3] = "N�o Conectado."; //not connected
?>