<?
include("./session_management.php");
if(!isset($folder) || !isset($ix)) die("Expected parameters");
echo($nocache);
echo($sess["currentbody"]);
?>
