----------------------------------------------------
OVERVIEW
----------------------------------------------------
UebiMiau is a web-based e-mail client written in PHP


----------------------------------------------------
DEVELOPERS/HELPS/LANGUAGE PACK
----------------------------------------------------
Core Developer: 
- Aldoir <aldoir@mail.com>

Languages:
- Portuguese: Aldoir <aldoir@mail.com>
- French: Christophe Buguet <christophe.buguet@wanadoo.fr>
- German: Jens Uehlecke <jens@e-nuff.de>
- English: Jens Uehlecke <jens@e-nuff.de>

----------------------------------------------------
FEATURES/REQUIREMENTS
----------------------------------------------------

* Working
----------------------------------------------------
- SMTP Compatible
- POP3 Compatible
- MIME Compatible
- Receive Attachments
- Send Attachments
- Folders/E-mail management support (Trash/Inbox/Sent/[Personal])
- Address book
- Language support
- Themes support
- Search in messages
- Personalized order messages
- Personal preferences
- Send HTML e-mails
- Quota Limit

* Planned
- Database support

* NOT Planned
----------------------------------------------------
- IMAP support
- PHP3 Port


* Dependences
----------------------------------------------------
--with-imap PHP module - NO        - Have own functions.
Sendmail/Qmail         - OPTIONAL  - Manage SMTP servers manually
Operational System OS  - NO        - Cross plataform
Database               - NO        - Manage data in hard disk
Client Cookies         - NO        - Manage session manually
Client JavaScript      - YES       - To make templates more easy
PHP                    - YES       - Obviously ;)



----------------------------------------------------
INSTALL
----------------------------------------------------
Unpack the package (.tar.gz or .zip file) into a directory within your web server.  
Open the config.php file in a text editor, all instructions are commented on this file

