<?php
//error_reporting(E_ALL);
include("email/htmlMimeMail.php");

$mail = new htmlMimeMail();
/* Setando o header */
$mail->setHeader('X-Mailer', 'HTML Mime mail class');
/* Setando o Subject */	
$mail->setSubject($mailsubject);
/* Setando o corpo do email */
$mail->setHtml($assinatura2);

/* Anexando arquivos */
if (!empty($img1) && $img1 != "none") {
    $attachment1 = $mail->getFile($img1);
	$mail->addAttachment($attachment1, $img1, "image/gif");
}
if (!empty($img2) && $img2 != "none") {
    $attachment2 = $mail->getFile($img2);
	$mail->addAttachment($attachment2, $img2, "image/gif");
}
if (!empty($img3) && $img3 != "none") {
    $attachment3 = $mail->getFile($img3);
	$mail->addAttachment($attachment3, $img3, "image/gif");
}


$fp = fopen("email.php", "r");
$mailaddr = fread($fp,filesize("email.php"));
fclose($fp);
$tmp = explode(",",$mailaddr);

for ($i = 0; $i < count($tmp); $i++) {
	$mail->setFrom($tmp[$i]);
	$result = $mail->send(array($tmp[$i]), 'smtp');
}

/* Destruindo o Objeto */
unset($mail);
echo  "E-mail enviado corretamente.";
?>

<script language="javascript">
<!--
function refresh() {
	window.location.href = 'mensagem.php';
}
setTimeout("refresh()",5000);
//-->
</script>