<HTML>
<HEAD>
   <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
   <META HTTP-EQUIV="Content-Language" CONTENT="pt-br">
   <META NAME="GENERATOR" CONTENT="Microsoft FrontPage 4.0">
   <META NAME="ProgId" CONTENT="FrontPage.Editor.Document">
   <META NAME="Microsoft Theme" CONTENT="strtedge 011, default">
   <META NAME="Microsoft Border" CONTENT="tl, default">
   <TITLE>Mensagem</TITLE>
   <STYLE TYPE="text/css">

  A:normal {color:#0033CC;}
  A:link   {color:#0033CC;text-decoration:none}
  A:visited{text-decoration: none}
  A:hover  {color:#990000;text-decoration:underline;}

</STYLE>
<script language='javascript'>
<!--
function validar() {
  document.personaliza_form.assinatura2.value = GetHtml();
  return true;
}
//-->
</script>
</HEAD>
<body bgColor=#FFFFF0><center>
<!--Inicio do composeForm-->
<center>
<div id="hiddenCompose" style="position: absolute; left: 3; top: -100; visibility: hidden; z-index: 3">
<form name="hiddencomposeForm">
<textarea name="hiddencomposeFormTextArea"><?print $assinatura?></textarea>
</form>
</div>
<!--Fim do composeForm-->


<h4> <font face="Arial, Helvetica" color="#000000"> <br>
  <center>SIMPLE SISTEMA DE LISTA DE E-MAIL<br></font></h4></center>
<hr>

<h5>

<table height="94" border=1 align="center" CELLPADDING=0 CELLSPACING=0 BGCOLOR=#0000aa>
  <form action="envia.php" method="POST" name="personaliza_form" onsubmit="return validar()" ENCTYPE="multipart/form-data">
  <input type="hidden" name="assinatura2">
    <tr bgcolor="#FFCC00"> 
      <td height="40"> <font face="Arial,Helvetica" color=#ffffff> 
        <p align="left"><strong><font color="#990000">Assunto: </font></strong></p>
        </font></td>
      <td height="40" align=center> <strong><font color="#990000" face="Arial,Helvetica"> 
        <input name="mailsubject" value="" SIZE="30">
        </font></strong></td>
    </tr>

	<tr bgcolor="#FFCC00"> 
      <td height="52"> <font face="Arial, Helvetica" color=#ffffff> 
        <p align="left"><strong><font color="#990000"> Texto: </font></strong></p>
        </font></td>
      <td height="200" align=center valing="top"> <strong><font color="#990000" face="Arial,Helvetica"> 
        <table width='100%' border='0' cellpadding=0 cellspacing=0>
          <tr>
             <td>
             <? include ("include/assinatura.php")?>
             </td>
          </tr>
      </table>
        </font></strong></td>
    </tr>

	<tr bgcolor="#FFCC00"> 
      <td valign='top'><font face="Arial, Helvetica" color=#ffffff> 
        <p align="left"><strong><font color="#990000"> Anexar Imagem: </font></strong></p>
        </font></td>
      <td align=center valing="top"> <strong><font color="#990000" face="Arial,Helvetica"> 
        <table width='100%' border='0' cellpadding=0 cellspacing=0>
          <tr>
             <td>
               <input type="file" class=form NAME="img1"  size=30 maxlength=60>
             </td>
          </tr>
          <tr>
             <td>
               <input type="file" class=form NAME="img2"  size=30 maxlength=60>
             </td>
          </tr>
          <tr>
             <td>
               <input type="file" class=form NAME="img3"  size=30 maxlength=60>
             </td>
          </tr>

      </table>
        </font></strong></td>
    </tr>
	<tr bgcolor="#FFCC00"> 
      <td height="52"> <p align="center">&nbsp;</td>
      <td height="52" align=center> <strong><font color="#990000"> 
        <INPUT type="submit" value="Enviar">
        <input type="reset" value="Limpar">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </font> </strong></td>
    </tr>
  </form>
</table>
</BODY>
</HTML>
                                                                                                                                                                                                                                                               
                                          
