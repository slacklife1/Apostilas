<?php
/* vim: set expandtab shiftwidth=4 softtabstop=4 tabstop=4 autoindent: */
/*****************************************************************************\
*   Classe para lembrar a senha esquecida em um sistema, a senha e enviada    *
*   para um e-mail ja cadastrado no sistema.                                  *
*-----------------------------------------------------------------------------*
*                                    Autor                                    *
*-----------------------------------------------------------------------------*
*                                                                             *
*   Ademir Lima                                                               *
*   adell@ieg.com.br                                                          *
*                                                                             *
*-----------------------------------------------------------------------------*
*                                > Documenta��o <                             *
*-----------------------------------------------------------------------------*
*                                                                             *
*   $user         -> Nome do usuario da senha a ser lembrada                  *
*   $mail         -> Mail do usuario a ser localizado no bd                   *
*   $tabela       -> Nome da tabela no bd                                     *
*   $campo_nome   -> Nome do campo onde est� o nick/nome do usuario na tabela *
*   $campo_senha  -> Nome do campo onde est� a senha do usuario na tabela     *
*   $campo_mail   -> Nome do campo onde foi gravado o email do usuario        *
*                                                                             *
*   Sintaxe                                                                   *
*                                                                             *
*   Lembra uma senha para um sistema se senhas plana (sem criptogafia):       *
*                                                                             *
*   $senha = new LembraSenha();                                               *
*   $senha->L_Senha_Plana($nome, $email, $tb, "nome", "pass", "email");       *
*                                                                             *
\*****************************************************************************/

$bd="teste1";
$host="localhost";
$senha="li8ad3";
$user="root";
$id = mysql_connect($host, $user, $senha);
$id_bd = mysql_select_db($bd);

class LembraSenha
{
    function L_Senha_Plan($user, $mail, $tabela, $campo_nome, $campo_senha, $campo_email)
    {
        //Verificando se todos os parametros foram passados
        if(!isSet($user))
        {
            echo "Preciso de informa��o, a variavel \$user n�o est� setada";
            exit();
        }
        if(!isSet($mail))
        {
            echo "Preciso de informa��o, a variavel \$mail n�o est� setada";
            exit();
        }
        if(!isSet($tabela))
        {
            echo "Preciso de informa��o, a variavel \$tabela n�o est� setada";
            exit();
        }
        if(!isSet($campo_nome))
        {
            echo "Preciso de informa��o, a variavel \$campo_nome n�o est� setada";
            exit();
        }
        if(!isSet($campo_senha))
        {
            echo "Preciso de informa��o, a variavel \$campo_senha n�o est� setada";
            exit();
        }
        if(!isSet($campo_email))
        {
            echo "Preciso de informa��o, a variavel \$campo_email n�o est� setada";
            exit();
        }
        
        //procura a senha
        $query = "select $campo_nome,$campo_email,$campo_senha from $tabela where $campo_nome = '$user' and $campo_email = '$mail';";
        $senha = mysql_query($query);
        $senha = mysql_fetch_row($senha);
        $corpo = "\nVoce pediu para que enviassemos sua senha para seu email, aqui esta ela\n$senha[2]\nwww.exemplo.com.br\nSuporte Tecnico\n";
        //Manda a senha para o usuario
        mail($senha[1],"Lembrar senha",$corpo);
        print "Sua senha foi enviada para o email $senha[1]";
        return(0);
    }
}
