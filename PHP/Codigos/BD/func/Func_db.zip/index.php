<?/*###############################################################################################
######                                                                                      #######
######           FUN��O DE PESQUISA,INSER��O,REMO��O NO BANCO DE DADOS MYSQL                #######
######                                                                                      #######
######           DESENVOLVIDA POR  Robert_Rsc                                               #######
######                             roberto@nutecs.com                                       #######
######                                                                                      #######
###### ATEN��O: VC PODE USAR E ABUSAR DO USO DESTE SCRIPT, SE PUDER AT� MELHORE-O, MAS POR  #######
######          FAVOR SE POSS�VEL MANTENHA OS CR�DITOS                                      #######
######                                                                                      #######
###################################################################################################
>>
>>>>
>>>>>> ATEN��O: AOS USU�RIOS MAIS EXPERIENTE ACREDITO SER DESNECESS�RIO LEREM ESTE LONGO COMENT�RIO QUE SE SEGUE...
>>>>
>>

FUNCIONAMENTO:
Primeiro colocamos a chamada para esta fun��o nas p�ginas em que se far� necess�rio o uso dela

include "fun_dbf.php";

VARI�VEIS UTILIZADAS:
			$query => aqui ser� informada a query a ser realizada no banco
	
			$fun => informe o tipo de tratamento que a pesquisa dever� resultar 
					EX:( fetch = mysql_fetch_array, num = mysql_num_rows, row = mysql_fetch_row )
					ou ent�o deixe em branco ou n�o declare esta vari�vel para retornar o resultado puro.
	
			$conex�oMY =>	neste exemplo esta vari�vel j� esta no mesmo arquivo da fun��o (fun_dbf.php). 
							Ela cont�m os dados para a conex�o com o mysql 	
	
			($conexaoMY = "ENDERECO&&USUARIO&&SENHA&&BANCO";) substitua os valores em letras mai�sculas pelos dados da sua conta mysql exemplo:
					
			$conexaoMY = "ENDERECO&&USUARIO&&SENHA&&BANCO";
			substitua pelos seus dados:

			EX:	$conexaoMY = "localhost&&administrador&&258369&&bancoTeste";


COMO UTILIZAR:
Em qualquer lugar da p�gina em que precisarmos chamar a fun��o utilizamos as vari�veis chave da seguinte maneira:

EXEMPLO PR�TICO: 1

			Pesquisa em uma tabela mysql (retornando o resultado puro da pesquisa no mysql)
			"note que n�o foi setado nenhum valor para a vari�el "$fun" na realidade eu nem precisaria ter declarado ela"

			$query = "SELECT * FROM clientes WHERE bairro = 'centro'";
			$fun = "";
			$ret = dbf($query,$fun,$conexaoMY);

			Depois deste ponto a vari�vel $ret conter� o resultado da pesquisa no mysql, e claro poder� ser tratada como vc bem entender....

			exemplo: $total_registros = mysql_num_rows($ret);


EXEMPLO PR�TICO: 2

			Pesquisa em uma tabela mysql (retornando o resultado em um array fetch)

			$query = "SELECT * FROM clientes WHERE bairro = 'centro'";
			$fun = "fetch";
			$ret = dbf($query,$fun,$conexaoMY);

			Apartir daqui vc pode trabalhar com o conte�do do fetch array retornado "$ret"
			exemplo: Nome do cliente: $ret["nome_cliente"] telefone de contato $ret["telefone_contato"]


EXEMPLO DE INCLUS�O NO BANCO DE DADOS USANDO ESTA FUN��O:


			$query = "INSERT clientes SET nome_cliente = '$var_nome', telefone_contato = '$var_tel_contato'";
			$fun = "";
			$ret = dbf($query,$fun,$conexaoMY);

			Para confirmar a inclus�o vc faz assim:

			if($ret){echo "Dados inclu�dos com sucesso";} else {echo "Erro na inclus�o ".mysql_error();}

Bom acredito que este longo coment�rio tenha exemplificado bem o uso desta fun��o, para as fun��es de altera��o "UPDATE" e remo��o "DELETE" acredito que n�o restem maiores d�vidas.

ABAIXO SEGUE UM EXEMPLO FUNCIONAL:
*/
?>



<?
include "fun_dbf.php";
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> New Document </TITLE>
<META NAME="Generator" CONTENT="PHPCODE">
<META NAME="Robert_Rsc" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
<style>
p {	font-family: Verdana, Arial, Helvetica, sans-serif; 
	font-size: 12px; 
	word-spacing: 0; 
	margin: 0
	}
</style>
</HEAD>
<BODY>
<br>
<?
$query = "select * from clientes"; 
$fun = "";
$ret = dbf($query,$fun,$conexaoMY);

while ($imprime = mysql_fetch_array($ret)){?>
<p><B>Cliente Nome:</B> <?echo $imprime["nome"];?></P>
<p><B>E-mail:</B> <?echo $imprime["email"];?></p>&nbsp;	
<?}?>
</BODY>
</HTML>