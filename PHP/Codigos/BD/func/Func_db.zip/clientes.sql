# phpMyAdmin MySQL-Dump
# version 2.3.0-rc4
# http://phpwizard.net/phpMyAdmin/
# http://www.phpmyadmin.net/ (download page)
#
# Servidor: localhost
# Tempo de Genera��o: Abr 20, 2003 at 01:11 PM
# Vers�o do Servidor: 4.00.04
# Vers�o do PHP: 4.2.3
# Banco de Dados : `teste`
# --------------------------------------------------------

#
# Estrutura da tabela `clientes`
#

CREATE TABLE clientes (
  codigo int(11) NOT NULL auto_increment,
  nome varchar(50) NOT NULL default '',
  email varchar(50) NOT NULL default '',
  PRIMARY KEY  (codigo)
) TYPE=MyISAM COMMENT='tabela exemplo fun��o DBF';

#
# Extraindo dados da tabela `clientes`
#

INSERT INTO clientes VALUES (1, 'Lojas Americas', 'americanas@americanas.com.br');
INSERT INTO clientes VALUES (2, 'Colombo Materiais para Constru��o', 'materiaiscolombo@ig.com.br');
INSERT INTO clientes VALUES (3, 'Supermercado Vit�ria', 'mercadovitoria@mercadovitoria.com.br');
INSERT INTO clientes VALUES (4, 'ADVB - advogados associados', 'advbadv@advbadv.com');
INSERT INTO clientes VALUES (5, 'Inca Sistemas', 'incasis@incasis.com.br');
INSERT INTO clientes VALUES (6, 'Cart�rio de Protestos 14', 'cartprotestos14@cartprotestos14.com.br');
INSERT INTO clientes VALUES (7, 'Livraria F�tima', 'fatimalivraria@bol.com.br');
INSERT INTO clientes VALUES (8, 'Escola Magister', 'escmagister@escmagister.com');
INSERT INTO clientes VALUES (9, 'Autoescola do Z�', 'autoescoladoze@hotmail.com');
INSERT INTO clientes VALUES (10, 'Farm�cia do Norte', 'farmaciadonorte@ig.com.br');

