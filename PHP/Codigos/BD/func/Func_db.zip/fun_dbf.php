<?
// SUBSTITUA AS ENTRADAS EM LETRA MAI�SCULAS ABAIXO PELOS SEUS DADOS DE CONEX�O COM MYSQL

$conexaoMY = "ENDERECO&&USUARIO&&SENHA&&BANCO";

function dbf($query,$fun,$conexaoMY){
$con = explode("&&",$conexaoMY);
$conexao = mysql_connect($con[0],$con[1],$con[2]);
$sql = $query;
$res2 = mysql_db_query("$con[3]","$sql",$conexao);
if($fun == "num"){$retorna = mysql_num_rows($res2);}
if($fun == "fetch"){$retorna = mysql_fetch_array($res2);}
if($fun == "row"){$retorna = mysql_fetch_row($res2);}
if($fun == ""){$retorna = $res2;}
return $retorna;
mysql_close($res1);
}
?>