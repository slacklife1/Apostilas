<?
function ibase_num_rows($TBD, $Database, $Comando)
      {
	  $SQL_New = new TSQL($TBD, $Database);
	  $Consulta = $SQL_New->Query($Comando);
      $i = 0;
      while ($SQL_New->fetch($Consulta)) 
  	        {
		    $i++;
		    }
      return $i;
}

Class TSQL 
      {
      var $Connection; // Numero da conex�o!!
	  var $TBD;        // Tipo do Banco de Dados (MY - Mysql, PG - PostgreSQL, FB - Firebird)
	  var $Database;   // Base a ser usada!
	  var $SQL;        // Comando SQL
	  var $Insert_Id; // Ultimo ID Gerado
      var $Host = "localhost";
      var $User = "web";
      var $Password_MY = "suasenha";
      var $Password_PG = "suasenha";
      var $User_FB = "sysdba";
      var $Password_FB = "suasenha";

	  // Usado nas msgs da classe
 	  var $Mostrar; // Quando verdadeiro mostra a variavel SQL
	  var $Foreground = "#ffffff";
	  var $Background = "#0000ff";
	  var $Font_Face = "Verdana";
	  var $Font_Size = 4;
	  var $E_Mail = "erro_sql@reditecnologia.com.br"; // E-Mail para aonde o erro e enviado

	  function TSQL($TBD, $Database)
	     {
		 if ( empty($TBD) ) $this->Error("Falha na conex�o .: \n<br>HOST = $this->Host \n<br>DATABASE = $this->Database \n<br>USER = ******************************************** (hehehehe) \n<br>Passwd = ******************************************** (hehehehe)");
		 $this->Mostrar = false;
		 $this->Database = $Database;
		 $this->TBD = $TBD;
		 if ( $this->TBD == 'MY' ) $this->Connection = MySQL_Connect($this->Host, $this->User, $this->Password_MY);
		 if ( $this->TBD == 'PG' ) $this->Connection = Pg_Connect("user=$this->User password=$this->Password_PG dbname=$this->Database");
//		 if ( $this->TBD == 'FB' ) $this->Connection = ibase_connect($this->Database, $this->User, $this->Password_FB);
		 if ( $this->TBD == 'FB' ) $this->Connection = ibase_connect($this->Database);
		 if ( !$this->Connection ) 
		    {
		    if ($this->TBD == 'MY') $Text_Erro = mysql_error();
  		    if ($this->TBD == 'PG') $Text_Erro = pg_last_error($this->Connection);
  		    if ($this->TBD == 'FB') $Text_Erro = ibase_errmsg();
            $this->Error("Falha na conex�o .: \n<br>HOST = $this->Host \n<br>DATABASE = $this->Database \n<br>USER = ******************************************** (hehehehe) \n<br>Passwd = ******************************************** (hehehehe)\n<br>\n<br> Msg de Erro = $Text_Erro\n");
			}
		 if ( $this->TBD == 'MY' ) $this->Select_Database($Database);
		 }

      function Select_Database($Database)
	     {
		 if ( $this->TBD != "MY" ) $this->Error("ATEN��O - Esta fun��o so funciona no MYSQL!");
		 $this->Database = $Database;
		 $Ok = MySQL_Select_DB($this->Database);
		 if ( !$Ok ) $this->Error(" Falha na sele��o da Base de Dados .: \n<br>DATABASE = $this->Database");
		 }

      function Query($Comando)
	     {
		 $Comando = trim($Comando);
		 $this->SQL = $Comando;
		 $Tipo = substr($this->SQL,0,6);
		 $Tipo = strtoupper($Tipo);
		 if ( $this->TBD == 'MY' ) $Ok = mysql_query($this->SQL, $this->Connection);
		 if ( $this->TBD == 'PG' ) $Ok = pg_query($this->Connection, $this->SQL);
		 if ( $this->TBD == 'FB' ) $Ok = ibase_query($this->Connection, $this->SQL);
		 if ( $Tipo == "INSERT" ) $this->Insert_Id = mysql_insert_id($this->Connection);
		 if ( $this->Mostrar ) 
		    {
			echo "<br><table width=\"600\" border=\"0\" cellpadding=\"4\" cellspacing=\"4\" align=\"center\">";
			echo "<tr bgcolor=\"$this->Background\">";
			echo "<td><font face=\"$this->Font_Face\" size=\"$this->Font_Size\" color=\"$this->Foreground</font>\"><strong>$this->SQL</strong></font></td>";
			echo "</tr>";
			echo "</table><br>";
			}
		 if (!$Ok) 
		    {
		    if ($this->TBD == 'MY') $Text_Erro = mysql_error();
  		    if ($this->TBD == 'PG') $Text_Erro = pg_last_error();
  		    if ($this->TBD == 'FB') $Text_Erro = ibase_errmsg();
			$this->Error ("Falha na Consulta .: \n<br>$this->SQL \n<br>\n<br> Msg de Erro = $Text_Erro \n");
			}
		 $this->Logs("");
		 Return $Ok;
		 }

     function Logs($Erro)
         {
		 $Erro = str_replace('\"','\'',$Erro);
		 $Erro = str_replace('\n<br>',' ',$Erro);
		 $Erro = trim($Erro);
		 $Erro = htmlspecialchars($Erro, ENT_QUOTES);
		 $sql = htmlspecialchars($this->SQL, ENT_QUOTES);
		 $Dat = date("Y-m-d");
		 $Hor = date("H:i:s");
		 $Comando = "insert into logs (logusuario, logdata, loghora, logsql, logmsg) values ('$this->User', '$Dat', '$Hor', '$sql', '$Erro')";
		 if ( $this->TBD == 'MY' ) $Ok = mysql_query($Comando, $this->Connection);
		 if ( $this->TBD == 'PG' ) $Ok = pg_query($this->Connection, $Comando);
		 if ( $this->TBD == 'FB' ) $Ok = ibase_query($this->Connection, $Comando);
	     return;
		 }

      function Fetch($Consulta, $Rows)
	     {
	     if ($this->TBD == 'MY') $Ok = MySQL_Fetch_Array($Consulta);
  		 if ($this->TBD == 'PG') $Ok = Pg_Fetch_Array($Consulta, $Rows);
  		 if ($this->TBD == 'FB') $Ok = ibase_fetch_row($Consulta);
		 if (!$Ok) 
		    {
		    if ($this->TBD == 'MY') $Text_Erro = mysql_error();
  		    if ($this->TBD == 'PG') $Text_Erro = pg_result_error($Ok);
  		    if ($this->TBD == 'FB') $Text_Erro = ibase_errmsg();
			if ( $Text_Erro != "" ) $this->Error ("Falha no Fetch .: \n<br>$this->SQL \n<br>\n<br> Msg de Erro = $Text_Erro \n<br>Numero do Erro = $Num_Erro");
			}
	     return $Ok;
		 }

      function Begin()
	     {
	     if ($this->TBD == 'MY') $this->Error ("Esta Fun��o nao funciona no MYSQL");
  		 if ($this->TBD == 'PG') $Ok = Pg_Exec($this->Connection, "Begin;");
  		 if ($this->TBD == 'FB') $Ok = ibase_trans();
		 }

      function Commit()
	     {
	     if ($this->TBD == 'MY') $this->Error ("Esta Fun��o nao funciona no MYSQL");
  		 if ($this->TBD == 'PG') $Ok = Pg_Exec($this->Connection, "Commit;");
  		 if ($this->TBD == 'FB') $Ok = ibase_commit();
		 }

      function Rollback()
	     {
	     if ($this->TBD == 'MY') $this->Error ("Esta Fun��o nao funciona no MYSQL");
  		 if ($this->TBD == 'PG') $Ok = Pg_Exec($this->Connection, "Rollback;");
  		 if ($this->TBD == 'FB') $Ok = ibase_rollback();
		 }

      function Close()
	     {
         if ($this->TBD == 'MY') MySQL_Close($this->Connection);
         if ($this->TBD == 'PG') Pg_Close($this->Connection);
         if ($this->TBD == 'FB') ibase_close($this->Connection);
		 }

      function Rows($Consulta)
	     {
		 $Tipo = substr($this->SQL,0,6);
		 $Tipo = strtoupper($Tipo);
         if ($this->TBD == 'MY') 
		    if ($Tipo == 'SELECT')
  		       Return MySQL_Num_Rows($Consulta);
 	        else
		       Return MySQL_Affected_Rows($this->Connection);
         if ($this->TBD == 'PG') Return Pg_NumRows($Consulta);
         if ($this->TBD == 'FB') Return ibase_num_rows($this->TBD, $this->Database, $this->SQL);
		 }

      function Error($Erro)
	     {
		 $Erro = str_replace('\"','\'',$Erro);
		 $Erro = str_replace('\n<br>',' ',$Erro);
		 $Erro = trim($Erro);
	     echo "<br><table width=\"750\" border=\"0\" cellpadding=\"6\" cellspacing=\"6\" align=\"center\">";
		 echo "<tr bgcolor=\"$this->Background\"><td align=\"center\"><font face=\"$this->Font_Face\" size=\"$this->Font_Size\" color=\"$this->Foreground</font>\">Foi enviado por email este erro, tomaremos as providencias, Obrigado!!</font></td></tr>";
		 echo "<tr bgcolor=\"$this->Background\">";
		 echo "<td><font face=\"$this->Font_Face\" size=\"$this->Font_Size\" color=\"$this->Foreground</font>\"><strong>$Erro</strong></font></td>";
		 echo "</tr>";
		 echo "</table><br>";
		 $this->Logs($Erro);
		 mail("$this->E_Mail", "Erro - $this->TBD, Script .: $_SERVER[PHP_SELF] ", "Data .: ".date("d-m-Y")."\nHora .: ".date("H:i:s")."\nHost .: ".gethostbyaddr($_SERVER["REMOTE_ADDR"])."\nIp .: $_SERVER[REMOTE_ADDR]\nScript .: $_SERVER[PHP_SELF] \n\n $Erro", "From: $this->E_Mail");
		 exit;
		 exit;
		 }
    }
?>
