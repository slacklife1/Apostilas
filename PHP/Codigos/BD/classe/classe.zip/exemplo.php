<?
include ("classes.inc.php");
$SQL = new TSQL("MY", "exemplo");
//$SQL->Mostrar = true; // caso queira ver o sql descomente esta linha
$Consulta = $SQL->Query("select * from tabela1");
$Rows = $SQL->Rows($Consulta);
echo "<table align=\"center\" border=1>";
for ($c=0; $c<$Rows; $c++)
    {
	$Campo = $SQL->Fetch($Consulta, $c);
    echo "<tr><td>";
    echo "$Campo[tabnome]";
	echo "</td></tr>";
    }
echo "</table>";
$SQL->Close();
?>
