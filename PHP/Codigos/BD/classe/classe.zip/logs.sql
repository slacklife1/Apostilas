CREATE TABLE logs (
  logusuario varchar(200),
  logdata date NOT NULL,  
  loghora time NOT NULL,  
  logsql varchar(200),  
  logmsg varchar(200),  
  PRIMARY KEY  (logdata,loghora))
