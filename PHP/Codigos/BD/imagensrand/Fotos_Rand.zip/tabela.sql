# MySQL-Front Dump 1.16 beta
#
# Host: localhost Database: teste
#--------------------------------------------------------
# Server version 3.23.36
#
# Table structure for table 'fotos'
#

CREATE TABLE fotos (
  ID int(11) unsigned NOT NULL auto_increment,
  texto text ,
  caminho varchar(100) ,
  link varchar(255) ,
  PRIMARY KEY (ID),
  UNIQUE ID (ID)
);


