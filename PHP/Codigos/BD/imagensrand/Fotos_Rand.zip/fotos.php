<?
         $conn = mysql_connect('servidor','usuario','senha') or die('Erro na Conexao');
         $db = mysql_select_db('banco',$conn) or die('Erro ao Selecionar Banco');


         //Caso queiro almentar a quantidade de imagens a ser exibida altere o numero do LIMIT da SQL
         //A Funcao RAND() para o SELECT faz com que seja feito o SQL randomico
	
         $SQL = "SELECT * FROM fotos ORDER BY RAND() LIMIT 3";

         $result = mysql_query($SQL) or die('Erro na SQL');


         echo "<TABLE>";
         while($coluna = mysql_fetch_array($result)){
               echo "<TR>";
               echo "<TD><A HREF=$coluna[link]><IMG SRC=$coluna[caminho]></IMG></A></TD>";
               echo "<TD>$coluna[texto]></TD>";
               echo "</TR>";
         }
         echo "</TABLE>";
?>