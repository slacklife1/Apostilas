<?php
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++#
#				Cria��o - Michel Souza	#
#	Script de exibi��o de banco de dados com tabelas#
#                 sem Arrays!!!!                        #
#                                                       #
#              griphom@bol.com.br                       #
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++#

// conex�o com o banco de dados
$hostname_teste = "localhost";
$database_teste = "banco de dados";
$username_teste = "user";
$password_teste = "suasenha";
$teste = mysql_pconnect($hostname_teste, $username_teste, $password_teste) or die(mysql_error());

//sele��o da tabela

$table = "nome da Tabela";
$tabela = mysql_select_db ($table);

//selecionamento dos dados

mysql_select_db($tabela, $teste);
$query_teste = "SELECT nome_do_campo FROM '$tabela' ORDER BY nome_do_campo ASC";
$teste1 = mysql_query($query_teste, $teste) or die(mysql_error());

//calculo da quantidade de linhas e colunas

$row_teste1 = mysql_fetch_assoc($teste1);
$totalRows_teste1 = mysql_num_rows($teste1);


?>
<html>
<head>
<title>Teste</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFCC99">
<h3 align="center"><font face="Verdana, Arial, Helvetica, sans-serif">Script de 
  exibi&ccedil;&atilde;o de banco de dados com tabelas </font></h3>
<p>&nbsp;</p>
<div align="center">
<table width="90%" border="1" align="center">
  <tr bgcolor="#009966"> 
    <td><strong><font color="#FFFFFF" size="2" face="Geneva, Arial, Helvetica, sans-serif">::Campo1</font></strong></td>
                  
    <td><strong><font color="#FFFFFF" size="2" face="Geneva, Arial, Helvetica, sans-serif">::Campo2</font></strong></td>
                  
    <td><strong><font color="#FFFFFF" size="2" face="Geneva, Arial, Helvetica, sans-serif">::Campo3</font></strong></td>
                  
    <td><strong><font color="#FFFFFF" size="2" face="Geneva, Arial, Helvetica, sans-serif">::Campo4</font></strong></td>
                  
    <td><strong><font color="#FFFFFF" size="2" face="Geneva, Arial, Helvetica, sans-serif">::Campon</font></strong></td>
                </tr>
                <?php do { ?>
                <tr> 
                  <td><font size="2" face="Geneva, Arial, Helvetica, sans-serif"><?php echo $row_teste1['nome_do_campo1']; ?></font></td>
                  
    <td bgcolor="#CCCCCC"><font size="2" face="Geneva, Arial, Helvetica, sans-serif"><?php echo $row_teste1['nome_do_campo2']; ?></font></td>
                  <td><font size="2" face="Geneva, Arial, Helvetica, sans-serif"><?php echo $row_teste1['nome_do_campo3']; ?></font></td>
                  
    <td bgcolor="#CCCCCC"><font size="2" face="Geneva, Arial, Helvetica, sans-serif"><?php echo $row_teste1['nome_do_campo4']; ?></font></td>
                  <td><font size="2" face="Geneva, Arial, Helvetica, sans-serif"><?php echo $row_teste1['nome_do_campon']; ?></font></td>
                </tr>
                <?php } while ($row_teste1 = mysql_fetch_assoc($teste1)); ?>
              </table>
			  <?php
			  //com este script � f�cil criar campos repetidos sem criar arrays complexas ou coisas do G�nero!!!
?>
</div>
</body>
</html>
