<?
    ##########################################
    # C�digo Gerado por Tadeu Pires Pasetto  #
    ##########################################
    #http://info.integrando.com.br/~al-u6zcg #
    ##########################################
    #         t.pasetto@bol.com.br           #
    ##########################################
    #C�digo Livre desde que os Cr�ditos sejam#
    #   mantidos. Tamb�m podem ser feitas    #
    #altera��es para  melhor funcionabildade #
    ##########################################

?>
<!doctype html public "-//W3C//DTD HTML 4.0 //EN">
<!-- Feito por Tadeu Pires Pasetto-->
<html>
<head>
       <title>Mapa do BD</title>
</head>
<body style="font-family: arial">

<?
$user = "usuario";// Usuario
$pass = "senha";//senha
$bd = "Banco de Dados"; // Banco de dabos do qual se pretende fazer o mapa
    echo ("<center><h1>BD: $bd</center></h1>");// titulo

$con = mysql_connect("localhost", "$user", "$pass"); // conexao
$result = mysql_list_tables ("$bd");// Consulta as tabelas do BD
$i = 0;

$file = file("$bd.bd"); // abre o arquivo com os relacionamntos
$x = 0;
$relacionamentos = "<table><tr><td><b><center> Relacionamentos </center></td></tr>";

// este While gera um array com todos os relacionamntos
while($file[$x] != ""){
    $rela = explode(" = ", $file[$x]);
    $y = $x +1;
    $relacionamentos .= "<tr><td><center>".$y." - ".$file[$x]."</center></td></tr>";
    $x++;
    $a = strlen($rela[1]);
    $a--;
    $a--;
    $rela[1] = substr($rela[1], 0, $a);
    $campos[$rela[0]] .= "$x,";
    $campos[$rela[1]] .= "$x,";
}

//comecando a imprimir
echo ("<center><table width= 600px>");
$rel = 0;
while ($i < mysql_num_rows ($result)) {
    if($i%3 == 0){ // exibe 3 tabelas por linha
        echo("<tr>");
    }
    $tabela = mysql_tablename ($result, $i); // carrega onome da tabela
    echo ("<td><br><table width= 120px border=1><tr><td><b><center>$tabela</b></center></td></tr>");
    $res = mysql_db_query("$bd", "select * from $tabela", $con);
    $num = mysql_num_fields ($res); // numero de campos
    $x = 0;
    while($x < $num){
        $campo = mysql_field_name($res, $x); // nome do campo
        $nome = $tabela.".".$campo;
        
        // Codigo para retirar a ultima virgula
        $a = strlen($campos[$nome]);
        $a--;
        $campos[$nome] =substr($campos[$nome], 0, $a);
        $a++;
        if($a != 0){
                $campos[$nome] .=" - ";
        }
        echo("<br><tr><td><center><table><tr><td>".$campos[$nome]."</td><td>$campo</td></tr></table></center></td></tr>");
        $x++;
    }
    echo("</table></td>\n");
    if($i%3 == 2){
        echo("</tr>");
    }
    $i++;
}

echo("</table><br><br><br>$relacionamentos");

?>


</body>
</html>
