<?
// Classe db usada para acesso a banco de dados "componentalizado"
// Leandro - 05/04/2002

   class db
   {
      var $lines;
      var $affected;
	  var $result;
      
      function db()
      {
         include("config.db.php");
         if ($conpersistente)
	 {
	    mysql_pconnect($servidor, $usuario, $senha);
	    $this->selectdb($alias);
	 }
      }
      
      function selectdb($alias)
      {
         mysql_select_db($alias);
      }
      
      function query($sql)
      {
         include("config.db.php");
         if (!$conpersistente)
	 {
	    $db = mysql_connect($servidor, $usuario, $senha);
	    $this->selectdb($alias);
	    $result = mysql_query($sql, $db);
	    if ($this->isselect($sql))
	       $this->lines = mysql_num_rows($result);
	    $this->affected = mysql_affected_rows($db);
	    mysql_close($db);
	    $this->result = $result; 
	 }
	 else
	 {
	    $result = mysql_query($sql);
	    if ($this->isselect($sql))
	       $this->lines = mysql_num_rows($result);
	    $this->affected = mysql_affected_rows();
	    $this->result = $result;
	 }
      }
      
      function isselect($sql)
      {
         if (strpos(strtolower($sql), "select") === false)
	    return false;
	 else
	    return true;
      }
	  
      function row($row, $field)
      {
         return mysql_result($this->result, $row, $field);
      }
   }
?>