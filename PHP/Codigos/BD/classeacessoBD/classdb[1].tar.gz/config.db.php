<?
   $servidor = "";
   $usuario = "root";
   $senha = "";
   $alias = "";
   $conpersistente = false; // Conex�o persistente ao servidor de Mysql - veja db.class.php
?>
