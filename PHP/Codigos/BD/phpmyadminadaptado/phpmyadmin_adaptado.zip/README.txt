///////////////////////////////////////////////////////////////////////////////
//
//			PhpMyAdmin Adaptado V. 2.1.0
//
///////////////////////////////////////////////////////////////////////////////
//
// Este software de administra��o do SGBD MySQL foi criado por 
// Tobias Ratschiller, pode ser encontrado na sua vers�o original 
// em http://www.phpwizard.net/phpmyadmin e � um open source.
//
// Altera��es no software: Pelo fato do PhpMyAdmin ser um open source, ou 
// seja, c�digo fonte aberto e de livre distribui��o, pude ent�o adapt�-lo �s ne// cessidades da empresa onde trabalho 
// FIC - Faculdades Integradas de Caratinga/MG http://www.spep.com.br
//
//////////////////////////////////////////////////////////////////////////////
	
     Foi criado o arquivo index.html que recebe o login e a senha de um usu�rio j� cadastrado no SGBD. Esses dados s�o remetidos ao arquivo redireciona.php que "seta" dois cookies (um com o login e outro com a senha) e redireciona para o arquivo index.php que por sua vez faz o restante o processo.
     Foi podificado o arquivo config.inc.php (Configura�oes gerais do software), essa modifica��o consiste em atribuir os cookies �s vari�veis: $cfgServers[1]['stduser']  $cfgServers[1]['stdpass']   $cfgServers[1]['user']   $cfgServers[1]['password'] 

OBS.: Seu servidor web deve estar configurado para abrir automaticamente o arquivo index.html. Caso contr�rio altere a configura��o ou chame ent�o pela url http://seuservidor.com.br/phpmyadmin/index.html

Bruno Rodrigues Silva - http://www.spep.com.br/~brunors
brunors@spep.com.br
Curso de Ci�ncia da Computa��o
FIC - Faculdades Integradas de Caratinga/MG
01/01/2001
