<?

setcookie ("usuario", $user);
setcookie ("senha", $pass);

Header ("Location: index.php");


?>

