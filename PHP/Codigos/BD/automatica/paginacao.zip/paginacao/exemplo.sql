# Database : `loja`
# --------------------------------------------------------

#
# Table structure for table `clientes`
#

CREATE TABLE clientes (
  nome varchar(200) NOT NULL default '',
  profissao varchar(200) NOT NULL default '',
  PRIMARY KEY  (nome)
) TYPE=MyISAM;

#
# Dumping data for table `clientes`
#

INSERT INTO clientes (nome, profissao) VALUES ('Jos�', 'Chaveiro');
INSERT INTO clientes (nome, profissao) VALUES ('Jo�o', 'Padeiro');
INSERT INTO clientes (nome, profissao) VALUES ('Rita', 'Costureira');
INSERT INTO clientes (nome, profissao) VALUES ('Marcela', 'Curandeira');
INSERT INTO clientes (nome, profissao) VALUES ('Cabral', 'Cientista');
INSERT INTO clientes (nome, profissao) VALUES ('Marisa', 'Parteira');
INSERT INTO clientes (nome, profissao) VALUES ('Virgulino', 'Violonista');
INSERT INTO clientes (nome, profissao) VALUES ('Lu�s', 'Eletricista');
INSERT INTO clientes (nome, profissao) VALUES ('Manuel', 'Lojista');
INSERT INTO clientes (nome, profissao) VALUES ('Santana', 'M�sico');
INSERT INTO clientes (nome, profissao) VALUES ('Maria Rita', 'M�sico');