<?php
//////////////////////////////////////
// arquivo exemplo:
//      supomos que voce tenha uma database chamada loja,
//      e nela seus clientes estao cadastrados
//      os fields supostos da tabela clientes sao:
//          nome 		(varchar(size))
//          profissao	(varchar(size))
//      acompanha exemplo.sql, caso queira ver esta p�gina funcionando
// assim, abrimos a conexao, incluimos a paginacao e logo em seguida
//  fazemos a query, incluindo (nao se esquecam) o $PAG_ADD_PESQ na
//  pesquisa


// abrimos conexao
$my_mysql_id_connection = mysql_connect('localhost','usuario','senha');
$my_database = mysql_select_db('loja',$my_mysql_id_connection);

// ***************************************
// SCRIPT DE PAGINACAO (MOSTRA_RESULTADOS = true)
// **************************************
$PAG_TABELA = 'clientes';
$PAG_RES_POR_PAGINA = '5';
$PAG_MYSQL_ID = $my_mysql_id_connection;
$PAG_MYSQL_DB = 'loja';
$PAG_END_QUERY = 'ORDER BY nome ASC';
include_once('paginacao.inc.php');
//////////////////////////////////////////


// fazendo a query e mostrando a paginacao:
echo "<BR><BR><table align='center'>";
$clients_query = mysql_query('SELECT * FROM '.$PAG_TABELA.' '.$PAG_ADD_PESQ, $my_mysql_id_connection);
if (mysql_num_rows($clients_query) > 0) {
	while ($clients = mysql_fetch_array($clients_query)) {
	    echo '<tr><td>';
	    echo 'Cliente: '.$clients['nome'].'</td><td>';
	    echo 'Profissao: '.$clients['profissao'].'';
	    echo '</td></tr>';
	}
} else {
	echo '';
}
echo "</table>";

?>
