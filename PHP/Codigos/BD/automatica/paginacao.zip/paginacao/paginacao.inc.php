<?php
/* vim: set expandtab tabstop=4 shiftwidth=4: */
// +----------------------------------------------------------------------+
// | PHP version 4                                                        |
// +----------------------------------------------------------------------+
// | Copyright (c) 1997-2004 The PHP Group                                |
// +----------------------------------------------------------------------+
// | This source file is subject to version 3.0 of the PHP license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available through the world-wide-web at the following url:           |
// | http://www.php.net/license/3_0.txt.                                  |
// | If you did not receive a copy of the PHP license and are unable to   |
// | obtain it through the world-wide-web, please send a note to          |
// | license@php.net so we can mail you a copy immediately.               |
// +----------------------------------------------------------------------+
// | Authors: Vin�cius Augusto Tagliatti Zani <viniciustz@netscape.net>   |
// +----------------------------------------------------------------------+
//
// $Id:
/* *********************LEIA ATENTAMENTE*********************
 * Como usar - (3) Passos:
 *      (1) Escolher o local onde a frase (e link) da paginacao
 *          ser�o exibidos (numa tabela, por exemplo)
 *
 *      (2) Digitar manualmente, pr�-configurando o paginador,
 *				as variaveis (leia abaixo)
 *          $PAG_TABELA = "tabela a ser paginada";
 *          $PAG_RES_POR_PAGINA = "resultados exibidos por pagina (numeal)";
 *			$PAG_END_QUERY = "ORDER BY ID DESC";
 *			$PAG_MYSQL_ID = $seu_id_de_conexao_mysql_aberta;
 *
 *      (3) Digitar logo abaixo: (veja o diretorio de inclusao correto)
 *           include_once("paginacao.php");
 *
 *************************************************************/

/** Variaveis que TEM que ser setadas para o paginador funcionar:
 *  $PAG_TABELA: qual tabela MYSQL sera paginada
 *      exemplo: $PAG_TABELA = 'usuarios'; // tabela usuarios
 *  $PAG_RES_POR_PAGINA: quantos resultados serao obtidos por pagina
 *      exemplo: $PAG_RES_POR_PAGINA = '10'; // 10 resultados por pagina
 *  $PAG_MYSQL_ID: seu id de conexao mysql aberta.
 *      exemplo: $PAG_MYSQL_ID = $my_mysql_id_connection;
 **/

/** Variaveis opcionais:
 * $PAG_END_QUERY: caso queira ordenar sua persquisa
 */

/************************
 * PARTE CONFIGURAVEL:
 ************************/

/******
 * IMPORTANTE:
 *  E necessario que uma conexao mysql esteja aberta e voce tenha o ID
 *
 ******/
// $PAG_MYSQL_ID = $my_mysql_id_connection; // MUDE ESTE VALOR PARA SUA CONEXAO, CASO ELA SEJA DEFAULT
		// E VOCE QUEIRA UTILIZAR UMA CONEXAO JA ABERTA
$PAG_MYSQL_SERVER = 'localhost'; // o host para o server mysql, usualmente localhost
$PAG_MYSQL_USER = ''; // usuario mysql
$PAG_MYSQL_PWD = ''; // password mysql
//$PAG_MYSQL_DB = ''; // db mysql descomente para generalizar

//$PAG_RES_POR_PAGINA = "3"; // descomente a linha para generalizar e nao
//                         // ter que ficar digitando no arquivo-m�e
$PAG_PARAGRAPH_STYLE['inicio'] 	= "<b><font face='Verdana' size='1'><div align='center'>\n";
$PAG_PARAGRAPH_STYLE['fim'] 	= "\n</div></font></b>";
// visual do link
$PAG_LINK['antes'] = '[ ';
$PAG_LINK['depois'] = ' ]';
// voce pode colocar imagens como links aqui:
$PAG_LINK['anterior'] = "<< Anterior";
$PAG_LINK['proximo'] = "Pr�ximo >>";
// ex: <img src='proxima.gif'></img>

/**********************
 * Se false, VOCE tera que colocar onde bem entender os resultados
 *    da paginacao, usando echo $PAG_RESULT;
 **********************/
$PAG_MOSTRA_RESULTADOS = true;


/* -------------------------------//----------------------------------- */

/************************
 * PARTE NAO-CONFIGURAVEL:
 *************************/

$PAG_ERR_MSG = '';
if (!isset($PAG_TABELA)) {
	$PAG_ERR_MSG .= '<b><div align="center">A Variavel $PAG_TABELA n�o apresenta nenhum valor. (leia README)</div</b><BR>';
}
if (!isset($PAG_RES_POR_PAGINA)) {
    $PAG_ERR_MSG .= '<b><div align="center">A Variavel $PAG_RES_POR_PAGINA n�o apresenta nenhum valor. (leia README)</div</b><BR>';
}
if (!isset($PAG_MYSQL_ID)) {
    $PAG_ERR_MSG .= '<b><div align="center">A Variavel $PAG_MYSQL_ID nao foi configurada em paginacao.inc.php. Utilize um link mysql j� aberto, ou configure para uma nova conex�o.</div</b><BR>';
}
if (!isset($PAG_MYSQL_DB)) {
    $PAG_ERR_MSG .= '<b><div align="center">A Variavel $PAG_MYSQL_DB n�o apresenta nenhum valor. (leia README).</div</b><BR>';
}
if (!empty($PAG_ERR_MSG)) {
	echo $PAG_ERR_MSG;
	die;
}

// abrimos uma conexao
if ($PAG_MYSQL_ID == NULL) {
	$PAG_MYSQL_ID 	= mysql_connect($PAG_MYSQL_SERVER, $PAG_MYSQL_USER, $PAG_MYSQL_PWD);
	$PAG_OPENED_NEW = true;
}
$PAG_CHANGE_DB 	= mysql_select_db($PAG_MYSQL_DB, $PAG_MYSQL_ID);


// pegamos total e quanto queremos:
$PAG_RES = mysql_query("SELECT * FROM ".$PAG_TABELA.";",$PAG_MYSQL_ID) or die("Erro consultando ".$PAG_TABELA.": ".mysql_error());
$PAG_TOTAL = mysql_num_rows($PAG_RES);
mysql_free_result($PAG_RES);
$PAG_NUM = $PAG_RES_POR_PAGINA;

// contamos as paginas:
$PAG_counter = 1;
// Causa lentidao: for ($PAG_counter=1; $PAG_TOTAL > $PAG_NUM; $PAG_counter++, $PAG_TOTAL -= $PAG_NUM) { }
if ($PAG_TOTAL > $PAG_NUM) {
	while ($PAG_TOTAL > $PAG_NUM) {
		$PAG_counter++;
		$PAG_TOTAL -= $PAG_NUM;
	}
} else {
	$PAG_counter = 1;
}
$PAG_TOTAL_PAGINAS = ($PAG_counter-1); // usado para Proximo >>
unset($TOTAL);

// adicionamos informacoes a SUA query
if(!isset($HTTP_GET_VARS['PAGE']) && !isset($HTTP_POST_VARS['PAGE'])) {
	$PAGE = 0;
}
$PAG_INICIO = ($PAGE*$PAG_NUM);
$PAG_ADD_PESQ = " ".$PAG_END_QUERY." LIMIT ".$PAG_INICIO.",".$PAG_NUM;

// exibimos o(s) link(s) na tela:
$PAG_RESULT = $PAG_PARAGRAPH_STYLE['inicio']."P�ginas: ".$PAG_counter." : Mostrando resultados de ".($PAG_INICIO)." a ".($PAG_INICIO+$PAG_NUM).", ".$PAG_RES_POR_PAGINA." resultados por pagina.<BR>";

if (empty($_SERVER['QUERY_STRING'])) {
    $PAG_ADD_QUERY_LINK = '';
} else {
    if (ereg_replace('PAGE=[[:digit:]]+','',$_SERVER['QUERY_STRING']) != '&') {
        $PAG_ADD_QUERY_LINK = str_replace("&&","&","&".ereg_replace('PAGE=[[:digit:]]+','',$_SERVER['QUERY_STRING']));
	}
}


if ($HTTP_GET_VARS['PAGE'] > 0) {
	$PAG_RESULT .= '<a href="'.$_SERVER['PHP_SELF'].'?PAGE='.($HTTP_GET_VARS['PAGE']-1).$PAG_ADD_QUERY_LINK.'">'.$PAG_LINK['anterior'].'</a> ';
} else {
	$PAG_RESULT .= $PAG_LINK['anterior'].' ';
}

for ($PAG_counter_j = 0; $PAG_counter_j < $PAG_counter; $PAG_counter_j++) {
	if ($PAG_counter_j == $HTTP_GET_VARS['PAGE']) {
	    $PAG_RESULT .= $PAG_LINK['antes'].($PAG_counter_j+1).$PAG_LINK['depois']." ";
	    continue;
	}
	$PAG_RESULT .= '<a href="'.$_SERVER['PHP_SELF'].'?PAGE='.$PAG_counter_j.$PAG_ADD_QUERY_LINK.'">'.$PAG_LINK['antes'].($PAG_counter_j+1).$PAG_LINK['depois'].'</a>&nbsp;';
}

//echo $PAG_TOTAL_PAGINAS;die;
if ($HTTP_GET_VARS['PAGE'] < $PAG_TOTAL_PAGINAS) {
	$PAG_RESULT .= ' <a href="'.$_SERVER['PHP_SELF'].'?PAGE='.($HTTP_GET_VARS['PAGE']+1).$PAG_ADD_QUERY_LINK.'">'.$PAG_LINK['proximo'].'</a> ';
} else {
	$PAG_RESULT .= ' '.$PAG_LINK['proximo'];
}

$PAG_RESULT .= $PAG_PARAGRAPH_STYLE['fim'];
if ($PAG_MOSTRA_RESULTADOS == true) {
 echo $PAG_RESULT;
}
	
// liberamos as aviraveis/conexoes
unset($PAG_PARAGRAPH_STYLE, $PAG_LINK, $PAG_counter_j, $PAG_counter, $PAG_LINK, $PAG_ADD_QUERY_LINK, $PAG_INICIO, $PAG_FIM, $PAG_NUM, $PAG_TOTAL, $PAG_RES);
if ($PAG_OPENED_NEW == true) {
	mysql_close($PAG_MYSQL_ID);
}
unset($PAG_OPENED_NEW);

?>
