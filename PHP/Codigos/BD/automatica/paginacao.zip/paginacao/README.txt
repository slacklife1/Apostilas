/************************************************************************
 * Sistema Automatico de Pagina��o (SAP) Vers�o 1.0		README
 * Autor: Vin�cius Augusto Tagliatti Zani <viniciustz@netscape.net>	*
 * Sobre o SAP (GPL):							*
 *	Utilize e modifique como quiser, mas este sistema N�O � pago.	*
 ************************************************************************/

Perf�cio:
--------
	H� tempos venho tentando achar o m�todo mais r�pido e eficiente para paginar
resultados de banco de dados mysql em php. Buscando este objetivo, desenvolvi, utilizando
minhas t�cnicas (algumas ainda primitivas, infelizmente), um sistema autom�tico de pagina��o
de resultados.
	O que antes consmuia muitos Kbytes de digita��o e uma mon�tona repeti��o de c�digo,
agora � feito em 5 ou 6 linhas.


Como utilizar:
------------
	1 passo) Abra o arquivo paginacao.inc.php e leia atentamente a sua configura��o,
		fazendo-a ao seu gosto.

	2 passo) Abra o arquivo no qual ocorre� a pagina��o e v� at� o ponto onde voc� quer 
		a pagina��o (pode ser tanto no in�cio do arquivo, com os outros includes,
		tanto quanto no meio ou fim. Como desejar).

	3 passo) Configure o paginador, adicionando, em poucas linhas, o seguinte:
		$PAG_MYSQL_ID = $o_id_da_conexao_mysql_ja_aberta;
		$PAG_MYSQL_DB = 'database a ser utilizada';
		$PAG_TABELA = 'qual tabela mysql da sua db vai ser paginada';
		$PAG_RES_POR_PAGINA = 'numero';
		include_once('paginacao.inc.php');
		// CONFIGURACAO OPCIONAL
		// Caso queira que sua paginacao ordene inversamente a pesquiva
		// (por exemplo, ORDER BY nome DESC), faca o seguinte:
		$PAG_ADD_QUERY = 'ORDER BY nome DESC';
		(isso se incluir� automaticamente em $PAG_ADD_PESQ)

	   * OBS: SE VOC� N�O TEM UMA CONEX�O J� ABERTA, E DESEJA ABRIR UMA NOVA,
		ABRA O ARQUIVO paginacao.inc.php E MUDE A CONFIGURACAO.
	   * OBS 2: TODAS AS VARI�VEIS PODEM SER CONSTANTES, BASTANDO UTILIZ�-LAS
		DENTRO DO ARQUIVO paginacao.inc.php

	4 passo) Caso voc� N�O queira exibir no MESMO local de inclus�o o resultado da 
		pagina��o (por exemplo, voc� que coloc�-lo no final do seu arquivo.php),
		COMENTE, em paginacao.inc.php a variavel $PAG_MOSTRA_RESULTADOS,
		e onde voc� bem entender, ABAIXO do include, adicione:
		<?php echo $PAG_RESULT; ?>

	5 passo) Sua query que vai listar realmente a tabela desejada (veja exemplo)
		era provavelmente assim:
		$query = mysql_query("SELECT * FROM tabela");
		Modifique-a, fazendo:
		$query = mysql_query("SELECT * FROM ".$PAG_TABELA.$PAG_ADD_PESQ);
		O que foi feito, basicamente, foi que voc� limitou a pesquisa feita,
		igualando-a � pesquisa da pagina��o.
		ESTE PASSO � IMPRESCIND�VEL PARA O FUNCIONAMENTO DO SISTEMA.

	* PS: Caso precise de mais ajuda, olhe o exemplo.php que acompanha este sistema.


Agradecimentos:
-------------
	- Ao site phpbrasil (www.phpbrasil.com) por me dar espa�o para a publica��o.

Bugs e coment�rios:
-----------------
	Vin�cius Augusto Tagliatti Zani: viniciustz@netscape.net