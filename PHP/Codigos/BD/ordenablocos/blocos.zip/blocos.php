<?php
/*
Este script tem como objetivo somente aprender a fazer uma ordena��o de blocos em um site din�mico, exemplo PHP-Nuke,
ele tem esse mesmo detalhe de ordena��o dos blocos, para isso quebrei a cabe�a por algum tempo(Pois nao sou expert em php)
 para inventar algo que n�o fosse muito complicado e que resolvesse o problema.
Esteja a vontade para modificar esse script de acordo com suas necessidades, como colocar as outras fun��es etc,
s� mantenha meus cr�ditos no script modificado.*/

###########CR�DITOS###########
# Script Original Criado Por #
# 		Neander Ara�jo       #
#   neander@eumesmo.com.br   #
# http://www.eumesmo.com.br/ #
##############################

echo "
<title>Sistema de Ordena��o de Blocos</title>
<table width=500 cellspacing=1 cellpadding=3 align=center bgcolor=#BBBBBB>
<td align=\"center\" valign=\"middle\" colspan=\"4\" bgcolor=DDDDDD><font face=Verdana size=2><b>Dados do Bloco</b></font></td>
<tr>
<td bgcolor=EEEEEE><font face=Verdana size=2>Codigo do Bloco:</font></td>
<td bgcolor=EEEEEE><font face=Verdana size=2>Descri��o do Bloco:</font></td>
<td bgcolor=EEEEEE><font face=Verdana size=2>Ordem do Bloco:</font></td>
<td bgcolor=EEEEEE><font face=Verdana size=2>Lado do Bloco:</font></td>
</tr>
<tr>";
#Conex��o com a base de dados:
////////////////////////////////////////////////////////////////////
#Obs: Altere de a Conexao De Acordo Com a Sua Base de Dados
$mysql_usuario="root"; //Usuario da base de dados
$mysql_password="";//Senha da base de dados
$mysql_database="blocos";//Nome da base de dados
$mysql_host="localhost";//Host de sua base de dados, Ex:Localhost
$con = mysql_connect($mysql_host, $mysql_usuario, $mysql_password);
mysql_select_db($mysql_database, $con);
////////////////////////////////////////////////////////////////////

#Extrai da base o numero de blocos por lado:
$resnLinhaE=mysql_query("SELECT max(oBloco) as ord_max FROM bloco where lBloco = 'E'",$con); //Faz o select na base para o lado Esquerdo
$nE = mysql_fetch_array($resnLinhaE); //seta string de resultado para lado Esquerdo
$nLinhaE = $nE['ord_max'];  //conta as linhas para lado Esquerdo
$resnLinhaD=mysql_query("SELECT max(oBloco) as ord_max FROM bloco where lBloco = 'D'",$con); //Faz o select na base para o lado Direito
$nD = mysql_fetch_array($resnLinhaD); //seta string de resultado para lado Direito
$nLinhaD = $nD['ord_max'];  //conta as linhas para lado Direto

#Select principal para buscar todos os blocos cadastrados ordenado por lado e em seguida por ordem.
$resultado=mysql_query("SELECT * FROM bloco order by lBloco, oBloco",$con); //Faz o select principal para achar os dados
echo"<font face=Verdana size=3>Clique nas Setas Para Ordenar o Bloco:</font>";
while ($row = mysql_fetch_row($resultado)) {  //Enquanto ele for encontrando os dados...
$sobeoBloco = $row[2] -1;   //Seta variavel para subir o bloco
$desceoBloco = $row[2] + 1; //Seta variavel para descer o bloco
echo"
     	<td bgcolor=EEEEEE><font face=Verdana size=2>$row[0]</font></td>
		<td bgcolor=EEEEEE><font face=Verdana size=2>$row[1]</font></td>
		<td bgcolor=EEEEEE><font face=Verdana size=2>$row[2]</font>&nbsp;&nbsp;&nbsp;&nbsp;";
        //Se o valor da ordem for igual a 1...
        if ($row[2] == 1) {
           //...s� aparece a seta para baixo e seta as variaveis de descida
           echo"<a href=\"$PHP_SELF?&faz=Ordena&cBloco=$row[0]&amp;&oBlocoAnt=$row[2]&amp;&lBloco=$row[3]&amp;&oBloco=$desceoBloco\"><img src=\"d.gif\" border = 0 alt =\"Desce\"></a>";
          }
        //Se o valor da ordem for diferente de 1...
        else {
           //e ainda a coluna lBloco for igual a D...
           if ($row[3] == 'D') {
               //e o numero da ordem for igual ao numero total de linhas para o lBloco D...
               if ($row[2] == $nLinhaD) {
                   //Seta as variaveis de subida
                   echo"<a href=\"$PHP_SELF?&faz=Ordena&cBloco=$row[0]&amp;&oBlocoAnt=$row[2]&amp;&lBloco=$row[3]&amp;&oBloco=$sobeoBloco\"><img src=\"s.gif\" border = 0 alt =\"Sobe\"></a>";
                 }
               //Se o numero da ordem for diferente do numero total de linhas...
               else {
                   //Seta as variaveis de descida e subida, alem das imagens de seta para cima e para baixo
                   echo"<a href=\"$PHP_SELF?&faz=Ordena&cBloco=$row[0]&amp;&oBlocoAnt=$row[2]&amp;&lBloco=$row[3]&amp;&oBloco=$sobeoBloco\"><img src=\"s.gif\" border = 0 alt =\"Sobe\"></a>&nbsp;&nbsp;&nbsp;<a href=\"$PHP_SELF?&faz=Ordena&cBloco=$row[0]&amp;&oBlocoAnt=$row[2]&amp;&lBloco=$row[3]&amp;&oBloco=$desceoBloco\"><img src=\"d.gif\" border = 0 alt =\"Desce\"></a>";
                   }
             }
            //Se o lado for diferente de D... Faz as sele�oes referentes a E
            else {
                if ($row[2] == $nLinhaE) {
                    echo"<a href=\"$PHP_SELF?&faz=Ordena&cBloco=$row[0]&amp;&oBlocoAnt=$row[2]&amp;&lBloco=$row[3]&amp;&oBloco=$sobeoBloco\"><img src=\"s.gif\" border = 0 alt =\"Sobe\"></a>";
                  }
                else {
                 	echo"<a href=\"$PHP_SELF?&faz=Ordena&cBloco=$row[0]&amp;&oBlocoAnt=$row[2]&amp;&lBloco=$row[3]&amp;&oBloco=$sobeoBloco\"><img src=\"s.gif\" border = 0 alt =\"Sobe\"></a>&nbsp;&nbsp;&nbsp;<a href=\"$PHP_SELF?&faz=Ordena&cBloco=$row[0]&amp;&oBlocoAnt=$row[2]&amp;&lBloco=$row[3]&amp;&oBloco=$desceoBloco\"><img src=\"d.gif\" border = 0 alt =\"Desce\"></a>";
                    }
                }
            }
        echo"</font></td>
        <td bgcolor=EEEEEE><font face=Verdana size=2>$row[3]</font></td>
</tr>";

}
//Fun��o para ordena��o
function Ordena ( $cBloco, $oBloco, $oBlocoAnt,$lBloco ) {
  global $con,$PHP_SELF;
   //Verifica o lado para separar o update
   if ($lBloco == 'D') {
        //O primeiro update seta marca a ordem atual do bloco na coluna oBlocoN e seta a nova ordem
  		mysql_query("update bloco set oBlocoN = '$oBlocoAnt', oBloco= '$oBloco' where cBloco='$cBloco' and lBloco = 'D'", $con);
        //O segundo update seta a ordem do bloco destino igual a ordem do bloco origem
  		mysql_query("update bloco set oBloco= '$oBlocoAnt' where oBloco='$oBloco' and oBlocoN is null and lBloco = 'D'", $con);
     }
   //Se o lado do bloco for diferente de Direito, faz os updates
   else {
        //O primeiro update seta marca a ordem atual do bloco na coluna oBlocoN e seta a nova ordem
 	   	mysql_query("update bloco set oBlocoN = '$oBlocoAnt', oBloco= '$oBloco' where cBloco='$cBloco' and lBloco = 'E'", $con);
        //O segundo update seta a ordem do bloco destino igual a ordem do bloco origem
    	mysql_query("update bloco set oBloco= '$oBlocoAnt' where oBloco='$oBloco' and oBlocoN is null and lBloco = 'E'", $con);

       }
        //Limpa a coluna oBlocoN para futuras ordena��es
      	mysql_query("update bloco set oBlocoN = null ", $con);
        //Refresh na pagina(se quiser, use um script de sua prefer�ncia)
        echo"
        <script>window.location.href = \"blocos.php\";</script>";
}
switch($faz){

    case 'Ordena':
            Ordena($cBloco, $oBloco, $oBlocoAnt, $lBloco);
            break;
}

?>
<br>
<br>
</TABLE>
<p><br><font face=Verdana size=1>
<center>
<a href="blocos.php">Atualiza</a><br><br>
<font face=Verdana size=3>
CR�DITOS<br>
Script Original Criado Por<br>
Neander Ara�jo      <br>
<a href="mailto:neander@eumesmo.com.br">neander@eumesmo.com.br</a><br>
<a href="http://www.eumesmo.com.br" target = "_blank">http://www.eumesmo.com.br</a><br>
<br>
</body>
</html>