# MySQL-Front Dump 2.5
#
# Host: localhost   Database: blocos
# --------------------------------------------------------
# Server version 4.0.12-nt

USE blocos;


#
# Table structure for table 'bloco'
#

DROP TABLE IF EXISTS bloco;
CREATE TABLE bloco (
  cBloco int(3) NOT NULL auto_increment,
  dBloco varchar(30) NOT NULL default '0',
  oBloco int(3) default '0',
  lBloco char(1) NOT NULL default '',
  oBlocoN int(3) default NULL,
  PRIMARY KEY  (cBloco)
) TYPE=MyISAM;



#
# Dumping data for table 'bloco'
#

INSERT INTO bloco VALUES("1", "Bloco Um", "1", "D", NULL);
INSERT INTO bloco VALUES("2", "Bloco Dois", "2", "D", NULL);
INSERT INTO bloco VALUES("3", "Bloco Tr�s", "3", "D", NULL);
INSERT INTO bloco VALUES("4", "Bloco  Quatro", "4", "D", NULL);
INSERT INTO bloco VALUES("5", "Bloco 1 de E", "1", "E", NULL);
INSERT INTO bloco VALUES("6", "Bloco 2 de E", "2", "E", NULL);
INSERT INTO bloco VALUES("7", "Bloco 3 de E", "3", "E", NULL);
INSERT INTO bloco VALUES("9", "Bloco 5 de E", "4", "E", NULL);
INSERT INTO bloco VALUES("10", "Bloco 6 de E", "6", "E", NULL);
INSERT INTO bloco VALUES("11", "Bloco 10 de E", "7", "E", NULL);
