<?
################################
#Script Escrito Por
#Neander Ara�jo
#neander@eumesmo.com.br
#http://www.eumesmo.com.br
################################
//Modifique os dados abaixo de acordo com suas configura��es:
$mysql_usuario="user";  //Usu�rio de base de dados
$mysql_password="senha"; //Senha da base de dados
$mysql_database="dados"; //Nome da base de dados
$mysql_host="localhost"; //Host da base de dados
$conexion = mysql_connect($mysql_host, $mysql_usuario, $mysql_password);
mysql_select_db($mysql_database, $conexion);
function mensaje($texto,$url){
  echo"<br><br><center><b>$texto</b><br><br><br><a href=$url>Aceitar</a></center><br><br><br><br><br><br>";
}
?>