<?
################################
#Script Escrito Por
#Neander Ara�jo
#neander@eumesmo.com.br
#http://www.eumesmo.com.br
################################
include "setup.php";
$result=mysql_query("SELECT * FROM dados order by nome", $conexion);
echo"
<table width=500 cellspacing=1 cellpadding=2 align=center bgcolor=#BBBBBB>
<tr align=\"center\" valign=\"middle\">
<td bgcolor=#DDDDDD colspan=\"4\"><font face=verdana size=2><b>Lista de Nomes</b></font></td>
</tr>
<tr>
<td bgcolor=#DDDDDD>
<b><font face=verdana size=1>C�digo</td>
<td bgcolor=#DDDDDD>
<b><font face=verdana size=1>Nome</td>
<td bgcolor=#DDDDDD>
<b><font face=verdana size=1>Telefone</td>
<td bgcolor=#DDDDDD>
<b><font face=verdana size=1>Observa��o</td>
</b>
</tr>
";
while ($row = mysql_fetch_row($result)){
        echo"
        <tr>
        <td bgcolor=EEEEEE><font face=verdana size=1>
        $row[0]</td>
        <td bgcolor=EEEEEE><font face=verdana size=1>
        <a href=#>$row[1]</a></td>
        <td bgcolor=EEEEEE><font face=verdana size=1>
        $row[2]</td>
        <td bgcolor=EEEEEE><font face=verdana size=1>
        $row[3]</td>
        </tr>";
}
 echo "
</table>
<br><br><br><br>
<center><font face=verdana size=2>
<a href=incluir>Incluir Novo Cadastro</a></center>
";
?>