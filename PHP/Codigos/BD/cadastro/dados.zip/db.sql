# MySQL-Front Dump 2.2
#
# Host: localhost   Database: dados
#--------------------------------------------------------
# Server version 3.23.49-nt


#
# Table structure for table 'dados'
#

DROP TABLE IF EXISTS dados;
CREATE TABLE `dados` (
  `codigo` int(3) NOT NULL auto_increment,
  `nome` varchar(60) NOT NULL default '0',
  `telefone` varchar(60) NOT NULL default '0',
  `obs` varchar(60) NOT NULL default '0',
  PRIMARY KEY  (`codigo`)
) TYPE=MyISAM;

