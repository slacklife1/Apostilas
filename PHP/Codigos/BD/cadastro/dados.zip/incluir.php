<?php
################################
#Script Escrito Por
#Neander Ara�jo
#neander@eumesmo.com.br
#http://www.eumesmo.com.br
################################
include"setup.php";
global $faz,$PHP_SELF;
echo"
                          <form name=\"form1\" method=\"post\" action=\"$PHP_SELF?op=incluir&faz=grava\">
                          <table width=500 cellspacing=1 cellpadding=3 align=center bgcolor=#BBBBBB>
                            <tr align=\"center\" valign=\"middle\">
                              <td colspan=\"2\" bgcolor=DDDDDD><font face=arial size=2><b>Criar Novo Dado</b></font></td>
                            </tr>
                            <tr>
                              <td bgcolor=EEEEEE><font face=arial size=2>Nome:</font></td>
                              <td align=\"left\" bgcolor=EEEEEE>
                                <input class=\"clsTextbox\" type=\"text\" name=\"nome\" size=\"30\">
                              </td>
                            </tr>
                            <tr>
                              <td bgcolor=EEEEEE><font face=arial size=2>Telefone:</font></td>
                              <td align=\"left\" bgcolor=EEEEEE>
                                <input class=\"clsTextbox\" type=\"text\" name=\"telefone\" size=\"30\">
                              </td>
                            </tr>
                            <tr>
                              <td bgcolor=EEEEEE><font face=arial size=2>Observa��o:</font></td>
                              <td align=\"left\" bgcolor=EEEEEE>
                                <textarea name=\"obs\"></textarea>
                              </td>
                            </tr>
                            <tr>
                            <td align=\"center\" bgcolor=EEEEEE colspan=2>
                                <INPUT class=\"clsButton3\" value=\"Incluir\" type=submit></td>
                            </tr>
                          </table>
                          </form>
                          <br><br><br><br>
                          <center><font face=verdana size=2>
                          <a href=index>Voltar Para Pagina Inicial</a></font></center>
                          <script language=\"JavaScript\">
                          document.form1.nome.focus();
                          </script>";
function grava($nome,$telefone,$obs){
  global $conexion,$PHP_SELF;
  mysql_query("INSERT INTO dados (nome,telefone,obs) VALUES ('$nome','$telefone','$obs') ",$conexion);
}

switch($faz){
        case 'grava':
           grava($nome,$telefone,$obs);
  mensaje("Inclus�o Efetuada Com Sucesso","index");
           break;

}
?>