DROP TABLE IF EXISTS noticias;
CREATE TABLE noticias (
  `id` int(11) NOT NULL auto_increment,
  `titulo` varchar(255) NOT NULL default '',
  `data` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=4 ;

INSERT INTO noticias (titulo) VALUES ('Atentado em Madri');
INSERT INTO noticias (tituloa) VALUES ('Lula viaja e volta');