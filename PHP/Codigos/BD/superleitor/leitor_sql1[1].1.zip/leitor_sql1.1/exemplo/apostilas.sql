# phpMyAdmin SQL Dump
# version 2.5.6
# http://www.phpmyadmin.net
#
# Servidor: localhost
# Tempo de Genera��o: Mar 15, 2004 at 01:49 PM
# Vers�o do Servidor: 3.23.47
# Vers�o do PHP: 4.3.4
# 
# Banco de Dados : `apostilas`
# 

# --------------------------------------------------------

#
# Estrutura da tabela `aps_apostilas`
#

DROP TABLE IF EXISTS `aps_apostilas`;
CREATE TABLE `aps_apostilas` (
  `id` int(11) NOT NULL auto_increment,
  `nome` varchar(255) NOT NULL default '',
  `data` int(11) NOT NULL default '0',
  `data_alt` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=4 ;

#
# Extraindo dados da tabela `aps_apostilas`
#

INSERT INTO `aps_apostilas` VALUES (1, 'B�sicas', 1078491219, 0);
INSERT INTO `ola` VALUES (2, 'Volume 01', 1078513259, 0);
INSERT INTO `aps_apostilas` VALUES (3, 'Produ��o de Texto', 1078513285, 0);

# --------------------------------------------------------

#
# Estrutura da tabela `aps_conteudo`
#

DROP TABLE IF EXISTS `aps_conteudo`;
CREATE TABLE `aps_conteudo` (
  `id` int(11) NOT NULL auto_increment,
  `nome` varchar(255) NOT NULL default '',
  `apostila` int(11) NOT NULL default '0',
  `materia` int(11) NOT NULL default '0',
  `observacao` text NOT NULL,
  `data` int(11) NOT NULL default '0',
  `data_alt` int(11) NOT NULL default '0',
  `aula` int(11) NOT NULL default '0',
  `pagina` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=54 ;

#
# Extraindo dados da tabela `aps_conteudo`
#

INSERT INTO `aps_conteudo` VALUES (1, 'No��es Fundamentais', 1, 1, 'O que � Qu�mica\r\nMat�ria\r\nEstados de Agrega��o da Mat�ria\r\nSubst�ncia\r\n�tomo', 1078491275, 1078510848, 1, 2);
INSERT INTO `aps_conteudo` VALUES (2, 'Eletrosfera', 1, 1, 'Distribui��o eletr�nica\r\nCamada de Val�ncia', 1078491275, 1078510862, 2, 6);
INSERT INTO `aps_conteudo` VALUES (3, 'Estudo de Tri�ngulos', 1, 3, 'Classifica��o de Tri�ngulos\r\nTeorema de Pit�goras\r\nRaz�es Trigonom�tricas\r\nSemelhan�a de Tri�ngulos', 1078505186, 1078510960, 1, 2);
INSERT INTO `aps_conteudo` VALUES (4, 'Classifica��o Peri�dica', 1, 1, '- Lei Peri�dica Moderna\r\n- Classifica��o Peri�dica Moderna', 1078509527, 1078510883, 3, 9);
INSERT INTO `aps_conteudo` VALUES (6, 'Liga��es Qu�micas', 1, 1, 'Teoria do Octeto/Dueto\r\nLiga��o I�nica\r\nLiga��o Covalente', 1078510236, 1078510910, 4, 13);
INSERT INTO `aps_conteudo` VALUES (7, 'Fen�menos e Rea��es', 1, 1, 'Fen�menos\r\nRea��es Qu�micas\r\nBalanceamento', 1078510283, 1078510926, 5, 15);
INSERT INTO `aps_conteudo` VALUES (8, 'Fun��es Minerais - Nox e �cidos', 1, 1, 'Nox\r\nFun��es - �cidos', 1078510314, 1078510941, 6, 18);
INSERT INTO `aps_conteudo` VALUES (9, 'Grandezas F�sicas e Vetores', 1, 3, 'Grandezas F�sicas\r\nGrandezas Escalares\r\nGrandezas Vetoriais\r\nVetor\r\nRegra do Paralelogramo', 1078510433, 1078510968, 2, 6);
INSERT INTO `aps_conteudo` VALUES (10, 'Opera��es com Vetores', 1, 3, 'Regra do Pol�gono\r\nSubtra��o de Vetores\r\nProduto de um n�mero real por um Vetor', 1078510476, 1078510980, 3, 11);
INSERT INTO `aps_conteudo` VALUES (11, 'Nota��o Cient�fica e Ordem de Grandeza', 1, 3, '', 1078510503, 1078510988, 4, 15);
INSERT INTO `aps_conteudo` VALUES (12, 'Algarismos Significativos', 1, 3, 'Medi��o\r\nAlgarismo Correto e algarismo duvidoso\r\nOpera��es com algarismos significativos', 1078511091, 0, 5, 17);
INSERT INTO `aps_conteudo` VALUES (13, 'Sistema Internacional de Unidades', 1, 3, 'Grandezas F�sicas Fundamentais\r\nGrandezas F�sicas Derivadas', 1078511161, 1078513873, 6, 20);
INSERT INTO `aps_conteudo` VALUES (14, 'N�meros Naturais', 1, 2, 'Decomposi��o de um n�mero natural\r\nM�ltiplos de um n�mero natural\r\nM�nimo m�ltiplo comum - mmc\r\nDivisores de um n�mero natural\r\nCrit�rios de divisibilidade\r\nM�ximo divisor comum - mdc', 1078511235, 0, 1, 2);
INSERT INTO `aps_conteudo` VALUES (15, 'N�meros Inteiros', 1, 2, 'N�meros Opostos\r\nM�dulo ou valor absoluto\r\nOpera��es elementares com inteiros\r\nMultiplica��o e Divis�o\r\nPotencia��o\r\nRaiz aritm�tica ou raiz quadrada\r\nC�lculo de uma express�o num�rica', 1078511309, 0, 2, 5);
INSERT INTO `aps_conteudo` VALUES (16, 'Fra��es Ordin�rias', 1, 2, 'Classifica��o de Fra��es\r\nSimplifica��o de Fra��es\r\nN�mero Misto\r\nAdi��o e Subtra��o de Fra��es\r\nMultiplica��o de Fra��es\r\nDivis�o de Fra��es', 1078511366, 0, 3, 8);
INSERT INTO `aps_conteudo` VALUES (17, 'N�meros Decimais', 1, 2, 'Fra��o Decimal\r\nOpera��es com n�meros decimais\r\n', 1078511430, 0, 4, 12);
INSERT INTO `aps_conteudo` VALUES (18, 'N�meros Racionais', 1, 2, 'Caracter�sticas dos n�meros racionais\r\nOpera��es b�sicas com n�meros racionais\r\nPot�ncias de n�meros racionais\r\nRaiz quadrada de n�meros racionais', 1078511490, 0, 5, 16);
INSERT INTO `aps_conteudo` VALUES (19, 'N�meros Irracionais', 1, 2, 'Raiz n-�sima\r\nRedu��o de radicais ao mesmo �ndice\r\nPropriedades dos radicais\r\nRacionaliza��o de denominadores', 1078511539, 0, 6, 19);
INSERT INTO `aps_conteudo` VALUES (20, 'C�lculo Literal', 1, 2, 'Express�es Alg�bricas\r\nNomenclatura das Express�es Alg�bricas\r\nClassifica��o das Express�es Alg�bricas\r\nGrau de uma Express�o Alg�brica\r\nAdi��o e Subtra��o de Express�es Alg�bricas\r\nMultiplica��o de Express�es Alg�bricas\r\nProdutos Not�veis\r\nDivis�o de express�es alg�bricas por mon�mios', 1078511651, 0, 7, 23);
INSERT INTO `aps_conteudo` VALUES (21, 'Fatora��o e Fra��es Alg�bricas', 1, 2, 'Fatora��o\r\nColoca��o de um fato comum em evid�ncia\r\nFatora��o por produtos not�veis\r\nFra��es alg�bricas\r\nM�nimo m�ltiplo comum de express�es alg�bricas - mmc', 1078511718, 0, 8, 29);
INSERT INTO `aps_conteudo` VALUES (22, 'Igualdade Alg�brica', 1, 2, 'Identidade Alg�brica\r\nEqua��o Alg�brica\r\nResolu��o de uma equa��o de 1� grau, com uma inc�gnita\r\nResolu��o de uma equa��o de 1� grau, com duas inc�gnitas\r\nM�todo da Substitui��o\r\nM�todo da Adi��o', 1078511863, 1078513843, 9, 32);
INSERT INTO `aps_conteudo` VALUES (23, 'Equa��es do 2� grau e Irracionais', 1, 2, 'Equa��o do 2� Grau\r\nTipos de equa��o do 2� Grau\r\nEqua��o Biquadrada\r\nEqua��es Irracionais', 1078512692, 0, 10, 36);
INSERT INTO `aps_conteudo` VALUES (24, 'Fun��es Minerais - Bases e Sais', 1, 1, '', 1078540667, 0, 7, 21);
INSERT INTO `aps_conteudo` VALUES (25, 'Rela��es de Massa', 1, 1, 'Unidade de massa at�mica (u)\r\nMassa at�mica (MA)\r\nMassa molecular (MM)\r\nConstante de Avogadro\r\nMassa Molar (M)\r\nVolume Molar\r\nN�mero de Mols', 1078540731, 0, 8, 23);
INSERT INTO `aps_conteudo` VALUES (26, 'An�lise Dimensional', 1, 3, 'S�mbolos Dimensionais\r\nEqua��es ou f�rmulas dimensionais\r\nAn�lise dimensional', 1078540788, 0, 7, 22);
INSERT INTO `aps_conteudo` VALUES (27, 'Fun��o do 1� Grau e Proporcionalidade', 1, 3, 'Tabela e Gr�fico\r\nFun��o do 1� Grau\r\nGrandezas Diretamente Proporcionais\r\nGrandezas Inversamente Proporcionais', 1078540850, 0, 8, 24);
INSERT INTO `aps_conteudo` VALUES (28, 'Regra de Tr�s', 1, 2, 'Grandezas Diretamente Proporcionais\r\nGrandezas Inversamente Proporcionais', 1078540887, 0, 11, 40);
INSERT INTO `aps_conteudo` VALUES (29, 'Porcentagem', 1, 2, 'Porcentagem de um n�mero em rela��o a outro\r\nResolu��o de problemas envolvendo Porcentagem', 1078540932, 0, 12, 42);
INSERT INTO `aps_conteudo` VALUES (30, 'Composi��o Qu�mica da Mat�ria Viva', 2, 4, '�gua\r\nSais Minerais\r\nGlic�dios\r\nLip�dios', 1078837662, 0, 1, 2);
INSERT INTO `aps_conteudo` VALUES (31, 'Classifica��o Biol�gica', 2, 6, 'Categorias Taxon�micas\r\nSistema binominal de classifica��o\r\nRegras internacionais de nomenclatura\r\nClassifica��o dos Seres Vivos em Reinos', 1078838152, 0, 1, 2);
INSERT INTO `aps_conteudo` VALUES (32, 'Reprodu��o', 2, 7, 'Tipos de Reprodu��o\r\nCaracter�sticas Gerais da Reprodu��o Sexuada', 1078838200, 0, 1, 2);
INSERT INTO `aps_conteudo` VALUES (33, 'Rela��es Bin�rias', 2, 8, 'Par ordenado\r\nRela��o bin�ria', 1078838290, 0, 1, 2);
INSERT INTO `aps_conteudo` VALUES (34, 'Literatura', 2, 12, 'Introdu��o\r\nG�neros Liter�rios\r\nG�nero l�rico\r\nG�nero �pico\r\nG�nero dram�tico\r\nG�nero narrativo', 1079019724, 0, 1, 2);
INSERT INTO `aps_conteudo` VALUES (35, 'For�a', 2, 13, 'Introdu��o\r\nFor�a\r\nFor�a El�stica (Lei de Hooke)\r\nFor�a resultante', 1079019799, 0, 1, 2);
INSERT INTO `aps_conteudo` VALUES (36, 'Conjuntos', 2, 9, 'Conjunto, elemento e pertin�ncia\r\nRepresenta��o de conjuntos\r\nConjuntos finitos e infinitos\r\nConjuntos num�ricos\r\nSubconjuntos', 1079019874, 0, 1, 2);
INSERT INTO `aps_conteudo` VALUES (37, 'Conjuntos II', 2, 9, 'Opera��es com Conjuntos\r\nComplementar de um conjunto\r\nIntervalos', 1079019925, 0, 2, 5);
INSERT INTO `aps_conteudo` VALUES (38, 'Fonologia', 2, 18, 'Fonemas e Letras\r\nClassifica��o dos fonemas', 1079019992, 0, 1, 2);
INSERT INTO `aps_conteudo` VALUES (39, 'Pr�-Hist�ria e Mesopot�mia', 2, 19, 'Pr�-Hist�ria\r\nPaleol�tico ou Idade da Pedra Lascada (500.000 - 10.000 a.C.)\r\nNeol�tico ou Idade da Pedra Polida (10000-5000 a.C.)\r\nIdade dos Metais (5000-4000 a.C.)\r\nMesopot�mia\r\nSum�rios e ac�dios (2800-2000 a.C.)\r\nPrimeiro Imp�rio Babil�nico (2000-1700 a.C.)\r\nImp�rio Ass�rio (1700-612 a.C.)\r\nSegundo Imp�rio Babil�nico (621-539 a.C.)', 1079020167, 0, 1, 2);
INSERT INTO `aps_conteudo` VALUES (40, 'Gr�cia', 2, 20, 'Civiliza��o Grega\r\nPer�odo Pr�-Hom�rico (s�c. XX a XII a.C.)\r\nPer�odo Hom�rico (s�c. XII a VIII a.C.)', 1079020247, 1079104743, 1, 2);
INSERT INTO `aps_conteudo` VALUES (41, 'Gr�cia II', 2, 20, 'Per�odo Arcaico (s�culos VIII a V a.C.)\r\nEsparta\r\nAtenas', 1079020290, 1079104737, 2, 8);
INSERT INTO `aps_conteudo` VALUES (42, 'Introdu��o � Geografia - Universo', 2, 21, 'Geografia\r\nPrinc�pios\r\nDivis�o\r\nGeografia F�sica\r\nGeografia Humana\r\nEscolas ou concep��es geogr�ficas\r\nUniverso\r\nGal�xias\r\nEstrelas\r\nConstela��es\r\nNebulosas', 1079020411, 0, 1, 2);
INSERT INTO `aps_coanteudo` VALUES (43, 'Geografia Humana', 2, 22, 'Evolu��o da popula��o mundial\r\nTeorias sobre o crescimento populacional\r\nPopula��o absoluta e popula��o relativa\r\nO que � um pa�s superpovoado?\r\nDistribui��o da Popula��o', 1079020514, 1079020531, 1, 2);
INSERT INTO `aps_conteudo` VALUES (44, 'Introdu��o � Eletrodin�mica', 2, 15, 'Carga El�trica\r\nCorrente El�trica\r\nResist�ncia El�trica', 1079103887, 0, 1, 2);
INSERT INTO `aps_conteudo` VALUES (45, 'Cinem�tica', 2, 14, 'Introdu��o\r\nCinem�tica\r\nPonto Material\r\nReferencial e movimento\r\nTrajet�ria\r\nPosi��o\r\nDeslocamento\r\nVelocidade M�dia\r\nVelocidade Instant�nea', 1079104009, 0, 1, 2);
INSERT INTO `aps_conteudo` VALUES (46, 'Mat�ria', 2, 24, 'Qu�mica\r\nMat�ria\r\nCorpo\r\nSubst�ncia\r\nPropriedades da Mat�ria', 1079104101, 0, 1, 2);
INSERT INTO `aps_conteudo` VALUES (47, '�tomo', 2, 23, 'Estrutura at�mica b�sica\r\nElemento qu�mico', 1079104133, 0, 1, 2);
INSERT INTO `aps_conteudo` VALUES (48, 'Pronouns', 2, 27, 'Personal pronouns\r\nReflexive pronouns', 1079104191, 0, 1, 2);
INSERT INTO `aps_conteudo` VALUES (49, 'Introdu��o � �ptica', 2, 16, 'Divis�o da �ptica\r\nLuz\r\nFontes de Luz\r\nPrinc�pios da �ptica\r\nC�mara escura de orif�cio', 1079215287, 0, 1, 2);
INSERT INTO `aps_conteudo` VALUES (50, 'F�rmulas', 2, 25, 'F�rmula Percentual\r\nF�rmula M�nima ou Emp�rica\r\nF�rmula Molecular', 1079215346, 0, 1, 2);
INSERT INTO `aps_conteudo` VALUES (51, 'Qu�mica Org�nica - Carbono', 2, 26, 'Hist�rico da Qu�mica Org�nica\r\nDiferen�as entre compostos qu�micos e minerais\r\nCarbono (propriedades, classifica��o, etc)', 1079215515, 0, 1, 2);
INSERT INTO `aps_conteudo` VALUES (52, 'Geometria Plana', 2, 10, '�ngulos\r\nBissetriz de um �ngulo\r\n�ngulos complementares e suplementares\r\n�ngulos formados por duas retas paralelas cortadas por uma transversal', 1079215637, 0, 1, 2);
INSERT INTO `aps_conteudo` VALUES (53, 'Trigonometria', 2, 11, 'Trigonometria no tri�ngulo ret�ngulo\r\nRaz�es trigonom�tricas no tri�ngulo ret�ngulo\r\nTabelas de valores dos �ngulos not�veis', 1079215719, 0, 2, 6);

# --------------------------------------------------------

#
# Estrutura da tabela `aps_materias`
#

DROP TABLE IF EXISTS `aps_materias`;
CREATE TABLE `aps_materias` (
  `id` int(11) NOT NULL auto_increment,
  `nome` varchar(255) NOT NULL default '',
  `data` int(11) NOT NULL default '0',
  `data_alt` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=28 ;

#
# Extraindo dados da tabela `aps_materias`
#

INSERT INTO `aps_materias` VALUES (1, 'Qu�mica', 1078491174, 0);
INSERT INTO `aps_materias` VALUES (2, 'Matem�tica', 1078491174, 0);
INSERT INTO `aps_materias` VALUES (3, 'F�sica', 1078491174, 0);
INSERT INTO `aps_materias` VALUES (4, 'Biologia A', 1078837594, 0);
INSERT INTO `aps_materias` VALUES (5, 'Biologia B', 1078837601, 0);
INSERT INTO `aps_materias` VALUES (6, 'Biologia C', 1078837607, 0);
INSERT INTO `aps_materias` VALUES (7, 'Biologia D', 1078837613, 0);
INSERT INTO `aps_materias` VALUES (8, 'Matem�tica A', 1078838242, 0);
INSERT INTO `aps_materias` VALUES (9, 'Matem�tica B', 1078838248, 0);
INSERT INTO `aps_materias` VALUES (10, 'Matem�tica C', 1078838253, 0);
INSERT INTO `aps_materias` VALUES (11, 'Matem�tica D', 1078838258, 0);
INSERT INTO `aps_materias` VALUES (12, 'Literatura', 1079019652, 0);
INSERT INTO `aps_materias` VALUES (13, 'F�sica A', 1079019743, 0);
INSERT INTO `aps_materias` VALUES (14, 'F�sica B', 1079019750, 0);
INSERT INTO `aps_materias` VALUES (15, 'F�sica C', 1079019756, 0);
INSERT INTO `aps_materias` VALUES (16, 'F�sica D', 1079019761, 0);
INSERT INTO `aps_materias` VALUES (17, 'Portugu�s A', 1079019949, 0);
INSERT INTO `aps_materias` VALUES (18, 'Portugu�s B', 1079019955, 0);
INSERT INTO `aps_materias` VALUES (19, 'Hist�ria A', 1079020027, 0);
INSERT INTO `aps_materias` VALUES (20, 'Hist�ria B', 1079020032, 0);
INSERT INTO `aps_materias` VALUES (21, 'Geografia A', 1079020299, 0);
INSERT INTO `aps_materias` VALUES (22, 'Geografia B', 1079020305, 0);
INSERT INTO `aps_materias` VALUES (23, 'Qu�mica A', 1079104048, 0);
INSERT INTO `aps_amaterias` VALUES (24, 'Qu�mica B', 1079104053, 0);
INSERT INTO `aps_materias` VALUES (25, 'Qu�mica C', 1079104057, 0);
INSERT INTO `aps_materias` VALUES (26, 'Qu�mica D', 1079104061, 0);
INSERT INTO `aps_materias` VALUES (27, 'Ingl�s', 1079104145, 0);
