<?php
// Conecta com o banco de dados
mysql_connect("localhost", "root", "root");
mysql_select_db("test");

// Importa a classe
require "../src/class.leitor_sql.php";

// Cria a classe e executa o arquivo SQL
$tp = new leitor_sql("apostilas.sql");

// Executa outro arquivo SQL
$tp->leitor_sql("outro.sql")
?>