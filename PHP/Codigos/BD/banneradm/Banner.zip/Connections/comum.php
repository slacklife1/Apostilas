<?php
// modifique este arquivo para a conex�o do banco de dados

# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname = "yxyxyxyx";     //nome do servidor
$database = "xyxyxyxy";         //banco de dados
$username = "xyxyxyxy";         //nome de usu�rio
$password = "xyxyxyxy";          //sua senha
$dbcon = mysql_pconnect($hostname, $username, $password) or die(mysql_error());
$tabela = "xyxyxyxy";           //aqui  vai o nome da sua tabela
?>