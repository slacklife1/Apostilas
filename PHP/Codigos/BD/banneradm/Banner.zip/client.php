<?php require_once('Connections/comum.php'); ?>
<?php
mysql_select_db($database, $dbcon);
$query_lista = "SELECT * FROM $tabela WHERE cliente = '$cliente'";
$lista = mysql_query($query_lista, $dbcon) or die(mysql_error());
$row_lista = mysql_fetch_assoc($lista);
$totalRows_lista = mysql_num_rows($lista);
?>

<html>
<head>
<title>:::Clientes</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td bgcolor="#990000"><h1>::Banner</h1></td>
  </tr>
</table>
<p>&nbsp;</p>
<form name="form1" method="post" action="client.php">
  <div align="center"><strong><font color="#990000" face="Verdana, Arial, Helvetica, sans-serif">C&oacute;digo
    de Cliente</font></strong>
    <input name="cliente" type="text" id="cliente">
    <input type="submit" name="Submit" value="Enviar">
  </div>
</form>
<?php if ($totalRows_lista > 0) { // Show if recordset not empty ?>
<p align="right"><font size="2" face="Geneva, Arial, Helvetica, sans-serif"><strong>Cliente:
  &nbsp;<?php echo $row_lista['cliente']; ?> - URL: <a href="<?php echo $row_lista['url']; ?>"><?php echo $row_lista['url']; ?></a></strong></font></p>
<table width="60%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
  <tr bordercolor="1">
    <td width="24%" bgcolor="#990000"><strong><font color="#FFFFFF" size="2" face="Geneva, Arial, Helvetica, sans-serif">Plano</font></strong></td>
    <td width="27%" bgcolor="#CCCCCC"> <div align="center"><font size="3" face="Geneva, Arial, Helvetica, sans-serif"><strong><?php echo $row_lista['zone']; ?></strong></font></div></td>
    <td width="49%" bgcolor="#CCCCCC"><div align="center"><font size="3" face="Geneva, Arial, Helvetica, sans-serif"><strong>Quantidade
        = <?php echo $row_lista['quant']; ?></strong></font></div></td>
  </tr>
  <tr bordercolor="1">
    <td bgcolor="#990000"><strong><font color="#FFFFFF" size="2" face="Geneva, Arial, Helvetica, sans-serif">Views</font></strong></td>
    <td colspan="2"><div align="center"><font size="3" face="Geneva, Arial, Helvetica, sans-serif"><strong><?php echo $row_lista['displays_life']; ?></strong></font></div></td>
  </tr>
  <tr bordercolor="1">
    <td bgcolor="#990000"><strong><font color="#FFFFFF" size="2" face="Geneva, Arial, Helvetica, sans-serif">Cliques</font></strong></td>
    <td colspan="2" bgcolor="#CCCCCC"> <div align="center"><font size="3" face="Geneva, Arial, Helvetica, sans-serif"><strong><?php echo $row_lista['clicks_life']; ?></strong></font></div></td>
  </tr>
  <tr bordercolor="1">
    <td bgcolor="#990000"><strong><font color="#FFFFFF" size="2" face="Geneva, Arial, Helvetica, sans-serif">V</font><font color="#FFFFFF" size="2" face="Geneva, Arial, Helvetica, sans-serif">iews
      Hoje</font></strong></td>
    <td colspan="2"><div align="center"><font size="3" face="Geneva, Arial, Helvetica, sans-serif"><strong><?php echo $row_lista['displays_day']; ?></strong></font></div></td>
  </tr>
  <tr bordercolor="1">
    <td bgcolor="#990000"><strong><font color="#FFFFFF" size="2" face="Geneva, Arial, Helvetica, sans-serif">Cliques
      Hoje</font></strong></td>
    <td colspan="2" bgcolor="#CCCCCC"> <div align="center"><font size="3" face="Geneva, Arial, Helvetica, sans-serif"><strong><?php echo $row_lista['clicks_day']; ?></strong></font></div></td>
  </tr>
  <tr bordercolor="1">
    <td valign="top" bgcolor="#990000"><strong><font color="#FFFFFF" size="2" face="Geneva, Arial, Helvetica, sans-serif">Banner</font></strong></td>
    <td colspan="2"><div align="center"><font size="2" face="Geneva, Arial, Helvetica, sans-serif"><?php echo $row_lista['image_url']; ?><?php echo $row_lista['html']; ?></font></div></td>
  </tr>
</table>
<?php } // Show if recordset not empty ?>
<p></p>
</body>
</html>
<?php
mysql_free_result($lista);
?>

