Banner Administrator v 1.0


Changelog

Incluidos nesta vers�o:

+Administra��o de clientes
+Gerenciamento de multiplos tamanhos de banner
+Upload de arquivos por http
+Corre��o de algumas rotinas
+painel de controle para clientes

==Aguarde novas Vers�es==Me ajude a melhorar este script

webmaster@webtuba.com.br

==========================================================
Instala��o:

Abra /banner/banner_inc.php e modifique corretamente as vari�veis indicadas.
Abra /Conections/comum.php e modifique corretamente as vari�veis indicadas.
Abra /banner/envia.php e modifique corretamente as vari�veis indicadas.

Envie todos os arquivos para o diret�rio "banner" e abra o arquivo banner_install.php. Clique em "Clique aqui para instalar o ICQuente Banner V1.0" para inst�la-lo. Se voc� receber uma mensagem de congratula��o,
delete o banner_install.php do seu servidor e abra o banner_admin.php para editar o seu sistema de banners.

N�o se esque�a de atribuir as op��es 777 na pasta para o upload dos arquivos

� s� isso. Se aparecer mensagem de erro, voc� ter� que trabalhar


o arquivo dos banners Full � banner2.php
o arquivo dos banners Half � banner.php


Para inclu�-lo em arquivos .html .htm .shtml .asp use:
<!--#include virtual="/banner/banner.php"-->
Mude o path do banner.php dependendo do diret�rio em seu servidor.

Para inclu�-lo em outro arquivo PHP:
<? include "/banner/banner.php" ?>

a p�gina de administra��o dos clientes � a client.php

para acessar � s� entrar pelo seu navegador pelo 

http://seuendere�o/banner/index.php


Atenciosamente


Michel Souza - 2002

