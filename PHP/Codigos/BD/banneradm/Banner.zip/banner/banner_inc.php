<?php

//Banner Administrator V 1.0
//Por -  Michel Souza
//webmaster@webtuba.com.br

//desenvolvido � partir do:

//ICQuente Banner V1.0 - Script Freeware

 //Nome do Host. Normalmente � localhost".
$hostname = "XYXYXYX";

 //Localiza��o do banner_click.php no servidor
$redirect = "XYXYXYXY";

 //Nome do Banco de Dados
$dbName = "XYXYXYX";

 //Nome do usu�rio do MySQL
$username = "XYXYXYX"; #Nome de usu�rio do MySQL (N�o se preocupe, n�o ir� aparecer na p�gina)

 //Senha de conex�o ao MySQL
$password = "XYXYXYX"; #Senha de usu�rio do MySQL (N�o se preocupe, n�o ir� aparecer na p�gina)

 //Nome da tabela do MySQL
$table = "XYXYXYXY"; #Nesta tabela ser�o inclusos os dados.

 //Senha Administrativa
$admin_pass = "hehehe"; #A senha pode ser alterada de sua prefer�ncia ou n�o

 //N�o precisa mudar depois dessa linha!
 ##################################
 //Cabe�alho e Copyright

 function head() {
 print "
 <html>

 <head>
 <title>Banner Administrator v 1.0.1 - GNU</title>
 <style>
 <!--
 textarea     { font-family: Tahoma,verdana; font-size: 8pt; padding: 3 }
 input        { font-family: Tahoma,verdana; font-size: 8pt;  }
 select        { font-family: Tahoma,verdana; font-size: 8pt; }
 a {text-decoration: none}
 A:hover {color: #00FFFF; text-decoration: underline}
 -->
 </style>
 </head>

 <body bgcolor=#999999 text=#000000 link=#00CCFF vlink=#00CCFF alink=#00FFFF style=font-family: Verdana;>
<font face=Arial size=2> ";
}

function foot() {
print "<center>Webtuba Design Studio</center>";
 }

 //Bad Password
 function bad_pass() {
 head();
 print "Erro, Senha inv�lida";
 foot();
 exit();
 }

?>