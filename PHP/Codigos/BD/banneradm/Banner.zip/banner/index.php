<html>
<head>
<title>Banners SP</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css"> <!-- A:link {color:#FFFFFF; text-decoration: none} A:visited {color:#FFFFFF} A:hover {color:#FF0000} A:active {color:#FFFF00} --> </style>
</head>

<body bgcolor="#CCCCCC">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td bgcolor="#990000"><h1>::Banner</h1></td>
  </tr>
  <tr>
    <td><font size="2" face="Geneva, Arial, Helvetica, sans-serif">&nbsp;</font></td>
  </tr>
  <tr>
    <td bgcolor="#000000"><div align="right"><font color="#FFFFFF" size="2" face="Geneva, Arial, Helvetica, sans-serif">::Menu:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::<a href="banner_admin.php" target="_blank">Administrar
        Banners</a>::</font></div></td>
  </tr>
</table>
<p>&nbsp;</p><table width="80%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="20">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><ul>
        <li><strong><font face="Verdana, Arial, Helvetica, sans-serif">Enviar
          Novo Banner</font></strong></li>
      </ul></td>
    <td><form action="envia.php" method="post" enctype="multipart/form-data" name="form1" target="_blank">
        <input name="file" type="file" size="30">
        <input type="submit" name="Submit" value="Enviar">
      </form></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Os
        Banners enviados devem ser *.jpg, *.gif ou *.swf</font></div></td>
  </tr>
</table>
<p>&nbsp;</p><p>&nbsp;</p>
</body>
</html>