<html>
<head>
<title>Confirma&ccedil;&atilde;o</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#CCCCCC" text="#990000">
<center>
<?php
//envia o arquivo

if (!empty($file) and is_file($file)) {
$caminho="/home/seusite/www/banner/";    //coloque aqui o caminho exato da pasta no seu servidor
$caminho=$caminho.$file_name;
copy($file,$caminho);
exec ("chmod 777 $file");
# grava o $arquivo no $caminho especificado
echo "<h2>O seu Arquivo foi transferido!</h2>";
}else{
echo "<h3>O Arquivo n�o foi transferido!</h3>";
}
?>
</center>
</body>
</html>