<?php

//Banner Administrator V 1.0
//Por -  Michel Souza
//webmaster@webtuba.com.br

//desenvolvido � partir do:

//ICQuente Banner V1.0 - Script Freeware
//By: Diego Designer - diegodesigner@icquente.com
//http://www.icquente.com/diegodesigner
//Este � um script gratuito, n�o me responsabilizo por danos causados em seu servidor.
//Este script pode ser modificado, desde que se mantenha a Copyright.

//Include file - S� mexa aqui se voc� mudou o nome e/ou diret�rio do arquivo
require "banner_inc.php";

//N�o precisa editar ap�s essa linha//

  /*Declarando vari�veis*/
$pagename = "$PHP_SELF"; #This Page's Name - Don't modify.
$req_id = $QUERY_STRING;

/* N�o mexa ap�s essa linha */
/* fazendo conex�o com banco de dados */
MYSQL_CONNECT($hostname, $username, $password) OR DIE("Unable to connect to database");
@mysql_select_db( "$dbName") or die( "Unable to select database");

//Pegando n� do banner no banco de dado
$query = "SELECT * FROM $table WHERE id = '$req_id'";
$result = MYSQL_QUERY($query);
$number = MYSQL_NUMROWS($result);

 if($number > 1):
 print "Algo errado... id de multiplos!";
 endif;

$url                = mysql_result($result,$randomnumber,"url");
$clicks_life        = mysql_result($result,$randomnumber,"clicks_life");
$clicks_day        = mysql_result($result,$randomnumber,"clicks_day");

header("Location: $url");

 //Gravando click.
++$clicks_life;
++$clicks_day;

 //Atualizando Banco de dados
$update_query = "UPDATE $table SET clicks_life = '$clicks_life' WHERE id = '$req_id'";
$update_result = MYSQL_QUERY($update_query);
$update_query = "UPDATE $table SET clicks_day = '$clicks_day' WHERE id = '$req_id'";
$update_result = MYSQL_QUERY($update_query);

MYSQL_CLOSE();
?>