<?php

//Banner Administrator V 1.0
//Por -  Michel Souza
//webmaster@webtuba.com.br

//desenvolvido � partir do:

//ICQuente Banner V1.0 - Script Freeware
//By: Diego Designer - diegodesigner@icquente.com
//http://www.icquente.com/diegodesigner
//Este � um script gratuito, n�o me responsabilizo por danos causados em seu servidor.
//Este script pode ser modificado, desde que se mantenha a Copyright.

//Include file - S� mexa aqui se voc� mudou o nome e/ou diret�rio do arquivo
require "banner_inc.php";

//N�o precisa editar ap�s essa linha//

  /*Declarando vari�veis*/
$pagename = "$PHP_SELF"; #This Page's Name - Don't modify.

/* N�o mexa ap�s essa linha! */
/* fazendo conex�o com o banco de dados */
MYSQL_CONNECT($hostname, $username, $password) OR DIE("Unable to connect to database");
@mysql_select_db( "$dbName") or die( "Unable to select database");

//selecionando a categoria
$cat = "Half";
//Pegando n� do banner no banco de dados
$query = "SELECT * FROM $table WHERE zone = '$cat'";
$result = MYSQL_QUERY($query);
$number = MYSQL_NUMROWS($result);

//Pegando um n�mero autom�tico
  //N� SQL inicia no 0
  if($number == 0):
  print "No Images to display";
  exit();
  elseif($number == 1):
  $randomnumber = 0;
  else:
  --$number;
  srand((double)microtime()*1000000);
  $randomnumber = rand(0,$number);
  endif;

//Pegando detalhes para inserir no banco de dados
$redir = "/banner/banner_click.php";
$id                = mysql_result($result,$randomnumber,"id");
$image_url        = mysql_result($result,$randomnumber,"image_url");
$url                = mysql_result($result,$randomnumber,"url");
$zone                = mysql_result($result,$randomnumber,"zone");
$displays_life        = mysql_result($result,$randomnumber,"displays_life");
$displays_day        = mysql_result($result,$randomnumber,"displays_day");
$dat_type        = mysql_result($result,$randomnumber,"dat_type");
$html                = mysql_result($result,$randomnumber,"html");

 //Criando Script HTML

if($dat_type == 'image'):
print "<a href=\"$redir?$id\"><img src=\"$image_url\" border=\"0\"></a>";
 elseif($dat_type == 'html'):
 print "$html";
else:
 print "<a href=\"$redir?$id\"><img src=\"$image_url\" border=\"0\"></a>";
endif;
 print "<!-- Fim do script -->";

 //Gravando Click.
++$displays_life;
++$displays_day;


 //Atualizando Banco de dados
$update_query = "UPDATE $table SET displays_life = '$displays_life' WHERE id = '$id'";
$update_result = MYSQL_QUERY($update_query);
$update_query = "UPDATE $table SET displays_day = '$displays_day' WHERE id = '$id'";
$update_result = MYSQL_QUERY($update_query);

MYSQL_CLOSE();
?>