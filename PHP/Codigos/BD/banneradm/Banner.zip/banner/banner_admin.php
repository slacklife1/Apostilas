<?php

//Banner Administrator V 1.0
//Por -  Michel Souza
//webmaster@webtuba.com.br

//desenvolvido � partir do:

//ICQuente Banner V1.0 - Script Freeware
//By: Diego Designer - diegodesigner@icquente.com
//http://www.icquente.com/diegodesigner
//Este � um script gratuito, n�o me responsabilizo por danos causados em seu servidor.
//Este script pode ser modificado, desde que se mantenha a Copyright.

//Include file - S� mexa aqui se voc� mudou o nome e/ou diret�rio do arquivo
require "banner_inc.php";

//N�o precisa editar ap�s essa linha//

  /*Declarando Vari�veis*/
$pagename = $PHP_SELF; #Este � o nome da p�gina - n�o modifique.
$qstring=split("&", $QUERY_STRING);
$action=$qstring[0];
$ad_id=$qstring[1];

/* N�o modifique depois dessa linha! */
/* Fazendo conex�o com o banco de dados */
MYSQL_CONNECT($hostname, $username, $password) OR DIE("Unable to connect to database");
@mysql_select_db("$dbName") or die("Unable to select database");

if($action == add):

head();
?>

        <b>Adicionar Banner (Standard)</b>
        <form action="<? echo $pagename ?>?do_add" method=POST>
        Local do Banner:<br><input type="text" name="image" size="60"><br>
        Link:<br><input type="text" name="link" size="60"><br>
        Tipo:<br><select name="zone">
        <option selected>Half</option>
        <option>Full</option>
        </select><br>
        Quantidade:<br><input type=text size=15 name=qt><br>
        Cliente:<br><input type="text" name="cliente"><br>
        Senha:<br><input type="password" name="admin_password"><br>
        <input type="hidden" name="dat_type" value="image">
        <input type="submit" value="Adicionar Banner">
        </form>
        <br>
        OU<br><br>
        <b>Inserir c�digo HTML para adicionar banner</b><br>
        <form action="<? echo $pagename ?>?do_add" method=POST>
        <textarea name="html_input" rows="10" cols="80">
        <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="468" height="60">
            <param name="movie" value="Nome_do_Banner.swf">
            <param name="quality" value="high">
            <embed src="Nome_do_Banner.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="468" height="60"></embed></object>
        </textarea><br>
        Link:<br><input type="text" name="link" size="60"><br>
        Tipo:<br><select name="zone">
        <option selected>Half</option>
        <option>Full</option>
        </select>
        <br>
        Quantidade:<br><input type=text size=15 name=qt><br>
        Cliente:<br><input type="text" name="cliente"><br>
        Senha:<br><input type="password" name="admin_password"><br>
        <input type="hidden" name="dat_type" value="html">
        <input type="submit" value="Adicionar Banner">
        </form>

<?php
foot();

elseif($action == do_add):
 //Check the Password
  if($admin_password != $admin_pass):
  bad_pass();
  endif;

  head();

  if($dat_type == 'image'):
     $query = "INSERT INTO $table (zone,url,image_url,dat_type,quant,cliente) VALUES ('$zone', '$link', '$image', '$dat_type','$qt','$cliente')";
     $result = MYSQL_QUERY($query);
  print "Banner Adicionado com sucesso";
  elseif($dat_type == 'html'):
     $query = "INSERT INTO $table (zone, url, html, dat_type,quant,cliente) VALUES ('$zone', '$link', '$html_input', '$dat_type','$qt','$cliente')";
     $result = MYSQL_QUERY($query);
  print "Banner Adicionado com sucesso";
  else:
  print "Erro, senha inv�lida";
  endif;
  foot();

elseif($action == modify):
head();

//Pegando n� do banner no banco de dados
$query = "SELECT * FROM $table";
$result = MYSQL_QUERY($query);
$number = MYSQL_NUMROWS($result);
$i=0;

print "<center>(Clique em \"modificar\" para modificar o banner)<br>";

WHILE ($i < $number):

    //Pegando detalhes para incluir registros
    $id                = mysql_result($result,$i,"id");
    $image_url        = mysql_result($result,$i,"image_url");
    $url        = mysql_result($result,$i,"url");
    $dat_type        = mysql_result($result,$i,"dat_type");
    $html        = mysql_result($result,$i,"html");
    $quant        = mysql_result($result,$i,"quant");
    $cliente        = mysql_result($result,$i,"cliente");
    if($dat_type == 'image'):
    print "<img src=\"$image_url\" border=\"0\">\n<br><a href=\"$pagename?mod_id&$id\">Modificar</a><br>";
    elseif($dat_type == 'html'):
    print "$html<br><a href=\"$pagename?mod_id&$id\">Modificar</a><br>";
    else:
    print "<img src=\"$image_url\" border=\"0\">\n<br><a href=\"$pagename?mod_id&$id\">Modificar</a><br>";
    endif;

    $i++;
ENDWHILE;
print "</center>";
foot();

elseif($action == mod_id):
$query = "SELECT * FROM $table WHERE id = '$ad_id'";
$result = MYSQL_QUERY($query);

    //Pegando detalhes para incluir registros
    $id                = mysql_result($result,0,"id");
    $zone        = mysql_result($result,0,"zone");
    $image_url        = mysql_result($result,0,"image_url");
    $url        = mysql_result($result,0,"url");
    $dat_type        = mysql_result($result,0,"dat_type");
    $html        = mysql_result($result,0,"html");
    $quant        = mysql_result($result,$i,"quant");
     $cliente        = mysql_result($result,$i,"cliente");
head();
    if($dat_type == 'image'):
?>
<b>Modificar</b>
<form action="<? echo $pagename ?>?do_modify" method=POST>
Local do banner:<br><input type="text" name="image" size="60" value="<? echo $image_url ?>"><br>
Link:<br><input type="text" name="link" size="60" value="<? echo $url ?>"><br>
Tipo:<br><select name="zone">
        <option selected>Half</option>
        <option>Full</option>
        </select>
        <br>
Quantidade:<br><input type=text size=15 name=quant value="<? echo $quant ?>"><br>
Cliente:<input type="text" name="cliente"><br>
Senha:<br><input type="password" name="admin_password"><br>
<input type="hidden" name="dat_type" value="image">
<input type="hidden" name="mod_id" value="<? echo $id ?>">
<input type="submit" value="Modificar Banner">
</form>
<?php
    elseif($dat_type == 'html'):
?>
        <form action="<? echo $pagename ?>?do_add" method=POST>
        <textarea name="html_input" rows="10" cols="80"><? echo $html ?></textarea><br>
        Tipo:<br><select name="zone">
        <option selected>Half</option>
        <option>Full</option>
        </select>
        <br>
Quantidade:<br><input type=text size=15 name=quant value="<? echo $quant ?>"><br>
        Cliente:<input type="text" name="cliente"><br>
        Senha:<br><input type="password" name="admin_password"><br>
        <input type="hidden" name="mod_id" value="<? echo $id ?>">
        <input type="hidden" name="dat_type" value="html">
        <input type="submit" value="Adicionar Banner">
        </form>
<?php
    else:
?>
<form action="<? echo $pagename ?>?do_modify" method=POST>
Local do Banner:<br><input type="text" name="image" size="60" value="<? echo $image_url ?>"><br>
Link:<br><input type="text" name="link" size="60" value="<? echo $url ?>"><br>
Tipo (Opicional):<br><input type="text" name="zone" value="<? echo $zone ?>"><br>
Cliente:<input type="text" name="cliente"><br>
Senha:<br><input type="password" name="admin_password"><br>
<input type="hidden" name="dat_type" value="image">
<input type="hidden" name="mod_id" value="<? echo $id ?>">
<input type="submit" value="Modificar Banner">
</form>

<?php
endif;
foot();

elseif($action == do_modify):
 //Checando senha
  if($admin_password != $admin_pass):
  bad_pass();
  endif;

  if($dat_type == 'image'):
   $update_query = "UPDATE $table SET zone = '$zone' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);
   $update_query = "UPDATE $table SET image_url = '$image' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);
   $update_query = "UPDATE $table SET url = '$link' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);
   $update_query = "UPDATE $table SET url = '$cliente' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);
   $update_query = "UPDATE $table SET url = '$quant' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);

  elseif($dat_type == 'html'):
   $update_query = "UPDATE $table SET zone = '$zone' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);
   $update_query = "UPDATE $table SET html = '$html' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);
   $update_query = "UPDATE $table SET url = '$cliente' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);
   $update_query = "UPDATE $table SET url = '$quant' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);

  else:
   $update_query = "UPDATE $table SET zone = '$zone' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);
   $update_query = "UPDATE $table SET image_url = '$image' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);
   $update_query = "UPDATE $table SET url = '$link' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);
   $update_query = "UPDATE $table SET url = '$cliente' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);
   $update_query = "UPDATE $table SET url = '$quant' WHERE id = '$mod_id'";
   $update_result = MYSQL_QUERY($update_query);
  endif;

   head();
   print "Updated";
   foot();

elseif($action == delete):
head();

//Pegando n� do banner no banco de dados
$query = "SELECT * FROM $table";
$result = MYSQL_QUERY($query);
$number = MYSQL_NUMROWS($result);
$i=0;

print "<center>(Configurar banner para serem deletados)<br>";
print "<form action=\"$pagename?do_del\" method=POST>";

WHILE ($i < $number):

    //Get the details for that entry
    $id                = mysql_result($result,$i,"id");
    $image_url        = mysql_result($result,$i,"image_url");
    $url        = mysql_result($result,$i,"url");
    $dat_type        = mysql_result($result,$i,"dat_type");
    $html        = mysql_result($result,$i,"html");
    $quant        = mysql_result($result,$i,"quant");
    $cliente        = mysql_result($result,$i,"cliente");


  if($dat_type == 'image'):
    print "<center>$cliente</center><br>\n <img src=\"$image_url\" border=\"0\"><br>\n<input type=\"checkbox\" name=\"del_id[]\" value=\"$id\"><br>\n";
  elseif($dat_type == 'html'):
    print "<center>$cliente</center><br>\n $html<br>\n<input type=\"checkbox\" name=\"del_id[]\" value=\"$id\"><br>\n";
  else:
    print "<center>$cliente</center><br>\n <img src=\"$image_url\" border=\"0\"><br>\n<input type=\"checkbox\" name=\"del_id[]\" value=\"$id\"><br>\n";
  endif;

    $i++;
ENDWHILE;
print "<hr width=\"100\">Senha:<br><input type=\"password\" name=\"admin_password\"><br>";
print "<input type=\"submit\" value=\"Deletar banner selecionado\">\n";
print "</form>\n";
print "</center>\n";

foot();

elseif($action == do_del):
 //Check the Password
  if($admin_password != $admin_pass):
  bad_pass();
  endif;

//Remover banner
 head();
 for($i=0; $i < count($del_id); $i++)
 {
  $query = "DELETE FROM $table WHERE id = '$del_id[$i]'";
  $exec = MYSQL_QUERY($query);

  if($exec == 1):
   print "Banner deletado: $del_id[$i]<br>\n";
  else:
   print "Error: $del_id[$i] didn't delete properly<br>\n";
  endif;
 }

  print "\n<br>Delete Complete";
  foot();

elseif($action == stats):
head();
$font="<font face=\"Arial\" size=\"2\">";
?>
        <TABLE BORDER=1 CELLSPACING=1 CELLPADDING=0 WIDTH="95%">
        <TR ALIGN="left" VALIGN="top">
                <th><? echo $font ?>::Cliente (ID) </th>
                <TH><? echo $font ?> Site (Tipo)(Quant)</TH>
                    <TH><? echo $font ?> Views Total</TH>
                    <TH><? echo $font ?> Views</TH>
                    <TH><? echo $font ?> Clicks Total</TH>
                    <TH><? echo $font ?> Clicks</TH>
        </tr>
<?

$query = "SELECT * FROM $table ORDER by id";
$result = MYSQL_QUERY($query);
$number = MYSQL_NUMROWS($result);
$i=0;

WHILE ($i < $number):

//Pegando detalhes para incluir registros
$id                = mysql_result($result,$i,"id");
$image_url        = mysql_result($result,$i,"image_url");
$url                = mysql_result($result,$i,"url");
$zone                = mysql_result($result,$i,"zone");
$displays_life        = mysql_result($result,$i,"displays_life");
$displays_day        = mysql_result($result,$i,"displays_day");
$clicks_life        = mysql_result($result,$i,"clicks_life");
$clicks_day        = mysql_result($result,$i,"clicks_day");
$cliente        = mysql_result($result,$i,"cliente");
$quant        = mysql_result($result,$i,"quant");
          print "
          <TR ALIGN=\"left\" VALIGN=\"top\">
                    <TD>$font $cliente ($id)</TD>
                    <TD>$font <a href=\"$url\" target=\"_blank\">$url</a> ($zone)($quant)</TD>
                    <TD>$font $displays_life</TD>
                    <TD>$font $displays_day</TD>
                    <TD>$font $clicks_life</TD>
                    <TD>$font $clicks_day</TD>

          </tr>";

            $tdisplays_life=$tdisplays_life+$displays_life;
            $tdisplays_day=$tdisplays_day+$displays_day;
            $tclicks_life=$tclicks_life+$clicks_life;
            $tclicks_day=$tclicks_day+$clicks_day;
    $i++;
ENDWHILE;
          print "
          <TR ALIGN=\"left\" VALIGN=\"top\">
                    <td bgcolor=\"#000000\"></td>
                    <TD bgcolor=\"#cfcfcf\"><strong>$font Totals:</strong></TD>
                    <TD bgcolor=\"#cfcfcf\">$font $tdisplays_life</TD>
                    <TD bgcolor=\"#cfcfcf\">$font $tdisplays_day</TD>
                    <TD bgcolor=\"#cfcfcf\">$font $tclicks_life</TD>
                    <TD bgcolor=\"#cfcfcf\">$font $tclicks_day</TD>
            </tr>";
         print "</TABLE>";

         foot();

elseif($action == clear_day):
head();
?>

<form action="<? echo $pagename ?>?do_clear_day" method=POST>
Senha:<br><input type="password" name="admin_password"><br>
<input type="submit" value="Limpar status">
</form>

<?php
foot();

elseif($action == do_clear_day):
 //Check the Password
  if($admin_password != $admin_pass):
  bad_pass();
  endif;
//Pegando n� do banner no banco de dados
$query = "SELECT * FROM $table";
$result = MYSQL_QUERY($query);
$number = MYSQL_NUMROWS($result);
$i=0;

WHILE ($i < $number):
    //Pegando detalhes para incluir registros
$id = mysql_result($result,$i,"id");
$update_query="UPDATE $table SET clicks_day = '0' WHERE id = '$id'";
$update_result=MYSQL_QUERY($update_query);
$update_query="UPDATE $table SET displays_day = '0' WHERE id = '$id'";
$update_result=MYSQL_QUERY($update_query);
    $i++;
ENDWHILE;

head();
print "Todas colunas de \"Hoje\" foram apagados.";
foot();

elseif($action == lframe):
?>
  <html>
  <head>
  <title>Left Frame</title>
  </head>
  <body bgcolor="#990000" text="#FFFFFF" link="#00CCFF" vlink="#00CCFF" alink="#00FFFF">
  <font face="Verdana,Arial" size="1">
<b>Op��es</b><br> <hr><br>
<a href="<? echo $pagename ?>?add" target="mainFrame"><strong>Adicionar banner</strong></a><br>
<br>
<a href="<? echo $pagename ?>?modify" target="mainFrame"><strong>Modificar banner</strong></a><br>
<br>
<a href="<? echo $pagename ?>?delete" target="mainFrame"><strong>Deletar Banner</strong></a><br><br>
<a href="<? echo $pagename ?>?stats" target="mainFrame"><strong>Ver Status</strong></a><br><br>
<a href="<? echo $pagename ?>?clear_day" target="mainFrame"><strong>Limpar colunas de hoje</strong></a><br>
<br><hr><br>
<left>Legenda</left> <br>

<hr><br>
Full Banner = 468x60<br>
<br>
Half Banner = 234x60<br>

<hr><br>
<li>Banner Administrator
<br><hr>



<br>

   </font>
  </body>
  </html>
<?php

elseif($action == rframe):
head();
?>
Bem vindo ao Banner Administrator V1.0 by <a href="mailto:webmaster@webtuba.com.br">Webtuba Design Studio</a><br>
<br>
Por favor escolha uma op��o ao lado
<?php
foot();

else:
?>
  <html>
  <head>
  <title>Banner Administrator V1.0 - GNU</title>
  </head>
  <frameset cols="150,*" frameborder="no" border="0" framespacing="0">
    <frame name="leftFrame" scrolling="auto" noresize src="<? echo $pagename ?>?lframe">
    <frame name="mainFrame" src="<? echo $pagename ?>?rframe">
  </frameset>
  <noframes>
  <body>
  This Page Requires Frames, but your browser doesn't support them.
  </body>
  </noframe>
  </html>
<?php
endif;

MYSQL_CLOSE();
?>