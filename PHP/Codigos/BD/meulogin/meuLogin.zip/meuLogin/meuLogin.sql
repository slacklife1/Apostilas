-- MySQL dump 8.21
--
-- Host: localhost    Database: meuLogin
---------------------------------------------------------
-- Server version	3.23.49-log

--
-- Table structure for table 'usuario'
--

CREATE TABLE usuario (
  login varchar(30) NOT NULL default '',
  senha varchar(100) default NULL,
  PRIMARY KEY  (login)
) TYPE=MyISAM;
