<?
include 'sessao.inc';
?>

<html>
<body>

Ol� <? echo $login; ?>,
<br><br>
Este script � oriundo do site: <a href="http://www.vivaolinux.com.br">www.vivaolinux.com.br</a>.
<br><br>
Atenciosamente,<bR>
F�bio Berbert de Paula 
&lt;<a href="mailto:fabio@vivaolinux.com.br">fabio@vivaolinux.com.br</a>&gt;

</body>
</html>
