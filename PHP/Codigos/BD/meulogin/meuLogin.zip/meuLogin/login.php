<html>
<body>

<form action="efetuar_login.php" method="post">

Login: <input name="usuario" style="width: 100px"><br>
Senha: <input type="password" name="senha" style="width: 100px"><br>
<input type="submit" value="Login" style="width: 60px;">

</form>

</body>
</html>
