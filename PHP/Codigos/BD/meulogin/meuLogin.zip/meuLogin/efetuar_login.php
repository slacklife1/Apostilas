<?
/*
efetuar_login.php

programa que efetua login e inicia a sess�o de usu�rio
*/

// definir conex�o com o banco de dados
$hostDb = 'localhost';
$userDb = 'root';
$passDb = '';
$con = mysql_pconnect($hostDb,$userDb,$passDb);
mysql_select_db('meuLogin');

// busca a senha do usu�rio que est� tentando efetuar login
$res = mysql_query("SELECT senha FROM usuario WHERE login='$usuario'",$con);
list($DBsenha) =  mysql_fetch_array($res);
mysql_free_result($res);

// se o usuario e senha foram digitados e a senha informada confere com a 
// senha cadastrada, ent�o tudo est� nos conformes, vamos iniciar a sess�o
// e a hora em que o login foi efetuado
if ($usuario && $senha == $DBsenha && $senha) {
  session_start('minhaSessao');
  $tempo = time();
  $login = $usuario;
  session_register("tempo");
  session_register("login");
  header("Location: index.php");
  exit;
} else {
  echo 'Usu�rio ou senha incorreta!';
  exit;
}

?>
