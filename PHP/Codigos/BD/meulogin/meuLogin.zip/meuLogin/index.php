<?
// incluir este arquivo em cada cabe�alho de cada script
// do site
include 'sessao.inc';
?>

<html>
<body>

Ol� <b><? echo $login; ?></b>, voc� est� logado no site desde 
<i><? echo date('d/m/Y h:m hs',$tempo); ?></i>.
<br><br>
<a href="sobre.php">Clique aqui</a> para continuar a navega��o.

</body>
</html>
