<?php


   include ("conect.inc");

   //conecta com o mysql
   $conecta = mysql_connect("$dbhost", "$dbuser", "") or print (mysql_error());
   mysql_select_db("$database", $conecta) or print(mysql_error());
   
   $sql = "SELECT * FROM $tableb WHERE usuario='$DBusuario'";
   $result = mysql_query($sql, $conecta);
   $consulta = mysql_fetch_array($result);
   $usuario=$consulta[usuario];
   
   mysql_close($conecta);
   
   if ((!$DBusuario=="") && (!$DBsenha==""))
   {
      if ((!$usuario==$DBusuario))
      {
         $conecta = mysql_connect("$dbhost", "$dbuser", "") or print (mysql_error());
         mysql_select_db("$database", $conecta) or print(mysql_error());
         mysql_query("INSERT INTO $tableb (usuario,senha) VALUES ('$DBusuario','$DBsenha')");
         mysql_close($conecta);
         echo "O Usu�rio $DBusuario foi cadastrado com sucesso!!";
         echo "  <META HTTP-EQUIV=\"Refresh\" CONTENT=\"2; URL= login.php\"> ";
      }
   else
      echo "Login j� Cadastrado, escolha outro!! <br>";
   }
   else
      echo "Informe o Usuario e a Senha";




?>
