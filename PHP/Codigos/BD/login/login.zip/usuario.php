<?php



      include ("conect.inc");
      //conecta com o mysql
      $conecta = mysql_connect("$dbhost", "$dbuser", "") or print (mysql_error());
      mysql_select_db("$database", $conecta) or print(mysql_error());

      //atualiza��o de logon
      $sql = "SELECT * FROM $tableb WHERE usuario='$DBusuario' AND senha='$DBsenha'";
      $result = mysql_query($sql, $conecta);
      $consulta = mysql_fetch_array($result);
      $senha=$consulta[senha];
      $usuario=$consulta[usuario];
      if ((!$usuario=="") && (!$senha==""))
      {
         echo "Seja Bem Vindo \"$DBusuario\"!";
         if (!$consulta[data]=="")
            echo " Seu �ltimo Acesso a nossa p�gina foi $consulta[data] as $consulta[hora]:$consulta[minuto]";
         else
             echo " Essa � a sua primeira visita<br>como usuario cadastrado a nossa p�gina";
         mysql_query("UPDATE $tableb SET data='$data', hora='$hora', minuto='$minuto' WHERE usuario='$DBusuario' AND senha='$DBsenha'");

      
         //estat�stica de Login
         $sql = "SELECT * FROM $tableb WHERE usuario='$DBusuario' AND senha='$DBsenha'";
         $result = mysql_query($sql, $conecta);
         $consulta = mysql_fetch_array($result);
      }
      else
      {
         if (($DBusuario=="") || ($DBsenha==""))
            echo "Informe o Usu�rio e a Senha! ";
         else
            echo "Acesso Negado, Verifique o Usu�rio e a Senha!!";
      }

      //desconecta com o mysql
      mysql_close($conecta);


?>
