


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>

</HEAD>


<table border="2" align=center bordercolor=blue width="40%">
<tr>
   <td align=center width=25%><br>
      <form method=post action="<? echo $PATH_INFO; ?>">
      <input type="text" size="8" name=DBusuario> <BR>
      <input type="password" size="8" name=DBsenha> <BR>
      <input type=submit name="sub" value=Enviar> </form>
  </td>
  <td align=center>
     <?include ("usuario_cadast.php");?>
  </td>
</tr>
</table>


</BODY>
</HTML>
