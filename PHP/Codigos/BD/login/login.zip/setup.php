<?php

$dbhost="localhost";
$dbuser="root";
$dbpasswd="";
$database="netbranimes";
$table="netbrcontador";
$tableb="ip";

//Conectando e tentando criar tabela
$db = mysql_connect("$dbhost", "$dbuser", "$dbpasswd");
if (!@mysql_select_db($database, $db)){
	if(!@mysql_query("CREATE DATABASE $database", $db)){
		echo "<b>Problema na instru��o SQL<br>n.o ".mysql_errno()."</b>--->  ".mysql_error()."<br>";
		die("<font color=\"#FF0000\">ERRO</font>");
  	}else{
	    	mysql_select_db($database, $db);
	}
}
if (!@mysql_query("SELECT numero FROM $table LIMIT 0,0", $db))
{
	$sql = "CREATE TABLE $table (
		  contador int (10),
		  local varchar (10),
		);";
	if(!@mysql_query($sql,$db)){
	        echo "<b>Problema na instru��o SQL<br>n.o ".mysql_errno()."</b>--->  ".mysql_error()."<br>";
	        die("<font color=\"#FF0000\">ERRO</font>");
        }
}

if (!@mysql_query("SELECT numero FROM $tableb LIMIT 0,0", $db))
{
	$sql = "CREATE TABLE $tableb
    (
        data text,
        hora text,
        minuto text,
        usuario text,
        senha text
		);";
	if(!@mysql_query($sql,$db)){
	        echo "<b>Problema na instru��o SQL<br>n.o ".mysql_errno()."</b>--->  ".mysql_error()."<br>";
	        die("<font color=\"#FF0000\">ERRO</font>");
        }

}


?>
