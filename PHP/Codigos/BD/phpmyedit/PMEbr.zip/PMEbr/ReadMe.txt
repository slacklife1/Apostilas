PHPMyEdit V4.0b3
----------------

Simplesmente descompacte isso tudo em uma pasta no seu httpd

Escrito por
Jim Kraai
jkraai@users.sourceforge.net

Traduzido pr
Neander Ara�jo
neander@eumesmo.com.br
