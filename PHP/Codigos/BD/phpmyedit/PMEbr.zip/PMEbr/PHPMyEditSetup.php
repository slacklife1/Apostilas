<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
  <title>PHPMyEdit Setup Portugu�s - neander@eumesmo.com.br</title>
</head>
<style type="text/css">
  body {font-family: "Verdana", "Arial", "Sans-Serif"; text-align: left}
  h1 {color: #004d9c; font-size: 12pt; font-weight: bold}
  h2 {color: #004d9c; font-size: 10pt; font-weight: bold}
  h3 {color: #004d9c; font-size: 10pt; }
  p  {color: #004d9c; font-size: 8pt; }
  table {border: 2px solid #004d9c; font-size: 8pt; text-align: center; border-collapse: "collapse"; }
  td {border: 2px solid; padding: 2px; color: #004d9c; font-size: 8pt; }
</style>
<center>
<body>
<?PHP
// -- setup.php version 3.5 27-Apr-01

$phpExtension = '.phtml';
$phpExtension = '.php';
# directory to put the .php file into
$destDir = '.';
# directory to put the .inc file into
$inclDir = '.';
$headerFile = 'SiteHeader.inc';
$footerFile = 'SiteFooter.inc';
if (isset($baseFilename)) {
        $phpFile = $baseFilename.$phpExtension;
        $contentFile = $baseFilename.'Content.inc';
} elseif (isset($tb)) {
        $phpFile = $tb.$phpExtension;
        $contentFile = $tb.'Content.inc';
} else {
        $phpFile = 'index'.$phpExtension;
        $contentFile = 'Content.inc';
}

$buffer = '';

function echo_html($x) {
        echo htmlentities($x)."\n";
}

function echo_buffer($x) {
        global $buffer;
        $buffer .= $x."\n";
}

$self = basename($PHP_SELF);
$dbl = @mysql_pconnect($hn,$un,$pw);
if ((!$dbl) or empty($submit))
{
        echo '  <h1>Por Favor Entre Com os Dados de Sua DataBase MySQL:</h1>';
        if (!empty($submit)) {echo '  <h2>Falha no Login - Tente Novamente</h2>'."\n";}
  echo '
  <form action="'.$self.'" method="POST">
    <table border="1" cellpadding="1" cellspacing="0" summary="Log in">
      <tr>
        <td>Hostname:</td>
        <td><input type="text" name="hn" value="'.$hn.'"></td>
      </tr><tr>
        <td>Username:</td>
        <td><input type="text" name="un" value="'.$un.'"></td>
      </tr><tr>
        <td>Password:</td>
        <td><input type="password" name="pw" value="'.$pw.'"></td>
      </tr>
    </table>
    <br>
    <input type="submit" name="submit" value="Conectar">
  </form>'."\n";
} else {
  if (!isset($db))
  {
    $dbs = mysql_list_dbs($dbl);
    $num_dbs = mysql_numrows($dbs);
    echo '  <h1>Por Favor Escolha a Base de Dados:</h1>
  <form action="'.$self.'" method="POST">
    <input type="hidden" name="hn" value="'.$hn.'">
    <input type="hidden" name="un" value="'.$un.'">
    <input type="hidden" name="pw" value="'.$pw.'">
    <table border="1" cellpadding="1" cellspacing="1" summary="Choose Database">'."\n";
      for ($i=0; $i<$num_dbs; $i++)
      {
        $db = mysql_dbname($dbs, $i);
                          if ($i==0)
             {echo '      <tr><td><input checked type="radio" name="db" value="'.$db.'"></td><td>'.$db.'</td></tr>'."\n"; }
        else {echo '      <tr><td><input type="radio" name="db" value="'.$db.'"></td><td>'.$db.'</td></tr>'."\n";}
      }
             echo '    </table>
    <br>
    <input type="submit" name="submit" value="Connectar">
    <input type="submit" name="cancel" value="Cancelar">
  </form>'."\n";
  } else {
    if (!isset($tb))
    {
      echo '  <h1>Por Favor Escolha Uma Tabela Para a Base de Dados: '.$db.'</h1>
  <form action="'.$self.'" method="POST">
    <input type="hidden" name="hn" value="'.$hn.'">
    <input type="hidden" name="un" value="'.$un.'">
    <input type="hidden" name="pw" value="'.$pw.'">
    <input type="hidden" name="db" value="'.$db.'">
    <table border="1" cellpadding="1" cellspacing="1" summary="Choose Table">'."\n";
      $tbs = mysql_list_tables($db,$dbl);
      $num_tbs = @mysql_numrows($tbs);
      for ($j=0; $j<$num_tbs; $j++)
      {
        $tb = mysql_tablename($tbs, $j);
                          if ($j==0)
             {echo '      <tr><td><input checked type="radio" name="tb" value="'.$tb.'"></td><td>'.$tb.'</td></tr>'."\n"; }
        else {echo '      <tr><td><input type="radio" name="tb" value="'.$tb.'"></td><td>'.$tb.'</td></tr>'."\n";}
      }
            echo '    </table>
    <br>
    <input type="submit" name="submit" value="Enviar">
    <input type="submit" name="cancel" value="Cancelar">
  </form>'."\n";
    } else  {
      if (!isset($id))
      {
        echo '  <h1>Por Favor Informe o Identificador Para a Tabela: '.$tb.'</h1>
  <h2>Este Field Ser� Usado Em Alera��es ou Deletes.</h2>
  <p>
          O valor escolhido precisa ser num�rico e �nico no record.<br>
    Se na sua tabela n�o existe esses valores escolha <i>None</i>.
        </p>
  <form action="'.$self.'" method="POST">
    <input type="hidden" name="hn" value="'.$hn.'">
    <input type="hidden" name="un" value="'.$un.'">
    <input type="hidden" name="pw" value="'.$pw.'">
    <input type="hidden" name="db" value="'.$db.'">
    <input type="hidden" name="tb" value="'.$tb.'">
    <table border="1" cellpadding="1" cellspacing="1" summary="Choose Key">
      <tr><td><input type="radio" name="id" value="">
  <td><i>None</i></td><td><i>No id field required</i></td></tr>'."\n";
        echo "Descri��o das Colunas na Tabela $tb<br>\n";
                mysql_select_db($db);
        $tb_desc = mysql_query("describe $tb");
        $fds = mysql_list_fields($db,$tb,$dbl);
        $j=0;
        while (1)
                {
          $fd = @mysql_field_name($fds, $j);
          if ($fd == "") { break; }
          $ff = mysql_field_flags($fds, $j);
                  echo "      <tr><td><input";
          if (stristr($ff,"primary_key"))
               echo ' checado';
          echo ' type="radio" name="id" value="'.$fd.'"></td><td>'.$fd.'</td><td>'.$ff.'</td>';
                  $r = mysql_fetch_array($tb_desc,$j);
/*
echo "<tr><td><pre>";
print_r($r);
echo "</pre></td></tr>\n";
echo "</tr>\n";
*/
          ++$j;
        }
              echo '    </table>
    <br>
       T�tulo Pagina: <input type="text" name=pageTitle value ="">
    <br>
        Nome Arquivo: <input type="text" name=baseFilename value ="'.$tb.'">
    <br>
    <input type="submit" name="submit" value="Criar">
    <input type="submit" name="cancel" value="Cancelar">
  </form>'."\n";

      } else  {
                          echo '<h1>Sistema PGPMyEdit de Cria��o de Forms</h1>'."\n";
                          echo '<h2>Conectividade Direta Com Sua Base MySQL</h2>'."\n";
        echo '<hr><pre>'."\n";
        echo_buffer('<div class="main">
  <h3><?PHP echo $_title; ?></h3>
<?PHP
//   MySQL host name, user name, password, database, and table to edit
# NOTE: coder is strongly urged to remove the hn, un, pw lines from
# here and set values in PME_site_defaults.inc
#require "PME_site_defaults.inc";
$opts["hn"]="'.$hn.'";
$opts["un"]="'.$un.'";
$opts["pw"]="'.$pw.'";
$opts["db"]="'.$db.'";
$opts["tb"]="'.$tb.'";

//  Name of field which is the unique key
$opts["key"]="'.$id.'";

//  Type of key field (int/real/string/date etc)');
if ($id=="")
{
        echo_buffer('$opts["key_type"]="";');
} else {
        $fds = mysql_list_fields($db,$tb,$dbl);
        $j=0;
        while (1)
        {
                $fd = @mysql_field_name($fds, $j);
                if ($fd == '') { break; }
                if ($fd == $id)
                {
                        echo_buffer('$opts["key_type"]="'.@mysql_field_type($fds, $j).'";');
                        break;
                }
                ++$j;
        }
}
echo_buffer("// Initial field to sort on");
echo_buffer('$opts["sort_field"]="'.$id.'";');

echo_buffer("
//   Number of records to display on the screen
// note that \$inc = -1 lists _all_ records in a table
\$opts['inc']= 15;

// Options you wish to give the users - A(dd) C(hange) D(elete) F(ilter)
// I(nitial sort suppressed) coPy view dEtail
\$opts['options']='APCDEF';

// Number of lines to display on multiple selection filters
\$opts['multiple']='4';

// Options you wish to give the users - A(dd) C(hange) D(elete) F(ilter)
// dEtail display, I(nitial sort suppressed)

// Number of lines to display on multiple selection filters
#\$opts['default_sort_columns'] = Array('pushId','due','priority','task');

// action hyper'link's, 'button's, or 'graphic's
\$opts['actionStyle']='button';
#\$opts['actionStyle']='link';
#\$opts['actionStyle']='graphic';

\$opts['display_query']=true;
\$opts['display_sort']=true;

/*
        Field definitions. Fields will be displayed left to right
        on the screen in the order in which they appear in this list.
        ['name'] is the title used for column headings, etc.;
        ['sort'] = true means the users may sort the display on this column;
        ['type'] is generated by SETUP.PHP and indicates the mysql field type
                best not edited
        ['maxlen'] maximum length to display add/edit/search input boxes
        ['trimlen'] maximum length of string content to display in row listing
                if strlen(value) > trimlen, display substr($value,0,trimlen-3).'...'
        ['width'] is an optional display width specification for the column,
                e.g.  ['width'] = '100px';
                or \$fdd['colname']['width'] = (\$fdd['colname']['trimlen'] * 8).'px';
        ['nowrap'] true or false.  whether this field should get a NOWRAP
        ['mask'] a string that is used by sprintf() to format field output
        ['datemask'] a string that is used by date() to format date fields
                see PHP's date() for valid formatting characters
        ['daterange'] a  of numbers
                ['daterange']['start'] = 1996;
                ['daterange']['end']   = \$fdd['colname']['daterange']['start']+20;
        ['URL'] is used to make a field 'clickable' in the display, e.g.:
                ['URL'] = 'mailto:' or ['URL'] = 'http://';
                ['URL'] = '\$page?stuff';
                Note that the following are available as variables:
                        \$key   key field for record
                        \$name  name of the field
                        \$value value of the field
                        \$page  this HTML page
                        \$row   mysql_fetch_assoc() for this row
        ['required'] = true will generate javascript to prevent null entries by users
        ['options'] is an optional parameter to control whether a field is
                displayed in the A(dd), C(hange), D(elete), view, or L(ist) views
                ['options']='R' indicates that a field is read only
                ['options']='P' indicates that a field is a password field
                ['options']='H' indicates that a field is to be hidden
                and marked as hidden
        ['textarea']['rows'] and/or ['textarea']['cols'] specifies a
        textarea is to be used to give multi-line input,
                e.g. ['textarea']['rows'] = 5; ['textarea']['cols'] = 10
        ['values'] restricts user input to the specified constants,
                e.g. ['values'] = array('A','B','C')
                or   ['values'] = range(1,99);
        ['values']['table'] and ['values']['column'] restricts user
                input to the values found in the specified column of another table.
                If the optional ['values']['description'] is also specified,
                the values displayed to the user by PHPMyEdit will be taken from the
                column specified by 'description'. e.g.:
                        ['values']['db']='mydb' *optional if table is in another database*
                        ['values']['table']='mytable'
                        ['values']['column']='key_column'
                        ['values']['description']='result_column' *optional*
                        ['values']['filters']='idcolumn in (1,,2,3)' *optional WHERE clause*
                        ['values']['orderby']='result_column' *optional ORDER BY clause*
                if a column is either SET or ENUM type, then the values are put in
                by PME Setup.
        ['select'] = 'T/D/M' (text, drop-down, or multiple selection for filters)
                if a column is a SET type, then this is automatically 'M'
        Calculated Expressions
                example:
                        \$fdd['other']['name']='Col Header';
                        \$fdd['other']['expression']='onHand-ordered';
                        \$fdd['other']['sort']='T:!';
                        \$fdd['other']['select']='T';
                        \$fdd['other']['type']='int';
                'other' can be anything, but needs to be unique within the list of \$fdd keys
                'expression' can be any valid MySQL expression
                'type' should reflect the results of the expression, e.g. 'int' or 'string'
                all other options work as with other, normal columns
                this kind of column is always read-only
*/");
                mysql_select_db($db);
        $tb_desc = mysql_query("describe $tb");
        $fds = mysql_list_fields($db, $tb, $dbl);
        $num_fds = mysql_num_fields($fds);
        for ($k=0 ; $k<$num_fds; $k++)
        {
                $fd = mysql_field_name($fds,$k);
                        $fm = mysql_fetch_field($fds,$k);
                          $fn = ucwords(
                                 strtr(
                                        $fd,
                                        "_-.",
                                        "   "
                                )
                        );
          $row = mysql_fetch_array($tb_desc);
          echo_buffer('$fdd["'.$fd.'"] = Array(');
                  echo_buffer("        'name'=>'$fn',");
                  if (substr($row[1],0,3) == 'set') {
                  echo_buffer("        'select'=>'M',");
                  echo_buffer("        'type'=>'set',");
                  } else {
                  echo_buffer("        'select'=>'T',");
                  echo_buffer("        'type'=>'".mysql_field_type($fds,$k)."',");
                  }
          echo_buffer("        'maxlen'=>".mysql_field_len($fds,$k).',');
          echo_buffer("        'nowrap'=>false,");
          if (stristr(mysql_field_flags($fds,$k),'not_null')) {
            echo_buffer("        'required'=>true,");
          }
                  # blobs -> textarea
          if (mysql_field_type($fds,$k)=='blob')
                {
            echo_buffer("        'textarea'=>Array(");
                        echo_buffer("                'rows'=>5,");
            echo_buffer("                'cols'=>50,");
            echo_buffer("                'wrap'=>'virtual'");
            echo_buffer("        ),");
                       }
                  # timestamps are read-only
          if (mysql_field_type($fds,$k)=='timestamp')
                {
            echo_buffer("        'options'=>'R',");
                  }

                  # SETs and ENUMs get special treatment
                  if (substr($row[1],0,3) == 'set') {
                          echo_buffer("        'values'=>Array".substr($row[1],3).',');
                  }
                  if (substr($row[1],0,4) == 'enum') {
                          echo_buffer("        'values'=>Array".substr($row[1],4).',');
                  }

                  # automatic support for Default values
                  if ($row[4] != '' && $row[4] != 'NULL') {
                          echo_buffer("        'default'=>'".$row[4]."',");
                  }
          echo_buffer("        'sort'=>true");
          echo_buffer(');');
          echo_buffer('');
        }

        echo_buffer("
\$opts['fdd'] = \$fdd;

/*
table-level filter capability

if set, is included in the WHERE clause of any generated SELECT statement

example:
\$opts['filters'] = \"column1 like '%11%' AND column2<17\";
);
*/

/*
Triggers are files that are included (via require) that perform
actions (before or after) X (inserts, updates, or deletes).

'before' triggers are usually used to verify conditions prior to
executing the main operation.

'after' triggers are usually used to perform follow-on operations
after the main operation.  For example, to update secondary tables
to enforce referential integrity or to update aggregate tables.

The operation sequence is this:  before, main, after.  If any
operation fails, not only should the next operation(s) not be
executed, but the previous ones are 'rolled back' as if they
never happened.  If a database is not able to do this, it is
not 'transaction-safe'.

Triggers are risky in basic MySQL as there is no native transaction
support--it is not transaction-safe by default.  There are
transaction-safe table types in MySQL that can be conditionally built
(see MySQL-Max), but PHPMyEdit is currently not set up to support real
transactions.  What that means is that if an operation fails, the
database may be left in an intermediate and invalid state.

The programmer must understand and accept these risks prior to using
the PHPMyEdit triggers mechanism.

If the triggers are used, they execute within the namespace or scope
of the PHPMyEdit class.

They _must_ return true or false to indicate success or failure.
*/

/*
\$opts['triggers']['insert']['before']='".substr($contentFile,0,strrpos($contentFile,'.inc'))."TIB.inc';
\$opts['triggers']['insert']['after'] ='".substr($contentFile,0,strrpos($contentFile,'.inc'))."TIA.inc';
\$opts['triggers']['update']['before']='".substr($contentFile,0,strrpos($contentFile,'.inc'))."TUB.inc';
\$opts['triggers']['update']['after'] ='".substr($contentFile,0,strrpos($contentFile,'.inc'))."TUA.inc';
\$opts['triggers']['delete']['before']='".substr($contentFile,0,strrpos($contentFile,'.inc'))."TDB.inc';
\$opts['triggers']['delete']['after'] ='".substr($contentFile,0,strrpos($contentFile,'.inc'))."TDA.inc';
*/

/*
logtable schema

CREATE TABLE changelog (
  updated timestamp(14) NOT NULL,
  user varchar(50) default NULL,
  host varchar(255) NOT NULL default '',
  operation varchar(50) default NULL,
  tab varchar(50) default NULL,
  rowkey varchar(255) default NULL,
  col varchar(255) default NULL,
  oldval blob,
  newval blob
);

\$opts['logtable']= 'changelog';
*/
");


        echo_buffer("
# get the user's default language and use it if possible
\$opts['language']= \$HTTP_POST_VARS['HTTP-ACCEPT-LANGUAGE'];

//  and now the all-important call to PHPMyEdit
//  warning - beware of case-sensitive operating systems!
require 'PHPMyEdit.inc';

\$MyForm = new PHPMyEdit(\$opts);

?>

  </div>");

// write the php file
$phpFileContents = '<?PHP
require \'PME_site_defaults.inc\';
$_title = "'.$pageTitle.'";
$_content = "'.$contentFile.'";
include "'.$headerFile.'";
include $_content;
include "'.$footerFile.'";
?>';

echo 'Criando Arquivo Em: '.$destDir.'/'.$phpFile."<br>\n";
$filehandle = fopen($destDir.'/'.$phpFile,'w+');

if ($filehandle) {
        fwrite($filehandle,$phpFileContents);
        flush($filehandle);
        fclose($filehandle);
        echo "Arquivo Criado Com Sucesso<br>";
}
echo "<hr>Arquivo PHP:<pre>";
echo_html($phpFileContents);
echo "</pre><hr>\n";


// write the content include file
echo 'Criando Arquivo de Conte�do: '.$inclDir.'/'.$contentFile."<br>\n";
$filehandle = fopen($inclDir.'/'.$contentFile,'w+');
if ($filehandle) {
        fwrite($filehandle,$buffer);
        flush($filehandle);
        fclose($filehandle);
        echo "Arquivo Criado Com Sucesso<br>";
}
echo "<hr>Arquivo PHP:<pre>";
echo_html($buffer);
echo "</pre><hr>\n";

      }
    }
  }
}
?>
</body>
</html>