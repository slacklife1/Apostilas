<?php
/**
* class TBDTotal
*
* { Autor: bragatto
*   HP: www.qkr.cjb.net
*   Vers�o: 0.2
*   Data: 01/05/2003
*
*   Classe para conexao com BD, gerando portabilidade, permitindo o
*   desenvolvimento de aplica��es 3 camadas. Baseado no arquivo
*   bdfunctions.php de Cl�ver Anjos.
*
*   }
*
*/
class TBDTotal
{
  var $dbhost;
  var $dbuname;
  var $dbpass;
  var $dbname;
  var $dbtype;
  var $debug;

  /**
  * TBDTotal::ErroFatal()
  *
  * { Uma funcao para mostrar um erro(parametro) no browser }
  *
  */
  function ErroFatal($erro){
    echo "<font color=#FF0000 size=20>Erro Fatal:<br></font>";
    echo "<font color=#FF0000 size=16>$erro</font>";
    die;
  }

  /**
  * TBDTotal::TBDTotal()
  *
  * { A funcao create j� eh utilizada para fazer a conexao com o BD }
  *
  */
  function TBDTotal(){
  global $dbhost, $dbuname, $dbpass, $dbname,$dbtype,$debug;
  $dbhost  = "localhost";
  $dbuname = "teste";
  $dbpass  = "teste";
  $dbname  = "teste";
  $dbtype  = "MySQL";
  $debug   = 0 ;
      if ($debug)
          echo "AbreBD:$dbhost:$dbuname:$dbpass:$dbname:$dbtype<br>";
      switch ($dbtype) {
          case "MySQL":
             @mysql_connect($dbhost,$dbuname,$dbpass)
                 or $this->ErroFatal("Banco de dados inacess�vel!");
             @mysql_select_db("$dbname");
          break;
      }
  }

  /**
  * TBDTotal::BDQuery()
  *
  * { Executa e abre resultados de comandos SQL }
  *
  */
  function BDQuery($query) {
  global $dbtype,$debug;
      if ( $debug ) echo "BDQuery:$query<br>";
         switch ($dbtype) {
        case "MySQL":
          $result=mysql_query($query) or die(mysql_error());
      break;
      }
      return $result;
  }

  /**
  * TBDTotal::BDRows()
  *
  * { Retorna a numero de linhas de uma selecao }
  *
  */
  function BDRows($result) {
  global $dbtype,$debug;
        switch ($dbtype) {
             case "MySQL":
                $rows=mysql_num_rows($result);
             break;
        }
        if ( $debug )
          echo "BDRows:$rows<br>";
        return $rows;
  }

  /**
  * TBDTotal::BDRowArray()
  *
  * { retorna o registro atual do query }
  *
  */
  function BDRowArray($result) {
  global $dbtype;
        switch ($dbtype) {
            case "MySQL":
                 return mysql_fetch_row($result);
            break;
      }
  }

  /**
  * TBDTotal::BDLastInsertID()
  *
  * { mostra a id do �ltimo registro adicionado }
  *
  */
  function BDLastInsertID() {
  global $dbtype;
        switch ($dbtype) {
            case "MySQL":
                 return mysql_insert_id();
            break;
      }
  }


  /**
  * TBDTotal::BDError()
  *
  * { retorna qual o erro ocorrido no BD }
  *
  */
  function BDError() {
  global $dbtype;
        switch ($dbtype) {
            case "MySQL":
              return (mysql_error());
            break;
      }
  }
}
?>


