<?
# acesso.php
# * Favor me comunicar por email caso for usar meu script!
# * Fernando Andreta - webmaster@asklink.eti.br
# * http://www.asklink.eti.br/scripts
# Fun��o: Esse script exemplifica como chamar as fun��es em seu script.
# LEMBRE-SE: BANCOS DE DADOS DE TEXTO DEVEM TER PERMISSAO DE ACESSO! (chmod 777)

// antes de utilizar qualquer fun��o voc� deve utilizar o "require" para declar�-las.
require ("subst.fcn");
require ("del.fcn");
require ("add.fcn");
require ("lista.fcn");
require ("verif.fcn");

// A vari�vel $ac determina qual fun��o ser� executada.
// exemplo:
// $ac - determina qual fun��o ser� executada.
// $valor = Valor que ser� substitu�do/deletado/adicionado.
// $novovalor = Valor que substituir�.
// $bd - Arquivo do Banco de Dados

// Como chamar as fun��es e como manipular seus erros.
switch ($ac) {
		case 'subst':
                	if ( !subst($valor,$novovalor,$bd) ) {
				exit; // sai em caso de erro.
			} else {
				echo "\r\nSubstituido com sucesso!"; // exibe essa mensagem em caso de sucesso.
			}
			break;

		case 'del':
			if ( !del($valor,$bd) ) {
				exit; // sai em caso de erro.
			} else {
				echo "\r\nApagado com sucesso!"; // exibe essa mensagem em caso de sucesso.
			}
			break;

		case 'add':
			if ( !add($valor,$bd) ) {
				exit; // sai em caso de erro.
			} else {
				echo "\r\nAdicionado com sucesso!"; // exibe essa mensagem em caso de sucesso.
			}
			break;

		case 'lista':
			$bdtxt_lista = lista($bd);
			if ( $bdtxt_lista === false ) {
				exit; // sai em caso de erro.
			} else {
				header("Content-type: text/plain");
				header("Content-Disposition: filename=bd_".$bd);
				echo $bdtxt_lista; // exibe o banco de dados em formato de texto em caso de sucesso.
				// caso $texto seja false, voc� poder� chamar: echo $bdtxt_lista[0]; para ver a linha 0, ou $bdtxt_lista[1];, 2, etc.
			}
			break;

		case 'verif':
			if ( !verif($valor,$bd) ) {
				exit; // sai em caso de erro.
			} else {
				echo "\r\nValor existente!!"; // exibe essa mensagem em caso de sucesso.
			}
			break;

		default:
			echo "Voc� deve especificar uma a��o![\$ac]";
			exit; // nenhum dos casos anteriores.
			break;
}
?>