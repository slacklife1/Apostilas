<?
/*
#####################################
#                                   #
# Desenvolvido por Rodrigo Mour�o   #
#				    #
# rodrigo@europanet.com.br          #
# http://www.europanet.com.br       #
#####################################

*/

include ("conexao.php");

//Fun��o para exibir as mensagens
function exibe_msg($msg,$id_mural){
	global $largura_msg;
	global $detalhes;
	global $admin;                
	global $PHP_SELF;
	global $QUERY_STRING;
	$mensagem = "<table width=\"";
	if (isset($detalhes)){
		$mensagem .= "100%";
	}else{
		$mensagem .= $largura_msg;
	}
	$mensagem .="\" cellspacing=\"0\" cellpadding=\"0\" style=\"".CSS_tabela_externa."\"><tr><td><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">";
	if (marcador != ""){
		$mensagem .= "<tr><td width=\"100%\" style=\"text-align:center;".CSS_recado."\"><img src=\"".marcador."\" border=\"0\"></td></tr>";
	}
	$mensagem .= "<tr><td width=\"100%\" style=\"".CSS_recado."\">";
	if (isset($admin) AND $admin == senha_adm){
		$mensagem .= "<a href=\"$PHP_SELF?$QUERY_STRING&excluir=$id_mural\"><img align=\"left\" src=\"".excluir."\" border=\"0\"></a>&nbsp;";
	}
	$mensagem .= "$msg</td></tr></table></td></tr></table>";
	return $mensagem;
}

//Fim da Fun��o


$largura_msg = floor(((largura_pg - ((num_msg_linha + 1) * spc_msg))/num_msg_linha));

if (!isset($QUERY_STRING)){
	$QUERY_STRING = "";
}else{
	$QUERY_STRING = ereg_replace("&excluir=".'[0-9]+',"",$QUERY_STRING);
}

//logout
If (isset($acao) AND $acao == "logout"){
	Header("Location:$PHP_SELF");
	exit();
} 

//Apaga recado
if (isset($admin) AND $admin == senha_adm AND isset($excluir)){
	$sql = "DELETE FROM $table WHERE id_mural = $excluir";
	if(!$result = mysql_query("$sql", $db)){
		echo "<b>Problema na instru��o SQL<br>n.o ".mysql_errno()."</b>--->  ".mysql_error()."<br>";
		die("<font color=\"#FF0000\">ERRO</font>");
	}
	$mensagem = "Recado removido com sucesso";	
}

//Grava recado
if (isset($acao) AND $acao == "gravar_recado"){
	if (isset($nome) AND $nome != "" AND isset($recado) AND $recado != ""){
		$recado = addslashes(strip_tags($recado));
		$nome = addslashes(strip_tags($nome));
		$email = addslashes(strip_tags($email));
		if ($email == ""){
			$email = "NULO";
		}
		$sql = "INSERT INTO $table(nome,email,recado,data) VALUES('$nome','$email','$recado',".time().")";
		if(!$result = mysql_query("$sql", $db)){
			echo "<b>Problema na instru��o SQL<br>n.o ".mysql_errno()."</b>--->  ".mysql_error()."<br>";
			die("<font color=\"#FF0000\">ERRO</font>");
		}
		$mensagem = "Seu recado foi enviado com sucesso";		
	}else{
		$mensagem = "Por favor, preencha o seu nome e o recado";
		
	}
}

//Carrega recados j� gravados
if (!isset($order) OR (isset($order) AND ($order != "DESC" OR $order != "ASC"))){
	$order = "DESC";
}
$sql = "SELECT * FROM $table ";
if (isset($detalhes)){
	$sql .= "WHERE id_mural = $detalhes ";
}
$sql .= "ORDER BY id_mural $order ";

//Pagina��o
if (!isset($pagina)){$pagina=1;}
$total_recados = mysql_num_rows(mysql_query("SELECT id_mural FROM $table", $db));
$total_paginas = $total_recados/itens_por_pagina;
if (!is_integer($total_paginas)){
	$total_paginas = floor($total_paginas);
	$total_paginas++;
}
if ($pagina > $total_paginas){
	$pagina = $total_paginas;
}
$sql .= " LIMIT ".(($pagina-1)*itens_por_pagina).",".itens_por_pagina;
if(!$result = mysql_query("$sql", $db)){
	echo "<b>Problema na instru��o SQL<br>n.o ".mysql_errno()."</b>--->  ".mysql_error()."<br>";
	die("<font color=\"#FF0000\">ERRO</font>");
}
If (mysql_num_rows($result) == 0){
	$recados[0]["recado"] = "Nenhum recado foi enviado at� o momento";
	$recados[0]["id_mural"] = "0";
}else{
	While ($r = mysql_fetch_array($result,$db)){
		$id_mural = $r["id_mural"];
		$nome = "<span style=\"".CSS_nome."\">".$r["nome"]."</span>";
		$data = "<span style=\"".CSS_data."\">".str_replace(" ","&nbsp;",date("G:i d/n/Y",$r["data"]))."</span>";
		$email = $r["email"];
		$recado = str_replace("\n","<br>",$r["recado"]);
		if (!isset($detalhes)){
			if (strlen($recado) > max_carac){
				$recado = substr($recado,0,max_carac)." ... <a href=\"$PHP_SELF?detalhes=$id_mural\">Mais</a>";
			}
		}
		if ($email != "" AND $email != "NULO"){
			$email = "<a href=\"mailto:$email\"><img src=\"".email."\" border=\"0\"></a> ";
		}else{
			$email = "";
		}
		$recados[]["recado"] = "$nome $email- <i>$data</i><br>$recado";		
		$i = count($recados)-1;
		$recados[$i]["id_mural"] = $id_mural;
	}		
}
?>
<html><head>
<link rel="stylesheet" href="mural.css" type="text/css">
</head><body>
<?           
echo cabecalho;
if (isset($admin) AND $admin == senha_adm){
	print "<span class=\"mensagem\"><a href=\"$PHP_SELF?".ereg_replace("admin=".'[0-9,a-z,A-Z]+',"",$QUERY_STRING)."\">Logout/Sair</a></span><br><br>";
}
if (isset($mensagem)){
	print "<span class=\"mensagem\">$mensagem</span><br><br>";
}
?>
<p><form action="<?echo $PHP_SELF;?>" method="post">
<input type="hidden" name="acao" value="gravar_recado">
<table border="0" cellpadding="0" cellspacing="0">
	<tr><td><fieldset><legend>&nbsp;Envie seu recado&nbsp;</legend>
		<table border="0" width="100%" cellpadding="0" cellspacing="0">
			<tr><td>Nome<sup>*</sup></td><td><input type="text" name="nome" size="35" maxlength="255"></td></tr>
			<tr><td>E-mail</td><td><input type="text" name="email" size="35" maxlength="255"></td></tr>
			<tr><td style="vertical-align:top">Recado<sup>*</sup>&nbsp;</td><td><textarea cols="35" rows="4" name="recado"></textarea></td></tr>
			<tr><td colspan="2" style="text-align:center">&nbsp;<br>&nbsp;<input type="submit" style="cursor:hand;padding-left:10px;padding-right:10px" value="Enviar"><br>&nbsp;</td></tr>
			<tr><td colspan="2" style="text-align:center">Os campos com asterisco s�o obrigat�rios!</td></tr>
		</table></fieldset>
	</td></tr>
</table>
</form></p>
<table width="<? echo largura_pg;?>" border="0" cellpadding="0" cellspacing="0">
<tr>
<?
$temp = 0;
for ($i=0;$i<count($recados);$i++){
	if ($temp == num_msg_linha){
		print "<td width=\"".spc_msg."\">&nbsp;</td></tr><tr><td colspan=\"0\" height=\"".spc_msg."\">&nbsp;</td></tr><tr>";
		$temp = 0;
	}
	$temp++;
	print "<td width=\"".spc_msg."\">&nbsp;</td><td>".exibe_msg($recados[$i]["recado"],$recados[$i]["id_mural"])."</td>";
}
if (!isset($detalhes)){
	while ($temp != num_msg_linha AND $temp < num_msg_linha){
		print "<td width=\"".spc_msg."\">&nbsp;</td><td width=\"$largura_msg\">&nbsp;</td>";
		$temp++;
		if ($temp == num_msg_linha){
			print "<td width=\"".spc_msg."\">&nbsp;</td>";
		}
	}
        print "</tr></table><br><table border=\"0\" class=\"rodape\"><tr><td class=\"rodape\">";
	$QUERY_STRING = ereg_replace("&pagina=".'[0-9]+',"",$QUERY_STRING);
 	if ($pagina != 1 AND $total_recados > 0){
		print "[&nbsp;<a href=\"$PHP_SELF?$QUERY_STRING&pagina=1\">Primeira</a>&nbsp;]&nbsp;&nbsp;";
		print "[&nbsp;<a href=\"$PHP_SELF?$QUERY_STRING&pagina=".($pagina-1)."\">Anterior</a>&nbsp;]&nbsp;&nbsp;";
	}
	print "&nbsp;&nbsp;P�gina&nbsp;::&nbsp;$pagina&nbsp;de&nbsp;$total_paginas&nbsp;&nbsp;";
	if ($pagina < $total_paginas){
		print "[&nbsp;<a href=\"$PHP_SELF?$QUERY_STRING&pagina=".($pagina+1)."\">Pr�xima</a>&nbsp;]&nbsp;&nbsp;";
		print "[&nbsp;<a href=\"$PHP_SELF?$QUERY_STRING&pagina=$total_paginas\">�ltima</a>&nbsp;]";
	}
	print "</td></tr><tr><td class=\"rodape\">Total de recados enviados: $total_recados</td></tr></table>";
	
}else{
	print "</table><br><table border=\"0\" class=\"rodape\"><tr><td class=\"rodape\"><a href=\"$PHP_SELF\">Voltar</a></td></tr></table>";
}
?>
</body></html>
