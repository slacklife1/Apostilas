<?
//Configura��es
Header("Cache-Control: no-cache, must-revalidate");
$dbhost = "127.0.0.1";
$dbuser = "root";
$dbpasswd = "";
$database = "mural";
$table = "mural";

//Cabe�alho da p�gina
define ("cabecalho","<div style=\"text-align:center;border:2px solid #000000;background-color:#ffffff\"><span style=\"font-size:14px;font-weight:bold\">Mural de Recados</span><br>
		<span style=\"font-size:12px\">Deixe a sua mensagem falando <br>o que voc� achou do nosso site</span></div>");

//Senha Administrador
define ("senha_adm","12345");

//N�mero de recados por linha
define ("num_msg_linha","2");

//Largura em pixel da p�gina
define ("largura_pg","740");

//Espaco em pixel entre os recados
define ("spc_msg","20");

//N�mero de recados por p�gina
define ("itens_por_pagina","20");

//M�ximo de caracteres exibidos na mensagem principal
define ("max_carac","150");

//Design do recado
define ("marcador","marcadorp.gif"); //imagem do marcador
define ("email","email.gif"); //imagem do email
define ("excluir","apagar.gif"); //imagem do �cone excluir
define ("CSS_recado","background-color:#FFFF80");//Estilo CSS do recado
define ("CSS_tabela_externa","background-color:#FFFF80;border:1px solid #000000;padding-top:0px;padding-left:5px;padding-right:5px;padding-bottom:5px;");//Estilo CSS da tabela externa do recado (borda)
define ("CSS_data","font-size:10px");//Estilo CSS da data
define ("CSS_nome","font-size:12px;font-weight:bold");//Estilo CSS do nome


/*
Estrutura da Tabela
CREATE TABLE $table (
  id_mural int(10) unsigned NOT NULL auto_increment,
  nome varchar(255) ,
  email varchar(255) ,
  data int(11) ,
  recado tinytext ,
  PRIMARY KEY (id_mural),
  UNIQUE id_mural (id_mural),
  INDEX id_mural_2 (id_mural)
);
*/                                                           

//Conectando e tentando criar tabela
$db = mysql_connect("$dbhost", "$dbuser", "$dbpasswd");
if (!@mysql_select_db($database, $db)){
	if(!@mysql_query("CREATE DATABASE $database", $db)){
		echo "<b>Problema na instru��o SQL<br>n.o ".mysql_errno()."</b>--->  ".mysql_error()."<br>";
		die("<font color=\"#FF0000\">ERRO</font>");			
  	}else{		
	    	mysql_select_db($database, $db);
	}
}
if (!@mysql_query("SELECT id_mural FROM $table LIMIT 0,0", $db)){
	$sql = "CREATE TABLE $table (
		  id_mural int(10) unsigned NOT NULL auto_increment,
		  nome varchar(255) ,
		  email varchar(255) ,
		  data int(11) ,
		  recado tinytext ,
		  PRIMARY KEY (id_mural),
		  UNIQUE id_mural (id_mural),
		  INDEX id_mural_2 (id_mural)
		);";
	if(!@mysql_query($sql,$db)){
	        echo "<b>Problema na instru��o SQL<br>n.o ".mysql_errno()."</b>--->  ".mysql_error()."<br>";
	        die("<font color=\"#FF0000\">ERRO</font>");
        }
}
?>
