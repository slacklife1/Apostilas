<?
#################################################################################################
#
#  project           	: phpBook
#  filename          	: icelandic.php
#  last modified by  	: Fri�geir H�lm
#  e-mail            	: fholm@isholf.is
#  purpose           	: �slensk ���ing
#
#################################################################################################

$languagemetatag	= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">";
$gb_link1		= "Innskr�ning";
$gb_link1desc		= "B�ta vi� �inni skr�ningu";
$gb_link1head		= "B�ta vi� skr�ningu";
$gb_pages		= "S��ur:";
$gb_name		= "Nafn";
$gb_comments		= "Skilabo�";
$gb_location		= "Sta�setning: ";
$gb_posted		= "sent: ";
$gb_modcomment		= "Stj�rnandi Skilabo�: ";
$gbadd_name		= "Nafn :";
$gbadd_location		= "Sta�setning :";
$gbadd_email		= "E-Mail :";
$gbadd_url		= "URL :";
$gbadd_icq		= "ICQ :";
$gbadd_msg		= "Skilabo� :";
$ad_pages		= "S��ur :";
$smiliehelp		= "Klikka�u h�r fyrir Bros-Kalla hj�lp";
$smiley_help		= "Bros-Kalla Hj�lp";
$urlcodehelp		= "Klikka�u h�r fyrir URL-K�da Hj�lp";
$url_code_help		= "URL K�da Hj�lp";
$submit			= "Sta�festa";
$location_sel		= "-------- vinsamlega veldu --------";
$send_email		= "Senda E-Mail";
$icq_message		= "Senda ICQ Skilabo�";
$view_homepage		= "Sko�a Vefs��u";
$ip_logged		= "IP logga�";
$banned			= "Fl��vernd virk, vinsamlega reyndu s��ar!";
$moderator_del_entry	= "Stj�rnandi Ey�a Skr�ning";
$moderator_del_comment	= "Stj�rnandi Ey�a Skilabo�";
$moderator_edit_comment	= "Stj�rnandi Rita Skilabo�";
$gb_notifysubj		= "TILKYNNS-N� Gestab�ka Skr�ningu";
$notify_text		= "N� Gestab�ka-Skr�ning fr�";
$name_empty		= "Vinsamlega sl��u inn nafni� �itt.";
$icq_wrong		= "Engin-virk ICQ skr�ning, ef �� hefur icq reikning vinsamlega hafi� t�mt.";
$non_valid_email	= "Engin-virk Email-skr�ning, vinsamlega sl�i� inn r�tta e-mail addressu e�a hafi� t�mt.";
$message_incorrect	= "Fyrirgefi�, skilabo�in ��n ver�a a� vera milli";
$and			= "og";
$characters		= "stafir";

?>