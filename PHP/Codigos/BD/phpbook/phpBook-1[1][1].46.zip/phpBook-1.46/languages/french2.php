<?
#################################################################################################
#
#  project           	: phpBook
#  filename          	: french.php
#  last modified by  	: Thomas L Puller
#  e-mail            	:
#  purpose           	: French language File
#
#################################################################################################

$languagemetatag	= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">";
$gb_link1		= "Ajoutez votre message";
$gb_link1desc		= "Ajoutez votre message";
$gb_link1head		= "Ajoutez votre message";
$gb_pages		= "Pages:";
$gb_name		= "Nom";
$gb_comments		= "Commentaires";
$gb_location		= "Domicile : ";
$gb_posted		= "Ajout� le : ";
$gb_modcomment		= "Commentaires du mod�rateur : ";
$gbadd_name		= "Nom :";
$gbadd_location		= "Domicile :";
$gbadd_email		= "Email :";
$gbadd_url		= "URL :";
$gbadd_icq		= "ICQ :";
$gbadd_msg		= "Message :";
$ad_pages		= "Pages :";
$smiliehelp		= "Cliquez ici pour aide avec les Smilies";
$smiley_help		= "Aide Smilies";
$urlcodehelp		= "Cliquez ici pour aide avec les codes URL";
$url_code_help		= "Aide codes URL";
$submit			= "Ajoutez";
$location_sel		= "-------- choisissez --------";
$send_email		= "Envoyez email";
$icq_message		= "Envoyez message ICQ";
$view_homepage		= "Voyez le site";
$ip_logged		= "IP enregistr�";
$banned			= "Floodprotect, essayez plus tard !";
$moderator_del_entry	= "MODERATEUR Effacez message";
$moderator_del_comment	= "MODERATEUR Effacez commentaire";
$moderator_edit_comment	= "MODERATEUR Corrigez commentaire";
$gb_notifysubj		= "AVIS - Nouveau message";                         // Subject for Notify E-Mail
$notify_text		= "Nouveau message par";
$name_empty		= "Veuiller inscrire votre nom.";
$icq_wrong		= "Num�ro ICQ invalide, veuillez ne pas remplir si vous n'avez aucun num�ro ICQ.";
$non_valid_email	= "Votre email n'est pas valide, veuillez ne pas remplir si vous n'avez aucun email.";
$message_incorrect	= "Votre message doit �tre entre";
$and			= "et";
$characters		= "caract�res";

?>