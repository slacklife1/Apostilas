<?
#################################################################################################
#
#  project           	: phpBook
#  filename          	: danish.php
#  last modified by  	: Just Thorning Blindb�k
#  e-mail            	: just@blindbaek.dk
#  purpose           	: Danish language File
#
#################################################################################################

$languagemetatag	= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">";
$gb_link1		= "Skriv indl�g";
$gb_link1desc		= "Tilf�j indl�g";
$gb_link1head		= "Tilf�j indl�g";
$gb_pages		= "Antal sider:";
$gb_name		= "Navn";
$gb_comments		= "Kommentar";
$gb_location		= "Landsdel: ";
$gb_posted		= "Skrevet: ";
$gb_modcomment		= "Louisa kommentar: ";
$gbadd_name		= "Navn :";
$gbadd_location		= "Landsdel :";
$gbadd_email		= "E-mail :";
$gbadd_url		= "URL :";
$gbadd_icq		= "ICQ :";
$gbadd_msg		= "Besked :";
$ad_pages		= "Sider :";
$smiliehelp		= "Klik her for hj�lp til Smileys";
$smiley_help		= "Smiley Hj�lp";
$urlcodehelp		= "Klik her for hj�lp til URL";
$url_code_help		= "URL Hj�lp";
$submit			= "Tilf�j";
$location_sel		= "--------- V�lg Venligst ---------";
$send_email		= "Send E-mail";
$icq_message		= "Send ICQ Besked";
$view_homepage		= "Bes�g hjemmeside";
$ip_logged		= "IP logged";
$banned			= "Spam-skjold aktivt, fors�g venligst senere";
$moderator_del_entry	= "ADMIN slet indl�g";
$moderator_del_comment	= "ADMIN slet kommentar";
$moderator_edit_comment	= "ADMIN rediger kommentar";
$gb_notifysubj		= "Meddel hvis nyt indl�g i g�stebogen";
$notify_text		= "Nyt indl�g i g�stebogen fra";
$name_empty		= "Indtast dit navn";
$icq_wrong		= "Forkert ICQ-nummer, lad blank hvis du ikke har nogen ICQ-nummer.";
$non_valid_email	= "Forkert e-mail, lad blank hvis du ikke har nogen e-mail.";
$message_incorrect	= "Desv�rre, din indl�g skal v�re mellem";
$and			= "og";
$characters		= "tegn";

?>