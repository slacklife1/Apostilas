<?
#################################################################################################
#
#  project            	: phpBook
#  filename            	: indonesian.php
#  last modified by    	: T Wisnu Wardhana
#  e-mail              	: LinuxServ@graffiti.net
#  purpose            	: Indonesian language File
#
#################################################################################################

$languagemetatag        = "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">";
$gb_link1               = "Kirim Pesan";
$gb_link1desc           = "Kirim Pesan anda ke Buku Tamu";
$gb_link1head           = "Kirim Pesan ke Buku Tamu";
$gb_pages               = "Halaman:";
$gb_name                = "Nama";
$gb_comments            = "Komentar";
$gb_location            = "Lokasi: ";
$gb_posted              = "waktu pengiriman: ";
$gb_modcomment          = "Komentar Moderator: ";
$gbadd_name             = "Nama :";
$gbadd_location         = "Lokasi :";
$gbadd_email            = "E-Mail :";
$gbadd_url              = "URL :";
$gbadd_icq              = "ICQ :";
$gbadd_msg              = "Pesan :";
$ad_pages               = "Halaman :";
$smiliehelp             = "Klik disini, untuk Pertolongan Kode-Smilie";
$smiley_help            = "Pertolongan kode Smilie";
$urlcodehelp            = "Klik disini, untuk Pertolongan Kode-URL";
$url_code_help          = "Pertolongan kode URL";
$submit                 = "Kirimkan.!";
$location_sel           = "-------- silahkan pilih --------";
$send_email             = "Kirim E-Mail";
$icq_message            = "Kirim Pesan ICQ";
$view_homepage          = "Kunjungi Website user(s)";
$ip_logged              = "IP logged";
$banned                 = "Floodprotect aktif, silahkan coba lagi nanti !";
$moderator_del_entry    = "MODERATOR Menghapus Pesan";
$moderator_del_comment  = "MODERATOR Menghapus Komentar";
$moderator_edit_comment = "MODERATOR Edit Komentar";
$gb_notifysubj          = "Kabar-Baru pada Buku Tamu ";
$notify_text            = "Pesan Buku Tamu Baru dari";
$name_empty             = "Silahkan ketikkan nama anda.";
$icq_wrong              = "Nomor ICQ tidak valid, jika anda tidak memiliki account icq tolong biarkan kosong.";
$non_valid_email        = "Alamat Email tidak valid, silahkan ketikkan alamat e-mail yang benar atau jika anda tidak memilikinya biarkan kosong.";
$message_incorrect      = "Maaf, pesan anda hanya diantaranya";
$and                    = "dan";
$characters             = "karakter";

?>