<?
################################################################################################
#
#  project          	: phpBook
#  filename             : spanish.php
#  last modified by     : Jose Arce
#  e-mail               : metallian_ccp@hotmail.com
#  purpose              : Spanish language File
#
#################################################################################################

$languagemetatag     	= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">";
$gb_link1              	= "Firma el Libro de Visitas";
$gb_link1desc           = "Firma el libre de visitas";
$gb_link1head           = "Firma el libro de visitas";
$gb_pages               = "Paginas:";
$gb_name                = "Nombre";
$gb_comments            = "Comentarios";
$gb_location            = "Lugar: ";
$gb_posted              = "Puesto: ";
$gb_modcomment          = "Comentario-Moderador: ";
$gbadd_name             = "Nombre :";
$gbadd_location         = "Lugar :";
$gbadd_email            = "E-Mail :";
$gbadd_url              = "URL :";
$gbadd_icq              = "ICQ :";
$gbadd_msg              = "Mensaje :";
$ad_pages               = "Paginas :";
$smiliehelp             = "Haz click aqui para obtener ayuda sobre las sonrisas";
$smiley_help            = "Ayuda sobre las sonrisas";
$urlcodehelp            = "Haz click aqui para obtener ayuda sobre el codigo de URL";
$url_code_help          = "Ayuda sobre codigo de URL";
$submit                 = "Submit";
$location_sel           = "----- selecciona por favor -----";
$send_email             = "Enviar E-Mail";
$icq_message            = "Enviar mensaje de ICQ";
$view_homepage          = "Ver la pagina";
$ip_logged              = "IP registrado";
$banned                 = "Floodprotect activo, intentalo mas tarde";
$moderator_del_entry    = "MODERADOR borrar firma";
$moderator_del_comment  = "MODERADOR borrar comentario";
$moderator_edit_comment = "MODERADOR editar comentario";
$gb_notifysubj          = "NOTIFICACION nueva firma del Libro de Visitas";
$notify_text            = "Nueva firma de";
$name_empty             = "Por favor pon tu nombre.";
$icq_wrong              = "Numero de ICQ no valido, si no tienes ICQ por favor deja ese campo en blanco.";
$non_valid_email        = "E-mail no valido, por favor por una direccion de correo valida o si no tienes deja ese campo en blaco.";
$message_incorrect      = "Lo siento, tu mensaje debe ser de entre";
$and                    = "y";
$characters             = "caracteres";

?>