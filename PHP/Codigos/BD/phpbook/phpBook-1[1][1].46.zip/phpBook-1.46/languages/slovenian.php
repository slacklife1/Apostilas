<?
#################################################################################################
#
#  project           	: phpBook
#  filename          	: Slovenski.php
#  last modified by  	: Hijacker
#  e-mail            	: Hijacker@email.si
#  purpose           	: Slovenian language file
#
#################################################################################################

$languagemetatag	= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1250\">";
$gb_link1		= "Vpi�i se";
$gb_link1desc		= "Tukaj se vpi�e�";
$gb_link1head		= "Tukaj se vpi�e�";
$gb_pages		= "Strani:";
$gb_name		= "Ime";
$gb_comments		= "Komentarji";
$gb_location		= "Lokacija: ";
$gb_posted		= "objavljeno: ";
$gb_modcomment		= "Moderator-Komentar: ";
$gbadd_name		= "Ime :";
$gbadd_location		= "Lokacija :";
$gbadd_email		= "E-Mail :";
$gbadd_url		= "URL :";
$gbadd_icq		= "ICQ :";
$gbadd_msg		= "Sporo�ilo :";
$ad_pages		= "Strani :";
$smiliehelp		= "Klikni tukaj, za pomo� o Sme�ko kodah";
$smiley_help		= "Sme�koti pomo�";
$urlcodehelp		= "Klikni tukaj, za pomo� o URL kodah";
$url_code_help		= "URL koda pomo�";
$submit			= "OK - Vpi�i me";
$location_sel		= "-------- izberi --------";
$send_email		= "Po�lji E-Mail";
$icq_message		= "Po�lji ICQ sporo�ilo";
$view_homepage		= "Doma�a stran";
$ip_logged		= "IP zabele�en";
$banned			= "Floodprotect aktiviran, poskusi kasneje!";
$moderator_del_entry	= "MODERATOR Izbri�i vpis";
$moderator_del_comment	= "MODERATOR Izbri�i komentar";
$moderator_edit_comment	= "MODERATOR Popravi Komentar";
$gb_notifysubj		= "INFO-Nov vpis v knjigi";
$notify_text		= "Nov vnos iz";
$name_empty		= "Vpi�i svoje ime";
$icq_wrong		= "Napa�na ICQ �tevilka. Vpi�i to�no �tevilko. �e nima� ICQ pusti polje prazno.";
$non_valid_email	= "Napa�en email naslov. Vpi�i svoj pravi email naslov �e ga nima� pusti polje prazno.";
$message_incorrect	= "Na�alost, tvoje sporo�ilo mora imeti med";
$and			= "in";
$characters		= "znakov";

?>