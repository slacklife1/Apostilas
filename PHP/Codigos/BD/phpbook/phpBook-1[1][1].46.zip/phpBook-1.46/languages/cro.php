<?
#################################################################################################
#
#  project           	: phpBook
#  filename          	: cro.php
#  last modified by  	: Igor
#  e-mail            	: ikokorus@yahoo.com
#  purpose           	: Croatian language File
#
#################################################################################################

$languagemetatag	= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1250\">";
$gb_link1		= "Upi�ite se";
$gb_link1desc		= "Upi�ite se ovdje";
$gb_link1head		= "Upi�ite se ovdje";
$gb_pages		= "Strana:";
$gb_name		= "Ime";
$gb_comments		= "Upi�i";
$gb_location		= "Iz: ";
$gb_posted		= "upisano: ";
$gb_modcomment		= "Moderator-Komentar: ";
$gbadd_name		= "Ime :";
$gbadd_location		= "Iz :";
$gbadd_email		= "E-Mail :";
$gbadd_url		= "URL :";
$gbadd_icq		= "ICQ :";
$gbadd_msg		= "Sadr�aj :";
$ad_pages		= "Strana :";
$smiliehelp		= "Klikni ovdje, za Smilie-Code pomo�";
$smiley_help		= "Smilie pomo�";
$urlcodehelp		= "Klikni ovde, za URL-Code pomo�";
$url_code_help		= "URL Code pomo�";
$submit			= "OK - Upi�i me";
$location_sel		= "-------- izaberi --------";
$send_email		= "E-Mail poslati";
$icq_message		= "ICQ vijest poslati";
$view_homepage		= "Homepage ";
$ip_logged		= "IP zabilje�ena";
$banned			= "Floodprotect aktivan, probajte kasnije opet!";
$moderator_del_entry	= "MODERATOR Upis izbrisati";
$moderator_del_comment	= "MODERATOR Komentar izbrisati";
$moderator_edit_comment	= "MODERATOR Komentar promijenuti";
$gb_notifysubj		= "INFO- novi upis u knjizi";
$notify_text		= "Upisao ";
$name_empty		= "Upi�ite i svoje ime.";
$icq_wrong		= "Pogre�an ICQ broj. Upi�ite svoj to�an broj, ako nemate ICQ ostavite polje prazno.";
$non_valid_email	= "Pogre�na email adresa. Upi�ite svoju pravu email adresu, ako nemate ostavite polje prazno.";
$message_incorrect	= "Na�alost, sadr�aj mora imati izme�u";
$and			= "i";
$characters		= "slova";

?>