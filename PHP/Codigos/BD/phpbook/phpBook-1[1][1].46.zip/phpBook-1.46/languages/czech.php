<?
#################################################################################################
#
# project 		: phpBook
# filename 		: czech.php
# last modified by 	: Dharma
# e-mail 		: dharma@dharma.cz <mailto:dharma@dharma.cz>
# purpose 		: Czech language File
#
#################################################################################################

$languagemetatag 	= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1250\">";
$gb_link1 		= "P�idat";
$gb_link1desc 		= "P�idan� z�znam";
$gb_link1head 		= "P�idej z�znam";
$gb_pages 		= "Strana:";
$gb_name 		= "Jm�no";
$gb_comments 		= "Koment��";
$gb_location 		= "Zem�:";
$gb_posted 		= "Zapsan�: ";
$gb_modcomment 		= "Moder�tor-pozn�mka: ";
$gbadd_name 		= "Jm�no:";
$gbadd_location 	= "Um�st�n�:";
$gbadd_email 		= "E-mail:";
$gbadd_url 		= "URL:";
$gbadd_icq 		= "ICQ:";
$gbadd_msg 		= "Spr�va:";
$ad_pages 		= "Strana:";
$smiliehelp 		= "Klikni tady-Smilie-Code Help";
$smiley_help 		= "Smilie Help";
$urlcodehelp 		= "Klikni tady-URL-Code Help";
$submit 		= "Ode�li";
$location_sel 		= "-------- v� v�b�r --------";
$send_email 		= "Po�li E-mail";
$icq_message 		= "Po�li ICQ zpr�vu";
$view_homepage 		= "Web str�nka";
$ip_logged 		= "IP p�ihl�en�";
$banned 		= "Ochrana proti floodov�n� zapnuta, zkuste to pozd�ji";
$moderator_del_entry 	= "MODERATOR Smazat";
$moderator_del_comment 	= "MODERATOR Smazat Koment��";
$moderator_edit_comment = "MODERATOR Editovat Koment��";
$gb_notifysubj 		= "NOTIFY - Nov� Guestbook";
$notify_text 		= "Nov� Guestbook - od:";
$name_empty 		= "Zadejte Va�e jm�no.";
$icq_wrong 		= "Nespr�vn� ICQ k�d, pokud nem�te ICQ konto, pole nevypl�ujte!";
$non_valid_email 	= "Nespr�vny e-mail, vlo�te e-mailovou adresu ve spr�vn�m tvaru, nebo pole nevypl�ujte!";
$message_incorrect 	= "Promi�te, va�e zpr�va mus� b�t mezi";
$and 			= "a";
$characters 		= "znak";

?>