<?
#################################################################################################
#
#  project           	: phpBook
#  filename          	: yug.php
#  last modified by  	: Nicky 21.07.2001
#  e-mail            	: nicky@nicky.net
#  purpose           	: Yugoslavian language File
#
#################################################################################################

$languagemetatag	= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1250\">";
$gb_link1		= "Upi�ite se";
$gb_link1desc		= "Upi�ite se ovde";
$gb_link1head		= "Upi�ite se ovde";
$gb_pages		= "Strana:";
$gb_name		= "Ime";
$gb_comments		= "Upisi";
$gb_location		= "Iz: ";
$gb_posted		= "upisano: ";
$gb_modcomment		= "Moderator-Komentar: ";
$gbadd_name		= "Ime :";
$gbadd_location		= "Iz :";
$gbadd_email		= "E-Mail :";
$gbadd_url		= "URL :";
$gbadd_icq		= "ICQ :";
$gbadd_msg		= "Sadr�aj :";
$ad_pages		= "Strana :";
$smiliehelp		= "Klikni ovde, za Smilie-Code pomo�";
$smiley_help		= "Smilie pomoc";
$urlcodehelp		= "Klikni ovde, za URL-Code pomo�";
$url_code_help		= "URL Code pomoc";
$submit			= "OKAY - Upisi me";
$location_sel		= "-------- izaberi --------";
$send_email		= "E-Mail poslati";
$icq_message		= "ICQ vest poslati";
$view_homepage		= "Homepage ";
$ip_logged		= "IP zabele�ena";
$banned			= "Floodprotect aktivan, probajte kasnije opet!";
$moderator_del_entry	= "MODERATOR Upis izbrisati";
$moderator_del_comment	= "MODERATOR Komentar izbrisati";
$moderator_edit_comment	= "MODERATOR Komentar promenuti";
$gb_notifysubj		= "INFO-Novi upis u Knjizi";
$notify_text		= "Upisao ";
$name_empty		= "Ipi�ite i Vase Ime.";
$icq_wrong		= "Pogre�an ICQ broj. Upi�ite Va� ta�an broj, ako nemate ICQ ostavite polje prazno.";
$non_valid_email	= "Pogre�na Email Adressa. Upi�ite va�u ta�nu Email, ako nemate Email ostavite polje prazno.";
$message_incorrect	= "Na�alost, sadr�aj mora imati izmedju";
$and			= "i";
$characters		= "Slova";

?>