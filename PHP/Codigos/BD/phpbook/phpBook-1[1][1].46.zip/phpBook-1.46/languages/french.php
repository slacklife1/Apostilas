<?
#################################################################################################
#
#  project            	: phpBook
#  filename          	: french.php
#  last modified by  	: Cyril GOURGEOT
#  e-mail           	: cyril.gourgeot@wanadoo.fr
#  purpose          	: French language File
#  Date             	: Mai 2nd, 2001
#
#################################################################################################

$languagemetatag    	= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">";
$gb_link1           	= "Ajoutez votre message";
$gb_link1desc        	= "Ajoutez votre message";
$gb_link1head        	= "Ajoutez votre message";
$gb_pages            	= "Pages :";
$gb_name            	= "Nom";
$gb_comments        	= "Commentaires";
$gb_location       	= "Domicile : ";
$gb_posted           	= "Ajout� le : ";
$gb_modcomment       	= "Commentaires du mod�rateur: ";
$gbadd_name           	= "Nom :";
$gbadd_location         = "Domicile :";
$gbadd_email            = "Email :";
$gbadd_url              = "URL :";
$gbadd_icq              = "ICQ :";
$gbadd_msg              = "Message :";
$ad_pages               = "Pages :";
$smiliehelp             = "Cliquez pour obtenir de l'aide sur les Smilies";
$smiley_help            = "Aide Smilies";
$urlcodehelp            = "Cliquez pour obtenir de l'aide sur les codes URL";
$url_code_help          = "Aide codes URL";
$submit                 = "Ajoutez";
$location_sel           = "-------- choisissez --------";
$send_email             = "Envoyez l'email";
$icq_message            = "Envoyez le message ICQ";
$view_homepage          = "Voir le site";
$ip_logged              = "IP enregistr�";
$banned                 = "Floodprotect, essayez plus tard !";
$moderator_del_entry    = "MODERATEUR Effacez le message";
$moderator_del_comment  = "MODERATEUR Effacez le commentaire";
$moderator_edit_comment = "MODERATEUR Corrigez le commentaire";
$gb_notifysubj          = "NOTIFICATION Nouveau message";                         // Subject for Notify E-Mail
$notify_text            = "Nouveau message par";
$name_empty             = "Veuillez inscrire votre nom.";
$icq_wrong              = "Num�ro ICQ invalide, ne pas remplir si vous n'en avez pas.";
$non_valid_email        = "Votre email n'est pas valide, ne pas remplir si vous n'en avez pas.";
$message_incorrect      = "Votre message doit �tre entre";
$and                    = "et";
$characters             = "caract�res";

?>