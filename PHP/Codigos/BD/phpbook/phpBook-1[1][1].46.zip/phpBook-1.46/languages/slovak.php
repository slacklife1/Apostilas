<?
#################################################################################################
#
#  project           	: phpBook
#  filename          	: slovak.php
#  last modified by  	: Lubomir Troppa
#  e-mail            	: lubo@vsld.tuzvo.sk
#  purpose           	: Slovak language File
#
#################################################################################################

$languagemetatag	= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">";
$gb_link1		= "Prida�";
$gb_link1desc		= "Pridan� z�znam";
$gb_link1head		= "Pridaj z�znam";
$gb_pages		= "Strana:";
$gb_name		= "Meno";
$gb_comments		= "Koment�r";
$gb_location		= "Krajina: ";
$gb_posted		= "zap�san�: ";
$gb_modcomment		= "Moder�tor-pozn�mka: ";
$gbadd_name		= "Meno :";
$gbadd_location		= "Umiestnenie :";
$gbadd_email		= "E-Mail :";
$gbadd_url		= "URL :";
$gbadd_icq		= "ICQ :";
$gbadd_msg		= "Spr�va :";
$ad_pages		= "Strana :";
$smiliehelp		= "Klikni sem - Smilie-Code Help";
$smiley_help		= "Smilie Help";
$urlcodehelp		= "Klikni sem - URL-Code Help";
$submit			= "Odo�li";
$location_sel		= "-------- v� v�ber --------";
$send_email		= "Po�li E-Mail";
$icq_message		= "Po�li ICQ spr�vu";
$view_homepage		= "Web str�nka";
$ip_logged		= "IP prihl�senie";
$banned			= "Floodprotect active, please try it later !";
$moderator_del_entry	= "MODERATOR Delete Entry";
$moderator_del_comment	= "MODERATOR Delete Comment";
$moderator_edit_comment	= "MODERATOR Edit Comment";
$gb_notifysubj		= "NOTIFY-New Guestbook Entry";
$notify_text		= "New Guestbook-Entry from";
$name_empty		= "Zadajte Va�e meno.";
$icq_wrong		= "Nespr�vny ICQ k�d, ak nem�te ICQ konto, pole nevyp��ajte !";
$non_valid_email	= "Nespr�vny email, vlozte spr�vnu e-mail adresu, alebo pole nevyp��ajte !";
$message_incorrect	= "Sorry, your message has to be between";
$and			= "a";
$characters		= "znak";

?>