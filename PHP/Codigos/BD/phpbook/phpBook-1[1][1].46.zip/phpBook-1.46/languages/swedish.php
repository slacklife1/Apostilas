<?
#################################################################################################
#
#  project           	: phpBook
#  filename          	: english.php
#  last modified by  	: Reine Larsson
#  e-mail            	: reine@skehus15.ac
#  purpose           	: Swedish language File
#
#################################################################################################

$languagemetatag	= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">";
$gb_link1		= "Skriv inl�gg";
$gb_link1desc		= "L�gg till ditt inl�gg";
$gb_link1head		= "Inl�gg i g�stboken";
$gb_pages		= "Sidor:";
$gb_name		= "Namn";
$gb_comments		= "Meddelande";
$gb_location		= "Landsdel: ";
$gb_posted		= "Skrivet: ";
$gb_modcomment		= "Kommentar: ";
$gbadd_name		= "Namn :";
$gbadd_location		= "Landsdel :";
$gbadd_email		= "E-post :";
$gbadd_url		= "URL :";
$gbadd_icq		= "ICQ :";
$gbadd_msg		= "Meddelande :";
$ad_pages		= "Sidor :";
$smiliehelp		= "Klicka h�r f�r hj�lp med Smilies";
$smiley_help		= "Smilies Hj�lp";
$urlcodehelp		= "Klicka h�r, f�r hj�lp med URL-kod";
$url_code_help		= "URL-Kod Hj�lp";
$submit			= "Skicka";
$location_sel		= "------------ V�lj ------------";
$send_email		= "Skicka E-Post";
$icq_message		= "Skicka ICQ Meddelande";
$view_homepage		= "Bes�k hemsida";
$ip_logged		= "IP loggad";
$banned			= "Spam-skydd akivt, f�rs�k igen senare";
$moderator_del_entry	= "ADMIN Radera inl�gg";
$moderator_del_comment	= "ADMIN Radera kommentar";
$moderator_edit_comment	= "ADMIN Editera kommentar";
$gb_notifysubj		= "Meddelande-Nytt inl�gg i g�stbokens";
$notify_text		= "Nytt g�stboksinl�gg fr�n";
$name_empty		= "Ditt namn, tack.";
$icq_wrong		= "Ogiltigt ICQ-nummer, l�mna f�ltet blankt om du inte anv�nder ICQ.";
$non_valid_email	= "Ogiltig e-post adress, l�mna f�ltet blankt om du inte har n�gon adress.";
$message_incorrect	= "Tyv�rr, ditt meddelande m�ste vara mellan";
$and			= "och";
$characters		= "tecken";

?>