<?
#################################################################################################
#
#  project           	: phpBook
#  filename          	: admin.php
#  last modified by  	: Erich Fuchs
#  e-mail            	: erich.fuchs@netone.at
#  purpose           	: Admin language File
#
#################################################################################################

$languagemetatag	= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">";
$gb_link2               = "Admin";
$gb_link2desc           = "Guestbook Administration";
$gb_link2head           = "Administration";
$gb_link3               = "Bad Words";
$gb_link3desc           = "Bad Words - Administration";
$gb_link3head           = "Bad Words";
$gb_link3text		= "Bad Word: ";
$gb_link3stat		= "Bad Words in [badwords]-Table.";
$gb_link4               = "Banned IPs";
$gb_link4desc           = "Banned IPs - Administration";
$gb_link4head           = "Banned IPs";
$gb_link4text		= "IP: ";
$gb_link4stat		= "Banned IPs in [banned_ips]-Table.";
$gb_link5               = "Guestbook";
$gb_link5desc           = "Back to Guestbook";

?>