<?

#################################################################################################
#
#  project           	: phpBook
#  filename          	: czech.php
#  last modified by  	: Martin Becvar
#  e-mail            	: becvar@vvs-pv.cz
#  purpose           	: Czech language File
#
#################################################################################################

$languagemetatag	= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-2\">";
$gb_link1		= "P�idej koment��";
$gb_link1desc		= "P�idej koment��";
$gb_link1head		= "P�idej koment��";
$gb_pages		= "Strana:";
$gb_name		= "Jm�no";
$gb_comments		= "Koment��";
$gb_location		= "Zem�: ";
$gb_posted		= "Vlo�eno: ";
$gb_modcomment		= "pozn�mka moder�tora: ";
$gbadd_name		= "Jm�no :";
$gbadd_location		= "M�sto :";
$gbadd_email		= "E-mail :";
$gbadd_url		= "URL :";
$gbadd_icq		= "ICQ :";
$gbadd_msg		= "Zpr�va :";
$ad_pages		= "Strana :";
$smiliehelp		= "Klikni sem - Smilie-n�pov�da";
$smiley_help		= "Smilie n�pov�da";
$urlcodehelp		= "Klikni sem - URL-Code Help";
$submit			= "Ode�li";
$location_sel		= "-- v� v�b�r --";
$send_email		= "Po�li e-mail";
$icq_message		= "Po�li ICQ zpr�vu";
$view_homepage		= "Web str�nka";
$ip_logged		= "IP adresa";
$banned			= "Floodprotect active, please try it later !";
$moderator_del_entry	= "MODERATOR Sma� koment��";
$moderator_del_comment	= "MODERATOR Sma� pozn�mku";
$moderator_edit_comment	= "MODERATOR P�idej pozn�mku";
$gb_notifysubj		= "NOTIFY-Nov� koment��";
$notify_text		= "Nov� koment�� od";
$name_empty		= "Zadejte Va�e jm�no.";
$icq_wrong		= "�patn� ICQ k�d, pokud nem�te ICQ konto, pole nevypl�ujte !";
$non_valid_email	= "�patn� e-mail, vlo�te spr�vnou e-mail adresu, nebo pole nevypl�ujte !";
$message_incorrect	= "Promi�te, ale Va�e zpr�va nen� v rozmez�";
$and			= "a�";
$characters		= "znak�";

?>