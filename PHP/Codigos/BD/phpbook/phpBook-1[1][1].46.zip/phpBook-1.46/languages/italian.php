<?
#################################################################################################
#
#  project             	: phpBook
#  filename             : italian.php
#  last modified by     : Daniele Leone
#  e-mail               :
#  purpose              : Italian language File
#
#################################################################################################

$languagemetatag      	= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">";
$gb_link1               = "Inserisci";
$gb_link1desc           = "Inserisci il tuo messaggio";
$gb_link1head           = "Inserisci il messaggio";
$gb_pages               = "Pagine:";
$gb_name                = "Nome";
$gb_comments            = "Commenti";
$gb_location            = "Localit�: ";
$gb_posted              = "pubblicato il: ";
$gb_modcomment          = "Commento del Moderatore: ";
$gbadd_name             = "Nome :";
$gbadd_location         = "Localit� :";
$gbadd_email            = "E-Mail :";
$gbadd_url              = "URL :";
$gbadd_icq              = "ICQ :";
$gbadd_msg              = "Messaggio :";
$ad_pages               = "Pagine :";
$smiliehelp             = "Aiuto per gli smile";
$smiley_help            = "Aiuto per gli Smile";
$urlcodehelp            = "Aiuto per l'URL";
$url_code_help          = "Aiuto per l'URL";
$submit                 = "Invia";
$location_sel           = "-------- seleziona --------";
$send_email             = "Invia E-Mail";
$icq_message            = "Invia Messaggio ICQ";
$view_homepage          = "Sito Web";
$ip_logged              = "IP logged";
$banned                 = "Protezione attiva, prova pi� tardi !";
$moderator_del_entry    = "Elimina il Messaggio";
$moderator_del_comment  = "Elimina il Commento del MODERATORE";
$moderator_edit_comment = "Inserisci-Modifica il Commento del MODERATORE";
$gb_notifysubj          = "NOTIFICA-Nuovo Messaggio nel Guestbook";
$notify_text            = "Nuovo messaggio da";
$name_empty             = "Inserisci il tuo Nome.";
$icq_wrong              = "Numero ICQ non valido, se non hai ICQ, lascialo vuoto.";
$non_valid_email        = "Email non valida, inserisci la tua corretta e-mail. Se non hai una e-mail, lascialo vuoto.";
$message_incorrect      = "Attenzione, il testo del tuo messaggio deve essere compreso tra i";
$and                    = "e";
$characters             = "caratteri";

?>