<?
#################################################################################################
#
#  project           	: phpBook
#  filename          	: english.php
#  last modified by  	: Vilson Cristiano G�rtner
#  e-mail            	: vgartner@univates.br
#  purpose           	: Portuguese-Brazilian language File
#
#################################################################################################

$languagemetatag	= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">";
$gb_link1		= "Registrar Visita";
$gb_link1desc		= "Registre sua visita";
$gb_link1head		= "Registrar visita";
$gb_pages		= "Page:";
$gb_name		= "Nome";
$gb_comments		= "Coment�rios";
$gb_location		= "Localidade: ";
$gb_posted		= "registrado: ";
$gb_modcomment		= "Coment�rios do Moderador: ";
$gbadd_name		= "Nome :";
$gbadd_location		= "Localidade :";
$gbadd_email		= "E-Mail :";
$gbadd_url		= "URL :";
$gbadd_icq		= "ICQ :";
$gbadd_msg		= "Mensagem :";
$ad_pages		= "P�ginas :";
$smiliehelp		= "Clique aqui para ver os c�digos das imagens";
$smiley_help		= "C�digos Imagens - Ajuda";
$urlcodehelp		= "Clique aqui para ajuda no c�digo de URL";
$url_code_help		= "Ajuda no C�digo de URL";
$submit			= "Registrar";
$location_sel		= "-------- selecione --------";
$send_email		= "Enviar E-Mail";
$icq_message		= "Enviar Mensagem ICQ";
$view_homepage		= "Ver P�gina Web";
$ip_logged		= "IP origem";
$banned			= "Prote��o contra excesso de mensagens ativada, tente mais tarde !";
$moderator_del_entry	= "MODERADOR Deletar Registro";
$moderator_del_comment	= "MODERADOR Deletar Coment�rio";
$moderator_edit_comment	= "MODERADOR Editar Coment�rio";
$gb_notifysubj		= "NOTIFICA��O-Novo Registro no Guestbook";
$notify_text		= "Novo registro no Guestbook, de";
$name_empty		= "Por favor, informe o seu nome.";
$icq_wrong		= "ICQ inv�lido. Se voc� n�o tiver uma conta de ICQ, n�o preencha este campo.";
$non_valid_email	= "Email inv�lido. Se voc� n�o tiver Email, n�o preencha este campo.";
$message_incorrect	= "Desculpe, mas sua mensagem deve ter entre";
$and			= "e";
$characters		= "caracteres";

?>