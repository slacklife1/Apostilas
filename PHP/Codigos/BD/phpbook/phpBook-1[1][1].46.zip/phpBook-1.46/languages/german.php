<?
#################################################################################################
#
#  project           	: phpBook
#  filename          	: german.php
#  last modified by  	: Erich Fuchs
#  e-mail            	: erich.fuchs@netone.at
#  purpose           	: German language File
#
#################################################################################################

$languagemetatag	= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">";
$gb_link1		= "Eintragen";
$gb_link1desc		= "Tragen Sie sich ein";
$gb_link1head		= "Eintragen";
$gb_pages		= "Seiten:";
$gb_name		= "Name";
$gb_comments		= "Eintr�ge";
$gb_location		= "Lokation: ";
$gb_posted		= "am: ";
$gb_modcomment		= "Moderator-Kommentar: ";
$gbadd_name		= "Name :";
$gbadd_location		= "Lokation :";
$gbadd_email		= "E-Mail :";
$gbadd_url		= "URL :";
$gbadd_icq		= "ICQ :";
$gbadd_msg		= "Nachricht :";
$ad_pages		= "Seiten :";
$smiliehelp		= "Klicken Sie hier, f�r Smilie-Code Hilfe";
$smiley_help		= "Smilie Hilfe";
$urlcodehelp		= "Klicken Sie hier, f�r URL-Code Hilfe";
$url_code_help		= "URL Code Hilfe";
$submit			= "Abschicken";
$location_sel		= "-------- bitte ausw�hlen --------";
$send_email		= "E-Mail verschicken";
$icq_message		= "ICQ Nachricht verschicken";
$view_homepage		= "Homepage besuchen";
$ip_logged		= "IP gespeichert";
$banned			= "Flutschutz aktiv, bitte probieren Sie es sp�ter nocheinmal !";
$moderator_del_entry	= "MODERATOR Eintrag l�schen";
$moderator_del_comment	= "MODERATOR Kommentar l�schen";
$moderator_edit_comment	= "MODERATOR Kommentar editieren";
$gb_notifysubj		= "INFO-Neuer Eintrag im G�stebuch";
$notify_text		= "Eingetragen von ";
$name_empty		= "Bitte geben Sie Ihr Name ein.";
$icq_wrong		= "Fehlerhafte ICQ Nummer. Tragen Sie Ihre richtige ein oder lassen Sie dieses Feld leer wenn Sie kein ICQ besitzen.";
$non_valid_email	= "Fehlerhafte Email Adresse. Tragen Sie Ihre richtige ein oder lassen Sie dieses Feld leer wenn Sie keine Email besitzen.";
$message_incorrect	= "Leider, aber Ihre Nachricht muss zwischen";
$and			= "und";
$characters		= "Zeichen lang sein";

?>