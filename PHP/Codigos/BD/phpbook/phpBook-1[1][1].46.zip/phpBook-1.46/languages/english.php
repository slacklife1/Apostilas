<?
#################################################################################################
#
#  project           	: phpBook
#  filename          	: english.php
#  last modified by  	: Erich Fuchs
#  e-mail            	: erich.fuchs@netone.at
#  purpose           	: English language File
#
#################################################################################################

$languagemetatag	= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">";
$gb_link1		= "Add Entry";
$gb_link1desc		= "Add your Guestbook Entry";
$gb_link1head		= "Add Guestbook Entry";
$gb_pages		= "Pages:";
$gb_name		= "Name";
$gb_comments		= "Comment's";
$gb_location		= "Location: ";
$gb_posted		= "posted: ";
$gb_modcomment		= "Moderator-Comment: ";
$gbadd_name		= "Name :";
$gbadd_location		= "Location :";
$gbadd_email		= "E-Mail :";
$gbadd_url		= "URL :";
$gbadd_icq		= "ICQ :";
$gbadd_msg		= "Message :";
$ad_pages		= "Pages :";
$smiliehelp		= "Click here, for Smilie-Code Help";
$smiley_help		= "Smilie Help";
$urlcodehelp		= "Click here, for URL-Code Help";
$url_code_help		= "URL Code Help";
$submit			= "Submit";
$location_sel		= "-------- please select --------";
$send_email		= "Send E-Mail";
$icq_message		= "Send ICQ Message";
$view_homepage		= "View Web Page";
$ip_logged		= "IP logged";
$banned			= "Floodprotect active, please try it later !";
$moderator_del_entry	= "MODERATOR Delete Entry";
$moderator_del_comment	= "MODERATOR Delete Comment";
$moderator_edit_comment	= "MODERATOR Edit Comment";
$gb_notifysubj		= "NOTIFY-New Guestbook Entry";
$notify_text		= "New Guestbook-Entry from";
$name_empty		= "Please enter your name.";
$icq_wrong		= "Non-valid ICQ entry, if you do not have an icq account please leave blank.";
$non_valid_email	= "Non-valid Email entry, please enter your correct e-mail address or if you don't have one leave it blank.";
$message_incorrect	= "Sorry, your message has to be between";
$and			= "and";
$characters		= "characters";

?>