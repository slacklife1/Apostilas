<?php

function validatxt($txt){
 $inject=0;

$badword = array(" select","select "," insert"," update","update "," delete","delete "," drop","drop "," destroy","destroy ");
 for($i=0;$i<sizeof($badword);$i++){
  if(substr_count($txt,$badword[$i])!=0){
   $inject=1;
  }
 }

$charvalidos = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789������������������������������������!?@#$%&(){}[]:;,.- ";

 for($i=0;$i<strlen($txt);$i++){
  $char = substr($txt,$i,1);
  if(substr_count($charvalidos,$char)==0){
   $inject=1;
  }
 }

return($inject);

}//end function

?>

<b>ant-sql-inject</b> (comandos do sql e caracteres como aspas e apostrofe n�o s�o aceitos)<p>

<form name="form1" action="inject.php" method="post">
 <input type="text" name="txt"> <input type="submit" value="testa palavra">
</form>

<?php

if($txt){
 if(validatxt($txt)){
  echo("caracteres ou palavra inv�lida");
 }else{
  echo("ok!");
 }
}

?>