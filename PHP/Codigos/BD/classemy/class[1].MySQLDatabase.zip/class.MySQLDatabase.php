<?php

/**
 * @program   class.MySQLDatabase.php
 * @desc      Classe de acesso ao banco de dados MySQL
 * @author    Caio N. Filipini
 * @author    caio_neo@yahoo.com.br
 * @date      22/10/2002
 * @copyright (c) 2002 by Caio N. Filipini
 * @license GNU / General Public Licence
 */
 
class MySQLDatabase {
	// parametros para conexao
	var $dbName;
	var $dbHost;
	var $dbUsername;
	var $dbPassword;

	// armazena o resultado das consultas
	var $result;
	var $numRows;

	// armazena o handle da conexao
	var $conn;
	var $persistent;
	
	/**
	 * Construtor
	 * @param $name nome da base de dados
	 * @param $host host da base de dados
	 * @param $username nome do usuario da base de dados
	 * @param $password senha do usuario
	 */
	function MySQLDatabase($name, $host, $username, $password) {
		$this->dbName = $name;
		$this->dbHost = $host;
		$this->dbUsername = $username;
		$this->dbPassword = $password;
		$this->result = false;
		$this->numRows = 0;
		$this->conn = NULL;
		$this->persistent = false;
	}
	
	/**
	 * Conecta ao banco de dados
	 * @param $persistent false - normal, true - persistente
	 * @return false - falha na conexao, true - conectado
	 */
	function dbConnect($persistent = false) {
		if($persistent) {
			$this->conn = mysql_pconnect($this->dbHost, $this->dbUsername, $this->dbPassword);
			$this->persistent = true;
		} else {
			$this->conn = mysql_connect($this->dbHost, $this->dbUsername, $this->dbPassword);
		}
		
		if($this->conn) {
			// seleciona a base de dados
			mysql_select_db($this->dbName, $this->conn);
			return true;
		}

		return false;
	}

	/**
	 * Consulta a base de dados e armazena o resultado no objeto
	 * @param $query consulta a ser enviada ao servidor
	 * @return false - erro, true - consulta enviada
	 */
	function dbQuery($query) {
		$result = mysql_query($query);

		if($result) {
			$this->result = $result;
			$this->numRows = mysql_num_rows($this->result);
			return true;
		}

		return false;
	}

	/**
	 * Retorna um array com os resultados da consulta
	 * @return $result array de registros
	 */
	function fetchRow() {
		return mysql_fetch_row($this->result);
	}

	/**
	 * Retorna um array associativo com os resultados da consulta
	 * @return $result array de registros
	 */
	function fetchArray() {
		return mysql_fetch_array($this->result);
	}

	/**
	 * Retorna um objeto com os resultados da consulta
	 * @return $result objeto contendo registros
	 */
	function fetchObject() {
		return mysql_fetch_object($this->result);
	}

	/**
	 * Retorna o numero de linhas afetadas pela ultima consulta
	 * @return $rows numero de linhas afetadas
	 */
	function affectedRows() {
		return mysql_affected_rows($this->conn);
	}

	/**
	 * Limpa o ponteiro de resultados
	 */
	function freeResult() {
		return mysql_free_result($this->result);
	}

	/**
	 * Fecha a conexao com o servidor
	 * @return false - falha, true - desconectado
	 */
	function dbDisconnect() {
		if($this->persistent) {
			return mysql_close($this->conn);
		}
	}

}

?>