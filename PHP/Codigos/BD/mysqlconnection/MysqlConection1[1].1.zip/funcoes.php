<? 
########################################################################################
# 
#    - Script Desenvolvido por: adilson de Almeida Pedro                     
#    - E-mail: adilson@muitopouco.com.br                         
#    - site: http://www.muitopouco.com.br 
#     
######################################################################################## 


    //---------------Configura��es gerais----------------- 

    $dominio="www.seudominio.com.br"; 

    $conf_remoto= array('host','db','usuario','senha'); 
    $conf_local= array('host','db','usuario','senha'); 

    //---------------------------------------------------- 


    $servidor=$SERVER_NAME; 


    if($servidor=="$dominio"){ // caso estaja na web configura automaticamente o servidor remoto 

        $host=$conf_remoto[0]; 
        $db=$conf_remoto[1]; 
        $user=$conf_remoto[2]; 
        $pass=$conf_remoto[3]; 

    }else{// ou configura o servidor local 

        $host=$conf_local[0]; 
        $db=$conf_local[1]; 
        $user=$conf_local[2]; 
        $pass=$conf_local[3]; 
    } 
     
    // abre uma conex�o persistente no servidor 
    $con=mysql_pconnect($host,$user,$pass) or die (mysql_error()); 


     
    function conecta($instsql){         
        global $servidor; 
        global $con; 
        global $user; 
        global $host;         
        global $pass; 
        global $db; 
         
        //seleciona o banco de dados 
        $dbs=mysql_select_db("$db") or die(mysql_error()); 

        //executa a consulta 
        $consulta=mysql_query($instsql,$con) or die(mysql_error()); 

        //retorna consulta 
        return $consulta; 
    } 

    function limpa($consulta){

        //libera a mem�ria da consulta 
        mysql_free_result($consulta); 
    } 
?>