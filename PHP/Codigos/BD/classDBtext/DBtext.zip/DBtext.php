<?
class DBtext {
	function DBtext($file, $indices=null, $unico=null) {

		$this->tab = "����";

		$this->line = "���";

		$this->file = $file;

		$this->linhas = array();

		if(is_string($unico)) {
			$this->unico = true;
			$this->id = $unico;
		}
		else {
			$this->unico = false;
		}

		if (!file_exists($file)) {
			$n=0;
			while ($i = array_shift($indices)) {
				$this->indices[$n] = $i;
				$this->indices["$i"] = $n;
				$n++;
			}
		}
		else {
			$fc = file ($file);

			$ind = rtrim(array_shift($fc),"\n\r");

			$inds=split("\t",$ind);
			
			$n=0;
			while ($i = array_shift($inds)) {
				$i=$this->desfiltrar($i);

				if(!$this->unico && preg_match('/\*/',$i)) {
					$this->unico = true;
					$i=preg_replace('/\*/',"",$i);
					$this->id = $i;
				}

				$i=preg_replace('/\*/',"",$i);

				$this->indices[$n] = $i;
				$this->indices["$i"] = $n;
				$n++;
			}

			while ($l = array_shift($fc)) {
				$tex=rtrim($l,"\n\r");

				$cols=split("\t",$tex);

				for ($i = 0; $i < sizeof($cols); $i++) {
					$cols[$i]=$this->desfiltrar($cols[$i]);
				}

				$this->linhas[] = $cols;
			}


		}
	}

	function filtrar($r) {
		$r = ereg_replace($this->tab,"",$r);
		$r = ereg_replace("\t",$this->tab,$r);

		$r = ereg_replace($this->line,"",$r);
		$r = ereg_replace("\r\n",preg_quote($this->line),$r);

		return $r;
	}
	
	function desfiltrar($r) {
		$r = ereg_replace($this->tab,"\t",$r);

		$r = ereg_replace($this->line,"\n",$r);

		return $r;
	}

	function find($a,$b) { // find(indice,procura)

		if(is_int($a)) {
			$nc = $a;
		}
		else {
			$nc = $this->indices[$a];
		}

		for($i=0;$i<sizeof($this->linhas);$i++) {
			if($this->linhas[$i][$nc] == $b) {
				return $i;
			}
		}
		return -1;
	}

	function get($a,$b,$c=false) { // get(coluna,linha) ou get(coluna,indice,procura)

		if(is_int($a)) {
			$nc = $a;
		}
		else {
			$nc=$this->indices[$a];
		}

		if(!$c) {
			$nl = $b;
		}
		else {
			$nl = $this->find($b,$c);
		}

		return $this->linhas[$nl][$nc];

	}

	function set($a,$b,$c,$d=false) { // set(coluna,linha,valor) ou set(coluna,indice,procura,valor)
		if(is_int($a)) {
			$nc = $a;
		}
		else {
			$nc = $this->indices[$col];
		}
	
		if(!$d) {
			$nl = $b;
		}
		else {
			$nl = $this->find($b,$c);
		}

		$this->linhas[$nl][$nc] = $val;
	}

	function add($a=false) { // add(array valores) ou add(string id) ou add()

		$vals = array();

		$nid = $this->indices[$this->id];

		if (is_array($a)) {
			$vals = $a;
		}
		elseif ($this->unico && is_string($a)) {

			for($i=0;$i<sizeof($this->indices)/2;$i++) {

				if($i == $nid) {
					$vals[] = $a;
				}
				else {
					$vals[] = "";
				}
			}

		}
		else {
			for($i=0;$i<sizeof($this->indices)/2;$i++) {
				$vals[] = "";
			}
		}

		if ($this->unico && $this->find($nid,$vals[$nid]) != -1) {
			return false;
		}

		$this->linhas[] = $vals;

		return true;
	}

	function push($cols=null) {
		$this->add($cols);
	}

	function del($a, $b=1, $c=1) { // del(linha [,length]) ou del(indice,procura [,length])

		if(!is_string($b)) {
			$nl = $a;
			$len = $b;
			if ($nl<0) {
				$nl = count($this->linhas)+$nl;
			}
		}
		else {
			$nl = $this->find($a,$b);
			$len = $c;
		}



		array_splice ($this->linhas, $nl,$len);	
	}

	function splice($a, $b=1, $c=1) {
		$this->del($a,$b,$c);
	}

	function slice($a, $b) {
		return array_slice($this->linhas,$a,$b);
	}

	function count() {
		return count($this->linhas);
	}

	function save() {
		$fp = fopen ($this->file, "wb");
		$numc = sizeof($this->indices)/2;
		$numl = sizeof($this->linhas);

		for($i=0;$i<$numc;$i++) {
			$ind = $this->filtrar($this->indices[$i]);
			if ($this->id == $this->indices[$i]) {
				fputs ($fp,$ind."*");
			}
			else {
				fputs ($fp,$ind);
			}

			if($i<$numc-1) {
				fputs ($fp,"\t");
			}
			else {
				fputs ($fp,"\n");
			}
		}


		for($i=0;$i<$numl;$i++) {
			for($g=0;$g<$numc;$g++) {
				$val = $this->filtrar($this->linhas[$i][$g]);
		
				fputs ($fp,$val);
		
	
				if($g<$numc-1) {
					fputs ($fp,"\t");
				}
				elseif ($i<$numl-1) {
					fputs ($fp,"\n");
				}
			}
		}

		fclose($fp);
	}
}

// *********** ILUSTRA��O ************** //

echo "<pre>";

// Tempo inicial
$inicio=time();

// Nova DataBase, n�o poder� haver dois registros com o mesmo nome (3.� par�metro)
$a = new DBtext("teste.txt",array("nome","idade"),"nome");


// Adicionando registros de 0 a 99
for($i=0;$i<100;$i++) {
	$a->add(array("nome $i","$i"));
}


// Encontrando o n�mero do registro
$nome = "nome 23";
$n = $a->find("nome",$nome);
echo "O registro cujo 'nome' � '$nome' � $n.\n\n";


// Obtendo um valor (idade) espec�fico de um �ndice (nome)
$nome = "nome 45";
$idade = $a->get("idade","nome",$nome);
echo "A idade de '$nome' � '$idade'!\n\n";


// Removendo o segundo e o pen�ltimo registro
$a->del(1);
$a->del(-2);

// Removendo 5 registros a partir do 7.�
$a->splice(6,5);

// Adicionando registro em branco
$a->add();

// Idem
$a->push();


// Obtendo 5 registros a partir do registro 10-para-o-final, coloca em array
$parte = $a->slice(-10,5);
echo "Cinco registros: \n";
print_r($parte);
echo "\n";


// Objendo o n�mero de registros
$n = $a->count();
echo "Tamanho: $n\n\n";

// Salvando
$a->save();

// Tempo final
$fim=time();

// Imprime a dura��o
echo "Tempo: ".($fim-$inicio)." segundo(s)!";

echo "</pre>";

?>
