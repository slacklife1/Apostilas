<?
class DBlongtext {
	function DBlongtext($file, $indices=null) {
																
		$this->tab = "����";
		
		$this->line = "���";
		
		$this->file = $file;
		
  		if (file_exists($file)) {
  				
   			$this->fp = fopen ($this->file, "a+b");

			fputs ($this->fp,"");
      		
        	$ind = rtrim(fgets($this->fp,4096),"\n\r");
			$inds=split("\t",$ind);
			
			$n=0;
			while ($i = array_shift($inds)) {
				$i=$this->desfiltrar($i);
				
				$this->indices[$n] = $i;
				$this->indices["$i"] = $n;
				$n++;
			}
		
  		}
  		else {

  			$this->fp = fopen ($this->file, "a+b");

			$n=0;
			while ($i = array_shift($indices)) {
				$this->indices[$n] = $i;
				$this->indices["$i"] = $n;
				$n++;
			}
			
            $numc = sizeof($this->indices)/2;
            
   			for($i=0;$i<$numc;$i++) {
				$ind = $this->filtrar($this->indices[$i]);
				
				fputs ($this->fp,$ind);
		 		
			 	if($i<$numc-1) {
					fputs ($this->fp,"\t");
				}
				else {
					fputs ($this->fp,"\n");
				}
			}
  		}
  		$this->set_lines();
	}
	
	function set_lines () {
		$this->setlines = array();
        
        fseek($this->fp,0);
		while(fgets($this->fp)) {    		
        	$this->setlines[] = ftell($this->fp);
   		}
   		array_pop($this->setlines);	
	}
	
	function filtrar($r) {
		$r = ereg_replace($this->tab,"",$r);
		$r = ereg_replace("\t",$this->tab,$r);
		
		$r = ereg_replace($this->line,"",$r);
		$r = ereg_replace("\r\n",preg_quote($this->line),$r);
		
		return $r;
	}
	 
	function desfiltrar($r) {
		$r = ereg_replace($this->tab,"\t",$r);
		
		$r = ereg_replace($this->line,"\n",$r);
		
		return $r;
	}
	
	function get($col,$lin) {

		if(!is_int($col)) {
			$col = $this->indices[$col]; 
		}

		$cols = $this->get_line($lin);
		
		return $cols[$col];
	}
	
	function get_line($lin) {

		fseek ($this->fp,$this->setlines[$lin]); 

  		$buffer = fgets($this->fp,4096);

		$linha=rtrim($buffer,"\n\r");
		
		$cols=split("\t",$linha);
		
		for ($i=0;$i<sizeof($cols);$i++) {
			$cols[$i]=$this->desfiltrar($cols[$i]);
		}

		return $cols;
	}
	
	function slice($lin, $len="nda") {

		if ($lin<0) {
			$lin = count($this->setlines)+$lin;
		}
  		
		if ($len == "nda") {
  			$len = count($this->setlines)-$lin;
  		}
				
		fseek ($this->fp,$this->setlines[$lin]);
  
        $r =  array();
  		
  		for($n=0;$n<$len;$n++) {
			$buffer = fgets($this->fp,4096);
	    
	    	$linha=rtrim($buffer,"\n\r");
			
	  		$cols=split("\t",$linha);
	   		
	     	for ($i=0;$i<sizeof($cols);$i++) {
				$cols[$i]=$this->desfiltrar($cols[$i]);
			}
	      	
	      	$r[] = $cols;
      	}
    	
       	return $r;
	}
	
	function add($cols=null) {

		fseek($this->fp,0,SEEK_END);
		
    	$this->setlines[] = ftell($this->fp);

  		if (!is_array($cols)) {
			$cols=array();

			for($i=0;$i<sizeof($this->indices)/2;$i++) {
				$cols[]="";			
			}
		}
		
		for($i=0;$i<count($cols);$i++) {
			$cols[$i]=$this->filtrar($cols[$i]);
		}
		
	 	$linha = implode("\t",$cols);
	 	$linha .= "\n";
	 	
	 	return fputs ($this->fp,$linha,4096);
	}
	
	function push($cols=null) {
		return $this->add($cols);
	}
	
	function del($lin, $len=1) {
		return $this->splice ($lin,$len);	
	}
	
	function splice($lin, $len="nda") {
		
  		if ($lin<0) {
			$lin = count($this->setlines)+$lin;
		}
  		
		if ($len == "nda") {
  			$len = count($this->setlines)-$lin;
  		}
  		
  		fseek($this->fp,$this->setlines[$lin+$len]);
  		
 		$stat = fstat($this->fp);
 		
		$trash = fread($this->fp,$stat[7]);
   
     	ftruncate($this->fp,$this->setlines[$lin]);
 		
 		fseek($this->fp,0,SEEK_END);

   		fputs($this->fp,$trash);

  		$this->set_lines();	
	}
	
 	function count() {
		return count($this->setlines);
	}
	
	function save() {
	 	fclose($this->fp);
	}
}

/*
// *********** ILUSTRA��O ************** //

echo "<pre>";

// Tempo inicial
$inicio=time();

// Nova DataBase
$a = new DBlongtext("teste.txt",array("nome","idade"));

// Adicionando registros de 0 a 999
for($i=0;$i<1000;$i++) {
	$a->add(array("nome $i","idade $i"));
}

// Removendo o segundo e o pen�ltimo registro
$a->del(1);
$a->del(-2);

// Removendo 5 registros a partir do 7.�
$a->splice(6,5);

// Adicionando registro em branco
$a->add();

// Idem
$a->push();

// Obtendo 15 registros a partir do registro 100-para-o-final; coloca em array
$parte = $a->slice(-100,15);
print_r($parte);

// Objendo o n�mero de registros
$n = $a->count();
echo "tamanho: $n\n\n";

// Tempo final
$fim=time();

// Imprime a dura��o
echo "tempo: ".($fim-$inicio)." segundo(s)!";

echo "</pre>";
*/
?>
