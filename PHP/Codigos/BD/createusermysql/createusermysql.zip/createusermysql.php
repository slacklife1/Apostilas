<?

/*
 *	 |_ |_      |_|_    |_          |_|_          |_  |_    |_
 *	 |_   |_  |_    |_  |_|_|_    |_    |_    |_|_|_    |_ |_
 *	 |_   |_  |_    |_  |_    |_  |_    |_  |_    |_      |_
 *	 |_   |_    |_|_    |_|_|_      |_|_      |_|_|_     |_
 */

   ### informa��es do servidor mySQL
   $server = "";// host do servidor mysql
   $user   = "";// nome do usu�rio root
   $pass   = "";// senha do usu�rio root
   $bco    = "mysql";// nome do banco de dados do servidor
                     // onde ficam armazenadas as senhas

   ### informa��es do usu�rio
   $userid  = '';// nome do usu�rio
   $passwd  = '';// senha do usu�rio
   $bcouser = '';// banco de dados do usu�rio

   ### conecta ao servidor mySQL
   $conn = mysql_connect($server,$user,$pass);
   
   ### conecta ao banco de dados mysql p/ adicionar novo usu�rio
   mysql_select_db($bco,$conn);
   
   ### insere informa��es do usu�rio no banco de dados mysql
   $sql_user  = " insert into user ";
   $sql_user .= " (host, user, password, select_priv, insert_priv, update_priv, ";
   $sql_user .= " delete_priv, create_priv, drop_priv, reload_priv, shutdown_priv, ";
   $sql_user .= " process_priv, file_priv, grant_priv, references_priv, index_priv, ";
   $sql_user .= " alter_priv) values ";
   $sql_user .= " ('$server', '$userid', password('$passwd'), 'Y', 'Y', 'Y', ";
   $sql_user .= " 'Y', 'Y', 'Y', 'Y', 'Y', ";
   $sql_user .= " 'Y', 'Y', 'Y', 'Y', 'Y', 'Y') ";

   ### adiciona permiss�es p/ usu�rio
   ### neste caso abaixo permiss�o root
   $sql_perm  = " GRANT ALL PRIVILEGES ON *.* TO $userid@$host IDENTIFIED BY '$passwd' ";
   
   ### neste caso abaixo permiss�o p/ todas tabelas de um banco
   // $sql_perm  = " GRANT ALL PRIVILEGES ON nomedobanco.* TO $userid@$host IDENTIFIED BY '$passwd' ";

   ### neste caso abaixo permiss�o p/ determinada tabela de um banco
   // $sql_perm  = " GRANT ALL PRIVILEGES ON nomedobanco.nomedatabela TO $userid@$host IDENTIFIED BY '$passwd' ";

   ### executa sql_insert
   mysql_query($sql_insert);
   
   ### executa sql_perm
   mysql_query($sql_perm);

   ### status do processo
   if (!mysql_error()){
       echo "Usu�rio Cadastrado!!!<br>";
   } else {
       echo mysql_error();
   }
   
?>
