<html>

<head>
  <title>EuMesmo MyPHP Wizard</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<?php

error_reporting(E_ERROR);
import_request_variables("GPC", '');
$PHP_SELF=$HTTP_SERVER_VARS['PHP_SELF'];

if (!isset($action)){$action='tablelist';}

// Generate
if ($action == 'generate') {
	$dbh=MYSQL_CONNECT($host, $user, $pswd) OR DIE("N�o foi poss�vel conex�o com a base de dados.");
	@mysql_select_db($database) or die("N�o foi poss�vel selecionar a base de dados.");

	$inc_file_name = $table_name . '.inc.php';
	$query = "SELECT * FROM $table_name";
	$result = mysql_query($query);

	if (mysql_errno() == 0) {
	  $num_fields = mysql_num_fields($result);

	  $keyfieldok = false;
	  for ($i=0; $i<$num_fields; $i++)
	  {
	    $field = mysql_fetch_field($result);
	    $fields_array[$i] = $field->name;

	    if ($field->name == $pkey_name){
	      $keyfieldok = true;
	    }
	  }
	  mysql_free_result($result);

	  if ($keyfieldok == false){
	    print "<h1>Error.</h1>\n";
	    print "<p>A tabela <b>$table_name</b> n�o possui o campo<b>$pkey_name</b> especificado como <b>Primary Key</b>!</p>\n";
	    print "</body>\n\n</html>\n";
	    exit;
	  }

	  $str_Like = " WHERE (";
	  $str_Table_Title = "";
	  $str_inc = "<?php
	global \$PHP_SELF;
	global \$orderby;
	global \$find;
	\$sel_bcolor = '0,0,0';
	\$sel_fcolor = '255,255,255';
	print \"<tr>\\n\";\r\n";
	  $str_Update_query = "UPDATE $table_name SET";
	  $str_Insert_query = "INSERT INTO $table_name (";
	  $str_Select_where = "SELECT * FROM $table_name WHERE ($pkey_name=\$id)";
	  $str_Delete_query = "DELETE FROM $table_name WHERE ($pkey_name=\$id)";
	  $str_function_body = "  if (isset(\$row)){\n";
	  for ($i=0; $i<$num_fields; $i++)
	  {
	    if ($i==0){
	      $str_Like = $str_Like . "$fields_array[$i] LIKE '%\$find%'";
	    }
	    else {
	      $str_Like = $str_Like . " OR $fields_array[$i] LIKE '%\$find%'";
	    }

      if (! isset($HTTP_POST_VARS[$fields_array[$i]])) {$HTTP_POST_VARS[$fields_array[$i]] = '';}
      if ($HTTP_POST_VARS[$fields_array[$i]] == 'ON') {
        $str_Table_Title = $str_Table_Title . "  print \"<td><a href=\\\"\$PHP_SELF?stpage=\$stpage&find=\$find&orderby=$fields_array[$i]\\\"><img src=\\\"arrow.gif\\\" alt=\\\"Ordena Por $fields_array[$i]\\\" border=\\\"0\\\"><br><b>$fields_array[$i]</b></a></td>\\n\";\r\n";
	      $str_inc = $str_inc . "print \"<td>\" . pdb_highlighter(\$row->$fields_array[$i],\$find,\$sel_bcolor,\$sel_fcolor,'_blank',true,true,true) . \"</td>\\n\";\r\n";
      }

	    $str_Update_query = $str_Update_query . " $fields_array[$i]='\$$fields_array[$i]'";
	    $str_Insert_query = $str_Insert_query . $fields_array[$i];
	    $str_function_body = $str_function_body . "    \$$fields_array[$i] = \$row->$fields_array[$i];\r\n";
	    if ($i+1 < $num_fields){
	      $str_Update_query = $str_Update_query . ',';
	      $str_Insert_query = $str_Insert_query . ',';
	    }
	  }
	  $str_Like = $str_Like . ")";
	  $str_inc = $str_inc .
	"print \"<td><a href=\\\"\$PHP_SELF?action=edit&stpage=\$stpage&orderby=\$orderby&find=\$find&id=\$row->$pkey_name\\\"><img src=\\\"editar.gif\\\" alt=\\\"Editar Dado\\\" border=0></a></td>\\n\";
	print \"<td><a href=\\\"\$PHP_SELF?action=confirm&stpage=\$stpage&orderby=\$orderby&find=\$find&id=\$row->$pkey_name\\\"><img src=\\\"apagar.gif\\\" alt=\\\"Apagar Dado\\\" border=0></a></td>\\n\";
	print \"</tr>\\n\";\r\n?>\r\n";
	  $str_Update_query = $str_Update_query . " WHERE($pkey_name=\$id)";
	  $str_Insert_query = $str_Insert_query . ") VALUES (";
	  $str_function_body = $str_function_body . "  }\n  else {\r\n";

	  for ($i=0; $i<$num_fields; $i++)
	  {
	    $str_Insert_query = $str_Insert_query . "'\$$fields_array[$i]'";
	    $str_function_body = $str_function_body . "    \$$fields_array[$i] = '';\r\n";
	    if ($i+1 < $num_fields){
	      $str_Insert_query = $str_Insert_query . ',';
	    }
	  }
	  $str_Insert_query = $str_Insert_query . ')';
	  $str_function_body = $str_function_body . "  }\r\n";

	  for ($i=0; $i<$num_fields; $i++)
	  {
	    $str_function_body = $str_function_body . "  print \"<tr><td>$fields_array[$i]: </td><td><input type=\\\"text\\\" name=\\\"$fields_array[$i]\\\" value=\\\"\$$fields_array[$i]\\\"></td></tr>\\n\";\r\n";
	  }

	  $filename = "generator.dat";
	  $fp = fopen ($filename, "r");
	  $contents = fread($fp, filesize ($filename));
	  fclose ($fp);

	  $contents = ereg_replace("<%GN_LIKE%>",$str_Like,$contents);
	  $contents = ereg_replace("<%GN_TITLE%>",$str_Table_Title,$contents);
	  $contents = ereg_replace("<%GN_SELECT_WHERE%>",$str_Select_where,$contents);
	  $contents = ereg_replace("<%GN_UPDATE%>",$str_Update_query,$contents);
	  $contents = ereg_replace("<%GN_DELETE%>",$str_Delete_query,$contents);
	  $contents = ereg_replace("<%GN_INSERT%>",$str_Insert_query,$contents);
	  $contents = ereg_replace("<%GN_PKEY%>",$pkey_name,$contents);
	  $contents = ereg_replace("<%GN_TABLE_NAME%>",$table_name,$contents);
	  $contents = ereg_replace("<%GN_INC_FILE%>",$inc_file_name,$contents);
	  $contents = ereg_replace("<%GN_RECORDS_ON_PAGE%>","$records_on_page",$contents);
	  $contents = ereg_replace("<%GN_FUNCTION_BODY%>",$str_function_body,$contents);

	  // Save Files
	  $filename = $table_name . ".php";
	  $fp = fopen ($filename, "w");
	  fwrite($fp, $contents);
	  fclose ($fp);

	  $fp = fopen ($inc_file_name, "w");
	  fwrite($fp, $str_inc);
	  fclose ($fp);

	  $str_connect = "<?php
	\$host='$host';
	\$database='$database';
	\$user='$user';
	\$pswd='$pswd';

	\$dbh=MYSQL_CONNECT(\$host, \$user, \$pswd) OR DIE(\"N�o foi poss�vel conex�o com a base de dados.\");
	@mysql_select_db(\$database) or die(\"N�o foi poss�vel selecionar a base de dados.\");
	?>";

	  $fp = fopen ("connect.php", "w");
	  fwrite($fp, $str_connect);
	  fclose ($fp);
	  print "<h1>EuMesmo MyPHP Wizard<br>Pronto.</h1>\n";
	  print "<table border=\"0\">\n";
	  print "<tr><td>\n";
	  print "  <table border=\"0\">\n";
	  print "  <tr><td>Veja os Arquivos Gerados:</td></tr>\n";
	  print "  <tr><td><b>$filename<br>$inc_file_name</b><br><br>Arquivos do Sistema:<br><b>connect.php<br>pdb.php<br>style.css</b></td></tr>\n";
	  print "  <tr><td>Abra o Script <a href=\"$filename\">$filename</a></td></tr>\n";
	  print "  </table>";
	  print "</td>\n";
	  print "</td></tr>\n";
	  print "</table>\n";
	}
	else {
	  print "Erro. Favor checar os par�mentros.";
	}
}

// Tables List
if ($action == 'tablelist') {
  print "<h1>Por favor, selecione uma tabela.</h1>\n\n";
  $dbh=MYSQL_CONNECT($host, $user, $pswd) OR DIE("N�o foi poss�vel conex�o com a base de dados.");
	@mysql_select_db($database) or die("N�o foi poss�vel selecionar a base de dados.");

  $result = mysql_list_tables($database);
  if (!$result) {
    print "Erro na base de dados, n�o foi poss�vel listar as tabelas\n";
    print 'Erro MySQL: ' . mysql_error() . "\n";
    print "</body>\n\n</html>\n";
    exit;
  }
  print "<table border=\"0\">\n";
  print "<tr><td>\n";
  print "<table>\n";
  while ($row = mysql_fetch_row($result)) {
    print "<tr><td>&nbsp;<b>$row[0]</b>&nbsp;</td><td>";
	  print "<form action=\"$PHP_SELF\" method=\"post\">\n";
	  print "<input name=\"action\" type=\"hidden\" value=\"fieldlist\">\n";
	  print "<input type=\"hidden\" name=\"host\" value=\"$host\">\n";
	  print "<input type=\"hidden\" name=\"database\" value=\"$database\">\n";
	  print "<input type=\"hidden\" name=\"user\" value=\"$user\">\n";
	  print "<input type=\"hidden\" name=\"pswd\" value=\"$pswd\">\n";
	  print "<input name=\"table_name\" type=\"hidden\" value=\"$row[0]\">\n";
      print "<input class=\"clsButton2\" type=\"submit\" value=\"Avan�ar >>\">";
	  print "</form>\n";
    print "</td></tr>\n";
  }
  print "</table>\n\n";
  print "</td></tr>\n";
  print "</table>\n";
  mysql_free_result($result);
}

// Fields Options
if ($action == 'fieldlist') {
  print "<h1>Por favor, especifique as op��es de colunas desejadas.</h1>\n\n";
  $dbh=MYSQL_CONNECT($host, $user, $pswd) OR DIE("N�o foi poss�vel conectar na base de dados.");
	@mysql_select_db($database) or die("N�o foi poss�vel selecionar a base de dados.");

  $fields = mysql_list_fields($database, $table_name, $dbh);
  $columns = mysql_num_fields($fields);

  print "<form action=\"$PHP_SELF\" method=\"post\">\n";
  print "<input name=\"action\" type=\"hidden\" value=\"generate\">\n";
  print "<input type=\"hidden\" name=\"host\" value=\"$host\">\n";
	print "<input type=\"hidden\" name=\"database\" value=\"$database\">\n";
	print "<input type=\"hidden\" name=\"user\" value=\"$user\">\n";
	print "<input type=\"hidden\" name=\"pswd\" value=\"$pswd\">\n";
	print "<input name=\"table_name\" type=\"hidden\" value=\"$table_name\">\n";

  print "<b>Selecione a coluna que est� marcada como <i>Primary</i> Key na sua base de dados:</b><br>\n";
  print "<select size=\"1\" name=\"pkey_name\">\n";
  for ($i = 0; $i < $columns; $i++) {
    $FieldName = mysql_field_name($fields, $i);
    print "<option value=\"$FieldName\">$FieldName</option>\n";
  }
	print "</select>\n";
  print "<p></p>\n";
  print "<b>Dados por p�gina:</b><br>\n";
  print "<input type=\"text\" name=\"records_on_page\" value=\"20\">\n";
  print "<p></p>\n";
  print "<b>Marque os campos que voc� deseja que apare�am no script:</b>\n";
  print "<table border=\"0\">\n";
  print "<tr><td>\n";
  print "<table>\n";
  for ($i = 0; $i < $columns; $i++) {
    $FieldName = mysql_field_name($fields, $i);
    print "<tr><td><b>$FieldName</b></td><td>\n";
    print "<input type=\"checkbox\" name=\"$FieldName\" value=\"ON\" checked>\n";
    print "</td></tr>\n";
  }
  print "</table>\n";
  print "</td></tr>\n";
  print "</table>\n";
  print "<p><input class=\"clsButton2\" type=\"submit\" value=\"Finalizar >>\"></p>\n";
  print "</form>\n";
}

print "<p>&copy; Neander Ara�jo - EuMesmo - 2003</p>";

?>
</body>

</html>
