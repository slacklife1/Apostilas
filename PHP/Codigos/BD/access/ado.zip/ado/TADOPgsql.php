<?php
	require_once('TAdo.php');
	class TADOPgsql extends TAdo{
	
		function TADOPgsql($host,$banco,$user,$senha) {
			$this->host = $host;
			$this->banco = $banco;
			$this->user = $user;
			$this->senha = $senha;		
			return false;
		}

		function db_connect() {
			if ($conn = pg_connect("host=$this->host dbname=$this->banco user=$this->user password=$this->senha")) {
				return $conn;
			}
			else {
				return false;
			}
		}

		function db_close($conn) {
			if (pg_close($conn)) {
				return true;
			}
			else {
				return false;
			}
		}

		function query($sql) {
			$this->conn = $this->db_connect() or die ("N�o � poss�vel connectar ao banco de dados.");
			if ($res = pg_query($this->conn,$sql)) {
				pg_close($this->conn);
				return $res;
			}
			else {
				pg_close($this->conn);			
				return false;
			}
		}

		function to_array($res) {
			if ($linha = pg_fetch_array($res)) {
				return $linha;
			}
			else {
				return false;
			}
		}
		
		function num_rows($res) {
			if ($num = pg_num_rows($res)) {
				return $num;
			}
			else {
				return false;
			}
		}

		function num_fields($res) {
			if ($num = pg_num_fields($res)) {
				return $num;
			}
			else {
				return false;
			}
		}

		function affected_rows($res) {
			if ($num = pg_affected_rows($res)) {
				return $num;
			}
			else {
				return false;
			}
		}
		
	}
?>