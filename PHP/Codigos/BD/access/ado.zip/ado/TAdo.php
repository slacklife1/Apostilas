<?php
	class TAdo {
		var $conn;	
		var	$host;
		var	$banco;
		var	$user;
		var	$senha;
		function db_connect() {
		}
		
		function db_name($banco,$conn) {
			echo "Esse m�todo n�o est� dispon�vel neste banco de dados.";		
		}

		function query($sql) {
			echo "Esse m�todo n�o est� dispon�vel neste banco de dados.";				
		}

		function to_array($res) {
			echo "Esse m�todo n�o est� dispon�vel neste banco de dados.";				
		}
		
		function num_rows($res) {
			echo "Esse m�todo n�o est� dispon�vel neste banco de dados.";				
		}

		function num_fields($res) {
			echo "Esse m�todo n�o est� dispon�vel neste banco de dados.";				
		}

		function affected_rows($res) {
			echo "Esse m�todo n�o est� dispon�vel neste banco de dados.";				
		}		
		function db_close() {
			echo "Esse m�todo n�o est� dispon�vel neste banco de dados.";						
		}
	}
?>