<?php
	require_once('TAdo.php');
	class TADOIbase extends TAdo{
		function TADOIbase($host,$user,$senha) {
			$this->host = $host;
			$this->user = $user;
			$this->senha = $senha;

		}
		function db_connect() {
			if ($conn = ibase_connect($this->host,$this->user,$this->senha)) {
				return $conn;
			}
			else {
				return false;
			}
		}

		function db_close($conn) {
			if (ibase_close($conn)) {
				return true;
			}
			else {
				return false;
			}
		}

		function query($sql) {
			$this->conn = $this->db_connect() or die ("N�o � poss�vel connectar ao banco de dados.");
			if ($res = ibase_query($this->conn,$sql)) {
				$this->db_close($this->conn);
				return $res;
			}
			else {
				$this->db_close($this->conn);			
				return false;
			}
		}

		function to_array($res) {
			if ($linha = ibase_fetch_assoc($res)) {
				return $linha;
			}
			else {
				return false;
			}
		}
		
		function num_fields($res) {
			if ($num = ibase_num_fields($res)) {
				return $num;
			}
			else {
				return false;
			}
		}

		function affected_rows($res) {
			if ($num = ibase_affected_rows($res)) {
				return $num;
			}
			else {
				return false;
			}
		}
		
	}
?>