<?php
	require_once('TAdo.php');
	class TADOSqlserver extends TAdo{

		function TADOSqlserver($host,$banco,$user,$senha) {
			$this->host = $host;
			$this->banco = $banco;
			$this->user = $user;
			$this->senha = $senha;		
			return true;
		}
	
		function db_connect() {
			if ($conn = mssql_connect($this->host,$this->user,$this->senha)) {
				if ($db = mssql_select_db($this->banco,$conn)) {
					return $conn;
				}
			}
			else {
				return false;
			}
		}

		function db_close($conn) {
			if (mssql_close($conn)) {
				return true;
			}
			else {
				return false;
			}
		}

		function db_name($banco) {
			if ($db = mssql_select_db($banco,$this->conn)) {
				$this->banco = $banco;			
				return $db;
			}
			else {
				return false;
			}
		}

		function query($sql) {
			$this->conn = $this->db_connect() or die ("N�o � poss�vel connectar ao banco de dados.");
			if ($res = mssql_query($sql,$this->conn)) {
				$this->db_close($this->conn);
				return $res;
			}
			else {
				$this->db_close($this->conn);			
				return false;
			}
		}

		function to_array($res) {
			if ($linha = mssql_fetch_array($res)) {
				return $linha;
			}
			else {
				return false;
			}
		}
		
		function num_rows($res) {
			if ($num = mssql_num_rows($res)) {
				return $num;
			}
			else {
				return false;
			}
		}

		function num_fields($res) {
			if ($num = mssql_num_fields($res)) {
				return $num;
			}
			else {
				return false;
			}
		}

		function affected_rows($res) {
			if ($num = mssql_rows_affected($res)) {
				return $num;
			}
			else {
				return false;
			}
		}
		
	}
?>