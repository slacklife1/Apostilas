<?php
	require_once('TAdo.php');
	class TADOOdbc extends TAdo{
		function TADOOdbc($banco,$user,$senha) {
			$this->banco = $banco;
			$this->user = $user;
			$this->senha = $senha;
		}
		function db_connect() {
			if ($conn = odbc_connect($this->banco,$this->user,$this->senha)) {
				return $conn;
			}
			else {
				return false;
			}
		}

		function db_close($conn) {
			if (odbc_close($conn)) {
				return true;
			}
			else {
				return false;
			}
		}

		function query($sql) {
			$this->conn = $this->db_connect() or die ("N�o � poss�vel connectar ao banco de dados.");
			if ($res = odbc_exec($this->conn,$sql) or die ("Inv�lida: ".odbc_errormsg())) {
				return $res;
			}
			else {
				$this->db_close($this->conn);			
				return false;
			}
		}

		function to_array($res) {
			if ($linha = odbc_fetch_array($res)) {
				return $linha;
			}
			else {
				return false;
			}
		}
		
		function num_rows($res) {
			if ($num = odbc_num_rows($res)) {
				return $num;
			}
			else {
				return false;
			}
		}

		function num_fields($res) {
			if ($num = odbc_num_fields($res)) {
				return $num;
			}
			else {
				return false;
			}
		}	
	}
?>