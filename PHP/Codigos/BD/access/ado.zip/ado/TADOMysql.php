<?php
	require_once('TAdo.php');
	class TADOMysql extends TAdo{

		function TADOMysql($host,$banco,$user,$senha) {
			$this->host = $host;
			$this->banco = $banco;
			$this->user = $user;
			$this->senha = $senha;		
			return true;
		}
		
		function db_connect() {
			if ($conn = mysql_connect($this->host,$this->user,$this->senha)) {
				if ($db = mysql_select_db($this->banco,$conn)) {
					return $conn;
				}
			}
			else {
				return false;
			}
		}

		function db_close($conn) {
			if (mysql_close($conn)) {
				return true;
			}
			else {
				return false;
			}
		}

		function db_name($banco) {
			if ($db = mysql_select_db($banco,$this->conn)) {
				$this->banco = $banco;
				return $db;
			}
			else {
				return false;
			}
		}

		function query($sql) {
			$this->conn = $this->db_connect() or die ("N�o � poss�vel connectar ao banco de dados.");
			if ($res = mysql_query($sql,$this->conn) or die ("Inv�lida: ".mysql_error())) {
				$this->db_close($this->conn);
				return $res;
			}
			else {
				echo "Bronca na query.";
				$this->db_close($this->conn);			
				return false;
			}
		}

		function to_array($res) {
			if ($linha = mysql_fetch_array($res)) {
				return $linha;
			}
			else {
				return false;
			}
		}
		
		function num_rows($res) {
			if ($num = mysql_num_rows($res)) {
				return $num;
			}
			else {
				return false;
			}
		}

		function num_fields($res) {
			if ($num = mysql_num_fields($res)) {
				return $num;
			}
			else {
				return false;
			}
		}

		function affected_rows($res) {
			if ($num = mysql_affected_rows($res)) {
				return $num;
			}
			else {
				return false;
			}
		}
		
	}
?>