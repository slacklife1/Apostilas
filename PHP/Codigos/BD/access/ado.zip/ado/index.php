<?php
	require_once('TADOPgsql.php');
	$banco = new TADOPgsql('10.79.6.46','vinnydb','vinny','vinicius');
	$res = $banco->query("select nome from tb_categoria order by nome");
	while ($linha = $banco->to_array($res)) {
		echo $linha["nome"]."<br>";
	}
	echo $banco->num_rows($res)."<br>";
	echo $banco->num_fields($res)."<br>";
	

	echo "<br>";
	echo "M�todos da classe TADOPgsql.php";
	echo "<br>";	
	$class_methods = get_class_methods(get_class($banco));
	foreach ($class_methods as $method_name) {
		echo "$method_name<br>";
	}

	echo "<br>";
	echo "<hr>";
	echo "<br>";

	require_once('TADOSqlserver.php');
	$banco = new TADOSqlserver('10.79.4.233','DESENVOLVIMENTO','sa','');
	$res = $banco->query("select Nome_Funcionario as nome,Guerra_Funcionario as guerra from Funcionario order by Guerra_Funcionario");
	while ($linha = $banco->to_array($res)) {
		echo $linha["guerra"] . " || " . $linha["nome"]."<br>";
	}
	echo $banco->num_rows($res)."<br>";
	echo $banco->num_fields($res)."<br>";
	
	echo "<br>";
	echo "M�todos da classe TADOSqlserver.php";
	echo "<br>";	
	$class_methods = get_class_methods(get_class($banco));
	foreach ($class_methods as $method_name) {
		echo "$method_name<br>";
	}		

	echo "<br>";
	echo "<hr>";
	echo "<br>";

	require_once('TADOMysql.php');
	$banco = new TADOMysql('10.79.5.2','nti','root','*nti*dpf79');
	$res = $banco->query("select dsc_modelo, cor_modelo from tb_modelos order by id_modelo");
	while ($linha = $banco->to_array($res)) {
		echo $linha["cor_modelo"] . " || " . $linha["dsc_modelo"]."<br>";
	}
	echo $banco->num_rows($res)."<br>";
	echo $banco->num_fields($res)."<br>";
	
	echo "<br>";
	echo "M�todos da classe TADOMysql.php";
	echo "<br>";	
	$class_methods = get_class_methods(get_class($banco));
	foreach ($class_methods as $method_name) {
		echo "$method_name<br>";
	}		

	echo "<br>";
	echo "<hr>";
	echo "<br>";
	
	require_once('TADOOdbc.php');
	$banco = new TADOOdbc("PostgreSQL30","vinny","vinicius");
	$res = $banco->query("select nome from tb_categoria order by nome");
	while ($linha = $banco->to_array($res)) {
		echo $linha["nome"]."<br>";
	}
	echo $banco->num_rows($res)."<br>";
	echo $banco->num_fields($res)."<br>";
	echo "<br>";
	echo "M�todos da classe TADOOdbc.php";
	echo "<br>";	
	$class_methods = get_class_methods(get_class($banco));
	foreach ($class_methods as $method_name) {
		echo "$method_name<br>";
	}

	echo "<br>";
	echo "<hr>";
	echo "<br>";
	
	require_once('TADOIbase.php');
	$banco = new TADOIbase;
	$res = $banco->query("select * from tb_operacao");
	while ($linha = $banco->to_array($res)) {
		echo $linha["DESC_OPERACAO"]."<br>";
	}
	echo $banco->num_fields($res)."<br>";
	echo "<br>";
	echo "M�todos da classe TADOIbase.php";
	echo "<br>";	
	$class_methods = get_class_methods(get_class($banco));
	foreach ($class_methods as $method_name) {
		echo "$method_name<br>";
	}

?>