<html>
<head>
</head>
<body>
<?php
###########CR�DITOS###########
# Script Original Criado Por #
# 		Neander Ara�jo       #
#   neander@eumesmo.com.br   #
# http://www.eumesmo.com.br/ #
##############################

echo "
<title>Sistema de Cores Alternadas Numa Tabela</title>
<table width=500 cellspacing=1 cellpadding=3 align=center bgcolor=#BBBBBB>";
//Conexao com a base
mysql_connect...
//Seleciona a base
mysql_select_db...
//Faz o select principal
$result= mysql_query...
//Fun�ao para alternar a cor
$cor = ($coralternada++ %2 ? "D9D9D9" : "E9E9E9")
//Coloque dentro do seu while, dentro de bgcolor da <td> ou <tr>, a variavel $cor
while($row = mysql_fetch_row($result)) {
echo"
<td bgcolor =\"#$cor\"> $row[1]
";
?>
</TABLE>
</body>
</html>