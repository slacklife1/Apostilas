<form action="pesca.php" method="post">
  <div align="center">
    <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>Digite 
      o modelo exemplo Voyage :</strong></font> 
      <input type="text" name="busca" value="">
      <BR>
      <BR>
      <input type="submit" value="Pesquisar">
    </p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
  </div>
</form>
<div align="center"><font color="#FF0000" face="Verdana, Arial, Helvetica, sans-serif"></font></div>
