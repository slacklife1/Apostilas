<form action="del.php" method="post">
  <div align="center">
    <p><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>Digite 
      a Placa do ve&iacute;culo s ser excluido :</strong></font> 
      <input type="text" name="del" value="">
      <BR>
      <BR>
      <input type="submit" value="Deletar">
    </p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
  </div>
</form>
<div align="center"><font color="#FF0000" face="Verdana, Arial, Helvetica, sans-serif"></font></div>
