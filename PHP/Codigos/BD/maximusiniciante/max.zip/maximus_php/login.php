<html>
<head>
	<title>Sistema Maximus Iniciante PHP </title>
</head>

<body bgcolor= "#336699">
<center>

<table border="1" cellspacing="0" cellpadding="0" align="center" width="450">
<tr bgcolor="#C6C3C6">
	<td>
		<table width="450" border="0" cellspacing="0" cellpadding="1" align="center">
		<tr bgcolor="#400080">
			
          <td height="20" bgcolor="#000084"> <b><font color="#FFFFFF"> Sistema 
           Maximus Iniciante PHP  V.1.0</font></b></td>
			
          <td height="20" align="right" bgcolor="#000084"> </a> </td>
        </tr>
        <tr align="center">
			<td colspan="2">
            	<form method="post" name="pass" action="libera.php">
				
              <table border="0" cellspacing="0" cellpadding="1" width="100%">
                <tr> 
                  <td rowspan="3" valign="top" align="right" width="12%">&nbsp; </td>
                  <td colspan="2" height="42"> <div align="center"><strong><font size="1" face="Verdana, Arial">Acesso 
                      restrito ao administrador. Por favor digite o nome de usu�rio 
                      e senha: </font></strong></div></td>
                </tr>
                <tr> 
                  <td width="18%"> <strong><font size="1" face="Verdana, Arial">USU&Aacute;RIO: 
                    </font></strong></td>
                  <td width="70%"> <strong><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                    <input type="text" name="usuario" size="25">
                    Digite: jecatatu</font></strong></td>
                </tr>
                <tr> 
                  <td height="35" width="18%"> <strong><font size="1" face="Verdana, Arial">SENHA:</font></strong></td>
                  <td height="35" width="70%"> <strong><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                    <input type="password" name="senha" size="25">
                    Digite: 2003</font></strong></td>
                </tr>
              </table>
			<table width="100%" border="0" cellspacing="0" cellpadding="1">
			<tr>
				<td align="right" width="47%">
					<input type="submit" value="Entrar">
				</td>
				<td align="right" width="1%">&nbsp;
					
				</td>
				<td width="52%">
					<input type="reset" value="Limpar">
				</td>
			</tr>
			</table>
			</form>
		</td>
	</tr>
	</table>
	</td>
</tr>
</table>


</body>
</html>
