

<?php
    $link = mysql_connect("localhost") or die("Could not connect");
    mysql_select_db("Cobaia") or die("Could not select database");
    $query = "SELECT * FROM teste";
    $result = mysql_query($query) or die("Query failed");

while ($r = mysql_fetch_array($result)) {
   extract($r);
?>
<div align="left"><BR><strong><CENTER>
  <table width=60% border=1  cellpadding="1" cellspacing="1" bordercolor=#FFFFCC bgcolor="#666666">
    <tr bordercolor="#CCCCCC" bgcolor="#FFFFCC">
      <td width="12%" bgcolor="#CCCCCC"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Modelo:</font></td>
      <td width="88%"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><?php echo "$modelo" ?></font></td>
    </tr>
    <tr bordercolor="#CCCCCC" bgcolor="#FFFFCC">
      <td bgcolor="#CCCCCC"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Placa:</font></td>
      <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
        <?php echo "$placa" ?></font></td>
    </tr>
    <tr bordercolor="#CCCCCC" bgcolor="#FFFFCC">
      <td bgcolor="#CCCCCC"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Ano:</font></td>
      <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
        <?php echo "$ano" ?></font></td>
    </tr>
    <tr bordercolor="#CCCCCC" bgcolor="#FFFFCC">
      <td height="60" bgcolor="#CCCCCC"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Obs:</font></td>
      <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
        <?php echo "$obs"?></font></td>
    </tr>
  </table>
  <?php
}
?>
  </strong></font></div>
<font color="#FF0000">
<p>&nbsp;</p>
<p>&nbsp;</p>
<p align="center"><a href="default.htm" target="_self"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><strong>VOLTAR 
  PAGINA INICIAL</strong></font></a></p>
