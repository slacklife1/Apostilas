<html>
<body bgcolor="#ffFFff">

<?php 
	$res1 = mysql_connect("localhost"); 
    mysql_select_db("Cobaia",$res1);
	if ($res1){ 
        $res2 = mysql_query("DELETE FROM teste WHERE placa = '$del'");
	 if ($res2) {

         echo "<body bgcolor=#ffffff link=#FFFFFF vlink=#FFFFFF alink=#FFFF99>\n";
         echo "<table border=1 cellpadding=0 cellspacing=0 bordercolor=#FFFFFF align=center>\n";   
         echo "<tr  bgcolor=#0066CC><td colspan=5><div align=center><font color=#ffffFF>Excluido com Sucesso !!! <BR><a href=default.htm><b>Pagina Inicial</b></a></font></div></td>\n";
         echo "</table>\n";

	 }else {
	   print("Erro na exclus�o ".mysql_error()."\n<br>");
	 }
	}else {
	   print("Erro na tentativa de conex�o ".mysql_error()."\n<br>");
	
	}
	mysql_close($res1); 


?> </html>