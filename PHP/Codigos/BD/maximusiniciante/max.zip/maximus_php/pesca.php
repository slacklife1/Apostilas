 <center> <strong><font size="2" face="Geneva, Arial, Helvetica, sans-serif"><font color=darkblue>Resultado da sua Consulta 
:</font></strong><br>
<br>

<?php
$connection = mysql_connect("localhost") or die("Could not Connect to DB");
$db = mysql_select_db("Cobaia", $connection) or die("Couldnt select DB");
$busca = mysql_query ("select *from teste where modelo like '$busca'") 
or die (mysql_error());
if ($busca) {
while ($row=mysql_fetch_array($busca)) {
$modelo = $row["modelo"];
$placa = $row["placa"];
$ano = $row["ano"];
$obs = $row["obs"];
?>
<br><br>
<table width="664" cellpadding="1" cellspacing="1">
  <tr> 
    <td width="77" height="18"  bgcolor="#6699FF"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">MODELO</font></strong></td>
    <td width="585"  bgcolor="#FFFFCC"><strong><? echo $modelo; ?></strong></td>
  </tr>
  <tr> 
    <td bgcolor="#CCCCCC"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>PLACA</strong></font></td>
    <td bgcolor="#FFFFCC">&nbsp;<? echo $placa; ?></td>
  </tr>
  <tr> 
    <td bgcolor="#6699FF"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>ANO</strong></font></td>
    <td bgcolor="#FFFFCC"><? echo $ano; ?></td>
  </tr>
  <tr> </tr>
  <tr> 
    <td bgcolor="#CCCCCC"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>OBS</strong></font></td>
    <td bgcolor="#FFFFCC">&nbsp;<? echo $obs; ?><br></td>
  </tr>
</table>
<? } } ?>
<br><br>
<font color="#000000"></font> 

<center>
<a href="default.htm" target="_self">Voltar P�gina Inicial </a>