<html>
<head>
<title>LOGIN</title>
</head>
<body>
<center>
<font face=arial, verdana  color=red size=2>
<?
 

if (!$usuario or !$senha) {
	echo "<script>alert('Preencha todos os campos')</script>";
	echo "<script>window.location='login.php'</script>";
}


$jecatatu = "<script>window.location='default.htm'</script>";

if ($usuario == "jecatatu" and $senha == "2003"){
	echo $jecatatu;
}
else{
	echo "<font color='red'>Acesso negado.</font><br><a href='login.htm'>voltar</a>";
}

?>
</body>
</html>