<?
##############################
##############################
##                          ##
##      Pagina��o f�cil     ##
##     Desenvolvido por:    ##
##        Robert_Rsc        ##
##                          ##
##    roberto@nutecs.com    ##
##                          ##
##                          ##
##############################
##############################

//ATEN��O ESTE SCRIPT � PARA USO LIVRE EM QUALQUER APLICA��O FOI DESENVOLVIDO COM A AJUDA DE OUTROS
//SCRIPTS DE C�DIGO ABERTO - VOC� PODE ALTER�-LO E UTILIZA-LO  DA MANEIRA  QUE QUIZER MAS POR FAVOR 
//MANTENHA OS CR�DITOS - CASO VC UTILIZE ESTE SCRIPT POR FAVOR ME ENVIE UM E-MAIL PARA ME NOTIFICAR 
//DO USO.
?>


<style>.estilos { color: #000000; text-decoration: none} A:hover {text-decoration: underline}</style>
			<?
			// BY SK15 
			// http://www.BuscaWeb.clic3.net 
			function getmicrotime(){ 
			list($sec, $usec) = explode(" ",microtime()); 
			return ($sec + $usec); 
			} 
			$time_start = getmicrotime(); 
//#####################################################################
			$arquivo = "index.php"; // COLOQUE AQUI O NOME DADO A ESTE ARQUIVO
									//CASO VC TENHA QUE UTILIZAR OUTRAS VARI�VEIS JUNTO COM A VARI�VEL (id) COLOQUE JUNTO EXEMPLO: "index.php?moldura=$mold&"
			$banco = "banco_d_dados";	  // NOME DO BANCO DE DADOS
			$endereco = "localhost";  // ENTRE COM O ENDERE�O DO BANCO DE DADOS
			$usuario = "usuario_banco";	  // NOME DE USU�RIO DO MYSQL
			$password = "senha_banco";	  // SENHA DO MySQL
			$table = "temporario";	  // NOME DA TABELA A SER UTILIZADA
			$maxpag = 2;			  // M�XIMO DE RESULTADOS POR P�GINA
			$maxlnk = 10;			  // M�XIMO DE LINKS POR P�GINA
			if ($id == ''){$param = 0;} else {
			$temp = $id;
			$passo1 = $temp - 1;
			$passo2 = $passo1*$maxpag;
			$param = $passo2;}
//#####################################################################
			$res = mysql_connect("$endereco", "$usuario", "$password");
			$sql = "select * from $table";
			$sql_01 = "select * from $table  limit $param,$maxpag";
			$res1 = mysql_db_query("$banco", "$sql", $res);
			$res2 = mysql_db_query("$banco", "$sql_01", $res);
  			$totreg = mysql_num_rows($res1);
			$totreg_01 = mysql_num_rows($res2);
//#####################################################################
			$results_tot = $totreg;
			$results_parc = $totreg_01;
			$result_div = $results_tot/$maxpag;
			$n_inteiro = (int)$result_div;
			if ($n_inteiro < $result_div) {$n_paginas = $n_inteiro + 1;}
			else {$n_paginas = $result_div;}
			$pg_atual = $param/$maxpag+1;
			$reg_inicial = $param + 1;
			$pg_anterior = $pg_atual - 1;
			$pg_proxima = $pg_atual + 1;
			$time_end = getmicrotime(); 
			$time = $time_end - $time_start; ?>

<html>
<head>
<title>Pagina��o de Resultados</title>
</head>
<body topmargin="0" leftmargin="0">
<table border="0" cellspacing="0" width="863">
  <tr>
    <td bgcolor="#3366CC" width="859">
      <p align="right"><font color="#FFFFFF" size="2" face="Arial">Foram encontradas <?echo $totreg;?> ocorr�ncias em <?echo $n_paginas?> p�ginas de resultados - visualizando&nbsp; <?echo $maxpag;?>
      resultados por p�gina</font></td>
  </tr>
</table>
<p style="word-spacing: 0; margin: 0">&nbsp;</p>
<p style="word-spacing: 0; margin: 0">&nbsp;</p>
<p style="word-spacing: 0; margin: 0">&nbsp;</p>
<p style="word-spacing: 0; margin: 0">&nbsp;</p>

			<?while($resultado = mysql_fetch_array($res2)) { $contador ++;?>


<?
// ################## COLOQUE AQUI OS RESULTADOS DA PESQUISA ######################?>


<p style="word-spacing: 0; margin: 0" align="center">
<font color="#000000" size="2" face="Arial"><?echo $resultado["nome"];?></font></p>


<?
// ############################ FIM DOS RESULTADOS ###############################?>
			
			<?}$reg_final = $param + $contador;?>

<p style="word-spacing: 0; margin: 0">&nbsp;</p>
<p style="word-spacing: 0; margin: 0">&nbsp;</p>
<p style="word-spacing: 0; margin: 0">&nbsp;</p>
<p style="word-spacing: 0; margin: 0">&nbsp;</p>
<div align="center">
  <table border="0" cellspacing="0" width="147">
    <tr>
      <td width="63">
        <p align="left"><font face="Verdana" size="2">

			<?if ($id > 1) {?><a href="<?$arquivo?>?id=<?echo $pg_anterior;?>" class="estilos"><b>&lt;&lt;anterior</font><?}?></a></td>
			<?if ($temp >= $maxlnk){
			if ($n_paginas > $maxlnk) {$n_maxlnk = $temp + 4;
			$maxlnk = $n_maxlnk;
			$n_start = $temp - 6;
			$lnk_impressos = $n_start;}}
			while(($lnk_impressos < $n_paginas) and ($lnk_impressos < $maxlnk))
			{ $lnk_impressos ++;?>

      <center>
      <td width="7">
        <p align="center"><font face="Verdana" size="2">

			<?if ($pg_atual != $lnk_impressos){echo "<a href=\"$arquivo?id=$lnk_impressos\" class=\"estilos\">";}
			if ($pg_atual == $lnk_impressos){echo "<h1>$lnk_impressos<h1>";} else {echo "$lnk_impressos";}?></a></b></font></td><?}?>

	  </font></td>
      </center>
      <td width="200">
        <p align="left"><font face="Verdana" size="2">
		
			<?if ($reg_final < $results_tot) {?><a href="<?$arquivo?>?id=<?echo $pg_proxima;?>" class="estilos"><b>Pr�ximo&gt;&gt;</b></font></a></td><?}?>

    </tr>
  </table>
</div>
<p style="word-spacing: 0; margin: 0">&nbsp;</p>
<div align="left">
<table border="0" cellspacing="0" width="863">
  <tr>
    <td bgcolor="#3366CC" width="859">
      <p align="right" style="word-spacing: 0; margin: 0"><font color="#FFFFFF" size="2" face="Arial">mostrando <?echo $reg_inicial;?> - <?echo $reg_final;?> sobre <?echo $totreg;?></font><font color="#FFFFFF" size="2" face="Arial">
      <?$texto=printf ("A pesquisa demorou <b>%.3f</b> segundos",$time);?></font></td>
  </tr>
</table>
</div>
</body>
</html>