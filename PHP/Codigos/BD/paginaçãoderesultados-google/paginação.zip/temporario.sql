CREATE TABLE temporario (
  sequencial int(11) NOT NULL auto_increment,
  nome varchar(20) NOT NULL default '',
  dados varchar(20) NOT NULL default '',
  PRIMARY KEY  (sequencial)
) TYPE=MyISAM COMMENT='teste de offset2';

#
# Extraindo dados da tabela `temporario`
#

INSERT INTO temporario VALUES (1, 'um', 'um');
INSERT INTO temporario VALUES (2, 'dois', 'dois');
INSERT INTO temporario VALUES (3, 'tres', 'tres');
INSERT INTO temporario VALUES (4, 'quatro', 'quatro');
INSERT INTO temporario VALUES (5, 'cinco', 'cinco');
INSERT INTO temporario VALUES (6, 'seis', 'seis');
INSERT INTO temporario VALUES (7, 'sete', 'sete');
INSERT INTO temporario VALUES (8, 'oito', 'oito');
INSERT INTO temporario VALUES (9, 'nove', 'nove');
INSERT INTO temporario VALUES (10, 'dez', 'dez');
INSERT INTO temporario VALUES (11, 'onze', 'onze');
INSERT INTO temporario VALUES (12, 'doze', 'doze');
INSERT INTO temporario VALUES (13, 'treze', 'treze');
INSERT INTO temporario VALUES (14, 'quatorze', 'quatorze');
INSERT INTO temporario VALUES (15, 'quinze', 'quinze');
INSERT INTO temporario VALUES (16, 'dezesseis', 'dezesseis');
INSERT INTO temporario VALUES (17, 'dezessete', 'dezessete');
INSERT INTO temporario VALUES (18, 'dezoito', 'dezoito');
INSERT INTO temporario VALUES (19, 'dezenove', 'dezenove');
INSERT INTO temporario VALUES (20, 'vinte', 'vinte');
INSERT INTO temporario VALUES (21, 'vinte um', 'vinte um');
INSERT INTO temporario VALUES (22, 'vinte dois', 'vinte dois');
INSERT INTO temporario VALUES (23, 'vinte e tres', 'vinte e tres');
INSERT INTO temporario VALUES (24, 'vinte e quatro', 'vinte e quatro');
INSERT INTO temporario VALUES (25, 'vinte e cinco', 'vinte e cinco');
INSERT INTO temporario VALUES (26, 'vinte e seis', 'vinte e seis');
INSERT INTO temporario VALUES (27, 'vinte e sete', 'vinte e sete');
INSERT INTO temporario VALUES (28, 'vinte e oito', 'vinte e oito');
INSERT INTO temporario VALUES (29, 'vinte e nove', 'vinte e nove');
INSERT INTO temporario VALUES (30, 'trinta', 'trinta');

