<?php

$mIP = getenv('REMOTE_ADDR');

$open_db=mysql_pconnect ("localhost", "base_de_dados_de_usuarios","senha_de_acesso_a_base_de_dados_de_usuarios");
mysql_select_db ("database_da_base_de_dados");
$resultado=mysql_query("SELECT * FROM usuarios where usuario = '$user' and senha = '$pass'");
while ($row = mysql_fetch_array($resultado)) {
       $verifica_user=$row['usuario'];
       $verifica_pass=$row['senha'];
       $verifica_db=$row['nome_do_db_do_usuario'];
      }
      if ($user !=$verifica_user || $pass !=$verifica_pass || $user =="" || $pass =="") {
          header("WWW-Authenticate: basic realm='Administra��o de Usu�rios'");
          header("HTTP/1.0 401 Unauthorized");
          echo "Nome de Usu�rio ou Senha Inv�lidos!\n";
          mail("seu-email@seu-dominio.com.br","Erro de Autentica��o MySQL","O usu�rio $user est� tentando se logar com a senha $pass.\nIP: ".gethostbyaddr($mIP)."@" .gethostbyname($mIP)."","From:seu-email@seu-dominio.com.br");
          exit;
      } else {
          setcookie ("usuario", $verifica_user);
          setcookie ("db", $verifica_db);
          setcookie ("senha", $verifica_pass);
          Header ("Location: index.php");
      }
mysql_close($open_db);
?>



