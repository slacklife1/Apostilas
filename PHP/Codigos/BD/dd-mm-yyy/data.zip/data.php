<?php
###########CR�DITOS###########
# Script Original Criado Por #
# 		Neander Ara�jo       #
#   neander@eumesmo.com.br   #
# http://www.eumesmo.com.br/ #
##############################

###     Fun��o para a mascara de data e valida��o:    ###
###          Mascara e valida��o de Data e Hora       ###
###             por Andre de Castro Zorro             ###
### http://www.phpbrasil.com/scripts/source.php/id/84 ###



////////////////////////////////////////////////////////////////////
#Conex��o com a base de dados:
#Obs: Altere de a Conexao De Acordo Com a Sua Base de Dados
$mysql_usuario="root"; //Usuario da base de dados
$mysql_password="root";//Senha da base de dados
$mysql_database="data";//Nome da base de dados
$mysql_host="localhost";//Host de sua base de dados, Ex:Localhost
$con = mysql_connect($mysql_host, $mysql_usuario, $mysql_password);
mysql_select_db($mysql_database, $con);
////////////////////////////////////////////////////////////////////
?>
<html>
<head>
<title>Teste de Datas</title>
<script>
function mascara_data(novadata){
              var mydata = '';
              mydata = mydata + novadata;
              if (mydata.length == 2){
                  mydata = mydata + '/';
                  document.forms[0].novadata.value = mydata;
              }
              if (mydata.length == 5){
                  mydata = mydata + '/';
                  document.forms[0].novadata.value = mydata;
              }
              if (mydata.length == 10){
                  verifica_data();
              }
          }
           function verifica_data () {

            dia = (document.forms[0].novadata.value.substring(0,2));
            mes = (document.forms[0].novadata.value.substring(3,5));
            ano = (document.forms[0].novadata.value.substring(6,10));

            situacao = "";
            // verifica o dia valido para cada mes
            if ((dia < 01)||(dia < 01 || dia > 30) && (  mes == 04 || mes == 06 || mes == 09 || mes == 11 ) || dia > 31) {
                situacao = "falsa";
            }

            // verifica se o mes e valido
            if (mes < 01 || mes > 12 ) {
                situacao = "falsa";
            }

            // verifica se e ano bissexto
            if (mes == 2 && ( dia < 01 || dia > 29 || ( dia > 28 && (parseInt(ano / 4) != ano / 4)))) {
                situacao = "falsa";
            }

            if (document.forms[0].novadata.value == "") {
                situacao = "falsa";
            }

            if (situacao == "falsa") {
                alert("Data inv�lida!");
                document.forms[0].novadata.focus();
                document.forms[0].novadata.value = "";
            }
          }

//Fun��o que n�o permite a digita��o de letras.
	function Somente_Numeros()
	{

		//No campo CEP permite a digita��o de um tra�o somente

		if('0123456789'.indexOf(String.fromCharCode(event.keyCode)) == -1)
	    {
		   event.returnValue = false;
		}
	}
    </script>
</head>
<body>

<?php
$resultado=mysql_query("SELECT * FROM data",$con); //Faz o select principal para achar os dados
$formatodata="d/m/Y"; //Seta o formato da data
echo"
<font size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\">
Dados J� Gravados Na Base de Dados:<br>
<table width=\"29%\" border=\"1\" cellpadding=\"1\" cellspacing=\"0\" bordercolor=\"#000000\">
  <tr bgcolor=\"#CCFFFF\">
    <td width=\"47%\"><font size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\">Codigo:</font></td>
    <td width=\"53%\"><font size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\">Datas:</font></td>
  </tr>";
while ($row = mysql_fetch_row($resultado)) {
//$time_stamp = strtotime($row[1]);
//$data = date("$formatodata", $time_stamp);
//$date = $row[1];
// AQUI FICA A MODIFICA��O DO C�DIGO
$tirahora = substr($row[1],0,-9);
list ($ano,$mes,$dia) = split ('[-]', $tirahora);
$databr = "$dia-$mes-$ano";

echo"
<tr> $rest
    <td><font size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\">$row[0]</font></td>
    <td><font size=\"2\" face=\"Verdana, Arial, Helvetica, sans-serif\">$databr</font></td>
  </tr>";
     }
echo"
</table>
";
?>
<!-- Formul�rio para enviar os dados da data para a fun��o novadata() -->
<form name="Form1" action="data.php?&faz=novadata" method="post">
<font size="2" face="Verdana, Arial, Helvetica, sans-serif">
Coloque a Data Para a Ser Gravada No Banco de Dados:<br>
<input name="novadata" type="text" onKeyPress="Somente_Numeros()" OnKeyUp="mascara_data(this.value)" maxlength="10">
<input type="submit" value="Gravar"></font>
</form>

<?
//Fun��o para gerar a data no padr�o mysql e grava-la no banco
function novadata($codigo, $novadata) {
global $con;
$date = $novadata;
list ($day, $month, $year) = split ('[/.-]', $date);
$mysqldata = "{$year}{$month}{$day}";
$x = strlen($mysqldata);
//2a Fun��o que verifica se a data �st� digitada corretamente.
if (strlen($mysqldata) < 8) {
echo"
<script>
alert(\"Esta Data Est� inv�lida!\");
document.forms[0].novadata.focus();
document.forms[0].novadata.value = \"\";
</script>";
break;
}
else {
mysql_query("insert into data (codigo, data) values('', '$mysqldata')", $con);
echo"
<script>
window.location.href = \"data.php\";</script>";
}
}
switch($faz){

    case 'novadata':
            novadata($codigo, $novadata);
            break;
}
?>
</body>
</html>