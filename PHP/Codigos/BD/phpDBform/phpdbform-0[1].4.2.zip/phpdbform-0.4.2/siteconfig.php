<?php
// database access
$dbcfg["host"] = "localhost";
$dbcfg["database"] = "phpdbform";
$dbcfg["admuser"] = "root";
$dbcfg["admpasswd"] = "";

// configure here the theme you want to use
$dbcfg["theme"] = "nt";

// list here the users and password you want to give access to
// the admin interface
$dbcfg["access"] = array(
	"adm"=>"123",
	"test"=>"test"
);

// list here the menu
$dbcfg["menu"] = array(
	"Contacts"=> array( "Test 1"=>"test_contact.php",
						"Test 2 (owner draw)"=>"test_contact2.php",
						"Test 3 (no selection form)"=>"test_contact3.php",
						"Test 4 (filter)"=>"test_contact4.php" ),
	"Photos"=>array( "Photos"=>"test_photos.php" ),
	"Reports"=> array( "Simple"=>"test_report.php",
					   "Extended"=>"test_report_wt.php" )
);

?>
