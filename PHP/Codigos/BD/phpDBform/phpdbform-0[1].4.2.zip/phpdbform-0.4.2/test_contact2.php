<?php
include_once("phpdbform/phpdbform_main.php");
include_once("phpdbform/phpdbform_mysql.php");
include_once("phpdbform/phpdbform_db.php");
check_login();

$db = new phpdbform_db( $dbcfg["database"], $dbcfg["host"], $dbcfg["admuser"], $dbcfg["admpasswd"] );
$db->connect();
$form = new phpdbform( $db, "contact", "cod", "name,email", "name" );

$form->add_textbox( "name", "Name:", 30 );
$form->add_textbox( "email", "E-mail:", 50 );
$form->add_static_listbox( "sex", "Male", "male,female" );
$form->add_checkbox( "active", "Active?", "Y", "N" );
$form->add_listbox( "type", "Type", $db, "type", "cod", "type", "type" );
$form->add_static_radiobox( "os", "Operating System:", "linux,windows,unix" );
$form->add_date( "birthday", "BirthDay", "fmtEUR" ); // fmtUSA, fmtEUR, fmtSQL
$form->add_textarea( "obs", "Obs", 30, 10 );

$header = "
<style type=\"text/css\">
	body, td {
		font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
		font-size: 10px;
	}

	input, select, textarea {
		font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
		font-size: 10px;
		background: #FFFFF0;
	}
</style>
";

draw_adm_header( "Test Contact 2", $header );
$form->process();
?>

<table border="1" cellspacing="0" cellpadding="5" bordercolor="#0000FF" bgcolor="#EDEDEF" frame="border" rules="groups">
<tr bgcolor="#F0E1A6">
    <td colspan=3><b>Select:</b><br><? $form->selform->draw(); ?></td>
</tr>
<? $form->draw_header(); ?>
<tr>
    <td colspan=3><? $form->fields["name"]->draw(); ?></td>
</tr>
<tr>
    <td colspan=3><? $form->fields["email"]->draw(); ?></td>
</tr>
<tr>
    <td><? $form->fields["sex"]->draw(); ?></td>
    <td><? $form->fields["active"]->draw(); ?></td>
    <td><? $form->fields["type"]->draw(); ?></td>
</tr>
<tr>
    <td colspan=2><? $form->fields["os"]->draw(); ?></td>
    <td><? $form->fields["birthday"]->draw(); ?></td>
</tr>
<tr>
    <td colspan=3><? $form->fields["obs"]->draw(); ?></td>
</tr>
<tr>
    <td><? $form->draw_delete_button( "Delete record" ); ?></td>
    <td>&nbsp;</td>
    <td><? $form->draw_submit( "Send", false ); ?></td>
</tr>
</table>
<? $form->draw_footer(); ?>
<br><br><hr>
version 2: a little less ugly<br>
This isn't a nice design, but it shows how to draw your own form. ;-)
<?php
draw_adm_footer();
?>