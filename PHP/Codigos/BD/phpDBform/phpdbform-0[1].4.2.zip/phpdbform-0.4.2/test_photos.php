<?php
include_once("phpdbform/phpdbform_main.php");
include_once("phpdbform/phpdbform_mysql.php");
include_once("phpdbform/phpdbform_db.php");
check_login();
$db = new phpdbform_db( $dbcfg["database"], $dbcfg["host"], $dbcfg["admuser"], $dbcfg["admpasswd"] );
$db->connect();
$form = new phpdbform( $db, "photos", "cod", "name", "name" );

$form->add_textbox( "name", "Name:", 30 );
$form->add_image( "image", "Image:" );

draw_adm_header( "Test Photos", $emptyHeader );
$form->process();
$form->draw();
draw_adm_footer();
?>
