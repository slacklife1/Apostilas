<?php
include_once("phpdbform/phpdbform_main.php");
include_once("phpdbform/phpdbform_mysql.php");
include_once("phpdbform/phpdbform_db.php");
check_login();
$db = new phpdbform_db( $dbcfg["database"], $dbcfg["host"], $dbcfg["admuser"], $dbcfg["admpasswd"] );
$db->connect();
$form = new phpdbform( $db, "contact", "cod", "name,email", "name" );

$form->add_textbox( "name", "Name:", 30 );
$form->add_textbox( "email", "E-mail:", 50 );
$form->add_static_listbox( "sex", "Sex", "male,female" );
$form->add_checkbox( "active", "Active?", "Y", "N" );
$form->add_listbox( "type", "Type", $db, "type", "cod", "type", "type" );
$form->add_static_radiobox( "os", "Operating System:", "linux,windows,unix" );
$form->add_date( "birthday", "BirthDay", "fmtEUR" ); // fmtUSA, fmtEUR, fmtSQL
$form->add_textarea( "obs", "Obs", 30, 10 );

draw_adm_header( "Test Contact", $emptyHeader );
$form->process();
$form->draw();
draw_adm_footer();
?>
