<?php
include_once("phpdbform/phpdbform_mysql.php");
include_once("phpdbform/phpdbform_db.php");

$db = new phpdbform_db( "phpdbform", "localhost", "root", "" );
$form = new phpdbform( $db, "type", "cod", "type,business", "type" );
$form->add_textbox( "type", "Type:", 20 );
$form->add_checkbox( "business", "Business related?", "1", "0" );
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
	<title>Untitled</title>
</head>
<body>
<?
$form->process();
$form->draw();
?>
<br><br><br><hr><a href="http://www.phpdbform.com" target="_blank">phpDBform site</a>
</body>
</html>
