<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
	<title>Untitled</title>
    <script language="JavaScript">
    <? require("libjs.js"); ?>
    </script>
</head>
<body>
<?php
include("phpdbform/phpdbform_form.php");

$form = new phpform("form1");
$form->add_textbox( "name", "Name:", 20, 20 );
$form->add_password( "passwd", "Password:", 20, 20 );
$form->add_static_listbox( "option", "Option:", " ,c;car,a;airplane,b;bycicle,s;sp2" );
$form->add_textarea( "msg", "Message:", 20, 7 );
$form->add_checkbox( "testing", "Testing", "Yes", "No" );
$form->add_filebox( "upfile", "Attach file:", 20, 2048, "." );

// This is a default value
// After filling it this value will do nothing
$form->fields["msg"]->value = "You message here";

// This is a javascript code to be run onblur
$form->fields["name"]->onblur = "TestLen(this,10,20);";
$form->fields["passwd"]->onblur = "TestLen(this,4,8);";
$form->fields["option"]->onblur = "TestCar(this);";



$processed = $form->process();
$form->draw();
echo "<hr>";

if( $processed )
{
    reset( $form->fields );
    while( $afield = each( $form->fields ) )
    {
        echo $afield[0] . " - " . $afield[1]->value . "<br>";
    }
}
echo "<hr>";
@reset( $_POST );
while( $k = @each( $_POST ) )
{
    echo $k[0] . " - " . $k[1] . "<br>";
}
?>
<br><br><br><hr><a href="http://www.phpdbform.com" target="_blank">phpDBform site</a>
</body>
</html>
