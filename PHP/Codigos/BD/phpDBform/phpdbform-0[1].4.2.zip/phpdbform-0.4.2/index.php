<?php
// Copyright 2002 - Coral Inform�tica Ltda
// Paulo Assis
require_once( "phpdbform/phpdbform_main.php" );

draw_adm_header( "Main page", $emptyHeader );
if( !$_SESSION["dbform"]["logged"] ) {
?>
<br>
<table border="0" cellpadding="4" cellspacing="0" width="80%" align="center">
<form action="index.php" method="post">
<tr>
<td>
<?php if( strlen($erro)>0 ) print "<div class=\"erro\">$erro</div><br>"; ?>
Login:<br>
<input type="text" name="admLogin" size="30" maxlength="30"><br>
Senha:<br>
<input type="password" name="admPasswd" size="30" maxlength="30"><br><br>
<input type="submit" name="admSubmit" value="Login">
</td>
</tr>
</form>
</table>
<?php
} else {
?>
<p>Welcome <?=$_SESSION["dbform"]["user"]?>,<br><br>Use the menu on the left to choose the tool you want to use.</p>
<?php
}
draw_adm_footer();
?>
