<?php
// a Simple report
// if want to see a more complete report, take a look at test_report_wt.php
include_once("phpdbform/phpdbform_main.php");
include_once("phpdbform/phpdbform_mysql.php");
include_once("phpdbform/phpdbform_report.php");
check_login();

$db = new phpdbform_db( "phpdbform", "localhost", "root", "" );
$db->connect();
$stmt = "select c.cod, c.name, c.email, c.sex, c.active, c.type, t.type as type_name, c.os, c.birthday from contact c left outer join type t on (c.type = t.cod) order by c.email";
$form = new phpdbform_report( $db, $stmt, "Contacts" );
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
	<title>Testing report</title>
    <link href="report.css" rel="stylesheet" type="text/css">
</head>
<body>
<?php
$form->process();
$form->draw();
$form->free();
?>
<a href="index.php">Index</a>
<br><br><br><hr><a href="http://www.phpdbform.com" target="_blank">phpDBform site</a>
</body>
</html>