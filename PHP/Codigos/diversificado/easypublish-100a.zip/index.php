<?
/********************************************************************************/
/* EasyPublish                                                                  */
/* ====================================================                         */
/*                                                                              */
/* Copyright (c) 2003 by Angel Stoitsov and Mario Stoitsov                      */
/*    http://software.stoitsov.com                                              */
/*                                                                              */
/* This file is part of EasyPublish.                                            */
/* EasyPublish is free software; you can redistribute it and/or modify          */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation; either version 2 of the License, or         */
/*    (at your option) any later version.                                       */
/* EasyPublish is distributed in the hope that it will be useful,               */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/* You should have received a copy of the GNU General Public License            */
/*    along with EasyBookMarker; if not, write to the Free Software             */
/*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */
/********************************************************************************/
/*
// Unzip the zip file in some subdirectory (e.g. EasyPublish) under the root
// directory on your server. Then follow the three easy steps below

// ********************************************************************
// *********************** Database Tables
// ********************************************************************

// STEP ONE: Create the tables below under your desired DataBase
//            using phpMyAdmin for example
/*

DROP TABLE IF EXISTS `pupublish`;
CREATE TABLE `pupublish` (
  `ID` bigint(20) NOT NULL auto_increment,
  `puHeading` varchar(255) NOT NULL default '',
  `puBody` text NOT NULL,
  `puDate` date NOT NULL default '0000-00-00',
  `puUserID` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  KEY `ID` (`ID`),
  KEY `puDate` (`puDate`),
  KEY `puUserID` (`puUserID`)
) TYPE=MyISAM;
INSERT INTO `pupublish` (`ID`, `puHeading`, `puBody`, `puDate`, `puUserID`) VALUES (3, 'Particle-Number Projected HFB Method with Skyrme Forces', '[p]Pairing-correlations play a central role in describing the properties of\r\natomic nuclei. In the traditional nuclear structure models,\r\nthe pairing-correlations are treated in Bardeen-Cooper-Schrieffer (BCS) or\r\nHartree-Fock-Bogoliubov (HFB) approximations.[/p]\r\n[p]The product ansatz of the mean-field approach breaks the\r\nsymmetries which the original many-body Hamiltonian obeys. In\r\nparticular, the product-state violates the gauge-symmetry\r\nassociated with the particle-number.[/p]\r\n[p]The symmetry restoration in the mean-field studies is a major challenge to\r\nthe nuclear structure models. It has been shown that the variation of an\r\narbitrary energy-functional, which is completely expressed in terms of the\r\nHFB density matrix and the pairing tensor, results in the\r\nHFB like equation and, therefore, one obtains HFB like\r\nequations with modified expressions for the pairing-potential and the\r\nHartree-Fock field.[/p]', '2003-08-01', 1),
(2, 'Systematic Study of Deformed Nuclei at the Drip Lines and Beyond', 'An improved prescription for choosing a transformed harmonic\r\noscillator (THO) basis for use in configuration-space\r\nHartree-Fock-Bogoliubov (HFB) calculations is presented. The new\r\nHFB+THO framework that follows accurately reproduces the results\r\nof coordinate-space HFB calculations for spherical and\r\naxially-deformed nuclei, including those that are weakly bound.\r\nFurthermore, it is fully automated, facilitating its use in\r\nsystematic investigations of large sets of nuclei throughout the\r\nperiodic table.', '2003-09-01', 1),
(4, 'Non-Hermitian Hartree-Fock Theory', '[p]We are going to apply the [i]bi-variational principle[/i] to the many-body HF problem formulated in terms of trial\r\nsingle Slater determinant wave functions. In nuclear physics applications, the general\r\nlinear many-body operators are Hermi.[/p]\r\n[p]Since HF hamiltonian depends on the one-body density, one is dealing with a nonlinear problem which can be solved by a  self-consistent procedure as in the case of the conventional HF theory. One could start with an appropriate initial guess for the one-body density\r\nmatrix and its adjoint. Under favorable circumstances, this iteration procedure is convergent and leads to self-consistent HF\r\nsolutions.[/p]', '2003-08-01', 1);

DROP TABLE IF EXISTS `puusers`;
CREATE TABLE `puusers` (
  `ID` bigint(20) NOT NULL auto_increment,
  `puUsername` varchar(50) NOT NULL default '',
  `puPassword` varchar(50) NOT NULL default '',
  `puScreenName` varchar(200) NOT NULL default '',
  `puMail` varchar(255) NOT NULL default '',
  `puAdmin` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  KEY `ID` (`ID`),
  KEY `puAdmin` (`puAdmin`),
  KEY `puScreenName` (`puScreenName`)
) TYPE=MyISAM;
INSERT INTO `puusers` (`ID`, `puUsername`, `puPassword`, `puScreenName`, `puMail`, `puAdmin`) VALUES (1, 'demo', 'demo', 'Web Demo User', 'demo@demo.com', 1);

*/


// STEP TWO: Edit your preferences below

// ********************************************************************
// *********************** Config options
// ********************************************************************
$EasyPublish["mysql_host"]="localhost";       // change to your MySQL Host
$EasyPublish["mysql_user"]="dbuser";      // change to your MySQL Username
$EasyPublish["mysql_pass"]="dbpass"; // change to your MySQL Password
$EasyPublish["mysql_base"]="dbname";       // Database name, to contain EasyClassifields tables
$EasyPublish["Articles"]="News"; // What you are going to publish ex. News, Reviews, Articles, etc.
$EasyPublish["Contact"]=TRUE; // Wheather to show Author's e-mails or not (TRUE or FALSE)
$EasyPublish["news_per_page"]=3; // How many News to display
$EasyPublish["head_per_page"]=20; // How many News Headings to display in Search, Contents & Author`s Pages
$EasyPublish["DarkColor"]="#4D6EB5"; // Color of the headings, tables, links
$EasyPublish["Background"]="#FFFFFF"; // Page Background color
$EasyPublish["LightColor1"]="#CFDEFF"; // Table Highlight type 1
$EasyPublish["LightColor2"]="#F5F5F5"; // Table Highlight type 2


// LAST STEP: Point to index.php and ENJOY !!!


// ********************************************************************
// You do not need to edit below this line
// ********************************************************************

// ********************************************************************
// ********************* Initialization & Constants
// ********************************************************************
$EasyPublish["version"]="1.00a";
session_start();
$sql=mysql_connect($EasyPublish["mysql_host"],$EasyPublish["mysql_user"],$EasyPublish["mysql_pass"]) or
			Die (puError("Problem!","<br>The database server is offline. Try again shortly.","If the problem persists, contact the system administrator."));
mysql_select_db($EasyPublish["mysql_base"]) or
			Die (puError("Problem!","<br>The database is down for maintenance. It takes about 2 minutes to complete.","If the problem persists, contact the system administrator."));

function puError($Heading="Error!",$Error="",$Solution="") {
return "<br><table border=0 cellspacing=0 cellpadding=0 align=center><tr><td><div style='background-color:#FFD8D8; border: 2px solid red; padding:10 10 10 10; font: 11px Verdana;'>
		<font color=red><b>$Heading</b></font><br><P>".mysql_error()."<b>$Error</b></P><i>$Solution</i></div></td></tr></table><br>";
} // function Error

function puHackers($Text) {
	$ret=strip_tags($Text);	$ret=escapeshellcmd($ret);
	$ret=trim($ret);	$ret=str_replace("'","`",$ret);
	return $ret;
}

function puTr($width=1,$height=1) {
	return "<img src='tr.gif' width='$width' height='$height' alt='' border='0'>";
}

function NewsOut($News) {
Global $Stoitsov, $EasyPublish;
		return "<span class=h1s>".$News["puHeading"]."</span><br><br>
		".BBCode2HTML($News["puBody"])."<br>
		<b>Author:</b> ".puShowAuthor($News["puUserID"])."
		<br>".$News["puDate"]."<br>".((puRegistered($Stoitsov)==2 or $Stoitsov["ID"]==$News["puUserID"]) ? "
		<table border=0 cellspacing=1 cellpadding=2>
			<tr>
				<td bgcolor='".$EasyPublish["LightColor2"]."' nowrap><a href='$PHP_SELF?page=edit_news&id=".$News["ID"]."' class=normal><b>Edit</b></a></td>
				<td bgcolor='".$EasyPublish["LightColor2"]."' nowrap><a href=\"#\" onClick=\"javascript:YesNo('$PHP_SELF?action=delete&id=".$News["ID"]."','Are you sure, you want to delete?');\" class=normal><b>Delete</b></a></td>
				<td bgcolor='".$EasyPublish["LightColor2"]."' nowrap width=100%>&nbsp;</td>
			</tr>
		</table>
		" : "" )."<br><br>\n\n";
}

function puElement($Element="default",$Arg1="default",$Arg2="default",$Arg3="default",$Arg4="default",$Arg5="default",$Arg6="default") {
	switch ($Element) {
		case "form" : // Element, Action, Name, Method, Aditional
			$Action=$Arg1; $Name=$Arg2; $Method=$Arg3; $Aditional=$Arg4;
			if ($Name=="default") $Name="my";
			if ($Method=="default") $Method="POST";
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			return "<form action='$Action' name='$Name' method='$Method'".$Aditional.">\n";
		break;
		case "hidden" : // Element, Name, Value
			$Name=$Arg1; $Value=$Arg2;
			if ($Value=="default") $Value="";
			return "<input type='hidden' name='".$Name."' value='".$Value."'>\n";
		break;
		case "text" : // Element, Name, Value, Width, Aditional, Class
			$Name=$Arg1; $Value=$Arg2; $Width=$Arg3; $Aditional=$Arg4; $Class=$Arg5;
			if (strpos($Name,"[")===FALSE) {
				$ID="";
			} else {
				$Tmp=split("\[",$Name);
				$TmpID=split("\]",$Tmp[1]);
				$ID=" ID='".$TmpID[0]."' ";
			}
			if ($Value=="default") $Value="";
			if ($Width=="default") { $Width=""; } else { $Width=" style='width: $Width;' "; }
			if ($Class=="default") { $Class=" class='f_text'"; } else { $Class=" class='".$Class."'"; }
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			return "<input type='text'".$Class.$ID." name='".$Name."' value='".$Value."'".$Width.$Aditional.">\n";
		break;
		case "textarea" : // Element, Name, Value, Width, Height
			$Name=$Arg1; $Value=$Arg2; $Width=$Arg3; $Height=$Arg4;
			if ($Value=="default") $Value="";
			if ($Width=="default") { $Width=""; } else { $Width=" style='width: $Width;' "; }
			if ($Height=="default") { $Height=""; } else { $Height=" Rows='$Height' "; }
			return "<textarea class='f_text' name='".$Name."'".$Width.$Height.">".$Value."</textarea>\n";
		break;
		case "password" : // Element, Name, Value, Width, Aditional
			$Name=$Arg1; $Value=$Arg2; $Width=$Arg3; $Aditional=$Arg4;
			if (strpos($Name,"[")===FALSE) {
				$ID="";
			} else {
				$Tmp=split("[",$Name);
				$TmpID=split("]",$Tmp[1]);
				$ID=" ID='".$TmpID[0]."' ";
			}
			if ($Value=="default") $Value="";
			if ($Width=="default") { $Width=""; } else { $Width=" style='width: $Width;' "; }
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			return "<input type='password' class='f_text'".$ID." name='".$Name."' value='".$Value."'".$Width.$Aditional.">\n";
		break;
		case "radio" : // Element, Name, Value, Selected, Aditional
			$Name=$Arg1; $Value=$Arg2; $Selected=$Arg3; $Aditional=$Arg4;
			if (strpos($Name,"[")===FALSE) {
				$ID="";
			} else {
				$Tmp=split("[",$Name);
				$TmpID=split("]",$Tmp[1]);
				$ID=" ID='".$TmpID[0]."' ";
			}
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			if ($Selected=="default") { $Selected=""; } else { $Selected=" checked"; }
			return "<input type='radio'".$ID." name='".$Name."' value='".$Value."'".$Selected.$Aditional.">"; break;
		break;
		case "checkbox" : // Element, Name, Value, Selected, Aditional
			$Name=$Arg1; $Value=$Arg2; $Selected=$Arg3; $Aditional=$Arg4;
			if (strpos($Name,"[")===FALSE) {
				$ID="";
			} else {
				$Tmp=split("[",$Name);
				$TmpID=split("]",$Tmp[1]);
				$ID=" ID='".$TmpID[0]."' ";
			}
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			if ($Selected=="default") { $Selected=""; } else { $Selected=" checked"; }
			return "<input type='checkbox'".$ID." name='".$Name."' value='".$Value."'".$Selected.$Aditional.">";
		break;
		case "submit" : // Element, Heading, Class
			$Value=$Arg1;
			$Class=$Arg2;
			if ($Class=="default") { $Class="f_text"; }
			return "<input type='submit' class='$Class' name='$Value' value='$Value'>";
		break;
		case "button" : // Element, Name, Heading, OnClick
			$Name=$Arg1; $Value=$Arg2; $OnClick=$Arg3;
			if ($OnClick=="default") { $OnClick=""; } else { $OnClick=" OnClick='".$OnClick."'"; }
			return "<input type='button' class='f_text' name='".$Name."' value='".$Value."'".$OnClick.">";
		break;
		case "select" : // Element, Name, Values, Selected, Width, Labels, Aditional
			$Name=$Arg1; $Values=$Arg2; $Selected=$Arg3; $Width=$Arg4; $Labels=$Arg5; $Aditional=$Arg6;
			if (!is_array($Values)) $Values=Array("!!!���� �������� ���������!!!");
			if ($Width=="default") { $Width=""; } else { $Width=" style='width: $Width;' "; }
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			if (strpos($Name,"[")===FALSE) {
				$ID="";
			} else {
				$Tmp=split("\[",$Name);
				$TmpID=split("\]",$Tmp[1]);
				$ID=" ID='".$TmpID[0]."' ";
			}
			$ret="<select class='f_text' name='".$Name."'".$ID.$Width.$Aditional.">";
			while(list($key,$val)=each($Values)) {
				$CurrentLabel="";
				if (isset($Labels[$key])) $CurrentLabel=" Label='".$Labels[$key]."'";
				$ret.="<option value='".$key."'".$CurrentLabel.($Selected==$key ? " selected" : "" ).">".$val."</option>\n";
			} // while
			$ret.="</select>";
			return $ret;
		break;
		case "reset" : // Element, Heading
			$Value=$Arg1;
			if ($Value=="default") $Value="��������";
			return "<input type='reset' class='f_text' name='reset' value='".$Value."'>";
		break;
		default : // (ANY)
			return "</form>";
		break;
	} // switch
} // function Element

function puHeading($Heading,$BR=1) {
	$ret="";
	$ret.="<span class='h1s'>".$Heading."</span>";
	for ($t=0; $t<$BR; $t++) $ret.="<BR>";
	return $ret."\n";
} // heading

function puMyQuery($Query) {
Global $sql;
	$Res=mysql_query($Query) or Die (puError("Error!","<br>Invalid DataBase Query.","<PRE>The query is:<br>$Query</PRE>If the problem persists, contact the system administrator."));
	return $Res;
} // function MyQuery

function puMyFetch($Query) {
Global $sql;
	$Res=mysql_fetch_array(mysql_query($Query)) or Die (puError("Error!","<br>Invalid DataBase Query.","<PRE>The query is:<br>$Query</PRE>If the problem persists, contact the system administrator."));
	return $Res;
} // function MyFetch

function puRegistered($Who) {
Global $Stoitsov;
	$ret=-1;
	if (isset($Stoitsov) && session_is_registered("Stoitsov") && $Who["puUsername"]===$Stoitsov["puUsername"] && $Who["puScreenName"]===$Stoitsov["puScreenName"] && $Who["ID"]===$Stoitsov["ID"] && $Who["puAdmin"]===$Stoitsov["puAdmin"])
		$ret=1;
	if (isset($Stoitsov) && session_is_registered("Stoitsov") && $Who["puAdmin"]==1)
		$ret=2;
	return $ret;
}

function BBCode2HTML($Text) {
	$Text=strip_tags($Text);
	$TextArray=split("\n",$Text);
	$Text="";
	foreach ($TextArray as $Line) {
		$patterns = array(); $replacements = array();
		$patterns[0]="#\[img\](.*?)\[/img\]#si"; $replacements[0]="<img src=\"\\1\" alt=\"\\1\"border=\"0\">";
		$patterns[1]="#\[url\]([a-z]+?://){1}(.*?)\[/url\]#si"; $replacements[1]="<a href=\"http://\\2\" target=\"_blank\" class=normal>\\2</a>";
		$patterns[2]="#\[url\](.*?)\[/url\]#si"; $replacements[2]="<a href=\"http://\\1\" target=\"_blank\" class=normal>\\1</a>";
		$patterns[3]="#\[url=([a-z]+?://){1}(.*?)\](.*?)\[/url\]#si"; $replacements[3]="<a href=\"http://\\2\" target=\"_blank\" class=normal>\\3</a>";
		$patterns[4]="#\[url=(.*?)\](.*?)\[/url\]#si"; $replacements[4]="<a href=\"http://\\1\" target=\"_blank\" class=normal>\\2</a>";
		$patterns[5]="/\[color=(\#[0-9A-F]{6}|[a-z]+)\]/si"; $replacements[5]="<font color=\"\\1\">";
		$patterns[6]="#\[/color\]#si"; $replacements[6]="</font>";
		$patterns[7]="/\[size=([\-\+]?[1-2]?[0-9])\]/si"; $replacements[7]="<span style=\"font-size: \\1px; line-height: normal\">";
		$patterns[8]="#\[/size\]#si"; $replacements[8]="</span>";
		$Line = preg_replace($patterns, $replacements, $Line);
		$Line=str_replace("[ul","<ul",$Line); // UL Start
		$Line=str_replace("[/ul","</ul",$Line); // UL End
		$Line=str_replace("[b","<b",$Line); // Bold Start
		$Line=str_replace("[/b","</b",$Line); // Bold End
		$Line=str_replace("[i","<i",$Line); // Italic Start
		$Line=str_replace("[/i","</i",$Line); // Italic End
		$Line=str_replace("[u","<u",$Line); // Underline Start
		$Line=str_replace("[/u","</u",$Line); // Underline End
		$Line=str_replace("[p","<p class=news",$Line); // Paragraf Start
		$Line=str_replace("[/p","</p",$Line); // paragraf End
		$Line=str_replace("[h1","<br><span class=h2s",$Line); // Heading 1 Start
		$Line=str_replace("[/h1]","</span><br>",$Line); // Heading 1 End
		$Line=str_replace("[h2","<br><span class=h3s",$Line); // Heading 2 Start
		$Line=str_replace("[/h2]","</span><br>",$Line); // Heading 2 End
		$Line=str_replace("]",">",$Line); // Close tags
		$Line=str_replace("'","`",$Line); // Close tags
		$Text.=$Line;
	} // foreach
	return $Text;
}

function puShowAuthor($ID) {
Global $EasyPublish,$sql;
	$Author=puMyFetch("SELECT puScreenName, puMail FROM puUsers WHERE ID=$ID LIMIT 1;");
	if (!$EasyPublish["Contact"]) {
		return "<i>".$Author["puScreenName"]."</i>";
	} else {
		return "<a href='mailto:".$Author["puMail"]."' class=normal><i>".$Author["puScreenName"]."</i></a>";
	}
}

// ********************************************************************
// ************************ Actions
// ********************************************************************

if ($action=="login") {
	$Check=puMyQuery("SELECT ID, puUsername, puScreenName, puAdmin FROM puUsers WHERE BINARY puUsername='".puHackers($puUsername)."' AND BINARY puPassword='".puHackers($puPassword)."' LIMIT 1;");
	if (mysql_num_rows($Check)!=0) { // valid user
		$Stoitsov=mysql_fetch_array($Check);
		session_register("Stoitsov");
	} else { // invalid user
		$Error="<b>Invalid username or password.</b><br>";
		$page="login";
	}// if
} // Login

if ($action=="logout") {
	session_unregister("Stoitsov");
	unset($Stoitsov);
} // Logout

if ($action=="add_user") {
	if (puRegistered($Stoitsov)!=2) { // invalid user
		$page="login";
		$Error="<b>You need to be an administrator to use this function.</b><br>";
	} else { // valid
		unset($Error);
		if (strlen(puHackers($puUsername))<4) $Error.="<b>Username is invalid. Min 4 chars.</b><br>";
		if (strlen(puHackers($puPassword))<4) $Error.="<b>Password is invalid. Min 4 chars.</b><br>";
		if (strlen(puHackers($puScreenName))<5) $Error.="<b>Screen Name is invalid. Min 5 chars.</b><br>";
		if (strlen(puHackers($puMail))<1) $Error.="<b>E-mail is empty. Must supply valid e-mail.</b><br>";
		if (isset($Error)) { // There are errors
			$page="users";
			$do="add_user";
		} else { // Add User
			puMyQuery("INSERT INTO puUsers VALUES(null,'".puHackers($puUsername)."','".puHackers($puPassword)."','".puHackers($puScreenName)."','".puHackers($puMail)."','".puHackers($puAdmin)."');");
			$page="users";
		} // if Errors
	} // if valid
} // Add User

if ($action=="edit_user") {
	if (puRegistered($Stoitsov)!=2) { // invalid user
		$page="login";
		$Error="<b>You need to be an administrator to use this function.</b><br>";
	} else { // valid
		unset($Error);
		if (strlen(puHackers($puUsername))<4) $Error.="<b>Username is invalid. Min 4 chars.</b><br>";
		if (strlen(puHackers($puPassword))<4) $Error.="<b>Password is invalid. Min 4 chars.</b><br>";
		if (strlen(puHackers($puScreenName))<5) $Error.="<b>Screen Name is invalid. Min 5 chars.</b><br>";
		if (strlen(puHackers($puMail))<1) $Error.="<b>E-mail is empty. Must supply valid e-mail.</b><br>";
		if (isset($Error)) { // There are errors
			$page="users";
			$do="edit_user";
			$id=$puID;
		} else { // Edit User
			puMyQuery("UPDATE puUsers SET puUsername='".puHackers($puUsername)."', puPassword='".puHackers($puPassword)."', puScreenName='".puHackers($puScreenName)."', puMail='".puHackers($puMail)."', puAdmin='".puHackers($puAdmin)."' WHERE ID=$puID;");
			$page="users";
		} // if Errors
	} // if valid
} // Edit User

if ($action=="add_news") {
	if (puRegistered($Stoitsov)<0) { // invalid user
		$page="login";
		$Error="<b>You need to be a registered user to use this function.</b><br>";
	} else { // valid
		if (isset($Preview)) { // Preview only
			$page="add_news";
		} else { // Check for errors
			unset($Error);
			if (strlen(puHackers($puHeading))<4) $Error.="<b>Heading is invalid. Min 4 chars.</b><br>";
			if (strlen(puHackers($message))<4) $Error.="<b>Body is invalid. Min 4 chars.</b><br>";
			if (strlen(puHackers($puDate))!=10) $Error.="<b>Date is invalid. Date format: YYYY-MM-DD.</b><br>";
			if (isset($Error)) { // There are errors
				$page="add_news";
			} else { // Add news
				puMyQuery("INSERT INTO puPublish VALUES(null,'".puHackers($puHeading)."','".puHackers($message)."','".puHackers($puDate)."','".puHackers($puUserID)."');");
			} // if Errors
		} // Error check
	} // if valid
} // Add News

if ($action=="edit_news") {
	if (puRegistered($Stoitsov)<0) { // invalid user
		$page="login";
		$Error="<b>You need to be a registered user to use this function.</b><br>";
	} else { // valid
		if (isset($Preview)) { // Preview only
			$page="edit_news";
		} else { // Check for errors
			unset($Error);
			if (strlen(puHackers($puHeading))<4) $Error.="<b>Heading is invalid. Min 4 chars.</b><br>";
			if (strlen(puHackers($message))<4) $Error.="<b>Body is invalid. Min 4 chars.</b><br>";
			if (strlen(puHackers($puDate))!=10) $Error.="<b>Date is invalid. Date format: YYYY-MM-DD.</b><br>";
			if (isset($Error)) { // There are errors
				$page="edit_news";
			} else { // Edit news
				puMyQuery("UPDATE puPublish SET puHeading='".puHackers($puHeading)."', puBody='".puHackers($message)."', puDate='".puHackers($puDate)."', puUserID='".puHackers($puUserID)."' WHERE ID=$id;");
			} // if Errors
		} // Error check
	} // if valid
} // Edit News

if ($action=="delete") {
	if (puRegistered($Stoitsov)<0) { // invalid user
		$page="login";
		$Error="<b>You need to be a registered user to use this function.</b><br>";
	} else { // valid
		puMyQuery("DELETE FROM puPublish WHERE ID=$id;");
	}
} // delete


// session_write_close();

// ********************************************************************
// **************   EasyPublish Screen Creation
// ********************************************************************

// Login page
if (isset($page) && $page=="login") {
	$ResultHtml="";
	$ResultHtml.=puHeading("User authorization",1).
	"You need to be registered user in order to add, edit or delete ".$EasyPublish["Articles"].".<br><br><br>
	<div align=center>
	<table border='0' cellspacing='1' cellpadding='2' bgcolor='".$EasyPublish["DarkColor"]."' width=200>
		<tr>
			<td colspan=2>&nbsp;<font color=".$EasyPublish["Background"]."><b>.: Login</b></font></td>
		</tr>
		".puElement("form",$PHP_SELF,"Login","POST")."
		<tr>
			<td bgcolor=".$EasyPublish["Background"]." align=right><b>Username:</b></td>
			<td bgcolor=".$EasyPublish["Background"].">".puElement("text","puUsername",$puUsername,100)."</td>
		</tr>
		<tr>
			<td bgcolor=".$EasyPublish["Background"]." align=right><b>Password:</b></td>
			<td bgcolor=".$EasyPublish["Background"].">".puElement("password","puPassword","",100)."</td>
		</tr>
		<tr>
			<td colspan=2 align=right>".puElement("submit","Login","f_button")."</td>
		</tr>
		".puElement("hidden","action","login").puElement()."
	</table><br>".
	$Error
	."</div>
	";
} // end: Login Page

// Users page
if (isset($page) && $page=="users" && puRegistered($Stoitsov)==2) {
	$ResultHtml="";
	if ($do=="add_user") { // Add new user
		$ResultHtml.=puHeading("Add User",1).
		"Registered users can add, edit or delete ".$EasyPublish["Articles"].".<br><br><br>
		<div align=center>
		<table border='0' cellspacing='1' cellpadding='2' bgcolor='".$EasyPublish["DarkColor"]."' width=350>
			<tr>
				<td colspan=2>&nbsp;<font color=".$EasyPublish["Background"]."><b>.: New user information</b></font></td>
			</tr>
			".puElement("form",$PHP_SELF,"NewUser","POST")."
			<tr>
				<td bgcolor=".$EasyPublish["Background"]." align=right><b>Username:</b></td>
				<td bgcolor=".$EasyPublish["Background"].">".puElement("text","puUsername","",100)."</td>
			</tr>
			<tr>
				<td bgcolor=".$EasyPublish["Background"]." align=right><b>Password:</b></td>
				<td bgcolor=".$EasyPublish["Background"].">".puElement("text","puPassword","",100)."</td>
			</tr>
			<tr>
				<td bgcolor=".$EasyPublish["Background"]." align=right><b>Screen name:</b></td>
				<td bgcolor=".$EasyPublish["Background"].">".puElement("text","puScreenName","",200)."</td>
			</tr>
			<tr>
				<td bgcolor=".$EasyPublish["Background"]." align=right><b>E-mail:</b></td>
				<td bgcolor=".$EasyPublish["Background"].">".puElement("text","puMail","",200)."</td>
			</tr>
			<tr>
				<td bgcolor=".$EasyPublish["Background"]." align=right><b>Administrator?</b></td>
				<td bgcolor=".$EasyPublish["Background"].">".puElement("select","puAdmin",Array(0=>"No",1=>"Yes"),100)."</td>
			</tr>
			<tr>
				<td colspan=2 align=right>".puElement("submit","Create","f_button")."</td>
			</tr>
			".puElement("hidden","action","add_user").puElement()."
		</table><br>".
		$Error
		."</div>
		";
	} elseif ($do=="edit_user" && isset($id)) { // Edit user
		$EditUser=puMyFetch("SELECT * FROM puUsers WHERE ID=$id LIMIT 1;");
		$ResultHtml.=puHeading("Edit User",1).
		"Registered users can add, edit or delete ".$EasyPublish["Articles"].".<br><br><br>
		<div align=center>
		<table border='0' cellspacing='1' cellpadding='2' bgcolor='".$EasyPublish["DarkColor"]."' width=350>
			<tr>
				<td colspan=2>&nbsp;<font color=".$EasyPublish["Background"]."><b>.: User information</b></font></td>
			</tr>
			".puElement("form",$PHP_SELF,"EditUser","POST")."
			<tr>
				<td bgcolor=".$EasyPublish["Background"]." align=right><b>Username:</b></td>
				<td bgcolor=".$EasyPublish["Background"].">".puElement("text","puUsername",$EditUser["puUsername"],100)."</td>
			</tr>
			<tr>
				<td bgcolor=".$EasyPublish["Background"]." align=right><b>Password:</b></td>
				<td bgcolor=".$EasyPublish["Background"].">".puElement("text","puPassword",$EditUser["puPassword"],100)."</td>
			</tr>
			<tr>
				<td bgcolor=".$EasyPublish["Background"]." align=right><b>Screen name:</b></td>
				<td bgcolor=".$EasyPublish["Background"].">".puElement("text","puScreenName",$EditUser["puScreenName"],200)."</td>
			</tr>
			<tr>
				<td bgcolor=".$EasyPublish["Background"]." align=right><b>E-mail:</b></td>
				<td bgcolor=".$EasyPublish["Background"].">".puElement("text","puMail",$EditUser["puMail"],200)."</td>
			</tr>
			<tr>
				<td bgcolor=".$EasyPublish["Background"]." align=right><b>Administrator?</b></td>
				<td bgcolor=".$EasyPublish["Background"].">".puElement("select","puAdmin",Array(0=>"No",1=>"Yes"),$EditUser["puAdmin"],100)."</td>
			</tr>
			<tr>
				<td colspan=2 align=right>".puElement("submit","Change","f_button")."</td>
			</tr>
			".puElement("hidden","action","edit_user").puElement("hidden","puID",$EditUser["ID"]).
			puElement()."
		</table><br>".
		$Error
		."</div>
		";
	} else { // User List
		$ResultHtml.=puHeading("Registered Users",1).
		"Registered users can add, edit or delete ".$EasyPublish["Articles"].".<br><br><br>
		<div align=center>
		<table border='0' cellspacing='1' cellpadding='2' width=90%>
			<tr bgcolor='".$EasyPublish["DarkColor"]."'>
				<td colspan=4>&nbsp;<font color=".$EasyPublish["Background"]."><b>.: Registered Users List</b></font></td>
			</tr>
			<tr bgcolor='".$EasyPublish["LightColor1"]."'>
				<td><b>Screen Name</b></td>
				<td><b>E-mail</b></td>
				<td align=center><b>Admin</b></td>
				<td align=center><b>Edit</b></td>
			</tr>";
		$RegUsers=puMyQuery("SELECT * FROM puUsers Order by puScreenName");
		$i=0;
		while ($RegUser=mysql_fetch_array($RegUsers)) {
			$i++;
			if ($i % 2 != 0) { $color=""; } else { $color=" bgcolor='".$EasyPublish["LightColor2"]."'"; }
			$ResultHtml.="
			<tr".$color.">
				<td><b>".$RegUser["puScreenName"]."</b></td>
				<td><a href='mailto:".$RegUser["puMail"]."' class=normal>".$RegUser["puMail"]."</a></td>
				<td align=center>".($RegUser["puAdmin"]==1 ? "Yes" : "No" )."</td>
				<td align=center><a href='$PHP_SELF?page=users&do=edit_user&id=".$RegUser["ID"]."' class=normal>Edit</a></td>
			</tr>
			";
		}
		$ResultHtml.="
			<tr bgcolor='".$EasyPublish["DarkColor"]."'>
				<td>".puTr()."<br></td>
				<td>".puTr()."<br></td>
				<td>".puTr()."<br></td>
				<td>".puTr()."<br></td>
			</tr>
		</table><br>
		<b>Note:</b> You can not delete existing users as they could be published some ".$EasyPublish["Articles"].".<br>You can rather change their password or assign their account to a new user, so they will not be able to logon.</div>
		";
	} // end page type
} // end: Users Page

// Add news page
if (isset($page) && $page=="add_news" && puRegistered($Stoitsov)>0) {
	$ResultHtml="";
	$ResultHtml.="<script language=\"JavaScript\" type=\"text/javascript\">
	<!--
	// bbCode control by subBlue design (www.subBlue.com)
	var imageTag = false; var theSelection = false;
	var clientPC = navigator.userAgent.toLowerCase(); var clientVer = parseInt(navigator.appVersion);
	var is_ie = ((clientPC.indexOf(\"msie\") != -1) && (clientPC.indexOf(\"opera\") == -1));
	var is_nav  = ((clientPC.indexOf('mozilla')!=-1) && (clientPC.indexOf('spoofer')==-1) && (clientPC.indexOf('compatible') == -1) && (clientPC.indexOf('opera')==-1) && (clientPC.indexOf('webtv')==-1) && (clientPC.indexOf('hotjava')==-1));
	var is_win   = ((clientPC.indexOf(\"win\")!=-1) || (clientPC.indexOf(\"16bit\") != -1)); var is_mac    = (clientPC.indexOf(\"mac\")!=-1);
	b_help = \"Bold text: [b]text[/b]  (alt+b)\"; i_help = \"Italic text: [i]text[/i]  (alt+i)\"; u_help = \"Underline text: [u]text[/u]  (alt+u)\"; q_help = \"Paragraf text: [p]text[/p]  (alt+q)\"; c_help = \"Heading 1: [h1]Heading[/h1]  (alt+c)\"; l_help = \"Heading 2: [h2]text[/h2] (alt+l)\"; o_help = \"List: [ul]text[/ul]  (alt+o)\"; p_help = \"Insert image: [img]http://image_url[/img]  (alt+p)\"; w_help = \"Insert URL: [url]http://url[/url] or [url=http://url]URL text[/url]  (alt+w)\"; a_help = \"Close all open tags\"; s_help = \"Font color: [color=red]text[/color]  Tip: you can also use color=#FF0000\"; f_help = \"Font size: [size=x-small]small text[/size]\";
	bbcode = new Array(); bbtags = new Array('[b]','[/b]','[i]','[/i]','[u]','[/u]','[p]','[/p]','[h1]','[/h1]','[h2]','[/h2]','[ul]','[/ul]','[img]','[/img]','[url]','[/url]'); imageTag = false;
	function helpline(help) { document.post.helpbox.value = eval(help + \"_help\"); }
	function getarraysize(thearray) { for (i = 0; i < thearray.length; i++) { if ((thearray[i] == \"undefined\") || (thearray[i] == \"\") || (thearray[i] == null)) return i; } return thearray.length; }
	function arraypush(thearray,value) { thearray[ getarraysize(thearray) ] = value; }
	function arraypop(thearray) { thearraysize = getarraysize(thearray); retval = thearray[thearraysize - 1]; delete thearray[thearraysize - 1]; return retval; }
	function bbfontstyle(bbopen, bbclose) { if ((clientVer >= 4) && is_ie && is_win) { theSelection = document.selection.createRange().text; if (!theSelection) { document.post.message.value += bbopen + bbclose; document.post.message.focus(); return; } document.selection.createRange().text = bbopen + theSelection + bbclose; document.post.message.focus(); return; } else { document.post.message.value += bbopen + bbclose; document.post.message.focus(); return; } storeCaret(document.post.message); }
	function bbstyle(bbnumber) { donotinsert = false; theSelection = false; bblast = 0; if (bbnumber == -1) { while (bbcode[0]) { butnumber = arraypop(bbcode) - 1; document.post.message.value += bbtags[butnumber + 1]; buttext = eval('document.post.addbbcode' + butnumber + '.value'); eval('document.post.addbbcode' + butnumber + '.value =\"' + buttext.substr(0,(buttext.length - 1)) + '\"'); } imageTag = false; ocument.post.message.focus(); return; }
	if ((clientVer >= 4) && is_ie && is_win) theSelection = document.selection.createRange().text;
	if (theSelection) { document.selection.createRange().text = bbtags[bbnumber] + theSelection + bbtags[bbnumber+1]; document.post.message.focus(); theSelection = ''; return; }
	for (i = 0; i < bbcode.length; i++) { if (bbcode[i] == bbnumber+1) { bblast = i; donotinsert = true; } }
	if (donotinsert) { while (bbcode[bblast]) { butnumber = arraypop(bbcode) - 1; document.post.message.value += bbtags[butnumber + 1]; buttext = eval('document.post.addbbcode' + butnumber + '.value'); eval('document.post.addbbcode' + butnumber + '.value =\"' + buttext.substr(0,(buttext.length - 1)) + '\"'); imageTag = false; } document.post.message.focus(); return; } else { // Open tags
	if (imageTag && (bbnumber != 14)) { document.post.message.value += bbtags[15]; lastValue = arraypop(bbcode) - 1; document.post.addbbcode14.value = \"Img\";	imageTag = false; } document.post.message.value += bbtags[bbnumber];
	if ((bbnumber == 14) && (imageTag == false)) imageTag = 1; arraypush(bbcode,bbnumber+1); eval('document.post.addbbcode'+bbnumber+'.value += \"*\"'); document.post.message.focus(); return; } storeCaret(document.post.message); }
	function storeCaret(textEl) { if (textEl.createTextRange) textEl.caretPos = document.selection.createRange().duplicate(); }
	//-->
	</script>";
	$ResultHtml.=puHeading("Add ".$EasyPublish["Articles"],1).
	"Registered users can add, edit or delete ".$EasyPublish["Articles"].".<br><br>
	<b>Preview</b><br>
	<div style='background-color: ".$EasyPublish["LightColor2"].";'>
	<span class=h1s>".$puHeading."</span><br><br>".BBCode2HTML($message)."<br><b>Author:</b> ".puShowAuthor($Stoitsov["ID"])."<br>".$puDate."
	</div>
	".puElement("form",$PHP_SELF,"post","POST").puElement("submit","Preview","f_button")." ".puElement("submit","Add","f_button")."<br><br>
	<div align=center>
	<table border='0' cellspacing='1' cellpadding='2' bgcolor='".$EasyPublish["DarkColor"]."' width=100%>
		<tr>
			<td>&nbsp;<font color=".$EasyPublish["Background"]."><b>.: Add</b></font></td>
		</tr>
		<tr>
			<td bgcolor=".$EasyPublish["Background"]."><b>Heading</b><br>".puElement("text","puHeading",$puHeading,450)."</td>
		</tr>
		<tr>
			<td bgcolor=".$EasyPublish["Background"]."><b>Body</b><br>";
			$ResultHtml.="
			<table width=\"450\" border=\"0\" cellspacing=\"0\" cellpadding=\"2\">
				<tr align=\"center\" valign=\"middle\">
					<td><input type=\"button\" class=\"f_text\" accesskey=\"b\" name=\"addbbcode0\" value=\" B \" style=\"font-weight:bold; width: 30px\" onClick=\"bbstyle(0)\" onMouseOver=\"helpline('b')\" /></td>
					<td><input type=\"button\" class=\"f_text\" accesskey=\"i\" name=\"addbbcode2\" value=\" i \" style=\"font-style:italic; width: 30px\" onClick=\"bbstyle(2)\" onMouseOver=\"helpline('i')\" /></td>
					<td><input type=\"button\" class=\"f_text\" accesskey=\"u\" name=\"addbbcode4\" value=\" u \" style=\"text-decoration: underline; width: 30px\" onClick=\"bbstyle(4)\" onMouseOver=\"helpline('u')\" /></td>
					<td><input type=\"button\" class=\"f_text\" accesskey=\"q\" name=\"addbbcode6\" value=\"P\" style=\"width: 30px\" onClick=\"bbstyle(6)\" onMouseOver=\"helpline('q')\" /></td>
					<td><input type=\"button\" class=\"f_text\" accesskey=\"c\" name=\"addbbcode8\" value=\"Heading 1\" style=\"width: 55px\" onClick=\"bbstyle(8)\" onMouseOver=\"helpline('c')\" /></td>
					<td><input type=\"button\" class=\"f_text\" accesskey=\"l\" name=\"addbbcode10\" value=\"Heading 2\" style=\"width: 55px\" onClick=\"bbstyle(10)\" onMouseOver=\"helpline('l')\" /></td>
					<td><input type=\"button\" class=\"f_text\" accesskey=\"o\" name=\"addbbcode12\" value=\"List\" style=\"width: 40px\" onClick=\"bbstyle(12)\" onMouseOver=\"helpline('o')\" /></td>
					<td><input type=\"button\" class=\"f_text\" accesskey=\"p\" name=\"addbbcode14\" value=\"Img\" style=\"width: 40px\"  onClick=\"bbstyle(14)\" onMouseOver=\"helpline('p')\" /></td>
					<td><input type=\"button\" class=\"f_text\" accesskey=\"w\" name=\"addbbcode16\" value=\"URL\" style=\"text-decoration: underline; width: 40px\" onClick=\"bbstyle(16)\" onMouseOver=\"helpline('w')\" /></td>
				</tr>
				<tr>
					<td colspan=\"9\">
						<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
							<tr>
							  <td>&nbsp;Font colour:<select name=\"addbbcode18\" onChange=\"bbfontstyle('[color=' + this.form.addbbcode18.options[this.form.addbbcode18.selectedIndex].value + ']', '[/color]')\" onMouseOver=\"helpline('s')\" class=f_text>
								<option style=\"color:black; background-color: #FFFFFF \" value=\"#004c75\" >Default</option>\n<option style=\"color:darkred; background-color: #DEE3E7\" value=\"darkred\" >Dark Red</option>\n<option style=\"color:red; background-color: #DEE3E7\" value=\"red\" >Red</option>
								<option style=\"color:orange; background-color: #DEE3E7\" value=\"orange\" >Orange</option>\n<option style=\"color:brown; background-color: #DEE3E7\" value=\"brown\" >Brown</option>\n<option style=\"color:yellow; background-color: #DEE3E7\" value=\"yellow\" >Yellow</option>
								<option style=\"color:green; background-color: #DEE3E7\" value=\"green\" >Green</option>\n<option style=\"color:olive; background-color: #DEE3E7\" value=\"olive\" >Olive</option>\n<option style=\"color:cyan; background-color: #DEE3E7\" value=\"cyan\" >Cyan</option>
								<option style=\"color:blue; background-color: #DEE3E7\" value=\"blue\" >Blue</option>\n<option style=\"color:darkblue; background-color: #DEE3E7\" value=\"darkblue\" >Dark Blue</option>\n<option style=\"color:indigo; background-color: #DEE3E7\" value=\"indigo\" >Indigo</option>
								<option style=\"color:violet; background-color: #DEE3E7\" value=\"violet\" >Violet</option>\n<option style=\"color:white; background-color: #DEE3E7\" value=\"white\" >White</option>\n<option style=\"color:black; background-color: #DEE3E7\" value=\"black\" >Black</option>
								</select> &nbsp;Font size:<select name=\"addbbcode20\" onChange=\"bbfontstyle('[size=' + this.form.addbbcode20.options[this.form.addbbcode20.selectedIndex].value + ']', '[/size]')\" onMouseOver=\"helpline('f')\" class=f_text>
								<option value=\"7\" >Tiny</option>\n<option value=\"9\" >Small</option>\n<option value=\"12\" selected >Normal</option>\n<option value=\"18\" >Large</option>\n<option  value=\"24\" >Huge</option></select>
								</td>
				  				<td nowrap=\"nowrap\" align=\"right\"><a href=\"javascript:bbstyle(-1)\"  onMouseOver=\"helpline('a')\" class=normal>Close tags</a></td>
							</tr>
			  			</table>
					</td>
		  		</tr>
		  		<tr>
					<td colspan=\"9\"><input type=\"text\" name=\"helpbox\" size=\"45\" maxlength=\"100\" style=\"width:450px; font-size:10px\" class=\"info_panel\" value=\"Tip: Styles can be applied quickly to selected text.\" /></td>
				</tr>
		  		<tr>
					<td colspan=\"9\"><textarea name=\"message\" rows=\"15\" cols=\"35\" wrap=\"virtual\" style=\"width:450px\" tabindex=\"3\" class=\"post\" onselect=\"storeCaret(this);\" onclick=\"storeCaret(this);\" onkeyup=\"storeCaret(this);\" class=f_text>".$message."</textarea></td>
		  		</tr>
			</table>";
$ResultHtml.="</td>
		</tr>
		<tr>
			<td bgcolor=".$EasyPublish["Background"]."><b>Date</b> [YYYY-MM-DD]<br>".puElement("text","puDate",((isset($puDate) && $puDate!="") ? $puDate : date("Y-m-d") ),200)."</td>
		</tr>
		<tr>
			<td align=right>".puElement("submit","Preview","f_button")." ".puElement("submit","Add","f_button")."</td>
		</tr>
		".puElement("hidden","action","add_news").puElement("hidden","puUserID",$Stoitsov["ID"]).puElement()."
	</table><br>".
	$Error
	."</div>
	";
} // end: Add News Page

// Edit news page
if (isset($page) && $page=="edit_news" && isset($id) && puRegistered($Stoitsov)>0) {
	$ResultHtml="";
	$ResultHtml.="<script language=\"JavaScript\" type=\"text/javascript\">
	<!--
	// bbCode control by subBlue design (www.subBlue.com)
	var imageTag = false; var theSelection = false;
	var clientPC = navigator.userAgent.toLowerCase(); var clientVer = parseInt(navigator.appVersion);
	var is_ie = ((clientPC.indexOf(\"msie\") != -1) && (clientPC.indexOf(\"opera\") == -1));
	var is_nav  = ((clientPC.indexOf('mozilla')!=-1) && (clientPC.indexOf('spoofer')==-1) && (clientPC.indexOf('compatible') == -1) && (clientPC.indexOf('opera')==-1) && (clientPC.indexOf('webtv')==-1) && (clientPC.indexOf('hotjava')==-1));
	var is_win   = ((clientPC.indexOf(\"win\")!=-1) || (clientPC.indexOf(\"16bit\") != -1)); var is_mac    = (clientPC.indexOf(\"mac\")!=-1);
	b_help = \"Bold text: [b]text[/b]  (alt+b)\"; i_help = \"Italic text: [i]text[/i]  (alt+i)\"; u_help = \"Underline text: [u]text[/u]  (alt+u)\"; q_help = \"Paragraf text: [p]text[/p]  (alt+q)\"; c_help = \"Heading 1: [h1]Heading[/h1]  (alt+c)\"; l_help = \"Heading 2: [h2]text[/h2] (alt+l)\"; o_help = \"List: [ul]text[/ul]  (alt+o)\"; p_help = \"Insert image: [img]http://image_url[/img]  (alt+p)\"; w_help = \"Insert URL: [url]http://url[/url] or [url=http://url]URL text[/url]  (alt+w)\"; a_help = \"Close all open tags\"; s_help = \"Font color: [color=red]text[/color]  Tip: you can also use color=#FF0000\"; f_help = \"Font size: [size=x-small]small text[/size]\";
	bbcode = new Array(); bbtags = new Array('[b]','[/b]','[i]','[/i]','[u]','[/u]','[p]','[/p]','[h1]','[/h1]','[h2]','[/h2]','[ul]','[/ul]','[img]','[/img]','[url]','[/url]'); imageTag = false;
	function helpline(help) { document.post.helpbox.value = eval(help + \"_help\"); }
	function getarraysize(thearray) { for (i = 0; i < thearray.length; i++) { if ((thearray[i] == \"undefined\") || (thearray[i] == \"\") || (thearray[i] == null)) return i; } return thearray.length; }
	function arraypush(thearray,value) { thearray[ getarraysize(thearray) ] = value; }
	function arraypop(thearray) { thearraysize = getarraysize(thearray); retval = thearray[thearraysize - 1]; delete thearray[thearraysize - 1]; return retval; }
	function bbfontstyle(bbopen, bbclose) { if ((clientVer >= 4) && is_ie && is_win) { theSelection = document.selection.createRange().text; if (!theSelection) { document.post.message.value += bbopen + bbclose; document.post.message.focus(); return; } document.selection.createRange().text = bbopen + theSelection + bbclose; document.post.message.focus(); return; } else { document.post.message.value += bbopen + bbclose; document.post.message.focus(); return; } storeCaret(document.post.message); }
	function bbstyle(bbnumber) { donotinsert = false; theSelection = false; bblast = 0; if (bbnumber == -1) { while (bbcode[0]) { butnumber = arraypop(bbcode) - 1; document.post.message.value += bbtags[butnumber + 1]; buttext = eval('document.post.addbbcode' + butnumber + '.value'); eval('document.post.addbbcode' + butnumber + '.value =\"' + buttext.substr(0,(buttext.length - 1)) + '\"'); } imageTag = false; ocument.post.message.focus(); return; }
	if ((clientVer >= 4) && is_ie && is_win) theSelection = document.selection.createRange().text;
	if (theSelection) { document.selection.createRange().text = bbtags[bbnumber] + theSelection + bbtags[bbnumber+1]; document.post.message.focus(); theSelection = ''; return; }
	for (i = 0; i < bbcode.length; i++) { if (bbcode[i] == bbnumber+1) { bblast = i; donotinsert = true; } }
	if (donotinsert) { while (bbcode[bblast]) { butnumber = arraypop(bbcode) - 1; document.post.message.value += bbtags[butnumber + 1]; buttext = eval('document.post.addbbcode' + butnumber + '.value'); eval('document.post.addbbcode' + butnumber + '.value =\"' + buttext.substr(0,(buttext.length - 1)) + '\"'); imageTag = false; } document.post.message.focus(); return; } else { // Open tags
	if (imageTag && (bbnumber != 14)) { document.post.message.value += bbtags[15]; lastValue = arraypop(bbcode) - 1; document.post.addbbcode14.value = \"Img\";	imageTag = false; } document.post.message.value += bbtags[bbnumber];
	if ((bbnumber == 14) && (imageTag == false)) imageTag = 1; arraypush(bbcode,bbnumber+1); eval('document.post.addbbcode'+bbnumber+'.value += \"*\"'); document.post.message.focus(); return; } storeCaret(document.post.message); }
	function storeCaret(textEl) { if (textEl.createTextRange) textEl.caretPos = document.selection.createRange().duplicate(); }
	//-->
	</script>";
	if (!isset($step)) { // Load the News only first time, after that - preview
		$News=puMyFetch("SELECT * FROM puPublish WHERE ID=$id");
	}
	$ResultHtml.=puHeading("Edit ".$EasyPublish["Articles"],1).
	"Registered users can add, edit or delete ".$EasyPublish["Articles"].".<br><br>
	<b>Preview</b><br>
	<div style='background-color: ".$EasyPublish["LightColor2"].";'>
	<span class=h1s>".(isset($News) ? $News["puHeading"] : $puHeading )."</span><br><br>".BBCode2HTML((isset($News) ? $News["puBody"] : $message ))."<br><b>Author:</b> ".(isset($News) ? puShowAuthor($News["puUserID"]) : puShowAuthor($puUserID) )."<br>".(isset($News) ? $News["puDate"] : $puDate )."
	</div>
	".puElement("form",$PHP_SELF,"post","POST").puElement("submit","Preview","f_button")." ".puElement("submit","Update","f_button")."<br><br>
	<div align=center>
	<table border='0' cellspacing='1' cellpadding='2' bgcolor='".$EasyPublish["DarkColor"]."' width=100%>
		<tr>
			<td>&nbsp;<font color=".$EasyPublish["Background"]."><b>.: Edit</b></font></td>
		</tr>
		<tr>
			<td bgcolor=".$EasyPublish["Background"]."><b>Heading</b><br>".puElement("text","puHeading",(isset($News) ? $News["puHeading"] : $puHeading ),450)."</td>
		</tr>
		<tr>
			<td bgcolor=".$EasyPublish["Background"]."><b>Body</b><br>";
			$ResultHtml.="
			<table width=\"450\" border=\"0\" cellspacing=\"0\" cellpadding=\"2\">
				<tr align=\"center\" valign=\"middle\">
					<td><input type=\"button\" class=\"f_text\" accesskey=\"b\" name=\"addbbcode0\" value=\" B \" style=\"font-weight:bold; width: 30px\" onClick=\"bbstyle(0)\" onMouseOver=\"helpline('b')\" /></td>
					<td><input type=\"button\" class=\"f_text\" accesskey=\"i\" name=\"addbbcode2\" value=\" i \" style=\"font-style:italic; width: 30px\" onClick=\"bbstyle(2)\" onMouseOver=\"helpline('i')\" /></td>
					<td><input type=\"button\" class=\"f_text\" accesskey=\"u\" name=\"addbbcode4\" value=\" u \" style=\"text-decoration: underline; width: 30px\" onClick=\"bbstyle(4)\" onMouseOver=\"helpline('u')\" /></td>
					<td><input type=\"button\" class=\"f_text\" accesskey=\"q\" name=\"addbbcode6\" value=\"P\" style=\"width: 30px\" onClick=\"bbstyle(6)\" onMouseOver=\"helpline('q')\" /></td>
					<td><input type=\"button\" class=\"f_text\" accesskey=\"c\" name=\"addbbcode8\" value=\"Heading 1\" style=\"width: 55px\" onClick=\"bbstyle(8)\" onMouseOver=\"helpline('c')\" /></td>
					<td><input type=\"button\" class=\"f_text\" accesskey=\"l\" name=\"addbbcode10\" value=\"Heading 2\" style=\"width: 55px\" onClick=\"bbstyle(10)\" onMouseOver=\"helpline('l')\" /></td>
					<td><input type=\"button\" class=\"f_text\" accesskey=\"o\" name=\"addbbcode12\" value=\"List\" style=\"width: 40px\" onClick=\"bbstyle(12)\" onMouseOver=\"helpline('o')\" /></td>
					<td><input type=\"button\" class=\"f_text\" accesskey=\"p\" name=\"addbbcode14\" value=\"Img\" style=\"width: 40px\"  onClick=\"bbstyle(14)\" onMouseOver=\"helpline('p')\" /></td>
					<td><input type=\"button\" class=\"f_text\" accesskey=\"w\" name=\"addbbcode16\" value=\"URL\" style=\"text-decoration: underline; width: 40px\" onClick=\"bbstyle(16)\" onMouseOver=\"helpline('w')\" /></td>
				</tr>
				<tr>
					<td colspan=\"9\">
						<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
							<tr>
							  <td>&nbsp;Font colour:<select name=\"addbbcode18\" onChange=\"bbfontstyle('[color=' + this.form.addbbcode18.options[this.form.addbbcode18.selectedIndex].value + ']', '[/color]')\" onMouseOver=\"helpline('s')\" class=f_text>
								<option style=\"color:black; background-color: #FFFFFF \" value=\"#004c75\" >Default</option>\n<option style=\"color:darkred; background-color: #DEE3E7\" value=\"darkred\" >Dark Red</option>\n<option style=\"color:red; background-color: #DEE3E7\" value=\"red\" >Red</option>
								<option style=\"color:orange; background-color: #DEE3E7\" value=\"orange\" >Orange</option>\n<option style=\"color:brown; background-color: #DEE3E7\" value=\"brown\" >Brown</option>\n<option style=\"color:yellow; background-color: #DEE3E7\" value=\"yellow\" >Yellow</option>
								<option style=\"color:green; background-color: #DEE3E7\" value=\"green\" >Green</option>\n<option style=\"color:olive; background-color: #DEE3E7\" value=\"olive\" >Olive</option>\n<option style=\"color:cyan; background-color: #DEE3E7\" value=\"cyan\" >Cyan</option>
								<option style=\"color:blue; background-color: #DEE3E7\" value=\"blue\" >Blue</option>\n<option style=\"color:darkblue; background-color: #DEE3E7\" value=\"darkblue\" >Dark Blue</option>\n<option style=\"color:indigo; background-color: #DEE3E7\" value=\"indigo\" >Indigo</option>
								<option style=\"color:violet; background-color: #DEE3E7\" value=\"violet\" >Violet</option>\n<option style=\"color:white; background-color: #DEE3E7\" value=\"white\" >White</option>\n<option style=\"color:black; background-color: #DEE3E7\" value=\"black\" >Black</option>
								</select> &nbsp;Font size:<select name=\"addbbcode20\" onChange=\"bbfontstyle('[size=' + this.form.addbbcode20.options[this.form.addbbcode20.selectedIndex].value + ']', '[/size]')\" onMouseOver=\"helpline('f')\" class=f_text>
								<option value=\"7\" >Tiny</option>\n<option value=\"9\" >Small</option>\n<option value=\"12\" selected >Normal</option>\n<option value=\"18\" >Large</option>\n<option  value=\"24\" >Huge</option></select>
								</td>
				  				<td nowrap=\"nowrap\" align=\"right\"><a href=\"javascript:bbstyle(-1)\"  onMouseOver=\"helpline('a')\" class=normal>Close tags</a></td>
							</tr>
			  			</table>
					</td>
		  		</tr>
		  		<tr>
					<td colspan=\"9\"><input type=\"text\" name=\"helpbox\" size=\"45\" maxlength=\"100\" style=\"width:450px; font-size:10px\" class=\"info_panel\" value=\"Tip: Styles can be applied quickly to selected text.\" /></td>
				</tr>
		  		<tr>
					<td colspan=\"9\"><textarea name=\"message\" rows=\"15\" cols=\"35\" wrap=\"virtual\" style=\"width:450px\" tabindex=\"3\" class=\"post\" onselect=\"storeCaret(this);\" onclick=\"storeCaret(this);\" onkeyup=\"storeCaret(this);\" class=f_text>".(isset($News) ? $News["puBody"] : $message )."</textarea></td>
		  		</tr>
			</table>";
$ResultHtml.="</td>
		</tr>
		<tr>
			<td bgcolor=".$EasyPublish["Background"]."><b>Date</b> [YYYY-MM-DD]<br>".puElement("text","puDate",(isset($News) ? $News["puDate"] : ((isset($puDate) && $puDate!="") ? $puDate : date("Y-m-d") ) ),200)."</td>
		</tr>
		<tr>
			<td align=right>".puElement("submit","Preview","f_button")." ".puElement("submit","Update","f_button")."</td>
		</tr>
		".puElement("hidden","action","edit_news").puElement("hidden","step","set").puElement("hidden","id",$id).puElement("hidden","puUserID",(isset($News) ? $News["puUserID"] : $puUserID )).puElement()."
	</table><br>".
	$Error
	."</div>
	";
} // end: Edit News Page


// Start: Main Page
if (strlen($ResultHtml)==0) {
	$ResultHtml="";
	if (!isset($From) or $From=="") $From=0;
	if (!isset($Order) or $Order=="") $Order=0;
	switch ($Order) {
		case 1	: $QryOrder="puHeading Asc"; break;
		default	: $QryOrder="puDate Desc, ID Desc"; break;
	}
	$TotalNews=mysql_num_rows(puMyQuery("SELECT ID FROM puPublish;"));
	$Newss=puMyQuery("SELECT * FROM puPublish ORDER BY ".$QryOrder." LIMIT $From, ".$EasyPublish["news_per_page"].";");
	If ($TotalNews-$From-$EasyPublish["news_per_page"]>0) { $More=TRUE; } else { $More=FALSE; }
	while ($News=mysql_fetch_array($Newss)) {
		$ResultHtml.=NewsOut($News);
	} // while
	$ResultHtml.="<table border='0' cellspacing='1' cellpadding='2'><tr>
	".($From!=0 ? "<td><a href='$PHP_SELF?From=".($From-$EasyPublish["news_per_page"])."&Order=$Order' class=normal><img src='prev.gif' width='89' height='14' alt='Jump backward' border='0'></a></td>" : "" )."
	".($More ? "<td align=right><a href='$PHP_SELF?From=".($From+$EasyPublish["news_per_page"])."&Order=$Order' class=normal><img src='next.gif' width='68' height='14' alt='Jump forward' border='0'></a></td>" : "" )."
	</tr></table>";
}
// End: Main Page

// Start Contents page
if (isset($page) && $page=="contents" ) {
	$ResultHtml=puHeading($EasyPublish["Articles"]." Contents",2);
	if (!isset($From) or $From=="") $From=0;
	if (!isset($Order) or $Order=="") $Order=0;
	switch ($Order) {
		case 1	: $QryOrder="puHeading Asc"; break;
		default	: $QryOrder="puDate Desc, ID Desc"; break;
	}
	$TotalNews=mysql_num_rows(puMyQuery("SELECT ID FROM puPublish;"));
	$Newss=puMyQuery("SELECT ID,puHeading, puUserID, puDate FROM puPublish ORDER BY ".$QryOrder." LIMIT $From, ".$EasyPublish["head_per_page"].";");
	If ($TotalNews-$From-$EasyPublish["head_per_page"]>0) { $More=TRUE; } else { $More=FALSE; }
	while ($News=mysql_fetch_array($Newss)) {
		$ResultHtml.="<a href='$PHP_SELF?page=individual&fage=$page&read=".$News["ID"]."&From=$From&Order=$Order' class=normal><b>".$News["puHeading"]."</b></a><br>
		<b>Author:</b> ".puShowAuthor($News["puUserID"])." <b>Publish date:</b> ".$News["puDate"]."<br><br>\n\n";
	} // while
	$ResultHtml.="<table border='0' cellspacing='1' cellpadding='2'><tr>
	".($From!=0 ? "<td><a href='$PHP_SELF?page=$page&From=".($From-$EasyPublish["head_per_page"])."&Order=$Order' class=normal><img src='prev.gif' width='89' height='14' alt='Jump backward' border='0'></a></td>" : "" )."
	".($More ? "<td align=right><a href='$PHP_SELF?page=$page&From=".($From+$EasyPublish["head_per_page"])."&Order=$Order' class=normal><img src='next.gif' width='68' height='14' alt='Jump forward' border='0'></a></td>" : "" )."
	</tr></table>";
}
// End Contents page

// Start Authors page
if (isset($page) && $page=="authors" ) {
	$ResultHtml=puHeading($EasyPublish["Articles"]." Authors",2);
	if (!isset($From) or $From=="") $From=0;
	if (!isset($Order) or $Order=="") $Order=0;
	switch ($Order) {
		case 1	: $QryOrder="puHeading Asc"; break;
		default	: $QryOrder="puDate Desc, ID Desc"; break;
	}
	$TotalAuthors=mysql_num_rows(puMyQuery("SELECT ID FROM puUsers;"));
	$Authors=puMyQuery("SELECT ID , puScreenName FROM puUsers ORDER BY puScreenName LIMIT $From, ".$EasyPublish["head_per_page"].";");
	If ($TotalAuthors-$From-$EasyPublish["head_per_page"]>0) { $More=TRUE; } else { $More=FALSE; }
	while ($Author=mysql_fetch_array($Authors)) {
		$NewsForAuthor=mysql_num_rows(puMyQuery("SELECT ID FROM puPublish WHERE puUserID=".$Author["ID"].";"));
		$ResultHtml.="<a href='$PHP_SELF?page=search&search=".$Author["puScreenName"]."' class=normal><b>".$Author["puScreenName"]."</b></a><br>
		<b>Publications:</b> ".$NewsForAuthor."<br><br>\n\n";
	} // while
	$ResultHtml.="<table border='0' cellspacing='1' cellpadding='2'><tr>
	".($From!=0 ? "<td><a href='$PHP_SELF?page=$page&From=".($From-$EasyPublish["head_per_page"])."&Order=$Order' class=normal><img src='prev.gif' width='89' height='14' alt='Jump backward' border='0'></a></td>" : "" )."
	".($More ? "<td align=right><a href='$PHP_SELF?page=$page&From=".($From+$EasyPublish["head_per_page"])."&Order=$Order' class=normal><img src='next.gif' width='68' height='14' alt='Jump forward' border='0'></a></td>" : "" )."
	</tr></table>";
}
// End Authors page

// Start Search page
if (isset($page) && $page=="search" ) {
	$search=puHackers($search);
	$ResultHtml=puHeading($EasyPublish["Articles"]." Search",1)."<b>Search for \"$search\"</b><br><br>";
	if (!isset($From) or $From=="") $From=0;
	if (!isset($Order) or $Order=="") $Order=0;
	switch ($Order) {
		case 1	: $QryOrder="t1.puHeading Asc"; break;
		default	: $QryOrder="t1.puDate Desc, t1.ID Desc"; break;
	}
	$TotalNews=mysql_num_rows(puMyQuery("SELECT t1.ID,t1.puHeading, t1.puUserID, t1.puDate, t2.puScreenName FROM puPublish as t1, puUsers as t2 WHERE t2.ID=t1.puUserID AND (t1.puHeading like '%$search%' OR t1.puBody like '%$search%' OR t2.puScreenName like '%$search%') ORDER BY ".$QryOrder.";"));
	$Newss=puMyQuery("SELECT t1.ID,t1.puHeading, t1.puUserID, t1.puDate, t2.puScreenName FROM puPublish as t1, puUsers as t2 WHERE t2.ID=t1.puUserID AND (t1.puHeading like '%$search%' OR t1.puBody like '%$search%' OR t2.puScreenName like '%$search%') ORDER BY ".$QryOrder." LIMIT $From, ".$EasyPublish["head_per_page"].";");
	If ($TotalNews-$From-$EasyPublish["head_per_page"]>0) { $More=TRUE; } else { $More=FALSE; }
	while ($News=mysql_fetch_array($Newss)) {
		$ResultHtml.="<a href='$PHP_SELF?page=individual&fage=$page&read=".$News["ID"]."&From=$From&Order=$Order&search=$search' class=normal><b>".$News["puHeading"]."</b></a><br>
		<b>Author:</b> ".puShowAuthor($News["puUserID"])." <b>Publish date:</b> ".$News["puDate"]."<br><br>\n\n";
	} // while
	if ($TotalNews==0) $ResultHtml.="<p>No results found.</p>";
	$ResultHtml.="<table border='0' cellspacing='1' cellpadding='2'><tr>
	".($From!=0 ? "<td><a href='$PHP_SELF?page=$page&From=".($From-$EasyPublish["head_per_page"])."&Order=$Order' class=normal><img src='prev.gif' width='89' height='14' alt='Jump backward' border='0'></a></td>" : "" )."
	".($More ? "<td align=right><a href='$PHP_SELF?page=$page&From=".($From+$EasyPublish["head_per_page"])."&Order=$Order' class=normal><img src='next.gif' width='68' height='14' alt='Jump forward' border='0'></a></td>" : "" )."
	</tr></table>";
}
// End Contents page


// Start Individual page
if (isset($page) && $page=="individual" ) {
	$ResultHtml="";
	$News=puMyFetch("SELECT * FROM puPublish WHERE ID=$read;");
	$ResultHtml.=NewsOut($News);
	$ResultHtml.="<a href='$PHP_SELF?page=$fage&From=$From&Order=$Order&search=$search' class=normal><img src='back.gif' width='38' height='14' alt='Jump backward' border='0'></a></td>";
}
// End Individual page

// ********************************************************************
// ********************** BuildMenu
// ********************************************************************
$puMenu="";
if (puRegistered($Stoitsov)==2) { // is Admin
	$puMenu.="<b>Administrator</b><br><br>
	<a href='$PHP_SELF?page=users&do=add_user' class=normal>Add user</a><br>
	<a href='$PHP_SELF?page=users' class=normal>Manage users</a><br><br>
	";
}
if (puRegistered($Stoitsov)==1 or puRegistered($Stoitsov)==2) { // is reguser
	$puMenu.="<b>Registered users</b><br><br>
	<a href='$PHP_SELF?page=add_news' class=normal>Add ".$EasyPublish["Articles"]."</a><br><br>
	";
}
// Always shown
$puMenu.="<b>".$EasyPublish["Articles"]."</b><br><br>
<a href='$PHP_SELF' class=normal>The ".$EasyPublish["Articles"]."</a><br>
<a href='$PHP_SELF?page=contents' class=normal>Contents</a><br>
<a href='$PHP_SELF?page=authors' class=normal>Author list</a><br><br>
<b>".$EasyPublish["Articles"]." order</b><br><br>
<a href='$PHP_SELF?page=$page&From=$From&Order=0' class=normal>By Date</a><br>
<a href='$PHP_SELF?page=$page&From=$From&Order=1' class=normal>Alphabetical</a><br><br>
".puElement("form","$PHP_SELF","SEARCH","GET")."
<b>Search for</b><br>
".puElement("text","search",$search,100).puElement("hidden","page","search").puElement("submit","Go").puElement();


// ********************************************************************
// ********************** HTML Output
// ********************************************************************
//                                You may edit to suit your site design
//                  but *please* leave the donation button & author names

// Start HTML HEADER
echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<html>
<head>
<title>.: EasyPublish - v".$EasyPublish["version"]." :.</title>
<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=windows-1251\">
<META NAME=\"description\" CONTENT=\"EasyPublish Free Software - by http://software.stoitsov.com\">
<META NAME=\"author\" CONTENT=\"Idea & Script by Cyber/SAS\">
";
// DO NOT DELETE THIS!
echo "<script language='JavaScript'>function YesNo(fURL,fMessage) {	if (confirm(fMessage)) { self.top.location.href=fURL; } }</script>\n";
// CSS Style - Edit to fit your site design
echo "<style type=\"text/css\">
body {
	font: 11px Arial, Helvetica; color:black;
	background-color: ".$EasyPublish["Background"]."; scrollbar-DarkShadow-Color: ".$EasyPublish["DarkColor"].";
	scrollbar-Track-Color: ".$EasyPublish["DarkColor"]."; scrollbar-Face-Color:	".$EasyPublish["DarkColor"].";
	scrollbar-Shadow-Color:	".$EasyPublish["Background"]."; scrollbar-Highlight-Color: ".$EasyPublish["Background"].";
	scrollbar-3dLight-Color: ".$EasyPublish["DarkColor"]."; scrollbar-Arrow-Color: ".$EasyPublish["Background"].";
}
td {
	font: 11px Arial, Helvetica; color: black;
}
p.news {
	font: 11px Arial, Helvetica;
	margin-top:5;
	margin-bottom:5;
}
table.main_tbl {
	border: 1px dotted ".$EasyPublish["DarkColor"].";
}
.h1s {
	font: 18px Verdana; font-weight:bold; color: ".$EasyPublish["DarkColor"].";
}
.h2s {
	font: 12px Verdana; font-weight:bold; color: ".$EasyPublish["DarkColor"].";
}
.h3s {
	font: 12px Arial; font-weight:bold; color: ".$EasyPublish["DarkColor"].";
}
.f_text {
	font: 11px Arial, Helvetica;
	color: black;
	background-color: ".$EasyPublish["Background"].";
	border: 1px dotted ".$EasyPublish["DarkColor"].";
}
.info_panel {
	font: 11px Arial, Helvetica;
	color: black;
	background-color: ".$EasyPublish["LightColor1"].";
	border: 1px dotted ".$EasyPublish["DarkColor"].";
}
.f_button {
	font: 11px Arial, Helvetica;
	color: ".$EasyPublish["Background"].";
	background-color: ".$EasyPublish["DarkColor"].";
	border: 1px solid black;
}
a:link.normal, a:visited.normal {
	font: 11px Verdana; color: ".$EasyPublish["DarkColor"]."; text-decoration:none;
}
a:hover.normal {
	font: 11px Verdana; color: red; text-decoration:none;
}
</style>
";
// Start HTML BODY
echo "</head>
<body leftmargin='0' rightmargin='0' topmargin='0' background='background.gif'>
<table border='0' cellspacing='0' cellpadding='0' width='100%'>
	<tr>
		<td><a href='$PHP_SELF'><img src='logo.gif' width='170' height='80' alt='EasyPublish - v".$EasyPublish["version"]."' border='0'></a><br></td>
		<td width=100% background='repeat.gif'>".puTR()."<br></td>
		<td><a href='http://software.stoitsov.com' target=_stoitsov><img src='right.gif' width='189' height='80' alt='Get more free software!' border='0'></a></td>
	</tr>
</table>
<table border='0' cellspacing='0' cellpadding='0' width='100%'>
	<tr>
		<td>".puTr(10)."<br></td>
		<td valign=top>".puTr(150,1)."<br>".$puMenu."</td>
		<td>".puTr(20)."<br></td>
		<td valign=top width=100%>";
	echo $ResultHtml;
echo "	<br>
		</td>
		<td>".puTr(10)."<br></td>
	</tr>
</table>";
// HTML FOOTER START
echo "<br><div align=right><table border='0' cellspacing='0' cellpadding='0' width='70%'>
	<tr>
		<td width='100%' colspan=2 bgcolor='".$EasyPublish["DarkColor"]."'>".puTr(1,1)."<br></td>
	</tr>
	<tr>
		<td nowrap valign=top>
		".(puRegistered($Stoitsov)<0 ? "<a href='$PHP_SELF?page=login' class=normal><img src='secure.gif' width='20' height='7' alt='Login' border='0'> &nbsp;Registered users</a>"
			: "<a href='$PHP_SELF?action=logout' class=normal><img src='secure.gif' width='20' height='7' alt='Login' border='0'> &nbsp;".$Stoitsov["puScreenName"]." [Logout]</a>" )."</td>
		<td width='100%' align=right><font color='".$EasyPublish["DarkColor"]."'><b>EasyPublish</b> v".$EasyPublish["version"]." is a free software by </font><a href='http://software.stoitsov.com' class=normal target=_stoitsov.com>Stoitsov.com</a>&nbsp;&nbsp;<br>
		<a href='https://www.paypal.com/affil/pal=mario@stoitsov.com' target=_donate><img src='donate.gif' width='110' height='23' alt='Support us!' border='0' hspace=4 align=right></a>To keep it free & developing:
		</td>
	</tr>
</table></div>
";
// End HTML Output
echo "</body>\n</html>";
/*	******************************************************************
        ********************** EasyPublish v1.00a *************************
	******************************************** software.stoitsov.com  */
