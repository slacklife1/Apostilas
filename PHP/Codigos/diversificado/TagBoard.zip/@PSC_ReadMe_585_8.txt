Title: TagBoard
Description: This is a TagBoard or TagBox which ever you would like to call it. This is done in PHP and uses mySQL. It is really easy to setup and use. Works Great on IE but looks bad on NS Enjoy. 
I have included tagboard_export.sql file so you can import the table into mySQL and start using it.
I have included to versions of the TagBoard one is incorporated into a page "IPDG3 TagBoard"
The other "Just TagBoard Code" is just the code with and fully commented.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=585&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
