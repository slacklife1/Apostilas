# MySQL-Front Dump 2.1
#
# Host: 192.168.0.1   Database: test
#--------------------------------------------------------
# Server version 4.0.1-alpha-nt

USE test;


#
# Table structure for table 'tagboard'
#

DROP TABLE IF EXISTS tagboard;
CREATE TABLE IF NOT EXISTS tagboard (
  RecordID int(6) unsigned zerofill NOT NULL auto_increment,
  post varchar(255) ,
  PRIMARY KEY (RecordID)
);



#
# Dumping data for table 'tagboard'
#
