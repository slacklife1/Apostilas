Project Name: TagBoard


Description: This is a TagBoard or TagBox which ever you would like to call it. This
is done in PHP and uses mySQL. It is really easy to setup and use. Works Great on IE
but looks bad on NS Enjoy.

I have included tagboard_export.sql file so you can import the table into mySQL and start using it.

I have included to versions of the TagBoard one is incorporated into a page "IPDG3 TagBoard"
The other "Just TagBoard Code" is just the code with and fully commented.


This program was Written by George
Interactive PsyberTechnology Developers Group (IPDG3)

IPDG3 is Geared Toward Helping Developers and Programmers Find Resources

We offer resources for ASP, C/C++, CSS, CGI, Delphi, DHTML, Java, JavaScript,
.NET, Perl, PHP, Visual Basic, XML, databases, networking and many others.
We also have source code, tutorials, book reviews, contest, forums and
other computer Q&A. Consulting is also available.

Developing Products to fit all your computer needs as well as
giving you the tools to build future business today.

For more information please visit our website for details.
www.ipdg3.com - info@ipdg3.com


Book Reviews http://www.ipdg3.com/bookreview.php
Chatroom     http://www.ipdg3.com/chatroom.php
Forums       http://pub52.ezboard.com/binteractivepsybertechnologydevelopersgroup
Links        http://www.ipdg3.com/links.php
Source Code  http://www.ipdg3.com/sourcecode.php
Tutorials    http://www.ipdg3.com/tutorial.php
Contest      http://www.ipdg3.com/contest.php
ORB          http://www.ipdg3.com/orb.php


Source Code Disclaimer:
The example programs and source code snippets are provided "as is" with no warranty of any kind. They are intended for demonstration purposes only. In particular, they do not perform error handling. Please mention and give credit to the original author. IPDG3 is not responsible for anything that may happen due to misuse, use, or improper application, of the source code located on this site. Use this code at your own risk. IPDG3 does not perform virus checks so please scan file before you use it. 