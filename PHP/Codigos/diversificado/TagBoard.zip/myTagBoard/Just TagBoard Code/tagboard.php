<?PHP

// This is the database setup if you change the name of the
// DatabaseName, TableName, Username, or Password be sure to change it here.
$db_name = "test";
$table_name = "tagboard";
$link = mysql_connect("localhost", "root", "") or die("Could not connect to server!");

function display_post($db_name, $table_name, $link) {
    // This queries the last 20 post on your TagBoard
    $query1 = "SELECT * FROM $table_name ORDER BY RecordID DESC LIMIT 0, 20";
    $result1 = mysql_db_query($db_name, $query1, $link) or die("Could not complete database query1");
    $num1 = mysql_num_rows($result1);

    // This queries all the post in your TagBoard to return a Number of post
    $query2 = "SELECT * FROM $table_name";
    $result2 = mysql_db_query($db_name, $query2, $link) or die("Could not complete database query2");
    $num2 = mysql_num_rows($result2);

    // This just displays your Number of post
    echo "I have (<b>$num2</b>) post on myTagBoard";

    // This creates the form for displaying the last 20 post on your TagBoard
    $Msg .="<form name='tagboard' action=tagboard.php method='post'>\n";
    $Msg .="<input type='hidden' name='save_post' value='add'>\n";
    $Msg .="<textarea style='width:200; background-color:#f0f0f0; height:200; border:1 solid #0f0f0f; font-size:12; name='messages'\n";
    $Msg .="readonly='readonly'>\n";

    while ($row = mysql_fetch_array($result2)) {
      $Msg .= "$row[post]\n";
    }

    $Msg .="</textarea><br>\n";
    $Msg .="<input name='newpost' style='width:200; background-color:#f0f0f0; border:1 solid #0f0f0f; font-size:15; line-height:9pt;'>\n";
    $Msg .="</form>\n";

    // This Sets the Focus to the Add Post TextBox
    $Msg .="<script language='JavaScript' type='text/javascript'>\n";
    $Msg .="document.tagboard.newpost.focus()\n";
    $Msg .="</script>\n";

    return $Msg;
}

function add_post($db_name, $table_name, $link, $newpost) {
    if (!$newpost) {
        return false;
    }

    //  This adds a a time to your post
    $newpost = date("G:i")." - $newpost";

    // htmlspecialchars --  Convert special characters to HTML entities
    $newpost = htmlspecialchars($newpost);

    // This Adds the post to your mySQL database
    $query = "INSERT INTO $table_name (`post`) VALUES ('$newpost')";
    $result = mysql_db_query($db_name, $query, $link) or die("Could not complete database query add post");

    // This returns you back to the page
    if (!$result) {
        return false;
    } else {
        header("Location: http://YOurDomainGoesHere/tagboard.php");
//        header("Location: http://".$SERVER_NAME.$PHP_SELF);
    }
}

// This determines weather or not someone has posted
switch ($save_post) {
  case "add":
  print add_post($db_name, $table_name, $link, $newpost);
  break;
}

?>

<html>
<head>
<title>Tagboard example</title>
</head>
<body>

<?PHP
  echo "<b>This is <font color='#ff0000'>myTagboard</font> Enjoy</b><br>\n";

  // This goes and gets the messages and form to display and
  // allow more people to post.
  echo display_post($db_name, $table_name, $link);

?>

</body>
</html>
