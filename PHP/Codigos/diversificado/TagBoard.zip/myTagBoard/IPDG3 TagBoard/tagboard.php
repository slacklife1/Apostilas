<?PHP

$db_name = "test";
$table_name = "tagboard";
$link = mysql_connect("localhost", "root", "") or die("Could not connect to server!");

function display_post($db_name, $table_name, $link) {

    $query1 = "SELECT * FROM $table_name ORDER BY RecordID DESC LIMIT 0, 20";
    $result1 = mysql_db_query($db_name, $query1, $link) or die("Could not complete database query1");
    $num1 = mysql_num_rows($result1);

    $query2 = "SELECT * FROM $table_name";
    $result2 = mysql_db_query($db_name, $query2, $link) or die("Could not complete database query2");
    $num2 = mysql_num_rows($result2);

    echo "I have (<b>$num2</b>) post on myTagBoard";

    $Msg .="<form name='tagboard' action=tagboard.php method='post'>\n";
    $Msg .="<input type='hidden' name='save_post' value='add'>\n";
    $Msg .="<textarea style='width:200; background-color:#f0f0f0; height:200; border:1 solid #0f0f0f; font-size:12; name='messages'\n";
    $Msg .="readonly='readonly'>\n";

    while ($row = mysql_fetch_array($result2)) {
      $Msg .= "$row[post]\n";
    }

    $Msg .="</textarea><br>\n";
    $Msg .="<input name='newpost' style='width:200; background-color:#f0f0f0; border:1 solid #0f0f0f; font-size:15; line-height:9pt;'>\n";
    $Msg .="</form>\n";

    $Msg .="<script language='JavaScript' type='text/javascript'>\n";
    $Msg .="document.tagboard.newpost.focus()\n";
    $Msg .="</script>\n";

    return $Msg;
}

function add_post($db_name, $table_name, $link, $newpost) {
    if (!$newpost) {
        return false;
    }

    $newpost = date("G:i")." - $newpost";

    $newpost = htmlspecialchars($newpost);

    $query = "INSERT INTO $table_name (`post`) VALUES ('$newpost')";
    $result = mysql_db_query($db_name, $query, $link) or die("Could not complete database query add post");

    if (!$result) {
        return false;
    } else {
        header("Location: http:/YourDomainGoesHere/tagboard.php");
//        header("Location: http://".$SERVER_NAME.$PHP_SELF);
    }
}

switch ($save_post) {
  case "add":
  print add_post($db_name, $table_name, $link, $newpost);
  break;
}

?>

<html>
<head>
</head>

<body bgcolor='#f0f0f0' topmargin='0' leftmargin='0' marginwidth='0' marginheight='0' text='#000000' link='#000099' alink='#0000ff' vlink='#000099'>

<center>

<table border='0' cellspacing='0' cellpadding='0' width='600' bgcolor='#ffffff'>

<tr bgcolor='#f0f0f0'>
<td width='165' align='left' valign='middle'>
<font face='Verdana, Arial, Helvetica' size='2' color='#000000'>
&nbsp;<img src='phptitle1.gif' width='150' height='150' border='0' hspace='0' vspace='0'>
</font></td>

<td align='left' valign='middle' bgcolor='#f0f0f0'>
<font face='Verdana, Arial, Helvetica' size='2' color='#000000'>

<font color='#0000ff' size='3'><b>This Example was brought to you by IPDG3</b></font><br><br>
IPDG3 Helps Developers and Programmers Find Resources.<br><br>
We offer resources for ASP, C/C++, CSS, CGI, Delphi, DHTML, Java, JavaScript,
.NET, Perl, PHP, Visual Basic, XML, databases, networking and many others.
We also have source code, tutorials, book reviews, contest, forums and
other computer Q&A. Consulting is also available.

</font></td>

<table border='0' cellspacing='0' cellpadding='0' width='600' bgcolor='#ffffff'>
<td width='50' valign='center' align='left'><br></td>

<td width='500' valign='center' align='left'>
<font face='Verdana, Arial, Helvetica' size='2' color='#000000'><br><br>
<?php
echo "<b>\n";
echo date("l F j, Y");
echo "</b>&nbsp;\n";
?>
<h4><font color='#0000ff'>Tagboard Example</font></h4>


<?PHP
//Place Code Here

  echo "<b>This is <font color='#ff0000'>myTagboard</font> Enjoy</b><br>\n";
  echo display_post($db_name, $table_name, $link);

// End Code
?>


</font></td>

<td width='50' valign='center' align='left'><br></td>
</tr></table>

</center>
</body>
</html>

