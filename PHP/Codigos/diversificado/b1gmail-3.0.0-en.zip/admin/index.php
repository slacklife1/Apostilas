<html>
<head>
<title>Admin</title>
</head>
<frameset rows="50,*" border="0">
 <frame src="header.php" scrolling="no" name="header" noresize>
 <frame src="welcome.php" scrolling="auto" name="main" noresize>
</frameset>
</html>