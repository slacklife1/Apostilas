<?php
include("config.php");











//#########################################
function tableview () {
include("config.php");
echo "<br>";
$needed = func_num_args();
$admin = func_get_arg (0);
$db = func_get_arg (1);
$use = func_get_arg (2);
echo "<center>";
mysql_connect (localhost, $username, $password);
mysql_select_db (func_get_arg (1));
$result = mysql_query ("SHOW TABLES;");
        while($value = mysql_fetch_array($result))
        {
               //This loop goes through the colums and prints
               //each value
                for($i=0; $i< mysql_num_fields($result); $i++ )
                {
echo "<table width=40%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
print "<a href=\"index.php?myadmin=$use&admin=$admin&dbuse=$db&tableuse=$value[$i]\"><b><h3>$value[$i]</b></A><br>";
echo "</td></tr></table>";
echo "</td></tr></table>";
                }
        }
        mysql_free_result($result);
        mysql_close();
echo "</center>";
}
//########################################









//########################################
function dbview() {
echo "<center>";
echo "<br>";
$needed = func_num_args();
$adm = func_get_arg (0);
$use = func_get_arg (1);
$result = mysql_query ("SHOW DATABASES;");
        while($value = mysql_fetch_array($result))
        {
               //This loop goes through the colums and prints
               //each value
                for($i=0; $i< mysql_num_fields($result); $i++ )
                {
echo "<table width=40%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<a href=index.php?myadmin=$use&admin=$adm&dbuse=$value[$i]><h3><b>$value[$i]</b></A>";
echo "</td></tr></table>";
echo "</td></tr></table>";
                }
        }
        mysql_free_result($result);
        mysql_close();
echo "</center>";
}
//###########################################
?>
