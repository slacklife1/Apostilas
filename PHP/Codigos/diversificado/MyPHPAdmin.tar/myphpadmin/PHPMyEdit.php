<?php
/*
  This is a generic table editing program. The table and fields to be 
  edited are defined in the calling program. In this version, the table 
	must have a unique numeric field for record identification. This is the 
	main limitation.

  This program works in three passes. Pass 1 (the last part of
  the program) displays the selected MySQL table in a scrolling table
  on the screen. Radio buttons are used to select a record for editing
  or deletion. If the user chooses Add, Change, or Delete buttons,
  Pass 2 starts, displaying the selected record. If the user chooses 
  the Save button from this screen, Pass 3 processes the update and 
  the display returns to the original table view (Pass 1).

  version 19-Dec-00
*/
// PHP3 version only...
//function in_array($needle,$haystack)
// ivo@ibuildings.nl
//{ 
//  for($i=0;$i<count($haystack) && $haystack[$i] !=$needle;$i++); 
//  return ($i!=count($haystack)); 
//}
// 
/* 
  Table/fields definition
*/
while (list($a,$b) = each($fdd)) {$fds[] = $a;} /*SQL Field Names*/
$num_fds = sizeof($fds);

function set_values_from_table($db1,$tb,$fd)
{
  $qry = "SELECT DISTINCT ".$fd." FROM ".$tb." ORDER BY ".$fd;
  $res = mysql_db_query($db1,$qry);
  while($row = mysql_fetch_row($res))
	  { $values[]=$row[0]; } 
  return $values;
}
if   ( $key_type=="string"||$key_type=="blob"||$key_type=="date"||$key_type=="time") 
     { $key_delim="\""; }
else { $key_delim="";   }

$dbl = @mysql_pconnect($hn,$un,$pw)    
  or die ("<h1>Could not connect to MySQL</h1>\n");
if (!isset($db1)) { die ("<h1>No Database defined</h1>\n</body>\n</html>\n"); }
if (!isset($tb)) { die ("<h1>No Table defined</h1>\n</body>\n</html>\n"); }
/*
  ======================================================================
  Pass 2: display an input/edit/confirmation screen if the user has 
  selected an editing button on Pass 1 through this page
  ======================================================================
*/  
set_magic_quotes_runtime(0);
$listit = true;
if (($add == "Add") or ($change == "Change") or ($delete == "Delete"))
{
  $listit = false;
  echo "<form action=\"".basename($PHP_SELF)."\" method=\"POST\">\n";
  echo "<table border=\"1\" summary=\"".$tb."\">\n";
  echo "  <input type=\"hidden\" name=\"rec\" value=\"".$rec."\" />\n";
  echo "  <input type=\"hidden\" name=\"fm\" value=\"".$fm."\" />\n";
  echo "  <input type=\"hidden\" name=\"sf\" value=\"".$sf."\" />\n";

  if ($add == "Add")
  {
    for ($k=0 ; $k<$num_fds; $k++)
    {
      echo "  <tr>\n";
      echo "    <td>".$fdd[$fds[$k]]["name"]."</td>\n";

      if (isset($fdd[$fds[$k]]["values"]["table"])
      and isset($fdd[$fds[$k]]["values"]["column"]))
      { 
			  $fdd[$fds[$k]]["values"]=
	  		  set_values_from_table($db1,$fdd[$fds[$k]]["values"]["table"],
					                      $fdd[$fds[$k]]["values"]["column"]);
			}
      if (isset($fdd[$fds[$k]]["values"])) /*Drop down list required*/
      {
        echo "    <td><select name=\"".$fds[$k]."\" size=\"1\">\n";
        for ($l=0; $l<count($fdd[$fds[$k]]["values"]); $l++)
        { echo "          <option>".$fdd[$fds[$k]]["values"][$l]."</option>\n"; }
        echo "        </select></td>\n";
      } elseif (isset($fdd[$fds[$k]]["textarea"])) {
        echo "    <td><textarea ";
				if (isset($fdd[$fds[$k]]["textarea"]["rows"])) 
				{ echo "rows=\"".$fdd[$fds[$k]]["textarea"]["rows"]."\" "; }
				if (isset($fdd[$fds[$k]]["textarea"]["cols"])) 
				{ echo "cols=\"".$fdd[$fds[$k]]["textarea"]["cols"]."\" "; }
				echo "name=\"".$fds[$k]."\"></textarea></td>\n";
      } else {                            /*Simple edit box required*/
        echo "    <td><input type=\"text\" name=\"".$fds[$k]."\" value=\" \" /></td>\n";
      }
      echo "  </tr>\n";
    }
  } else {
/*
  for delete or change: SQL SELECT to retrieve the selected record
*/
    for ($k=0 ; $k<$num_fds; $k++)
    {
      if ($k==0) { $qry = "SELECT ".$fds[$k]; } 
            else { $qry = $qry.",".$fds[$k]; }
    }
    if (!in_array($key,$fds)) { $qry = $qry.",".$key; };
    $qry = $qry." FROM ".$tb." WHERE (".$key." = ".$key_delim.$rec.$key_delim.")";
    $res = mysql_db_query($db1,$qry);
    if ($row = mysql_fetch_array($res))
    {
      for ($k=0 ; $k<$num_fds; $k++)
      {
        echo "  <tr>\n";
        echo "    <td>".$fdd[$fds[$k]]["name"]."</td>\n";
        if ($change == "Change")
        { 
          if (isset($fdd[$fds[$k]]["values"]["table"])
          and isset($fdd[$fds[$k]]["values"]["column"]))
          { 
    			  $fdd[$fds[$k]]["values"]=
	  	    	  set_values_from_table($db1,$fdd[$fds[$k]]["values"]["table"],
					                          $fdd[$fds[$k]]["values"]["column"]);
	    		}
				  if (isset($fdd[$fds[$k]]["values"]))
          {
            echo "    <td><select name=\"".$fds[$k]."\" size=\"1\">\n";
            for ($l=0; $l<count($fdd[$fds[$k]]["values"]); $l++)
            {
              if ($fdd[$fds[$k]]["values"][$l] == $row[$fds[$k]])
              { $w = " selected value=\"".$fdd[$fds[$k]]["values"][$l]."\""; } else {$w = "";}
              echo "          <option".$w.">".$fdd[$fds[$k]]["values"][$l]."</option>\n"; 
            }
            echo "        </select></td>\n";
          } elseif (isset($fdd[$fds[$k]]["textarea"])) {
            echo "    <td><textarea ";
		    		if (isset($fdd[$fds[$k]]["textarea"]["rows"])) 
    				  { echo "rows=\"".$fdd[$fds[$k]]["textarea"]["rows"]."\" "; }
		    		if (isset($fdd[$fds[$k]]["textarea"]["cols"])) 
				      { echo "cols=\"".$fdd[$fds[$k]]["textarea"]["cols"]."\" "; }
				    echo "name=\"".$fds[$k]."\">".htmlentities($row[$fds[$k]])."</textarea></td>\n";
          } else {
            echo "    <td><input type=\"text\" name=\"".$fds[$k]."\" value=\"".htmlentities($row[$fds[$k]])."\" /></td>\n";
          }
        }  
        if ($delete == "Delete")
        { 
          if ($row[$fds[$k]]=="") {
					  echo "    <td>&nbsp;</td>\n";
					} else {
            echo "    <td>".htmlentities($row[$fds[$k]])."</td>\n";
					}
        }
        echo "  </tr>\n";
      }
    }
  }
  echo "</table>\n";      
  echo "<hr />\n";
  if ($add == "Add")
  { echo "<input type=\"submit\" name=\"saveadd\" value=\"Save\" />\n"; }
  if ($change == "Change")
  { echo "<input type=\"submit\" name=\"savechange\" value=\"Save\" />\n"; }
  if ($delete == "Delete")
  { echo "<input type=\"submit\" name=\"savedelete\" value=\"Delete\" />\n"; }
  echo "<input type=\"submit\" name=\"cancel\" value=\"Cancel\" />\n";
  echo "</form>\n";
}  
/*
  ======================================================================
  Pass 3: process any updates generated from the confirmation screen 
  displayed during Pass 2
  ======================================================================
*/  
if ($saveadd=="Save")
{
  for ($k=0 ; $k<$num_fds; $k++)
  {
    if ($k==0) { $qry = "INSERT INTO ".$tb." (".$fds[$k]; } 
          else { $qry = $qry.",".$fds[$k]; }
  }
  for ($k=0 ; $k<$num_fds; $k++)
  {
   if ($k==0) { $qry = $qry.") VALUES ('".$$fds[$k]."'"; } 
         else { $qry = $qry.",'".$$fds[$k]."'";} 
  }
  $qry = $qry.")";
  $res = mysql_db_query($db1,$qry);
  echo "<h5>".mysql_affected_rows()." record added</h5>\n";
}
if ($savechange=="Save")
{
  for ($k=0 ; $k<$num_fds; $k++)
  {
    if ($k==0) 
    { 
      $qry = "UPDATE ".$tb." SET ".$fds[$k]."='".$$fds[$k]."'"; 
    } else { 
      $qry = $qry.",".$fds[$k]."='".$$fds[$k]."'"; 
    }
  }
  $qry = $qry." WHERE (".$key." = ".$key_delim.$rec.$key_delim.")";
  $res = mysql_db_query($db1,$qry);
  echo "<h5>".mysql_affected_rows()." record changed</h5>\n";
}
if ($savedelete=="Delete")
{
  $qry = "DELETE FROM ".$tb." WHERE (".$key." = ".$key_delim.$rec.$key_delim.")";
  $res = mysql_db_query($db1,$qry);
  echo "<h5>".mysql_affected_rows()." record deleted</h5>\n";
}
/*
  ======================================================================
  Pass 1 and Pass 3: display the MySQL table in a scrolling window on 
  the screen.
  ======================================================================
*/
if ($listit)
{
/* Process any navigation buttons */

  if (!isset($fm)) {$fm = 0;}
  if ($prev == "Prev") 
  { 
    $fm = $fm - $inc;
    if ($fm < 0) { $fm = 0; }
  }
  if ($next == "Next")
  { 
    $fm = $fm + $inc;
  }
/* 
   If user is allowed to Change/Delete records, we need an extra column
   to allow users to select a record
*/
   $select_recs = ( (stristr($options,"C") or stristr($options,"D")) and 
	                  ($key != ""));
										
/* Default is to sort on first field */

  if ($sf == "") {$sf = $fds[0];}

/* Display the MySQL table in an HTML table */

  echo "<form action=\"".basename($PHP_SELF)."\" method=\"POST\">\n";
  echo "  <input type=\"hidden\" name=\"fm\" value=\"".$fm."\" />\n";
  echo "  <input type=\"hidden\" name=\"sf\" value=\"".$sf."\" />\n";
  echo "  <table border=\"1\" bgcolor=ffffff cellpadding=\"1\" cellspacing=\"0\" summary=\"".$tb."\">\n";

/* Table Headings are determined by the calling program */

  echo "    <tr>\n";
	if ($select_recs)
  { echo "      <th>&nbsp;</th>\n"; }
  for ($k=0 ; $k<$num_fds; $k++)
  {
    $fd = $fds[$k];
    $fdn = $fdd[$fd]["name"];
    if (isset($fdd[$fd]["width"])) { 
      $w = " width=\"".$fdd[$fd]["width"]."\"";
    } else {
      $w = "";
    }
    if ($fdd[$fd]["sort"]) {
      echo "      <th".$w."><a href=\"".basename($PHP_SELF)."?fm=0&sf=".$fd."\">".$fdn."</a></th>\n";
    } else {
      echo "      <th".$w.">".$fdn."</th>\n";
    }
  }
  echo "    </tr>\n";
/* Prepare the SQL Query from the data definition file*/
  for ($k=0 ; $k<$num_fds; $k++)
  {
    if ($k==0) { $qry = "SELECT DISTINCT ".$fds[$k]; } 
          else { $qry = $qry.",".$fds[$k]; }
  }
/* Even if the key field isn't displayed, we still need its value */
  if ($select_recs)
  { if (!in_array($key,$fds)) { $qry = $qry.",".$key; }; }
  $qry = $qry." FROM ".$tb;
  if (isset($sf)) { $qry = $qry." ORDER BY ".$sf; }
  $to = $fm + $inc;
  $qry = $qry." LIMIT ".$fm.",".$inc;
/* Each row of the HTML table is one record from the SQL Query */
  $res = mysql_db_query($db1,$qry);
  $first = true;
  $eot = $inc;
  while($row = mysql_fetch_array($res)) 
  {
    echo "    <tr>\n";
    if ($select_recs)
		{
      if ($first)
      {
        echo "      <td><input checked type=\"radio\" name=\"rec\" value=\"".$row[$key]."\" /></td>\n";
        $first = false;
      } else {
        echo "      <td><input type=\"radio\" name=\"rec\" value=\"".$row[$key]."\" /></td>\n";
      }
		}
    for ($k=0 ; $k<$num_fds; $k++) 
    {
      if (($row[$k]=="") or ($row[$k]=="NULL")) { 
			  echo "      <td>&nbsp;</td>\n"; 
			} else {
			  $row[$k]=htmlentities($row[$k]);
/*      Make clickable items clickable */
        if (!isset($fdd[$fds[$k]]["URL"])) {
          echo "      <td>".$row[$k]."</td>\n";
        } else {
          echo "      <td><a href=\"".$fdd[$fds[$k]]["URL"].$row[$k]."\">".$row[$k]."</a></td>\n"; 
			  } 
			}
    }
    echo "    </tr>\n";
    --$eot;
  }
  echo "  </table>\n";      
/* note that <input disabled isn't valid HTML but most browsers support it */
  echo "  <hr />\n  <table summary=\"nav buttons\"><tr>\n";
  if ($fm > 0)
  { echo "    <td><input type=\"submit\" name=\"prev\" value=\"Prev\" /></td>\n"; 
  } else 
  { echo "    <td><input disabled type=\"submit\" name=\"dprev\" value=\"Prev\" /></td>\n"; }
  if (stristr($options,"A"))
  { echo "    <td><input type=\"submit\" name=\"add\" value=\"Add\" /></td>\n"; }
  if ($first)
  {
    if (stristr($options,"C"))
    { echo "    <td><input disabled type=\"submit\" name=\"dchange\" value=\"Change\" /></td>\n"; }
    if (stristr($options,"D"))
    { echo "    <td><input disabled type=\"submit\" name=\"ddelete\" value=\"Delete\" /></td>\n"; }
  } else {
    if (stristr($options,"C"))
    { echo "    <td><input type=\"submit\" name=\"change\" value=\"Change\" /></td>\n"; }
    if (stristr($options,"D"))
    { echo "    <td><input type=\"submit\" name=\"delete\" value=\"Delete\" /></td>\n"; }
  }  
  if ($eot == 0)
  { 
    echo "    <td><input type=\"submit\" name=\"next\" value=\"Next\" /></td>\n"; 
  } else {
    echo "    <td><input disabled type=\"submit\" name=\"dnext\" value=\"Next\" /></td>\n"; 
  }
  echo "  </tr></table>\n";
  echo "</form>\n";
}
?>
