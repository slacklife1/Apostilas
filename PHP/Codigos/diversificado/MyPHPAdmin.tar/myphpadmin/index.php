
<HTML>
<TITLE>MyPHPAdmin - By Tim Geiges</TITLE>
<BODY BGCOLOR="#ccccff" vlink=000000 link=000000>


<?php
include("db.php");
//######################################################################
//				MENU
//######################################################################
echo "<center>";
echo "<table width=80% bgcolor=000000><tr><td>";
echo "<table width=100% cellpadding=0 cellspacing=0><tr><td bgcolor=dddddd> &nbsp </td>";
echo "<td bgcolor=dddddd><center><h1>MyPHPAdmin</h1></center></td></tr>";
echo "<tr><td bgcolor=e1e1e1 valign=top width=15%>";
echo "<table width=100%>";
echo "<tr><td bgcolor=e1e1e1><a href=index.php?login=1><img src=images/home.jpg></a></td></tr>";
echo "<tr><td bgcolor=e1e1e1><a href=index.php?login=1&myadmin=db><img src=images/db.jpg></a></td></tr>";
echo "<tr><td bgcolor=e1e1e1><a href=index.php?login=1&myadmin=table><img src=images/table.jpg></a></td></tr>";
echo "<tr><td bgcolor=e1e1e1><a href=index.php?login=1&myadmin=backup><img src=images/backup.jpg></a></td></tr>";
echo "</td></tr></table>";
echo "<table cellspacing=3><tr><td bgcolor=000000><table cellpadding=0 cellspacing=1>";
echo "<tr><td bgcolor=e1e1e1><form><input type=image border=0 src=images/logoff.jpg name=close onclick=\"top.close();\"></td></tr>";
echo "</form>";
echo "</table></td></tr></table>";
echo "<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
echo "<a href=http://www.php.net><img src=images/pbphp.gif border=0></a>";
echo "</td>";
echo "<td width=85% bgcolor=cccccc rowspan=7>";
echo "<table width=100%><tr><td bgcolor=ffffff>";
//#####################################################################
if ($myadmin == ""){
echo "<Center><b><h2>Welcome to MyPHPAdmin</h2>";
echo "<h3>PHP/MySQL administration by: <a href=mailto:tim@lvcm.com>Tim Geiges</a><br>";
echo "<h3><a href=http://wmf.dyndns.org>http://wmf.dyndns.org</a></h3>";
echo "</b></h3></center>";
echo "<center><a href=http://wmf.dyndns.org/><img src=images/wmflogo.jpg border=0></a></center>";
}














//#####################################################################
//					DATABASE				
//######################################################################
if ($myadmin == "db") {
echo "<center><h3>Database Admin</h3></center>";
echo "<table><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<a href=index.php?myadmin=db&admin=view><img src=images/view.jpg border=0></A>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "<table><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<a href=index.php?myadmin=db&admin=create><img src=images/createdb.jpg border=0></A>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "<table><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<a href=index.php?myadmin=db&admin=dropdb><img src=images/deldb.jpg border=0></A>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "<table><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<a href=index.php?myadmin=editdb><img src=images/edit.jpg border=0></A>";
echo "</td></tr></table>";
echo "</td></tr></table>";
//#####################################################################
if ($admin == "") {
echo "<center><img src=images/wmflogo.jpg></center>";
}
//#####################################################################
if ($admin == "view") {
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<center><b><br>Choose a database to VIEW!!!<br><br></center>";
echo "</td></tr></table>";
echo "</td></tr></table>";
dbview(tableview, db);
}
//#####################################################################
if ($admin == "tableview") {
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<center><b><br>Choose a table to VIEW!!!<br><br></center>";
echo "</td></tr></table>";
echo "</td></tr></table>";
tableview(viewtablecontents, $dbuse, db);
}
//#####################################################################
if ($admin == "viewtablecontents") {
echo "<br><CENTER>";
mysql_connect ($dbhost, $username, $password);
mysql_select_db ($dbuse);
$result = mysql_query ("SELECT * FROM $tableuse;");
echo "<center><table bgcolor=bbbbbb>";
echo "<tr><td>";
echo "        <table><!---- Inside Table ---->";
         while($value = mysql_fetch_array($result))
        {
                print "<tr BGCOLOR=e1e1e1>";
               for($i=0; $i< mysql_num_fields($result); $i++ )
                {
                    print "<td> $value[$i] </td>";
                }
        print "</tr>";

        }
        mysql_free_result($result);
        mysql_close();

echo "       </table><!---- Inside Table ----->";
echo " </td></tr>";
echo " </table></Center>";
echo "</CENTER>";
}



//#########################################################################################

if ($admin == "create") {
echo "<form action=index.php?myadmin=db&admin=createdb method=post>";
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<b><center><br>Type a name for the new Database.</b><br><input type=text name=dbname size=40><br>";
echo "<input type=submit name=Createdb value=Create></form></center>";
echo "</td></tr></table>";
echo "</td></tr></table></center>";
}

//#########################################################################################

if ($admin == "createdb") {
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
mysql_connect ($dbhost, $username, $password);
mysql_query ("CREATE DATABASE $dbname");
echo "<br>Your Databases called $dbname has been created, would you like to set up some tables?<br><br>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "<table width=10%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<a href=index.php?myadmin=table&dbuse=$dbname&admin=maketableform>YES</a>";
echo "<br><a href=index.php>NO</a>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "</center>";
}



//#########################################################################################

if ($admin == "dropdb") {
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<b><center><br>Choose a database to DROP!!!!!!</b><br><br>";
echo "</td></tr></table>";
echo "</td></tr></table>";
dbview(dropdbques, db);
}


//#########################################################################################

if ($admin == "dropdbques") {
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<b><center><br>Are you sure you want to delete database $dbuse</b><br><br>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "<table width=10%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<input type=hidden name=dbuse value=$dbuse>";
echo "<a href=index.php?myadmin=db&dbuse=$dbuse&admin=dropdbdoit>YES</a>";
echo "<br><a href=index.php>NO</a>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "</center>";
}

//#########################################################################################
if ($admin == "dropdbdoit") {
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<b><center><br>The Database \"$dbuse\" has been deleted.</b><br><br>";
echo "</td></tr></table>";
echo "</td></tr></table>";
mysql_connect ($dbhost, $username, $password);
mysql_select_db ($dbuse);
mysql_query ("drop database $dbuse");
echo "</center>";
}
//#####################################################################
}
//#####################################################################








//############################################################
// EDIT DATABASE
//############################################################

if ($myadmin == "editdb") {
include ("SETUP.PHP");
}

//############################################################

















//######################################################################
//						TABLE
//######################################################################

if ($myadmin == "table") {
echo "<center><h3>Table Admin</h3></center>";
echo "<table><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<a href=index.php?myadmin=table&admin=describetable><img src=images/describe.jpg border=0></A>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "<table><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<a href=index.php?myadmin=table&admin=maketable><img src=images/create.jpg border=0></A>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "<table><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<a href=index.php?myadmin=table&admin=deletetable><img src=images/deltab.jpg border=0></A>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "<table><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<a href=index.php?myadmin=table&admin=newcol><img src=images/edit.jpg border=0></A>";
echo "</td></tr></table>";
echo "</td></tr></table>";
//#########################################################################################
if ($admin == "") {
echo "<center><img src=images/wmflogo.jpg></center>";
}
//#########################################################################################
if ($admin == "describetable") {
echo "<center>";
echo "<table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<center><b>Choose a database to DESCRIBE a table from</b><br><br>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "</center>";
dbview(describetablelist, table);
}
//#########################################################################################

if ($admin == "describetablelist") {
echo "<center>";
echo "<table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<center><b>Choose a table to DESCRIBE</b><br><br>";
echo "</td></tr></table>";
echo "</td></tr></table>";
tableview(describetabledoit, $dbuse, table);
echo "</center>";
}
//#########################################################################################
if ($admin == "describetabledoit") {
echo "<CENTER>";
mysql_connect ($dbhost, $username, $password);
mysql_select_db ($dbuse);
$result = mysql_query ("describe $tableuse;");
echo "<center><table bgcolor=bbbbbb>";
echo "<tr><td>";
echo "        <table><!---- Inside Table ---->";
         while($value = mysql_fetch_array($result))
        {
                print "<tr BGCOLOR=e1e1e1>";
               for($i=0; $i< mysql_num_fields($result); $i++ )
                {
                    print "<td> $value[$i] </td>";
                }
        print "</tr>";

        }
        mysql_free_result($result);
        mysql_close();

echo "       </table><!---- Inside Table ----->";
echo " </td></tr>";
echo " </table></Center>";
echo "</CENTER>";
}
//#####################################################################
if ($admin == "maketable") {
echo "<center>";
echo "<table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<center><br><b>Choose a database to MAKE a table in.<br><br></center>";
echo "</td></tr></table>";
echo "</td></tr></table>";
dbview (maketableform, table);
echo "</center>";
}
//#####################################################################

if ($admin == "maketableform") {
echo "<center>";
echo "<table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<h3>This is the new table form<br>";
echo "below are the existing tables within the database \"$dbuse\"</h3>";
echo "</td></tr></table>";
echo "</td></tr></table><br>";
mysql_connect ($dbhost, $username, $password);
mysql_select_db ($dbuse);
$result = mysql_query ("SHOW TABLES;");
        while($value = mysql_fetch_array($result))
        {
               //This loop goes through the colums and prints
               //each value
                for($i=0; $i< mysql_num_fields($result); $i++ )
                {
echo "<table width=40%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
print "<a
href=\"index.php?myadmin=db&admin=viewtablecontents&dbuse=$dbuse&tableuse=$value[$i]\">$value[$i]</A><br>";
echo "</td></tr></table>";
echo "</td></tr></table>";
                }
        }
        mysql_free_result($result);
        mysql_close();
echo "<br><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<form action=index.php?myadmin=table&admin=maketabledoit method=post>";
echo "<b>Edit this data to fit your needs.<br>";
echo "<textarea name=createtable cols=80 rows=5>";
echo "create table REPLACEME (name varchar(255), name2 varchar(255));";
echo "</textarea>";
echo "<input type=hidden name=dbuse value=$dbuse>";
echo "<br><input type=submit name=submit>";
echo "</td></tr></table>";
echo "</td></tr></table><br>";
}

//#########################################################################################

if ($admin == "maketabledoit") {
echo "<center>";
echo "Your new table has been created";
mysql_connect ($dbhost, $username, $password);
mysql_query ("CREATE DATABASE $dbname");
echo "� Would you like to create another table?";
echo "<br><br><a href=index.php?dbuse=$dbuse&myadmin=table&admin=maketableform>YES</a>";
echo "<br><a href=index.php>NO</a>";
mysql_connect ($dbhost, $username, $password);
mysql_select_db ($dbuse);
mysql_query ("$createtable");
echo "<br><br><br><br><a href=index.php>HOME</a>";
echo "</center>";
}

//#########################################################################################

if ($admin == "deletetable") {
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<b><center><br>Choose a database to DROP a TABLE from!!!!</b><br><br>";
echo "</td></tr></table>";
echo "</td></tr></table>";
dbview(droptableview, table);
}

//#########################################################################################

if ($admin == "droptableview") {
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<b><center><br>Choose a TABLE to DROP!!!</b><br><br>";
echo "</td></tr></table>";
echo "</td></tr></table>";
tableview(droptableques, $dbuse, table);
}

//#########################################################################################

if ($admin == "droptableques") {
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<b><br><center>Are you sure you want to delete the table $tableuse from the database
$dbuse<br><br>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "<input type=hidden name=dbuse value=$dbuse>";
echo "<input type=hidden name=tableuse value=$tableuse>";
echo "<center><table width=10%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<a
href=index.php?dbuse=$dbuse&myadmin=table&admin=droptabledoit&tableuse=$tableuse>YES</a>";
echo "<br><a href=index.php>NO</a>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "</center>";
}
//#########################################################################################

if ($admin == "droptabledoit") {
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<center><b><br>The Table \"$tableuse\" was dropped.<br><br>";
echo "</td></tr></table>";
echo "</td></tr></table>";
mysql_connect ($dbhost, $username, $password);
mysql_select_db ($dbuse);
mysql_query ("drop table $tableuse");
echo "</center>";
}

//#########################################################################################
//########################## NEW COLUMN CODE   ############################################


if ($admin == "newcol") {
echo "<center>";
echo "<table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<center><br><b>Choose a database to EDIT COLUMNS in.<br><br></center>";
echo "</td></tr></table>";
echo "</td></tr></table>";
dbview (newcoltab, table);
echo "</center>";
}
//######################################################################
if ($admin == "newcoltab") {
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<center><b><br>Choose a table to EDIT COLUMNS in.<br><br></center>";
echo "</td></tr></table>";
echo "</td></tr></table>";
tableview(newcolques, $dbuse, table);
}
//#####################################################################

if ($admin == "newcolques") {
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<b><center><br>Before we continue you will need to backup the Database</b>";
echo "<b><br>Are you sure you want to BACKUP the database $dbuse?</b><br><br>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "<table width=10%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<input type=hidden name=dbuse value=$dbuse>";
echo "<a href=index.php?myadmin=table&dbuse=$dbuse&tableuse=$tableuse&admin=newcoldoit>YES</a>";
echo "<br><a href=index.php>NO</a>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "</center>";
}
//######################################################################

if ($admin == "newcoldoit") {
echo "<center>";
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<b><center>Click an existing coloumn to DELETE <u>OR</u><br>";
echo "Enter a new column name and column type in the fields provided to add a NEW column.";
echo "</td></tr></table>";
echo "</td></tr></table><br>";
$dd = "/usr/bin/mysqldump -u $username --password=$password --add-drop-table $dbuse > tabledump/$dbuse";
exec ($dd, $ddR, $ddRV);

mysql_connect ($dbhost, $username, $password);
mysql_select_db ($dbuse);
$result = mysql_query ("describe $tableuse;");
echo "<center><table bgcolor=bbbbbb>";
echo "<tr><td>CLICK A COLUMN TO DELETE";
echo "        <table width=100%><!---- Inside Table ---->";
         while($value = mysql_fetch_array($result))
        {
                print "<tr BGCOLOR=e1e1e1>";
print "<td><a href=index.php?myadmin=table&tableuse=$tableuse&dbuse=$dbuse&admin=coldelques&col=$value[0]>$value[0]</a></td>";
                print "<td>$value[1]</td>";
                print "<td>$value[2]</td>";
                print "<td>$value[3]</td>";
                print "<td>$value[4]</td>";
                print "<td>$value[5]</td>";

        print "</tr>";

        }

print "<tr></tr></table><br> <table bgcolor=e1bbe1 width=100%><tr><td bgcolor=e1cce1>Fill out the form below for new columns</td>";
echo "</tr><tr><td></td><tr><form name=newcol method=get action=index.php>";
print "<td bgcolor=e1cce1>col name <input type=text name=newcol size=10> &nbsp";

echo "col type <SELECT NAME=type>";
echo "<OPTION VALUE=>";
echo "<OPTION VALUE=varchar>varchar";
echo "<OPTION VALUE=int>int";
echo "<OPTION VALUE=text>text";
echo "<OPTION VALUE=tinyint>tinyint";
echo "<OPTION VALUE=smallint>smallint";
echo "<OPTION VALUE=mediumint>mediumint";
echo "<OPTION VALUE=bigint>bigint";
echo "<OPTION VALUE=float>float";
echo "<OPTION VALUE=double>double";
echo "<OPTION VALUE=decimal>decimal";
echo "<OPTION VALUE=char>char";
echo "<OPTION VALUE=tinyblob>tinyblob";
echo "<OPTION VALUE=blob>blob";
echo "<OPTION VALUE=mediumblob>mediumblob";
echo "<OPTION VALUE=longblob>longblob";
echo "<OPTION VALUE=tinytext>tinytext";
echo "<OPTION VALUE=mediumtext>mediumtext";
echo "<OPTION VALUE=longtext>longtext";
echo "<OPTION VALUE=enum>enum";
echo "<OPTION VALUE=set>set";
echo "<OPTION VALUE=date>date";
echo "<OPTION VALUE=time>time";
echo "<OPTION VALUE=datetime>datetime";
echo "<OPTION VALUE=timestamp>timestamp";
echo "<OPTION VALUE=year>year";
echo "</SELECT> &nbsp";

print "col size <input type=text name=size size=10></td>";
echo "<input type=hidden name=tableuse value=$tableuse>";
echo "<input type=hidden name=dbuse value=$dbuse>";
echo "<input type=hidden name=admin value=newcolnext>";
echo "<input type=hidden name=myadmin value=table>";
echo "</tr><tr><td><input type=submit></form>";
        mysql_free_result($result);
        mysql_close();

echo "       </tr></table><!---- Inside Table ----->";
echo " </td></tr>";
echo " </table></Center>";
echo "</center>";
}
//#####################################################################

if ($admin == "newcolnext" && $newcol != "" && $type != "") {
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<center><b><br>Are you sure you would like to continue?</b><br><br></center>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "<table width=10%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<form name=newcolnext method=get action=index.php>";
echo "<br><center><input type=hidden name=tableuse value=$tableuse>";
echo "<input type=hidden name=dbuse value=$dbuse>";
echo "<input type=hidden name=newcol value=$newcol>";
echo "<input type=hidden name=addl value=\"$addl\">";
echo "<input type=hidden name=type value=$type>";
echo "<input type=hidden name=size value=$size>";
echo "<input type=hidden name=admin value=newcolnextdoit>";
echo "<input type=hidden name=myadmin value=table>";
echo "<input type=submit name=yes value=Yes></form></center>";
echo "<form name=newcolnextno method=get action=index.php>";
echo "<center><input type=hidden name=myadmin value=table>";
echo "<input type=submit name=no value=\"&nbsp no &nbsp\"></form></center>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "</center>";
}

if ($admin == "newcolnext" && $newcol == "") {
echo "<center>";
echo "<table width=80%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<h2>You need to type a name in the colname field</h2><br>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "</center>";
}

if ($admin == "newcolnext" && $type == "") {
echo "<center>";
echo "<table width=80%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<h2>You need to type a name in the coltype field</h2>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "</center>";
}
//#####################################################################

if ($admin == "newcolnextdoit") {
mysql_connect ($dbhost, $username, $password);
mysql_select_db ($dbuse);
if ($size == "") {
mysql_query ("ALTER TABLE $tableuse add $newcol $type;");
} else {
mysql_query ("ALTER TABLE $tableuse add $newcol $type($size);");
}
echo "<CENTER>";
mysql_connect ($dbhost, $username, $password);
mysql_select_db ($dbuse);
$result = mysql_query ("describe $tableuse;");
echo "<center><table>";

$valof = $result;
if ($valof != "") {
echo "<tr><td>";
$dd = "/bin/rm -f -r  tabledump/$dbuse";
exec ($dd, $ddR, $ddRV);
}
if ($valof == "") {
echo "<tr><td bgcolor=e1e1e1>There was a problem with your new col<br>";
echo "Your database will now be restored...";
echo "<br><br>$newcol &nbsp $type($size)<br>$addl, $param";
mysql_connect ($dbhost, $username, $password);
mysql_drop_db ($dbuse);
mysql_create_db ($dbuse);
$dd = "/usr/bin/mysql -u $username --password=$password $dbuse < tabledump/$dbuse";
exec ($dd, $ddR, $ddRV);
$dd = "/bin/rm -f -r  tabledump/$dbuse";
exec ($dd, $ddR, $ddRV);
}


echo "<center>";
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<b><center>Click an existing coloumn to DELETE <u>OR</u><br>";
echo "Enter a new column name and column type in the fields provided to add a NEW column.";
echo "</td></tr></table>";
echo "</td></tr></table><br>";
$dd = "/usr/bin/mysqldump -u $username --password=$password --add-drop-table $dbuse > tabledump/$dbuse";
exec ($dd, $ddR, $ddRV);

mysql_connect ($dbhost, $username, $password);
mysql_select_db ($dbuse);
$result = mysql_query ("describe $tableuse;");
echo "<center><table bgcolor=bbbbbb>";
echo "<tr><td>CLICK A COLUMN TO DELETE";
echo "        <table width=100%><!---- Inside Table ---->";
         while($value = mysql_fetch_array($result))
        {
                print "<tr BGCOLOR=e1e1e1>";
print "<td><a href=index.php?myadmin=table&tableuse=$tableuse&dbuse=$dbuse&admin=coldelques&col=$value[0]>$value[0]</a></td>";
                print "<td>$value[1]</td>";
                print "<td>$value[2]</td>";
                print "<td>$value[3]</td>";
                print "<td>$value[4]</td>";
                print "<td>$value[5]</td>";

        print "</tr>";

}
print "<tr></tr></table><br> <table bgcolor=e1bbe1 width=100%><tr><td bgcolor=e1cce1>Fill out the form below for
new columns</td>";
echo "</tr><tr><td></td><tr><form name=newcol method=get action=index.php>";
print "<td bgcolor=e1cce1>col name <input type=text name=newcol size=10> &nbsp";

echo "col type <SELECT NAME=type>";
echo "<OPTION VALUE=>";
echo "<OPTION VALUE=varchar>varchar";
echo "<OPTION VALUE=int>int";
echo "<OPTION VALUE=text>text";
echo "<OPTION VALUE=tinyint>tinyint";
echo "<OPTION VALUE=smallint>smallint";
echo "<OPTION VALUE=mediumint>mediumint";
echo "<OPTION VALUE=bigint>bigint";
echo "<OPTION VALUE=float>float";
echo "<OPTION VALUE=double>double";
echo "<OPTION VALUE=decimal>decimal";
echo "<OPTION VALUE=char>char";
echo "<OPTION VALUE=tinyblob>tinyblob";
echo "<OPTION VALUE=blob>blob";
echo "<OPTION VALUE=mediumblob>mediumblob";
echo "<OPTION VALUE=longblob>longblob";
echo "<OPTION VALUE=tinytext>tinytext";
echo "<OPTION VALUE=mediumtext>mediumtext";
echo "<OPTION VALUE=longtext>longtext";
echo "<OPTION VALUE=enum>enum";
echo "<OPTION VALUE=set>set";
echo "<OPTION VALUE=date>date";
echo "<OPTION VALUE=time>time";
echo "<OPTION VALUE=datetime>datetime";
echo "<OPTION VALUE=timestamp>timestamp";
echo "<OPTION VALUE=year>year";
echo "</SELECT> &nbsp";

print "col size <input type=text name=size size=10></td>";
echo "<input type=hidden name=tableuse value=$tableuse>";
echo "<input type=hidden name=dbuse value=$dbuse>";
echo "<input type=hidden name=admin value=newcolnext>";
echo "<input type=hidden name=myadmin value=table>";
echo "</tr><tr><td><input type=submit></form>";
        mysql_free_result($result);
        mysql_close();

echo "       </tr></table><!---- Inside Table ----->";
echo " </td></tr>";
echo " </table></Center>";
echo "</center>";


}

//#####################################################################
if ($admin == "coldelques") {
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<center><b><br>Are you sure you would like to delete column \"$col\"?</b><br><br></center>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "<table width=10%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<br><center>";
echo "<form name=coldeldoit method=get action=index.php>";
echo "<input type=hidden name=tableuse value=$tableuse>";
echo "<input type=hidden name=dbuse value=$dbuse>";
echo "<input type=hidden name=admin value=coldeldoit>";
echo "<input type=hidden name=coldel value=$col>";
echo "<input type=hidden name=myadmin value=table>";
echo "<input type=submit name=yes value=Yes></form></center>";
echo "<form name=newcolnextno method=get action=index.php>";
echo "<center><input type=hidden name=myadmin value=table>";
echo "<input type=submit name=no value=\"&nbsp no &nbsp\"></form></center>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "</center>";
}


//#####################################################################
if ($admin == "coldeldoit") {
mysql_connect ($dbhost, $username, $password);
mysql_select_db ($dbuse);
mysql_query ("ALTER TABLE $tableuse drop $coldel;");
echo "<center>";
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<b><center>Click an existing coloumn to DELETE <u>OR</u><br>";
echo "Enter a new column name and column type in the fields provided to add a NEW column.";
echo "</td></tr></table>";
echo "</td></tr></table><br>";
$dd = "/usr/bin/mysqldump -u $username --password=$password --add-drop-table $dbuse > tabledump/$dbuse";
exec ($dd, $ddR, $ddRV);

mysql_connect ($dbhost, $username, $password);
mysql_select_db ($dbuse);
$result = mysql_query ("describe $tableuse;");
echo "<center><table bgcolor=bbbbbb>";
echo "<tr><td>CLICK A COLUMN TO DELETE";
echo "        <table width=100%><!---- Inside Table ---->";
         while($value = mysql_fetch_array($result))
        {
                print "<tr BGCOLOR=e1e1e1>";
print "<td><a href=index.php?myadmin=table&tableuse=$tableuse&dbuse=$dbuse&admin=coldelques&col=$value[0]>$value[0]</a></td>";
                print "<td>$value[1]</td>";
                print "<td>$value[2]</td>";
                print "<td>$value[3]</td>";
                print "<td>$value[4]</td>";
                print "<td>$value[5]</td>";

        print "</tr>";

}
print "<tr></tr></table><br> <table bgcolor=e1bbe1 width=100%><tr><td bgcolor=e1cce1>Fill out the form below for
new columns</td>";
echo "</tr><tr><td></td><tr><form name=newcol method=get action=index.php>";
print "<td bgcolor=e1cce1>col name <input type=text name=newcol size=10> &nbsp";

echo "col type <SELECT NAME=type>";
echo "<OPTION VALUE=>";
echo "<OPTION VALUE=varchar>varchar";
echo "<OPTION VALUE=int>int";
echo "<OPTION VALUE=text>text";
echo "<OPTION VALUE=tinyint>tinyint";
echo "<OPTION VALUE=smallint>smallint";
echo "<OPTION VALUE=mediumint>mediumint";
echo "<OPTION VALUE=bigint>bigint";
echo "<OPTION VALUE=float>float";
echo "<OPTION VALUE=double>double";
echo "<OPTION VALUE=decimal>decimal";
echo "<OPTION VALUE=char>char";
echo "<OPTION VALUE=tinyblob>tinyblob";
echo "<OPTION VALUE=blob>blob";
echo "<OPTION VALUE=mediumblob>mediumblob";
echo "<OPTION VALUE=longblob>longblob";
echo "<OPTION VALUE=tinytext>tinytext";
echo "<OPTION VALUE=mediumtext>mediumtext";
echo "<OPTION VALUE=longtext>longtext";
echo "<OPTION VALUE=enum>enum";
echo "<OPTION VALUE=set>set";
echo "<OPTION VALUE=date>date";
echo "<OPTION VALUE=time>time";
echo "<OPTION VALUE=datetime>datetime";
echo "<OPTION VALUE=timestamp>timestamp";
echo "<OPTION VALUE=year>year";
echo "</SELECT> &nbsp";

print "col size <input type=text name=size size=10></td>";
echo "<input type=hidden name=tableuse value=$tableuse>";
echo "<input type=hidden name=dbuse value=$dbuse>";
echo "<input type=hidden name=admin value=newcolnext>";
echo "<input type=hidden name=myadmin value=table>";
echo "</tr><tr><td><input type=submit></form>";
        mysql_free_result($result);
        mysql_close();

echo "       </tr></table><!---- Inside Table ----->";
echo " </td></tr>";
echo " </table></Center>";
echo "</center>";
}
//#####################################################################
}
//#####################################################################














//######################################################################
//						BACKUP/RESTORE					
//######################################################################


if ($myadmin == "backup") {
echo "<center><h3>Backup/Restore Admin</h3></center>";
echo "<table><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<a href=index.php?myadmin=backup&admin=backup><img src=images/backup.jpg border=0></A>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "<table><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<a href=index.php?myadmin=backup&admin=restore><img src=images/restore.jpg border=0></A>";
echo "</td></tr></table>";
echo "</td></tr></table>";

//######################################################################
if ($admin == "") {
echo "<center><img src=images/wmflogo.jpg></center>";
}

//######################################################################


if ($admin == "backup") {
echo "<center>";
echo "<table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<center><br><b>Choose a database to BACKUP!!!!<br><br></center>";
echo "</td></tr></table>";
echo "</td></tr></table>";
dbview (backupdbques, backup);
echo "</center>";
}
//######################################################################

if ($admin == "backupdbques") {
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<b><center><br>Are you sure you want to BACKUP the database $dbuse?</b><br><br>"; 
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "<table width=10%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<input type=hidden name=dbuse value=$dbuse>";
echo "<a href=index.php?myadmin=backup&dbuse=$dbuse&admin=backupdbdoit>YES</a>";
echo "<br><a href=index.php>NO</a>";
echo "</td></tr></table>";
echo "</td></tr></table>";
echo "</center>";
}
//######################################################################

if ($admin == "backupdbdoit") {
echo "<center>";
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<b><center><br>\"$dbuse\" has been backed up.</b><br><br>";
echo "</td></tr></table>";
echo "</td></tr></table>";
$dd = "/usr/bin/mysqldump -u $username --password=$password --add-drop-table $dbuse > dumps/$dbuse";
exec ($dd, $ddR, $ddRV);
echo "</center>";
}

//######################################################################
if ($admin == "restore") {
echo "<center>";
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<b><center><br>Choose a database to RESTORE!!!<br>This will delete
and restore the database<br><br>";
echo "</td></tr></table>";
echo "</td></tr></table><br>";
  $dd = "/bin/ls dumps";
  exec ($dd, $ddR, $ddRV);
  reset ($ddR);
  while (list($key,$val) = each($ddR))
  {
echo "<center><table width=40%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
    print "<a href=index.php?myadmin=backup&admin=restoredbques&restore=$val><b>$val</a><BR>";
echo "</td></tr></table>";
echo "</td></tr></table>";
  }
echo "</center>";
}

//#########################################################################################

if ($admin == "restoredbques") {
echo "<center>";
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<center><b><br>Are you sure you want to RESTORE the database
$dbuse<br><br>";
echo "</td></tr></table>";
echo "</td></tr></table><br>";
echo "<input type=hidden name=restore value=$restore>";
echo "<br><br><a href=index.php?restore=$restore&myadmin=backup&admin=restoredbdoit>YES</a>";
echo "<br><a href=index.php>NO</a>";
echo "</center>";
}
//#########################################################################################

if ($admin == "restoredbdoit") {
echo "<center>";
echo "<center><table width=60%><tr><td bgcolor=000000>";
echo "<table width=100%><tr><td bgcolor=e1e1e1>";
echo "<b><center><br>The database \"$restore\" has been restored.<br><br>";
echo "</td></tr></table>";
echo "</td></tr></table><br>";
mysql_connect ($dbhost, $username, $password);
mysql_drop_db ($restore);
mysql_create_db ($restore);
$dd = "/usr/bin/mysql -u $username --password=$password $restore < dumps/$restore";
exec ($dd, $ddR, $ddRV);
echo "</center>";
}


//######################################################################
}
//###################################################################












echo "<BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR>";
echo "</td></tr></table>";
echo "</td></tr></table>";
//#####################################################################
?>
</td></tr></table>
</body>
</html>

