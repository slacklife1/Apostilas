<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN">
<html>
<head>
  <title>phpMyNewsletter</title>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
 </head>
<body>



<h1>phpMyNewsletter v 0.6.10</h1>
Choose your language :<BR> <FORM ACTION="customize.php" METHOD="POST"><CENTER>
<SELECT NAME="l" TABINDEX=2>
    <OPTION VALUE="lang-french.php">Fran�ais</OPTION>
    <OPTION VALUE="lang-en.php">English</OPTION>
    <OPTION VALUE="lang-deutch.php">Deutch</OPTION>
    <OPTION VALUE="lang-it.php">Italiano</OPTION>
    <OPTION VALUE="lang-spanish.php">Spanish</OPTION>
    <OPTION VALUE="lang-slovak.php">Slovack</OPTION>
    <OPTION VALUE="lang-dutch.php">Dutch</OPTION>
    <OPTION VALUE="lang-ptbr.php" selected>Brazilian Portuguese</OPTION>
  </SELECT>
 <INPUT TYPE="submit" VALUE="ok">
</FORM></CENTER>



</body></html>