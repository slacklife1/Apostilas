	


	</td>
  </tr>
</table>

<p>&nbsp;</p>
<HR width="60%" size=0>
<center><a href=http://gregory.kokanosky.free.fr/phpmynewsletter/><img src=img/logo.png border=0></A><br>
</center>
</body>

</html> 