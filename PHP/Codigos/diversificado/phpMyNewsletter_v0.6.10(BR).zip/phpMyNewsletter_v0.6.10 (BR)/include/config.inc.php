<? 
$f_host="database.hostnet.com.br";
$f_user="portalpantanal";
$f_passwd="j7q6s4n7";
$f_db="portalpantanal";
$f_tableconfig="pmnl_config";
 ?>