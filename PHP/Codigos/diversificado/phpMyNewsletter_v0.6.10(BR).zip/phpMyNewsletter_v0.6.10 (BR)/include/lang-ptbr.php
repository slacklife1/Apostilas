<?



function translate($phrase) {
 global $lang;
 if($lang[$phrase]!="") return $lang[$phrase];
else return ("[** N�o dispomos desta frase: ] -> $phrase");
}

/************************************************************************************/
/********* Translation by: Edson Luiz Bassani - diretoria@portalpantanal.com ********/
/************************************************************************************/


/********* New translation style *******/

$lang=array("Adresse e-mail"=>"Endere�o de E-mail",	
	    "Inscription"=>"Inscri��o",
	    "D�sinscription"=>"Cancelar Inscri��o",
	    "Nombre d'abonn�s"=>"N�mero de inscritos",
	    "Erreur ! Le mot de passe n'est pas valide"=>"Senha Incorreta",
	    "En attente de validation"=>"Tempo de Valida��o",
	    "Nbr de NewsLetter d�j� envoy�es"=>"Not�cias Enviadas",
	    "Num�ro de la prochaine NewsLetter"=>"N�mero da pr�xima not�cia",
	    "Retour"=> "Voltar",
	    "Erreur"=>"Erro",
	    "D�j� inscrit"=>"Seu e-mail j� consta em nossa base de dados",
	    "Impossible de trouver la base"=>"Seu e-mail n�o consta em nossa base de dados",
	    "Impossible de trouver le serveur"=>"Erro de conex�o com o servidor",
	    "Erreur lors du flush de la table temp"=>"Erro ao recuperar a tabela temp",
	    "Appercu du message"=>"Mensagem Anterior",
	    "R�initialiser"=>"Reiniciar",
	    "Sujet"=>"Assunto:",
	    "R�diger un nouveau message"=>"Criar uma nova mensagem",
	    "Tous les champs doivent �tre remplis"=>"Voc� precisa preencher todos os campos",
	    "Texte"=>"Texto",
	    "Adresse Email non valide"=>"Endere�o de E-Mail Inv�lido. Tente novamente.",
	    "Administration"=>"�rea de Administra��o",
	     "Nouveau message"=>"Nova Mensagem",
	    "Liste des abonn�s"=>"Lista de Inscritos",
	    "Ajout d'un abonn�"=>"Inserir uma Inscri��o",
	    "Suppression d'un abonn�"=>"Eliminar uma Inscri��o",
	    "Voir l'historique"=>"Ver Controle de A��es",
	    "Pour vous d�sinscrire, rendez-vous � l'adresse suivante" =>"para cancelar a inscri��o copie em seu navegador a seguinte URL: ",
	    "Configuration"=>"Configura��o",
	    "Se d�connecter"=>"Sair",
	    "Configuration de phpMyNewsletter"=>"Configura��o da Lista de E-Mails",
	    "Editer la configuration"=>"Editar Configura��o",
	    "Editer les messages de bienvenue ..."=>"Editar a Mensagem de Boas-Vindas ...",
	    "Mise � jour de la configuration effectu�e"=>"Configura��o Atualizada",
	    "Supprimer des abonn�s"=>"Eliminar Inscritos",
	    "S�lectionner les abonn�s � supprimer"=>"Seleccione os E-Mails que deseja apagar de sua lista de correio",
	    "Supprimer les abonn�s s�lectionn�s"=>"Apagar E-Mails selecionados",
	    "Les abonn�s s�lectionn�s ont �t� supprim�"=>"Registros Apagados",
	    "Importer un fichier texte dans la base de donn�e"=>"Importar um Arquivo de Texto para o Banco de Dados",
	    "Importation effectu�e"=>"Importa��o efetuada com �xito",
	    "Logs de phpMyNewsletter"=>"Log do phpMyNewsletter",
	    "Heure"=>"Hora",
	    "Sujet du message de bienvenue"=>"T�tulo da Mensagem de Boas-Vindas",
	    "Message de bienvenue envoy� apr�s la confirmation de l'abonn�"=>"Mensagem de Boas-Vindas enviada ap�s a confirma��o",
	    "Corps du message de bienvenue"=>"Corpo da Mensagem de Boas-Vindas",
	    "Pied des messages"=>"Rodap� da Mensagem",
	    
	    "Mettre � jour"=>"Atualizar",
	    "R�initialiser"=>"Reiniciar",
	    "Message de demande de confirmation"=>"Mensagem de Confirma��o",
	    "Inscription"=>"Inscri��o",
	    
	    "Avertir de l'inscription par mail"=>"Informar o Suscriptor por E-Mail",
	    "Un mail de d'information va �tre envoy�"=>"Foi enviada uma mensagem informando que seu E-Mail foi incluido na Lista de E-Mails",
	    "Nombre total d'abonn�s"=>"N�mero total de inscritos",
	    "Vous n'avez pas d'abonn�s"=>"N�mero de inscritos na base de dados",
	    
	    
	    "Mot de passe"=>"Senha",
	    "valider"=>"Acesso",
	    "Identification"=>"Identifica��o",
	    "Acc�s � l'administration"=>"Acesso ao Painel de Administra��o",
	    
	    "Rendez-vous � l'adresse suivante pour confirmer votre inscription"=>"para confirmar sua inscri��o digite em seu navegador a seguinte URL: ",
	    "Si vous n'avez pas demand� d'inscription � cette newsletter, ignorez simplement ce message"=>"Se voc� n�o pediu para ser inclu�do nesta NewsLetter, por favor ignore e apague esta mensagem.",
	    "Confirmation de l'inscription"=>"Confirma��o da Inscri��o",
	    
	    
	    "Votre inscription c'est bien d�roul�e"=>"Inscri��o Correta",
	    "L'inscription s'est bien d�roul�e"=>"Inscri��o Correta",
	    "Vous allez recevoir un mail de confirmation"=>"Acabamos de enviar a seu E-Mail uma mensagem para confirmar sua inscri��o.",
	    "Vous �tes d�j� inscrit"=>"Endere�o de E-Mail j� incluso em nosso cadastro.",
	    "Vous n'�tes pas inscrit � cette Newsletter"=>"Seus dados ainda n�o se encontram em nossos registros",
	    "Votre inscription a �t� confirm�e"=>"Inscri��o confirmada",
	    "D�sinscription de" =>"Desinscri��o de:",
	    "effectu�e, merci de votre visite" =>"A��o realizada com sucesso. Muito obrigado por sua visita!",
	    "Si vous d�sirez vous r�inscrire, rendez vous � l'adresse suivante" =>"Para voltar a inscrever-se, clique aqui" ,
	    
	    
	    "Nom de la lettre d'information"=>"T�tulo da Newsletter",
	    "H�bergeur" =>"Provedor",
	    "autre" =>"Nenhuma das anteriores",
	    "Adresse de provenance des messages envoy�s" =>"Campo DE no E-Mail da Newsletter",
	    "Nombre de jours accord� pour la validation de l'abonnement"=>"Dias de Espera para a Valida��o",
	    "jours"=>"dias",
	    "Base de donn�es"=>"DataBase",
	    "Serveur mysql"=>"MySQL Server",
	    "Nom d'utilisateur"=>"Usu�rio",
	    "Mot de passe"=>"Senha",
	    "Nom de la base de donn�e"=>"Nome do Banco de Dados",
	    "Nom de la table de stockage des adresses"=>"Nome da Tabela de E-Mails",
	    "Nom de la table d'attente de validation"=>"Nome da Tabela de Valida��es",
	    "Nom de la table de logs"=>"Nome para Tabela de Logs",
	    "Nom de la table de config"=>"Nome para a Tabela de Configura��o",
	    "Mot de passe d'acc�s au panneau d'administration"=>"Senha para Acesso ao Painel de Administra��o",
	    "Nombre de newsletter � afficher par page de logs"=>"N�mero de accesos por p�gina",
	    "Adresse de votre page ex : http://www.myweb.com/ avec un / � la fin" =>"Pagina web: exemplo: http://www.myweb.com/ (inclua o �ltimo / )", 
	    "Emplacement du r�pertoire de phpMyNewsletter ex : tools/newsletter/ avec un / � la fin"=>"Diret�rio em que se encontra o phpMyNewsletter, exemplo: tools/newsletter/ (inclua o �ltimo / )",
	    "Langue"=>"Idioma",  
	    "Activer le processus de validation des inscriptions"=>"Ativar o processo de valida��o das Inscri��es",
	    "OUI"=>"SIM",
	    "NON"=>"N�O",
	    "Export" => "Exportar",
	    "Message envoy�"=>"Mensagem(ns) Enviada(s) com Sucesso!",
	    "Collez les lignes suivantes dans le fichier include/config.inc.php" => "Copie e Cole a informa��o abaixo no arquivo: include/config.inc.php. Se ele n�o existir, crie um.",
	    "Lettre d'information N�"=>"SLKE - Noticias & News No.");
	  
/************************************************************************************/
/********* Translation by: Edson Luiz Bassani - diretoria@portalpantanal.com ********/
/************************************************************************************/
?>
