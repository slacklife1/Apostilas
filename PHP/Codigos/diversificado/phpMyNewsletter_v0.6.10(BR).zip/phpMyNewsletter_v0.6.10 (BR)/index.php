<?
echo "<h1><center>Bienvenue</center></h1>";

include("form.php");


?>

