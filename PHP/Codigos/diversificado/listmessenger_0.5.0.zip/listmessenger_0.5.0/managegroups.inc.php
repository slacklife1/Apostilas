<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

	if ($addgroup) {
		if ($parent_group_id) {
			if(($add_status = add_group($group_name, $parent_group_id)) == 1) {
				header("location: index.php?section=managegroups");
			}
		} else {
			if(($add_status = add_group($group_name)) == 1) {
				header("location: index.php?section=managegroups");
			}
		}
	}

	// Do a Group Count.
	$group_id_count = get_total_rows("user_groups");

	echo "<table width=\"720\" height=\"532\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\">\n";
	echo "<tr>\n";
	echo "	<td width=\"125\" valign=\"top\">\n";
	echo "		<img src=\"images/pixel.gif\" width=\"125\" height=\"15\" alt=\"\">\n";
	echo "	</td>\n";
	echo "	<td width=\"595\" valign=\"top\">\n";
	echo "		<img src=\"images/pixel.gif\" width=\"595\" height=\"15\" alt=\"\">\n";
				if ($deletegroup)  {
					// ----------- End of Delete Group Pre Assign ----------- //
					$query = "SELECT * FROM user_groups WHERE group_id='$group_id'";
					$result = mysql_db_query(DATABASE_NAME, $query, $cid);
					if (($result) && ($row=mysql_fetch_array($result))) {
						$group_name	= $row["group_name"];
						$group_type	= $row["group_type"];
						$belongs_to	= $row["belongs_to"];
					}
					echo "<b>Delete A Group</b>";
					if (($num_sub_groups > 0) || ($num_users > 0)) {
						echo "<form name=\"form1\" action=\"index.php?section=delete&type=group\" method=\"post\">";
						echo "<table width=\"400\" cellspacing=\"1\" cellpadding=\"2\" border=\"0\">";
						echo "<tr>";
						echo "	<td colspan=\"2\">";
						echo "		<table width=\"400\" cellspacing=\"1\" cellpadding=\"2\" border=\"0\">";
									if ($num_users > 0) {
										$query = "SELECT group_id,group_name FROM user_groups WHERE group_id<>'$group_id' AND group_type='0' ORDER BY group_id ASC";
										$result = mysql_db_query(DATABASE_NAME, $query, $cid);
										if (($result) && ($row=mysql_fetch_array($result))) {
											echo "<tr>";
											echo "	<td colspan=\"2\">";
											echo "		You have $num_users member";
														if ($num_users > 1) { echo "s"; }
											echo " 		in the group $group_name.";
											echo "	</td>";
											echo "</tr>";
											echo "<tr>";
											echo "	<td><input type=\"radio\" name=\"delete_users\" value=\"1\" onClick=\"disable1()\" CHECKED></td>";
											echo "	<td> - Delete them.</td>";
											echo "</tr>";
											echo "<tr>";
											echo "	<td><input type=\"radio\" name=\"delete_users\" value=\"0\" onClick=\"enable1()\"></td>";
											echo "	<td> - Move them.</td>";
											echo "</tr>";
											echo "<tr>";
											echo "	<td>&nbsp;</td>";
											echo "	<td>&nbsp;&nbsp;";
														do {
															$group_id_list[$row["group_id"]] = $row["group_name"];
														} while ($row=mysql_fetch_array($result));
														// Displaying Main Group + 2 Next levels of Sub-Groups.					
														echo "<select name=\"group_id_1\" style=\"width: 200px\">\n";
//														echo "<option value=\"\">-- Select Group --</option>\n";
														foreach ($group_id_list as $key => $value) {
															echo "	<option value=\"".$key."\"";
															if ($group_id == $key) { echo " SELECTED"; }
															echo ">/".$value."</option>";
															$query = "SELECT * FROM user_groups WHERE group_id<>'$group_id' AND group_type='1' AND belongs_to=$key ORDER BY group_name ASC";
															$result = mysql_db_query(DATABASE_NAME, $query, $cid);
															if (($result) && ($row=mysql_fetch_array($result))) {
																do {
																	echo "<option value=\"".$row["group_id"]."\"";
																	if ($group_id == $row["group_id"]) { echo " SELECTED"; }
																	echo ">&nbsp;&nbsp;-&gt;&nbsp;".$row["group_name"]."</option>";
																	$subquery = "SELECT * FROM user_groups WHERE group_id<>'$group_id' AND group_type='2' AND belongs_to='".$row["group_id"]."' ORDER BY group_name ASC";
																	$subresult = mysql_db_query(DATABASE_NAME, $subquery, $cid);
																	if (($subresult) && ($row=mysql_fetch_array($subresult))) {
																		do {
																			echo "	<option value=\"".$row["group_id"]."\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|_&nbsp;".$row["group_name"]."</option>";
																		} while ($row=mysql_fetch_array($subresult));
																	}
																} while ($row=mysql_fetch_array($result));
															}
														}
														echo "</select>";
											echo "	</td>";
											echo "</tr>";
										} else {
											echo "<tr>";
											echo "	<td colspan=\"2\">";
											echo "		$num_users member";
														if ($num_users > 1) { echo "s"; }
											echo " 		in the group <b>\"$group_name\"</b> will be deleted because there will be no groups to move to, once the group <b>\"$group_name\"</b> is removed.<br><br>";
											echo "		<input type=\"hidden\" name=\"group_id_1\" value=\"\">";
											echo "		<input type=\"hidden\" name=\"delete_users\" value=\"1\">";											
											echo "	</td>";
											echo "</tr>";
										}
									}
								
									if ($num_sub_groups > 0) {
										echo "<tr>";
										echo "	<td colspan=\"2\">";
										echo "		You have $num_sub_groups sub-group";
													if ($num_sub_groups > 1) { echo "s"; }
										echo " 		under the $group_name group.";
										echo "	</td>";
										echo "</tr>";
										echo "<tr>";
										echo "	<td><input type=\"radio\" name=\"delete_subgroups\" value=\"1\" onClick=\"disable2()\" CHECKED></td>";
										echo "	<td> - Delete all sub-groups &amp; sub-members.</td>";
										echo "</tr>";
										echo "<tr>";
										echo "	<td><input type=\"radio\" name=\"delete_subgroups\" value=\"0\" onClick=\"enable2()\"></td>";
										echo "	<td> - Move all sub-groups &amp; sub-members.</td>";
										echo "</tr>";
										echo "<tr>";
										echo "	<td>&nbsp;</td>";
										echo "	<td>&nbsp;&nbsp;";
													$query = "SELECT group_id,group_name FROM user_groups WHERE group_id<>'$group_id' AND group_type='0' AND belongs_to='0' ORDER BY group_id ASC";
													$result = mysql_db_query(DATABASE_NAME, $query, $cid);
													if (($result) && ($row=mysql_fetch_array($result))) {
														do {
															$group_id_list_2[$row["group_id"]] = $row["group_name"];
														} while ($row=mysql_fetch_array($result));
														// Displaying Main Group + 2 Next levels of Sub-Groups.					
														echo "<select name=\"group_id_2\" style=\"width: 200px\">\n";
//														echo "<option value=\"\">-- Select Group --</option>\n";
														echo "<option value=\"root\">/</option>\n";
														foreach ($group_id_list_2 as $key => $value) {
															echo "	<option value=\"".$key."\"";
															if ($group_id == $key) { echo " SELECTED"; }
															echo ">/".$value."</option>";
															$query = "SELECT * FROM user_groups WHERE group_id<>'$key' AND group_type='1' AND belongs_to='$key' ORDER BY group_name ASC";
															$result = mysql_db_query(DATABASE_NAME, $query, $cid);
															if (($result) && ($row=mysql_fetch_array($result))) {
																do {
																	echo "<option value=\"".$row["group_id"]."\"";
																	if ($group_id == $row["group_id"]) { echo " SELECTED"; }
																	echo ">&nbsp;&nbsp;-&gt;&nbsp;".$row["group_name"]."</option>";
																} while ($row=mysql_fetch_array($result));
															}
														}
														echo "</select>";
													} else {
														echo "<select name=\"group_id_2\" style=\"width: 200px\">\n";
//														echo "	<option value=\"\">-- Select Group --</option>\n";
														echo "	<option value=\"root\">/</option>\n";
														echo "</select>";											
													}
										echo "	</td>";
										echo "</tr>";
									}
						echo "		</table>";
						echo "	</td>";
						echo "</tr>";
		
						echo "<tr><td>&nbsp;</td></tr>";
					
						echo "<tr>";
						echo "	<td align=\"right\">";
						echo "		<input type=\"hidden\" name=\"group_id\" value=\"$group_id\">";
						echo "		<input type=\"hidden\" name=\"delete_group\" value=\"1\">";
						echo "		<input type=\"hidden\" name=\"do_delete\" value=\"Yes\">";
						echo "		<input type=\"submit\" class=\"submit\" name=\"action\" value=\"Proceed &gt;\">";
						echo "	</td>";
						echo "</tr>";
						echo "</table>";
						echo "</form>";
					} else {
						// There are no groups or members under this group, 
						// just make sure they want to delete it.
						echo "<form action=\"index.php?section=delete&type=group\" method=\"post\">";
						echo "Are you sure you want to delete \"$group_name\"?&nbsp;&nbsp;";
						echo "<input type=\"hidden\" name=\"group_id\" value=\"$group_id\">";
						echo "<input type=\"hidden\" name=\"delete_group\" value=\"1\">";
						echo "<input type=\"submit\" class=\"submit\" name=\"do_delete\" value=\"Yes\">&nbsp;<input type=\"submit\" class=\"submit\" name=\"do_delete\" value=\"&nbsp;No\">";
						echo "</form>";
					}		

					// ----------- End of Delete Group Pre Assign ----------- //				

				} elseif ($modifygroup) {				
					// ----------- Modify Group Pre Assign ----------- //
				
					$query = "SELECT * FROM user_groups WHERE group_id='$group_id'";
					$result = mysql_db_query(DATABASE_NAME, $query, $cid);
					if (($result) && ($row=mysql_fetch_array($result))) {				
						echo "<br /><br />\n";
						echo "<b>Modify Group</b>\n";
						echo "<form action=\"index.php?section=modify\" method=\"post\" name=\"modify\">\n";
						echo "<input type=\"hidden\" name=\"type\" value=\"group\">\n";
						echo "<input type=\"hidden\" name=\"group_id\" value=\"$group_id\">\n";
						echo "<table width=\"400\" cellspacing=\"1\" cellpadding=\"2\" border=\"0\">\n";
						echo "<tr>\n";
						echo "	<td>Group Name:&nbsp;&nbsp;</td>\n";
						echo "	<td><input type=\"text\" class=\"text\" size=\"20\" style=\"width: 200px\" name=\"group_name\" value=\"".$row["group_name"]."\"></td>\n";
						echo "</tr>\n";
						echo "<tr>\n";
						echo "	<td colspan=\"2\">&nbsp;</td>\n";
						echo "</tr>\n";
						echo "<tr>\n";
						echo "	<td colspan=\"2\" align=\"right\"><input type=\"submit\" class=\"submit\" name=\"process\" value=\"Modify Group &gt;\"></td>\n";
						echo "</tr>\n";
						echo "</table>\n";
						echo "</form>\n";
					} else {
						echo "[ERROR]: No group ID.";
					}
	
					// ----------- End of Modify Group Pre Assign ----------- //
			
				} else {
					// ----------- Display the Main Page ----------- //

					if ($addgroup) {
						echo $add_status;
					}
			
					echo "<br /><br />\n";
					echo "<b>Add A Group</b>\n";
					echo "<form action=\"index.php?section=managegroups\" method=\"post\">\n";
					echo "<table width=\"400\" cellspacing=\"1\" cellpadding=\"2\" border=\"0\">\n";
					echo "<tr>\n";
					echo "	<td colspan=\"2\">\n";
								if (($process) && ($success == true)) {
									echo "The group ".$group_name." was successfully added to the database";
									if ($parent_group_id) {
										$query = "SELECT * FROM user_groups WHERE group_id='".$parent_group_id."'";
										$result = mysql_db_query(DATABASE_NAME, $query, $cid);
										if (($result) && ($row=mysql_fetch_array($result))) {
											echo " under the parent group ".$row["group_name"].".<br>";
										}
									} else {
										echo ".<br>";
									}
		
									unset ($group_name);
		
								} elseif (($process) && ($success == false)) {
									echo "Please address the following ".$error." error";
									if ($error > 1) { echo "s"; }
									echo ".<br>";
									echo "<ul>";
									echo 	$errorstring;
									echo "</ul>";
								} else {
									echo "To add a new group, simply enter the name of the group.<br>";
									if ($group_id_count > 0) {
										echo "If you want this to be a sub-group, select the parent group<br>";
										echo "this group belongs to.";
									}
								}
					echo "	</td>\n";
					echo "</tr>\n";
					echo "<tr>\n";
					echo "	<td colspan=\"2\">&nbsp;</td>\n";
					echo "</tr>\n";
					echo "<tr>\n";
					echo "	<td>Group Name:&nbsp;&nbsp;</td>\n";
					echo "	<td><input type=\"text\" class=\"text\" size=\"20\" style=\"width: 200px\" name=\"group_name\" value=\"".$group_name."\" maxlength=\"30\"></td>\n";
					echo "</tr>\n";

					// Makes sure there are Child Groups.
					if ($group_id_count > 0) {
						echo "<tr>\n";
						echo "	<td>Is Child Under:&nbsp;&nbsp;</td>\n";
						echo "	<td>".show_group_select("parent_group_id", "200", 4, $group_id,array(""),"","y")."</td>\n";
						echo "</tr>\n";
					}

					echo "<tr>\n";
					echo "	<td colspan=\"2\">&nbsp;</td>\n";
					echo "</tr>\n";
					echo "<tr>\n";
					echo "	<td colspan=\"2\" align=\"right\"><input type=\"submit\" class=\"submit\" name=\"addgroup\" value=\"Add Group &gt;\"></td>\n";
					echo "</tr>\n";
				
					if ($group_id_count > 0) {			
						echo "<tr>\n";
						echo "	<td colspan=\"2\">\n";
						echo "		<blockquote>\n";
						echo "		<b>Visual Groups Layout</b>\n";
									// Gets All Main Directories.
									$query = "SELECT group_id,group_name FROM user_groups WHERE group_type='0' ORDER BY group_id ASC";
									$result = mysql_db_query(DATABASE_NAME, $query, $cid);
									if (($result) && ($row=mysql_fetch_array($result))) {
										do {
											$group_id_list[$row["group_id"]] = $row["group_name"];
										} while ($row=mysql_fetch_array($result));
				
										// Displaying Main Group + 2 Next levels of Sub-Groups.					
										foreach ($group_id_list as $key => $value) {
											echo "<ul>";
											echo "	<li>".$value."</li>";
											$query = "SELECT * FROM user_groups WHERE group_type='1' AND belongs_to=$key ORDER BY group_name ASC";
											$result = mysql_db_query(DATABASE_NAME, $query, $cid);
											if (($result) && ($row=mysql_fetch_array($result))) {
												echo "		<ul>";							
												do {
													echo "		<li>".$row["group_name"]."</li>";
													$subquery = "SELECT * FROM user_groups WHERE group_type='2' AND belongs_to='".$row["group_id"]."' ORDER BY group_name ASC";
													$subresult = mysql_db_query(DATABASE_NAME, $subquery, $cid);
													if (($subresult) && ($row=mysql_fetch_array($subresult))) {
														echo "		<ul>";
														do {
															echo "		<li>".$row["group_name"]."</li>";
														} while ($row=mysql_fetch_array($subresult));
														echo "		</ul>";
													}
												} while ($row=mysql_fetch_array($result));
												echo "</ul>";
											}
											echo "</ul>";
										}
									}
	
									// List total groups.
									if ($group_id_count == 1) {
										echo "There is ".$group_id_count." group in total.";					
									} elseif ($group_id_count > 1) {
										echo "There are ".$group_id_count." groups in total.";
									}
						echo "		</blockquote>\n";
						echo "	</td>\n";
						echo "</tr>\n";
					}
					echo "</table>\n";	
					echo "</form>\n";
			
					if ($group_id_count > 0) {		
						echo "<b>Modify / Delete A Group</b>\n";
						echo "<form action=\"index.php?section=managegroups\" method=\"post\">\n";
						echo "<table width=\"400\" cellspacing=\"1\" cellpadding=\"2\" border=\"0\">\n";
						echo "<tr>\n";
						echo "	<td colspan=\"2\">\n";
									if ($action=="modify") {
										if ($success == true) {
											echo $group_name." was successfully modified.";
											unset ($group_name);
										} else {
											if ($error > 1) {
												echo "There were ".$error." errors.<br>";
 											} else { 
												echo "There was ".$error." error.a<br>";
											}
											echo "<ul>";
											echo 	$errorstring;
											echo "</ul>";
										}
									} elseif ($action=="delete") {
										if ($success == true) {
											echo $group_name." was successfully removed.";
											unset($group_name);
										} else {
											if ($error > 1) {
												echo "There were ".$error." errors.<br>";
				 							} else { 
												echo "There was ".$error." error.b<br>";
											}
											echo "<ul>";
											echo 	$errorstring;
											echo "</ul>";
										}
									} else {
										echo "Select the group you want to modify/delete and click the<br> corresponding button.";
									}
						echo "	</td>\n";
						echo "</tr>\n";
						echo "<tr>\n";
						echo "	<td colspan=\"2\">&nbsp;</td>\n";
						echo "</tr>\n";
						echo "<tr>\n";
						echo "	<td>Select Group:&nbsp;&nbsp;</td>\n";
						echo "	<td>".show_group_select("group_id", "200", 0, $group_id)."</td>\n";
						echo "</tr>\n";
						echo "<tr>\n";
						echo "	<td colspan=\"2\">&nbsp;</td>\n";
						echo "</tr>\n";
						echo "<tr>\n";
						echo "	<td colspan=\"2\" align=\"right\">\n";
						echo "		<input type=\"submit\" class=\"submit\" name=\"deletegroup\" value=\"Delete&gt;\">&nbsp;<input type=\"submit\" class=\"submit\" name=\"modifygroup\" value=\"Modify&gt;\">\n";			
						echo "	</td>\n";
						echo "</tr>\n";
						echo "<tr>\n";
						echo "	<td colspan=\"2\">&nbsp;</td>\n";
						echo "</tr>\n";
						echo "</table>\n";
					}
					// ----------- End of the Main Page ----------- //
				}
	echo "	</td>\n";
	echo "</tr>\n";
	echo "</table>\n";

?>
