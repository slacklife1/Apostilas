<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

	if($loginattempt) {
		$error=0;
		$query = "SELECT * FROM preferences WHERE preference_id='".PREF_ADMUSER_ID."'";
		$result = mysql_db_query(DATABASE_NAME, $query, $cid);
		if (($result) && ($row=mysql_fetch_array($result))) {
			$realusername = $row["preference_value"];
		} else {
			$error++;
		}		
		$query = "SELECT * FROM preferences WHERE preference_id='".PREF_ADMPASS_ID."'";
		$result = mysql_db_query(DATABASE_NAME, $query, $cid);
		if (($result) && ($row=mysql_fetch_array($result))) {
			$realpassword = $row["preference_value"];
		} else {
			$error++;
		}
	
		if(($username != $realusername) || ($password != $realpassword) || (!$password) || (!$username)) {
			$error++;
		} else {
			$_SESSION["isAuthenticated"] = true;		
			header("location: index.php");
		}
	}
?>
	<table width="100%" height="100%" cellspacing="0" cellpadding="0" border="0">
	<tr>
		<td valign="middle" align="center">
			<table border="0">
			<? if($error) : ?>
			<tr bgcolor="#FFCECE">
				<td colspan="2" align="center"><img src="images/error.gif" width="15" height="15" align="absmiddle"> The Admin username, password or both are incorrect.</td>
			</tr>
			<? endif; ?>
			<tr>
				<td align="center" valign="middle"><img src="images/listmessenger.gif" width="139" height="167" alt="ListMessenger <?= VERSION_INFO ?>"></td>
				<td>
					Welcome to <span class="titlea_positive">List</span><span class="titleb_positive">Messenger</span> <span class="titlea_positive"><? echo VERSION_INFO; ?></span>
					<br /><br />
					<form action="index.php?section=login" method="post">
					<table border="0">
					<tr>
						<td nowrap>Username:&nbsp;&nbsp;</td>
						<td><input type="text" class="text" size="15" style="width: 150px" name="username" value="<?= $user_name ?>"></td>
					</tr>
					<tr>
						<td nowrap>Password:&nbsp;&nbsp;</td>
						<td><input type="password" class="text" size="15" style="width: 150px" name="password" value=""></td>
					</tr>
					<tr>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td colspan="2" align="right">
							<input type="submit" class="submit" name="loginattempt" value="Login &gt;">
						</td>
					</tr>		
					</table>
					</form>
				</td>
			</tr>
			</table>
		</td>
	</tr>
	</table>
