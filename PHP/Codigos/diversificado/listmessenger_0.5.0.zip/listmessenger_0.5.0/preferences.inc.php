<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

?>

	<table width="720" height="532" cellspacing="0" cellpadding="0" border="0">
	<tr>
		<td width="125" valign="top">
			<img src="images/pixel.gif" width="125" height="15" alt="">
		</td>
		<td width="595" valign="top">
			<img src="images/pixel.gif" width="595" height="15" alt="">
		
			<form action="index.php?section=preferences" method="post">
			<br><br>
			<table width="450" cellspacing="1" cellpadding="2" border="0">
			<?
			if ($update) {
				$error = 0;
				$errorstring = "";
				
				$warning = 0;
				$warningstring = "";
				
				foreach($preference_id as $key => $value) {
					$query = "SELECT is_required,type FROM preferences WHERE preference_id='$key'";
					$result = mysql_db_query(DATABASE_NAME, $query, $cid);
					if (($result) && ($row = mysql_fetch_array($result))) {
						if ($row["is_required"] == "1") {
							if ((!$value) || ($value == "")) {
								$query = "SELECT preference_name FROM preferences WHERE preference_id='$key'";
								$result = mysql_db_query(DATABASE_NAME, $query, $cid);
								if (($result) && ($row = mysql_fetch_array($result))) {
									$preference_name = $row["preference_name"];
								} else {
									$preference_name = "( Can't find preference name )";
								}
							
								$error++;
								$errorstring .= "<tr><td bgcolor=\"#FFCECE\"><img src=\"images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"> ".$preference_name." is a required field.</td></tr>\n"; 
							}
						}
						
						switch ($row["type"]) {
							case "text":
								// Currently no special checking done.
							break;
							
							case "password":
								// Currently no special checking done, although password verification
								// will be in next release of ListMessenger.
							break;
							
							case "email":
								// Does as check to make sure this is a valid e-mail address.
								if (!eregi("^[a-z0-9]+([_\\.-][a-z0-9]+)*@([a-z0-9]+([\.-][a-z0-9]+)*)+\\.[a-z]{2,}$", $value)) {
									$error++;
									$errorstring .= "<tr><td bgcolor=\"#FFCECE\"><img src=\"images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"> Please enter a valid e-mail address.</td></tr>\n";
								}
							break;
							
							case "int":
								// Makes sure the string entered is an integer and that it is greater that 1.
								if ((!str_is_int($value)) || ($value < 1)) {
									$error++;
									$errorstring .= "<tr><td bgcolor=\"#FFCECE\"><img src=\"images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"> You must use a positive integer.</td></tr>\n";
								}
							break;
							
							case "path":
								// Checks to make sure the path has a trailing slash.
								if ((substr($value, -1) != "\\") && (substr($value, -1) != "/")) {
									$error++;
									$errorstring .= "<tr><td bgcolor=\"#FFCECE\"><img src=\"images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"> Make sure you enter the trailing slash in your path.</td></tr>\n";
								} 
								// Checks to make sure the path actually exists.
								if (!is_dir($value)) {
									$error++;
									$errorstring .= "<tr><td bgcolor=\"#FFCECE\"><img src=\"images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"> Your path is not accessible. Please create it and try again.</td></tr>\n";
								}									
							break;
							
							case "radio":
								// Will implement next version.
							break;
							
							case "url":
								// Checks to make sure the URL has a trailing slash if not, it just adds one.
								if (substr($value, -1) != "/") {
									$warning++;
									$warningstring .="<tr><td bgcolor=\"#FFFFCC\"><img src=\"images/caution.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"> A trailing slash was added to your URL, you forgot it.</td></tr>\n";
									$value = $value."/";
								}
								// Checks to make sure the URL begins with http://
								if (substr($value, 0, 7) != "http://") {
									$error++;
									$errorstring .= "<tr><td bgcolor=\"#FFCECE\"><img src=\"images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"> URL's must start with \"http://\".</td></tr>\n";
								}
							break;
						}
					
						
					}
			
					if ((!$error) || ($error == 0)) {	
						$query = "UPDATE preferences SET preference_value='$value' WHERE preference_id='$key'";
						$result = mysql_db_query(DATABASE_NAME, $query, $cid);
					}
				}
			}	

			// Gets group info and makes an array
			$query = "SELECT * FROM `preferences` WHERE visible='1' ORDER BY `order_num` ASC";
			$result = mysql_db_query(DATABASE_NAME, $query, $cid);
			if (($result) && ($row = mysql_fetch_array($result))) {
				echo "<tr>";
				echo "	<td colspan=\"2\">";
							if ($update) {
								if ($error) {
									echo "<b>Your preferences were not updated</b>.<br /><br />";
									echo "The following error";
									echo ($error > 1 ? "s " : " "); 
									echo "occured:\n";
									echo "<br /><br />\n";							
									echo "<table width=\"400\" cellspacing=\"2\" cellpadding=\"2\" border=\"0\">\n";
									echo 	$errorstring;
									echo "</table>\n";
									echo "<br /><br />\n";
								} else {
									echo "<b>Your preferences have been updated successfully.</b> <br /><br />	";	
								}
								if ($warning) {
									echo "The following warning";
									echo ($warning > 1 ? "s were" : " was");
									echo " given:";
									echo "<br /><br />\n";							
									echo "<table width=\"400\" cellspacing=\"2\" cellpadding=\"2\" border=\"0\">\n";
									echo 	$warningstring;
									echo "</table>\n";
									echo "<br /><br />\n";
								}
							}
				echo "		Please be sure to update the following preferences on first run.<br />";
				echo "		If you do not understand a setting, please consult with the help<br />"; 
				echo "		file (doc/help.html) as everything is explained in detail there.";
				echo "	</td>";
				echo "</tr>";
				echo "<tr>";
				echo "	<td colspan=\"2\">&nbsp;</td>";
				echo "</tr>";

				do {
					echo "<tr>";
					echo "	<td>".$row["preference_name"].":&nbsp;&nbsp;</td>";
					echo "	<td>";
					
					/* I'm not implementing this now untill version.
					if ($row["type"] == "radio") {
						//1:PHP Mail;2:SMTP
						$options = explode(";",$row["preference_value"]);
						$i=0;

						unset($radiovalue);
						foreach ($options as $key => $value) {
							$i++;
							$this = explode(":", $value);

							if (!$radiovalue) {
								$radiovalue = $row["preference_value"];
							} else {
								$radiovalue = $value.";".$tempa;
							}

							echo "	<input type=\"radio\" name=\"preference_id[".$row["preference_id"]."]\" value=\"".$radiovalue."\"";
							if ($i == 1) { echo " CHECKED"; }
							echo "> - ".$this[1];
						}
					} else {
						echo "	<input type=\"text\" class=\"text\" size=\"20\" style=\"width: 200px\" name=\"preference_id[".$row["preference_id"]."]\" value=\"".$row["preference_value"]."\">\n";
					}
					*/

					echo "		<input type=\"text\" class=\"text\" size=\"25\" style=\"width: 250px\" name=\"preference_id[".$row["preference_id"]."]\" value=\"".$row["preference_value"]."\">\n";
					echo "	</td>";
					echo "</tr>";
				} while ($row = mysql_fetch_array($result));

				echo "<tr>";
				echo "	<td colspan=\"2\">&nbsp;</td>";
				echo "</tr>";
				echo "<tr>";
				echo "	<td colspan=\"2\" align=\"right\"><input type=\"submit\" class=\"submit\" name=\"update\" value=\"Update &gt;\"></td>";
				echo "</tr>";
				
			} else {
				echo "<tr>";
				echo "	<td colspan=\"2\" align=\"left\">";
				echo "		There are currently no preferences in the database.<br>";
				echo "		Please be sure to insert the SQL file that was included with ListMessenger.";
				echo "	</td>";
				echo "</tr>";
			
			}
			
			?>
			</table>	
			</form>
		</td>
	</tr>
	</table>
		
