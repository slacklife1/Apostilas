<?php
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

	session_start();
	ob_start("ob_gzhandler");

	require ("settings.inc.php");	
	
	// Database Connection
	$cid = mysql_pconnect(DATABASE_HOST, DATABASE_USER, DATABASE_PASS);

	// Make sure that the program is setup. If it's not, redirect it to setup.php
	$query = "SELECT preference_value FROM preferences WHERE preference_id='".PREF_ISSETUP_ID."'";
	$result = mysql_db_query(DATABASE_NAME, $query, $cid);
	if (($result) && ($row=mysql_fetch_array($result))) {
		if($row["preference_value"] == 0) {
			header("location: setup/setup.php");
		}
	} else {
		header("location: setup/setup.php");		
	}
	
	if ($action == "logout") {
		unset($_SESSION["isAuthenticated"]);
		$_SESSION["isAuthenticated"] = false;
	}
	if ((!isset($_SESSION["isAuthenticated"])) || ($_SESSION["isAuthenticated"] != true)) {
		$section = "login";
	}

	

	if (!$section) {
		$section = "memberlist";
	}

/*
	setcookie("orderby","$orderby",time()-7200,"/scripts/massmessenger","www.digitalorphans.org");
	setcookie("sort","$sort",time()-7200,"/scripts/massmessenger","www.digitalorphans.org");
	setcookie("orderby","$orderby",time()+7200,"/scripts/massmessenger","www.digitalorphans.org");
	setcookie("sort","$sort",time()+7200,"/scripts/massmessenger","www.digitalorphans.org");
*/

?>

	<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

	<html>
	<head>
		<title>ListMessenger <?= VERSION_INFO ?></title>
		<link rel="stylesheet" type="text/css" href="messenger.css.php" title="style-sheet">
		<?
		if (($section == "managegroups") && ($deletegroup)) {
			$num_sub_groups = group_count($group_id);
			$num_users = user_count($group_id);
	
			echo "<script language=\"JavaScript\">\n";
			if ($num_users > 0) {		
				echo "function disable1() {\n";
				echo "	document.form1.group_id_1.disabled=true\n";
				echo "}\n";
				echo "function enable1() {\n";
				echo "	document.form1.group_id_1.disabled=false\n";
				echo "}\n";
			}

			if ($num_sub_groups > 0) {		
				echo "function disable2() {\n";
				echo "	document.form1.group_id_2.disabled=true\n";
				echo "}\n";
				echo "function enable2() {\n";
				echo "	document.form1.group_id_2.disabled=false\n";
				echo "}\n";
			}
			echo "</script>\n";

			$onLoad = " onLoad=\"";
			if ($num_users > 0) {
				$onLoad .= " disable1();";
			}
			if ($num_sub_groups > 0) {
				$onLoad .= " disable2();";
			}
			$onLoad .= "\"";
		}
		?>
	
	</head>
	<body<?= $onLoad ?>>

	<table bgcolor="#000000" width="720" height="550" cellspacing="0" cellpadding="0" border="0" align="center">
	<tr>
		<td align="center" valign="middle">
			<table width="720" height="550" cellspacing="1" cellpadding="1" border="0">
			<tr>
				<? if($_SESSION["isAuthenticated"]) : ?>
					<td bgcolor="<? if ($section == "memberlist") { echo "#FFFFFF"; } else { echo "#CCCCCC"; }?>" width="125" height="18" align="center" style="cursor:hand;" onclick="window.location='index.php?section=memberlist'"><a href="index.php?section=memberlist">Member List</a></td>
					<td bgcolor="<? if ($section == "composemessage") { echo "#FFFFFF"; } else { echo "#CCCCCC"; }?>" width="125" height="18" align="center" style="cursor:hand;" onclick="window.location='index.php?section=composemessage'"><a href="index.php?section=composemessage">Compose Message</a></td>
					<td bgcolor="<? if ($section == "messagearchive") { echo "#FFFFFF"; } else { echo "#CCCCCC"; }?>" width="125" height="18" align="center" style="cursor:hand;" onclick="window.location='index.php?section=messagearchive'"><a href="index.php?section=messagearchive">Message Archive</a></td>
					<td bgcolor="<? if ($section == "preferences") { echo "#FFFFFF"; } else { echo "#CCCCCC"; }?>" width="125" height="18" align="center" style="cursor:hand;" onclick="window.location='index.php?section=preferences'"><a href="index.php?section=preferences">Preferences</a></td>
				<? else : ?>
					<td bgcolor="#CCCCCC" width="500" height="18"><img src="images/pixel.gif" width="198" height="16"></td>
				<? endif; ?>
				<td bgcolor="#999999" width="220" height="18" align="right"><span class="titlea">List</span><span class="titleb">Messenger</span> <span class="titlea"><? echo VERSION_INFO; ?></span>&nbsp;&nbsp;&nbsp;&nbsp;</td>			
			</tr>
			<? if($_SESSION["isAuthenticated"]) : ?>
			<tr>
				<td colspan="4" bgcolor="#FFFFFF">&nbsp;</td>
				<td bgcolor="#FFFFFF" width="220" height="18" align="right"><a href="index.php?section=update">Update Check</a> | <a href="index.php?action=logout">Logout</a>&nbsp;&nbsp;&nbsp;&nbsp;</td>			
			</tr>
			<? endif; ?>
			<tr>
				<td bgcolor="#FFFFFF" width="720" height="100%" colspan="5">
					<?
					// Database Connection
					$cid = mysql_pconnect(DATABASE_HOST, DATABASE_USER, DATABASE_PASS);

					$query="SELECT preference_value FROM preferences WHERE preference_id='".PREF_PROPATH_ID."'"; 
					$result = mysql_db_query(DATABASE_NAME, $query, $cid);
					if (($result) && ($row = mysql_fetch_array($result))) {
						$program_directory = $row["preference_value"];
					}
					
					if ((eregi("../", $section)) || (eregi("://", $section))) {
						$section = "error";
					}
					
					if ($section) {
						if (file_exists($program_directory.$section.".inc.php")) {
							include $section.".inc.php";
						} else {
							require "error.inc.php";
						}
					} else {
						require "error.inc.php";
					}						
					?>
				</td>
			</tr>
			</table>
		</td>
	</tr>
	</table>
	<table width="720" cellspacing="0" cellpadding="0" border="0" align="center">
	<tr>
		<td width="125">&nbsp;</td>
		<td width="595"><span class="copyright">Copyright &copy; <?= date("Y", time()) ?> <a href="http://www.silentweb.ca" target="_blank" class="copyright">Silentweb</a>. All rights reserved. Written by <a href="mailto:matt@silentweb.ca" class="copyright">Matt Simpson</a></td>
	</tr>
	</table>

	</body>
	</html>

<? ob_end_flush(); ?>
