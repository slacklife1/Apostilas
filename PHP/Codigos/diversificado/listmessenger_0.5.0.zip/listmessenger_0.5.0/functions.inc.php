<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

	if(!defined('_PHP_SNIFF_INCLUDED')) include("classes/sniff.class.php");

	$client = new phpSniff($UA,0);
	$client->init();

	$platform	= $client->property('platform');
	$browser	= $client->property('browser');
	$version	= $client->property('maj_ver');

	// Determines the correct font size based on what Browser / OS end-user has.	
	function fontsize($value) {
		global $platform, $browser, $version;
	
		$WinIE	= $value;
		$WinNS6	= $value;
		$WinNS4	= $value;
		$MacIE	= $value;
		$MacNS6	= $value;
		$MacNS4	= $value+2;

		if ($platform == "win") {
			// It's Windows.
			if ($browser == "ie") {
				// It's Internet Explorer
				return $WinIE;			
			} elseif (($browser == "ns") && ($version == "4")) {
				// It's Netscape 4.x
				return $WinNS4;
			} elseif (($browser == "ns") && ($version == "6")) {
				// It's Netscape 6.x
				return $WinNS6;		
			} else {
				return $WinIE;		
			}
		} elseif ($platform == "mac") {
			// It's a Mac.
			if ($browser == "ie") {
				// It's Internet Explorer
				return $MacIE;		
			} elseif (($browser == "ns") && ($version == "4")) {
				// It's Netscape 4.x
				return $MacNS4;		
			} elseif (($browser == "ns") && ($version == "6")) {
				// It's Netscape 6.x
				return $MacNS6;		
			} else {
				return $MacIE;		
			}
		} else {
			// It's neither. Default to Windows.
			if ($browser == "ie") {
				// It's Internet Explorer
				return $WinIE;			
			} elseif (($browser == "ns") && ($version == "4")) {
				// It's Netscape 4.x
				return $WinNS4;
			} elseif (($browser == "ns") && ($version == "6")) {
				// It's Netscape 6.x
				return $WinNS6;		
			} else {
				return $WinIEw;		
			}
		}
	}

	// I have no idea where this is used or why. I'm confused.
	function get_total_rows($table) {
		// 0 = Error with the count. Probably $table is wrong.
	
		$cid = mysql_pconnect(DATABASE_HOST, DATABASE_USER, DATABASE_PASS);
	
		$query = "SELECT COUNT(*) as totalrows FROM ".$table;
		$result = mysql_db_query(DATABASE_NAME, $query, $cid);
		if (($result) && ($row=mysql_fetch_array($result))) {
			$totalrows = $row["totalrows"];
			return $totalrows;
		} else {
			return 0;
		}
	}

	// Counts to see how many groups & sub-groups there are.
	function group_count($group_id) {
		$cid = mysql_pconnect(DATABASE_HOST, DATABASE_USER, DATABASE_PASS);

		$query = "SELECT * FROM user_groups WHERE belongs_to='$group_id'";
		$result = mysql_db_query(DATABASE_NAME, $query, $cid);
		if (($result) && ($row=mysql_fetch_array($result))) {
			do {
				$sub_groups[$row["group_id"]] = $row["group_name"];
			} while ($row=mysql_fetch_array($result));
				foreach ($sub_groups as $key => $value) {
				$query = "SELECT * FROM user_groups WHERE belongs_to='$key'";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				if (($result) && ($row=mysql_fetch_array($result))) {
					do {
						$sub_groups[$row["group_id"]] = $row["group_name"];
					} while ($row=mysql_fetch_array($result)); 
				}
			}
			return count($sub_groups);
		}
	}

	// Counts to see how many users are in specific group & sub-groups.
	function user_count($group_id) {
		$cid = mysql_pconnect(DATABASE_HOST, DATABASE_USER, DATABASE_PASS);			
	
		$query = "SELECT * FROM user_list WHERE group_id='$group_id'";
		$result = mysql_db_query(DATABASE_NAME, $query, $cid);
		if (($result) && ($row=mysql_fetch_array($result))) {
			do {
				$users[$row["user_id"]] = $row["group_id"];
			} while ($row=mysql_fetch_array($result));
			foreach ($users as $key => $value) {
				$query = "SELECT * FROM user_list WHERE group_id='$value'";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				if (($result) && ($row=mysql_fetch_array($result))) {
					do {
						$users[$row["user_id"]] = $row["group_id"];
					} while ($row=mysql_fetch_array($result)); 
				}
			}
			return count($users);
		}
	}

	// Deletes the specified User
	function del_user($userid) {
		$cid = mysql_pconnect(DATABASE_HOST, DATABASE_USER, DATABASE_PASS);

		$query="DELETE FROM user_list WHERE user_id=$userid";
		$result = mysql_db_query(DATABASE_NAME, $query, $cid);
	
		return true;
	}

	// Adds a group
	function add_group($group_name, $parent_group_id="0") {
		// 1		=	Went through with no errors.
		// error	=	Did not add group, return errors.

		$cid = mysql_pconnect(DATABASE_HOST, DATABASE_USER, DATABASE_PASS);

		$errorstring = "";
		$error_count = 0;

		if (!$group_name) {
			$error_count++;
			$errorstring .= "<li>[ERROR] Please enter the name of the group.</li>\n";
		}
	
		if ($parent_group_id) {
			$query = "SELECT group_id,group_type FROM user_groups WHERE group_id='$parent_group_id'";
			$result = mysql_db_query(DATABASE_NAME, $query, $cid);
			if (($result) && ($row=mysql_fetch_array($result))) {
				if ($row["group_type"] == "0") {
					$group_type = 1;
				} elseif ($row["group_type"] == "1") {
					$group_type = 2;
				} else {
					// This should never happen.
					$group_type = 0;
				}
			} else {
				// This should never happen.
				$group_type = 1;
			}
		} else {
			$group_type = 0;
		}
		$query = "SELECT * FROM user_groups WHERE group_name='$group_name' AND belongs_to='$parent_group_id'";
		$result = mysql_db_query(DATABASE_NAME, $query, $cid);
		if (($result) && ($row=mysql_fetch_array($result))) {
			$error_count++;
			$errorstring .= "<li>[ERROR] That group name already exists under that parent.</li>\n";
		}
		
		if ((!$error_count) || ($error_count == 0)) {
			$query = "INSERT INTO user_groups (group_id, group_type, belongs_to, group_name) VALUES ('$group_id', '$group_type', '$parent_group_id', '$group_name')";
			$result = mysql_db_query(DATABASE_NAME, $query, $cid);
			return 1;
		} else {
			return $errorstring;				
		}
	}

	// Checks to see if Magic Quotes is enabled before adding slashes.
	function checkAddSlashes($this) { 
		if (get_magic_quotes_gpc()) { 
			return ($this); 
		} else {
			return (addslashes($this)); 
		} 
	}

	// Converts string back to HTML.
	function unhtmlspecialchars($html) {
		$this = str_replace(array("&gt;", "&lt;", "&quot;", "&amp;"), array(">", "<", "\"", "&"), $html);
		return $this;
	}

	// Generates the chosen select box type.
	function show_group_select($select_name, $select_width="200", $type=0, $group_id="0", $options = array(""), $current_selection="", $show_blank="") {
		$cid = mysql_pconnect(DATABASE_HOST, DATABASE_USER, DATABASE_PASS);
	
		// Types:
		// 0 = Show All
		// 1 = Show Level 1
		// 2 = Show Level 2
		// 3 = Show Level 3
		// 4 = Show Level 1 & 2
		// 5 = Show Level 2 & 3

		$showthis = true;	
		$html = "";
	
		$query = "SELECT belongs_to FROM user_groups WHERE group_id='$group_id'";
		$result = mysql_db_query(DATABASE_NAME, $query, $cid);
		if (($result) && ($row=mysql_fetch_array($result))) {
			$belongs_to = $row["belongs_to"];
		} else {
			$belongs_to = 0;
		}

		switch ($type) {
			case 0:
			// Show All
			$query = "SELECT group_id,group_name FROM user_groups WHERE group_type='0' ORDER BY group_id ASC";
			$result = mysql_db_query(DATABASE_NAME, $query, $cid);
			if (($result) && ($row=mysql_fetch_array($result))) {
				do {
					$group_id_list[$row["group_id"]] = $row["group_name"];
				} while ($row=mysql_fetch_array($result));
		
				$html .= "<select name=\"".$select_name."\" style=\"width: ".$select_width."px\">\n";
				if ($show_blank == "y") {
					$html .= "<option value=\"\">-- Select Group --</option>\n";
				}
				foreach ($group_id_list as $key => $value) {
					$html .= "	<option value=\"".$key."\"";
					if ($group_id == $key) { $html .= " SELECTED"; }
					$html .= ">".$value."</option>";
					$query = "SELECT * FROM user_groups WHERE group_type='1' AND belongs_to=$key ORDER BY group_name ASC";
					$result = mysql_db_query(DATABASE_NAME, $query, $cid);
					if (($result) && ($row=mysql_fetch_array($result))) {
						do {
							$html .= "	<option value=\"".$row["group_id"]."\"";
							if ($group_id == $row["group_id"]) { $html .= " SELECTED"; }
							$html .= ">&nbsp;&nbsp;-&gt;&nbsp;".$row["group_name"]."</option>";
							$subquery = "SELECT * FROM user_groups WHERE group_type='2' AND belongs_to='".$row["group_id"]."' ORDER BY group_name ASC";
							$subresult = mysql_db_query(DATABASE_NAME, $subquery, $cid);
							if (($subresult) && ($row=mysql_fetch_array($subresult))) {
								do {
									$html .= "	<option value=\"".$row["group_id"]."\"";
									if ($group_id == $row["group_id"]) { $html .= " SELECTED"; }									
									$html .= ">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|_&nbsp;".$row["group_name"]."</option>";
								} while ($row=mysql_fetch_array($subresult));
							}
						} while ($row=mysql_fetch_array($result));
					}
				}
				$html .= "</select>";
			} else {
				$html .= "No Groups Exist. <a href=\"index.php?section=managegroups\" class=\"menu\">Add a group</a>.\n";
				$disable = true;							
			}
			return $html;
			break;

			case 1:
			// Show Level 1
			return $html;			
			break;

			case 2:
			// Show Level 2
			return $html;
			break;

			case 3:
			// Show Level 3
			return $html;
			break;
		
			case 4:
			// Show Level 1 & 2
			
			if (in_array("holdroot", $options)) {
				if ($belongs_to == 0) {
					$showthis = false;
				}
			}
			
			if ($showthis == true) {
				$query = "SELECT group_id,group_name,belongs_to FROM user_groups WHERE group_type='0' ORDER BY group_id ASC";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				if (($result) && ($row=mysql_fetch_array($result))) {
					do {
						$group_id_list[$row["group_id"]] = $row["group_name"];
					} while ($row=mysql_fetch_array($result));
	
					$html .= "<select name=\"".$select_name."\" style=\"width: ".$select_width."px\">\n";			
					if ($show_blank == "y") {
						$html .= "<option value=\"\">-- Select Group --</option>\n";
					}
					foreach ($group_id_list as $key => $value) {
						$html .= "<option value=\"".$key."\"";
						if (in_array("belongsto", $options)) {
							if ($belongs_to == $key) { $html .= " SELECTED"; }
						} else {
							if ($group_id == $key) { $html .= " SELECTED"; }					
						}
						$html .= ">".$value."</option>\n";
						$query = "SELECT * FROM user_groups WHERE group_type='1' AND belongs_to=$key ORDER BY group_name ASC";
						$result = mysql_db_query(DATABASE_NAME, $query, $cid);
						if (($result) && ($row=mysql_fetch_array($result))) {
							do {
								$html .= "	<option value=\"".$row["group_id"]."\"";
								if (in_array("belongsto", $options)) {
									if ($belongs_to == $row["group_id"]) { $html .= " SELECTED"; }
								} else {
									if ($group_id == $key) { $html .= " SELECTED"; }					
								}									
								$html .= ">&nbsp;&nbsp;-&gt;&nbsp;".$row["group_name"]."</option>\n";
							} while ($row=mysql_fetch_array($result));
						}
					}
					$html .= "</select>\n";
				} else {
					$html .= "&nbsp;";
				}
			} else {
				$html .= "Moving a root group is not allowed.";
				$html .= "<input type=\"hidden\" name=\"".$select_name."\" value=\"".$group_id."\">\n";
			}
			return $html;
			break;
			
			case 5:
			// Show Level 2 & 3
			return $html;
			break;
		}
	}

	// Checks to make sure the string is an integer.
	function str_is_int($str) {
		$var = intval($str);
		return ($str == $var);
	}

	// Returns the name of the group from the ID.
	function group_name($id) {
		// Database Connection.
		$cid = mysql_pconnect(DATABASE_HOST, DATABASE_USER, DATABASE_PASS);
		$query = "SELECT group_name FROM user_groups WHERE group_id='".$id."'";
		$result = mysql_db_query(DATABASE_NAME, $query, $cid);
		if (($result) && ($row=mysql_fetch_array($result))) {
			return $row["group_name"];
		} else {
			return "Group Not Present";
		}
	}
	
?>
