<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

	if ($type == "member") {
		if ($userid) {
			del_user($userid);
		}
		header("Location: index.php?section=managegroups");

	} elseif ($type == "group") {

		// This will delete/move the users in the delete group.
		if ($delete_users == 1) {
			if ($group_id) {
				// Delete the users from the main group your deleting.
				$query = "DELETE FROM user_list WHERE group_id='$group_id'";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
			}
		} elseif ($delete_users == 0) {
			if (($group_id) && ($group_id_1)) {
				$new_group = $group_id_1;
				// Move them elsewhere.
				$query = "UPDATE user_list SET group_id='$new_group' WHERE group_id='$group_id'";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
			}
		}

		// This will delete the group if there are no users/sub-groups in the delete group.
		if (($delete_group == 1) && ($do_delete=="Yes")) {
			if($group_id) {
				// Delete the main user group your trying to delete.
				$query = "DELETE FROM user_groups WHERE group_id='$group_id'";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
			}	
		}

		// This will delete/move the sub-groups & users under the delete group.	
		if ($delete_subgroups == 1) {
			if ($group_id) {
				// Delete the sub groups
				$query = "DELETE FROM user_groups WHERE group_id='$group_id'";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				$query = "DELETE FROM user_list WHERE group_id='$group_id'";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				$query = "SELECT group_id,group_name FROM user_groups WHERE belongs_to='$group_id'";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				if (($result) && ($row=mysql_fetch_array($result))) {
					do {
						$sub_groups[$row["group_id"]] = $row["group_name"];
					} while ($row=mysql_fetch_array($result));
					foreach ($sub_groups as $key => $value) {
						$query = "DELETE FROM user_groups WHERE group_id='$key'";
						$result = mysql_db_query(DATABASE_NAME, $query, $cid);
						$query = "SELECT group_id,group_name FROM user_groups WHERE belongs_to='$key'";
						$result = mysql_db_query(DATABASE_NAME, $query, $cid);
						if (($result) && ($row=mysql_fetch_array($result))) {
							do {
								$sub_groups_2[$row["group_id"]] = $row["group_name"];
							} while ($row=mysql_fetch_array($result));
							foreach ($sub_groups_2 as $subkey => $subvalue) {
								$query = "DELETE FROM user_list WHERE group_id='$subkey'";
								$result = mysql_db_query(DATABASE_NAME, $query, $cid);						
							}
						}				
						$query = "DELETE FROM user_groups WHERE belongs_to='$key'";
						$result = mysql_db_query(DATABASE_NAME, $query, $cid);
						$query = "DELETE FROM user_list WHERE group_id='$key'";
						$result = mysql_db_query(DATABASE_NAME, $query, $cid);
					}
				}
			}
		} elseif ($delete_subgroups == 0) {
			if (($group_id) && ($group_id_2)) {
				// Move the sub groups
				if ($group_id_2 == "root") {
					$query = "SELECT * FROM user_groups WHERE belongs_to='$group_id'";
					$result = mysql_db_query(DATABASE_NAME, $query, $cid);
					if (($result) && ($row=mysql_fetch_array($result))) {
						do {
							$sub_groups[$row["group_id"]] = $row["group_name"];
						} while ($row=mysql_fetch_array($result));
						foreach ($sub_groups as $key => $value) {
							$query = "UPDATE user_groups SET belongs_to='0', group_type='0' WHERE group_id='$key'";
							$result = mysql_db_query(DATABASE_NAME, $query, $cid);
							$query = "SELECT * FROM user_groups WHERE belongs_to='$key'";
							$result = mysql_db_query(DATABASE_NAME, $query, $cid);
							if (($result) && ($row=mysql_fetch_array($result))) {
								do {
									$sub_groups_2[$row["group_id"]] = $row["group_name"];
								} while ($row=mysql_fetch_array($result));
								foreach ($sub_groups_2 as $key => $value) {
									$query = "UPDATE user_groups SET group_type='1' WHERE group_id='$key'";
									$result = mysql_db_query(DATABASE_NAME, $query, $cid);		
								}
							}
						}
					}
				} else {
					$query = "SELECT * FROM user_groups WHERE group_id='$group_id_2'";
					$result = mysql_db_query(DATABASE_NAME, $query, $cid);
					if (($result) && ($row=mysql_fetch_array($result))) {
						$group_type = $row["group_type"];
						$belongs_to = $row["belongs_to"];
					}
					$query = "SELECT * FROM user_groups WHERE belongs_to='$group_id'";
					$result = mysql_db_query(DATABASE_NAME, $query, $cid);
					if (($result) && ($row=mysql_fetch_array($result))) {
						do {
							$sub_groups[$row["group_id"]] = $row["group_name"];
						} while ($row=mysql_fetch_array($result));
						if ($group_type == "0") {
							foreach ($sub_groups as $key => $value) {
								$query = "UPDATE user_groups SET belongs_to='$group_id_2', group_type='1' WHERE group_id='$key'";
								$result = mysql_db_query(DATABASE_NAME, $query, $cid);
								$query = "SELECT * FROM user_groups WHERE belongs_to='$key'";
								$result = mysql_db_query(DATABASE_NAME, $query, $cid);
								if (($result) && ($row=mysql_fetch_array($result))) {
									do {
										$sub_groups_2[$row["group_id"]] = $row["group_name"];
									} while ($row=mysql_fetch_array($result));
									foreach ($sub_groups_2 as $key => $value) {
										$query = "UPDATE user_groups SET group_type='2' WHERE group_id='$key'";
										$result = mysql_db_query(DATABASE_NAME, $query, $cid);
										// Checking for current level two's, and changing who owns them.
										$query = "SELECT * FROM user_groups WHERE belongs_to='$key'";
										$result = mysql_db_query(DATABASE_NAME, $query, $cid);
										if (($result) && ($row=mysql_fetch_array($result))) {
											do {
												$sub_groups_3[$row["group_id"]] = $row["group_name"];
											} while ($row=mysql_fetch_array($result));
											foreach ($sub_groups_3 as $key => $value) {
												$query = "UPDATE user_groups SET belongs_to='$group_id_2' WHERE group_id='$key'";
												$result = mysql_db_query(DATABASE_NAME, $query, $cid);
											}
										}
									}
								}
							}
						} elseif ($group_type == "1") {
							foreach ($sub_groups as $key => $value) {
								$query = "UPDATE user_groups SET belongs_to='$group_id_2', group_type='2' WHERE group_id='$key'";
								$result = mysql_db_query(DATABASE_NAME, $query, $cid);
							}
						}
					}
				}
			}
		}
		header("Location: index.php?section=managegroups");

	} else {
		header("Location: index.php?section=managegroups");
	}

?>
