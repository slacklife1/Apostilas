<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

/*
	NOTE: MySQL is only currently supported.  
	
	After you edit this information, you can use whatever to import
	the setup/listmessenger.sql file into the database.

*/

	// Database Connection Options
	define("DATABASE_TYPE", "mysql");
	define("DATABASE_HOST", "localhost");
	define("DATABASE_NAME", "listmessenger");
	define("DATABASE_USER", "");
	define("DATABASE_PASS", "");

?>
