<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/
	require("../config.inc.php");
	
	function mysql_table_exists($tableName, $database, $dbLink) {
		$tables = array();
		$tablesResult = mysql_list_tables($database, $dbLink);
		while ($row = mysql_fetch_row($tablesResult)) $tables[] = $row[0];
		return(in_array($tableName, $tables));
	}

	function str_is_int($str) {
		$var = intval($str);
		return ($str == $var);
	}	

	$error = 0;
	$errorstring = "";

	if(DATABASE_TYPE == "") {
		$error++;
		$errorstring .= "<tr bgcolor=\"#FFCECE\"><td valign=\"top\"><img src=\"../images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"></td><td valign=\"top\">You didn't define DATABASE_TYPE in config.inc.php. Do this first.</td></tr>\n"; 
	}
	if(DATABASE_HOST == "") {
		$error++;
		$errorstring .= "<tr bgcolor=\"#FFCECE\"><td valign=\"top\"><img src=\"../images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"></td><td valign=\"top\">You didn't define DATABASE_HOST in config.inc.php. Do this first.</td></tr>\n"; 
	}
	if(DATABASE_NAME == "") {
		$error++;
		$errorstring .= "<tr bgcolor=\"#FFCECE\"><td valign=\"top\"><img src=\"../images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"></td><td valign=\"top\">You didn't define DATABASE_NAME in config.inc.php. Do this first.</td></tr>\n"; 
	}
	if(DATABASE_USER == "") {
		$error++;
		$errorstring .= "<tr bgcolor=\"#FFCECE\"><td valign=\"top\"><img src=\"../images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"></td><td valign=\"top\">You didn't define DATABASE_USER in config.inc.php. Do this first.</td></tr>\n"; 
	}
	if(DATABASE_PASS == "") {
		$error++;
		$errorstring .= "<tr bgcolor=\"#FFCECE\"><td valign=\"top\"><img src=\"../images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"></td><td valign=\"top\">You didn't define DATABASE_PASS in config.inc.php. Do this first.</td></tr>\n"; 
	}
	
	if ($error > 0) {
		echo "<table width=\"500\" cellspacing=\"1\" cellpadding=\"1\" border=\"0\">\n";
		echo $errorstring;
		echo "</table>\n";
		exit;
	} else {
		// Database Connection
		$cid = mysql_pconnect(DATABASE_HOST, DATABASE_USER, DATABASE_PASS);

		$query = "SELECT preference_value FROM preferences WHERE preference_name='is_setup'";
		$result = mysql_db_query(DATABASE_NAME, $query, $cid);				
		if (($result) && ($row=mysql_fetch_array($result))) {
			if ($row["preference_value"] == 1) {
				header("location: ../index.php");
			}
		}	
	}
	
	if (!$step) {
		$step = 1;
	}
	
	if ($step == 1) {
		require ("setup_1.inc.php");
	} elseif ($step == 2) {
		require ("setup_2.inc.php");	
	} elseif ($step == 3) {
		require ("setup_3.inc.php");	
	} elseif ($step == 4) {
		require ("setup_4.inc.php");	
	} elseif ($step == 5) {
		header("location: ../index.php");	
	}
	

