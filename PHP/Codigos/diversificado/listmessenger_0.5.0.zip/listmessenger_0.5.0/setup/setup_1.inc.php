<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

?>
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

	<html>
	<head>
		<title>ListMessenger Initital Setup - Step 1</title>
		<link rel="stylesheet" type="text/css" href="../messenger.css.php" title="style-sheet">
		
	</head>
	<body>

	<table bgcolor="#000000" width="720" height="550" cellspacing="0" cellpadding="0" border="0" align="center">
	<tr>
		<td align="center" valign="middle">
			<table width="720" height="550" cellspacing="1" cellpadding="1" border="0">
			<tr>
				<td bgcolor="#CCCCCC" width="500" height="18"><img src="../images/pixel.gif" width="198" height="16"></td>
				<td bgcolor="#999999" width="220" height="18" align="right"><span class="titlea">List</span><span class="titleb">Messenger</span> <span class="titlea">Setup</span>&nbsp;&nbsp;&nbsp;&nbsp;</td>			
			</tr>
			<tr>
				<td bgcolor="#FFFFFF" width="720" height="100%" colspan="5" valign="top">
					<table width="720" height="532" cellspacing="0" cellpadding="0" border="0">
					<tr>
						<td width="125" valign="top">
							<img src="../images/pixel.gif" width="125" height="15" alt="">
						</td>
						<td width="500" valign="top">
							<img src="../images/pixel.gif" width="500" height="15" alt="">
							<br><br><br>
							Welcome to the ListMessenger setup script. This script 
							will install the tables to the database that you specified 
							in config.inc.php and allow you to make the initial  
							settings in preferences that you need to be able to run  
							ListMessenger.
							<br><br>
							If you have problems with the setup script installing the 
							correct tables and data, you will have to do it yourself using, 
							PHPMyAdmin or whatever you use to run your MySQL query's. 
							There is a listmessenger.sql file in the setup directory.
							<br><br>
							Any problems with installation can be addressed on the 
							<a href="http://www.digitalorphans.org/openbb/index.php?CID=8" target="_blank" class="internal">message board</a>.
							<br><br>
							Before we begin the install you must <b>Agree</b> to the <b>licence agreement</b>:<br>
							<textarea cols="500" rows="25" style="width: 500px; height:250px" name="licence"><? require("../docs/licence.txt"); ?></textarea>
							<br><br>
							<img src="../images/black_pixel.gif" height="1" width="450">
							<br /><br />
							<form action="setup.php" method="post">
								<input type="hidden" name="step" value="2">
								<input type="submit" class="submit" value="I Agree">
							</form>
						</td>
						<td width="95" valign="top">
							<img src="../images/pixel.gif" width="95" height="15" alt="">						
						</td>
					</tr>
					</table>
				</td>
			</tr>
			</table>
		</td>
	</tr>
	</table>
	<table width="720" cellspacing="0" cellpadding="0" border="0" align="center">
	<tr>
		<td width="125">&nbsp;</td>
		<td width="595"><span class="copyright">Copyright &copy; 2002 <a href="http://www.silentweb.ca" target="_blank" class="copyright">Silentweb</a>. All rights reserved. Written by <a href="mailto:matt@silentweb.ca" class="copyright">Matt Simpson</a></td>
	</tr>
	</table>
	</body>
	</html>