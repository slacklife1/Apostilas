<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/
	// Database Connection
	$cid = mysql_pconnect(DATABASE_HOST, DATABASE_USER, DATABASE_PASS);

	$error = 0;
	$errorstring = "";

	if(DATABASE_TYPE == "") {
		$error++;
		$errorstring .= "<tr bgcolor=\"#FFCECE\"><td valign=\"top\"><img src=\"../images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"></td><td valign=\"top\">You didn't define DATABASE_TYPE in config.inc.php. Do this first.</td></tr>\n"; 
	}
	if(DATABASE_HOST == "") {
		$error++;
		$errorstring .= "<tr bgcolor=\"#FFCECE\"><td valign=\"top\"><img src=\"../images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"></td><td valign=\"top\">You didn't define DATABASE_HOST in config.inc.php. Do this first.</td></tr>\n"; 
	}
	if(DATABASE_NAME == "") {
		$error++;
		$errorstring .= "<tr bgcolor=\"#FFCECE\"><td valign=\"top\"><img src=\"../images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"></td><td valign=\"top\">You didn't define DATABASE_NAME in config.inc.php. Do this first.</td></tr>\n"; 
	}
	if(DATABASE_USER == "") {
		$error++;
		$errorstring .= "<tr bgcolor=\"#FFCECE\"><td valign=\"top\"><img src=\"../images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"></td><td valign=\"top\">You didn't define DATABASE_USER in config.inc.php. Do this first.</td></tr>\n"; 
	}
	if(DATABASE_PASS == "") {
		$error++;
		$errorstring .= "<tr bgcolor=\"#FFCECE\"><td valign=\"top\"><img src=\"../images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"></td><td valign=\"top\">You didn't define DATABASE_PASS in config.inc.php. Do this first.</td></tr>\n"; 
	}		

	if ($error == 0) {
		$status = "";

		// Database Connection
		$cid = mysql_pconnect(DATABASE_HOST, DATABASE_USER, DATABASE_PASS);

		// Checks for the preferences table, if it doesn't exist, it creates it and inserts the data.
		if (mysql_table_exists("preferences", DATABASE_NAME, $cid) != 1) {
			// Doesn't exist, try to create it now.
			$query  = "CREATE TABLE preferences (";
			$query .= "  preference_id int(10) NOT NULL auto_increment,";
			$query .= "  order_num smallint(2) NOT NULL default '0',";
			$query .= "  is_required int(2) NOT NULL default '0',";
			$query .= "  preference_name varchar(150) NOT NULL default '',";
			$query .= "  preference_value text NOT NULL,";
			$query .= "  type varchar(25) NOT NULL default 'text',";
			$query .= "  visible tinyint(2) NOT NULL default '1',";
			$query .= "  PRIMARY KEY  (preference_id),";
			$query .= "  UNIQUE KEY preference_id (preference_id)";
			$query .= ") TYPE=MyISAM;";

			$result = mysql_db_query(DATABASE_NAME, $query, $cid);

			if (mysql_table_exists("preferences", DATABASE_NAME, $cid) == 1) {
				$status .= "<li>Created the table \"preferences\".</li>";
				
				$query  = "INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (1, 1, 1, 'Admin Password', 'password', 'password', 1);";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				$query  = "INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (2, 2, 1, 'From Name', 'From Name', 'text', 1);";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				$query  = "INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (3, 3, 1, 'From Email', 'from@email.com', 'email', 1);";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				$query  = "INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (4, 4, 0, 'Reply Email', 'reply@email.com', 'email', 1);";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				$query  = "INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (5, 5, 0, 'Site Title', 'ListMessenger Lists', 'text', 1);";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				$query  = "INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (8, 0, 1, 'Admin Username', 'administrator', 'text', 1);";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				$query  = "INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (9, 10, 1, 'Display Rows Per Page', '25', 'int', 1);";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				$query  = "INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (13, 0, 1, 'is_setup', '0', 'int', 0);";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				$query  = "INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (14, 6, 1, 'Program Directory Path', '/your/path/to/listmessenger/', 'path', 1);";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				$query  = "INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (15, 7, 1, 'Program Directory URL', 'http://www.yourdomain.com/listmessenger/', 'url', 1);";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);

				$query = "SELECT * FROM preferences";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);				
				if (($result) && ($row=mysql_fetch_array($result))) {
					$status .= "<ul>";
					$status .= "	<li>Inserted Data into \"preferences\".</li>";
					$status .= "</ul>";
				} else {
					$status .= "<ul>";
					$status .= "	<li>Failed to inserted the preference data into \"preferences\", you'll have to do it manually.</li>";
					$status .= "</ul>";
				}	
			} else {
				$status .= "<li>Failed to create the table \"preferences\". You will have to do it yourself.</li>";
			}
			
		} else {
			// Table does exist, check to see if anything is in it.
			$status .= "<li>The preferences table already exists. Good, less work for me.</li>";

			// Checks to see if there is anything in preferences.
			$query = "SELECT * FROM preferences";
			$result = mysql_db_query(DATABASE_NAME, $query, $cid);				
			if (($result) && ($row=mysql_fetch_array($result))) {
				$status .= "<li>Data is already present in the preferences table. Fine, fine... Less work for me.</li>";
			} else {
				$query  = "INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (1, 1, 1, 'Admin Password', 'password', 'password', 1);";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				$query  = "INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (2, 2, 1, 'From Name', 'From Name', 'text', 1);";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				$query  = "INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (3, 3, 1, 'From Email', 'from@email.com', 'email', 1);";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				$query  = "INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (4, 4, 0, 'Reply Email', 'reply@email.com', 'email', 1);";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				$query  = "INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (5, 5, 0, 'Site Title', 'ListMessenger Lists', 'text', 1);";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				$query  = "INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (8, 0, 1, 'Admin Username', 'administrator', 'text', 1);";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				$query  = "INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (9, 10, 1, 'Display Rows Per Page', '25', 'int', 1);";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				$query  = "INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (13, 0, 1, 'is_setup', '0', 'int', 0);";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				$query  = "INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (14, 6, 1, 'Program Directory Path', '/your/path/to/listmessenger/', 'path', 1);";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				$query  = "INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (15, 7, 1, 'Program Directory URL', 'http://www.yourdomain.com/listmessenger/', 'url', 1);";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);

				$query = "SELECT * FROM preferences";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);				
				if (($result) && ($row=mysql_fetch_array($result))) {
					$status .= "<ul>";
					$status .= "	<li>\"preferences\" was already there, so I inserted the data for you.</li>";
					$status .= "</ul>";
				} else {
					$status .= "<ul>";
					$status .= "	<li>\"preferences\" was already there, so I tried to insert the data, but I failed. You'll have to do it manually. Sorry, I tried.</li>";
					$status .= "</ul>";
				}	
			}
		}
		
		// Checks to see if the sent_messages table is there, if it's not, it creates it.
		if (mysql_table_exists("sent_messages", DATABASE_NAME, $cid) != 1) {
			$query  = "CREATE TABLE sent_messages (";
			$query .= "  email_id int(10) NOT NULL auto_increment,";
			$query .= "  email_date varchar(30) NOT NULL default '',";
			$query .= "  email_subject longtext NOT NULL,";
			$query .= "  email_text longtext NOT NULL,";
			$query .= "  email_html longtext,";
			$query .= "  email_to int(11) NOT NULL default '0',";
			$query .= "  status varchar(30) NOT NULL default '',";
			$query .= "  num_sent bigint(30) NOT NULL default '0',";
			$query .= "  num_failed bigint(30) NOT NULL default '0',";
			$query .= "  PRIMARY KEY  (email_id),";
			$query .= "  UNIQUE KEY email_id (email_id)";
			$query .= ") TYPE=MyISAM;";		
			$result = mysql_db_query(DATABASE_NAME, $query, $cid);

			if (mysql_table_exists("preferences", DATABASE_NAME, $cid) == 1) {
				$status .= "<li>Created the table \"sent_messages\".</li>";
			} else {
				$status .= "<li>Failed to create the table \"sent_messages\". Sorry, but you're going to have to do this yourself.</li>";
			}
		} else {
			// Table does exist.
			$status .= "<li>The sent_messages table already exists. Good, I didn't want to do it anyways.</li>";
		}
		
		// Checks to see if the sent_templates table is there, if it's not, it creates it.
		if (mysql_table_exists("sent_templates", DATABASE_NAME, $cid) != 1) {
			$query  = "CREATE TABLE sent_templates (";
			$query .= "  template_id int(10) NOT NULL auto_increment,";
			$query .= "  template_html longtext NOT NULL,";
			$query .= "  PRIMARY KEY  (template_id)";
			$query .= ") TYPE=MyISAM;";
			$result = mysql_db_query(DATABASE_NAME, $query, $cid);

			if (mysql_table_exists("preferences", DATABASE_NAME, $cid) == 1) {
				$status .= "<li>Created the table \"sent_templates\".</li>";
			} else {
				$status .= "<li>Failed to create the table \"sent_templates\". You are going to have to do it yourself.</li>";
			}					
		} else {
			// Table does exist.
			$status .= "<li>The sent_templates table already exists. Damn, do I get to do anything?</li>";
		}

		// Checks to see if the user_groups table is there, if it's not, it creates it.		
		if (mysql_table_exists("user_groups", DATABASE_NAME, $cid) != 1) {
			$query  = "CREATE TABLE user_groups (";
			$query .= "  group_id int(10) NOT NULL auto_increment,";
			$query .= "  group_type int(10) NOT NULL default '0',";
			$query .= "  belongs_to int(10) default NULL,";
			$query .= "  group_name varchar(30) NOT NULL default '',";
			$query .= "  PRIMARY KEY  (group_id),";
			$query .= "  UNIQUE KEY group_id (group_id)";
			$query .= ") TYPE=MyISAM;";		
			$result = mysql_db_query(DATABASE_NAME, $query, $cid);

			if (mysql_table_exists("user_groups", DATABASE_NAME, $cid) == 1) {
				$status .= "<li>Created the table \"user_groups\".</li>";
			} else {
				$status .= "<li>Failed to create the table \"user_groups\". You're going to have to do it. It's all up to you now.</li>";
			}
		} else {
			// Table does exist.
			$status .= "<li>The user_groups table already exists. Man am I ever getting bored!</li>";
		}

		// Checks to see if the user_list table is there, if it's not, it creates it.		
		if (mysql_table_exists("user_list", DATABASE_NAME, $cid) != 1) {
			$query  = "CREATE TABLE user_list (";
			$query .= "  user_id int(10) NOT NULL auto_increment,";
			$query .= "  group_id int(10) NOT NULL default '1',";
			$query .= "  user_name varchar(30) NOT NULL default '',";
			$query .= "  user_address varchar(30) NOT NULL default '',";
			$query .= "  PRIMARY KEY  (user_id),";
			$query .= "  UNIQUE KEY user_id (user_id)";
			$query .= ") TYPE=MyISAM;";
			$result = mysql_db_query(DATABASE_NAME, $query, $cid);

			if (mysql_table_exists("user_list", DATABASE_NAME, $cid) == 1) {
				$status .= "<li>Created the table \"user_list\".</li>";
			} else {
				$status .= "<li>Failed to create the table \"user_list\". Do it yourself, ya baby.</li>";
			}			
		} else {
			// Table does exist.
			$status .= "<li>The user_list table already exists. Whatever.</li>";
		}
	}
	
?>
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

	<html>
	<head>
		<title>ListMessenger Initital Setup - Step 2</title>
		<link rel="stylesheet" type="text/css" href="../messenger.css.php" title="style-sheet">
		
	</head>
	<body>

	<table bgcolor="#000000" width="720" height="550" cellspacing="0" cellpadding="0" border="0" align="center">
	<tr>
		<td align="center" valign="middle">
			<table width="720" height="550" cellspacing="1" cellpadding="1" border="0">
			<tr>
				<td bgcolor="#CCCCCC" width="500" height="18"><img src="../images/pixel.gif" width="198" height="16"></td>
				<td bgcolor="#999999" width="220" height="18" align="right"><span class="titlea">List</span><span class="titleb">Messenger</span> <span class="titlea">Setup</span>&nbsp;&nbsp;&nbsp;&nbsp;</td>			
			</tr>
			<tr>
				<td bgcolor="#FFFFFF" width="720" height="100%" colspan="5" valign="top">
					<table width="720" height="532" cellspacing="0" cellpadding="0" border="0">
					<tr>
						<td width="125" valign="top">
							<img src="../images/pixel.gif" width="125" height="15" alt="">
						</td>
						<td width="500" valign="top">
							<img src="../images/pixel.gif" width="500" height="15" alt="">
							<br><br><br>
							<?
							if ($error > 0) {
								echo "<table width=\"500\" cellspacing=\"1\" cellpadding=\"1\" border=\"0\">\n";
								echo $errorstring;
								echo "</table>\n";
							}

							if ($status) {
								echo "<ul>";
								echo 	$status;
								echo "</ul>";
							}
							?>
							<br><br>
							<br><br>
							<img src="../images/black_pixel.gif" height="1" width="450">
							<br /><br />
							<form action="setup.php" method="post">
								<input type="hidden" name="step" value="3">
								<input type="submit" class="submit" value="Continue">
							</form>
							
						</td>
						<td width="95" valign="top">
							<img src="../images/pixel.gif" width="95" height="15" alt="">						
						</td>
					</tr>
					</table>
				</td>
			</tr>
			</table>
		</td>
	</tr>
	</table>
	<table width="720" cellspacing="0" cellpadding="0" border="0" align="center">
	<tr>
		<td width="125">&nbsp;</td>
		<td width="595"><span class="copyright">Copyright &copy; 2002 <a href="http://www.silentweb.ca" target="_blank" class="copyright">Silentweb</a>. All rights reserved. Written by <a href="mailto:matt@silentweb.ca" class="copyright">Matt Simpson</a></td>
	</tr>
	</table>
	</body>
	</html>