<? header("location: setup.php"); ?>
