# Program: ListMessenger 0.5.0
# Generation Time: Jun 11, 2002 at 12:34 PM
# By: Matt Simpson - matt@silentweb.ca
# --------------------------------------------------------

CREATE TABLE preferences (
  preference_id int(10) NOT NULL auto_increment,
  order_num smallint(2) NOT NULL default '0',
  is_required int(2) NOT NULL default '0',
  preference_name varchar(150) NOT NULL default '',
  preference_value text NOT NULL,
  type varchar(25) NOT NULL default 'text',
  visible tinyint(2) NOT NULL default '1',
  PRIMARY KEY  (preference_id),
  UNIQUE KEY preference_id (preference_id)
) TYPE=MyISAM;

CREATE TABLE sent_messages (
  email_id int(10) NOT NULL auto_increment,
  email_date varchar(30) NOT NULL default '',
  email_subject longtext NOT NULL,
  email_text longtext NOT NULL,
  email_html longtext,
  email_to int(11) NOT NULL default '0',
  status varchar(30) NOT NULL default '',
  num_sent bigint(30) NOT NULL default '0',
  num_failed bigint(30) NOT NULL default '0',
  PRIMARY KEY  (email_id),
  UNIQUE KEY email_id (email_id)
) TYPE=MyISAM;

CREATE TABLE sent_templates (
  template_id int(10) NOT NULL auto_increment,
  template_html longtext NOT NULL,
  PRIMARY KEY  (template_id)
) TYPE=MyISAM;

CREATE TABLE user_groups (
  group_id int(10) NOT NULL auto_increment,
  group_type int(10) NOT NULL default '0',
  belongs_to int(10) default NULL,
  group_name varchar(30) NOT NULL default '',
  PRIMARY KEY  (group_id),
  UNIQUE KEY group_id (group_id)
) TYPE=MyISAM;

CREATE TABLE user_list (
  user_id int(10) NOT NULL auto_increment,
  group_id int(10) NOT NULL default '1',
  user_name varchar(30) NOT NULL default '',
  user_address varchar(30) NOT NULL default '',
  PRIMARY KEY  (user_id),
  UNIQUE KEY user_id (user_id)
) TYPE=MyISAM;

INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (1, 1, 1, 'Admin Password', 'password', 'password', 1);
INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (2, 2, 1, 'From Name', 'From Name', 'text', 1);
INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (3, 3, 1, 'From Email', 'from@email.com', 'email', 1);
INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (4, 4, 0, 'Reply Email', 'reply@email.com', 'email', 1);
INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (5, 5, 0, 'Site Title', 'ListMessenger Lists', 'text', 1);
INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (8, 0, 1, 'Admin Username', 'administrator', 'text', 1);
INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (9, 10, 1, 'Display Rows Per Page', '25', 'int', 1);
INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (13, 0, 1, 'is_setup', '0', 'int', 0);
INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (14, 6, 1, 'Program Directory Path', '/your/path/to/listmessenger/', 'path', 1);
INSERT INTO preferences (preference_id, order_num, is_required, preference_name, preference_value, type, visible) VALUES (15, 7, 1, 'Program Directory URL', 'http://www.yourdomain.com/listmessenger/', 'url', 1);
