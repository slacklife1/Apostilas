<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/
	// Database Connection
	$cid = mysql_pconnect(DATABASE_HOST, DATABASE_USER, DATABASE_PASS);
	
	$query = "UPDATE preferences SET preference_value='1' WHERE preference_name='is_setup'";
	$result = mysql_db_query(DATABASE_NAME, $query, $cid);

?>
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

	<html>
	<head>
		<title>ListMessenger Initital Setup - Finished</title>
		<link rel="stylesheet" type="text/css" href="../messenger.css.php" title="style-sheet">
		
	</head>
	<body>

	<table bgcolor="#000000" width="720" height="550" cellspacing="0" cellpadding="0" border="0" align="center">
	<tr>
		<td align="center" valign="middle">
			<table width="720" height="550" cellspacing="1" cellpadding="1" border="0">
			<tr>
				<td bgcolor="#CCCCCC" width="500" height="18"><img src="../images/pixel.gif" width="198" height="16"></td>
				<td bgcolor="#999999" width="220" height="18" align="right"><span class="titlea">List</span><span class="titleb">Messenger</span> <span class="titlea">Setup</span>&nbsp;&nbsp;&nbsp;&nbsp;</td>			
			</tr>
			<tr>
				<td bgcolor="#FFFFFF" width="720" height="100%" colspan="5" valign="top">
					<table width="720" height="532" cellspacing="0" cellpadding="0" border="0">
					<tr>
						<td width="125" valign="top">
							<img src="../images/pixel.gif" width="125" height="15" alt="">
						</td>
						<td width="500" valign="top">
							<img src="../images/pixel.gif" width="500" height="15" alt="">
							<br><br><br>
							Thank-you for installing ListMessenger.<br><br>
							As I said before, if you have any problems with ListMessenger 
							or need support in any way it is available on our website's 
							<a href="http://www.digitalorphans.org/openbb/index.php?CID=8" target="_blank" class="internal">message board</a>.
							<br><br>
							<br><br>
							<img src="../images/black_pixel.gif" height="1" width="450">
							<br /><br />
							<form action="setup.php" method="post">
								<input type="hidden" name="step" value="5">
								<input type="submit" class="submit" value="Run ListMessenger">
							</form>
						</td>
						<td width="95" valign="top">
							<img src="../images/pixel.gif" width="95" height="15" alt="">						
						</td>
					</tr>
					</table>
				</td>
			</tr>
			</table>
		</td>
	</tr>
	</table>
	<table width="720" cellspacing="0" cellpadding="0" border="0" align="center">
	<tr>
		<td width="125">&nbsp;</td>
		<td width="595"><span class="copyright">Copyright &copy; 2002 <a href="http://www.silentweb.ca" target="_blank" class="copyright">Silentweb</a>. All rights reserved. Written by <a href="mailto:matt@silentweb.ca" class="copyright">Matt Simpson</a></td>
	</tr>
	</table>
	</body>
	</html>