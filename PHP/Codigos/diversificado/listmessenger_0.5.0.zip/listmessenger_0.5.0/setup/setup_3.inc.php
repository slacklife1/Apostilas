<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

	// Database Connection
	$cid = mysql_pconnect(DATABASE_HOST, DATABASE_USER, DATABASE_PASS);

?>
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

	<html>
	<head>
		<title>ListMessenger Initital Setup - Step 3</title>
		<link rel="stylesheet" type="text/css" href="../messenger.css.php" title="style-sheet">
		
	</head>
	<body>

	<table bgcolor="#000000" width="720" height="550" cellspacing="0" cellpadding="0" border="0" align="center">
	<tr>
		<td align="center" valign="middle">
			<table width="720" height="550" cellspacing="1" cellpadding="1" border="0">
			<tr>
				<td bgcolor="#CCCCCC" width="500" height="18"><img src="../images/pixel.gif" width="198" height="16"></td>
				<td bgcolor="#999999" width="220" height="18" align="right"><span class="titlea">List</span><span class="titleb">Messenger</span> <span class="titlea">Setup</span>&nbsp;&nbsp;&nbsp;&nbsp;</td>			
			</tr>
			<tr>
				<td bgcolor="#FFFFFF" width="720" height="100%" colspan="5" valign="top">
					<table width="720" height="532" cellspacing="0" cellpadding="0" border="0">
					<tr>
						<td width="125" valign="top">
							<img src="../images/pixel.gif" width="125" height="15" alt="">
						</td>
						<td width="500" valign="top">
							<img src="../images/pixel.gif" width="500" height="15" alt="">

							<form action="setup.php" method="post">
							<br><br><br>
							<table cellspacing="1" cellpadding="2" border="0">
							<?
							if ($update) {
								$error = 0;
								$errorstring = "";
				
								$warning = 0;
								$warningstring = "";
				
								foreach($preference_id as $key => $value) {
									$query = "SELECT is_required,type FROM preferences WHERE preference_id='$key'";
									$result = mysql_db_query(DATABASE_NAME, $query, $cid);
									if (($result) && ($row = mysql_fetch_array($result))) {
										if ($row["is_required"] == "1") {
											if ((!$value) || ($value == "")) {
												$query = "SELECT preference_name FROM preferences WHERE preference_id='$key'";
												$result = mysql_db_query(DATABASE_NAME, $query, $cid);
												if (($result) && ($row = mysql_fetch_array($result))) {
													$preference_name = $row["preference_name"];
												} else {
													$preference_name = "( Can't find preference name )";
												}
							
												$error++;
												$errorstring .= "<tr><td bgcolor=\"#FFCECE\"><img src=\"../images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"> ".$preference_name." is a required field.</td></tr>\n"; 
											}
										}
						
										switch ($row["type"]) {
											case "text":
											// Currently no special checking done.
											break;
							
											case "password":
												// Currently no special checking done, although password verification
												// will be in next release of ListMessenger.
											break;
							
											case "email":
												// Does as check to make sure this is a valid e-mail address.
												if (!eregi("^[a-z0-9]+([_\\.-][a-z0-9]+)*@([a-z0-9]+([\.-][a-z0-9]+)*)+\\.[a-z]{2,}$", $value)) {
													$error++;
													$errorstring .= "<tr><td bgcolor=\"#FFCECE\"><img src=\"../images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"> Please enter a valid e-mail address.</td></tr>\n";
												}
											break;
							
											case "int":
												// Makes sure the string entered is an integer and that it is greater that 1.
												if ((!str_is_int($value)) || ($value < 1)) {
												$error++;
													$errorstring .= "<tr><td bgcolor=\"#FFCECE\"><img src=\"../images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"> You must use a positive integer.</td></tr>\n";
												}
											break;
							
											case "path":
												// Checks to make sure the path has a trailing slash.
												if ((substr($value, -1) != "\\") && (substr($value, -1) != "/")) {
													$error++;
													$errorstring .= "<tr><td bgcolor=\"#FFCECE\"><img src=\"../images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"> Make sure you enter the trailing slash in your path.</td></tr>\n";
												} 
												// Checks to make sure the path actually exists.
												if (!is_dir($value)) {
													$error++;
													$errorstring .= "<tr><td bgcolor=\"#FFCECE\"><img src=\"../images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"> Your path is not accessible. Please create it and try again.</td></tr>\n";
												}									
											break;
								
											case "radio":
												// Will implement next version.
											break;
							
											case "url":
												// Checks to make sure the URL has a trailing slash if not, it just adds one.
												if (substr($value, -1) != "/") {
													$warning++;
													$warningstring .="<tr><td bgcolor=\"#FFFFCC\"><img src=\"../images/caution.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"> A trailing slash was added to your URL, you forgot it.</td></tr>\n";
													$value = $value."/";
												}
												// Checks to make sure the URL begins with http://
												if (substr($value, 0, 7) != "http://") {
													$error++;
													$errorstring .= "<tr><td bgcolor=\"#FFCECE\"><img src=\"../images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"> URL's must start with \"http://\".</td></tr>\n";
												}
											break;
										}
									}
			
									if ((!$error) || ($error == 0)) {	
										$query = "UPDATE preferences SET preference_value='$value' WHERE preference_id='$key'";
										$result = mysql_db_query(DATABASE_NAME, $query, $cid);
									}
								}
							}	

							// Gets group info and makes an array
							$query = "SELECT * FROM `preferences` WHERE visible='1' ORDER BY `order_num` ASC";
							$result = mysql_db_query(DATABASE_NAME, $query, $cid);
							if (($result) && ($row = mysql_fetch_array($result))) {
								echo "<tr>";
								echo "	<td colspan=\"2\">";
											if ($update) {
												if ($error) {
													echo "<b>Your preferences were not updated</b>.<br /><br />";
													echo "The following error";
													echo ($error > 1 ? "s " : " "); 
													echo "occured:\n";
													echo "<br /><br />\n";							
													echo "<table width=\"400\" cellspacing=\"2\" cellpadding=\"2\" border=\"0\">\n";
													echo 	$errorstring;
													echo "</table>\n";
													echo "<br /><br />\n";
												} else {
													echo "<b>Your preferences have been updated successfully.</b> <br /><br />	";	
												}
												if ($warning) {
													echo "The following warning";
													echo ($warning > 1 ? "s were" : " was");
													echo " given:";
													echo "<br /><br />\n";							
													echo "<table width=\"400\" cellspacing=\"2\" cellpadding=\"2\" border=\"0\">\n";
													echo 	$warningstring;
													echo "</table>\n";
													echo "<br /><br />\n";
												}
											}
											echo "Please update these Settings.<br />";
								echo "	</td>";
								echo "</tr>";
								echo "<tr>";
								echo "	<td colspan=\"2\">&nbsp;</td>";
								echo "</tr>";
								
								$path_guess = strlen($_SERVER["PATH_TRANSLATED"]);
								$path_guess = ($path_guess - 15);
								$path_guess = substr($_SERVER["PATH_TRANSLATED"], 0, $path_guess);
								
								do {
									if ($row["preference_id"] == "14") {
										echo "<tr>";
										echo "	<td>".$row["preference_name"].":&nbsp;&nbsp;</td>";
										echo "	<td>";
										echo "		<input type=\"text\" class=\"text\" size=\"25\" style=\"width: 300px\" name=\"preference_id[".$row["preference_id"]."]\" value=\"".$path_guess."\">\n";
										echo "	</td>";
										echo "</tr>";									
									} else {
										echo "<tr>";
										echo "	<td>".$row["preference_name"].":&nbsp;&nbsp;</td>";
										echo "	<td>";
										echo "		<input type=\"text\" class=\"text\" size=\"25\" style=\"width: 300px\" name=\"preference_id[".$row["preference_id"]."]\" value=\"".$row["preference_value"]."\">\n";
										echo "	</td>";
										echo "</tr>";
									}
								} while ($row = mysql_fetch_array($result));

								echo "<tr>";
								echo "	<td colspan=\"2\">&nbsp;</td>";
								echo "</tr>";
								echo "<tr>";
								echo "	<td colspan=\"2\" align=\"right\">";
								if (($update) && (!$error)) {
									$is_updated = 1;
								}
								echo "		<input type=\"hidden\" name=\"step\" value=\"3\">";
								echo "		<input type=\"submit\" class=\"submit\" name=\"update\" value=\"Update\">";
								echo "	</td>";
								echo "</tr>";
							} else {
								echo "<tr>";
								echo "	<td colspan=\"2\" align=\"left\">";
								echo "		There are currently no preferences in the database.<br>";
								echo "		Please be sure to insert the SQL file that was included with ListMessenger.";
								echo "	</td>";
								echo "</tr>";
							}
							?>
							</table>	
							</form>

							<? if($is_updated == 1) : ?>
								<br><br>
								<br><br>
								<img src="../images/black_pixel.gif" height="1" width="450">
								<br /><br />
								<form action="setup.php" method="post">
									<input type="hidden" name="step" value="4">
									<input type="submit" class="submit" value="Continue">
								</form>
							<? endif; ?>
							
						</td>
						<td width="95" valign="top">
							<img src="../images/pixel.gif" width="95" height="15" alt="">						
						</td>
					</tr>
					</table>
				</td>
			</tr>
			</table>
		</td>
	</tr>
	</table>
	<table width="720" cellspacing="0" cellpadding="0" border="0" align="center">
	<tr>
		<td width="125">&nbsp;</td>
		<td width="595"><span class="copyright">Copyright &copy; 2002 <a href="http://www.silentweb.ca" target="_blank" class="copyright">Silentweb</a>. All rights reserved. Written by <a href="mailto:matt@silentweb.ca" class="copyright">Matt Simpson</a></td>
	</tr>
	</table>
	</body>
	</html>
		
