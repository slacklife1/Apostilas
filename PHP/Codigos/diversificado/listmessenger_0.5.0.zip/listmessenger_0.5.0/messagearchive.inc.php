<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

	if (!isset($_SESSION["sortby_messagearchive"])) {
		$_SESSION["sortby_messagearchive"] = "date";
	}
	if (!isset($_SESSION["sortorder_messagearchive"])) {
		$_SESSION["sortorder_messagearchive"] = "asc";
	}
	if ($orderby) {
		unset($_SESSION["sortby_messagearchive"]);
		unset($_SESSION["sortorder_messagearchive"]);
		$_SESSION["sortby_messagearchive"] = $orderby;
		$_SESSION["sortorder_messagearchive"] = "asc";
	}
	if ($sort) {
		unset($_SESSION["sortorder_messagearchive"]);
		$_SESSION["sortorder_messagearchive"] = $sort;
	}

	$orderby = $_SESSION["sortby_messagearchive"];
	$sort = $_SESSION["sortorder_messagearchive"];

	// Do an Initial Count of Users to get a total.
	$totalrows = get_total_rows("sent_messages");

	// Show this many per page.
	$query = "SELECT preference_value FROM preferences WHERE preference_id='".PREF_PERPAGE_ID."'";
	$result = mysql_db_query(DATABASE_NAME, $query, $cid);
	if (($result) && ($row=mysql_fetch_array($result))) {
		$per_page = $row["preference_value"];
	} else {
		$per_page = 25;
	}

	// If there is no start, define it. Yes this is a bad way of doing it, but it works. I'll change for version 1.
	if (!$page) {
		$page = 1;
	}
	
	// Make sure someone isn't trying to hack the Query.
	if (($sort != "asc") && ($sort != "desc")) {
		$sort = "asc";
	}

	// If sort doesn't exist, make it.
	if (!$sort) {
		$sort = "asc";
	}

	// Just cause this is how I like it.
	$sort = strtoupper($sort);

	$prev_page = $page - 1;  
	$next_page = $page + 1;  
	$page_start = ($per_page * $page) - $per_page;

	if ($totalrows <= $per_page) {  
		$num_pages = 1;  
	} elseif (($totalrows % $per_page) == 0) {  
		$num_pages = ($totalrows / $per_page);  
	} else {  
		$num_pages = ($totalrows / $per_page) + 1;  
	}  

	$num_pages = (int) $num_pages;

	// Incase someone tries to specify an invaid page.
	if (($page > $num_pages) || ($page < 0)) {  
		$page = 1;  
	}
	
?>

	<script language="JavaScript">
	<!--
	function confirmDelete(id,name) {
		doConfirm = confirm('Do you really want to empty the archive?');
		if (doConfirm == true) { 
			window.location = 'index.php?section=delete&type=archive';  
		} else {
			return;
		}
	}	
	//-->
	</script>

	<table width="720" height="532" cellspacing="0" cellpadding="0" border="0">
	<tr>
		<td width="125" valign="top">
			<img src="images/pixel.gif" width="125" height="15" alt="">
			<br /><br />
			<div align="right">
			<?
			// <a href="index.php?section=addmember" class="menu" title="Add A New Member"><img src="images/user.gif" width="16" height="16" alt="Add A New Member" border="0" align="absmiddle" hspace="5" vspace="3">Add Member</a>
			// <a href="index.php?section=managegroups" class="menu" title="Manage Groups"><img src="images/group.gif" width="16" height="16" alt="Manage Groups" border="0" align="absmiddle" hspace="5" vspace="3">Manage Groups</a>

			echo $totalrows;
			if ($totalrows != 1) {
				echo " messages sent";
			} else {
				echo " message sent";
			}
			?>
			&nbsp;&nbsp;
			</div>
			<br /><br />
		</td>
		<td width="595" valign="top">
			<img src="images/pixel.gif" width="595" height="15" alt="">
			<table width="501" cellspacing="1" cellpadding="2" border="0">
			<tr>
				<?
				if ($prev_page) {
					echo "<td align=\"left\" colspan=\"2\"><a href=\"index.php?section=messagearchive&page=".$prev_page."\"><img src=\"images/back_record.gif\" width=\"20\" height=\"11\" alt=\"View Previous Page\" border=\"0\"></a></td>\n";			
				} else {
					echo "<td align=\"left\" colspan=\"2\"><img src=\"images/pixel.gif\" width=\"20\" height=\"11\" alt=\"\"></td>\n";
				}

				echo "<td align=\"center\"\n>";
				echo "	Showing Page ".$page." of ".$num_pages.".\n";
				echo "</td>\n";
	
				if ($page != $num_pages) {
					echo "<td align=\"right\"><a href=\"index.php?section=messagearchive&page=".$next_page."\"><img src=\"images/next_record.gif\" width=\"20\" height=\"11\" alt=\"View Next Page\" border=\"0\"></a></td>\n";			
				} else {
					echo "<td align=\"right\"><img src=\"images/pixel.gif\" width=\"20\" height=\"11\" alt=\"\"></td>\n";			
				}
				?>
			</tr>
			<tr bgcolor="#CCCCCC">
				<td>&nbsp;</td>
				<?
				// I'll figure out a better way to do this some other time.
				// Order by Name Link with sorting options.
				if ($orderby == "date") {
					$queryorderby = "email_date";
					if ($sort == "ASC") {
						echo "<td>&nbsp;<a href=\"index.php?section=messagearchive&orderby=date&sort=desc\" class=\"theadingb\" title=\"Order by Date &amp; Sort Decending\">Date Sent</a>&nbsp;<img src=\"images/arrow_down.gif\" width=\"9\" height=\"9\" alt=\"Ordered By Date\"></td>\n";				
					} elseif ($sort == "DESC") {
						echo "<td>&nbsp;<a href=\"index.php?section=messagearchive&orderby=date&sort=asc\" class=\"theadingb\" title=\"Order by Date &amp; Sort Ascending\">Date Sent</a>&nbsp;<img src=\"images/arrow_up.gif\" width=\"9\" height=\"9\" alt=\"Ordered By Date\"></td>\n";				
					}
				} else {
					echo "<td>&nbsp;<a href=\"index.php?section=messagearchive&orderby=date\" class=\"theading\" title=\"Order by Date\">Date</a>&nbsp;<img src=\"images/pixel.gif\" width=\"9\" height=\"9\" alt=\"\"></td>\n";			
				}
		
				// Order by E-mail Address with sorting options.
				if ($orderby == "subject") {
					$queryorderby = "email_subject";

					if ($sort == "ASC") {
						echo "<td>&nbsp;<a href=\"index.php?section=messagearchive&orderby=subject&sort=desc\" class=\"theadingb\" title=\"Order by Subject &amp; Sort Decending\">Subject</a>&nbsp;<img src=\"images/arrow_down.gif\" width=\"9\" height=\"9\" alt=\"Ordered By Subject\"></td>\n";				
					} elseif ($sort == "DESC") {
						echo "<td>&nbsp;<a href=\"index.php?section=messagearchive&orderby=subject&sort=asc\" class=\"theadingb\" title=\"Order by Subject &amp; Sort Ascending\">Subject</a>&nbsp;<img src=\"images/arrow_up.gif\" width=\"9\" height=\"9\" alt=\"Ordered By Subject\"></td>\n";				
					}
				} else {
					echo "<td>&nbsp;<a href=\"index.php?section=messagearchive&orderby=subject\" class=\"theading\" title=\"Order by Subject\">Subject</a>&nbsp;<img src=\"images/pixel.gif\" width=\"9\" height=\"9\" alt=\"\"></td>\n";			
				}
		
				// Order by Group with sorting options.
				if ($orderby == "group") {
					$queryorderby = "email_to";

					if ($sort == "ASC") {
						echo "<td>&nbsp;<a href=\"index.php?section=messagearchive&orderby=group&sort=desc\" class=\"theadingb\" title=\"Order by Group &amp; Sort Decending\">Sent To</a>&nbsp;<img src=\"images/arrow_down.gif\" width=\"9\" height=\"9\" alt=\"Ordered By Group\"></td>\n";				
					} elseif ($sort == "DESC") {
						echo "<td>&nbsp;<a href=\"index.php?section=messagearchive&orderby=group&sort=asc\" class=\"theadingb\" title=\"Order by Group &amp; Sort Ascending\">Sent To</a>&nbsp;<img src=\"images/arrow_up.gif\" width=\"9\" height=\"9\" alt=\"Ordered By Group\"></td>\n";				
					}
				} else {
					echo "<td>&nbsp;<a href=\"index.php?section=messagearchive&orderby=group\" class=\"theading\" title=\"Order by Group\">Sent To</a>&nbsp;<img src=\"images/pixel.gif\" width=\"9\" height=\"9\" alt=\"\"></td>\n";			
				}  
				?>
			</tr>	
			<?
			// Do the Query.
			$query = "SELECT * FROM sent_messages ORDER BY ".$queryorderby." ".$sort." LIMIT ".$page_start.",".$per_page;
			$result = mysql_db_query(DATABASE_NAME, $query, $cid);

			if (($result) && ($row = mysql_fetch_array($result))) {
				do {
					$date		= date("m.d.y - h:ia", $row["email_date"]);
					$subject		= $row["email_subject"];
					$group 		= group_name($row["email_to"]);
					$messageid	= $row["email_id"];
		
					echo "<tr>";
					echo "	<td width=\"15\"><a href=\"index.php?section=view&type=message&id=".$messageid."\"><img src=\"images/view.gif\" width=\"15\" height=\"15\" alt=\"View Message\" border=\"0\"></a></td>";
					echo "	<td>&nbsp;".$date."</td>";
					echo "	<td>".$subject."</td>";
					echo "	<td>".$group."</td>";
					echo "</tr>";
					} while ($row = mysql_fetch_array($result));
			} else {
				echo "<tr>";
				echo "	<td colspan=\"4\" align=\"center\">No messages have been sent yet.</td>";
				echo "</tr>";
			}
			?>
			<tr>
				<td colspan="5">&nbsp;</td>
			</tr>
			</table>
		</td>
	</tr>
	</table>
		
