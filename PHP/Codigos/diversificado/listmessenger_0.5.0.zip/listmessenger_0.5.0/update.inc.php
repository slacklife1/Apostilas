<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

?>

	<table width="720" height="532" cellspacing="0" cellpadding="0" border="0">
	<tr>
		<td width="125" valign="top">
			<img src="images/pixel.gif" width="125" height="15" alt="">
		</td>
		<td width="595" valign="top">
			<img src="images/pixel.gif" width="595" height="15" alt="">
			<?
			$update = 0;

			$check = @fopen("http://scripts.digitalorphans.org/listmessenger/version", "r");
			$read_version = fread($check, 5); 
			fclose($check);

			if (($check) && ($version)) {
				if ($read_version > VERSION_INFO) {
					$update = 1;
				}
				
				if ($update == 1) {
					echo "Current Version:&nbsp;&nbsp;".VERSION_INFO."<br />";
					echo "New Version:&nbsp;&nbsp;<b>".$read_version."</b><br /><br />";
					echo "Update your version of ListMessenger today. A download is available from <a href=\"http://scripts.digitalorphans.org/listmessenger\" class=\"internal\" target=\"_blank\">our website</a>.";
					echo "<br /><br />";
					echo "<b>URL:</b>&nbsp;&nbsp;<a href=\"http://scripts.digitalorphans.org/listmessenger\" class=\"internal\" target=\"_blank\">http://scripts.digitalorphans.org/listmessenger</a>";
				} else {
					echo "No new versions of list messenger are available at this time.";
				} 
			} else {
				echo "ListMessenger was unable to check for updates at this time. Please try again later.";
			}
			?>
		</td>
	</tr>
	</table>
		
