<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

	require ("settings.inc.php");

?>

	body {
		background-color:			#FFFFFF;
		color:					#000000;
		font-size:				<?= fontsize(8.5) ?>pt;
		font-family:				Verdana, Arial, Sans Sarif;
		font-style:				normal;
		font-weight:				normal;
		text-decoration:			none;
		scrollbar-base-color:		#CCCCCC;
		scrollbar-arrow-color:		#999999;
		scrollbar-3dlight-color:		#EEEEEE;
		scrollbar-darkshadow-color:	#CCCCCC;
		scrollbar-face-color:		#EEEEEE;
		scrollbar-highlight-color:	#EEEEEE;
		scrollbar-shadow-color:		#999999;
		scrollbar-track-color:		#FFFFFF
	}

	a  {
		text-decoration:	none;
		color:			#000000;
		font-size:		<?= fontsize(8.5) ?>pt;
		font-family:		Verdana, Arial, Sans Serif;
		font-weight:		normal
	}
	a:hover  {
		text-decoration:	none;
		color:			#CC0000
	}

	a.internal  {
		text-decoration:	none;
		color:			#CC0000;
		font-size:		<?= fontsize(8.5) ?>pt;
		font-family:		Verdana, Arial, Sans Serif;
		font-weight:		normal
	}
	a.internal:hover  {
		text-decoration:	none;
		color:			#666666
	}

	a.menu  {
		color:			#FF3300;
		font-size:		<?= fontsize(8.5) ?>pt;
		font-family:		Verdana, Arial, Sans Sarif;
		font-style:		normal;
		font-weight:		normal;
		text-decoration:	none		
	}
	a.menu:hover  {
		text-decoration:	none;
		color:			#CC0000
	}

	a.theading  {
		color:			#000000;
		font-size:		<?= fontsize(8.5) ?>pt;
		font-family:		Verdana, Arial, Sans Sarif;
		font-style:		normal;
		font-weight:		bold;
		text-decoration:	none		
	}
	a.theading:hover  {
		color:			#CC0000
	}

	a.theadingb  {
		color:			#333333;
		font-size:		<?= fontsize(8.5) ?>pt;
		font-family:		Verdana, Arial, Sans Sarif;
		font-style:		oblique;
		font-weight:		bold;
	}
	a.theadingb:hover  {
		color:			#CC0000
	}
	
	
	td {
		color:			#000000;
		font-size:		<?= fontsize(8.5) ?>pt;
		font-family:		Verdana, Arial, Sans Sarif;
		font-style:		normal;
		font-weight:		normal;
		text-decoration:	none		
	}

	input.text {
		margin-top:		0px; 
		margin-bottom:		4px; 
		height:			20px; 
		font-family:		Verdana, Arial, Sans Serif; 
		font-size:		<?= fontsize(8.5) ?>pt; 
		color:			#000000; 	
		background:		#CCCCCC; 
		border:			1px; 
		border-style:		solid; 
		border-color:		#000000
	}

	input.submit {
		height:			20px; 
		font-family:		Verdana, Arial, Sans Serif; 
		font-size:		<?= fontsize(8.5) ?>pt; 
		color:			#000000; 	
		background:		#CCCCCC; 
		border:			1px; 
		border-style:		solid; 
		border-color:		#000000
	}

	select {
		margin-top:		0px; 
		margin-bottom:		4px; 
		height:			20px; 
		font-family:		Verdana, Arial, Sans Serif; 
		font-size:		<?= fontsize(8.5) ?>pt; 
		color:			#000000; 	
		background:		#CCCCCC; 
		border:			1px; 
		border-style:		solid; 
		border-color:		#000000;
	}

	.titlea {
		color:			#FFFFFF;
		font-size:		<?= fontsize(10) ?>pt;
		font-family:		Verdana, Arial, Sans Sarif;
		font-style:		normal;
		font-weight:		normal;
		text-decoration:	none		
	}

	.titleb {
		color:			#FFFFFF;
		font-size:		<?= fontsize(10) ?>pt;
		font-family:		Verdana, Arial, Sans Sarif;
		font-style:		normal;
		font-weight:		bold;
		text-decoration:	none		
	}

	.titlea_positive {
		color:			#666666;
		font-size:		<?= fontsize(10) ?>pt;
		font-family:		Verdana, Arial, Sans Sarif;
		font-style:		normal;
		font-weight:		normal;
		text-decoration:	none		
	}

	.titleb_positive {
		color:			#666666;
		font-size:		<?= fontsize(10) ?>pt;
		font-family:		Verdana, Arial, Sans Sarif;
		font-style:		normal;
		font-weight:		bold;
		text-decoration:	none		
	}

	.copyright {
		color:			#999999;
		font-size:		<?= fontsize(7) ?>pt;
		font-family:		Verdana, Arial, Sans Sarif;
		font-style:		normal;
		font-weight:		normal;
		text-decoration:	none		
	}
	.copyright:hover  {
		text-decoration:	none;
		color:			#CC0000
	}