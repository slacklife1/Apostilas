<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

	if (!isset($_SESSION["sortby_memberlist"])) {
		$_SESSION["sortby_memberlist"] = "name";
	}
	if (!isset($_SESSION["sortorder_memberlist"])) {
		$_SESSION["sortorder_memberlist"] = "asc";
	}
	if ($orderby) {
		unset($_SESSION["sortby_memberlist"]);
		unset($_SESSION["sortorder_memberlist"]);
		$_SESSION["sortby_memberlist"] = $orderby;
		$_SESSION["sortorder_memberlist"] = "asc";
	}
	if ($sort) {
		unset($_SESSION["sortorder_memberlist"]);
		$_SESSION["sortorder_memberlist"] = $sort;
	}

	$orderby = $_SESSION["sortby_memberlist"];
	$sort = $_SESSION["sortorder_memberlist"];

	// Do an Initial Count of Users to get a total.
	$totalrows = get_total_rows("user_list");

	// Show this many per page.
	$query = "SELECT preference_value FROM preferences WHERE preference_id='".PREF_PERPAGE_ID."'";
	$result = mysql_db_query(DATABASE_NAME, $query, $cid);
	if (($result) && ($row=mysql_fetch_array($result))) {
		$per_page = $row["preference_value"];
	} else {
		$per_page = 25;
	}

	// If there is no start, define it. Yes this is a bad way of doing it, but it works. I'll change for version 1.
	if (!$page) {
		$page = 1;
	}
	
	// Gets group info and makes an array
	$query = "SELECT * FROM user_groups";
	$result = mysql_db_query(DATABASE_NAME, $query, $cid);
	if (($result) && ($row=mysql_fetch_array($result))) {
		do {
			$usergroup[$row["group_id"]] = $row["group_name"];
		} while ($row = mysql_fetch_array($result));
	}

	// Make sure someone isn't trying to hack the Query.
	if (($sort != "asc") && ($sort != "desc")) {
		$sort = "asc";
	}

	// If sort doesn't exist, make it.
	if (!$sort) {
		$sort = "asc";
	}

	// Just cause this is how I like it.
	$sort = strtoupper($sort);

	$prev_page = $page - 1;  
	$next_page = $page + 1;  
	$page_start = ($per_page * $page) - $per_page;

	if ($totalrows <= $per_page) {  
		$num_pages = 1;  
	} elseif (($totalrows % $per_page) == 0) {  
		$num_pages = ($totalrows / $per_page);  
	} else {  
		$num_pages = ($totalrows / $per_page) + 1;  
	}  

	$num_pages = (int) $num_pages;

	// Incase someone tries to specify an invaid page.
	if (($page > $num_pages) || ($page < 0)) {  
		$page = 1;  
	}
	
?>

	<script language="JavaScript">
	<!--
	function confirmDelete(id,name) {
		doConfirm = confirm('Do you really want to delete '+name+'?');
		if (doConfirm == true) { 
			window.location = 'index.php?section=delete&type=member&userid='+id;  
		} else {
			return;
		}
	}
	//-->
	</script>


	<table width="720" height="532" cellspacing="0" cellpadding="0" border="0">
	<tr>
		<td width="125" valign="top">
			<img src="images/pixel.gif" width="125" height="15" alt="">
			<a href="index.php?section=addmember" class="menu" title="Add A New Member"><img src="images/user.gif" width="16" height="16" alt="Add A New Member" border="0" align="absmiddle" hspace="5" vspace="3">Add Member</a>
			<a href="index.php?section=managegroups" class="menu" title="Manage Groups"><img src="images/group.gif" width="16" height="16" alt="Manage Groups" border="0" align="absmiddle" hspace="5" vspace="3">Manage Groups</a>
		
			<br><br><br><br><br>
			<div align="right">
			<?
			echo $totalrows;
			if ($totalrows != 1) {
				echo " subscribers";
			} else {
				echo " subscriber";
			}
			?>
			&nbsp;&nbsp;
			</div>
		</td>
		<td width="595" valign="top">
			<img src="images/pixel.gif" width="595" height="15" alt="">
			<table width="501" cellspacing="1" cellpadding="2" border="0">
			<tr>
				<?
				if ($prev_page) {
					echo "<td align=\"left\" colspan=\"3\"><a href=\"index.php?section=memberlist&page=".$prev_page."\"><img src=\"images/back_record.gif\" width=\"20\" height=\"11\" alt=\"View Previous Page\" border=\"0\"></a></td>\n";			
				} else {
					echo "<td align=\"left\" colspan=\"3\"><img src=\"images/pixel.gif\" width=\"20\" height=\"11\" alt=\"\"></td>\n";
				}
	
				echo "<td align=\"center\"\n>";
				echo "	Showing Page ".$page." of ".$num_pages.".\n";
				echo "</td>\n";

				if ($page != $num_pages) {
					echo "<td align=\"right\"><a href=\"index.php?section=memberlist&page=".$next_page."\"><img src=\"images/next_record.gif\" width=\"20\" height=\"11\" alt=\"View Next Page\" border=\"0\"></a></td>\n";			
				} else {
					echo "<td align=\"right\"><img src=\"images/pixel.gif\" width=\"20\" height=\"11\" alt=\"\"></td>\n";			
				}
				?>
			</tr>
			<tr bgcolor="#CCCCCC">
				<td colspan="2">&nbsp;</td>
				<?
				// I'll figure out a better way to do this some other time.
				// Order by Name Link with sorting options.
				if ($orderby == "name") {
					$queryorderby = "user_name";
					if ($sort == "ASC") {
						echo "<td>&nbsp;<a href=\"index.php?section=memberlist&orderby=name&sort=desc\" class=\"theadingb\" title=\"Order by Name &amp; Sort Decending\">Persons Name</a>&nbsp;<img src=\"images/arrow_down.gif\" width=\"9\" height=\"9\" alt=\"Ordered By Name\"></td>\n";				
					} elseif ($sort == "DESC") {
						echo "<td>&nbsp;<a href=\"index.php?section=memberlist&orderby=name&sort=asc\" class=\"theadingb\" title=\"Order by Name &amp; Sort Ascending\">Persons Name</a>&nbsp;<img src=\"images/arrow_up.gif\" width=\"9\" height=\"9\" alt=\"Ordered By Name\"></td>\n";				
					}
				} else {
					echo "<td>&nbsp;<a href=\"index.php?section=memberlist&orderby=name\" class=\"theading\" title=\"Order by Name\">Persons Name</a>&nbsp;<img src=\"images/pixel.gif\" width=\"9\" height=\"9\" alt=\"\"></td>\n";			
				}
		
				// Order by E-mail Address with sorting options.
				if ($orderby == "email") {
					$queryorderby = "user_address";

					if ($sort == "ASC") {
						echo "<td>&nbsp;<a href=\"index.php?section=memberlist&orderby=email&sort=desc\" class=\"theadingb\" title=\"Order by E-mail Address &amp; Sort Decending\">E-mail Address</a>&nbsp;<img src=\"images/arrow_down.gif\" width=\"9\" height=\"9\" alt=\"Ordered By E-mail Address\"></td>\n";				
					} elseif ($sort == "DESC") {
						echo "<td>&nbsp;<a href=\"index.php?section=memberlist&orderby=email&sort=asc\" class=\"theadingb\" title=\"Order by E-mail Address &amp; Sort Ascending\">E-mail Address</a>&nbsp;<img src=\"images/arrow_up.gif\" width=\"9\" height=\"9\" alt=\"Ordered By E-mail Address\"></td>\n";				
					}
				} else {
					echo "<td>&nbsp;<a href=\"index.php?section=memberlist&orderby=email\" class=\"theading\" title=\"Order by E-mail Address\">E-mail Address</a>&nbsp;<img src=\"images/pixel.gif\" width=\"9\" height=\"9\" alt=\"\"></td>\n";			
				}
			
				// Order by Group with sorting options.
				if ($orderby == "group") {
					$queryorderby = "group_id";

					if ($sort == "ASC") {
						echo "<td>&nbsp;<a href=\"index.php?section=memberlist&orderby=group&sort=desc\" class=\"theadingb\" title=\"Order by Group &amp; Sort Decending\">In Group</a>&nbsp;<img src=\"images/arrow_down.gif\" width=\"9\" height=\"9\" alt=\"Ordered By Group\"></td>\n";				
					} elseif ($sort == "DESC") {
						echo "<td>&nbsp;<a href=\"index.php?section=memberlist&orderby=group&sort=asc\" class=\"theadingb\" title=\"Order by Group &amp; Sort Ascending\">In Group</a>&nbsp;<img src=\"images/arrow_up.gif\" width=\"9\" height=\"9\" alt=\"Ordered By Group\"></td>\n";				
					}
				} else {
					echo "<td>&nbsp;<a href=\"index.php?section=memberlist&orderby=group\" class=\"theading\" title=\"Order by Group\">In Group</a>&nbsp;<img src=\"images/pixel.gif\" width=\"9\" height=\"9\" alt=\"\"></td>\n";			
				}  
				?>
			</tr>	
			<?
			// Do the Query.
			$query = "SELECT * FROM user_list ORDER BY ".$queryorderby." ".$sort." LIMIT ".$page_start.",".$per_page;
			$result = mysql_db_query(DATABASE_NAME, $query, $cid);
			if (($result) && ($row = mysql_fetch_array($result))) {
				do {
					$userid		= $row["user_id"];
					$groupid		= $row["group_id"];
					$username 	= $row["user_name"];
					$useraddress	= $row["user_address"];
		
					if ($usergroup[$groupid]) {
						$groupname = $usergroup[$groupid];
					} else {
						$groupname = "unknown";
					}
			
					echo "<tr>";
					echo "	<td width=\"13\"><a href=\"javascript:confirmDelete('".$userid."','".$useraddress."')\"><img src=\"images/delete.gif\" width=\"13\" height=\"14\" alt=\"Delete ".$username."\" border=\"0\"></a></td>";
					echo "	<td width=\"13\"><a href=\"index.php?section=modify&type=member&userid=".$userid."\"><img src=\"images/edit.gif\" width=\"13\" height=\"14\" alt=\"Edit ".$username."\" border=\"0\"></a></td>";
					echo "	<td>&nbsp;".$username."</td>";
					echo "	<td>".$useraddress."</td>";
					echo "	<td>".$groupname."</td>";
					echo "</tr>";

				} while ($row = mysql_fetch_array($result));
			} else {
				echo "<tr>";
				echo "	<td colspan=\"5\" align=\"center\">There are no users in your database</td>";
				echo "</tr>";
			}
			?>
			<tr>
				<td colspan="5">&nbsp;</td>
			</tr>
			</table>
		</td>
	</tr>
	</table>
		
