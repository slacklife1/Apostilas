<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

	// Processing starts.
	if (($process) && ($type == "member")) {
		$error = 0;
		if ($user_address) {
			if (!eregi("^[a-z0-9]+([_\\.-][a-z0-9]+)*@([a-z0-9]+([\.-][a-z0-9]+)*)+\\.[a-z]{2,}$", $user_address, $regs)) {
				$error++;
				$errorstring .= "<li>[ERROR] Please enter a valid e-mail address.</li>\n";
			}
		} else {
			$error++;
			$errorstring .= "<li>[ERROR] Please enter the members e-mail address.</li>\n";
		}
		if ((!$group_id) || ($group_id == "")) {
			$error++;
			$errorstring .= "<li>[ERROR] Please select a group to insert into.</li>\n";
		}

		$query = "SELECT * FROM user_list WHERE user_id<>'$userid'";
		$result = mysql_db_query(DATABASE_NAME, $query, $cid);
		if (($result) && ($row=mysql_fetch_array($result))) {
			do {
				if ($user_address == $row["user_address"]) {
					$error++;
					$errorstring .= "<li>[ERROR] The address ".$row["user_address"]." already exists in the database and belongs to ".$row["user_name"].".</li>\n";
				}
			} while ($row=mysql_fetch_array($result));
		}
		if (!$error) {
			$query = "UPDATE user_list SET group_id='$group_id', user_name='$user_name', user_address='$user_address' WHERE user_id='$userid'";
			$result = mysql_db_query(DATABASE_NAME, $query, $cid);
							
			header("location: index.php");
		} else {
			echo "<table width=\"720\" height=\"532\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\">\n";
			echo "<tr>\n";
			echo "	<td width=\"125\" valign=\"top\">\n";
			echo "		<img src=\"images/pixel.gif\" width=\"125\" height=\"15\" alt=\"\">\n";
			echo "	</td>\n";
			echo "	<td width=\"595\" valign=\"top\">\n";
			echo "		<img src=\"images/pixel.gif\" width=\"595\" height=\"15\" alt=\"\">\n";
			echo "		<br /><br />\n";
			echo "		Unable to update group information:<br />\n";
			echo "		<ul>\n";
			echo 			$errorstring;
			echo "		</ul>\n";
			echo "		<a href=\"javascript:history.go(-1)\">go back</a>\n";
			echo "	</td>\n";
			echo "</tr>\n";
			echo "</table>\n";		
		}
	} elseif (($process) && ($type == "group")) {
		$error = 0;
	
		if ((!$group_name) || ($group_name == "")) {
			$error++;
			$errorstring .= "<li>[ERROR] Group Name cannot be empty.</li>\n";
		}
	
		if ((!$group_id) || ($group_id == "")) {
			$error++;
			$errorstring .= "<li>[ERROR] Oops, we lost the group id.</li>\n";
		}
		
		if ((!$error) || ($error == 0)) {
			$query = "UPDATE user_groups SET group_name='$group_name' WHERE group_id='$group_id'";
			$result = mysql_db_query(DATABASE_NAME, $query, $cid);
		
			header("location: index.php");
		} else {
			$success = false;
		}

	} elseif ($type == "member") {
		$success = true;
		echo "<table width=\"720\" height=\"532\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\">\n";
		echo "<tr>\n";
		echo "	<td width=\"125\" valign=\"top\">\n";
		echo "		<img src=\"images/pixel.gif\" width=\"125\" height=\"15\" alt=\"\">\n";
		echo "	</td>\n";
		echo "	<td width=\"595\" valign=\"top\">\n";
		echo "		<img src=\"images/pixel.gif\" width=\"595\" height=\"15\" alt=\"\">\n";
		echo "		<br /><br />\n";
					if (($type == "member") && ($userid)) {
						$query = "SELECT * FROM user_list WHERE user_id=$userid";
						$result = mysql_db_query(DATABASE_NAME, $query, $cid);
						if (($result) && ($row=mysql_fetch_array($result))) {
							$user_name = $row["user_name"];
							$user_address = $row["user_address"];
							$group_id = $row["group_id"];
			
							echo "<form action=\"index.php?section=modify\" method=\"post\">\n";
							echo "<table width=\"450\" cellspacing=\"1\" cellpadding=\"2\" border=\"0\">\n";
							echo "<tr>\n";
							echo "	<td colspan=\"2\">\n";
										if ($success == false) {
											if ($error > 1) {
												echo "Please fix the following $error errors.";
											} else {
												echo "Please fix the following error.";
											}
											echo "<ul>";
											echo 	$errorstring;
											echo "</ul>";
										} else {
											echo "Change the values you wish to change and click Update.";
										}
							echo "	</td>\n";
							echo "</tr>\n";
							echo "<tr>\n";
							echo "	<td colspan=\"2\">&nbsp;</td>\n";
							echo "</tr>\n";
							echo "<tr>\n";
							echo "	<td>Full Name:&nbsp;&nbsp;</td>\n";
							echo "	<td><input type=\"text\" class=\"text\" size=\"20\" style=\"width: 200px\" name=\"user_name\" value=\"".$user_name."\"></td>\n";
							echo "</tr>\n";
							echo "<tr>\n";
							echo "	<td>E-mail Address:&nbsp;&nbsp;</td>\n";
							echo "	<td><input type=\"text\" class=\"text\" size=\"20\" style=\"width: 200px\" name=\"user_address\" value=\"".$user_address."\"></td>\n";
							echo "</tr>\n";
							echo "<tr>\n";
							echo "	<td>Belongs To:&nbsp;&nbsp;</td>\n";
							echo "	<td>".show_group_select("group_id", "200", 0, $group_id)."</td>\n";
							echo "</tr>\n";
							echo "<tr>\n";
							echo "	<td colspan=\"2\">&nbsp;</td>\n";
							echo "</tr>\n";
							echo "<tr>\n";
							echo "	<td colspan=\"2\" align=\"right\">\n";
							echo "		<input type=\"hidden\" name=\"userid\" value=\"".$userid."\">\n";
							echo "		<input type=\"hidden\" name=\"type\" value=\"member\">\n";
							echo "		<input type=\"submit\" class=\"submit\" name=\"process\" value=\"Update &gt;\"";
										if ($disable == true) { echo " disabled"; }
							echo "		>\n";
							echo "	</td>\n";
							echo "</tr>\n";
							echo "</table>\n";
							echo "</form>\n";
						}
					}
		echo "	</td>\n";
		echo "</tr>\n";
		echo "</table>\n";
	}		
