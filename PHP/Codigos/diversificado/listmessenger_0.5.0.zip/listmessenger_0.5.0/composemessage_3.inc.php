<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

?>
	<table width="720" height="532" cellspacing="0" cellpadding="0" border="0">
	<tr>
		<td width="125" valign="top">
			<img src="images/pixel.gif" width="125" height="15" alt="">
		</td>
		<td width="595" valign="top">
			<img src="images/pixel.gif" width="595" height="15" alt="">
			<?
			if ($send == "Send E-Mail") {
				$query = "SELECT preference_value FROM preferences WHERE preference_id='".PREF_RPYEMAL_ID."'";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				if (($result) && ($row=mysql_fetch_array($result))) {
					$reply_email = $row["preference_value"];
				} else {
					$reply_email = $from_email;
				}
				
				require("classes/class.phpmailer.php");			
				
				$this->Mail = new phpmailer();
				$this->Mail->Priority = 3;
				$this->Mail->Encoding = "8bit";
				$this->Mail->CharSet = "iso-8859-1";
				$this->Mail->From = $from_email;
				$this->Mail->FromName = $from_name;
				$this->Mail->Sender = $from_email;
				if (($html_message) && ($html_message != "")) {
					$this->Mail->Body = $html_message;
					$this->Mail->AltBody = $text_message;
				} else {
					$this->Mail->Body = $text_message;			
				}
				$this->Mail->WordWrap = 60;
				$this->Mail->PluginDir = "classes/";
				$this->Mail->Mailer = "mail";
				$this->Mail->AddReplyTo($reply_email, $from_name);
/*
				$this->Mail->Host = $global_vars["mail_host"];
				$this->Mail->Port = 25;
				$this->Mail->Helo = "localhost.localdomain";
				$this->Mail->SMTPAuth = false;
				$this->Mail->Username = "";
				$this->Mail->Password = "";
				if(strlen($this->Mail->Host) > 0) {
					$this->Mail->Mailer = "smtp";
				} else {
					$this->Mail->Mailer = "mail";
					$this->Sender = "unit_test@phpmailer.sf.net";
				}
*/		
				$error		= 0;
				$errorstring	= "";
				$date		= date("l, F dS, Y", time());

				$total_subscribers = user_count($group_id);
				$tmp_text_message	= stripslashes($text_message);
				$tmp_subject		= stripslashes($subject);
			
				// Modifying string to show current [date]
				$tmp_subject		= str_replace("[date]", $date, $tmp_subject);			
				$tmp_text_message	= str_replace("[date]", $date, $tmp_text_message);
						
				if (($html_message) && ($html_message != "")) {
					$tmp_html_message = stripslashes($html_message);
					$tmp_html_message = str_replace("[date]", $date, $tmp_html_message);
				}

				$query = "SELECT * FROM user_list WHERE group_id='".$to_group."'";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
				if (($result) && ($row=mysql_fetch_array($result))) {
					$success=0;
					do {
						unset($text_version);
						unset($html_version);
						unset($mod_subject);
						unset($use_name);
	
						// This does the replace of the [name] & [email]
						if ((!$row["user_name"]) || ($row["user_name"] == "")) {
							$use_name = "Friend";
						} else {
							$use_name = $row["user_name"];
						}

						$mod_subject	= str_replace("[name]", $use_name, $tmp_subject);
						$mod_subject	= str_replace("[email]", $row["user_address"], $mod_subject);
						$text_version	= str_replace("[name]", $use_name, $tmp_text_message);
						$text_version	= str_replace("[email]", $row["user_address"], $text_version);
										
						if (($html_message) && ($html_message != "")) {
							$html_version = str_replace("[name]", $use_name, $tmp_html_message);
							$html_version = str_replace("[email]", "<a href=\"mailto:".$row["user_address"]."\">".$row["user_address"]."</a>", $html_version);
							$this->Mail->Body = $html_version;
							$this->Mail->AltBody = $text_version;
						} else {
							$this->Mail->Body = $text_version;	
						}

						$this->Mail->Subject = $mod_subject;		
						$this->Mail->ClearAddresses();
						$this->Mail->AddAddress($row["user_address"],$row["user_name"]);
					
						if($this->Mail->Send()) {
							$success++;
						} else {
							$error++;
							$errorstring .= "<tr bgcolor=\"#FFCECE\"><td valign=\"top\" width=\"15\"><img src=\"images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"></td><td valign=\"top\">Error sending e-mail to ".$row["user_address"].".</td></tr>\n";
						}
					} while($row=mysql_fetch_array($result));
				} else {
					$error++;
					$errorstring .= "<tr bgcolor=\"#FFCECE\"><td valign=\"top\" width=\"15\"><img src=\"images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"></td><td valign=\"top\">Unable to select users in that group. The group may be empty.</td></tr>\n";
				}

				// I know this won't work correctly if there is only 1 person in your list, but who cares right now.
				if (($error > 0) && ($success > 0)) {
					$status = "Sent messages but failures occurred.";
				} elseif ($success == 0) {
					$status = "Failed to send any messages.";
				} elseif ($error == 0) {
					$status = "Messages were sent successfully.";
				}

				$query = "INSERT INTO sent_messages (email_id, email_date, email_subject, email_text, email_html, email_to, status, num_sent, num_failed) VALUES ('','".time()."','".$subject."','".$text_message."','".$html_message."','".$to_group."','".$status."','".$success."','".$error."')";
				$result = mysql_db_query(DATABASE_NAME, $query, $cid);
						
				echo "<br /><br />";
				echo "<table width=\"450\" cellspacing=\"1\" cellpadding=\"2\" border=\"0\">";
				if ($error > 0) {
					echo $errorstring;
				} else {
					echo "<tr>";
					echo "	<td>$success messeges were sent and $error failed.</td>";
					echo "</tr>";
				}
				echo "</table>";
			}
			?>
		</td>
	</tr>
	</table>

