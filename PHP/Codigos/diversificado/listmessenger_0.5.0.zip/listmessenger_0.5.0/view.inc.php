<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

?>

	<table width="720" height="532" cellspacing="0" cellpadding="0" border="0">
	<tr>
		<td width="125" valign="top">
			<img src="images/pixel.gif" width="125" height="15" alt="">
		</td>
		<td width="595" valign="top">
			<img src="images/pixel.gif" width="595" height="15" alt="">
			<?
			if ($type == "message") {
				if ($id) {
					$query = "SELECT * FROM sent_messages WHERE email_id='".$id."'";
					$result = mysql_db_query(DATABASE_NAME, $query, $cid);
					if (($result) && ($row=mysql_fetch_array($result))) {
						$date		= date("m.d.y - h:ia", $row["email_date"]);
						$subject		= $row["email_subject"];
						$text_message	= $row["email_text"];
						$html_message	= $row["email_html"];
						$group 		= group_name($row["email_to"]);
						$status		= $row["status"];
						$num_sent		= $row["num_sent"];
						$num_failed	= $row["num_failed"];
	
						echo "<table width=\"450\" cellspacing=\"1\" cellpadding=\"2\" border=\"0\">\n";
						echo "<tr>\n";
						echo "	<td><b>Date Sent:</b>&nbsp;&nbsp;</td>\n";
						echo "	<td colspan=\"2\">".$date."</td>\n";
						echo "</tr>\n";

						echo "<tr>\n";
						echo "	<td><b>To:</b>&nbsp;&nbsp;</td>\n";
						echo "	<td colspan=\"2\">".$group."</td>\n";
						echo "</tr>\n";
	
						echo "<tr>\n";
						echo "	<td><b>Subject:</b>&nbsp;&nbsp;</td>\n";
						echo "	<td colspan=\"2\">".$subject."</td>\n";
						echo "</tr>\n";

						echo "<tr>\n";
						echo "	<td><b>Status:</b>&nbsp;&nbsp;</td>\n";
						echo "	<td colspan=\"2\">".$status.".</td>\n";
						echo "</tr>\n";
						echo "<tr>\n";
						echo "	<td>&nbsp;&nbsp;</td>\n";
						echo "	<td colspan=\"2\">";
						echo "		<br>";
						echo 		$num_sent." message";
									if ($num_sent > 1) { echo "s"; }
									echo " sent, ".$num_failed." message";
									if ($num_sent > 1) { echo "s"; }					
									echo " failed.";
						echo "	</td>\n";
						echo "</tr>\n";
						
						echo "<tr><td colspan=\"3\"><br><br>&nbsp;</td></tr>";
						
						echo "<tr>\n";
						echo "	<td colspan=\"3\">\n";
						echo "		<b>Plain Text</b> version:<br />\n";
						echo "		<img src=\"images/black_pixel.gif\" height=\"1\" width=\"450\">\n";
						echo "		<br /><br />\n";
						echo 		nl2br(stripslashes($text_message));
						echo "		<br /><br /><br /><br />\n";
									if ($html_message) {
										echo "<b>HTML</b> version:<br />\n";
										echo "<img src=\"images/black_pixel.gif\" height=\"1\" width=\"450\">\n";
										echo "<br /><br />\n";
										echo "<form action=\"preview.php\" method=\"post\" target=\"_blank\">\n";
										echo "	There is an HTML version of this e-mail present. Select below which you wish<br />\n";
										echo "	to view. This will open in a new _blank window. Close it when you're finished.\n";
										echo "	<br /><br />\n";
										echo "	<input type=\"hidden\" name=\"html_message\" value=\"".htmlspecialchars(stripslashes($html_message))."\">\n";
										echo "	<input type=\"submit\" class=\"submit\" name=\"view\" value=\"View Source\">&nbsp;&nbsp;\n";
										echo "	<input type=\"submit\" class=\"submit\" name=\"view\" value=\"View Page\">\n";
										echo "</form>\n";
									}
						echo "		<br><br><br>";								
						echo "	</td>\n";
						echo "</tr>";
						echo "</table>";		
					}				
				} else {
					echo "No Message ID was present.";
				}
			}
			?>		
		</td>
	</tr>
	</table>