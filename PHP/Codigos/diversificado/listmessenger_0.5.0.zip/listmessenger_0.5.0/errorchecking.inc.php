<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

	if ($preview) {
		$error = 0;
		$errorstring = "";

		$warning = 0;
		$warningstring = "";

		if ((!$from_name) || ($from_name == "")) {
			$error++;
			$errorstring .= "<tr bgcolor=\"#FFCECE\"><td valign=\"top\"><img src=\"images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"></td><td valign=\"top\">From name was not found. There is a problem with your settings.</td></tr>\n";
		} else {
			$from_name = checkAddSlashes($from_name);
		}
		if ((!$from_email) || ($from_email == "")) {
			$error++;
			$errorstring .= "<tr bgcolor=\"#FFCECE\"><td valign=\"top\"><img src=\"images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"></td><td valign=\"top\">From e-mail was not found. There is a problem with your settings.</td></tr>\n";
		} else {
			$from_email = checkAddSlashes($from_email);
		}
		if ((!$to_group) || ($to_group == "")) {
			$error++;
			$errorstring .= "<tr bgcolor=\"#FFCECE\"><td valign=\"top\"><img src=\"images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"></td><td valign=\"top\">You did not select a \"<b>To Group</b>\" to send this to.</td></tr>\n";
		} else {
			$to_group = checkAddSlashes($to_group);
		}
		if ((!$subject) || ($subject == "")) {
			$warning++;
			$warningstring .= "<tr bgcolor=\"#FFFFCC\"><td valign=\"top\"><img src=\"images/caution.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"></td><td valign=\"top\">You did not enter a \"<b>Subject</b>\". You can ignore this and your subject will read as (no subject).</td></tr>\n";
		} else {
			$subject = checkAddSlashes($subject);
		}
		if ((!$text_message) || ($text_message == "")) {
			$error++;
			$errorstring .= "<tr bgcolor=\"#FFCECE\"><td valign=\"top\"><img src=\"images/error.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"></td><td valign=\"top\">You did not enter a text message, this is required at a minimum. HTML only e-mails are anoying to those who do not have an e-mail client that will read HTML e-mail.</td></tr>\n";
		} else {
			$text_message = checkAddSlashes($text_message);
		}
		if ((!$html_message) || ($html_message == "")) {
			$warning++;
			$warningstring .= "<tr bgcolor=\"#FFFFCC\"><td valign=\"top\"><img src=\"images/caution.gif\" width=\"15\" height=\"15\" align=\"absmiddle\"></td><td valign=\"top\">You did not enter anything in the HTML e-mail field. You can ignore this and your message will send just plain text.</td></tr>\n";
		} else {
			$html_message = checkAddSlashes($html_message);
		}
	} elseif ($send) {
	
	}

?>
