<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

	$query = "SELECT preference_value FROM preferences WHERE preference_id='".PREF_FRMEMAL_ID."'";
	$result = mysql_db_query(DATABASE_NAME, $query, $cid);
	if (($result) && ($row=mysql_fetch_array($result))) {
		$from_email = $row["preference_value"];
	} else {
		$from_email = "Error: From e-mail undefined.";
	}
	
	$query = "SELECT preference_value FROM preferences WHERE preference_id='".PREF_FRMNAME_ID."'";
	$result = mysql_db_query(DATABASE_NAME, $query, $cid);
	if (($result) && ($row=mysql_fetch_array($result))) {
		$from_name = $row["preference_value"];
	} else {
		$from_name = "Error: From name undefined.";
	}
	
	if ((!$cc) || ($cc !=1)) { $cc=0; }
	if ((!$bcc) || ($bcc != 1)) { $bcc=0; }
	
?>

	<table width="720" height="532" cellspacing="0" cellpadding="0" border="0">
	<tr>
		<td width="125" valign="top">
			<img src="images/pixel.gif" width="125" height="15" alt="">
			<br />
			&nbsp;&nbsp;<b>E-Mail Variables</b><br />
			&nbsp;<img src="images/question.gif" align="absmiddle" width="13" height="13" hspace="3" vspace="3">&nbsp;[name]<br />
			&nbsp;<img src="images/question.gif" align="absmiddle" width="13" height="13" hspace="3" vspace="3">&nbsp;[email]<br />
			&nbsp;<img src="images/question.gif" align="absmiddle" width="13" height="13" hspace="3" vspace="3">&nbsp;[date]<br />
		</td>
		<td width="595" valign="top">
			<img src="images/pixel.gif" width="595" height="15" alt="">
			<?
			if ($error) {
				echo "The following error";
				echo ($error > 1 ? "s " : " "); 
				echo "occured and must be fixed before previewing the message:\n";
				echo "<br /><br />\n";							
				echo "<table width=\"400\" cellspacing=\"2\" cellpadding=\"2\" border=\"0\">\n";
				echo 	$errorstring;
				echo "</table>\n";
				echo "<br /><br />\n";
			}
			if ($warning) {
				echo "The following warning";
				echo ($warning > 1 ? "s were" : " was");
				echo " also issued:";
				echo "<br /><br />\n";							
				echo "<table width=\"400\" cellspacing=\"2\" cellpadding=\"2\" border=\"0\">\n";
				echo		$warningstring;
				echo "</table>\n";
				echo "<br /><br />\n";
			}
			?>
		
			<form action="index.php?section=composemessage" method="post">
			<table width="450" cellspacing="1" cellpadding="2" border="0">
			<tr>
				<td><b>From:</b>&nbsp;&nbsp;</td>
				<td colspan="2">
					<b>"<?= htmlspecialchars(stripslashes($from_name)) ?>" &lt;<?= htmlspecialchars(stripslashes($from_email)) ?>&gt;</b>
					<input type="hidden" name="from_name"  value="<?= htmlspecialchars(stripslashes($from_name)) ?>">
					<input type="hidden" name="from_email" value="<?= htmlspecialchars(stripslashes($from_email)) ?>">
				</td>
			</tr>
			<tr>
				<td><b>To:</b>&nbsp;&nbsp;</td>
				<td colspan="2"><?= show_group_select("to_group", "200", 0); ?></td>
			</tr>		
			<tr>
				<td><b>Subject:</b>&nbsp;&nbsp;</td>
				<td colspan="2"><input type="text" class="text" size="20" style="width: 350px" name="subject" value="<?= htmlspecialchars(stripslashes($subject)) ?>"></td>
			</tr>		
			<tr>
				<td colspan="3">
					<br /><br />
					<b>Plain Text</b> version of e-mail here.<br />
					<textarea cols="45" rows="17" style="width: 450px; height:175px" name="text_message"><?= htmlspecialchars(stripslashes($text_message)) ?></textarea>
					<br /><br />
					<b>HTML</b> version of e-mail here if one exists.<br />
					<textarea cols="45" rows="17" style="width: 450px; height:300px" name="html_message"><?= htmlspecialchars(stripslashes($html_message)) ?></textarea>
				</td>
			</tr>
			<tr>
				<td align="right" colspan="3">
					<input type="hidden" name="doCheck" value="1">
					<input type="hidden" name="step" value="2">
					<input type="submit" class="submit" name="preview" value="Preview E-Mail">&nbsp;&nbsp;
				</td>
			</tr>
			</table>
			</form>
		</td>
	</tr>
	</table>
