<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

	if (!$step) {
		$step = 1;
	}

	if ($back) {
		$doCheck = 0;
		$step = $step - 2;
	}

	if ($doCheck == 1) {
		require ("errorchecking.inc.php");
	}

	if ($error) {
		$step = $step - 1;
	}

	if ($step == 1) {
		require ("composemessage_1.inc.php");
	} elseif ($step == 2) {
		require ("composemessage_2.inc.php");
	} elseif ($step == 3) {
		require ("composemessage_3.inc.php");
	}

?>

