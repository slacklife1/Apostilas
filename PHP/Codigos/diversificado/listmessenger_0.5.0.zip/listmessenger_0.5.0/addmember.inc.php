<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

	echo "<table width=\"720\" height=\"532\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\">\n";
	echo "<tr>\n";
	echo "	<td width=\"125\" valign=\"top\">\n";
	echo "		<img src=\"images/pixel.gif\" width=\"125\" height=\"15\" alt=\"\">\n";
	echo "	</td>\n";
	echo "	<td width=\"595\" valign=\"top\">\n";
	echo "		<img src=\"images/pixel.gif\" width=\"595\" height=\"15\" alt=\"\">\n";
	echo "		<br><br>\n";

				if ($process) {
					$error = 0;
					if ($user_address) {
						if (!eregi("^[a-z0-9]+([_\\.-][a-z0-9]+)*@([a-z0-9]+([\.-][a-z0-9]+)*)+\\.[a-z]{2,}$", $user_address, $regs)) {
							$error++;
							$errorstring .= "<li>[ERROR] Please enter a valid e-mail address.</li>\n";
						}
					} else {
						$error++;
						$errorstring .= "<li>[ERROR] Please enter the members e-mail address.</li>\n";
					}
							
					if (!$group_id) {
						$error++;
						$errorstring .= "<li>[ERROR] Please select a group to insert into.</li>\n";
					}

					// Gets a list of users
					$query = "SELECT * FROM user_list WHERE user_address='$user_address'";
					$result = mysql_db_query(DATABASE_NAME, $query, $cid);
					if (($result) && ($row=mysql_fetch_array($result))) {
						$error++;
						$errorstring .= "<li>[ERROR] The address ".$row["user_address"]." already exists.</li>\n";
					}

					if (!$error) {
						$query = "INSERT INTO user_list (user_id, group_id, user_name, user_address) VALUES ('', '$group_id', '$user_name', '$user_address')";
						$result = mysql_db_query(DATABASE_NAME, $query, $cid);
						$success = true;
					} else {
						$success = false;				
					}
				}

	echo "		<form action=\"index.php?section=addmember\" method=\"post\">\n";
	echo "		<table width=\"450\" cellspacing=\"1\" cellpadding=\"2\" border=\"0\">\n";
	echo "		<tr>\n";
	echo "			<td colspan=\"2\">\n";
						if (($process) && ($success == true)) {
							echo $user_address." was successfully added to the database.<br>";
							echo "You can now add another or return to <a href=\"index.php\" class=\"menu\">member list</a>.";
							unset ($user_name);
							unset ($user_address);
						} elseif (($process) && ($success == false)) {
							if ($error > 1) {
								echo "There were $error errors. Please fix:<br>";
							} else {
								echo "Please fix the following error:<br>";
							}
							echo "<ul>";
							echo		$errorstring;
							echo "</ul>";
						} else {
							echo "To manually add a new entry, simply enter the users full name<br>";
							echo "and e-mail address before clicking the add user button.";
						}
	echo "			</td>\n";
	echo "		</tr>\n";
	echo "		<tr>\n";
	echo "			<td colspan=\"2\">&nbsp;</td>\n";
	echo "		</tr>\n";
	echo "		<tr>\n";
	echo "			<td>Full Name:&nbsp;&nbsp;</td>\n";
	echo "			<td><input type=\"text\" class=\"text\" size=\"20\" style=\"width: 200px\" name=\"user_name\" value=\"".$user_name."\"></td>\n";
	echo "		</tr>\n";
	echo "		<tr>\n";
	echo "			<td>E-mail Address:&nbsp;&nbsp;</td>\n";
	echo "			<td><input type=\"text\" class=\"text\" size=\"20\" style=\"width: 200px\" name=\"user_address\" value=\"".$user_address."\"></td>\n";
	echo "		</tr>\n";
	echo "		<tr>\n";
	echo "			<td>Belongs To:&nbsp;&nbsp;</td>\n";
	echo "			<td>\n";

						$query = "SELECT group_id,group_name FROM user_groups WHERE group_type='0' ORDER BY group_id ASC";
						$result = mysql_db_query(DATABASE_NAME, $query, $cid);
						if (($result) && ($row=mysql_fetch_array($result))) {
							do {
								$group_id_list[$row["group_id"]] = $row["group_name"];
							} while ($row=mysql_fetch_array($result));


							// Displaying Main Group + 2 Next levels of Sub-Groups.					
						
							echo "<select name=\"group_id\" style=\"width: 200px\">\n";
							foreach ($group_id_list as $key => $value) {
								echo "	<option value=\"".$key."\"";
								if ($group_id == $key) { echo " SELECTED"; }
								echo ">".$value."</option>";
								$query = "SELECT * FROM user_groups WHERE group_type='1' AND belongs_to=$key ORDER BY group_name ASC";
								$result = mysql_db_query(DATABASE_NAME, $query, $cid);
								if (($result) && ($row=mysql_fetch_array($result))) {
									do {
										echo "	<option value=\"".$row["group_id"]."\"";
										if ($group_id == $row["group_id"]) { echo " SELECTED"; }
										echo ">&nbsp;&nbsp;-&gt;&nbsp;".$row["group_name"]."</option>";
										$subquery = "SELECT * FROM user_groups WHERE group_type='2' AND belongs_to='".$row["group_id"]."' ORDER BY group_name ASC";
										$subresult = mysql_db_query(DATABASE_NAME, $subquery, $cid);
										if (($subresult) && ($row=mysql_fetch_array($subresult))) {
											do {
												echo "	<option value=\"".$row["group_id"]."\"";
												if ($group_id == $row["group_id"]) { echo " SELECTED"; }
												echo ">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|_&nbsp;".$row["group_name"]."</option>";
											} while ($row=mysql_fetch_array($subresult));
										}
		
									} while ($row=mysql_fetch_array($result));
								}
							}
							echo "</select>";
						} else {
							echo "<a href=\"index.php?section=managegroups\" class=\"menu\">Add group</a> before adding members.";
							$disable = true;							
						}
	echo "			</td>\n";
	echo "		</tr>\n";
	echo "		<tr>\n";
	echo "			<td colspan=\"2\">&nbsp;</td>\n";
	echo "		</tr>\n";
	echo "		<tr>\n";
	echo "			<td colspan=\"2\" align=\"right\">\n";
	echo "				<input type=\"submit\" class=\"submit\" name=\"process\" value=\"Add User &gt;\"";
						if ($disable == true) {
							echo " disabled>";
						} else {
							echo ">";
						}
	echo "			</td>\n";
	echo "		</tr>\n";
	echo "		</table>\n";
	echo "		</form>\n";
	echo "	</td>\n";
	echo "</tr>\n";
	echo "</table>\n";

?>
		
