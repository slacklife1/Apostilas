<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

?>
	<table width="720" height="532" cellspacing="0" cellpadding="0" border="0">
	<tr>
		<td width="125" valign="top">
			<img src="images/pixel.gif" width="125" height="15" alt="">
		</td>
		<td width="595" valign="top">
			<img src="images/pixel.gif" width="595" height="15" alt="">
			<?
			if ($warning) {
				echo "The following <b>warning</b>";
				echo ($warning > 1 ? "<b>s</b> were" : " was");
				echo ($error > 0 ? " also" : "");
				echo " issued:";
				echo "<br /><br />\n";							
				echo "<table width=\"400\" cellspacing=\"2\" cellpadding=\"2\" border=\"0\">\n";
				echo		$warningstring;
				echo "</table>\n";
			}
			?>
			<br /><br />
			<table width="450" cellspacing="1" cellpadding="2" border="0">
			<tr>
				<td><b>From:</b>&nbsp;&nbsp;</td>
				<td colspan="2"><b>"<?= htmlspecialchars(stripslashes($from_name)) ?>" &lt;<?= htmlspecialchars(stripslashes($from_email)) ?>&gt;</b></td>
			</tr>
			<tr>
				<td><b>To:</b>&nbsp;&nbsp;</td>
				<td colspan="2">
					<?
					$query = "SELECT group_name FROM user_groups WHERE group_id='".stripslashes($to_group)."'";
					$result = mysql_db_query(DATABASE_NAME, $query, $cid);
					if (($result) && ($row=mysql_fetch_array($result))) {
						echo $row["group_name"];
					} else {
						echo "Cannot find To Group name.";
					}
					?>
				</td>
			</tr>		
			<tr>
				<td><b>Subject:</b>&nbsp;&nbsp;</td>
				<td colspan="2">
					<?
					if ((!$subject) || ($subject == "")) {
						$subject = "(no subject)";
					}
					echo $subject;
					?>
				</td>
			</tr>		
			<tr>
				<td colspan="3">
					<br /><br />				
					<b>Plain Text</b> version:<br />
					<img src="images/black_pixel.gif" height="1" width="450">
					<br /><br />
					<?= nl2br(stripslashes($text_message)) ?>
					<br /><br />						
					<br /><br />
					<? if ($html_message) : ?>
						<b>HTML</b> version:<br />
						<img src="images/black_pixel.gif" height="1" width="450">
						<br /><br />
						<form action="preview.php" method="post" target="_blank">
							There is an HTML version of this e-mail present. Select below which you wish<br />
							to view. This will open in a new _blank window. Close it when you're finished.
							<br /><br />
							<input type="hidden" name="html_message" value="<?= htmlspecialchars(stripslashes($html_message)) ?>">
							<input type="submit" class="submit" name="view" value="View Source">&nbsp;&nbsp;
							<input type="submit" class="submit" name="view" value="View Page">
						</form>
					<? endif; ?>
				</td>
			</tr>
			<tr>
				<td align="right" colspan="3">
					<form action="index.php?section=composemessage" method="post">
					<input type="hidden" name="from_name"		value="<?= htmlspecialchars(stripslashes($from_name)) ?>">
					<input type="hidden" name="from_email"		value="<?= htmlspecialchars(stripslashes($from_email)) ?>">
					<input type="hidden" name="to_group"		value="<?= htmlspecialchars(stripslashes($to_group)) ?>">
					<input type="hidden" name="subject"		value="<?= htmlspecialchars(stripslashes($subject)) ?>">
					<input type="hidden" name="text_message"	value="<?= htmlspecialchars(stripslashes($text_message)) ?>">
					<input type="hidden" name="html_message"	value="<?= htmlspecialchars(stripslashes($html_message)) ?>">
					<input type="hidden" name="doCheck" value="1">
					<input type="hidden" name="step" value="3">					
					<input type="submit" class="submit" name="back" value="Go Back">&nbsp;&nbsp;
					<input type="submit" class="submit" name="send" value="Send E-Mail">
				</td>
			</tr>
			</table>
			</form>		
		</td>
	</tr>
	</table>

