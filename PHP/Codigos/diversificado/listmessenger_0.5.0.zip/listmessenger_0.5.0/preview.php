<?
/*
	=============================================================
	# ListMessenger By Matt Simpson - matt@silentweb.ca            
	# Copyright � 2002 Silentweb - http://www.silentweb.ca                     
	#
	# For the most recent version, visit the ListMessenger
	# website: http://scripts.digitalorphans.org/listmessenger/
	#
	# License Information is found in docs/licence.txt              
	=============================================================
*/

	require("functions.inc.php");

	if ($view == "View Source") {
		if (($html_message) && ($html_message != "")) {
			echo "<pre>";
			echo htmlspecialchars(stripslashes($html_message));
			echo "</pre>";
		} else {
			header("Location: index.php");
		}
	} elseif ($view == "View Page") {
		if (($html_message) && ($html_message != "")) {
			echo stripslashes($html_message);
		} else {
			header("Location: index.php");
		}
	} else {
		header("Location: index.php");
	}

?>
