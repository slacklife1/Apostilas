Author : Nasarudin Abdullah
Created Date : 18-09-2002
Propose : To display date picker or pocket calendar.

How do I develop ?
I developed this date picker using PHP 4.0.

How to run ?
There are 4 files which are :
1. main.php
2. Calendar.php
3. DatePicker.php
4. kalendar.gif

Place all files in your web server.
The main.php is main file.