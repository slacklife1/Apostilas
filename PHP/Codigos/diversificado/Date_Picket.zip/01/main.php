	
<html>
<head>
<title>Example of Datepicker</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<Script Language="JavaScript">
	function showCalendar(frm,textbox){
		window.open("Calendar.php?frm=" + frm + "&txt=" + textbox,"DatePicker","width=250,height=230,status=no,resizable=no,top=200,left=200");
	}
	
	function getObject(obj){
		alert(obj.value);
	}
</Script>
</head>

<body bgcolor="#eeeeee" text="#000000">
<form name="frm">
<input type="text" name="txtCalendar">
<img src="kalendar.gif" width="28" height="24" style="cursor:hand" onclick="showCalendar('frm','txtCalendar')"> 
</form>
</body>
</html>
