 <?php
 include 'DatePicker.php';
 
 //Get form and textbox from calling paging
 $frm = $_GET['frm'];
 $txt = $_GET['txt'];
 
 ?>
<html>
<head>
<title><< Date Picker >></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<Script Language="JavaScript">
	function getSelDate(SelDate){
		var frm,txt;
		frm = '<?php print "$frm" ?>';
		txt = '<?php print "$txt" ?>';
		
		window.opener.document.forms[frm].elements[txt].value = SelDate;
		window.close();
	} 
</Script>
</head>

<body bgcolor="#999999" text="#000000">
<div align="center">
<table width="40%" border="0" bgcolor=#DCF3FC>
  <tr bgcolor=#DCF3FC> 
    <td>
      <?php $prevYear = $intYear - 1; 
      print "<a href=Calendar.php?prevYear=$prevYear&prevMonth=$intMonth&frm=$frm&txt=$txt>";
      ?>
      <div align="right">[&lt;]</div>
      </a>
    </td>
    <td>
      <div align="center"><?php print"<B>$intYear</B>"; ?></div>
    </td>
    <td>
      <?php $nextYear = $intYear + 1;
      print "<a href=Calendar.php?nextYear=$nextYear&prevMonth=$intMonth&frm=$frm&txt=$txt>";
      ?>
      <div align="left">[&gt;]</div>
      </a>
    </td>
  </tr>
</table>
</div>
<div align="center">
<table width="40%" border="0" bgcolor=#DCF3FC>
  <tr> 
    <td>
      <?php 
      $prevMonth = $intMonth - 1; 
      if ($prevMonth % 12 == 0){
      	$prevMonth = 12;
      	$intYear = $intYear - 1;
      }
      
      print "<a href=Calendar.php?prevMonth=$prevMonth&curYear=$intYear&frm=$frm&txt=$txt>";
      ?>
      <div align="right">[&lt;]</div>
      </a>
    </td>
    <td>
      <div align="center"><?php print"<b>$strLongMonth</b>" ?></div>
    </td>
    <td>
	<?php 
      $nextMonth = $intMonth + 1; 
      if ($nextMonth % 13 == 0){
      	$nextMonth = 1;
      	$intYear = $intYear + 1;
      }
	  print "<a href=Calendar.php?nextMonth=$nextMonth&curYear=$intYear&frm=$frm&txt=$txt>";
	  ?>
      <div align="left">[&gt;]</div>
      </a>
    </td>
  </tr>
</table>
</div>
<div align="center">
<table width="40%" border="0" bgcolor=ffffff>
  <tr bgcolor=#FFFFD2> 
    <td> 
      <div align="center"><b>Sun</b></div>
    </td>
    <td> 
      <div align="center"><b>Mon</b></div>
    </td>
    <td> 
      <div align="center"><b>Tue</b></div>
    </td>
    <td> 
      <div align="center"><b>Wed</b></div>
    </td>
    <td> 
      <div align="center"><b>Thu</a></div>
    </td>
    <td> 
      <div align="center"><b>Fri</b></div>
    </td>
    <td> 
      <div align="center"><b>Sat</b></div>
    </td>
  </tr>
  <?php
  for($i=0;$i<6;$i++){
  ?>
  <tr> 
  <?php
    for($j=0;$j<7;$j++){
    
  ?>
	    
    <?php if($j==0 || $j==6){
    	print "<td bgcolor=#FFFF00>";
    }else{
    	print "<td bgcolor=#FFFFD2>";
    }
    ?>
      <?php
	    	
	    	if($intAllDays >= $intStartDayOfMonth && $intDays <= $intDayInMonth){
	    $intMonth = $intMonth - 0;
	    $selDate = FormatDate($intDays,$intMonth,$intYear,"DD/MM/YYYY");	
	   ?>
	    
      <div align="center">
      	<?php if($j==0 || $j==6){ 
      		print"<a href=# onclick=getSelDate('$selDate')><font color=red>$intDays</font></a>"; 
      	}else{
      		if($selDate == $Today){
      			print"<a href=# onclick=getSelDate('$selDate')><font color=blue><B>$intDays</B></font></a>"; 
      		}else{
        		print"<a href=# onclick=getSelDate('$selDate')>$intDays</a>"; 
        	}
        }
        ?>
      </div>
	    <?php
	    $intDays = $intDays + 1;
	    }
	    ?>
	    </td>
	     
   <?php
    $intAllDays = $intAllDays + 1;
    }
   ?>
  </tr>
  <?php  
  }
  ?>
</table>

</div>
</body>
</html>
