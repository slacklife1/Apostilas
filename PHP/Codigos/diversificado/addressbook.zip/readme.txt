author: Somdutt Ganguly
email: gangulysomdutt@yahoo.com
date: may 2002

requirement: apache web server, create a dsn of somduttaddress.mdb using 32bit odbc. The name of the dsn should be 'mydsn' .. This example is tested in windows 98..since access database works with windows only so this application must be hosted in a windows supported with ms access os..also i have used php3..
(u need to configure php in windows98 using apache....and u must also configure your php.ini file before running this eg..get detail about it in php manuals..www.php.net)

description: This is an example of an address book in php....This is a full fledged eg which you can use to understand all kind's of database connectivity with php using ms access in windows environment..all the features are included...Now after learning this example you can do any kind of database related activity..thx.

about: My name is Somdutt Ganguly and I have developed this application. I am right now in TY BCA..in short, i am just waiting for my final year results..I am studying at CPICA college, Gujarat University, Ahmedabad, Gujarat...Among my favourite languages are visual basic, php, asp..and i do like flash.....apart from this i do know java, c, c++...etc..Also I do like to play cricket and walk a lot and listen to music.............anyway enjoy and do respond in the form of feedback or else.


...

INDEX.php is the opening page...
keep the folder in the root.....of the webserver and call it...and don't forget to make a dsn name mydsn for the access database

my address:
gangulysomdutt@yahoo.com

no 6, chandrodaya apt,
bhaikaka nagar,
thaltej,
ahmedabad, gujarat, india...380059
