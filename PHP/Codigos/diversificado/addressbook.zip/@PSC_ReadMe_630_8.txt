Title: addressbook full fledged
Description: This is a full fledged php application which is ready to work in windows with ms access 2000 back end...This is a good relief for php windows programming as they will learn how easy it is to make an application in php in windows98..with apache as server and ms access2000 as backend..you can add, update, search, show all records, delete all the records from the database...this is a unique example...it possesses all kinds of validations....and is good for beginners as well as advance programmers.........this is a good resource for database programming in php...do vote for my hard work..best of luck..thx.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=630&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
