<html>
<head>
<title>
put me in</title></head>
<body text='white' bgcolor='black'>
<?php 
//####################################################
//author: Somdutt Ganguly
//email: gangulysomdutt@yahoo.com
//desc: confirmation for deletion
//####################################################

//connection
$connection = odbc_connect("mydsn","","") or die("Couldn't connect to the database....sorry");

// define query
$query = "delete from informa where id=$id";

//executing query and get result
odbc_exec($connection, $query);
print "<h2>Thx..RECORD DELETED</h2>";
odbc_close($connection);
?>
<br>
<br>
<a href='index.php'>home</a>
</body>
</html>