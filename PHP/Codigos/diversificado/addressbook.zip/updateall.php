<html>
<head>
<title>
put me in</title></head>
<body text='white' bgcolor='black'>
<?php 

//####################################################
//author: Somdutt Ganguly
//email: gangulysomdutt@yahoo.com
//desc: loading in textboxes and textfield...
//####################################################

print "<h1>ADDRESS BOOK : UPDATE CONFIRMATION</h1><hr><hr>";
$counter = 0;
//connection
$connection = odbc_connect("mydsn","","") or die("Couldn't connect to the database....sorry");
settype($id,'integer');
// define query
$query = "select * from informa where id=$id";

//executing query and get result
$result = odbc_exec($connection, $query);
print("<table border=4>");

// printing the table header section
print("<tr bgcolor='blue'><td>ID</td><td>FNAME</td><td>LNAME</td><td>SEX</td><td>ADDRESS</td><td>DOB</td><td>EMAIL</td><td>PHONE</td><td>NOTE</td>");

//looping throught the result
while(odbc_fetch_row($result)) {
$counter+=1;
$id = odbc_result($result, 1);
$fname = odbc_result($result, 2);
$lname = odbc_result($result, 3);
$sex = odbc_result($result, 4);
$address = odbc_result($result, 5);
$dob = odbc_result($result, 6);
$email = odbc_result($result, 7);
$phone = odbc_result($result, 8);
$note = odbc_result($result, 9);
print "<form method='get' action='finalupdate.php'>";

//print("<tr><td>$id</td><td>$fname</td><td>$lname</td><td>$sex</td><td>$address</td><td>$dob</td><td>$email</td><td>$phone</td><td>$note</td>");

print("<tr><td>$id</td><td><input type='text' name='fname' value='$fname'></td><td><input type='text' name='lname' value='$lname'></td><td><input type='text' name='sex' value='$sex'></td><td><input type='text' name='address' value='$address'></td><td><input type='text' name='dob' value='$dob'></td><td><input type='text' name='email' value='$email'></td><td><input type='text' name='phone' value='$phone'></td><td><textarea  name='note' type='text'>$note</textarea></td>");
print "<input type='hidden' value='$id' name='id'>";


}
print("</table>");
print("<br>");
print("<p>$counter records found<br><br>");
print "<center>"; 
print "<input type='submit' value='confirm updation'>";
print "</center>";
print "</form>";
odbc_close($connection);
?>
<br>
<br>
<a href='index.php'>home</a>
</body>
</html>