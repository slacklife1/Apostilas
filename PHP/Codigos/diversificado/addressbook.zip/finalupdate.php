

<html>
<body bgcolor='black' text='white'>
<?php 

//####################################################
//author: Somdutt Ganguly
//email: gangulysomdutt@yahoo.com
//desc: This is a nice updation routine............I can't forget a fact
//in this routine...i just wasted an hour for a single update statement
//in sql...........i typed out everything correctly in the updation statement..
//but at last i discovered the error.....it was not my error it was the internal
//problem of php i.e. it just took the "note" statement as keyword...so i had
//to change the name of the field in access.....just be carefull of keywords such
//as note...
//####################################################

//connection
$connection = odbc_connect("mydsn","","") or die("Couldn't connect to the database....sorry");
settype($id,'integer');
if ($fname==""|| $lname=="" || $email=="" || $sex=="" || $address=="" || $phone=="" || $note=="" || $dob=="")
{
print "<h2> You have made an error in typing or may be datatype entered is wrong..try again!</h2>";
}
else
{

$query="update informa set fname='$fname' , lname='$lname' , sex='$sex', address='$address', phone='$phone', email='$email', dob='$dob', note1='$note' where id=$id";

odbc_exec($connection,$query);

print "<h3>THANKS A LOT FOR UPDATING RECORDS.....</h3>";
} 
odbc_close($connection);

?>
<br>
<br>
<br>
<h2>Hit the back button of the browser to move back or move to <a href='index.php'>home</a> </h2>
</body>
</html>