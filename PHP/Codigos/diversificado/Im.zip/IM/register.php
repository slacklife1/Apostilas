<?
include("style.php");
include ("mysql.php");

echo"<font face='arial' size='2'>Php Instant Messenger Registration";
echo"</center><form name=\"log\" action=\"reg.php\">";
echo"<input type=\"text\" name=\"username\" maxlength=\"20\"> Username <br>";
echo"<br><input type=\"password\" name=\"password\" maxlength=\"20\"> Password<br> ";
echo"<br><input type=\"submit\" value=\"Register\">";
echo"</form>";
echo"<div align='justify'>This is a Php Instant Messenger, it does not use an IRC layer, Java, Javascript, Active-X or any
platform dependant plugin control.The drop down list on your interface provides you other users online.</div>";
?>