<html><title><?php print $title;?></title><head></head>
<? echo"<FRAMESET frameborder=\"0\" framespacing=\"0\" border=\"0\" ROWS=\"80%*,20%\" cols=\"*\" onUnload='window.open(\"index.php?user=$username\",\"\", \"width=250,height=400\")' >" ;?>
<?php
 echo"<FRAME name=\"body\" src=\"window.php?username=$username\"  SCROLLING=\"no\" >\n";
 echo"<FRAME name=\"post\" src=\"dialog.php?username=$username\"  SCROLLING=\"no\"> \n";
 ?>
<? echo"</FRAMESET><noframes></noframes>"?>
<style type="text/css">
body {font:12px;color:#99ccff;background:#000066;text-align:center;}
tr,td,th {font:12px;color:#ffffff;background:#000000}
a:visited{color:#ff0088;text-decoration:none;}
a:link{color:#ffcc88;text-decoration:none;}
a:hover{color:#ff80c4;text-decoration:underline;}
a:active{color:#666699;text-decoration:none;}
input,textarea{border:2px #666699 solid;color:#ffcc88;background:#000066}
select{font:13px;color:#ffcc88;background:#666699; menubar-arrow-color:red}
textarea,body {scrollbar-3d-light-color:#666699;scrollbar-arrow-color:#666699;scrollbar-base-color:black;scrollbar-highlight-color:#000028;scrollbar-shadow-color:#666699;}
</style>

<body><font face="arial" size="2" >
</body>
  </html>