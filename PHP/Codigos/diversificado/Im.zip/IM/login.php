<?
include("mysql.php");
$query="select username, password from users where username=\"$username\" and password=\"$password\" and status=\"no\"";
$result= mysql_query($query, $link);
if (mysql_num_rows($result)==0)
{
print"<font face='arial' size='2'><span style=background-color:#666699><font color='#ffcc99'>&nbsp;ERROR !&nbsp;</font></span><br>";
print"<br>Invalid username - password <br><b>OR</b><br> username already in use.<br>";
print"<br><input type='button' value='Back' onclick='window.history.back()'>";
}else{
$query="update users set status='yes' where username='$username'";
$result= mysql_query($query, $link);
header("Location:IM.php?username=$username&title=$username");
}
include("style.php");
?>
<body bgcolor="000066" text="lightblue"><font face="arial">