
<?
include ("style.php");
include ("mysql.php");

//-----------------Logout script

if($user)
{
$query="update users set status=\"no\" where username=\"$user\"";
$result=mysql_query($query, $link);
$query="delete from chatdata where sender like '%$user%'or buddy like '%$user%'";
mysql_query($query, $link);
print"<center><body bgcolor=\"000066\"><span style=background-color:8080C0><font color=lightblue>&nbsp;$user you have logged out&nbsp;</span>";
exit;
}
//-----------------------------Login form

echo"Php Instant Messenger Login";
echo"<form name=\"log\" action=\"login.php\">";
echo"<input type=\"text\" name=\"username\" maxlength=\"20\"> Username <br>";
echo"<br><input type=\"password\" name=\"password\" maxlength=\"20\"> Password <br><br> ";
echo"<input type=\"submit\" value=\"Login\">";
echo"<input type=\"hidden\" name=\"login\"value=\"log\">";
echo"&nbsp;&nbsp;New Users Click<a href='register.php'><b> Here</b></a><br><br>";
echo"</form>";
echo"<div align='justify'>This is a Php Instant Messenger, it does not use an IRC layer, Java, Active-X or any
platform dependant plugin control.The drop down list on your interface provides you other users online.</div>";
?>