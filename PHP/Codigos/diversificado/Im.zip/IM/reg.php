<?php if((!$username)||(!$password))
{
print"<font face='arial' size='2'>You have submitted blank fields";
print"<br><input type='button' value='Back' onclick='window.history.back()'>";
exit;
}
include("mysql.php");
$query="select username from users where username=\"$username\"";
$result= mysql_query($query, $link);
if (mysql_num_rows($result)!=0)
{
print"<font face='arial' size='2'>Username already taken";
print"<br><input type='button' value='Back' onclick='window.history.back()'>";
}else{
$query="insert into users set username=\"$username\", password=\"$password\", status=\"yes\"";
$result= mysql_query($query, $link);
header("Location:IM.php?username=$username&title=$username");
}
include("style.php"); 
?>
