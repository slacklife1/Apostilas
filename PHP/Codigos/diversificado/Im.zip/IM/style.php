<html><title>Php Instant Messenger</title> <head></head>
<style type="text/css">
 body {font:12px;color:#99ccff;background:#000066;text-align:left;}
tr,td,th {font:12px;color:#ffffff;background:#000000}
a:visited{color:#ff0088;text-decoration:none;}
a:link{color:#ffcc88;text-decoration:none;}
a:hover{color:#ff80c4;text-decoration:underline;}
a:active{color:#666699;text-decoration:none;}
input,textarea{border:2px #666699 solid;color:#ffcc88;background:#000066}
select{font:13px;color:#ffcc88;background:#666699; menubar-arrow-color:red}
textarea,body {scrollbar-3d-light-color:#666699;scrollbar-arrow-color:#666699;scrollbar-base-color:black;scrollbar-highlight-color:#000028;scrollbar-shadow-color:#666699;}
</style><body><font face="arial" size="2" >