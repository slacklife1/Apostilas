<?
include("style.php");
include("mysql.php");
$username=$user;
print"Php Instant Messenger Buddy List<br>";
$query="select username, status from users order by username asc";
$result=mysql_query($query, $link);
$num=mysql_num_rows($result);
$query="select username, status from users where status='yes'";
$result1=mysql_query($query, $link);
$num1=mysql_num_rows($result1);
print"<b>$num</b> Registered users - <b>$num1</b> Online<br><br>";
while($row=mysql_fetch_array($result))
 {
$row[1]= eregi_replace ("yes", "<IMAGE SRC='img/coo.gif'>", $row[1]);
$row[1]= eregi_replace ("no", "<IMAGE SRC='img/ide.gif'>", $row[1]);
print" $row[0] $row[1]<br>";
 }



?>