

<script lnaguage="javascript">

var limit="0:5"
if (document.images){
var parselimit=limit.split(":")
parselimit=parselimit[0]*60+parselimit[1]*1
}
function beginrefresh(){
if (!document.images)
return
if (parselimit==1)
window.location.reload() && window.scroll(0,20000)
else{
parselimit-=1
curmin=Math.floor(parselimit/60)
cursec=parselimit%60
if (curmin!=0)
curtime=curmin+" minutes and "+cursec+" seconds left until page refresh!"
else
curtime=cursec+" seconds left until page refresh!"

setTimeout("beginrefresh()",1000)
}
}

window.onload=beginrefresh

</script>
<body ><font face="arial" size="2">
<?
include ("mysql.php");
$query="select from users where username='$username' and status='yes'";
$result=mysql_query($query, $link);
if($result!=0)
{
print"<center><body bgcolor=\"000066\"><span style=background-color:8080C0><font color=lightblue>&nbsp;$username you have logged out&nbsp;</span>";
exit;
}
else
{
$query="delete from chatdata where message ='<br>' or buddy='to <font color=blue></font>'";
mysql_query($query,$link);
$query="select sender, buddy, message from chatdata where sender = '<font color=red>$username</font>' or sender like '%$buddy%'  and   buddy ='<font color=blue>$buddy</font>' or buddy like '%$username%'  order by id desc";
$result=mysql_query($query, $link);
$num_rows=mysql_num_rows($result);
while($fresult=mysql_fetch_array($result))
{
print"$fresult[0] $fresult[1]$fresult[2]";
print"<br><br>";
}
}
?>