<?
include("mysql.php");

if($user=="$username")
{
$query="delete from chatdata where username like '%$username%'";
mysql_query($query, $link);
$query="update users set status='no' where username='$username'";
$result= mysql_query($query, $link);
header("location: index.php");
}
print$msg;
print$user;
?>