# --------------------------------------------------------
#
# Table structure for table 'chatdata'
#

CREATE TABLE chatdata (
   id int(11) NOT NULL auto_increment,
   sender varchar(255) NOT NULL,
   buddy varchar(255) NOT NULL,
   message varchar(255) NOT NULL,
   PRIMARY KEY (id)
);


# --------------------------------------------------------
#
# Table structure for table 'users'
#

CREATE TABLE users (
   username varchar(20) NOT NULL,
   password varchar(20) NOT NULL,
   status char(3),
   UNIQUE username (username)
);
