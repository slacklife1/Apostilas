<?
include("style.php");
include("mysql.php");
$buddy="$list";
$sender=$username;
$message = str_replace ( " ", " ", $message);
$message = str_replace ( "\n", " ", $message);
$message = str_replace ( "<",  " ", $message);
$message = str_replace ( ">",  " ", $message);
$message = stripslashes ($message);
$message=str_replace ( "\n", " ", $message);
$message = eregi_replace (";)", "<IMG SRC=\"img/smi.gif\">", $message);
$message = eregi_replace (':)', "<IMG SRC=\"img/sad.gif\">", $message);
$message = eregi_replace (':P', "<IMG SRC=\"img/ang.gif\">", $message);
$message = eregi_replace (';P', "<IMG SRC=\"img/win.gif\">", $message);
$message = eregi_replace (':q', "<IMG SRC=\"img/coo.gif\">", $message);
$message = eregi_replace (';q', "<IMG SRC=\"img/ide.gif\">", $message);
$message = eregi_replace (':o', "<IMG SRC=\"img/que.gif\">", $message);
$message = eregi_replace (':!', "<IMG SRC=\"img/sur.gif\">", $message);
$message = eregi_replace (':l', "<IMG SRC=\"img/tup.gif\">", $message);
$query="insert into chatdata set sender='<font color=red>$username</font>',  buddy ='to <font color=blue>$buddy</font>', message='<br>$message'";
$result=mysql_query($query, $link);
echo"<body bgcolor=\"#000066\" text=\"lightblue\" link=\"00FFCC\" vlink =\"FF6666\" alink=\"FFFFFF\" onload=\"form.message.focus()\"  ><font face=\"arial\" size=\"2\">";
echo"<center><form name='form' action='dialog.php?username=$username&buddy=$buddy&message=$message' method=\"post\">\n";
echo"<input type=\"textarea\" name=\"message\">";
echo"<input type=\"hidden\" value=\"$username\">";
echo"&nbsp;Online<img src = \"img/coo.gif\" onclick=\"window.open('online.php?user=$username','','width=250,height=400,dependant=yes scrolling=auto')\"><br>";
echo"<select size='1' name='list'>";
echo"<option value=$buddy>$buddy</option>";
$query="select username from users where status=\"yes\" and username<>\"$username\"";
$res=mysql_query($query, $link);
while($fresult=mysql_fetch_row($res))
{
foreach($fresult as $field)
print"<option value=$field>$field</option>";
}
echo"</select>";
echo"&nbsp;<input type=\"submit\"value=\"Refresh\" onclick=\"form.message.focus()\">";


echo"</form>";

?>

