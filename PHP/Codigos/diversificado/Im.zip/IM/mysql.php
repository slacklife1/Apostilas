<?
$db="";                  //------name of database

$host="localhost";      //----this is the name of your database

$dbuser="";             //----database username

$dbpass="";            //----database access password

$link=mysql_pconnect($host,$dbuser,$dbpass);

mysql_select_db($db);
?>