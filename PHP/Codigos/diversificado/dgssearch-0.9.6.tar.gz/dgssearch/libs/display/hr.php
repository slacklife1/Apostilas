<?php

/*
** DGS Search
** hr.php written by James Sella
** Copyright (c) 2000-2001 Digital Genesis Software, LLC. All Rights Reserved.
** Released under the GPL Version 2 License.
** http://www.digitalgenesis.com
*/

function hr($retVal, $q, $r, $o, $s, $timer) {
	printf("\t<DIV> <!-- Display Module: hr -->\n\t\t<HR>\n\t</DIV>\n");
	return true;
}

?>
