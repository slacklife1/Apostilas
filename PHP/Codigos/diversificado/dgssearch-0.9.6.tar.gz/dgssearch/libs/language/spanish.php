<?php

/*
** DGS Search
** spanish.php written by Jo�o Luis Correia and James Sella
** Copyright (c) 2000-2001 Digital Genesis Software, LLC. All Rights Reserved.
** Released under the GPL Version 2 License.
** http://www.digitalgenesis.com
*/

	/* Spanish Language Pack */

	$lang['header']		= 'DGS Search Resultados';
	$lang['query']			= '<B>Pesquisar:</B>';
	$lang['submit']		= 'B�squeda';
	$lang['stats']			= 'Resultados <B>@LOWERBOUND@</B>-<B>@UPPERBOUND@</B> de <B>@TOTALRESULTS@</B> para \'<B>@QUERY@</B>\'.';
   $lang['noQuery']		= '<B>No se incorpor� ninguna interrogaci�n de la b�squeda. Por favor b�squeda otra vez.</B>';
	$lang['noResults']	= 'La b�squeda para la interrogaci�n \'<B>@QUERY@</B>\' no encontr� ning�n resultado.';
	$lang['searchTime']	= 'A pesquisa demorou @SEARCHTIME@ seg.';
	$lang['resultPages']	= 'P�gina de Resultados';
	$lang['translate']	= 'Traducen';
	$lang['next']			= '[Proxima >>]';
	$lang['prev']			= '[<< Anterior]';

	/* Add error messages here. */

?>
