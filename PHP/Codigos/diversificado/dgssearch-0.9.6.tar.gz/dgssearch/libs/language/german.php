<?php

/*
** DGS Search
** german.php written by Sebastian Barbe and James Sella
** Copyright (c) 2000-2001 Digital Genesis Software, LLC. All Rights Reserved.
** Released under the GPL Version 2 License.
** http://www.digitalgenesis.com
*/

	/* German Language Pack */

	$lang['header']		= 'DGS Search Resultate';
	$lang['query']			= '<B>Abfrage:</B>';
	$lang['submit']		= 'Suchen';
	$lang['stats']			= 'Zeige Ergebnisse <B>@LOWERBOUND@</B>-<B>@UPPERBOUND@</B> von <B>@TOTALRESULTS@</B> Treffern f�r die Suche nach \'<B>@QUERY@</B>\'.';
   $lang['noQuery']		= '<B>Es wurde kein Suchbegriff eingegeben. Bitte geben Sie die W�rter ein, nach denen gesucht werden soll.</B>';
	$lang['noResults']	= 'Suche nach \'<B>@QUERY@</B>\' f�hrte zu keinen Ergebnissen.';
	$lang['searchTime']	= 'Suche dauerte @SEARCHTIME@ sek.';
	$lang['resultPages']	= 'Anzahl der Ergebnissseiten';
	$lang['translate']	= '�bersetzen';
	$lang['next']			= '[Zun�chst >>]';
	$lang['prev']			= '[<< Vorhergehend]';

	/* Add error messages here. */

?>
