<HTML> <!-- DGS Search 0.9.6 -->
<HEAD>
	<META NAME="author" CONTENT="Digital Genesis Software, LLC.">
	<META NAME="classification" CONTENT="PHP Script - Site Search Utility">
	<META NAME="description" CONTENT="DGS Search is a PHP based utility capable of filesystem and database searches on MySQL, PgSQL, MSSQL, InterBase and ODBC sources.">
	<META NAME="keywords" CONTENT="search, php, filesystem, database, mysql, pgsql, mssql, odbc, interbase, digital, genesis">
	<META NAME="generator" CONTENT="vi (Linux); The only editor">
	<TITLE>DGS Search v0.9</TITLE>
</HEAD>
<BODY BGCOLOR="ffffff">
