<?PHP
//break//";
$to1="yourname@someISP.com";
//break//";
#$to1= '$abuse';
?>
