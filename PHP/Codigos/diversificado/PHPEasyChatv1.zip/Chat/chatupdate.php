 <html>
 <!---LEAVE THIS COMMENT IF YOU USE THIS SCRIPT!!
 PHPEasyChat v.1.0
 This script is created by Robert Hughes
 staffordshire@c2i.net and is free for use for everyone.
 If You would like a copy of this script contact the webmaster of the site using this script.
 The Script is mainly based on PHP4 and mixed with JAVA it works fine.
 When you use this script you allso are responible to give this script to any one who asks
 for it.
 --->
 <head>
<SCRIPT LANUAGE="JavaScript"><!--
    window.setTimeout("location.reload()",6000)
//--></SCRIPT><NOSCRIPT><meta http-equiv="refresh" content="4"></NOSCRIPT>
</head>
<body>
<?php
$filename="go.txt";
$body=file($filename);
for ( $i = count($body) + 1; $i >= 0; --$i)
{
print ($body[$i]);
}
?>
</body>
</html>
