<html>
<!---LEAVE THIS COMMENT IF YOU USE THIS SCRIPT!!
PHPEasyChat v.1.0
This script is created by Robert Hughes
staffordshire@c2i.net and is free for use for everyone.
If You would like a copy of this script contact the webmaster of the site using this script.
The Script is mainly based on PHP4 and mixed with JAVA it works fine.
When you use this script you allso are responible to give this script to any one who asks
for it.
--->
<head>
<script language="JavaScript">
<!--
var time = null
function move() {
window.location = 'goinput.php'
}
//-->
</script>
</head>
<body onload="timer=setTimeout('move()',0)">

<?php
//Date stamp on message
  $date = (date ("d/n -H:i"));


  //Write to text
    $fp = fopen("go.txt",  "a");
    $text1 = stripslashes($text_here);
    $text = strip_tags($text1);
    fputs($fp, "<table width=\"100%\" border=\"1\" bgcolor=\"#CCCCCC\"><tr><td><img src=\"ikoner/$icon_id\" border=\"0\"><font face=\"Verdana\" Size=\"1\">&nbsp;&nbsp;$date &nbsp;</font><font face=\"Verdana\" Size=\"2\">$text</font><br></td></tr></table>\n");
  fclose($fp);

//delete file whwn it gets to big, and plase new message.
$file="go.txt";
$file_size = filesize("$file");
if ($file_size >= 4000) {
fopen("$file","w+");
fwrite($file,"");
fclose($file);
}
?>

</body>
</html>
