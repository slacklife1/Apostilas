<!---FORM FOR OUTPUT--->
<html>
<head>
<script>
<!--
function setfocus() { document.f.text_here.focus(); }
// -->
</script>
</head>
<!---LEAVE THIS COMMENT IF YOU USE THIS SCRIPT!!
PHPEasyChat v.1.0
This script is created by Robert Hughes
staffordshire@c2i.net and is free for use for everyone.
If You would like a copy of this script contact the webmaster of the site using this script.
The Script is mainly based on PHP4 and mixed with JAVA it works fine.
When you use this script you allso are responible to give this script to any one who asks
for it.
--->
<body bgcolor=#ffffff text=#000000 link=#0000cc vlink=551a8b alink=#ff0000 onLoad=setfocus()>

<FORM METHOD="POST" ACTION="gorecieve.php" name="f">

<input type="radio" name="icon_id" value="1.gif" checked><img src="ikoner/1.gif" border="0">
<input type="radio" name="icon_id" value="2.gif"><img src="ikoner/2.gif" border="0">
<input type="radio" name="icon_id" value="3.gif"><img src="ikoner/3.gif" border="0">
<input type="radio" name="icon_id" value="4.gif"><img src="ikoner/4.gif" border="0">
<input type="radio" name="icon_id" value="5.gif"><img src="ikoner/5.gif" border="0">
<input type="radio" name="icon_id" value="6.gif"><img src="ikoner/6.gif" border="0">
<input type="radio" name="icon_id" value="7.gif"><img src="ikoner/7.gif" border="0">
<input type="radio" name="icon_id" value="8.gif"><img src="ikoner/8.gif" border="0">
  <input type="text" name="text_here" value="" maxlength="50" size="30">

<INPUT TYPE="submit" NAME="submitme" VALUE="Ok">

</FORM>
</body>
</html>
