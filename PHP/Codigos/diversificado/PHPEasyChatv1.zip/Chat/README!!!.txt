PHPEasyChat v.1.0

This script is created by Robert Hughes
staffordshire@c2i.net and is free for use for everyone.
If You would like a copy of this script contact the webmaster of the site using this script.
The Script is mainly based on PHP4 and mixed with JAVA it works fine.
When you use this script you allso are responible to give this script to any one who asks
for it.


Installation:
Simply add the total directory structure as is.
------------------------------------------------
Directory for your pages/Chat/

chat.html
chatlink.html
chatupdate.php
goinput.php
gorecieve.php
go.txt

------------------------------------------------
Directory for your pages/Chat/ikoner/
1.gif
2.gif
3.gif
4.gif
5.gif
6.gif
7.gif
8.gif
------------------------------------------------
Use the chatlink.html file to open the script, 
or grab the code used and place it on your page.
------------------------------------------------
CHMOD to 777
go.txt
(all rights)
PS!
go.txt is the file where all chats are stored 
as HTML.
If the file grows big, empty it.
------------------------------------------------
CHAT AWAY!
------------------------------------------------

Credits:

Thanks for all support with making this script!

� Ploc

� www.php.net
------------------------------------------------