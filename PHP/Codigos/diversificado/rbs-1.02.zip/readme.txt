################################
RANDOM BUTTON SCRIPT (RBS) v1.02
################################

This script is perfect for any of you who have a large ammount of affilates and want easy 
management. Basicly what the script does is let you specify where the button is (url), give 
name and URL to the affilates site. You fill in the necessary field and they are added to 
the rotation. The information is stored in a MySQL database so its easy to edit. The random 
generator script (randimg.php) random selects 3 (by default, you can change this in the script) 
affilates to show and prints their buttons to the browser.

--Requirements--
PHP4, MySQL, phpMyAdmin for manual editing

--Instalation--
#1 Open randimg.php and edit the values.

#2 Upload data.sql to the MySQL database

#3 upload create.php and randimg.php. 

--Adding Affilates--
To add affilates open up create.php in the browser and fill in the field.

--Using RBS--
To use in a normal webpage use this code
========
<?php
include("randimg.php");
?>
========

Make sure you get the directory paths right.


==============
Need Support?
==============
http://www.mutate.us/support.php

Have fun.

-Kaliber
Mutate.us