<?php
if ( ! (empty($site)) && ! (empty($url)) && ! (empty($imgpath)) ) {
//Connect to Database
$dbusername = "";
$dbpassword = "";
$dbname = "";
$link = mysql_connect( "localhost", $u, $p );

if ( ! $link ) die ( "Connection Error" );

//Printing the Current Styles
mysql_select_db( $db, $link ) or die ( "Could not connect to DB" );
$aff = mysql_query( "INSERT INTO affilates(site, url, imgpath ) VALUES( '$site', '$url', '$imgpath' );
if (!$aff) {
print "Script Failure";
}
}
?>
<form action="<? print $PHP_SELF; ?>" method="POST">
<font size=2 face="Verdana">Add your site</font><br><font size=1 face="Verdana">
Site Name: <input type=text name="site" value="<? print $site; ?>"><br>
Site URL: <input type=text name="url" value="<? print $url; ?>"><br>
Image Path (88x31) <input type=text name="imgpath" value="<?print $imgpath; ?>"><br>
<b>Note: We check all sites submitted before we verify them for the presence of out own button.</b><br>
<img src="images/button.gif"><br>
(Copy and paste button)
<p>
<input type=submit value="Add site for Verification">
</form>
<br><br>
Powered by <a href="http://www.mutate.us/scripts.php">RBS v1.02</a>