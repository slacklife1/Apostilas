<?php

//Connect to Database
$dbusername = ""; // Database username
$dbpassword = ""; // Database Password
$dbname = ""; // Database Name
$dbconnection = "localhost"; //Type os connection (99% of the time its 'localhost')

// Number of buttons to display
$total = "3";

####### DO NOT EDIT BELOW THIS LINE #######
$link = mysql_connect( $dbconnection, $u, $p );

if ( ! $link ) die ( "Connection Error" );

//Printing the Current Buttons
mysql_select_db( $db, $link ) or die ( "Could not connect to DB" );
$aff = mysql_query( "SELECT * FROM affilates ORDER BY RAND() LIMIT $total" );
		while ($row = mysql_fetch_array($aff)) {
			print "<a href=\"$row[url]\" target=_blank><img src="$row[imgpath]" border=0></a>&nbsp;";
			}
?>