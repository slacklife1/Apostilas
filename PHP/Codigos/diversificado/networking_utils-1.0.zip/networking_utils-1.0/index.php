<html>
<head>
<title>Networking Utilities</title>
<link href="networking_utils.css" rel="stylesheet" type="text/css">

<SCRIPT LANGUAGE="JavaScript">
<!-- Send form data to pop-up window -->
var myHeight = 420;
var myWidth = 640;
var isResizable = true;

function createTarget(form) {
_target = form.target;
_colon = _target.indexOf(":");
if(_colon != -1) {
form.target = _target.substring(0,_colon);
form.args = _target.substring(_colon+1);
} else if(typeof(form.args)=="undefined") {
form.args = "";
}
if(form.args.indexOf("{")!=-1) {
_args = form.args.split("{");
form.args = _args[0];
for(var i = 1; i < _args.length;i++) {
_args[i] = _args[i].split("}");
form.args += eval(_args[i][0]) + _args[i][1];
   }
}
form.args = form.args.replace(/ /g,"");
_win = window.open('',form.target,form.args);
if(typeof(focus)=="function")
_win.focus();
return true;
}
//  End -->
</SCRIPT>
</head>
<body>

<form method="post" action="networking_utils.php" target="foobar:width={myWidth}, height={myHeight}, scrollbars, {(isResizable)?'noresizable':''}, nostatus" onSubmit="return createTarget(this);">
  <table width="600" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#000000">
	<tr> 
	  <td valign="top" bgcolor="#184984"><span class="pagetitle">&nbsp;&nbsp;Ping Utility</span></td>
	</tr>
	<tr> 
	  <td valign="top" bgcolor="#FFFFFF"> <table width="100%" border="0" cellspacing="0" cellpadding="1">
		  <tr> 
			<td width="165">&nbsp;Domain Name or IP Address : </td>
			<td> <input type=text class="textbox" name="webaddress" size="30" value="<?php print $REMOTE_ADDR; ?>"> 
			</td>
		  </tr>
		  <tr> 
			<td width="165">&nbsp;Number of Ping Packets to Send : </td>
			<td> <input type=text class="textbox" name="pingnum" value="5" size="2" maxlength="2"> 
			</td>
		  </tr>
		  <tr> 
			<td width="165">&nbsp;</td>
			<td>&nbsp;</td>
		  </tr>
		  <tr> 
			<td width="165">&nbsp;</td>
			<td> <input type=submit class="submit_button" value="Ping">
			  <input type="hidden" name="action" value="ping"> </td>
		  </tr>
		</table></td>
	</tr>
  </table>
</form>
<form method="post" action="networking_utils.php" target="foobar:width={myWidth}, height={myHeight}, scrollbars, {(isResizable)?'noresizable':''}, nostatus" onSubmit="return createTarget(this);">
  <table width="600" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#000000">
	<tr> 
	  <td valign="top" bgcolor="#184984"> <span class="pagetitle">&nbsp;&nbsp;Traceroute 
		Utility</span></td>
	</tr>
	<tr> 
	  <td valign="top" bgcolor="#FFFFFF"> <table width="100%" border="0" cellspacing="0" cellpadding="1">
		  <tr> 
			<td width="144">&nbsp;Domain Name or IP Address : </td>
			<td> <input type=text class="textbox" name="webaddress" size="30" value="<?php print $REMOTE_ADDR; ?>"> 
			</td>
		  </tr>
		  <tr> 
			<td width="144">&nbsp;</td>
			<td>&nbsp;</td>
		  </tr>
		  <tr> 
			<td width="144">&nbsp;</td>
			<td> <input type=submit class="submit_button" value="Traceroute">
			  <input type="hidden" name="action" value="traceroute"> 
			</td>
		  </tr>
		</table></td>
	</tr>
  </table>
</form>
<form method="post" action="networking_utils.php" target="foobar:width={myWidth}, height={myHeight}, scrollbars, {(isResizable)?'noresizable':''}, nostatus" onSubmit="return createTarget(this);">
  <table width="600" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#000000">
	<tr> 
	  <td valign="top" bgcolor="#184984"> <span class="pagetitle">&nbsp;&nbsp;NSLookup 
		Utility</span></td>
	</tr>
	<tr> 
	  <td valign="top" bgcolor="#FFFFFF"> <table width="100%" border="0" cellspacing="0" cellpadding="1">
		  <tr> 
			<td width="175">&nbsp;Host, Domain Name, or IP Address : </td>
			<td> <input type=text class="textbox" name="webaddress" size="30"> 
			</td>
		  </tr>
		  <tr> 
			<td width="175">&nbsp;</td>
			<td>&nbsp;</td>
		  </tr>
		  <tr> 
			<td width="175"><b>&nbsp;Optional Parameters</b></td>
			<td>&nbsp;</td>
		  </tr>
		  <tr> 
			<td width="175"> <p> 
			  <p> &nbsp;Type of Record : </td>
			<td> <p> 
				<select class="textbox" name="querytype">
				  <option value="A" selected>A - &lt; Address Record &gt;</option>
				  <option value="PTR">PTR - &lt; Pointer &gt;</option>
				  <option value="NS">NS - &lt; Name Server &gt;</option>
				  <option value="MX">MX - &lt; Mail Exchanger &gt;</option>
				  <option value="SOA">SOA - &lt; Start of Authority &gt;</option>
				  <option value="ANY">ANY</option>
				</select>
			</td>
		  </tr>
		  <tr> 
			<td width="175">&nbsp;Server To Query : </td>
			<td> <input type=text class="textbox" name="server" value="ns1.dis.net" size="30"> 
			</td>
		  </tr>
		  <tr> 
			<td width="175">&nbsp;</td>
			<td>&nbsp;&nbsp;Example: <i>ns1.dis.net</i> </td>
		  </tr>
		  <tr> 
			<td width="175">&nbsp;</td>
			<td>&nbsp;</td>
		  </tr>
		  <tr> 
			<td width="175">&nbsp;</td>
			<td> <input type=submit class="submit_button" value=" NSLookup">
			  <input type="hidden" name="action" value="nslookup"> </td>
		  </tr>
		</table></td>
	</tr>
  </table>
</form>
</body>
</html>
