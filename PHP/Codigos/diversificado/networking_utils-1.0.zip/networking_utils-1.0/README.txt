WHAT ARE NETWORKING UTILS?
-----------------------------------------------------
The networking utilities included with this script include a ping tool, a traceroute tool
and an nslookup tool. These are very commonly available tools, however by making them web-based, it allows you and your clients to test connectivity from a centralized location, thus helping you track down common problems on your network, or a clients network.

This software is free to use and distribute, but please, if you make any meaningful changes, please email me with the details at murdock42@hotmail.com

INSTALLATION
-----------------------------------------------------
Step 1 - Unzip the package.
Step 2 - Upload the networking_utils folder to your server.
Step 3 - Access http://www.yourdomain.com/networking_utils/ to use the script.