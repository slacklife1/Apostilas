<?php
# networking_utils.php	
# Includes a ping function, a traceroute function, and an nslookup function.
#
# Copyright (C)2001 Clint Nelissen
#
# Maintained by Clint Nelissen <murdock42@hotmail.com>
#
# For the most recent version of this package:
#
# http://www.sourcecraft.org/downloads/
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
#
# networking_utils.pl	Version 0.1	Clint Nelissen	2002/08/09 */

print "<html>\n";
print "<head>\n";
if ($action == "ping") {
	print "<title>Ping Utility</title>\n";
} else if ($action == "traceroute") {
	print "<title>Traceroute Utility</title>\n";
} else if ($action == "nslookup") {
	print "<title>NS-Lookup Utility</title>\n";
}
print "</head>\n";
print "<body>\n";

# The Ping Routine
if ($action == "ping") {
	if ($webaddress) {
  	 	#Some sanity check on number of pings
   		if ($pingnum < 1 ) {
			$pingnum=1;
 		} else if ($pingnum > 99 ) {
			$pingnum=99;
		}

		print "<b>Ping Results For : $webaddress</b><p>\n";
		print "<pre>\n";
		echo exec ("ping -c $pingnum $webaddress");
		print "</pre>\n";
	} else {
		data_entry();
	}
}

# The Traceroute Routine
else if ($action == "traceroute") {
	if ($webaddress) {
		print "<b>Traceroute Results For : $webaddress</b><p>\n";
		print "<pre>\n";
		system ("traceroute $webaddress");
		print "</pre>\n";
	} else {
		data_entry();
	}
}


# The NS-Lookup Routine
else if ($action == "nslookup") {
	if ($webaddress) {
        $nslookup = 
        print "<b>NS-Lookup Results For : $webaddress</b><p>\n";
        print "<pre>\n";
		system ("nslookup -type=$querytype $webaddress $server");
		print "</pre>\n";
	} else {
		data_entry();
	}
}

# Missing Fields
function data_entry() {
	print "<b>Error!</b>\n";
        print "You did not fill in the necessary fields!\n";
        print "<p>Use your Browsers back button to correct your mistakes.\n";
        exit;
}

print "</body>\n";
print "</html>\n";
?>

