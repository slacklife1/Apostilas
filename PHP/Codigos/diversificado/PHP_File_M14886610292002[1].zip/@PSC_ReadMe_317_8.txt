Title: PHP File Manager (Explorer)
Description: Php File Explorer is a complete .php application that allows you to browse and manage an online www file system with your favorite navigator the way you would browse a filesystem on your own computer.
A configuration file explorer.cfg can be tailored to your own settings.
Allowing you to set the root directory to the directory you wish.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=317&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
