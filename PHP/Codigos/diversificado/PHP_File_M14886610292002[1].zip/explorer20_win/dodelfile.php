<?php
/*this script unlinks a file $name*/
require("path.ini");

/*check access mode*/
require("explorer.cfg");

/* get the variable $dir*/
$dir=$_GET["dir"];
$name=$_GET["name"];

/*check path security*/
require("lib/inc/security.inc");

$allowbrowse= $AllowSelfBrowse || !strstr($dir,basename(dirname($GLOBALS["SCRIPT_FILENAME"])));

if(!$allowbrowse) {
 	print "  <div >browsing under the explorer itself is forbidden (see your administrator)</div>\n";
 	exit();
}

/*************************************************/
if(file_exists($ROOTPATH.$dir.$sp.$name) && is_writeable($ROOTPATH.$dir.$sp.$name)) {
	/*delete it*/
	if(!$IsSim)
		$rc=unlink($ROOTPATH.$dir.$sp.$name);
}
else {
	Header("Location: unreadf.php?filename=".urlencode($ROOTPATH.$dir.$sp.$name));
	exit();
}

?>
<html>
<head>
<title>File Explorer - Deleting File</title>
<link rel=stylesheet href="lib/explorer.css" type=text/css>
</head>

<body bgcolor=white>
<table border=0 width=500 cellspacing=1 cellpadding=1>
  <tr>
    <td colspan=2 class=title1>
	<img border=0 src='images/del.gif'> Deleting File<br>
	<a href="explorer.php?dir=<?php echo $dir; ?>" class=href>file explorer</a>
	<hr size=1 width=100%>
    </td>
  </tr>
  <tr>
    <td class=bdyResult1 align=justify>File <?php print $ROOTPATH.$dir.$sp.$name ?> has been processed <?php
if($IsSim) { echo "(simulation)"; }
elseif(!$rc) { echo "(failed)"; }
else { echo "(success)"; } ?>
    </td>
  </tr>
</table>
<hr size=1 width=500 align=left>
<a href="explorer.php?dir=<?php echo $dir; ?>" class=href>file explorer</a>

</body>
</html>



