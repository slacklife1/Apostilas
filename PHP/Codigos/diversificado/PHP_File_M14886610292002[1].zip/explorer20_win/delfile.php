<?php
require("path.ini");

/* get the variable $dir & name*/
$dir=$_GET["dir"];
$name=$_GET["name"];

/*check path security*/
require("lib/inc/security.inc");

if(!file_exists($ROOTPATH.$dir.$sp.$name)) {
	Header("Location: unreadf.php?filename=".$dir.$sp.$name);
	exit;
}
?>
<html>

<head>
<title>File Explorer - Confirm the deletion</title>
<link rel=stylesheet href="lib/explorer.css" type="text/css">

<script language=JavaScript>
<!--
function go(url) {
/*redirect to url*/
window.location.href=url;
}
//-->
</script>
</head>

<body bgcolor=white>
<table border=0 width=500 cellspacing=1 cellpadding=1>
<form name=myForm>
  <tr>
    <td colspan=2 class=title1 >
	<img src="images/del.gif" border=0>
	Confirm the removal of <?php print $dir.$sp.$name ?>
	<br>
	<a href="explorer.php?dir=<?php print $dir.$sp.$name; ?>" class=href>file explorer</a>
	<hr size=1 width=100%>
    </td>
  </tr>
  <tr>
    <td colspan=2 class=bdyForm>Are you sure you want to remove the file <?php print $dir.$sp.$name ?>?</td>
  </tr>
  <tr>
    <td align=left class=bdyForm>
	<input type=button class=combtn name="cmdNo" value="  No  " onClick="go('explorer.php?dir=<?php print $dir; ?>')">
    </td>
    <td align=right class=bdyForm>
	<input type=button class=combtn value=" Yes " onclick="go('dodelfile.php?<?php print "dir=$dir&name=$name" ;?>')" >
    </td>
  </tr>
</form>
</table>

<hr size=1 align=left width=500>
<a href="explorer.php?dir=<?php print $dir; ?>" class=href>file Explorer</a>

<script language=JavaScript>
<!--
document.myForm.cmdNo.focus();
//-->
</script>
</body>

</html>


