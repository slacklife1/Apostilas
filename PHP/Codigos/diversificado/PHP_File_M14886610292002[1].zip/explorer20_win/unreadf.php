<html>

<head>
<title>File Explorer - Read error</title>
<link rel=stylesheet href="lib/explorer.css" type="text/css">
</head>

<body bgcolor=white>
<table border=0 cellspacing=1 width=400>
  <tr>
    <td class=error>
    	<img src='images/critical.gif' border=0>
	<?php
	if($dir!="") {
		print "The directory: $dir does not exist.<br>\n";
	}
	else {
		print "The file you requested ($filename) couldn't be read.<br>\n";
	}
	?>
    </td>
  </tr>	
</table>

<!-- Close button block -->
<hr size=1 width=400 align=left>
<table border=0 width=400>
  <tr>
    <td align=right>
	<form>
	<input type=button class=combtn value="Close" onClick="javascript:window.close()">
	</form>
    </td>
  </tr>
</table>

</body>

</html>

