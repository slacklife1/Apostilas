<?php
require("path.ini");

/* get the variable $dir & name*/
$dir=$_GET["dir"];

/*check path security*/
require("../lib/inc/security.inc");
?>
<html>

<head>
<title>File Explorer - More Options</title>
<link rel=stylesheet href="../lib/explorer.css" type="text/css">

<script language=JavaScript>
<!--
function chklocalname(entry) {

   if (entry == "") {
	return false;
   }
   return true;
}

function chkname(entry) {

   if (entry.charAt(0) != "/") {
	return false;
   }

   for(var i = 0; i < entry.length; i++){
       if (entry.charAt(i) == " ") {
   	return false;
       }
   }
   return true;
}

function chkdir(entry) {

   if (entry.charAt(0) != "/" || form.dir.value.charAt(entry.lenght) == "/") {
	return error("'DIR NAME'");
   }
}

function chkAll(form) {
   	if(chklocalname(form.localname.value)!=true) {
   		return error("'LOCAL NAME'");
   	}

   	if(chkname(form.name.value)!=true) {
   		return error("'REMOTE NAME'");
   	}
   return true;
}

function error(field) {
       alert("Error: Field " + field + " is not valid,\n it must begin with a slash (/)");
       return false;
}

function clearDest(aForm) {
	aForm.name.value="";
	return true;
}

function clearMkdir(aForm) {
	aForm.dir.value="";
	return true;
}
//-->
</script>
</head>

<body bgcolor=white>

<div class=title1>More Options</div>

<!-- Copy local to remote block -->
<hr size=1 width=400 align=left>
<form action="../expl2save.php" method=POST enctype="multipart/form-data">
<table border=0 width=400>
  <tr><td class=comment align=left>
	<img src="../images/filexfer.gif" border=0>
	copy a local file to the server</td></tr>
  <tr>
    <td class=bdyMenu align=left>source <input type=file size=32 style="height:14pt;font-family:arial; border: 1 solid #0034F7;" name="localname" value="Browse...">
    </td>
  </tr>
  <tr>
    <td class=bdyMenu>destination <input type=text size=32 style="height:14pt;font-family:arial;font-size:9pt; border: 1 solid #0034F7;" onFocus='clearDest(document.forms[0])' name="name" value="<?php echo $dir.$sp."[filename...]" ?>">
	<input type=submit class=combtn value="Save" onClick="return chkAll(document.forms[0]);">
    </td>
  </tr>
</form>
</table>


<!-- Make dir block -->
<hr size=1 width=400 align=left>
<table border=0 width=400>
<form action="../mkdir.php" method=POST enctype="multipart/form-data">
  <tr><td class=comment align=left><img src="../images/hddop.gif" border=0>&nbsp;Make directory</td></tr>
  <tr>
    <td class=bdyMenu align=left>name
	<input type=text size=32 name="dir" style="height:14pt;font-family:arial;font-size:9pt; border: 1 solid #0034F7;" onFocus='clearMkdir(document.forms[1])' value="<?php echo $dir.$sp."[directory...]"; ?>">
	<input type=submit class=combtn value="mkdir" onClick="return chkdir(document.forms[1].dir.value);">
    </td>
  </tr>
</form>
</table>

<!-- Remove dir block -->
<hr size=1 width=400 align=left>
<table border=0 width=400>
<form action="../rmdir.php" method=POST enctype="multipart/form-data">
  <tr><td class=comment align=left>
	<img src="../images/hddop.gif" border=0>
	Remove directory</td></tr>
  <tr>
    <td class=bdyMenu align=left>name
	<input type=text size=32 name="dir" style="height:14pt;font-family:arial;font-size:9pt; border: 1 solid #0034F7;" value=''>
	<input type=submit class=combtn value="rmdir" onClick="return chkdir(document.forms[2].dir.value);">
    </td>
  </tr>
</form>
</table>

<!-- Close button block -->
<hr size=1 width=400 align=left>
<table border=0 width=400>
  <tr>
    <td align=right>
	<form>
	<input type=button class=combtn value="Close" onclick="javascript:window.close()">
	</form>
    </td>
  </tr>
</table>

<script language=JavaScript>
<!--
document.forms[0].localname.focus();
//-->
</script>
</body>
</html>