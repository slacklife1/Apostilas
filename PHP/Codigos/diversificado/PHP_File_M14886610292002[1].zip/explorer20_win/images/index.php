<?php
Header("Location: ../explorer.php");
?>
