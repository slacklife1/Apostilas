<?php
/*this script writes a file $filename
whose content is $content*/
require("path.ini");

/*check access mode*/
require("explorer.cfg");

/* get the variable $dir*/
$filename=$_POST["filename"];

/*check path security*/
require("lib/inc/security.inc");

$allowbrowse= $AllowSelfBrowse || !strstr($filename,basename(dirname($GLOBALS["SCRIPT_FILENAME"])));

if(!$allowbrowse) {
	print "saving under the explorer itself is forbidden (see your administrator)\n";
	exit();
}
  
/*************************************************/
if($filename=="")
        Header("Location: unreadf.php?filename=$filename");

if(file_exists($filename) && is_writeable($filename) && !$IsSim) {
	/*prepare file*/
	$content=str_replace(chr(92).chr(34),chr(34),$content);
	$content=str_replace(chr(92).chr(39),chr(39),$content);
	$content=str_replace(chr(92).chr(92),chr(92),$content);
	
	/*open it*/
	$fp=fopen($filename,"wb");
	/*write it*/
	$rc=fwrite($fp,$content,strlen($content));
	/*chmod it to rw-r--r--*/
	chmod($filename,0644);
	/*close it*/
	fclose($fp);
}
	
?>
<html>
<head>
<title>File Explorer - File writing</title>
<link rel=stylesheet href="lib/explorer.css" type=text/css>
</head>

<body bgcolor=white>
<table border=0 width=400 cellspacing=1 cellpadding=1>
  <tr>
    <td colspan=2 class=title1 >
	<img border=0 src='images/disk.gif'> File writing
	<br>
	<a href="explorer.php?dir=<?php echo str_replace($ROOTPATH,"",dirname($filename)); ?>" class=href>file explorer</a><br>
	<hr size=1 width=100%>
    </td>
  </tr>
  <tr>
    <td class=bdyResult1>The file <?php print $filename ?> has been processed,<br><?php if($IsSim) echo "(simulation)"; else echo '('.(int)$rc.' bytes written)'; ?>
    </td>
  </tr>
</table>
<br>

<hr size=1 align=left width=400>
<a href="explorer.php?dir=<?php echo str_replace($ROOTPATH,"",dirname($filename)); ?>" class=href>file explorer</a>

</body>
</html>
