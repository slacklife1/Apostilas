<?php
/*This scripts echoes the content of a server file
whose name is passed in argument to a textarea
so that it can be viewed or edited.

a client file content can also be passed as $content,
in this case, $dir and $name are overridden

arguments:
- $dir is the relative directory where the server file is
- $name is the name of the server file
- $content is the content of a client file
*/
require("path.ini");

/* get the variable $dir & name*/
$dir=$_GET["dir"];
$name=$_GET["name"];

/*check path security*/
require("lib/inc/security.inc");

$filename=$ROOTPATH."$dir$sp$name";

if(!file_exists($filename)) {
	Header("Location: unreadf.php?filename=".$filename);
	exit;
}

$allowbrowse= $AllowSelfBrowse || !strstr($dir,basename(dirname($GLOBALS["SCRIPT_FILENAME"])));
?>
<html>
<head>
<meta HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=ISO-8859-1">
<title>File Explorer - Edit a file</title>
<link rel=stylesheet href="lib/explorer.css" type="text/css">
</head>

<body bgcolor=white>

<table border=0 cellspacing=1 cellpadding=1>
  <tr>
    <td colspan=2 class=title1 >
    <img border=0 src="images/edit.gif"> File editing
	<br>
	<a href="explorer.php?dir=<?php echo $dir; ?>" class=href>file explorer</a>
	<hr size=1 width=100%>
    </td>
  </tr>
  
  <?php
  if(!$allowbrowse) {
 	print "  <tr><td class=error colspan=2>browsing under the explorer itself is forbidden (see your administrator)</td></tr>\n";
 	print "</table>\n</body></html>\n";
 	exit();
  }
  ?>
  
  <tr>
    <td class=bdyForm>

	File <?php print $filename; ?>
    </td>
  </tr>
  <tr>
    <td class=bdyForm>
	<form method=POST action="save.php">
	<?php echo "<input type=hidden name=filename value='$filename'>\n"; ?>
	<textarea name=content cols=128 rows=30 style="font-family:arial; font-size:9pt; color=#000000; border:1 solid #000000; background-color=#EFEF00"><?php
if($content != "") echo urldecode($content);
else {
	if(file_exists($filename)) {
		$fd=fopen($filename,"rb");
		$cts=fread($fd,filesize($filename));
		fclose($fd);
		/*prepare file*/
		$cts=str_replace(chr(92).chr(34),chr(34),$cts);
		$cts=str_replace(chr(92).chr(39),chr(39),$cts);
		$cts=str_replace(chr(92).chr(92),chr(92),$cts);
		echo htmlspecialchars($cts);
	}
}
?></textarea>
    </td>
  </tr>
  <tr>
    <td class=bdyForm align=right>
	<input type=submit class=combtn value='Save'>
    </td>
  </tr>
</form>
</table>

<hr size=1 width=665 align=left>
<a href="explorer.php?dir=<?php echo $dir; ?>" class=href>file explorer</a>
</body>
</html>
