<?php
/*This script copies a file sent
by a form to a file on the server*/
require("path.ini");
require("explorer.cfg");

/* get the variable $localname name*/
$name=$_POST["name"];

/*check path security*/
require("lib/inc/security.inc");
$allowbrowse= $AllowSelfBrowse || !strstr($name,basename(dirname($GLOBALS["SCRIPT_FILENAME"])));

if(!is_dir($ROOTPATH.dirname($name))) Header("Location: unreadf.php?dir=".urlencode($ROOTPATH.dirname($name)));

if(!$allowbrowse) {
 	print "  <div >action under the explorer itself is forbidden (see your administrator)</div>\n";
 	exit();
}

if(!empty($localname) && $localname != "none" && $IsSim==false) {
    $rc=copy($localname,$ROOTPATH.$name);
    unlink($localname);
}
else {
	if($IsSim==false) die("<font color=red>Error: couldn't copy $localname: non valid file.</font>");
}
?>
<html>
<head>
<title>File Explorer - File writing</title>
<link rel=stylesheet href="lib/explorer.css" type=text/css>
<script language=JavaScript>
<!--
function exitWin() {
 	window.close();
}
//-->
</script>
</head>

<body bgcolor=white>
<table border=0 width=400 cellspacing=1 cellpadding=1>
  <tr>
    <td colspan=2 class=title1 >
	<img border=0 src='images/disk.gif'>
	File writing
	<hr size=1 width=100%>
    </td>
  </tr>
  <tr>
    <td class=bdyResult1>The file <?php print $name ?> has been processed <?php if($IsSim!=0) echo '(simulation)'; if($rc) echo '(success)'; else echo '(failed)'; ?></td>
  </tr>
</table>
<hr align=left size=1 width=400>

<div align=right>
<form>
<input type=button class=combtn value="Close" onclick='exitWin()'>
</form>
</div>

</body>
</html>
