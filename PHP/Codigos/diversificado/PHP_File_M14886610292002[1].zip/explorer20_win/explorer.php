<?php
/*This is the main file of the PHP File Explorer Project

Given a directory $dir, it scans it and displays its contents
on a per-line basis.

A matching icon is shown, and more details are shown if the directive
IsShowDetails is set to true in the explorer.cfg file

The Delte button and the Edit button are set according to the directive
$IsShowDelete and the editability of the file.

(c) 2000-2002 Crow & Co.
*/
require("path.ini");

define("SHOW_EDIT",1);
define("HIDE_EDIT",0);

/*check access mode*/
require("explorer.cfg");

/* get the variable $dir*/
$dir=$_GET["dir"];

/*check path security*/
require("lib/inc/security.inc");

$allowbrowse= $AllowSelfBrowse || !strstr($dir,basename(dirname($GLOBALS["SCRIPT_FILENAME"])));

if($IsCheckAccess) { 
	include("access.php");
}

/*Load the mime type file*/
require("lib/inc/mime.inc");

/*************************************************/
function GetFileInfo($f) {
/*this function feeds a structure $s with file info:
permission, owner, group, size, mtime from filename $f
*/
$s = array (	'perm'  => '',
		'humanperm' => '',	//human readable permissions: rwxrwxrwx
		'ux'    => false,	//is this file is user executable ?
		'islnk' => false,	//is this file is a link ?
		'owner'  => '',
		'group'  => '',
		'size'   => 0,
		'mtime'  => ''
		);
$mystat=stat($f);

//permissions (restrict to the last 9 bit)
$s["perm"]=$mystat[2] & 511;

/*u+x permission for owner ( 101000000 (=320) is r-x******)
we first have to filter with 512-1 to substract 16384 from the permissions
returned by fileperms()
*/
if(($s["perm"] & 320) == 320) $s['ux']=true;

/*convert the permissions to human readable perms*/
$fullperms=256; // rwxrwxrwx
$s["humanperm"]="";
$let = array('r','x','w'); //no, it's not rwx, but rxw, because browsed backwards

for($i=9;$i>0;$i--) { 
	($s["perm"] & $fullperms)? $s["humanperm"].=$let[$i % 3]:$s["humanperm"].="-";
	$fullperms = $fullperms >> 1;
}

//is it a link?
if(!strcmp(filetype($f),"link")) $s['islnk']=true;

//owner
$s["owner"]=$mystat[4];

//group
$s["group"]=$mystat[5];

//size in b
$s["size"]=$mystat[7];

//last modification date
$s["mtime"]=date('Y M d H:s',$mystat[10]);

return($s);
}
/*
/*************************************************/
?>
<html>

<head>
<title>File Explorer - Tropicalm Admin</title>
<link rel=stylesheet href="lib/explorer.css" type="text/css">
<script language=JavaScript src="lib/more.js"></script>
</head>

<body bgcolor=white>

<table border=0 cellspacing=3 width=700>
  <tr>
    <td colspan=2>
	<div class=title1>
	<img src="images/explorer.gif" border=0>
	File Explorer</div>
	<br>
	<a href="/admin/" class=href>Admin Tools</a>
	<hr size=1>
    </td>
  </tr>
</table>
<?php
/*if path exists, open it!*/
$hDir=opendir($ROOTPATH.$dir);

/*output the current path*/
print "<div class=title2>\n";

if($allowbrowse) {
	print "Contents of ".$dir;
	if(strcmp($dir,'/')) print "/";
}
print "</div>\n";

/*browse dir*/
$j=0;
$frmid=0;

//browse all the dirs + files of the current folder
//prepare the exceptions (file to hide)
if(strlen($Exceptions)>0) $except=explode(",",$Exceptions);

while ($file=readdir($hDir)) {
	$res=true;
	if(strlen($Exceptions)>0) {
		reset($except);
		for($i=0;$i<count($except);$i++) {
			if(!strcmp($file,$except[$i])) {
				$res=false;
				break;
			}
		}
	}
	//is the file to be displayed
	if($res) {
		$files[$j++]=$file;
	}
} /*end while*/

/*updir link*/
if($allowbrowse) {
	if(strcmp($dir,"/")) 	{
		$updir=dirname($dir);
		$updir=str_replace("\\","/",$updir);
		
		if($updir=="")
			$updir="/";
	
		print "<div class=normal><a href='explorer.php?dir=$updir'><img src='images/updir.gif' border=0 alt='updir' width=16 height=16></a></div>\n";
	}

	/*sort files if some*/
	if(count($files)) {
		sort($files);
		reset($files);
	
		/*format contents of dir into a table*/
		
		
		print "<table border=0 width=";
		($IsShowDetails)? print "700" : print "288";
		print " class=normal>\n";
	
		/*print headers*/
		print "  <tr>\n";
		print "    <td class=bdyResult0 width=240><b>name</b></td>\n";
		
		//show details ?
		if($IsShowDetails) {
			print "    <td class=bdyResult0 width=60 height=10 align=right><b>mode</b></td>\n";
			print "    <td class=bdyResult0 width=50 height=15 align=center><b>owner</b></td>\n";
			print "    <td class=bdyResult0 width=50 height=15 align=center><b>group</b></td>\n";
			print "    <td class=bdyResult0 width=30 height=10 align=center><b>size</b></td>\n";
			print "    <td class=bdyResult0 width=120 height=10 align=left><b>last modified</b></td>\n";
		}
		
		print "    <td class=bdyResult0 width=48 colspan=3 height=10>&nbsp;</td>\n";
		print "  </tr>\n";
	
		//number of items
		$i=0;
		while (list($key,$name) = each($files)) {
			
			//what kind of class do we have for this line #i
			$class= "bdyResult".($i%2);
			
			$filename=$ROOTPATH."$dir$sp$name";
			$rc=chkfile($name,&$icon);
	
			//is the current file is a directory ?
			if(is_dir($filename)) {
				$filestats=GetFileInfo($filename);
	
				/*if the dir has not the u+x permission or the dir is explorer, notice it*/
				if(!$filestats['ux'] || !$AllowSelfBrowse && !strcmp($name,basename(dirname($GLOBALS["SCRIPT_FILENAME"]))) ) {
					// display name
					print "  <tr>\n";
					print "    <td class=$class width=240>\n";
					print "\t<img border=0 src='images/icon_nodir.gif' alt='[private dir]' width=16 height=16>&nbsp;$name\n";
					print "    </td>\n";
				}
				else {
					// display name
					print "  <tr>\n";
					print "    <td class=$class width=240>\n";

					$href="explorer.php?dir=$dir$sp$name";
					print "\t<a href=\"".$href."\"><img border=0 width=16 height=16 ";
					if($filestats['islnk'])
						print "src='images/icon_dirlnk.gif' alt='[dir link]'></a>";
					else
						print "src='images/icon_dir.gif' alt='[dir]'></a>";
						
					print "&nbsp;<a href=\"".$href."\">$name</a>\n";
					print "    </td>\n";
				}		
	
				//show details ?
				if($IsShowDetails) {
					//display permissions
					print "    <td class=$class width=60 height=10 align=right>";
					print $filestats["humanperm"];
					print "</td>\n";
		
					//display owner's name
					print "    <td class=$class width=50 height=15 align=center>";
					print $filestats["owner"];
					print "</td>\n";
		
					//display group's name
					print "    <td class=$class width=50 height=15 align=center>";
					print $filestats["group"];
					print "</td>\n";			
		
					//padding for unused size field
					print "    <td class=$class width=30 height=10 align=right>&nbsp;</td>\n";
					
					//display last modification date
					print "    <td class=$class colspan=4 width=168 height=10 align=left>";
					print $filestats["mtime"];
					print "</td>\n";
					print "  </tr>\n";			
					
					$i++;
				}
			}
		}
		
		reset($files);
		while (list($key,$name) = each($files)) {
		
			$rc=chkfile($name,&$icon);
				
			/*the output format is:
			<permissions> <owner> <group> <size> <last modified time> <name>*/
			$filename=$ROOTPATH."$dir$sp$name";
			$href=$ROOTURL."$dir$sp$name";
	
			if(!is_dir($filename)) {
	
				//what kind of class do we have for this line #i
				$class= "bdyResult".($i%2);
	
				$filestats=GetFileInfo($filename);
				
				print "  <tr>\n";
				print "    <td class=$class width=240 height=10 valign=middle>\n";
				print "\t<a href=\"".$href."\"><img border=0 src='$icon' alt='[file]' width=16 height=16></a>";
				print "&nbsp;<a href=\"".$href."\">$name</a>\n";
				print "    </td>\n";
	
				//show details ?
				if($IsShowDetails) {			
					//display permissions
					print "    <td class=$class width=60 height=10 align=right>";
					print $filestats["humanperm"];
					print "</td>\n";
		
					//display owner's name
					print "    <td class=$class width=50 height=15 align=center>";
					print $filestats["owner"];
					print "</td>\n";
		
					//display group's name
					print "    <td class=$class width=50 height=15 align=center>";
					print $filestats["group"];
					print "</td>\n";
								
					//display file size
					print "    <td class=$class width=30 height=10 align=center>";
					$s=$filestats["size"];
					$unit="b";
					if($s >= 1024) { 
						$s=floor(round($s/1024));
						$unit="kb";
					}
					if($s>=1024*1024) {
						$s=floor(round($s/1048576));
						$unit="Mb";
					}
					print $s.$unit;
					print "</td>\n";
		
					//display last modification date
					print "    <td class=$class width=120 height=10 align=left>";
					print $filestats["mtime"];
					print "</td>\n";
				}
				
				/*if the file is a known text file, allow edit and delete (based on explorer.cfg)*/
				if($rc) {
					print "    <td class=$class valign=middle width=16>\n";
					print "\t<a href='edit.php?dir=$dir&name=$name'><img src='images/edit.gif' border=0 alt='edit'></a>\n";
					print "    </td>\n";
				}	
				else {
					print "    <td class=$class width=16>&nbsp;</td>\n";
				}
	
				if($IsShowDelete) {
					print "    <td class=$class valign=middle width=16>\n";
					print "\t<a href='delfile.php?dir=$dir&name=$name'><img src='images/del.gif' border=0 alt='delete' width=16 height=16></a>\n";
					print "    </td>\n";
				}
				else {
					print "    <td class=$class width=16>&nbsp;</td>\n";
				}
	
				/*Allow send*/
				print "    <td class=$class valign=middle width=16>\n";
				print "\t<a href='send.php?filename=$dir$sp$name'><img src='images/xfer.gif' alt='send' border=0 width=16 height=16></a>\n";
				print "\t    </td>\n";
				print "  </tr>\n";
			$i++;
			}
		} //end of while
		
	print "</table>\n\n";
	
	//print number of items in this directory
	$msg=$i." item";
	if($i>1) $msg.="s";
	print "<div class=comment>$msg.</div>\n";
	
	} //end of if(count($files))
	
	else {
		print "<br><div class=normal>[Empty]</div>\n";
	}
	
	print "<div class=normal><p><a href=\"javascript:shwMoreOpt('moreopt.php?dir=$dir',430,330,0)\"> More options...</a></p></div>\n";
	
} //endif allowbrowse
else {
	if(! $pass++) {
	print "  <div class=error>browsing under the explorer itself is forbidden (see your administrator)</div>\n";
	}
}

?>


<hr size=1 width=700 align=left>
<a href="/admin/" class=href>Admin Tools</a>

</body>
</html>
