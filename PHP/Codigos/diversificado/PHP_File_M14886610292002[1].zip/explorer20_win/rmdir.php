<?php
@set_time_limit(10);
require("path.ini");

/*this script attempts to remove a
directory dir*/

/*check access mode*/
require("explorer.cfg");

/* get the variable $dir*/
$dir=$_GET["dir"];

/*check path security*/
require("lib/inc/security.inc");

$allowbrowse= $AllowSelfBrowse || !strstr($dir,basename(dirname($GLOBALS["SCRIPT_FILENAME"])));

if(!$allowbrowse) {
 	print "removing from the explorer itself is forbidden (see your administrator)\n";
 	exit();
}
/*************************************************/
if($dir=="")
        Header("Location: unreadf.php?dir=$dir");

if($IsSim!=0) {
	$msg="simulation";
}
else {
	$msg="success";
	if(@!rmdir($ROOTPATH.$dir)) {
		$msg="failed";
	}
}
?>
<html>
<head>
<title>File Explorer - Remove Directory</title>
<link rel=stylesheet href="lib/explorer.css" type=text/css>

<script language=JavaScript>
<!--
function exitWin() {
 	window.close();
}
//-->
</script>
</head>

<body bgcolor=white>
<table border=0 width=400 cellspacing=1 cellpadding=1>
  <tr>
    <td colspan=2 class=title1 >
	<img border=0 src="images/del.gif"> Remove Directory
	<hr size=1 width=100%>
    </td>
  </tr>
  <tr>
    <td class=bdyResult1>Directory removal <?php print "$ROOTPATH.$dir" ?> has been processed <?php echo "($msg)"; ?>
  </tr>
  <tr>
    <td align=right>
	<hr align=left size=1 width=400>
	<form>
	<input type=button class=combtn value="Close" onclick='exitWin()'>
	</form>
    </td>
  </tr>
</table>

</body>
</html>

