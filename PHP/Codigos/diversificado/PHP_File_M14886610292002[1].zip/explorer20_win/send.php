<?php
/*This script sends to the client
the content of a server file filename*/
require("path.ini");

@set_time_limit(600);
$crlf="\n";

/* get the variable $dir*/
$filename=$_GET["filename"];

/*check path security*/
require("lib/inc/security.inc");

if(!file_exists("$ROOTPATH/$filename")) {
	Header("Location: unreadf.php?filename="."$ROOTPATH/$filename");
	exit;
}

/*check access mode*/
require("explorer.cfg");

$allowbrowse= $AllowSelfBrowse || !strstr($filename,basename(dirname($GLOBALS["SCRIPT_FILENAME"])));

 if(!$allowbrowse) {
 	print "sending a file from the explorer itself is forbidden (see your administrator)\n";
 	exit();
  }
 
/*prepare file*/
/*replace \\n or \\t with \n or \t*/
$content=str_replace(chr(92).chr(92)."n",chr(92)."n",$content);
$content=str_replace(chr(92).chr(92)."t",chr(92)."t",$content);

$content=str_replace("\\'","'",$content);
$content=str_replace('\\"','"',$content);
$content=str_replace(chr(92).chr(92),chr(92),$content);

header("Content-disposition: filename=".str_replace("/",'_',$filename).".src");
header("Content-type: application/octet-stream");
header("Pragma: no-cache");
header("Expires: 0");
// doing some DOS-CRLF magic...
$client=getenv("HTTP_USER_AGENT");
if (ereg('[^(]*\((.*)\)[^)]*',$client,$regs)) {
	$os = $regs[1];
        // this looks better under WinX
        if (eregi("Win",$os)) $crlf="\r\n";
}
/*read the file*/
readfile($ROOTPATH.$filename);
echo "$crlf";

exit();
?>

