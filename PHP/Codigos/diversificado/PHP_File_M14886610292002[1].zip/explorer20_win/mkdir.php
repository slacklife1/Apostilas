<?php
@set_time_limit(10);
require("path.ini");

/*this script attempts to create a
directory dir*/

/*check access mode*/
require("explorer.cfg");

/* get the variable $dir*/
$dir=$_POST["dir"];

/*check path security*/
$dir=str_replace("..","",$dir);
$dir=str_replace("//","/",$dir);

$allowbrowse= $AllowSelfBrowse || !strstr($dir,basename(dirname($GLOBALS["SCRIPT_FILENAME"])));

if(!$allowbrowse) {
	print "creating under the explorer itself is forbidden (see your administrator)\n";
	exit();
}

/*************************************************/
if($dir=="")
        Header("Location: unreadf.php?dir=$dir");

if(is_dir($ROOTPATH.$dir)) {
	$msg="failed: directory $dir already exists";
}
else {
	if($IsSim!=0) {
		$msg="simulation";
	}
	else {
		$msg="success";
		if(@!mkdir($ROOTPATH.$dir,0755)) {
			$msg="failed";
		}
	}
}
?>
<html>
<head>
<title>File Explorer - Make Directory</title>
<link rel=stylesheet href="lib/explorer.css" type=text/css>

<script language=JavaScript>
<!--
function exitWin() {
 	window.close();
}
//-->
</script>
</head>

<body bgcolor=white>
<table border=0 width=400 cellspacing=1 cellpadding=1>
  <tr>
    <td colspan=2 class=title1 >
	<img border=0 src='images/disk.gif'> Make Directory
	<hr size=1 width=100%>
    </td>
  </tr>
  <tr>
    <td class=bdyResult1>Directory writing <?php print $ROOTPATH.$dir ?> has been processed <?php echo "($msg)"; ?>
  </tr>
  <tr>
    <td align=right>
	<hr align=left size=1 width=400>
	<form>
	<input type=button class=combtn value="Close" onclick='exitWin()'>
	</form>
    </td>
  </tr>
</table>

</body>
</html>

