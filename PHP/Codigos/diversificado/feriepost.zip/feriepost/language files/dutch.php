<?php
#####################################################################
# Dutch translation by Martin Klerx <mklerx@eid.nl>.
#####################################################################

#################################################
# The error page
#################################################

$s_error =              "Er is een fout opgetreden:";
$s_back =               "Terug";
$s_cannotConnect =      "Verbinding met server $server op poort $port mislukt.";
$s_wrongPassword =      "Onjuiste combinatie van gebruikersnaam en wachtwoord.";


#################################################
# The logout page
#################################################

$s_loggedOut =          "U bent nu uitgelogd";
$s_reenter =            "Klik <a href=\"$PHP_SELF\">hier</a> om opnieuw in te loggen.";



#################################################
# The login page
#################################################

$s_server =             "Server:";
$s_port =               "Poort:";
$s_user =               "Gebruikersnaam:";
$s_password =           "Wachtwoord:";
$s_submit =             "OK";
$s_cookies =            "LET OP: cookies moeten aanstaan";



#################################################
# The message list
#################################################

$s_noEmails =           "Er zijn geen nieuwe berichten.";
$s_selectAll =          "Alles selecteren";
$s_deselectAll =        "Niets selecteren";
$s_delete =             "Verwijderen";
$s_subject =            "Onderwerp";
$s_from =               "Afzender";
$s_date =               "Datum";
$s_size =               "Grootte";
$s_kb =                 "Kb";
$s_messagesDeleted =    "De berichten zijn verwijderd";
$s_ok =                 "OK";

# The decimal delimiter. In some countries it is
# a comma, in other countries it is a period:
$s_decimalDelimiter =   ",";



#################################################
# Message information
#################################################

$s_mSubject =           "Onderwerp:";
$s_mFrom =              "Afzender:";
$s_mTo =                "Geadresseerde:";
$s_mDate =              "Datum:";
$s_mMailer =            "Mail programma:";
$s_reply =              "Beantwoorden";
$s_forward =            "Doorsturen";
$s_showNormalHeaders =  "Toon normale headers";
$s_showAllHeaders =     "Toon alle headers";
$s_showSource =         "Toon de bron";
$s_print =              "Afdrukken";



#################################################
# The left frame
#################################################

$s_check =              "Controleren op nieuwe e-mail";
$s_compose =            "Nieuw bericht";
$s_help =               "Help";
$s_logOut =             "Uitloggen";



#################################################
# The compose page
#################################################

$s_writeTo =            "Aan:";
$s_writeFrom =          "Van:";
$s_writeCc =            "CC:";
$s_writeBcc =           "BCC:";
$s_writeAttach =        "Attachment:";
$s_writeSubject =       "Onderwerp:";
$s_wrote =              "schreef:";
$s_forwarded =          "Doorgestuurd bericht";
$s_send =               "Verzenden";
$s_emailSent =          "Het bericht is verzonden";
$s_noRecipient =        "U heeft niets in het <i>Aan:</i> veld ingevuld.";
$s_invalidRecipient =   "Het email addres in het <i>Aan:</i> veld is niet geldig.";
?>
