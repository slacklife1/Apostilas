<?php
#####################################################################
# French translation by Sylvain Querne <sylvain@querne.com>.
#####################################################################

#################################################
# The error page
#################################################

$s_error =              "Erreur:";
$s_back =               "Retour";
$s_cannotConnect =      "Le programme ne peut pas se connecter au serveur $server sur le port $port.";
$s_wrongPassword =      "Combinaison login/mot de passe incorrecte";


#################################################
# The logout page
#################################################

$s_loggedOut =          "Vous �tes d�connect�";
$s_reenter =            "Cliquez <a href=\"$PHP_SELF\">ici</a> pour vous reconnecter";



#################################################
# The login page
#################################################

$s_server =             "Serveur :";
$s_port =               "Port :";
$s_user =               "Login :";
$s_password =           "Mot de passe :";
$s_submit =             "OK";
$s_cookies =            "NB : Pour que le programme fonctionne, vous devez accepter les cookies.";



#################################################
# The message list
#################################################

$s_noEmails =           "Pas de nouveaux messages.";
$s_selectAll =          "S�lectionner tous les messages";
$s_deselectAll =        "D�s�lectionner tous les messages";
$s_delete =             "Effacer";
$s_subject =            "Objet";
$s_from =               "De";
$s_date =               "Date";
$s_size =               "Taille";
$s_kb =                 "ko";
$s_messagesDeleted =    "Les messages s�l�ctionn�s ont �t� effac�s";
$s_ok =                 "OK";

# The decimal delimiter. In some countries it is
# a comma, in other countries it is a period:
$s_decimalDelimiter =   ",";



#################################################
# Message information
#################################################

$s_mSubject =           "Objet :";
$s_mFrom =              "De :";
$s_mTo =                "A :";
$s_mDate =              "Date :";
$s_mMailer =            "Client :";
$s_reply =              "R�pondre";
$s_forward =            "Transf�rer";
$s_showNormalHeaders =  "Afficher header normaux";
$s_showAllHeaders =     "Afficher header complets";
$s_showSource =         "Afficher la source";
$s_print =              "Imprimer";



#################################################
# The left frame
#################################################

$s_check =              "V�rifier le courrier";
$s_compose =            "Nouveau message";
$s_help =               "Aide";
$s_logOut =             "Sortir";



#################################################
# The compose page
#################################################

$s_writeTo =            "A :";
$s_writeFrom =          "De :";
$s_writeCc =            "CC :";
$s_writeBcc =           "CCi :";
$s_writeAttach =        "Attach� :";
$s_writeSubject =       "Objet :";
$s_wrote =              "Message :";
$s_forwarded =          "Messagge transmis";
$s_send =               "Envoyer";
$s_emailSent =          "Messagge envoy� !";
$s_noRecipient =        "Le champ \"<i>A:</i>\" est vide.";
$s_invalidRecipient =   "L'adresse email \"<i>A:</i>\" n'est pas valide.";
?>
