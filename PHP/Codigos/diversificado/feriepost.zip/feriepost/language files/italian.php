<?php
#####################################################################
# Italian translation by Luca Benni <benni@netemedia.net>.
#####################################################################

#################################################
# The error page
#################################################

$s_error =              "Errore:";
$s_back =               "Indietro";
$s_cannotConnect =      "Il programma non riesce a connettersi al server $server nella porta $port.";
$s_wrongPassword =      "Username e/o password non corretti.";


#################################################
# The logout page
#################################################

$s_loggedOut =          "Sei uscito.";
$s_reenter =            "Clicca <a href=\"$PHP_SELF\">qui</a> per rientrare.";



#################################################
# The login page
#################################################

$s_server =             "Server:";
$s_port =               "Porta:";
$s_user =               "Username:";
$s_password =           "Password:";
$s_submit =             "OK";
$s_cookies =            "Nota: per far funzionare il programma di PostaWeb deve essere attiva la ricezione dei Cookies nel tuo browser.";



#################################################
# The message list
#################################################

$s_noEmails =           "Non ci sono nuovi messaggi.";
$s_selectAll =          "Seleziona tutti i messaggi";
$s_deselectAll =        "Deseleziona tutti i messaggi";
$s_delete =             "Cancella";
$s_subject =            "Oggetto";
$s_from =               "Da";
$s_date =               "Data";
$s_size =               "Dimensione";
$s_kb =                 "Kb";
$s_messagesDeleted =    "Messaggi selezionati sono stati cancellati.";
$s_ok =                 "OK";

# The decimal delimiter. In some countries it is
# a comma, in other countries it is a period:
$s_decimalDelimiter =   ",";



#################################################
# Message information
#################################################

$s_mSubject =           "Oggetto:";
$s_mFrom =              "Da:";
$s_mTo =                "A:";
$s_mDate =              "Data:";
$s_mMailer =            "Client di posta:";
$s_reply =              "Risposta";
$s_forward =            "Inoltra";
$s_showNormalHeaders =  "Mostra gli header normali";
$s_showAllHeaders =     "Mostra tutti gli header";
$s_showSource =         "Mostra il sorgente";
$s_print =              "Stampa";



#################################################
# The left frame
#################################################

$s_check =              "Controlla la posta";
$s_compose =            "Componi";
$s_help =               "Aiuto";
$s_logOut =             "Esci";



#################################################
# The compose page
#################################################

$s_writeTo =            "A:";
$s_writeFrom =          "Da:";
$s_writeCc =            "CC:";
$s_writeBcc =           "BCC:";
$s_writeAttach =        "Allegato:";
$s_writeSubject =       "Soggetto:";
$s_wrote =              "scrivi:";
$s_forwarded =          "Messaggio inoltrato";
$s_send =               "Spedisci";
$s_emailSent =          "Il messaggio � stato inviato.";
$s_noRecipient =        "Non hai scritto niente nel campo <i>A:</i>";
$s_invalidRecipient =   "Indirizzo email non valido nel campo <i>A:</i>.";
?>
