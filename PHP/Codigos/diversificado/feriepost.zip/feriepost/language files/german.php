<?php
# Translation by Tobias J�lke <tobias@juelke.de>.

#################################################
# The error page
#################################################

$s_error =              "Es ist folgender Fehler ist aufgetreten:";
$s_back =               "Zur�ck";
$s_cannotConnect =      "Verbindungsaufbau zu Server $server auf Port $port ist fehlgeschlagen.";
$s_wrongPassword =      "Der Benutzername und/oder das Passwort ist falsch.";


#################################################
# The logout page
#################################################

$s_loggedOut =          "Sie wurden abgemeldet.";
$s_reenter =            "Klicken Sie <a href=\"$PHP_SELF\">hier</a> um sich erneut anzumelden.";



#################################################
# The login page
#################################################

$s_server =             "Server:";
$s_port =               "Port:";
$s_user =               "Benutzername:";
$s_password =           "Passwort:";
$s_submit =             "OK";
$s_cookies =            "Bitte beachten Sie, dass dieses Programm nur lauff�hig ist, wenn Sie Cookies in Ihrem Browser aktiviert haben.";



#################################################
# The message list
#################################################

$s_noEmails =           "Keine neuen Nachrichten.";
$s_selectAll =          "Alle markieren";
$s_deselectAll =        "Markierung von allen aufheben";
$s_delete =             "L�schen";
$s_subject =            "Betreff";
$s_from =               "Absender";
$s_date =               "Datum";
$s_size =               "Gr��e";
$s_kb =                 "Kb";
$s_messagesDeleted =    "Die markierte(n) Nachricht(en) wurden gel�scht.";
$s_ok =                 "OK";

# The decimal delimiter. In some countries it is
# a comma, in other countries it is a period:
$s_decimalDelimiter =   ".";



#################################################
# Message information
#################################################

$s_mSubject =           "Betreff:";
$s_mFrom =              "Absender:";
$s_mTo =                "Empf�nger:";
$s_mDate =              "Datum:";
$s_mMailer =            "eMail Programm:";
$s_reply =              "Antworten";
$s_forward =            "Weiterleiten";
$s_showNormalHeaders =  "Normalen Mail-Header anzeigen";
$s_showAllHeaders =     "Kompletten Mail-Header anzeigen";
$s_showSource =         "Quelltext anzeigen";
$s_print =              "Drucken";



#################################################
# The left frame
#################################################

$s_check =              "Auf neue Nachrichten �berpr�fen";
$s_compose =            "Nachricht verfassen";
$s_help =               "Hilfe";
$s_logOut =             "Abmelden";



#################################################
# The compose page
#################################################

$s_writeTo =            "An:";
$s_writeFrom =          "Von:";
$s_writeCc =            "CC:";
$s_writeBcc =           "BCC:";
$s_writeAttach =        "Anhang:";
$s_writeSubject =       "Betreff:";
$s_wrote =              "schrieb:";
$s_forwarded =          "Weitergeleitete Nachricht";
$s_send =               "Senden";
$s_emailSent =          "Die Nachricht wurde gesendet.";
$s_noRecipient =        "Sie haben keinen Empf�nger angegeben.";
$s_invalidRecipient =   "Die angegebene Empf�nger-eMail-Adresse ist ung�ltig.";
?>
