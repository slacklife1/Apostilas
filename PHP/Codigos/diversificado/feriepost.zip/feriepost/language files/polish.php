<?php
#####################################################################
# Polish  translation by Michal 'aZZaZel' Paj�k <mpajak@student.uci.agh.edu.pl>.
#####################################################################

#################################################
# The error page
#################################################

$s_error =              "Wyst�pi� b��d:";
$s_back =               "Wstecz";
$s_cannotConnect =      "Nie mog� si� po�aczy� z serwerem $server na port $port.";
$s_wrongPassword =      "Nazwa u�ytkownika i/lub has�o zosta�y �le wprowadzone.";


#################################################
# The logout page
#################################################

$s_loggedOut =          "Zosta�e� wylogowany.";
$s_reenter =            "Kliknij <a href=\"$PHP_SELF\">tutaj</a> aby si� ponownie zalogowa�.";



#################################################
# The login page
#################################################

$s_server =             "Serwer:";
$s_port =               "Port:";
$s_user =               "U�ytkownik:";
$s_password =           "Has�o:";
$s_submit =             "Zaloguj si�";
$s_cookies =            "Pamietaj, �e aby Feriepost dzia�a� poprawnie musisz mie� w��czon� obs�ug� cookies w przegl�darce.";



#################################################
# The message list
#################################################

$s_noEmails =           "Nie masz nowych wiadomo�ci.";
$s_selectAll =          "Zaznacz wszystko";
$s_deselectAll =        "Odznacz wszystko";
$s_delete =             "Usu�";
$s_subject =            "Temat";
$s_from =               "Nadawca";
$s_date =               "Data";
$s_size =               "Rozmiar";
$s_kb =                 "Kb";
$s_messagesDeleted =    "Zaznaczone wiadomo�ci zosta�y usuni�te.";
$s_ok =                 "OK";

# The decimal delimiter. In some countries it is
# a comma, in other countries it is a period:
$s_decimalDelimiter =   ",";



#################################################
# Message information
#################################################

$s_mSubject =           "Temat:";
$s_mFrom =              "Nadawca:";
$s_mTo =                "Adresat:";
$s_mDate =              "Data:";
$s_mMailer =            "Program pocztowy:";
$s_reply =              "Odpowiedz";
$s_forward =            "Prze�lij dalej";
$s_showNormalHeaders =  "Poka� normalny nag��wek";
$s_showAllHeaders =     "Poka� rozszerzony nag��wek";
$s_showSource =         "Poka� �r�d�o";
$s_print =              "Drukuj";



#################################################
# The left frame
#################################################

$s_check =              "Sprawd� czy nie masz nowych wiadomo�ci";
$s_compose =            "Nowa wiadomo��";
$s_help =               "Pomoc";
$s_logOut =             "Wyloguj si�";



#################################################
# The compose page
#################################################

$s_writeTo =            "Adresat:";
$s_writeFrom =          "Nadawca:";
$s_writeCc =            "CC:";
$s_writeBcc =           "BCC:";
$s_writeAttach =        "Za��czniki:";
$s_writeSubject =       "Temat:";
$s_wrote =              "Napisany:";
$s_forwarded =          "Przes�ana wiadomo��";
$s_send =               "Wy�lij";
$s_emailSent =          "Wiadomo�� zosta�a wys�ana.";
$s_noRecipient =        "Nie podano <B>adresata</b>.";
$s_invalidRecipient =   "Adres e-mail <B>adresata</B> nie zosta� podany poprawnie.";
?>