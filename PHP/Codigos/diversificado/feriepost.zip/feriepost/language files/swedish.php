<?php
# Oversat af Andreas Barth <andreas@barth.se>.

#################################################
# The error page
#################################################

$s_error =              "Ett fel har uppst�tt:";
$s_back =               "Tillbaka";
$s_cannotConnect =      "Programmet kan inte koppla upp mot servern: $server p� port: $port.";
$s_wrongPassword =      "Ditt anv�ndarnamn och/eller l�senord st�mmer inte.";


#################################################
# The logout page
#################################################

$s_loggedOut =          "Du har loggat ut.";
$s_reenter =            "Tryck <a href=\"$PHP_SELF\">h�r</a> f�r att logga in igen.";



#################################################
# The login page
#################################################

$s_server =             "Server:";
$s_port =               "Port:";
$s_user =               "Anv�ndarnamn:";
$s_password =           "L�senord:";
$s_submit =             "OK";
$s_cookies =            "F�r att logga in m�ste din webbl�sare vara inst�lld f�r att hantera cookies.";



#################################################
# The message list
#################################################

$s_noEmails =           "Det finns inga nya meddelanden.";
$s_selectAll =          "Markera alla";
$s_deselectAll =        "�ngra";
$s_delete =             "Radera";
$s_subject =            "�mne";
$s_from =               "Avs�ndare";
$s_date =               "Datum";
$s_size =               "Storlek";
$s_kb =                 "Kb";
$s_messagesDeleted =    "De markerade meddelandet/meddelandena har raderats.";
$s_ok =                 "OK";

# The decimal delimiter. In some countries it is
# a comma, in other countries it is a period:
$s_decimalDelimiter =   ",";



#################################################
# Message information
#################################################

$s_mSubject =           "�mne:";
$s_mFrom =              "Fr�n:";
$s_mTo =                "Till:";
$s_mDate =              "Datum:";
$s_mMailer =            "E-postprogram:";
$s_reply =              "Svara";
$s_forward =            "Vidarebefordra";
$s_showNormalHeaders =  "Visa normalhuvud";
$s_showAllHeaders =     "Visa huvud";
$s_showSource =         "Meddelandek�lla";
$s_print =              "Skriv ut";



#################################################
# The left frame
#################################################

$s_check =              "Kolla efter ny e-post";
$s_compose =            "Skriv ett nytt meddelande";
$s_help =               "Hj�lp";
$s_logOut =             "Logga ut";



#################################################
# The compose page
#################################################

$s_writeTo =            "Till:";
$s_writeFrom =          "Fr�n:";
$s_writeCc =            "CC:";
$s_writeBcc =           "BCC:";
$s_writeAttach =        "Bifoga fil:";
$s_writeSubject =       "�mne:";
$s_wrote =              "skriv:";
$s_forwarded =          "Vidarebefordra";
$s_send =               "Skicka";
$s_emailSent =          "Ditt meddelande har skickats.";
$s_noRecipient =        "Du m�ste fylla i en e-postadress i <i>Till</i>-f�ltet.";
$s_invalidRecipient =   "E-postadressen i <i>Till</i>-f�ltet �r ogiltig.";
?>
