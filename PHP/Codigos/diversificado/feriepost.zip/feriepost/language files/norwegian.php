<?php
# Oversat af Tormod R. Landet <trlandet@online.no>

#################################################
# The error page
#################################################

$s_error =              "En feil har oppst�tt:";
$s_back =               "Tilbake";
$s_cannotConnect =      "Programmet kan ikke oppn� forbindelse til serveren $server p� port $port.";
$s_wrongPassword =      "Brukernavnet og/eller adgangskoden er feil.";


#################################################
# The logout page
#################################################

$s_loggedOut =          "Du er n� logget ut.";
$s_reenter =            "Hvis du vil logge inn igjen, klikk <a href=\"$PHP_SELF\">her</a>.";



#################################################
# The login page
#################################################

$s_server =             "Server:";
$s_port =               "Port:";
$s_user =               "Brukernavn:";
$s_password =           "Adgangskode:";
$s_submit =             "OK";
$s_cookies =            "Husk at cookies m� v�re sl�tt p� i din nettleser hvis Feriepost skal virke.";



#################################################
# The message list
#################################################

$s_noEmails =           "Det er ingen nye epost.";
$s_selectAll =          "Velg alle";
$s_deselectAll =        "Velg ingen";
$s_delete =             "Slett";
$s_subject =            "Emne";
$s_from =               "Avsender";
$s_date =               "Dato";
$s_size =               "St�rrelse";
$s_kb =                 "Kb";
$s_messagesDeleted =    "Den/De valgte epost(ene) er n� slettet.";
$s_ok =                 "OK";

# The decimal delimiter. In some countries it is
# a comma, in other countries it is a period:
$s_decimalDelimiter =   ",";



#################################################
# Message information
#################################################

$s_mSubject =           "Emne:";
$s_mFrom =              "Avsender:";
$s_mTo =                "Mottaker:";
$s_mDate =              "Dato:";
$s_mMailer =            "Epostprogram:";
$s_reply =              "Svar";
$s_forward =            "Videresend";
$s_showNormalHeaders =  "Vis f� headere";
$s_showAllHeaders =     "Vis alle headere";
$s_showSource =         "Vis kilden";
$s_print =              "Skriv ut";



#################################################
# The left frame
#################################################

$s_check =              "Sjekk om det er ny post";
$s_compose =            "Skriv en nytt epost";
$s_help =               "Hjelp";
$s_logOut =             "Logg ut";



#################################################
# The compose page
#################################################

$s_writeTo =            "Til:";
$s_writeFrom =          "Fra:";
$s_writeCc =            "CC:";
$s_writeBcc =           "BCC:";
$s_writeAttach =        "Vedlegg:";
$s_writeSubject =       "Emne:";
$s_wrote =              "skrev:";
$s_forwarded =          "Videresendt brev";
$s_send =               "Send eposten";
$s_emailSent =          "Eposten er sendt.";
$s_noRecipient =        "<i>Til</i>-feltet er ikke fylt ut.";
$s_invalidRecipient =   "Epostadressen i <i>Til</i>-feltet er ugyldig.";
?>
