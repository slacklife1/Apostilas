<?php
#################################################
# The error page
#################################################

$s_error =              "An error occured:";
$s_back =               "Back";
$s_cannotConnect =      "The program cannot connect to the server $server on port $port.";
$s_wrongPassword =      "The username and/or the password is wrong.";


#################################################
# The logout page
#################################################

$s_loggedOut =          "You are now logged out.";
$s_reenter =            "Click <a href=\"$PHP_SELF\">here</a> to re-enter.";



#################################################
# The login page
#################################################

$s_server =             "Server:";
$s_port =               "Port:";
$s_user =               "Username:";
$s_password =           "Password:";
$s_submit =             "OK";
$s_cookies =            "Please notice that cookies must be enabled in your browser in order for Feriepost to work.";



#################################################
# The message list
#################################################

$s_noEmails =           "There are no new messages.";
$s_selectAll =          "Select all";
$s_deselectAll =        "Deselect all";
$s_delete =             "Delete";
$s_subject =            "Subject";
$s_from =               "Sender";
$s_date =               "Date";
$s_size =               "Size";
$s_kb =                 "Kb";
$s_messagesDeleted =    "The selected message(s) have been deleted.";
$s_ok =                 "OK";

# The decimal delimiter. In some countries it is
# a comma, in other countries it is a period:
$s_decimalDelimiter =   ".";



#################################################
# Message information
#################################################

$s_mSubject =           "Subject:";
$s_mFrom =              "Sender:";
$s_mTo =                "Recipient:";
$s_mDate =              "Date:";
$s_mMailer =            "Mail client:";
$s_reply =              "Reply";
$s_forward =            "Forward";
$s_showNormalHeaders =  "Show normal headers";
$s_showAllHeaders =     "Show all headers";
$s_showSource =         "Show the source";
$s_print =              "Print";



#################################################
# The left frame
#################################################

$s_check =              "Check for new mail";
$s_compose =            "Compose";
$s_help =               "Help";
$s_logOut =             "Log out";



#################################################
# The compose page
#################################################

$s_writeTo =            "To:";
$s_writeFrom =          "From:";
$s_writeCc =            "CC:";
$s_writeBcc =           "BCC:";
$s_writeAttach =        "Attachment:";
$s_writeSubject =       "Subject:";
$s_wrote =              "wrote:";
$s_forwarded =          "Forwarded message";
$s_send =               "Send";
$s_emailSent =          "The message has been sent.";
$s_noRecipient =        "You did not enter anything in the <i>To</i> field.";
$s_invalidRecipient =   "The email address in the <i>To</i> field is invalid.";
?>