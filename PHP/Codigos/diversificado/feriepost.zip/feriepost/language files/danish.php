<?php
#################################################
# The error page
#################################################

$s_error =              "Der er opst�et en fejl:";
$s_back =               "Tilbage";
$s_cannotConnect =      "Programmet kan ikke opn� forbindelse til serveren $server p� port $port.";
$s_wrongPassword =      "Brugernavnet og/eller adgangskoden er forkert.";


#################################################
# The logout page
#################################################

$s_loggedOut =          "Du er nu logget ud.";
$s_reenter =            "Hvis du vil logge ind igen, s� klik <a href=\"$PHP_SELF\">her</a>.";



#################################################
# The login page
#################################################

$s_server =             "Server:";
$s_port =               "Port:";
$s_user =               "Brugernavn:";
$s_password =           "Adgangskode:";
$s_submit =             "Okay";
$s_cookies =            "Husk venligst, at cookies skal v�re sl�et til i din browser, hvis Feriepost skal virke.";



#################################################
# The message list
#################################################

$s_noEmails =           "Der er ingen nye ebreve.";
$s_selectAll =          "V�lg alle";
$s_deselectAll =        "Frav�lg alle";
$s_delete =             "Slet";
$s_subject =            "Emne";
$s_from =               "Afsender";
$s_date =               "Dato";
$s_size =               "St�rrelse";
$s_kb =                 "Kb";
$s_messagesDeleted =    "De(t) valgte ebrev(e) er nu slettet.";
$s_ok =                 "Okay";

# The decimal delimiter. In some countries it is
# a comma, in other countries it is a period:
$s_decimalDelimiter =   ",";



#################################################
# Message information
#################################################

$s_mSubject =           "Emne:";
$s_mFrom =              "Afsender:";
$s_mTo =                "Modtager:";
$s_mDate =              "Dato:";
$s_mMailer =            "Epostprogram:";
$s_reply =              "Besvar";
$s_forward =            "Videresend";
$s_showNormalHeaders =  "Vis kun f� headere";
$s_showAllHeaders =     "Vis alle headere";
$s_showSource =         "Vis kilden";
$s_print =              "Udskriv";



#################################################
# The left frame
#################################################

$s_check =              "Se, om der er nye ebreve";
$s_compose =            "Skriv et nyt ebrev";
$s_help =               "Hj�lp";
$s_logOut =             "Log ud";



#################################################
# The compose page
#################################################

$s_writeTo =            "Til:";
$s_writeFrom =          "Fra:";
$s_writeCc =            "CC:";
$s_writeBcc =           "BCC:";
$s_writeAttach =        "Vedh�ft:";
$s_writeSubject =       "Emne:";
$s_wrote =              "skrev:";
$s_forwarded =          "Videresendt brev";
$s_send =               "Send ebrevet";
$s_emailSent =          "Ebrevet er afsendt.";
$s_noRecipient =        "<i>Til</i>-feltet er ikke udfyldt.";
$s_invalidRecipient =   "Epostadressen i <i>Til</i>-feltet er ugyldig.";
?>