<?php
# Translated by xeron@cfutura.com.

#################################################
# The error page
#################################################

$s_error =              "Ha ocurrido un error:";
$s_back =               "Volver";
$s_cannotConnect =      "El programa no puede conectar con el servidor $server en el puerto $port.";
$s_wrongPassword =      "El nombre de usuario y/o la clave est� mal.";


#################################################
# The logout page
#################################################

$s_loggedOut =          "Has sido desconectado.";
$s_reenter =            "Haz click <a href=\"$PHP_SELF\">aqu�</a> para volver a entrar.";



#################################################
# The login page
#################################################

$s_server =             "Servidor:";
$s_port =               "Puerto:";
$s_user =               "Usuario:";
$s_password =           "Clave:";
$s_submit =             "ACEPTAR";
$s_cookies =            "Debr� tener los cookies activados en su navegador para que Feriepost funcione correctamente.";



#################################################
# The message list
#################################################

$s_noEmails =           "No tiene mensajes nuevos.";
$s_selectAll =          "Seleccionar todos";
$s_deselectAll =        "Deseleccionar todos";
$s_delete =             "Borrar";
$s_subject =            "Asunto";
$s_from =               "De";
$s_date =               "Fecha";
$s_size =               "Tama�o";
$s_kb =                 "Kb";
$s_messagesDeleted =    "Los mensajes elegidos han sido borrados.";
$s_ok =                 "ACEPTAR";

# The decimal delimiter. In some countries it is
# a comma, in other countries it is a period:
$s_decimalDelimiter =   ",";



#################################################
# Message information
#################################################

$s_mSubject =           "Asunto:";
$s_mFrom =              "De:";
$s_mTo =                "A:";
$s_mDate =              "Fecha:";
$s_mMailer =            "X-Mail:";
$s_reply =              "Responder";
$s_forward =            "Redireccionar";
$s_showNormalHeaders =  "Ver cabeceras normales";
$s_showAllHeaders =     "Ver todas las cabeceras";
$s_showSource =         "Ver origen";
$s_print =              "Imprimir";



#################################################
# The left frame
#################################################

$s_check =              "Comprobar nuevos mensajes";
$s_compose =            "Escribir";
$s_help =               "Ayuda";
$s_logOut =             "Desconectar";



#################################################
# The compose page
#################################################

$s_writeTo =            "A:";
$s_writeFrom =          "De:";
$s_writeCc =            "CC:";
$s_writeBcc =           "BCC:";
$s_writeAttach =        "Adjuntar:";
$s_writeSubject =       "Asunto:";
$s_wrote =              "escribi�:";
$s_forwarded =          "Mensaje redirigido";
$s_send =               "Enviar";
$s_emailSent =          "El mensaje ha sido enviado.";
$s_noRecipient =        "No has escrito nada en el campo <i>A</i>.";
$s_invalidRecipient =   "La direcci�n de E-Mail en el campo <i>A</i> es invalida.";
?>
