<?php
#####################################################################
#
# Feriepost
#
$version = "0,13";
#
# Released under the terms of the GNU General Public License.
# Please refer to the readme file for more information.
#####################################################################

#####################################################################
# You may edit the following variables if you want to.
#####################################################################

# Please pick a language file:
$languageFile = "language files/english.php";

# If you only want to use Feriepost with one particular server,
# you can write the name of the server (i.e. mail.example.com) here:
$fixedServer = "";

# If the fixed server does not run on port 110,
# you can fill in the port number here:
$fixedServerPort = "";

# If Feriepost is only going to be used by one particular user
# (that is, one particular POP3 account), you can fill in the
# POP3 username here:
$fixedUser = "";

# If Feriepost is only going to be used by one particular user,
# you can write the default "From:" address here
# (i.e. "Your Name <your.name@example.com>").
$fixedSender = "";

# If Feriepost is only going to be used by one particular user,
# you can write a signature here.
$signature = "";

#####################################################################
# That's it!
#####################################################################







require($languageFile);



function links($tekst) {
    # Quoted printable... I hate it!
    $tekst = str_replace("=E6", "�", $tekst);
    $tekst = str_replace("=F8", "�", $tekst);
    $tekst = str_replace("=E5", "�", $tekst);
    $tekst = str_replace("=C6", "�", $tekst);
    $tekst = str_replace("=D8", "�", $tekst);
    $tekst = str_replace("=C5", "�", $tekst);
    $tekst = str_replace("=A7", "�", $tekst);
    $tekst = str_replace("=A4", "�", $tekst);
    $tekst = str_replace("=3D", "=", $tekst);
    $tekst = str_replace("=20", " ", $tekst);
    $tekst = str_replace("=A3", "�", $tekst);
    $tekst = str_replace("=E4", "�", $tekst);
    $tekst = str_replace("=F6", "�", $tekst);
    $tekst = str_replace("=C4", "�", $tekst);
    $tekst = str_replace("=D6", "�", $tekst);

    # Replacing less than and greater than with the HTML entities.
    # The reason why I don't use htmlspecialchars() is the fact that
    # htmlspecialchars() also converts "&" into "&amp;", which creates problems
    # with the regular expressions below when dealing with URLs that include
    # "&" (i.e. "http://example.com/page.php?var1=value&var2=value").
    $tekst = str_replace("<", "&lt;", $tekst);
    $tekst = str_replace(">", "&gt;", $tekst);

    # Turning email addresses into links:
    $tekst = eregi_replace("([_.a-z0-9-]+@[_.a-z0-9-]+\.[a-z]{2,3})", "<a href=\"$GLOBALS[PHP_SELF]?handling=skriv&modtager=\\1\">\\1</a>", $tekst);

    # Links beginning with an Internet protocol:
    $tekst = eregi_replace("((http://|ftp://|news://|file://)[_.a-z0-9-]+[a-z]{2,3}[a-z0-9/_:@=.+?#%&~-]*[^. |! |? ])", "<a href=\"\\1\" target=\"blank\">\\1</a>", $tekst);

    # HTTP links with no "http://" in front of them. The string must begin with either
    # a space, a carriage return or a newline.
    $tekst = eregi_replace("([ |\r|\n])([a-z0-9.-]+\.[a-z]{2,3}[a-z0-9&/_:@=.+?;#%~-]*[^. |! |? ])", "\\1<a href=\"http://\\2\" target=\"blank\">\\2</a>", $tekst);

    return $tekst;
}



function sidehoved($titel = "", $klasse = "", $visBody = 1) {
    if ($titel) {
        $titel = "Feriepost | $titel";
    }
    else {
        $titel = "Feriepost";
    }

    echo "<html><head><title>$titel</title>\n";
    echo "<style type=text/css><!--\n";
    echo "body { background: white; color: black }\n";
    echo "body.venstre { background: navy; color: black }\n";
    echo "body.oevre { background: white; color: black }\n";
    echo "body.nedre { background: white; color: black }\n";
    echo "body,td { font-family: helvetica; font-size: 10pt }\n";
    echo "td.listeoverskrift { background: navy; color: white }\n";
    echo "td.liste { background: #d0d0d0; color: black }\n";
    echo "input.blaa { background: navy; color: white }\n";
    echo "a:link { color: red }\n";
    echo "a:active { color: red }\n";
    echo "a:visited { color: navy }\n";
    echo "--></style>\n";
    echo "</head>\n\n\n\n";

    if ($visBody == 1) {
        if ($klasse) {
            $klasse = " class=\"$klasse\"";
        }
        echo "<body$klasse>\n";
    }
}

function sidefod() {
    echo "</body></html>";
}

function fejl($fejlbesked, $hoved = 0, $fod = 0) {
    if ($hoved == 1) {
        sidehoved();
    }

    echo "<h3>$GLOBALS[s_error]</h3>\n";
    echo "$fejlbesked<p>\n";
    echo "<form><input type=button class=blaa value=\"&lt;&lt;&lt; $GLOBALS[s_back]\" onClick=history.back()></form>\n";

    if ($fod == 1) {
        sidefod();
    }

    exit;
}



#################################################
# The logout page
#################################################

if ($logUd == 1) {
    setcookie("server");
    setcookie("port");
    setcookie("bruger");
    setcookie("adgangskode");

    sidehoved();

    echo "<h3>$s_loggedOut</h3>\n";
    echo "$s_reenter\n";

    sidefod();

    exit;
}



#################################################
# Left frame
#################################################

if ($ramme == "venstre") {
    sidehoved("", "venstre");

    sidefod();

    echo "<a href=\"$PHP_SELF?ramme=oevre\" target=oevre><img src=\"images/hent.gif\" height=48 width=48 border=0 alt=\"$s_check\"></a>\n";
    echo "<a href=\"$PHP_SELF?handling=skriv\" target=nedre><img src=\"images/skriv.gif\" height=48 width=48 border=0 alt=\"$s_compose\"></a>\n";
    echo "<a href=\"README.html\" target=nedre><img src=\"images/readme.gif\" height=48 width=48 border=0 alt=\"$s_help\"></a>\n";
    echo "<a href=\"$PHP_SELF?logUd=1\" target=_top><img src=\"images/ud.gif\" height=48 width=48 border=0 alt=\"$s_logOut\"></a>\n";

    exit;
}



#################################################
# Bottom frame
#################################################

if ($ramme == "nedre") {
    sidehoved("", "nedre");

    echo "<br><br><br><br>\n";
    echo "<center>\n";
    echo "<span style=\"background: black; color: white; font-size: 14pt; font-style: italic; font-weight: bold\">";
    echo " &nbsp; Feriepost &nbsp; ";
    echo "</span>\n";
    echo "</center>\n";

    sidefod();

    exit;
}



#################################################
# The login page
#################################################

if (!$server || !$port || !$bruger || !$adgangskode) {
    sidehoved();

    echo "<table border=0 cellspacing=1 cellpadding=3>\n";
    echo "<form action=\"$PHP_SELF\" method=post>\n";

    echo "<tr><td class=listeoverskrift colspan=2><b>Feriepost</b></td>\n";

    echo "<tr><td class=liste>$s_server</td>\n";
    if ($fixedServer) {
        echo "<input type=hidden name=server value=\"$fixedServer\">\n";
        echo "<td class=liste>$fixedServer</td>\n";
    }
    else {
        echo "<td class=liste><input type=text name=server size=18></td>\n";
    }

    echo "<tr><td class=liste>$s_port</td>\n";
    if ($fixedServer) {
        if ($fixedServerPort) {
            echo "<input type=hidden name=port value=\"$fixedServerPort\">\n";
            echo "<td class=liste>$fixedServerPort</td>\n";
        }
        else {
            echo "<input type=hidden name=port value=110>\n";
            echo "<td class=liste>110</td>\n";
        }
    }
    else {
        echo "<td class=liste><input type=text name=port size=18 value=110></td>\n";
    }

    echo "<tr><td class=liste>$s_user</td>\n";
    if ($fixedUser) {
        echo "<input type=hidden name=bruger value=\"$fixedUser\">\n";
        echo "<td class=liste>$fixedUser</td>\n";
    }
    else {
        echo "<td class=liste><input type=text name=bruger size=18></td>\n";
    }

    echo "<tr><td class=liste>$s_password</td>\n";
    echo "<td class=liste><input type=password name=adgangskode size=18></td>\n";

    echo "<tr><td class=liste>&nbsp;</td>\n";
    echo "<td class=liste><input type=submit class=blaa value=\"$s_submit\"></td>\n";

    echo "<tr><td class=listeoverskrift colspan=2>$s_cookies</td>\n";

    echo "</form>\n";
    echo "</table>\n";

    sidefod();

    exit;
}



$fp = fsockopen($server, $port) or fejl($s_cannotConnect, 1, 1);
$foersteLinje = fgets($fp, 1024);

fputs($fp, "USER $bruger\r\n");
$andenLinje = fgets($fp, 1024);

fputs($fp, "PASS $adgangskode\r\n");
if (substr(fgets($fp, 1024), 0, 3) != "+OK") {
    fejl($s_wrongPassword, 1, 1);
}



setcookie("server", $server, time()+3600);
setcookie("port", $port, time()+3600);
setcookie("bruger", $bruger, time()+3600);
setcookie("adgangskode", $adgangskode, time()+3600);



#################################################
# Frameset
#################################################

if (!$QUERY_STRING) {
    sidehoved("", "", 0);

    echo "<frameset cols=75,* border=3>\n";
    echo "<frame src=\"$PHP_SELF?ramme=venstre\" name=venstre scrolling=no>\n";
    echo "<frameset rows=20%,* border=3>\n";
    echo "<frame src=\"$PHP_SELF?ramme=oevre\" name=oevre>\n";
    echo "<frame src=\"$PHP_SELF?ramme=nedre\" name=nedre>\n";
    echo "</frameset>\n";
    echo "</frameset></html>";
}



#################################################
# The compose page
#################################################

if ($handling == "skriv") {
    sidehoved();

    if ($send) {
        if (!$til) {
            fejl($s_noRecipient);
        }
        if (!eregi("[a-z0-9]+@[a-z0-9]+", $til)) {
            fejl($s_invalidRecipient);
        }

        $til = stripslashes($til);
        $fra = stripslashes($fra);
        $emne = stripslashes($emne);
        $tekst = stripslashes($tekst);

        $headere = "From: $fra\nX-Mailer: Feriepost $version\n";
        if ($cc) {
            $headere .= "CC: $cc\n";
        }
        if ($bcc) {
            $headere .= "BCC: $bcc\n";
        }
        if ($fil_name) {
            if (!$fil_type) {
                $fil_type = "application/unknown";
            }

            $adskiller = uniqid("Feriepost");
            $headere .= "Content-Type: multipart/mixed;\n boundary=\"$adskiller\"\n";

            $aabenFil = $filindhold = fopen($fil, "r");
            $filindhold = fread($aabenFil, filesize($fil));

            if (ereg("^text/", $fil_type)) {
                $disposition = "inline";
                $indkodning = "8bit";
            }
            else {
                $filindhold = chunk_split(base64_encode($filindhold));
                $disposition = "attachment";
                $indkodning = "base64";
            }

            $tekst = "--$adskiller\nContent-Type: text/plain\nContent-Transfer-Encoding: 8bit\n\n$tekst\n\n";
            $tekst .= "--$adskiller\nContent-Type: $fil_type;\n name=\"$fil_name\"\nContent-Transfer-Encoding: $indkodning\nContent-Disposition: $disposition;\n filename=\"$fil_name\"\n\n$filindhold\n--$adskiller--";
        }

        mail($til, $emne, $tekst, $headere);

        echo "$s_emailSent\n";

        sidefod();

        exit;
    }



    $ebrev = htmlspecialchars(stripslashes($ebrev));
    $fixedSender = htmlspecialchars($fixedSender);
    $signature = htmlspecialchars($signature);
    $emne = htmlspecialchars(chop($emne));

    if ($besvar) {
        if (!eregi("^Re: ", $emne)) {
            $emne = "Re: $emne";
        }
    }
    if ($videresend) {
        $emne = "Fwd: $emne";
        $ebrev = "-------------------- $s_forwarded --------------------\n\n$ebrev";
    }

    if ($besvar) {
        $modtager = htmlspecialchars(chop($modtager));
        $ebrev = str_replace("\n", "\n> ", $ebrev);
        $ebrev = "$modtager $s_wrote\n>\n> $ebrev";
    }
    if ($videresend) {
        $modtager = "";
    }

    echo "<form action=\"$PHP_SELF?handling=skriv\" enctype=\"multipart/form-data\" method=post>\n";
    echo "<table border=0 cellspacing=1 cellpadding=3>\n";
    echo "<tr><td class=liste>$s_writeTo</td>\n";
    echo "<td class=liste><input type=text name=til size=40 value=\"$modtager\">\n";
    echo "<tr><td class=liste>$s_writeFrom</td>\n";
    echo "<td class=liste><input type=text name=fra size=40 value=\"$fixedSender\">\n";
    echo "<tr><td class=liste>$s_writeCc</td>\n";
    echo "<td class=liste><input type=text name=cc size=40>\n";
    echo "<tr><td class=liste>$s_writeBcc</td>\n";
    echo "<td class=liste><input type=text name=bcc size=40>\n";
    echo "<tr><td class=liste>$s_writeAttach</td>\n";
    echo "<input type=hidden name=\"MAX_FILE_SIZE\" value=\"204800\">\n";
    echo "<td class=liste><input type=file name=fil size=40>\n";
    echo "<tr><td class=listeoverskrift>$s_writeSubject</td>\n";
    echo "<td class=listeoverskrift><input type=text name=emne size=40 value=\"$emne\">\n";
    echo "</table>\n";
    echo "<textarea name=tekst cols=72 rows=10>\n";
    echo $ebrev;
    if ($signature) {
        echo "\n\n-- \n$signature";
    }
    echo "</textarea><br>\n";
    echo "<input type=submit class=blaa name=send value=\"$s_send\">\n";
    echo "</form>\n";

    sidefod();
}



#################################################
# The top frame -- message list
#################################################

if ($ramme == "oevre") {
    sidehoved("", "oevre");

    # Deleting emails:
    if ($sletEbreve) {
        for ($i = 0; $i < sizeof($sletEbreve); $i++) {
            fputs($fp, "DELE $sletEbreve[$i]\r\n");
            $foersteLinje = fgets($fp, 1024);
        }
        fputs($fp, "QUIT\r\n");

        echo "<form action=\"$PHP_SELF?ramme=oevre\" method=post>\n";
        echo "$s_messagesDeleted<br>\n";
        echo "<input type=submit class=blaa value=\"$s_ok\">\n";
        echo "</form>\n";

        sidefod();

        exit;
    }

    fputs($fp, "STAT\r\n");
    $ebreve = fgets($fp, 1024);
    $ebreve = split(" ", $ebreve);
    $antalEbreve = $ebreve[1];

    if ($antalEbreve == 0) {
        echo "$s_noEmails\n";

        sidefod();

        exit;
    }

    echo "<script language=\"javascript\"><!--\n";
    echo "function krydsAf(alleEllerIngen) {\n";
    echo "  for (i = 0; i < document.forms[0].elements.length; i++) {\n";
    echo "      if (alleEllerIngen == \"alle\") {\n";
    echo "          document.forms[0].elements[i].checked = true\n";
    echo "      }\n";
    echo "      else {\n";
    echo "          document.forms[0].elements[i].checked = false\n";
    echo "      }\n";
    echo "  }\n";
    echo "}\n";
    echo "// --></script>\n";

    echo "<form action=\"$PHP_SELF?ramme=oevre\" method=post>\n";
    echo "<table width=100% border=0 cellspacing=1 cellpadding=2>\n";
    echo "<tr><td class=listeoverskrift>$s_delete</td>\n";
    echo "<td class=listeoverskrift>$s_subject</td>\n";
    echo "<td class=listeoverskrift>$s_from</td>\n";
    echo "<td class=listeoverskrift>$s_date</td>\n";
    echo "<td class=listeoverskrift>$s_size</td>\n";

    for ($i = $antalEbreve; $i >= 1; $i--) {
        fputs($fp, "TOP $i 0\r\n");
        while (substr($linje = fgets($fp, 1024), 0, 2) != chr(13).chr(10)) {
            if (substr($linje, 0, 9) == "Subject: ") {
                $emne = htmlspecialchars(substr($linje, 9));
            }
            if (substr($linje, 0, 6) == "From: ") {
                $fra = htmlspecialchars(substr($linje, 6));
            }
            if (substr($linje, 0, 6) == "Date: ") {
                $dato = htmlspecialchars(substr($linje, 6));
            }
            if (substr($linje, 0, 3) == "+OK") {
                $stoerrelse = split(" ", $linje);
                $stoerrelse = $stoerrelse[1];
                # If the size information is available:
                if ($stoerrelse && $stoerrelse != "\r\n") {
                    $stoerrelse = $stoerrelse / 1024;
                    $stoerrelse = number_format($stoerrelse, 1);
                    $stoerrelse = str_replace(".", $s_decimalDelimiter, $stoerrelse);
                    $stoerrelse = "$stoerrelse $s_kb";
                }
                else {
                    # Some POP3 servers don't show the file size of the message
                    # when you enter the "TOP" command.
                    # Therefore, we'll just write a hyphen instead of the file size.
                    $stoerrelse = "-";
                }
            }
        }

        # Certain browsers don't paint the background in the table cells
        # if the cells are empty. Therefore, we need to put a "&nbsp;"
        # in the cells if the headers are empty.
        if (!$emne || $emne == "\r\n") {
            $emne = "&nbsp;";
        }
        if (!$dato || $dato == "\r\n") {
            $dato = "&nbsp;";
        }
        if (!$fra || $fra == "\r\n") {
            $fra = "&nbsp;";
        }

        echo "<tr><td class=liste><input type=checkbox name=sletEbreve[] value=$i></td>\n";
        echo "<td class=liste><a href=\"$PHP_SELF?visEbrevNummer=$i\" target=nedre style=\"text-decoration: none; color: black\">$emne</a></td>\n";
        echo "<td class=liste><a href=\"$PHP_SELF?visEbrevNummer=$i\" target=nedre style=\"text-decoration: none; color: black\">$fra</a></td>\n";
        echo "<td class=liste><a href=\"$PHP_SELF?visEbrevNummer=$i\" target=nedre style=\"text-decoration: none; color: black\">$dato</a></td>\n";
        echo "<td class=liste><a href=\"$PHP_SELF?visEbrevNummer=$i\" target=nedre style=\"text-decoration: none; color: black\">$stoerrelse</a></td>\n";
    }

    echo "</table>\n";
    echo "<input type=button class=blaa value=\"$s_selectAll\" onClick=\"krydsAf('alle')\">\n";
    echo "<input type=button class=blaa value=\"$s_deselectAll\" onClick=\"krydsAf('ingen')\">\n";
    echo "<input type=submit class=blaa value=\"$s_delete\">\n";
    echo "</form>\n";

    sidefod();
}



if ($visKilden && $ebrevNummer) {
    sidehoved();

    echo "<pre>\n";

    fputs($fp, "RETR $ebrevNummer\r\n");
    $foersteLinje = fgets($fp, 1024);

    while (substr($linje = fgets($fp, 1024), 0, 3) != ".".chr(13).chr(10)) {
        echo htmlspecialchars($linje);
    }

    echo "</pre>\n";

    sidefod();
}



#################################################
# Displaying the contents of the email
#################################################

if ($visEbrevNummer) {
    sidehoved();

    fputs($fp, "RETR $visEbrevNummer\r\n");
    $foersteLinje = fgets($fp, 1024);

    while (substr($linje = fgets($fp, 1024), 0, 2) != chr(13).chr(10)) {
        if ($visAlleHeadere == 1) {
            if (ereg(": ", $linje)) {
                $position =strpos($linje, " ");
                $headernavn = substr($linje, 0, $position);
                $headervaerdi = substr($linje, $position);
                $headernavn = htmlspecialchars($headernavn);
                $headervaerdi = htmlspecialchars($headervaerdi);

                $alleHeadere .= "<b>$headernavn</b>$headervaerdi";
            }
            else {
                $alleHeadere .= htmlspecialchars($linje);
            }
        }
        if (substr($linje, 0, 9) == "Subject: ") {
            $emne = htmlspecialchars(substr($linje, 9));
        }
        if (substr($linje, 0, 6) == "From: ") {
            $fra = htmlspecialchars(substr($linje, 6));
        }
        if (substr($linje, 0, 4) == "To: ") {
            $til = htmlspecialchars(substr($linje, 4));
        }
        if (substr($linje, 0, 6) == "Date: ") {
            $dato = htmlspecialchars(substr($linje, 6));
        }
        if (substr($linje, 0, 10) == "X-Mailer: ") {
            $postprogram = htmlspecialchars(substr($linje, 10));
        }
    }

    echo "<form action=\"$PHP_SELF?handling=skriv\" method=post>\n";
    echo "<table width=100% border=0 cellspacing=0 cellpadding=2 style=\"background: #d0d0d0\">\n";

    $mellemrum = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";

    echo "<tr><td style=\"background: navy; color: white\" colspan=2>\n";
    echo "<input type=submit class=blaa name=besvar value=\"$s_reply\">\n";
    echo "$mellemrum\n";
    echo "<input type=submit class=blaa name=videresend value=\"$s_forward\">\n";
    echo "$mellemrum\n";
    echo "<input type=button class=blaa value=\"$s_print\" onClick=self.print()>\n";
    echo "$mellemrum\n";
    if ($visAlleHeadere == 1) {
        echo "<a href=\"$PHP_SELF?visEbrevNummer=$visEbrevNummer\" style=\"text-decoration: none; color: white\">$s_showNormalHeaders</a>\n";
    }
    else {
        echo "<a href=\"$PHP_SELF?visEbrevNummer=$visEbrevNummer&visAlleHeadere=1\" style=\"text-decoration: none; color: white\">$s_showAllHeaders</a>\n";
    }
    echo "$mellemrum\n";
    echo "<a href=\"$PHP_SELF?visKilden=1&ebrevNummer=$visEbrevNummer\" target=\"_blank\" style=\"text-decoration: none; color: white\">$s_showSource</a>\n";
    echo "</td>\n";

    if ($visAlleHeadere == 1) {
        echo "<tr><td>\n";
        echo "<pre>\n";
        echo $alleHeadere;
        echo "</pre>\n";
        echo "</td>\n";
        echo "<td>&nbsp;</td>\n";
    }
    else {
        # Certain browsers don't paint the background in the table cells
        # if the cells are empty. Therefore, we need to put a "&nbsp;"
        # in the cells if the headers are empty.
        if (!$emne || $emne == "\r\n") {
            $emne = "&nbsp;";
        }
        if (!$dato || $dato == "\r\n") {
            $dato = "&nbsp;";
        }
        if (!$fra || $fra == "\r\n") {
            $fra = "&nbsp;";
        }
        if (!$til || $til == "\r\n") {
            $til = "&nbsp;";
        }
        if (!$postprogram || $postprogram == "\r\n") {
            $postprogram = "&nbsp;";
        }

        echo "<tr><td><b>$s_mSubject</b></td>\n";
        echo "<td><b>".links($emne)."</b></td>\n";
        echo "<tr><td><b>$s_mDate</b></td>\n";
        echo "<td>".links($dato)."</td>\n";
        echo "<tr><td><b>$s_mFrom</b></td>\n";
        echo "<td>".links($fra)."</td>\n";
        echo "<tr><td><b>$s_mTo</b></td>\n";
        echo "<td>".links($til)."</td>\n";
        echo "<tr><td><b>$s_mMailer</b></td>\n";
        echo "<td>".links($postprogram)."</td>\n";
    }

    echo "</table>\n";



    while (substr($linje = fgets($fp, 1024), 0, 3) != ".".chr(13).chr(10)) {
        $ebrevtekst .= $linje;
    }

    echo "<input type=hidden name=ebrev value=\"".htmlspecialchars($ebrevtekst)."\">\n";
    echo "<input type=hidden name=modtager value=\"$fra\">\n";
    echo "<input type=hidden name=emne value=\"$emne\">\n";
    echo "<pre>\n";
    echo links($ebrevtekst);
    echo "</pre>\n";
    echo "</form>\n";

    sidefod();
}



fclose($fp);
?>
