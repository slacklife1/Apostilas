<?php

#######################
##  Chris's Guestbook Script
##  Freely distributed PHP
##  Script.  Enjoy!!  Now see
##  wasn't that a short enough
##  liscense :)
##  I don't care what you do
##  with this script as long as
##  you give me credit if it makes
##  you famous and give me money
##   if it makes you rich ;)
#######################

$log_file = "/path/to/gbook.log";
$template_sign = "/path/to/sign.tmp";
$template_view = "/path/to/view.tmp";

######## for those who are too lazy to edit the template files :)
$site_name =  "Your Website's Name";  //  Your Website's Name
$site_url = "http://yourhost.com/you";  //URL to return page
$bgcolor = "#404040";   //  Back Ground color
$textcolor = "#FFFFFF";   //  Text Color
$linkcolor = "#376B89";   //  Non-visited Links Color
$vlinkcolor = "#D7C771";  // Visited Links Color
$font = "verdana,arial";  //  Comma Seperated list of fonts to use in descending order

#############  Thats It For Configuration  ####################

if($action == "sign"){
if(!$submit){
require($template_sign); }
else{
$Dstamp = date("M d,Y");
$msg = "Thank you for signing our guestbook!";
$myArr = array($name, $email, $feature, $best, $worst, $rank, $comments, $Dstamp);
$line = implode("|", $myArr);
$line .= "\n";
if($fp = fopen($log_file, "w")){
if(flock($fp, LOCK_EX)){}
else{ flock($fp, 2); }
fputs($fp, $line);
fclose($fp);
include($template_view);
	}
}

elseif($action == "view"){
$line = file($log_file);
foreach($lines as $temp){
$sp[] = trim($temp);  }
include($template_view);
}

else{
$msg = "ERROR! An Unknown Error Has Occured!"; 
include($template_view);  }

?>