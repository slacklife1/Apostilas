########################################################################
##  Simple Guestbook Script written by Chris Wall.
##  If you have any questions or comments email me at 
##  chris@neosd.net    Also check my site soon (neosd.net) for
##  lots more free, pay, and remotely hosted scripts........
##  Scirpt comes AS IS, no warranty given or implied,
##  Chris Wall will not be held responsible for misuse of the script
##  or for what it may do.  It has run fine on my machine for a long time, so
##  if it crashes yours its not my fault ;)
##
##  Liscence:::
##  By using this script you agree to the following terms:
##   1. You agree not to modify the code of this script outside of 
##         normal configuration
##   2.  You agree not to claim this code as your own for any purposes
##   3.  This code may be passed around, but not commercially distributed
##   4.  If you want to distribute this code, whole or in part, on CD-Rom or in
##         any other manufactured fashion, you must retain written permission
##          from Chris Wall (chris@neosd.net).
##              
##        Simple Enuff huh?   Enjoy!
#########################################################################

This Readme will try to walk you through setup and install of this script.
This is the first script I've written for distrobution so bare with me on the whole
"Technical Writing" thing :)

###### Configure the Script

1.  Open gbook.php in any text/php editor and locate the 3 variables near the top.

2.  Set the paths to your absolute or relative path to the specified files.

3.  If you keep the log and template files in the same directory as the script you
          list the paths as just the file names (ie if view.tmp is in the same folder as gbook.php,
   									then $template_view = "view.tmp"; will work fine!!)

4.  Edit the Templates (view.tmp, sign.tmp) to your liking WARNING!! Do not mess with the php code unless you know
         what you are doing ;) 

5.  Upload gbook.php, view.tmp, and sign.tmp to any directory you choose.


###### Running the Script

1.  You should always test scripts so point your browser to your url and the file gbook.php?action=sign.
	(i.e. http://yourhost.com/yourname/guestbook/gbook.php?action=sign ).

2.  Everything work fine??  If not look at the bottom of this file at the troubleshooting FAQ.

3.  Now to point to your new guestbook just link to gbook.php?action=sign to sign the guestbook
	and gbook.php?action=view to view the guestbook (simple right).


#############  Troubleshooting FAQ

Q:  I am getting the error "failure to include file "view.tmp (or sign.tmp)" include_path(....blah blah"!!
A:   This means that the variables $template_view and/or $template_sign are not where you said they would be
       double check the variables at the top of gbook.php and make sure you set the paths correctly!!

Q:  I am getting the error "....not a valid file handle resource...."!!
A:  Try creating and uploading an empty text file called gbook.log (or whatever you might have changed the name to)
       and uploading it where you told the script it would be.  Some systems have problems creating new files

Q:  I am getting the previous error even after uploading the log file!!
A:  That means there is a problem with the log file.  You may have to set the permissions on the log to 666 to get the
         script to work (works fine without it on my machine, but some people might have to know this).

Any other problems, you can email me at chris@neosd.net and I will try to answer you as soon as possible.

#############  Change Log

v1.0:   Initial Build.  Personal Use Only

v1.5:  Distro Build.  Made Config File and turned in script html into templates.

v2.0:  Distro Build second release.  Added some extra configuration options.