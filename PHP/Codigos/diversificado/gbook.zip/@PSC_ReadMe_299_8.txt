Title: Gbook2K
Description: Your basic guestbook...consists of only 4 files, 2 templates so you can totally customize the look of it, a log file and the script...easy to read code, compatible with php3 and 4...no DB needed
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=299&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
