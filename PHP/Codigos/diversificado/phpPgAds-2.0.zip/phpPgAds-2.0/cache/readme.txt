Make this directory writable by phpAdsNew to be able
to use it to store Delivery cache files. This is needed
if you want to use the 'File' module.