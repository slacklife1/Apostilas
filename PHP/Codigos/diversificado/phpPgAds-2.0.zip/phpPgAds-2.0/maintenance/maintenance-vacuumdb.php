<?php // $Id: maintenance-vacuumdb.php,v 2.0.2.1 2003/10/05 12:05:55 ciaccia Exp $

/************************************************************************/
/* phpPgAds                                                             */
/* ========                                                             */
/*                                                                      */
/* Copyright (c) 2001-2003 by the phpPgAds developers                   */
/* For more information visit: http://phppgads.sourceforge.net          */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/



if ($phpAds_config['auto_clean_tables_vacuum'])
{
	include ('../admin/lib-install-db.inc.php');
	
	// Read database structure
	$dbstructure = phpAds_prepareDatabaseStructure();
	
	$vacuum = array();
	
	while (list($k,) = each($dbstructure))
		$vacuum[] = "VACUUM ANALYZE $k";
	
	phpAds_dbQuery(join('; ', $vacuum));
}

?>
