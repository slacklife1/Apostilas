<?php // $Revision: 1.1.2.1 $

/************************************************************************/
/* phpAdsNew 2                                                          */
/* ===========                                                          */
/*                                                                      */
/* Copyright (c) 2000-2003 by the phpAdsNew developers                  */
/* For more information visit: http://www.phpadsnew.com                 */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/


$phpAds_cont_name['AS'] = 'Asia';
$phpAds_cont_name['EU'] = 'Europa';
$phpAds_cont_name['AF'] = 'Africa';
$phpAds_cont_name['OC'] = 'Australia/Oceania';
$phpAds_cont_name['CA'] = 'Caraibi';
$phpAds_cont_name['SA'] = 'America del Sud';
$phpAds_cont_name['NA'] = 'America del Nord';
$phpAds_cont_name['AQ'] = 'Antartide';

?>