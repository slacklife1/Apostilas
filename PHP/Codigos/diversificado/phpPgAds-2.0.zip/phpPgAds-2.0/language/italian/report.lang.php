<?php // $Revision: 2.0.2.1 $

/************************************************************************/
/* phpAdsNew 2                                                          */
/* ===========                                                          */
/*                                                                      */
/* Copyright (c) 2000-2003 by the phpAdsNew developers                  */
/* http://sourceforge.net/projects/phpadsnew                            */
/*                                                                      */
/* Translations by Matteo Beccati                                       */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/


$GLOBALS['strPluginAffiliate'] 		= "Genera un resoconto per l'editore selezionato. Il rapporto sar&agrave; esportato in formato CSV per l'utilizzo in un foglio elettronico.";
$GLOBALS['strPluginCampaign'] 		= "Genera un resoconto per la campagna selezionata. Il rapporto sar&agrave; esportato in formato CSV per l'utilizzo in un foglio elettronico.";
$GLOBALS['strPluginClient'] 		= "Genera un resoconto per l'inserzionista selezionato. Il rapporto sar&agrave; esportato in formato CSV per l'utilizzo in un foglio elettronico.";
$GLOBALS['strPluginGlobal'] 		= "Genera un resoconto storico globale. Il rapporto sar&agrave; esportato in formato CSV per l'utilizzo in un foglio elettronico.";
$GLOBALS['strPluginZone'] 			= "Genera un resoconto per la zona selezionata. Il rapporto sar&agrave; esportato in formato CSV per l'utilizzo in un foglio elettronico.";

?>