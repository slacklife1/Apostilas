<?php // $Revision: 2.0.2.1 $

/************************************************************************/
/* phpAdsNew 2                                                          */
/* ===========                                                          */
/*                                                                      */
/* Copyright (c) 2000-2003 by the phpAdsNew developers                  */
/* For more information visit: http://www.phpadsnew.com                 */
/*                                                                      */
/* Portuguese translation Lopo Lencastre de Almeida  www.humaneasy.com  */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/


$GLOBALS['strPluginAffiliate'] 	= "Gera um hist�rico descritivo do editor selecionado. O relat�rio � exportado como CSV para f�cil importa��o.";
$GLOBALS['strPluginCampaign'] 	= "Gera um hist�rico descritivo da campanha selecionada. O relat�rio � exportado como CSV para f�cil importa��o.";
$GLOBALS['strPluginClient'] 	= "Gera um hist�rico descritivo do anunciante selecionado. O relat�rio � exportado como CSV para f�cil importa��o.";
$GLOBALS['strPluginGlobal'] 	= "Gera um hist�rico descritivo global. O relat�rio � exportado como CSV para f�cil importa��o.";
$GLOBALS['strPluginZone'] 		= "Gera um hist�rico descritivo do zona selecionado. O relat�rio � exportado como CSV para f�cil importa��o.";

?>