<?php // $Revision: 1.1.2.2 $

/************************************************************************/
/* phpAdsNew 2                                                          */
/* ===========                                                          */
/*                                                                      */
/* Copyright (c) 2000-2003 by the phpAdsNew developers                  */
/* For more information visit: http://www.phpadsnew.com                 */
/*                                                                      */
/*                                                                      */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/
/* Turkish Translation by :												*/
/* 		Metin AKTA� (metin@yapayzeka.net)								*/
/* 		B�nyamin VICIL (bunyamin@yapayzeka.net)					        */
/************************************************************************/

$GLOBALS['strPluginAffiliate'] 		= "Se�ili Yay�nc�ya ait �zet ge�mi� raporu �ret. Rapor CSV format�nda �retilecektir.";
$GLOBALS['strPluginCampaign'] 		= "Se�ili Kampanyaya ait �zet ge�mi� raporu �ret. Rapor CSV format�nda �retilecektir.";
$GLOBALS['strPluginClient'] 		= "Se�ili Reklamc�ya ait �zet ge�mi� raporu �ret. Rapor CSV format�nda �retilecektir.";
$GLOBALS['strPluginGlobal'] 		= "Genel ge�mi� raporu �ret. Rapor CSV format�nda �retilecektir.";
$GLOBALS['strPluginZone'] 		= "Se�ili Alana ait �zet ge�mi� raporu �ret. Rapor CSV format�nda �retilecektir.";

?>