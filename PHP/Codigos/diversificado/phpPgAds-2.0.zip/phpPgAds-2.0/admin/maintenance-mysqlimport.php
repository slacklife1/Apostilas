<?php // $Id: maintenance-mysqlimport.php,v 1.1.2.5 2003/10/05 12:05:47 ciaccia Exp $

/************************************************************************/
/* phpPgAds                                                             */
/* ========                                                             */
/*                                                                      */
/* Copyright (c) 2001-2003 by the phpPgAds developers                   */
/* For more information visit: http://phppgads.sourceforge.net          */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/



// Include required files
require ("config.php");
require ("lib-maintenance.inc.php");
require ("lib-statistics.inc.php");
require ("lib-zones.inc.php");


// Security check
phpAds_checkAccess(phpAds_Admin);



/*********************************************************/
/* HTML framework                                        */
/*********************************************************/

phpAds_PageHeader("5.3");
phpAds_ShowSections(array("5.1", "5.3", "5.4", "5.2"));
phpAds_MaintenanceSelection("mysqlimport");


/*********************************************************/
/* Main code                                             */
/*********************************************************/

echo "<br>";
echo '
Using this tool you will be able to import inventory and stats from a running phpAdsNew.
You will need to supply the config.inc.php file of the source phpAdsNew install. All the entilty IDs will be remapped and appended to your current '.$phpAds_productname.'
inventory. Nothing will be changed on the phpAdsNew database.<br><br>
<b>This feature is currently experimental.</b>
';
echo "<br><br>";

if (get_cfg_var ('safe_mode'))
{
	echo "<b>It seems you currenlty have PHP running in safe mode. You could not be able to run the
		import correctly!</b>";
	echo "<br><br>";
}

phpAds_ShowBreak();

echo "<form action='maintenance-mysqlimport-execute.php' method='post' enctype='multipart/form-data'>";
echo 'phpAdsNew config.inc.php file'.' ';
echo "<input name='altconfig' type='file'>";
phpAds_ShowBreak();

echo "<br><input type='submit' name='submit' value='Invia'></form>";



/*********************************************************/
/* HTML framework                                        */
/*********************************************************/

phpAds_PageFooter();

?>