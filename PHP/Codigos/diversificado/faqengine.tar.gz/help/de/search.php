<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/REC-html40/loose.dtd">
<?php
require('../../config.php');
require('../../functions.php');
$sql = "select * from ".$tableprefix."_layout where (layoutnr=1)";
if(!$result = faqe_db_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = faqe_db_fetch_array($result))
{
	$FontFace=$myrow["fontface"];
	$FontSize1=$myrow["fontsize1"];
	$FontSize2=$myrow["fontsize2"];
	$FontSize3=$myrow["fontsize3"];
	$FontSize4=$myrow["fontsize4"];
	$FontSize5=$myrow["fontsize5"];
	$FontColor=$myrow["fontcolor"];
	$TableWidth=$myrow["tablewidth"];
	$heading_bgcolor=$myrow["headingbg"];
	$table_bgcolor=$myrow["bgcolor1"];
	$row_bgcolor=$myrow["bgcolor2"];
	$group_bgcolor=$myrow["bgcolor3"];
	$page_bgcolor=$myrow["pagebg"];
	$stylesheet=stripslashes($myrow["stylesheet"]);
	$show_proglist=$myrow["showproglist"];
	$HeadingFontColor=$myrow["headingfontcolor"];
	$SubheadingFontColor=$myrow["subheadingfontcolor"];
	$GroupFontColor=$myrow["groupfontcolor"];
	$LinkColor=$myrow["linkcolor"];
	$VLinkColor=$myrow["vlinkcolor"];
	$ALinkColor=$myrow["alinkcolor"];
	$TableDescFontColor=$myrow["tabledescfontcolor"];
	$newtime=$myrow["newtime"];
	$closepic=$myrow["closepic"];
	$addbodytags=$myrow["addbodytags"];
	if((substr($closepic,0,1)!="/") && (!strstr($closepic,"://")))
		$closepic="../../".$closepic;
	if((substr($stylesheet,0,1)!="/") && (!strstr($stylesheet,"://")))
		$stylesheet="../../".$stylesheet;
}
else
	die("Layout not set up");
if(!isset($lang) || !$lang)
	$act_lang=$default_lang;
else
	$act_lang=$lang;
if(!language_avail($act_lang,"../../language"))
	die ("Language <b>$act_lang</b> not configured");
include('../../language/lang_'.$act_lang.'.php');
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<?php
if($stylesheet)
	echo"<link rel=stylesheet href=\"$stylesheet\" type=\"text/css\">";
?>
<title>FAQEngine - Suche - Hilfe</title>
</head>
<body onload="top.window.focus()" bgcolor="<?php echo $row_bgcolor?>" link="<?php echo $LinkColor?>" vlink="<?php echo $VLinkColor?>" alink="<?php echo $ALinkColor?>" text="<?php echo $FontColor?>" <?php echo $addbodytags?>>
<table width="<?php echo $TableWidth?>" align="center">
<tr bgcolor="<?php echo $heading_bgcolor?>"><td width="98%">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize3?>" color="<?php echo $HeadingFontColor?>">
<b>Hilfe zur Suchfunktion</b></font>
</td>
<td align="center" valign="middle" width="2%"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize4?>"><a class="pFo" href="javascript:parent.window.focus();top.window.close()"><img src="<?php echo $closepic?>" border="0" alt="<?php echo $l_close?>"></a></font></td></tr>
</tr>
<tr bgcolor="<?php echo $page_bgcolor?>">
<td colspan="2">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
Es gibt zwei Arten der Suchfunktion, die <i>einfache</i> Suche und die <i>erweiterte</i> Suche.
</font><br><br>
<table border=0 cellpadding=0 cellspacing=0 width="100%" align="CENTER"><TR><td bgcolor="<?php echo $table_bgcolor?>">
<table border=0 cellpadding=4 cellspacing=1 width="100%">
<TR bgcolor="<?php echo $heading_bgcolor?>">
<TD>
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $SubheadingFontColor?>">
<b>Einfache Suche</b></FONT></td></tr>
<TR bgcolor="<?php echo $row_bgcolor?>"><TD><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
Diese Formular bietet Ihnen eine einfacher zu bedienende Suchfunktion. Sie k&ouml;nnen hier angeben,
welche Worte das zu Suchende Dokument enthalten <i>muss</i>, <i>kann</i> und <i>nicht enthalten</i> darf.<br>
Dazu benutzen Sie folgende Sonderzeichen:<ul>
<li>stellen Sie vor das Wort ein <b>+</b>, so werden nur Dokumente angezeigt, die dieses Wort enthalten. Geben
Sie mehrere solch gekennzeichnete Worte an, so werden nur die Dokumente angezeigt, die <i>alle</i> diese Worte enthalten.</li>
<li>stellen Sie vor das Wort ein <b>-</b>, so werden nur Dokumente angezeigt, die dieses Wort nicht enthalten. Geben
Sie mehrere solch gekennzeichnete Worte an, so werden nur Dokumente angezeigt, die <i>keines</i> dieser Worte enthalen.</li>
<li>stellen Sie kein Kennzeichen vor das Wort, so bedeutet dies, dass die zu suchenden Dokumente das Wort enthalten sollen. Geben
Sie mehrere solch gekennzeichnete Worte an, so werden die Dokumente angezeigt, die <i>mind. eins</i> dieser Worte enthalten.</li>
</ul>
Beispiel:<br>
+Donald +Duck -Mikey Goofy<br>
gibt alle Dokumente aus, die Donald <i>und</i> Duck, aber <i>nicht</i> Mickey und evtl. noch Goofy enthalten.
<br><br>
Bei der einfachen Suche m&uuml;ssen die Suchbegriffe entweder in der &Uuml;berschrift, dem Frage- oder dem Antworttext der FAQ auftauchen.<br>
</font></td></tr>
<tr bgcolor="<?php echo $heading_bgcolor?>"><td>
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $SubheadingFontColor?>">
<b>Erweiterte Suche</b></FONT></td></tr>
<TR bgcolor="<?php echo $row_bgcolor?>"><TD>
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
Die Syntax der erweiterten Suche ist analog zu der der <i>einfachen</i> Suche.<br>
Allerdings k&ouml;nnen Sie hier genauer bestimmen, in welchem Teil der FAQ nach dem
Begriffen gesucht werden soll.
</font></td></tr>
</table>
</td></tr></table></td></tr>
<tr bgcolor="<?php echo $heading_bgcolor?>"><td>&nbsp;</td>
<td align="center" valign="middle" width="2%"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize4?>"><a class="pFo" href="javascript:parent.window.focus();top.window.close()"><img src="<?php echo $closepic?>" border="0" alt="<?php echo $l_close?>"></a></font></td></tr>
</tr></table>
</body>
</html>