<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('./config.php');
require_once('./functions.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<?php
$sql = "select * from ".$tableprefix."_layout where (layoutnr=1)";
if(!$result = faqe_db_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = faqe_db_fetch_array($result))
{
	$FontFace=$myrow["fontface"];
	$FontSize1=$myrow["fontsize1"];
	$FontSize2=$myrow["fontsize2"];
	$FontSize3=$myrow["fontsize3"];
	$FontSize4=$myrow["fontsize4"];
	$FontSize5=$myrow["fontsize5"];
	$FontColor=$myrow["fontcolor"];
	$TableWidth=$myrow["tablewidth"];
	$heading_bgcolor=$myrow["headingbg"];
	$table_bgcolor=$myrow["bgcolor1"];
	$row_bgcolor=$myrow["bgcolor2"];
	$group_bgcolor=$myrow["bgcolor3"];
	$page_bgcolor=$myrow["pagebg"];
	$stylesheet=stripslashes($myrow["stylesheet"]);
	$show_proglist=$myrow["showproglist"];
	$HeadingFontColor=$myrow["headingfontcolor"];
	$SubheadingFontColor=$myrow["subheadingfontcolor"];
	$GroupFontColor=$myrow["groupfontcolor"];
	$LinkColor=$myrow["linkcolor"];
	$VLinkColor=$myrow["vlinkcolor"];
	$ALinkColor=$myrow["alinkcolor"];
	$TableDescFontColor=$myrow["tabledescfontcolor"];
	$dateformat=$myrow["dateformat"];
	$newtime=$myrow["newtime"];
	$searchpic=$myrow["searchpic"];
	$printpic=$myrow["printpic"];
	$backpic=$myrow["backpic"];
	$pageheader=$myrow["pageheader"];
	$pagefooter=$myrow["pagefooter"];
	$usecustomheader=$myrow["usecustomheader"];
	$usecustomfooter=$myrow["usecustomfooter"];
	$allowemail=$myrow["allowemail"];
	$allowlists=$myrow["allowlists"];
	$server_timezone=$myrow["timezone"];
	$headerfile=$myrow["headerfile"];
	$footerfile=$myrow["footerfile"];
	$copyrightbgcolor=$myrow["copyrightbgcolor"];
	$showcurrtime=$myrow["showcurrtime"];
	$showtimezone=$myrow["showtimezone"];
	$copyrightpos=$myrow["copyrightpos"];
	$subheadingbgcolor=$myrow["subheadingbgcolor"];
	$actionbgcolor=$myrow["actionbgcolor"];
	$headerfilepos=$myrow["headerfilepos"];
	$footerfilepos=$myrow["footerfilepos"];
	$newinfobgcolor=$myrow["newinfobgcolor"];
	$addbodytags=$myrow["addbodytags"];
	$htmllisttype=$myrow["htmllisttype"];
	if((!$pageheader) && (!$headerfile))
		$usecustomheader=0;
	if((!$pagefooter) && (!$footerfile))
		$usecustomfooter=0;
}
else
	die("Layout not set up");
if(!isset($$langvar) || !$$langvar)
	$act_lang=$default_lang;
else
	$act_lang=$$langvar;
if(!language_avail($act_lang))
	die ("Language <b>$act_lang</b> not configured");
include('./language/lang_'.$act_lang.'.php');
if((@fopen("./config.php", "a")) && !$testmode)
{
	die($l_config_writeable);
}
if(!isset($prog))
	die($l_calling_error);
if($allowlists!=1)
	die($l_function_disabled);
?>
<html>
<head>
<meta name="generator" content="FAQEngine v<?php echo $version?>, <?php echo $copyright_asc?>">
<?php
if($stylesheet)
	echo"<link rel=stylesheet href=\"$stylesheet\" type=\"text/css\">";
if(file_exists("./metadata.php"))
	include ("./metadata.php");
else
{
?>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<title><?php echo $l_heading?></title>
<?php
}
?>
</head>
<body bgcolor="<?php echo $page_bgcolor?>" link="<?php echo $LinkColor?>" vlink="<?php echo $VLinkColor?>" alink="<?php echo $ALinkColor?>" text="<?php echo $FontColor?>" <?php echo $addbodytags?>>
<?php
if($usecustomheader==1)
{
	if(($headerfile) && ($headerfilepos==0))
	{
		if(is_phpfile($headerfile))
			include_once($headerfile);
		else
			file_output($headerfile);
	}
	echo $pageheader;
	if(($headerfile) && ($headerfilepos==1))
	{
		if(is_phpfile($headerfile))
			include_once($headerfile);
		else
			file_output($headerfile);
	}
}
?>
<table width="<?php echo $TableWidth?>" border="0" CELLPADDING="1" CELLSPACING="0" ALIGN="CENTER" VALIGN="TOP">
<tr><TD BGCOLOR="<?php echo $table_bgcolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<TR BGCOLOR="<?php echo $heading_bgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE" width="95%"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize3?>" color="<?php echo $HeadingFontColor?>"><b><?php echo $l_heading?></b></font>
</td>
<?php
$sql = "select * from ".$tableprefix."_misc";
if(!$result = faqe_db_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = faqe_db_fetch_array($result))
{
	if($myrow["shutdown"]==1)
	{
?>
</tr></table></td></tr>
<tr><TD BGCOLOR="<?php echo $table_bgcolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<?php
		$shutdowntext=stripslashes($myrow["shutdowntext"]);
		$shutdowntext = undo_htmlspecialchars($shutdowntext);
		echo $shutdowntext;
		echo "</font></td></tr></table></td></tr></table>";
		echo "<br><div align=\"center\"><font face=\"$FontFace\" SIZE=\"$FontSize4\">$l_timezone_note $server_timezone<br>Generated by $copyright_url<br>$copyright_note</font></div>";
		exit;
	}
}
?>
<td align="right" valign="MIDDLE" width="5%">
<a href="faq.php?list=all&prog=<?php echo $prog?>&amp;<?php echo "$langvar=$act_lang"?><?php if(isset($onlynewfaq)) echo "&amp;onlynewfaq=$onlynewfaq"?>">
<img src="<?php echo $backpic?>" border="0" alt="<?php echo $l_faqlink?>"></a></td>
</tr></table></td></tr>
<tr><TD BGCOLOR="<?php echo $table_bgcolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<tr BGCOLOR="<?php echo $group_bgcolor?>" ALIGN="CENTER">
<?php
if($htmllisttype==0)
	$list_url="all_html.php";
else
	$list_url="all_html2.php";
?>
<TD ALIGN="CENTER" VALIGN="MIDDLE"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>"><a href="<?php echo $list_url?>?prog=<?php echo $prog?>&amp;<?php echo "$langvar=$act_lang"?>" target="_blank"><?php echo $l_htmllist?></a></font></td></tr>
<tr BGCOLOR="<?php echo $group_bgcolor?>" ALIGN="CENTER">
<?php
if($htmllisttype==0)
	$list_url="all_print.php";
else
	$list_url="all_print2.php";
?>
<TD ALIGN="CENTER" VALIGN="MIDDLE"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>"><a href="<?php echo $list_url?>?prog=<?php echo $prog?>&amp;<?php echo "$langvar=$act_lang"?>" target="_blank"><?php echo $l_printlist?></a></font></td></tr>
<tr BGCOLOR="<?php echo $group_bgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>"><a href="all_ascii.php?prog=<?php echo $prog?>&amp;<?php echo "$langvar=$act_lang"?>" target="_blank"><?php echo $l_asciilist?></a></font></td></tr>
<tr BGCOLOR="<?php echo $group_bgcolor?>" ALIGN="CENTER">
<?php
if($allowemail==1)
{
?>
<TD ALIGN="CENTER" VALIGN="MIDDLE"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>"><a href="all_email.php?prog=<?php echo $prog?>&amp;<?php echo "$langvar=$act_lang"?>" target="_blank"><?php echo $l_maillist?></a></font></td></tr>
<?php
}
?>
</table></td></tr></table>
<?php
if(($usecustomfooter==1) && ($copyrightpos==0))
{
	if(($footerfile) && ($footerfilepos==0))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
	echo $pagefooter;
	if(($footerfile) && ($footerfilepos==1))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
}
?>
<br>
<table align="center" bgcolor="<?php echo $copyrightbgcolor?>" width="<?php echo $TableWidth?>" border="0">
<tr><td align="center">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize4?>" color="<?php echo $FontColor?>">
<?php
if($showcurrtime)
{
	$displaytime=date("H:i");
	echo "$l_currtime $displaytime<br>";
}
if($showtimezone==1)
	echo "$l_timezone_note $server_timezone<br>";
echo "Generated by $copyright_url, $copyright_note";
?>
</td></tr></table>
<br>
<?php
if(($usecustomfooter==1) && ($copyrightpos==1))
{
	if(($footerfile) && ($footerfilepos==0))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
	echo $pagefooter;
	if(($footerfile) && ($footerfilepos==1))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
}
?>
</body></html>
