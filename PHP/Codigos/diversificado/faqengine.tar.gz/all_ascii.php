<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('./config.php');
require('./functions.php');
$sql = "select * from ".$tableprefix."_layout where (layoutnr=1)";
if(!$result = faqe_db_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = faqe_db_fetch_array($result))
{
	$FontFace=$myrow["fontface"];
	$FontSize1=$myrow["fontsize1"];
	$FontSize2=$myrow["fontsize2"];
	$FontSize3=$myrow["fontsize3"];
	$FontSize4=$myrow["fontsize4"];
	$FontSize5=$myrow["fontsize5"];
	$FontColor=$myrow["fontcolor"];
	$TableWidth=$myrow["tablewidth"];
	$heading_bgcolor=$myrow["headingbg"];
	$table_bgcolor=$myrow["bgcolor1"];
	$row_bgcolor=$myrow["bgcolor2"];
	$group_bgcolor=$myrow["bgcolor3"];
	$page_bgcolor=$myrow["pagebg"];
	$stylesheet=stripslashes($myrow["stylesheet"]);
	$show_proglist=$myrow["showproglist"];
	$HeadingFontColor=$myrow["headingfontcolor"];
	$SubheadingFontColor=$myrow["subheadingfontcolor"];
	$GroupFontColor=$myrow["groupfontcolor"];
	$LinkColor=$myrow["linkcolor"];
	$VLinkColor=$myrow["vlinkcolor"];
	$ALinkColor=$myrow["alinkcolor"];
	$TableDescFontColor=$myrow["tabledescfontcolor"];
	$dateformat=$myrow["dateformat"];
	$newtime=$myrow["newtime"];
	$searchpic=$myrow["searchpic"];
	$printpic=$myrow["printpic"];
	$backpic=$myrow["backpic"];
	$allowlists=$myrow["allowlists"];
	$server_timezone=$myrow["timezone"];
	$showtimezone=$myrow["showtimezone"];
	$useascheader=$myrow["usecustomheader"];
	$ascheader=stripslashes($myrow["ascheader"]);
	$asclinelength=$myrow["asclinelength"];
	$ascforcewrap=$myrow["ascforcewrap"];
	$asclistmimetype=$myrow["asclistmimetype"];
	$asclistcharset=$myrow["asclistcharset"];
	$faqsortmethod=$myrow["faqsortmethod"];
	if(!$ascheader)
		$useascheader=0;
}
else
	die("Layout not set up");
if(!isset($$langvar) || !$$langvar)
	$act_lang=$default_lang;
else
	$act_lang=$$langvar;
if(!language_avail($act_lang))
	die ("Language <b>$act_lang</b> not configured");
include('./language/lang_'.$act_lang.'.php');
if((@fopen("./config.php", "a")) && !$testmode)
{
	die($l_config_writeable);
}
if($asclistmimetype==0)
{
	$content_type="Content-Type: ".$avail_mimetypes[$asclistmimetype]."; charset=".$asclistcharset."\n";
	header($content_type);
}
else
{
	$content_type="Content-Type: ".$avail_mimetypes[$asclistmimetype]."\n";
	header($content_type);
	header('Content-Disposition: filename="faqlist.txt"\n');
}
$data="";
header("Content-Transfer-Encoding: binary\n");
$crlf="\r\n";
$sql = "select * from ".$tableprefix."_misc";
if(!$result = faqe_db_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = faqe_db_fetch_array($result))
{
	if($myrow["shutdown"]==1)
	{
		$shutdowntext=stripslashes($myrow["shutdowntext"]);
		$shutdowntext = undo_htmlspecialchars($shutdowntext);
		echo $shutdowntext;
		exit;
	}
}
if(!isset($prog))
	die($l_calling_error);
if($allowlists!=1)
	die($l_function_disabled);
if(($useascheader==1) && ($ascheader))
{
	$ascheader=str_replace("\n", "\r\n", $ascheader);
	$data.=$ascheader.$crlf;
}
$sql = "select * from ".$tableprefix."_programm where (progid='$prog') and (language='$act_lang')";
if(!$result = faqe_db_query($sql, $db))
   	die("Could not connect to the database.");
if (!$myrow = faqe_db_fetch_array($result))
   	die($l_nosuchprog);
$data.="$l_heading$crlf";
$data.="$l_progname: ".$myrow["programmname"]."$crlf$crlf";
$prognr=$myrow["prognr"];
$sql = "select * from ".$tableprefix."_category where (programm=$prognr) order by displaypos";
if(!$result = faqe_db_query($sql, $db))
   	die("Could not connect to the database.");
if (!$myrow = faqe_db_fetch_array($result))
   	die($l_noentries);
$faqcount=1;
do{
	$data.=$myrow["categoryname"]."$crlf";
	$sql = "select * from ".$tableprefix."_data where (category=".$myrow["catnr"].") and subcategory = 0";
	if($faqsortmethod==0)
		$sql.=" order by editdate desc";
	else
		$sql.=" order by displaypos asc";
	if(!$result2 = faqe_db_query($sql, $db))
	   	die("Could not connect to the database.");
	if (!$myrow2 = faqe_db_fetch_array($result2))
		$data.=undo_htmlentities($l_noentries).$crlf;
	else
	{
		do{
		$headingtext=stripslashes($myrow2["heading"]);
		$headingtext=undo_htmlentities($headingtext);
		if($asclinelength>0)
		{
			if($ascforcewrap==1)
				$headingtext=wordwrap($headingtext,$asclinelength,$crlf,1);
			else
				$headingtext=wordwrap($headingtext,$asclinelength,$crlf);
		}
		$data.="$faqcount. ".$headingtext."$crlf";
		$faqcount+=1;
		}while($myrow2 = faqe_db_fetch_array($result2));
	}
	$data.=$crlf;
	$sql = "select * from ".$tableprefix."_subcategory where category=".$myrow["catnr"]." order by displaypos asc";
	if(!$result2 = faqe_db_query($sql, $db))
	   	die("Could not connect to the database.");
	if ($myrow2 = faqe_db_fetch_array($result2))
	{
		do{
		$data.=" ".$myrow2["categoryname"]."$crlf";
		$sql = "select * from ".$tableprefix."_data where subcategory=".$myrow2["catnr"]." order by displaypos asc";
		if(!$result3 = faqe_db_query($sql, $db))
		   	die("Could not connect to the database.");
		if (!$myrow3 = faqe_db_fetch_array($result3))
			$data.=undo_htmlentities($l_noentries).$crlf;
		else
		{
			do{
				$headingtext=stripslashes($myrow3["heading"]);
				$headingtext=undo_htmlentities($headingtext);
				if($asclinelength>0)
				{
					if($ascforcewrap==1)
						$headingtext=wordwrap($headingtext,$asclinelength,$crlf,1);
					else
						$headingtext=wordwrap($headingtext,$asclinelength,$crlf);
				}
				$data.="$faqcount. ".$headingtext."$crlf";
				$faqcount+=1;
			}while($myrow3 = faqe_db_fetch_array($result3));
		}
		}while($myrow2 = faqe_db_fetch_array($result2));
		$data.=$crlf;
	}
} while($myrow = faqe_db_fetch_array($result));
$data.="$crlf$crlf";
$sql = "select * from ".$tableprefix."_category where (programm=$prognr) order by displaypos asc";
if(!$result = faqe_db_query($sql, $db))
   	die("Could not connect to the database.");
if (!$myrow = faqe_db_fetch_array($result))
   	die($l_noentries);
$faqcount=1;
do{
	$data.=$myrow["categoryname"]."$crlf";
	$sql = "select * from ".$tableprefix."_data where (category=".$myrow["catnr"].") and subcategory=0";
	if($faqsortmethod==0)
		$sql.=" order by editdate desc";
	else
		$sql.=" order by displaypos asc";
	if(!$result2 = faqe_db_query($sql, $db))
	   	die("Could not connect to the database.");
	if (!$myrow2 = faqe_db_fetch_array($result2))
		$data.=undo_htmlentities($l_noentries).$crlf.$crlf;
	else
	{
		do{
			$headingtext=stripslashes($myrow2["heading"]);
			$headingtext=undo_htmlentities($headingtext);
			if($asclinelength>0)
			{
				if($ascforcewrap==1)
					$headingtext=wordwrap($headingtext,$asclinelength,$crlf,1);
				else
					$headingtext=wordwrap($headingtext,$asclinelength,$crlf);
			}
			$questiontext=stripslashes($myrow2["questiontext"]);
			$questiontext = str_replace("<BR>", $crlf, $questiontext);
			$questiontext = undo_htmlentities($questiontext);
			$questiontext = strip_tags($questiontext);
			if($asclinelength>0)
			{
				if($ascforcewrap==1)
					$questiontext=wordwrap($questiontext,$asclinelength,$crlf,1);
				else
					$questiontext=wordwrap($questiontext,$asclinelength,$crlf);
			}
			$answertext=stripslashes($myrow2["answertext"]);
			$answertext = str_replace("<BR>", $crlf, $answertext);
			$answertext = undo_htmlentities($answertext);
			$answertext = strip_tags($answertext);
			if($asclinelength>0)
			{
				if($ascforcewrap==1)
					$answertext=wordwrap($answertext,$asclinelength,$crlf,1);
				else
					$answertext=wordwrap($answertext,$asclinelength,$crlf,0);
			}
			$data.="$faqcount. ".$headingtext."$crlf";
			$data.="$l_question:$crlf";
			$data.=$questiontext."$crlf";
			$data.="$l_answer:$crlf";
			$data.=$answertext."$crlf$crlf";
			$faqcount+=1;
		}while($myrow2 = faqe_db_fetch_array($result2));
	}
	$sql = "select * from ".$tableprefix."_subcategory where category=".$myrow["catnr"]." order by displaypos asc";
	if(!$result2 = faqe_db_query($sql, $db))
	   	die("Could not connect to the database.");
	if ($myrow2 = faqe_db_fetch_array($result2))
	{
		do{
		$data.=" ".$myrow2["categoryname"]."$crlf";
		$sql = "select * from ".$tableprefix."_data where subcategory=".$myrow2["catnr"];
		if($faqsortmethod==0)
			$sql.=" order by editdate desc";
		else
			$sql.=" order by displaypos asc";
		if(!$result3 = faqe_db_query($sql, $db))
		   	die("Could not connect to the database.");
		if (!$myrow3 = faqe_db_fetch_array($result3))
			$data.=undo_htmlentities($l_noentries).$crlf.$crlf;
		else
		{
			do{
			$headingtext=stripslashes($myrow3["heading"]);
			$headingtext=undo_htmlentities($headingtext);
			if($asclinelength>0)
			{
				if($ascforcewrap==1)
					$headingtext=wordwrap($headingtext,$asclinelength,$crlf,1);
				else
					$headingtext=wordwrap($headingtext,$asclinelength,$crlf);
			}
			$questiontext=stripslashes($myrow3["questiontext"]);
			$questiontext = str_replace("<BR>", $crlf, $questiontext);
			$questiontext = undo_htmlentities($questiontext);
			$questiontext = strip_tags($questiontext);
			if($asclinelength>0)
			{
				if($ascforcewrap==1)
					$questiontext=wordwrap($questiontext,$asclinelength,$crlf,1);
				else
					$questiontext=wordwrap($questiontext,$asclinelength,$crlf);
			}
			$answertext=stripslashes($myrow3["answertext"]);
			$answertext = str_replace("<BR>", $crlf, $answertext);
			$answertext = undo_htmlentities($answertext);
			$answertext = strip_tags($answertext);
			if($asclinelength>0)
			{
				if($ascforcewrap==1)
					$answertext=wordwrap($answertext,$asclinelength,$crlf,1);
				else
					$answertext=wordwrap($answertext,$asclinelength,$crlf,0);
			}
			$data.="$faqcount. ".$headingtext."$crlf";
			$data.="$l_question:$crlf";
			$data.=$questiontext."$crlf";
			$data.="$l_answer:$crlf";
			$data.=$answertext."$crlf$crlf";
			$faqcount+=1;
			}while($myrow3 = faqe_db_fetch_array($result3));
		}
	} while($myrow2 = faqe_db_fetch_array($result2));
	}
} while($myrow = faqe_db_fetch_array($result));
$actdate=date("$dateformat H:i");
$data.=undo_htmlentities($l_generated).": $actdate$crlf";
if($showtimezone==1)
	$data.="$l_timezone_note $server_timezone$crlf";
$copyrightline="FAQEngine v$version, (c)2001,2002 Boesch EDV-Consulting (http://www.boesch-it.de)$crlf";
	if($asclinelength>0)
	{
		if($ascforcewrap==1)
			$copyrightline=wordwrap($copyrightline,$asclinelength,$crlf,1);
		else
			$copyrightline=wordwrap($copyrightline,$asclinelength,$crlf);
	}
$data.=$copyrightline;
header("Content-length: " . strlen($data) . "\n");
print($data);
?>
