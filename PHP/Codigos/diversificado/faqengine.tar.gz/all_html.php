<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('./config.php');
require('./functions.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<?php
$sql = "select * from ".$tableprefix."_layout where (layoutnr=1)";
if(!$result = faqe_db_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = faqe_db_fetch_array($result))
{
	$FontFace=$myrow["fontface"];
	$FontSize1=$myrow["fontsize1"];
	$FontSize2=$myrow["fontsize2"];
	$FontSize3=$myrow["fontsize3"];
	$FontSize4=$myrow["fontsize4"];
	$FontSize5=$myrow["fontsize5"];
	$FontColor=$myrow["fontcolor"];
	$TableWidth=$myrow["tablewidth"];
	$heading_bgcolor=$myrow["headingbg"];
	$table_bgcolor=$myrow["bgcolor1"];
	$row_bgcolor=$myrow["bgcolor2"];
	$group_bgcolor=$myrow["bgcolor3"];
	$page_bgcolor=$myrow["pagebg"];
	$stylesheet=stripslashes($myrow["stylesheet"]);
	$show_proglist=$myrow["showproglist"];
	$HeadingFontColor=$myrow["headingfontcolor"];
	$SubheadingFontColor=$myrow["subheadingfontcolor"];
	$GroupFontColor=$myrow["groupfontcolor"];
	$LinkColor=$myrow["linkcolor"];
	$VLinkColor=$myrow["vlinkcolor"];
	$ALinkColor=$myrow["alinkcolor"];
	$TableDescFontColor=$myrow["tabledescfontcolor"];
	$dateformat=$myrow["dateformat"];
	$newtime=$myrow["newtime"];
	$searchpic=$myrow["searchpic"];
	$printpic=$myrow["printpic"];
	$backpic=$myrow["backpic"];
	$pageheader=$myrow["pageheader"];
	$pagefooter=$myrow["pagefooter"];
	$usecustomheader=$myrow["usecustomheader"];
	$usecustomfooter=$myrow["usecustomfooter"];
	$allowlists=$myrow["allowlists"];
	$server_timezone=$myrow["timezone"];
	$headerfile=$myrow["headerfile"];
	$footerfile=$myrow["footerfile"];
	$faqsortmethod=$myrow["faqsortmethod"];
	$copyrightbgcolor=$myrow["copyrightbgcolor"];
	$showtimezone=$myrow["showtimezone"];
	$copyrightpos=$myrow["copyrightpos"];
	$subheadingbgcolor=$myrow["subheadingbgcolor"];
	$actionbgcolor=$myrow["actionbgcolor"];
	$headerfilepos=$myrow["headerfilepos"];
	$footerfilepos=$myrow["footerfilepos"];
	$newinfobgcolor=$myrow["newinfobgcolor"];
	$addbodytags=$myrow["addbodytags"];
	$subcatbgcolor=$myrow["subcatbgcolor"];
	$subcatfontcolor=$myrow["subcatfontcolor"];
	if((!$pageheader) && (!$headerfile))
		$usecustomheader=0;
	if((!$pagefooter) && (!$headerfile))
		$usecustomfooter=0;
}
else
	die("Layout not set up");
if(!isset($$langvar) || !$$langvar)
	$act_lang=$default_lang;
else
	$act_lang=$$langvar;
if(!language_avail($act_lang))
	die ("Language <b>$act_lang</b> not configured");
include('./language/lang_'.$act_lang.'.php');
if((@fopen("./config.php", "a")) && !$testmode)
{
	die($l_config_writeable);
}
?>
<html>
<head>
<meta name="generator" content="FAQEngine v<?php echo $version?>, <?php echo $copyright_asc?>">
<?php
if($stylesheet)
	echo"<link rel=stylesheet href=\"$stylesheet\" type=\"text/css\">";
if(file_exists("./metadata.php"))
	include ("./metadata.php");
else
{
?>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<title><?php echo $l_heading?></title>
<?php
}
?>
</head>
<body bgcolor="<?php echo $page_bgcolor?>" link="<?php echo $LinkColor?>" vlink="<?php echo $VLinkColor?>" alink="<?php echo $ALinkColor?>" text="<?php echo $FontColor?>" <?php echo $addbodytags?>>
<?php
if($usecustomheader==1)
{
	if(($headerfile) && ($headerfilepos==0))
	{
		if(is_phpfile($headerfile))
			include($headerfile);
		else
			file_output($headerfile);
	}
	echo $pageheader;
	if(($headerfile) && ($headerfilepos==1))
	{
		if(is_phpfile($headerfile))
			include($headerfile);
		else
			file_output($headerfile);
	}
}
$sql = "select * from ".$tableprefix."_misc";
if(!$result = faqe_db_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = faqe_db_fetch_array($result))
{
	if($myrow["shutdown"]==1)
	{
		$shutdowntext=stripslashes($myrow["shutdowntext"]);
		$shutdowntext = undo_htmlspecialchars($shutdowntext);
		echo $shutdowntext;
		exit;
	}
}
if(!isset($prog))
	die($l_calling_error);
if($allowlists!=1)
	die($l_function_disabled);
$sql = "select * from ".$tableprefix."_programm where (progid='$prog') and (language='$lang')";
if(!$result = faqe_db_query($sql, $db))
   	die("Could not connect to the database.");
if (!$myrow = faqe_db_fetch_array($result))
   	die($l_nosuchprog);
?>
<table width="<?php echo $TableWidth?>" border="0" CELLPADDING="1" CELLSPACING="0" ALIGN="CENTER">
<tr><TD BGCOLOR="<?php echo $table_bgcolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<TR BGCOLOR="<?php echo $heading_bgcolor?>" ALIGN="CENTER"><TD ALIGN="CENTER" VALIGN="MIDDLE">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize3?>" color="<?php echo $HeadingFontColor?>">
<b><?php echo $l_heading?></b></font></td></tr>
<TR BGCOLOR="<?php echo $subheadingbgcolor?>" ALIGN="CENTER"><TD ALIGN="CENTER" VALIGN="MIDDLE">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $SubheadingFontColor?>">
<b><?php echo "$l_progname: ".$myrow["programmname"]?></b></font></td></tr>
<?
$prognr=$myrow["prognr"];
$sql = "select * from ".$tableprefix."_category where (programm=$prognr) order by displaypos";
if(!$result = faqe_db_query($sql, $db))
   	die("Could not connect to the database.");
if (!$myrow = faqe_db_fetch_array($result))
   	die($l_noentries);
$faqcount=1;
do{
?>
<TR BGCOLOR="<?php echo $group_bgcolor?>" ALIGN="CENTER"><TD ALIGN="left" VALIGN="MIDDLE">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $GroupFontColor?>">
<?php echo $myrow["categoryname"]?></font></td></tr>
<?php
$sql = "select * from ".$tableprefix."_data where (category=".$myrow["catnr"].") and subcategory=0";
if($faqsortmethod==0)
	$sql.=" order by editdate desc";
else
	$sql.=" order by displaypos asc";
if(!$result2 = faqe_db_query($sql, $db))
   	die("Could not connect to the database.");
?>
<TR BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER"><TD ALIGN="left" VALIGN="MIDDLE">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<?php
if (!$myrow2 = faqe_db_fetch_array($result2))
	echo $l_noentries;
else
{
	do{
		echo "$faqcount. <a href=\"#".$myrow2["faqnr"]."\">".$myrow2["heading"]."</a><br>";
		$faqcount+=1;
	}while($myrow2 = faqe_db_fetch_array($result2));
}
echo "</font></td></tr>";
$sql = "select * from ".$tableprefix."_subcategory where category=".$myrow["catnr"]." order by displaypos asc";
if(!$result2 = faqe_db_query($sql, $db))
   	die("Could not connect to the database.");
if ($myrow2 = faqe_db_fetch_array($result2))
{
	do{
?>
<TR BGCOLOR="<?php echo $subcatbgcolor?>" ALIGN="CENTER"><TD ALIGN="left" VALIGN="MIDDLE">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $subcatfontcolor?>">
<i><?php echo $myrow2["categoryname"]?></i></font></td></tr>
<TR BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER"><TD ALIGN="left" VALIGN="MIDDLE">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<?php
		$sql = "select * from ".$tableprefix."_data where subcategory=".$myrow2["catnr"];
		if(!$result3 = faqe_db_query($sql, $db))
		   	die("Could not connect to the database.");
		if (!$myrow3 = faqe_db_fetch_array($result3))
			echo $l_noentries;
		else
		{
			do{
				echo "$faqcount. <a href=\"#".$myrow3["faqnr"]."\">".$myrow3["heading"]."</a><br>";
				$faqcount+=1;
			}while($myrow3 = faqe_db_fetch_array($result3));
		}
	}while($myrow2 = faqe_db_fetch_array($result2));
}
echo "</font></td></tr>";
} while($myrow = faqe_db_fetch_array($result));
$sql = "select * from ".$tableprefix."_category where (programm=$prognr) order by displaypos";
if(!$result = faqe_db_query($sql, $db))
   	die("Could not connect to the database.");
if (!$myrow = faqe_db_fetch_array($result))
   	die($l_noentries);
$faqcount=1;
do{
?>
<TR BGCOLOR="<?php echo $group_bgcolor?>" ALIGN="CENTER"><TD ALIGN="left" VALIGN="MIDDLE">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $GroupFontColor?>">
<?php echo $myrow["categoryname"]?></font></td></tr>
<?php
$sql = "select * from ".$tableprefix."_data where (category=".$myrow["catnr"].") and subcategory=0";
if($faqsortmethod==0)
	$sql.=" order by editdate desc";
else
	$sql.=" order by displaypos asc";
if(!$result2 = faqe_db_query($sql, $db))
   	die("Could not connect to the database.");
?>
<TR BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER"><TD ALIGN="left" VALIGN="MIDDLE">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<?php
if (!$myrow2 = faqe_db_fetch_array($result2))
	echo $l_noentries;
else
{
	do{
	$questiontext=stripslashes($myrow2["questiontext"]);
	$questiontext = undo_htmlspecialchars($questiontext);
	$answertext=stripslashes($myrow2["answertext"]);
	$answertext = undo_htmlspecialchars($answertext);
	echo "$faqcount. <a name=\"#".$myrow2["faqnr"]."\"><b>".$myrow2["heading"]."</b></a><br>";
	echo "<i>$l_question:</i><br>";
	echo $questiontext."<br>";
	echo "<i>$l_answer:</i><br>";
	echo $answertext."<br>";
	$faqcount+=1;
	$attachsql="select * from ".$tableprefix."_bindata where faqnr=".$myrow2["faqnr"];
	if(!$attachresult = faqe_db_query($attachsql, $db))
	   	die("Could not connect to the database.");
	if($attachrow=faqe_db_fetch_array($attachresult))
	{
		echo "<a href=\"download.php?faqnr=".$myrow2["faqnr"]."\">$l_attachement</a><br>";
	}
	echo "<br>";
	}while($myrow2 = faqe_db_fetch_array($result2));
}
echo "</font></td></tr>";
$sql = "select * from ".$tableprefix."_subcategory where category=".$myrow["catnr"]." order by displaypos asc";
if(!$result2 = faqe_db_query($sql, $db))
   	die("Could not connect to the database.");
if ($myrow2 = faqe_db_fetch_array($result2))
{
	do{
?>
<TR BGCOLOR="<?php echo $subcatbgcolor?>" ALIGN="CENTER"><TD ALIGN="left" VALIGN="MIDDLE">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $subcatfontcolor?>">
<i><?php echo $myrow2["categoryname"]?></i></font></td></tr>
<?php
$sql = "select * from ".$tableprefix."_data where subcategory=".$myrow2["catnr"];
if($faqsortmethod==0)
	$sql.=" order by editdate desc";
else
	$sql.=" order by displaypos asc";
if(!$result3 = faqe_db_query($sql, $db))
   	die("Could not connect to the database.");
?>
<TR BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER"><TD ALIGN="left" VALIGN="MIDDLE">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<?php
if (!$myrow3 = faqe_db_fetch_array($result3))
	echo $l_noentries;
else
{
	do{
	$questiontext=stripslashes($myrow3["questiontext"]);
	$questiontext = undo_htmlspecialchars($questiontext);
	$answertext=stripslashes($myrow3["answertext"]);
	$answertext = undo_htmlspecialchars($answertext);
	echo "$faqcount. <a name=\"#".$myrow3["faqnr"]."\"><b>".$myrow3["heading"]."</b></a><br>";
	echo "<i>$l_question:</i><br>";
	echo $questiontext."<br>";
	echo "<i>$l_answer:</i><br>";
	echo $answertext."<br>";
	$attachsql="select * from ".$tableprefix."_bindata where faqnr=".$myrow3["faqnr"];
	if(!$attachresult = faqe_db_query($attachsql, $db))
	   	die("Could not connect to the database.");
	if($attachrow=faqe_db_fetch_array($attachresult))
	{
		echo "<a href=\"download.php?faqnr=".$myrow3["faqnr"]."\">$l_attachement</a><br>";
	}
	echo "<br>";
	$faqcount+=1;
	}while($myrow3 = faqe_db_fetch_array($result3));
}
echo "</font></td></tr>";
} while($myrow2 = faqe_db_fetch_array($result2));
}
} while($myrow = faqe_db_fetch_array($result));
?>
</table></td></tr></table>
<?php
if(($usecustomfooter==1) && ($copyrightpos==0))
{
	if(($footerfile) && ($footerfilepos==0))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
	echo $pagefooter;
	if(($footerfile) && ($footerfilepos==1))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
}
?>
<table align="center" bgcolor="<?php echo $copyrightbgcolor?>" width="<?php echo $TableWidth?>" border="0">
<tr><td align="center">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<?
$actdate=date("$dateformat H:i");
echo "$l_generated: $actdate<br>";
if($showtimezone==1)
	echo "$l_timezone_note $server_timezone<br>";
?>
</font>
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize4?>" color="<?php echo $FontColor?>">
<?php
echo "$copyright_url ";
echo "$copyright_note<br>";
echo "</font></td></tr></table>";
if(($usecustomfooter==1) && ($copyrightpos==1))
{
	if(($footerfile) && ($footerfilepos==0))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
	echo $pagefooter;
	if(($footerfile) && ($footerfilepos==1))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
}
?>
</body></html>
