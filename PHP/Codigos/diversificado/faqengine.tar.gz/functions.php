<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
function language_select($default, $name="language", $dirname="language/")
{
	$dir = opendir($dirname);
	$lang_select = "<SELECT NAME=\"$name\">\n";
	while ($file = readdir($dir))
	{
		if (ereg("^lang_", $file))
		{
			$file = str_replace("lang_", "", $file);
			$file = str_replace(".php", "", $file);
			$file == $default ? $selected = " SELECTED" : $selected = "";
			$lang_select .= "  <OPTION value=\"$file\"$selected>$file\n";
		}
	}
	$lang_select .= "</SELECT>\n";
	closedir($dir);
	return $lang_select;
}

function language_list($dirname="language/")
{
	$langs = array();
	$dir = opendir($dirname);
	while($file = readdir($dir))
	{
		if (ereg("^lang_",$file))
		{
			$file = str_replace("lang_", "", $file);
			$file = str_replace(".php", "", $file);
			array_push($langs,$file);
		}
	}
	closedir($dir);
	return $langs;
}

function language_avail($checklang, $dirname="language/")
{
	$dir = opendir($dirname);
	$langfound=false;
	while ($file = readdir($dir))
	{
		if (ereg("^lang_", $file))
		{
			$file = str_replace("lang_", "", $file);
			$file = str_replace(".php", "", $file);
			if($file == $checklang)
				$langfound=true;
		}
	}
	return $langfound;
}

function dateToJuliandays($day, $month, $year)
{
	$juliandays = 367*$year - floor(7*($year+floor(($month+9)/12))/4)
      - floor(3*(floor(($year+($month-9)/7)/100)+1)/4)
      + floor(275*$month/9) + $day + 1721028.5 + 12/24;
    return $juliandays;
}

function juliandaysToDate($JD,$dateformat)
{
	$Z = $JD+0.5;
	$F = $Z - floor($Z);

	$Z = floor($Z);
	$W = floor(($Z - 1867216.25)/36524.25);
	$X = floor($W/4);
	$A = $Z + 1 + $W - $X;
	$B = $A + 1524;
	$C = floor(($B - 122.1)/365.25);
	$D = floor(365.25*$C);
	$E = floor(($B - $D)/30.6001);

	if($E>13)
		$NewMonth = $E-13;
	else
		$NewMonth = $E-1;
	$NewDay = $B - $D - floor(30.6001*$E) +$F;
	if($NewMonth<3)
		$NewYear = $C-4715;
	else
		$NewYear = $C-4716;
	$returndate=date($dateformat,mktime(0,0,0,$NewMonth,$NewDay,$NewYear));
	return $returndate;
}

function undo_htmlspecialchars($input, $quotes=true)
{
	$input = preg_replace("/&gt;/i", ">", $input);
	$input = preg_replace("/&lt;/i", "<", $input);
	if($quotes)
		$input = preg_replace("/&quot;/i", "\"", $input);
	$input = preg_replace("/&amp;/i", "&", $input);
	return $input;
}

function undo_htmlentities($input)
{
	$trans = get_html_translation_table (HTML_ENTITIES);
	$trans = array_flip($trans);
	$input=strtr($input,$trans);
	return $input;
}

function validate_email($email)
{
	$email_regex="^([-!#\$%&'*+./0-9=?A-Z^_`a-z{|}~ ])+@([-!#\$%&'*+/0-9=?A-Z^_`a-z{|}~ ]+\\.)+[a-zA-Z]{2,4}\$";
	return(eregi($email_regex,$email)!=0);
}

function format_bytes($size)
{
	if($size>(1024*1024))
		return (round($size/(1024*1024),1)." MB");
	if($size>1024)
		return (round($size/1024,1)." KBytes");
	return $size." Bytes";
}

function get_summary($text, $maxTextLength)
{
	$summarytext=stripslashes($text);
	$summarytext = undo_htmlspecialchars($summarytext);
	$summarytext = strip_tags($summarytext);
	$summarytext = substr($summarytext,0,$maxTextLength);
	if(strlen($text)>$maxTextLength)
		$summarytext.="...";
	return $summarytext;
}

function is_phpfile($filename)
{
	global $php_fileext;
	$fileext=strrchr($filename,".");
	if(!$fileext)
		return false;
	$fileext=strtolower(substr($fileext,1));
	if(in_array($fileext,$php_fileext))
	{
		$fdat=get_file($filename);
		return true;
	}
	return false;
}

function file_output($filename)
{
	$filedata=get_file($filename);
	if($filedata)
	{
		$filedata=str_replace("</body>","",$filedata);
		$filedata=str_replace("</html>","",$filedata);
		echo $filedata;
	}
}

function get_file($filename)
{
	$return = "";
	if($fp = fopen($filename, 'rb'))
	{
		while(!feof($fp)){
			$return .= fread($fp, 1024);
		}
		fclose($fp);
		return $return;
	}
	else
	{
		return FALSE;
	}
}

function faqe_array_key_exists($searcharray, $searchkey)
{
	$arraykeys=array_keys($searcharray);
	for($i=0;$i<count($arraykeys);$i++)
	{
		if($arraykeys[$i]==$searchkey)
			return true;
	}
	return false;
}
?>