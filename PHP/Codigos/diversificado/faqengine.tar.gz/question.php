<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('./config.php');
require('./functions.php');
if(isset($HTTP_COOKIE_VARS[$cookiename]) && !isset($submit))
{
	$cookiedata=$HTTP_COOKIE_VARS[$cookiename];
	if(faqe_array_key_exists($cookiedata,"email"))
		$cookieemail=$cookiedata["email"];
	if(isset($submit) && !isset($storedata))
		setcookie($cookiename."[email]","",time()-(24*60*60),$cookiepath,$cookiedomain,$cookiesecure);
}
if(isset($submit) && isset($storedata))
{
	setcookie($cookiename."[email]",$email,1,$cookiepath,$cookiedomain,$cookiesecure);
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<?php
$sql = "select * from ".$tableprefix."_layout where (layoutnr=1)";
if(!$result = faqe_db_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = faqe_db_fetch_array($result))
{
	$FontFace=$myrow["fontface"];
	$FontSize1=$myrow["fontsize1"];
	$FontSize2=$myrow["fontsize2"];
	$FontSize3=$myrow["fontsize3"];
	$FontSize4=$myrow["fontsize4"];
	$FontSize5=$myrow["fontsize5"];
	$FontColor=$myrow["fontcolor"];
	$TableWidth=$myrow["tablewidth"];
	$heading_bgcolor=$myrow["headingbg"];
	$table_bgcolor=$myrow["bgcolor1"];
	$row_bgcolor=$myrow["bgcolor2"];
	$group_bgcolor=$myrow["bgcolor3"];
	$page_bgcolor=$myrow["pagebg"];
	$stylesheet=stripslashes($myrow["stylesheet"]);
	$show_proglist=$myrow["showproglist"];
	$HeadingFontColor=$myrow["headingfontcolor"];
	$SubheadingFontColor=$myrow["subheadingfontcolor"];
	$GroupFontColor=$myrow["groupfontcolor"];
	$LinkColor=$myrow["linkcolor"];
	$VLinkColor=$myrow["vlinkcolor"];
	$ALinkColor=$myrow["alinkcolor"];
	$TableDescFontColor=$myrow["tabledescfontcolor"];
	$dateformat=$myrow["dateformat"];
	$newtime=$myrow["newtime"];
	$searchpic=$myrow["searchpic"];
	$printpic=$myrow["printpic"];
	$backpic=$myrow["backpic"];
	$pageheader=$myrow["pageheader"];
	$pagefooter=$myrow["pagefooter"];
	$usecustomheader=$myrow["usecustomheader"];
	$usecustomfooter=$myrow["usecustomfooter"];
	$allowemail=$myrow["allowemail"];
	$allowquestions=$myrow["allowquestions"];
	$faqemail=$myrow["faqemail"];
	$server_timezone=$myrow["timezone"];
	$headerfile=$myrow["headerfile"];
	$footerfile=$myrow["footerfile"];
	$minquestionlength=$myrow["minquestionlength"];
	$textareacols=$myrow["textareawidth"];
	$textarearows=$myrow["textareaheight"];
	$enablelanguageselector=$myrow["enablelanguageselector"];
	$copyrightbgcolor=$myrow["copyrightbgcolor"];
	$showcurrtime=$myrow["showcurrtime"];
	$showtimezone=$myrow["showtimezone"];
	$copyrightpos=$myrow["copyrightpos"];
	$subheadingbgcolor=$myrow["subheadingbgcolor"];
	$actionbgcolor=$myrow["actionbgcolor"];
	$headerfilepos=$myrow["headerfilepos"];
	$footerfilepos=$myrow["footerfilepos"];
	$newinfobgcolor=$myrow["newinfobgcolor"];
	$addbodytags=$myrow["addbodytags"];
	$questionrequireos=$myrow["questionrequireos"];
	$questionrequireversion=$myrow["questionrequireversion"];
	$pagetoppic=$myrow["pagetoppic"];
	$faqengine_hostname=$myrow["faqengine_hostname"];
	if(!$faqemail)
		$faqemail="faq@foo.bar";
	if((!$pageheader) && (!$headerfile))
		$usecustomheader=0;
	if((!$pagefooter) && (!$footerfile))
		$usecustomfooter=0;
	$dateformat.=" H:i:s";
}
else
	die("Layout not set up");
if(!isset($$langvar) || !$$langvar)
	$act_lang=$default_lang;
else
	$act_lang=$$langvar;
if(!language_avail($act_lang))
	die ("Language <b>$act_lang</b> not configured");
include('./language/lang_'.$act_lang.'.php');
if((@fopen("./config.php", "a")) && !$testmode)
{
	die($l_config_writeable);
}
if($allowquestions!=1)
{
	die($l_disallowed);
}
if(isset($prog) && ($prog) && !isset($newprog))
	$newprog=$prog;
?>
<html>
<head>
<meta name="generator" content="FAQEngine v<?php echo $version?>, <?php echo $copyright_asc?>">
<?php
if($stylesheet)
	echo"<link rel=stylesheet href=\"$stylesheet\" type=\"text/css\">";
if(file_exists("./metadata.php"))
	include ("./metadata.php");
else
{
?>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<title><?php echo $l_heading?></title>
<?php
}
?>
</head>
<body bgcolor="<?php echo $page_bgcolor?>" link="<?php echo $LinkColor?>" vlink="<?php echo $VLinkColor?>" alink="<?php echo $ALinkColor?>" text="<?php echo $FontColor?>" <?php echo $addbodytags?>>
<?php
if($usecustomheader==1)
{
	if(($headerfile) && ($headerfilepos==0))
	{
		if(is_phpfile($headerfile))
			include($headerfile);
		else
			file_output($headerfile);
	}
	echo $pageheader;
	if(($headerfile) && ($headerfilepos==1))
	{
		if(is_phpfile($headerfile))
			include($headerfile);
		else
			file_output($headerfile);
	}
}
?>
<table width="<?php echo $TableWidth?>" border="0" CELLPADDING="1" CELLSPACING="0" ALIGN="CENTER" VALIGN="TOP">
<tr><TD BGCOLOR="<?php echo $table_bgcolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<TR BGCOLOR="<?php echo $heading_bgcolor?>" ALIGN="CENTER">
<TD class="mainheading" ALIGN="CENTER" VALIGN="MIDDLE" colspan="2"><a name="#top"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize3?>" color="<?php echo $HeadingFontColor?>"><b><?php echo $l_heading?></b></font></a></td>
<?php
$sql = "select * from ".$tableprefix."_misc";
if(!$result = faqe_db_query($sql, $db)) {
    die("<tr bgcolor=\"$heading_bgcolor\" align=\"center\"><td>Could not connect to the database.");
}
if ($myrow = faqe_db_fetch_array($result))
{
	if($myrow["shutdown"]==1)
	{
?>
</tr></table></td></tr>
<tr><TD BGCOLOR="<?php echo $table_bgcolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<?php
		$shutdowntext=stripslashes($myrow["shutdowntext"]);
		$shutdowntext = undo_htmlspecialchars($shutdowntext);
		echo $shutdowntext;
		echo "</font></td></tr></table></td></tr></table>";
		echo "<br><div align=\"center\"><font face=\"$FontFace\" SIZE=\"$FontSize4\">$l_timezone_note $server_timezone<br>Generated by $copyright_url<br>$copyright_note</font></div>";
		exit;
	}
}
if(isset($mode))
{
	if($mode=="display")
		$heading=$l_displayquestions;
	if($mode=="read")
		$heading=$l_displayquestions;
}
else
{
	if($type=="followup")
		$heading=$l_write_followup;
	else
		$heading = $l_askquestion;
}
?>
<tr BGCOLOR="<?php echo $subheadingbgcolor?>" ALIGN="CENTER">
<TD class=\"subheading\" ALIGN="CENTER" VALIGN="MIDDLE" width="95%"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $SubheadingFontColor?>"><b><?php echo $heading?></b></font>
</td>
<td align="right" valign="MIDDLE" width="5%">
<?php
if(isset($backurl))
{
	echo "<a class=\"backurl\" href=\"$backurl\">";
}
else if(isset($faqnr) && ($faqnr>0))
{
	echo "<a class=\"backurl\" href=\"faq.php?display=faq&amp;nr=$faqnr&amp;catnr=$catnr&amp;prog=$prog&amp;$langvar=$act_lang";
	if(isset($onlynewfaq))
		echo "&amp;onlynewfaq=$onlynewfaq";
	echo "\">";
}
else
{
$faqnr=0;
if(isset($prog))
{
	echo "<a class=\"backurl\" href=\"faq.php?list=all&amp;prog=$prog&amp;$langvar=$act_lang";
	if(isset($onlynewfaq))
		echo "&amp;onlynewfaq=$onlynewfaq";
	echo "\">";
}
else
{
	echo "<a class=\"backurl\" href=\"faq.php?list=progs&amp;$langvar=$act_lang";
	if(isset($onlynewfaq))
		echo "&amp;onlynewfaq=$onlynewfaq";
	echo "\">";
}
}
?>
<img class="backurl" src="<?php echo $backpic?>" border="0" alt="<?php echo $l_faqlink?>"></a></td>
</tr></table></td></tr>
<tr><TD BGCOLOR="<?php echo $table_bgcolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<?php
if(isset($mode))
{
	if($mode=="read")
	{
		$sql = "select * from ".$tableprefix."_questions where questionnr=$question";
		if(!$result = faqe_db_query($sql, $db))
		{
			echo "<tr><td bgcolor=\"$heading_bgcolor\">";
	    	die("Could not connect to the database.");
	    }
		if (!$myrow = faqe_db_fetch_array($result))
		{
			echo "<tr bgcolor=\"$group_bgcolor\" align=\"center\"><td>";
			echo "<font face=\"$FontFace\" SIZE=\"$FontSize5\" color=\"$FontColor\">";
			echo "$l_noentries</font></td></tr>";
		}
		else
		{
			list($mydate,$mytime)=explode(" ",$myrow["enterdate"]);
			list($year, $month, $day) = explode("-", $mydate);
			list($hour, $min, $sec) = explode(":",$mytime);
			if($month>0)
				$displaydate=date($dateformat,mktime($hour,$min,$sec,$month,$day,$year));
			else
			$displaydate="";
			$questiontext=htmlentities($myrow["question"]);
			$questiontext=str_replace("\n","<BR>",$questiontext);
			echo "<tr bgcolor=\"$group_bgcolor\">";
			echo "<td class=\"posterline\" colspan=\"2\">";
			echo "<font face=\"$FontFace\" SIZE=\"$FontSize2\" color=\"$FontColor\">";
			echo "<b>".$myrow["email"]."</b> $l_on $displaydate</font>";
			echo "<tr bgcolor=\"$row_bgcolor\">";
			echo "<td class=\"question\" width=\"25%\" valign=\"top\">";
			echo "<font face=\"$FontFace\" SIZE=\"$FontSize2\" color=\"$FontColor\">";
			echo "$l_question:";
			echo "</font></td>";
			echo "<td class=\"question\" width=\"75%\">";
			echo "<font face=\"$FontFace\" SIZE=\"$FontSize2\" color=\"$FontColor\">";
			echo "$questiontext</font></td>";
			echo "</tr>";
			if($myrow["answerauthor"]>0)
			{
				list($mydate,$mytime)=explode(" ",$myrow["answerdate"]);
				list($year, $month, $day) = explode("-", $mydate);
				list($hour, $min, $sec) = explode(":",$mytime);
				if($month>0)
					$displaydate=date($dateformat,mktime($hour,$min,$sec,$month,$day,$year));
				else
					$displaydate="";
				$answertext=$myrow["answer"]."\n($displaydate)";
				$answertext=htmlentities($answertext);
				$answertext=str_replace("\n","<BR>",$answertext);
				echo "<tr bgcolor=\"$row_bgcolor\">";
				echo "<td class=\"answer\" width=\"25%\" valign=\"top\">";
				echo "<font face=\"$FontFace\" SIZE=\"$FontSize2\" color=\"$FontColor\">";
				echo "$l_answer:";
				echo "</font></td>";
				echo "<td class=\"answer\" width=\"75%\">";
				echo "<font face=\"$FontFace\" SIZE=\"$FontSize2\" color=\"$FontColor\">";
				echo "$answertext</font></td>";
				echo "</tr>";
			}
		}
		echo "</table></td></tr></table>";
		if(($usecustomfooter==1) && ($copyrightpos==0))
		{
			if(($footerfile) && ($footerfilepos==0))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
			echo $pagefooter;
			if(($footerfile) && ($footerfilepos==1))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
		}
?>
<br>
<table align="center" bgcolor="<?php echo $copyrightbgcolor?>" width="<?php echo $TableWidth?>" border="0">
<tr><td align="center" class="copyright">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize4?>" color="<?php echo $FontColor?>">
<?php
		if($showcurrtime)
		{
			$displaytime=date("H:i");
			echo "$l_currtime $displaytime<br>";
		}
		if($showtimezone==1)
			echo "$l_timezone_note $server_timezone<br>";
		echo "Generated by $copyright_url, $copyright_note";
?>
</td></tr></table>
<br>
<?php
		if(($usecustomfooter==1) && ($copyrightpos==1))
		{
			if(($footerfile) && ($footerfilepos==0))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
			echo $pagefooter;
			if(($footerfile) && ($footerfilepos==1))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
		}
		echo "</body></html>";
		exit;
	}
	if($mode=="display")
	{
		if(!isset($questionref))
			$sql = "select * from ".$tableprefix."_questions where faqref=$faqnr and publish=1 and questionref=0 order by enterdate desc";
		else
			$sql = "select * from ".$tableprefix."_questions where publish=1 and questionref=$questionref order by enterdate desc";
		if(!$result = faqe_db_query($sql, $db))
		{
			echo "<tr><td bgcolor=\"$heading_bgcolor\">";
	    	die("Could not connect to the database.");
	    }
		if (!$myrow = faqe_db_fetch_array($result))
		{
			echo "<tr bgcolor=\"$group_bgcolor\" align=\"center\"><td>";
			echo "<font face=\"$FontFace\" SIZE=\"$FontSize5\" color=\"$FontColor\">";
			echo "$l_noentries</font></td></tr>";
		}
		else
		{
			do{
				list($mydate,$mytime)=explode(" ",$myrow["enterdate"]);
				list($year, $month, $day) = explode("-", $mydate);
				list($hour, $min, $sec) = explode(":",$mytime);
				if($month>0)
					$displaydate=date($dateformat,mktime($hour,$min,$sec,$month,$day,$year));
				else
					$displaydate="";
				$questiontext=htmlentities($myrow["question"]);
				$questiontext=str_replace("\n","<BR>",$questiontext);
				echo "<tr bgcolor=\"$group_bgcolor\">";
				echo "<td class=\"posterline\" colspan=\"2\">";
				echo "<font face=\"$FontFace\" SIZE=\"$FontSize5\" color=\"$FontColor\">";
				echo "<b>".$myrow["email"]."</b> $l_on $displaydate</font></td></tr>";
				echo "<tr bgcolor=\"$row_bgcolor\">";
				echo "<td class=\"question\" width=\"25%\" valign=\"top\">";
				echo "<font face=\"$FontFace\" SIZE=\"$FontSize2\" color=\"$FontColor\">";
				echo "$l_question:";
				echo "</font></td>";
				echo "<td class=\"question\" width=\"75%\">";
				echo "<font face=\"$FontFace\" SIZE=\"$FontSize2\" color=\"$FontColor\">";
				echo "$questiontext</font></td>";
				echo "</tr>";
				if($myrow["answerauthor"]>0)
				{
					list($mydate,$mytime)=explode(" ",$myrow["answerdate"]);
					list($year, $month, $day) = explode("-", $mydate);
					list($hour, $min, $sec) = explode(":",$mytime);
					if($month>0)
						$displaydate=date($dateformat,mktime($hour,$min,$sec,$month,$day,$year));
					else
						$displaydate="";
					$answertext=$myrow["answer"]."\n($displaydate)";
					$answertext=htmlentities($answertext);
					$answertext=str_replace("\n","<BR>",$answertext);
					echo "<tr bgcolor=\"$row_bgcolor\">";
					echo "<td class=\"answer\" width=\"25%\" valign=\"top\">";
					echo "<font face=\"$FontFace\" SIZE=\"$FontSize2\" color=\"$FontColor\">";
					echo "$l_answer:";
					echo "</font></td>";
					echo "<td class=\"answer\" width=\"75%\">";
					echo "<font face=\"$FontFace\" SIZE=\"$FontSize2\" color=\"$FontColor\">";
					echo "$answertext</font></td>";
					echo "</tr>";
				}
				$tempsql="select * from ".$tableprefix."_questions where questionref=".$myrow["questionnr"]." and publish=1";
				if(!$tempresult = faqe_db_query($tempsql, $db))
				{
					echo "<tr><td bgcolor=\"$heading_bgcolor\">";
    				die("Could not connect to the database.");
    			}
				if ($temprow = faqe_db_fetch_array($tempresult))
				{
					echo "<tr bgcolor=\"$row_bgcolor\"><td class=\"userquestions\" colspan=\"2\">";
					echo "<font face=\"$FontFace\" SIZE=\"$FontSize1\" color=\"$FontColor\">";
					echo faqe_db_num_rows($tempresult)." $l_followup_questions";
					echo "&nbsp;&nbsp;&nbsp;(<a class=\"userquestions\" href=\"question.php?prog=$prog&amp;catnr=$catnr&amp;faqnr=$faqnr&amp;mode=display&amp;questionref=".$myrow["questionnr"]."&amp;$langvar=$act_lang";
					if(isset($onlynewfaq))
						echo "&amp;onlynewfaq=$onlynewfaq";
					echo "\">$l_display</a>)</font></td></tr>";
				}
				echo "<tr bgcolor=\"$actionbgcolor\"><td colspan=\"2\" align=\"center\">";
				echo "<table width=\"100%\" bgcolor=\"$actionbgcolor\" cellpadding=\"0\" cellspacing=\"0\">";
				echo "<tr><td class=\"userquestions\" align=\"center\" width=\"99%\">";
				if($myrow["questionref"]!=0)
					$refnr=$myrow["questionref"];
				else
					$refnr=$myrow["questionnr"];
				echo "<font face=\"$FontFace\" SIZE=\"$FontSize1\" color=\"$FontColor\">";
				echo "<a class=\"userquestions\" href=\"question.php?prog=$prog&amp;catnr=$catnr&amp;faqnr=$faqnr&amp;type=followup&amp;$langvar=$act_lang&amp;questionref=$refnr";
				if(isset($onlynewfaq))
					echo "&amp;onlynewfaq=$onlynewfaq";
				echo "\">$l_followup</a></font></td>";
?>
<td class="gototop" align="right" width="1%"><a class="gototop" href="#top"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize4?>"><img class="gototop" src="<?php echo $pagetoppic?>" border="0" align="middle" alt="<?php echo $l_top?>"></a></td>
<?php
				echo "</tr></table></td></tr>";
			}while($myrow=faqe_db_fetch_array($result));
		}
		echo "</table></td></tr></table>";
		if(($usecustomfooter==1) && ($copyrightpos==0))
		{
			if(($footerfile) && ($footerfilepos==0))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
			echo $pagefooter;
			if(($footerfile) && ($footerfilepos==1))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
		}
?>
<br>
<table align="center" bgcolor="<?php echo $copyrightbgcolor?>" width="<?php echo $TableWidth?>" border="0">
<tr><td class="copyright" align="center">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize4?>" color="<?php echo $FontColor?>">
<?php
		if($showcurrtime)
		{
			$displaytime=date("H:i");
			echo "$l_currtime $displaytime<br>";
		}
		if($showtimezone==1)
			echo "$l_timezone_note $server_timezone<br>";
		echo "Generated by $copyright_url, $copyright_note";
?>
</td></tr></table>
<br>
<?php
		if(($usecustomfooter==1) && ($copyrightpos==1))
		{
			if(($footerfile) && ($footerfilepos==0))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
			echo $pagefooter;
			if(($footerfile) && ($footerfilepos==1))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
		}
		echo "</body></html>";
		exit;
	}
}
if(isset($submit))
{
	$errors=0;
	if((!$email) || (!validate_email($email)))
	{
		echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td class=\"error\">";
		echo "<font face=\"$FontFace\" SIZE=\"$FontSize2\" color=\"$FontColor\">";
		echo "$l_invalidemail</font></td></tr>";
		$errors=1;
	}
	if(!$osname && ($questionrequireos==1))
	{
		echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td class=\"error\">";
		echo "<font face=\"$FontFace\" SIZE=\"$FontSize2\" color=\"$FontColor\">";
		echo "$l_noos</font></td></tr>";
		$errors=1;
	}
	if(!$question)
	{
		echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td class=\"error\">";
		echo "<font face=\"$FontFace\" SIZE=\"$FontSize2\" color=\"$FontColor\">";
		echo "$l_noquestion</font></td></tr>";
		$errors=1;
	}
	else if(strlen($question)<$minquestionlength)
	{
		echo "<tr bgcolor=\"$group_bgcolor\" align=\"center\"><td class=\"error\">";
		echo "<font face=\"$FontFace\" SIZE=\"$FontSize2\" color=\"$FontColor\">";
		echo "$l_shortquestion<br>$l_minlength $minquestionlength $l_characters.<br>($l_entered: ".strlen($question).")</font></td></tr>";
		$errors=1;
	}
	if(!isset($questionref))
		$questionref=0;
	if($errors==0)
	{
		if(!isset($questionref))
			$questionref=0;
		$actdate = date("Y-m-d H:i:s");
		$question=strip_tags($question);
		$question=addslashes($question);
		$sql ="insert into ".$tableprefix."_questions (prognr, osname, versionnr, email, question, enterdate, faqref, posterip, language, questionref) ";
		$sql .="values ($input_prognr, '$osname', '$usedversion', '$email', '$question', '$actdate', $faqnr, '$REMOTE_ADDR', '$act_lang', $questionref)";
		if(!$result = faqe_db_query($sql, $db)) {
		    die("<tr bgcolor=\"$heading_bgcolor\" align=\"center\"><td>Could not connect to the database.");
		}
		$questionnr=faqe_db_insert_id($db);
		$sql ="select u.* from ".$tableprefix."_admins u, ".$tableprefix."_programm_admins pa where ((pa.prognr='$input_prognr' and pa.usernr=u.usernr) or (u.rights>2)) group by u.usernr";
		if(!$result = faqe_db_query($sql, $db))
		    die("<tr bgcolor=\"$heading_bgcolor\" align=\"center\"><td>Could not connect to the database.");
		if ($myrow = faqe_db_fetch_array($result))
		{
			$fromadr = "From:".$faqemail."\r\n";
			$questionlink = "http://".$faqengine_hostname.$url_faqengine."/admin/userquestions.php?mode=display&input_questionnr=".$questionnr;
			do{
				if(strlen($myrow["email"])>1)
				{
					$tempsql="select * from ".$tableprefix."_texts where textid='uqsubj' and lang='".$myrow["language"]."'";
					if(!$tempresult = faqe_db_query($tempsql, $db))
					    die("<tr bgcolor=\"$heading_bgcolor\" align=\"center\"><td>Could not connect to the database.");
					if($temprow=faqe_db_fetch_array($tempresult))
					{
						$subject=undo_htmlentities($temprow["text"]);
						$subject=strip_tags($subject);
					}
					else
						$subject="FAQEngine - new user question";
					$tempsql="select * from ".$tableprefix."_texts where textid='uqbody' and lang='".$myrow["language"]."'";
					if(!$tempresult = faqe_db_query($tempsql, $db))
					    die("<tr bgcolor=\"$heading_bgcolor\" align=\"center\"><td>Could not connect to the database.");
					if($temprow=faqe_db_fetch_array($tempresult))
					{
						$mailmsg=undo_htmlentities($temprow["text"]);
						$mailmsg=str_replace("<BR>","\n",$mailmsg);
						$mailmsg=strip_tags($mailmsg);
						$mailmsg=str_replace("{qnr}",$questionnr,$mailmsg);
						$mailmsg=str_replace("{qlink}",$questionlink,$mailmsg);
					}
					else
						$mailmsg="New user question # $questionnr\nClick on this link to see:\n$questionlink";
					mail($myrow["email"],$subject,$mailmsg,$fromadr);
				}
			}while($myrow = faqe_db_fetch_array($result));
		}
		echo "<tr bgcolor=\"$group_bgcolor\" align=\"center\"><td class=\"actionmsg\">";
		echo "<font face=\"$FontFace\" SIZE=\"$FontSize2\" color=\"$FontColor\">";
		echo $l_questiondone;
		echo "</font></td></tr></table></td></tr></table>";
	}
	else
	{
		echo "<tr bgcolor=\"$actionbgcolor\" align=\"center\"><td class=\"error\">";
		echo "<font face=\"$FontFace\" SIZE=\"$FontSize2\" color=\"$FontColor\">";
		echo "<a class=\"error\" href=\"javascript:history.back()\">$l_back</a>";
		echo "</font></td></tr></table></td></tr></table>";
	}
	if(($usecustomfooter==1) && ($copyrightpos==0))
	{
		if(($footerfile) && ($footerfilepos==0))
		{
			if(is_phpfile($footerfile))
				include($footerfile);
			else
				file_output($footerfile);
		}
		echo $pagefooter;
		if(($footerfile) && ($footerfilepos==1))
		{
			if(is_phpfile($footerfile))
				include($footerfile);
			else
				file_output($footerfile);
		}
	}
?>
<br>
<table align="center" bgcolor="<?php echo $copyrightbgcolor?>" width="<?php echo $TableWidth?>" border="0">
<tr><td align="center" class="copyright">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize4?>" color="<?php echo $FontColor?>">
<?php
	if($showcurrtime)
	{
		$displaytime=date("H:i");
		echo "$l_currtime $displaytime<br>";
	}
	if($showtimezone==1)
		echo "$l_timezone_note $server_timezone<br>";
	echo "Generated by $copyright_url, $copyright_note";
?>
</td></tr></table>
<br>
<?php
	if(($usecustomfooter==1) && ($copyrightpos==1))
	{
		if(($footerfile) && ($footerfilepos==0))
		{
			if(is_phpfile($footerfile))
				include($footerfile);
			else
				file_output($footerfile);
		}
		echo $pagefooter;
		if(($footerfile) && ($footerfilepos==1))
		{
			if(is_phpfile($footerfile))
				include($footerfile);
			else
				file_output($footerfile);
		}
	}
	echo "</body></html>";
	exit;
}
$sql = "select * from ".$tableprefix."_texts where textid='questpre' and lang='$act_lang'";
if(!$result = faqe_db_query($sql, $db)) {
    die("<tr bgcolor=\"$heading_bgcolor\" align=\"center\"><td>Could not connect to the database.");
}
if($myrow=faqe_db_fetch_array($result))
{
	$displaytext=stripslashes($myrow["text"]);
	$displaytext = undo_htmlspecialchars($displaytext);
	echo "<tr bgcolor=\"$group_bgcolor\"><td align=\"center\" colspan=\"2\">";
	echo "<font face=\"$FontFace\" SIZE=\"$FontSize2\" color=\"$FontColor\">";
	echo $displaytext;
	echo "</font></td></tr>\n";
}
?>
<form method="post" action="<?php echo $PHP_SELF?>">
<?php
	if(isset($onlynewfaq))
		echo "<input type=\"hidden\" name=\"onlynewfaq\" value=\"$onlynewfaq\">";
?>
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="faqnr" value="<?php echo $faqnr?>">
<?php
	if(isset($prog) && $prog)
		echo "<input type=\"hidden\" name=\"prog\" value=\"$prog\">";
?>
<input type="hidden" name="type" value="<?php echo $type?>">
<?php
if($type=="followup")
{
	echo "<input type=\"hidden\" name=\"questionref\" value=\"$questionref\">";
	echo "<input type=\"hidden\" name=\"catnr\" value=\"$catnr\">";
}
?>
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<TD ALIGN="right" width="30%" class="questionform"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>"><?php echo $l_progname?>:</font></td>
<td align="left" width="70%" class="questionform">
<?php
$progdefined=false;
if(isset($newprog))
{
	$sql = "select * from ".$tableprefix."_programm where progid='$newprog' and language = '$act_lang'";
	if(!$result = faqe_db_query($sql, $db)) {
	    die("<tr bgcolor=\"$heading_bgcolor\" align=\"center\"><td>Could not connect to the database.");
	}
	if ($myrow = faqe_db_fetch_array($result))
	{
		$input_prognr=$myrow["prognr"];
		echo "<input type=\"hidden\" name=\"input_prognr\" value=\"$input_prognr\">";
		$progdefined=true;
	}
}
if($progdefined)
{
	echo "<font face=\"$FontFace\" SIZE=\"$FontSize2\" color=\"$FontColor\">";
	echo htmlentities($myrow["programmname"]);
	echo "</font>";
}
else
{
	$sql = "select * from ".$tableprefix."_programm where language = '$act_lang'";
	if(!$result = faqe_db_query($sql, $db)) {
	    die("Could not connect to the database.");
	}
	if ($myrow = faqe_db_fetch_array($result))
	{
		echo "<font face=\"$FontFace\" SIZE=\"$FontSize2\" color=\"$FontColor\">";
		echo "<select name=\"newprog\">";
		do{
			echo "<OPTION VALUE=\"".$myrow["progid"]."\" >".htmlentities($myrow["programmname"])."</OPTION>\n";
		} while($myrow = faqe_db_fetch_array($result));
		echo "</select>";
		echo "</font></td></tr>";
		echo "<tr bgcolor=\"$actionbgcolor\"><td class=\"questionform\" colspan=\"2\" align=\"center\"><input type=\"submit\" value=\"$l_select\"></td></tr>";
		echo "</form></table></td></tr></table>";
		echo "<br>";
		if(($usecustomfooter==1) && ($copyrightpos==0))
		{
			if(($footerfile) && ($footerfilepos==0))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
			echo $pagefooter;
			if(($footerfile) && ($footerfilepos==1))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
		}
?>
<br>
<table align="center" bgcolor="<?php echo $copyrightbgcolor?>" width="<?php echo $TableWidth?>" border="0">
<tr><td align="center" class="copyright">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize4?>" color="<?php echo $FontColor?>">
<?php
		if($showcurrtime)
		{
			$displaytime=date("H:i");
			echo "$l_currtime $displaytime<br>";
		}
		if($showtimezone==1)
			echo "$l_timezone_note $server_timezone<br>";
		echo "Generated by $copyright_url, $copyright_note";
?>
</td></tr></table>
<br>
<?php
		if(($usecustomfooter==1) && ($copyrightpos==1))
		{
			if(($footerfile) && ($footerfilepos==0))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
			echo $pagefooter;
			if(($footerfile) && ($footerfilepos==1))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
		}
		echo "</body></html>";
		echo"</body></html>";
		exit;
	}
	else
		die ($l_noprogsdefined);
}
?>
</td></tr>
<?php
echo "<font face=\"$FontFace\" SIZE=\"$FontSize2\" color=\"$FontColor\">";
$sql = "select os.* from ".$tableprefix."_os os, ".$tableprefix."_prog_os po where po.prognr='$input_prognr' and os.osnr=po.osnr order by os.osnr";
if(!$result = faqe_db_query($sql, $db)) {
    die("<tr bgcolor=\"$heading_bgcolor\" align=\"center\"><td>Could not connect to the database.");
}
if ($myrow = faqe_db_fetch_array($result))
{
?>
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<TD ALIGN="right" width="30%" class="questionform"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>"><?php echo $l_os?>:</font></td>
<td align="left" width="70%" class="questionform">
<?php
	echo "<select name=\"osname\">";
	do{
		echo "<OPTION VALUE=\"".$myrow["osname"]."\" >".htmlentities($myrow["osname"])."</OPTION>\n";
	} while($myrow = faqe_db_fetch_array($result));
	echo "</select>";
	echo "</font></td></tr>";
}
else if($questionrequireos==1)
{
?>
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<TD ALIGN="right" width="30%" class="questionform"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>"><?php echo $l_os?>:</font></td>
<td align="left" width="70%" class="questionform">
<input type="text" name="osname" size ="40" maxlength="180">
</font></td></tr>
<?php
}
else
	echo "<input type=\"hidden\" name=\"osname\" value=\"\">";
if(isset($catnr))
	echo "<input type=\"hidden\" name=\"catnr\" value=\"$catnr\">";
?>
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<?
$sql = "select * from ".$tableprefix."_programm_version where programm=$input_prognr";
if(!$result = faqe_db_query($sql, $db)) {
    die("<tr bgcolor=\"$heading_bgcolor\" align=\"center\"><td>Could not connect to the database.");
}
if ($myrow = faqe_db_fetch_array($result))
{
?>
<TD ALIGN="right" width="30%" class="questionform"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>"><?php echo $l_usedversion?>:</font></td>
<td align="left" width="70%" class="questionform"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<?php
	echo "<select name=\"usedversion\">";
	do{
		echo "<OPTION VALUE=\"".$myrow["version"]."\" >".htmlentities($myrow["version"])."</OPTION>\n";
	} while($myrow = faqe_db_fetch_array($result));
	echo "</select>";
	echo "</font></td></tr>";
}
else if($questionrequireversion==1)
{
?>
<TD ALIGN="right" width="30%" class="questionform"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>"><?php echo $l_usedversion?>:</font></td>
<td align="left" width="70%" class="questionform"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<input type="text" name="usedversion" size="10" maxlength="10">
</font></td></tr>
<?php
}
else
	echo "<input type=\"hidden\" name=\"usedversion\" value=\"\">";
?>
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<TD ALIGN="right" width="30%" class="questionform"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>"><?php echo $l_sendermail?>:</font></td>
<td align="left" width="70%" class="questionform"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<input type="text" name="email" size="30" maxlength="140" <?php if(isset($cookieemail)) echo "value=\"$cookieemail\""?>>
</font></td></tr>
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<TD ALIGN="right" width="30%" valign="top" class="questionform"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>"><?php echo $l_question?>:</font>
<?php
if($minquestionlength>0)
	echo "<br><font face=\"$FontFace\" size=\"$FontSize4\" color=\"$FontColor\">($l_min $minquestionlength $l_characters)</font>";
?>
</td>
<td align="left" width="70%" class="questionform"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<textarea name="question" rows="<?php echo $textarearows?>" cols="<?php echo $textareacols?>" wrap="virtual"></textarea>
</font></td></tr>
<tr bgcolor="<?php echo $row_bgcolor?>">
<td>&nbsp;</td><td align="left" class="questionform"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>"><input type="checkbox" name="storedata" value="1" <?php if(isset($storedata) || isset($cookieemail)) echo "checked"?>><?php echo $l_storedata?></font></td></tr>
<tr bgcolor="<?php echo $actionbgcolor?>"><td class="questionform" colspan="2" align="center"><input type="submit" name="submit" value="<?php echo $l_submit?>"></td></tr>
</form>
</table></td></tr></table>
<?
if(($usecustomfooter==1) && ($copyrightpos==0))
{
	if(($footerfile) && ($footerfilepos==0))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
	echo $pagefooter;
	if(($footerfile) && ($footerfilepos==1))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
}
?>
<br>
<table align="center" bgcolor="<?php echo $copyrightbgcolor?>" width="<?php echo $TableWidth?>" border="0">
<tr><td align="center" class="copyright">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize4?>" color="<?php echo $FontColor?>">
<?php
if($showcurrtime)
{
	$displaytime=date("H:i");
	echo "$l_currtime $displaytime<br>";
}
if($showtimezone==1)
	echo "$l_timezone_note $server_timezone<br>";
echo "Generated by $copyright_url, $copyright_note";
?>
</td></tr></table>
<br>
<?php
if(($usecustomfooter==1) && ($copyrightpos==1))
{
	if(($footerfile) && ($footerfilepos==0))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
	echo $pagefooter;
	if(($footerfile) && ($footerfilepos==1))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
}
?>
</body></html>
