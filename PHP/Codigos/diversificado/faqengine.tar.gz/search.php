<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('./config.php');
require('./functions.php');
$sql = "select * from ".$tableprefix."_layout where (layoutnr=1)";
if(!$result = faqe_db_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = faqe_db_fetch_array($result))
{
	$FontFace=$myrow["fontface"];
	$FontSize1=$myrow["fontsize1"];
	$FontSize2=$myrow["fontsize2"];
	$FontSize3=$myrow["fontsize3"];
	$FontSize4=$myrow["fontsize4"];
	$FontSize5=$myrow["fontsize5"];
	$FontColor=$myrow["fontcolor"];
	$TableWidth=$myrow["tablewidth"];
	$heading_bgcolor=$myrow["headingbg"];
	$table_bgcolor=$myrow["bgcolor1"];
	$row_bgcolor=$myrow["bgcolor2"];
	$group_bgcolor=$myrow["bgcolor3"];
	$page_bgcolor=$myrow["pagebg"];
	$stylesheet=stripslashes($myrow["stylesheet"]);
	$show_proglist=$myrow["showproglist"];
	$HeadingFontColor=$myrow["headingfontcolor"];
	$SubheadingFontColor=$myrow["subheadingfontcolor"];
	$GroupFontColor=$myrow["groupfontcolor"];
	$LinkColor=$myrow["linkcolor"];
	$VLinkColor=$myrow["vlinkcolor"];
	$ALinkColor=$myrow["alinkcolor"];
	$TableDescFontColor=$myrow["tabledescfontcolor"];
	$newtime=$myrow["newtime"];
	$newpic=$myrow["newpic"];
	$searchpic=$myrow["searchpic"];
	$printpic=$myrow["printpic"];
	$backpic=$myrow["backpic"];
	$pageheader=$myrow["pageheader"];
	$pagefooter=$myrow["pagefooter"];
	$usecustomheader=$myrow["usecustomheader"];
	$usecustomfooter=$myrow["usecustomfooter"];
	$dateformat=$myrow["dateformat"];
	$allowsearch=$myrow["allowsearch"];
	$allowusercomments=$myrow["allowusercomments"];
	$server_timezone=$myrow["timezone"];
	$searchcomments=$myrow["searchcomments"];
	$searchquestions=$myrow["searchquestions"];
	$showsummary=$myrow["showsummary"];
	$allowquestions=$myrow["allowquestions"];
	$summarylength=$myrow["summarylength"];
	$progrestrict=$myrow["progrestrict"];
	$headerfile=$myrow["headerfile"];
	$footerfile=$myrow["footerfile"];
	$helpwindowwidth=$myrow["helpwindowwidth"];
	$helpwindowheight=$myrow["helpwindowheight"];
	$helpwindowleft=$myrow["helpwindowleft"];
	$helpwindowtop=$myrow["helpwindowtop"];
	$helppic=$myrow["helppic"];
	$defsearchmethod=$myrow["defsearchmethod"];
	$enablelanguageselector=$myrow["enablelanguageselector"];
	$enablekeywordsearch=$myrow["enablekeywordsearch"];
	$copyrightbgcolor=$myrow["copyrightbgcolor"];
	$showcurrtime=$myrow["showcurrtime"];
	$showtimezone=$myrow["showtimezone"];
	$copyrightpos=$myrow["copyrightpos"];
	$subheadingbgcolor=$myrow["subheadingbgcolor"];
	$actionbgcolor=$myrow["actionbgcolor"];
	$headerfilepos=$myrow["headerfilepos"];
	$footerfilepos=$myrow["footerfilepos"];
	$newinfobgcolor=$myrow["newinfobgcolor"];
	$addbodytags=$myrow["addbodytags"];
	$keywordsearchmode=$myrow["keywordsearchmode"];
	if($summarylength==0)
		$summarylength=40;
	if((!$pageheader) && (!$headerfile))
		$usecustomheader=0;
	if((!$pagefooter) && (!$footerfile))
		$usecustomfooter=0;
}
else
	die("Layout not set up");
if(!isset($$langvar) || !$$langvar)
	$act_lang=$default_lang;
else
	$act_lang=$$langvar;
if(!language_avail($act_lang))
	die ("Language <b>$act_lang</b> not configured");
include('./language/lang_'.$act_lang.'.php');
if((@fopen("./config.php", "a")) && !$testmode)
{
	die($l_config_writeable);
}
if($allowsearch!=1)
	die($l_function_disabled);
if(!isset($stype))
	$stype=0;
if($usevisitcookie)
{
	$actdate = date("Y-m-d");
	if(isset($HTTP_COOKIE_VARS[$cookiename]) && !isset($onlynewfaq))
	{
		$cookiedata=$HTTP_COOKIE_VARS[$cookiename];
		if(faqe_array_key_exists($cookiedata,"date"))
			$cookiedate=$cookiedata["date"];
		if($cookiedate && (strpos($cookiedate,"-")>0))
		{
			$today=getdate(time());
			$datedays=dateToJuliandays($today["mday"],$today["mon"],$today["year"]);
			list($year, $month, $day) = explode("-", $cookiedate);
			$cookiedatedays=dateToJuliandays($day,$month,$year);
			$datedifference = $datedays-$cookiedatedays;
			if($datedifference<1)
			{
				if(!isset($onlynewfaq))
					$onlynewfaq=1;
			}
			else
			{
				$onlynewfaq=$datedifference;
				setcookie($cookiename."[date]",$actdate,1,$cookiepath,$cookiedomain,$cookiesecure);
			}
		}
		else
			setcookie($cookiename."[date]",$actdate,1,$cookiepath,$cookiedomain,$cookiesecure);
	}
	else
		setcookie($cookiename."[date]",$actdate,1,$cookiepath,$cookiedomain,$cookiesecure);
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<?php
if($newtime>0)
{
	$actdate=getdate(time());
	$datedays=dateToJuliandays($actdate["mday"],$actdate["mon"],$actdate["year"]);
	$newdatedays = $datedays-$newtime;
	$newdate=juliandaysToDate($newdatedays,"Y-m-d");
}
if(!isset($dosearch) || isset($clear))
{
	$search_head="";
	$search_question="";
	$search_answer="";
	$answer_option="all";
	$criteria_option="any";
	if(!isset($newdays))
		$newdays=0;
	$search_comments="";
	$enablesummary=1;
	$search_questions="";
	$search_arguments="";
	$max_results=0;
	$doquestionsearch=0;
	$docommentsearch=0;
	$searchmethod=$defsearchmethod;
}
else
{
	if(isset($local_searchcomments))
		$docommentsearch=1;
	else
		$docommentsearch=0;
	if(isset($local_searchquestions))
		$doquestionsearch=1;
	else
		$doquestionsearch=0;
}
if(isset($enablesummary))
	$local_showsummary=1;
else
	$local_showsummary=0;
?>
<html>
<head>
<meta name="generator" content="FAQEngine v<?php echo $version?>, <?php echo $copyright_asc?>">
<?php
if($stylesheet)
	echo"<link rel=stylesheet href=\"$stylesheet\" type=\"text/css\">";
if(file_exists("./metadata.php"))
	include ("./metadata.php");
else
{
?>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<title><?php echo $l_heading?></title>
<?php
}
?>
<script>
var windowW= <?php echo $helpwindowwidth?> // wide
var windowH= <?php echo $helpwindowheight?> // high
var windowX = <?php echo $helpwindowleft?> // from left
var windowY = <?php echo $helpwindowtop?> // from top
var autoclose = true
s = "width="+windowW+",height="+windowH;
var beIE = document.all?true:false

function openFrameless(urlPop,title){
  if (beIE){
    NFW = window.open("","popFrameless","fullscreen,"+s)
    NFW.blur()
    window.focus()
    NFW.resizeTo(windowW,windowH)
    NFW.moveTo(windowX,windowY)
    var frameString=""+
"<html>"+
"<head>"+
"<title>"+title+"</title>"+
"</head>"+
"<frameset rows='*,0' framespacing=0 border=0 frameborder=0>"+
"<frame name='top' src='"+urlPop+"' scrolling=auto>"+
"<frame name='bottom' src='about:blank' scrolling='no'>"+
"</frameset>"+
"</html>"
    NFW.document.open();
    NFW.document.write(frameString)
    NFW.document.close()
  } else {
    NFW=window.open(urlPop,"popFrameless","scrollbars,"+s)
    NFW.blur()
    window.focus()
    NFW.resizeTo(windowW,windowH)
    NFW.moveTo(windowX,windowY)
  }
  NFW.focus()
  if (autoclose){
    window.onunload = function(){NFW.close()}
  }
}

var isNetscape = false;
var isIE = false;
var isWhoKnows = false;
function submitByEnter()
{

	//This determines which browser the user is using
	if (parseInt(navigator.appVersion) >= 4) {
		if(navigator.appName == "Netscape") {
		  isNetscape = true;
		}else if (navigator.appName == "Microsoft Internet Explorer"){
		  isIE = true;
		}else {
			isWhoKnows = true;
		}
	}

	//This stuff captures the events of the user
	if(isNetscape) {
		document.captureEvents(Event.KEYUP);
	}
	document.onkeyup = checkValue
}
function checkValue(evt){
		var theButtonPressed;
		if (isNetscape) {
			if(evt.target.type == "text"){
				theButtonPressed = evt.which;
			}
        }else if(isIE) {
			if (window.event.srcElement.type == "text") {
				theButtonPressed = window.event.keyCode;
			}
		}else if(isWhoKnows) {
			alert("<?php echo $l_usesubmit?>");
		}

		if (theButtonPressed == 13) {
			document.searchform.dosearch.click();
		}
}
</script>
</head>
<body onLoad="submitByEnter()" bgcolor="<?php echo $page_bgcolor?>" link="<?php echo $LinkColor?>" vlink="<?php echo $VLinkColor?>" alink="<?php echo $ALinkColor?>" text="<?php echo $FontColor?>" <?php echo $addbodytags?>>
<?php
if($usecustomheader==1)
{
	if(($headerfile) && ($headerfilepos==0))
	{
		if(is_phpfile($headerfile))
			include($headerfile);
		else
			file_output($headerfile);
	}
	echo $pageheader;
	if(($headerfile) && ($headerfilepos==1))
	{
		if(is_phpfile($headerfile))
			include($headerfile);
		else
			file_output($headerfile);
	}
}
?>
<table width="<?php echo $TableWidth?>" border="0" CELLPADDING="1" CELLSPACING="0" ALIGN="CENTER" VALIGN="TOP">
<tr><TD BGCOLOR="<?php echo $table_bgcolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<TR BGCOLOR="<?php echo $heading_bgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE" width="95%"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize3?>" color="<?php echo $HeadingFontColor?>"><b><?php echo $l_searchheading?></b></font>
</td>
<?php
$sql = "select * from ".$tableprefix."_misc";
if(!$result = faqe_db_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = faqe_db_fetch_array($result))
{
	if($myrow["shutdown"]==1)
	{
?>
</tr></table></td></tr>
<tr><TD BGCOLOR="<?php echo $table_bgcolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<?php
		$shutdowntext=stripslashes($myrow["shutdowntext"]);
		$shutdowntext = undo_htmlspecialchars($shutdowntext);
		echo $shutdowntext;
		echo "</font></td></tr></table></td></tr></table>";
		if(($usecustomfooter==1) && ($copyrightpos==0))
		{
			if(($footerfile) && ($footerfilepos==0))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
			echo $pagefooter;
			if(($footerfile) && ($footerfilepos==1))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
		}
?>
<br>
<table align="center" bgcolor="<?php echo $copyrightbgcolor?>" width="<?php echo $TableWidth?>" border="0">
<tr><td align="center">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize4?>" color="<?php echo $FontColor?>">
<?php
		if($showcurrtime)
		{
			$displaytime=date("H:i");
			echo "$l_currtime $displaytime<br>";
		}
		if($showtimezone==1)
			echo "$l_timezone_note $server_timezone<br>";
		echo "Generated by $copyright_url, $copyright_note";
?>
</td></tr></table>
<br>
<?php
		if(($usecustomfooter==1) && ($copyrightpos==1))
		{
			if(($footerfile) && ($footerfilepos==0))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
			echo $pagefooter;
			if(($footerfile) && ($footerfilepos==1))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
		}
		echo "</body></html>";
		exit;
	}
}
?>
<td align="right" valign="MIDDLE" width="2%" nowrap>
<?php
if(!isset($prog) || !$prog)
	echo "<a href=\"faq.php?list=progs&$langvar=$act_lang";
else
	echo "<a href=\"faq.php?list=all&prog=$prog&$langvar=$act_lang";
if(isset($onlynewfaq))
	echo "&amp;onlynewfaq=$onlynewfaq";
echo "\"><img src=\"$backpic\" border=\"0\" alt=\"$l_faqlink\">";
?>
</a>
<a href="javascript:openFrameless('help/<?php echo $act_lang?>/search.php?<?php echo "$langvar=$act_lang"?>')"><img src="<?php echo $helppic?>" border="0" alt="<?php echo $l_help?>"></a></td>
</tr>
<tr bgcolor="<?php echo $subheadingbgcolor?>"><td align="center" colspan="2">
<font color="<?php echo $SubheadingFontColor?>" face="<?php echo $FontFace?>" size="<?php echo $FontSize5?>">
<b>
<?php
if($stype==1)
	echo $l_advanced_search;
else
	echo $l_simple_search;
?>
</b></font></td></tr></table></td></tr>
<tr><TD BGCOLOR="<?php echo $table_bgcolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<form name="searchform" action="<?php echo $PHP_SELF?>" method="post">
<?php
	if(isset($onlynewfaq))
		echo "<input type=\"hidden\" name=\"onlynewfaq\" value=\"$onlynewfaq\"";
	if(isset($prog) && $prog)
		echo "<input type=\"hidden\" name=\"prog\" value=\"$prog\">";
?>
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="stype" value="<?php echo $stype?>">
<?php
$sql = "select * from ".$tableprefix."_texts where textid='searchpre' and lang='$act_lang'";
if(!$result = faqe_db_query($sql, $db)) {
	die("<tr bgcolor=\"$heading_bgcolor\" align=\"center\"><td>Could not connect to the database.");
}
if($myrow=faqe_db_fetch_array($result))
{
	$displaytext=stripslashes($myrow["text"]);
	$displaytext = undo_htmlspecialchars($displaytext);
	echo "<tr bgcolor=\"$group_bgcolor\"><td align=\"center\" colspan=\"2\">";
	echo "<font face=\"$FontFace\" SIZE=\"$FontSize2\" color=\"$FontColor\">";
	echo $displaytext;
	echo "</font></td></tr>\n";
}
if($stype==1)
{
?>
<tr><td align="left" colspan="2" bgcolor="<?php echo $subheadingbgcolor?>">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize5?>" color="<?php echo $SubheadingFontColor?>">
<b><?php echo $l_searchfaq?>:</b></font></td></tr>
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<td bgcolor="<?php echo $group_bgcolor?>" ALIGN="LEFT" colspan="2">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize5?>" color="<?php echo $GroupFontColor?>">
<b><?php echo $l_searchheadings?>:</b></font></td></tr>
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<td align="left" colspan="2">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<input type="text" name="search_head" value="<?php echo $search_head?>" size="60" maxlength="255"></font></td></tr>
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<td bgcolor="<?php echo $group_bgcolor?>" ALIGN="LEFT" colspan="2">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize5?>" color="<?php echo $GroupFontColor?>">
<b><?php echo $l_searchquestions?>:</b></font></td></tr>
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<td align="left" colspan="2">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<input type="text" name="search_question" value="<?php echo $search_question?>" size="60" maxlength="255"></font></td></tr>
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<td bgcolor="<?php echo $group_bgcolor?>" ALIGN="LEFT" colspan="2">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize5?>" color="<?php echo $GroupFontColor?>">
<b><?php echo $l_searchanswers?>:</b></font></td></tr>
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<td align="left" colspan="2">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<input type="text" name="search_answer" value="<?php echo $search_answer?>" size="60" maxlength="255"></font></td></tr>
<tr BGCOLOR="<?php echo $group_bgcolor?>">
<td align="center" colspan="2">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<?php echo $l_chaincriterias?>:<br>
<select name="criteria_option">
<option value="all" <?php if($criteria_option=="all") echo "selected"?>><?php echo $l_allcriterias?></option>
<option value="any" <?php if($criteria_option=="any") echo "selected"?>><?php echo $l_anycriteria?></option>
</select></font></td></tr>
<tr><td align="center" bgcolor="<?php echo $row_bgcolor?>" colspan="2">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<?php echo $l_searchnew?> <select name="newdays">
<option value="0"><?php echo $l_any?></option>
<?php
for($i=1;$i<15;$i++)
{
	echo "<option value=\"$i\"";
	if($newdays==$i)
		echo "selected";
	echo ">$i</option>";
}
?>
</select>&nbsp;<?php echo $l_days?>
</font></td></tr>
<?php
if(($allowusercomments==1) && ($searchcomments==1))
{
?>
<tr><td align="left" colspan="2" bgcolor="<?php echo $subheadingbgcolor?>">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize5?>" color="<?php echo $SubheadingFontColor?>">
<b><?php echo $l_searchcomments?>:</b></font></td></tr>
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<td width="55%" align="left" colspan="2">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<input type="text" name="search_comments" value="<?php echo $search_comments?>" size="60" maxlength="255"></font></td></tr>
<?php
}
if(($allowquestions==1) && ($searchquestions==1))
{
?>
<tr><td align="left" colspan="2" bgcolor="<?php echo $subheadingbgcolor?>">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize5?>" color="<?php echo $SubheadingFontColor?>">
<b><?php echo $l_search_userquestions?>:</b></font></td></tr>
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<td width="55%" align="left" colspan="2">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<input type="text" name="search_questions" value="<?php echo $search_questions?>" size="60" maxlength="255"></font></td></tr>
<?php
}
}
else
{
?>
<input type="hidden" name="criteria_option" value="any">
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<td align="left" colspan="2"><input type="text" name="search_arguments" value="<?php echo $search_arguments?>" size="60" maxlength="255"></td></tr>
<?php
if($enablekeywordsearch==1)
{
?>
<tr bgcolor="<?php echo $group_bgcolor?>"><td align="center" colspan="2">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<input type="radio" name="searchmethod" value="0" <?php if($searchmethod==0) echo "checked"?>>
<?php echo $l_keywordsearch?>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="searchmethod" value="1" <?php if($searchmethod==1) echo "checked"?>>
<?php echo $l_fulltextsearch?></font></td></tr>
<?php
}
else
	echo "<input type=\"hidden\" name=\"searchmethod\" value=\"1\">";
?>
<tr BGCOLOR="<?php echo $group_bgcolor?>" ALIGN="CENTER">
<?php
if(($allowquestions==1) && ($searchquestions==1))
{
	echo "<tr bgcolor=\"$group_bgcolor\"><td align=\"center\">";
	echo "<font face=\"$FontFace\" size=\"$FontSize2\" color=\"$FontColor\">";
	echo "<input type=\"checkbox\" name=\"local_searchquestions\"";
	if($doquestionsearch==1)
		echo " checked";
	echo"> $l_questionsearch</font></td></tr>";
}
if(($allowusercomments==1) && ($searchcomments==1))
{
	echo "<tr bgcolor=\"$group_bgcolor\"><td align=\"center\">";
	echo "<font face=\"$FontFace\" size=\"$FontSize2\" color=\"$FontColor\">";
	echo "<input type=\"checkbox\" name=\"local_searchcomments\"";
	if($docommentsearch==1)
		echo " checked";
	echo"> $l_commentsearch</font></td></tr>";
}
}
if(($showsummary==1))
{
?>
<tr><td align="center" colspan="2" bgcolor="<?php echo $group_bgcolor?>">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<input type="checkbox" name="enablesummary" value="1" <?php if($local_showsummary==1) echo "checked"?>>
<?php echo $l_showsummary?></font></td></tr>
<?php
}
?>
<tr bgcolor="<?php echo $group_bgcolor?>"><td align="center">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<?php echo "$l_max_results1 "?>
<select name="max_results">
<option value="0"
<?php
	if($max_results==0)
		echo "selected";
?>
><?php echo $l_all?></option>
<?php
for($i=5;$i<51;$i+=5)
{
	echo "<option value=\"$i\"";
	if($i==$max_results)
		echo " selected";
	echo ">$i</option>";
}
?>
</select>
<?php echo " $l_max_results2"?>
</font></td></tr>
<tr><td align="center" colspan="2" bgcolor="<?php echo $actionbgcolor?>">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize5?>" color="<?php echo $FontColor?>">
<input type="submit" name="dosearch" value="<?php echo $l_dosearch?>">
<input type="reset" value="<?php echo $l_reset?>">
<input type="submit" name="clear" value="<?php echo $l_clear?>">
</font></td></tr>
<?php
if($stype==0)
{
?>
<tr BGCOLOR="<?php echo $actionbgcolor?>" ALIGN="CENTER">
<td align="center" colspan="2">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize1?>" color="<?php echo $FontColor?>">
<?php
if(isset($prog) && $prog)
	echo "<a href=\"$PHP_SELF?$langvar=$act_lang&amp;prog=$prog&amp;stype=1";
else
	echo "<a href=\"$PHP_SELF?$langvar=$act_lang&amp;stype=1";
if(isset($onlynewfaq))
	echo "&amp;onlynewfaq=$onlynewfaq";
echo "\">$l_advanced_search</a>";
?>
</font></td></tr>
<?php
}
else
{
?>
<tr BGCOLOR="<?php echo $actionbgcolor?>" ALIGN="CENTER">
<td align="center" colspan="2">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize1?>" color="<?php echo $FontColor?>">
<?php
if(isset($prog) && $prog)
	echo "<a href=\"$PHP_SELF?$langvar=$act_lang&amp;prog=$prog&amp;stype=0";
else
	echo "<a href=\"$PHP_SELF?$langvar=$act_lang&amp;stype=0";
if(isset($onlynewfaq))
	echo "&amp;onlynewfaq=$onlynewfaq";
echo "\">$l_simple_search</a>";
?>
</font></td></tr>
<?php
}
?>
</form></table></td></tr></table>
<?
	if(($enablelanguageselector==1) && !isset($dosearch))
	{
		echo "<table width=\"$TableWidth\" align=\"center\" border=\"0\">\n";
		echo "<form method=\"post\" action=\"$PHP_SELF\">";
		echo "<tr bgcolor=\"$group_bgcolor\"><td align=\"center\">\n";
		if(isset($onlynewfaq))
			echo "<input type=\"hidden\" name=\"onlynewfaq\" value=\"$onlynewfaq\">";
		echo "<input type=\"hidden\" name=\"stype\" value=\"$stype\">";
		echo "<font face=\"$FontFace\" size=\"$FontSize2\" color=\"$FontColor\">";
		echo "$l_changelang: ".language_select($act_lang,$langvar);
		echo "&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"$l_ok\">";
		echo "</font></td></tr></form></table>\n";
	}
?>
<br>
<?php
if(isset($dosearch))
{
	if($stype==0)
	{
		$newdays=0;
		$search_head=$search_arguments;
		$search_question=$search_arguments;
		$search_answer=$search_arguments;
		if(($allowusercomments==1) && ($searchcomments==1) && ($docommentsearch==1))
			$search_comments=$search_arguments;
		else
			$search_comments="";
		if(($allowquestions==1) && ($searchquestions==1) && ($doquestionsearch==1))
			$search_questions=$search_arguments;
		else
			$search_questions="";
	}
	if(($stype!=0) || ($searchmethod!=0))
	{
		$num_results_faq=0;
		$numcriterias=0;
		$sql ="SELECT dat.* from ".$tableprefix."_data dat, ".$tableprefix."_category cat, ".$tableprefix."_programm prog ";
		if(($progrestrict==0) || !isset($prog) || !$prog)
			$sql .="where cat.programm=prog.prognr and dat.category=cat.catnr and prog.language='$act_lang' and (";
		else
			$sql .="where cat.programm=prog.prognr and dat.category=cat.catnr and prog.progid='$prog' and prog.language='$act_lang' and (";
		$search_head=htmlentities(trim($search_head));
		if($search_head)
		{
			$musts=array();
			$cans=array();
			$nots=array();
			$numcriterias+=1;
			$searchcriterias=0;
			$searchterms = explode(" ",$search_head);
			foreach($searchterms as $searchstring)
			{
				$qualifier=substr($searchstring,0,1);
				if($qualifier=='-')
				{
					array_push($nots,substr($searchstring,1,strlen($searchstring)-1));
				}elseif ($qualifier=='+')
				{
					array_push($musts,substr($searchstring,1,strlen($searchstring)-1));
				}
				else
				{
					array_push($cans,$searchstring);
				}
			}
			$first=1;
			if(count($musts)>0)
			{
				$sql .="((";
				$searchcriterias++;
				for($i=0;$i<count($musts);$i++)
				{
					if($first==1)
						$first=0;
					else
						$sql .=" and ";
					$sql.="dat.heading like '%".$musts[$i]."%'";
				}
				$sql .=")";

			}
			$first=1;
			if(count($nots)>0)
			{
				if($searchcriterias>0)
					$sql .=" and ";
				else
					$sql.="(";
				$sql .="(";
				$searchcriterias++;
				for($i=0;$i<count($nots);$i++)
				{
					if($first==1)
					$first=0;
					else
						$sql .=" and ";
					$sql.="dat.heading not like '%".$nots[$i]."%'";
				}
				$sql .=")";
			}
			$first=1;
			if((count($cans)>0) && (count($musts)<1))
			{
				if($searchcriterias>0)
					$sql .=" and ";
				else
					$sql .="(";
				$sql .="(";
				$searchcriterias++;
				for($i=0;$i<count($cans);$i++)
				{
					if($first==1)
						$first=0;
					else
						$sql .=" or ";
					$sql.="dat.heading like '%".$cans[$i]."%'";
				}
				$sql .=")";
			}
			if($searchcriterias>0)
				$sql.=")";
		}
		if($newdays>0)
		{
			$actdate2=getdate(time());
			$datedays2=dateToJuliandays($actdate2["mday"],$actdate2["mon"],$actdate2["year"]);
			$newdatedays2 = $datedays2-$newdays;
			$newdate2=juliandaysToDate($newdatedays2,"Y-m-d");
			if($numcriterias>0)
				$sql .=" AND ";
			$numcriterias = $numcriterias + 1;
			$sql .="(dat.editdate >= '$newdate2')";
		}
		$search_question=htmlentities(trim($search_question));
		if($search_question)
		{
			$musts=array();
			$cans=array();
			$nots=array();
			if($numcriterias>0)
			{
				if($criteria_option=="all")
					$sql .=" AND ";
				else
					$sql .=" OR ";
			}
			$numcriterias+=1;
			$searchcriterias=0;
			$searchterms = explode(" ",$search_question);
			foreach($searchterms as $searchstring)
			{
				$qualifier=substr($searchstring,0,1);
				if($qualifier=='-')
				{
					array_push($nots,substr($searchstring,1,strlen($searchstring)-1));
				}elseif ($qualifier=='+')
				{
					array_push($musts,substr($searchstring,1,strlen($searchstring)-1));
				}
				else
				{
					array_push($cans,$searchstring);
				}
			}
			$first=1;
			if(count($musts)>0)
			{
				$sql .="((";
				$searchcriterias++;
				for($i=0;$i<count($musts);$i++)
				{
					if($first==1)
						$first=0;
					else
						$sql .=" and ";
					$sql.="dat.questiontext like '%".$musts[$i]."%'";
				}
				$sql .=")";
			}
			$first=1;
			if(count($nots)>0)
			{
				if($searchcriterias>0)
					$sql .=" and ";
				else
					$sql .="(";
				$sql .="(";
				$searchcriterias++;
				for($i=0;$i<count($nots);$i++)
				{
					if($first==1)
						$first=0;
					else
						$sql .=" and ";
					$sql.="dat.questiontext not like '%".$nots[$i]."%'";
				}
				$sql .=")";
			}
			$first=1;
			if((count($cans)>0) && (count($musts)<1))
			{
				if($searchcriterias>0)
					$sql .=" and ";
				else
					$sql .="(";
				$sql .="(";
				$searchcriterias++;
				for($i=0;$i<count($cans);$i++)
				{
					if($first==1)
						$first=0;
					else
						$sql .=" or ";
					$sql.="dat.questiontext like '%".$cans[$i]."%'";
				}
				$sql .=")";
			}
			if($searchcriterias>0)
				$sql.=")";
		}
		$search_answer=htmlentities(trim($search_answer));
		if($search_answer)
		{
			$musts=array();
			$cans=array();
			$nots=array();
			if($numcriterias>0)
			{
				if($criteria_option=="all")
					$sql .=" AND ";
				else
					$sql .=" OR ";
			}
			$numcriterias+=1;
			$searchcriterias=0;
			$searchterms = explode(" ",$search_answer);
			foreach($searchterms as $searchstring)
			{
				$qualifier=substr($searchstring,0,1);
				if($qualifier=='-')
				{
					array_push($nots,substr($searchstring,1,strlen($searchstring)-1));
				}elseif ($qualifier=='+')
				{
					array_push($musts,substr($searchstring,1,strlen($searchstring)-1));
				}
				else
				{
					array_push($cans,$searchstring);
				}
			}
			$first=1;
			if(count($musts)>0)
			{
				$sql .="((";
				$searchcriterias++;
				for($i=0;$i<count($musts);$i++)
				{
					if($first==1)
						$first=0;
					else
						$sql .=" and ";
					$sql.="dat.answertext like '%".$musts[$i]."%'";
				}
				$sql .=")";
			}
			$first=1;
			if(count($nots)>0)
			{
				if($searchcriterias>0)
					$sql .=" and ";
				else
					$sql.="(";
				$sql .="(";
				$searchcriterias++;
				for($i=0;$i<count($nots);$i++)
				{
					if($first==1)
						$first=0;
					else
						$sql .=" and ";
					$sql.="dat.answertext not like '%".$nots[$i]."%'";
				}
				$sql .=")";
			}
			$first=1;
			if((count($cans)>0) && (count($musts)<1))
			{
				if($searchcriterias>0)
					$sql .=" and ";
				else
					$sql.="(";
				$sql .="(";
				$searchcriterias++;
				for($i=0;$i<count($cans);$i++)
				{
					if($first==1)
						$first=0;
					else
						$sql .=" or ";
					$sql.="dat.answertext like '%".$cans[$i]."%'";
				}
				$sql .=")";
			}
			if($searchcriterias>0)
				$sql.=")";
		}
	}
	if(($stype==0) && ($searchmethod==0))
	{
		$num_results_faq=0;
		$numcriterias=0;
		$sql = "select faq.* from ".$tableprefix."_data faq, ".$tableprefix."_category cat, ".$tableprefix."_programm prog ";
		if(($progrestrict==0) || !isset($prog) || !$prog)
			$sql .="where cat.programm=prog.prognr and faq.category=cat.catnr and prog.language='$act_lang' and ";
		else
			$sql .="where cat.programm=prog.prognr and faq.category=cat.catnr and prog.progid='$prog' and prog.language='$act_lang' and ";
		$faqnrs=array();
		$excludefaqs=array();
		$musts=array();
		$cans=array();
		$nots=array();
		if($search_arguments)
		{
			$searchterms = explode(" ",$search_arguments);
			foreach($searchterms as $searchstring)
			{
				$qualifier=substr($searchstring,0,1);
				if($qualifier=='-')
				{
					array_push($nots,substr($searchstring,1,strlen($searchstring)-1));
				}elseif ($qualifier=='+')
				{
					array_push($musts,substr($searchstring,1,strlen($searchstring)-1));
				}
				else
				{
					array_push($cans,$searchstring);
				}
			}
			if(count($nots)>0)
			{
				$numcriterias++;
				$tempsql="select faq.faqnr from ".$tableprefix."_faq_keywords faq, ".$tableprefix."_keywords kw where faq.keywordnr=kw.keywordnr";
				for($i=0;$i<count($nots);$i++)
				{
					$tempsql .=" and ";
					if($keywordsearchmode==0)
						$tempsql.="kw.keyword ='".$nots[$i]."'";
					else
						$tempsql.="kw.keyword like '%".$nots[$i]."%'";
				}
				if(!$result = faqe_db_query($tempsql, $db)) {
					die("Could not connect to the database (3).".faqe_db_error());
				}
				while($temprow=faqe_db_fetch_array($result))
				{
					array_push($excludefaqs,$temprow["faqnr"]);
				}
			}
			if(count($musts)>0)
			{
				$numcriterias++;
				$tempsql="select faq.faqnr from ".$tableprefix."_faq_keywords faq, ".$tableprefix."_keywords kw where faq.keywordnr=kw.keywordnr";
				for($i=0;$i<count($musts);$i++)
				{
					$tempsql .= " and ";
					if($keywordsearchmode==0)
						$tempsql .="kw.keyword='".$musts[$i]."'";
					else
						$tempsql.="kw.keyword like '%".$musts[$i]."%'";
				}
				if(!$result = faqe_db_query($tempsql, $db)) {
					die("Could not connect to the database (3).".faqe_db_error());
				}
				while($temprow=faqe_db_fetch_array($result))
				{
					if(!in_array($temprow["faqnr"],$excludefaqs))
						array_push($faqnrs,$temprow["faqnr"]);
				}
			}
			if((count($cans)>0) && (count($musts)<1))
			{
				$numcriterias++;
				$tempsql="select faq.faqnr from ".$tableprefix."_faq_keywords faq, ".$tableprefix."_keywords kw where faq.keywordnr=kw.keywordnr and (";
				$first=1;
				for($i=0;$i<count($cans);$i++)
				{
					if($first==1)
						$first=0;
					else
						$tempsql .=" or ";
					if($keywordsearchmode==0)
						$tempsql.="kw.keyword='".$cans[$i]."'";
					else
						$tempsql.="kw.keyword like '%".$cans[$i]."%'";
				}
				$tempsql.=")";
				if(!$result = faqe_db_query($tempsql, $db)) {
					die("Could not connect to the database (3).".faqe_db_error());
				}
				while($temprow=faqe_db_fetch_array($result))
				{
					if(!in_array($temprow["faqnr"],$excludefaqs))
						array_push($faqnrs,$temprow["faqnr"]);
				}
			}
		}
	}
	$questioncount=0;
	$search_questions=trim($search_questions);
	if(($allowquestions==1) && ($search_questions) && ($searchquestions==1))
	{
		$musts=array();
		$cans=array();
		$nots=array();
		$searchcriterias=0;
		$sql_questions="select * from ".$tableprefix."_questions WHERE ";
		$sql_questions .=" (";
		$searchterms = explode(" ",$search_questions);
		foreach($searchterms as $searchstring)
		{
			$qualifier=substr($searchstring,0,1);
			if($qualifier=='-')
			{
				array_push($nots,substr($searchstring,1,strlen($searchstring)-1));
			}elseif ($qualifier=='+')
			{
				array_push($musts,substr($searchstring,1,strlen($searchstring)-1));
			}
			else
			{
				array_push($cans,$searchstring);
			}
		}
		$first=1;
		if(count($musts)>0)
		{
			$questioncount++;
			$sql_questions .="(";
			$searchcriterias++;
			for($i=0;$i<count($musts);$i++)
			{
				if($first==1)
					$first=0;
				else
					$sql_questions .=" and ";
				$sql_questions .="(questions like '%".$musts[$i]."%' or answer like '%".$musts[$i]."%')";
			}
			$sql_questions .=")";
		}
		$first=1;
		if(count($nots)>0)
		{
			$questioncount++;
			if($searchcriterias>0)
				$sql_questions .=" and ";
			$sql_questions .="(";
			$searchcriterias++;
			for($i=0;$i<count($nots);$i++)
			{
				if($first==1)
					$first=0;
				else
					$sql_questions .=" and ";
				$sql_questions .="(question not like '%".$nots[$i]."%' and answer not like '%".$nots[$i]."%')";
			}
			$sql_questions .=")";
		}
		$first=1;
		if((count($cans)>0) && (count($musts)<1))
		{
			$questioncount++;
			if($searchcriterias>0)
				$sql_questions .=" and ";
			$sql_questions .="(";
			$searchcriterias++;
			for($i=0;$i<count($cans);$i++)
			{
				if($first==1)
					$first=0;
				else
					$sql_questions .=" or ";
				$sql_questions .="(question like '%".$cans[$i]."%' or answer like '%".$cans[$i]."%')";
			}
			$sql_questions .=")";
		}
		$sql_questions .=") and (publish=1) group by questionnr order by enterdate desc";
	}
	$commentcount=0;
	$search_comments=trim($search_comments);
	if(($allowusercomments==1) && ($search_comments) && ($searchcomments==1))
	{
		$musts=array();
		$cans=array();
		$nots=array();
		$searchcriterias=0;
		$sql_comment="select * from ".$tableprefix."_comments WHERE ";
		$sql_comment .=" (";
		$searchterms = explode(" ",$search_comments);
		foreach($searchterms as $searchstring)
		{
			$qualifier=substr($searchstring,0,1);
			if($qualifier=='-')
			{
				array_push($nots,substr($searchstring,1,strlen($searchstring)-1));
			}elseif ($qualifier=='+')
			{
				array_push($musts,substr($searchstring,1,strlen($searchstring)-1));
			}
			else
			{
				array_push($cans,$searchstring);
			}
		}
		$first=1;
		if(count($musts)>0)
		{
			$commentcount++;
			$sql_comment .="(";
			$searchcriterias++;
			for($i=0;$i<count($musts);$i++)
			{
				if($first==1)
					$first=0;
				else
					$sql_comment .=" and ";
				$sql_comment .="comment like '%".$musts[$i]."%'";
			}
			$sql_comment .=")";
		}
		$first=1;
		if(count($nots)>0)
		{
			$commentcount++;
			if($searchcriterias>0)
				$sql_comment .=" and ";
			$sql_comment .="(";
			$searchcriterias++;
			for($i=0;$i<count($nots);$i++)
			{
				if($first==1)
					$first=0;
				else
					$sql_comment .=" and ";
				$sql_comment .="comment not like '%".$nots[$i]."%'";
			}
			$sql_comment .=")";
		}
		$first=1;
		if((count($cans)>0) && (count($musts)<1))
		{
			$commentcount++;
			if($searchcriterias>0)
				$sql_comment .=" and ";
			$sql_comment .="(";
			$searchcriterias++;
			for($i=0;$i<count($cans);$i++)
			{
				if($first==1)
					$first=0;
				else
					$sql_comment .=" or ";
				$sql_comment .="comment like '%".$cans[$i]."%'";
			}
			$sql_comment .=")";
		}
		$sql_comment .=") group by commentnr order by postdate";
	}
?>
<table width="<?php echo $TableWidth?>" border="0" CELLPADDING="1" CELLSPACING="0" ALIGN="CENTER" VALIGN="TOP">
<tr><TD BGCOLOR="<?php echo $table_bgcolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<TR BGCOLOR="<?php echo $heading_bgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize3?>" color="<?php echo $HeadingFontColor?>"><b><?php echo $l_searchresult?>:</b></font>
</td></tr></table></td></tr>
<tr><TD BGCOLOR="<?php echo $table_bgcolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<?php
	if(($numcriterias<1) && ($commentcount<1) && ($questioncount<1))
	{
		$num_results=0;
		echo "<td bgcolor=\"$group_bgcolor\" ALIGN=\"CENTER\">";
		echo "<font face=\"$FontFace\" size=\"$FontSize2\" color=\"$FontColor\">";
		echo $l_searchnoquery;
		echo "</font></td></tr>";
	}
	else
	{
		if($numcriterias>0)
		{
			if(($stype==0) && ($searchmethod==0))
			{
				if(count($faqnrs)>0)
				{
					$sql .=" faq.faqnr in (";
					$first=1;
					for($i=0;$i<count($faqnrs);$i++)
					{
						if($first==1)
							$first=0;
						else
							$sql.=", ";
						$sql.=$faqnrs[$i];
					}
					$sql .=") group by faq.faqnr order by faq.editdate desc";
					if(!$result = faqe_db_query($sql, $db)) {
						die("Could not connect to the database (3).".faqe_db_error());
					}
					$num_results = faqe_db_num_rows($result);
				}
				else
					$num_results = 0;
			}
			else
			{
				$sql .=") group by dat.faqnr order BY dat.editdate desc";
				if(!$result = faqe_db_query($sql, $db)) {
					die("Could not connect to the database (3).".faqe_db_error());
				}
				$num_results = faqe_db_num_rows($result);
			}
?>
<tr><td align="left" colspan="3" bgcolor="<?php echo $subheadingbgcolor?>">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize5?>" color="<?php echo $SubheadingFontColor?>">
<b><?php echo $l_searchfaq?>:</b></font></td></tr>
<?php
			$num_results_faq = $num_results;
			if($num_results<1)
			{
				echo "<td bgcolor=\"$group_bgcolor\" ALIGN=\"CENTER\" colspan=\"3\">";
				echo "<font face=\"$FontFace\" size=\"$FontSize5\" color=\"$FontColor\">";
				echo $l_searchnonefound;
				echo "</font></td></tr>";
			}
			else
			{
				if($max_results>0)
				{
					if(isset($start) && ($start>0) && ($num_results>$max_results))
					{
						$sql .=" limit $start,$max_results";
					}
					else
					{
						$sql .=" limit $max_results";
						$start=0;
					}
					if(!$result = faqe_db_query($sql, $db))
						die("Could not connect to the database (3).".faqe_db_error());
				}
				echo "<td bgcolor=\"$group_bgcolor\" ALIGN=\"CENTER\" colspan=\"3\">";
				echo "<font face=\"$FontFace\" size=\"$FontSize5\" color=\"$FontColor\">";
				echo "$num_results $l_searchnumresults";
				if(($max_results>0) && ($num_results>$max_results))
				{
					if(($max_results+$start)>$num_results)
						$displayresults=$num_results;
					else
						$displayresults=($max_results+$start);
					echo "<br>($l_showing: ".($start+1)." - $displayresults)";
				}
				echo "</font></td></tr>";
				WHILE ($myrow=faqe_db_fetch_array($result))
				{
					list($year, $month, $day) = explode("-", $myrow["editdate"]);
					if($month>0)
						$displaydate=date($dateformat,mktime(0,0,0,$month,$day,$year));
					else
						$displaydate="";
					$catnr=$myrow["category"];
					$sql = "select * from ".$tableprefix."_category where (catnr=$catnr)";
					if(!$result2 = faqe_db_query($sql, $db)) {
						die("Could not connect to the database (3).");
					}
					if($myrow2=faqe_db_fetch_array($result2))
					{
						$prognr=$myrow2["programm"];
						$catname=$myrow2["categoryname"];
					}
					else
					{
						$prognr=0;
						$catname="";
					}
					$sql = "select * from ".$tableprefix."_programm where (prognr=$prognr)";
					if(!$result2 = faqe_db_query($sql, $db)) {
						die("Could not connect to the database (3).");
					}
					if($myrow2=faqe_db_fetch_array($result2))
					{
						$progid=$myrow2["progid"];
						$progname=$myrow2["programmname"];
						$language=$myrow2["language"];
					}
					else
					{
						$progid="";
						$progname="";
						$language=$default_lang;
					}
					echo "<tr><td bgcolor=\"$row_bgcolor\" ALIGN=\"CENTER\" width=\"5%\">";
					if($newtime>0)
					{
						list($year, $month, $day) = explode("-", $myrow["editdate"]);
						$tempdays=dateToJuliandays($day, $month, $year);
						if($tempdays>$newdatedays)
							echo "<img src=\"$newpic\" border=\"0\" alt=\"$l_newfaq2\">";
						else
							echo "&nbsp;";
					}
					echo "</td><td bgcolor=\"$row_bgcolor\" ALIGN=\"LEFT\" width=\"85%\">";
					echo "<font face=\"$FontFace\" size=\"$FontSize5\" color=\"$FontColor\">";
					echo "<a href=\"faq.php?display=faq&amp;nr=".$myrow["faqnr"]."&amp;catnr=$catnr&amp;prog=$progid&amp;$langvar=$language";
					if(isset($onlynewfaq))
						echo "&amp;onlynewfaq=$onlynewfaq";
					echo "\">";
					echo "$progname : $catname : ".$myrow["heading"];
					echo "</a></font>";
					if(($showsummary==1) && ($local_showsummary==1))
					{
						$summarytext=get_summary($myrow["questiontext"],$summarylength);
						echo "<br><font face=\"$FontFace\" SIZE=\"$FontSize4\">$l_question: $summarytext</font>";
						$summarytext=get_summary($myrow["answertext"],$summarylength);
						echo "<br><font face=\"$FontFace\" SIZE=\"$FontSize4\">$l_answer: $summarytext</font>";
					}
					echo "</td>";
					echo "<td bgcolor=\"$row_bgcolor\" width=\"10%\" align=\"center\">";
					echo "<font face=\"$FontFace\" size=\"$FontSize5\" color=\"$FontColor\">";
					echo $displaydate."</font></td></tr>";
				}
				if(($max_results>0) && ($num_results>$max_results))
				{
					echo "<tr><td align=\"center\" colspan=\"3\" bgcolor=\"$actionbgcolor\">";
					echo "<font face=\"$FontFace\" size=\"$FontSize1\" color=\"$FontColor\">";
					echo "$l_page ";
					for($i=1;$i<($num_results/$max_results)+1;$i++)
					{
						if(floor(($start+$max_results)/$max_results)!=$i)
						{
							echo "<a href=\"$PHP_SELF?lang=$lang&amp;stype=$stype&amp;start=".(($i-1)*$max_results);
							echo "&amp;max_results=$max_results";
							echo "&amp;criteria_option=$criteria_option";
							if(isset($onlynewfaq))
								echo "&amp;onlynewfaq=$onlynewfaq";
							if($stype==0)
								echo "&amp;search_arguments=".urlencode($search_arguments);
							else
							{
								echo "&amp;search_head=".urlencode($search_head);
								echo "&amp;search_question=".urlencode($search_question);
								echo "&amp;search_answer=".urlencode($search_answer);
								echo "&amp;search_comments=".urlencode($search_comments);
								echo "&amp;search_questions=".urlencode($search_questions);
								echo "&amp;newdays=$newdays";
							}
							if(isset($searchmethod))
								echo "&amp;searchmethod=$searchmethod";
							if(isset($local_searchquestions))
								echo "&amp;local_searchquestions=$local_searchquestions";
							if(isset($local_searchcomments))
								echo "&amp;local_searchcomments=$local_searchcomments";
							if(isset($enablesummary))
								echo "&amp;enablesummary=$enablesummary";
							echo "&amp;dosearch=1";
							echo "\">$i</a>";
						}
						else
							echo $i;
					}
					echo "</font></td></tr>";
				}
			}
		}
		if(($allowusercomments==1) && ($commentcount>0) && ($searchcomments==1))
		{
			if(!$result = faqe_db_query($sql_comment, $db)) {
				die("Could not connect to the database (4).");
			}
?>
<tr><td align="left" colspan="3" bgcolor="<?php echo $subheadingbgcolor?>">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize5?>" color="<?php echo $SubheadingFontColor?>">
<b><?php echo $l_searchcomments?>:</b></font></td></tr>
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<?php
			$num_results = faqe_db_num_rows($result);
			if(!$num_results)
			{
				echo "<td bgcolor=\"$group_bgcolor\" ALIGN=\"CENTER\" colspan=\"3\">";
				echo "<font face=\"$FontFace\" size=\"$FontSize5\" color=\"$FontColor\">";
				echo $l_searchnonefound;
				echo "</font></td></tr>";
			}
			else
			{
				if($max_results>0)
				{
					$sql_comment.=" limit $max_results";
					if(!$result = faqe_db_query($sql_comment, $db)) {
						die("Could not connect to the database (4).");
					}
				}
				echo "<td bgcolor=\"$group_bgcolor\" ALIGN=\"CENTER\" colspan=\"3\">";
				echo "<font face=\"$FontFace\" size=\"$FontSize5\" color=\"$FontColor\">";
				echo "$num_results $l_searchnumresults";
				if(($max_results>0) && ($num_results>$max_results))
					echo "<br>($l_showing: $max_results)";
				echo "</font></td></tr>";
				WHILE ($myrow=faqe_db_fetch_array($result))
				{
					list($date,$time) = explode(" ",$myrow["postdate"]);
					list($year, $month, $day) = explode("-", $date);
					if($month>0)
						$displaydate=date($dateformat,mktime(0,0,0,$month,$day,$year));
					else
						$displaydate="";
					echo "<tr bgcolor=\"$row_bgcolor\">";
					echo "<td>&nbsp;</td>";
					$tmpsql = "select prog.programmname, cat.categoryname, dat.heading, prog.progid, cat.catnr from ".$tableprefix."_programm prog, ".$tableprefix."_category cat, ".$tableprefix."_data dat ";
					$tmpsql .="where prog.prognr=cat.programm and cat.catnr = dat.category and dat.faqnr=".$myrow["faqnr"];
					if(!$tmpresult = faqe_db_query($tmpsql, $db)) {
						die("Could not connect to the database (5).");
					}
					if(!$tmprow=faqe_db_fetch_array($tmpresult))
					{
						$displaytext=get_summary($myrow["comment"],$summarylength);
						$summarytext="";
					}
					else
					{
						$displaytext=$tmprow["programmname"].":".$tmprow["categoryname"].":".$tmprow["heading"];
						if(($showsummary==1) && ($local_showsummary==1))
						{
							$summarytext=get_summary($myrow["comment"],$summarylength);
						}
					}
					echo "<td bgcolor=\"$row_bgcolor\" ALIGN=\"LEFT\" width=\"85%\">";
					echo "<font face=\"$FontFace\" size=\"$FontSize5\" color=\"$FontColor\">";
					echo "<a href=\"comment.php?mode=read&amp;prog=".$tmprow["progid"]."&amp;catnr=".$tmprow["catnr"]."&amp;faqnr=".$myrow["faqnr"]."&amp;commentnr=".$myrow["commentnr"]."&amp;$langvar=$act_lang";
					if(isset($onlynewfaq))
						echo "&amp;onlynewfaq=$onlynewfaq";
					echo "\">$displaytext</a>";
					if($summarytext)
						echo "<br><font face=\"$FontFace\" SIZE=\"$FontSize4\">$l_comment: $summarytext</font>";
					echo "</font></td>";
					echo "<td bgcolor=\"$row_bgcolor\" width=\"10%\" align=\"center\">";
					echo "<font face=\"$FontFace\" size=\"$FontSize5\" color=\"$FontColor\">";
					echo $displaydate."</font></td></tr>";
				}
			}
		}
		if(($allowquestions==1) && ($questioncount>0) && ($searchquestions==1))
		{
			if(!$result = faqe_db_query($sql_questions, $db)) {
				die("Could not connect to the database (5).");
			}
?>
<tr><td align="left" colspan="3" bgcolor="<?php echo $subheadingbgcolor?>">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize5?>" color="<?php echo $SubheadingFontColor?>">
<b><?php echo $l_search_userquestions?>:</b></font></td></tr>
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<?php
			$num_results = faqe_db_num_rows($result);
			if(!$num_results)
			{
				echo "<td bgcolor=\"$group_bgcolor\" ALIGN=\"CENTER\" colspan=\"3\">";
				echo "<font face=\"$FontFace\" size=\"$FontSize5\" color=\"$FontColor\">";
				echo $l_searchnonefound;
				echo "</font></td></tr>";
			}
			else
			{
				if($max_results>0)
				{
					$sql_questions.=" limit $max_results";
					if(!$result = faqe_db_query($sql_questions, $db)) {
						die("Could not connect to the database (5).");
					}
				}
				echo "<td bgcolor=\"$group_bgcolor\" ALIGN=\"CENTER\" colspan=\"3\">";
				echo "<font face=\"$FontFace\" size=\"$FontSize5\" color=\"$FontColor\">";
				echo "$num_results $l_searchnumresults";
				if(($max_results>0) && ($num_results>$max_results))
					echo "<br>($l_showing: $max_results)";
				echo "</font></td></tr>";
				WHILE ($myrow=faqe_db_fetch_array($result))
				{
					list($date,$time) = explode(" ",$myrow["enterdate"]);
					list($year, $month, $day) = explode("-", $date);
					if($month>0)
						$displaydate=date($dateformat,mktime(0,0,0,$month,$day,$year));
					else
						$displaydate="";
					echo "<tr bgcolor=\"$row_bgcolor\">";
					echo "<td>&nbsp;</td>";
					$displaytext=get_summary($myrow["question"],$summarylength);
					echo "<td bgcolor=\"$row_bgcolor\" ALIGN=\"LEFT\" width=\"85%\">";
					echo "<font face=\"$FontFace\" size=\"$FontSize5\" color=\"$FontColor\">";
					echo "<a href=\"question.php?mode=read&amp;question=".$myrow["questionnr"]."&amp;$langvar=$act_lang";
					if(isset($onlynewfaq))
						echo "&amp;onlynewfaq=$onlynewfaq";
					echo "\">$displaytext</a></font>";
					if(($showsummary==1) && ($local_showsummary==1) && ($myrow["answerauthor"]>0))
					{
						$summarytext=get_summary($myrow["answer"],$summarylength);
						echo "<br><font face=\"$FontFace\" SIZE=\"$FontSize4\">$l_answer: $summarytext</font>";
					}
					echo "</td>";
					echo "<td bgcolor=\"$row_bgcolor\" width=\"10%\" align=\"center\">";
					echo "<font face=\"$FontFace\" size=\"$FontSize5\" color=\"$FontColor\">";
					echo $displaydate."</font></td></tr>";
				}
			}
		}
	}
?>
<?php
	if($newtime>0 && $num_results_faq)
	{
?>
<tr BGCOLOR="<?php echo $newinfobgcolor?>" valign="middle"><td colspan="3">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize4?>"><img src="<?php echo $newpic?>" border="0" align="middle" alt="<?php echo $l_newfaq2?>"> = <?php echo $l_newfaq?></font></td></tr>
<?php
	}
}
?>
</table></td></tr></table>
<?php
if(($usecustomfooter==1) && ($copyrightpos==0))
{
	if(($footerfile) && ($footerfilepos==0))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
	echo $pagefooter;
	if(($footerfile) && ($footerfilepos==1))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
}
?>
<br>
<table align="center" bgcolor="<?php echo $copyrightbgcolor?>" width="<?php echo $TableWidth?>" border="0">
<tr><td align="center">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize4?>" color="<?php echo $FontColor?>">
<?php
if($showcurrtime)
{
	$displaytime=date("H:i");
	echo "$l_currtime $displaytime<br>";
}
if($showtimezone==1)
	echo "$l_timezone_note $server_timezone<br>";
echo "Generated by $copyright_url, $copyright_note";
?>
</td></tr></table>
<br>
<?php
if(($usecustomfooter==1) && ($copyrightpos==1))
{
	if(($footerfile) && ($footerfilepos==0))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
	echo $pagefooter;
	if(($footerfile) && ($footerfilepos==1))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
}
?>
</body></html>