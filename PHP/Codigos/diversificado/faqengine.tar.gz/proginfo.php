<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('./config.php');
require('./functions.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<?php
$sql = "select * from ".$tableprefix."_layout where (layoutnr=1)";
if(!$result = faqe_db_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = faqe_db_fetch_array($result))
{
	$FontFace=$myrow["fontface"];
	$FontSize1=$myrow["fontsize1"];
	$FontSize2=$myrow["fontsize2"];
	$FontSize3=$myrow["fontsize3"];
	$FontSize4=$myrow["fontsize4"];
	$FontSize5=$myrow["fontsize5"];
	$FontColor=$myrow["fontcolor"];
	$TableWidth=$myrow["tablewidth"];
	$heading_bgcolor=$myrow["headingbg"];
	$table_bgcolor=$myrow["bgcolor1"];
	$row_bgcolor=$myrow["bgcolor2"];
	$group_bgcolor=$myrow["bgcolor3"];
	$page_bgcolor=$myrow["pagebg"];
	$stylesheet=stripslashes($myrow["stylesheet"]);
	$show_proglist=$myrow["showproglist"];
	$HeadingFontColor=$myrow["headingfontcolor"];
	$SubheadingFontColor=$myrow["subheadingfontcolor"];
	$GroupFontColor=$myrow["groupfontcolor"];
	$LinkColor=$myrow["linkcolor"];
	$VLinkColor=$myrow["vlinkcolor"];
	$ALinkColor=$myrow["alinkcolor"];
	$TableDescFontColor=$myrow["tabledescfontcolor"];
	$dateformat=$myrow["dateformat"];
	$newtime=$myrow["newtime"];
	$searchpic=$myrow["searchpic"];
	$printpic=$myrow["printpic"];
	$backpic=$myrow["backpic"];
	$listpic=$myrow["listpic"];
	$displayrating=$myrow["displayrating"];
	$pageheader=stripslashes($myrow["pageheader"]);
	$pagefooter=stripslashes($myrow["pagefooter"]);
	$usecustomheader=$myrow["usecustomheader"];
	$usecustomfooter=$myrow["usecustomfooter"];
	$allowemail=$myrow["allowemail"];
	$emailpic=$myrow["emailpic"];
	$allowquestions=$myrow["allowquestions"];
	$questionpic=$myrow["questionpic"];
	$usercommentpic=$myrow["usercommentpic"];
	$allowusercomments=$myrow["allowusercomments"];
	$allowlists=$myrow["allowlists"];
	$allowsearch=$myrow["allowsearch"];
	$server_timezone=$myrow["timezone"];
	$headerfile=$myrow["headerfile"];
	$footerfile=$myrow["footerfile"];
	$proginfopic=$myrow["proginfopic"];
	$closepic=$myrow["closepic"];
	$subheadingbgcolor=$myrow["subheadingbgcolor"];
	$actionbgcolor=$myrow["actionbgcolor"];
	$headerfilepos=$myrow["headerfilepos"];
	$footerfilepos=$myrow["footerfilepos"];
	$newinfobgcolor=$myrow["newinfobgcolor"];
	$addbodytags=$myrow["addbodytags"];
	if((!$pageheader) && (!$headerfile))
		$usecustomheader=0;
	if((!$pagefooter) && (!$footerfile))
		$usecustomfooter=0;
}
else
	die("Layout not set up");
if(!isset($$langvar) || !$$langvar)
	$act_lang=$default_lang;
else
	$act_lang=$$langvar;
if(!language_avail($act_lang))
	die ("Language <b>$act_lang</b> not configured");
include('./language/lang_'.$act_lang.'.php');
if((@fopen("./config.php", "a")) && !$testmode)
{
	die($l_config_writeable);
}
if(!isset($prog))
	die($l_callingerror);
?>
<html>
<head>
<meta name="generator" content="FAQEngine v<?php echo $version?>, <?php echo $copyright_asc?>">
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<?php
if($stylesheet)
	echo"<link rel=stylesheet href=\"$stylesheet\" type=\"text/css\">";
?>
<title><?php echo $l_proginfo?></title>
</head>
<body onload="top.window.focus()" bgcolor="<?php echo $row_bgcolor?>" link="<?php echo $LinkColor?>" vlink="<?php echo $VLinkColor?>" alink="<?php echo $ALinkColor?>" text="<?php echo $FontColor?>" <?php echo $addbodytags?>>
<?php
	$sql = "select * from ".$tableprefix."_programm where prognr=$prog";
	if(!$result = faqe_db_query($sql, $db))
	   	die("Could not connect to the database.");
	if (!$myrow = faqe_db_fetch_array($result))
		die($l_nosuchprog);
	$descriptiontext=stripslashes($myrow["description"]);
	$descriptiontext = undo_htmlspecialchars($descriptiontext);
?>
<table width="<?php echo $TableWidth?>" border="0" CELLPADDING="1" CELLSPACING="0" ALIGN="CENTER">
<tr><TD BGCOLOR="<?php echo $table_bgcolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<TR BGCOLOR="<?php echo $subheadingbgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE" width="98%"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $SubheadingFontColor?>"><b><?php echo $l_proginfo." ".$l_for." ".$myrow["programmname"]?></b></font>
</td>
<td align="center" valign="middle" width="2%"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize4?>"><a class="pFo" href="javascript:parent.window.focus();top.window.close()"><img src="<?php echo $closepic?>" border="0" alt="<?php echo $l_close?>"></a></font></td></tr>
<tr bgcolor="<?php echo $group_bgcolor?>" align="center">
<td align="left" valign="middle" colspan="2">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<?php echo $descriptiontext?></font></td></tr>
<TR BGCOLOR="<?php echo $actionbgcolor?>" ALIGN="CENTER"><td>&nbsp;</td>
<td align="center" valign="middle" width="2%"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize4?>"><a class="pFo" href="javascript:parent.window.focus();top.window.close()"><img src="<?php echo $closepic?>" border="0" alt="<?php echo $l_close?>"></a></font></td></tr>
</table></td></tr></table>
</body></html>
