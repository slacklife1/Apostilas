<?php
// Edit this to fit your needs
// Begin edit
	// hostname mysql running on
	$dbhost = "localhost";
	// name of database
	$dbname = "faq";
	// username for database
	$dbuser = "root";
	// password for databaseuser
	$dbpasswd = "";
	// prefix for tables, so you can have multiple instances of
	// FAQEngine in one database (please set before calling install or update)
	$tableprefix= "faq";
	// prefix for hostcache table, if you also use one of our other PHP scripts
	// you can set all hostcache tables to 1 prefix, so you only have 1 hostcache
	$hcprefix= "faq";
	// prefix for ip banlist table, if you also use one of our other PHP scripts
	// you can set all banlist tables to 1 prefix, so you only have 1 banlist
	$banprefix= "faq";
	// default language, you can create your own languagefile
	// for other languages in ./language
    $default_lang = "de";
    // language to use for admininterface
    $admin_lang = "de";
    // URL-Path for FAQEngine instance. If you use http://www.myhost.com/faq
    // this is /faq
	$url_faqengine = "/faq";
	// URL-Path for graphics to include in FAQs
	$url_gfx = "/faq/gfx/inline";
	// complete path to directory containing FAQEngine (without trailing slash)
	$path_faqe = getenv("DOCUMENT_ROOT")."/faq";
	// complete path to directory containing graphics to include in FAQs (without trailing slash)
	$path_gfx = getenv("DOCUMENT_ROOT")."/faq/gfx/inline";
	// Set this to true, if last visitdate of user should be stored on his
	// computer and only faqs newer than this date should be displayed.
	$usevisitcookie = true;
	// It should be safe to leave this alone as well. But if you do change it
	// make sure you don't set it to a variable already in use (use a seperate
	// name for each instance of FAQEngine)
	$cookiename = "faqengine";
	// It should be safe to leave these alone as well.
	$cookiepath = $url_faqengine;
	$cookiesecure = false;
	// This is the cookie name for the sessions cookie, you shouldn't have to change it
	// (for multiple instances use different names)
	$sesscookiename = "faqenginesession";
	// This is the number of seconds that a session lasts for, 3600 == 1 hour.
	// The session will exprire if the user dosn't view a page on the admininterface
	// in this amount of time.
	$sesscookietime = 600;
	// If there is a conflict with the HTTP variable "lang", because e.g. your CMS needs it
	// set this to some other value. The calling URLs then not will be URL?lang=..., but
	// URL?<setvalue>=...
	$langvar="lang";
	// Set this to true if you want to use authentication by htacces rather then the
	// internal version (for details reffer to readme.txt)
	$enable_htaccess=false;
	// Set this to true if you want to use sessionid passed throught get and put requests
	// rathern than by cookie (for details reffer to readme.txt)
	$sessid_url=false;
	// Please set this to the hostname, where your instance of FAQEngine is installed
	$faqsitename="localhost";
	// Set to true if you want to have password recovery for admin interface enabled
	$enablerecoverpw=true;
	// maximal filesize for attachements by admin
	$maxfilesize=1000000;
	// please enter all fileextension your server uses for PHP scripts here
	$php_fileext=array("php","php3","phtml");
	// Set this to the charset to be used as content encoding
	$contentcharset="iso-8859-1";
	// minimal fontsize to use for dropdown BBcode button
	$minfontsize=-10;
	// maximal fontsize to use for dropdown BBcode button
	$maxfontsize=10;
	// set DB engine to be used:
	// 1 = mySQL
	$dbengine=1;
	// leaving this to false is the best.
    $testmode = true;
// end edit
// you are not allowed to edit beyond this point
	require_once($path_faqe."/includes/global.inc");
?>