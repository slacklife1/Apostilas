Edit config.php so it fits your needs.
Note: You can have multiple instances of FAQEngine in the same database.
Just set tableprefix in config.php to different values for each installation.
Do this before calling install.php.

Upload all .php-files to your webhoster.
Please maintain directory structure.

Important installation note: the database you define in config.php must still exist. The
install script does not create a database for security reasons.

1st time installation:
Now you can call http://your.host.com/installdir/admin/install.php to create the tables in database
and defining 1 adminuser.

Upgrade:
Please replace all .php-Files on your server
Due to a bug in the installscript in some prior versions, we are unable to provide
an automatic upgrade for versions prior to 1.0.
If you don't want to loose data in the database please see admin/faq.sql for changes
you need to do on database tables.
Contained in this archive only updates from v3.00 and above are provided.
For versions prior to v3.00 please download the v3.00 update script pack.
So you determine which script you need: Take the actually installed versionnumber (e.g. 2.15).
Remove the last number (in the example this would result in 2.1). Now remove the
point in the versionnumber (in our example this results in 21). Now you have the upgrade version.
Now you need to sequentially use all upgrade scripts from this version to the actual version.
For our example the actual version should be 2.5 (short 25). Use upgrade_21to22.php than upgrade_22to23.php
and so on till you reach upgrade_24to25.php

After installation remove install.php or anyone can mess up your database.

Now you can enter the admininterface by calling http://your.host.com/installdir/admin/index.php
and login using the adminuser created during the installprogress.

To display the FAQ just call
http://your.host.com/installdir/faq.php?list=categories&prog=<progid>&lang=<language>
to display only the list of the defined categories for this program
or
http://your.host.com/installdir/faq.php?list=all&prog=<progid>&lang=<language>
to display a list of all FAQ headings in all categories as a treeview for this program
or
http://your.host.com/installdir/faq.php?list=progs&lang=<language>
to display a list of all programs (show programlist in the layout must be enabled)

To display knowledgebase use:
http://your.host.com/installdir/kb.php?prog=<progid>&lang=<language>
if you don't define a progid, user will have the possibility to choosen a program
(only used for wizard mode).
This uses the default mode choosen on admin interface.
You also can use an other mode by defining it on the URL:
http://your.host.com/installdir/kb.php?lang=<language>&mode=wizard
starts with the wizard interface
http://your.host.com/installdir/kb.php?lang=<language>&mode=search
starts with the keyword search
http://your.host.com/installdir/kb.php?lang=<language>&mode=proglist
starts with the program list

If you don't define a language in URL, the default language defined in config.php will be used.


Copying
-------
This program is Freeware. You are allowed to use this for free in non commercial
and commercial environments. You are not allowed to do any changes without written permission.
Except are the following files:
* lang/lang_*
* admin/lang/lang_*
* the marked part in config.php

If you are using this program on Your website, please enter Your site as a
reference on our homepage.

If you are using this program in a commercial environment, it would be very kind to
provide our work with a little donation.

(c)2001,2002 Boesch IT-Consulting

newest version can be found at
http://www.boesch-it.de


Authentitication of admin users
-------------------------------
There are 3 ways to get authentication for admin users.
1) Using the internal authentication method. This is based on the data in the admin table and uses
cookies for session handling.
2) Using the internal authentication method. Sessionid sent by get and post requests.
3) Using authentication by webserver via .htaccess

Method #1
---------
You have to set $enable_htaccess and $sessid_url in config.php to false.
In this case please ensure the following settings in config.php are right:
$url_faqengine
$cookiedomain
$cookiename
$cookiepath
$cookiesecure
$sesscookiename
$sesscookietime

This method uses username and password stored in the database and because of this you can
change the password within the admin interface.

Method #2
---------
You have to set $enable_htaccess to false and $sessid_url to true in config.php.
This method uses no cookie for storing the sessionid, but instead sends the sessionid in every
get and post request.
Because of this, everybody who can look on your screen also can see your sessionid. We think
this is not really secure and recommend to use method 1 or 3. But you decide yourself.
Please ensure $sesscookiename is set to an value not used in an other way by FAQEngine (best
would be to let the default name, because this ensures avoiding conflicts with other
HTTP-variables FAQEngine uses).

This method uses username and password stored in the database and because of this you can
change the password within the admin interface.

Method #3
---------
You have to set $enable_htaccess in config.php to true.
For every user set up in the admin interface, you also have to set up an user in .htpasswd.
Username in database and .htpasswd must be the same, so the program can do assignment of
external and internal userdefinition.
Because of security reasons the admin interface _does not_ update .htpasswd. So if you use
this kind of authentication changes of the password in the admin interface _will not_ have
any effects. Also if you generate a new user in the admin interface be sure to also add
this user to .htpasswd. You still have to provide a password while creating a new user,
so no security whole appears if you change from Method 3 to Method 1 or 2.
Remark: Using this method the internal login and failed login tracking is not available.
Also the logout function does not work.


Note for text template "Mail: notification for new user question":
==================================================================
{qnr} in the text will be replaced by the actual question number.
{qlink} will be replaced by a direct link to this question in the admin interface.

FAQ upload by textfile
======================
You can upload a textfile containing heading, question and answer of a FAQ.
This way you can prepare the FAQs offline and upload them later (and define
the needed references, as program, category etc.).
You must use a seperate file for each FAQ.
Here is an example of the format the file has to be in:
{heading}
here goes the heading
{/heading}
{question}
here goes the question
{/question}
{answer}
here goes the answer
{/answer}

You can use BBCode in the text for question and answer,
just as if you enter them online using the form.
