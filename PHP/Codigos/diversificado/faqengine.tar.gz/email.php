<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('./config.php');
require('./functions.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<?php
$sql = "select * from ".$tableprefix."_layout where (layoutnr=1)";
if(!$result = faqe_db_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = faqe_db_fetch_array($result))
{
	$FontFace=$myrow["fontface"];
	$FontSize1=$myrow["fontsize1"];
	$FontSize2=$myrow["fontsize2"];
	$FontSize3=$myrow["fontsize3"];
	$FontSize4=$myrow["fontsize4"];
	$FontSize5=$myrow["fontsize5"];
	$FontColor=$myrow["fontcolor"];
	$TableWidth=$myrow["tablewidth"];
	$heading_bgcolor=$myrow["headingbg"];
	$table_bgcolor=$myrow["bgcolor1"];
	$row_bgcolor=$myrow["bgcolor2"];
	$group_bgcolor=$myrow["bgcolor3"];
	$page_bgcolor=$myrow["pagebg"];
	$stylesheet=stripslashes($myrow["stylesheet"]);
	$show_proglist=$myrow["showproglist"];
	$HeadingFontColor=$myrow["headingfontcolor"];
	$SubheadingFontColor=$myrow["subheadingfontcolor"];
	$GroupFontColor=$myrow["groupfontcolor"];
	$LinkColor=$myrow["linkcolor"];
	$VLinkColor=$myrow["vlinkcolor"];
	$ALinkColor=$myrow["alinkcolor"];
	$TableDescFontColor=$myrow["tabledescfontcolor"];
	$dateformat=$myrow["dateformat"];
	$newtime=$myrow["newtime"];
	$searchpic=$myrow["searchpic"];
	$printpic=$myrow["printpic"];
	$backpic=$myrow["backpic"];
	$pageheader=$myrow["pageheader"];
	$pagefooter=$myrow["pagefooter"];
	$usecustomheader=$myrow["usecustomheader"];
	$usecustomfooter=$myrow["usecustomfooter"];
	$allowemail=$myrow["allowemail"];
	$emailpic=$myrow["emailpic"];
	$server_timezone=$myrow["timezone"];
	$footerfile=$myrow["footerfile"];
	$headerfile=$myrow["headerfile"];
	$copyrightbgcolor=$myrow["copyrightbgcolor"];
	$showcurrtime=$myrow["showcurrtime"];
	$showtimezone=$myrow["showtimezone"];
	$copyrightpos=$myrow["copyrightpos"];
	$subheadingbgcolor=$myrow["subheadingbgcolor"];
	$actionbgcolor=$myrow["actionbgcolor"];
	$headerfilepos=$myrow["headerfilepos"];
	$footerfilepos=$myrow["footerfilepos"];
	$newinfobgcolor=$myrow["newinfobgcolor"];
	$addbodytags=$myrow["addbodytags"];
	if((!$pageheader) && (!$headerfile))
		$usecustomheader=0;
	if((!$pagefooter) && (!$footerfile))
		$usecustomfooter=0;
}
else
	die("Layout not set up");
if(!isset($$langvar) || !$$langvar)
	$act_lang=$default_lang;
else
	$act_lang=$$langvar;
if(!language_avail($act_lang))
	die ("Language <b>$act_lang</b> not configured");
include('./language/lang_'.$act_lang.'.php');
if(!isset($prog))
	die ("Calling error");
if($allowemail!=1)
	die ("Function disabled");
if((@fopen("./config.php", "a")) && !$testmode)
{
	die($l_config_writeable);
}
?>
<html>
<head>
<meta name="generator" content="FAQEngine v<?php echo $version?>, <?php echo $copyright_asc?>">
<?php
if($stylesheet)
	echo"<link rel=stylesheet href=\"$stylesheet\" type=\"text/css\">";
if(file_exists("./metadata.php"))
	include ("./metadata.php");
else
{
?>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<title><?php echo $l_heading?></title>
<?php
}
?>
</head>
<body bgcolor="<?php echo $page_bgcolor?>" link="<?php echo $LinkColor?>" vlink="<?php echo $VLinkColor?>" alink="<?php echo $ALinkColor?>" text="<?php echo $FontColor?>" <?php echo $addbodytags?>>
<?php
if($usecustomheader==1)
{
	if(($headerfile) && ($headerfilepos==0))
	{
		if(is_phpfile($headerfile))
			include($headerfile);
		else
			file_output($headerfile);
	}
	echo "$pageheader";
	if(($headerfile) && ($headerfilepos==1))
	{
		if(is_phpfile($headerfile))
			include($headerfile);
		else
			file_output($headerfile);
	}
}
?>
<table width="<?php echo $TableWidth?>" border="0" CELLPADDING="1" CELLSPACING="0" ALIGN="CENTER">
<tr><TD BGCOLOR="<?php echo $table_bgcolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<TR BGCOLOR="<?php echo $heading_bgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE" WIDTH="95%"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize3?>" color="<?php echo $HeadingFontColor?>"><b><?php echo $l_heading?></b></font>
</td>
<td align="right" valign="middle" width="5%"><a href="faq.php?display=faq&nr=<?php echo $nr?>&catnr=<?php echo $catnr?>&prog=<?php echo $prog?>&<?php echo "$langvar=$act_lang"?><?php if(isset($onlynewfaq)) echo "&amp;onlynewfaq=$onlynewfaq"?>"><img src="<?php echo $backpic?>" border="0" alt="<?php echo $l_faqlink?>"></a></td>
<?php
$sql = "select * from ".$tableprefix."_misc";
if(!$result = faqe_db_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = faqe_db_fetch_array($result))
{
	if($myrow["shutdown"]==1)
	{
?>
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<?php
		$shutdowntext=stripslashes($myrow["shutdowntext"]);
		$shutdowntext = undo_htmlspecialchars($shutdowntext);
		echo $shutdowntext;
		echo "</font></td></tr></table></td></tr></table>";
		echo "<br><div align=\"center\"><font face=\"$FontFace\" SIZE=\"$FontSize4\">$l_timezone_note $server_timezone<br>Generated by $copyright_url<br>$copyright_note</font></div>";
		exit;
	}
}
if(!isset($nr))
	die("Calling error. No nr found");
if(!isset($catnr))
	die("Calling error. No catnr found");
if(!isset($email))
{
?>
</table></td></tr>
<tr><TD BGCOLOR="<?php echo $table_bgcolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<TR BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="LEFT">
<td align="right" width="40%">
<form method="post" action="<?php echo $PHP_SELF?>">
<?php
	if(isset($onlynewfaq))
		echo "<input type=\"hidden\" name=\"onlynewfaq\" value=\"$onlynewfaq\">";
?>
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="nr" value="<?php echo $nr?>">
<input type="hidden" name="catnr" value="<?php echo $catnr?>">
<input type="hidden" name="prog" value="<?php echo $prog?>">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<?php echo $l_sendername?>:</font></td>
<td align="left" width="60%">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<input type="text" name="fromname" size="30" maxlength="100"></font></td></tr>
<TR BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="LEFT">
<td align="right" width="40%">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<?php echo $l_sendermail?>:</font></td>
<td align="left" width="60%">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<input type="text" name="frommail" size="30" maxlength="100"></font></td></tr>
<TR BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="LEFT">
<td align="right" width="40%">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<?php echo $l_receivermail?>:</font></td>
<td align="left" width="60%">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<input type="text" name="tomail" size="30" maxlength="100"></font></td></tr>
<TR BGCOLOR="<?php echo $actionbgcolor?>" ALIGN="LEFT">
<td align="center" colspan="2"><input type="submit" name="email" value="<?php echo $l_send?>"></td></form></tr>
<?php
}
else
{
	$errors=0;
	$errmsg="";
	if(!isset($frommail) || !$frommail)
	{
		$errmsg .= "$l_nofrommail<br>";
		$errors=1;
	}
	if(!isset($tomail) || !$tomail)
	{
		$errmsg .= "$l_notomail<br>";
		$errors=1;
	}
	if(!validate_email($frommail))
	{
		$errmsg .= "$l_invalidfrommail<br>";
		$errors=1;
	}
	if(!validate_email($tomail))
	{
		$errmsg .= "$l_invalidtomail<br>";
		$errors=1;
	}
	if($errors==1)
	{
?>
</table></td></tr>
<tr><TD BGCOLOR="<?php echo $table_bgcolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<TR BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="LEFT">
<td align="center" width="100%">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<?php echo $errmsg?></font></td>
<tr bgcolor="<?php echo $actionbgcolor?>" align="center"><td>
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize1?>" color="<?php echo $FontColor?>">
<a href="javascript:history.back()"><?php echo $l_back?></a>
</font></td></tr></table></td></tr></table>
<?php
		if(($usecustomfooter==1) && ($copyrightpos==0))
		{
			if(($footerfile) && ($footerfilepos==0))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
			echo $pagefooter;
			if(($footerfile) && ($footerfilepos==1))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
		}
?>
<br>
<table align="center" bgcolor="<?php echo $copyrightbgcolor?>" width="<?php echo $TableWidth?>" border="0">
<tr><td align="center">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize4?>" color="<?php echo $FontColor?>">
<?php
		if($showcurrtime)
		{
			$displaytime=date("H:i");
			echo "$l_currtime $displaytime<br>";
		}
		if($showtimezone==1)
			echo "$l_timezone_note $server_timezone<br>";
		echo "Generated by $copyright_url, $copyright_note";
?>
</td></tr></table>
<br>
<?php
		if(($usecustomfooter==1) && ($copyrightpos==1))
		{
			if(($footerfile) && ($footerfilepos==0))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
			echo $pagefooter;
			if(($footerfile) && ($footerfilepos==1))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
		}
		echo "</body></html>";
		exit;
	}
	if($fromname)
		$fromadr = "From:".$fromname." <".$frommail.">";
	else
		$fromadr = "From:".$frommail;
	$sql = "select * from ".$tableprefix."_category where (catnr=$catnr)";
	if(!$result = faqe_db_query($sql, $db))
	   	die("Could not connect to the database.");
	if (!$myrow = faqe_db_fetch_array($result))
		die("Parametererror");
	$catname=$myrow["categoryname"];
	$sql = "select * from ".$tableprefix."_programm where (progid='$prog') and (language='$act_lang')";
	if(!$result = faqe_db_query($sql, $db))
	   	die("Could not connect to the database.");
	if (!$myrow = faqe_db_fetch_array($result))
		die("Parametererror");
	$prognr=$myrow["prognr"];
	$progname=$myrow["programmname"];
	$sql = "select * from ".$tableprefix."_data where (faqnr=$nr)";
	if(!$result = faqe_db_query($sql, $db))
	   	die("Could not connect to the database.");
	if (!$myrow = faqe_db_fetch_array($result))
		die("unkown FAQ-NR");
	$headingtext=stripslashes($myrow["heading"]);
	$headingtext=undo_htmlentities($headingtext);
	$questiontext=stripslashes($myrow["questiontext"]);
	$questiontext = str_replace("<BR>", "\r\n", $questiontext);
	$questiontext = undo_htmlentities($questiontext);
	$questiontext = strip_tags($questiontext);
	$answertext=stripslashes($myrow["answertext"]);
	$answertext = str_replace("<BR>", "\r\n", $answertext);
	$answertext = undo_htmlentities($answertext);
	$answertext = strip_tags($answertext);
	$mailbody = $l_mailprelude."\r\n";
	$mailbody .= "$progname : $catname : ".$headingtext."\r\n";
	$mailbody .= "$l_question:\r\n".$questiontext."\r\n";
	$mailbody .= "$l_answer:\r\n".$answertext."\r\n";
	$mailbody .= "\r\n$l_timezone_note $server_timezone\r\nGenerated by FAQEngine V$version (http://www-boesch-it.de)\r\n\r\n";
	mail($tomail,$l_mailsubject,$mailbody,$fromadr);
?>
</table></td></tr>
<tr><TD BGCOLOR="<?php echo $table_bgcolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<TR BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="LEFT">
<td align="center" width="100%">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<?php echo $l_mailsent?></font></td>
<?php
}
echo "</tr></table></td></tr></table>";
if(($usecustomfooter==1) && ($copyrightpos==0))
{
	if(($footerfile) && ($footerfilepos==0))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
	echo $pagefooter;
	if(($footerfile) && ($footerfilepos==1))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
}
?>
<br>
<table align="center" bgcolor="<?php echo $copyrightbgcolor?>" width="<?php echo $TableWidth?>" border="0">
<tr><td align="center">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize4?>" color="<?php echo $FontColor?>">
<?php
if($showcurrtime)
{
	$displaytime=date("H:i");
	echo "$l_currtime $displaytime<br>";
}
if($showtimezone==1)
	echo "$l_timezone_note $server_timezone<br>";
echo "Generated by $copyright_url, $copyright_note";
?>
</td></tr></table>
<br>
<?php
if(($usecustomfooter==1) && ($copyrightpos==1))
{
	if(($footerfile) && ($footerfilepos==0))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
	echo $pagefooter;
	if(($footerfile) && ($footerfilepos==1))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
}
?>
</body></html>
