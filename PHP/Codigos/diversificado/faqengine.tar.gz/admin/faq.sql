# MySQL-Front Dump 1.22
#
# Host: localhost Database: faq
#--------------------------------------------------------
# Server version 3.23.43-nt


#
# Table structure for table 'faq_admins'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_admins;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_admins (
  usernr tinyint(3) unsigned NOT NULL auto_increment,
  username varchar(80) NOT NULL DEFAULT '' ,
  password varchar(40) binary NOT NULL DEFAULT '' ,
  email varchar(80) NOT NULL DEFAULT '' ,
  rights int(2) unsigned NOT NULL DEFAULT '0' ,
  lastlogin datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,
  lockpw tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  signature text NOT NULL DEFAULT '' ,
  autopin int(10) unsigned NOT NULL DEFAULT '0' ,
  language varchar(20) NOT NULL DEFAULT 'en' ,
  PRIMARY KEY (usernr)
);



#
# Table structure for table 'faq_banlist'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_banlist;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_banlist (
  bannr int(10) unsigned NOT NULL auto_increment,
  ipadr varchar(16) NOT NULL DEFAULT '0.0.0.0' ,
  subnetmask varchar(16) NOT NULL DEFAULT '0.0.0.0' ,
  reason text NOT NULL DEFAULT '' ,
  PRIMARY KEY (bannr)
);



#
# Table structure for table 'faq_bindata'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_bindata;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_bindata (
  faqnr int(10) unsigned NOT NULL DEFAULT '0' ,
  bindata longblob NOT NULL DEFAULT '' ,
  filename varchar(240) NOT NULL DEFAULT '' ,
  mimetype varchar(240) NOT NULL DEFAULT '' ,
  filesize int(10) NOT NULL DEFAULT '0' ,
  UNIQUE entrynr (faqnr)
);



#
# Table structure for table 'faq_category'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_category;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_category (
  catnr int(10) unsigned NOT NULL auto_increment,
  categoryname varchar(80) NOT NULL DEFAULT '' ,
  numfaqs int(10) unsigned NOT NULL DEFAULT '0' ,
  programm int(10) unsigned DEFAULT '0' ,
  displaypos int(10) unsigned NOT NULL DEFAULT '0' ,
  PRIMARY KEY (catnr)
);



#
# Table structure for table 'faq_category_admins'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_category_admins;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_category_admins (
  catnr int(10) unsigned NOT NULL DEFAULT '0' ,
  usernr int(10) unsigned NOT NULL DEFAULT '0' 
);



#
# Table structure for table 'faq_category_ref'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_category_ref;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_category_ref (
  srccatnr int(10) unsigned NOT NULL DEFAULT '0' ,
  language varchar(5) NOT NULL DEFAULT '' ,
  destcatnr int(10) unsigned NOT NULL DEFAULT '0' 
);



#
# Table structure for table 'faq_comments'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_comments;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_comments (
  commentnr int(10) unsigned NOT NULL auto_increment,
  faqnr int(10) unsigned NOT NULL DEFAULT '0' ,
  email varchar(140) NOT NULL DEFAULT '' ,
  comment text NOT NULL DEFAULT '' ,
  ipadr varchar(16) NOT NULL DEFAULT '0.0.0.0' ,
  postdate datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,
  rating int(10) unsigned NOT NULL DEFAULT '0' ,
  ratingcount int(10) unsigned NOT NULL DEFAULT '0' ,
  views int(10) unsigned NOT NULL DEFAULT '0' ,
  PRIMARY KEY (commentnr)
);



#
# Table structure for table 'faq_data'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_data;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_data (
  faqnr int(10) unsigned NOT NULL auto_increment,
  heading varchar(80) ,
  category int(10) unsigned NOT NULL DEFAULT '0' ,
  questiontext text ,
  editor varchar(80) NOT NULL DEFAULT 'unknown' ,
  editdate date NOT NULL DEFAULT '0000-00-00' ,
  answertext text ,
  views int(10) unsigned NOT NULL DEFAULT '0' ,
  ratingcount int(10) unsigned NOT NULL DEFAULT '0' ,
  rating int(10) unsigned NOT NULL DEFAULT '0' ,
  displaypos int(10) unsigned NOT NULL DEFAULT '0' ,
  subcategory int(10) unsigned NOT NULL DEFAULT '0' ,
  PRIMARY KEY (faqnr),
  INDEX category (category)
);



#
# Table structure for table 'faq_failed_logins'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_failed_logins;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_failed_logins (
  loginnr int(10) unsigned NOT NULL auto_increment,
  username varchar(250) NOT NULL DEFAULT '0' ,
  ipadr varchar(16) NOT NULL DEFAULT '' ,
  logindate datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,
  usedpw varchar(240) NOT NULL DEFAULT '' ,
  PRIMARY KEY (loginnr)
);



#
# Table structure for table 'faq_failed_notify'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_failed_notify;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_failed_notify (
  usernr int(10) unsigned DEFAULT '0' 
);



#
# Table structure for table 'faq_faq_keywords'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_faq_keywords;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_faq_keywords (
  faqnr int(10) unsigned NOT NULL DEFAULT '0' ,
  keywordnr int(10) unsigned NOT NULL DEFAULT '0' 
);



#
# Table structure for table 'faq_faq_ref'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_faq_ref;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_faq_ref (
  srcfaqnr int(10) unsigned NOT NULL DEFAULT '0' ,
  language varchar(5) NOT NULL DEFAULT '' ,
  destfaqnr int(10) unsigned NOT NULL DEFAULT '0' 
);



#
# Table structure for table 'faq_freemailer'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_freemailer;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_freemailer (
  entrynr int(10) unsigned NOT NULL auto_increment,
  address varchar(100) NOT NULL DEFAULT '' ,
  PRIMARY KEY (entrynr)
);



#
# Table structure for table 'faq_hostcache'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_hostcache;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_hostcache (
  ipadr varchar(16) NOT NULL DEFAULT '0' ,
  hostname varchar(240) NOT NULL DEFAULT '' ,
  UNIQUE ipadr (ipadr)
);



#
# Table structure for table 'faq_iplog'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_iplog;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_iplog (
  lognr int(10) unsigned NOT NULL auto_increment,
  usernr int(10) unsigned NOT NULL DEFAULT '0' ,
  logtime datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,
  ipadr varchar(16) NOT NULL DEFAULT '' ,
  used_lang varchar(4) NOT NULL DEFAULT '' ,
  PRIMARY KEY (lognr)
);



#
# Table structure for table 'faq_kb_articles'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_kb_articles;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_kb_articles (
  articlenr int(10) unsigned NOT NULL auto_increment,
  programm int(10) unsigned NOT NULL DEFAULT '0' ,
  heading varchar(80) NOT NULL DEFAULT '' ,
  article text NOT NULL DEFAULT '' ,
  ratingcount int(10) unsigned NOT NULL DEFAULT '0' ,
  rating int(10) unsigned NOT NULL DEFAULT '0' ,
  editor varchar(80) NOT NULL DEFAULT '' ,
  lastedited date NOT NULL DEFAULT '0000-00-00' ,
  category int(10) unsigned NOT NULL DEFAULT '0' ,
  displaypos int(10) unsigned NOT NULL DEFAULT '0' ,
  subcategory int(10) unsigned NOT NULL DEFAULT '0' ,
  PRIMARY KEY (articlenr)
);



#
# Table structure for table 'faq_kb_cat'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_kb_cat;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_kb_cat (
  catnr int(10) unsigned NOT NULL auto_increment,
  catname varchar(80) NOT NULL DEFAULT '' ,
  heading varchar(250) NOT NULL DEFAULT '' ,
  programm int(10) unsigned NOT NULL DEFAULT '0' ,
  displaypos int(10) unsigned NOT NULL DEFAULT '0' ,
  PRIMARY KEY (catnr)
);



#
# Table structure for table 'faq_kb_keywords'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_kb_keywords;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_kb_keywords (
  articlenr int(10) unsigned NOT NULL DEFAULT '0' ,
  keywordnr int(10) unsigned NOT NULL DEFAULT '0' 
);



#
# Table structure for table 'faq_kb_os'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_kb_os;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_kb_os (
  articlenr int(10) unsigned NOT NULL DEFAULT '0' ,
  osnr int(10) unsigned NOT NULL DEFAULT '0' 
);



#
# Table structure for table 'faq_kb_ratings'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_kb_ratings;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_kb_ratings (
  entrynr int(10) unsigned NOT NULL auto_increment,
  rating int(10) unsigned NOT NULL DEFAULT '0' ,
  articlenr int(10) unsigned NOT NULL DEFAULT '0' ,
  comment tinytext NOT NULL DEFAULT '' ,
  PRIMARY KEY (entrynr)
);



#
# Table structure for table 'faq_kb_subcat'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_kb_subcat;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_kb_subcat (
  catnr int(10) unsigned NOT NULL auto_increment,
  catname varchar(80) NOT NULL DEFAULT '' ,
  heading varchar(250) NOT NULL DEFAULT '' ,
  category int(10) unsigned NOT NULL DEFAULT '0' ,
  displaypos int(10) unsigned NOT NULL DEFAULT '0' ,
  PRIMARY KEY (catnr)
);



#
# Table structure for table 'faq_keywords'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_keywords;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_keywords (
  keywordnr int(10) unsigned NOT NULL auto_increment,
  keyword varchar(250) NOT NULL DEFAULT '' ,
  PRIMARY KEY (keywordnr)
);



#
# Table structure for table 'faq_layout'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_layout;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_layout (
  layoutnr tinyint(3) unsigned NOT NULL DEFAULT '0' ,
  headingbg varchar(8) ,
  bgcolor1 varchar(8) ,
  bgcolor2 varchar(8) ,
  pagebg varchar(8) ,
  tablewidth varchar(10) ,
  fontface varchar(80) ,
  fontsize1 varchar(10) ,
  fontsize2 varchar(10) ,
  fontsize3 varchar(10) ,
  fontcolor varchar(8) ,
  fontsize4 varchar(10) ,
  bgcolor3 varchar(8) ,
  stylesheet varchar(80) ,
  showproglist tinyint(1) unsigned DEFAULT '1' ,
  headingfontcolor varchar(8) ,
  subheadingfontcolor varchar(8) ,
  linkcolor varchar(8) ,
  vlinkcolor varchar(8) ,
  alinkcolor varchar(8) ,
  groupfontcolor varchar(8) ,
  tabledescfontcolor varchar(8) ,
  fontsize5 varchar(10) ,
  dateformat varchar(10) ,
  newtime int(4) unsigned DEFAULT '0' ,
  newpic varchar(80) ,
  searchpic varchar(80) ,
  printpic varchar(80) ,
  backpic varchar(80) ,
  listpic varchar(80) ,
  watchlogins tinyint(1) unsigned DEFAULT '1' ,
  displayrating tinyint(1) unsigned DEFAULT '0' ,
  pageheader text ,
  pagefooter text ,
  usecustomheader tinyint(1) unsigned DEFAULT '1' ,
  usecustomfooter tinyint(1) unsigned DEFAULT '1' ,
  emailpic varchar(80) ,
  allowemail tinyint(1) unsigned DEFAULT '1' ,
  urlautoencode tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  enablespcode tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  nofreemailer tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  allowquestions tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  questionpic varchar(80) ,
  faqemail varchar(140) NOT NULL DEFAULT '' ,
  allowusercomments tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  usercommentpic varchar(80) ,
  newcommentnotify tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  allowlists tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  allowsearch tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  enablefailednotify tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  loginlimit int(5) unsigned NOT NULL DEFAULT '0' ,
  timezone varchar(10) NOT NULL DEFAULT 'GMT' ,
  enablehostresolve tinyint(1) unsigned DEFAULT '1' ,
  searchcomments tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  searchquestions tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  showsummary tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  summarylength tinyint(2) unsigned NOT NULL DEFAULT '40' ,
  progrestrict tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  ratecomments tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  footerfile varchar(240) NOT NULL DEFAULT '' ,
  headerfile varchar(240) NOT NULL DEFAULT '' ,
  printheader tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  printfooter tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  usemenubar tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  mincommentlength int(3) unsigned NOT NULL DEFAULT '0' ,
  minquestionlength int(3) unsigned NOT NULL DEFAULT '0' ,
  proginfopic varchar(80) NOT NULL DEFAULT '' ,
  proginfowidth int(4) unsigned NOT NULL DEFAULT '0' ,
  proginfoheight int(4) unsigned NOT NULL DEFAULT '0' ,
  textareawidth int(4) unsigned NOT NULL DEFAULT '0' ,
  textareaheight int(4) unsigned NOT NULL DEFAULT '0' ,
  proginfoleft int(4) unsigned NOT NULL DEFAULT '0' ,
  proginfotop int(4) unsigned NOT NULL DEFAULT '0' ,
  helpwindowwidth int(4) unsigned NOT NULL DEFAULT '0' ,
  helpwindowheight int(4) unsigned NOT NULL DEFAULT '0' ,
  helpwindowleft int(4) unsigned NOT NULL DEFAULT '0' ,
  helpwindowtop int(4) unsigned NOT NULL DEFAULT '0' ,
  helppic varchar(80) NOT NULL DEFAULT '' ,
  closepic varchar(80) NOT NULL DEFAULT '' ,
  kbmode varchar(20) NOT NULL DEFAULT 'wizard' ,
  enablekbrating tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  defsearchmethod tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  enablekeywordsearch tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  enablelanguageselector tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  faqsortmethod tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  kbsortmethod tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  showtimezone tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  showcurrtime tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  copyrightpos tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  copyrightbgcolor varchar(8) NOT NULL DEFAULT '' ,
  ascheader text NOT NULL DEFAULT '' ,
  subheadingbgcolor varchar(8) NOT NULL DEFAULT '' ,
  actionbgcolor varchar(8) NOT NULL DEFAULT '' ,
  headerfilepos tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  footerfilepos tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  newinfobgcolor varchar(8) NOT NULL DEFAULT '' ,
  useascheader tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  asclinelength int(4) unsigned NOT NULL DEFAULT '0' ,
  ascforcewrap tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  addbodytags varchar(240) NOT NULL DEFAULT '' ,
  asclistmimetype tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  asclistcharset varchar(80) NOT NULL DEFAULT 'iso-8859-1' ,
  userquestionanswermode tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  userquestionanswermail tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  userquestionautopublish tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  keywordsearchmode tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  questionrequireos tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  faqlistshortcuts tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  questionrequireversion tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  newfaqdisplaymethod tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  enablefaqnewdisplay tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  faqnewdisplaybgcolor varchar(8) NOT NULL DEFAULT '' ,
  faqnewdisplayfontcolor varchar(8) NOT NULL DEFAULT '' ,
  listallfaqmethod tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  enableshortcutbar tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  enablejumpboxes tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  subcatbgcolor varchar(8) NOT NULL DEFAULT '' ,
  subcatfontcolor varchar(8) NOT NULL DEFAULT '' ,
  displayrelated tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  htmllisttype int(2) unsigned NOT NULL DEFAULT '0' ,
  pagetoppic varchar(80) NOT NULL DEFAULT 'gfx/top.gif' ,
  attachpic varchar(80) NOT NULL DEFAULT 'gfx/attach.gif' ,
  faqengine_hostname varchar(140) NOT NULL DEFAULT 'localhost' ,
  faqlimitrelated tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  summaryintotallist tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  summarychars tinyint(2) unsigned NOT NULL DEFAULT '40' ,
  ratingcomment tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  maxentries int(10) unsigned NOT NULL DEFAULT '0' ,
  activcellcolor varchar(8) NOT NULL DEFAULT '#ffff72' ,
  ratingspublic tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  ratingcommentpublic tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  hovercells tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  PRIMARY KEY (layoutnr)
);



#
# Table structure for table 'faq_misc'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_misc;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_misc (
  shutdown tinyint(3) unsigned NOT NULL DEFAULT '0' ,
  shutdowntext text 
);



#
# Table structure for table 'faq_os'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_os;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_os (
  osnr int(10) unsigned NOT NULL auto_increment,
  osname varchar(180) NOT NULL DEFAULT '' ,
  PRIMARY KEY (osnr)
);



#
# Table structure for table 'faq_prog_os'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_prog_os;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_prog_os (
  osnr int(10) unsigned NOT NULL DEFAULT '0' ,
  prognr int(10) unsigned NOT NULL DEFAULT '0' 
);



#
# Table structure for table 'faq_programm'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_programm;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_programm (
  prognr int(10) unsigned NOT NULL auto_increment,
  programmname varchar(80) ,
  numcats int(10) unsigned DEFAULT '0' ,
  progid varchar(10) NOT NULL DEFAULT '' ,
  language varchar(5) NOT NULL DEFAULT 'de' ,
  newsgroup varchar(250) NOT NULL DEFAULT '' ,
  newssubject varchar(80) ,
  nntpserver varchar(80) ,
  newsdomain varchar(80) ,
  description text NOT NULL DEFAULT '' ,
  displaypos int(10) unsigned NOT NULL DEFAULT '0' ,
  PRIMARY KEY (prognr)
);



#
# Table structure for table 'faq_programm_admins'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_programm_admins;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_programm_admins (
  prognr int(10) unsigned NOT NULL DEFAULT '0' ,
  usernr int(10) unsigned NOT NULL DEFAULT '0' 
);



#
# Table structure for table 'faq_programm_version'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_programm_version;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_programm_version (
  entrynr int(10) unsigned NOT NULL auto_increment,
  programm int(10) unsigned NOT NULL DEFAULT '0' ,
  version varchar(20) NOT NULL DEFAULT '' ,
  PRIMARY KEY (entrynr)
);



#
# Table structure for table 'faq_questions'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_questions;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_questions (
  questionnr int(10) unsigned NOT NULL auto_increment,
  prognr int(10) unsigned NOT NULL DEFAULT '0' ,
  osname varchar(180) ,
  versionnr varchar(10) ,
  email varchar(140) NOT NULL DEFAULT '' ,
  question text NOT NULL DEFAULT '' ,
  enterdate datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,
  faqref int(10) unsigned DEFAULT '0' ,
  posterip varchar(20) NOT NULL DEFAULT '' ,
  answerdate datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,
  answerauthor int(10) unsigned NOT NULL DEFAULT '0' ,
  answer text NOT NULL DEFAULT '' ,
  language varchar(5) NOT NULL DEFAULT 'de' ,
  questionref int(10) unsigned NOT NULL DEFAULT '0' ,
  publish tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  PRIMARY KEY (questionnr)
);



#
# Table structure for table 'faq_ratings'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_ratings;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_ratings (
  entrynr int(10) unsigned NOT NULL auto_increment,
  rating int(10) unsigned NOT NULL DEFAULT '0' ,
  faqnr int(10) unsigned NOT NULL DEFAULT '0' ,
  comment tinytext NOT NULL DEFAULT '' ,
  PRIMARY KEY (entrynr)
);



#
# Table structure for table 'faq_related_categories'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_related_categories;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_related_categories (
  srccat int(10) unsigned NOT NULL DEFAULT '0' ,
  destcat int(10) unsigned NOT NULL DEFAULT '0' 
);



#
# Table structure for table 'faq_related_faq'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_related_faq;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_related_faq (
  srcfaq int(10) unsigned NOT NULL DEFAULT '0' ,
  destfaq int(10) unsigned NOT NULL DEFAULT '0' 
);



#
# Table structure for table 'faq_related_subcat'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_related_subcat;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_related_subcat (
  srccat int(10) unsigned NOT NULL DEFAULT '0' ,
  destcat int(10) unsigned NOT NULL DEFAULT '0' 
);



#
# Table structure for table 'faq_session'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_session;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_session (
  sessid int(10) unsigned NOT NULL DEFAULT '0' ,
  usernr int(10) NOT NULL DEFAULT '0' ,
  starttime int(10) unsigned NOT NULL DEFAULT '0' ,
  remoteip varchar(15) NOT NULL DEFAULT '' ,
  lastlogin datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,
  PRIMARY KEY (sessid),
  INDEX sess_id (sessid),
  INDEX start_time (starttime),
  INDEX remote_ip (remoteip)
);



#
# Table structure for table 'faq_subcategory'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_subcategory;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_subcategory (
  catnr int(10) unsigned NOT NULL auto_increment,
  categoryname varchar(80) NOT NULL DEFAULT '' ,
  category int(10) unsigned DEFAULT '0' ,
  displaypos int(10) unsigned NOT NULL DEFAULT '0' ,
  PRIMARY KEY (catnr)
);



#
# Table structure for table 'faq_texts'
#

DROP TABLE /*!32200 IF EXISTS*/ faq_texts;
CREATE TABLE /*!32300 IF NOT EXISTS*/ faq_texts (
  textnr int(10) unsigned NOT NULL auto_increment,
  textid varchar(20) NOT NULL DEFAULT '' ,
  lang varchar(4) NOT NULL DEFAULT '' ,
  text text NOT NULL DEFAULT '' ,
  PRIMARY KEY (textnr)
);

