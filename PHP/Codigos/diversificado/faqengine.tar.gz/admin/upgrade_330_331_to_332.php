<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
?>
<html><body>
<div align="center"><h3>FAQEngine: Upgrade v3.30/v3.31 to v3.32</h3></div>
<br>
<?php
echo "Upgrading tables...<br>";
$sql = "ALTER TABLE ".$tableprefix."_admins ";
$sql.= "add language varchar(20) NOT NULL DEFAULT '$admin_lang'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_admins");
$sql = "ALTER TABLE ".$tableprefix."_layout ";
$sql.= "add faqengine_hostname varchar(140) NOT NULL DEFAULT 'localhost' ,";
$sql.= "add faqlimitrelated tinyint(1) unsigned NOT NULL DEFAULT '1'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_layout");
?>
<br><div align="center">Upgrade done.<br>Please remove install.php, upgrade*.php and fill_freemailer.php from server</div>
<div align="center">Now you can login to the <a href="index.php">admininterface</a></div>
</body></html>
