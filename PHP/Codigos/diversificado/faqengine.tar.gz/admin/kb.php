<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
require('./auth.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include('./language/lang_'.$act_lang.'.php');
$page_title=$l_kb_article;
$page="kbedit";
require('./heading.php');
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<?php
if(isset($mode))
{
	if($mode=="display")
	{
		include("./includes/kb_display.inc");
	}
	// Page called with some special mode
	if($mode=="new")
	{
		include("./includes/kb_new.inc");
	}
	if($mode=="new2")
	{
		include("./includes/kb_new2.inc");
	}
	if($mode=="add")
	{
		include("./includes/kb_add.inc");
	}
	if($mode=="delete")
	{
		if($admin_rights < 2)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$deleteSQL = "delete from ".$tableprefix."_kb_articles where (articlenr=$input_articlenr)";
		$success = faqe_db_query($deleteSQL,$db);
		if (!$success)
			die("<tr bgcolor=\"#cccccc\"><td>$l_cantdelete.");
		$deleteSQL = "delete from ".$tableprefix."_kb_os where (articlenr=$input_articlenr)";
		$success = faqe_db_query($deleteSQL,$db);
		if (!$success)
			die("<tr bgcolor=\"#cccccc\"><td>$l_cantdelete.");
		$deleteSQL = "delete from ".$tableprefix."_kb_keywords where (articlenr=$input_articlenr)";
		$success = faqe_db_query($deleteSQL,$db);
		if (!$success)
			die("<tr bgcolor=\"#cccccc\"><td>$l_cantdelete.");
		purge_keywords($db);
		echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
		echo "<i>$heading</i> $l_deleted<br>";
		echo "</td></tr></table></td></tr></table>";
		echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_articlelist</a></div>";
	}
	if($mode=="edit")
	{
		include("./includes/kb_edit.inc");
	}
	if($mode=="edit2")
	{
		include("./includes/kb_edit2.inc");
	}
	if($mode=="update")
	{
		include("./includes/kb_update.inc");
	}
}
else
{
	include("./includes/kb_list.inc");
}
include('./trailer.php');
?>