<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
require('./auth.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include('./language/lang_'.$act_lang.'.php');
$page_title=$l_statistics;
require('./heading.php');
$sql = "select * from ".$tableprefix."_layout where (layoutnr=1)";
if(!$result = faqe_db_query($sql, $db)) {
    die("Could not connect to the database.");
}
$displayrating=0;
$dateformat="Y-m-d";
if ($myrow = faqe_db_fetch_array($result))
{
	$dateformat=$myrow["dateformat"];
	$dateformat2=$dateformat;
	$dateformat2.=" H:i:s";
	$enablekbrating=$myrow["enablekbrating"];
}
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
$act_lang="";
$sql = "select * from ".$tableprefix."_programm order by language, prognr";
if(!$result = faqe_db_query($sql, $db))
    die("Could not connect to the database.");
if (!$myrow = faqe_db_fetch_array($result))
{
	echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
	echo $l_noentries;
?>
</td></tr>
</table></tr></td></table>
<?php
include('./trailer.php');
exit;
}
?>
<tr bgcolor="#94AAD6"><td align="center" colspan="4">
<b><?php echo $l_top10article_prog?></b></td></tr>
<?php
	do {
		$progname=htmlentities($myrow["programmname"]);
		$proglang=$myrow["language"];
		$sql = "select * from ".$tableprefix."_kb_cat where (programm=".$myrow["prognr"].") order by catnr";
		if(!$result2 = faqe_db_query($sql, $db))
		    die("Could not connect to the database.");
		$datasql="";
		if ($myrow2 = faqe_db_fetch_array($result2))
		{
			$datasql = "select *, (rating/ratingcount) as rate from ".$tableprefix."_kb_articles where((category=0) ";
			do {
				$datasql.=" or ";
				$datasql.="(category=".$myrow2["catnr"].")";
			} while($myrow2 = faqe_db_fetch_array($result2));
		}
		if($datasql)
		{
			$datasql .=") order by rate desc limit 10";
			if(!$dataresult = faqe_db_query($datasql, $db))
			    die("<tr bgcolor=\"#cccccc\"><td colspan=\"4\" align=\"center\">Could not connect to the database.".faqe_db_error());
			if ($datarow = faqe_db_fetch_array($dataresult))
			{
				echo "<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"4\">";
				echo "<b>".htmlentities($myrow["programmname"])." [".$myrow["language"]."]</b></td></tr>\n";
				echo "<tr bgcolor=\"#cccccc\">";
				echo "<td align=\"center\" width=\"10%\">&nbsp;</td>";
				echo "<td align=\"center\" width=\"30%\"><b>$l_heading</b></td>";
				echo "<td align=\"center\" colspan=\"2\">";
				if($enablekbrating==1)
					echo "<b>$l_rating</b>";
				else
					echo "&nbsp;";
				echo "</td></tr>\n";
				do {
					echo "<tr bgcolor=\"#cccccc\">";
					echo "<td align=\"center\">";
					echo $datarow["articlenr"];
					echo "</td>";
					echo "<td align=\"center\">";
					echo $datarow["heading"];
					echo "</td>";
					if($enablekbrating==1)
					{
						echo "<td width=\"20%\" align=\"center\">";
						$rating=$datarow["rating"];
						$ratingcount=$datarow["ratingcount"];
						if($ratingcount>0)
						{
							echo $l_ratings[round($rating/$ratingcount,0)];
							echo " ($ratingcount&nbsp;$l_ratingsdone)</td><td width=\"10%\">";
							echo " <img src=\"gfx/bargif.gif\" border=\"0\" width=\"".round(($rating/$ratingcount)*20)."\" height=\"10\">";
							echo " ".round($rating/$ratingcount,2)."</td>";
						}
						else
							echo "--</td><td>&nbsp;</td>";
					}
					else
						echo "<td colspan=\"2\">&nbsp;";
					echo "</td>";
					echo "</tr>\n";
				} while($datarow = faqe_db_fetch_array($dataresult));
			}
			else
			{
				echo "<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"4\">";
				echo "<b>".htmlentities($myrow["programmname"])." [".$myrow["language"]."]</b></td></tr>";
				echo "<tr bgcolor=\"#cccccc\"><td colspan=\"4\" align=\"center\">";
				echo "$l_noentries";
				echo "</td></tr>";
			}
		}
		else
		{
			echo "<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"4\">";
			echo "<b>".htmlentities($myrow["programmname"])." [".$myrow["language"]."]</b></td></tr>";
			echo "<tr bgcolor=\"#cccccc\"><td colspan=\"4\" align=\"center\">";
			echo "$l_noentries";
			echo "</td></tr>";
		}
	} while($myrow = faqe_db_fetch_array($result));
?>
</td></tr>
<tr bgcolor="#94AAD6"><td align="center" colspan="4">
<b><?php echo $l_top10articles?></b></td></tr>
<?php
$sql = "select * from ".$tableprefix."_kb_articles where (rating>0) order by (rating/ratingcount) desc limit 10";
if(!$result = faqe_db_query($sql, $db))
	die("<tr bgcolor=\"#cccccc\"><td colspan=\"4\" align=\"center\">Could not connect to the database.");
if ($myrow = faqe_db_fetch_array($result))
{
	echo "<tr bgcolor=\"#cccccc\"><td align=\"center\" colspan=\"2\"><b>$l_article</b></td>";
	echo "<td colspan=\"2\" align=\"center\">";
	if($enablekbrating==1)
		echo "<b>$l_rating</b>";
	echo "</td></tr>\n";
	do {
		$sql2 = "select * from ".$tableprefix."_kb_cat where (catnr=".$myrow["category"].")";
		if(!$result2 = faqe_db_query($sql2, $db))
			die("<tr bgcolor=\"#cccccc\"><td colspan=\"4\" align=\"center\">Could not connect to the database ($sql2).");
		if ($myrow2 = faqe_db_fetch_array($result2))
			$catname=htmlentities($myrow2["catname"]);
		else
			$catname=$l_none;
		$sql3 = "select * from ".$tableprefix."_programm where (prognr=".$myrow["programm"].")";
		if(!$result3 = faqe_db_query($sql3, $db))
			die("<tr bgcolor=\"#cccccc\"><td colspan=\"4\" align=\"center\">Could not connect to the database ($sql3).");
		if ($myrow3 = faqe_db_fetch_array($result3))
		{
			$progname=htmlentities($myrow3["programmname"]);
			$proglang=$myrow3["language"];
		}
		else
		{
			$progname=$l_none;
			$proglang="";
		}
		echo "<tr bgcolor=\"#cccccc\">";
		echo "<td align=\"center\" width=\"10%\">".$myrow["articlenr"]."</td>";
		echo "<td align=\"center\" width=\"30%\">";
		echo "$progname [$proglang] : $catname : ".$myrow["heading"]."</td>";
		if($enablekbrating==1)
		{
			echo "<td width=\"20%\" align=\"center\">";
			$rating=$myrow["rating"];
			$ratingcount=$myrow["ratingcount"];
			if($ratingcount>0)
			{
				echo $l_ratings[round($rating/$ratingcount,0)];
				echo " ($ratingcount&nbsp;$l_ratingsdone)</td><td width=\"10%\">";
				echo " <img src=\"gfx/bargif.gif\" border=\"0\" width=\"".round(($rating/$ratingcount)*20)."\" height=\"10\">";
				echo " ".round($rating/$ratingcount,2)."</td>";
			}
			else
				echo "--</td><td>&nbsp;</td>";
		}
		else
			echo "<td colspan=\"2\">&nbsp;";
		echo "</td>";
		echo "</tr>\n";
	} while($myrow = faqe_db_fetch_array($result));
}
else
{
	echo "<tr bgcolor=\"#cccccc\"><td colspan=\"4\" align=\"center\">";
	echo $l_noentries;
	echo "</td></tr>\n";
}
?>
</td></tr>
<tr bgcolor="#94AAD6"><td align="center" colspan="4">
<b><?php echo $l_last10articles?></b></td></tr>
<?php
$sql = "select * from ".$tableprefix."_kb_articles where (rating>0) order by (rating/ratingcount) asc limit 10";
if(!$result = faqe_db_query($sql, $db))
	die("<tr bgcolor=\"#cccccc\"><td colspan=\"4\" align=\"center\">Could not connect to the database.");
if ($myrow = faqe_db_fetch_array($result))
{
	echo "<tr bgcolor=\"#cccccc\"><td align=\"center\" colspan=\"2\"><b>$l_article</b></td>";
	echo "<td colspan=\"2\" align=\"center\">";
	if($enablekbrating==1)
		echo "<b>$l_rating</b>";
	echo "</td></tr>\n";
	do {
		$sql2 = "select * from ".$tableprefix."_kb_cat where (catnr=".$myrow["category"].")";
		if(!$result2 = faqe_db_query($sql2, $db))
			die("<tr bgcolor=\"#cccccc\"><td colspan=\"4\" align=\"center\">Could not connect to the database ($sql2).");
		if ($myrow2 = faqe_db_fetch_array($result2))
			$catname=htmlentities($myrow2["catname"]);
		else
			$catname=$l_none;
		$sql3 = "select * from ".$tableprefix."_programm where (prognr=".$myrow["programm"].")";
		if(!$result3 = faqe_db_query($sql3, $db))
			die("<tr bgcolor=\"#cccccc\"><td colspan=\"4\" align=\"center\">Could not connect to the database ($sql3).");
		if ($myrow3 = faqe_db_fetch_array($result3))
		{
			$progname=htmlentities($myrow3["programmname"]);
			$proglang=$myrow3["language"];
		}
		else
		{
			$progname=$l_none;
			$proglang="";
		}
		echo "<tr bgcolor=\"#cccccc\">";
		echo "<td align=\"center\" width=\"10%\">".$myrow["articlenr"]."</td>";
		echo "<td align=\"center\" width=\"30%\">";
		echo "$progname [$proglang] : $catname : ".$myrow["heading"]."</td>";
		if($enablekbrating==1)
		{
			echo "<td width=\"20%\" align=\"center\">";
			$rating=$myrow["rating"];
			$ratingcount=$myrow["ratingcount"];
			if($ratingcount>0)
			{
				echo $l_ratings[round($rating/$ratingcount,0)];
				echo " ($ratingcount&nbsp;$l_ratingsdone)</td><td width=\"10%\">";
				echo " <img src=\"gfx/bargif.gif\" border=\"0\" width=\"".round(($rating/$ratingcount)*20)."\" height=\"10\">";
				echo " ".round($rating/$ratingcount,2)."</td>";
			}
			else
				echo "--</td><td>&nbsp;</td>";
		}
		else
			echo "<td colspan=\"2\">&nbsp;";
		echo "</td>";
		echo "</tr>\n";
	} while($myrow = faqe_db_fetch_array($result));
}
else
{
	echo "<tr bgcolor=\"#cccccc\"><td colspan=\"4\" align=\"center\">";
	echo $l_noentries;
	echo "</td></tr>\n";
}
?>
</td></tr>
</table></td></tr>
</table></tr></td></table>
<?php
include('./trailer.php');
?>