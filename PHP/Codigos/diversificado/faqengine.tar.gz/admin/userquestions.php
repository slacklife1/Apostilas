<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
require('./auth.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include('language/lang_'.$act_lang.'.php');
$page_title=$l_userquestions;
require('./heading.php');
$sql = "select * from ".$tableprefix."_layout where (layoutnr=1)";
if(!$result = faqe_db_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = faqe_db_fetch_array($result))
{
	$dateformat=$myrow["dateformat"];
	$dateformat.=" H:i:s";
	$userquestionanswermail=$myrow["userquestionanswermail"];
	$userquestionanswermode=$myrow["userquestionanswermode"];
	$userquestionautopublish=$myrow["userquestionautopublish"];
}
else
{
	$dateformat="Y-m-d H:i:s";
	$userquestionanswermail=0;
	$userquestionanswermode=0;
	$userquestionautopublish=0;
}
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<?php
if(isset($mode))
{
	if($mode=="display")
	{
		if($admin_rights < 1)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?
		$sql = "select * from ".$tableprefix."_questions where (questionnr=$input_questionnr)";
		if(!$result = faqe_db_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
		if (!$myrow = faqe_db_fetch_array($result))
			die("<tr bgcolor=\"#cccccc\"><td>no such entry");
		$progsql = "select * from ".$tableprefix."_programm where (prognr=".$myrow["prognr"].")";
		if(!$progresult=faqe_db_query($progsql,$db))
		    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
		if(!$progrow=faqe_db_fetch_array($progresult))
			$progname=$l_none;
		else
			$progname=htmlentities($progrow["programmname"]);
		$questiontext = $myrow["question"];
		$questiontext = htmlentities($questiontext);
		$questiontext = str_replace("\n", "<BR>", $questiontext);
?>
<tr bgcolor="#94AAD6"><td align="center" colspan="2"><b><?php echo $l_displayuserquestion?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_progname?>:</td><td><?php echo $progname?></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_os?>:</td><td><?php echo $myrow["osname"]?></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_usedversion?>:</td><td><?php echo $myrow["versionnr"]?></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_email?>:</td><td><?php echo $myrow["email"]?></td></tr>
<?php
		list($mydate,$mytime)=explode(" ",$myrow["enterdate"]);
		list($year, $month, $day) = explode("-", $mydate);
		list($hour, $min, $sec) = explode(":",$mytime);
		if($month>0)
			$displaydate=date($dateformat,mktime($hour,$min,$sec,$month,$day,$year));
		else
			$displaydate="";
?>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_date?>:</td><td><?php echo $displaydate?></td></tr>
<?php
		if($myrow["faqref"]>0)
		{
			$tempsql = "select * from ".$tableprefix."_data where faqnr=".$myrow["faqref"];
			if(!$tempresult=faqe_db_query($tempsql,$db))
			    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
			if($temprow=faqe_db_fetch_array($tempresult))
			{
				$faq_heading=$temprow["heading"];
				$tempsql = "select * from ".$tableprefix."_category where catnr=".$temprow["category"];
				if(!$tempresult=faqe_db_query($tempsql,$db))
				    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
				if($temprow=faqe_db_fetch_array($tempresult))
					$faq_category=htmlentities($temprow["categoryname"]);
				else
					$faq_category=$l_none;
?>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_faqref2?>:</td><td><?php echo $faq_category.":".$faq_heading?>
&nbsp;&nbsp;&nbsp;
<?php
if($admin_rights<2)
	echo "<a href=\"".do_url_session("faq.php?$langvar=$act_lang&input_faqnr=".$myrow["faqref"]."&mode=display")."\" target=\"_blank\">$l_display";
else
	echo "<a href=\"".do_url_session("faq.php?$langvar=$act_lang&input_faqnr=".$myrow["faqref"]."&mode=edit")."\" target=\"_blank\">$l_edit";
?>
</a>
</td></tr>
<?php
			}
		}
		if($myrow["questionref"]>0)
		{
?>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_questionref?>:</td><td><?php echo "#".$myrow["questionref"]?>
&nbsp;&nbsp;&nbsp;<a href="<?php echo do_url_session("$PHP_SELF?$langvar=$act_lang&mode=display&input_questionnr=".$myrow["questionref"])?>"><?php echo $l_display?></a>
<?php
		}
?>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_ipadr?>:</td><td><?php echo $myrow["posterip"]?></td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_question?>:</td><td><?php echo $questiontext?></td></tr>
<form method="post" action="<?php echo $PHP_SELF?>"><tr bgcolor="#c0c0c0"><td>&nbsp;</td><td valign="middle">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="mode" value="publish">
<input type="hidden" name="input_questionnr" value="<?php echo $input_questionnr?>">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="checkbox" name="dopublish" value="1" <?php if ($myrow["publish"]==1) echo "checked"?>> <?php echo $l_publish?>
 &nbsp;&nbsp;&nbsp;<input type="submit" value="<?php echo $l_ok?>"></td></tr></form>
<?php
if($myrow["answerauthor"]>0)
{
	$tempsql = "select username from ".$tableprefix."_admins where usernr=".$myrow["answerauthor"];
	if(!$tempresult=faqe_db_query($tempsql,$db))
	    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
	if($temprow=faqe_db_fetch_array($tempresult))
		$authorname=$temprow["username"];
	else
		$authorname=$l_none;
	list($mydate,$mytime)=explode(" ",$myrow["answerdate"]);
	list($year, $month, $day) = explode("-", $mydate);
	list($hour, $min, $sec) = explode(":",$mytime);
	if($month>0)
		$displaydate=date($dateformat,mktime($hour,$min,$sec,$month,$day,$year));
	else
		$displaydate=$l_unknown;
?>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_answered?>:</td><td><?php echo $authorname.", ".$displaydate?></td></tr>
<?
	if(($admin_rights>2) || (($admin_rights>1) && ($myrow["answerauthor"]==$userdata["usernr"])))
	{
		$answertext=$myrow["answer"];
		$answertext=htmlentities($answertext);
		$answertext = str_replace("\n", "<BR>", $answertext);
?>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_answer?>:</td><td><?php echo $answertext?></td></tr>
<tr bgcolor="#c0c0c0"><td align="center" valign="top"><?php echo $l_transferquestion?></td>
<form method="post" action="question2faq.php">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="mode" value="transfer">
<input type="hidden" name="input_questionnr" value="<?php echo $input_questionnr?>">
<td><input type="checkbox" name="transferdel" value="1"><?php echo $l_deleteaftertransfer?><br>
<input type="checkbox" name="delquotes" value="1"><?php echo $l_removequotes?><br>
<input type="submit" value="<?php echo $l_copy?>">
</td></form>
</tr>
<?php
		if($userquestionanswermode==0)
		{
?>
<tr bgcolor="#94AAD6"><td align="center" colspan="2"><a href="<?php echo do_url_session("$PHP_SELF?$langvar=$act_lang&input_questionnr=$input_questionnr&mode=answer")?>"><?php echo $l_answerquestion?></a></td></tr>
<?php
		}
		else
		{
?>
<tr bgcolor="#94AAD6"><td align="center" colspan="2"><a href="<?php echo do_url_session("question2faq.php?mode=transfer&$langvar=$act_lang&input_questionnr=$input_questionnr&transferdel=1")?>"><?php echo $l_answerquestion?></a></td></tr>
<?php
		}
	}
}
else
{
		if($userquestionanswermode==0)
		{
?>
<tr bgcolor="#94AAD6"><td align="center" colspan="2"><a href="<?php echo do_url_session("$PHP_SELF?$langvar=$act_lang&input_questionnr=$input_questionnr&mode=answer")?>"><?php echo $l_answerquestion?></a></td></tr>
<?php
		}
		else
		{
?>
<tr bgcolor="#94AAD6"><td align="center" colspan="2"><a href="<?php echo do_url_session("question2faq.php?mode=transfer&$langvar=$act_lang&input_questionnr=$input_questionnr&transferdel=1")?>"><?php echo $l_answerquestion?></a></td></tr>
<?php
		}
	}
		echo "</table></td></tr></table>";
		echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_userquestions</a></div>";
	}
	if($mode=="publish")
	{
		if($admin_rights < 2)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
		if(isset($dopublish))
			$publish=1;
		else
			$publish=0;
		$sql = "update ".$tableprefix."_questions set publish=$publish where (questionnr=$input_questionnr)";
		if(!$result = faqe_db_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr bgcolor="#94AAD6"><td align="center"><b><?php echo $l_publishquestion?></b></td></tr>
<tr bgcolor="#cccccc"><td align="center"><?php echo $l_questionpublished?></td></tr>
</table></td></tr></table>
<div align="center"><a href="<?php echo do_url_session("$PHP_SELF?$langvar=$act_lang")?>"><?php echo $l_userquestions?></a></div>
<?
	}
	if($mode=="answer")
	{
		if($admin_rights < 2)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
		if(strlen($userdata["email"])<1)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_noadminmail");
		}
		$sql = "select * from ".$tableprefix."_questions where (questionnr=$input_questionnr)";
		if(!$result = faqe_db_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
		if (!$myrow = faqe_db_fetch_array($result))
			die("<tr bgcolor=\"#cccccc\"><td>no such entry");
		list($mydate,$mytime)=explode(" ",$myrow["enterdate"]);
		list($year, $month, $day) = explode("-", $mydate);
		list($hour, $min, $sec) = explode(":",$mytime);
		if($month>0)
			$displaydate=date($dateformat,mktime($hour,$min,$sec,$month,$day,$year));
		else
			$displaydate="";
		if(strlen($myrow["language"])>0)
			$questionlang=$myrow["language"];
		else
			$questionlang=$default_lang;
		include('language/userquestions_'.$questionlang.'.php');
		$answertext = "> ".str_replace("\n", "\n> ", $myrow["question"]);
		$answertext = htmlentities($answertext);
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr bgcolor="#94AAD6"><td align="center" colspan="2"><b><?php echo $l_answerquestion?></b></td></tr>
<form method="post" action="<?php echo $PHP_SELF?>"><input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="input_questionnr" value="<?php echo $input_questionnr?>">
<input type="hidden" name="mode" value="sendanswer">
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_sender?>:</td><td><?php echo $userdata["email"]?></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_receiver?>:</td><td><?php echo $myrow["email"]?></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%" valign="top"><?php echo $l_answer?>:</td><td><?php echo $l_answer_prelude?><br><textarea name="answer" cols="50" rows="10" wrap="virtual"><?php echo $answertext?></textarea></td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_options?>:</td>
<td align="left"><input type="checkbox" name="dontemail" value="1" <?php if($userquestionanswermail==0) echo "checked"?>> <?php echo $l_dontsendanswer?></td></tr>
<tr bgcolor="#94AAD6"><td align="center" colspan="2"><input type="submit" value="<?php echo $l_send?>"></td></tr>
</form>
</table></td></tr></table>
<div align="center"><a href="<?php echo do_url_session("$PHP_SELF?$langvar=$act_lang")?>"><?php echo $l_userquestions?></a></div>
<?
	}
	if($mode=="sendanswer")
	{
		if($admin_rights < 2)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
		if((strlen($userdata["email"])<1) && (!isset($dontemail)))
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_noadminmail");
		}
		$answer=strip_tags($answer);
		$sql = "select * from ".$tableprefix."_questions where (questionnr=$input_questionnr)";
		if(!$result = faqe_db_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
		if (!$myrow = faqe_db_fetch_array($result))
			die("<tr bgcolor=\"#cccccc\"><td>no such entry");
		list($mydate,$mytime)=explode(" ",$myrow["enterdate"]);
		list($year, $month, $day) = explode("-", $mydate);
		list($hour, $min, $sec) = explode(":",$mytime);
		if($month>0)
			$displaydate=date($dateformat,mktime($hour,$min,$sec,$month,$day,$year));
		else
			$displaydate="";
		if(!isset($dontemail))
		{
			$fromadr = "From:".$userdata["email"];
			if(strlen($myrow["language"])>0)
				$questionlang=$myrow["language"];
			else
				$questionlang=$default_lang;
			include('language/userquestions_'.$questionlang.'.php');
			$mailbody = $l_answer_prelude."\n".$answer;
			$mailbody = str_replace("\n","\r\n",$mailbody);
			$mailbody .="\r\n\r\n";
			if(strlen($userdata["signature"])>1)
			{
				$sigtext=str_replace("\n","\r\n",$userdata["signature"]);
				$mailbody .= "---\r\n";
				$mailbody .=$sigtext;
				$mailbody .="\r\n\r\n";
			}
			$mailbody.="\r\n";
			$fromadr = "From:".$userdata["email"];
			$subject = $l_answer_subject;
			mail($myrow["email"],$subject,$mailbody,$fromadr);
		}
		$actdate = date("Y-m-d H:i:s");
		$sql = "UPDATE ".$tableprefix."_questions set answerauthor=".$userdata["usernr"].", answerdate='$actdate', answer='$answer'";
		if($userquestionautopublish==1)
			$sql.=", publish=1";
		$sql.=" where questionnr=$input_questionnr";
		if(!$result = faqe_db_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr bgcolor="#94AAD6"><td align="center"><b><?php echo $l_answerquestion?></b></td></tr>
<tr bgcolor="#cccccc"><td align="center"><?php echo $l_questionanswered?></td></tr>
<?php
		if(!isset($dontemail))
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">$l_answersent</td></tr>";
?>
</table></td></tr></table>
<div align="center"><a href="<?php echo do_url_session("$PHP_SELF?$langvar=$act_lang")?>"><?php echo $l_userquestions?></a></div>
<?
	}
	if($mode=="delete")
	{
		if($admin_rights < 2)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$deleteSQL = "delete from ".$tableprefix."_questions where (questionnr=$input_questionnr)";
		$success = faqe_db_query($deleteSQL,$db);
		if (!$success)
			die("<tr bgcolor=\"#cccccc\"><td>$l_cantdelete.");
		echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
		echo "$l_deleted<br>";
		echo "</td></tr></table></td></tr></table>";
		echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_userquestions</a></div>";
	}
}
else
{
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?
if($admin_rights<3)
	$sql = "select q.* from ".$tableprefix."_questions q, ".$tableprefix."_programm_admins pa where pa.usernr=$act_usernr and q.prognr=pa.prognr order by q.enterdate desc";
else
	$sql = "select q.* from ".$tableprefix."_questions q order by q.enterdate desc";
if(!$result = faqe_db_query($sql, $db)) {
    die("Could not connect to the database.");
}
if (!$myrow = faqe_db_fetch_array($result))
{
	echo "<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"3\">";
	echo $l_noentries;
	echo "</td></tr></table></td></tr></table>";
}
else
{
?>
<tr bgcolor="#c0c0c0">
<td align="center"><b><?php echo $l_question?></b></td>
<td align="center"><b><?php echo $l_progname?></b></td>
<td align="center"><b><?php echo $l_date?></b></td>
<td align="center"><b><?php echo $l_email?></b></td>
<td align="center"><b><?php echo $l_answered?></b></td>
<td>&nbsp;</td></tr>
<?php
	do {
		$act_id=$myrow["questionnr"];
		$prog_sql="select * from ".$tableprefix."_programm where prognr=".$myrow["prognr"];
		if(!$prog_result = faqe_db_query($prog_sql, $db)) {
		    die("Could not connect to the database.");
		}
		if($progrow=faqe_db_fetch_array($prog_result))
			$progname=htmlentities($progrow["programmname"]);
		else
			$progname=$l_undefined;
		$mod_sql ="select * from ".$tableprefix."_programm_admins where prognr=".$myrow["prognr"]." and usernr=".$userdata["usernr"];
		if(!$mod_result = faqe_db_query($mod_sql, $db)) {
		    die("Could not connect to the database.");
		}
		if($modrow=faqe_db_fetch_array($mod_result))
			$ismod=1;
		else
			$ismod=0;
		if($myrow["answerauthor"]>0)
		{
			if($myrow["enterdate"]>$userdata["lastlogin"])
				echo "<tr bgcolor=\"#cccc00\">";
			else
				echo "<tr bgcolor=\"#cccccc\">";
		}
		else
		{
			if($myrow["enterdate"]>$userdata["lastlogin"])
				echo "<tr bgcolor=\"#eeee00\">";
			else
				echo "<tr bgcolor=\"#eeeeee\">";
		}
		list($mydate,$mytime)=explode(" ",$myrow["enterdate"]);
		list($year, $month, $day) = explode("-", $mydate);
		list($hour, $min, $sec) = explode(":",$mytime);
		if($month>0)
			$displaydate=date($dateformat,mktime($hour,$min,$sec,$month,$day,$year));
		else
			$displaydate="";
		echo "<td width=\"5%\" align=\"right\">".$myrow["questionnr"]."</td>";
		echo "<td width=\"20%\" align=\"center\">$progname</td>";
		echo "<td width=\"25%\" align=\"center\">$displaydate</td>";
		echo "<td width=\"25%\" align=\"center\">".$myrow["email"]."</td>";
		if($myrow["answerauthor"]>0)
			echo "<td align=\"center\" width=\"10%\">$l_yes";
		else
			echo "<td align=\"center\" width=\"10%\">$l_no";
		if($myrow["publish"]==1)
			echo " *";
		echo "</td>";
		echo "<td>";
		if(($admin_rights > 2) || ($ismod==1))
		{
			echo "<a href=\"".do_url_session("$PHP_SELF?mode=display&$langvar=$act_lang&input_questionnr=$act_id")."\">";
			echo "$l_display</a>";
			echo "&nbsp;&nbsp;";
			echo "<a href=\"".do_url_session("$PHP_SELF?mode=delete&input_questionnr=$act_id&$langvar=$act_lang")."\">";
			echo "$l_delete</a>";
			if($myrow["answerauthor"]>0)
			{
				echo "<br>";
				echo "<a href=\"".do_url_session("question2faq.php?mode=transfer&input_questionnr=$act_id&$langvar=$act_lang")."\">";
				echo "$l_transferquestion</a>";
			}
		}
		echo "</td></tr>";
   } while($myrow = faqe_db_fetch_array($result));
   echo "</table></tr></td></table>";
}
}
include('trailer.php');
?>