<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
require('./auth.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include('./language/lang_'.$act_lang.'.php');
$page_title=$l_freemailerlist;
require('./heading.php');
$sql = "select * from ".$tableprefix."_layout where (layoutnr=1)";
if(!$result = faqe_db_query($sql, $db)) {
    die("Could not connect to the database.");
}
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<?php
if(isset($mode))
{
	if($mode=="display")
	{
		if($admin_rights < 1)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?
		$sql = "select * from ".$tableprefix."_freemailer where (entrynr=$input_entrynr)";
		if(!$result = faqe_db_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
		if (!$myrow = faqe_db_fetch_array($result))
			die("<tr bgcolor=\"#cccccc\"><td>no such entry");
?>
<tr bgcolor="#94AAD6"><td align="center" colspan="2"><b><?php echo $l_editfreemailer?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_freemaileradr?>:</td><td><?php echo htmlentities($myrow["address"])?></td></tr>
</table></td></tr></table>
<?php
		echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_freemailerlist</a></div>";
	}
	// Page called with some special mode
	if($mode=="newadr")
	{
		if($admin_rights < 3)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
		// Display empty form for entering userdata
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr><td bgcolor="#94AAD6" align="center" colspan="2"><b><?php echo $l_newfreemailer?></b></td></tr>
<form method="post" action="<?php echo $PHP_SELF?>"><input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_freemaileradr?>:</td><td><input type="text" name="address" size="30" maxlength="100"></td></tr>
<tr bgcolor="#94aad6"><td align="center" colspan="2"><input type="hidden" name="mode" value="add"><input type="submit" value="<?php echo $l_add?>"></td></tr>
</form>
</table></td></tr></table>
<div align="center"><a href="<?php echo do_url_session("$PHP_SELF?$langvar=$act_lang")?>"><?php echo $l_freemailerlist?></a></div>
<?php
	}
	if($mode=="add")
	{
		if($admin_rights < 3)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$errors=0;
		if(!$address)
		{
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$l_noaddress</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			$sql = "INSERT INTO ".$tableprefix."_freemailer (address) ";
			$sql .="VALUES ('$address')";
			if(!$result = faqe_db_query($sql, $db))
			    die("<tr bgcolor=\"#cccccc\"><td>Unable to add address to database.");
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$l_adradded";
			echo "</td></tr></table></td></tr></table>";
			echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?mode=newadr&$langvar=$act_lang")."\">$l_newfreemailer</a></div>";
			echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_freemailerlist</a></div>";
		}
		else
		{
			echo "<tr bgcolor=\"#94AAD6\" align=\"center\"><td>";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
	}
	if($mode=="delete")
	{
		if($admin_rights < 3)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$deleteSQL = "delete from ".$tableprefix."_freemailer where (entrynr=$input_entrynr)";
		$success = faqe_db_query($deleteSQL,$db);
		if (!$success)
			die("<tr bgcolor=\"#cccccc\"><td>$l_cantdelete.");
		echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
		echo "$l_deleted<br>";
		echo "</td></tr></table></td></tr></table>";
		echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_freemailerlist</a></div>";
	}
	if($mode=="edit")
	{
		if($admin_rights < 3)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?
		$sql = "select * from ".$tableprefix."_freemailer where (entrynr=$input_entrynr)";
		if(!$result = faqe_db_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
		if (!$myrow = faqe_db_fetch_array($result))
			die("<tr bgcolor=\"#cccccc\"><td>no such entry");
?>
<tr bgcolor="#94AAD6"><td align="center" colspan="2"><b><?php echo $l_editfreemailer?></b></td></tr>
<form method="post" action="<?php echo $PHP_SELF?>"><input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="input_entrynr" value="<?php echo $myrow["entrynr"]?>">
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_freemaileradr?>:</td><td><input type="text" name="address" size="30" maxlength="100" value="<?php echo htmlentities($myrow["address"])?>"></td></tr>
<tr bgcolor="#94AAD6"><td align="center" colspan="2"><input type="hidden" name="mode" value="update"><input type="submit" value="<?php echo $l_update?>"></td></tr>
</form>
</table></td></tr></table>
<div align="center"><a href="<?php echo do_url_session("$PHP_SELF?$langvar=$act_lang")?>"><?php echo $l_freemailerlist?></a></div>
<?php
	}
	if($mode=="update")
	{
		if($admin_rights < 3)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$errors=0;
		if(!$address)
		{
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$l_noaddress</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			$sql = "UPDATE ".$tableprefix."_freemailer SET address='$address' ";
			$sql .="WHERE (entrynr = $input_entrynr)";
			if(!$result = faqe_db_query($sql, $db))
			    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$l_adrupdated";
			echo "</td></tr></table></td></tr></table>";
			echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_freemailerlist</a></div>";
		}
		else
		{
			echo "<tr bgcolor=\"#94AAD6\" align=\"center\"><td>";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
	}
}
else
{
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
	if($admin_rights>2)
	{
?>
<tr bgcolor="#94AAD6"><td colspan="6" align="center">
<a href="<?php echo do_url_session("$PHP_SELF?mode=newadr&$langvar=$act_lang")?>"><?php echo $l_newfreemailer?></a>
</table></td></tr></table>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?
	}
$sql = "select * from ".$tableprefix."_freemailer order by address";
if(!$result = faqe_db_query($sql, $db)) {
    die("Could not connect to the database.");
}
if (!$myrow = faqe_db_fetch_array($result))
{
	echo "<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"2\">";
	echo $l_noentries;
	echo "</td></tr></table></td></tr></table>";
}
else
{
?>
<tr bgcolor="#c0c0c0">
<td align="center" width="70%"><b><?php echo $l_freemaileradr?></b></td>
<td width="30%">&nbsp;</td></tr>
<?php
		do {
		$act_id=$myrow["entrynr"];
		echo "<tr bgcolor=\"#cccccc\">";
		echo "<td>".htmlentities($myrow["address"])."</td>";
		echo "<td>";
		if($admin_rights > 2)
		{
			echo "<a href=\"".do_url_session("$PHP_SELF?mode=delete&input_entrynr=$act_id&$langvar=$act_lang")."\">";
			echo "$l_delete</a>";
			echo "&nbsp;&nbsp;";
			echo "<a href=\"".do_url_session("$PHP_SELF?mode=edit&$langvar=$act_lang&input_entrynr=$act_id")."\">";
			echo "$l_edit</a>";
		}
		else
		{
			echo "<a href=\"".do_url_session("$PHP_SELF?mode=display&input_entrynr=$act_id&$langvar=$act_lang")."\">";
			echo "$l_display</a>";
		}
		echo "</td></tr>";
   } while($myrow = faqe_db_fetch_array($result));
   echo "</table></tr></td></table>";
}
if($admin_rights > 2)
{
?>
<div align="center"><a href="<?php echo do_url_session("$PHP_SELF?mode=newadr&$langvar=$act_lang")?>"><?php echo $l_newfreemailer?></a></div>
<?php
}
}
include('./trailer.php');
?>