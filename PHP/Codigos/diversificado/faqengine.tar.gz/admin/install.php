<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
?>
<html><body>
<div align="center"><h3>FAQEngine V<?php echo $version?> Install</h3></div>
<br>
<?php
if(isset($submit))
{
if(!$admin_pw1 || !$admin_pw2 || !$admin_user)
	die("Needed fields not filled");
if($admin_pw1 != $admin_pw2)
{
	echo "<div align=\"center\">";
	echo "<font color=\"#ff2200\"><b>Error</b>: Passwords don't match</font>";
	echo "</div><br>";
}
else
{
// create table faq_kb_ratings
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_kb_ratings;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_kb_ratings");
$sql = "CREATE TABLE ".$tableprefix."_kb_ratings (";
$sql.= "entrynr int(10) unsigned NOT NULL auto_increment,";
$sql.= "rating int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "articlenr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "comment tinytext NOT NULL DEFAULT '' ,";
$sql.= "PRIMARY KEY (entrynr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_kb_ratings");
// create table faq_ratings
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_ratings;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_ratings");
$sql = "CREATE TABLE ".$tableprefix."_ratings (";
$sql.= "entrynr int(10) unsigned NOT NULL auto_increment,";
$sql.= "rating int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "faqnr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "comment tinytext NOT NULL DEFAULT '' ,";
$sql.= "PRIMARY KEY (entrynr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_ratings");
// create table faq_bindata
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_bindata;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_bindata");
$sql = "CREATE TABLE ".$tableprefix."_bindata (";
$sql.= "faqnr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "bindata longblob NOT NULL DEFAULT '' ,";
$sql.= "filename varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "mimetype varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "filesize int(10) NOT NULL DEFAULT '0' ,";
$sql.= "UNIQUE entrynr (faqnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_bindata");
// create table faq_related_faq
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_related_faq;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_related_faq");
$sql = "CREATE TABLE ".$tableprefix."_related_faq (";
$sql.= "srcfaq int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "destfaq int(10) unsigned NOT NULL DEFAULT '0' );";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_related_faq");
// create table faq_related_subcat
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_related_subcat;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_related_subcat");
$sql = "CREATE TABLE ".$tableprefix."_related_subcat (";
$sql.= "srccat int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "destcat int(10) unsigned NOT NULL DEFAULT '0' );";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_related_subcat");
// create table faq_related_categories
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_related_categories;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_related_categories");
$sql = "CREATE TABLE ".$tableprefix."_related_categories (";
$sql.= "srccat int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "destcat int(10) unsigned NOT NULL DEFAULT '0' );";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_related_categories");
// create table faq_kb_subcat
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_kb_subcat;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_kb_subcat");
$sql = "CREATE TABLE ".$tableprefix."_kb_subcat (";
$sql.= "catnr int(10) unsigned NOT NULL auto_increment,";
$sql.= "catname varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "heading varchar(250) NOT NULL DEFAULT '' ,";
$sql.= "category int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "displaypos int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "PRIMARY KEY (catnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_kb_subcat");
// create table faq_subcategory
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_subcategory;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_subcategory");
$sql = "CREATE TABLE ".$tableprefix."_subcategory (";
$sql.= "catnr int(10) unsigned NOT NULL auto_increment,";
$sql.= "categoryname varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "category int(10) unsigned DEFAULT '0' ,";
$sql.= "displaypos int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "PRIMARY KEY (catnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_subcategory");
// create table faq_programm_version
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_programm_version;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_programm_version");
$sql = "CREATE TABLE ".$tableprefix."_programm_version (";
$sql.= "entrynr int(10) unsigned NOT NULL auto_increment,";
$sql.= "programm int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "version varchar(20) NOT NULL DEFAULT '' ,";
$sql.= "PRIMARY KEY (entrynr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_programm_version");
// create table faq_faq_ref
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_faq_ref;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_faq_ref");
$sql = "CREATE TABLE ".$tableprefix."_faq_ref (";
$sql.="srcfaqnr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.="language varchar(5) NOT NULL DEFAULT '' ,";
$sql.="destfaqnr int(10) unsigned NOT NULL DEFAULT '0');";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_faq_ref");
// create table faq_category_ref
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_category_ref;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_category_ref");
$sql = "CREATE TABLE ".$tableprefix."_category_ref (";
$sql.="srccatnr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.="language varchar(5) NOT NULL DEFAULT '' ,";
$sql.="destcatnr int(10) unsigned NOT NULL DEFAULT '0');";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_category_ref");
// create table faq_keywords
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_keywords;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_keywords");
$sql = "CREATE TABLE ".$tableprefix."_keywords (";
$sql.="keywordnr int(10) unsigned NOT NULL auto_increment,";
$sql.="keyword varchar(250) NOT NULL DEFAULT '' ,";
$sql.="PRIMARY KEY (keywordnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_keywords");
// create table faq_kb_os
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_kb_os;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_kb_os");
$sql = "CREATE TABLE ".$tableprefix."_kb_os (";
$sql.="articlenr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.="osnr int(10) unsigned NOT NULL DEFAULT '0');";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_kb_os");
// create table faq_kb_keywords
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_kb_keywords;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_kb_keywords");
$sql = "CREATE TABLE ".$tableprefix."_kb_keywords (";
$sql.="articlenr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.="keywordnr int(10) unsigned NOT NULL DEFAULT '0');";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_kb_keywords");
// create table faq_kb_cat
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_kb_cat;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_kb_cat");
$sql = "CREATE TABLE ".$tableprefix."_kb_cat (";
$sql.="catnr int(10) unsigned NOT NULL auto_increment,";
$sql.="catname varchar(80) NOT NULL DEFAULT '' ,";
$sql.="heading varchar(250) NOT NULL DEFAULT '' ,";
$sql.="programm int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.="displaypos int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.="PRIMARY KEY (catnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_kb_cat");
// create table faq_kb_articles
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_kb_articles;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_kb_articles");
$sql = "CREATE TABLE ".$tableprefix."_kb_articles (";
$sql .="articlenr int(10) unsigned NOT NULL auto_increment,";
$sql .="programm int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="heading varchar(80) NOT NULL DEFAULT '' ,";
$sql .="article text NOT NULL DEFAULT '' ,";
$sql .="ratingcount int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="rating int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="editor varchar(80) NOT NULL DEFAULT '' ,";
$sql .="lastedited date NOT NULL DEFAULT '0000-00-00' ,";
$sql .="category int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="displaypos int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="subcategory int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="PRIMARY KEY (articlenr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_kb_articles");
// create table faq_faq_keywords
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_faq_keywords;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_faq_keywords");
$sql = "CREATE TABLE ".$tableprefix."_faq_keywords (";
$sql.="faqnr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.="keywordnr int(10) unsigned NOT NULL DEFAULT '0');";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_faq_keywords");
// create table faq_hostcache
if(!table_exists($hcprefix."_hostcache"))
{
	$sql = "CREATE TABLE /*!32300 IF NOT EXISTS*/ ".$hcprefix."_hostcache (";
	$sql .="ipadr varchar(16) NOT NULL DEFAULT '0' ,";
	$sql .="hostname varchar(240) NOT NULL DEFAULT '' ,";
	$sql .="UNIQUE ipadr (ipadr));";
	if(!$result = mysql_query($sql, $db))
		die("Unable to create table ".$hcprefix."_hostcache");
}
// create table faq_texts
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_texts;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_texts");
$sql = "CREATE TABLE ".$tableprefix."_texts (";
$sql .="textnr int(10) unsigned NOT NULL auto_increment,";
$sql .="textid varchar(20) NOT NULL DEFAULT '' ,";
$sql .="lang varchar(4) NOT NULL DEFAULT '' ,";
$sql .="text text NOT NULL DEFAULT '' ,";
$sql .="PRIMARY KEY (textnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_texts");
// create table faq_failed_notify
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_failed_notify;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_failed_notify");
$sql = "CREATE TABLE ".$tableprefix."_failed_notify (";
$sql .="usernr int(10) unsigned DEFAULT '0');";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_failed_notify");
// create table faq_questions
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_questions;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_questions");
$sql = "CREATE TABLE ".$tableprefix."_questions (";
$sql .="questionnr int(10) unsigned NOT NULL auto_increment,";
$sql .="prognr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="osname varchar(180) ,";
$sql .="versionnr varchar(10) ,";
$sql .="email varchar(140) NOT NULL DEFAULT '' ,";
$sql .="question text NOT NULL DEFAULT '' ,";
$sql .="enterdate datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql .="faqref int(10) unsigned DEFAULT '0' ,";
$sql .="posterip varchar(20) NOT NULL DEFAULT '' ,";
$sql .="answerdate datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql .="answerauthor int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="answer text NOT NULL DEFAULT '' ,";
$sql .="language varchar(5) NOT NULL DEFAULT 'de' ,";
$sql .="questionref int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="publish tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="PRIMARY KEY (questionnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_questions");
// create table faq_prog_os
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_prog_os;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_prog_os");
$sql = "CREATE TABLE ".$tableprefix."_prog_os (";
$sql .="osnr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="prognr int(10) unsigned NOT NULL DEFAULT '0');";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_prog_os");
// create table faq_os
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_os;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_os");
$sql = "CREATE TABLE ".$tableprefix."_os (";
$sql .="osnr int(10) unsigned NOT NULL auto_increment,";
$sql .="osname varchar(180) NOT NULL DEFAULT '' ,";
$sql .="PRIMARY KEY (osnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_os");
// create table faq_failed_logins
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_failed_logins;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_failed_logins");
$sql = "CREATE TABLE ".$tableprefix."_failed_logins (";
$sql .="loginnr int(10) unsigned NOT NULL auto_increment,";
$sql .="username varchar(250) NOT NULL DEFAULT '0' ,";
$sql .="ipadr varchar(16) NOT NULL DEFAULT '' ,";
$sql .="logindate datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql .="usedpw varchar(240) NOT NULL DEFAULT '' ,";
$sql .="PRIMARY KEY (loginnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_failed_logins");
// create table faq_freemailer
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_comments;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_comments");
$sql = "CREATE TABLE ".$tableprefix."_comments (";
$sql .="commentnr int(10) unsigned NOT NULL auto_increment,";
$sql .="faqnr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="email varchar(140) NOT NULL DEFAULT '' ,";
$sql .="comment text NOT NULL DEFAULT '' ,";
$sql .="ipadr varchar(16) NOT NULL DEFAULT '0.0.0.0' ,";
$sql .="postdate datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql .="rating int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="ratingcount int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="views int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="PRIMARY KEY (commentnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_comments");
// create table faq_freemailer
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_freemailer;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_freemailer");
$sql = "CREATE TABLE ".$tableprefix."_freemailer (";
$sql .="entrynr int(10) unsigned NOT NULL auto_increment,";
$sql .="address varchar(100) NOT NULL DEFAULT '' ,";
$sql .="PRIMARY KEY (entrynr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_freemailer");
// create table faq_banlist
if(!table_exists($banprefix."_banlist"))
{
	$sql = "CREATE TABLE /*!32300 IF NOT EXISTS*/ ".$banprefix."_banlist (";
	$sql .="bannr int(10) unsigned NOT NULL auto_increment,";
	$sql .="ipadr varchar(16) NOT NULL DEFAULT '0.0.0.0' ,";
	$sql .="subnetmask varchar(16) NOT NULL DEFAULT '0.0.0.0' ,";
	$sql .="reason text NOT NULL DEFAULT '' ,";
	$sql .="PRIMARY KEY (bannr));";
	if(!$result = mysql_query($sql, $db))
		die("Unable to create table ".$banprefix."_banlist");
}
// create table faq_category
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_category;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_category");
$sql = "CREATE TABLE ".$tableprefix."_category (";
$sql .="catnr int(10) unsigned NOT NULL auto_increment,";
$sql .="categoryname varchar(80) NOT NULL DEFAULT '' ,";
$sql .="numfaqs int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="programm int(10) unsigned DEFAULT '0' ,";
$sql .="displaypos int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="PRIMARY KEY (catnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_category");
// create table faq_programm_admins
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_programm_admins;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_programm_admins");
$sql = "CREATE TABLE ".$tableprefix."_programm_admins (";
$sql .="prognr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="usernr int(10) unsigned NOT NULL DEFAULT '0');";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_programm_admins");
// create table faq_category_admins
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_category_admins;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_category_admins");
$sql = "CREATE TABLE ".$tableprefix."_category_admins (";
$sql .="catnr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="usernr int(10) unsigned NOT NULL DEFAULT '0');";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_category_admins");
// create table faq_data
$sql ="DROP TABLE IF EXISTS ".$tableprefix."_data;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_data");
$sql ="CREATE TABLE ".$tableprefix."_data (";
$sql .="faqnr int(10) unsigned NOT NULL auto_increment,";
$sql .="heading varchar(80) ,";
$sql .="category int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="questiontext text ,";
$sql .="editor varchar(80) NOT NULL DEFAULT 'unknown' ,";
$sql .="editdate date NOT NULL DEFAULT '0000-00-00' ,";
$sql .="answertext text ,";
$sql .="views int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="ratingcount int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="rating int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="displaypos int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="subcategory int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="PRIMARY KEY (faqnr),";
$sql .="INDEX category (category));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_question");
// create table faq_programm
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_programm;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_programm");
$sql = "CREATE TABLE ".$tableprefix."_programm (";
$sql .="prognr int(10) unsigned NOT NULL auto_increment,";
$sql .="programmname varchar(80) ,";
$sql .="numcats int(10) unsigned DEFAULT '0' ,";
$sql .="progid varchar(10) NOT NULL DEFAULT '' ,";
$sql .="language varchar(5) NOT NULL DEFAULT 'de' ,";
$sql .="newsgroup varchar(250) NOT NULL DEFAULT '' ,";
$sql .="newssubject varchar(80) ,";
$sql .="nntpserver varchar(80) ,";
$sql .="newsdomain varchar(80) ,";
$sql .="description text NOT NULL DEFAULT '' ,";
$sql .="displaypos int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="PRIMARY KEY (prognr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_programm");
// create table faq_admins
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_admins;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_admins");
$sql = "CREATE TABLE ".$tableprefix."_admins (";
$sql .="usernr tinyint(3) unsigned NOT NULL auto_increment,";
$sql .="username varchar(80) NOT NULL DEFAULT '' ,";
$sql .="password varchar(40) binary NOT NULL DEFAULT '' ,";
$sql .="email varchar(80) NOT NULL DEFAULT '' ,";
$sql .="rights int(2) unsigned NOT NULL DEFAULT '0' ,";
$sql .="lastlogin datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql .="lockpw tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="signature text ,";
$sql .="autopin int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="language varchar(20) NOT NULL DEFAULT 'en' ,";
$sql .="PRIMARY KEY (usernr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_admins");
// create table faq_iplog
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_iplog;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_iplog");
$sql = "CREATE TABLE ".$tableprefix."_iplog (";
$sql .="lognr int(10) unsigned NOT NULL auto_increment,";
$sql .="usernr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="logtime datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql .="ipadr varchar(16) NOT NULL DEFAULT '' ,";
$sql .="used_lang varchar(4) NOT NULL DEFAULT '' ,";
$sql .="PRIMARY KEY (lognr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_iplog");
// create table faq_layout
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_layout;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_layout");
$sql = "CREATE TABLE ".$tableprefix."_layout (";
$sql .="layoutnr tinyint(3) unsigned NOT NULL DEFAULT '0' ,";
$sql .="headingbg varchar(8) ,";
$sql .="bgcolor1 varchar(8) ,";
$sql .="bgcolor2 varchar(8) ,";
$sql .="pagebg varchar(8) ,";
$sql .="tablewidth varchar(10) ,";
$sql .="fontface varchar(80) ,";
$sql .="fontsize1 varchar(10) ,";
$sql .="fontsize2 varchar(10) ,";
$sql .="fontsize3 varchar(10) ,";
$sql .="fontcolor varchar(8) ,";
$sql .="fontsize4 varchar(10) ,";
$sql .="bgcolor3 varchar(8) ,";
$sql .="stylesheet varchar(80) ,";
$sql .="showproglist tinyint(1) unsigned DEFAULT '1' ,";
$sql .="headingfontcolor varchar(8) ,";
$sql .="subheadingfontcolor varchar(8) ,";
$sql .="linkcolor varchar(8) ,";
$sql .="vlinkcolor varchar(8) ,";
$sql .="alinkcolor varchar(8) ,";
$sql .="groupfontcolor varchar(8) ,";
$sql .="tabledescfontcolor varchar(8) ,";
$sql .="fontsize5 varchar(10) ,";
$sql .="dateformat varchar(10) ,";
$sql .="newtime int(4) unsigned DEFAULT '0' ,";
$sql .="newpic varchar(80) ,";
$sql .="searchpic varchar(80) ,";
$sql .="printpic varchar(80) ,";
$sql .="backpic varchar(80) ,";
$sql .="listpic varchar(80) ,";
$sql .="watchlogins tinyint(1) unsigned DEFAULT '1' ,";
$sql .="displayrating tinyint(1) unsigned DEFAULT '1' ,";
$sql .="pageheader text ,";
$sql .="pagefooter text ,";
$sql .="usecustomheader tinyint(1) unsigned DEFAULT '1' ,";
$sql .="usecustomfooter tinyint(1) unsigned DEFAULT '1' ,";
$sql .="emailpic varchar(80) ,";
$sql .="allowemail tinyint(1) DEFAULT '1' ,";
$sql .="urlautoencode tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql .="enablespcode tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql .="nofreemailer tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="allowquestions tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql .="questionpic varchar(80) ,";
$sql .="faqemail varchar(140) NOT NULL DEFAULT '' ,";
$sql .="allowusercomments tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql .="usercommentpic varchar(80) ,";
$sql .="newcommentnotify tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql .="allowlists tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql .="allowsearch tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql .="enablefailednotify tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="loginlimit int(5) unsigned NOT NULL DEFAULT '0' ,";
$sql .="timezone varchar(10) NOT NULL DEFAULT 'GMT' ,";
$sql .="enablehostresolve tinyint(1) unsigned DEFAULT '1' ,";
$sql .="searchcomments tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql .="searchquestions tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql .="showsummary tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql .="summarylength tinyint(2) unsigned NOT NULL DEFAULT '40' ,";
$sql .="progrestrict tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql .="ratecomments tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql .="footerfile varchar(240) NOT NULL DEFAULT '' ,";
$sql .="headerfile varchar(240) NOT NULL DEFAULT '' ,";
$sql .="printheader tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="printfooter tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="usemenubar tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql .="mincommentlength int(3) unsigned NOT NULL DEFAULT '0' ,";
$sql .="minquestionlength int(3) unsigned NOT NULL DEFAULT '0' ,";
$sql .="proginfopic varchar(80) NOT NULL DEFAULT '' ,";
$sql .="proginfowidth int(4) unsigned NOT NULL DEFAULT '0' ,";
$sql .="proginfoheight int(4) unsigned NOT NULL DEFAULT '0' ,";
$sql .="proginfoleft int(4) unsigned NOT NULL DEFAULT '0' ,";
$sql .="proginfotop int(4) unsigned NOT NULL DEFAULT '0' ,";
$sql .="textareawidth int(4) unsigned NOT NULL DEFAULT '0' ,";
$sql .="textareaheight int(4) unsigned NOT NULL DEFAULT '0' ,";
$sql .="helpwindowwidth int(4) unsigned NOT NULL DEFAULT '0' ,";
$sql .="helpwindowheight int(4) unsigned NOT NULL DEFAULT '0' ,";
$sql .="helpwindowleft int(4) unsigned NOT NULL DEFAULT '0' ,";
$sql .="helpwindowtop int(4) unsigned NOT NULL DEFAULT '0' ,";
$sql .="helppic varchar(80) NOT NULL DEFAULT '' ,";
$sql .="closepic varchar(80) NOT NULL DEFAULT '' ,";
$sql .="kbmode varchar(20) NOT NULL DEFAULT 'wizard' ,";
$sql .="enablekbrating tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="defsearchmethod tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="enablekeywordsearch tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql .="enablelanguageselector tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="faqsortmethod tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="kbsortmethod tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="showtimezone tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="showcurrtime tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="copyrightpos tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="copyrightbgcolor varchar(8) NOT NULL DEFAULT '' ,";
$sql .="ascheader text NOT NULL DEFAULT '' ,";
$sql .="subheadingbgcolor varchar(8) NOT NULL DEFAULT '' ,";
$sql .="actionbgcolor varchar(8) NOT NULL DEFAULT '' ,";
$sql .="headerfilepos tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="footerfilepos tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="newinfobgcolor varchar(8) NOT NULL DEFAULT '' ,";
$sql .="useascheader tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="asclinelength int(4) unsigned NOT NULL DEFAULT '0' ,";
$sql .="ascforcewrap tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="addbodytags varchar(240) NOT NULL DEFAULT '' ,";
$sql .="asclistmimetype tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="asclistcharset varchar(80) NOT NULL DEFAULT 'iso-8859-1' ,";
$sql .="userquestionanswermode tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="userquestionanswermail tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="userquestionautopublish tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="keywordsearchmode tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="questionrequireos tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql .="faqlistshortcuts tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="questionrequireversion tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="newfaqdisplaymethod tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="enablefaqnewdisplay tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="faqnewdisplaybgcolor varchar(8) NOT NULL DEFAULT '' ,";
$sql .="faqnewdisplayfontcolor varchar(8) NOT NULL DEFAULT '' ,";
$sql .="listallfaqmethod tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="enableshortcutbar tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="enablejumpboxes tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="subcatbgcolor varchar(8) NOT NULL DEFAULT '' ,";
$sql .="subcatfontcolor varchar(8) NOT NULL DEFAULT '' ,";
$sql .="displayrelated tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="htmllisttype int(2) unsigned NOT NULL DEFAULT '0' ,";
$sql .="pagetoppic varchar(80) NOT NULL DEFAULT 'gfx/top.gif' ,";
$sql .="attachpic varchar(80) NOT NULL DEFAULT 'gfx/attach.gif' ,";
$sql .="faqengine_hostname varchar(140) NOT NULL DEFAULT 'localhost' ,";
$sql .="faqlimitrelated tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql .="summaryintotallist tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="summarychars tinyint(2) unsigned NOT NULL DEFAULT '40' ,";
$sql .="ratingcomment tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="maxentries int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="activcellcolor varchar(8) NOT NULL DEFAULT '#ffff72' ,";
$sql .="ratingspublic tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="ratingcommentpublic tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="hovercells tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql .="PRIMARY KEY (layoutnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_layout");
// create table faq_session
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_session;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_session");
$sql = "CREATE TABLE ".$tableprefix."_session (";
$sql .="sessid int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="usernr int(10) NOT NULL DEFAULT '0' ,";
$sql .="starttime int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql .="remoteip varchar(15) NOT NULL DEFAULT '' ,";
$sql .="lastlogin datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql .="PRIMARY KEY (sessid),";
$sql .="INDEX sessid (sessid),";
$sql .="INDEX starttime (starttime),";
$sql .="INDEX remoteip (remoteip));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_session");
// create table faq_misc
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_misc;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_misc");
$sql = "CREATE TABLE ".$tableprefix."_misc (";
$sql .="shutdown tinyint(3) unsigned NOT NULL DEFAULT '0' ,";
$sql .="shutdowntext text);";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_misc");
// insert adminuser
$admin_pw=md5($admin_pw1);
$admin_user=addslashes(strtolower($admin_user));
$sql = "INSERT INTO ".$tableprefix."_admins (";
$sql .="username, password, rights, language";
if(isset($admin_email))
	$sql .=", email";
$sql .=")";
$sql .="VALUES ('$admin_user', '$admin_pw', 3, '$inputlang'";
if(isset($admin_email))
	$sql .=", '$admin_email'";
$sql .=");";
if(!$result = mysql_query($sql, $db))
	die("Unable to create adminuser");
if(isset($importfreemailer))
{
	require('./fill_freemailer.php');
	fill_freemailer($tableprefix,$db);
}
?>
<br><div align="center">Installation done.<br>Please remove install.php, upgrade*.php and fill_freemailer.php from server</div>
<div align="center">Now you can login to the <a href="index.php">admininterface</a></div>
</body></html>
<?php
exit;
}
}
if(!isset($admin_user))
	$admin_user="";
if(!isset($admin_email))
	$admin_email="";
?>
<table align="center" width="80%">
<tr><td align="center" colspan="3"><b>Adminuser</b></td></tr>
<form action="<?php echo $PHP_SELF?>" method="post">
<tr><td align="right">Username:</td><td align="center" width="1%">*</td>
<td><input type="text" name="admin_user" size="40" maxlength="80" value="<?php echo $admin_user?>"></td></tr>
<tr><td align="right">E-Mail:</td><td align="center" width="1%">&nbsp;</td>
<td><input type="text" name="admin_email" size="40" maxlength="80" value="<?php echo $admin_email?>"></td></tr>
<tr><td align="right">Password:</td><td align="center" width="1%">*</td>
<td><input type="password" name="admin_pw1" size="40" maxlength="40"></td></tr>
<tr><td align="right">retype password:</td><td align="center" width="1%">*</td>
<td><input type="password" name="admin_pw2" size="40" maxlength="40"></td></tr>
<tr><td align="right">Language:</td><td align="center" width="1%">*</td>
<td><?php echo language_select($admin_lang,"inputlang","./language/")?></td></tr>
<tr><td colspan="2">&nbsp;</td><td align="left"><input type="checkbox" name="importfreemailer" value="1"> import predefined freemailer</td></TR>
<tr><td align="center" colspan="3"><input type="submit" name="submit" value="submit"></td></tr>
</form>
</table>
</body></html>
<?php
function language_select($default, $name="language", $dirname="language/")
{
	$dir = opendir($dirname);
	$lang_select = "<SELECT NAME=\"$name\">\n";
	while ($file = readdir($dir))
	{
		if (ereg("^lang_", $file))
		{
			$file = str_replace("lang_", "", $file);
			$file = str_replace(".php", "", $file);
			$file == $default ? $selected = " SELECTED" : $selected = "";
			$lang_select .= "  <OPTION value=\"$file\"$selected>$file\n";
		}
	}
	$lang_select .= "</SELECT>\n";
	closedir($dir);
	return $lang_select;
}
function table_exists($searchedtable)
{
	global $dbname;

	$tables = mysql_list_tables($dbname);
	$numtables = @mysql_numrows($tables);
	for($i=0;$i<$numtables;$i++)
	{
		$tablename = mysql_tablename($tables,$i);
		if($tablename==$searchedtable)
			return true;
	}
	return false;
}
?>