<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
function do_login($username, $password, $db)
{
	global $tableprefix, $userdata, $sesscookietime, $sesscookiename, $cookiepath, $cookiedomain, $cookiesecure, $REMOTE_ADDR, $act_lang, $url_sessid, $sessid_url, $enablerecoverpw, $db_dateformat_full;

	$pinlogin=0;
	$sql = "select * from ".$tableprefix."_layout where (layoutnr=1)";
	if(!$result = faqe_db_query($sql, $db)) {
		die("Could not connect to the database.");
	}
	if ($myrow = faqe_db_fetch_array($result))
	{
		$watchlogins=$myrow["watchlogins"];
		$enablefailednotify=$myrow["enablefailednotify"];
		$faqemail=$myrow["faqemail"];
		if(!$faqemail)
			$faqemail="faq@foo.bar";
		$dateformat=$myrow["dateformat"];
		$dateformat.=" H:i:s";
		$loginlimit=$myrow["loginlimit"];
	}
	else
	{
		$watchlogins=1;
		$enablefailednotify=0;
		$faqemail="faq@foo.bar";
		$dateformat="Y-m-d H:i:s";
		$loginlimit=0;
	}
	$banreason="";
	if(isbanned($REMOTE_ADDR,$db))
	{
		return -99; exit;
	}
	if(!$username)
	{
		return -1; exit;
	}
	if(!$password)
	{
		return -2; exit;
	}
	$pw=md5($password);
	$sql = "select * from ".$tableprefix."_admins where (username = '$username') and (password = '$pw')";
	if(!$result = faqe_db_query($sql, $db))
	    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database");
	if (!$myrow = faqe_db_fetch_array($result))
	{
		if(!$enablerecoverpw)
		{
			log_failed($username, $password, $REMOTE_ADDR, $dateformat, $db, $tableprefix, $enablefailednotify, $faqemail);
			return 0;
		}
		$sql = "select * from ".$tableprefix."_admins where (username = '$username') and (autopin = '$password') and (autopin!=0)";
		if(!$result = faqe_db_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database");
		if (!$myrow = faqe_db_fetch_array($result))
		{
			log_failed($username, $password, $REMOTE_ADDR, $dateformat, $db, $tableprefix, $enablefailednotify, $faqemail);
			return 0;
		}
		else
		{
			$pinlogin=1;
		}
	}
	$userdata = get_userdata($username, $db);
	if(($userdata["rights"]<3) && ($loginlimit>0))
	{
		cleanup_old_sessions($sesscookietime,$db);
		if($loginlimit <= count_logged_users($db))
		{
			return 22; exit;
		}
	}
	$sessid = new_session($userdata["usernr"], $REMOTE_ADDR, $sesscookietime, $db, $userdata["lastlogin"]);
	if($sessid_url)
		$url_sessid=$sessid;
	else
		set_sessioncookie($sessid, $sesscookietime, $sesscookiename, $cookiepath, $cookiedomain, $cookiesecure);
	$actdate = date($db_dateformat_full);
	$sql = "UPDATE ".$tableprefix."_admins set lastlogin='$actdate' where usernr=".$userdata["usernr"];
	if(!$result = faqe_db_query($sql, $db))
		die("Could not connect to the database (".$tableprefix."_admins).");
	if($watchlogins==1)
	{
		$actdate = date($db_dateformat_full);
		$sql = "INSERT ".$tableprefix."_iplog (usernr, logtime, ipadr, used_lang) values (".$userdata["usernr"].", '$actdate', '$REMOTE_ADDR', '$act_lang')";
		if(!$result = faqe_db_query($sql, $db))
			die("Could not connect to the database (".$tableprefix."_iplog).");
	}
	if($pinlogin==0)
	{
		$sql = "update ".$tableprefix."_admins set autopin=0 where usernr=".$userdata["usernr"];
		if(!$result = faqe_db_query($sql, $db))
			die("Could not connect to the database (".$tableprefix."_admins).");
		return 1;
		exit;
	}
	else
	{
		return 4711;
		exit;
	}
}

function count_logged_users($db)
{
	global $tableprefix;
	$sql = "select * from ".$tableprefix."_session";
	if(!$result=faqe_db_query($sql,$db))
		die("Error counting logged users");
	$numusers=faqe_db_num_rows($result);
	return $numusers;
}

function get_userdata($username, $db)
{
	global $tableprefix;
	$sql = "SELECT * FROM ".$tableprefix."_admins WHERE username = '$username'";
	if(!$result = faqe_db_query($sql, $db))
		$userdata = array("error" => "1");
	if(!$myrow = faqe_db_fetch_array($result))
	{
		$userdata = array("error" => "1");
	}
	return($myrow);
}

function cleanup_old_sessions($lifetime,$db)
{
	global $tableprefix;
	$expiretime = (string) (time() - $lifetime);
	$delsql = "DELETE FROM ".$tableprefix."_session WHERE (starttime < $expiretime)";
	$delresult = faqe_db_query($delsql, $db);
	if (!$delresult) {
		die("Error deleting old sessions");
	}
}

function new_session($userid, $ip, $lifetime, $db, $lastlogin)
{
	global $tableprefix;
	mt_srand((double)microtime()*1000000);
	$sessid = mt_rand();
	$currtime = time();
	cleanup_old_sessions($lifetime,$db);
	$sql = "INSERT INTO ".$tableprefix."_session (sessid, usernr, starttime, remoteip, lastlogin) VALUES ($sessid, $userid, $currtime, '$ip', '$lastlogin')";
	$result = faqe_db_query($sql, $db);
	if ($result) {
		return $sessid;
	} else {
		die("Unable to create new session");
	}
}

function set_sessioncookie($sessid, $cookietime, $cookiename, $cookiepath, $cookiedomain, $cookiesecure) {
	setcookie($cookiename,$sessid,0,$cookiepath,$cookiedomain,$cookiesecure);
}

function get_userid_from_session($sessid, $cookietime, $ip, $db)
{
	global $tableprefix;
	$mintime = time() - $cookietime;
	$sql = "SELECT usernr FROM ".$tableprefix."_session WHERE (sessid = $sessid) AND (starttime > $mintime) AND (remoteip = '$ip')";
	$result = faqe_db_query($sql, $db);
	if (!$result) {
		die("Unable to connect to database");
	}
	$row = faqe_db_fetch_array($result);
	if (!$row) {
		return 0;
	} else {
		return $row["usernr"];
	}
}

function get_lastlogin_from_session($sessid, $cookietime, $ip, $db)
{
	global $tableprefix;
	$mintime = time() - $cookietime;
	$sql = "SELECT lastlogin FROM ".$tableprefix."_session WHERE (sessid = $sessid) AND (starttime > $mintime) AND (remoteip = '$ip')";
	$result = faqe_db_query($sql, $db);
	if (!$result) {
		die("Unable to connect to database");
	}
	$row = faqe_db_fetch_array($result);
	if (!$row) {
		return 0;
	} else {
		return $row["lastlogin"];
	}
}

function update_session($sessid, $db)
{
	global $tableprefix;
	$newtime = (string) time();
	$sql = "UPDATE ".$tableprefix."_session SET starttime=$newtime WHERE (sessid = $sessid)";
	$result = faqe_db_query($sql, $db);
	if (!$result) {
		die("Unable to connect to database");
	}
	return 1;
}

function get_userdata_by_id($userid, $db)
{
	global $tableprefix;
	$sql = "SELECT * FROM ".$tableprefix."_admins WHERE usernr = $userid";
	if(!$result = faqe_db_query($sql, $db)) {
		$userdata = array("error" => "1");
		return ($userdata);
	}
	if(!$myrow = faqe_db_fetch_array($result)) {
		$userdata = array("error" => "1");
		return ($userdata);
	}
	return($myrow);
}

function end_session($userid, $db)
{
	global $tableprefix;
	$sql = "DELETE FROM ".$tableprefix."_session WHERE (usernr = $userid)";
	$result = faqe_db_query($sql, $db);
	if (!$result) {
		die("Unable to connect to database");
	}
	return 1;
}

function ipinrange($verifyip, $ipadr, $subnetmask)
{
	list($val1,$val2,$val3,$val4)=explode(".",$ipadr);
	list($val5,$val6,$val7,$val8)=explode(".",$subnetmask);
	$val9 = $val1;
	$val10 = 0;
	$val11 = 0;
	$val12 = 0;
	$val13 = $val1;
	$val14 = 0;
	$val15 = 0;
	$val16 = 0;
	$val17 = "-";
	$n = 0;
	$smdec = ($val6 * 65536) + ($val7 * 256) + $val8;
	$ipdec = ($val2 * 65536) + ($val3 * 256) + $val4;
	for ($t = 2; $t < 25; $t++)
	{
		if ($smdec == (16777216 - pow(2,$t)))
			($n = 32 - $t);
	}
	if ($n > 23){
		$x = pow(2,(32 - $n));
		for ($i = - 1;  $i < (256 - $x);  $i = ($i + $x))
		{
			if (($val4 >= ($i + 1)) && ($val4 <= ($i + $x)))
			{
				$val12 = ($i + 2);
				$val16 = ($i + ($x - 1));
			}
		}
		$val10 = $val2;
		$val11 = $val3;
		$val14 = $val2;
		$val15 = $val3;
	}
	if (($n >= 16) && ($n < 24)){
		$x = pow(2,(24 - $n));
		for ($i = 0;  $i <= (256 - $x);  $i = ($i + $x))
		{
			if (($val3 >= ($i)) && ($val3 <= ($i + $x)))
			{
				$val11 = ($i);
				$val15 = ($i + ($x - 1));
			}
		}
		$val10 = $val2;
		$val14 = $val2;
		$val12 = 1;
		$val16 = 254;
	}
	if (($n >= 8) && ($n < 16)){
		$x = pow(2,(16 - $n));
		for ($i = 0;  $i <= (256 - $x);  $i = ($i + $x))
		{
			if (($val2 >= ($i)) && ($val2 <= ($i + $x)))
			{
				$val10 = ($i);
				$val14 = ($i + ($x - 1));
			}
		}
		$val11 = 0;
		$val15 = 255;
		$val12 = 1;
		$val16 = 254;
	}
	$val12--;
	$val16++;
	$rangestart = "$val9.$val10.$val11.$val12";
	$rangeend = "$val13.$val14.$val15.$val16";
	$startdec = ip2long($rangestart);
	$enddec = ip2long($rangeend);
	$verifydec = ip2long($verifyip);
	if(($startdec <= $verifydec) && ($enddec >= $verifydec))
	{
		return true;
	}
	return false;
}

function isbanned($ipadr, $db)
{
	global $banprefix, $banreason;

	$sql="select * from ".$banprefix."_banlist";
	if(!$result = faqe_db_query($sql, $db))
	    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database (faq_banlist)");
	if (!$myrow = faqe_db_fetch_array($result))
	{
		return false;
		exit;
	}
	do{
		if(ipinrange($ipadr,$myrow["ipadr"],$myrow["subnetmask"]))
		{
			$banreason=stripslashes($myrow["reason"]);
			$banreason = undo_htmlspecialchars($banreason);
			return true;
		}
	}while($myrow = faqe_db_fetch_array($result));
	return false;
}

function log_failed($username, $password, $remoteip, $dateformat, $db, $tableprefix, $enablefailednotify, $faqemail)
{
	global $db_dateformat_full;
	$actdate = date($db_dateformat_full);
	$displaydate = date($dateformat);
	$sql = "INSERT INTO ".$tableprefix."_failed_logins (username, ipadr, logindate, usedpw) ";
	$sql .="values ('$username', '$remoteip', '$actdate', '$password')";
	echo $sql;
	if(!$result = faqe_db_query($sql, $db))
	    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database");
	if($enablefailednotify)
	{
		$sql = "select u.email from ".$tableprefix."_failed_notify fn, ".$tableprefix."_admins u where u.usernr=fn.usernr";
		if(!$result = faqe_db_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database");
		if($myrow=faqe_db_fetch_array($result))
		{
			$usercount=0;
			$fromadr = "From:".$faqemail."\r\n";
			$subject = "Info from FAQEngine";
			$mailmsg = "Fehlgeschlagener Loginversuch.\r\n";
			$mailmsg .="Failed login.\r\n";
			$mailmsg .="$displaydate, $REMOTE_ADDR\r\n";
			$mailmsg .="Username: $username\r\n";
			$mailmsg .="PW: $password\r\n\r\n";
			do{
				if(strlen($myrow["email"])>1)
				{
					if($usercount==0)
					{
						$receiver=$myrow["email"];
						$usercount+=1;
					}
					else
					{
						$receiver.=", ".$myrow["email"];
					}
				}
			}while($myrow=faqe_db_fetch_array($result));
			mail($receiver,$subject,$mailmsg,$fromadr);
		}
	}
}
?>