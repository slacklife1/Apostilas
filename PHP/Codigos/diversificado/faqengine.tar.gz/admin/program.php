<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
require('./auth.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include('./language/lang_'.$act_lang.'.php');
$page_title=$l_programm_title;
require('./heading.php');
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<?php
if(isset($mode))
{
	if($mode=="display")
	{
		if($admin_rights < 1)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
		$sql = "select * from ".$tableprefix."_programm where (prognr=$input_prognr)";
		if(!$result = faqe_db_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
		if (!$myrow = faqe_db_fetch_array($result))
			die("<tr bgcolor=\"#cccccc\"><td>no such entry");
		$descriptiontext=stripslashes($myrow["description"]);
		$descriptiontext = undo_htmlspecialchars($descriptiontext);
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr><td bgcolor="#94AAD6" align="center" colspan="2"><b><?php echo $l_editprogs?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_progname?>:</td>
<td><?php echo htmlentities($myrow["programmname"])?></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_id?>:</td>
<td><?php echo $myrow["progid"]?></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_language?>:</td><td>
<?php echo $myrow["language"]?>
</td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_description?>:</td>
<td align="left"><?php echo $descriptiontext?></td>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_supportedos?>:</td>
<td valign="top">
<?php
	$sql = "SELECT o.osname, o.osnr FROM ".$tableprefix."_os o, ".$tableprefix."_prog_os po WHERE po.prognr = '$input_prognr' AND o.osnr = po.osnr order by o.osnr";
	if(!$r = faqe_db_query($sql, $db))
	    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
	if ($row = faqe_db_fetch_array($r))
	{
		 do {
		    echo $row["osname"]."<BR>";
		 } while($row = faqe_db_fetch_array($r));
	}
	else
		echo "$l_noos<br>";
?>
</td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_admins?>:</td>
<td>
<?php
	$sql = "SELECT u.username, u.usernr FROM ".$tableprefix."_admins u, ".$tableprefix."_programm_admins f WHERE f.prognr = '$input_prognr' AND u.usernr = f.usernr order by u.username";
	if(!$r = faqe_db_query($sql, $db))
	    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
	if ($row = faqe_db_fetch_array($r))
	{
		 do {
		    echo $row["username"]."<BR>";
		 } while($row = faqe_db_fetch_array($r));
	}
	else
		echo "$l_noadmins<br>";
?>
</td></tr>
<tr bgcolor="#c0c0c0"><td align="left" colspan="2"><b><?php echo $l_news_settings?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_nntpserver?>:</td>
<td><?php echo $myrow["nntpserver"]?></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_domain?>:</td>
<td><?php echo $myrow["newsdomain"]?></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_newsgroup?>:</td>
<td><?php echo $myrow["newsgroup"]?></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_newssubject?>:</td>
<td><?php echo $myrow["newssubject"]?></td></tr>
</table></tr></td></table>
<?php
		echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_proglist</a></div>";
	}
	// Page called with some special mode
	if($mode=="new")
	{
		if($admin_rights < 2)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
		// Display empty form for entering programm
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr><td bgcolor="#94AAD6" align="center" colspan="2"><b><?php echo $l_newprogramm?></b></td></tr>
<form method="post" action="<?php echo $PHP_SELF?>"><input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_progname?>:</td><td><input type="text" name="programmname" size="40" maxlength="80"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_id?>:</td><td><input type="text" name="progid" size="10" maxlength="10"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_language?>:</td><td>
<?php print language_select($default_lang, "proglang", "../language");?>
</td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_description?>:<br>
<?php echo "<a href=\"help/".$act_lang."/bbcode.html\" target=\"_blank\">$l_bbcodehelp</a>"?></td>
<td align="left"><textarea name="description" cols="30" rows="6"></textarea></td>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_supportedos?>:</td>
<td>
<SELECT NAME="os[]" size="5" multiple>
<?php
		$sql = "SELECT osnr, osname FROM ".$tableprefix."_os ORDER BY osnr";
	    if(!$r = faqe_db_query($sql, $db))
			die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
	    if($row = faqe_db_fetch_array($r)) {
			do {
				echo "<OPTION VALUE=\"".$row["osnr"]."\" >".$row["osname"]."</OPTION>\n";
			} while($row = faqe_db_fetch_array($r));
		}
		else {
			echo "<OPTION VALUE=\"0\">$l_none</OPTION>\n";
		}
?>
</select>
</td></tr>
<?php
	if($admin_rights>2)
	{
?>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_admins?>:</td>
<td>
<SELECT NAME="mods[]" size="5" multiple>
<?php
		$sql = "SELECT usernr, username FROM ".$tableprefix."_admins WHERE rights > 1 ORDER BY username";
	    if(!$r = faqe_db_query($sql, $db))
			die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
	    if($row = faqe_db_fetch_array($r)) {
			do {
				echo "<OPTION VALUE=\"$row[usernr]\" >$row[username]</OPTION>\n";
			} while($row = faqe_db_fetch_array($r));
		}
		else {
			echo "<OPTION VALUE=\"0\">$l_none</OPTION>\n";
		}
?>
</select>
</td></tr>
<?php
	}
	else
		echo "<input type=\"hidden\" name=\"mods[]\" value=\"$act_usernr\">";
?>
<tr bgcolor="#c0c0c0"><td align="left" colspan="2"><b><?php echo $l_news_settings?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_nntpserver?>:</td><td><input type="text" name="nntpserver" size="40" maxlength="80"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_domain?>:</td><td><input type="text" name="newsdomain" size="40" maxlength="80"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_newsgroup?>:</td><td><input type="text" name="newsgroup" size="40" maxlength="250"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_newssubject?>:</td><td><input type="text" name="newssubject" size="40" maxlength="80"></td></tr>
<tr bgcolor="#c0c0c0"><td align="right" valign="top"><?php echo $l_options?>:</td><td align="left">
<input type="checkbox" name="local_urlautoencode" value="1" <?php if($urlautoencode==1) echo "checked"?>> <?php echo $l_urlautoencode?><br>
<input type="checkbox" name="local_enablespcode" value="1" <?php if($enablespcode==1) echo "checked"?>> <?php echo $l_enablespcode?>
</td></tr>
<tr bgcolor="#94AAD6"><td align="center" colspan="2"><input type="hidden" name="mode" value="add">
<input type="submit" value="<?php echo $l_add?>">
&nbsp;&nbsp;<input type="submit" name="preview" value="<?php echo $l_preview?>"></td></tr>
</form>
</table></td></tr></table>
<div align="center"><a href="<?php echo do_url_session("$PHP_SELF?$langvar=$act_lang")?>"><?php echo $l_proglist?></a></div>
<?php
	}
	if($mode=="reindex")
	{
		if($admin_rights < 3)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			echo "$l_functionnotallowed</td></tr></table></td></tr></table>";
			echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_proglist</a></div>";
			include('./trailer.php');
			exit;
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$sql = "select * from ".$tableprefix."_programm";
		if(!$result = faqe_db_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
		if($myrow=faqe_db_fetch_array($result))
		{
			do{
				$tempsql="select * from ".$tableprefix."_category where programm=".$myrow["prognr"];
				if(!$tempresult = faqe_db_query($tempsql, $db))
				    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
				$catcount=faqe_db_num_rows($tempresult);
				$updatesql="update ".$tableprefix."_programm set numcats=$catcount where prognr=".$myrow["prognr"];
				if(!$updateresult = faqe_db_query($updatesql, $db))
				    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
			}while($myrow=faqe_db_fetch_array($result));
		}
		echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
		echo "$l_progreindexed";
		echo "</td></tr></table></td></tr></table>";
		echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_proglist</a></div>";
	}
	if($mode=="add")
	{
		if($admin_rights < 2)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		// Add new programm to database
		$errors=0;
		if(!$proglang)
			$proglang="";
		if(!$programmname)
		{
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$l_noprogname</td></tr>";
			$errors=1;
		}
		if(!$progid)
		{
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$l_noid</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			if(!isset($local_urlautoencode))
				$urlautoencode=0;
			else
				$urlautoencode=1;
			if(!isset($local_enablespcode))
				$enablespcode=0;
			else
				$enablespcode=1;
			if(isset($preview))
			{
				$displaydescription="";
				if($description)
				{
					$displaydescription=stripslashes($description);
					if($urlautoencode==1)
						$dispalydescription = make_clickable($displaydescription);
					if($enablespcode==1)
						$displaydescription = bbencode($displaydescription);
					$displaydescription = htmlentities($displaydescription);
					$displaydescription = str_replace("\n", "<BR>", $displaydescription);
					$displaydescription = undo_htmlspecialchars($displaydescription);
				}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr><td bgcolor="#94AAD6" align="center" colspan="2"><b><?php echo $l_newprogramm?></b></td></tr>
<form method="post" action="<?php echo $PHP_SELF?>"><input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<tr><td bgcolor="#c0c0c0" align="center" colspan="2"><?php echo $l_previewprelude?>:</td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_progname?>:</td><td><?php echo $programmname?><input type="hidden" name="programmname" value="<?php echo $programmname?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_id?>:</td><td><?php echo $progid?><input type="hidden" name="progid" value="<?php echo $progid?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_language?>:</td><td><?php echo $proglang?><input type="hidden" name="proglang" value="<?php echo $proglang?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%" valign="top"><?php echo $l_description?>:</td><td><?php echo $displaydescription?><input type="hidden" name="description" value="<?php echo $description?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%" valign="top"><?php echo $l_supportedos?>:</td><td>
<?php
				if(isset($os))
				{
					while(list($null, $os) = each($HTTP_POST_VARS["os"]))
					{
						$os_query = "SELECT * from ".$tableprefix."_os where osnr=$os";
	    			   	if(!$os_result=faqe_db_query($os_query, $db))
						    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database.");
						if($os_row=faqe_db_fetch_array($os_result))
						{
							echo $os_row["osname"];
							echo "<input type=\"hidden\" name=\"os[]\" value=\"$os\"><br>";
						}

					}
				}
?>
</td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%" valign="top"><?php echo $l_admins?>:</td><td>
<?php
				if(isset($mods))
				{
					while(list($null, $mod) = each($HTTP_POST_VARS["mods"]))
					{
						$mod_query = "SELECT * from ".$tableprefix."_admins where usernr=$mod";
	    			   	if(!$mod_result=faqe_db_query($mod_query, $db))
						    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database.");
						if($mod_row=faqe_db_fetch_array($mod_result))
						{
							echo $mod_row["username"];
							echo "<input type=\"hidden\" name=\"mods[]\" value=\"$mod\"><br>";
						}

					}
				}
?>
</td></tr>
<tr bgcolor="#c0c0c0"><td align="left" colspan="2"><b><?php echo $l_news_settings?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_nntpserver?>:</td>
<td><?php echo $nntpserver?><input type="hidden" name="nntpserver" value="<?php echo $nntpserver?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_domain?>:</td>
<td><?php echo $newsdomain?><input type="hidden" name="newsdomain" value="<?php echo $newsdomain?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_newsgroup?>:</td>
<td><?php echo $newsgroup?><input type="hidden" name="newsgroup" value="<?php echo $newsgroup?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_newssubject?>:</td>
<td><?php echo $newssubject?><input type="hidden" name="newssubject" value="<?php echo $newssubject?>"></td></tr>
<?php
if(isset($local_urlautoencode))
	echo "<input type=\"hidden\" name=\"local_urlautoencode\" value=\"1\">";
if(isset($local_enablespcode))
	echo "<input type=\"hidden\" name=\"local_enablespcode\" value=\"1\">";
?>
<tr bgcolor="#94AAD6"><td colspan="2" align="center">
<input type="submit" value="<?php echo $l_enter?>">&nbsp;&nbsp;
<input type="button" value="<?php echo $l_back ?>" onclick="self.history.back();">
<input type="hidden" name="mode" value="add">
</td></tr></form></table></td></tr></table>
<?php
			}
			else
			{
				if($description)
				{
					$description=stripslashes($description);
					if($urlautoencode==1)
						$description = make_clickable($description);
					if($enablespcode==1)
						$description = bbencode($description);
					$description = htmlentities($description);
					$description = str_replace("\n", "<BR>", $description);
					$description=addslashes($description);
				}
				$sql = "select max(displaypos) as newdisplaypos from ".$tableprefix."_programm where language='$proglang'";
				if(!$result = faqe_db_query($sql, $db))
				    die("<tr bgcolor=\"#cccccc\"><td>Unable to add programm to database.");
				if($myrow=faqe_db_fetch_array($result))
					$displaypos=$myrow["newdisplaypos"]+1;
				else
					$displaypos=1;
				$programmname=addslashes($programmname);
				$sql = "INSERT INTO ".$tableprefix."_programm (programmname, numcats, progid, language, newsgroup, newssubject, nntpserver, newsdomain, description, displaypos) ";
				$sql .="VALUES ('$programmname', 0, '$progid', '$proglang', '$newsgroup', '$newssubject', '$nntpserver', '$newsdomain', '$description', $displaypos)";
				if(!$result = faqe_db_query($sql, $db))
				    die("<tr bgcolor=\"#cccccc\"><td>Unable to add programm to database.");
				$prognr = faqe_db_insert_id($db);
				if(isset($mods))
				{
	    			while(list($null, $mod) = each($HTTP_POST_VARS["mods"]))
	    			{
						$mod_query = "INSERT INTO ".$tableprefix."_programm_admins (prognr, usernr) VALUES ('$prognr', '$mod')";
	    			   	if(!faqe_db_query($mod_query, $db))
						    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
					}
				}
				if(isset($os))
				{
					while(list($null, $os) = each($HTTP_POST_VARS["os"]))
					{
						$os_query = "INSERT INTO ".$tableprefix."_prog_os (prognr, osnr) VALUES ('$prognr', '$os')";
	    			   	if(!faqe_db_query($os_query, $db))
						    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
					}
				}
				echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
				echo "$l_progadded";
				echo "</td></tr></table></td></tr></table>";
				echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?mode=new&$langvar=$act_lang")."\">$l_newprogramm</a></div>";
				echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_proglist</a></div>";
			}
		}
		else
		{
			echo "<tr bgcolor=\"#94AAD6\" align=\"center\"><td>";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
	}
	if($mode=="delete")
	{
		if($admin_rights < 2)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		if(isset($cat_action))
		{
			$countsql = "select count(catnr), sum(numfaqs) from ".$tableprefix."_category where (programm=$input_prognr)";
			if(!$result = faqe_db_query($countsql, $db))
			    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database.");
			if ($temprow = faqe_db_fetch_array($result))
			{
				$catcount=$temprow["count(catnr)"];
				$faqcount=$temprow["sum(numfaqs)"];
			}
			else
			{
				$catcount=0;
				$faqcount=0;
			}
			if($cat_action=="del")
			{
				$tempsql = "select * from ".$tableprefix."_category where (programm=$input_prognr)";
				if(!$result = faqe_db_query($tempsql, $db))
				    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database.");
				if ($temprow = faqe_db_fetch_array($result))
				{
					do{
						$act_cat=$temprow["catnr"];
						$deletesql = "delete from ".$tableprefix."_data where (category=$act_cat)";
						$success = faqe_db_query($deletesql,$db);
						if (!$success)
							die("<tr bgcolor=\"#cccccc\"><td>$l_cantdelete $l_faq.");
						$deletesql = "delete from ".$tableprefix."_category_admins where (catnr=$act_cat)";
						$success = faqe_db_query($deletesql,$db);
						if (!$success)
							die("<tr bgcolor=\"#cccccc\"><td>$l_cantdelete.");
					}while($temprow = faqe_db_fetch_array($result));
				}
				$deletesql = "delete from ".$tableprefix."_category where (programm=$input_prognr)";
				$success = faqe_db_query($deletesql,$db);
				if (!$success)
					die("<tr bgcolor=\"#cccccc\"><td>$l_cantdelete $l_category.");
				echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
				echo "<i>$faqcount</i> $l_faq $l_in <i>$catcount</i> $l_categories $l_deleted<br></td></tr>";
			}
			if($cat_action=="move")
			{
				if($new_prog>0)
				{
					$movesql = "update ".$tableprefix."_category set programm=$new_prog where (programm=$input_prognr)";
					$success = faqe_db_query($movesql,$db);
					if (!$success)
						die("<tr bgcolor=\"#cccccc\"><td>$l_cantmove.");
					$sql = "UPDATE ".$tableprefix."_programm SET numcats = numcats + $catcount WHERE (prognr = $new_prog)";
					@faqe_db_query($sql, $db);
					echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
					echo "<i>$faqcount</i> $l_faq $l_in <i>$catcount</i> $l_categories $l_moved<br></td></tr>";
				}
			}
		}
		$countsql = "select count(catnr), sum(numfaqs) from ".$tableprefix."_category where (programm=$input_prognr)";
		if(!$result = faqe_db_query($countsql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database.");
		if ($temprow = faqe_db_fetch_array($result))
		{
			$catcount=$temprow["count(catnr)"];
			if($catcount>0)
				$faqcount=$temprow["sum(numfaqs)"];
		}
		else
		{
			$catcount=0;
			$faqcount=0;
		}
		if($catcount > 0)
		{
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr><td bgcolor="#94AAD6" align="center" colspan="2"><b><?php echo "$l_delprog ($progname)"?></b></td></tr>
<tr><td bgcolor="#c0c0c0" align="center" colspan="2"><?php echo "$l_catinprog ($catcount)"?>
<?php
if ($faqcount>0)
	echo "<br>$l_withfaq ($faqcount)";
?>
</td></tr>
<form action="<?php echo $PHP_SELF?>" method="post"><input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="mode" value="delete"><input type="hidden" name="input_prognr" value="<?php echo $input_prognr?>">
<input type="hidden" name="progname" value="<?php echo $progname?>">
<tr><td bgcolor="#cccccc"><input type="radio" name="cat_action" value="del"><?php echo "$l_delcats"?></td></tr>
<tr><td bgcolor="#cccccc"><input type="radio" name="cat_action" value="move"><?php echo "$l_movecats"?> <?php echo $l_to?>:
<?php
	$sql1 = "select * from ".$tableprefix."_programm where (prognr != $input_prognr)";
	if(!$result1 = faqe_db_query($sql1, $db)) {
		die("Could not connect to the database (3).");
	}
	if (!$temprow = faqe_db_fetch_array($result1))
	{
		echo "$l_noentries";
	}
	else
	{
?>
<select name="new_prog">
<option value="-1">???</option>
<?php
	do {
		$progname=htmlentities($temprow["programmname"]);
		$prognr=$temprow["prognr"];
		$proglang=$temprow["language"];
		echo "<option value=\"".$temprow["prognr"]."\">";
		echo "$progname [$proglang]";
		echo "</option>";
	} while($temprow = faqe_db_fetch_array($result1));
?>
</select>
<?php
	}
?>
</td></tr>
<tr bgcolor="#94aad6"><td align="center" colspan="2">
<input type="submit" value="<?php echo $l_ok?>"></td></tr>
</form>
</table></tr></td></table>
<div align="center"><a href="<?php echo do_url_session("$PHP_SELF?$langvar=$act_lang")?>"><?php echo $l_proglist?></a></div>
<?php
		}
		else
		{
			$deleteSQL = "delete from ".$tableprefix."_programm where (prognr=$input_prognr)";
			$success = faqe_db_query($deleteSQL,$db);
			if (!$success)
				die("<tr bgcolor=\"#cccccc\"><td>$l_cantdelete.");
			$deleteSQL = "delete from ".$tableprefix."_programm_admins where (prognr=$input_prognr)";
			$success = faqe_db_query($deleteSQL,$db);
			if (!$success)
				die("<tr bgcolor=\"#cccccc\"><td>$l_cantdelete.");
			$deleteSQL = "delete from ".$tableprefix."_prog_os where (prognr=$input_prognr)";
			$success = faqe_db_query($deleteSQL,$db);
			if (!$success)
				die("<tr bgcolor=\"#cccccc\"><td>$l_cantdelete.");
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "<i>$progname</i> $l_deleted<br>";
			echo "</td></tr></table></td></tr></table>";
			echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_proglist</a></div>";
		}
	}
	if($mode=="edit")
	{
		$modsql="select * from ".$tableprefix."_programm_admins where prognr=$input_prognr and usernr=$act_usernr";
		if(!$modresult = faqe_db_query($modsql, $db)) {
		    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
		}
		if($modrow=faqe_db_fetch_array($modresult))
			$ismod=1;
		else
			$ismod=0;
		if(($admin_rights < 2) || (($admin_rights < 3) && ($ismod==0)))
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			echo "$l_functionnotallowed</td></tr></table></td></tr></table>";
			echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_proglist</a></div>";
			include('./trailer.php');
			exit;
		}
		$sql = "select * from ".$tableprefix."_programm where (prognr=$input_prognr)";
		if(!$result = faqe_db_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
		if (!$myrow = faqe_db_fetch_array($result))
			die("<tr bgcolor=\"#cccccc\"><td>no such entry");
		$descriptiontext=stripslashes($myrow["description"]);
		$descriptiontext = str_replace("<BR>", "\n", $descriptiontext);
		$descriptiontext = undo_htmlspecialchars($descriptiontext);
		$descriptiontext = bbdecode($descriptiontext);
		$descriptiontext = undo_make_clickable($descriptiontext);
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr><td bgcolor="#94AAD6" align="center" colspan="2"><b><?php echo $l_editprogs?></b></td></tr>
<form method="post" action="<?php echo $PHP_SELF?>"><input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="input_prognr" value="<?php echo $myrow["prognr"]?>">
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_progname?>:</td><td><input type="text" name="programmname" size="40" maxlength="80" value="<?php echo htmlentities(stripslashes($myrow["programmname"]))?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_id?>:</td><td><input type="text" name="progid" size="10" maxlength="10" value="<?php echo $myrow["progid"]?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_language?>:</td><td>
<?php print language_select($myrow["language"], "proglang", "../language");?>
</td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_description?>:<br>
<?php echo "<a href=\"help/".$act_lang."/bbcode.html\" target=\"_blank\">$l_bbcodehelp</a>"?></td>
<td align="left"><textarea name="description" cols="30" rows="6"><?php echo $descriptiontext?></textarea></td>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_supportedos?>:</td>
<td>
<?php
	$sql = "SELECT o.osname, o.osnr FROM ".$tableprefix."_os o, ".$tableprefix."_prog_os po WHERE po.prognr = '$input_prognr' AND o.osnr = po.osnr order by o.osnr";
	if(!$r = faqe_db_query($sql, $db))
	    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
	if ($row = faqe_db_fetch_array($r))
	{
		 do {
		    echo $row["osname"]." (<input type=\"checkbox\" name=\"rem_os[]\" value=\"".$row["osnr"]."\"> $l_remove)<BR>";
		    $current_os[] = $row["osnr"];
		 } while($row = faqe_db_fetch_array($r));
		 echo "<br>";
	}
	else
		echo "$l_noos<br><br>";
?>
<?php
	$sql = "SELECT osnr, osname FROM ".$tableprefix."_os ";
	$first=1;
	if(isset($current_os))
	{
    	while(list($null, $curros) = each($current_os)) {
    		if($first==1)
    		{
				$sql .= "WHERE osnr != $curros ";
				$first=0;
			}
			else
				$sql .= "AND osnr != $curros ";
    	}
    }
    $sql .= "ORDER BY osnr";
    if(!$r = faqe_db_query($sql, $db))
		die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
    if($row = faqe_db_fetch_array($r)) {
		echo "<b>$l_add:</b><br>";
		echo "<SELECT NAME=\"os[]\" size=\"5\" multiple>";
		do {
			echo "<OPTION VALUE=\"$row[osnr]\" >$row[osname]</OPTION>\n";
		} while($row = faqe_db_fetch_array($r));
		echo"</select>";
	}
?>
</td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_admins?>:</td>
<td>
<?php
	$sql = "SELECT u.username, u.usernr FROM ".$tableprefix."_admins u, ".$tableprefix."_programm_admins f WHERE f.prognr = '$input_prognr' AND u.usernr = f.usernr order by u.username";
	if(!$r = faqe_db_query($sql, $db))
	    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
	if ($row = faqe_db_fetch_array($r))
	{
		 do {
		    echo $row["username"]." (<input type=\"checkbox\" name=\"rem_mods[]\" value=\"".$row["usernr"]."\"> $l_remove)<BR>";
		    $current_mods[] = $row["usernr"];
		 } while($row = faqe_db_fetch_array($r));
		 echo "<br>";
	}
	else
		echo "$l_noadmins<br><br>";
	$sql = "SELECT usernr, username FROM ".$tableprefix."_admins WHERE rights > 1 ";
	if(isset($current_mods))
	{
    	while(list($null, $currMod) = each($current_mods)) {
			$sql .= "AND usernr != $currMod ";
    	}
    }
    $sql .= "ORDER BY username";
    if(!$r = faqe_db_query($sql, $db))
		die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
    if($row = faqe_db_fetch_array($r)) {
		echo"<b>$l_add:</b><br>";
		echo"<SELECT NAME=\"mods[]\" size=\"5\" multiple>";
		do {
			echo "<OPTION VALUE=\"$row[usernr]\" >$row[username]</OPTION>\n";
		} while($row = faqe_db_fetch_array($r));
		echo"</select>";
	}
?>
</td></tr>
<tr bgcolor="#c0c0c0"><td align="left" colspan="2"><b><?php echo $l_news_settings?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_nntpserver?>:</td><td><input type="text" name="nntpserver" size="40" maxlength="80" value="<?php echo $myrow["nntpserver"]?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_domain?>:</td><td><input type="text" name="newsdomain" size="40" maxlength="80" value="<?php echo $myrow["newsdomain"]?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_newsgroup?>:</td><td><input type="text" name="newsgroup" size="40" maxlength="250" value="<?php echo $myrow["newsgroup"]?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_newssubject?>:</td><td><input type="text" name="newssubject" size="40" maxlength="80" value="<?php echo $myrow["newssubject"]?>"></td></tr>
<tr bgcolor="#c0c0c0"><td align="right" valign="top"><?php echo $l_options?>:</td><td align="left">
<input type="checkbox" name="local_urlautoencode" value="1" <?php if($urlautoencode==1) echo "checked"?>> <?php echo $l_urlautoencode?><br>
<input type="checkbox" name="local_enablespcode" value="1" <?php if($enablespcode==1) echo "checked"?>> <?php echo $l_enablespcode?>
</td></tr>
<tr bgcolor="#94aad6"><td align="center" colspan="2"><input type="hidden" name="mode" value="update">
<input type="submit" value="<?php echo $l_update?>">
&nbsp;&nbsp;<input type="submit" name="preview" value="<?php echo $l_preview?>"></td></tr>
</form>
</table></tr></td></table>
<div align="center"><a href="<?php echo do_url_session("$PHP_SELF?$langvar=$act_lang")?>"><?php echo $l_proglist?></a></div>
<?php
	}
	if($mode=="update")
	{
		$modsql="select * from ".$tableprefix."_programm_admins where prognr=$input_prognr and usernr=$act_usernr";
		if(!$modresult = faqe_db_query($modsql, $db)) {
		    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
		}
		if($modrow=faqe_db_fetch_array($modresult))
			$ismod=1;
		else
			$ismod=0;
		if(($admin_rights < 2) || (($admin_rights < 3) && ($ismod==0)))
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			echo "$l_functionnotallowed</td></tr></table></td></tr></table>";
			echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_proglist</a></div>";
			include('./trailer.php');
			exit;
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$errors=0;
		if(!$programmname)
		{
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$l_noprogname</td></tr>";
			$errors=1;
		}
		if(!$progid)
		{
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$l_noid</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			if(!isset($local_urlautoencode))
				$urlautoencode=0;
			else
				$urlautoencode=1;
			if(!isset($local_enablespcode))
				$enablespcode=0;
			else
				$enablespcode=1;
			if(isset($preview))
			{
				$displaydescription="";
				if($description)
				{
					$displaydescription=stripslashes($description);
					if($urlautoencode==1)
						$dispalydescription = make_clickable($displaydescription);
					if($enablespcode==1)
						$displaydescription = bbencode($displaydescription);
					$displaydescription = htmlentities($displaydescription);
					$displaydescription = str_replace("\n", "<BR>", $displaydescription);
					$displaydescription = undo_htmlspecialchars($displaydescription);
				}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr><td bgcolor="#94AAD6" align="center" colspan="2"><b><?php echo $l_newprogramm?></b></td></tr>
<form method="post" action="<?php echo $PHP_SELF?>"><input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<tr><td bgcolor="#c0c0c0" align="center" colspan="2"><?php echo $l_previewprelude?>:</td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_progname?>:</td><td><?php echo $programmname?><input type="hidden" name="programmname" value="<?php echo $programmname?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_id?>:</td><td><?php echo $progid?><input type="hidden" name="progid" value="<?php echo $progid?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_language?>:</td><td><?php echo $proglang?><input type="hidden" name="proglang" value="<?php echo $proglang?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%" valign="top"><?php echo $l_description?>:</td><td><?php echo $displaydescription?><input type="hidden" name="description" value="<?php echo $description?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%" valign="top"><?php echo $l_supportedos?>:</td><td>
<?php
				$os_query="select os.* from ".$tableprefix."_os os, ".$tableprefix."_prog_os po where po.prognr=$input_prognr and os.osnr=po.osnr";
				if(isset($rem_os))
				{
					while(list($null, $os) = each($HTTP_POST_VARS["rem_os"]))
					{
						echo "<input type=\"hidden\" name=\"rem_os[]\" value=\"$os\">";
						$os_query.=" and os.osnr!=$os";
					}
				}
   			   	if(!$os_result=faqe_db_query($os_query, $db))
				    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database.");
				if($os_row=faqe_db_fetch_array($os_result))
				{
					do{
						echo $os_row["osname"];
						echo "<br>";
					}while($os_row=faqe_db_fetch_array($os_result));
				}
				if(isset($os))
				{
					while(list($null, $os) = each($HTTP_POST_VARS["os"]))
					{
						$os_query = "SELECT * from ".$tableprefix."_os where osnr=$os";
	    			   	if(!$os_result=faqe_db_query($os_query, $db))
						    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database.");
						if($os_row=faqe_db_fetch_array($os_result))
						{
							echo $os_row["osname"];
							echo "<input type=\"hidden\" name=\"os[]\" value=\"$os\"><br>";
						}

					}
				}
?>
</td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%" valign="top"><?php echo $l_admins?>:</td><td>
<?php
				$mod_query="select mod.* from ".$tableprefix."_admins mod, ".$tableprefix."_programm_admins pa where pa.prognr=$input_prognr and mod.usernr=pa.usernr";
				if(isset($rem_mods))
				{
					while(list($null, $mod) = each($HTTP_POST_VARS["rem_mods"]))
					{
						echo "<input type=\"hidden\" name=\"rem_mods[]\" value=\"$mod\">";
						$mod_query.=" and mod.usernr!=$mod";
					}
				}
   			   	if(!$mod_result=faqe_db_query($mod_query, $db))
				    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database.");
				if($mod_row=faqe_db_fetch_array($mod_result))
				{
					do{
						echo $mod_row["username"];
						echo "<br>";
					}while($mod_row=faqe_db_fetch_array($mod_result));
				}
				if(isset($mods))
				{
					while(list($null, $mod) = each($HTTP_POST_VARS["mods"]))
					{
						$mod_query = "SELECT * from ".$tableprefix."_admins where usernr=$mod";
	    			   	if(!$mod_result=faqe_db_query($mod_query, $db))
						    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database.");
						if($mod_row=faqe_db_fetch_array($mod_result))
						{
							echo $mod_row["username"];
							echo "<input type=\"hidden\" name=\"mods[]\" value=\"$mod\"><br>";
						}

					}
				}
?>
</td></tr>
<tr bgcolor="#c0c0c0"><td align="left" colspan="2"><b><?php echo $l_news_settings?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_nntpserver?>:</td>
<td><?php echo $nntpserver?><input type="hidden" name="nntpserver" value="<?php echo $nntpserver?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_domain?>:</td>
<td><?php echo $newsdomain?><input type="hidden" name="newsdomain" value="<?php echo $newsdomain?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_newsgroup?>:</td>
<td><?php echo $newsgroup?><input type="hidden" name="newsgroup" value="<?php echo $newsgroup?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_newssubject?>:</td>
<td><?php echo $newssubject?><input type="hidden" name="newssubject" value="<?php echo $newssubject?>"></td></tr>
<?php
if(isset($local_urlautoencode))
	echo "<input type=\"hidden\" name=\"local_urlautoencode\" value=\"1\">";
if(isset($local_enablespcode))
	echo "<input type=\"hidden\" name=\"local_enablespcode\" value=\"1\">";
?>
<tr bgcolor="#94AAD6"><td colspan="2" align="center">
<input type="hidden" name="input_prognr" value="<?php echo $input_prognr?>">
<input type="submit" value="<?php echo $l_update?>">&nbsp;&nbsp;
<input type="button" value="<?php echo $l_back ?>" onclick="self.history.back();">
<input type="hidden" name="mode" value="update">
</td></tr></form></table></td></tr></table>
<?php
			}
			else
			{
				if($description)
				{
					$description=stripslashes($description);
					if($urlautoencode==1)
						$description = make_clickable($description);
					if($enablespcode==1)
						$description = bbencode($description);
					$description = htmlentities($description);
					$description = str_replace("\n", "<BR>", $description);
					$description=addslashes($description);
				}
				$programmname=addslashes($programmname);
				$sql = "UPDATE ".$tableprefix."_programm SET programmname='$programmname', progid='$progid', language='$proglang', newsgroup='$newsgroup', newssubject='$newssubject', nntpserver='$nntpserver', newsdomain='$newsdomain', description='$description' ";
				$sql .=" WHERE (prognr = $input_prognr)";
				if(!$result = faqe_db_query($sql, $db))
				    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
				if(isset($mods))
				{
		    		while(list($null, $mod) = each($HTTP_POST_VARS["mods"]))
		    		{
						$mod_query = "INSERT INTO ".$tableprefix."_programm_admins (prognr, usernr) VALUES ('$input_prognr', '$mod')";
		    		   	if(!faqe_db_query($mod_query, $db))
						    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
					}
				}
				if(isset($rem_mods))
				{
					while(list($null, $mod) = each($HTTP_POST_VARS["rem_mods"]))
					{
						$rem_query = "DELETE FROM ".$tableprefix."_programm_admins WHERE prognr = '$input_prognr' AND usernr = '$mod'";
		       			if(!faqe_db_query($rem_query,$db))
						    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
					}
				}
				if(isset($os))
				{
					while(list($null, $os) = each ($HTTP_POST_VARS["os"]))
					{
						$os_query = "INSERT INTO ".$tableprefix."_prog_os (osnr, prognr) VALUES ('$os', '$input_prognr')";
		    		   	if(!faqe_db_query($os_query, $db))
						    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
					}
				}
				if(isset($rem_os))
				{
					while(list($null, $os) = each($HTTP_POST_VARS["rem_os"]))
					{
						$rem_query = "DELETE FROM ".$tableprefix."_prog_os WHERE prognr = '$input_prognr' AND osnr='$os'";
		       			if(!faqe_db_query($rem_query,$db))
						    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
					}
				}
				echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
				echo "$l_progupdated";
				echo "</td></tr></table></td></tr></table>";
				echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_proglist</a></div>";
			}
		}
		else
		{
			echo "<tr bgcolor=\"#94AAD6\" align=\"center\"><td>";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
	}
}
else
{
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
	if($admin_rights>1)
	{
?>
<tr bgcolor="#94AAD6"><td colspan="6" align="center">
<a href="<?php echo do_url_session("$PHP_SELF?mode=new&$langvar=$act_lang")?>"><?php echo $l_newprogramm?></a>
</table></td></tr></table>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?
	}
// Display list of actual categories
$sql = "select * from ".$tableprefix."_programm order by prognr";
if(!$result = faqe_db_query($sql, $db)) {
    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
}
if (!$myrow = faqe_db_fetch_array($result))
{
	echo "<tr bgcolor=\"#c0c0c0\"><td align=\"center\">";
	echo $l_noentries;
	echo "</td></tr></table></td></tr></table>";
}
else
{
	echo "<tr bgcolor=\"#c0c0c0\">";
	echo "<td align=\"center\" width=\"10%\"><b>#</b></td>";
	echo "<td align=\"center\" width=\"10%\"><b>$l_id</b></td>";
	echo "<td align=\"center\" width=\"50%\"><b>$l_progname</b></td>";
	echo "<td align=\"center\" width=\"20%\"><b>$l_language</b></td>";
	echo "<td align=\"center\"><b>$l_categories</b></td>";
	echo "<td>&nbsp;</td></tr>";
	do {
		$act_id=$myrow["prognr"];
		echo "<tr bgcolor=\"#cccccc\">";
		echo "<td align=\"center\">".$myrow["prognr"]."</td>";
		echo "<td align=\"center\">".$myrow["progid"]."</td>";
		echo "<td>".htmlentities($myrow["programmname"])."</td>";
		echo "<td align=\"center\">".$myrow["language"]."</td>";
		echo "<td align=\"right\">".$myrow["numcats"]."</td>";
		echo "<td>";
		$modsql="select * from ".$tableprefix."_programm_admins where prognr=$act_id and usernr=$act_usernr";
		if(!$modresult = faqe_db_query($modsql, $db)) {
		    die("Could not connect to the database.");
		}
		if($modrow=faqe_db_fetch_array($modresult))
			$ismod=1;
		else
			$ismod=0;
		if(($admin_rights>2) || ($ismod==1))
		{
			echo "<a href=\"".do_url_session("$PHP_SELF?mode=delete&input_prognr=$act_id&$langvar=$act_lang&progname=".urlencode($myrow["programmname"]))."\">";
			echo "$l_delete</a>";
			echo "&nbsp;&nbsp;";
			echo "<a href=\"".do_url_session("$PHP_SELF?mode=edit&$langvar=$act_lang&input_prognr=$act_id")."\">";
			echo "$l_edit</a>";
			if((strlen($myrow["newsgroup"])>0) && (strlen($myrow["nntpserver"])>0) && (strlen($myrow["newsdomain"])>0))
			{
				echo "&nbsp; ";
				echo "<a href=\"".do_url_session("newspost.php?$langvar=$act_lang&input_prognr=$act_id")."\">";
				echo "$l_newspost</a>";
			}
			echo "&nbsp; ";
			echo "<a href=\"".do_url_session("programversion.php?input_prognr=$act_id&$langvar=$act_lang")."\">";
			echo "$l_versions</a>&nbsp; ";
			echo "&nbsp; ";
			echo "<a href=\"".do_url_session("reorder_cat.php?input_prognr=$act_id&$langvar=$act_lang")."\">";
			echo "$l_reorder_cat</a>&nbsp; ";
			echo "&nbsp; ";
		}
		echo "<a href=\"".do_url_session("$PHP_SELF?mode=display&input_prognr=$act_id&$langvar=$act_lang&progname=".urlencode($myrow["programmname"]))."\">";
		echo "$l_display</a>";
		echo "</td></tr>";
	} while($myrow = faqe_db_fetch_array($result));
	if($admin_rights>2)
	{
		echo "<tr bgcolor=\"#c0c0c0\"><td colspan=\"6\" align=\"center\">";
		echo "<a href=\"".do_url_session("$PHP_SELF?mode=reindex&$langvar=$act_lang")."\">";
		echo "$l_reindex_prog</a></td></tr>";
	}
	echo "</table></tr></td></table>";
}
if($admin_rights > 1)
{
?>
<div align="center"><a href="<?php echo do_url_session("$PHP_SELF?mode=new&$langvar=$act_lang")?>"><?php echo $l_newprogramm?></a></div>
<?php
}
}
include('./trailer.php');
?>