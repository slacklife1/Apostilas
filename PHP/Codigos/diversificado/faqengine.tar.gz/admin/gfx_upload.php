<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
require_once('../functions.php');
require_once('./auth.php');
require_once('./functions.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include_once('./language/lang_'.$act_lang.'.php');
$user_loggedin=0;
$userdata=Array();
if($enable_htaccess)
{
	if(isbanned($REMOTE_ADDR,$db))
	{
?>
<html>
<head>
<meta name="generator" content="FAQEngine v<?php echo $version?>, <?php echo $copyright_asc?>">
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<title>FAQEngine - Administration</title>
</head>
<body>
<table width="80%" align="CENTER" calign="MIDDLE" border="0" cellspacing="0" cellpadding="0">
<tr><td align="CENTER" bgcolor="#94AAD6"><font size="+2"><img src="gfx/logo.gif" border="0" align="absmiddle"> <b>FAQEngine v<?php echo $version?></b></font></td></tr>
</table>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr bgcolor="#c0c0c0"><td colspan="2" align="center"><b><?php echo $l_ipbanned?></b></td></tr>
<tr bgcolor="#c0c0c0"><td align="right" width="20%"><?php echo $l_reason?>:</td>
<td align="left" width="80%"><?php echo $banreason?></td></tr>
</table></td></tr></table></body></html>
<?php
		exit;
	}
	$username=$REMOTE_USER;
	$myusername=addslashes(strtolower($username));
	$sql = "select * from ".$tableprefix."_admins where username='$myusername'";
	if(!$result = faqe_db_query($sql, $db))
	    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database");
	if (!$myrow = faqe_db_fetch_array($result))
	{
	    die("<tr bgcolor=\"#cccccc\"><td>User not defined for FAQEngine");
	}
	$userid=$myrow["usernr"];
	$user_loggedin=1;
    $userdata = get_userdata_by_id($userid, $db);
}
else if($sessid_url)
{
	if(isset($$sesscookiename))
	{
		$url_sessid=$$sesscookiename;
		$userid = get_userid_from_session($url_sessid, $sesscookietime, get_userip(), $db);
		if ($userid) {
		   $user_loggedin = 1;
		   update_session($url_sessid, $db);
		   $userdata = get_userdata_by_id($userid, $db);
		   $userdata["lastlogin"]=get_lastlogin_from_session($url_sessid, $sesscookietime, get_userip(), $db);
		}
	}
} else if(isset($HTTP_COOKIE_VARS[$sesscookiename])) {
	$sessid = $HTTP_COOKIE_VARS[$sesscookiename];
	$userid = get_userid_from_session($sessid, $sesscookietime, $REMOTE_ADDR, $db);
	if ($userid) {
	   $user_loggedin = 1;
	   update_session($sessid, $db);
	   $userdata = get_userdata_by_id($userid, $db);
	}
}
if($user_loggedin==0)
	die($l_loginfirst);
if($userdata["rights"]<3)
	die($l_functionnotallowed);
if(isset($ACTION))
{
	if ( $ACTION == "UPLOAD" ) {
		if ($USERFILE_name) {
			move_uploaded_file($USERFILE,$path_gfx."/".$USERFILE_name);
		}
	} else if ( $ACTION == "DEL" ) {
		unlink($path_gfx."/".$DELFILE);
}
}
?>
<html>
<head>
<title><?php echo $l_inlinegfx?></title>
<script language='javascript'>
function choosepic(filestr)
{
	var mywin=window.opener;
	var strSelection = mywin.document.selection.createRange().text;
	var newvalue="[img]http://<?php echo $HTTP_HOST.$url_gfx?>/" + filestr + "[/img]";
	if (strSelection == "")
		mywin.document.inputform.<?php echo $usedfield?>.focus();
	mywin.document.selection.createRange().text = newvalue;
	window.close()
}
</SCRIPT>
</head><body bgcolor="#FFFFFF"><center>
<table width="100%" align="CENTER" calign="MIDDLE" border="0" cellspacing="0" cellpadding="0">
<tr bgcolor="#94AAD6"><td align="CENTER"><b><?php echo $l_inlinegfx?></b></td>
<td align="center" valign="middle" width="2%"><a class="pFo" href="javascript:parent.window.focus();top.window.close()"><img src="../gfx/close.gif" border="0" alt="<?php echo $l_close?>"></a></font></td></tr>
</table>
<?php
echo "<FORM name=\"gfxform\" enctype=\"multipart/form-data\" action=\"$PHP_SELF\" method=\"post\">";
if($sessid_url)
	echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
echo "<input type=\"hidden\" name=\"usedfield\" value=\"$usedfield\">";
echo "<input type=\"hidden\" name=\"$langvar\" value=\"$act_lang\">";
echo "<input type=\"hidden\" name=\"MAX_FILE_SIZE\" value=\"9999999\">";
echo "<input type=\"hidden\" name=\"ACTION\" value=\"UPLOAD\">";
echo "<input name=\"USERFILE\" type=\"File\" size=\"20\">";
echo "<input type=\"submit\" value=\"$l_upload\">";
echo "</FORM><br>";

/* ********************************************************** */
$cdir = dir($path_gfx);
echo "<table border=\"0\" width=\"95%\" align=\"center\" cellspacing=\"0\" cellpadding=\"4\">";

$old_cwd = getcwd();
$piccount=0;
if( !chdir($path_gfx) )
	die($l_wronggfxdir);
while ($entry=$cdir->read())
{
	if ((strlen($entry)>2) && (filetype($entry)=="file"))
	{
		if(!($piccount % 2))
			$row_color = "#cccccc";
		else
			$row_color = "#c0c0c0";
        $piccount++;
        echo "<tr bgcolor=\"$row_color\">";
		echo "<td align=\"center\"><img src=\"$url_gfx/$entry\" border=\"0\"></a></td>";
		echo "<td>$entry</a></td>";
		echo "<td align=\"right\">".filesize($entry)." bytes</a></td>";
		echo "<td align=\"right\"><a href=\"javascript:choosepic('$entry')\">$l_choose</a></td>";
		echo "<td align=\"right\"><a href=\"".do_url_session("$PHP_SELF?ACTION=DEL&DELFILE=$entry")."\">$l_delete</a>";
		echo "</tr>";
	}
}
echo "</table>";
chdir($old_cwd);
if($piccount==0)
	echo "<center>$l_nogfxindir</center>";
echo "</center><br><br>";
?>