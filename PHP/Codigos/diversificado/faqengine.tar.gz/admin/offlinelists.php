<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
@set_time_limit(600);
require('../config.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include('./language/lang_'.$act_lang.'.php');
require('./auth.php');
$crlf="\r\n";
$url_sessid=0;
$user_loggedin=0;
$userdata=Array();
if($enable_htaccess)
{
	if(isbanned($REMOTE_ADDR,$db))
	{
?>
<html>
<head>
<meta name="generator" content="FAQEngine v<?php echo $version?>, <?php echo $copyright_asc?>">
<title>FAQEngine - Administration</title>
</head>
<body>
<table width="80%" align="CENTER" calign="MIDDLE" border="0" cellspacing="0" cellpadding="0">
<tr><td align="CENTER" bgcolor="#94AAD6"><font size="+2"><img src="gfx/logo.gif" border="0" align="absmiddle"> <b>FAQEngine v<?php echo $version?></b></font></td></tr>
<tr><td align="CENTER" bgcolor="#c0c0c0"><font size="+2"><?php echo $page_title?></font></td></tr>
</table>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr bgcolor="#c0c0c0"><td colspan="2" align="center"><b><?php echo $l_ipbanned?></b></td></tr>
<tr bgcolor="#c0c0c0"><td align="right" width="20%"><?php echo $l_reason?>:</td>
<td align="left" width="80%"><?php echo $banreason?></td></tr>
</table></td></tr></table></body></html>
<?php
	}
	$username=$REMOTE_USER;
	$myusername=addslashes(strtolower($username));
	$sql = "select * from ".$tableprefix."_admins where username='$myusername'";
	if(!$result = faqe_db_query($sql, $db))
	    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database");
	if (!$myrow = faqe_db_fetch_array($result))
	{
	    die("<tr bgcolor=\"#cccccc\"><td>User not defined for FAQEngine");
	}
	$userid=$myrow["usernr"];
	$user_loggedin=1;
    $userdata = get_userdata_by_id($userid, $db);
}
else if($sessid_url)
{
	if(isset($$sesscookiename))
	{
		$url_sessid=$$sesscookiename;
		$userid = get_userid_from_session($url_sessid, $sesscookietime, $REMOTE_ADDR, $db);
		if ($userid) {
		   $user_loggedin = 1;
		   update_session($url_sessid, $db);
		   $userdata = get_userdata_by_id($userid, $db);
		   $userdata["lastlogin"]=get_lastlogin_from_session($url_sessid, $sesscookietime, $REMOTE_ADDR, $db);
		}
	}
}
else
{
	if(isset($HTTP_COOKIE_VARS[$sesscookiename])) {
		$sessid = $HTTP_COOKIE_VARS[$sesscookiename];
		$userid = get_userid_from_session($sessid, $sesscookietime, $REMOTE_ADDR, $db);
		if ($userid) {
		   $user_loggedin = 1;
		   update_session($sessid, $db);
		   $userdata = get_userdata_by_id($userid, $db);
		}
	}
}
if($user_loggedin==0)
{
	echo "<div align=\"center\">$l_notloggedin2</div>";
	echo "<div align=\"center\">";
	echo "<a href=\"login.php?$langvar=$act_lang\">$l_loginpage</a>";
	die ("</div>");
}
else
{
	$admin_rights=$userdata["rights"];
}
if($admin_rights<2)
{
	die($l_functionotallowed);
}
$dump_buffer="";
$sql = "select cat.*, prog.programmname, prog.language from ".$tableprefix."_category cat, ".$tableprefix."_programm prog where prog.prognr=cat.programm order by cat.catnr asc";
if(!$result = faqe_db_query($sql, $db))
	die("Could not connect to the database.");
if($myrow=faqe_db_fetch_array($result))
{
	$dump_buffer.="{cats}".$crlf;
	do{
		$dump_buffer.=$myrow["catnr"].$crlf;
		$dump_buffer.=$myrow["categoryname"]." (".$myrow["programmname"]." [".$myrow["language"]."])".$crlf;
	}while($myrow=faqe_db_fetch_array($result));
	$dump_buffer.="{/cats}".$crlf;
}
$sql = "select subcat.*, cat.categoryname as maincat, cat.catnr as maincatnr, prog.programmname, prog.language from ".$tableprefix."_subcategory subcat, ".$tableprefix."_category cat, ".$tableprefix."_programm prog where prog.prognr=cat.programm and cat.catnr=subcat.category order by subcat.catnr asc";
if(!$result = faqe_db_query($sql, $db))
	die("Could not connect to the database.");
if($myrow=faqe_db_fetch_array($result))
{
	$dump_buffer.="{subcats}".$crlf;
	do{
		$dump_buffer.=$myrow["catnr"].$crlf;
		$dump_buffer.=$myrow["maincatnr"].$crlf;
		$dump_buffer.=$myrow["categoryname"]." (".$myrow["maincat"]." [".$myrow["programmname"].", ".$myrow["language"]."])".$crlf;
	}while($myrow=faqe_db_fetch_array($result));
	$dump_buffer.="{/subcats}".$crlf;
}
header("Pragma: no-cache");
header("Expires: 0");
header("Content-Type: application/octetstream\n");
header("Content-Disposition: filename=\"offline.lst\"\n");
header("Content-Transfer-Encoding: binary\n");
header("Content-length: ".strlen($dump_buffer)."\n");
print($dump_buffer);
?>
