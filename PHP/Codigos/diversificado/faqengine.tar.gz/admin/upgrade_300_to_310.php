<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
?>
<html><body>
<div align="center"><h3>FAQEngine: Upgrade v3.0x to v3.10</h3></div>
<br>
<?php
if(isset($submit))
{
echo "Upgrading tables...<br>";
$sql = "ALTER TABLE ".$tableprefix."_layout ADD ";
$sql .="newfaqdisplaymethod tinyint(1) unsigned NOT NULL DEFAULT '0';";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_layout (1)");
$sql = "ALTER TABLE ".$tableprefix."_layout ADD ";
$sql .="enablefaqnewdisplay tinyint(1) unsigned NOT NULL DEFAULT '0';";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_layout (2)");
$sql = "ALTER TABLE ".$tableprefix."_layout ADD ";
$sql .="faqnewdisplaybgcolor varchar(8) NOT NULL DEFAULT '';";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_layout (3)");
$sql = "ALTER TABLE ".$tableprefix."_layout ADD ";
$sql .="faqnewdisplayfontcolor varchar(8) NOT NULL DEFAULT '';";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_layout (4)");
$sql = "ALTER TABLE ".$tableprefix."_layout ADD ";
$sql .="listallfaqmethod tinyint(1) unsigned NOT NULL DEFAULT '0';";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_layout (6)");
$sql = "ALTER TABLE ".$tableprefix."_layout ADD ";
$sql .="enableshortcutbar tinyint(1) unsigned NOT NULL DEFAULT '0';";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_layout (7)");
if(isset($importfreemailer))
{
	require('fill_freemailer.php');
	echo "Importing predefined freemailer...<br>";
	fill_freemailer($tableprefix,$db);
}
?>
<br><div align="center">Upgrade done.<br>Please remove install.php, upgrade*.php and fill_freemailer.php from server</div>
<div align="center">Now you can login to the <a href="index.php">admininterface</a></div>
<?php
}
else
{
?>
<table align="center" width="80%">
<form action="<?php echo $PHP_SELF?>" method="post">
<tr><td align="center">
<input type="checkbox" name="importfreemailer" value="1"> import predefined freemailer</td></TR>
<tr><td align="center"><input type="submit" name="submit" value="submit"></td></tr>
</form></table>
<?php
}
?>
</body></html>
