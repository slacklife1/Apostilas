<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
require('./auth.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include('./language/lang_'.$act_lang.'.php');
$page_title=$l_reorder_subcat;
require('./heading.php');
$sql = "select * from ".$tableprefix."_layout where (layoutnr=1)";
if(!$result = faqe_db_query($sql, $db)) {
    die("Could not connect to the database.");
}
if($admin_rights < 2)
{
	echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
	die("$l_functionnotallowed");
}
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<?php
if(isset($mode))
{
	// Page called with some special mode
	if($mode=="move")
	{
		if($admin_rights < 2)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
		if($direction=="up")
		{
			$sql="select displaypos from ".$tableprefix."_subcategory where catnr=$input_subcatnr";
			if(!$result = faqe_db_query($sql, $db))
			    die("<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".faqe_db_error());
			if(!$myrow=faqe_db_fetch_array($result))
			    die("<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"2\">Calling error.");
			$newpos=$myrow["displaypos"]-1;
			$sql="update ".$tableprefix."_subcategory set displaypos=displaypos+1 where displaypos=$newpos and category=$input_catnr";
			if(!$result = faqe_db_query($sql, $db))
			    die("<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".faqe_db_error());
			$sql="update ".$tableprefix."_subcategory set displaypos=$newpos where catnr=$input_subcatnr";
			if(!$result = faqe_db_query($sql, $db))
			    die("<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".faqe_db_error());
		}
		if($direction=="down")
		{
			$sql="select displaypos from ".$tableprefix."_subcategory where catnr=$input_subcatnr";
			if(!$result = faqe_db_query($sql, $db))
			    die("<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".faqe_db_error());
			if(!$myrow=faqe_db_fetch_array($result))
			    die("<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"2\">Calling error.");
			$newpos=$myrow["displaypos"]+1;
			$sql="update ".$tableprefix."_subcategory set displaypos=displaypos-1 where displaypos=$newpos and category=$input_catnr";
			if(!$result = faqe_db_query($sql, $db))
			    die("<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".faqe_db_error());
			$sql="update ".$tableprefix."_subcategory set displaypos=$newpos where catnr=$input_subcatnr";
			if(!$result = faqe_db_query($sql, $db))
			    die("<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".faqe_db_error());
		}
	}
}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?
if(!isset($input_catnr))
{
	if($admin_rights>2)
		$sql = "select prog.programmname, prog.language, cat.categoryname, cat.catnr from ".$tableprefix."_programm prog, ".$tableprefix."_category cat where prog.prognr=cat.programm  order by cat.catnr, prog.prognr";
	else
		$sql = "select prog.programmname, prog.language, cat.categoryname, cat.catnr from ".$tableprefix."_programm prog, ".$tableprefix."_category cat, ".$tableprefix."_category_admins ca where prog.prognr=cat.programm and cat.catnr=ca.catnr and ca.usernr=".$userdata["usernr"]." order by cat.catnr, prog.prognr";
	if(!$result = faqe_db_query($sql, $db)) {
	    die("<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".faqe_db_error());
	}
	if (!$myrow = faqe_db_fetch_array($result))
	{
		echo "<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"2\">";
		echo $l_noentries;
		echo "</td></tr></table></td></tr></table>";
	}
	else
	{
?>
<tr bgcolor="#c0c0c0"><td align="right" width="30%"><?php echo $l_selectcat?>:</td>
<form method="post" action="<?php echo $PHP_SELF?>">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<td><select name="input_catnr">
<?php
	do{
		echo "<option value=\"".$myrow["catnr"]."\">";
		echo $myrow["categoryname"]." (".$myrow["programmname"]." [".$myrow["language"]."])</option>";
	}while($myrow=faqe_db_fetch_array($result));
?>
</select></td></tr>
<tr bgcolor="#94AAD6"><td align="center" colspan="2"><input type="submit" value="<?php echo $l_ok?>"></td></tr></form>
</table></td></tr></table>
<?
	}
}
else
{
$sql = "select cat.*, prog.programmname, prog.language from ".$tableprefix."_programm prog, ".$tableprefix."_category cat where prog.prognr=cat.programm and cat.catnr=$input_catnr";
if(!$result = faqe_db_query($sql, $db)) {
    die("<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".faqe_db_error());
}
if (!$myrow = faqe_db_fetch_array($result))
{
	echo "<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"2\">";
	die("Calling error");
}
else
{
	$progname=$myrow["programmname"];
	$proglang=$myrow["language"];
}
?>
<tr bgcolor="#94AAD6">
<td align="center" colspan="3"><b><?php echo $l_category?>: <?php echo $myrow["categoryname"].": $progname [$proglang]"?></b></td></tr>
<?php
$sql = "select * from ".$tableprefix."_subcategory where category=$input_catnr order by displaypos asc";
if(!$result = faqe_db_query($sql, $db)) {
    die("<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".faqe_db_error());
}
if (!$myrow = faqe_db_fetch_array($result))
{
	echo "<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"3\">";
	echo $l_noentries;
	echo "</td></tr></table></td></tr></table>";
}
else
{
?>
<tr bgcolor="#c0c0c0">
<td align="center"><b><?php echo $l_subcatname?></b></td>
<td width="2%">&nbsp;</td><td width="2%">&nbsp;</td></tr>
<?php
		$mycount=0;
		do {
		$mycount++;
		$act_id=$myrow["catnr"];
		echo "<tr bgcolor=\"#cccccc\">";
		echo "<td width=\"70%\">".$myrow["categoryname"]."</td>";
		if($admin_rights > 1)
		{
			if($myrow["displaypos"]==0)
			{
				$tempsql="select max(displaypos) as newdisplaypos from ".$tableprefix."_subcategory where category=".$myrow["category"];
				if(!$tempresult = faqe_db_query($tempsql, $db))
				    die("<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".faqe_db_error());
				if(!$temprow = faqe_db_fetch_array($tempresult))
					$newpos=1;
				else
					$newpos=$temprow["newdisplaypos"]+1;
				$updatesql="update ".$tableprefix."_subcategory set displaypos=$newpos where catnr=".$myrow["catnr"];
				if(!$updateresult = faqe_db_query($updatesql, $db))
				    die("<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".faqe_db_error());
			}
			if($mycount>1)
			{
				echo "<td align=\"center\">";
				echo "<a href=\"".do_url_session("$PHP_SELF?mode=move&input_catnr=$input_catnr&input_subcatnr=$act_id&$langvar=$act_lang&direction=up")."\">";
				echo "<img src=\"gfx/up.gif\" border=\"0\" alt=\"$l_move_up\"></a>";
				echo "</td>";
			}
			else
				echo "<td>&nbsp;</td>";
			if($mycount<faqe_db_num_rows($result))
			{
				echo "<td align=\"center\">";
				echo "<a href=\"".do_url_session("$PHP_SELF?mode=move&$langvar=$act_lang&input_catnr=$input_catnr&input_subcatnr=$act_id&direction=down")."\">";
				echo "<img src=\"gfx/down.gif\" border=\"0\" alt=\"$l_move_down\"></a>";
				echo "</td>";
			}
			else
				echo "<td>&nbsp;</td>";
		}
		else
			echo "<td>&nbsp;</td>";
		echo "</td></tr>";
	} while($myrow = faqe_db_fetch_array($result));
	echo "</table></tr></td></table>";
}
	echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_change_cat</a></div>";
}
echo "<div align=\"center\"><a href=\"".do_url_session("subcategories.php?$langvar=$act_lang")."\">$l_subcatlist</a></div>";
include('./trailer.php');
?>