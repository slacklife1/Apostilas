<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
?>
<html><body>
<div align="center"><h3>FAQEngine: Upgrade v3.17/3.18 to v3.19</h3></div>
<br>
<?php
echo "Creating new tables...<br>";
// create table faq_subcategory
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_subcategory;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_subcategory");
$sql = "CREATE TABLE ".$tableprefix."_subcategory (";
$sql.= "catnr int(10) unsigned NOT NULL auto_increment,";
$sql.= "categoryname varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "category int(10) unsigned DEFAULT '0' ,";
$sql.= "displaypos int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "PRIMARY KEY (catnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_subcategory");
echo "Upgrading tables...<br>";
$sql = "ALTER TABLE ".$tableprefix."_data ADD ";
$sql.= "subcategory int(10) unsigned NOT NULL DEFAULT '0'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_data");
?>
<br><div align="center">Upgrade done.<br>Please remove install.php, upgrade*.php and fill_freemailer.php from server</div>
<div align="center">Now you can login to the <a href="index.php">admininterface</a></div>
</body></html>
