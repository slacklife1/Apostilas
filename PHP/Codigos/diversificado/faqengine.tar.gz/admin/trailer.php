<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
echo "<div align=\"center\">";
if(($userdata["rights"]>2)||($shutdown<1))
	echo "<a href=\"".do_url_session("index.php?$langvar=$act_lang")."\">$l_mainmenu</a><br>";
else
	echo "<hr>";
$usermode=$l_admin_rights[$admin_rights];
if($user_loggedin)
{
	echo "$l_loggedinas <i>".$userdata["username"]."</i> ($usermode)&nbsp;&nbsp;";
	if($enable_htaccess)
		echo "<a href=\"javascript:alert('$l_notavail_htaccess2')\">";
	else
		echo "<a href=\"".do_url_session("logout.php?$langvar=$act_lang")."\">";
	echo "$l_logout</a><br>";
}
echo "<hr><div align=\"center\">";
if($showcurrtime==1)
{
	$displaytime=date("H:i");
	echo "<font size=\"2\">$l_currtime $displaytime</font><br>";
}
if($showtimezone==1)
	echo "<font size=\"2\">$l_timezone_note $server_timezone</font><br>";
echo "<font size=\"2\">$copyright_url</font></a><br><font size=\"2\">$copyright_note</font></div>";
?>
</body></html>