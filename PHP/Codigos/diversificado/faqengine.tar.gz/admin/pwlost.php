<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include('./language/lang_'.$act_lang.'.php');
$sql = "select * from ".$tableprefix."_layout where (layoutnr=1)";
if(!$result = faqe_db_query($sql, $db))
	die("Could not connect to the database.");
if ($myrow = faqe_db_fetch_array($result))
{
	$faqemail=$myrow["faqemail"];
	if(!$faqemail)
		$faqemail="faq@foo.bar";
}
else
{
	$faqemail="faq@foo.bar";
}
if($enable_htaccess)
	die($l_notavail_htaccess);
if(!$enablerecoverpw)
	die($l_functionnotallowed);
?>
<html>
<head>
<meta name="generator" content="FAQEngine v<?php echo $version?>, <?php echo $copyright_asc?>">
<title>FAQEngine - Administration</title>
</head>
<body>
<table width="80%" align="CENTER" calign="MIDDLE" border="0" cellspacing="0" cellpadding="0">
<tr><td align="CENTER" bgcolor="#94AAD6"><font size="+2"><b>FAQEngine v<?php echo $version?></b></font></td></tr>
<tr><td align="CENTER" bgcolor="#c0c0c0"><font size="+2"><?php echo $l_pwlost?></font></td></tr>
</table>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
if(isset($mode))
{
	if($mode=="recover")
	{
		if(!$username)
		{
?>
<tr bgcolor="#94AAD6"><td align="center" colspan="2">
<?php echo $l_nousername?></td></tr>
<tr bgcolor="#c0c0c0"><form method="post" action="<?php echo $PHP_SELF?>">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<td align="right" width="30%"><?php echo $l_username?>:</td><td><input type="text" name="username" size="40" maxlength="80"></td></tr>
<tr bgcolor="#94AAD6"><td align="center" colspan="2"><input type="hidden" name="mode" value="recover"><input type="submit" value="<?php echo $l_submit?>"></td></tr>
</form>
<?
		}
		else
		{
			$username=strtolower($username);
			$sql = "select * from ".$tableprefix."_admins where username='$username'";
			if(!$result = faqe_db_query($sql, $db))
			    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
			if($myrow=faqe_db_fetch_array($result))
			{
				if(($myrow["lockpw"]==0) && $myrow["email"])
				{
					do{
						$maximum=9999999999;
						if($maximum>mt_getrandmax())
							$maximum=mt_getrandmax();
						mt_srand((double)microtime()*1000000);
						$autopin=mt_rand(10000,$maximum);
						$tempsql = "select * from ".$tableprefix."_admins where autopin=$autopin";
						if(!$tempresult = faqe_db_query($tempsql, $db))
							die("<tr bgcolor=\"#c0c0c0\" align=\"center\"><td align=\"center\" colspan=\"2\">Could not connect to the database.");
					}while($temprow=faqe_db_fetch_array($tempresult));
					$updatesql = "update ".$tableprefix."_admins set autopin=$autopin where username='$username'";
					if(!$updateresult = faqe_db_query($updatesql, $db))
						die("<tr bgcolor=\"#c0c0c0\" align=\"center\"><td align=\"center\" colspan=\"2\">Could not connect to the database.");
					$fromadr = "From:".$faqemail."\r\n";
					$subject = "Lost password FAQEngine ($faqsitename)";
					$mailmsg = "Sie haben bei der FAQEngine auf $faqsitename ein neues Passwort fuer Ihren Administrationszugang angefordert.\r\n";
					$mailmsg.= "Bitte benutzen Sie bei Ihrer naechsten Anmeldung das folgende temporaere Passwort und vergeben Sie ein neues.\r\n";
					$mailmsg.= "Sollten Sie das Passwort nicht angefordert haben, so melden Sie sich bitte so bald als moeglich mit Ihrem alten Passwort an.\r\n";
					$mailmsg.= "Das temporaere Passwort wird dann geloescht und verliert seine Gueltigkeit\r\n\r\n";
					$mailmsg.= "You have requested a new password for your administration account at FAQEngine on $faqsitename.\r\n";
					$mailmsg.= "Please use the temporary password provided in this email the next time you login and enter a new one.\r\n";
					$mailmsg.= "If this request was not initiated by you, please login as soon as possible using your old password.\r\n";
					$mailmsg.= "Doing so will erase the temporary password, so it no longer will be valid.\r\n\r\n";
					$mailmsg .="temporaeres Passwort/temporary password: $autopin\r\n\r\n\r\n\r\n";
					mail($myrow["email"],$subject,$mailmsg,$fromadr);
?>
<tr bgcolor="#94AAD6"><td align="center" colspan="2">
<?php echo $l_pwmailed?></td></tr>
<?php
				}
				else
				{
?>
<tr bgcolor="#94AAD6"><td align="center" colspan="2">
<?php echo $l_nonewpw?></td></tr>
<?php
				}
			}
			else
			{
?>
<tr bgcolor="#94AAD6"><td align="center" colspan="2">
<?php echo $l_nonewpw?></td></tr>
<?php
			}
		}
	}
}
else
{
?>
<tr bgcolor="#94AAD6"><td align="center" colspan="2">
<?php echo $l_enterusername?></td></tr>
<tr bgcolor="#c0c0c0"><form method="post" action="<?php echo $PHP_SELF?>">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<td align="right" width="30%"><?php echo $l_username?>:</td><td><input type="text" name="username" size="40" maxlength="80"></td></tr>
<tr bgcolor="#94AAD6"><td align="center" colspan="2"><input type="hidden" name="mode" value="recover"><input type="submit" value="<?php echo $l_submit?>"></td></tr>
</form>
<?
}
?>
</table></td></tr></table>
<?php
echo "<hr><div align=\"center\"><font size=\"2\">$copyright_url</font><br><font size=\"2\">$copyright_note</font></div>";
?>
</body></html>
