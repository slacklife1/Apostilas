<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include('./language/lang_'.$act_lang.'.php');
require('./auth.php');
$page_title=$l_cleansession;
require('./heading.php');
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<?php
if($admin_rights < 3)
{
	echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
	die("$l_functionnotallowed");
}
if(isset($submit))
{
		$sql = "DELETE FROM ".$tableprefix."_session";
		if(!$result = faqe_db_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr bgcolor="#C0C0C0"><td align="center"><?php echo $l_sessionsdeleted?></td></tr>
</table></td></tr></table>
<?php
	include('./trailer.php');
	exit;
}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr bgcolor="#C0C0C0">
<form method="post" action="<?php echo $PHP_SELF?>">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<td align="center"><?php echo $l_sessionwarning?></td></tr>
<tr bgcolor="#94AAD6">
<td align="center"><input type="submit" name="submit" value="<?php echo $l_yes?>"></td></tr>
</table></td></tr></table>
<?php
include('./trailer.php');
?>