<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
?>
<html><body>
<div align="center"><h3>FAQEngine: Upgrade v3.23/3.24 to v3.25</h3></div>
<br>
<?php
echo "Upgrading tables...<br>";
$sql = "ALTER TABLE ".$tableprefix."_layout add ";
$sql.= "pagetoppic varchar(80) NOT NULL DEFAULT 'gfx/top.gif'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_layout");
?>
<br><div align="center">Upgrade done.<br>Please remove install.php, upgrade*.php and fill_freemailer.php from server</div>
<div align="center">Now you can login to the <a href="index.php">admininterface</a></div>
</body></html>
