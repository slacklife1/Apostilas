<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include('./language/lang_'.$act_lang.'.php');
require('./auth.php');
$page_title=$l_admin_title;
require('./heading.php');
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr bgcolor="#94AAD6"><td align="center"><a name="#faq"><b><?php echo $l_faq?></b></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("os.php?$langvar=$act_lang")?>"><?php echo $l_oslist?></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("program.php?$langvar=$act_lang")?>"><?php echo $l_editprogs?></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("categories.php?$langvar=$act_lang")?>"><?php echo $l_editcats?></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("subcategories.php?$langvar=$act_lang")?>"><?php echo $l_editsubcats?></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("faq.php?$langvar=$act_lang")?>"><?php echo $l_editfaq?></a></td></tr>
<?php
if($admin_rights>2)
{
?>
<tr bgcolor="#e0e0e0"><td align="center"><b><?php echo $l_offlinefunctions?></b></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("offlinelists.php?$langvar=$act_lang")?>"><?php echo $l_offlinelists?></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("faq_upload.php?$langvar=$act_lang")?>"><?php echo $l_faqupload?></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("faq_download.php?$langvar=$act_lang")?>"><?php echo $l_faqdownload?></a></td></tr>
<?php
}
if($admin_rights>1)
{
?>
<tr bgcolor="#e0e0e0"><td align="center"><b><?php echo $l_rearrange?></b></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("reorder_prog.php?$langvar=$act_lang")?>"><?php echo $l_reorder_prog?></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("reorder_cat.php?$langvar=$act_lang")?>"><?php echo $l_reorder_cat?></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("reorder_subcat.php?$langvar=$act_lang")?>"><?php echo $l_reorder_subcat?></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("reorder_faq.php?$langvar=$act_lang")?>"><?php echo $l_reorder_faq?></a></td></tr>
<?php
}
?>
<tr bgcolor="#94AAD6"><td align="center"><a name="#userposts"><b><?php echo $l_userposts?></b></a></td></tr>
<tr bgcolor="#c0c0c0" align="center"><td><a href="<?php echo do_url_session("userquestions.php?$langvar=$act_lang")?>"><?php echo $l_userquestions?></a></td></tr>
<tr bgcolor="#c0c0c0" align="center"><td><a href="<?php echo do_url_session("usercomments.php?$langvar=$act_lang")?>"><?php echo $l_usercomments?></a></td></tr>
<tr bgcolor="#94AAD6"><td align="center"><a name="#kb"><b><?php echo $l_kb?></b></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("kb.php?$langvar=$act_lang")?>"><?php echo $l_articles?></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("kb_cats.php?$langvar=$act_lang")?>"><?php echo $l_editcats?></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("kb_subcats.php?$langvar=$act_lang")?>"><?php echo $l_editsubcats?></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("kb_treeview.php?$langvar=$act_lang")?>"><?php echo $l_treeview?></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("kb_stats.php?$langvar=$act_lang")?>"><?php echo $l_statistics?></a></td></tr>
<?php
if($admin_rights>1)
{
?>
<tr bgcolor="#e0e0e0"><td align="center"><b><?php echo $l_rearrange?></b></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("reorder_kb_cats.php?$langvar=$act_lang")?>"><?php echo $l_reorder_cat?></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("reorder_kb_subcats.php?$langvar=$act_lang")?>"><?php echo $l_reorder_subcat?></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("reorder_kb.php?$langvar=$act_lang")?>"><?php echo $l_reorder_kb?></a></td></tr>
<?php
}
?>
<tr bgcolor="#94AAD6"><td align="center"><a name="#stats"><b><?php echo $l_statistics?></b></a></td></tr>
<tr bgcolor="#c0c0c0" align="center"><td><a href="<?php echo do_url_session("treeview.php?$langvar=$act_lang")?>"><?php echo $l_treeview?></a></td></tr>
<tr bgcolor="#c0c0c0" align="center"><td><a href="<?php echo do_url_session("stats.php?$langvar=$act_lang")?>"><?php echo $l_statistics?></a></td></tr>
<tr bgcolor="#94AAD6"><td align="center"><a name="#users"><b><?php echo $l_adminmanagement?></b></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("users.php?$langvar=$act_lang")?>"><?php echo $l_editadmins?></a></td></tr>
<?php
if($admin_rights>2)
{
?>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("loginfailures.php?$langvar=$act_lang")?>"><?php echo $l_failed_logins?></a></td></tr>
<?php
}
?>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("banlist.php?$langvar=$act_lang")?>"><?php echo $l_ipbanlist?></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("freemailer.php?$langvar=$act_lang")?>"><?php echo $l_freemailerlist?></a></td></tr>
<?php
if($admin_rights>2)
{
?>
<tr bgcolor="#94AAD6"><td align="center"><a name="#layout"><b><?php echo $l_layout?></b></a></td></tr>
<tr bgcolor="#c0c0c0" align="center"><td><a href="<?php echo do_url_session("settings.php?$langvar=$act_lang")?>"><?php echo $l_editsettings?></a></td></tr>
<tr bgcolor="#c0c0c0" align="center"><td><a href="<?php echo do_url_session("texts.php?$langvar=$act_lang")?>"><?php echo $l_texts?></a></td></tr>
<tr bgcolor="#94AAD6"><td align="center"><a name="#admin"><b><?php echo $l_administration?></b></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("hostcache.php?$langvar=$act_lang")?>"><?php echo $l_hostcache?></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("sessions.php?$langvar=$act_lang")?>"><?php echo $l_cleansession?></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("shutdown.php?$langvar=$act_lang")?>"><?php echo $l_shutdownsys?></a></td></tr>
<tr bgcolor="#cccccc" align="center"><td><a href="<?php echo do_url_session("backup.php?$langvar=$act_lang")?>"><?php echo $l_dbbackup?></a></td></tr>
<?php
}
?>
</table></td></tr></table>
<?php include('./trailer.php')?>
