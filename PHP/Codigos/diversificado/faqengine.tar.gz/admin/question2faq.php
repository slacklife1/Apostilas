<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
require('./auth.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include('./language/lang_'.$act_lang.'.php');
$page_title=$l_transferquestion;
require('./heading.php');
$sql = "select * from ".$tableprefix."_layout where (layoutnr=1)";
if(!$result = faqe_db_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = faqe_db_fetch_array($result))
{
	$dateformat=$myrow["dateformat"];
	$dateformat.=" H:i:s";
}
else
	$dateformat="Y-m-d H:i:s";
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<?php
if(isset($mode))
{
	if($mode=="transfer")
	{
		if($admin_rights < 1)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
		$sql = "select * from ".$tableprefix."_questions where(questionnr=$input_questionnr)";
		if(!$result = faqe_db_query($sql, $db)) {
		    die("Could not connect to the database.");
		}
		if(!$myrow=faqe_db_fetch_array($result))
			die("No such entry");

		$prog_sql="select * from ".$tableprefix."_programm where prognr=".$myrow["prognr"];
		if(!$prog_result = faqe_db_query($prog_sql, $db)) {
		    die("Could not connect to the database.");
		}
		if($progrow=faqe_db_fetch_array($prog_result))
			$progname=htmlentities($progrow["programmname"]);
		else
			$progname=$l_undefined;
		$mod_sql ="select * from ".$tableprefix."_programm_admins where prognr=".$myrow["prognr"]." and usernr=".$userdata["usernr"];
		if(!$mod_result = faqe_db_query($mod_sql, $db)) {
		    die("Could not connect to the database.");
		}
		if($modrow=faqe_db_fetch_array($mod_result))
			$ismod=1;
		else
			$ismod=0;
		if(($admin_rights <3) && ($ismod==0))
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
		$actcat=-1;
		if($myrow["faqref"]>0)
		{
			$tempsql="select category from ".$tableprefix."_data where faqnr=".$myrow["faqref"];
			if(!$tempresult = faqe_db_query($tempsql, $db)) {
			    die("Could not connect to the database.");
			}
			if($temprow=faqe_db_fetch_array($tempresult))
				$actcat=$temprow["category"];
		}
		$questiontext=stripslashes($myrow["question"]);
		$questiontext = str_replace("<BR>", "\n", $questiontext);
		$questiontext = undo_htmlspecialchars($questiontext);
		$questiontext = bbdecode($questiontext);
		$questiontext = undo_make_clickable($questiontext);
		$answertext=stripslashes($myrow["answer"]);
		$answertext = str_replace("<BR>", "\n", $answertext);
		$answertext = undo_htmlspecialchars($answertext);
		$answertext = bbdecode($answertext);
		$answertext = undo_make_clickable($answertext);
		if(isset($delquotes))
			$answertext = preg_replace("#^>(.*)\n#m", "", $answertext);
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr bgcolor="#94AAD6"><td align="center" colspan="2"><b><?php echo $l_transferquestion?></b></td></tr>
<form method="post" action="<?php echo $PHP_SELF?>">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_heading?>:</td><td><input type="text" name="heading" size="40" maxlength="80"></td></tr>
<?php
		if($actcat<0)
		{
?>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_programm?>:</td><td><?php echo $progname?></td></tr>
<?php
		}
?>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_category?>:</td>
<td>
<?php
		if($admin_rights<3)
			$sql1 = "select cat.* from ".$tableprefix."_category cat, ".$tableprefix."_category_admins ca where cat.catnr = ca.catnr and ca.usernr=$act_usernr order by cat.catnr";
		else
			$sql1 = "select cat.* from ".$tableprefix."_category cat order by cat.catnr";
		if(!$result1 = faqe_db_query($sql1, $db)) {
			die("Could not connect to the database (3).");
		}
		if (!$temprow = faqe_db_fetch_array($result1))
		{
			echo "<a href=\"".do_url_session("categories.php?mode=new&$langvar=$act_lang")."\" target=\"_blank\">$l_new</a>";
		}
		else
		{
?>
<select name="category">
<option value="-1">???</option>
<?php
			do {
				$catname=htmlentities($temprow["categoryname"]);
				$prognr=$temprow["programm"];
				$sql = "select * from ".$tableprefix."_programm where (prognr=$prognr)";
				if(!$result2 = faqe_db_query($sql, $db)) {
					die("Could not connect to the database (3).");
				}
				if($temprow2 = faqe_db_fetch_array($result2))
				{
					$progname=htmlentities($temprow2["programmname"]);
					$proglang=$temprow2["language"];
				}
				else
				{
					$progname=$l_undefined;
					$proglang=$l_none;
				}
				echo "<option value=\"".$temprow["catnr"]."\"";
				if($temprow["catnr"]==$actcat)
					echo " selected";
				echo ">";
				echo "$catname ($progname [$proglang])";
				echo "</option>";
			} while($temprow = faqe_db_fetch_array($result1));
?>
</select>
<?php
		}
?>
</td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_question?>:<br>
<?php echo "<a href=\"help/".$act_lang."/bbcode.html\" target=\"_blank\">$l_bbcodehelp</a>"?>
</td><td><textarea name="question" cols="50" rows="10"><?php echo $questiontext?></textarea></td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_answer?>:<br>
<?php echo "<a href=\"help/".$act_lang."/bbcode.html\" target=\"_blank\">$l_bbcodehelp</a>"?>
</td><td><textarea name="answer" cols="50" rows="10"><?php echo $answertext?></textarea></td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_options?>:</td><td align="left">
<input type="checkbox" name="local_urlautoencode" value="1" <?php if($urlautoencode==1) echo "checked"?>> <?php echo $l_urlautoencode?><br>
<input type="checkbox" name="local_enablespcode" value="1" <?php if($enablespcode==1) echo "checked"?>> <?php echo $l_enablespcode?><br>
<input type="checkbox" name="transferdel" value="1" <?php if (isset($transferdel)) echo "checked"?>> <?php echo $l_deleteaftertransfer?>
<input type="hidden" name="input_questionnr" value="<?php echo $input_questionnr?>">
</td></tr>
<tr bgcolor="#94AAD6"><td align="center" colspan="2">
<input type="hidden" name="mode" value="add">
<input type="submit" value="<?php echo $l_enter?>">&nbsp;&nbsp;<input type="submit" name="preview" value="<?php echo $l_preview?>"></td></tr>
</form>
</table></td></tr></table>
<?php
		echo "<div align=\"center\"><a href=\"".do_url_session("userquestions.php?$langvar=$act_lang")."\">$l_userquestions</a></div>";
	}
	if($mode=="add")
	{
		if($admin_rights < 2)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		// Add new FAQ to database
		$errors=0;
		if(!$heading)
		{
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$l_noheading</td></tr>";
			$errors=1;
		}
		if($category<0)
		{
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$l_nocategory</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			if(isset($preview))
			{
				$displayheading=$heading;
				$displayheading=addslashes($displayheading);
				$displayheading=htmlentities($displayheading);
				$sql = "select prog.*, cat.categoryname from ".$tableprefix."_programm prog, ".$tableprefix."_category cat where prog.prognr=cat.programm and cat.catnr=$category";
				if(!$result = faqe_db_query($sql, $db))
				    die("Unable to connect to database.");
				if(!$myrow=faqe_db_fetch_array($result))
				{
					$progname=$l_unknown;
					$proglang=$l_unknown;
					$catname=$l_unknown;
				}
				else
				{
					$proglang=$myrow["language"];
					$progname=$myrow["programmname"];
					$catname=$myrow["categoryname"];
				}
				if(!isset($local_urlautoencode))
					$urlautoencode=0;
				else
					$urlautoencode=1;
				if(!isset($local_enablespcode))
					$enablespcode=0;
				else
					$enablespcode=1;
				$displayquestion="";
				$displayanswer="";
				if($question)
				{
					$displayquestion=stripslashes($question);
					if($urlautoencode==1)
						$displayquestion = make_clickable($displayquestion);
					if($enablespcode==1)
						$displayquestion = bbencode($displayquestion);
					$displayquestion = htmlentities($displayquestion);
					$displayquestion = str_replace("\n", "<BR>", $displayquestion);
					$displayquestion = undo_htmlspecialchars($displayquestion);
				}
				if($answer)
				{
					$displayanswer=stripslashes($answer);
					if($urlautoencode==1)
						$displayanswer = make_clickable($displayanswer);
					if($enablespcode==1)
						$displayanswer = bbencode($displayanswer);
					$displayanswer = htmlentities($displayanswer);
					$displayanswer = str_replace("\n", "<BR>", $displayanswer);
					$displayanswer = undo_htmlspecialchars($displayanswer);
				}
				echo "<tr><td bgcolor=\"#94AAD6\" align=\"center\" colspan=\"2\"><b>$l_newfaq</b></td></tr>";
				echo "<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"2\">";
				echo "$l_previewprelude:";
				echo "</td></tr>";
				echo "<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"2\">";
				echo "<b>$progname [$proglang] : $catname : $displayheading</b></td></tr>";
				echo "<tr bgcolor=\"#cccccc\"><td align=\"right\" width=\"20%\" valign=\"top\">";
				echo "$l_question:</td>";
				echo "<td align=\"left\" width=\"80%\">$displayquestion</td></tr>";
				echo "<tr bgcolor=\"#cccccc\"><td align=\"right\" width=\"20%\" valign=\"top\">";
				echo "$l_answer:</td>";
				echo "<td align=\"left\" width=\"80%\">$displayanswer</td></tr>";
?>
<tr bgcolor="#94AAD6" align="center"><form method="post" action="<?php echo $PHP_SELF?>">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<td colspan="2">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="mode" value="add">
<?php
if(isset($local_urlautoencode))
	echo "<input type=\"hidden\" name=\"local_urlautoencode\" value=\"1\">";
if(isset($local_enablespcode))
	echo "<input type=\"hidden\" name=\"local_enablespcode\" value=\"1\">";
if(isset($transferdel))
	echo "<input type=\"hidden\" name=\"transferdel\" value=\"1\">";
?>
<input type="hidden" name="input_questionnr" value="<?php echo $input_questionnr?>">
<input type="hidden" name="heading" value="<?php echo $heading?>">
<input type="hidden" name="category" value="<?php echo $category?>">
<input type="hidden" name="question" value="<?php echo $question?>">
<input type="hidden" name="answer" value="<?php echo $answer?>">
<input type="submit" value="<?php echo $l_enter?>">&nbsp;&nbsp;
<input type="button" value="<?php echo $l_back ?>" onclick="self.history.back();">
</td></form></tr></table></td></tr></table>
<?php
			}
			else
			{
				if(isset($transferdel))
				{
					if(isset($refaction))
					{
						if($refaction==1)
						{
							$sql="update ".$tableprefix."_questions set questionref=0 where questionref=$input_questionnr";
							if(!$result = faqe_db_query($sql, $db))
							    die("Unable to connect to database.");
						}
						if($refaction==2)
						{
							$sql="delete from ".$tableprefix."_questions where questionref=$input_questionnr";
							if(!$result = faqe_db_query($sql, $db))
							    die("Unable to connect to database.");
						}
					}
					$sql="select count(questionnr) from ".$tableprefix."_questions where questionref=$input_questionnr";
					if(!$result = faqe_db_query($sql, $db))
					    die("Unable to connect to database.");
					if ($temprow = faqe_db_fetch_array($result))
						$refcount=$temprow["count(questionnr)"];
					else
						$refcount=0;
					if($refcount>0)
					{
?>
<tr bgcolor="#c0c0c0"><form method="post" action="<?php echo $PHP_SELF?>">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<td align="center" colspan="2"><?php echo $l_qrefexist?></td></tr>
<tr bgcolor="#cccccc"><td width="20%">&nbsp;</td><td><input type="radio" name="refaction" value="1"> <?php echo $l_qrefremove?></td></tr>
<tr bgcolor="#cccccc"><td width="20%">&nbsp;</td><td><input type="radio" name="refaction" value="2"> <?php echo $l_qrefdel?>
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="mode" value="add">
<?php
if(isset($local_urlautoencode))
	echo "<input type=\"hidden\" name=\"local_urlautoencode\" value=\"1\">";
if(isset($local_enablespcode))
	echo "<input type=\"hidden\" name=\"local_enablespcode\" value=\"1\">";
?>
<input type="hidden" name="transferdel" value="1">
<input type="hidden" name="input_questionnr" value="<?php echo $input_questionnr?>">
<input type="hidden" name="heading" value="<?php echo $heading?>">
<input type="hidden" name="category" value="<?php echo $category?>">
<input type="hidden" name="question" value="<?php echo $question?>">
<input type="hidden" name="answer" value="<?php echo $answer?>">
</td></tr><tr bgcolor="#94AAD6" align="center">
<td colspan="2"><input type="submit" value="<?php echo $l_ok?>">
</td></form></tr></table></td></tr></table>
<?php
						include('./trailer.php');
						exit;
					}
				}
				$heading=addslashes($heading);
				$heading=htmlentities($heading);
				$editor=$userdata["username"];
				if($editor==-1)
					$editor="unknown";
				else
					$editor=addslashes($editor);
				if(!isset($local_urlautoencode))
					$urlautoencode=0;
				else
					$urlautoencode=1;
				if(!isset($local_enablespcode))
					$enablespcode=0;
				else
					$enablespcode=1;
				if($question)
				{
					$question=stripslashes($question);
					if($urlautoencode==1)
						$question = make_clickable($question);
					if($enablespcode==1)
						$question = bbencode($question);
					$question = htmlentities($question);
					$question = str_replace("\n", "<BR>", $question);
					$question=addslashes($question);
				}
				if($answer)
				{
					$answer=stripslashes($answer);
					if($urlautoencode==1)
						$answer = make_clickable($answer);
					if($enablespcode==1)
						$answer = bbencode($answer);
					$answer = htmlentities($answer);
					$answer = str_replace("\n", "<BR>", $answer);
					$answer=addslashes($answer);
				}
				$actdate = date("Y-m-d");
				$sql = "UPDATE ".$tableprefix."_category SET numfaqs = numfaqs + 1 WHERE (catnr = $category)";
				@faqe_db_query($sql, $db);
				$sql = "INSERT INTO ".$tableprefix."_data (heading, category, questiontext, answertext, editor, editdate) ";
				$sql .="VALUES ('$heading', $category, '$question', '$answer', '$editor', '$actdate')";
				if(!$result = faqe_db_query($sql, $db))
				    die("Unable to add FAQ to database.");
				if(isset($transferdel))
				{
					$sql = "delete from ".$tableprefix."_questions where questionnr=$input_questionnr";
					if(!$result = faqe_db_query($sql, $db))
					    die("Unable to delete user question from database.");
				}
				echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
				echo "$l_faqadded";
				if(isset($transferdel))
					echo "<br>$l_questiondeleted";
				echo "</td></tr></table></td></tr></table>";
				echo "<div align=\"center\">";
				echo "<a href=\"".do_url_session("faq.php?$langvar=$act_lang")."\">$l_faqlist</a>";
				echo "&nbsp;&nbsp;&nbsp;&nbsp;";
				echo "<a href=\"".do_url_session("userquestions.php?$langvar=$act_lang")."\">$l_userquestions</a>";
				echo "</div>";

			}
		}
		else
		{
			echo "<tr bgcolor=\"#94AAD6\" align=\"center\"><td>";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
	}
}
else
{
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr bgcolor="#c0c0c0"><td align="center"><?php echo $l_callingerror?></td></tr>
</table></td></tr></table>
<?php
}
include('./trailer.php');
?>