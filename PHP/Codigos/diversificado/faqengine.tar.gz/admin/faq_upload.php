<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
require('./auth.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include('./language/lang_'.$act_lang.'.php');
$page_title=$l_faqupload;
require('./heading.php');
$sql = "select * from ".$tableprefix."_layout where (layoutnr=1)";
if(!$result = faqe_db_query($sql, $db))
    die("Could not connect to the database.");
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<?php
if($admin_rights < 2)
{
	echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
	die("$l_functionnotallowed");
}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
if(isset($mode))
{
	if($mode=="upload")
	{
		$errors=0;
		if($faqlist=="none")
		{
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$l_nofile</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			$actmode=0;
			$numadded=0;
			$faqfile=fopen($faqlist,"r");
			$maxsize=filesize($faqlist);
			while($fileLine=fgets($faqfile,$maxsize))
			{
				if(eregi("^\{faqlist\}",$fileLine))
					$actmode=1;
				else if($actmode==1)
				{
					if(eregi("^\{/faqlist\}",$fileLine))
						$actmode=0;
					if(eregi("^\{faqentry\}",$fileLine))
					{
						$faqnr=0;
						$category=0;
						$subcategory=0;
						$heading="";
						$question="";
						$answer="";
						$actmode=2;
					}
				}
				else if($actmode==2)
				{
					if(eregi("^\{faqnr\}",$fileLine))
					{
						$fileLine=fgets($faqfile,$maxsize);
						if($fileLine)
						{
							$faqnr=trim($fileLine);
						}
						$fileLine=fgets($faqfile,$maxsize);
						if($fileLine)
						{
							if(!eregi("^\{/faqnr\}",$fileLine))
							{
								echo "<tr bgcolor=\"#94AAD6\" align=\"center\"><td>";
								die("corrupted list file");
							}
						}
					}
					if(eregi("^\{category\}",$fileLine))
					{
						$fileLine=fgets($faqfile,$maxsize);
						if($fileLine)
						{
							$category=trim($fileLine);
						}
						$fileLine=fgets($faqfile,$maxsize);
						if($fileLine)
						{
							if(!eregi("^\{/category\}",$fileLine))
							{
								echo "<tr bgcolor=\"#94AAD6\" align=\"center\"><td>";
								die("corrupted list file");
							}
						}
					}
					if(eregi("^\{subcategory\}",$fileLine))
					{
						$fileLine=fgets($faqfile,$maxsize);
						if($fileLine)
						{
							$subcategory=trim($fileLine);
						}
						$fileLine=fgets($faqfile,$maxsize);
						if($fileLine)
						{
							if(!eregi("^\{/subcategory\}",$fileLine))
							{
								echo "<tr bgcolor=\"#94AAD6\" align=\"center\"><td>";
								die("corrupted list file");
							}
						}
					}
					if(eregi("^\{heading\}",$fileLine))
					{
						$actmode=3;
						while(($fileLine=fgets($faqfile,$maxsize)) && ($actmode==3))
						{
							if(eregi("^\{/heading\}",$fileLine))
								$actmode=2;
							else
								$heading.=trim($fileLine);
						}
					}
					if(eregi("^\{question\}",$fileLine))
					{
						$actmode=3;
						while(($fileLine=fgets($faqfile,$maxsize)) && ($actmode==3))
						{
							if(eregi("^\{/question\}",$fileLine))
								$actmode=2;
							else
								$question.=trim($fileLine)."\n";
						}
					}
					if(eregi("^\{answer\}",$fileLine))
					{
						$actmode=3;
						while(($fileLine=fgets($faqfile,$maxsize)) && ($actmode==3))
						{
							if(eregi("^\{/answer\}",$fileLine))
								$actmode=2;
							else
								$answer.=trim($fileLine)."\n";
						}
					}
					if(eregi("^\{/faqentry\}",$fileLine))
					{
						$actmode=1;
						$question=stripslashes($question);
						if($urlautoencode==1)
							$question = make_clickable($question);
						if($enablespcode==1)
							$question = bbencode($question);
						$question = htmlentities($question);
						$question = str_replace("\n", "<BR>", $question);
						$question=addslashes($question);
						$answer=stripslashes($answer);
						if($urlautoencode==1)
							$answer = make_clickable($answer);
						if($enablespcode==1)
							$answer = bbencode($answer);
						$answer = htmlentities($answer);
						$answer = str_replace("\n", "<BR>", $answer);
						$answer=addslashes($answer);
						$heading=stripslashes($heading);
						$heading=htmlentities($heading);
						$heading=addslashes($heading);
						$editor=$userdata["username"];
						if($editor==-1)
							$editor="unknown";
						else
							$editor=addslashes($editor);
						$actdate = date("Y-m-d");
						if($faqnr>0)
						{
							$sql = "select * from ".$tableprefix."_data where faqnr=$faqnr";
							if(!$result = faqe_db_query($sql, $db))
							    die("Unable to connect to database.");
							if($myrow=faqe_db_fetch_array($result))
							{
								$oldcat=$myrow["category"];
								if($oldcat!=$category)
								{
									$sql = "UPDATE ".$tableprefix."_category SET numfaqs = numfaqs + 1 WHERE (catnr = $category)";
									@faqe_db_query($sql, $db);
									$sql = "UPDATE ".$tableprefix."_category SET numfaqs = numfaqs - 1 WHERE (catnr = $oldcat)";
									@faqe_db_query($sql, $db);
								}
								$sql = "update ".$tableprefix."_data set heading='$heading', questiontext='$question', answertext='$answer', ";
								$sql.= "editor='$editor', editdate='$actdate', category=$category, subcategory=$subcategory ";
								$sql.= "where faqnr=$faqnr";
								if(!$result = faqe_db_query($sql, $db))
								    die("Unable to update FAQ in database.");
							}
							else
								$faqnr=0;
						}
						if($faqnr==0)
						{
							$sql = "UPDATE ".$tableprefix."_category SET numfaqs = numfaqs + 1 WHERE (catnr = $category)";
							@faqe_db_query($sql, $db);
							$sql = "select max(displaypos) as newdisplaypos from ".$tableprefix."_data where category=$category";
							if(!$result = faqe_db_query($sql, $db))
							    die("Unable to add FAQ to database.");
							if($myrow=faqe_db_fetch_array($result))
								$displaypos=$myrow["newdisplaypos"]+1;
							else
								$displaypos=1;
							$sql = "INSERT INTO ".$tableprefix."_data (heading, category, questiontext, answertext, editor, editdate, displaypos, subcategory) ";
							$sql .="VALUES ('$heading', $category, '$question', '$answer', '$editor', '$actdate', $displaypos, $subcategory)";
							if(!$result = faqe_db_query($sql, $db))
							    die("Unable to add FAQ to database.");
						}
						$numadded++;
					}
				}
			}
			fclose($faqfile);
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$numadded $l_faqsadded";
			echo "</td></tr></table></td></tr></table>";
		}
		else
		{
			echo "<tr bgcolor=\"#94AAD6\" align=\"center\"><td>";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
	}
}
else
{
?>
<form ENCTYPE="multipart/form-data" method="post" action="<?php echo $PHP_SELF?>"><input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_file?>:</td>
<td><input type="file" name="faqlist"></td></tr>
<tr bgcolor="#94AAD6"><td align="center" colspan="2">
<input type="hidden" name="mode" value="upload">
<input type="submit" value="<?php echo $l_ok?>"></td></tr>
</form>
</table></td></tr></table>
<?
}
echo "<div align=\"center\"><a href=\"".do_url_session("faq.php?$langvar=$act_lang")."\">$l_faqlist</a></div>";
include('./trailer.php');
?>