<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
require('./auth.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include('./language/lang_'.$act_lang.'.php');
$page_title=$l_subcategory_title;
require('./heading.php');
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<?php
if(isset($mode))
{
	if($mode=="display")
	{
		if($admin_rights < 1)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$sql = "select * from ".$tableprefix."_subcategory where (catnr=$input_subcatnr)";
		if(!$result = faqe_db_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.".faqe_db_error());
		if (!$myrow = faqe_db_fetch_array($result))
			die("<tr bgcolor=\"#cccccc\"><td>no such entry");
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr><td bgcolor="#94AAD6" align="center" colspan="2"><b><?php echo $l_editsubcats?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_subcatname?>:</td><td><?php echo htmlentities($myrow["categoryname"])?></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_category?>:</td>
<td>
<?php
	$sql = "select cat.categoryname, prog.programmname, prog.language from ".$tableprefix."_programm prog, ".$tableprefix."_category cat where prog.prognr=cat.programm and cat.catnr=".$myrow["category"];
	if(!$result = faqe_db_query($sql, $db)) {
		die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database (3).");
	}
	if ($temprow = faqe_db_fetch_array($result))
		echo htmlentities($temprow["categoryname"])." : ".htmlentities($temprow["programmname"])." [".$temprow["language"]."]";
?>
</td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_relatedsubcats?>:</td>
<td>
<?php
	$sql = "select subcat.* from ".$tableprefix."_related_subcat rsc, ".$tableprefix."_subcategory subcat where rsc.srccat=$input_subcatnr and subcat.catnr=rsc.destcat";
	if(!$result = faqe_db_query($sql, $db)) {
		die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database (3).");
	}
	if (!$temprow = faqe_db_fetch_array($result))
	{
		echo $l_none;
	}
	else
	{
		do{
			echo $temprow["categoryname"]."<br>";
		}while($temprow=faqe_db_fetch_array($result));
	}
?>
</td></tr>
</table></tr></td></table>
<?php
		echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_subcatlist</a></div>";
	}
	// Page called with some special mode
	if($mode=="new")
	{
		if($admin_rights < 2)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
		// Display empty form for entering subcategory
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr><td bgcolor="#94AAD6" align="center" colspan="2"><b><?php echo $l_newsubcategory?> (1/2)</b></td></tr>
<form method="post" action="<?php echo $PHP_SELF?>"><input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_subcatname?>:</td><td><input type="text" name="subcategory" size="40" maxlength="80"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_category?>:</td>
<td>
<?php
	if($admin_rights<3)
		$sql = "select cat.*, prog.programmname, prog.language from ".$tableprefix."_programm prog, ".$tableprefix."_category cat, ".$tableprefix."_category_admins ca where cat.catnr = ca.catnr and ca.usernr=$act_usernr order and prog.prognr=cat.programm by cat.catnr";
	else
		$sql = "select cat.*, prog.programmname, prog.language from ".$tableprefix."_programm prog, ".$tableprefix."_category cat where prog.prognr=cat.programm order by cat.catnr";
	if(!$result = faqe_db_query($sql, $db)) {
		die("Could not connect to the database (3).");
	}
	if (!$temprow = faqe_db_fetch_array($result))
	{
		echo "<a href=\"".do_url_session("categories.php?mode=new&$langvar=$act_lang")."\" target=\"_blank\">$l_new</a>";
	}
	else
	{
?>
<select name="category">
<option value="-1">???</option>
<?php
	do {
		echo "<option value=\"".$temprow["catnr"]."\">";
		echo htmlentities(stripslashes($temprow["categoryname"]));
		echo " (";
		echo htmlentities(stripslashes($temprow["programmname"]));
		echo " [";
		echo stripslashes($temprow["language"]);
		echo "])</option>";
	} while($temprow = faqe_db_fetch_array($result));
?>
</select>
<?php
	}
?>
</td></tr>
<tr bgcolor="#94AAD6"><td align="center" colspan="2">
<input type="hidden" name="mode" value="new2">
<input type="submit" value="<?php echo $l_continue?>"></td></tr>
</form>
</table></td></tr></table>
<div align="center"><a href="<?php echo do_url_session("$PHP_SELF?$langvar=$act_lang")?>"><?php echo $l_subcatlist?></a></div>
<?php
	}
	if($mode=="new2")
	{
		if($admin_rights < 2)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr><td bgcolor="#94AAD6" align="center" colspan="2"><b><?php echo $l_newsubcategory?> (2/2)</b></td></tr>
<?php
		$errors=0;
		if($category<1)
		{
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$l_nocategory</td></tr>";
			$errors=1;
		}
		if(!$subcategory)
		{
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$l_nosubcatname</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
?>
<form method="post" action="<?php echo $PHP_SELF?>"><input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<tr bgcolor="#c0c0c0"><td align="right" width="30%"><?php echo $l_subcatname?>:</td><td><?php echo htmlentities($subcategory)?></td></tr>
<tr bgcolor="#c0c0c0"><td align="right"><?php echo $l_category?>:</td>
<td>
<?php
			$sql = "select cat.categoryname, prog.prognr, prog.programmname, prog.language from ".$tableprefix."_programm prog, ".$tableprefix."_category cat where prog.prognr=cat.programm and cat.catnr=".$category;
			if(!$result = faqe_db_query($sql, $db))
				die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database (3).");
			if ($temprow = faqe_db_fetch_array($result))
			{
				$prognr=$temprow["prognr"];
				echo htmlentities($temprow["categoryname"])." : ".htmlentities($temprow["programmname"])." [".$temprow["language"]."]";
			}
?>
</td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_relatedsubcats?>:</td>
<td>
<?php
			$sql = "SELECT subcat.*, cat.categoryname as maincat from ".$tableprefix."_subcategory subcat, ".$tableprefix."_category cat WHERE cat.programm=$prognr and subcat.category=cat.catnr";
		    if(!$result = faqe_db_query($sql, $db))
				die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.".faqe_db_error());
		    if($catrow = faqe_db_fetch_array($result))
		    {
				echo "<SELECT NAME=\"relsubcats[]\" size=\"5\" multiple>";
				do{
					echo "<OPTION VALUE=\"".$catrow["catnr"]."\" >".$catrow["categoryname"]." (".$catrow["maincat"].")</OPTION>\n";
				} while($catrow = faqe_db_fetch_array($result));
				echo "</select>";
			}
			else {
				echo "$l_none_avail\n";
			}
?>
</td></tr>
<input type="hidden" name="category" value="<?php echo $category?>">
<input type="hidden" name="subcategory" value="<?php echo htmlentities($subcategory)?>">
<tr bgcolor="#94AAD6"><td align="center" colspan="2">
<input type="hidden" name="mode" value="add">
<input type="submit" value="<?php echo $l_continue?>"></td></tr>
</form>
</table></td></tr></table>
<div align="center"><a href="<?php echo do_url_session("$PHP_SELF?$langvar=$act_lang")?>"><?php echo $l_subcatlist?></a></div>
<?php
		}
		else
		{
			echo "<tr bgcolor=\"#94AAD6\" align=\"center\"><td>";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
	}
	if($mode=="add")
	{
		if($admin_rights < 2)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		// Add new category to database
		$errors=0;
		if($category<1)
		{
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$l_nocategory</td></tr>";
			$errors=1;
		}
		if(!$subcategory)
		{
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$l_nosubcatname</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			$sql = "select max(displaypos) as newdisplaypos from ".$tableprefix."_subcategory where category=$category";
			if(!$result = faqe_db_query($sql, $db))
			    die("<tr bgcolor=\"#cccccc\"><td>Unable to add category to database.");
			if($myrow=faqe_db_fetch_array($result))
				$displaypos=$myrow["newdisplaypos"]+1;
			else
				$displaypos=1;
			$category=addslashes($category);
			$sql = "INSERT INTO ".$tableprefix."_subcategory (categoryname, category, displaypos) ";
			$sql .="VALUES ('$subcategory', '$category', $displaypos)";
			if(!$result = faqe_db_query($sql, $db))
			    die("<tr bgcolor=\"#cccccc\"><td>Unable to add subcategory to database.");
			$subcatnr = faqe_db_insert_id($db);
			if(isset($relsubcats))
			{
	    		while(list($null, $refsubcat) = each($HTTP_POST_VARS["relsubcats"])) {
	    			$cat_query = "INSERT INTO ".$tableprefix."_related_subcat (srccat, destcat) VALUES ($subcatnr,$refsubcat)";
	    		   	if(!faqe_db_query($cat_query, $db))
					    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
	    			$cat_query = "INSERT INTO ".$tableprefix."_related_subcat (destcat, srccat) VALUES ($subcatnr,$refsubcat)";
	    		   	if(!faqe_db_query($cat_query, $db))
					    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
	    		}
			}
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$l_subcatadded";
			echo "</td></tr></table></td></tr></table>";
			echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?mode=new&$langvar=$act_lang")."\">$l_newsubcategory</a></div>";
			echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_subcatlist</a></div>";
		}
		else
		{
			echo "<tr bgcolor=\"#94AAD6\" align=\"center\"><td>";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
	}
	if($mode=="delete")
	{
		if($admin_rights < 2)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		if(isset($faq_action))
		{
			$sql = "select count(faqnr) from ".$tableprefix."_data where (subcategory=$input_subcatnr)";
			if(!$result = faqe_db_query($sql, $db))
			    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database.");
			if ($temprow = faqe_db_fetch_array($result))
				$faqcount=$temprow["count(faqnr)"];
			else
				$faqcount=0;
			if($faq_action=="moveup")
			{
				$deleteSQL = "update ".$tableprefix."_data set subcategory=0 where (subcategory=$input_subcatnr)";
				$success = faqe_db_query($deleteSQL,$db);
				if (!$success)
					die("<tr bgcolor=\"#cccccc\"><td>$l_cantmove.");
				echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
				echo "<i>$faqcount</i>$l_faq $l_moved<br></td></tr>";
			}
			if($faq_action=="del")
			{
				$deleteSQL = "delete from ".$tableprefix."_data where (subcategory=$input_subcatnr)";
				$success = faqe_db_query($deleteSQL,$db);
				if (!$success)
					die("<tr bgcolor=\"#cccccc\"><td>$l_cantdelete.");
				echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
				echo "<i>$faqcount</i>$l_faq $l_deleted<br></td></tr>";
			}
			if($faq_action=="move")
			{
				if($new_cat>0)
				{
					$moveSQL = "UPDATE ".$tableprefix."_data set subcategory=$new_cat where (subcategory=$input_subcatnr)";
					$success = faqe_db_query($moveSQL,$db);
					if (!$success)
						die("<tr bgcolor=\"#cccccc\"><td>$l_cantmove.");
					$sql = "UPDATE ".$tableprefix."_category SET numfaqs = numfaqs + $faqcount WHERE (catnr = $new_maincat)";
					@faqe_db_query($sql, $db);
					echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
					echo "<i>$faqcount</i> $l_faq $l_moved<br></td></tr>";
				}
			}
		}
		$sql = "select count(faqnr) from ".$tableprefix."_data where (subcategory=$input_subcatnr)";
		if(!$result = faqe_db_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database.");
		if ($temprow = faqe_db_fetch_array($result))
			$faqcount=$temprow["count(faqnr)"];
		else
			$faqcount=0;
		if($faqcount>0)
		{
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr><td bgcolor="#94AAD6" align="center" colspan="2"><b><?php echo "$l_delsubcat ($catname)"?></b></td></tr>
<tr><td bgcolor="#c0c0c0" align="center" colspan="2"><?php echo "$l_faqincat ($faqcount)"?></td></tr>
<form action="<?php echo $PHP_SELF?>" method="post"><input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<?php
			if($sessid_url)
				echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="mode" value="delete">
<input type="hidden" name="input_catnr" value="<?php echo $input_catnr?>">
<input type="hidden" name="input_subcatnr" value="<?php echo $input_subcatnr?>">
<input type="hidden" name="catname" value="<?php echo $catname?>"><input type="hidden" name="oldprog" value="<?php echo $oldprog?>">
<tr><td bgcolor="#cccccc"><input type="radio" name="faq_action" value="del"><?php echo "$l_delfaq"?></td></tr>
<tr><td bgcolor="#cccccc"><input type="radio" name="faq_action" value="moveup"><?php echo "$l_movefaq"?> <?php echo $l_to?> <?php echo $l_maincat?></td></tr>
<tr><td bgcolor="#cccccc"><input type="radio" name="faq_action" value="move"><?php echo "$l_movefaq"?> <?php echo $l_to?>:
<?php
	$sql1 = "select * from ".$tableprefix."_subcategory where (catnr != $input_subcatnr) and (category = $input_catnr) order by catnr";
	if(!$result1 = faqe_db_query($sql1, $db)) {
		die("Could not connect to the database (3).");
	}
	if (!$temprow = faqe_db_fetch_array($result1))
	{
		echo "$l_noentries";
	}
	else
	{
?>
<select name="new_cat">
<option value="-1">???</option>
<?php
	do {
		$subcatname=htmlentities($temprow["categoryname"]);
		$catnr=$temprow["category"];
		$sql2 = "select cat.categoryname, prog.programmname, prog.language from ".$tableprefix."_programm prog, ".$tableprefix."_category cat where prog.prognr=cat.programm and cat.catnr=$catnr";
		if(!$result2 = faqe_db_query($sql2, $db)) {
			die("Could not connect to the database (3).");
		}
		if($temprow2 = faqe_db_fetch_array($result2))
		{
			$catname=htmlentities($temprow2["categoryname"]);
			$progname=htmlentities($temprow2["programmname"]);
			$proglang=$temprow2["language"];
		}
		else
		{
			$catname=$l_undefined;
			$progname=$l_undefined;
			$proglang=$l_none;
		}
		echo "<option value=\"".$temprow["catnr"]."\">";
		echo "$subcatname ($catname : $progname [$proglang])";
		echo "</option>";
	} while($temprow = faqe_db_fetch_array($result1));
?>
</select>
<?php
	}
?>
</td></tr>
<tr bgcolor="#94aad6"><td align="center" colspan="2">
<input type="submit" value="<?php echo $l_ok?>"></td></tr>
</form>
</table></tr></td></table>
<div align="center"><a href="<?php echo do_url_session("$PHP_SELF?$langvar=$act_lang")?>"><?php echo $l_subcatlist?></a></div>
<?php
		}
		else
		{
			$deleteSQL = "delete from ".$tableprefix."_subcategory where (catnr=$input_subcatnr)";
			$success = faqe_db_query($deleteSQL,$db);
			if (!$success)
				die("<tr bgcolor=\"#cccccc\"><td>$l_cantdelete.");
			$deleteSQL = "delete from ".$tableprefix."_related_subcat where srccat=$input_subcatnr or destcat=$input_catnr";
			$success = faqe_db_query($deleteSQL,$db);
			if (!$success)
				die("<tr bgcolor=\"#cccccc\"><td>$l_cantdelete.");
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "<i>$catname</i> $l_deleted<br>";
			echo "</td></tr></table></td></tr></table>";
			echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_subcatlist</a></div>";
		}
	}
	if($mode=="edit")
	{
		$modsql="select * from ".$tableprefix."_category_admins where catnr=$input_catnr and usernr=$act_usernr";
		if(!$modresult = faqe_db_query($modsql, $db)) {
		    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
		}
		if($modrow=faqe_db_fetch_array($modresult))
			$ismod=1;
		else
			$ismod=0;
		if(($admin_rights < 2) || (($admin_rights < 3) && ($ismod==0)))
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			echo "$l_functionnotallowed</td></tr></table></td></tr></table>";
			echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_subcatlist</a></div>";
			include('./trailer.php');
			exit;
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$sql = "select * from ".$tableprefix."_subcategory where (catnr=$input_subcatnr)";
		if(!$result = faqe_db_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
		if (!$myrow = faqe_db_fetch_array($result))
			die("<tr bgcolor=\"#cccccc\"><td>no such entry");
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr><td bgcolor="#94AAD6" align="center" colspan="2"><b><?php echo $l_editsubcats?> (1/2)</b></td></tr>
<form method="post" action="<?php echo $PHP_SELF?>">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="input_catnr" value="<?php echo $input_catnr?>">
<input type="hidden" name="input_subcatnr" value="<?php echo $myrow["catnr"]?>">
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_catname?>:</td><td><input type="text" name="subcategory" size="40" maxlength="80" value="<?php echo htmlentities($myrow["categoryname"])?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_category?>:</td>
<td>
<?php
	if($admin_rights<3)
		$sql = "select pr.programmname, pr.language, cat.categoryname, cat.catnr from ".$tableprefix."_programm pr, ".$tableprefix."_category cat, ".$tableprefix."_category_admins ca where pr.prognr = cat.programm and ca.usernr=".$userdata["usernr"]." order by cat.catnr";
	else
		$sql = "select pr.programmname, pr.language, cat.categoryname, cat.catnr from ".$tableprefix."_programm pr, ".$tableprefix."_category cat where pr.prognr=cat.programm  order by cat.catnr";
	if(!$result = faqe_db_query($sql, $db)) {
		die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database (3).");
	}
	if (!$temprow = faqe_db_fetch_array($result))
	{
		echo "<a href=\"".do_url_session("category.php?mode=new&$langvar=$act_lang")."\" target=\"_blank\">$l_new</a>";
	}
	else
	{
?>
<select name="category">
<option value="-1">???</option>
<?php
	do {
		echo "<option value=\"".$temprow["catnr"]."\"";
		if($myrow["category"]==$temprow["catnr"])
			echo " selected";
		echo ">";
		echo htmlentities(stripslashes($temprow["categoryname"]));
		echo " (";
		echo htmlentities(stripslashes($temprow["programmname"]));
		echo " [";
		echo stripslashes($temprow["language"]);
		echo "])";
		echo "</option>";
	} while($temprow = faqe_db_fetch_array($result));
?>
</select>
<?php
	}
?>
</td></tr>
<tr bgcolor="#94aad6"><td align="center" colspan="2"><input type="hidden" name="mode" value="edit2">
<input type="submit" value="<?php echo $l_continue?>"></td></tr>
</form>
</table></tr></td></table>
<div align="center"><a href="<?php echo do_url_session("$PHP_SELF?$langvar=$act_lang")?>"><?php echo $l_subcatlist?></a></div>
<?php
	}
	if($mode=="edit2")
	{
		if($admin_rights < 2)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr><td bgcolor="#94AAD6" align="center" colspan="2"><b><?php echo $l_editsubcats?> (2/2)</b></td></tr>
<?php
		$errors=0;
		if($category<1)
		{
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$l_nocategory</td></tr>";
			$errors=1;
		}
		if(!$subcategory)
		{
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$l_nosubcatname</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
?>
<form method="post" action="<?php echo $PHP_SELF?>"><input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<tr bgcolor="#c0c0c0"><td align="right" width="30%"><?php echo $l_subcatname?>:</td><td><?php echo htmlentities($subcategory)?></td></tr>
<tr bgcolor="#c0c0c0"><td align="right"><?php echo $l_category?>:</td>
<td>
<?php
			$sql = "select cat.categoryname, prog.prognr, prog.programmname, prog.language from ".$tableprefix."_programm prog, ".$tableprefix."_category cat where prog.prognr=cat.programm and cat.catnr=".$category;
			if(!$result = faqe_db_query($sql, $db))
				die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database (3).");
			if ($temprow = faqe_db_fetch_array($result))
			{
				$prognr=$temprow["prognr"];
				echo htmlentities($temprow["categoryname"])." : ".htmlentities($temprow["programmname"])." [".$temprow["language"]."]";
			}
?>
</td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_relatedsubcats?>:</td>
<td>
<?php
			$catsql = "SELECT subcat.*, cat.categoryname as maincat from ".$tableprefix."_subcategory subcat, ".$tableprefix."_related_subcat rsc, ".$tableprefix."_category cat where rsc.srccat=$input_subcatnr and subcat.catnr=rsc.destcat and cat.catnr=subcat.category";
			if(!$catresult = faqe_db_query($catsql, $db))
			    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
			if ($catrow = faqe_db_fetch_array($catresult))
			{
				 do {
				    echo $catrow["categoryname"]." (".$catrow["maincat"].") (<input type=\"checkbox\" name=\"rem_relsubcats[]\" value=\"".$catrow["catnr"]."\"> $l_remove)<BR>";
				    $current_relsubcats[] = $catrow["catnr"];
				 } while($catrow = faqe_db_fetch_array($catresult));
				 echo "<br>";
			}
			else
				echo "$l_norelatedsubcats<br><br>";
			$catsql = "SELECT subcat.*, cat.categoryname as maincat from ".$tableprefix."_subcategory subcat, ".$tableprefix."_category cat WHERE cat.programm=$prognr and subcat.category=cat.catnr and subcat.catnr!=$input_subcatnr ";
			if(isset($current_relsubcats))
			{
    			while(list($null, $currCat) = each($current_relsubcats)) {
					$catsql .= "and subcat.catnr != $currCat ";
    			}
    		}
    		$catsql .="order by subcat.categoryname";
    		if(!$catresult = faqe_db_query($catsql, $db))
				die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.".faqe_db_error());
    		if($catrow = faqe_db_fetch_array($catresult)) {
				echo"<b>$l_add:</b><br>";
				echo "<SELECT NAME=\"relsubcats[]\" size=\"5\" multiple>";
				do {
					echo "<OPTION VALUE=\"".$catrow["catnr"]."\" >".$catrow["categoryname"]."(".$catrow["maincat"].")</OPTION>\n";
				} while($catrow = faqe_db_fetch_array($catresult));
				echo "</select>";
			}
?>
</td></tr>
<input type="hidden" name="category" value="<?php echo $category?>">
<input type="hidden" name="subcategory" value="<?php echo htmlentities($subcategory)?>">
<input type="hidden" name="input_catnr" value="<?php echo $input_catnr?>">
<input type="hidden" name="input_subcatnr" value="<?php echo $input_subcatnr?>">
<tr bgcolor="#94AAD6"><td align="center" colspan="2">
<input type="hidden" name="mode" value="update">
<input type="submit" value="<?php echo $l_continue?>"></td></tr>
</form>
</table></td></tr></table>
<div align="center"><a href="<?php echo do_url_session("$PHP_SELF?$langvar=$act_lang")?>"><?php echo $l_subcatlist?></a></div>
<?php
		}
		else
		{
			echo "<tr bgcolor=\"#94AAD6\" align=\"center\"><td>";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
	}
	if($mode=="update")
	{
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$modsql="select * from ".$tableprefix."_category_admins where catnr=$input_catnr and usernr=$act_usernr";
		if(!$modresult = faqe_db_query($modsql, $db)) {
		    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
		}
		if($modrow=faqe_db_fetch_array($modresult))
			$ismod=1;
		else
			$ismod=0;
		if(($admin_rights < 2) || (($admin_rights < 3) && ($ismod==0)))
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			echo "$l_functionnotallowed</td></tr></table></td></tr></table>";
			echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_subcatlist</a></div>";
			include('./trailer.php');
			exit;
		}
		$errors=0;
		if($category<1)
		{
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$l_nocategory</td></tr>";
			$errors=1;
		}
		if(!$subcategory)
		{
			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$l_nosubcatname</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			$sql = "UPDATE ".$tableprefix."_subcategory SET categoryname='$subcategory', category='$category' ";
			$sql .=" WHERE (catnr = $input_subcatnr)";
			if(!$result = faqe_db_query($sql, $db))
			    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
			if(isset($rem_relsubcats))
			{
				while(list($null, $subcat) = each($HTTP_POST_VARS["rem_relsubcats"]))
				{
					$rem_query = "DELETE FROM ".$tableprefix."_related_subcat WHERE srccat = '$input_subcatnr' AND destcat = '$subcat'";
	       			if(!faqe_db_query($rem_query,$db))
					    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
					$rem_query = "DELETE FROM ".$tableprefix."_related_subcat WHERE destcat = '$input_subcatnr' AND srccat = '$subcat'";
	       			if(!faqe_db_query($rem_query,$db))
					    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
				}
			}
			if(isset($relsubcats))
			{
	    		while(list($null, $relsubcat) = each($HTTP_POST_VARS["relsubcats"])) {
	    			$cat_query = "INSERT INTO ".$tableprefix."_related_subcat (srccat, destcat) VALUES ($input_subcatnr,$relsubcat)";
	    		   	if(!faqe_db_query($cat_query, $db))
					    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
	    			$cat_query = "INSERT INTO ".$tableprefix."_related_subcat (destcat, srccat) VALUES ($input_subcatnr,$relsubcat)";
	    		   	if(!faqe_db_query($cat_query, $db))
					    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
	    		}
			}

			echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
			echo "$l_subcatupdated";
			echo "</td></tr></table></td></tr></table>";
			echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_subcatlist</a></div>";
		}
		else
		{
			echo "<tr bgcolor=\"#94AAD6\" align=\"center\"><td>";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
	}
}
else
{
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
	if($admin_rights>1)
	{
?>
<tr bgcolor="#94AAD6"><td colspan="6" align="center">
<a href="<?php echo do_url_session("$PHP_SELF?mode=new&$langvar=$act_lang")?>"><?php echo $l_newsubcategory?></a>
</table></td></tr></table>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?
	}
// Display list of actual subcategories
if(isset($filtercat) && ($filtercat >=0))
	$sql = "select * from ".$tableprefix."_subcategory where category=$filtercat order by catnr";
else
	$sql = "select * from ".$tableprefix."_subcategory order by catnr";
if(!$result = faqe_db_query($sql, $db)) {
    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
}
if (!$myrow = faqe_db_fetch_array($result))
{
	echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
	echo $l_noentries;
	echo "</td></tr></table></td></tr></table>";
}
else
{
	echo "<tr bgcolor=\"#c0c0c0\">";
	echo "<td align=\"center\" width=\"5%\"><b>#</b></td>";
	echo "<td align=\"center\" width=\"40%\"><b>$l_subcatname</b></td>";
	echo "<td align=\"center\" width=\"30%\"><b>$l_category</b></td>";
	echo "<td>&nbsp;</td></tr>";
	do {
		$act_id=$myrow["catnr"];
		$act_cat=$myrow["category"];
		echo "<tr bgcolor=\"#cccccc\">";
		echo "<td align=\"right\">".$myrow["catnr"]."</td>";
		echo "<td>".htmlentities($myrow["categoryname"])."</td>";
		$tempsql = "select cat.categoryname, prog.programmname, prog.language from ".$tableprefix."_programm prog, ".$tableprefix."_category cat where prog.prognr=cat.programm and cat.catnr=".$myrow["category"];
		if(!$tempresult = faqe_db_query($tempsql, $db)) {
		    die("Could not connect to the database.");
		}
		if (!$temprow = faqe_db_fetch_array($tempresult))
		{
			$progame=$l_undefined;
			$proglang=$l_none;
			$catname=$l_undefined;
		}
		else
		{
			$catname=htmlentities($temprow["categoryname"]);
			$progname=htmlentities($temprow["programmname"]);
			$proglang=$temprow["language"];
		}
		echo "<td>$progname [$proglang]: $catname</td>";
		echo "<td>";
		$modsql="select * from ".$tableprefix."_category_admins where catnr=$act_cat and usernr=".$userdata["usernr"];
		if(!$modresult = faqe_db_query($modsql, $db)) {
		    die("Could not connect to the database.");
		}
		if($modrow=faqe_db_fetch_array($modresult))
			$ismod=1;
		else
			$ismod=0;
		if(($admin_rights>2) || ($ismod==1))
		{
			echo "<a href=\"".do_url_session("$PHP_SELF?mode=delete&input_subcatnr=$act_id&$langvar=$act_lang&catname=".urlencode($myrow["categoryname"])."&input_catnr=".$myrow["category"])."\">";
			echo "$l_delete</a>";
			echo "&nbsp;&nbsp;";
			echo "<a href=\"".do_url_session("$PHP_SELF?mode=edit&input_subcatnr=$act_id&$langvar=$act_lang&input_catnr=".$myrow["category"])."\">";
			echo "$l_edit</a>&nbsp; ";
		}
		echo "<a href=\"".do_url_session("$PHP_SELF?mode=display&input_subcatnr=$act_id&$langvar=$act_lang&catname=".urlencode($myrow["categoryname"]))."\">";
		echo "$l_display</a>";
		echo "</td></tr>";
	} while($myrow = faqe_db_fetch_array($result));
	echo "</table></tr></td></table>";
}
if($admin_rights > 1)
{
	if($admin_rights<3)
		$sql1 = "select cat.*, prog.programmname, prog.language from ".$tableprefix."_programm prog, ".$tableprefix."_category cat, ".$tableprefix."_category_admins ca where cat.catnr = ca.catnr and ca.usernr=$act_usernr order and prog.prognr=cat.programm by cat.catnr";
	else
		$sql1 = "select cat.*, prog.programmname, prog.language from ".$tableprefix."_programm prog, ".$tableprefix."_category cat where prog.prognr=cat.programm order by cat.catnr";
	if(!$result1 = faqe_db_query($sql1, $db)) {
		die("Could not connect to the database (3).".faqe_db_error());
	}
	if ($temprow = faqe_db_fetch_array($result1))
	{
?>
<br>
<table align="center" width="50%" border="0" cellspacing="0" cellpadding="1" valign="top">
<form action="<?php echo $PHP_SELF?>" method="post">
<input type="hidden" name="lang" value="<?php echo $lang?>">
<tr><td align="right" width="50%" valign="top"><?php echo $l_catfilter?>:</td>
<td align="left" width="30%"><select name="filtercat">
<option value="-1"><?php echo $l_nofilter?></option>
<?php
	do {
		$progname=htmlentities($temprow["programmname"]);
		$proglang=htmlentities($temprow["language"]);
		$catname=htmlentities($temprow["categoryname"]);
		echo "<option value=\"".$temprow["catnr"]."\"";
		if(isset($filtercat))
		{
			if($filtercat==$temprow["catnr"])
				echo " selected";
		}
		echo ">";
		echo "$catname ($progname [$proglang])";
		echo "</option>";
	} while($temprow = faqe_db_fetch_array($result1));
?>
</select></td><td align="left"><input type="submit" value="<?php echo $l_ok?>"></td></tr>
</form></table>
<?php
	}
?>
<div align="center"><a href="<?php echo do_url_session("$PHP_SELF?mode=new&$langvar=$act_lang")?>"><?php echo $l_newsubcategory?></a></div>
<?php
}
}
include('./trailer.php');
?>