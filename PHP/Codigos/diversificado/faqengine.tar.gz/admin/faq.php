<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
require_once('./auth.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include('./language/lang_'.$act_lang.'.php');
$page_title=$l_faq_title;
$page="faqedit";
require_once('./heading.php');
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<?php
if(isset($mode))
{
	if($mode=="display")
	{
		include("./includes/faq_display.inc");
	}
	// Page called with some special mode
	if($mode=="new")
	{
		include("./includes/faq_new.inc");
	}
	if($mode=="new2")
	{
		include("./includes/faq_new2.inc");
	}
	if($mode=="add")
	{
		include("./includes/faq_add.inc");
	}
	if($mode=="delattach")
	{
		if($admin_rights < 2)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$deleteSQL = "delete from ".$tableprefix."_bindata where (faqnr=$input_faqnr)";
		$success = faqe_db_query($deleteSQL,$db);
		if (!$success)
			die("<tr bgcolor=\"#cccccc\"><td>$l_cantdelete.");
		echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
		echo "$l_attachementdeleted<br>";
		echo "</td></tr></table></td></tr></table>";
		echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_faqlist</a></div>";
	}
	if($mode=="delete")
	{
		if($admin_rights < 2)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$deleteSQL = "delete from ".$tableprefix."_bindata where (faqnr=$input_faqnr)";
		$success = faqe_db_query($deleteSQL,$db);
		if (!$success)
			die("<tr bgcolor=\"#cccccc\"><td>$l_cantdelete.");
		$deleteSQL = "delete from ".$tableprefix."_data where (faqnr=$input_faqnr)";
		$success = faqe_db_query($deleteSQL,$db);
		if (!$success)
			die("<tr bgcolor=\"#cccccc\"><td>$l_cantdelete.");
		$sql = "UPDATE ".$tableprefix."_category SET numfaqs = numfaqs - 1 WHERE (catnr = $oldcat)";
		@faqe_db_query($sql, $db);
		$deleteSQL = "delete from ".$tableprefix."_faq_keywords where (faqnr=$input_faqnr)";
		$success = faqe_db_query($deleteSQL,$db);
		if (!$success)
			die("<tr bgcolor=\"#cccccc\"><td>$l_cantdelete.");
		purge_keywords($db);
		$deleteSQL = "delete from ".$tableprefix."_faq_ref where (srcfaqnr=$input_faqnr) or (destfaqnr=$input_faqnr)";
		$success = faqe_db_query($deleteSQL,$db);
		if (!$success)
			die("<tr bgcolor=\"#cccccc\"><td>$l_cantdelete.");
		$deleteSQL = "DELETE FROM ".$tableprefix."_related_faq WHERE srcfaq = '$input_faqnr' or destfaq = '$input_faqnr'";
		$success = faqe_db_query($deleteSQL,$db);
		if (!$success)
			die("<tr bgcolor=\"#cccccc\"><td>$l_cantdelete.");
		echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
		echo "<i>$heading</i> $l_deleted<br>";
		echo "</td></tr></table></td></tr></table>";
		echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_faqlist</a></div>";
	}
	if($mode=="edit")
	{
		include("./includes/faq_edit.inc");
	}
	if($mode=="edit2")
	{
		include("./includes/faq_edit2.inc");
	}
	if($mode=="update")
	{
		include("./includes/faq_update.inc");
	}
	if($mode=="resetviews")
	{
		$sql = "UPDATE ".$tableprefix."_data SET views=0 WHERE (faqnr = $input_faqnr)";
		if(!$result = faqe_db_query($sql, $db))
		    die("<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>Unable to update the database.");
		echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
		echo "$l_viewsreset";
		echo "</td></tr></table></td></tr></table>";
		echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_faqlist</a></div>";
	}
}
else
{
	include("./includes/faq_list.inc");
}
include('./trailer.php');
?>