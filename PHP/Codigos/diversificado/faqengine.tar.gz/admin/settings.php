<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include('./language/lang_'.$act_lang.'.php');
require('./auth.php');
$page_title=$l_settings_title;
require('./heading.php');
$checked_pic="gfx/checked.gif";
$unchecked_pic="gfx/unchecked.gif";
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<?php
if($admin_rights < 3)
{
	echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
	die("$l_functionnotallowed");
}
if(isset($mode))
{
	if(isset($ratingspub))
		$ratingspublic=1;
	else
		$ratingspublic=0;
	if(isset($pubratecom))
	{
		if($ratingspublic==1)
			$ratingcommentpublic=1;
		else
			$ratingcommentpublic=0;
	}
	else
		$ratingcommentpublic=0;
	if(isset($enablehover))
		$hovercells=1;
	else
		$hovercells=0;
	if(isset($ratingcom))
		$ratingcomment=1;
	else
		$ratingcomment=0;
	if(isset($totalsummary))
		$summaryintotallist=1;
	else
		$summaryintotallist=0;
	if(isset($limitrelated))
		$faqlimitrelated=1;
	else
		$faqlimitrelated=0;
	if(isset($enablerelated))
		$displayrelated=1;
	else
		$displayrelated=0;
	$stylesheet=addslashes($stylesheet);
	if(isset($allowjumpboxes))
		$enablejumpboxes=1;
	else
		$enablejumpboxes=0;
	if(isset($dofaqnewdisplay))
		$enablefaqnewdisplay=1;
	else
		$enablefaqnewdisplay=0;
	if(isset($dokbrating))
		$enablekbrating=1;
	else
		$enablekbrating=0;
	if(isset($dorating))
		$displayrating=1;
	else
		$displayrating=0;
	if(isset($showproglist))
		$proglist=1;
	else
		$proglist=0;
	if(isset($dologincount))
		$watchlogins=1;
	else
		$watchlogins=0;
	if(isset($enablecustomheader))
		$usecustomheader=1;
	else
		$usecustomheader=0;
	if(isset($enablecustomfooter))
		$usecustomfooter=1;
	else
		$usecustomfooter=0;
	if(isset($enableascheader))
		$useascheader=1;
	else
		$useascheader=0;
	if(isset($questionosrequired))
		$questionrequireos=1;
	else
		$questionrequireos=0;
	if(isset($useshortcutbar))
		$enableshortcutbar=1;
	else
		$enableshortcutbar=0;
	if(isset($enablefaqshortcuts))
		$faqlistshortcuts=1;
	else
		$faqlistshortcuts=0;
	if(isset($versionrequired))
		$questionrequireversion=1;
	else
		$questionrequireversion=0;
	$sql="select * from ".$tableprefix."_layout where (layoutnr=1)";
	if(!$result = faqe_db_query($sql, $db)) {
	    die("Could not connect to the database.");
	}
	if(!$myrow = faqe_db_fetch_array($result))
	{
		$customheader="";
		$customfooter="";
		$ascheader="";
	}
	else
	{
		$customheader=$myrow["pageheader"];
		$customfooter=$myrow["pagefooter"];
		$ascheader=$myrow["ascheader"];
	}
	if(isset($clearcustomheader))
		$customheader="";
	else
	{
		if($customheaderfile!="none")
			$customheader = addslashes(fread(fopen($customheaderfile,"r"), filesize($customheaderfile)));
	}
	if(isset($clearascheader))
		$ascheader="";
	else
	{
		if($ascheaderfile!="none")
			$ascheader = addslashes(fread(fopen($ascheaderfile,"r"), filesize($ascheaderfile)));
	}
	if(isset($clearcustomfooter))
		$customfooter="";
	else
	{
		if($customfooterfile!="none")
			$customfooter = addslashes(fread(fopen($customfooterfile,"r"), filesize($customfooterfile)));
	}
	if(isset($enabletimezone))
		$showtimezone=1;
	else
		$showtimezone=0;
	if(isset($enablecurrenttime))
		$showcurrtime=1;
	else
		$showcurrtime=0;
	if(isset($doheaderprint))
		$printheader=1;
	else
		$printheader=0;
	if(isset($dofooterprint))
		$printfooter=1;
	else
		$printfooter=0;
	$footerfile=addslashes($footerfile);
	$headerfile=addslashes($headerfile);
	if((!$customheader) && (!$headerfile))
		$usecustomheader=0;
	if((!$customfooter) && (!$footerfile))
		$usecustomfooter=0;
	if(isset($enableemail))
		$allowemail=1;
	else
		$allowemail=0;
	if(isset($enableautourl))
		$urlautoencode=1;
	else
		$urlautoencode=0;
	if(isset($allowspcode))
		$enablespcode=1;
	else
		$enablespcode=0;
	if(isset($enablefreemailer))
		$nofreemailer=0;
	else
		$nofreemailer=1;
	if(isset($enablequestions))
		$allowquestions=1;
	else
		$allowquestions=0;
	if(isset($enableusercomments))
		$allowusercomments=1;
	else
		$allowusercomments=0;
	if(isset($commentnotify))
		$newcommentnotify=1;
	else
		$newcommentnotify=0;
	if(isset($enablesearch))
		$allowsearch=1;
	else
		$allowsearch=0;
	if(isset($enablelists))
		$allowlists=1;
	else
		$allowlists=0;
	if(isset($dofailednotify))
		$enablefailednotify=1;
	else
		$enablefailednotify=0;
	if(isset($allowhostresolve))
		$enablehostresolve=1;
	else
		$enablehostresolve=0;
	if(isset($enablesearchcomments))
		$searchcomments=1;
	else
		$searchcomments=0;
	if(isset($enablesearchquestions))
		$searchquestions=1;
	else
		$searchquestions=0;
	if(isset($enablesummary))
		$showsummary=1;
	else
		$showsummary=0;
	if(isset($dorestrict))
		$progrestrict=1;
	else
		$progrestrict=0;
	if(isset($docommentrating))
		$ratecomments=1;
	else
		$ratecomments=0;
	if(isset($enablemenubar))
		$usemenubar=1;
	else
		$usemenubar=0;
	if(isset($allowkeywordsearch))
		$enablekeywordsearch=1;
	else
		$enablekeywordsearch=0;
	if(isset($showlanguageselector))
		$enablelanguageselector=1;
	else
		$enablelanguageselector=0;
	if(isset($forcewrap))
		$ascforcewrap=1;
	else
		$ascforcewrap=0;
	if(isset($sendanswermail))
		$userquestionanswermail=1;
	else
		$userquestionanswermail=0;
	if(isset($autopublishquestion))
		$userquestionautopublish=1;
	else
		$userquestionautopublish=0;
	if($new==1)
	{
		$sql = "INSERT INTO ".$tableprefix."_layout (layoutnr, headingbg, bgcolor1, bgcolor2, bgcolor3, pagebg, tablewidth, fontface, fontsize1, fontsize2, fontsize3, fontsize4, fontcolor, stylesheet, showproglist, headingfontcolor, subheadingfontcolor, linkcolor, vlinkcolor, alinkcolor, groupfontcolor, tabledescfontcolor, fontsize5, dateformat, newtime, newpic, searchpic, printpic, backpic, listpic, watchlogins, displayrating, pageheader, pagefooter, usecustomheader, usecustomfooter, allowemail, emailpic, urlautoencode, enablespcode, nofreemailer, allowquestions, questionpic, faqemail, allowusercomments, usercommentpic, newcommentnotify, allowlists, allowsearch, enablefailednotify, timezone, loginlimit, enablehostresolve, searchcomments, searchquestions, showsummary, summarylength, progrestrict, ratecomments, footerfile, headerfile, printheader, printfooter, usemenubar, mincommentlength, minquestionlength, proginfopic, proginfowidth, proginfoheight, textareawidth, textareaheight, proginfoleft, proginfotop, helpwindowwidth, helpwindowheight, helpwindowleft, helpwindowtop, helppic, closepic, kbmode, enablekbrating, defsearchmethod, enablekeywordsearch, enablelanguageselector, faqsortmethod, kbsortmethod, showtimezone, showcurrtime, copyrightpos, copyrightbgcolor, subheadingbgcolor, actionbgcolor, headerfilepos, footerfilepos, newinfobgcolor, ascheader, useascheader, asclinelength, ascforcewrap, addbodytags, asclistmimetype, asclistcharset, userquestionanswermail, userquestionanswermode, userquestionautopublish, keywordsearchmode, questionrequireos, faqlistshortcuts, questionrequireversion, enablefaqnewdisplay, newfaqdisplaymethod, faqnewdisplaybgcolor, faqnewdisplayfontcolor, listallfaqmethod, enableshortcutbar, enablejumpboxes, subcatbgcolor, subcatfontcolor, displayrelated, htmllisttype, pagetoppic, attachpic, faqengine_hostname, faqlimitrelated, summaryintotallist, summarychars, ratingcomment, maxentries, hovercells, activcellcolor, ratingspublic, ratingcommentpublic) ";
		$sql .="VALUES (1, '$headingbg', '$bgcolor1', '$bgcolor2', '$bgcolor3', '$pagebg', '$tablewidth', '$fontface', '$fontsize1', '$fontsize2', '$fontsize3', '$fontsize4', '$fontcolor', '$stylesheet', $proglist, '$headingfontcolor', '$subheadingfontcolor', '$linkcolor', '$vlinkcolor', '$alinkcolor', '$groupfontcolor', '$tabledescfontcolor', '$fontsize5', '$dateformat', $newtime, '$newpic', '$searchpic', '$printpic', '$backpic', '$listpic', $watchlogins, $displayrating, '$customheader', '$customfooter', $usecustomheader, $usecustomfooter, $allowemail, '$emailpic', $urlautoencode, $enablespcode, $nofreemailer, $allowquestions, '$questionpic', '$faqemail', $allowusercomments, '$usercommentpic', $newcommentnotify, $allowlists, $allowsearch, $enablefailednotify, '$timezone', $loginlimit, $enablehostresolve, $searchcomments, $searchquestions, $showsummary, $summarylength, $progrestrict, $ratecomments, '$footerfile', '$headerfile', $printheader, $printfooter, $usemenubar, $input_mincomment, $input_minquestion, '$proginfopic', $proginfowidth, $proginfoheight, $textareawidth, $textareaheight, $proginfoleft, $proginfotop, $helpwindowwidth, $helpwindowheight, $helpwindowleft, $helpwindowtop, '$helppic', '$closepic', '$kbmode', $enablekbrating, $defsearchmethod, $enablekeywordsearch, $enablelanguageselector, $faqsortmethod, $kbsortmethod, $showtimezone, $showcurrtime, $copyrightpos, '$copyrightbgcolor', '$subheadingbgcolor', '$actionbgcolor', $headerfilepos, $footerfilepos, '$newinfobgcolor', '$ascheader', $useascheader, $asclinelength, $ascforcewrap, '$addbodytags', '$asclistmimetype', '$asclistcharset', $userquestionanswermail, $userquestionanswermode, $userquestionautopublish, $keywordsearchmode, $questionrequireos, $faqlistshortcuts, $questionrequireversion, $enablefaqnewdisplay, $newfaqdisplaymethod, '$faqnewdisplaybgcolor', '$faqnewdisplayfontcolor', $listallfaqmethod, $enableshortcutbar, $enablejumpboxes, '$subcatbgcolor', '$subcatfontcolor', $displayrelated, $htmllisttype, '$pagetoppic', '$attachpic', '$faqengine_hostname', $faqlimitrelated, $summaryintotallist, $summarychars, $ratingcomment, $maxentries, $hovercells, '$activcellcolor', $ratingspublic, $ratingcommentpublic)";
		if(!$result = faqe_db_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Unable to add layout to database.".faqe_db_error());
		if(isset($mods))
		{
    		while(list($null, $mod) = each($HTTP_POST_VARS["mods"]))
    		{
				$mod_query = "INSERT INTO ".$tableprefix."_failed_notify (usernr) VALUES ('$mod')";
    		   	if(!faqe_db_query($mod_query, $db))
				    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
			}
		}
		if(isset($rem_mods))
		{
			while(list($null, $mod) = each($HTTP_POST_VARS["rem_mods"]))
			{
				$rem_query = "DELETE FROM ".$tableprefix."_failed_notify WHERE usernr = '$mod'";
       			if(!faqe_db_query($rem_query,$db))
				    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
			}
		}
		echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
		echo "$l_settingsupdated";
		echo "</td></tr></table></td></tr></table>";
	}
	else
	{
		$sql = "UPDATE ".$tableprefix."_layout SET headingbg='$headingbg', bgcolor1='$bgcolor1', bgcolor2='$bgcolor2', bgcolor3='$bgcolor3', pagebg='$pagebg', tablewidth='$tablewidth', fontface='$fontface', ";
		$sql .="fontsize1='$fontsize1', fontsize2='$fontsize2', fontsize3='$fontsize3', fontsize4='$fontsize4', fontcolor='$fontcolor', stylesheet='$stylesheet', showproglist=$proglist, headingfontcolor='$headingfontcolor', ";
		$sql .="subheadingfontcolor='$subheadingfontcolor', linkcolor='$linkcolor', vlinkcolor='$vlinkcolor', alinkcolor='$alinkcolor', groupfontcolor='$groupfontcolor', tabledescfontcolor='$tabledescfontcolor', fontsize5='$fontsize5', dateformat='$dateformat', newtime=$newtime, newpic='$newpic', ";
		$sql .="searchpic='$searchpic', printpic='$printpic', backpic='$backpic', listpic='$listpic', watchlogins=$watchlogins, displayrating=$displayrating, ";
		$sql .="pageheader='$customheader', pagefooter='$customfooter', usecustomheader=$usecustomheader, usecustomfooter=$usecustomfooter, allowemail=$allowemail, emailpic='$emailpic', ";
		$sql .="urlautoencode=$urlautoencode, enablespcode=$enablespcode, nofreemailer=$nofreemailer, allowquestions=$allowquestions, questionpic='$questionpic', faqemail='$faqemail', allowusercomments=$allowusercomments, ";
		$sql .="usercommentpic='$usercommentpic', newcommentnotify=$newcommentnotify, allowlists=$allowlists, allowsearch=$allowsearch, enablefailednotify=$enablefailednotify, loginlimit=$loginlimit, timezone='$timezone', enablehostresolve=$enablehostresolve, ";
		$sql .="searchcomments=$searchcomments, searchquestions=$searchquestions, showsummary=$showsummary, summarylength=$summarylength, progrestrict=$progrestrict, ratecomments=$ratecomments, footerfile='$footerfile', headerfile='$headerfile', ";
		$sql .="printheader=$printheader, printfooter=$printfooter, usemenubar=$usemenubar, mincommentlength=$input_mincomment, minquestionlength=$input_minquestion, proginfopic='$proginfopic', ";
		$sql .="proginfowidth=$proginfowidth, proginfoheight=$proginfoheight, textareawidth=$textareawidth, textareaheight=$textareaheight, proginfoleft=$proginfoleft, proginfotop=$proginfotop, enablekbrating=$enablekbrating, ";
		$sql .="helpwindowwidth=$helpwindowwidth, helpwindowheight=$helpwindowheight, helpwindowleft=$helpwindowleft, helpwindowtop=$helpwindowtop, helppic='$helppic', closepic='$closepic', kbmode='$kbmode', defsearchmethod=$defsearchmethod, ";
		$sql .="enablekeywordsearch=$enablekeywordsearch, enablelanguageselector=$enablelanguageselector, faqsortmethod=$faqsortmethod, kbsortmethod=$kbsortmethod, showtimezone=$showtimezone, showcurrtime=$showcurrtime, copyrightpos=$copyrightpos, copyrightbgcolor='$copyrightbgcolor', ";
		$sql .="subheadingbgcolor='$subheadingbgcolor', actionbgcolor='$actionbgcolor', headerfilepos=$headerfilepos, footerfilepos=$footerfilepos, newinfobgcolor='$newinfobgcolor', ascheader='$ascheader', useascheader=$useascheader, asclinelength=$asclinelength, ";
		$sql .="ascforcewrap=$ascforcewrap, addbodytags='$addbodytags', asclistmimetype='$asclistmimetype', asclistcharset='$asclistcharset', userquestionanswermail=$userquestionanswermail, userquestionanswermode=$userquestionanswermode, userquestionautopublish=$userquestionautopublish, ";
		$sql .="keywordsearchmode=$keywordsearchmode, questionrequireos=$questionrequireos, faqlistshortcuts=$faqlistshortcuts, questionrequireversion=$questionrequireversion, newfaqdisplaymethod=$newfaqdisplaymethod, enablefaqnewdisplay=$enablefaqnewdisplay, ";
		$sql .="faqnewdisplaybgcolor='$faqnewdisplaybgcolor', faqnewdisplayfontcolor='$faqnewdisplayfontcolor', listallfaqmethod=$listallfaqmethod, enableshortcutbar=$enableshortcutbar, enablejumpboxes=$enablejumpboxes, subcatbgcolor='$subcatbgcolor', subcatfontcolor='$subcatfontcolor', ";
		$sql .="displayrelated=$displayrelated, htmllisttype=$htmllisttype, pagetoppic='$pagetoppic', attachpic='$attachpic', faqengine_hostname='$faqengine_hostname', faqlimitrelated=$faqlimitrelated, summaryintotallist=$summaryintotallist, summarychars=$summarychars, ratingcomment=$ratingcomment, ";
		$sql .="maxentries=$maxentries, hovercells=$hovercells, activcellcolor='$activcellcolor', ratingspublic=$ratingspublic, ratingcommentpublic=$ratingcommentpublic ";
		$sql .="WHERE (layoutnr=1)";
		if(!$result = faqe_db_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.".faqe_db_error());
		if(isset($mods))
		{
    		while(list($null, $mod) = each($HTTP_POST_VARS["mods"]))
    		{
				$mod_query = "INSERT INTO ".$tableprefix."_failed_notify (usernr) VALUES ('$mod')";
    		   	if(!faqe_db_query($mod_query, $db))
				    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
			}
		}
		if(isset($rem_mods))
		{
			while(list($null, $mod) = each($HTTP_POST_VARS["rem_mods"]))
			{
				$rem_query = "DELETE FROM ".$tableprefix."_failed_notify WHERE usernr = '$mod'";
       			if(!faqe_db_query($rem_query,$db))
				    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
			}
		}
		echo "<tr bgcolor=\"#c0c0c0\" align=\"center\"><td>";
		echo "$l_settingsupdated";
		echo "</td></tr></table></td></tr></table>";
		echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_editsettings</a></div>";
	}
	include('./trailer.php');
	exit;
}
$sql="select * from ".$tableprefix."_layout where (layoutnr=1)";
if(!$result = faqe_db_query($sql, $db))
    die("Could not connect to the database.");
if (!$myrow = faqe_db_fetch_array($result))
{
	$new=1;
	$headingbg="#94AAD6";
	$subheadingbgcolor="#94AAD6";
	$actionbgcolor="#94AAD6";
	$newinfobgcolor="#94AAD6";
	$bgcolor1="#000000";
	$bgcolor2="#CCCCCC";
	$bgcolor3="#C0C0C0";
	$pagebg="#C0C0C0";
	$copyrightbgcolor="#C0C0C0";
	$tablewidth="98%";
	$fontface="Verdana, Geneva, Arial, Helvetica, sans-serif";
	$fontsize1="1";
	$fontsize2="2";
	$fontsize3="+1";
	$fontsize4="-2";
	$fontsize5="2";
	$fontcolor="#000000";
	$headingfontcolor="#FFF0C0";
	$subheadingfontcolor="#F0F0F0";
	$linkcolor="#CC0000";
	$vlinkcolor="#CC0000";
	$alinkcolor="#0000CC";
	$stylesheet="faq.css";
	$showproglist=1;
	$groupfontcolor="#2C2C2C";
	$tabledescfontcolor="#2C2C2C";
	$dateformat="j.m.Y";
	$newtime=7;
	$newpic="gfx/new.gif";
	$searchpic="gfx/search.gif";
	$printpic="gfx/print.gif";
	$backpic="gfx/back.gif";
	$listpic="gfx/list.gif";
	$watchlogins=1;
	$displayrating=1;
	$pageheader="";
	$pagefooter="";
	$usecustomheader=1;
	$usecustomfooter=1;
	$allowemail = 1;
	$emailpic="gfx/email.gif";
	$urlautoencode=1;
	$enablespcode=1;
	$nofreemailer=0;
	$allowquestions=1;
	$questionpic="gfx/question.gif";
	$faqemail="faqengine@localhost";
	$allowusercomments=1;
	$usercommentpic="gfx/comment.gif";
	$newcommentnotify=1;
	$allowlists=1;
	$allowsearch=1;
	$enablefailednotify=0;
	$timezone="GMT+1";
	$loginlimit=0;
	$enablehostresolve=1;
	$searchcomments=1;
	$searchquestions=1;
	$showsummary=1;
	$summarylength=40;
	$progrestrict=1;
	$ratecomments=1;
	$footerfile="example_footer.php";
	$headerfile="example_head.php";
	$printheader=0;
	$printfooter=0;
	$usemenubar=1;
	$mincommentlength=0;
	$minquestionlength=0;
	$proginfopic="gfx/info.gif";
	$proginfowidth=380;
	$proginfoheight=420;
	$textareawidth=30;
	$textareaheight=6;
	$proginfoleft=20;
	$proginfotop=20;
	$helpwindowwidth=380;
	$helpwindowheight=420;
	$helpwindowleft=20;
	$helpwindowtop=20;
	$helppic="gfx/help.gif";
	$closepic="gfx/close.gif";
	$kbmode="wizard";
	$enablekbrating=1;
	$defsearchmethod=0;
	$enablekeywordsearch=1;
	$enablelanguageselector=0;
	$faqsortmethod=0;
	$kbsortmethod=0;
	$showtimezone=1;
	$showcurrtime=0;
	$copyrightpos=0;
	$headerfilepos=0;
	$footerfilepos=0;
	$ascheader="";
	$useascheader=0;
	$asclinelength=0;
	$ascforcewrap=0;
	$addbodytags="";
	$asclistmimetype=0;
	$asclistcharset="iso-8859-1";
	$userquestionanswermail=0;
	$userquestionanswermode=0;
	$userquestionautopublish=0;
	$keywordsearchmode=0;
	$questionrequireos=1;
	$faqlistshortcuts=0;
	$questionrequireversion=1;
	$faqnewdisplaymethod=0;
	$enablefaqnewdisplay=0;
	$faqnewdisplaybgcolor="#94AAD6";
	$faqnewdisplayfontcolor="#000000";
	$listallfaqmethod = 0;
	$enableshortcutbar=0;
	$enablejumpboxes=0;
	$subcatbgcolor="#e0e0e0";
	$subcatfontcolor="#000000";
	$displayrelated=0;
	$htmllisttype=0;
	$pagetoppic="gfx/top.gif";
	$attachpic="gfx/attach.gif";
	$faqengine_hostname="localhost";
	$faqlimitrelated=1;
	$summaryintotallist=0;
	$summarychars=40;
	$ratingcomment=0;
	$maxentries=0;
	$hovercells=0;
	$activcellcolor="#ffff72";
	$ratingspublic=0;
	$ratingcommentpublic=0;
}
else
{
	$new=0;
	$headingbg=$myrow["headingbg"];
	$bgcolor1=$myrow["bgcolor1"];
	$bgcolor2=$myrow["bgcolor2"];
	$bgcolor3=$myrow["bgcolor3"];
	$pagebg=$myrow["pagebg"];
	$tablewidth=$myrow["tablewidth"];
	$fontface=$myrow["fontface"];
	$fontsize1=$myrow["fontsize1"];
	$fontsize2=$myrow["fontsize2"];
	$fontsize3=$myrow["fontsize3"];
	$fontsize4=$myrow["fontsize4"];
	$fontsize5=$myrow["fontsize5"];
	$fontcolor=$myrow["fontcolor"];
	$stylesheet=$myrow["stylesheet"];
	$showproglist=$myrow["showproglist"];
	$headingfontcolor=$myrow["headingfontcolor"];
	$subheadingfontcolor=$myrow["subheadingfontcolor"];
	$linkcolor=$myrow["linkcolor"];
	$vlinkcolor=$myrow["vlinkcolor"];
	$alinkcolor=$myrow["alinkcolor"];
	$groupfontcolor=$myrow["groupfontcolor"];
	$tabledescfontcolor=$myrow["tabledescfontcolor"];
	$dateformat=$myrow["dateformat"];
	$newtime=$myrow["newtime"];
	$newpic=$myrow["newpic"];
	$searchpic=$myrow["searchpic"];
	$printpic=$myrow["printpic"];
	$backpic=$myrow["backpic"];
	$listpic=$myrow["listpic"];
	$watchlogins=$myrow["watchlogins"];
	$displayrating=$myrow["displayrating"];
	$pageheader=$myrow["pageheader"];
	$pagefooter=$myrow["pagefooter"];
	$usecustomheader=$myrow["usecustomheader"];
	$usecustomfooter=$myrow["usecustomfooter"];
	$allowemail=$myrow["allowemail"];
	$emailpic=$myrow["emailpic"];
	$urlautoencode=$myrow["urlautoencode"];
	$enablespcode=$myrow["enablespcode"];
	$nofreemailer=$myrow["nofreemailer"];
	$allowquestions=$myrow["allowquestions"];
	$questionpic=$myrow["questionpic"];
	$faqemail=$myrow["faqemail"];
	$allowusercomments=$myrow["allowusercomments"];
	$usercommentpic=$myrow["usercommentpic"];
	$newcommentnotify=$myrow["newcommentnotify"];
	$allowlists=$myrow["allowlists"];
	$allowsearch=$myrow["allowsearch"];
	$enablefailednotify=$myrow["enablefailednotify"];
	$loginlimit=$myrow["loginlimit"];
	$timezone=$myrow["timezone"];
	$enablehostresolve=$myrow["enablehostresolve"];
	$searchcomments=$myrow["searchcomments"];
	$searchquestions=$myrow["searchquestions"];
	$showsummary=$myrow["showsummary"];
	$summarylength=$myrow["summarylength"];
	$progrestrict=$myrow["progrestrict"];
	$ratecomments=$myrow["ratecomments"];
	$footerfile=$myrow["footerfile"];
	$headerfile=$myrow["headerfile"];
	$printheader=$myrow["printheader"];
	$printfooter=$myrow["printfooter"];
	$usemenubar=$myrow["usemenubar"];
	$mincommentlength=$myrow["mincommentlength"];
	$minquestionlength=$myrow["minquestionlength"];
	$proginfopic=$myrow["proginfopic"];
	$proginfowidth=$myrow["proginfowidth"];
	$proginfoheight=$myrow["proginfoheight"];
	$proginfoleft=$myrow["proginfoleft"];
	$proginfotop=$myrow["proginfotop"];
	$textareawidth=$myrow["textareawidth"];
	$textareaheight=$myrow["textareaheight"];
	$helpwindowwidth=$myrow["helpwindowwidth"];
	$helpwindowheight=$myrow["helpwindowheight"];
	$helpwindowleft=$myrow["helpwindowleft"];
	$helpwindowtop=$myrow["helpwindowtop"];
	$helppic=$myrow["helppic"];
	$closepic=$myrow["closepic"];
	$kbmode=$myrow["kbmode"];
	$enablekbrating=$myrow["enablekbrating"];
	$defsearchmethod=$myrow["defsearchmethod"];
	$enablekeywordsearch=$myrow["enablekeywordsearch"];
	$enablelanguageselector=$myrow["enablelanguageselector"];
	$faqsortmethod=$myrow["faqsortmethod"];
	$kbsortmethod=$myrow["kbsortmethod"];
	$showtimezone=$myrow["showtimezone"];
	$showcurrtime=$myrow["showcurrtime"];
	$copyrightpos=$myrow["copyrightpos"];
	$copyrightbgcolor=$myrow["copyrightbgcolor"];
	$subheadingbgcolor=$myrow["subheadingbgcolor"];
	$actionbgcolor=$myrow["actionbgcolor"];
	$headerfilepos=$myrow["headerfilepos"];
	$footerfilepos=$myrow["footerfilepos"];
	$newinfobgcolor=$myrow["newinfobgcolor"];
	$ascheader=$myrow["ascheader"];
	$useascheader=$myrow["useascheader"];
	$asclinelength=$myrow["asclinelength"];
	$ascforcewrap=$myrow["ascforcewrap"];
	$addbodytags=$myrow["addbodytags"];
	$asclistmimetype=$myrow["asclistmimetype"];
	$asclistcharset=$myrow["asclistcharset"];
	$userquestionanswermail=$myrow["userquestionanswermail"];
	$userquestionanswermode=$myrow["userquestionanswermode"];
	$userquestionautopublish=$myrow["userquestionautopublish"];
	$keywordsearchmode=$myrow["keywordsearchmode"];
	$questionrequireos=$myrow["questionrequireos"];
	$faqlistshortcuts=$myrow["faqlistshortcuts"];
	$questionrequireversion=$myrow["questionrequireversion"];
	$faqnewdisplaymethod=$myrow["newfaqdisplaymethod"];
	$enablefaqnewdisplay=$myrow["enablefaqnewdisplay"];
	$faqnewdisplaybgcolor=$myrow["faqnewdisplaybgcolor"];
	$faqnewdisplayfontcolor=$myrow["faqnewdisplayfontcolor"];
	$listallfaqmethod=$myrow["listallfaqmethod"];
	$enableshortcutbar=$myrow["enableshortcutbar"];
	$enablejumpboxes=$myrow["enablejumpboxes"];
	$subcatbgcolor=$myrow["subcatbgcolor"];
	$subcatfontcolor=$myrow["subcatfontcolor"];
	$displayrelated=$myrow["displayrelated"];
	$htmllisttype=$myrow["htmllisttype"];
	$pagetoppic=$myrow["pagetoppic"];
	$attachpic=$myrow["attachpic"];
	$faqengine_hostname=$myrow["faqengine_hostname"];
	$faqlimitrelated=$myrow["faqlimitrelated"];
	$summaryintotallist=$myrow["summaryintotallist"];
	$summarychars=$myrow["summarychars"];
	$ratingcomment=$myrow["ratingcomment"];
	$maxentries=$myrow["maxentries"];
	$hovercells=$myrow["hovercells"];
	$activcellcolor=$myrow["activcellcolor"];
	$ratingspublic=$myrow["ratingspublic"];
	$ratingcommentpublic=$myrow["ratingcommentpublic"];
}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr bgcolor="#C0C0C0">
<form name="myform" ENCTYPE="multipart/form-data" method="post" action="<?php echo $PHP_SELF?>">
<?php
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="colorfield" value="">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="new" value="<?php echo $new?>">
<input type="hidden" name="mode" value="update">
<td align="left" colspan="2"><b><?php echo $l_layout_settings?></b></td></tr>
<tr bgcolor="#E0E0E0"><td align="left" colspan="2"><b><?php echo $l_global?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right" width="30%"><?php echo $l_stylesheet?>:</td>
<td><input name="stylesheet" value="<?php echo $stylesheet?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_tablewidth?>:</td>
<td><input name="tablewidth" value="<?php echo $tablewidth?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_pagebgcolor?>:</td>
<td><table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="pagebg" value="<?php echo $pagebg?>" onchange="pagebgprev.bgColor=document.myform.pagebg.value">
<input type="button" onclick="color_picker('pagebg')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="pagebgprev" bgcolor="<?php echo $pagebg?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_textcolor?>:</td>
<td><table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="fontcolor" value="<?php echo $fontcolor?>" onchange="fontcolorprev.bgColor=document.myform.fontcolor.value">
<input type="button" onclick="color_picker('fontcolor')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="fontcolorprev" bgcolor="<?php echo $fontcolor?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_fontface?>:</td>
<td><input name="fontface" size="50" value="<?php echo $fontface?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_fontsize1?>:</td>
<td><input name="fontsize1" value="<?php echo $fontsize1?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_fontsize4?>:</td>
<td><input name="fontsize4" value="<?php echo $fontsize4?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_linkcolor?>:</td>
<td><table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="linkcolor" value="<?php echo $linkcolor?>" onchange="linkcolorprev.bgColor=document.myform.linkcolor.value">
<input type="button" onclick="color_picker('linkcolor')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="linkcolorprev" bgcolor="<?php echo $linkcolor?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_vlinkcolor?>:</td>
<td><table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="vlinkcolor" value="<?php echo $vlinkcolor?>" onchange="vlinkcolorprev.bgColor=document.myform.vlinkcolor.value">
<input type="button" onclick="color_picker('vlinkcolor')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="vlinkcolorprev" bgcolor="<?php echo $vlinkcolor?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_alinkcolor?>:</td>
<td><table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="alinkcolor" value="<?php echo $alinkcolor?>" onchange="alinkcolorprev.bgColor=document.myform.alinkcolor.value">
<input type="button" onclick="color_picker('alinkcolor')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="alinkcolorprev" bgcolor="<?php echo $alinkcolor?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_customheader?>:<br>
<input name="enablecustomheader" value="1" type="checkbox"
<?php if($usecustomheader==1) echo " checked"?>> <?php echo $l_enable?><br>
<input type="checkbox" value="1" name="doheaderprint" <?php if ($printheader==1) echo "checked"?>> <?php echo $l_useatprint?>
</td>
<td><?php echo htmlentities($pageheader)?><br><hr noshade color="#000000" size="1">
<input type="file" name="customheaderfile"><br>
<input type="checkbox" value="1" name="clearcustomheader"><?php echo $l_clear?><br>
<hr noshade color="#000000" size="1">
<?php echo $l_includefile?>: <input type="text" size="30" maxlength="240" name="headerfile" value="<?php echo $headerfile?>"><br>
<input type="radio" name="headerfilepos" value="0" <?php if ($headerfilepos==0) echo "checked"?>> <?php echo $l_beforecustomheader?><br>
<input type="radio" name="headerfilepos" value="1" <?php if ($headerfilepos==1) echo "checked"?>> <?php echo $l_aftercustomheader?></td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_customfooter?>:<br>
<input name="enablecustomfooter" value="1" type="checkbox"
<?php if($usecustomfooter==1) echo " checked"?>> <?php echo $l_enable?><br>
<input type="checkbox" value="1" name="dofooterprint" <?php if ($printfooter==1) echo "checked"?>> <?php echo $l_useatprint?>
</td>
<td><?php echo htmlentities($pagefooter)?><br><hr noshade color="#000000" size="1">
<input type="file" name="customfooterfile"><br>
<input type="checkbox" value="1" name="clearcustomfooter"><?php echo $l_clear?><br><hr noshade color="#000000" size="1">
<?php echo $l_includefile?>: <input type="text" size="30" maxlength="240" name="footerfile" value="<?php echo $footerfile?>"><br>
<input type="radio" name="footerfilepos" value="0" <?php if ($footerfilepos==0) echo "checked"?>> <?php echo $l_beforecustomfooter?><br>
<input type="radio" name="footerfilepos" value="1" <?php if ($footerfilepos==1) echo "checked"?>> <?php echo $l_aftercustomfooter?>
</td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_addbodytags?>:</td>
<td align="left"><input type="text" name="addbodytags" value="<?php echo htmlentities($addbodytags)?>" size="40" maxlength="240"></td></tr>
<tr bgcolor="#E0E0E0"><td align="left" colspan="2"><b><?php echo $l_headings?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_bgcolor?>:</td>
<td><table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="headingbg" value="<?php echo $headingbg?>" onchange="headingbgprev.bgColor=document.myform.headingbg.value">
<input type="button" onclick="color_picker('headingbg')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="headingbgprev" bgcolor="<?php echo $headingbg?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_fontcolor?>:</td>
<td><table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="headingfontcolor" value="<?php echo $headingfontcolor?>" onchange="headingfontcolorprev.bgColor=document.myform.headingfontcolor.value">
<input type="button" onclick="color_picker('headingfontcolor')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="headingfontcolorprev" bgcolor="<?php echo $headingfontcolor?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input name="fontsize3" value="<?php echo $fontsize3?>"></td></tr>
<tr bgcolor="#E0E0E0"><td align="left" colspan="2"><b><?php echo $l_subheading?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_bgcolor?>:</td>
<td><table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="subheadingbgcolor" value="<?php echo $subheadingbgcolor?>" onchange="subheadingbgcolorprev.bgColor=document.myform.subheadingbgcolor.value">
<input type="button" onclick="color_picker('subheadingbgcolor')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="subheadingbgcolorprev" bgcolor="<?php echo $subheadingbgcolor?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_fontcolor?>:</td>
<td><table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="subheadingfontcolor" value="<?php echo $subheadingfontcolor?>" onchange="subheadingfontcolorprev.bgColor=document.myform.subheadingfontcolor.value">
<input type="button" onclick="color_picker('subheadingfontcolor')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="subheadingfontcolorprev" bgcolor="<?php echo $subheadingfontcolor?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input name="fontsize2" value="<?php echo $fontsize2?>"></td></tr>
<tr bgcolor="#E0E0E0"><td align="left" colspan="2"><b><?php echo $l_grouping?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_bgcolor?>:</td>
<td><table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="bgcolor3" value="<?php echo $bgcolor3?>" onchange="bgcolor3prev.bgColor=document.myform.bgcolor3.value">
<input type="button" onclick="color_picker('bgcolor3')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="bgcolor3prev" bgcolor="<?php echo $bgcolor3?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_fontcolor?>:</td>
<td><table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="groupfontcolor" value="<?php echo $groupfontcolor?>" onchange="groupfontcolorprev.bgColor=document.myform.groupfontcolor.value">
<input type="button" onclick="color_picker('groupfontcolor')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="groupfontcolorprev" bgcolor="<?php echo $groupfontcolor?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input name="fontsize5" value="<?php echo $fontsize5?>"></td></tr>
<tr bgcolor="#E0E0E0"><td align="left" colspan="2"><b><?php echo $l_subcategories?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_bgcolor?>:</td>
<td><table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="subcatbgcolor" value="<?php echo $subcatbgcolor?>" onchange="subcatbgcolorprev.bgColor=document.myform.subcatbgcolor.value">
<input type="button" onclick="color_picker('subcatbgcolor')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="subcatbgcolorprev" bgcolor="<?php echo $subcatbgcolor?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_fontcolor?>:</td>
<td><table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="subcatfontcolor" value="<?php echo $subcatfontcolor?>" onchange="subcatfontcolorprev.bgColor=document.myform.subcatfontcolor.value">
<input type="button" onclick="color_picker('subcatfontcolor')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="subcatfontcolorprev" bgcolor="<?php echo $subcatfontcolor?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#E0E0E0"><td align="left" colspan="2"><b><?php echo $l_tableheading?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_fontcolor?>:</td>
<td><table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="tabledescfontcolor" value="<?php echo $tabledescfontcolor?>" onchange="tabledescfontcolorprev.bgColor=document.myform.tabledescfontcolor.value">
<input type="button" onclick="color_picker('tabledescfontcolor')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="tabledescfontcolorprev" bgcolor="<?php echo $tabledescfontcolor?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#E0E0E0"><td align="left" colspan="2"><b><?php echo $l_tablebg?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_bgcolor?> 1:</td>
<td><table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="bgcolor1" value="<?php echo $bgcolor1?>" onchange="bgcolor1prev.bgColor=document.myform.bgcolor1.value">
<input type="button" onclick="color_picker('bgcolor1')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="bgcolor1prev" bgcolor="<?php echo $bgcolor1?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_bgcolor?> 2:</td>
<td><table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="bgcolor2" value="<?php echo $bgcolor2?>" onchange="bgcolor2prev.bgColor=document.myform.bgcolor2.value">
<input type="button" onclick="color_picker('bgcolor2')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="bgcolor2prev" bgcolor="<?php echo $bgcolor2?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#E0E0E0"><td align="left" colspan="2"><b><?php echo $l_actionline?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_bgcolor?>:</td>
<td><table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="actionbgcolor" value="<?php echo $actionbgcolor?>" onchange="actionbgcolorprev.bgColor=document.myform.actionbgcolor.value">
<input type="button" onclick="color_picker('actionbgcolor')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="actionbgcolorprev" bgcolor="<?php echo $actionbgcolor?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#E0E0E0"><td align="left" colspan="2"><b><?php echo $l_newinfoline?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_bgcolor?>:</td>
<td><table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="newinfobgcolor" value="<?php echo $newinfobgcolor?>" onchange="newinfobgcolorprev.bgColor=document.myform.newsinfobgcolor.value">
<input type="button" onclick="color_picker('newinfobgcolor')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="newinfobgcolorprev" bgcolor="<?php echo $newinfobgcolor?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#E0E0E0"><td align="left" colspan="2"><b><?php echo $l_graphics?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_newpic?>:</td>
<td><input name="newpic" value="<?php echo $newpic?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_searchpic?>:</td>
<td><input name="searchpic" value="<?php echo $searchpic?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_printpic?>:</td>
<td><input name="printpic" value="<?php echo $printpic?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_backpic?>:</td>
<td><input name="backpic" value="<?php echo $backpic?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_listpic?>:</td>
<td><input name="listpic" value="<?php echo $listpic?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_emailpic?>:</td>
<td><input name="emailpic" value="<?php echo $emailpic?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_questionpic?>:</td>
<td><input name="questionpic" value="<?php echo $questionpic?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_usercommentpic?>:</td>
<td><input name="usercommentpic" value="<?php echo $usercommentpic?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_proginfopic?>:</td>
<td><input name="proginfopic" value="<?php echo $proginfopic?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_helppic?>:</td>
<td><input name="helppic" value="<?php echo $helppic?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_closepic?>:</td>
<td><input name="closepic" value="<?php echo $closepic?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_pagetoppic?>:</td>
<td><input name="pagetoppic" value="<?php echo $pagetoppic?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_attachement?>:</td>
<td><input name="attachpic" value="<?php echo $attachpic?>"></td></tr>
<tr bgcolor="#E0E0E0"><td align="left" colspan="2"><b><?php echo $l_copyrightfooter?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_bgcolor?>:</td><td align="left">
<table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="copyrightbgcolor" value="<?php echo $copyrightbgcolor?>" onchange="copyrightbgcolorprev.bgColor=document.myform.copyrightbgcolor.value">
<input type="button" onclick="color_picker('copyrightbgcolor')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="copyrightbgcolorprev" bgcolor="<?php echo $copyrightbgcolor?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_position?>:</td><td align="left">
<input type="radio" name="copyrightpos" value="1" <?php if($copyrightpos==1) echo "checked"?>><?php echo $l_beforefooter?><br>
<input type="radio" name="copyrightpos" value="0" <?php if($copyrightpos==0) echo "checked"?>><?php echo $l_afterfooter?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td><input type="checkbox" name="enabletimezone" value="1" <?php if($showtimezone==1) echo "checked"?>> <?php echo $l_showtimezone?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td><input type="checkbox" name="enablecurrenttime" value="1" <?php if($showcurrtime==1) echo "checked"?>> <?php echo $l_showcurrtime?></td></tr>
<tr bgcolor="#E0E0E0"><td align="left" colspan="2"><b><?php echo $l_asclist?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_asclinelength?>:</td>
<td><input name="asclinelength" value="<?php echo $asclinelength?>" size="4" maxlength="4"> <?php echo $l_characters?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td><input type="checkbox" name="forcewrap" value="1" <?php if($ascforcewrap==1) echo "checked"?>>
<?php echo $l_forcewrap?></td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_ascheader?>:<br>
<input name="enableascheader" value="1" type="checkbox"
<?php if($useascheader==1) echo " checked"?>> <?php echo $l_enable?></td>
<td><?php echo $ascheader?><br><hr noshade color="#000000" size="1">
<input type="file" name="ascheaderfile"><br>
<input type="checkbox" value="1" name="clearascheader"><?php echo $l_clear?></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_mimetype?>:</td>
<td><select name="asclistmimetype">
<?php
for($i=0;$i<count($avail_mimetypes);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$asclistmimetype)
		echo " selected";
	echo ">".$avail_mimetypes[$i]."</option>";
}
?>
</select></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_asclistcharset?>:</td>
<td><input type="text" name="asclistcharset" value="<?php echo $asclistcharset?>" size="40" maxlength="80"></td></tr>
<tr bgcolor="#e0e0e0"><td align="left" colspan="2"><b><?php echo $l_faqnewdisplay?></b></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td><input type="checkbox" name="dofaqnewdisplay" value="1" <?php if($enablefaqnewdisplay==1) echo "checked"?>>
<?php echo $l_activateselectionbox?></td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_displaymethod?>:</td>
<td>
<?php
for($i=0;$i<count($l_faqnewdisplaymethods);$i++)
{
	echo "<input type=\"radio\" name=\"newfaqdisplaymethod\" value=\"$i\"";
	if($faqnewdisplaymethod==$i)
		echo " checked";
	echo "> ".$l_faqnewdisplaymethods[$i]."<br>";
}
?>
</td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_markedbgcolor?>:</td><td>
<table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="faqnewdisplaybgcolor" value="<?php echo $faqnewdisplaybgcolor?>" onchange="faqnewdisplaybgcolorprev.bgColor=document.myform.faqnewdisplaybgcolor.value">
<input type="button" onclick="color_picker('faqnewdisplaybgcolor')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="faqnewdisplaybgcolorprev" bgcolor="<?php echo $faqnewdisplaybgcolor?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_markedfontcolor?>:</td><td>
<table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="faqnewdisplayfontcolor" value="<?php echo $faqnewdisplayfontcolor?>" onchange="faqnewdisplayfontcolorprev.bgColor=document.myform.faqnewdisplayfontcolor.value">
<input type="button" onclick="color_picker('faqnewdisplayfontcolor')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="faqnewdisplayfontcolorprev" bgcolor="<?php echo $faqnewdisplayfontcolor?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#e0e0e0"><td align="left" colspan="2"><b><?php echo $l_hovercells?></b></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td><input type="checkbox" name="enablehover" <?php if($hovercells==1) echo " checked"?>> <?php echo $l_hovercells?></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_activcellcolor?>:</td><td>
<table bgcolor="#000000" cellspacing="2" width="100%"><tr><td bgcolor="#cccccc" width="90%">
<input name="activcellcolor" value="<?php echo $activcellcolor?>" onchange="activcellcolorprev.bgColor=document.myform.activcellcolor.value">
<input type="button" onclick="color_picker('activcellcolor')" value="<?php echo $l_choose?>"></td>
<td width="10%" id="activcellcolorprev" bgcolor="<?php echo $activcellcolor?>">&nbsp;</td></tr></table>
</td></tr>
<tr bgcolor="#C0C0C0"><td align="left" colspan="2"><b><?php echo $l_totallist?></b></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td><input type="checkbox" name="totalsummary" value="1" <?php if($summaryintotallist==1) echo "checked"?>>
<?php echo $l_showsummary?></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_summarylength?>:</td><td>
<input type="text" name="summarychars" size="2" maxlength="2" value="<?php echo $summarychars?>"><?php echo $l_characters?></td></tr>
<tr bgcolor="#C0C0C0"><td align="left" colspan="2"><b><?php echo $l_textareas?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_width?>:</td>
<td><input name="textareawidth" value="<?php echo $textareawidth?>" size="4" maxlength="4"> <?php echo $l_cols?></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_height?>:</td>
<td><input name="textareaheight" value="<?php echo $textareaheight?>" size="4" maxlength="4"> <?php echo $l_rows?></td></tr>
<tr bgcolor="#C0C0C0"><td align="left" colspan="2"><b><?php echo $l_proginfopopup?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_width?>:</td>
<td><input name="proginfowidth" value="<?php echo $proginfowidth?>" size="4" maxlength="4"> <?php echo $l_pixel?></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_height?>:</td>
<td><input name="proginfoheight" value="<?php echo $proginfoheight?>" size="4" maxlength="4"> <?php echo $l_pixel?></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_topoffset?>:</td>
<td><input name="proginfotop" value="<?php echo $proginfotop?>" size="4" maxlength="4"> <?php echo $l_pixel?></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_leftoffset?>:</td>
<td><input name="proginfoleft" value="<?php echo $proginfoleft?>" size="4" maxlength="4"> <?php echo $l_pixel?></td></tr>
<tr bgcolor="#C0C0C0"><td align="left" colspan="2"><b><?php echo $l_searchhelpwindow?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_width?>:</td>
<td><input name="helpwindowwidth" value="<?php echo $helpwindowwidth?>" size="4" maxlength="4"> <?php echo $l_pixel?></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_height?>:</td>
<td><input name="helpwindowheight" value="<?php echo $helpwindowheight?>" size="4" maxlength="4"> <?php echo $l_pixel?></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_topoffset?>:</td>
<td><input name="helpwindowtop" value="<?php echo $helpwindowtop?>" size="4" maxlength="4"> <?php echo $l_pixel?></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_leftoffset?>:</td>
<td><input name="helpwindowleft" value="<?php echo $helpwindowleft?>" size="4" maxlength="4"> <?php echo $l_pixel?></td></tr>
<tr bgcolor="#C0C0C0"><td align="left" colspan="2"><b><?php echo $l_kb?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_defmode?>:</td>
<td><input type="radio" name="kbmode" value="wizard" <?php if ($kbmode=="wizard") echo "checked"?>> <?php echo $l_wizard?><br>
<input type="radio" name="kbmode" value="search" <?php if ($kbmode=="search") echo "checked"?>> <?php echo $l_search?><br>
<input type="radio" name="kbmode" value="progs" <?php if ($kbmode=="progs") echo "checked"?>> <?php echo $l_proglist?>
</td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="dokbrating" value="1" type="checkbox"
<?php if($enablekbrating==1) echo " checked"?>> <?php echo $l_kbrating?></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_kbsortmethod?>:</td><td align="left">
<input type="radio" name="kbsortmethod" value="0" <?php if ($kbsortmethod==0) echo "checked"?>><?php echo $l_faqsortbydate?><br>
<input type="radio" name="kbsortmethod" value="1" <?php if ($kbsortmethod==1) echo "checked"?>><?php echo $l_faqsortgiven?><br>
<input type="radio" name="kbsortmethod" value="2" <?php if ($kbsortmethod==2) echo "checked"?>><?php echo $l_faqsortalpha?>
</td></tr>
<tr bgcolor="#C0C0C0"><td align="left" colspan="2"><b><?php echo $l_misc_settings?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_dateformat?>:</td>
<td><input name="dateformat" value="<?php echo $dateformat?>"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_servertimezone?>:</td>
<td><input name="timezone" value="<?php echo $timezone?>" size="10" maxlength="10"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_newtime?>:</td>
<td><input name="newtime" value="<?php echo $newtime?>" size="4" maxlength="4"> <?php echo $l_days?></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_faqemailadr?>:</td>
<td><input name="faqemail" value="<?php echo $faqemail?>" size="30" maxlength="140"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_faqhostname?>:</td>
<td><input name="faqengine_hostname" value="<?php echo $faqengine_hostname?>" size="30" maxlength="140"></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_maxentries?></td>
<td><input type="text" name="maxentries" value="<?php echo $maxentries?>" size="5" maxlength="5"></td></tr>
<tr bgcolor="#C0C0C0"><td align="left" colspan="2"><b><?php echo $l_search?></b></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="enablesearch" value="1" type="checkbox"
<?php if($allowsearch==1) echo " checked"?>> <?php echo $l_allowsearch?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="dorestrict" value="1" type="checkbox"
<?php if($progrestrict==1) echo " checked"?>> <?php echo $l_progrestrict?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="enablesearchcomments" value="1" type="checkbox"
<?php if($searchcomments==1) echo " checked"?>> <?php echo $l_searchcomments?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="enablesearchquestions" value="1" type="checkbox"
<?php if($searchquestions==1) echo " checked"?>> <?php echo $l_searchquestions?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="enablesummary" value="1" type="checkbox"
<?php if($showsummary==1) echo " checked"?>> <?php echo $l_showsummary?></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_summarylength?>:</td>
<td><input name="summarylength" value="<?php echo $summarylength?>" size="2" maxlength="2"> <?php echo $l_characters?></td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_defsearchmethod?>:</td>
<td><input type="radio" name="defsearchmethod" value="0" <?php if($defsearchmethod==0) echo "checked"?>> <?php echo $l_search_keywords?><br>
<input type="radio" name="defsearchmethod" value="1" <?php if($defsearchmethod==1) echo "checked"?>> <?php echo $l_search_fulltext?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td><input type="checkbox" value="1" name="allowkeywordsearch" <?php if($enablekeywordsearch==1) echo "checked"?>>
<?php echo $l_enablekeywordsearch?></td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_keywordsearchmode?>:</td>
<td><input type="radio" name="keywordsearchmode" value="0" <?php if($keywordsearchmode==0) echo "checked"?>><?php echo $l_exactmatch?><br>
<input type="radio" name="keywordsearchmode" value="1" <?php if($keywordsearchmode==1) echo "checked"?>><?php echo $l_partialmatch?></td></tr>
<tr bgcolor="#C0C0C0"><td align="left" colspan="2"><b><?php echo $l_options?></b></td></tr>
<tr bgcolor="#e0e0e0"><td align="left" colspan="2"><b><?php echo $l_global?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_faqsortmethod?>:</td><td align="left">
<input type="radio" name="faqsortmethod" value="0" <?php if ($faqsortmethod==0) echo "checked"?>><?php echo $l_faqsortbydate?><br>
<input type="radio" name="faqsortmethod" value="1" <?php if ($faqsortmethod==1) echo "checked"?>><?php echo $l_faqsortgiven?><br>
<input type="radio" name="faqsortmethod" value="2" <?php if ($faqsortmethod==2) echo "checked"?>><?php echo $l_faqsortalpha?>
</td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_listallfaqmethod?>:</td><td align="left">
<?php
for($i=0;$i<count($l_listallfaqmethods);$i++)
{
	echo "<input type=\"radio\" name=\"listallfaqmethod\" value=\"$i\"";
	if($listallfaqmethod==$i)
		echo "checked";
	echo "> ".$l_listallfaqmethods[$i]."<br>";
}
?>
</td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input type="checkbox" name="useshortcutbar" value="1" <?php if ($enableshortcutbar==1) echo "checked"?>>
<?php echo $l_enableshortcutbar?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input type="checkbox" name="showlanguageselector" value="1" <?php if ($enablelanguageselector==1) echo "checked"?>>
<?php echo $l_showlanguageselector?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="enableemail" value="1" type="checkbox"
<?php if($allowemail==1) echo " checked"?>> <?php echo $l_allowemail?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left">
<input name="showproglist" value="1" type="checkbox"
<?php if($showproglist==1) echo " checked"?>> <?php echo $l_showproglist?></td>
</tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="dorating" value="1" type="checkbox"
<?php if($displayrating==1) echo " checked"?>> <?php echo $l_displayrating?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="ratingspub" value="1" type="checkbox"
<?php if($ratingspublic==1) echo " checked"?>> <?php echo $l_ratingspublic?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input type="checkbox" name="ratingcom" value="1" <?php if ($ratingcomment==1) echo "checked"?>>
<?php echo $l_ratingcomment?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="pubratecom" value="1" type="checkbox"
<?php if($ratingcommentpublic==1) echo " checked"?>> <?php echo $l_ratingcommentspublic?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="enablelists" value="1" type="checkbox"
<?php if($allowlists==1) echo " checked"?>> <?php echo $l_allowlists?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="allowjumpboxes" value="1" type="checkbox"
<?php if($enablejumpboxes==1) echo " checked"?>> <?php echo $l_enablejumpboxes?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="enablerelated" value="1" type="checkbox"
<?php if($displayrelated==1) echo " checked"?>> <?php echo $l_displayrelated?></td></tr>
<tr bgcolor="#e0e0e0"><td align="left" colspan="2"><b><?php echo $l_userquestions?></b></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="enablequestions" value="1" type="checkbox"
<?php if($allowquestions==1) echo " checked"?>> <?php echo $l_allowquestions?></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_minquestionlength?>:</td>
<td><input type="text" name="input_minquestion" value="<?php echo $minquestionlength?>" size="3" maxlength="3"> <?php echo $l_characters?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="sendanswermail" value="1" type="checkbox"
<?php if($userquestionanswermail==1) echo " checked"?>> <?php echo $l_userquestionanswermail?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="autopublishquestion" value="1" type="checkbox"
<?php if($userquestionautopublish==1) echo " checked"?>> <?php echo $l_autopublishquestion?></td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_userquestionanswermode?></td><td align="left">
<?php
	for($i=0;$i<count($l_userquestionanswermodes);$i++)
	{
		echo "<input type=\"radio\" name=\"userquestionanswermode\" value=\"$i\"";
		if($i==$userquestionanswermode)
			echo " checked";
		echo "> ".$l_userquestionanswermodes[$i]."<br>";
	}
?>
</td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td><input type="checkbox" name="questionosrequired" value="1" <?php if($questionrequireos==1) echo "checked"?>>
<?php echo $l_questionrequireos?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td><input type="checkbox" name="versionrequired" value="1" <?php if($questionrequireversion==1) echo "checked"?>>
<?php echo $l_questionrequireversion?></td></tr>
<tr bgcolor="#e0e0e0"><td align="left" colspan="2"><b><?php echo $l_usercomments?></b></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="enableusercomments" value="1" type="checkbox"
<?php if($allowusercomments==1) echo " checked"?>> <?php echo $l_allowusercomments?></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_mincommentlength?>:</td>
<td><input type="text" name="input_mincomment" value="<?php echo $mincommentlength?>" size="3" maxlength="3"> <?php echo $l_characters?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="docommentrating" value="1" type="checkbox"
<?php if($ratecomments==1) echo " checked"?>> <?php echo $l_commentrating?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="commentnotify" value="1" type="checkbox"
<?php if($newcommentnotify==1) echo " checked"?>> <?php echo $l_newcommentnotify?></td></tr>
<tr bgcolor="#e0e0e0"><td align="left" colspan="2"><b><?php echo $l_lists?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_htmllisttype?>:</td>
<td><input type="radio" name="htmllisttype" value="0" <?php if($htmllisttype==0) echo "checked"?>> <?php echo $l_type?> 1<br>
<input type="radio" name="htmllisttype" value="1" <?php if($htmllisttype==1) echo "checked"?>> <?php echo $l_type?> 2</td></tr>
<tr bgcolor="#C0C0C0"><td align="left" colspan="2"><b><?php echo $l_admininterface?></b></td></tr>
<tr bgcolor="#cccccc"><td align="right"><?php echo $l_loginlimit?>:</td>
<td><input name="loginlimit" value="<?php echo $loginlimit?>" size="5" maxlength="5"></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="dologincount" value="1" type="checkbox"
<?php if($watchlogins==1) echo " checked"?>> <?php echo $l_watchlogins?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="enablefaqshortcuts" value="1" type="checkbox"
<?php if($faqlistshortcuts==1) echo " checked"?>> <?php echo $l_faqlistshortcuts?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="enableautourl" value="1" type="checkbox"
<?php if($urlautoencode==1) echo " checked"?>> <?php echo $l_urlautoencode?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="allowspcode" value="1" type="checkbox"
<?php if($enablespcode==1) echo " checked"?>> <?php echo $l_enablespcode?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="enablefreemailer" value="1" type="checkbox"
<?php if($nofreemailer==0) echo " checked"?>> <?php echo $l_allowfreemailer?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="enablemenubar" value="1" type="checkbox"
<?php if($usemenubar==1) echo " checked"?>> <?php echo $l_usemenubar?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td align="left"><input name="allowhostresolve" value="1" type="checkbox"
<?php if($enablehostresolve==1) echo " checked"?>> <?php echo $l_enablehostresolve?></td></tr>
<tr bgcolor="#cccccc"><td>&nbsp;</td><td><input type="checkbox" name="limitrelated" value="1" <?php if($faqlimitrelated==1) echo "checked"?>>
<?php echo $l_faqlimitrelated?></td></tr>
<tr bgcolor="#cccccc"><td align="right" valign="top"><?php echo $l_failednotify?>:<br><input name="dofailednotify" value="1" type="checkbox"
<?php if($enablefailednotify==1) echo " checked"?>><?php echo $l_enable?></td>
<td align="left" valign="top">
<?php
	$sql = "SELECT * FROM ".$tableprefix."_failed_notify fn, ".$tableprefix."_admins u where u.usernr=fn.usernr order by u.username";
	if(!$r = faqe_db_query($sql, $db))
	    die("Could not connect to the database.");
	if ($row = faqe_db_fetch_array($r))
	{
		 do {
		    echo $row["username"]." (<input type=\"checkbox\" name=\"rem_mods[]\" value=\"".$row["usernr"]."\"> $l_remove)<BR>";
		    $current_mods[] = $row["usernr"];
		 } while($row = faqe_db_fetch_array($r));
		 echo "<br>";
	}
	else
		echo "$l_noadmins<br><br>";
	$sql = "SELECT usernr, username FROM ".$tableprefix."_admins WHERE rights > 2 ";
	if(isset($current_mods))
	{
    	while(list($null, $currMod) = each($current_mods)) {
			$sql .= "AND usernr != $currMod ";
    	}
    }
    $sql .= "ORDER BY username";
    if(!$r = faqe_db_query($sql, $db))
		die("Could not connect to the database.");
    if($row = faqe_db_fetch_array($r)) {
		echo"<b>$l_add:</b><br>";
		echo"<SELECT NAME=\"mods[]\" size=\"5\" multiple>";
		do {
			echo "<OPTION VALUE=\"$row[usernr]\" >$row[username]</OPTION>\n";
		} while($row = faqe_db_fetch_array($r));
		echo"</select>";
	}
?>
</td></tr>
<tr bgcolor="#94AAD6"><td align="center" colspan="2">
<input type="submit" name="submit" value="<?php echo $l_submit?>"></td></tr>
</table></td></tr></table>
<?php
include('./trailer.php');
?>