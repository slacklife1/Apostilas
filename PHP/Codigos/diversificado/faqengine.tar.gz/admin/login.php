<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include('./language/lang_'.$act_lang.'.php');
require('./functions.php');
require('./auth.php');
$url_sessid=0;
$page_title=$l_loginpage;
$redirect="index.php?$langvar=$act_lang";		// Page to redirect after login
if(isset($do_login))
{
	$myusername=addslashes(strtolower($username));
	$banreason="";
	$result=do_login(addslashes($myusername),$userpw,$db);
	if($result==22)
	{
?>
<html>
<head>
<meta name="generator" content="FAQEngine v<?php echo $version?>, <?php echo $copyright_asc?>">
<title>FAQEngine - Administration</title>
</head>
<body>
<table width="80%" align="CENTER" calign="MIDDLE" border="0" cellspacing="0" cellpadding="0">
<tr><td align="CENTER" bgcolor="#94AAD6"><font size="+2"><img src="gfx/logo.gif" border="0" align="absmiddle"> <b>FAQEngine v<?php echo $version?></b></font></td></tr>
<tr><td align="CENTER" bgcolor="#c0c0c0"><font size="+2"><?php echo $page_title?></font></td></tr>
</table>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr bgcolor="#c0c0c0"><td colspan="2" align="center"><?php echo $l_too_many_users?></td></tr>
</table></td></tr></table></body></html>
<?
		exit;
	}
	if($result==-99)
	{
?>
<html>
<head>
<meta name="generator" content="FAQEngine v<?php echo $version?>, <?php echo $copyright_asc?>">
<title>FAQEngine - Administration</title>
</head>
<body>
<table width="80%" align="CENTER" calign="MIDDLE" border="0" cellspacing="0" cellpadding="0">
<tr><td align="CENTER" bgcolor="#94AAD6"><font size="+2"><img src="gfx/logo.gif" border="0" align="absmiddle"> <b>FAQEngine v<?php echo $version?></b></font></td></tr>
<tr><td align="CENTER" bgcolor="#c0c0c0"><font size="+2"><?php echo $page_title?></font></td></tr>
</table>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr bgcolor="#c0c0c0"><td colspan="2" align="center"><b><?php echo $l_ipbanned?></b></td></tr>
<tr bgcolor="#c0c0c0"><td align="right" width="20%"><?php echo $l_reason?>:</td>
<td align="left" width="80%"><?php echo $banreason?></td></tr>
</table></td></tr></table></body></html>
<?php
		exit;
	}
	if(($result!=1) && ($result!=4711))
	{
?>
<html>
<head>
<meta name="generator" content="FAQEngine v<?php echo $version?>, <?php echo $copyright_asc?>">
<title>FAQEngine - <?php echo $page_title?></title>
</head>
<body>
<table width="80%" align="CENTER" calign="MIDDLE" border="0" cellspacing="0" cellpadding="0">
<tr><td align="CENTER" bgcolor="#94AAD6"><font size="+2"><img src="gfx/logo.gif" border="0" align="abmiddle"> <b>FAQEngine v<?php echo $version?></b></font></td></tr>
<tr><td align="CENTER" bgcolor="#c0c0c0"><font size="+2"><?php echo $page_title?></font></td></tr>
</table>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr bgcolor="#94AAD6"><td align="center" colspan="2">
<?php echo $l_loginerror?></td></tr>
<?php
	}
	else
	{
		if($result==4711)
			$redirect="changepw.php?$langvar=$act_lang";
		if($sessid_url)
			$redirect=do_url_session($redirect);
		echo "<META HTTP-EQUIV=\"refresh\" content=\"0.01; URL=$redirect\">";
		exit;
	}
}
else
{
?>
<html>
<head>
<meta name="generator" content="FAQEngine v<?php echo $version?>, <?php echo $copyright_asc?>">
<title>FAQEngine - <?php echo $page_title?></title>
</head>
<body>
<table width="80%" align="CENTER" calign="MIDDLE" border="0" cellspacing="0" cellpadding="0">
<tr><td align="CENTER" bgcolor="#94AAD6"><font size="+2"><img src="gfx/logo.gif" border="0" align="absmiddle"> <b>FAQEngine v<?php echo $version?></b></font></td></tr>
<tr><td align="CENTER" bgcolor="#c0c0c0"><font size="+2"><?php echo $page_title?></font></td></tr>
</table>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr bgcolor="#94AAD6"><td align="center" colspan="2">
<?php echo $l_notloggedin?></td></tr>
<?php
}
?>
<tr bgcolor="#c0c0c0"><form method="post" action="<?php echo $PHP_SELF?>">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<td align="right" width="30%"><?php echo $l_username?>:</td><td><input type="text" name="username" size="40" maxlength="80"></td></tr>
<tr bgcolor="#c0c0c0"><td align="right"><?php echo $l_password?>:</td><td><input type="password" name="userpw" size="40" maxlength="40"></td></tr>
<tr bgcolor="#94AAD6"><td align="center" colspan="2"><input type="submit" name="do_login" value="<?php echo $l_login?>"></td></tr>
<?php
if($enablerecoverpw)
{
?>
<tr bgcolor="#94AAD6"><td align="center" colspan="2"><a href="pwlost.php?<?php echo "$langvar=$act_lang"?>"><?php echo $l_pwlost?></td></tr>
<?php
}
?>
</form></table></td></tr></table>
<?php
echo "<hr><div align=\"center\"><font size=\"2\">$copyright_url</font><br>$copyright_note</div>";
?>
