<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
?>
<html><body>
<div align="center"><h3>FAQEngine: Upgrade v3.25 - v3.29 to v3.30</h3></div>
<br>
<?php
echo "Creating new tables...<br>";
// create table faq_bindata
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_bindata;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_bindata");
$sql = "CREATE TABLE ".$tableprefix."_bindata (";
$sql.= "faqnr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "bindata longblob NOT NULL DEFAULT '' ,";
$sql.= "filename varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "mimetype varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "filesize int(10) NOT NULL DEFAULT '0' ,";
$sql.= "UNIQUE entrynr (faqnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_bindata");
echo "Upgrading tables...<br>";
$sql = "ALTER TABLE ".$tableprefix."_layout add ";
$sql.= "attachpic varchar(80) NOT NULL DEFAULT 'gfx/attach.gif'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_layout");
?>
<br><div align="center">Upgrade done.<br>Please remove install.php, upgrade*.php and fill_freemailer.php from server</div>
<div align="center">Now you can login to the <a href="index.php">admininterface</a></div>
</body></html>
