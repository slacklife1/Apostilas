<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
$l_answer_prelude = "Am $displaydate haben Sie folgende Frage gestellt:";
$l_answer_subject = "Antwort auf FAQ-Anfrage";
?>