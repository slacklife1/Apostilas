<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
$l_answer_prelude = "On $displaydate You posted the following question:";
$l_answer_subject = "Answer to FAQ-question posting";
?>