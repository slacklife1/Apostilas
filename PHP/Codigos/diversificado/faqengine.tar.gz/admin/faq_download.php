<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
require('./auth.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include('./language/lang_'.$act_lang.'.php');
$page_title=$l_faqdownload;
require('./heading.php');
$sql = "select * from ".$tableprefix."_layout where (layoutnr=1)";
if(!$result = faqe_db_query($sql, $db))
    die("Could not connect to the database.");
if($admin_rights < 2)
	die("$l_functionnotallowed");
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
	if(!isset($sorting))
	{
		if($faqlistshortcuts==1)
			$sorting=1;
		else
			$sorting=2;
	}
	if(($faqlistshortcuts==1) && ($sorting==1))
	{
		echo "<tr bgcolor=\"#94AAD6\"><td colspan=\"7\" align=\"center\">";
		for($i=65;$i<91;$i++)
			echo "<a href=\"#".chr($i)."\">".chr($i)."</a> ";
		echo "</td></tr>";
		$startchar="";
	}
	// Display list of actual FAQ
	if(isset($filterprog) && ($filterprog>0))
		$sql = "select dat.* from ".$tableprefix."_data dat, ".$tableprefix."_category cat where dat.category=cat.catnr and cat.programm=$filterprog ";
	else
	{
		if(isset($filterlang) && ($filterlang!="none"))
			$sql = "select dat.* from ".$tableprefix."_data dat, ".$tableprefix."_category cat, ".$tableprefix."_programm prog where dat.category=cat.catnr and cat.programm=prog.prognr and prog.language='$filterlang' ";
		else
		{
			if(isset($filtercat) && ($filtercat>0))
				$sql = "select dat.* from ".$tableprefix."_data dat where dat.category=$filtercat ";
			else
				$sql = "select dat.* from ".$tableprefix."_data dat ";
		}
	}
	switch($sorting)
	{
		case 1:
			$sql.="order by dat.heading asc";
			break;
		case 2:
			$sql.="order by dat.category asc";
			break;
		case 3:
			$sql.="order by dat.views desc";
			break;
		default:
			$sql.="order by dat.faqnr asc";
			break;
	}
	if(!$result = faqe_db_query($sql, $db)) {
	    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.".faqe_db_error());
	}
	if (!$myrow = faqe_db_fetch_array($result))
	{
		echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
		echo $l_noentries;
		echo "</td></tr></table></td></tr></table>";
	}
	else
	{
		echo "<form name=\"listform\" method=\"post\" action=\"faq_download2.php\">";
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
		echo "<input type=\"hidden\" name=\"$langvar\" value=\"$act_lang\">";
		echo "<tr bgcolor=\"#c0c0c0\">";
		echo "<td align=\"center\" width=\"5%\">&nbsp;</td>";
		echo "<td align=\"center\" width=\"5%\">";
		$myurl="$PHP_SELF?$langvar=$act_lang&sorting=0";
		if(isset($filterprog))
			$myurl.="&filterprog=$filterprog";
		if(isset($filtercat))
			$myurl.="&filtercat=$filtercat";
		if(isset($filterlang))
			$myurl.="&filterlang=$filterlang";
		echo "<a href=\"".do_url_session($myurl)."\">";
		echo "<b>#</b></a></td>";
		echo "<td align=\"center\" width=\"30%\">";
		$myurl="$PHP_SELF?$langvar=$act_lang&sorting=1";
		if(isset($filterprog))
			$myurl.="&filterprog=$filterprog";
		if(isset($filtercat))
			$myurl.="&filtercat=$filtercat";
		if(isset($filterlang))
			$myurl.="&filterlang=$filterlang";
		echo "<a href=\"".do_url_session($myurl)."\">";
		echo "<b>$l_heading</b></a></td>";
		echo "<td align=\"center\" width=\"10%\">";
		$myurl="$PHP_SELF?$langvar=$act_lang&sorting=2";
		if(isset($filterprog))
			$myurl.="&filterprog=$filterprog";
		if(isset($filtercat))
			$myurl.="&filtercat=$filtercat";
		if(isset($filterlang))
			$myurl.="&filterlang=$filterlang";
		echo "<a href=\"".do_url_session($myurl)."\">";
		echo "<b>$l_category</b></a></td>";
		echo "<td align=\"center\" width=\"10%\"><b>$l_programm</b></td>";
		echo "<td align=\"center\" width=\"10%\"><b>$l_language</b></td>";
		echo "<td align=\"center\" width=\"10%\"><b>";
		$myurl="$PHP_SELF?$langvar=$act_lang&sorting=3";
		if(isset($filterprog))
			$myurl.="&filterprog=$filterprog";
		if(isset($filtercat))
			$myurl.="&filtercat=$filtercat";
		if(isset($filterlang))
			$myurl.="&filterlang=$filterlang";
		echo "<a href=\"".do_url_session($myurl)."\">";
		echo "$l_views</b></a></td></tr>";
		do {
			$tempsql = "select * from ".$tableprefix."_category where (catnr=".$myrow["category"].")";
			if(!$tempresult = faqe_db_query($tempsql, $db)) {
			    die("Could not connect to the database.");
			}
			if (!$temprow = faqe_db_fetch_array($tempresult))
			{
				$prognr=0;
				$catname=$l_undefined;
			}
			else
			{
				$prognr=$temprow["programm"];
				$catname=htmlentities($temprow["categoryname"]);
			}
			$tempsql = "select * from ".$tableprefix."_programm where (prognr=$prognr)";
			if(!$tempresult = faqe_db_query($tempsql, $db)) {
			    die("Could not connect to the database.");
			}
			if (!$temprow = faqe_db_fetch_array($tempresult))
			{
				$proglang=$l_none;
				$progname=$l_none;
			}
			else
			{
				$proglang=$temprow["language"];
				$progname=$temprow["programmname"];
			}
			$act_id=$myrow["faqnr"];
			if($myrow["editdate"]>$userdata["lastlogin"])
				echo "<tr bgcolor=\"#eeeeee\">";
			else
				echo "<tr bgcolor=\"#cccccc\">";
			if(($faqlistshortcuts==1) && ($sorting==1))
			{
				$asc_heading=undo_htmlentities($myrow["heading"]);
				$firstchar=substr($asc_heading,0,1);
				$firstchar=strtoupper($firstchar);
				if(($firstchar!=$startchar) && (ord($firstchar)>64) && (ord($firstchar)<91))
				{
					$startchar=$firstchar;
					echo "<a name=\"#$startchar\"></a>";
				}
			}
			if($myrow["subcategory"]>0)
			{
				$subcatsql="select * from ".$tableprefix."_subcategory where catnr=".$myrow["subcategory"];
				if(!$subcatresult = faqe_db_query($subcatsql, $db))
				    die("Unable to connect to database.");
				if($subcatrow=faqe_db_fetch_array($subcatresult))
					$subcatname=$subcatrow["categoryname"];
			}
			else
				$subcatname="";
			echo "<td align=\"center\"><input type=\"checkbox\" name=\"faqnrs[]\" value=\"".$myrow["faqnr"]."\"></td>";
			echo "<td align=\"center\">".$myrow["faqnr"]."</td>";
			echo "<td>".$myrow["heading"]."</td>";
			if($subcatname)
				echo "<td align=\"center\">$catname : $subcatname</td>";
			else
				echo "<td align=\"center\">$catname</td>";
			echo "<td align=\"center\">$progname</td>";
			echo "<td align=\"center\">$proglang</td>";
			echo "<td align=\"right\">".$myrow["views"]."</td>";
			echo "</tr>";
		} while($myrow = faqe_db_fetch_array($result));
		echo "<tr bgcolor=\"#94AAD6\"><td align=\"center\" colspan=\"7\">";
		echo "<input type=\"hidden\" name=\"mode\" value=\"download\">";
		echo "<input type=\"submit\" value=\"$l_download_selected\">";
		echo "\n&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"button\" onclick=\"checkAll(document.listform)\" value=\"$l_checkall\">\n";
		echo "\n&nbsp;&nbsp;<input type=\"button\" onclick=\"uncheckAll(document.listform)\" value=\"$l_uncheckall\">\n";
		echo "</td></tr>";
		echo "</form>";
	   echo "</table></tr></td></table>";
	}
	if($admin_rights > 1)
	{
		if($admin_rights<3)
			$sql1 = "select prog.* from ".$tableprefix."_programm prog, ".$tableprefix."_programm_admins pa where prog.prognr = pa.prognr and pa.usernr=$act_usernr order by prog.prognr";
		else
			$sql1 = "select prog.* from ".$tableprefix."_programm prog order by prog.prognr";
		if(!$result1 = faqe_db_query($sql1, $db)) {
			die("Could not connect to the database (3).".faqe_db_error());
		}
		if ($temprow = faqe_db_fetch_array($result1))
		{
?>
<br>
<table align="center" width="80%" border="0" cellspacing="0" cellpadding="1" valign="top">
<form action="<?php echo $PHP_SELF?>" method="post">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="lang" value="<?php echo $lang?>">
<input type="hidden" name="sorting" value="<?php echo $sorting?>">
<tr><td align="right" width="50%" valign="top"><?php echo $l_progfilter?>:</td>
<td align="left" width="30%"><select name="filterprog">
<option value="-1"><?php echo $l_nofilter?></option>
<?php
			do {
				$progname=htmlentities($temprow["programmname"]);
				$proglang=$temprow["language"];
				echo "<option value=\"".$temprow["prognr"]."\"";
				if(isset($filterprog))
				{
					if($filterprog==$temprow["prognr"])
						echo " selected";
				}
				echo ">";
				echo "$progname [$proglang]";
				echo "</option>";
			} while($temprow = faqe_db_fetch_array($result1));
?>
</select></td><td align="left"><input type="submit" value="<?php echo $l_ok?>"></td></tr>
</form></table>
<?php
		}
		if($admin_rights<3)
			$sql1 = "select cat.*, prog.programmname, prog.language from ".$tableprefix."_category cat, ".$tableprefix."_programm prog, ".$tableprefix."_category_admins ca where prog.prognr = cat.programm and ca.usernr=$act_usernr and cat.catnr=ca.catnr order by cat.catnr";
		else
			$sql1 = "select cat.*, prog.programmname, prog.language from ".$tableprefix."_programm prog, ".$tableprefix."_category cat where prog.prognr=cat.programm order by cat.catnr";
		if(!$result1 = faqe_db_query($sql1, $db)) {
			die("Could not connect to the database (3).".faqe_db_error());
		}
		if ($temprow = faqe_db_fetch_array($result1))
		{
?>
<br>
<table align="center" width="80%" border="0" cellspacing="0" cellpadding="1" valign="top">
<form action="<?php echo $PHP_SELF?>" method="post">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="lang" value="<?php echo $lang?>">
<input type="hidden" name="sorting" value="<?php echo $sorting?>">
<tr><td align="right" width="50%" valign="top"><?php echo $l_catfilter?>:</td>
<td align="left" width="30%"><select name="filtercat">
<option value="-1"><?php echo $l_nofilter?></option>
<?php
			do {
				$progname=htmlentities($temprow["programmname"]);
				$proglang=$temprow["language"];
				$catname=htmlentities($temprow["categoryname"]);
				echo "<option value=\"".$temprow["catnr"]."\"";
				if(isset($filtercat))
				{
					if($filtercat==$temprow["catnr"])
						echo " selected";
				}
				echo ">";
				echo "$catname | $progname [$proglang]";
				echo "</option>";
			} while($temprow = faqe_db_fetch_array($result1));
?>
</select></td><td align="left"><input type="submit" value="<?php echo $l_ok?>"></td></tr>
</form></table>
<?php
		}
?>
<br>
<table align="center" width="80%" border="0" cellspacing="0" cellpadding="1" valign="top">
<form action="<?php echo $PHP_SELF?>" method="post">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="lang" value="<?php echo $lang?>">
<input type="hidden" name="sorting" value="<?php echo $sorting?>">
<tr><td align="right" width="50%" valign="top"><?php echo $l_langfilter?>:</td>
<td align="left" width="30%"><select name="filterlang">
<option value="none"><?php echo $l_nofilter?></option>
<?php
		$langs=language_list("../language");
		for($i=0;$i<count($langs);$i++)
		{
			echo "<option value=\"".$langs[$i]."\"";
			if(isset($filterlang))
			{
				if($filterlang==$langs[$i])
					echo " selected";
			}
			echo ">";
			echo $langs[$i];
			echo "</option>";
		}
?>
</select></td><td align="left"><input type="submit" value="<?php echo $l_ok?>"></td></tr>
</form></table>
<?php
	}
echo "<div align=\"center\"><a href=\"".do_url_session("faq.php?$langvar=$act_lang")."\">$l_faqlist</a></div>";
include('./trailer.php');
?>