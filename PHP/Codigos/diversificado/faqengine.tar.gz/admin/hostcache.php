<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
if(!isset($$langvar) || !$$langvar)
	$act_lang=$admin_lang;
else
	$act_lang=$$langvar;
include('./language/lang_'.$act_lang.'.php');
require('./auth.php');
$page_title=$l_emptyhostcache;
require('./heading.php');
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<?php
if(isset($mode))
{
	if($mode=="doclear")
	{
		if($admin_rights < 3)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
		$sql = "DELETE FROM ".$hcprefix."_hostcache";
		if(!$result = faqe_db_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr bgcolor="#C0C0C0"><td align="center"><?php echo $l_hostcachecleared?></td></tr>
</table></td></tr></table>
<?php
		echo "<div align=\"center\"><a href=\"".do_url_session("$PHP_SELF?$langvar=$act_lang")."\">$l_hostcache</a></div>";
		include('./trailer.php');
		exit;
	}
	if($mode=="clear")
	{
		if($admin_rights < 3)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr bgcolor="#C0C0C0">
<form method="post" action="<?php echo $PHP_SELF?>">
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="mode" value="doclear">
<?php
		if($sessid_url)
			echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<td align="center"><?php echo $l_hostcachewarning?></td></tr>
<tr bgcolor="#94AAD6">
<td align="center"><input type="submit" name="submit" value="<?php echo $l_yes?>"></td></tr>
</table></td></tr></table>
<?php
	}
}
else
{
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
	$sql = "select * from ".$hcprefix."_hostcache order by ipadr";
	if(!$result = faqe_db_query($sql, $db)) {
	    die("Could not connect to the database.");
	}
?>
<tr bgcolor="#c0c0c0">
<td align="center"><b><?php echo $l_ipadr?></b></td>
<td align="center"><b><?php echo $l_hostname?></b></td>
</tr>
<?php
	if (!$myrow = faqe_db_fetch_array($result))
	{
		echo "<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"2\">";
		echo $l_noentries;
		echo "</td></tr></table></td></tr></table>";
	}
	else
	{
		do {
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			echo $myrow["ipadr"];
			echo "</td><td align=\"center\">";
			echo $myrow["hostname"];
			echo "</td></tr>";
		} while($myrow = faqe_db_fetch_array($result));
		echo "</table></tr></td></table>";
	}
	if($admin_rights > 2)
	{
?>
<div align="center"><a href="<?php echo do_url_session("$PHP_SELF?mode=clear&$langvar=$act_lang")?>"><?php echo $l_emptyhostcache?></a></div>
<?php
	}
}
include('./trailer.php');
?>