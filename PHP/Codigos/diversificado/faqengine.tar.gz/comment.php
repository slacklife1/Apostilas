<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('./config.php');
require('./functions.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<?php
$sql = "select * from ".$tableprefix."_layout where (layoutnr=1)";
if(!$result = faqe_db_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = faqe_db_fetch_array($result))
{
	$FontFace=$myrow["fontface"];
	$FontSize1=$myrow["fontsize1"];
	$FontSize2=$myrow["fontsize2"];
	$FontSize3=$myrow["fontsize3"];
	$FontSize4=$myrow["fontsize4"];
	$FontSize5=$myrow["fontsize5"];
	$FontColor=$myrow["fontcolor"];
	$TableWidth=$myrow["tablewidth"];
	$heading_bgcolor=$myrow["headingbg"];
	$table_bgcolor=$myrow["bgcolor1"];
	$row_bgcolor=$myrow["bgcolor2"];
	$group_bgcolor=$myrow["bgcolor3"];
	$page_bgcolor=$myrow["pagebg"];
	$stylesheet=stripslashes($myrow["stylesheet"]);
	$show_proglist=$myrow["showproglist"];
	$HeadingFontColor=$myrow["headingfontcolor"];
	$SubheadingFontColor=$myrow["subheadingfontcolor"];
	$GroupFontColor=$myrow["groupfontcolor"];
	$LinkColor=$myrow["linkcolor"];
	$VLinkColor=$myrow["vlinkcolor"];
	$ALinkColor=$myrow["alinkcolor"];
	$TableDescFontColor=$myrow["tabledescfontcolor"];
	$dateformat=$myrow["dateformat"];
	$newtime=$myrow["newtime"];
	$searchpic=$myrow["searchpic"];
	$printpic=$myrow["printpic"];
	$backpic=$myrow["backpic"];
	$pageheader=$myrow["pageheader"];
	$pagefooter=$myrow["pagefooter"];
	$usecustomheader=$myrow["usecustomheader"];
	$usecustomfooter=$myrow["usecustomfooter"];
	$allowemail=$myrow["allowemail"];
	$allowquestions=$myrow["allowquestions"];
	$allowusercomments=$myrow["allowusercomments"];
	$faqemail=$myrow["faqemail"];
	$newcommentnotify=$myrow["newcommentnotify"];
	$server_timezone=$myrow["timezone"];
	$ratecomments=$myrow["ratecomments"];
	$headerfile=$myrow["headerfile"];
	$footerfile=$myrow["footerfile"];
	$mincommentlength=$myrow["mincommentlength"];
	$textarearows=$myrow["textareaheight"];
	$textareacols=$myrow["textareawidth"];
	$copyrightbgcolor=$myrow["copyrightbgcolor"];
	$showcurrtime=$myrow["showcurrtime"];
	$showtimezone=$myrow["showtimezone"];
	$copyrightpos=$myrow["copyrightpos"];
	$subheadingbgcolor=$myrow["subheadingbgcolor"];
	$actionbgcolor=$myrow["actionbgcolor"];
	$headerfilepos=$myrow["headerfilepos"];
	$footerfilepos=$myrow["footerfilepos"];
	$newinfobgcolor=$myrow["newinfobgcolor"];
	$addbodytags=$myrow["addbodytags"];
	$pagetoppic=$myrow["pagetoppic"];
	if(!$faqemail)
		$faqemail="faq@foo.bar";
	if((!$pageheader) && (!$headerfile))
		$usecustomheader=0;
	if((!$pagefooter) && (!$footerfile))
		$usecustomfooter=0;
	$dateformat.=" H:i:s";
}
else
	die("Layout not set up");
if(!isset($$langvar) || !$$langvar)
	$act_lang=$default_lang;
else
	$act_lang=$$langvar;
if(!language_avail($act_lang))
	die ("Language <b>$act_lang</b> not configured");
include('./language/lang_'.$act_lang.'.php');
if($allowusercomments!=1)
{
	die($l_disallowed);
}
if(!isset($mode) || !isset($prog) || !isset($faqnr) || !isset($catnr))
	die($l_callingerror);
if((@fopen("./config.php", "a")) && !$testmode)
{
	die($l_config_writeable);
}
?>
<html>
<head>
<meta name="generator" content="FAQEngine v<?php echo $version?>, <?php echo $copyright_asc?>">
<?php
if($stylesheet)
	echo"<link rel=stylesheet href=\"$stylesheet\" type=\"text/css\">";
if(file_exists("./metadata.php"))
	include ("./metadata.php");
else
{
?>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<title><?php echo $l_heading?></title>
<?php
}
?>
</head>
<body bgcolor="<?php echo $page_bgcolor?>" link="<?php echo $LinkColor?>" vlink="<?php echo $VLinkColor?>" alink="<?php echo $ALinkColor?>" text="<?php echo $FontColor?>" <?php echo $addbodytags?>>
<?php
if($usecustomheader==1)
{
	if(($headerfile) && ($headerfilepos==0))
	{
		if(is_phpfile($headerfile))
			include($headerfile);
		else
			file_output($headerfile);
	}
	echo $pageheader;
	if(($headerfile) && ($headerfilepos==1))
	{
		if(is_phpfile($headerfile))
			include($headerfile);
		else
			file_output($headerfile);
	}
}
?>
<table width="<?php echo $TableWidth?>" border="0" CELLPADDING="1" CELLSPACING="0" ALIGN="CENTER" VALIGN="TOP">
<tr><TD BGCOLOR="<?php echo $table_bgcolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<TR BGCOLOR="<?php echo $heading_bgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE" colspan="2"><a name="#top"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize3?>" color="<?php echo $HeadingFontColor?>"><b><?php echo $l_heading?></b></font></a></td>
<?php
$sql = "select * from ".$tableprefix."_misc";
if(!$result = faqe_db_query($sql, $db)) {
    die("<tr bgcolor=\"$heading_bgcolor\" align=\"center\"><td>Could not connect to the database.");
}
if ($myrow = faqe_db_fetch_array($result))
{
	if($myrow["shutdown"]==1)
	{
?>
</tr></table></td></tr>
<tr><TD BGCOLOR="<?php echo $table_bgcolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<?php
		$shutdowntext=stripslashes($myrow["shutdowntext"]);
		$shutdowntext = undo_htmlspecialchars($shutdowntext);
		echo $shutdowntext;
		echo "</font></td></tr></table></td></tr></table>";
		echo "<br><div align=\"center\"><font face=\"$FontFace\" SIZE=\"$FontSize4\">$l_timezone_note $server_timezone<br>Generated by $copyright_url<br>$copyright_note</font></div>";
		exit;
	}
}
?>
<tr BGCOLOR="<?php echo $subheadingbgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE" width="95%"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $SubheadingFontColor?>"><b><?php echo $l_usercomments?></b></font>
</td>
<td align="right" valign="MIDDLE" width="5%">
<a href="faq.php?display=faq&amp;nr=<?php echo $faqnr?>&amp;catnr=<?php echo $catnr?>&amp;prog=<?php echo $prog?>&<?php echo "$langvar=$act_lang"?><?php if(isset($onlynewfaq)) echo "&amp;onlynewfaq=$onlynewfaq"?>">
<img src="<?php echo $backpic?>" border="0" alt="<?php echo $l_faqlink?>"></a></td>
</tr></table></td></tr>
<tr><TD BGCOLOR="<?php echo $table_bgcolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<?php
if($mode=="display")
{
	$sql = "select * from ".$tableprefix."_comments where faqnr = $faqnr";
	if(!$result = faqe_db_query($sql, $db)) {
	    die("<tr bgcolor=\"$heading_bgcolor\" align=\"center\"><td>Could not connect to the database.");
	}
	if(!$myrow=faqe_db_fetch_array($result))
	{
		echo "<tr bgcolor=\"$group_bgcolor\" align=\"center\"><td>";
		echo "<font face=\"$FontFace\" size=\"$FontSize5\" color=\"$FontColor\">";
		echo "$l_noentries</font></td></tr>";
	}
	else
	{
		$tempsql = "select dat.heading, prog.programmname, cat.categoryname  from ".$tableprefix."_data dat, ".$tableprefix."_category cat, ".$tableprefix."_programm prog where ";
		$tempsql .="dat.category=cat.catnr and prog.prognr=cat.programm and dat.faqnr=$faqnr";
		if(!$tempresult = faqe_db_query($tempsql, $db)) {
		    die("<tr bgcolor=\"$heading_bgcolor\" align=\"center\"><td>Could not connect to the database.");
		}
		if($temprow=faqe_db_fetch_array($tempresult))
		{
			echo "<tr bgcolor=\"$subheadingbgcolor\" align=\"center\"><td align=\"center\" colspan=\"2\">";
			echo "<font face=\"$FontFace\" size=\"$FontSize2\" color=\"$SubheadingFontColor\"><b>";
			echo htmlentities($temprow["programmname"]).":".htmlentities($temprow["categoryname"]).":".$temprow["heading"];
			echo "</b></font></td></tr>";
		}
		do{
			$updatesql = "update ".$tableprefix."_comments set views = views+1 where commentnr = ".$myrow["commentnr"];
			if(!$updateresult=faqe_db_query($updatesql, $db))
			    die("<tr bgcolor=\"$heading_bgcolor\" align=\"center\"><td>Could not connect to the database.");
			list($mydate,$mytime)=explode(" ",$myrow["postdate"]);
			list($year, $month, $day) = explode("-", $mydate);
			list($hour, $min, $sec) = explode(":",$mytime);
			if($month>0)
				$displaydate=date($dateformat,mktime($hour,$min,$sec,$month,$day,$year));
			else
				$displaydate="";
			$commenttext=htmlentities($myrow["comment"]);
			$commenttext = str_replace("\n", "<BR>", $commenttext);
			$displaycomment ="<a href=\"mailto:".$myrow["email"]."\">".$myrow["email"]."</a> $l_on $displaydate:<br>";
			$displaycomment.=$commenttext;
			echo "<tr bgcolor=\"$row_bgcolor\" align=\"center\"><td align=\"left\" colspan=\"2\">";
			echo "<font face=\"$FontFace\" size=\"$FontSize5\" color=\"$FontColor\">";
			echo $displaycomment;
			echo "</font></td></tr>";
			if($ratecomments==1)
			{
				echo "<TR BGCOLOR=\"$row_bgcolor\" ALIGN=\"LEFT\" valign=\"middle\">";
				echo "<form action=\"$PHP_SELF\" method=\"post\"><td colspan=\"2\" valign=\"middle\">";
				if(isset($onlynewfaq))
					echo "<input type=\"hidden\" name=\"onlynewfaq\" value=\"$onlynewfaq\">";
				echo "<input type=\"hidden\" name=\"mode\" value=\"rate\" alt=\"mode\">";
				echo "<input type=\"hidden\" name=\"$langvar\" value=\"$act_lang\" alt=\"$langvar\">";
				echo "<input type=\"hidden\" name=\"prog\" value=\"$prog\" alt=\"prog\">";
				echo "<input type=\"hidden\" name=\"catnr\" value=\"$catnr\" alt=\"catnr\">";
				echo "<input type=\"hidden\" name=\"faqnr\" value=\"$faqnr\" alt=\"faqnr\">";
				echo "<input type=\"hidden\" name=\"origin\" value=\"display\" alt=\"origin\">";
				echo "<input type=\"hidden\" name=\"commentnr\" value=\"".$myrow["commentnr"]."\" alt=\"commentnr\">";
				echo "<font face=\"$FontFace\" size=\"$FontSize2\" color=\"$FontColor\">";
				echo "$l_ratingprelude ";
				echo "<select name=\"rating\">";
				for($i = 0; $i< count($l_ratings); $i++)
				{
					echo "<option value=\"$i\"";
					if($i==(count($l_ratings)-1))
						echo " selected";
					echo ">".$l_ratings[$i]."</option>";
				}
				echo "</select> ";
				echo "&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"$l_rate\" alt=\"$l_rate\"></font></td></form></tr>";
			}
			echo "<tr></tr>";
		}while($myrow=faqe_db_fetch_array($result));
	}
	echo "<tr bgcolor=\"$actionbgcolor\"><td align=\"center\" width=\"99%\">";
	echo "<font face=\"$FontFace\" size=\"$FontSize1\" color=\"$FontColor\">";
	echo "<a href=\"$PHP_SELF?mode=write&amp;$langvar=$act_lang&amp;faqnr=$faqnr&amp;prog=$prog&amp;catnr=$catnr";
	if(isset($onlynewfaq))
		echo "&amp;onlynewfaq=$onlynewfaq";
	echo "\">";
	echo "$l_writecomment</a></font></td>";
	echo "<td align=\"right\" width=\"1%\"><a href=\"#top\"><font face=\"$FontFace\" size=\"$FontSize4\"><img src=\"$pagetoppic\" border=\"0\" align=\"middle\" alt=\"$l_top\"></a></td>";
	echo "</tr>";
}
if($mode=="rate")
{
	$sql = "UPDATE ".$tableprefix."_comments set rating=rating+$rating, ratingcount=ratingcount+1 where commentnr=$commentnr";
	if(!$result = faqe_db_query($sql, $db)) {
	    die("<tr bgcolor=\"$heading_bgcolor\" align=\"center\"><td>Could not connect to the database.");
	}
	echo "<tr bgcolor=\"$group_bgcolor\" align=\"center\"><td align=\"center\">";
	echo "<font face=\"$FontFace\" size=\"$FontSize2\" color=\"$FontColor\">";
	echo "$l_commentrated";
	echo "</font></td></tr>";
	if($origin=="display")
		$backlink="<a href=\"$PHP_SELF?mode=display&amp;$langvar=$act_lang&amp;prog=$prog&amp;catnr=$catnr&amp;faqnr=$faqnr";
	else
		$backlink="<a href=\"$PHP_SELF?mode=read&amp;$langvar=$act_lang&amp;prog=$prog&amp;catnr=$catnr&amp;faqnr=$faqnr&amp;commentnr=$commentnr";
	if(isset($onlynewfaq))
		$backlink.="&amp;onlynewfaq=$onlynewfaq";
	$backlink.="\">";
	echo "<tr bgcolor=\"$actionbgcolor\" align=\"center\"><td align=\"center\">";
	echo "<font face=\"$FontFace\" size=\"$FontSize1\" color=\"$FontColor\">";
	echo $backlink;
	echo $l_back;
	echo "</a></td></tr>";
	echo "</table></td></tr></table>";
	if(($usecustomfooter==1) && ($copyrightpos==0))
	{
		if(($footerfile) && ($footerfilepos==0))
		{
			if(is_phpfile($footerfile))
				include($footerfile);
			else
				file_output($footerfile);
		}
		echo $pagefooter;
		if(($footerfile) && ($footerfilepos==1))
		{
			if(is_phpfile($footerfile))
				include($footerfile);
			else
				file_output($footerfile);
		}
	}
?>
<br>
<table align="center" bgcolor="<?php echo $copyrightbgcolor?>" width="<?php echo $TableWidth?>" border="0">
<tr><td align="center">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize4?>" color="<?php echo $FontColor?>">
<?php
	if($showcurrtime)
	{
		$displaytime=date("H:i");
		echo "$l_currtime $displaytime<br>";
	}
	if($showtimezone==1)
		echo "$l_timezone_note $server_timezone<br>";
	echo "Generated by $copyright_url, $copyright_note";
?>
</td></tr></table>
<br>
<?php
	if(($usecustomfooter==1) && ($copyrightpos==1))
	{
		if(($footerfile) && ($footerfilepos==0))
		{
			if(is_phpfile($footerfile))
				include($footerfile);
			else
				file_output($footerfile);
		}
		echo $pagefooter;
		if(($footerfile) && ($footerfilepos==1))
		{
			if(is_phpfile($footerfile))
				include($footerfile);
			else
				file_output($footerfile);
		}
	}
	echo "</body></html>";
	exit;
}
if($mode=="read")
{
	$sql = "select * from ".$tableprefix."_comments where commentnr = $commentnr";
	if(!$result = faqe_db_query($sql, $db)) {
	    die("<tr bgcolor=\"$heading_bgcolor\" align=\"center\"><td>Could not connect to the database.");
	}
	if(!$myrow=faqe_db_fetch_array($result))
	{
		echo "<tr bgcolor=\"$group_bgcolor\" align=\"center\"><td>";
		echo "<font face=\"$FontFace\" size=\"$FontSize5\" color=\"$FontColor\">";
		echo "$l_noentries</font></td></tr>";
	}
	else
	{
		$tempsql = "select dat.heading, prog.programmname, cat.categoryname  from ".$tableprefix."_data dat, ".$tableprefix."_category cat, ".$tableprefix."_programm prog where ";
		$tempsql .="dat.category=cat.catnr and prog.prognr=cat.programm and dat.faqnr=".$myrow["faqnr"];
		if(!$tempresult = faqe_db_query($tempsql, $db)) {
		    die("<tr bgcolor=\"$heading_bgcolor\" align=\"center\"><td>Could not connect to the database.");
		}
		if($temprow=faqe_db_fetch_array($tempresult))
		{
			echo "<tr bgcolor=\"$subheadingbgcolor\" align=\"center\"><td align=\"center\">";
			echo "<font face=\"$FontFace\" size=\"$FontSize2\" color=\"$SubheadingFontColor\"><b>";
			echo htmlentities($temprow["programmname"]).":".htmlentities($temprow["categoryname"]).":".$temprow["heading"];
			echo "</b></font></td></tr>";
		}
		$updatesql = "update ".$tableprefix."_comments set views = views+1 where commentnr = ".$myrow["commentnr"];
		if(!$updateresult=faqe_db_query($updatesql, $db))
		    die("<tr bgcolor=\"$heading_bgcolor\" align=\"center\"><td>Could not connect to the database.");
		list($mydate,$mytime)=explode(" ",$myrow["postdate"]);
		list($year, $month, $day) = explode("-", $mydate);
		list($hour, $min, $sec) = explode(":",$mytime);
		if($month>0)
			$displaydate=date($dateformat,mktime($hour,$min,$sec,$month,$day,$year));
		else
			$displaydate="";
		$commenttext=htmlentities($myrow["comment"]);
		$commenttext = str_replace("\n", "<BR>", $commenttext);
		$displaycomment ="<a href=\"mailto:".$myrow["email"]."\">".$myrow["email"]."</a> $l_on $displaydate:<br>";
		$displaycomment .=$commenttext;
		echo "<tr bgcolor=\"$row_bgcolor\" align=\"center\"><td align=\"left\">";
		echo "<font face=\"$FontFace\" size=\"$FontSize5\" color=\"$FontColor\">";
		echo $displaycomment;
		echo "</font></td></tr>";
		if($ratecomments==1)
		{
			echo "<TR BGCOLOR=\"$row_bgcolor\" ALIGN=\"LEFT\" valign=\"middle\">";
			echo "<form action=\"$PHP_SELF\" method=\"post\"><td colspan=\"2\" valign=\"middle\">";
			if(isset($onlynewfaq))
				echo "<input type=\"hidden\ name=\"onlynewfaq\" value=\"$onlynewfaq\">";
			echo "<input type=\"hidden\" name=\"mode\" value=\"rate\" alt=\"mode\">";
			echo "<input type=\"hidden\" name=\"$langvar\" value=\"$act_lang\" alt=\"$langvar\">";
			echo "<input type=\"hidden\" name=\"prog\" value=\"$prog\" alt=\"prog\">";
			echo "<input type=\"hidden\" name=\"catnr\" value=\"$catnr\" alt=\"catnr\">";
			echo "<input type=\"hidden\" name=\"faqnr\" value=\"$faqnr\" alt=\"faqnr\">";
			echo "<input type=\"hidden\" name=\"origin\" value=\"read\" alt=\"origin\">";
			echo "<input type=\"hidden\" name=\"commentnr\" value=\"".$myrow["commentnr"]."\" alt=\"commentnr\">";
			echo "<font face=\"$FontFace\" size=\"$FontSize2\" color=\"$FontColor\">";
			echo "$l_ratingprelude ";
			echo "<select name=\"rating\">";
			for($i = 0; $i< count($l_ratings); $i++)
			{
				echo "<option value=\"$i\"";
				if($i==(count($l_ratings)-1))
					echo " selected";
				echo ">".$l_ratings[$i]."</option>";
			}
			echo "</select> ";
			echo "&nbsp;&nbsp;&nbsp;<input type=\"submit\" value=\"$l_rate\" alt=\"$l_rate\"></font></td></form></tr>";
		}
		echo "<tr></tr>";
	}
	echo "<tr bgcolor=\"$actionbgcolor\"><td align=\"center\">";
	echo "<font face=\"$FontFace\" size=\"$FontSize1\" color=\"$FontColor\">";
	echo "<a href=\"$PHP_SELF?mode=write&amp;$langvar=$act_lang&amp;faqnr=$faqnr&amp;prog=$prog&amp;catnr=$catnr";
	if(isset($onlynewfaq))
		echo "&amp;onlynewfaq=$onlynewfaq";
	echo "\">";
	echo "$l_writecomment</a></font></td></tr>";
}
if($mode=="post")
{
	$errors=0;
	if((!$email) || (!validate_email($email)))
	{
		echo "<tr bgcolor=\"$group_bgcolor\" align=\"center\"><td>";
		echo "<font face=\"$FontFace\" size=\"$FontSize2\" color=\"$FontColor\">";
		echo "$l_invalidemail</font></td></tr>";
		$errors=1;
	}
	if(!$comment)
	{
		echo "<tr bgcolor=\"$group_bgcolor\" align=\"center\"><td>";
		echo "<font face=\"$FontFace\" size=\"$FontSize2\" color=\"$FontColor\">";
		echo "$l_nocomment</font></td></tr>";
		$errors=1;
	}
	else if(strlen($comment)<$mincommentlength)
	{
		echo "<tr bgcolor=\"$group_bgcolor\" align=\"center\"><td>";
		echo "<font face=\"$FontFace\" size=\"$FontSize2\" color=\"$FontColor\">";
		echo "$l_shortcomment<br>$l_minlength $mincommentlength $l_characters.<br>($l_entered: ".strlen($comment).")</font></td></tr>";
		$errors=1;
	}
	if($errors==0)
	{
		$actdate = date("Y-m-d H:i:s");
		$displaydate=date($dateformat);
		$comment=strip_tags($comment);
		$sql = "INSERT INTO ".$tableprefix."_comments (faqnr, email, comment, ipadr, postdate) ";
		$sql .="values ($faqnr, '$email', '$comment', '$REMOTE_ADDR', '$actdate')";
		if(!$result = faqe_db_query($sql, $db)) {
		    die("<tr bgcolor=\"$heading_bgcolor\" align=\"center\"><td>Could not connect to the database.");
		}
		if($newcommentnotify==1)
		{
			$sql = "select u.email from ".$tableprefix."_admins u, ".$tableprefix."_category cat, ".$tableprefix."_programm_admins pa, ".$tableprefix."_data dat ";
			$sql .=" where (dat.faqnr=$faqnr and cat.catnr=dat.category and pa.prognr=cat.programm and u.usernr=pa.usernr) or (u.rights>2) group by u.usernr";
			if(!$result = faqe_db_query($sql, $db)) {
			    die("<tr bgcolor=\"$heading_bgcolor\" align=\"center\"><td>Could not connect to the database.");
			}
			if($myrow=faqe_db_fetch_array($result))
			{
				$usercount=0;
				$fromadr = "From:".$faqemail."\r\n";
				$subject = "Info from FAQEngine";
				$mailmsg = "$displaydate:\r\n";
				$mailmsg .= "Neuer Benutzerkommentar zu FAQ-Nr. $faqnr.\r\n";
				$mailmsg .= "New user comment for FAQ # $faqnr.\r\n\r\n";
				do{
					if(strlen($myrow["email"])>1)
					{
						if($usercount==0)
						{
							$receiver=$myrow["email"];
							$usercount+=1;
						}
						else
						{
							$receiver.=", ".$myrow["email"];
						}
					}
				}while($myrow = faqe_db_fetch_array($result));
				mail($receiver,$subject,$mailmsg,$fromadr);
			}
		}
		echo "<tr bgcolor=\"$group_bgcolor\" align=\"center\"><td>";
		echo "<font face=\"$FontFace\" size=\"$FontSize2\" color=\"$FontColor\">";
		echo $l_commentposted;
		echo "</font></td></tr></table></td></tr></table>";
		if(($usecustomfooter==1) && ($copyrightpos==0))
		{
			if(($footerfile) && ($footerfilepos==0))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
			echo $pagefooter;
			if(($footerfile) && ($footerfilepos==1))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
		}
?>
<br>
<table align="center" bgcolor="<?php echo $copyrightbgcolor?>" width="<?php echo $TableWidth?>" border="0">
<tr><td align="center">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize4?>" color="<?php echo $FontColor?>">
<?php
		if($showcurrtime)
		{
			$displaytime=date("H:i");
			echo "$l_currtime $displaytime<br>";
		}
		if($showtimezone==1)
			echo "$l_timezone_note $server_timezone<br>";
		echo "Generated by $copyright_url, $copyright_note";
?>
</td></tr></table>
<br>
<?php
		if(($usecustomfooter==1) && ($copyrightpos==1))
		{
			if(($footerfile) && ($footerfilepos==0))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
			echo $pagefooter;
			if(($footerfile) && ($footerfilepos==1))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
		}
		echo "</body></html>";
		exit;
	}
	else
	{
		echo "<tr bgcolor=\"$actionbgcolor\" align=\"center\"><td>";
		echo "<font face=\"$FontFace\" size=\"$FontSize1\" color=\"$FontColor\">";
		echo "<a href=\"javascript:history.back()\">$l_back</a>";
		echo "</font></td></tr></table></td></tr></table>";
		if(($usecustomfooter==1) && ($copyrightpos==0))
		{
			if(($footerfile) && ($footerfilepos==0))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
			echo $pagefooter;
			if(($footerfile) && ($footerfilepos==1))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
		}
?>
<br>
<table align="center" bgcolor="<?php echo $copyrightbgcolor?>" width="<?php echo $TableWidth?>" border="0">
<tr><td align="center">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize4?>" color="<?php echo $FontColor?>">
<?php
		if($showcurrtime)
		{
			$displaytime=date("H:i");
			echo "$l_currtime $displaytime<br>";
		}
		if($showtimezone==1)
			echo "$l_timezone_note $server_timezone<br>";
		echo "Generated by $copyright_url, $copyright_note";
?>
</td></tr></table>
<br>
<?php
		if(($usecustomfooter==1) && ($copyrightpos==1))
		{
			if(($footerfile) && ($footerfilepos==0))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
			echo $pagefooter;
			if(($footerfile) && ($footerfilepos==1))
			{
				if(is_phpfile($footerfile))
					include($footerfile);
				else
					file_output($footerfile);
			}
		}
		echo "</body></html>";
		exit;
	}
}
if($mode=="write")
{
	$sql = "select * from ".$tableprefix."_texts where textid='commpre' and lang='$act_lang'";
	if(!$result = faqe_db_query($sql, $db)) {
	    die("<tr bgcolor=\"$heading_bgcolor\" align=\"center\"><td>Could not connect to the database.");
	}
	if($myrow=faqe_db_fetch_array($result))
	{
		$displaytext=stripslashes($myrow["text"]);
		$displaytext = undo_htmlspecialchars($displaytext);
		echo "<tr bgcolor=\"$group_bgcolor\"><td align=\"center\" colspan=\"2\">";
		echo "<font face=\"$FontFace\" size=\"$FontSize2\" color=\"$FontColor\">";
		echo $displaytext;
		echo "</font></td></tr>\n";
	}
?>
<form method="post" action="<?php echo $PHP_SELF?>">
<?php
	if(isset($onlynewfaq))
		echo "<input type=\"hidden\" name=\"onlynewfaq\" value=\"$onlynewfaq\">";
?>
<input type="hidden" name="<?php echo $langvar?>" value="<?php echo $act_lang?>">
<input type="hidden" name="faqnr" value="<?php echo $faqnr?>">
<input type="hidden" name="prog" value="<?php echo $prog?>">
<input type="hidden" name="catnr" value="<?php echo $catnr?>">
<input type="hidden" name="mode" value="post">
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<TD ALIGN="right" width="30%"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>"><?php echo $l_sendermail?>:</font></td>
<td align="left" width="70%">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<input type="text" name="email" size="30" maxlength="140"></font></td></tr>
<tr BGCOLOR="<?php echo $row_bgcolor?>" ALIGN="CENTER">
<TD ALIGN="right" width="30%" valign="top"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>"><?php echo $l_comment?>:</font>
<?php
if($mincommentlength>0)
	echo "<br><font face=\"$FontFace\" size=\"$FontSize4\" color=\"$FontColor\">($l_min $mincommentlength $l_characters)</font>";
?>
</td>
<td align="left" width="70%"><font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>"><textarea name="comment" cols="<?php echo $textareacols?>" rows="<?php echo $textarearows?>"></textarea></font></td></tr>
<tr bgcolor="<?php echo $actionbgcolor?>"><td colspan="2" align="center">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize2?>" color="<?php echo $FontColor?>">
<input type="submit" name="submit" value="<?php echo $l_submit?>"></font></td></tr>
</form>
<?php
}
?>
</table></td></tr></table>
<?php
if(($usecustomfooter==1) && ($copyrightpos==0))
{
	if(($footerfile) && ($footerfilepos==0))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
	echo $pagefooter;
	if(($footerfile) && ($footerfilepos==1))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
}
?>
<br>
<table align="center" bgcolor="<?php echo $copyrightbgcolor?>" width="<?php echo $TableWidth?>" border="0">
<tr><td align="center">
<font face="<?php echo $FontFace?>" size="<?php echo $FontSize4?>" color="<?php echo $FontColor?>">
<?php
if($showcurrtime)
{
	$displaytime=date("H:i");
	echo "$l_currtime $displaytime<br>";
}
if($showtimezone==1)
	echo "$l_timezone_note $server_timezone<br>";
echo "Generated by $copyright_url, $copyright_note";
?>
</td></tr></table>
<br>
<?php
if(($usecustomfooter==1) && ($copyrightpos==1))
{
	if(($footerfile) && ($footerfilepos==0))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
	echo $pagefooter;
	if(($footerfile) && ($footerfilepos==1))
	{
		if(is_phpfile($footerfile))
			include($footerfile);
		else
			file_output($footerfile);
	}
}
?>
</body></html>
