<?php
echo "This is a example footerfile";
?>