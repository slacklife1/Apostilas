#!/usr/local/bin/php
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
</HEAD>
<BODY BGCOLOR="#FFFFFF">
<div align="Center">
<? include("sendsms.inc"); ?>
</div>
</BODY>
</HTML>
