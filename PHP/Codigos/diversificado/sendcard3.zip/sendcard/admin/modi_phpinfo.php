<?php
$mod_name = "PHP Info";
?>