<?php
include("prepend.php");

$mod_description = "PHP info";
phpinfo();
?>
