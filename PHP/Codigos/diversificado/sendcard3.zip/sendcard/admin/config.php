<?php
define("DOCROOT", "");
define("SENDCARD_HOST", "");
define("SENDCARD_DIR", "sendcard/");
define("ADMIN_PASSWORD", "5f4dcc3b5aa765d61d8327deb882cf99");
$first_time = 1;
?>