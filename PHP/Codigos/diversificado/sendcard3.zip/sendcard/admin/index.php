<?php
include("prepend.php");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>sendcard administration</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<frameset cols="140,*" frameborder="YES" border="2" framespacing="0" rows="*" bordercolor="#333333"> 
  <frame name="menu" src="menu.php">
  <frame name="main" src="index2.php">
</frameset>
<noframes><body bgcolor="#ffffff">

</body></noframes>
</html>
