<?php 
$mod_name = "Statistics"

?>