<?php 
$mod_name = "Plugins"

?>