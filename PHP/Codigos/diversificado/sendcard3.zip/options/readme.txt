This directory contains alternative files, showing you how sendcard can be used.  These should just replace the existing file in the sendcard/ directory and those below it.

If you have any files which you would like to go here, please email me at sendcard@f2s.com

Contents:
Form.tpl - simple as in sendcard 1.2
This was created because I found that some people were still using sendcard 1.2 because they preferred the layout of its form, and didn't realise that it could be simplified.  If you are one of these people, you can use this file instead of the existing form.tpl.