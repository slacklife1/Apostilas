Full instructions may be found in the code's comments.

If you need support, please contact churmtom@hotmail.com

Interested in a desktop application that backs up a
COMPLETE MySQL database to an Excel File--without using ODBC?

Then try out my MySQL Database 2 Excel KonvertR program:
http://www.churm.com/konvertr/index.php