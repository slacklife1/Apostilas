Title: Dynamic Excel or Word File from MySQL
Description: This script takes the contents of a MySQL table and dumps it to either a dynamically-generated MS Word File (file with ending '.doc') or a dynamically-generated MS Excel File (file with ending '.xls'). You can place this script on any Unix/Linux or Windows Server running PHP & MySQL, but you have to access it using a browser on a Windows computer with Word or Excel installed on it. This script does not use COM objects and does not support multiple Worksheets in Excel. It can be used not only for creating complete dumps of MySQL tables (as Word or Excel files), but can be very easily modified to support just about any kind of select statement you'd like to use.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=625&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
