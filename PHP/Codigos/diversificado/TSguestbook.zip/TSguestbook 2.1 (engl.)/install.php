<!-- add style sheet -->
<link rel="stylesheet" href="guestbook.css" type="text/css">

<!-- display the link to add a new entry -->
<a href="form.php">Sign the guestbook!</a>

<?php

include("class_guestbook.php");

// if there is no start_entry specified, display the first entry
if (!isset($start_entry))
  $start_entry = 1;

$guestbook = new TSguestbook($REMOTE_ADDR);

// if the "submit"-button was pressed, a new entry has to be added before displaying the entries
if ($submit_entry == TRUE) {
  $guestbook->_addEntry($name, $email, $icq, $homepage, $entry);
}

// display a specified number of entries on one webpage
$MAX_PER_PAGE = 10;
$end = $guestbook->_displayEntry($start_entry, $MAX_PER_PAGE);

// display the link sto browse the guestbook
echo($guestbook->_displayLinks($start_entry, $end));

?>