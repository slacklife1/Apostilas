<table cellspacing="0" class="tableSingleEntry">
  <tr> 
    <td class="tdEntryNo"><?php echo($i + 1); ?></td>
    <td class="tdEntryDate"><?php echo($this->timestamp); ?> </td>
  </tr>
  <tr> 
    <td class="tdEntryHeadLeft">Name:</td>
    <td class="tdEntryHeadRight"><?php echo($this->name); ?></td>
  </tr>
  <tr> 
    <td class="tdEntryHeadLeft">E-mail:</td>
    <td class="tdEntryHeadRight">
      <a href="mailto:<?php echo($this->email); ?>"> <?php echo($this->email); ?></a>
    </td>
  </tr>
  <tr> 
    <td class="tdEntryHeadLeft">ICQ:</td>
    <td class="tdEntryHeadRight"><?php echo($this->icq); ?></td>
  </tr>
  <tr> 
    <td class="tdEntryHeadLeft">Homepage:</td>
    <td class="tdEntryHeadRight">
      <a href="http://<?php echo($this->homepage); ?>" target="_blank"> <?php echo($this->homepage); ?></a>
    </td>
  </tr>
  <tr> 
    <td colspan="2" class="tdEntryUserInput"><?php echo($this->entry); ?></td>
  </tr>
  <tr> 
    <td colspan="2" class="tdEntryIp">IP: <?php echo($this->ip); ?></td>
  </tr>
</table>