<link rel="stylesheet" href="guestbook.css" type="text/css">
<form name="form" method="post" action="demo.php">
  <table border=0 cellpadding="0" cellspacing="0">
    <tr> 
      <td colspan=2 class="tdFormHeadline">New guestbook entry:</td>
    </tr>
    <tr> 
      <td class="tdFormHeadLeft">Name:</td>
      <td class="tdFormHeadRight"><input type="text" name="name" size="30" class="formUserInput"></td>
    </tr>
    <tr> 
      <td class="tdFormHeadLeft">E-Mail:</td>
      <td class="tdFormHeadRight"><input type="text" name="email" size="30" class="formUserInput"></td>
    </tr>
    <tr> 
      <td class="tdFormHeadLeft">ICQ:</td>
      <td class="tdFormHeadRight"><input type="text" name="icq" size="30" class="formUserInput"></td>
    </tr>
    <tr> 
      <td class="tdFormHeadLeft">Homepage:</td>
      <td class="tdFormHeadRight"><input type="text" name="homepage" size="30" class="formUserInput"></td>
    </tr>
    <tr> 
      <td class="tdFormBodyLeft">&nbsp;</td>
      <td class="tdFormBodyRight">
        <textarea name="entry" rows=10 cols=35 class="formUserInput"></textarea>
        <br>
        <br>
        <input type="submit" name="submit_entry" value="Send" class="formButton">
      </td>
    </tr>
  </table>
</form>