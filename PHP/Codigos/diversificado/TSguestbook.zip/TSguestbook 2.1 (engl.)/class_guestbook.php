<?php

/********************************************
*  TSguestbook 2.0                          *
*                                           * 
*  by Thomas Schuster                       *
*  http://www.TSinter.net                   *
*                                           *
*  This class provides the functionality    *
*  of a simple guestbook script. The look   *
*  can be modified through html-templates.  *
*  The data is stored in one text file.     *
*                                           *
********************************************/ 


class TSguestbook extends SupportFunctions {

  # EDIT THE NAME OF YOUR WEBPAGE #
  var $pageName = "demo.php";
  
  // define datafiles
  var $guestbook_dat = "guestbook.dat";
  var $entry_html_code = "html_entry.php";

  
  // define variables
  var $name;
  var $email;
  var $icq;
  var $homepage;
  var $ip;
  var $entry;
  var $timestamp;
  var $admin_mail = "your email address";
  
  
  function TSguestbook($ip) {
    $this->ip = $ip;
  }

  
  // add new entry
  function _addEntry($name, $email, $icq, $homepage, $entry) {
    $this->name = stripslashes($name);
    $this->email = $email;
    $this->icq = $icq;
    $this->homepage = $homepage;
    $this->entry = stripslashes($this->_replace_nl($entry));
    $this->timestamp = date('d.m.Y \u\m H:i');
    $line = $this->name."|".$this->email."|".$this->icq."|".$this->homepage."|"
            .$this->ip."|".$this->entry."|".$this->timestamp."|\r\n";
    $this->_writeLine($this->guestbook_dat, $line, "a");
    $this->_sendMail();
    return 1;
  }


  // display entries
  function _displayEntry($start_entry, $MAX_PER_PAGE) {
    $end = FALSE;
    $guestbook_array = file($this->guestbook_dat);
    for ($i = sizeof($guestbook_array) - $start_entry, $j = $MAX_PER_PAGE; $i >= 0 && $j > 0; $i--, $j--) {
      $guestbook_line = explode("|", $guestbook_array[$i]);

      # empty strings must be substituted by " " to display the HTML correctly
      for ($k = 0; $k < sizeof($guestbook_line); $k++) {
        if (!strcmp($guestbook_line[$k], ""))
          $guestbook_line[$k] = " ";
      }

      $this->name = $guestbook_line[0];
      $this->email = $guestbook_line[1];
      $this->icq = $guestbook_line[2];
      $this->homepage = $guestbook_line[3];
      $this->ip = $guestbook_line[4];
      $this->entry = $guestbook_line[5];
      $this->timestamp = $guestbook_line[6];

      # check, if there are any older entries in the datafile
      if ($i < 1)
        $end = TRUE;

      include($this->entry_html_code);
           
    }        
    return $end;
  }
  


  // display links to browse the entries
  function _displayLinks($start_entry, $end) {

    # this will add a link to newer entries, if there are some
    if (($back = $start_entry - 10) > 0) {
      $link = "<a href=\"$this->pageName?start_entry=$back\">Next entries</a>   ";
    }

    # this will add a link to older entries, if there are some
    if (!$end) {
      $start_entry += 10;
      $link .= "<a href=\"$this->pageName?start_entry=$start_entry\">Previous entries</a>";
    }

    return $link;
  }



  // send email-notification
  function _sendMail() {
    $mail_string = "There is a new guestbook entry.\n\nSent
                    by $this->name ($this->email) on $this->timestamp:\n\n$this->entry";
    mail ($this->admin_mail, "New guestbook entry", $mail_string, "From: Your guestbook");
    return 1;
  }


  // check entry
  function _checkEntry($entry) {
    $this->entry = $entry;
    if ($entry == "") {
      # user pressed the return key instead of the tabulator key, so the entry is empty
      return 0;
    } else return 1;
  }

}

?>

