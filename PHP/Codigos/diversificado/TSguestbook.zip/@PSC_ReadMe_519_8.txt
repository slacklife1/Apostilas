Title: TSguestbook 2.1
Description: This guestbook script is designed object orientated. The features of the guestbook are specified in class_guestbook.php. On demo.php a new guestbook object is created and different operations are processed via this object (displaying the entries, adding a new entry...). Some basic functionality is given through class_support.php. 
Code and layout are separated through templates. The data is stored in a text file, there is no need for a database.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=519&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
