<?php
show_source("class/class.whois.php");
?>