<?php
/*
polish version 1.00 by Wojciech Dorosz
<wojtek@serwisy.net>
http://www.serwisy.net
v. 1.02 updated 2002-01-14 WoJD
*/

	$charset                = "iso-8859-1";

	$_sign_in_mailinglist   = "subskrybcja";
	$_sign_out_mailinglist  = "rezygnacja";

	$_sign_in_newsletter    = "zapisz si�";
	$_sign_out_newsletter   = "wypisz si�";

	$_birth_year            = "rok urodzenia";
	$_profession            = "zaw�d";
	$_nationality           = "narodowo��";
	$_email_address         = "e-mail";

	$_enter_birthdate       = "prosimy o wpisanie roku urodzenia !";
	$_enter_profession      = "prosimy o wpisanie zawodu !";
	$_enter_nationality     = "prosimy o wpisanie narodowo�ci !";
	$_enter_email           = "prosimy o wpisanie adresu e-mail !";

	$_ml_contains           = "lista e-mailowa";
	$_entries               = "wpisy";
	$_recipient             = "odbiorcy";
	$_domain                = "domeny";
	$_sort_by_user_az       = "sortuj wg odbiorcy (A-Z)";
	$_sort_by_user_za       = "sortuj wg odbiorcy (Z-A)";
	$_sort_by_domain_az     = "sortuj wg domeny (A-Z)";
	$_sort_by_domain_za     = "sortuj wg domeny (Z-A)";
	$_enabled               = "aktywny";
	$_disabled              = "nieaktywny";
	$_enable                = "w��cz";
	$_disable               = "wy��cz";
	$_delete                = "skasuj";

	$sign_error             = "B��d przy dodawaniu danych do bazy!<br>Spr�buj p�niej!";

	$sign_in_mail_txt       = "Kliknij na link, aby potwierdzi� ch�� subskrybowania\n"
	                        . "newslettera " . $newsletter_title . " !\n\n";

	$sign_in_mail_subject   = "Subskrybuj ". $newsletter_title;

	$sign_out_mail_txt      = "Kliknij na link, aby potwierdzi� ch�� rezygnacji z subskrybcji\n"
   				. "newslettera " . $newsletter_title . " !\n\n";

	$sign_out_mail_subject  = "Zrezygnuj z subskrybcji ". $newsletter_title;

        $signed_in_txt          = "<p>Tw�j adres e-mail zosta� dodany do naszej listy!</p>";
        $signed_out_txt         = "<p>Tw�j adres e-mail zosta� usuni�ty z naszej listy!</p>";
	$not_in_list_error      = "<p>B��d - tego adresu nie ma na li�cie oczekuj�cych!<br><br>"
	                        . "By� mo�e Tw�j adres zosta� ju� dodany lub usuni�ty ?</p>";

	$data_protection_info   = "Oznaczone gwiazdk� pola potrzebne s� nam wy��cznie do wewn�trznych cel�w statystycznych i marketingowych.<br>"
                                . "Gwarantujemy, �e nie udost�pnimy komukolwiek uzyskanych tu danych "
	                        . "bez specjalnego zezwolenia z Pa�stwa strony!<br>";

	$_kill_entry            = "Usu� wpis";
	$_enable_entry          = "Aktywuj wpis";
	$_disable_entry         = "Deaktywuj wpis";

	$newsletter_sign_out_info = "Tutaj mo�esz zrezygnowa� z subsktybcji "
	                         . "&quot;".$newsletter_title."&quot;<br>";

	$wait_for_mail          = "Dzi�kujemy za zainteresowanie &quot".$newsletter_title."&quot!<br><br>"
	                        ."W ci�gu kilku minut zostanie przes�any e-mail z linkiem do strony z potwierdzeniem subskrybcji/rezygnacji. <br>"
	                        ."Prosimy o uwa�ne przeczytanie jego tre�ci !";

	$newsletter_sign_in_info= "Witamy!<br><br>"
   				." najwa�niejsze informacje o nowo�ciach"
   				." otrzymacie Pa�stwo wprost do swojej skrzynki!.<br>";

	$newsletter_info        = "B�dziemy Pa�stwa informowa� o nowo�ciach w kukbuku izy, "
	                        . "nowych stronach kulinarnych i ciekawych wydarzeniach, zwi�zanych z kulinarnym Internetem...";

	$_list_admin            = "administruj subskrybentami (usu� z listy)";

	$_post_to_mailinglist   = "wy�lij wiadomo�c do listy emailowej";
	$_skipped_as_disabled   = "pomini�ty (nieaktywny)";
	$_message_sent          = "<b>wys�ano</b>";
	$_message_not_sent      = '<b><font color="red">B��d</font></b>: skrypt nie mo�e wys�a� newslettera !!!';
	$_sent                  = "wys�ane";
	$_of                    = "z";
	$_post_to_ml            = "wy�lij newsletter(y)";
	$_subject               = "temat";
	$_message               = "wiadomo��";
	$_check_for_updates	= "sprawd� aktualizacje";

	$_recipients_group      = "group of recipients (mailinglist)";
	$_copy                  = "copy to";
	$_copy_entry            = "copy entry";
	$_add                   = "add";
	$_added_to_list         = "added to mailinglist";
	$_archived_newsletters  = "newsletters archived";
	$_newsletter_archive    = "Newsletter Archive";

	$_warning               = "Warning!";
	$_last_posting_failed   = "Last time the posting was broken before mail could be sent to ALL recipients.";
	$_continue_mailing      = "Do you want post the remaining messages?";
	$_yes                   = "Yes";
	$_no                    = "No";

?>