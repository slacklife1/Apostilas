<?php
/*
Dutch Template by Jan-Ruben van Schie [jr@jrwebdsign.nl]
JRwebDsign.
http://www.jrwebdsign.nl
*/

	$charset                = "iso-8859-1";

	$_sign_in_mailinglist   = "Toevoegen aan mailinglist";
	$_sign_out_mailinglist  = "Verwijderen uit mailinglist";

	$_sign_in_newsletter    = "Aanmelden";
	$_sign_out_newsletter   = "Uitschrijven";

	$_birth_year            = "Geboortejaar";
	$_profession            = "Opleiding / beroep";
	$_nationality           = "Nationaliteit";
	$_email_address         = "Emailadres";

	$_enter_birthdate       = "Vul alstublieft uw geboortejaar in.";
	$_enter_profession      = "Vul alstublieft uw opleiding/beroep in.";
	$_enter_nationality     = "Geef alstublieft aan welke nationaliteit u hebt.";
	$_enter_email           = "Vul  alstublieft uw volledige en correcte E-mailadres in.";

	$_ml_contains           = "Mailinglist bevat";
	$_entries               = "aanmeldingen";
	$_recipient             = "Ontvangers";
	$_domain                = "Domein";
	$_sort_by_user_az       = "Sorteren op ontvanger (A-Z)";
	$_sort_by_user_za       = "Sorteren op ontvanger (Z-A)";
	$_sort_by_domain_az     = "Sorteren op domein (A-Z)";
	$_sort_by_domain_za     = "Sorteren op domein (Z-A)";
	$_enabled               = "Geactiveerd";
	$_disabled              = "Ge�nactiveerd";
	$_enable                = "Activeren";
	$_disable               = "Inactiveren";
	$_delete                = "Verwijderen";

	$sign_error             = "Er is een fout opgetreden tijdens het aan-/afmelden.<br>Probeer het alstublieft later nog eens!";

	$sign_in_mail_txt       = "Door middel van een muisklik op de volgende link kunt u bevestigen, \n"
	                        . "dat u " . $newsletter_title . " in het vervolg wenst te ontvangen!\n\n";

	$sign_in_mail_subject   = "Uw aanmelding voor: ". $newsletter_title;

	$sign_out_mail_txt      = "Door middel van een muisklik op de volgende link kunt u bevestigen,\n"
				. "dat u " . $newsletter_title . " in het vervolg niet meer wenst te ontvangen!\n\n";

	$sign_out_mail_subject  = "Uw afmelding bij: ". $newsletter_title;

	$signed_in_txt          = "<p>Uw Emailadres is met succes aan de mailinglist toegevoegd.</p>";
	$signed_out_txt         = "<p>Uw Emailadres is met succes uit de mailinglist verwijderd.</p>";
	$not_in_list_error      = "<p>Foutmelding: Uw Emailadres komt niet voor in onze lijst van in- of uit te schrijven Emailadressen.<br><br>"
	                        . "Waarschijnlijk is het adres reeds toegevoegd / verwijderd. </p>";

	$_post_to_ml            = "Versturen aan mailinglist ...";
	$_subject               = "Onderwerp";
	$_message               = "Berichttekst";
	$data_protection_info   = "<font size=1>De door ons aan u gevraagde gegevens dienen alleen statistische doeleinden. <BR>"
                                . "Wij garanderen u dat uw persoonlijke gegevens alleen intern verwerkt,"
	                        . "en nooit zonder uw toestemming aan derden verstrekt, zullen worden.</font>";

	$_kill_entry            = "Verwijder toegevoegde";
	$_enable_entry          = "Activeer toevoeging";
	$_disable_entry         = "Inactiveer toevoeging";

	$newsletter_sign_in_info= "Hartelijk welkom!<br><br>Op deze pagina kunt u zich aanmelden voor een abonnement op<br>"
   				. "&quot;".$newsletter_title."&quot; , en u daarmee voortaan gemakkelijk per Email over alle belangrijke<br>"
				. "nieuwigheden laten informeren.";
	$newsletter_sign_out_info = "Hartelijk welkom!<BR><BR>Op deze pagina kunt u zich afmelden voor <br>&quot;"
	.$newsletter_title."&quot; om de nieuwsbrief in het vervolg niet meer te ontvangen.<br>";

	$wait_for_mail          = "Bedankt voor uw interesse in &quot".$newsletter_title."&quot!<br><br>"
	                        . "Binnen een zeer korte tijd zult u van ons een Email ter bevestiging ontvangen.<br>"
	                        . "Lees deze Email alstublieft nauwkeurig door, want hierin staat hoe u uw aan-/afmelding van onze mailinglist moet bevestigen.";

	$newsletter_info        = "Met &quot;".$newsletter_title."&quot; blijft u per Email op een eenvoudige manier op de hoogte van alle belangrijke<br>"
	                        . "informatie rondom onze internetpagina.";

	$_list_admin            = "Abonnementen bijwerken (toevoegen/verwijderen van de mailinglist)";

	$_post_to_mailinglist   = "stuur bericht naar mailinglist";
	$_skipped_as_disabled   = "Overgeslagen (wegens inactiviteit)";
	$_message_sent          = "Bericht verstuurd";
	$_message_not_sent      = "<b><font color=\"red\">Foutmelding</font></b>: Het script kon het bericht niet versturen!!!";
	$_sent			= "Verstuurd";
	$_of			= "Van";
	$_check_for_updates	= "Naar actuele updates zoeken";
	$_of                    = "van";
	$_last                  = "Vorige";
	$_next                  = "Volgende";

	$_recipients_group      = "Ontvangersgroep (Mailinglist)";
	$_copy                  = "Kopi�ren naar";
	$_copy_entry            = "Kopieer de aanmelding";
	$_add                   = "Toevoegen";
	$_added_to_list         = "is aan de mailinglist toegevoegd";
	$_archived_newsletters  = "De nieuwsbrief is opgenomen in het archief.";
	$_newsletter_archive    = "Nieuwsbrieven archief";

	$_warning               = "Warning!";
	$_last_posting_failed   = "Last time the posting was broken before mail could be sent to ALL recipients.";
	$_continue_mailing      = "Do you want post the remaining messages?";
	$_yes                   = "Yes";
	$_no                    = "No";

?>