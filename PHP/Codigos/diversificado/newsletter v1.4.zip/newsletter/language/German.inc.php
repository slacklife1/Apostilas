<?php

	$charset                = "iso-8859-1";

	$_sign_in_mailinglist   = "In die Abonenntenliste eintragen";
	$_sign_out_mailinglist  = "Aus der Abonnentenliste austragen";

	$_sign_in_newsletter    = "Abonnieren";
	$_sign_out_newsletter   = "Abbestellen";

	$_birth_year            = "Geburtsjahr";
	$_profession            = "berufl. T�tigkeit";
	$_nationality           = "Nationalit�t / Herkunft";
	$_email_address         = "e-mail-Adresse";

	$_enter_birthdate       = "Bitte geben Sie Ihr Geburtsjahr an !";
	$_enter_profession      = "Bitte geben Sie Ihre Berufsbezeichnung an !";
	$_enter_nationality     = "Bitte geben Sie Ihre Nationalit�t an !";
	$_enter_email           = "Bitte geben Sie Ihre vollst�ndige e-mail-Adresse an !";

	$_ml_contains           = "Mailingliste enth�lt";
	$_entries               = "Eintr�ge";
	$_recipient             = "Empf�nger";
	$_domain                = "Domain";
	$_sort_by_user_az       = "Nach Empf�nger sortieren (A-Z)";
	$_sort_by_user_za       = "Nach Empf�nger sortieren (Z-A)";
	$_sort_by_domain_az     = "Nach Domain sortieren (A-Z)";
	$_sort_by_domain_za     = "Nach Domain sortieren (Z-A)";
	$_enabled               = "aktiviert";
	$_disabled              = "deaktiviert";
	$_enable                = "Aktivieren";
	$_disable               = "Deaktivieren";
	$_delete                = "L�schen";

	$sign_error             = "Fehler beim An-/Abmelden!<br>Bitte versuchen Sie es sp�ter noch einmal!";

	$sign_in_mail_txt       = "Mit einem Klick auf den folgenden Link best�tigen Sie,\n"
	                        . "dass Sie " . $newsletter_title . " bestellen m�chten.\n\n";

	$sign_in_mail_subject   = "Ihre Eintragung bei ". $newsletter_title;

	$sign_out_mail_txt      = "Mit einem Klick auf den folgenden Link best�tigen Sie,\n"
	                        . "dass Sie " . $newsletter_title . " abbestellen m�chten.\n\n";

	$sign_out_mail_subject  = "Ihre Abmeldung bei ". $newsletter_title;

	$signed_in_txt          = "<p>Ihre e-mail-Adresse wurde in unsere Mailingliste aufgenommen!</p>";
	$signed_out_txt         = "<p>Ihre e-mail-Adresse wurde aus unserer Mailingliste entfernt!</p>";
	$not_in_list_error      = "<p>Fehler: Sie stehen nicht in unserer An-/Abmeldeliste!<br><br>"
	                        . "Wahrscheinlich wurde Ihre Adresse bereits in die Mailingliste ein- / ausgetragen?</p>";

	$_post_to_ml            = "Senden an Mailingliste...";
	$_subject               = "Betreff";
	$_message               = "Nachricht";
	$data_protection_info   = '<font size="1">Die zus&auml;tzlich erfassten Daten dienen ausschlie&szlig;lich statistischen Zwecken.<br>'
	                        . "Wir garantieren Ihnen, dass Ihre pers&ouml;nlichen Daten nur intern verwendet<br>"
	                        . ' und nicht ohne Ihre Zustimmung an Dritte weitergegeben werden!</font>';
	$_kill_entry            = "L�sche Eintrag";
	$_enable_entry          = "Aktiviere Eintrag";
	$_disable_entry         = "Deaktiviere Eintrag";

	$newsletter_sign_in_info= "Herzlich Willkommen!<br><br>Auf dieser Seite k&ouml;nnen Sie sich in die Abonnentenliste f&uuml;r den Newsletter<br>"
   				."&quot;".$newsletter_title."&quot; eintragen, und sich fortan bequem per e-Mail &uuml;ber alle wichtigen<br>"
    				."Neuigkeiten informieren lassen.";



	$newsletter_sign_out_info =
	"Auf dieser Seite k&ouml;nnen Sie sich aus der Abonnentenliste f&uuml;r den Newsletter<br>&quot;"
	.$newsletter_title."&quot; wieder austragen<br>";

	$wait_for_mail          = "Vielen Dank f�r Ihr Interesse f�r &quot;".$newsletter_title."&quot; !<br><br>"
	                        ."Sie sollten in K�rze eine Best�tigungs-email von uns erhalten. <br>"
	                        ."Bitte lesen Sie diese e-Mail aufmerksam durch !";

	$newsletter_info        = "Mit &quot;".$newsletter_title."&quot; erhalten Sie alle wichtigen<br>"
	                        . "Informationen rund um unsere Website bequem per e-mail...";

	$_list_admin            = "Abonnenten verwalten (hinzuf&uuml;gen/l&ouml;schen)";
	$_post_to_mailinglist   = "Nachricht an die Mailingliste senden";
	$_skipped_as_disabled   = "�bersprungen (weil deaktiviert)";
	$_message_sent          = "Nachricht verschickt";
	$_message_not_sent      = "<b><font color=\"red\">Fehler</font></b>: Das Skript konnte die Nachricht nicht versenden!!!";
	$_sent			= "verschickt";
	$_of			= "von";
	$_check_for_updates	= "Nach aktuellen Updates suchen";
	$_of                    = "von";
	$_last                  = "letzte";
	$_next                  = "n�chste";

	$_recipients_group      = "Empf�ngergruppe (Mailingliste)";
	$_copy                  = "Kopieren nach";
	$_copy_entry            = "Kopiere Eintrag";
	$_add                   = "Hinzuf�gen";
	$_added_to_list         = "zur Mailingliste hinzugef�gt";
	$_archived_newsletters  = "Newsletter archiviert";
	$_newsletter_archive    = "Newsletter-Archiv";

	$_warning               = "Achtung!";
	$_last_posting_failed   = "Beim letzen Mal wurde der Sendevorgang unterbrochen, bevor ALLE Empf�nger angemailt werden konnten.";
	$_continue_mailing      = "M�chten Sie den Vorgang fortsetzen und die restlichen Nachrichten noch verschicken?";
	$_yes                   = "Ja";
	$_no                    = "N�";

?>