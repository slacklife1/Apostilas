<?php
/*
Hungarian Template by Jozsef Tamas Herczeg [info@soft-trans.hu]
Soft-Trans, Inc.
http://www.soft-trans.hu
*/
	$charset                = "iso-8859-2";

	$_sign_in_mailinglist   = "H�rlev�l megrendel�se";
	$_sign_out_mailinglist  = "H�rlev�l lemond�sa";

	$_sign_in_newsletter    = "Megrendel�s";
	$_sign_out_newsletter   = "Lemond�s";

	$_birth_year            = "Sz�l. �v";
	$_profession            = "Munkak�r";
	$_nationality           = "Orsz�g";
	$_email_address         = "E-mail c�m";

	$_enter_birthdate       = "�rja be a sz�let�si �vsz�m�t!";
	$_enter_profession      = "�rja be a munkak�r�t!";
	$_enter_nationality     = "�rja be, hogy mely orsz�gban �l!";
	$_enter_email           = "�rja be az e-mail c�m�t!";

	$_ml_contains           = "A h�rlev�l adatb�zisa tartalma";
	$_entries               = "t�tel";
	$_recipient             = "c�mzett";
	$_domain                = "tartom�ny";
	$_sort_by_user_az       = "rendez�s c�mzett szerint (A-Z)";
	$_sort_by_user_za       = "rendez�s c�mzett szerint (Z-A)";
	$_sort_by_domain_az     = "rendez�s tartom�ny szerint (A-Z)";
	$_sort_by_domain_za     = "rendez�s tartom�ny szerint (Z-A)";
	$_enabled               = "enged�lyez�s";
	$_disabled              = "tilt�s";
	$_enable                = "enged�lyez�s";
	$_disable               = "tilt�s";
	$_delete                = "t�rl�s";

	$sign_error             = "Hiba t�rt�nt a h�rlev�l megrendel�sekor/lemond�sakor!<br>Pr�b�lkozzon k�s�bb!";

	$sign_in_mail_txt       = "Tisztelt �rdekl�d�!\n\nKattintson a k�vetkez� hivatkoz�sra, amennyiben j�v� k�v�nja hagyni\n"
				. "a " . $newsletter_title . " megrendel�s�t!\n\n";

	$sign_in_mail_subject   = "Megrendel�s: ". $newsletter_title;

	$sign_out_mail_txt      = "Tisztelt �rdekl�d�!\n\nKattintson a k�vetkez� hivatkoz�sra, amennyiben j�v� k�v�nja hagyni\n"
				. "a " . $newsletter_title . " lemond�s�t!\n\n";

	$sign_out_mail_subject  = "Lemond�s: ". $newsletter_title;

	$signed_in_txt          = "<p>E-mail c�m�nek nyilv�ntart�sba v�tele megt�rt�nt!</p>";
	$signed_out_txt         = "<p>E-mail c�m�nek t�rl�se a nyilv�ntart�sunkb�l megt�rt�nt!</p>";
	$not_in_list_error      = "<p>Hiba: Az �n e-mail c�me nem szerepel a nyilv�ntart�sunkban!<br><br>"
				. "Az �n adatait minden bizonnyal m�r felvett�k/t�r�lt�k adatb�zisunkb�l.</p>";

	$data_protection_info   = "Ezekre a kieg�sz�t� adatokra csak statisztikai c�lb�l van sz�ks�g�nk.<br>"
				. "Garant�ljuk, hogy az �n enged�lye n�lk�l nem adjuk �t harmadik f�lnek<br>"
				. "a szem�lyes adatait!<br>";

	$_kill_entry            = "Kiz�r�s";
	$_enable_entry          = "Enged�lyez�s";
	$_disable_entry         = "Tilt�s";

	$newsletter_sign_out_info = "H�rlevel�nket ezen az oldalon mondhatja le";

	$wait_for_mail          = "�rdekl�d�s�t k�sz�nj�k<br><br>"
				."N�h�ny percen bel�l a megadott e-mail c�men �n megkapja j�v�hagy�si k�r�s�nket. <br>"
				."K�rj�k, hogy figyelmesen olvassa el az �zenetet!";

	$newsletter_sign_in_info= "�dv�z�lj�k!<br><br>Ezen az oldalon rendelheti meg h�rlevel�nket.<br>"
				."Megrendel�ink e-mailben megkapnak minden fontos inform�ci�t.<br>";

	$newsletter_info        = "A &quot;".$newsletter_title."&quot; j�volt�b�l e-mailben kaphat<br>"
				. "t�j�koztat�st �jdons�gainkr�l, akci�inkr�l, fejleszt�seinkr�l...";

	$_list_admin            = "a megrendel�k adminisztr�ci�ja (elt�vol�t�s a list�r�l)";

	$_post_to_mailinglist   = "�zenet k�ld�se";
	$_skipped_as_disabled   = "kihagyott (letiltott)";
	$_message_sent          = "<b>elk�ldve</b>";
	$_message_not_sent      = '<b><font color="red">Hiba</font></b>: a parancsf�jl nem tudta elk�ldeni az �zenetet !!!';
	$_sent                  = "elk�ldve";
	$_of                    = "/";
	$_post_to_ml            = "H�rlev�l k�ld�se";
	$_subject               = "T�rgy";
	$_message               = "�zenet";
	$_check_for_updates     = "Leg�jabb v�ltozat keres�se";
	$_of                    = "/";
	$_last                  = "utols�";
	$_next                  = "k�vetkez�";

	$_recipients_group      = "group of recipients (mailinglist)";
	$_copy                  = "copy to";
	$_copy_entry            = "copy entry";
	$_add                   = "add";
	$_added_to_list         = "added to mailinglist";
	$_archived_newsletters  = "newsletters archived";
	$_newsletter_archive    = "Newsletter Archive";

	$_warning               = "Warning!";
	$_last_posting_failed   = "Last time the posting was broken before mail could be sent to ALL recipients.";
	$_continue_mailing      = "Do you want post the remaining messages?";
	$_yes                   = "Yes";
	$_no                    = "No";

?>