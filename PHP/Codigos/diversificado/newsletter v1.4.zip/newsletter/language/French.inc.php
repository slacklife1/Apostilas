<?php

	$charset                = "iso-8859-1";

	$_sign_in_mailinglist   = "S'abonner";
	$_sign_out_mailinglist  = "Se d�sabonner";

	$_sign_in_newsletter    = "S'abonner";
	$_sign_out_newsletter   = "Se d�sabonner";

	$_birth_year            = "Ann�e de naissance";
	$_profession            = "Profession";
	$_nationality           = "Nationalit� / Origine";
	$_email_address         = "Adresse e-mail";

	$_enter_birthdate       = "Indiquez votre ann�e de naissance s.v.p. !";
	$_enter_profession      = "Indiquez votre profession s.v.p !";
	$_enter_nationality     = "Indiquez votre nationalit� s.v.p !";
	$_enter_email           = "Donnez votre adresse e-mail compl�te s.v.p. !";

	$_ml_contains           = "La mailing liste contient";
	$_entries               = "Entr�es";
	$_recipient             = "Destinataire";
	$_domain                = "Domaine";
	$_sort_by_user_az       = "Ordonner d'apr�s les destinataires (A-Z)";
	$_sort_by_user_za       = "Ordonner d'apr�s les destinataires (Z-A)";
	$_sort_by_domain_az     = "Ordonner d'apr�s les domaines (A-Z)";
	$_sort_by_domain_za     = "Ordonner d'apr�s les domaines (Z-A)";
	$_enabled               = "activ�";
	$_disabled              = "d�activ�";
	$_enable                = "Activer";
	$_disable               = "D�activer";
	$_delete                = "Effacer";

	$sign_error             = "Une erreur est survenue lors de votre inscription/d�sinscription!<br>Retentez un peu plus tard s.v.p. !";

	$sign_in_mail_txt       = "Cliquez sur le lien qui suit pour confirmer\n"
	                        . "que vous souhaitez recevoir " . $newsletter_title . ".\n\n";

	$sign_in_mail_subject   = "Votre inscription � ". $newsletter_title;

	$sign_out_mail_txt      = "Cliquez sur le lien qui suit pour confirmer\n"
	                        . "que vous souhaitez vous d�sabonner � " . $newsletter_title . " .\n\n";

	$sign_out_mail_subject  = "Votre d�sabonnement � ". $newsletter_title;

	$signed_in_txt          = "<p>Votre adresse e-mail a �t� enregistr�e dans notre liste d'adresses!</p>";
	$signed_out_txt         = "<p>Votre adresse e-mail a �t� effac�e de notre liste d'adresses!</p>";
	$not_in_list_error      = "<p>Erreur: votre adresse ne figure pas dans notre liste d'inscriptions/de d�sinscriptions !<br><br>"
	                        . "Votre adresse a probablement d�j� �t� ajout�e �/effac�e de notre liste d'adresses ?</p>";

	$_post_to_ml            = "Envoyer aux abonn�s...";
	$_subject               = "Sujet";
	$_message               = "Message";
	$data_protection_info   = '<font size="1">Les donn�es demand�es sont uniquement enregistr�es � des fins statistiques.<br>'
	                        . "Nous vous certifions que vos donn�es ne servirons qu'� usage interne<br>"
	                        . ' et ne seront pas transmises � un tiers sans votre accord !</font>';
	$_kill_entry            = "Effacer l'entr�e";
	$_enable_entry          = "Activer l'entr�e";
	$_disable_entry         = "D�sactiver l'entr�e";

	$newsletter_sign_in_info= "Bienvenue!<br><br>Sur cette page, vous pouvez vous inscrire � la liste des abonn�s � la newsletter"
   				."&quot;".$newsletter_title."&quot;, et recevoir confortablement par e-Mail toutes les nouvelles importantes "
    				."concernant notre site.";

	$newsletter_sign_out_info = "Sur cette page, vous pouvez vous d�sabonner � la lettre<br>&quot;"
	                            .$newsletter_title."&quot;<br>";

	$wait_for_mail          = "Merci de votre int�r�t pour &quot;".$newsletter_title."&quot; !<br><br>"
	                        ."Vous devriez recevoir d'ici peu un mail de confirmation. <br>"
	                        ."Lisez-le attentivement s.v.p !";

	$newsletter_info        = "Avec &quot;".$newsletter_title."&quot;, vous �tes mis au courant<br>"
	                        . "de toutes les informations concernant notre site, confortablement par e-mail...";

	$_list_admin            = "administration des abonnen�s (ajouter/effacer)";
	$_post_to_mailinglist   = "Envoyer le message aux abonn�s";
	$_skipped_as_disabled   = "Ignor� (parce que d�activ�)";
	$_message_sent          = "Message envoy�";
	$_message_not_sent      = "<b><font color=\"red\">Erreur</font></b>: le script n'a pas pu envoyer le message!!!";
	$_sent			= "envoy�";
	$_of			= "de";
	$_check_for_updates	= "Chercher des actualisations";
	$_of                    = "de";
	$_last                  = "pr�c�dent";
	$_next                  = "suivant";

	$_recipients_group      = "Gruppe des destinataires (Mailingliste)";
	$_copy                  = "Copier vers";
	$_copy_entry            = "Copier l'entr�e";
	$_add                   = "Ajouter";
	$_added_to_list         = "Ajout� � la liste de mails";
	$_archived_newsletters  = "Newsletter archiviert";
	$_newsletter_archive    = "Newsletter-Archiv";	

	$_warning               = "Warning!";
	$_last_posting_failed   = "Last time the posting was broken before mail could be sent to ALL recipients.";
	$_continue_mailing      = "Do you want post the remaining messages?";
	$_yes                   = "Yes";
	$_no                    = "No";

?>