<?php
/*
Italian Template by Giovanni Scopel [skop@keymail.net]
*/
	$charset                = "iso-8859-1";

	$_sign_in_mailinglist   = "Iscriviti alla mailinglist";
	$_sign_out_mailinglist  = "Rimuoviti dalla mailinglist";

	$_sign_in_newsletter    = "Iscriviti";
	$_sign_out_newsletter   = "Rimuoviti";

	$_birth_year            = "Anno di Nascita";
	$_profession            = "Professione";
	$_nationality           = "Nazionalit�";
	$_email_address         = "Indirizzo e-mail";

	$_enter_birthdate       = "Per favore inserisci il tuo anno di nascita!";
	$_enter_profession      = "Per favore inserisci la tua professione!";
	$_enter_nationality     = "Per favore inserisci la tua nazionalit�!";
	$_enter_email           = "Per favore inserisci il tuo indirizzo e-mail!";

	$_ml_contains           = "la Mailinglist contiene";
	$_entries               = "Inserimenti";
	$_recipient             = "Contenuti";
	$_domain                = "dominio";
	$_sort_by_user_az       = "Ordina per contenuti (A-Z)";
	$_sort_by_user_za       = "Ordina per contenuti (Z-A)";
	$_sort_by_domain_az     = "Ordina per dominio (A-Z)";
	$_sort_by_domain_za     = "Ordina per dominio (Z-A)";
	$_enabled               = "Abilitato";
	$_disabled              = "Disabilitato";
	$_enable                = "Abilita";
	$_disable               = "Disabilita";
	$_delete                = "Elimina";

	$sign_error             = "Errore nella procedura di iscrizione / rimozione!<br>Per favore riprova dopo!";

	$sign_in_mail_txt       = "Clicca il link per confermare l'iscrizione\n"
	                        . " alla mailing list " . $newsletter_title . " !\n\n";

	$sign_in_mail_subject   = "Iscriviti in ". $newsletter_title;

	$sign_out_mail_txt      = "Clicca il link per confermare la rimozione\n"
							. " dalla mailinglist " . $newsletter_title . "!\n\n";

	$sign_out_mail_subject  = "Rimuoviti ". $newsletter_title;

	$signed_in_txt          = "<p>Il tuo indirizzo e-mail � stato aggiunto alla  mailinglist!</p>";
	$signed_out_txt         = "<p>Il tuo indirizzo e-mail � stato rimosso dalla mailinglist!</p>";
	$not_in_list_error      = "<p>Errore: non ti sei iscritto / rimosso dalla mailinglist!<br><br>"
	                        . "Forse ti sei gi� iscritto / rimosso dalla mailinglist?</p>";

	$data_protection_info   = "I dati aggiuntivi sono solo a scopo statistico.<br>"
                                . "Garantiamo che non saranno inviati a terze parti "
	                        . "senza il permesso esplicito!<br>";

	$_kill_entry            = "Elimina riferimento";
	$_enable_entry          = "Abilita riferimento";
	$_disable_entry         = "Disabilita riferimento";

	$newsletter_sign_out_info = "Qui puoi rimuoverti dalla mailinglist "
	                         . "&quot;".$newsletter_title."&quot;<br>";

	$wait_for_mail          = "Grazie per esserti interessato alla &quot".$newsletter_title."&quot!<br><br>"
	                        ."Ricerverai conferma via e-mail in qualche minuto. <br>"
	                        ."Leggi l'e-mail correttamente !";

	$newsletter_sign_in_info= "Benvenuto!<br><br>Qui puoi registrarti alla mailinglist "
   				." &quot;".$newsletter_title."&quot;.<br>Gli iscritti riceveranno"
   				." importanti informazioni via e-mail.<br>";

	$newsletter_info        = "&quot;".$newsletter_title."&quot; provvede ad inviarti tutte le informazioni<br>"
	                        . " importanti direttamente e comodamente via e-mail...";

	$_list_admin            = "Amministrazione iscritti (rimuovi dalla lista)";

	$_post_to_mailinglist   = "Invia messaggi alla mailinglist";
	$_skipped_as_disabled   = "Saltato (disabilitato)";
	$_message_sent          = "<b>Inviato</b>";
	$_message_not_sent      = '<b><font color="red">Errore</font></b>: non siamo stati in grado di inviare il messaggio!!';
	$_sent                  = "Inviato";
	$_of                    = "di";
	$_post_to_ml            = "Invia alla Mailinglist";
	$_subject               = "Soggetto";
	$_message               = "Messaggio";
	$_check_for_updates     = "Guarda per updates";
	$_of                    = "di";
	$_last                  = "precedente";
	$_next                  = "prossimo";

	$_recipients_group      = "Elenco di iscritti (mailinglist)";
	$_copy                  = "copia a";
	$_copy_entry            = "copia riferimento";
	$_add                   = "aggiungi";
	$_added_to_list         = "aggiunto alla mailinglist";
	$_archived_newsletters  = "Newsletter archiviate";
	$_newsletter_archive    = "Archivio Newsletter";

	$_warning               = "Warning!";
	$_last_posting_failed   = "Last time the posting was broken before mail could be sent to ALL recipients.";
	$_continue_mailing      = "Do you want post the remaining messages?";
	$_yes                   = "Yes";
	$_no                    = "No";

?>