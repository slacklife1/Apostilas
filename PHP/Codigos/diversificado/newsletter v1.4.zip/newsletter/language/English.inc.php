<?php

	$charset                = "iso-8859-1";

	$_sign_in_mailinglist   = "Sign in mailinglist";
	$_sign_out_mailinglist  = "Sign out mailinglist";

	$_sign_in_newsletter    = "Sign in";
	$_sign_out_newsletter   = "Sign out";

	$_birth_year            = "Birth-Year";
	$_profession            = "Profession";
	$_nationality           = "Nationality";
	$_email_address         = "e-mail-Address";

	$_enter_birthdate       = "Please enter your birth-year !";
	$_enter_profession      = "Please enter your profession !";
	$_enter_nationality     = "Please enter your nationality !";
	$_enter_email           = "Please enter your e-mail address !";

	$_ml_contains           = "Mailinglist contains";
	$_entries               = "entries";
	$_recipient             = "recipient";
	$_domain                = "domain";
	$_sort_by_user_az       = "sort by recipient (A-Z)";
	$_sort_by_user_za       = "sort by recipient (Z-A)";
	$_sort_by_domain_az     = "sort by domain (A-Z)";
	$_sort_by_domain_za     = "sort by domain (Z-A)";
	$_enabled               = "enabled";
	$_disabled              = "disabled";
	$_enable                = "enable";
	$_disable               = "disable";
	$_delete                = "delete";

	$sign_error             = "Error signing in/out!<br>Please try again later!";

	$sign_in_mail_txt       = "Klick on the following Link to confirm that you want,\n"
	                        . "to receive " . $newsletter_title . " !\n\n";

	$sign_in_mail_subject   = "Sign in ". $newsletter_title;

	$sign_out_mail_txt      = "Klick on the following Link to confirm that you don't want,\n"
							. "to receive " . $newsletter_title . " anymore!\n\n";

	$sign_out_mail_subject  = "Sign out ". $newsletter_title;

	$signed_in_txt          = "<p>Your e-mail-address has been added to our mailinglist!</p>";
	$signed_out_txt         = "<p>Your e-mail-address has been removed from our mailinglist!</p>";
	$not_in_list_error      = "<p>Error: You are not in our sign-in/out-list!<br><br>"
	                        . "Probably your address already has been added to / removed from our mailinglist?</p>";

	$data_protection_info   = "These additionally data we need for statistical purposes only.<br>"
                                . "We guarantee you that we will not give your personal data to third "
	                        . "without your explicit permission!<br>";

	$_kill_entry            = "Kill entry";
	$_enable_entry          = "Enable entry";
	$_disable_entry         = "Disable entry";

	$newsletter_sign_out_info = "Here you can sign out from the mailinglist "
	                         . "&quot;".$newsletter_title."&quot;<br>";

	$wait_for_mail          = "Thank you for your interest in &quot".$newsletter_title."&quot!<br><br>"
	                        ."You should receive a confirmation e-mail in a few minutes. <br>"
	                        ."Please read that e-mail thoroughly !";

	$newsletter_sign_in_info= "Welcome!<br><br>Here you can sign in our mailinglist for"
   				." &quot;".$newsletter_title."&quot;.<br>Subscribers will receive"
   				." all important information comfortably by e-mail.<br>";

	$newsletter_info        = "&quot;".$newsletter_title."&quot; provides you with all important<br>"
	                        . "information around our website comfortably by e-mail...";

	$_list_admin            = "administer subscribers (remove from list)";

	$_post_to_mailinglist   = "post message to mailinglist";
	$_skipped_as_disabled   = "skipped (disabled)";
	$_message_sent          = "<b>sent</b>";
	$_message_not_sent      = '<b><font color="red">Error</font></b>: script was not able to send the message !!!';
	$_sent                  = "sent";
	$_of                    = "of";
	$_post_to_ml            = "Post to Mailinglist";
	$_subject               = "Subject";
	$_message               = "Message";
	$_check_for_updates     = "Look for latest updates";
	$_of                    = "of";
	$_last                  = "last";
	$_next                  = "next";

	$_recipients_group      = "Group of recipients (mailinglist)";
	$_copy                  = "copy to";
	$_copy_entry            = "copy entry";
	$_add                   = "add";
	$_added_to_list         = "added to mailinglist";
	$_archived_newsletters  = "newsletters archived";
	$_newsletter_archive    = "Newsletter Archive";

	$_warning               = "Warning!";
	$_last_posting_failed   = "Last time the posting was broken before mail could be sent to ALL recipients.";
	$_continue_mailing      = "Do you want post the remaining messages?";
	$_yes                   = "Yes";
	$_no                    = "No";

?>