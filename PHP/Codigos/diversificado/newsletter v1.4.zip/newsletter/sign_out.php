<html>

<?php

	// Global variables (have to be fitted)
	require ("globals.inc.php");

	// template file for native language support
	require ( "language/" .$languagepack . ".inc.php" );
?>

<head>
	<title><?php echo $newsletter_title; ?></title>
	<link rel="stylesheet" href="<?php echo $css_file; ?>">
	<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $charset ?>">
</head>

<script language="JavaScript">

	/* validates the input form data */

	function chkform()
	{
		var email = document.sendform.email.value;

		if ( (email.length < 6) ||
		(email.indexOf('@') < 1) ||
		(email.indexOf('.') == -1) )
		{
			alert("<? echo $_enter_email; ?>");
			document.sendform.email.focus();
			return false;
		}
		return true;
	}

</script>

<body >
<?php
echo <<< FORMSHEET
<table border="0">
<tr>
<td><h3>$newsletter_title</h3></td>
<td><img src="images/1x1.gif" width="100"></td>
<td><img src="images/newsletter.gif"></td>
</tr>
</table>
<br>
<p>$newsletter_sign_out_info</p>
<br>
<form name="sendform" method="post" action="$sign_script?do=sign_out&language=$languagepack&ml_id=$ml_id" onsubmit="return chkform()">
  <table border="0" cellspacing="0" cellpadding="0" width="50%" class="sign_form">
    <tr align="center">
      <td>
        <table border="0" width="100%">
          <tr>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td><nobr>$_email_address:</nobr></td>
            <td>
              <input type="text" name="email" size="48" maxlength="48">
            </td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>
              <input type="submit" value="$_sign_out_newsletter" name="go">
            </td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</form>
FORMSHEET;
?>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<!-- Please don't remove the link to the author's website!!! -->
<p><font size="1" color="#BBBBBB">Jax Newsletter v1.4 by Jack (tR),
<a href="http://www.jtr.de/scripting/php">www.jtr.de/scripting/php</a>
</body>

</html>