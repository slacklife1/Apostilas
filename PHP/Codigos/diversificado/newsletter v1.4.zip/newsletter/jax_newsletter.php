<html>

<?php

	// global variables (have to be fitted)
	require ("globals.inc.php");

	// template file for native language support
	require ( "language/" .$languagepack . ".inc.php" );
?>

<head>
	<title><?php echo strip_tags($newsletter_title); ?></title>
	<link rel="stylesheet" href="<?php echo $css_file; ?>">
	<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $charset ?>">
</head>

<body>
<table border="0">
<tr>
<td><h3><?php echo $newsletter_title; ?></h3></td>
<td><img src="images/1x1.gif" width="50"></td>
<td><img src="images/newsletter.gif"></td>
</tr>
</table>

<?php

echo <<<INFOTEXT
<p>$newsletter_info</p>
<p>&nbsp;</p><blockquote>
<p><img src="images/right.gif" width="12" height="12"><a href="$sign_in_form?language=$languagepack&ml_id=$ml_id">$_sign_in_mailinglist</a></p>
<p><img src="images/right.gif" width="12" height="12"><a href="$sign_out_form?language=$languagepack&ml_id=$ml_id">$_sign_out_mailinglist</a></p>
<p>&nbsp;</p>
<p><img src="images/right.gif" width="12" height="12"><a href="archive.php?language=$languagepack&ml_id=$ml_id">$_newsletter_archive</a></p>
</blockquote>
INFOTEXT;

?>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<!-- Please don't remove the link to the author's website!!! -->
<p><font size="1" color="#BBBBBB">Jax Newsletter v1.4 by Jack (tR),
<a href="http://www.jtr.de/scripting/php">www.jtr.de/scripting/php</a>
</body>

</html>