<html>

<?php

	// global variables (have to be fitted)
	require ("globals.inc.php");

	// template file for native language support
	require ( "language/" .$languagepack . ".inc.php" );
?>

<head>
	<title><?php echo $newsletter_title; ?></title>
	<link rel="stylesheet" href="<?php echo $css_file; ?>">
	<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $charset ?>">
</head>


<?php

if ( $data_source == "mysql" )
{
	// include class for database support
	require ( "mysql.inc.php" );

	// prepare objects for database access
	// list of subscribers which signed in/off
	$subscr_list           = new mysql;
	$subscr_list->name     = $listfile_name;
	$subscr_list->server   = $db_server;
	$subscr_list->login    = $db_login;
	$subscr_list->password = $db_password;
	$subscr_list->database = $db_database;
	$subscr_list->init();

	// log file for statistical reports
	$logbook            = new mysql;
	$logbook->name      = $logfile_name;
	$logbook->server    = $db_server;
	$logbook->login     = $db_login;
	$logbook->password  = $db_password;
	$logbook->database  = $db_database;
	$logbook->init();
}

if ( $data_source == "csvfile" )
{
	// include class for CSV-textfile support
	require ( "csvfile.inc.php" );

	// prepeare objects for file access
	// list of subscribers which signed in/off
	$subscr_list        = new csvfile;
	$subscr_list->name  = $listfile_name;
	$subscr_list->init();

	// log file for statistical reports
	$logbook         = new csvfile;
	$logbook->name   = $logfile_name;
	$logbook->init();
}

	$time_now = date("Y-m-d H:i:s");

	if (!empty($HTTP_POST_VARS["email"])) 
	  { $email = $HTTP_POST_VARS["email"]; }
	else
	  { exit; }

	if ( !empty( $HTTP_GET_VARS["do"] ) && 
	   ( ( $HTTP_GET_VARS["do"] == "sign_in" ) || ( $HTTP_GET_VARS["do"] == "sign_out" ) ) )
	{
		// stores the e-mail-address in the signers list
		// together with an individual generated user-id.
		  
		$key = md5( $time_now . $email );

		$data = array();
		$data[ "date" ] = date( "Y-m-d" );
		$data[ "hash" ] = $key;
		$data[ "email" ] = $email;
		$subscr_list->append( $data );

		// prepare e-mail-header
		$mailheader = trim( "From: ".$newsletter_title." <".$newsletter_email.">\n"
		. "Reply-To: ".$newsletter_email."\n"
		. "X-Mailer: PHP " . phpversion() );
		
		// shortens the pathname by scriptname
		$script_path_dummy = explode( "/", $SCRIPT_NAME );
		unset ( $script_path_dummy[ count( $script_path_dummy ) - 1 ] );

		$script_url = "http://" . $SERVER_NAME . implode("/",$script_path_dummy ) . '/' ;
	}

	// sign in procedure
  	if ( !empty( $HTTP_GET_VARS["do"] ) && $HTTP_GET_VARS["do"] == "sign_in" )
	{
		// save the received form data for statistical reports
		// in a special log file

		if ( $log_signings )
		{
			$log = array();
			$log[ "action" ] = "+";
			$log[ "time" ] = $time_now;
			$log[ "ip" ] = $REMOTE_ADDR;
			$log[ "email" ] = $email;
			if ( !empty( $HTTP_POST_VARS["profession"]) ) 
			{ $log[ "profession" ] = $HTTP_POST_VARS["profession"]; }

			if ( !empty( $HTTP_POST_VARS["age"]) ) 
			{ $log[ "age" ] = $HTTP_POST_VARS["age"]; }

			if ( !empty( $HTTP_POST_VARS["nationality"]) ) 
			{ $log[ "nationality" ] = $HTTP_POST_VARS["nationality"];}

			$logbook->append( $log );
		}

		// sends a sign-in-e-mail to the mailinglist candidate !

		$message = trim( $sign_in_mail_txt . $script_url . $verify_script . "?do=sign&uid=$key&language=$languagepack&ml_id=$ml_id\n" );
		$subject = trim( $sign_in_mail_subject."\n" );

		// you have mail!
		$sent = @mail( trim( $email ), $subject, $message, $mailheader );
	}


	// sign off procedure
	if ( !empty( $HTTP_GET_VARS["do"] ) && $HTTP_GET_VARS["do"] == "sign_out" )
	{
		if ( $log_signings )
		{
			$log = array();
			$log[ "action" ] = "-";
			$log[ "time" ] = $time_now;
			$log[ "ip" ] = $REMOTE_ADDR;
			$log[ "email" ] = $email;
			$log[ "age" ] = "";
			$log[ "profession" ] = "";
			$log[ "nationality" ] = "";
			$logbook->append( $log );
		}

		// sends a sign-off-email to the subscriber!
		$message = trim( $sign_out_mail_txt . $script_url . $verify_script . "?do=leave&uid=$key&language=$languagepack&ml_id=$ml_id\n" );
		$subject = trim( $sign_out_mail_subject ."\n" );

		// you have mail!
		$sent = @mail( trim( $email ), $subject, $message, $mailheader );
	}
?>

<body>
<table border="0">
<tr>
<td><h3><?php echo $newsletter_title; ?></h3></td>
<td><img src="images/1x1.gif" width="100"></td>
<td><img src="images/newsletter.gif"></td>
</tr>
</table>

<p>
<?php

	if ($sent)
	{
		echo $wait_for_mail;
	}
	else
	{
		echo $sign_error;
	}

?>
</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<!-- Please don't remove the link to the author's website!!! -->
<p><font size="1" color="#BBBBBB">Jax Newsletter v1.4 by Jack (tR),
<a href="http://www.jtr.de/scripting/php">www.jtr.de/scripting/php</a>
</body>

</html>