<html>

<?php

	// fit if nescessary:
	$path_to_newsletter = "../";

	// Global variables (have to be fit)
	require ( $path_to_newsletter."globals.inc.php");

	// file for language support
	require ( $path_to_newsletter."language/" .$languagepack . ".inc.php" );

	if ( !empty($HTTP_GET_VARS["do"]) )
  	  $do = $HTTP_GET_VARS["do"];
	else
  	  $do = "show_list";

	if (!empty( $HTTP_GET_VARS["sortorder"] ) )
	  $sortorder = $HTTP_GET_VARS["sortorder"];
	else
  	  $sortorder = "unsorted";
  	  
	if (!empty( $HTTP_GET_VARS["page"] ) )
	  $page = $HTTP_GET_VARS["page"];
	else
  	  $page = 0;
  
?>


<head>
  <title><?php echo $newsletter_title; ?></title>
  <link rel="stylesheet" href="<?php echo $path_to_newsletter.$css_file; ?>">
  <meta http-equiv="Content-Type" content="text/html; charset=<?php echo $charset ?>">
</head>


<script language="JavaScript">

  // calls the script dependent on the selected function button

  function send_data( selection )
  {
  	var thisform = document.memberlist;

  	thisform.method = "post";

  	if ( selection == "add" )       { thisform.action = "<?php echo "$PHP_SELF?action=add&language=$languagepack&ml_id=$ml_id&page=$page"; ?>" };
  	if ( selection == "delete" )    { thisform.action = "<?php echo "$PHP_SELF?action=delete&language=$languagepack&ml_id=$ml_id&page=$page"; ?>" };
	if ( selection == "disable" )   { thisform.action = "<?php echo "$PHP_SELF?action=disable&language=$languagepack&ml_id=$ml_id&page=$page"; ?>" };
	if ( selection == "enable" )    { thisform.action = "<?php echo "$PHP_SELF?action=enable&language=$languagepack&ml_id=$ml_id&page=$page"; ?>" };
	if ( selection == "duplicate" ) { thisform.action = "<?php echo "$PHP_SELF?action=duplicate&language=$languagepack&ml_id=$ml_id&page=$page"; ?>" };

    	thisform.submit();
  }

  function go2link()
  {
  	var thisform = document.selectform;

	location.href="<?php echo "$PHP_SELF?language=$languagepack&ml_id="; ?>"+
	thisform.newsletter.options[thisform.newsletter.options.selectedIndex].value;
  }

</script>


<body >
  <?PHP

	// load class for data base support
	require ( $path_to_newsletter."mysql.inc.php" );

	// load class for CSV-textfile
	require ( $path_to_newsletter."csvfile.inc.php" );


	if ( $data_source == "mysql" )
	{
		// prepare objects for database access
		// mailinglist
		$ml		= new mysql;
		$ml->name	= $mailing_list;
		$ml->server	= $db_server;
		$ml->login	= $db_login;
		$ml->password	= $db_password;
		$ml->database	= $db_database;
		$ml->init();

		// logfile
		$logbook            = new mysql;
		$logbook->name      = $logfile_name;
		$logbook->server    = $db_server;
		$logbook->login     = $db_login;
		$logbook->password  = $db_password;
		$logbook->database  = $db_database;
		$logbook->init();
	}

	if ( $data_source == "csvfile" )
	{
		// prepare objects for file access
		// mailinglist
		$ml		= new csvfile;
		$ml->name	= $path_to_newsletter.$mailing_list;
		$ml->init();

		// logfile
		$logbook         = new csvfile;
		$logbook->name   = $path_to_newsletter.$logfile_name;
		$logbook->init();

	}

	// repeat this init procedure for the target list

	if (!empty( $HTTP_GET_VARS["target_list"] ))
	  $tl_id = $HTTP_GET_VARS["target_list"];
	else
	  $tl_id = 0;
	  
	$data_source      = $newsletters[$tl_id]->data_source;
	$db_server        = $newsletters[$tl_id]->db_server;
	$db_login         = $newsletters[$tl_id]->db_login;
	$db_database      = $newsletters[$tl_id]->db_database;
	$db_password      = $newsletters[$tl_id]->db_password;
	$mailing_list     = $newsletters[$tl_id]->mailinglist;

	if ( $data_source == "mysql" )
	{
		// prepare objects for database access
		// mailinglist
		$tl	          = new mysql;
		$tl->name      = $mailing_list;
		$tl->server    = $db_server;
		$tl->login     = $db_login;
		$tl->password  = $db_password;
		$tl->database  = $db_database;
		$tl->init();

	}

	if ( $data_source == "csvfile" )
	{
		// prepare objects for file access
		// mailinglist
		$tl		= new csvfile;
		$tl->name	= $path_to_newsletter.$mailing_list;
		$tl->init();
	}

// show history list
if ( $do == "show_history" )
{
	if ( !empty( $HTTP_GET_VARS[ "subscriber" ] ) )
	  $subscriber = $HTTP_GET_VARS[ "subscriber" ];
	else
	  $subscriber = "noname";
	
	$entries = $logbook->entries();

	echo "<b>Log-Eintr�ge f�r $subscriber</b><br><br>";
	$tosearch = array();
	$tosearch["email"] = $subscriber;
	$found = $logbook->find_entry( $tosearch );

	echo "<table>\n<tr>\n";
	$headrows = array_values( $logbook->captions );

	foreach ( $headrows as $title )
	{
		echo "  <td><b>$title</b>&nbsp;&nbsp;</td>\n";
	}
	echo "</tr>\n";

	while ( $found < $entries )
	{

		$data = array();
		$logbook->get_entry( $found, $data );

		echo "<tr>\n";
		foreach ( $headrows as $title )
		{
			echo "  <td>".$data[$title]."</td>\n";
		}
		echo "</tr>\n";

		$found = $logbook->find_next_entry( $tosearch );
	}
	echo "</table>\n";


  exit;
}


if (!empty( $HTTP_GET_VARS["action"] ) )
  $action = $HTTP_GET_VARS["action"];

if ( !empty( $action ) )
{

	// get data from mailinglist

	$mailinglist = array();
	$entries = $ml->entries();

	$ml->get_entrylist( 0, $entries-1, $mailinglist );

     	switch ( $action )
    	{

// -- duplicate entries -------------------------------------------------------------------

    		case "duplicate":
    		{
				if ($ml_id != $tl_id)
				for ( $i=$entries-1; $i>=0; $i-- )
				{
					$ind = "a".$i;
					if ( !empty( $HTTP_POST_VARS[ $ind ] ) ) 
					{
						$var = $HTTP_POST_VARS[ $ind ];
						if ($var == true)
						{
							echo "$_copy_entry ".$mailinglist[$i]["username"]."@"
							.$mailinglist[$i]["domain"]."...";

							$newdata = array();
							$newdata["username"] = $mailinglist[$i]["username"];
							$newdata["domain"] = $mailinglist[$i]["domain"];

							echo "to ".$tl->name."<br>";

							$tl->append( $newdata );
						}
					}
				}
				break;
    		}

// -- kill entries -------------------------------------------------------------------

    		case "delete":
    		{
				for ( $i=$entries-1; $i>=0; $i-- )
				{
					$ind = "a".$i;
					if ( !empty( $HTTP_POST_VARS[ $ind ] ) ) 
					{
						$var = $HTTP_POST_VARS[$ind];
						if ( $var == true )
						{
							echo "$_kill_entry ".$mailinglist[$i]["username"]."@"
							.$mailinglist[$i]["domain"]."...<br>";
							$ml->delete($i);
							
							$log = array();
							$log["time"] = date("Y-m-d H:i:s");
							$log["action"] = "-(admin)";
							$log["ip"] = $REMOTE_ADDR;
							$log["email"] = $mailinglist[$i]["username"]."@".$mailinglist[$i]["domain"];
							$logbook->append( $log );
											
						}
					}
				}
				break;
    		}

// -- enable entries -------------------------------------------------------------------

    	    case "enable":
    		{
				for ( $i=$entries-1; $i>=0; $i-- )
				{
					$ind = "a".$i;
					if ( !empty( $HTTP_POST_VARS[ $ind ] ) ) 
					{
						$var = '$HTTP_POST_VARS["a'.$i.'"]';
						if ( $var==true && ( substr( $mailinglist[$i]["username"],0,2) == "**" ) )
						{
							echo "$_enable_entry ".$mailinglist[$i]["username"]."@"
							.$mailinglist[$i]["domain"]."...<br>";
							$mailinglist[$i]["username"] = substr( $mailinglist[$i]["username"],2,255);
							$ml->change( $i, $mailinglist[$i] );
						}
					}
				}
				break;
    		}

// -- disable entries -------------------------------------------------------------------

    	    case "disable":
    		{
						
    			for ( $i=$entries-1; $i>=0; $i-- )
				{
					$ind = "a".$i;
					if ( !empty( $HTTP_POST_VARS[ $ind ] ) ) 
					{
						$var = $HTTP_POST_VARS[ $ind ];
						if ( $var==true && substr( $mailinglist[$i]["username"],0,2) != "**" )
						{
							echo "$_disable_entry ".$mailinglist[$i]["username"]."@"
							.$mailinglist[$i]["domain"]."...<br>";

							$mailinglist[$i]["username"] = "**".$mailinglist[$i]["username"];
							$ml->change( $i, $mailinglist[$i] );
						}
					}
				}
				break;
    		}


// -- add entry -------------------------------------------------------------------

		case "add":
    		{
			if ( !empty( $HTTP_POST_VARS["new_subscriber"] ) )
			{
				$new_subscriber = explode( "@", $HTTP_POST_VARS["new_subscriber"] );
				$new_entry = array();

				$new_entry["username"] = $new_subscriber[0];
				$new_entry["domain"] = $new_subscriber[1];

				$ml->append( $new_entry );
				
				$log = array();
				$log["time"] = date("Y-m-d H:i:s");
				$log["action"] = "+(admin)";
				$log["ip"] = $REMOTE_ADDR;
				$log["email"] = $new_entry["username"]."@".$new_entry["domain"];
				$logbook->append( $log );
				
				echo $new_entry["username"]."@".$new_entry["domain"]. " $_added_to_list ";
			}
			break;
    		}

    		default:
    		{
    		}
    	}

}

	$mailinglist = array();
	$entries = $ml->entries();

	$ml->get_entrylist( 0, $entries-1, $mailinglist );

	if ( empty($page) ) { $page = 1; }
	$maxpages = ceil( $entries / $entries_per_page );

	if ( $page < $maxpages )
	{
		$nextpage = $page+1;
	}
	else
	{
		$nextpage = $maxpages;
	}
	$lastpage = $page-1;

	// Line of the file from where to start
	$first_entry = ($page-1) * $entries_per_page;

	// Line of the file where to end
	$last_entry = ( $page * $entries_per_page ) - 1;
	if ($last_entry > $entries) { $last_entry = $entries-1; }


$pagenavigation = <<<NAV
<a href="$PHP_SELF?page=$lastpage&language=$languagepack&ml_id=$ml_id&sortorder=$sortorder">$_last</a> | $page $_of $maxpages |
<a href="$PHP_SELF?page=$nextpage&language=$languagepack&ml_id=$ml_id&sortorder=$sortorder">$_next</a> &gt;
NAV;

  ?>

<h3><?php echo $newsletter_title ?></h3>

<?php
	$ml_selection = "";
	$dummy = array_keys( $newsletters );
	foreach ($dummy as $ml_num)
	{
		if ($ml_num == $ml_id)
		{ $dummy2=" selected"; }
		else
		{ $dummy2=""; }

		$ml_selection .= '<option value="'.$ml_num.'"'.$dummy2.'>'.$newsletters[ $ml_num ]->groupname."</option>\n";
	}


echo <<< FORM_ML_SELECT
<p>$_recipients_group:
<FORM name="selectform" method="post" javascript:go2link();>
<SELECT onchange=javascript:go2link(); name="newsletter">
$ml_selection
</SELECT>
</FORM></p>

FORM_ML_SELECT;


echo <<< FORMSHEET_HEAD
<form name="memberlist" action="">
  <p>$_ml_contains <b> $entries </b> $_entries.</p>
  <p align="right">$_enabled / <span class="disabled">$_disabled</span></p>
  <table border="0" cellspacing="0" cellpadding="0" width="100%">
    <tr class="admin">
      <th>&nbsp;</th>
      <th align="left"> $_recipient
      <a href="$PHP_SELF?sortorder=usera2z&language=$languagepack&ml_id=$ml_id&page=$page"><img src="../images/up.gif" width="12" height="12" border="0" alt="$_sort_by_user_az"></a>
      <a href="$PHP_SELF?sortorder=userz2a&language=$languagepack&ml_id=$ml_id&page=$page"><img src="../images/down.gif" width="12" height="12" border="0" alt="$_sort_by_user_za"></a></th>
      <th align="left"> $_domain
      <a href="$PHP_SELF?sortorder=domaina2z&language=$languagepack&ml_id=$ml_id&page=$page"><img src="../images/up.gif" width="12" height="12" border="0" alt="$_sort_by_domain_az"></a>
      <a href="$PHP_SELF?sortorder=domainz2a&language=$languagepack&ml_id=$ml_id&page=$page"><img src="../images/down.gif" width="12" height="12" border="0" alt="$_sort_by_domain_za"></a>
      </th>
    </tr>
    <tr>
      <td><img src="../images/1x1.gif" height="10" width="50"></td>
      <td><img src="../images/1x1.gif" height="10" width="200"></td>
      <td><img src="../images/1x1.gif" height="10" width="200"></td>
    </tr>
  </table>

  <table border="0" cellspacing="0" cellpadding="0" width="100%">
  <tr>
      <td><img src="../images/1x1.gif" height="1" width="50"></td>
      <td><img src="../images/1x1.gif" height="1" width="200"></td>
      <td><img src="../images/1x1.gif" height="1" width="200"></td>
  </tr>

FORMSHEET_HEAD;


// outputs the table of email-addresses

	function show_entry( $username, $domain, $keynum )
	{
		global $_disabled, $PHP_SELF;

		if ( substr( $username,0,2 ) == "**" )
		{
			$username = substr( $username,2,255 );

	  		echo '<tr class="disabled"><td align="center"><a href="'."$PHP_SELF?do=show_history&subscriber=$username@$domain".'" target="_blank"><img src="../images/log.gif" border="0"></a>&nbsp;<input type="checkbox" name="'
			. "a$keynum" . '" value="1"></td>'
			. "<td>$username <b>(".$_disabled.")</b></td>"
			. "<td>$domain</td></tr>";
		}
	  	else
	  		{
				echo '<tr><td align="center"><a href="'."$PHP_SELF?do=show_history&subscriber=$username@$domain".'" target="_blank"><img src="../images/log.gif" border="0"></a>&nbsp;<input type="checkbox" name="' .
				"a$keynum" . '" value="1"></td>'.
				"<td>$username</td>".
				"<td>$domain</td></tr>";
			}
	}


	switch( $sortorder )
	{
		case "usera2z": // sort by usernames (A to Z)
		{
    		asort( $mailinglist );

		$current = 0;
    		$mykeys = array_keys( $mailinglist );
    		foreach ( $mykeys as $keynum )
    		{
			if ( ($current >= $first_entry) &&
			     ($current <= $last_entry ) )
			{
				show_entry( $mailinglist[$keynum]["username"], $mailinglist[$keynum]["domain"], $keynum );
			}
			$current++;

	  	}
	  	break;
	  	}

		case "userz2a": // sort by usernames reward (Z to A)
	  	{
    		arsort( $mailinglist );

		$current = 0;
    		$mykeys = array_keys( $mailinglist );
    		foreach ( $mykeys as $keynum )
    		{
			if ( ($current >= $first_entry) &&
			     ($current <= $last_entry ) )
			{
    				show_entry( $mailinglist[$keynum]["username"], $mailinglist[$keynum]["domain"], $keynum );
    			}
    			$current++;
    		}

	  		break;
	  	}

		case "domaina2z": // sort by domain names (A to Z)
	  	{

		$domains = array();
		for ($i=0; $i<$entries; $i++)
		{
			$domains[$i] = $mailinglist[$i]["domain"];
		}

		asort( $domains );

    		$mykeys = array_keys( $domains );
		$current = 0;
    		foreach ( $mykeys as $keynum )
    		{
			if ( ($current >= $first_entry) &&
			     ($current <= $last_entry ) )
			{
    			show_entry( $mailinglist[$keynum]["username"], $mailinglist[$keynum]["domain"], $keynum );
    			}
    			$current++;
    		}

	  		break;
	  	}

		case "domainz2a": // sort by domain names reward (Z to A)
		{
  		$domains = array();
		for ($i=0; $i<$entries; $i++)
		{
			$domains[$i] = $mailinglist[$i]["domain"];
		}

		arsort( $domains );

    		$mykeys = array_keys( $domains );
    		$current = 0;
    		foreach ( $mykeys as $keynum )
    		{
			if ( ($current >= $first_entry) &&
			     ($current <= $last_entry ) )
			{
    			show_entry( $mailinglist[$keynum]["username"], $mailinglist[$keynum]["domain"], $keynum );
    			}
    			$current++;
    		}

	  	break;
	  }


	default:
	  {
	  	for ( $i=$first_entry; $i<=$last_entry; $i++ )
	  	{
			show_entry( $mailinglist[$i]["username"], $mailinglist[$i]["domain"], $i );
		}
	  }

	}

echo <<< FORMSHEET_TAIL
  </table>
  <table border="0" cellspacing="0" cellpadding="0" width="100%">
  <tr><td>&nbsp;</td></tr>
  <tr align="middle" class="admin">
      <td>$pagenavigation</td>
  </tr>
  </table>


  <p align="center">

<input style="height: 18pt; font: bold 10pt arial, helvetica, sans-serif; text-decoration: none; color: #000000; background-image:url(../images/delete.gif); background-repeat:no-repeat; background-position: 1px 1px;" type="button"  name="delete"  value="&nbsp;&nbsp; $_delete" onclick="send_data(this.name)">
<input style="height: 18pt; font: bold 10pt arial, helvetica, sans-serif; text-decoration: none; color: #000000; background-image:url(../images/disable.gif); background-repeat:no-repeat; background-position: 1px 1px;" type="button" name="disable" value="&nbsp;&nbsp; $_disable" onclick="send_data(this.name)">
<input style="height: 18pt; font: bold 10pt arial, helvetica, sans-serif; text-decoration: none; color: #000000; background-image:url(../images/enable.gif); background-repeat:no-repeat; background-position: 1px 1px;" type="button"  name="enable"  value="&nbsp;&nbsp; $_enable" onclick="send_data(this.name)">
    <br><br>
<input style="height: 18pt; font: bold 10pt arial, helvetica, sans-serif; text-decoration: none; color: #000000; background-image:url(../images/new_entry.gif); background-repeat:no-repeat; background-position: 1px 1px;" type="button"  name="add"  value="&nbsp;&nbsp; $_add" onclick="send_data(this.name)">&nbsp;<input type="text" name="new_subscriber"> &nbsp;
<input style="height: 18pt; font: bold 10pt arial, helvetica, sans-serif; text-decoration: none; color: #000000; background-image:url(../images/copy.gif); background-repeat:no-repeat; background-position: 1px 1px;" type="button"  name="duplicate"  value="&nbsp;&nbsp;&nbsp;&nbsp; $_copy" onclick="send_data(this.name)">
<select name="target_list" size="1">$ml_selection</select>


    <br><br>

  </p>
</form>
FORMSHEET_TAIL;

?>


<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<!-- Please don't remove the link to the author's website!!! -->
<p><font size="1" color="#BBBBBB">Jax Newsletter v1.4 by Jack (tR),
<a href="http://www.jtr.de/scripting/php">www.jtr.de/scripting/php</a>
</body>
</html>