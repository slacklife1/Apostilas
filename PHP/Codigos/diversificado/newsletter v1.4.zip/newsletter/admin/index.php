<html>

<?php

	// fit if nescessary:
	$path_to_newsletter = "../";

	// Global variables (have to be fit)
	require ( $path_to_newsletter."globals.inc.php");

	// file for language support
	require ( $path_to_newsletter."language/" .$languagepack . ".inc.php" );
?>

<head>
  <title><?php echo $newsletter_title; ?></title>
  <link rel="stylesheet" href="<?php echo $path_to_newsletter.$css_file; ?>">
  <meta http-equiv="Content-Type" content="text/html; charset=<?php echo $charset ?>">
</head>



<body>
<h3 align="center"><?php echo $newsletter_title; ?></h3>
<p><br>
</p>
<table border="0" valign="middle" align="center" width="100%"><tr><td align="center">
<table border="0">
<tr><td><a href="list.admin.php<? echo "?ml_id=$ml_id&language=$languagepack" ?>"><img src="../images/group.gif" width="64" height="64" border="0" alt="<? echo $_list_admin ?>"></a></td><td>&nbsp;</td>
<td><a href="list.admin.php<? echo "?ml_id=$ml_id&language=$languagepack" ?>"><? echo $_list_admin ?></a></td></tr>
<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td><a href="posting.php<? echo "?ml_id=$ml_id&language=$languagepack" ?>"><img src="../images/writing_letter.gif" width="64" height="64" border="0" alt="<? echo $_post_to_mailinglist ?>"></a></td><td>&nbsp;</td>
<td><a href="posting.php<? echo "?ml_id=$ml_id&language=$languagepack" ?>"><? echo $_post_to_mailinglist ?></a></td></tr>
<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>&nbsp;</td><td>&nbsp;</td>
<td><img src="http://www.jtr.de/scripting/php/newsletter/updateinfo/updateinfo.php?current_version=140&img=status">&nbsp;&nbsp;<?php echo "<a href=\"http://www.jtr.de/scripting/php/newsletter/updateinfo/updateinfo.php?current_version=140&language=$languagepack\">$_check_for_updates</a>"; ?></td></tr>
</table>
</td><tr></table>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<!-- Please don't remove the link to the author's website!!! -->
<p><font size="1" color="#BBBBBB">Jax Newsletter v1.4 by Jack (tR),
<a href="http://www.jtr.de/scripting/php">www.jtr.de/scripting/php</a>
</font></p>
</body>

</html>