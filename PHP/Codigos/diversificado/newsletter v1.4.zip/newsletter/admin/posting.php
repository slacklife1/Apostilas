<html>

<?php

	// fit if nescessary:
	$path_to_newsletter = "../";

	// Globale Variable (m�ssen evtl. angepasst werden)
	require ("../globals.inc.php");

	// Datei f�r die jeweilige Sprache einbinden
	require ( "../language/" .$languagepack . ".inc.php" );
?>


<head>
	<title><?php echo $newsletter_title; ?></title>
	<link rel="stylesheet" href="<?php echo $path_to_newsletter.$css_file; ?>">
	<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $charset ?>">
	<meta http-equiv="cache-control" content="no-cache">
	<meta http-equiv="pragma" content="no-cache">
	<meta http-equiv="expires" content="0">	
</head>


<body >
<?php

	if (!empty( $HTTP_POST_VARS["target_list"] ))
	  $tl_id = $HTTP_POST_VARS["target_list"];
	else
	  $tl_id = 0;
	  
	if ( $tl_id != $ml_id )
	{
		$data_source      = $newsletters[$tl_id]->data_source;
		$newsletter_title = $newsletters[$tl_id]->title;
		$log_signings     = $newsletters[$tl_id]->do_log;
		$logfile_name     = $newsletters[$tl_id]->logfile;
		$db_server        = $newsletters[$tl_id]->db_server;
		$db_login         = $newsletters[$tl_id]->db_login;
		$db_database      = $newsletters[$tl_id]->db_database;
		$db_password      = $newsletters[$tl_id]->db_password;
		$listfile_name    = $newsletters[$tl_id]->subscriberlist;
		$mailing_list     = $newsletters[$tl_id]->mailinglist;
	}



	if ( $data_source == "mysql" )
	{
		// class for data base support
		require ( $path_to_newsletter."mysql.inc.php" );

		// prepare objects for database access
		// mailinglist
		$ml            = new mysql;
		$ml->name      = $mailing_list;
		$ml->server    = $db_server;
		$ml->login     = $db_login;
		$ml->password  = $db_password;
		$ml->database  = $db_database;
		$ml->init();

		// list of postings
		$archive           = new mysql;
		$archive->name     = $archive_file;
		$archive->server   = $db_server;
		$archive->login    = $db_login;
		$archive->password = $db_password;
		$archive->database = $db_database;
		$archive->init();

	}

	if ( $data_source == "csvfile" )
	{
		// class for CSV-textfile
		require ( $path_to_newsletter."csvfile.inc.php" );

		// prepare objects for file access
		// mailinglist
		$ml		= new csvfile;
		$ml->name	= $path_to_newsletter.$mailing_list;
		$ml->init();

		// list of postings
		$archive        = new csvfile;
		$archive->name  = $path_to_newsletter.$archive_file;
		$archive->init();
	}


	if ( !empty($HTTP_GET_VARS["do"]) )
		$do = $HTTP_GET_VARS["do"];
	else
	{
		$do = "start";

		// resume on HTTP-time out or -break!
		$entries = $ml->entries();

		if (! $checkfile = fopen( $path_to_newsletter.$archive_dir."/resume_recipient.txt", "r" ))
		{
			echo "Resume on TimeOut kann nicht ausgef�hrt werden, da $path_to_newsletter.$archive_dir/resume_recipient.txt nicht ge�ffnet werden kann";
		}
		else
		{
			$last = fgets( $checkfile, 4096 );
			fclose( $checkfile );

			if ( ($last != '*') && ($last < $entries) )
			{
$question_form = <<<QF
<script type="text/javascript">
<!--

 function send_data( selection )
  {
  	var thisform = document.decision_form;

  	thisform.method = "post";

  	if ( selection == "yes" ) { thisform.action = '$PHP_SELF?do=resume' };
  	if ( selection == "no" )  { thisform.action = '$PHP_SELF?do=reset' };

    	thisform.submit();
  }
 
//-->
</script>
<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
<tr><td>
<table border="1" width="50%" valign="middle" align="center" cellspacing="0" class="admin" bordercolor="#000000"
<tr><td>
<form name="decision_form" action="" onSubmit="return false;">
<table border="0" cellpadding="10" cellspacing="0">
<tr align="middle" valign="center">
<td colspan="2" align="left"><b>$_warning</b><br>$_last_posting_failed<br><br>$last $_of $entries $_sent<br><br>$_continue_mailing</td>
</tr>
<tr align="middle" valign="center">
<td><input type="button" name="yes" width="60" class="button" value=" $_yes " onClick="send_data(this.name)"></td>
<td><input type="button" name="no" width="60" class="button" value=" $_no " onClick="send_data(this.name)"></td>

</tr>
</table>
</form>
</td></tr></table>
</td></tr></table>
QF;

			echo $question_form;
			exit;
			}
		} // if opened checkfile
	} // if do = "start" || do = ""


if ( $do == "reset" )
{
	if (! $checkfile = fopen( $path_to_newsletter.$archive_dir."/resume_recipient.txt", "w" ))
  		echo "Resume on TimeOut kann nicht zur�ckgesetzt werden, da $path_to_newsletter.$archive_dir/resume_recipient.txt nicht ge�ffnet werden kann";
	else
  	{
  		fwrite( $checkfile, "*" );
  		fclose( $checkfile );
		echo '<meta http-equiv="refresh" content="0;URL='.$PHP_SELF.'">';	
  	}	
}


if ( $do == "resume" )
{
	$checkfile = fopen( $path_to_newsletter.$archive_dir."/resume_recipient.txt", "r" );
	
	$last = fgets( $checkfile, 4096 );
	fclose( $checkfile );

	$first_recipient = $last+1;

	$do = "start";		
}


if ( $do == "start" )
{
	
	$ml_selection = "";
	$dummy = array_keys( $newsletters );
	foreach ($dummy as $ml_num)
	{
		if ($ml_num == $ml_id)
		{ $sel =" selected"; }
		else
		{ $sel =""; }

		$ml_selection .= '<option value="'.$ml_num.'"'.$sel.'>'.$newsletters[ $ml_num ]->groupname."</option>\n";
	}

	if ( !empty($first_recipient) && $first_recipient > 0 )
	{
		$first_recipient--;

		$checkfile = fopen( $path_to_newsletter.$archive_dir."/resume_message.txt", "r" );
		$last_subject = fgets( $checkfile, 4096 );
		$last_message = "";
		while ( $line = fgets( $checkfile, 4096 ) )
		{
			$last_message .= $line;
		}
		fclose( $checkfile );
  	}
	else
  	  { $first_recipient = 0; $last_message = ""; $last_subject = ""; }
  	  


echo <<< FORMSHEET
<h3>$newsletter_title</h3>
<br>
<form name="postform" method="post" action="posting.php?do=sendmail&language=$languagepack&ml_id=$ml_id">
  <table border="0" cellspacing="0" cellpadding="0" bordercolor="#000000" width="50%" class="admin">
    <tr align="center">
      <td>
        <table border="0" width="100%">
          <tr>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>$_recipients_group:</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>
              <select name="target_list">
              $ml_selection
              </select>
            </td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;</td>
            <td><nobr>$_subject:</nobr></td>
            <td>&nbsp;&nbsp;&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td></td>
            <td>
              <input type="text" name="subject" size="60" maxlength="255" value="$last_subject">
            </td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;</td>
            <td><nobr>$_message:</nobr></td>
            <td>&nbsp;&nbsp;&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>
              <textarea name="message" cols="50" rows="15">$last_message</textarea>
            </td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
          </tr>
          <tr align="middle">
            <td>&nbsp;</td>
            <td>&nbsp;<input type="hidden" name="first_recipient" value="$first_recipient"></td>
            <td>
              <input type="submit" value="$_post_to_ml" name="go">
            </td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</form>
FORMSHEET;
}


if ( $do == "sendmail" )
{

	if ( !empty($HTTP_POST_VARS["message"]) )
  	  $message = $HTTP_POST_VARS["message"];
	else
  	  exit;

	if ( !empty($HTTP_POST_VARS["subject"]) )
  	  $subject = $HTTP_POST_VARS["subject"];
	else
  	  exit;

	if ( !empty($HTTP_POST_VARS["first_recipient"]) )
  	  $first_recipient = $HTTP_POST_VARS["first_recipient"];
	else
	{
		$first_recipient = 0;

		$checkfile = fopen( $path_to_newsletter.$archive_dir."/resume_message.txt", "w" );
  		fputs( $checkfile, $subject."\n" );
  		fputs( $checkfile, $message );  	
  		fclose( $checkfile );
  	}

	echo "<p>Erster Empf�nger: $first_recipient</p>";

	// shortens the pathname by scriptname
	$script_path_dummy = explode( "/", $SCRIPT_NAME );
	unset ( $script_path_dummy[ count( $script_path_dummy ) - 1 ] );

	$script_path = "http://" . $SERVER_NAME
	. implode("/",$script_path_dummy );


	$mailheader = trim( "From: ".$newsletter_title." <".$newsletter_email.">\n"
   			. "Reply-To: ".$newsletter_email."\n"
   			. "X-Mailer: Jax Newsletter v1.4 (PHP " . phpversion()
   			. ") unsubscribe at: " . $script_path . "/" . $path_to_newsletter . $sign_out_form . ")\n" );

   	$message	= stripslashes( quoted_printable_decode( trim( $message ) ) );
   	$subject	= trim( $subject );


	// save newsletter to archive

	$now_date = gmdate("Y-m-d");
	$now_time = gmdate("H:i:s");
	$nl_dump_file = "nl_".gmdate("Y_m_d_H_i_s");

	$dump = fopen( $path_to_newsletter.$archive_dir."/".$nl_dump_file, "a+" );
	fputs( $dump, $subject . " ( ". $now_date. " " . $now_time. " )\n\n" );
	fputs( $dump, $message . "\n\n" );
	fclose( $dump );

	$checkfile = @fopen( $path_to_newsletter.$archive_dir."/resume_recipient.txt", "w" );
	@fwrite( $checkfile, "0" );
  	@fclose( $checkfile );


	// put it into the archive index
	$data = array();
	$data[ "date" ] = $now_date;
	$data[ "time" ] = $now_time;
	$data[ "title" ] = $subject;
	$data[ "content_file" ] = $nl_dump_file;
	$archive->append( $data );

	// get data from mailinglist

	$mailinglist = array();
	$entries = $ml->entries();

	$ml->get_entrylist( 0, $entries-1, $mailinglist );
	$sent_mails = 0;

	for ( $i=0; $i<$entries; $i++ )
	{
		$fulladdress = $mailinglist[$i]["username"]."@".$mailinglist[$i]["domain"];
		echo "$i -> $fulladdress  : ";

		if ( substr( $mailinglist[$i]["username"],0,2) != "**" && $i >= $first_recipient )
		{
			// you have mail!
			$sent = @mail( trim( $fulladdress ), $subject, $message, $mailheader );
			if ( $sent )
			{
				echo $_message_sent."<br>";
				$sent_mails++;

				$checkfile = @fopen( $path_to_newsletter.$archive_dir."/resume_recipient.txt", "w" );
			  	@fwrite( $checkfile, $sent_mails );
  				@fclose( $checkfile );

			}
			else
			{
				echo $_message_not_sent."<br>";
			}
		}
		else
	 	{ echo $_skipped_as_disabled."<br>"; }

		flush();
	}
	echo "<br>$sent_mails $_of $entries $_sent!<br>";

}

?>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<!-- Please don't remove the link to the author's website!!! -->
<p><font size="1" color="#BBBBBB">Jax Newsletter v1.4 by Jack (tR),
<a href="http://www.jtr.de/scripting/php">www.jtr.de/scripting/php</a>
</font></p>
</body>

</html>