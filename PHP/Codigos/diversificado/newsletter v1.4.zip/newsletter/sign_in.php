<html>

<?php

	// global variables (have to be fitted)
	require ("globals.inc.php");

	// template file for native language support
	require ( "language/" .$languagepack . ".inc.php" );
?>

<head>
	<title><?php echo $newsletter_title; ?></title>
	<link rel="stylesheet" href="<?php echo $css_file; ?>">
	<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $charset ?>">
</head>

<script language="JavaScript">

	function xxx( str )
	{
		result = true;
		firstchar = str.charAt(0);
		for ( var i=0; i < str.length; i++ )
		{
			if ( str.charAt(i) != firstchar )
			{ result = false }
		}
		return result;
	}

	function chkform()
	{

		var age         = document.sendform.age.value;
		var profession  = document.sendform.profession.value;
		var nationality = document.sendform.nationality.value;
		var email       = document.sendform.email.value;

		var datum       = /^([1-9])([0-9]{3})/;
		var time_stamp = new Date();
		var thisyear = time_stamp.getFullYear();

		if (( datum.test(age) == false ) ||
		(age > thisyear-16) ||
		(age < thisyear-80))
		{
			alert("<? echo $_enter_birthdate; ?>");
			document.sendform.age.focus();
			return false;
		}

		if ( (profession.length < 3) || xxx(profession) )
		{
			alert("<? echo $_enter_profession; ?>");
			document.sendform.profession.focus();
			return false;
		}

		if ( (nationality.length < 2) || xxx(nationality) )
		{
			alert("<? echo $_enter_nationality; ?>");
			document.sendform.nationality.focus();
			return false;
		}

		if ( (email.length < 6) ||
		(email.indexOf('@') < 1) ||
		(email.indexOf('.') == -1 ) )
		{
			alert("<? echo $_enter_email; ?>");
			document.sendform.email.focus();
			return false;
		}
		return true;
  	}

</script>


<body >
<?php
echo <<< FORMSHEET
<table border="0">
<tr>
<td><h3>$newsletter_title</h3></td>
<td><img src="images/1x1.gif" width="100"></td>
<td><img src="images/newsletter.gif"></td>
</tr>
</table>
<br>
<p>$newsletter_sign_in_info</p><br>
<form name="sendform" method="post" action="$sign_script?do=sign_in&language=$languagepack&ml_id=$ml_id" onsubmit="return chkform()">
  <table border="0" cellspacing="0" cellpadding="0" width="50%" class="sign_form">
    <tr align="center">
      <td>
        <table border="0" width="100%">
          <tr>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>$_birth_year: <sup>*</sup></td>
            <td>
              <input type="text" name="age" maxlength="4" size="4">
            </td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>$_profession: <sup>*</sup></td>
            <td>
              <input type="text" name="profession" maxlength="32" size="48">
            </td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>$_nationality: <sup>*</sup></td>
            <td>
              <input type="text" name="nationality" size="48" maxlength="32">
            </td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td><nobr>$_email_address:</nobr></td>
            <td>
              <input type="text" name="email" size="48" maxlength="48">
            </td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>
              <input type="submit" value="$_sign_in_newsletter" name="go">
            </td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
  <p>* $data_protection_info</p>
</form>
FORMSHEET;
?>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<!-- Please don't remove the link to the author's website!!! -->
<p><font size="1" color="#BBBBBB">Jax Newsletter v1.4 by Jack (tR),
<a href="http://www.jtr.de/scripting/php">www.jtr.de/scripting/php</a>
</body>

</html>