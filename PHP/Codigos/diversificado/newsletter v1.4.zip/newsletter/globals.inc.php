<?php

// Global variables (have to be fitted) :

// Title of the Newsletter
$newsletters[0]->title          = "Jax Newsletter";
$newsletters[0]->data_source    = "csvfile";
$newsletters[0]->groupname      = "German Recipients";

// CSS template for the Newsletter
$newsletters[0]->css            = "styles/default.css";

$newsletters[0]->do_log         = true;
$newsletters[0]->logfile        = "records.csv";
$newsletters[0]->subscriberlist = "subscribers.csv";
$newsletters[0]->mailinglist    = "mailinglist_ger.csv";
$newsletters[0]->archive        = "archive_ger.csv";

$newsletters[0]->db_server      = "";
$newsletters[0]->db_login       = "";
$newsletters[0]->db_database    = "";
$newsletters[0]->db_password    = "";

$newsletters[1]->title          = "Jax Newsletter";
$newsletters[1]->data_source    = "csvfile";
$newsletters[1]->groupname      = "English Recipients";

// CSS template for the Newsletter
$newsletters[1]->css            = "styles/default.css";

$newsletters[1]->do_log         = true;
$newsletters[1]->logfile        = "records.csv";
$newsletters[1]->subscriberlist = "subscribers.csv";
$newsletters[1]->mailinglist    = "mailinglist_eng.csv";
$newsletters[1]->archive        = "archive_eng.csv";

$newsletters[1]->db_server      = "";
$newsletters[1]->db_login       = "";
$newsletters[1]->db_database    = "";
$newsletters[1]->db_password    = "";


if (!empty( $_SERVER["PHP_SELF"] )) 
  $PHP_SELF = $_SERVER["PHP_SELF"];

if (!empty( $_SERVER["SCRIPT_NAME"] ) ) 
  { $SCRIPT_NAME = $_SERVER["SCRIPT_NAME"]; }

if (!empty( $_SERVER["SERVER_NAME"] ) ) 
  { $SERVER_NAME = $_SERVER["SERVER_NAME"]; }
  
if (!empty( $_SERVER["REMOTE_ADDR"] ) ) 
  { $REMOTE_ADDR = $_SERVER["REMOTE_ADDR"]; }


$newsletter_email = "postmaster@".$SERVER_NAME;

$sign_in_form 	 = "sign_in.php";
$sign_out_form  = "sign_out.php";
$sign_script 	 = "sign.php";
$verify_script  = "verify.php";


// if no mailinglist id is given in URI, take default (0)
if ( empty( $HTTP_GET_VARS["ml_id"] ) )
  { $ml_id = 0; }
else
  { $ml_id = $HTTP_GET_VARS["ml_id"]; }

$data_source      = $newsletters[$ml_id]->data_source;
$newsletter_title = $newsletters[$ml_id]->title;
$log_signings     = $newsletters[$ml_id]->do_log;
$logfile_name     = $newsletters[$ml_id]->logfile;
$db_server        = $newsletters[$ml_id]->db_server;
$db_login         = $newsletters[$ml_id]->db_login;
$db_database      = $newsletters[$ml_id]->db_database;
$db_password      = $newsletters[$ml_id]->db_password;
$listfile_name    = $newsletters[$ml_id]->subscriberlist;
$mailing_list     = $newsletters[$ml_id]->mailinglist;
$archive_file     = $newsletters[$ml_id]->archive;
$css_file         = $newsletters[$ml_id]->css;

// Language support
if ( empty( $HTTP_GET_VARS[ "language" ] ) )
{
    $languagepack = "English";
}
else
{
    $languagepack = $HTTP_GET_VARS[ "language" ];
}

$entries_per_page = 100;

$archive_dir	   = "archive";

?>