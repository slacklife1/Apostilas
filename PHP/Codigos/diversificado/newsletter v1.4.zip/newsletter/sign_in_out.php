<html>

<?php

	// global variables (have to be fitted)
	require ("globals.inc.php");

	// template file for native language support
	require ( "language/" .$languagepack . ".inc.php" );
?>

<head>
	<title><?php echo $newsletter_title; ?></title>
	<link rel="stylesheet" href="<?php echo $css_file; ?>">
	<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $charset ?>">
</head>


<script language="JavaScript">

	function xxx( str )
	{
		result = true;
		firstchar = str.charAt(0);
		for ( var i=0; i < str.length; i++ )
		{
			if ( str.charAt(i) != firstchar )
			{ result = false }
		}
		return result;
	}

	function chkform()
	{

		var email       = document.sign_form.email.value;

		if ( (email.length < 6) ||
		(email.indexOf('@') < 1) ||
		(email.indexOf('.') == -1 ) )
		{
			alert("<? echo $_enter_email; ?>");
			document.sign_form.email.focus();
			return false;
		}
		return true;
  	}

  // calls the script dependent on the selected function button

  function send_data( selection )
  {

	if (chkform())
	{

  	document.sign_form.method = "post";

  	if ( selection == "sign_in" )  { document.sign_form.action = "<?php echo "$sign_script?do=sign_in&language=$languagepack&ml_id=$ml_id"; ?>" };
	if ( selection == "sign_out" ) { document.sign_form.action = "<?php echo "$sign_script?do=sign_out&language=$languagepack&ml_id=$ml_id"; ?>" };

    document.sign_form.submit();

    }
  }

</script>


<body >
<?php
echo <<< FORMSHEET
<table border="0">
<tr>
<td><h3>$newsletter_title</h3></td>
<td><img src="images/1x1.gif" width="100"></td>
<td><img src="images/newsletter.gif"></td>
</tr>
</table>
<br>
<p>$newsletter_sign_in_info</p><br>
<form name="sign_form">
  <table border="0" cellspacing="0" cellpadding="0" class="sign_form">
    <tr align="center">
      <td>
        <table border="0" width="100%">
          <tr>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td><nobr>$_email_address:</nobr></td>
            <td>
              <input type="text" name="email" size="48" maxlength="48">
            </td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>
              <input type="button" value="$_sign_in_newsletter" name="sign_in" onclick="send_data(this.name)">
              <input type="button" value="$_sign_out_newsletter" name="sign_out" onclick="send_data(this.name)">
            </td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
  </form>
FORMSHEET;
?>



<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<!-- Please don't remove the link to the author's website!!! -->
<p><font size="1" color="#BBBBBB">Jax Newsletter v1.4 by Jack (tR),
<a href="http://www.jtr.de/scripting/php">www.jtr.de/scripting/php</a>
</body>

</html>