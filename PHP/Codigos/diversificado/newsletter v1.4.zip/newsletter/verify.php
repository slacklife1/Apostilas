<html>
<?php

	// global variables (have to be fitted)
	require ("globals.inc.php");

	// template file for native language support
	require ( "language/" .$languagepack . ".inc.php" );
?>

<head>
	<title><?php echo $newsletter_title; ?></title>
	<link rel="stylesheet" href="<?php echo $css_file; ?>">
	<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $charset ?>">
	<style type="text/css">
	<!--
	.input {  color: #FF0000; background-color: #CCCCCC}
	.output { color: #00FF00; background-color: #CCCCCC }
	-->
	</style>
</head>

<body>
<table border="0">
<tr>
<td><h3><?php echo $newsletter_title; ?></h3></td>
<td><img src="images/1x1.gif" width="100"></td>
<td><img src="images/newsletter.gif"></td>
</tr>
</table>

<?PHP

	if ( $data_source == "mysql" )
	{
		// include class for database support
		require ( "mysql.inc.php" );

		// prepare objects for database access
		// Mailinglist
		$ml           = new mysql;
		$ml->name     = $mailing_list;
		$ml->server   = $db_server;
		$ml->login    = $db_login;
		$ml->password = $db_password;
		$ml->database = $db_database;
		$ml->init();

		// List of addresses which want to sign in/off
		$subscr_list           = new mysql;
		$subscr_list->name     = $listfile_name;
		$subscr_list->server   = $db_server;
		$subscr_list->login    = $db_login;
		$subscr_list->password = $db_password;
		$subscr_list->database = $db_database;
		$subscr_list->init();
	}

	if ( $data_source == "csvfile" )
	{
		// include class for csv-textfile support
		require ( "csvfile.inc.php" );

		// prepeare objects for file access
		// Mailinglist
		$ml        = new csvfile;
		$ml->name  = $mailing_list;
		$ml->init();

		// List of addresses which want to sign in/off
		$subscr_list        = new csvfile;
		$subscr_list->name  = $listfile_name;
		$subscr_list->init();
	}


	function add_to_mailinglist( $entry )
	{
		global $ml;

 		$parts = explode( '@', $entry );
		$data = array();
		$data["username"] = $parts[0];
		$data["domain"] = $parts[1];
		$entries = $ml->entries();
		
		$found = $ml->find_entry( $data );

		if ($found >= $entries)
		{
			$ml->append( $data );
		}
		return;
	}

	function remove_from_mailinglist( $entry )
	{
		global $ml;
		$parts = explode( '@', $entry );
		$pattern = array();
		$pattern["username"] = $parts[0];
		$pattern["domain"] = $parts[1];
		$pos = $ml->find_entry( $pattern );
		$ml->delete( $pos );

		return;
	}

	function valid_user( $uid, $do )
	{
		$found = false;

		global $subscr_list;
		$entries = $subscr_list->entries();

		$list = array();
		$subscr_list->get_entrylist( 0, $entries, $list );

		for ($i=0; $i<$entries; $i++)
		{

			if ( $list[$i]["hash"] == $uid )
			{
				if ( $do == "sign in" )
				{
					add_to_mailinglist( $list[$i]["email"] );
					$subscr_list->delete( $i );
				}

				if ( $do == "sign out" )
				{
					remove_from_mailinglist( $list[$i]["email"] );
					$subscr_list->delete( $i );
				}
				$found = true;
			}
		}
		return $found;
	}

if (!empty( $HTTP_GET_VARS["uid"] )) { $uid = $HTTP_GET_VARS["uid"]; }

if ( !empty( $HTTP_GET_VARS["do"] ) )
switch( $HTTP_GET_VARS["do"] )
{
	case "sign" :
	{
		if ( valid_user( $uid, "sign in" ) )
		{
			echo $signed_in_txt;
		}
		else
		{
			echo $not_in_list_error;
		}
		break;
	}

	case "leave" :
	{
		if ( valid_user( $uid, "sign out" ) )
		{
			echo $signed_out_txt;
		}
		else
		{
			echo $not_in_list_error;
		}
		break;
	}
	default : {}
}

?>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<!-- Please don't remove the link to the author's website!!! -->
<p><font size="1" color="#BBBBBB">Jax Newsletter v1.4 by Jack (tR),
<a href="http://www.jtr.de/scripting/php">www.jtr.de/scripting/php</a>
</body>

</html>