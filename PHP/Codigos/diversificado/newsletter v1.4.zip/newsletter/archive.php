<html>

<?php

	// global variables (have to be fitted)
	require ("globals.inc.php");

	// template file for native language support
	require ( "language/" .$languagepack . ".inc.php" );
?>

<head>
	<title><?php echo "$newsletter_title - Archive"; ?></title>
	<link rel="stylesheet" href="<?php echo $css_file; ?>">
	<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $charset ?>">
</head>


<body >
<table border="0">
<tr>
<td><h3><?php echo $newsletter_title; ?></h3></td>
<td><img src="images/1x1.gif" width="100"></td>
<td><img src="images/newsletter.gif"></td>
</tr>
</table>

<?php


	if ( $data_source == "mysql" )
	{
		// include class for database support
		require ( "mysql.inc.php" );

		// prepare objects for database access
		// list of postings
		$archive           = new mysql;
		$archive->name     = $archive_file;
		$archive->server   = $db_server;
		$archive->login    = $db_login;
		$archive->password = $db_password;
		$archive->database = $db_database;
		$archive->init();
	}

	if ( $data_source == "csvfile" )
	{
		// include class for CSV-textfile support
		require ( "csvfile.inc.php" );

		// prepeare objects for file access
		// list of postings
		$archive        = new csvfile;
		$archive->name  = $archive_file;
		$archive->init();
	}

if (!empty( $HTTP_GET_VARS["do"] ) )
  $do = $HTTP_GET_VARS["do"];
else
  $do = "show_index";


	if ( $do == "show_posting" )
	{
		// show an archived newsletter
		$entries = $archive->entries();

		$i=0;
		$data = array();
		$archive->get_entry( $i, $data );
		while ( $i < $entries )
		{
			if ( $i == $num )
			{
				$dumpfile_name = $archive_dir."/".$data["content_file"];
				$dumpfile = fopen( $dumpfile_name, "r" );
				while ( $text = fgets( $dumpfile, 4096 ) )
				{
					$text = nl2br( ereg_replace("[[:alpha:]]+://[^<>[:space:]]+[[:alnum:]/]",
					               "<a href=\"\\0\">\\0</a>", $text) );
					echo $text;
				}
				fclose($dumpfile);
				break;
			}
			$i++;
			$archive->get_next_entry( $data );
		}
		exit;
	}


	if ( $do = "show_index" )
	{
		// generate index
		$entries = $archive->entries();
		echo "<p>$entries $_archived_newsletters...</p>";

		echo "<table>\n";
		$i=0;
		$data = array();
		$archive->get_entry( $i, $data );
		while ( $i < $entries )
		{
			echo "<tr>\n"
			. "<td>".$data["date"]."</td>\n"
			. "<td>".$data["time"]."</td>\n"
			. "<td>". '<a href="'.$PHP_SELF."?do=show_posting&num=".$i.'">'
			. $data["title"] ."</a></td>\n";
			$i++;
			$archive->get_next_entry( $data );
		}
		echo "</table>\n";
	}

?>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<!-- Please don't remove the link to the author's website!!! -->
<p><font size="1" color="#BBBBBB">Jax Newsletter v1.4 by Jack (tR),
<a href="http://www.jtr.de/scripting/php">www.jtr.de/scripting/php</a>
</body>

</html>