<?php
#################################################################################
#
#  Written by: Martynas Matuliauskas
#  E-mail: martynas.m@delfi.lt; web@editor.lt; admin@gomultiplex.com
#  Phone: +370 683 21711
#  Martynas Matuliauskas 2001-2002 Copyright(C)
#
#  Created:	2002 06 11
#  Modified:	2002 06 11
#
#  MD5signature:   kp9KjKP9cMXIAc16102mcfab8a80ddd706ad514682facdd369d5mcCy6Kzlc/I
#  
#  All rights reserved.
#
#################################################################################
#################################################################################

?>
function MM_findObj(n, d) {
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_changeProp(objName,x,theProp,theValue) {
  var obj = MM_findObj(objName);
  if (obj && (theProp.indexOf("style.")==-1 || obj.style)) eval("obj."+theProp+"='"+theValue+"'");
}