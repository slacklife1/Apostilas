<?php
#################################################################################
#
#  Written by: Martynas Matuliauskas
#  E-mail: martynas.m@delfi.lt; web@editor.lt; admin@gomultiplex.com
#  Phone: +370 683 21711
#  Martynas Matuliauskas 2001-2002 Copyright(C)
#
#  Created:	2002 05 31
#  Modified:	2002 06 11
#
#  MD5signature:   GCTz8Ex9dIfoMc16102mcfab8a80ddd706ad514682facdd369d5mcOHjcmBSN1
#  
#  All rights reserved.
#
#################################################################################
#################################################################################


include("mm.calendar.cfg.php");
include("mm.calendar.inc.php");

?>
<!--
 *
 *  Written by: Martynas Matuliauskas
 *  E-mail: martynas.m@delfi.lt
 *  Phone: +370 83 21711
 *  Copyright(C) 2001-2002 Martynas Matuliauskas.
 *
 *  Created:	2002 05 31
 *  <? echo "Last modified:	".date ("Y m d", getlastmod())."\n"; ?>
 *
 *  
 *  All rights reserved.
 *
-->
<!DOCTYPE HTML PUBLIC "-//W3C/DTD HTML 4.0 Transitional//EN">
<html><head>
<title><?=$title?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Reply-to" content="martynas.m@delfi.lt">
<meta name="Title" content="MM calendar">
<meta name="Copyright" content="M. Matuliauskas (C)">
<meta name="Version" content="2.0">
<meta name="Distribution" content="Global">
<meta name="Rating" content="General">
<meta name="Language" content="EN">
<meta name="Doc-type" content="Web Page">
<meta name="Doc-rights" content="M. Matuliauskas">
<meta name="Classification" content="Internet Services">
<meta name="Category" content="Free site">
<meta name="Author" content="M.Matuliauskas martynas.m@delfi.lt">
<meta name="Publisher" content="M.Matuliauskas martynas.m@delfi.lt">
<meta name="Robots" content="INDEX,FOLLOW,ALL">
<meta name="Audience" content="All">
<meta name="Distribution" content="Global">
<meta name="Revisit-After" content="7 days">
<meta name="ProgId" content="MM.Editor.Document">
<meta name="Generator" content="MMphtml/1.1">
<meta name="Keywords" content="MM calendar, calendar, php, day, year, month, , time, timestamp, Martynas Matuliauskas">
<meta name="Description" content="MM calendar">
<link rel="stylesheet" href="mm.calendar.css.php" type="text/css">
<script language="JavaScript" src="mm.calendar.vbs.php"></script>
</head>
<body bgcolor="<?=$bgcolor?>" text="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="480" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="15" align="right" valign="top" class="datetime" width="480">
      <? echo(date("m/d/Y H:i:s")); ?>
    </td>
  </tr>
  <tr> 
    <td height="15" width="480"> 
      <? if ( (!$action)&&(!$y)&&(!$timestamp) ) { ?>
<span class="year"><?=$title?></span><br><br>
      <a href="?a=ylist" class="main">year list</a><br>
	  <a href="?a=fdate" class="main">find date</a>
	  <br><br><br><br><br><br><br><br><br><br>
<? } elseif( ($action=="docs") || (($action=="help")&&(!$y)&&(!$timestamp)) ) { ?>
<span class="year"><?=$title?></span><br><br>
      <a href="docs/readme.html" class="main">Readme</a><br>
      <a href="docs/support.html" class="main">Support</a><br>
      <a href="docs/donation.html" class="main">Donation</a><br>

<br><br><br><br><br><br><br><br><br><br>
<? } elseif( ($action=="fdate")&&(!$y)&&(!$timestamp) ) { ?>
      <form name="fdate" method="get" action="">
	  <span class="year"><?=$title?></span><br><br>
        <table width="400" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td width="80" class="main" height="10">Year :</td>
            <td width="320" class="main" height="10"> 
              <input type="text" name="y" class="main" maxlength="4" size="4" onChange="MM_changeProp('tstamp','','value','','INPUT/TEXT')" value="<? echo(date("Y")); ?>">
            </td>
          </tr>
          <tr> 
            <td width="80" class="main" height="10"></td>
            <td width="320" class="main" height="10"></td>
          </tr>
          <tr> 
            <td width="80" class="main" height="10">Month:</td>
            <td width="320" class="main" height="10"> 
              <input type="text" name="sm" class="main" maxlength="2" size="2" onChange="MM_changeProp('tstamp','','value','','INPUT/TEXT')" value="<? echo(date("m")); ?>">
            </td>
          </tr>
          <tr> 
            <td width="80" class="main" height="10"></td>
            <td width="320" class="main" height="10"></td>
          </tr>
          <tr> 
            <td width="80" class="main" height="10">Day:</td>
            <td width="320" class="main" height="10"> 
              <input type="text" name="sd" class="main" maxlength="2" size="2" onChange="MM_changeProp('tstamp','','value','','INPUT/TEXT')" value="<? echo(date("d")); ?>">
            </td>
          </tr>
          <tr> 
            <td width="80" class="main" height="25"></td>
            <td width="320" class="main" height="25"></td>
          </tr>
          <tr> 
            <td width="80" class="main" height="10">TimeStamp:</td>
            <td width="320" class="main" height="10">
              <input type="text" name="tstamp" class="main" maxlength="10" size="10" onChange="MM_changeProp('y','','value','','INPUT/TEXT'); MM_changeProp('sm','','value','','INPUT/TEXT'); MM_changeProp('sd','','value','','INPUT/TEXT');">
            </td>
          </tr>
          <tr> 
            <td width="80" class="main" height="10"></td>
            <td width="320" class="main" height="10"></td>
          </tr>
          <tr> 
            <td width="80" class="main" height="10"></td>
            <td width="320" class="main" height="10"> 
              <input type="submit" value="search" class="main">
            </td>
          </tr>
          <tr> 
            <td width="80" class="main" height="10"></td>
            <td width="320" class="main" height="10"></td>
          </tr>
          <tr> 
            <td width="80" class="main" height="10"></td>
            <td width="320" class="main" height="10"></td>
          </tr>
        </table>
      </form>
      <? } elseif( ($action=="ylist")&&(!$y)&&(!$timestamp) ) {
	  print "<span class=\"year\">$title</span><br><br>";
		for ($i=$startyear; $i<=$endyear; $i++){
			print "<a href=\"?y=$i\"  class=\"main\">$i</a> \n<br>";
		}
	  print "<br><br>";
	} else {
		if ( ($y<$startyear)||($y>$endyear) ) {
			print "<span class=\"year\">$title</span><br><br><span class=\"main\">Bad year input</span><br><br><br><br><br><br><br>";
		} else {
		print "<span class=\"year\">$y</span>";
?>
      <table width="450" border="1" cellspacing="3" cellpadding="3"  bordercolor="<?=$bordercolor?>">
        <tr align="left" valign="top"> 
          <td width="150"> 
            <? MakeCalendar("01/01/$y"); ?>
          </td>
          <td width="150"> 
            <? MakeCalendar("02/01/$y"); ?>
          </td>
          <td width="150"> 
            <? MakeCalendar("03/01/$y"); ?>
          </td>
        </tr>
        <tr align="left" valign="top"> 
          <td width="150"> 
            <? MakeCalendar("04/01/$y"); ?>
          </td>
          <td width="150"> 
            <? MakeCalendar("05/01/$y"); ?>
          </td>
          <td width="150"> 
            <? MakeCalendar("06/01/$y"); ?>
          </td>
        </tr>
        <tr align="left" valign="top"> 
          <td width="150"> 
            <? MakeCalendar("07/01/$y"); ?>
          </td>
          <td width="150"> 
            <? MakeCalendar("09/01/$y"); ?>
          </td>
          <td width="150"> 
            <? MakeCalendar("10/01/$y"); ?>
          </td>
        </tr>
        <tr align="left" valign="top"> 
          <td width="150"> 
            <? MakeCalendar("11/01/$y"); ?>
          </td>
          <td width="150"> 
            <? MakeCalendar("12/01/$y"); ?>
          </td>
          <td width="150"></td>
        </tr>
      </table>
      <?
	 } }
	?>
    </td>
  </tr>
  <tr> 
    <td height="5" width="480"></td>
  </tr>
  <tr> 
    <td height="20" align="left" valign="top" width="480"><a href="mailto:martynas.m@delfi.lt" class="copyright">Copyright(C) 
      2001-2002 Martynas Matuliauskas. All rights reserved.</a></td>
  </tr>
</table>
</body>
</html>
