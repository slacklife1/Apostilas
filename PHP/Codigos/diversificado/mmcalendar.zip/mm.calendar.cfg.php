<?php
#################################################################################
#
#  Written by: Martynas Matuliauskas
#  E-mail: martynas.m@delfi.lt; web@editor.lt; admin@gomultiplex.com
#  Phone: +370 683 21711
#  Martynas Matuliauskas 2001-2002 Copyright(C)
#
#  Created:	2002 05 31
#  Modified:	2002 06 11
#
#  MD5signature:   bk897ygUYITJQc16102mcfab8a80ddd706ad514682facdd369d5mcktxcmcOb9
#  
#  All rights reserved.
#
#################################################################################
#################################################################################


### year 
$startyear="1971";
$endyear="2037";
### year 

### HTML ###
$title="MM calendar";
$charset="iso-8859-1";
$bgcolor="#FFFFFF";	    //use a hex value
$mounthtbbgcolor=$bgcolor;	    //use a hex value
$txtcolor="#666666";	 //use a hex value
$txtfontsize="8"; # in pt
$fontface="Arial, Helvetica, sans-serif";
$datetimesize="7"; # in pt
$datetimefontcolor="#CCCCCC";	 //use a hex value
$yearfontsize="12"; # in pt
$yearfontcolor="#000066";	 //use a hex value
$bordercolor="#CCCCCC";	 //use a hex value
$selectday="#CCCCCC";	 //use a hex value
$copyrightfontsize="7"; # in pt
$copyrightfontcolor="#990000";	 //use a hex value
$bordersize=1;	//use an integer
$ahovercolor="#FF0000";
### HTML ###

### Month Names ###
$monthName = array('January','February','March','April','May','June','July','August','September','October','November','December');
### Month Names ###

?>