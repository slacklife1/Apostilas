<?php
#################################################################################
#
#  Written by: Martynas Matuliauskas
#  E-mail: martynas.m@delfi.lt; web@editor.lt; admin@gomultiplex.com
#  Phone: +370 683 21711
#  Martynas Matuliauskas 2001-2002 Copyright(C)
#
#  Created:	2002 06 11
#  Modified:	2002 06 11
#
#  MD5signature:   qk8Lv0KrI5Kwoc16102mcfab8a80ddd706ad514682facdd369d5mcVd.JtGReX
#  
#  All rights reserved.
#
#################################################################################
#################################################################################

include("mm.calendar.php");
exit;

?>