<?php
//#####################################
//# APP (Another PHP Poll)            #
//# written by Tom Kohnen             #
//# http://www.tkohnen.com            #
//# Distributed under the GPL License #
//# Edit at your own risk             #
//#####################################

//############### Edit your admin-password here ##########

$password="12345";

//#########################################################
if(!isset($passwd) or $passwd!=$password){
echo "<table width=\"303\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" height=\"169\" bgcolor=\"#336699\" align=\"center\"><tr><td bgcolor=\"#336699\" height=\"110\"> 
<table width=\"311\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" bgcolor=\"#FFFFFF\" height=\"136\">
<tr><td height=\"175\"><div align=\"center\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><font size=\"2\">Enter 
your administration passsword!</font></b></font><br>
</div><form name=\"form1\" method=\"post\" action=\"$PHP_SELF\"><div align=\"center\">
<input type=\"password\" name=\"passwd\"><br><input type=\"submit\" name=\"Submit\" value=\"Login\">
</div></form></td></tr></table></td></tr></table>";

}elseif ($passwd==$password){
if (isset($submit)){
$fp=fopen($datafile, "w");
fputs($fp, $question."\n");
for($i=1; $i <=10; $i++){
if($answer[$i]==""){ break;}
$input=$answer[$i]."][".$image[$i]."][".$votes[$i]."\n";
fputs($fp, $input);
}
fclose($fp);
$config="<?php\n";
$config.="\$textcolor='$textcolor';\n";
$config.="\$linkcolor='#FFFFFF';\n";
$config.="\$bgcolor='$bgcolor';\n";
$config.="\$tableborder='$tableborder';\n";
$config.="\$timeout='$timeout';\n";
$config.="\$ip_file='$ip_file';\n";
$config.="\$font='$font';\n";
$config.="\$fontsize='$fontsize';\n";
$config.="\$datafile='$datafile';\n";
$config.="?>";
$fp=fopen($ip_file, "w");
fclose($fp);
$fp=fopen("config.php", "w");
fputs($fp, $config);
fclose($fp);
echo "<div align=\"center\"><b><font face=\"Verdana, Arial, Helvetica, sans-serif\" color=\"#00CC00\">Your 
  settings have been updated!</font></b></div>";
}

include('config.php');
$data=file($datafile);
$nb=count($data);
?>
<html>
<head>
<title>APP  (Another PHP Poll)</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#FFFFFF" vlink="#CCCCCC" alink="#CCCCCC">
<table width="760" border="0" cellspacing="1" cellpadding="0" align="center" height="566">
  <tr> 
    <td bgcolor="#336699" height="6"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF"><b>APP</b><font size="1"> 
      (Another PHP Poll) by Tom Kohnen ( <a href="http://www.tkohnen.com">www.tkohnen.com</a> 
      )</font></font></td>
  </tr>
  <tr> 
    <td bgcolor="#336699" height="221"> 
      <table width="768" border="0" cellspacing="1" cellpadding="5" height="634">
        <tr> 
          <td bgcolor="#EEEDEA" height="463" valign="top"> 
            <form name="APP" method="post" action="">
              <p><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b><i>Poll 
                Settings:</i></b><br>
                <br>
                </font></p>
              <table width="753" border="0" cellspacing="1" cellpadding="3" height="396" align="center">
                <tr> 
                  <td width="116" height="15"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>Question</b></font></td>
                  <td colspan="3" height="15"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="text" name="question" size="100" maxlength="150" value="<?php echo $data[0]; ?>">
                    </font></td>
                </tr>
                <tr> 
                  <td colspan="4" height="10">&nbsp;</td>
                </tr>
                <tr> 
                  <td colspan="4"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Here 
                    you can enter the options the users can choose from when they 
                    are voting, the first <b>2</b> have to be filled out, leave 
                    the ones blank you don't need!</font></td>
                </tr>
                <tr> 
                  <td width="116">&nbsp;</td>
                  <td width="246"> 
                    <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>Answer</b></font></div>
                  </td>
                  <td width="181"> 
                    <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>Image File</b></font></div>
                  </td>
				  <td> 
                    <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>Votes</b></font></div>
                  </td>
<?
for($i=1; $i<=10; $i++){
	$subdata=explode("][",$data[$i]);

echo "<tr><td width=\"116\">
<font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"2\"><b>Option $i</b></font></td>
<td width=\"246\"> 
<div align=\"center\"><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"2\"> 
<input type=\"text\" name=\"answer[$i]\" size=\"40\" maxlength=\"40\" value=\"$subdata[0]\"></font></div>
</td><td width=\"181\"> 
<div align=\"center\"><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"2\" > 
<input type=\"text\" name=\"image[$i]\" size=\"25\" maxlength=\"50\" value=\"$subdata[1]\">
</font></div></td><td width=\"181\"> 
<div align=\"center\"><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"2\">
<input type=\"text\" name=\"votes[$i]\" size=\"4\" maxlength=\"4\" value=\"$subdata[2]\">
</font></div></td></tr>";
}
?>

               </table>
              <hr width="95%" size="1" align="center" noshade>
              <table width="753" border="0" cellspacing="1" cellpadding="1">
                <tr bgcolor="#EEEDEA"> 
                  <td width="154" height="22"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>Colors</b></font></td>
                  <td width="148" height="22">&nbsp;</td>
                  <td width="22" height="22">&nbsp;</td>
                  <td colspan="2" height="22"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>Other 
                    settings</b></font></td>
                </tr>
                <tr bgcolor="#EEEDEA"> 
                  <td width="154"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Text</font></td>
                  <td width="148"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="text" name="textcolor" maxlength="10" size="10" value="<?php echo $textcolor; ?>">
                    </font></td>
                  <td width="22">&nbsp;</td>
                  <td width="218"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Timeout 
                    (hours)</font></td>
                  <td width="205"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="text" name="timeout" size="3" maxlength="3" value="<?php echo $timeout; ?>">
                    </font></td>
                </tr>
                <tr bgcolor="#EEEDEA"> 
                  <td width="154"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Background</font></td>
                  <td width="148"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="text" name="bgcolor" size="10" maxlength="10" value="<?php echo $bgcolor; ?>">
                    </font></td>
                  <td width="22">&nbsp;</td>
                  <td width="218"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">File 
                    where the data is stored</font></td>
                  <td width="205"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="text" name="datafile" size="25" maxlength="50" value="<?php echo $datafile; ?>">
                    </font></td>
                </tr>
                <tr bgcolor="#EEEDEA"> 
                  <td width="154"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Border</font></td>
                  <td width="148"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <b> 
                    <input type="text" name="tableborder" size="10" maxlength="10" value="<?php echo $tableborder; ?>">
                    </b> </font></td>
                  <td width="22"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"></font></td>
                  <td width="218"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">File 
                    where the IP adresses are stored</font></td>
                  <td width="205"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="text" name="ip_file" size="25" maxlength="50" value="<?php echo $ip_file; ?>">
                    </font></td>
                </tr>
                <tr bgcolor="#EEEDEA"> 
                  <td width="154"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Font</font></td>
                  <td width="148"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="text" name="font" size="20" maxlength="100" value="<?php echo $font; ?>">
                    </font></td>
                  <td width="22"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"></font></td>
                  <td width="218"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Font-Size</font></td>
                  <td width="205"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
                    <input type="text" name="fontsize" value="<?php echo $fontsize; ?>" size="1" maxlength="1">
                    </font></td>
                </tr>
              </table>
              <div align="center">
                <input type="hidden" name="passwd" value="<?php echo $password; ?>">
                <hr width="95%" size="1" align="center" noshade>
                <input type="submit" name="submit" value="Save your modifications">
                <input type="reset" name="Submit2" value="Reset">
              </div>
            </form>
            <p>&nbsp; </p>
            </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>
<?php } ?>