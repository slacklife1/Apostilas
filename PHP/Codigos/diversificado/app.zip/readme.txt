#####################################
# APP (Another PHP Poll)            #
# written by Tom Kohnen             #
# http://www.tkohnen.com            #
# Distributed under the GPL License #
#####################################

1) Installation

- Extract all files and change the  Admin password in "admin.php"
- Upload all files to your webserver
- Apply CHMOD 666 to the IP, CONFIG and DATA file (normally "ip.txt", "config.php" and "data.txt")

2) Configuration

- Go to admin.php, log in and modify everything to your needs
- If you change the DATA and IP file be sure to create a blank file (with the new name) and CHMOD it to 666

- If you have problems, mail me a complete description of it (error msg's) to tom@tkohnen.com !