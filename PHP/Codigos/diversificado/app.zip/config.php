<?php
$textcolor='#000000';
$linkcolor='#FFFFFF';
$bgcolor='#FFFFFF';
$tableborder='#336699';
$timeout='24';
$ip_file='ip.txt';
$font='Verdana, Arial, Helvetica, sans-serif';
$fontsize='2';
$datafile='data.txt';
?>