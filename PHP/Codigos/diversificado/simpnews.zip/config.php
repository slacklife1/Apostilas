<?php
// Edit this to fit your needs
// begin user editable part
	// hostname mysql running on
	$dbhost = "localhost";
	// name of database
	$dbname = "news";
	// username for database
	$dbuser = "root";
	// password for databaseuser
	$dbpasswd = "";
	// prefix for tables, so you can have multiple instances of
	// SimpNews in one database (please set before calling install or update)
	$tableprefix= "simpnews";
	// prefix for hostcache table, if you also use one of our other PHP scripts
	// you can set all hostcache tables to 1 prefix, so you only have 1 hostcache
	$hcprefix= "simpnews";
	// prefix for ip banlist table, if you also use one of our other PHP scripts
	// you can set all banlist tables to 1 prefix, so you only have 1 banlist
	$banprefix= "simpnews";
	// default language, you can create your own languagefile
	// for other languages in ./language
    $default_lang = "de";
    // language to use for admininterface
    $admin_lang = "de";
    // URL-Path for SimpNews instance. If you use http://www.myhost.com/simpnews
    // this is /simpnews
	$url_simpnews = "/simpnews";
	// URL-Path for graphics (no trailing slash)
	$url_gfx=$url_simpnews."/gfx";
	// URL-Path for emoticons (no trailing slash)
	$url_emoticons=$url_gfx."/emoticons";
	// URL-Path for icons (no trailing slash)
	$url_icons=$url_gfx."/icons";
	// complete path to directory containing scripts (without trailing slash)
	$path_simpnews = getenv("DOCUMENT_ROOT")."/simpnews";
	// complete path to directory containing graphics (without trailing slash)
	$path_gfx = getenv("DOCUMENT_ROOT")."/simpnews/gfx";
	// complete path to directory containing emoticons (without trailing slash)
	$path_emoticons = getenv("DOCUMENT_ROOT")."/simpnews/gfx/emoticons";
	// complete path to directory containing icons (without trailing slash)
	$path_icons = getenv("DOCUMENT_ROOT")."/simpnews/gfx/icons";
	// It should be safe to leave this alone. But if you do change it
	// make sure you don't set it to a variable allready in use (use a seperate
	// name for each instance of SimpNews)
	$cookiename = "simpnews";
	// It should be safe to leave these alone as well.
	$cookiepath = $url_simpnews;
	$cookiesecure = false;
	// This is the cookie name for the sessions cookie, you shouldn't have to change it
	// (for multiple instances use different names)
	$sesscookiename = "simpnewssession";
	// This is the number of seconds that a session lasts for, 3600 == 1 hour.
	// The session will exprire if the user dosn't view a page on the admininterface
	// in this amount of time.
	$sesscookietime = 600;
	// Full url for SimpNews with trailing slash
	$simpnews_fullurl = "http://localhost/simpnews/";
	// Set this to true if you want to use sessionid passed throught get and put requests
	// rathern than by cookie (for details reffer to readme.txt)
	$sessid_url=false;
	// maximal filesize for attachements by admin
	$maxfilesize=1000000;
	// Set to true if you want to have password recovery for admin interface enabled
	$enablerecoverpw=true;
	// Set this to the charset to be used as content encoding
	$contentcharset="iso-8859-1";
	// Set this to true, if you want to have attachements stored in file system instead of DB
	// WARNING: directory with attachements must be world writeable (chmod 777) on most servers
	// to allow webserver to write to it. Also mention -> if you delete the attachement only
	// in filesystem, the reference in the news still will be present and point to nothing.
	// 2nd: If you upload a file with same name as a file allready existing in the directory,
	// old file will be overwritten without further notice
	$attach_in_fs=false;
	// complete path to directory, where attachements should be stored
	$path_attach = getenv("DOCUMENT_ROOT")."/simpnews/attachements";
	// complete path to directory, where uploaded files should temporary be copied to
	// (PHP has to have write permissions on this directory)
	// Needed if open_basedir restriction is in effect. If your PHP instance can
	// access the default upload directory, you don't need to set it
	// $path_tempdir = getenv("DOCUMENT_ROOT")."/simpnews/admin/temp";
	// url to directory with attachements
	$url_attach = "/simpnews/attachements";
	// Set this to true if you want to use authentication by htacces rather then the
	// internal version (for details reffer to readme.txt)
	$enable_htaccess=false;
	// Please set this to the hostname, where your instance of SimpNews is installed
	$simpnewssitename="localhost";
	// Set to true if you want to try to get the real IP of the user.
	// Please note: This may not work for all HTTPDs.
	$try_real_ip=false;
	// please enter all fileextension your server uses for PHP scripts here
	$php_fileext=array("php","php3","phtml","php4");
    // For sending emails through SMTP server instead of PHP mail function set this to true
    $use_smtpmail = false;
    // SMTP Server to use
    $smtpserver = "localhost";
    // SMTP Port
    $smtpport = 25;
    // Senderdomain (set this to your domain)
    $smtpsenderdomain = "localhost";
    // SMTP Server needs authentication
    $smtpauth = false;
    // Authentication username
    $smtpuser = "";
	// Authentication password
	$smtppasswd = "";
	// minimal fontsize to use for dropdown BBcode button
	$minfontsize=-10;
	// maximal fontsize to use for dropdown BBcode button
	$maxfontsize=10;
	// set to false if file upload is disabled in php.ini
	$upload_avail=true;
	// set this to true, if you are using PHP 4.1.0 or greater (has to be set to true for
	// PHP 4.2.0 or greater)
	$new_global_handling=false;
	// leaving this to false is the best.
    $testmode = false;
// end user editable part
// you are not allowed to edit beyond this point
	require_once($path_simpnews.'/includes/global.inc');
?>
