<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
// begin user editable part
// complete path to directory containing simpnews scripts (without trailing slash)
$path_simpnews = getenv("DOCUMENT_ROOT")."/simpnews";
// end user editable part
//
require($path_simpnews.'/config.php');
require($path_simpnews.'/functions.php');
if(!isset($category))
	$category=0;
if(!isset($lang) || !$lang)
	$lang=$default_lang;
include($path_simpnews.'/language/lang_'.$lang.'.php');
$sql = "select * from ".$tableprefix."_settings where settingnr=1";
if(!$result = mysql_query($sql, $db))
    die();
if(!$myrow=mysql_fetch_array($result))
	die();
$enablesubscriptions=$myrow["enablesubscriptions"];
$maxage=$myrow["maxage"];
$entriesperpage=$myrow["entriesperpage"];
$allowcomments=$myrow["allowcomments"];
$numhotnews=$myrow["numhotnews"];
$servertimezone=$myrow["servertimezone"];
$displaytimezone=$myrow["displaytimezone"];
$sql = "select * from ".$tableprefix."_layout where lang='$lang'";
if(isset($layout))
	$sql.=" and id='$layout'";
else
	$sql.=" and deflayout=1";
if(!$result = mysql_query($sql, $db))
    die();
if(!$myrow=mysql_fetch_array($result))
	die();
$heading=$myrow["heading"];
$headingbgcolor=$myrow["headingbgcolor"];
$headingfontcolor=$myrow["headingfontcolor"];
$headingfont=$myrow["headingfont"];
$headingfontsize=$myrow["headingfontsize"];
$bordercolor=$myrow["bordercolor"];
$contentbgcolor=$myrow["contentbgcolor"];
$contentfontcolor=$myrow["contentfontcolor"];
$contentfont=$myrow["contentfont"];
$contentfontsize=$myrow["contentfontsize"];
$TableWidth=$myrow["TableWidth"];
$timestampfontcolor=$myrow["timestampfontcolor"];
$timestampfontsize=$myrow["timestampfontsize"];
$timestampfont=$myrow["timestampfont"];
$dateformat=$myrow["dateformat"];
$showcurrtime=$myrow["showcurrtime"];
$pagebgcolor=$myrow["pagebgcolor"];
$stylesheet=$myrow["stylesheet"];
$newsheadingbgcolor=$myrow["newsheadingbgcolor"];
$newsheadingfontcolor=$myrow["newsheadingfontcolor"];
$newsheadingstyle=$myrow["newsheadingstyle"];
$displayposter=$myrow["displayposter"];
$posterbgcolor=$myrow["posterbgcolor"];
$posterfontcolor=$myrow["posterfontcolor"];
$posterfont=$myrow["posterfont"];
$posterfontsize=$myrow["posterfontsize"];
$posterstyle=$myrow["posterstyle"];
$newsheadingfont=$myrow["newsheadingfont"];
$newsheadingfontsize=$myrow["newsheadingfontsize"];
$timestampbgcolor=$myrow["timestampbgcolor"];
$timestampstyle=$myrow["timestampstyle"];
$displaysubscriptionbox=$myrow["displaysubscriptionbox"];
$subscriptionbgcolor=$myrow["subscriptionbgcolor"];
$subscriptionfontcolor=$myrow["subscriptionfontcolor"];
$subscriptionfont=$myrow["subscriptionfont"];
$subscriptionfontsize=$myrow["subscriptionfontsize"];
$copyrightbgcolor=$myrow["copyrightbgcolor"];
$copyrightfontcolor=$myrow["copyrightfontcolor"];
$copyrightfont=$myrow["copyrightfont"];
$copyrightfontsize=$myrow["copyrightfontsize"];
$newsscrollerbgcolor=$myrow["newsscrollerbgcolor"];
$newsscrollerfontcolor=$myrow["newsscrollerfontcolor"];
$newsscrollerfont=$myrow["newsscrollerfont"];
$newsscrollerfontsize=$myrow["newsscrollerfontsize"];
$newsscrollerheight=$myrow["newsscrollerheight"];
$newsscrollerwidth=$myrow["newsscrollerwidth"];
$newsscrollerscrollspeed=$myrow["newsscrollerscrollspeed"];
$newsscrollerscrolldelay=$myrow["newsscrollerscrolldelay"];
$newsscrollerscrollpause=$myrow["newsscrollerscrollpause"];
$newsscrollermaxdays=$myrow["newsscrollermaxdays"];
$newsscrollermaxentries=$myrow["newsscrollermaxentries"];
$newsscrollertype=$myrow["newsscrollertype"];
$newsscrollerbgimage=$myrow["newsscrollerbgimage"];
$newsscrollerfgimage=$myrow["newsscrollerfgimage"];
$newsscrollermaxchars=$myrow["newsscrollermaxchars"];
$newsscrollertarget=$myrow["newsscrollertarget"];
$newsscrollerdisplaydate=$myrow["newsscrollerdisplaydate"];
$newsscrollerwordwrap=$myrow["newsscrollerwordwrap"];
$newsscrollerdateformat=$myrow["newsscrollerdateformat"];
$newsscrollernolinking=$myrow["newsscrollernolinking"];
$separatebylang=$myrow["separatebylang"];
$layout=$myrow["id"];
$crlf="\n";
if(isset($download))
{
	$crlf="\r\n";
	header('Content-Type: application/octetstream');
	header('Content-Disposition: filename="newsscroller_'.$lang.'.txt"');
}
if(!isset($scrolltype))
	$scrolltype=$newsscrollertype;
if(!isset($limitdays))
	$limitdays=$newsscrollermaxdays;
if(!isset($limitentries))
	$limitentries=$newsscrollermaxentries;
$sql = "select * from ".$tableprefix."_data ";
$firstarg=true;
if($separatebylang==1)
{
	if($firstarg)
	{
		$firstarg=false;
		$sql.="where lang='$lang' ";
	}
	else
		$sql.="and lang='$lang' ";
}
if($category>=0)
{
	if($firstarg)
	{
		$firstarg=false;
		$sql.="where category=$category ";
	}
	else
		$sql.= "and category=$category ";
}
if($limitdays>=0)
{
	$actdate = date("Y-m-d H:i:s");
	if($firstarg)
	{
		$firstarg=false;
		$sql.= "where date >= date_sub('$actdate', INTERVAL $limitdays DAY) ";
	}
	else
		$sql.= "and date >= date_sub('$actdate', INTERVAL $limitdays DAY) ";
}
$sql.= "order by date desc";
if($limitentries > 0)
	$sql.=" limit $limitentries";
if(!$result = mysql_query($sql, $db))
	die();
$bgcolor=str_replace("#","",$newsscrollerbgcolor);
$bgcolor=hexdec($bgcolor);
$fontcolor=str_replace("#","",$newsscrollerfontcolor);
$fontcolor=hexdec($fontcolor);
echo md5($copyright_note).$crlf;
if(mysql_num_rows($result)>0)
{
	while($myrow=mysql_fetch_array($result))
	{
		if($newsscrollerdisplaydate)
		{
			list($mydate,$mytime)=explode(" ",$myrow["date"]);
			list($year, $month, $day) = explode("-", $mydate);
			list($hour, $min, $sec) = explode(":",$mytime);
			if($month>0)
			{
				$displaytime=mktime($hour,$min,$sec,$month,$day,$year);
				$displaytime=$displaytime-($servertimezone*60*60);
				$displaytime=$displaytime+($displaytimezone*60*60);
				$displaydate=date($newsscrollerdateformat,$displaytime);
				echo $displaydate.":\\n";
			}
		}
		if($myrow["heading"])
		{
			$displayheading=undo_htmlentities(stripslashes($myrow["heading"]));
			if($scrolltype==1)
				$displayheading.=": ";
			else
				$displayheading.="\\n";
			echo $displayheading;
		}
		$displaytext = undo_htmlspecialchars(stripslashes($myrow["text"]));
		$displaytext = str_replace("\r","",$displaytext);
		$displaytext = undo_htmlentities($displaytext);
		if($scrolltype==1)
			$displaytext = str_replace("<BR>","    ",$displaytext);
		else
			$displaytext = str_replace("<BR>","\\n",$displaytext);
		$displaytext = strip_tags($displaytext);
		if(($newsscrollermaxchars>0) && (strlen($displaytext)>$newsscrollermaxchars))
		{
			$text = explode(" ", $displaytext);
			$i = 0;
			$length = 0;
			$displaytext="";
			while(($i<count($text)) && ($length<$newsscrollermaxchars))
			{
				$length+=strlen($text[$i]);
				if($length<=$newsscrollermaxchars)
				{
					$displaytext.=$text[$i]." ";
					$i++;
				}
			}
			if($i<count($text))
				$displaytext.="...";
		}
		echo $displaytext." ; ";
		if($newsscrollernolinking==0)
		{
			if($myrow["tickerurl"])
				echo $myrow["tickerurl"];
			else
				echo "http://".$simpnewssitename.$url_simpnews."/singlenews.php?newsnr=".$myrow["newsnr"]."&lang=$lang&layout=$layout&category=$category";
		}
		echo "; $bgcolor ; $fontcolor; $newsscrollerfont; $newsscrollerfontsize ; $newsscrollertarget ; ";
		if(isset($lastvisitdate))
		{
			list($mydate,$mytime)=explode(" ",$myrow["date"]);
			list($year, $month, $day) = explode("-", $mydate);
			list($hour, $min, $sec) = explode(":",$mytime);
			$thisentrydate=mktime($hour,$min,$sec,$month,$day,$year);
			if($thisentrydate>=$lastvisitdate)
				echo "1 ;";
			else
				echo "0 ;";
		}
		else
			echo "0 ;";
		echo " 2$crlf";
	}
}
else
{
		echo "$l_nonewnews ; ";
		if($newsscrollernolinking==0)
			echo "http://".$simpnewssitename.$url_simpnews."/news.php?lang=$lang&layout=$layout&category=$category";
		echo "; $bgcolor ; $fontcolor; $newsscrollerfont; $newsscrollerfontsize ; $newsscrollertarget ; 1 ; 0\n";
}
?>
