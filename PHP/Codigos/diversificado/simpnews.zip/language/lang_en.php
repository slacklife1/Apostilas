<?php
$l_poster = "poster";
$l_functiondisabled = "function disabled";
$l_subscriptionprelude = "subscribe news";
$l_email = "email";
$l_nofreemailer = "(no freemailers allowed)";
$l_subscribe = "subscribe";
$l_noemail = "You must provide an email";
$l_back = "back";
$l_novalidemail = "Please provide a valid email";
$l_forbidden_freemailer = "An email at this freemailer is not allowed for subscribers";
$l_hours = "hours";
$l_subscriptionconfirmmail = "Hello,\nYou have requested to subscribe news at {sitename}.\n
To ensure the request really was done by you, this confirmation request has been sent by us.\n
To activate subscription, please go to this URL within the next {confirmtime}:\n{confirmurl}\n
If you haven't requested subscription, you need not to do anything.";
$l_subscriptionconfirmmail_html = "<font face=\"Verdana, Geneva, Arial, Helvetica, sans-serif\" size=\"2\">Hello,\nYou have requested to subscribe news at {sitename}.\n
To ensure the request really was done by you, this confirmation request has been sent by us.\n
To activate subscription, please go to this URL within the next {confirmtime}:\n<a href=\"{confirmurl}\"><font face=\"Verdana, Geneva, Arial, Helvetica, sans-serif\" size=\"1\">{confirmurl}</font></a>\n
If you haven't requested subscription, you need not to do anything.</font>";
$l_subscriptionconfirmsubject = "News subscription ({sitename}) - confirmation request";
$l_subscriptiondone = "Thank you for subscribing to our news";
$l_allready_subscribed = "A subscription for this email allread exists.";
$l_allready_pending = "There allready is an unconfirmed subscription request for this email.<br>Please wait for confirmation request beeing sent to you by email.";
$l_missingemail = "No email submitted";
$l_missingid = "No ID submitted";
$l_noconfirmentry = "No subscription request for confirmation found.<br>Maybe the maximum amount of time to confirm your request has been passed<br>or you allready confirmed the request.";
$l_subscriptionconfirmed = "Your news subscription has been actived.";
$l_noremoveentry = "No subscription for removing found.";
$l_unsubscribed = "subscription removed.";
$l_emailtype = "Type for email";
$l_htmlmail = "HTML";
$l_ascmail = "plain text";
$l_subscriptionremoveprelude = "Do you really want to remove subscription for {email}?";
$l_yes = "yes";
$l_subscribe = "subscribe news";
$l_ok = "Ok";
$l_unsubscribe = "unsubscribe news";
$l_unsubscriptionconfirmmail = "Hello,\nyou have requeste to unsubscribe news at {sitename}.\n
To ensure the request really was done by you, this confirmation request has been sent by us.\n
To remove your subscription, please go to this URL:\n{confirmurl}\n
If you haven't requested tu unsubscribe, you need not to do anything.";
$l_unsubscriptionconfirmmail_html = "<font face=\"Verdana, Geneva, Arial, Helvetica, sans-serif\" size=\"2\">Hello,\nyou have requeste to unsubscribe news at {sitename}.\n
To ensure the request really was done by you, this confirmation request has been sent by us.\n
To remove your subscription, please go to this URL:\n<a href=\"{confirmurl}\"><font face=\"Verdana, Geneva, Arial, Helvetica, sans-serif\" size=\"1\">{confirmurl}</font></a>\n
If you haven't requested tu unsubscribe, you need not to do anything.</font>";
$l_unsubscriptionconfirmsubject = "News subscription ({sitename}) - unsubscribe request";
$l_unsubscribesent = "An email containing the URL to confirm your unsubscription has been sent.<br>Please follow the instructions in this email to remove your subscription.";
$l_page = "page";
$l_entries = "entries";
$l_of = "of";
$l_writecomment = "write comment";
$l_name = "Name";
$l_comment = "Comment";
$l_noname = "You have to provide a name";
$l_nocomment = "You have to provide a comment";
$l_callingerror = "calling error";
$l_commentposted = "comment saved";
$l_news = "news";
$l_comments = "comments";
$l_allnews = "all news";
$l_timeonserver = "actual time on server";
$l_search="search";
$l_dosearch = "search";
$l_result = "results";
$l_page_forward = "next page";
$l_page_back = "previous page";
$l_page_last = "last page";
$l_page_first = "first page";
$l_gotop = "goto top of page";
$l_newnews = "new news entries";
$l_nonewnews = "no new news entries";
$l_help = "help";
$l_noentriesfound = "no matching entries found";
$l_attachement = "download attachement";
$l_weekday = array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
$l_monthname = array("January","February","March","April","May","June","July","August","September","October","November","December");
$l_prevmonth = "previous Month";
$l_nextmonth = "next Month";
$l_newsforthisdate = "News for this date";
$l_noentries = "no entries";
$l_nosuchentry = "no such entry";
$l_noeventstoday = "no events today";
$l_new = "new";
$l_more = "more";
$l_eventsfor = "Events for";
$l_redirected = "You will be forwarded to the news shortly.";
$l_text = "Text";
$l_betweendate = "in the following Timeframe";
$l_startdate = "start date";
$l_enddate = "end date";
$l_dateselformat = array("month","day","year");
$l_day = "Day";
$l_month = "Month";
$l_year = "Year";
$l_morenews = "more news";
$l_general = "General";
$l_morenews = "more news";
$l_events = "Events";
$l_showevents = "show events";
$l_showcategory = "only show this category";
?>