<?php
$l_poster = "Verfasser";
$l_functiondisabled = "Funktion nicht verf&uuml;gbar";
$l_subscriptionprelude = "Abonnieren der News";
$l_email = "E-Mailadresse";
$l_nofreemailer = "(keine Adressen bei Freemailern)";
$l_subscribe = "abonnieren";
$l_noemail = "Sie m&uuml;ssen eine E-Mailadresse angeben";
$l_back = "zur&uuml;ck";
$l_novalidemail = "Bitte eine g&uuml;ltige E-Mailadresse angeben";
$l_forbidden_freemailer = "Eine E-Mailadresse bei diesem Freemailer ist f&uuml;r Abonemments nicht zul&auml;ssig";
$l_hours = "Stunden";
$l_subscriptionconfirmmail = "Hallo,\nSie haben sich beim Aboservice von {sitename} angemeldet.\n
Um sicher zu stellen, dass Sie sich auch selbst angemeldet haben, haben wir diesen Bestaetigungsmechanismus aktiviert.\n
Um das Abo zu aktivieren, besuchen sie bitte innerhalb von {confirmtime} folgende URL:\n{confirmurl}\n
Sollten Sie die Anmeldung nicht aktivieren wollen, so brauchen Sie nichts zu tun.";
$l_subscriptionconfirmmail_html = "<font face=\"Verdana, Geneva, Arial, Helvetica, sans-serif\" size=\"2\">Hallo,\nSie haben sich beim Aboservice von {sitename} angemeldet.\n
Um sicher zu stellen, dass Sie sich auch selbst angemeldet haben, haben wir diesen Best&auml;tigungsmechanismus aktiviert.\n
Um das Abo zu aktivieren, besuchen sie bitte innerhalb von <b>{confirmtime}</b> folgende URL:\n<a href=\"{confirmurl}\"><font face=\"Verdana, Geneva, Arial, Helvetica, sans-serif\" size=\"1\">{confirmurl}</font></a>\n
Sollten Sie die Anmeldung nicht aktivieren wollen, so brauchen Sie nichts zu tun.</font>";
$l_subscriptionconfirmsubject = "Aboservice ({sitename}) - Anmeldebestaetigung";
$l_subscriptiondone = "Danke, dass Sie unsere News abonniert haben.";
$l_allready_subscribed = "Ein Abonnement f&uuml;r diese E-Mailadresse besteht schon.";
$l_allready_pending = "Eine offene Abonnementanforderung f&uuml;r diese E-Mailadresse besteht schon.<br>Warten Sie bitte die Best&auml;tigungsanforderung ab und best&auml;tigen Sie dann Ihr Abonnement.";
$l_missingemail = "Keine Emailadresse &uuml;bergeben";
$l_missingid = "Keine ID &uuml;bergeben";
$l_noconfirmentry = "Kein entsprechender Abonnenteneintrag zur Best&auml;tigung gefunden.<br>Wahrscheinlich ist die maximale Wartezeit abgelaufen<br>oder Sie haben die Anforderung schon best&auml;tigt.";
$l_subscriptionconfirmed = "Ihr Abonnement f&uuml;r die News ist nun aktiviert.";
$l_noremoveentry = "Kein passender Abonnenteneintrag zum Entfernen gefunden.";
$l_unsubscribed = "Abonnement entfernt.";
$l_emailtype = "Format der E-Mail";
$l_htmlmail = "HTML";
$l_ascmail = "nur Text";
$l_subscriptionremoveprelude = "Wollen Sie das Abonnement f&uuml;r {email} wirklich l&ouml;schen?";
$l_yes = "Ja";
$l_subscribe = "News per E-Mail abbonieren";
$l_ok = "Ok";
$l_unsubscribe = "Abonnement l&ouml;schen";
$l_unsubscriptionconfirmmail = "<font face=\"Verdana, Geneva, Arial, Helvetica, sans-serif\" size=\"2\">Hallo,\nSie haben angefordert sich beim Aboservice von {sitename} abzumelden.\n
Um sicher zu stellen, dass Sie sich auch selbst abmelden wollen, haben wir diesen Bestaetigungsmechanismus aktiviert.\n
Um sich endgueltig abzumelden, besuchen sie bitte folgende URL:\n{confirmurl}\n
Sollten Sie die Abmeldung nicht vornehmen wollen, so brauchen Sie nichts zu tun.";
$l_unsubscriptionconfirmmail_html = "Hallo,\nSie haben angefordert sich beim Aboservice von {sitename} abzumelden.\n
Um sicher zu stellen, dass Sie sich auch selbst abmelden wollen, haben wir diesen Best&auml;tigungsmechanismus aktiviert.\n
Um sich endg&uuml;ltig abzumelden, besuchen sie bitte folgende URL:\n<a href=\"{confirmurl}\"><font face=\"Verdana, Geneva, Arial, Helvetica, sans-serif\" size=\"1\">{confirmurl}</font></a>\n
Sollten Sie die Abmeldung nicht vornehmen wollen, so brauchen Sie nichts zu tun.</font>";
$l_unsubscriptionconfirmsubject = "Aboservice ({sitename}) - Abmeldebestaetigung";
$l_unsubscribesent = "Eine E-Mail mit dem Best&auml;tigungslink f&uuml;r die Abmeldung wurde verschickt.<br>Bitte befolgen Sie die Anweisungen in der E-Mail, um sich endg&uuml;ltig abzumelden.";
$l_page = "Seite";
$l_entries = "Eintr&auml;ge";
$l_of = "von";
$l_writecomment = "Kommentar schreiben";
$l_name = "Name";
$l_comment = "Kommentar";
$l_noname = "Sie m&uuml;ssen Ihren Namen angeben";
$l_nocomment = "Sie m&uuml;ssen einen Kommentar eingeben";
$l_callingerror = "Aufruffehler";
$l_commentposted = "Kommentar gespeichert";
$l_news = "News";
$l_comments = "Kommentare";
$l_timeonserver = "aktuelle Uhrzeit am Server";
$l_allnews = "alle News";
$l_search = "Suche";
$l_dosearch = "suchen";
$l_result = "Ergebnis";
$l_page_forward = "n&auml;chste Seite";
$l_page_back = "Seite zur&uuml;ck";
$l_page_last = "letzte Seite";
$l_page_first = "erste Seite";
$l_gotop = "zum Seitenanfang";
$l_newnews = "neue News";
$l_nonewnews = "keine neuen News";
$l_noentriesfound = "keine passenden Eintr&auml;ge vorhanden";
$l_help = "Hilfe";
$l_attachement = "Dateianhang herunterladen";
$l_weekday = array("Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag");
$l_monthname = array("Januar","Februar","M&auml;rz","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember");
$l_prevmonth = "Monat zur&uuml;ck";
$l_nextmonth = "n&auml;chster Monat";
$l_newsforthisdate = "News von diesem Datum";
$l_noentries = "keine Eintr&auml;ge";
$l_nosuchentry = "kein solcher Eintrag vorhanden";
$l_noeventstoday = "keine Events";
$l_new = "neu";
$l_more = "weiter";
$l_eventsfor = "Events vom";
$l_redirected = "Sie werden in K&uuml;rze zu den News weitergeleitet.";
$l_text = "Text";
$l_betweendate = "im Zeitrahmen";
$l_startdate = "Anfangsdatum";
$l_enddate = "Enddatum";
$l_dateselformat = array("day","month","year");
$l_day = "Tag";
$l_month = "Monat";
$l_year = "Jahr";
$l_general = "Allgemeines";
$l_morenews = "weitere News";
$l_events = "Events";
$l_showevents = "Events anzeigen";
$l_showcategory = "Nur diese Kategorie anzeigen";
?>