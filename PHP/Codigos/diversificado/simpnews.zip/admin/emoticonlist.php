<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
require_once('../functions.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<?php
if(!isset($lang) || !$lang)
	$lang=$default_lang;
include_once('./language/lang_'.$lang.'.php');
?>
<html>
<head>
<meta name="generator" content="SimpNews v<?php echo $version?>, <?php echo $copyright_asc?>">
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<title><?php echo $l_emoticonlist?></title>
<?php
		if(is_ns4())
			echo "<link rel=stylesheet href=./snadm_ns4.css type=text/css>\n";
		else if(is_ns6())
			echo "<link rel=stylesheet href=./snadm_ns6.css type=text/css>\n";
		else if(is_opera())
			echo "<link rel=stylesheet href=./snadm_opera.css type=text/css>\n";
		else if(is_konqueror())
			echo "<link rel=stylesheet href=./snadm_konqueror.css type=text/css>\n";
		else if(is_gecko())
			echo "<link rel=stylesheet href=./snadm_gecko.css type=text/css>\n";
		else
			echo "<link rel=stylesheet href=./snadm.css type=text/css>\n";
?>
<script language='javascript'>
function chooseemoticon(code)
{
	mywin=parent.window.opener;
	addText = " "+code+" ";
	mywin.document.inputform.<?php echo $inputfield?>.value+=addText;
	parent.window.focus();
	top.window.close();
	mywin.document.inputform.<?php echo $inputfield?>.focus();
	return;
}
</SCRIPT>
</head>
<body onLoad="capture()">
<?php
	$sql = "select * from ".$tableprefix."_emoticons";
	if(!$result = mysql_query($sql, $db))
	   	die("Could not connect to the database.");
?>
<table width="98%" border="0" CELLPADDING="1" CELLSPACING="0" ALIGN="CENTER">
<tr><TD BGCOLOR="#000000">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<TR BGCOLOR="#94AAD6" ALIGN="CENTER">
<TR class="headingrow" ALIGN="CENTER"><td><h3><?php echo $l_emoticonlist?></h3></td>
</td>
<td class="actionrow" align="center" valign="middle" width="2%"><a class="pFo" href="javascript:parent.window.focus();top.window.close()"><img src="gfx/close.gif" border="0" title="<?php echo $l_close?>" alt="<?php echo $l_close?>"></a></td></tr>
</table></td></tr>
<tr><TD BGCOLOR="#000000">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<?php
	if(!$myrow=mysql_fetch_array($result))
	{
?>
<tr class="displayrow" align="center">
<td align="left" valign="middle" colspan="2">
<?php echo $l_noneavailable?></td></tr>
<?php
	}
	else
	{
?>
<tr class="rowheadings" align="center">
<td align="center" valign="middle" width="2%">&nbsp;</td>
<td class="rowheadings" align="center" valign="middle" width="20%">
<b><?php echo $l_code?></b></td>
<td class="rowheadings" align="center" valign="middle">
<b><?php echo $l_emotion?></b></td>
<?php
		do{
?>
<tr class="displayrow" align="center">
<td align="center" valign="middle" width="2%">
<font size="2" color="#000000">
<a class="listlink" href="javascript:chooseemoticon('<?php echo " ".stripslashes($myrow["code"])." "?>')"><img src="<?php echo "$url_emoticons/".stripslashes($myrow["emoticon_url"])?>" border="0"></a></font></td>
<td align="center" valign="middle" width="20%">
<font size="2" color="#000000">
<?php echo htmlentities(stripslashes($myrow["code"]))?></font></td>
<td align="center" valign="middle">
<font size="2" color="#000000">
<?php echo htmlentities(stripslashes($myrow["emotion"]))?></font></td></tr>
<?php
		}while($myrow=mysql_fetch_array($result));
	}
?>
</table></td></tr>
<tr><TD BGCOLOR="#000000">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<TR class="actionrow" ALIGN="CENTER"><td>&nbsp;</td>
<td align="center" valign="middle" width="2%"><a class="pFo" href="javascript:parent.window.focus();top.window.close()"><img src="gfx/close.gif" border="0" title="<?php echo $l_close?>" alt="<?php echo $l_close?>"></a></td></tr>
</table></td></tr></table>
</body></html>
