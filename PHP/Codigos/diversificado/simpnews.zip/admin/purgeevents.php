<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
if(!isset($lang) || !$lang)
	$lang=$admin_lang;
include_once('./language/lang_'.$lang.'.php');
require_once('./auth.php');
$page_title=$l_purgeevents;
require_once('./heading.php');
$sql = "select * from ".$tableprefix."_settings where settingnr=1";
if(!$result = mysql_query($sql, $db))
    die("Unable to connect to database.".mysql_error());
if(!$myrow=mysql_fetch_array($result))
	die("SimpNews not set up.");
$maxage=$myrow["maxage"];
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<?php
if($admin_rights < 2)
{
	echo "<tr class=\"errorrow\"><td align=\"center\">";
	die("$l_functionnotallowed");
}
if(isset($submit))
{
	$errors=0;
	if(!$purgedays)
	{
		echo "<tr class=\"errorrow\"><td align=\"center\">";
		echo "$l_nopurgedays</td></tr>";
		$errors=1;
	}
	if($errors==0)
	{
		$actdate = date("Y-m-d H:i:s");
		$sql = "DELETE FROM ".$tableprefix."_events where date<date_sub('$actdate', INTERVAL $purgedays DAY)";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td>Unable to update the database.");
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="displayrow"><td align="center"><?php echo $l_eventspurged?></td></tr>
</table></td></tr></table>
<?php
	}
	else
	{
		echo "<tr class=\"actionrow\" align=\"center\"><td>";
		echo "<a href=\"javascript:history.back()\">$l_back</a>";
		echo "</td></tr></table></td></tr></table>";
	}
	include('trailer.php');
	exit;
}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="inputrow">
<form method="post" action="<?php echo $act_script_url?>">
<?php
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="lang" value="<?php echo $lang?>">
<td align="center"><?php echo $l_purgeevents2a?> <input class="sninput" type="text" name="purgedays" size="3" maxlength="5"> <?php echo "$l_days $l_purgeevents2b"?></td></tr>
<tr class="actionrow">
<td align="center"><input class="snbutton" type="submit" name="submit" value="<?php echo $l_submit?>"></td></tr>
</table></td></tr></table>
<?php
include('./trailer.php');
?>