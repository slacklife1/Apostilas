<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
if(!isset($lang) || !$lang)
	$lang=$admin_lang;
include_once('./language/lang_'.$lang.'.php');
require_once('./auth.php');
$page_title=$l_layout;
require_once('./heading.php');
include_once('./includes/color_chooser.inc');
if(!isset($layoutlang))
	$layoutlang=$lang;
if($admin_rights < 2)
{
	die($l_functionotallowed);
}
if(isset($dellayout))
{
	$sql = "delete from ".$tableprefix."_layout where id='$layoutid'";
	if(!$result = mysql_query($sql, $db))
	    die("Could not connect to the database.");
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="displayrow"><td align="center" colspan="2"><?php echo $l_layoutdeleted?></td></tr>
</table></td></tr></table>
<div class="bottombox" align="center"><a href="<?php echo do_url_session("$act_script_url?lang=$lang")?>"><?php echo $l_selectlayout?></a></div>
<?
	include('./trailer.php');
	exit;
}
if(!isset($layoutid) && !isset($mode))
{
	$sql = "select * from ".$tableprefix."_layout group by id";
	if(!$result = mysql_query($sql, $db)) {
	    die("Could not connect to the database.");
	}
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<form method="post" action="<?php echo $act_script_url?>"><input type="hidden" name="lang" value="<?php echo $lang?>">
<?php
	if(is_konqueror())
		echo "<tr><td></td></tr>";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<?php
	if($myrow=mysql_fetch_array($result))
	{
?>
<tr class="inputrow"><td align="center" colspan="2"><?php echo $l_selectlayout?>:
<select name="layoutid">
<?
		do{
			echo "<option value=\"".$myrow["id"]."\"";
			if($myrow["deflayout"]==1)
				echo " selected";
			echo ">".$myrow["id"];
			if($myrow["deflayout"]==1)
				echo " [*]";
			echo "</option>";
		}while($myrow=mysql_fetch_array($result));
	}
?>
</select>&nbsp;&nbsp;
<input class="snbutton" type="submit" value="<?php echo $l_ok?>"><br>
<span class="remark"><?php echo $l_defremark?></span>
</td></tr></form>
<tr class="actionrow"><td align="center" colspan="2"><a href="<?php echo do_url_session("$act_script_url?lang=$lang&layoutid=")?>"><?php echo $l_newlayout?></a></td></tr>
</table></td></tr></table>
<?php
	include('./trailer.php');
	exit;
}
if(isset($setdefault))
{
	$sql = "update ".$tableprefix."_layout set deflayout=0 where deflayout=1";
	if(!$result = mysql_query($sql, $db))
	    die("Unable to connect to database.".mysql_error());
	$sql = "update ".$tableprefix."_layout set deflayout=1 where id='$layoutid'";
	if(!$result = mysql_query($sql, $db))
	    die("Unable to connect to database.".mysql_error());
}
if(isset($mode))
{
	if(!$layoutid)
	{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="errorrow"><td align="center" colspan="2"><?php echo $l_nolayoutid?></td></tr>
<?
		echo "<tr class=\"actionrow\" align=\"center\"><td>";
		echo "<a href=\"javascript:history.back()\">$l_back</a>";
		echo "</td></tr></table></td></tr></table>";
		include('./trailer.php');
		exit;
	}
	if(isset($hostnewsdisplayicons))
		$hotnewsicons=1;
	else
		$hotnewsicons=0;
	if(isset($hotnewsnohtml))
		$hotnewsnohtmlformatting=1;
	else
		$hotnewsnohtmlformatting=0;
	if(isset($hotnewsposter))
		$hotnewsdisplayposter=1;
	else
		$hotnewsdisplayposter=0;
	if(isset($shortheadings))
		$eventcalshortonlyheadings=1;
	else
		$eventcalshortonlyheadings=0;
	if(isset($eventcalshorts))
		$eventcalshortnews=1;
	else
		$eventcalshortnews=0;
	if(isset($enablesbcolors))
		$colorscrollbars=1;
	else
		$colorscrollbars=0;
	if($newsscrollermaxlines>4000)
		$newsscrollermaxlines=4000;
	if(isset($sepbylang))
		$separatebylang=1;
	else
		$separatebylang=0;
	if(isset($eventscrollerdate))
		$eventscrolleractdate=1;
	else
		$eventscrolleractdate=0;
	if(isset($typer2date))
		$newstyper2displaydate=1;
	else
		$newstyper2displaydate=0;
	if(isset($typer2waitentry))
		$newstyper2waitentry=1;
	else
		$newstyper2waitentry=0;
	if(isset($typer2newscreen))
		$newstyper2newscreen=1;
	else
		$newstyper2newscreen=0;
	if(isset($disablescrollerlink))
		$newsscrollernolinking=1;
	else
		$newsscrollernolinking=0;
	if(isset($typerscroll))
		$newstyperscroll=1;
	else
		$newstyperscroll=0;
	if(isset($typerdate))
		$newstyperdisplaydate=1;
	else
		$newstyperdisplaydate=0;
	if(isset($scrollerdate))
		$newsscrollerdisplaydate=1;
	else
		$newsscrollerdisplaydate=0;
	if(isset($scrollerwordwrap))
		$newsscrollerwordwrap=1;
	else
		$newsscrollerwordwrap=0;
	if(isset($scrollerstoponmouse))
		$newsscrollermousestop=1;
	else
		$newsscrollermousestop=0;
	if(isset($enablesubscriptionbox))
		$displaysubscriptionbox=1;
	else
		$displaysubscriptionbox=0;
	if(isset($enablecurrtime))
		$showcurrtime=1;
	else
		$showcurrtime=0;
	if(isset($showposter))
		$displayposter=1;
	else
		$displayposter=0;
	if(isset($enablecustomheader))
		$usecustomheader=1;
	else
		$usecustomheader=0;
	if(isset($enablecustomfooter))
		$usecustomfooter=1;
	else
		$usecustomfooter=0;
	if(isset($clearcustomheader))
		$customheader="";
	else
	{
		if($upload_avail && is_uploaded_file($HTTP_POST_FILES['customheaderfile']['tmp_name']))
		{
			if(isset($path_tempdir) && $path_tempdir)
			{
				$filename=$HTTP_POST_FILES['customheaderfile']['name'];
				if(!move_uploaded_file ($customheaderfile, $path_tempdir."/".$filename))
					die("unable to move uploaded file to $path_tempdir");
				$orgfile=$path_tempdir."/".$filename;
			}
			else
				$orgfile=$customheaderfile;
			$customheader = addslashes(get_file($orgfile));
			if(isset($path_tempdir) && $path_tempdir)
				unlink($orgfile);
		}
	}
	if(isset($clearcustomfooter))
		$customfooter="";
	else
	{
		if($upload_avail && is_uploaded_file($HTTP_POST_FILES['customfooterfile']['tmp_name']))
		{
			if(isset($path_tempdir) && $path_tempdir)
			{
				$filename=$HTTP_POST_FILES['customfooterfile']['name'];
				if(!move_uploaded_file ($customfooterfile, $path_tempdir."/".$filename))
					die("unable to move uploaded file to $path_tempdir");
				$orgfile=$path_tempdir."/".$filename;
			}
			else
				$orgfile=$customfooterfile;
			$customfooter = addslashes(get_file($orgfile));
			if(isset($path_tempdir) && $path_tempdir)
				unlink($orgfile);
		}
	}
	$defsignature=strip_tags($defsignature);
	if(!isset($layoutnr))
	{
		$sql = "insert into ".$tableprefix."_layout (lang, heading, headingbgcolor, headingfont, headingfontsize, headingfontcolor, ";
		$sql.= "contentbgcolor, contentfontcolor, contentfont, contentfontsize, timestampfontsize, timestampfontcolor, timestampfont, ";
		$sql.= "TableWidth, bordercolor, dateformat, showcurrtime, customheader, pagebgcolor, stylesheet, newsheadingstyle, ";
		$sql.= "newsheadingbgcolor, newsheadingfontcolor, newsheadingfont, newsheadingfontsize, posterbgcolor, posterfontcolor, posterfont, ";
		$sql.= "posterfontsize, posterstyle, displayposter, timestampbgcolor, timestampstyle, defsignature, displaysubscriptionbox, ";
		$sql.= "subscriptionbgcolor, subscriptionfontcolor, subscriptionfont, subscriptionfontsize, copyrightbgcolor, copyrightfontcolor, ";
		$sql.= "copyrightfont, copyrightfontsize, emailremark, id, customfooter, searchpic, backpic, pagetoppic, pagepic_back, pagepic_first, ";
		$sql.= "pagepic_next, pagepic_last, newssignal_on, newssignal_off, helppic, attachpic, prevpic, fwdpic, eventheading, event_dateformat, ";
		$sql.= "newstickerbgcolor, newstickerfontcolor, newstickerfont, newstickerfontsize, newstickerhighlightcolor, newstickerheight, newstickerwidth, ";
		$sql.= "newstickerscrollspeed, newstickerscrolldelay, newstickermaxdays, newstickermaxentries, newsscrollerbgcolor, newsscrollerfontcolor, ";
		$sql.= "newsscrollerfont, newsscrollerfontsize, newsscrollerheight, newsscrollerwidth, newsscrollerscrollspeed, newsscrollerscrolldelay, newsscrollerscrollpause, ";
		$sql.= "newsscrollertype, newsscrollermaxdays, newsscrollermaxentries, newsscrollerbgimage, newsscrollerfgimage, newsscrollermousestop, newsscrollermaxchars, ";
		$sql.= "newstickertarget, newsscrollertarget, newsscrollerxoffset, newsscrolleryoffset, newsscrollerdisplaydate, newsscrollerwordwrap, newsscrollerdateformat, ";
		$sql.= "newentrypic, newstypermaxentries, newstypermaxdays, newstyperbgcolor, newstyperfontcolor, newstyperfont, newstyperfontsize, newstyperfontstyle, ";
		$sql.= "newstyperdisplaydate, newstyperdateformat, newstyperxoffset, newstyperyoffset, newstypermaxchars, newstyperwidth, newstyperheight, newstyperbgimage, newstyperscroll, ";
		$sql.= "newsscrollernolinking, newstyper2maxentries, newstyper2bgcolor, newstyper2fontcolor, newstyper2fontsize, newstyper2displaydate, newstyper2newscreen, newstyper2waitentry, ";
		$sql.= "newstyper2dateformat, newstyper2indent, newstyper2linespace, newstyper2maxdays, newstyper2maxchars, newstyper2width, newstyper2height, newstyper2bgimage, newstyper2sound, ";
		$sql.= "newstyper2charpause, newstyper2linepause, newstyper2screenpause, eventscrolleractdate, separatebylang, headerfile, footerfile, headerfilepos, footerfilepos, ";
		$sql.= "usecustomheader, usecustomfooter, copyrightpos, categorybgcolor, categoryfontcolor, categoryfont, categoryfontsize, categorystyle, hotnews2target, news2target, ";
		$sql.= "newsscrollermaxlines, linkcolor, vlinkcolor, alinkcolor, morelinkcolor, morevlinkcolor, morealinkcolor, catlinkcolor, catvlinkcolor, catalinkcolor, ";
		$sql.= "commentlinkcolor, commentvlinkcolor, commentalinkcolor, attachlinkcolor, attachvlinkcolor, attachalinkcolor, pagenavlinkcolor, pagenavvlinkcolor, pagenavalinkcolor, ";
		$sql.= "colorscrollbars, sbfacecolor, sbhighlightcolor, sbshadowcolor, sb3dlightcolor, sbarrowcolor,  sbtrackcolor, sbdarkshadowcolor, snsel_bgcolor, snsel_fontcolor, snsel_font, ";
		$sql.= "snsel_fontsize, snsel_fontstyle, snsel_fontweight, snsel_borderstyle, snsel_borderwidth, snsel_bordercolor, morelinkfontsize, ";
		$sql.= "sninput_bgcolor, sninput_fontcolor, sninput_font, sninput_fontsize, sninput_fontstyle, sninput_fontweight, sninput_borderstyle, sninput_borderwidth, sninput_bordercolor, ";
		$sql.= "snisb_facecolor, snisb_highlightcolor, snisb_shadowcolor, snisb_3dlightcolor, snisb_arrowcolor,  snisb_trackcolor, snisb_darkshadowcolor, ";
		$sql.= "snbutton_bgcolor, snbutton_fontcolor, snbutton_font, snbutton_fontsize, snbutton_fontstyle, snbutton_fontweight, snbutton_borderstyle, snbutton_borderwidth, snbutton_bordercolor, ";
		$sql.= "eventlinkcolor, eventvlinkcolor, eventalinkcolor, eventlinkfontsize, actionlinkcolor, actionvlinkcolor, actionalinkcolor, pagebgpic, eventcalshortnews, eventcalshortlength, ";
		$sql.= "eventcalshortnum, eventcalshortonlyheadings, hotnewstarget, hotnewsdisplayposter, hotnewsnohtmlformatting, hotnewsicons, ns4style, ns6style, operastyle, geckostyle, konquerorstyle ";
		$sql.= ") values (";
		$sql.= "'$layoutlang', '$heading', '$headingbgcolor', '$headingfont', '$headingfontsize', '$headingfontcolor', ";
		$sql.= "'$contentbgcolor', '$contentfontcolor', '$contentfont', '$contentfontsize', '$timestampfontsize', '$timestampfontcolor', '$timestampfont', ";
		$sql.= "'$TableWidth', '$bordercolor', '$dateformat', $showcurrtime, '$customheader', '$pagebgcolor', '$stylesheet', $newsheadingstyle, ";
		$sql.= "'$newsheadingbgcolor', '$newsheadingfontcolor', '$newsheadingfont', '$newsheadingfontsize', '$posterbgcolor', '$posterfontcolor', '$posterfont', ";
		$sql.= "'$posterfontsize', $posterstyle, $displayposter, '$timestampbgcolor', $timestampstyle, '$defsignature', $displaysubscriptionbox, '$subscriptionbgcolor', ";
		$sql.= "'$subscriptionfontcolor', '$subscriptionfont', '$subscriptionfontsize', '$copyrightbgcolor', '$copyrightfontcolor', '$copyrightfont', ";
		$sql.= "'$copyrightfontsize', '$emailremark', '$layoutid', '$customfooter', '$searchpic', '$backpic', '$pagetoppic', '$pagepic_back', '$pagepic_first', ";
		$sql.= "'$pagepic_next', '$pagepic_last', '$newssignal_on', '$newssignal_off', '$helppic', '$attachpic', '$prevpic', '$fwdpic', '$eventheading', '$event_dateformat', ";
		$sql.= "'$newstickerbgcolor', '$newstickerfontcolor', '$newstickerfont', '$newstickerfontsize', '$newstickerhighlightcolor', $newstickerheight, $newstickerwidth, ";
		$sql.= "$newstickerscrollspeed, $newstickerscrolldelay, $newstickermaxdays, $newstickermaxentries, '$newsscrollerbgcolor', '$newsscrollerfontcolor', '$newsscrollerfont', ";
		$sql.= "'$newsscrollerfontsize', $newsscrollerheight, $newsscrollerwidth, $newsscrollerscrollspeed, $newsscrollerscrolldelay, $newsscrollerscrollpause, $newsscrollertype, ";
		$sql.= "$newsscrollermaxdays, $newsscrollermaxentries, '$newsscrollerbgimage', '$newsscrollerfgimage', $newsscrollermousestop, $newsscrollermaxchars, '$newstickertarget', ";
		$sql.= "'$newsscrollertarget', $newsscrollerxoffset, $newsscrolleryoffset, $newsscrollerdisplaydate, $newsscrollerwordwrap, '$newsscrollerdateformat', '$newentrypic', ";
		$sql.= "$newstypermaxentries, $newstypermaxdays, '$newstyperbgcolor', '$newstyperfontcolor', '$newstyperfont', '$newstyperfontsize', '$newstyperfontstyle', ";
		$sql.= "'$newstyperdisplaydate', '$newstyperdateformat', $newstyperxoffset, $newstyperyoffset, $newstypermaxchars, $newstyperwidth, $newstyperheight, '$newstyperbgimage', ";
		$sql.= "$newstyperscroll, $newsscrollernolinking, $newstyper2maxentries, '$newstyper2bgcolor', '$newstyper2fontcolor', '$newstyper2fontsize', $newstyper2displaydate, ";
		$sql.= "$newstyper2newscreen, $newstyper2waitentry, '$newstyper2dateformat', $newstyper2indent, $newstyper2linespace, $newstyper2maxdays, $newstypermaxchars, $newstyper2width, ";
		$sql.= "$newstyper2height, '$newstyper2bgimage', '$newstyper2sound', $newstyper2charpause, $newstyper2linepause, $newstyper2screenpause, $eventscrolleractdate, $separatebylang, ";
		$sql.= "'$headerfile', '$footerfile', $headerfilepos, $footerfilepos, $usecustomheader, $usecustomfooter, $copyrightpos, '$categorybgcolor', '$categoryfontcolor', ";
		$sql.= "'$categoryfont', '$categoryfontsize', $categorystyle, '$hotnews2target', '$news2target', $newsscrollermaxlines, '$linkcolor', '$vlinkcolor', '$alinkcolor', ";
		$sql.= "'$morelinkcolor', '$morevlinkcolor', '$morealinkcolor', '$catlinkcolor', '$catvlinkcolor', '$catalinkcolor', '$commentlinkcolor', '$commentvlinkcolor', '$commentalinkcolor', ";
		$sql.= "'$attachlinkcolor', '$attachvlinkcolor', '$attachalinkcolor', '$pagenavlinkcolor', '$pagenavvlinkcolor', '$pagenavalinkcolor', '$colorscrollbars', '$sbfacecolor', ";
		$sql.= "'$sbhighlightcolor', '$sbshadowcolor', '$sb3dlightcolor', '$sbarrowcolor',  '$sbtrackcolor', '$sbdarkshadowcolor', '$snsel_bgcolor', '$snsel_fontcolor', '$snsel_font', ";
		$sql.= "'$snsel_fontsize', '$snsel_fontstyle', '$snsel_fontweight', '$snsel_borderstyle', '$snsel_borderwidth', '$snsel_bordercolor', '$morelinkfontsize', ";
		$sql.= "'$sninput_bgcolor', '$sninput_fontcolor', '$sninput_font', '$sninput_fontsize', '$sninput_fontstyle', '$sninput_fontweight', '$sninput_borderstyle', '$sninput_borderwidth', '$sninput_bordercolor', ";
		$sql.= "'$snisb_facecolor', '$snisb_highlightcolor', '$snisb_shadowcolor', '$snisb_3dlightcolor', '$snisb_arrowcolor', '$snisb_trackcolor', '$snisb_darkshadowcolor', ";
		$sql.= "'$snbutton_bgcolor', '$snbutton_fontcolor', '$snbutton_font', '$snbutton_fontsize', '$snbutton_fontstyle', '$snbutton_fontweight', '$snbutton_borderstyle', '$snbutton_borderwidth', '$snbutton_bordercolor', ";
		$sql.= "'$eventlinkcolor', '$eventvlinkcolor', '$eventalinkcolor', '$eventlinkfontsize', '$actionlinkcolor', '$actionvlinkcolor', '$actionalinkcolor', '$pagebgpic', $eventcalshortnews, $eventcalshortlength, ";
		$sql.= "$eventcalshortnum, $eventcalshortonlyheadings, '$hotnewstarget', $hotnewsdisplayposter, $hotnewsnohtmlformatting, $hotnewsicons, '$ns4style', '$ns6style', '$operastyle', '$geckostyle', '$konquerorstyle' ";
		$sql.= ")";
	}
	else
	{

		$sql = "update ".$tableprefix."_layout set heading='$heading', headingbgcolor='$headingbgcolor', headingfont='$headingfont', headingfontsize='$headingfontsize', headingfontcolor='$headingfontcolor', ";
		$sql.= "contentbgcolor='$contentbgcolor', contentfontcolor='$contentfontcolor', contentfont='$contentfont', contentfontsize='$contentfontsize', ";
		$sql.= "timestampfontsize='$timestampfontsize', timestampfontcolor='$timestampfontcolor', timestampfont='$timestampfont', ";
		$sql.= "TableWidth='$TableWidth', bordercolor='$bordercolor', dateformat='$dateformat', showcurrtime=$showcurrtime, customheader='$customheader', pagebgcolor='$pagebgcolor', ";
		$sql.= "stylesheet='$stylesheet', newsheadingstyle=$newsheadingstyle, newsheadingbgcolor='$newsheadingbgcolor', newsheadingfontcolor='$newsheadingfontcolor', ";
		$sql.= "newsheadingfont='$newsheadingfont', newsheadingfontsize='$newsheadingfontsize', posterbgcolor='$posterbgcolor', posterfontcolor='$posterfontcolor', ";
		$sql.= "posterfont='$posterfont', posterfontsize='$posterfontsize', posterstyle=$posterstyle, displayposter=$displayposter, timestampbgcolor='$timestampbgcolor', timestampstyle=$timestampstyle, defsignature='$defsignature', ";
		$sql.= "displaysubscriptionbox=$displaysubscriptionbox, subscriptionbgcolor='$subscriptionbgcolor', subscriptionfontcolor='$subscriptionfontcolor', subscriptionfont='$subscriptionfont', ";
		$sql.= "subscriptionfontsize='$subscriptionfontsize', copyrightbgcolor='$copyrightbgcolor', copyrightfontcolor='$copyrightfontcolor', copyrightfont='$copyrightfont', copyrightfontsize='$copyrightfontsize', emailremark='$emailremark', ";
		$sql.= "customfooter='$customfooter', searchpic='$searchpic', backpic='$backpic', pagetoppic='$pagetoppic', pagepic_back='$pagepic_back', pagepic_first='$pagepic_first', pagepic_next='$pagepic_next', pagepic_last='$pagepic_last', ";
		$sql.= "newssignal_on='$newssignal_on', newssignal_off='$newssignal_off', helppic='$helppic', attachpic='$attachpic', prevpic='$prevpic', fwdpic='$fwdpic', eventheading='$eventheading', event_dateformat='$event_dateformat', ";
		$sql.= "newstickerbgcolor='$newstickerbgcolor', newstickerfontcolor='$newstickerfontcolor', newstickerfont='$newstickerfont', newstickerfontsize='$newstickerfontsize', newstickerhighlightcolor='$newstickerhighlightcolor',  ";
		$sql.= "newstickerwidth=$newstickerwidth, newstickerheight=$newstickerheight, newstickerscrollspeed=$newstickerscrollspeed, newstickerscrolldelay=$newstickerscrolldelay, newstickermaxdays=$newstickermaxdays, newstickermaxentries=$newstickermaxentries, ";
		$sql.= "newsscrollerbgcolor='$newsscrollerbgcolor', newsscrollerfontcolor='$newsscrollerfontcolor', newsscrollerfont='$newsscrollerfont', newsscrollerfontsize='$newsscrollerfontsize', newsscrollerscrollpause=$newsscrollerscrollpause,  newsscrollertype=$newsscrollertype, ";
		$sql.= "newsscrollerwidth=$newsscrollerwidth, newsscrollerheight=$newsscrollerheight, newsscrollerscrollspeed=$newsscrollerscrollspeed, newsscrollerscrolldelay=$newsscrollerscrolldelay, newsscrollermaxdays=$newsscrollermaxdays, newsscrollermaxentries=$newsscrollermaxentries, ";
		$sql.= "newsscrollerbgimage='$newsscrollerbgimage', newsscrollerfgimage='$newsscrollerfgimage', newsscrollermousestop=$newsscrollermousestop, newsscrollermaxchars=$newsscrollermaxchars, newstickertarget='$newstickertarget', newsscrollertarget='$newsscrollertarget', ";
		$sql.= "newsscrollerxoffset=$newsscrollerxoffset, newsscrolleryoffset=$newsscrolleryoffset, newsscrollerdisplaydate=$newsscrollerdisplaydate, newsscrollerwordwrap=$newsscrollerwordwrap, newsscrollerdateformat='$newsscrollerdateformat', newentrypic='$newentrypic', ";
		$sql.= "newstypermaxentries=$newstypermaxentries, newstypermaxdays=$newstypermaxdays, newstyperbgcolor='$newstyperbgcolor', newstyperfontcolor='$newstyperfontcolor', newstyperfont='$newstyperfont', newstyperfontsize='$newstyperfontsize', newstyperfontstyle='$newstyperfontstyle', ";
		$sql.= "newstyperdisplaydate=$newstyperdisplaydate, newstyperdateformat='$newstyperdateformat', newstyperxoffset=$newstyperxoffset, newstyperyoffset=$newstyperyoffset, newstypermaxchars=$newstypermaxchars, newstyperwidth=$newstyperwidth, newstyperheight=$newstyperheight, ";
		$sql.= "newstyperbgimage='$newstyperbgimage', newstyperscroll=$newstyperscroll, newsscrollernolinking=$newsscrollernolinking, newstyper2maxentries=$newstyper2maxentries, newstyper2bgcolor='$newstyper2bgcolor', newstyper2fontcolor='$newstyper2fontcolor', ";
		$sql.= "newstyper2fontsize='$newstyper2fontsize', newstyper2displaydate=$newstyper2displaydate, newstyper2newscreen=$newstyper2newscreen, newstyper2waitentry=$newstyper2waitentry, newstyper2dateformat='$newstyper2dateformat', newstyper2indent=$newstyper2indent, ";
		$sql.= "newstyper2linespace=$newstyper2linespace, newstyper2maxdays=$newstyper2maxdays, newstyper2width=$newstyper2width, newstyper2height=$newstyper2height, newstyper2bgimage='$newstyper2bgimage', newstyper2sound='$newstyper2sound', newstyper2charpause=$newstyper2charpause, ";
		$sql.= "newstyper2linepause=$newstyper2linepause, newstyper2screenpause=$newstyper2screenpause, newstyper2maxchars=$newstyper2maxchars, eventscrolleractdate=$eventscrolleractdate, separatebylang=$separatebylang, headerfile='$headerfile', footerfile='$footerfile', ";
		$sql.= "headerfilepos=$headerfilepos, footerfilepos=$footerfilepos, usecustomheader=$usecustomheader, usecustomfooter=$usecustomfooter, copyrightpos=$copyrightpos, categorybgcolor='$categorybgcolor', categoryfontcolor='$categoryfontcolor', categoryfont='$categoryfont', ";
		$sql.= "categoryfontsize='$categoryfontsize', categorystyle=$categorystyle, hotnews2target='$hotnews2target', news2target='$news2target', newsscrollermaxlines='$newsscrollermaxlines', linkcolor='$linkcolor', vlinkcolor='$vlinkcolor', alinkcolor='$alinkcolor', ";
		$sql.= "morelinkcolor='$morelinkcolor', morevlinkcolor='$morevlinkcolor', morealinkcolor='$morealinkcolor', catlinkcolor='$catlinkcolor', catvlinkcolor='$catvlinkcolor', catalinkcolor='$catalinkcolor', commentlinkcolor='$commentlinkcolor', ";
		$sql.= "commentvlinkcolor='$commentvlinkcolor', commentalinkcolor='$commentalinkcolor', attachlinkcolor='$attachlinkcolor', attachvlinkcolor='$attachvlinkcolor', attachalinkcolor='$attachalinkcolor', pagenavlinkcolor='$pagenavlinkcolor', ";
		$sql.= "pagenavalinkcolor='$pagenavalinkcolor', pagenavvlinkcolor='$pagenavvlinkcolor', colorscrollbars=$colorscrollbars, sb3dlightcolor='$sb3dlightcolor', sbarrowcolor='$sbarrowcolor', sbdarkshadowcolor='$sbdarkshadowcolor', sbfacecolor='$sbfacecolor', ";
		$sql.= "sbhighlightcolor='$sbhighlightcolor', sbshadowcolor='$sbshadowcolor', sbtrackcolor='$sbtrackcolor', snsel_bgcolor='$snsel_bgcolor', snsel_fontcolor='$snsel_fontcolor', snsel_font='$snsel_font', snsel_fontsize='$snsel_fontsize', ";
		$sql.= "snsel_fontstyle='$snsel_fontstyle', snsel_fontweight='$snsel_fontweight', snsel_borderstyle='$snsel_borderstyle', snsel_borderwidth='$snsel_borderwidth', snsel_bordercolor='$snsel_bordercolor', morelinkfontsize='$morelinkfontsize', ";
		$sql.= "sninput_bgcolor='$sninput_bgcolor', sninput_fontcolor='$sninput_fontcolor', sninput_font='$sninput_font', sninput_fontsize='$sninput_fontsize', sninput_fontstyle='$sninput_fontstyle', sninput_fontweight='$sninput_fontweight', sninput_borderstyle='$sninput_borderstyle', sninput_borderwidth='$sninput_borderwidth', sninput_bordercolor='$sninput_bordercolor', ";
		$sql.= "snisb_3dlightcolor='$snisb_3dlightcolor', snisb_arrowcolor='$snisb_arrowcolor', snisb_darkshadowcolor='$snisb_darkshadowcolor', snisb_facecolor='$snisb_facecolor', snisb_highlightcolor='$snisb_highlightcolor', snisb_shadowcolor='$snisb_shadowcolor', snisb_trackcolor='$snisb_trackcolor', ";
		$sql.= "snbutton_bgcolor='$snbutton_bgcolor', snbutton_fontcolor='$snbutton_fontcolor', snbutton_font='$snbutton_font', snbutton_fontsize='$snbutton_fontsize', snbutton_fontstyle='$snbutton_fontstyle', snbutton_fontweight='$snbutton_fontweight', snbutton_borderstyle='$snbutton_borderstyle', snbutton_borderwidth='$snbutton_borderwidth', snbutton_bordercolor='$snbutton_bordercolor', ";
		$sql.= "eventlinkcolor='$eventlinkcolor', eventvlinkcolor='$eventvlinkcolor', eventalinkcolor='$eventalinkcolor', eventlinkfontsize='$eventlinkfontsize', actionlinkcolor='$actionlinkcolor', actionvlinkcolor='$actionvlinkcolor', actionalinkcolor='$actionalinkcolor', pagebgpic='$pagebgpic', ";
		$sql.= "eventcalshortnews=$eventcalshortnews, eventcalshortlength=$eventcalshortlength, eventcalshortnum=$eventcalshortnum, eventcalshortonlyheadings=$eventcalshortonlyheadings, hotnewstarget='$hotnewstarget', hotnewsdisplayposter=$hotnewsdisplayposter, hotnewsnohtmlformatting=$hotnewsnohtmlformatting, ";
		$sql.= "hotnewsicons=$hotnewsicons, ns4style='$ns4style', ns6style='$ns6style', operastyle='$operastyle', geckostyle='$geckostyle', konquerorstyle='$konquerorstyle' ";
		$sql.= "where layoutnr=$layoutnr";
	}
	if(!$result = mysql_query($sql, $db))
	    die("Unable to connect to database.".mysql_error());
}
$sql = "select * from ".$tableprefix."_layout where lang='$layoutlang' and id='$layoutid'";
if(!$result = mysql_query($sql, $db))
    die("Unable to connect to database.".mysql_error());
if(!$myrow=mysql_fetch_array($result))
{
	$heading=$l_news;
	$headingbgcolor="#94AAD6";
	$headingfontcolor="#FFF0C0";
	$headingfont="Verdana, Geneva, Arial, Helvetica, sans-serif";
	$headingfontsize="+2";
	$bordercolor="#000000";
	$contentbgcolor="#c0c0c0";
	$contentfontcolor="#000000";
	$contentfont="Verdana, Geneva, Arial, Helvetica, sans-serif";
	$contentfontsize="2";
	$TableWidth="98%";
	$timestampfontcolor="#000000";
	$timestampfontsize="1";
	$timestampfont="Verdana, Geneva, Arial, Helvetica, sans-serif";
	$dateformat="d.m.Y H:i:s";
	$showcurrtime=0;
	$customheader="";
	$pagebgcolor="#c0c0c0";
	$stylesheet="simpnews.css";
	$newsheadingbgcolor="#c0c0c0";
	$newsheadingfontcolor="#222222";
	$newsheadingfont="Verdana, Geneva, Arial, Helvetica, sans-serif";
	$newsheadingfontsize="3";
	$newsheadingstyle=0;
	$displayposter=1;
	$posterbgcolor="#c0c0c0";
	$posterfontcolor="#000000";
	$posterfont="Verdana, Geneva, Arial, Helvetica, sans-serif";
	$posterfontsize="1";
	$posterstyle=0;
	$timestampbgcolor="#c0c0c0";
	$timestampstyle=0;
	$defsignature="";
	$displaysubscriptionbox=1;
	$subscriptionbgcolor="#94AAD6";
	$subscriptionfontcolor="#FFF0C0";
	$subscriptionfont="Verdana, Geneva, Arial, Helvetica, sans-serif";
	$subscriptionfontsize="2";
	$copyrightbgcolor="#c0c0c0";
	$copyrightfontcolor="#000000";
	$copyrightfont="Verdana, Geneva, Arial, Helvetica, sans-serif";
	$copyrightfontsize="1";
	$emailremark="";
	$deflayout=0;
	$costumfooter="";
	$searchpic="search.gif";
	$backpic="back.gif";
	$pagetoppic="pagetop.gif";
	$pagepic_back="prev.gif";
	$pagepic_first="first.gif";
	$pagepic_next="next.gif";
	$pagepic_last="last.gif";
	$newssignal_on="blink.gif";
	$newssignal_off="off.gif";
	$helppic="help.gif";
	$attachpic="attach.gif";
	$prevpic="prev_big.gif";
	$fwdpic="next_big.gif";
	$eventheading="Ereignisse";
	$event_dateformat="d.m.Y";
	$newstickerbgcolor="#cccccc";
	$newstickerfontcolor="#000000";
	$newstickerfont="Verdana";
	$newstickerfontsize="12";
	$newstickerhighlightcolor="#0000ff";
	$newstickerheight="20";
	$newstickerwidth="300";
	$newstickerscrollspeed="1";
	$newstickerscrolldelay="30";
	$newstickermaxdays = "0";
	$newstickermaxentries = "0";
	$newsscrollerbgcolor="#cccccc";
	$newsscrollerfontcolor="#000000";
	$newsscrollerfont="Verdana";
	$newsscrollerfontsize="12";
	$newsscrollerheight="20";
	$newsscrollerwidth="300";
	$newsscrollerscrollspeed="1";
	$newsscrollerscrolldelay="30";
	$newsscrollerscrollpause="2000";
	$newsscrollermaxdays = "0";
	$newsscrollermaxentries = "0";
	$newsscrollertype="4";
	$newsscrollerbgimage="";
	$newsscrollerfgimage="";
	$newsscrollermousestop=0;
	$newsscrollermaxchars=0;
	$newstickertarget="_self";
	$newsscrollertarget="_self";
	$newsscrollerxoffset=0;
	$newsscrolleryoffset=0;
	$newsscrollerdisplaydate=1;
	$newsscrollerwordwrap=1;
	$newsscrollerdateformat="Y-m-d";
	$newentrypic="new.gif";
	$newstyperbgcolor="#cccccc";
	$newstyperfontcolor="#000000";
	$newstyperfont="Verdana";
	$newstyperfontsize="12";
	$newstyperfontstyle=0;
	$newstyperheight="20";
	$newstyperwidth="300";
	$newstyperscroll=0;
	$newstypermaxdays = "0";
	$newstypermaxentries = "0";
	$newstyperbgimage="";
	$newstypermaxchars=0;
	$newstyperxoffset=0;
	$newstyperyoffset=0;
	$newstyperdisplaydate=1;
	$newstyperdateformat="Y-m-d";
	$newsscrollernolinking=0;
	$newstyper2maxentries=0;
	$newstyper2bgcolor="#cccccc";
	$newstyper2fontcolor="#000000";
	$newstyper2fontsize=12;
	$newstyper2displaydate=1;
	$newstyper2newscreen=1;
	$newstyper2waitentry=0;
	$newstyper2dateformat="Y-m-d";
	$newstyper2indent=8;
	$newstyper2linespace=15;
	$newstyper2maxdays=-1;
	$newstyper2width=300;
	$newstyper2height=200;
	$newstyper2bgimage="";
	$newstyper2sound="$url_simpnews/sfx/tick.au";
	$newstyper2charpause=50;
	$newstyper2linepause=500;
	$newstyper2screenpause=5000;
	$newstyper2maxchars=0;
	$eventscrolleractdate=1;
	$separatebylang=1;
	$headerfile="";
	$footerfile="";
	$headerfilepos=0;
	$footerfilepos=0;
	$usecustomheader=0;
	$usecustomfooter=0;
	$copyrightpos=0;
	$categorybgcolor="#999999";
	$categoryfont="Verdana, Geneva, Arial, Helvetica, sans-serif";
	$categoryfontcolor="#EEEEEE";
	$categoryfontsize="3";
	$categorystyle=1;
	$hotnews2target="_self";
	$news2target="_self";
	$newsscrollermaxlines=20;
	$linkcolor="#696969";
	$vlinkcolor="#696969";
	$alinkcolor="#696969";
	$morelinkcolor="#191970";
	$morevlinkcolor="#191970";
	$morealinkcolor="#191970";
	$catlinkcolor="#F0FFFF";
	$catvlinkcolor="#F0FFFF";
	$catalinkcolor="#F0FFFF";
	$commentlinkcolor="#191970";
	$commentvlinkcolor="#191970";
	$commentalinkcolor="#191970";
	$attachlinkcolor="#CD5C5C";
	$attachvlinkcolor="#CD5C5C";
	$attachalinkcolor="#CD5C5C";
	$pagenavlinkcolor="#FFF0C0";
	$pagenavvlinkcolor="#FFF0C0";
	$pagenavalinkcolor="#FFF0C0";
	$colorscrollbars=1;
	$sbfacecolor="#94AAD6";
	$sbhighlightcolor="#AFEEEE";
	$sbshadowcolor="#ADD8E6";
	$sb3dlightcolor="#1E90FF";
	$sbarrowcolor="#0000ff";
	$sbtrackcolor="#E0FFFF";
	$sbdarkshadowcolor="#4682B4";
	$snsel_bgcolor="#DCDCDC";
	$snsel_fontcolor="#000000";
	$snsel_font="Verdana, Geneva, Arial, Helvetica, sans-serif";
	$snsel_fontsize="10pt";
	$snsel_fontstyle="normal";
	$snsel_fontweight="normal";
	$snsel_borderstyle="none";
	$snsel_borderwidth="";
	$snsel_bordercolor="";
	$morelinkfontsize="8pt";
	$sninput_bgcolor="#DCDCDC";
	$sninput_fontcolor="#000000";
	$sninput_font="Verdana, Geneva, Arial, Helvetica, sans-serif";
	$sninput_fontsize="10pt";
	$sninput_fontstyle="normal";
	$sninput_fontweight="normal";
	$sninput_borderstyle="solid";
	$sninput_borderwidth="thin";
	$sninput_bordercolor="#696969";
	$snisb_facecolor="#94AAD6";
	$snisb_highlightcolor="#AFEEEE";
	$snisb_shadowcolor="#ADD8E6";
	$snisb_3dlightcolor="#1E90FF";
	$snisb_arrowcolor="#0000ff";
	$snisb_trackcolor="#E0FFFF";
	$snisb_darkshadowcolor="#4682B4";
	$snbutton_bgcolor="#94AAD6";
	$snbutton_fontcolor="#FFFAF0";
	$snbutton_font="Verdana, Geneva, Arial, Helvetica, sans-serif";
	$snbutton_fontsize="9pt";
	$snbutton_fontstyle="normal";
	$snbutton_fontweight="normal";
	$snbutton_borderstyle="ridge";
	$snbutton_borderwidth="thin";
	$snbutton_bordercolor="#483D8B";
	$eventlinkcolor="#696969";
	$eventvlinkcolor="#696969";
	$eventalinkcolor="#696969";
	$eventlinkfontsize="9pt";
	$actionlinkcolor="#F0FFFF";
	$actionvlinkcolor="#F0FFFF";
	$actionalinkcolor="#F0FFFF";
	$pagebgpic="pagebg.gif";
	$eventcalshortnews=0;
	$eventcalshortlength=20;
	$eventcalshortnum=3;
	$eventcalshortonlyheadings=1;
	$hotnewstarget="_self";
	$hotnewsdisplayposter=1;
	$hotnewsnohtmlformatting=0;
	$hotnewsicons=1;
	$ns4style="simpnews_ns4.css";
	$ns6style="simpnews_ns6.css";
	$operastyle="simpnews_opera.css";
	$geckostyle="simpnews_gecko.css";
	$konquerorstyle="simpnews_konqueror.css";
}
else
{
	$heading=$myrow["heading"];
	$headingbgcolor=$myrow["headingbgcolor"];
	$headingfontcolor=$myrow["headingfontcolor"];
	$headingfont=$myrow["headingfont"];
	$headingfontsize=$myrow["headingfontsize"];
	$bordercolor=$myrow["bordercolor"];
	$contentbgcolor=$myrow["contentbgcolor"];
	$contentfontcolor=$myrow["contentfontcolor"];
	$contentfont=$myrow["contentfont"];
	$contentfontsize=$myrow["contentfontsize"];
	$TableWidth=$myrow["TableWidth"];
	$timestampfontcolor=$myrow["timestampfontcolor"];
	$timestampfontsize=$myrow["timestampfontsize"];
	$timestampfont=$myrow["timestampfont"];
	$dateformat=$myrow["dateformat"];
	$showcurrtime=$myrow["showcurrtime"];
	$customheader=stripslashes($myrow["customheader"]);
	$pagebgcolor=$myrow["pagebgcolor"];
	$stylesheet=$myrow["stylesheet"];
	$newsheadingbgcolor=$myrow["newsheadingbgcolor"];
	$newsheadingfontcolor=$myrow["newsheadingfontcolor"];
	$newsheadingstyle=$myrow["newsheadingstyle"];
	$displayposter=$myrow["displayposter"];
	$posterbgcolor=$myrow["posterbgcolor"];
	$posterfontcolor=$myrow["posterfontcolor"];
	$posterfont=$myrow["posterfont"];
	$posterfontsize=$myrow["posterfontsize"];
	$posterstyle=$myrow["posterstyle"];
	$newsheadingfont=$myrow["newsheadingfont"];
	$newsheadingfontsize=$myrow["newsheadingfontsize"];
	$timestampbgcolor=$myrow["timestampbgcolor"];
	$timestampstyle=$myrow["timestampstyle"];
	$defsignature=$myrow["defsignature"];
	$displaysubscriptionbox=$myrow["displaysubscriptionbox"];
	$subscriptionbgcolor=$myrow["subscriptionbgcolor"];
	$subscriptionfontcolor=$myrow["subscriptionfontcolor"];
	$subscriptionfont=$myrow["subscriptionfont"];
	$subscriptionfontsize=$myrow["subscriptionfontsize"];
	$copyrightbgcolor=$myrow["copyrightbgcolor"];
	$copyrightfontcolor=$myrow["copyrightfontcolor"];
	$copyrightfont=$myrow["copyrightfont"];
	$copyrightfontsize=$myrow["copyrightfontsize"];
	$emailremark=$myrow["emailremark"];
	$layoutid=$myrow["id"];
	$deflayout=$myrow["deflayout"];
	$layoutnr=$myrow["layoutnr"];
	$customfooter=$myrow["customfooter"];
	$searchpic=$myrow["searchpic"];
	$backpic=$myrow["backpic"];
	$pagetoppic=$myrow["pagetoppic"];
	$pagepic_back=$myrow["pagepic_back"];
	$pagepic_first=$myrow["pagepic_first"];
	$pagepic_next=$myrow["pagepic_next"];
	$pagepic_last=$myrow["pagepic_last"];
	$newssignal_on=$myrow["newssignal_on"];
	$newssignal_off=$myrow["newssignal_off"];
	$helppic=$myrow["helppic"];
	$attachpic=$myrow["attachpic"];
	$prevpic=$myrow["prevpic"];
	$fwdpic=$myrow["fwdpic"];
	$eventheading=$myrow["eventheading"];
	$event_dateformat=$myrow["event_dateformat"];
	$newstickerbgcolor=$myrow["newstickerbgcolor"];
	$newstickerfontcolor=$myrow["newstickerfontcolor"];
	$newstickerfont=$myrow["newstickerfont"];
	$newstickerfontsize=$myrow["newstickerfontsize"];
	$newstickerhighlightcolor=$myrow["newstickerhighlightcolor"];
	$newstickerheight=$myrow["newstickerheight"];
	$newstickerwidth=$myrow["newstickerwidth"];
	$newstickerscrollspeed=$myrow["newstickerscrollspeed"];
	$newstickerscrolldelay=$myrow["newstickerscrolldelay"];
	$newstickermaxdays=$myrow["newstickermaxdays"];
	$newstickermaxentries=$myrow["newstickermaxentries"];
	$newsscrollerbgcolor=$myrow["newsscrollerbgcolor"];
	$newsscrollerfontcolor=$myrow["newsscrollerfontcolor"];
	$newsscrollerfont=$myrow["newsscrollerfont"];
	$newsscrollerfontsize=$myrow["newsscrollerfontsize"];
	$newsscrollerheight=$myrow["newsscrollerheight"];
	$newsscrollerwidth=$myrow["newsscrollerwidth"];
	$newsscrollerscrollspeed=$myrow["newsscrollerscrollspeed"];
	$newsscrollerscrolldelay=$myrow["newsscrollerscrolldelay"];
	$newsscrollerscrollpause=$myrow["newsscrollerscrollpause"];
	$newsscrollermaxdays=$myrow["newsscrollermaxdays"];
	$newsscrollermaxentries=$myrow["newsscrollermaxentries"];
	$newsscrollertype=$myrow["newsscrollertype"];
	$newsscrollerbgimage=$myrow["newsscrollerbgimage"];
	$newsscrollerfgimage=$myrow["newsscrollerfgimage"];
	$newsscrollermousestop=$myrow["newsscrollermousestop"];
	$newsscrollermaxchars=$myrow["newsscrollermaxchars"];
	$newstickertarget=$myrow["newstickertarget"];
	$newsscrollertarget=$myrow["newsscrollertarget"];
	$newsscrollerxoffset=$myrow["newsscrollerxoffset"];
	$newsscrolleryoffset=$myrow["newsscrolleryoffset"];
	$newsscrollerdisplaydate=$myrow["newsscrollerdisplaydate"];
	$newsscrollerwordwrap=$myrow["newsscrollerwordwrap"];
	$newsscrollerdateformat=$myrow["newsscrollerdateformat"];
	$newentrypic=$myrow["newentrypic"];
	$newstyperbgcolor=$myrow["newstyperbgcolor"];
	$newstyperfontcolor=$myrow["newstyperfontcolor"];
	$newstyperfont=$myrow["newstyperfont"];
	$newstyperfontsize=$myrow["newstyperfontsize"];
	$newstyperheight=$myrow["newstyperheight"];
	$newstyperwidth=$myrow["newstyperwidth"];
	$newstypermaxdays=$myrow["newstypermaxdays"];
	$newstypermaxentries=$myrow["newstypermaxentries"];
	$newstyperbgimage=$myrow["newstyperbgimage"];
	$newstyperxoffset=$myrow["newstyperxoffset"];
	$newstyperyoffset=$myrow["newstyperyoffset"];
	$newstyperdisplaydate=$myrow["newstyperdisplaydate"];
	$newstyperdateformat=$myrow["newstyperdateformat"];
	$newstyperfontstyle=$myrow["newstyperfontstyle"];
	$newstyperscroll=$myrow["newstyperscroll"];
	$newstypermaxchars=$myrow["newstypermaxchars"];
	$newstyper2maxchars=$myrow["newstyper2maxchars"];
	$newsscrollernolinking=$myrow["newsscrollernolinking"];
	$newstyper2maxentries=$myrow["newstyper2maxentries"];
	$newstyper2bgcolor=$myrow["newstyper2bgcolor"];
	$newstyper2fontcolor=$myrow["newstyper2fontcolor"];
	$newstyper2fontsize=$myrow["newstyper2fontsize"];
	$newstyper2displaydate=$myrow["newstyper2displaydate"];
	$newstyper2newscreen=$myrow["newstyper2newscreen"];
	$newstyper2waitentry=$myrow["newstyper2waitentry"];
	$newstyper2dateformat=$myrow["newstyper2dateformat"];
	$newstyper2indent=$myrow["newstyper2indent"];
	$newstyper2linespace=$myrow["newstyper2linespace"];
	$newstyper2maxdays=$myrow["newstyper2maxdays"];
	$newstyper2width=$myrow["newstyper2width"];
	$newstyper2height=$myrow["newstyper2height"];
	$newstyper2bgimage=$myrow["newstyper2bgimage"];
	$newstyper2sound=$myrow["newstyper2sound"];
	$newstyper2charpause=$myrow["newstyper2charpause"];
	$newstyper2linepause=$myrow["newstyper2linepause"];
	$newstyper2screenpause=$myrow["newstyper2screenpause"];
	$eventscrolleractdate=$myrow["eventscrolleractdate"];
	$separatebylang=$myrow["separatebylang"];
	$headerfile=$myrow["headerfile"];
	$footerfile=$myrow["footerfile"];
	$headerfilepos=$myrow["headerfilepos"];
	$footerfilepos=$myrow["footerfilepos"];
	$usecustomheader=$myrow["usecustomheader"];
	$usecustomfooter=$myrow["usecustomfooter"];
	$copyrightpos=$myrow["copyrightpos"];
	$categorybgcolor=$myrow["categorybgcolor"];
	$categoryfont=$myrow["categoryfont"];
	$categoryfontcolor=$myrow["categoryfontcolor"];
	$categoryfontsize=$myrow["categoryfontsize"];
	$categorystyle=$myrow["categorystyle"];
	$hotnews2target=$myrow["hotnews2target"];
	$news2target=$myrow["news2target"];
	$newsscrollermaxlines=$myrow["newsscrollermaxlines"];
	$linkcolor=$myrow["linkcolor"];
	$vlinkcolor=$myrow["vlinkcolor"];
	$alinkcolor=$myrow["alinkcolor"];
	$morelinkcolor=$myrow["morelinkcolor"];
	$morevlinkcolor=$myrow["morevlinkcolor"];
	$morealinkcolor=$myrow["morealinkcolor"];
	$catlinkcolor=$myrow["catlinkcolor"];
	$catvlinkcolor=$myrow["catvlinkcolor"];
	$catalinkcolor=$myrow["catalinkcolor"];
	$commentlinkcolor=$myrow["commentlinkcolor"];
	$commentvlinkcolor=$myrow["commentvlinkcolor"];
	$commentalinkcolor=$myrow["commentalinkcolor"];
	$attachlinkcolor=$myrow["attachlinkcolor"];
	$attachvlinkcolor=$myrow["attachvlinkcolor"];
	$attachalinkcolor=$myrow["attachalinkcolor"];
	$pagenavlinkcolor=$myrow["pagenavlinkcolor"];
	$pagenavvlinkcolor=$myrow["pagenavvlinkcolor"];
	$pagenavalinkcolor=$myrow["pagenavalinkcolor"];
	$colorscrollbars=$myrow["colorscrollbars"];
	$sbfacecolor=$myrow["sbfacecolor"];
	$sbhighlightcolor=$myrow["sbhighlightcolor"];
	$sbshadowcolor=$myrow["sbshadowcolor"];
	$sb3dlightcolor=$myrow["sb3dlightcolor"];
	$sbarrowcolor=$myrow["sbarrowcolor"];
	$sbtrackcolor=$myrow["sbtrackcolor"];
	$sbdarkshadowcolor=$myrow["sbdarkshadowcolor"];
	$snsel_bgcolor=$myrow["snsel_bgcolor"];
	$snsel_fontcolor=$myrow["snsel_fontcolor"];
	$snsel_font=$myrow["snsel_font"];
	$snsel_fontsize=$myrow["snsel_fontsize"];
	$snsel_fontstyle=$myrow["snsel_fontstyle"];
	$snsel_fontweight=$myrow["snsel_fontweight"];
	$snsel_borderstyle=$myrow["snsel_borderstyle"];
	$snsel_borderwidth=$myrow["snsel_borderwidth"];
	$snsel_bordercolor=$myrow["snsel_bordercolor"];
	$morelinkfontsize=$myrow["morelinkfontsize"];
	$sninput_bgcolor=$myrow["sninput_bgcolor"];
	$sninput_fontcolor=$myrow["sninput_fontcolor"];
	$sninput_font=$myrow["sninput_font"];
	$sninput_fontsize=$myrow["sninput_fontsize"];
	$sninput_fontstyle=$myrow["sninput_fontstyle"];
	$sninput_fontweight=$myrow["sninput_fontweight"];
	$sninput_borderstyle=$myrow["sninput_borderstyle"];
	$sninput_borderwidth=$myrow["sninput_borderwidth"];
	$sninput_bordercolor=$myrow["sninput_bordercolor"];
	$snisb_facecolor=$myrow["snisb_facecolor"];
	$snisb_highlightcolor=$myrow["snisb_highlightcolor"];
	$snisb_shadowcolor=$myrow["snisb_shadowcolor"];
	$snisb_3dlightcolor=$myrow["snisb_3dlightcolor"];
	$snisb_arrowcolor=$myrow["snisb_arrowcolor"];
	$snisb_trackcolor=$myrow["snisb_trackcolor"];
	$snisb_darkshadowcolor=$myrow["snisb_darkshadowcolor"];
	$snbutton_bgcolor=$myrow["snbutton_bgcolor"];
	$snbutton_fontcolor=$myrow["snbutton_fontcolor"];
	$snbutton_font=$myrow["snbutton_font"];
	$snbutton_fontsize=$myrow["snbutton_fontsize"];
	$snbutton_fontstyle=$myrow["snbutton_fontstyle"];
	$snbutton_fontweight=$myrow["snbutton_fontweight"];
	$snbutton_borderstyle=$myrow["snbutton_borderstyle"];
	$snbutton_borderwidth=$myrow["snbutton_borderwidth"];
	$snbutton_bordercolor=$myrow["snbutton_bordercolor"];
	$eventlinkcolor=$myrow["eventlinkcolor"];
	$eventvlinkcolor=$myrow["eventvlinkcolor"];
	$eventalinkcolor=$myrow["eventalinkcolor"];
	$eventlinkfontsize=$myrow["eventlinkfontsize"];
	$actionlinkcolor=$myrow["actionlinkcolor"];
	$actionvlinkcolor=$myrow["actionvlinkcolor"];
	$actionalinkcolor=$myrow["actionalinkcolor"];
	$pagebgpic=$myrow["pagebgpic"];
	$eventcalshortnews=$myrow["eventcalshortnews"];
	$eventcalshortlength=$myrow["eventcalshortlength"];
	$eventcalshortnum=$myrow["eventcalshortnum"];
	$eventcalshortonlyheadings=$myrow["eventcalshortonlyheadings"];
	$hotnewstarget=$myrow["hotnewstarget"];
	$hotnewsdisplayposter=$myrow["hotnewsdisplayposter"];
	$hotnewsnohtmlformatting=$myrow["hotnewsnohtmlformatting"];
	$hotnewsicons=$myrow["hotnewsicons"];
	$ns4style=$myrow["ns4style"];
	$ns6style=$myrow["ns6style"];
	$operastyle=$myrow["operastyle"];
	$geckostyle=$myrow["geckostyle"];
	$konquerorstyle=$myrow["konquerorstyle"];
}
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<form method="post" action="<?php echo $act_script_url?>"><input type="hidden" name="lang" value="<?php echo $lang?>">
<?php
	if(is_konqueror())
		echo "<tr><td></td></tr>";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<tr class="inputrow"><td align="center" colspan="2"><?php echo $l_layoutlang?>: <?php echo language_select($layoutlang,"layoutlang")?>
<input class="snbutton" type="submit" value="<?php echo $l_change?>">
<input type="hidden" name="layoutid" value="<?php echo $layoutid?>">
</td></tr></form>
<tr class="actionrow"><td align="center" colspan="2"><a href="<?php echo do_url_session("$act_script_url?lang=$lang")?>"><?php echo $l_changelayout?></a>
<?php
if((strlen($layoutid)>0) && ($deflayout==0))
	echo "&nbsp;&nbsp;<a href=\"".do_url_session("$act_script_url?dellayout=1&layoutid=$layoutid&lang=$lang")."\">$l_deletelayout</a>";
?>
</td></tr>
<tr class="inforow"><td align="center" colspan="2"><b><?php echo "$l_actuallyselected: $layoutid, $layoutlang"?></b></td></tr>
<form name="layoutform" <?php if($upload_avail) echo "ENCTYPE=\"multipart/form-data\""?> method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="colorfield" value="">
<?php
	if(is_konqueror())
		echo "<tr><td></td></tr>";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="lang" value="<?php echo $lang?>">
<input type="hidden" name="mode" value="submit">
<input type="hidden" name="layoutlang" value="<?php echo $layoutlang?>">
<tr class="displayrow"><td align="right" width="30%"><?php echo $l_id?>:</td>
<?php
if(isset($layoutnr))
	echo "<input type=\"hidden\" name=\"layoutnr\" value=\"$layoutnr\">";
if(strlen($layoutid)<1)
{
	echo "<td class=\"inputrow\"><input class=\"sninput\" type=\"text\" name=\"layoutid\" size=\"10\" maxlength=\"10\">";
}
else
{
	echo "<td>".$layoutid;
	echo "<input type=\"hidden\" name=\"layoutid\" value=\"$layoutid\">";
	echo "</td></tr>";
	if($deflayout==1)
	{
		echo "<tr class=\"displayrow\"><td>&nbsp;</td><td>";
		echo $l_default;
	}
	else
	{
		echo "<tr class=\"actionrow\"><td>&nbsp;</td><td>";
		echo "<a href=\"".do_url_session("$act_script_url?lang=$lang&layoutlang=$layoutlang&layoutid=$layoutid&setdefault=1")."\">$l_setdefault</a>";
	}
}
?>
</td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_heading?></b></td>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_text?>:</td>
<td align="left"><input class="sninput" type="text" name="heading" value="<?php echo $heading?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("headingbgcolor",$headingbgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("headingfontcolor",$headingfontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sninput" type="text" name="headingfont" value="<?php echo $headingfont?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sninput" type="text" name="headingfontsize" value="<?php echo $headingfontsize?>" size="4" maxlength="4"></td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_news?></b></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_heading?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("newsheadingbgcolor",$newsheadingbgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("newsheadingfontcolor",$newsheadingfontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sninput" type="text" name="newsheadingfont" value="<?php echo $newsheadingfont?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sninput" type="text" name="newsheadingfontsize" value="<?php echo $newsheadingfontsize?>" size="4" maxlength="4"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_style?>:</td>
<td align="left"><select name="newsheadingstyle">
<?php
for($i=0;$i<count($l_styles);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$newsheadingstyle)
		echo " selected";
	echo ">".$l_styles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_poster?></b></td></tr>
<tr class="inputrow"><td>&nbsp;</td><td><input type="checkbox" name="showposter" value="1" <?php if($displayposter==1) echo "checked"?>>
<?php echo $l_displayposter?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("posterbgcolor",$posterbgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("posterfontcolor",$posterfontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sninput" type="text" name="posterfont" value="<?php echo $posterfont?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sninput" type="text" name="posterfontsize" value="<?php echo $posterfontsize?>" size="4" maxlength="4"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_style?>:</td>
<td align="left"><select name="posterstyle">
<?php
for($i=0;$i<count($l_styles);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$posterstyle)
		echo " selected";
	echo ">".$l_styles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_text?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("contentbgcolor",$contentbgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("contentfontcolor",$contentfontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sninput" type="text" name="contentfont" value="<?php echo $contentfont?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sninput" type="text" name="contentfontsize" value="<?php echo $contentfontsize?>" size="4" maxlength="4"></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_timestamp?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("timestampbgcolor",$timestampbgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("timestampfontcolor",$timestampfontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sninput" type="text" name="timestampfont" value="<?php echo $timestampfont?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sninput" type="text" name="timestampfontsize" value="<?php echo $timestampfontsize?>" size="4" maxlength="4"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_style?>:</td>
<td align="left"><select name="timestampstyle">
<?php
for($i=0;$i<count($l_styles);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$timestampstyle)
		echo " selected";
	echo ">".$l_styles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_dateformat?>:</td>
<td align="left"><input class="sninput" type="text" name="dateformat" value="<?php echo $dateformat?>" size="20" maxlength="20"></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_categorylayout?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("categorybgcolor",$categorybgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("categoryfontcolor",$categoryfontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td><input class="sninput" type="text" size="40" maxlength="240" name="categoryfont" value="<?php echo $categoryfont?>"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td><input class="sninput" type="text" size="4" maxlength="4" name="categoryfontsize" value="<?php echo $categoryfontsize?>"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_style?>:</td>
<td align="left"><select name="categorystyle">
<?php
for($i=0;$i<count($l_styles);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$categorystyle)
		echo " selected";
	echo ">".$l_styles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_copyrightnotice?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("copyrightbgcolor",$copyrightbgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("copyrightfontcolor",$copyrightfontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sninput" type="text" name="copyrightfont" value="<?php echo $copyrightfont?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sninput" type="text" name="copyrightfontsize" value="<?php echo $copyrightfontsize?>" size="4" maxlength="4"></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_position?>:</td><td align="left">
<input type="radio" name="copyrightpos" value="0" <?php if($copyrightpos==0) echo "checked"?>><?php echo $l_beforefooter?><br>
<input type="radio" name="copyrightpos" value="1" <?php if($copyrightpos==1) echo "checked"?>><?php echo $l_afterfooter?></td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_linkcolors?></b></td>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_general?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_normal?>:</td>
<?php echo color_chooser("linkcolor",$linkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_visited?>:</td>
<?php echo color_chooser("vlinkcolor",$vlinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_activ?>:</td>
<?php echo color_chooser("alinkcolor",$alinkcolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_morelink?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_normal?>:</td>
<?php echo color_chooser("morelinkcolor",$morelinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_visited?>:</td>
<?php echo color_chooser("morevlinkcolor",$morevlinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_activ?>:</td>
<?php echo color_chooser("morealinkcolor",$morealinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sninput" type="text" name="morelinkfontsize" value="<?php echo $morelinkfontsize?>" size="10" maxlength="20"></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_catlink?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_normal?>:</td>
<?php echo color_chooser("catlinkcolor",$catlinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_visited?>:</td>
<?php echo color_chooser("catvlinkcolor",$catvlinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_activ?>:</td>
<?php echo color_chooser("catalinkcolor",$catalinkcolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_comment?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_normal?>:</td>
<?php echo color_chooser("commentlinkcolor",$commentlinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_visited?>:</td>
<?php echo color_chooser("commentvlinkcolor",$commentvlinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_activ?>:</td>
<?php echo color_chooser("commentalinkcolor",$commentalinkcolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_attachement?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_normal?>:</td>
<?php echo color_chooser("attachlinkcolor",$attachlinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_visited?>:</td>
<?php echo color_chooser("attachvlinkcolor",$attachvlinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_activ?>:</td>
<?php echo color_chooser("attachalinkcolor",$attachalinkcolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_pagenav?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_normal?>:</td>
<?php echo color_chooser("pagenavlinkcolor",$pagenavlinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_visited?>:</td>
<?php echo color_chooser("pagenavvlinkcolor",$pagenavvlinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_activ?>:</td>
<?php echo color_chooser("pagenavalinkcolor",$pagenavalinkcolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_eventlink?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_normal?>:</td>
<?php echo color_chooser("eventlinkcolor",$eventlinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_visited?>:</td>
<?php echo color_chooser("eventvlinkcolor",$eventvlinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_activ?>:</td>
<?php echo color_chooser("eventalinkcolor",$eventalinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sninput" type="text" name="eventlinkfontsize" value="<?php echo $eventlinkfontsize?>" size="10" maxlength="20"></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_actionlink?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_normal?>:</td>
<?php echo color_chooser("actionlinkcolor",$actionlinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_visited?>:</td>
<?php echo color_chooser("actionvlinkcolor",$actionvlinkcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_activ?>:</td>
<?php echo color_chooser("actionalinkcolor",$actionalinkcolor)?>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_grafiks?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_searchpic?>:</td>
<?php echo gfx_selector("searchpic",$searchpic)?>
<tr class="inputrow"><td align="right"><?php echo $l_backpic?>:</td>
<?php echo gfx_selector("backpic",$backpic)?>
<tr class="inputrow"><td align="right"><?php echo $l_help?>:</td>
<?php echo gfx_selector("helppic",$helppic)?>
<tr class="inputrow"><td align="right"><?php echo $l_attachement?>:</td>
<?php echo gfx_selector("attachpic",$attachpic)?>
<tr class="inputrow"><td align="right"><?php echo $l_newentry?>:</td>
<?php echo gfx_selector("newentrypic",$newentrypic)?>
<tr class="inputrow"><td align="right"><?php echo $l_pagetoppic?>:</td>
<?php echo gfx_selector("pagetoppic",$pagetoppic)?>
<tr class="inputrow"><td align="right"><?php echo $l_pagepicback?>:</td>
<?php echo gfx_selector("pagepic_back",$pagepic_back)?>
<tr class="inputrow"><td align="right"><?php echo $l_pagepicnext?>:</td>
<?php echo gfx_selector("pagepic_next",$pagepic_next)?>
<tr class="inputrow"><td align="right"><?php echo $l_pagepicfirst?>:</td>
<?php echo gfx_selector("pagepic_first",$pagepic_first)?>
<tr class="inputrow"><td align="right"><?php echo $l_pagepiclast?>:</td>
<?php echo gfx_selector("pagepic_last",$pagepic_last)?>
<tr class="inputrow"><td align="right"><?php echo $l_newssignal_on?>:</td>
<?php echo gfx_selector("newssignal_on",$newssignal_on)?>
<tr class="inputrow"><td align="right"><?php echo $l_newssignal_off?>:</td>
<?php echo gfx_selector("newssignal_off",$newssignal_off)?>
<tr class="inputrow"><td align="right"><?php echo $l_pagebgpic?>:</td>
<?php echo gfx_selector("pagebgpic",$pagebgpic)?>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_eventcal?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_heading?>:</td>
<td align="left"><input class="sninput" type="text" name="eventheading" value="<?php echo $eventheading?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_dateformat?>:</td>
<td align="left"><input class="sninput" type="text" name="event_dateformat" value="<?php echo $event_dateformat?>" size="20" maxlength="20"></td></tr>
<tr class="inputrow"><td>&nbsp;</td><td><input type="checkbox" name="eventcalshorts" value="1" <?php if($eventcalshortnews==1) echo "checked"?>>
<?php echo $l_eventcalshortnews?></td></tr>
<tr class="inputrow"><td>&nbsp;</td><td><input type="checkbox" name="shortheadings" value="1" <?php if($eventcalshortonlyheadings==1) echo "checked"?>>
<?php echo $l_onlyheadings?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_eventcalshortnum?>:</td>
<td><input class="sninput" type="text" name="eventcalshortnum" value="<?php echo $eventcalshortnum?>" size="4" maxlength="10"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_eventcalshortlength?>:</td>
<td><input class="sninput" type="text" name="eventcalshortlength" value="<?php echo $eventcalshortlength?>" size="4" maxlength="10"> <?php echo $l_chars?></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_grafiks?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_monthback?>:</td>
<?php echo gfx_selector("prevpic",$prevpic)?>
<tr class="inputrow"><td align="right"><?php echo $l_monthforward?>:</td>
<?php echo gfx_selector("fwdpic",$fwdpic)?>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_general?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_tablewidth?>:</td>
<td align="left"><input class="sninput" type="text" name="TableWidth" value="<?php echo $TableWidth?>" size="10" maxlength="10"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_tableborder?>:</td>
<?php echo color_chooser("bordercolor",$bordercolor)?>
<tr class="inputrow"><td>&nbsp;</td>
<td><input type="checkbox" name="sepbylang" value="1" <?php if($separatebylang==1) echo "checked"?>>
<?php echo $l_separatebylang?></td></tr>
<tr class="inputrow"><td>&nbsp;</td>
<td><input type="checkbox" name="enablecurrtime" value="1" <?php if($showcurrtime==1) echo "checked"?>>
<?php echo $l_showcurrtime?></td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_pagelayout?></b></td>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_customheader?>:<br>
<input name="enablecustomheader" value="1" type="checkbox"
<?php if($usecustomheader==1) echo " checked"?>> <?php echo $l_enable?></td>
<td align="left"><textarea class="sninput" name="customheader" cols="40" rows="8"><?php echo htmlentities($customheader)?></textarea>
<?php
if($upload_avail)
{
?>
<hr noshade color="#000000" size="1">
<?php echo $l_uploadfromfile?>: <input class="sninput" type="file" name="customheaderfile">
<?php
}
?>
<hr noshade color="#000000" size="1">
<input type="checkbox" value="1" name="clearcustomheader"><?php echo $l_clear?>
<hr noshade color="#000000" size="1">
<?php echo $l_includefile?>: <input class="sninput" type="text" size="30" maxlength="240" name="headerfile" value="<?php echo $headerfile?>"><br>
<input type="radio" name="headerfilepos" value="0" <?php if ($headerfilepos==0) echo "checked"?>> <?php echo $l_beforecustomheader?><br>
<input type="radio" name="headerfilepos" value="1" <?php if ($headerfilepos==1) echo "checked"?>> <?php echo $l_aftercustomheader?></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_customfooter?>:<br>
<input name="enablecustomfooter" value="1" type="checkbox"
<?php if($usecustomfooter==1) echo " checked"?>> <?php echo $l_enable?></td>
<td align="left"><textarea class="sninput" name="customfooter" rows="8" cols="40"><?php echo htmlentities($customfooter)?></textarea>
<?php
if($upload_avail)
{
?>
<hr noshade color="#000000" size="1">
<?php echo $l_uploadfromfile?>: <input class="sninput" type="file" name="customfooterfile">
<?php
}
?>
<hr noshade color="#000000" size="1">
<input type="checkbox" value="1" name="clearcustomfooter"><?php echo $l_clear?>
<hr noshade color="#000000" size="1">
<?php echo $l_includefile?>: <input class="sninput" type="text" size="30" maxlength="240" name="footerfile" value="<?php echo $footerfile?>"><br>
<input type="radio" name="footerfilepos" value="0" <?php if ($footerfilepos==0) echo "checked"?>> <?php echo $l_beforecustomfooter?><br>
<input type="radio" name="footerfilepos" value="1" <?php if ($footerfilepos==1) echo "checked"?>> <?php echo $l_aftercustomfooter?>
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("pagebgcolor",$pagebgcolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_stylesheets?></b></td>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_general?>:</td>
<td><input class="sninput" type="text" name="stylesheet" value="<?php echo $stylesheet?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_ns4?>:</td>
<td><input class="sninput" type="text" name="ns4style" value="<?php echo $ns4style?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_ns6?>:</td>
<td><input class="sninput" type="text" name="ns6style" value="<?php echo $ns6style?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_opera?>:</td>
<td><input class="sninput" type="text" name="operastyle" value="<?php echo $operastyle?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_gecko?>:</td>
<td><input class="sninput" type="text" name="geckostyle" value="<?php echo $geckostyle?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_konqueror?>:</td>
<td><input class="sninput" type="text" name="konquerorstyle" value="<?php echo $konquerorstyle?>" size="40" maxlength="80"></td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_userstyles?></b></td>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_browserscrollbar?></b></td>
<tr class="inputrow"><td>&nbsp;</td><td><input type="checkbox" name="enablesbcolors" value="1" <?php if($colorscrollbars==1) echo "checked"?>> <?php echo $l_enable?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_sbfacecolor?>:</td>
<?php echo color_chooser("sbfacecolor",$sbfacecolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sbhighlightcolor?>:</td>
<?php echo color_chooser("sbhighlightcolor",$sbhighlightcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sbshadowcolor?>:</td>
<?php echo color_chooser("sbshadowcolor",$sbshadowcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sbdarkshadowcolor?>:</td>
<?php echo color_chooser("sbdarkshadowcolor",$sbdarkshadowcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sb3dlightcolor?>:</td>
<?php echo color_chooser("sb3dlightcolor",$sb3dlightcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sbarrowcolor?>:</td>
<?php echo color_chooser("sbarrowcolor",$sbarrowcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sbtrackcolor?>:</td>
<?php echo color_chooser("sbtrackcolor",$sbtrackcolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_selectboxes?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("snsel_bgcolor",$snsel_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("snsel_fontcolor",$snsel_fontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sninput" type="text" name="snsel_font" value="<?php echo htmlentities($snsel_font)?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sninput" type="text" name="snsel_fontsize" value="<?php echo $snsel_fontsize?>" size="10" maxlength="10"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontstyle?>:</td>
<td align="left"><select class="snlayout" name="snsel_fontstyle">
<?php
for($i=0;$i<count($l_fstyles);$i++)
{
	echo "<option value=\"".$l_fontstyles[$i]."\"";
	if($l_fstyles[$i]==$snsel_fontstyle)
		echo " selected";
	echo ">".$l_fstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontweight?>:</td>
<td align="left"><select class="snlayout" name="snsel_fontweight">
<?php
for($i=0;$i<count($l_fontweights);$i++)
{
	echo "<option value=\"".$l_fontweights[$i]."\"";
	if($l_fontweights[$i]==$snsel_fontweight)
		echo " selected";
	echo ">".$l_fontweights[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderstyle?>:</td>
<td align="left"><select class="snlayout" name="snsel_borderstyle">
<?php
for($i=0;$i<count($l_borderstyles);$i++)
{
	echo "<option value=\"".$l_borderstyles[$i]."\"";
	if($l_borderstyles[$i]==$snsel_borderstyle)
		echo " selected";
	echo ">".$l_borderstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderwidth?>:</td>
<td align="left"><input class="sninput" type="text" name="snsel_borderwidth" value="<?php echo $snsel_borderwidth?>" size="10" maxlength="20"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bordercolor?>:</td>
<?php echo color_chooser("snsel_bordercolor",$snsel_bordercolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_inputfields_textareas?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("sninput_bgcolor",$sninput_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("sninput_fontcolor",$sninput_fontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sninput" type="text" name="sninput_font" value="<?php echo htmlentities($sninput_font)?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sninput" type="text" name="sninput_fontsize" value="<?php echo $sninput_fontsize?>" size="10" maxlength="10"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontstyle?>:</td>
<td align="left"><select class="snlayout" name="sninput_fontstyle">
<?php
for($i=0;$i<count($l_fstyles);$i++)
{
	echo "<option value=\"".$l_fstyles[$i]."\"";
	if($l_fstyles[$i]==$sninput_fontstyle)
		echo " selected";
	echo ">".$l_fstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontweight?>:</td>
<td align="left"><select class="snlayout" name="sninput_fontweight">
<?php
for($i=0;$i<count($l_fontweights);$i++)
{
	echo "<option value=\"".$l_fontweights[$i]."\"";
	if($l_fontweights[$i]==$sninput_fontweight)
		echo " selected";
	echo ">".$l_fontweights[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderstyle?>:</td>
<td align="left"><select class="snlayout" name="sninput_borderstyle">
<?php
for($i=0;$i<count($l_borderstyles);$i++)
{
	echo "<option value=\"".$l_borderstyles[$i]."\"";
	if($l_borderstyles[$i]==$sninput_borderstyle)
		echo " selected";
	echo ">".$l_borderstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderwidth?>:</td>
<td align="left"><input class="sninput" type="text" name="sninput_borderwidth" value="<?php echo $sninput_borderwidth?>" size="10" maxlength="20"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bordercolor?>:</td>
<?php echo color_chooser("sninput_bordercolor",$sninput_bordercolor)?>
<tr class="listheading2"><td align="left" colspan="2"><b><?php echo $l_scrollbar?> <span class="remark">(<?php echo $l_textareas?>)</span></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_sbfacecolor?>:</td>
<?php echo color_chooser("snisb_facecolor",$snisb_facecolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sbhighlightcolor?>:</td>
<?php echo color_chooser("snisb_highlightcolor",$snisb_highlightcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sbshadowcolor?>:</td>
<?php echo color_chooser("snisb_shadowcolor",$snisb_shadowcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sbdarkshadowcolor?>:</td>
<?php echo color_chooser("snisb_darkshadowcolor",$snisb_darkshadowcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sb3dlightcolor?>:</td>
<?php echo color_chooser("snisb_3dlightcolor",$snisb_3dlightcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sbarrowcolor?>:</td>
<?php echo color_chooser("snisb_arrowcolor",$snisb_arrowcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_sbtrackcolor?>:</td>
<?php echo color_chooser("snisb_trackcolor",$snisb_trackcolor)?>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_buttons?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("snbutton_bgcolor",$snbutton_bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("snbutton_fontcolor",$snbutton_fontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sninput" type="text" name="snbutton_font" value="<?php echo htmlentities($snbutton_font)?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sninput" type="text" name="snbutton_fontsize" value="<?php echo $snbutton_fontsize?>" size="10" maxlength="10"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontstyle?>:</td>
<td align="left"><select class="snlayout" name="snbutton_fontstyle">
<?php
for($i=0;$i<count($l_fstyles);$i++)
{
	echo "<option value=\"".$l_fstyles[$i]."\"";
	if($l_fstyles[$i]==$snbutton_fontstyle)
		echo " selected";
	echo ">".$l_fstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontweight?>:</td>
<td align="left"><select class="snlayout" name="snbutton_fontweight">
<?php
for($i=0;$i<count($l_fontweights);$i++)
{
	echo "<option value=\"".$l_fontweights[$i]."\"";
	if($l_fontweights[$i]==$snbutton_fontweight)
		echo " selected";
	echo ">".$l_fontweights[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderstyle?>:</td>
<td align="left"><select class="snlayout" name="snbutton_borderstyle">
<?php
for($i=0;$i<count($l_borderstyles);$i++)
{
	echo "<option value=\"".$l_borderstyles[$i]."\"";
	if($l_borderstyles[$i]==$snbutton_borderstyle)
		echo " selected";
	echo ">".$l_borderstyles[$i]."</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_borderwidth?>:</td>
<td align="left"><input class="sninput" type="text" name="snbutton_borderwidth" value="<?php echo $snbutton_borderwidth?>" size="10" maxlength="20"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bordercolor?>:</td>
<?php echo color_chooser("snbutton_bordercolor",$snbutton_bordercolor)?>

<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_emails?></b></td>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_signature?>:</td>
<td><textarea class="sninput" name="defsignature" rows="5" cols="40"><?php echo $defsignature?></textarea></td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_subscriptions?></b></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_emailremark?>:</td>
<td><textarea class="sninput" name="emailremark" rows="5" cols="40"><?php echo htmlentities($emailremark)?></textarea></td></tr>
<tr class="inputrow"><td>&nbsp;</td><td><input type="checkbox" name="enablesubscriptionbox" value="1"
<?php if($displaysubscriptionbox==1) echo "checked"?>> <?php echo $l_displaysubscriptionbox?></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_box?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:</td>
<?php echo color_chooser("subscriptionbgcolor",$subscriptionbgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:</td>
<?php echo color_chooser("subscriptionfontcolor",$subscriptionfontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sninput" type="text" name="subscriptionfont" value="<?php echo $subscriptionfont?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sninput" type="text" name="subscriptionfontsize" value="<?php echo $subscriptionfontsize?>" size="4" maxlength="4"></td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_newsticker?></b></td>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:<br>(<?php echo $l_usehexvalue?>)</td>
<?php echo color_chooser("newstickerbgcolor",$newstickerbgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:<br>(<?php echo $l_usehexvalue?>)</td>
<?php echo color_chooser("newstickerfontcolor",$newstickerfontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_highlightcolor?>:<br>(<?php echo $l_usehexvalue?>)</td>
<?php echo color_chooser("newstickerhighlightcolor",$newstickerhighlightcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sninput" type="text" name="newstickerfont" value="<?php echo $newstickerfont?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sninput" type="text" name="newstickerfontsize" value="<?php echo $newstickerfontsize?>" size="4" maxlength="4"> <?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_width?>:</td>
<td align="left"><input class="sninput" type="text" name="newstickerwidth" value="<?php echo $newstickerwidth?>" size="4" maxlength="10"> <?php echo $l_pixel?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_height?>:</td>
<td align="left"><input class="sninput" type="text" name="newstickerheight" value="<?php echo $newstickerheight?>" size="4" maxlength="10"> <?php echo $l_pixel?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_scrollspeed?>:</td>
<td align="left">
<select name="newstickerscrollspeed">
<?php
for($i=1;$i<11;$i++)
{
	echo "<option value=\"$i\"";
	if($i==$newstickerscrollspeed)
		echo " selected";
	echo ">$i</option>";
}
?>
</select>
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_scrolldelay?>:</td>
<td align="left"><input class="sninput" type="text" name="newstickerscrolldelay" value="<?php echo $newstickerscrolldelay?>" size="4" maxlength="10"> ms
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_linktarget?>:</td>
<td align="left"><input class="sninput" type="text" name="newstickertarget" value="<?php echo $newstickertarget?>" size="40" maxlength="80">
</td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_showednews?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_timeframe?>:</td>
<td align="left"><input class="sninput" type="text" name="newstickermaxdays" value="<?php echo $newstickermaxdays?>" size="4" maxlength="10"> <?php echo $l_days?>
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_maxentries?>:</td>
<td align="left"><input class="sninput" type="text" name="newstickermaxentries" value="<?php echo $newstickermaxentries?>" size="4" maxlength="10">
</td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_newsscroller?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:<br>(<?php echo $l_usehexvalue?>)</td>
<?php echo color_chooser("newsscrollerbgcolor",$newsscrollerbgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:<br>(<?php echo $l_usehexvalue?>)</td>
<?php echo color_chooser("newsscrollerfontcolor",$newsscrollerfontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sninput" type="text" name="newsscrollerfont" value="<?php echo $newsscrollerfont?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sninput" type="text" name="newsscrollerfontsize" value="<?php echo $newsscrollerfontsize?>" size="4" maxlength="4"> <?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_width?>:</td>
<td align="left"><input class="sninput" type="text" name="newsscrollerwidth" value="<?php echo $newsscrollerwidth?>" size="4" maxlength="10"> <?php echo $l_pixel?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_height?>:</td>
<td align="left"><input class="sninput" type="text" name="newsscrollerheight" value="<?php echo $newsscrollerheight?>" size="4" maxlength="10"> <?php echo $l_pixel?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgimage?>:</td>
<?php echo gfx_selector("newsscrollerbgimage",$newsscrollerbgimage,2)?>
<tr class="inputrow"><td align="right"><?php echo $l_fgimage?>:</td>
<?php echo gfx_selector("newsscrollerfgimage",$newsscrollerfgimage,2)?>
<tr class="inputrow"><td align="right"><?php echo $l_scrollspeed?>:</td>
<td align="left">
<select name="newsscrollerscrollspeed">
<?php
for($i=1;$i<11;$i++)
{
	echo "<option value=\"$i\"";
	if($i==$newsscrollerscrollspeed)
		echo " selected";
	echo ">$i</option>";
}
?>
</select>
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_scrolldelay?>:</td>
<td align="left"><input class="sninput" type="text" name="newsscrollerscrolldelay" value="<?php echo $newsscrollerscrolldelay?>" size="4" maxlength="10"> ms
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_scrollpause?>:</td>
<td align="left"><input class="sninput" type="text" name="newsscrollerscrollpause" value="<?php echo $newsscrollerscrollpause?>" size="4" maxlength="10"> ms
</td></tr>
<tr class="inputrow"><td align="right">&nbsp;</td><td>
<input type="checkbox" value="1" name="scrollerstoponmouse" <?php if($newsscrollermousestop==1) echo "checked"?>><?php echo $l_stoponmouseover?></td></tr>
<tr class="inputrow"><td align="right">&nbsp;</td><td>
<input type="checkbox" value="1" name="scrollerdate" <?php if($newsscrollerdisplaydate==1) echo "checked"?>><?php echo $l_displaydate?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_dateformat?>:</td>
<td align="left"><input class="sninput" type="text" name="newsscrollerdateformat" value="<?php echo $newsscrollerdateformat?>" size="20" maxlength="20">
</td></tr>
<tr class="inputrow"><td align="right">&nbsp;</td><td>
<input type="checkbox" value="1" name="scrollerwordwrap" <?php if($newsscrollerwordwrap==1) echo "checked"?>><?php echo $l_wordwrap?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_scrollertype?>:</td>
<td align="left">
<select name="newsscrollertype">
<?php
for($i=0;$i<count($l_scrollertypes);$i++)
{
	echo "<option value=\"".($i+1)."\"";
	if($i+1==$newsscrollertype)
		echo " selected";
	echo ">".$l_scrollertypes[$i]."</option>";
}
?>
</select>
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_linktarget?>:</td>
<td align="left"><input class="sninput" type="text" name="newsscrollertarget" value="<?php echo $newsscrollertarget?>" size="40" maxlength="80">
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_xoffset?>:</td>
<td align="left"><input class="sninput" type="text" name="newsscrollerxoffset" value="<?php echo $newsscrollerxoffset?>" size="4" maxlength="4"> <?php echo $l_pixel?>
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_yoffset?>:</td>
<td align="left"><input class="sninput" type="text" name="newsscrolleryoffset" value="<?php echo $newsscrolleryoffset?>" size="4" maxlength="4"> <?php echo $l_pixel?>
</td></tr>
<tr class="inputrow"><td>&nbsp;</td><td><input type="checkbox" name="disablescrollerlink" value="1" <?php if($newsscrollernolinking==1) echo "checked"?>>
<?php echo $l_newsscrollernolinking?></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_showednews?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_timeframe?>:</td>
<td align="left"><input class="sninput" type="text" name="newsscrollermaxdays" value="<?php echo $newsscrollermaxdays?>" size="4" maxlength="10"> <?php echo $l_days?>
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_maxentries?>:</td>
<td align="left"><input class="sninput" type="text" name="newsscrollermaxentries" value="<?php echo $newsscrollermaxentries?>" size="4" maxlength="10">
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_maxchars?>:</td>
<td align="left"><input class="sninput" type="text" name="newsscrollermaxchars" value="<?php echo $newsscrollermaxchars?>" size="4" maxlength="10">
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_maxlines?>:</td>
<td align="left"><input class="sninput" type="text" name="newsscrollermaxlines" value="<?php echo $newsscrollermaxlines?>" size="4" maxlength="4">
</td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_newstyper?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:<br>(<?php echo $l_usehexvalue?>)</td>
<?php echo color_chooser("newstyperbgcolor",$newstyperbgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:<br>(<?php echo $l_usehexvalue?>)</td>
<?php echo color_chooser("newstyperfontcolor",$newstyperfontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_font?>:</td>
<td align="left"><input class="sninput" type="text" name="newstyperfont" value="<?php echo $newstyperfont?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sninput" type="text" name="newstyperfontsize" value="<?php echo $newstyperfontsize?>" size="4" maxlength="4"> <?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_fontstyle?>:</td>
<td align="left">
<select name="newstyperfontstyle">
<?php
for($i=0;$i<count($l_fontstyles);$i++)
{
	echo "<option value=\"$i\"";
	if($i==$newstyperfontstyle)
		echo " selected";
	echo ">".$l_fontstyles[$i]."</option>";
}
?>
</select>
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_width?>:</td>
<td align="left"><input class="sninput" type="text" name="newstyperwidth" value="<?php echo $newstyperwidth?>" size="4" maxlength="10"> <?php echo $l_pixel?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_height?>:</td>
<td align="left"><input class="sninput" type="text" name="newstyperheight" value="<?php echo $newstyperheight?>" size="4" maxlength="10"> <?php echo $l_pixel?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgimage?>:</td>
<?php echo gfx_selector("newstyperbgimage",$newstyperbgimage,2)?>
<tr class="inputrow"><td align="right">&nbsp;</td><td>
<input type="checkbox" value="1" name="typerscroll" <?php if($newstyperscroll==1) echo "checked"?>><?php echo $l_newstyperscroll?></td></tr>
<tr class="inputrow"><td align="right">&nbsp;</td><td>
<input type="checkbox" value="1" name="typerdate" <?php if($newstyperdisplaydate==1) echo "checked"?>><?php echo $l_displaydate?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_dateformat?>:</td>
<td align="left"><input class="sninput" type="text" name="newstyperdateformat" value="<?php echo $newstyperdateformat?>" size="20" maxlength="20">
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_xoffset?>:</td>
<td align="left"><input class="sninput" type="text" name="newstyperxoffset" value="<?php echo $newstyperxoffset?>" size="4" maxlength="4"> <?php echo $l_pixel?>
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_yoffset?>:</td>
<td align="left"><input class="sninput" type="text" name="newstyperyoffset" value="<?php echo $newstyperyoffset?>" size="4" maxlength="4"> <?php echo $l_pixel?>
</td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_showednews?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_timeframe?>:</td>
<td align="left"><input class="sninput" type="text" name="newstypermaxdays" value="<?php echo $newstypermaxdays?>" size="4" maxlength="10"> <?php echo $l_days?>
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_maxentries?>:</td>
<td align="left"><input class="sninput" type="text" name="newstypermaxentries" value="<?php echo $newstypermaxentries?>" size="4" maxlength="10">
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_maxchars?>:</td>
<td align="left"><input class="sninput" type="text" name="newstypermaxchars" value="<?php echo $newstypermaxchars?>" size="4" maxlength="10">
</td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_newstyper2?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgcolor?>:<br>(<?php echo $l_usehexvalue?>)</td>
<?php echo color_chooser("newstyper2bgcolor",$newstyper2bgcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontcolor?>:<br>(<?php echo $l_usehexvalue?>)</td>
<?php echo color_chooser("newstyper2fontcolor",$newstyper2fontcolor)?>
<tr class="inputrow"><td align="right"><?php echo $l_fontsize?>:</td>
<td align="left"><input class="sninput" type="text" name="newstyper2fontsize" value="<?php echo $newstyper2fontsize?>" size="4" maxlength="4"> <?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_linespace?>:</td>
<td align="left"><input class="sninput" type="text" name="newstyper2linespace" value="<?php echo $newstyper2linespace?>" size="4" maxlength="4"> <?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_indent?>:</td>
<td align="left"><input class="sninput" type="text" name="newstyper2indent" value="<?php echo $newstyper2indent?>" size="4" maxlength="4"> <?php echo $l_points?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_width?>:</td>
<td align="left"><input class="sninput" type="text" name="newstyper2width" value="<?php echo $newstyper2width?>" size="4" maxlength="10"> <?php echo $l_pixel?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_height?>:</td>
<td align="left"><input class="sninput" type="text" name="newstyper2height" value="<?php echo $newstyper2height?>" size="4" maxlength="10"> <?php echo $l_pixel?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_bgimage?>:</td>
<?php echo gfx_selector("newstyper2bgimage",$newstyper2bgimage,2)?>
<tr class="inputrow"><td align="right"><?php echo $l_sound?>:</td>
<td align="left"><input class="sninput" type="text" name="newstyper2sound" value="<?php echo $newstyper2sound?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_charpause?>:</td>
<td align="left"><input class="sninput" type="text" name="newstyper2charpause" value="<?php echo $newstyper2charpause?>" size="10" maxlength="10"> ms</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_linepause?>:</td>
<td align="left"><input class="sninput" type="text" name="newstyper2linepause" value="<?php echo $newstyper2linepause?>" size="10" maxlength="10"> ms</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_screenpause?>:</td>
<td align="left"><input class="sninput" type="text" name="newstyper2screenpause" value="<?php echo $newstyper2screenpause?>" size="10" maxlength="10"> ms</td></tr>
<tr class="inputrow"><td align="right">&nbsp;</td><td>
<input type="checkbox" value="1" name="typer2newscreen" <?php if($newstyper2newscreen==1) echo "checked"?>><?php echo $l_newstyper2newscreen?></td></tr>
<tr class="inputrow"><td align="right">&nbsp;</td><td>
<input type="checkbox" value="1" name="typer2waitentry" <?php if($newstyper2waitentry==1) echo "checked"?>><?php echo $l_newstyper2waitentry?></td></tr>
<tr class="inputrow"><td align="right">&nbsp;</td><td>
<input type="checkbox" value="1" name="typer2date" <?php if($newstyper2displaydate==1) echo "checked"?>><?php echo $l_displaydate?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_dateformat?>:</td>
<td align="left"><input class="sninput" type="text" name="newstyper2dateformat" value="<?php echo $newstyper2dateformat?>" size="20" maxlength="20">
</td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_showednews?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_timeframe?>:</td>
<td align="left"><input class="sninput" type="text" name="newstyper2maxdays" value="<?php echo $newstyper2maxdays?>" size="4" maxlength="10"> <?php echo $l_days?>
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_maxentries?>:</td>
<td align="left"><input class="sninput" type="text" name="newstyper2maxentries" value="<?php echo $newstyper2maxentries?>" size="4" maxlength="10">
</td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_maxchars?>:</td>
<td align="left"><input class="sninput" type="text" name="newstyper2maxchars" value="<?php echo $newstyper2maxchars?>" size="4" maxlength="10">
</td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_eventscroller?></b></td></tr>
<tr class="inputrow"><td>&nbsp;</td><td><input type="checkbox" name="eventscrollerdate" value="1" <?php if($eventscrolleractdate==1) echo "checked"?>>
<?php echo $l_eventscrolleractdate?></td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_hotnews?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_linktarget?>:</td>
<td><input class="sninput" type="text" name="hotnewstarget" value="<?php echo $hotnewstarget?>" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td>&nbsp;</td><td><input type="checkbox" name="hotnewsposter" value="1" <?php if($hotnewsdisplayposter==1) echo "checked"?>>
<?php echo $l_displayposter?></td></tr>
<tr class="inputrow"><td>&nbsp;</td><td><input type="checkbox" name="hotnewsnohtml" value="1" <?php if($hotnewsnohtmlformatting==1) echo "checked"?>>
<?php echo $l_removehtmlformatting?></td></tr>
<tr class="inputrow"><td>&nbsp;</td><td><input type="checkbox" name="hotnewsdisplayicons" value="1" <?php if($hotnewsicons==1) echo "checked"?>>
<?php echo $l_displayicons?></td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_hotnews2?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_targetframe?>:</td>
<td><input class="sninput" type="text" name="hotnews2target" value="<?php echo $hotnews2target?>" size="40" maxlength="240"></td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_news2?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_targetframe?>:</td>
<td><input class="sninput" type="text" name="news2target" value="<?php echo $news2target?>" size="40" maxlength="240"></td></tr>
<tr class="actionrow"><td align="center" colspan="2"><input class="snbutton" type="submit" value="<?php if(strlen($layoutid)>0) echo $l_update; else echo $l_add?>"></td></tr>
</form>
</table></td></tr></table>
<?php
include_once('./trailer.php');
echo "</body></html>";
?>
