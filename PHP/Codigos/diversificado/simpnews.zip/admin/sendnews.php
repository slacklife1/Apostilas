<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
if(!isset($lang) || !$lang)
	$lang=$admin_lang;
include_once('./language/lang_'.$lang.'.php');
if(!isset($newslang))
	$newslang=$lang;
require_once('./auth.php');
$page_title=$l_emailnews;
require_once('./heading.php');
include_once('../includes/class.html.mime.mail.inc');
define('CRLF', "\r\n", TRUE);
if($use_smtpmail)
	include_once('../includes/class.smtp.inc');
$sql = "select * from ".$tableprefix."_settings where (settingnr=1)";
if(!$result = mysql_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = mysql_fetch_array($result))
{
	$subscriptionsendmode=$myrow["subscriptionsendmode"];
	$enablesubscriptions=$myrow["enablesubscriptions"];
	$subject=$myrow["subject"];
	$simpnewsmail=$myrow["simpnewsmail"];
	$simpnewsmailname=$myrow["simpnewsmailname"];
}
else
{
	$subscriptionsendmode=0;
	$enablesubscriptions=0;
	$subject="News";
	$simpnewsmail="simpnews@foo.bar";
	$simpnewsmailname="SimpNews";
}
if(($admin_rights<2) || ($subscriptionsendmode==0))
{
	echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
	die("$l_functionnotallowed");
}
$actdate = date("Y-m-d H:i:s");
$sql="select * from ".$tableprefix."_subscriptions where confirmed=1";
if(!$result = mysql_query($sql, $db))
    die("Unable to connect to database.".mysql_error());
while($myrow=mysql_fetch_array($result))
{
	$layout_sql="select * from ".$tableprefix."_layout where lang='".$myrow["language"]."' and deflayout=1";
	if(!$layout_result = mysql_query($layout_sql, $db))
	    die("Unable to connect to database.".mysql_error());
	if(!$layoutrow=mysql_fetch_array($layout_result))
		die("Layout setup error");
	$dateformat=$layoutrow["dateformat"];
	$timestampfontcolor=$layoutrow["timestampfontcolor"];
	$timestampfontsize=$layoutrow["timestampfontsize"];
	$timestampfont=$layoutrow["timestampfont"];
	$timestampstyle=$layoutrow["timestampstyle"];
	$timestampbgcolor=$layoutrow["timestampbgcolor"];
	$globalheading=$layoutrow["heading"];
	$headingbgcolor=$layoutrow["headingbgcolor"];
	$headingfontcolor=$layoutrow["headingfontcolor"];
	$headingfont=$layoutrow["headingfont"];
	$headingfontsize=$layoutrow["headingfontsize"];
	$bordercolor=$layoutrow["bordercolor"];
	$contentbgcolor=$layoutrow["contentbgcolor"];
	$contentfontcolor=$layoutrow["contentfontcolor"];
	$contentfont=$layoutrow["contentfont"];
	$contentfontsize=$layoutrow["contentfontsize"];
	$TableWidth=$layoutrow["TableWidth"];
	$newsheadingbgcolor=$layoutrow["newsheadingbgcolor"];
	$newsheadingfontcolor=$layoutrow["newsheadingfontcolor"];
	$newsheadingstyle=$layoutrow["newsheadingstyle"];
	$newsheadingfont=$layoutrow["newsheadingfont"];
	$newsheadingfontsize=$layoutrow["newsheadingfontsize"];
	$displayposter=$layoutrow["displayposter"];
	$posterbgcolor=$layoutrow["posterbgcolor"];
	$posterfontcolor=$layoutrow["posterfontcolor"];
	$posterfont=$layoutrow["posterfont"];
	$posterfontsize=$layoutrow["posterfontsize"];
	$posterstyle=$layoutrow["posterstyle"];
	$copyrightbgcolor=$layoutrow["copyrightbgcolor"];
	$copyrightfontcolor=$layoutrow["copyrightfontcolor"];
	$copyrightfont=$layoutrow["copyrightfont"];
	$copyrightfontsize=$layoutrow["copyrightfontsize"];
	$attachpic=$layoutrow["attachpic"];
	$numnews=0;
	$asc_mailmsg="";
	$html_mailmsg="<table width=\"$TableWidth\" border=\"0\" CELLPADDING=\"1\" CELLSPACING=\"0\" ALIGN=\"CENTER\" VALIGN=\"TOP\">";
	$html_mailmsg.="<tr><TD BGCOLOR=\"$bordercolor\">";
	$html_mailmsg.="<TABLE BORDER=\"0\" CELLPADDING=\"1\" CELLSPACING=\"1\" WIDTH=\"100%\">";
	if(strlen($globalheading)>0)
	{
		$html_mailmsg.="<TR BGCOLOR=\"$headingbgcolor\" ALIGN=\"CENTER\">";
		$html_mailmsg.="<TD ALIGN=\"CENTER\" VALIGN=\"MIDDLE\"><font face=\"$headingfont\" size=\"$headingfontsize\" color=\"$headingfontcolor\"><b>$globalheading</b></font></td></tr>";
	}
	$mail = new html_mime_mail(array('X-Mailer: SimpNews v'.$version));
	$sql2="select * from ".$tableprefix."_data where date>'".$myrow["lastsent"]."' and lang='".$myrow["language"]."'";
	if(!$result2 = mysql_query($sql2, $db))
	    die("Unable to connect to database.".mysql_error());
	while($myrow2=mysql_fetch_array($result2))
	{
		$numnews++;
		list($mydate,$mytime)=explode(" ",$myrow2["date"]);
		list($year, $month, $day) = explode("-", $mydate);
		list($hour, $min, $sec) = explode(":",$mytime);
		$temptime=mktime($hour,$min,$sec,$month,$day,$year);
		$temptime=$temptime-($servertimezone*60*60);
		$temptime=$temptime+($displaytimezone*60*60);
		$displaydate=date($dateformat,$temptime);
		$asc_mailmsg.="$displaydate:\r\n";
		$html_mailmsg.="<tr>";
		$html_mailmsg.="<td width=\"2%\" height=\"100%\" align=\"center\" bgcolor=\"$contentbgcolor\">";
		if($myrow2["headingicon"])
		{
			$html_mailmsg.="<img src=\"$url_icons/".$myrow2["headingicon"]."\" border=\"0\" align=\"middle\"> ";
		}
		else
			$html_mailmsg.="&nbsp;";
		$html_mailmsg.="</td>";
		$html_mailmsg.="<td  align=\"center\"><table width=\"100%\" align=\"center\" bgcolor=\"$contentbgcolor\" cellspacing=\"0\" cellpadding=\"0\">";
		$html_mailmsg.="<tr bgcolor=\"$timestampbgcolor\"><td align=\"left\">";
		$html_mailmsg.="<font face=\"$timestampfont\" size=\"$timestampfontsize\" color=\"$timestampfontcolor\">";
		$html_mailmsg.=get_start_tag($timestampstyle);
		$html_mailmsg.=$displaydate;
		$html_mailmsg.=get_end_tag($timestampstyle);
		$html_mailmsg.="</font></td></tr>";
		if(strlen($myrow2["heading"])>0)
		{
			$asc_heading=strip_tags($myrow2["heading"]);
			$asc_mailmsg.=$asc_heading;
			$asc_mailmsg.="\r\n";
			for($i=0;$i<strlen($asc_heading);$i++)
				$asc_mailmsg.="-";
			$asc_mailmsg.="\r\n";
			$html_mailmsg.="<tr bgcolor=\"$newsheadingbgcolor\"><td align=\"left\">";
			$html_mailmsg.="<font face=\"$newsheadingfont\" size=\"$newsheadingfontsize\" color=\"$newsheadingfontcolor\">";
			$html_mailmsg.=get_start_tag($newsheadingstyle);
			$html_mailmsg.=htmlentities(stripslashes($myrow2["heading"]));
			$html_mailmsg.=get_end_tag($newsheadingstyle);
			$html_mailmsg.="</font></td></tr>";
		}
		$html_mailmsg.="<tr bgcolor=\"$contentbgcolor\"><td align=\"left\">";
		$html_mailmsg.="<font face=\"$contentfont\" size=\"$contentfontsize\" color=\"$contentfontcolor\">";
		$html_news=stripslashes($myrow2["text"]);
		$html_news=undo_htmlspecialchars($html_news);
		$html_mailmsg.=$html_news."</font></td></tr>";
		$asc_newstext=str_replace("<BR>","\r\n",$html_news);
		$asc_newstext=undo_htmlentities($asc_newstext);
		$asc_newstext=strip_tags($asc_newstext);
		$asc_mailmsg.=$asc_newstext."\r\n";
		if($displayposter && (strlen($myrow2["poster"])>0))
		{
			$html_mailmsg.="<tr bgcolor=\"$posterbgcolor\"><td align=\"left\">";
			$html_mailmsg.="<font face=\"$posterfont\" size=\"$posterfontsize\" color=\"$posterfontcolor\">";
			$html_mailmsg.=get_start_tag($posterstyle);
			$html_mailmsg.="$l_poster: ".htmlentities($myrow2["poster"]);
			$html_mailmsg.=get_end_tag($posterstyle);
			$html_mailmsg.="</font></td></tr>";
		}
		$tempsql="select * from ".$tableprefix."_bindata where entrynr=".$myrow2["newsnr"];
		if(!$tempresult=mysql_query($tempsql,$db))
		    die("Unable to connect to database.".mysql_error());
		if($temprow=mysql_fetch_array($tempresult))
		{
			$html_mailmsg.="<tr bgcolor=\"$contentbgcolor\">";
			$html_mailmsg.="<td align=\"left\">";
			$html_mailmsg.="<font face=\"$contentfont\" size=\"$contentfontsize\" color=\"$contentfontcolor\">";
			$fileinfo=$temprow["filename"]." (".$temprow["filesize"]."Bytes)";
			$html_mailmsg.="&nbsp;<a href=\"".$simpnews_fullurl."sndownload.php?entrynr=".$myrow2["newsnr"]."\" target=\"_blank\"><img src=\"$attachpic\" border=\"0\" align=\"absmiddle\" title=\"$fileinfo\" alt=\"$fileinfo\"></a>&nbsp; ";
			$html_mailmsg.="<a href=\"".$simpnews_fullurl."sndownload.php?entrynr=".$myrow2["newsnr"]."\" target=\"_blank\">Download</a></font></td></tr>";
			$asc_mailmsg.= "Download attachement: ".$simpnews_fullurl."sndownload.php?entrynr=".$myrow2["newsnr"]."\r\n";
		}
		$asc_mailmsg.="\r\n";
		$html_mailmsg.="</table></td></tr>";
	}
	$html_mailmsg.="<TR BGCOLOR=\"$copyrightbgcolor\" ALIGN=\"CENTER\">";
	$html_mailmsg.="<TD ALIGN=\"CENTER\" VALIGN=\"MIDDLE\" colspan=\"2\"><font face=\"$copyrightfont\" size=\"$copyrightfontsize\" color=\"$copyrightfontcolor\">";
	$html_mailmsg.="Generated by $copyright_url, $copyright_note</td></tr>";
	$html_mailmsg.="</table></td></tr></table>";
	$html_mailmsg = str_replace($url_gfx."/","",$html_mailmsg);
	if($numnews>0)
	{
		$unsubscribeurl=$simpnews_fullurl."subscription.php?lang=".$myrow["language"]."&id=".$myrow["unsubscribeid"]."&mode=remove&email=".$myrow["email"];
		$unsubscribeurl_html="<font face=\"Verdana, Geneva, Arial, Helvetica, sans-serif\" size=\"1\"><a href=\"$unsubscribeurl\">$unsubscribeurl</a></font>";
		if($layoutrow["emailremark"])
			$html_remark=str_replace("{unsubscribeurl}",$unsubscribeurl_html,$layoutrow["emailremark"]);
		else
			$html_remark="unsubscribe: $unsubscribeurl_html";
		$html_remark=str_replace("\n","<br>",$html_remark);
		if($layoutrow["emailremark"])
			$asc_remark=str_replace("{unsubscribeurl}",$unsubscribeurl,strip_tags($layoutrow["emailremark"]));
		else
			$asc_remark="unsubscribe: $unsubscribeurl";
		$asc_remark=str_replace("\n","\r\n",$asc_remark);
		$userhtmlbody=$html_mailmsg;
		if(strlen($html_remark)>0)
			$userhtmlbody.="<hr>$html_remark<br><br>";
		$userhtmlbody.="---<BR>".str_replace("\n","<BR>",$layoutrow["defsignature"]);
		$userascbody=$asc_mailmsg;
		if(strlen($asc_remark)>0)
			$userascbody.="---------------------------\r\n$asc_remark\r\n\r\n";
		$userascbody.="---\r\n".str_replace("\n","\r\n",$layoutrow["defsignature"]);
		if($myrow["emailtype"]==0)
		{
			$mail->build_params['html_charset']=$contentcharset;
			$mail->build_params['text_charset']=$contentcharset;
    	    $mail->add_html($userhtmlbody, $userascbody);
			$mail->find_html_images($path_gfx."/");
    	}
    	else
    	{
			$mail->build_params['text_charset']=$contentcharset;
    		$mail->add_text($userascbody);
    	}
    	$mail->build_message();
		if($use_smtpmail)
		{
			if($simpnewsmailname)
				$smtpfrom="\"$simpnewsmailname\" <$simpnewsmail>";
			else
				$smtpfrom=$simpnewsmail;
			$mailparams = array(
				'host' => $smtpserver,
				'port' => $smtpport,
				'helo' => $smtpsenderdomain,
				'auth' => $smtpauth,
				'user' => $smtpuser,
				'pass' => $smtppasswd);
	        $smtp =& smtp::connect($mailparams);
			$send_params = array(
				'from'			=> $simpnewsmail,
				'recipients'	=> array($myrow["email"]),
				'headers'		=> array(
				'From: '.$smtpfrom,
				'To: '.$myrow["email"],
				'Subject: '.$subject));
	        $mail->smtp_send($smtp, $send_params);
		}
		else
	    	$mail->send("",$myrow["email"],$simpnewsmailname,$simpnewsmail,$subject);
    }
    $sql2="update ".$tableprefix."_subscriptions set lastsent='$actdate' where subscriptionnr=".$myrow["subscriptionnr"];
	if(!$result2 = mysql_query($sql2, $db))
		die("Unable to connect to database.".mysql_error());
}
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="displayrow"><td align="center"><?php echo $l_emailssent?></td></tr>
</table></td></tr></table>
<?php
include('./trailer.php');
?>