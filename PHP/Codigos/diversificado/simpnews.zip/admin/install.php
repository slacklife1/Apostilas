<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require('../config.php');
require('./fill_freemailer.php');
require('./fill_emoticons.php');
require('./fill_icons.php');
?>
<html><body>
<div align="center"><h3>SimpNews V<?php echo $version?> Install</h3></div>
<br>
<?php
if(isset($submit))
{
if(!$admin_pw1 || !$admin_pw2 || !$admin_user)
	die("Needed fields not filled");
if($admin_pw1 != $admin_pw2)
{
	echo "<div align=\"center\">";
	echo "<font color=\"#ff2200\"><b>Error</b>: Passwords don't match</font>";
	echo "</div><br>";
}
else
{
// create table simpnews_events
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_events;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_events");
$sql = "CREATE TABLE ".$tableprefix."_events (";
$sql.= "eventnr int(10) unsigned NOT NULL auto_increment,";
$sql.= "date date NOT NULL DEFAULT '0000-00-00' ,";
$sql.= "lang varchar(4) NOT NULL DEFAULT '' ,";
$sql.= "poster varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "category int(10) NOT NULL DEFAULT '0' ,";
$sql.= "heading varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "headingicon varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "text text NOT NULL DEFAULT '' ,";
$sql.= "added datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql.= "PRIMARY KEY (eventnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_events");
// create table simpnews_bindata
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_bindata;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_bindata");
$sql = "CREATE TABLE ".$tableprefix."_bindata (";
$sql.= "entrynr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "bindata longblob NOT NULL DEFAULT '' ,";
$sql.= "filename varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "mimetype varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "filesize int(10) NOT NULL DEFAULT '0' ,";
$sql.= "UNIQUE entrynr (entrynr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_bindata");
// create table simpnews_search
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_search;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_search");
$sql = "CREATE TABLE ".$tableprefix."_search (";
$sql.= "newsnr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "text text NOT NULL DEFAULT '' );";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_search");
// create table simpnews_comments
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_comments;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_comments");
$sql = "CREATE TABLE ".$tableprefix."_comments (";
$sql.= "commentnr int(10) unsigned NOT NULL auto_increment,";
$sql.= "poster varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "email varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "entryref int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "comment text NOT NULL DEFAULT '' ,";
$sql.= "enterdate datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql.= "PRIMARY KEY (commentnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_comments");
// create table simpnews_categories
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_categories;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_categories");
$sql = "CREATE TABLE ".$tableprefix."_categories (";
$sql.= "catnr int(10) unsigned NOT NULL auto_increment,";
$sql.= "catname varchar(40) NOT NULL DEFAULT '' ,";
$sql.= "PRIMARY KEY (catnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_categories");
// create table simpnews_icons
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_icons;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_icons");
$sql = "CREATE TABLE ".$tableprefix."_icons (";
$sql.= "iconnr int(10) unsigned NOT NULL auto_increment,";
$sql.= "icon_url varchar(100) NOT NULL DEFAULT '' ,";
$sql.= "PRIMARY KEY (iconnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_icons");
// create table simpnews_emoticons
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_emoticons;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_emoticons");
$sql = "CREATE TABLE ".$tableprefix."_emoticons (";
$sql.= "iconnr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "code varchar(20) NOT NULL DEFAULT '' ,";
$sql.= "emoticon_url varchar(100) NOT NULL DEFAULT '' ,";
$sql.= "emotion varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "PRIMARY KEY (iconnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_emoticons");
// create table simpnews_subscriptions
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_subscriptions;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_subscriptions");
$sql = "CREATE TABLE ".$tableprefix."_subscriptions (";
$sql.= "subscriptionnr int(10) unsigned NOT NULL auto_increment,";
$sql.= "email varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "confirmed int(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "language varchar(4) NOT NULL DEFAULT '' ,";
$sql.= "subscribeid int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "unsubscribeid int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "enterdate datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql.= "lastsent datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql.= "emailtype tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "lastmanual datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql.= "PRIMARY KEY (subscriptionnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_subscriptions");
// create table simpnews_users
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_users;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_users");
$sql = "CREATE TABLE ".$tableprefix."_users (";
$sql.= "usernr tinyint(3) unsigned NOT NULL auto_increment,";
$sql.= "username varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "password varchar(40) binary NOT NULL DEFAULT '' ,";
$sql.= "email varchar(80) ,";
$sql.= "rights int(2) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "lastlogin datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql.= "lockpw tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "realname varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "autopin int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "PRIMARY KEY (usernr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_users");
// create table simpnews_settings
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_settings;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_settings");
$sql = "CREATE TABLE ".$tableprefix."_settings (";
$sql.= "settingnr int(10) unsigned NOT NULL auto_increment,";
$sql.= "watchlogins tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "enablefailednotify tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "simpnewsmail varchar(180) NOT NULL DEFAULT '' ,";
$sql.= "loginlimit int(2) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "usemenubar tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "nofreemailer tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "enablehostresolve tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "enablesubscriptions tinyint(1) NOT NULL DEFAULT '0' ,";
$sql.= "maxconfirmtime int(1) unsigned NOT NULL DEFAULT '2' ,";
$sql.= "subject varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "subscriptionsendmode tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "subscriptionfreemailer tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "sitename varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "maxage int(5) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "entriesperpage int(2) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "allowcomments tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "numhotnews tinyint(2) unsigned NOT NULL DEFAULT '5' ,";
$sql.= "enablesearch tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "newsnotifydays tinyint(2) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "redirectdelay tinyint(2) NOT NULL DEFAULT '-1' ,";
$sql.= "newsineventcal tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "lastvisitcookie tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "servertimezone tinyint(3) NOT NULL DEFAULT '0' ,";
$sql.= "displaytimezone tinyint(3) NOT NULL DEFAULT '0' ,";
$sql.= "simpnewsmailname varchar(180) NOT NULL DEFAULT '' ,";
$sql.= "news2entries int(2) unsigned NOT NULL DEFAULT '5' ,";
$sql.= "hotnewsmaxchars int(10) NOT NULL DEFAULT '0' ,";
$sql.= "PRIMARY KEY (settingnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_settings");
// create table simpnews_session
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_session;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_session");
$sql = "CREATE TABLE ".$tableprefix."_session (";
$sql.= "sessid int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "usernr int(10) NOT NULL DEFAULT '0' ,";
$sql.= "starttime int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "remoteip varchar(15) NOT NULL DEFAULT '' ,";
$sql.= "lastlogin datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql.= "PRIMARY KEY (sessid),";
$sql.= "INDEX sess_id (sessid),";
$sql.= "INDEX start_time (starttime),";
$sql.= "INDEX remote_ip (remoteip));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_session");
// create table simpnews_misc
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_misc;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_misc");
$sql = "CREATE TABLE ".$tableprefix."_misc (";
$sql.= "shutdown tinyint(3) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "shutdowntext text);";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_misc");
// create table simpnews_iplog
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_iplog;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_iplog");
$sql = "CREATE TABLE ".$tableprefix."_iplog (";
$sql.= "lognr int(10) unsigned NOT NULL auto_increment,";
$sql.= "usernr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "logtime datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql.= "ipadr varchar(16) NOT NULL DEFAULT '' ,";
$sql.= "used_lang varchar(4) NOT NULL DEFAULT '' ,";
$sql.= "PRIMARY KEY (lognr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_iplog");
// create table simpnews_hostcache
if(!table_exists($hcprefix."_hostcache"))
{
	$sql = "CREATE TABLE /*!32300 IF NOT EXISTS*/ ".$hcprefix."_hostcache (";
	$sql.= "ipadr varchar(16) NOT NULL DEFAULT '0' ,";
	$sql.= "hostname varchar(240) NOT NULL DEFAULT '' ,";
	$sql.= "UNIQUE ipadr (ipadr));";
	if(!$result = mysql_query($sql, $db))
		die("Unable to create table ".$hcprefix."_hostcache");
}
// create table simpnews_freemailer
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_freemailer;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_freemailer");
$sql = "CREATE TABLE ".$tableprefix."_freemailer (";
$sql.= "entrynr int(10) unsigned NOT NULL auto_increment,";
$sql.= "address varchar(100) NOT NULL DEFAULT '' ,";
$sql.= "PRIMARY KEY (entrynr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_freemailer");
// create table simpnews_failed_notify
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_failed_notify;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_failed_notify");
$sql = "CREATE TABLE ".$tableprefix."_failed_notify (";
$sql.= "usernr int(10) unsigned NOT NULL DEFAULT '0');";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_failed_notify");
// create table simpnews_failed_logins
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_failed_logins;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_failed_logins");
$sql = "CREATE TABLE ".$tableprefix."_failed_logins (";
$sql.= "loginnr int(10) unsigned NOT NULL auto_increment,";
$sql.= "username varchar(250) NOT NULL DEFAULT '0' ,";
$sql.= "ipadr varchar(16) NOT NULL DEFAULT '' ,";
$sql.= "logindate datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql.= "usedpw varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "PRIMARY KEY (loginnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_failed_logins");
// create table simpnews_banlist
if(!table_exists($banprefix."_banlist"))
{
	$sql = "CREATE TABLE /*!32300 IF NOT EXISTS*/ ".$banprefix."_banlist (";
	$sql.="bannr int(10) unsigned NOT NULL auto_increment,";
	$sql.="ipadr varchar(16) NOT NULL DEFAULT '0.0.0.0' ,";
	$sql.="subnetmask varchar(16) NOT NULL DEFAULT '0.0.0.0' ,";
	$sql.="reason text ,";
	$sql.="PRIMARY KEY (bannr));";
	if(!$result = mysql_query($sql, $db))
		die("Unable to create table ".$banprefix."_banlist");
}
// create table simpnews_data
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_data;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_data");
$sql = "CREATE TABLE ".$tableprefix."_data (";
$sql .="newsnr int(10) unsigned NOT NULL auto_increment,";
$sql .="lang varchar(4) NOT NULL DEFAULT '' ,";
$sql .="date datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql .="text text NOT NULL DEFAULT '' ,";
$sql .="heading varchar(80) NOT NULL DEFAULT '' ,";
$sql .="poster varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "headingicon varchar(100) NOT NULL DEFAULT '' ,";
$sql.= "category int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "allowcomments tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "tickerurl varchar(240) NOT NULL DEFAULT '' ,";
$sql .="PRIMARY KEY (newsnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_data");
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_layout;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_layout");
$sql = "CREATE TABLE ".$tableprefix."_layout (";
$sql.="lang varchar(4) NOT NULL DEFAULT '0' ,";
$sql.="heading varchar(80) NOT NULL DEFAULT '' ,";
$sql.="headingbgcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.="headingfontcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.="headingfont varchar(240) NOT NULL DEFAULT '' ,";
$sql.="headingfontsize varchar(4) NOT NULL DEFAULT '' ,";
$sql.="bordercolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.="contentbgcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.="contentfontcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.="contentfont varchar(240) NOT NULL DEFAULT '' ,";
$sql.="contentfontsize varchar(4) NOT NULL DEFAULT '' ,";
$sql.="TableWidth varchar(10) NOT NULL DEFAULT '' ,";
$sql.="timestampfontcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.="timestampfontsize varchar(4) NOT NULL DEFAULT '' ,";
$sql.="timestampfont varchar(240) NOT NULL DEFAULT '' ,";
$sql.="dateformat varchar(20) NOT NULL DEFAULT '' ,";
$sql.="showcurrtime tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.="customheader text NOT NULL DEFAULT '' ,";
$sql.="pagebgcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.="stylesheet varchar(80) NOT NULL DEFAULT '' ,";
$sql.="newsheadingbgcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.="newsheadingfontcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.="newsheadingstyle tinyint(1) NOT NULL DEFAULT '0' ,";
$sql.="posterbgcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.="posterfontcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.="posterstyle tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.="displayposter tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.="posterfont varchar(240) NOT NULL DEFAULT '' ,";
$sql.="posterfontsize varchar(4) NOT NULL DEFAULT '' ,";
$sql.="newsheadingfont varchar(240) NOT NULL DEFAULT '' ,";
$sql.="newsheadingfontsize varchar(4) NOT NULL DEFAULT '' ,";
$sql.="timestampbgcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.="timestampstyle tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.="displaysubscriptionbox tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.="defsignature varchar(240) NOT NULL DEFAULT '' ,";
$sql.="subscriptionbgcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.="subscriptionfontcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.="subscriptionfont varchar(240) NOT NULL DEFAULT '' ,";
$sql.="subscriptionfontsize varchar(4) NOT NULL DEFAULT '' ,";
$sql.="copyrightbgcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.="copyrightfontcolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.="copyrightfont varchar(240) NOT NULL DEFAULT '' ,";
$sql.="copyrightfontsize varchar(4) NOT NULL DEFAULT '' ,";
$sql.="emailremark text NOT NULL DEFAULT '' ,";
$sql.="layoutnr int(10) NOT NULL auto_increment,";
$sql.="id varchar(10) NOT NULL DEFAULT '' ,";
$sql.="deflayout tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.="customfooter text NOT NULL DEFAULT '' ,";
$sql.="searchpic varchar(240) NOT NULL DEFAULT 'search.gif' ,";
$sql.="backpic varchar(240) NOT NULL DEFAULT 'back.gif' ,";
$sql.="pagepic_back varchar(240) NOT NULL DEFAULT 'prev.gif' ,";
$sql.="pagepic_first varchar(240) NOT NULL DEFAULT 'first.gif' ,";
$sql.="pagepic_next varchar(240) NOT NULL DEFAULT 'next.gif' ,";
$sql.="pagepic_last varchar(240) NOT NULL DEFAULT 'last.gif' ,";
$sql.="pagetoppic varchar(240) NOT NULL DEFAULT 'pagetop.gif' ,";
$sql.="newssignal_on varchar(240) NOT NULL DEFAULT 'blink.gif' ,";
$sql.="newssignal_off varchar(240) NOT NULL DEFAULT 'off.gif' ,";
$sql.="helppic varchar(240) NOT NULL DEFAULT 'help.gif' ,";
$sql.="attachpic varchar(240) NOT NULL DEFAULT 'attach.gif' ,";
$sql.="prevpic varchar(240) NOT NULL DEFAULT 'prev_big.gif' ,";
$sql.="fwdpic varchar(240) NOT NULL DEFAULT 'next_big.gif' ,";
$sql.="eventheading varchar(80) NOT NULL DEFAULT '' ,";
$sql.="event_dateformat varchar(20) NOT NULL DEFAULT '' ,";
$sql.="newstickerbgcolor varchar(7) NOT NULL DEFAULT '#cccccc' ,";
$sql.="newstickerfontcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.="newstickerfont varchar(240) NOT NULL DEFAULT 'Verdana' ,";
$sql.="newstickerfontsize tinyint(2) unsigned NOT NULL DEFAULT '12' ,";
$sql.="newstickerhighlightcolor varchar(7) NOT NULL DEFAULT '#0000ff' ,";
$sql.="newstickerheight int(10) unsigned NOT NULL DEFAULT '20' ,";
$sql.="newstickerwidth int(10) unsigned NOT NULL DEFAULT '300' ,";
$sql.="newstickerscrollspeed tinyint(2) unsigned NOT NULL DEFAULT '1' ,";
$sql.="newstickerscrolldelay int(10) unsigned NOT NULL DEFAULT '30' ,";
$sql.="newstickermaxdays int(10) NOT NULL DEFAULT '0' ,";
$sql.="newstickermaxentries int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.="newsscrollerbgcolor varchar(7) NOT NULL DEFAULT '#cccccc' ,";
$sql.="newsscrollerfontcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.="newsscrollerfont varchar(240) NOT NULL DEFAULT 'Verdana' ,";
$sql.="newsscrollerfontsize tinyint(2) unsigned NOT NULL DEFAULT '12' ,";
$sql.="newsscrollerheight int(10) unsigned NOT NULL DEFAULT '300' ,";
$sql.="newsscrollerwidth int(10) unsigned NOT NULL DEFAULT '200' ,";
$sql.="newsscrollerscrollspeed tinyint(2) unsigned NOT NULL DEFAULT '1' ,";
$sql.="newsscrollerscrolldelay int(10) unsigned NOT NULL DEFAULT '100' ,";
$sql.="newsscrollerscrollpause int(10) unsigned NOT NULL DEFAULT '2000' ,";
$sql.="newsscrollermaxdays int(10) NOT NULL DEFAULT '0' ,";
$sql.="newsscrollermaxentries int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.="newsscrollertype tinyint(4) unsigned NOT NULL DEFAULT '4' ,";
$sql.="newsscrollerbgimage varchar(240) NOT NULL DEFAULT '' ,";
$sql.="newsscrollerfgimage varchar(240) NOT NULL DEFAULT '' ,";
$sql.="newsscrollermousestop tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.="newsscrollermaxchars int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.="newstickertarget varchar(80) NOT NULL DEFAULT '_self' ,";
$sql.="newsscrollertarget varchar(80) NOT NULL DEFAULT '_self' ,";
$sql.="newsscrollerxoffset tinyint(4) unsigned NOT NULL DEFAULT '0' ,";
$sql.="newsscrolleryoffset tinyint(4) unsigned NOT NULL DEFAULT '0' ,";
$sql.="newsscrollerwordwrap tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.="newsscrollerdisplaydate tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.="newsscrollerdateformat varchar(20) NOT NULL DEFAULT 'Y-m-d' ,";
$sql.="newentrypic varchar(240) NOT NULL DEFAULT 'new.gif' ,";
$sql.="newstypermaxentries int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.="newstyperbgcolor varchar(7) NOT NULL DEFAULT '#cccccc' ,";
$sql.="newstyperfontcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.="newstyperfont varchar(240) NOT NULL DEFAULT 'Verdana' ,";
$sql.="newstyperfontsize tinyint(2) unsigned NOT NULL DEFAULT '12' ,";
$sql.="newstyperfontstyle tinyint(2) unsigned NOT NULL DEFAULT '0' ,";
$sql.="newstyperdisplaydate tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.="newstyperdateformat varchar(20) NOT NULL DEFAULT 'Y-m-d' ,";
$sql.="newstyperxoffset tinyint(4) unsigned NOT NULL DEFAULT '8' ,";
$sql.="newstyperyoffset tinyint(4) unsigned NOT NULL DEFAULT '8' ,";
$sql.="newstypermaxdays int(10) NOT NULL DEFAULT '0' ,";
$sql.="newstypermaxchars int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.="newstyperwidth int(10) unsigned NOT NULL DEFAULT '200' ,";
$sql.="newstyperheight int(10) unsigned NOT NULL DEFAULT '300' ,";
$sql.="newstyperbgimage varchar(240) NOT NULL DEFAULT '' ,";
$sql.="newstyperscroll tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.="newsscrollernolinking tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.="newstyper2maxentries int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.="newstyper2bgcolor varchar(7) NOT NULL DEFAULT '#cccccc' ,";
$sql.="newstyper2fontcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.="newstyper2fontsize tinyint(2) unsigned NOT NULL DEFAULT '12' ,";
$sql.="newstyper2displaydate tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.="newstyper2newscreen tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.="newstyper2waitentry tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.="newstyper2dateformat varchar(20) NOT NULL DEFAULT 'Y-m-d' ,";
$sql.="newstyper2indent tinyint(4) unsigned NOT NULL DEFAULT '8' ,";
$sql.="newstyper2linespace tinyint(4) unsigned NOT NULL DEFAULT '15' ,";
$sql.="newstyper2maxdays int(10) NOT NULL DEFAULT '-1' ,";
$sql.="newstyper2maxchars int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.="newstyper2width int(10) unsigned NOT NULL DEFAULT '300' ,";
$sql.="newstyper2height int(10) unsigned NOT NULL DEFAULT '200' ,";
$sql.="newstyper2bgimage varchar(240) NOT NULL DEFAULT '' ,";
$sql.="newstyper2sound varchar(240) NOT NULL DEFAULT 'sfx/tick.au' ,";
$sql.="newstyper2charpause int(10) unsigned NOT NULL DEFAULT '50' ,";
$sql.="newstyper2linepause int(10) unsigned NOT NULL DEFAULT '500' ,";
$sql.="newstyper2screenpause int(10) unsigned NOT NULL DEFAULT '5000' ,";
$sql.="eventscrolleractdate tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.="separatebylang tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.="headerfile varchar(250) NOT NULL DEFAULT '' ,";
$sql.="footerfile varchar(250) NOT NULL DEFAULT '' ,";
$sql.="headerfilepos tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.="footerfilepos tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.="usecustomheader tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.="usecustomfooter tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.="copyrightpos tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.="categorybgcolor varchar(7) NOT NULL DEFAULT '#999999' ,";
$sql.="categoryfont varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.="categoryfontsize varchar(4) NOT NULL DEFAULT '3' ,";
$sql.="categoryfontcolor varchar(7) NOT NULL DEFAULT '#EEEEEE' ,";
$sql.="categorystyle int(2) unsigned NOT NULL DEFAULT '0' ,";
$sql.="hotnews2target varchar(240) NOT NULL DEFAULT '_self' ,";
$sql.="news2target varchar(240) NOT NULL DEFAULT '_self' ,";
$sql.="newsscrollermaxlines int(2) unsigned NOT NULL DEFAULT '20' ,";
$sql.="linkcolor varchar(7) NOT NULL DEFAULT '#696969' ,";
$sql.="vlinkcolor varchar(7) NOT NULL DEFAULT '#696969' ,";
$sql.="alinkcolor varchar(7) NOT NULL DEFAULT '#696969' ,";
$sql.="morelinkcolor varchar(7) NOT NULL DEFAULT '#191970' ,";
$sql.="morevlinkcolor varchar(7) NOT NULL DEFAULT '#191970' ,";
$sql.="morealinkcolor varchar(7) NOT NULL DEFAULT '#191970' ,";
$sql.="catlinkcolor varchar(7) NOT NULL DEFAULT '#F0FFFF' ,";
$sql.="catvlinkcolor varchar(7) NOT NULL DEFAULT '#F0FFFF' ,";
$sql.="catalinkcolor varchar(7) NOT NULL DEFAULT '#F0FFFF' ,";
$sql.="commentlinkcolor varchar(7) NOT NULL DEFAULT '#191970' ,";
$sql.="commentvlinkcolor varchar(7) NOT NULL DEFAULT '#191970' ,";
$sql.="commentalinkcolor varchar(7) NOT NULL DEFAULT '#191970' ,";
$sql.="attachlinkcolor varchar(7) NOT NULL DEFAULT '#CD5C5C' ,";
$sql.="attachvlinkcolor varchar(7) NOT NULL DEFAULT '#CD5C5C' ,";
$sql.="attachalinkcolor varchar(7) NOT NULL DEFAULT '#CD5C5C' ,";
$sql.="pagenavlinkcolor varchar(7) NOT NULL DEFAULT '#FFF0C0' ,";
$sql.="pagenavvlinkcolor varchar(7) NOT NULL DEFAULT '#FFF0C0' ,";
$sql.="pagenavalinkcolor varchar(7) NOT NULL DEFAULT '#FFF0C0' ,";
$sql.="colorscrollbars tinyint(1) NOT NULL DEFAULT '1' ,";
$sql.="sbfacecolor varchar(7) NOT NULL DEFAULT '#94AAD6' ,";
$sql.="sbhighlightcolor varchar(7) NOT NULL DEFAULT '#AFEEEE' ,";
$sql.="sbshadowcolor varchar(7) NOT NULL DEFAULT '#ADD8E6' ,";
$sql.="sbdarkshadowcolor varchar(7) NOT NULL DEFAULT '#4682B4' ,";
$sql.="sb3dlightcolor varchar(7) NOT NULL DEFAULT '#1E90FF' ,";
$sql.="sbarrowcolor varchar(7) NOT NULL DEFAULT '#0000ff' ,";
$sql.="sbtrackcolor varchar(7) NOT NULL DEFAULT '#E0FFFF' ,";
$sql.="snsel_bgcolor varchar(7) NOT NULL DEFAULT '#DCDCDC' ,";
$sql.="snsel_fontcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.="snsel_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.="snsel_fontsize varchar(10) NOT NULL DEFAULT '10pt' ,";
$sql.="snsel_fontstyle varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.="snsel_fontweight varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.="snsel_borderstyle varchar(20) NOT NULL DEFAULT 'none' ,";
$sql.="snsel_bordercolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.="snsel_borderwidth varchar(20) NOT NULL DEFAULT '' ,";
$sql.="morelinkfontsize varchar(20) NOT NULL DEFAULT '8pt' ,";
$sql.="sninput_bgcolor varchar(7) NOT NULL DEFAULT '#DCDCDC' ,";
$sql.="sninput_fontcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.="sninput_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.="sninput_fontsize varchar(20) NOT NULL DEFAULT '10pt' ,";
$sql.="sninput_fontstyle varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.="sninput_fontweight varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.="sninput_borderstyle varchar(20) NOT NULL DEFAULT 'solid' ,";
$sql.="sninput_borderwidth varchar(20) NOT NULL DEFAULT 'thin' ,";
$sql.="sninput_bordercolor varchar(7) NOT NULL DEFAULT '#696969' ,";
$sql.="snisb_facecolor varchar(7) NOT NULL DEFAULT '#708090' ,";
$sql.="snisb_highlightcolor varchar(7) NOT NULL DEFAULT '#A9A9A9' ,";
$sql.="snisb_shadowcolor varchar(7) NOT NULL DEFAULT '#191970' ,";
$sql.="snisb_darkshadowcolor varchar(7) NOT NULL DEFAULT '#000080' ,";
$sql.="snisb_3dlightcolor varchar(7) NOT NULL DEFAULT '#F5FFFA' ,";
$sql.="snisb_arrowcolor varchar(7) NOT NULL DEFAULT '#c0c0c0' ,";
$sql.="snisb_trackcolor varchar(7) NOT NULL DEFAULT '#b0b0b0' ,";
$sql.="snbutton_bgcolor varchar(7) NOT NULL DEFAULT '#94AAD6' ,";
$sql.="snbutton_fontcolor varchar(7) NOT NULL DEFAULT '#FFFAF0' ,";
$sql.="snbutton_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.="snbutton_fontsize varchar(20) NOT NULL DEFAULT '7pt' ,";
$sql.="snbutton_fontstyle varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.="snbutton_fontweight varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.="snbutton_borderstyle varchar(20) NOT NULL DEFAULT 'ridge' ,";
$sql.="snbutton_borderwidth varchar(20) NOT NULL DEFAULT 'thin' ,";
$sql.="snbutton_bordercolor varchar(7) NOT NULL DEFAULT '#483D8B' ,";
$sql.="eventlinkcolor varchar(7) NOT NULL DEFAULT '#696969' ,";
$sql.="eventalinkcolor varchar(7) NOT NULL DEFAULT '#696969' ,";
$sql.="eventvlinkcolor varchar(7) NOT NULL DEFAULT '#696969' ,";
$sql.="eventlinkfontsize varchar(20) NOT NULL DEFAULT '9pt' ,";
$sql.="actionlinkcolor varchar(7) NOT NULL DEFAULT '#F0FFFF' ,";
$sql.="actionvlinkcolor varchar(7) NOT NULL DEFAULT '#F0FFFF' ,";
$sql.="actionalinkcolor varchar(7) NOT NULL DEFAULT '#F0FFFF' ,";
$sql.="pagebgpic varchar(240) NOT NULL DEFAULT 'pagebg.gif' ,";
$sql.="eventcalshortnews tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.="eventcalshortlength int(10) unsigned NOT NULL DEFAULT '20' ,";
$sql.="eventcalshortnum int(10) unsigned NOT NULL DEFAULT '3' ,";
$sql.="eventcalshortonlyheadings tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.="hotnewstarget varchar(80) NOT NULL DEFAULT '' ,";
$sql.="hotnewsdisplayposter tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.="hotnewsnohtmlformatting tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.="hotnewsicons tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.="ns4style varchar(80) NOT NULL DEFAULT 'simpnews_ns4.css' ,";
$sql.="ns6style varchar(80) NOT NULL DEFAULT 'simpnews_ns6.css' ,";
$sql.="operastyle varchar(80) NOT NULL DEFAULT 'simpnews_opera.css' ,";
$sql.="geckostyle varchar(80) NOT NULL DEFAULT 'simpnews_gecko.css' ,";
$sql.="konquerorstyle varchar(80) NOT NULL DEFAULT 'simpnews_konqueror.css' ,";
$sql.="PRIMARY KEY (layoutnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_layout");
// insert adminuser
$admin_pw=md5($admin_pw1);
$admin_user=addslashes(strtolower($admin_user));
$sql = "INSERT INTO ".$tableprefix."_users (";
$sql .="username, password, rights, realname";
if(isset($admin_email))
	$sql .=", email";
$sql .=")";
$sql .="VALUES ('$admin_user', '$admin_pw', 3, '$realname'";
if(isset($admin_email))
	$sql .=", '$admin_email'";
$sql .=");";
if(!$result = mysql_query($sql, $db))
	die("Unable to create adminuser");
echo "Adding default layout...<br>";
$sql ="INSERT INTO ".$tableprefix."_layout VALUES ('en', 'News', '#94AAD6', '#FFF0C0', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '+2', '#000000', '#c0c0c0', '#000000', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '2', '98%', '#000000', '1', 'Verdana, Geneva, Arial, Helvetica, sans-serif', 'm/d/Y H:i:s', 1, '', '#c0c0c0', 'simpnews.css', '#c0c0c0', '#222222', 0, '#c0c0c0', '#000000', 0, 1, 'Verdana, Geneva, Arial, Helvetica, sans-serif', '1', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '3', '#c0c0c0', 0, 1, '', '#94AAD6', '#FFF0C0', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '2', '#c0c0c0', '#000000', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '1', '{unsubscribeurl}', 11, 'orig', 1, '', 'search.gif', 'back.gif', 'prev.gif', 'first.gif', 'next.gif', 'last.gif', 'pagetop.gif', 'blink.gif', 'off.gif', 'help.gif', 'attach.gif', 'prev_big.gif', 'next_big.gif', 'Events', 'm-d-Y', '#cccccc', '#000000', 'Verdana', 12, '#9933ff', 20, 300, 1, 30, -1, 0, '#cccccc', '#000000', 'Verdana', 12, 300, 200, 1, 30, 2000, -1, 0, 4, '', '', 1, 0, '_self', '_self', 0, 0, 1, 1, 'm/d/Y', 'new.gif', 0, '#cccccc', '#000000', 'Verdana', 12, 0, 1, 'Y-m-d', 8, 8, -1, 0, 200, 300, '', 1, 0, 0, '#cccccc', '#000000', 12, 1, 1, 0, 'Y-m-d', 8, 15, 0, 0, 300, 200, '', 'sfx/tick.au', 50, 500, 5000, 0, 1, '', '', 0, 0, 0, 0, 0, '#999999', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '3', '#EEEEEE', 0, '_self', '_self', 20, '#696969', '#696969', '#696969', '#191970', '#191970', '#191970', '#F0FFFF', '#F0FFFF', '#F0FFFF', '#191970', '#191970', '#191970', '#CD5C5C', '#CD5C5C', '#CD5C5C', '#FFF0C0', '#FFF0C0', '#FFF0C0', 1, '#94AAD6', '#AFEEEE', '#ADD8E6', '#4682B4', '#1E90FF', '#0000ff', '#E0FFFF', '#DCDCDC', '#000000', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '10pt', 'normal', 'normal', 'none', '', '', '8pt', '#DCDCDC', '#000000', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '10pt', 'normal', 'normal', 'solid', 'thin', '#696969', '#708090', '#A9A9A9', '#191970', '#000080', '#F5FFFA', '#c0c0c0', '#b0b0b0', '#94AAD6', '#FFFAF0', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '9pt', 'normal', 'normal', 'ridge', 'thin', '#483D8B', '#696969', '#696969', '#696969', '9pt', '#F0FFFF', '#F0FFFF', '#F0FFFF', 'pagebg.gif', 0, 20, 3, 1, '', 1, 0, 1, 'simpnews_ns4.css', 'simpnews_ns6.css', 'simpnews_opera.css', 'simpnews_gecko.css', 'simpnews_konqueror.css');";
if(!$result = mysql_query($sql, $db))
	die("Unable to add layout (en) ".mysql_error());
$sql ="INSERT INTO ".$tableprefix."_layout VALUES ('de', 'Aktuelles', '#94AAD6', '#FFF0C0', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '+2', '#000000', '#c0c0c0', '#000000', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '2', '98%', '#000000', '1', 'Verdana, Geneva, Arial, Helvetica, sans-serif', 'd.m.Y H:i:s', 1, '', '#c0c0c0', 'simpnews.css', '#c0c0c0', '#222222', 0, '#c0c0c0', '#000000', 0, 1, 'Verdana, Geneva, Arial, Helvetica, sans-serif', '1', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '3', '#c0c0c0', 0, 1, '', '#94AAD6', '#FFF0C0', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '2', '#c0c0c0', '#000000', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '1', '{unsubscribeurl}', 10, 'orig', 1, '', 'search.gif', 'back.gif', 'prev.gif', 'first.gif', 'next.gif', 'last.gif', 'pagetop.gif', 'blink.gif', 'off.gif', 'help.gif', 'attach.gif', 'prev_big.gif', 'next_big.gif', 'Events', 'd.m.Y', '#cccccc', '#000000', 'Verdana', 12, '#9933ff', 20, 300, 1, 30, -1, 0, '#cccccc', '#000000', 'Verdana', 12, 300, 200, 1, 30, 2000, -1, 0, 4, '', '', 1, 0, '_self', '_self', 0, 0, 1, 1, 'd.m.Y', 'new.gif', 0, '#cccccc', '#000000', 'Verdana', 12, 0, 1, 'Y-m-d', 8, 8, -1, 0, 200, 300, '', 1, 0, 0, '#cccccc', '#000000', 12, 1, 1, 0, 'Y-m-d', 8, 15, 0, 0, 300, 200, '', 'sfx/tick.au', 50, 500, 5000, 0, 1, '', '', 0, 0, 0, 0, 0, '#999999', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '3', '#EEEEEE', 0, '_self', '_self', 20, '#696969', '#696969', '#696969', '#191970', '#191970', '#191970', '#F0FFFF', '#F0FFFF', '#F0FFFF', '#191970', '#191970', '#191970', '#CD5C5C', '#CD5C5C', '#CD5C5C', '#FFF0C0', '#FFF0C0', '#FFF0C0', 1, '#94AAD6', '#AFEEEE', '#ADD8E6', '#4682B4', '#1E90FF', '#0000ff', '#E0FFFF', '#DCDCDC', '#000000', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '10pt', 'normal', 'normal', 'none', '', '', '8pt', '#DCDCDC', '#000000', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '10pt', 'normal', 'normal', 'solid', 'thin', '#696969', '#708090', '#A9A9A9', '#191970', '#000080', '#F5FFFA', '#c0c0c0', '#b0b0b0', '#94AAD6', '#FFFAF0', 'Verdana, Geneva, Arial, Helvetica, sans-serif', '9pt', 'normal', 'normal', 'ridge', 'thin', '#483D8B', '#696969', '#696969', '#696969', '9pt', '#F0FFFF', '#F0FFFF', '#F0FFFF', 'pagebg.gif', 0, 20, 3, 1, '', 1, 0, 1, 'simpnews_ns4.css', 'simpnews_ns6.css', 'simpnews_opera.css', 'simpnews_gecko.css', 'simpnews_konqueror.css');";
if(!$result = mysql_query($sql, $db))
	die("Unable to add layout (de) ".mysql_error());
echo "Adding default settings...<br>";
$sql = "INSERT INTO ".$tableprefix."_settings VALUES (1, 0, 0, 'simpnews@localhost', 0, 0, 0, 0, 0, 2, '', 1, 1, 'Sitename', 0, 20, 0, 5, 0, 1, -1, 0, 1, 0, 0, 'SimpNews', 5, 0);";
if(!$result = mysql_query($sql, $db))
	die("Unable to add settings ".mysql_error());
if(isset($importfreemailer))
{
	echo "Adding default freemailer...<br>";
	fill_freemailer($tableprefix,$db);
}
if(isset($importemoticons))
{
	echo "Adding default smilies...<br>";
	fill_emoticons($tableprefix,$db);
}
if(isset($importicons))
{
	echo "Adding default icons...<br>";
	fill_icons($tableprefix,$db);
}
?>
<br><div align="center">Installation done.<br>Please remove install.php, upgrade*.php and fill_*.php from server</div>
<div align="center">Now you can login to the <a href="index.php">admininterface</a></div>
</body></html>
<?php
exit;
}
}
if(!isset($admin_user))
	$admin_user="";
if(!isset($admin_email))
	$admin_email="";
if(!isset($realname))
	$realname="";
?>
<table align="center" width="80%">
<tr><td align="center" colspan="3"><b>Adminuser</b></td></tr>
<form action="<?php echo $act_script_url?>" method="post">
<tr><td align="right">Username:</td><td align="center" width="1%">*</td>
<td><input type="text" name="admin_user" size="40" maxlength="80" value="<?php echo $admin_user?>"></td></tr>
<tr><td align="right">real name:</td><td align="center" width="1%">&nbsp;</td>
<td><input type="text" name="realname" size="40" maxlength="240" value="<?php echo $realname?>"></td></tr>
<tr><td align="right">E-Mail:</td><td align="center" width="1%">&nbsp;</td>
<td><input type="text" name="admin_email" size="40" maxlength="80" value="<?php echo $admin_email?>"></td></tr>
<tr><td align="right">Password:</td><td align="center" width="1%">*</td>
<td><input type="password" name="admin_pw1" size="40" maxlength="40"></td></tr>
<tr><td align="right">retype password:</td><td align="center" width="1%">*</td>
<td><input type="password" name="admin_pw2" size="40" maxlength="40"></td></tr>
<tr><td colspan="2">&nbsp;</td><td align="left"><input type="checkbox" name="importfreemailer" value="1"> import predefined freemailer</td></TR>
<tr><td colspan="2">&nbsp;</td><td align="left"><input type="checkbox" name="importemoticons" value="1"> import predefined smilies</td></TR>
<tr><td colspan="2">&nbsp;</td><td align="left"><input type="checkbox" name="importicons" value="1"> import predefined icons</td></TR>
<tr><td align="center" colspan="3"><input type="submit" name="submit" value="submit"></td></tr>
</form>
</table>
</body></html>
<?php
function table_exists($searchedtable)
{
	global $dbname;

	$tables = mysql_list_tables($dbname);
	$numtables = @mysql_numrows($tables);
	for($i=0;$i<$numtables;$i++)
	{
		$tablename = mysql_tablename($tables,$i);
		if($tablename==$searchedtable)
			return true;
	}
	return false;
}
?>
