<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
if(!isset($lang) || !$lang)
	$lang=$admin_lang;
include_once('./language/lang_'.$lang.'.php');
if(!isset($eventlang))
	$eventlang=$lang;
require_once('./auth.php');
$page_title=$l_events;
$bbcbuttons=true;
require_once('./heading.php');
include_once("./includes/bbcode_buttons.inc");
$headingtext="";
if(!isset($catnr))
	$catnr=0;
if(!isset($eventlang))
	$eventlang=$lang;
$allowcomments=1;
$hasattach=0;
if(!isset($sel_year))
	list($sel_year, $sel_month, $sel_day) = explode("-", date("Y-m-d"));
if(isset($mode) && ($admin_rights>1))
{
	if($mode=="add")
	{
		if(!isset($headingicon))
			$headingicon="";
		if(isset($eventtext) && $eventtext)
		{
			if(isset($preview))
			{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<form method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="lang" value="<?php echo $lang?>">
<?php
	if(is_konqueror())
		echo "<tr><td></td></tr>";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
	if(isset($urlautoencode))
		echo "<input type=\"hidden\" name=\"urlautoencode\" value=\"1\">";
	if(isset($enablespcode))
		echo "<input type=\"hidden\" name=\"enablespcode\" value=\"1\">";
?>
<input type="hidden" name="eventlang" value="<?php echo $eventlang?>">
<input type="hidden" name="sel_day" value="<?php echo $sel_day?>">
<input type="hidden" name="sel_month" value="<?php echo $sel_month?>">
<input type="hidden" name="sel_year" value="<?php echo $sel_year?>">
<input type="hidden" name="catnr" value="<?php echo $catnr?>">
<input type="hidden" name="eventtext" value="<?php echo htmlentities($eventtext)?>">
<input type="hidden" name="heading" value="<?php echo htmlentities($heading)?>">
<input type="hidden" name="headingicon" value="<?php echo $headingicon?>">
<input type="hidden" name="mode" value="add">
<tr class="inforow"><td align="center" colspan="2"><?php echo $l_previewprelude?></td></tr>
<?php
				$displaydate=date($l_datefrmt,mktime(0,0,0,$sel_month,$sel_day,$sel_year));
				if(isset($urlautoencode))
					$eventtext = make_clickable($eventtext);
				if(isset($enablespcode))
					$eventtext = bbencode($eventtext);
				if(!isset($disableemoticons))
					$eventtext = encode_emoticons($eventtext, $url_emoticons, $db);
				$eventtext = htmlentities($eventtext);
				$eventtext = str_replace("\n", "<BR>", $eventtext);
				$eventtext = undo_htmlspecialchars($eventtext);
				echo "<tr><td width=\"2%\" height=\"100%\" align=\"center\" class=\"eventicon\">";
				if($headingicon)
					echo "<img src=\"$url_icons/".$headingicon."\" border=\"0\" align=\"middle\"> ";
				else
					echo "&nbsp;";
				echo "</td>";
				echo "<td align=\"center\"><table width=\"100%\" align=\"center\" cellspacing=\"0\" cellpadding=\"0\">";
				echo "<tr><td align=\"left\" class=\"eventdate\">";
				echo $displaydate."</td></tr>";
				if(strlen($heading)>0)
				{
					echo "<tr class=\"eventheading\"><td align=\"left\">";
					echo htmlentities($heading);
					echo "</td></tr>";
				}
				echo "<tr class=\"evententry\"><td align=\"left\">";
				echo $eventtext;
				echo "</td></tr>";
				echo "</table></td></tr>";
				echo "<tr class=\"actionrow\"><td align=\"center\" colspan=\"2\"><input class=\"snbutton\" type=\"submit\" value=\"$l_add\">&nbsp;&nbsp;<input class=\"snbutton\" type=\"button\" value=\"$l_back\" onclick=\"self.history.back();\"></td></tr>";
				echo "</table></td></tr></table>";
			}
			else
			{
				$adddate = date("Y-m-d H:i:00");
				$entrydate=date("Y-m-d",mktime(0,0,0,$sel_month,$sel_day,$sel_year));
				if(isset($enablecomments))
					$allowcomments=1;
				else
					$allowcomments=0;
				if(strlen($userdata["realname"]>0))
					$poster=$userdata["realname"];
				else
					$poster=$userdata["username"];
				if(isset($urlautoencode))
					$eventtext = make_clickable($eventtext);
				if(isset($enablespcode))
					$eventtext = bbencode($eventtext);
				if(!isset($disableemoticons))
					$eventtext = encode_emoticons($eventtext, $url_emoticons, $db);
				$eventtext = htmlentities($eventtext);
				$eventtext = str_replace("\n", "<BR>", $eventtext);
				$eventtext=addslashes($eventtext);
				$sql = "insert into ".$tableprefix."_events (lang, date, text, heading, poster, headingicon, category, added) values ('$eventlang', '$entrydate', '$eventtext', '$heading', '$poster', '$headingicon', $catnr, '$adddate')";
				if(!$result = mysql_query($sql, $db))
				    die("Unable to connect to database.".mysql_error());
				list($sel_year, $sel_month, $sel_day) = explode("-", date("Y-m-d"));
			}
		}
		else
			unset($preview);
	}
	if($mode=="massdel")
	{
		if(isset($eventnr))
		{
    		while(list($null, $input_eventnr) = each($HTTP_POST_VARS["eventnr"]))
    		{
				$sql = "delete from ".$tableprefix."_events where eventnr=$input_eventnr";
				if(!$result = mysql_query($sql, $db))
				    die("Unable to connect to database.".mysql_error());
			}
		}
	}
	if($mode=="del")
	{
		$sql = "delete from ".$tableprefix."_events where eventnr=$input_eventnr";
		if(!$result = mysql_query($sql, $db))
		    die("Unable to connect to database.".mysql_error());
	}
	if($mode=="edit")
	{
		$sql = "select * from ".$tableprefix."_events where eventnr=$input_eventnr";
		if(!$result = mysql_query($sql, $db))
		    die("Unable to connect to database.".mysql_error());
		if ($myrow = mysql_fetch_array($result))
		{
			$doedit=1;
			list($sel_year, $sel_month, $sel_day) = explode("-", $myrow["date"]);
			$headingtext=$myrow["heading"];
			$eventtext = stripslashes($myrow["text"]);
			$eventtext = str_replace("<BR>", "\n", $eventtext);
			$eventtext = undo_htmlspecialchars($eventtext);
			$eventtext = decode_emoticons($eventtext, $url_emoticons, $db);
			$eventtext = bbdecode($eventtext);
			$eventtext = undo_make_clickable($eventtext);
			$actheadingicon=$myrow["headingicon"];
		}
	}
	if($mode=="update")
	{
		if(!isset($headingicon))
			$headingicon="";
		if(isset($eventtext) && $eventtext)
		{
			if(isset($preview))
			{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<form method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="lang" value="<?php echo $lang?>">
<?php
	if(is_konqueror())
		echo "<tr><td></td></tr>";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
	if(isset($urlautoencode))
		echo "<input type=\"hidden\" name=\"urlautoencode\" value=\"1\">";
	if(isset($enablespcode))
		echo "<input type=\"hidden\" name=\"enablespcode\" value=\"1\">";
?>
<input type="hidden" name="eventlang" value="<?php echo $eventlang?>">
<input type="hidden" name="sel_day" value="<?php echo $sel_day?>">
<input type="hidden" name="sel_month" value="<?php echo $sel_month?>">
<input type="hidden" name="sel_year" value="<?php echo $sel_year?>">
<input type="hidden" name="catnr" value="<?php echo $catnr?>">
<input type="hidden" name="eventtext" value="<?php echo htmlentities($eventtext)?>">
<input type="hidden" name="heading" value="<?php echo htmlentities($heading)?>">
<input type="hidden" name="headingicon" value="<?php echo $headingicon?>">
<input type="hidden" name="mode" value="update">
<input type="hidden" name="input_eventnr" value="<?php echo $input_eventnr?>">
<tr class="inforow"><td align="center" colspan="2"><?php echo $l_previewprelude?></td></tr>
<?php
				$entrydate=date("Y-m-d",mktime(0,0,0,$sel_month,$sel_day,$sel_year));
				if(isset($urlautoencode))
					$eventtext = make_clickable($eventtext);
				if(isset($enablespcode))
					$eventtext = bbencode($eventtext);
				if(!isset($disableemoticons))
					$eventtext = encode_emoticons($eventtext, $url_emoticons, $db);
				$eventtext = htmlentities($eventtext);
				$eventtext = str_replace("\n", "<BR>", $eventtext);
				$eventtext = undo_htmlspecialchars($eventtext);
				echo "<tr><td width=\"2%\" height=\"100%\" align=\"center\" class=\"eventicon\">";
				if($headingicon)
					echo "<img src=\"$url_icons/".$headingicon."\" border=\"0\" align=\"middle\"> ";
				else
					echo "&nbsp;";
				echo "</td>";
				echo "<td align=\"center\"><table width=\"100%\" align=\"center\" cellspacing=\"0\" cellpadding=\"0\">";
				echo "<tr><td align=\"left\" class=\"eventdate\">";
				echo $entrydate."</td></tr>";
				if(strlen($heading)>0)
				{
					echo "<tr class=\"eventheading\"><td align=\"left\">";
					echo htmlentities($heading);
					echo "</td></tr>";
				}
				echo "<tr class=\"evententry\"><td align=\"left\">";
				echo $eventtext;
				echo "</td></tr>";
				echo "</table></td></tr>";
				echo "<tr class=\"actionrow\"><td align=\"center\" colspan=\"2\"><input class=\"snbutton\" type=\"submit\" value=\"$l_update\">&nbsp;&nbsp;<input class=\"snbutton\" type=\"button\" value=\"$l_back\" onclick=\"self.history.back();\"></td></tr>";
				echo "</table></td></tr></table>";
			}
			else
			{
				$adddate = date("Y-m-d H:i:00");
				$entrydate=date("Y-m-d",mktime(0,0,0,$sel_month,$sel_day,$sel_year));
				if(isset($urlautoencode))
					$eventtext = make_clickable($eventtext);
				if(isset($enablespcode))
					$eventtext = bbencode($eventtext);
				if(!isset($disableemoticons))
					$eventtext = encode_emoticons($eventtext, $url_emoticons, $db);
				$eventtext = htmlentities($eventtext);
				$eventtext = str_replace("\n", "<BR>", $eventtext);
				$eventtext=addslashes($eventtext);
				$sql = "update ".$tableprefix."_events set headingicon='$headingicon', text='$eventtext', heading='$heading', date='$entrydate', added='$adddate' where eventnr=$input_eventnr";
				if(!$result = mysql_query($sql, $db))
				    die("Unable to connect to database.".mysql_error());
				list($sel_year, $sel_month, $sel_day) = explode("-", date("Y-m-d"));
			}
		}
	}
}
if(!isset($preview))
{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
if($admin_rights > 1)
{
?>
<form method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="lang" value="<?php echo $lang?>">
<?php
	if(is_konqueror())
		echo "<tr><td></td></tr>";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="eventlang" value="<?php echo $eventlang?>">
<tr class="inputrow"><td align="center" colspan="2"><?php echo $l_category?>:
<select class="snselect" name="catnr"><option value="0" <?php if($catnr==0) echo "selected"?>><?php echo $l_without?></option>
<?php
$catsql="select * from ".$tableprefix."_categories";
if(!$result = mysql_query($catsql, $db))
    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database.".mysql_error());
if($myrow=mysql_fetch_array($result))
{
	do{
		echo "<option value=\"".$myrow["catnr"]."\"";
		if($myrow["catnr"]==$catnr)
			echo " selected";
		echo ">".htmlentities($myrow["catname"])."</option>";
	}while($myrow=mysql_fetch_array($result));
}
?>
</select>
<input class="snbutton" type="submit" value="<?php echo $l_change?>"></td></tr></form>
<form method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="lang" value="<?php echo $lang?>">
<input type="hidden" name="catnr" value="<?php echo $catnr?>">
<?php
	if(is_konqueror())
		echo "<tr><td></td></tr>";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<tr class="inputrow"><td align="center" colspan="2"><?php echo $l_edlang2?>: <?php echo language_select($eventlang,"eventlang")?>
<input class="snbutton" type="submit" value="<?php echo $l_change?>"></td></tr></form>
<?php
if($catnr==0)
	$catname=$l_without." ".$l_category;
else
{
	$tempsql="select * from ".$tableprefix."_categories where catnr=$catnr";
	if(!$tempresult = mysql_query($tempsql, $db))
	    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database.".mysql_error());
	if($temprow=mysql_fetch_array($tempresult))
		$catname=$temprow["catname"];
	else
		$catname=$l_without." ".$l_category;
}
?>
<tr class="inforow"><td align="center" valign="top" colspan="2"><b><?php echo "$l_actuallyselected: $catname, $eventlang"?></b></td></tr>
<form name="inputform" method="post" action="<?php echo $act_script_url?>">
<?php
	if(is_konqueror())
		echo "<tr><td></td></tr>";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="lang" value="<?php echo $lang?>">
<input type="hidden" name="eventlang" value="<?php echo $eventlang?>">
<tr class="inputrow"><td align="right" width="20%"><?php echo $l_date?>:</td>
<td>
<table width="50%" cellpadding="0" cellspacing="0" border="0" align="left">
<tr>
<td align="center" width="20%"><?php echo $l_day?></td>
<td align="center" width="20%"><?php echo $l_month?></td>
<td align="center" width="20%"><?php echo $l_year?></td>
</tr>
<tr>
<td align="center"><select name="sel_day">
<?php
for($i=1;$i<32;$i++)
{
	echo "<option value=\"$i\"";
	if($i==$sel_day)
		echo " selected";
	echo ">$i</option>";
}
?>
</select></td>
<td align="center"><select name="sel_month">
<?php
for($i=1;$i<13;$i++)
{
	echo "<option value=\"$i\"";
	if($i==$sel_month)
		echo " selected";
	echo ">".$l_monthname[$i-1]."</option>";
}
?>
</select></td>
<td align="center"><select name="sel_year">
<?php
for($i=$sel_year-5;$i<$sel_year+6;$i++)
{
	echo "<option value=\"$i\"";
	if($i==$sel_year)
		echo " selected";
	echo ">$i</option>";
}
?>
</select></td>
</tr>
</table></td></tr>
<tr class="inputrow"><td align="right" valign="top" width="20%"><?php echo $l_heading?>:</td>
<td><input class="sninput" type="text" name="heading" value="<?php echo $headingtext?>" size="40" maxlength="80"></td></tr>
<?php
$sql = "select * from ".$tableprefix."_icons order by icon_url asc";
if(!$result = mysql_query($sql, $db))
    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database.".mysql_error());
if($myrow=mysql_fetch_array($result))
{
?>
<tr class="inputrow"><td align="right" valign="top" width="20%"><?php echo $l_headingicon?>:</td>
<td valign="middle" nowrap>
<table width="100%" cellspacing="1" cellpadding="1" align="center" class="iconselector">
<tr>
<?php
	$iconcount=0;
	do{
		$iconcount++;
		echo "<td class=\"iconselector\" align=\"center\"><input type=\"radio\" name=\"headingicon\" value=\"",$myrow["icon_url"]."\"";
		if(isset($actheadingicon) && ($actheadingicon==$myrow["icon_url"]))
			echo " checked";
		echo "> <img src=\"$url_icons/".$myrow["icon_url"]."\" border=\"0\" align=\"top\"></td>";
		if($iconcount>4)
		{
			$iconcount=0;
			echo "</tr><tr>";
		}
	}while($myrow=mysql_fetch_array($result));
	echo "</tr>";
?>
</table>
</td></tr>
<?php
}
?>
<tr class="inputrow"><td align="right" valign="top" width="20%"><?php echo $l_text?>:</td>
<td align="left"><textarea class="sninput" name="eventtext" rows="10" cols="50">
<?php
if(isset($doedit))
	echo $eventtext;
?>
</textarea><br>
<?php
	display_smiliebox("eventtext");
	display_bbcode_buttons($l_bbbuttons,"eventtext")
?>
</td></tr>
<?php
if(isset($doedit))
{
	echo "<input type=\"hidden\" name=\"mode\" value=\"update\">";
	echo "<input type=\"hidden\" name=\"input_eventnr\" value=\"$input_eventnr\">";
}
else
	echo "<input type=\"hidden\" name=\"mode\" value=\"add\">";
?>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_options?>:</td><td align="left">
<input type="checkbox" name="urlautoencode" value="1" checked> <?php echo $l_urlautoencode?><br>
<input type="checkbox" name="enablespcode" value="1" checked> <?php echo $l_enablespcode?><br>
<input type="checkbox" name="disableemoticons" value="1"> <?php echo $l_disableemoticons?>
<input type="hidden" name="catnr" value="<?php echo $catnr?>">
</td></tr>
<tr class="actionrow"><td align="center" colspan="2"><input class="snbutton" type="submit" value="<?php if(isset($doedit)) echo $l_update; else echo $l_add?>">&nbsp;&nbsp;<input class="snbutton" type="submit" name="preview" value="<?php echo $l_preview?>"></td></tr>
</form>
<?php
}
?>
</table></td></tr></table>
<p></p>
<?php
$sql = "select * from ".$tableprefix."_events where lang='$eventlang' and category=$catnr order by date desc";
if(!$result = mysql_query($sql, $db))
    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database.".mysql_error());
if ($myrow = mysql_fetch_array($result))
{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<form method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="lang" value="<?php echo $lang?>">
<input type="hidden" name="mode" value="massdel">
<input type="hidden" name="eventlang" value="<?php echo $eventlang?>">
<input type="hidden" name="catnr" value="<?php echo $catnr?>">
<?php
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
	do{
		$act_id=$myrow["eventnr"];
		$eventtext=stripslashes($myrow["text"]);
		$eventtext = undo_htmlspecialchars($eventtext);
		if($myrow["heading"])
			$displaytext="<b>".$myrow["heading"]."</b><br>".$eventtext;
		else
			$displaytext=$eventtext;
		echo "<tr>";
		if($admin_rights > 1)
		{
			echo "<td class=\"inputrow\" align=\"center\" width=\"1%\">";
			echo "<input type=\"checkbox\" name=\"eventnr[]\" value=\"$act_id\">";
			echo "</td>";
		}
		echo "<td class=\"displayrow\" align=\"center\" width=\"8%\">";
		echo $myrow["eventnr"]."</td>";
		echo "<td class=\"eventicon\" align=\"center\" width=\"2%\">";
		if($myrow["headingicon"])
			echo "<img src=\"$url_icons/".$myrow["headingicon"]."\" border=\"0\" align=\"bottom\">";
		else
			echo "&nbsp;";
		echo "</td><td class=\"evententry\" align=\"left\">";
		echo "$displaytext</td>";
		echo "<td class=\"eventdate\" align=\"center\" width=\"20%\">";
		echo $myrow["date"]."</td>";
		if($admin_rights > 1)
		{
			echo "<td class=\"adminactions\" align=\"center\" width=\"2%\"><a href=\"".do_url_session("$act_script_url?lang=$lang&eventlang=$eventlang&mode=edit&input_eventnr=$act_id&catnr=$catnr")."\"><img src=\"gfx/edit.gif\" border=\"0\" title=\"$l_edit\" alt=\"$l_edit\"></a></td>";
			echo "<td class=\"adminactions\" align=\"center\" width=\"2%\"><a href=\"".do_url_session("$act_script_url?lang=$lang&eventlang=$eventlang&mode=del&input_eventnr=$act_id&catnr=$catnr")."\"><img src=\"gfx/delete.gif\" border=\"0\" title=\"$l_delete\" alt=\"$l_delete\"></a></td>";
		}
		echo "</tr>";
	}while($myrow=mysql_fetch_array($result));
	if($admin_rights > 1)
	{
		echo "<tr class=\"actionrow\"><td colspan=\"9\" align=\"left\"><input class=\"snbutton\" type=\"submit\" value=\"$l_delselected\"></td></tr>";
	}
	echo "</form></table></td></tr></table>";
}
}
include('./trailer.php')
?>
