<?php
require('../config.php');
require('./functions.php');
?>
<html><body>
<div align="center"><h3>SimpNews: Upgrade from 1.07/1.08/1.09 to 1.10</h3></div>
<br>
<?php
echo "Adding new tables...<br>";
// create table simpnews_events
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_events;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_events");
$sql = "CREATE TABLE ".$tableprefix."_events (";
$sql.= "eventnr int(10) unsigned NOT NULL auto_increment,";
$sql.= "date date NOT NULL DEFAULT '0000-00-00' ,";
$sql.= "lang varchar(4) NOT NULL DEFAULT '' ,";
$sql.= "poster varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "category int(10) NOT NULL DEFAULT '0' ,";
$sql.= "heading varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "headingicon varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "text text NOT NULL DEFAULT '' ,";
$sql.= "PRIMARY KEY (eventnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_events");
echo "Upgrading tables...<br>";
$sql = "ALTER TABLE ".$tableprefix."_layout ";
$sql.= "add prevpic varchar(240) NOT NULL DEFAULT 'prev_big.gif' ,";
$sql.= "add fwdpic varchar(240) NOT NULL DEFAULT 'next_big.gif' ,";
$sql.= "add eventheading varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "add event_dateformat varchar(20) NOT NULL DEFAULT ''";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_layout");
$sql = "ALTER TABLE ".$tableprefix."_settings ";
$sql.= "add newsineventcal tinyint(1) unsigned NOT NULL DEFAULT '0'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_settings");
?>
<br><div align="center">Installation done.<br>Please remove install.php, upgrade*.php and fill_freemailer.php from server</div>
<div align="center">Now you can login to the <a href="index.php">admininterface</a></div>
</html></body>