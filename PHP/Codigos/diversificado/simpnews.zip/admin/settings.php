<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
if(!isset($lang) || !$lang)
	$lang=$admin_lang;
include_once('./language/lang_'.$lang.'.php');
require_once('./auth.php');
$page_title=$l_syssettings;
require_once('./heading.php');
if($admin_rights < 2)
{
	die($l_functionotallowed);
}
if(isset($mode))
{
	$simpnewsmailname=trim($simpnewsmailname);
	if(isset($visitcookie))
		$lastvisitcookie=1;
	else
		$lastvisitcookie=0;
	if(isset($eventcalnews))
		$newsineventcal=1;
	else
		$newsineventcal=0;
	if(isset($allowsearch))
		$enablesearch=1;
	else
		$enablesearch=0;
	if(isset($enablecomments))
		$allowcomments=1;
	else
		$allowcomments=0;
	if(isset($subfreemailer))
		$subscriptionfreemailer=1;
	else
		$subscriptionfreemailer=0;
	if(isset($allowsubscriptions))
		$enablesubscriptions=1;
	else
		$enablesubscriptions=0;
	if(isset($nosubscriptionconfirm))
		$maxconfirmtime=0;
	if(isset($dowatchlogins))
		$watchlogins=1;
	else
		$watchlogins=0;
	if(isset($enablemenubar))
		$usemenubar=1;
	else
		$usemenubar=0;
	if(isset($enablefreemailer))
		$nofreemailer=0;
	else
		$nofreemailer=1;
	if(isset($dofailednotify))
		$enablefailednotify=1;
	else
		$enablefailednotify=0;
	if(isset($allowhostresolve))
		$enablehostresolve=1;
	else
		$enablehostresolve=0;
	if($settingsnew==1)
	{
		$sql = "insert into ".$tableprefix."_settings (";
		$sql.= "watchlogins, usemenubar, nofreemailer, enablefailednotify, ";
		$sql.= "loginlimit, simpnewsmail, enablehostresolve, maxconfirmtime, enablesubscriptions, subject, ";
		$sql.= "subscriptionsendmode, subscriptionfreemailer, sitename, maxage, entriesperpage, allowcomments, ";
		$sql.= "numhotnews, enablesearch, redirectdelay, newsnotifydays, newsineventcal, lastvisitcookie, ";
		$sql.= "servertimezone, displaytimezone, simpnewsmailname, news2entries, hotnewsmaxchars";
		$sql.= ") values (";
		$sql.= "$watchlogins, $usemenubar, $nofreemailer, $enablefailednotify, $loginlimit, '$simpnewsmail', ";
		$sql.= "$enablehostresolve, $maxconfirmtime, $enablesubscriptions, '$subject', $subscriptionsendmode, ";
		$sql.= "subscriptionfreemailer, '$sitename', $maxage, $entriesperpage, $allowcomments, $numhotnews, ";
		$sql.= "$enablesearch, $redirectdelay, $newsnotifydays, $newsineventcal, $lastvisitcookie, ";
		$sql.= "$input_servertimezone, $input_displaytimezone, $simpnewsmailname, $news2entries, $hotnewsmaxchars";
		$sql.= ")";
	}
	else
	{
		$sql = "update ".$tableprefix."_settings set watchlogins=$watchlogins, usemenubar=$usemenubar, ";
		$sql.= "nofreemailer=$nofreemailer, enablefailednotify=$enablefailednotify, loginlimit=$loginlimit, ";
		$sql.= "simpnewsmail='$simpnewsmail', enablehostresolve=$enablehostresolve, maxconfirmtime=$maxconfirmtime, ";
		$sql.= "enablesubscriptions=$enablesubscriptions, subject='$subject', subscriptionsendmode=$subscriptionsendmode, ";
		$sql.= "subscriptionfreemailer=$subscriptionfreemailer, sitename='$sitename', maxage=$maxage, ";
		$sql.= "entriesperpage=$entriesperpage, allowcomments=$allowcomments, numhotnews=$numhotnews, ";
		$sql.= "enablesearch=$enablesearch, redirectdelay=$redirectdelay, newsnotifydays=$newsnotifydays, ";
		$sql.= "newsineventcal=$newsineventcal, lastvisitcookie=$lastvisitcookie, servertimezone=$input_servertimezone, ";
		$sql.= "displaytimezone=$input_displaytimezone, simpnewsmailname='$simpnewsmailname', news2entries=$news2entries, ";
		$sql.= "hotnewsmaxchars=$hotnewsmaxchars ";
		$sql.= "where settingnr=1";
	}
	if(!$result = mysql_query($sql, $db))
	    die("Unable to connect to database.".mysql_error());
	if(isset($mods))
	{
   		while(list($null, $mod) = each($HTTP_POST_VARS["mods"]))
   		{
			$mod_query = "INSERT INTO ".$tableprefix."_failed_notify (usernr) VALUES ('$mod')";
   		   	if(!mysql_query($mod_query, $db))
			    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
		}
	}
	if(isset($rem_mods))
	{
		while(list($null, $mod) = each($HTTP_POST_VARS["rem_mods"]))
		{
			$rem_query = "DELETE FROM ".$tableprefix."_failed_notify WHERE usernr = '$mod'";
   			if(!mysql_query($rem_query))
			    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
		}
	}
}
$sql = "select * from ".$tableprefix."_settings where settingnr=1";
if(!$result = mysql_query($sql, $db))
    die("Unable to connect to database.".mysql_error());
if(!$myrow=mysql_fetch_array($result))
{
	$settingsnew=1;
	$watchlogins=0;
	$enablefailednotify=0;
	$simpnewsmail="simpnews@localhost";
	$loginlimit=0;
	$usemenubar=0;
	$nofreemailer=0;
	$enablehostresolve=0;
	$subscriptionfreemailer=1;
	$subject="";
	$enablesubscriptions=0;
	$subscriptionsendmode=1;
	$maxconfirmtime=2;
	$sitename="Sitename";
	$maxage=0;
	$entriesperpage=20;
	$allowcomments=0;
	$numhotnews=5;
	$enablesearch=0;
	$redirectdelay=-1;
	$newsnotifydays=1;
	$newsineventcal=0;
	$lastvisitcookie=1;
	$act_servertimezone=0;
	$act_displaytimezone=0;
	$simpnewsmailname="SimpNews";
	$news2entries=5;
	$hotnewsmaxchars=0;
}
else
{
	$settingsnew=0;
	$watchlogins=$myrow["watchlogins"];
	$enablefailednotify=$myrow["enablefailednotify"];
	$simpnewsmail=$myrow["simpnewsmail"];
	$loginlimit=$myrow["loginlimit"];
	$usemenubar=$myrow["usemenubar"];
	$nofreemailer=$myrow["nofreemailer"];
	$enablehostresolve=$myrow["enablehostresolve"];
	$subscriptionfreemailer=$myrow["subscriptionfreemailer"];
	$subject=$myrow["subject"];
	$enablesubscriptions=$myrow["enablesubscriptions"];
	$subscriptionsendmode=$myrow["subscriptionsendmode"];
	$maxconfirmtime=$myrow["maxconfirmtime"];
	$sitename=$myrow["sitename"];
	$maxage=$myrow["maxage"];
	$entriesperpage=$myrow["entriesperpage"];
	$allowcomments=$myrow["allowcomments"];
	$numhotnews=$myrow["numhotnews"];
	$enablesearch=$myrow["enablesearch"];
	$redirectdelay=$myrow["redirectdelay"];
	$newsnotifydays=$myrow["newsnotifydays"];
	$newsineventcal=$myrow["newsineventcal"];
	$lastvisitcookie=$myrow["lastvisitcookie"];
	$act_servertimezone=$myrow["servertimezone"];
	$act_displaytimezone=$myrow["displaytimezone"];
	$simpnewsmailname=$myrow["simpnewsmailname"];
	$news2entries=$myrow["news2entries"];
	$hotnewsmaxchars=$myrow["hotnewsmaxchars"];
}
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<form name="settingsform" method="post" action="<?php echo $act_script_url?>">
<?php
	if(is_konqueror())
		echo "<tr><td></td></tr>";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="lang" value="<?php echo $lang?>">
<input type="hidden" name="mode" value="submit">
<input type="hidden" name="settingsnew" value="<?php echo $settingsnew?>">
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_admininterface?></b></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="dowatchlogins" value="1" <?php if($watchlogins==1) echo "checked"?>> <?php echo $l_watchlogins?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="enablemenubar" value="1" <?php if($usemenubar==1) echo "checked"?>> <?php echo $l_usemenubar?></td></tr>
<tr class="inputrow"><td>&nbsp;</td><td align="left"><input name="allowhostresolve" value="1" type="checkbox"
<?php if($enablehostresolve==1) echo " checked"?>> <?php echo $l_enablehostresolve?></td></tr>
<tr class="inputrow"><td align="right" width="30%">&nbsp;</td>
<td align="left"><input type="checkbox" name="enablefreemailer" value="1" <?php if($nofreemailer==0) echo "checked"?>> <?php echo $l_enablefreemailer?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_loginlimit?>:</td>
<td align="left"><input class="sninput" type="text" name="loginlimit" value="<?php echo $loginlimit?>" size="2" maxlength="2"></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_failednotify?>:<br><input name="dofailednotify" value="1" type="checkbox"
<?php if($enablefailednotify==1) echo " checked"?>><?php echo $l_enable?></td>
<td align="left" valign="top">
<?php
	$sql = "SELECT * FROM ".$tableprefix."_failed_notify fn, ".$tableprefix."_users u where u.usernr=fn.usernr order by u.username";
	if(!$r = mysql_query($sql, $db))
	    die("Could not connect to the database.");
	if ($row = mysql_fetch_array($r))
	{
		 do {
		    echo $row["username"]." (<input type=\"checkbox\" name=\"rem_mods[]\" value=\"".$row["usernr"]."\"> $l_remove)<BR>";
		    $current_mods[] = $row["usernr"];
		 } while($row = mysql_fetch_array($r));
		 echo "<br>";
	}
	else
		echo "$l_noadmins<br><br>";
	$sql = "SELECT usernr, username FROM ".$tableprefix."_users WHERE rights > 2 ";
	if(isset($current_mods))
	{
    	while(list($null, $currMod) = each($current_mods)) {
			$sql .= "AND usernr != $currMod ";
    	}
    }
    $sql .= "ORDER BY username";
    if(!$r = mysql_query($sql, $db))
		die("Could not connect to the database.");
    if($row = mysql_fetch_array($r)) {
		echo"<b>$l_add:</b><br>";
		echo"<SELECT NAME=\"mods[]\" size=\"5\" multiple>";
		do {
			echo "<OPTION VALUE=\"$row[usernr]\" >$row[username]</OPTION>\n";
		} while($row = mysql_fetch_array($r));
		echo"</select>";
	}
?>
</td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_userinterface?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_entriesperpage?>:</td>
<td align="left"><input class="sninput" type="text" name="entriesperpage" value="<?php echo $entriesperpage?>" size="2" maxlength="2"></td></tr>
<tr class="inputrow"><td>&nbsp;</td><td align="left"><input type="checkbox" name="enablecomments" value="1" <?php if($allowcomments==1) echo "checked"?>> <?php echo $l_allowcomments?></td></tr>
<tr class="inputrow"><td>&nbsp;</td><td align="left"><input type="checkbox" name="allowsearch" value="1" <?php if($enablesearch==1) echo "checked"?>> <?php echo $l_enablesearch?></td></tr>
<tr class="inputrow"><td>&nbsp;</td><td align="left"><input type="checkbox" name="visitcookie" value="1" <?php if($lastvisitcookie==1) echo "checked"?>> <?php echo $l_lastvisitcookie?></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b>Hotnews <span class="remark">(hotnews.php/hotnews2.php)</span></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_numhotnews?>:</td>
<td align="left"><input class="sninput" type="text" name="numhotnews" value="<?php echo $numhotnews?>" size="2" maxlength="2"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_maxchars2?>:</td>
<td align="left"><input class="sninput" type="text" name="hotnewsmaxchars" value="<?php echo $hotnewsmaxchars?>" size="2" maxlength="4"> <?php echo $l_chars?></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b><?php echo $l_newsnotify?> <span class="remark">(newsnotify.php/newsnotify2.php)</span></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_newsnotifydays?>:</td>
<td align="left"><input class="sninput" type="text" name="newsnotifydays" value="<?php echo $newsnotifydays?>" size="2" maxlength="2"> <?php echo $l_days?></td></tr>
<tr class="listheading1"><td align="left" colspan="2"><b>News2.php</b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_entriespercategory?>:</td>
<td align="left"><input class="sninput" type="text" name="news2entries" value="<?php echo $news2entries?>" size="2" maxlength="2"></td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_eventcal?></b></td></tr>
<tr class="inputrow"><td>&nbsp;</td><td align="left"><input type="checkbox" name="eventcalnews" value="1" <?php if ($newsineventcal==1) echo "checked"?>> <?php echo $l_newsineventcal?></td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_general?></b></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_maxnewsage?>:</td>
<td align="left"><input class="sninput" type="text" name="maxage" value="<?php echo $maxage?>" size="5" maxlength="5"> <?php echo $l_days?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_sitename?>:</td>
<td align="left"><input class="sninput" type="text" name="sitename" value="<?php echo $sitename?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_simpnewsmail?>:</td>
<td align="left"><input class="sninput" type="text" name="simpnewsmail" value="<?php echo $simpnewsmail?>" size="40" maxlength="180"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_simpnewsmailname?>:</td>
<td align="left"><input class="sninput" type="text" name="simpnewsmailname" value="<?php echo $simpnewsmailname?>" size="40" maxlength="180"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_servertimezone?>:</td>
<td>GMT <select name="input_servertimezone">
<?php
for($i=-12;$i<13;$i++)
{
	echo "<option value=\"$i\"";
	if($i==$act_servertimezone)
		echo " selected";
	echo ">";
	if($i>0)
		echo "+$i";
	else
		echo "$i";
	echo "</option>";
}
?>
</select></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_displaytimezone?>:</td>
<td>GMT <select name="input_displaytimezone">
<?php
for($i=-12;$i<13;$i++)
{
	echo "<option value=\"$i\"";
	if($i==$act_displaytimezone)
		echo " selected";
	echo ">";
	if($i>0)
		echo "+$i";
	else
		echo "$i";
	echo "</option>";
}
?>
</select></td></tr>
<tr class="listheading0"><td align="left" colspan="2"><b><?php echo $l_subscriptions?></b></td></tr>
<tr class="inputrow"><td>&nbsp;</td><td align="left"><input type="checkbox" name="allowsubscriptions" value="1" <?php if($enablesubscriptions==1) echo "checked"?>> <?php echo $l_enable?></td></tr>
<tr class="inputrow"><td>&nbsp;</td><td align="left"><input type="checkbox" name="subfreemailer" value="1" <?php if($subscriptionfreemailer==1) echo "checked"?>> <?php echo $l_subscriptionfreemailer?></td></tr>
<tr class="inputrow"><td>&nbsp;</td><td align="left"><input type="radio" name="subscriptionsendmode" value="0" <?php if($subscriptionsendmode==0) echo "checked"?>> <?php echo $l_directsend?><br>
<input type="radio" name="subscriptionsendmode" value="1" <?php if($subscriptionsendmode==1) echo "checked"?>> <?php echo $l_masssend?></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_maxconfirmtime?>:</td><td align="left" valign="top">
<input type="checkbox" name="nosubscriptionconfirm" onClick="settings_maxconfirmtime()" value="1" <?php if ($maxconfirmtime==0) echo "checked"?>> <?php echo $l_noconfirm?><br>
<select name="maxconfirmtime" <?php if($maxconfirmtime==0) echo "disabled"?>>
<?php
for($i=1;$i<10;$i++)
{
	echo "<option value=\"$i\"";
	if($i==$maxconfirmtime)
		echo " selected";
	echo ">$i</option>";
}
?>
</select>&nbsp;<?php echo $l_days?></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_subject?>:</td><td align="left">
<input class="sninput" type="text" name="subject" value="<?php echo $subject?>" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_subscriptionredirectdelay?>:</td>
<td><input class="sninput" type="text" name="redirectdelay" value="<?php echo $redirectdelay?>" size="2" maxlength="2"> <?php echo $l_seconds?></td></tr>
<tr class="actionrow"><td align="center" colspan="2"><input class="snbutton" type="submit" value="<?php echo $l_submit?>"></td></tr>
</form>
</table></td></tr></table>
<?php include('./trailer.php')?>
