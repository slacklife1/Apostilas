<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
require_once('../functions.php');
require_once('./functions.php');
require_once('./auth.php');
if(!isset($lang) || !$lang)
	$lang=$admin_lang;
include_once('./language/lang_'.$lang.'.php');
$user_loggedin=0;
$userdata=Array();
if(!isset($subdir))
	$subdir="";
if($enable_htaccess)
{
	if(isbanned(get_userip(),$db))
	{
?>
<html>
<head>
<meta name="generator" content="SimpNews v<?php echo $version?>, <?php echo $copyright_asc?>">
<title>SimpNews- Administration</title>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<?php
	if(is_ns4())
		echo "<link rel=stylesheet href=./snadm_ns4.css type=text/css>\n";
	else if(is_ns6())
		echo "<link rel=stylesheet href=./snadm_ns6.css type=text/css>\n";
	else if(is_opera())
		echo "<link rel=stylesheet href=./snadm_opera.css type=text/css>\n";
	else if(is_konqueror())
		echo "<link rel=stylesheet href=./snadm_konqueror.css type=text/css>\n";
	else if(is_gecko())
		echo "<link rel=stylesheet href=./snadm_gecko.css type=text/css>\n";
	else
		echo "<link rel=stylesheet href=./snadm.css type=text/css>\n";
?>
</head>
<body>
<table width="80%" align="CENTER" calign="MIDDLE" border="0" cellspacing="0" cellpadding="0">
<tr><td align="CENTER" class="prognamerow"><h1>SimpNews v<?php echo $version?></h1></td></tr>
</table>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="displayrow"><td colspan="2" align="center"><b><?php echo $l_ipbanned?></b></td></tr>
<tr class="displayrow"><td align="right" width="20%"><?php echo $l_reason?>:</td>
<td align="left" width="80%"><?php echo $banreason?></td></tr>
</table></td></tr></table></body></html>
<?php
		exit;
	}
	$username=$REMOTE_USER;
	$myusername=addslashes(strtolower($username));
	$sql = "select * from ".$tableprefix."_users where username='$myusername'";
	if(!$result = mysql_query($sql, $db))
	    die("<tr class=\"errorrow\"><td>Unable to connect to database");
	if (!$myrow = mysql_fetch_array($result))
	{
	    die("<tr class=\"errorrow\"><td>User not defined for SimpNews");
	}
	$userid=$myrow["usernr"];
	$user_loggedin=1;
    $userdata = get_userdata_by_id($userid, $db);
}
else if($sessid_url)
{
	if(isset($$sesscookiename))
	{
		$url_sessid=$$sesscookiename;
		$userid = get_userid_from_session($url_sessid, $sesscookietime, get_userip(), $db);
		if ($userid) {
		   $user_loggedin = 1;
		   update_session($url_sessid, $db);
		   $userdata = get_userdata_by_id($userid, $db);
		   $userdata["lastlogin"]=get_lastlogin_from_session($url_sessid, $sesscookietime, get_userip(), $db);
		}
	}
} else if(isset($HTTP_COOKIE_VARS[$sesscookiename])) {
	$sessid = $HTTP_COOKIE_VARS[$sesscookiename];
	$userid = get_userid_from_session($sessid, $sesscookietime, get_userip(), $db);
	if ($userid) {
	   $user_loggedin = 1;
	   update_session($sessid, $db);
	   $userdata = get_userdata_by_id($userid, $db);
	}
}
if($user_loggedin==0)
	die($l_loginfirst);
if($userdata["rights"]<3)
	die("$l_functionnotallowed");
$gfx_dir=$path_gfx;
$pic_url=$url_gfx;
if($subdir)
{
	$gfx_dir.=$subdir;
	$pic_url.=$subdir;
}
if(isset($ACTION))
{
	if ( $ACTION == "UPLOAD" ) {
		if ($USERFILE_name) {
			move_uploaded_file($USERFILE,$gfx_dir."/".$USERFILE_name);
		}
	} else if ( $ACTION == "DEL" ) {
		unlink($gfx_dir."/".$DELFILE);
	} else if ( $ACTION == "MKDIR" ) {
		$newdir=$gfx_dir."/".$NEWDIR;
		mkdir($newdir,0755);
		chmod ($newdir,0777);
	}
}
echo "<html><head><title>";
if($upload_avail)
	echo $l_gfxupload;
else
	echo $l_choose;
echo "</title>\n";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=$contentcharset\">";
	if(is_ns4())
		echo "<link rel=stylesheet href=./snadm_ns4.css type=text/css>\n";
	else if(is_ns6())
		echo "<link rel=stylesheet href=./snadm_ns6.css type=text/css>\n";
	else if(is_opera())
		echo "<link rel=stylesheet href=./snadm_opera.css type=text/css>\n";
	else if(is_konqueror())
		echo "<link rel=stylesheet href=./snadm_konqueror.css type=text/css>\n";
	else if(is_gecko())
		echo "<link rel=stylesheet href=./snadm_gecko.css type=text/css>\n";
	else
		echo "<link rel=stylesheet href=./snadm.css type=text/css>\n";
echo "<script language='javascript'>\n";
if(($mode==1) || ($mode==2))
{
	echo "function choosepic(filestr)\n";
	echo "{\n";
	echo "	mywin=window.opener;\n";
	echo "	mywin.document.$inputform.$inputfield.value=filestr;\n";
	echo "	window.close();\n";
	echo "	return;\n";
	echo "}\n";
	echo "</SCRIPT>\n";
}
else
{
	echo "function choosepic(filestr)\n";
	echo "{\n";
	echo "	var strSelection=\"\";\n";
	echo "	mywin=window.opener;\n";
	if(is_msie() && is_win() && (get_browser_version()>=4))
		echo "strSelection = mywin.document.selection.createRange().text;\n";
	echo "	if (strSelection == \"\")\n";
	if(is_msie() && is_win() && (get_browser_version()>=4))
		echo "		mywin.document.inputform.$inputfield.focus();\n";
	echo "	var addText = \"[img]http://".$simpnewssitename.$url_gfx."/\" + filestr + \"[/img]\";\n";
	if(is_msie() && is_win() && (get_browser_version()>=4))
		echo "	mywin.document.selection.createRange().text = addText;\n";
	else
		echo "	mywin.document.inputform.$inputfield.value += addText;\n";
	echo "	window.close();\n";
	echo "	return;\n";
	echo "}\n";
	echo "</SCRIPT>\n";
}
echo "</head><body><center>";
if($upload_avail)
{
	echo "<FORM enctype=\"multipart/form-data\" action=\"$act_script_url\" method=\"post\">";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
	if(isset($inputform))
		echo "<input type=\"hidden\" name=\"inputform\" value=\"$inputform\">";
	echo "<input type=\"hidden\" name=\"MAX_FILE_SIZE\" value=\"9999999\">";
	echo "<input type=\"hidden\" name=\"ACTION\" value=\"UPLOAD\">";
	echo "<input type=\"hidden\" name=\"mode\" value=\"$mode\">";
	echo "<input type=\"hidden\" name=\"inputfield\" value=\"$inputfield\">";
	echo "<input class=\"snfile\" name=\"USERFILE\" type=\"File\" size=\"20\">";
	echo "<input class=\"snbutton\" type=\"submit\" value=\"$l_upload\">";
	echo "<input type=\"hidden\" name=\"lang\" value=\"$lang\">";
	echo "<input type=\"hidden\" name=\"subdir\" value=\"$subdir\">";
	echo "</FORM><br>";
}
echo "<FORM name=\"dirform\" action=\"$act_script_url\" method=\"post\">";
if($sessid_url)
	echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
if(isset($inputform))
	echo "<input type=\"hidden\" name=\"inputform\" value=\"$inputform\">";
echo "<input type=\"hidden\" name=\"lang\" value=\"$lang\">";
echo "<input type=\"hidden\" name=\"subdir\" value=\"$subdir\">";
echo "<input type=\"hidden\" name=\"ACTION\" value=\"MKDIR\">";
echo "<input type=\"hidden\" name=\"mode\" value=\"$mode\">";
echo "<input type=\"hidden\" name=\"inputfield\" value=\"$inputfield\">";
echo "<input class=\"snfile\" name=\"NEWDIR\" type=\"text\" size=\"20\">&nbsp;";
echo "<input class=\"snbutton\" type=\"submit\" value=\"$l_createsubdir\">";
echo "</FORM><br>";
/* ********************************************************** */
$cdir = dir($gfx_dir);
echo "<table border=\"0\" width=\"95%\" align=\"center\" cellspacing=\"0\" cellpadding=\"4\">";
echo "<tr class=\"inforow\"><td align=\"center\"><b>$l_actsubdir:</b> ";
if($subdir)
{
	$tmpsubdir=substr($subdir,1);
	$subdirparts=explode("/",$tmpsubdir);
	$newsubdir="";
	for($i=0;$i<count($subdirparts);$i++)
	{
		$newsubdir.="/".$subdirparts[$i];
		$link_url="$act_script_url?lang=$lang&inputfield=$inputfield&subdir=$newsubdir&mode=$mode";
		if(isset($inputform))
			$link_url.="&inputform=$inputform";
		echo "<a class=\"listlink\" href=\"".do_url_session($link_url)."\">";
		echo $subdirparts[$i];
		echo "</a>/";
	}
}
else
	echo $l_none2;
echo "</td></tr>";
echo "</table>";

echo "<table border=\"0\" width=\"95%\" align=\"center\" cellspacing=\"0\" cellpadding=\"4\">";
$old_cwd = getcwd();
$piccount=0;
if( !chdir($gfx_dir) )
	die($l_wrong_emoticondir);
if($subdir)
{
		if(substr_count($subdir,"/")>1)
		{
	        echo "<tr class=\"listrow3\">";
			echo "<td align=\"center\">&lt;/&gt;</td>";
			echo "<td>$l_rootdir</td>";
			echo "<td align=\"right\">&nbsp;</td>";
			$newsubdir="";
			$link_url="$act_script_url?lang=$lang&inputfield=$inputfield&subdir=$newsubdir&mode=$mode";
			if(isset($inputform))
				$link_url.="&inputform=$inputform";
			echo "<td class=\"listlink\" align=\"right\" colspan=\"2\"><a href=\"".do_url_session($link_url)."\">$l_changedir</a></td>";
			echo "</tr>";
		}
        echo "<tr class=\"listrow3\">";
		echo "<td align=\"center\">&lt;..&gt;</td>";
		echo "<td>$l_parentdir</td>";
		echo "<td align=\"right\">&nbsp;</td>";
		if($parentend=strrpos($subdir,"/"))
		{
			if($parentend<1)
				$newsubdir="";
			else
				$newsubdir=substr($subdir,0,$parentend);
		}
		else
			$newsubdir="";
		$link_url="$act_script_url?lang=$lang&inputfield=$inputfield&subdir=$newsubdir&mode=$mode";
		if(isset($inputform))
			$link_url.="&inputform=$inputform";
		echo "<td align=\"right\" colspan=\"2\"><a class=\"listlink\" href=\"".do_url_session($link_url)."\">$l_changedir</a></td>";
		echo "</tr>";
}
while ($entry=$cdir->read())
{
	if ((strlen($entry)>2) && (filetype($entry)=="dir"))
	{
        echo "<tr class=\"listrow3\">";
		echo "<td align=\"center\">&lt;$entry&gt;</a></td>";
		echo "<td>$entry</a></td>";
		echo "<td align=\"right\">&nbsp;</td>";
		$newsubdir=$subdir."/".$entry;
		$link_url="$act_script_url?lang=$lang&inputfield=$inputfield&subdir=$newsubdir&mode=$mode";
		if(isset($inputform))
			$link_url.="&inputform=$inputform";
		echo "<td align=\"right\" colspan=\"2\"><a class=\"listlink\" href=\"".do_url_session($link_url)."\">$l_changedir</a></td>";
		echo "</tr>";
	}
}
$cdir->rewind();
while ($entry=$cdir->read())
{
	if ((strlen($entry)>2) && (filetype($entry)=="file"))
	{
		if(!($piccount % 2))
			$row_class = "listrow1";
		else
			$row_class = "listrow2";
        $piccount++;
        echo "<tr class=\"$row_class\">";
		echo "<td align=\"center\">";
		echo "<img src=\"$pic_url/$entry\" border=\"0\">";
		echo "</td>";
		echo "<td>$entry</a></td>";
		echo "<td align=\"right\">".filesize($entry)." bytes</a></td>";
		$reldir=str_replace($path_gfx,"",$gfx_dir);
		if(substr($reldir,0,1)=="/")
			$reldir=substr($reldir,1);
		if(strlen($reldir)>0)
			$reldir.="/";
		if($mode==2)
			$reldir=$url_gfx."/".$reldir;
		echo "<td align=\"right\"><a class=\"listlink\" href=\"javascript:choosepic('".$reldir.$entry."')\">$l_choose</a></td>";
		$link_url="$act_script_url?ACTION=DEL&DELFILE=$entry&lang=$lang&inputfield=$inputfield&subdir=$subdir&mode=$mode";
		if(isset($inputform))
			$link_url.="&inputform=$inputform";
		echo "<td align=\"right\"><a class=\"listlink\" href=\"".do_url_session($link_url)."\">$l_delete</a>";
		echo "</tr>";
	}
}
echo "</table>";
chdir($old_cwd);
if($piccount==0)
	echo "<center>$l_noemoticonsindir</center>";
echo "</center><br><br>";
?>