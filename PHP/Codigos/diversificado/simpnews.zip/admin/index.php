<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
if(!isset($lang) || !$lang)
	$lang=$admin_lang;
include_once('./language/lang_'.$lang.'.php');
require_once('./auth.php');
$page_title=$l_admin_title;
require_once('./heading.php');
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="indexsep"><td align="center"><a name="#news"><b><?php echo $l_news?></b></a></td></tr>
<tr class="indexrow1"><td align="center"><a href="<?php echo do_url_session("news.php?lang=$lang")?>"><?php echo $l_editnews?></a></td></tr>
<tr class="indexrow1"><td align="center"><a href="<?php echo do_url_session("events.php?lang=$lang")?>"><?php echo $l_events?></a></td></tr>
<?php
if($admin_rights > 1)
{
?>
<tr class="indexrow1"><td align="center"><a href="<?php echo do_url_session("categories.php?lang=$lang")?>"><?php echo $l_categories?></a></td></tr>
<tr class="indexrow1"><td align="center"><a href="<?php echo do_url_session("purgenews.php?lang=$lang")?>"><?php echo $l_purgenews?></a></td></tr>
<tr class="indexrow1"><td align="center"><a href="<?php echo do_url_session("purgeevents.php?lang=$lang")?>"><?php echo $l_purgeevents?></a></td></tr>
<tr class="indexrow1"><td align="center"><a href="<?php echo do_url_session("rebuildsearch.php?lang=$lang")?>"><?php echo $l_rebuildsearch?></a></td></tr>
<?php
}
if($admin_rights > 2)
{
?>
<tr class="indexsep"><td align="center"><a name="#set"><b><?php echo $l_settings?></b></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("layout.php?lang=$lang")?>"><?php echo $l_layout?></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("settings.php?lang=$lang")?>"><?php echo $l_syssettings?></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("emoticons.php?lang=$lang")?>"><?php echo $l_emoticons?></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("icons.php?lang=$lang")?>"><?php echo $l_icons?></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("freemailer.php?lang=$lang")?>"><?php echo $l_freemailerlist?></a></td></tr>
<?php
}
?>
<tr class="indexsep"><td align="center"><a name="#subscription"><b><?php echo $l_subscriptions?></b></a></td></tr>
<tr class="indexrow1"><td align="center"><a href="<?php echo do_url_session("subscribers.php?lang=$lang")?>"><?php echo $l_subscribers?></a></td></tr>
<tr class="indexrow1"><td align="center"><a href="<?php echo do_url_session("sendnews.php?lang=$lang")?>"><?php echo $l_emailnews?></a></td></tr>
<tr class="indexsep"><td align="center"><a name="#users"><b><?php echo $l_user?></b></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("users.php?lang=$lang")?>"><?php echo $l_editusers?></a></td></tr>
<?php
if($admin_rights>2)
{
?>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("loginfailures.php?lang=$lang")?>"><?php echo $l_failed_logins?></a></td></tr>
<tr class="indexrow2"><td align="center"><a href="<?php echo do_url_session("banlist.php?lang=$lang")?>"><?php echo $l_ipbanlist?></a></td></tr>
<tr class="indexsep"><td align="center"><a name="#admin"><b><?php echo $l_administration?></b></a></td></tr>
<tr class="indexrow1"><td align="center"><a href="<?php echo do_url_session("hostcache.php?lang=$lang")?>"><?php echo $l_hostcache?></a></td></tr>
<tr class="indexrow1"><td align="center"><a href="<?php echo do_url_session("sessions.php?lang=$lang")?>"><?php echo $l_cleansession?></a></td></tr>
<tr class="indexrow1"><td align="center"><a href="<?php echo do_url_session("shutdown.php?lang=$lang")?>"><?php echo $l_shutdownsys?></a></td></tr>
<tr class="indexrow1"><td align="center"><a href="<?php echo do_url_session("backup.php?lang=$lang")?>"><?php echo $l_dbbackup?></a></td></tr>
<?php
}
?>
</table></td></tr></table>
<?php include('./trailer.php')?>
