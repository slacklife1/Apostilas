<?php
require('../config.php');
require('./functions.php');
?>
<html><body>
<div align="center"><h3>SimpNews: Upgrade from 1.22 to 1.23</h3></div>
<br>
<?php
echo "Upgrading tables...<br>";
$sql = "ALTER TABLE ".$tableprefix."_layout ";
$sql.= "add newentrypic varchar(240) NOT NULL DEFAULT 'new.gif' ,";
$sql.= "add newstypermaxentries int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "add newstyperbgcolor varchar(7) NOT NULL DEFAULT '#cccccc' ,";
$sql.= "add newstyperfontcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.= "add newstyperfont varchar(240) NOT NULL DEFAULT 'Verdana' ,";
$sql.= "add newstyperfontsize tinyint(2) unsigned NOT NULL DEFAULT '12' ,";
$sql.= "add newstyperfontstyle tinyint(2) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "add newstyperdisplaydate tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "add newstyperdateformat varchar(20) NOT NULL DEFAULT 'Y-m-d' ,";
$sql.= "add newstyperxoffset tinyint(4) unsigned NOT NULL DEFAULT '8' ,";
$sql.= "add newstyperyoffset tinyint(4) unsigned NOT NULL DEFAULT '8' ,";
$sql.= "add newstypermaxdays int(10) NOT NULL DEFAULT '0' ,";
$sql.= "add newstypermaxchars int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "add newstyperwidth int(10) unsigned NOT NULL DEFAULT '200' ,";
$sql.= "add newstyperheight int(10) unsigned NOT NULL DEFAULT '300' ,";
$sql.= "add newstyperbgimage varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "add newstyperscroll tinyint(1) unsigned NOT NULL DEFAULT '1'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_layout");
$sql = "ALTER TABLE ".$tableprefix."_settings ";
$sql.= "add lastvisitcookie tinyint(1) unsigned NOT NULL DEFAULT '1'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_settings");
$sql = "ALTER TABLE ".$tableprefix."_events ";
$sql.= "add added datetime NOT NULL DEFAULT '0000-00-00 00:00:00'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_events");
?>
<br><div align="center">Installation done.<br>Please remove install.php, upgrade*.php and fill_freemailer.php from server</div>
<div align="center">Now you can login to the <a href="index.php">admininterface</a></div>
</html></body>