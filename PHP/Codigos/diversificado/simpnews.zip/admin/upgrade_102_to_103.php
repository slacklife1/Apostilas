<?php
require('../config.php');
require('./functions.php');
?>
<html><body>
<div align="center"><h3>SimpNews: Upgrade from 1.02 to 1.03</h3></div>
<br>
<?php
echo "Upgrading tables..<br>";
$sql = "ALTER TABLE ".$tableprefix."_data ADD ";
$sql.= "allowcomments tinyint(1) unsigned NOT NULL DEFAULT '1'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_data");
$sql = "ALTER TABLE ".$tableprefix."_settings ADD ";
$sql.= "enablesearch tinyint(1) unsigned NOT NULL DEFAULT '0'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_settings");
$sql = "ALTER TABLE ".$tableprefix."_layout ";
$sql.= "add searchpic varchar(240) NOT NULL DEFAULT 'search.gif', ";
$sql.= "add backpic varchar(240) NOT NULL DEFAULT 'back.gif' ,";
$sql.= "add pagepic_back varchar(240) NOT NULL DEFAULT 'prev.gif' ,";
$sql.= "add pagepic_first varchar(240) NOT NULL DEFAULT 'first.gif' ,";
$sql.= "add pagepic_next varchar(240) NOT NULL DEFAULT 'next.gif' ,";
$sql.= "add pagepic_last varchar(240) NOT NULL DEFAULT 'last.gif' ,";
$sql.= "add pagetoppic varchar(240) NOT NULL DEFAULT 'pagetop.gif'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_layout");
?>
<br><div align="center">Installation done.<br>Please remove install.php, upgrade*.php and fill_freemailer.php from server</div>
<div align="center">Now you can login to the <a href="index.php">admininterface</a></div>
</html></body>