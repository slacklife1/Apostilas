<?php
require('../config.php');
require('./functions.php');
?>
<html><body>
<div align="center"><h3>SimpNews: Upgrade from 1.23 to 1.24</h3></div>
<br>
<?php
echo "Upgrading tables...<br>";
$sql = "ALTER TABLE ".$tableprefix."_layout ";
$sql.= "add newsscrollernolinking tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "add newstyper2maxentries int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "add newstyper2bgcolor varchar(7) NOT NULL DEFAULT '#cccccc' ,";
$sql.= "add newstyper2fontcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.= "add newstyper2fontsize tinyint(2) unsigned NOT NULL DEFAULT '12' ,";
$sql.= "add newstyper2displaydate tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "add newstyper2newscreen tinyint(1) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "add newstyper2waitentry tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "add newstyper2dateformat varchar(20) NOT NULL DEFAULT 'Y-m-d' ,";
$sql.= "add newstyper2indent tinyint(4) unsigned NOT NULL DEFAULT '8' ,";
$sql.= "add newstyper2linespace tinyint(4) unsigned NOT NULL DEFAULT '15' ,";
$sql.= "add newstyper2maxdays int(10) NOT NULL DEFAULT '-1' ,";
$sql.= "add newstyper2maxchars int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "add newstyper2width int(10) unsigned NOT NULL DEFAULT '300' ,";
$sql.= "add newstyper2height int(10) unsigned NOT NULL DEFAULT '200' ,";
$sql.= "add newstyper2bgimage varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "add newstyper2sound varchar(240) NOT NULL DEFAULT '$url_simpnews/sfx/tick.au' ,";
$sql.= "add newstyper2charpause int(10) unsigned NOT NULL DEFAULT '50' ,";
$sql.= "add newstyper2linepause int(10) unsigned NOT NULL DEFAULT '500' ,";
$sql.= "add newstyper2screenpause int(10) unsigned NOT NULL DEFAULT '5000'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_layout");
?>
<br><div align="center">Installation done.<br>Please remove install.php, upgrade*.php and fill_freemailer.php from server</div>
<div align="center">Now you can login to the <a href="index.php">admininterface</a></div>
</html></body>