<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
if(!isset($lang) || !$lang)
	$lang=$admin_lang;
include_once('./language/lang_'.$lang.'.php');
if(!isset($newslang))
	$newslang=$lang;
require_once('./auth.php');
$page_title=$l_comments;
require_once('./heading.php');
if($admin_rights < 2)
{
	die($l_functionotallowed);
}
$sql = "select * from ".$tableprefix."_settings where (settingnr=1)";
if(!$result = mysql_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = mysql_fetch_array($result))
{
	$subscriptionsendmode=$myrow["subscriptionsendmode"];
	$enablesubscriptions=$myrow["enablesubscriptions"];
	$subject=$myrow["subject"];
	$simpnewsmail=$myrow["simpnewsmail"];
}
else
{
	$subscriptionsendmode=0;
	$enablesubscriptions=0;
	$subject="News";
	$simpnewsmail="simpnews@foo.bar";
}
if(isset($mode))
{
	if($mode=="del")
	{
		$sql = "delete from ".$tableprefix."_comments where commentnr=$input_commentnr";
		if(!$result = mysql_query($sql, $db))
		    die("Unable to connect to database.".mysql_error());
	}
}
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
$sql = "select * from ".$tableprefix."_comments where entryref=$entryref order by enterdate desc";
if(!$result = mysql_query($sql, $db))
    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
if ($myrow = mysql_fetch_array($result))
{
?>
<?php
	do{
		$act_id=$myrow["commentnr"];
		$commenttext=htmlentities($myrow["comment"]);
		echo "<tr class=\"displayrow\"><td align=\"center\" width=\"8%\">";
		echo $myrow["commentnr"]."</td>";
		echo "<td align=\"left\">";
		echo "$commenttext</td>";
		echo "<td align=\"center\" width=\"20%\">";
		echo $myrow["enterdate"]."</td>";
		if($admin_rights > 1)
		{
			echo "<td align=\"center\" width=\"2%\"><a class=\"listlink\" href=\"".do_url_session("$act_script_url?lang=$lang&mode=del&input_commentnr=$act_id&entryref=$entryref")."\"><img src=\"gfx/delete.gif\" border=\"0\" title=\"$l_delete\" alt=\"$l_delete\"></a></td>";
		}
		echo "</tr>";
	}while($myrow=mysql_fetch_array($result));
}
else
{
	echo "<tr class=\"displayrow\"><td align=\"center\">$l_noentries</td></tr>";
}
echo "</table></td></tr></table>";
echo "<div class=\"bottombox\" align=\"center\"><a href=\"news.php?lang=$lang\">$l_news</a></div>";
include('./trailer.php')
?>
