<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
if(!isset($lang) || !$lang)
	$lang=$admin_lang;
include_once('./language/lang_'.$lang.'.php');
if(!isset($newslang))
	$newslang=$lang;
require_once('./auth.php');
$page_title=$l_emailnews;
require_once('./heading.php');
include_once('../includes/class.html.mime.mail.inc');
define('CRLF', "\r\n", TRUE);
if($use_smtpmail)
	include_once('../includes/class.smtp.inc');
if(!isset($input_subscriptionnr))
	die("calling error");
$sql = "select * from ".$tableprefix."_settings where (settingnr=1)";
if(!$result = mysql_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = mysql_fetch_array($result))
{
	$subscriptionsendmode=$myrow["subscriptionsendmode"];
	$enablesubscriptions=$myrow["enablesubscriptions"];
	$subject=$myrow["subject"];
	$simpnewsmail=$myrow["simpnewsmail"];
	$simpnewsmailname=$myrow["simpnewsmailname"];
	$servertimezone=$myrow["servertimezone"];
	$displaytimezone=$myrow["displaytimezone"];
}
else
{
	$subscriptionsendmode=0;
	$enablesubscriptions=0;
	$subject="News";
	$simpnewsmail="simpnews@foo.bar";
	$simpnewsmailname="SimpNews";
}
if($admin_rights<2)
{
	echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
	die("$l_functionnotallowed");
}
if(!isset($filtercat))
	$filtercat=-1;
$actdate = date("Y-m-d H:i:s");
$sql="select * from ".$tableprefix."_subscriptions where confirmed=1 and subscriptionnr=$input_subscriptionnr";
if(!$result = mysql_query($sql, $db))
    die("Unable to connect to database.".mysql_error());
if(!$myrow=mysql_fetch_array($result))
    die("Unable to connect to database.");
if(!isset($mode))
{
	$newssql="select * from ".$tableprefix."_data where lang='".$myrow["language"]."'";
	if($filtercat>=0)
		$newssql.=" and category=$filtercat";
	$newssql.=" order by category asc, date desc";
	if(!$newsresult = mysql_query($newssql, $db))
	    die("Unable to connect to database.".mysql_error());
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
	echo "<form name=\"newslist\" method=\"post\" action=\"$act_script_url\">";
	if(is_konqueror())
		echo "<tr><td></td></tr>";
	echo "<input type=\"hidden\" name=\"lang\" value=\"$lang\">";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
	echo "<input type=\"hidden\" name=\"mode\" value=\"send\">";
	echo "<input type=\"hidden\" name=\"input_subscriptionnr\" value=\"$input_subscriptionnr\">";
	echo "<tr class=\"rowheadings\"><td width=\"2%\"></td>";
	echo "<td align=\"center\" width=\"5%\"><b>#</b></td>";
	echo "<td align=\"center\" width=\"40%\"><b>$l_news</b></td>";
	echo "<td align=\"center\" width=\"20%\"><b>$l_date</b></td>";
	echo "<td align=\"center\" width=\"20%\"><b>$l_category</b></td>";
	echo "</tr>";
	$numnews=mysql_num_rows($newsresult);
	while($newsrow=mysql_fetch_array($newsresult))
	{
		if($newsrow["category"]>0)
		{
			$catsql="select * from ".$tableprefix."_categories where catnr=".$newsrow["category"];
			if(!$catresult = mysql_query($catsql, $db))
			    die("Unable to connect to database.".mysql_error());
			if(!$catrow = mysql_fetch_array($catresult))
			    die("Unable to connect to database.");
			$catname=htmlentities(stripslashes($catrow["catname"]));
		}
		else
			$catname=$l_general;
		echo "<tr><td valign=\"top\" class=\"displayrow\" align=\"center\"><input type=\"checkbox\" name=\"newsnr[]\" value=\"".$newsrow["newsnr"]."\"></td>";
		echo "<td class=\"displayrow\" align=\"center\" valign=\"top\">".$newsrow["newsnr"]."</td>";
		$newstext=stripslashes($newsrow["text"]);
		$newstext = undo_htmlspecialchars($newstext);
		if($newsrow["heading"])
			$displaytext="<b>".$newsrow["heading"]."</b><br>".$newstext;
		else
			$displaytext=$newstext;
		echo "</td><td class=\"newsentry\" align=\"left\">";
		echo "$displaytext</td>";
		echo "<td valign=\"top\" class=\"newsdate\" align=\"center\" width=\"20%\">";
		list($mydate,$mytime)=explode(" ",$newsrow["date"]);
		list($year, $month, $day) = explode("-", $mydate);
		list($hour, $min, $sec) = explode(":",$mytime);
		$temptime=mktime($hour,$min,$sec,$month,$day,$year);
		$temptime=$temptime-($servertimezone*60*60);
		$temptime=$temptime+($displaytimezone*60*60);
		$displaydate=date("Y-m-d H:i:s",$temptime);
		echo "$displaydate</td>";
		echo "<td class=\"displayrow\" align=\"center\" valign=\"top\">";
		echo $catname;
		echo "</td></tr>";
	}
	if($numnews>0)
	{
		echo "<tr class=\"actionrow\"><td colspan=\"9\" align=\"left\"><input class=\"snbutton\" type=\"submit\" value=\"$l_sendselected\">";
		echo "&nbsp; <input class=\"snbutton\" type=\"button\" onclick=\"checkAll(document.newslist)\" value=\"$l_checkall\">";
		echo "&nbsp; <input class=\"snbutton\" type=\"button\" onclick=\"uncheckAll(document.newslist)\" value=\"$l_uncheckall\">";
		echo "</td></tr>";
	}
	else
		echo "<tr><td class=\"displayrow\" align=\"center\" colspan=\"5\">$l_noentries</td></tr>";
	echo "</form>";
	echo"</table></td></tr></table>";
	echo "<table class=\"filterbox\" align=\"center\" width=\"80%\" cellspacing=\"0\" cellpadding=\"1\" valign=\"top\">";
	echo "<form method=\"post\" action=\"$act_script_url\">";
	echo "<tr><td align=\"center\" valign=\"middle\">";
	echo "<input type=\"hidden\" name=\"lang\" value=\"$lang\">";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
	echo "<input type=\"hidden\" name=\"input_subscriptionnr\" value=\"$input_subscriptionnr\">";
	echo "<b>$l_filtercat:</b> ";
	echo "<select name=\"filtercat\">";
	echo "<option value=\"-1\"";
	if($filtercat==-1)
		echo " selected";
	echo ">$l_nofilter</option>";
	echo "<option value=\"0\"";
	if($filtercat==0)
		echo " selected";
	echo ">$l_general</option>";
	$catsql="select * from ".$tableprefix."_categories";
	if(!$catresult = mysql_query($catsql, $db))
	    die("Unable to connect to database.".mysql_error());
	while($catrow=mysql_fetch_array($catresult))
	{
		echo "<option value=\"".$catrow["catnr"]."\"";
		if($filtercat==$catrow["catnr"])
			echo " selected";
		echo ">".stripslashes($catrow["catname"])."</option>";
	}
	echo "</select>&nbsp; ";
	echo "<input class=\"snbutton\" type=\"submit\" value=\"$l_ok\">";
	echo "</td></tr></form></table>";
}
else
{
	if(!isset($newsnr))
	{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		echo "<tr class=\"errorrow\"><td align=\"center\">";
		echo $l_nonewsselected;
		echo "</td></tr>";
		echo "<tr class=\"actionrow\" align=\"center\"><td>";
		echo "<a href=\"javascript:history.back()\">$l_back</a>";
		echo "</td></tr>";
		echo"</table></td></tr></table>";
		include('./trailer.php');
		exit;
	}
	$layout_sql="select * from ".$tableprefix."_layout where lang='".$myrow["language"]."' and deflayout=1";
	if(!$layout_result = mysql_query($layout_sql, $db))
	    die("Unable to connect to database.".mysql_error());
	if(!$layoutrow=mysql_fetch_array($layout_result))
		die("Layout setup error");
	$dateformat=$layoutrow["dateformat"];
	$timestampfontcolor=$layoutrow["timestampfontcolor"];
	$timestampfontsize=$layoutrow["timestampfontsize"];
	$timestampfont=$layoutrow["timestampfont"];
	$timestampstyle=$layoutrow["timestampstyle"];
	$timestampbgcolor=$layoutrow["timestampbgcolor"];
	$globalheading=$layoutrow["heading"];
	$headingbgcolor=$layoutrow["headingbgcolor"];
	$headingfontcolor=$layoutrow["headingfontcolor"];
	$headingfont=$layoutrow["headingfont"];
	$headingfontsize=$layoutrow["headingfontsize"];
	$bordercolor=$layoutrow["bordercolor"];
	$contentbgcolor=$layoutrow["contentbgcolor"];
	$contentfontcolor=$layoutrow["contentfontcolor"];
	$contentfont=$layoutrow["contentfont"];
	$contentfontsize=$layoutrow["contentfontsize"];
	$TableWidth=$layoutrow["TableWidth"];
	$newsheadingbgcolor=$layoutrow["newsheadingbgcolor"];
	$newsheadingfontcolor=$layoutrow["newsheadingfontcolor"];
	$newsheadingstyle=$layoutrow["newsheadingstyle"];
	$newsheadingfont=$layoutrow["newsheadingfont"];
	$newsheadingfontsize=$layoutrow["newsheadingfontsize"];
	$displayposter=$layoutrow["displayposter"];
	$posterbgcolor=$layoutrow["posterbgcolor"];
	$posterfontcolor=$layoutrow["posterfontcolor"];
	$posterfont=$layoutrow["posterfont"];
	$posterfontsize=$layoutrow["posterfontsize"];
	$posterstyle=$layoutrow["posterstyle"];
	$copyrightbgcolor=$layoutrow["copyrightbgcolor"];
	$copyrightfontcolor=$layoutrow["copyrightfontcolor"];
	$copyrightfont=$layoutrow["copyrightfont"];
	$copyrightfontsize=$layoutrow["copyrightfontsize"];
	$attachpic=$layoutrow["attachpic"];
	$numnews=0;
	$asc_mailmsg="";
	$html_mailmsg="<table width=\"$TableWidth\" border=\"0\" CELLPADDING=\"1\" CELLSPACING=\"0\" ALIGN=\"CENTER\" VALIGN=\"TOP\">";
	$html_mailmsg.="<tr><TD BGCOLOR=\"$bordercolor\">";
	$html_mailmsg.="<TABLE BORDER=\"0\" CELLPADDING=\"1\" CELLSPACING=\"1\" WIDTH=\"100%\">";
	if(strlen($globalheading)>0)
	{
		$html_mailmsg.="<TR BGCOLOR=\"$headingbgcolor\" ALIGN=\"CENTER\">";
		$html_mailmsg.="<TD ALIGN=\"CENTER\" VALIGN=\"MIDDLE\"><font face=\"$headingfont\" size=\"$headingfontsize\" color=\"$headingfontcolor\"><b>$globalheading</b></font></td></tr>";
	}
	$mail = new html_mime_mail(array('X-Mailer: SimpNews v'.$version));
	$sql2="select * from ".$tableprefix."_data";
	$firstarg=true;
	while(list($null, $newsentry) = each($HTTP_POST_VARS["newsnr"]))
   	{
   		if($firstarg)
   		{
   			$firstarg=false;
			$sql2.= " where newsnr=$newsentry";
		}
		else
			$sql2.= " or newsnr=$newsentry";
	}
	if(!$result2 = mysql_query($sql2, $db))
	    die("Unable to connect to database.".mysql_error());
	while($myrow2=mysql_fetch_array($result2))
	{
		$numnews++;
		list($mydate,$mytime)=explode(" ",$myrow2["date"]);
		list($year, $month, $day) = explode("-", $mydate);
		list($hour, $min, $sec) = explode(":",$mytime);
		$temptime=mktime($hour,$min,$sec,$month,$day,$year);
		$temptime=$temptime-($servertimezone*60*60);
		$temptime=$temptime+($displaytimezone*60*60);
		$displaydate=date($dateformat,$temptime);
		$asc_mailmsg.="$displaydate:\r\n";
		$html_mailmsg.="<tr>";
		$html_mailmsg.="<td width=\"2%\" height=\"100%\" align=\"center\" bgcolor=\"$contentbgcolor\">";
		if($myrow2["headingicon"])
		{
			$html_mailmsg.="<img src=\"$url_icons/".$myrow2["headingicon"]."\" border=\"0\" align=\"middle\"> ";
		}
		else
			$html_mailmsg.="&nbsp;";
		$html_mailmsg.="</td>";
		$html_mailmsg.="<td  align=\"center\"><table width=\"100%\" align=\"center\" bgcolor=\"$contentbgcolor\" cellspacing=\"0\" cellpadding=\"0\">";
		$html_mailmsg.="<tr bgcolor=\"$timestampbgcolor\"><td align=\"left\">";
		$html_mailmsg.="<font face=\"$timestampfont\" size=\"$timestampfontsize\" color=\"$timestampfontcolor\">";
		$html_mailmsg.=get_start_tag($timestampstyle);
		$html_mailmsg.=$displaydate;
		$html_mailmsg.=get_end_tag($timestampstyle);
		$html_mailmsg.="</font></td></tr>";
		if(strlen($myrow2["heading"])>0)
		{
			$asc_heading=strip_tags($myrow2["heading"]);
			$asc_mailmsg.=$asc_heading;
			$asc_mailmsg.="\r\n";
			for($i=0;$i<strlen($asc_heading);$i++)
				$asc_mailmsg.="-";
			$asc_mailmsg.="\r\n";
			$html_mailmsg.="<tr bgcolor=\"$newsheadingbgcolor\"><td align=\"left\">";
			$html_mailmsg.="<font face=\"$newsheadingfont\" size=\"$newsheadingfontsize\" color=\"$newsheadingfontcolor\">";
			$html_mailmsg.=get_start_tag($newsheadingstyle);
			$html_mailmsg.=htmlentities(stripslashes($myrow2["heading"]));
			$html_mailmsg.=get_end_tag($newsheadingstyle);
			$html_mailmsg.="</font></td></tr>";
		}
		$html_mailmsg.="<tr bgcolor=\"$contentbgcolor\"><td align=\"left\">";
		$html_mailmsg.="<font face=\"$contentfont\" size=\"$contentfontsize\" color=\"$contentfontcolor\">";
		$html_news=stripslashes($myrow2["text"]);
		$html_news=undo_htmlspecialchars($html_news);
		$html_mailmsg.=$html_news."</font></td></tr>";
		$asc_newstext=str_replace("<BR>","\r\n",$html_news);
		$asc_newstext=undo_htmlentities($asc_newstext);
		$asc_newstext=strip_tags($asc_newstext);
		$asc_mailmsg.=$asc_newstext."\r\n";
		if($displayposter && (strlen($myrow2["poster"])>0))
		{
			$html_mailmsg.="<tr bgcolor=\"$posterbgcolor\"><td align=\"left\">";
			$html_mailmsg.="<font face=\"$posterfont\" size=\"$posterfontsize\" color=\"$posterfontcolor\">";
			$html_mailmsg.=get_start_tag($posterstyle);
			$html_mailmsg.="$l_poster: ".htmlentities($myrow2["poster"]);
			$html_mailmsg.=get_end_tag($posterstyle);
			$html_mailmsg.="</font></td></tr>";
		}
		$tempsql="select * from ".$tableprefix."_bindata where entrynr=".$myrow2["newsnr"];
		if(!$tempresult=mysql_query($tempsql,$db))
		    die("Unable to connect to database.".mysql_error());
		if($temprow=mysql_fetch_array($tempresult))
		{
			$html_mailmsg.="<tr bgcolor=\"$contentbgcolor\">";
			$html_mailmsg.="<td align=\"left\">";
			$html_mailmsg.="<font face=\"$contentfont\" size=\"$contentfontsize\" color=\"$contentfontcolor\">";
			$fileinfo=$temprow["filename"]." (".$temprow["filesize"]."Bytes)";
			$html_mailmsg.="&nbsp;<a href=\"".$simpnews_fullurl."sndownload.php?entrynr=".$myrow2["newsnr"]."\" target=\"_blank\"><img src=\"$attachpic\" border=\"0\" align=\"absmiddle\" title=\"$fileinfo\" alt=\"$fileinfo\"></a>&nbsp; ";
			$html_mailmsg.="<a href=\"".$simpnews_fullurl."sndownload.php?entrynr=".$myrow2["newsnr"]."\" target=\"_blank\">Download</a></font></td></tr>";
			$asc_mailmsg.= "Download attachement: ".$simpnews_fullurl."sndownload.php?entrynr=".$myrow2["newsnr"]."\r\n";
		}
		$asc_mailmsg.="\r\n";
		$html_mailmsg.="</table></td></tr>";
	}
	$html_mailmsg.="<TR BGCOLOR=\"$copyrightbgcolor\" ALIGN=\"CENTER\">";
	$html_mailmsg.="<TD ALIGN=\"CENTER\" VALIGN=\"MIDDLE\" colspan=\"2\"><font face=\"$copyrightfont\" size=\"$copyrightfontsize\" color=\"$copyrightfontcolor\">";
	$html_mailmsg.="Generated by $copyright_url, $copyright_note</td></tr>";
	$html_mailmsg.="</table></td></tr></table>";
	$html_mailmsg = str_replace($url_gfx."/","",$html_mailmsg);
	if($numnews>0)
	{
		$unsubscribeurl=$simpnews_fullurl."subscription.php?lang=".$myrow["language"]."&id=".$myrow["unsubscribeid"]."&mode=remove&email=".$myrow["email"];
		$unsubscribeurl_html="<font face=\"Verdana, Geneva, Arial, Helvetica, sans-serif\" size=\"1\"><a href=\"$unsubscribeurl\">$unsubscribeurl</a></font>";
		if($layoutrow["emailremark"])
			$html_remark=str_replace("{unsubscribeurl}",$unsubscribeurl_html,$layoutrow["emailremark"]);
		else
			$html_remark="unsubscribe: $unsubscribeurl_html";
		$html_remark=str_replace("\n","<br>",$html_remark);
		if($layoutrow["emailremark"])
			$asc_remark=str_replace("{unsubscribeurl}",$unsubscribeurl,strip_tags($layoutrow["emailremark"]));
		else
			$asc_remark="unsubscribe: $unsubscribeurl";
		$asc_remark=str_replace("\n","\r\n",$asc_remark);
		$userhtmlbody=$html_mailmsg;
		if(strlen($html_remark)>0)
			$userhtmlbody.="<hr>$html_remark<br><br>";
		$userhtmlbody.="---<BR>".str_replace("\n","<BR>",$layoutrow["defsignature"]);
		$userascbody=$asc_mailmsg;
		if(strlen($asc_remark)>0)
			$userascbody.="---------------------------\r\n$asc_remark\r\n\r\n";
		$userascbody.="---\r\n".str_replace("\n","\r\n",$layoutrow["defsignature"]);
		if($myrow["emailtype"]==0)
		{
			$mail->build_params['html_charset']=$contentcharset;
			$mail->build_params['text_charset']=$contentcharset;
    	    $mail->add_html($userhtmlbody, $userascbody);
			$mail->find_html_images($path_gfx."/");
    	}
    	else
    	{
			$mail->build_params['text_charset']=$contentcharset;
    		$mail->add_text($userascbody);
    	}
    	$mail->build_message();
		if($use_smtpmail)
		{
			if($simpnewsmailname)
				$smtpfrom="\"$simpnewsmailname\" <$simpnewsmail>";
			else
				$smtpfrom=$simpnewsmail;
			$mailparams = array(
				'host' => $smtpserver,
				'port' => $smtpport,
				'helo' => $smtpsenderdomain,
				'auth' => $smtpauth,
				'user' => $smtpuser,
				'pass' => $smtppasswd);
	        $smtp =& smtp::connect($mailparams);
			$send_params = array(
				'from'			=> $simpnewsmail,
				'recipients'	=> array($myrow["email"]),
				'headers'		=> array(
				'From: '.$smtpfrom,
				'To: '.$myrow["email"],
				'Subject: '.$subject));
	        $mail->smtp_send($smtp, $send_params);
		}
		else
	    	$mail->send("",$myrow["email"],$simpnewsmailname,$simpnewsmail,$subject);
    }
    $sql2="update ".$tableprefix."_subscriptions set lastmanual='$actdate' where subscriptionnr=$input_subscriptionnr";
	if(!$result2 = mysql_query($sql2, $db))
		die("Unable to connect to database.".mysql_error());
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="displayrow"><td align="center"><?php echo $l_emailssent?></td></tr>
<?php
echo"</table></td></tr></table>";
echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("subscribers?lang=$lang")."\">$l_subscribers</a></div>";
}
include('./trailer.php');
?>