# MySQL-Front Dump 1.22
#
# Host: localhost Database: news
#--------------------------------------------------------
# Server version 3.23.43-nt


#
# Table structure for table 'simpnews_banlist'
#

DROP TABLE /*!32200 IF EXISTS*/ simpnews_banlist;
CREATE TABLE /*!32300 IF NOT EXISTS*/ simpnews_banlist (
  bannr int(10) unsigned NOT NULL auto_increment,
  ipadr varchar(16) NOT NULL DEFAULT '0.0.0.0' ,
  subnetmask varchar(16) NOT NULL DEFAULT '0.0.0.0' ,
  reason text ,
  PRIMARY KEY (bannr)
);



#
# Table structure for table 'simpnews_bindata'
#

DROP TABLE /*!32200 IF EXISTS*/ simpnews_bindata;
CREATE TABLE /*!32300 IF NOT EXISTS*/ simpnews_bindata (
  entrynr int(10) unsigned NOT NULL DEFAULT '0' ,
  bindata longblob NOT NULL DEFAULT '' ,
  filename varchar(240) NOT NULL DEFAULT '' ,
  mimetype varchar(240) NOT NULL DEFAULT '' ,
  filesize int(10) NOT NULL DEFAULT '0' ,
  UNIQUE entrynr (entrynr)
);



#
# Table structure for table 'simpnews_categories'
#

DROP TABLE /*!32200 IF EXISTS*/ simpnews_categories;
CREATE TABLE /*!32300 IF NOT EXISTS*/ simpnews_categories (
  catnr int(10) unsigned NOT NULL auto_increment,
  catname varchar(40) NOT NULL DEFAULT '' ,
  PRIMARY KEY (catnr)
);



#
# Table structure for table 'simpnews_comments'
#

DROP TABLE /*!32200 IF EXISTS*/ simpnews_comments;
CREATE TABLE /*!32300 IF NOT EXISTS*/ simpnews_comments (
  commentnr int(10) unsigned NOT NULL auto_increment,
  poster varchar(80) NOT NULL DEFAULT '' ,
  email varchar(80) NOT NULL DEFAULT '' ,
  entryref int(10) unsigned NOT NULL DEFAULT '0' ,
  comment text NOT NULL DEFAULT '' ,
  enterdate datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,
  PRIMARY KEY (commentnr)
);



#
# Table structure for table 'simpnews_data'
#

DROP TABLE /*!32200 IF EXISTS*/ simpnews_data;
CREATE TABLE /*!32300 IF NOT EXISTS*/ simpnews_data (
  newsnr int(10) unsigned NOT NULL auto_increment,
  lang varchar(4) NOT NULL DEFAULT '' ,
  date datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,
  text text NOT NULL DEFAULT '' ,
  heading varchar(80) NOT NULL DEFAULT '' ,
  poster varchar(240) NOT NULL DEFAULT '' ,
  headingicon varchar(100) NOT NULL DEFAULT '' ,
  category int(10) unsigned NOT NULL DEFAULT '0' ,
  allowcomments tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  tickerurl varchar(240) NOT NULL DEFAULT '' ,
  PRIMARY KEY (newsnr)
);



#
# Table structure for table 'simpnews_emoticons'
#

DROP TABLE /*!32200 IF EXISTS*/ simpnews_emoticons;
CREATE TABLE /*!32300 IF NOT EXISTS*/ simpnews_emoticons (
  iconnr int(10) unsigned NOT NULL DEFAULT '0' ,
  code varchar(20) NOT NULL DEFAULT '' ,
  emoticon_url varchar(100) NOT NULL DEFAULT '' ,
  emotion varchar(80) NOT NULL DEFAULT '' ,
  PRIMARY KEY (iconnr)
);



#
# Table structure for table 'simpnews_events'
#

DROP TABLE /*!32200 IF EXISTS*/ simpnews_events;
CREATE TABLE /*!32300 IF NOT EXISTS*/ simpnews_events (
  eventnr int(10) unsigned NOT NULL auto_increment,
  date date NOT NULL DEFAULT '0000-00-00' ,
  lang varchar(4) NOT NULL DEFAULT '' ,
  poster varchar(240) NOT NULL DEFAULT '' ,
  category int(10) NOT NULL DEFAULT '0' ,
  heading varchar(80) NOT NULL DEFAULT '' ,
  headingicon varchar(240) NOT NULL DEFAULT '' ,
  text text NOT NULL DEFAULT '' ,
  added datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,
  PRIMARY KEY (eventnr)
);



#
# Table structure for table 'simpnews_failed_logins'
#

DROP TABLE /*!32200 IF EXISTS*/ simpnews_failed_logins;
CREATE TABLE /*!32300 IF NOT EXISTS*/ simpnews_failed_logins (
  loginnr int(10) unsigned NOT NULL auto_increment,
  username varchar(250) NOT NULL DEFAULT '0' ,
  ipadr varchar(16) NOT NULL DEFAULT '' ,
  logindate datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,
  usedpw varchar(240) NOT NULL DEFAULT '' ,
  PRIMARY KEY (loginnr)
);



#
# Table structure for table 'simpnews_failed_notify'
#

DROP TABLE /*!32200 IF EXISTS*/ simpnews_failed_notify;
CREATE TABLE /*!32300 IF NOT EXISTS*/ simpnews_failed_notify (
  usernr int(10) unsigned NOT NULL DEFAULT '0' 
);



#
# Table structure for table 'simpnews_freemailer'
#

DROP TABLE /*!32200 IF EXISTS*/ simpnews_freemailer;
CREATE TABLE /*!32300 IF NOT EXISTS*/ simpnews_freemailer (
  entrynr int(10) unsigned NOT NULL auto_increment,
  address varchar(100) NOT NULL DEFAULT '' ,
  PRIMARY KEY (entrynr)
);



#
# Table structure for table 'simpnews_hostcache'
#

DROP TABLE /*!32200 IF EXISTS*/ simpnews_hostcache;
CREATE TABLE /*!32300 IF NOT EXISTS*/ simpnews_hostcache (
  ipadr varchar(16) NOT NULL DEFAULT '0' ,
  hostname varchar(240) NOT NULL DEFAULT '' ,
  UNIQUE ipadr (ipadr)
);



#
# Table structure for table 'simpnews_icons'
#

DROP TABLE /*!32200 IF EXISTS*/ simpnews_icons;
CREATE TABLE /*!32300 IF NOT EXISTS*/ simpnews_icons (
  iconnr int(10) unsigned NOT NULL auto_increment,
  icon_url varchar(100) NOT NULL DEFAULT '' ,
  PRIMARY KEY (iconnr)
);



#
# Table structure for table 'simpnews_iplog'
#

DROP TABLE /*!32200 IF EXISTS*/ simpnews_iplog;
CREATE TABLE /*!32300 IF NOT EXISTS*/ simpnews_iplog (
  lognr int(10) unsigned NOT NULL auto_increment,
  usernr int(10) unsigned NOT NULL DEFAULT '0' ,
  logtime datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,
  ipadr varchar(16) NOT NULL DEFAULT '' ,
  used_lang varchar(4) NOT NULL DEFAULT '' ,
  PRIMARY KEY (lognr)
);



#
# Table structure for table 'simpnews_layout'
#

DROP TABLE /*!32200 IF EXISTS*/ simpnews_layout;
CREATE TABLE /*!32300 IF NOT EXISTS*/ simpnews_layout (
  lang varchar(4) NOT NULL DEFAULT '0' ,
  heading varchar(80) NOT NULL DEFAULT '' ,
  headingbgcolor varchar(7) NOT NULL DEFAULT '' ,
  headingfontcolor varchar(7) NOT NULL DEFAULT '' ,
  headingfont varchar(240) NOT NULL DEFAULT '' ,
  headingfontsize varchar(4) NOT NULL DEFAULT '' ,
  bordercolor varchar(7) NOT NULL DEFAULT '' ,
  contentbgcolor varchar(7) NOT NULL DEFAULT '' ,
  contentfontcolor varchar(7) NOT NULL DEFAULT '' ,
  contentfont varchar(240) NOT NULL DEFAULT '' ,
  contentfontsize varchar(4) NOT NULL DEFAULT '' ,
  TableWidth varchar(10) NOT NULL DEFAULT '' ,
  timestampfontcolor varchar(7) NOT NULL DEFAULT '' ,
  timestampfontsize varchar(4) NOT NULL DEFAULT '' ,
  timestampfont varchar(240) NOT NULL DEFAULT '' ,
  dateformat varchar(20) NOT NULL DEFAULT '' ,
  showcurrtime tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  customheader text NOT NULL DEFAULT '' ,
  pagebgcolor varchar(7) NOT NULL DEFAULT '' ,
  stylesheet varchar(80) NOT NULL DEFAULT '' ,
  newsheadingbgcolor varchar(7) NOT NULL DEFAULT '' ,
  newsheadingfontcolor varchar(7) NOT NULL DEFAULT '' ,
  newsheadingstyle tinyint(1) NOT NULL DEFAULT '0' ,
  posterbgcolor varchar(7) NOT NULL DEFAULT '' ,
  posterfontcolor varchar(7) NOT NULL DEFAULT '' ,
  posterstyle tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  displayposter tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  posterfont varchar(240) NOT NULL DEFAULT '' ,
  posterfontsize varchar(4) NOT NULL DEFAULT '' ,
  newsheadingfont varchar(240) NOT NULL DEFAULT '' ,
  newsheadingfontsize varchar(4) NOT NULL DEFAULT '' ,
  timestampbgcolor varchar(7) NOT NULL DEFAULT '' ,
  timestampstyle tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  displaysubscriptionbox tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  defsignature varchar(240) NOT NULL DEFAULT '' ,
  subscriptionbgcolor varchar(7) NOT NULL DEFAULT '' ,
  subscriptionfontcolor varchar(7) NOT NULL DEFAULT '' ,
  subscriptionfont varchar(240) NOT NULL DEFAULT '' ,
  subscriptionfontsize varchar(4) NOT NULL DEFAULT '' ,
  copyrightbgcolor varchar(7) NOT NULL DEFAULT '' ,
  copyrightfontcolor varchar(7) NOT NULL DEFAULT '' ,
  copyrightfont varchar(240) NOT NULL DEFAULT '' ,
  copyrightfontsize varchar(4) NOT NULL DEFAULT '' ,
  emailremark text NOT NULL DEFAULT '' ,
  layoutnr int(10) NOT NULL auto_increment,
  id varchar(10) NOT NULL DEFAULT '' ,
  deflayout tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  customfooter text NOT NULL DEFAULT '' ,
  searchpic varchar(240) NOT NULL DEFAULT 'search.gif' ,
  backpic varchar(240) NOT NULL DEFAULT 'back.gif' ,
  pagepic_back varchar(240) NOT NULL DEFAULT 'prev.gif' ,
  pagepic_first varchar(240) NOT NULL DEFAULT 'first.gif' ,
  pagepic_next varchar(240) NOT NULL DEFAULT 'next.gif' ,
  pagepic_last varchar(240) NOT NULL DEFAULT 'last.gif' ,
  pagetoppic varchar(240) NOT NULL DEFAULT 'pagetop.gif' ,
  newssignal_on varchar(240) NOT NULL DEFAULT 'blink.gif' ,
  newssignal_off varchar(240) NOT NULL DEFAULT 'off.gif' ,
  helppic varchar(240) NOT NULL DEFAULT 'help.gif' ,
  attachpic varchar(240) NOT NULL DEFAULT 'attach.gif' ,
  prevpic varchar(240) NOT NULL DEFAULT 'prev_big.gif' ,
  fwdpic varchar(240) NOT NULL DEFAULT 'next_big.gif' ,
  eventheading varchar(80) NOT NULL DEFAULT '' ,
  event_dateformat varchar(20) NOT NULL DEFAULT '' ,
  newstickerbgcolor varchar(7) NOT NULL DEFAULT '#cccccc' ,
  newstickerfontcolor varchar(7) NOT NULL DEFAULT '#000000' ,
  newstickerfont varchar(240) NOT NULL DEFAULT 'Verdana' ,
  newstickerfontsize tinyint(2) unsigned NOT NULL DEFAULT '12' ,
  newstickerhighlightcolor varchar(7) NOT NULL DEFAULT '#0000ff' ,
  newstickerheight int(10) unsigned NOT NULL DEFAULT '20' ,
  newstickerwidth int(10) unsigned NOT NULL DEFAULT '300' ,
  newstickerscrollspeed tinyint(2) unsigned NOT NULL DEFAULT '1' ,
  newstickerscrolldelay int(10) unsigned NOT NULL DEFAULT '30' ,
  newstickermaxdays int(10) NOT NULL DEFAULT '0' ,
  newstickermaxentries int(10) unsigned NOT NULL DEFAULT '0' ,
  newsscrollerbgcolor varchar(7) NOT NULL DEFAULT '#cccccc' ,
  newsscrollerfontcolor varchar(7) NOT NULL DEFAULT '#000000' ,
  newsscrollerfont varchar(240) NOT NULL DEFAULT 'Verdana' ,
  newsscrollerfontsize tinyint(2) unsigned NOT NULL DEFAULT '12' ,
  newsscrollerheight int(10) unsigned NOT NULL DEFAULT '300' ,
  newsscrollerwidth int(10) unsigned NOT NULL DEFAULT '200' ,
  newsscrollerscrollspeed tinyint(2) unsigned NOT NULL DEFAULT '1' ,
  newsscrollerscrolldelay int(10) unsigned NOT NULL DEFAULT '100' ,
  newsscrollerscrollpause int(10) unsigned NOT NULL DEFAULT '2000' ,
  newsscrollermaxdays int(10) NOT NULL DEFAULT '0' ,
  newsscrollermaxentries int(10) unsigned NOT NULL DEFAULT '0' ,
  newsscrollertype tinyint(4) unsigned NOT NULL DEFAULT '4' ,
  newsscrollerbgimage varchar(240) NOT NULL DEFAULT '' ,
  newsscrollerfgimage varchar(240) NOT NULL DEFAULT '' ,
  newsscrollermousestop tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  newsscrollermaxchars int(10) unsigned NOT NULL DEFAULT '0' ,
  newstickertarget varchar(80) NOT NULL DEFAULT '_self' ,
  newsscrollertarget varchar(80) NOT NULL DEFAULT '_self' ,
  newsscrollerxoffset tinyint(4) unsigned NOT NULL DEFAULT '0' ,
  newsscrolleryoffset tinyint(4) unsigned NOT NULL DEFAULT '0' ,
  newsscrollerwordwrap tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  newsscrollerdisplaydate tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  newsscrollerdateformat varchar(20) NOT NULL DEFAULT 'Y-m-d' ,
  newentrypic varchar(240) NOT NULL DEFAULT 'new.gif' ,
  newstypermaxentries int(10) unsigned NOT NULL DEFAULT '0' ,
  newstyperbgcolor varchar(7) NOT NULL DEFAULT '#cccccc' ,
  newstyperfontcolor varchar(7) NOT NULL DEFAULT '#000000' ,
  newstyperfont varchar(240) NOT NULL DEFAULT 'Verdana' ,
  newstyperfontsize tinyint(2) unsigned NOT NULL DEFAULT '12' ,
  newstyperfontstyle tinyint(2) unsigned NOT NULL DEFAULT '0' ,
  newstyperdisplaydate tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  newstyperdateformat varchar(20) NOT NULL DEFAULT 'Y-m-d' ,
  newstyperxoffset tinyint(4) unsigned NOT NULL DEFAULT '8' ,
  newstyperyoffset tinyint(4) unsigned NOT NULL DEFAULT '8' ,
  newstypermaxdays int(10) NOT NULL DEFAULT '0' ,
  newstypermaxchars int(10) unsigned NOT NULL DEFAULT '0' ,
  newstyperwidth int(10) unsigned NOT NULL DEFAULT '200' ,
  newstyperheight int(10) unsigned NOT NULL DEFAULT '300' ,
  newstyperbgimage varchar(240) NOT NULL DEFAULT '' ,
  newstyperscroll tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  newsscrollernolinking tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  newstyper2maxentries int(10) unsigned NOT NULL DEFAULT '0' ,
  newstyper2bgcolor varchar(7) NOT NULL DEFAULT '#cccccc' ,
  newstyper2fontcolor varchar(7) NOT NULL DEFAULT '#000000' ,
  newstyper2fontsize tinyint(2) unsigned NOT NULL DEFAULT '12' ,
  newstyper2displaydate tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  newstyper2newscreen tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  newstyper2waitentry tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  newstyper2dateformat varchar(20) NOT NULL DEFAULT 'Y-m-d' ,
  newstyper2indent tinyint(4) unsigned NOT NULL DEFAULT '8' ,
  newstyper2linespace tinyint(4) unsigned NOT NULL DEFAULT '15' ,
  newstyper2maxdays int(10) NOT NULL DEFAULT '-1' ,
  newstyper2maxchars int(10) unsigned NOT NULL DEFAULT '0' ,
  newstyper2width int(10) unsigned NOT NULL DEFAULT '300' ,
  newstyper2height int(10) unsigned NOT NULL DEFAULT '200' ,
  newstyper2bgimage varchar(240) NOT NULL DEFAULT '' ,
  newstyper2sound varchar(240) NOT NULL DEFAULT 'sfx/tick.au' ,
  newstyper2charpause int(10) unsigned NOT NULL DEFAULT '50' ,
  newstyper2linepause int(10) unsigned NOT NULL DEFAULT '500' ,
  newstyper2screenpause int(10) unsigned NOT NULL DEFAULT '5000' ,
  eventscrolleractdate tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  separatebylang tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  headerfile varchar(250) NOT NULL DEFAULT '' ,
  footerfile varchar(250) NOT NULL DEFAULT '' ,
  headerfilepos tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  footerfilepos tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  usecustomheader tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  usecustomfooter tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  copyrightpos tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  categorybgcolor varchar(7) NOT NULL DEFAULT '#999999' ,
  categoryfont varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,
  categoryfontsize varchar(4) NOT NULL DEFAULT '3' ,
  categoryfontcolor varchar(7) NOT NULL DEFAULT '#EEEEEE' ,
  categorystyle int(2) unsigned NOT NULL DEFAULT '0' ,
  hotnews2target varchar(240) NOT NULL DEFAULT '_self' ,
  news2target varchar(240) NOT NULL DEFAULT '_self' ,
  newsscrollermaxlines int(2) unsigned NOT NULL DEFAULT '20' ,
  linkcolor varchar(7) NOT NULL DEFAULT '#696969' ,
  vlinkcolor varchar(7) NOT NULL DEFAULT '#696969' ,
  alinkcolor varchar(7) NOT NULL DEFAULT '#696969' ,
  morelinkcolor varchar(7) NOT NULL DEFAULT '#191970' ,
  morevlinkcolor varchar(7) NOT NULL DEFAULT '#191970' ,
  morealinkcolor varchar(7) NOT NULL DEFAULT '#191970' ,
  catlinkcolor varchar(7) NOT NULL DEFAULT '#F0FFFF' ,
  catvlinkcolor varchar(7) NOT NULL DEFAULT '#F0FFFF' ,
  catalinkcolor varchar(7) NOT NULL DEFAULT '#F0FFFF' ,
  commentlinkcolor varchar(7) NOT NULL DEFAULT '#191970' ,
  commentvlinkcolor varchar(7) NOT NULL DEFAULT '#191970' ,
  commentalinkcolor varchar(7) NOT NULL DEFAULT '#191970' ,
  attachlinkcolor varchar(7) NOT NULL DEFAULT '#CD5C5C' ,
  attachvlinkcolor varchar(7) NOT NULL DEFAULT '#CD5C5C' ,
  attachalinkcolor varchar(7) NOT NULL DEFAULT '#CD5C5C' ,
  pagenavlinkcolor varchar(7) NOT NULL DEFAULT '#FFF0C0' ,
  pagenavvlinkcolor varchar(7) NOT NULL DEFAULT '#FFF0C0' ,
  pagenavalinkcolor varchar(7) NOT NULL DEFAULT '#FFF0C0' ,
  colorscrollbars tinyint(1) NOT NULL DEFAULT '1' ,
  sbfacecolor varchar(7) NOT NULL DEFAULT '#94AAD6' ,
  sbhighlightcolor varchar(7) NOT NULL DEFAULT '#AFEEEE' ,
  sbshadowcolor varchar(7) NOT NULL DEFAULT '#ADD8E6' ,
  sbdarkshadowcolor varchar(7) NOT NULL DEFAULT '#4682B4' ,
  sb3dlightcolor varchar(7) NOT NULL DEFAULT '#1E90FF' ,
  sbarrowcolor varchar(7) NOT NULL DEFAULT '#0000ff' ,
  sbtrackcolor varchar(7) NOT NULL DEFAULT '#E0FFFF' ,
  snsel_bgcolor varchar(7) NOT NULL DEFAULT '#DCDCDC' ,
  snsel_fontcolor varchar(7) NOT NULL DEFAULT '#000000' ,
  snsel_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,
  snsel_fontsize varchar(10) NOT NULL DEFAULT '10pt' ,
  snsel_fontstyle varchar(20) NOT NULL DEFAULT 'normal' ,
  snsel_fontweight varchar(20) NOT NULL DEFAULT 'normal' ,
  snsel_borderstyle varchar(20) NOT NULL DEFAULT 'none' ,
  snsel_bordercolor varchar(7) NOT NULL DEFAULT '' ,
  snsel_borderwidth varchar(20) NOT NULL DEFAULT '' ,
  morelinkfontsize varchar(20) NOT NULL DEFAULT '8pt' ,
  sninput_bgcolor varchar(7) NOT NULL DEFAULT '#DCDCDC' ,
  sninput_fontcolor varchar(7) NOT NULL DEFAULT '#000000' ,
  sninput_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,
  sninput_fontsize varchar(20) NOT NULL DEFAULT '10pt' ,
  sninput_fontstyle varchar(20) NOT NULL DEFAULT 'normal' ,
  sninput_fontweight varchar(20) NOT NULL DEFAULT 'normal' ,
  sninput_borderstyle varchar(20) NOT NULL DEFAULT 'solid' ,
  sninput_borderwidth varchar(20) NOT NULL DEFAULT 'thin' ,
  sninput_bordercolor varchar(7) NOT NULL DEFAULT '#696969' ,
  snisb_facecolor varchar(7) NOT NULL DEFAULT '#708090' ,
  snisb_highlightcolor varchar(7) NOT NULL DEFAULT '#A9A9A9' ,
  snisb_shadowcolor varchar(7) NOT NULL DEFAULT '#191970' ,
  snisb_darkshadowcolor varchar(7) NOT NULL DEFAULT '#000080' ,
  snisb_3dlightcolor varchar(7) NOT NULL DEFAULT '#F5FFFA' ,
  snisb_arrowcolor varchar(7) NOT NULL DEFAULT '#c0c0c0' ,
  snisb_trackcolor varchar(7) NOT NULL DEFAULT '#b0b0b0' ,
  snbutton_bgcolor varchar(7) NOT NULL DEFAULT '#94AAD6' ,
  snbutton_fontcolor varchar(7) NOT NULL DEFAULT '#FFFAF0' ,
  snbutton_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,
  snbutton_fontsize varchar(20) NOT NULL DEFAULT '7pt' ,
  snbutton_fontstyle varchar(20) NOT NULL DEFAULT 'normal' ,
  snbutton_fontweight varchar(20) NOT NULL DEFAULT 'normal' ,
  snbutton_borderstyle varchar(20) NOT NULL DEFAULT 'ridge' ,
  snbutton_borderwidth varchar(20) NOT NULL DEFAULT 'thin' ,
  snbutton_bordercolor varchar(7) NOT NULL DEFAULT '#483D8B' ,
  eventlinkcolor varchar(7) NOT NULL DEFAULT '#696969' ,
  eventalinkcolor varchar(7) NOT NULL DEFAULT '#696969' ,
  eventvlinkcolor varchar(7) NOT NULL DEFAULT '#696969' ,
  eventlinkfontsize varchar(20) NOT NULL DEFAULT '9pt' ,
  actionlinkcolor varchar(7) NOT NULL DEFAULT '#F0FFFF' ,
  actionvlinkcolor varchar(7) NOT NULL DEFAULT '#F0FFFF' ,
  actionalinkcolor varchar(7) NOT NULL DEFAULT '#F0FFFF' ,
  pagebgpic varchar(240) NOT NULL DEFAULT 'pagebg.gif' ,
  eventcalshortnews tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  eventcalshortlength int(10) unsigned NOT NULL DEFAULT '20' ,
  eventcalshortnum int(10) unsigned NOT NULL DEFAULT '3' ,
  eventcalshortonlyheadings tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  hotnewstarget varchar(80) NOT NULL DEFAULT '' ,
  hotnewsdisplayposter tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  hotnewsnohtmlformatting tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  hotnewsicons tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  ns4style varchar(80) NOT NULL DEFAULT 'simpnews_ns4.css' ,
  ns6style varchar(80) NOT NULL DEFAULT 'simpnews_ns6.css' ,
  operastyle varchar(80) NOT NULL DEFAULT 'simpnews_opera.css' ,
  geckostyle varchar(80) NOT NULL DEFAULT 'simpnews_gecko.css' ,
  konquerorstyle varchar(80) NOT NULL DEFAULT 'simpnews_konqueror.css' ,
  PRIMARY KEY (layoutnr)
);



#
# Table structure for table 'simpnews_misc'
#

DROP TABLE /*!32200 IF EXISTS*/ simpnews_misc;
CREATE TABLE /*!32300 IF NOT EXISTS*/ simpnews_misc (
  shutdown tinyint(3) unsigned NOT NULL DEFAULT '0' ,
  shutdowntext text 
);



#
# Table structure for table 'simpnews_search'
#

DROP TABLE /*!32200 IF EXISTS*/ simpnews_search;
CREATE TABLE /*!32300 IF NOT EXISTS*/ simpnews_search (
  newsnr int(10) unsigned NOT NULL DEFAULT '0' ,
  text text NOT NULL DEFAULT '' 
);



#
# Table structure for table 'simpnews_session'
#

DROP TABLE /*!32200 IF EXISTS*/ simpnews_session;
CREATE TABLE /*!32300 IF NOT EXISTS*/ simpnews_session (
  sessid int(10) unsigned NOT NULL DEFAULT '0' ,
  usernr int(10) NOT NULL DEFAULT '0' ,
  starttime int(10) unsigned NOT NULL DEFAULT '0' ,
  remoteip varchar(15) NOT NULL DEFAULT '' ,
  lastlogin datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,
  PRIMARY KEY (sessid),
  INDEX sess_id (sessid),
  INDEX start_time (starttime),
  INDEX remote_ip (remoteip)
);



#
# Table structure for table 'simpnews_settings'
#

DROP TABLE /*!32200 IF EXISTS*/ simpnews_settings;
CREATE TABLE /*!32300 IF NOT EXISTS*/ simpnews_settings (
  settingnr int(10) unsigned NOT NULL auto_increment,
  watchlogins tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  enablefailednotify tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  simpnewsmail varchar(180) NOT NULL DEFAULT '' ,
  loginlimit int(2) unsigned NOT NULL DEFAULT '0' ,
  usemenubar tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  nofreemailer tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  enablehostresolve tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  enablesubscriptions tinyint(1) NOT NULL DEFAULT '0' ,
  maxconfirmtime int(1) unsigned NOT NULL DEFAULT '2' ,
  subject varchar(80) NOT NULL DEFAULT '' ,
  subscriptionsendmode tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  subscriptionfreemailer tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  sitename varchar(80) NOT NULL DEFAULT '' ,
  maxage int(5) unsigned NOT NULL DEFAULT '0' ,
  entriesperpage int(2) unsigned NOT NULL DEFAULT '0' ,
  allowcomments tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  numhotnews tinyint(2) unsigned NOT NULL DEFAULT '5' ,
  enablesearch tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  newsnotifydays tinyint(2) unsigned NOT NULL DEFAULT '0' ,
  redirectdelay tinyint(2) NOT NULL DEFAULT '-1' ,
  newsineventcal tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  lastvisitcookie tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  servertimezone tinyint(3) NOT NULL DEFAULT '0' ,
  displaytimezone tinyint(3) NOT NULL DEFAULT '0' ,
  simpnewsmailname varchar(180) NOT NULL DEFAULT '' ,
  news2entries int(2) unsigned NOT NULL DEFAULT '5' ,
  hotnewsmaxchars int(10) NOT NULL DEFAULT '0' ,
  PRIMARY KEY (settingnr)
);



#
# Table structure for table 'simpnews_subscriptions'
#

DROP TABLE /*!32200 IF EXISTS*/ simpnews_subscriptions;
CREATE TABLE /*!32300 IF NOT EXISTS*/ simpnews_subscriptions (
  subscriptionnr int(10) unsigned NOT NULL auto_increment,
  email varchar(240) NOT NULL DEFAULT '' ,
  confirmed int(1) unsigned NOT NULL DEFAULT '0' ,
  language varchar(4) NOT NULL DEFAULT '' ,
  subscribeid int(10) unsigned NOT NULL DEFAULT '0' ,
  unsubscribeid int(10) unsigned NOT NULL DEFAULT '0' ,
  enterdate datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,
  lastsent datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,
  emailtype tinyint(1) unsigned NOT NULL DEFAULT '1' ,
  lastmanual datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,
  PRIMARY KEY (subscriptionnr)
);



#
# Table structure for table 'simpnews_users'
#

DROP TABLE /*!32200 IF EXISTS*/ simpnews_users;
CREATE TABLE /*!32300 IF NOT EXISTS*/ simpnews_users (
  usernr tinyint(3) unsigned NOT NULL auto_increment,
  username varchar(80) NOT NULL DEFAULT '' ,
  password varchar(40) binary NOT NULL DEFAULT '' ,
  email varchar(80) ,
  rights int(2) unsigned NOT NULL DEFAULT '0' ,
  lastlogin datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,
  lockpw tinyint(1) unsigned NOT NULL DEFAULT '0' ,
  realname varchar(240) NOT NULL DEFAULT '' ,
  autopin int(10) unsigned NOT NULL DEFAULT '0' ,
  PRIMARY KEY (usernr)
);

