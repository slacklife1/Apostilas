<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
require_once('./auth.php');
if(!isset($lang) || !$lang)
	$lang=$admin_lang;
include_once('./language/lang_'.$lang.'.php');
$page_title=$l_icons;
require_once('./heading.php');
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<?php
if(isset($mode))
{
	// Page called with some special mode
	if($mode=="new")
	{
		if($admin_rights < 2)
		{
			echo "<tr bgcolor=\"#cccccc\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
		// Display empty form for entering userdata
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr><td class="headingrow" align="center" colspan="2"><b><?php echo $l_addicon?></b></td></tr>
<form method="post" action="<?php echo $act_script_url?>"><input type="hidden" name="lang" value="<?php echo $lang?>">
<?php
	if(is_konqueror())
		echo "<tr><td></td></tr>";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_url?>:</td><td><input class="sninput" type="text" name="icon_url" size="40" maxlength="100">
<?php
if($upload_avail)
	echo "<input class=\"snbutton\" type=\"button\" value=\"$l_iconupload\" onClick=\"openWindow('".do_url_session("icon_upload.php?lang=$lang")."')\">";
else
	echo "<input class=\"snbutton\" type=\"button\" value=\"$l_choose\" onClick=\"openWindow('".do_url_session("icon_upload.php?lang=$lang")."')\">";
?>
</td></tr>
<tr class="actionrow"><td align="center" colspan="2"><input type="hidden" name="mode" value="add"><input class="snbutton" type="submit" value="<?php echo $l_add?>"></td></tr>
</form>
</table></td></tr></table>
<div class="bottombox" align="center"><a href="<?php echo do_url_session("$act_script_url?lang=$lang")?>"><?php echo $l_icons?></a></div>
<?php
	}
	if($mode=="add")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$errors=0;
		if(!$icon_url)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_nourl</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			$icon_url=addslashes($icon_url);
			$sql = "INSERT INTO ".$tableprefix."_icons (icon_url) ";
			$sql .="VALUES ('$icon_url')";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to add icon to database.");
			echo "<tr class=\"displayrow\" align=\"center\"><td>";
			echo "$l_iconadded";
			echo "</td></tr></table></td></tr></table>";
			echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?mode=new&lang=$lang")."\">$l_addicon</a></div>";
			echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?lang=$lang")."\">$l_icons</a></div>";
		}
		else
		{
			echo "<tr class=\"actionrow\" align=\"center\"><td>";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
	}
	if($mode=="delete")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$deleteSQL = "delete from ".$tableprefix."_icons where (iconnr=$input_iconnr)";
		$success = mysql_query($deleteSQL);
		if (!$success)
			die("<tr class=\"errorrow\"><td>$l_cantdelete.");
		echo "<tr class=\"displayrow\" align=\"center\"><td>";
		echo "$l_deleted<br>";
		echo "</td></tr></table></td></tr></table>";
		echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?lang=$lang")."\">$l_emoticons</a></div>";
	}
	if($mode=="edit")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?
		$sql = "select * from ".$tableprefix."_icons where (iconnr=$input_iconnr)";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td>Could not connect to the database.");
		if (!$myrow = mysql_fetch_array($result))
			die("<tr class=\"errorrow\"><td>no such entry");
?>
<tr class="headingrow"><td align="center" colspan="2"><b><?php echo $l_editicon?></b></td></tr>
<form method="post" action="<?php echo $act_script_url?>"><input type="hidden" name="lang" value="<?php echo $lang?>">
<?php
	if(is_konqueror())
		echo "<tr><td></td></tr>";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="input_iconnr" value="<?php echo $myrow["iconnr"]?>">
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_url?>:</td><td><input class="sninput" type="text" name="icon_url" size="40" maxlength="100" value="<?php echo htmlentities(stripslashes($myrow["icon_url"]))?>">
<?php
if($upload_avail)
	echo "<input class=\"snbutton\" type=\"button\" value=\"$l_iconupload\" onClick=\"openWindow('".do_url_session("icon_upload.php?lang=$lang")."')\">";
else
	echo "<input class=\"snbutton\" type=\"button\" value=\"$l_choose\" onClick=\"openWindow('".do_url_session("icon_upload.php?lang=$lang")."')\">";
?>
</td></tr>
<tr class="actionrow"><td align="center" colspan="2"><input type="hidden" name="mode" value="update"><input class="snbutton" type="submit" value="<?php echo $l_update?>"></td></tr>
</form>
</table></td></tr></table>
<div class="bottombox" align="center"><a href="<?php echo do_url_session("$act_script_url?lang=$lang")?>"><?php echo $l_icons?></a></div>
<?php
	}
	if($mode=="update")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$errors=0;
		if(!$icon_url)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_nourl</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			$icon_url=addslashes($icon_url);
			$sql = "UPDATE ".$tableprefix."_icons SET icon_url='$icon_url' ";
			$sql .="WHERE (iconnr = $input_iconnr)";
			if(!$result = mysql_query($sql, $db))
			    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.".mysql_error());
			echo "<tr class=\"displayrow\" align=\"center\"><td>";
			echo "$l_iconupdated";
			echo "</td></tr></table></td></tr></table>";
			echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?lang=$lang")."\">$l_icons</a></div>";
		}
		else
		{
			echo "<tr class=\"actionrow\"><td align=\"center\">";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
	}
}
else
{
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?
if($admin_rights>1)
{
?>
<tr class="actionrow"><td align="center" colspan="3">
<a href="<?php echo do_url_session("$act_script_url?mode=new&lang=$lang")?>"><?php echo $l_addicon?>
</td></tr>
<?
}
$sql = "select * from ".$tableprefix."_icons order by icon_url asc";
if(!$result = mysql_query($sql, $db)) {
    die("Could not connect to the database.");
}
if (!$myrow = mysql_fetch_array($result))
{
	echo "<tr bgcolor=\"#c0c0c0\"><td align=\"center\" colspan=\"3\">";
	echo $l_noentries;
	echo "</td></tr></table></td></tr></table>";
}
else
{
?>
<tr class="rowheadings">
<td align="center" width="10%"><b><?php echo $l_icon?></b></td>
<td align="center" width="10%"><b><?php echo $l_url?></b></td>
<td width="30%">&nbsp;</td></tr>
<?php
		do {
			$act_id=$myrow["iconnr"];
			echo "<tr class=\"displayrow\">";
			echo "<td align=\"center\"><img src=\"$url_icons/".$myrow["icon_url"]."\" border=\"0\"></td>";
			echo "<td align=\"center\">".htmlentities($myrow["icon_url"])."</td>";
			echo "<td>";
		if($admin_rights > 1)
		{
			echo "<a class=\"listlink\" href=\"".do_url_session("$act_script_url?mode=delete&input_iconnr=$act_id&lang=$lang")."\">";
			echo "$l_delete</a>";
			echo "&nbsp; ";
			echo "<a class=\"listlink\" href=\"".do_url_session("$act_script_url?mode=edit&lang=$lang&input_iconnr=$act_id")."\">";
			echo "$l_edit</a>";
		}
		echo "</td></tr>";
   } while($myrow = mysql_fetch_array($result));
   echo "</table></tr></td></table>";
}
if($admin_rights > 1)
{
?>
<div class="bottombox" align="center"><a href="<?php echo do_url_session("$act_script_url?mode=new&lang=$lang")?>"><?php echo $l_addicon?></a></div>
<?php
}
}
include('./trailer.php');
?>