<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
if(!isset($bbcbuttons))
	$bbcbuttons=false;
if(!$testmode)
{
	$stop_now=0;
	$stopmsg="";
	if(file_exists("mkconfig.php"))
	{
		$stop_now=1;
		$msg=str_replace("{file}","mkconfig.php",$l_remove_file);
		$stopmsg.="<li>$msg";
	}
	if(file_exists("fill_emoticons.php"))
	{
		$stop_now=1;
		$msg=str_replace("{file}","fill_emoticons.php",$l_remove_file);
		$stopmsg.="<li>$msg";
	}
	if(file_exists("fill_icons.php"))
	{
		$stop_now=1;
		$msg=str_replace("{file}","fill_icons.php",$l_remove_file);
		$stopmsg.="<li>$msg";
	}
	if(file_exists("fill_freemailer.php"))
	{
		$stop_now=1;
		$msg=str_replace("{file}","fill_freemailer.php",$l_remove_file);
		$stopmsg.="<li>$msg";
	}
	if(file_exists("install.php"))
	{
		$stop_now=1;
		$msg=str_replace("{file}","install.php",$l_remove_file);
		$stopmsg.="<li>$msg";
	}
	$dir = opendir("./");
	while ($file = readdir($dir))
	{
		if (ereg("^upgrade_", $file))
		{
			$stop_now=1;
			$msg=str_replace("{file}",$file,$l_remove_file);
			$stopmsg.="<li>$msg";
		}
	}
	if(@fopen("../config.php", "a"))
	{
		$stop_now=1;
		$stopmsg.="<li>$l_config_writeable";
	}
	if($stop_now==1)
		die("<ul>".$stopmsg."</ul>");
}
require_once('../functions.php');
require_once('./functions.php');
header('Pragma: no-cache');
header('Expires: 0');
$redirect="index.php?lang=$lang";		// Page to redirect after login
$user_loggedin=0;
$url_sessid=0;
$userdata = Array();
$banreason="";
if(isset($do_login))
{
	$myusername=addslashes(strtolower($username));
	$result=do_login($myusername,$userpw,$db);
	if($result==22)
	{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//en">
<html>
<head>
<title>SimpNews - Administration</title>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<?php
		if(is_ns4())
			echo "<link rel=stylesheet href=./snadm_ns4.css type=text/css>\n";
		else if(is_ns6())
			echo "<link rel=stylesheet href=./snadm_ns6.css type=text/css>\n";
		else if(is_opera())
			echo "<link rel=stylesheet href=./snadm_opera.css type=text/css>\n";
		else if(is_konqueror())
			echo "<link rel=stylesheet href=./snadm_konqueror.css type=text/css>\n";
		else if(is_gecko())
			echo "<link rel=stylesheet href=./snadm_gecko.css type=text/css>\n";
		else
			echo "<link rel=stylesheet href=./snadm.css type=text/css>\n";
?>
</head>
<body>
<table width="80%" align="CENTER" calign="MIDDLE" border="0" cellspacing="0" cellpadding="0">
<tr><td align="CENTER" class="prognamerow"><h1>SimpNews v<?php echo $version?></h1></td></tr>
<tr><td align="CENTER" class="pagetitlerow"><h2><?php echo $page_title?></h2></td></tr>
</table>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="displayrow"><td colspan="2" align="center"><?php echo $l_too_many_users?></td></tr>
</table></td></tr></table></body></html>
<?
		exit;
	}
	if($result==-99)
	{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//en">
<html>
<head>
<title>SimpNews - Administration</title>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<?php
if(is_ns4())
	echo "<link rel=stylesheet href=./snadm_ns4.css type=text/css>\n";
else if(is_ns6())
	echo "<link rel=stylesheet href=./snadm_ns6.css type=text/css>\n";
else if(is_opera())
	echo "<link rel=stylesheet href=./snadm_opera.css type=text/css>\n";
else if(is_konqueror())
	echo "<link rel=stylesheet href=./snadm_konqueror.css type=text/css>\n";
else if(is_gecko())
	echo "<link rel=stylesheet href=./snadm_gecko.css type=text/css>\n";
else
	echo "<link rel=stylesheet href=./snadm.css type=text/css>\n";
?>
</head>
<body>
<table width="80%" align="CENTER" calign="MIDDLE" border="0" cellspacing="0" cellpadding="0">
<tr><td align="CENTER" class="prognamerow"><h1>SimpNews v<?php echo $version?></h1></td></tr>
<tr><td align="CENTER" class="pagetitlerow"><h2><?php echo $page_title?></h2></td></tr>
</table>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="displayrow"><td colspan="2" align="center"><b><?php echo $l_ipbanned?></b></td></tr>
<tr class="displayrow"><td align="right" width="20%"><?php echo $l_reason?>:</td>
<td align="left" width="80%"><?php echo $banreason?></td></tr>
</table></td></tr></table></body></html>
<?php
		exit;
	}
	if(($result!=1) && ($result!=4711))
	{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//en">
<html>
<head>
<title>SimpNews - <?php echo $l_loginpage?></title>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<?php
if(is_ns4())
	echo "<link rel=stylesheet href=./snadm_ns4.css type=text/css>\n";
else if(is_ns6())
	echo "<link rel=stylesheet href=./snadm_ns6.css type=text/css>\n";
else if(is_opera())
	echo "<link rel=stylesheet href=./snadm_opera.css type=text/css>\n";
else if(is_konqueror())
	echo "<link rel=stylesheet href=./snadm_konqueror.css type=text/css>\n";
else if(is_gecko())
	echo "<link rel=stylesheet href=./snadm_gecko.css type=text/css>\n";
else
	echo "<link rel=stylesheet href=./snadm.css type=text/css>\n";
?>
</head>
<body>
<table width="80%" align="CENTER" calign="MIDDLE" border="0" cellspacing="0" cellpadding="0">
<tr><td align="CENTER" class="prognamerow"><h1>SimpNews v<?php echo $version?></h1></td></tr>
<tr><td align="CENTER" class="pagetitlerow"><h2><?php echo $page_title?></h2></td></tr>
</table>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="errorrow"><td align="center" colspan="2">
<?php echo $l_loginerror?></td></tr>
<tr class="inputrow"><form method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="lang" value="<?php echo $lang?>">
<td align="right" width="30%"><?php echo $l_username?>:</td><td><input class="sninput" type="text" name="username" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_password?>:</td><td><input class="sninput" type="password" name="userpw" size="40" maxlength="40"></td></tr>
<tr class="actionrow"><td align="center" colspan="2"><input class="snbutton" type="submit" name="do_login" value="<?php echo $l_login?>"></td></tr>
<?php
if($enablerecoverpw && !$enable_htaccess)
{
?>
<tr class="actionrow"><td align="center" colspan="2"><a href="pwlost.php?<?php echo "lang=$lang"?>"><?php echo $l_pwlost?></td></tr>
<?
}
?>
</form></table></td></tr></table>
<?php
	echo "<hr><div class=\"copyright\" align=\"center\">$copyright_url $copyright_note</div>";
	exit;
	}
	else
	{
		if($result==4711)
			$redirect="changepw.php?lang=$lang";
		if($sessid_url)
			$redirect=do_url_session($redirect);
		echo "<META HTTP-EQUIV=\"refresh\" content=\"0.01; URL=$redirect\">";
		exit;
	}
}
if($enable_htaccess)
{
	if(isbanned(get_userip(),$db))
	{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//en">
<html>
<head>
<title>SimpNews - Administration</title>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<?php
if(is_ns4())
	echo "<link rel=stylesheet href=./snadm_ns4.css type=text/css>\n";
else if(is_ns6())
	echo "<link rel=stylesheet href=./snadm_ns6.css type=text/css>\n";
else if(is_opera())
	echo "<link rel=stylesheet href=./snadm_opera.css type=text/css>\n";
else if(is_konqueror())
	echo "<link rel=stylesheet href=./snadm_konqueror.css type=text/css>\n";
else if(is_gecko())
	echo "<link rel=stylesheet href=./snadm_gecko.css type=text/css>\n";
else
	echo "<link rel=stylesheet href=./snadm.css type=text/css>\n";
?>
</head>
<body>
<table width="80%" align="CENTER" calign="MIDDLE" border="0" cellspacing="0" cellpadding="0">
<tr><td align="CENTER" class="prognamerow"><h1>SimpNews v<?php echo $version?></h1></td></tr>
<tr><td align="CENTER" class="pagetitlerow"><h2><?php echo $page_title?></h2></td></tr>
</table>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="displayrow"><td colspan="2" align="center"><b><?php echo $l_ipbanned?></b></td></tr>
<tr class="displayrow"><td align="right" width="20%"><?php echo $l_reason?>:</td>
<td align="left" width="80%"><?php echo $banreason?></td></tr>
</table></td></tr></table></body></html>
<?php
		exit;
	}
	$username=$REMOTE_USER;
	$myusername=addslashes(strtolower($username));
	$sql = "select * from ".$tableprefix."_users where username='$myusername'";
	if(!$result = mysql_query($sql, $db))
	    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database");
	if (!$myrow = mysql_fetch_array($result))
	{
	    die("<tr bgcolor=\"#cccccc\"><td>User not defined for SimpNews");
	}
	$userid=$myrow["usernr"];
	$user_loggedin=1;
    $userdata = get_userdata_by_id($userid, $db);
}
else if($sessid_url)
{
	if(isset($$sesscookiename))
	{
		$url_sessid=$$sesscookiename;
		$userid = get_userid_from_session($url_sessid, $sesscookietime, $REMOTE_ADDR, $db);
		if ($userid)
		{
		   $user_loggedin = 1;
		   update_session($url_sessid, $db);
		   $userdata = get_userdata_by_id($userid, $db);
		   $userdata["lastlogin"]=get_lastlogin_from_session($url_sessid, $sesscookietime, $REMOTE_ADDR, $db);
		}
	}
}
else if(isset($HTTP_COOKIE_VARS[$sesscookiename])) {
	$sessid = $HTTP_COOKIE_VARS[$sesscookiename];
	$userid = get_userid_from_session($sessid, $sesscookietime, $REMOTE_ADDR, $db);
	if ($userid) {
	   $user_loggedin = 1;
	   update_session($sessid, $db);
	   $userdata = get_userdata_by_id($userid, $db);
	   $userdata["lastlogin"]=get_lastlogin_from_session($sessid, $sesscookietime, $REMOTE_ADDR, $db);
	}
}
if($user_loggedin==0)
	$page_title=$l_loginpage;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//en">
<html>
<head>
<title>SimpNews - <?php echo $page_title?></title>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $contentcharset?>">
<?php
if(is_ns4())
	echo "<link rel=stylesheet href=./snadm_ns4.css type=text/css>\n";
else if(is_ns6())
	echo "<link rel=stylesheet href=./snadm_ns6.css type=text/css>\n";
else if(is_opera())
	echo "<link rel=stylesheet href=./snadm_opera.css type=text/css>\n";
else if(is_konqueror())
	echo "<link rel=stylesheet href=./snadm_konqueror.css type=text/css>\n";
else if(is_gecko())
	echo "<link rel=stylesheet href=./snadm_gecko.css type=text/css>\n";
else
	echo "<link rel=stylesheet href=./snadm.css type=text/css>\n";
if($user_loggedin!=0)
{
	include_once("menus.php");
?>
<script type="text/javascript" language="javascript">
var windowX = 20 // from left
var windowY = 20 // from top
var autoclose = true
var beIE = document.all?true:false

function openFrameless(urlPop,title,width,height){
	s = "width="+width+",height="+height;
	if (beIE){
		NFW = window.open("","popFrameless","fullscreen,"+s)
		NFW.blur()
		window.focus()
		NFW.resizeTo(width,height)
		NFW.moveTo(windowX,windowY)
		var frameString=""+
"<html>"+
"<head>"+
"<title>"+title+"</title>"+
"</head>"+
"<frameset rows='*,0' framespacing=0 border=0 frameborder=0>"+
"<frame name='top' src='"+urlPop+"' scrolling=auto>"+
"<frame name='bottom' src='about:blank' scrolling='no'>"+
"</frameset>"+
"</html>"
		NFW.document.open();
		NFW.document.write(frameString)
		NFW.document.close()
	} else {
		NFW=window.open(urlPop,"popFrameless","scrollbars,"+s)
		NFW.blur()
		window.focus()
		NFW.resizeTo(width,height)
		NFW.moveTo(windowX,windowY)
	}
	NFW.focus()
	if (autoclose){
		window.onunload = function(){NFW.close()}
	}
}
</script>
<?php
	if(!is_opera() && !is_ns4() && !is_gecko() && !is_msie())
	{
?>
<script type="text/javascript" language="javascript">
// constants
var initX       = 110; // x-coordinate of top left corner of dropdown menu
var initY       = 93; // y-coordinate of top left corner of dropdown menu
var backColor   = ''; // the background color of dropdown menu, set empty '' for transparent
var borderColor = 'black'; // the color of dropdown menu border
var borderSize  = '1'; // the width of dropdown menu border
var itemHeight  = 20;
var xOverlap    = 5;
var yOverlap    = 10;
//

// Don't change these parameters
var delay        = 500; /////
var menuElement  = new Array ();
var usedWidth    = 0;
var numOfMenus   = 0;
/// ----------------------------

var menuContent     = new Array ();

<?php
		for($i=0;$i<count($l_menus);$i++)
		{
			echo "menuContent [$i] = new Array (\n";
			echo "-1, // the id of parent menu, -1 if this is a first level menu\n";
			echo "-1, // the number of line in parent menu, -1 if this is a first level menu\n";
			echo "125, // the width of current menu list\n";
			echo "-1, // x coordinate (absolute) of left corner of this menu list, -1 if the coordinate is defined from parent x-coordinate\n";
			echo "-1, // y coordinate (absolute) of left corner of this menu list, -1 if the coordinate is defined from parent y-coordinate\n";
			echo "new Array (";
			for($j=1;$j<count($l_menus[$i]);$j++)
			{
				if($l_menus[$i][$j]["level"]<=$userdata["rights"])
				{
					if($j>1)
						echo ",\n";
					echo "'".$l_menus[$i][$j]["entry"]."', '".do_url_session($l_menus[$i][$j]["url"])."'";
				}
			}
			echo "\n));\n";
		}
?>
</script>
<script language=JavaScript src=./menu.js></script>
<?php
}
else
{
?>
<script language="JavaScript1.2" src="coolmenus4.js">
/*****************************************************************************
This site uses the coolMenus. You can get it for your own site by
going to http://www.dhtmlcentral.com/projects/coolmenus
******************************************************************************/
</script>
<?php
			echo "<script type=\"text/JavaScript\" language=\"JavaScript\">\n";
			echo "function findPos(num)\n";
			echo "{\n";
			echo "	if(bw.ns4)\n";
			echo "	{	//Netscape 4\n";
			echo "		x = document.layers[\"layerMenu\"+num].pageX;\n";
    		echo "		y = document.layers[\"layerMenu\"+num].pageY;\n";
			echo "	}\n";
			echo "	else\n";
			echo "	{	//other browsers\n";
			echo "		x=0;\n";
			echo "		y=0;\n";
			echo "		var el,temp;\n";
    		echo "		el = bw.ie4?document.all[\"divMenu\"+num]:document.getElementById(\"divMenu\"+num);\n";
    		echo "		if(el.offsetParent)\n";
    		echo "		{\n";
			echo "			temp = el;\n";
			echo "			while(temp.offsetParent)\n";
			echo "			{	//Looping parent elements to get the offset of them as well\n";
			echo "				temp=temp.offsetParent;\n";
			echo "				x+=temp.offsetLeft;\n";
			echo "				y+=temp.offsetTop;\n";
			echo "			}\n";
			echo "		}\n";
			echo "		x+=el.offsetLeft;\n";
			echo "		y+=el.offsetTop;\n";
			echo "	}\n";
			echo "	//Returning the x and y as an array\n";
			echo "	return [x,y];\n";
			echo "}\n";
			echo "function placeElements(){\n";
			for($i=0;$i<count($l_menus);$i++)
			{
				if($l_menus[$i][0]["level"]<=$userdata["rights"])
				{
		  			echo "	pos = findPos($i);\n";
		  			echo "	oCMenu.m[\"top$i\"].b.moveIt(pos[0],pos[1]);\n";
				}
			}
		  	echo "	oCMenu.fromTop = pos[1];\n";
			echo "}\n";
			echo "</script>\n";
}
if($bbcbuttons)
	include_once("./includes/bbcode_js.inc");
?>
<script type="text/javascript" language="javascript">
<!--
function settings_maxconfirmtime()
{
	if(document.settingsform.nosubscriptionconfirm.checked == true)
		document.settingsform.maxconfirmtime.disabled=true;
	else
	{
		document.settingsform.maxconfirmtime.disabled=false;
		document.settingsform.maxconfirmtime.focus();
	}
	return;
}
//-->
</script>
<script type="text/javascript" language="javascript">
function checkAll(myform)
{
	for (i = 0; i < myform.length; i++)
		if( myform.elements[i].type == 'checkbox')
			myform.elements[i].checked = true;
}

function uncheckAll(myform)
{
	for (i = 0; i < myform.length; i++)
		if( myform.elements[i].type == 'checkbox' )
			myform.elements[i].checked = false;
}
</script>
<script type="text/javascript" language="javascript">
function color_picker(fieldname)
{
	document.layoutform.colorfield.value=fieldname;
	openFrameless('colorwheel.php?lang=<?php echo $lang?>','Colors',450,400);
}
function color_chooser(fieldname)
{
	document.layoutform.colorfield.value=fieldname;
	openFrameless('colorchooser.php?lang=<?php echo $lang?>','Colors',450,400);
}
function setcolor(colorcode)
{
	eval('document.layoutform.' + document.layoutform.colorfield.value + '.value=\'' + colorcode + '\'');
	eval(document.layoutform.colorfield.value + 'prev.bgColor=\'' + colorcode + '\'');
}
function color_prev(fieldname)
{
	eval('colorcode=document.layoutform.'+fieldname+'.value');
<?php
	if(is_ns6())
	{
		echo "prevfield=document.getElementById(fieldname+'prev');\n";
		echo "prevfield.bgColor=colorcode;\n";
	}
	else
	{
		echo "eval(fieldname + 'prev.bgColor=' + '\''+colorcode+'\'');\n";

	}
?>
	return;
}
</script>
<?php
echo "\n".'<script language="javascript">'."\nfunction openWindow(loc) {\n".'   openWin = window.open(loc,"myWindow","top=20,left=100,width=500,height=450,buttons=no,scrollbars=yes,location=no,menubar=no,resizable=yes,status=no,directories=no,toolbar=no");'."\n   openWin.focus();\n"."}\n</script>\n";
}
?>
</head>
<body>
<table width="80%" align="CENTER" calign="MIDDLE" border="0" cellspacing="0" cellpadding="0">
<tr><td align="CENTER" class="prognamerow"><h1>SimpNews v<?php echo $version?></h1></td></tr>
<tr><td align="CENTER" class="pagetitlerow"><h2><?php echo $page_title?></h2></td></tr>
</table>
<?php
if($user_loggedin==0)
{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="displayrow"><td align="center" colspan="2">
<?php echo $l_notloggedin?></td></tr>
<tr class="inputrow"><form method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="lang" value="<?php echo $lang?>">
<td align="right" width="30%"><?php echo $l_username?>:</td><td><input class="sninput" type="text" name="username" size="40" maxlength="80"></td></tr>
<tr class="inputrow"><td align="right"><?php echo $l_password?>:</td><td><input class="sninput" type="password" name="userpw" size="40" maxlength="40"></td></tr>
<tr class="actionrow"><td align="center" colspan="2"><input class="snbutton" type="submit" name="do_login" value="<?php echo $l_login?>"></td></tr>
<?php
if($enablerecoverpw && !$enable_htaccess)
{
?>
<tr class="actionrow"><td align="center" colspan="2"><a href="pwlost.php?<?php echo "lang=$lang"?>"><?php echo $l_pwlost?></td></tr>
<?php
}
?>
</form></table></td></tr></table>
<?php
	echo "<hr><div class=\"copyright\" align=\"center\">$copyright_url $copyright_note</div>";
	exit;
}
else
{
	$sql = "select * from ".$tableprefix."_settings where (settingnr=1)";
	if(!$result = mysql_query($sql, $db)) {
	    die("Could not connect to the database.");
	}
	if ($myrow = mysql_fetch_array($result))
	{
		$usemenubar=$myrow["usemenubar"];
		$servertimezone=$myrow["servertimezone"];
		$displaytimezone=$myrow["displaytimezone"];
	}
	$shutdown=0;
	$act_usernr=$userdata["usernr"];
	$admin_rights=$userdata["rights"];
	if($admin_rights==0)
	{
		die("$l_functionnotallowed");
	}
	$sql = "select * from ".$tableprefix."_misc";
	if(!$result = mysql_query($sql, $db)) {
		die("Could not connect to the database (faq_misc).");
	}
	if ($temprow = mysql_fetch_array($result))
	{
		if(($temprow["shutdown"]>0) && ($admin_rights<3))
		{
			echo "<div align=\"center\">";
			$shutdowntext=stripslashes($temprow["shutdowntext"]);
			$shutdowntext = undo_htmlspecialchars($shutdowntext);
			echo $shutdowntext;
			echo "</div>";
			$shutdown=1;
			include('./trailer.php');
			exit;
		}
	}
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
	$nummenucols=0;
	if($usemenubar==1)
	{
		if(!is_opera() && !is_ns4() && !is_gecko() && !is_msie())
		{
			echo "<tr class=\"menurow\">";
			for($i=0;$i<count($l_menus);$i++)
			{
				if($l_menus[$i][0]["level"]<=$userdata["rights"])
				{
					echo "<td align=\"center\" valign=\"middle\" width=\"90\" height=\"20\">";
					echo "<a href=\"".do_url_session($l_menus[$i][0]["url"])."\" ";
					echo "onMouseOver = \"enterTopItem ($i);\" onMouseOut = \"exitTopItem ($i);\" class=\"topMenu\">".$l_menus[$i][0]["entry"]."</a></td>";
					$nummenucols++;
				}
			}
		}
		else
		{
			echo "<tr class=\"menurow\">";
			for($i=0;$i<count($l_menus);$i++)
			{
				if($l_menus[$i][0]["level"]<=$userdata["rights"])
				{
  					echo "<td width=\"15%\">";
  					echo "<ilayer id=\"layerMenu$i\"><div id=\"divMenu$i\">";
    				echo "<img src=\"gfx/space.gif\" width=\"6\" height=\"25\" alt=\"\" border=\"0\">";
  					echo "</div></ilayer></td>";
  					$nummenucols++;
  				}
			}
			for($j=$nummenucols;$j<count($l_menus);$j++)
			{
				echo "<td width=\"15%\">";
   				echo "<img src=\"gfx/space.gif\" width=\"6\" height=\"25\" alt=\"\" border=\"0\">";
   				echo "</td>";
   			}
		}
		echo "</tr>";
	}
	if(($userdata["rights"]>2)||($shutdown<1))
	{
		echo "<tr class=\"actionrow\"><td align=\"center\"";
		if($nummenucols>0)
			echo " colspan=\"".count($l_menus)."\"";
		echo ">";
		echo "<a href=\"".do_url_session("index.php?lang=$lang")."\">$l_mainmenu</a>";
		echo "</td></tr>";
	}
	echo "</table></td></tr></table>";
}
?>
