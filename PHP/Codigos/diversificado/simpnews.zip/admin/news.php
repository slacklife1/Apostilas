<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
if(!isset($lang) || !$lang)
	$lang=$admin_lang;
include_once('./language/lang_'.$lang.'.php');
if(!isset($newslang))
	$newslang=$lang;
require_once('./auth.php');
$page_title=$l_news;
$bbcbuttons=true;
require_once('./heading.php');
include_once("./includes/bbcode_buttons.inc");
$headingtext="";
if(!isset($catnr))
	$catnr=0;
$allowcomments=1;
$hasattach=0;
$errmsg="";
$sql = "select * from ".$tableprefix."_settings where (settingnr=1)";
if(!$result = mysql_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = mysql_fetch_array($result))
{
	$subscriptionsendmode=$myrow["subscriptionsendmode"];
	$enablesubscriptions=$myrow["enablesubscriptions"];
	$subject=$myrow["subject"];
	$simpnewsmail=$myrow["simpnewsmail"];
	$simpnewsmailname=$myrow["simpnewsmailname"];
}
else
{
	$subscriptionsendmode=0;
	$enablesubscriptions=0;
	$subject="News";
	$simpnewsmail="simpnews@foo.bar";
	$simpnewsmailname="SimpNews";
}
if(isset($mode) && ($admin_rights>1))
{
	if($mode=="add")
	{
		if(!isset($headingicon))
			$headingicon="";
		$newstext=trim($newstext);
		if(isset($newstext) && $newstext)
		{
			if($upload_avail && is_uploaded_file($HTTP_POST_FILES['uploadfile']['tmp_name']))
			{
				$filename=$HTTP_POST_FILES['uploadfile']['name'];
				$filesize=$HTTP_POST_FILES['uploadfile']['size'];
				if(($filesize>0) && ($filesize<$maxfilesize))
				{
					if(isset($path_tempdir) && $path_tempdir)
					{
						if(!move_uploaded_file ($uploadfile, $path_tempdir."/".$filename))
							die("unable to move uploaded file to $path_tempdir");
						$orgfile=$path_tempdir."/".$filename;
					}
					else
						$orgfile=$uploadfile;
					if(!$attach_in_fs)
					{
						$filedata = addslashes(get_file($orgfile));
						$filetype=$HTTP_POST_FILES['uploadfile']['type'];
					}
					else
						copy ($orgfile,$path_attach."/".$filename);
					if(isset($path_tempdir) && $path_tempdir)
					{
						unlink($path_tempdir."/".$filename);
					}
				}
				else
				{
					unset($filename);
					unset($filedata);
				}
			}
			if(isset($preview))
			{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<form method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="lang" value="<?php echo $lang?>">
<?php
	if(is_konqueror())
		echo "<tr><td></td></tr>";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
	if(isset($enablecomments))
		echo "<input type=\"hidden\" name=\"enablecomments\" value=\"1\">";
	if(isset($urlautoencode))
		echo "<input type=\"hidden\" name=\"urlautoencode\" value=\"1\">";
	if(isset($enablespcode))
		echo "<input type=\"hidden\" name=\"enablespcode\" value=\"1\">";
?>
<input type="hidden" name="newslang" value="<?php echo $newslang?>">
<input type="hidden" name="catnr" value="<?php echo $catnr?>">
<input type="hidden" name="newstext" value="<?php echo htmlentities($newstext)?>">
<input type="hidden" name="heading" value="<?php echo htmlentities($heading)?>">
<input type="hidden" name="headingicon" value="<?php echo $headingicon?>">
<input type="hidden" name="mode" value="add">
<input type="hidden" name="tickerurl" value="<?php echo $tickerurl?>">
<tr class="inforow"><td align="center" colspan="2"><?php echo $l_previewprelude?></td></tr>
<?php
				if(isset($urlautoencode))
					$newstext = make_clickable($newstext);
				if(isset($enablespcode))
					$newstext = bbencode($newstext);
				if(!isset($disableemoticons))
					$newstext = encode_emoticons($newstext, $url_emoticons, $db);
				$newstext = htmlentities($newstext);
				$newstext = str_replace("\n", "<BR>", $newstext);
				$newstext = str_replace("\r","",$newstext);
				$newstext = undo_htmlspecialchars($newstext);
				$actdate = date("Y-m-d H:i:s");
				echo "<tr><td width=\"2%\" height=\"100%\" align=\"center\" class=\"newsicon\">";
				if($headingicon)
					echo "<img src=\"$url_icons/".$headingicon."\" border=\"0\" align=\"middle\"> ";
				else
					echo "&nbsp;";
				echo "</td>";
				echo "<td align=\"center\"><table width=\"100%\" align=\"center\" cellspacing=\"0\" cellpadding=\"0\">";
				echo "<tr><td align=\"left\" class=\"newsdate\">";
				echo $actdate."</td></tr>";
				if(strlen($heading)>0)
				{
					echo "<tr class=\"newsheading\"><td align=\"left\">";
					echo htmlentities($heading);
					echo "</td></tr>";
				}
				echo "<tr class=\"newsentry\"><td align=\"left\">";
				echo $newstext;
				echo "</td></tr>";
				echo "<tr class=\"displayrow\"><td align=\"left\">";
				echo "$l_tickerurl: $tickerurl";
				echo "</td></tr>";

				if($upload_avail && is_uploaded_file($HTTP_POST_FILES['uploadfile']['tmp_name']) && ($filesize>0))
				{
					echo "<tr class=\"displayrow\"><td align=\"left\">";
					if($filesize>$maxfilesize)
					{
						echo str_replace("{maxfilesize}",$maxfilesize,$l_filetoolarge);
					}
					else
					{
						if(!$attach_in_fs)
						{
							echo "<input type=\"hidden\" name=\"filedata\" value=\"".htmlentities($filedata)."\">";
							echo "<input type=\"hidden\" name=\"filetype\" value=\"$filetype\">";
						}
						echo "<input type=\"hidden\" name=\"filesize\" value=\"$filesize\">";
						echo "<input type=\"hidden\" name=\"filename\" value=\"$filename\">";
						echo "<img src=\"../gfx/attach.gif\" border=\"0\" align=\"absmiddle\">";
						echo "&nbsp;$l_actualattached: $filename ($filesize Bytes)";
					}
					echo "</td></tr>";
				}
				echo "</table></td></tr>";
				echo "<tr class=\"actionrow\"><td align=\"center\" colspan=\"2\"><input class=\"snbutton\" type=\"submit\" value=\"$l_add\">&nbsp;&nbsp;<input class=\"snbutton\" type=\"button\" value=\"$l_back\" onclick=\"self.history.back();\"></td></tr>";
				echo "</table></td></tr></table>";
			}
			else
			{
				if(isset($enablecomments))
					$allowcomments=1;
				else
					$allowcomments=0;
				if(strlen($userdata["realname"]>0))
					$poster=$userdata["realname"];
				else
					$poster=$userdata["username"];
				if(isset($urlautoencode))
					$newstext = make_clickable($newstext);
				if(isset($enablespcode))
					$newstext = bbencode($newstext);
				if(!isset($disableemoticons))
					$newstext = encode_emoticons($newstext, $url_emoticons, $db);
				if($heading)
					$searchtext = $heading." ";
				else
					$searchtext = "";
				$searchtext.= $newstext;
				$newstext = htmlentities($newstext);
				$newstext = str_replace("\n", "<BR>", $newstext);
				$newstext = str_replace("\r", "", $newstext);
				$searchtext = remove_htmltags($searchtext);
				$searchtext = strtolower($searchtext);
				$newstext=addslashes($newstext);
				$actdate = date("Y-m-d H:i:s");
				$sql = "insert into ".$tableprefix."_data (lang, date, text, heading, poster, headingicon, category, allowcomments, tickerurl) values ('$newslang', '$actdate', '$newstext', '$heading', '$poster', '$headingicon', $catnr, $allowcomments, '$tickerurl')";
				if(!$result = mysql_query($sql, $db))
				    die("Unable to connect to database.".mysql_error());
				$newsnr=mysql_insert_id($db);
				$sql = "insert into ".$tableprefix."_search (newsnr, text) values ($newsnr, '$searchtext')";
				if(!$result = mysql_query($sql, $db))
				    die("Unable to connect to database.".mysql_error());
				if($upload_avail && isset($filedata))
				{
					$sql = "insert into ".$tableprefix."_bindata (entrynr, bindata, filename, mimetype, filesize) ";
					$sql.= "values ($newsnr, '$filedata', '$filename', '$filetype', '$filesize')";
					if(!$result = mysql_query($sql, $db))
					    die("<tr class=\"errorrow\"><td>Unable to add entry to database.".mysql_error());
				}
				if($upload_avail && isset($filename) && $attach_in_fs)
				{
					$sql = "insert into ".$tableprefix."_bindata (entrynr, filename, filesize) ";
					$sql.= "values ($newsnr, '$filename', '$filesize')";
					if(!$result = mysql_query($sql, $db))
					    die("<tr class=\"errorrow\"><td>Unable to add entry to database.".mysql_error());
				}
				if(($enablesubscriptions==1) && ($subscriptionsendmode==0))
					email_single_news($heading, $newstext, $newslang, $db, $subject, $simpnewsmail, $simpnewsmailname, $actdate, $poster, $newsnr, $headingicon);
			}
		}
		else
			unset($preview);
	}
	if($mode=="massdel")
	{
		if(isset($newsnr))
		{
    		while(list($null, $input_newsnr) = each($HTTP_POST_VARS["newsnr"]))
    		{
				$sql = "delete from ".$tableprefix."_data where newsnr=$input_newsnr";
				if(!$result = mysql_query($sql, $db))
				    die("Unable to connect to database.".mysql_error());
				$sql = "delete from ".$tableprefix."_search where newsnr=$input_newsnr";
				if(!$result = mysql_query($sql, $db))
				    die("Unable to connect to database.".mysql_error());
				if($attach_in_fs)
				{
					$sql = "select * from ".$tableprefix."_bindata where entrynr=$input_newsnr";
					if(!$result = mysql_query($sql, $db))
					    die("<tr class=\"errorrow\"><td>Unable to update entry in database.");
					if($myrow=mysql_fetch_array($result))
						unlink($path_attach."/".$myrow["filename"]);
				}
				$sql = "delete from ".$tableprefix."_bindata where entrynr=$input_newsnr";
				if(!$result = mysql_query($sql, $db))
				    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
			}
		}
	}
	if($mode=="del")
	{
		$sql = "delete from ".$tableprefix."_data where newsnr=$input_newsnr";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
		$sql = "delete from ".$tableprefix."_search where newsnr=$input_newsnr";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
		if($attach_in_fs)
		{
			$sql = "select * from ".$tableprefix."_bindata where entrynr=$input_newsnr";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to update entry in database.");
			if($myrow=mysql_fetch_array($result))
				unlink($path_attach."/".$myrow["filename"]);
		}
		$sql = "delete from ".$tableprefix."_bindata where entrynr=$input_newsnr";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
	}
	if($mode=="delattach")
	{
		if($attach_in_fs)
		{
			$sql = "select * from ".$tableprefix."_bindata where entrynr=$input_newsnr";
			if(!$result = mysql_query($sql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to update entry in database.");
			if($myrow=mysql_fetch_array($result))
				unlink($path_attach."/".$myrow["filename"]);
		}
		$sql = "delete from ".$tableprefix."_bindata where entrynr=$input_newsnr";
		if(!$result = mysql_query($sql, $db))
		    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
	}
	if($mode=="edit")
	{
		$sql = "select * from ".$tableprefix."_data where newsnr=$input_newsnr";
		if(!$result = mysql_query($sql, $db))
		    die("Unable to connect to database.".mysql_error());
		if ($myrow = mysql_fetch_array($result))
		{
			$doedit=1;
			$headingtext=$myrow["heading"];
			$newstext = stripslashes($myrow["text"]);
			$newstext = str_replace("<BR>", "\n", $newstext);
			$newstext = undo_htmlspecialchars($newstext);
			$newstext = decode_emoticons($newstext, $url_emoticons, $db);
			$newstext = bbdecode($newstext);
			$newstext = undo_make_clickable($newstext);
			$actheadingicon=$myrow["headingicon"];
			$allowcomments=$myrow["allowcomments"];
			$tickerurl=$myrow["tickerurl"];
		}
		$sql="select * from ".$tableprefix."_bindata where entrynr=$input_newsnr";
		if(!$result = mysql_query($sql, $db))
		    die("Unable to connect to database.".mysql_error());
		if ($myrow = mysql_fetch_array($result))
		{
			$hasattach=1;
			$filename=$myrow["filename"];
			$filesize=$myrow["filesize"];
		}
	}
	if($mode=="update")
	{
		if(!isset($headingicon))
			$headingicon="";
		$newstext=trim($newstext);
		if(isset($newstext) && $newstext)
		{
			if($upload_avail && is_uploaded_file($HTTP_POST_FILES['uploadfile']['tmp_name']) && !isset($delattach))
			{
				$filesize=$HTTP_POST_FILES['uploadfile']['size'];
				$filename=$HTTP_POST_FILES['uploadfile']['name'];
				if(($filesize>0) && ($filesize<$maxfilesize))
				{
					$filedata="";
					if(isset($path_tempdir) && $path_tempdir)
					{
						if(!move_uploaded_file ($uploadfile, $path_tempdir."/".$filename))
							die("unable to move uploaded file to $path_tempdir");
						$orgfile=$path_tempdir."/".$filename;
					}
					else
						$orgfile=$uploadfile;
					if(!$attach_in_fs)
					{
						$filedata=addslashes(get_file($orgfile));
						$filetype=$HTTP_POST_FILES['uploadfile']['type'];
					}
					else
					{
						$sql = "select * from ".$tableprefix."_bindata where entrynr=$input_newsnr";
						if(!$result = mysql_query($sql, $db))
						    die("<tr class=\"errorrow\"><td>Unable to update entry in database.");
						if($myrow=mysql_fetch_array($result))
							unlink($path_attach."/".$myrow["filename"]);
						copy ($orgfile,$path_attach."/".$filename);
					}
					if(isset($path_tempdir) && $path_tempdir)
					{
						unlink($path_tempdir."/".$filename);
					}
				}
				else
				{
					unset($filedata);
					unset($filename);
				}
			}
			if(isset($enablecomments))
				$allowcomments=1;
			else
				$allowcomments=0;
			if(isset($preview))
			{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<form method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="lang" value="<?php echo $lang?>">
<?php
	if(is_konqueror())
		echo "<tr><td></td></tr>";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
	if(isset($enablecomments))
		echo "<input type=\"hidden\" name=\"enablecomments\" value=\"1\">";
	if(isset($urlautoencode))
		echo "<input type=\"hidden\" name=\"urlautoencode\" value=\"1\">";
	if(isset($enablespcode))
		echo "<input type=\"hidden\" name=\"enablespcode\" value=\"1\">";
	if(isset($delattach))
		echo "<input type=\"hidden\" name=\"delattach\" value=\"1\">";
	if(isset($resetdate))
		echo "<input type=\"hidden\" name=\"resetdate\" value=\"1\">";
?>
<input type="hidden" name="newslang" value="<?php echo $newslang?>">
<input type="hidden" name="catnr" value="<?php echo $catnr?>">
<input type="hidden" name="newstext" value="<?php echo htmlentities($newstext)?>">
<input type="hidden" name="heading" value="<?php echo htmlentities($heading)?>">
<input type="hidden" name="headingicon" value="<?php echo $headingicon?>">
<input type="hidden" name="mode" value="update">
<input type="hidden" name="input_newsnr" value="<?php echo $input_newsnr?>">
<input type="hidden" name="tickerurl" value="<?php echo $tickerurl?>">
<tr class="inforow"><td align="center" colspan="2"><?php echo $l_previewprelude?></td></tr>
<?php
				if(isset($urlautoencode))
					$newstext = make_clickable($newstext);
				if(isset($enablespcode))
					$newstext = bbencode($newstext);
				if(!isset($disableemoticons))
					$newstext = encode_emoticons($newstext, $url_emoticons, $db);
				$newstext = htmlentities($newstext);
				$newstext = str_replace("\n", "<BR>", $newstext);
				$newstext = str_replace("\r", "", $newstext);
				$newstext = undo_htmlspecialchars($newstext);
				if(isset($resetdate))
				{
					$acttime=time();
					$acttime=$acttime-($servertimezone*60*60);
					$acttime=$acttime+($displaytimezone*60*60);
					$actdate = date("Y-m-d H:i:s",$acttime);
				}
				else
				{
					$tempsql="select * from ".$tableprefix."_data where newsnr=$input_newsnr";
					if(!$tempresult = mysql_query($tempsql, $db))
					    die("Unable to connect to database.".mysql_error());
					if($temprow=mysql_fetch_array($tempresult))
					{
						list($mydate,$mytime)=explode(" ",$temprow["date"]);
						list($year, $month, $day) = explode("-", $mydate);
						list($hour, $min, $sec) = explode(":",$mytime);
						$temptime=mktime($hour,$min,$sec,$month,$day,$year);
						$temptime=$temptime-($servertimezone*60*60);
						$temptime=$temptime+($displaytimezone*60*60);
						$actdate=date("Y-m-d H:i:s",$temptime);
					}
					else
						$actdate="";
				}
				echo "<tr><td width=\"2%\" height=\"100%\" align=\"center\" class=\"newsicon\">";
				if($headingicon)
					echo "<img src=\"$url_icons/".$headingicon."\" border=\"0\" align=\"middle\"> ";
				else
					echo "&nbsp;";
				echo "</td>";
				echo "<td align=\"center\"><table width=\"100%\" align=\"center\" bgcolor=\"#c0c0c0\" cellspacing=\"0\" cellpadding=\"0\">";
				echo "<tr><td align=\"left\" class=\"newsdate\">";
				echo $actdate."</td></tr>";
				if(strlen($heading)>0)
				{
					echo "<tr class=\"newsheading\"><td align=\"left\">";
					echo htmlentities($heading);
					echo "</td></tr>";
				}
				echo "<tr class=\"newsentry\"><td align=\"left\">";
				echo $newstext;
				echo "</td></tr>";
				echo "<tr class=\"displayrow\"><td align=\"left\">";
				echo "$l_tickerurl: $tickerurl";
				echo "</td></tr>";
				if($upload_avail && is_uploaded_file($HTTP_POST_FILES['uploadfile']['tmp_name']) && ($filesize>0))
				{
					echo "<tr class=\"displayrow\"><td align=\"left\">";
					if($filesize>$maxfilesize)
					{
						echo str_replace("{maxfilesize}",$maxfilesize,$l_filetoolarge);
					}
					else
					{
						if(!$attach_in_fs)
						{
							echo "<input type=\"hidden\" name=\"filedata\" value=\"".htmlentities($filedata)."\">";
							echo "<input type=\"hidden\" name=\"filetype\" value=\"$filetype\">";
						}
						echo "<input type=\"hidden\" name=\"$filesize\" value=\"$filesize\">";
						echo "<input type=\"hidden\" name=\"$filename\" value=\"$filename\">";
						echo "<img src=\"../gfx/attach.gif\" border=\"0\" align=\"absmiddle\">";
						echo "&nbsp;$l_newattach: $filename ($filesize Bytes)</td></tr>";
					}
				}
				if($upload_avail && isset($delattach))
				{
					echo "<tr class=\"displayrow\"><td align=\"left\">";
					echo "<img src=\"../gfx/attach.gif\" border=\"0\" align=\"absmiddle\">";
					echo "&nbsp;$l_delattach</td></tr>";
				}
				echo "</table></td></tr>";
				echo "<tr class=\"actionrow\"><td align=\"center\" colspan=\"2\"><input class=\"snbutton\" type=\"submit\" value=\"$l_update\">&nbsp;&nbsp;<input class=\"snbutton\" type=\"button\" value=\"$l_back\" onclick=\"self.history.back();\"></td></tr>";
				echo "</table></td></tr></table>";
			}
			else
			{
				if(isset($urlautoencode))
					$newstext = make_clickable($newstext);
				if(isset($enablespcode))
					$newstext = bbencode($newstext);
				if(!isset($disableemoticons))
					$newstext = encode_emoticons($newstext, $url_emoticons, $db);
				if($heading)
					$searchtext = $heading." ";
				else
					$searchtext = "";
				$searchtext.= $newstext;
				$newstext = htmlentities($newstext);
				$newstext = str_replace("\n", "<BR>", $newstext);
				$newstext = str_replace("\r", "", $newstext);
				$searchtext = remove_htmltags($searchtext);
				$searchtext = strtolower($searchtext);
				$newstext=addslashes($newstext);
				$actdate = date("Y-m-d H:i:s");
				$sql = "update ".$tableprefix."_data set headingicon='$headingicon', text='$newstext', heading='$heading', allowcomments=$allowcomments, tickerurl='$tickerurl'";
				if(isset($resetdate))
					$sql.=", date='$actdate'";
				$sql.= " where newsnr=$input_newsnr";
				if(!$result = mysql_query($sql, $db))
				    die("Unable to connect to database.".mysql_error());
				$sql = "update ".$tableprefix."_search set text='$searchtext' where newsnr=$input_newsnr";
				if(!$result = mysql_query($sql, $db))
				    die("Unable to connect to database.".mysql_error());
				if(isset($delattach))
				{
					if($attach_in_fs)
					{
						$sql = "select * from ".$tableprefix."_bindata where entrynr=$input_newsnr";
						if(!$result = mysql_query($sql, $db))
						    die("<tr class=\"errorrow\"><td>Unable to update entry in database.");
						if($myrow=mysql_fetch_array($result))
							unlink($path_attach."/".$myrow["filename"]);
					}
					$sql = "delete from ".$tableprefix."_bindata where entrynr=$input_newsnr";
					if(!$result = mysql_query($sql, $db))
					    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
				} else if($upload_avail && isset($filename))
				{
					$sql = "delete from ".$tableprefix."_bindata where entrynr=$input_newsnr";
					if(!$result = mysql_query($sql, $db))
					    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
					if($attach_in_fs)
					{
						$sql = "insert into ".$tableprefix."_bindata (entrynr, filename, filesize) ";
						$sql.= "values ($input_newsnr, '$filename', '$filesize')";
						if(!$result = mysql_query($sql, $db))
						    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
					}
					else if(isset($filedata))
					{
						$sql = "insert into ".$tableprefix."_bindata (entrynr, bindata, filename, mimetype, filesize) ";
						$sql.= "values ($input_newsnr, '$filedata', '$filename', '$filetype', '$filesize')";
						if(!$result = mysql_query($sql, $db))
						    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
					}
				}
				if(($enablesubscriptions==1) && ($subscriptionsendmode==0) && isset($resetdate))
				{
					$sql = "select * from ".$tableprefix."_data where newsnr=$input_newsnr";
					if(!$result = mysql_query($sql, $db))
					    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
					if($myrow=mysql_fetch_array($result))
					{
						$poster=$myrow["poster"];
						email_single_news($heading, $newstext, $newslang, $db, $subject, $simpnewsmail, $simpnewsmailname, $actdate, $poster, $input_newsnr, $headingicon);
					}
				}
			}
		}
	}
}
if(!isset($preview))
{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
if($admin_rights > 1)
{
?>
<form method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="lang" value="<?php echo $lang?>">
<?php
	if(is_konqueror())
		echo "<tr><td></td></tr>";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="newslang" value="<?php echo $newslang?>">
<tr class="inputrow"><td align="center" colspan="2"><?php echo $l_category?>:
<select class="snselect" name="catnr"><option value="0" <?php if($catnr==0) echo "selected"?>><?php echo $l_without?></option>
<?php
$catsql="select * from ".$tableprefix."_categories";
if(!$result = mysql_query($catsql, $db))
    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database.".mysql_error());
if($myrow=mysql_fetch_array($result))
{
	do{
		echo "<option value=\"".$myrow["catnr"]."\"";
		if($myrow["catnr"]==$catnr)
			echo " selected";
		echo ">".htmlentities($myrow["catname"])."</option>";
	}while($myrow=mysql_fetch_array($result));
}
?>
</select>
<input class="snbutton" type="submit" value="<?php echo $l_change?>"></td></tr></form>
<form method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="lang" value="<?php echo $lang?>">
<input type="hidden" name="catnr" value="<?php echo $catnr?>">
<?php
	if(is_konqueror())
		echo "<tr><td></td></tr>";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<tr class="inputrow"><td align="center" colspan="2"><?php echo $l_edlang?>: <?php echo language_select($newslang,"newslang")?>
<input class="snbutton" type="submit" value="<?php echo $l_change?>"></td></tr></form>
<?php
if($catnr==0)
	$catname=$l_without." ".$l_category;
else
{
	$tempsql="select * from ".$tableprefix."_categories where catnr=$catnr";
	if(!$tempresult = mysql_query($tempsql, $db))
	    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database.".mysql_error());
	if($temprow=mysql_fetch_array($tempresult))
		$catname=$temprow["catname"];
	else
		$catname=$l_without." ".$l_category;
}
?>
<tr class="inforow"><td align="center" valign="top" colspan="2"><b><?php echo "$l_actuallyselected: $catname, $newslang"?></b></td></tr>
<form <?php if($upload_avail) echo "enctype=\"multipart/form-data\""?>  name="inputform" method="post" action="<?php echo $act_script_url?>">
<?php
	if(is_konqueror())
		echo "<tr><td></td></tr>";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="lang" value="<?php echo $lang?>">
<input type="hidden" name="newslang" value="<?php echo $newslang?>">
<tr class="inputrow"><td align="right" width="20%"><?php echo $l_heading?>:</td>
<td><input class="sninput" type="text" name="heading" value="<?php echo $headingtext?>" size="40" maxlength="80"></td></tr>
<?php
$sql = "select * from ".$tableprefix."_icons order by icon_url asc";
if(!$result = mysql_query($sql, $db))
    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database.".mysql_error());
if($myrow=mysql_fetch_array($result))
{
?>
<tr class="inputrow"><td align="right" valign="top" width="20%"><?php echo $l_headingicon?>:</td>
<td valign="middle" nowrap>
<table width="100%" class="iconselector" cellspacing="1" cellpadding="1" align="center">
<tr>
<?php
	$iconcount=0;
	do{
		$iconcount++;
		echo "<td class=\"iconselector\" align=\"center\"><input type=\"radio\" name=\"headingicon\" value=\"",$myrow["icon_url"]."\"";
		if(isset($actheadingicon) && ($actheadingicon==$myrow["icon_url"]))
			echo " checked";
		echo "> <img src=\"$url_icons/".$myrow["icon_url"]."\" border=\"0\" align=\"top\"></td>";
		if($iconcount>4)
		{
			$iconcount=0;
			echo "</tr><tr>";
		}
	}while($myrow=mysql_fetch_array($result));
	echo "</tr>";
?>
</table>
</td></tr>
<?php
}
?>
<tr class="inputrow"><td align="right" valign="top" width="20%"><?php echo $l_news?>:
</td>
<td align="left"><textarea class="sninput" name="newstext" rows="10" cols="50">
<?php
if(isset($doedit))
	echo $newstext;
?>
</textarea><br>
<?php
	display_smiliebox("newstext");
	display_bbcode_buttons($l_bbbuttons,"newstext")
?>
</td></tr>
<?php
if(isset($doedit))
{
	echo "<input type=\"hidden\" name=\"mode\" value=\"update\">";
	echo "<input type=\"hidden\" name=\"input_newsnr\" value=\"$input_newsnr\">";
}
else
	echo "<input type=\"hidden\" name=\"mode\" value=\"add\">";
?>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_options?>:</td><td align="left">
<input type="checkbox" name="urlautoencode" value="1" checked> <?php echo $l_urlautoencode?><br>
<input type="checkbox" name="enablespcode" value="1" checked> <?php echo $l_enablespcode?><br>
<input type="checkbox" name="disableemoticons" value="1"> <?php echo $l_disableemoticons?>
<input type="hidden" name="catnr" value="<?php echo $catnr?>">
</td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_tickerurl?>:</td>
<td><input class="sninput" type="text" name="tickerurl" size="40" maxlength="240" <?php if(isset($doedit)) echo "value=\"$tickerurl\""?>></td></tr>
<?php
if($upload_avail)
{
?>
<INPUT TYPE="hidden" name="MAX_FILE_SIZE" value="<?php echo $maxfilesize?>">
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_attachfile?>:</td>
<td><input class="sninput" type="file" name="uploadfile">
<?php
		if($hasattach==1)
		{
			echo "<br>$l_actualattached: $filename ($filesize Bytes)";
			echo "<br><input type=\"checkbox\" name=\"delattach\" value=\"1\">$l_delattach";
		}
	echo "</td></tr>";
}
?>
<tr class="inputrow"><td>&nbsp;</td><td>
<input type="checkbox" name="enablecomments" value="1" <?php if($allowcomments==1) echo "checked"?>> <?php echo $l_commentsonpost?></td></tr>
<?php
if(isset($doedit))
{
?>
<tr class="inputrow"><td>&nbsp;</td><td>
<input type="checkbox" name="resetdate" value="1"> <?php echo $l_resetdate?></td></tr>
<?php
}
?>
<tr class="actionrow"><td align="center" colspan="2"><input class="snbutton" type="submit" value="<?php if(isset($doedit)) echo $l_update; else echo $l_add?>">&nbsp;&nbsp;<input class="snbutton" type="submit" name="preview" value="<?php echo $l_preview?>"></td></tr>
</form>
<?php
}
?>
</table></td></tr></table>
<p></p>
<?php
$sql = "select * from ".$tableprefix."_data where lang='$newslang' and category=$catnr order by date desc";
if(!$result = mysql_query($sql, $db))
    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database.".mysql_error());
if ($myrow = mysql_fetch_array($result))
{
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<form name="newslist" method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="lang" value="<?php echo $lang?>">
<input type="hidden" name="newslang" value="<?php echo $newslang?>">
<input type="hidden" name="mode" value="massdel">
<input type="hidden" name="catnr" value="<?php echo $catnr?>">
<?php
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
	do{
		$act_id=$myrow["newsnr"];
		$newstext=stripslashes($myrow["text"]);
		$newstext = undo_htmlspecialchars($newstext);
		if($myrow["heading"])
			$displaytext="<b>".$myrow["heading"]."</b><br>".$newstext;
		else
			$displaytext=$newstext;
		echo "<tr>";
		if($admin_rights > 1)
		{
			echo "<td class=\"actionrow\" align=\"center\" width=\"1%\">";
			echo "<input type=\"checkbox\" name=\"newsnr[]\" value=\"$act_id\">";
			echo "</td>";
		}
		echo "<td class=\"displayrow\" align=\"center\" width=\"8%\">";
		echo $myrow["newsnr"]."</td>";
		echo "<td class=\"newsicon\" align=\"center\" width=\"2%\">";
		if($myrow["headingicon"])
			echo "<img src=\"$url_icons/".$myrow["headingicon"]."\" border=\"0\" align=\"bottom\">";
		else
			echo "&nbsp;";
		echo "</td><td class=\"newsentry\" align=\"left\">";
		echo "$displaytext</td>";
		echo "<td class=\"newsdate\" align=\"center\" width=\"20%\">";
		list($mydate,$mytime)=explode(" ",$myrow["date"]);
		list($year, $month, $day) = explode("-", $mydate);
		list($hour, $min, $sec) = explode(":",$mytime);
		$temptime=mktime($hour,$min,$sec,$month,$day,$year);
		$temptime=$temptime-($servertimezone*60*60);
		$temptime=$temptime+($displaytimezone*60*60);
		$displaydate=date("Y-m-d H:i:s",$temptime);
		echo "$displaydate</td>";
		if($admin_rights > 1)
		{
			$tmpsql = "select * from ".$tableprefix."_comments where entryref=".$myrow["newsnr"];
			if(!$tmpresult = mysql_query($tmpsql, $db))
			    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
			$numcomments=mysql_num_rows($tmpresult);
			echo "<td class=\"adminactions\" align=\"center\" width=\"2%\">";
			if($numcomments>0)
				echo "<a href=\"".do_url_session("comments.php?lang=$lang&entryref=".$myrow["newsnr"])."\"><img src=\"gfx/comment.gif\" border=\"0\" title=\"$numcomments $l_comments\" alt=\"$numcomments $l_comments\"></a>";
			else
				echo "&nbsp;";
			echo "</td>";
			$tempsql="select * from ".$tableprefix."_bindata where entrynr=$act_id";
			if(!$tempresult=mysql_query($tempsql,$db))
			    die("<tr class=\"errorrow\"><td>Unable to connect to database.".mysql_error());
			echo "<td class=\"adminactions\" align=\"center\" width=\"2%\">";
			if($temprow=mysql_fetch_array($tempresult))
			{
				$filedesc=$temprow["filename"]." (".$temprow["filesize"]."Bytes)";
				echo "<a href=\"".do_url_session("$act_script_url?lang=$lang&newslang=$newslang&mode=delattach&input_newsnr=$act_id&catnr=$catnr")."\">";
				echo "<img src=\"gfx/delattach.gif\" border=\"0\" align=\"absmiddle\" alt=\"$l_delattach: $filedesc\" title=\"$l_delattach: $filedesc\"></a>";
			}
			else
				echo "&nbsp;";
			echo "</td>";
			echo "<td class=\"adminactions\" align=\"center\" width=\"2%\"><a href=\"".do_url_session("$act_script_url?lang=$lang&newslang=$newslang&mode=edit&input_newsnr=$act_id&catnr=$catnr")."\"><img src=\"gfx/edit.gif\" border=\"0\" title=\"$l_edit\" alt=\"$l_edit\"></a></td>";
			echo "<td class=\"adminactions\" align=\"center\" width=\"2%\"><a href=\"".do_url_session("$act_script_url?lang=$lang&newslang=$newslang&mode=del&input_newsnr=$act_id&catnr=$catnr")."\"><img src=\"gfx/delete.gif\" border=\"0\" title=\"$l_delete\" alt=\"$l_delete\"></a></td>";
		}
		echo "</tr>";
	}while($myrow=mysql_fetch_array($result));
	if($admin_rights > 1)
	{
		echo "<tr class=\"actionrow\"><td colspan=\"9\" align=\"left\"><input class=\"snbutton\" type=\"submit\" value=\"$l_delselected\">";
		echo "&nbsp; <input class=\"snbutton\" type=\"button\" onclick=\"checkAll(document.newslist)\" value=\"$l_checkall\">";
		echo "&nbsp; <input class=\"snbutton\" type=\"button\" onclick=\"uncheckAll(document.newslist)\" value=\"$l_uncheckall\">";
		echo "</td></tr>";
	}
	echo "</form></table></td></tr></table>";
}
}
include('./trailer.php')
?>
