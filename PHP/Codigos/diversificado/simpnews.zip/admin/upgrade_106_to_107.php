<?php
require('../config.php');
require('./functions.php');
?>
<html><body>
<div align="center"><h3>SimpNews: Upgrade from 1.06 to 1.07</h3></div>
<br>
<?php
echo "Adding new tables...<br>";
// create table simpnews_bindata
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_bindata;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_bindata");
$sql = "CREATE TABLE ".$tableprefix."_bindata (";
$sql.= "entrynr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "bindata longblob NOT NULL DEFAULT '' ,";
$sql.= "filename varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "mimetype varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "filesize int(10) NOT NULL DEFAULT '0' ,";
$sql.= "UNIQUE entrynr (entrynr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_bindata");
echo "Upgrading tables...<br>";
$sql = "ALTER TABLE ".$tableprefix."_layout ";
$sql.= "add attachpic varchar(240) NOT NULL DEFAULT 'attach.gif'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_layout");
?>
<br><div align="center">Installation done.<br>Please remove install.php, upgrade*.php and fill_freemailer.php from server</div>
<div align="center">Now you can login to the <a href="index.php">admininterface</a></div>
</html></body>