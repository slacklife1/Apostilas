<?php
require('../config.php');
require('./functions.php');
?>
<html><body>
<div align="center"><h3>SimpNews: Upgrade from 1.24 to 1.25</h3></div>
<br>
<?php
echo "Upgrading tables...<br>";
$sql = "ALTER TABLE ".$tableprefix."_layout ";
$sql.= "drop servertimezone ,";
$sql.= "add eventscrolleractdate tinyint(1) unsigned NOT NULL DEFAULT '1'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_layout");
$sql = "ALTER TABLE ".$tableprefix."_settings ";
$sql.= "add servertimezone tinyint(3) NOT NULL DEFAULT '0' ,";
$sql.= "add displaytimezone tinyint(3) NOT NULL DEFAULT '0'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_settings");
?>
<br><div align="center">Installation done.<br>Please remove install.php, upgrade*.php and fill_freemailer.php from server</div>
<div align="center">Now you can login to the <a href="index.php">admininterface</a></div>
</html></body>