<?php
require('../config.php');
require('./functions.php');
?>
<html><body>
<div align="center"><h3>SimpNews: Upgrade from 1.05 to 1.06</h3></div>
<br>
<?php
echo "Adding new tables...<br>";
// create table simpnews_comments
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_comments;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_comments");
$sql = "CREATE TABLE ".$tableprefix."_comments (";
$sql.= "commentnr int(10) unsigned NOT NULL auto_increment,";
$sql.= "poster varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "email varchar(80) NOT NULL DEFAULT '' ,";
$sql.= "entryref int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "comment text NOT NULL DEFAULT '' ,";
$sql.= "enterdate datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ,";
$sql.= "PRIMARY KEY (commentnr));";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_comments");
// create table simpnews_search
$sql = "DROP TABLE IF EXISTS ".$tableprefix."_search;";
if(!$result = mysql_query($sql, $db))
	die("Unable to drop existing table ".$tableprefix."_search");
$sql = "CREATE TABLE ".$tableprefix."_search (";
$sql.= "newsnr int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "text text NOT NULL DEFAULT '' );";
if(!$result = mysql_query($sql, $db))
	die("Unable to create table ".$tableprefix."_search");
echo "Upgrading tables...<br>";
$sql = "ALTER TABLE ".$tableprefix."_layout ";
$sql.= "add customfooter text NOT NULL DEFAULT '' ,";
$sql.= "add helppic varchar(240) NOT NULL DEFAULT 'help.gif'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_layout");
?>
<br><div align="center">Installation done.<br>Please remove install.php, upgrade*.php and fill_freemailer.php from server</div>
<div align="center">Now you can login to the <a href="index.php">admininterface</a></div>
<div align="center">And don't forget to update the search index in admin interface</div>
</html></body>