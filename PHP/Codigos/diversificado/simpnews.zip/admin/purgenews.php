<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
if(!isset($lang) || !$lang)
	$lang=$admin_lang;
include_once('./language/lang_'.$lang.'.php');
require_once('./auth.php');
$page_title=$l_purgenews;
require_once('./heading.php');
$sql = "select * from ".$tableprefix."_settings where settingnr=1";
if(!$result = mysql_query($sql, $db))
    die("Unable to connect to database.".mysql_error());
if(!$myrow=mysql_fetch_array($result))
	die("SimpNews not set up.");
$maxage=$myrow["maxage"];
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<?php
if($admin_rights < 2)
{
	echo "<tr class=\"errorrow\"><td align=\"center\">";
	die("$l_functionnotallowed");
}
if(isset($submit))
{
		$actdate = date("Y-m-d H:i:s");
		$sql = "SELECT * FROM ".$tableprefix."_data where date<date_sub('$actdate', INTERVAL $maxage DAY)";
		if(!$result = mysql_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Unable to connect to database.");
		while($myrow=mysql_fetch_array($result))
		{
			$sql2 = "delete from ".$tableprefix."_search where newsnr=".$myrow["newsnr"];
			if(!$result2 = mysql_query($sql2, $db))
			    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
			if($attach_in_fs)
			{
				$sql2 = "select * from ".$tableprefix."_bindata where entrynr=".$myrow["newsnr"];
				if(!$result2 = mysql_query($sql2, $db))
					die("<tr bgcolor=\"#cccccc\"><td>Unable to update entry in database.");
				if($myrow2=mysql_fetch_array($result2))
					unlink($path_attach."/".$myrow2["filename"]);
			}
			$sql2 = "delete from ".$tableprefix."_bindata where entrynr=".$myrow["newsnr"];
			if(!$result2 = mysql_query($sql2, $db))
				die("Unable to connect to database.".mysql_error());
		}
		$sql = "DELETE FROM ".$tableprefix."_data where date<date_sub('$actdate', INTERVAL $maxage DAY)";
		if(!$result = mysql_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Unable to update the database.");
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="displayrow"><td align="center"><?php echo $l_newspurged?></td></tr>
</table></td></tr></table>
<?php
	include('trailer.php');
	exit;
}
if($maxage>0)
{
$displaymsg=$l_purgenewswarning;
$displaymsg=str_replace("{maxage}",$maxage,$displaymsg);
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="inforow">
<form method="post" action="<?php echo $act_script_url?>">
<?php
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<input type="hidden" name="lang" value="<?php echo $lang?>">
<td align="center"><?php echo $displaymsg?></td></tr>
<tr class="actionrow">
<td align="center"><input class="snbutton" type="submit" name="submit" value="<?php echo $l_yes?>"></td></tr>
</table></td></tr></table>
<?php
}
else
{
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr class="inforow"><td align="center"><?php echo $l_functiondisabled?></td></tr>
</table></td></tr></table>
<?php
}
include('./trailer.php');
?>