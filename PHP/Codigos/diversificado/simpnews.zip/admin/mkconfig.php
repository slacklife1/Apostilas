<?php
/***************************************************************************
 * (c)2001,2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
// begin user editable part
// Set to true, if you're useing PHP version 4.1.0 or greater
$new_global_handling=false;
// end user editable part
//
error_reporting  (E_ERROR | E_PARSE); // This will NOT report uninitialized variables
echo "<html><body>";
if(!isset($lang))
{
?>
<form method="post" action="mkconfig.php">
<div align="center">Please select language/Bitte Sprache ausw&auml;hlen<br>
<input type="radio" name="lang" value="en">English<br>
<input type="radio" name="lang" value="de">Deutsch<br>
<input type="submit" value="submit"></div></form>
</body></html>
<?php
	exit;
}
if($lang=="en")
	$msgs=get_en_msgs();
else
	$msgs=get_de_msgs();
if(!isset($mode))
{
	if($new_global_handling)
		$act_script_url=$GLOBALS["PHP_SELF"];
	else
		$act_script_url=$PHP_SELF;
	$snurl=substr($act_script_url,0,strrpos($act_script_url,"/"));
	$snurl=substr($snurl,0,strrpos($snurl,"/"));
?>
<div align="center"><?php echo $msgs["prelude"]?></div>
<br>
<form method="post" action="mkconfig.php">
<input type="hidden" name="lang" value="<?php echo $lang?>">
<table align="center" border="1" width="80%">
<tr><td align="right"><?php echo $msgs["dbhost"]?>:</td>
<td><input type="text" name="dbhost" size="40" maxlength="180" value="localhost"></td></tr>
<tr><td align="right"><?php echo $msgs["dbname"]?>:</td>
<td><input type="text" name="dbname" size="40" maxlength="180" value="news"></td></tr>
<tr><td align="right"><?php echo $msgs["dbuser"]?>:</td>
<td><input type="text" name="dbuser" size="40" maxlength="180" value="root"></td></tr>
<tr><td align="right"><?php echo $msgs["dbpwd"]?>:</td>
<td><input type="text" name="dbpwd" size="40" maxlength="180"></td></tr>
<tr><td align="right"><?php echo $msgs["dbprefix"]?>:</td>
<td><input type="text" name="dbprefix" size="40" maxlength="180" value="simpnews"></td></tr>
<tr><td align="right"><?php echo $msgs["deflang"]?>:</td>
<td><select name="deflang"><option value="en">English</option><option value="de">Deutsch</option></select></td></tr>
<tr><td align="right"><?php echo $msgs["admlang"]?>:</td>
<td><select name="admlang"><option value="en">English</option><option value="de">Deutsch</option></select></td></tr>
<tr><td align="right"><?php echo $msgs["scripturl"]?>:</td>
<td><input type="text" name="scripturl" size="40" maxlength="180" value="<?php echo $snurl?>"></td></tr>
<tr><td align="right"><?php echo $msgs["scriptpath"]?>:</td>
<td>
<?php
$scriptpath=dirname(getcwd());
$scriptpath=str_replace("\\","/",$scriptpath);
?>
<input type="text" name="scriptpath" size="40" maxlength="180" value="<?php echo $scriptpath?>"></td></tr>
<tr><td align="right" width="40%"><?php echo $msgs["sesstype"]?>:</td>
<td><select name="sesstype">
<option value="cookie"><?php echo $msgs["sesscookie"]?></option>
<option value="url"><?php echo $msgs["sessurl"]?></option>
<option value="htaccess"><?php echo $msgs["htaccess"]?></option>
</select></td></tr>
<tr><td align="right"><?php echo $msgs["sesscookietime"]?>:</td>
<td><input type="text" name="sesscookietime" size="5" maxlength="10" value="600"> <?php echo $msgs["sec"]?></td></tr>
<tr><td align="right"><?php echo $msgs["pwrecov"]?>:</td>
<td><input type="checkbox" name="pwrecov" value="1" checked> <?php echo $msgs["enable"]?></td></tr>
<tr><td align="right"><?php echo $msgs["sitename"]?>:</td>
<td><input type="text" name="sitename" size="40" maxlength="180" value="<?php echo $_SERVER["HTTP_HOST"]?>"></td></tr>
<tr><td align="right"><?php echo $msgs["maxattach"]?>:</td>
<td><input type="text" name="maxattach" size="10" maxlength="20" value="1000000"> Bytes</td></tr>
<tr><td align="right"><?php echo $msgs["attachfs"]?>:</td>
<td><input type="checkbox" name="fsattach" value="1"><?php echo $msgs["enable"]?></td></tr>
<tr><td align="right"><?php echo $msgs["openbasedir"]?>:</td>
<td><input type="checkbox" name="openbasedir" value="1"><?php echo $msgs["enabled"]?></td></tr>
<tr><td align="right"><?php echo $msgs["realip"]?>:</td>
<td><input type="checkbox" name="realip" value="1"> <?php echo $msgs["enable"]?><br>
<tr><td align="right"><?php echo $msgs["contentcharset"]?>:</td>
<td><input type="text" name="contentcharset" size="40" maxlength="240" value="iso-8859-1"></td></tr>
<tr><td align="right"><?php echo $msgs["smtpmail"]?>:</td>
<td><input type="checkbox" name="smtpmail" value="1"><?php echo $msgs["enabled"]?></td></tr>
<tr><td align="right"><?php echo $msgs["smtpserver"]?>:</td>
<td><input type="text" name="smtpserver" size="40" maxlength="240" value="localhost"></td></tr>
<tr><td align="right"><?php echo $msgs["smtpdomain"]?>:</td>
<td><input type="text" name="smtpdomain" size="40" maxlength="240" value="<?php echo determinedomain($_SERVER["HTTP_HOST"])?>"></td></tr>
<tr><td align="right"><?php echo $msgs["smtpauth"]?>:</td>
<td><input type="radio" name="smtpauth" value="false" checked> <?php echo $msgs["notneeded"]?><br>
<input type="radio" name="smtpauth" value="true"> <?php echo $msgs["needed"]?></td></tr>
<input type="hidden" name="mode" value="writecfg">
<tr><td align="right"><?php echo $msgs["smtpuser"]?>:</td>
<td><input type="text" name="smtpuser" size="40" maxlength="240"></td></tr>
<tr><td align="right"><?php echo $msgs["smtppwd"]?>:</td>
<td><input type="text" name="smtppwd" size="40" maxlength="240"></td></tr>
<tr><td colspan="2" align="center"><input type="submit" value="submit"></tr>
</table></form></body></html>
<?php
}
else
{
	if($mode=="writecfg")
	{
	$configfile=$scriptpath."/config.php";
	if(file_exists($configfile))
	{
		if(!is_writeable($configfile))
		{
			printf($msgs["notwriteable"],$configfile);
			die("<br>".$msgs["correctfirst"]);
		}
	}
	$cfgfile=fopen($configfile,"w");
	if(!$cfgfile)
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"<?php\n// Edit this to fit your needs\n// Begin edit\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// hostname mysql running on\n	\$dbhost = \"$dbhost\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// name of database\n	\$dbname = \"$dbname\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// username for database\n	\$dbuser = \"$dbuser\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// password for database\n	\$dbpasswd = \"$dbpwd\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// prefix for tables, so you can have multiple instances of\n	// SimpNews in one database (please set before calling install or update)\n	\$tableprefix = \"$dbprefix\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// prefix for hostcache table, if you also use one of our other PHP scripts\n	// you can set all hostcache tables to 1 prefix, so you only have 1 hostcache\n	\$hcprefix= \"$dbprefix\";\n	// prefix for ip banlist table, if you also use one of our other PHP scripts\n	// you can set all banlist tables to 1 prefix, so you only have 1 banlist\n	\$banprefix= \"$dbprefix\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// default language, you can create your own languagefile\n	// for other languages in ./language\n    \$default_lang = \"$deflang\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"    // language to use for admininterface\n    \$admin_lang = \"$admlang\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"    // URL-Path for SimpNews instance. If you use http://www.myhost.com/simpnews\n    // this is /simpnews\n	\$url_simpnews = \"$scripturl\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// URL-Path for graphics (no trailing slash)\n	\$url_gfx = \"".$scripturl."/gfx\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// URL-Path for emoticons (no trailing slash)\n	\$url_emoticons = \"".$scripturl."/gfx/emoticons\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// URL-Path for icons (no trailing slash)\n	\$url_icons = \"".$scripturl."/gfx/icons\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// complete path to directory containing simpnews (without trailing slash)\n	\$path_simpnews = \"".$scriptpath."\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// complete path to directory containing graphics (without trailing slash)\n	\$path_gfx = \"".$scriptpath."/gfx\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// complete path to directory containing emoticons (without trailing slash)\n	\$path_emoticons = \"".$scriptpath."/gfx/emoticons\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// complete path to directory containing icons (without trailing slash)\n	\$path_icons = \"".$scriptpath."/gfx/icons\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// It should be safe to leave this alone as well. But if you do change it\n	// make sure you don't set it to a variable already in use (use a seperate\n	// name for each instance of SimpNews)\n	\$cookiename = \"simpnews\";\n	// It should be safe to leave these alone as well.\n	\$cookiepath = \$url_simpnews;\n	\$cookiesecure = false;\n	// This is the cookie name for the sessions cookie, you shouldn't have to change it\n	// (for multiple instances use different names)\n	\$sesscookiename = \"simpnewssession\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// This is the number of seconds that a session lasts for, 3600 == 1 hour.\n	// The session will exprire if the user dosn't view a page on the admininterface\n	// in this amount of time.\n	\$sesscookietime = $sesscookietime;\n"))
		die($msgs["cfgferror"]);
	$fullurl="http://".$sitename.$scripturl;
	if(!fwrite($cfgfile,"	// Full URL for SimpNews with trailing slash\n	\$simpnews_fullurl = \"$fullurl\";\n"))
		die($msgs["cfgferror"]);
	if($sesstype=="htaccess")
		$htaccess="true";
	else
		$htaccess="false";
	if(!fwrite($cfgfile,"	// Set this to true if you want to use authentication by htacces rather then the\n	// internal version (for details reffer to readme.txt)\n	\$enable_htaccess=$htaccess;\n"))
		die($msgs["cfgferror"]);
	if($sesstype=="url")
		$urlsess="true";
	else
		$urlsess="false";
	if(!fwrite($cfgfile,"	// Set this to true if you want to use sessionid passed throught get and put requests\n	// rathern than by cookie (for details reffer to readme.txt)\n	\$sessid_url=$urlsess;\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// Please set this to the hostname, where your instance of SimpNews is installed\n	\$simpnewssitename=\"$sitename\";\n"))
		die($msgs["cfgferror"]);
	if(isset($pwrecov))
		$pwrecover="true";
	else
		$pwrecover="false";
	if(!fwrite($cfgfile,"	// Set to true if you want to have password recovery for admin interface enabled\n	\$enablerecoverpw=$pwrecover;\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// maximal filesize for attachements by admin\n	\$maxfilesize=$maxattach;\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// Set this to the charset to be used as content encoding\n	\$contentcharset=\"$contentcharset\";\n"))
		die($msgs["cfgferror"]);
	if(isset($fsattach))
		$attachfs="true";
	else
		$attachfs="false";
	if(!fwrite($cfgfile,"	// Set this to true, if you want to have attachements stored in file system instead of DB\n	// WARNING: directory with attachements must be world writeable (chmod 777) on most servers\n	// to allow webserver to write to it. Also mention -> if you delete the attachement only\n	// in filesystem, the reference in the guestbook still will be present and point to nothing\n	// 2nd: If you upload a file with same name as a file allready existing in the directory,\n	// old file will be overwritten without further notice\n	\$attach_in_fs=$attachfs;\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// complete path to directory, where attachements should be stored\n	\$path_attach = \"".$scriptpath."/attachements\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// url to directory with attachements\n	\$url_attach = \"".$scripturl."/attachements\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// complete path to directory, where uploaded files should temporary be copied to\n	// (PHP has to have write permissions on this directory)\n	// Needed if open_basedir restriction is in effect. If your PHP instance can\n	// access the default upload directory, you don't need to set it\n"))
		die($msgs["cfgferror"]);
	if(isset($openbasedir))
	{
		if(!fwrite($cfgfile,"	\$path_tempdir = \"".$scriptpath."/admin/temp\";\n"))
			die($msgs["cfgferror"]);
	}
	else
	{
		if(!fwrite($cfgfile,"	// \$path_tempdir = \"".$scriptpath."/admin/temp\";\n"))
			die($msgs["cfgferror"]);
	}
	if(isset($realip))
		$userealip="true";
	else
		$userealip="false";
	if(!fwrite($cfgfile,"	// Set to true if you want to try to get the real IP of the user.\n	// Please note: This may not work for all HTTPDs.\n	\$try_real_ip=$userealip;\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// please enter all fileextension your server uses for PHP scripts here\n	\$php_fileext=array(\"php\",\"php3\",\"phtml\",\"php4\");\n"))
		die($msgs["cfgferror"]);
	if(isset($smtpmail))
		$usesmtp="true";
	else
		$usesmtp="false";
	if(!fwrite($cfgfile,"    // For sending emails through SMTP server instead of PHP mail function set this to true\n	\$use_smtpmail = $usesmtp;\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"    // SMTP Server to use\n    \$smtpserver = \"$smtpserver\";\n    // SMTP Port\n    \$smtpport = 25;\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"    // Senderdomain (set this to your domain)\n    \$smtpsenderdomain = \"$smtpdomain\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"    // SMTP Server needs authentication\n    \$smtpauth = $smtpauth;\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"    // Authentication username\n    \$smtpuser = \"$smtpuser\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// Authentication password\n	\$smtppasswd = \"$smtppwd\";\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// minimal fontsize to use for dropdown BBcode button\n	\$minfontsize=-10;\n	// maximal fontsize to use for dropdown BBcode button\n	\$maxfontsize=10;\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// set to false if file upload is disabled in php.ini\n	\$upload_avail=true;\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// set this to true, if you are using PHP 4.1.0 or greater (has to be set to true for\n	// PHP 4.2.0 or greater)\n	\$new_global_handling=$new_global_handling;\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"	// leaving this to false is the best\n    \$testmode = false;\n"))
		die($msgs["cfgferror"]);
	if(!fwrite($cfgfile,"// end edit\n// you are not allowed to edit beyond this point\n	require_once(\$path_simpnews.'/includes/global.inc');\n?>"))
		die($msgs["cfgferror"]);
	fclose($cfgfile);
	chmod($configfile,0444);
	$notes="";
	if(!file_exists($scriptpath."/gfx/emoticons"))
	{
		$notes.="<li>".sprintf($msgs["notexists"],$scriptpath."/gfx/emoticons");
		$notes.="<br><input type=\"checkbox\" name=\"dircreate[]\" value=\"".$scriptpath."/gfx/emoticons\"> ".$msgs["correct"];
	}
	else
	{
		if(!is_writeable($scriptpath."/gfx/emoticons"))
		{
			$notes.="<li>".sprintf($msgs["notwriteable"],$scriptpath."/gfx/emoticons");
			$notes.="<br>".sprintf($msgs["uploadnotworking"],"Smilies");
			$notes.="<br><input type=\"checkbox\" name=\"dirmod[]\" value=\"".$scriptpath."/gfx/emoticons\"> ".$msgs["correct"];
		}
	}
	if(!file_exists($scriptpath."/gfx/icons"))
	{
		$notes.="<li>".sprintf($msgs["notexists"],$scriptpath."/gfx/icons");
		$notes.="<br><input type=\"checkbox\" name=\"dircreate[]\" value=\"".$scriptpath."/gfx/icons\"> ".$msgs["correct"];
	}
	else
	{
		if(!is_writeable($scriptpath."/gfx/icons"))
		{
			$notes.="<li>".sprintf($msgs["notwriteable"],$scriptpath."/gfx/icons");
			$notes.="<br>".sprintf($msgs["uploadnotworking"],"icons");
			$notes.="<br><input type=\"checkbox\" name=\"dirmod[]\" value=\"".$scriptpath."/gfx/icons\"> ".$msgs["correct"];
		}
	}
	if(isset($fsattach))
	{
		if(!file_exists($scriptpath."/attachements"))
		{
			$notes.="<li>".sprintf($msgs["notexists"],$scriptpath."/attachements");
			$notes.="<br>".sprintf($msgs["uploadnotworking"],$msgs["attachements"]);
			$notes.="<br><input type=\"checkbox\" name=\"dircreate[]\" value=\"".$scriptpath."/attachements\"> ".$msgs["correct"];
		}
		else
		{
			if(!is_writeable($scriptpath."/attachements"))
			{
				$notes.="<li>".sprintf($msgs["notwriteable"],$scriptpath."/attachements");
				$notes.="<br>".sprintf($msgs["uploadnotworking"],$msgs["attachements"]);
				$notes.="<br><input type=\"checkbox\" name=\"dirmod[]\" value=\"".$scriptpath."/attachements\"> ".$msgs["correct"];
			}
		}
	}
	if(isset($openbasedir))
	{
		if(!file_exists($scriptpath."/admin/temp"))
		{
			$notes.="<li>".sprintf($msgs["notexists"],$scriptpath."/admin/temp");
			$notes.="<br>".sprintf($msgs["uploadnotworking"],$msgs["files"]);
			$notes.="<br><input type=\"checkbox\" name=\"dircreate[]\" value=\"".$scriptpath."/admin/temp\"> ".$msgs["correct"];
		}
		else
		{
			if(!is_writeable($scriptpath."/admin/temp"))
			{
				$notes.="<li>".sprintf($msgs["notwriteable"],$scriptpath."/admin/temp");
				$notes.="<br>".sprintf($msgs["uploadnotworking"],$msgs["files"]);
				$notes.="<br><input type=\"checkbox\" name=\"dirmod[]\" value=\"".$scriptpath."/admin/temp\"> ".$msgs["correct"];
			}
		}
	}
	echo "<div align=\"center\">";
	echo $msgs["cfgwritten"];
	echo "</div>";
	if($notes)
	{
		echo "<br><br><div align=\"center\"><form method=\"post\" action=\"mkconfig.php\">";
		echo "<input type=\"hidden\" name=\"lang\" value=\"$lang\">";
		echo "<input type=\"hidden\" name=\"mode\" value=\"correct\">";
		echo $msgs["notes"].":<ul>";
		echo $notes;
		echo "</ul>";
		echo "<input type=\"submit\" value=\"OK\"></form>";
		echo "</div>";
	}
	echo "</body></html>";
	}
	if($mode=="correct")
	{
		echo "<div align=\"center\"><ul>";
		if(isset($dirmod))
		{
			while(list($null, $actdir) = each($HTTP_POST_VARS["dirmod"]))
			{
				chmod($actdir,0777);
				if(!$testfile=fopen($actdir."/tst.txt","w"))
				{
					echo "<li>".sprintf($msgs["notwriteable"],$actdir);
					echo "<br>".$msgs["cantcorrect"];
				}
				else
				{
					fclose($testfile);
					unlink($actdir."/tst.txt");
					echo "<li>".sprintf($msgs["corrected"],$actdir);
				}
			}
		}
		if(isset($dircreate))
		{
			while(list($null, $actdir) = each($HTTP_POST_VARS["dircreate"]))
			{
				mkdir($actdir,0777);
				if(!is_writeable($actdir))
				{
					echo "<li>".sprintf($msgs["notwriteable"],$actdir);
					echo "<br>".$msgs["cantcorrect"];
				}
				else
				{
					echo "<li>".sprintf($msgs["corrected"],$actdir);
				}
			}
		}
		echo "</ul></div>";
	}
}
function get_en_msgs()
{
	$msgs=array(
		"prelude"=>"Create config.php for SimpNews.<br>In order for this script to work, PHP has to have write access to the parent directory.",
		"dbhost"=>"Databasehost",
		"dnmame"=>"Databasename",
		"dbuser"=>"Databaseuser",
		"dbpwd"=>"Databasepassword",
		"dbprefix"=>"Tableprefix",
		"deflang"=>"default language",
		"admlang"=>"default language for admin interface",
		"scripturl"=>"URL where scripts reside",
		"scriptpath"=>"path where scripts reside",
		"sesstype"=>"type of sessionhandling",
		"sesscookie"=>"using cookie",
		"sessurl"=>"POST/GET",
		"htaccess"=>"by HTTPD (htaccess)",
		"sitename"=>"Website name",
		"cfgferror"=>"error creating config.php",
		"enable"=>"enable",
		"sesscookietime"=>"Timeout for session cookie in admin interface",
		"sec"=>"seconds",
		"pwrecov"=>"password recovery",
		"maxattach"=>"max. filesize for attachements by admin",
		"contentcharset"=>"Charset for content encoding",
		"cfgwritten"=>"config.php generated",
		"attachfs"=>"Store attachements in filesystem and not DB",
		"openbasedir"=>"open_basedir restriction for PHP is",
		"enabled"=>"enabled",
		"smtpmail"=>"Send emails through SMTP server rather than PHP mail function",
		"smtpserver"=>"Name of SMTP server",
		"smtpdomain"=>"Domain for sending through SMTP server",
		"smtpauth"=>"Authentication to send emails through SMTP server",
		"needed"=>"needed",
		"notneeded"=>"not needed",
		"smtpuser"=>"username for SMTP server",
		"smtppwd"=>"password for SMTP server",
		"notes"=>"Notes",
		"notexists"=>"%s does not exist.",
		"notwriteable"=>"%s is not writeable by PHP.",
		"uploadnotworking"=>"Upload of %s will not work.",
		"correct"=>"try to correct problem",
		"cantcorrect"=>"Couldn't be corrected. Please correct by hand.",
		"corrected"=>"Problem with %s corrected.",
		"files"=>"files",
		"attachements"=>"attachements",
		"correctfirst"=>"Please correct this and submit form again.",
		"realip"=>"Try do determine real IP of users"
	);
	return $msgs;
}
function get_de_msgs()
{
	$msgs=array(
		"prelude"=>"Erzeugen der config.php f&uuml;r SimpNews.<br>Damit dieses Skript die Datei erstellen kann, ben&ouml;tigt PHP Schreibzugriff auf das &uuml;bergeordnete Verzeichnis.",
		"dbhost"=>"Hostname des Datenbankservers",
		"dbname"=>"Datenbankname",
		"dbuser"=>"Benutzername f&uuml;r Datenbank",
		"dbpwd"=>"Passwort f&uuml;r Datenbank",
		"dbprefix"=>"Pr&auml;fix f&uuml;r Datenbanktabellen",
		"deflang"=>"voreingestellte Sprache",
		"admlang"=>"voreingestellte Sprache f&uuml;r Administrationsoberfl&auml;che",
		"scripturl"=>"URL der Skripte",
		"scriptpath"=>"Verzeichnis, in dem die Skripte liegen",
		"sesstype"=>"Art des Sessionhandlings",
		"sesscookie"=>"per Cookie",
		"sessurl"=>"POST/GET",
		"htaccess"=>"durch den Webserver (htaccess)",
		"sitename"=>"Name der Website",
		"cfgferror"=>"Fehler beim Erzeugen der config.php",
		"enable"=>"aktivieren",
		"sesscookietime"=>"Timeout f&uuml;r das Sessioncookie in der Administrationsoberfl&auml;che",
		"sec"=>"Sekunden",
		"pwrecov"=>"Passwortermittlung",
		"maxattach"=>"max. Filegr&ouml;sse f&uuml;r Dateianh&auml;nge der Admins",
		"contentcharset"=>"Contentcharset",
		"cfgwritten"=>"config.php erzeugt",
		"attachfs"=>"Dateianh&auml;nge im Dateisystem und nicht in der Datenbank ablegen",
		"openbasedir"=>"Die open_basedir Einschr&auml;nkung f&uuml;r PHP ist",
		"enabled"=>"aktiviert",
		"smtpmail"=>"E-Mails an Stelle der PHP Mailfunktion &uuml;ber SMTP-Server versenden",
		"smtpserver"=>"Name des SMTP-Servers",
		"smtpdomain"=>"Domain, die beim Versand &uuml;ber SMTP-Server verwendet wird",
		"smtpauth"=>"Authentifizierung, um E-Mails &uuml;ber den SMTP-Server zu versenden",
		"needed"=>"ben&ouml;tigt",
		"notneeded"=>"nicht ben&ouml;tigt",
		"smtpuser"=>"Benutzername zur Anmeldung am SMTP-Server",
		"smtppwd"=>"Passwort zur Anmledung am SMTP-Server",
		"notes"=>"Anmerkungen",
		"notexists"=>"%s existiert nicht.",
		"notwriteable"=>"PHP hat keine Schreibrechte auf %s.",
		"uploadnotworking"=>"Der Upload von %s funktioniert dann nicht.",
		"correct"=>"versuchen das Problem zu beheben",
		"cantcorrect"=>"Problem konnte nicht behoben werden. Bitte von Hand beheben",
		"corrected"=>"Problem mit %s behoben",
		"files"=>"Dateien",
		"attachements"=>"Dateianh&auml;ngen",
		"correctfirst"=>"Bitte beheben und Formular erneut senden.",
		"realip"=>"Versuchen die echte IP-Adresse von Benutzern zu ermitteln"
	);
	return $msgs;
}
function determinedomain($hostname)
{
	$fqdn=explode(".",$hostname);
	$domainlevel=sizeof($fqdn);
	if($domainlevel>4 || $domainlevel<3)
		return $hostname;
	if($domainlevel==3)
	{
		return $fqdn[1].".".$fqdn[2];
	}
	if($domainlevel==4)
	{
		return $fqdn[2].".".$fqdn[3];
	}
	return $hostname;
}
?>