<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
echo "<div class=\"bottombox\" align=\"center\">";
if(($userdata["rights"]>2)||($shutdown<1))
	echo "<a href=\"".do_url_session("index.php?lang=$lang")."\">$l_mainmenu</a><br>";
$usermode=$l_admin_rights[$admin_rights];
if($user_loggedin)
{
	echo "$l_loggedinas <i>".$userdata["username"]."</i> ($usermode)&nbsp;&nbsp;";
	if($enable_htaccess)
		echo "<a href=\"javascript:alert('$l_notavail_htaccess2')\">";
	else
		echo "<a href=\"".do_url_session("logout.php?lang=$lang")."\">";
	echo "$l_logout</a><br>";
}
echo "</div><hr><div class=\"copyright\" align=\"center\">$copyright_url $copyright_note</div>";
if($user_loggedin)
{
	$acttime=time();
	$acttime=$acttime-($servertimezone*60*60);
	$acttime=$acttime+($displaytimezone*60*60);
	$displaytime=date($l_datefrmt_main,$acttime);
	echo "<table class=\"timebox\" align=\"center\">";
	echo "<tr><td align=\"center\" class=\"timebox\">";
	echo "$l_timeonserver: $displaytime (GMT";
	if($displaytimezone>0)
		echo "+$displaytimezone";
	else if($displaytimezone<0)
		echo "$displaytimezone";
	echo ")";
	echo "</td></tr></table>";
	if($usemenubar==1)
	{
		if(is_opera() || is_ns4() || is_gecko() || is_msie())
		{
			include_once('./includes/coolmenu.inc');
			make_menu();
		}
	}
}
?>
</body></html>