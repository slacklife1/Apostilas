<?php
require('../config.php');
require('./functions.php');
?>
<html><body>
<div align="center"><h3>SimpNews: Upgrade from 1.11 to 1.20</h3></div>
<br>
<?php
echo "Upgrading tables...<br>";
$sql = "ALTER TABLE ".$tableprefix."_layout ";
$sql.= "add newstickerbgcolor varchar(7) NOT NULL DEFAULT '#cccccc' ,";
$sql.= "add newstickerfontcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.= "add newstickerfont varchar(240) NOT NULL DEFAULT 'Verdana' ,";
$sql.= "add newstickerfontsize tinyint(2) unsigned NOT NULL DEFAULT '12' ,";
$sql.= "add newstickerhighlightcolor varchar(7) NOT NULL DEFAULT '#0000ff' ,";
$sql.= "add newstickerheight int(10) unsigned NOT NULL DEFAULT '20' ,";
$sql.= "add newstickerwidth int(10) unsigned NOT NULL DEFAULT '300' ,";
$sql.= "add newstickerscrollspeed tinyint(2) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "add newstickerscrolldelay int(10) unsigned NOT NULL DEFAULT '30' ,";
$sql.= "add newstickermaxdays int(10) NOT NULL DEFAULT '0' ,";
$sql.= "add newstickermaxentries int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "add newsscrollerbgcolor varchar(7) NOT NULL DEFAULT '#cccccc' ,";
$sql.= "add newsscrollerfontcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.= "add newsscrollerfont varchar(240) NOT NULL DEFAULT 'Verdana' ,";
$sql.= "add newsscrollerfontsize tinyint(2) unsigned NOT NULL DEFAULT '12' ,";
$sql.= "add newsscrollerheight int(10) unsigned NOT NULL DEFAULT '300' ,";
$sql.= "add newsscrollerwidth int(10) unsigned NOT NULL DEFAULT '200' ,";
$sql.= "add newsscrollerscrollspeed tinyint(2) unsigned NOT NULL DEFAULT '1' ,";
$sql.= "add newsscrollerscrolldelay int(10) unsigned NOT NULL DEFAULT '100' ,";
$sql.= "add newsscrollerscrollpause int(10) unsigned NOT NULL DEFAULT '2000' ,";
$sql.= "add newsscrollermaxdays int(10) NOT NULL DEFAULT '0' ,";
$sql.= "add newsscrollermaxentries int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "add newsscrollertype tinyint(4) unsigned NOT NULL DEFAULT '4' ,";
$sql.= "add newsscrollerbgimage varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "add newsscrollerfgimage varchar(240) NOT NULL DEFAULT '' ,";
$sql.= "add newsscrollermousestop tinyint(1) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "add newsscrollermaxchars int(10) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "add newstickertarget varchar(80) NOT NULL DEFAULT '_self' ,";
$sql.= "add newsscrollertarget varchar(80) NOT NULL DEFAULT '_self', ";
$sql.= "add newsscrollerxoffset tinyint(4) unsigned NOT NULL DEFAULT '0' ,";
$sql.= "add newsscrolleryoffset tinyint(4) unsigned NOT NULL DEFAULT '0'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_layout");
?>
<br><div align="center">Installation done.<br>Please remove install.php, upgrade*.php and fill_freemailer.php from server</div>
<div align="center">Now you can login to the <a href="index.php">admininterface</a></div>
</html></body>