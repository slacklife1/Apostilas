<?php
require('../config.php');
require('./functions.php');
?>
<html><body>
<div align="center"><h3>SimpNews: Upgrade from 1.44 to 1.45</h3></div>
<br>
<?php
echo "Upgrading tables...<br>";
$sql = "ALTER TABLE ".$tableprefix."_layout ";
$sql.= "add linkcolor varchar(7) NOT NULL DEFAULT '#696969' ,";
$sql.= "add vlinkcolor varchar(7) NOT NULL DEFAULT '#696969' ,";
$sql.= "add alinkcolor varchar(7) NOT NULL DEFAULT '#696969' ,";
$sql.= "add morelinkcolor varchar(7) NOT NULL DEFAULT '#191970' ,";
$sql.= "add morevlinkcolor varchar(7) NOT NULL DEFAULT '#191970' ,";
$sql.= "add morealinkcolor varchar(7) NOT NULL DEFAULT '#191970' ,";
$sql.= "add catlinkcolor varchar(7) NOT NULL DEFAULT '#F0FFFF' ,";
$sql.= "add catvlinkcolor varchar(7) NOT NULL DEFAULT '#F0FFFF' ,";
$sql.= "add catalinkcolor varchar(7) NOT NULL DEFAULT '#F0FFFF' ,";
$sql.= "add commentlinkcolor varchar(7) NOT NULL DEFAULT '#191970' ,";
$sql.= "add commentvlinkcolor varchar(7) NOT NULL DEFAULT '#191970' ,";
$sql.= "add commentalinkcolor varchar(7) NOT NULL DEFAULT '#191970' ,";
$sql.= "add attachlinkcolor varchar(7) NOT NULL DEFAULT '#CD5C5C' ,";
$sql.= "add attachvlinkcolor varchar(7) NOT NULL DEFAULT '#CD5C5C' ,";
$sql.= "add attachalinkcolor varchar(7) NOT NULL DEFAULT '#CD5C5C' ,";
$sql.= "add pagenavlinkcolor varchar(7) NOT NULL DEFAULT '#FFF0C0' ,";
$sql.= "add pagenavvlinkcolor varchar(7) NOT NULL DEFAULT '#FFF0C0' ,";
$sql.= "add pagenavalinkcolor varchar(7) NOT NULL DEFAULT '#FFF0C0' ,";
$sql.= "add colorscrollbars tinyint(1) NOT NULL DEFAULT '1' ,";
$sql.= "add sbfacecolor varchar(7) NOT NULL DEFAULT '#94AAD6' ,";
$sql.= "add sbhighlightcolor varchar(7) NOT NULL DEFAULT '#AFEEEE' ,";
$sql.= "add sbshadowcolor varchar(7) NOT NULL DEFAULT '#ADD8E6' ,";
$sql.= "add sbdarkshadowcolor varchar(7) NOT NULL DEFAULT '#4682B4' ,";
$sql.= "add sb3dlightcolor varchar(7) NOT NULL DEFAULT '#1E90FF' ,";
$sql.= "add sbarrowcolor varchar(7) NOT NULL DEFAULT '#0000ff' ,";
$sql.= "add sbtrackcolor varchar(7) NOT NULL DEFAULT '#E0FFFF' ,";
$sql.= "add snsel_bgcolor varchar(7) NOT NULL DEFAULT '#DCDCDC' ,";
$sql.= "add snsel_fontcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.= "add snsel_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.= "add snsel_fontsize varchar(10) NOT NULL DEFAULT '10pt' ,";
$sql.= "add snsel_fontstyle varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.= "add snsel_fontweight varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.= "add snsel_borderstyle varchar(20) NOT NULL DEFAULT 'none' ,";
$sql.= "add snsel_bordercolor varchar(7) NOT NULL DEFAULT '' ,";
$sql.= "add snsel_borderwidth varchar(20) NOT NULL DEFAULT '' ,";
$sql.= "add morelinkfontsize varchar(20) NOT NULL DEFAULT '8pt' ,";
$sql.= "add sninput_bgcolor varchar(7) NOT NULL DEFAULT '#DCDCDC' ,";
$sql.= "add sninput_fontcolor varchar(7) NOT NULL DEFAULT '#000000' ,";
$sql.= "add sninput_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.= "add sninput_fontsize varchar(20) NOT NULL DEFAULT '10pt' ,";
$sql.= "add sninput_fontstyle varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.= "add sninput_fontweight varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.= "add sninput_borderstyle varchar(20) NOT NULL DEFAULT 'solid' ,";
$sql.= "add sninput_borderwidth varchar(20) NOT NULL DEFAULT 'thin' ,";
$sql.= "add sninput_bordercolor varchar(7) NOT NULL DEFAULT '#696969' ,";
$sql.= "add snisb_facecolor varchar(7) NOT NULL DEFAULT '#708090' ,";
$sql.= "add snisb_highlightcolor varchar(7) NOT NULL DEFAULT '#A9A9A9' ,";
$sql.= "add snisb_shadowcolor varchar(7) NOT NULL DEFAULT '#191970' ,";
$sql.= "add snisb_darkshadowcolor varchar(7) NOT NULL DEFAULT '#000080' ,";
$sql.= "add snisb_3dlightcolor varchar(7) NOT NULL DEFAULT '#F5FFFA' ,";
$sql.= "add snisb_arrowcolor varchar(7) NOT NULL DEFAULT '#c0c0c0' ,";
$sql.= "add snisb_trackcolor varchar(7) NOT NULL DEFAULT '#b0b0b0' ,";
$sql.= "add snbutton_bgcolor varchar(7) NOT NULL DEFAULT '#94AAD6' ,";
$sql.= "add snbutton_fontcolor varchar(7) NOT NULL DEFAULT '#FFFAF0' ,";
$sql.= "add snbutton_font varchar(240) NOT NULL DEFAULT 'Verdana, Geneva, Arial, Helvetica, sans-serif' ,";
$sql.= "add snbutton_fontsize varchar(20) NOT NULL DEFAULT '9pt' ,";
$sql.= "add snbutton_fontstyle varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.= "add snbutton_fontweight varchar(20) NOT NULL DEFAULT 'normal' ,";
$sql.= "add snbutton_borderstyle varchar(20) NOT NULL DEFAULT 'ridge' ,";
$sql.= "add snbutton_borderwidth varchar(20) NOT NULL DEFAULT 'thin' ,";
$sql.= "add snbutton_bordercolor varchar(7) NOT NULL DEFAULT '#483D8B' ,";
$sql.= "add eventlinkcolor varchar(7) NOT NULL DEFAULT '#696969' ,";
$sql.= "add eventalinkcolor varchar(7) NOT NULL DEFAULT '#696969' ,";
$sql.= "add eventvlinkcolor varchar(7) NOT NULL DEFAULT '#696969' ,";
$sql.= "add eventlinkfontsize varchar(20) NOT NULL DEFAULT '9pt' ,";
$sql.= "add actionlinkcolor varchar(7) NOT NULL DEFAULT '#F0FFFF' ,";
$sql.= "add actionvlinkcolor varchar(7) NOT NULL DEFAULT '#F0FFFF' ,";
$sql.= "add actionalinkcolor varchar(7) NOT NULL DEFAULT '#F0FFFF'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_layout");
?>
<br><div align="center">Installation done.<br>Please remove install.php, upgrade*.php and fill_freemailer.php from server</div>
<div align="center">Now you can login to the <a href="index.php">admininterface</a></div>
</html></body>