<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('../config.php');
require_once('./auth.php');
if(!isset($lang) || !$lang)
	$lang=$admin_lang;
include_once('./language/lang_'.$lang.'.php');
$page_title=$l_subscribers;
require_once('./heading.php');
$sql = "select * from ".$tableprefix."_settings where (settingnr=1)";
if(!$result = mysql_query($sql, $db))
    die("Could not connect to the database.");
if ($myrow = mysql_fetch_array($result))
	$maxconfirmtime=$myrow["maxconfirmtime"];
else
	$maxconfirmtime=0;
$dateformat="Y-m-d H:i:s";
?>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<?php
if(isset($mode))
{
	if($mode=="impfile")
	{
		if(($admin_rights < 2) || (!$upload_avail))
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr><td class="headingrow" align="center" colspan="2"><b><?php echo $l_importemaillist?></b></td></tr>
<?php
		$errors=0;
		if(is_uploaded_file($HTTP_POST_FILES['maillist']['tmp_name']))
		{
			$filename=$HTTP_POST_FILES['maillist']['name'];
			$filesize=$HTTP_POST_FILES['maillist']['size'];
			$filedata="";
			if($filesize>0)
			{
				if(isset($path_tempdir) && $path_tempdir)
				{
					if(!move_uploaded_file ($maillist, $path_tempdir."/".$filename))
							die("<tr class=\"errorrow\"><td align=\"center\">unable to move uploaded file to $path_tempdir");
					$orgfile=$path_tempdir."/".$filename;
				}
				else
					$orgfile=$maillist;
			}
		}
		if(!isset($filename) || ($filesize<1))
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_nolistfile</td></tr>";
			$errors=1;
		}
		if(($listtype==1) && (!$sepchar))
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_nosepchar</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			if($listtype==1)
			{
				$imported=import_seplist($orgfile, $newslang, $emailtype, $sepchar);
			}
			else
			{
				$imported=import_single_line($orgfile, $newslang, $emailtype);
			}
			echo "<tr class=\"displayrow\" align=\"center\"><td>";
			echo str_replace("{imported}",$imported,$l_listimported);
			echo "</td></tr></table></td></tr></table>";
			echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?lang=$lang")."\">$l_subscribers</a></div>";
		}
		else
		{
			echo "<tr class=\"actionrow\" align=\"center\"><td>";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
	}
	if($mode=="import")
	{
		if(($admin_rights < 2) || (!$upload_avail))
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr><td class="headingrow" align="center" colspan="2"><b><?php echo $l_importemaillist?></b></td></tr>
<form <?php if($upload_avail) echo "enctype=\"multipart/form-data\""?> method="post" action="<?php echo $act_script_url?>">
<input type="hidden" name="lang" value="<?php echo $lang?>">
<input type="hidden" name="mode" value="impfile">
<?php
	if(is_konqueror())
		echo "<tr><td></td></tr>";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_emaillistfile?>:</td>
<td><input class="sninput" type="file" name="maillist"></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_listfiletype?>:</td>
<td><input type="radio" name="listtype" value="0" checked> <?php echo $l_emailperline?><hr>
<input type="radio" name="listtype" value="1"> <?php echo $l_charsep?>:
<input class="sninput" type="text" size="1" maxlength="1" name="sepchar" value=","></td></tr>
<tr class="displayrow"><td align="right" width="30%"><?php echo $l_language?>:</td>
<td><?php echo language_select("","newslang","../language")?></td></tr>
<tr class="displayrow"><td align="right" valign="top"><?php echo $l_emailtype?>:</td><td>
<?php
for($i=0;$i<count($l_emailtypes);$i++)
{
	echo "<input type=\"radio\" name=\"emailtype\" value=\"$i\"";
	if($i==0)
		echo " checked";
	echo "> ".$l_emailtypes[$i]."<br>";
}
?>
</td></tr>
<tr class="actionrow"><td align="center" colspan="2">
<input class="snbutton" type="submit" value="<?php echo $l_import?>"></td></tr>
<?
		echo "</td></tr></table></td></tr></table>";
		echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?lang=$lang")."\">$l_subscribers</a></div>";
	}
	if($mode=="display")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?
		$sql = "select * from ".$tableprefix."_subscriptions where (subscriptionnr=$input_subscriptionnr)";
		if(!$result = mysql_query($sql, $db))
		    die("<tr bgcolor=\"#cccccc\"><td>Could not connect to the database.");
		if (!$myrow = mysql_fetch_array($result))
			die("<tr bgcolor=\"#cccccc\"><td>no such entry");
?>
<tr class="displayrow"><td align="right" width="30%"><?php echo $l_email?>:</td><td><?php echo $myrow["email"]?></td></tr>
<tr class="displayrow"><td align="right" width="30%"><?php echo $l_confirmed?>:</td><td>
<?php if($myrow["confirmed"]==1) echo "<img src=\"gfx/checkmark.gif\" border=\"0\">"?></td></tr>
<tr class="displayrow"><td align="right" width="30%"><?php echo $l_emailtype?>:</td><td>
<?php echo $l_emailtypes[$myrow["emailtype"]]?></td></tr>
<tr class="displayrow"><td align="right"><?php echo $l_subscriptiondate?>:</td><td><?php echo $myrow["enterdate"]?></td></tr>
</table></td></tr></table>
<?php
		echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?lang=$lang")."\">$l_subscribers</a></div>";
	}
	if($mode=="new")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<tr><td class="headingrow" align="center" colspan="2"><b><?php echo $l_newsubscriber?></b></td></tr>
<form method="post" action="<?php echo $act_script_url?>"><input type="hidden" name="lang" value="<?php echo $lang?>">
<?php
	if(is_konqueror())
		echo "<tr><td></td></tr>";
	if($sessid_url)
		echo "<input type=\"hidden\" name=\"$sesscookiename\" value=\"$url_sessid\">";
?>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_email?>:</td>
<td><input class="sninput" type="text" name="email" size="40" maxlength="240"></td></tr>
<tr class="inputrow"><td align="right" width="30%"><?php echo $l_language?>:</td>
<td><?php echo language_select("","newslang","../language")?></td></tr>
<tr class="inputrow"><td align="right" valign="top"><?php echo $l_emailtype?>:</td><td>
<?php
for($i=0;$i<count($l_emailtypes);$i++)
{
	echo "<input type=\"radio\" name=\"emailtype\" value=\"$i\"";
	if($i==0)
		echo " checked";
	echo "> ".$l_emailtypes[$i]."<br>";
}
?>
</td></tr>
<tr class="actionrow"><td align="center" colspan="2">
<input type="hidden" name="mode" value="add">
<input class="snbutton" type="submit" value="<?php echo $l_add?>"></td></tr>
<?
		echo "</td></tr></table></td></tr></table>";
		echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?lang=$lang")."\">$l_subscribers</a></div>";
	}
	if($mode=="add")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$errors=0;
		if(!isset($emailtype))
			$emailtype=1;
		if(!isset($email) || !$email)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_noemail</td></tr>";
			$errors=1;
		}
		else if(!validate_email($email))
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			echo "$l_noemail</td></tr>";
			$errors=1;
		}
		if($errors==0)
		{
			$sql="select * from ".$tableprefix."_subscriptions where email='$email'";
			if(!$result = mysql_query($sql, $db))
				die("<tr bgcolor=\"#cccccc\" align=\"center\"><td align=\"center\" colspan=\"2\">Could not connect to the database.");
			if($myrow=mysql_fetch_array($result))
			{
					echo "<tr class=\"errorrow\"><td align=\"center\">";
					echo "$l_subscriptionexists</td></tr>";
					$errors=1;
			}
		}
		if($errors==0)
		{
			$actdate = date("Y-m-d H:i:s");
			$confirmed=1;
			$subscribeid=0;
			do{
				$maximum=9999999999;
				if($maximum>mt_getrandmax())
					$maximum=mt_getrandmax();
				mt_srand((double)microtime()*1000000);
				$unsubscribeid=mt_rand(10000,$maximum);
				$sql = "select * from ".$tableprefix."_subscriptions where unsubscribeid=$unsubscribeid";
				if(!$result = mysql_query($sql, $db))
					die("<tr class=\"errorrow\" align=\"center\"><td align=\"center\" colspan=\"2\">Could not connect to the database.");
			}while($myrow=mysql_fetch_array($result));
			$sql = "insert into ".$tableprefix."_subscriptions (email, confirmed, subscribeid, enterdate, emailtype, language, unsubscribeid) ";
			$sql.= "values ('$email', $confirmed, $subscribeid, '$actdate', $emailtype, '$newslang', $unsubscribeid)";
			if(!$result = mysql_query($sql, $db))
				die("<tr class=\"errorrow\" align=\"center\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".mysql_error());
			echo "<tr class=\"displayrow\" align=\"center\"><td>";
			echo "$l_subscriberadded";
			echo "</td></tr></table></td></tr></table>";
			echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?mode=new&lang=$lang")."\">$l_newsubscriber</a></div>";
			echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?lang=$lang")."\">$l_subscribers</a></div>";
		}
		else
		{
			echo "<tr class=\"actionrow\" align=\"center\"><td>";
			echo "<a href=\"javascript:history.back()\">$l_back</a>";
			echo "</td></tr></table></td></tr></table>";
		}
	}
	if($mode=="cleanup")
	{
		if($admin_rights < 2)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?
		$actdate = date("Y-m-d H:i:s");
		$confirmtime=($maxconfirmtime*24)+1;
		$sql = "delete from ".$tableprefix."_subscriptions where confirmed=0 and enterdate<=DATE_SUB('$actdate', INTERVAL $confirmtime HOUR)";
		if(!$result = mysql_query($sql, $db))
			die("<tr class=\"errorrow\" align=\"center\"><td align=\"center\" colspan=\"2\">Could not connect to the database.".mysql_error());
		echo "<tr class=\"displayrow\" align=\"center\"><td>";
		echo "$l_cleanedup<br>";
		echo "</td></tr></table></td></tr></table>";
		echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?lang=$lang")."\">$l_subscribers</a></div>";
	}
	if($mode=="delete")
	{
		if($admin_rights < 3)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$deleteSQL = "delete from ".$tableprefix."_subscriptions where (subscriptionnr=$input_subscriptionnr)";
		$success = mysql_query($deleteSQL);
		if (!$success)
			die("<tr class=\"errorrow\"><td>$l_cantdelete.");
		echo "<tr class=\"displayrow\" align=\"center\"><td>";
		echo "$l_deleted<br>";
		echo "</td></tr></table></td></tr></table>";
		echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?lang=$lang")."\">$l_subscribers</a></div>";
	}
	if($mode=="setmanual")
	{
		if($admin_rights < 3)
		{
			echo "<tr class=\"errorrow\"><td align=\"center\">";
			die("$l_functionnotallowed");
		}
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
		$actdate=date("Y-m-d H:i:s");
		$deleteSQL = "update ".$tableprefix."_subscriptions set lastmanual='$actdate' where (subscriptionnr=$input_subscriptionnr)";
		$success = mysql_query($deleteSQL);
		if (!$success)
			die("<tr class=\"errorrow\"><td>$l_cantupdate.");
		echo "<tr class=\"displayrow\" align=\"center\"><td>";
		echo "$l_updated<br>";
		echo "</td></tr></table></td></tr></table>";
		echo "<div class=\"bottombox\" align=\"center\"><a href=\"".do_url_session("$act_script_url?lang=$lang")."\">$l_subscribers</a></div>";
	}
}
else
{
?>
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?
	if($admin_rights < 2)
	{
		echo "<tr class=\"errorrow\"><td align=\"center\">";
		die("$l_functionnotallowed");
	}
?>
<tr class="actionrow">
<td colspan="6" align="center">
<a href="<?php echo do_url_session("$act_script_url?mode=cleanup&lang=$lang")?>"><?php echo $l_cleanupoverdue?></a>&nbsp;&nbsp;
<a href="<?php echo do_url_session("$act_script_url?mode=new&lang=$lang")?>"><?php echo $l_newsubscriber?></a>
<?php
if($upload_avail)
{
	echo "&nbsp;&nbsp;";
	echo "<a href=\"".do_url_session("$act_script_url?mode=import&lang=$lang")."\">$l_importemaillist</a>";
}
?>
</td></tr>
</table></td></tr></table>
<table align="center" width="80%" CELLPADDING="1" CELLSPACING="0" border="0" valign="top">
<tr><TD BGCOLOR="#000000">
<table align="center" width="100%" border="0" cellspacing="1" cellpadding="1">
<?php
// Display list of actual subscriptions
	$sql = "select * from ".$tableprefix."_subscriptions order by enterdate desc";
	if(!$result = mysql_query($sql, $db))
	    die("Could not connect to the database.");
?>
<tr class="rowheadings">
<td align="center" width="40%"><b><?php echo $l_email?></b></td>
<td align="center" width="5%"><b><?php echo $l_language?></b></td>
<td align="center" width="5%"><b><?php echo $l_confirmed?></b></td>
<td align="center" width="20%"><b><?php echo $l_date?></b></td>
<td align="center" width="10%"><b><?php echo $l_lastmanual?></b></td>
<td width="30%">&nbsp;</td></tr>
<?php
	if (!$myrow = mysql_fetch_array($result))
	{
		echo "<tr class=\"displayrow\"><td align=\"center\" colspan=\"6\">";
		echo $l_noentries;
		echo "</td></tr></table></td></tr></table>";
	}
	else
	{
		do {
			$act_id=$myrow["subscriptionnr"];
			echo "<tr class=\"displayrow\">";
			echo "<td width=\"40%\">".$myrow["email"]."</td>";
			echo "<td width=\"5%\" align=\"center\">";
			echo $myrow["language"];
			echo "</td>";
			echo "<td width=\"5%\" align=\"center\">";
			if($myrow["confirmed"]==1)
				echo "<img src=\"gfx/checkmark.gif\" border=\"0\">";
			else
				echo "&nbsp;";
			echo "</td>";
			echo "<td width=\"20%\" align=\"center\">";
			echo $myrow["enterdate"];
			echo "</td>";
			echo "<td align=\"center\">";
			if($myrow["lastmanual"]!="0000-00-00 00:00:00")
				echo $myrow["lastmanual"];
			else
				echo "<a class=\"listlink\" href=\"".do_url_session("$act_script_url?mode=setmanual&input_subscriptionnr=$act_id&lang=$lang")."\">$l_set</a>";
			echo "</td>";
			echo "<td>";
			echo "<a class=\"listlink\" href=\"".do_url_session("$act_script_url?mode=delete&input_subscriptionnr=$act_id&lang=$lang")."\">";
			echo "$l_delete</a>";
			echo "&nbsp; ";
			echo "<a class=\"listlink\" href=\"".do_url_session("$act_script_url?mode=display&input_subscriptionnr=$act_id&lang=$lang")."\">";
			echo "$l_display</a>";
			if($myrow["confirmed"]==1)
			{
				echo "&nbsp; ";
				echo "<a class=\"listlink\" href=\"".do_url_session("newsmailer.php?input_subscriptionnr=$act_id&lang=$lang")."\">";
				echo "$l_sendnews</a>";
			}
	   } while($myrow = mysql_fetch_array($result));
	   echo "</table></tr></td></table>";
	}
if(($admin_rights > 1) && ($maxconfirmtime>0))
{
?>
<div class="bottombox" align="center">
<a href="<?php echo do_url_session("$act_script_url?mode=cleanup&lang=$lang")?>"><?php echo $l_cleanupoverdue?></a>&nbsp;&nbsp;
<a href="<?php echo do_url_session("$act_script_url?mode=new&lang=$lang")?>"><?php echo $l_newsubscriber?></a>
<?php
if($upload_avail)
{
	echo "&nbsp;&nbsp;";
	echo "<a href=\"".do_url_session("$act_script_url?mode=import&lang=$lang")."\">$l_importemaillist</a>";
}
?>
</div>
<?php
}
}
include_once('./trailer.php');
function import_single_line($inputfile, $newslang, $emailtype)
{
	global $tableprefix, $db;

	$emailfile=fopen($inputfile,"r");
	$maxsize=filesize($inputfile);
	$imported=0;
	while($fileLine=fgets($emailfile,$maxsize))
	{
		$fileLine=str_replace("\n","",$fileLine);
		$fileLine=str_replace("\r","",$fileLine);
		$fileLine=trim($fileLine);
		if(strlen($fileLine)<1)
			continue;
		$sql="select * from ".$tableprefix."_subscriptions where email='$fileLine'";
		if(!$result = mysql_query($sql, $db))
			die("Could not connect to the database.");
		if(!$myrow=mysql_fetch_array($result))
		{
			$actdate = date("Y-m-d H:i:s");
			$confirmed=1;
			$subscribeid=0;
			do{
				$maximum=9999999999;
				if($maximum>mt_getrandmax())
					$maximum=mt_getrandmax();
				mt_srand((double)microtime()*1000000);
				$unsubscribeid=mt_rand(10000,$maximum);
				$sql = "select * from ".$tableprefix."_subscriptions where unsubscribeid=$unsubscribeid";
				if(!$result = mysql_query($sql, $db))
					die("Could not connect to the database.");
			}while($myrow=mysql_fetch_array($result));
			$sql = "insert into ".$tableprefix."_subscriptions (email, confirmed, subscribeid, enterdate, emailtype, language, unsubscribeid) ";
			$sql.= "values ('$fileLine', $confirmed, $subscribeid, '$actdate', $emailtype, '$newslang', $unsubscribeid)";
			if(!$result = mysql_query($sql, $db))
				die("Could not connect to the database.".mysql_error());
			$imported++;
		}
	}
	return $imported;
}

function import_seplist($inputfile, $newslang, $emailtype, $sepchar)
{
	global $tableprefix, $db;

	$filedata=get_file($inputfile);
	$filedata=str_replace("\n","",$filedata);
	$filedata=str_replace("\r","",$filedata);
	$emails=explode($sepchar,$filedata);
	$imported=0;
	for($i=0;$i<count($emails);$i++)
	{
		$actmail=trim($emails[$i]);
		if(strlen($actmail)<1)
			continue;
		$sql="select * from ".$tableprefix."_subscriptions where email='$actmail'";
		if(!$result = mysql_query($sql, $db))
			die("Could not connect to the database.");
		if(!$myrow=mysql_fetch_array($result))
		{
			$actdate = date("Y-m-d H:i:s");
			$confirmed=1;
			$subscribeid=0;
			do{
				$maximum=9999999999;
				if($maximum>mt_getrandmax())
					$maximum=mt_getrandmax();
				mt_srand((double)microtime()*1000000);
				$unsubscribeid=mt_rand(10000,$maximum);
				$sql = "select * from ".$tableprefix."_subscriptions where unsubscribeid=$unsubscribeid";
				if(!$result = mysql_query($sql, $db))
					die("Could not connect to the database.");
			}while($myrow=mysql_fetch_array($result));
			$sql = "insert into ".$tableprefix."_subscriptions (email, confirmed, subscribeid, enterdate, emailtype, language, unsubscribeid) ";
			$sql.= "values ('$actmail', $confirmed, $subscribeid, '$actdate', $emailtype, '$newslang', $unsubscribeid)";
			if(!$result = mysql_query($sql, $db))
				die("Could not connect to the database.".mysql_error());
			$imported++;
		}
	}
	return $imported;
}
?>