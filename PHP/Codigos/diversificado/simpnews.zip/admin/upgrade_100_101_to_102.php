<?php
require('../config.php');
require('./functions.php');
?>
<html><body>
<div align="center"><h3>SimpNews: Upgrade from 1.00/1.01 to 1.02</h3></div>
<br>
<?php
echo "Upgrading tables..<br>";
$sql = "ALTER TABLE ".$tableprefix."_settings ADD ";
$sql.= "numhotnews tinyint(2) unsigned NOT NULL DEFAULT '5'";
if(!$result = mysql_query($sql, $db))
	die("Unable to upgrade table ".$tableprefix."_settings");
?>
<br><div align="center">Installation done.<br>Please remove install.php, upgrade*.php and fill_freemailer.php from server</div>
<div align="center">Now you can login to the <a href="index.php">admininterface</a></div>
</html></body>