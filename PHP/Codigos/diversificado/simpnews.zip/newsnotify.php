<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
// begin user editable part
// complete path to directory containing simpnews scripts (without trailing slash)
$path_simpnews = getenv("DOCUMENT_ROOT")."/simpnews";
// end user editable part
//
require($path_simpnews.'/config.php');
require($path_simpnews.'/functions.php');
if(!isset($category))
	$category=0;
if(!isset($lang) || !$lang)
	$lang=$default_lang;
include($path_simpnews.'/language/lang_'.$lang.'.php');
$sql = "select * from ".$tableprefix."_settings where settingnr=1";
if(!$result = mysql_query($sql, $db))
    die("Unable to connect to database.".mysql_error());
if(!$myrow=mysql_fetch_array($result))
	die("SimpNews not set up.");
$enablesubscriptions=$myrow["enablesubscriptions"];
$maxage=$myrow["maxage"];
$entriesperpage=$myrow["entriesperpage"];
$allowcomments=$myrow["allowcomments"];
$numhotnews=$myrow["numhotnews"];
$newsnotifydays=$myrow["newsnotifydays"];
$servertimezone=$myrow["servertimezone"];
$displaytimezone=$myrow["displaytimezone"];
$sql = "select * from ".$tableprefix."_layout where lang='$lang'";
if(isset($layout))
	$sql.=" and id='$layout'";
else
	$sql.=" and deflayout=1";
if(!$result = mysql_query($sql, $db))
    die("Unable to connect to database.".mysql_error());
if(!$myrow=mysql_fetch_array($result))
	die("Layout not set up.");
$heading=$myrow["heading"];
$headingbgcolor=$myrow["headingbgcolor"];
$headingfontcolor=$myrow["headingfontcolor"];
$headingfont=$myrow["headingfont"];
$headingfontsize=$myrow["headingfontsize"];
$bordercolor=$myrow["bordercolor"];
$contentbgcolor=$myrow["contentbgcolor"];
$contentfontcolor=$myrow["contentfontcolor"];
$contentfont=$myrow["contentfont"];
$contentfontsize=$myrow["contentfontsize"];
$TableWidth=$myrow["TableWidth"];
$timestampfontcolor=$myrow["timestampfontcolor"];
$timestampfontsize=$myrow["timestampfontsize"];
$timestampfont=$myrow["timestampfont"];
$dateformat=$myrow["dateformat"];
$showcurrtime=$myrow["showcurrtime"];
$pagebgcolor=$myrow["pagebgcolor"];
$stylesheet=$myrow["stylesheet"];
$newsheadingbgcolor=$myrow["newsheadingbgcolor"];
$newsheadingfontcolor=$myrow["newsheadingfontcolor"];
$newsheadingstyle=$myrow["newsheadingstyle"];
$displayposter=$myrow["displayposter"];
$posterbgcolor=$myrow["posterbgcolor"];
$posterfontcolor=$myrow["posterfontcolor"];
$posterfont=$myrow["posterfont"];
$posterfontsize=$myrow["posterfontsize"];
$posterstyle=$myrow["posterstyle"];
$newsheadingfont=$myrow["newsheadingfont"];
$newsheadingfontsize=$myrow["newsheadingfontsize"];
$timestampbgcolor=$myrow["timestampbgcolor"];
$timestampstyle=$myrow["timestampstyle"];
$displaysubscriptionbox=$myrow["displaysubscriptionbox"];
$subscriptionbgcolor=$myrow["subscriptionbgcolor"];
$subscriptionfontcolor=$myrow["subscriptionfontcolor"];
$subscriptionfont=$myrow["subscriptionfont"];
$subscriptionfontsize=$myrow["subscriptionfontsize"];
$copyrightbgcolor=$myrow["copyrightbgcolor"];
$copyrightfontcolor=$myrow["copyrightfontcolor"];
$copyrightfont=$myrow["copyrightfont"];
$copyrightfontsize=$myrow["copyrightfontsize"];
$newssignal_on=$myrow["newssignal_on"];
$newssignal_off=$myrow["newssignal_off"];
$separatebylang=$myrow["separatebylang"];
$layout=$myrow["id"];
$sql = "select * from ".$tableprefix."_misc";
if(!$result = mysql_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = mysql_fetch_array($result))
{
	if($myrow["shutdown"]==1)
	exit;
}
?>
<table width="<?php echo $TableWidth?>" border="0" CELLPADDING="1" CELLSPACING="0" ALIGN="CENTER" VALIGN="TOP">
<tr><TD BGCOLOR="<?php echo $bordercolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<?php
$actdate = date("Y-m-d H:i:s");
$sql = "select * from ".$tableprefix."_data where date >= date_sub('$actdate', INTERVAL $newsnotifydays DAY) ";
if($separatebylang==1)
	$sql.=" and lang='$lang' ";
if($category>=0)
	$sql.= "and category=$category ";
if(!$result = mysql_query($sql, $db))
    die("Unable to connect to database.");
$numentries=mysql_numrows($result);
?>
<tr bgcolor="<?php echo $contentbgcolor?>"><td align="center">
<font face="<?php echo $contentfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $contentfontcolor?>">
<a href="<?php echo $url_simpnews?>/news.php?lang=<?php echo $lang?>&amp;layout=<?php echo $layout?>&amp;category=<?php echo $category?>">
<?php
if($numentries>0)
	echo "<img src=\"$url_gfx/$newssignal_on\" border=\"0\" align=\"absmiddle\"> $l_newnews";
else
	echo "<img src=\"$url_gfx/$newssignal_off\" border=\"0\" align=\"absmiddle\"> $l_nonewnews";
?>
</a></font></td></tr></table></td></tr></table>
