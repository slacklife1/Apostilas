<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
// begin user editable part
// complete path to directory containing simpnews scripts (without trailing slash)
$path_simpnews = getenv("DOCUMENT_ROOT")."/simpnews";
// end user editable part
//
require_once($path_simpnews.'/config.php');
require_once($path_simpnews.'/functions.php');
if(!isset($category))
	$category=0;
if(!isset($lang) || !$lang)
	$lang=$default_lang;
include($path_simpnews.'/language/lang_'.$lang.'.php');
$sql = "select * from ".$tableprefix."_settings where settingnr=1";
if(!$result = mysql_query($sql, $db))
    die("Unable to connect to database.".mysql_error());
if(!$myrow=mysql_fetch_array($result))
	die("SimpNews not set up.");
$enablesubscriptions=$myrow["enablesubscriptions"];
$maxage=$myrow["maxage"];
$entriesperpage=$myrow["entriesperpage"];
$allowcomments=$myrow["allowcomments"];
$numhotnews=$myrow["numhotnews"];
$sql = "select * from ".$tableprefix."_layout where lang='$lang'";
if(isset($layout))
	$sql.=" and id='$layout'";
else
	$sql.=" and deflayout=1";
if(!$result = mysql_query($sql, $db))
    die("Unable to connect to database.".mysql_error());
if(!$myrow=mysql_fetch_array($result))
	die("Layout not set up.");
$heading=$myrow["heading"];
$headingbgcolor=$myrow["headingbgcolor"];
$headingfontcolor=$myrow["headingfontcolor"];
$headingfont=$myrow["headingfont"];
$headingfontsize=$myrow["headingfontsize"];
$bordercolor=$myrow["bordercolor"];
$contentbgcolor=$myrow["contentbgcolor"];
$contentfontcolor=$myrow["contentfontcolor"];
$contentfont=$myrow["contentfont"];
$contentfontsize=$myrow["contentfontsize"];
$TableWidth=$myrow["TableWidth"];
$timestampfontcolor=$myrow["timestampfontcolor"];
$timestampfontsize=$myrow["timestampfontsize"];
$timestampfont=$myrow["timestampfont"];
$dateformat=$myrow["dateformat"];
$showcurrtime=$myrow["showcurrtime"];
$pagebgcolor=$myrow["pagebgcolor"];
$stylesheet=$myrow["stylesheet"];
$newsheadingbgcolor=$myrow["newsheadingbgcolor"];
$newsheadingfontcolor=$myrow["newsheadingfontcolor"];
$newsheadingstyle=$myrow["newsheadingstyle"];
$displayposter=$myrow["displayposter"];
$posterbgcolor=$myrow["posterbgcolor"];
$posterfontcolor=$myrow["posterfontcolor"];
$posterfont=$myrow["posterfont"];
$posterfontsize=$myrow["posterfontsize"];
$posterstyle=$myrow["posterstyle"];
$newsheadingfont=$myrow["newsheadingfont"];
$newsheadingfontsize=$myrow["newsheadingfontsize"];
$timestampbgcolor=$myrow["timestampbgcolor"];
$timestampstyle=$myrow["timestampstyle"];
$displaysubscriptionbox=$myrow["displaysubscriptionbox"];
$subscriptionbgcolor=$myrow["subscriptionbgcolor"];
$subscriptionfontcolor=$myrow["subscriptionfontcolor"];
$subscriptionfont=$myrow["subscriptionfont"];
$subscriptionfontsize=$myrow["subscriptionfontsize"];
$copyrightbgcolor=$myrow["copyrightbgcolor"];
$copyrightfontcolor=$myrow["copyrightfontcolor"];
$copyrightfont=$myrow["copyrightfont"];
$copyrightfontsize=$myrow["copyrightfontsize"];
$newsscrollerbgcolor=$myrow["newsscrollerbgcolor"];
$newsscrollerfontcolor=$myrow["newsscrollerfontcolor"];
$newsscrollerfont=$myrow["newsscrollerfont"];
$newsscrollerfontsize=$myrow["newsscrollerfontsize"];
$newsscrollerheight=$myrow["newsscrollerheight"];
$newsscrollerwidth=$myrow["newsscrollerwidth"];
$newsscrollerscrollspeed=$myrow["newsscrollerscrollspeed"];
$newsscrollerscrolldelay=$myrow["newsscrollerscrolldelay"];
$newsscrollerscrollpause=$myrow["newsscrollerscrollpause"];
$newsscrollermaxdays=$myrow["newsscrollermaxdays"];
$newsscrollermaxentries=$myrow["newsscrollermaxentries"];
$newsscrollertype=$myrow["newsscrollertype"];
$newsscrollerbgimage=$myrow["newsscrollerbgimage"];
$newsscrollerfgimage=$myrow["newsscrollerfgimage"];
$newsscrollermousestop=$myrow["newsscrollermousestop"];
$newsscrollerxoffset=$myrow["newsscrollerxoffset"];
$newsscrolleryoffset=$myrow["newsscrolleryoffset"];
$newsscrollerdisplaydate=$myrow["newsscrollerdisplaydate"];
$newsscrollerwordwrap=$myrow["newsscrollerwordwrap"];
$newsscrollermaxlines=$myrow["newsscrollermaxlines"];
$separatebylang=$myrow["separatebylang"];
$layout=$myrow["id"];
$sql = "select * from ".$tableprefix."_misc";
if(!$result = mysql_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = mysql_fetch_array($result))
{
	if($myrow["shutdown"]==1)
	{
?>
<table width="<?php echo $TableWidth?>" border="0" CELLPADDING="1" CELLSPACING="0" ALIGN="CENTER" VALIGN="TOP">
<tr><TD BGCOLOR="<?php echo $bordercolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<?php
if(strlen($heading)>0)
{
?>
<TR BGCOLOR="<?php echo $headingbgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE" colspan="2"><font face="<?php echo $headingfont?>" size="<?php echo $headingfontsize?>" color="<?php echo $headingfontcolor?>"><b><?php echo $heading?></b></font></td></tr>
<?php
}
?>
</tr></table></td></tr>
<tr><TD BGCOLOR="<?php echo $bordercolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<tr BGCOLOR="<?php echo $contentbgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE" colspan="2"><font face="<?php echo $contentfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $contentfontcolor?>">
<?php
		$shutdowntext=stripslashes($myrow["shutdowntext"]);
		$shutdowntext = undo_htmlspecialchars($shutdowntext);
		echo $shutdowntext;
		echo "</font></td></tr></table></td></tr></table>";
?>
</td></tr></table>
<?php
		echo "<div align=\"center\">Generated by $copyright_url, $copyright_note</div>";
		exit;
	}
}
if(isset($download))
{
	header('Content-Type: application/octetstream');
	header('Content-Disposition: filename="newsscroller_'.$lang.'.ht"');
}
if(!isset($scrolltype))
	$scrolltype=$newsscrollertype;
if(!isset($limitentries))
	$limitentries=$newsscrollermaxentries;
if(!isset($limitdays))
	$limitdays=$newsscrollermaxdays;
$datasourceurl="$url_simpnews/newsscroller2.php?limitentries=$limitentries&limitdays=$limitdays&scrolltype=$scrolltype&lang=$lang&layout=$layout&category=$category";
if(isset($lastvisitdate))
	$datasourceurl.="&lastvisitdate=$lastvisitdate";
?>
<applet archive="<?php echo $url_simpnews?>/applet/scroller.jar"
	codebase="<?php echo $url_simpnews?>/applet"
	code="de.boesch_it.simpnews.scroller.NewsScroller"
	width="<?php echo $newsscrollerwidth?>"
	height="<?php echo $newsscrollerheight?>">
<param name="datasource" value="<?php echo $datasourceurl?>">
<param name="separator" value=";">
<param name="scrollspeed" value="<?php echo $newsscrollerscrollspeed?>">
<param name="scrolldelay" value="<?php echo $newsscrollerscrolldelay?>">
<param name="pause" value="<?php echo $newsscrollerscrollpause?>">
<param name="scrolltype" value="<?php echo $scrolltype?>">
<param name="onmouseoverstop" value="<?php echo $newsscrollermousestop?>">
<param name="xoffset" value="<?php echo $newsscrollerxoffset?>">
<param name="yoffset" value="<?php echo $newsscrolleryoffset?>">
<param name="maxlines" value="<?php echo $newsscrollermaxlines+2?>">
<?php
if($newsscrollerwordwrap==1)
	echo "<param name=\"wordwrap\" value=\"on\">";
if($newsscrollerbgimage)
	echo "<param name=\"backgroundimage\" value=\"$newsscrollerbgimage\">";
if($newsscrollerfgimage)
	echo "<param name=\"foregroundimage\" value=\"$newsscrollerfgimage\">";
?>
</applet>