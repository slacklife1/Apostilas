<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
// begin user editable part
// complete path to directory containing simpnews scripts (without trailing slash)
$path_simpnews = getenv("DOCUMENT_ROOT")."/simpnews";
// end user editable part
//
require_once($path_simpnews.'/config.php');
require_once($path_simpnews.'/functions.php');
if(!isset($category))
	$category=0;
if(!isset($lang) || !$lang)
	$lang=$default_lang;
include($path_simpnews.'/language/lang_'.$lang.'.php');
$sql = "select * from ".$tableprefix."_settings where settingnr=1";
if(!$result = mysql_query($sql, $db))
    die("Unable to connect to database.".mysql_error());
if(!$myrow=mysql_fetch_array($result))
	die("SimpNews not set up.");
$enablesubscriptions=$myrow["enablesubscriptions"];
$maxage=$myrow["maxage"];
$entriesperpage=$myrow["entriesperpage"];
$allowcomments=$myrow["allowcomments"];
$numhotnews=$myrow["numhotnews"];
$servertimezone=$myrow["servertimezone"];
$displaytimezone=$myrow["displaytimezone"];
$sql = "select * from ".$tableprefix."_layout where lang='$lang'";
if(isset($layout))
	$sql.=" and id='$layout'";
else
	$sql.=" and deflayout=1";
if(!$result = mysql_query($sql, $db))
    die("Unable to connect to database.".mysql_error());
if(!$myrow=mysql_fetch_array($result))
	die("Layout not set up.");
$heading=$myrow["heading"];
$headingbgcolor=$myrow["headingbgcolor"];
$headingfontcolor=$myrow["headingfontcolor"];
$headingfont=$myrow["headingfont"];
$headingfontsize=$myrow["headingfontsize"];
$bordercolor=$myrow["bordercolor"];
$contentbgcolor=$myrow["contentbgcolor"];
$contentfontcolor=$myrow["contentfontcolor"];
$contentfont=$myrow["contentfont"];
$contentfontsize=$myrow["contentfontsize"];
$TableWidth=$myrow["TableWidth"];
$timestampfontcolor=$myrow["timestampfontcolor"];
$timestampfontsize=$myrow["timestampfontsize"];
$timestampfont=$myrow["timestampfont"];
$dateformat=$myrow["dateformat"];
$showcurrtime=$myrow["showcurrtime"];
$pagebgcolor=$myrow["pagebgcolor"];
$stylesheet=$myrow["stylesheet"];
$newsheadingbgcolor=$myrow["newsheadingbgcolor"];
$newsheadingfontcolor=$myrow["newsheadingfontcolor"];
$newsheadingstyle=$myrow["newsheadingstyle"];
$displayposter=$myrow["displayposter"];
$posterbgcolor=$myrow["posterbgcolor"];
$posterfontcolor=$myrow["posterfontcolor"];
$posterfont=$myrow["posterfont"];
$posterfontsize=$myrow["posterfontsize"];
$posterstyle=$myrow["posterstyle"];
$newsheadingfont=$myrow["newsheadingfont"];
$newsheadingfontsize=$myrow["newsheadingfontsize"];
$timestampbgcolor=$myrow["timestampbgcolor"];
$timestampstyle=$myrow["timestampstyle"];
$displaysubscriptionbox=$myrow["displaysubscriptionbox"];
$subscriptionbgcolor=$myrow["subscriptionbgcolor"];
$subscriptionfontcolor=$myrow["subscriptionfontcolor"];
$subscriptionfont=$myrow["subscriptionfont"];
$subscriptionfontsize=$myrow["subscriptionfontsize"];
$copyrightbgcolor=$myrow["copyrightbgcolor"];
$copyrightfontcolor=$myrow["copyrightfontcolor"];
$copyrightfont=$myrow["copyrightfont"];
$copyrightfontsize=$myrow["copyrightfontsize"];
$newstyperbgcolor=$myrow["newstyperbgcolor"];
$newstyperfontcolor=$myrow["newstyperfontcolor"];
$newstyperfont=$myrow["newstyperfont"];
$newstyperfontsize=$myrow["newstyperfontsize"];
$newstyperheight=$myrow["newstyperheight"];
$newstyperwidth=$myrow["newstyperwidth"];
$newstypermaxdays=$myrow["newstypermaxdays"];
$newstypermaxentries=$myrow["newstypermaxentries"];
$newstypermaxchars=$myrow["newstypermaxchars"];
$newstyperbgimage=$myrow["newstyperbgimage"];
$newstyperxoffset=$myrow["newstyperxoffset"];
$newstyperyoffset=$myrow["newstyperyoffset"];
$newstyperdisplaydate=$myrow["newstyperdisplaydate"];
$newstyperdateformat=$myrow["newstyperdateformat"];
$newstyperfontstyle=$myrow["newstyperfontstyle"];
$newstyperscroll=$myrow["newstyperscroll"];
$layout=$myrow["id"];
$sql = "select * from ".$tableprefix."_misc";
if(!$result = mysql_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = mysql_fetch_array($result))
{
	if($myrow["shutdown"]==1)
	{
?>
<table width="<?php echo $TableWidth?>" border="0" CELLPADDING="1" CELLSPACING="0" ALIGN="CENTER" VALIGN="TOP">
<tr><TD BGCOLOR="<?php echo $bordercolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<?php
if(strlen($heading)>0)
{
?>
<TR BGCOLOR="<?php echo $headingbgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE" colspan="2"><font face="<?php echo $headingfont?>" size="<?php echo $headingfontsize?>" color="<?php echo $headingfontcolor?>"><b><?php echo $heading?></b></font></td></tr>
<?php
}
?>
</tr></table></td></tr>
<tr><TD BGCOLOR="<?php echo $bordercolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<tr BGCOLOR="<?php echo $contentbgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE" colspan="2"><font face="<?php echo $contentfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $contentfontcolor?>">
<?php
		$shutdowntext=stripslashes($myrow["shutdowntext"]);
		$shutdowntext = undo_htmlspecialchars($shutdowntext);
		echo $shutdowntext;
		echo "</font></td></tr></table></td></tr></table>";
?>
</td></tr></table>
<?php
		echo "<div align=\"center\">Generated by $copyright_url, $copyright_note</div>";
		exit;
	}
}
if(isset($download))
{
	header('Content-Type: application/octetstream');
	header('Content-Disposition: filename="newstyper_'.$lang.'.ht"');
}
if(!isset($limitentries))
	$limitentries=$newstypermaxentries;
if(!isset($limitdays))
	$limitdays=$newstypermaxdays;
$sql = "select * from ".$tableprefix."_data where lang='$lang' ";
if($category>=0)
	$sql.= "and category=$category ";
if($limitdays>=0)
{
	$actdate = date("Y-m-d H:i:s");
	$sql.= "and date >= date_sub('$actdate', INTERVAL $limitdays DAY) ";
}
$sql.= "order by date desc";
if($limitentries > 0)
	$sql.=" limit $limitentries";
if(!$result = mysql_query($sql, $db))
    die();
$bgcolor=str_replace("#","",$newstyperbgcolor);
$fontcolor=str_replace("#","",$newstyperfontcolor);
$datasourceurl="$url_simpnews/newstyper2.php?limitentries=$limitentries&limitdays=$limitdays&lang=$lang&layout=$layout&category=$category";
if(isset($lastvisitdate))
	$datasourceurl.="&lastvisitdate=$lastvisitdate";
?>
<applet archive="<?php echo $url_simpnews?>/applet/typer.jar"
	codebase="<?php echo $url_simpnews?>/applet"
	code="de.boesch_it.simpnews.typer.TeleTyper"
	width="<?php echo $newstyperwidth?>"
	height="<?php echo $newstyperheight?>">
<param name="datasource" value="<?php echo $datasourceurl?>">
<param name="fontcolor" value="<?php echo $fontcolor?>">
<param name="bgcolor" value="<?php echo $bgcolor?>">
<param name="font" value="<?php echo $newstyperfont?>">
<param name="fontsize" value="<?php echo $newstyperfontsize?>">
<param name="fontstyle" value="<?php echo $typerfontstyles[$newstyperfontstyle]?>">
<param name="xoffset" value="<?php echo $newstyperxoffset?>">
<param name="yoffset" value="<?php echo $newstyperyoffset?>">
<?php
if($newstyperscroll)
	echo "<param name=\"scroll\" value=\"yes\">\n";
else
	echo "<param name=\"scroll\" value=\"no\">\n";
if($newstyperbgimage)
	echo "<param name=\"backgroundimage\" value=\"$newstyperbgimage\">\n";
?>
</applet>