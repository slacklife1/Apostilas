<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
function language_avail($checklang, $dirname="language/")
{
	$dir = opendir($dirname);
	$langfound=false;
	while ($file = readdir($dir))
	{
		if (ereg("^lang_", $file))
		{
			$file = str_replace("lang_", "", $file);
			$file = str_replace(".php", "", $file);
			if($file == $checklang)
				$langfound=true;
		}
	}
	return $langfound;
}

function dateToJuliandays($day, $month, $year)
{
	$juliandays = 367*$year - floor(7*($year+floor(($month+9)/12))/4)
      - floor(3*(floor(($year+($month-9)/7)/100)+1)/4)
      + floor(275*$month/9) + $day + 1721028.5 + 12/24;
    return $juliandays;
}

function juliandaysToDate($JD,$dateformat)
{
	$Z = $JD+0.5;
	$F = $Z - floor($Z);

	$Z = floor($Z);
	$W = floor(($Z - 1867216.25)/36524.25);
	$X = floor($W/4);
	$A = $Z + 1 + $W - $X;
	$B = $A + 1524;
	$C = floor(($B - 122.1)/365.25);
	$D = floor(365.25*$C);
	$E = floor(($B - $D)/30.6001);

	if($E>13)
		$NewMonth = $E-13;
	else
		$NewMonth = $E-1;
	$NewDay = $B - $D - floor(30.6001*$E) +$F;
	if($NewMonth<3)
		$NewYear = $C-4715;
	else
		$NewYear = $C-4716;
	$returndate=date($dateformat,mktime(0,0,0,$NewMonth,$NewDay,$NewYear));
	return $returndate;
}

function undo_htmlspecialchars($input)
{
	$input = preg_replace("/&gt;/i", ">", $input);
	$input = preg_replace("/&lt;/i", "<", $input);
	$input = preg_replace("/&quot;/i", "\"", $input);
	$input = preg_replace("/&amp;/i", "&", $input);
	return $input;
}

function undo_htmlentities($input)
{
	$trans = get_html_translation_table (HTML_ENTITIES);
	$trans = array_flip($trans);
	$input=strtr($input,$trans);
	return $input;
}

function validate_email($email)
{
	$email_regex="^([-!#\$%&'*+./0-9=?A-Z^_`a-z{|}~ ])+@([-!#\$%&'*+/0-9=?A-Z^_`a-z{|}~ ]+\\.)+[a-zA-Z]{2,4}\$";
	return(eregi($email_regex,$email)!=0);
}

function get_start_tag($style)
{
	$start_tags=array("","<b>","<i>");
	return($start_tags[$style]);
}

function get_end_tag($style)
{
	$end_tags=array("","</b>","</i>");
	return($end_tags[$style]);
}

function forbidden_freemailer($email, $db)
{
	global $tableprefix;

	$sql="select * from ".$tableprefix."_freemailer";
	if(!$result = mysql_query($sql, $db))
	    die("Could not connect to the database.");
	if (!$myrow = mysql_fetch_array($result))
		return false;
	do{
		if(substr_count(strtolower($email), strtolower($myrow["address"]))>0)
			return true;
	} while($myrow = mysql_fetch_array($result));
	return false;
}

function remove_htmltags($input)
{
	$temp = "";
	$add=true;
	for ($i = 0; $i < strlen($input); $i++)
	{
		if (substr($input, $i, 1) == "<")
			$add = false;
		if ($add)
			$temp .= substr($input, $i, 1);
		if (substr($input, $i, 1) == ">")
			$add = true;
	}
	return $temp;
}

function get_userip()
{
	global $REMOTE_ADDR, $try_real_ip;

	if($try_real_ip)
	{
		$ip = getenv("REMOTE_ADDR");
		$ip1 = getenv("HTTP_X_FORWARDED_FOR");
		$ip2 = getenv("HTTP_CLIENT_IP");
		($ip1) ? $ip = $ip1 : null ;
		($ip2) ? $ip = $ip2 : null ;
	}
	else
		$ip = $REMOTE_ADDR;
	return $ip;

}

function is_phpfile($filename)
{
	global $php_fileext;
	$fileext=strrchr($filename,".");
	if(!$fileext)
		return false;
	$fileext=strtolower(substr($fileext,1));
	if(in_array($fileext,$php_fileext))
		return true;
	return false;
}

function file_output($filename)
{
	$filedata=get_file($filename);
	if($filedata)
		echo $filedata;
}

function get_file($filename)
{
	$return = "";
	if($fp = fopen($filename, 'rb'))
	{
		while(!feof($fp)){
			$return .= fread($fp, 1024);
		}
		fclose($fp);
		return $return;
	}
	else
	{
		return FALSE;
	}
}

function mail_smtp($receiver,$subject,$mailbody,$sender)
{
	global $smtpserver, $smtpport, $smtpsenderdomain, $smtpauth, $smtpuser, $smtppasswd, $path_simpnews;

	include_once($path_simpnews.'/includes/class.smtp.inc');

	$receivers=explode(", ",$receiver);
	if(count($receivers>0))
		$tomail=$sender;
	else
		$tomail=$receivers[0];
	$smtpparams = array(
		'host' => $smtpserver,
		'port' => $smtpport,
		'helo' => $smtpsenderdomain,
		'auth' => $smtpauth,
		'user' => $smtpuser,
		'pass' => $smtppasswd);
	$smtp = smtp::connect($smtpparams);
	$send_params['recipients']	= $receivers;
	$send_params['headers']		= array(
		'From: '.$sender,
		'To: '.$tomail,
		'Subject: '.$subject);
	$send_params['from']		= $sender;																						// It should end up as the Return-Path: header
	$send_params['body']		= $mailbody;
	$smtp->send($send_params);
}

function is_gecko()
{
	global $HTTP_USER_AGENT;

	if (eregi('Konqueror.([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
		return false;
	if (eregi("Netscape6",$HTTP_USER_AGENT))
		return false;
	if (eregi("Gecko",$HTTP_USER_AGENT) ||
		eregi("Mozilla/5",$HTTP_USER_AGENT))
		return true;
	return false;
}

function is_konqueror()
{
	global $HTTP_USER_AGENT;

	if (eregi('Konqueror.([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
		return true;
	return false;
}

function is_ns6()
{
	global $HTTP_USER_AGENT;

	if (eregi("Netscape6",$HTTP_USER_AGENT))
		return true;
	return false;
}

function is_ns4()
{
	global $HTTP_USER_AGENT;

	if (ereg( 'MSIE.([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
		return false;
	if (ereg( 'Opera.([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
		return false;
	if (ereg( 'Mozilla/([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
	{
		list($major,$minor)=explode(".",$log_version[1]);
		if($major=="4")
			return true;
	}
	return false;
}

function is_opera()
{
	global $HTTP_USER_AGENT;

	if (ereg( 'Opera.([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
		return true;
	return false;
}

function is_msie()
{
	global $HTTP_USER_AGENT;

	if (ereg( 'MSIE.([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
		return true;
	return false;
}

function is_win()
{
	global $HTTP_USER_AGENT;

    if (preg_match('/(win[dows]*)[\s]?([0-9a-z]*)[\w\s]?([a-z0-9.]*)/i',$HTTP_USER_AGENT))
    	return true;
    return false;
}

function get_browser_version()
{
	global $HTTP_USER_AGENT;

	if (ereg( 'MSIE ([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
	    return($log_version[1]);
	elseif (ereg( 'Opera ([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
    	return($log_version[1]);
    elseif (ereg( 'Netscape6/([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
    	return($log_version[1]);
    elseif (ereg( 'Mozilla/([0-9].[0-9]{1,2})',$HTTP_USER_AGENT,$log_version))
    	return($log_version[1]);
	else
		return(0);
}

/* please uncomment only if you have PHP4 <= 4.0.4 */
/*
function is_null($var)
{
	return($var==NULL);
}
*/
?>