<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
require_once('./config.php');
require_once('./functions.php');
$sql = "select * from ".$tableprefix."_misc";
if(!$result = mysql_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = mysql_fetch_array($result))
{
	if($myrow["shutdown"]==1)
		die("Service not available at the moment");
}
if(!isset($entrynr))
	die("Calling error");
$sql="select * from ".$tableprefix."_bindata where entrynr=$entrynr";
if(!$result=mysql_query($sql,$db))
	die("unable to connect to database");
if(!$myrow=mysql_fetch_array($result))
	die("no attachement for this entry (1)");
if(!$myrow["mimetype"])
{
	if(!$attach_in_fs)
		die("no attachement for this entry (2)");
	$downloadurl="Location: ".$url_attach."/".$myrow["filename"];
	header($downloadurl);
	exit;
}
$content_type="Content-type: ".$myrow["mimetype"]."\n";
$filename=$myrow["filename"];
header($content_type);
header("Content-Disposition: atachment; filename=$filename");
header("Content-Transfer-Encoding: binary\n");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");
header("Content-Length: " . $myrow["filesize"] . "\n");
echo $myrow["bindata"];
?>