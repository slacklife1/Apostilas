<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
// begin user editable part
// complete path to directory containing simpnews scripts (without trailing slash)
$path_simpnews = getenv("DOCUMENT_ROOT")."/simpnews";
// end user editable part
//
require_once($path_simpnews.'/config.php');
require_once($path_simpnews.'/functions.php');
if(!isset($category))
	$category=0;
if(!isset($lang) || !$lang)
	$lang=$default_lang;
include($path_simpnews.'/language/lang_'.$lang.'.php');
$sql = "select * from ".$tableprefix."_settings where settingnr=1";
if(!$result = mysql_query($sql, $db))
    die("Unable to connect to database.".mysql_error());
if(!$myrow=mysql_fetch_array($result))
	die("SimpNews not set up.");
$enablesubscriptions=$myrow["enablesubscriptions"];
$maxage=$myrow["maxage"];
$entriesperpage=$myrow["entriesperpage"];
$allowcomments=$myrow["allowcomments"];
$numhotnews=$myrow["numhotnews"];
$servertimezone=$myrow["servertimezone"];
$displaytimezone=$myrow["displaytimezone"];
$sql = "select * from ".$tableprefix."_layout where lang='$lang'";
if(isset($layout))
	$sql.=" and id='$layout'";
else
	$sql.=" and deflayout=1";
if(!$result = mysql_query($sql, $db))
    die("Unable to connect to database.".mysql_error());
if(!$myrow=mysql_fetch_array($result))
	die("Layout not set up.");
$heading=$myrow["heading"];
$headingbgcolor=$myrow["headingbgcolor"];
$headingfontcolor=$myrow["headingfontcolor"];
$headingfont=$myrow["headingfont"];
$headingfontsize=$myrow["headingfontsize"];
$bordercolor=$myrow["bordercolor"];
$contentbgcolor=$myrow["contentbgcolor"];
$contentfontcolor=$myrow["contentfontcolor"];
$contentfont=$myrow["contentfont"];
$contentfontsize=$myrow["contentfontsize"];
$TableWidth=$myrow["TableWidth"];
$timestampfontcolor=$myrow["timestampfontcolor"];
$timestampfontsize=$myrow["timestampfontsize"];
$timestampfont=$myrow["timestampfont"];
$dateformat=$myrow["dateformat"];
$showcurrtime=$myrow["showcurrtime"];
$pagebgcolor=$myrow["pagebgcolor"];
$stylesheet=$myrow["stylesheet"];
$newsheadingbgcolor=$myrow["newsheadingbgcolor"];
$newsheadingfontcolor=$myrow["newsheadingfontcolor"];
$newsheadingstyle=$myrow["newsheadingstyle"];
$displayposter=$myrow["displayposter"];
$posterbgcolor=$myrow["posterbgcolor"];
$posterfontcolor=$myrow["posterfontcolor"];
$posterfont=$myrow["posterfont"];
$posterfontsize=$myrow["posterfontsize"];
$posterstyle=$myrow["posterstyle"];
$newsheadingfont=$myrow["newsheadingfont"];
$newsheadingfontsize=$myrow["newsheadingfontsize"];
$timestampbgcolor=$myrow["timestampbgcolor"];
$timestampstyle=$myrow["timestampstyle"];
$displaysubscriptionbox=$myrow["displaysubscriptionbox"];
$subscriptionbgcolor=$myrow["subscriptionbgcolor"];
$subscriptionfontcolor=$myrow["subscriptionfontcolor"];
$subscriptionfont=$myrow["subscriptionfont"];
$subscriptionfontsize=$myrow["subscriptionfontsize"];
$copyrightbgcolor=$myrow["copyrightbgcolor"];
$copyrightfontcolor=$myrow["copyrightfontcolor"];
$copyrightfont=$myrow["copyrightfont"];
$copyrightfontsize=$myrow["copyrightfontsize"];
$newstyper2maxentries=$myrow["newstyper2maxentries"];
$newstyper2bgcolor=$myrow["newstyper2bgcolor"];
$newstyper2fontcolor=$myrow["newstyper2fontcolor"];
$newstyper2fontsize=$myrow["newstyper2fontsize"];
$newstyper2displaydate=$myrow["newstyper2displaydate"];
$newstyper2newscreen=$myrow["newstyper2newscreen"];
$newstyper2waitentry=$myrow["newstyper2waitentry"];
$newstyper2dateformat=$myrow["newstyper2dateformat"];
$newstyper2indent=$myrow["newstyper2indent"];
$newstyper2linespace=$myrow["newstyper2linespace"];
$newstyper2maxdays=$myrow["newstyper2maxdays"];
$newstyper2width=$myrow["newstyper2width"];
$newstyper2height=$myrow["newstyper2height"];
$newstyper2bgimage=$myrow["newstyper2bgimage"];
$newstyper2sound=$myrow["newstyper2sound"];
$newstyper2charpause=$myrow["newstyper2charpause"];
$newstyper2linepause=$myrow["newstyper2linepause"];
$newstyper2screenpause=$myrow["newstyper2screenpause"];
$layout=$myrow["id"];
$sql = "select * from ".$tableprefix."_misc";
if(!$result = mysql_query($sql, $db)) {
    die("Could not connect to the database.");
}
if ($myrow = mysql_fetch_array($result))
{
	if($myrow["shutdown"]==1)
	{
?>
<table width="<?php echo $TableWidth?>" border="0" CELLPADDING="1" CELLSPACING="0" ALIGN="CENTER" VALIGN="TOP">
<tr><TD BGCOLOR="<?php echo $bordercolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<?php
if(strlen($heading)>0)
{
?>
<TR BGCOLOR="<?php echo $headingbgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE" colspan="2"><font face="<?php echo $headingfont?>" size="<?php echo $headingfontsize?>" color="<?php echo $headingfontcolor?>"><b><?php echo $heading?></b></font></td></tr>
<?php
}
?>
</tr></table></td></tr>
<tr><TD BGCOLOR="<?php echo $bordercolor?>">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
<tr BGCOLOR="<?php echo $contentbgcolor?>" ALIGN="CENTER">
<TD ALIGN="CENTER" VALIGN="MIDDLE" colspan="2"><font face="<?php echo $contentfont?>" size="<?php echo $contentfontsize?>" color="<?php echo $contentfontcolor?>">
<?php
		$shutdowntext=stripslashes($myrow["shutdowntext"]);
		$shutdowntext = undo_htmlspecialchars($shutdowntext);
		echo $shutdowntext;
		echo "</font></td></tr></table></td></tr></table>";
?>
</td></tr></table>
<?php
		echo "<div align=\"center\">Generated by $copyright_url, $copyright_note</div>";
		exit;
	}
}
if(isset($download))
{
	header('Content-Type: application/octetstream');
	header('Content-Disposition: filename="newsmsgtyper_'.$lang.'.ht"');
}
if(!isset($limitentries))
	$limitentries=$newstyper2maxentries;
if(!isset($limitdays))
	$limitdays=$newstyper2maxdays;
$datasourceurl="$url_simpnews/newsmsgtyper2.php?limitentries=$limitentries&limitdays=$limitdays&lang=$lang&layout=$layout&category=$category";
if(isset($lastvisitdate))
	$datasourceurl.="&lastvisitdate=$lastvisitdate";
?>
<applet archive="<?php echo $url_simpnews?>/applet/msgtyper.jar"
	codebase="<?php echo $url_simpnews?>/applet"
	code="de.boesch_it.simpnews.msgtyper.MsgTyper"
	width="<?php echo $newstyper2width?>"
	height="<?php echo $newstyper2height?>">
<param name="datasource" value="<?php echo $datasourceurl?>">
<param name="fontcolor" value="<?php echo $newstyper2fontcolor?>">
<param name="bgcolor" value="<?php echo $newstyper2bgcolor?>">
<param name="moremsg" value="<?php echo "$l_more..."?>">
<param name="characterpause" value="<?php echo $newstyper2charpause?>">
<param name="linepause" value="<?php echo $newstyper2linepause?>">
<param name="screenpause" value="<?php echo $newstyper2screenpause?>">
<param name="linespace" value="<?php echo $newstyper2linespace?>">
<param name="indent" value="<?php echo $newstyper2indent?>">
<param name="fontsize" value="<?php echo $newstyper2fontsize?>">
<?php
if($newstyper2sound)
	echo "<param name=\"audioclip\" value=\"$newstyper2sound\">";
if($newstyper2bgimage)
	echo "<param name=\"backgroundimage\" value=\"$newstyper2bgimage\">";
?>
</applet>