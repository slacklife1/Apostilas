<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
// begin user editable part
// edit these variables to fit your configuration
$cookiename="simpnews";
$cokkiedomain="http://www.foo.bar";
// end user editable part
//
$actdate = date("Y-m-d H:i:00");
if(isset($HTTP_COOKIE_VARS[$cookiename]))
{
	$cookiedata=$HTTP_COOKIE_VARS[$cookiename];
	$cookiedate=$cookiedata["lastvisit"];
	$today=getdate(time());
	if($cookiedate && (strpos($cookiedate,"-")>0))
	{
		list($mydate,$mytime)=explode(" ",$cookiedate);
		list($year, $month, $day) = explode("-", $mydate);
		list($hour, $min, $sec) = explode(":",$mytime);
		$lastvisitdate=mktime($hour,$min,0,$month,$day,$year);
		if((time()-$lastvisitdate)>(60*60))
			setcookie($cookiename."[lastvisit]",$actdate,1,"/",$cookiedomain,$cookiesecure);
	}
	else
		setcookie($cookiename."[lastvisit]",$actdate,1,"/",$cookiedomain,$cookiesecure);
}
else
	setcookie($cookiename."[lastvisit]",$actdate,1,"/",$cookiedomain,$cookiesecure);
?>