Edit config.php so it fits your needs or call admin/mkconfig.php to generate one.
(if you're using PHP version >= 4.2.0, you have to set $new_global_handling=true;
in mkconfig.php)
Note: You can have multiple instances of SimpeNews in the same database.
Just set tableprefix in config.php to different values for each installation.
Do this bevore calling install.php.

Upload all .php-files to your webhoster.
Please maintain subdirectory structure.

Important installation note: the database you define in config.php must still exist. The
install script does not create a database for security reasons.

1st time installation:
Now you can call http://your.host.com/installdir/admin/install.php to create the tables

Upgrade:
Please replace all .php-Files on your server
So you determine which script you need: Take the actually installed versionnumber (e.g. 0.20).
Remove the point in the versionnumber (in our example this results in 020).
Now you have the upgrade version.
Now you need to sequentially use all upgrade scripts from this version to the actual version.
For our example the actual version should be 0.22 (short 023). Use upgrade_020_to_021.php
than upgrade_021_to_022.php and so on till you reach upgrade_022_to_023.php
After installation remove install.php or anyone can mess up your database.
If one script in the sequence does not exists, this only means for this upgrade step
no database changes were necessary. In this case just continue with the next one.
After installation remove install.php or anyone can mess up your database.

Important:
Use binary mode in ftp to transfer files in /applet, /gfx and /sfx !!!!

Now you can enter the admininterface by calling http://your.host.com/installdir/admin/index.php
and login using the adminuser created during the installprogress.

Note for users of PHP4 <= 4.0.4:
Please uncomment function is_null at end of functions.php.

Call newslist:
http://your.host.com/installdir/news.php?lang=<language>&layout=<layoutid>&category=<categorynr>
Call newslist separated by categories:
http://your.host.com/installdir/news2.php?lang=<language>&layout=<layoutid>
Call subscription form:
http://your.host.com/installdir/subscription.php?lang=<language>&layout=<layoutid>
Display event calender:
http://your.host.com/installdir/eventcal.php?lang=<language>&layout=<layoutid>&category=<categorynr>

If you don't define a language in URL, the default language defined in config.php will be used.
If you don't define a layout the layout marked as default will be used.
Use category=-1 to display entries of all categories.

Include hotnews list in your page:
Edit hotnews.php/hotnews2.php, so $path_simpnews points to the directory with the scripts.
Use include('<pathtosimpnews>/hotnews.php') to include the table in your page.
(or include('<pathtosimpnews>/hotnews2.php'))
If you want to enable last visit tracking by cookie (and marking new news since last visit),
use include('<pathtosimpnews>/newscookie.php') to include cookiehandling in your existing
page. This file has to be included before any HTTP body content is sent by PHP.
These versions doe not use the header and footer data defined in the admin interface, nor
the stylesheet, nor metadata.php, nor link colors. These scripts are designed to be
included in an existing page (e.g. if you want to have the latest 3 entries on your main page).
hotnews.php works like news.php. It displays the latest x entries for a single category or (if
you define category=-1) for all categories (not seperated by categories).
hotnews2.php displays the latest x entries per category, seperated by categories.

Include news notification icon in your page:
Edit newsnotify.php, so $path_simpnews points to the directory with the scripts.
Use include('<pathtosimpnews>/newsnotify.php') to include the table in your page.
This version does not use the header and footer data defined in the admin interface, nor
the stylesheet, nor metadata.php, nor link colors. This script is designed to be
included in an existing page.

Include news notification icon (with lastvisit cookie) in your page:
Edit newsnotify2.php, so $path_simpnews points to the directory with the scripts.
use include('<pathtosimpnews>/newscookie.php') to include cookiehandling in your existing
Use include('<pathtosimpnews>/newsnotify2.php') to include the table in your page.
This version does not use the header and footer data defined in the admin interface, nor
the stylesheet, nor metadata.php, nor link colors. This script is designed to be
included in an existing page.

Include event calendar in your page:
Edit eventcal2.php, so $path_simpnews points to the directory with the scripts.
If you want to enable last visit tracking by cookie (and marking new news since last visit),
use include('<pathtosimpnews>/newscookie.php') to include cookiehandling in your existing
page. This file has to be included before any HTTP body content is sent by PHP.
Use include('<pathtosimpnews>/eventcal2.php') to include the table in your page.
This version does not use the header and footer data defined in the admin interface, nor
the stylesheet, nor metadata.php, nor link colors. This script is designed to be
included in an existing page.

Include eventticker in your page:
Edit eventscroller.php, so $path_simpnews points to the directory with the scripts.
Use include('<pathtosimpnews>/eventscroller.php') to include the applet in your page.
This version does not use the header and footer data defined in the admin interface, nor
the stylesheet, nor metadata.php, nor link colors. This script is designed to be
included in an existing page.
The events of the actual day are displayed.

Include newsticker in your page:
There are 4 different kinds of newsticker available.
newsticker.php only displays the headings and opens the newsentry by clicking on the heading.
newsscroller.php displays the complete newsentry.
newstyper.php displays the newsentries in a typewriter style. No linking.
newsmsgtyper.php displays the newsentries in a different typewriter style. No linking.
You include all types in the same way.
Edit newsticker.php/newsscroller.php/newstyper.php/newsmsgtyper.php, so $path_simpnews points
to the directory with the scripts. Use include('<pathtosimpnews>/<script>') to include the
applet in your page.
If you want to enable last visit tracking by cookie (and marking new news since last visit),
use include('<pathtosimpnews>/newscookie.php') to include cookiehandling in your existing
page. This file has to be included before any HTTP body content is sent by PHP.
This version does not use the header and footer data defined in the admin interface, nor
the stylesheet, nor metadata.php, nor link colors. This script is designed to be
included in an existing page.

Notes for newscookie.php:
Edit newscookie.php, so $cookiename and $cokkiedomain fit for your
installation. Use include('<pathtosimpnews>/newscookie.php') to include cookiehandling
in your existing page. This file has to be included before any HTTP body content is sent by PHP.
If you get "headers allready sent", you have included it in the wrong place.

You also can download the HTML code to include the typers and scrollers in your HTML pages.
Just call /<pathtosimpnews>/<appletcall>?lang=<language>&layout=<layoutid>&download=1.
e.g.: http://www.foo.bar/simpnews/newsscroller.php?lang=en&layout=default&download=1
This will download the HTML code to include the applet with the actual settings of the admin
interface. Copy it to your HTML page or include it with SHTML.

Authentitication of admin users
-------------------------------
There are 3 ways to get authentication for admin users.
1) Using the internal authentication method. This is based on the data in the admin table and uses
cookies for session handling.
2) Using the internal authentication method. Sessionid sent by get and post requests.
3) Using authentication by webserver via .htaccess

Method #1
---------
You have to set $enable_htaccess and $sessid_url in config.php to false.
In this case please ensure the following settings in config.php are right:
$url_simpnews
$cookiename
$cookiepath
$cookiesecure
$sesscookiename
$sesscookietime

This method uses username and password stored in the database and because of this you can
change the password within the admin interface.

Method #2
---------
You have to set $enable_htaccess to false and $sessid_url to true in config.php.
This method uses no cookie for storing the sessionid, but instead sends the sessionid in every
get and post request.
Because of this, everybody who can look on your screen also can see your sessionid. We think
this is not really secure and recommend to use method 1 or 3. But you decide yourself.
Please ensure $sesscookiename is set to an value not used in an other way by SimpNews (best
would be to let the default name, because this ensures avoiding conflicts with other
HTTP-variables SimpNews uses).

This method uses username and password stored in the database and because of this you can
change the password within the admin interface.

Method #3
---------
You have to set $enable_htaccess in config.php to true.
For every user set up in the admin interface, you also have to set up an user in .htpasswd.
Username in database and .htpasswd must be the same, so the program can do assignment of
external and internal userdefinition.
Because of security reasons the admin interface _does not_ update .htpasswd. So if you use
this kind of authentication changes of the password in the admin interface _will not_ have
any effects. Also if you generate a new user in the admin interface be sure to also add
this user to .htpasswd. You still have to provide a password while creating a new user,
so no security whole appears if you change from Method 3 to Method 1 or 2.
Remark: Using this method the internal login and failed login tracking is not available.
Also the logout function does not work.

Tested browser
--------------
Konqueror 3.0.0 (Linux)
Mozilla 1.0 (Linux, Windows)
MS IE 5.5, 6.0 (Windows)
Netscape 6.2.1 (Linux), 6.2.2 (Windows)
Netscape 4.78 (Windows)
Opera 6.0 (Linux), 6.02 (Windows)


Newsletter
==========
Example code for using external form to subscribe to news:
<!-- --------- Start of subscription code --------- -->
<table width="80%" align="center">
<form method="post" action="/simpnews/subscription.php">
<input type="hidden" name="lang" value="en">
<input type="hidden" name="mode" value="subscribe">
<tr><td align="right" width="30%">Email:</td>
<td><input type="text" name="email" size="40" maxlength="240"></td></tr>
<tr><td align="right" valign="top">Email type:</td><td>
<input type="radio" name="emailtype" value="0" checked> HTML<br>
<input type="radio" name="emailtype" value="1"> plain text</td></tr>
<td align="center" colspan="2"><input type="submit" value="subscribe"></td></tr></form></table>
<!-- --------- End of subscription code --------- -->

Example code for using external form to unsubscribe:
<!-- --------- Start of unsubscription code --------- -->
<table width="80%" align="center">
<form method="post" action="/simpnews/subscription.php">
<input type="hidden" name="lang" value="en">
<input type="hidden" name="mode" value="unsubscribe">
<tr><td align="right" width="30%">Email:</td>
<td><input type="text" name="email" size="40" maxlength="240"></td></tr>
<td align="center" colspan="2"><input type="submit" value="unsubscribe"></td></tr></form></table>
<!-- --------- End of unsubscription code --------- -->

Note on field "remark put in emails" in layout:
Please include "{unsubscribeurl}" somewhere in your text (without the quotes). This will
be replaced by the appropriate URL to unsubscribe for the recipient on sending mails.

Note concerning attachements:
If you switch $attach_in_fs from true to false or vice versa and there are existing attachements,
this will result in database inconsitency. Please first delete all attachements in the admin
interface, than switch and upload the attachements again.

Licence
-------
This program is Freeware. You are allowed to use this for free in non commercial
and commercial environments. You are not allowed to do any changes without written permission.
Except of the following files:
* language/lang_*
* admin/language/lang_*
* stylesheets (*.css)
* index.html
* metadata.php
* the marked parts in the files in the main directory. Changes only allowed between
  "// begin user editable part" and "// end user editable part"


If you are using this program on your website, please enter your site as a
reference on our homepage.

If you are using this program in a commercial environment, it would be very kind to
provide our work with a little donation.

newest version can be found at
http://www.boesch-it.de

(Uses HTML Mime Mail class by Richard Heyes <richard@phpguru.org>)