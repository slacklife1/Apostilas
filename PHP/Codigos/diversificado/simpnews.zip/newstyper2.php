<?php
/***************************************************************************
 * (c)2002 Boesch IT-Consulting (info@boesch-it.de)
 ***************************************************************************/
// begin user editable part
// complete path to directory containing simpnews scripts (without trailing slash)
$path_simpnews = getenv("DOCUMENT_ROOT")."/simpnews";
// end user editable part
//
require_once($path_simpnews.'/config.php');
require_once($path_simpnews.'/functions.php');
if(!isset($category))
	$category=0;
if(!isset($lang) || !$lang)
	$lang=$default_lang;
include($path_simpnews.'/language/lang_'.$lang.'.php');
$sql = "select * from ".$tableprefix."_settings where settingnr=1";
if(!$result = mysql_query($sql, $db))
    die("Unable to connect to database.".mysql_error());
if(!$myrow=mysql_fetch_array($result))
	die("SimpNews not set up.");
$enablesubscriptions=$myrow["enablesubscriptions"];
$maxage=$myrow["maxage"];
$entriesperpage=$myrow["entriesperpage"];
$allowcomments=$myrow["allowcomments"];
$numhotnews=$myrow["numhotnews"];
$servertimezone=$myrow["servertimezone"];
$displaytimezone=$myrow["displaytimezone"];
$sql = "select * from ".$tableprefix."_layout where lang='$lang'";
if(isset($layout))
	$sql.=" and id='$layout'";
else
	$sql.=" and deflayout=1";
if(!$result = mysql_query($sql, $db))
    die("Unable to connect to database.".mysql_error());
if(!$myrow=mysql_fetch_array($result))
	die("Layout not set up.");
$heading=$myrow["heading"];
$headingbgcolor=$myrow["headingbgcolor"];
$headingfontcolor=$myrow["headingfontcolor"];
$headingfont=$myrow["headingfont"];
$headingfontsize=$myrow["headingfontsize"];
$bordercolor=$myrow["bordercolor"];
$contentbgcolor=$myrow["contentbgcolor"];
$contentfontcolor=$myrow["contentfontcolor"];
$contentfont=$myrow["contentfont"];
$contentfontsize=$myrow["contentfontsize"];
$TableWidth=$myrow["TableWidth"];
$timestampfontcolor=$myrow["timestampfontcolor"];
$timestampfontsize=$myrow["timestampfontsize"];
$timestampfont=$myrow["timestampfont"];
$dateformat=$myrow["dateformat"];
$showcurrtime=$myrow["showcurrtime"];
$pagebgcolor=$myrow["pagebgcolor"];
$stylesheet=$myrow["stylesheet"];
$newsheadingbgcolor=$myrow["newsheadingbgcolor"];
$newsheadingfontcolor=$myrow["newsheadingfontcolor"];
$newsheadingstyle=$myrow["newsheadingstyle"];
$displayposter=$myrow["displayposter"];
$posterbgcolor=$myrow["posterbgcolor"];
$posterfontcolor=$myrow["posterfontcolor"];
$posterfont=$myrow["posterfont"];
$posterfontsize=$myrow["posterfontsize"];
$posterstyle=$myrow["posterstyle"];
$newsheadingfont=$myrow["newsheadingfont"];
$newsheadingfontsize=$myrow["newsheadingfontsize"];
$timestampbgcolor=$myrow["timestampbgcolor"];
$timestampstyle=$myrow["timestampstyle"];
$displaysubscriptionbox=$myrow["displaysubscriptionbox"];
$subscriptionbgcolor=$myrow["subscriptionbgcolor"];
$subscriptionfontcolor=$myrow["subscriptionfontcolor"];
$subscriptionfont=$myrow["subscriptionfont"];
$subscriptionfontsize=$myrow["subscriptionfontsize"];
$copyrightbgcolor=$myrow["copyrightbgcolor"];
$copyrightfontcolor=$myrow["copyrightfontcolor"];
$copyrightfont=$myrow["copyrightfont"];
$copyrightfontsize=$myrow["copyrightfontsize"];
$newstyperbgcolor=$myrow["newstyperbgcolor"];
$newstyperfontcolor=$myrow["newstyperfontcolor"];
$newstyperfont=$myrow["newstyperfont"];
$newstyperfontsize=$myrow["newstyperfontsize"];
$newstyperheight=$myrow["newstyperheight"];
$newstyperwidth=$myrow["newstyperwidth"];
$newstypermaxdays=$myrow["newstypermaxdays"];
$newstypermaxentries=$myrow["newstypermaxentries"];
$newstypermaxchars=$myrow["newstypermaxchars"];
$newstyperbgimage=$myrow["newstyperbgimage"];
$newstyperxoffset=$myrow["newstyperxoffset"];
$newstyperyoffset=$myrow["newstyperyoffset"];
$newstyperdisplaydate=$myrow["newstyperdisplaydate"];
$newstyperdateformat=$myrow["newstyperdateformat"];
$newstyperfontstyle=$myrow["newstyperfontstyle"];
$newstyperscroll=$myrow["newstyperscroll"];
$separatebylang=$myrow["separatebylang"];
$layout=$myrow["id"];
$crlf="\n";
if(isset($download))
{
	$crlf="\r\n";
	header('Content-Type: application/octetstream');
	header('Content-Disposition: filename="newstyper_'.$lang.'.txt"');
}
if(!isset($limitentries))
	$limitentries=$newstypermaxentries;
if(!isset($limitdays))
	$limitdays=$newstypermaxdays;
$sql = "select * from ".$tableprefix."_data ";
$firstarg=1;
if($separatebylang==1)
{
	$firstarg=0;
	$sql.= "where lang='$lang' ";
}
if($category>=0)
{
	if($firstarg==1)
	{
		$firstarg=0;
		$sql.="where category=$category ";
	}
	else
		$sql.= "and category=$category ";
}
if($limitdays>=0)
{
	$actdate = date("Y-m-d H:i:s");
	if($firstarg==1)
	{
		$firstarg=1;
		$sql.="where date >= date_sub('$actdate', INTERVAL $limitdays DAY) ";
	}
	else
		$sql.= "and date >= date_sub('$actdate', INTERVAL $limitdays DAY) ";
}
$sql.= "order by date desc";
if($limitentries > 0)
	$sql.=" limit $limitentries";
if(!$result = mysql_query($sql, $db))
    die();
echo md5($copyright_note).$crlf;
if(mysql_num_rows($result)>0)
{
	echo mysql_num_rows($result).$crlf;
	while($myrow=mysql_fetch_array($result))
	{
		$msgtext="";
		if(isset($lastvisitdate))
		{
			list($mydate,$mytime)=explode(" ",$myrow["date"]);
			list($year, $month, $day) = explode("-", $mydate);
			list($hour, $min, $sec) = explode(":",$mytime);
			$thisentrydate=mktime($hour,$min,$sec,$month,$day,$year);
			if($thisentrydate>=$lastvisitdate)
			$msgtext.="$l_new ";
		}
		if($newstyperdisplaydate==1)
		{
			list($mydate,$mytime)=explode(" ",$myrow["date"]);
			list($year, $month, $day) = explode("-", $mydate);
			list($hour, $min, $sec) = explode(":",$mytime);
			if($month>0)
			{
				$displaytime=mktime($hour,$min,$sec,$month,$day,$year);
				$displaytime=$displaytime-($servertimezone*60*60);
				$displaytime=$displaytime+($servertimezone*60*60);
				$displaydate=date($newstyperdateformat,$displaytime);
				$msgtext.=$displaydate.": ";
			}
		}
		if($myrow["heading"])
		{
			$displayheading=undo_htmlentities(stripslashes($myrow["heading"]));
			$msgtext.=$displayheading." ";
		}
		$displaytext = undo_htmlentities(stripslashes($myrow["text"]));
		$displaytext = str_replace("\r","",$displaytext);
		$displaytext = str_replace("<BR>"," ",$displaytext);
		$displaytext = strip_tags($displaytext);
		if(($newstypermaxchars>0) && (strlen($displaytext)>$newstypermaxchars))
		{
			$text = explode(" ", $displaytext);
			$i = 0;
			$length = 0;
			$displaytext="";
			while(($i<count($text)) && ($length<$newstypermaxchars))
			{
				$length+=strlen($text[$i]);
				if($length<=$newstypermaxchars)
				{
					$displaytext.=$text[$i]." ";
					$i++;
				}
			}
			if($i<count($text))
				$displaytext.="...";
		}
		$msgtext.=$displaytext;
		echo $msgtext.$crlf;
	}
}
else
{
	echo "1$crlf";
	echo "$l_nonewnews$crlf";
	echo "$l_nonewnews$crlf";
}
?>
