Note:

There are definite known issues with Phorm and PHP4. I really hate 
to say this, but I'm afraid I cannot support Phorm on PHP4 
installations until the official release of PHP4, as things are
constantly changing with it. Problems that existed before have
disappeared. Problems that didn't exist before have appeared. I
can't afford the time to try to make Phorm work with a product
that's going to change in a few weeks.

If you are using PHP4, I really do appreciate your interest in
Phorm, and hope you'll consider using it on a PHP3 installation
or checking it out again when PHP4 is officially released.