If you are having difficulties with Phorm, please execute the 
phpinfo.php3 script, and send me the resulting page when asking
for assistance. This will help greatly in locating your trouble.