<form action="consulta.php" method="post">
  <p> 
    <input name="localizacao" type="text">
  </p>
  <p>
    <input type="submit" name="Submit" value="ok">
  </p>
</form>
