<?
//**************************************************************************
function conectar($dbNome)
{
  $db = mysql_connect("SERVIDOR MYSQL","USU�RIO MYSQL","SENHA MYSQL "); //mysql_connect("domain","login","password")
  mysql_select_db($dbNome);

  if (!$db)
  {
    echo("Erro de conex�o ".mysql_error()."\n");
    exit;
  }
}

//**************************************************************************

function bg_cell($contador)
{
	$resto = $contador % 2;
	if ($resto == '1')
		echo "#EEEEEE";
	else
		echo "#DDDDDD"; 
}

//**************************************************************************

$dbNome = "NOME DO BANCO DE DADOS";
conectar($dbNome);

$sql = "select * from NOME DA TABELA where NOME DO CAMPO A SER PESQUISADO = '$NOME DO CAMPO DE FORMUL�RIO DO ARQUIVO form.php'";
$result = mysql_query ($sql);

?>

<head>
<STYLE>
A{
        COLOR: #003366; TEXT-DECORATION: none
}
A:visited {
        COLOR: #003366; TEXT-DECORATION: none
}
A:hover {
        COLOR: red; TEXT-DECORATION: none
}

</STYLE>
</head>
<body>
<p align="center"><strong><font color="#999999" size="5"><tt>MYSQL Search</tt></font></strong></p>
<TABLE WIDTH="58%" BORDER="1" align="center" CELLPADDING="0" CELLSPACING="0" BORDERCOLOR="#000000">
  <?php
   	$contador = '1';
	while ( $valor = mysql_fetch_array($result) )
	{
?>
  <TR  BGCOLOR="<?php bg_cell($contador);?>"> 
    <TD WIDTH="113" bgcolor="#CCCCCC"> <div align="left"><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Campo 
        1 :</strong></font></div></TD>
    <TD WIDTH="333" bgcolor="#FFFFFF"> <div align="left"><font face="Times New Romam"><strong><font color="#999999"> 
        &nbsp;<?php echo $valor["campo1"];?></font></strong></font></div></TD>
  </TR>
  <TR  BGCOLOR="<?php bg_cell($contador);?>"> 
    <TD WIDTH="113" bgcolor="#CCCCCC"> <div align="left"><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Campo 
        2 :</strong></font></div></TD>
    <TD WIDTH="333" bgcolor="#FFFFFF"> <div align="left"><font face="Times New Romam"><strong><font color="#999999">&nbsp;<?php echo $valor["campo2"];?></font></strong></font></div></TD>
  </TR>
  <TR  BGCOLOR="<?php bg_cell($contador);?>"> 
    <TD WIDTH="113" bgcolor="#CCCCCC"> <div align="left"><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Campo 
        3 *:</strong></font></div></TD>
    <TD WIDTH="333" bgcolor="#FFFFFF"> <div align="left"><font face="Times New Romam"><strong><font color="red">&nbsp;<?php echo $valor["campo3"];?></font></strong></font></div></TD>
  </TR>
  <?php
	$contador++;
	} //end while
?>
</TABLE>
<p>* Campo a ser buscado.</p>
<p>&nbsp;</p>
<p>d&uacute;vidas: lyppe@pop.com.br</p>
<p align="center">&nbsp;</p>
</body>