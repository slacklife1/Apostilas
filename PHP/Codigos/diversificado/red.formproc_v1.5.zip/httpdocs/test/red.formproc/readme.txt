/***************************************
** Title........: Red Dot From Processor
** Filename.....: readme.txt
** Author.......: Richard Heyes
** Version......: *** See script ***
** Notes........: *** See script ***
** Last changed.: *** See script ***
** Last change..: *** See script ***
****************************************


Installation
============

Extract the formproc.php3. Place it in the correct directory.

There is an example form included that shows how to create a form
with various elements that utilises the script.


Script variables
================

There are a few variables in the script itself that you can configure.
Open the script with your most favourite text editor.

$security        This should be set to either 1 (one) or 0 (zero). If it is
                set to 1 then the referring page will be checked for the
                correct server name (the www.yourname.com bit). If it is
                incorrect (Eg. A form on another server referring to your
                form processor) then an error will be given.

$servername     This is the name of your server. It is only required when
                $security is set to 1 (one). An example:

                http://www.yourname.com/ Server name would be www.yourname.com
                http://users.isp.net/    Server name would be users.isp.net

$email          This is optional, you can if you wish leave it as is. However,
                if you have an input called email or email_required then that
                value will override this.
                It is used as the From: header on the resulting email that is sent
                out, so you can use the above clause and add an input to your form
                called email or email_required and the email you get will have the
                users email already in the From: field. Alternatively you can set
                this value by having a hidden input in your form called email (no
                need for _required if it is hidden) and then the emails will be sent
                to that address. Useful for having one script control multiple forms.
                Whichever method you choose, it must be set somewhere, otherwise the
                script won't work properly. Also, when set in the form, the email
                address is checked for valid form, so users cannot enter invalid
                email addresses.

$recipient      This is optional here in the script, but must also be set somewhere.
                Either in the script or in your form. Pretty self explanatory,
                determines who receives the email. Not a good idea at all to have this
                as a text input in your form, as users will be able to enter anyones
                email address.

$subject        Again, optional in the script but must be set somewhere. Determines the
                subject of the resulting email. Can also be a hidden input or user defined.


"In form" variables available
=============================

redirect                Specifies a webpage to redirect to on successful submission. Name is case sensitive.
                        This is a hidden variable. Example:
                        <INPUT TYPE="HIDDEN" NAME="redirect" VALUE="http://www.yourwebsite.com/thanks.html">
                        NB: This can also be set in the script.

recipient               Specifies the recipient of the resultant email from the form. Case sensitive. Example:
                        <INPUT TYPE="HIDDEN" NAME="recipient" VALUE="submissions@yourwebsite.com">
                        NB: This can also be set in the script.

subject                 Specifies the subject of the resultant email from the form. Case sensitive. Example:
                        <INPUT TYPE="HIDDEN" NAME="subject" VALUE="Feedback from webform">
                        NB: This can also be set in the script.

addhostip               If specified, the IP address and hostname will be added to the email sent as a result
                        of the form submission. Useful if you're trying to track abuse I guess. It is a boolean
                        value, so either 1 (on) or 0 (off). Can't see why you would have it set to 0 (off) as you
                        could just as easily leave it out all together, but it's there anyway. Case sensitive.
                        Example:
                        <INPUT TYPE="HIDDEN" NAME="addhostip" VALUE="1">
                        NB: This can also be set in the script.

email                   Specifies an email address. Can be hidden or not. If an email address is supplied then
                        it is used in the From: header of the email that is sent. The format of the email address
                        is first validated, if incorrect then it is rejected. This option can also be used in
                        conjunction with _required. Again, case sensitive. Two examples:
                        <INPUT TYPE="TEXT SIZE="25" NAME="email">
                        <INPUT TYPE="HIDDEN" NAME="email" VALUE="webform@yourwebsite.com">
                        NB: This can also be set in the script.

_required               Specifies a field to be mandatory and is added on to the name. Usually used on text boxes
                        but can be also use on select boxes, radio buttons, and textareas. CANNOT be used on check
                        box lists or multiple select lists. Case sensitive. Example:
                        <INPUT TYPE="TEXT" NAME="firstname_required" SIZE="25">

_file                   Specifies a field to be a file input and is added onto the name. Resultant file will be
                        attached to the email that is sent to the recipient. Like so:
                        <INPUT TYPE="FILE" NAME="fileupload_file" SIZE="25">

MAX_FILE_SIZE           Used in conjunction with the above to specify a maxmimum file size to be uploaded. However,
                        if used, and a file is uploaded above this value then a rather ugly error will be generated.
                        With usual php3 installations, another max file size is also set in the php ini file. This
                        is by default 2Mb.
                        Example:
                        <INPUT TYPE="HIDDEN" NAME="MAX_FILE_SIZE" VALUE="204800">


Notes
=====

If you use checkboxes with the same name (as is the norm) or if you have a multiple select
box (<SELECT MULTIPLE NAME="...">) then these MUST have "[]" tagged onto the end of their
names, (without the quotemarks).

Checkboxes and multiple selects cannot be used with the "_required" option. Normal select
boxes (aka drop down lists) can. If you do use a select box with "_required" then it's
advisable to make the first option blank. Otherwise there is no point making it _required.


Possible future enhancements
============================

Fixture of the below bug plus possibly the addition of html email support. Maybe.


Bugs and problems
=================

At the moment file uploads do not work with php4. I have an idea how to fix this, so stay tuned!


History
=======

16/04/00 - Version 1.5 released. Changed mime_mail.class to html_mime_mail.class,
					   an extension of mime_mail.class. File uploads
					   now work correctly under win32. Added support
					   for file uploads under Php4.

15/04/00 - Version 1.4 released. Another bug fix. This time for the security
				         feature.

09/04/00 - Version 1.3 released. My god. I wonder how this script ever worked.
                                 Massive code clean up as well as numerous bug
                                 fixes. Also added the debug feature, so that if
                                 you're having trouble you can gain a clue as to
                                 what's happening.

14/01/00 - Version 1.2 released. Removal of a few unnecessary bits.

26/12/99 - Version 1.1 released. Addition of file upload support.

30/11/99 - Version 1.0 released.


Credits
=======

Script was created by me, Richard Heyes.
Thanks to Sascha Schumann and Tobias Ratschiller for the mime mail class.

Email me: red.software@heyes-computing.net
  Web me: http://www.heyes-computing.net/red.software/

Copyright 1999, 2000 Richard Heyes. All rights reserved.
"For some, life itself is the biggest pain of all." - Anon.