<?
/********************************************************************************/
/* EasyClassifields                                                             */
/* ====================================================                         */
/*                                                                              */
/* Copyright (c) 2003 by Angel Stoitsov and Mario Stoitsov                      */
/*    http://software.stoitsov.com                                              */
/*                                                                              */
/* This file is part of EasyClassifields.                                       */
/* EasyClassifields is free software; you can redistribute it and/or modify     */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation; either version 2 of the License, or         */
/*    (at your option) any later version.                                       */
/* EasyClassifields is distributed in the hope that it will be useful,          */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/* You should have received a copy of the GNU General Public License            */
/*    along with EasyBookMarker; if not, write to the Free Software             */
/*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */
/********************************************************************************/
/*
/*      ******************************************************************
        ********************** EasyClassifields v2.01a *********************
        ******************************************** software.stoitsov.com      */

// Unzip the zip file in some subdirectory (e.g. EasyBookMarker) under the root
// directory on your server. Then follow the three easy steps below


// STEP ONE: Create the tables below under your desired DataBase
//           using phpMyAdmin for example


// ********************************************************************
// *********************** Database Tables
// ********************************************************************
/*

DROP TABLE IF EXISTS `cllink`;
CREATE TABLE `cllink` (
  `ID` bigint(20) NOT NULL auto_increment,
  `LUrl` varchar(255) NOT NULL default '',
  `LName` varchar(200) NOT NULL default '',
  `LDescription` text NOT NULL,
  `Date` date NOT NULL default '0000-00-00',
  `Modify` date NOT NULL default '0000-00-00',
  `Visit` date NOT NULL default '0000-00-00',
  `Hits` bigint(20) NOT NULL default '0',
  `Parent` bigint(20) default '0',
  `Choice` tinyint(4) NOT NULL default '0',
  `IP` varchar(18) NOT NULL default '',
  PRIMARY KEY  (`ID`),
  KEY `Date` (`Date`),
  KEY `Modify` (`Modify`),
  KEY `Visit` (`Visit`),
  KEY `Hits` (`Hits`),
  KEY `Parent` (`Parent`),
  KEY `Choice` (`Choice`)
) TYPE=MyISAM;

#
# Dumping data for table `cllink`
#

INSERT INTO `cllink` (`ID`, `LUrl`, `LName`, `LDescription`, `Date`, `Modify`, `Visit`, `Hits`, `Parent`, `Choice`, `IP`) VALUES (2, 'http://www.google.com/', 'Google', 'petia link', '2003-01-12', '2003-03-20', '2003-03-20', 1, 2, 1, '192.168.4.2'),
(5, 'http://www.geocities.com/SoHo/Studios/2165/sevda/sevdacv.html', 'SEVDALINA KOSTADINOVA - curriculum vitae', 'SEVDALINA KOSTADINOVA - curriculum vitae', '2000-10-21', '2003-01-16', '2003-01-16', 0, 2, 0, ''),
(6, 'http://nuctheor.alinea.bg/', 'Theoretical Nuclear Physics Group - Sofia, Bulgaria', 'Site of the group at INRNE, BAS', '2002-09-04', '2003-03-20', '2003-03-20', 0, 2, 0, ''),
(7, 'http://www.orau.gov/ria/', 'First RIA Summer School on Exotic Beam Physics', 'First RIA Summer School on Exotic Beam Physics', '2002-09-05', '2003-03-05', '2003-03-05', 0, 4, 0, ''),
(8, 'http://www.fuw.edu.pl/~hs2001/', 'High Spin Physics 2001', 'High Spin Physics 2001', '2000-10-21', '2002-08-29', '2002-08-29', 0, 4, 0, ''),
(9, 'http://int.phys.washington.edu/seminars_all.html', 'INT Seminars', 'INT Seminars', '2000-10-21', '2003-01-08', '2003-01-08', 0, 4, 0, ''),
(10, 'http://www.nsf.gov/sbe/int/ce_europe/start.htm', 'NSF INT CEE Program Homepage', 'NSF INT CEE Program Homepage', '2002-06-28', '2002-09-02', '2002-09-02', 0, 4, 0, ''),
(11, 'http://www.fuw.edu.pl/~int2000/', 'Nuclear structure for the 21st century', 'Nuclear structure for the 21st century', '2000-10-23', '2003-02-28', '2003-02-28', 0, 4, 0, ''),
(12, 'http://www.orau.gov/neutron/contact.html', 'Sanibel Island, Florida', 'Sanibel Island, Florida', '2002-08-28', '2003-02-06', '2003-02-06', 0, 4, 0, ''),
(15, 'http://ojps.aip.org/journal_cgi/dbt?KEY=AJPIAS&Volume=CURVOL&Issue=CURISS', 'American Journal of Physics--August 1999', 'American Journal of Physics--August 1999', '2000-11-03', '2003-01-27', '2003-01-27', 0, 8, 0, ''),
(16, 'http://physical.annualreviews.org/', 'Annual Review of Physical Sciences', 'Annual Review of Physical Sciences', '2000-11-03', '2003-02-21', '2003-02-21', 0, 8, 0, ''),
(17, 'http://publish.aps.org/', 'APS Research Journals', 'APS Research Journals', '2000-11-03', '1970-01-01', '1970-01-01', 0, 8, 0, ''),
(218, 'http://www.fultonbooks.co.uk/fultie.htm', 'Cognitive styles and Learning Strategies', 'David Fulton Publishers: Cognitive styles and Learning Strategies; Understanding Style Differences in Learning and Behavior by Richaard Riding and Stephen Rayner', '2002-04-10', '1970-01-01', '1970-01-01', 0, 35, 0, ''),
(219, 'http://129.113.160.149/comm2002/Textbook/Chapter02.html', 'Communication Policy and Strategy', 'Communication Policy and Strategy', '2002-04-06', '1970-01-01', '1970-01-01', 0, 35, 0, ''),
(220, 'http://www.vrd.org/conferences/VRD2000/proceedings/ware-intro.shtml', 'Communication Theory', 'Communication Theory and the Design of Live Online Reference Services', '2002-03-18', '1970-01-01', '1970-01-01', 0, 35, 0, ''),
(244, 'http://www.nameit.net/', 'Domain Registration - NameIT Corporation', 'Domain Registration - NameIT Corporation', '2000-10-31', '2003-02-19', '2003-02-19', 0, 37, 0, ''),
(246, 'http://desktoppublishing.com/icons.html', 'Icons for Web Publishing and Design', 'Icons for Web Publishing and Design', '2000-10-21', '2003-03-01', '2003-03-01', 0, 37, 0, '');


*/

// STEP TWO: edit your preferences below

// ********************************************************************
// *********************** Config options
// ********************************************************************
$EasyClassifields["mysql_host"]="localhost";       // change to your MySQL Host
$EasyClassifields["mysql_user"]="dbuser";      // change to your MySQL Username
$EasyClassifields["mysql_pass"]="dbpass"; // change to your MySQL Password
$EasyClassifields["mysql_base"]="dbname";       // Database name, to contain EasyClassifields tables
$EasyClassifields["new_days"]=7;              // New link`s age (default one week old)
$EasyClassifields["web_user"]="adminname";         // Username for Admin`s interface
$EasyClassifields["web_pass"]="adminpass";         // Password for Admin`s interface
$EasyClassifields["links_per_page"]=10;       // How many links to display on Search & Show pages
$EasyClassifields["DarkColor"]="#226834";     // Color of the headings, tables, links
$EasyClassifields["Background"]="#DCFFE5";    // Page Background color
$EasyClassifields["LightColor1"]="#CDEFD6";   // Table Highlight type 1
$EasyClassifields["LightColor2"]="#C4E2CC";   // Table Highlight type 2


// Generates Block Ads for your EasyClassifields powered site
function clBlockAds() {
global $EasyClassifields;
        $PowerBlock[0]="<a href='http://software.stoitsov.com/free/easybookmarker/' class=normal target=_ads>Get your bookmarks optimized in a very few steps!<br><br>Get your site<br><img src='powerbookmarker90x30.gif' width='90' height='30' alt='Get powered!' border='0'></a><br><br>";
        $PowerBlock[1]="<a href='http://software.stoitsov.com/free/easygallery/' class=normal target=_ads>Get your photoes on-line instantly!<br><br>Get your site<br><img src='powergallery90x30.gif' width='90' height='30' alt='Get powered!' border='0'></a><br><br>";
        $PowerBlock[2]="<a href='http://software.stoitsov.com/free/easyclassifields/' class=normal target=_ads>Get your Yahoo-style portal for free!<br><br>Get your site<br><img src='powerclassifields90x30.gif' width='90' height='30' alt='Get powered!' border='0'></a><br><br>";
        $PowerBlock[3]="<a href='http://software.stoitsov.com/free/easye-cards/' class=normal target=_ads>Offer e-cards on-line for free!<br><br>Get your site<br><img src='powere-cards90x30.gif' width='90' height='30' alt='Get powered!' border='0'></a><br><br>";
        $PowerBlock[4]="<a href='http://software.stoitsov.com/free/easypublish/' class=normal target=_ads>Want own news on your site?<br><br>Get your site<br><img src='powerpublish90x30.gif' width='90' height='30' alt='Get powered!' border='0'></a><br><br>";
	return "<div style='float: right; width:200; background-color:".$EasyClassifields["LightColor2"]."; padding: 15 15 15 15; text-align:center;'>
	<div align=right><span class=light2><b>Advertizement</b></span></div><br>
	".$PowerBlock[rand(0,Count($PowerBlock)-1)]."</div><br>";
}

// Generates Front Ads for your EasyClassifields powered site
function clFrontAds() {
global $EasyClassifields;
        $PowerBlock[0]="<a href='http://software.stoitsov.com/free/easybookmarker/' class=normal target=_ads>Get your bookmarks optimized in a few steps! Get your site<br><img src='powerbookmarker90x30.gif' width='90' height='30' alt='Get powered!' border='0'></a>";
        $PowerBlock[1]="<a href='http://software.stoitsov.com/free/easygallery/' class=normal target=_ads>Get your photoes on-line instantly! Get your site<br><img src='powergallery90x30.gif' width='90' height='30' alt='Get powered!' border='0'></a>";
        $PowerBlock[2]="<a href='http://so.stoitsov.com/free/easyclassifields/' target=_stoitsov class=normal><img src='classifields90x30.gif' width='90' height='30' alt='Get your Yahoo-style portal for free!' border='0'><br>Get your Yahoo-style<br>portal for free!</a>";
        $PowerBlock[3]="<a href='http://software.stoitsov.com/free/easye-cards/' class=normal target=_ads>Offer e-cards on-line for free! Get your site<br><img src='powere-cards90x30.gif' width='90' height='30' alt='Get powered!' border='0'></a>";
        $PowerBlock[4]="<a href='http://software.stoitsov.com/free/easypublish/' class=normal target=_ads>Want own news on your site? Get your site<br><img src='powerpublish90x30.gif' width='90' height='30' alt='Get powered!' border='0'></a>";
	return $PowerBlock[rand(0,Count($PowerBlock)-1)];
}

// Generates Sponsored Links for your EasyClassifields powered site
function clSponsoredLink() {
global $EasyClassifields;
	$PowerBlock[0]="<a href='http://software.stoitsov.com' target=_new class=normali>Get your desired software from <b>Stoitsov.com</b> for FREE now!</a>";
	$PowerBlock[1]="<a href='http://software.stoitsov.com' target=_new class=normali>Free PHP powered software from <b>Stoitsov.com</b>!</a>";
	return "<div style='background-color:".$EasyClassifields["LightColor1"]."; padding: 1 1 1 1; text-align:center;'
	><b>Sponsored link:</b> ".$PowerBlock[rand(0,Count($PowerBlock)-1)]."</div>";
}


// LAST STEP THREE: POINT TO INDEX.PHP and ENJOY !!!


// ********************************************************************
// You do not need to edit below this line
// ********************************************************************

// ********************************************************************
// ********************* Initialization & Constants
// ********************************************************************

$EasyClassifields["version"]="2.01a";
$clWidth="100%";
error_reporting  (E_ERROR | E_PARSE);
session_start();
$sql=mysql_connect($EasyClassifields["mysql_host"],$EasyClassifields["mysql_user"],$EasyClassifields["mysql_pass"]) or
			Die (clError("Problem!","<br>The database server is offline. Try again shortly.","If the problem persists, contact the system administrator."));
mysql_select_db($EasyClassifields["mysql_base"]) or
			Die (clError("Problem!","<br>The database is down for maintenance. It takes about 2 minutes to complete.","If the problem persists, contact the system administrator."));

if (isset($out)) { // Proceed clicked link
	if (clGetByID("clLink","IP",$out)!=$REMOTE_ADDR) {
		clMyQuery("UPDATE clLink SET Hits=Hits+1, Visit='".date("Y-m-d")."', IP='".$REMOTE_ADDR."' WHERE ID=$out;");
	} else {
		clMyQuery("UPDATE clLink SET Visit='".date("Y-m-d")."' WHERE ID=$out;");
	}
	$Link=clMyFetch("SELECT LUrl From clLink WHERE ID=$out;");
	Header("Location: ".$Link["LUrl"]);
	exit;
}

// ********************************************************************
// ********************** Functions
// ********************************************************************

function clFindParents($This,&$found) {
global $sql;
	$Query=clMyFetch("SELECT Parent,CName FROM clCategory WHERE ID=$This;");
	if ($Query["Parent"]==0) {
			$found="<a href='$PHP_SELF' class=normali><b>Home</b></a> <img src='menu_itema.gif' width='9' height='8' alt='' border='0'><a href='$PHP_SELF?page=browse&go=$This' class=normali>".$Query["CName"]."</a> ".$found;
	} else {
		$found=" <img src='menu_itema.gif' width='9' height='8' alt='' border='0'><a href='$PHP_SELF?page=browse&go=$This' class=normali>".$Query["CName"]."</a> ".$found;
		clFindParents($Query["Parent"],$found);
	} // if
} // clFindParents

function clDisplayLink($Link,$track=0) {
global $Stoitsov, $EasyClassifields;
	$Temp=split("/",$Link["LUrl"]);
	$Domain=$Temp[2];
	if ($track!=0) { // find path
		$found="";
		clFindParents($Link["Parent"],$found);
		$SiteNavigation=$found."<img src='menu_itema.gif' width='9' height='8' alt='' border='0'>";
	} // if
	return "<LI>".($track!=0 ? $SiteNavigation : "")."<a href='$PHP_SELF?out=".$Link["ID"]."' class=normal OnMouseover='self.status=\"GoTo: ".$Link["LUrl"]."\"; return true;' OnMouseOut='self.status=\"EasyClassifields ver.".$EasyClassifields["version"]."\"; return true;'>".$Link["LName"]."</a><br>
		<i>".$Link["LDescription"]."</i><br>".
		($Link["Choice"]==1 ? "<img src='choice.gif' width='65' height='10' alt='' border='0' hspace=1>" : "").
		($Link["Date"]>date("Y-m-d",mktime(0,0,0,intval(date("m")),intval(date("d"))-$EasyClassifields["new_days"],intval(date("Y")))) ? "<img src='new.gif' width='22' height='10' alt='' border='0' hspace=1>" : "").
		(($Link["Date"]>date("Y-m-d",mktime(0,0,0,intval(date("m")),intval(date("d"))-$EasyClassifields["new_days"],intval(date("Y")))) or $Link["Choice"]==1) ? "<br>" : "").
		"<span class=light1>Rank:</span> <span class=light2>".$Link["Hits"]."</span>
		<span class=light1>Added:</span> <span class=light2>".$Link["Date"]."</span>
		<span class=light1>Modified:</span> <span class=light2>".$Link["Modify"]."</span>
		<span class=light1>Visited:</span> <span class=light2>".$Link["Visit"]."</span>
		<span class=light1>Domain:</span> <span class=light2>".$Domain."</span>".
		(clRegistered($Stoitsov)==2 ? " <a href='$PHP_SELF?page=edit_link&id=".$Link["ID"]."&parent=".$Link["Parent"]."' class=admin>Edit</a>" : "")."
		</LI><br><br>";
} // clDisplayLink

function clRegistered($Who) {
Global $Stoitsov,$EasyClassifields;
        $ret=-1;
	if (isset($Stoitsov) && session_is_registered("Stoitsov") && $EasyClassifields["webuser"]==$Stoitsov["webuser"])
		$ret=2;
	return $ret;
} // clRegistered

function clError($Heading="������!",$Error="",$Solution="") {
return "<br><table border=0 cellspacing=0 cellpadding=0 align=center><tr><td><div style='background-color:#FFD8D8; border: 2px solid red; padding:10 10 10 10; font: 11px Verdana;'>
		<font color=red><b>$Heading</b></font><br><P>".mysql_error()."<b>$Error</b></P><i>$Solution</i></div></td></tr></table><br>";
} // clError

function clTr($width=1,$height=1) {
	return "<img src='tr.gif' width='$width' height='$height' alt='' border='0'>";
} // clTr

function clstriplen($text,$len,&$saved) {
	if (strlen(strip_tags(str_replace(" ","",$text)))<=$len) {
		$saved=$text;
	} else {
		$mtext="";
		$spl=split(",",$text);
		for ($t=0; $t<count($spl)-1; $t++) $mtext.=$spl[$t].", ";
		$mtext=substr($mtext,0,strlen($mtext)-2);
		clstriplen($mtext,$len,$saved);
	} // if
} // clstriplen

function clElement($Element="default",$Arg1="default",$Arg2="default",$Arg3="default",$Arg4="default",$Arg5="default",$Arg6="default") {
	switch ($Element) {
		case "form" : // Element, Action, Name, Method, Aditional
			$Action=$Arg1; $Name=$Arg2; $Method=$Arg3; $Aditional=$Arg4;
			if ($Name=="default") $Name="my";
			if ($Method=="default") $Method="POST";
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			return "<form action='$Action' name='$Name' method='$Method'".$Aditional.">\n";
		break;
		case "hidden" : // Element, Name, Value
			$Name=$Arg1; $Value=$Arg2;
			if ($Value=="default") $Value="";
			return "<input type='hidden' name='".$Name."' value='".$Value."'>\n";
		break;
		case "text" : // Element, Name, Value, Width, Aditional, Class
			$Name=$Arg1; $Value=$Arg2; $Width=$Arg3; $Aditional=$Arg4; $Class=$Arg5;
			if (strpos($Name,"[")===FALSE) {
				$ID="";
			} else {
				$Tmp=split("\[",$Name);
				$TmpID=split("\]",$Tmp[1]);
				$ID=" ID='".$TmpID[0]."' ";
			}
			if ($Value=="default") $Value="";
			if ($Width=="default") { $Width=""; } else { $Width=" style='width: $Width;' "; }
			if ($Class=="default") { $Class=" class='f_text'"; } else { $Class=" class='".$Class."'"; }
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			return "<input type='text'".$Class.$ID." name='".$Name."' value='".$Value."'".$Width.$Aditional.">\n";
		break;
		case "textarea" : // Element, Name, Value, Width, Height
			$Name=$Arg1; $Value=$Arg2; $Width=$Arg3; $Height=$Arg4;
			if ($Value=="default") $Value="";
			if ($Width=="default") { $Width=""; } else { $Width=" style='width: $Width;' "; }
			if ($Height=="default") { $Height=""; } else { $Height=" Rows='$Height' "; }
			return "<textarea class='f_text' name='".$Name."'".$Widht.$Height.">".$Value."</textarea>\n";
		break;
                case "password" : // Element, Name, Value, Width, Aditional
			$Name=$Arg1; $Value=$Arg2; $Width=$Arg3; $Aditional=$Arg4;
			if (strpos($Name,"[")===FALSE) {
				$ID="";
			} else {
				$Tmp=split("[",$Name);
				$TmpID=split("]",$Tmp[1]);
				$ID=" ID='".$TmpID[0]."' ";
			}
			if ($Value=="default") $Value="";
			if ($Width=="default") { $Width=""; } else { $Width=" style='width: $Width;' "; }
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			return "<input type='password' class='f_text'".$ID." name='".$Name."' value='".$Value."'".$Width.$Aditional.">\n";
		break;
		case "radio" : // Element, Name, Value, Selected, Aditional
			$Name=$Arg1; $Value=$Arg2; $Selected=$Arg3; $Aditional=$Arg4;
			if (strpos($Name,"[")===FALSE) {
				$ID="";
			} else {
				$Tmp=split("[",$Name);
				$TmpID=split("]",$Tmp[1]);
				$ID=" ID='".$TmpID[0]."' ";
			}
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			if ($Selected!=$Value) { $Selected=""; } else { $Selected=" checked"; }
			return "<input type='radio'".$ID." name='".$Name."' value='".$Value."'".$Selected.$Aditional.">"; break;
		break;
		case "checkbox" : // Element, Name, Value, Selected, Aditional
			$Name=$Arg1; $Value=$Arg2; $Selected=$Arg3; $Aditional=$Arg4;
			if (strpos($Name,"[")===FALSE) {
				$ID="";
			} else {
			}
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			if ($Selected=="default") { $Selected=""; } else { $Selected=" checked"; }
			return "<input type='checkbox'".$ID." name='".$Name."' value='".$Value."'".$Selected.$Aditional.">";
		break;
		case "submit" : // Element, Heading, Class
			$Value=$Arg1;
			$Class=$Arg2;
			if ($Class=="default") { $Class="f_text"; }
			return "<input type='submit' class='$Class' name='submit' value='$Value'>";
		break;
		case "button" : // Element, Name, Heading, OnClick
			$Name=$Arg1; $Value=$Arg2; $OnClick=$Arg3;
			if ($OnClick=="default") { $OnClick=""; } else { $OnClick=" OnClick='".$OnClick."'"; }
			return "<input type='button' class='f_text' name='".$Name."' value='".$Value."'".$OnClick.">";
		break;
		case "select" : // Element, Name, Values, Selected, Width, Labels, Aditional
			$Name=$Arg1; $Values=$Arg2; $Selected=$Arg3; $Width=$Arg4; $Labels=$Arg5; $Aditional=$Arg6;
			if (!is_array($Values)) $Values=Array("!!!���� �������� ���������!!!");
			if ($Width=="default") { $Width=""; } else { $Width=" style='width: $Width;' "; }
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			if (strpos($Name,"[")===FALSE) {
				$ID="";
			} else {
				$Tmp=split("\[",$Name);
				$TmpID=split("\]",$Tmp[1]);
				$ID=" ID='".$TmpID[0]."' ";
			}
			$ret="<select class='f_text' name='".$Name."'".$ID.$Width.$Aditional.">";
			while(list($key,$val)=each($Values)) {
				$CurrentLabel="";
				if (isset($Labels[$key])) $CurrentLabel=" Label='".$Labels[$key]."'";
				$ret.="<option value='".$key."'".$CurrentLabel.($Selected==$key ? " selected" : "" ).">".$val."</option>\n";
			} // while
			$ret.="</select>";
			return $ret;
		break;
		case "reset" : // Element, Heading
			$Value=$Arg1;
			if ($Value=="default") $Value="��������";
			return "<input type='reset' class='f_text' name='reset' value='".$Value."'>";
		break;
		default : // (ANY)
			return "</form>";
		break;
	} // switch
} // clElement

function clHeading($Heading,$BR=1) {
	$ret.="<span class='h1s'>".$Heading."</span>";
	for ($t=0; $t<$BR; $t++) $ret.="<BR>";
	return $ret."\n";
} // clHeading

function clMyQuery($Query) {
Global $sql;
	$Res=mysql_query($Query) or Die (clError("Error!","<br>Invalid DataBase Query.","<PRE>The query is:<br>$Query</PRE>If the problem persists, contact the system administrator."));
	return $Res;
} // clMyQuery

function clMyFetch($Query) {
Global $sql;
	$Res=mysql_fetch_array(mysql_query($Query)) or Die (clError("Error!","<br>Invalid DataBase Query.","<PRE>The query is:<br>$Query</PRE>If the problem persists, contact the system administrator."));
	return $Res;
} // clMyFetch

function clHackers($Text) {
	$ret=strip_tags($Text);	$ret=escapeshellcmd($ret);
	$ret=trim($ret);	$ret=str_replace("'","`",$ret);
	return $ret;
} // clHackers

function clGetByID($Table,$Field,$ID) {
Global $sql;
	$Result=clMyQuery("SELECT ".$Field." FROM ".$Table." WHERE ID='".$ID."';");
	if (mysql_num_rows($Result)==0) {
		return "Error! (GetByID)";
	} else {
		$Ret=mysql_fetch_array($Result);
		return $Ret[$Field];
	} // if
} // clGetByID

// ********************************************************************
// ************************ Actions
// ********************************************************************


if ($action=="login") {
   if ($clUsername==$EasyClassifields["web_user"] && $clPassword==$EasyClassifields["web_pass"]) { // valid user
		$Stoitsov["User"]=$EasyClassifields["web_user"];
		session_register("Stoitsov");
	} else { // invalid user
		$Error="<b>Invalid username or password.</b><br>";
		$page="login";
	} // if
} // Login


 if ($action=="logout") {
	session_unregister("Stoitsov");
	unset($Stoitsov);
    } // Logout

 //session_write_close();

if ($action=="add_folder") {
	if (clRegistered($Stoitsov)<0)  { // invalid user
		$page="login";
		$Error="<b>You need to be a registered user in order to add folders.</b><br>";
	} else { // valid
		unset($Error);
		if (strlen(clHackers($clICName))<1) $Error="<b>Folder Name is empty.</b><br>";
		if (strlen(clHackers($clICDescription))<1) $Error.="<b>Folder Description is empty.</b><br>";
		if (isset($Error)) { // There are errors
			$page="add_folder";
			$parent=$clParent;
		} else { // Add Folder
			clMyQuery("INSERT INTO clCategory VALUES(null,'".clHackers($clICName)."','".clHackers($clICDescription)."','$clParent');");
			$page="browse"; $go=mysql_insert_id();
		} // if Errors
	} // if valid
} // Add Folder

if ($action=="edit_folder") {
	if (clRegistered($Stoitsov)<0)  { // invalid user
		$page="login";
		$Error="<b>You need to be a registered user in order to edit folders.</b><br>";
	} else { // valid
		unset($Error);
		if (strlen(clHackers($clICName))<1) $Error="<b>Folder Name is empty.</b><br>";
		if (strlen(clHackers($clICDescription))<1) $Error.="<b>Folder Description is empty.</b><br>";
		if (isset($Error)) { // There are errors
			$page="edit_folder";
			$id=$clID;
		} else { // Edit Folder
			clMyQuery("UPDATE clCategory SET Parent='".$clParent."', CName='".clHackers($clICName)."', CDescription='".clHackers($clICDescription)."' WHERE ID=$clID;");
			$page="browse"; $go=$clID;
		} // if Errors
	} // if valid
} // Edit Folder

if ($action=="delete_folder") {
	if (clRegistered($Stoitsov)<0)  { // invalid user
		$page="login";
		$Error="<b>You need to be a registered user in order to delete folders.</b><br>";
	} else { // valid
		clMyQuery("DELETE FROM clCategory WHERE ID=$clID;");
		$page="browse"; $go=$parent;
	} // if valid
} // Delete Folder

if ($action=="add_link") {
	unset($Error);
	if (strlen(clHackers($clLUrl))<8) $Error="<b>The link is invalid.</b><br>";
	if (strlen(clHackers($clLName))<1) $Error="<b>Site Name is empty.</b><br>";
	if (strlen(clHackers($clLDescription))<1) $Error.="<b>Site Description is empty.</b><br>";
	if (isset($Error)) { // There are errors
		$page="add_link";
		$parent=$clParent;
	} else { // Add Link
		clMyQuery("INSERT INTO clLink VALUES(null,'".clHackers($clLUrl)."','".clHackers($clLName)."','".clHackers($clLDescription)."','".date("Y-m-d")."','".date("Y-m-d")."','".date("Y-m-d")."',0,'$clParent',0,'');");
		$page="browse"; $go=$clParent;
	} // if Errors
} // Add Link

if ($action=="edit_link") {
	if (clRegistered($Stoitsov)<0)  { // invalid user
		$page="login";
		$Error="<b>You need to be a registered user in order to edit links.</b><br>";
	} else { // valid
		unset($Error);
		if (strlen(clHackers($clLUrl))<8) $Error="<b>The link is invalid.</b><br>";
		if (strlen(clHackers($clLName))<1) $Error="<b>Site Name is empty.</b><br>";
		if (strlen(clHackers($clLDescription))<1) $Error.="<b>Site Description is empty.</b><br>";
		if (isset($Error)) { // There are errors
			$page="add_link";
			$parent=$clParent;
			$id=$clID;
		} else { // Edit Link
			clMyQuery("UPDATE clLink SET Parent='".$clParent."', LUrl='".clHackers($clLUrl)."', LName='".clHackers($clLName)."', LDescription='".clHackers($clLDescription)."', Modify='".date("Y-m-d")."', Visit='".date("Y-m-d")."', Choice='".$clChoice."' WHERE ID=$clID;");
			$page="browse"; $go=$clParent;
		} // if Errors
	} // if valid
} // Edit Link

if ($action=="delete_link") {
	if (clRegistered($Stoitsov)<0)  { // invalid user
		$page="login";
		$Error="<b>You need to be a registered user in order to delete links.</b><br>";
	} else { // valid
		clMyQuery("DELETE FROM clLink WHERE ID=$clID;");
		$page="browse"; $go=$parent;
	} // if valid
} // Delete Link


// ********************************************************************
// **************   EasyClassifields Screen Creation
// ********************************************************************

// Start: Browse page
if (isset($page) && $page=="browse" && isset($go)) {
	if ($go==0) { // Goto Main Page
		unset($page);
	} else { // Goto Browse Page
		$ResultHtml="";
		$found="";
		clFindParents($go,$found);
		$SiteNavigation=$found;
		$Folders=clMyQuery("SELECT * FROM clCategory WHERE Parent=".$go." ORDER BY CName;");
		$ResultHtml.="<table border='0' cellspacing='0' cellpadding='10' width=100%>
		<tr>
			<td width=100% bgcolor='".$EasyClassifields["LightColor1"]."' valign=top>
			<a href='$PHP_SELF?page=browse&go=$go' class=normalc>".clGetByID("clCategory","CName",$go)."</a>".
			(clRegistered($Stoitsov)==2 ? " <a href='$PHP_SELF?page=edit_folder&id=$go' class=admin>Administrator Edit</a>" : "") ."<br>
			<i>".clGetByID("clCategory","CDescription",$go)."</i><br><br>".(mysql_num_rows($Folders)!=0 ? "<b>SubFolders:</b> " : " ");
			while ($Folder=mysql_fetch_array($Folders)) {
				$ResultHtml.="<a href='$PHP_SELF?page=browse&go=".$Folder["ID"]."' class=normali>".$Folder["CName"]."</a>, ";
			} // while folders
			if (mysql_num_rows($Folders)!=0) $ResultHtml=substr($ResultHtml,0,strlen($ResultHtml)-2);
			$ResultHtml.=(clRegistered($Stoitsov)==2 ? " <a href='$PHP_SELF?page=add_folder&parent=$go' class=admin>Add subfolder</a>" : "") ."</td>
			".clElement("form",$PHP_SELF,"search","GET").clElement("hidden","page","search")."<td nowrap bgcolor='".$EasyClassifields["LightColor2"]."'>".clElement("text","search","",220)." ".clElement("submit","Search")."<br>
			&nbsp;&nbsp;&nbsp;<b>What: </b>".clElement("radio","what","1",1)." all words ".clElement("radio","what","2")." exact phrase<br>
			<b>Where: </b>".clElement("checkbox","where[]","name",1)." name ".clElement("checkbox","where[]","description",1)." description  ".clElement("checkbox","where[]","url")." url
			</td>".clElement()."
		</tr>
		</table><br>";
		if (!isset($from)) $from=0;
		$TotalLinks=mysql_num_rows(clMyQuery("SELECT * FROM clLink WHERE Parent=$go;"));
		if ($TotalLinks>0) $ResultHtml.=clHeading("Sites",2).clSponsoredLink()."<UL>";
		$Links=clMyQuery("SELECT * FROM clLink WHERE Parent=$go ORDER BY Hits Desc LIMIT $from,".$EasyClassifields["links_per_page"].";");
		$i=0;
		while ($Link=mysql_fetch_array($Links)) {
			$i++;
			if ($i==2 or $i==8) $ResultHtml.=clBlockAds();
			$ResultHtml.=clDisplayLink($Link);
		} // while links
		if ($TotalLinks>0) $ResultHtml.="</UL>";
		if ($from!=0) $ResultHtml.= "<a href='$PHP_SELF?page=browse&go=$go&from=".($from-$EasyClassifields["links_per_page"])."'><img src='prev.gif' width='66' height='14' alt='Previous Page' border='0'></a>";
		if ($TotalLinks>$from+$EasyClassifields["links_per_page"]) $ResultHtml.= "<a href='$PHP_SELF?page=browse&go=$go&from=".($from+$EasyClassifields["links_per_page"])."'><img src='next.gif' width='66' height='14' alt='Next Page' border='0' hspace=4></a>";
		$ResultHtml.="<br>";
	} // if Main or Browse page
} // End: Browse Page

// Start: Main page
if (!isset($page)) {
	$ResultHtml="";
	$SiteNavigation="";
	$clWidth="620";
	$ResultHtml.="<table border='0' cellspacing='0' cellpadding='20' width=".$clWidth." align=center>
	<tr>
		<td bgcolor='".$EasyClassifields["LightColor1"]."'>".clTr(25)."<br></td>"
		.clElement("form",$PHP_SELF,"search","GET").clElement("hidden","page","search")."<td bgcolor='".$EasyClassifields["LightColor1"]."' width=100%>".clElement("text","search","",220)." ".clElement("submit","Search")."<br>
		&nbsp;&nbsp;&nbsp;<b>What: </b>".clElement("radio","what","1",1)." all words ".clElement("radio","what","2")." exact phrase<br>
		<b>Where: </b>".clElement("checkbox","where[]","name",1)." name ".clElement("checkbox","where[]","description",1)." description  ".clElement("checkbox","where[]","url")." url
		</td>".clElement()."
		<td align=center>".clTR(150,1)."<br>".clFrontAds()."<br>
		</td>
	</tr>
	</table>
	<table border='0' cellspacing='4' cellpadding='2' width=640 align=center>
	<tr>
		<td width=100%>
			<table border='0' cellspacing='4' cellpadding='0' width=100%>
		";
		$Categories=clMyQuery("SELECT * FROM clCategory WHERE Parent=0 ORDER BY CName;");
		while ($Category=mysql_fetch_array($Categories)) {
			$Folders=clMyQuery("SELECT * FROM clCategory WHERE Parent=".$Category["ID"]." ORDER BY CName;");
			$i++;
			if ($i % 2 !=0) { $ResultHtml.="<tr><td width=50%>"; } else { $ResultHtml.="<td width=50%>"; }
				$ResultHtml.="<a href='$PHP_SELF?page=browse&go=".$Category["ID"]."' class=normalc>".$Category["CName"]."</a><br>";
				$saved=$SubHtml="";
				while ($Folder=mysql_fetch_array($Folders)) {
					$SubHtml.="<a href='$PHP_SELF?page=browse&go=".$Folder["ID"]."' class=normali>".$Folder["CName"]."</a>, ";
				} // while folders
				$SubHtml=substr($SubHtml,0,strlen($SubHtml)-2);
				clstriplen($SubHtml,40,$saved);
				$ResultHtml.=$saved;
				if (strlen($saved)!=strlen($SubHtml)) $ResultHtml.="...";
			if ($i % 2 ==0) { $ResultHtml.="</td></tr>"; } else { $ResultHtml.="</td>"; }
		} // while categories
		if ($i % 2 != 0) { $ResultHtml.="<td>&nbsp;</td></td></tr>"; }
		$ResultHtml.="</table></td>
		<td bgcolor='".$EasyClassifields["LightColor2"]."' rowspan=2 valign=top>".clTr(180)."<br>&nbsp;<b>Editor's Choice</b><br><br>";
		$News=clMyQuery("SELECT * FROM clLink ORDER BY Choice DESC, Hits DESC Limit 13;");
		while ($New=mysql_fetch_array($News)) {
			$Result=substr($New["LName"],0,24);
			if (strlen($Result)!=strlen($New["LName"])) $Result.="...";
			$ResultHtml.="&nbsp;<a href='$PHP_SELF?out=".$New["ID"]."' class=normal>".$Result."</a><br>".clTr(1,4)."<br>";
		} // while Editor`s choice
		$ResultHtml.="<div align=right><a href='$PHP_SELF?page=charts&chart=3' class=normal><b>More...</b></a>&nbsp;</div></td>
		</tr>
		<tr>
			<td bgcolor='".$EasyClassifields["LightColor1"]."' align=center>".clSponsoredLink()."</td>
		</tr>
	</table>";
} // End: Main Page

// Start: Charts page
if (isset($page) && $page=="charts" && isset($chart)) {
	if ($chart==1) { // What`s new
		$ResultHtml=clHeading("What`s New",1)."Recently added sites<br><br><UL>";
		$SiteNavigation="<a href='$PHP_SELF' class=normali><b>Home</b></a> <img src='menu_itema.gif' width='9' height='8' alt='' border='0'><b>What`s New</b>";
		$Links=clMyQuery("SELECT * FROM clLink ORDER BY Date Desc LIMIT 20;");
		$i=0;
		while ($Link=mysql_fetch_array($Links)) {
			$i++;
			if ($i==2 or $i==8) $ResultHtml.=clBlockAds();
			$ResultHtml.=clDisplayLink($Link,1);
		} // while links
		$ResultHtml.="</UL>";
	} // end: What`s New
	if ($chart==2) { // Top sites
		$ResultHtml=clHeading("Top sites",1)."Most popular sites<br><br><UL>";
		$SiteNavigation="<a href='$PHP_SELF' class=normali><b>Home</b></a> <img src='menu_itema.gif' width='9' height='8' alt='' border='0'><b>Top sites</b>";
		$Links=clMyQuery("SELECT * FROM clLink ORDER BY Hits Desc LIMIT 20;");
		$i=0;
		while ($Link=mysql_fetch_array($Links)) {
			$i++;
			if ($i==2 or $i==8) $ResultHtml.=clBlockAds();
			$ResultHtml.=clDisplayLink($Link,1);
		} // while links
		$ResultHtml.="</UL>";
	} // end: Top sites
	if ($chart==3) { // Editor`s choice
		$ResultHtml=clHeading("Editor`s choice",1)."Sites choosen by the editor as valuable<br><br><UL>";
		$SiteNavigation="<a href='$PHP_SELF' class=normali><b>Home</b></a> <img src='menu_itema.gif' width='9' height='8' alt='' border='0'><b>Editor`s choice</b>";
		$Links=clMyQuery("SELECT * FROM clLink WHERE Choice=1 ORDER BY Hits Desc LIMIT 20;");
		$i=0;
		while ($Link=mysql_fetch_array($Links)) {
			$i++;
			if ($i==2 or $i==8) $ResultHtml.=clBlockAds();
			$ResultHtml.=clDisplayLink($Link,1);
		} // while links
		$ResultHtml.="</UL>";
	} // end: Editor`s choice
} // End: Charts Page

// Start: Search page
if (isset($page) && $page=="search") {
	$search=clHackers($search);
	$SiteNavigation="<a href='$PHP_SELF' class=normali><b>Home</b></a> <img src='menu_itema.gif' width='9' height='8' alt='' border='0'><b>Search</b>";
	$clean=$search;
	$addurl="&search=".$search;
	if ($what==1) { // any word
		$search="%".str_replace(" ","%",$search)."%";
		$addurl.="&what=1";
	} else { // exact phrase
		$search="%".$search."%";
		$addurl.="&what=2";
	}
	$w1=$w2=$w3="default";
	$Query="";
	if (count($where)>=1) {
		foreach ($where as $field) { // where to search
			if ($field=="name") { $Query.=" OR LName LIKE '".$search."'"; $addurl.="&where[]=name"; $w1=1;}
			if ($field=="description") { $Query.=" OR LDescription LIKE '".$search."'"; $addurl.="&where[]=description";  $w2=1;}
			if ($field=="url") { $Query.=" OR LUrl LIKE '".$search."'"; $addurl.="&where[]=url";  $w3=1;}
		}
	}
	$ResultHtml="<div style='float:right; padding:10 10 10 10; background-color:".$EasyClassifields["LightColor1"].";'
	>".clElement("form",$PHP_SELF,"search","GET").clElement("hidden","page","search")."<b>Search again</b><br>".clElement("text","search",$clean,220)." ".clElement("submit","Search")."<br>
	&nbsp;&nbsp;&nbsp;<b>What: </b>".clElement("radio","what","1",$what)." all words ".clElement("radio","what","2",$what)." exact phrase<br>
	<b>Where: </b>".clElement("checkbox","where[]","name",$w1)." name ".clElement("checkbox","where[]","description",$w2)." description  ".clElement("checkbox","where[]","url",$w3)." url</div>";
	if (strlen($Query)>5) { $Query="WHERE ".substr($Query,3,strlen($Query)-3); } else { $nothing=1; }
	$Query="SELECT * FROM clLink ".$Query." ORDER BY Hits Desc, Date Desc";
	if (!isset($from)) $from=0;
	if (!isset($nothing)) { $TotalLinks=mysql_num_rows(clMyQuery($Query.";")); } else { $TotalLinks=0; }
	$ResultHtml.=clHeading("Search results",1)."Found ".$TotalLinks." matches for \"<b>".$clean."</b>\"<ul>";
	if ($TotalLinks>0) {
		$Links=clMyQuery($Query." LIMIT $from,".$EasyClassifields["links_per_page"].";");
		$i=0;
		while ($Link=mysql_fetch_array($Links)) {
			$i++;
			if ($i==3 or $i==8) $ResultHtml.=clBlockAds();
			$ResultHtml.=clDisplayLink($Link,1);
		} // while links
		if ($TotalLinks>0) $ResultHtml.="</UL>";
		if ($from!=0) $ResultHtml.= "<a href='$PHP_SELF?page=search&from=".($from-$EasyClassifields["links_per_page"]).$addurl."'><img src='prev.gif' width='66' height='14' alt='Previous Page' border='0'></a>";
		if ($TotalLinks>$from+$EasyClassifields["links_per_page"]) $ResultHtml.= "<a href='$PHP_SELF?page=search&from=".($from+$EasyClassifields["links_per_page"]).$addurl."'><img src='next.gif' width='66' height='14' alt='Next Page' border='0' hspace=4></a>";
	} else { // nothing found
		$ResultHtml.="<b>Nothing found.</b> Please, check your search string.</UL>";
	}
	$ResultHtml.="<br>".clElement();
} // End: Search Page

// Start: Add Folder page
if (isset($page) && $page=="add_folder" && isset($parent)) {
	$ResultHtml="";
	if ($parent!=0) { // Go navigation
		$found="";
		clFindParents($parent,$found);
		$SiteNavigation=$found."<img src='menu_itema.gif' width='9' height='8' alt='' border='0'><b>Add Folder</b>";
	} else { // Main category
		$SiteNavigation="<a href='$PHP_SELF' class=normali><b>Home</b></a> <img src='menu_itema.gif' width='9' height='8' alt='' border='0'><b>Add Folder</b>";
	} // if
	if (clRegistered($Stoitsov)<0)  { // invalid user
		$page="login";
		$Error="You need to be a registered user in order to add categories.";
	} else { // valid
		if ($parent!=0) {
			$UnderCategory=clMyFetch("SELECT * FROM clCategory WHERE ID=$parent LIMIT 1");
		} else {
			$UnderCategory["CName"]="EasyClassifields";
		} // if
		$ResultHtml.=clHeading("Add Folder",1).
		"<b>Add Folder under ".$UnderCategory["CName"]."</b><br><br>
		<div align=center>
		<table border='0' cellspacing='1' cellpadding='2' bgcolor='".$EasyClassifields["DarkColor"]."' width=200>
			<tr>
				<td>&nbsp;<font color=".$EasyClassifields["Background"]."><b>.: New Folder Information</b></font></td>
			</tr>
			".clElement("form",$PHP_SELF,"Folder","POST")."
			<tr>
				<td bgcolor=".$EasyClassifields["Background"]."><b>Name:</b> [200 Chars max]<br>
				".clElement("text","clICName","",250)."</td>
			</tr>
			<tr>
				<td bgcolor=".$EasyClassifields["Background"]."><b>Description:</b> [255 Chars max]<br>
				".clElement("text","clICDescription","",250)."</td>
			</tr>
			<tr>
				<td align=right>".clElement("submit","Create","f_button")."</td>
			</tr>
			".clElement("hidden","clParent",$parent).clElement("hidden","action","add_folder").clElement()."
		</table><br>".
		$Error
		."</div>";
	} // if valid
} // End: Add Folder page

// Start: Edit Folder page
if (isset($page) && $page=="edit_folder" && isset($id)) {
	$ResultHtml="";
	$found="";
	clFindParents($id,$found);
	$SiteNavigation=$found."<img src='menu_itema.gif' width='9' height='8' alt='' border='0'><b>Edit Folder</b>";
	if (clRegistered($Stoitsov)<0)  { // invalid user
		$page="login";
		$Error="You need to be registered user in order to edit the folders.";
	} else { // valid
		$EditFolder=clMyFetch("SELECT * FROM clCategory WHERE ID=$id LIMIT 1");
		$isEmpty=mysql_num_rows(clMyQuery("SELECT * FROM clLink Where Parent=".$EditFolder["ID"].";"))+
		mysql_num_rows(clMyQuery("SELECT * FROM clCategory Where Parent=".$EditFolder["ID"].";"));
		$CatSelects=clMyQuery("SELECT * FROM clCategory Where ID<>$id ORDER BY Parent, ID;");
		$Under=$Categories[0]="EasyClassifields";
		while ($CatSelect=mysql_fetch_array($CatSelects)) {
			$found="";
			clFindParents($CatSelect["ID"],$found);
			$Categories[$CatSelect["ID"]]=strip_tags(str_replace("<img","> <img",$found));
		} // while
		$ResultHtml.= clHeading("Edit Folder",1).
		 "<b>Edit Folder under ".clGetByID("clCategory","CName",$EditFolder["Parent"])."</b><br><br>
		<div align=center>
		<table border='0' cellspacing='1' cellpadding='2' bgcolor='".$EasyClassifields["DarkColor"]."' width=200>
			<tr>
				<td>&nbsp;<font color=".$EasyClassifields["Background"]."><b>.: Folder Information</b></font></td>
			</tr>
			".clElement("form",$PHP_SELF,"Folder","POST")."
			<tr>
				<td bgcolor=".$EasyClassifields["Background"]."><b>Move folder under:</b> [no change - no move]<br>
				".clElement("select","clParent",$Categories,$EditFolder["Parent"],250)."</td>
			</tr>
			<tr>
				<td bgcolor=".$EasyClassifields["Background"]."><b>Name:</b> [200 Chars max]<br>
				".clElement("text","clICName",$EditFolder["CName"],250)."</td>
			</tr>
			<tr>
				<td bgcolor=".$EasyClassifields["Background"]."><b>Description:</b> [255 Chars max]<br>
				".clElement("text","clICDescription",$EditFolder["CDescription"],250)."</td>
			</tr>
			<tr>
				<td align=right>".clElement("submit","Change","f_button")."</td>
			</tr>
			".clElement("hidden","action","edit_folder").
			clElement("hidden","parent",$EditFolder["Parent"]).
			clElement("hidden","clID",$EditFolder["ID"]).clElement()."
		</table><br>".
		$Error.
		($isEmpty==0 ? "<a href='$PHP_SELF?action=delete_folder&clID=$id&parent=".$EditFolder["Parent"]."' class=normal>You may delete this folder. It is empty.</a>" : "You can not delete this folder. It is not empty." )
		."</div>";
	} // if valid
} // End: Edit Folder page

// Start: Add Link page
if (isset($page) && $page=="add_link" && isset($parent)) {
	$ResultHtml="";
	if ($parent==0) { // Can not add links under root
		$ResultHtml.=clHeading("Add site",1)."<P>You need to enter a category in which you will place your site. Choose from bellow:</P><UL>";
		$CatSelects=clMyQuery("SELECT * FROM clCategory ORDER BY Parent, ID;");
		while ($CatSelect=mysql_fetch_array($CatSelects)) {
			$found="";
			clFindParents($CatSelect["ID"],$found);
			$ResultHtml.="<LI><a href='$PHP_SELF?page=add_link&parent=".$CatSelect["ID"]."' class=normal>".strip_tags(str_replace("<img","> <img",$found))."</a></LI>";
		} // while
		$ResultHtml.="</UL>";
	} else { // add link
		$found="";
		clFindParents($parent,$found);
		$SiteNavigation=$found."<img src='menu_itema.gif' width='9' height='8' alt='' border='0'><b>Add site</b>";
		if ($parent!=0) {
			$UnderCategory=clMyFetch("SELECT * FROM clCategory WHERE ID=$parent LIMIT 1");
		} else {
			$UnderCategory["CName"]="EasyClassifields";
		} // if
		$ResultHtml.= clHeading("Add site",1).
		"<b>Add site in ".$UnderCategory["CName"]."</b><br><br>
		<div align=center>
		<table border='0' cellspacing='1' cellpadding='2' bgcolor='".$EasyClassifields["DarkColor"]."' width=200>
			<tr>
				<td>&nbsp;<font color=".$EasyClassifields["Background"]."><b>.: New Link Information</b></font></td>
			</tr>
			".clElement("form",$PHP_SELF,"Link","POST")."
			<tr>
				<td bgcolor=".$EasyClassifields["Background"]."><b>Link:</b> [255 Chars max]<br>
				".clElement("text","clLUrl","http://",250)."</td>
			</tr>
			<tr>
				<td bgcolor=".$EasyClassifields["Background"]."><b>Site Name:</b> [200 Chars max]<br>
				".clElement("text","clLName","",250)."</td>
			</tr>
			<tr>
				<td bgcolor=".$EasyClassifields["Background"]."><b>Site Description:</b><br>
				".clElement("text","clLDescription","",250)."</td>
			</tr>
			<tr>
				<td align=right>".clElement("submit","Add","f_button")."</td>
			</tr>
			".clElement("hidden","clParent",$parent).
			clElement("hidden","action","add_link").clElement()."
		</table><br>".
		$Error."</div>";
	} // if add link or select category
} // End: Add Link page

// Start: Edit Link page
if (isset($page) && $page=="edit_link" && isset($id) && isset($parent)) {
	$ResultHtml="";
	$found="";
	clFindParents($parent,$found);
	$SiteNavigation=$found."<img src='menu_itema.gif' width='9' height='8' alt='' border='0'><b>Edit Link</b>";
	if (clRegistered($Stoitsov)<0)  { // invalid user
		$page="login";
		$Error="You need to be a registered user in order to edit the links.";
	} else { // valid
		if ($parent!=0) {
			$UnderCategory=clMyFetch("SELECT * FROM clCategory WHERE ID=$parent LIMIT 1");
		} else {
			$UnderCategory["CName"]="EasyClassifields";
		} // if
		$EditLink=clMyFetch("SELECT * FROM clLink WHERE ID=$id LIMIT 1");
		$CatSelects=clMyQuery("SELECT * FROM clCategory ORDER BY Parent;");
		while ($CatSelect=mysql_fetch_array($CatSelects)) {
			$found="";
			clFindParents($CatSelect["ID"],$found);
			$Categories[$CatSelect["ID"]]=strip_tags(str_replace("<img","> <img",$found));
		} // while category
		$ResultHtml.= clHeading("Edit Links",1).
		"<b>Edit Link under ".$UnderCategory["CName"]."</b><br><br>
		<div align=center>
		<table border='0' cellspacing='1' cellpadding='2' bgcolor='".$EasyClassifields["DarkColor"]."' width=200>
			<tr>
				<td>&nbsp;<font color=".$EasyClassifields["Background"]."><b>.: Link Information</b></font></td>
			</tr>
			".clElement("form",$PHP_SELF,"Link","POST")."
			<tr>
				<td bgcolor=".$EasyClassifields["Background"]."><b>Move Link under:</b> [no change - no move]<br>
				".clElement("select","clParent",$Categories,$parent,250)."</td>
			</tr>
			<tr>
				<td bgcolor=".$EasyClassifields["Background"]."><b>Link:</b> [255 Chars max]<br>
				".clElement("text","clLUrl",$EditLink["LUrl"],250)."</td>
			</tr>
			<tr>
				<td bgcolor=".$EasyClassifields["Background"]."><b>Site Name:</b> [200 Chars max]<br>
				".clElement("text","clLName",$EditLink["LName"],250)."</td>
			</tr>
			<tr>
				<td bgcolor=".$EasyClassifields["Background"]."><b>Site Description:</b><br>
				".clElement("text","clLDescription",$EditLink["LDescription"],250)."</td>
			</tr>
			<tr>
				<td bgcolor=".$EasyClassifields["Background"]."><b>Editor`s choice:</b><br>
				".clElement("select","clChoice",array("0"=>"No","1"=>"Yes"),$EditLink["Choice"],250)."</td>
			</tr>
			<tr>
				<td align=right>".clElement("submit","Change","f_button")."</td>
			</tr>
			".clElement("hidden","action","edit_link").
			clElement("hidden","parent",$parent).
			clElement("hidden","clID",$EditLink["ID"]).clElement()."
		</table><br>".
		$Error.
		"<a href='$PHP_SELF?action=delete_link&clID=$id&parent=$parent' class=normal>You may delete this link.</a>"
		."</div>";
	} // if valid
} // End: Edit Link page

// Start: Login page
if (isset($page) && $page=="login") {
	$ResultHtml="";
	$ResultHtml.=clHeading("User authorization",1).
	"You need to be a registered user in order to administer the EasyClassifields.<br><br>
	<div align=center>
	<table border='0' cellspacing='1' cellpadding='2' bgcolor='".$EasyClassifields["DarkColor"]."' width=200>
		<tr>
			<td colspan=2>&nbsp;<font color=".$EasyClassifields["Background"]."><b>.: Login</b></font></td>
		</tr>
		".clElement("form",$PHP_SELF,"Login","POST")."
		<tr>
			<td bgcolor=".$EasyClassifields["Background"]." align=right><b>Username:</b></td>
			<td bgcolor=".$EasyClassifields["Background"].">".clElement("text","clUsername",$clUsername,100)."</td>
		</tr>
		<tr>
			<td bgcolor=".$EasyClassifields["Background"]." align=right><b>Password:</b></td>
			<td bgcolor=".$EasyClassifields["Background"].">".clElement("password","clPassword","",100)."</td>
		</tr>
		<tr>
			<td colspan=2 align=right>".clElement("submit","Login","f_button")."</td>
		</tr>
		".clElement("hidden","action","login").clElement()."
	</table><br>".
	$Error."</div>";
} // End: Login Page




// ********************************************************************
// ********************** HTML Output
// ********************************************************************
//                                You may edit to suit your site design
//                  but *please* leave the donation button & author names
// Start HTML HEADER
echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<html>
<head>
<title>.: EasyClassifields - v".$EasyClassifields["version"]." :.</title>
<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=windows-1251\">
<META NAME=\"description\" CONTENT=\"EasyClassifields Software - by http://software.stoitsov.com\">
<META NAME=\"author\" CONTENT=\"Idea&development - Cyber/SAS\">
";
// CSS Style - Edit to fit your site design
echo "<style type=\"text/css\">
body {
	font: 11px Arial, Helvetica; color:black;
	background-color: ".$EasyClassifields["Background"]."; scrollbar-DarkShadow-Color: ".$EasyClassifields["DarkColor"].";
	scrollbar-Track-Color: ".$EasyClassifields["DarkColor"]."; scrollbar-Face-Color:	".$EasyClassifields["DarkColor"].";
	scrollbar-Shadow-Color:	".$EasyClassifields["Background"]."; scrollbar-Highlight-Color: ".$EasyClassifields["Background"].";
	scrollbar-3dLight-Color: ".$EasyClassifields["DarkColor"]."; scrollbar-Arrow-Color: ".$EasyClassifields["Background"].";
}
.light1 { color: ".$EasyClassifields["LightColor2"]."; }
.light2 { color: ".$EasyClassifields["LightColor1"]."; }
td {
	font: 11px Arial, Helvetica; color: black;
}
.h1s {
	font: 18px Verdana; font-weight:bold; color: ".$EasyClassifields["DarkColor"].";
}
.f_text {
	font: 11px Arial, Helvetica;
	color: black;
	background-color: ".$EasyClassifields["Background"].";
	border: 1px solid ".$EasyClassifields["DarkColor"].";
}
.f_button {
	font: 11px Arial, Helvetica;
	color: ".$EasyClassifields["Background"].";
	background-color: ".$EasyClassifields["DarkColor"].";
	border: 1px solid black;
}
a:link.normal, a:visited.normal {
	font: 11px Arial; color: ".$EasyClassifields["DarkColor"]."; text-decoration:none;
}
a:hover.normal {
	font: 11px Arial; color: red; text-decoration:none;
}
a:link.admin, a:visited.admin {
	font: 11px Arial; color: red; text-decoration:none; font-weight:bold;
}
a:hover.admin {
	font: 11px Arial; color: yellow; text-decoration:none;  font-weight:bold;
}
a:link.normalc, a:visited.normalc {
	font: 16px Arial; color: ".$EasyClassifields["DarkColor"]."; text-decoration:none; font-weight:bold;
}
a:hover.normalc {
	font: 16px Arial; color: red; text-decoration:none; font-weight:bold;
}
a:link.normali, a:visited.normali {
	font: 11px Arial; color: ".$EasyClassifields["DarkColor"]."; text-decoration:none; font-style:italic;
}
a:hover.normali {
	font: 11px Arial; color: red; text-decoration:none; font-style:italic;
}
</style>
";
// Start HTML BODY
echo "</head>
<MAP NAME='buttons_Map'>
<AREA SHAPE='rect' ALT='Add site to EasyClassifields' COORDS='135,2,177,14' HREF='$PHP_SELF?page=add_link&parent=$go'>
<AREA SHAPE='rect' ALT='Top visited sites' COORDS='89,2,133,14' HREF='$PHP_SELF?page=charts&chart=2'>
<AREA SHAPE='rect' ALT='What is new' COORDS='33,2,87,14' HREF='$PHP_SELF?page=charts&chart=1'>
<AREA SHAPE='rect' ALT='Home' COORDS='1,3,31,14' HREF='$PHP_SELF'>
</MAP>
<body OnLoad='self.status=\"EasyClassifields ver.".$EasyClassifields["version"]."\"; return true;'>
<table border='0' cellspacing='0' cellpadding='0' width='".$clWidth."' align=center>
	<tr>
		<td rowspan=2><a href='$PHP_SELF'><img src='logo1.gif' width='120' height='105' alt='' border='0'></a><br></td>
		<td valign=top><a href='$PHP_SELF'><img src='logo2.gif' width='309' height='64' alt='' border='0'></a><br></td>
		<td width=100% background='repeat_top.gif' align=right valign=top>".clTR(1,55)."<br><img src='buttons.gif' width='186' height='22' alt='' border='0' USEMAP='#buttons_Map'><br></td>
		<td valign=top><img src='top_right.gif' width='1' height='77' alt='' border='0'><br></td>
	</tr>
	<tr>
		<td colspan=2 valign=top>".$SiteNavigation."</td>
		<td>".clTr(1,28)."<br></td>
	</tr>
</table>";
echo $ResultHtml;
// HTML FOOTER START
echo "
<br><table border='0' cellspacing='0' cellpadding='0' width='".$clWidth."' align=center>
	<tr>
		<td><img src='bottom_right.gif' width='1' height='33' alt='' border='0'><br></td>
		<td width=100% background='repeat_bottom.gif' valign=top>".clTR(1,5)."<br>
		<img src='secure.gif' width='20' height='7' alt='' border='0'>".(clRegistered($Stoitsov)==2 ? "<a href='$PHP_SELF?action=logout' class=normal>Logout</a> <a href='$PHP_SELF?page=add_folder&parent=0' class=admin>Add Category</a>" : "<a href='$PHP_SELF?page=login' class=normal>Login</a>" )."</td>
		<td><a href='http://software.stoitsov.com' target=_stoitsov><img src='stoitsov.gif' width='176' height='33' alt='Get more free software from Stoitsov.com!' border='0'></a><br></td>
		<td><img src='bottom_right.gif' width='1' height='33' alt='' border='0'><br></td>
	</tr>
</table><br><div align=center>
<a href='http://software.stoitsov.com/free/easyclassifields/' target=_stoitsov><img src='powerclassifields90x30.gif' width='90' height='30' alt='Get your Yahoo-style portal for free!' border='0'></a><br>
<font color='".$EasyGallery["DarkColor"]."'><b>EasyClassifields</b> v".$EasyClassifields["version"]." is a free software by </font><a href='http://software.stoitsov.com' class=normal target=_stoitsov.com>Stoitsov.com</a><br>
To keep it free & developing:<br>
<a href='https://www.paypal.com/affil/pal=mario%40stoitsov.com' target=_donate><img src='donate.gif' width='110' height='23' alt='Support us!' border='0'></a>
</div>
";
// End HTML Output
echo "</body>\n</html>";
/*	******************************************************************
        ********************** EasyClassifields v2.01a **********************
	******************************************** software.stoitsov.com  */
?>
