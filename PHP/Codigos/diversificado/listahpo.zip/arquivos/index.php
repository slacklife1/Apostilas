<html>
<head>
<title>Lista de Emails HPonline</title>
<style>
body      { scrollbar-face-color:FFFFFF;scrollbar-shadow-color:0099CC;scrollbar-highlight-color:0099CC;
            scrollbar-3dlight-color:0099CC;scrollbar-darkshadow-color:0099CC;scrollbar-track-color:FFFFFF;
            scrollbar-arrow-color:0099CC; }
.txt      { font-family:verdana;font-size:8pt;color:000080; }
a:normal  { text-decoration:none;font-family:Verdana;font-size:8pt;color:000080;font-weight: bold; }
a:link    { text-decoration:none;font-family:Verdana;font-size:8pt;color:000080;font-weight: bold; }
a:visited { text-decoration:none;font-family:Verdana;font-size:8pt;color:000080;font-weight: bold; }
a:hover   { text-decoration:none;font-family:Verdana;font-size:8pt;color:0099CC;font-weight: bold; }
</style>
<script>window.defaultStatus='Lista de Email Home Page Online'</script>
</head>
<body topmargin='25' leftmargin='0'>
<?
echo "<div class='txt'><center><br><br><br><br>
<font size='3'><b>Lista de Emails HPonline</b></font><br><br>
<a href='http://www.hpobr.com' target='_blank' onmouseover=\"self.status='Conhe�a a Home Page Online';return true\">www.hpobr.com</a><br><br>
<a href='mailto:hpobr@hpobr.com' onmouseover=\"self.status='Envie sua d�vida ou sugest�o';return true\">hpobr@hpobr.com</a><br><br>
Para fazer seu Login <a href='login.php' onmouseover=\"self.status='Acesso a Administra��o da Lista';return true\">Clique Aqui</a><br><br>
Desenvolvida por Alexandre Pina</center></div>";
?>
</body>
</html>
