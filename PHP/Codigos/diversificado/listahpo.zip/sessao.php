<?
session_start();
if($HTTP_SESSION_VARS["LogInAdmHpo"] != "ok"){
header("Location:login.php");
exit;
}
?>
