<?
/*
	Abaixo est�o todos os modelos de mensagens enviadas para o usu�rio e para o
	administrador da lista. Tenha cuidado ao modificar estes modelos. Voc� pode
	modificar o conte�do dos modelos mas n�o mude o nome das vari�veis.

	Logo abaixo est�o os modelos em duas partes
	1 - Mensagens para o usu�rio
	2 - Mensagens para o administrador
*/

//	1 - Mensagens para o usu�rio

// Assunto do Email de agradecimento ap�s o usu�rio se cadastrar na lista
$EmailAssuntoIn = 'Email adicionado a lista';

// Mensagem ao usu�rio quando ele se cadastra na lista
$MensagemAgradeceIn = "====================
$TituloSite
====================
Lista $NomeDaLista
====================
Prezado(a) $ListaNome

Obrigado por assinar a nossa Lista de Emails

As informa��es adicionadas foram:
Nome: $ListaNome
Email: $ListaEmail
Em: $DataHpo �s $HoraHpo

Obs: Guarde este email, pois caso queira sair da Lista, ser�
necess�rio informar os mesmos dados.

Caso n�o tenha feito a inscri��o em nossa lista, significa
que algu�m cadastrou seu email, para remover utilize o link abaixo:
$UrlDaLista/remover.php?IDout=$ListaEmail

Atenciosamente,
$Webmaster - Admin da Lista $NomeDaLista
$EmailSite
$UrlSite";

// Assunto do Email quando o usu�rio se retira da lista
$EmailAssuntoOut = 'Email retirado da lista';

// Mensagem ao usu�rio quando ele se retira da lista
$MensagemAgradeceOut = "====================
$TituloSite
====================
Lista $NomeDaLista
====================
Prezado(a) $ListaNome

Obrigado por participar de nossa Lista de Emails
Seu email foi retirado com Sucesso

As informa��es exclu�das foram:
Nome: $ListaNome
Email: $ListaEmail
Em: $DataHpo �s $HoraHpo

Atenciosamente,
$Webmaster - Admin da Lista $NomeDaLista
$EmailSite
$UrlSite";

// Mensagem para o usu�rio solicitando a confirma��o do cadastro
$MsgConfirmaCadastro = "====================
$TituloSite
====================
Lista $NomeDaLista
====================
Prezado(a) $ListaNome

Obrigado por assinar a nossa Lista de Emails

Aten��o:
Para que seu cadastro seja efetivado, � necess�rio que voc�
clique ou visite o link abaixo, confirmando sua inscri��o.
$UrlDaLista/confirmar.php?IDin=$ListaEmail

As informa��es adicionadas foram:
Nome: $ListaNome
Email: $ListaEmail
Em: $DataHpo �s $HoraHpo

Caso n�o tenha feito a inscri��o em nossa lista, significa
que algu�m cadastrou seu email, para remover utilize o link abaixo:
$UrlDaLista/remover.php?IDout=$ListaEmail

Atenciosamente,
$Webmaster - Admin da Lista $NomeDaLista
$EmailSite
$UrlSite";

// Mensagem ao usu�rio quando confirma sua inscri��o
$MsgCadastroConfirmado = "====================
$TituloSite
====================
Lista $NomeDaLista
====================
Prezado(a) $ChecaConfirmar[nome]

Obrigado por assinar a nossa Lista de Emails
Seu cadastro foi confirmado com Sucesso

As informa��es adicionadas foram:
Nome: $ChecaConfirmar[nome]
Email: $ChecaConfirmar[email]
Em: $DataHpo �s $HoraHpo

Obs: Guarde este email, pois caso queira sair da Lista, ser�
necess�rio informar os mesmos dados.

Atenciosamente,
$Webmaster - Admin da Lista $NomeDaLista
$EmailSite
$UrlSite";

//	2 - Mensagens para o administrador

// Mensagem para o administrador avisando que a lista foi assinada
$MensagemAvisoIn = "A lista do Site foi assinada
====================
Em $DataHpo - �s $HoraHpo
Por: $ListaNome
Email: $ListaEmail
====================
$TituloSite
$Webmaster";

// Mensagem para o administrador avisando que a lista foi assinada
// (aguardando confirma��o)
$MsgAvisoConfirmaAdm = "A lista do Site foi assinada
====================
Aguardando Confirma��o
======================
Em $DataHpo - �s $HoraHpo
Por: $ListaNome
Email: $ListaEmail
====================
$TituloSite
$Webmaster";

// Mensagem para o administrador quando um usu�rio se retira da lista
$MensagemAvisoOut = "Email retirado da lista via Site
====================
Em $DataHpo - �s $HoraHpo
Por: $ListaNome
Email: $ListaEmail
====================
$TituloSite
$Webmaster";

// Cabe�alho em Html do Envio de mensagem via Administra��o
$MsgHtmlCab = "
<p align='justify'><font face='arial,verdana' color='000080' size='2'><b>$TituloSite</b><br>
===============<br>
<b>Lista de Emails</b> $NomeDaLista<br>
<b>Mensagem enviada em:</b> $DataHpo �s $HoraHpo<br>
===============<br>
Prezado(a) <b>$Linha[nome]</b>,</font></p>";

// Rodap� em Html do Envio de mensagem via Administra��o
$MsgHtmlRod = "<br><br><font face='arial,verdana' color='000080' size='2'>
<p align='justify'>
===============<br>
$Webmaster - Admin da Lista $NomeDaLista<br>
$EmailSite<br>
$UrlSite<br>
<br>
Caso n�o deseje mais receber nossas not�cias:<br>
<a href='$UrlDaLista/remover.php?IDout=$Linha[email]' target='_blank'>Remover meu email</a>
<br><br></font>";

// Mensagem em Text do Envio de mensagem via Administra��o
$MsgTextCab = "$TituloSite
===============
Lista de Emails $NomeDaLista
Mensagem enviada em: $DataHpo �s $HoraHpo
===============
Prezado(a) $Linha[nome],";

$MsgTextRod = "===============
$Webmaster - Admin da Lista $NomeDaLista
$EmailSite
$UrlSite

Caso n�o deseje mais receber nossas not�cias:
$UrlDaLista/remover.php?IDout=$Linha[email]";

// Mensagem para o administrador quando solicita recuperar sua senha
$MsgRecuperaSenha = "$TituloSite
===============
Recupera��o de Senha
Solicita��o feita em: $DataHpo �s $HoraHpo
===============
Prezado(a) $RecNomeCompleto,

Conforme solicitado, segue abaixo suas informa��es
para acesso na �rea de Administra��o da Lista de Emails

Nome do Admin: $RecNome
Senha do Admin: $RecSenha

Obs: Caso voc� n�o tenha feito a solicita��o,
significa que algu�m tentou acessar a Administra��o
da Lista sem autoriza��o
===============
$EmailSite
$UrlSite";

// Mensagem para o Administrador quando o usu�rio se retira
// da lista pelo link de uma mensagem enviada para ele
$MsgRemoverAuto = "Email retirado da lista via Web
====================
Em $DataHpo - �s $HoraHpo
Por: $ChecaExcluir[nome]
Email: $ChecaExcluir[email]
====================
$TituloSite
$Webmaster";

// Mensagem para o Administrador avisando sobre a confirma��o do cadastro
$MsgCadastroConfirmadoAdm = "Cadastro de usu�rio confirmado
====================
Em $DataHpo - �s $HoraHpo
Por: $ChecaConfirmar[nome]
Email: $ChecaConfirmar[email]
====================
$TituloSite
$Webmaster";

?>
