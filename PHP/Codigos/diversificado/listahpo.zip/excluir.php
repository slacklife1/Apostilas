<?
require ("sessao.php");
require ("config.php");
$LocalArq = '/admin.php';
$LocalCorreto = $UrlDaLista . $LocalArq;
if ($SCRIPT_URI != $LocalCorreto) {
	if (!headers_sent()) {
	header("Location:admin.php?Acao=Excluir");
	exit;
	}
}
        abre_conexao_db();
	    $Consultar = mysql_query("select * from $TableNome");
			if (mysql_num_rows($Consultar) == 0) {
			$Conclusao = "<b>N�o existem registros no Banco de Dados";
			fecha_conexao_db();
			imprime_resultado();
			}
			elseif ($Acao == "Excluir" and !$submit) {
			echo "<br><table border=\"0\" width=\"100%\">
<form method=\"POST\" action=\"admin.php?Acao=Excluir\">
<tr><td width=\"100%\" valign=\"middle\" align=\"center\" class=\"txt\">
Escolha na rela��o abaixo o usu�rio que deseja <b>Excluir</b><br><br><select size=\"1\" name=\"ExcluirID\">
<option>Rela��o dos usu�rios cadastrados na Lista $NomeDaLista</option>";
abre_conexao_db();
$ConsultaRapida = mysql_query("select * from $TableNome");
fecha_conexao_db();
while($LinhaBRap = mysql_fetch_array($ConsultaRapida)) {
if ($LinhaBRap[ativo] == 0) { $InfoAtivo = Inativo; }
if ($LinhaBRap[ativo] == 1) { $InfoAtivo = Ativo; }
echo "<option value=\"$LinhaBRap[id]\">$LinhaBRap[id] - $LinhaBRap[nome] - $LinhaBRap[email] - $InfoAtivo</option>";
}
echo "</select></td></tr>
<tr><td width=\"100%\" valign=\"middle\" align=\"center\">
<input type=\"submit\" name=\"submit\" value=\" Excluir Usu�rio \" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">
<input type=\"hidden\" name=\"ExcluirUsuario\" value=\"1\">
</form></td></tr></table>";
	}
	if ($Acao == "Excluir" and $ExcluirUsuario == "1") {
	abre_conexao_db();
    $ConsultaExcluir = mysql_query("select * from $TableNome WHERE (id='" . $ExcluirID . "')");
	$ChecaExcluir = mysql_fetch_assoc($ConsultaExcluir);
       	if ($ChecaExcluir) {
        $deletar = mysql_query("DELETE FROM $TableNome WHERE (id='".$ExcluirID."')");
        $NovaInfo = "<b>Exclus�o de usu�rio ($AdminLogado)</b><br>Nome: $ChecaExcluir[nome] || Email: $ChecaExcluir[email]";
		InfoLog();
		fecha_conexao_db();
        	if ($deletar) { $Conclusao = "A exclus�o do cadastro foi efetuada com <b>Sucesso</b><br><br><b>Informa��es Exclu�das:</b><br><br><b>ID:</b> $ChecaExcluir[id] - <b>Nome:</b> $ChecaExcluir[nome] - <b>Email:</b> $ChecaExcluir[email]<br><br>
<input type=\"button\" value=\" Excluir outro Usu�rio \" onClick=\"location='$PHP_SELF?Acao=Excluir'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
			imprime_resultado();
			}
		}
		else { $Conclusao = "Prezado Administrador da Lista $NomeDaLista.<br><br>Voc� tem que selecionar um usu�rio para poder <b>Excluir</b><br><br>
<input type=\"button\" value=\" Voltar e Corrigir \" onClick=\"location='$PHP_SELF?Acao=Excluir'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
		imprime_resultado();
		}
	}
?>
