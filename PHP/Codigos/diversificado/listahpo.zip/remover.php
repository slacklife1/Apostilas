<?php

require ("config.php");
require ("funcoes.php");

echo "<html><head>
<title>Lista de Emails HPonline</title>
</script>
<style>
body      { scrollbar-face-color:FFFFFF;scrollbar-shadow-color:0099CC;scrollbar-highlight-color:0099CC;
            scrollbar-3dlight-color:0099CC;scrollbar-darkshadow-color:0099CC;scrollbar-track-color:FFFFFF;
            scrollbar-arrow-color:0099CC; }
.txt      { font-family:verdana;font-size:8pt;color:000080; }
a:normal  { text-decoration:none;font-family:Verdana;font-size:8pt;color:000080;font-weight: bold; }
a:link    { text-decoration:none;font-family:Verdana;font-size:8pt;color:000080;font-weight: bold; }
a:visited { text-decoration:none;font-family:Verdana;font-size:8pt;color:000080;font-weight: bold; }
a:hover   { text-decoration:none;font-family:Verdana;font-size:8pt;color:0099CC;font-weight: bold; }
</style>
<script>window.defaultStatus='$TituloSite - Removendo Email da Lista de Email $NomeDaLista'</script>
</head><body>";

print ("<center><br><table border=\"1\" bordercolor=\"0099CC\"width=\"90%\"><tr><td>");

abre_conexao_db();
$ConsultaExcluir = mysql_query("select * from $TableNome WHERE (email='" . $IDout . "')");
$ChecaExcluir = mysql_fetch_assoc($ConsultaExcluir);
if ($ChecaExcluir) {
$NovaInfo = "<b>Auto Remo��o via Web</b><br>O usu�rio $ChecaExcluir[nome] se retirou da Lista<br>Email retirado: $ChecaExcluir[email]";
InfoLog();
$deletar = mysql_query("delete from $TableNome WHERE email='" . $IDout . "'");
fecha_conexao_db();
if ($deletar) { $Conclusao = "Prezado(a) <b>$ChecaExcluir[nome]</b><br><br>Seu Cadastro foi exclu�do com <b>Sucesso</b><br><br>Email exlclu�do: <b>$ChecaExcluir[email]</b><br><br>Obrigado - $Webmaster<br><br>Lista de Emails $NomeDaLista - $TituloSite - $UrlSite";
require ("modelos.php");
mail("$EmailSite", "Email Retirado da Lista", "$MsgRemoverAuto", "From: Remover Auto Web<$EmailSite>");
imprime_resultado();
}
}
else { $Conclusao = "Prezado(a) usu�rio(a)<br><br>Seu Cadastro <b>n�o foi exclu�do</b> porque o email <b>n�o consta mais</b> em nossa lista<br><br>Obrigado - $Webmaster<br><br>Lista de Emails $NomeDaLista - $TituloSite - $UrlSite";
imprime_resultado();
}

print ("</td></tr></table>");

?>
</body>
</html>

