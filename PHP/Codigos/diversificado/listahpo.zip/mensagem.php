<?
require ("sessao.php");
require ("config.php");
$LocalArq = '/admin.php';
$LocalCorreto = $UrlDaLista . $LocalArq;
if ($SCRIPT_URI != $LocalCorreto) {
	if (!headers_sent()) {
	header("Location:admin.php?Acao=Mensagem");
	exit;
	}
}
    abre_conexao_db();
	    $Consultar = mysql_query("select * from $TableNome");
			if (mysql_num_rows($Consultar) == 0) {
			$Conclusao = "<b>N�o existem registros no Banco de Dados";
			fecha_conexao_db();
			imprime_resultado();
			}
			elseif ($Acao == "Mensagem" and !$submit) {
			echo "<table border=\"0\" width=\"100%\">
<form method='POST' action='admin.php?Acao=Mensagem' name='Admin' ENCTYPE=\"multipart/form-data\">
<tr><td width='75%' colspan='2' valign='middle' align='center' class='txt'>
<p align='center' style='margin-left:5;margin-right:5;margin-top:5'>Digite abaixo o <b>Assunto e o Texto da Mensagem</b> que deseja <b>Enviar</b></td>
<td width='25%' valign='top' align='center' class='txt' rowspan='6'>
<p align='justify' style='margin-left:5;margin-right:5;margin-top:5'><b><font color='FF0000'>Aten��o: </font></b>
As mensagens s�o enviadas apenas para os usu�rios com cadastro ativo<br><b>Mensagem em Texto</b><br>
Para enviar sua mensagem em apenas texto, basta digit�-la e ela ser� enviada do mesmo modo
como voc� v�<br><b>Mensagem em Html</b><br>Para mensagens em html, voc� pode digitar o c�digo
como tamb�m criar a mesma no seu editor de html preferido e depois colar no campo mensagem<br>
<b>Anexos</b><br>Basta clicar em procurar para selecionar o arquivo desejado em seu micro</td></tr>
<tr><td width='10%' valign='middle' align='right' class='txt'>
<b>Assunto:</b> </td>
<td width='50%' valign='middle' align='left'>
<input type='text' size='66' name='AssuntoMail' style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
</td></tr>
<tr><td width='10%' valign='middle' align='right' class='txt'>
<b>Mensagem:</b> </td>
<td width='50%' valign='middle' align='left'>
<textarea type='text' rows='10' cols='65' name='MensagemMail' style='color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
</textarea></td></tr>
<tr><td width='10%' valign='middle' align='right' class='txt'>
<b>Anexo:</b> </td>
<td width='50%' valign='middle' align='left'>
<input type='file' size='50' name='anexo' style='font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080'><br>
<input type='hidden' name='MAX_FILE_SIZE' value='100000'></td></tr>
<tr><td width='10%' valign='middle' align='right' class='txt'></td>
<td width='50%' valign='middle' align='left' class='txt'>
<b>Formato da Mensagem:</b><input type='radio' name='FormatoMsg' value='Text' checked> <b>Text</b>
<input type='radio' name='FormatoMsg' value='Html'> <b>Html</b>
</td></tr>
<tr><td colspan='2' valign='middle' align='center'>
<input type='hidden' name='EnvMsg' value='1'>";
if(isset($_GET['MsgVista'])){
echo "<input type='hidden' name='MsgVista' value='$MsgVista'>"; }
echo "<input type='submit' name='submit' value=' Enviar o Mensagem ' style='cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080'>
<script>document.Admin.AssuntoMail.focus();</script>
</form></td></tr></table>";
}
if ($Acao == "Mensagem" and $EnvMsg == "1" and !$MsgVista ) {
		if (!empty($AssuntoMail) and !empty($MensagemMail)) { $MsgVista = 1; }
		else {
		if (empty($AssuntoMail) or empty($MensagemMail)) {
		if (empty($AssuntoMail) and empty($MensagemMail)) { $ErroMensagem3 = "os seguintes erros:"; } else { $ErroMensagem3 = "o seguinte erro:"; }
		if (empty($AssuntoMail)) { $ErroMensagem1 = "<b><font color=FF0000>Mensagem Sem Assunto</font></b>"; }
		if (empty($MensagemMail)) { $ErroMensagem2 = "<b><font color=FF0000>Mensagem Sem Texto</font></b>"; }
		$Conclusao = "<b><font color=FF0000> << A T E N � � O >> </font>&nbsp;&nbsp;&nbsp; Administrador</b> || A Mensagem apresenta $ErroMensagem3<br>
<br>$ErroMensagem1&nbsp;&nbsp;&nbsp;$ErroMensagem2<br><br>
<input type='button' value=' Voltar e Refazer a Mensagem ' onClick=\"location='$PHP_SELF?Acao=Mensagem&MsgVista=1'\" style=\"width:280;height:18;cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">
<br><br><font color='FF0000'><b>A V I S O</b></font> - Esta mensagem de erro foi configurada para aparecer <b>uma �nica vez</b>";
	imprime_resultado();
		}
		}
		}
	if ($submit and $Acao == "Mensagem" and $EnvMsg == "1" and $MsgVista == "1") {
	abre_conexao_db();
	$ConsultaMensagem = mysql_query("select * from $TableNome WHERE ativo=1 order by id desc");
	$TotalLinhas = mysql_num_rows($ConsultaMensagem);
	while($Linha = mysql_fetch_array($ConsultaMensagem)) {
		$EmailAssunto = $AssuntoMail;
		if (empty($AssuntoMail)) { $EmailAssunto = "Sem Assunto"; }
		if (empty($MensagemMail)) { $MsgHtmlCorpo = "Sem Mensagem"; }
		if (empty($MensagemMail)) { $MsgTxtCorpo = "Sem Mensagem"; }
		$mime_list = array("html"=>"text/html","htm"=>"text/html", "txt"=>"text/plain", "rtf"=>"text/enriched","csv"=>"text/tab-separated-values","css"=>"text/css","gif"=>"image/gif");
		$ABORT = FALSE;
		$boundary = "XYZ-" . date(dmyhms) . "-ZYX";
		require ("modelos.php");

		$message = "--$boundary\n";
		$message .= "Content-Transfer-Encoding: 8bits\n";
			if ($FormatoMsg == Text) {
			$message .= "Content-Type: text/plain; charset=\"ISO-8859-1\"\n\n";
			} elseif ($FormatoMsg == Html) {
			$message .= "Content-Type: text/html; charset=\"ISO-8859-1\"\n\n";
			}
			if ($FormatoMsg == Text) {
			$message .= "$MsgTextCab\n\n$MensagemMail\n\n$MsgTextRod\n\n";
			} elseif ($FormatoMsg == Html) {
			$MsgHtmlCorpo = str_replace("\\","", $HTTP_POST_VARS[MensagemMail]);
			$message .= "$MsgHtmlCab\n\n$MsgHtmlCorpo\n\n$MsgHtmlRod\n\n";
			}
			$message .= "\n";

		// Nome do anexo com path completo
		$attachments[1] = $anexo;

		// Checa se o anexo existe e codifica
	foreach ($attachments as $key => $full_path) {
	if ($full_path !='') {
       if (file_exists($full_path)){
       // Tenta abrir o arquivo
             if ($fp = fopen($full_path,"rb")) {
                     // Pega o nome do arquivo com o path completo
                     $filename = array_pop(explode(chr(92),$full_path));
                     $contents = fread($fp,filesize($full_path));
                     // Codifica o arquivo
                     $encoded = base64_encode($contents);
                     // SPLIT o arquivo codificado
                     $encoded_split = chunk_split($encoded);
                     fclose($fp);
                     $message .= "--$boundary\n";
                     $message .= "Content-Type: $anexo_type\n";
                     $message .= "Content-Disposition: attachment; filename=\"$anexo_name\" \n";
                     $message .= "Content-Transfer-Encoding: base64\n\n";
                     $message .= "$encoded_split\n";
             }
             else {
             echo "Cannot open file$key: $filename";
             $ABORT = TRUE;
             }
       }
       else {
       echo "File$key does not exist: $filename";
       $ABORT = TRUE;
       }
}
}

$message .= "--$boundary--\r\n";

$headers = "MIME-Version: 1.0\n";
$headers .= "From: $TituloSite<$EmailSite>\r\n";
$headers .= "Content-type: multipart/mixed; boundary=\"$boundary\"\r\n";

mail($Linha[email], $EmailAssunto, $message, $headers);

$ConfereConexao = mysql_ping($conexao);
if(!$ConfereConexao){ $Conclusao = "<font color='FF0000'><b> | A T E N � � O | </b></font> - A Conex�o com o Banco de Dados <b>foi perdida !!!</b><br>
<br><b>A �ltima mensagem enviada foi para:</b><br><br><b>ID:</b> $Linha[id] - <b>Nome:</b> $Linha[nome] - <b>Email:</b> $Linha[email]<br>
<br><input type=\"button\" value=\" Enviar nova Mensagem \" onClick=\"location='$PHP_SELF?Acao=Mensagem'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
			$NovaInfo = "<b>Envio de Mensagem ($AdminLogado) - <font color=FF0000>Falha na Conex�o</font></b><br>Falha de conex�o com o banco de dados durante o envio da mensagem com o Assunto: $EmailAssunto";
			InfoLog(); imprime_resultado(); echo "</td></tr></table>"; footer(); exit;
			}
		}
	if ($FormatoMsg == Html) { $FormatoMensagem = "Html"; }
	if ($FormatoMsg == Text) { $FormatoMensagem = "Texto"; }
	if (empty($AssuntoMail)) { $SemAssunto = "<br>A mensagem foi enviada Sem Assunto<br>"; }
	if (empty($MensagemMail)) { $SemMensagem = "<br>A mensagem foi enviada Sem Texto"; }
	$NovaInfo = "<b>Envio de Mensagem ($AdminLogado) - Formato $FormatoMensagem</b><br>Assunto: $EmailAssunto - Enviada para $TotalLinhas usu�rios";
	InfoLog(); fecha_conexao_db();
	$Conclusao = "<b>Mensagem Enviada com Sucesso<br><br>Foram enviados $TotalLinhas emails</b><br>
<br><input type=\"button\" value=\" Enviar nova Mensagem \" onClick=\"location='$PHP_SELF?Acao=Mensagem'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">
<br><font color='FF0000'><b>$SemAssunto $SemMensagem</b></font>";
	imprime_resultado();
}

?>
