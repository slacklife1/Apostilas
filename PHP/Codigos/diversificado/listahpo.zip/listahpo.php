<?php

require ("config.php");

$TableExtLog = "_log";
$TableLog = $TableNome . $TableExtLog;

function abre_conexao_db() {
global $db; global $TableNome; global $conexao; global $erro; global $n_erros;
$conexao = mysql_connect($db[host], $db[user], $db[senha]);
	if (!$conexao) { $erro.= "ERRO - N�o foi poss�vel conectar com o Banco de Dados" . mysql_erro();
	$n_erros++; exit;
	}
mysql_select_db($db[nome],$conexao);
	if (!mysql_select_db($db[nome],$conexao)) { $erro.= "ERRO - N�o foi poss�vel selecionar a tabela no Banco de Dados" . mysql_erro();
	$n_erros++; exit;
	}
}

function fecha_conexao_db() {
global $conexao;
mysql_close($conexao);
}

function imprime_resultado() {
global $TableConfig; global $Conclusao; global $Copyright;
echo "
<div align='center'>
<center>
<table width=$TableConfig[1] border=$TableConfig[2] bordercolor=$TableConfig[4] cellpadding=$TableConfig[7] cellspacing=$TableConfig[7] bgcolor=$TableConfig[3]>
<tr><td width='100%' align='center' valign='middle' bordercolorlight=$TableConfig[5] bordercolordark=$TableConfig[6] style=$TableConfig[9]>
<br>$Conclusao<br>
<form method=post action='$PHP_SELF'>
<input type=\"submit\" value=\" Voltar \" style=$TableConfig[11]><br><br>$Copyright
</form></td></tr></table></center></div>";
}

// Verifica a validade do email

function verifica_mail($mail) {
if (strpos ($mail, "@") == 0) {
return true;
}
list($user,$domain)=split("@",$mail,2);
	if (checkdnsrr($domain,"MX")) {
	return false;
	}
	else {
	return true;
	}
}

// Verifica se os campos est�o vazios

if($Acao == "incluir" or $Acao == "excluir") {
	$n_erros = 0;
	$erro = "  ";
	if(empty($ListaNome)) {
	$erro.= "ERRO - Digitar o nome<br>";
	$n_erros++;
	}
	if(empty($ListaEmail)) {
	$erro.= "ERRO - Digitar o email<br>";
	$n_erros++;
	}
	elseif (verifica_mail($ListaEmail)) {
	$erro.= "ERRO - Confira o email<br>";
	$n_erros++;
	}

} // Fecha verifica��o de campos vazios e exist�ncia do email

// Se n�o h� erros, abre o banco de dados, verifica e inclui as informa��es
// Com envio de emails para o usu�rio (opcional) e para o Webmaster (n�o opcional)

if($Acao == "incluir" and $n_erros == "0" or $Acao == "excluir" and $n_erros == "0") {

	if($Acao == "incluir" and $n_erros == "0") {
	abre_conexao_db();
    $ConsultaIncluir = mysql_query("select email from $TableNome WHERE (email='" . $ListaEmail . "')");
	$ChecaIncluir = mysql_fetch_assoc($ConsultaIncluir);
       	if ($ChecaIncluir) { $Conclusao = "Prezado(a) <b>$ListaNome</b><br>Seu Cadastro <b>n�o foi efetuado</b> porque o email: $ListaEmail <b>j� consta</b> em nossa lista<br>Obrigado - $Webmaster";
		imprime_resultado();
		}
		elseif (!$ChecaIncluir and $ConfirmaCadastro == 1) {
		$NovaInfo = "<b>Auto Inclus�o via Site - Aguardando Confirma��o</b><br>O usu�rio $ListaNome se cadastrou na Lista<br>Email inclu�do: $ListaEmail";
        $log = mysql_query("INSERT INTO $TableLog (info, data, hora) VALUES('$NovaInfo','$DataHpo','$HoraHpo')");
		$InfoAtivo = 0;
        $inserir = mysql_query("INSERT INTO $TableNome (nome, email, data, hora, ativo) VALUES('$ListaNome','$ListaEmail','$DataHpo','$HoraHpo','$InfoAtivo')");
		fecha_conexao_db();
        	if ($inserir) { $Conclusao = "Prezado(a) <b>$ListaNome</b><br>Seu Cadastro foi registrado com <b>Sucesso</b><br>Email inclu�do: $ListaEmail<br>Voc� receber� em momentos um email para confirmar sua inscri��o<br>Obrigado - $Webmaster";
				require("$PathDaLista/modelos.php");
				mail("$ListaEmail", "$EmailAssuntoIn", "$MsgConfirmaCadastro", "From: $TituloSite<$EmailSite>");
                mail("$EmailSite", "$EmailAssuntoIn", "$MsgAvisoConfirmaAdm", "From: $TituloSite<$EmailSite>");
				imprime_resultado();
			}
		}
		else {
        $NovaInfo = "<b>Auto Inclus�o via Site</b><br>O usu�rio $ListaNome se cadastrou na Lista<br>Email inclu�do: $ListaEmail";
        $log = mysql_query("INSERT INTO $TableLog (info, data, hora) VALUES('$NovaInfo','$DataHpo','$HoraHpo')");
		$InfoAtivo = 1;
        $inserir = mysql_query("INSERT INTO $TableNome (nome, email, data, hora, ativo) VALUES('$ListaNome','$ListaEmail','$DataHpo','$HoraHpo','$InfoAtivo')");
		fecha_conexao_db();
        	if ($inserir) { $Conclusao = "Prezado(a) <b>$ListaNome</b><br>Seu Cadastro foi efetuado com <b>Sucesso</b><br>Email inclu�do: $ListaEmail<br>Obrigado - $Webmaster";
				require("$PathDaLista/modelos.php");
				if ($MsgAgradece == '1') {
				mail("$ListaEmail", "$EmailAssuntoIn", "$MensagemAgradeceIn", "From: $TituloSite<$EmailSite>");
				}
                mail("$EmailSite", "$EmailAssuntoIn", "$MensagemAvisoIn", "From: $TituloSite<$EmailSite>");
				imprime_resultado();
			}
		}
	}
	
// Se n�o h� erros, abre o banco de dados, verifica e exclui as informa��es
// Com envio de emails para o usu�rio e para o Webmaster

	if($Acao == "excluir" and $n_erros == "0") {
	abre_conexao_db();
    $ConsultaExcluir = mysql_query("select * from $TableNome WHERE (email='" . $ListaEmail . "')");
	$ChecaExcluir = mysql_fetch_assoc($ConsultaExcluir);
       	if ($ChecaExcluir) {
        $NovaInfo = "<b>Auto Remo��o via Site</b><br>O usu�rio $ChecaExcluir[nome] se retirou da Lista<br>Email retirado: $ChecaExcluir[email]";
        $log = mysql_query("INSERT INTO $TableLog (info, data, hora) VALUES('$NovaInfo','$DataHpo','$HoraHpo')");
        $deletar = mysql_query("delete from $TableNome WHERE email='" . $ListaEmail . "'");
		fecha_conexao_db();
			if ($deletar) { $Conclusao = "Prezado(a) <b>$ListaNome</b><br>Seu Cadastro foi exclu�do com <b>Sucesso</b><br>Email exclu�do: $ListaEmail<br>Obrigado - $Webmaster";
			require("$PathDaLista/modelos.php");
			mail("$ListaEmail", "$EmailAssuntoOut", "$MensagemAgradeceOut", "From: $TituloSite<$EmailSite>");
			mail("$EmailSite", "$EmailAssuntoOut", "$MensagemAvisoOut", "From: $TituloSite<$EmailSite>");
			imprime_resultado();
			}
		}
		else { $Conclusao = "Prezado(a) <b>$ListaNome</b><br>Seu Cadastro <b>n�o foi exclu�do</b> porque o email: $ListaEmail <b>n�o consta</b> em nossa lista<br>Obrigado - $Webmaster";
  		imprime_resultado();
		}
	}
	
} // Fim da inclus�o ou exclus�o

// Se n�o executa nada vai para o Formul�rio

else {
print ("<form method=post action='$PHP_SELF'>
<div align=\"center\">
<center>
<table width=$TableConfig[1] border=$TableConfig[2] bordercolor=$TableConfig[4] cellpadding=$TableConfig[7] cellspacing=$TableConfig[7] bgcolor=$TableConfig[3]>
<tr><td width='100%' align='center' valign='middle' bordercolorlight=$TableConfig[5] bordercolordark=$TableConfig[6] style=$TableConfig[9]>
$CabLista</td></tr>
<tr><td width='100%' align='center' valign='middle' bordercolorlight=$TableConfig[5] bordercolordark=$TableConfig[6] style=$TableConfig[9]>
<b>Nome:</b><BR><input type=\"text\" name=\"ListaNome\" size=$TableConfig[8] style=$TableConfig[10]><br>
<b>E-mail:</b><BR><input type=\"text\" name=\"ListaEmail\" size=$TableConfig[8] style=$TableConfig[10]><br>
<input type=\"radio\" name=\"Acao\" value=\"incluir\" checked> Incluir <input type=\"radio\" name=\"Acao\" value=\"excluir\"> Excluir<br>
<center><table border='0' cellpadding='0' cellspacing='0'>
<tr><td valign='middle' align='left' width='30' height='25'>
<a href=\"#\" onclick=\"window.open('$UrlDaLista/arquivos/incluir.htm','IncluirLista','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=yes,top=30,left=20,width=270,height=370');return false\" onMouseOver=\"self.status='Informa��es para Incluir seu Email';return true\">
<img border='0' src='$UrlDaLista/arquivos/incluir.gif' alt='Informa��es para Incluir' width='20' height='20'></a></td>
<td valign='middle' align='center'>
<input type=\"submit\" value=\" Enviar \" style=$TableConfig[11]></td>
<td valign='middle' align='right' width='30' height='25'>
<a href=\"#\" onclick=\"window.open('$UrlDaLista/arquivos/excluir.htm','ExcluirLista','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=yes,top=30,left=300,width=270,height=310');return false\" onMouseOver=\"self.status='Informa��es para Excluir seu Email';return true\">
<img border='0' src='$UrlDaLista/arquivos/excluir.gif' alt='Informa��es para Excluir' width='20' height='20'></a></td>
</tr></table></center>
<font color=red size=1>$erro</font></form></td></tr></table></center></div>");

} // Fim do Else - Fim do Script

?>


