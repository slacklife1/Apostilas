<?php

require ("config.php");
require ("funcoes.php");

echo "<html><head>
<title>Lista de Emails HPonline</title>
</script>
<style>
body      { scrollbar-face-color:FFFFFF;scrollbar-shadow-color:0099CC;scrollbar-highlight-color:0099CC;
            scrollbar-3dlight-color:0099CC;scrollbar-darkshadow-color:0099CC;scrollbar-track-color:FFFFFF;
            scrollbar-arrow-color:0099CC; }
.txt      { font-family:verdana;font-size:8pt;color:000080; }
a:normal  { text-decoration:none;font-family:Verdana;font-size:8pt;color:000080;font-weight: bold; }
a:link    { text-decoration:none;font-family:Verdana;font-size:8pt;color:000080;font-weight: bold; }
a:visited { text-decoration:none;font-family:Verdana;font-size:8pt;color:000080;font-weight: bold; }
a:hover   { text-decoration:none;font-family:Verdana;font-size:8pt;color:0099CC;font-weight: bold; }
</style>
<script>window.defaultStatus='$TituloSite - Confirmando Cadastro de Email da Lista de Email $NomeDaLista'</script>
</head><body>";

print ("<center><br><table border=\"1\" bordercolor=\"0099CC\"width=\"90%\"><tr><td>");

abre_conexao_db();
$ConsultaConfirmar = mysql_query("select * from $TableNome WHERE (email='" . $IDin . "')");
$ChecaConfirmar = mysql_fetch_assoc($ConsultaConfirmar);
if ($ChecaConfirmar[ativo] != 1) {
$InfoAtivo = 1;
$Ativando = mysql_query("UPDATE $TableNome SET ativo='$InfoAtivo' WHERE email='" . $IDin . "'");
$NovaInfo = "<b>Confirma��o de Cadastro</b><br>O usu�rio $ChecaConfirmar[nome] ativou seu cadastro na lista<br>Email Inclu�do: $ChecaConfirmar[email]";
InfoLog();
fecha_conexao_db();
$Conclusao = "Prezado(a) <b>$ChecaConfirmar[nome]</b><br><br>Seu Cadastro foi ativado com <b>Sucesso</b><br><br>Email inclu�do: <b>$ChecaConfirmar[email]</b><br><br>Obrigado - $Webmaster<br><br>Lista de Emails $NomeDaLista - $TituloSite - $UrlSite";
require ("modelos.php");
mail("$ChecaConfirmar[email]", "Confirma��o de Cadastro", "$MsgCadastroConfirmado", "From: Confirma Auto Web<$EmailSite>");
mail("$EmailSite", "Confirma��o de Cadastro", "$MsgCadastroConfirmadoAdm", "From: Confirma Auto Web<$EmailSite>");
imprime_resultado();
}
else { $Conclusao = "Prezado(a) usu�rio(a)<br><br>Seu Cadastro <b>j� foi confirmado</b> em nossa lista<br><br>Obrigado - $Webmaster<br><br>Lista de Emails $NomeDaLista - $TituloSite - $UrlSite";
imprime_resultado();
}

print ("</td></tr></table>");

?>
</body>
</html>

