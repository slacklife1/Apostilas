<?
require ("sessao.php");
require ("config.php");
$LocalArq = '/admin.php';
$LocalCorreto = $UrlDaLista . $LocalArq;
if ($SCRIPT_URI != $LocalCorreto) {
	if (!headers_sent()) {
	header("Location:admin.php?Acao=Buscar");
	exit;
	}
}
    abre_conexao_db();
	$Consultar = mysql_query("select * from $TableNome");
	if (mysql_num_rows($Consultar) == 0) {
	$Conclusao = "<b>N�o existem registros no Banco de Dados";
	imprime_resultado();
	fecha_conexao_db();
	}
	elseif (!$submit) {
	echo "<br><table border=\"0\" width=\"100%\">
<form method=\"POST\" action=\"admin.php?Acao=Buscar\" name='Admin'>
<tr><td width=\"100%\" valign=\"middle\" align=\"center\" class=\"txt\">
Digite abaixo o <b>Nome ou Email</b> que deseja procurar</td></tr>
<tr><td width=\"100%\" valign=\"middle\" align=\"center\">
<input type=\"text\" size=\"55\" name=\"Busca\" style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
</td></tr>
<tr><td width=\"100%\"  valign=\"middle\" align=\"center\">
<input type=\"submit\" name=\"submit\" value=\" Buscar Usu�rio \" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">
<script>document.Admin.Busca.focus();</script>
</form></td></tr></table>";
	}
	elseif ($submit) {
	$n_erros = 0;
	$erro = "  ";
	if(empty($Busca)) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - Voc� esqueceu de digitar um <b>Nome ou Email</b><br>";
	$n_erros++;
	}
	if ($n_erros != 0) { $Conclusao = "$erro<br>
<input type=\"button\" value=\" Voltar e Corrigir \" onClick=\"location='$PHP_SELF?Acao=Buscar'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
imprime_resultado(); }
	}
    if ($submit and $n_erros == "0") {
    abre_conexao_db();
	$BuscaUsu = str_replace(" ","%", $HTTP_POST_VARS[Busca]);
	$Consultar = mysql_query("SELECT * FROM $TableNome WHERE nome LIKE '%".$BuscaUsu."%' or email LIKE '%".$BuscaUsu."%' ORDER BY id DESC");
	$TotalBusca = mysql_num_rows($Consultar);
	fecha_conexao_db();
	   if (mysql_num_rows($Consultar) == 0) {
       $Conclusao = "<b>N�o existe</b> nenhum usu�rio com essa informa��o: <b>$BuscaUsu</b><br><br>
<input type=\"button\" value=\" Voltar para Nova Busca \" onClick=\"location='$PHP_SELF?Acao=Buscar'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
	   imprime_resultado();
	   }
       else {
	   echo "<center><table width='90%'  border='0'><tr>
	   <td width='100%' colspan='4' height='35' align='center' valign='middle' class='txt'>
A busca por: <b>$BuscaUsu</b> retornou <b>($TotalBusca)</b> resultados</b></td></tr>
	   <tr><td align='left' valign='middle' class='txt'><b>Nome</b></td>
	   <td align='left' valign='middle' class='txt'><b>Email</b></td>
	   <td align='center' valign='middle' class='txt'><b>Ativo</b></td>
	   <td align='center' valign='middle' class='txt'><b>Inclu�do em:</b></td></tr>";

	   while ($ResBus = mysql_fetch_array($Consultar)) {
		if ($ResBus[ativo] == 0) { $InfoAtivo = "<font color='FF0000'>N�o</font>"; }
		if ($ResBus[ativo] == 1) { $InfoAtivo = Sim; }
	   echo "<tr><td align='left' valign='middle' class='txt'>$ResBus[nome]</td>
	   <td align='left' valign='middle' class='txt'>$ResBus[email]</td>
	   <td align='center' valign='middle' class='txt'>$InfoAtivo</td>
	   <td align='center' valign='middle' class='txt'>$ResBus[data] �s $ResBus[hora]</td></tr>";
	   }
	   echo "<tr><td width='100%' height='40' colspan='4' align='center' valign='middle' class='txt'>
<input type=\"button\" value=\" Realizar Nova Busca \" onClick=\"location='$PHP_SELF?Acao=Buscar'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\"></td></tr>
</table></center>";
       }
	}
?>

