<?
require ("sessao.php");
require ("config.php");
$LocalArq = '/admin.php';
$LocalCorreto = $UrlDaLista . $LocalArq;
if ($SCRIPT_URI != $LocalCorreto) {
	if (!headers_sent()) {
	header("Location:admin.php?Acao=Historico");
	exit;
	}
}
echo "<br><center><div class='txt'><b>Hist�rico de todas as Vers�es da Lista de Emails</b></div></center><br>
<p align='justify' style='margin-left:15;margin-right:15' class='txt'>

<br><b>Em 15 de julho de 2003</b> - Vers�o 3.0<br>
Inclus�o do download do arquivo de backup das tabelas e outras melhorias no instalador.<br>

<br><b>Em 08 de julho de 2003</b> - Vers�o 2.9<br>
Inclus�o do backup das tabelas. Foi criado para garantir maior seguran�a
para os dados da lista. As op��es s�o de fazer o backup ou restaurar
o mesmo. Al�m de uma nova op��o no (config.php) que � o backup autom�tico.
Essa op��o faz o backup de todas as tabelas e seus registros no momento
que o administrador entra na �rea de Administra��o.<br>

<br><b>Em 05 de julho de 2003</b> - Vers�o 2.8<br>
Cria��o do novo instalador unificado, agora ele serve tanto para instalar como para atualizar a Lista.<br>

<br><b>Em 04 de julho de 2003</b> - Vers�o 2.7<br>
Corrigido o sistema de envio de mensagens, e agora � poss�vel enviar anexos junto a mensagem.
Continuam as op��es de envio em Html e Text.<br>

<br><b>Em 01 de julho de 2003</b> - Vers�o 2.6<br>
Inclu�da as op��es de Administra��o Geral, onde agora � poss�vel cadastrar mais de um Admin, sendo criado um sistema
de hierarquia, onde apenas os Admins com Level Master tem total controle sobre as fun��es da Lista. Sendo um Admin Master
voc� poder� incluir novos admins, excluir, editar seu Level.<br>

<br><b>Em 25 de junho de 2003</b> - Vers�o 2.5<br>
Inclus�o da fun��o de Manuten��o das Tabelas, colocadas na p�gina de 'Alterar Senha', tamb�m inclui a
op��o de imprimir resultados nas p�ginas de Consulta e Log, para isso foi inclu�do mais um script (imprimir.php).
Corre��o do arquivo modelos.php que estava com c�digos excessivos para html.<br>

<br><b>Em 22 de junho de 2003</b> - Vers�o 2.4<br>
Corre��o do arquivo mensagem.php que n�o estava enviando as mensagens por erro na rotina de
verifica��o de campos vazios.<br>

<br><b>Em 21 de junho de 2003</b> - Vers�o 2.3<br>
Reformuladas as fun��es da lista para melhorar o desempenho, e todas foram inclu�das em um
arquivo separado (funcoes.php). Criado o sistema de seguran�a para o envio de mensagens para
que caso haja perda de conex�o, o script para de enviar as mensagens avisando o administrador e
informando para quem foi enviada a �ltima mensagem. Em breve haver� a op��o de escolher os
usu�rios que receber�o as mensagens, para complementar a fun��o acima.<br>

<br><b>Em 18 de junho de 2003</b> - Vers�o 2.2<br>
Melhorias no arquivo editar.php, adicionando uma orienta��o para a p�gina correta do seu
funcionamento. Fiz isso para que o arquivo n�o seja chamado fora da administra��o. Estava
acontecendo alguns erros com o antigo arquivo. Tamb�m houve melhorias nos arquivos que informam
sobre atualiza��es do script, mas esses funcionam dentro do meu site.<br>

<br><b>Em 17 de junho de 2003</b> - Vers�o 2.1<br>
Corre��o nos arquivos da administra��o que informavam erro ao serem carregados pelo menu,
indicando que o header j� havia sido informado. Tamb�m foi modificada a op��o Editar na Administra��o.
Podendo agora ser mudado o nome do usu�rio e mantido o email. Continua n�o sendo poss�vel
ter emails duplicados na lista. Isso � proposital, pois n�o me parece l�gico mandar a mesma
mensagem para o mesmo email.<br>

<br><b>Em 15 de junho de 2003</b> - Vers�o 2.0<br>
Esta vers�o deu muito trabalho, pois inclui uma fun��o para confirmar a inscri��o do novo
usu�rio. Assim, quando ele se cadastra, recebe um email com um link que ir� ativar seu cadastro.
Sendo que esta fun��o � opcional. Tamb�m continuei o desmembramento dos arquivos, visando
agilizar o funcionamento do script de um modo geral. As mensagens agora s�o totalmente customiz�veis
para que voc� deixe elas como deseja. � importante lembrar que esta vers�o exige a utiliza��o
do arquivo upgrade.php pois foi necess�rio incluir um novo campo na tabela do banco de dados.
O script de upgrade atualiza a tabela e ainda faz um update nas informa��es de todos os emails
j� cadastrados. Assim, os administradores da Lista n�o ter�o que refazer os cadastros, pois
todos j� estar�o atualizados para a op��o 'Ativo'.<br>

<br><b>Em 12 de junho de 2003</b> - Vers�o 1.9<br>
Otimizado o sistema para melhorar a performance da administra��o. O arquivo admin.php foi
desmenbrado em v�rias partes para tornar seu funcionamento mais r�pido. Tamb�m foram
desmembradas as mensagens do script, ficando todas elas em um arquivo a parte (modelos.php),
podendo agora o usu�rio do sistema modificar todas as mensagens que s�o enviadas para os
cadastrados com tamb�m aquelas que o sistema envia para o administrador.<br>

<br><b>Em 10 de junho de 2003</b> - Vers�o 1.8<br>
Modifica��o na mensagem enviada ao usu�rio no momento do cadastramento. Agora ele recebe a
confirma��o do seu cadastro e tamb�m tem a op��o de remover o mesmo. Fiz isso para evitar
que outras pessoas incluam emails de outros sem autoriza��o. E assim, os administradores
da lista n�o ser�o acusados de fazer Spam.<br>Tamb�m foi modificado o arquivo leiame.txt,
por sugest�o do Luciano, que antes n�o indicava a vers�o da lista
e tamb�m n�o informava sobre o procedimento no caso de upgrade.<br>

<br><b>Em 09 de junho de 2003</b> - Vers�o 1.7<br>
Corre��o no envio de mensagens em html, com a substitui��o de aspas duplas por simples,
com replace<br>
<br><b>Em 08 de junho de 2003</b> - Vers�o 1.6<br>
Inclus�o da op��o de envio de mensagens em Html<br>
Agradecimento ao Sergio Manoel Jr por sua sugest�o em incluir a op��o de emails em Html<br>
<br><b>Em 07 de junho de 2003</b> - Vers�o 1.5<br>
Corre��o do array que configura as tabelas<br>
<br><b>Em 04 de junho de 2003</b> - Vers�o 1.4<br>
Corre��o da verifica��o online de novas vers�es<br>
<br><b>Em 01 de junho de 2003</b> - Vers�o 1.3<br>
Inclus�o do hist�rico de altera��es<br>
<br><b>Em 31 de maio de 2003</b> - Vers�o 1.2<br>
Corre��o dos bot�es para voltar e corrigir<br>
<br><b>Em 31 de maio de 2003</b> - Vers�o 1.1<br>
Tantas pequenas corre��es que passei para a vers�o 1.2<br>
<br><b>Em 25 de maio de 2003</b> - Vers�o 1.0 - Lan�amento<br>
<br><b>Em 15 de maio de 2003</b> - In�cio do Projeto - Vers�o 1.0<br><br>";
echo "<center><a href=\"#\" onclick=\"window.open('imprimir.php?TableImp=Historico','Imprimindo','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,top=800,left=0');return false\" onMouseOver=\"self.status='Imprimir esta p�gina';return true\"><img src=\"arquivos/print.gif\" width=\"20\" height=\"18\" border=\"0\" alt=\"Imprimir esta P�gina\"> Imprimir esta P�gina</a></center><br>";
?>

