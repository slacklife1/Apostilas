<?
require ("sessao.php");
require ("config.php");
$LocalArq = '/admin.php';
$LocalCorreto = $UrlDaLista . $LocalArq;
if ($SCRIPT_URI != $LocalCorreto) {
	if (!headers_sent()) {
	header("Location:admin.php?Acao=Log");
	exit;
	}
}
    abre_conexao_db();
	$busca = "SELECT * FROM $TableLog";
	$registrosPorPagina = 20;
	if (empty($pagina)):    $pc = 1; 	else:    $pc = $pagina; endif;
	if (!isset($pagina)) { $pagina = 1; }
	$inicio = $pc - 1;
	$inicio = $inicio * $registrosPorPagina;
	$limite = mysql_query("$busca WHERE id order by id desc LIMIT $inicio,$registrosPorPagina");
	$totalRegistros = mysql_num_rows(mysql_query("$busca"));
	$TotalRegistrosInf = mysql_num_rows(mysql_query("$busca"));
	$numPaginas = $totalRegistros / $registrosPorPagina;
		if ($totalRegistros == 0) {
		$Conclusao = "<b>N�o existem registros no Banco de Dados";
		imprime_resultado();
		}
		else {
		echo "<table border='0' width=\"100%\">
		<tr><td width=\"5%\" height=\"35\" valign=\"middle\" align=\"right\" class='txt'><b>ID</b></td>
		<td width=\"1%\" height=\"35\"></td>
		<td width=\"24%\" height=\"35\" valign=\"middle\" align=\"center\" class='txt'><b>Data e Hora</b></td>
		<td width=\"70%\" height=\"35\" valign=\"middle\" align=\"center\" class='txt'><b>Resumo das altera��es feitas at� o momento | P�gina $pagina</b></td></tr>";
			while($Linha = mysql_fetch_array($limite)) {
			echo "<tr><td width=\"5%\" valign=\"top\" align=\"right\" class='txt'>$Linha[id]</td>
           	<td width=\"1%\"></td>
			<td width=\"24%\" valign=\"top\" align=\"center\" class='txt'>$Linha[data] �s $Linha[hora]</td>
			<td width=\"70%\" valign=\"top\" align=\"left\" class='txt'>$Linha[info]</td></tr>";
			}

		echo "<tr><td colspan='4' align='center' valign='middle' class='txt'><br>";

	$anterior = $pc - 1;
	$proximo =  $pc + 1;
	if ($pc>1): echo " <a href='$PHP_SELF?Acao=Log&pagina=$anterior' onmouseover=\"self.status='$TituloSite - Ir para P�gina Anterior';return true\"><img src='arquivos/setaesq.gif' width='18' height='8' border='0'><img src='arquivos/setaesq.gif' width='18' height='8' border='0'> Anterior | </a> "; else: echo "<img src='arquivos/setaesq.gif' width='18' height='8' border='0'><img src='arquivos/setaesq.gif' width='18' height='8' border='0'><b> Anterior | </b>"; endif;
	if ($pc<$numPaginas):	echo " <a href='$PHP_SELF?Acao=Log&pagina=$proximo' onmouseover=\"self.status='$TituloSite - Ir para Pr�xima P�gina';return true\"> | Pr�xima <img src='arquivos/setadir.gif' width='18' height='8' border='0'><img src='arquivos/setadir.gif' width='18' height='8' border='0'></a>"; else: echo "<b> | Pr�xima </b><img src='arquivos/setadir.gif' width='18' height='8' border='0'><img src='arquivos/setadir.gif' width='18' height='8' border='0'>";		endif;

	echo "<br><br>";

	if (($totalRegistros%$registrosPorPagina!=0)):
		while($totalRegistros%$registrosPorPagina!=0){$totalRegistros++;}
	endif;
	echo "<b>Link Direto para as P�ginas</b><br>";
	for ($a=1;$a<=$totalRegistros;$a++) {
	if ($a%$registrosPorPagina==0):
		$link = $a;
		$link /= $registrosPorPagina;	
		if ($link!=$pagina):
			echo " <a href='$PHP_SELF?Acao=Log&pagina=$link' onmouseover=\"self.status='$TituloSite - Ir para P�gina $link';return true\">$link</a>&nbsp;";
		else:
			echo "<font color=0099CC> ::<strong>$link</strong>::&nbsp;</font>";
		endif;
		$aux++;
	endif;
}

	echo "<br><br>| <b>Exibindo p�g: $pagina</b> | <b>Total de $link p�ginas</b> | <b>Total de $TotalRegistrosInf registros</b> |
<a href=\"#\" onclick=\"window.open('imprimir.php?TableImp=$TableLog&pagina=$pagina','Imprimindo','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,top=800,left=0');return false\" onMouseOver=\"self.status='Imprimir esta p�gina de resultados';return true\"><img src=\"arquivos/print.gif\" width=\"20\" height=\"18\" border=\"0\" alt=\"Imprimir esta P�gina\"> Imprimir esta P�gina</a> |
</td></tr></table>";

}

	fecha_conexao_db();

?>
