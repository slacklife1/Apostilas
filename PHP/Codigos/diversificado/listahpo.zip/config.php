<?php
/*
	Lista de Emails HPonline - Vers�o 3.0
	Criada em 15 de maio de 2003
	Por Alexandre Pina - alexandre@hpobr.com
	Home Page Online - www.hpobr.com
	
	Sugiro n�o modificar o nome das vari�veis, esse script
	foi testado diversas vezes, sem apresentar problemas.
	Em caso de d�vidas veja o arquivo leiame.txt
*/

//	Configura��es do Banco de Dados e layout da p�gina
//  Fa�a isso com aten��o e cuidado

$db = Array();
$db[host] = "xxxxx";		// Host do Banco de Dados
$db[user] = "xxxxx";		// Login para o Banco de Dados
$db[senha] = "xxxxx";    	// Senha para o Banco de Dados
$db[nome] = "xxxxx";		// Nome do Banco de Dados

$TableNome = "listahpo";	// Nome que vc deseja para a tabela que ser� criada

$DataHpo = date("d/m/Y");	// Data formatada - N�o altere esta vari�vel
$HoraHpo = date("H:i:s");	// Hora formatada - N�o altere esta vari�vel

// Url completa do diret�rio da Lista
$UrlDaLista = 'http://www.seusite.com/listahpo';

// Path completo do diret�rio da Lista
$PathDaLista = '/home/seusite/www/listahpo';

// Obs: Em caso de d�vida, no momento da instala��o, o sistema vai gerar
// as duas informa��es acima baseado no Servidor

$TituloSite = 'xxxxx xxxxx';		// T�tulo do site
$NomeDaLista = 'xxxxx xxxxx';		// Nome da lista
$EmailSite = 'xxxxx@xxxxx.com';		// Email do site
$UrlSite = 'www.xxxxx.com';			// Url do site (pode ser sem o http://)
$Webmaster = 'xxxxx xxxxx';			// Nome do Webmaster

// Texto do cabe�alho da lista
$CabLista = "Lista de Emails $NomeDaLista<br>Inscreva-se para receber not�cias";

// Op��o de reenvio da Senha para o Administrador (vai para o email dele)
// S� envia se o email estiver cadastrado
$RecuperaSenha = '1'; // (0 = n�o || 1 = sim)

// Mensagem de agradecimento ao usu�rio ( 0 = N�o || 1 = Sim)
$MsgAgradece = '1';

// Confirma��o de inscri��o - Usada para que o usu�rio s� seja inclu�do no cadastro ap�s
// confirmar atrav�s de um link enviado por email ( 0 = N�o || 1 = Sim)
$ConfirmaCadastro = '1';

// Backup Autom�tico das Tabelas ( 0 = N�o || 1 = Sim)
// O Sistema realiza o backup no momento em que o Admin entra na Administra��o
$BackupAuto = 1;

// N�mero de linhas por p�gina para exibir na consulta por usu�rios e de Log (Admin)
$lpp = 20;

// Configura��o da tabela que cont�m o formul�rio de inscri��o da lista
// Ficou um pouco grande essa parte, mas s� assim poder� acompanhar o layout do seu site
$TableConfig = Array();
$TableConfig[1] = '300';		// Largura da tabela
$TableConfig[2] = '1';			// Largura da borda da tabela
$TableConfig[3] = 'FFFFFF';		// Cor de fundo da tabela
$TableConfig[4] = '000080';    	// Cor da borda da tabela
$TableConfig[5] = '000080';    	// Cor da borda inferior
$TableConfig[6] = '000080';    	// Cor da borda superior
$TableConfig[7] = '3';         	// Espa�amento das c�lulas
$TableConfig[8] = '25';        	// Largura dos campos do formul�rio
// Estilo dos textos
$TableConfig[9] = 'font-family:verdana;font-size:8pt;color:000080;background-color:FFFFFF';
// Estilo dos Campos do formul�rio (input text)
$TableConfig[10] = 'height:15;font-family:verdana;font-size:8pt;color:000080;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080';
// Estilo dos bot�es (submit e outros)
$TableConfig[11] = 'height:18;cursor:hand;font-family:verdana;font-size:8pt;color:000080;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080';

// N�o altere essa vari�vel - Ela vai informar sobre novas vers�es
$VersaoLista = '3.0';

?>
