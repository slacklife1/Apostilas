<?
require ("sessao.php");
require ("config.php");
$LocalArq = '/admin.php';
$LocalCorreto = $UrlDaLista . $LocalArq;
if ($SCRIPT_URI != $LocalCorreto) {
	if (!headers_sent()) {
	header("Location:admin.php?Acao=Incluir");
	exit;
	}
}
	if (!$submit) {
	echo "<br><table border=\"0\" width=\"100%\">
<form method=\"POST\" action=\"admin.php?Acao=Incluir\" name='Admin'>
<tr><td width=\"100%\" colspan='2' valign=\"middle\" align=\"center\" class=\"txt\">
Digite abaixo o <b>Nome e o Email</b> que deseja <b>Incluir</b></td></tr>
<tr><td width=\"30%\" valign=\"middle\" align=\"right\" class=\"txt\">
<b>Nome:</b></td>
<td width=\"70%\" valign=\"middle\" align=\"left\">
<input type=\"text\" size=\"55\" name=\"NovoNome\" style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
</td></tr>
<tr><td width=\"30%\" valign=\"middle\" align=\"right\" class=\"txt\">
<b>Email:</b></td>
<td width=\"70%\" valign=\"middle\" align=\"left\">
<input type=\"text\" size=\"55\" name=\"NovoEmail\" style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
</td></tr>
<tr><td colspan=\"2\" valign=\"middle\" align=\"center\">
<input type=\"submit\" name=\"submit\" value=\" Incluir Usu�rio \" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">
<script>document.Admin.NovoNome.focus();</script>
</form></td></tr></table>";
	}
	elseif ($submit) {
	$n_erros = 0;
	$erro = "  ";
	if(empty($NovoNome)) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - Voc� esqueceu de digitar um <b>Nome</b><br>";
	$n_erros++;
	}
	if(empty($NovoEmail)) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - Voc� esqueceu de digitar um <b>Email</b><br>";
	$n_erros++;
	}
	elseif (verifica_mail($NovoEmail)) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - Confira o email, pois este dom�nio <b>N�o Existe</b><br>";
	$n_erros++;
	}
	if ($n_erros != 0) { $Conclusao = "$erro<br>
<input type=\"button\" value=\" Voltar e Corrigir \" onClick=\"location='$PHP_SELF?Acao=Incluir'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
imprime_resultado(); }
	}
    if ($submit and $n_erros == "0") {
    abre_conexao_db();
    $ConsultaIncluir = mysql_query("select email from $TableNome WHERE (email='" . $NovoEmail . "')");
	$ChecaIncluir = mysql_fetch_assoc($ConsultaIncluir);
       	if ($ChecaIncluir) { $Conclusao = "O cadastro <b>n�o foi efetuado</b> porque<br>o email: $NovoEmail <b>j� consta</b> no Banco de Dados<br><br>
<input type=\"button\" value=\" Voltar e Corrigir \" onClick=\"location='$PHP_SELF?Acao=Incluir'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
		imprime_resultado();
		}
		else {
		$InfoAtivo = 1;
		$inserir = mysql_query("INSERT INTO $TableNome (nome, email, data, hora, ativo) VALUES('$NovoNome','$NovoEmail','$DataHpo','$HoraHpo','$InfoAtivo')");
        $NovaInfo = "<b>Inclus�o de novo usu�rio ($AdminLogado)</b><br>Nome: $NovoNome || Email: $NovoEmail";
		InfoLog();
        fecha_conexao_db();
        	if ($inserir) { $Conclusao = "O novo cadastro foi inclu�do com <b>Sucesso</b><br><br>Nome: <b>$NovoNome</b> - Email: <b>$NovoEmail</b><br><br>
<input type=\"button\" value=\" Incluir outro Usu�rio \" onClick=\"location='$PHP_SELF?Acao=Incluir'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
			imprime_resultado();
			}
		}
	}
?>

