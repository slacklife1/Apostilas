<?
require ("sessao.php");
require ("config.php");
$LocalArq = '/admin.php';
$LocalCorreto = $UrlDaLista . $LocalArq;
if ($SCRIPT_URI != $LocalCorreto) {
	if (!headers_sent()) {
	header("Location:admin.php?Acao=Ajuda");
	exit;
	}
}
echo "<br><center><div class='txt'><b>Arquivo de Ajuda da Lista de Emails Home Page Online</b></div></center><br>
<p align='justify' style='margin-left:15;margin-right:15' class='txt'>
Neste arquivo de ajuda voc� vai encontrar orienta��es para todas as fun��es da Lista.
Procurei dar o m�ximo de op��es para o Administrador, para que desse modo, ele fosse
capaz de executar qualquer opera��o dentro da Administra��o.<br>
<br>Veja abaixo as principais caracter�sticas da administra��o da Lista:<br>
<br>
<b>Na parte superior do cabe�alho, voc� encontra:</b><br>
<br>
<b>| LogOut |</b><br>
Ao clicar em LogOut voc� encerra a sess�o existente, saindo da p�gina de administra��o.
Nesse caso, para retornar � necess�rio fazer novo Login, informando Nome e Senha.<br>

<br><b>| Admin Geral |</b><br>
Nesta �rea voc� encontra diversas ferramentas para a administra��o da lista. Como alterar a
sua senha, incluir, editar ou excluir Admins (Exclusivo para o Admin Master), e a parte de
manutan��o das tabelas do Banco de Dados. Em mais detalhes:<br><br>
<b>1) Manuten��o das Tabelas</b><br>
<b>Backup das Tabelas</b> - Para realizar o backup das tabelas da lista, � diferente do Backup
Autom�tico, pois cria um arquivo (.txt) que ser� manipulado depois pela fun��o de restaurar
as tabelas. Voc� encontra a informa��o do �ltimo backup via Administra��o no final.<br>
<b>Restaurar Backup</b> - Fun��o para restaurar um backup criado pela fun��o de 'Backup das Tabelas',
voc� deve ter muito cuidado com essas fun��es, pois se n�o prestar aten��o na data do �ltimo backup
poder� restaurar um backup antigo, e assim, desatualizar suas informa��es.<br>
<b>Checar as Tabelas</b> - Verifica se as tabelas est�o sem erros.<br>
<b>Otimizar as Tabelas</b> - Fun��o destinada apenas para um Banco de Dados muito grande.<br>
<b>Analizar as Tabelas</b> - Verifica as tabelas e se ok, indica que est�o prontas para grava��o.<br>
<b>Reparar as Tabelas</b> - Caso encontre erros nas tabelas, acione esta fun��o antes de mais nada,
provavelmente ir� resolver.<br>
<b>2) Alterar Info Admin</b><br>
Para poder alterar as suas informa��es, o script informa e permite alterar as informa��es do
Admin que estiver logado no momento.<br>
<b>3) Incluir/Excluir Admin</b><br>
Fun��o Exclusiva para o Admin Master, apenas este poder� consultar, incluir, excluir ou editar os privil�gios
dos demais Admins. Nesta �rea tamb�m � poss�vel realizar o Download do arquivo de Backup das tabelas. � muito importante que apenas o Admin Master tenha acesso ao Banco de Dados.<br>
<br><b>| Consultar log |</b><br>
Nesta op��o voc� poder� consultar todas as altera��es j� efetuadas, incluindo o envio
de mensagens, a altera��o de Senha, quando um usu�rio se cadastra na lista, aguardando ou
n�o pela confirma��o quando configurado assim, quando um usu�rio se retira da lista, e
tamb�m quando voc� entra na Administra��o, edita, inclui ou exclui usu�rios. Registra todas as a��es
feitas na Administra��o Geral, assim como, tentativas de entrada na �rea reservada ao Admin Master.
Tamb�m � poss�vel imprimir os resultados da p�gina. Os resultados s�o exibidos por pagina��o.<br>
<br><b>Nas op��es do menu:</b><br>
<br>
<b>| Home |</b><br>
� apenas a p�gina de entrada na Lista, mas quando vc entra na Administra��o, � gravado
em um arquivo a data e hora do acesso, assim como, tamb�m � informado seu �ltimo acesso
na Administra��o, muito �til em termos de seguran�a. O n�mero de usu�rios cadastrados,
ativos ou n�o e tamb�m lhe � informado online se existe uma nova vers�o desta Lista de Emails.<br>
<br>
<b>| Consultar |</b><br>
Para consultar todos os usu�rios cadastrados na lista, exibe a informa��o em ordem decrescente
por usu�rio inscrito, com nome, data e se ele est� com o cadastro ativo. No caso de n�o haver
registros, o programa critica o erro. Na p�gina de Consulta � poss�vel imprimir os resultados
da p�gina.<br>
<br><b>| Buscar |</b><br>
Para poder buscar por um nome ou email, retornando a informa��o com o n�mero de resultados
encontrados, exibindo nome e email, ou informando que n�o existe o usu�rio com a informa��o
digitada. Deixei a Busca sem ser espec�fica, para que quando procurar por uma palavra, o
resultado retorne tudo que for semelhante aquela palavra.<br>
<br><b>| Editar |</b><br>
Permite editar um usu�rio, modificando seu nome, email ou a situa��o do seu cadastro (Ativado ou Desativado).
Conta com uma busca r�pida para auxiliar na procura pelo usu�rio desejado. A edi��o <b>n�o
permite</b> a inclus�o de um email repetido. Assim como, se n�o houver usu�rios para se editar
ou forem deixados campos em branco, o programa critica o erro.<br>
<br><b>| Incluir |</b><br>
Para a inclus�o de usu�rios, sendo que n�o permite a inclus�o caso o email j� exista, e
tamb�m critica em caso de campos em branco. Lembrando que a inclus�o via Administra��o j�
inclui o usu�rio como ativo.<br>
<br><b>| Excluir |</b><br>
Permite excluir um usu�rio. Conta com uma busca r�pida para auxiliar na procura pelo
usu�rio desejado. Se n�o houver usu�rios para excluir o programa critica o erro.<br>
<br><b>| Enviar Mensagem |</b><br>
Fun��o para o envio de mensagens para todos os usu�rios da lista que est�o com seu cadastro
ativado, j� conta com um cabe�alho personalizado, com base nas informa��es do site, e tamb�m
um rodap�. Ao final da mensagem, h� um link para remo��o autom�tica do usu�rio da lista. Permite
o envio de mensagens sem assunto e sem texto, mas lhe informa isso como erro. As mensagens
podem ser enviadas em somente Texto, como tamb�m em Html. Al�m disso, voc� poder� anexar arquivos
nas mensagens.<br>
<br><b>| Ajuda |</b><br>
O arquivo que voc� est� lendo neste momento.<br>
<br><b>| Hist�rico |</b><br>
Nesta op��o voc� poder� acompanhar todas as mudan�as na Lista de Emails HPonline desde a sua
cria��o na <b>vers�o 1.0</b> lan�ada em 25 de maio de 2003<br><br>";
echo "<center><a href=\"#\" onclick=\"window.open('imprimir.php?TableImp=Ajuda','Imprimindo','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,top=800,left=0');return false\" onMouseOver=\"self.status='Imprimir esta p�gina';return true\"><img src=\"arquivos/print.gif\" width=\"20\" height=\"18\" border=\"0\" alt=\"Imprimir esta P�gina\"> Imprimir esta P�gina</a></center><br>";
?>

