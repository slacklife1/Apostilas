<?
require ("sessao.php");
require ("config.php");
$LocalArq = '/admin.php';
$LocalCorreto = $UrlDaLista . $LocalArq;
if ($SCRIPT_URI != $LocalCorreto) {
	if (!headers_sent()) {
	header("Location:admin.php?Acao=Senha");
	exit;
	}
}
echo "<table border=\"0\" width=\"100%\">
<tr>
<td width=\"33%\" valign=\"middle\" align=\"center\" class=\"txt\">
<input type='button' value=' Manuten��o das Tabelas ' onClick=\"location='admin.php?Acao=Senha&ManutTab=1'\" style=\"width:200;height:18;cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">
</td>
<td width=\"34%\" valign=\"middle\" align=\"center\" class=\"txt\">
<input type='button' value=' Alterar Info Admin ' onClick=\"location='admin.php?Acao=Senha&InfoAdmin=1'\" style=\"width:200;height:18;cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">
</td>
<td width=\"33%\" valign=\"middle\" align=\"center\" class=\"txt\">
<input type='button' value=' Incluir/Excluir Admin ' onClick=\"location='admin.php?Acao=Senha&MasterAdmin=1'\" style=\"width:200;height:18;cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">
</td>
</tr></table>";

if (!$ManutTab and !$InfoAdmin and !$MasterAdmin) {
echo "<table border=\"0\" width=\"100%\">
<tr>
<td width=\"100%\" height='30' valign=\"middle\" align=\"center\" class=\"txt\">
<b>Op��es da Administra��o Geral</b></td></tr>
<tr><td width=\"100%\" valign=\"middle\" align=\"center\" class=\"txt\">
<p align='justify' style='margin-left:5;margin-right:5;margin-top:5'>
<b>Manuten��o das Tabelas - </b>Esta op��o � destinada a manuten��o das
tabelas de cadastros e log. Voc� poder� checar as tabelas para saber se a conex�o com o banco de
dados est� ativa. Poder� tamb�m verficar se as tabelas est�o prontas para grava��o. Em caso de
encontrar erros durante os processos, utilize a op��o de reparar as tabelas, como tamb�m a op��o
de otimizar, sendo esta para quando a lista � utilizada com grande n�mero de cadastros. E por fim, realizar Backup das Tabelas.<br>
<br><b>Alterar Info Admin - </b> Esta op��o � para que vc possa modificar seus dados, como nome, login, email
e senha.<br>
<br><b>Incluir/Excluir Admin - </b>Fun��o exclusiva do Administrador Master, nesta op��o ele poder� consultar os
administradores cadastrados, podendo editar seus dados, assim como incluir novos administradores.</td>
</tr></table>";
}

if ($ManutTab == 1) {
$ArqDatBac = "backup/ArqDatas.txt";
$ResDatBac = fopen($ArqDatBac, "r+");
$ContDatBack = fread($ResDatBac,100);
$InfoDat = explode("|",$ContDatBack);
for ($i=0;$i < count($InfoDat);$i++) { $DataUBac = $InfoDat[0]; $DataURec = $InfoDat[1]; }
?>

<table border='0' width='100%'>
<tr><td width='100%' colspan='3' height='30' align='center' valign='middle' class='txt'>
<b>< < < Manuten��o das Tabelas > > ><b></td></tr>
<tr><td width='33%' align='center' valign='top' class='txt'>
<input type='button' value=' Backup das Tabelas ' onClick="location='admin.php?Acao=Senha&ManutTab=1&Backup=1'" style="width:200;height:18;cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080">
<p align='justify' style='margin-left:5;margin-right:5;margin-top:5'>
Utilize esta fun��o para realizar o backup das Tabelas da Lista de Emails. <b>�ltimo Backup</b> em: <? echo $DataUBac; ?>
<?
if ($Backup == 1) {
abre_conexao_db();
$back = fopen("backup/BacTabWeb.txt","w");
$res = mysql_query("SHOW CREATE TABLE $TableNome");
while ( $lin = mysql_fetch_row($res)){
fwrite($back,"DROP TABLE IF EXISTS $TableNome;\n");
fwrite($back,"$lin[1];\n");
$res1 = mysql_query("SELECT * FROM $TableNome");
while($r=mysql_fetch_row($res1)){
$sql="INSERT INTO $TableNome VALUES ('";
$sql .= implode("','",$r);
$sql .= "');\n";
fwrite($back,$sql);
}
}

$res = mysql_query("SHOW CREATE TABLE $TableAdm");
while ( $lin = mysql_fetch_row($res)){
fwrite($back,"DROP TABLE IF EXISTS $TableAdm;\n");
fwrite($back,"$lin[1];\n");
$res1 = mysql_query("SELECT * FROM $TableAdm");
while($r=mysql_fetch_row($res1)){
$sql="INSERT INTO $TableAdm VALUES ('";
$sql .= implode("','",$r);
$sql .= "');\n";
fwrite($back,$sql);
}
}

$res = mysql_query("SHOW CREATE TABLE $TableLog");
while ( $lin = mysql_fetch_row($res)){
fwrite($back,"DROP TABLE IF EXISTS $TableLog;\n");
fwrite($back,"$lin[1];\n");
$res1 = mysql_query("SELECT * FROM $TableLog");
while($r=mysql_fetch_row($res1)){
$sql="INSERT INTO $TableLog VALUES ('";
$sql .= implode("','",$r);
$sql .= "');\n";
fwrite($back,$sql);
}
}

$RespTab1 = "Backup da Tabela de Cadastros <b>realizado com Sucesso</b><br>
Backup da Tabela de Admin <b>realizado com Sucesso</b><br>
Backup da Tabela de Log <b>realizado com Sucesso</b>";
fclose($back);

	$ArqDatBac = "backup/ArqDatas.txt";
	$ResDatBac = fopen($ArqDatBac, "w");
	$NovaDataBac = "$DataHpo �s $HoraHpo";
    $AtualizaData = $NovaDataBac . "|" . $DataURec;
	fwrite($ResDatBac, $AtualizaData);
	fclose($ResDatBac);

	$NovaInfo = "<b>Backup das Tabelas ($AdminLogado)</b>";
	InfoLog();
	fecha_conexao_db();
}
?>
</td>
<td width='34%' align='center' valign='top' class='txt'>
<input type='button' value=' Checar as Tabelas ' onClick="location='admin.php?Acao=Senha&ManutTab=1&ChecarTab=1'" style="width:200;height:18;cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080">
<p align='justify' style='margin-left:5;margin-right:5;margin-top:5'>
Checagem das Tabelas da Lista de Emails, indicando sua integridade
<?
if ($ChecarTab == 1 ) {
	abre_conexao_db();
	$sql_check_cad = mysql_query("CHECK TABLE $TableNome EXTENDED");
	$ChecarCad = mysql_fetch_array($sql_check_cad);
	$sql_check_log = mysql_query("CHECK TABLE $TableLog EXTENDED");
	$ChecarLog = mysql_fetch_array($sql_check_log);
		if ($ChecarCad[Msg_type] == status) {
		$RespTab1 = "Checagem da Tabela de Cadastros: <b>OK</b>"; }
		else { $RespTab1 = "<font color=FF0000> Verifique o Banco de Dados e Tabelas - Poss�vel Erro</font>"; }
		if ($ChecarLog[Msg_type] == status) {
		$RespTab2 = "Checagem da Tabela de Log: <b>OK</b>"; }
		else { $RespTab2 = "<font color=FF0000> Verifique o Banco de Dados e Tabelas - Poss�vel Erro</font>"; }
	$NovaInfo = "<b>Checagem das Tabelas ($AdminLogado)</b>";
	InfoLog();
	fecha_conexao_db();
}
?>
</td>
<td width='33%' align='center' valign='top' class='txt'>
<input type='button' value=' Analizar as Tabelas ' onClick="location='admin.php?Acao=Senha&ManutTab=1&AnalizarTab=1'" style="width:200;height:18;cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080">
<p align='justify' style='margin-left:5;margin-right:5;margin-top:5'>
An�lise das Tabelas, se positiva indica que o Banco de Dados est� pronto para gravar
<?
if ($AnalizarTab == 1 ) {
	abre_conexao_db();
	$sql_check_cad = mysql_query("ANALYZE TABLE $TableNome");
	$ChecarCad = mysql_fetch_array($sql_check_cad);
	$sql_check_log = mysql_query("ANALYZE TABLE $TableLog");
	$ChecarLog = mysql_fetch_array($sql_check_log);
		if ($ChecarCad[Msg_type] == status) {
		$RespTab1 = "An�lise da Tabela de Cadastros: <b>OK</b>"; }
		else { $RespTab1 = "<font color=FF0000>Verifique o Banco de Dados e Tabelas - Poss�vel Erro</font>"; }
		if ($ChecarLog[Msg_type] == status) {
		$RespTab2 = " An�lise da Tabela de Log: <b>OK</b>"; }
		else { $RespTab2 = "<font color=FF0000>Verifique o Banco de Dados e Tabelas - Poss�vel Erro</font>"; }
	$NovaInfo = "<b>An�lise das Tabelas ($AdminLogado)</b>";
	InfoLog();
	fecha_conexao_db();
}
?>
</td></tr>
<tr><td width='33%' align='center' valign='top' class='txt'>
<input type='button' value=' Restaurar Backup ' onClick="location='admin.php?Acao=Senha&ManutTab=1&RestaurarBack=1'" style="width:200;height:18;cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080">
<p align='justify' style='margin-left:5;margin-right:5;margin-top:5'>
Fun��o para restaurar as Tabelas da Lista. <font color='FF0000'><b>Aten��o</b></font> nesta opera��o. <b>�ltima recupera��o</b> de Backup em: <? echo $DataURec; ?>
<?
if ($RestaurarBack == 1 ) {
$ArqBac = "backup/BacTabWeb.txt";
if(!file_exists($ArqBac)) { $RespTabFa = "O Arquivo de Backup n�o foi Encontrado<br>"; }
else {
abre_conexao_db();
$TamArq = filesize($ArqBac);
$ResBac = fopen($ArqBac, "r");
$ConteudoBack = fread($ResBac,$TamArq);
$query=explode(";\n",$ConteudoBack);
for ($i=0;$i < count($query)-1;$i++) {
$RestBackup = mysql_query($query[$i]) or die(mysql_error());
}
fecha_conexao_db();
}
if ($RestBackup) { $RespTab1 = "Restaura��o de Backup das tabelas realizado com Sucesso";
	abre_conexao_db();
	$NovaInfo = "<b>Restaura��o de Backup das Tabelas ($AdminLogado)</b>";
	InfoLog();
	fecha_conexao_db();
   	$ArqDatBac = "backup/ArqDatas.txt";
	$ResDatBac = fopen($ArqDatBac, "w");
	$NovaDataBac = "$DataHpo �s $HoraHpo";
    $AtualizaData = $DataUBac . "|" . $NovaDataBac;
	fwrite($ResDatBac, $AtualizaData);
	fclose($ResDatBac);

}
else { $RespTab1 = "<font color=FF0000><b>$RespTabFa N�o foi poss�vel realizar a Restaura��o</font></b>"; }
}
?>
</td>
<td width='34%' align='center' valign='top' class='txt'>
<input type='button' value=' Otimizar as Tabelas ' onClick="location='admin.php?Acao=Senha&ManutTab=1&OtimizarTab=1'" style="width:200;height:18;cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080">
<p align='justify' style='margin-left:5;margin-right:5;margin-top:5'>
Esta op��o � destinada apenas para um Banco de Dados de Cadastros muito grande
<?
if ($OtimizarTab == 1 ) {
	abre_conexao_db();
	$sql_check_cad = mysql_query("OPTIMIZE TABLE $TableNome");
	$ChecarCad = mysql_fetch_array($sql_check_cad);
	$sql_check_log = mysql_query("OPTIMIZE TABLE $TableLog");
	$ChecarLog = mysql_fetch_array($sql_check_log);
		if ($ChecarCad[Msg_type] == status) {
		$RespTab1 = "Otimiza��o da Tabela de Cadastros: <b>OK</b>"; }
		else { $RespTab1 = "<font color=FF0000>Verifique o Banco de Dados e Tabelas - Poss�vel Erro</font>"; }
		if ($ChecarLog[Msg_type] == status) {
		$RespTab2 = "Otimiza��o da Tabela de Log: <b>OK</b>"; }
		else { $RespTab2 = "<font color=FF0000>Verifique o Banco de Dados e Tabelas - Poss�vel Erro</font>"; }
	$NovaInfo = "<b>Otimiza��o das Tabelas ($AdminLogado)</b>";
	InfoLog();
	fecha_conexao_db();
}
?>
</td>
<td width='33%' align='center' valign='top' class='txt'>
<input type='button' value=' Reparar as Tabelas ' onClick="location='admin.php?Acao=Senha&ManutTab=1&RepararTab=1'" style="width:200;height:18;cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080">
<p align='justify' style='margin-left:5;margin-right:5;margin-top:5'>
Utilize esta op��o caso receba alguma mensagem de erro no Banco de Dados
<?
if ($RepararTab == 1 ) {
	abre_conexao_db();
	$sql_check_cad = mysql_query("REPAIR TABLE $TableNome EXTENDED");
	$ChecarCad = mysql_fetch_array($sql_check_cad);
	$sql_check_log = mysql_query("REPAIR TABLE $TableLog EXTENDED");
	$ChecarLog = mysql_fetch_array($sql_check_log);
		if ($ChecarCad[Msg_type] == status) {
		$RespTab1 = "Repara��o da Tabela de Cadastros: <b>OK</b>"; }
		else { $RespTab1 = "<font color=FF0000>Verifique o Banco de Dados e Tabelas - Poss�vel Erro</font>"; }
		if ($ChecarLog[Msg_type] == status) {
		$RespTab2 = " Reparara��o da Tabela de Log: <b>OK</b>"; }
		else { $RespTab2 = "<font color=FF0000>Verifique o Banco de Dados e Tabelas - Poss�vel Erro</font>"; }
	$NovaInfo = "<b>Repara��o das Tabelas ($AdminLogado)</b>";
	InfoLog();
	fecha_conexao_db();
}
?>
</td></tr>
<tr><td width='100%' colspan='3' align='center' valign='middle' class='txt'>
<p align='justify' style='margin-left:20;margin-right:10;margin-top:5'>
<? if ($RespTab1 or $RespTab2) { echo "<font color=008080><b>Resultado da A��o:</b><br></font>" . $RespTab1 . "<br>" . $RespTab2; } ?>
</td></tr></table>

<?
}
// Aqui termina a Tabela de Manuten��o
?>

<?
if ($InfoAdmin == 1 and !$submit) {
echo "<br><table border=\"0\" width=\"100%\">
<form method=\"POST\" action=\"admin.php?Acao=Senha&InfoAdmin=1\" name='Admin'>
<tr><td width=\"40%\" valign=\"top\" align=\"right\" class=\"txt\">
<b>Login do Admin:</b></td>
<td width=\"60%\" valign=\"middle\" align=\"left\" class='txt'>
<input type=\"text\" size=\"20\" name=\"NomeAdmin\" value='$AdminLogado' style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
 (m�ximo de 25 caracteres)</td>
</tr>
<tr>
<td width=\"40%\" valign=\"top\" align=\"right\" class=\"txt\">
<b>Nome Completo:</b></td>
<td width=\"60%\" valign=\"middle\" align=\"left\" class='txt'>
<input type=\"text\" size=\"30\" name=\"NomeCompleto\" value='$NomeCompletoAdmin' style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
 (m�ximo de 40 caracteres)</td>
</tr>
<tr>
<td width=\"40%\" valign=\"top\" align=\"right\" class=\"txt\">
<b>Seu Email:</b></td>
<td width=\"60%\" valign=\"middle\" align=\"left\" class='txt'>
<input type=\"text\" size=\"30\" name=\"EmailAdm\" value='$EmailAdminLog' style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
 (m�ximo de 40 caracteres)</td>
</tr>
<tr>
<td width=\"40%\" valign=\"top\" align=\"right\" class=\"txt\">
<b>Informe a Senha:</b></td>
<td width=\"60%\" valign=\"middle\" align=\"left\" class='txt'>
<input type=\"text\" size=\"15\" name=\"Senha01\" value='$SenhaAdminLog' style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
 (m�ximo de 10 caracteres)</td>
</tr>
<tr><td width=\"40%\" valign=\"middle\" align=\"right\" class=\"txt\">
<b>Confirme a Senha:</b></td>
<td width=\"60%\" valign=\"middle\" align=\"left\">
<input type=\"text\" size=\"15\" name=\"Senha02\" value='$SenhaAdminLog' style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
</td></tr>
<tr><td colspan=\"2\" valign=\"middle\" align=\"center\" class='txt'>
<input type=\"submit\" name=\"submit\" value=\" Alterar Info Admin \" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">
<br>
<script>document.Admin.NomeAdmin.focus();</script>
</form></td></tr></table>
</td></tr></table></center></div>";
}
if ($InfoAdmin == 1 and $submit) {
    $n_erros = 0;
	$erro = "  ";
	if(empty($NomeAdmin)) {
	$erro.= "<b><font color='FF0000'>E R R O</font></b> - Voc� esqueceu de digitar <b>Nome do Admin</b><br>";
	$n_erros++;
	}
	if(empty($NomeCompleto)) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - Voc� esqueceu de digitar <b>Nome Completo</b><br>";
	$n_erros++;
	}
	if(empty($EmailAdm)) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - Voc� esqueceu de digitar <b>Email</b><br>";
	$n_erros++;
	}
	if(empty($Senha01)) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - Voc� esqueceu de digitar <b>Informe a Senha</b><br>";
	$n_erros++;
	}
	if(empty($Senha02)) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - Voc� esqueceu de digitar <b>Confirme a Senha</b><br>";
	$n_erros++;
	}
	elseif($Senha01 != $Senha02) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - As Senhas digitadas est�o <b>Diferentes</b><br>";
	$n_erros++;
	}
	if ($n_erros != 0) { $Conclusao = "$erro<br>
<input type=\"button\" value=\" Voltar e Corrigir \" onClick=\"location='$PHP_SELF?Acao=Senha&InfoAdmin=1'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
imprime_resultado(); }
	}
    if ($submit and $n_erros == "0") {
    abre_conexao_db();
    $Atualiza = mysql_query("UPDATE $TableAdm SET nome = '$NomeAdmin', nomecompleto = '$NomeCompleto', email = '$EmailAdm', senha = '$Senha01' WHERE id='$IdAdminLogado'");
    $NovaInfo = "<b>Altera��o das Informa��es do Administrador ($AdminLogado)</b>";
	InfoLog();
	fecha_conexao_db();
        if ($Atualiza) { $Conclusao = "<br><b>A altera��o das informa��es do Administrador foi realizada com Sucesso</b><br>";
	    imprime_resultado();
	    }
     }

if ($MasterAdmin == 1 and !$ExcluirAdmin and !$UpdateLevel) {
    abre_conexao_db();
	$ChecaInfoLevel = mysql_query("SELECT * FROM $TableAdm WHERE id ='$IdAdminLogado'");
	$ChecaLevel = mysql_fetch_array($ChecaInfoLevel);
	$AdminAutorizado = $ChecaLevel[level];
		if ($AdminAutorizado != Master) { $Conclusao = "<br><font color=FF0000><b>A t e n � � o</font> - Esta �rea � de uso Exclusivo do Admin Master</b><br><br>Voc� n�o tem autoriza��o para executar estas a��es<br><br>Esta tentativa ficar� registrada<br><br>";
    $NovaInfo = "<b><font color=FF0000>Tentativa de Entrada N�o Autorizada</font></b><br>O Admin $AdminLogado tentou entrar na �rea Restrita ao Admin Master";
	InfoLog();
	fecha_conexao_db();
    imprime_resultado(); echo "</td></tr></table>"; footer(); exit;
	}
echo "<table border=\"0\" width=\"100%\">
<tr>
<td width=\"45%\" rowspan='2' valign=\"top\" align=\"center\" class=\"txt\">
<b>Rela��o dos Administradores Cadastrados</b><br><br>";
    abre_conexao_db();
	$ChecaInfoLevel = mysql_query("SELECT * FROM $TableAdm");
	while ($ChecaLevel = mysql_fetch_array($ChecaInfoLevel)) {
		if ($ChecaLevel[level] == Master) { $LinkUpdate = "<a href='admin.php?Acao=Senha&MasterAdmin=1&UpdateLevel=1&IDUpdate=$ChecaLevel[id]' onmouseover=\"self.status='Update Admin $ChecaLevel[nomecompleto] para Admin';return true\"> Update para Admin</a>"; }
		elseif ($ChecaLevel[level] == Admin) { $LinkUpdate = "<a href='admin.php?Acao=Senha&MasterAdmin=1&UpdateLevel=1&IDUpdate=$ChecaLevel[id]' onmouseover=\"self.status='Update Admin $ChecaLevel[nomecompleto] para Master';return true\"> Update para Master</a>"; }
	echo "<p align='justify' style='margin-left:5;margin-right:5;margin-top:5'>
<b>Nome:</b> $ChecaLevel[nomecompleto]<br><b>Email:</b> $ChecaLevel[email]<br><b>Login:</b> $ChecaLevel[nome]<br><b>Senha:</b> $ChecaLevel[senha]<br><b>Level:</b> $ChecaLevel[level]<br>
<a href='admin.php?Acao=Senha&MasterAdmin=1&ExcluirAdmin=1&IDAdmOut=$ChecaLevel[id]' onmouseover=\"self.status='Excluir Admin $ChecaLevel[nomecompleto]';return true\"><font color=FF0000>Excluir</font></a> | $LinkUpdate<br><br>";
    }
echo "</td>
<td width=\"55%\" valign=\"middle\" align=\"center\" class=\"txt\">";
if ($zipit==1) { echo "<script language='JavaScript'>window.open('backup/BackupTabelas.sql','homepage','top=100,left=100,width=400,height=400');</script><b><font color=8080FF>Download realizado com Sucesso</font></b>";
	abre_conexao_db();
	$NovaInfo = "<b><font color=8080FF>Download do Arquivo de Backup por $AdminLogado (Master)</font></b>";
	InfoLog();
	fecha_conexao_db();
}
else {
echo "<input type='button' value=' Download do Arquivo de Backup ' onClick=\"location='admin.php?Acao=Senha&MasterAdmin=1&zipit=1'\" style=\"width:230;height:18;cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:FF0000\">";
}
echo "</td>
</tr>
<tr>
<td width=\"55%\" valign=\"top\" align=\"center\" class=\"txt\">
<b>Inclus�o de Novo Admin</b><br><br>";

if ($MasterAdmin == 1 and $Submit and !$ExcluirAdmin) {
    $n_erros = 0;
	$erro = "  ";
	if(empty($INomeAdmin)) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - Voc� esqueceu de digitar o <b>Login do Admin</b><br>";
	$n_erros++;
	}
	if(empty($INomeCompleto)) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - Voc� esqueceu de digitar o <b>Nome Completo</b><br>";
	$n_erros++;
	}
	if(empty($IEmailAdm)) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - Voc� esqueceu de digitar o <b>Email</b><br>";
	$n_erros++;
	}
	if(empty($ISenha01)) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - Voc� esqueceu de digitar <b>a Senha</b><br>";
	$n_erros++;
	}
}
echo "<table border=\"0\" width=\"100%\">
<form method=\"POST\" action=\"admin.php?Acao=Senha&MasterAdmin=1\" name='Admin'>
<tr><td width=\"40%\" valign=\"top\" align=\"right\" class=\"txt\">
<b>Login do Admin:</b></td>
<td width=\"60%\" valign=\"middle\" align=\"left\" class='txt'>
<input type=\"text\" size=\"20\" name=\"INomeAdmin\" style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
<br>M�ximo de 25 caracteres</td>
</tr>
<tr>
<td width=\"40%\" valign=\"top\" align=\"right\" class=\"txt\">
<b>Nome Completo:</b></td>
<td width=\"60%\" valign=\"middle\" align=\"left\" class='txt'>
<input type=\"text\" size=\"30\" name=\"INomeCompleto\" style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
<br>M�ximo de 40 caracteres</td>
</tr>
<tr>
<td width=\"40%\" valign=\"top\" align=\"right\" class=\"txt\">
<b>Email:</b></td>
<td width=\"60%\" valign=\"middle\" align=\"left\" class='txt'>
<input type=\"text\" size=\"30\" name=\"IEmailAdm\" style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
<br>M�ximo de 40 caracteres</td>
</tr>
<tr>
<td width=\"40%\" valign=\"top\" align=\"right\" class=\"txt\">
<b>Informe a Senha:</b></td>
<td width=\"60%\" valign=\"middle\" align=\"left\" class='txt'>
<input type=\"password\" size=\"15\" name=\"ISenha01\" style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
<br>M�ximo de 10 caracteres</td>
</tr>
<tr><td width=\"40%\" valign=\"middle\" align=\"right\" class=\"txt\">
<b>Level Admin:</b></td>
<td width=\"60%\" valign=\"middle\" align=\"left\">
<select size=\"1\" name=\"ILevelAdm\">
<option>Admin</option>
<option>Master</option>
</select>
</td></tr>
<tr><td colspan=\"2\" valign=\"middle\" align=\"center\" class='txt'>
<input type=\"submit\" name=\"Submit\" value=\" Incluir Novo Admin \" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\"><br>";
	if ($n_erros != 0) { echo $erro; }
echo "
<script>document.Admin.INomeAdmin.focus();</script>
</form></td></tr></table>
</td></tr></table></center></div>";
}

if ($MasterAdmin == 1 and $Submit and $n_erros == 0 and !$ExcluirAdmin) {
	abre_conexao_db();
	$Consultar = mysql_query("select * from $TableAdm");
	$INovaDataIns = "$DataHpo �s $HoraHpo";
	$IncluiNovoAdm = mysql_query("INSERT INTO $TableAdm (nome, nomecompleto, email, senha, data, level) VALUES('$INomeAdmin','$INomeCompleto','$IEmailAdm','$ISenha01','$INovaDataIns','$ILevelAdm')");
	$NovaInfo = "<b>Inclus�o de Novo Admin por $AdminLogado (Master)</b><br><b>Admin inclu�do: </b>$INomeCompleto";
	InfoLog();
	fecha_conexao_db();
	$Conclusao = "A <b>Inclus�o</b> do Admin <b>$INomeCompleto</b> foi realizada com <b>Sucesso</b><br>";
	imprime_resultado();
}

if ($MasterAdmin == 1 and $ExcluirAdmin == 1) {
	abre_conexao_db();
	$ConsultarMaster = mysql_query("select level from $TableAdm where level = 'Master'");
		if (mysql_num_rows($ConsultarMaster) == 1) {
		$Conclusao = "<b><font color=FF0000>N�o ser� poss�vel Excluir o Administrador</font><br><br>O sistema tem que ter no m�nimo (1) Admin Master<br>";
		imprime_resultado();
		fecha_conexao_db(); echo "</td></tr></table>"; footer(); exit;
		}
	$ExcluirAdm = mysql_query("select * from $TableAdm WHERE (id='" . $IDAdmOut . "')");
	$InfoExcluir = mysql_fetch_assoc($ExcluirAdm);
	$DeletarAdm = mysql_query("delete from $TableAdm WHERE id='" . $IDAdmOut . "'");
	$NovaInfo = "<b><font color=FF0000>Exclus�o</font> de Admin por $AdminLogado (Master)</b><br><b>Admin exclu�do:</b> $InfoExcluir[nomecompleto]";
	InfoLog();
	fecha_conexao_db();
	$Conclusao = "A <b>Exclus�o</b> do Admin <b>$InfoExcluir[nomecompleto]</b> foi realizada com <b>Sucesso</b><br>";
	imprime_resultado();
}

if ($MasterAdmin == 1 and $UpdateLevel == 1) {
abre_conexao_db();
$ConsultarMaster = mysql_query("select level from $TableAdm where level = 'Master'");
$UpdateAdm = mysql_query("select * from $TableAdm WHERE (id='" . $IDUpdate . "')");
$InfoUpdate = mysql_fetch_assoc($UpdateAdm);
	if ($InfoUpdate[level] == Admin) {
	$Atualiza = mysql_query("UPDATE $TableAdm SET level = 'Master' WHERE id='$IDUpdate'");
	$NovaInfo = "<b><font color=FF0000>Update</font> de Admin por $AdminLogado (Master)</b><br><b>Admin $InfoUpdate[nomecompleto]</b> passou para o Level <b>Master</b>";
	InfoLog();
	fecha_conexao_db();
	$Conclusao = "O <b>Update</b> do Admin <b>$InfoUpdate[nomecompleto]</b> foi realizado com <b>Sucesso</b><br><br><b>O Admin $InfoUpdate[nomecompleto]</b> passou para o Level <b>Master</b>";
	imprime_resultado();
    }
	elseif ($InfoUpdate[level] == Master) {
		if (mysql_num_rows($ConsultarMaster) == 1) {
		$Conclusao = "<b><font color=FF0000>N�o ser� poss�vel mudar o Level do Administrador para 'Admin'</font><br><br>O sistema tem que ter no m�nimo (1) Admin Master<br>";
		imprime_resultado();
		fecha_conexao_db(); echo "</td></tr></table>"; footer(); exit;
		}
	$Atualiza = mysql_query("UPDATE $TableAdm SET level = 'Admin' WHERE id='$IDUpdate'");
	$NovaInfo = "<b><font color=FF0000>Update</font> de Admin por $AdminLogado (Master)</b><br><b>Admin $InfoUpdate[nomecompleto]</b> passou para o Level <b>Admin</b>";
	InfoLog();
	fecha_conexao_db();
	$Conclusao = "O <b>Update</b> do Admin <b>$InfoUpdate[nomecompleto]</b> foi realizado com <b>Sucesso</b><br><br><b>O Admin $InfoUpdate[nomecompleto]</b> passou para o Level <b>Admin</b>";
	imprime_resultado();
    }
}

echo "</td></tr></table>";

?>
