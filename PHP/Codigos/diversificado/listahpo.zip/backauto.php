<?php
require ("sessao.php");
require ("config.php");
$LocalArq = '/admin.php';
$LocalCorreto = $UrlDaLista . $LocalArq;
if ($SCRIPT_URI != $LocalCorreto) {
	if (!headers_sent()) {
	header("Location:admin.php?Acao=Senha&ManutTab=1");
	exit;
	}
}

abre_conexao_db();
$back = fopen("backup/BackupTabelas.sql","w");
$res = mysql_query("SHOW CREATE TABLE $TableNome");
while ( $lin = mysql_fetch_row($res)){
fwrite($back,"-- Criando tabela : $TableNome\n");
fwrite($back,"$lin[1];\n-- Dump de Dados\n");
$res1 = mysql_query("SELECT * FROM $TableNome");
while($r=mysql_fetch_row($res1)){
$sql="INSERT INTO $TableNome VALUES ('";
$sql .= implode("','",$r);
$sql .= "');\n";
fwrite($back,$sql);
}
}

$res = mysql_query("SHOW CREATE TABLE $TableAdm");
while ( $lin = mysql_fetch_row($res)){
fwrite($back,"\n-- Criando tabela : $TableAdm\n");
fwrite($back,"$lin[1];\n-- Dump de Dados\n");
$res1 = mysql_query("SELECT * FROM $TableAdm");
while($r=mysql_fetch_row($res1)){
$sql="INSERT INTO $TableAdm VALUES ('";
$sql .= implode("','",$r);
$sql .= "');\n";
fwrite($back,$sql);
}
}

$res = mysql_query("SHOW CREATE TABLE $TableLog");
while ( $lin = mysql_fetch_row($res)){
fwrite($back,"\n-- Criando tabela : $TableLog\n");
fwrite($back,"$lin[1];\n-- Dump de Dados\n");
$res1 = mysql_query("SELECT * FROM $TableLog");
while($r=mysql_fetch_row($res1)){
$sql="INSERT INTO $TableLog VALUES ('";
$sql .= implode("','",$r);
$sql .= "');\n";
fwrite($back,$sql);
}
}

fclose($back);
	$NovaInfo = "<b><font color=008080>Backup Autom�tico das Tabelas</font></b>";
	InfoLog();
	fecha_conexao_db();
?>

