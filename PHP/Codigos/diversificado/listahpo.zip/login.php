<?

require ("config.php");
require ("funcoes.php");

if ($LogOut == "Sim") {
session_start();
$LogInAdmHpo = NULL;
session_unregister("LogInAdmHpo");
session_destroy();
header("Location: index.php");
exit;
}
echo "";

if ($EnviarSenha == sim and !$submit) {
echo "<html><head>
<title>Administra��o da $NomeDaLista - Login</title>
<script>window.defaultStatus='Login Administra��o da $NomeDaLista - Informe seu Nome e Senha'</script>
</head><body><br><center><table border='1' bordercolor='000080' cellpadding='3' cellspacing='3' bgcolor='FFFFFF'>
<form method=\"POST\" action=\"$PHP_SELF?EnviarSenha=sim\" name='remail'>
<tr><td width='100%' align='center' valign='middle' bordercolorlight='ff0000' bordercolordark='ff0000'>
<font face='Verdana' size='3' color='000080'>
<br><b>Recupera��o de Senha - Administra��o</b></font><br>
<font face='Verdana' size='2' color='000080'>
<br><b>Lista de Emails $NomeDaLista</b><br><br>Informe abaixo seu Email<br><br></font>
</td></tr>
<tr><td width='100%' align='center' valign='middle' bordercolorlight='ff0000' bordercolordark='ff0000'>
<font face='Verdana' size='2' color='000080'>
<b>Email do Admin: </b></font><br>
<input type=\"text\" size=\"40\" name=\"EmailAdm\" style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
</td></tr>
<tr><td width='100%' align='center' valign='middle' bordercolorlight='ff0000' bordercolordark='ff0000'>
<br><input type=\"submit\" name=\"submit\" value=\" Enviar a Senha \" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">
<script>document.remail.EmailAdm.focus();</script>
</form></td></tr></font></table></center>";
}
if ($EnviarSenha == sim and $submit) {

	$conexao = mysql_connect($db[host], $db[user], $db[senha]);
	mysql_select_db($db[nome],$conexao);
	$Consultar = mysql_query("select * from $TableAdm WHERE email='$EmailAdm'");
	$Entrada = mysql_fetch_array($Consultar);
	if ($Entrada) {
	$RecNome = $Entrada[nome];
	$RecNomeCompleto = $Entrada[nomecompleto];
	$RecSenha = $Entrada[senha];
	$RecEmail = $Entrada[email];
	mysql_close($conexao);
	require ("modelos.php");
	mail("$RecEmail", "Recupera��o de Senha", "$MsgRecuperaSenha", "From: Lista $NomeDaLista<$EmailSite>");
	$Conclusao = "<font face='Verdana' size='2' color='FF0000'>
<b>A sua Senha de Administrador foi enviada para o seu Email</b><br><br>
<input type=\"button\" value=\" Voltar \" onClick=\"location='login.php'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
imprime_resultado_Login(); exit;
	} else {
	$Conclusao = "<font face='Verdana' size='2' color='FF0000'>
<b>O Email informado na consta em nosso cadastro</b><br><br>
<input type=\"button\" value=\" Voltar \" onClick=\"location='login.php'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
imprime_resultado_Login(); exit;
	}
}

if (!$EnviarSenha and !$submit) {
echo "<html><head>
<title>Administra��o da $NomeDaLista - Login</title>
<script>window.defaultStatus='Login Administra��o da $NomeDaLista - Informe seu Nome e Senha'</script>
</head><body><br><center><table border='01' bordercolor='000080' cellpadding='3' cellspacing='3' bgcolor='FFFFFF'>
<form method=\"POST\" action=\"$PHP_SELF\" name='login'>
<tr><td width='100%' colspan='2' align='center' valign='middle' bordercolorlight='ff0000' bordercolordark='ff0000'>
<font face='Verdana' size='3' color='000080'>
<br><b>�rea de Acesso para Administra��o</b></font><br>
<font face='Verdana' size='2' color='000080'>
<br><b>Lista de Emails $NomeDaLista</b><br><br>Informe abaixo seu Nome e Senha de Acesso<br><br></font>
</td></tr>
<tr><td width='50%' align='right' valign='middle' bordercolorlight='ff0000' bordercolordark='ff0000'>
<font face='Verdana' size='2' color='000080'>
<b>Nome do Admin: </b></font></td>
<td width='50%' align='left' valign='middle' bordercolorlight='ff0000' bordercolordark='ff0000'>
<input type=\"text\" size=\"20\" name=\"NomeAdm\" style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
</td></tr>
<tr><td width='50%' align='right' valign='middle' bordercolorlight='ff0000' bordercolordark='ff0000'>
<font face='Verdana' size='2' color='000080'>
<b>Senha do Admin: </b></font></td>
<td width='50%' align='left' valign='middle' bordercolorlight='ff0000' bordercolordark='ff0000'>
<input type=\"password\" size=\"20\" name=\"SenhaAdm\" style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
</td></tr>
<tr><td width='100%' colspan='2' align='center' valign='middle' bordercolorlight='ff0000' bordercolordark='ff0000'>
<br><input type=\"submit\" name=\"submit\" value=\" E n t r a r \" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">
<script>document.login.NomeAdm.focus();</script>
</form></td></tr></font></table></center>";
if ($RecuperaSenha == "1") {
echo "<center><font face='Verdana' size='2' color='000080'>
Para recuperar sua Senha - <a href='login.php?EnviarSenha=sim' onmouseover=\"self.status='Enviar Senha do Administrador';return true\" style='text-decoration:none;color:0099CC'><b>Clique Aqui</b></a></font></center>";
}
}
	elseif ($submit) {
	$n_erros = 0;
	$erro = "  ";
	if(empty($NomeAdm)) {
	$erro.= "<br><b><font face='Verdana' size='2' color='FF0000'>E R R O</font></b><font face='Verdana' size='2' color='000080'> - Voc� esqueceu de digitar <b>Nome do Admin</b></font><br>";
	$n_erros++;
	}
	if(empty($SenhaAdm)) {
	$erro.= "<br><b><font face='Verdana' size='2' color='FF0000'>E R R O</font></b><font face='Verdana' size='2' color='000080'> - Voc� esqueceu de digitar <b>Senha do Admin</b></font><br>";
	$n_erros++;
	}
	if ($n_erros != 0) { $Conclusao = "$erro<br>
<input type=\"button\" value=\" Voltar e Corrigir \" onClick=\"location='login.php'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
imprime_resultado_Login(); }
	}
    if ($submit and $n_erros == "0") {
	$conexao = mysql_connect($db[host], $db[user], $db[senha]);
	mysql_select_db($db[nome],$conexao);
    $Consultar = mysql_query("select * from $TableAdm WHERE nome='$NomeAdm' and senha='$SenhaAdm'");
	$Entrada = mysql_fetch_array($Consultar);
    $NomeOk = $Entrada[nome];
    $SenhaOk = $Entrada[senha];
	$IdEntra = $Entrada[id];
		if ($NomeAdm == $NomeOk and $SenhaAdm == $SenhaOk ) {
		$NovaInfo = "<b>Entrada do Administrador no Sistema ($NomeOk)</b>";
		InfoLog();
		$UltimoAcesso = $Entrada[data];
		$Atualiza1 = mysql_query("UPDATE $TableAdm SET acesso = '$UltimoAcesso' WHERE id='$IdEntra'");
		$NovaData = "$DataHpo �s $HoraHpo";
		$Atualiza2 = mysql_query("UPDATE $TableAdm SET data = '$NovaData' WHERE id='$IdEntra'");

		mysql_close($conexao);
        session_start();
        $LogInAdmHpo = "ok";
		$NomeAdmin = $Entrada[nome];
		$IdAdmin = $Entrada[id];
		$NomeAdminCompleto = $Entrada[nomecompleto];
		$EmailAdminLogado = $Entrada[email];
		$AdminLevel = $Entrada[level];
		$SenhaAdmin = $Entrada[senha];

		session_register("LogInAdmHpo","NomeAdmin","IdAdmin","NomeAdminCompleto","EmailAdminLogado","AdminLevel","SenhaAdmin");
        header("location:admin.php");
		}
			else {
			$Conclusao = "<font face='Verdana' size='2' color='FF0000'>
<b>O Nome e Senha do Administrador n�o Conferem</b><br><br>
<input type=\"button\" value=\" Voltar e Corrigir \" onClick=\"location='login.php'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
			imprime_resultado_Login();
			}
   }
echo "</body></html>";
?>
