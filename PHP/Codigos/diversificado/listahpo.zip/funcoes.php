<?

$TableExtAdm = "_adm";
$TableAdm = $TableNome . $TableExtAdm;
$TableExtLog = "_log";
$TableLog = $TableNome . $TableExtLog;

function Checa_Update() {
global $ArquivoHpobr;
$ChecaUpdate = curl_init();
curl_setopt ($ChecaUpdate, CURLOPT_URL, $ArquivoHpobr);
curl_exec ($ChecaUpdate);
curl_close ($ChecaUpdate);
}

function abre_conexao_db() {
global $db, $TableNome, $conexao, $Conclusao;
$conexao = mysql_pconnect($db[host], $db[user], $db[senha]);
	if (!$conexao) { $Conclusao = "E R R O - N�o foi poss�vel conectar com o Banco de Dados" . mysql_error();
	echo imprime_resultado(); exit;
	}
mysql_select_db($db[nome],$conexao);
	if (!mysql_select_db($db[nome],$conexao)) { $Conclusao = "E R R O - N�o foi poss�vel selecionar a tabela no Banco de Dados" . mysql_error();
	echo imprime_resultado(); exit;
	}
}

function InfoLog() {
global $NovaInfo, $TableLog, $DataHpo, $HoraHpo;
mysql_query("INSERT INTO $TableLog (info, data, hora) VALUES('$NovaInfo','$DataHpo','$HoraHpo')");
}

function fecha_conexao_db() {
global $conexao;
mysql_close($conexao);
}

function verifica_mail($mail) {
if (strpos ($mail, "@") == 0) {
return true;
}
list($user,$domain)=split("@",$mail,2);
	if (checkdnsrr($domain,"MX")) {
	return false;
	}
	else {
	return true;
	}
}

function imprime_resultado() {
global $Conclusao;
echo "
<div align='center'>
<center>
<table width=\"100%\" border=\"0\" bordercolor=\"000080\" cellpadding=\"0\" cellspacing=\"0\" bgcolor=\"FFFFFF\">
<tr><td width='100%' align='center' valign='middle' bordercolorlight=\"\" bordercolordark=\"\" class=\"txt\">
<br>$Conclusao<br><br></td></tr></table></center></div>";
}

function imprime_resultado_Login() {
global $Conclusao;
echo "<div align='center'><center>
<br><table border=\"1\" bordercolor=\"000080\" cellpadding=\"3\" cellspacing=\"3\" bgcolor=\"FFFFFF\">
<tr><td width='100%' align='center' valign='middle' bordercolorlight=\"FF0000\" bordercolordark=\"FF0000\">
<br>$Conclusao<br><br></td></tr></table></center></div>";
}

function data_extenso($data = 0) {
if (!$data) $data = time();
$mes = array ("Janeiro","fevereiro","Mar�o","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro");
$sem = array ("Domingo","Segunda-feira","Ter�a-feira","Quarta-feira","Quinta-feira","Sexta-feira","S�bado");
return ($sem[(integer)date("w",$data)].", ".date("d",$data)." de ".$mes[(integer)date("m",$data) - 1]." de ".date("Y",$data));
}
$hora = date(H);
if ($hora == 0 or $hora == 1 or $hora == 2 or $hora == 3 or $hora == 4 or $hora == 5) {
$TxtData = 'Boa madrugada! '; }
if ($hora == 6 or $hora == 7 or $hora == 8 or $hora == 9 or $hora == 10 or $hora == 11) {
$TxtData = 'Bom dia! '; }
if ($hora == 12 or $hora == 13 or $hora == 14 or $hora == 15 or $hora == 16 or $hora == 17) {
$TxtData = 'Boa tarde! '; }
if ($hora == 18 or $hora == 19 or $hora == 20 or $hora == 21 or $hora == 22 or $hora == 23) {
$TxtData = 'Boa noite! ';
}

function footer() {
global $TituloSite;
echo "<br><div align=\"center\">
<center><table border=\"0\" bordercolor=\"000080\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">
<tr>
<td width=\"85%\" height=\"40\" valign=\"middle\" align=\"center\" class=\"txt\" background='arquivos/fundo_rod.gif'>
<b>Lista de Emails desenvolvida por <a href='mailto:alexandre@hpobr.com' onmouseover=\"self.status='Fale com o Desenvolvedor da lista';return true\">Alexandre Pina</a> - Home Page Online - <a href='http://www.hpobr.com' target='_blank' onmouseover=\"self.status='Visite a Home Page Online';return true\">www.hpobr.com</a></b></td>
<td width=\"15%\" height=\"40\" valign=\"middle\" align=\"center\" class=\"txt\" background='arquivos/fundo_rod.gif'>
<b>[ <span id=\"pendule\"></span>&nbsp;]</b><br>
<a href=\"javascript:favoritos();\" onMouseOver=\"self.status='$TituloSite - Adicione a Administra��o aos seus favoritos';return true\">Favoritos</a></td>
</tr>
<tr>
<td width=\"100%\" colspan='2' height=\"30\" valign=\"middle\" align=\"center\" class=\"txt\">
A Lista HPonline foi desenvolvida e testada usando: Servidor Apache | PHP  4.3.2 | MySql 4.0.13 | Ambiente Linux RedHat 9.0<br>
Copyright�2003 - Home Page Online - Nova Friburgo/RJ - Brasil | 25 de maio de 2003</td>
</tr></table></center></div>";
}
function relogio_hpo() {
echo "<script language='JavaScript'>
function clock() {
if (!document.layers && !document.all) return;
var digital = new Date();
var hours = digital.getHours();
var minutes = digital.getMinutes();
var seconds = digital.getSeconds();
if (hours == 0) hours = 00;
if (hours < 10) hours = \"0\" + hours;
if (minutes <= 9) minutes = \"0\" + minutes;
if (seconds <= 9) seconds = \"0\" + seconds;
dispTime = hours + \":\" + minutes + \":\" + seconds;
if (document.layers) {
document.layers.pendule.document.write(dispTime);
document.layers.pendule.document.close();
}
else
if (document.all)
pendule.innerHTML = dispTime;
setTimeout(\"clock()\", 1000);
}
</script>";
}

function favoritos_hpo() {
global $UrlDaLista, $NomeDaLista, $TituloSite;
echo "<script>
function favoritos() {
var browsName = navigator.appName;
if (browsName == \"Microsoft Internet Explorer\") {
window.external.AddFavorite('$UrlDaLista/admin.php','Administra��o da Lista $NomeDaLista');
} else
if (browsName == \"Netscape\") {
alert (\"Para adicionar essa p�gina aos seus Favoritos aperte CTRL+D\");
}
}
</script>";
}

?>
