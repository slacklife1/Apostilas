<?php
$username = "hpobr"; // username para entrar na p�gina
$password = "hpobr"; // password para entrar na p�gina
if ($PHP_AUTH_USER != $username || $PHP_AUTH_PW != $password)
{
header("WWW-Authenticate: basic realm='�rea Protegida'");
header("HTTP/1.0 401 Unauthorized");
echo "<br><br><center>Voc� n�o validou login e senha!</center>";
exit;
}
// Se autenticado entra na p�gina de Instala��o
else {
require ("config.php");
require ("funcoes.php");
function headinstalar() {
echo "<html><head>
<title>Instala��o da Lista de Emails HPonline</title>
<style>
body      { scrollbar-face-color:FFFFFF;scrollbar-shadow-color:0099CC;scrollbar-highlight-color:0099CC;
            scrollbar-3dlight-color:0099CC;scrollbar-darkshadow-color:0099CC;scrollbar-track-color:FFFFFF;
            scrollbar-arrow-color:0099CC; }
.txt      { font-family:verdana;font-size:8pt;color:000080; }
a:normal  { text-decoration:none;font-family:Verdana;font-size:8pt;color:000080;font-weight: bold; }
a:link    { text-decoration:none;font-family:Verdana;font-size:8pt;color:000080;font-weight: bold; }
a:visited { text-decoration:none;font-family:Verdana;font-size:8pt;color:000080;font-weight: bold; }
a:hover   { text-decoration:none;font-family:Verdana;font-size:8pt;color:0099CC;font-weight: bold; }
</style>
<script>window.defaultStatus='Instalando a Lista de Email'</script>";
relogio_hpo();
echo "</head>
<body onload=\"clock()\" topmargin='5' leftmargin='0'>
<center><table border=\"1\" bordercolor=\"0099CC\" width=\"95%\">
<tr><td width='100%' height='40' align='center' valign='middle' class='txt'>
<b>Instala��o da Lista de Emails - Home Page Online</b></td></tr>";
}

if (!$Fase) {
headinstalar();
echo "<tr><td width='100%' height='40' align='center' valign='middle' class='txt'>
<p align='justify' style='margin-left:10;margin-right:10'>
<br><b>Bem-vindo ao instalador da Lista HPonline,</b> este script ir� criar as tabelas necess�rias
para o funcionamento da Lista de Emails. Como disse antes no arquivo leiame.txt, que eu
acredito que voc� tenha lido, esta lista foi criada e testada em Servidor Apache, ambiente
Linux, com o PHP 4.3.2 e o Banco de Dados MySql.<br><br>Ent�o, <b>antes de instalar,</b> tenha
certeza de que seu Servidor de Hospedagem possui essas configura��es. Clique no link abaixo
para iniciar a instala��o da lista, e ap�s isso, ser� dada a op��o para o registro de suas informa��es como
Administrador da Lista. Considerando que este � o primeiro registro de Administrador, voc� ser� inscrito como Administrador
Master, ou seja, voc� ser� o �nico a fazer de tudo na Lista de Emails.<br><br><b>I m p o r t a n t e </b> - Este
script foi desenvolvido tanto para <b>Instalar</b> como para <b>Upgrade</b> de novas vers�es. Nas etapas
seguintes ser� verificado se as tabelas j� existem, atualizando se necess�rio, e finalmente ser�
dada a op��o de cadastrar suas informa��es de Administrador, no caso de instala��o.<br><br>";

echo "<b><font color=FF0000>Aten��o:</font></b> Informa��es importantes para voc� configurar corretamente o seu arquivo de configura��o (config.php). Digite as informa��es no (config.php) exatamente como voc� est� vendo abaixo.<br>";
$path = $SCRIPT_URI;
$file = dirname ($path);
echo "<br><b>Esta � a URL da sua Lista: ";
echo "<font color=008080>" . $file . "</b></font><br><br>";
echo "<b>Este � o PATH da sua Lista: ";
$curdir = getcwd();
echo "<font color=008080>" . $curdir . "</font></b>";
echo "<br><br>";
echo "<center><a href='instalar.php?Fase=1' onmouseover=\"self.status='Iniciar a instala��o da Lista';return true\">Iniciar a Instala��o da Lista HPonline</a><br><br></center>
</td></tr>";
footer();

} // Fim do If !$Fase

// In�cio Fase 1
if ($Fase == 1) {
	headinstalar();
	$FADB = "backup/ArqDatas.txt";
	$CFADB = fopen($FADB, "a");
	chmod($FADB,0666);
	fclose($CFADB);
	$ArqDatBac = "backup/ArqDatas.txt";
	$ResDatBac = fopen($ArqDatBac, "w");
	$NovaDataBac = "$DataHpo �s $HoraHpo";
    $AtualizaData = "Sem Backup|Sem Restaurar";
	fwrite($ResDatBac, $AtualizaData);
	fclose($ResDatBac);

	echo "<tr><td width='100%' height='40' align='left' valign='middle' class='txt'>";
	echo "<p align='justify' style='margin-left:15;margin-right:15;margin-top:5'>";
	echo "Verificando as tabelas de <b>Cadastros, Admin e Log</b> e atualizando, se necess�rio";
	echo "<hr width=\"70%\" align=\"left\" color=\"000080\" style='margin-left:15'>";
	echo "<p align='justify' style='margin-left:15;margin-right:15;margin-top:5'>";
	echo "<b>Verificando a tabela de Cadastros</b><br>";
	abre_conexao_db();
	$VerT1 = "SELECT * FROM $TableNome";
	$ResVerT1 = mysql_query($VerT1);
	if ($ResVerT1) { echo "A tabela de Cadastros <b>j� existe</b> --> Verificando Campos...<br>"; }
	else {
	$CriaT1 = "CREATE TABLE $TableNome (id int not null auto_increment primary key, nome varchar(40), email varchar(40), data varchar(15), hora varchar(10), ativo varchar(8))";
	$ResCriaT1 = mysql_query($CriaT1);
	if ($ResCriaT1) { echo "A tabela de Cadastros foi <b>Criada com Sucesso</b> --> Verificando Campos...<br>"; }
	}
	$VerCampo = mysql_query("select id from $TableNome"); if ($VerCampo) { $Atual1 = mysql_query("ALTER TABLE $TableNome CHANGE id id int not null auto_increment primary key"); echo "Campo 01: <b>Atualizado</b> --> Verificando pr�ximo Campo...<br>"; } else { $CriaC1 = mysql_query("ALTER TABLE $TableNome ADD id int not null auto_increment primary key"); echo "<b>Campo 01 criado com Sucesso</b> --> Continuando a verificar os campos...<br>"; }
	$VerCampo = mysql_query("select nome from $TableNome"); if ($VerCampo) { $Atual1 = mysql_query("ALTER TABLE $TableNome CHANGE nome nome VARCHAR(40) DEFAULT NULL "); echo "Campo 02: <b>Atualizado</b> --> Verificando pr�ximo Campo...<br>"; } else { $CriaC1 = mysql_query("ALTER TABLE $TableNome ADD nome varchar(40) AFTER id"); echo "<b>Campo 02 criado com Sucesso</b> --> Continuando a verificar os campos...<br>"; }
	$VerCampo = mysql_query("select email from $TableNome"); if ($VerCampo) { $Atual1 = mysql_query("ALTER TABLE $TableNome CHANGE email email VARCHAR(40) DEFAULT NULL "); echo "Campo 03: <b>Atualizado</b> --> Verificando pr�ximo Campo...<br>"; } else { $CriaC1 = mysql_query("ALTER TABLE $TableNome ADD email varchar(40) AFTER nome"); echo "<b>Campo 03 criado com Sucesso</b> --> Continuando a verificar os campos...<br>"; }
	$VerCampo = mysql_query("select data from $TableNome"); if ($VerCampo) { $Atual1 = mysql_query("ALTER TABLE $TableNome CHANGE data data VARCHAR(15) DEFAULT NULL "); echo "Campo 04: <b>Atualizado</b> --> Verificando pr�ximo Campo...<br>"; } else { $CriaC1 = mysql_query("ALTER TABLE $TableNome ADD data varchar(15) AFTER email"); echo "<b>Campo 04 criado com Sucesso</b> --> Continuando a verificar os campos...<br>"; }
	$VerCampo = mysql_query("select hora from $TableNome"); if ($VerCampo) { $Atual1 = mysql_query("ALTER TABLE $TableNome CHANGE hora hora VARCHAR(10) DEFAULT NULL "); echo "Campo 05: <b>Atualizado</b> --> Verificando pr�ximo Campo...<br>"; } else { $CriaC1 = mysql_query("ALTER TABLE $TableNome ADD hora varchar(10) AFTER data"); echo "<b>Campo 05 criado com Sucesso</b> --> Continuando a verificar os campos...<br>"; }
	$VerCampo = mysql_query("select ativo from $TableNome"); if ($VerCampo) { $Atual1 = mysql_query("ALTER TABLE $TableNome CHANGE ativo ativo VARCHAR(8) DEFAULT NULL "); echo "Campo 06: <b>Atualizado</b> --> Verificando pr�xima Tabela...<br>"; } else { $CriaC1 = mysql_query("ALTER TABLE $TableNome ADD ativo varchar(8) AFTER hora"); echo "<b>Campo 06 criado com Sucesso</b> --> Continuando a verificar as tabelas...<br>"; }

	echo "<hr width=\"70%\" align=\"left\" color=\"000080\" style='margin-left:15'>";
	echo "<p align='justify' style='margin-left:15;margin-right:15;margin-top:5'>";
	echo "<b>Verificando a tabela de Admin</b><br>";

	$VerT2 = "SELECT * FROM $TableAdm";
	$ResVerT2 = mysql_query($VerT2);
	if ($ResVerT2) { echo "A tabela de Admin <b>j� existe</b> --> Verificando Campos...<br>"; }
	else {
	$CriaT2 = "CREATE TABLE $TableAdm (id int not null auto_increment primary key, acesso varchar(25), nome varchar(25), nomecompleto varchar(40), email varchar(40), senha varchar(10), data varchar(25), level varchar(10))";
	$ResCriaT2 = mysql_query($CriaT2);
	if ($ResCriaT2) { echo "A tabela de Admin foi <b>Criada com Sucesso</b> --> Verificando Campos...<br>"; }
	}
	$VerCampo = mysql_query("select id from $TableAdm"); if ($VerCampo) { $Atual1 = mysql_query("ALTER TABLE $TableAdm CHANGE id id int not null auto_increment primary key"); echo "Campo 01: <b>Atualizado</b> --> Verificando pr�ximo Campo...<br>"; } else { $CriaC1 = mysql_query("ALTER TABLE $TableAdm ADD id int not null auto_increment primary key"); echo "<b>Campo 01 criado com Sucesso</b> --> Continuando a verificar os campos...<br>"; }
	$VerCampo = mysql_query("select acesso from $TableAdm"); if ($VerCampo) { $Atual1 = mysql_query("ALTER TABLE $TableAdm CHANGE acesso acesso VARCHAR(25) DEFAULT NULL "); echo "Campo 02: <b>Atualizado</b> --> Verificando pr�ximo Campo...<br>"; } else { $CriaC1 = mysql_query("ALTER TABLE $TableAdm ADD acesso varchar(25) AFTER id"); echo "<b>Campo 02 criado com Sucesso</b> --> Continuando a verificar os campos...<br>"; }
	$VerCampo = mysql_query("select nome from $TableAdm"); if ($VerCampo) { $Atual1 = mysql_query("ALTER TABLE $TableAdm CHANGE nome nome VARCHAR(25) DEFAULT NULL "); echo "Campo 03: <b>Atualizado</b> --> Verificando pr�ximo Campo...<br>"; } else { $CriaC1 = mysql_query("ALTER TABLE $TableAdm ADD nome varchar(25) AFTER acesso"); echo "<b>Campo 03 criado com Sucesso</b> --> Continuando a verificar os campos...<br>"; }
	$VerCampo = mysql_query("select nomecompleto from $TableAdm"); if ($VerCampo) { $Atual1 = mysql_query("ALTER TABLE $TableAdm CHANGE nomecompleto nomecompleto VARCHAR(40) DEFAULT NULL "); echo "Campo 04: <b>Atualizado</b> --> Verificando pr�ximo Campo...<br>"; } else { $CriaC1 = mysql_query("ALTER TABLE $TableAdm ADD nomecompleto varchar(40) AFTER nome"); echo "<b>Campo 04 criado com Sucesso</b> --> Continuando a verificar os campos...<br>"; }
	$VerCampo = mysql_query("select email from $TableAdm"); if ($VerCampo) { $Atual1 = mysql_query("ALTER TABLE $TableAdm CHANGE email email VARCHAR(40) DEFAULT NULL "); echo "Campo 05: <b>Atualizado</b> --> Verificando pr�ximo Campo...<br>"; } else { $CriaC1 = mysql_query("ALTER TABLE $TableAdm ADD email varchar(40) AFTER nomecompleto"); echo "<b>Campo 05 criado com Sucesso</b> --> Continuando a verificar os campos...<br>"; }
	$VerCampo = mysql_query("select senha from $TableAdm"); if ($VerCampo) { $Atual1 = mysql_query("ALTER TABLE $TableAdm CHANGE senha senha VARCHAR(10) DEFAULT NULL "); echo "Campo 06: <b>Atualizado</b> --> Verificando pr�ximo Campo...<br>"; } else { $CriaC1 = mysql_query("ALTER TABLE $TableAdm ADD senha varchar(10) AFTER email"); echo "<b>Campo 06 criado com Sucesso</b> --> Continuando a verificar os campos...<br>"; }
	$VerCampo = mysql_query("select data from $TableAdm"); if ($VerCampo) { $Atual1 = mysql_query("ALTER TABLE $TableAdm CHANGE data data VARCHAR(25) DEFAULT NULL "); echo "Campo 07: <b>Atualizado</b> --> Verificando pr�ximo Campo...<br>"; } else { $CriaC1 = mysql_query("ALTER TABLE $TableAdm ADD data varchar(25) AFTER senha"); echo "<b>Campo 07 criado com Sucesso</b> --> Continuando a verificar os campos...<br>"; }
	$VerCampo = mysql_query("select level from $TableAdm"); if ($VerCampo) { $Atual1 = mysql_query("ALTER TABLE $TableAdm CHANGE level level VARCHAR(10) DEFAULT NULL "); echo "Campo 08: <b>Atualizado</b> --> Verificando pr�xima Tabela...<br>"; } else { $CriaC1 = mysql_query("ALTER TABLE $TableAdm ADD level varchar(10) AFTER data"); echo "<b>Campo 08 criado com Sucesso</b> --> Continuando a verificar as tabelas...<br>"; }

	echo "<hr width=\"70%\" align=\"left\" color=\"000080\" style='margin-left:15'>";
	echo "<p align='justify' style='margin-left:15;margin-right:15;margin-top:5'>";
	echo "<b>Verificando a tabela de Log</b><br>";

	$VerT3 = "SELECT * FROM $TableLog";
	$ResVerT3 = mysql_query($VerT3);
	if ($ResVerT3) { echo "A tabela de Log <b>j� existe</b> --> Verificando Campos...<br>"; }
	else {
	$CriaT3 = "CREATE TABLE $TableLog (id int not null auto_increment primary key, info varchar(255), data varchar(15), hora varchar(10))";
	$ResCriaT3 = mysql_query($CriaT3);
	if ($ResCriaT3) { echo "A tabela de Log foi <b>Criada com Sucesso</b> --> Verificando Campos...<br>"; }
	}
	$VerCampo = mysql_query("select id from $TableLog"); if ($VerCampo) { $Atual1 = mysql_query("ALTER TABLE $TableLog CHANGE id id int not null auto_increment primary key "); echo "Campo 01: <b>Atualizado</b> --> Verificando pr�ximo Campo...<br>"; } else { $CriaC1 = mysql_query("ALTER TABLE $TableLog ADD id int not null auto_increment primary key"); echo "<b>Campo 01 criado com Sucesso</b> --> Continuando a verificar os campos...<br>"; }
	$VerCampo = mysql_query("select info from $TableLog"); if ($VerCampo) { $Atual1 = mysql_query("ALTER TABLE $TableLog CHANGE info info VARCHAR(255) DEFAULT NULL "); echo "Campo 02: <b>Atualizado</b> --> Verificando pr�ximo Campo...<br>"; } else { $CriaC1 = mysql_query("ALTER TABLE $TableLog ADD info varchar(255) AFTER id"); echo "<b>Campo 02 criado com Sucesso</b> --> Continuando a verificar os campos...<br>"; }
	$VerCampo = mysql_query("select data from $TableLog"); if ($VerCampo) { $Atual1 = mysql_query("ALTER TABLE $TableLog CHANGE data data VARCHAR(15) DEFAULT NULL "); echo "Campo 03: <b>Atualizado</b> --> Verificando pr�ximo Campo...<br>"; } else { $CriaC1 = mysql_query("ALTER TABLE $TableLog ADD data varchar(15) AFTER info"); echo "<b>Campo 03 criado com Sucesso</b> --> Continuando a verificar os campos...<br>"; }
	$VerCampo = mysql_query("select hora from $TableLog"); if ($VerCampo) { $Atual1 = mysql_query("ALTER TABLE $TableLog CHANGE hora hora VARCHAR(10) DEFAULT NULL "); echo "Campo 04: <b>Atualizado</b> --> Fim da Verifica��o de Tabelas e Campos...<br>"; } else { $CriaC1 = mysql_query("ALTER TABLE $TableLog ADD hora varchar(10) AFTER data"); echo "<b>Campo 04 criado com Sucesso</b> --> Fim da Verifica��o de Tabelas e Campos...<br>"; }

	echo "<hr width=\"70%\" align=\"left\" color=\"000080\" style='margin-left:15'>";
	echo "<p align='justify' style='margin-left:15;margin-right:15;margin-top:5'>";
	echo "<center><b>Pronto !!! Tabelas instaladas (ou atualizadas) com Sucesso...</b><br><br>Agora o pr�ximo passo ser� cadastrar suas informa��es como Administrador da Lista<br><br>";
	echo "<a href='instalar.php?Fase=2' onmouseover=\"self.status='Iniciar Cadastro';return true\">Iniciar o meu Cadastro de Administrador</a><br><br></center>";
	echo "</td></tr></table>";
fecha_conexao_db();
footer();
}
// Fim da Fase 1

// In�cio Fase 2
if ($Fase == 2) {
	headinstalar();
	echo "<tr><td width='100%' height='40' align='left' valign='middle' class='txt'>";
	abre_conexao_db();
    $Consultar = mysql_query("select * from $TableAdm");
    $AdmExiste = mysql_num_rows($Consultar);
    if ($AdmExiste != 0) {
    $InsLevel = 'Master';
    $UpdateMaster = mysql_query("UPDATE $TableAdm SET level='$InsLevel'");
	fecha_conexao_db();
	echo "<center><br><div class='txt'><font color=FF0000><b>Tabela e Senha do Admin j� configurados anteriormente</b></font></div><br><a href='admin.php' onmouseover=\"self.status='Entrar na Administra��o';return true\">Clique Aqui para entrar na Administra��o</a><br><br></center>";
	}

	else {

if ($Submit) {
    $n_erros = 0;
	$erro = "  ";
	if(empty($NomeAdmin)) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - Voc� esqueceu de digitar <b>Nome do Admin</b><br>";
	$n_erros++;
	}
	if(empty($NomeCompleto)) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - Voc� esqueceu de digitar <b>Nome Completo</b><br>";
	$n_erros++;
	}
	if(empty($EmailAdm)) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - Voc� esqueceu de digitar <b>Email</b><br>";
	$n_erros++;
	}
	if(empty($Senha01)) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - Voc� esqueceu de digitar <b>Informe a Senha</b><br>";
	$n_erros++;
	}
	if(empty($Senha02)) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - Voc� esqueceu de digitar <b>Confirme a Senha</b><br>";
	$n_erros++;
	}
	elseif($Senha01 != $Senha02) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - As Senhas digitadas est�o <b>Diferentes</b><br>";
	$n_erros++;
	}
}
echo "<br><div align=\"center\">
<center><table border=\"0\" bordercolor=\"0099CC\" width=\"95%\" cellpadding=\"2\" cellspacing=\"2\">
<tr><td width=\"45%\" valign=\"top\" align=\"center\" class=\"txt\">
<p align='justify' style='margin-left:5;margin-right:5'><b>Prezado $Webmaster,</b><br>
<br>Agora voc� deve cadastrar suas informa��es como Administrador da Lista de Emails.
Esta op��o s� permite o cadastro enquanto os campos da tabela de Admin est�o vazios, ap�s
feito, nada mais ser� registrado, porque as informa��es j� foram inseridas.<br>Caso haja algum erro, ele vai
aparecer logo abaixo do formul�rio para que voc� possa corrigir.<br><br>";
echo "</td>
<td width=\"55%\" valign=\"top\" align=\"center\" class=\"txt\">
<table border=\"0\" width=\"100%\">
<form method=\"POST\" action=\"instalar.php?Fase=2\" name='Admin'>
<tr><td width=\"40%\" valign=\"top\" align=\"right\" class=\"txt\">
<b>Login do Admin:</b></td>
<td width=\"60%\" valign=\"top\" align=\"left\" class='txt'>
<input type=\"text\" size=\"20\" name=\"NomeAdmin\" style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
<br>M�ximo de 25 caracteres</td>
</tr>
<tr>
<td width=\"40%\" valign=\"top\" align=\"right\" class=\"txt\">
<b>Nome Completo:</b></td>
<td width=\"60%\" valign=\"top\" align=\"left\" class='txt'>
<input type=\"text\" size=\"30\" name=\"NomeCompleto\" style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
<br>M�ximo de 40 caracteres</td>
</tr>
<tr>
<td width=\"40%\" valign=\"top\" align=\"right\" class=\"txt\">
<b>Seu Email:</b></td>
<td width=\"60%\" valign=\"middle\" align=\"left\" class='txt'>
<input type=\"text\" size=\"30\" name=\"EmailAdm\" style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
<br>M�ximo de 40 caracteres</td>
</tr>
<tr>
<td width=\"40%\" valign=\"top\" align=\"right\" class=\"txt\">
<b>Informe a Senha:</b></td>
<td width=\"60%\" valign=\"middle\" align=\"left\" class='txt'>
<input type=\"password\" size=\"15\" name=\"Senha01\" style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
<br>M�ximo de 10 caracteres</td>
</tr>
<tr><td width=\"40%\" valign=\"middle\" align=\"right\" class=\"txt\">
<b>Confirme a Senha:</b></td>
<td width=\"60%\" valign=\"middle\" align=\"left\">
<input type=\"password\" size=\"15\" name=\"Senha02\" style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
</td></tr>
<tr><td colspan=\"2\" valign=\"middle\" align=\"center\" class='txt'>
<input type=\"submit\" name=\"Submit\" value=\" Cadastrar Admin \" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">
<br>";
if ($n_erros != 0) { echo "$erro"; }
echo "
<script>document.Admin.NomeAdmin.focus();</script>
</form></td></tr></table>
</td></tr></table></center></div>";

if ($Submit and $n_erros == "0") {
abre_conexao_db();
$NovaDataIns = "$DataHpo �s $HoraHpo";
$InsLevel = 'Master';
$inserir = mysql_query("INSERT INTO $TableAdm (nome, nomecompleto, email, senha, data, level) VALUES('$NomeAdmin','$NomeCompleto','$EmailAdm','$Senha01','$NovaDataIns','$InsLevel')");
fecha_conexao_db();
echo "<center><br><div class='txt'><b>Pronto !!! Tabela e Senha do Admin configurados, agora � s� usar...</b></div>
<br><a href='admin.php' onmouseover=\"self.status='Entrar na Administra��o';return true\">Clique Aqui para entrar na Administra��o</a><br><br></center>";
} // fim do submit sem erros

} // Fim do else da Fase 2

echo "</td></tr></table>";

footer();
} // Fim da Fase 2

} // Final da P�gina de Instala��o (Fim do Else)
?>

