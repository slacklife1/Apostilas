<?php
require ("sessao.php");
require ("config.php");
require ("funcoes.php");
?>
<html>
<head>
<?

$AdminLogado = $HTTP_SESSION_VARS[NomeAdmin];
$IdAdminLogado = $HTTP_SESSION_VARS[IdAdmin];
$NomeCompletoAdmin = $HTTP_SESSION_VARS[NomeAdminCompleto];
$EmailAdminLog = $HTTP_SESSION_VARS[EmailAdminLogado];
$SenhaAdminLog = $HTTP_SESSION_VARS[SenhaAdmin];
$LevelAdminLog = $HTTP_SESSION_VARS[AdminLevel];

// In�cio da p�gina de Administra��o

echo "
<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=iso-8859-1\">
<META HTTP-EQUIV=\"Expires\" CONTENT=\"0\">
<META HTTP-EQUIV=\"Cache-Control\" CONTENT=\"no-cache, must-revalidate\">
<META HTTP-EQUIV=\"Pragma\" CONTENT=\"no-cache\">
<META NAME=\"generator\" CONTENT=\"HPonline - http://www.hpobr.com\">
<META NAME=\"author\" CONTENT=\"Alexandre Pina\">
<style>
body      { scrollbar-face-color:FFFFFF;scrollbar-shadow-color:0099CC;scrollbar-highlight-color:0099CC;
            scrollbar-3dlight-color:0099CC;scrollbar-darkshadow-color:0099CC;scrollbar-track-color:FFFFFF;
            scrollbar-arrow-color:0099CC; }
.txt      { font-family:verdana;font-size:8pt;color:000080; }
a:normal  { text-decoration:none;font-family:Verdana;font-size:8pt;color:000080;font-weight: bold; }
a:link    { text-decoration:none;font-family:Verdana;font-size:8pt;color:000080;font-weight: bold; }
a:visited { text-decoration:none;font-family:Verdana;font-size:8pt;color:000080;font-weight: bold; }
a:hover   { text-decoration:none;font-family:Verdana;font-size:8pt;color:0099CC;font-weight: bold; }
select    { font-size:8pt;font-family:Verdana;color:000080;background-color:FFFFFF; }
</style>";

relogio_hpo();
favoritos_hpo();

// In�cio da tabela do Cabe�alho

if ($Acao == "Senha") { $LocalStatus = 'Administra��o Geral'; }
if ($Acao == "Log") { $LocalStatus = 'Exibindo Log'; }
if ($Acao == "Consultar") { $LocalStatus = 'Consultar a Lista'; }
if ($Acao == "Buscar") { $LocalStatus = 'Busca por Usu�rio'; }
if ($Acao == "Editar") { $LocalStatus = 'Editar Usu�rio'; }
if ($Acao == "Incluir") { $LocalStatus = 'Incluir Usu�rio'; }
if ($Acao == "Excluir") { $LocalStatus = 'Excluir Usu�rio'; }
if ($Acao == "Mensagem") { $LocalStatus = 'Enviar Mensagem'; }
if ($Acao == "Ajuda") { $LocalStatus = 'Arquivo de Ajuda'; }
if ($Acao == "Historico") { $LocalStatus = 'Hist�rico das Vers�es'; }
if ($Acao == "Principal") { $LocalStatus = 'P�gina Principal'; }
if (!$Acao) { $LocalStatus = 'Seja bem-vindo'; }

abre_conexao_db();
$Consultar = mysql_query("select * from $TableAdm WHERE id ='$IdAdminLogado'");
$UAcesso = mysql_fetch_array($Consultar);
$UltimoAcesso = $UAcesso[acesso];
fecha_conexao_db();

print ("<script>window.defaultStatus='$TituloSite - Lista de Email $NomeDaLista - $LocalStatus'</script>
<title>$TituloSite - Administra��o da Lista de Emails $NomeDaLista [ $LocalStatus ]</title>
</head>
<body onload=\"clock()\" topmargin=\"0\" leftmargin=\"0\">
<div align=\"center\">
<center>
<table border=\"0\" bordercolor=\"000080\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" background='arquivos/fundo_cab.gif'>
<tr><td valign=\"middle\" align=\"left\">
<img border='0' src='$UrlDaLista/arquivos/logohpobr.gif' alt='Desenvolvido por Home Page Online' width='100' height='100'></td>
<td valign=\"middle\" align=\"left\" class=\"txt\"><p align='left' style='margin-left:10'>
<font size=\"3\"><b>Lista de Emails Home Page Online</b></font><br><br>Administra��o da Lista de Emails <b>$NomeDaLista</b>
<br><br>Administrador Logado: <b>$AdminLogado ($LevelAdminLog)</b><br>Seu �ltimo acesso foi em: $UltimoAcesso</td>
<td width=\"20%\" valign=\"middle\" align=\"center\" class='txt'>
<b>Seu IP atual:</b><br><input type='text' size='20' name='Ip' value=\"$REMOTE_ADDR\" style='text-align:center;color:000080;background:FFFFFF;font:8pt,Verdana;border-width:1;border-style:solid;border-color:FF0000'>
<br><br><b>Voc� est� em:</b><br>
<input type='text' size='20' name='Local' value=\"$LocalStatus\" style='text-align:center;color:000080;background:FFFFFF;font:8pt,Verdana;border-width:1;border-style:solid;border-color:FF0000'>
</td>
<td width=\"20%\" valign=\"middle\" align=\"center\" class='txt'>
<a href='login.php?LogOut=Sim' onmouseover=\"self.status='$TituloSite - Sair do Sistema';return true\"><font color='FF0000'>| L o g o u t |</font></a><br>
<br><a href='admin.php?Acao=Senha' onmouseover=\"self.status='$TituloSite - Administra��o Geral';return true\">| Admin Geral |</a><br>
<br><a href='admin.php?Acao=Log' onmouseover=\"self.status='$TituloSite - Consultar o Log';return true\">| Consultar Log |</a>
</td></tr></table></center></div>");

// Tabela do Menu

print ("<div align=\"center\">
<center>
<table border=\"0\" bordercolor=\"000080\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" background='arquivos/fundo_menu.gif'>
<tr><td colspan=\"9\" width=\"100%\" height=\"2\" valign=\"middle\" align=\"center\" bgcolor=\"000080\"></td></tr>
<tr>
<td valign=\"middle\" align=\"center\">
<a href='admin.php?Acao=Principal' onmouseover=\"self.status='$TituloSite - P�gina principal';return true\">| Home |</a></td>
<td valign=\"middle\" align=\"center\">
<a href='admin.php?Acao=Consultar' onmouseover=\"self.status='$TituloSite - Consultar a lista';return true\">| Consultar |</a></td>
<td valign=\"middle\" align=\"center\">
<a href='admin.php?Acao=Buscar' onmouseover=\"self.status='$TituloSite - Buscar por Usu�rio';return true\">| Buscar |</a></td>
<td valign=\"middle\" align=\"center\">
<a href='admin.php?Acao=Editar' onmouseover=\"self.status='$TituloSite - Editar usu�rio';return true\">| Editar |</a></td>
<td valign=\"middle\" align=\"center\">
<a href='admin.php?Acao=Incluir' onmouseover=\"self.status='$TituloSite - Incluir usu�rio';return true\">| Incluir |</a></td>
<td valign=\"middle\" align=\"center\">
<a href='admin.php?Acao=Excluir' onmouseover=\"self.status='$TituloSite - Excluir usu�rio';return true\">| Excluir |</a></td>
<td valign=\"middle\" align=\"center\">
<a href='admin.php?Acao=Mensagem' onmouseover=\"self.status='$TituloSite - Enviar Mensagem';return true\">| Enviar Mensagem |</a></td>
<td valign=\"middle\" align=\"center\">
<a href='admin.php?Acao=Ajuda' onmouseover=\"self.status='$TituloSite - Ajuda Online';return true\">| Ajuda |</a></td>
<td valign=\"middle\" align=\"center\">
<a href='admin.php?Acao=Historico' onmouseover=\"self.status='$TituloSite - Hist�rico das Vers�es';return true\">| Hist�rico |</a></td>
</tr>
<tr><td colspan=\"9\" width=\"100%\" height=\"2\" valign=\"middle\" align=\"center\" bgcolor=\"000080\"></td></tr>
</table></center></div>");
echo "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">
<tr><td valign=\"middle\" align=\"center\" class='txt'>";
echo "<b>$TxtData</b>"; echo data_extenso();
echo " :: Rodando em ";
if ($SERVER_SOFTWARE) { echo "<b>Servidor</b> "; echo $SERVER_SOFTWARE; }
abre_conexao_db();
if (mysql_get_server_info()) { echo " :: <b>MySql</b> vers�o "; echo mysql_get_server_info(); }
fecha_conexao_db();
if (phpversion()) { echo " :: <b>PHP</b> vers�o "; echo phpversion(); }
echo "</td></tr>
<tr><td width=\"100%\" height=\"2\" valign=\"middle\" align=\"center\" bgcolor=\"000080\"></td></tr>
</table>";

// Fim da tabela do cabe�alho

// In�cio das p�ginas de tarefas

print ("<center><br><table border=\"1\" bordercolor=\"0099CC\" width=\"90%\"><tr><td>");

if (!$Acao and $BackupAuto == 1) { include("backauto.php"); }

if (!$Acao or $Acao == "Principal") {
echo "<center><table width=\"99%\" border=\"0\" cellpadding='4' cellspacing='4'>
<tr><td width='62%' valign='middle' class='txt'><b>Bem-vindo $NomeCompletoAdmin</b>,<br>Na administra��o da Lista de Emails, voc� ter� as seguintes op��es:<br><br>
<p align='justify' style='margin-left:0;margin-right:0;margin-top:5' class='txt'>
a) Consultar a Lista; b) Buscar usu�rios; c) Editar usu�rios;
d) Incluir usu�rios; e) Excluir usu�rios; f) Enviar mensagens para os membros da lista;
g) Alterar sua Senha; h) Consultar todas as altera��es j� efetuadas; i) Fazer ou Restaurar Backup.<br>";
    abre_conexao_db();
    $Consultar = mysql_query("select * from $TableNome");
	$TotalCons = mysql_num_rows($Consultar);
    $ConsultaAtivo = mysql_query("select * from $TableNome WHERE ativo=1");
	$TotalAtivos = mysql_num_rows($ConsultaAtivo);
    $ConsultaInativo = mysql_query("select * from $TableNome WHERE ativo=0");
	$TotalInativos = mysql_num_rows($ConsultaInativo);
	if ($TotalInativos == 1) { $MsgIna01 = 'usu�rio'; $MsgIna02 = 'ainda n�o confirmou seu cadastro'; }
	else { $MsgIna01 = 'usu�rios'; $MsgIna02 = 'ainda n�o confirmaram seus cadastros'; }
	if ($TotalCons == 1) { $TextoTotalCons = "usu�rio</b> inscrito na Lista"; }
	else { $TextoTotalCons = "usu�rios</b> inscritos na Lista"; }
	if ($TotalAtivos == 1) { $TextoTotalAtivos = usu�rio; }
	else { $TextoTotalAtivos = usu�rios; }
    $Consultar = mysql_query("select * from $TableNome");
    mysql_close($conexao);
    echo "<br>No momento existe um total de <b>$TotalCons $TextoTotalCons<br>Sendo <b>$TotalAtivos $TextoTotalAtivos</b> com o cadastro <b>Ativo</b><br>
<font color='FF0000'><b>$TotalInativos $MsgIna01</b></font> $MsgIna02<br>
<br><b>Vers�o da sua Lista:</b> $VersaoLista";
$ArquivoHpobr = "http://www.hpobr.com/hponline/scripts/lista/lista_update.php?Lista=$VersaoLista";
Checa_Update();
echo "</td><td width='38%' valign='top' class='txt'>";
$ArquivoHpobr = 'http://www.hpobr.com/hponline/scripts/lista/lista_avisos.php';
Checa_Update();
echo "</td></tr></table></center>";
}

// In�cio de Senha
if ($Acao == "Senha") { include "senha.php"; }
// Final de Senha

// In�cio do Log
if ($Acao == "Log") { include "log.php"; }
// Final do Log

// In�cio da Consulta
if ($Acao == "Consultar") { include "consultar.php"; }
// Final da Consulta

// In�cio de Buscar
if ($Acao == "Buscar") { include "buscar.php"; }
// Final de Buscar

// In�cio de Editar
if ($Acao == "Editar") { include "editar.php"; }
// Final de Editar

// In�cio de Incluir
if ($Acao == "Incluir") { include "incluir.php"; }
// Final de Incluir

// In�cio de Excluir
if ($Acao == "Excluir") { include "excluir.php"; }
// Final de Excluir

// In�cio de Enviar Mensagens
if ($Acao == "Mensagem") { include "mensagem.php"; }
// Final de Enviar Mensagem

// In�cio da Ajuda
if ($Acao == "Ajuda") { include ("ajuda.php"); }
// Final da Ajuda

// In�cio de Hist�rico
if ($Acao == "Historico") { include ("historico.php"); }
// Final de Hist�rico

// Final das p�ginas de tarefas

print ("</td></tr></table>");

// Tabela do Rodap�

footer();

// Fim da p�gina de Administra��o

?>

</body>
</html>

