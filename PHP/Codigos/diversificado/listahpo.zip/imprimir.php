<?php
require ("sessao.php");
require ("config.php");
require ("funcoes.php");
?>
<html>
<head>
<META NAME='pragma' CONTENT='no-cache'>
<style>
body      { scrollbar-face-color:FFFFFF;scrollbar-shadow-color:0099CC;scrollbar-highlight-color:0099CC;
            scrollbar-3dlight-color:0099CC;scrollbar-darkshadow-color:0099CC;scrollbar-track-color:FFFFFF;
            scrollbar-arrow-color:0099CC; }
.txt      { font-family:verdana;font-size:8pt;color:000080; }
a:normal  { text-decoration:none;font-family:Verdana;font-size:8pt;color:000080;font-weight: bold; }
a:link    { text-decoration:none;font-family:Verdana;font-size:8pt;color:000080;font-weight: bold; }
a:visited { text-decoration:none;font-family:Verdana;font-size:8pt;color:000080;font-weight: bold; }
a:hover   { text-decoration:none;font-family:Verdana;font-size:8pt;color:0099CC;font-weight: bold; }
select    { font-size:8pt;font-family:Verdana;color:000080;background-color:FFFFFF; }
</style>

<script>window.defaultStatus='Imprimindo Resultados'</script>
<title>Imprimindo Resultados</title>
</head>
<body onload="self.print();window.close()" topmargin="0" leftmargin="0">
<div align='center'>
<center>
<table border="0" bordercolor='000080' cellpadding='0' cellspacing='0' width='100%'>
<tr><td valign='middle' align='center' height='50' class='txt'>
<?
if ($TableImp == Ajuda) { $pagina = "de Ajuda"; }
if ($TableImp == Historico) { $pagina = "do Hist�rico"; }
?>
<b>Administra��o da Lista de Emails <? echo $NomeDaLista; ?><br><br>
Impress�o dos Resultados da p�gina <? echo $pagina; ?> || Em <? echo "$DataHpo �s $HoraHpo"; ?></b></td></tr>
<tr><td>
<?
if ($TableImp == Ajuda) { include ("ajuda.php"); exit; }
if ($TableImp == Historico) { include ("historico.php"); exit; }

    abre_conexao_db();
	$busca = "SELECT * FROM $TableImp";
	$registrosPorPagina = 20;
	if (empty($pagina)):    $pc = 1; 	else:    $pc = $pagina; endif;
	if (!isset($pagina)) { $pagina = 1; }
	$inicio = $pc - 1;
	$inicio = $inicio * $registrosPorPagina;
	$limite = mysql_query("$busca WHERE id order by id desc LIMIT $inicio,$registrosPorPagina");
	$totalRegistros = mysql_num_rows(mysql_query("$busca"));
	$TotalRegistrosInf = mysql_num_rows(mysql_query("$busca"));
	$numPaginas = $totalRegistros / $registrosPorPagina;
		if ($TableImp == $TableNome) {
			echo "<br><table border='0' width=\"100%\">
			<tr><td width=\"5%\" valign=\"middle\" align=\"right\" class='txt'><b>ID</b></td>
            <td width=\"1%\"></td>
			<td width=\"30%\" valign=\"middle\" align=\"left\" class='txt'><b>Nome do usu�rio</b></td>
			<td width=\"30%\" valign=\"middle\" align=\"left\" class='txt'><b>Email do usu�rio</b></td>
			<td width=\"10%\" valign=\"middle\" align=\"center\" class='txt'><b>Ativo</b></td>
			<td width=\"24%\" valign=\"middle\" align=\"center\" class='txt'><b>Inclu�do em:</b></td></tr>";
		} else {
		echo "<table border='0' width=\"100%\">
		<tr><td width=\"5%\" height=\"35\" valign=\"middle\" align=\"right\" class='txt'><b>ID</b></td>
		<td width=\"1%\" height=\"35\"></td>
		<td width=\"24%\" height=\"35\" valign=\"middle\" align=\"center\" class='txt'><b>Data e Hora</b></td>
		<td width=\"70%\" height=\"35\" valign=\"middle\" align=\"center\" class='txt'><b>Resumo das altera��es feitas at� o momento | Exibindo p�g: $pagina</b></td></tr>";
		}
				while($Linha = mysql_fetch_array($limite)) {
				if ($Linha[ativo] == 0) { $InfoAtivo = "<font color='FF0000'>N�o</font>"; }
				if ($Linha[ativo] == 1) { $InfoAtivo = Sim; }
		if ($TableImp == $TableNome) {
				echo "<tr><td width=\"5%\" valign=\"middle\" align=\"right\" class='txt'>$Linha[id]</td>
            	<td width=\"1%\"></td>
				<td width=\"30%\" valign=\"middle\" align=\"left\" class='txt'>$Linha[nome]</td>
				<td width=\"30%\" valign=\"middle\" align=\"left\" class='txt'>$Linha[email]</td>
				<td width=\"10%\" valign=\"middle\" align=\"center\" class='txt'>$InfoAtivo</td>
				<td width=\"24%\" valign=\"middle\" align=\"center\" class='txt'>$Linha[data] �s $Linha[hora]</td></tr>";
		} else {
			echo "<tr><td width=\"5%\" valign=\"top\" align=\"right\" class='txt'>$Linha[id]</td>
           	<td width=\"1%\"></td>
			<td width=\"24%\" valign=\"top\" align=\"center\" class='txt'>$Linha[data] �s $Linha[hora]</td>
			<td width=\"70%\" valign=\"top\" align=\"left\" class='txt'>$Linha[info]</td></tr>";
		}
				}
				echo "</table></center>";
	fecha_conexao_db();
?>
</td></tr></table></center></div>
<?
echo "<br><div align=\"center\">
<center><table border=\"0\" bordercolor=\"000080\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">
<tr>
<td width=\"100%\" height=\"40\" valign=\"middle\" align=\"center\" class=\"txt\" background='arquivos/fundo_rod.gif'>
<b>Lista de Emails desenvolvida por Alexandre Pina - Home Page Online - www.hpobr.com</b></td>
</tr>
<tr>
<td width=\"100%\" height=\"30\" valign=\"middle\" align=\"center\" class=\"txt\">
A Lista HPo foi desenvolvida em: Servidor Apache | PHP  4.3.2 | MySql 4.0.13 | Ambiente Linux RedHat 9.0<br>
Copyright�2003 - Home Page Online - Nova Friburgo/RJ - Brasil | 25 de maio de 2003</td>
</tr></table></center></div>";
?>

