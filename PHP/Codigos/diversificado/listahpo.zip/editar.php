<?
require ("sessao.php");
require ("config.php");
$LocalArq = '/admin.php';
$LocalCorreto = $UrlDaLista . $LocalArq;
if ($SCRIPT_URI != $LocalCorreto) {
	if (!headers_sent()) {
	header("Location:admin.php?Acao=Editar");
	exit;
	}
}

abre_conexao_db();
$Consultar = mysql_query("select * from $TableNome");
if (mysql_num_rows($Consultar) == 0) {
$Conclusao = "<b>N�o existem registros no Banco de Dados";
fecha_conexao_db();
imprime_resultado();
}
	elseif ($Acao == "Editar" and !$submit and !$AtivaCadastro and !$DesativaCadastro) {
	echo "<br><table border=\"0\" width=\"100%\">
<form method=\"POST\" action=\"admin.php?Acao=Editar\">
<tr><td width=\"100%\" valign=\"middle\" align=\"center\" class=\"txt\">
Escolha na rela��o abaixo o usu�rio que deseja <b>Editar</b><br><br><select size=\"1\" name=\"EditarID\">
<option>Rela��o dos usu�rios cadastrados na Lista $NomeDaLista</option>";
	abre_conexao_db();
	$ConsultaRapida = mysql_query("select * from $TableNome");
	fecha_conexao_db();
		while($LinhaBRap = mysql_fetch_array($ConsultaRapida)) {
		if ($LinhaBRap[ativo] == 0) { $InfoAtivo = Inativo; }
		if ($LinhaBRap[ativo] == 1) { $InfoAtivo = Ativo; }
		echo "<option value=\"$LinhaBRap[id]\">$LinhaBRap[id] - $LinhaBRap[nome] - $LinhaBRap[email] - $InfoAtivo</option>";
		}
	echo "</select></td></tr>
<tr><td width=\"100%\" valign=\"middle\" align=\"center\">
<input type=\"hidden\" name=\"EditarUsuario\" value=\"1\">
<input type=\"submit\" name=\"submit\" value=\" Editar Usu�rio \" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">
</form></td></tr></table>";
	}

if ($Acao == "Editar" and $EditarUsuario == "1") {

	if ($EditarID == "Rela��o dos usu�rios cadastrados na Lista $NomeDaLista") { $Conclusao = "Prezado Administrador da Lista $NomeDaLista.<br><br>Voc� tem que selecionar um usu�rio para poder <b>Editar</b><br><br>
<input type=\"button\" value=\" Voltar e Corrigir \" onClick=\"location='$PHP_SELF?Acao=Editar'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
	imprime_resultado(); }
	else {
	abre_conexao_db();
	$ConsultaEditar = mysql_query("select * from $TableNome WHERE (id='" . $EditarID . "')");
	$EditaID = mysql_fetch_assoc($ConsultaEditar);
	fecha_conexao_db();
	echo "<br><table border=\"0\" width=\"100%\">
<form method=\"POST\" action=\"admin.php?Acao=Editar\">
<tr><td colspan=\"2\" width=\"100%\" valign=\"middle\" align=\"center\" class=\"txt\">
Para <b>editar o nome e email</b>, modifique abaixo as informa��es do usu�rio</td></tr>
<tr><td width=\"30%\" valign=\"middle\" align=\"right\" class=\"txt\">
<b>Nome:</b></td>
<td width=\"70%\" valign=\"middle\" align=\"left\">
<input type=\"text\" size=\"55\" name=\"EditaNovoNome\" value=\"$EditaID[nome]\" style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
</td></tr>
<tr><td width=\"30%\" valign=\"middle\" align=\"right\" class=\"txt\">
<b>Email:</b></td>
<td width=\"70%\" valign=\"middle\" align=\"left\">
<input type=\"text\" size=\"55\" name=\"EditaNovoEmail\" value=\"$EditaID[email]\" style='height:16;color:000080;background:#CCCCCC;font:8pt,Verdana;border-width:1;border-style:solid;border-color:000080'>
</td></tr>
<tr><td colspan=\"2\" width=\"100%\" valign=\"middle\" align=\"center\" class='txt'>";
if ($EditaID[ativo] == 0) { $SitCad = Inativo; }
if ($EditaID[ativo] == 1) { $SitCad = Ativo; }
echo "<b>Situa��o do Cadastro:</b> $SitCad | <b>Inclu�do em:</b> $EditaID[data] �s $EditaID[hora]</td></tr>
<tr><td colspan=\"2\" width=\"100%\" valign=\"middle\" align=\"center\">
<input type=\"hidden\" name=\"AntigoNome\" value=\"$EditaID[nome]\">
<input type=\"hidden\" name=\"AntigoEmail\" value=\"$EditaID[email]\">
<input type=\"hidden\" name=\"EditaIdUsuario\" value=\"$EditaID[id]\">
<input type=\"hidden\" name=\"EditarUsuario\" value=\"2\">
<input type=\"submit\" name=\"submit\" value=\" Atualizar as informa��es do Usu�rio (Nome e Email) \" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">
</form></td></tr>
<tr><td colspan=\"2\" width=\"100%\" valign=\"middle\" align=\"center\" class='txt'>
Para <b>modificar a situa��o</b> do usu�rio para <b>'Ativo' ou 'Inativo'</b>, utilize o link abaixo:<br><br>";
		if ($EditaID[ativo] == 0) {
		echo "<a href='admin.php?Acao=Editar&AtivaCadastro=$EditaID[id]' onmouseover=\"self.status='Ativar o Cadastro de $EditaID[nome]';return true;\">Ativar Cadastro ID: $EditaID[id]</a>";
		} else {
		echo "<a href='admin.php?Acao=Editar&DesativaCadastro=$EditaID[id]' onmouseover=\"self.status='Desativar o Cadastro de $EditaID[nome]';return true;\"><font color='FF0000'>Desativar</font> Cadastro ID: $EditaID[id]</a>";
		}
	echo "<br><br></td></tr></table>";
	}

}

if ($Acao == "Editar" and $EditarUsuario == "2") {
    $n_erros = 0;
	$erro = "  ";
	if(empty($EditaNovoNome)) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - Voc� esqueceu de digitar um <b>Nome</b><br>";
	$n_erros++;
	}
	if(empty($EditaNovoEmail)) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - Voc� esqueceu de digitar um <b>Email</b><br>";
	$n_erros++;
	}
	elseif (verifica_mail($EditaNovoEmail)) {
	$erro.= "<br><b><font color='FF0000'>E R R O</font></b> - Confira o email, pois este dom�nio <b>N�o Existe</b><br>";
	$n_erros++;
	}
	if ($n_erros != 0) { $Conclusao = "$erro<br>
<input type=\"button\" value=\" Voltar e Corrigir \" onClick=\"location='$PHP_SELF?Acao=Editar'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
	imprime_resultado(); }
	}
    if ($submit and $n_erros == "0") {
    abre_conexao_db();
    $EmailsTabela = mysql_query("select email from $TableNome WHERE email='" . $EditaNovoEmail . "' ");
	$ChecaEmails = mysql_num_rows($EmailsTabela);
    $ConsultaEditar = mysql_query("select * from $TableNome WHERE id='" . $EditaIdUsuario . "' ");
	$ChecaEditar = mysql_fetch_assoc($ConsultaEditar);
       	if ($ChecaEditar[nome] == $EditaNovoNome and $ChecaEditar[email] == $EditaNovoEmail ) {
		$Conclusao = "A atualiza��o <b>n�o foi efetuada</b> porque o nome e o email informados<br><br><b>j� exitem</b> no Banco de Dados (informa��es id�nticas)<br><br>
<input type=\"button\" value=\" Editar outro Usu�rio \" onClick=\"location='$PHP_SELF?Acao=Editar'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
		imprime_resultado();
		}
       	if ($ChecaEditar[nome] != $EditaNovoNome and $ChecaEditar[email] == $EditaNovoEmail ) {
		$editar = mysql_query("UPDATE $TableNome SET nome='$EditaNovoNome' WHERE id=$EditaIdUsuario");
        $NovaInfo = "<b>Edi��o de usu�rio ($AdminLogado) - Mudan�a de Nome</b><br><b>Antes</b> Nome: $AntigoNome <br><b>Depois</b> Nome: $EditaNovoNome";
		InfoLog();
		$Conclusao = "A atualiza��o do cadastro <b>foi efetuada com Sucesso</b><br><br><b>Novo nome:</b> $EditaNovoNome | <b>Email mantido:</b> $EditaNovoEmail<br><br>
<input type=\"button\" value=\" Editar outro Usu�rio \" onClick=\"location='$PHP_SELF?Acao=Editar'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
		imprime_resultado();
		}
       	if ($ChecaEditar[nome] == $EditaNovoNome and $ChecaEditar[email] != $EditaNovoEmail ) {
			if ($ChecaEmails == 0 ) {
            $editar = mysql_query("UPDATE $TableNome SET email='$EditaNovoEmail' WHERE id=$EditaIdUsuario");
        	$NovaInfo = "<b>Edi��o de usu�rio ($AdminLogado) - Mudan�a de Email</b><br><b>Antes</b> Email: $AntigoEmail <br><b>Depois</b> Email: $EditaNovoEmail";
			InfoLog();
			$Conclusao = "A atualiza��o do cadastro <b>foi efetuada com Sucesso</b><br><br><b>Novo Email:</b> $EditaNovoEmail | <b>Nome mantido:</b> $EditaNovoNome<br><br>
<input type=\"button\" value=\" Editar outro Usu�rio \" onClick=\"location='$PHP_SELF?Acao=Editar'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
			imprime_resultado();
			}
			else {
			$Conclusao = "A atualiza��o do cadastro <b>n�o foi efetuada</b><br><br>Porque o email: <b>$EditaNovoEmail</b> j� consta no Banco de Dados<br><br>
<input type=\"button\" value=\" Editar outro Usu�rio \" onClick=\"location='$PHP_SELF?Acao=Editar'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
			imprime_resultado();
            }
		}
       	if ($ChecaEditar[nome] != $EditaNovoNome and $ChecaEditar[email] != $EditaNovoEmail ) {
			if ($ChecaEmails == 0 ) {
			$editar = mysql_query("UPDATE $TableNome SET email='$EditaNovoEmail',nome='$EditaNovoNome' WHERE id=$EditaIdUsuario");
	        $NovaInfo = "<b>Edi��o de usu�rio ($AdminLogado) - Mudan�a de Nome e Email</b><br><b>Antes</b> Nome: $AntigoNome || Email: $AntigoEmail<br><b>Depois</b> Nome: $EditaNovoNome || Email: $EditaNovoEmail";
			InfoLog();
			$Conclusao = "A altera��o do cadastro foi efetuada com <b>Sucesso</b><br><br>Nome: <b>$EditaNovoNome</b> - Email: <b>$EditaNovoEmail</b><br><br>
<input type=\"button\" value=\" Editar outro Usu�rio \" onClick=\"location='$PHP_SELF?Acao=Editar'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
			imprime_resultado();
			}
			else {
			$Conclusao = "A atualiza��o do cadastro <b>n�o foi efetuada</b><br><br>Porque o email: <b>$EditaNovoEmail</b> j� consta no Banco de Dados<br><br>
<input type=\"button\" value=\" Editar outro Usu�rio \" onClick=\"location='$PHP_SELF?Acao=Editar'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
			imprime_resultado();
            }
		}
		fecha_conexao_db();
	}
if ($AtivaCadastro) {
abre_conexao_db();
$ConsultaAtivar = mysql_query("select * from $TableNome WHERE (id='" . $AtivaCadastro . "')");
$AtivaID = mysql_fetch_assoc($ConsultaAtivar);
$NovaInfo = "<b>Edi��o de usu�rio ($AdminLogado) - Cadastro Ativado</b><br>O usu�rio $AtivaID[nome] passou a ter seu cadastro <b>Ativo</b>";
InfoLog();
$InfoAtivo = 1;
$Ativar = mysql_query("UPDATE $TableNome SET ativo='$InfoAtivo' WHERE id=$AtivaID[id]");
fecha_conexao_db();
$Conclusao = "<b>Cadastro do usu�rio $AtivaID[nome] Ativado</b><br><br>
<input type=\"button\" value=\" Editar outro Usu�rio \" onClick=\"location='$PHP_SELF?Acao=Editar'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
imprime_resultado();
}
if ($DesativaCadastro) {
abre_conexao_db();
$ConsultaDesativar = mysql_query("select * from $TableNome WHERE (id='" . $DesativaCadastro . "')");
$DesativaID = mysql_fetch_assoc($ConsultaDesativar);
$NovaInfo = "<b>Edi��o de usu�rio ($AdminLogado) - Cadastro Desativado</b><br>O usu�rio $DesativaID[nome] passou a ter seu cadastro <b>Inativo</b>";
InfoLog();
$InfoAtivo = 0;
$Desativar = mysql_query("UPDATE $TableNome SET ativo='$InfoAtivo' WHERE id=$DesativaID[id]");
fecha_conexao_db();
$Conclusao = "<b>Cadastro do usu�rio $DesativaID[nome] <font color='FF0000'>Desativado</font></b><br><br>
<input type=\"button\" value=\" Editar outro Usu�rio \" onClick=\"location='$PHP_SELF?Acao=Editar'\" style=\"cursor:hand;font-family:Verdana;font-size:8pt;color:000080;font-weight:bold;background-color:FFFFFF;border-width:1;border-style:solid;border-color:000080\">";
imprime_resultado();
}

?>
