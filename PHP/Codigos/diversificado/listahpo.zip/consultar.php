<?
require ("sessao.php");
require ("config.php");
$LocalArq = '/admin.php';
$LocalCorreto = $UrlDaLista . $LocalArq;
if ($SCRIPT_URI != $LocalCorreto) {
	if (!headers_sent()) {
	header("Location:admin.php?Acao=Consultar");
	exit;
	}
}
    abre_conexao_db();
	$busca = "SELECT * FROM $TableNome";
	$registrosPorPagina = 20;
	if (empty($pagina)):    $pc = 1; 	else:    $pc = $pagina; endif;
	if (!isset($pagina)) { $pagina = 1; }
	$inicio = $pc - 1;
	$inicio = $inicio * $registrosPorPagina;
	$limite = mysql_query("$busca WHERE id order by id desc LIMIT $inicio,$registrosPorPagina");
	$totalRegistros = mysql_num_rows(mysql_query("$busca"));
	$TotalRegistrosInf = mysql_num_rows(mysql_query("$busca"));
	$numPaginas = $totalRegistros / $registrosPorPagina;
		if ($totalRegistros == 0) {
		$Conclusao = "<b>N�o existem registros no Banco de Dados";
		imprime_resultado();
		}
		else {
			echo "<br><table border='0' width=\"100%\">
			<tr><td width=\"5%\" valign=\"middle\" align=\"right\" class='txt'><b>ID</b></td>
            <td width=\"1%\"></td>
			<td width=\"30%\" valign=\"middle\" align=\"left\" class='txt'><b>Nome do usu�rio</b></td>
			<td width=\"30%\" valign=\"middle\" align=\"left\" class='txt'><b>Email do usu�rio</b></td>
			<td width=\"10%\" valign=\"middle\" align=\"center\" class='txt'><b>Ativo</b></td>
			<td width=\"24%\" valign=\"middle\" align=\"center\" class='txt'><b>Inclu�do em:</b></td></tr>";
				while($Linha = mysql_fetch_array($limite)) {
				if ($Linha[ativo] == 0) { $InfoAtivo = "<font color='FF0000'>N�o</font>"; }
				if ($Linha[ativo] == 1) { $InfoAtivo = Sim; }
				echo "<tr><td width=\"5%\" valign=\"middle\" align=\"right\" class='txt'>$Linha[id]</td>
            	<td width=\"1%\"></td>
				<td width=\"30%\" valign=\"middle\" align=\"left\" class='txt'>$Linha[nome]</td>
				<td width=\"30%\" valign=\"middle\" align=\"left\" class='txt'>$Linha[email]</td>
				<td width=\"10%\" valign=\"middle\" align=\"center\" class='txt'>$InfoAtivo</td>
				<td width=\"24%\" valign=\"middle\" align=\"center\" class='txt'>$Linha[data] �s $Linha[hora]</td></tr>";
				}

		echo "<tr><td colspan='6' align='center' valign='middle' class='txt'><br>";

	$anterior = $pc - 1;
	$proximo =  $pc + 1;
	if ($pc>1): echo " <a href='$PHP_SELF?Acao=Consultar&pagina=$anterior' onmouseover=\"self.status='$TituloSite - Ir para P�gina Anterior';return true\"><img src='arquivos/setaesq.gif' width='18' height='8' border='0'><img src='arquivos/setaesq.gif' width='18' height='8' border='0'> Anterior | </a> "; else: echo "<img src='arquivos/setaesq.gif' width='18' height='8' border='0'><img src='arquivos/setaesq.gif' width='18' height='8' border='0'><b> Anterior | </b>"; endif;
	if ($pc<$numPaginas):	echo " <a href='$PHP_SELF?Acao=Consultar&pagina=$proximo' onmouseover=\"self.status='$TituloSite - Ir para Pr�xima P�gina';return true\"> | Pr�xima <img src='arquivos/setadir.gif' width='18' height='8' border='0'><img src='arquivos/setadir.gif' width='18' height='8' border='0'></a>"; else: echo "<b> | Pr�xima </b><img src='arquivos/setadir.gif' width='18' height='8' border='0'><img src='arquivos/setadir.gif' width='18' height='8' border='0'>";		endif;

	echo "<br><br>";

	if (($totalRegistros%$registrosPorPagina!=0)):
		while($totalRegistros%$registrosPorPagina!=0){$totalRegistros++;}
	endif;
	echo "<b>Link Direto para as P�ginas</b><br>";
	for ($a=1;$a<=$totalRegistros;$a++) {
	if ($a%$registrosPorPagina==0):
		$link = $a;
		$link /= $registrosPorPagina;
		if ($link!=$pagina):
			echo " <a href='$PHP_SELF?Acao=Consultar&pagina=$link' onmouseover=\"self.status='$TituloSite - Ir para P�gina $link';return true\">$link</a>&nbsp;";
		else:
			echo "<font color=0099CC> ::<strong>$link</strong>::&nbsp;</font>";
		endif;
		$aux++;
	endif;
}
	echo "<br><br>| <b>Exibindo p�g: $pagina</b> | <b>Total de $link p�ginas</b> | <b>Total de $TotalRegistrosInf registros</b> |
<a href=\"#\" onclick=\"window.open('imprimir.php?TableImp=$TableNome&pagina=$link','Imprimindo','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,top=800,left=0');return false\" onMouseOver=\"self.status='Imprimir esta p�gina de resultados';return true\"><img src=\"arquivos/print.gif\" width=\"20\" height=\"18\" border=\"0\" alt=\"Imprimir esta P�gina\"> Imprimir esta P�gina</a> |
</td></tr></table>";

}

	fecha_conexao_db();

?>
