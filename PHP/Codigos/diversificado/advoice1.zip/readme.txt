
About AdVoice 1.0
- - - - - - - - - - - - - - - - -

AdVoice is a simple, PHP-based banner ROTATION program. We emphasize rotation, because
we're talking actual rotation. There is absolutely nothing random about AdVoice's banner
selection. It always goes to the next banner in the rotation. It features a farily simple, clean
interface for developers looking for an easy way to rotate banners. It doesn't yet have features
to count displays, nor does it have statistics. But it'd be a great program for a small web
site to give its advertisers a fair, easy solution for their needs.

AdVoice must be included into a PHP document. It can't run through the <IMG> tag. That feature
will be added as soon as possible. 'iframe_example.html' is an example of how to use "Inline Frames"
to use AdVoice in any HTML document on any server.

Installing AdVoice 1.0
- - - - - - - - - - - - - - - - -

You need to open 'ads.php' and set the $pathtofiles directory to the full UNIX path to your
'next.tdb' and 'ads.conf' files. That allows AdVoice to have full read/write permissions on
these files.

Upload 'ads.php', 'show_ad.php', 'admin.php', 'next.tdb', 'ads.conf', and 'iframe_example.html'
to a directory (such as /ads) on your server. CHMOD the '__.php' files 755, and the following
777; the /ads directory (or wherever you're installing AdVoice), 'next.tdb', and 'ads.conf'.

'show_ad.php' is an example of how to include AdVoice into any PHP document. It's also
used with the inline frame example to display the ads program in any HTML document.

AdVoice 1.0 Admin
- - - - - - - - - - - - - - - - -

To run the admin program, open it in your favorite browser.

Currently the admin program can only add banners to the rotation. Enter the URL
to the image in the appropriate text box, and the URL to link the banner to in
the other box. Submit the form. If configured properly, AdVoice will give you a
confirmation message and display the banner you have added.

Using AdVoice 1.0
- - - - - - - - - - - - - - - - -

Put the following code into any PHP document:

<? include("/ads/ads.php"); ?>

Change the path to 'ads.php' if you need to. Or insert the <IFRAME> tag into any
HTML document as shown in 'iframe_example.html' and open the document in your
browser to see if it worked.

Support
- - - - - - - - - - - - - - - - -

You can e-mail 'downloads@yoai.org' for help regarding AdVoice 1.0 or any other
script written by us. If you need a script installed, let us know. We'll set it up on
your server for free.