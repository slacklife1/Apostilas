<?
# AdVoice 1.0 - freedom through great ads
# �2001 YOA/LSYF/YoAi
###

# Just one variable to edit
$pathtofiles = "/www/you/ads"; # don't add the trailing slash (ex. /www/you/ads/) or AdVoice will crash


$pics = file("$pathtofiles/ads.conf");

$max = count($pics);
$next = file("$pathtofiles/next.tdb");
$n = $next[0];

/*
   Ads.conf LOOKS LIKE THIS:

   `1`www.tomssite.com/images/image.gif~www.tomssite.com~1000`1`
   `2`www.cadoo.com/gfx/image.jpg~www.cadoo.com~1000`2`

*/

$pics_j = join($pics,"");
$s = "`" . $n . "`";
$show = split($s,$pics_j);

if(!strstr($pics_j,"`" . ++$n . "`")) {
$n = 1;
}

$fp = fopen("$pathtofiles/next.tdb","w");
fwrite($fp, $n);
fclose($fp);

$output = split("~",$show[1]);
$image = $output[0];
$url = $output[1];
print "<A HREF=\"$url\"><IMG SRC=\"$image\" WIDTH=400 HEIGHT=40 BORDER=0 ALT=\"Please visit our advertisers\"></A>";

?>