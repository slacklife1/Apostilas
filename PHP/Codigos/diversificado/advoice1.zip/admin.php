<?
# AdVoice 1.0 - freedom through great ads
# �2001 YOA/LSYF/YoAi
# Banner Admin
###

# No editing needed, just make sure that you put this program in the same directory
# as the other AdVoice files (such as 'ads.conf')

$url = $HTTP_GET_VARS["a"];
$img = $HTTP_GET_VARS["img"];
$adlist = file("ads.conf");
$count = count($adlist);
$count = ++$count;
if($HTTP_GET_VARS["add"] == "1") {
$fp = fopen("ads.conf","append");
fwrite($fp, "`$count`$img~$url`$count`\n");
fclose($fp);
}
?>
<html><head><title>Ads</title></head>
<body>
<h2>Ads Database Admin</h2>
<form action="<? echo $PHP_SELF ?>" method="get">
<input type="hidden" name="add" value="1">
<b>Image</b><br>
<input type="text" size=30 name="img"><p>
<b>URL</b><br>
<input type="text" size=30 name="a">
<input type="submit" name="sub" value="Submit">
</form><p>
<?
if($add == "1") {
echo "<center><h4><i>The following banner was added to the database:</i></h4>";
echo "<A HREF=\"$url\"><IMG SRC=\"$img\" WIDTH=400 HEIGHT=40 ALT=\"Item added\" BORDER=0></A></center>";
}
?>
</body></html>