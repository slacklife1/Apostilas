<?
 // Visitor's Chat Setup
  print "<HTML><META HTTP-EQUIV=\"refresh\" CONTENT=\"10; URL=msg.php\">\n";
  @include('livechat.txt');
  print "</HTML>";
?>