<HTML>
<TITLE> <?php $name=file_get_contents("chatname.txt"); echo $name; ?> | Powered by zChat 1.1 </TITLE>
<FRAMESET ROWS="25%,43%,32%">
<FRAME SRC="logo.html">
<FRAMESET COLS="85%,15%">
 <FRAME SRC="msg.php">
 <FRAME SRC="online.php">
</FRAMESET>
<FRAME SRC="chat.php">
</FRAMESET>
</HTML>