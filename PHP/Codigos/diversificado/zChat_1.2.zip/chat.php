<?
 // Chat Display
  if (!isset($_POST[name])) {
   print "<body onload=\"document.chatForm.name.focus();\">";
   print "<FORM ACTION=\"chat.php\" METHOD=\"POST\" NAME=\"chatForm\">";
   print "<B>UserName:</B> <INPUT TYPE=\"text\" NAME=\"name\" MAXLENGTH=50><br>";
  }
  else {
   print "<body onload=\"document.chatForm.chat.focus();\">";
   print "<FORM ACTION=\"chat.php\" METHOD=\"POST\" NAME=\"chatForm\">";
   if ($_POST[name]=="") {
    $_POST[name]="Anonymous User";
   }
   print "<B>UserName:</B> $name<br><INPUT TYPE=\"hidden\" NAME=\"name\" VALUE=\"$name\">";
   $fp=fopen("./userlog.txt",'a');
   $fs="Username: $name\nIP: $_SERVER[REMOTE_ADDR]\nISP: $_SERVER[REMOTE_HOST]\nUser Agent: $_SERVER[HTTP_USER_AGENT]\nMessage: $chat";
   fputs($fp,$fs);
   fclose($fp);
   $fp = fopen($_POST['name'] . '.usr','w');
   fputs($fp,'');
   fclose($fp);
  }
  print "<B>Message:</B> <INPUT TYPE=\"text\" NAME=\"chat\" MAXLENGTH=250><br><INPUT TYPE=\"submit\" VALUE=\"Send Message!\">";
 if ($_POST[chat]!="") {
  $old=file_get_contents("livechat.txt");
  $fp=fopen("livechat.txt",'w');
  $colfnt = array ("[blue]","[black]","[green]","[red]","[gray]","[pink]","[orange]");
  $ccolfnt = array ("</FONT><FONT COLOR=\"blue\">","</FONT><FONT COLOR=\"black\">","</FONT><FONT COLOR=\"green\">","</FONT><FONT COLOR=\"red\">","</FONT><FONT COLOR=\"gray\">","</FONT><FONT COLOR=\"pink\">","</FONT><FONT COLOR=\"Orange\">");
  $uc = $_POST['chat'];
  $uc = strip_tags($uc,'<b><i><tt><u><del><a>');
  $uc = str_replace ( ":)", "<IMG SRC=\"smile.png\">", $uc );
  $uc = str_replace ( ":(", "<IMG SRC=\"sad.png\">", $uc );
  $uc = str_replace ( ";)", "<IMG SRC=\"wink.png\">", $uc );
  $uc = str_replace ( ":D", "<IMG SRC=\"lol.png\">", $uc );
  $uc = str_replace ( ":'(", "<IMG SRC=\"crying.png\">", $uc );
  $uc = str_replace ( ":?", "<IMG SRC=\"unsure.png\">", $uc );
  $uc = str_replace ( ":X", "<IMG SRC=\"sealed.png\">", $uc );
  $uc = str_replace ( "8)", "<IMG SRC=\"cool.png\">", $uc );
  $uc = str_replace ( ":P", "<IMG SRC=\"tongue.png\">", $uc );
  $uc = str_replace ( $colfnt, $ccolfnt, $uc );
  $uc = $uc . "</FONT>";
  $_POST[name] = strip_tags($_POST[name]);
  $tw="$_POST[name] :: $uc<br> \n \n$old";
  $ttw=stripslashes($tw);
  fputs($fp,$ttw);
  fclose($fp);
  unset($chat);
 }
 print "<br><br><hr><br><CENTER><A HREF=\"http://piranhaweb.xgt.us\" TARGET=\"_blank\"><IMG SRC=\"copyright.gif\" BORDER=0></A></CENTER></BODY>";
?>