<?
 print "<HTML><META HTTP-EQUIV=\"refresh\" CONTENT=\"10; URL=online.php\">\n";
 echo "<B>Members Online:</B><br />";
 $fns = glob('*.usr');
 foreach($fns as $todel) {
  $Diff = (time() - filemtime($todel))/60;
  if ($Diff > 5) {
   unlink($todel);
  }
 }
 $fns = glob('*.usr');
 foreach($fns as $ntp) {
  $ntp = str_replace('.usr','',$ntp);
  echo $ntp . '<br>';
 }
 print "</HTML>";
?>