<?php
/*
 * Copyright (c) 2002, Ted Shieh (http://www.liquidmarkets.com/m.php?m=contact)
 * All rights reserved
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 *   this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

 ## @author <a href="http://www.liquidmarkets.com/m.php?m=contact">Ted Shieh</a>
 ## Utility functions

/**
 * Example:
 * cmd('ls'); # UNIX
 * cmd('dir'); # Windows
 */

function cmd($cmd) {
  print "$cmd\n";
  $out = `$cmd`;
  print "output:<br>\n $out<br>\n";
}

/**
 * Example:
 * $dir = '/dev/php/phpsqlgen';
 * $phpsqlgen_dir = current_dir($dir);
 */
function current_dir($dir) {
  $dir = rtrim($dir, '/\\'); # PHP >= 4.1.0 
  if (preg_match('#/#', $dir)) {
    $separator = '/';
  } else {
    $separator = '\\';
  }
  $tokens = explode($separator, $dir);
  $current_dir = array_pop($tokens);
  return $current_dir;
}

/**
 * Example:
 * debug(__FILE__,__LINE__,"submit: $submit");
 */
function debug($file,$line,$message) {
  $datetime = date("Y-m-d H:i:s", time());
  print "$datetime $file:$line $message<br>\n";
}

/**
 * Example:
 * debug_var(__FILE__,__LINE__,'submit');
 */
function debug_var($file,$line,$var) {
  global $$var;
  $value = $$var;
  $datetime = date("Y-m-d H:i:s", time());
  if (is_scalar($value)) {
    print "$datetime $file:$line $var: $value<br>\n";
  } else {
    print "$datetime $file:$line $var:\n<pre>\n";
    print_r($value);
    print "</pre><br>\n";
  }
}

/**
 * Example:
 * $separator = get_separator();
 * ini_set('include_path', ".$separator$web_dir/pear");
 */
function get_separator() {
  if (substr(php_uname(), 0, 7) == "Windows") {
    return ';';
  }
  return ':';
}

/**
 * Example:
 * $web_dir = getenv('DOCUMENT_ROOT');
 * $base_dir = parent_dir($web_dir);
 */
function parent_dir($dir) {
  $dir = rtrim($dir, '/\\'); # PHP >= 4.1.0 
  if (preg_match('#/#', $dir)) {
    $separator = '/';
  } else {
    $separator = '\\';
  }
  $tokens = explode($separator, $dir);
  array_pop($tokens);
  $parent_dir = implode('/', $tokens);
  return $parent_dir;
}

/**
 * Example:
 * print_r_web($array);
 */
function print_r_web($var) {
  print '<pre>';
  print_r($var);
  print '</pre>';
}
?>
