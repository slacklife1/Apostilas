<?php
/*
 * Copyright (c) 2002, Ted Shieh (http://www.liquidmarkets.com/m.php?m=contact)
 * All rights reserved
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 *   this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

 ## @author <a href="http://www.liquidmarkets.com/m.php?m=contact">Ted Shieh</a>
 ## Provides functions for generating SQL statements from arrays.  Currently, 
 ## only the most basic SQL queries are handled.  While "select URL, username 
 ## from pageview where to_days(datetime) = to_days(curdate())" is handled, 
 ## "select distinct username from pageview" is not.

class SQLGen {

  /**
   * @returns string
   * Example:
   * $table = 'pageview';
   * $record['URI'] = 'http://www.liquidmarkets.com';
   * $record['username'] = 'tedshieh';
   * $db_funcs['datetime'] = 'now()';
   * $sql = SQLGen::gen_insert($table,$record,$db_funcs);
   */
  function gen_insert($table,$variables,$db_functions = array()) {
    $query_string = '';
    $first = true;
    if ($table and $variables) {
      $query_string = "insert into $table (";
      foreach ($variables as $column => $value) {
        if ($first) {
          $prefix = '';
          $first = false;
        } else {
          $prefix = ', ';
        }
        $query_string .= "$prefix$column";
      }
      if ($db_functions) {
        foreach ($db_functions as $column => $value) {
          if ($first) {
            $prefix = '';
            $first = false;
          } else {
            $prefix = ', ';
          }
          $query_string .= "$prefix$column";
        }
      }
      $query_string .= ') values (';
      $first = true;
      foreach ($variables as $column => $value) {
        if ($first) {
          $prefix = '';
          $first = false;
        } else {
          $prefix = ', ';
        }
        if (is_numeric($value)) {
          $db_value = $value;
        } else {
          $db_value = "'$value'";
        }
        $query_string .= "$prefix$db_value";
      }
      foreach ($db_functions as $column => $value) {
        if ($first) {
          $prefix = '';
          $first = false;
        } else {
          $prefix = ', ';
        }
        $query_string .= "$prefix$value";
      }
      $query_string .= ')';
      return $query_string;
    }
    return false;
  }

  /**
   * @returns string
   * Example:
   * $query['pageview'] = array('URL','username');
   * $options['where'] = array("username = 'tedshieh'");
   * if ($filter_by_date) {
   *   array_push($options['where'], 'to_days(datetime) = to_days(curdate())';
   * }
   * $sql = SQLGen::gen_select($query, $options);
   */
  function gen_select($query, $options = array()) {
    $query_string = 'select ';
    $first = true;
    foreach ($query as $table => $columns) {
      foreach ($columns as $column) {
        if ($first) {
          $query_string .= "$table.$column";
          $first = false;
        } else {
          $query_string .= ", $table.$column";
        }
      }
    }
    if (is_array($options['as'])) {
      foreach ($options['as'] as $name => $value) {
        if ($first) {
          $query_string .= "$value as $name";
          $first = false;
        } else {
          $query_string .= ", $value as $name";
        }
      }
    }
    $query_string .= " from ";
    if ($options['special_from']) {
      $query_string .= $options['special_from'];
    } else {
      $first = true;
      foreach ($query as $table => $columns) {
        if ($first) {
          $query_string .= "$table";
          $first = false;
        } else {
          $query_string .= ", $table";
        }
      }
    }
    $query_string = SQLGen::gen_where_etc($query_string,$options);
    return $query_string;
  }

  /**
   * Example:
   * @returns string
   * $table = 'pageview';
   * $record['URI'] = 'http://www.liquidmarkets.com';
   * $db_funcs['datetime'] = 'now()';
   * $query['pageview'] = array('URL','username');
   * $options['where'] = array("username = 'tedshieh'");
   * if ($filter_by_date) {
   *   array_push($options['where'], 'to_days(datetime) = to_day(curdate())';
   * }
   * $sql = SQLGen::gen_update($table, $record, $options, $db_funcs);
   */
  function gen_update($table,$variables,$options = array(),$db_functions = array()) {
    $query_string = '';
    $first = true;
    if ($table and $variables) {
      $query_string = "update $table set ";
      foreach ($variables as $column => $value) {
        if ($first) {
          $prefix = '';
          $first = false;
        } else {
          $prefix = ', ';
        }
        if (is_numeric($value)) {
          $db_value = $value;
        } else {
          $db_value = "'$value'";
        }
        $query_string .= "$prefix$column=$db_value ";
      }
      if ($db_functions) {
        foreach ($db_functions as $column => $value) {
          if ($first) {
            $prefix = '';
            $first = false;
          } else {
            $prefix = ', ';
          }
          $query_string .= "$prefix$column=$value ";
        }
      }
      $query_string = SQLGen::gen_where_etc($query_string,$options);
      return $query_string;
    }
    return false;
  }

  /**
   * For internal use only
   */
  function gen_where_etc($query_string,$options) {
    $first = true;
    if ($options['where']) {
      $query_string .= ' where ';
      foreach ($options['where'] as $fragment) {
        if ($first) {
          $prefix = '';
          $first = false;
        } else {
          $prefix = ' and ';
        }
        $query_string .= "$prefix$fragment";
      }
    }
    $query_string .= " {$options['etc']}";
    return $query_string;
  }
}
?>
