<?php
/*
 * TableMaker
 *
 * Copyright (c) 2002, Ted Shieh (http://www.liquidmarkets.com/m.php?m=contact)
 * All rights reserved
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 *   this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

 ## @author <a href="http://www.liquidmarkets.com/m.php?m=contact">Ted Shieh</a>
 ## Create an HTML table given an ADODB database result set or an array

class TableMaker {
  var $table_style;
  var $row1style;
  var $row2style;
  var $header_style;

  /**
   * @returns void
   * Constructor
   * Example:
   * $tm = new TableMaker();
   */
  function TableMaker($display_options = array()) {
    if (empty($display_options['table_style'])) {
      $this->table_style = "bgcolor=#FFFFFF border=1 width=500 cellpadding=0 cellspacing=0 ";
    } else {
      $this->table_style = $display_options['table_style'];
    }
    if (empty($display_options['header_style'])) {
      $this->header_style = "bgcolor=#E4E4E4 nowrap";
    } else {
      $this->header_style = $display_options['header_style'];
    }
    if (empty($display_options['row1style'])) {
      $this->row1style = array('bgcolor'=>'#E4E4E4', 'align'=>'left');
    } else {
      $this->row1style = $display_option['row1style'];
    }
    if (empty($display_options['row2style'])) {
      $this->row2style = array('bgcolor'=>'#f1f1f1', 'align'=>'left');
    } else {
      $this->row2style = $display_option['row2style'];
    }
  }

  /**
   * @returns void
   * Example:
   *
   * $tm = new TableMaker();
   * $display = array('URL');
   * $tm->display('adodb', $rs, $display); # $rs is an ADODB database result set 
   * $URLs = array(
   *   0=>array(
   *     'URL'=>
   *       '<a href="http://www.liquidmarkets.com">http://www.liquidmarkets.com</a>'),
   *   1=>array(
   *     'URL'=>
   *       '<a href="http://www.liquidmarkets.com/m.php?m=wish">http://www.liquidmarkets.com/m.php?m=wish</a>'
   *   )
   * );
   * $tm->display('array', $URLs, $display);
   */
  function display($type, $data, $display, $display_options = array()) {
    if (empty($display_options['table_style'])) {
      $table_style = $this->table_style;
    } else {
      $table_style = $display_options['table_style'];
    }
    if (empty($display_options['header_style'])) {
      $header_style = $this->header_style;
    } else {
      $header_style = $display_options['header_style'];
    }
    if (empty($display_options['row1style'])) {
      $row1style = $this->row1style;
    } else {
      $row1style = $display_option['row1style'];
    }
    if (empty($display_options['row2style'])) {
      $row2style = $this->row2style;
    } else {
      $row2style = $display_option['row2style'];
    }
    $col_headers = array_values($display);
    $table = new HTML_Table($table_style);
    $table->addRow($col_headers, $header_style, "TH");
    $keys = array_keys($display);
    if (is_int($keys[0])) {
      $keys = $col_headers;
    }
    if ($type == 'adodb') {
      while (!$data->EOF) {
        foreach ($keys as $key) {
          $row[$key] = nl2br($data->fields[$key]);
        }
        $row_display = array_values($row);
        for ($i=0;$i<count($row_display);$i++) {
          $row_display[$i] = stripSlashes($row_display[$i]);
        }
        $table->addRow($row_display);
        $data->MoveNext();
      }
    } else if ($type == 'array') {
      foreach ($data as $data_row) {
        foreach ($data_row as $data_key => $data_value) {
          foreach ($keys as $key) {
            if ($key == $data_key) {
              $row[$key] = nl2br($data_value);
            }
          }
        }
        $row_display = array_values($row);
        for ($i=0;$i<count($row_display);$i++) {
          $row_display[$i] = stripSlashes($row_display[$i]);
        }
        $table->addRow($row_display);
      }
    }  else {
      die("Invalid type $type used in TableMaker->display()");
    }
    $table->altRowAttributes(1,$row1style,$row2style);
    $table->display();
  }

  /**
   * @returns void
   * Example:
   *
   * $tm = new TableMaker();
   * $tm->set_display_options(
   *   array(
   *     'table_style'=>'bgcolor=#FFFFFF border=1 width=500 cellpadding=0 cellspacing=0', 
   *     'header_style'=>'bgcolor=#E4E4E4 nowrap'
   *   )
   * );
   */
  function set_display_options($display_options = array()) {
    if (empty($display_options['table_style'])) {
      $this->table_style = "bgcolor=#FFFFFF border=1 width=500 cellpadding=0 cellspacing=0";
    } else {
      $this->table_style = $display_options['table_style'];
    }
    if (empty($display_options['header_style'])) {
      $this->header_style = "bgcolor=#E4E4E4 nowrap";
    } else {
      $this->header_style = $display_options['header_style'];
    }
    if (empty($display_options['row1style'])) {
      $this->row1style = array('bgcolor'=>'#E4E4E4', 'align'=>'left');
    } else {
      $this->row1style = $display_option['row1style'];
    }
    if (empty($display_options['row2style'])) {
      $this->row2style = array('bgcolor'=>'#f1f1f1', 'align'=>'left');
    } else {
      $this->row2style = $display_option['row2style'];
    }
  }
}
?>
