<?php

// This is the page where you will put your free for fall links on. This is a URL!
$viewpage = "view.php";

// The directory to where you will upload your images. DO NOT END WITH TRAILING SLASH!
$imagedir = "/images"

?>