<br>
<center>
Link List Version 1.5
<br>
By Russell F.
<br>
For more scripts, go to <a href="http://www.dynamicfx.net">dynamicfx.net</a>.
</center>
</head>
</html>