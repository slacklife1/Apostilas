<?php
require "variables.php";
if ($wsname == "") {
echo "You must fill out a site name.";
exit;
} 
else
if ($wsurl == "") {
echo "You must fill out a site URL.";
exit;
}
else
if ($description == "") {
echo "You must put a description.";
exit;
}
else
$textfile = ("links.txt");
$fp = fopen($textfile, "a+");
fputs ($fp, "<center><table><tr><td bgcolor=dcdcdc width=400 height=20><font size=2><img src=$imagedir/browser.gif> <a href=http://$wsurl target=_blank>$wsname</a></td></tr><tr><td bgcolor=cccccc width=400><font size=2>$description</td></tr></table></center><br><br>\n");
fclose($fp);
echo "Your site has been successfully added. <a href=$viewpage>Click here</a> to view the Link List page.";
?>