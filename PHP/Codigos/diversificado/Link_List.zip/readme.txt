#######################################
#
#
#    Link List Version 1.5
#    Coded by Russell F.
#    For more scripts go to
#    http://www.dynamicfx.net.
#
#
#######################################

#######################################
#  INSTALLATION
#######################################

1) Make sure the information in variables.php is correct. You should have to change anything as long as view.php is in the same directory as all the other files.

2) Upload linklist.php, footer.php, header.php, submit.php, variables.php, view.php and links.txt in ASCII mode to the directory /linklist. Then, upload browser.gif to the directory /images in BINARY mode. If you upload any of the files to any other directory, you may need to edit variables.php.

3) CHMOD links.txt 777.

3) Your done, to view your Link List page, go to www.yourdomain.com/linklist/view.php. To add a link, go to www.yourdomain.com/linklist/submit.php.


If you have any questions, feel free to email me at russell@dynamicfx.net.

