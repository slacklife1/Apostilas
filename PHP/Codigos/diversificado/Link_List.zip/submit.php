<html>
<head>
<title>Link List 1.0</title>
<body bgcolor="#003366">
<font color="#FFFFFF" size="1" face="verdana">
<table align="center">
<tr>
<td valign="top">
<FORM METHOD="POST" ACTION="linklist.php">
<font color="#FFFFFF" size="2" face="verdana">
<b>Website Name:</b>
</td>
<td valign="top">
<INPUT TYPE="text" NAME="wsname" SIZE="30">
</td>
</tr>
<tr>
<td valign="top">
<font color="#FFFFFF" size="2" face="verdana">
<b>Website URL:</b> 
</td>
<td>
<font color="#FFFFFF" size="2" face="verdana">http://<INPUT TYPE="text" NAME="wsurl" SIZE="24">
</td>
</tr>
<tr>
<td valign="top">
<font color="#FFFFFF" size="2" face="verdana">
<b>Description:</b>
</td>
<td>
<textarea name="description" cols="26"></textarea>
</td>
</tr>
<tr>
<td colspan="2">
<br>
<p align="right"><INPUT TYPE="submit" value="Submit!"></form></p>
</td>
</tr>
</table>
<br>
<center>
Link List Version 1.5
<br>
By Russell F.
<br>
For more scripts, go to <a href="http://www.dynamicfx.net">dynamicfx.net</a>.
</center>
</head>
</html>