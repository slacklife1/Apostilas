Title: Link List v 1.5
Description: It is a script that allows visitors to add their website link with a description to a page. The code writes information to a textfile, and then views the textfile backwards putting the newest link at the top.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=553&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
