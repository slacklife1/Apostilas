<html>
<head>
<title>
PHPMailList
</title>
<style>
<!--
body { background-color: white; color: black; font-family: arial;}
a:link { color: blue; text-decoration: none; }
a:active { color: red; text-decoration: underline; }
a:hover { color: red; text-decoration: underline; }
a:visited { color: purple; text-decoration: none }
-->
</style>
</head>
<body>
<!-- PHPMail List: http://php.warpedweb.net/ -->
<?php
/////////////////////////////////////////////////////
//                                                 //
//                  PHPMailList                    //
//                 Version 1.8.0                   //
//                                                 //
//                 Copyright 2002                  //
//                  David Broker                   //
//           http://php.warpedweb.net/             //
//              All Rights Reserved                //
//                                                 //
//          In using this script you               //
//           agree to the following:               //
//                                                 //
//      This script may be used and modified       //
//              freely as long as this             //
//             copyright remains intact.           //
//                                                 //
//     You may not distibute this script, or       //
//           any modifications of it.              //
//                                                 //
//   A link must be provided on the website that   //
//             uses the script to:                 //
//          http://php.warpedweb.net/              //
//                                                 //
//      Any breaches of these conditions           //
//        will result in legal action.             //
//                                                 //
//      This script is distributed with            //
//        no warrenty, free of charge.             //
//                                                 //
/////////////////////////////////////////////////////

// The full server path to the configuration file.

$config_file = "c:\\path\\to\\ml_config.dat";

/*********************************************\
* NOTHING BELOW THIS POINT NEEDS TO BE EDITED *
\*********************************************/

// Sets the keywork to access admin. IE: action=?keyword.

$admin_keyword = "admin";

// Sets the version number.

$version = "1.8.0a";

// Reads the config file.

$config = @file($config_file) or die("<center><b>Could not open configuration file.</b></center>");

// Sets the variables from the config file.

$user = trim($config[0]);
$pass = trim($config[1]);
$list_name = trim($config[2]);
$list_file = trim($config[3]);
$owner_email = trim($config[4]);
$send_confirm = trim($config[5]);
$confirm_subject = trim($config[6]);
$send_welcome = trim($config[7]);
$welcome_subject = trim($config[8]);
$send_goodbye = trim($config[9]);
$goodbye_subject = trim($config[10]);
$default_per_page = trim($config[11]);
$confirm_msg = get_data($config, "confirm");
$welcome_msg = get_data($config, "welcome");
$goodbye_msg = get_data($config, "goodbye");
$sig = get_data($config, "sig");
$banned_addresses = get_data($config, "banned");

// If statements to determine the action.

if ($action == $admin_keyword)   admin();
elseif ($action == "sub")        subscribe(trim($email), $send_confirm, $send_welcome);
elseif ($action == "confirm")    confirm($email, $conf);
elseif ($action == "unsub")      unsubscribe(trim($email));
else                             print_subscribe_form();

print_footer();

function admin() {
 // Controls the administration options.
 global $q, $username, $password, $user, $pass;
 if (($user == $username) && ($pass == $password)) {
  if ($q == "send_msg")              admin_send_msg();
  elseif ($q == "send_msg_confirm")  admin_send_msg_confirm();
  elseif ($q == "write_msg")         admin_write_msg();
  elseif ($q == "view_subs")         admin_view_subs();
  elseif ($q == "config")            admin_config();
  elseif ($q == "add_remove")        admin_add_remove();
  admin_print_options(); 
 }
 else {
  if (($username == "") && ($password == "")) admin_print_logon("");
  else admin_print_logon("Invalid username and/or password.");
 }
}

function subscribe($email, $send_confirm, $send_welcome) {
 // Subscribes address to list.
 global $list_name;
 if ($email == "") {
   print_subscribe_form();
 }
 else {
  if (!banned($email)) {
   if (!on_list($email)) {
    if (valid_email($email)) {
     if ($send_confirm == "on") { 
      send_confirm($email);
      echo "<h4 align=\"center\">Thank you for subscribing to \"$list_name\".</h4><center>An email will be sent to \"$email\" asking you to confirm your subscription.<br>Please follow those instructions to complete the process.</center>";
     }
     else { 
      if (add_to_list($email)) {
       echo "<h4 align=\"center\">The email address: \"$email\" has been subscribed to \"$list_name\".</h4>";
       if ($send_welcome == "on") { 
        send_welcome($email);
        echo "<br><center>A welcome message will be emailed to you confirming this.</center>";
       }
      }
     }
    }
    else echo "<h4 align=\"center\">The email address: \"$email\" does not appear to be valid.</h4>";
   }
   else echo "<h4 align=\"center\">The email address: \"$email\" is already subscribed to this list.</h4>";
  }
  else echo "<h4 align=\"center\">The email address: \"$email\" has been banned from \"$list_name\".</h4>";
 }
}

function unsubscribe($email) {
 // Removes email from list if it exists.
 global $list_file, $list_name, $send_goodbye;
 if ($email == "") {
  print_subscribe_form();
 }
 else {
  if (remove_from_list($email)) {
   echo "<center><b>The email address: \"$email\" has been removed from \"$list_name\".</b>";
   if ($send_goodbye == "on") { 
   send_goodbye($email);
   echo "<br>A email confirming this will be sent to \"$email\".";
   }
   echo "</center>";
  }
  else    echo "<center><b>The email address: \"$email\" is not subscribed to \"$list_name\".</b>";
 }
}

function confirm($email, $conf) {
 $check_code = substr(strrev(md5($email).strtolower(soundex(email))),0,5);
 if ($conf == $check_code) {
  subscribe($email, "off", $GLOBALS['send_welcome']);
 }
 else {
  echo "<h4 align=\"center\">Your confirmation was not approved, an invalid code was specifed.</h4>";
 }
}

function remove_from_list($email) {
 // Removes the address from the file.
 global $list_file;
 $file = @file($list_file);
 $success = false;
 $fd = @fopen($list_file, "w") or die("<center><b>The list data file could not be opened for writing.</b></center>");
 if ($file) {
  foreach($file as $address) {
   $address = trim($address);
   if ($address != $email) fputs($fd, "$address\n");
   else $success = true;
  }
  fclose($fd); 
 }
 return $success;
}

function add_to_list($email) {
 // Adds the email address to the data file.
 global $list_file;
 $fd = @fopen($list_file, "a") or die("<center><b>The list data file could not be opened.</b><br>Check the path and permissions.</center>");
 fputs($fd, strtolower($email)."\n");
 fclose($fd);
 return true;
}

function get_data($array, $keyword) {
 // Reads the message from the text file inbetween <$keyword> & </$keyword>
 foreach ($array as $i => $line) {
  if (trim($line) == "<$keyword>") {
   $i++;
   break;
  }
 }
 $array[$i] = trim($array[$i]);
 while ($array[$i] != "</$keyword>") {
  $tmp = stripslashes($array[$i]);
  $msg .= "\n$tmp";
  $i++;
  $array[$i] = trim($array[$i]);
 }
 return $msg;
}

function valid_email($email) {
 // Returns true if email address has a valid form.
 $pattern = "^[-_.[:alnum:]]+@((([[:alnum:]]|[[:alnum:]][[:alnum:]-]*[[:alnum:]])\.)+(ad|ae|aero|af|ag|ai|al|am|an|ao|aq|ar|arpa|as|at|au|aw|az|ba|bb|bd|be|bf|bg|bh|bi|biz|bj|bm|bn|bo|br|bs|bt|bv|bw|by|bz|ca|cc|cd|cf|cg|ch|ci|ck|cl|cm|cn|co|com|coop|cr|cs|cu|cv|cx|cy|cz|de|dj|dk|dm|do|dz|ec|edu|ee|eg|eh|er|es|et|eu|fi|fj|fk|fm|fo|fr|ga|gb|gd|ge|gf|gh|gi|gl|gm|gn|gov|gp|gq|gr|gs|gt|gu|gw|gy|hk|hm|hn|hr|ht|hu|id|ie|il|in|info|int|io|iq|ir|is|it|jm|jo|jp|ke|kg|kh|ki|km|kn|kp|kr|kw|ky|kz|la|lb|lc|li|lk|lr|ls|lt|lu|lv|ly|ma|mc|md|mg|mh|mil|mk|ml|mm|mn|mo|mp|mq|mr|ms|mt|mu|museum|mv|mw|mx|my|mz|na|name|nc|ne|net|nf|ng|ni|nl|no|np|nr|nt|nu|nz|om|org|pa|pe|pf|pg|ph|pk|pl|pm|pn|pr|pro|ps|pt|pw|py|qa|re|ro|ru|rw|sa|sb|sc|sd|se|sg|sh|si|sj|sk|sl|sm|sn|so|sr|st|su|sv|sy|sz|tc|td|tf|tg|th|tj|tk|tm|tn|to|tp|tr|tt|tv|tw|tz|ua|ug|uk|um|us|uy|uz|va|vc|ve|vg|vi|vn|vu|wf|ws|ye|yt|yu|za|zm|zw)|(([0-9][0-9]?|[0-1][0-9][0-9]|[2][0-4][0-9]|[2][5][0-5])\.){3}([0-9][0-9]?|[0-1][0-9][0-9]|[2][0-4][0-9]|[2][5][0-5]))$"; 
 if(eregi($pattern, $email)) return true;
 else  return false; 
}

function on_list($email) {
 // Returns true if email address is on list.
 global $list_file;
 $found = false;
 $file = @file($list_file);
 if ($file) {
  foreach ($file as $address) {
   if (trim($address) == trim($email)) {
    $found = true;
   }
  }
 }
 return $found; 
}

function banned($email) {
 // Returns true if email is banned from subscribing.
 global $banned_addresses;
 $banned = false;
 $addresses = explode("\n", $banned_addresses);
 foreach ($addresses as $add) {
  if ($email == $add) {
   $banned = true;
   break;
  }
 }
 return $banned;
}

function send_welcome($email) {
 // Send confirmation letter to new subscriber.
 global $welcome_msg, $welcome_subject, $list_name, $owner_email, $sig, $version;
 $welcome_subject = replace_shortcuts($welcome_subject, $email);
 $headers = "From: \"$list_name\" <$owner_email>\r\nReply-To: $owner_email\r\nX-Mailer: PHPMailList V$version http://php.warpedweb.net/\r\n";
 $welcome_msg .= "\n\n$sig";
 $welcome_msg = replace_shortcuts($welcome_msg, $email);
 ini_set("sendmail_from", $owner_email);
 mail($email, $welcome_subject, $welcome_msg, $headers);
}

function send_confirm($email) {
 // Send message asking for confirmation.
 global $confirm_msg, $confirm_subject, $list_name, $owner_email, $version;
 $confirm_subject = replace_shortcuts($confirm_subject, $email);
 $headers = "From: \"$list_name\" <$owner_email>\r\nReply-To: $owner_email\r\nX-Mailer: PHPMailList V$version http://php.warpedweb.net/\r\n";
 $confirm_msg = replace_shortcuts($confirm_msg, $email).$GLOBALS[sig];
 mail($email, $confirm_subject, $confirm_msg, $headers);
}

function send_goodbye($email) {
 // Send goodbye message to unsubscriber.
 global $goodbye_msg, $goodbye_subject, $list_name, $owner_email, $version;
 $goodbye_subject = replace_shortcuts($goodbye_subject, $email);
 $headers = "From: \"$list_name\" <$owner_email>\r\nReply-To: $owner_email\r\nX-Mailer: PHPMailList V$version http://php.warpedweb.net/\r\n";
 $goodbye_msg = replace_shortcuts($goodbye_msg, $email).$GLOBALS[sig];
 mail($email, $goodbye_subject, $goodbye_msg, $headers);
}

function replace_shortcuts($msg, $email) {
 // Replaces the shortcuts used in when sending emails.
 global $list_name, $HTTP_HOST, $SCRIPT_NAME;
 $conf_code = substr(strrev(md5($email).strtolower(soundex(email))),0,5);
 $msg = str_replace("%list_name%", $list_name, $msg);
 $msg = str_replace("%email%", $email, $msg);
 $msg = str_replace("%confirm_url%", "http://$HTTP_HOST$SCRIPT_NAME?action=confirm&email=$email&conf=$conf_code", $msg);
 $msg = str_replace("%subscribe_url%", "http://$HTTP_HOST$SCRIPT_NAME?action=sub&email=$email", $msg);
 $msg = str_replace("%unsubscribe_url%", "http://$HTTP_HOST$SCRIPT_NAME?action=unsub&email=$email", $msg);
 return $msg;
}

function admin_write_msg() {
 // Prints the form to send a message.
 global $username, $password, $owner_email, $list_name, $admin_keyword;
echo "
<form method=\"post\">
<input type=\"hidden\" name=\"username\" value=\"$username\">
<input type=\"hidden\" name=\"password\" value=\"$password\">
<input type=\"hidden\" name=\"action\" value=\"$admin_keyword\">
<input type=\"hidden\" name=\"q\" value=\"send_msg_confirm\">
<table align=\"center\" border=\"0\">
<tr><td colspan=\"2\" align=\"center\" valign=\"top\"><font size=\"+1\"><b>Send A Message:</b><br>&nbsp;</td></tr>
<tr><td align=\"left\" valign=\"top\"><b>From: </b></td><td align=\"left\" valign=\"top\">\"$list_name\" &lt;$owner_email&gt;</td></tr>
<tr><td align=\"left\" valign=\"top\"><b>Subject: </b></td><td align=\"left\" valign=\"top\"><input type=\"text\" name=\"subject\" size=\"35\"></td></tr>
<tr><td align=\"left\" valign=\"top\"><b>Message: </b></td><td align=\"left\" valign=\"top\"><textarea rows=\"15\" cols=\"65\" wrap=\"off\" name=\"message\"></textarea></td></tr>
<tr><td></td><td align=\"left\" valign=\"top\"><input type=\"checkbox\" checked name=\"use_sig\"><font size=\"-1\"><i>&nbsp;Append Signature</i></td></tr>
<tr><td></td><td align=\"left\" valign=\"top\"><input type=\"submit\" value=\"Send\">&nbsp;<input type=\"reset\" value=\"Clear\"></td></tr></table>
</form>";
}

function admin_send_msg_confirm() {
 // Confirms the message before sending.
 global $username, $password, $subject, $message, $owner_email, $list_name, $list_file, $admin_keyword, $use_sig;
 $subject = stripslashes($subject);
 $message = stripslashes($message);
echo "
<form method=\"post\">
<table align=\"center\" border=\"0\">
<tr><td colspan=\"2\" align=\"center\" valign=\"top\"><font size=\"+1\"><b>Please Confirm this is what you wish to send:</b><br>&nbsp;</td></tr>
<tr><td align=\"left\" valign=\"top\"><b>From: </b></td><td align=\"left\" valign=\"top\">\"$list_name\" &lt;$owner_email&gt;</td></tr>
<tr><td align=\"left\" valign=\"top\"><b>Subject: </b></td><td align=\"left\" valign=\"top\">$subject</td></tr>
<tr><td align=\"left\" valign=\"top\"><b>Message: </b></td><td align=\"left\" valign=\"top\"><pre>$message</pre></td></tr>";
 $subject = str_replace("\"", "%%", $subject);
 $message = str_replace("\"", "%%", $message);
echo"
<input type=\"hidden\" name=\"username\" value=\"$username\">
<input type=\"hidden\" name=\"password\" value=\"$password\">
<input type=\"hidden\" name=\"message\" value=\"$message\">
<input type=\"hidden\" name=\"subject\" value=\"$subject\">
<input type=\"hidden\" name=\"use_sig\" value=\"$use_sig\">
<input type=\"hidden\" name=\"action\" value=\"$admin_keyword\">
<input type=\"hidden\" name=\"q\" value=\"send_msg\">
<tr><td></td><td align=\"left\" valign=\"top\"><input type=\"submit\" value=\"Send\">&nbsp;<input type=\"reset\" value=\"Edit\" OnClick=\"history.go(-1); return true;\"></td></tr></table>
</form>";
}

function admin_send_msg() {
 // Sends the message to all subscribers on the list.
 global $list_name, $list_file, $owner_email;
  set_time_limit(0);
 $subject = stripslashes($GLOBALS[subject]);
 $message = stripslashes($GLOBALS[message]);
 $subject = str_replace("%%", "\"", $subject);
 $message = str_replace("%%", "\"", $message);

 $headers = "From: \"$list_name\" <$owner_email>\r\nReply-To: $owner_email\r\nX-Sender: $owner_email\r\nX-UnsubscribeURL: http://$GLOBALS[HTTP_HOST]$GLOBALS[SCRIPT_NAME]\r\nX-Mailer: PHPMailList V$GLOBALS[version] http://php.warpedweb.net/\r\nX-AntiSpam: PHPMailList did not send you this email, review below for sender info.\r\nX-AntiSpam: Sent by $GLOBALS[REMOTE_ADDR]\r\n";

 if ($GLOBALS[SERVER_ADMIN]) $headers .= "X-AntiSpam: Server Administrator $GLOBALS[SERVER_ADMIN]\r\n"; 

 if ($GLOBALS['use_sig'] == "on") $message .= $GLOBALS['sig'];

 $sucess_count = 0;
 $fail_count = 0;

 $addresses = @file($list_file) or die("<center><b>The list data file could not be opened.</b><br>Check the path and permissions.</center>");
 $addresses[] = $owner_email;
 set_time_limit(0);
 foreach ($addresses as $email) {
  $email = trim($email);
  if (mail($email, $subject, $message, $headers)) $sucess_count++;
  else $fail_count++;
 }
 echo "<h3 align=\"center\">Your message was sucessfully sent to $sucess_count addresses.</h3><h4 align=\"center\">There was $fail_count unsucessfully sent.</h4>";
}

function admin_view_subs() {
 // Displays the subscribers of the list.
 global $per_page, $page;

 if (!$per_page) $per_page = $GLOBALS[default_per_page];
 if (!$page) $page = 1;

 $address_arr = @file($GLOBALS[list_file]) or die("<center><b>The list data file could not be read.</b><br>You may have no subscribers or the file could not be found.</center>");
 sort($address_arr);
 $count = count($address_arr);
 $total_page = floor($count/$per_page) + 1;
 $start_num = (($page * $per_page) - $per_page) + 1;

 if (($page+1) > $total_page) $end_num = $count;
 else $end_num = $page * $per_page;

 echo "<h2 align=\"center\">Subscribers List</h2>
<h3 align=\"center\">There are $count addresses are subscribed to this list.</h3>
<h4 align=\"center\"><i>Subscribers $start_num - $end_num</i></h4>
<table border=\"1\" align=\"center\" bordercolor=\"black\" cellspacing=\"0\" cellpadding=\"2\">
<tr><td align=\"center\" bgcolor=\"#999999\"><b>#</b></td>
<td align=\"center\" bgcolor=\"#999999\"><b>Addresses</b></td></tr>";

 $start1 = $start_num -1;
 $end_num--;
 $j = $start_num;
 for($i = $start1; $i <= $end_num; $i++) {
  echo "<tr><td align=\"center\">$j</td><td align=\"center\">$address_arr[$i]</td></tr>\n";
  $j++;
 }
 echo "</table>";
?>
<form method="post" name="view">
<input type="hidden" name="username" value="<?php echo $GLOBALS[username]; ?>">
<input type="hidden" name="password" value="<?php echo $GLOBALS[password]; ?>">
<input type="hidden" name="action" value="<?php echo $GLOBALS[admin_keyword]; ?>">
<input type="hidden" name="q" value="view_subs">
<input type="hidden" name="page">
<input type="hidden" name="per_page">
<br><div align="center" style="font-size:95%">
View 
| <a href="" Onclick="per_page.value='10'; submit(); return false;" >10</a> 
| <a href="" Onclick="per_page.value='20'; submit(); return false;" >20</a> 
| <a href="" Onclick="per_page.value='30'; submit(); return false;" >30</a> 
| <a href="" Onclick="per_page.value='50'; submit(); return false;" >50</a> 
| <a href="" Onclick="per_page.value='100'; submit(); return false;">100</a> | per page.
<?php

if ($count > $per_page) {
 $prev_page = $page - 1;
 $next_page = $page + 1;
 // Prints bottom page numbers.
 echo "<br><br>";
 if ($prev_page > 0) echo "| <a href=\"\" Onclick=\"page.value='$prev_page';per_page.value='$per_page';submit();return false;\">Previous $per_page</a> ";
 echo " | ";
 for($i=1; $i <= $total_page; $i++) {
  if ($i == $page) echo "<b>$i</b> | ";
  else echo "<a href=\"\" Onclick=\"per_page.value='$per_page';page.value='$i';submit();return false;\">$i</a> | ";
 }
 if ($next_page <= $total_page) echo "<a href=\"\" Onclick=\"per_page.value='$per_page';page.value='$next_page';submit();return false;\">Next  $per_page</a> |";
}
echo "<br><br><i>Page $page of $total_page</i>
</div>
</form>";
}

function admin_add_remove() {
 // Adding/Removing subscribers through admin.
 global $username, $password, $remove_address_arr, $list_file, $x, $y, $admin_keyword, $email, $admin_add_email_opt, $list_name;

 if ($x == "remove") {
  $file = @file($list_file) or die("<center><b>The list data file could not be read.</b><br>You may have no subscribers or the file could not be found.</center>");
  sort($file);
  echo "
<form method=\"post\" name=\"remove\">
<input type=\"hidden\" name=\"username\" value=\"$username\">
<input type=\"hidden\" name=\"password\" value=\"$password\">
<input type=\"hidden\" name=\"action\" value=\"$admin_keyword\">
<input type=\"hidden\" name=\"q\" value=\"add_remove\">
<input type=\"hidden\" name=\"x\" value=\"remove_submit\">
<center><font size=\"+1\"><b>Remove Addresses:</b>
<br><br><font size=\"-1\">Hold down <i>Ctrl</i> to select multiple addresses.
<br><br><select multiple name=\"remove_address_arr[]\" size=\"7\">
";
  foreach ($file as $key => $address) {
   $address = trim($address);
   echo "<option value=\"$address\">&nbsp;$address&nbsp;&nbsp;&nbsp;</option>\n";
  }
  echo "</select><br><br><input type=\"submit\" value=\"Remove\">&nbsp;<input type=\"reset\" value=\"Reset\"></form></center>\n";
 }
 elseif ($x == "remove_submit") {
  $sucess_count = 0;
  foreach ($remove_address_arr as $rm_add) {
   if (remove_from_list($rm_add)) {
    $sucess_count++;
   }
  }
  echo "<center><b>$sucess_count email addresses were removed.</b></center><br>";
 }
 elseif ($x == "remove_all") {
  echo "
<center><b>Warning!</b>
<br>If you continue with this action all subscribers to
<br>your list will be removed.
<br>
<br>Are you sure you wish to proceed?
<br>
<form method=\"post\">
<input type=\"hidden\" name=\"username\" value=\"$username\">
<input type=\"hidden\" name=\"password\" value=\"$password\">
<input type=\"hidden\" name=\"action\" value=\"$admin_keyword\">
<input type=\"hidden\" name=\"q\" value=\"add_remove\">
<input type=\"hidden\" name=\"x\" value=\"remove_all_submit\">
<input type=\"submit\" value=\"Remove All Addresses\"><br><br>
</center>";
 }
 elseif ($x == "remove_all_submit") {
  $fd = fopen($list_file, "w") or die("<center><b>List Data file could not be opened.</b></center>");
  fclose($fd);
  echo "<center><b>All addresses have been removed.</b></center>";
 }
 elseif ($x == "add") {
   $email = trim($email);
   $welcome = "off";
   $confirm = "off";
   if ($admin_add_email_opt == "confirm") $confirm = "on";
   elseif ($admin_add_email_opt == "welcome") $welcome = "on";
  if ($y == "single") subscribe($email, $confirm, $welcome);
  elseif ($y == "many") {
   $email_arr = explode("\n", $email);
   foreach ($email_arr as $email) subscribe(trim($email), $confirm, $welcome);
  }
  else admin_print_add();
 }
 admin_print_addremove_options();
}

function admin_print_add() {
 global $username, $password, $admin_keyword;
  echo "
<table border=\"0\" align=\"center\"><tr><td>
<form method=\"post\">
<table border=\"0\" align=\"left\">
<tr><td colspan=\"2\"><font size=\"+1\"><b>Add Addresses</font></b><br>&nbsp;</td></tr>
<tr><td><font size=\"-1\">Single Email Address:</font></td>
<td><input type=\"text\" name=\"email\" size=\"30\"></td></tr>
<tr><td></td><td>
<input type=\"hidden\" name=\"username\" value=\"$username\">
<input type=\"hidden\" name=\"password\" value=\"$password\">
<input type=\"hidden\" name=\"action\" value=\"$admin_keyword\">
<input type=\"hidden\" name=\"q\" value=\"add_remove\">
<input type=\"hidden\" name=\"x\" value=\"add\">
<input type=\"hidden\" name=\"y\" value=\"single\">
<br><input type=\"radio\" name=\"admin_add_email_opt\" value=\"welcome\"><font size=\"-1\">Send Welcome Message
<br><input type=\"radio\" name=\"admin_add_email_opt\" value=\"confirm\"><font size=\"-1\">Ask for confirmation
<br>
<br><input type=\"submit\" value=\"Add Address\">&nbsp;<input type=\"reset\" value=\"Clear\">
<br>&nbsp</td></tr></table></form>
</td></tr><tr><td>
<form method=\"post\">
<table border=\"0\" align=\"left\">
<tr><td valign=\"top\"><font size=\"-1\">Many Email Addresses:
<br><i>(one per line)</i></font></td>
<td><textarea name=\"email\" rows=\"6\" cols=\"30\"></textarea></td></tr>
<tr><td></td><td>
<input type=\"hidden\" name=\"username\" value=\"$username\">
<input type=\"hidden\" name=\"password\" value=\"$password\">
<input type=\"hidden\" name=\"action\" value=\"$admin_keyword\">
<input type=\"hidden\" name=\"q\" value=\"add_remove\">
<input type=\"hidden\" name=\"x\" value=\"add\">
<input type=\"hidden\" name=\"y\" value=\"many\">
<br><input type=\"radio\" name=\"admin_add_email_opt\" value=\"welcome\"><font size=\"-1\">Send Welcome Message
<br><input type=\"radio\" name=\"admin_add_email_opt\" value=\"confirm\"><font size=\"-1\">Ask for confirmation
<br>
<br><input type=\"submit\" value=\"Add Addresses\">&nbsp;<input type=\"reset\" value=\"Clear\">
</td></tr></table></form>
</td></tr></table>";
}

function admin_print_addremove_options() {
 global $username, $password, $admin_keyword;
 echo "
<form method=\"post\">
<input type=\"hidden\" name=\"username\" value=\"$username\">
<input type=\"hidden\" name=\"password\" value=\"$password\">
<input type=\"hidden\" name=\"action\" value=\"$admin_keyword\">
<input type=\"hidden\" name=\"q\" value=\"add_remove\">
<table border=\"0\" align=\"center\" cellspacing=\"0\" cellpadding=\"1\">
<tr><td colspan=\"2\"><font size=\"+1\"><br><b>Add/Remove Options</b></td></tr>
<tr><td><input type=\"radio\" name=\"x\" value=\"remove\"></td><td>Remove Subscribers</td></tr>
<tr><td><input type=\"radio\" name=\"x\" value=\"remove_all\"></td><td>Remove All Subscribers</td></tr>
<tr><td><input type=\"radio\" name=\"x\" value=\"add\"></td><td>Add Subscribers</td></tr>
<tr><td></td><td><input type=\"submit\" value=\"Submit\"></form></td></tr></table>";
}

function admin_print_options() {
 // Prints the administration options.
 global $username, $password, $admin_keyword;
 echo "
<form method=\"post\">
<input type=\"hidden\" name=\"username\" value=\"$username\">
<input type=\"hidden\" name=\"password\" value=\"$password\">
<input type=\"hidden\" name=\"action\" value=\"$admin_keyword\">
<table border=\"0\" align=\"center\" cellspacing=\"0\" cellpadding=\"1\">
<tr><td colspan=\"2\"><font size=\"+1\"><br><b>PHPMail List Options</b></td></tr>
<tr><td><input type=\"radio\" name=\"q\" value=\"write_msg\"></td><td>Send a message</td></tr>
<tr><td><input type=\"radio\" name=\"q\" value=\"view_subs\"></td><td>View Subscribers</td></tr>
<tr><td><input type=\"radio\" name=\"q\" value=\"add_remove\"></td><td>Add/Remove Subscribers</td></tr>
<tr><td><input type=\"radio\" name=\"q\" value=\"config\"></td><td>Administration</td></tr>
<tr><td></td><td><input type=\"submit\" value=\"Submit\"></form></td></tr></table>";
}

function admin_config() {
 // Changes the configuration/options of the script.
 global $s, $config_file, $newsig, $newusername, $newbanned_addresses, $newpassword, $newlist_name, $newlist_file, $newowner_email, $newsend_welcome, $newwelcome_subject, $newwelcome_msg, $newsend_goodbye, $newgoodbye_subject, $newgoodbye_msg, $newsend_confirm, $newconfirm_subject, $newconfirm_msg, $newdefault_per_page;
 if ($s == "submit") {
  echo "<h3 align=\"center\">";
  $back_button = "<h4 align=\"center\">Your changes have not been saved.</h4><input align=\"center\" type=\"submit\" value=\"Go Back\" OnClick=\"history.go(-1); return true;\">";
  if (!valid_email($newowner_email)) echo "Owner's Email address is invalid.".$back_button;
  elseif ($newusername == "") echo "You did not enter a username.".$back_button;
  elseif ($newpassword == "") echo "You did not enter a password.".$back_button;
  elseif ($newlist_name == "") echo "You did not enter a name for the list.".$back_button;
  elseif ($newlist_file == "") echo "You did not enter a path to the list data file.".$back_button;
  elseif ($newlist_file == "") echo "You did not enter a path to the list data file.".$back_button;
  elseif ($newconfirm_subject == "") echo "You did not enter subject for confirmation emails.".$back_button;
  elseif ($newconfirm_msg == "") echo "You did not enter confirmation email message.".$back_button;
  elseif ($newwelcome_subject == "") echo "You did not enter subject for welcome emails.".$back_button;
  elseif ($newwelcome_msg == "") echo "You did not enter welcome email message.".$back_button;
  elseif ($newgoodbye_subject == "") echo "You did not enter subject for goodbye emails.".$back_button;
  elseif ($newgoodbye_msg == "") echo "You did not enter goodbye email message.".$back_button;
  elseif ($newdefault_per_page == "") echo "You did not enter a number of default subscribers per page.".$back_button;
  elseif (!is_numeric($newdefault_per_page)) echo "The default number of subscribers per page must be an integer.".$back_button;
  else {
   $fd = @fopen($config_file, "w") or die("Could not open configuration file for writing.");
   $new_config = "$newusername\n$newpassword\n$newlist_name\n$newlist_file\n$newowner_email\n$newsend_confirm\n$newconfirm_subject\n$newsend_welcome\n$newwelcome_subject\n$newsend_goodbye\n$newgoodbye_subject\n$newdefault_per_page\n";
   fputs($fd, $new_config);
   fputs($fd, "<confirm>\n$newconfirm_msg\n</confirm>\n");
   fputs($fd, "<welcome>\n$newwelcome_msg\n</welcome>\n");
   fputs($fd, "<sig>\n$newsig\n</sig>\n");
   fputs($fd, "<goodbye>\n$newgoodbye_msg\n</goodbye>\n");
   fputs($fd, "<banned>\n$newbanned_addresses\n</banned>");
   fclose($fd);
   echo "Your configuration has been updated.</h3><h4 align=\"center\">If you changed the username/password you will need to log in again.</h4>";
  }
  echo "</h3>";
 }
 else admin_print_config_form();
}

function admin_print_config_form() {
 // Prints the configuration options.
 $list_file = stripslashes($list_file);
 echo "<form method=\"post\">
<input type=\"hidden\" name=\"username\" value=\"$GLOBALS[username]\">
<input type=\"hidden\" name=\"password\" value=\"$GLOBALS[password]\">
<input type=\"hidden\" name=\"action\" value=\"$GLOBALS[admin_keyword]\">
<input type=\"hidden\" name=\"q\" value=\"config\">
<input type=\"hidden\" name=\"s\" value=\"submit\">
<table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
<tr><td colspan=\"2\"><font size=\"+1\"><b>Configuration</b><br></td></tr>
<tr><td colspan=\"2\"><font size=\"-1\">
<br><b>Shortcuts:</b>
<br><i>%list_name%</i> = The name of the list.
<br><i>%email%</i> = The email address the email is being sent it.
<br><i>%confirm_url%</i> = URL user must go to to confirm subscription.
<br><i>%subscribe_url%</i> = URL users go to to resubscribe.
<br><i>%unsubscribe_url%</i> = URL where user can unsubscribe.
<br></td></tr>
<tr><td><font size=\"-1\"><br><i><b>General</b></i></td><td></td></tr>
<tr><td><font size=\"-1\">Username: </td><td><input size=\"40\" type=\"text\" name=\"newusername\" value=\"$GLOBALS[username]\"></td></tr>
<tr><td><font size=\"-1\">Password: </td><td><input size=\"40\" type=\"password\" name=\"newpassword\" value=\"$GLOBALS[password]\"></td></tr>
<tr><td><font size=\"-1\">List Name: </td><td><input size=\"40\" type=\"text\" name=\"newlist_name\" value=\"$GLOBALS[list_name]\"></td></tr>
<tr><td><font size=\"-1\">List File: </td><td><input size=\"40\" type=\"text\" name=\"newlist_file\" value=\"".stripslashes($GLOBALS[list_file])."\"></td></tr>
<tr><td><font size=\"-1\">Owner's Email: </td><td><input size=\"40\" type=\"text\" name=\"newowner_email\" value=\"$GLOBALS[owner_email]\"></td></tr>
<tr><td><font size=\"-1\">Default # Subscribers/page: </td><td><input size=\"4\" maxlength=\"3\" type=\"text\" name=\"newdefault_per_page\" value=\"$GLOBALS[default_per_page]\"></td></tr>
<tr><td><font size=\"-1\"><br><i><b>Banned Addresses</b></i></td><td></td></tr>
<tr><td valign=\"top\"><font size=\"-1\">Addresses:<br><i>(New line for each address)</i></td><td><textarea name=\"newbanned_addresses\" rows=\"4\" cols=\"25\">$GLOBALS[banned_addresses]</textarea></td></tr>
<tr><td><font size=\"-1\"><br><i><b>Signature</b></i></td><td></td></tr>
<tr><td valign=\"top\"><font size=\"-1\">Signature:<br><i>(Include by default on the<br>bottom of all messages)<br>Shortcuts not valid in signature.</i></td><td><textarea name=\"newsig\" rows=\"6\" cols=\"45\">$GLOBALS[sig]</textarea></td></tr>
<tr><td><font size=\"-1\"><br><i><b>Confirmation</b></i></td><td></td></tr>
<tr><td><font size=\"-1\">Send Email Asking for confirmation? &nbsp</td><td><input type=\"checkbox\" name=\"newsend_confirm\" ";
if ($GLOBALS[send_confirm] == "on") { echo "checked"; }
echo "></td></tr>
<tr><td><font size=\"-1\">Confirmation Subject: </td><td><input size=\"45\" type=\"text\" name=\"newconfirm_subject\" value=\"$GLOBALS[confirm_subject]\"></td></tr>
<tr><td valign=\"top\"><font size=\"-1\">Confirmation Message: </td><td><textarea name=\"newconfirm_msg\" rows=\"10\" cols=\"45\">$GLOBALS[confirm_msg]</textarea></td></tr>
<tr><td><font size=\"-1\"><br><i><b>Welcome Message</b></i></td><td></td></tr>
<tr><td><font size=\"-1\">Send Welcome Message? </td><td><input type=\"checkbox\" name=\"newsend_welcome\" ";
if ($GLOBALS[send_welcome] == "on") { echo "checked"; }
echo "></td></tr>
<tr><td><font size=\"-1\">Welcome Message Subject: </td><td><input size=\"45\" type=\"text\" name=\"newwelcome_subject\" value=\"$GLOBALS[welcome_subject]\"></td></tr>
<tr><td valign=\"top\"><font size=\"-1\">Welcome Message: </td><td><textarea name=\"newwelcome_msg\" rows=\"10\" cols=\"45\">$GLOBALS[welcome_msg]</textarea></td></tr>
<tr><td><font size=\"-1\"><br><i><b>Goodbye Message</b></i></td><td></td></tr>
<tr><td><font size=\"-1\">Send Goodbye Message? </td><td><input type=\"checkbox\" name=\"newsend_goodbye\" ";
if ($GLOBALS[send_goodbye] == "on") { echo "checked"; }
echo "></td></tr>
<tr><td><font size=\"-1\">Goodbye Message Subject: </td><td><input size=\"45\" type=\"text\" name=\"newgoodbye_subject\" value=\"$GLOBALS[goodbye_subject]\"></td></tr>
<tr><td valign=\"top\"><font size=\"-1\">Goodbye Message: </td><td><textarea name=\"newgoodbye_msg\" rows=\"10\" cols=\"45\">$GLOBALS[goodbye_msg]</textarea></td></tr>
<tr><td></td><td><br><input type=\"submit\" value=\"Save\">&nbsp;<input type=\"reset\" value=\"Reset\"></td></tr>
</table>
</form>";
}

function admin_print_logon($msg) {
 // Prints the logon screen.
 echo "
<form method=\"post\">
<center><b>$msg</b><br><br></center>
<table border=\"0\" align=\"center\">
<tr><td colspan=\"2\" align=\"center\"><b>Logon:</b></td></tr>
<tr><td>Username:</td><td><input type=\"text\" name=\"username\"></td></tr>
<tr><td>Password:</td><td><input type=\"password\" name=\"password\"></td></tr>
<tr><td></td><td><input type=\"submit\" value=\"Logon\"></td></tr></table></form>";
}

function print_subscribe_form() {
 // Prints the subscription form.
 global $list_name;
 echo "
<form method=\"post\"><center>Subscribe to:<br><b>$list_name</b></center>
<table border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">
<tr><td rowspan=\"2\"><input type=\"text\" name=\"email\" value=\"Your Email Address\" size=\"20\"></td>
<td><input type=\"radio\" name=\"action\" value=\"sub\" checked><font size=\"-1\">&nbsp;Subscribe</font></td></tr>
<tr><td><input type=\"radio\" name=\"action\" value=\"unsub\"><font size=\"-1\">&nbsp;Unsubscribe</font></td></tr>
<tr><td colspan=\"2\" align=\"center\" valign=\"center\"><input type=\"submit\" value=\"Submit\"></td></tr>
</table></form>";
}

function print_footer() {
 // Prints the footer.
 global $version;
 echo "
<br><br><center><b>PHPMailList</b>\n<br>A script by <a href=\"http://php.warpedweb.net/\">David Broker</a>.
<br><a href=\"http://php.warpedweb.net/\"><i>http://php.warpedweb.net/</i></a>
<br>Version $version</center>";
}
?>
<!-- PHPMail List: http://php.warpedweb.net/ -->
</body></html>