# phpMyAdmin MySQL-Dump
# version 2.3.3pl1
# http://www.phpmyadmin.net/ (download page)
#
# Host: localhost
# Generation Time: Dec 20, 2003 at 09:08 PM
# Server version: 3.23.54
# PHP Version: 4.3.0
# Database : `dynamicpages`
# --------------------------------------------------------

#
# Table structure for table `edp_bmcategory`
#

DROP TABLE IF EXISTS `edp_bmcategory`;
CREATE TABLE `edp_bmcategory` (
  `ID` bigint(20) NOT NULL auto_increment,
  `CName` varchar(200) NOT NULL default 'Category Name',
  `CDescription` varchar(255) NOT NULL default 'Category Description',
  `Parent` bigint(20) default '0',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM;

#
# Dumping data for table `edp_bmcategory`
#

INSERT INTO `edp_bmcategory` (`ID`, `CName`, `CDescription`, `Parent`) VALUES (1, 'Banks', 'USA', 0),
(4, 'Physics', 'All about physics', 0),
(5, 'Conferences', 'Related conferences', 4),
(6, 'Credit Cards', 'USA', 1);
# --------------------------------------------------------

#
# Table structure for table `edp_bmlink`
#

DROP TABLE IF EXISTS `edp_bmlink`;
CREATE TABLE `edp_bmlink` (
  `ID` bigint(20) NOT NULL auto_increment,
  `LUrl` varchar(255) NOT NULL default '',
  `LName` varchar(200) NOT NULL default '',
  `LDescription` text NOT NULL,
  `Date` date NOT NULL default '0000-00-00',
  `Modify` date NOT NULL default '0000-00-00',
  `Visit` date NOT NULL default '0000-00-00',
  `Hits` bigint(20) NOT NULL default '0',
  `Parent` bigint(20) default '0',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM;

#
# Dumping data for table `edp_bmlink`
#

INSERT INTO `edp_bmlink` (`ID`, `LUrl`, `LName`, `LDescription`, `Date`, `Modify`, `Visit`, `Hits`, `Parent`) VALUES (1, 'https://www48.americanexpress.com/en/en_US/logon/IntlLogLogon.jsp?Face=en_US&DestPage=https%3A%2F%2Fwww48.americanexpress.com%2Fen%2Fcards%3Frequest_type%3Dauthreg_acctAccountSummary%26Face%3Den_US', 'American Express', 'Credit Cards', '2003-02-09', '2003-07-30', '2003-07-31', 3, 6),
(2, 'https://chaseonline.chase.com', 'Chase', 'chase online', '2003-01-23', '2003-07-30', '2003-07-31', 3, 1),
(4, 'https://www.paypal.com/cgi-bin/webscr?cmd=_login-run', 'PayPal', 'ebay', '2003-02-09', '2003-07-30', '2003-07-30', 0, 1),
(6, 'https://www.wilmingtontrust.com', 'Wilmington Trust', 'Wilmington', '2003-01-31', '2003-07-30', '2003-07-30', 0, 1),
(17, 'http://alinea.bg/', 'alinea.bg', 'BG', '2003-01-18', '2003-07-30', '2003-12-17', 3, 0),
(18, 'http://bgfree.biz/', 'bgfree.biz', 'BG', '2003-01-18', '2003-07-30', '2003-12-17', 1, 0),
(21, 'http://mario.stoitsov.com/', 'mario.stoitsov.com', 'BG', '2003-01-18', '2003-07-30', '2003-08-01', 2, 0),
(28, 'http://www.aps.org/', 'American Physical Society', 'for the advancement and diffusion of knowledge of physics', '2003-02-06', '2003-07-30', '2003-07-31', 1, 4),
(29, 'http://ie.lbl.gov/toimass.html', 'Atomic Masses', 'Mass chart', '2003-01-18', '2003-07-30', '2003-07-30', 0, 4),
(35, 'http://www.orau.gov/ria/', 'First RIA Summer School on Exotic Beam Physics', 'ornl', '2003-01-18', '2003-07-30', '2003-07-30', 0, 5),
(45, 'http://alice-france.in2p3.fr/qm2002/', 'Quark matter 2002', 'France', '2003-01-18', '2003-07-30', '2003-07-30', 0, 5),
(47, 'http://www.sciencedirect.com/science?_ob=JournalURL&_cdi=6706&_auth=y&_acct=C000050221&_version=1&_urlVersion=0&_userid=10&md5=5a7cbb5d17d602fee4c60955da87f665', 'ScienceDirect', 'Atomic Data and Nuclear Data Tables', '2003-03-05', '2003-07-30', '2003-07-30', 0, 4),
(48, 'http://xxx.lanl.gov/find/nucl-th', 'Search Physics archives', 'e-prints', '2003-01-22', '2003-07-30', '2003-07-30', 0, 4);
# --------------------------------------------------------

#
# Table structure for table `edp_cacards`
#

DROP TABLE IF EXISTS `edp_cacards`;
CREATE TABLE `edp_cacards` (
  `ID` int(11) NOT NULL auto_increment,
  `SenderName` varchar(255) NOT NULL default '',
  `RecipientName` varchar(255) NOT NULL default '',
  `FirstLine` varchar(255) NOT NULL default '',
  `MText` text NOT NULL,
  `LastLine` varchar(255) NOT NULL default '',
  `Music` varchar(255) NOT NULL default '',
  `TextFont` varchar(100) NOT NULL default '',
  `TextColor` varchar(100) NOT NULL default '',
  `BackColor` varchar(100) NOT NULL default '',
  `sid` varchar(200) NOT NULL default '',
  `Date` date NOT NULL default '0000-00-00',
  `Picture` varchar(255) NOT NULL default '',
  `PType` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM;

#
# Dumping data for table `edp_cacards`
#

INSERT INTO `edp_cacards` (`ID`, `SenderName`, `RecipientName`, `FirstLine`, `MText`, `LastLine`, `Music`, `TextFont`, `TextColor`, `BackColor`, `sid`, `Date`, `Picture`, `PType`) VALUES (1, '', '', '', '', '', './music/Bach_aria.mid', 'Arial', 'black', 'white', 'f81cf4370191be8fe3156ec9c1539c6c', '2003-11-16', 'Nature/21.jpg', 1),
(2, '', '', '', '', '', './music/Bach_aria.mid', 'Arial', 'black', 'white', '1d85dd9acb15b2c6b9fba82882a9fc54', '2003-11-16', 'Animals/0004960.jpg', 2),
(3, '', '', '', '', '', './music/Bach_aria.mid', 'Arial', 'black', 'white', '2e4d48f00d540b4d4d41733a58ec2130', '2003-11-16', 'Nature/22.jpg', 1);
# --------------------------------------------------------

#
# Table structure for table `edp_calendar`
#

DROP TABLE IF EXISTS `edp_calendar`;
CREATE TABLE `edp_calendar` (
  `IID` mediumint(5) unsigned NOT NULL auto_increment,
  `uid` tinyint(3) unsigned NOT NULL default '0',
  `m` tinyint(2) NOT NULL default '0',
  `d` tinyint(2) NOT NULL default '0',
  `y` smallint(4) NOT NULL default '0',
  `start_time` time NOT NULL default '00:00:00',
  `end_time` time NOT NULL default '00:00:00',
  `title` varchar(50) NOT NULL default '',
  `text` text NOT NULL,
  `pub` int(11) NOT NULL default '0',
  PRIMARY KEY  (`IID`),
  KEY `id` (`IID`),
  KEY `m` (`m`),
  KEY `y` (`y`),
  KEY `uid` (`uid`)
) TYPE=MyISAM;

#
# Dumping data for table `edp_calendar`
#

INSERT INTO `edp_calendar` (`IID`, `uid`, `m`, `d`, `y`, `start_time`, `end_time`, `title`, `text`, `pub`) VALUES (1, 1, 1, 1, 2004, '00:00:00', '00:00:00', 'Happy New Year', 'Happy New Year to all registered users.', 0),
(2, 1, 1, 1, 2004, '14:00:00', '15:00:00', 'Arc tangent-atan', 'Returns the arc tangent of arg in radians.', 0),
(3, 1, 1, 16, 2004, '00:00:00', '00:00:00', 'What is PHP?', 'Widely-used Open Source general-purpose scripting language that is especially suited for Web development and can be embedded into HTML.', 0),
(4, 1, 1, 16, 2004, '00:00:00', '00:00:00', 'What can PHP do?', 'Server-side scripting, comand-line scripting, writing client-side GUI applications.', 0);
# --------------------------------------------------------

#
# Table structure for table `edp_catop`
#

DROP TABLE IF EXISTS `edp_catop`;
CREATE TABLE `edp_catop` (
  `ID` int(11) NOT NULL auto_increment,
  `Dir` varchar(255) NOT NULL default '',
  `PType` tinyint(4) NOT NULL default '0',
  `Picture` varchar(255) NOT NULL default '',
  `Hits` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM;

#
# Dumping data for table `edp_catop`
#

INSERT INTO `edp_catop` (`ID`, `Dir`, `PType`, `Picture`, `Hits`) VALUES (1, 'Nature', 1, 'Nature/21.jpg', 1),
(2, 'Animals', 2, 'Animals/0004960.jpg', 1),
(3, 'Nature', 1, 'Nature/22.jpg', 1);
# --------------------------------------------------------

#
# Table structure for table `edp_clcategory`
#

DROP TABLE IF EXISTS `edp_clcategory`;
CREATE TABLE `edp_clcategory` (
  `ID` bigint(20) NOT NULL auto_increment,
  `CName` varchar(200) NOT NULL default 'Category Name',
  `CDescription` varchar(255) NOT NULL default 'Category Description',
  `Parent` bigint(20) default '0',
  PRIMARY KEY  (`ID`),
  KEY `ID` (`ID`),
  KEY `Parent` (`Parent`)
) TYPE=MyISAM;

#
# Dumping data for table `edp_clcategory`
#

INSERT INTO `edp_clcategory` (`ID`, `CName`, `CDescription`, `Parent`) VALUES (1, 'Bulgaria', 'Imported folder', 0),
(2, 'Sites', 'Imported folder', 1),
(3, 'Conferences1', 'Imported folder', 0),
(4, 'Physics', 'Imported folder', 3),
(7, 'Journals', 'Imported folder', 0),
(8, 'general', 'Imported folder', 7),
(33, 'Psychology', 'Imported folder', 0),
(35, 'Media', 'Imported folder', 33),
(36, 'Webdesign', 'Imported folder', 0),
(37, 'tools', 'Imported folder', 36);
# --------------------------------------------------------

#
# Table structure for table `edp_cllink`
#

DROP TABLE IF EXISTS `edp_cllink`;
CREATE TABLE `edp_cllink` (
  `ID` bigint(20) NOT NULL auto_increment,
  `LUrl` varchar(255) NOT NULL default '',
  `LName` varchar(200) NOT NULL default '',
  `LDescription` text NOT NULL,
  `Date` date NOT NULL default '0000-00-00',
  `Modify` date NOT NULL default '0000-00-00',
  `Visit` date NOT NULL default '0000-00-00',
  `Hits` bigint(20) NOT NULL default '0',
  `Parent` bigint(20) default '0',
  `Choice` tinyint(4) NOT NULL default '0',
  `IP` varchar(18) NOT NULL default '',
  PRIMARY KEY  (`ID`),
  KEY `Date` (`Date`),
  KEY `Modify` (`Modify`),
  KEY `Visit` (`Visit`),
  KEY `Hits` (`Hits`),
  KEY `Parent` (`Parent`),
  KEY `Choice` (`Choice`)
) TYPE=MyISAM;

#
# Dumping data for table `edp_cllink`
#

INSERT INTO `edp_cllink` (`ID`, `LUrl`, `LName`, `LDescription`, `Date`, `Modify`, `Visit`, `Hits`, `Parent`, `Choice`, `IP`) VALUES (2, 'http://www.google.com/', 'Google', 'petia link', '2003-01-12', '2003-03-20', '2003-08-01', 2, 2, 1, '127.0.0.1'),
(5, 'http://www.geocities.com/SoHo/Studios/2165/sevda/sevdacv.html', 'SEVDALINA KOSTADINOVA - curriculum vitae', 'SEVDALINA KOSTADINOVA - curriculum vitae', '2000-10-21', '2003-01-16', '2003-01-16', 0, 2, 0, ''),
(6, 'http://nuctheor.alinea.bg/', 'Theoretical Nuclear Physics Group - Sofia, Bulgaria', 'Site of the group at INRNE, BAS', '2002-09-04', '2003-03-20', '2003-03-20', 0, 2, 0, ''),
(7, 'http://www.orau.gov/ria/', 'First RIA Summer School on Exotic Beam Physics', 'First RIA Summer School on Exotic Beam Physics', '2002-09-05', '2003-03-05', '2003-03-05', 0, 4, 0, ''),
(8, 'http://www.fuw.edu.pl/~hs2001/', 'High Spin Physics 2001', 'High Spin Physics 2001', '2000-10-21', '2002-08-29', '2002-08-29', 0, 4, 0, ''),
(9, 'http://int.phys.washington.edu/seminars_all.html', 'INT Seminars', 'INT Seminars', '2000-10-21', '2003-01-08', '2003-01-08', 0, 4, 0, ''),
(10, 'http://www.nsf.gov/sbe/int/ce_europe/start.htm', 'NSF INT CEE Program Homepage', 'NSF INT CEE Program Homepage', '2002-06-28', '2002-09-02', '2002-09-02', 0, 4, 0, ''),
(11, 'http://www.fuw.edu.pl/~int2000/', 'Nuclear structure for the 21st century', 'Nuclear structure for the 21st century', '2000-10-23', '2003-02-28', '2003-02-28', 0, 4, 0, ''),
(12, 'http://www.orau.gov/neutron/contact.html', 'Sanibel Island, Florida', 'Sanibel Island, Florida', '2002-08-28', '2003-02-06', '2003-02-06', 0, 4, 0, ''),
(15, 'http://ojps.aip.org/journal_cgi/dbt?KEY=AJPIAS&Volume=CURVOL&Issue=CURISS', 'American Journal of Physics--August 1999', 'American Journal of Physics--August 1999', '2000-11-03', '2003-01-27', '2003-01-27', 0, 8, 0, ''),
(16, 'http://physical.annualreviews.org/', 'Annual Review of Physical Sciences', 'Annual Review of Physical Sciences', '2000-11-03', '2003-02-21', '2003-02-21', 0, 8, 0, ''),
(17, 'http://publish.aps.org/', 'APS Research Journals', 'APS Research Journals', '2000-11-03', '1970-01-01', '1970-01-01', 0, 8, 0, ''),
(218, 'http://www.fultonbooks.co.uk/fultie.htm', 'Cognitive styles and Learning Strategies', 'David Fulton Publishers: Cognitive styles and Learning Strategies; Understanding Style Differences in Learning and Behavior by Richaard Riding and Stephen Rayner', '2002-04-10', '1970-01-01', '2003-08-05', 1, 35, 0, '127.0.0.1'),
(219, 'http://129.113.160.149/comm2002/Textbook/Chapter02.html', 'Communication Policy and Strategy', 'Communication Policy and Strategy', '2002-04-06', '1970-01-01', '1970-01-01', 0, 35, 0, ''),
(220, 'http://www.vrd.org/conferences/VRD2000/proceedings/ware-intro.shtml', 'Communication Theory', 'Communication Theory and the Design of Live Online Reference Services', '2002-03-18', '1970-01-01', '1970-01-01', 0, 35, 0, ''),
(244, 'http://www.nameit.net/', 'Domain Registration - NameIT Corporation', 'Domain Registration - NameIT Corporation', '2000-10-31', '2003-02-19', '2003-02-19', 0, 37, 0, ''),
(246, 'http://desktoppublishing.com/icons.html', 'Icons for Web Publishing and Design', 'Icons for Web Publishing and Design', '2000-10-21', '2003-03-01', '2003-03-01', 0, 37, 0, ''),
(247, 'http://test.com', 'testcom', 'test', '2003-08-04', '2003-08-04', '2003-08-04', 0, 1, 0, ''),
(248, 'http://aaaaaaaaaaaaaaa', 'aaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaa', '2003-12-17', '2003-12-17', '2003-12-17', 0, 36, 0, '');
# --------------------------------------------------------

#
# Table structure for table `edp_config`
#

DROP TABLE IF EXISTS `edp_config`;
CREATE TABLE `edp_config` (
  `ID` bigint(10) NOT NULL default '0',
  `sitetitle` varchar(200) NOT NULL default '',
  `sitecharset` varchar(200) NOT NULL default '',
  `sitecontent` varchar(200) NOT NULL default '',
  `siteauthor` varchar(200) NOT NULL default '',
  `pagesectionhome` varchar(200) NOT NULL default '',
  `themename` varchar(200) NOT NULL default '',
  `abackground` varchar(200) NOT NULL default '',
  `adarkcolor` varchar(200) NOT NULL default '',
  `agraycolor` varchar(200) NOT NULL default '',
  `alightcolor` varchar(200) NOT NULL default '',
  `ebackground` varchar(200) NOT NULL default '',
  `elightcolor1` varchar(200) NOT NULL default '',
  `eightcolor2` varchar(200) NOT NULL default '',
  `earticles` varchar(200) NOT NULL default '',
  `econtact` varchar(200) NOT NULL default '',
  `enews_per_page` varchar(200) NOT NULL default '',
  `ehead_per_page` varchar(200) NOT NULL default '',
  `etable_width` varchar(200) NOT NULL default '',
  `elinks_per_page` varchar(200) NOT NULL default '',
  `enew_days` varchar(200) NOT NULL default '',
  `epage_width` varchar(200) NOT NULL default '',
  `egd_version` varchar(200) NOT NULL default '',
  `epics_per_page` varchar(200) NOT NULL default '',
  `edemo_mode` varchar(200) NOT NULL default '',
  `emedia_folder` varchar(200) NOT NULL default '',
  `ecats_per_page` varchar(200) NOT NULL default '',
  `eupload_fields` varchar(200) NOT NULL default '',
  `eupload_resizex` varchar(200) NOT NULL default '',
  `eupload_resizey` varchar(200) NOT NULL default '',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM;

#
# Dumping data for table `edp_config`
#

INSERT INTO `edp_config` (`ID`, `sitetitle`, `sitecharset`, `sitecontent`, `siteauthor`, `pagesectionhome`, `themename`, `abackground`, `adarkcolor`, `agraycolor`, `alightcolor`, `ebackground`, `elightcolor1`, `eightcolor2`, `earticles`, `econtact`, `enews_per_page`, `ehead_per_page`, `etable_width`, `elinks_per_page`, `enew_days`, `epage_width`, `egd_version`, `epics_per_page`, `edemo_mode`, `emedia_folder`, `ecats_per_page`, `eupload_fields`, `eupload_resizex`, `eupload_resizey`) VALUES (0, '.: Free Software - Stoitsov.com :.', 'charset=windows-1251', 'Free PHP Software - http://software.stoitsov.com', 'Mario Stoitsov, Cyber/SAS', '0', 'mambo', '#FFFFFF', '#000000', 'Gray', '#F0F0F0', '#FFFFFF', '#FFF9DD', '#F5F5F5', 'News', 'FALSE', '3', '20', '90%', '20', '7', '771', '2', '10', 'FALSE', 'MediaFolders', '4', '10', '500', '400'),
(1, '.: Free Software - Stoitsov.com :.', 'charset=windows-1251', 'Free PHP Software - http://software.stoitsov.com', 'Mario Stoitsov, Cyber/SAS', '0', 'mambo_light', '#FFFFFF', '#000000', 'Gray', '#F0F0F0', '#FFFFFF', '#FFF9DD', '#F5F5F5', 'News', 'FALSE', '6', '20', '90%', '20', '7', '771', '2', '10', 'FALSE', 'MediaFolders', '4', '10', '500', '400');
# --------------------------------------------------------

#
# Table structure for table `edp_Dynamic_Page`
#

DROP TABLE IF EXISTS `edp_Dynamic_Page`;
CREATE TABLE `edp_Dynamic_Page` (
  `ID` bigint(20) NOT NULL auto_increment,
  `puHeading` varchar(255) NOT NULL default '',
  `puBody` text NOT NULL,
  `puDate` date NOT NULL default '0000-00-00',
  `puUserID` bigint(20) NOT NULL default '0',
  `puTopic` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`ID`),
  KEY `ID` (`ID`),
  KEY `puDate` (`puDate`),
  KEY `puUserID` (`puUserID`)
) TYPE=MyISAM;

#
# Dumping data for table `edp_Dynamic_Page`
#

INSERT INTO `edp_Dynamic_Page` (`ID`, `puHeading`, `puBody`, `puDate`, `puUserID`, `puTopic`) VALUES (2, 'CONGRATULATIONS', '[p]You have [color=red]EasyDynamicPages [/color]instaled and running.[/p] [p]From now you can easily create, edit, remove dynamic pages and easily include, edit, remove any kind of information on them.[/p]\r\n[p]Right now your admin user name and password are set to [color=red]demo demo[/color]. Don`t forget to change them as soon as possible.[/p]\r\n[p][color=red]ENJOY![/color][/p]', '2003-08-01', 1, 'edp_Dynamic_Page'),
(3, 'Dynamic Page', 'This is an example of a [color=red]Dynamic Page[/color]. You can edit it as an administrator, add and modify its setings and the information posted. You can add or delete as many [color=red]Dynamic Pages[/color] as you want.', '2003-08-10', 1, 'edp_Dynamic_Page');
# --------------------------------------------------------

#
# Table structure for table `edp_gacategories`
#

DROP TABLE IF EXISTS `edp_gacategories`;
CREATE TABLE `edp_gacategories` (
  `ID` bigint(20) NOT NULL auto_increment,
  `DisplayName` varchar(255) NOT NULL default '',
  `PictureFile` varchar(200) NOT NULL default '',
  PRIMARY KEY  (`ID`),
  KEY `ID` (`ID`)
) TYPE=MyISAM;

#
# Dumping data for table `edp_gacategories`
#

# --------------------------------------------------------

#
# Table structure for table `edp_gamediafolders`
#

DROP TABLE IF EXISTS `edp_gamediafolders`;
CREATE TABLE `edp_gamediafolders` (
  `ID` bigint(20) NOT NULL auto_increment,
  `Folder` varchar(50) NOT NULL default '',
  `FolderName` varchar(200) NOT NULL default '',
  `Description` text NOT NULL,
  `Pictures` bigint(20) NOT NULL default '0',
  `PictureFile` varchar(200) NOT NULL default '',
  `Grand` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  KEY `ID` (`ID`),
  KEY `FolderName` (`FolderName`),
  KEY `Folder` (`Folder`)
) TYPE=MyISAM;

#
# Dumping data for table `edp_gamediafolders`
#

# --------------------------------------------------------

#
# Table structure for table `edp_gapictures`
#

DROP TABLE IF EXISTS `edp_gapictures`;
CREATE TABLE `edp_gapictures` (
  `ID` bigint(20) NOT NULL auto_increment,
  `Description` text NOT NULL,
  `PictureSize` varchar(20) NOT NULL default '',
  `FileSize` varchar(20) NOT NULL default '',
  `PictureFile` varchar(50) NOT NULL default '',
  `Folder` bigint(20) NOT NULL default '0',
  `Date` date NOT NULL default '0000-00-00',
  PRIMARY KEY  (`ID`),
  KEY `ID` (`ID`),
  KEY `Folder` (`Folder`),
  KEY `Date` (`Date`),
  KEY `PictureFile` (`PictureFile`)
) TYPE=MyISAM;

#
# Dumping data for table `edp_gapictures`
#

# --------------------------------------------------------

#
# Table structure for table `edp_Help_Page`
#

DROP TABLE IF EXISTS `edp_Help_Page`;
CREATE TABLE `edp_Help_Page` (
  `ID` bigint(20) NOT NULL auto_increment,
  `puHeading` varchar(255) NOT NULL default '',
  `puBody` text NOT NULL,
  `puDate` date NOT NULL default '0000-00-00',
  `puUserID` bigint(20) NOT NULL default '0',
  `puTopic` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`ID`),
  KEY `ID` (`ID`),
  KEY `puDate` (`puDate`),
  KEY `puUserID` (`puUserID`)
) TYPE=MyISAM;

#
# Dumping data for table `edp_Help_Page`
#

INSERT INTO `edp_Help_Page` (`ID`, `puHeading`, `puBody`, `puDate`, `puUserID`, `puTopic`) VALUES (2, 'Why Easy?', '[p]Many reasons:[/p][ul]No needs of script or html knowlege[br]No ftp uploads or sinhronizations[br]Simple posting of information[br]Simple dynamical creation of new pages[br]Easy to change all preferences[/ul][p]And more... You only have to enter as a registered user[/p]', '2003-08-11', 1, 'edp_Help_Page'),
(3, 'Why DynamicPages?', 'Because you can create, edit or delete pages and the information they contain remoutly. No ftp, no telnet with the remoute server. Just an internet connection and your password of a registered user. You can do all operatinos via internet from everywhere.', '2003-08-11', 1, 'edp_Help_Page'),
(4, 'Main Structure', '[p][color=red][b]EasyDynamicPages[/b][/color] is an integrated application which consist of some [color=red]StaticPages[/color]  with dynamical content as EasyBookMarker, EasyClassifield, Easy-E-Cards, EasyGallery. [color=red][b]EasyDynamicPages[/b][/color] system also has capability to operate with [color=red]DynamicalPages[/color] you can create and modify as you want.[/p]\r\n[p]Each of these pages ([color=red]Static or Dynamic[/color]) consist of: [ul][color=red]Left Block[/color] which usualy can carry menu options and some important links[br][color=red]Center Block[/color] where the information is posted and can contain everything - images, links, scripts ...[br][color=red]Right Block[/color] which is optional.[/ul][/p][p]Left and Right Blocks as well as the information of the Center block are strictly separeted from page to page. They can be different for the different pages and the [color=red]title[/color] of the page is mentioned as a [color=red]topic[/color] in the information items. [/p][p]All topics can be seen and searched via [color=red]FrontNews[/color] page or how you call the home page of the site.[/p]', '2003-08-11', 1, 'edp_Help_Page'),
(5, 'Separation Principle', '[h2]Search Engine and Author List[/h2]\r\n[p]In the [color=red]Search window[/color] on the Left Block you can seach for information included only within the given DynamicPage.[/p][p] Only the same [color=red]Search window[/color] of the [color=red]FrontNews[/color] page gives you possibility to search all pages (or topics). This keeps the data clear, separeted and well structured.[/p] [p]The same holds also for the [color=red]Author List[/color] (a link on the Left Blocks). It shows who is posting on the particular page or on all pages (from FrontNews page).[/p]\r\n[h2]Posting data (news)[/h2]\r\n[p]The same separation principle is valid when adding data to pages. You can add data ([color=red]news[/color]) only trough a particular page and it automatically is labeled by the page title further associated with the topic of the [color=red]news[/color][/p].\r\n[h2]Configurations[/h2]\r\n[p]Again, from the given particular page, one can change its settings: [color=red]title, color, Left and Right Blocks[/color] and so on.[/p]', '2003-08-11', 1, 'edp_Help_Page'),
(6, 'Site Config', '[p]The link [color=red]Site Config[/color] from the LeftBlock, when logged as administrator, modifies all global items and preferences of the [b][color=red]EasyDinamicPages[/color][/b] application.[/p][p]A particular [color=red]DynamicalPage[/color] can be modified by the link [color=red]Page Edit[/color] from the LeftBlock, when logged as administrator.[/p]', '2003-08-11', 1, 'edp_Help_Page'),
(7, 'Site Config', '[p]The link [color=red]Site Config[/color] from the LeftBlock, when logged as administrator, modifies all global items and preferences of the [b][color=red]EasyDinamicPages[/color][/b] application.[/p]', '2003-08-25', 1, 'edp_Help_Page'),
(8, 'Page Edit', '[p]A particular [color=red]DynamicalPage[/color] can be modified by the link [color=red]Page Edit[/color] from the LeftBlock, when logged as administrator.[/p]', '2003-08-25', 1, 'edp_Help_Page'),
(9, 'Add Page', '[p]A particular [color=red]DynamicalPage[/color] can be created by the link [color=red]Add Page[/color] from the LeftBlock, when logged as administrator.[/p]\r\n[p]The new DynamicPage is created with an arbitrary name, color and Left/Right Blocks. They are supposed to be changed using the link [color=red]Page Edit[/color] from the LeftBlock.[/p]', '2003-08-25', 1, 'edp_Help_Page'),
(10, 'Delete Page', '[p]A particular [color=red]DynamicalPage[/color] can be deleted by the link [color=red]Delete Page[/color] from the LeftBlock, when logged as administrator.[/p]\r\n[p]The page is deleted together with its  posted news. They cannot be seen and restored anymore[/p]', '2003-08-25', 1, 'edp_Help_Page'),
(11, 'Add User', '[p]New registered or admin user can be added by the link [color=red]Add User[/color] from the LeftBlock, when logged as administrator.[/p]', '2003-08-25', 1, 'edp_Help_Page'),
(12, 'Manage Users', '[p]Users account can be modified by the link [color=red]Manage Users[/color] from the LeftBlock, when logged as administrator.[/p]', '2003-08-25', 1, 'edp_Help_Page'),
(13, 'Add News', '[p]Particular information on a particular [color=red]DynamicalPage[/color] can be added by the registered users using the link [color=red]Add News[/color] from the LeftBlock, when logged as registered user.[/p]', '2003-08-25', 1, 'edp_Help_Page'),
(14, 'Login/Logout', '[p]One can Login or Logout the [color=red]EasyDynamicalPages[/color] using the link [color=red]Login[/color] or [color=red]Logout[/color] from the LeftBlock.[/p]', '2003-08-25', 1, 'edp_Help_Page'),
(15, 'Themes', '[p]One can choose the theme which is used by [color=red]EasyDinamicPages[/color] system. This can be done by the drop down menu in the [color=red]Site Config[/color] menu. [/p]\r\n[p]There one can additionaly modify some restricted features of the theme choosen.[/p]\r\n[p]Everyone can create new themes. The rules are the following:\r\n[ul]Create a directory in the themes folder with a given name (e.g. `test`). This name will be the name of the new theme (in this example test).[/ul]\r\n[ul]In the directory `test` you should cteate a file `index.php` which is normally using css.php and images with the appropriate subdirectoties from the directory `test`.[/ul][/p]\r\n[p] The easiest way to create new theme is simply to coppy one theme, already available in the folder `themes` (e.g., the theme `main`) under a different name (e.g., the theme `test`). Then you can modify all information in the new folder `test`. The file index.php will contain the most important information and rules.[/p]', '2003-08-25', 1, 'edp_Help_Page'),
(16, 'Left/Right Blocks', '[p]One can choose which Left and/or Right Blocks are included in a particular [color=red]DinamicPage[/color] in the [color=red]EasyDinamicPages[/color] system. This can be done by the drop down Left and/or Right menu in the particular [color=red]Edit Page[/color] menu. You can add or remove a Block, rearrange the order of the Blocks already choosen.[/p]\r\n[p]If the LeftBlock is emty - no LeftBlock field on the page will appear.[/p]\r\n[p]There, one can additionaly modify the color and the title (topic) of the page choosen.[/p]\r\n[p]Everyone can create new Blocks. They are simply BlockName.php files in the folder /admin/Blocks. The rules are the following:\r\n[ul]NewBlockName part of a file NewBlockName.php is simply the name of the new block.[/ul]\r\n[ul]To fill in the content of the NewBlockName.php you can inspect some of the block files already available in the /admin/Blocks/ folder.[/ul][/p]\r\n[p] The easiest way to create new block is simply to coppy one file, already available in the folder /admin/Blocks/ (e.g., the file BlockName.php) under a different name (e.g., NewBlockName.php). Then, you can modify all information in the new NewBlockName.php file. [/p]\r\n[p]No difference between BlockName.php files used for the Left or the Right Block so you should make experiments untill the block file looks good in both possitions.[/p]', '2003-08-25', 1, 'edp_Help_Page');
# --------------------------------------------------------

#
# Table structure for table `edp_pconfig`
#

DROP TABLE IF EXISTS `edp_pconfig`;
CREATE TABLE `edp_pconfig` (
  `ID` bigint(10) NOT NULL auto_increment,
  `dpFREE` varchar(10) NOT NULL default '',
  `dpFREED` varchar(100) NOT NULL default '',
  `dpFREET` varchar(20) NOT NULL default '',
  `dpLBData` varchar(200) NOT NULL default '',
  `dpRBData` varchar(200) NOT NULL default '',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM;

#
# Dumping data for table `edp_pconfig`
#

INSERT INTO `edp_pconfig` (`ID`, `dpFREE`, `dpFREED`, `dpFREET`, `dpLBData`, `dpRBData`) VALUES (1, '#600040', 'staticpages/easypublish', 'edp_Front_News', 'ComrsialSoftware:Donations', 'Promote:RespectedSites:GetPowered:Donations'),
(4, '#74000B', 'staticpages/easybookmarker', 'edp_Easy_Book_Marker', 'StoitsovCom', ''),
(5, '#007469', 'staticpages/easyclassifields', 'edp_Easy_Classifield', 'Promote', ''),
(3, '#006489', 'staticpages/easyecards', 'edp_Easy_E-Cards', 'ComrsialSoftware', ''),
(6, '#00259D', 'staticpages/easygallery', 'edp_Easy_Gallery', 'Donations:RespectedSites', ''),
(7, 'green', 'dynamicpages', 'edp_Dynamic_Page', 'RespectedSites:ComrsialSoftware', 'StoitsovCom:AdvertizementAlinea:ShareCode:Promote'),
(8, '#332017', 'dynamicpages', 'edp_Help_Page', 'Donations', 'StoitsovCom:ShareCode:Promote:AdvertizementAlinea'),
(2, '#200080', 'staticpages/easycalendar', 'edp_Easy_Calendar', 'CoolProjects', '');
# --------------------------------------------------------

#
# Table structure for table `edp_pupublish`
#

DROP TABLE IF EXISTS `edp_pupublish`;
CREATE TABLE `edp_pupublish` (
  `ID` bigint(20) NOT NULL auto_increment,
  `puHeading` varchar(255) NOT NULL default '',
  `puBody` text NOT NULL,
  `puDate` date NOT NULL default '0000-00-00',
  `puUserID` bigint(20) NOT NULL default '0',
  `puTopic` varchar(255) NOT NULL default '',
  `puTopicID` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  KEY `ID` (`ID`),
  KEY `puDate` (`puDate`),
  KEY `puUserID` (`puUserID`)
) TYPE=MyISAM;

#
# Dumping data for table `edp_pupublish`
#

INSERT INTO `edp_pupublish` (`ID`, `puHeading`, `puBody`, `puDate`, `puUserID`, `puTopic`, `puTopicID`) VALUES (20, 'CONGRATULATIONS', '[p]You have [color=red]EasyDynamicPages [/color]instaled and running.[/p] [p]From now you can easily create, edit, remove dynamic pages and easily include, edit, remove any kind of information on them.[/p]\r\n[p]Right now your admin user name and password are set to [color=red]demo demo[/color]. Don`t forget to change them as soon as possible.[/p]\r\n[p][color=red]ENJOY![/color][/p]', '2003-08-01', 1, 'edp_Dynamic_Page', 2);
# --------------------------------------------------------

#
# Table structure for table `edp_puusers`
#

DROP TABLE IF EXISTS `edp_puusers`;
CREATE TABLE `edp_puusers` (
  `ID` bigint(20) NOT NULL auto_increment,
  `puUsername` varchar(50) NOT NULL default '',
  `puPassword` varchar(50) NOT NULL default '',
  `puScreenName` varchar(200) NOT NULL default '',
  `puMail` varchar(255) NOT NULL default '',
  `puAdmin` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  KEY `ID` (`ID`),
  KEY `puAdmin` (`puAdmin`),
  KEY `puScreenName` (`puScreenName`),
  KEY `puUsername` (`puUsername`)
) TYPE=MyISAM;

#
# Dumping data for table `edp_puusers`
#

INSERT INTO `edp_puusers` (`ID`, `puUsername`, `puPassword`, `puScreenName`, `puMail`, `puAdmin`) VALUES (1, 'demo', 'demo', 'Demo User', 'demo@demo.com', 1);
# --------------------------------------------------------

#
# Table structure for table `edp_usersonline`
#

DROP TABLE IF EXISTS `edp_usersonline`;
CREATE TABLE `edp_usersonline` (
  `timestamp` int(15) NOT NULL default '0',
  `ip` varchar(40) NOT NULL default '',
  PRIMARY KEY  (`timestamp`),
  KEY `ip` (`ip`)
) TYPE=MyISAM;

#
# Dumping data for table `edp_usersonline`
#

INSERT INTO `edp_usersonline` (`timestamp`, `ip`) VALUES (1071972479, '127.0.0.1'),
(1071972471, '127.0.0.1'),
(1071972457, '127.0.0.1'),
(1071972459, '127.0.0.1'),
(1071972405, '127.0.0.1'),
(1071972401, '127.0.0.1'),
(1071972389, '127.0.0.1'),
(1071972410, '127.0.0.1');

