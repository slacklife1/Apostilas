<?
/*      ******************************************************************
        **********************  EasyDynamicPages  ************************
	******************************************** software.stoitsov.com  */

// CSS Style - Edit to fit your site design
echo "<style type=\"text/css\">
body {  font: 12px Arial, Helvetica; color:black; margin: 0px 0px 0px 0px; padding: 0px 0px 0px 0px;background-color:        ".$FBG."; scrollbar-DarkShadow-Color: ".$FDC.";scrollbar-Track-Color:   ".$FDC.";  scrollbar-Face-Color:      ".$FDC.";scrollbar-Shadow-Color:  ".$FBG."; scrollbar-Highlight-Color:  ".$FBG.";scrollbar-3dLight-Color: ".$FDC.";  scrollbar-Arrow-Color:     ".$FBG.";}
.f_text     {font: 11px Arial, Helvetica; color: ".$FDC.";  background-color: ".$FBG."; border: 1px dotted ".$EPS.";}
.info_panel {font: 11px Arial, Helvetica; color: ".$FDC.";  background-color: ".$FLC."; border: 1px dotted ".$EPS.";}
.f_button   {font: 11px Arial, Helvetica; color: ".$FBG."; background-color: ".$EPS.";  border: 1px solid black;}
.strong {font: 12px Arial, Helvetica; color:                ".$EPS."; font-weight:bold;}
table.main_tbl {border: 1px dotted                          ".$EPS.";}
.h1s {font: 18px Verdana; font-weight:bold; color:          ".$EPS.";}
.h1m {font: 18px Verdana; font-weight:bold; color: yellow;}
.h2s {font: 12px Verdana; font-weight:bold; color:          ".$EPS.";}
.h3s {font: 12px Arial; font-weight:bold; color:            ".$EPS.";}
a:link.normal, a:visited.normal {font: 11px Verdana; color: ".$EPS."; text-decoration:none;}
a:link.normalc, a:visited.normalc {font: 16px Arial; color: ".$EPS."; text-decoration:none; font-weight:bold;}
a:link.normali, a:visited.normali {font: 11px Arial; color: ".$EPS."; text-decoration:none; font-style:italic;}
.small {font: 10px Arial, Helvetica; color: gray;}
.menuL {font: 9px Verdana; color: yellow;}
.menuR {font: 9px Verdana; color: black;}
p {font: 12px Arial, Helvetica;}
p.news {font: 12px Arial, Helvetica; margin-top:5; margin-bottom:5;}
td {font: 12px Arial, Helvetica; color: black;}
a:link.menuL, a:visited.menuL {font: 11px Arial; color: white; text-decoration:none;}
a:hover.menuL {font: 11px Arial; color: yellow; text-decoration:none;}
a:link.menuR, a:visited.menuR {font: 11px Arial; color: gray; text-decoration:none;}
a:hover.menuR {font: 11px Arial; color: yellow; text-decoration:none;}
a:link.invert, a:visited.invert {font: 11px Arial; color: yellow; text-decoration:none;}
a:hover.invert {font: 11px Arial; color: white; text-decoration:none;}
a:hover.normal {font: 11px Verdana; color: red; text-decoration:none;}
a:hover.normalc {font: 16px Arial; color: red; text-decoration:none; font-weight:bold;}
a:hover.normali {font: 11px Arial; color: red; text-decoration:none; font-style:italic;}
</style>";

?>

