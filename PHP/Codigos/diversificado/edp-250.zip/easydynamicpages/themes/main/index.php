<?
/*      ******************************************************************
        **********************  EasyDynamicPages  ************************
	******************************************** software.stoitsov.com  */
/*
        The Principle for the theme creation is the following:
        1) all css files images and so on should reside in a named directory (e.g., 'main') under
           the subdirectory 'themes', The name of this directory (e.g., 'main') is the name of the theme.
        2) Input variables one can use sre:
           a)  $LeftBlock, $ResultHtml and $RightBlock which carry the html information for the LeftBlock,
               CentralPage and RightBlock, respectively, including the clolor information $EPS
               of the particular page with given $PageSection. These colors and information are controlled by
               the particular PageEdit script.
           b)  $PageSection is a number which shows which page is executed; $Easy[$i] for $i=0 to $i=$FREEMAX-1
               contains the color data in the dbase for already creted pages.
           c)  Collor Arrays carry information for the theme ($FREEA colors as e.g., $FREEA["GrayColor"]).
               They are used in this file only. If not defined here they are defined and controlled by ConfigSetup script.
           e)  Other variables as $sitetitle, $sitecharset, $sitecontent, $siteauthor
        ******************************************** software.stoitsov.com  */

$version="2.5";
// Particular page color
$EPS=$Easy[$PageSection];
// Theme colors
$FDC=$FREEA["DarkColor"];
$FBG=$FREEA["Background"];
$FLC=$FREEA["LightColor"];

$theme_path=$edp_relative_path."themes/".$ThemeName;

// Generates white space
function Tr($width=1,$height=1) {global $edp_relative_path; return "<img src='".$edp_relative_path."images/tr.gif' width='$width' height='$height' alt='' border='0'>";}

// header
echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<html><head><title>$sitetitle</title>
<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; $sitecharset\">
<META NAME=\"description\" CONTENT=\" $sitecontent \">
<META NAME=\"author\" CONTENT=\" $siteauthor \"> ";
include_once $theme_path."/style/css.php";
echo "</head>";

// Start HTML BODY
echo "<body leftmargin='0' rightmargin='0' topmargin='0' rightmargin=0>";
echo "<table border=0 width=100% cellspacing=0 cellpadding=0><tr><td>";
echo "<table border=0 width=100% cellspacing=0 cellpadding=0>
       <tr><td background='".$theme_path."/images/bkg.gif' height='14' width=100% colspan=2></td></tr>
       <tr>
        <td bgcolor=".$EPS." align=left  nowrap><span class=h1m>&nbsp;EasyDynamicPages ".$version."</span><br>".TR(5,4)."<br></td>
        <td bgcolor=".$EPS." align=right nowrap><span class=h1m>".$FREET[$PageSection]."&nbsp;&nbsp;</span><br>".TR(5,4)."<br></td>
       </tr>
       <tr><td background='".$theme_path."/images/bkg.gif' height='14' width=100% colspan=2></td></tr>
       <tr><td bgcolor='".$EPS."' height='14' width=100% colspan=2></td></tr>
      </table>";
echo "<table border=0 width=100% cellspacing=0 cellpadding=0>
      <tr><td  bgcolor=$Easy[$PageSection]  valign=top align=center>";

// LeftBlock
$LeftBlock.=$Login."<br>".$Adminmenu."<br><br>";
for ($i=1; $i<Count($LeftBlockArray); $i++) { $LeftBlock.=$LeftBlockArray[$i]; }
echo "<table border=0 cellspacing=0 cellpadding=0  width=142 align=center>
      <tr> <td>&nbsp;&nbsp;</td><td><table border=0 cellspacing=0 cellpadding=0  width=142 align=center>";
              for ($i=0; $i<$FREEMAX; $i++) {
                if($i==$PageSection){ echo "<tr><td valign=top align=left  background='".$theme_path."/images/bkg.gif'>&nbsp;</td><td><a href='".$edp_relative_path.$FREED[$i]."/index.php?PageSection=".$i."' class=invert nowrap>&nbsp;&nbsp;&nbsp;&nbsp;$FREET[$i]</a><br></td></tr>";
                } else { echo "<tr><td valign=top align=left bgcolor='".$Easy[$i]."'>&nbsp;</td><td><a href='".$edp_relative_path.$FREED[$i]."/index.php?PageSection=".$i."' class=invert nowrap>&nbsp;&nbsp;&nbsp;&nbsp;$FREET[$i]</a></td></tr>"; }
              }
echo "</table> </td> <td>&nbsp;&nbsp;</td> </tr>
      <tr>
          <td>&nbsp;&nbsp;</td>
          <td><br>$LeftBlock</td>
          <td>&nbsp;&nbsp;</td>
     </tr>";
  echo "</table> </td>";
// LeftBlock end

// Main
// SpacerLeft+MainPage+SpacerRight
echo "<td valign=top bgcolor=white>&nbsp;&nbsp;&nbsp;&nbsp;<br></td>
      <td width=100% valign=top bgcolor=white><br>";
      echo "<script language='JavaScript'>function YesNo(fURL,fMessage) {
      if (confirm(fMessage)) { self.top.location.href=fURL; } }
      </script>\n";
      echo $ResultHtml;
      echo "</td>";
echo "<td valign=top bgcolor=white><br>&nbsp;&nbsp;<br></td>
      <td valign=top><br>&nbsp;&nbsp;<br></td>";

$RightBlock="";
for ($i=0; $i<Count($RightBlockArray); $i++) { $RightBlock.=$RightBlockArray[$i]; }
// RightBlock START
if($RightBlock!==""){
  echo "<td>".Tr(10,1)."<br></td>
	<td bgcolor='#E4E4E4'>".Tr(10,1)."<br></td>
	<td bgcolor='#E4E4E4' valign=top>".Tr(130,10)."<br>";

  // Right menu : START
  echo "<div align=right><span class=menuR><b>SIDEBAR</b></span></div><br>";
        echo $RightBlock;
  // Right menu : END
	echo "</td>
        <td bgcolor='#E4E4E4'>".Tr(10,1)."<br></td>";
         }
    echo "<td bgcolor='".$Easy[$PageSection]."'>".Tr(11,1)."<br></td>";
echo "</tr></table>";

// Last (bottom)  table
echo "
      <table border=0 width=100% cellspacing=0 cellpadding=0>
       <tr><td bgcolor='".$EPS."' height='14' width=100% colspan=3></td></tr>
       <tr><td background='".$theme_path."/images/bkg.gif' height='14' width=100% colspan=3></td></tr>
       <tr>
       <td bgcolor=".$EPS." align=left  nowrap><span class=h1m>&nbsp;EasyDynamicPages ".$version."</span><br>".TR(5,4)."<br></td><td bgcolor=".$EPS." ></td>
       <td bgcolor=".$EPS." align=right nowrap><span class=h1m>".$FREET[$PageSection]."&nbsp;&nbsp;</span><br>".TR(5,4)."<br></td>
      </tr>
       <tr><td background='".$theme_path."/images/bkg.gif' height='14' width=100% colspan=3></td></tr>
       <tr>
           <td background='".$theme_path."/images/bkg.gif' height='14' width=100% colspan=0></td>
           <td width='100%' align=right bgcolor=white valign=top  nowrap ><font color='".$EPS."'><b>&nbsp;&nbsp;Free Software</b> by </font><a href='http://software.stoitsov.com' class=vormal target=_stoitsov.com>Software.Stoitsov.com</a>&nbsp;&nbsp;<br><font color='".$EPS."'>&nbsp;&nbsp;To keep it free & developing&nbsp;&nbsp;</font></td>
           <td width='100%' align=center valign=middle  nowrap background='".$theme_path."/images/bkg.gif'>
           <a href='https://www.paypal.com/affil/pal=mario%40stoitsov.com' target=_donate ><img src='".$edp_relative_path."images/donate.gif' width='110' height='23' alt='Support us!' border='0' ></a></td>
      </tr>
      <tr><td background='".$theme_path."/images/bkg.gif' height='14' width=100% colspan=3 style='padding: 15px;'></td></tr>";

// vote hotscripts start
       echo "
       <tr><td background='".$theme_path."/images/bkg.gif' height='14' width=100% colspan=3></td></tr>
       <tr>
           <td background='".$theme_path."/images/bkg.gif' height='1' width=100% colspan=0></td>
           <td width='100%' align=left bgcolor=white valign=middle  nowrap >
            <font color='".$EPS."'><b>&nbsp;&nbsp;&nbsp;If you like the script, please vote for it.&nbsp;<br>&nbsp;&nbsp;&nbsp;We do appreciate this much.&nbsp;</font>
           </td>
           <td width='100%' align=center valign=middle  nowrap background='".$theme_path."/images/bkg.gif'>
            <form action='http://www.hotscripts.com/cgi-bin/rate.cgi' method='POST' target='_new'>
            <input type=hidden name='ID' value='25604'>
            &nbsp;&nbsp;&nbsp;&nbsp;<a href='http://www.hotscripts.com/Detailed/25604.html'><b>HotScripts.com</b></a> :<br>
            <select name='rate' size='1' style='font-size:10px;'>
            <option selected value='5'>Excellent!</option>
            <option value='4'>Very Good</option>
            <option value='3'>Good</option>
            <option value='2'>Fair</option>
            <option value='1'>Poor</option>
            </select>&nbsp;<input type='submit' value='Rate It!' style='font-size:10px;'></form>
           </td>
      </tr>
      <tr><td background='".$theme_path."/images/bkg.gif' height='14' width=100% colspan=3 style='padding: 15px;'></td></tr>";
// vote hotscripts end

echo "</table></td></tr></table></body></html>";


?>
