<?
/*      ******************************************************************
        **********************  EasyDynamicPages  ************************
	******************************************** software.stoitsov.com  */
/*
        The Principle for the theme creation is the following:
        1) all css files images and so on should reside in a named directory (e.g., 'main') under
           the subdirectory 'themes', The name of this directory (e.g., 'main') is the name of the theme.
        2) Input variables one can use sre:
           a)  $LeftBlock, $ResultHtml and $RightBlock which carry the html information for the LeftBlock,
               CentralPage and RightBlock, respectively, including the clolor information $EPS
               of the particular page with given $PageSection. These colors and information are controlled by
               the particular PageEdit script.
           b)  $PageSection is a number which shows which page is executed; $Easy[$i] for $i=0 to $i=$FREEMAX-1
               contains the color data in the dbase for already creted pages.
           c)  Collor Arrays carry information for the theme ($FREEA colors as e.g., $FREEA["GrayColor"]).
               They are used in this file only. If not defined here they are defined and controlled by ConfigSetup script.
           e)  Other variables as $sitetitle, $sitecharset, $sitecontent, $siteauthor
        ******************************************** software.stoitsov.com  */

$version="1.5";
// Particular page color
$EPS=$Easy[$PageSection];
// Theme colors
$FDC=$FREEA["DarkColor"];
$FBG=$FREEA["Background"];
$FLC=$FREEA["LightColor"];
$theme_path=$edp_relative_path."themes/".$ThemeName;

// Generates white space
function Tr($width=1,$height=1) {global $edp_relative_path; return "<img src='".$edp_relative_path."images/tr.gif' width='$width' height='$height' alt='' border='0'>";}

// header
echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<html><head><title>$sitetitle</title>
<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; $sitecharset\">
<META NAME=\"description\" CONTENT=\" $sitecontent \">
<META NAME=\"author\" CONTENT=\" $siteauthor \"> ";
include_once $theme_path."/style/css.php";
echo "</head>";

// HTML BODY
echo "<body leftmargin='0' rightmargin='0' topmargin='0' rightmargin=0>";
echo "<table border=0 cellspacing=0 cellpadding=0 width=100%><tr><td>";
echo "<table border=0 cellspacing=0 cellpadding=0 width=100% >
<tr><td  bgcolor='".$FDC."' align=left  ><img src='$theme_path/images/logo.gif' width='300' height='50' alt='' border='0'></td>
    <td bgcolor='".$FDC."'  align=right valign=bottom nowrap >
    <table border=1 cellspacing=0 cellpadding=0  BORDERCOLOR='".$EPS."' BORDERCOLORLIGHT='' BORDERCOLORDARK=''><tr> ";
         $step=9; $jtr=-1;
         for ($i=0; $i<$FREEMAX; $i++) {$jtr=$jtr+1;
           if($i==$PageSection) {
             echo "<td bgcolor='".$EPS."' align=left nowrap><a href='".$edp_relative_path."".$FREED[$PageSection]."/index.php?PageSection=".$PageSection."' class=invert nowrap><font color=$FBG>&nbsp;&#149;</font>&nbsp;$FREET[$PageSection]</a></td>";
           } else {
             echo "<td bgcolor='".$Easy[$i]."' align=left  nowrap><a href='".$edp_relative_path."".$FREED[$i]."/index.php?PageSection=".$i."' class=invert nowrap><font color=$FBG>&nbsp;&#149;</font>&nbsp;$FREET[$i]</a></td>";
           }
           if($jtr==$step && $i!==$FREEMAX-1) {$jtr=-1; echo "</tr><tr>"; }
         }
echo "</tr></table></td></tr>
<tr><td width=100% bgcolor='".$EPS."' colspan=3>".Tr(1,12)."</td></tr>
</table>";

// Second  table : start
echo "<table border=0 cellspacing=0 cellpadding=0 width=100%><tr>";
// Left Block : START
$LeftBlock.=$Login."<br>".$Adminmenu."<br><br>";
for ($i=1; $i<Count($LeftBlockArray); $i++) { $LeftBlock.=$LeftBlockArray[$i]; }
echo "<td bgcolor='".$EPS."' valign='top'>".Tr(12,131)."<br></td>
      <td bgcolor='".$EPS."'>".Tr(10,1)."<br></td>
      <td bgcolor='".$EPS."' valign=top>".Tr(130,1)."<br>";
      echo $LeftBlock;
echo "</td>";
// Left Block : END

// Main page : Start
echo "<td bgcolor='".$EPS."'>".Tr(10,1)."<br></td>
      <td>".Tr(10,1)."<br></td>
      <td valign=top width=100%>".Tr(200,10)."<br>";
      echo "<script language='JavaScript'>function YesNo(fURL,fMessage) {
      if (confirm(fMessage)) { self.top.location.href=fURL; } }
      </script>\n";
      echo $ResultHtml;
      echo "</td>";
// mainpage END

// Right Block : START
$RightBlock="";
for ($i=0; $i<Count($RightBlockArray); $i++) { $RightBlock.=$RightBlockArray[$i]; }
if($RightBlock!=""){
   echo "<td>".Tr(10,1)."<br></td>
	<td bgcolor='#E4E4E4'>".Tr(10,1)."<br></td>
	<td bgcolor='#E4E4E4' valign=top>".Tr(130,10)."<br>";
  // Right Block content : START
   echo "<div align=right><span class=menuR><b>SIDEBAR</b></span></div><br>";
   echo $RightBlock;
  // Right Block content : END
	echo "</td>
        <td bgcolor='#E4E4E4'>".Tr(10,1)."<br></td>";
         }
        echo "<td bgcolor='".$EPS."'>".Tr(11,1)."<br>";
echo "</td>";
// Right Block : END

echo "</tr></table>";
// Second  table : END

// Last (bottom)  table: START
echo "<table border='0' cellspacing='0' cellpadding='0' width='100%'>
<tr><td width=100% bgcolor='".$EPS."'>".Tr(471,12)."</td></tr>
<tr><td width='100%' bgcolor='".$FDC."'>".Tr(1,1)."<br></td>
</tr><tr>
<td width='100%' align=right><font color='".$FDC."'><b>Free Software</b> by </font><a href='http://software.stoitsov.com' class=normal target=_stoitsov.com>Software.Stoitsov.com</a>&nbsp;&nbsp;<br>
<a href='https://www.paypal.com/affil/pal=mario%40stoitsov.com' target=_donate><img src='".$edp_relative_path."images/donate.gif' width='110' height='23' alt='Support us!' border='0' hspace=4 align=right></a>To keep it free & developing:
</td></tr></table>";
// Last (bottom)  table: END



echo "</td></tr></table>";
// Total table : END

echo "</body></html>";

// NB to remove $PageSection unconsistency
// session_unregister("PageSection");

?>
