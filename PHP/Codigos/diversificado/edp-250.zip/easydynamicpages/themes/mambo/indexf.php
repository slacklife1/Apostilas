<?

function NewsOut($News,$short) {
Global $Stoitsov, $FREED, $PageSection, $page, $Easy, $EDP_SELF, $table, $edp_relative_path;

$image_theme_path=$edp_relative_path."themes/mambo_light/images";

$news_topic="Topic: ".str_replace("_"," ",str_replace("edp_","",$News["puTopic"]));
$news_head="<span class=h1s>".$News["puHeading"]."</span>";
$news_author=puShowAuthor($News["puUserID"]);
$news_date=$News["puDate"];
$news_more="";
if($short>=0) {
 $news_body=BBCode2HTML(substr($News["puBody"],0,$short));
 if(strlen($news_body)>=$short-1) { $news_body.=" ..."; $news_more=" <a href='$EDP_SELF&page=individual&table=".$News["puTopic"]."&read=".$News["ID"]."'>Read More ...</a> "; }
} else {
$news_body=BBCode2HTML($News["puBody"]);
}
$news_all= "<table border='0' cellpadding='0' cellspacing='0' width='100%'>
            <tr><td>
              <table border='0' cellpadding='1' cellspacing='0'  width='100%'>
              <tr><td><h3>&nbsp;$news_head</h3></td></tr>
              </table>
              <table border='1' cellpadding='5' cellspacing='0' width='100%'>
              <tr><td valign=top bgcolor=#EEEEEE><dvi id='story'>".$news_body."</dvi></td></tr>
              </table>
              <table border='0' cellpadding='0' cellspacing='0' width='100%'>
               <tr><td align='left'  valign='top' nowrap>&nbsp;".$news_topic."</td><td align='right' valign='top' nowrap >Contributed by ".$news_author." on ".$news_date."</font></td></tr>
               <tr><td align='left'  valign='top' nowrap>&nbsp;".$news_more."</td>";
                 if ((puRegistered($Stoitsov)==2 or $Stoitsov["ID"]==$News["puUserID"])) {
                  if($FREED[$PageSection]=="dynamicpages") {
                   $news_all.=  "<td align='right' nowrap>&nbsp;&nbsp; [ ";
                   $news_all.=  "<a href='$EDP_SELF&page=edit_news&id=".$News["ID"]."&home=1'>Edit-Move-Add to Home</a> | ";
                   $news_all.=  "<a href='$EDP_SELF&page=edit_news&id=".$News["ID"]."&home=0'>Edit-Move</a> | <a href=\"#\" onClick=\"javascript:YesNo('$EDP_SELF&action=delete&id=".$News["ID"]."','Are you sure, you want to delete?');\">Delete</a>";
                   $news_all.=  "]&nbsp;&nbsp;</td>";
                  } else {
                   if($page!="individual") {
                   $news_all.=  "<td align='right' nowrap>&nbsp;&nbsp; [ ";
                   $news_all.=  "<a href='$EDP_SELF&page=edit_news&id=".$News["ID"]."'>Edit-Move</a> | <a href=\"#\" onClick=\"javascript:YesNo('$EDP_SELF&action=delete&id=".$News["ID"]."','Are you sure, you want to remove from Home?');\">Remove from Home</a>";
                   $news_all.=  "]&nbsp;&nbsp;</td>";
                    }
                  }
                 }
 $news_all.="  </tr>
              </table>
             </td></tr></table><br>";
return $news_all;
}

?>
