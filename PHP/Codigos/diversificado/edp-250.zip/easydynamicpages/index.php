<?
/*      ******************************************************************
        **********************  EasyDynamicPages  ************************
	******************************************** software.stoitsov.com  */
include_once "admin/serverdata.php";
mysql_connect($Easy["mysql_host"],$Easy["mysql_user"],$Easy["mysql_pass"]);
mysql_select_db($Easy["mysql_base"]);
$home=mysql_fetch_array(mysql_query("SELECT dpFREED FROM edp_pconfig WHERE ID=1"));
Header("Location:".$home["dpFREED"]);

// $edp_http_path="http://".$HTTP_SERVER_VARS["HTTP_HOST"].str_replace("index.php",'',$HTTP_SERVER_VARS["PHP_SELF"]);
?>


