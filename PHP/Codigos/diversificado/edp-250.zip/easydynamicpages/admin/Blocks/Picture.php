<?
/*      ******************************************************************
        **********************  EasyDynamicPages  ************************
	******************************************** software.stoitsov.com  */
$Block= "<div align=center><a href='http://software.stoitsov.com/free/description.php?software=EasyPublish' target=_stoitsov class=".$menuLlink.">
<img src='".$edp_relative_path."images/EasyPublishLogo_big.gif' height='90' width='105'  alt='EasyPublish!' border='0'></a> </div><br><br>";
?>
