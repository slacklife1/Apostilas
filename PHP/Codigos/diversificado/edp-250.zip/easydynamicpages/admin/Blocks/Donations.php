<?
/*      ******************************************************************
        **********************  EasyDynamicPages  ************************
	******************************************** software.stoitsov.com  */
   $Block= "<span class=".$menuL."><b>Donation</b></span><br>
   <span class=".$menuL.">Our software is
   completely free of charge, unless you decide to
   <a href='/donate/' class=".$menuLlink.">donate us</a>.
   <br><br>";
?>
