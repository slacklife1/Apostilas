<?
/*      ******************************************************************
        **********************  EasyDynamicPages  ************************
	******************************************** software.stoitsov.com  */
// Generates Advertizement for the right MENU
$Block="<span class=".$menuL."><b>Advertizement</b></span><br>
<a href='http://www.alinea.bg' target=_advertizement><img src='".$edp_relative_path."images/banners/alinea1.gif' width='130' height='130' alt='Hosted by' border='0' class=".$menuLlink."></a><br><br>\n";
?>

