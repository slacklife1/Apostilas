<?
/*      ******************************************************************
        **********************  EasyDynamicPages  ************************
	******************************************** software.stoitsov.com  */
        // Generates ShareCode Sites for the right MENU
        $Block=" <span class=".$menuL."><b>Share code</b></span><br>
        <a href='http://www.hotscripts.com' target=_advertizement class=".$menuLlink.">Hot Scripts</a><br>
        <a href='http://www.resourceindex.com/' target=_advertizement class=".$menuLlink.">Resource Index</a><br><br>";
?>
