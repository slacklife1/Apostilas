<?
/*      ******************************************************************
        **********************  EasyDynamicPages  ************************
	******************************************** software.stoitsov.com  */
// Generates Sites on Stoitsov.com for the right MENU
$Block="<span class=".$menuL."><b>More on stoitsov.com</b></span><br>
        <a href='http://mario.stoitsov.com' target=_family class=".$menuLlink.">Mario Stoitsov</a><br>
        <a href='http://angel.stoitsov.com' target=_family class=".$menuLlink.">Angel Stoitsov</a><br>
        <a href='http://valentin.stoitsov.com' target=_family class=".$menuLlink.">Valentin Stoitsov</a><br>
        <a href='http://tolya.stoitsov.com' target=_family class=".$menuLlink.">Tolya Stoitsova</a><br>
        <a href='http://ludmila.stoitsov.com' target=_family class=".$menuLlink.">Ludmila Stoitsova</a><br>
        <a href='http://alex.stoitsov.com' target=_family class=".$menuLlink.">Alex Stoitsov</a><br><br>\n";
?>
