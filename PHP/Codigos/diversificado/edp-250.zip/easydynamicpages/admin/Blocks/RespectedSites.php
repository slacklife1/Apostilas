<?
/*      ******************************************************************
        **********************  EasyDynamicPages  ************************
	******************************************** software.stoitsov.com  */
// Generates Respected Sites for the right MENU
$Block="<span class=".$menuL."><b>Respect</b></span><br>
        <a href='http://www.opensource.org' target=_advertizement class=".$menuLlink.">Open Source Initiative</a><br>
        <a href='http://www.linux.org/' target=_advertizement class=".$menuLlink.">Linux Society</a><br>
        <a href='http://www.php.net' target=_advertizement class=".$menuLlink.">PHP Developers</a><br>
        <a href='http://www.mysql.com' target=_advertizement class=".$menuLlink.">MySQL Developers</a><br>
        <a href='http://www.boutell.com/gd/' target=_advertizement class=".$menuLlink.">GD Developers</a><br><br>\n";
?>
