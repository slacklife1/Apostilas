<?
/*      ******************************************************************
        **********************  EasyDynamicPages  ************************
	******************************************** software.stoitsov.com  */
// Generates Cool Projects for the right MENU
$Block="<span class=".$menuL."><b>Cool projects</b></span><br>
        <a href='http://www.phpmyadmin.net' target=_advertizement class=".$menuLlink.">phpMyAdmin</a><br>
        <a href='http://www.thedezine.com/' target=_advertizement class=".$menuLlink.">theDezine</a><br><br>\n";
?>
