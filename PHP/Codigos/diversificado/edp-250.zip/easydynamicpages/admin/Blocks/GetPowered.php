<?
/*      ******************************************************************
        **********************  EasyDynamicPages  ************************
	******************************************** software.stoitsov.com  */
        $PowerBlock[0]="<a href='/free/easybookmarker/' class=".$menuLlink.">".$Alt["EasyBookmarker"]."<br><br>Get your site <img src='".$edp_relative_path."images/banners/powerbookmarker90x30.gif' width='90' height='30' alt='Get powered!' border='0' class=".$menuLlink."></a><br><br>";
        $PowerBlock[1]="<a href='/free/easygallery/' class=".$menuLlink.">".$Alt["EasyGallery"]."<br><br>Get your site <img src='".$edp_relative_path."images/banners/powergallery90x30.gif' width='90' height='30' alt='Get powered!' border='0' class=".$menuLlink."></a><br><br>";
        $PowerBlock[2]="<a href='/free/easyclassifields/' class=".$menuLlink.">".$Alt["EasyClassifields"]."<br><br>Get your site <img src='".$edp_relative_path."images/banners/powerclassifields90x30.gif' width='90' height='30' alt='Get powered!' border='0' class=".$menuLlink."></a><br><br>";
        $PowerBlock[3]="<a href='/free/easye-cards/' class=".$menuLlink.">".$Alt["EasyE-Cards"]."<br><br>Get your site <img src='".$edp_relative_path."images/banners/powere-cards90x30.gif' width='90' height='30' alt='Get powered!' border='0' class=".$menuLlink."></a><br><br>";
        $PowerBlock[4]="<a href='/free/easypublish/' class=".$menuLlink.">".$Alt["EasyPublish"]."<br><br>Get your site <img src='".$edp_relative_path."images/banners/powerpublish90x30.gif' width='90' height='30' alt='Get powered!' border='0' class=".$menuLlink."></a><br><br>";
        $Block="<div style='padding: 5 5 5 5; text-align:center;'>
        <div align=left><span class=".$menuL."><b>Gain power</b></span></div><br>
        ".$PowerBlock[rand(0,Count($PowerBlock)-1)]."</div><br><br>";
?>
