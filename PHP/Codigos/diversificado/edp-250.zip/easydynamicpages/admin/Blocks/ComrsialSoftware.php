<?
/*      ******************************************************************
        **********************  EasyDynamicPages  ************************
	******************************************** software.stoitsov.com  */
$Block= "<span class=".$menuL."><b>Commercial software</b></span><br>
   <span class=".$menuL.">We are also developing
   a large number of commercial scripts. If you are interested,
   <a href='/donate/?page=contact' class=".$menuLlink.">describe your interest</a>.
   </font></span><br><br>";
?>
