<?
/*      ******************************************************************
        **********************  EasyDynamicPages  ************************
	******************************************** software.stoitsov.com  */

    if($op=="ConfigUpdate") {ConfigUpdated($xdpFREE, $xdpFREED, $xdpFREET, $xdpLBData, $xdpRBData, $xxL, $xxR);}
    $result=mysql_query("SELECT dpFREE, dpFREED, dpFREET, dpLBData, dpRBData FROM edp_pconfig where ID=$FREEID[$PageSection]");
    list($dpFREE, $dpFREED, $dpFREET, $dpLBData, $dpRBData) = mysql_fetch_row($result);
    if(isset($def)) {$dpFREE="red"; $dpFREET="DynamicPage"; $dpLBData="RespectedSites:Donations:ComrsialSoftware"; $dpRBData="Donations:ComrsialSoftware:RespectedSites:StoitsovCom:GetPowered:AdvertizementAlinea:ShareCode:Promote:Picture"; }
    $dpFREET=str_replace("_"," ",str_replace("edp_","",$dpFREET));
    $EmptyBlock="EmptyBlock";
    $spL=preg_split('/:/',$dpLBData);  $spR=preg_split('/:/',$dpRBData);
    $handle=opendir("".$edp_relative_path."/admin/Blocks");
    $blocklist1=""; while ($file = readdir($handle)) {if ( (!ereg("[ ]",$file)) && $file!=="."  && $file!==".." && $file!==" ") {$blocklist1.= "$file";}}
    closedir($handle);  $blocklist1 = explode(".php", $blocklist1); sort($blocklist1);
    $i=0; for ($ii=0; $ii < count($blocklist1); $ii++) {  if($blocklist1[$ii]!="") { $blocklist[$i]=$blocklist1[$ii]; $i=$i+1;}}

    $ResultHtml= "<table  width=100%><tr><td><form action='$EDP_SELF&page=config&do=add_page&du=dpage' method='post' NAME='formFREE'><left><font class='title'><b>DYNAMIC PAGE (".$FREET[$PageSection].") CONFIG</b></font></left><br><br></td></tr></table><br>";
    $ResultHtml.="<table width=100%><tr><td>
         <table border='0'>
           <tr><td><b>Page Color:</b></td><td><INPUT NAME='xdpFREE' SIZE=7 MAXLENGTH=7 VALUE=$dpFREE> <INPUT TYPE='button' ONCLICK=selectColor('xdpFREE') VALUE='Select'></td></tr>
           <tr><td><b>Directory:</b></td><td><input type='hidden' name='xdpFREED' value='$dpFREED' size='40' maxlength='200'>$dpFREED</td></tr>
           <tr><td><b>Title(Topic):</b></td><td><input type='text' name='xdpFREET' value='$dpFREET' size='40' maxlength='200'></td></tr>
         </table><br>
         <center><dvi><b>BLOCKS CHECK LIST</b><li>Check the checkbox next to a particular Block in order to delete it.</li></dvi><br><br></center>
         <table>
            <tr><td align=center valign=top><b>LEFT BLOCKS (select)</b></td><td>".puTr(6,1)."</td><td align=center  valign=top><b>RIGHT BLOCKS (select)</b></td></tr>";

            $cTable=count($blocklist); $ResultHtmlL="";  $ResultHtmlR=""; $NumL=-1; $NumR=-1;
            for ($i=0; $i < $cTable;  $i++) {
                  if ( preg_match("/$blocklist[$i]/",$dpLBData) ) {
                      $NumL=$NumL+1;
                      $ResultHtmlL.="$NumL&nbsp;&nbsp;<select name=\"xdpLBData[$NumL]\">";
                      for ($j=0; $j < $cTable; $j++) {
                          $ResultHtmlL.="<option   value='".$blocklist[$j]."'";
                          if($blocklist[$j]==$spL[$NumL]) {$ResultHtmlL.="selected"; $checkL=$blocklist[$j];  }
                          $ResultHtmlL.=">".$blocklist[$j];}
                          $ResultHtmlL.="</select><input type='checkbox' name=\"xxL[$NumL]\" value='".$checkL."' ><br>";}
                  if ( preg_match("/$blocklist[$i]/",$dpRBData) ) {
                      $NumR=$NumR+1;
                      $ResultHtmlR.="&nbsp;&nbsp;$NumR&nbsp;&nbsp;<select name=\"xdpRBData[$NumR]\">";
                      for ($j=0; $j < $cTable; $j++) {
                          $ResultHtmlR.="<option   value='".$blocklist[$j]."'";
                          if($blocklist[$j]==$spR[$NumR]) {$ResultHtmlR.="selected"; $checkR=$blocklist[$j];}
                          $ResultHtmlR.=">".$blocklist[$j];}
                          $ResultHtmlR.="</select>";
                          if($checkR!==$EmptyBlock) {$ResultHtmlR.= "<input type='checkbox' name=\"xxR[$NumR]\" value='".$checkR."' >";}
                          $ResultHtmlR.="<br>";}
            }

            $NumL=$NumL+1; $ResultHtmlL.="<table><tr><td align=left><br>&nbsp;&nbsp;&nbsp;&nbsp;<b>Add New Left Block</b><br>";
            $ResultHtmlL.="&nbsp;&nbsp;&nbsp;&nbsp;<select name=\"xdpLBData[$NumL]\">";
            for ($j=0; $j < $cTable; $j++) { $ResultHtmlL.="<option   value='".$blocklist[$j]."'>".$blocklist[$j]; }
            $ResultHtmlL.="<option   value='$checkL' selected>".$EmptyBlock."</select></td></tr><tr><td><li>not already selected</li></td></tr></table><br>";

            $NumR=$NumR+1; $ResultHtmlR.="<table><tr><td align=left><br><b>&nbsp;&nbsp;&nbsp;&nbsp;Add New Right Block</b><br>";
            $ResultHtmlR.="&nbsp;&nbsp;&nbsp;&nbsp;<select name=\"xdpRBData[$NumR]\">";
            for ($j=0; $j < $cTable; $j++) { $ResultHtmlR.="<option   value='".$blocklist[$j]."'>".$blocklist[$j]; }
            $ResultHtmlR.="<option   value='$checkR' selected>".$EmptyBlock."</select></td></tr><tr><td><li>not already selected</li>
            </td></tr></table><br>";

           $ResultHtml.="<tr><td valign=top>".$ResultHtmlL."</td><td>&nbsp;</td><td align=left>".$ResultHtmlR."</td></tr>
            </table><br><br><input type='hidden' name='op' value='ConfigUpdate'>"."<center><input type='submit' value='SAVE CHANGES'></center>
            </form></td></tr></table>
            <table><tr><td>
            <br><br>
            <left><b>IMPORTANT LINKS:</b></left><br>
            <li><left><font class='option'><b>&nbsp;<a href='$EDP_SELF&page=config&do=add_page&du=dpage&def=1'>Click here to restore the default settin of the page if needed.<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Then modify and save.</a></b></left><br></li>";
            if($PageSection!=0) {$ResultHtml.="<li><left><font class='option'><b>&nbsp;<a href=\" \" onClick=\"javascript:YesNo('".$EDP_SELF."&page=config&do=add_page&du=page_delete','Are you sure, you want to delete this page and its content?');\">Delete this page</a></b></font></left><br></li>"; }
            $ResultHtml.="<li><left><font class='option'><b>&nbsp;<a href=\"#\" onClick=\"javascript:YesNo('".$edp_relative_path."dynamicpages/index.php?PageSection=".$PageSection."&page=config&do=add_page&du=page_add','Are you sure, you want to add a new page?');\">Add new page</a></b></font></left></li>
            </td></tr></table><br>";



            function ConfigUpdated($xdpFREE, $xdpFREED, $xdpFREET, $xdpLBData, $xdpRBData, $xxL, $xxR) {
             Global $PageSection, $FREEID, $FREET, $FREETDB, $EmptyBlock, $EDP_SELF;

             $xdpFREET="edp_".str_replace(" ","_",str_replace("edp_","",$xdpFREET));
             $xdpLBData=array_unique($xdpLBData); $xdpRBData=array_unique($xdpRBData);
             if(count($xxL)!==0) $xdpLBData=array_diff($xdpLBData, $xxL);
             if(count($xxR)!==0) $xdpRBData=array_diff($xdpRBData, $xxR);
             $zdpLBData=implode(":", $xdpLBData); $zdpRBData=implode(":", $xdpRBData);
             $j=0; for($i=0; $i<Count($FREET); $i++)    { if($xdpFREET==$FREETDB[$i]) {$j=1;} }
             if($j<=1) {
              mysql_query("UPDATE edp_pconfig SET dpFREE='$xdpFREE', dpFREED='$xdpFREED', dpFREET='$xdpFREET', dpLBData='$zdpLBData', dpRBData='$zdpRBData' where ID=$FREEID[$PageSection];");
              if($FREETDB[$PageSection]!==$xdpFREET) { mysql_query("RENAME TABLE $FREETDB[$PageSection] TO $xdpFREET");
               mysql_query("UPDATE edp_pupublish SET puTopic='".puHackers($xdpFREET)."'  WHERE puTopic='".$FREETDB[$PageSection]."';");
              }
              mysql_query("UPDATE $xdpFREET SET puTopic='$xdpFREET'  where puTopic='$FREETDB[$PageSection]'");
             }
             Header("Location: $EDP_SELF&page=config&do=add_page&du=dpage");
             }
?>
<SCRIPT LANGUAGE="JavaScript">
function selectColor ( color ) { url = "<? echo $edp_relative_path."admin/colors.php?color="; ?>" + color; var colorWindow = window.open(url,"ColorSelection","width=390,height=343,resizable=no,scrollbars=no"); }
</SCRIPT>





