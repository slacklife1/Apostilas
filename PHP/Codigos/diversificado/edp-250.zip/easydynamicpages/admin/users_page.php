<?
  $ResultHtml="";
  if ($do=="add_user") {
    $ResultHtml.=puHeading("Add User",1). "Registered users can add, edit or delete ".$Easy["Articles"].".<br><br><br>
		<div align=center>
      <table border='0' cellspacing='1' cellpadding='2' bgcolor='".$Easy[$PageSection]."' width=350>
      <tr><td colspan=2>&nbsp;<font color=".$Easy["Background"]."><b>.: New user information</b></font></td> </tr> ".puElement("form",$EDP_SELF,"NewUser","POST")."
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>Username:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("text","puUsername","",100)."</td> </tr>
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>Password:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("text","puPassword","",100)."</td> </tr>
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>Screen name:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("text","puScreenName","",200)."</td> </tr>
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>E-mail:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("text","puMail","",200)."</td> </tr>
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>Administrator?</b></td> <td bgcolor=".$Easy["Background"].">".puElement("select","puAdmin",Array(0=>"No",1=>"Yes"),100)."</td> </tr>
      <tr> <td colspan=2 align=right>".puElement("submit","Create","f_button")."</td> </tr> ".puElement("hidden","action","add_user").puElement()."
    </table><br>". $Error ."</div><br><hr><br> ";
  } elseif ($do=="edit_user" && isset($id)) {
    $EditUser=puMyFetch("SELECT * FROM edp_puusers WHERE ID=$id LIMIT 1;");
    $ResultHtml.=puHeading("Edit User",1). "Registered users can add, edit or delete ".$Easy["Articles"].".<br><br><br>
		<div align=center>
      <table border='0' cellspacing='1' cellpadding='2' bgcolor='".$Easy[$PageSection]."' width=350>
      <tr><td colspan=2>&nbsp;<font color=".$Easy["Background"]."><b>.: User information</b></font></td> </tr> ".puElement("form",$EDP_SELF,"EditUser","POST")."
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>Username:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("text","puUsername",$EditUser["puUsername"],100)."</td> </tr>
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>Password:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("text","puPassword",$EditUser["puPassword"],100)."</td> </tr>
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>Screen name:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("text","puScreenName",$EditUser["puScreenName"],200)."</td> </tr>
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>E-mail:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("text","puMail",$EditUser["puMail"],200)."</td> </tr>
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>Administrator?</b></td> <td bgcolor=".$Easy["Background"].">".puElement("select","puAdmin",Array(0=>"No",1=>"Yes"),$EditUser["puAdmin"],100)."</td> </tr>
      <tr> <td colspan=2 align=right>".puElement("submit","Change","f_button")."</td> </tr> ".puElement("hidden","action","edit_user").puElement("hidden","puID",$EditUser["ID"]).
      puElement()." </table><br>". $Error ."</div><br><hr><br> ";
  } else {
    $ResultHtml.=puHeading("Registered Users",1). "Registered users can add, edit or delete ".$Easy["Articles"].".<br><br><br>
		<div align=center>
		<table border='0' cellspacing='1' cellpadding='2' width=90%>
       <tr bgcolor='".$Easy[$PageSection]."'> <td colspan=4>&nbsp;<font color=".$Easy["Background"]."><b>.: Registered Users List</b></font></td> </tr>
       <tr bgcolor='".$Easy["LightColor1"]."'>
				<td><b>Screen Name</b></td>
				<td><b>E-mail</b></td>
				<td align=center><b>Admin</b></td>
				<td align=center><b>Edit</b></td>
			</tr>";
    $RegUsers=puMyQuery("SELECT * FROM edp_puusers Order by puScreenName");
		$i=0;
    while ($RegUser=mysql_fetch_array($RegUsers)) { $i++;
     if ($i % 2 != 0) { $color=""; } else { $color=" bgcolor='".$Easy["LightColor2"]."'"; }
			$ResultHtml.="
			<tr".$color.">
				<td><b>".$RegUser["puScreenName"]."</b></td>
				<td><a href='mailto:".$RegUser["puMail"]."'>".$RegUser["puMail"]."</a></td>
				<td align=center>".($RegUser["puAdmin"]==1 ? "Yes" : "No" )."</td>
        <td align=center><a href='$EDP_SELF&page=users&do=edit_user&id=".$RegUser["ID"]."'>Edit</a></td>
      </tr> ";
		}
		$ResultHtml.="
      <tr bgcolor='".$Easy[$PageSection]."'>
				<td>".puTr()."<br></td>
				<td>".puTr()."<br></td>
				<td>".puTr()."<br></td>
				<td>".puTr()."<br></td>
			</tr>
    </table><br> <b>Note:</b> You can not delete existing users as they could be published some ".$Easy["Articles"].".<br>You can rather change their password or assign their account to a new user, so they will not be able to logon.</div><br><hr><br> ";
  }
?>
