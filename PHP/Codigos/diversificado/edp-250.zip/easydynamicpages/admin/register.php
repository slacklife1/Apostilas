<?
    $ResultHtml=puHeading("Register New User",1). "Registered users can add, edit or delete ".$Easy["Articles"]." and Calendar events<br><br><br>
		<div align=center>
      <table border='0' cellspacing='1' cellpadding='2' bgcolor='".$Easy[$PageSection]."' width=350>
      <tr><td colspan=2>&nbsp;<font color=".$Easy["Background"]."><b>.: Enter new user information</b></font></td> </tr> ".puElement("form",$EDP_SELF,"NewUser","POST")."
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>Username:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("text","puUsername","",100)."</td> </tr>
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>Password:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("text","puPassword","",100)."</td> </tr>
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>Screen name:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("text","puScreenName","",200)."</td> </tr>
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>E-mail:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("text","puMail","",200)."</td> </tr>
      ".puElement("hidden","puAdmin",0)."
      <tr> <td colspan=2 align=right>".puElement("submit","Create","f_button")."</td> </tr> ".puElement("hidden","action","reg_user").puElement()."
    </table><br>". $Error ."</div><br><hr><br> ";
?>
