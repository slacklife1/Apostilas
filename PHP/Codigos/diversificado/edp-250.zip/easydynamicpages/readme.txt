/********************************************************************************/
/* EasyDynamicPages: Advanced Portal Management System                          */
/* ====================================================                         */
/* Copyright (c) 2003 by Angel Stoitsov and Mario Stoitsov                      */
/*    http://software.stoitsov.com                                              */
/********************************************************************************/

Installation
============

Prerequisites:

Download and install MySQL.
Download and install Apache
Download and install PHP 4.1.0 or greater.

Then, do the following:

1. Unzip the zip file not in some subdirectory (e.g. easydynamicpages)
   under the root directory of your server.

2. Open the file  easydynamicpages/admin/serverdata.php and edit your
   server name, MySql user name, password and dbase table name

3. Point your browser to
http://your_domain.com/easydynamicpages/install/install.php
      and follow the instructions.

You are done.

Remember: Your admin name, password are demo, demo, respectively.
          Change them and delete the file install.php

Enjoy your EasyDynamicPages.

For more details visit:
http://software.stoitsov.com
/********************************************************************************/
