The Server-Date-Time script

"inc_clock.php3"

Purpose: Install a digital clock showing server date and time using php and javascript

Browser: IE, NS

the original javascript-code comes from http://javascript.internet.com/clocks/basic-clock.html

copyright (c) 2001 by knito@knito.de
http://www.ingoknito.de

LICENSE: FREE

FILES:

readme.txt        you read it
clockdemo.php3    working demo
inc_clock.php3    used by clockdemo.php3


INSTALLATION:

Put inc_clock.php3 and clockdemo.php3 into a directory on your server.

MUCH MORE INSTALLION HINTS:

Use the functions in inc_clock.php3 to have the clock run.
It is a 4-step installation process demonstrated in inc_clock.php3.


step 1/4: include the script and install the javascript vars into the <head>

     include 'inc_clock.php3';
     InstallClockhead();

step 2/4: put the javascript onload="clock()" into the body tag.

     <body onLoad="clock()">

step 3/4: Put the Clock()-function somewhere into your page. This will "echo" the clock.

    Clock();

step 4/4: Put the javascript-function at the end of your html-body-section.

    InstallClockBody();
