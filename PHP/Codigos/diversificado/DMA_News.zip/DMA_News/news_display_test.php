<html>
	<head>
		<title>Razamataz</title>
		<style type="text/css">
	body
	{
		background: #EEEEEE;
		margin: 20;
		padding: 0;
		border: 0;
		color: #000000;
		font-family: verdana,arial,sans-serif;
		font-size: 10 px;
		text-decoration: none;
	}
	
	a:link
	{
		color: #000000;
		font-family: verdana,arial,sans-serif;
		font-size: 10 px;
		text-decoration: underline;
	}
	
	a:visited 
	{
		color: #000000; 
		font-family: verdana,arial,sans-serif;
		font-size: 10 px;
		text-decoration: underline;
	}
	
	a:hover 
	{
		color:#C93125; 
		font-family: verdana,arial,sans-serif;
		font-size: 10 px;
		text-decoration: underline;
	}
	
	td	
	{
		color: #000000;
		font-family: verdana,arial,sans-serif;
		font-size: 10 px;
		font-weight: normal;
	}
	</style>
	</head>
	
	<body>
		<center>
			 <?php
			 	include ("./dma_news_display.php");
			 ?>
		</center>
	</body>
</html>