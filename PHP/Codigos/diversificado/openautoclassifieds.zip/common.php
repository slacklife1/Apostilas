<?php
//common include file

//mysql database setup
$user = "database_user";
$password = "database_password";
$db = "openautoclassifieds";
$server = "localhost";


//OPENREALTY ADMIN PASS AND LOGIN
//DEFAULTS TO MYSQL DATABASE USER/PASS
$openadmin = "$user";
$openpassword = "$password";



//SITE INFORMATION
//use city and state? 'Y' or 'N'
global $use_city_state;
$use_city_state = "Y";



//used mostly for the email a friend function...
//but may come in handy elsewhere.
$baseurl = "http://www.yoursite.com/openautoclassifieds";
$yourname = "Your Name";
$youremail = "you@yoursite.com";

//number of listings to list at once:
$listings_per_page = 10;


//AGENT ADMINISTRATION
//use linefeed in description fields 'Y' or 'N'
$linefeeds = "Y";

//maximum number of imges for a given listing
$max_agent_images =1;

//how large can an agent image be? (n bytes)
$max_agent_upload = 1000000;


//INDIVIDUAL VEHICLE LISTING OPTIONS
//use email-a-friend option? 'Y' or 'N'
$friendmail = "Y";

//maximum numer of images for one vehicle
$max_images = 6;

//max size of vehicle images (in bytes)
$max_prop_upload = 1000000;

//available options for vehicles
//each option separated by a ||
//currently supports up to 10 options
$vehiclefeatureoptions = "Cruise Control||Air Conditioning||Power Steering||Power Brakes||Power Windows||Power Locks||Power Seats||Security Remote";

//the master list of states
$stateslist = "Alabama||Alaska||Arizona||Arkansas||California||Colorado||Connecticut||Delaware||District of Columbia||Florida||Georgia||Hawaii||Idaho||Illinois||Indiana||Iowa||Kansas||Kentucky||Louisiana||Maine||Maryland||Massachusetts||Michigan||Minnesota||Mississippi||Missouri||Montana||Nebraska||Nevada||New Hampshire||New Jersey||New Mexico||New York||North Carolina||North Dakota||Ohio||Oklahoma||Oregon||Pennsylvania||Rhode Island||South Carolina||South Dakota||Tennessee||Texas||Utah||Vermont||Virginia||Washington||West Virginia||Wisconsin||Wyoming";

//the master list of car types
$cartypeslist = "Sports||Sedan||4x4||SUV||Family||Van||Truck||Pickup||Motorcycle||Station Wagon";

//the master list of car makes
$carmakeslist = "Acura||Alfa Romeo||Audi||BMW||Bentley||Buick||Cadillac||Chevrolet||Chrysler||Daewoo||Daihatsu||Daimler||Datsun||DeLorean||DeSoto||Dodge||Eagle||Ferrari||Fiat||Ford||Geo||Honda||Hyundai||Infiniti||Isuzu||Jaguar||Jeep||Kia||Lamborghini||Lexus||Lincoln||Lotus||MG||Maserati||Mazda||Mercedes-Benz||Mercury||Mitsubishi||Nissan||Oldsmobile||Plymouth||Pontiac||Porsche||Renault||Rolls Royce||Saab||Saturn||Singer||Sterling||Studebaker||Subaru||Suzuki||Toyota||Triumph||Volkswagen||Volvo||Yugo||-----||Other";
?>