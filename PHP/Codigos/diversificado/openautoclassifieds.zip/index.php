<?php
include("common.php");

//set up SQL connection
	$link = mysql_connect ($server, $user, $password);
		if (! $link)
			{
			die ("Couldn't connect to mySQL server");
			}
		if (!mysql_select_db ($db, $link) )
			{
			die ("Coldn't open $db: ".mysql_error() );
			}
print "<!-- HERE BEGINNETH THE HEADER -->\r\n";
include("./templates/user_top.html");
?>


<table border=0 cellspacing=0>
<tr><td width=120 valign=top>
<!-- left navigation bar -->

<!-- begin feature code-->
<center>


<B><font face=\"ms sans serif\" size=2>Featured Listings:</font></b>


<?php
//EXAMPLE CODE:

//handles the listing of featured properties
$result = mysql_query("SELECT * FROM vehicles WHERE featured = 'Y';",$link);
while ($a_row =mysql_fetch_array ($result) )
	{
	//add commas to price
	$a_row[price] = number_format ($a_row[price]);
	
	print "<P>";
	print "<a href=\"./carview.php?view=$a_row[id]\"><b>$a_row[title]</b></a><BR>";
	//select images connected to a given listing
				$query = "SELECT * FROM tbl_Files WHERE prop_num = $a_row[id] LIMIT 1";
				$output = mysql_query("$query",$link);
				
				
				$count = 0;
				while ($image_row =mysql_fetch_array ($output) )
					{
					
					
					print "<a href=\"carview.php?view=$a_row[id]\"><img src='image.php?Id=$image_row[id_files]' border=1 width=100 alt=\"Photo\"></a><br>";
					$count++;
					}
				
				
				if ($count == 0)
					{
					print "<a href=\"./carview.php?view=$a_row[id]\"><img src=\"./images/nophoto.gif\" border=1 width=100 alt=\"View Listing\"></a><br>";
					}	
				
	
 	print "$a_row[year] $a_row[model] $a_row[make]<BR>";
  	print "\$$a_row[price]<BR>";
  	print "<P>";
  	

	
	}
//END OF EXAMPLE
?>

</font></center>
</td>
<!-- End feature code -->
<td width=30> </td>
<td valign=top>
<!-- End Header -->


<!-- begin main content -->


<center>
<font face=\"ms sans serif\" size=4><B>Welcome to OpenAutoClassifieds 1.0</b></font></center>
<P>
<font face=\"ms sans serif\" size=3>
<center><a href="./browse.php">Browse Listings</a>  |  <a href="http://jonroig.com/freecode/openrealty/bbs/bbbb.php3">Support Forum</a>
<BR>
<BR><Font color=red><B>*NEW*</b></font> <a href="http://jonroig.com/freecode/openautoclassifieds/openautoclassifieds.zip">Download OpenAutoClassifieds</a> (version 1.0)

<BR><a href="http://jonroig.com/freecode/openrealty/openlinks.php">See the Code in Use</a>
</center>
<p><B>So easy, even a grease monkey can do it!(*)</b> OpenAutoClassifieds is a free, open source vehicle classifieds manager. Intended to be both easy to install and easy to administer, OpenAutoClassifieds uses PHP to drive a mySQL backend, thus creating a tool which is fast and flexible.</p>
		<BR>
		
<b>Features:</b></p>
		<ul>
			<li>Allows visitors to look through your auto listings 24 hours a day, 7 days a week, 365.25 days a year.
			<li>Easily keep your auto listings updated -- no HTML coding required to add, delete, or modify listings.
			<li>Built-in image manager -- upload photos via your web browser, either when creating new listings or modifying an existing one. If photos are not uploaded for a vehicle, a &quot;photo not available&quot; image will be automatically displayed for the listing.
			<li>MySQL database backend -- free and fast, mySQL is standard with most hosting plans.
			<li>Secure -- no one but you can change your listings.
			<li>Viral Marketing -- visitors can email listings to their friends right from OpenAutoClassifieds.
			<li>Easy to install -- just edit a single configuration file.
			<li>Showcase specific vehicles -- built-in featured listing manager allows you to place special offerings right on your front page.
			<li>Flexible search -- browse vehicles according to whatever criteria you like.
			<li>Easy setup -- configurator tool makes OpenAutoClassifieds easy to install.
			<li>Extendable -- if you're using OpenRealty, you can use the same user and image databases.
		</ul>
		<p>Of course, OpenAutoClassifieds is written entirely in PHP, which makes it easy to customize and revise to match the look of your website.</p>
		<p><br>
		(*) This, by the way, is not meant to diss any members of the automotive repair community -- you've got nothing but the highest respect from me...
<P>
		


		</table>
		
<?php		
//print the footer
		print"\r\n<!-- THUS ENDETH THE MAIN CONTENT -->\r\n<!-- HERE BEGINNETH THE FOOTER -->";
		include("./templates/user_bottom.html");
		
//gots to close the mysql connection
	mysql_close($link);
?>