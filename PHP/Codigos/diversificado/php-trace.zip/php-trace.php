<?php
//  This script was writen by webmaster@theworldsend.net, Aug. 2001
//  check out my webpage with the newest stuff...around php and networking
//  http://www.theworldsend.net 
//  This is my second script. Enjoy.
//
//
$os = "win";   //os is "win" or "unix" (unix includes linux and friends)
//
// 
// Trace on unix already displays the hostnames, so we don't blend in the "resolve" option.
// If os = win, we put in a checkbox to ask for "resolve or not".
//
//  Put it into whatever directory and call it. That's all.
//
//
// nothing more to be done. 
//
If ($submit =="Trace!") 
{
  If (ereg(" ",$host)) 
  {
      echo 'No Space in Host field allowed !';
      echo '<a href="php-trace.php">Back</a>';
      $again= True;
  }
  else 
  {
       If ($host <> "")
       {
          echo("Traceroute Output:<br>"); 
          echo '<pre>';
          $host = escapeshellarg($host); 
          if ($os ="win") 
          {
               If ($resolve == "true") 
               {
                   system("tracert $host");
               }
               else
               {
                   system("tracert -d  $host");
               }; 
          }
          else
          {
               system("traceroute $host");
          };
          echo '</pre>';
       }
       else
       {
          echo 'You have not fill out the host field. Use your BACK button';
          echo 'to return to the form and enter an IP or Host';
       };
  };
}
else 
{
  echo '<html><body>';
  echo '<form methode="post" action="php-trace.php">';
  echo 'Enter IP or Host <input type="text" name="host"></input>';
  if ($os == "win") 
  {
     echo 'Resolve IPs ? <input type="checkbox" name="resolve" value="true" unchecked></input>';

  };
  echo '<input type="submit" name="submit" value="Trace!"></input>';
  echo '</form>';
  echo '</body></html>';
};
?>	
