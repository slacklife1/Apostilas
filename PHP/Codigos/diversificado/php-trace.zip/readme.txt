PHP-Trace Readme.

Contents of the zip-package:

readme.txt - this one
php-trace.php - the php-script

Installation:
Drop it into a directory, and call it. You will need execute-rights for this file.

What for?:
I dunno...just cool !.  

Can I change it?:
Sure, just sent me back the changed script and let's share your bright ideas (I doubt that there is 
much to add on, it's a simple script...).

It doesn't work, the error messages talks about a "fork?!?". 
Great. There are two possible causes. First, you use the "win" version on Unix or the other way around.
Edit the script an check/change the $os variable.

Second, your webserver doesn't allow the execution of system command out of the script. Well, if you own 
the server, you can change this in the php.ini or in the webserver settings. If you don't own the server,
it's bad. The script needs to call "system" to do the traceroute. Not much I can do...or you, other 
than changing provider....

Support ??!
Hello, this isn't a compicated script. More likley you will have a problem with your PHP installation or
webserver, but not with the script itself...but if you really want to, write me or post your questions 
at my little forum (http://www.theworldsend.net) and webmaster@theworldsend.net

Enjoy and share,
webmaster@theworldsend.net



