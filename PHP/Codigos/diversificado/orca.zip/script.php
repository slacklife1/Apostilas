<?php /* **************************************** Orca Forum/Blog */

/* ********************************************** Manual
Orca Forum/Blog - v3.1  Coded by GreyWyvern - http://www.greywyvern.com
                        PostgreSQL support added by Dragoniade

The Orca Forum/Blog is an easy-to-setup PHP script which uses either a MySQL or PostgreSQL database
to store the messages.  It's been developed as a single script, to be embedded into any normal
PHP page, and will follow the styling of whatever page you place it in.  Already have a format or
layout for your website?  Great!  Orca Forum/Blog will fit right in, no matter where you put it!
You can also fine tune the look of the post/reply form and message display using predefined
style variables.  Comes with cookie support, moderating tools and spam-prevention built in.

Now avoid huge lists on a single page!
 - Specify how many threads you want on each page and the messages will flow onto different pages!
 - Save many more messages for a longer time, without having to load ALL the messages to get to
     the most recent entries.
 - Only a specifed number of the latest messages are retrieved and displayed on the main page.

This program is freely distributable under the GPL. If you use it, I ask that you either: a) do
not remove the link to http://www.greywyvern.com from the end of the code, or b) give prominent
mention to the coder (GreyWyvern) somewhere on your site.  Thanks for using the Orca Forum/Blog!
Hope you like it!

Great Features:
 - Users are prompted to confirm a message (via JavaScript) if it does not have a name,
     subject or message text.
 - Messages without a subject and message are rejected, preventing board spamming.
 - Posting is only allowed from the domain your forum resides on (can be disabled)
 - Subjects and Names are truncated at 64 characters
 - Broken image links are handled without causing program errors
 - Choose to allow or disallow HTML in messages
 - Choose how to display author IP's or don't display them at all
 - Delete messages directly from within phpMyAdmin with no errors, or delete entire
     threads with a simple name/password function through the post form
 - Stores your name, email, homepage and image url in a cookie when you post
     These fields are automatically filled and ready to go on every page!
 - Generated HTML validates under XHTML Strict!

Version 3.0 changes:
 - Change to the way time stamps are saved so board-spamming is limited
     Unfortunately, time stamps saved using the old format will be incorrect
     Once new entries scroll the old ones off the screen, it will be fine again
 - Now use the forum as a blog!  Top level messages can appear in full text on the
     main page
 - Change the way the date/time appears in your forum
 - Specify an upper limit on image size in messages
 - Messages no longer use the constraining unordered list <ul> format
     <div> tags with margins space the messages accordingly, thus no markers/bullets
     will appear beside messages anymore
 - Automagically adds (n/t) to posts without text

Version 3.1 changes:
 - Added ability to expand to new pages, thus holding more messages
 - Cleaned up post form, removed "Reset Form" button
 - Cleaned up blog main-post display
 - Added email address munging

Setup: 1 - 2 - 3  Simple, no?
1. Paste this code in a php file such as "forum.php".  Take special care that no white space comes
   before the first <?php tag!  The start of your HTML goes where you see the tag "Begin your HTML
   page here", and the forum HTML will begin where your HTML leaves off.  Close your HTML page
   where you see "End your HTML page here".
2. Edit the user variables below, including SQL information, styles and setup/admin variables.
3. If you've entered the SQL information correctly, the program will automagically generate the
   database it needs to store the messages and display a confirmation message.  Congratulations!
   Your forum is now ready to use!

You can visit this code in action at the following URLs:
   http://www.greywyvern.com/forum.php
   http://www.greywyvern.com/blog.php

Thanks for choosing the Orca Forum/Blog!
Send comments to: orcaforum@greywyvern.com
************************************************* /Manual */

/* ********************************************** Setup */
/* ********************************************** User variables */
// ***** SQL information *****
$hostname = "localhost";             // Contact your hosting provider if you don't know these variables
$username = "username";
$password = "password";
$database = "database";
$sqlType = "mySQL";                  // Either mySQL or postgreSQL
$tableName = "orcaforum";

// ***** Reply form styles *****
$rfBorderColour = "black";           // Change these styles as you see fit
$rfBorderStyle = "solid";
$rfBackgroundColour = "transparent";
$rfFontColour = "black";
$rfTitleBarColour ="#708090";
$rfTitleFontColour = "black";
$rfInputBackgroundColour = "#c1ccd9";
$rfInputFontColour = "black";

// ***** Message styles *****
$mBordersColour = "#d3d3d3";
$mTitleFontColour = "black";

// ***** User variables *****
$welcomeMessage = "<span style=\"font-weight:bold;\">Welcome to my forum!</span>";
                                     // Welcome message can be any HTML as long as double quotes (")
                                     //   are escaped with a backslash like so: \"
$timezoneacronym = "EST";            // Standard time zone acronym
$timezoneoffset = "-5";              // Standard offset from GMT
$dateFormat = "M j, Y  g:i a";       // PHP date() format. See http://www.php.net/manual/en/function.date.php
$verifyDomain = "strict";            // Degree of security against POSTs coming from outside your domain
                                     //   Any of: "strict", "loose" or "none"
$displayIPstyle = "tip";             // Method of author IP display on the tree of messages
                                     //   Any of: "full", "tip" or "none"
$twolevel = true;                    // true = display post title on one line, author and date below,
                                     //   false = display post title, author and date all on one line.
$permitHTML = false;                 // Allow HTML tags in messages (true|false)
                                     //   If set to true, it *is* possible for a malicious user to insert
                                     //   code which can upset your layout and even direct the post form
                                     //   to another site.  Use with caution
$emailMung = "REMOVE@THIS";          // Munges posted email addresses by replacing the at (@) symbol with
                                     //   the contents of this variable
$imageWidthLimit = "250";            // Force an upper limit for images in messages.
$maxTopLevelPosts = 10;              // The number of top-level posts that can exist before they begin
                                     //   scrolling off the bottom of the page
$maxPages = 3;                       // Total pages your forum/blog can expand to.  The total number of
                                     //   top level messages retained is equal to $maxPages multiplied by
                                     //   $maxTopLevelPosts.  The default is 10x3 or 30 threads.
$spamSeconds = 60;                   // Time to wait before another message from the same IP will be
                                     //   accepted.  Prevents spamming/flooding.
$deletePostsAdmin = "admin";         // Change these values
$deletePostsPassword = "password";   //   Type your admin name in the Name field, the password in the
                                     //   Subject field, and the number of the post (the number of each
                                     //   post can be found in it's URL eg. msg=###) in the email field,
                                     //   and submit the form to delete that message and all of its
                                     //   replies.  Use this tool to moderate your forum as you desire.

// ***** Blogger Setup *****
$bloggerSwitch = false;              // True = Function as blog, False = Function as forum
$bloggerPrivate = true;              // True = Password required for top-level posts
$bloggerPassword = "password";       // Your blog password if above is true.  Enter it in the box which
                                     //   appears to the right of the "Post Message!" button before you
                                     //   submit a blog entry.  Replies to blog entries do not require a
                                     //   password.
$bloggerWords = 75;                  // Number of words to display on main page before an ellipsis (...)
/* ********************************************** /User variables */

// ***** Do not cache this page *****
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// ***** PHP Hacks & Initialization *****
error_reporting(E_ALL & ~E_NOTICE);
$mySQL = ($sqlType == "postgreSQL") ? false : true;
$db = db_connect($hostname, $username, $password, $database, $tableName);
$offset = (date("I")) ? ($GLOBALS['timezoneoffset'] + 1) * 3600 : $GLOBALS['timezoneoffset'] * 3600;
if (isset($_SERVER['QUERY_STRING'])) {
  if ($_SERVER['QUERY_STRING']) {
    $aArrSrc = explode("&", $_SERVER['QUERY_STRING']);
    foreach ($aArrSrc as $pair) {
      $qryArr = explode("=", $pair);
      ${$qryArr[0]} = $qryArr[1];
    } $event = $aArrSrc[0];
  }
} if (!isset($event)) $event = ""; if (!isset($start)) $start = 0;
if ($_SERVER['REQUEST_METHOD'] == "POST") postMessage();
/* ********************************************** /Setup */
/* ********************************************** HTML */ ?>


<!-- Begin your HTML page here -->


<?php /* **************************************** /HTML */
/* ********************************************** Forum display */

echo "<!-- ***** Begin Forum/Blog Generated HTML ***** -->\n<div style=\"text-align:center;\">
  $welcomeMessage\n</div>\n\n<div style=\"text-align:left;\">\n\n";
if ($event != "View") {$topMsgs = getThreads(-1); $pstd = 0;
  if ($bloggerSwitch == false) echo forumLinks("02");
  if (db_numrows($topMsgs) != 0) {
    if ($start >= db_numrows($topMsgs)) $start = db_numrows($topMsgs) - 1;
    if (db_numrows($topMsgs) > $maxTopLevelPosts) pageList(db_numrows($topMsgs) - 1 - $start - $maxTopLevelPosts);
    for ($num = db_numrows($topMsgs) - 1 - $start; $num > db_numrows($topMsgs) - 1 - $start - $maxTopLevelPosts; $num--) {
      ($start + $pstd++ < $maxTopLevelPosts * $maxPages) ? dispTree(db_result($topMsgs, $num, "msg_no"), true) : delTree(db_result($topMsgs, $num, "msg_no"));
      if ($num == 0) break;
    } if (db_numrows($topMsgs) > $maxTopLevelPosts) pageList($num);
  } else echo "\n<hr/>\n<p>Thanks for choosing the Orca Forum/Blog!<br/>
  If you're seeing this message, it means that the program has successfully connected to your SQL server/database and has created the table for storing the forum messages!  Congratulations!<br/><br/>
  Start off your new forum by posting a welcome message using the form below. Once you post your first message, you won't see this message again.<br/><br/>
  - GreyWyvern</p>\n<hr/>\n\n";
  postForm(-1);
} else dispMsg($msg);
echo "</div>\n\n";

// ***** Orca Script Signature *****
echo "<hr style=\"width:80%;text-align:center;\"/><br/>
<div style=\"text-align:center;font:italic 90% Times,serif;\">
  All times listed in $timezoneacronym<br/>An <a href=\"http://www.greywyvern.com\" onmouseover=\"this.target='_top';\">Orca</a> Script
</div><br/>\n<!-- ***** End Forum/Blog Generated HTML ***** -->\n";

/* ********************************************** /Forum display */
/* ********************************************** Function list */

// ***** Database functions ***** - Adaptation to PostgreSQL by Dragoniade [many thanks! :] *****
function db_connect($hostname, $username, $password, $database, $tableName) {
  if ($GLOBALS['mySQL']) {
    $db = mysql_connect($hostname, $username, $password) or die("Could not connect to the MySQL server!");
    mysql_select_db($database,$db) or die("Could not connect to the database!");
    mysql_query("CREATE TABLE IF NOT EXISTS $tableName (
      msg_no int(11), subject text, author text, email text, homepage text, ip text, dateStamp text, message longtext, image text, childOf int(11)
    );") or die("Could not create forum table!");
  } else {
    $str_connect = (($hostname != "") ? $str_connect = "host=$hostname " : "")."dbname=$database user=$username password=$password";
    $db = pg_connect($str_connect) or die("Could not connect to the postgreSQL server!");
    $createTable = @pg_query("CREATE TABLE $tableName (
      msg_no int, subject text, author text, email text, homepage text, ip text, dateStamp text, message text, image text, childOf int
    );");
  } return $db;
}

function db_query($query) {return ($GLOBALS['mySQL']) ? @mysql_query($query) : @pg_query($query);}
function db_numrows($result) {return ($GLOBALS['mySQL']) ? @mysql_numrows($result) : @pg_numrows($result);}
function db_result($result,$row,$field) {return ($GLOBALS['mySQL']) ? @mysql_result($result,$row,$field) : @pg_fetch_result($result,$row,$field);}
function getMsgs() {return db_query("SELECT * FROM {$GLOBALS['tableName']} ORDER BY msg_no");}
function getRow($msg) {return db_query("SELECT * FROM {$GLOBALS['tableName']} WHERE msg_no='$msg'");}
function getThreads($msg) {return db_query("SELECT * FROM {$GLOBALS['tableName']} WHERE childOf='$msg' ORDER BY msg_no");}

// ***** Display functions *****
// Display a full, readable message, the tree of replies and the reply form
function dispMsg($msg) {echo forumLinks("11");
  $message = getRow($msg); $prevMsg = getRow(db_result($message, 0, "childOf"));
  if (db_numrows($message) != 0) { ?>
<table border="0" cellpadding="2" cellspacing="0" style="width:75%;margin-left:auto;margin-right:auto;">
  <tr style="background-color:<?php echo $GLOBALS['mBordersColour']; ?>;color:<?php echo $GLOBALS['mTitleFontColour']; ?>;">
    <td style="width:75%;font-weight:bold;font-size:150%;text-align:left;"><?php echo db_result($message, 0, "subject").((!db_result($message, 0, "message")) ? " (n/t)" : ""); ?></td>
    <?php $eMung = ($GLOBALS['emailMung']) ? trim(preg_replace("/@/", $GLOBALS['emailMung'], db_result($message, 0, "email"))) : db_result($message, 0, "email"); ?>
    <td style="text-align:right;width:25%;">By <?php echo (($eMung) ? "<a href=\"mailto:$eMung\">" : "").db_result($message, 0, "author").(($eMung) ? "</a>" : ""); ?></td>
  </tr><tr>
    <td colspan="2" style="padding:10px;"><?php
      if (db_result($message, 0, "image")) {
        if ($imgAr = @getimagesize(db_result($message, 0, "image"))) {
          if ($imgAr[0] > $GLOBALS['imageWidthLimit']) {$imgSc = $imgAr[0] / $GLOBALS['imageWidthLimit']; $imgAr[1] /= $imgSc; $imgAr[0] = $GLOBALS['imageWidthLimit'];}
        } else $imgAr = array($GLOBALS['imageWidthLimit'] * .4, $GLOBALS['imageWidthLimit'] * .4);
        echo "\n      <img src=\"".db_result($message, 0, "image")."\" width=\"".(int)$imgAr[0]."\" height=\"".(int)$imgAr[1]."\" style=\"float:right;\" alt=\"Posted Image\"/>";
      } $buildMsg = preg_replace("/([^\s]{72})/i", "$1\n", db_result($message, 0, "message"));
      echo "\n\n<!-- Text of Message -->\n".addLinks($buildMsg)."\n<!-- /Text of Message -->\n\n";
      echo (db_result($message, 0, "homepage")) ? "      <p style=\"text-align:left;font:bold italic 125% sans-serif;margin-top:20px;\">
        <a href=\"".db_result($message, 0, "homepage")."\">Homepage</a>\n      </p>\n" : ""; ?>
    </td>
  </tr>
  <tr style="background-color:<?php echo $GLOBALS['mBordersColour']; ?>;color:<?php echo $GLOBALS['mTitleFontColour']; ?>;">
    <?php echo (db_result($message,0,"childOf") != -1) ? "<td style=\"text-align:left;font-size:90%;width:90%;\">Above message is a reply to:<br/><a href=\"{$_SERVER['PHP_SELF']}?View&amp;msg="
                                                          .db_result($message,0,"childOf")."\">".db_result($prevMsg,0,"subject")."</a></td>\n    <td style=\"text-align:right;white-space:nowrap;\">"
                                                        : "<td colspan=\"2\" style=\"text-align:right;white-space:nowrap;\">";
    echo gmdate($GLOBALS['dateFormat'], db_result($message,0,"dateStamp") + $GLOBALS['offset'])."</td>\n  </tr>\n</table><br/>\n\n";
    if (db_numrows(getThreads($msg))) {
      echo "<span style=\"font-style:italic;\">Replies to this post...</span><br/>\n\n";
      dispTree($msg, false);
    } postForm($msg);
  } else echo "Message <strong>$msg</strong> does not exist!<br/>\n";
  echo forumLinks("10");
}

// Display a tree of replies below message number $msg >> If $selfInc == true then include message $msg in the tree
function dispTree($msg, $selfInc) {static $dntLvl = -1; $message = getRow($msg); $dntLvl++;
  if (db_numrows($message) != 0) {
    if ($selfInc) {
      echo spaces($dntLvl * 2)."<div style=\"margin-left:30px;".((!$dntLvl) ? "margin-top:15px;": "")."\">\n";
      echo spaces($dntLvl * 2)."  <a href=\"{$_SERVER['PHP_SELF']}?View&amp;msg=$msg\" style=\"font-weight:bold;".(($GLOBALS['bloggerSwitch'] && !$dntLvl) ? "font-size:150%;" : "")
          ."\">".db_result($message, 0, "subject").((!db_result($message, 0, "message")) ? " (n/t)" : "")."</a>".((!$GLOBALS['bloggerSwitch'] and $GLOBALS['twolevel']) ? "<br/>" : " | ")."\n";
      echo spaces($dntLvl * 2)."  By <span style=\"font-weight:bold;\"".(($GLOBALS['displayIPstyle'] == "tip") ? " title=\""
          .db_result($message, 0, "ip")."\"" : "").">".db_result($message, 0, "author")."</span>".(($GLOBALS['displayIPstyle'] == "full") ? " <span style=\"font-size:80%;\">"
          .db_result($message, 0, "ip")."</span>" : "")." - <small style=\"font-style:italic;\">".gmdate($GLOBALS['dateFormat'], db_result($message,0,"dateStamp") + $GLOBALS['offset'])."</small>\n";
      if ($GLOBALS['bloggerSwitch'] && !$dntLvl) {
        echo spaces($dntLvl * 2)."  <div style=\"margin-left:10px;padding:10px;border-bottom:1px {$GLOBALS['rfBorderStyle']} {$GLOBALS['rfBorderColour']};\">\n";
        $trimArray = explode(" ", preg_replace("/<br\s\/>/i", "<br/>", db_result($message, 0, "message")));
        if (count($trimArray) >= $GLOBALS['bloggerWords']) {for ($i = 0; $i < $GLOBALS['bloggerWords']; $i++) $trimArray2[$i] = $trimArray[$i];} else $trimArray2 = $trimArray;
        $trimMessage = join(" ", $trimArray2).(($i == $GLOBALS['bloggerWords']) ? "... <a href=\"{$_SERVER['PHP_SELF']}?View&amp;msg=$msg\" style=\"font-size:85%;font-style:italic;\">&lt;More&gt;</a>" : "");
        echo spaces($dntLvl * 2)."    $trimMessage\n";
        echo spaces($dntLvl * 2)."  </div>\n";
      }
    } if (db_numrows(getThreads($msg))) for ($i = db_numrows(getThreads($msg)) - 1; $i >= 0; $i--) dispTree(db_result(getThreads($msg), $i, "msg_no"), true);
    if ($selfInc) echo spaces($dntLvl * 2)."</div>\n";
  } else echo "Message <strong>$msg</strong> does not exist!<br/>\n";
  $dntLvl--;
}

// Display the Post/Reply form
function postForm($replyVal) {$message = getRow($replyVal); $prevPost = unserialize(stripslashes($_COOKIE[$GLOBALS['tableName']]));
  $inputStyle = "color:{$GLOBALS['rfInputFontColour']};background-color:{$GLOBALS['rfInputBackgroundColour']};"; ?>
<script type="text/javascript"><!--
  function subValidate() {
    if (!document.getElementById('orcaForumPost').author.value) if (!confirm("Post message without a name?")) return false;
    if (!document.getElementById('orcaForumPost').subject.value) if (!confirm("Post message without a subject?")) return false;
    if (!document.getElementById('orcaForumPost').message.value) {
      if (!document.getElementById('orcaForumPost').subject.value) {alert("You must have at least a subject or message!"); return false;}
      if (!confirm("There is no message text!  Post anyway?")) return false;}
    return true;}
// --></script>
<a name="post"></a><hr style="width:80%;text-align:center;"/>
<div style="text-align:center;color:<?php echo $GLOBALS['rfFontColour']; ?>;">
  <table cellpadding="0" cellspacing="0" border="0" style="border:2px <?php echo $GLOBALS['rfBorderStyle']." ".$GLOBALS['rfBorderColour']; ?>;background-color:<?php echo $GLOBALS['rfBackgroundColour']; ?>;margin-right:auto;margin-left:auto;"><tr><td>
    <div style="background-color:<?php echo $GLOBALS['rfTitleBarColour']; ?>;font:italic bold 150% serif;color:<?php echo $GLOBALS['rfTitleFontColour']; ?>;white-space:nowrap;text-align:left;margin:3px;">
      <span style="padding-right:6px;font-size:90%;white-space:nowrap;float:right;"><?php echo gmdate($GLOBALS['dateFormat'], time() + $GLOBALS['offset'])." ".$GLOBALS['timezoneacronym']; ?></span>
      <span style="padding-left:6px;"><?php
        if ($replyVal != -1) {echo "Reply..."; $subject = db_result($message, 0, "subject"); if (substr($subject, 0, 4) != "Re: ") $subject = "Re: ".$subject;
        } else {echo (($GLOBALS['bloggerSwitch'] == true) ? "Add new entry..." : "Post new message..."); $subject = "";} ?></span>
    </div>
    <div style="margin:3px;text-align:center;white-space:nowrap;">
      <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" id="orcaForumPost" onsubmit="return subValidate();" style="margin:0px;">
        <div style="font-weight:bold;">
          Name: <input type="text" name="author" maxlength="32" size="20" value="<?php echo $prevPost['author']; ?>" style="<?php echo $inputStyle; ?>"/>
          Subject: <input type="text" name="subject" maxlength="96" size="40" value="<?php echo $subject; ?>" style="<?php echo $inputStyle; ?>"/></div>
        <div style="font-size:90%;">
          <?php echo ($GLOBALS['permitHTML']) ? "HTML tags are permitted in your message.<br/>" : "";?>
          <textarea cols="60" name="message" rows="5" style="margin:2px;<?php echo $inputStyle; ?>"></textarea></div>
        <div style="font:bold 90% sans-serif;">
          E-mail: <input type="text" name="email" maxlength="64" size="25" value="<?php echo $prevPost['email']; ?>" style="<?php echo $inputStyle; ?>"/>
          Homepage: <input type="text" name="homepage" maxlength="64" size="25" value="<?php echo $prevPost['homepage']; ?>" style="<?php echo $inputStyle; ?>"/></div>
        <div style="font:bold 90% sans-serif;margin-top:2px;">
          Image URL: <input type="text" name="image" maxlength="64" size="40" value="<?php echo $prevPost['image']; ?>" style="<?php echo $inputStyle; ?>"/>
          <input type="submit" value="Post Message!" style="margin:0px;padding:0px;font-size:90%;"/>
          <?php if ($GLOBALS['bloggerSwitch'] == true && $replyVal == -1 && $GLOBALS['bloggerPrivate'] == true) echo "<input type=\"password\" name=\"blogpass\" maxlength=\"8\" size=\"8\" style=\"$inputStyle\"/>\n"; ?>
          <input type="hidden" name="childOf" value="<?php echo $replyVal; ?>"/></div>
      <?php echo "</form>\n    </div>\n  </td></tr></table>\n</div>\n\n";
}

// Post a message to the DB on a page you can't get back to.
function postMessage() {extract($_POST, EXTR_PREFIX_SAME, "invalid");
  $parseReferrer = parse_url($_SERVER["HTTP_REFERER"]);
  $lastMsg = db_query("SELECT * FROM {$GLOBALS['tableName']} WHERE ip='{$_SERVER['REMOTE_ADDR']}' ORDER BY msg_no DESC LIMIT 1");
  if ($_SERVER['SERVER_ADDR'] != gethostbyname($parseReferrer[host]) && $GLOBALS['verifyDomain'] == "strict") {
    $rspMessage = "Bad Referrer IP.";
  } else if (strpos($parseReferrer[host], $_SERVER['SERVER_NAME']) === false && $GLOBALS['verifyDomain'] == "loose") {
    $rspMessage = "Bad Referrer Domain.";
  } else if ($author == $GLOBALS['deletePostsAdmin'] && $subject == $GLOBALS['deletePostsPassword']) {
    $rspMessage = ($email != "" && delTree($email)) ? "Post number $email and all of it's replies have been deleted from the database." : "There is no message number $email in the database.";
  } else if ($GLOBALS['bloggerSwitch'] == true && $childOf == -1 && $GLOBALS['bloggerPrivate'] == true && $blogpass != $GLOBALS['bloggerPassword']) {
    $rspMessage = "Incorrect Blogger Password.";
  } else if (db_result($lastMsg, 0, "dateStamp") + $GLOBALS['spamSeconds'] > time()) {
    $rspMessage = "You must wait {$GLOBALS['spamSeconds']} seconds between posts.";
  } else if (!$subject && !$message) {
    $rspMessage = "Post was disallowed: Missing both subject and message.";
  } else {
    $author = (trim($author)) ? prepStr(trim($author), "10") : "Anonymous";
      $author = (strlen($author) > 64) ? substr($author, 0, 64) : $author;
    $subject = (trim($subject)) ? prepStr(trim($subject), "10") : "&lt;No Subject&gt;";
      $subject = (strlen($subject) > 64) ? substr($subject, 0, 64) : $subject;
    $email = (preg_match("/([a-z0-9\-_.]+?)@([\w\-]+\.([\w\-\.]+\.)?[\w]+)/i", $email)) ? prepStr($email, "10") : "";
    $homepage = (strtolower($homepage) == "http://") ? "" : prepStr($homepage, "10");
      if ((strpos($homepage, "://") === false) && ($homepage)) $homepage = "http://".$homepage;
    if (preg_match('/.*(jpeg|jpg|png|gif|bmp|php|asp)$/i', $image)) {
      $image = (strtolower($image) == "http://") ? "" : prepStr($image, "10");
        if ((strpos($image, "://") === false) && ($image)) $image = "http://".$image;
    } else $image = "";
    $message = ($GLOBALS['permitHTML']) ? prepStr($message, "01") : prepStr($message, "11");
    $pNum = @db_result(getMsgs(), db_numrows(getMsgs()) - 1, "msg_no") + 1;
    $result = db_query("INSERT INTO {$GLOBALS['tableName']} VALUES ('$pNum', '$subject', '$author', '$email', '$homepage', '{$_SERVER['REMOTE_ADDR']}', '".time()."', '$message', '$image', '$childOf')");
    setcookie($GLOBALS['tableName'], serialize($_POST), time() * 2, "/");
    $rspMessage = "Success!  Your message has been posted.";
  } echo "<html>\n<head>\n  <title>$rspMessage</title>\n<meta http-equiv=\"refresh\" content=\"0;URL={$_SERVER['PHP_SELF']}\"/></head>\n";
  echo "<body>\n\n<div style=\"font-size:250%;text-align:center;\">$rspMessage</div>\n\n</body>\n</html>";
  exit();
}

// ***** Other functions *****
// Display links if forum/blog runs more than one page
function pageList($num) {global $start, $maxTopLevelPosts, $topMsgs; if ($num < 0) $num = 0;
  echo "<div style=\"text-align:center;\">\n";
  echo "\n<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"margin:10px auto 0px auto;width:60%;\"><tr>\n  <td style=\"text-align:left;width:20%;white-space:nowrap;\">\n    ";
  echo ($start != 0) ? "<a href=\"{$_SERVER['PHP_SELF']}".(($start - $maxTopLevelPosts <= 0) ? "" : "?start=".($start - $maxTopLevelPosts))."\" title=\"Previous $maxTopLevelPosts Posts\">&lt;&lt; Previous</a>" : "&nbsp;";
  echo "\n  </td>\n  <td style=\"text-align:center;width:60%;\">\n";
  for ($pglnk = 0; $pglnk < db_numrows($topMsgs); $pglnk += $maxTopLevelPosts) {
    if ($pglnk == $start) {echo "    <span style=\"font:bold 200% sans-serif;\" title=\"Page ".(($pglnk / $maxTopLevelPosts) + 1)."\">".(($pglnk / $maxTopLevelPosts) + 1)."</span>\n";}
      else echo "    <a href=\"{$_SERVER['PHP_SELF']}".(($pglnk != 0) ? "?start=$pglnk" : "")."\" title=\"Page ".(($pglnk / $maxTopLevelPosts) + 1)."\">".(($pglnk / $maxTopLevelPosts) + 1)."</a>\n";
  } echo "  </td>\n  <td style=\"text-align:right;width:20%;white-space:nowrap;\">\n    ";
  echo ($num != 0) ? "<a href=\"{$_SERVER['PHP_SELF']}?start=".($start + $maxTopLevelPosts)."\" title=\"Next $maxTopLevelPosts Posts\">Next &gt;&gt;</a>" : "&nbsp;";
  echo "\n  </td>\n</tr></table>\n</div>\n\n";
}

// Starting with message $msg, delete it and all replies.
function delTree($msg) {$message = getrow($msg);
  if (db_numrows($message)) {
    if ($repList = db_numrows(getThreads($msg))) {
      for ($i = 0; $i < $repList; $i++) delTree(db_result(getThreads($msg), 0, "msg_no"));
    } return db_query("DELETE FROM {$GLOBALS['tableName']} WHERE msg_no='$msg'");
  } else return false;}

function addLinks($string) {
  $string = preg_replace("/(?<!quot;|[=\".]|:\/\/)\b((\w+:\/\/|www\.).+?)(?=\W*([<>\s]|$))/i", "<a href=\"$1\">$1</a>", $string);
  return preg_replace("/href=\"www/i", "href=\"http://www", $string);}

function spaces($num) {
  for ($i = 0; $i < $num; $i++) $buildStr .= " ";
  return $buildStr;}

function prepStr($strg, $type) { // $type = "##", first 0 or 1 for htmlentities, second 0 or 1 for nl2br
  $strg = ($type[0]) ? htmlentities($strg) : $strg;
  $strg = ($type[1]) ? nl2br($strg) : $strg;
  return (get_magic_quotes_gpc()) ? $strg : addslashes($strg);}

function forumLinks($type) { // $type = "##", first digit = Forum home, second digit(if 1) = Post a Reply, (if 2) Post New Message
  $buildStr = "<p style=\"text-align:center;margin:5px;font-weight:bold;white-space:nowrap;\">\n  ";
  $buildStr .= (($type[0]) ? "<a href=\"{$_SERVER['PHP_SELF']}\">Main page</a>" : "").(($type[0] && $type[1]) ? " | " : "");
  $buildStr .= (($type[1] == "1") ? "<a href=\"#post\">Post a reply</a>" : "").(($type[1] == "2") ? "<a href=\"#post\">Post new message</a>" : "");
  $buildStr .= "\n</p>\n\n"; return $buildStr;}
/* ********************************************** /Function list */
/* ********************************************** /Orca Forum/Blog */ ?>


<!-- End your HTML page here -->