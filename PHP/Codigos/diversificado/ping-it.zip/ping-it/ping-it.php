<?
/*
Ping-it version 2.0
This script is created by Josepablo P�rez josepablo@correo.co.cr
check if you have ping enabled at the command prompt otherwords there will not be a ping output
By the way.. if you need custom programing feel free to contact me =-)
*/


$max_count = "15";    /* Change to restrict the maximum packets sent allowed per ping.  */
/*No need to edit after this line */

$main_page = '<html>
<head>
<title>Ping-It</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<META NAME="Author" CONTENT="Josepablo P�rez">
</head>
<body bgcolor="#999999" text="#000000">
<form methode="get" action="'.$PHP_SELF.'">
<input type=hidden name=action value=ping>
  <div align="center">
    <table width="590" border="1">
      <tr>
        <td height="21">
          <div align="center"><b><font size="6">Ping-It PHP </font></b><font size="6"><font size="4">&copy;
            Josepablo P&eacute;rez</font></font></div>
        </td>
      </tr>
    </table>
    <table width="590" border="1">
      <tr>
        <td>
          <table width="580" border="0">
            <tr>
              <td width="56%">Hostname / IP number to ping:
                <input type="text" name="host">
              </td>
              <td width="35%">
                <div align="right">Number of packets to send: </div>
              </td>
              <td width="9%">
                <input type="text" name="count" value="5" size=5>
              </td>
            </tr>
            <tr>
              <td width="56%">&nbsp;</td>
              <td width="35%">
                <div align="right">Seconds bewteen each packet:</div>
              </td>
              <td width="9%">
                <input type="text" name="time" value="1" size=5>
              </td>
            <tr>
              <td>&nbsp;</td>
              <td>
                <div align="right">Packet size:</div>
              </td>
              <td>
                <input type="text" name="size" value="64" size=5>
              </td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>
                <div align="right">Summary only output:</div>
              </td>
              <td>
                <input type="checkbox" name="quiet" value="yes">
              </td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>
                <div align="right"></div>
              </td>
              <td>&nbsp; </td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>
                <div align="right"></div>
              </td>
              <td>
                <input type="submit" name="Submit" value="Ping!">
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </div>
</form>
</body>
</html>';

$result_page1 = '<html>
<head>
<title>Ping-It</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<META NAME="Author" CONTENT="Josepablo P�rez">
</head>
<body bgcolor="#999999" text="#000000">
<form methode="get" action="'.$PHP_SELF.'">
<input type=hidden name=action value=ping>
  <div align="center">
    <table width="590" border="1">
      <tr>
        <td height="21">
          <div align="center"><b><font size="6">Ping-It PHP </font></b><font size="6"><font size="4">&copy;
            Josepablo P&eacute;rez</font></font></div>
        </td>
      </tr>
    </table>
    <table width="590" border="1">
      <tr>
        <td>
          <table width="580" border="0">
            <tr>
              <td width="56%">Hostname / IP number to ping:
                <input type="text" name="host">
              </td>
              <td width="35%">
                <div align="right">Number of packets to send: </div>
              </td>
              <td width="9%">
                <input type="text" name="count" value="5" size=5>
              </td>
            </tr>
            <tr>
              <td width="56%">&nbsp;</td>
              <td width="35%">
                <div align="right">Seconds bewteen each packet:</div>
              </td>
              <td width="9%">
                <input type="text" name="time" value="1" size=5>
              </td>
            <tr>
              <td>&nbsp;</td>
              <td>
                <div align="right">Packet size:</div>
              </td>
              <td>
                <input type="text" name="size" value="64" size=5>
              </td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>
                <div align="right">Summary only output:</div>
              </td>
              <td>
                <input type="checkbox" name="quiet" value="yes">
              </td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>
                <div align="right"></div>
              </td>
              <td>&nbsp; </td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>
                <div align="right"></div>
              </td>
              <td>
                <input type="submit" name="Submit" value="Ping!">
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
    <table width="590" border="1">
      <tr>
        <td height="21">
          <div align="left">
            <p><b>Ping Results:</b></p>';

$result_page2 = '<p>&nbsp;</p>
          </div>
        </td>
      </tr>
    </table>
    <p>&nbsp;</p>
  </div>
</form>
</body>
</html>';

//End of HTML

if ($HTTP_GET_VARS["action"] == "ping" )
{ if ($count > $max_count)
  {
  echo $result_page1;
  echo "<p><font color=\"#FF0000\"><b>Error: </b>Maximum packet sends allowed is $max_count.</font></p>";
  echo $result_page2;
  }
  elseif (ereg(" ",$host))
  {
  echo $result_page1;
  echo "<p><font color=\"#FF0000\"><b>Error: </b>No spaces allowed in hostname / IP.</font></p>";
  echo $result_page2;
  }
  elseif (empty($host))
  {
  echo $result_page1;
  echo "<p><font color=\"#FF0000\"><b>Error: </b>You did not input a hostname / IP.</font></p>";
  echo $result_page2;
  }
  else
  {
  $date = ucfirst(strftime("%A %B %d, %Y. %I:%M %p %Z"));
  echo $result_page1;
  echo "<p><b><pre>";
  if ($quiet == 'yes') { system("ping $host -c $count -i $time -q -s $size"); }
  else { system("ping $host -c $count -i $time -s $size"); }
  //system("ls");
  echo "</pre></b></p>";
  echo "<p><b>The results were obtained: $date from server: $SERVER_NAME.</b></p>";
  echo $result_page2;
  }
}
else
{
echo $main_page;
}

?>