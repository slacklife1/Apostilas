Ping-It version 2.0
README file for ping-it package.

Instructions: simply place the ping.php somewhere in your public html 
folder, once you have done this please register the script by simply letting me know who 
you are and were you used the script at: http://www.net.co.cr/distros/ping-it/register.php

Remember more information on this script is available at: http://www.net.co.cr/distros/ping-it/ 

Thanks!
