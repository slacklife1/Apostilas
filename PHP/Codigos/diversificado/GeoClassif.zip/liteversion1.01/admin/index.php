<? //index.php

/**************************************************************************\
Copyright (c) 2002 Geodesic Solutions, LLC
GeoClassifieds@version V1.01 June 22, 2002
All rights reserved
http://www.geodesicsolutions.com
This file written by 
James Park
IT Project Manager
<geoclassifieds@geodesicsolutions.com>

Released under BSD Style with conditions below
==============================
Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the 
following disclaimer. 
Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the 
following disclaimer in the documentation and/or other materials provided with the distribution. 
Neither the name of the James Park nor Geodesic Solutions may be used to endorse or promote
products derived from this software without specific prior written permission. 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT 
SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

==========================================================

 \**************************************************************************/

include("../config.php");
include("../classes/adodb.inc.php");
include("../classes/authenticate_class.php");

session_start();

$db = &ADONewConnection('mysql');
//$db = &ADONewConnection('access');
//$db = &ADONewConnection('ado');
//$db = &ADONewConnection('ado_mssql');
//$db = &ADONewConnection('borland_ibase');
//$db = &ADONewConnection('csv');
//$db = &ADONewConnection('db2');
//$db = &ADONewConnection('fbsql');
//$db = &ADONewConnection('firebird');
//$db = &ADONewConnection('ibase');
//$db = &ADONewConnection('informix');
//$db = &ADONewConnection('mssql');
//$db = &ADONewConnection('mysqlt');
//$db = &ADONewConnection('oci8');
//$db = &ADONewConnection('oci8po');
//$db = &ADONewConnection('odbc');
//$db = &ADONewConnection('odbc_mssql');
//$db = &ADONewConnection('odbc_oracle');
//$db = &ADONewConnection('oracle');
//$db = &ADONewConnection('postgres7');
//$db = &ADONewConnection('postgress');
//$db = &ADONewConnection('proxy');
//$db = &ADONewConnection('sqlanywhere');
//$db = &ADONewConnection('sybase');
//$db = &ADONewConnection('vfp');

if (!$db->PConnect($db_host, $db_username, $db_password, $database))
{
	echo "could not connect to database";
	exit;
}

if (!session_is_registered("auth")) 
{
	$auth = new Auth();
	session_register("auth");
}

if ($auth->level == 1)
{
	switch ($a) {

		case 1:
			//display the add category form
			include("admin_categories_class.php");
			$admin_category = new Admin_categories();
			if (!$admin_category->display_category_form($db,$b,1))
				$admin_category->category_error();
			break;

		case 2:
			//insert the new subcategory
			include("admin_categories_class.php");
			$admin_category = new Admin_categories();
			if (!$admin_category->insert_category($db,$b,$c))
				$admin_category->category_error();
			else
				if (!$admin_category->browse($db))
					$admin_category->category_error();				
			break;

		case 3:
			//display a category
			include("admin_categories_class.php");
			$admin_category = new Admin_categories();
			if (!$admin_category->display_current_category($db,$b))
				$admin_category->category_error();
			else
				if (!$admin_category->browse($db))
					$admin_category->category_error();
			break;

		case 4:
			//delete a category
			//deletes a category and all categories underneath
			//moves all items in any of these categories into the parent category of the intended category to be deleted
			include("admin_categories_class.php");
			$admin_category = new Admin_categories();
			if (($b) && ($c))
			{
				if (!$admin_category->delete_category($db,$b,$c))
					$admin_category->category_error();
				else
				{
					if (!$admin_category->browse($db))
						$admin_category->category_error();
				}
			}			
			elseif ($b)
			{
				if (!$admin_category->delete_category_check($db,$b))
					$admin_category->category_error();
				else
				{
					if (!$admin_category->browse($db))
						$admin_category->category_error();
				}			
			}
			else
			{
				if (!$admin_category->browse($db))
					$admin_category->category_error();			
			}
			break;		

		case 5:
			//edit a category
			include("admin_categories_class.php");
			$admin_category = new Admin_categories();
			if ($b)
			{
				if (!$admin_category->display_category_form($db,$b))
					$admin_category->category_error();
			}
			else
			{
				if (!$admin_category->browse($db))
					$admin_category->category_error();
			}
			break;

		case 6:
			//update a category
			include("admin_categories_class.php");
			$admin_category = new Admin_categories();
			if (($b) && ($c))
			{
				if (!$admin_category->update_category($db,$b,$c))
					$admin_category->category_error();
				else
					if (!$admin_category->browse($db))
						$admin_category->category_error();				
			}
			else
			{
				$admin_category->category_error();
			}
			break;
			
		case 7:
			//browse a category
			include("admin_categories_class.php");
			$admin_category = new Admin_categories();
			if ($b)
			{
				if (!$admin_category->browse($db,$b))
					$admin_category->category_error();
			}
			else
			{
				if (!$admin_category->browse($db))
					$admin_category->category_error();
			}
			break;
			
		case 50:
			//edit the admin login
			if ($b)
			{
				if (!$auth->update_admin_login($db,$b))
					$auth->auth_error();
				else
				{
					include("admin_categories_class.php");
					$admin_category = new Admin_categories();
					$admin_category->home();
				}
			}
			else
			{
				if (!$auth->edit_admin_login_form($db))
					$auth->auth_error();				
			}
			break;
			
		default:
			include("admin_categories_class.php");
			$admin_category = new Admin_categories();
			$admin_category->home();

	} //end of switch
}
elseif ($b)
{
	if (!$auth->login($db,$b["username"],$b["password"]))
	{
		$auth->auth_error();				
	}
	elseif ($auth->level == 1)
	{
		include("admin_categories_class.php");
		$admin_category = new Admin_categories();
		$admin_category->home();	
	}
	else
	{
		$auth->admin_login_form();
	}
	
}
else
{
	$auth->admin_login_form();
}
?>

