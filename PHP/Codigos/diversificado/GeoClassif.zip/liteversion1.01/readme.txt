readme.txt for distribution with GeoClassifieds

/**************************************************************************\
Copyright (c) 2002 Geodesic Solutions
All rights reserved

http://www.geodesicsolutions.com
This file written by 
James Park
IT Project Manager
<james@geodesicsolutions.com>

The GeoClassifieds Lite is distributed under the following license.

BSD Style-License
=================
Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the 
following disclaimer. 
Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the 
following disclaimer in the documentation and/or other materials provided with the distribution. 
Neither the name of the James Park nor Geodesic Solutions may be used to endorse or promote
products derived from this software without specific prior written permission. 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT 
SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

==========================================================

\**************************************************************************/

Thanks for trying the GeoClassifieds program. 
 
Uploading---------------------
 Upload the following files that come with this distribution maintaining the 
 directory structure
 
 classifieds.php
 register.php
 classes/authenticate.php
 classes/classified_browse_class.php
 classes/classified_sell_class.php
 classes/register_class.php
 
 admin/index.php
 admin/admin_categories_class.php
 
Configuring-------------------------
 GeoClassifieds also requires ADODB to work properly.  ADODB version 1.90 has
 been included in this distribution to speed installation.  You can go to 
 http://php.weblogs.com/ADODB or probably one of several other places to get 
 the latest version if you wish.
 
 Unless you make changes to classifieds.php GeoClassifieds looks for ADODB in the 
 classes subdirectory.  Upload the adodb.inc.php file into the classes directory.
 
 classes/adodb.inc.php
 
 Then choose the appropriate wrapper class file for the database you wish to use.  We used
 MySQL when building GeoClassifieds so we used the adodb-mysql.inc.php file to communicate
 to the MySQL server and placed in the classes directory.  
 
 classes/adodb-<wrapper class you need>.inc.php 
 ps adodb version 1.9 may require you to place the wrapper class file into 
 classes/drivers/adodb-<wrapper class you need>.inc.php 
 
 Inside the classifieds.php file uncomment the appropriate database wrapper file to include. 
 Do the same for the admin/index.php file also.
 
 enter your database information into the config.php
 
 Configure the information in the top of the following files to your installation 
 and likes
 
 classes/classified_browse_class.php
 classes/authenticate.php
 classes/classified_sell_class.php
 
 if you allow uploaded images into your classified ads you will have to create the
 appropriate directory and make sure the proper permissions are in place.
 
Database---------------------------------- 
 SQL Instructions
 The SQL to set up the database structure is in the file geoclassified.sql
 distributed with this download.  This has only been tested with MySQL but there  are no complicated sql statement......But there is always an exception so some modifications may be required to work with other databases.  Load the database using the geoclassified.sql file. This will create the basic database to get you started.   
 
Customize-------------------------------
 Next login into the admin facility at 
 admin/index.php
 
 The default username and password for the admin are:
 username: admin
 password: geodesic
 
 Create the classified category structure you would like.
 
Finished!!!!!!!!!!!!!

 GeoClassifieds uses sessions to save user data.
 
 
 Have fun ;)
 
 Geodesic Staff
 geoclassifieds@geodesicsolutions.com
 
 Contact us with any questions or proposals for this, other and possible projects.
 We are always open.
