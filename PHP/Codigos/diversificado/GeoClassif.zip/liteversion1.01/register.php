<? //register.php

/**************************************************************************\
Copyright (c) 2002 Geodesic Solutions, LLC
@version V1.01 June 22, 2002
All rights reserved
http://www.geodesicsolutions.com
This file written by 
James Park
IT Project Manager
<geoclassifieds@geodesicsolutions.com>

Released under BSD Style with conditions below
==============================
Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the 
following disclaimer. 
Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the 
following disclaimer in the documentation and/or other materials provided with the distribution. 
Neither the name of the James Park nor Geodesic Solutions may be used to endorse or promote
products derived from this software without specific prior written permission. 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT 
SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

==========================================================

 \**************************************************************************/

include("config.php");
include("classes/adodb.inc.php");
include("classes/register_class.php");

session_start();

$db = &ADONewConnection('mysql');

if (!$db->PConnect($db_host, $db_username, $db_password, $database))
{
	echo "could not connect to database";
	exit;
}

if ((!$register) || (!session_is_registered("register")))
{
	$register = new Register($db);
	session_register("register");
}

if ($b) {
	switch ($b) 
	{
	case "1":
		include("classheader.htm");
		$register->error_found = 0;
		//unset $register->error;

		if (!$register->check_info($db,$c))
		{
			//contact info has problems so go back
			$register->registration_form_1($db);
		}
  		else
  		{
  			$register->registration_form_2();
  		}

		include("classfooter.htm");
		exit;
		break;

	case "2":
		//check the username,password and whether agreement was checked
		include("classheader.htm");
		if (!$register->check_info($db))
		{
			//contact info has problems so go back
			$register->registration_form_1($db);
		}
		else
		{
			if (!$register->check_username($db,$c[username]))
				$register->registration_error();
			else
			{
				if (!$register->check_password($c[password],$c[password_confirm]))
					$register->registration_error();
				else
				{
					if (!$register->check_agreement($c[agreement]))
						$register->registration_error();
					else
					{
						if ($register->error_found == 0)
						{
							//echo "no error in registration<Br>\n";
							if (!$register->insert_user($db))
								$register->registration_error();
							else
								$register->confirmation_instructions();
						}
						else
						{
							//contact info is ok so put info into temp for final step
							$register->registration_form_2();
						}
					}
				}
			}
		}
		include("classfooter.htm");
		exit;
		break;
		
	case "3":
		//the user has clicked the confirmation sent in the email sent to him
		//process the confirmation and put the user in the 
		include("classheader.htm");
		if ($register->confirm($db,$hash,$username))
		{
			//display the registration confirmation completion
			$register->registration_confirmation_success();
		}
		else
		{
			//display the error message from confirmation
			$register->confirmation_error();
		}
		include("classfooter.htm");
		exit;
		break;
		
	default:
		//show the basic form
		include("classheader.htm");
		$register->registration_form_1($db);
		include("classfooter.htm");
		exit;
	}


}
else 
{
	//show the basic form to register
	include("classheader.htm");
	$register->registration_form_1($db);
	include("classfooter.htm");
	exit;
}

?>