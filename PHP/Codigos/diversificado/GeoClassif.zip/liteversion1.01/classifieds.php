<? //classifieds.php

/**************************************************************************\
Copyright (c) 2002 Geodesic Solutions, LLC
@version V1.01 June 22, 2002
All rights reserved
http://www.geodesicsolutions.com
This file written by 
James Park
IT Project Manager
<geoclassifieds@geodesicsolutions.com>

Released under BSD Style with conditions below
==============================
Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the 
following disclaimer. 
Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the 
following disclaimer in the documentation and/or other materials provided with the distribution. 
Neither the name of the James Park nor Geodesic Solutions may be used to endorse or promote
products derived from this software without specific prior written permission. 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT 
SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

==========================================================

 \**************************************************************************/

include("config.php");
include("classes/adodb.inc.php");
include("classes/authenticate_class.php");
include("classes/register_class.php");
include("classes/classified_sell_class.php");

session_start();

$db = &ADONewConnection('mysql');
//$db = &ADONewConnection('access');
//$db = &ADONewConnection('ado');
//$db = &ADONewConnection('ado_mssql');
//$db = &ADONewConnection('borland_ibase');
//$db = &ADONewConnection('csv');
//$db = &ADONewConnection('db2');
//$db = &ADONewConnection('fbsql');
//$db = &ADONewConnection('firebird');
//$db = &ADONewConnection('ibase');
//$db = &ADONewConnection('informix');
//$db = &ADONewConnection('mssql');
//$db = &ADONewConnection('mysqlt');
//$db = &ADONewConnection('oci8');
//$db = &ADONewConnection('oci8po');
//$db = &ADONewConnection('odbc');
//$db = &ADONewConnection('odbc_mssql');
//$db = &ADONewConnection('odbc_oracle');
//$db = &ADONewConnection('oracle');
//$db = &ADONewConnection('postgres7');
//$db = &ADONewConnection('postgress');
//$db = &ADONewConnection('proxy');
//$db = &ADONewConnection('sqlanywhere');
//$db = &ADONewConnection('sybase');
//$db = &ADONewConnection('vfp');

if (!$db->PConnect($db_host, $db_username, $db_password, $database))
{
	echo "could not connect to database";
	exit;
}

if (!session_is_registered("auth")) 
{
	$auth = new Auth();
	session_register("auth");
}

switch ($a) {

	case 1:
		//put an ad into the classifieds
		include("classheader.htm");
		if ($auth->user_id)
		{
			if (!session_is_registered("sell")) 
			{
				$sell = new Classified_sell($auth->user_id);
				session_register("sell");
			}
			
			if (!$sell->terminal_category)
			{
				if (($b) && ($c == "terminal"))
				{
					if ($sell->set_terminal_category(&$db,$b))
						$sell->display_classified_detail_form($db);
					else
						$sell->sell_error();				
				}
				elseif ($b)
				{
					if (!$sell->choose_category(&$db,$b))
						$sell->sell_error();				
				}
				else
				{
					if (!$sell->choose_category(&$db))
						$sell->sell_error();
				}
			}
			elseif (!$sell->classified_details_collected)
			{
				//echo "in the classified details section<br>\n";
				//echo $HTTP_POST_FILES["c"]["tmp_name"]." is the tmp file name<br>\n";
				//echo $HTTP_POST_FILES["c"]["name"]." is the file name<br>\n";
				//echo $c." is the file<br>\n";
				if (($b) && (is_array($b)))
				{
					//echo "checking classified details<br>\n";
					$sell->get_sell_form_variables($b);
					if ($sell->classified_detail_check())
					{
						//echo $HTTP_POST_FILES["c"]["size"]." is the uploaded file size<br>";
						if (is_uploaded_file($c))
						{
							//echo $HTTP_POST_FILES["c"]["type"]." is the uploaded file type<br>";
							//upload the classified image
							$image_type = $HTTP_POST_FILES["c"]["type"];
							$image_size = $HTTP_POST_FILES["c"]["size"];
							$sell->upload_the_classified_image($c,$image_type,$image_size);
						}
						$sell->classified_approval_display($db);
					}
					else
						$sell->display_classified_detail_form($db);	
				}
				else
				{
					//detail form has not been submitted yet
					$sell->display_classified_detail_form($db);
				}

			}
			elseif (!$sell->classified_approved)
			{
				//echo "in the classified approved section<br>\n";
				if ($b)
				{
					if ($b == "accepted")
					{
						if ($sell->insert_classified($db))
							$sell->sell_success();
						else
						{
							$sell->classified_approval_display($db);
						}
					}
					elseif ($b == "edit_details")
					{
						$sell->classified_details_collected = 0;
						$sell->display_classified_detail_form($db);	
					}
					elseif ($b == "edit_category")
					{
						$sell->terminal_category = 0;
						$sell->choose_category($db);								
					}
					else
					{
						$sell->classified_approval_display($db);
					}
				}
				else
				{
					$sell->classified_approval_display($db);
				}			
			}
			else
				$sell->choose_category($db);		
		}
  		else
  		{
  			$auth->login_form();
		}
		include("classfooter.htm");
		exit;
		break;

	case 2:
		include("classheader.htm");
		//display a classified
		include("classes/classified_browse_class.php");
		$browse = new Classified_browse($auth);
		$browse->classified_close($db);
		if ($b)
		{
			if ($browse->classified_exists($db,$b))
			{
				if (!$browse->display_classified($db,$b))
					$browse->browse_error();			
			}
			else
			{
				$browse->browse_error();
			}
		}
		else
		{
			//display the home page
			if (!$browse->main($db))
				$browse->browse_error();
		}		
		include("classfooter.htm");
		break;

	case "4":
		//display this user profile
		//b is user id
		include("classheader.htm");
		if ($auth->user_id)
		{
			if (!$auth->edit_user_form($db))
				$auth->auth_error();
		}
		else
		{
			$auth->login_form();
		}
		include("classfooter.htm");
		exit;
		break;
		
	case "5":
		//display a category
		//b will contain the category id
		include("classheader.htm");
		include("classes/classified_browse_class.php");
		$browse = new Classified_browse($auth);
		$browse->classified_close($db);
		if ($b)
		{
			if (!$browse->browse($db,$b))
				$browse->browse_error();
		}
		else
		{
			if (!$browse->main($db))
				$browse->browse_error();
		}
		include("classfooter.htm");
		exit;
		break;

	case 10:
		//login
		include("classheader.htm");
		if (!$auth->user_id)
		{
			if (($b[username]) && ($b[password]))
			{
				if ($auth->login($db,$b[username],$b[password]))
				{
					include("classes/classified_browse_class.php");
					$browse = new Classified_browse($auth);
					$browse->main($db);
				}
				else
				{
					$auth->login_form($b[username], $b[password]);
				}

			}
			else
			{
				$auth->login_form();
			}
		}
		else
		{
			$auth->already_logged_in();
		}
		include("classfooter.htm");
		exit;
		break;
		
	case 11:
		//update user data
		include("classheader.htm");
		if ($auth->user_id)
		{
			if ($b)
			{
				if ($auth->update_user($db,$b))
				{
					if (!$auth->edit_user_form($db))
						$auth->auth_error();
				}
				else
				{
					$auth->login_form();	
				}
			}
			else
			{
				$auth->login_form();
			}
		}
		else
		{
			$auth->login_form();
		}
		include("classfooter.htm");
		exit;
		break;

	case 12:
		//notify a friend
		include("classheader.htm");
		include("classes/classified_browse_class.php");
		$browse = new Classified_browse($auth);
		if ($b)
		{
			if ($auth->verify_notify_friend($db,$b))
			{
				if ($auth->notify_friend($db,$b))
					$browse->main($db);
				else
					$auth->auth_error();
			}
			else
				if (!$auth->notify_friend_form($db,$c))
					$auth->auth_error();
				
		}
		elseif ($c)
		{
			if (!$auth->notify_friend_form($db,$c))
				$auth->auth_error();
		}
		else
		{
			$browse->main($db);
		}
		include("classfooter.htm");
		exit;
		break;
		
	case 17:
		//log this user out
		include("classheader.htm");
		include("classes/classified_browse_class.php");
		$browse = new Classified_browse($auth);
		if ($auth->user_id)
		{
			session_destroy();
			$browse->main($db);
		}
		else
		{
			$browse->main($db);
		}
		include("classfooter.htm");
		exit;
		break;

	case 18:
		//lost password
		include("classheader.htm");
		include("classes/classified_browse_class.php");
		$browse = new Classified_browse($auth);
		if (!$auth->user_id)
		{
			if ($b)
			{
				if (!$auth->lostpassword(&$db,$b[email]))
					$auth->auth_error();
				else
					$browse->main($db);	
			}
			else
			{
				//show the lost password form
				$auth->lostpassword_form();
			}
		}
		else
		{
			//show the change password form
			if ($b)
			{
				if (!$auth->change_password (&$db,$b))
				{
					if ($auth->error_message)
					{	
						$auth->auth_error();
					}
					else
					{
						if ($auth->change_password_form())
							$auth->auth_error();
					}
				}
				else
				{
					$browse->main($db);	
				}
			}
			else
			{
				if (!$auth->change_password_form())
					$auth->auth_error();
			}
		}
		include("classfooter.htm");
		exit;
		break;

	case 98:
		//end this sell process
		include("classheader.htm");
		include("classes/classified_browse_class.php");
		$browse = new Classified_browse($auth);
		if ($auth->user_id)
		{
			session_unregister("sell");
			unset ($sell);
			$browse->main($db);
		}
		else
		{
			$browse->main($db);
		}
		include("classfooter.htm");
		exit;
		break;

	case 99:
		//this is the admin
		//trying to delete a classified
		include("classheader.htm");
		include("classes/classified_browse_class.php");
		$browse = new Classified_browse($auth);
		if ($auth->level == 1)
		{
			if ($b)
			{
				if ($browse->admin_delete_classified($db,$b))
				{
					$browse->delete_images($b);
					if (!$browse->browse($db,$c))
						$browse->browse_error();
				}
				else
				{
					$browse->browse_error();
				}					
			}
			else
			{
				$browse->main($db);
			}
		}
		else
		{
			$browse->main($db);
		}
		include("classfooter.htm");
		exit;
		break;

	default:
		include("classheader.htm");
		include("classes/classified_browse_class.php");
		$browse = new Classified_browse($auth);
		$browse->main($db);
		include("classfooter.htm");
		exit;


} //end of switch ($a)
?>