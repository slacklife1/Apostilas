<? //classified_browse_class.php

/**************************************************************************\
Copyright (c) 2002 Geodesic Solutions, LLC
@version V1.01 June 22, 2002
All rights reserved
http://www.geodesicsolutions.com
This file written by 
James Park
IT Project Manager
<geoclassifieds@geodesicsolutions.com>

Released under BSD Style with conditions below
==============================
Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the 
following disclaimer. 
Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the 
following disclaimer in the documentation and/or other materials provided with the distribution. 
Neither the name of the James Park nor Geodesic Solutions may be used to endorse or promote
products derived from this software without specific prior written permission. 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT 
SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

==========================================================

 \**************************************************************************/

class Classified_browse {

	var $messages = array();
	
	//database table names -  can be left alone
	var $classifieds_table = "geodesic_classifieds";
	var $classifieds_userdata_table = "geodesic_classifieds_userdata";
	var $classifieds_categories_table = "geodesic_classifieds_categories";
	
	//font tag information used throughout several parts of the site
	var $font_title_tag = "<font face=arial,helvetica size=3 color=#003333>";
	var $font_tag = "<font face=arial,helvetica size=2 color=#000000>";
	var $font_tag_light = "<font face=arial,helvetica size=2 color=#ffffff>";
	
	//color backgrounds of the classified ad listing table
	var $background_color_light = "#eeeeee";
	var $background_color_dark = "#dddddd";
	
	var $subcategory_array = array();
	
	var $level;
	
	//final directory path the uploaded classified images will be placed in
	//used when removing expired classified images 
	//same path in classified_sell_class.php
	var $classified_images_path= "/home/geodesicsolutions/www/products/classified/litedemo/classified_images/";
	
	//if display_sub_category_classifieds is set to 1:
	//the classified ads in the subcategories of the currently browsed category will be displayed also
	//with those in the current category
	//if display_sub_category_classifieds is set to 0:
	//only classified ads in the currently browsed category will be displayed
	var $display_sub_category_classifieds = 1; 
	
	//set to 1 to display the classifieds ads count for that category while browsing
	//set to 0 to turn off
	var $display_counter = 1; 

	var $category_tree_array = array();
		
//########################################################################

	function Classified_browse($auth)
	{
	
		$this->level = $auth->level;
		
		$this->messages[2502] = "Classified category";
		$this->messages[2503] = "Seller";
		$this->messages[2509] = "Ad started";
		$this->messages[2510] = "Time till ad ends";
		$this->messages[2511] = "Location";
		$this->messages[2512] = "Description";
		$this->messages[2513] = "Classified id";
		$this->messages[2515] = "Subcategories of ";
		$this->messages[2516] = "There are no classified ads in this category";
		$this->messages[2517] = "picture";
		$this->messages[2520] = "date ad entered";
		$this->messages[2521] = "none";
		$this->messages[2522] = "Main";
		$this->messages[2523] = "Internal browse error!";
		$this->messages[2524] = "Not enough information to display the classified ad";
		$this->messages[2525] = "Welcome to our Classified Ads";
		$this->messages[2526] = "Start browsing the main categories below";
		$this->messages[2527] = "There are no categories to browse";
		$this->messages[2528] = "Not enough information to browse the Classifieds";
		$this->messages[2529] = "Classifed ad title";
		$this->messages[2530] = "There are no subcategories to ";
		$this->messages[2531] = "Click here to notify a friend of this ad ";
		
		
	} //end of function Classified_browse

//###########################################################

	function display_classified($db,$id=0)
	{
		if ($id)
		{
			$sql_query = "select * from ".$this->classifieds_table." where id = ".$id;
			$result = &$db->Execute($sql_query);
			if (!$result)
			{
				//echo $sql_query." is the query<br>\n";
				$this->error_message = $this->messages[2524];
				return false;
			}
			elseif ($result->RecordCount() > 1 )
			{
				//more than one classified matches
				//echo $sql_query." is the query<br>\n";
				$this->error_message = $this->messages[2524];
				return false;
			}
			elseif ($result->RecordCount() <= 0)
			{
				//echo $sql_query." is the query<br>\n";
				$this->error_message = $this->messages[2524];
				return false;
			}
			else
			{
				//the classified ad exists diplay it
				$show = $result->FetchNextObject();

				echo "<table width=600 cellpadding=3 cellspacing=0 align=center border=0>\n";
				
				$category_tree = $this->get_category_tree($db,$show->CATEGORY);
				reset ($this->category_tree_array);
		
				if ($category_tree)
				{
					//category tree
					echo "<tr>\n\t<td>\n\t<b>";
					echo $this->font_tag.$this->messages[2502]." : </b> <a href=classifieds.php?a=5>".$this->font_tag."Main</a> >";
					if (is_array($this->category_tree_array))
					{
						$i = 0;
						//$categories = array_reverse($this->category_tree_array);
						$i = count($this->category_tree_array);
						while ($i > 0 ) 
						{
							//display all the categories
							$i--;
							if ($i == 0)
								echo "<a href=classifieds.php?a=5&b=".$this->category_tree_array[$i]["category_id"]."><b>".$this->font_tag.$this->category_tree_array[$i]["category_name"]."</b></a>";
							else
								echo "<a href=classifieds.php?a=5&b=".$this->category_tree_array[$i]["category_id"].">".$this->font_tag.$this->category_tree_array[$i]["category_name"]."</a> > ";
						}
					}
					else
					{
						echo $category_tree;
					}
					echo "\n\t</td>\n</tr>\n";
				}
			
				//classified id
				echo "<tr>\n\t<td>".$this->font_tag.$this->messages[2513].": ".$show->ID."</font>\n\t</td>\n</tr>\n";
				
				//classified title
				echo "<tr>\n\t<td>".$this->font_title_tag.$show->TITLE."</font>\n\t</td>\n</tr>\n";

				//get sellers data				
				$sql_query = "select * from ".$this->classifieds_userdata_table." where id = ".$show->SELLER;
				$user_result = &$db->Execute($sql_query);
				if (!$user_result)
				{
					//echo $sql_query." is the query<br>\n";
					$this->error_message = $this->messages[2524];
					return false;
					
				}
				$show_user  = 	$user_result->FetchNextObject();
				
				//seller 
				echo "<tr>\n\t\t<td>".$this->font_tag.$this->messages[2503]." : ".$show_user->USERNAME."</td>\n\t</tr>\n\t";
				
				//start date
				$start_date = date("M d, Y H:i:s", $show->DATE);
				echo "<tr>\n\t\t<td>".$this->font_tag.$this->messages[2509]." : ".$start_date."</td>\n\t</tr>\n\t";

				//location
				echo "<tr>\n\t\t<td>".$this->font_tag.$this->messages[2511]." : ".$show->LOCATION_STATE." ".$show->LOCATION_ZIP."</td>\n\t</tr>\n\t";

				//description
				echo "<tr>\n\t\t<td>".$this->font_tag.$this->messages[2512]."<br>".$show->DESCRIPTION."</td>\n\t</tr>\n\t";
				
				//image
				if (strlen(trim($show->IMAGE_URL)) > 0)
				{
					echo "<tr>\n\t\t<td><img src=".$show->IMAGE_URL."></td>\n\t</tr>\n\t";
				}

				echo "<tr>\n\t\t<td><a href=classifieds.php?a=12&c=".$show->ID.">".$this->font_tag.$this->messages[2531]."</font></a></td>\n\t</tr>\n\t";

				echo "</table>\n";

				return true;
			}
		}
		else
		{
			//no id to display
			return false;
		} //end of else
	} //end of function display_classifed
	
//####################################################################################

	function browse($db,$category=0,$browse_type=0)
	{
		//browse the classifieds in this category that are open
		
		if ($category)
		{
			if (($this->display_sub_category_classifieds) && ($this->display_counter))
			{
				$in_statement = $this->get_sql_in_statement($db,$category);
			}
			else
			{
				$in_statement = " in (".$category.") ";
			}
			
			switch($browse_type)
			{
				case 1:
					//browse the classifieds started in the last 24 hours
					$last_24 = time() - 86400;
					$sql_query = "select * from ".$this->classifieds_table." where 
						category ".$in_statement." date > ".$last_24." order by date asc";;
					break;			

				default:
					$sql_query = "select * from ".$this->classifieds_table." where 
						category ".$in_statement." order by ends asc";
			}

			$result = &$db->Execute($sql_query);
			////echo $sql_query." is the query<br>\n";
			if (!$result)
			{
				//echo $sql_query." is the query<br>\n";
				$this->error_message = $this->messages[2524];
				return false;
			}
			else
			{
				echo "<table cellpadding=2 cellspacing=1 border=0 width=600 align=center>\n";
				//get this categories name
				$sql_query = "select *from ".$this->classifieds_categories_table." where category_id = ".$category;
				$name_result = &$db->Execute($sql_query);	
				if (!$name_result)
				{
					//echo $sql_query." is the query<br>\n";
					$this->error_message = $this->messages[2524];
					return false;
				}
				elseif ($name_result->RecordCount() == 1)
				{
					$show_name = $name_result->FetchNExtObject();
					$category_name = $show_name->CATEGORY_NAME;
				}
				else
				{
					$category_name = $this->messages[2522];
				}

				//get the categories inside of this category
				$sql_query = "select * from ".$this->classifieds_categories_table." where 
					parent_id = ".$category." order by display_order";
				$category_result = &$db->Execute($sql_query);

				////echo $sql_query." is the query<br>\n";
				if (!$category_result)
				{
					//echo $sql_query." is the query<br>\n";
					$this->error_message = $this->messages[2524];
					return false;
				}
				else
				{
					if ($category_result->RecordCount() > 0)
					{
						//display the sub categories of this category
						echo "<tr>\n\t<td>\n\t".$this->font_title_tag.$this->messages[2515]." ".$category_name."\n\t</td>\n</tr>\n";
						echo "<tr>\n\t<td>\n\t";
						while ($show_sub_categories = $category_result->FetchNextObject())
						{
							$count = $this->get_ad_count_for_category($db,$show_sub_categories->CATEGORY_ID);
							echo "<a href=classifieds.php?a=5&b=".$show_sub_categories->CATEGORY_ID.">".
								$this->font_title_tag.$show_sub_categories->CATEGORY_NAME."</a>";
							if ($this->display_counter)
								echo "(".$count.")";
							echo "<br>\n\t";
						}
						echo "</td>\n</tr>\n";					
					}
					else
					{
						echo "<tr>\n\t<td>\n\t".$this->font_title_tag.$this->messages[2530]." ".$category_name."\n\t</td>\n</tr>\n";
					}

					$category_tree = $this->get_category_tree($db,$category);
					reset ($this->category_tree_array);

					if ($category_tree)
					{
						//category tree
						echo "<tr>\n\t<td>\n\t<b>";
						echo $this->font_title_tag.$this->messages[2502]." : </b> <a href=classifieds.php?a=5>".$this->font_title_tag."Main</a> >";
						if (is_array($this->category_tree_array))
						{
							$i = 0;
							//$categories = array_reverse($this->category_tree_array);
							$i = count($this->category_tree_array);
							while ($i > 0 ) 
							{
								//display all the categories
								$i--;
								if ($i == 0)
									echo "<b>".$this->font_title_tag.$this->category_tree_array[$i]["category_name"]."</b>";
								else
									echo "<a href=classifieds.php?a=5&b=".$this->category_tree_array[$i]["category_id"].">".$this->font_title_tag.$this->category_tree_array[$i]["category_name"]."</a> > ";
							}
						}
						else
						{
							echo $category_tree;
						}
						echo "\n\t</td>\n</tr>\n";
					}

					if ($result->RecordCount() > 0)
					{
						//classifieds exist in this category
						//display the classifieds inside of this category
						echo "<tr>\n\t<td>\n\t";
						echo "<table cellpadding=3 cellspacing=1 border=1 align=center>\n\t";
						echo "<tr bgcolor=#000000>\n\t\t
							<td>".$this->font_tag_light.$this->messages[2529]."</td>\n\t\t
							<td>".$this->font_tag_light.$this->messages[2520]."</td>\n\t";
						if ($this->level == 1)
						{
							//this is the admin
							echo "<td>".$this->font_tag_light."click to delete</td>\n\t";								
						}
						echo "</tr>\n\t";
						$i = 0;
						while ($show_classifieds = $result->FetchNextObject())
						{
							$row_color = $this->get_row_color($i);
							echo "<tr bgcolor=".$row_color.">\n\t\t";
							echo "<td>\n\t\t<a href=classifieds.php?a=2&b=".$show_classifieds->ID.">".$this->font_tag.$show_classifieds->TITLE."</a>\n\t\t</td>\n\t\t";
							echo "<td>\n\t\t".$this->font_tag.date("F d-G:i",$show_classifieds->DATE)."\n\t\t</td>\n\t\t";
							if ($this->level == 1)
							{
								//this is the admin
								echo "<td>\n\t\t<a href=classifieds.php?a=99&b=".$show_classifieds->ID."&c=".$category.">".$this->font_tag."delete</a>\n\t\t</td>\n\t";								
							}							
							echo "</tr>\n\t";
							$i++;
						} //end of while
						echo "</table>\n\t</td>\n</tr>\n";
					}
					else
					{
						//no classifieds in this category
						echo "<tr>\n\t<td>\n\t".$this->font_title_tag.$this->messages[2516]."\n\t</td>\n</tr>\n";
					}
				}
				echo "</table>\n";
			}
		}
		else
		{
			//go to browse the main category
			if (!$this->browse_main($db))
			{
				return false;
			}
		}
		return true;
	} //end of function browse
	
//########################################################################

	function get_category_tree($db,$category)
	{
		$i = 0;
		$category_next = $category;
		do
		{
			$sql_query = "select category_id,parent_id,category_name from ".$this->classifieds_categories_table." 
				where category_id = ".$category_next;
			$category_result =  &$db->Execute($sql_query);
			
			//$category = array();
			
			////echo $sql_query." is the query<br>\n";
			if (!$category_result)
			{
				////echo $sql_query." is the query<br>\n";
				$this->error_message = $this->messages[2052];
				return false;
			}
			elseif ($category_result->RecordCount() == 1)
			{
				$show_category = $category_result->FetchNextObject();
				//echo $i." is i before increment in get_category_tree<br>\n";
				//$category[$i] = array("parent_id"=>$show_category->PARENT_ID,"category_name"=>$show_category->CATEGORY_NAME,"category_id"=>$show_category->CATEGORY_ID);
				$this->category_tree_array[$i]["parent_id"]  = $show_category->PARENT_ID;
				$this->category_tree_array[$i]["category_name"] = $show_category->CATEGORY_NAME;
				$this->category_tree_array[$i]["category_id"]   = $show_category->CATEGORY_ID;
				//echo $this->category_tree_array[$i]["category_id"]." is the category id<br>\n";
				$i++;
				$category_next = $show_category->PARENT_ID;
			}
			else
			{
				echo "wrong return<Br>\n";
				return false;
			}

     		} while ( $show_category->PARENT_ID != 0 );
     		
     		return true;

	} // end of function get_category_tree($category)
	
//####################################################################################

	function DateDifference ($interval, $date1,$date2) 
	{
		$difference =  $date2 - $date1;
		switch ($interval) 
		{
			case "w":
				$returnvalue  =$difference/604800;
				break;
			case "d":
				$returnvalue  = $difference/86400;
				break;
			case "h":
				$returnvalue = $difference/3600;
				break;        
			case "m":
				$returnvalue  = $difference/60;
				break;        
			case "s":
				$returnvalue  = $difference;
				break;        
	    	}    
	    	return $returnvalue;
	} //end of function DateDifference	    

//####################################################################################

	function classified_exists ($db,$classified_id=0) 
	{
		if ($classified_id)
		{
			$sql_query = "select id from ".$this->classifieds_table." where id = ".$classified_id;
			$result = &$db->Execute($sql_query);
			
			if (!$result)
			{
				$this->error_message = $this->messages[2524];
				return false;				
			}
			elseif ($result->RecordCount() == 1)
			{
				return true;
			}
			else
			{
				$this->error_message = $this->messages[2524];
				return false;			
			}
		}    
		else
		{
			//no classified id to check
			$this->error_message = $this->messages[2524];
			return false;
		}
	 } //end of function classified_exists	 
	
//####################################################################################

	function browse_error () 
	{
		//this->error_message is the class variable that will contain the error message
		echo "<table cellpadding=5 cellspacing=1 border=0>\n";
		echo "<tr>\n\t<td>".$this->messages[2523]."</td>\n</tr>\n";
				if ($this->error_message)
			echo "<tr>\n\t<td>".$this->error_message."</td>\n</tr>\n";
		echo "</table>\n";  
	 } //end of function browse_error	 
	
//####################################################################################

	function main($db) 
	{
		echo "<table cellpadding=5 cellspacing=1 border=0 width=600 align=center>\n";
		echo "<tr>\n\t<td>".$this->font_title_tag.$this->messages[2525]."</td>\n</tr>\n";
		echo "<tr>\n\t<td>".$this->font_tag.$this->messages[2526]."</td>\n</tr>\n";
		echo "<tr>\n\t<td>\n\t";
		if (!$this->browse_main($db))
			$this->browse_error();
		echo "</td>\n</tr>\n";
		echo "</table>\n";  
		return true;
	 } //end of function main	 
	
//####################################################################################

	function browse_main($db) 
	{
		$sql_query = "select * from ".$this->classifieds_categories_table." where parent_id = 0 order by display_order";
		$result = &$db->Execute($sql_query);
		if (!$result)
		{
			//echo $sql_query." is the query<br>\n";
			$this->error_message = $this->messages[2524];
			return false;			
		}
		elseif  ($result->RecordCount() > 0)
		{
			echo "<table cellpadding=5 cellspacing=1 border=0>\n\t";
			while ($show = $result->FetchNextObject())
			{
				$count = $this->get_ad_count_for_category($db,$show->CATEGORY_ID);
				echo "<tr>\n\t\t<td>
					<a href=classifieds.php?a=5&b=".$show->CATEGORY_ID.">
					".$this->font_title_tag.$show->CATEGORY_NAME."</a>";
					
				if ($this->display_counter)
					echo "(".$count.")";
				echo "\n\t\t</td>\n\t</tr>\n\t";
			}
			echo "</table>\n";
			return true;
		}
		else
		{
			echo "<table cellpadding=5 cellspacing=1 border=0>\n\t";
			echo "<tr>\n\t<td>".$this->font_title_tag.$this->messages[2527]."</td>\n</tr>\n";
			echo "</table>\n";		
			return true;
		}
		

	 } //end of function main	 
	
//#####################################################################

	function delete_images ($classified_id)
	{
		if (is_file($this->classified_images_path.$classified_id.".gif"))
		{
			//echo "gif exists<br>\n";
			//chmod ($this->classified_images_path.$classified_id.".gif", 0777);	
			unlink($this->classified_images_path.$classified_id.".gif");
		}
		if (is_file($this->classified_images_path.$classified_id.".jpg"))
		{
			//echo "jpg exists<br>\n";
			chmod ($this->classified_images_path.$classified_id.".jpg", 0777);	
			unlink($this->classified_images_path.$classified_id.".jpg");
		}
	} //end of function delete_images

//####################################################################################

	function classified_close($db)
	{
		$current_time = time();
		
		$sql_query = "select id from ".$this->classifieds_table." where ends < ".$current_time;
		$delete_result = &$db->Execute($sql_query);
		if (!$delete_result)
		{
			$this->error_message = $this->messages[2524];
			return false;			
		}
		elseif ($delete_result->RecordCount() > 0)
		{ 
			while ($show = $delete_result->FetchNextObject())
			{
				@chmod ($this->classified_images_path.$show->ID.".jpg", 0777);
				@unlink($this->classified_images_path.$show->ID.".jpg");
				
				@chmod ($this->classified_images_path.$show->ID.".gif", 0777);
				@unlink($this->classified_images_path.$show->ID.".gif");							
			}
			
			$sql_query = "delete from ".$this->classifieds_table." where ends < ".$current_time;
			$result = &$db->Execute($sql_query);
			if (!$result)
			{
				$this->error_message = $this->messages[2524];
				return false;			
			}
		}
		
	} //end of function classified_close
	
//##################################################################################3

	function classified_force_close($db)
	{
		$sql_query = "select * from ".$this->classifieds_table." where closed = 0";
		$result = &$db->Execute($sql_query);
		if (!$result)
		{
			$this->error_message = $this->messages[2524];
			return false;			
		}
		elseif  ($result->RecordCount() > 0)
		{
			//close these classifieds
			while ($show = $result->FetchNExtObject())
			{


			} //end of while
		}
		
	} //end of function classified_force_close

//##################################################################################3

	function admin_delete_classified($db,$classified_id=0)
	{
		if ($classified_id)
		{
			$sql_query = "delete from ".$this->classifieds_table." where id = ".$classified_id;
			$result = &$db->Execute($sql_query);
			if (!$result)
			{
				//echo $sql_query." is the query<br>\n";
				$this->error_message = $this->messages[2524];
				return false;			
			}
			return true;
		}
		else
		{
			$this->error_message = $this->messages[2524];
			return false;
		}
		
	} //end of function admin_delete_classified

//##################################################################################

	function get_row_color($i)
	{
		if (($i % 2) == 0)
			$row_color = $this->background_color_light;
		else
			$row_color = $this->background_color_dark;
		return $row_color;
	} //end of function get_row_color

//##################################################################################

	function get_ad_count_for_category($db,$category_id=0)
	{
		if ($category_id)
		{
			//get the count for this category
			$count = 0;
			
			$sql_query = "select category_id from ".$this->classifieds_categories_table." where parent_id = ".$category_id;
			$result = &$db->Execute($sql_query);
			if (!$result)
			{
				//echo $sql_query." is the query<br>\n";
				$this->error_message = $this->messages[2524];
				return false;			
			}
			elseif ($result->RecordCount() > 0)
			{
				while ($show_category = $result->FetchNextObject())
				{
					$returned_count = $this->get_ad_count_for_category($db,$show_category->CATEGORY_ID);
					if ($returned_count)
						$count += $returned_count;
					
					//echo $count." is count returned for category ".$category_id."<br>\n";
				}
			}
		
			$count += $this->get_ad_count_this_category($db,$category_id);
			
			return $count;
		}
		else
		{
			//category_id is missing
			return false;
		}		
		
	} //end of function get_ad_count_for_category

//##################################################################################

	function get_ad_count_this_category($db,$category_id=0)
	{
		if ($category_id)
		{
			$sql_query = "select count(*) as total from ".$this->classifieds_table." where category = ".$category_id;
			$result = &$db->Execute($sql_query);
			if (!$result)
			{
				//echo $sql_query." is the query<br>\n";
				$this->error_message = $this->messages[2524];
				return false;			
			}
			elseif ($result->RecordCount() == 1)
			{
				$show = $result->FetchNextObject();
				return $show->TOTAL;				
			}
			else
			{
				return false;
			}
			
		}
		else
		{
			//category_id is missing
			return false;
		}		
		
	} //end of function get_ad_count_this_category

//##################################################################################

	function get_sql_in_array($db,$category_id)
	{
		if ($category_id)
		{
			//get the count for this category
			$count = 0;
			
			$sql_query = "select category_id from ".$this->classifieds_categories_table." where parent_id = ".$category_id;
			$result = &$db->Execute($sql_query);
			if (!$result)
			{
				//echo $sql_query." is the query<br>\n";
				$this->error_message = $this->messages[2524];
				return false;			
			}
			elseif ($result->RecordCount() > 0)
			{
				while ($show_category = $result->FetchNextObject())
				{
					$this->get_sql_in_array($db,$show_category->CATEGORY_ID);
				}
			}
		
			array_push ($this->subcategory_array, $category_id);
						
			return true;
		}
		else
		{
			//category_id is missing
			return false;
		}		
		
	} //end of get_sql_in_array
	
//##################################################################################

	function get_sql_in_statement($db,$category_id)
	{
		if ($category_id)
		{
			$this->get_sql_in_array($db,$category_id);
			if (count($this->subcategory_array) > 0)
			{
				$in_statement .= "in (";
				while (list($key,$value) = each($this->subcategory_array))
				{
					if ($key == 0)
						$in_statement .= $value;
					else
						$in_statement .= ",".$value;
				}
				$in_statement .= ")";
				return $in_statement;
			}
			else
			{
				return false;
			}
		}
		else
		{
			//category_id is missing
			return false;
		}		
		
	} //end of get_sql_in_statement
	
//##################################################################################


} //end of class Classified_browse

?>