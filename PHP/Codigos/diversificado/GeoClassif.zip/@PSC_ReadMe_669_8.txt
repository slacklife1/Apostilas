Title: GeoClassifieds Lite
Description: GeoClassifieds Lite is a highly versatile free Classified Ads script created with PHP and MySQL that can be easily installed on any website. It is a skeletal version of the full GeoClassifieds designed for additional customization by developers. From a �dating service� to �widgets�, its multiple-tier category system is set up to accommodate virtually any product or service market.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=669&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
