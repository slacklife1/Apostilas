-= DLCOUNT 1.00 =-
DLCount counts the number of downloads and stores the results in a single 
text file. Entries are separated by pipes "|" and split in to an array 
while reading. Includes DLCount Admin to view your counter stats in a table. 
DLCount can also be used to count how many times a link was clicked on. 
Example: /dlcount/dlcount.php3?http://www.php.net/
DLCount requires PHP 3.0.7 or later.

-= INSTALLATION =-
- unzip dlcount.php3, dlcountadmin.php3 and dlcount.text into a directory.
- chmod dlcount.text to 0666 (read/write for everyone).
- in dlcount.php3 and dlcountadmin.php3 change the path for $dlcountfile.
- in dlcountadmin.php3 change $password to your own password.
- alter your links. example: /dlcount/dlcount.php3?url=http://somesite.com/somefile.zip

-= HISTORY =-
- 1.00: Nov 19, 1999: First public release.


Have fun,

Sascha Blansjaar
http://phtml.com/