Title: backup_mySQL beta
Description: This code gives a dump(backup) of your local or remote database.
I use this in combination with vb to backup my remote database.
If you are interested in the vb_code to do so... let me know....
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=628&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
