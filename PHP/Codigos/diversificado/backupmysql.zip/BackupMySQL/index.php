<html>
<head>
<style>
body{font-family:'Arial'; font-size:'12';}
#menu {color:#333333; background-color:'CCCC99';border :'1px ridge #CCCC99';font-size:'12'}
#titel{font-size:'18'; color:#FFFFFF; background-color:'#000080';border :'1px ridge #CCCC99';}
</style>
</head>

<body leftmargin="0" topmargin ="0" bgcolor="#F8F8FF">
<table width="100%" height="75%" border="0" align="center" valign="middle">
	<tr><td>
	<table width="200" border="0" align="center">
		<tr>
			<td id="titel" width="200" align="center" valign="middle">- BACKUP -</td>
		</tr>
		<tr>
			<td id="menu" width ="200"><br>
			<form action="backupdb.php" method="post">
				&nbsp;&nbsp;<input type="Checkbox" name="createData">Data<br>
				&nbsp;&nbsp;<input type="Checkbox" name="dropTable">Add 'drop table'<br>
				&nbsp;&nbsp;<input type="Checkbox" name="createTable" checked="true">Structure<br><br>
				<p align="center"><input type="submit"></p>
			</form>
			</td>
		</tr>
	</table>
	</td></tr>
</table>
</body>
</html>