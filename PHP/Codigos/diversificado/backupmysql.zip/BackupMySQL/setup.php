<?
$user="root";
$dbName="dbname";
$host="localhost";
$dbPass="";
?>
