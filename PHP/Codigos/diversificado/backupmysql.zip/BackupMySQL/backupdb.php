<html><head></head><body bgcolor="#F8F8FF"><font face="verdana,arial" size="-2" >
<?
include "setup.php";
//connect to mysql_server
$connect = mysql_connect($host,$user,$dbPass);
//connect to database
mysql_select_db($dbName);

$tables = mysql_query("SHOW TABLE STATUS");
$tCount =  mysql_num_rows($tables);
while ($tableRows = mysql_fetch_row($tables)) {
	if (isset($createTable)) {
		echo "#<br>";
		echo "# Table structure for table `" . $tableRows[0] . "`<br>\n";
		echo "#<br><br>";
	}
	if (isset($dropTable)){
		echo "DROP TABLE IF EXISTS ".$tableRows[0].";<br>";
	}
	if (isset($createTable)) {
	$buildSQL ="CREATE TABLE ". $tableRows[0] ." (<br>";
	$fields = mysql_query("SHOW FULL FIELDS FROM ". $tableRows[0]);
	$mCount = 0;
			while($fieldRows = mysql_fetch_row($fields)) {
				$buildSQL .= "&nbsp;&nbsp;".$fieldRows[0]." ".$fieldRows[1];
				if ($fieldRows[2]!="YES"){
					if ($fieldRows[1] != "text") {
						$buildSQL .= " NOT NULL ";
					}else{
						$buildSQL .= " NOT NULL";
					}
					if ($fieldRows[3]=="PRI"){
						$Prim = "PRIMARY KEY (".$fieldRows[0].")<br>\n";
					}else{
						if ($fieldRows[1] != "text") {
							if ($fieldRows[4]== ''){
								$buildSQL.= "default ''";
							}else{
								$buildSQL.= "default '".$fieldRows[4]."'";
							}
						}
					}
				}else{
					if ($fieldRows[1] != "text") {
						if (isset($fieldRows[4]) == false){
							$buildSQL .= " default NULL";
						} else {
							$buildSQL.= " default '".$fieldRows[4]."'";
						}
					}
				}
				
				if ($mCount == $fieldRows){$buildSQL .= $fieldRows[5]."<br>\n";}else{if ($fieldRows[5] ==''){$buildSQL .=",<br>\n";}else{$buildSQL .= " ".$fieldRows[5].",<br>\n";}};
				$mCount = $mCount + 1;
			}	
	if(isset($Prim)){$buildSQL .= "&nbsp;&nbsp;". $Prim;};		
	$buildSQL .=") TYPE=". $tableRows[1] .";<br><br>\n";
	unset($Prim);
	unset($mCount);
	echo $buildSQL;
	}
	if (isset($createData)) {	
		echo "#<br>";
		echo "# Data for table `".$tableRows[0]."`<br>";
		echo "#<br><br>";
	
	$result = mysql_query("SELECT * FROM " .$tableRows[0]);
	while ($wRows = mysql_fetch_row($result)){ 
		echo "INSERT INTO ".$tableRows[0]." VALUES (";
		$mCount = mysql_num_fields($result);
			for ($i=0; $i < $mCount;$i++) {
				if ($i != $mCount-1) {
					if (mysql_field_type($result,$i) == "string" || mysql_field_type($result,$i) == "blob"){
						$flags=mysql_field_flags($result,$i);
						$flags=strpos($flags,"not_null");
						if (isset($wRows[$i]) == true){
							$mTemp=addslashes($wRows[$i]);
							echo "'".$mTemp."', ";
						}else{
							if ($flags == 0){echo "NULL, ";}else{echo "'', ";};
						}
					}else{
						$flags=mysql_field_flags($result,$i);
						$flags=strpos($flags,"not_null");
						if (isset($wRows[$i]) == true){
							echo $wRows[$i].", ";
						}else{
							if ($flags == 0){echo "NULL, ";}else{echo " , ";};
						}
					}
				}else{
					if (mysql_field_type($result,$i) == "string" || mysql_field_type($result,$i) == "blob"){
						$flags=mysql_field_flags($result,$i);
						$flags=strpos($flags,"not_null");
						if (isset($wRows[$i]) == true){
							$mTemp=addslashes($wRows[$i]);
							echo "'".$mTemp."'";
						}else{
							if ($flags == 0){echo "NULL";}else{echo "''";};
						}
					}else{
						$flags=mysql_field_flags($result,$i);
						$flags=strpos($flags,"not_null");
						if (isset($wRows[$i]) == true){
							echo $wRows[$i];
						}else{
							if ($flags == 0){echo "NULL";};
						}
						
					}
				}
			unset($flags);
			}
		echo ");<br>";
	  }
	}
$cCount = $cCount + 1; 
if (isset($createData)) {	
if ($cCount != $tCount){
	echo "<br>";
	echo "# --------------------------------------------------------<br><br>";
} 
}
}
?>
</font></body></html>