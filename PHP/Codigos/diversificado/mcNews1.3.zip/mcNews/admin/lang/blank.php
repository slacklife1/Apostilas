<?
////////////////////////////////////////////////////////////////////
// mcNews 1.2 Marc Cagninacci marc@phpforums.net                  //
//                                                                //
// Use this blank file to translate in an other language,         //
// complete with your name (and email and site if you wish),      //
// then please send it to me, so I can provide it to other users  //
// Thanks in advance.                                             //
//                                                                //
////////////////////////////////////////////////////////////////////
// Translation by:                                                //
// @ :                                                            //
// www :                                                          //
////////////////////////////////////////////////////////////////////

$lAccept = ""; // "Accept";
$lAccueil = ""; // "mcNews Administration";
$lAucun = ""; // "No";
$lAuteur = ""; // "Author";
$lAvec = ""; // "With";
$lBordure = ""; // "Borders";
$lChoisir = ""; // "Pick a skin :";
$lChoisirLang = ""; // "Pick a language :";
$lComment = ""; // "Comment by";
$lcomment = ""; // "comment";
$lCommentNum = ""; // "Comment #";
$lComments = ""; // "Comments";
$lcomments = ""; // "comments";
$lCommentsTemp = ""; // "Comments waiting for validation";
$lConBase = ""; // "Connexion to the database";
$lConf = ""; // "Configuration";
$lConHost = ""; // "Connection to the host";
$lConnexion = ""; // "Log In";
$lCreTables = ""; // "The script will now create tables";
$lDans = ""; // "in";
$lDate = ""; // "Date";
$lDeconnexion = ""; // "Log Out";
$lDel = ""; // "Delete";
$lDescr = ""; // "Description";
$lDesignParam = ""; // "Design Parameters";
$lDropTables = ""; // "Attention: If these tables already exists, they will be suppressed and all datas deleted";
$lEcrire = ""; // "Write";
$lEcrireComment = ""; // "Write a Comment";
$lEmail = ""; // "Email";
$lEmailAdmin = ""; // "Moderator's email address";
$lErreur = ""; // "The fields Name, Title ant Text are required.";
$lErreurEmail = ""; // " Email is not required,<br>but a valid address is required if you fill it.";
$lErreurMail = ""; // "The fields Email 'yours), Subject ant Text are required.";
$lErrLog = ""; // "Wrong Login!";
$lErrPass = ""; // "Wrong Password!";
$lFormatDate = ""; //"en";
$lGoAdmin = ""; // "Go to mcNews setup";
$lGoValid = ""; // "You have to go to mcNews/admin to validate it.";
$lImpossible = ""; //"failed.<br>Verify the datas in the file <b>config.inc.php</b>";
$lInvalidEmail = ""; // "Your email address must be valid.";
$lLast = ""; // "Lastest";
$lLien = ""; // "Link";
$lLiensRapp = ""; // "Related links";
$lLire = ""; // "Read";
$lListe = ""; // "List";
$lLogin = ""; // "Name";
$lMailSent = ""; // "Message sent to";
$lMailTo = ""; // "Send a message to";
$lMerci = ""; // "Thanks for your contribution. Your text will be published as soon as possible, after webmaster's validation.";
$lMercival = ""; //  "Thanks for your contribution.";
$lMethode = ""; // "Type a maximum of three words, separated with comas ( , )";
$lModifComm = ""; //"Modify a Comment";
$lModifier = ""; // "Edit";
$lModifNews = ""; // "Modify a News";
$lMustval = "";  // "Must be accepted before published";
$lNbListe = ""; // "Number of News to display (list page)";
$lNbNews = ""; //  "Number of News to display (index page)";
$lNews = ""; //  "News";
$lNewsTemp = ""; // "News waiting for validation";
$lNewsValid = ""; // "Validated News";
$lNomAdmin = ""; // "Name as \"Author\"";
$lOk = ""; // "OK";
$lPass = ""; // "Password";
$lPostCom = ""; // "A Comment has been posted";
$lPostNews = ""; // "A News has been posted";
$lPropo = ""; // "Submit a News";
$lPubliCom = ""; // "Write a Comment";
$lPubliNews = ""; // "Write a News";
$lRetour = ""; // "Back to the Site";
$lRetourSite = ""; // "Back to the Site";
$lSearch = ""; // "Search";
$lSite = ""; // "Web Site URL";
$lSommaire = ""; // "Index";
$lSubmit = ""; // "Submit";
$lSujet= ""; // "Subject";
$lTablesOk = ""; // "Tables are created.
                  //<br>You could verify in your database.
                  //<br>The file <b>install.php</b> is now useless.
                  //<br>You can drop this file <b>install.php</b> from your site.";
$lTechParam = ""; // "Technical Parameters";
$lTexte = ""; // "Text";
$lTitre = ""; // "Title";
$lTous = ""; // "All the words";
$lUn = ""; // "At least one word";
$lValid = ""; //  "Accepted";
$lVoirSkin = ""; // "See it";
?>
