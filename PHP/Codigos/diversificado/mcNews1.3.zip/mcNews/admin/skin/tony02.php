<?
// mcNews 1.1 Marc Cagninacci marc@phpforums.net
// skin de tony pour mcNews     tonypage@free.fr
//                            tons VERT et BEIGE
$BodyBgcolor="#ffffcc";
$FontFace="Ms Sans Serif";
$FontLien="Ms Sans Serif";
$LienWeight="normal";
$LienColor="#666600";
$LienSurvolColor="#33cc33";
$TableBgcolor="#6e8e23";
$TDBgcolorTitre="#006400";
$FontColorTitre="#ffffcc";
$FontSizeTitre="2";
$TDBgcolorAuteur="#cccc99";
$FontColorAuteur="#666600";
$FontSizeAuteur="2";
$TDBgcolorTexte="#ffffcc";
$FontColorTexte="#330033";
$FontSizeTexte="2";
?>
