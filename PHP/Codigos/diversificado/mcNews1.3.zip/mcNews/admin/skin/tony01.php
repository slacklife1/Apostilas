<?
// mcNews 1.1 Marc Cagninacci marc@phpforums.net
// skin de tony pour mcNews     tonypage@free.fr
//                                     tons BLEU
$BodyBgcolor="#ddeeff";
$FontFace="Ms Sans Serif";
$FontLien="Ms Sans Serif";
$LienWeight="normal";
$LienColor="#002850";
$LienSurvolColor="red";
$TableBgcolor="#6c859c";
$TDBgcolorTitre="#506e87";
$FontColorTitre="#ffcc00";
$FontSizeTitre="2";
$TDBgcolorAuteur="#ddeeff";
$FontColorAuteur="#002850";
$FontSizeAuteur="2";
$TDBgcolorTexte="#cbe5ff";
$FontColorTexte="#000000";
$FontSizeTexte="2";
?>
