<?
////////////////////////////////////////////////////////////////////
// mcNews 1.1 Marc Cagninacci marc@phpforums.net                  //
//                                                                //
// Use this blank file to make new skins,                         //
// complete with your name (and email and site if you wish),      //
// then please send it to me, so I can provide it to other users  //
// Thanks in advance.                                             //
//                                                                //
////////////////////////////////////////////////////////////////////
// Skin designed by:                                              //
// @ :                                                            //
// www :                                                          //
////////////////////////////////////////////////////////////////////


$BodyBgcolor="";
$FontFace="";
$FontLien="";    // link font face
$LienWeight="";  // normal, bold ...
$LienColor="";   // link font color
$LienSurvolColor="";   // link "hover" color
$TableBgcolor="";
$TDBgcolorTitre="";
$FontColorTitre="";
$FontSizeTitre="";
$TDBgcolorAuteur="";
$FontColorAuteur="";
$FontSizeAuteur="";
$TDBgcolorTexte="";
$FontColorTexte="";
$FontSizeTexte="";
?>