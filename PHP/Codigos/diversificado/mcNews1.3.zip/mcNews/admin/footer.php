<p align="center">
<br><br>
<a href="http://www.phpforums.net/index.php?dir=dld" target="_blank"><img border="0" src="../images/mcn.gif"
        alt="Download mcNews"></a><br><br>
<a href="http://validator.w3.org/check/referer"><img border="0" src="../images/w3c.gif"
        alt="Valid HTML 4.01!" height="31" width="88"></a>

</p>
</body>
</html>