<?
$host="";
$login="";
$pass="";
$base="";
$admin_login="";
$admin_pass="";
?>
