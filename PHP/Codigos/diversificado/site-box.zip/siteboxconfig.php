<?php
// mySQL LOGIN --------------------
$servername=	"localhost";
$dbusername=	"mysqlusername";
$dbpassword=	"mysqlpass";
$dbname =   	"mysqldbname";

$sitepath = "http://syn.up-root.org";
$timeoffset = 0;
// SHOUTBOX -----------------------
$postdisp = 	"	<font face=\"verdana\" size=1><font color=#333333><b>
			<a href=\"javascript:newwin('shoutinfo.php?id=!id');\" class=\"shout\">!nick</a>
			</b></font><font color=#555555> - !date<br>!comment</font><br><br></font>
		";
$break =	10;

// GUESTBOOK ----------------------
$gbookform = 	"	<font face=\"Verdana\" size=1 color=\"#003C4A\">
			<form onSubmit=\"document.gbook.submitter.disabled='true'\" name=\"gbook\" method=\"post\" action=\"sendgbook.php\">
			<input type=\"hidden\" name=\"ip\" value=\"$REMOTE_ADDR\">
			<input type=\"hidden\" name=\"page\" value=\"$PHP_SELF\">
			<table border=0 cellspacing=0 cellpadding=2 align=center>
				<tr>		<td width=60 align=right><font face=\"Verdana\" size=1 color=\"#555555\">Nick:</font></td>
						<td width=220 align=left><input type=\"text\" name=\"nick\" style=\"font-family: Verdana, Arial, sans-serif; font-size: 9px; width: 220px\"></td>
				</tr><tr>	<td width=60 align=right><font face=\"Verdana\" size=1 color=\"#555555\">Email:</font></td>
						<td width=220 align=left><input type=\"text\" name=\"email\" style=\"font-family: Verdana, Arial, sans-serif; font-size: 9px; width: 220px\"></td>
				</tr><tr>	<td width=60 align=right><font face=\"Verdana\" size=1 color=\"#555555\">Website:</font></td>
						<td width=220 align=left><input type=\"text\" name=\"url\" style=\"font-family: Verdana, Arial, sans-serif; font-size: 9px;\ width: 220px\"></td>
				</tr><tr>	<td width=280 colspan=2><font face=\"Verdana\" size=1 color=\"#555555\">		
							Comment:<br>
							<textarea name=\"comment\" cols=54 rows=4 style=\"font-family: Verdana, Arial, sans-serif; font-size: 9px;\"></textarea><p align=\"right\"><input type=\"submit\" name=\"submitter\" value=\"post\" style=\"font-family: Verdana, Arial, sans-serif; font-size: 9px;\"></p>
						</font></td>
				</tr>
			</table></form><center>
		";
$gbookpost =	"	<img src=\"img/divider.gif\" width=\"293\"><br>
				<table width=100% border=0 cellpadding=0 cellspacing=3>
					<tr>		<td><font face=\"verdana\" size=1 color=\"#333333\"><b>!nick</b></font></td>
							<td align=right><font face=\"verdana\" size=1 color=\"#555555\">!date</font></td>
					</tr>
				</table>
				<table width=100% border=0 cellpadding=0 cellspacing=3 align=center>
					<tr>		<td><font face=\"verdana\" size=1 color=\"#555555\">!ip</td>
							<td align=right><font face=\"verdana\" size=1 color=\"#555555\">!urls</font></td>
					</tr><tr>	<td colspan=2><font face=\"verdana\" size=1 color=\"#555555\">!comment</font></td>
					</tr>
				</table><br>
		";
$gbookarchive =	"<font face=\"Verdana\" size=1 color=\"555555\"><a href=\"$PHP_SELF?start=!prev\">&lt;&lt;</a>&nbsp;&nbsp;!sview - !eview of !total&nbsp;&nbsp;<a href=\"$PHP_SELF?start=!next\">&gt;&gt;</a></font>";
?>