<?
require("siteboxconfig.php");

$connection = mysql_connect ("$servername", "$dbusername", "$dbpassword");
mysql_select_db ("$dbname");


if ($nick != null AND $nick != "name" AND $comment != null AND $comment != "message") {
	$date = time();
	if (!mysql_query ("INSERT INTO shouts (id, nick, date, ip, comment) values (NULL, '$nick', '$date', '$ip', '$comment')")) {
		echo mysql_error();
	}
}
mysql_close($connection);
Header("Location: $sitepath" . "$page");
?>