<HEAD>
</HEAD>

<?
require("siteboxconfig.php");
?>

<?
$connection = mysql_connect ("$servername", "$dbusername", "$dbpassword");
mysql_select_db ("$dbname");

mysql_query("CREATE TABLE shouts (id int(4) NOT NULL auto_increment, nick text, date text, ip text, comment text, PRIMARY KEY (id))") or die(mysql_error()); 
print "The table <b>shouts</b> was succesfully created<br>";

mysql_query("CREATE TABLE gbook (id int(4) NOT NULL auto_increment, nick text, date text, ip text, email text, url text, comment text, PRIMARY KEY (id))") or die(mysql_error()); 
print "The table <b>gbook</b> was succesfully created<br>";

mysql_query("CREATE TABLE banlist (id int(4) NOT NULL auto_increment, ip text, comment text, PRIMARY KEY (id))") or die(mysql_error());
print "The table <b>banlist</b> was succesfully created<br>";
?>
</BODY>
</HTML>