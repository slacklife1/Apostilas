Site-Box
 Release 10
 by Derrick Staples
 http://syn.up-root.org

Updates:
 Release 10
  - Second release in 1 day :|
  - Added a time offset feature (add 3600
    for every hour the time is behind, or
    -3600 for every hour the time is
    ahead)
  - Also fixed automatic url creation.
    This was done earlier but somehow versions
    were mixed.
 Release 9
  - Someone shoot me... added in the same
    multi-post spam protection to the gbook
    as I did the shoutbox.  (Note, do NOT
    edit the shoutbox and guestbooks <form...>
    and <input type="submit"...> tags, they're
    important for the protection.)
 Release 8
  - This section of the readme will now show
    people whats added to the script :)
  - Added a function so shouters can no longer
    hold down the enter button and spam.
    (Locks the submit button once submit is
    triggered)

Notice: I cannot be held responsible for any damage
 these files do to your computer/website/database
 and/or server. The code found in these files is
 open-source obviously, so learn from it and edit
 it as you please.

Installing: First edit siteboxconfig.php, filling
 in your mySQL access information, and editing
 how you want the data to be displayed.  You
 will have to figure out the special variables
 for yourself, but it shouldn't be too incredibally
 difficult, and remember to put a "\" before every
 quotation mark.  To add the shoutbox to a page,
 just put '<? include("shoutbox.php"); ?>' in your
 page, and '<? include("gbook.php"); ?>' for the
 guestbook.

Contact: If your needing help with the scripts or
 just want to give me money, you can contact me via
 any of these methods:
  Email:  Sole@up-root.org
  ICQ:	  31039406
  AIM:	  SoleDev
  MSN:	  solereaver@hotmail.com
  IRC:	  irc.breakfree.com / #razorart