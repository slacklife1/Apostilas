<script language="javascript">
function newwin($url) {
	window.open($url, 'winpopup', config='height=250,width=300');
}
</script>

<?
require("siteboxconfig.php");

$connection = mysql_connect ("$servername", "$dbusername", "$dbpassword");
mysql_select_db ("$dbname");

$userip = $REMOTE_ADDR;
$banned = 0;
$result = mysql_query("SELECT * FROM banlist ORDER BY id DESC");
if ($row = mysql_fetch_array($result)) {
	do {
		$id = $row[id];
		$ip = $row[ip];
		$comment = $row[comment];
		
		$iplength = strlen($ip);
		$temp = Substr($userip, 0, $iplength);
		if ($temp == $ip) {
			echo "<center><b>banned :P</b></center>";
			$banned = 1;
		}
	} while($row = mysql_fetch_array($result));
}

if ($banned == 0) {
	echo "
		<center>
		<form onSubmit=\"document.shout.submitter.disabled='true'\" name=\"shout\" method=\"post\" action=\"sendshout.php\">
		<input type=\"hidden\" name=\"ip\" value=\"$userip\">
		<input type=\"hidden\" name=\"page\" value=\"$PHP_SELF\">
		<input type=\"text\" name=\"nick\" value=\"name\" maxlength=10 size=12 style=\"font-family: Verdana, Arial, sans-serif; font-size: 9px;\"><br>
		<input type=\"text\" name=\"comment\" value=\"message\" maxlength=200 size=12 style=\"font-family: Verdana, Arial, sans-serif; font-size: 9px;\"><br>
		<input type=\"submit\" value=\"shout\" name=\"submitter\" style=\"font-family: Verdana, Arial, sans-serif; font-size: 9px;\">
		</form></center>
	";

	function replace_text_smiley() {
		global $comment;
		$faces[" :)"] =  " <IMG SRC=\"emoticons/smile.gif\">";
		$faces[" :P"] =  " <IMG SRC=\"emoticons/tongue.gif\">";
		$faces[" :D"] =  " <IMG SRC=\"emoticons/happy.gif\">";
		$faces[" :("] =  " <IMG SRC=\"emoticons/mad.gif\">";
		$faces[" ;)"] =  " <IMG SRC=\"emoticons/wink.gif\">";
		$faces[" :|"] =  " <IMG SRC=\"emoticons/blank.gif\">";
		$faces[" :/"] =  " <IMG SRC=\"emoticons/smirk.gif\">";
		$faces[" :\\"] = " <IMG SRC=\"emoticons\smirk.gif\">";
		$faces[" =)"] =  " <IMG SRC=\"emoticons/smile.gif\">";
		$faces[" =P"] =  " <IMG SRC=\"emoticons/tongue.gif\">";
		$faces[" =D"] =  " <IMG SRC=\"emoticons/happy.gif\">";
		$faces[" =("] =  " <IMG SRC=\"emoticons/mad.gif\">";
		$faces[" =|"] =  " <IMG SRC=\"emoticons/blank.gif\">";
		$faces[" =/"] =  " <IMG SRC=\"emoticons/smirk.gif\">";
		$faces[" =\\"] = " <IMG SRC=\"emoticons\smirk.gif\">";
		while(list($text,$image) = each($faces)) {
			$comment = str_replace("$text","$image","$comment");
		}
		return $comment;
	}
	$result = mysql_query("SELECT * FROM shouts ORDER BY id DESC LIMIT 10");
	if ($row = mysql_fetch_array($result)) {
		do {
			$showpost = $postdisp;
			$id = $row[id];
			$nick = $row[nick];
			$date = date("g.ia", ($row[date] + $timeoffset));
			$ip = $row[ip];
			$comment = $row[comment];
			$comment = strip_tags($comment);
			$comment = eregi_replace("((http|https|mailto|ftp):(\/\/)?[^[:space:]<>]{1,})", "[\n<a href=\"\\1\">link\n</a>]", $comment);
			$comment = eregi_replace("([_\.0-9a-z-]+@([0-9a-z][0-9a-z-]+\.)+[a-z]{2,3})","[\n<A HREF=\"mailto:\\1\">mail\n</A>]", $comment);
			replace_text_smiley();
			$comment = wordwrap($comment, $break, "\n", 1);
			$showpost = eregi_replace("!id", "$id", $showpost);
			$showpost = eregi_replace("!nick", "$nick", $showpost);
			$showpost = eregi_replace("!date", "$date", $showpost);
			$showpost = eregi_replace("!ip", "$ip", $showpost);
			$showpost = eregi_replace("!text", "$text", $showpost);
			$showpost = eregi_replace("!comment", "$comment", $showpost);
			echo "$showpost";
		} while($row = mysql_fetch_array($result));
	}
	echo "
	</td>
                    </tr>
                  </table>
	";
}
mysql_close($connection);
?>