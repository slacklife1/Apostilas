<html><head><title>Shout Info #<? echo "$id"; ?></title>
<style type="text/css">
a:link { text-decoration: underline; color: #000000; }
a:visited { text-decoration: underline; color: #000000; }
a:active { text-decoration: none; color: #265A79; }
a:hover { text-decoration: none; color: #265A79; }
</style>
</head><body text="#000000" bgcolor="#ffffff" topmargin=0 leftmargin=0 bottommargin=0 rightmargin=0 marginwidth=0 marginheight=0>

<?
require("siteboxconfig.php");

$connection = mysql_connect ("$servername", "$dbusername", "$dbpassword");
mysql_select_db ("$dbname");

function replace_text_smiley() {
	global $comment;
	$faces[" :)"] = " <IMG SRC=\"emoticons/smile.gif\"> ";
	$faces[" :P"] = " <IMG SRC=\"emoticons/tongue.gif\"> ";
	$faces[" :D"] = " <IMG SRC=\"emoticons/happy.gif\"> ";
	$faces[" :("] = " <IMG SRC=\"emoticons/mad.gif\"> ";
	$faces[" ;)"] = " <IMG SRC=\"emoticons/wink.gif\"> ";
	$faces[" :|"] = " <IMG SRC=\"emoticons/blank.gif\"> ";
	$faces[" :/"] = " <IMG SRC=\"emoticons/smirk.gif\"> ";
	$faces[" :\\"] = " <IMG SRC=\"emoticons\smirk.gif\"> ";
	$faces[" =)"] = " <IMG SRC=\"emoticons/smile.gif\"> ";
	$faces[" =P"] = " <IMG SRC=\"emoticons/tongue.gif\"> ";
	$faces[" =D"] = " <IMG SRC=\"emoticons/happy.gif\"> ";
	$faces[" =("] = " <IMG SRC=\"emoticons/mad.gif\"> ";
	$faces[" =)"] = " <IMG SRC=\"emoticons/wink.gif\"> ";
	$faces[" =|"] = " <IMG SRC=\"emoticons/blank.gif\"> ";
	$faces[" =/"] = " <IMG SRC=\"emoticons/smirk.gif\"> ";
	$faces[" =\\"] = " <IMG SRC=\"emoticons\smirk.gif\"> ";
	while(list($text,$image) = each($faces)) {
		$comment = str_replace("$text","$image","$comment");
	}
	return $comment;
}
$result = mysql_query("SELECT * FROM shouts WHERE id = $id");
if ($row = mysql_fetch_array($result)) {
	do {
		$id = $row[id];
		$nick = $row[nick];
		$date = date("l, jS F Y - g.ia", ($row[date] + $timeoffset));
		$ip = $row[ip];
		$comment = $row[comment];
		$comment = strip_tags($comment);
		$comment = eregi_replace("((http|https|mailto|ftp):(\/\/)?[^[:space:]<>]{1,})", "[<a href='\\1'>\\1</a>]", $comment);
		$comment = eregi_replace("([_\.0-9a-z-]+@([0-9a-z][0-9a-z-]+\.)+[a-z]{2,3})","[<A HREF=\"mailto:\\1\">mail</A>]", $comment);
		replace_text_smiley();
		$comment = wordwrap($comment, $break, "\n", 1);
		echo "
<table width=270 border=0 cellpadding=3 cellspacing=5>
	<tr>		<td><font face=\"Verdana\" size=2><b>$nick</b></font></td>
			<td align=right><font face=\"Verdana\" size=1>$date</font></td>
	</tr><tr>	<td colspan=2><font face=\"Verdana\" size=1>$ip</font></td>
	</tr><tr>	<td colspan=2><font face=\"Verdana\" size=1>$comment</td>
	</tr>
</table>
</body></html>		";

	} while($row = mysql_fetch_array($result));
}
mysql_close($connection);
?>