<?
require("siteboxconfig.php");
$connection = mysql_connect ("$servername", "$dbusername", "$dbpassword");
mysql_select_db ("$dbname");

$userip = $REMOTE_ADDR;
$banned = 0;
$result = mysql_query("SELECT * FROM banlist ORDER BY id DESC");
if ($row = mysql_fetch_array($result)) {
	do {
		$id = $row[id];
		$ip = $row[ip];
		$comment = $row[comment];
		
		$iplength = strlen($ip);
		$temp = Substr($userip, 0, $iplength);
		if ($temp == $ip) {
			echo "<center><b>banned :P</b></center>";
			$banned = 1;
		}
	} while($row = mysql_fetch_array($result));
}
function replace_gbook_smiley() {
	global $comment;
	$faces[" :)"] =  " <IMG SRC=\"emoticons/smile.gif\">";
	$faces[" :P"] =  " <IMG SRC=\"emoticons/tongue.gif\">";
	$faces[" :D"] =  " <IMG SRC=\"emoticons/happy.gif\">";
	$faces[" :("] =  " <IMG SRC=\"emoticons/mad.gif\">";
	$faces[" ;)"] =  " <IMG SRC=\"emoticons/wink.gif\">";
	$faces[" :|"] =  " <IMG SRC=\"emoticons/blank.gif\">";
	$faces[" :/"] =  " <IMG SRC=\"emoticons/smirk.gif\">";
	$faces[" :\\"] = " <IMG SRC=\"emoticons\smirk.gif\">";
	$faces[" =)"] =  " <IMG SRC=\"emoticons/smile.gif\">";
	$faces[" =P"] =  " <IMG SRC=\"emoticons/tongue.gif\">";
	$faces[" =D"] =  " <IMG SRC=\"emoticons/happy.gif\">";
	$faces[" =("] =  " <IMG SRC=\"emoticons/mad.gif\">";
	$faces[" =|"] =  " <IMG SRC=\"emoticons/blank.gif\">";
	$faces[" =/"] =  " <IMG SRC=\"emoticons/smirk.gif\">";
	$faces[" =\\"] = " <IMG SRC=\"emoticons\smirk.gif\">";
	while(list($text,$image) = each($faces)) {
		$comment = str_replace("$text","$image","$comment");
	}
	return $comment;
}
if ($banned == 0) {
	echo "\n$gbookform";
	if ($view == null) { $view = 0; }
	if (!IsSet($start)) { $start = 0; }
	if ($start <= 0) { $start = 0; }
	$result = mysql_query("SELECT * FROM gbook ORDER BY id DESC LIMIT $start, 10");
	if ($row = mysql_fetch_array($result)) {
		do {
			$post = $gbookpost;
			$urls = "";
			$id = $row[id];
			$nick = $row[nick];
			$date = date("l, jS F Y - g.ia", ($row[date] + $timeoffset));
			$ip = $row[ip];
			$email = $row[email];
			$url = $row[url];
			$comment = $row[comment];
			$comment = strip_tags($comment);
			$comment = eregi_replace("((http|https|mailto|ftp):(\/\/)?[^[:space:]<>]{1,})", "[\n<a href=\"\\1\">link\n</a>]", $comment);
			$comment = eregi_replace("([_\.0-9a-z-]+@([0-9a-z][0-9a-z-]+\.)+[a-z]{2,3})","[\n<A HREF=\"mailto:\\1\">mail\n</A>]</a>", $comment);
			replace_gbook_smiley();
			$comment = wordwrap($comment, $break, "\n", 1);
			if ($email != "") {
				$urls .= "[<b><a href=\"mailto:$email\" class=\"shout\">email</a></b>]";
			}
			if ($email != "" AND $url != "" AND $url != "http://") {
				$urls .= "&nbsp;&nbsp;";
			}
			if ($url != "" AND !url != "http://") {
				if (Substr($url, 0, 7) == "http://") {
					$urls .= "[<b><a href=\"$url\" target=\"_blank\" class=\"shout\">www</a></b>]";
				} else {
					$urls .= "[<b><a href=\"http://$url\" target=\"_blank\" class=\"shout\">www</a></b>]";
				}
			}
			$post = ereg_replace("!id", "$id", $post);
			$post = ereg_replace("!nick", "$nick", $post);
			$post = ereg_replace("!date", "$date", $post);
			$post = ereg_replace("!ip", "$ip", $post);
			$post = ereg_replace("!urls", "$urls", $post);
			$post = ereg_replace("!comment", "$comment", $post);
			echo "$post";
				

		} while($row = mysql_fetch_array($result));
	}
	$result = mysql_query("SELECT * FROM gbook");
	$total = mysql_num_rows($result);
	$sview = $total - $start;
	$eview = $sview - 10;
	$next = $start + 10;
	if ($next + 10 > $total) {
		$next = $total - 10;
	}
	$prev = $start - 10;
	if ($prev <= 0) {
		$prev = 0;
	}
	if ($eview < 0) {
		$eview = 0;
	}
	$gbookarchive = ereg_replace("!total", "$total", $gbookarchive);
	$gbookarchive = ereg_replace("!sview", "$sview", $gbookarchive);
	$gbookarchive = ereg_replace("!eview", "$eview", $gbookarchive);
	$gbookarchive = ereg_replace("!next", "$next", $gbookarchive);
	$gbookarchive = ereg_replace("!prev", "$prev", $gbookarchive);
	echo "$gbookarchive";
	echo "</center>";
	
}

mysql_close($connection);
?>