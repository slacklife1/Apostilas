<?
  $default["display_lines"] = 20;
  $default["email_sender"]  = "Y";
  $default["email_admin"]   = "Y";
  $default["username"]      = "admin";
  $default["password"]      = "admin";
?>
