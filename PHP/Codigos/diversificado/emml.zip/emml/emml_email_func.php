<?
   include("$emml_path/class.html.mime.mail.php");

   $em_mail = new html_mime_mail('X-Mailer: EternalMart');
   
   function set_email_content($email_info,$is_gpc = true) {
       
       global $em_mail;
                            
       if($is_gpc){              
         if(get_magic_quotes_gpc()){                      
           $is_strip = true;
         }
         else{
           $is_strip = false;
         }   
       }
       else{
         if(get_magic_quotes_runtime()){                      
           $is_strip = true;
         }
         else{
           $is_strip = false;
         }          
       }

       if($is_strip){                      
          while(list($key,$val) = each($email_info)){
            $email_info[$key] = trim(stripslashes($val));
          }
       }
       else{
          while(list($key,$val) = each($email_info)){
            $email_info[$key] = trim($val);
          }       
       }   

       if($email_info[email_sender] == "Y") {

          if($email_info[html_message] <> "") {
            $em_mail->add_html($email_info[html_message], $email_info[message]);
          }
          else{
            return "plain";
          }

          $em_mail->set_charset($email_info[charset], TRUE);
          $em_mail->build_message();
          return "html";
       }                    
       return false;
   }     

   function send_email($email_info,$method){
       
       global $em_mail;       
       
       if($method) {
          if($method == "html") {
            $em_mail->send('', $email_info[to_email], '', $email_info[from_email], $email_info[subject]);   
          }
          else{     
            mail("$email_info[to_email]", "$email_info[subject]", "$email_info[message]", "From: $email_info[from_email]");
          }   
       }   
   }   
?>
