<?
   ###########################################################################
   #                                                                         #
   # Script       : EternalMart Mailing List                                 #
   # Version      : 1.32                                                     #
   # Created      : 2-Dec-2000 by Kukfa                                      #
   # Last Updated : 03-May-2002                                              #
   #                                                                         #
   # Copyright (c) 2001 - 2002 EternalMart. All rights reserved.             #
   # WWW    : http://www.eternalmart.com                                     #
   # Email  : webmaster@eternalmart.com                                      #
   #                                                                         #
   ###########################################################################

   // ****************** Database Config. ***************************************

   // The host where the database server resides
   $DbHost        = "";   
      
   // The database you are going to use            
   $DbDatabase    = "";    

   // username
   $DbUser        = "";            
      
   // password
   $DbPassword    = "";                    

   // ****************** Directory Config. **************************************

   // set $emml_path where emml scripts resides      
   // e.g. $emml_path = "/home/yourname/html/cgi-bin/emml";     
      
   $emml_path = "";
   
   // set $emml_admin_path where emml admin scripts resides      
   // e.g. $emml_admin_path = "/home/yourname/html/cgi-bin/emml/admin";          
   
   $emml_admin_path = "";

   // set $template_html_path where emml html templates resides      
   // e.g. $template_html_path = "/home/yourname/html/cgi-bin/emml/template";          

   $template_html_path = "";

   // temp file
   // e.g $emml_temp_file = "/home/yourname/html/cgi-bin/emml/admin/emml.temp";
   // NOTE : Please chmod this file to 666. It is for the background processing
   
   $emml_temp_file = "";

   // set URL of emml 
   // e.g. $emml_url = "http://www.yourdomain.com/cgi-bin/emml";
         
   $emml_url  = "";

   // set URL of emml admin
   // e.g. $emml_admin_url = "http://www.yourdomain.com/cgi-bin/emml/admin";      
   
   $emml_admin_url = "";

   // set URL of images
   // e.g. $emml_image_url = "http://www.yourdomain.com/images";         
     
   $emml_image_url = "";
   
   // location of php
   // e.g. $php_path = "/usr/bin/php";
   $php_path = "";

// ******************* Message **********************************************

   // error message
   $emml_msg["db_err"]        = "Database Error.";
   $emml_msg["invalid_email"] = "Please enter valid email address. (e.g. a@b.com)";
   $emml_msg["empty_email"]   = "Please enter your email address";
   
// **************************************************************************

// ******************* END OF CONFIGURATION *********************************

   define("DBNAME",$DbDatabase);
   
   $emml_script_url = $emml_url."/emml.php";
   $admin_url       = $emml_admin_url."/admin.php";
   $sendmail_prog   = $emml_admin_path."/emml_mail.php";
   
   $emml_version = "1.32";

   // default charset
   $default_charset = "iso-8859-1";   

   // set charset
   $charset = array(
      "iso-8859-1"  => "Western (ISO-8859-1)",
      "Shift_JIS"   => "Japanese (Shift_JIS)",
      "iso-2022-jp" => "Japanese (JIS)",
      "EUC-JP"      => "Japanese (EUC)",
      "big5"        => "Traditional Chinese (BIG 5)",
      "gb2312"      => "Simplified Chinese (GB2312)",
      "euc-kr"      => "Korean (EUC KR)",
      "iso-8859-2"  => "Central European (ISO-8859-2)" 
   );

   set_magic_quotes_runtime(0);
   
?>
