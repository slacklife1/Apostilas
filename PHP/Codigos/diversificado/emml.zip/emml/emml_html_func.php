<?  
  function display_acknowledge($tpl_name){
     
     global $tpl_html;
     
     // display acknowledge
     $tpl_html->parse(CONTENT, "$tpl_name");
     $tpl_html->fastprint(CONTENT);
  
  }
  
  function display_emml_db_err(){
     
     global $emml_msg;
     
     // database error
     display_html($emml_msg[db_err].mysql_error());
     exit;

  }
  
  function display_html($content){

     global $tpl_html;

     $tpl_html->assign( array(
        "CONTENT" => "$content"
     ));
     $tpl_html->parse(CONTENT, "tpl_emml"); 
     $tpl_html->fastprint(CONTENT);	   
  }
    
  function display_emml_form($msg){
     
     global $tpl_html;          
     global $emml;     
     global $emml_script_url;    
     global $eternalmart; 
     global $emml_image_url;
     global $listid;
     
     $default_mailing_list = get_default_mailing_list();
     
     if(get_magic_quotes_gpc()){                           
        $emml[email] = htmlspecialchars(stripslashes(trim($emml[email])));
     }
     else{
        $emml[email] = htmlspecialchars(trim($emml[email]));
     }    
     
     if($emml[subscribe] == 'N'){
        $subscribe_yes = "";
        $subscribe_no = "CHECKED";
     }
     else{
        $subscribe_yes = "CHECKED";
        $subscribe_no = "";
     }
     
     $tpl_html->assign( array( 
        "ERR_MSG"              => "$msg",
        "SCRIPT_URL"           => "$emml_script_url",
        "EMAIL"                => "$emml[email]",
        "DEFAULT_MAILING_LIST" => "$default_mailing_list",
        "SUBSCRIBE_YES"        => "$subscribe_yes",
        "SUBSCRIBE_NO"         => "$subscribe_no",
        "COPYRIGHT"            => "$eternalmart",
        "IMAGE_URL"            => "$emml_image_url",
        "LISTID"               => "$listid"
     ));             
     $tpl_html->parse(TPL_EMML_FORM, "tpl_emml_form"); 
     $emml_form = $tpl_html->fetch(TPL_EMML_FORM);	        
     
     display_html($emml_form);
  }

  function display_subscribe_form($emml) {
  
     global $tpl_html;
     global $bgcolor;
     global $emml_script_url;
     global $eternalmart;
     global $emml_image_url;
     global $emsql;
     global $show_list;
     global $listid;
     
     if(gettype($show_list) == "array" ){
        $maillist_id = join(",",$show_list);
     }

     if($maillist_id <> "") {     
        $sql = "SELECT * FROM emml_maillist WHERE ispublic <> 'N' AND id IN ($maillist_id) ORDER BY id";
     }
     else{
        $sql = "SELECT * FROM emml_maillist WHERE ispublic <> 'N' ORDER BY id";
     }   
     
     $emsql->set_sql($sql);
     
     $result = $emsql->sql_execute();
     
     if($result){
         
         while($row = $emsql->sql_fetch_array($result)){
                     
            $checked = "";
            if($emml["maillist_".$row[id]] <> "") {
               $checked = "checked";
            }
            
            $listcount = get_list_count($row[id]);
            
            if($color == $bgcolor[1]){
              $color = $bgcolor[2];            
            }
            else{
              $color = $bgcolor[1];
            };
            
            $tpl_html->assign( array( 
               "MAILLIST_ID" => "$row[id]",
               "CHECKED"     => "$checked",
               "LISTNAME"    => "$row[listname]",
               "LISTDESC"    => "$row[listdesc]",
               "COUNT"       => "$listcount",
               "BGCOLOR"     => "$color"
            ));             
            $tpl_html->parse(TPL_EMML_SUBSCRIBE_ROWS, "tpl_emml_subscribe_row"); 
            $emml_subscribe_rows .= $tpl_html->fetch(TPL_EMML_SUBSCRIBE_ROWS);	        
         
         }
  
         if(get_magic_quotes_gpc()){                           
            $emml[email] = htmlspecialchars(stripslashes(trim($emml[email])));
         }
         else{
            $emml[email] = htmlspecialchars(trim($emml[email]));
         }    
  
         $tpl_html->assign( array( 
            "SCRIPT_URL" => "$emml_script_url",
            "EMAIL"      => "$emml[email]",
            "ROWS"       => "$emml_subscribe_rows",
            "IMAGE_URL"  => "$emml_image_url",
            "COPYRIGHT"  => "$eternalmart",
            "LISTID"     => "$listid"
         ));             
         $tpl_html->parse(TPL_EMML_SUBSCRIBE_FORM, "tpl_emml_subscribe_form"); 
         display_html($tpl_html->fetch(TPL_EMML_SUBSCRIBE_FORM));	                 
     }
     else {        
         // database error
         display_emml_db_err();
     }  
  }
  
  function update_subscribe($emml){
      
      global $emsql;
      global $show_list;

      $is_subscribe = false;
      $i = 0;
      $subscribe_email = array();
      
      if($emml[action] == "subscribe") {         
         while(list($key,$val) = each($emml)) {  
            if($val == "Y"){
               $is_subscribe = true;
               $subscribe_email[$i] = $key;
               $i++;               
            }            
         }      
      }

      $available_maillistid = join(",",$show_list);
      
      if($is_subscribe) {               

         $id = get_emailid($emml[email]);         

         if($id == ""){                     
            $emml_subscriber_fields = array(
                "emailaddress" => "$emml[email]",
                "jointime"     => date("Y-m-d H:i:s")
            );                       
            $emsql->sql_insert("emml_subscriber",$emml_subscriber_fields);
            $result = $emsql->sql_execute();            
            if(!$result){
               // database error
               display_emml_db_err();
            }
            $id = get_emailid($emml[email]);             
         }
         
         if($id <> "" AND $id <> "db_err") {         
            
            if($available_maillistid <> ""){
               $emsql->sql_delete("emml_mail_subscribe","emailid = '$id' AND maillistid IN ($available_maillistid)");           
               $result = $emsql->sql_execute();
                     
               if(!$result) { 
                 // database error
                 display_emml_db_err();
               }   
            }

            while(list($key,$val) = each($subscribe_email)){
               $emml_mail_subscribe_fields = array(
                   "emailid"    => "$id",
                   "maillistid" => "$val"                
               );                       
               $emsql->sql_insert("emml_mail_subscribe",$emml_mail_subscribe_fields);
               $result = $emsql->sql_execute();
               if(!$result){
                  // database error
                  display_emml_db_err();
               }
            }                                             
         }   
         elseif($id == "db_err"){
             // database error
             display_emml_db_err();
         }
         
      }      
      else{

         $id = get_emailid($emml[email]);         

         if($id <> "" AND $id <> "db_err"){                     

              // remove the subscriber
            if($available_maillistid <> ""){
               $emsql->sql_delete("emml_mail_subscribe","emailid = '$id' AND maillistid IN ($available_maillistid)");
               $result = $emsql->sql_execute();                       
               if(!$result) { 
                  // database error
                  $display_emml_db_err();
               }   
            }

            $sql = "SELECT * FROM emml_mail_subscribe WHERE emailid = '$id'";
            $emsql->set_sql($sql);
            $result = $emsql->sql_execute();
            if($result){
               if(!$emsql->sql_num_rows($result)){
                  $emsql->sql_delete("emml_subscriber","id = '$id'");
                  $result = $emsql->sql_execute();
                  if(!$result){
                    // database error
                    $display_emml_db_err();
                  }
               }        
            }
            else{
               // database error
               $display_emml_db_err();
            }                  
         }   
         elseif($id == "db_err"){
            // database error
            display_emml_db_err();
         }
      }            
      return $is_subscribe;  
  }
      
  function send_autoreply($toemail,$is_subscribe){
     
     global $tpl_html;
     global $admin_url;
     global $notify_subject;
     global $notify_subscribe_message;
     global $notify_unsubscribe_message;
     global $emsql;
     global $default_charset;

     global $subscribe_fromemail;
     global $subscribe_email_template_id;
     global $unsubscribe_fromemail;
     global $unsubscribe_email_template_id;

     $date = date("l,d-M-Y",time());                

     $from_email = "";     
     $subject    = "";
     $message    = "";
     
     if($is_subscribe) {
        
        $sql = "SELECT C.listname FROM emml_subscriber AS A, emml_mail_subscribe AS B, emml_maillist AS C WHERE B.maillistid = C.id AND B.emailid = A.id AND A.emailaddress = '$toemail'";
        $emsql->set_sql($sql);
        
        $result = $emsql->sql_execute();
     
        $subscribe_list = "";
        if($result){        
           while($row = $emsql->sql_fetch_array($result)){
               $subscribe_list .= "$row[listname]\n";
           }        
        }
        
        $from_email = $subscribe_fromemail;  
        $email_template_id = $subscribe_email_template_id; 
        
        if($email_template_id){
           $sql = "SELECT * FROM emml_email_template WHERE id = '$email_template_id'";
           $emsql->set_sql($sql);
           $result = $emsql->sql_execute();
           if($result){
              if($emsql->sql_num_rows($result)){
                 $row = $emsql->sql_fetch_array($result);
                 $charset = $row[charset];
                 $subject = $row[subject];
                 $message = $row[message];
                 $html_message = $row[html_message];
                 if(trim($charset) == ""){ 
                    $charset = $default_charset;
                 }
              }
           }        
        } 
                
        $message = ereg_replace("#SUBSCRIBE_LIST#","$subscribe_list",$message);
        $message = ereg_replace("#DATE#","$date",$message);

        $html_message = ereg_replace("#SUBSCRIBE_LIST#","$subscribe_list",$html_message);
        $html_message = ereg_replace("#DATE#","$date",$html_message);
        
     }
     else {

        $from_email = $unsubscribe_fromemail;  
        $email_template_id = $unsubscribe_email_template_id; 

        if($email_template_id){
           $sql = "SELECT * FROM emml_email_template WHERE id = '$email_template_id'";
           $emsql->set_sql($sql);           
           $result = $emsql->sql_execute();
           if($result){
              if($emsql->sql_num_rows($result)){
                 $row = $emsql->sql_fetch_array($result);
                 $charset = $row[charset];
                 $subject = $row[subject];
                 $message = $row[message];  
                 $html_message = $row[html_message];                                
                 if(trim($charset) == ""){ 
                    $charset = $default_charset;
                 }
              }              
           }        
        }
        $message = ereg_replace("#DATE#","$date",$message);
        $html_message = ereg_replace("#DATE#","$date",$html_message);
     }
     
     if(trim($from_email) <> "" AND trim($subject) <> "" AND (trim($message) <> "" OR trim($html_message) <> "")) {          
       // send email
       
       $email_sender = get_option_value("email_sender");
       $email_admin  = get_option_value("email_admin");
       $admin_email  = get_option_value("admin_email");
       
       $email_info = array(
          "to_email"     => $toemail,
          "from_email"   => $from_email,
          "charset"      => $charset,
          "subject"      => $subject,
          "message"      => $message,
          "html_message" => $html_message,
          "email_sender" => $email_sender
       );
       $rc = set_email_content($email_info,false);
       send_email($email_info,$rc);
     }   
     
     // send to admin
     if($email_admin == "Y") {

        if($admin_email <> "") {
           $datetime = date("l,d-M-Y H:i:s",time());
           
           if($is_subscribe){
             $notify_subscribe_message = ereg_replace ("#DATETIME#", $datetime , $notify_subscribe_message);
             $notify_subscribe_message = ereg_replace ("#EMAIL#", $toemail, $notify_subscribe_message);           
             $notify_subscribe_message = ereg_replace ("#EMML_URL#", "$admin_url", $notify_subscribe_message);                      
             $notify_subscribe_message = ereg_replace ("#MAILLIST#", "$subscribe_list", $notify_subscribe_message);
             $notify_message = $notify_subscribe_message;
           }
           else{           
             $notify_unsubscribe_message = ereg_replace ("#DATETIME#", $datetime , $notify_unsubscribe_message);
             $notify_unsubscribe_message = ereg_replace ("#EMAIL#", $toemail, $notify_unsubscribe_message);                        
             $notify_message = $notify_unsubscribe_message;             
           }  
           
           $email_info = array(
             "to_email"     => $admin_email,
             "from_email"   => $admin_email,
             "charset"      => $charset,
             "subject"      => $notify_subject,
             "message"      => $notify_message,
             "email_sender" => "Y"
           );
           $rc = set_email_content($email_info,false);
           send_email($email_info,$rc);           
        }   
     }        
   }        
?>
