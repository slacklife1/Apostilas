<? 
   include("emml_config.php");     
   include("$emml_path/class.fasttemplate.php");
   include("$emml_path/emml_html_func.php");     
   include("$emml_path/emml_common_func.php");
   include("$emml_path/emml_email_func.php");
   include("$emml_path/emml_default.php");      
   include("$emml_path/emml_msg.php");   
   include("$emml_path/sql_func.php");  
   
   $emsql = new sql_class($DbHost,$DbUser,$DbPassword,$DbDatabase);

   if($emsql->get_errno()){
      display_emml_db_err();
      exit;
   }

   $listid = trim($listid);

   $show_list = "";
   $flag = "";
   
   if($listid <> ""){   
      $sql = "SELECT * FROM emml_list WHERE id = '$listid'";
   }
   else{
      $sql = "SELECT * FROM emml_list ORDER BY id";
   }

   $emsql->set_sql($sql);
   $result = $emsql->sql_execute();

   if($result){
      if($emsql->sql_num_rows($result)){
         $row = $emsql->sql_fetch_array($result);
         $template_html_path            = $row[template_html_path]; 
         $flag                          = $row[flag]; 
         $show_lists                    = $row[maillist];
         $default_show_lists            = $row[default_maillist];
         $subscribe_fromemail           = $row[sub_frommail];
         $subscribe_email_template_id   = $row[sub_template];          
         $unsubscribe_fromemail         = $row[unsub_frommail];
         $unsubscribe_email_template_id = $row[unsub_template];                              
         $show_list = split("\n",$show_lists);
         $default_show_list = split("\n",$default_show_lists);
         if($flag == "Y"){
            for($i=0;$i<count($show_list);$i++){
               $emml[trim($show_list[$i])] = "Y";
            }
         }
         else{
            if($emml[action] <> "subscribe"){
               for($i=0;$i<count($default_show_list);$i++){
                 $emml["maillist_".trim($default_show_list[$i])] = "Y";
               }
            }
         }
      }   
   }
   else{
      // database error
      display_emml_db_err();
   }

   $tpl_html = new FastTemplate($template_html_path,$os);
   $tpl_html->no_strict();
   $tpl_html->define(array(
       "tpl_emml"                => "template_emml.html",
       "tpl_emml_form"           => "template_emml_form.html",
       "tpl_emml_thankyou"       => "template_emml_thankyou.html",
       "tpl_emml_unsubscribe"    => "template_emml_unsubscribe.html",
       "tpl_emml_subscribe_form" => "template_emml_subscribe_form.html",
       "tpl_emml_subscribe_row"  => "template_emml_subscribe_row.html"
   ));
   
   $emml[email] = trim($emml[email]);
   
   $valid_email = false;
   if(getenv("REQUEST_METHOD") == "POST"){
      if($emml[email] <> "") {
         if(is_valid_email($emml[email])){
            $valid_email = true;
         }
         else{
            $emml_msg = $emml_msg["invalid_email"];
         }
      }
      else{
         $emml_msg = $emml_msg["empty_email"];
      }
   }
   else{
      $emml_msg = "";
   }

   if(!$valid_email){
     display_emml_form($emml_msg);
     exit;
   }
   
   if($emml[subscribe] == 'N') {
     update_subscribe($emml);
     send_autoreply($emml[email],false);     
     display_acknowledge("tpl_emml_unsubscribe");
     exit;
   }
   
   $is_subscriber = false;
      
   $mailid = get_emailid($emml[email]);

   if($mailid <> "" && $mailid <> "db_err") {      
      
      $sql = "SELECT * FROM emml_mail_subscribe WHERE emailid = '$mailid'";
      $emsql->set_sql($sql);      
      $result = $emsql->sql_execute();
      if($result){            
        while($row = $emsql->sql_fetch_array($result)){               
           $emlist["maillist_".$row[maillistid]] = true;               
        }                     
        $emlist[email] = $emml[email];                
        $is_subscriber = true;
      }   
      else{
         // database error
         display_emml_db_err();
      }
   }
   elseif($mailid == "db_err"){
       // database error
       display_emml_db_err();
   }
   
   if($flag == "Y"){
     $emml[action] = "subscribe";
   }
  
   if($emml[action] == "subscribe") {
      $is_subscribe = update_subscribe($emml);
      send_autoreply($emml[email],$is_subscribe);
      if($is_subscribe){
         display_acknowledge("tpl_emml_thankyou");
      }
      else{
         display_acknowledge("tpl_emml_unsubscribe");
      }
   }
   else {
      if($is_subscriber) {
         display_subscribe_form($emlist);
      }
      else{
         display_subscribe_form($emml);
      }
   }   
?>
