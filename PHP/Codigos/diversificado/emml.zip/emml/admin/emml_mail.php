<?
  include("../emml_config.php");
  include("$emml_path/class.fasttemplate.php");
  include("$emml_path/emml_common_func.php");
  include("$emml_path/emml_default.php");
  include("$emml_path/emml_msg.php");      
  include("$emml_path/sql_func.php"); 
  include("$emml_path/emml_email_func.php"); 
  include("$emml_admin_path/admin_func.php");
 
  $template_html_admin_path = "$template_html_path/admin";
  
  if(@function_exists('ignore_user_abort')){
     ignore_user_abort(1);
  }

  set_time_limit(0);
 
  $tpl_html = new FastTemplate($template_html_admin_path,$os);
  $tpl_html ->no_strict();
  $tpl_html ->define(array(
     "tpl_emml_admin" => "template_emml_admin.html"
  ));

  $emsql = new sql_class($DbHost,$DbUser,$DbPassword,$DbDatabase);

  if($emsql->get_errno()){
     display_emml_admin_html($msg["db_err"]);
     exit;
  }
    
//  $argv = $HTTP_SERVER_VARS["argv"];
  $id   = $argv[1];
  $mode = $argv[2];
  
  if($mode == "test") {
     sendout_email($id,true);
  }
  else {
     sendout_email($id);
  }   

?>