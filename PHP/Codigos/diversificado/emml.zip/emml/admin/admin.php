<?   
  include("../emml_config.php");
  include("$emml_path/class.fasttemplate.php");
  include("$emml_path/emml_common_func.php");
  include("$emml_path/emml_default.php");
  include("$emml_path/emml_msg.php");      
  include("$emml_path/emml_email_func.php");      
  include("$emml_path/sql_func.php"); 

  include("$emml_admin_path/admin_func.php");
  
  $mark = "<font color=\"#ff0000\">*</font>";

  set_time_limit(0);

  if(function_exists('ignore_user_abort')){
     ignore_user_abort(1);
  }

  $template_html_admin_path = "$template_html_path/admin";

  $tpl_html = new FastTemplate($template_html_admin_path,$os);
  $tpl_html ->no_strict();
  $tpl_html ->define(array(
     "tpl_emml_subscriber_maillist_row"   => "template_emml_subscriber_maillist_row.html",
     "tpl_emml_subscriber_search"         => "template_emml_subscriber_search.html",     
     "tpl_emml_subscriber_table"          => "template_emml_subscriber_table.html",
     "tpl_emml_subscriber_row"            => "template_emml_subscriber_row.html",
     "tpl_emml_subscriber_add"            => "template_emml_subscriber_add.html",          
     "tpl_emml_subscriber_update"         => "template_emml_subscriber_update.html",               
     "tpl_emml_subscriber_delete"         => "template_emml_subscriber_delete.html",                    
     "tpl_emml_maillist_table"            => "template_emml_maillist_table.html",
     "tpl_emml_maillist_row"              => "template_emml_maillist_row.html",
     "tpl_emml_maillist_add"              => "template_emml_maillist_add.html",     
     "tpl_emml_maillist_update"           => "template_emml_maillist_update.html",          
     "tpl_emml_maillist_delete"           => "template_emml_maillist_delete.html",
     "tpl_emml_maillist_view_subscriber_table" => "template_emml_maillist_view_subscriber_table.html",
     "tpl_emml_maillist_view_subscriber_row"   => "template_emml_maillist_view_subscriber_row.html",
     "tpl_emml_maillist_import_email"     => "template_emml_maillist_import_email.html",
     "tpl_emml_maillist_export_email"     => "template_emml_maillist_export_email.html",
     "tpl_emml_email_template_table"      => "template_emml_email_template_table.html",     
     "tpl_emml_email_template_row"        => "template_emml_email_template_row.html",     
     "tpl_emml_email_template_add"        => "template_emml_email_template_add.html",
     "tpl_emml_email_template_update"     => "template_emml_email_template_update.html",
     "tpl_emml_email_template_delete"     => "template_emml_email_template_delete.html",
     "tpl_emml_sendmail"                  => "template_emml_sendmail.html",
     "tpl_emml_sendmail_build"            => "template_emml_sendmail_build.html",     
     "tpl_emml_sendmail_preview"          => "template_emml_sendmail_preview.html",
     "tpl_emml_sendmail_status"           => "template_emml_sendmail_status.html",
     "tpl_emml_sendmail_status_row"       => "template_emml_sendmail_status_row.html",
     "tpl_emml_sendmail_viewdetails"      => "template_emml_sendmail_viewdetails.html",
     "tpl_emml_htmlcode_table"            => "template_emml_htmlcode_table.html",
     "tpl_emml_htmlcode_row"              => "template_emml_htmlcode_row.html",     
     "tpl_emml_htmlcode_add"              => "template_emml_htmlcode_add.html",          
     "tpl_emml_htmlcode_update"           => "template_emml_htmlcode_update.html",               
     "tpl_emml_htmlcode_delete"           => "template_emml_htmlcode_delete.html",                    
     "tpl_emml_htmlcode_html"             => "template_emml_htmlcode_html.html",                    
     "tpl_emml_setting"                   => "template_emml_setting.html",
     "tpl_emml_admin"                     => "template_emml_admin.html"
  ));

  $emsql = new sql_class($DbHost,$DbUser,$DbPassword,$DbDatabase);

  if($emsql->get_errno()){
     display_emml_admin_html($msg["db_err"]);
     exit;
  }
  
  // remove old sendmail record
  delete_old_emailstatus();
  
  include("$emml_admin_path/auth.php");
  
############# subscriber ##################
  
  if($type == "subscriber"){

     $back_subscriber[msg]  = "$msg[back]";
     $back_subscriber[link] = "$admin_url?type=subscriber";

     if($action == "add"){
        if($confirm == "Y"){
          $err_msg = validate_subscriber($subscriber,"",$subscriber_mark);
          if($err_msg <> ""){
             display_emml_admin_html(display_add_subscriber($subscriber_mark));
             exit;
          }          
          else {
          
             $rc = add_subscriber($subscriber);
             if($rc){            
                $subscriber_msg = $msg["subscriber_added_OK"];
             }
             else{
                $subscriber_msg = $msg["subscriber_added_fail"];
             }
             display_emml_admin_html($subscriber_msg,$back_subscriber);                         
             exit;                        
          }   
        }
        else{
          display_emml_admin_html(display_add_subscriber());
          exit;
        }          
     }

     if($action == "update"){
        if($confirm == "Y"){
          $err_msg = validate_subscriber($subscriber,$id,$subscriber_mark);
          if($err_msg <> "") {
            display_emml_admin_html(display_update_subscriber($id,$subscriber_mark));  
            exit;                  
          }
          else{

            $rc = update_subscriber($id,$subscriber);

            switch ($rc) {
               case "subscriber_not_found" :
                  $subscriber_msg = $msg["subscriber_not_found"];
                  break;
               case "OK":
                  $subscriber_msg = $msg["subscriber_updated_OK"];
                  break;
               case "FAILED":
                  $subscriber_msg = $msg["subscriber_updated_fail"];
                  break;
            }
            
            display_emml_admin_html($subscriber_msg,$back_subscriber);                         
            exit;                        
          }  
        }
        else{
           display_emml_admin_html(display_update_subscriber($id));
           exit;
        }             
     }      

     if($action == "delete"){
        if($confirm == "Y"){

           $rc = delete_subscriber($id,$subscriber);

           switch ($rc) {
              case "subscriber_not_found" :
                 $subscriber_msg = $msg["subscriber_not_found"];
                 break;
              case "OK":
                 $subscriber_msg = $msg["subscriber_deleted_OK"];
                 break;
              case "FAILED":
                 $subscriber_msg = $msg["subscriber_deleted_fail"];
                 break;
           }

           display_emml_admin_html($subscriber_msg,$back_subscriber);                         
           exit;                                                       
        }
        else{
           display_emml_admin_html(display_delete_subscriber($id),$back_subscriber);
           exit;
        }             
     }      

     display_emml_admin_html(display_search_subscriber().display_subscriber_maint($criteria));

  }
  
##################################################

############# mailing list #######################

  if($type == "maillist") {

     $back_maillist[msg] = "$msg[back]";
     $back_maillist[link] = "$admin_url?type=maillist";

     $err_msg = "";
     if($action == "add"){     
        if($confirm == "Y"){
          
          $err_msg = validate_maillist($maillist,"",$maillist_mark);
          
          if($err_msg <> "") {                        
            display_emml_admin_html(display_add_maillist($maillist_mark),$back_maillist);  
            exit;        
          }
          else{
            
            $rc = add_maillist($maillist);
            
            if($rc){
               $maillist_msg = $msg["maillist_added_OK"];
            }
            else{
               $maillist_msg = $msg["maillist_added_fail"];
            }
            
            display_emml_admin_html($maillist_msg,$back_maillist);                         
            exit;                        
          }  
        }
        else {
           display_emml_admin_html(display_add_maillist(),$back_maillist);
           exit;
        }   
     }     
     
     if($action == "update"){
        if($confirm == "Y"){
          
          $err_msg = validate_maillist($maillist,$id,$maillist_mark);

          if($err_msg <> ""){          
            display_emml_admin_html(display_update_maillist($id,$maillist_mark));     
            exit;     
          }
          else{
            
            $rc = update_maillist($id,$maillist);
            
            switch ($rc) {
               case "maillist_not_found" :
                  $maillist_msg = $msg["maillist_not_found"];            
                  break;
               case "OK":
                  $maillist_msg = $msg["maillist_updated_OK"];               
                  break;
               case "FAILED":
                  $maillist_msg = $msg["maillist_updated_fail"];
                  break;
            }

            display_emml_admin_html($maillist_msg,$back_maillist);                         
            exit;                        
          }  
        }
        else{
          display_emml_admin_html(display_update_maillist($id),$back_maillist);
          exit;
        }             
     }      

     if($action == "delete"){         
        if($confirm == "Y"){
          $num_subscriber = get_list_count($id);
          if($num_subscriber > 0){
            display_emml_admin_html(display_delete_maillist($id),$back_maillist);
            exit;
          }
          else{     

            $rc = delete_maillist($id);    

            switch ($rc) {
               case "maillist_not_found" :
                  $maillist_msg = $msg["maillist_not_found"];            
                  break;
               case "OK":
                  $maillist_msg = $msg["maillist_deleted_OK"];               
                  break;
               case "FAILED":
                  $maillist_msg = $msg["maillist_deleted_fail"];
                  break;
            }

            display_emml_admin_html($maillist_msg,$back_maillist);                         
            exit;                                       
          }  
        }
        else{
          display_emml_admin_html(display_delete_maillist($id),$back_maillist);
          exit;
        }     
     } 

     if($action == "subscriber"){     

        if($confirm == "Y"){
           if(gettype($subscriber) == "array"){
             $subscriber_id = "";
             while(list($key,$val) = each($subscriber)){
                $subscriber_id .= "'$key',";
             }             
             if($subscriber_id <> ""){
               $subscriber_id = substr($subscriber_id,0,strlen($subscriber_id) - 1);
               $emsql->sql_delete("emml_mail_subscribe","maillistid = '$id' AND emailid IN ($subscriber_id)");
               $result = $emsql->sql_execute();
             }             
           } 
        }
        
        display_emml_admin_html(display_maillist_view_subscriber($id),$back_maillist);
        exit;    
     } 

     if($action == "import"){     
     
        if($confirm == "Y"){

           if($email <> ""){
              $emails = get_email($email);
              $rc = import_email($emails,$id);                              
           }            
           if($rc <> "") {              
              display_emml_admin_html($rc,$back_maillist);      
              exit;
           }              
           else{
              display_emml_admin_html($msg["maillist_import_ok"],$back_maillist);      
              exit;
           }
        }
        
        display_emml_admin_html(display_maillist_import_email($id),$back_maillist);
        exit;    
     }

     if($action == "export"){     
        display_emml_admin_html(display_maillist_export_email($id),$back_maillist);
        exit;    
     }
      
     display_emml_admin_html(display_maillist_maint());     
  }

##################################################

############### send email #######################

  if($type == "sendmail"){

     $back_sendmail[msg]  = "$msg[back]";
     $back_sendmail[link] = "$admin_url?type=sendmail";
     
     // STEP 1
     if($action == "step1"){             
        $err_msg = validate_sendmail($sendmail,$sendmail_mark);
        if($err_msg == "") {
             display_emml_admin_html(display_sendemail_build());
        }
        else{   
           display_emml_admin_html(display_sendmail($sendmail_mark));
        }   
        exit;
     }        

     // STEP 2
     if($action == "step2"){             
        $err_msg = validate_sendmail_preview($sendmail,$sendmail_mark);
        if($err_msg == "") {
           display_emml_admin_html(display_preview());
        }
        else{   
           display_emml_admin_html(display_sendemail_build($sendmail_mark));
        }   
        exit;
     }        
          
     display_emml_admin_html(display_sendmail());

  }

##################################################

############### email status #####################

  if($type == "emailstatus"){

     $back_emailstatus[msg]  = "$msg[back]";
     $back_emailstatus[link] = "$admin_url?type=emailstatus";
     
     if($action == "view_details"){
     
       display_emml_admin_html(display_emailstatus_detail($id),$back_emailstatus);
       exit;
     
     }

     if($action == "delete_emailstatus"){
        delete_emailstatus($sendmail_id);
     }
     
     display_emml_admin_html(display_emailstatus());
     
  }

##################################################

############# email template #####################

  if($type == "email_template"){

     $back_email_template[msg]  = "$msg[back]";
     $back_email_template[link] = "$admin_url?type=email_template";
     
     if($action == "add"){
        if($confirm == "Y"){
          $err_msg = validate_email_template($email_template,"",$email_template_mark);
          if($err_msg <> "") {
             display_emml_admin_html(display_add_email_template($email_template_mark),$back_email_template);  
             exit;                  
          }
          else{

             $rc = add_email_template();
             if($rc){            
                $email_template_msg = $msg["email_template_added_OK"];
             }
             else{
                $email_template_msg = $msg["email_template_added_fail"];
             }
             display_emml_admin_html($email_template_msg,$back_email_template);                         
             exit;                        
          }  
        }
        else{
           display_emml_admin_html(display_add_email_template(),$back_email_template);  
           exit;
        }          
     }          
     if($action == "update"){
        if($confirm == "Y"){
          $err_msg = validate_email_template($email_template,$id,$email_template_back);
          if($err_msg <> "") {
            display_emml_admin_html(display_update_email_template($id,$email_template_back),$back_email_template);  
            exit;                  
          }
          else{

            $rc = update_email_template($id);

            switch ($rc) {
               case "email_template_not_found" :
                  $email_template_msg = $msg["email_template_not_found"];            
                  break;
               case "OK":
                  $email_template_msg = $msg["email_template_updated_OK"];
                  break;
               case "FAILED":
                  $email_template_msg = $msg["email_template_updated_fail"];
                  break;
            }
            
            display_emml_admin_html($email_template_msg,$back_email_template);                         
            exit;                        
          }  
        }
        else{
          display_emml_admin_html(display_update_email_template($id),$back_email_template);  
          exit;
        }          
     }     
     if($action == "delete"){
        if($confirm == "Y"){

            $rc = delete_email_template($id);

            switch ($rc) {
               case "email_template_not_found" :
                  $email_template_msg = $msg["email_template_not_found"];            
                  break;
               case "OK":
                  $email_template_msg = $msg["email_template_deleted_OK"];
                  break;
               case "FAILED":
                  $email_template_msg = $msg["email_template_deleted_fail"];
                  break;
            }

            display_emml_admin_html($email_template_msg,$back_email_template);                         
            exit;                                               
        }
        else{
          display_emml_admin_html(display_delete_email_template($id),$back_email_template);  
          exit;
        }          
     }          
     display_emml_admin_html(display_email_template_maint());       
  }

##################################################

############### Send out emails ########################

  if($type == "sendout"){

     if(file_exists($emml_temp_file)){
        $temp_file = $emml_temp_file;
     }
     else{
        $temp_file = "emml.temp";
     }
     
     if($php_path == ""){
       $php_path = "/usr/bin/php";
     }

     $is_php_executable = is_php_execute($php_path);
     
     if($is_php_executable){
        clearstatcache();
        $is_file_writeable = is_writeable($temp_file);
      
        if(!$is_file_writeable){
           // Advise to chmod 666 to emml.temp
           display_emml_admin_html("Please change the permission of $temp_file to 666");    
           exit;                
        }
     }
     
     $sql = "SELECT * FROM emml_sendmail WHERE id = '$sendmail_id'";
     $emsql->set_sql($sql);

     $result = $emsql->sql_execute();
  
     if(!$result){
       // db error
       display_emml_admin_html($msg["db_err"]);    
       exit;
     }
     
     // test sending email
     if($test <> ""){
       
       $default = get_settings();       
       // send out emails               

       $test_msg .= "Test email was sent to $default[admin_email]";
       $test_msg .= "<br><a href='javascript:history.go(-1)'><b>Back to send out emails</b></a>";
       display_emml_admin_html($test_msg);

       if($is_php_executable){
          exec("$php_path $sendmail_prog $sendmail_id test > $temp_file &");
       }
       else{
          // send email via mail()
          sendout_email($sendmail_id,true);
       }
              
       exit;
     }
     
     $msg = "";

     if($emsql->sql_num_rows($result)) {

         $row = $emsql->sql_fetch_array($result);
         $status = $row["status"];

         if($status == "R"){
            $emml_sendmail_fields = array(
               "status" => "S"
            );

            $emsql->sql_update("emml_sendmail",$emml_sendmail_fields,"id = '$sendmail_id'");
       
            $result = $emsql->sql_execute();
            if(!$result){
               // db error
               display_emml_admin_html($msg["db_err"]);          
               exit;
            }
         }
         else{
            $msg = "Email request has been already sent";
         }
     }
     else{  
        $msg = "Record not found";
     }  
   
     if($msg <> "") {
         display_emml_admin_html("$msg");  
         exit;
     }
     else{                  

        // send out emails   

        if($is_php_executable){
           exec("$php_path $sendmail_prog $sendmail_id > $temp_file &");
        }
        else{
           sendout_email($sendmail_id);
        }

        display_emml_admin_html("Email request has been sent successfully");
        exit;
     }  
  }

##################################################

############### HTML code ########################

  if($type == "htmlcode"){
     
     $back_htmlcode[msg]  = $msg[back];
     $back_htmlcode[link] = "$admin_url?type=htmlcode";

     if($action == "add"){
       if($confirm == "Y"){
          $err_msg = validate_htmlcode($htmlcode,"",$htmlcode_mark);
          if($err_msg <> ""){
             display_emml_admin_html(display_add_htmlcode($htmlcode_mark),$back_htmlcode);
             exit;
          }          
          else {             

             $rc = add_htmlcode($htmlcode);
             if($rc){            
                $htmlcode_msg = $admin_msg["htmlcode_added_OK"];
             }
             else{
                $htmlcode_msg = $admin_msg["htmlcode_added_fail"];
             }
             display_emml_admin_html($htmlcode_msg,$back_htmlcode);                         
             exit;                        
          }   
        }
        else{
          display_emml_admin_html(display_add_htmlcode(),$back_htmlcode);
          exit;
        }                                  
     }  

     if($action == "update"){
        if($confirm == "Y"){
          $err_msg = validate_htmlcode($htmlcode,$id,$htmlcode_mark);
          if($err_msg <> "") {
            display_emml_admin_html(display_update_htmlcode($id,$htmlcode_mark),$back_htmlcode);  
            exit;                  
          }
          else{

            $rc = update_htmlcode($id,$htmlcode);

            switch ($rc) {
               case "htmlcode_not_found" :
                  $htmlcode_msg = $admin_msg["htmlcode_not_found"];            
                  break;
               case "OK":
                  $htmlcode_msg = $admin_msg["htmlcode_updated_OK"];
                  break;
               case "FAILED":
                  $htmlcode_msg = $admin_msg["htmlcode_updated_fail"];
                  break;
            }

            display_emml_admin_html($htmlcode_msg,$back_htmlcode);                         
            exit;                        
          }  
        }
        else{
           display_emml_admin_html(display_update_htmlcode($id),$back_htmlcode);
           exit;
        }             
     }      

     if($action == "delete"){
        if($confirm == "Y"){

           $rc = delete_htmlcode($id);

           switch ($rc) {
               case "htmlcode_not_found" :
                  $htmlcode_msg = $admin_msg["htmlcode_not_found"];            
                  break;
               case "OK":
                  $htmlcode_msg = $admin_msg["htmlcode_deleted_OK"];
                  break;
               case "FAILED":
                  $htmlcode_msg = $admin_msg["htmlcode_deleted_fail"];
                  break;
           }

           display_emml_admin_html($htmlcode_msg,$htmlcode_form);                         
           exit;                                                       
        }
        else{
           display_emml_admin_html(display_delete_htmlcode($id),$back_htmlcode);
           exit;
        }             
     }                

     if($action == "html"){
        display_emml_admin_html(display_htmlcode_html($id),$back_htmlcode);
        exit;
     }                
          
     display_emml_admin_html(display_htmlcode());

  }

##################################################

############### setting ##########################

  if($type == "setting"){        
     if($action == "update"){    
        $back_setting[msg] = $msg[back];
        $back_setting[link] = "$admin_url?type=setting";
        
        $setting_mark = array();
        $err_msg = validate_setting($setting,$setting_mark);                        

        if($err_msg == ""){

           $rc = update_setting();
           if($rc) {
             $setting_msg = $msg["setting_update_ok"];
           }
           else{
             $setting_msg = $msg["setting_update_fail"];
           }         
           display_emml_admin_html($setting_msg,$back_setting);                         
           exit;                                                          
        }        
     }      
          
     display_emml_admin_html(display_setting_maint($setting_mark));
  }

##################################################

  if($type == ""){
     display_emml_admin_html("",false);
  }
    
?>
