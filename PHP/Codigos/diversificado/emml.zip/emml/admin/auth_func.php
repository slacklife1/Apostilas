<?
   function GenerateSecret ( $username) {
  
      global $login_session_table;
      global $cookie_name;
      global $expire_time;
      global $emsql;
  
      $md5str = MD5(TIME());
      setcookie( "$cookie_name", $md5str, $expire_time, "/");

      $login_session_fields = array(
         "username"        => "$username",   
         "string"          => "$md5str",
         "lastupdatedtime" => date("Y-m-d H:i:s")         
      );
   
      $emsql->sql_insert($login_session_table,$login_session_fields, "username='$username'");             
  
      return $emsql->sql_execute();
   }

   function AuthenticateUser ($username, $password) {
  
      global $login_table;
  	
      $setting = get_settings();
      if($username == $setting[username] && $password == $setting[password]){
         GenerateSecret($username);      
      }
      else{
         display_login_form("Please try again ..");
         exit;      
      }
   }

   function AuthenticateCookie ( $cookie, $username, $password ) {
  
      global $login_session_table;
      global $emsql;
  	
      $sql = "select * from $login_session_table where string='$cookie'";
      $emsql->set_sql($sql);
      $result = $emsql->sql_execute();
	
      if($result) {
         if($emsql->sql_num_rows($result)){    
            $row = $emsql->sql_fetch_array($result);
            return $row[username];
         }  
         else{
            AuthenticateUser ( $username, $password );    
         }
      }
      else{
        // database error
        display_login_form("Database Error<BR>");
        exit;
      }
   }

   function display_login_form($msg = "") {
   
      global $tpl_html;      
      global $template_html_admin_path,$os;
      global $script_url;
      global $login_template;
      global $image_url;

      global $username;
      global $password;
      
      global $emml_version;
      
      if(get_magic_quotes_gpc()){                             
         $username = htmlspecialchars(stripslashes($username));
         $password = htmlspecialchars(stripslashes($password));
      }
      else{
         $username = htmlspecialchars($username);
         $password = htmlspecialchars($password);
      }    
      
      $tpl_form = new FastTemplate($template_html_admin_path,$os);
      $tpl_form->no_strict();
      $tpl_form->define(array(
         "tpl_login" => "$login_template"
      ));
          
      $tpl_form->assign( array( 
          "SCRIPT_URL" => "$script_url",
          "LOGO"       => "$image_url/emlogo.gif",       
          "COPYRIGHT"  => "$eternalmart",
          "ERR_MSG"    => "$msg",
          "USERNAME"   => "$username",
          "PASSWORD"   => "",
          "VERSION"    => "$emml_version"
      ));  
      
      $tpl_form->parse(TPL_LOGIN_FORM, "tpl_login");            
      $html = $tpl_form->fetch(TPL_LOGIN_FORM);	                                     

      print $html;   
   }

   function delete_old_login_session(){
      
      global $login_session_table;
      global $emsql;

      // 2 hours
      $expiredtime = 2 * 60 * 60;
      $expired = time() - $expiredtime;

      $sql = "DELETE FROM $login_session_table WHERE unix_timestamp(lastupdatedtime) <= '$expired'";
      $emsql->set_sql($sql);
      $result = $emsql->sql_execute();

   }

   function update_login_session($cookie){
      
      global $login_session_table;
      global $emsql;

      $login_session_fields = array(   
         "lastupdatedtime" => date("Y-m-d H:i:s")         
      );

      $emsql->sql_update($login_session_table,$login_session_fields, "string='$cookie'");
      return $emsql->sql_execute();
   }
   
?>
