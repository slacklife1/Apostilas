<?

  $cookie_name = "emml_login";
  $login_table = "emml_login";
  $login_session_table = "emml_login_session";
  
  $script_url     = $admin_url;
  $login_template = "template_emml_login_form.html";
  $image_url      = $emml_image_url;

  $expire_time    = 0;

  include("$emml_admin_path/auth_func.php");
  
  $username = trim($login[username]);
  $password = trim($login[password]);

  if($type == "logout"){
     $sql = "DELETE FROM $login_session_table WHERE string = '".${$cookie_name}."'";
     $emsql->set_sql($sql);
     $result = $emsql->sql_execute();
     $expiredtime = 0;
     setcookie( "$cookie_name", "", $expiredtime, "/") ;       
     display_login_form();
     exit;
  }

  delete_old_login_session();

  if($action == "login") {
     $expiredtime = 0;
     setcookie( "$cookie_name", "", $expiredtime, "/") ;    
     display_login_form();
     exit;
  }
  else if (${$cookie_name}) {
     $username = AuthenticateCookie( ${$cookie_name}, $username, $password );
  }   
  else {
     if ($username) {
        AuthenticateUser( $username, $password );
     }	
     else {
        display_login_form();
        exit;
     }   
  }       

  update_login_session(${$cookie_name});

?>
