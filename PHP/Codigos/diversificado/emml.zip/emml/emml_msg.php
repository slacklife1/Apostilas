<?
  $msg["subscriber_added_OK"]     = "Subscriber added successfully";
  $msg["subscriber_added_fail"]   = "Database Error. Can't add subscriber";
  $msg["subscriber_updated_OK"]   = "Subscriber updated successfully";
  $msg["subscriber_updated_fail"] = "Database Error. Can't update subscriber";
  $msg["subscriber_deleted_OK"]   = "Subscriber deleted successfully";
  $msg["subscriber_deleted_fail"] = "Database Error. Can't delete subscriber";
  $msg["subscriber_not_found"]    = "Subscriber not found";

  $msg["maillist_added_OK"]       = "Mailing list added successfully";
  $msg["maillist_added_fail"]     = "Database Error. Can't add mailing list";
  $msg["maillist_updated_OK"]     = "Mailing list updated successfully";
  $msg["maillist_updated_fail"]   = "Database Error. Can't update mailing list";
  $msg["maillist_deleted_OK"]     = "Mailing list deleted successfully";
  $msg["maillist_deleted_fail"]   = "Database Error. Can't delete mailing list";
  $msg["maillist_not_found"]      = "Mailing list not found";
  $msg["maillist_hidden"]         = "(Hidden Mailing List)";  
  $msg["maillist_import_ok"]      = "Emails imported successfully";  

  $msg["sendmail_mail_sent"]      = "Email has been already sent";
  $msg["sendmail_form_error"]     = "Send Email form data error";
      
  $msg["email_template_added_OK"]     = "Email template added successfully";
  $msg["email_template_added_fail"]   = "Database Error. Can't add email template";
  $msg["email_template_updated_OK"]   = "Email template updated successfully";
  $msg["email_template_updated_fail"] = "Database Error. Can't update email template";
  $msg["email_template_deleted_OK"]   = "Email template deleted successfully";
  $msg["email_template_deleted_fail"] = "Database Error. Can't delete email template";
  $msg["email_template_not_found"]    = "Email template not found";

  $msg["setting_update_ok"]   = "Settings updated successfully";
  $msg["setting_update_fail"] = "Database Error. Can't update settings";

  $msg["back"]   = "back";
  $msg["db_err"] = "Can't connect to database";

  $admin_msg["db_err"]         = "Database Error";    
  $admin_msg["all_subscriber"] = "All Subscribers";
  
  $admin_msg["subscriber_empty_email"]     = "Please enter email address";
  $admin_msg["subscriber_invalid_email"]   = "The email address format is invalid. Please enter it again.";
  $admin_msg["subscriber_email_exist"]     = "Email exists in the database";
  $admin_msg["subscriber_empty_maillist"]  = "Please tick the check box to subscribe the mailing lists";
  $admin_msg["subscriber_no_mailing_list"] = "<center>There is no mailing list available. Please click <a href=\"$admin_url?type=maillist\">here</a> to create mailing list.<center>";
  $admin_msg["subscriber_not_found"]       = "Subscriber not found";

  $admin_msg["maillist_empty_title"]       = "Title should not be blank";
  $admin_msg["maillist_empty_desc"]        = "Description should not be blank";
  $admin_msg["maillist_list_exist"]        = "Mailing List exists";
  $admin_msg["maillist_subscriber_exist"]  = "The mailing list is not empty. You can't delete it.";
  $admin_msg["maillist_not_found"]         = "Mailing List not found";

  $admin_msg["sendmail_no_subscriber"]           = "The mailing list has no subscriber";
  $admin_msg["sendmail_select_default_email_address"] = "Please select email address";
  $admin_msg["sendmail_select_email_address"]    = "Please select email address";
  $admin_msg["sendmail_toemail_fill_in_email"]   = "Please fill in <B>To field</B> email address";
  $admin_msg["sendmail_fromemail_fill_in_email"] = "Please fill in <B>From field</B> email address";
  $admin_msg["sendmail_select_template"]         = "Please select email template";
  $admin_msg["sendmail_toemail_invalid_email"]   = "Please fill in valid email address(<B>To field</B>)";
  $admin_msg["sendmail_fromemail_invalid_email"] = "Please fill in valid email address(<B>From field</B>)";
  $admin_msg["sendmail_select_email_template"]   = "Please select email template or custom email";
  $admin_msg["sendmail_ok"]                      = "Send Email request submitted successfully";
  $admin_msg["sendmail_empty_subject"]           = "Please enter subject";
  $admin_msg["sendmail_empty_message"]           = "Please enter plain text or HTML message";

  $admin_msg["emailstatus_not_found"] = "Record not found";

  $admin_msg["email_template_empty_name"]    = "Please fill in email template name";
  $admin_msg["email_template_empty_subject"] = "Please fill in subject";
  $admin_msg["email_template_empty_message"] = "Please fill in message (plain text or HTML)";
  $admin_msg["email_template_name_exist"]    = "Email template name exists";
  $admin_msg["email_template_not_found"]     = "Email template not found";

  $admin_msg["htmlcode_empty_listname"]      = "Please fill in Mailing List Form Name";
  $admin_msg["htmlcode_empty_maillist"]      = "Please select Mailing Lists";
  $admin_msg["htmlcode_empty_html_path"]     = "Please enter HTML template path";
  $admin_msg["htmlcode_not_exist_html_path"] = "HTML Templates Path not found";
  $admin_msg["htmlcode_added_OK"]            = "Mailing List Form added successfully";
  $admin_msg["htmlcode_added_fail"]          = "Database Error. Can't add mailing list form";
  $admin_msg["htmlcode_updated_OK"]          = "Mailing List Form updated successfully";
  $admin_msg["htmlcode_updated_fail"]        = "Database Error. Can't update mailing list form";
  $admin_msg["htmlcode_deleted_OK"]          = "Mailing List Form deleted successfully";
  $admin_msg["htmlcode_deleted_fail"]        = "Database Error. Can't delete mailing list form";
  $admin_msg["htmlcode_empty_subscribe_email"]         = "Please select subscribe email template"; 
  $admin_msg["htmlcode_empty_subscribe_fromemail"]     = "Please enter Subscribe Email Template From Email";
  $admin_msg["htmlcode_empty_unsubscribe_email"]       = "Please select unsubscribe email template"; 
  $admin_msg["htmlcode_empty_unsubscribe_fromemail"]   = "Please enter Unsubscribe Email Template From Email";
  $admin_msg["htmlcode_invalid_subscribe_fromemail"]   = "Invalid email address of Subscribe From Email";
  $admin_msg["htmlcode_invalid_unsubscribe_fromemail"] = "Invalid email address of Unsubscribe From Email";
  $admin_msg["htmlcode_subscribe_email_template_not_found"]   = "Subscribe email template not found";
  $admin_msg["htmlcode_unsubscribe_email_template_not_found"] = "Unsubscribe email template not found";
  $admin_msg["htmlcode_create_email_template"]         = "Please click <a href=\"$admin_url?type=email_template\">here</a> to create subscribe and unsubscribe email templates";
  $admin_msg["htmlcode_create_mailing_list"]           = "Please click <a href=\"$admin_url?type=maillist\">here</a> to create mailing lists";

  $admin_msg["setting_empty_username"]                = "Please enter Login Username";  
  $admin_msg["setting_display_lines"]                 = "Please select No. of records per page";
  $admin_msg["setting_empty_admin_email"]             = "Please enter Admin Email";
  $admin_msg["setting_invalid_admin_email"]           = "Invalid admin email address";
  $admin_msg["setting_default_fromemail"]             = "#EMAIL# is not in valid email format";
  $admin_msg["setting_default_mailing_list"]          = "Please select default mailing list";
    
  $eternalmart = "Powered by <a href=\"http://www.eternalmart.com\">EternalMart</a>";
  
  $notify_subject = "EternalMart Mailing List Manager Notification";
  $notify_subscribe_message = "
This email notification has been sent to inform you that someone has just 
subscribed to the mailing lists with the following details:

Subscribed at : #DATETIME#

############################################

Email address : #EMAIL#
Subscribed Mailing Lists :
#MAILLIST#

############################################

To manage this subscriber, please go to the link at
   
   #EMML_URL#


-------------------------------------
http://www.eternalmart.com

EternalMart Mailing List Manager

";  

  $notify_unsubscribe_message = "
This email notification has been sent to inform you that 

    #EMAIL# has unsubscribed to the mailing list at #DATETIME#

-------------------------------------
http://www.eternalmart.com

EternalMart Mailing List Manager

";  

  
?>
