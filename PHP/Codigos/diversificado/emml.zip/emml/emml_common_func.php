<?
  function is_valid_email($email_address) {
     $regex = '^([._a-z0-9-]+[._a-z0-9-]*)@(([a-z0-9-]+\.)*([a-z0-9-]+)(\.[a-z]{2,3}))$';
     if (!eregi($regex,$email_address)) {
       return false;
     }
     else {
       return true;
     }   
  }
  
  function get_option_value($key){
     
     global $default;
     global $emsql;
     
     $key = trim($key);
     $value = $default[$key];
     
     $sql = "SELECT * FROM emml_options WHERE option_key = '$key'";
     
     $emsql->set_sql($sql);
     
     $result = $emsql->sql_execute();        
     
     if($result){
        if($emsql->sql_num_rows($result)){
           $row = $emsql->sql_fetch_array($result);
           $value = $row[option_value];
        }           
     }     
     return trim($value);
  }
  
  function get_default_mailing_list(){
     
     global $emsql;
             
     $default_mailing_list = "";     
     
     $sql = "SELECT * FROM emml_options WHERE emml_options.option_key like 'maillist_%'";
     $emsql->set_sql($sql);
     
     $result = $emsql->sql_execute();     
     if($result){        
        while($row = $emsql->sql_fetch_array($result)){            
           $default_mailing_list .= "<INPUT TYPE=HIDDEN NAME=\"emml[$row[option_key]]\">";            
        }           
     }            
     return $default_mailing_list;
  }

  function get_emailid($email){
     
     global $emsql;
     
     $email = trim($email);
     
     $sql = "SELECT * FROM emml_subscriber WHERE emailaddress = '$email'";
     
     $emsql->set_sql($sql);
     $result = $emsql->sql_execute();         
     
     if($result){            
        if($emsql->sql_num_rows($result)){                
           $row = $emsql->sql_fetch_array($result);
           return $row["id"];                           
        }
        else {
           return "";
        }  
     }
     else {
       return "db_err";
     }  
  }  
  
  function get_list_count($listid){  
     
     global $emsql;
     
     if($listid == "ALL"){        
        $sql = "SELECT DISTINCT(emailaddress) FROM emml_subscriber, emml_mail_subscribe WHERE emml_subscriber.id = emml_mail_subscribe.emailid";
        $emsql->set_sql($sql);        
        $result = $emsql->sql_execute();
        if($result){
          return $emsql->sql_num_rows($result);         
        }
     }
     else {   
        $sql = "SELECT count(*) as listcount FROM emml_mail_subscribe WHERE emml_mail_subscribe.maillistid = '$listid'";
        $emsql->set_sql($sql);
        $result = $emsql->sql_execute();
        if($result) {        
           if($emsql->sql_num_rows($result)){
             $row = $emsql->sql_fetch_array($result);
             return $row["listcount"];
           }        
        }  
        return 0;
     }   
  }
  
?>
