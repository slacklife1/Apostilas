<?
header("Location: nkadsmin/");
?>