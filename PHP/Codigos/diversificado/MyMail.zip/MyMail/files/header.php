<html>
<head>
<title>MyMail - Version 1</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="MyMail is an easy to use Mailing list script that can handle multiple lists and addresses. MyMail is also capable of handling archives that are ready to use and insert into your site. Get MyMail now at: http://www.codingclick.com">
</head>

<body bgcolor="#FFFFFF" text="#000000" vlink="#0000FF" alink="#0000FF" link="#0000FF">
<table width="650" border="0" cellspacing="0" cellpadding="3">
  <tr valign="top"> 
    
  <td colspan="2"><a href="index.php"><img src="../images/logo.gif" width="640" height="75" border="0"></a></td>
  </tr>
  <tr> 
    <td width="120" valign="top"> 
      <p><b><font face="Verdana" size="2">Lists</font></b><font face="Verdana" size="2"><br>
        <a href="list.php?action=add">Add List</a><br>
        <a href="list.php?action=edit">Edit List</a><br>
        <a href="list.php?action=delete">Delete List</a><br>
        <a href="list.php?action=clean">Clean List</a></font></p>
      
    <p><font face="Verdana" size="2"><b>Emails</b><br>
      <a href="email.php?action=add">Add Emails</a><br>
      <a href="email.php?action=delete">Delete Emails</a><br>
      <a href="email.php?action=view">View Emails</a><br>
      <a href="export.php">Export</a> </font></p>
      
    <p><font face="Verdana" size="2"><b>Archive</b><br>
      <a href="archive.php?action=view">View</a><br>
      <a href="archive.php?action=edit">Edit/Delete</a><br>
      <a href="archive.php?action=add">Add</a><br>
    </font> </p>
    <p><font face="Verdana" size="2"><b>Other</b><br>
        <a href="send.php?action=fill">Send Mail</a><br>
        <a href="get_html.php">Get HTML</a><br>
		<a href="stats.php">Statistics</a></font></p>
      <p><a href="http://www.codingclick.com"><font face="Verdana" size="2">CodingClick</font></a></p>
      </td>
    <td width="530" valign="top">
	<br>
