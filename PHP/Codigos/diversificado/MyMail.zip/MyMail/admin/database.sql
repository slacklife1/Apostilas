
DROP TABLE IF EXISTS archive;
CREATE TABLE archive (
   ID int(11) NOT NULL auto_increment,
   listID int(11) DEFAULT '0' NOT NULL,
   issueID int(11),
   date date DEFAULT '0000-00-00' NOT NULL,
   text text NOT NULL,
   PRIMARY KEY (ID)
);




DROP TABLE IF EXISTS emails;
CREATE TABLE emails (
   ID int(11) NOT NULL auto_increment,
   email varchar(150) NOT NULL,
   validated int(11) DEFAULT '0' NOT NULL,
   listID int(11) DEFAULT '0' NOT NULL,
   date date DEFAULT '0000-00-00' NOT NULL,
   PRIMARY KEY (ID)
);




DROP TABLE IF EXISTS lists;
CREATE TABLE lists (
   ID int(11) NOT NULL auto_increment,
   listName varchar(100) NOT NULL,
   listEmail varchar(150) NOT NULL,
   listDescription varchar(255),
   listHeader text,
   listFooter text,
   archiveHeader varchar(200),
   archiveFooter varchar(200),
   archive int(11) DEFAULT '0' NOT NULL,
   useValid int(11) DEFAULT '0' NOT NULL,
   welcomeMsg text NULL,
   validMsg text NULL,
   welcomeMsgTitle varchar(100) NULL,
   validMsgTitle varchar(100) NULL,
   fontColor varchar(25),
   fontType varchar(25),
   fontSize smallint(6),
   generalHeader varchar(200),
   generalFooter varchar(200),
   PRIMARY KEY (ID),
   KEY ID (ID)
);


