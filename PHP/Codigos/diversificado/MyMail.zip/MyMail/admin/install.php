<?php
include("config.php");
include("files/header.php");

$emailsa = mysql_query("DROP TABLE IF EXISTS emails");
$listsa = mysql_query("DROP TABLE IF EXISTS lists");
$archivea = mysql_query("DROP TABLE IF EXISTS archive");

$emailsb = mysql_query("CREATE TABLE emails (
   ID int(11) NOT NULL auto_increment,
   email varchar(150) NOT NULL,
   validated int(11) DEFAULT '0' NOT NULL,
   listID int(11) DEFAULT '0' NOT NULL,
   date date DEFAULT '0000-00-00' NOT NULL,
   PRIMARY KEY (ID)
);");
$listsb = mysql_query("CREATE TABLE lists (
   ID int(11) NOT NULL auto_increment,
   listName varchar(100) NOT NULL,
   listEmail varchar(150) NOT NULL,
   listDescription varchar(255),
   listHeader text,
   listFooter text,
   archiveHeader varchar(200),
   archiveFooter varchar(200),
   archive int(11) DEFAULT '0' NOT NULL,
   useValid int(11) DEFAULT '0' NOT NULL,
   welcomeMsg text NOT NULL,
   welcomeMsgTitle varchar(100) NULL,
   validMsg text NOT NULL,
   validMsgTitle varchar(100) NULL,
   fontColor varchar(25),
   fontType varchar(25),
   fontSize smallint(6),
   generalHeader varchar(200),
   generalFooter varchar(200),
   PRIMARY KEY (ID),
   KEY ID (ID)
);");

$archiveb = mysql_query("CREATE TABLE archive (
   ID int(11) NOT NULL auto_increment,
   listID int(11) DEFAULT '0' NOT NULL,
   issueID int(11),
   date DATE NOT NULL,
   text text NOT NULL,
   PRIMARY KEY (ID)
);");


if(!$emailsa) { errorMsg("Cannot drop emails table."); print mysql_error(); }
if(!$emailsb) { errorMsg("Cannot create emails table"); print mysql_error(); } else { msg("emails table created."); }
if(!$listsa) { errorMsg("Cannot drop lists table."); print mysql_error(); }
if(!$listsb) { errorMsg("Cannot create lists table."); print mysql_error(); } else { msg("lists table created."); }
if(!$archivea) { errorMsg("Cannot drop archive table."); print mysql_error(); } 
if(!$archiveb) { errorMsg("Cannot create archive table."); print mysql_error(); } else { msg("archive table created."); }

if($emailsb && $listsb && $archiveb) {
msg("All tables created successfully. Please delete this file(install.php).");

} else {
errorMsg("Please retry the install.php. If it fails, then manually create the tables from database.sql");
}

include("files/footer.php");

?>
