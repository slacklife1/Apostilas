<?php
include("config.php");
include("files/header.php");

$query = mysql_query("SELECT * FROM emails");
if(!$query) {
errorMsg("Cannot query the database.");
} else {
$num = mysql_numrows($query);
while($result = mysql_fetch_array($query)) {
$id = $result["ID"];
$em = $result["email"];
$em = str_replace("\r", "", $em);

$insert = mysql_query("UPDATE emails SET email='$em' WHERE ID='$id'");
if(!$insert) {
errorMsg("Cannot Update $em");
}

}

msg("Update Complete.");
}

include("files/footer.php");

?>