<?php

error_reporting (E_ALL ^ E_NOTICE);

// DATEBASE HOST
$host = "localhost";

// DATEBASE USERNAME
$dbuser = "";

// DATABASE PASSWORD
$dbpass = "";

// DATABASE NAME
$dbname = "mymail";

// PATH TO MyMail folder, NOT THE ADMIN FOLDER. EXCLUDE TRAILING SLASH AND INCLUDE HTTP://

$path = "http://domain.com/MyMail";


/****************************\
* DO NOT DELETE THE BELOW    *
* UNLESS YOU HAVE ALREADY    *
* CONNECTED TO THE DATABASE. *
\****************************/


$cnx = @mysql_connect($host, $dbuser, $dbpass) or die("
<br><p><font face='Verdana' size='2' color='red'><center><b>
Cannot connect to the database at the current time.</b></center></p>" . mysql_error());

/**************************\
* DO NOT DELETE THE BELOW  *
\**************************/

mysql_select_db($dbname);

global $path;
function msg($text) {
echo("<br><p><font face='Verdana' size='2'><center>$text</center></font></p>");
}

function errorMsg($text) {
echo("<br><p><font face='Verdana' size='2' color='red'><center><b>$text</b></center></font></p>");
}

function getID() {
global $action, $PHP_SELF;
$do_get = mysql_query("SELECT * FROM lists");
$num_rows = @mysql_numrows($do_get);
if($num_rows == 0) {
errorMsg("You Must create a list first.");
} else {
if(!$do_get) {
errorMsg("Cannot query the database at the current time.");
} else {
?>
<form method="post" action="<?php echo $PHP_SELF; ?>">
  <p><font size="2" face="Verdana">Please select a list:
    <select name="listID">
<?php

while ($results = mysql_fetch_array($do_get)) {
$listID = $results["ID"];
$listName = $results["listName"];
$listName = stripslashes($listName);


print "<option value=\"$listID\">$listName</option>";

}
?>
    </select>

	<input type="hidden" name="action" value="<?php echo $action; ?>">
    <input type="submit" name="Submit" value="Go">
    </font>
</form>
<?php
}
}
}

function headers() {
global $generalHeader;
if($generalHeader == "") {
$generalHeader = "admin/files/generalHeader.php";
}
include($generalHeader);
}

function footers() {
global $generalFooter;
if($generalFooter == "") {
$generalFooter = "admin/files/generalFooter.php";
}
include($generalFooter);
}


?>
