<?php

include("config.php");
include("files/header.php");

function add_list() {

global $PHP_SELF, $action, $name, $email, $description, $listID;
global $listHeader, $listFooter, $generalHeader, $generalFooter;
global $validate, $welcomeMsg, $archive, $archiveHeader, $archiveFooter;
global $fontColor, $fontType, $fontSize, $validMsg, $validMsgTitle, $welcomeMsgTitle;
$name = stripslashes($name);
$description = stripslashes($description);
$welcomeMsg = stripslashes($welcomeMsg);
$listHeader = stripslashes($listHeader);
$listFooter = stripslashes($listFooter);
$validMsg = stripslashes($validMsg);
$validMsgTitle = stripslashes($validMsgTitle);
$welcomeMsgTitle = stripslashes($welcomeMsgTitle);
?>

<form action="<?php echo $PHP_SELF; ?>" method="post">
  <table width="500" border="1" cellspacing="0" cellpadding="3">
    <tr> 
      <td width="94"><b><font size="2" face="Verdana">List Name:</font></b></td>
      <td width="128"> 
        <input type="text" name="name" maxlength="100" value="<?php echo $name; ?>">
      </td>
      <td width="252"><font size="1" face="Verdana">The name of the list</font></td>
    </tr>
    <tr> 
      <td width="94"><b><font size="2" face="Verdana">From Email:</font></b></td>
      <td width="128"> 
        <input type="text" name="email" maxlength="150" value="<?php echo $email; ?>">
      </td>
      <td width="252"><font size="1" face="Verdana">The email address the list 
        is sent from.</font></td>
    </tr>
    <tr> 
      <td width="94"><b><font size="2" face="Verdana">List Description:</font></b></td>
      <td width="128"> 
        <textarea name="description" cols="30" rows="5"><?php echo $description; ?></textarea>
      </td>
      <td width="252"><font size="1" face="Verdana">A description of the list. 
        Maximum of 255 characters</font></td>
    </tr>
    <tr> 
      <td width="94"><b><font size="2" face="Verdana">List Header:</font></b></td>
      <td width="128"> 
        <textarea name="listHeader" cols="30" rows="8"><?php echo $listHeader; ?></textarea>
      </td>
      <td width="252">
        <p><font size="1" face="Verdana">The header inserted into the list. You 
          may leave this blank however when sending out to the list you have the 
          choice to include it or not. </font></p>
        <p>
          <font size="1" face="Verdana">&lt;--unsub--&gt; = Unsubscribe Link</font></p>
      </td>
    </tr>
    <tr> 
      <td width="94"><b><font size="2" face="Verdana">List Footer:</font></b></td>
      <td width="128"> 
        <textarea name="listFooter" cols="30" rows="8"><?php echo $listFooter; ?></textarea>
      </td>
      <td width="252">
        <p><font size="1" face="Verdana">Exactly the same as the header except 
          it is at the bottom of the email sent out. Again, you may leave it blank 
          but when sending out to the list you may opt to leave it out.</font></p>
        <p>
          <font size="1" face="Verdana">&lt;--unsub--&gt; = Unsubscribe Link</font></p>
      </td>
    </tr>
    <tr> 
      <td width="94"><b><font size="2" face="Verdana">General Header:</font></b></td>
      <td width="128"> 
        <input type="text" name="generalHeader" maxlength="200" value="<?php echo $generalHeader; ?>">
      </td>
      <td width="252"><font size="1" face="Verdana">This is the header that is 
        displayed on the signup page and any error pages. Use the full path to 
        the file to include. If left blank, the default will be used. </font></td>
    </tr>
    <tr> 
      <td width="94"><b><font size="2" face="Verdana">General Footer:</font></b></td>
      <td width="128"> 
        <input type="text" name="generalFooter" maxlength="200" value="<?php echo $generalFooter; ?>">
      </td>
      <td width="252"><font size="1" face="Verdana">Same as the general header 
        but displayed at the bottom of the page.</font></td>
    </tr>
    <tr> 
      <td width="94"><b><font size="2" face="Verdana">Check Emails:</font></b></td>
      <td width="128"> 
        <input type="radio" name="validate" value="1" <?php if($validate == "1") { print "checked"; } ?>>
        <font face="Verdana" size="2"> Yes&nbsp;&nbsp;&nbsp; 
        <input type="radio" name="validate" value="0" <?php if($validate == "0") { print "checked"; } ?>>
        No </font></td>
      <td width="252"><font size="1" face="Verdana">This option if selected yes 
        will make the user confirm that his email must be added to the list.</font></td>
    </tr>
    <tr>
	  <td width="94"><font size="2" face="Verdana"><b>Validation Message:</b></font></td>
      <td width="128">
        <textarea name="validMsg" cols="30" rows="8"><?php echo $validMsg; ?></textarea>
      </td>
	  <td width="252"> 
        <p><font size="1" face="Verdana">This is the message that will be sent 
          to users if you wish for them to confirm their email address.<br>
          <br>
          &lt;--confirm--&gt; = Confirm Link<br>
          &lt;--unsub--&gt; = Unsubscribe Link</font></p>
        </td>
	</tr>
<tr>
	  <td width="94" height="65"><font size="2" face="Verdana"><b>Validation Message 
        Title:</b></font></td>
      <td width="128" height="65"> 
        <input type="text" name="validMsgTitle" value="<?php echo $validMsgTitle; ?>">
      </td>
	  <td width="252" height="65"> 
        <p><font size="1" face="Verdana">This is the title of the messagemessage 
          that will be sent to users if you wish for them to confirm their email 
          address. </font></p>
        </td>
	</tr>
<tr>
	  <td width="94"><font size="2" face="Verdana"><b>Welcome Message Title:</b></font></td>
      <td width="128">
        <input type="text" name="welcomeMsgTitle" value="<?php echo $welcomeMsgTitle; ?>">
      </td>
	  <td width="252"> 
        <p><font size="1" face="Verdana">This is the title of the message that 
          will be sent to users if you wish for them to confirm their email address. 
          </font></p>
        </td>
	</tr>
    <tr> 
      <td width="94"><b><font size="2" face="Verdana">Welcome Message:</font></b></td>
      <td width="128"> 
        <textarea name="welcomeMsg" cols="30" rows="8"><?php echo $welcomeMsg; ?></textarea>
      </td>
      <td width="252"> 
        <p><font size="1" face="Verdana">This is the message sent to new subscribers 
          upon signup or confirmation. <br>
          &lt;--unsub--&gt; = Unsubscribe Link</font>
          </p>
        </td>
    </tr>
    <tr> 
      <td colspan="3"> 
        <p>&nbsp;</p>
        <p>&nbsp;</p>
      </td>
    </tr>
    <tr> 
      <td><b><font size="2" face="Verdana">Archive Mails Sent:</font></b></td>
      <td><font size="2" face="Verdana">
        <input type="radio" name="archive" value="1"  <?php if($archive == "1") { print "checked"; } ?>>
        Yes&nbsp;&nbsp;&nbsp; 
        <input type="radio" name="archive" value="0"  <?php if($archive == "0") { print "checked"; } ?>>
        No</font></td>
      <td><font size="1" face="Verdana">Use this option to choose whether you 
        want the emails saved and made public for people to view.</font></td>
    </tr>
    <tr> 
      <td width="94"><b><font size="2" face="Verdana">Archive Header: </font></b></td>
      <td width="128"> 
        <input type="text" name="archiveHeader" maxlength="200" value="<?php echo $archiveHeader; ?>">
      </td>
      <td width="252"><font size="1" face="Verdana">If selected yes on the previous 
        then this will be the header for archive. Use the full path and a default 
        will be used if left blank.</font></td>
    </tr>
    <tr> 
      <td width="94"><b><font size="2" face="Verdana">Archive Footer:</font></b></td>
      <td width="128"> 
        <input type="text" name="archiveFooter" maxlength="200" value="<?php echo $archiveFooter; ?>">
      </td>
      <td width="252"><font size="1" face="Verdana">This is the footer for the 
        archive.</font></td>
    </tr>
    <tr> 
      <td width="94"><b><font size="2" face="Verdana">Font Color </font></b></td>
      <td width="128"> 
        <input type="text" name="fontColor" maxlength="25" value="<?php echo $fontColor; ?>">
      </td>
      <td width="252"><font size="1" face="Verdana">This is the text color for 
        the archive. Default is black.</font></td>
    </tr>
    <tr> 
      <td width="94"><b><font size="2" face="Verdana">Font Face</font></b></td>
      <td width="128"> 
        <input type="text" name="fontType" maxlength="25" value="<?php echo $fontType; ?>">
      </td>
      <td width="252"><font size="1" face="Verdana">This is the font type for 
        the archive. Default is 'Verdana'</font></td>
    </tr>
    <tr> 
      <td width="94"><b><font size="2" face="Verdana">Font Size </font></b></td>
      <td width="128"> 
        <select name="fontSize">
          <option value="1" <?php if($fontSize == "1") { print "selected"; } ?>>1</option>
          <option value="2" <?php if($fontSize == "2") { print "selected"; } ?>>2</option>
          <option value="3" <?php if($fontSize == "3") { print "selected"; } ?>>3</option>
          <option value="4" <?php if($fontSize == "4") { print "selected"; } ?>>4</option>
          <option value="5" <?php if($fontSize == "5") { print "selected"; } ?>>5</option>
          <option value="6" <?php if($fontSize == "6") { print "selected"; } ?>>6</option>
          <option value="7" <?php if($fontSize == "7") { print "selected"; } ?>>7</option>
        </select>
      </td>
      <td width="252"><font size="1" face="Verdana">This is the font size for 
        the archive option. The default is size '2'.</font></td>
    </tr>
  </table>
  <p> 
    <input type="hidden" name="listID" value="<?php echo $listID; ?>">
    <input type="hidden" name="action" value="<?php echo $action; ?>">
    <input type="submit" name="add_list" value="Submit">
  </p>
</form>


<?php
}

if (!isset($action)) {
errorMsg("You must choose something to do from the menu on the right.");
} else {
if((!isset($listID)) && ($action == "edit" || $action == "delete" || $action == "clean")) {
getID();
} else {

if($action == "add") {

if($add_list) {
if(($name == "") || ($email == "") || ($description == "") || ($validate == "") || ($archive == "") || ($welcomeMsg == "")) {
errorMsg("You haven't filled in the required fields:");
if($name == "") { errorMsg("List Name"); }
if($email == "") { errorMsg("List Email"); }
if($description == "") { errorMsg("List Description"); }
if($validate == "") { errorMsg("Check Emails"); }
if($archive == "") { errorMsg("Archive Messages"); }
if($welcomeMsg == "") { errorMsg("Welcome Message"); }
if($welcomeMsgTitle == "") { errorMsg("Welcome Message Title"); }
add_list();

} else {

$name = addslashes($name);
$description = addslashes($description);
$listHeader = addslashes($listHeader);
$listFooter = addslashes($listFooter);
$welcomeMsg = addslashes($welcomeMsg);
$valid_msg = addslashes($valid_msg);
$validMsgTitle = addslashes($validMsgTitle);
$welcomeMsgTitle = addslashes($welcomeMsgTitle);

$insert = mysql_query("INSERT INTO lists SET " .
"listName='$name', " .
"listEmail='$email', " .
"listDescription='$description', " .
"listHeader='$listHeader', " .
"listFooter='$listFooter', " .
"archiveHeader='$archiveHeader', " .
"archiveFooter='$archiveFooter', " .
"archive='$archive', " .
"useValid='$validate', " .
"welcomeMsg='$welcomeMsg', " .
"fontColor='$fontColor', " .
"fontType='$fontType', " .
"fontSize='$fontSize', " .
"validMsgTitle='$validMsgTitle', " .
"welcomeMsgTitle='$welcomeMsgTitle', " .
"validMsg='$validMsg', " .
"generalHeader='$generalHeader', " .
"generalFooter='$generalFooter'");

if(!insert) {
errorMsg("Cannot insert data into the database. Please try again.");
print mysql_error();
} else {
msg("List successfully Added.");
}
}
} else {
add_list();


}
} elseif ($action == "delete") {
if($delete_list) {
$delete = mysql_query("DELETE FROM lists WHERE ID=$listID");
if(!$delete) {
errorMsg("Cannot delete list.");
print mysql_error();
} else {
msg("List Delete successfully.");
}
$email_delete = mysql_query("DELETE FROM emails WHERE listID=$listID");
if(!$email_delete) {
errorMsg("Could not delete emails that belong to the selected list");
print mysql_error();
} else {
$rows = mysql_affected_rows();
msg("Successfully deleted $rows emails from the selected list.");
}
} else { 

$list = mysql_query("SELECT listName FROM lists WHERE ID=$listID");
if(!$list) {
errorMsg("Cannot Get list name.");
print mysql_error();
} else {
$got = mysql_fetch_array($list);
$listName = $got["listName"];
$listName = stripslashes($listName);
?>
<p><font size="2" face="Verdana">Clicking the delete button will permanantly delete 
  this list and all email addresses that are within this list.</font></p>
<p><font size="2" face="Verdana">List to be deleted: <b><?php print $listName; ?></b></font></p>
<form method="post" action="">
  <font size="2" face="Verdana"> 
  <input type="hidden" name="listID" value="<?php echo $listID; ?>">
  <input type="hidden" name="action" value="<?php echo $action; ?>">
  <input type="submit" name="delete_list" value="Delete List">
  </font> 
</form>
<p>&nbsp;</p>
<?php
}
}
} elseif ($action == "clean") {
if($clean_list) {
$clean = mysql_query("DELETE FROM emails WHERE listID='$listID' AND validated='0' AND date < DATE_SUB(CURDATE(), INTERVAL 14 DAY);");
if(!$clean) {
errorMsg("Cannot clean list.");
print mysql_error();
} else {
$rows = mysql_affected_rows();
msg("List successfully cleaned of $rows email addresses.");
} #IF CANNOT CLEAN

} else {

$list = mysql_query("SELECT * FROM lists WHERE ID=$listID");
if(!$list) {
errorMsg("Cannot Get list name.");
print mysql_error();
} else {
$got = mysql_fetch_array($list);
$listName = $got["listName"];
$useValid = $got["useValid"];
if($useValid == "0") {
?>
<p><font size="2" face="Verdana">This list cannot be cleaned as it does not require 
  a confirmation of address.</font></p>
<p>&nbsp;</p>
<?php
} else {
?>
<p><font size="2" face="Verdana">Clicking the clean button will permanantly delete 
  all emails addresses that have not been validated for two weeks since sign up.</font></p>
<p><font size="2" face="Verdana">List to be deleted: <b><?php print $listName; ?></b></font></p>
<form method="post" action="">
  <font size="2" face="Verdana"> 
  <input type="hidden" name="listID" value="<?php echo $listID; ?>">
  <input type="hidden" name="action" value="<?php echo $action; ?>">
  <input type="submit" name="clean_list" value="Clean List">
  </font> 
</form>
<p>&nbsp;</p>
<?php
} #END IF USEVALID
} #END IF LIST
} #END IF SUBMIT
} elseif ($action == "edit") {
if($add_list) {

if(($name == "") || ($email == "") || ($description == "") || ($validate == "") || ($archive == "") || ($welcomeMsg == "")) {
errorMsg("You haven't filled in the required fields:");
if($name == "") { errorMsg("List Name"); }
if($email == "") { errorMsg("List Email"); }
if($description == "") { errorMsg("List Description"); }
if($validate == "") { errorMsg("Check Emails"); }
if($archive == "") { errorMsg("Archive Messages"); }
if($welcomeMsg == "") { errorMsg("Welcome Message"); }
if($welcomeMsgTitle == "") { errorMsg("Welcome Message Title"); }


add_list();

} else {

$name = addslashes($name);
$description = addslashes($description);
$listHeader = addslashes($listHeader);
$listFooter = addslashes($listFooter);
$welcomeMsg = addslashes($welcomeMsg);
$valid_msg = addslashes($valid_msg);
$validMsgTitle = addslashes($validMsgTitle);
$welcomeMsgTitle = addslashes($welcomeMsgTitle);


$insert = mysql_query("UPDATE lists SET " .
"listName='$name', " .
"listEmail='$email', " .
"listDescription='$description', " .
"listHeader='$listHeader', " .
"listFooter='$listFooter', " .
"archiveHeader='$archiveHeader', " .
"archiveFooter='$archiveFooter', " .
"archive='$archive', " .
"useValid='$validate', " .
"welcomeMsg='$welcomeMsg', " .
"fontColor='$fontColor', " .
"fontType='$fontType', " .
"fontSize='$fontSize', " .
"validMsgTitle='$validMsgTitle', " .
"welcomeMsgTitle='$welcomeMsgTitle', " .
"validMsg='$validMsg', " .
"generalHeader='$generalHeader', " .
"generalFooter='$generalFooter' WHERE ID=$listID");

if(!$insert) {
errorMsg("Cannot update list. Please try again.");
print mysql_error();
} else {
msg("List successfully updated.");
}
}

} else {

$get_details = mysql_query("SELECT * FROM lists WHERE ID=$listID");
if(!$get_details) {
errorMsg("Cannot get list details");
print mysql_error();
} else {
$detail = mysql_fetch_array($get_details);
$name = $detail["listName"];
$email = $detail["listEmail"];
$description = $detail["listDescription"];
$listHeader = $detail["listHeader"];
$listFooter = $detail["listFooter"];
$archiveHeader = $detail["archiveHeader"];
$archiveFooter = $detail["archiveFooter"];
$archive = $detail["archive"];
$validate = $detail["useValid"];
$welcomeMsg = $detail["welcomeMsg"];
$fontColor = $detail["fontColor"];
$fontType = $detail["fontType"];
$fontSize = $detail["fontSize"];
$validMsg = $detail["validMsg"];
$validMsgTitle = $detail["validMsgTitle"];
$welcomeMsgTitle = $detail["welcomeMsgTitle"];
$generalHeader = $detail["generalHeader"];
$generalFooter = $detail["generalFooter"];

$name = stripslashes($name);
$description = stripslashes($description);
$listHeader = stripslashes($listHeader);
$listFooter = stripslashes($listFooter);
$welcomeMsg = stripslashes($welcomeMsg);
$validMsg = stripslashes($validMsg);
$validMsgTitle = stripslashes($validMsgTitle);
$welcomeMsgTitle = stripslashes($welcomeMsgTitle);

add_list();

} #END IF CANNOT QUERY
} #END IF SUBMIT
} #END ELSE IF EDIT
}
}
include("files/footer.php");

?>
