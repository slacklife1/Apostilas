<?php

include("config.php");
include("files/header.php");

if(!isset($listID)) {
getID();
} else {
$do_get = mysql_query("SELECT * FROM lists WHERE ID=$listID");
if(!$do_get) {
errorMsg("Cannot query the database at the current time.");
} else {
$done = mysql_fetch_array($do_get);
$listName = $done["listName"];

?>
<font size="2" face="Verdana">The form which the users sign up to your list will 
look like the below. You may edit the design but you must keep all the vital parts 
there. Copy the code below the example and insert it into a page that you have 
made anywhere you like. Once a user signs up, there email is checked to make sure 
it is valid and if you select use a valid email address in the list options then 
the user will be made to confirm their signup. If you didn't then they will receive 
the welcome message that you specified in the list options. </font> 
<form method="post" action="<?php echo $path; ?>/entry.php?action=add">
  <table width="209" border="0" cellspacing="0" cellpadding="3">
  <tr> 
    <td colspan="2"><font size="2" face="Verdana"><b><?php echo $listName; ?></b></font></td>
  </tr>
  <tr> 
    <td colspan="2"> 
      <p> 
        <input type="text" name="email">
        <input type="hidden" name="listID" value="<?php echo $listID; ?>">
        <input type="submit" name="Submit" value="Go">
      </p>
    </td>
  </tr>
  <tr> 
    <td> <font size="2" face="Verdana"> 
      <input type="radio" name="what" value="sub" checked>
      Subscribe<br>
      </font></td>
    <td> <font size="2" face="Verdana"> 
      <input type="radio" name="what" value="unsub">
      Unsubscribe </font></td>
  </tr>
</table>
</form>
<p><br>
  <b><font size="2" face="Verdana">Code:</font></b> </p>
<blockquote> 
  <p><code><font size="2">&lt;form method="post" action="<?php echo $path; ?>/entry.php?action=add"&gt; 
    <br>
    &lt;table width="209" border="0" cellspacing="0" cellpadding="3"&gt;<br>
    &lt;tr&gt; &lt;td colspan="2"&gt; &lt;font size="2" face="Verdana"&gt;&lt;b&gt;<?php echo $listName; ?>&lt;/b&gt;<br>
    &lt;/font&gt;&lt;/td&gt; &lt;/tr&gt; &lt;tr&gt; &lt;td colspan="2"&gt; &lt;p&gt;<br>
    &lt;input type="text" name="email"&gt;<br>
    &lt;input type="hidden" name="listID" value="<?php echo $listID; ?>"&gt; <br>
    &lt;input type="submit" name="Submit" value="Go"&gt; <br>
    &lt;/p&gt; &lt;/td&gt; &lt;/tr&gt; &lt;tr&gt; &lt;td&gt; &lt;font size="2" 
    face="Verdana"&gt; <br>
    &lt;input type="radio" name="what" value="sub" checked&gt; Subscribe&lt;br&gt; <br>
    &lt;/font&gt;&lt;/td&gt; &lt;td&gt; &lt;font size="2" face="Verdana"&gt; <br>
    &lt;input type="radio" name="what" value="unsub"&gt; Unsubscribe &lt;/font&gt;<br>
    &lt;/td&gt; &lt;/tr&gt; &lt;/table&gt; &lt;/form&gt; &lt;p&gt;&nbsp;&amp;nbsp;&lt;/p&gt; 
    </font></code></p>
</blockquote>
<p></p>

<?php
} #END IF CANNOT DO_GET
} #END ISSET ID

include("files/footer.php");

?>