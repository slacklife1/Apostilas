<?php
global $path;
?>
<html>
<head>
<title>MyMail - Version 1</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="description" content="MyMail is an easy to use Mailing list script that can handle multiple lists and addresses. MyMail is also capable of handling archives that are ready to use and insert into your site. Get MyMail now at: http://www.codingclick.com">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<table width="650" border="0" cellspacing="0" cellpadding="3">
  <tr valign="top"> 
    <td colspan="2"><a href="http://www.codingclick.com"><img src="<?php echo $path . "/admin/files/logo.gif"; ?>" width="640" height="75" border="0"></a></td>
  </tr>
  <tr> 
    <td colspan="2" valign="top"> 
      <p>&nbsp;</p>

