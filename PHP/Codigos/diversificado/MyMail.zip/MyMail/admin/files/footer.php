</td>
  </tr>
  <tr> 
    <td colspan="2"><br>
      <center>
        <font face="Verdana" size="1">Version 0.92 | Copyright � 2001 - 2002 Peter McNulty of
        <a href="http://www.codingclick.com">CodingClick.com</a></font> 
      </center></td>
  </tr>
</table>
</body>
</html>
