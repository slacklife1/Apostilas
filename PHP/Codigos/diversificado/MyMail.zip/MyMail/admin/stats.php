<?php

include("config.php");
include("files/header.php");

if(!isset($listID)) {
getID();
} else {
$subs = mysql_query("SELECT COUNT(*) as totalnum FROM emails WHERE listID='$listID'");
$valid = mysql_query("SELECT COUNT(*) as num_valid FROM emails WHERE listID='$listID' AND validated='1'");

if(!$subs || !$valid) {
errorMsg("Cannot query the database.");
print mysql_error();
} else {
$sub = mysql_fetch_array($subs);
$totalnum = $sub["totalnum"];

$valids = mysql_fetch_array($valid);
$num_valid = $valids["num_valid"];
$num_un = $totalnum - $num_valid;
?>

<font size="2" face="Verdana">Below are some statistics for your mailing list 
that you might want to know. At the moment there aren't much but there will be 
additions at a later date.
<br><br>
Number of Subscribers: <b><?php echo $totalnum; ?></b><br>
Number of Validated Subscribers: <b><?php echo $num_valid; ?></b><br>
Number of Un-Validated Subscribers: <b><?php echo $num_un; ?></b><br></font> 
<?php
} #CANNOT QUERY
} #END GET ID
include("files/footer.php");
?>