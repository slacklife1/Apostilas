<?php

include("config.php");
include("files/header.php");

if(!isset($listID)) {
getID();
} else {

if($action == "fill") {
$do_get = mysql_query("SELECT * FROM lists WHERE ID=$listID");
if(!$do_get) {
errorMsg("Cannot query the database at the current time.");

} else {
$done = mysql_fetch_array($do_get);
$listEmail = $done["listEmail"];
$archive = $done["archive"];
?>
<p><font size="2" face="Verdana">Use the below form to send out an email to the 
  list the you have previously selected. After you click the submit button you 
  will be shown a preview of the email that will be sent out. Click next to send 
  it out. Below, the Issue ID only should be entered if you selected this list 
  to be archived. If you enter nothing and you have selected it to be archived 
  then a number will automatically be added. Issue ID must be a number. &lt;--unsub--&gt; 
enters the automatic unsubscribe link.</font></p>
<form method="post" action="send.php?action=preview">
  <table width="500" border="0" cellspacing="0" cellpadding="3">
    <tr> 
      <td width="107"><font size="2" face="Verdana">From Email: </font></td>
      <td width="130"> <font size="2" face="Verdana"> 
        <input type="text" name="fromemail" value="<?php echo $listEmail; ?>">
        </font></td>
      <td width="107"><font size="2" face="Verdana">Subject:</font></td>
      <td width="132"> <font size="2" face="Verdana"> 
        <input type="text" name="subject">
        </font></td>
    </tr>
    <tr> 
      <td width="107"><font size="2" face="Verdana">From Name: </font></td>
      <td width="130"> <font size="2" face="Verdana"> 
        <input type="text" name="fromname">
        </font></td>
      <td width="107"><font size="2" face="Verdana">Issue ID:</font></td>
      <td width="132"> <font size="2" face="Verdana"> 
        <input type="text" name="issueID" size="5" value="<?php if ($archive == "0") { print "N/A"; } ?>">
        </font></td>
    </tr>
    <tr> 
      <td width="107"><font size="2" face="Verdana">Include Header:</font></td>
      <td width="130"> <font size="2" face="Verdana"> 
        <select name="header">
          <option value="1">Yes</option>
          <option value="0">No</option>
        </select>
        </font></td>
      <td width="107"><font size="2" face="Verdana">Include Footer:</font></td>
      <td width="132"> <font size="2" face="Verdana"> 
        <select name="footer">
          <option value="1">Yes</option>
          <option value="0">No</option>
        </select>
        </font></td>
    </tr>
    <tr> 
      <td colspan="4"><font size="2" face="Verdana">Message:</font></td>
    </tr>
    <tr> 
      <td colspan="4"> 
        <textarea name="messagetext" cols="60" rows="15" wrap="PHYSICAL"></textarea>
      </td>
    </tr>
    <tr> 
      <td width="107"><font size="2" face="Verdana">Messages Sent Before wait:</font></td>
      <td width="130">
        <select name="wait">
          <option value="10" selected>10</option>
          <option value="50">50</option>
          <option value="100">100</option>
          <option value="200">200</option>
          <option value="300">300</option>
          <option value="500">500</option>
          <option value="1000">1000</option>
		  <option value="10000000">All</option>
        </select>
      </td>
      <td width="107">
        <input type="submit" name="Submit" value="Preview ">
        <input type="hidden" name="listID" value="<?php echo $listID; ?>">
      </td>
      <td width="132">&nbsp; </td>
    </tr>
  </table>
</form>

<?php
} #END IF CANNOT DO_GET
} elseif($action == "preview") {
$do_get = mysql_query("SELECT * FROM lists WHERE ID=$listID");
if(!$do_get) {
errorMsg("Cannot query the database at the current time.");
} else {
$done = mysql_fetch_array($do_get);
$archive = $done["archive"];
$listHeader = $done["listHeader"];
$listFooter = $done["listFooter"];
$listHeader = stripslashes($listHeader);
$listFooter = stripslashes($listFooter);
$subject = stripslashes($subject);
$fromname = stripslashes($fromname);
?>

<p><b><font size="2" face="Verdana">Preview:</font></b> </p>
<p><font size="2" face="Verdana">From Email: <?php echo $fromemail; ?><br>
  From Name: <?php echo $fromname; ?><br>
  Use Header: <?php print ($header == "0") ? "No" : "Yes"; ?><br>
  User Footer: <?php print ($footer == "0") ? "No" : "Yes"; ?><br>
  Use Archive: <?php if($archive == "0") { print "No"; } else { print "Yes"; } ?><br>
  Issue ID: <?php if($archive == "0" ) { print "N/A"; } else { print $issueID; } ?><br>
  Subject: <?php echo $subject; ?></font></p>
<hr noshade align="left" width="90%" size="1">
<p>
<?php

if($header == "1") {
print nl2br($listHeader);

} #END IF HEADER = 1

$text = str_replace("&lt;--unsub--&gt;", "<--unsub-->", $text);
$messagetext = stripslashes($messagetext);

print nl2br(htmlspecialchars($messagetext));


if($footer == "1") {
print nl2br($listFooter);
} #END IF FOOTER = 1
  ?>
</p>
<hr noshade align="left" width="90%" size="1">
<form method="post" action="send.php?action=send">
<?php

$fromname = addslashes($fromname);
$subject = addslashes($subject);
$messagetext = str_replace("\"", "%quotes%", $messagetext);
$subject = str_replace("\"", "%quotes%", $subject);
$fromname = str_replace("\"", "%quotes%", $fromname);
?>
 <input type="hidden" name="fromemail" value="<?php echo $fromemail; ?>">
  <input type="hidden" name="fromname" value="<?php echo $fromname; ?>">
  <input type="hidden" name="header" value="<?php echo $header; ?>">
  <input type="hidden" name="footer" value="<?php echo $footer; ?>">
  <input type="hidden" name="issueID" value="<?php echo $issueID; ?>">
  <input type="hidden" name="listID" value="<?php echo $listID; ?>">
  <input type="hidden" name="subject" value="<?php echo $subject; ?>">
<input type="hidden" name="wait" value="<?php echo $wait; ?>">
  <input type="submit" name="Submit" value="Submit">
<input type="hidden" name="messagetext" value="<?php echo $messagetext ?>">

 
</form>
<p>&nbsp;</p>


<?php
 

} #END IF CANNOT DO_GET
} elseif($action == "send") {

$query = mysql_query("SELECT * FROM emails WHERE listID=$listID and validated='1'");

if(!$query) {
errorMsg("Cannot get emails.");
print mysql_error();
} else {

$do_get = mysql_query("SELECT * FROM lists WHERE ID=$listID");
if(!$do_get) {
errorMsg("Cannot query the database at the current time.");
} else {
$done = mysql_fetch_array($do_get);
$listEmail = $done["listEmail"];
$archive = $done["archive"];
$listHeader = $done["listHeader"];
$listFooter = $done["listFooter"];
$listHeader = stripslashes($listHeader);
$listFooter = stripslashes($listFooter);

if($header == "1") {
$text = $listHeader;
}

$text .= $messagetext;

if($footer == "1") {
$text .= $listFooter;
}

$text = str_replace("\r\n", "\n", $text);

$text = stripslashes($text);
$subject = stripslashes($subject);
$fromname = stripslashes($fromname);

$text = str_replace("%quotes%", "\"", $text);
$subject = str_replace("%quotes%", "\"", $subject);
$fromname = str_replace("%quotes%", "\"", $fromname);

$subject = stripslashes($subject);
$fromname = stripslashes($fromname);
$text = stripslashes($text);

$headers = "From: \"$fromname\" <$fromemail>\n" .
            "Return-Path: $fromemail\n";



$x = 1;

while ($do = mysql_fetch_array($query)) {
$address = $do["email"];
$texts = str_replace("<--unsub-->", $path . "/entry.php?action=add&listID=" . $listID .
"&email=" . $address . "&what=unsub", $text);
$mail_send = mail($address,$subject,$texts,$headers);

if(!$mail_send) {
errorMsg("Message not sent to $address.");
}
$x++;


if($x == $wait) {
sleep(3); 
$x = 0;
}
 
}

if($mail_send) {
msg("Mail Sent.");
} else {
msg("Mail not sent.");
}

if($archive == "1") {
$text = nl2br($text);
$text = addslashes($text);
if($issueID == "") {
$query = mysql_query("SELECT issueID FROM archive WHERE listID='$listID' ORDER by issueID DESC LIMIT 1");
if(!$query) {
errorMsg("Cannot query archive table.");
print mysql_error();
} else {
$query = mysql_fetch_array($query);
$issueID = $query[0] + 1;
} #END GET LATEST
$text = addslashes($text);
$insert = mysql_query("INSERT INTO archive SET " .
"listID='$listID', " .
"issueID='$issueID', " .
"date=CURDATE(), " .
"text='$text'");
} else {
$text = addslashes($text);
$insert = mysql_query("INSERT INTO archive SET " .
"listID='$listID', " .
"issueID='$issueID', " .
"date=CURDATE(), " .
"text='$text'");
}

if(!$insert) {
errorMsg("Cannot insert data into archive");
print mysql_error();
} else {
msg("Archive successfully updated.");
} #END INSERT

if($mail_send) {
msg("Mail Sent!");
} #END MAIL SENT

} #END IF ARCHIVE =1
} #END QUERY
} #END IF CANNOT QUERY
} #END IF ACTION == ""
} #END ISSET ID

include("files/footer.php");

?>
