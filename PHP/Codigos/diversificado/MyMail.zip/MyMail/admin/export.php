<?php

include("config.php");
include("files/header.php");

if(!isset($listID)) {
getID();
} else {

if($action == "export") {
$export = mysql_query("SELECT * FROM emails WHERE listID=$listID");
$num_rows = mysql_numrows($export);
if(!$export) {
errorMsg("Can't retrieve emails.");
print mysql_error();
} else {
if($num_rows == "0") {
errorMsg("There are no emails");
} else {
$format = nl2br($format);
print '<font face="verdana" size="2">';
while ($results = mysql_fetch_array($export)) {
$emails = $results["email"];
print "$emails$format";


} #END WHILE
print "</font>";
} #END NUMBER ROWS
} #END EXPORT
} else {
?>

<p><font size="2" face="Verdana">In the textarea below enter the format in which 
  you wish the list to be exported like. Exmaple: In the box you press 'Enter 
  on your keyboard, the each email address will be printed on a new line.</font></p>
<form method="post" action="export.php?action=export">
  <textarea name="format"></textarea>
  <br>
  <input type="submit" name="Submit" value="Export">
  <input type="hidden" name="listID" value="<?php echo $listID; ?>">
</form>
<p>&nbsp;</p>


<?php
} #END ACTION
} #END ISSET ID
include("files/footer.php");
?>