<?php
include("config.php");
include("files/header.php");

$sql = "ALTER TABLE lists ADD welcomeMsgTitle VARCHAR (100) not null AFTER welcomeMsg , ADD validMsg TEXT not null AFTER welcomeMsgTitle , ADD validMsgTitle VARCHAR (100) not null AFTER validMsg";
$query = mysql_query($sql);
if($query) {
    errorMsg("Cannot query the database.");
    print mysql_error();
} else {
    msg("Update completed successfully. Please delete this file and any other install / upgrade files as they are a security threat.");
}


include("files/footer.php");

?>
