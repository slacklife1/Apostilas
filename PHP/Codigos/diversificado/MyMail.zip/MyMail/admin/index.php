<?php

// INCLUDE STUFF
include("config.php");
include("files/header.php");


?>

<p><font size="2" face="Verdana">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Welcome to 
  MyMail the multi-mailing list script. If this is your first time using this 
  script then go to the left menu and select add list. Once the page displays, 
  there are easy to follow directions on setting up your mailings list. Remember 
  that after you have run install.php, which you should have, please delete install.php 
  as it is a hazard to your list. It is recommended that you password protect 
  the admin directory as then no ne will have access to this admin area of the 
  script. </font></p>
<p><font size="2" face="Verdana">Peter McNulty<br>
  <a href="http://www.codingclick.com">CodingClick.com</a> </font></p>

<?php

include("files/footer.php");

?>
