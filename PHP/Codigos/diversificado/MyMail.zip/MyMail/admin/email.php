<?php

include("config.php");
include("files/header.php");


if($action == "") {
errorMsg("Please choose an action to do.");
} else {
if(!isset($listID)) {
getID();
} else {

if($action == "add") {
if($add_email) {
$x = 0;
if($enter == "") {
errorMsg("You must enter at least one email address.");
} else {
$email = explode("\r\n", $enter);
$num_row = count($email);
if($num_row == "0") {
errorMsg("You must enter some addresses.");
} else {

for ($i=0; $i<$num_row; $i++) {
$check = mysql_query("SELECT email FROM emails WHERE email='$emails[$i]' AND listID='$listID'");
if(!$check) {
errorMsg("Cannot query database");
} else {
$rows = mysql_numrows($check);
if($rows == "1") {
errorMsg("$email[$i] already exists in this list.");
} else {
$insert = mysql_query("INSERT INTO emails SET email='$email[$i]', validated='1', listID='$listID', date=CURDATE()");
if(!$insert) {
errorMsg("Cannot Insert $email[$i] into the database.");
} else {
while ($x < 1) {
msg("Addresses added succesfully.");
$x++;
}
} 
}
}
}
}

}
} else {
?>
<p><font size="2" face="Verdana">Use the text box below to enter email addresses 
  into the previously selected list. Enter one email address per line an do not 
  use commas or semi colons to separate the entries. Once completed, click the 
  submit button to add the addresses to the list. Note: Emails added in this list 
  are automatically assumed valid email addresses and the newsletter will be sent 
  to them.</font></p>
<form method="post" action="<?php echo $PHP_SELF; ?>">
  <textarea name="enter" cols="40" rows="20"></textarea>
  <br>
  <input type="hidden" name="listID" value="<?php echo $listID; ?>">
  <input type="hidden" name="action" value="<?php echo $action; ?>">
  <input type="submit" name="add_email" value="Add Addresses">
</form>
<p>&nbsp;</p>
<?
}
} elseif ($action == "delete") {
if($delete_box) {

if($ent == "") {
errorMsg("You must enter at least one email address.");
} else {

$ents = explode("\n", $ent);
if(count($ents) > 0) { 
$delidStr = implode("','",$ents); 
}
$del = mysql_query("DELETE from emails WHERE listID='$listID' AND email in ('$delidStr')");
$num = mysql_affected_rows();
if($del) {
msg("$num emails have been deleted.");
} else {
errorMsg("There was an error deleting the emails from the database.");
print mysql_error();
}
}


} elseif($delete_emails) {

if(count($delid) > 0) { 
$delidStr = implode(",",$delid); 
} 
$del = mysql_query("DELETE from emails where ID in ($delidStr)");
if($del) {
msg("The selected emails have been deleted.");
} else {
errorMsg("There was an error deleting the emails from the database.");
}


} else {
$do_get = mysql_query("SELECT * FROM emails WHERE listID=$listID");
if(!$do_get) {
errorMsg("Cannot retrieve the email addresses from the database.");
} else {
$num_rows = mysql_numrows($do_get);
if($num_rows == "0") {
errorMsg("There are no email addresses for this list. Please add some first.");
} else {

?>
<p><font size="2" face="Verdana">After you have selected the Email addresses that 
  must be deleted then click submit at the top. This will permanently delete the 
  email addresses in the database. Alternatively if you need to delete an address 
  without searching for it then use the box below. Enter one address per line.</font></p>
<form method="post" action="<?php echo $PHP_SELF; ?>">
  <textarea name="ent" cols="30" rows="5"></textarea>
  <br>
  <input type="hidden" name="listID" value="<?php echo $listID; ?>">
  <input type="hidden" name="action" value="<?php echo $action; ?>">
  <input type="submit" name="delete_box" value="Delete">
</form>
<p>&nbsp;</p>
<form method="post" action="<?php echo $PHP_SELF; ?>">
  <p> 
    <input type="hidden" name="listID" value="<?php echo $listID; ?>">
    <input type="hidden" name="action" value="<?php echo $action; ?>">
    <input type="submit" name="delete_emails" value="Delete Checked">
    <br>
  </p>
  <table width="490" border="0" cellspacing="0" cellpadding="3">
    <tr> 
      <td width="7">&nbsp;</td>
      <td width="287"><font size="2" face="Verdana"><b>Email?</b></font></td>
      <td width="87"><font size="2" face="Verdana"><b>Validated?</b></font></td>
      <td width="100"><font size="2" face="Verdana"><b>Date Added?</b></font></td>
    </tr>
    <?php
while ($results = mysql_fetch_array($do_get)) {
$emailID = $results["ID"];
$email = $results["email"];
$valid = $results["validated"];
$date = $results["date"];
if($valid == "1") {
$valid = "Yes";
} else {
$valid = "No";
}

?> 
    <tr> 
      <td width="7"> 
        <input type="checkbox" name="delid[]" value="<?php echo $emailID; ?>">
      </td>
      <td width="287"><font size="2" face="Verdana"><?php echo $email; ?></font></td>
      <td width="87"><font size="2" face="Verdana"><?php echo $valid; ?></font></td>
      <td width="96"><font size="2" face="Verdana"><?php echo $date; ?></font></td>
    </tr>
    <?php
}
?> 
  </table>
  <p>&nbsp;</p>
</form>
<?php

}
}
}

} elseif ($action == "view") {

$do_view = mysql_query("SELECT * FROM emails WHERE listID=$listID");
if(!$do_view) {
errorMsg("Cannot retrieve the email addresses from the database.");
} else {
$num_rows = mysql_numrows($do_view);
if($num_rows == "0") {
errorMsg("There are no email addresses for this list. Please add some first.");
} else {

?>

<p><font size="2" face="Verdana">Here is a list of the emails that reside in the 
  list that you previously selected.</font></p>
  <p>&nbsp;</p>
  <table width="488" border="0" cellspacing="0" cellpadding="3">
    <tr> 
      <td width="287"><b><font size="2" face="Verdana">Email?</font></b></td>
      <td width="87"><b><font size="2" face="Verdana">Validated?</font></b></td>
      <td width="96"><b><font size="2" face="Verdana">Date Added?</font></b></td>
    </tr>
<?php
while ($result = mysql_fetch_array($do_view)) {
$emailID = $result["ID"];
$email = $result["email"];
$valid = $result["validated"];
$date = $result["date"];
if($valid == "1") {
$valid = "Yes";
} else {
$valid = "No";
}

?>
    <tr> 
      <td width="287"><font size="2" face="Verdana"><?php echo $email; ?></font></td>
      <td width="87"><font size="2" face="Verdana"><?php echo $valid; ?></font></td>
      <td width="96"><font size="2" face="Verdana"><?php echo $date; ?></font></td>
<?php
} 
?>
    </tr>
  </table>
  <p>&nbsp;</p>
<?php

}
}
}


}
}
include("files/footer.php");

?>
