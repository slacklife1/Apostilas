<?php
include("config.php");
include("files/header.php");

if(!isset($listID)) {
getID();
} else {

if($action == "add") {
if($add_archive) {
if($issueID == "") {
$select = mysql_query("SELECT issueID FROM archive WHERE listID='$listID' ORDER BY issueID DESC LIMIT 1");
if(!$select) {
errorMsg("Cannot query the database");
print mysql_error();
} else {
$got = mysql_fetch_array($select);
$issueID = $got["issueID"];
$issueID++;

} #END CANNOT QUERY
} #END IF
$text = nl2br($text);
$text = addslashes($text);
if($date == "") { 
$add_text = mysql_query("INSERT INTO archive SET issueID='$issueID', text='$text', listID='$listID', date=CURDATE()");
 } else {
$add_text = mysql_query("INSERT INTO archive SET issueID='$issueID', text='$text', listID='$listID', date='$date'");
}
if(!$add_text) {
errorMsg("Cannot insert email into the archive.");
print mysql_error();
} else {
msg("Email Successfully Inserted into the archive.");
} #END CANNOT ADD
} else {
$query = mysql_query("SELECT * FROM lists WHERE ID='$listID'");
if(!$query) {
errorMsg("Cannot query the database.");
print mysql_error();
} else {
$results = mysql_fetch_array($query);
$archive = $results["archive"];

if($archive == "0") {
errorMsg("This list isn't setup to use the archive system.");
} else {
?>
<p><font face="Verdana" size="2">Use the below form to add a new email to the 
  archive. You must manually add the headers and footers. If you choose an ID 
  that already exists then you will have two with the same issueID and will need 
  to modify one. If you leave the issueID blank then one will automatically be 
  added. The date must be entered in the correct format, the one shown.</font></p>
<form method="post" action="<?php echo $PHP_SELF; ?>">
  <table width="500" border="0" cellspacing="0" cellpadding="3">
    <tr> 
      <td width="190"><font size="2" face="Verdana">IssueID:</font></td>
      <td width="298"> <font size="2" face="Verdana"> 
        <input type="text" name="issueID" size="5">
        </font></td>
      <td width="298"><font size="2" face="Verdana">Date:</font></td>
      <td width="298">
        <input type="text" name="date">
      </td>
    </tr>
    <tr> 
      <td colspan="4"><font size="2" face="Verdana">Content:</font></td>
    </tr>
    <tr> 
      <td colspan="4"> 
        <textarea name="text" cols="60" rows="10"></textarea>
      </td>
    </tr>
    <tr> 
      <td colspan="4"> 
        <input type="submit" name="add_archive" value="Submit">
        <input type="hidden" name="listID" value="<?php echo $listID; ?>">
        <input type="hidden" name="action" value="<?php echo $action; ?>">
      </td>
    </tr>
  </table>
  <br>
</form>
<?php
} #END ARCHIVE CHECK
} #END QUERY
} #END SUBMIT ADD

} elseif($action == "edit") {
If(!isset($what)) {
$query = mysql_query("SELECT * FROM lists WHERE ID='$listID'");
if(!$query) {
errorMsg("Cannot query the database.");
print mysql_error();
} else {
$results = mysql_fetch_array($query);
$archive = $results["archive"];

if($archive == "0") {
errorMsg("This list isn't setup to use the archive system.");
} else {
$get = mysql_query("SELECT * FROM archive WHERE listID='$listID'");
if(!$get) {
errorMsg("Cannot query the archive.");
print mysql_error();
} else {
$num = mysql_numrows($get);
if($num == "0") {
errorMsg("There are no emails in the archive.");
} else {
while ( $got = mysql_fetch_array($get)) {
$id = $got["ID"];
$issueID = $got["issueID"];

print("<font face=\"verdana\" size=\"2\">Issue #$issueID [ <a href=\"archive.php?action=edit&listID=$listID&what=edit&ID=$id\">Edit</a> ] " .
"[ <a href=\"archive.php?action=edit&listID=$listID&what=delete&ID=$id\">Delete</a> ]</font><br>");
} #END WHILE
} #END NO EMAILS
} #END IF GET
} #END QUERY
}
} elseif($what == "edit") {
if($edit_now) {
$text = nl2br($text);
$text = addslashes($text);
$update = mysql_query("UPDATE archive SET issueID='$issueID', text='$text', date='$date' WHERE ID='$ID'");
if(!$update) {
errorMsg("Cannot update the database.");
print mysql_error();
} else {
msg("Record Successfully updated.");
} #END QUERY UPDATE
} else {
$get_email = mysql_query("SELECT * FROM archive WHERE ID='$ID'");
$num = mysql_numrows($get_email);
if(!$get_email) {
errorMsg("Cannot query the database.");
print mysql_error();
} else {
if($num == "0") {
errorMsg("That record doesn't exist.");
} else {
$got = mysql_fetch_array($get_email);
$issueID = $got["issueID"];
$date = $got["date"];
$text = $got["text"];
$text = str_replace("<br>\n", "\n", $text);
$text = stripslashes($text);
?>
<p><font face="Verdana" size="2">Use the below form to an email. You must manually 
  add the headers and footers. If you choose an ID that already exists then you 
  will have two with the same issueID and will need to modify one. </font> </p>
<form method="post" action="">
  <table width="500" border="0" cellspacing="0" cellpadding="3">
    <tr> 
      <td><font size="2" face="Verdana">IssueID:</font></td>
      <td> <font size="2" face="Verdana"> 
        <input type="text" name="issueID" size="5" value="<?php echo $issueID; ?>">
        </font></td>
      <td><font size="2" face="Verdana">Date:</font></td>
      <td>
        <input type="text" name="date" value="<?php echo $date; ?>">
      </td>
    </tr>
    <tr> 
      <td colspan="4"><font size="2" face="Verdana">Content:</font></td>
    </tr>
    <tr> 
      <td colspan="4"> 
        <textarea name="text" cols="60" rows="10"><?php echo $text; ?></textarea>
      </td>
    </tr>
    <tr> 
      <td colspan="4"> 
        <input type="submit" name="edit_now" value="Edit">
        <input type="hidden" name="listID" value="<?php echo $listID; ?>">
        <input type="hidden" name="action" value="<?php echo $action; ?>">
        <input type="hidden" name="what" value="<?php echo $what; ?>">
        <input type="hidden" name="ID" value="<?php echo $ID; ?>">
      </td>
    </tr>
  </table>
  <br>
</form>
<?php
} #END NUM ROWS
} #END QUERY
} #END EDIT NOW _ SUBMIT CHECK
} elseif($what == "delete") {
if($delete_now) {
$delete = mysql_query("DELETE FROM archive WHERE ID='$ID'");
$num_rows = mysql_affected_rows();
if(!delete) {
errorMsg("Could not delete the record.");
} else {

if($num_rows == "0") {
errorMsg("A record was not deleted because it did not exist.");
} else {
msg("Record successfully deleted");
} #END NUM ROWS
} #END COULD NOT DELETE
} else {
?>
<p><font face="Verdana" size="2">By selecting the button below, this will permanently 
  remove this email from the archive.</font></p>
<form method="post" action="<?php echo $PHP_SELF; ?>">
  <input type="submit" name="delete_now" value="Delete Email">
  <input type="hidden" name="listID" value="<?php echo $listID; ?>">
  <input type="hidden" name="action" value="<?php echo $action; ?>">
  <input type="hidden" name="what" value="<?php echo $what; ?>">
  <input type="hidden" name="ID" value="<?php echo $ID; ?>">
  <br>
</form>
<?php
} #END DELETE SUBMIT
} #END WHAT
} elseif($action == "view") {
?>
<font size="2" face="Verdana">To view the archive use the link below. This is 
the link that you would have on your website to get people to your archive. </font> 
<br><br>
<font size="2" face="Verdana">
<?php 
print "$path/archive.php?id=$listID";
print "</font>";

} #END ACTION
} #END ISSET LISTID
include("files/footer.php");

?>