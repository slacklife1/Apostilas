<?php
require("admin/config.php");

if(!isset($id)) {

errorMsg("A list must be selected");
} else {
$check = mysql_query("SELECT * FROM lists WHERE ID=$id");
$num = mysql_numrows($check);
if(!$check) {
errorMsg("Cannot query the database.");
} else {

if($num == "0") {
errorMsg("There is no list by this ID.");
} else {
$checked = mysql_fetch_array($check);
$archive = $checked["archive"];
$archiveHeader = $checked["archiveHeader"];
$archiveFooter = $checked["archiveFooter"];
$fontColor = $checked["fontColor"];
$fontSize = $checked["fontSize"];
$fontType = $checked["fontType"];

if($fontColor == "") { $fontColor = "Black"; }
if($fontType == "") { $fontType = "Verdana"; }
if($fontSize == "") { $fontSize = "2"; }
if($archiveHeader == "") { $archiveHeader = "admin/files/generalHeader.php"; }
if($archiveFooter == "") { $archiveFooter = "admin/files/generalFooter.php"; }


if($archive == "0") {
include($archiveHeader);
errorMsg("This list doesn't have the archive option available.");
include($archiveFooter);
} else {

if(isset($issueID)) {

$get_archive = mysql_query("SELECT * FROM archive WHERE listID='$id' AND issueID='$issueID'");
if(!$get_archive) {
include($archiveHeader);
errormsg("Cannot query the database.");
print mysql_error();
include($archiveFooter);
} else {
$num = mysql_numrows($get_archive);
if($num == "0") {
include($archiveHeader);
msg("This email does not exist in the archive.");
include($archiveFooter);
} else {
include($archiveHeader);
$result = mysql_fetch_array($get_archive);
$issueID = $result["issueID"];
$text = $result["text"];
$date = $result["date"];
$text = stripslashes($text);
?>
<font size="<?php echo $fontSize; ?>" color="<?php echo $fontColor; ?>" face="<?php echo $fontType; ?>">Issue <?php
print "$issueID - $date";
print "<hr width=\"90%\" align=\"left\" noshade height=\"1\"><br>";
print $text;
print "</font>";
include($archiveFooter);

} #GET ARCHIVE
} #END NUM
} else {

$get_archive = mysql_query("SELECT * FROM archive WHERE listID='$id' ORDER BY issueID");
if(!$get_archive) {
include($archiveHeader);
errormsg("Cannot query the database.");
print mysql_error();
include($archiveFooter);
} else {
$num = mysql_numrows($get_archive);
if($num == "0") {
include($archiveHeader);
msg("There are no emails in the archive.");
include($archiveFooter);
} else {
include($archiveHeader);

$y = 0;
?>
<table width="500" border="0">
<?php
while ($result = mysql_fetch_array($get_archive)) {
$issueID = $result["issueID"];
$y++;
if($y == "1") {
print "<tr><td width=\"100\"><a href=\"archive.php?id=$id&issueID=$issueID\"><font size=$fontSize color=$fontColor face=$fontType>Issue #$issueID</font></a></td>";
} elseif(($y == "2") || ($y == "3") || ($y == "4")) {
print "<td width=\"100\"><a href=\"archive.php?id=$id&issueID=$issueID\"><font size=$fontSize color=$fontColor face=$fontType>Issue #$issueID</font></a></td>";
} elseif($y == "5") {
print "<td width=\"100\"><a href=\"archive.php?id=$id&issueID=$issueID\"><font size=$fontSize color=$fontColor face=$fontType>Issue #$issueID</font></a></td><tr>";
$y = 0;
}

} #END WHILE
print "</table>";
include($archiveFooter);
} #NUM ROWS
} #END QUERY
} #END ISSET ISSUE ID
} #END ARCHIVE CHECK
} #END NUM
} #END IF CHECK
} #END IF ISSET ID
?>
