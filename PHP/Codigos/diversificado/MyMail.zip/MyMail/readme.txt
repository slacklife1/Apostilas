MyMail is copyright Peter McNulty or CodingClick.com
You may not redistribute this script or any variations of
this script.

You may edit this script for you own personal use.