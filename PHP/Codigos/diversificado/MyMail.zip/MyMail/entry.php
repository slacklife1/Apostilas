<?php
require("admin/config.php");
if(!$listID) {
    errorMsg("A List Id must be specified.");
} else {
$details = mysql_query("SELECT * FROM lists WHERE ID=$listID");
if(!$details) {
errorMsg("Cannot query database");
print mysql_error();
} else {
$results = mysql_fetch_array($details);
$generalHeader = $results["generalHeader"];
$generalFooter = $results["generalFooter"];
$valid = $results["useValid"];
$welcomeMsg = $results["welcomeMsg"];
$welcomeMsgTitle = $results["welcomeMsgTitle"];
$validMsg = $results["validMsg"];
$validMsgTitle = $results["validMsgTitle"];
$listEmail = $results["listEmail"];
$listName = $results["listName"];

$listName = stripslashes($listName);
$welcomeMsg = stripslashes($welcomeMsg);
$validMsg = stripslashes($validMsg);
$welcomeMsgTitle = stripslashes($welcomeMsgTitle);
$validMsgTitle = stripslashes($validMsgTitle);
$welcomeMsg = str_replace("\r\n", "\n", $welcomeMsg);
$validMsg = str_replace("\r\n", "\n", $validMsg);

global $listEmail, $listID, $listName, $path;
$headers = "From: $listEmail\n" .
            "Reply-To: $listEmail\n" .
            "X-Mailer: PHP\n" .
            "Return-Path: <$listEmail>\n";

function send_welcome_msg() {
global $email, $listName, $welcomeMsg, $welcomeMsgTitle, $headers, $listID, $listEmail, $path;
$welcomeMsg = str_replace("<--unsub-->", "$path/entry.php?action=add&listID=$listID&email=$email&what=unsub", $welcomeMsg);

$mail_send = mail($email, $welcomeMsgTitle, $welcomeMsg, $headers);
if(!$mail_send) {
headers();
errorMsg("Message not sent to $email.");
footers();
exit;
}
}

function send_valid_msg() {
global $email, $listName, $validMsg, $validMsgTitle, $headers, $listID, $listEmail, $path;
$validMsg = str_replace("<--unsub-->", "$path/entry.php?action=add&listID=$listID&email=$email&what=unsub", $validMsg);
$validMsg = str_replace("<--confirm-->", "$path/entry.php?action=confirm&listID=$listID&email=$email", $validMsg);

$mail_send = mail($email, $validMsgTitle, $validMsg, $headers);
if(!$mail_send) {
headers();
errorMsg("Message not sent to $email.");
footers();
exit;
}
}

if($action == "add") {

if($what == "sub") {


// CHECK ONE HAS BEEN ENTERED
if($listID == "") {
headers();
errorMsg("You must specify a list.");
footers();
} else {
if($email == "") {
headers();
errorMsg("You must enter an email address.");
footers();
exit;
}

if (!(ereg("^.+@.+\\..+$", $email))) {
headers();
errorMsg("You must enter a valid email address");
footers();
exit;
}

$check = mysql_query("SELECT * FROM emails WHERE listID='$listID' AND email='$email'");
if(!$check) {
headers();
errorMsg("Cannot query the database");
print mysql_error();
footers();
exit;
} else {
$count = mysql_numrows($check);
if($count == "1") {
headers();
errorMsg("That email address already exists in the database");
footers();
exit;
} else {

if($valid == "0") {

$insert = mysql_query("INSERT INTO emails SET " .
"listID='$listID', " .
"email='$email', " .
"validated='1', " .
"date=CURDATE()");
if(!$insert) {
headers();
errorMsg("Cannot Insert email address");
print mysql_error();
footers();
exit;
} else {
headers();
msg("Email added");
send_welcome_msg();
footers();
} #END IF INSERT
} else {
$insert = mysql_query("INSERT INTO emails SET listID='$listID', email='$email', validated='0', date=CURDATE()");
if(!$insert) {
headers();
errorMsg("Cannot Insert email address");
print mysql_error();
footers();
exit;
} else {

headers();
msg("Email added");
send_valid_msg();
footers();
} #END IF INSERT
} #END VALID
} #END COUNT
} #END CHECK
} #END LISTID

} elseif ($what == "unsub") {

$delete = mysql_query("DELETE FROM emails WHERE email='$email' AND listID='$listID'");
if(!$delete) {
headers();
errorMsg("Cannot delete email address");
print mysql_error();
footers();
} else {
headers();
msg("Email successfully removed");
footers();
} #END DELETE
} #END WHAT

} elseif ($action == "confirm") {
$check = mysql_query("SELECT * FROM emails WHERE listID='$listID' AND email='$email' AND validated='0'");
if(!$check) {
headers();
errorMsg("Cannot query the database.");
print mysql_error();
footers();
} else {
$num_rows = mysql_numrows($check);
if($num_rows == "0") {
headers();
errorMsg("Emails Doesn't exist / Already Confirmed / or an invalid email address");
footers();
} else {
$update = mysql_query("UPDATE emails SET validated='1' WHERE listID='$listID' AND email='$email'");
if(!$update) {
headers();
errorMsg("Cannot update record.");
print mysql_error();
footers();
} else { 
headers();
msg("Email address successfully confirmed.");
send_welcome_msg();
footers();
} #END UPDATE
} #END NUM ROWS
} #END QUERY
} #END CONFIRM
}
} # END IF ID
?>
