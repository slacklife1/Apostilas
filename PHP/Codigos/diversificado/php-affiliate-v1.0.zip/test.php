<html>
<body>
<a href=index.php?ref=testing123>click here</a>
</body>
</html>