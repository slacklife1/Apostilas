<?PHP

        include "header.290"; 
        
     print "Username Already Exists!<br>Please click BACK<br><br><br><br><br>"; 
        
        include "footer.290"; 