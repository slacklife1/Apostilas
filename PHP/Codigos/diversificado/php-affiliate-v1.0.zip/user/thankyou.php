<?PHP


        include "header.290"; 
        
        print "<p align=center><font size=3><b>Thank You For Joining!</b></font><br><br>"; 
        print "<font size=2>Please check your email for the account information email we sent you.<br><br></font>";
        
        include "footer.290"; 
        
        ?>