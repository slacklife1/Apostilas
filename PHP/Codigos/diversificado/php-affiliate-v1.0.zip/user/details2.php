<?php
 
 include "../config.php";  
  
{ 
mysql_connect($server, $db_user, $db_pass) or die ("Database CONNECT Error (line 6)"); 
mysql_db_query($database, "UPDATE affiliates SET pass = '$password', company = '$clientcompany', payableto = '$clientpayableto', title = '$clienttitle', firstname = '$clientfirstname', lastname = '$clientlastname', email = '$clientemail', street = '$clientstreet', town = '$clienttown', county = '$clientcounty', country = '$clientcountry', postcode = '$clientpostcode', website = '$clienturl', phone = '$clientphone', fax = '$clientfax' WHERE refid = '$affiliate'") or die ("Database INSERT Error (line 7)"); 
 
}


        include "header.290"; 
        
        ?><font face=arial>Change Your Details<br>
    	<a href=clicks.php>View Your Click Throughs</a><br>
    	<a href=sales.php>View Your Sales</a><br>
    	<a href=banners.php>Choose A Banner Or Link</a><br>
    	<a href=contact.php>Contact Us</a><br>
    	<p>
    	Your Details Have Now Been Changed</p><br>
    	</p>
<br>
    
       
      <?PHP
      
      include "footer.290"; 
      
      ?>
      
      