<?PHP 


	include "../header.290";
	
	print "<br>Not yet available on PHP Affiliate v1.0<br>";
	
	include "../footer.290";
	
	
?>
	
	