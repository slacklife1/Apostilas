<META HTTP-EQUIV="refresh" content="3;URL=<?= $urlof ?>">

<b>Connecting...</b>
<br><br>
<blockquote>
Some Servers do not honor the flush() buffer 
statment in php and some browsers will not load
other frames if some of the frames have not 
finished loading. if you are still reading this 
a minute from now then then your server does not
honor the flush statment. Click on the 
Admin tab and select refresh as the type of
chat.
</blockquote>

