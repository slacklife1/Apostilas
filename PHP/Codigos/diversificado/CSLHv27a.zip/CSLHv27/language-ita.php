<?
//#####################################
// Language Italian for LIVE HELP
// by Pierluigi Covelli from http://www.siamobastardi.com
//#####################################
$lang_expand = "Maximize";
$lang_tabs = "Modules/Tabs";
$lang_livehelp = "ONLINE!";
$lang_operators = "Operatori";
$lang_dept = "Dipartimento";
$lang_settings = "Settaggio";
$lang_data = "Data";
$lang_qa = "Q&A";
$lang_over = "Overview index";
$lang_hlp = "Help";
$lang_exit = "Uscita";
$lang_contact = "Contatta";
$lang_notchat = "Ora stai chattando...";
$lang_ask = "Ask:";
$lang_leave_mess = "MESSAGGIO DAL VIVO:";
$lang_leave_text = "Prego scrivi i tuoi commenti/domande in questo box <br> e provveder� a contattarti al piu' presto";
$lang_chat_text = "Utenti in Chat";
$lang_no_chat = "no one is chatting...";
$lang_diff = "Dipartimenti differenti";
$lang_chat = "chat";
$lang_stop = "STOP";
$lang_begin = "Inizio Chat";
$lang_answer = "CHAIMATA";
$lang_details = "Dettagli";
$lang_visit = "Visitatori correnti:";
$lang_options_num = "Opzioni e #pages:";
$lang_noone_online = "Attualmente non state chattando con nessuno. Quando un utente vi contatta apparir� un messaggio ed un segnale lampeggiante.  ";
$lang_choose = "Sgegli un utente con il segnale lampeggiante per chattare con lui.";
$lang_message_to = "Messaggio inviato a:";
$lang_addtional = "Opzioni addizionali";
$lang_pick = "selezionare qualcosa";
$lang_online_image = "Quando un operatore � loggato questa sar� quello che appare nel sito. Questa � URL riguardante immagine gif. Se vuoi puoi cambiarla http://www.yourdomain.com/livehelp/myimage.gif in <b>myimage.gif</b> Altrimenti se � in un altro server dovrete usare il URL pieno come  <b>http://www.yourdomain.com/someotherfolder/myimage.gif</b>";
$lang_offline_image = "Quando un operatore non � loggato nell'HELP ed al Q&A in tensione � inabilitato allora questa � l'immagine che sar� indicata che laddove il codice HTML di aiuto � individuato. Ci� � un URL all'immagine riguardante l'indice del livehelp. Cos� per esempio se immagine gif si trova su un altro server dovete scrivere <b>http://www.yourdomain.com/someotherfolder/myimage.gif</b>";
$lang_qa_image = "Quando un operatore non � loggato allora questo sar� l'icona che sar� indicata che laddove il codice HTML di aiuto � inserito. Ci� � un URL all'immagine riguardante l'indice del livehelp. Cos� per esempio se l'immagine � nello stesso server dell'applicazionel'indirizzo � http://www.yourdomain.com/livehelp/myimage.goppure <b>myimage.gif</b> Mentre se � esterna al sito dovete mettere un indirizzo completo <b>http://www.yourdomain.com/someotherfolder/myimage.gif</b>";
$lang_qa_section = "Il Q&A � una sezione per permettere che gli ospiti osservino un indice di aiuto delle domande e delle risposte per aiutarli anche quando nessuno � in linea. se questo � permesso inoltre avrete bisogno di avete indicato che numero di identificazione dei soggetti di aiuto vorreste cominciare con. ";
$lang_askname = "Quando un visitatore chiede un contatto cliccando sull'icona di aiuto possono allora essere chiesti il loro nome o direttamente essere trasmessi alla chat";
$lang_hide_icon = "Quando non c'� nessun operatore in linea avete l'opzione per nascondere l'icona di aiuto.";
$lang_email = "Quando qualcuno compila la domanda verr� inoltrata una email all'indirizzo imposto.";
$lang_opening_message = "Se l'utente mette il nome questo sar� il messaggio che appare all'inizio della chiacchierata.";
$lang_offline_mess = "Se nessuno � in linea e un ospite clicca sopra l'immagine di aiuto questo sar� il messaggio che vedranno. E' una buona idea mettere degli orari di Servizio Online .";
$lang_credit = "This is the Publicly shown credit link back to CSLH. This link is optional and can be turned off or on here. However if you opt to not have a link back to the program you <b>MUST</b> be sure to have the copyright notice in the HTML comments of the code. (a donation would be helpful too)";
$lang_how_to_add = " <b>COME AGGIUNGERE L'ICONA ALLE VOSTRE PAGINE:</b><br>Quello che dovete fare non � altro che un bel COPIA/INCOLLA nelle vostre pagine del codice HTML generato. <br><br> <b>Opzione 1: Dynamic Javascript Icon: </b> copia il codice HTML nel box giallo qui di eseguito e tutto sar� automatico.";
$lang_how_to_add2 = "<b>Opzione 2: Link semplice: </b> se desiderate fornire un semplice collegamento, potete fare come segue.";
$lang_how_to_add3 = "<b>Opzione 3: MONITORIZZAZIONE INVISIBILE: </b> se desiderate controllare e rintracciare una pagina ma non desideri avere un'icona a quella pagina o collegamento, usate questo HTML. Gli ospiti non potranno vedere l'icona .<br>";
$lang_user_choose = "SCELGA PREGO Una CATEGORIA Dalla PARTE DI SINISTRA";
$lang_question = "Domande";
$lang_answer = "Chiamta";
$lang_help = "Categorie di aiuto";
$lang_help2 = "Domande/Topics";

?>
