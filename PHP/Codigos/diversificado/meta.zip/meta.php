<?
#-----------------------------------------#
# PHP Meta Search Engine		  #
#					  #
# by Ericson C. Smith (2001)		  #
# under the GPL				  #
# esconsult1@yahoo.com			  #
# 					  #
# If you need new to add new engines,     #
# I can do this for a small fee to cover  #
# my busy time! $US 25 to add each eng.   #
# Just e-mail me at the above address     #
# with the name of the site and a         #
# description of the results to be parsed.#
# Turnaround is normally in a few hours!  #
#					  #
# I can also make this over to completely #
# integrate within your site.		  #
#					  # 
#-----------------------------------------#

print "
<HTML>
<HEAD>
<TITLE>Meta Search Engine</TITLE>
</HEAD>

<BODY>

<font face=Verdana,Arial,Helvetica,sans-serif size=-1>
<FORM method=get>
 Search: <input type=text name=search><input type=submit name=Search value=$search><br>
</FORM>
<hr size=1 noshade>";

#- Start search 
if($search) {
 
 $q = urlencode($search);
 
 $start = time();

 $eng[0]['url']  = "http://www.google.com/search?q=$q&hl=en&lr=&safe=off&start=0&sa=N";
 $eng[0]['name'] = "Google";
 $eng[0]['reg']  = "/<p><A HREF=(.*?)>(.*?)<\/A><font.*?<br>(.*?)<br>/";
 $eng[0]['strip'] = "\n";

 $eng[1]['url'] = "http://www.alltheweb.com/search?cat=web&lang=any&query=$q";
 $eng[1]['name'] = "AllTheWeb";
 $eng[1]['reg'] = '/<dt>.*?href=\"(.*?)\">(.*?)<\/a>.*?<dd>(.*?)<br>/i';
 $eng[1]['strip'] = "\n";

 $eng[2]['url'] = "http://altavista.com/sites/search/web?q=$q&enc=&kl=XX&search=Search";
 $eng[2]['name'] = "Altavista";
 $eng[2]['reg'] = "/<A .*?status='(.*?)'.*?\">(.*?)<\/A>.*?<BR>(.*?)<BR>/i";
 $eng[2]['strip'] = "\n";

 $eng[3]['url'] = "http://search.msn.com/results.asp?ba=(0.0)0&co=(0.10)4.1..2.1.4.1&FORM=MSNH&RS=CHECKED&q=$q&v=1";
 $eng[3]['name'] = "MSN";
 $eng[3]['reg'] = "/<A CLASS.*?href=\"(.*?)\">(.*?)<\/A><br.*?>(.*?)<br/i";
 $eng[3]['strip'] = "";

 $eng[4]['url'] = "http://search.excite.com/search.gw?c=web&search=$q&onload=";
 $eng[4]['name'] = "Excite";
 $eng[4]['reg'] = "/pos=.*?;(http.*?)onMouse.*?<b>(.*?)<br>.*?size8>(.*?)<\/span>/i";
 $eng[4]['strip'] = "\n";

 $eng[5]['url'] = "http://google.yahoo.com/bin/query?p=$q&hc=1&hs=4";
 $eng[5]['name'] = "Yahoo";
 $eng[5]['reg'] = "/href.*?\*(.*?)\">(.*?)<br>.*?<\/b>(.*?)<br>/i";
 $eng[5]['strip'] = "\n"; 

 $urls = array();
 $out = array();
 $y=0;

 foreach($eng as $c)
   {
     $text1 = join("",file($c['url']));

     if($c[strip])
       $text1 = ereg_replace($c[strip],"",$text1);
       
     preg_match_all($c['reg'],$text1,$matches);
     $num = count($matches[0]);
     
     for($x=0;$x<$num;$x++) {
     $url = strip_tags($matches[1][$x]);
     $title = strip_tags($matches[2][$x]);
     $description = strip_tags($matches[3][$x]);
     $engine = $c[name];
     
     if($out["$url"])
       {
         $out["$url"][engine] .= ", $engine";
       }
     else
       {
         $out["$url"][title] = $title;
         $out["$url"][description] = $description;
         $out["$url"][engine] = $engine;
       }  
      $y++;
     } 
       
   }#rof

 $secs = time() - $start;
 
 print "$y results returned in $secs seconds.<br><br>";
 print "<OL>";
 #print "<pre>";
 #print_r($out);
 #print "</pre>";
 
 while(list($url,$rec) = each($out))
   {
     extract($rec);
     print " 
	<li>
	<a href=$url><b>$title</b></a><BR>
	   $description
	<FONT size=1><BR>$url<br></FONT>
	<FONT size=1 color=green>$engine</FONT>
	<BR><BR>"; 
   }

 print "</OL>";  

 print "
	</font>
	</BODY>
	</HTML>
	";	
 } #end search
 	
?>