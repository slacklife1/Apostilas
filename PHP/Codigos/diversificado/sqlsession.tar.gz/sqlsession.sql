CREATE DATABASE session;
USE session;
CREATE TABLE session (
   id char(20) NOT NULL,
   LastAction datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
   ip char(15) NOT NULL,
   userID mediumint(9),
   PRIMARY KEY (id),
   KEY id (id),
   UNIQUE id_2 (id)
);

CREATE TABLE user_vars (
   name varchar(30) NOT NULL,
   session varchar(20) NOT NULL,
   intval int(10) unsigned,
   strval varchar(100),
   id mediumint(8) unsigned DEFAULT '0' NOT NULL auto_increment,
   PRIMARY KEY (id),
   KEY sessionID (session),
   UNIQUE id (id)
);
