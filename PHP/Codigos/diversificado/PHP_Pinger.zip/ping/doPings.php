<?
##### FILE #####
#
#    Name:	ping\doPings.php
# Package:  PHP Pinger
# Purpose:	Prints a list of ips and does a continuous ping on each one.  The pings
#			are done through an invisible IFRAME pointing to pinger.php.
#  Author:	Michael Bailey <mpbailey@byu.edu>
#    Date:	23 May 2002
#
##

# Set the cookie for the IPs
setcookie('PingCookie', $_GET['IPs'], time()+1000000);

# Get the IP List
$arr = split(":", $_GET['IPs']);
$IPs = $_GET['IPs'];
$ips = array();

# Grab each IP and verify that the IP is valid
foreach ($arr AS $ip) {
	if (preg_match('/^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/', $ip))
		$ips[] = $ip;
}

# If no IPs were specified, return to the config page
if (!$ips) {
	header("Location: index.php");
	exit;
}

?>

<HTML>
<HEAD>
<STYLE>

SPAN.total_pings {
	font-family:sans-serif;
	text-align:center;
	color:#FF0000;
	width:20;
	font-size:80%;
	padding:2;
	border-bottom:1pt dashed black;
}	

TD.failures {
	font-family:sans-serif;
	text-align:center;
	color:#FF0000;
	font-size:80%;
	border:1pt solid black;
	padding-left:2;
	padding-right:2;
}

TD.ip_address {
	font-family:sans-serif;
}

TABLE.bar_graphs {
	font-size:10%;
	width:300;
	height:5;
}

.red_bar {
	background:#EE3333;
	height:5;
	width:0%;
}

.blue_bar {
	background:#3366CC;
	height:5;
	width:0%;
}

TD.empty_bar {
	background:#AAAAAA;
	height:5;
}

TD.graph {
	background:url('graph-bg.png');
	font-size:10%;
}


</STYLE>

<TITLE>PHP Pinger</TITLE>
<SCRIPT Language='JScript'>

var seguir = true;
var avg = new Array(<? echo count($ips) ?>);
var hi = new Array(<? echo count($ips) ?>);
var lo = new Array(<? echo count($ips) ?>);

for (i=0; i<<? echo count($ips) ?>; i++) {
	avg[i] = 0;
	hi[i] = 0;
	lo[i] = 10000;
}

function pingResults(arr) {
	for (var i=0; i<<? echo count($ips) ?>; i++) {
		if (parseInt(arr[i]) < 1) {
			document.all['t'+i].style.width = '0%';
			document.all['f'+i].innerHTML = parseInt(document.all['f'+i].innerHTML) + 1;
		} else {
			if (arr[i] < lo[i]) {
				document.all['lo' + i].innerHTML = arr[i];
				lo[i] = arr[i];
			}
			if (arr[i] > hi[i]) {
				document.all['hi' + i].innerHTML = arr[i];
				hi[i] = arr[i];
			}
			avg[i] = (parseFloat(avg[i])*parseInt(document.all['total'].innerHTML)+parseInt(arr[i]))/(parseInt(document.all['total'].innerHTML)+1);
			document.all['t' + i].style.width = arr[i];
			document.all['av'+i].style.width = parseInt(avg[i]);
			document.all['avg' + i].innerHTML = parseInt(avg[i]);
			document.all['las' + i].innerHTML = arr[i];
		}		
	}
	document.all['total'].innerHTML = parseInt(document.all['total'].innerHTML) + 1;
}

function restart()
{
	avg = new Array(<? echo count($ips) ?>);
	for (i=0; i<<? echo count($ips) ?>; i++) {
		avg[i] = 0;
		document.all['f'+i].innerHTML = 0;
	}
	seguir = true;
	document.all.total.innerHTML = 0;
	fr.document.location = "pinger.php?IPs=<? echo $IPs; ?>";
}

function stop()
{
	seguir = false;
}	

</SCRIPT>
</HEAD>
<BODY>
<INPUT Type=button Value="Stop" OnClick="stop();">&nbsp;
<INPUT Type=button Value="Back" OnClick="document.location = 'index.php'">&nbsp;
<INPUT Type=button Value="Restart" OnClick="restart();">
<P>
All values are measured in milliseconds (ms).  The red bar measures<BR>
the last ping time.  The blue bar measures the average ping time.
</P>
Total Pings: <SPAN Class=total_pings ID=total>0</SPAN> ( 20 ping intervals )
<BR>
<TABLE Cellspacing=0 Cellpadding=0>
	<TR>
		<TH>Fails</TH><TD>&nbsp;</TD>
		<TH>Avg</TH><TD>&nbsp;</TD>
		<TH>Last</TH><TD>&nbsp;</TD>
		<TH>High</TH><TD>&nbsp;</TD>
		<TH>Low</TH><TD>&nbsp;</TD>
		<TH>Address</TH><TD><IMG Src='graph-hdr.png'></TD></TR>
	
<?	for ($i=0; $i<count($ips); $i++) {?>
	<TR><TD Class=failures ID=f<? echo $i ?>>0</TD>
		<TD>&nbsp;</TD>
		<TD Class=failures ID=avg<? echo $i ?>>&nbsp;</TD>
		<TD>&nbsp;</TD>
		<TD Class=failures ID=las<? echo $i ?>>&nbsp;</TD>
		<TD>&nbsp;</TD>
		<TD Class=failures ID=hi<? echo $i ?>>&nbsp;</TD>
		<TD>&nbsp;</TD>
		<TD Class=failures ID=lo<? echo $i ?>>&nbsp;</TD>
		<TD>&nbsp;</TD>
		<TD Class=ip_address>&nbsp;&nbsp;<? echo $ips[$i]; ?>&nbsp;&nbsp;</TD><TD Class=graph>
		<TABLE Class=bar_graphs Cellspacing=0 Cellpadding=0>
			<TR><TD ID=t<? echo $i ?> Class=red_bar>&nbsp;</TD><TD Class=empty_bar>&nbsp;</TD>
		</TABLE><BR>
		<TABLE Class=bar_graphs Cellspacing=0 Cellpadding=0>
			<TR><TD ID=av<? echo $i ?> Class=blue_bar>&nbsp;</TD><TD Class=empty_bar>&nbsp;</TD>
		</TABLE>
	</TD></TR>
<?}?>
</TABLE>
<IFRAME ID=fr Width=1 Height=1></IFRAME>
<SCRIPT>
	fr.document.location = "pinger.php?IPs=<? echo $IPs; ?>";
</SCRIPT>
</BODY>
</HTML>


