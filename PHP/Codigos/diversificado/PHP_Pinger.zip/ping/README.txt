PHP Pinger
Author: Michael Bailey <mpbailey@byu.edu>
Distribution Date: 1 Oct 2002

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Purpose:

The PHP Pinger was designed to allow system administrators to
quickly examine the status of their computer systems using the
ping protocol.

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Installation:

This module requires the use of PHP.  Simply decompress this the
contents of phpPinger.zip.  A directory called 'ping' will be created
automatically.  Put this in a directory with PHP access and initiate 
the file 'index.php'

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Linux:

I must also whole-heartedly appologize that this currently only runs on 
Winnt servers.  I had a version of this program which runs in linux, but
I seem to have misplaced it and we have recently reformatted the only linux
server that we have here.  I would appreciate anyone's help on adding linux
functionality.  The winnt specific code is solely located in 'pinger.php'

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Usage Notes:

The files employ JScript which is only fully supported on IE.  IE6 is the
only version which will support the graphs, though if you find a way
that I can make IE4 and IE5 support the graphs, please tell me.  I'd like to
know how.  Netscape will probably not support this program correctly.

I am always welcoming comments, criticism, advice, and good clean jokes, so 
feel free to contact me at mpbailey@byu.edu
