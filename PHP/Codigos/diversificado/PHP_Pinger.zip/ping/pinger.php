<?
##### FILE #####
#
#    Name:	ping/pinger.php	
# Package:  PHP Pinger
# Purpose:	Does the actual pinging for the ping test.  This is called in an
#			invisible IFRAME by the doPings.php script.  This calls jscript functions
#			in the doPings.php page which change the graph.
#  Author:	Michael Bailey <mpbailey@byu.edu>
#    Date:	23 May 2002
#
##

# Default number of pings to do per check
$interval = 20;

# Grab each IP and verify that the IP is valid
$arr = split(":", $_GET['IPs']);
$ips = array();
foreach ($arr AS $ip) {
	if (preg_match('/^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/', $ip))
		$ips[] = $ip;
}

# Exit if no IPs have been defined
if (!$ips)  exit;
flush();

# Open a pipe to each Ping process (be careful that you don't do a denial of service attack on yourself)
foreach ($ips AS $ip)  $p[] = popen("ping $ip -n $interval ", "r");

# Throw away the first three header lines
foreach ($p AS $ping) {
	fgets($ping, 1024);
	fgets($ping, 1024);
	fgets($ping, 1024);
}

# Loop through each process for each ping and display the results
for ($i=0; $i<$interval; $i++) {
	print "<SCRIPT>\n";
	$timeouts = array();

# Get the response time for each ping
	foreach ($p AS $ping) {
		$resp = fgets($ping,1024);
		preg_match('/time[=\<](\d*)ms/', $resp, $matches);
		$timeouts[] = ( $matches[1] ? $matches[1] : 0);
	}
	$timeouts[] = 0;

# Calls a Javascript function to display the results	
	print "    parent.pingResults(new Array(" . join(', ', $timeouts) . "));\n";
	print "</SCRIPT>\n";
	flush();
}

# Close all of the pipes
foreach ($p AS $ping)  pclose($ping);

# Tell the browser to reload this frame unless, the user has specified that he wants to stop
?>
<SCRIPT>
	if (parent.seguir)  document.location = '<? echo $PHP_SELF . "?${_SERVER['QUERY_STRING']}"; ?>';
	else  parent.document.all.total.innerHTML = "Stopped! " + parent.document.all.total.innerHTML;
</SCRIPT>

<?


?>