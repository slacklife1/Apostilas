<?php
##### FILE #####
#
#    Name:	ping\index.php
# Package:  PHP Pinger
# Purpose:	Allows the user to define what ips they wish to ping.  This will then send
#			the user to the doPings.php page to actually do the pinging.  The information
#			is stored in a cookie on the user's computer so that the next time they log
#			in they have the same IPs set.
#  Author:	Michael Bailey <mpbailey@byu.edu>
#    Date:	23 May 2002
#
##

# If a cookie is set on the browser, grab the IPs that it contains
$cookie = $_COOKIE['PingCookie'];
$ips = array();
if ($cookie) {
	$tmp = split(':', $cookie);
	foreach ($tmp AS $ip) {
		if (preg_match('/^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/', $ip))
			$ips[] = $ip;
	}
}
?>
<HTML>
<HEAD>
<TITLE>PHP Pinger - IP Select</TITLE>
<STYLE>

SELECT {
	font-size:100%;
	width:100%;
	border:1pt solid black;
}

INPUT.text {
	font-size:80%;
	border:1pt solid black;
}

INPUT.button {
	width:100%;
}

</STYLE>	

<SCRIPT Language='JavaScript'>
// Add the interval
	function addAll()
	{
		var start_ip = ping.ip_start.value;
		var ip_ex = /^(((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3})(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
		
		if (!ip_ex.exec(start_ip)) {
			alert(start_ip + " is not a valid IP address.");
			return;
		}

		var options = ping.ips.options;
		var subnet = start_ip.replace(ip_ex, "$1");
		var suffix = start_ip.replace(ip_ex, "$4");
		var end_ip = ping.ip_end.value;
		
		if (parseInt(suffix) > parseInt(end_ip)) {
			alert("The first IP must be lower than the second.");
			return;
		}
		if (parseInt(end_ip) >= 256) {
			alert("The second IP must be less than 256.");
			return;
		}

		for (var i=parseInt(suffix); i<=parseInt(end_ip); i++) {
			flag = true;
			for (j=0; j<options.length; j++) {
				if (options[j].value == (subnet + i)) {
					flag = false;
				}
			}
			if (flag)  options[options.length] = new Option(subnet + i, subnet + i);
		}
	}

	function addIP() 
	{
		var options = ping.ips.options;
		var new_ip = ping.ip_address.value;
		var valid_ip = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/.exec(new_ip);
		if (!valid_ip) {
			alert(new_ip + " is not a valid IP address.");
		} else {
			for (i=0; i<options.length; i++) {
				if (options[i].value == new_ip) {
					alert(new_ip + " is already in the list.");
					break;
				}
			}
			if (i >= options.length) options[options.length] = new Option(new_ip,new_ip);
		}
	}

// Send the IPs to the pinger
	function doPings()
	{
		var ips = "";
		var options = ping.ips.options;

		if (options.length <= 0) {
			alert("You have not defined any IP addresses to ping.");
			return;
		}
		for (i=0; i<options.length; i++) {
			ips += options[i].value + ":";
		}
		document.location = "doPings.php?IPs=" + ips;
	}

// Remove the selected IP
	function removeIP() 
	{
		var index = ping.ips.selectedIndex;
		if (index < 0)  return;
		ping.ips.options[index] = null;
	}
	
// Clear the IP List
	function clearIPs()
	{
		for (i=ping.ips.options.length-1; i>=0; i--)
			ping.ips.options[i] = null;
	}
</SCRIPT>
</HEAD>
<BODY>

<FORM Name=ping OnSubmit='return false;'>
<TABLE Align=Center Style="border:1pt solid black;">
	<TR><TH BgColor="wheat" Colspan=3 Style="border:1pt solid black;">Ping Test - IP Select</TH></TR>
	<TR>
		<TD Align=Right><B>IP Address:</B></TD>
		<TD><INPUT Name=ip_address Type=text Class=text MaxLength=15 Size=15></TD>
		<TD Width=75><INPUT Type=submit Name=addButton Class=button Value='Add' OnClick="addIP();"></TD>
	</TR>
	<TR>
		<TD Align=Right><B>Interval:</B></TD>
		<TD NOWRAP><INPUT Name=ip_start Type=text Class=text MaxLength=15 Size=15> <B>=&gt;</B> <INPUT Name=ip_end Type=text Class=text MaxLength=3 Size=3></TD>
		<TD><INPUT Type=submit Name=addButton Class=button Value='Add All' OnClick="addAll();"></TD>
	</TR>
	<TR>
		<TD Align=Right VAlign=Top><B>IP List:</B></TD>
		<TD VAlign=Top>
			<SELECT Name=ips Size=10>
				<?	foreach ($ips AS $ip)  print "<OPTION Value='$ip'>$ip</OPTION>"; ?>
			</SELECT>		
		</TD>
		<TD VAlign=Top>
			<INPUT Type=Button Style='width:100%;' Value="Do Pings" OnClick="doPings();"><BR>
			<INPUT Type=button Style='width:100%;' Value="Clear" OnClick="clearIPs();"><BR>
			<INPUT Type=button Style='width:100%;' Value="Remove" OnClick="removeIP();">
		</TD>
	</TR>
</TABLE>
</FORM>

</BODY>
</HTML>

