Title: PHP Pinger
Description: The PHP Pinger is designed as GUI interface for the common network utility, ping. The pinger allows the user to ping any number of servers at once and monitor their performance with a dynamically generated graph (graph supported in IE6 only) and various diagnostic variables.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=760&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
