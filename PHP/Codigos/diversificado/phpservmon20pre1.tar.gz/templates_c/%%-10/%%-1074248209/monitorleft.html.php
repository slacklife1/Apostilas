<?php /* Smarty version 2.6.0-RC2, created on 2003-11-11 12:57:34
         compiled from /home/vluther/websites/phpcult/htdocs/phpservmon/templates//monitorleft.html */ ?>
<tr><td colspan=\"1\"> <?php echo $this->_tpl_vars['server_name']; ?>
 </td> <td> <?php echo $this->_tpl_vars['server_ip']; ?>
 </td> 