<?php /* Smarty version 2.6.0-RC2, created on 2003-11-11 12:59:23
         compiled from /home/vluther/websites/phpcult/htdocs/phpservmon/templates//footer.html */ ?>
</table> 



Code copyright by Vidyut Luther 