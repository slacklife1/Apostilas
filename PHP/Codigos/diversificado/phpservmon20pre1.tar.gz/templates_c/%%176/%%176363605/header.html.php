<?php /* Smarty version 2.6.0-RC2, created on 2003-11-11 12:44:00
         compiled from /home/vluther/websites/phpcult/htdocs/phpservmon//templates/header.html */ ?>
<?php require_once(SMARTY_DIR . 'core' . DIRECTORY_SEPARATOR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'refresh_rate', '/home/vluther/websites/phpcult/htdocs/phpservmon//templates/header.html', 3, false),array('function', 'PHPSELF', '/home/vluther/websites/phpcult/htdocs/phpservmon//templates/header.html', 3, false),)), $this); ?>
<html>
<head>
<META HTTP-EQUIV="refresh" content="<?php echo smarty_function_refresh_rate(array(), $this);?>
;URL=<?php echo smarty_function_PHPSELF(array(), $this);?>
"> 
<title>PHP Service Monitor </title></head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<link rel="stylesheet" href="sysinfo.css" type="text/css">
<table width="100%" border="0" cellspacing="0" cellpadding="2">
<form method="POST">
<tr>
<td width="55%" class="nav" nowrap>
<input type="submit" name="Submit" value="Refresh">
</form>
</td>
</tr>
</table>
<table border="1" cellspacing="1" cellpadding="2" class="tablescheme" align="center" width="100%">
<tr>
<td class="tblhead">Servername</td>
<td class="tblhead">Server IP</td>
<td class="status">HTTP</td>
<td class="status">FTP</td>
<td class="status">SMTP </td>
<td class="status">POP3</td>
</tr>
