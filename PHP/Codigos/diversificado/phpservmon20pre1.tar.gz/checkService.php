<?php
/**
* +----------------------------------------------------------------------+
* | $Workfile: $                                                         | 
* +----------------------------------------------------------------------+
* | $Revision: 1.3 $ (PHP 4)                                                 |
* +----------------------------------------------------------------------+
* | Copyright (c) 2002-2003 Linuxpowered, Inc                            |
* +----------------------------------------------------------------------+
* | Author: Vidyut Luther <vid@linuxpowered.com>                         |
* +----------------------------------------------------------------------+
* 
* $Header: /home/repository/phpservmon/checkService.php,v 1.3 2003/11/11 20:21:36 admin Exp $
**/
error_reporting(1);
function checkService($serverip,$port)  {
	$servicename = getservbyport($port,"tcp") ; 
	$fp = fsockopen ("$serverip", $port, $errno, $errstr, 1);
        if(!$fp) {
                $status = "Down";
                $downport = $serverip . ":" . $port ; 
                if(in_array($downport,$_SESSION['downport'])) {
                    AlertAdmin($serverip,$port) ;  
                } else { 
                    $timedown = time(); 
                    $_SESSION['downport'][$downport] = $downport ;             
                    $_SESSION[$downport][timedown] = $timedown ; 

                }

        } else {
                $status = "Up";
                $upport = $serverip . ":" . $port ; 
                if(in_array($upport,$_SESSION['downport'])) {
                    echo "$upport  is now UP  ";
                    $_SESSION['downport'][$upport] = NULL ; 
                } 

                
        }
        return $status; 
	fclose($fp); 
}

function byteToHuman($bytes) {

                if ($bytes >= 1073741824) { #Gigabytes
                        $file_size = round($bytes / 1073741824 * 100) / 100 . "Gb";
                } elseif ($bytes >= 1048576) { # Megabytes
                        $file_size = round($bytes / 1048576 * 100) / 100 . "MB";
                } elseif ($bytes >= 1024) { # Kilo Bytes
                        $file_size = round($bytes / 1024 * 100) / 100 . "Kb";
                } else { # bytes
                        $filesize = $bytes . "B";
                }

                return $file_size;
}



function AlertAdmin($serverip,$port) 
{

    global $admin_email ; 
   
    mail("$admin_email", "$serverip PORT $port is DOWN", "The System is Down!!!!!");
    
    


}

?>
