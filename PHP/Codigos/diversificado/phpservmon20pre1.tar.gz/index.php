<?php
/**
* +----------------------------------------------------------------------+
* | $Workfile: $                                                         | 
* +----------------------------------------------------------------------+
* | $Revision: 1.3 $ (PHP 4)                                                 |
* +----------------------------------------------------------------------+
* | Copyright (c) 2002-2003 Linuxpowered, Inc                            |
* +----------------------------------------------------------------------+
* | Author: Vidyut Luther <vid@linuxpowered.com>                         |
* +----------------------------------------------------------------------+
* 
* $Header: /home/repository/phpservmon/index.php,v 1.3 2003/11/11 20:17:33 admin Exp $
**/

require_once("./config.inc");
require_once("./checkService.php");

session_start() ; 
$tpl->assign("PHPSELF",$PHPSELF) ; 
$tpl->assign("refresh_rate",$refresh_rate) ; 


$tpl->display(TEMPLATE_PATH."/header.html") ;


foreach($server as $server_name=>$server_ip)  {
    $tpl->assign("server_name",$server_name) ; 
    $tpl->assign("server_ip",$server_ip)  ;  
    $tpl->display(TEMPLATE_PATH."/monitorleft.html") ; 
    foreach($port as $port_name=>$port_value)  {
      $status=checkService($server_ip,$port_value);
      if($status=="Up")  {
      	echo <<<TERMHTML
			<td class="image"><img src="images/green.gif" alt="Up"></td>
TERMHTML;
		
		}
      else  {
      	echo <<<TERMHTML
			<td class="image"><img src="images/red.gif" alt="Down"></td>
TERMHTML;
   	}
}  
echo "</tr>";
} 


$tpl->display(TEMPLATE_PATH."/footer.html") ; 
?>
