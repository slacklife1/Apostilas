<?
	include("cfg.php");
	include("functions.php");
	include("db.php");
	session_start();
?>
<html>
<head>
  <title>phpMyAds</title>
  <meta name="description" content="">
  <meta name="keywords" content="">
  <style type="text/css">
  <!--
       A:link {text-decoration: none;}
       A:visited {text-decoration: none;}
	   A:hover {text-decoration: underline;}
  -->
  </style>
</head>
<body bgcolor="#2E425A" text="#FFFFFF" link="#C0C0C0" vlink="#969696" topmargin="0" leftmargin="0" rightmargin="0">
<table bgcolor="#2E425A" border="1" bordercolor="#000000" width="100%" style="BORDER-COLLAPSE: collapse" cellpadding="0" cellspacing="0" align="center">
<tr>
	<td width="100%" height="25"><a href="javascript:close();">Click here</a> to close this window. It is an ad preview window.</td>
</tr>
</table>
<br><br>
<?
	include("cfg.php");
	$conn = db_connect();
	$sql = "select * from ads where id='$id'";
	$result = mysql_query($sql, $conn);
	if(!$result)
	{
		echo "Unable to get ad information";
		exit;
	}
	while($row = mysql_fetch_array($result)) {
	$type = stripslashes($row["type"]);
	$text = stripslashes($row["text"]);
	$url = stripslashes($row["url"]);
	$target = stripslashes($row["target"]);
	$bar = stripslashes($row["bar"]);
	$cpc = stripslashes($row["cpc"]);
	$zone = stripslashes($row["zone"]);
	if($type == "img")
	{
		$width = stripslashes($row["bwidth"]);
		$height = stripslashes($row["bheight"]);
		$img = stripslashes($row["imgurl"]);
	}
	if($bar == "yes")
	{
		$conn = db_connect();
	$sql = "select * from zones where name='$zone'";
	$result = mysql_query($sql, $conn);
	while($row = mysql_fetch_array($result)) {
	$barurl = stripslashes($row["barurl"]);
	}
	}
	if(!$result)
	{
		echo "Unable to get bar information";
		exit;
	}
	}
		if($bar == "yes")
		{
		echo "<a href='click.php?bar=$barurl&url=$url&cpc=$cpc&title=$text&zone=$zone' target='$target'>";
		}
		else
		{
		echo "<a href='click.php?url=$url&cpc=$cpc&title=$text&zone=$zone' target='$target'>";
		}
		if($type == "img")
		{
		echo "<img src='$img' border='0' alt='$text' width='$width' height='$height'><br>$text";
		}
		else
		{
		echo "$text";
		}
		echo "</a>";
?>
</body>
</html>

