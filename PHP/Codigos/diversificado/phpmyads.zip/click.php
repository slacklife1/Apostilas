<html>
<head>
<title><?=$title?></title>
<? if(!$bar) { echo "<meta http-equiv='refresh' content='0; url=$url'>"; } ?>
<? if($bar) { echo "<meta http-equiv='refresh' content='0; url=bar.php?url=$url&title=$title&bar=$bar'>"; } ?>
</head>
<?
include("functions.php");
$conn = db_connect();
$sql = "select * from stats where zone='$zone'";
$result = mysql_query($sql, $conn);
if(!$result)
{
	echo "Unable to count clicks.";
}
while($row = mysql_fetch_array($result)) {
$revenue = stripslashes($row["revenue"]);
$clicks = stripslashes($row["clicks"]);
}
$revenue = $revenue + $cpc;
$clicks = $clicks + 1;
$now = date("Y-m-d H:i:s");
$sql = "update stats set clicks='$clicks', lastclick='$now', revenue='$revenue' where zone='$zone'";
$result = mysql_query($sql, $conn);
if(!$result)
{
	echo "Unable to count clicks.";
}
?>
</html>
