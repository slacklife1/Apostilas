<? include("head.php"); ?>
<table bgcolor="#2E425A" border="1" bordercolor="#000000" width="95%" style="BORDER-COLLAPSE: collapse" cellpadding="0" cellspacing="0" align="center">
<tr>
	<td width="17%" bgcolor="#2E425A"><center><a href="add.php">Add Ads</a></center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="cp.php">Home/Stats</a></center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="edit.php">Edit Ads</a></center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="view.php">View Ads</a></center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="zones.php">Add Website</a></center></td>
	<td width="17%" bgcolor="#000000"><center>Edit/Remove</center></td>
</tr>
<tr>
	<td width="100%" colspan="6">
	<table width="100%" bgcolor="#2E425A" align="center" border="1" cellpadding="2" cellspacing="0" style="BORDER-COLLAPSE: collapse" bordercolor="#000000">
	<tr bgcolor="#000000" height="25">
		<td width="100%" colspan="2"><h3>Edit/Remove:</td></h3>
	</tr>
	<? if(!$mode) { ?>
	<tr>
		<td width="35%" valign="top"><b>Select Action:</b></td>
		<td width="65%" valign="top"><ul style="list-style-type:disc;">
		<li><a href="eddel.php?mode=delete">Delete Website</a></li>
		<li><a href="eddel.php?mode=edit">Edit Website</a></li>
		<li><a href="eddel.php?mode=ad">Delete Ad</a></li>
		</td>
	</tr>
	<? } if($mode == "delete") { if(!$id) { ?>
	<form action="<? $PHP_SELF ?>" method="POST">
	<tr>
		<td width="35%" valign="top"><b>Select Website:</b></td>
		<td width="65%" valign="top"><ul style="list-style-type:none;">
		<?
		$conn = db_connect();
		$sql = "select * from zones";
		$result = mysql_query($sql, $conn);
		while($row = mysql_fetch_array($result)) {
		$id = stripslashes($row["id"]);
		$zone = stripslashes($row["name"]);
		?>
		<li><? echo "<input type='radio' name='id' value='$id'>$zone"; ?></li>
		<?
		}
		?>
		</td>
	</tr>
	<tr>
		<td width="100%" align="center" colspan="2"><input type="submit" name="submit" value="Delete Website"></td>
	</tr>
	</form>
	<? } else { 
	echo "<tr><td colspan='2'>Deleting website...</td></tr>";
	$conn = db_connect();
	$sql = "select * from zones where id='$id'";
	$result = mysql_query($sql, $conn);
	while($row = mysql_fetch_array($result)) {
	$zone = stripslashes($row["name"]);
	}
	$sql = "delete from zones where id='$id'";
	$result = mysql_query($sql, $conn);
	if(!$result)
	{
		echo "<tr><td colspan='2'><b>Unable to delete website.</b></td></tr>";
	}
	else
	{
		echo "<tr><td colspan='2'>Deleted website successfully.</td></tr>";
	}
	$sql = "delete from stats where zone='$zone'";
	$result = mysql_query($sql, $conn);
	if(!$result)
	{
		echo "<tr><td colspan='2'><b>Unable to delete website from stats table.</td></tr>";
	}
	}
	}
	else { if($mode == "edit") { if(!$id) { ?>
	<tr>
		<td width="35%" valign="top"><b>Select Website:</b></td>
		<td width="65%" valign="top"><ul style="list-style-type:disc;">
		<?
		$conn = db_connect();
		$sql = "select * from zones";
		$result = mysql_query($sql, $conn);
		while($row = mysql_fetch_array($result)) {
		$id = stripslashes($row["id"]);
		$zone = stripslashes($row["name"]);
		?>
		<li><? echo "<a href='eddel.php?mode=edit&id=$id'>$zone</a>"; ?></li>
		<?
		}
		?>
		</td>
	</tr>
	<? } else {
	if(!$submit) {
	$conn = db_connect();
	$sql = "select * from zones where id='$id'";
	$result = mysql_query($sql, $conn);
	if(!$result)
	{
		echo "<tr><td colspan='2'>Unable to get website information.</td></tr>";
	}
	while($row = mysql_fetch_array($result)) {
	$id = stripslashes($row["id"]);
	$name = stripslashes($row["name"]);
	$rand = stripslashes($row["random"]);
	$barurl = stripslashes($row["barurl"]);
	}
	echo "<input type='hidden' name='id' value='$id'>";
	?>
	<form action="<? $PHP_SELF ?>" method="POST">
	<tr>
		<td width="35%"><b>Website Name:</b></td>
		<td width="65%"><? echo $name; ?></td>
	</tr>
	<tr>
		<td width="35%"><b>Head Bar URL:</b></td>
		<td width="65%"><input type="text" name="barurl" value="<? echo $barurl; ?>" maxlength="255" size="25"></td>
	</tr>
	<tr>
		<td width="100%" colspan="2"><center><input type="submit" name="submit" value="Edit Website"></center></td>
	</tr>
	</form>
	<? } else { 
	$conn = db_connect();
	$sql = "update zones set random='$rand', barurl='$barurl' where id='$id'";
	$result = mysql_query($sql, $conn);
	if(!$result)
	{
		echo "<tr><td colspan='2'><b>Unable to edit website details.</b></td></tr>";
	}
	else
	{
		echo "<tr><td colspan='2'>Website updated successfully.</td></tr>".mysql_error();
	}
	} } } if($mode == "ad") { if(!$zone) { ?>
	<form action="<? $PHP_SELF ?>" method="POST">
	<tr>
		<td width="35%" valign="top"><b>Select Website:</b></td>
		<td width="65%" valign="top"><ul style="list-style-type:disc;">
		<?
		$conn = db_connect();
		$sql = "select * from zones";
		$result = mysql_query($sql, $conn);
		while($row = mysql_fetch_array($result)) {
		$id = stripslashes($row["id"]);
		$zone = stripslashes($row["name"]);
		?>
		<li><? echo "<a href='eddel.php?mode=ad&zone=$zone&type=del'>$zone</a>"; ?></li>
		<?
		}
		?>
		</td>
	</tr>
	<? } elseif($type == "del") { ?>
	<form action="eddel.php?mode=ad&zone=<? echo $zone; ?>&type=rem" method="POST">
	<tr>
		<td width="35%" valign="top"><b>Select Ad:</b></td>
		<td width="65%" valign="top"><ul style="list-style-type:none;">
		<?
		$conn = db_connect();
		$sql = "select * from ads where zone='$zone'";
		$result = mysql_query($sql, $conn);
		while($row = mysql_fetch_array($result)) {
		$id = stripslashes($row["id"]);
		$ad = stripslashes($row["name"]);
		?>
		<li><? echo "<input type='radio' value='$id' name='id'>$ad</a>"; ?></li>
		<?
		}
		?>
		</td>
	</tr>
	<tr>
		<td width="100%" colspan="2"><center><input type="submit" name="submit" value="Delete Ad"></td>
	</tr>
	<? } elseif($type == "rem") {
	echo "<tr><td colspan='2'>Deleting ad...</td></tr>";
	$conn = db_connect();
	$sql = "delete from ads where id='$id'";
	$result = mysql_query($sql, $conn);
	if(!$result)
	{
		echo "<tr><td colspan='2'><b>Unable to delete ad.</b></td></tr>";
	}
	else
	{
		echo "<tr><td colspan='2'>Deleted ad successfully.</td></tr>";
	}
	} } } ?>
	</table>
	</td>
</tr>
<tr>
	<td width="100%" colspan="6"><div align="right"><font size="2"><a href="javascript:history.back(-1);">Back</a> | <a href="logout.php">Log Out</a></div></font></td></tr>
</table>
<br><div align="right"><font size="1">phpMyAds Copyright&copy; <a href="http://php.melchior.us">WiredPHP</a> 2002</font></div>
</body>
</html>

</body>
</html>

