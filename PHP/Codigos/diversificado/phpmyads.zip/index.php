<html>
<head>
  <title>phpMyAds</title>
  <meta name="description" content="">
  <meta name="keywords" content="">
  <style type="text/css">
  <!--
       A:link {text-decoration: none;}
       A:visited {text-decoration: none;}
  -->
  </style>
</head>
<body bgcolor="#2E425A" text="#FFFFFF" link="#C0C0C0" vlink="#969696">
<table bgcolor="#2E425A" border="1" bordercolor="#000000" width="95%" style="BORDER-COLLAPSE: collapse" cellpadding="2" cellspacing="0" align="center">
<?
	@ $file = readfile("cfg.php");
	if(!$file)
	{
?>
<tr>
	<td width="100%" bgcolor="#000000" colspan="2"><h3>phpMyAds Installation:</td>
</tr>
<form action="install.php?step=2" method="POST">
<tr>
	<td width="35%"><b>Your Name:</b></td>
	<td width="65%"><input type="text" name="name" value="" maxlength="255" size="35"></td>
</tr>
</form>
<?
}
else
{
?>
<tr border="0">
	<td width="100%" colspan="2"><img src="images/admin.gif" width="88" height="31" alt="" border="0"></td>
</tr>
<form action="cp.php" method="POST">
<tr>
	<td width="35%"><b>Admin Username:</b></td>
	<td width="65%"><input type="text" name="user" value="" size="35" maxlength="255"></td>
</tr>
<tr>
	<td width="35%"><b>Admin Password:</b></td>
	<td width="65%"><input type="password" name="psswd" value="" size="35" maxlength="16"></td>
</tr>
<tr>
	<td width="100%" colspan="2"><center><input type="submit" name="submit" value="Enter Admin"></center></td>
</tr>
</form>
<?
}
?>
</table>
</body>
</html>

