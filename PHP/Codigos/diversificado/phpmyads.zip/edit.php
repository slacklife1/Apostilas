<? include("head.php"); ?>
<table bgcolor="#2E425A" border="1" bordercolor="#000000" width="95%" style="BORDER-COLLAPSE: collapse" cellpadding="0" cellspacing="0" align="center">
<tr>
	<td width="17%" bgcolor="#2E425A"><center><a href="add.php">Add Ads</a></center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="cp.php">Home/Stats</a></center></td>
	<td width="17%" bgcolor="#000000"><center>Edit Ads</center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="view.php">View Ads</a></center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="zones.php">Add Website</a></center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="eddel.php">Edit/Remove</a></center></td>
</tr>
<tr>
	<td width="100%" colspan="6">
	<table width="100%" bgcolor="#2E425A" align="center" border="1" cellpadding="2" cellspacing="0" style="BORDER-COLLAPSE: collapse" bordercolor="#000000">
	<tr bgcolor="#000000" height="25">
		<td width="100%" colspan="2"><h3>Edit Ads:</td></h3>
	</tr>
	<? if(!$id) { ?>
	<tr>
		<td width="35%" valign="top"><b>Select Website:</b></td>
		<td width="65%" valign="top"><ul style="list-style-type:disc">
		<?
		$conn = db_connect();
		$sql = "select * from zones";
		$result = mysql_query($sql, $conn);
		while($row = mysql_fetch_array($result)) {
		$id = stripslashes($row["id"]);
		$zone = stripslashes($row["name"]);
		?>
		<li><? echo "<a href='edit.php?id=$id&type=select&zone=$zone'>$zone</a>"; ?></li>
		<?
		}
		?>
		</td>
	</tr>
	<? } elseif($type == "select") { ?>
	<tr>
		<td width="35%" valign="top"><b>Select Ad:</b></td>
		<td width="65%" valign="top"><ul style="list-style-type:disc">
		<?
		$conn = db_connect();
		$sql = "select * from ads where zone='$zone'";
		$result = mysql_query($sql, $conn);
		while($row = mysql_fetch_array($result)) {
		$id = stripslashes($row["id"]);
		$ad = stripslashes($row["name"]);
		?>
		<li><? echo "<a href='edit.php?id=$id&type=edit'>$ad</a>"; ?></li>
		<?
		}
		?>
		</td>
	</tr>
	<? } elseif($type == "edit") { 
	$conn = db_connect();
	$sql = "select * from ads where id=$id";
	$result = mysql_query($sql, $conn);
	while($row = mysql_fetch_array($result)) {
	$type = stripslashes($row["type"]);
	$ad = stripslashes($row["name"]);
	$imgurl = stripslashes($row["imgurl"]);
	$bwidth = stripslashes($row["bwidth"]);
	$bheight = stripslashes($row["bheight"]);
	$text = stripslashes($row["text"]);
	$url = stripslashes($row["url"]);
	$target = stripslashes($row["target"]);
	$bar = stripslashes($row["bar"]);
	$cpc = stripslashes($row["cpc"]);
	?>
	<? echo "<form action='edit.php?id=$id&type=update' method='POST'>"; ?>
	<tr>
		<td width="35%"><b>Ad Type:</b></td>
		<td width="65%"><? if($type == "img") { echo "Banner Image"; } else { echo "Text Link"; } ?></td>
	</tr>
	<tr>
		<td width="35%"><b>Ad Name:</b></td>
		<td width="65%"><input type="text" name="name" value="<? echo $ad; ?>" size="25" maxlength="255"></td>
	</tr>
	<? if($type == "img") { ?>
	<tr>
		<td width="35%"><b>Image URL:</b></td>
		<td width="65%"><input type="text" name="imgurl" value="<? echo $imgurl; ?>" size="25" maxlength="255"></td>
	</tr>
	<tr>
		<td width="35%"><b>Banner Width:</b></td>
		<td width="65%"><input type="text" name="bwidth" value="<? echo $bwidth; ?>" size="4" maxlength="3"></td>
	</tr>
	<tr>
		<td width="35%"><b>Banner Height:</b></td>
		<td width="65%"><input type="text" name="bheight" value="<? echo $bheight; ?>" size="4" maxlength="3"></td>
	</tr>
	<? } ?>
	<tr>
		<td width="35%"><b>Caption/Link Text:</b></td>
		<td width="65%"><input type="text" name="text" value="<? echo $text; ?>" size="25" maxlength="255"></td>
	</tr>
	<tr>
		<td width="35%"><b>Link URL:</b></td>
		<td width="65%"><input type="text" name="url" value="<? echo $url; ?>" size="25" maxlength="255"></td>
	</tr>
	<tr>
		<td width="35%"><b>Target:</b></td>
		<td width="65%"><input type="text" name="target" value="<? echo $target; ?>" size="25" maxlength="255"></td>
	</tr>
	<tr>
		<td width="35%"><b>Include Head Bar?</b></td>
		<td width="65%"><? if($bar == "yes") { echo "<input type='radio' name='bar' value='yes' checked>Yes <input type='radio' name='bar' value='no'>No"; } else { echo "<input type='radio' name='bar' value='yes'>Yes <input type='radio' name='bar' value='no' checked>No"; } ?></td>
	</tr>
	<tr>
		<td width="35%"><b>Commision per Click:</b><br><font size="2">(Leave blank if none -- Use US dollars)</font></td>
		<td width="65%">$<input type="text" name="cpc" value="<? echo $cpc; ?>" size="10" maxlength="255"></td>
	</tr>
	<tr>
		<td width="100%" colspan="2"><center><input type="submit" name="update" value="Update"></center></td>
	</tr>
	<? } } elseif($type == "update") { ?>
	<tr>
		<td width="100%" colspan="2">Updating information...</td>
	</tr>
	<?
	$conn = db_connect();
	$sql = "update ads set imgurl='$imgurl', name='$name', bwidth='$bwidth', bheight='$bheight', text='$text', url='$url', target='$target', bar='$bar', cpc='$cpc' where id=$id";
	$result = mysql_query($sql, $conn);
	if(!$result)
	{
		echo "<tr><td colspan='2'><b>Information not updated!</b></td></tr>";
	}
	else
	{
		echo "<tr><td colspan='2'>Information updated successfully</td></tr>";
	}
	} ?>
	</table>
	</td>
</tr>
<tr>
	<td width="100%" colspan="6"><div align="right"><font size="2"><a href="javascript:history.back(-1);">Back</a> | <a href="logout.php">Log Out</a></div></font></td></tr>
</table>
<br><div align="right"><font size="1">phpMyAds Copyright&copy; <a href="http://php.melchior.us">WiredPHP</a> 2002</font></div>
</body>
</html>
