<?

//DO NOT EDIT THE FOLLOWING

$adminuser = "demo";
$adminpswd = "demo";
$adminname = "Stephen Craton";
$url = "http://localhost/phpmyads";
$background = "#2E425A";
$link = "#C0C0C0";


?>