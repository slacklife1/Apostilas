<?
	include("cfg.php");
	include("functions.php");
	include("db.php");
	session_start();
?>
<html>
<head>
  <title>phpMyAds</title>
  <meta name="description" content="">
  <meta name="keywords" content="">
  <style type="text/css">
  <!--
       A:link {text-decoration: none;}
       A:visited {text-decoration: none;}
	   A:hover {text-decoration: underline;}
  -->
  </style>
</head>
<body bgcolor="#2E425A" text="#FFFFFF" link="#C0C0C0" vlink="#969696" topmargin="0" leftmargin="0" rightmargin="0">
<table width="100%" height="44" border="0" bgcolor="#2E425A" cellpadding="0" cellspacing="0" align="center">
<tr>
	<td width="160" height="44"><a href="cp.php"><img src="images/logo.gif" width="160" height="44" alt="phpMyAds" border="0"></a></td>
	<td width="100%" height="44" valign="top" align="right">
<?
	if($user && $psswd)
	{
		if(login($user, $psswd))
		{
			$valid = $user;
			session_register("valid");
		}
		else
		{
			echo "You have not been logged in or you are not authorized to view th admin page.<br>";
			echo "<a href='index.php'>Login</a>";
			exit;
		}
	}
	check_valid();
?>
	</td>
</tr>
</table><br>