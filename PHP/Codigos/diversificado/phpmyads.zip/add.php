<? include("head.php"); ?>
<table bgcolor="#2E425A" border="1" bordercolor="#000000" width="95%" style="BORDER-COLLAPSE: collapse" cellpadding="0" cellspacing="0" align="center">
<tr>
	<td width="17%" bgcolor="#000000"><center>Add Ads</center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="cp.php">Home/Stats</a></center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="edit.php">Edit Ads</a></center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="view.php">View Ads</a></center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="zones.php">Add Website</a></center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="eddel.php">Edit/Remove</a></center></td>
</tr>
<tr>
	<td width="100%" colspan="6">
	<table width="100%" bgcolor="#2E425A" align="center" border="1" cellpadding="2" cellspacing="0" style="BORDER-COLLAPSE: collapse" bordercolor="#000000">
	<tr bgcolor="#000000" height="25">
		<td width="100%" colspan="5"><h3>Add Ads:</td></h3>
	</tr>
	<? if(!$id) { ?>
	<tr>
		<td width="35%" valign="top"><b>Select a Website:</b></td>
		<td width="65%" valign="top"><ul style="list-style-type:disc">
		<?
		$conn = db_connect();
		$sql = "select * from zones";
		$result = mysql_query($sql, $conn);
		while($row = mysql_fetch_array($result)) {
		$id = stripslashes($row["id"]);
		$zone = stripslashes($row["name"]);
		?>
		<li><? echo "<a href='add.php?id=$id&part=1'>$zone</a>"; ?></li>
		<?
		}
		?>
		</td>
	</tr>
	<? } elseif($id && $part == "1") { ?>
	<? echo "<input type='hidden' name='id' value='$id'>"; 
	echo "<form action='add.php?part=2&id=$id' method='POST'>"; ?>
	<tr>
		<td width="35%"><b>Ad Type:</b></td>
		<td width="65%"><input type="radio" name="type" value="img">Banner Image <input type="radio" name="type" value="href">Text Link</td>
	</tr>
	<tr>
		<td width="35%"><b>Ad Name:</b></td>
		<td width="65%"><input type="text" name="name" value="" size="25" maxlength="255"></td>
	</tr>
	<tr>
		<td width="100%" colspan="2"><center><input type="submit" name="add2" value="Next >"></center></td>
	</tr>
	</form>
	<? } if($part == "2") {
	echo "<form action='add.php?part=3&id=$id' method='POST'>";
	echo "<input type='hidden' name='type' value='$type'>";
	echo "<input type='hidden' name='name' value='$name'>";
	echo "<input type='hidden' name='id' value='$id'>";
	if($type == "img") {
	?>
	<tr>
		<td width="35%"><b>Image URL:</b></td>
		<td width="65%"><input type="text" name="imgurl" value="http://" size="25" maxlength="255"></td>
	</tr>
	<tr>
		<td width="35%"><b>Banner Width:</b></td>
		<td width="65%"><input type="text" name="bwidth" value="" size="4" maxlength="3"></td>
	</tr>
	<tr>
		<td width="35%"><b>Banner Height:</b></td>
		<td width="65%"><input type="text" name="bheight" value="" size="4" maxlength="3"></td>
	</tr>
	<?
	}
	?>
	<tr>
		<td width="35%"><b>Caption/Link Text:</b></td>
		<td width="65%"><input type="text" name="text" value="" size="25" maxlength="255"></td>
	</tr>
	<tr>
		<td width="35%"><b>Link URL:</b></td>
		<td width="65%"><input type="text" name="link" value="" size="25" maxlength="255"></td>
	</tr>
	<tr>
		<td width="100%" colspan="2"><center><input type="submit" name="add3" value="Next >"></center></td>
	</tr>
	<?
	}
	elseif($part == "3") {
	echo "<form action='add.php?part=4&id=$id' method='POST'>";
	echo "<input type='hidden' name='type' value='$type'>";
	echo "<input type='hidden' name='name' value='$name'>";
	echo "<input type='hidden' name='text' value='$text'>";
	echo "<input type='hidden' name='link' value='$link'>";
	if($type == "img"){
	echo "<input type='hidden' name='imgurl' value='$imgurl'>";
	echo "<input type='hidden' name='bheight' value='$bheight'>";
	echo "<input type='hidden' name='bwidth' value='$bwidth'>";
	}
	echo "<form action='add.php?part=5&id=$id' method='POST'>";
	?>
	<tr>
		<td width="35%"><b>Open In:</b><br><font size="2">(Target for link)</font></td>
		<td width="65%"><input type="radio" name="target" value="_blank">New Window <input type="radio" name="target" value="_top">Top Frame <input type="radio" name="target" value="other">Other: <input type="text" name="other2" value="" size="10"></td>
	</tr>
	<tr>
		<td width="35%"><b>Include Head Bar?</b></td>
		<td width="65%"><input type="radio" name="bar" value="yes">Yes <input type="radio" name="bar" value="no">No</td>
	</tr>
	<tr>
		<td width="35%"><b>Commision per Click:</b><br><font size="2">(Leave blank if none -- Use US dollars)</font></td>
		<td width="65%">$<input type="text" name="cpc" value="" size="10" maxlength="255"></td>
	</tr>
	<tr>
		<td width="100%" colspan="2"><center><input type="submit" name="add4" value="Next >"></center></td>
	</tr>
	<?
	}
		elseif($part == "4") {
		if($target == "other") {
		$target = $other2;
			if(empty($other2))
			{
				echo "<tr><td colspan='2'><b>You did not enter all the information needed for the 'Open In' field of this form.<a href='javascript:history.back(-1)'>Go Back</a> and try again.</td></tr>";
				exit;
			}
		}
	?>
	<tr>
		<td width="100%" colspan="2">Inserting information into database...</td>
	</tr>
	<?
	$conn = db_connect();
	$sql = "select * from zones where id=$id";
	$result = mysql_query($sql, $conn);
	if(!$result)
	{
		echo "<tr><td colspan='2'>Unable to get website name!</td></tr>";
		exit;
	}
	while($row = mysql_fetch_array($result)) {
	$zone = stripslashes($row["name"]); 
	$barurl = stripslashes($row["barurl"]);
	$num = stripslashes($row["numads"]);
	$num = $num + 1;
	}
	$sql = "insert into ads values ('', '$imgurl', '$zone', '$type', '$name', '$bwidth', '$bheight', '$text', '$link', '$target', '$bar', '$cpc', '$barurl')";
	$result = mysql_query($sql, $conn);
	if(!$result)
	{
		echo "<tr><td colspan='2'><b>Unable to add information to database!</b></td></tr>";
	}
	else
	{
		echo "<tr><td colspan='2'><b>Information stored and your ad has been entered!</b></td></tr>";
	}
	$sql = "update zones set numads='$num' where id=$id";
	$result = mysql_query($sql, $conn);
	if(!$result)
	{
		echo "<tr><td colspan='2'><b>Number of ads not updated.</b></td></tr>";
	}
	}
	?>
	</table>
	</td>
</tr>
<tr>
	<td width="100%" colspan="6"><div align="right"><font size="2"><a href="javascript:history.back(-1);">Back</a> | <a href="logout.php">Log Out</a></div></font></td></tr>
</table>
<br><div align="right"><font size="1">phpMyAds Copyright&copy; <a href="http://php.melchior.us">WiredPHP</a> 2002</font></div>
</body>
</html>
