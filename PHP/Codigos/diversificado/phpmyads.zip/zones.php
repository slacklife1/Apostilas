<? include("head.php"); ?>
<table bgcolor="#2E425A" border="1" bordercolor="#000000" width="95%" style="BORDER-COLLAPSE: collapse" cellpadding="0" cellspacing="0" align="center">
<tr>
	<td width="17%" bgcolor="#2E425A"><center><a href="add.php">Add Ads</a></center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="cp.php">Home/Stats</a></center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="edit.php">Edit Ads</a></center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="view.php">View Ads</a></center></td>
	<td width="17%" bgcolor="#000000"><center>Add Website</center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="eddel.php">Edit/Remove</a></center></td>
</tr>
<tr>
	<td width="100%" colspan="6">
	<table width="100%" bgcolor="#2E425A" align="center" border="1" cellpadding="2" cellspacing="0" style="BORDER-COLLAPSE: collapse" bordercolor="#000000">
	<tr bgcolor="#000000" height="25">
		<td width="100%" colspan="2"><h3>Add Website:</td></h3>
	</tr>
	<? if(!$submit) { ?>
	<form action="<? $PHP_SELF ?>" method="POST">
	<tr>
		<td width="35%"><b>Website Name:</b></td>
		<td width="65%"><input type="name" name="name" value="" maxlength="255" size="25"></td>
	</tr>
	<tr>
		<td width="35%"><b>Head Bar URL:</b><br><font size="2">(Must be in bars folder)</font></td>
		<td width="65%"><input type="text" name="barurl" value="bars/" maxlength="255" size="25"></td>
	</tr>
	<tr>
		<td width="100%" colspan="2"><center><input type="submit" name="submit" value="Add Website"></center></td>
	</tr>
	</form>
	<? } else { 
	echo "<tr><td colspan='2'>Adding website into database...</td></tr>";
	$conn = db_connect();
	$sql = "insert into zones values ('', '$name', '', '$barurl', '')";
	$result = mysql_query($sql, $conn);
	if(!$result)
	{
		echo "<tr><td colspan='2'><b>Unable to add website.</b></td></tr>";
	}
	else
	{
		echo "<tr><td colspan='2'>Added website to database successfully!<br>Copy and paste the following on your website where you want the ads for this website to appear:<br><br>&lt;iframe width=\"<i>width here</i>\" height=\"<i>height here</i>\" src=\"$url/ads.php?zone=$name\" name=\"ads\" scrolling=\"no\" frameborder=\"0\" marginwidth=\"0\" marginheight=\"0\"&gt;<br><br>Do not forget to replace <i>width here</i> and <i>height here</i> with the height and width you want.</td></tr>";
	}
	$sql = "insert into stats values ('', '$name', '0', '', '0')";
	$result = mysql_query($sql, $conn);
	if(!$result)
	{
		echo "<tr><td colspan='2'><b>Unable to add website to stats table.</b><br>".mysql_error()."</td></tr>";
	}
	}
	?>
	</table>
	</td>
</tr>
<tr>
	<td width="100%" colspan="6"><div align="right"><font size="2"><a href="javascript:history.back(-1);">Back</a> | <a href="logout.php">Log Out</a></div></font></td></tr>
</table>
<br><div align="right"><font size="1">phpMyAds Copyright&copy; <a href="http://php.melchior.us">WiredPHP</a> 2002</font></div>
</body>
</html>
