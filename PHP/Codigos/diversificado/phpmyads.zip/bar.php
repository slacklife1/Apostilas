<html>
<head>
<title><?=$title?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<frameset rows="44,*" frameborder="NO" border="0" framespacing="0"> 
  <frame name="menu" scrolling="NO" noresize src="<? echo $bar; ?>" frameborder="NO" border="0" framespacing="0" marginwidth="0" marginheight="0" topmargin="0" leftmargin="0">
  <frame name="main" scrolling="AUTO" noresize src="<? echo $url; ?>" frameborder="NO" border="0" framespacing="0" marginwidth="0" marginheight="0" topmargin="0" leftmargin="0">
</frameset>
<noframes>
<body bgcolor="#FFFFFF" text="#000000">
You must support frames to view this ad.
</body>
</noframes> 
</html>
