<?
session_start();
$old_user = $valid;
$result_unreg = session_unregister("valid");
$result_dest = session_destroy();
?>
<html>
<head>
  <title>phpMyAds</title>
  <meta name="description" content="">
  <meta name="keywords" content="">
  <style type="text/css">
  <!--
       A:link {text-decoration: none;}
       A:visited {text-decoration: none;}
	   A:hover {text-decoration: underline;}
  -->
  </style>
</head>
<body bgcolor="#2E425A" text="#FFFFFF" link="#C0C0C0" vlink="#969696" topmargin="0" leftmargin="0" rightmargin="0">
<table width="100%" height="44" border="0" bgcolor="#2E425A" cellpadding="0" cellspacing="0" align="center">
<tr>
	<td width="160" height="44"><a href="cp.php"><img src="images/logo.gif" width="160" height="44" alt="phpMyAds" border="0"></a></td>
	<td width="100%" height="44" valign="top" align="right">
	</td>
</tr>
</table><br>
<table bgcolor="#2E425A" border="1" bordercolor="#000000" width="95%" style="BORDER-COLLAPSE: collapse" cellpadding="0" cellspacing="0" align="center">
<tr>
	<td width="17%" bgcolor="#2E425A"><center><a href="add.php">Add Ads</a></center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="cp.php">Home/Stats</a></center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="edit.php">Edit Ads</a></center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="view.php">View Ads</a></center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="zones.php">Add Website</a></center></td>
	<td width="17%" bgcolor="#2E425A"><center><a href="eddel.php">Edit/Remove</a></center></td>
</tr>
<tr>
	<td width="100%" colspan="6">
	<table width="100%" bgcolor="#2E425A" align="center" border="1" cellpadding="2" cellspacing="0" style="BORDER-COLLAPSE: collapse" bordercolor="#000000">
	<tr bgcolor="#000000" height="25">
		<td width="100%" colspan="5"><h3>Logout:</td></h3>
	</tr>
	<?
	if (!empty($old_user))
	{
  		if ($result_unreg && $result_dest)
  		{
  		    echo "<tr><td colspan='2'>You have been logged out.</td></tr>";
  		}
  		else
  		{
  		  echo "<tr><td colspan='2'><b>You were not logged out.</b></td></tr>";
  		}
	}
	else
	{
  		echo "<tr><td colspan='2'>You were not logged in so you have not been logged out.</td></tr>";
	}
	?>
	</table>
	</td>
</tr>
<tr>
	<td width="100%" colspan="6"><div align="right"><font size="2"><a href="javascript:history.back(-1);">Back</a> | <a href="logout.php">Log Out</a></div></font></td></tr>
</table>
<br><div align="right"><font size="1">phpMyAds Copyright&copy; <a href="http://php.melchior.us">WiredPHP</a> 2002</font></div>
</body>
</html>