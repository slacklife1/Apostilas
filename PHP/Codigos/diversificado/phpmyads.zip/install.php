<html>
<head>
  <title>phpMyAds</title>
  <meta name="description" content="">
  <meta name="keywords" content="">
  <style type="text/css">
  <!--
       A:link {text-decoration: none;}
       A:visited {text-decoration: none;}
	   A:hover {text-decoration: underline;}
  -->
  </style>
</head>
<body bgcolor="#2E425A" text="#FFFFFF" link="#C0C0C0" vlink="#969696" topmargin="0" leftmargin="0" rightmargin="0">
<table width="100%" height="44" border="0" bgcolor="#2E425A" cellpadding="0" cellspacing="0" align="center">
<tr>
	<td width="160" height="44"><a href="cp.php"><img src="images/logo.gif" width="160" height="44" alt="phpMyAds" border="0"></a></td>
</tr>
</table><br>
<table width="90%" border="1" bordercolor="#000000" bgcolor="#2E425A" cellpadding="2" cellspacing="0" align="center" style="BORDER-COLLAPSE: collapse">
<? if(!$submit) { ?>
<form action="<? $PHP_SELF ?>" method="POST">
<tr>
	<td width="35%"><b>Database Host:</b></td>
	<td width="65%"><input type="text" name="dbhost" value="localhost" size="25"></td>
</tr>
<tr>
	<td width="35%"><b>Database Username:</b></td>
	<td width="65%"><input type="text" name="dbuser" value="" size="25"></td>
</tr>
<tr>
	<td width="35%"><b>Database Password:</b></td>
	<td width="65%"><input type="password" name="dbpswd" value="" size="25"></td>
</tr>
<tr>
	<td width="35%"><b>Database Name:</b></td>
	<td width="65%"><input type="text" name="dbname" value="" size="25"></td>
</tr>
<tr>
	<td width="35%"><b>Admin Username:</b></td>
	<td width="65%"><input type="text" name="user" value="" size="25"></td>
</tr>
<tr>
	<td width="35%"><b>Admin Password:</b></td>
	<td width="65%"><input type="password" name="pswd" value="" size="25"></td>
</tr>
<tr>
	<td width="35%"><b>Admin Name:</b></td>
	<td width="65%"><input type="text" name="name" value="" size="25"></td>
</tr>
<tr>
	<td width="35%"><b>Admin Email:</b></td>
	<td width="65%"><input type="text" name="email" value="" size="25"></td>
</tr>
<tr>
	<td width="35%"><b>URL to Script:</b><br><font size="2">(I.E. http://www.yourdomain.com/phpmyads)</font></td>
	<td width="65%"><input type="text" name="url" value="http://" size="25"></td>
</tr>
<tr>
	<td width="35%"><b>Website Background Color:</b></font></td>
	<td width="65%"><input type="text" name="bgcolor" value="#" size="25"></td>
</tr>
<tr>
	<td width="35%"><b>Link Color:</b></font></td>
	<td width="65%"><input type="text" name="link" value="#" size="25"></td>
</tr>
<tr>
	<td colspan="2"><center><input type="submit" name="submit" value="Install phpMyAds"></center></td>
</tr>
</form>
<? } else {
	$line1 = "<?\n\n";
	$line2 = "//DO NOT EDIT THE FOLLOWING\n\n";
	$line3 = "\$adminuser = \"$user\";\n";
	$line4 = "\$adminpswd = \"$pswd\";\n";
	$line5 = "\$adminname = \"$name\";\n";
	$line6 = "\$url = \"$url\";\n";
	$line7 = "\$background = \"$bgcolor\";\n";
	$line8 = "\$link = \"$link\";\n";
	$line9 = "\n\n?>";
	
	$output = $line1.$line2.$line3.$line4.$line5.$line6.$line7.$line8.$line9;
	
	$fp = fopen("cfg.php", "w");
	$install = fwrite($fp, $output);
	
	if(!$install)
	{
		echo "<tr><td colspan='2'><b>Unable to write to cfg.php.</b> CHMOD it to 777 and reinstall this.</td></tr>";
		exit;
	}
	
	$line1 = "<?\nfunction db_connect()\n";
	$line2 = "{\n";
	$line3 = "\$result = mysql_pconnect(\"$dbhost\", \"$dbuser\", \"$dbpswd\");\n";
	$line4 = "if(!\$result)\n";
	$line5 = "return false;\n";
	$line6 = "if(!mysql_select_db(\"$dbname\"))\n";
	$line7 = "return false;\n\n";
	$line8 = "return \$result;\n";
	$line9 = "}\n?>\n";
	
	$output2 = $line1.$line2.$line3.$line4.$line5.$line6.$line7.$line8.$line9;
	
	$fp2 = fopen("db.php", "w");
	$install2 = fwrite($fp2, $output2);
	
	if(!$install2)
	{
		echo "<tr><td colspan='2'><b>Unable to write to db.php.</b> CHMOD it to 777 and reninstall this.</td></tr>";
		exit;
	}
	
	function db_connect($dbhost, $dbuser, $dbpswd, $dbname)
	{
		$result = mysql_pconnect("$dbhost", "$dbuser", "$dbpswd");
		if(!$result)
			return false;
		if(!mysql_select_db("$dbname"))
			return false;
		return $result;
	}
	$conn = db_connect($dbhost, $dbuser, $dbpswd, $dbname);
	$sql = "CREATE TABLE ads ( id int(11) NOT NULL auto_increment, imgurl varchar(255) NOT NULL default '', zone varchar(255) NOT NULL default '', type varchar(4) NOT NULL default '', name varchar(255) NOT NULL default '', bwidth int(3) NOT NULL default '0', bheight int(3) NOT NULL default '0', text varchar(255) NOT NULL default '', url varchar(255) NOT NULL default '', target varchar(255) NOT NULL default '', bar char(3) NOT NULL default '', cpc varchar(255) NOT NULL default '', barurl varchar(255) NOT NULL default '', PRIMARY KEY  (id)) TYPE=MyISAM;";
	$install3 = mysql_query($sql, $conn);
	$sql = "CREATE TABLE stats ( id int(11) NOT NULL auto_increment, zone varchar(255) NOT NULL default '', clicks int(255) NOT NULL default '0', lastclick datetime NOT NULL default '0000-00-00 00:00:00', revenue varchar(255) NOT NULL default '', PRIMARY KEY  (id)) TYPE=MyISAM;";
	$install4 = mysql_query($sql, $conn);
	$sql = "CREATE TABLE zones ( id int(10) NOT NULL auto_increment, name varchar(255) NOT NULL default '0', random char(3) NOT NULL default '0', barurl varchar(255) NOT NULL default '0', numads int(10) NOT NULL default '0', PRIMARY KEY  (id)) TYPE=MyISAM;";
	$install5 = mysql_query($sql, $conn);
	
	if(!$install3 || !$install4 || !$install5)
	{
		echo "<tr><td colspan='2'><b>Unable to create database tables.</b> Check your database information and try again. Also make sure that you do not have any tables named ads, stats, or zones already in your database.</td></tr>";
		exit;
	}
	echo "<tr><td colspan='2'>phpMyAds has been installed. Thank you for choosing a WiredPHP script!</td></tr>";
	$now = date("Y-m-d h:i:s");
	$content = "phpMyAds Instalation has taken place!\n\n Name: ".$name."\n Email: ".$email."\n Date: ".$now."\n URL: ".$url."\n\nWiredPHP Email";
	mail("To: Stephen Craton <webmaster@melchior.us>", "phpMyAds Instalation", $content, "From: $name <$email>");
	}
?>
</table>
</body>
</html>

