<html>
<head>
  <title>phpMyAds</title>
</head>
<body bgcolor="#2E425A" text="#FFFFFF" link="#C0C0C0" vlink="#969696" topmargin="0" leftmargin="0" rightmargin="0">
<table width="100%" height="44" border="0" bgcolor="#2E425A" cellpadding="0" cellspacing="0" align="center">
<tr>
	<td width="160" height="44"><a href="cp.php"><img src="../images/logo.gif" width="160" height="44" alt="phpMyAds" border="0"></a></td>
</tr>
</table>
</body>
</html>