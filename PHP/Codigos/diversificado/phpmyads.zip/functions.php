<?php
	include("cfg.php");
	//DO NOT REMOVE THE FOLLOWING!!
	$copyright = "<a href='http://php.melchior.us/' target='new'><img src='http://www.melchior.us/button2.jpg' width='80' height='31' border='0' alt='phpMyAds Made by WiredPHP'></a>";
	//DO NOT REMOVE THE ABOVE COPYRIGHT!!
	function login($user, $psswd)
	{
		global $adminuser, $adminpswd;
		if($user == "$adminuser" && $psswd == "$adminpswd")
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	function check_valid()
	{
		global $adminname;
		if(session_is_registered("valid"))
		{
			echo "<font size='2'>Administrator $adminname is logged in.</font>";
			echo "<br>";
		}
		else
		{
			echo "<font size='2'>You are not logged in or not an admin. Authorization denied!<br>";
			echo "<a href='index.php'>Click here to login</a></font>";
			exit;
		}
	}
?>
