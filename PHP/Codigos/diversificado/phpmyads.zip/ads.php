<? include("cfg.php"); include("db.php"); ?>
<html><head><meta http-equiv="refresh" content="45;"></head>
<body bgcolor="<?=$background?>" link="<?=$link2?>" vlink="<?=$link2?>">
<center>
<?

if(!$zone)
{
	echo "You must specify a website to display.";
	exit;
}
include("functions.php");
$conn = db_connect();
$sql = "select * from ads where zone='$zone'";
$result = mysql_query($sql, $conn);
if(!$result)
{
	echo "Unable to get ad information";
	exit;
}
while($row = mysql_fetch_array($result)) {
$id = stripslashes($row["id"]);
}
srand ((double) microtime() * 1000000);
$rand = rand(1,$id);
$sql = "select * from ads where id='$rand' and zone='$zone'";
$result = mysql_query($sql, $conn);
if(!$result)
{
	echo "Unable to get ad information";
	exit;
}
while($row = mysql_fetch_array($result)) {
	$type = stripslashes($row["type"]);
	$text = stripslashes($row["text"]);
	$url2 = stripslashes($row["url"]);
	$target = stripslashes($row["target"]);
	$bar = stripslashes($row["bar"]);
	$cpc = stripslashes($row["cpc"]);
	$zone = stripslashes($row["zone"]);
	$id = stripslashes($row["id"]);
	if($type == "img")
	{
		$width = stripslashes($row["bwidth"]);
		$height = stripslashes($row["bheight"]);
		$img = stripslashes($row["imgurl"]);
	}
		if($bar == "yes")
	{
		$barurl = stripslashes($row["barurl"]);
		$part1 = "<a href='click.php?bar=$barurl&url=$url2&cpc=$cpc&title=$text&zone=$zone' target='$target'>";
	}
	else
	{
		$part1 = "<a href='click.php?url=$url2&cpc=$cpc&title=$text&zone=$zone' target='$target'>";
	}
	if($type == "img")
	{
		$part2 = "<img src='$img' border='0' alt='$text' width='$width' height='$height'><br>$text";
	}
	else
	{
		$part2 = "$text";
	}
	$part3 = "</a><br>";
	$adinfo = $part1.$part2.$part3;
}
	if($adinfo == "")
	{
		echo $copyright;
	}
	echo $adinfo;
?>
</body></html>
