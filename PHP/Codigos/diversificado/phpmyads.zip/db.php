<?
function db_connect()
{
$result = mysql_pconnect("localhost", "root", "");
if(!$result)
return false;
if(!mysql_select_db("installtest"))
return false;

return $result;
}
?>
