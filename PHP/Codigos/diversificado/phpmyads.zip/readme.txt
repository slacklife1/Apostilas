					|-----------------|
					|--phpMyAds v1.0--|
					|-----------------|
					    Created By:
					  Stephen Craton

|--FEATURES:--|

-Multiple sites containing multiple and different ads
-Counts total clicks and total revunue (CPC Only)
-All webbased
-Banner and text ads
-Randomizes ads

|--HOW TO INSTALL:--|

1. Unzip all the files
2. Upload all the files (You may delete the FoxServ folder if you wish)
3. CHMOD cfg.php and db.php to 777 (Write and execute all)
4. Open the install.php in your browser from your server and fill out the form
5. After instaltion, go to the base directory and enjoy phpMyAds

|--HOW TO USE:--|

If you are having trouble using phpMyAds, contact me at webmaster@melchior.us.

|--SUPPORT AND WHATNOT:--|

If you need support or have any other problems using phpMyAds or any other WiredPHP script,
contact me at webmaster@melchior.us.

|--COPYRIGHT(c) 2002 WIREDPHP----------------------------------------|
|--DO NOT REMOVE THE COPYRIGHT FROM ANY PART OF ANY WIREDPHP SCRIPT--|
