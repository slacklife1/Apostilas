<?
define("titulo_hp", "Romano Chat");
define("tit_caretas", "Caretas");
define("tit_dados", "Dados Iniciais");
define("tit_salas", "Salas");
define("campo_nome", "Nome");
define("campo_cor", "Cor do Nick");
define("campo_careta", "Careta");
define("campo_pessoas", "Pessoas");
define("cor_preto", "Preto");
define("cor_laranja", "Laranja");
define("cor_azul", "Azul");
define("cor_roxo", "Roxo");
define("cor_verde", "Verde");
define("cor_vermelho", "Vermelho");
define("btn_inserir", "Inserir");
define("btn_entrar", "Entrar");
define("btn_instrucoes", "Instru��es");
define("txt_desenv", "Desenvolvido com:");
define("txt_recomend", "Recomendado usar em Internet Explorer 5.0 e Netscape 6.2 e em uma resolu&ccedil;&atilde;o 800x600");
?>