<?
include "config.php";
?>
<html>
<head>
<title>Romano Chat</title>
<META HTTP-EQUIV="expires" CONTENT="Tue, 20 Aug 1996 4:25:27">
<META HTTP-EQUIV="Cache Control" Content="No-cache">
<link href="romano.css" rel="stylesheet" type="text/css">
<script src="borderize.js"></script>
</head>
<BODY bgColor=#ffffff leftMargin=0 topMargin=0 marginheight="0" marginwidth="0">
<table border="0" width="100%">
  <tr>
	<td align="center"><img src="images/logo_intro.jpg" width="300" height="83"></td>
  </tr>
  <tr> 
	<td width="100%"> <p>Este chat � experimental,qualquer problema ou sugest�o 
		entre contato com o webmaster . 
	  <P><B>O que � sala de Chat ou Bate-Papo?</B> 
	  <P>� uma p�gina de WWW (World Wide Web) onde v�rias pessoas podem "entrar" 
		e conversar trocando mensagens entre si, em tempo real. 
	  <P><B>Preciso de algum programa especial para participar do chat?</B> 
	  <P>Nada de especial, apenas o seu software de navega��o ou browser, como 
		se costuma cham�-lo. Por exemplo: Netscape ou Internet Explorer.
	  <P><b>Por que o Romano Chat � parecido com o Chat Uol?</b>
	  <P>Este � meu segundo projeto de chat em php(o primeiro foi um chat sem 
		banco de dados).<br>
		Neste segundo projeto a inten��o era traduzir um Chat em asp para php(<a href="http://www.freecode.com.br">Super 
		Chat</a>).<br>
		Mas contudo n�o foi poss�vel ,a estrutura era um pouco complicada .<br>
		Aproveitei muita coisa do Super Chat (como as caretas) e outras do meu 
		primeiro chat.<br>
		Isso deve ser mudado em futuras vers�es , j� que esse chat � feito com 
		a contribui��o dos membros do <a href="http://www.phpbrasil.com">PHPBRASIL</a>&nbsp; 
		e de amigos . 
	  <P><B>Tio Romano, minha m�e disse que os garotos s� falam comigo no chat 
		por que querem me levar para a cama. Isso � verdade?</B> <BR>
		Mas que coisa feia isso que a sua m�e falou. Isto s� pode ser fruto de 
		muito preconceito e desinforma��o. Qualquer homem, ao abordar uma mulher, 
		fazendo aquele esfor�o danado para parecer simp�tico e educado, na verdade 
		s� pensa em encontrar uma companheira, casar e constituir fam�lia. � absurda 
		a hip�tese de que ele seja s� um fingido, que usa de subterf�gios vis 
		para convenc�-la a realizar todos aqueles atos de lasc�via e lux�ria que 
		s� a supostamente doentia mente masculina poderia conceber. Homens s�o 
		incapazes de arquitetar tais coisas, j� que s� pensam em carros, futebol, 
		cerveja, pol�tica, economia e outros assuntos chatos... T�, t� bom! Eles 
		tamb�m pensam nas Sheilas do Tchan. Mas � s� porque admiram o talento 
		art�stico, a intelig�ncia, e a vasta bagagem cultural das mo�as. 
	  <P><B>Regras de Conviv�ncia Virtual </B> 
	  <P>Para melhor utilizar a sala de chat, � importante que voc� conhe�a algumas 
		regras de conviv�ncia virtual, tais como: 
	  <P>1 - Evite utilizar letras mai�sculas, pois significa que voc� est� gritando.</P>
	  <P>2 - N�o use palavr�es e insultos, trate as pessoas da mesma forma como 
		voc� gostaria de ser tratado.</P>
	  <P>3 - Dentro da sala de bate-papo,para melhor expressar suas mensagens 
		voc� pode usar uma das <i><b>emoctions&nbsp; </b></i>abaixo :</P>
	  <p><img border="0" src="img/1.gif" width="15" height="15"> <img border="0" src="img/2.gif" width="15" height="15"> 
		<img border="0" src="img/3.gif" width="15" height="15"> <img border="0" src="img/4.gif" width="15" height="15"> 
		<img border="0" src="img/5.gif" width="15" height="15"> <img border="0" src="img/6.gif" width="15" height="15"> 
		<img border="0" src="img/7.gif" width="19" height="15"> <img border="0" src="img/8.gif" width="15" height="15"> 
		<img border="0" src="img/9.gif" width="15" height="15"> <img border="0" src="img/10.gif" width="15" height="15"> 
		<img border="0" src="img/11.gif" width="15" height="15"> <img border="0" src="img/12.gif" width="15" height="15"> 
		<img border="0" src="img/13.gif" width="19" height="15"> <img border="0" src="img/14.gif" width="15" height="15"> 
		<img border="0" src="img/15.gif" width="22" height="24"> <img border="0" src="img/16.gif" width="50" height="15"> 
		<img border="0" src="img/17.gif" width="15" height="15"> <img border="0" src="img/18.gif" width="15" height="15"> 
		<img border="0" src="img/19.gif" width="19" height="15"> <img border="0" src="img/20.gif" width="15" height="15"> 
		<img border="0" src="img/21.gif" width="15" height="15"> <img border="0" src="img/22.gif" width="15" height="15"> 
	  <P>4 - N�o forne�a seu telefone e nem seu endere�o, voc� n�o sabe quem est� 
		do outro lado.</P>
	  <P>5 - Divirta-se e fa�a muitas amizades virtuais!!!</P></td>
  </tr>
</table>
<p align="center"><font face="Verdana, Arial, Helvetica, sans-serif"
size="2">Copyleft <a href="mailto:romano@dcc.ufmg.br">Rodrigo Romano</a> - 2002.</font>&nbsp;</p>
<p align="center">
<table width="80" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="<? echo botao_up ?>">
  <tr onMouseOver="this.style.backgroundColor='<? echo botao_over ?>'" onMouseOut="this.style.backgroundColor='<? echo botao_up ?>'" onClick="window.close();"> 
    <td width="10" class="button" align="left"><img src="images/dobra.gif"></td>
    <td class="button"><b>Fechar</b></td>
    <td width="10" class="button"><img src="images/dobra2.gif"></td>
  </tr>
</table>
</html>