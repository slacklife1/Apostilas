<?
include "config.php";
?>
<html>
<head>
<title>Informa&ccedil;&otilde;es</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script src="borderize.js"></script>
<link href="romano.css" rel="stylesheet" type="text/css">
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellpadding="1" cellspacing="0" bgcolor="#000000">
  <tr>
	<td><table width="100%" border="0" cellspacing="1" cellpadding="0">
		<tr> 
		  <td align="center" valign="middle" class="titulo"><b>Informa&ccedil;&otilde;es</b></td>
		</tr>
		<tr>
		  <td bgcolor="#FFFFFF">&nbsp;</td>
		</tr>
		<tr> 
		  <td bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="1" cellpadding="2">
			  <tr>
				<td width="10">&nbsp;</td>
				<td>
				  <p>Bem vindo ao Romano Chat, a seguir algumas instru&ccedil;&otilde;es 
					e dicas para conversar no bate-papo:</p>
				  <ul>
					<li>Para enviar uma mensagem para todas as pessoas, selecione 
					  <b>TODOS</b> no menu de sele&ccedil;&atilde;o das pessoas: 
					  <select name="select">
						<option value="TODOS" selected>TODOS</option>
					  </select>
					</li>
					<li>Voc&ecirc; pode usar uma express&atilde;o de sentimento 
					  no menu: 
					  <select size=1 name=a>
						<option value="fala para" selected>fala para</option>
						<option value="pergunta para">pergunta para</option>
						<option value="responde para">responde para</option>
						<option value="concorda com">concorda com</option>
						<option value="discorda de">discorda de</option>
						<option value="desculpa-se com">desculpa-se com</option>
						<option value="surpreende-se com">surpreende-se com</option>
						<option value="murmura para">murmura para</option>
						<option value="sorri para">sorri para</option>
						<option value="suspira por">suspira por</option>
						<option value="flerta com">flerta com</option>
						<option value="entusiasma-se com">entusiasma-se com</option>
						<option value="ri de">ri de</option>
						<option value="d� um fora em">d� um fora em</option>
						<option value="briga com">briga com</option>
						<option value="grita com">grita com</option>
						<option value=xinga>xinga</option>
					  </select>
					</li>
					<li>Se quiser que a mensagem apare&ccedil;a apenas para uma 
					  pessoa, selecione essa pessoa no menu das pessoas e marque 
					  a caixa: 
					  <input type=checkbox value=ON name=d>
					  <font face="Arial" color="#000000" size="1">Reservadamente</font></li>
					<li>Escreva a mensagem na caixa de texto: 
					  <input size=50 name=e>
					</li>
					<li>Al&eacute;m dos sentimentos b&aacute;sicos mostrados acima, 
					  voc&ecirc; pode ainda usar os <b><i>emoticons</i></b> 
					  <select size="1" name="c">
						<option value="0" selected>nenhum</option>
						<option value="1">Alien</option>
						<option value="2">Endiabrado</option>
						<option value="3">Grito</option>
						<option value="4">Envergonhado</option>
						<option value="5">Pensativo</option>
						<option value="6">Triste</option>
						<option value="7">&Oacute;culos Escuros</option>
						<option value="8">Sorriso Largo</option>
						<option value="9">Feliz</option>
						<option value="10">Frio</option>
						<option value="11">Gargalhada</option>
						<option value="12">Zangado</option>
						<option value="13">Nerd</option>
						<option value="14">Sem gra&ccedil;a</option>
						<option value="15">Cafet&atilde;o</option>
						<option value="16">Rolando de rir</option>
						<option value="17">Enjoado</option>
						<option value="18">Sorriso</option>
						<option value="19">Fumando</option>
						<option value="20">Dormindo</option>
						<option value="21">Mostrando a l&iacute;ngua</option>
						<option value="22">Piscando a olho</option>
					  </select>
					 Segue abaixo as imagens correspondentes e o seu resultado na tela:</li>
				  </ul>
				  <table width="300" border="0" align="center" cellpadding="2" cellspacing="1">
					<tr> 
					  <td align="center"><img src="img/1.gif" width="15" height="15"></td>
					  <td>Alien</td>
					</tr>
					<tr> 
					  <td align="center"><img src="img/2.gif" width="15" height="15"></td>
					  <td>Endiabrado</td>
					</tr>
					<tr> 
					  <td align="center"><img src="img/3.gif" width="15" height="15"></td>
					  <td>Grito</td>
					</tr>
					<tr> 
					  <td align="center"><img src="img/4.gif" width="15" height="15"></td>
					  <td>Envergonhado</td>
					</tr>
					<tr> 
					  <td align="center"><img src="img/5.gif" width="15" height="15"></td>
					  <td>Pensativo</td>
					</tr>
					<tr> 
					  <td align="center"><img src="img/6.gif" width="15" height="15"></td>
					  <td>Triste</td>
					</tr>
					<tr> 
					  <td align="center"><img src="img/7.gif" width="19" height="15"></td>
					  <td>&Oacute;culos Escuro</td>
					</tr>
					<tr> 
					  <td align="center"><img src="img/8.gif" width="15" height="15"></td>
					  <td>Sorriso Largo</td>
					</tr>
					<tr> 
					  <td align="center"><img src="img/9.gif" width="15" height="15"></td>
					  <td>Feliz</td>
					</tr>
					<tr> 
					  <td align="center"><img src="img/10.gif" width="15" height="15"></td>
					  <td>Frio</td>
					</tr>
					<tr> 
					  <td align="center"><img src="img/11.gif" width="15" height="15"></td>
					  <td>Gargalhada</td>
					</tr>
					<tr> 
					  <td align="center"><img src="img/12.gif" width="15" height="15"></td>
					  <td>Zangado</td>
					</tr>
					<tr> 
					  <td align="center"><img src="img/13.gif" width="19" height="15"></td>
					  <td>Nerd</td>
					</tr>
					<tr> 
					  <td align="center"><img src="img/14.gif" width="15" height="15"></td>
					  <td>Sem Gra&ccedil;a</td>
					</tr>
					<tr> 
					  <td align="center"><img src="img/15.gif" width="22" height="24"></td>
					  <td>Cafet&atilde;o</td>
					</tr>
					<tr> 
					  <td align="center"><img src="img/16.gif" width="50" height="15"></td>
					  <td>Rolando de Rir</td>
					</tr>
					<tr> 
					  <td align="center"><img src="img/17.gif" width="15" height="15"></td>
					  <td>Enjoado</td>
					</tr>
					<tr> 
					  <td align="center"><img src="img/18.gif" width="15" height="15"></td>
					  <td>Sorriso</td>
					</tr>
					<tr> 
					  <td align="center"><img src="img/19.gif" width="19" height="15"></td>
					  <td>Fumando</td>
					</tr>
					<tr> 
					  <td align="center"><img src="img/20.gif" width="15" height="15"></td>
					  <td>Dormindo</td>
					</tr>
					<tr> 
					  <td align="center"><img src="img/21.gif" width="15" height="15"></td>
					  <td>Mostrando a L&iacute;ngua</td>
					</tr>
					<tr>
					  <td align="center"><img src="img/22.gif" width="15" height="15"></td>
					  <td>Piscando o Olho</td>
					</tr>
				  </table>
				</td>
				<td width="10">&nbsp;</td>
			  </tr>
			</table></td>
		</tr>
		<tr> 
		  <td height="50" align="center" bgcolor="#FFFFFF"><table width="80" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="<? echo botao_up ?>">
              <tr onMouseOver="this.style.backgroundColor='<? echo botao_over ?>'" onMouseOut="this.style.backgroundColor='<? echo botao_up ?>'" onClick="window.close();"> 
                <td width="10" class="button" align="left"><img src="images/dobra.gif"></td>
                <td class="button"><b>Fechar</b></td>
                <td width="10" class="button"><img src="images/dobra2.gif"></td>
              </tr>
            </table></td>
		</tr>
	  </table></td>
  </tr>
</table>
</body>
</html>