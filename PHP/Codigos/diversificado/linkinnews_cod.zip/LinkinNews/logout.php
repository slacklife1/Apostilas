<?
/*################################################  #     #    #
# Sistema de Noticias 1.0 desenvolvido         #  #     #    #
#por: Linkin                                   #  #     #    #
#icq: 159148126                                #  #     ### #
#Email: igorescobar@bol.com.br  Igor Escobar   #  #     #    #
################################################  ##### #    # */

setcookie("username");
setcookie("senha");
header("Location: index.php");

?>

