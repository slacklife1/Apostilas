<?
//################################################  #     #    #
//# Sistema de Noticias 1.0 desenvolvido         #  #     #    #
//#por: Linkin                                   #  #     #    #
//#icq: 159148126                                #  #     ### #
//#Email: igorescobar@bol.com.br  Igor Escobar   #  #     #    #
//################################################  ##### #    #
?>
<? include "cabecalho.php"; ?><BR>
 <img src="busca.jpg" width="200" height="50" border="0"><BR>
<? include "valida_cookies.php"; ?>

<B<BR><BR><BR><BR>
 <p align="center"><form action=buscando.php method=post>
  <select size="1" name=por style="font-family: Verdana; font-size: 8 pt; font-weight: bold">
  <option SELECTED>Buscar Por...</option>
   <option value=titulo>Titulo</option>
   <option value=ip>ip</option>
</select> <input type=text name=valor style="font-family: Verdana; font-size: 8 pt; font-weight: bold"> <input type=submit value="Buscar >>" style="font-family: Verdana; font-size: 8 pt; font-weight: bold"></form></p>
<p align="center"><a href=admin.php> Voltar ao Painel Admin </a><br></p>
<BR><BR>
<CENTER><font face=verdana size=1> Sistema de noticia Desenvolvido e Projetado por: Linkin<BR> igorescobar@bol.com.br</CENTER>
