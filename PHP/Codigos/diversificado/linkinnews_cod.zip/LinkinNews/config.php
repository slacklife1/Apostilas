<?
$site = "Digite_seu_Site"; // Digite a url do site que vai instalar.

$host = "localhost"; // Host valor padrao � localhost

$usuariodb="Usuario_Mysql"; //Usuario de Conexao com  o MySQL

$senhadb="sua_senha_MySQL"; // Senha de Conexao com o MySQL

$db="seu_baco_de_dados"; //Banco de Dados MySQL

$tb1="msgs"; // NAO ALTERE AQUI DE MANEIRA ALGUMA !!

$tb2="usuarios"; // NAO ALTERE AQUI DE MANEIRA ALGUMA !!

$nnoticias="5"; // Coloque aqui o n�de noticias exibidas por vez

$useradmin="Coloque aqui seu usuario admin"; // Coloque aqui o seu usuario Administrador

$senhaadmin="sua senha admin"; // Sua senha do administrador para o acesso ao painel

$conexao=mysql_connect ("$host", "$usuariodb", "$senhadb") or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db ("$db") or die("n�o foi possivel");
?>
