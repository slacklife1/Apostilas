<body alink="black"  link="black"    vlink="black">
<?
//################################################  #     #    #
//# Sistema de Noticias 1.0 desenvolvido         #  #     #    #
//#por: Linkin                                   #  #     #    #
//#icq: 159148126                                #  #     ### #
//#Email: igorescobar@bol.com.br  Igor Escobar   #  #     #    #
//################################################  ##### #    #
?>
<?php
include "config.php";
$busca = "SELECT * FROM $tb1 ORDER BY id DESC";
$total_reg = "$nnoticias"; // n�mero de registros por p�gina
$pagina = $_GET['pagina'];
if (!$pagina) {
    $pc = "1";
} else {
    $pc = $pagina;
}
$inicio = $pc - 1;
$inicio = $inicio * $total_reg;

$limite = mysql_query("$busca LIMIT $inicio,$total_reg");
$todos = mysql_query("$busca");

$tr = mysql_num_rows($todos); // verifica o n�mero total de registros
$tp = $tr / $total_reg; // verifica o n�mero total de p�ginas

// vamos criar a visualiza��o
while ($dados = mysql_fetch_array($limite)) {
$titulo = $dados['titulo'];
$data = $dados['data'];
$hora = $dados['hora'];
 echo "
<div align=left><font face=\"verdana\" size=\"1\"> $data - <a href=\"#\" onClick=\"window.open('../LinkinNews/exibemsg.php?titulo=$titulo','Janela','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,width=300,height=197'); return false;\" style=\"color: #000000\"><u>$titulo</u></a><br></div>";
}

// agora vamos criar os bot�es "Anterior e pr�ximo"
$anterior = $pc -1;
$proximo = $pc +1;
if ($pc>1) {
    echo " <a href='?pagina=$anterior'><- Anterior</a> ";
}
if ($pc<$tp) {
    echo " <a href='?pagina=$proximo'>Pr�xima -></a>";
}
?>

