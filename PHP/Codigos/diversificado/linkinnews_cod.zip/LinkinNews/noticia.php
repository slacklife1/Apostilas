<?
//################################################  #     #    #
//# Sistema de Noticias 1.0 desenvolvido         #  #     #    #
//#por: Linkin                                   #  #     #    #
//#icq: 159148126                                #  #     ### #
//#Email: igorescobar@bol.com.br  Igor Escobar   #  #     #    #
//################################################  ##### #    #
?>
<script language="JavaScript" type="text/javascript">
function emoticon(text) {
	text = ' ' + text + ' ';
	if (document.post.msg.createTextRange && document.post.msg.caretPos) {
		var caretPos = document.post.msg.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ? text + ' ' : text;
		document.post.msg.focus();
	} else {
	document.post.msg.value  += text;
	document.post.msg.focus();
	}
}

</script>
 <? include "cabecalho.php"; ?>
   <? include "valida_cookies.php"; ?><BR>
      <?
$data=date ("d/m/Y",time());
$hora = strftime("%H:%M:%S");
$ip= getenv("REMOTE_ADDR");
echo "<form action=\"postar.php\" method=\"post\" name=\"post\" >
<input type='hidden' name='data' value='$data'>
<input type='hidden' name='hora' value='$hora'>
<input type='hidden' name='ip' value='$ip'>
<p aling=\"center\" align=\"center\"><font face=\"Verdana\" size=\"1\">

<table border=\"0\" cellpadding=\"3\" cellspacing=\"1\" width=\"593\" align=\"center\">
    <tr> 
      <th class=\"thHead\" colspan=\"2\" height=\"25\">&nbsp;</th>
    </tr>
    <tr> 
      <td class=\"row1\" width=\"122\"><b><font size=1><p align=\"center\">Assunto:</p></b></td>
      <td class=\"row2\" width=\"456\">
         <input name=\"titulo\" type=\"text\" id=\"Titulo:\" size=\"60\" style=\"font-family: Verdana; font-size: 8 pt; font-weight: bold\">
        </td>
    </tr>
    <tr> 
      <td valign=\"top\"> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\">
          <tr> 
            <td>&nbsp;</td>
          </tr>
          <tr> 
            <td valign=\"top\" align=\"center\"> <br />
              <table width=\"100\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">
                <tr align=\"center\">
                  <td colspan=\"4\"><b><font size=1>Emo��es</b></td>
                </tr>
                <tr align=\"center\" valign=\"middle\">
                  <td><a href=\"javascript:emoticon(':D')\"><img src=\"smyles/dente.gif\" border=0></a></td>
                  <td><a href=\"javascript:emoticon(':)')\"><img src=\"smyles/aaa.gif\" border=0></a></td>
                  <td><a href=\"javascript:emoticon(':(')\"><img src=\"smyles/sad.gif\" border=0></a></td>
                  <td><a href=\"javascript:emoticon(':o')\"><img src=\"smyles/ohmy.gif\" border=0></a></td>
                </tr>
                <tr align=\"center\" valign=\"middle\">
                  <td><a href=\"javascript:emoticon(':shock:')\"><img src=\"smyles/icon_eek.gif\" border=0></a></td>
                  <td><a href=\"javascript:emoticon(':e')\"><img src=\"smyles/smalie_lol.gif\" border=0></a></td>
                  <td><a href=\"javascript:emoticon('8)')\"><img src=\"smyles/cool.gif\" border=0></a></td>
                  <td><a href=\"javascript:emoticon(':lol:')\"><img src=\"smyles/laugh.gif\" border=0></a></td>
                </tr>
                <tr align=\"center\" valign=\"middle\">
                  <td><a href=\"javascript:emoticon(':x')\"><img src=\"smyles/mad.gif\" border=0></a></td>
                  <td><a href=\"javascript:emoticon(':P')\"><img src=\"smyles/Tongue.jpg\" border=0></a></td>
                  <td><a href=\"javascript:emoticon('o.O')\"><img src=\"smyles/blink.gif\" border=0></a></td>
                  <td><a href=\"javascript:emoticon(':*')\"><img src=\"smyles/teeth_smile.gif\" border=0></a></td>
                </tr>
                <tr align=\"center\" valign=\"middle\">
                  <td><a href=\"javascript:emoticon('-_-')\"><img src=\"smyles/77_77.gif\" border=0></a></td>
                  <td><a href=\"javascript:emoticon('<_<')\"><img src=\"smyles/dry.gif\" border=0></a></td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
              </table></td>
          </tr>
        </table>
      </td>
      <td class=\"row2\" valign=\"top\">
        <table width=\"450\" border=\"0\" cellspacing=\"0\" cellpadding=\"2\">
          <tr> 
            <td><div align=\"right\">
                <textarea name=\"msg\" rows=\"10\" cols=\"30\" style=\"width:450px\" font-family: Verdana; font-size: 8 pt; font-weight: bold\"></textarea>
                <input type=\"submit\" name=\"Submit\" value=\"Postar &gt;&gt;\" style=\"font-family: Verdana; font-size: 8 pt; font-weight: bold\">
                </div></td>
          </tr>
        </table>
        </span></td>
    </tr>
  </table>

  </form>";

?>
    
<BR>
<BR><BR>
<CENTER><a href=admin.php> Voltar ao Painel Admin </A> <CENTER>
<BR><BR><BR><BR>
<CENTER><font face=verdana size=1> Sistema de noticia Desenvolvido e Projetado por: Linkin<BR> igorescobar@bol.com.br</CENTER>
