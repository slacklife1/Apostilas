<?
//################################################  #     #    #
//# Sistema de Noticias 1.0 desenvolvido         #  #     #    #
//#por: Linkin                                   #  #     #    #
//#icq: 159148126                                #  #     ### #
//#Email: igorescobar@bol.com.br  Igor Escobar   #  #     #    #
//################################################  ##### #    #
?>
<? include "cabecalho.php"; ?>
<form method="POST" action="confirmar_login.php">
  <p aling="center" align="center"><font face="Verdana" size="1"><b>Login:<br>
&nbsp;<input type="text" name="username" size="15" style="font-family: Verdana; font-size: 8 pt; font-weight: bold"><br>
  Senha: <br>
  <input type="password" name="senha" size="15" style="font-family: Verdana; font-size: 8 pt; font-weight: bold"><br>
  <input type="submit" value="Entrar" name="submeter" size="15" style="font-size: 8 pt; font-family: Verdana; font-weight: bold"></b></font></p>
</form>
<BR><BR><BR><BR>
<CENTER><font face=verdana size=1> Sistema de noticia Desenvolvido e Projetado por: Linkin<BR> igorescobar@bol.com.br</CENTER>
