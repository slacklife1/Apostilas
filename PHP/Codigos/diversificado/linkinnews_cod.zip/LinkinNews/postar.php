<?
//################################################  #     #    #
//# Sistema de Noticias 1.0 desenvolvido         #  #     #    #
//#por: Linkin                                   #  #     #    #
//#icq: 159148126                                #  #     ### #
//#Email: igorescobar@bol.com.br  Igor Escobar   #  #     #    #
//################################################  ##### #    #
?>
 <? include "cabecalho.php"; ?>
<?
include "config.php";
include "valida_cookies.php";
$data= $_POST['data'];
$hora= $_POST['hora'];
$ip= $_POST['ip'];
$titulo= $_POST['titulo'];
$msg = $_POST['msg'];
if (empty($titulo) && empty($msg))
{
echo "Todos os campos obrigat�rios";
}
else {
include "config.php";
global $tb1;
$sql= mysql_query("INSERT INTO $tb1 (msg, titulo, data, hora, ip) VALUES ('$msg','$titulo','$data','$hora','$ip');");
if (!$sql)
{
echo "N�o foi possivel postar a noticia<br><br> ";
} else {
echo "
<BR>
<font face=verdana size=1>
<b>Titulo:</b> $titulo<br>
<b>Mensagem:</b> $msg<BR>
<b>Data:</b> $data<br>
<b>Hora:</b> $hora<BR>
<b>Ip do Postador:</b> $ip<BR>
<BR><h3>Noticia Postada com sucesso !</h3></font>";
}
}
?>
<BR><BR><BR><BR><BR>
<center><a href=admin.php> Voltar ao painel Admin</a> | <a href=noticia.php> Postar Outra noticia</a></center>
<BR><BR><BR><BR>
<CENTER><font face=verdana size=1> Sistema de noticia Desenvolvido e Projetado por: Linkin<BR> igorescobar@bol.com.br</CENTER>
