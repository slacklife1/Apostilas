<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" link="black" alink="black" vlink="black">
<?
//################################################  #     #    #
//# Sistema de Noticias 1.0 desenvolvido         #  #     #    #
//#por: Linkin                                   #  #     #    #
//#icq: 159148126                                #  #     ### #
//#Email: igorescobar@bol.com.br  Igor Escobar   #  #     #    #
//################################################  ##### #    #
?>
<font face=verdana size=1>
<img src="noticia.jpg" width="280" height="30s" border="0">
<?
include "config.php";
$titulo = $_GET['titulo'];
$sql= mysql_query("SELECT * FROM $tb1 where titulo='$titulo'");
while ($reg = mysql_fetch_array($sql)){
$text= $reg['msg'];
if (strstr($text,':D')){
$text = str_replace(":D", "<img src=\"smyles/dente.gif\" border=0>", $text);
}
if (strstr($text,':)')){
$text = str_replace(":)", "<img src=\"smyles/aaa.gif\" border=0>", $text);
}
if (strstr($text,':(')){
$text = str_replace(":(", "<img src=\"smyles/sad.gif\" border=0>", $text);
}
if (strstr($text,':o')){
$text = str_replace(":o", "<img src=\"smyles/ohmy.gif\" border=0>", $text);
}
if (strstr($text,':shock:')){
$text = str_replace(":shock:", "<img src=\"smyles/icon_eek.gif\" border=0>", $text);
}
if (strstr($text,':e')){
$text = str_replace(":e", "<img src=\"smyles/smalie_lol.gif\" border=0>", $text);
}
if (strstr($text,'o.O')){
$text = str_replace("o.O", "<img src=\"smyles/blink.gif\" border=0></a>", $text);
}
if (strstr($text,':lol:')){
$text = str_replace(":lol:", "<img src=\"smyles/laugh.gif\" border=0>", $text);
}
if (strstr($text,':*')){
$text = str_replace(":*", "<img src=\"smyles/teeth_smile.gif\" border=0>", $text);
}
if (strstr($text,'-_-')){
$text = str_replace("-_-", "<img src=\"smyles/77_77.gif\" border=0>", $text);
}
if (strstr($text,'<_<')){
$text = str_replace("<_<", "<img src=\"smyles/dry.gif\" border=0>", $text);
}
if (strstr($text,':P')){
$text = str_replace(":P", "<img src=\"smyles/Tongue.jpg\" border=0>", $text);
}
if (strstr($text,'8)')){
$text = str_replace("8)", "<img src=\"smyles/cool.gif\" border=0>", $text);
}
if (strstr($text,':x')){
$text = str_replace(":x", "<img src=\"smyles/mad.gif\" border=0>", $text);
}
$text=nl2br($text);
echo "$text";

}

?><br>
<p align="center">LinkinNews�</p>
