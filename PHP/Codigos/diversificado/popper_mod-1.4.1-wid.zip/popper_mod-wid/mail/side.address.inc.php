<?
        function show_side_addresses($blocked = false) {
                global $addr_id, $strings, $show;

                if ($show == "blocked") {
                        $blocked = true;
                        echo("<h3>".$strings["l_Blocked"]."</h3>");
                }


                if (isset($addr_id) && !empty($addr_id)) {
                        $this->cur_address_id = $addr_id;
                }

                $query = "SELECT id, IF(LENGTH(name) > '".$this->config["address_size"]."', CONCAT(LEFT(name, '".$this->config["address_size"]."'), '...'), name) as name, IF(LENGTH(email) > \'".$this->config["address_size"]."', CONCAT(LEFT(email, '".$this->config["address_size"]."'), '...'), email) as email FROM addresses WHERE user_id = '$this->userid' AND blocked='$blocked'";
                $res = $this->db_tool->db_query($query);
                if ($res == 0) {
                        $this->report_error($this->db_tool->db_error(), $strings["l_DBError"]);
                        return;
                }
                if ($this->db_tool->affected_rows() < 1) {
                        echo($strings[l_NoAddress]);
                        return;
                }

                echo("<table width=\"400\" class=bw>\n");
                echo("<tr><th align=\"left\" width=\"50%\">Name</th><th align=\"left\">E-Mail</th></tr>\n");
                while($row = $this->db_tool->fetch_array($res)) {
                        echo("<tr><td>\n");
                        echo("<a href=\"$GLOBALS[PHP_SELF]?action=addressbook&addr_id=$row[id]");
                        if ($blocked) {
                                echo("&show=blocked");
                        }
                        echo("\" title=\"$strings[l_ShowDetails]\"");
                        $this->address_selected($row[id]);
                        echo(">".$this->extract_disp_name(stripslashes($row[name]))."</a></td>\n");
                        echo("<td><a href=\"$GLOBALS[PHP_SELF]?action=newmail&addr_id=$row[id]\" title=\"$strings[l_SendMail]\" target=\"_parent\">".stripslashes($row["email"])."</a></td></tr>\n");
                }
                echo("</table>\n");

?>
