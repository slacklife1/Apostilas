<tr class="window">
	<td width="35%" valign="top">
		<?php $this->show_accounts()?>
	</td>

	<td>
	<table width="100%" border="0" cellpadding="0" cellspacing="0">
		<tr>
			<td class="windowtitle">
				<?php echo($strings["l_AccDetails"]);?>
			</td>
		</tr>
		<tr>
			<td>
				<?php $this->show_account(); ?>
			</td>
		</tr>
	</table>
	</td>

</tr>
<tr><td>
<a href="<?php echo $GLOBALS[PHP_SELF]; echo "?action=frameset"; ?>">
<IMG SRC="graphics/sendandreceive.gif">
<i><?php echo $strings["l_Close1"]; echo " "; echo $strings["l_Accounts"]; echo " "; echo $strings["l_Close2"]; ?></i></a>
<br>
<a href="<?php echo $GLOBALS[PHP_SELF];?>">
<IMG SRC="graphics/logo.gif">
<i><?php echo $strings["l_Close1"]; echo " "; echo $strings["l_Accounts"]; echo " "; echo $strings["l_Close3"]; ?></i></a>
</td></tr>
