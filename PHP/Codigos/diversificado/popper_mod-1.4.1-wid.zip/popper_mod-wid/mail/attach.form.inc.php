<? global $body,$subject,$tos; ?>
<?
global $NewAttachment_name, $NewAttachment_type, $NewAttachment, $ToRemove;
if ($NewAttachment[0] != "") {
 if (substr(phpversion(), 0, 5) >= "4.0.3") {
                $tmp_path = "tmp/".basename($NewAttachment[0]);

                $move = move_uploaded_file($NewAttachment[0], $tmp_path);
                if (!$move) {
                        echo "error couldn't move file<br>";
                        return false;
                }
                $NewAttachment[0] = $tmp_path;
        }
}
?>
<table><tr><td>
<form class="mail" action="<?php echo("$GLOBALS[PHP_SELF]?action=choosen")?>"method="post"  enctype="multipart/form-data">


<input type=file name="NewAttachment[]">	<input type="submit" value="<?=$strings["l_Add"] ?>" name="submit"><br>
<table border=1 bgcolor=white width=200><tr><td><center><b><?=$strings[l_Attachments]; ?></b></center></td></tr><tr><td>
<?
echo "<input type=hidden name=attachment_name[] value=\"$NewAttachment_name[0]\">";
echo "<input type=hidden name=attachment_type[] value=\"$NewAttachment_type[0]\">";
echo "<input type=hidden name=attachment[] value=\"$NewAttachment[0]\">";
echo "$NewAttachment_name[0]<br>";

for($i=0;$i < sizeof($attachment); $i++) {
if($attachment[$i] != "" && $attachment_name[$i] != $ToRemove) {
echo "<input type=hidden name=attachment[] value=\"$attachment[$i]\">";
echo "<input type=hidden name=attachment_name[] value=\"$attachment_name[$i]\">";
echo "<input type=hidden name=attachment_type[] value=\"$attachment_type[$i]\">";
echo "$attachment_name[$i]<br>";
}
}
?>
</td></tr></table>

<br>

<input type=hidden name=body value="<?=$body; ?>">
<input type=hidden name=subject value="<?=$subject; ?>">
<input type=hidden name=tos value="<?=$tos; ?>">

</form>
<form class="mail" action="<?php echo("$GLOBALS[PHP_SELF]?action=choosen")?>"method="post"  enctype="multipart/form-data">


<input type=hidden name=body value="<?=$body; ?>">
<input type=hidden name=subject value="<?=$subject; ?>">
<input type=hidden name=tos value="<?=$tos; ?>">
<?
if($NewAttachment_name[0] != "") {
echo "<input type=hidden name=attachment_name[] value=\"$NewAttachment_name[0]\">";
echo "<input type=hidden name=attachment_type[] value=\"$NewAttachment_type[0]\">";
echo "<input type=hidden name=attachment[] value=\"$NewAttachment[0]\">";
}
for($i=0;$i < sizeof($attachment); $i++) {
if($attachment[$i] != "" && $attachment_name[$i] != $ToRemove) {
echo "<input type=hidden name=attachment[] value=\"$attachment[$i]\">";
echo "<input type=hidden name=attachment_name[] value=\"$attachment_name[$i]\">";
echo "<input type=hidden name=attachment_type[] value=\"$attachment_type[$i]\">";
	}
}
?>	<input class="button" type="submit" value="Finished" name="finished">


</td><td width=50>
</td><td>
<?
echo "<select name=\"ToRemove\">";
if($NewAttachment_name[0] != "") { echo "<option>$NewAttachment_name[0]</option><br>\n"; }

for($i=0;$i < sizeof($attachment); $i++) {
if($attachment_name[$i] != "" && $attachment_name[$i] != $ToRemove) {
echo "<option>$attachment_name[$i]</option><br>";
}
}
?>
</selected></td><td>
<input type=submit name=submit value="<?=$strings["l_Delete"]; ?>">
</form>
</td></tr></table>
