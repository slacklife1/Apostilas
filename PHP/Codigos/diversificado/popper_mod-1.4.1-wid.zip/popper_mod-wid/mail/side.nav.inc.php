<?
///////////////////////////////////////////////////////////////////////////////////////////////////
//Tree View for Popper_mod hacked into Popper_mod by Robert Campbell (rob@boobert.net)          ///
//Copyright (c) 2002 This script can be used freely as long as all copyright messages are intact.//
//Hope you like my addition :)									 //
///////////////////////////////////////////////////////////////////////////////////////////////////
include('skin.db');
?>

<tr class="window">
<td width="15%" valign="top">
<table width="100%" class=bw><tr>
<td nowrap>

	<link rel="StyleSheet" href="<?=$Treesheet ?>" type="text/css">
	<script type="text/javascript" src="<?=$TreeJS ?>"></script>
	<script type="text/javascript">
		<!--
		var Tree = new Array;
		// nodeId | parentNodeId | nodeName | nodeUrl
		Tree[0]  = "1|0|Popper Mail|#|folder";
		Tree[1]	 = "2|1|Standard|#|folder";
		Tree[2]	 = "3|2|Inbox (<?php num_mails("inbox", "false", $this->userid);?>)|<?=$GLOBALS[PHP_SELF] ?>?action=showfolder&folder=inbox|inbox";
Tree[3]	 = "4|2|Outbox|<?=$GLOBALS[PHP_SELF] ?>?action=showfolder&folder=outbox|outbox";
Tree[4]	 = "5|2|Sent|<?=$GLOBALS[PHP_SELF] ?>?action=showfolder&folder=sent|sent";
Tree[5]	 = "6|2|Deleted|<?=$GLOBALS[PHP_SELF] ?>?action=showfolder&folder=bin|bin";
Tree[6]	 = "7|2|Drafts|<?=$GLOBALS[PHP_SELF] ?>?action=showfolder&folder=drafts|drafts";
		Tree[7]  = "8|1|Your Folders|#|folder";

<? 
global $v;
$v=8; ?>

<?php

                include "config.inc.php";
                $connection = mysql_connect($host, $user, $pass) or die ("SQL server problem");

                $tblname = "mail_" . $this->userid;
                $query = "SELECT DISTINCT folder from $tblname";
                $result = mysql_db_query($dbname, $query, $connection);

                while ($folders = mysql_fetch_row($result))
                {
                        switch ($folders[0])
                        {
                                case 'inbox';
                                case 'outbox';
                                case 'sent';
                                case 'bin';
                                case 'drafts';
                                case 'trash';
                                case 'saved';

                                        break;

                                default:
					if ($this->folder == $folders[0]) {
global $v;
$p = $v+1;
echo "Tree[$v]	 = \"$p|8|$folders[0] (";
num_mails("$folders[0]", "false", $this->userid);
echo ")|$GLOBALS[PHP_SELF]?navopen=".$v."&action=showfolder&folder=$folders[0]|folder\";";
$v++;
					}
					else {
global $v;
$p = $v+1;

echo "Tree[$v]	 = \"$p|8|$folders[0] (";
num_mails("$folders[0]", "false", $this->userid);
echo ")|$GLOBALS[PHP_SELF]?navopen=".$v."&action=showfolder&folder=$folders[0]|folder\";";
$v++;

					}
                        }
                }

?>
		//-->
	</script>
</head>

<body>

<div id="tree">
<script type="text/javascript">
<!--
	createTree(Tree,1,2);  // starts the tree at the top and open it at node nr. 7
//-->
</script>
</div>


<tr>
<td align="center">
<a href="index.php?action=showcal" target=new>


<img src="<?=$graphic_dir ?>/cal.gif" alt="Calendar" title="Calendar" style="vertical-align: middle;" border="0"></a></td></tr>
</table>
<?
function stylecolor($picked) {
global $folder;
if ($folder == $picked) {
echo "style=\"background-color: Blue; color: White;\"";
}
} 
?>










<?


function num_mails($folder = "", $total = "false", $userid)
{

        $tblname = "mail_" . $userid;

        if ($total == "true")
                $query = "SELECT id FROM $tblname WHERE folder='$folder' AND is_mime!=9";
        if ($total == "false")
                $query = "SELECT id FROM $tblname WHERE folder='$folder' AND was_read=0";

        $result = mysql_query($query);
        echo mysql_num_rows($result);

}
 ?>

