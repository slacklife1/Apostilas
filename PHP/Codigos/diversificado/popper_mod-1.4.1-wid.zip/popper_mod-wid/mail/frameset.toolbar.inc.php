<? include('skin.db'); ?>
	<tr class="toolbar">
		<td colspan="3" nowrap>
		<img src="<?=$graphic_dir ?>/toolbar_left.gif" alt="|">
<?php	
		global $mail_id;
		include "config.inc.php";
		
		$frame_view = true;
		
		echo("<a href=\"$GLOBALS[PHP_SELF]?action=newmail\"><img src=\"$graphic_dir/newmail.gif\" alt=\"$strings[l_NewMail]\" title=\"$strings[l_NewMail]\" border=\"0\"></a>\n");

			echo("<img src=\"$graphic_dir/spacing.gif\" alt=\"|\">");
				// Enable the Reply, forward etc. buttons only when a message is selected and
				// if we're not in the outbox

				$disable = !$frame_view && ($this->cur_message_id == 0 || $this->folder == "outbox");
				if ($disable) {

					echo("<img style=\"margin: 0px, 1px, 0px, 1px;\" src=\"$graphic_dir/reply_dis.gif\" alt=\"$strings[l_Select]\" title=\"$strings[l_Select]\">\n");
					echo("<img style=\"margin: 0px, 1px, 0px, 1px;\" src=\"$graphic_dir/replytoall_dis.gif\" alt=\"$strings[l_Select]\" title=\"$strings[l_Select]\">\n");
					echo("<img style=\"margin: 0px, 1px, 0px, 1px;\" src=\"$graphic_dir/forward_dis.gif\" alt=\"$strings[l_Select]\" title=\"$strings[l_Select]\">\n");
				}
				else
				{
					if ($frame_view) {
					echo("<a href=\"$GLOBALS[PHP_SELF]?action=reply\"><img src=\"$graphic_dir/reply.gif\" alt=\"$strings[l_ReplyMail]\" title=\"$strings[l_ReplyMail]\" border=\"0\"></a>\n");
					echo("<a href=\"$GLOBALS[PHP_SELF]?action=replytoall\"><img src=\"$graphic_dir/replytoall.gif\" alt=\"$strings[l_ReplyAllMail]\" title=\"$strings[l_ReplyAllMail]\" border=\"0\"></a>\n");
					echo("<a href=\"$GLOBALS[PHP_SELF]?action=forward\"><img src=\"$graphic_dir/forward.gif\" alt=\"$strings[l_ForwardMail]\" title=\"$strings[l_ForwardMail]\" border=\"0\"></a>\n");					
					}
					else {
					echo("<a href=\"$GLOBALS[PHP_SELF]?action=reply&mail_id=$mail_id\"><img src=\"$graphic_dir/reply.gif\" alt=\"$strings[l_ReplyMail]\" title=\"$strings[l_ReplyMail]\" border=\"0\"></a>\n");
					echo("<a href=\"$GLOBALS[PHP_SELF]?action=replytoall&mail_id=$mail_id\"><img src=\"$graphic_dir/replytoall.gif\" alt=\"$strings[l_ReplyAllMail]\" title=\"$strings[l_ReplyAllMail]\" border=\"0\"></a>\n");
					echo("<a href=\"$GLOBALS[PHP_SELF]?action=forward&mail_id=$mail_id\"><img src=\"$graphic_dir/forward.gif\" alt=\"$strings[l_ForwardMail]\" title=\"$strings[l_ForwardMail]\" border=\"0\"></a>\n");
					}
				}

				echo("<img src=\"$graphic_dir/spacing.gif\" alt=\"|\">");

				// Enable the delete button only when a message is selected
				$disable = (!$frame_view && $this->cur_message_id == 0);
				if ($disable) {
					echo("<img style=\"margin: 0px, 1px, 0px, 1px;\" src=\"$graphic_dir/print_dis.gif\" alt=\"$strings[l_Select]\" title=\"$strings[l_Select]\">\n");
					echo("<img style=\"margin: 0px, 1px, 0px, 1px;\" src=\"$graphic_dir/cancel_dis.gif\" alt=\"$strings[l_Select]\" title=\"$strings[l_Select]\">\n");
				}
				else {
					// MNS frame fix patch
					if ($frame_view) {
					echo("<a href=\"$GLOBALS[PHP_SELF]?action=printmail\" target=\"blank_\"><img src=\"$graphic_dir/print.gif\" alt=\"$strings[l_Print]\" title=\"$strings[l_Print]\" border=\"0\"></a>\n");
					echo("<a href=\"$GLOBALS[PHP_SELF]?action=showsources\" target=\"blank_\"><img src=\"$graphic_dir/prop.gif\" alt=\"$strings[l_ShowSources]\" title=\"$strings[l_ShowSources]\" border=\"0\"></a>\n");
					//boobert
					//echo("<a href=\"$GLOBALS[PHP_SELF]?action=deletemail\"");					
					//echo(" target=\"maillist\"");
					}
					else {
					echo("<a href=\"$GLOBALS[PHP_SELF]?action=printmail&mail_id=$mail_id\" target=\"blank_\"><img src=\"$graphic_dir/print.gif\" alt=\"$strings[l_Print]\" title=\"$strings[l_Print]\" border=\"0\"></a>\n");
					echo("<a href=\"$GLOBALS[PHP_SELF]?action=deletemail&mail_id=$mail_id\"");
					}
					//boobert
					//echo("><img src=\"$graphic_dir/cancel.gif\" alt=\"$strings[l_DeleteSel]\" title=\"$strings[l_DeleteSel]\" border=\"0\"></a>\n");
				}
			
			echo("<a href=\"$GLOBALS[PHP_SELF]?action=deleteall\"");
			if ($frame_view) {
				echo(" target=\"maillist\"");
			}			
			echo("><img src=\"$graphic_dir/cancelm.gif\" alt=\"$strings[l_DeleteAll]\" title=\"$strings[l_DeleteAll]\" border=\"0\"></a>\n");
			echo("<img src=\"$graphic_dir/spacing.gif\" alt=\"|\">");
			echo("<a href=\"$GLOBALS[PHP_SELF]?action=sendandreceive\"");
			if ($frame_view) {
				echo(" target=\"maillist\"");
			}
			echo("><img src=\"$graphic_dir/sendandreceive.gif\" alt=\"$strings[l_SendReceive]\" title=\"$strings[l_SendReceive]\" border=\"0\"></a>\n");
			//echo("<a href=\"$GLOBALS[PHP_SELF]?action=checkrep\" target=\"blank_\"><img src=\"$graphic_dir/get_rep.gif\" alt=\"\"" title=\"$strings[l_GetRep]\" border=\"0\"></a>\n");
			echo("<img src=\"$graphic_dir/spacing.gif\" alt=\"|\">");
			echo("<a href=\"$GLOBALS[PHP_SELF]?action=addressbook\" target=\"_top\"");
			if ($frame_view) {
				echo(" target=\"maillist\"");
			}
			echo("><img src=\"$graphic_dir/address.gif\" alt=\"$strings[l_AddressBook]\" title=\"$strings[l_AddressBook]\" border=\"0\"></a>\n");
echo("<a href=\"index.php?action=showcal\" target=new>");			
echo("<img src=\"$graphic_dir/calbutton.gif\" alt=\"$strings[l_CalButton]\" title=\"$strings[l_CalButton]\" border=\"0\"></a>\n");
			if ($allowaccount == '1')
			{
				//echo("<img src=\"$graphic_dir/spacing.gif\" alt=\"|\">");
				echo("<a href=\"$GLOBALS[PHP_SELF]?action=accounts\"");
				if ($frame_view) {
					echo(" target=\"maillist\"");
				}			
				echo("><img src=\"$graphic_dir/account.gif\" alt=\"$strings[l_Accounts]\" title=\"$strings[l_Accounts]\" border=\"0\"></a>\n");
			}
			if ($allowgeneral == '1')
			{
				//echo("<img src=\"$graphic_dir/spacing.gif\" alt=\"|\">");
				echo("<a href=\"$GLOBALS[PHP_SELF]?action=config\"><img src=\"$graphic_dir/config.gif\" alt=\"$strings[l_Config]\" title=\"$strings[l_Config]\" border=\"0\"></a>\n");
			}
?>	
<img src="<?=$graphic_dir ?>/spacing.gif" alt="|">
<a href="<?php echo $GLOBALS[PHP_SELF]; ?>?action=managefolders" target="_top">
                        <IMG SRC="<?=$graphic_dir ?>/manfolders.gif" alt="Manage Folders"></a>

		</td>

	</tr>
