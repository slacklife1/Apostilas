<?php
global $attachment, $attachment_name, $attachment_type, $body,$subject, $tos;

//quote fix
$tos = PrettyFormat($tos);
$body = PrettyFormat($body);
$subject = PrettyFormat($subject);

function PrettyFormat($content) {
$content = htmlentities($content);
$content = stripslashes($content);
return $content;
}

	if (isset($GLOBALS[addr_id]) && $GLOBALS[addr_id] != 0) {
		$query = "SELECT email, name FROM addresses WHERE id='$GLOBALS[addr_id]' AND user_id='$this->userid'";
		$to_res = $this->db_tool->db_query($query);
		if ($to_res == 0) {
			$this->report_error($this->db_tool->db_error(), "DB Error");
			return;
		}
		$to_row = $this->db_tool->fetch_array($to_res);
	}
	else if (isset($GLOBALS[addr]) && !empty($GLOBALS[addr])) {
		$to_row["email"] = $GLOBALS["addr"];
		$to_row["name"] = "";
	}
	

	// Check if we come from the "Choose recipients" form
global $recp;
global $recpcc;
global $recpto;


	if ($recp != "") {
	$in = implode(", ", $GLOBALS[recp]);
		
$query = "SELECT email, name FROM addresses WHERE user_id='$this->userid' AND id IN ($in)";
		$res = $this->db_tool->db_query($query);

		if ($res == 0) {
			$this->report_error($this->db_tool->db_error(), "Could not fetch recipients");
			return;
		}
	$recp="";
		while($row = $this->db_tool->fetch_array($res)) {
			$recp .= $row[email];
			$recp .= ", ";


		}
		// Remove the last ", "
		$recp = trim(substr($recp, 0, strlen($recp) - 2));
		if (!empty($rec)) {

			switch(trim($GLOBALS["recipient"])) {
				case "TO":
					$this->cur_mailer->to($rec);
					break;
				case "CC":
					$this->cur_mailer->cc($rec);
					break;
				case "BCC":
					$this->cur_mailer->bcc($rec);			
					break;
			}
		}
		$mailer = $this->cur_mailer;
	}
	
//Attach File form////////////////////////////////////////////////////////////////////////
//echo "--".$strings["l_Delete"]."--";
if($GLOBALS["submit"] == $strings[l_AttachFile] || $GLOBALS["submit"] == "Add" ||$GLOBALS["submit"] == $strings["l_Delete"]) { include("attach.form.inc.php");	
return false; 	}									

//////////////////////////////////////////////////////////////////////////////////////////



	if ($GLOBALS["submit"] == $strings["l_SpellCheck"]) {
		//$this->cur_mailer = new mailer($this->userid);
	
		$mailer = $this->cur_mailer;
	}
	else if (!isset($GLOBALS[rec])) {
		dbg("NEW CUR_MAILER");
		$this->cur_mailer = new mailer($this->userid);
		$mailer = $this->cur_mailer;
	}

	if (isset($GLOBALS[draft]) && ($GLOBALS[draft] == "true")) {

		// $this->cur_message_id is the message number

		if ($this->cur_message_id == 0) {
			$this->show();
			return;
		}

		if (!$mailer->load_draft($this->cur_message_id)) {
			$this->report_error($mailer->db_tool->db_error(), "DB Error");
                        return;
		}

	}

	if (isset($GLOBALS[action]) && ($GLOBALS[action] == "reply" || $GLOBALS[action] == "replytoall")) {
		if ($this->cur_message_id == 0) {
			$this->show();
			return;
		}
		if (!$mailer->load_reply($this->cur_message_id, $GLOBALS[action] == "replytoall")) {
			$this->report_error($mailer->db_tool->db_error(), "DB Error");
			return;
		}
		$read_status = MAIL_REPLIED;
		$tblname = "mail_" . $this->userid;
		$query = "UPDATE $tblname SET was_read='$read_status' WHERE id='$this->cur_message_id' AND user_id='$this->userid'";
		$res = $this->db_tool->db_query($query);

	}
	else if (isset($GLOBALS[action]) && $GLOBALS[action] == "forward") {
		if ($this->cur_message_id == 0) {
			$this->show();
			return;
		}
		if (!$mailer->load_forward($this->cur_message_id, $GLOBALS[action] == "replytoall")) {
			$this->report_error($mailer->db_tool->db_error(), "DB Error");
			return;
		}
		$read_status = MAIL_FORWARDED;		
		// MNS table per user patch
		$tblname = "mail_" . $this->userid;
		$query = "UPDATE $tblname SET was_read='$read_status' WHERE id='$this->cur_message_id' AND user_id='$this->userid'";
		$res = $this->db_tool->db_query($query);		

	}
	else if (isset($GLOBALS[action]) && $GLOBALS[action] == "openmail") {
		if ($this->cur_message_id == 0) {
			$this->show();
			return;
		}
		// When the mail is in one of these folders you only can read them, but not modify
		$readonly = ($this->folder == 'sent' || $this->folder == 'inbox' || $this->folder == 'bin');

		if (!$mailer->load($this->cur_message_id)) {
			$this->report_error($mailer->db_tool->db_error(), "DB Error");
			return;
		}
	}
	else if (isset($GLOBALS[action]) && $GLOBALS[action] == "showattmail") {
		if ($this->cur_mailer == 0) {
			$this->show();
			return;
		}
		
		$mailer = $this->cur_mailer;
		
		$readonly = 1;
	}
	
	if (!$readonly) {
		$query = "SELECT id, replyto, name FROM accounts WHERE user_id='$this->userid'";
		$acc_res = $this->db_tool->db_query($query);
	}
?>

<form class="mail" action="<?php echo("$GLOBALS[PHP_SELF]")?>" method="post" enctype="multipart/form-data">
<table style="width: 100%">
	<tr>
		<td style="width: 15%;"><label for="from" accesskey="F"><?php echo($strings["l_From"]);?>:<label></td>
<?php
		if ($readonly) {
			echo("<td>".$mailer->from()."</td>");
		}
		else {
?>
		<td>
			<select name="replyaccount" style="width: 100%">
<?php
				while($acc_row = $this->db_tool->fetch_array($acc_res)) {
					echo("<option value=\"$acc_row[id]\"");
					if ($acc_row[id] == $mailer->acc_id) {
						echo(" selected");
					}
					echo(">".stripslashes($acc_row["replyto"])." (".stripslashes($acc_row["name"]).")</option>");
				}
?>
			</select>
<?php
		}
?>
		</td>
	</tr>
	<tr>
<?php

		if ($readonly) {
			echo("<td><label for=\"tos\" accesskey=\"T\">To:</label><td>\n");
			echo(htmlspecialchars(stripslashes($mailer->headers->get("To"))));
		}
		else {
echo("<td><input style=\"vertical-align: middle;\" name=\"to\" type=\"image\" 
src=\"graphics/small_address.gif\" alt=\"$strings[l_To]:\" value=\"to\"> 
	<label for=\"tos\" accesskey=\"T\">$strings[l_To]:</label></td>");
			// When the user clicked on an address in the addressbook, the $to_row is set (from above)
			
			if ($to_row) {
				dbg("TO_ROW: $to_row[email]");
?>
				<td><input name="tos" size="80" value="<?php echo(stripslashes($to_row["email"])); ?>"></td>
<?php
			}
			else {

//boobert

			if($recp != "") {
				global $tos;
				if($tos!="") {$recp = "$tos, $recp";}
				echo ("<td><input name=\"tos\" size=\"80\" value=\"$recp\"></td>");

			}else{
				if($tos!="") {
				echo ("<td><input
name=\"tos\" size=\"80\" value=\"$tos\"></td>"); }else{
echo ("<td><input name=\"tos\" size=\"80\" value=\"".(htmlspecialchars(stripslashes($mailer->headers->get("To"))))."\"></td>");	}

				}
			}
		}
?>
	</tr>
	<tr>
	</tr>
	<tr>
	</tr>
	<tr>
		<td><label for="subject" accesskey="S"><?php echo($strings["l_Subject"]); ?>:</label></td>
<?php
		if ($readonly) {
			echo("<td>".htmlspecialchars($mailer->charset_decode($mailer->subject()))."</td>\n");
		}
		else {
			global $subject;
			if ($subject != "") {	
			echo("<td><input name=\"subject\" size=\"80\" value=\"$subject\"></td>");
			}else{
			echo("<td><input name=\"subject\" size=\"80\" value=\"".htmlspecialchars($mailer->charset_decode($mailer->subject()))."\"></td>");
			}		
		}
?>
	</tr>
</table>
<table style="width: 100%">
<tr>	
	<td style="width: 15%">
<?php

			echo("<label>$strings[l_Priority]:</label></td>\n");
                        echo("<td><select name=\"priority\">");
                        echo("<option value=\"".NORMAL_PRIORITY."\"></option>\n");
			echo("<option value=\"".HIGHEST_PRIORITY."\" style=\"background-color: #ff3333;\">$strings[l_HighestPriority]</option>\n");
                        echo("<option value=\"".HIGH_PRIORITY."\" style=\"background-color: #ff6666;\">$strings[l_HighPriority]</option>\n");
                        echo("<option value=\"".LOW_PRIORITY."\" style=\"background-color: #9999ff;\">$strings[l_LowPriority]</option>\n");
                        echo("<option value=\"".LOWEST_PRIORITY."\" style=\"background-color: #4444ff;\">$strings[l_LowestPriority]</option>\n");
                        echo("</select></td>");

?>
<td style="width: 10%">
	<td><label><?php echo $strings[l_Attachments];?>:</label></td>
<td>
<?
//MultiAttachments
for($i=0;$i < sizeof($attachment); $i++) {
if($attachment_name[$i] != "") {
$attachment[$i] = PrettyFormat($attachment[$i]);
$attachment_name[$i] = PrettyFormat($attachment_name[$i]);
$attachment_type[$i] = PrettyFormat($attachment_type[$i]);

echo "<input type=hidden name=attachment[] value=\"$attachment[$i]\">";
echo "<input type=hidden name=attachment_name[] value=\"$attachment_name[$i]\">";
echo "<input type=hidden name=attachment_type[] value=\"$attachment_type[$i]\">";
}
}

echo "<select>";
for($i=0;$i < sizeof($attachment); $i++) {
if($attachment_name[$i] != "") {
echo "<input type=hidden name=attachment[] value=\"$attachment[$i]\">";
echo "<input type=hidden name=attachment_name[] value=\"$attachment_name[$i]\">";
echo "<input type=hidden name=attachment_type[] value=\"$attachment_type[$i]\">";
echo "<option>$attachment_name[$i]</option><br>";
}
}
?>
</selected></td><td>
<?	echo "<input class=\"sbttn\" type=\"submit\" value=\"$strings[l_AttachFile]\" name=\"submit\">&nbsp;";

?></td>


<? //<td><input type=\"file\" name=\"NewAttachment[]\"></td> ?>


</td>
</tr>

<tr>
</tr>
</table>
<?php

if ($GLOBALS["submit"] == $strings["l_SpellCheck"])
{
	include "class.spellcheck.inc.php";
        $spellsuggest = spellcheck($mailer->body);

	echo "<HR><B>".$strings["l_SpellerUse"]."</B>";
        echo "<TABLE>";
        echo "<TR><TD>";
        echo $spellsuggest;
        echo "</TR></TD>";
        echo "</TABLE>";
	echo "<HR>";
}

?>
<input class="sbttn" type="submit" value="<?php echo($strings["l_Send"]);?>" name="submit" onclick="return validateNewMail(this.form)">
<?
if ($GLOBALS[spellcheck] == "1")
	echo "<input class=\"sbttn\" type=\"submit\" value=\"$strings[l_SpellCheck]\" name=\"submit\">&nbsp;";
?>
<input class="sbttn" type="submit" value="<?php echo($strings["l_Draft"]);?>" name="submit">
<input class="sbttn" type="reset" value="<?php echo($strings["l_Reset"]);?>">
<input type="checkbox" name="notification"> <?php echo($strings["l_Notification"]);?><br>
<?php
	echo "<textarea name=\"body\" rows=\"20\" cols=\"120\">";
	global $body;
	if($body!="") {echo("$body");}else {

        // Show the signature if the user wants to...
        if (!$readonly && !isset($GLOBALS[rec]) && ($GLOBALS[submit] != $strings[l_SpellCheck])) {
                $query = "SELECT signature, app_sig FROM conf WHERE user_id = '$this->userid'";
                $res = $this->db_tool->db_query($query);
                if ($res) {
                        $row = $this->db_tool->fetch_array($res);
                        if ($row["app_sig"]) {
                                echo("\r\n\r\n".$row["signature"]."\n\n"); } } }
	
	global $action; if($action=="reply" || $action=="forward" || $action=="replytoall") {echo ("-----Original Message-----\n"); }
        echo($mailer->decode($mailer->get_text_body()));
	
		        
        }
	echo "</textarea><br>";

?>
<input class="sbttn" type="submit" value="<?php echo($strings["l_Send"]);?>" name="submit" onclick="return validateNewMail(this.form)">
<?
if ($GLOBALS[spellcheck] == "1")
        echo "<input class=\"sbttn\" type=\"submit\" value=\"$strings[l_SpellCheck]\" name=\"submit\">&nbsp;";
?>
<input class="sbttn" type="submit" value="<?php echo($strings["l_Draft"]);?>" name="submit">
<input class="sbttn" type="reset" value="<?php echo($strings["l_Reset"]);?>"><br>
<?php

global $return;

if ($return == "welcome")
	echo("<input type=\"hidden\" name=\"return\" value=\"welcome\">");

?>

<input type="hidden" name="action" value="storemail">
<input type="hidden" name="update" value="<?php if ($GLOBALS[action] == "openmail") echo("1"); else echo("0");?>">
</form>
