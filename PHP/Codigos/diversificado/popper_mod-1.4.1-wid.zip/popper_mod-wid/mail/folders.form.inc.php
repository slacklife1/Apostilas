<? include('skin.db'); ?>
<table width="100%">
<form action="<?php echo ("$GLOBALS[PHP_SELF]?action=addfolder\""); ?> method="post">
<tr>
	<td width="50%">
		<u>Your Folders:</u>
	</td>

	<td width="25%">
		<input type="submit" name="hitsubmit" value="Add New Folder">
	</td>
	
</tr>
</form>
</table>

<table width="100%">

<?php
	
	$tblname = "mail_" . $this->userid;

	$query = "SELECT DISTINCT folder from $tblname";
	$result = $this->db_tool->db_query($query);

	while($folders = mysql_fetch_row($result))
	{

		switch($folders[0])
		{
			case 'inbox';
			case 'outbox';
			case 'sent';
			case 'bin';
			case 'drafts';
			case 'trash';
			case 'saved';
			
				break;

			default:

				$pself = $GLOBALS["PHP_SELF"];

				echo "<tr>";
					echo "<td width=\"70%\">";
						echo "$folders[0]";
					echo "</td>";
			
					echo "<td width=\"10%\">";
						echo "<a href=\"$pself?action=renfolder&oldfoldername=$folders[0]\">Rename</a>";
					echo "</td>";
		
					echo "<td width=\"10%\">";
						echo "<a href=\"$pself?action=delfolder&oldfoldername=$folders[0]\">Delete</a>";
					echo "</td>";
		
					echo "<td width=\"10%\">";
						echo "<a href=\"$pself?action=emptyfolder&oldfoldername=$folders[0]\">Empty</a>";
					echo "</td>";
				echo "<tr>";
		}
	}
?>

</table>
<table width="100%">
<tr>
        <td>
                <u>Standard Folders:</u>
        </td>
</tr>
</table>
<table width="100%">

<?php

        $FolderList = array(
                'inbox',
                'sent',
                'bin',
                'drafts',
                'saved',
        );

        foreach ($FolderList as $FolderName)
        {
                echo "<tr>";
                        echo "<td width=\"70%\">";
                                echo $FolderName;
                        echo "</td>";

                        echo "<td width=\"10%\">";

                        echo "</td>";

                        echo "<td width=\"10%\">";

                        echo "</td>";

                        echo "<td width=\"10%\">";
				echo "<a href=\"$pself?action=emptyfolder&oldfoldername=$FolderName\">Empty</a>";
                        echo "</td>";
                echo "</tr>";
        }
?>
</table>
<br>
<a href="<?php echo $GLOBALS[PHP_SELF]; echo "?action=frameset"; ?>">
<IMG SRC="<?=$graphic_dir ?>/sendandreceive.gif">
<i><?php echo $strings["l_Close1"]; echo " "; echo $strings["l_Folders"]; echo " "; echo $strings["l_Close2"]; ?></i></a>
<br>
<a href="<?php echo $GLOBALS[PHP_SELF];?>">
<IMG SRC="<?=$graphic_dir ?>/logo.gif">
<i><?php echo $strings["l_Close1"]; echo " "; echo $strings["l_Folders"]; echo " "; echo $strings["l_Close3"]; ?></i></a>
</body></html>
