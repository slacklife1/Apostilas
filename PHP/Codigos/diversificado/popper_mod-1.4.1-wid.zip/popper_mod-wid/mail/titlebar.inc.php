<? include_once('skin.db');
//$graphics="graphics"; //Skinning ?> 
<table class="windowborder" width="100%" border="0" align="center">
	<tr class="titlebar">
		<td colspan="3">
			<table class="titlebar" width="100%" border="0">
				<tr>
					<td>
						<a href="<?php echo("$GLOBALS[PHP_SELF]");?>"><img src="<?=$graphic_dir ?>/logo.gif" alt="" title="<?php echo($strings["l_MainView"]);?>" style="vertical-align: middle;" border="0"></a><?php echo("$GLOBALS[titlebar] <b>$this->name</b>");?>
					</td>
					<td>
						<a href="<?php echo("$GLOBALS[PHP_SELF]?action=logoff");?>"><img src="<?=$graphic_dir ?>/logoff.gif" alt="<?php echo($strings["l_Logoff"]);?>" title="<?php echo($strings["l_Logoff"]);?>" align="right" border="0"></a>
						<a href="<?php echo("$GLOBALS[PHP_SELF]?action=help");?>" target="_blank"><img src="<?=$graphic_dir ?>/help.gif" alt="<?php echo($strings["l_Help"]);?>" title="<?php echo($strings["l_Help"]);?>" align="right" border="0"></a>	
					</td>
				</tr>
			</table>
		</td>
	</tr>
