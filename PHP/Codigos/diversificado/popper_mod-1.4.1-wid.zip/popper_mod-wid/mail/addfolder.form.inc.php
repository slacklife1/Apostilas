Please name your new folder.<br>
<form action="<?php echo ("$GLOBALS[PHP_SELF]?action=addfolder\""); ?> method="post">
<input type="text" name="foldername" size="30" maxlength="30"><br><br>
<input type="submit" name="hitsubmit" value="Add Folder">&nbsp;
<a href="<?php echo ("$GLOBALS[PHP_SELF]?action=managefolders\">"); ?>Cancel</a>
</form>
</body></html>
