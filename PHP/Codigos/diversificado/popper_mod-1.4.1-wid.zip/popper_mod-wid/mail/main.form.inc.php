<tr class="bw">
	<td width="75%">

<?php
		include("welcome.form.inc.php");
?>

	</td>
</tr>
</table>

