<?php

	// The file which describes the upper part of the HTML code
	$top_part = "top.inc.php";
	// The file which describes the bottom part of the HTML code
	$bottom_part = "bottom.inc.php";
	// Allow the access to other mail-servers than localhost? true/false
	$only_localhost = false;

	// If this value is set to true, the user needs to confirm the creation of the account
	// He'll receive an E-mail with a link to activate it.
	// Set it to false if you don't need this
	$user_confirmation = false;

	// Set this var only to true if you don't have access to the document-root and popper.inc.php
	// was moved into the document-root
	$in_docroot = false;

	// Login greeting
	// please use the administration panel to set the above values
	
	include("./admin/popper.inc.php");
	$connection = mysql_connect($host, $user, $pass) or die ("Unable to read configuration, cannot connect to server");
	$query = "SELECT * FROM config";
	$result = mysql_db_query($dbname, $query, $connection);
	
	if ($result == 0)
	{
		echo 'It seems that this copy of popper_mod has not been configured.  Please do so using the administration
			panel';
		die;
	}

	$row = mysql_fetch_row($result);
	
	// 0 = signuptype
        // 1 = authtype
        // 2 = delimiter
        // 3 = allowaccount
        // 4 = allowgeneral
        // 5 = popname
        // 6 = greeting
        // 7 = titlebar
        // 8 = browsertitle
	// 9 = spellcheck
	// 10 = dictionaryurl
	// 11 = domainlist
        // 12 = acceptdomain
	// 13 = maximumsize

	$signuptype = $row[0];
	$authtype = $row[1];
	$delimiter = $row[2];
	$allowaccount = $row[3];
	$allowgeneral = $row[4];
	$popname = $row[5];
	$greeting = $row[6];
	$titlebar = $row[7];
	$browsertitle = $row[8];
	$spellcheck = $row[9];
	$dictionaryurl = $row[10];
	$domainlist = $row[11];
	$acceptdomain = $row[12];
	$maximumsize = $row[13];
?>
