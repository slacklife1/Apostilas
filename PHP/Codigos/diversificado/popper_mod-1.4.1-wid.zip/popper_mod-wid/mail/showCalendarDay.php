<?php

require("Calc.php");

if(empty($year) || empty($month) || empty($day))
{
	$year = Date_Calc::dateNow("%Y");
	$month = Date_Calc::dateNow("%m");
	$day = Date_Calc::dateNow("%d");
}

$day_cal = Date_Calc::getCalendarWeek($day,$month,$year);
$view = "day";

?>
<CENTER>
<TABLE border=0 bgcolor=#1e1e1e cellspacing=1 width=80%>

<TR>
<TD align=center bgcolor=#d0d0d0>
<?php include("showNavBar.php"); ?>
</TD>
</TR>

<TR bgcolor=#e0e0e0>
<TD align=center>
<A href="<?php echo $PHP_SELF."?".Date_Calc::prevDay($day,$month,$year,"year=%Y&month=%m&day=%d"); ?>">&lt;&lt;</A>
&nbsp;
<?php	echo Date_Calc::dateFormat($day,$month,$year,"<b>%A, %B %e, %Y</b>%n");
?>

&nbsp;
<A href="<?php echo $PHP_SELF."?date=".Date_Calc::nextDay($day,$month,$year,"year=%Y&month=%m&day=%d"); ?>">&gt;&gt;</A>
</TD>
</TR>

<?php

$curr_day = Date_Calc::dateNow();

for($hour = 8; $hour < 18; $hour++)
{
	echo "<TR><TD bgcolor=#f1f1f1>\n";
		if($hour < 13)
			echo "$hour:00";
		else
			echo ($hour - 12).":00";
	echo "</TD></TR>\n";
	
}

?>
</TABLE>
</CENTER>
