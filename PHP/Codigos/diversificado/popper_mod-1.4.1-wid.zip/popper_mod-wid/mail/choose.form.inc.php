<? global $body,$subject,$tos, $attachment, $attachment_name, $attachment_type; ?>
<?
$tos = PrettyFormat($tos);
$body = PrettyFormat($body);
$subject = PrettyFormat($subject);

function PrettyFormat($content) {
$content = htmlentities($content);
$content = stripslashes($content);
return $content;}
?>
<form class="mail" action="<?php echo("$GLOBALS[PHP_SELF]?action=choosen")?>" method="post">
<?php

	$this->show_recipients();
?>
<br>
<center>
<input type=hidden name=body value="<?=$body; ?>">
<input type=hidden name=subject value="<?=$subject; ?>">
<input type=hidden name=tos value="<?=$tos; ?>">
<?
//MultiAttachments
for($i=0;$i < sizeof($attachment); $i++) {
$attachment[$i] = PrettyFormat($attachment[$i]);
$attachment_name[$i] = PrettyFormat($attachment_name[$i]);
$attachment_type[$i] = PrettyFormat($attachment_type[$i]);

echo "<input type=hidden name=attachment[] value=\"$attachment[$i]\">";
echo "<input type=hidden name=attachment_name[] value=\"$attachment_name[$i]\">";
echo "<input type=hidden name=attachment_type[] value=\"$attachment_type[$i]\">";
}


?>
	<input class="button" type="submit" value="<?php echo(strtoupper($GLOBALS[field])); ?>" name="recipient">
</center>
<br>
</form>
