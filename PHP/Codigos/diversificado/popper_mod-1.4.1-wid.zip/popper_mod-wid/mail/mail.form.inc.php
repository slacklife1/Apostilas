<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td class="mailwindow">
			<?php $this->show_folder_content(); ?>
		</td>
	</tr>
</table>
<?php
	echo("<iframe src=\"$GLOBALS[PHP_SELF]?action=mail_cont\" scrolling=\"yes\" name=\"mail\" width=\"100%\" style=\"height: ".$this->config["mail_rows"]."em; border-top: medium solid silver;\" frameborder=\"0\" marginwidth=\"0\" marginheight=\"0\"></iframe>");
?>
