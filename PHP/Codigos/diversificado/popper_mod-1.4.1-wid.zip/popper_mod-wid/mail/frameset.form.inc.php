<tr class="window">
<?
if($this->config[side_nav] || $this->config[side_address]) {
echo('<td bgcolor=silver height=100% valign=top>');
}
if ($this->config[side_nav]) {
include("side.nav.inc.php"); //WID boobert
} 


echo('<p class="windowtitle">');

//make this a user option
if ($this->config[side_address]) {
echo('<a href="/mail/index.php?action=newaddress">Add contact...</a></p>');
$this->side_address(); }

?></td>
	<td width="95%">

<?php
		include("mail.form.inc.php");
?>

	</td>
</tr>


