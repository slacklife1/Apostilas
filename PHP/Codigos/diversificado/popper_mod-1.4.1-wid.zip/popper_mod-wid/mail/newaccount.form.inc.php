<?php

	if ($GLOBALS["update"] == 1) {
		$query = "SELECT * FROM accounts WHERE id = '$this->cur_account_id' AND user_id='$this->userid'";
		$res = $this->db_tool->db_query($query);
		if ($res == 0) {
			$this->report_error($this->db_tool->db_error(), $strings["l_DBError"]);
			return;
		}
		$row = $this->db_tool->fetch_array($res);
	}
?>
<br>
<center>
<h2>
<?php echo($strings["l_NewAcc"]);?>
</h2>

<form action="<?php echo("$GLOBALS[PHP_SELF]");?>" method="post">
	<table cellpadding="5">

	</table>
	<br><hr><br>
	&nbsp;
	<input class="button" type="submit" value="<?php echo $strings["l_Store"];?>">
	<input type="hidden" name="update" value="<?php echo($GLOBALS["update"]);?>">
	<input type="hidden" name="name" value="extra">
	<input type="hidden" name="action" value="storeaccount">
</form>
</center>
