<?php 

// Requirements: 
// 1: Your system must have ispell installed and in the path. If you have 
// it installed but not in the path, edit this script to call the correct 
// path for ispell.  You can get ispell at http://www.gnu.org/software/ispell/ispell.html
// 2: Your server must be set up to allow the Apache/PHP user, which is 
// usually "nobody", to have write access to ./tmp.  You need this anyway
// for email attachments to work.

function spellcheck( $inString ) { 
// regexp to ignore html tags. 

$inString = eregi_replace( "<[^>]*>", " ", $inString); 

mt_srand( (double) microtime() * 1000000 ); 
$rfn = mt_rand(); 
$scf = fopen( "./tmp/in-$rfn", "w+" ); 
fwrite( $scf, $inString ); 
fclose( $scf ); 

$cmdline = "ispell -l < ./tmp/in-$rfn > ./tmp/out-$rfn"; 
system( $cmdline ); 
unlink( "./tmp/in-$rfn" ); 

if( filesize( "./tmp/out-$rfn" ) > 1 ) { 
$winc = 0; 
$scf = fopen( "./tmp/out-$rfn", "r" ); 
while( !feof( $scf ) ) { 
$badwords[ $winc ] = trim( fgets( $scf, 255 ) ); 
$goodwords[$winc] = "<A HREF=\"$GLOBALS[dictionaryurl]$badwords[$winc]\" style=\"color: red;\" target=\"_blank\">".$badwords[$winc]."</a>"; 
$winc++; 
} 
fclose( $scf ); 
$winc--; 

$badwords = array_unique($badwords);
$goodwords = array_unique($goodwords);

for( $ridx = 0; $ridx < $winc; $ridx++ ) { 
$inString = str_replace( $badwords[ $ridx ], $goodwords[ $ridx ], $inString ); 
} 
} 
unlink( "./tmp/out-$rfn" ); 
return $inString; 
} 

?>
