<?php
include('skin.db');
function num_mails($folder = "", $total = "false", $userid)
{

	$tblname = "mail_" . $userid;

	if ($total == "true")
		$query = "SELECT id FROM $tblname WHERE folder='$folder' AND is_mime!=9";
	if ($total == "false")
		$query = "SELECT id FROM $tblname WHERE folder='$folder' AND was_read=0";

        $result = mysql_query($query);
	echo mysql_num_rows($result);

}

$this->get_mails();

?>

<BR>
<TABLE cellpadding=0 cellspacing=0 align="center" width="70%">
<TR bgcolor="#FFFFFF" align="center">
<TD align="left" bgcolor="#6d7b8d" width="20%">
        <font style="color: white;">Tasks</font></TD>
<TD align="left" bgcolor="#FFFFFF">&nbsp;</TD>
</TR>
</TABLE>
<TABLE cellpadding=0 cellspacing=0 align="center" width="70%" class="bw">
<HR>
<TR>
	<TD><A HREF="<?php echo $GLOBALS[PHP_SELF];?>?action=frameset"><IMG SRC="<?=$graphic_dir ?>/sendandreceive.gif"></A></TD>
	<TD><A HREF="<?php echo $GLOBALS[PHP_SELF];?>?action=frameset">Go directly to my Inbox</A></TD>
        <TD><I>read your new mail</I></TD>
</TR>
<TR>
	<TD><A HREF="<?php echo $GLOBALS[PHP_SELF];?>?action=newmail&return=welcome"><IMG SRC="<?=$graphic_dir ?>/newmail.gif"></A></TD>
	<TD><A HREF="<?php echo $GLOBALS[PHP_SELF];?>?action=newmail&return=welcome">Compose a new message</A></TD>
        <TD><I>send mail to someone else</I></TD>
</TR>
<TR>
	<TD><A HREF="<?php echo $GLOBALS[PHP_SELF];?>?action=addressbook"><IMG SRC="<?=$graphic_dir ?>/address.gif"></A></TD>
	<TD><A HREF="<?php echo $GLOBALS[PHP_SELF];?>?action=addressbook">Open my Addressbook</A></TD>
        <TD><I>find an address</I></TD>
</TR>
<TR>
	<TD><A HREF="<?php echo $GLOBALS[PHP_SELF];?>?action=managefolders"><IMG height=20 width=20 SRC="<?=$graphic_dir ?>/move.gif"></A></TD>
	<TD><A HREF="<?php echo $GLOBALS[PHP_SELF];?>?action=managefolders">Manage folders</A></TD>
	<TD><I>add and work with your mail folders</I></TD>
</TR>
<TR>
	<TD><A HREF="<?php echo $GLOBALS[PHP_SELF];?>?action=config"><IMG SRC="<?=$graphic_dir ?>/config.gif"></A></TD>
	<TD><A HREF="<?php echo $GLOBALS[PHP_SELF];?>?action=config">Change my configuration</A></TD>
        <TD><I>set webmail options</I></TD>
</TR>
<TR>
	<TD><A HREF="<?php echo $GLOBALS[PHP_SELF];?>?action=help" target="_blank"><IMG SRC="<?=$graphic_dir ?>/logo.gif"></A></TD>
	<TD><A HREF="<?php echo $GLOBALS[PHP_SELF];?>?action=help" target="_blank">Open help page</A></TD>
        <TD><I>webmail instructions</I></TD>
</TR>
</TABLE>
<BR>

<TABLE cellpadding=0 cellspacing=0 align="center" width="70%">
<TR bgcolor="#FFFFFF" align="center">
<TD align="left" bgcolor="#6d7b8d" width="20%">
        <font style="color: white;">Standard Folders</font></TD>
<TD width="58%"></TD>
<TD align="left" width="11%">New</TD>
<TD align="left" width="11%">Total</TD>
</TR>
</TABLE>
<TABLE cellpadding=0 cellspacing=0 align="center" width="70%" class=bw>
<HR>
<TR>
	<TD WIDTH="50%"><A HREF="<?php echo $GLOBALS[PHP_SELF];?>?action=frameset&folder=inbox">Inbox</A></TD>
	<TD WIDTH="30%"><I>open folder</I></TD>
	<TD WIDTH="10%"><?php num_mails("inbox", "false", $this->userid);?></TD>
	<TD WIDTH="10%"><?php num_mails("inbox", "true", $this->userid);?></TD>
</TR>
<TR>
	<TD WIDTH="50%"><A HREF="<?php echo $GLOBALS[PHP_SELF];?>?action=frameset&folder=sent">Sent Items</A></TD>
	<TD WIDTH="30%"><I>open folder</I></TD>
	<TD WIDTH="10%">0</TD>
	<TD WIDTH="10%"><?php num_mails("sent", "true", $this->userid);?></TD>
</TR>
<TR>
	<TD WIDTH="50%"><A HREF="<?php echo $GLOBALS[PHP_SELF];?>?action=frameset&folder=bin">Recycle Bin</TD>
	<TD WIDTH="30%"><I>open folder</I></TD>
	<TD WIDTH="10%"><?php num_mails("bin", "false", $this->userid);?></TD>
	<TD WIDTH="10%"><?php num_mails("bin", "true", $this->userid);?></TD>
</TR>
<TR>
	<TD WIDTH="50%"><A HREF="<?php echo $GLOBALS[PHP_SELF];?>?action=frameset&folder=drafts">Drafts</TD>
	<TD WIDTH="30%"><I>open folder</I></TD>
	<TD WIDTH="10%">0</TD>
	<TD WIDTH="10%"><?php num_mails("drafts", "true", $this->userid);?></TD>
</TR>
</TR>
<TR>
	<TD WIDTH="50%"><A HREF="<?php echo $GLOBALS[PHP_SELF];?>?action=frameset&folder=saved">Saved Messages</TD>
	<TD WIDTH="30%"><I>open folder</I></TD>
	<TD WIDTH="10%"><?php num_mails("saved", "false", $this->userid);?></TD>
	<TD WIDTH="10%"><?php num_mails("saved", "true", $this->userid);?></TD>
</TR>
</TABLE>
<BR>

<TABLE cellpadding=0 cellspacing=0 align="center" width="70%" class=bw>
<TR bgcolor="#FFFFFF" align="center">
<TD align="left" bgcolor="#6d7b8d" width="20%">
        <font style="color: white;">Your Folders</font></TD>
<TD width="58%"></TD>
<TD align="left" width="11%">New</TD>
<TD align="left" width="11%">Total</TD>
</TR>
</TABLE>
<TABLE cellpadding=0 cellspacing=0 align="center" width="70%" class=bw>
<HR>

<?php
	$tblname = "mail_" . $this->userid;

        $query = "SELECT DISTINCT folder from $tblname";
        $result = $this->db_tool->db_query($query);

        while($folders = mysql_fetch_row($result))
        {

                switch($folders[0])
                {
                        case 'inbox';
                        case 'outbox';
                        case 'sent';
                        case 'bin';
                        case 'drafts';
                        case 'trash';
                        case 'saved';

                                break;

                        default:

			echo("<TR><TD WIDTH=\"50%\"><A HREF=\"$GLOBALS[PHP_SELF]?action=frameset&folder=$folders[0]\">
				$folders[0]</TD>");
			echo("<TD WIDTH=\"30%\"><I>open folder</I></TD>");
			
			echo "<TD WIDTH=\"10%\">";
			num_mails($folders[0], "false", $this->userid);
			echo "</TD><TD WIDTH=\"10%\">";
			num_mails($folders[0], "true", $this->userid);
			echo "</TD>";
		}
	}

?>
</TABLE>
<BR>
<BR>
