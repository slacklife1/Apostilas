<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/REC-html40/loose.dtd">
<HTML>
<HEAD>
<TITLE><?php echo($GLOBALS[browsertitle]);?></TITLE>
<META http-equiv="Content-Type" content="text/html; charset=utf-8">
<? $Skin == $this->config[skins]; //WID Skin
include_once('skin.db'); ?>
<LINK REL=stylesheet TYPE="text/css" HREF="<?=$stylesheet ?>">
<?php 

	if ($form == "newmail")
		echo "<SCRIPT LANGUAGE=\"JavaScript\" SRC=\"popper.js\"></SCRIPT>";

?>
</HEAD>
<BODY>
