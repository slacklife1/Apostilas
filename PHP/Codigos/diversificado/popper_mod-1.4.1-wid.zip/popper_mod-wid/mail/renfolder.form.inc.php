What would you like to rename <?php echo $GLOBALS["oldfoldername"]; ?> to ?<br>
<form action="<?php echo ("$GLOBALS[PHP_SELF]?action=renfolder\""); ?> method="post">
<input type="text" name="newfoldername" size="30" maxlength="30"><br><br>
<input type="hidden" name="oldfoldername" value="<?php echo $GLOBALS["oldfoldername"]; session_unregister("oldfoldername"); ?>">
<input type="submit" name="hitsubmit" value="Rename Folder">&nbsp;
<a href="<?php echo $GLOBALS[PHP_SELF];?>?action=managefolders">Cancel</a>
</form>
</body></html>
