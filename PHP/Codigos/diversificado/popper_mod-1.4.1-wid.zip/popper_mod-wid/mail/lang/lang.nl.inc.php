<?php
	$locale = "dutch";

        $strings["l_Add"]               = "Add";
        $strings["l_AttachFile"]        = "Add Attachments";
	$strings["l_Inbox"]		= "Postvak in";
	$strings["l_Outbox"]		= "Postvak uit";
	$strings["l_SentMail"]		= "Verzonden";
	$strings["l_RecycleBin"]	= "Prullebak";
	$strings["l_Drafts"]		= "Concepten";
	$strings["l_NoAddress"]		= "Geen adressen gevonden";
	$strings["l_ShowDetails"]	= "Laat details zien";
	$strings["l_SendMail"]		= "Verstuur e-mail";
	$strings["l_ClickName"]		= "Klik op een naam om de details te zien...";
	$strings["l_NoMails"]		= "Geen e-mails in deze map";
	$strings["l_To"]		    = "Aan";
	$strings["l_From"]			= "Van";
	$strings["l_Date"]			= "Datum";
	$strings["l_Subject"]		= "Onderwerp";
	$strings["l_GetAttachment"]	= "Bijlagen toevoegen";
	$strings["l_NoMsgSelected"]	= "Geen bericht geselecteerd";
	$strings["l_Name"]			= "Naam";
	$strings["l_LastName"]		= "Achternaam";
	$strings["l_NickName"]		= "Gebruikersnaam";
	$strings["l_Address"]		= "Adres";
	$strings["l_ZIP"]		    = "Postcode";
	$strings["l_Town"]			= "Woonplaats";
	$strings["l_State"]			= "Provincie";
	$strings["l_Country"]		= "Land";
	$strings["l_Phone"]			= "Telefoon";
	$strings["l_MobilePhone"]	= "Mobiel nummer";
	$strings["l_AccountName"]	= "Account naam";
	$strings["l_ReplyTo"]		= "Antwoord aan E-mail";
	$strings["l_POPServer"]		= "POP-Server";
	$strings["l_POPLogin"]		= "POP Login-naam";
	$strings["l_Server"]		= "Server";
	$strings["l_Keep"]			= "Laat e-mails op de server staan";
	$strings["l_RemoveDel"]		= "Verwijder de e-mails van de server na het 
verwijderen (uit de prullebak)";
	$strings["l_CheckMails"]	= "Controleer op nieuwe email na het inloggen";
	$strings["l_SendDirect"]	= "Verstuur e-mails meteen, bewaar ze niet in het 
postvak uit.";
	$strings["l_AddAddress"]	= "Plaats het e-mailadres van de ontvangen e-mail 
in mijn adresboek.";
	$strings["l_Show"]			= "Zien";
	$strings["l_MailsPerPage"]	= "E-mails per pagina";
	$strings["l_Lines"]			= "lijnen ineens";
	$strings["l_Singature"]		= "Handtekening";
	$strings["l_AppSig"]		= "Voeg mijn handtekening toe aan elke e-mail";
	$strings["l_Attachment"]	= "Bijlagen";
	$strings["l_MainView"]		= "Ga naar de eerste site";
	$strings["l_NewAccount"]	= "Nieuw account";
	$strings["l_EditAccount"]	= "Account informatie bijwerken";
	$strings["l_DelAccount"]	= "Verwijder dit account";
	$strings["l_AccDetails"]	= "Account details";
	$strings["l_DelAck"]		= "Weet je zeker dat je dit artikel wilt 
verwijderen?";
	$strings["l_DelAck2"]		= "Bevestig a.u.b deze verwijdering";
	$strings["l_AddressDetails"]= "Adres details";
	$strings["l_NewAddress"]	= "Nieuw adres";
	$strings["l_EditAddress"]	= "Werk dit adres bij";
	$strings["l_DelAddress"]	= "Verwijder dit adres";
	$strings["l_AddContact"]	= "Contacten toevoegen...";
	$strings["l_Logoff"]		= "Log-uit";
	$strings["l_Help"]			= "Help";
	$strings["l_Cancel"]		= "Annuleer";
	$strings["l_ServerConnect"]	= "Kan geen verbinding maken met de MySQL 
server";
	$strings["l_OpenDB"]		= "De database kan niet geopend worden";
	$strings["l_Delete"]		= "Verwijder";
    //$strings["l_WelcomeLogin"]= 'If this is your first time to visit our 
new mail interface, click on `Set up my Mailbox`<br><br>If you would like to 
set up Outlook Express, you can find step by step instructions by clicking 
<a 
href="http://www.ectisp.net/mailhelp/ie/ie5text.html"><u>here</u>.</a><br><br>If 
you would like to go to our discussion forum and leave feedback on the new 
webmail system, click <a 
href="http://www.symatec-computer.com/forums/"><u>here</u>.</a>';
	$strings["l_WelcomeLogin"]	= 'Als je al een account hebt klik dan op " 
Controleer mijn e-mail " om verder te gaan, of, klik op " Ik wil een 
e-mailadres " om een nieuw account aan te maken.';
	$strings["l_Welcome"]		= "Welkom";
	$strings["l_Login"]			= "Controleer mijn e-mail";
	$strings["l_NewUser"]		= "Ik wil een e-mailadres";
	$strings["l_PwdFail"]		= "Je password  is in-correct. Probeer het 
nogmaals"	;
	$strings["l_Account"]		= "Account";
	$strings["l_AccInfo"]		= "Je kunt nu als eerste je account informatie 
invullen";
	$strings["l_AccCreated1"]	= "Je account was succesvol aangemaakt,  klik 
'OK' en log dan in op je e-mail account.";
	$strings["l_AccCreated2"]	= "Account gemaakt";
	$strings["l_DelCancel"]		= "Verwijderen geannuleerd!";
	$strings["l_UserDelFail"]	= "kan niet verwijderd worden uit de 
datebase.<br>nProbeer het nogmaals!";
	$strings["l_Error"]			= "Fout";
	$strings["l_UserDel"]		= "De gebruiker en alle mails zijn verwijderd uit de 
database";
	$strings["l_UserDel2"]		= "Gebruiker is verwijderd";
	$strings["l_LoggedOff"]		= "Uitgelogd";
	$strings["l_LogoffMsg"]		= "Je bent uitgelogd.";
	$strings["l_GoodBye"]		= "Tot ziens";
	$strings["l_NewMail"]		= "Nieuwe e-mail";
	$strings["l_ShowSources"]	= "Laat de bronnen zien";
	$strings["l_OpenMail"]		= "Open de e-mail";
	$strings["l_ReplyMail"]		= "Beantwoord";
	$strings["l_ReplyAllMail"]	= "Beantwoord allen";
	$strings["l_ForwardMail"]	= "Doorsturen";
	$strings["l_ShowMail"]		= "Laat de e-mail zien";
	$strings["l_Choosen"]		= "Gekozen";
	$strings["l_FillInAll"]		= "Vul a.u.b alle velden in!";
	$strings["l_SendReceive"]	= "Verzenden en ontvangen";
	$strings["l_Config"]		= "Configuratie";
	$strings["l_LoginName"]		= "E-mail Adres";
	$strings["l_Pwd"]		    = "Password";
	$strings["l_Select"]		= "Selecteer eerst een e-mail";
	$strings["l_DeleteMultiple"]= "Verwijder de geselecteerde e-mails";
	$strings["l_AddressBook"]	= "Adresboek";
	$strings["l_Accounts"]		= "Accounts";
	$strings["l_ManageAcc"]		= "Beheer je accounts";
	$strings["l_UserName"]		= "Gebruikersnaam";
	$strings["l_EMailAddress"]	= "E-Mail adres";
	$strings["l_ConfPwd"]		= "Bevestig het password";
	$strings["l_NewUserMsg"]	= "Vul je voledige e-mailadres in. Als voorbeeld: 
<b>jouwnaam@data-connect.nl</b> <br><br> Passwords zijn case sensitive, wat 
betekend kleine-en hoofdletters daar waar nodig! `password` en `PaSsWoRD` 
zijn NIET gelijk.<br>";
	$strings["l_Action"]		= "Welke aktie kies je?";
	$strings["l_DBError"]		= "Database fout";
	$strings["l_UserInfoFail"]	= "De gebruikers configuratie kon niet opgehaald 
worden";
	$strings["l_AccInfoFail"]	= "Kon geen account onformatie ophalen";
	$strings["l_ChooseRec"]		= "Selecteer de ontvangers a.u.b";
	$strings["l_FolderMove"]	= "Deze e-mail is verplaatst naar de volgende 
map";
	$strings["l_FolderMoveFail"]= "Deze e-mail kon NIET verplaatst worden naar 
de volgende map";
	$strings["l_AttFail"]		= "Deze bijlage kan niet uitgepakt worden";
	$strings["l_DelMail"]		= "Verwijder e-mail";
	$strings["l_DelMailQuest"]	= "Wilt u deze e-mail echt verwijderen?";
	$strings["l_DelMails"]		= "Verwijder e-mails";
	$strings["l_DelMailsQuest"]	= "Wilt u deze e-mails echt verwijderen?";
	$strings["l_ServerDel"]		= "Deze e-mail is verwijderd van de server";
	$strings["l_ServerDelFail"]	= "Deze e-mail kon NIET verwijderd worden van 
de server";
	$strings["l_AllDel"]		= "Alle e-mails zijn verwijderd";
	$strings["l_AllDelFail"]	= "Niet alle e-mails konder verwijderd worden";
	$strings["l_MailStoreFail"]	= "The mail could not be stored in the 
database";
	$strings["l_MailSentSucc"]	= "E-mail is succesvol verzonden";
	$strings["l_DelAddress"]	= "Verwijder dit adres";
	$strings["l_DelAddressConf"]= "Bevestig het verwijderen van dit adres";
	$strings["l_AddressDel"]	= "Het adres is verwijderd";
	$strings["l_AddressDelFail"]= "Het adres kon niet verwijderd worden";
	$strings["l_DelAccount"]	= "Verwijder dit account";
	$strings["l_DelAccountConf"]= "Bevestig het verwijderen van dit account";
	$strings["l_AccountDel"]	= "Het account is verwijderd";
	$strings["l_AccountDelFail"]= "Het account kon niet verwijderd worden";
	$strings["l_Language"]		= "Taal";
	$strings["l_Remember"]		= "Vink dit aan zodat het systeem je e-mailadres 
onthoud";
	$strings["l_SubjectSize"]	= "karakters van het onderwerp";
	$strings["l_AddressSize"]	= "Karakters van het adres";
	$strings["l_Store"]			= "Verder";
	$strings["l_Draft"]			= "Opslaan in de map concepten";
	$strings["l_Reset"]			= "Wissen";
	$strings["l_NewAddress"]	= "Enter het adresboek";
	$strings["l_Addressbook"]	= "Adresboek";
	$strings["l_Folders"]		= "Mappen";
	$strings["l_FromName"]		= "Naam";
	$strings["l_AccName"]		= "Account naam";
	$strings["l_NewAcc"]		= "Welkom.<br> Je account is gemaakt.";
	$strings["l_ComposeMail"]	= "E-mail maken";
	$strings["l_Send"]			= "Verstuur";
	$strings["l_Print"]			= "Open printer vriendelijke site";
	$strings["l_DeleteAll"]		= "Verwijder alle e-mail in de  huidige map";
	$strings["l_DeleteSel"]		= "Verwijder deze e-mailD";
	$strings["l_CheckRep"]		= "Controleer op nieuwe e-mail elke";
	$strings["l_Minutes"]		= "minuten";
	$strings["l_Previous"]		= "Vorige";
	$strings["l_Current"]		= "Huidige";
	$strings["l_Next"]			= "Volgende";
	$strings["l_Priority"]		= "Prioriteit";
	$strings["l_LowestPriority"]= "Laagste";
	$strings["l_LowPriority"]	= "Laag";
	$strings["l_HighPriority"]	= "Gemiddeld";
	$strings["l_HighestPriority"]= "Hoogste";
	$strings["l_Notification"]	= "Vraag een leesbevestiging";
	$strings["l_NotifyQuest"]	= "De afzender vraagt om een leesbevestiging.";
	$strings["l_NotifyQuest2"]	= "Wilt u het versturen?";
	$strings["l_SendNot"]		= "Stuur een waarschuwing";
	$strings["l_NotMsg"]		= "Het volgende bericht is gezien.rnDit is geen 
garantie dat het bericht is gelezen of begrepen.";
	$strings["l_SentAt"]		= "Verstuurd op";
	$strings["l_ReadAt"]		= "Gelezen op";
	$strings["l_NotiSub"]		= "Lezen";
	$strings["l_FirstP"]		= "Eerste site";
	$strings["l_LastP"]			= "Laatste site";
	$strings["l_FromTo"]		= "Laat de e-mails zien";
	$strings["l_ToM"]			= "Aan";
	$strings["l_Order"]			= "Gesorteerd op";
	$strings["l_AddAddr"]		= "Voeg gemarkeerde e-mailverstuurders toe aan het 
adresboek";
	$strings["l_Block"]			= "Block gemarkeerde verstuurders";
	$strings["l_ShowBlocked"]	= "Laat de geblokeerde verstuurders zien";
	$strings["l_Blocked"]		= "Geblokeerde verstuurders";
	$strings["l_View"]			= "Zien";
	$strings["l_FullView"]		= "Mappenlijst en contacten";
	$strings["l_MidView"]		= "Mappenlijst";
	$strings["l_MinView"]		= "Alleen mappen";
	$strings["l_NextMail"]		= "Ga naar de volgende e-mail";
	$strings["l_PrevMail"]		= "Ga naar de vorige e-mail";
	$strings["l_ChangePwd"]		= "Verander je password";
	$strings["l_PwdMismatch1"]	= "Password fout";
	$strings["l_PwdMismatch2"]	= "De passwords komen niet overeen";
	$strings["l_EmptyPwd1"]		= "Leeg password";
	$strings["l_EmptyPwd2"]		= "Je MOET een password invulen";
	$strings["l_UserExists1"]	= "Gebruikersnaam bestaat al";
	$strings["l_UserExists2"]	= "Er is al een account met deze gebruikersnaam";
	$strings["l_PwdChanged"]	= "Het password is gewijzigd";
	$strings["l_PwdWrong"]		= "Het password is fout, probeer het nogmaals.";
	$strings["l_UserNotFound"]	= "De gebruiker  $name is niet gevonden in de 
database.";
	$strings["l_DelUser"]		= "Verwijder dit e-mailaccount";
	$strings["l_DelUserQuest"]	= "Weet je zeker dat je dit account wilt 
verwijderen?.Alle berichten en e-mails gaan verloren.!";
	$strings["l_UserDeleted1"]	= "Gebruikersaccount verwijderd";
	$strings["l_UserDeleted2"]	= "Je account en alle data is verwijderd.";
	$strings["l_Move"]			= "Verplaats bericht(en)";
	$strings["l_ManageFolders"]	= "Mappen beheer";
	$strings["l_AddFolder"]		= "Map toevoegen";
	$strings["l_RenFolder"]		= "Map andere naam geven";
	$strings["l_CalButton"]		= "Kalender";
	$strings["l_Close1"]		= "Sluit";
	$strings["l_Close2"]		= "en keer terug naar je e-mail";
	$strings["l_Close3"]		= "en keer terug naar het welkom's scherm";
	$strings["l_WelcomeScreen"]	= "Laat geen welkom's scherm zien, ga direct 
naar de e-mail.";
	$strings["l_Attachments"]	= "Bijlage(s)";
	$strings["l_Size"]			= "Formaat";
	$strings["l_SpellCheck"]	= "Spellings controle";
	$strings["l_SpellerUse"]	= "Spellings controle: Woorden in het rood zijn 
wellicht verkeerd.  Klik op dat woord voor een suggestie.";
	$strings["l_BadDomain"]		= "Domein is vereerd";
	$strings["l_BadDomainTxt"]	= "Sorry, het e-mail adres dat je ingeeft is 
niet toegestaan op deze server.";
//	$strings["l_BadDomainTxt"]	= "I'm sorry, but the email address you 
entered is not available on this webmail server. This system is for ECTISP 
customers, only. Please check that you entered the email address correctly, 
and try again. If you do not have an account with ECTISP and are trying to 
test the system, please use email address <i>test@ectisp.net</i>, password 
<i>test</i>, as this account has already been set up for your use.  Thank 
you.";
?>

