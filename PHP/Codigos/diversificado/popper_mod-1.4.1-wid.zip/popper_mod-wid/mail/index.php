<?php
	////////////md5 password in cookie		
	//setcookie("poppercookie[pwd]", $pwd, time() + 365 * 24 * 3600);


	function dbg($string) {
		//echo("DEBUG_OUT: $string<br>");
	}
	

	// Check for PHP4
	if (substr(phpversion(), 0, 1) == "3") {
		die("<h1>PHP3 is not supported!</h1>Install PHP4: http://www.php.net");
	}

	
	define("MAIL_UNREAD", 0);
	define("MAIL_READ", 1);
	define("MAIL_REPLIED", 2);
	define("MAIL_FORWARDED", 3);
	
	define("HIGHEST_PRIORITY", 1);
	define("HIGH_PRIORITY", 2);
	define("NORMAL_PRIORITY", 3);
	define("LOW_PRIORITY", 4);
	define("LOWEST_PRIORITY", 5);
	
	define("FULL_VIEW", 0);
	define("MID_VIEW", 1);
	define("MIN_VIEW", 2);
	
	function is_logged_in() {
		global $logged_in;
		return (isset($logged_in) && session_is_registered("logged_in") && $logged_in == 1);
	}
	global $strings, $locale, $configs;
	
	@set_time_limit(60);

	include("class.popper.inc.php");
	session_start();
	
	//if ($poppercookie["pwd"]) {
	//	echo "password is $poppercookie[pwd]";
	//}



	if ($poppercookie["language"]) {
		$lang_file = "lang/lang.".$poppercookie["language"].".inc.php";
	}
	else {
		if (isset($popper->config["language"]) && !empty($popper->config["language"])) {
			$lang_file = "lang/lang.".$popper->config["language"].".inc.php";
		}
		else {
			$lang_file = "lang/lang.english.inc.php";
		}
	}
	
	if (!file_exists($lang_file)) {
		$lang_file = "lang/lang.english.inc.php";
	}

	include($lang_file);
	setlocale(LC_ALL, $locale);

	if (!isset($popper) || !is_object($popper)) {
		$popper = new popper;
	}
	
	if (isset($action) && $action == "lostpwd") {
		$popper->show_in_window("lostpwd");
		exit;
	}
	else if (isset($action) && $action == "help") {
		$popper->show_form("help");
		exit;
	}
	
	if (!isset($popper->db_tool)) {
		$popper->db_tool = new db_tool("admin/popper.inc.php");
	}	
	
	if (!isset($check) && !isset($newuser) && (isset($login) || ($poppercookie["user"] && !is_logged_in()))) {

		if (!isset($login) || !isset($pwd)) {
			$popper->show_in_window("login", $strings["l_Login"]);
			exit;
		}

 		if (!$popper->pwd_check(strtolower($name), $pwd)) {
 			exit;
 		}

		if ($HTTP_COOKIE_VARS["poppercookie"] && $set_cookie != "on") {
			// This indicates that the user previously set the cookie, but don't
			// want to have it anymore
			// We delete the cookies
			setcookie ("poppercookie[user]", "", time() - 3600);		
			setcookie ("poppercookie[language]", "", time() - 3600);
			unset($poppercookie);
		}

		// The password was ok. Now we start the session
		$logged_in = 1;
		$popper->set_user(strtolower($name));
		
		session_register("popper", "logged_in");

		if (isset($set_cookie) && $set_cookie && !$HTTP_COOKIE_VARS["poppercookie"]) {
			// Set the cookies if the user wants that and if it's not set yet.
			setcookie("poppercookie[language]", $popper->config["language"], time() + 365 * 24 * 3600);
			setcookie("poppercookie[user]", strtolower($name), time() + 365 * 24 * 3600);

		}
		
		if (!$popper->has_account()) {
			$popper->show_in_window("newaccount", $strings["l_Account"], $strings["l_AccInfo"]);		
			return;
		}
		//$popper->show();
		// This allows a reload of the page
//BOOBERT//////////////////////////////////////////////////////////////
if($MailChecker == "yes") { $CheckerURL="?MailChecker=yes"; }	//////
///////////////////////////////////////////////////////////////////// 

Header("Location: $PHP_SELF$CheckerURL");
	}


//BOOBERT
	if (isset($GetWaseca)) {
		if($GetWaseca=="Terms") {
			$popper->show_in_window("Terms","WasecaMail Terms and Conditions","you must agree to continue");
			}else{
			$popper->show_in_window("GetWaseca","@Waseca accout setup","setting up account");
}			
exit;
		}
/////////////////////////////////////////////////////////////////////////////////////////////////////////



	else if (isset($newuser)) {
		if ($popper->create_user()) {
			$popper->messagebox($strings["l_AccCreated1"], $strings["l_AccCreated2"], $strings["l_AccCreated2"], $strings["l_Welcome"]);
		}
	}
	else if (is_logged_in()) {
		// Remove previously created tmp-files
		$popper->unlink_tmp();

 
		if ($ok == "OK") {
			$popper->show_frame_list();


			return;
		}	
		
		if (isset($action)) {
			
			$popper->pre_frame();

			if ($action == "showfolder") {
				$popper->show_frameset($folder);
			}
			else if ($action == "list") {
				$popper->show_frame_list();
			}		
			else if ($action == "foldermenu") {

				if ($folderaction == "Open Folder") 
				{
					$popper->show_frame_list();
				}
				
			}
			
			else if ($action == "managefolders") {
	unset($foldername);
				$popper->show_in_window("folders", $strings["l_ManageFolders"]);
			}
			else if ($action == "mail_cont") {
				$popper->show_mail_frame();
			}							
			else if ($action == "showmail") {
				$popper->show_popup_mail();
				//$popper->show_form("newmail", $strings["l_ShowMail"]);
			}			
			else if ($action == "showsources") {
				$popper->show_sources();
			}
			else if ($action == "logoff") {
				session_destroy();
				$popper->messagebox($strings["l_LogoffMsg"], $strings["l_Logoff"], "$popper->name ".$strings["l_LoggedOff"], $strings["l_GoodBye"]);
				return;
			}
			else if ($action == "newmail") {
				$popper->show_in_window("newmail", $strings["l_NewMail"]);
			}
			else if ($action == "printmail") {
				$popper->show_popup_mail();
			}			
			else if ($action == "reply") {
				$popper->show_in_window("newmail", $strings["l_ReplyMail"]);
			}
			else if ($action == "replytoall") {
				$popper->show_in_window("newmail", $strings["l_ReplyAllMail"]);
			}
			else if ($action == "forward") {
				$popper->show_in_window("newmail", $strings["l_ForwardMail"]);
			}
			else if ($action == "showmail") {
				$popper->show_popup_mail();
			}
			else if ($action == "openmail") {
				$popper->show_in_window("newmail", $strings["l_ShowMail"]);
			}
			else if ($action == "choosen") {
				$popper->show_in_window("newmail", $strings["l_Choosen"]);
			}			
			else if ($action == "cancel") {
				$popper->show_frameset();
			}
			else if ($action == "accounts") {
				$popper->show_form("accounts");
			}
			else if ($action == "addressbook") {
				$popper->show_form("addressbook", $strings["l_Addressbook"]);
			
			}
			else if ($action == "newaccount") {
				$popper->show_in_window("newacct", $strings["l_Account"], $strings["l_FillInAll"]);
			}
			else if ($action == "newaddress") {
				$popper->show_in_window("newaddress", $strings["l_Address"]);
			}
			else if ($action == "storemail") {
				$msg = $popper->store_mail();
				if ($return == "welcome")
				{
				$popper->show_form("main");
					die;
				}
				$popper->show_frameset();
			}
			else if ($action == "storeaccount") {
				$popper->store_account();
				$popper->show_form("accounts");
			}
			else if ($action == "storeaddress") {
				$popper->store_address();
				$popper->show_form("addressbook");
			}
			else if ($action == "deladdress") {
				$popper->del_address();
			}
			else if ($action == "delaccount") {
				$popper->del_account();
			}
			else if ($action == "checkrep") {
				$popper->check_repetitive();
			}			
			else if ($action == "frameset") {
				$popper->show_frameset();
			}
			else if ($action == "sendandreceive") {
				$what = "sendandreceive";

				if (!isset($what)) {
					$popper->show_small_window("sendreceive", $strings["l_SendReceive"]);
				}
				else {
					$popper->send_and_receive();
				}
			}
			else if ($action == "getattachment") {
				$popper->get_attachment();
			}
			else if ($action == "config") {
				if (isset($GLOBALS[conf_submit])) {
					$popper->store_config();
		
					$lang_file = "lang/lang.".$popper->config["language"].".inc.php";

					include($lang_file);
					
					setlocale(LC_ALL, $locale);	
					
					$popper->show();
				}
				else if (isset($changepwd)) {
					$popper->show_in_window("changepwd", $strings["l_ChangePwd"]);
				}
				else if (isset($deluser) || isset($ack)) {
					$popper->delete_user();
				}				
				else {
					$popper->show_in_window("config", $strings["l_Config"]);
				}
			}	
			else if ($action == "changepwd") {
				$popper->change_pwd();
			}					
			else if ($action == "deletemail") {
				$popper->delete_mail();
			}
			else if ($action == "selected") {

				if (isset($GLOBALS["delete_x"]) || isset($GLOBALS["ack"])) {
					$popper->delete_mails();
				}
				else if (isset($GLOBALS["add_addr_x"])) {
					$popper->add_sel_addr();
					$popper->show_frame_list();
				}
				else if (isset($GLOBALS["block_x"])) {
					// Mark the senders as blocked
					$popper->add_sel_addr(true);
					// Delete the mails
					$popper->delete_blocked();
				}
				else if (isset($GLOBALS["move_x"]) || isset($GLOBALS["moveack"])) {
					$popper->move_mails();
				}
			}
			else if ($action == "addfolder") {	
				
				if (isset($foldername)) {
					$popper->add_folder($foldername);
			unset($foldername);
					$popper->show_frame_form("folders", $strings["l_ManageFolders"]);
					}
				else
					$popper->show_in_window("addfolder", $strings["l_AddFolder"]);
		
			}

			else if ($action == "emptyfolder") {
				$popper->delete_all($oldfoldername);
				
			}

			else if ($action == "delfolder") {
				$popper->del_folder($oldfoldername);
			}

			else if ($action == "renfolder") {
				
				if ($hitsubmit == "Cancel")
				{
					$popper->show_frame_list();
				}

				if (isset($hitsubmit) && isset($newfoldername))
				{
					$popper->ren_folder($newfoldername, $oldfoldername, $hitsubmit);
				}
				else
				{
					$popper->ren_folder(0, $oldfoldername, 0);
				}
			}

			else if ($action == "deleteall") {
				$popper->delete_all(0);
			}
			else if ($action == "notification") {
				$popper->send_notification();
				$popper->show_mail_frame();
			}					
			else if ($action == "showcal") {
				include "cal.form.inc.php";
			}

			else {
				$popper->show();
			}
		}
		else {
			$popper->show();
		}
	}
	else {


		$popper->show_in_window("home", $strings["l_Welcome"]);
	}
	$cururi = getenv("REQUEST_URI");
	if ($uri != $cururi) {
		$old_uri = $uri;
	}
	$uri = $cururi;
	session_register("old_uri");
	session_register("uri");
?>



