<?php
	$host = "localhost";
	$user = "mysqlUser";
	$pass = "mysqlUsersPassword";
	$dbname = "popper";

	//this login and password can be changed and moved to the data base thru 
	//admin web interface...  Once moved to the data base these may be removed
	//from here if you want because they will be inactive.
	$savelogin = "admin";
	$savepasswd = "password";

	$version = "1.4.1";
?>
