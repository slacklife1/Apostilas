<?
include('popper.inc.php');
echo "<form action=index.php method=post>";

if (isset($savelogin)) {
echo ('Click the upgrade button to upgrade the admins login name and password to the database.<br>
After you upgrade to the database you will need to open the file popper.inc.php in the admin directory of popper_mod<br>
then delete or comment out the two lines that have your login name and password ($savelogin & $savepasswd).<br><br>If you have 
already upgraded to a database then the fact that you are getting this message means that you haven\'t deleted the 2 lines from
popper.inc.php yet.  Do So Now. Once you have upgraded your password will be saved in an encrypted format and you will be able to
change your username and password using this form<br>
<input type=hidden name=AdminLoad value=Database>
<input type=submit value=Upgrade><br><br>');


}

echo ('<input type=hidden name=AdminLoad value=Database>
There is no error checking at this time so be carefull and type correctly<br>
Login Name:<input type=text name=NewLogin><br>
Password<input type=text name=NewPasswd><br>
<input type=submit value="Change">
</form>');

?>


