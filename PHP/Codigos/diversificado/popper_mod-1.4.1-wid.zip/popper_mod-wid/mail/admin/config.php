<?php 

session_start();
if (!session_is_registered("SESSION"))
{
		echo ("ERROR: You are not logged in.");
                echo ("<br><i>support: <a href=\"http://www.symatec-computer.com/forums/\">www.symatec-computer.com/forums/</i>");
                die;
}


include("popper.inc.php");
$connection = mysql_connect($host, $user, $pass) or die ("Unable to connect to server!");

if ('saveconfig' == $action)

{

	if ($customstring != "")
		$delimiter = $customstring;

	$query = "DROP TABLE IF EXISTS config";
	mysql_db_query($dbname, $query, $connection);	
	
	$query = "CREATE TABLE config (signuptype varchar(1), authtype varchar(1), delimiter varchar(50), allowaccount varchar(1),
		  allowgeneral varchar(1), popname varchar(50), greeting varchar(50), titlebar varchar(50), browsertitle
		  varchar(50), spellchecker varchar(1), dictionaryurl varchar(255), domainlist text, acceptdomain varchar(1),
		  maximumsize varchar(25))";

	mysql_db_query($dbname, $query, $connection);

	$query = "INSERT INTO config (signuptype, authtype, delimiter, allowaccount, allowgeneral, popname, greeting,
			titlebar, browsertitle, spellchecker, dictionaryurl, domainlist, acceptdomain, maximumsize)
	          VALUES ('$signuptype', '$authtype', '$delimiter', '$allowaccount', '$allowgeneral', '$popname',
			'$greeting', '$titlebar', '$browsertitle', '$spellchecker', '$dictionaryurl', '$domainlist',
			'$acceptdomain', '$maximumsize')";
	mysql_db_query($dbname, $query, $connection);
	
	echo 'Configuration updated!  <a href="./">Click here to return to Administration panel</a>';
	die;
}

if ('viewconfig' == $action)

{
	
	$query = "SELECT * FROM config";
	$res = mysql_db_query($dbname, $query, $connection);

	if ($res == 0)
	{
		echo 'It seems you have not yet configured popper_mod.  <a href="./config.php">Click here to do so.</a>';
		die;
	}

	$row = mysql_fetch_row($res);

	// 0 = signuptype
	// 1 = authtype
	// 2 = delimiter
	// 3 = allowaccount
	// 4 = allowgeneral
	// 5 = popname
	// 6 = greeting
	// 7 = titlebar
	// 8 = browsertitle
	// 9 = spellchecker
	// 10 = dictionaryurl
	// 11 = domainlist
	// 12 = acceptdomain
	// 13 = maximumsize

	if ($row[0] == '1')
		$signuptype = "Easy";
	else
		$signuptype = "Classic";

	if ($row[1] == '1')
		$authtype = "Send email name only";
	else if ($row[1] == '2')
		$authtype = "Send email and domain (Delimiter: $row[2])";
	else
		$authtype = "Send custom string (String: $row[2])";

	echo "Signup type: $signuptype<br>";
	echo "Authorization: $authtype<br>";
	
	if ($row[3] == '1')
		echo "** Users are allowed to manipulate POP3 account information<br>";
	if ($row[4] == '1')
		echo "** Users are allowed to change general configuration<br>";
	
	echo "POP server prefix: $row[5]<br>";
	echo "Greeting: $row[6]<br>";
	echo "Titlebar: $row[7]<br>";
	echo "Browsertitle: $row[8]<br>";

	if ($row[12] == '1')
	{
		echo "** Acceptable Domains only is ON<br><br>";
		echo "Acceptable domain list: <br><textarea rows=6 cols=80>$row[11]</textarea><br>";
	}
	if ($row[12] == '0')
		echo "** Acceptable Domains only is OFF<br>";

	echo "<br>";

	if ($row[9] == '1')
	{
		echo "** Spell-checker is ON<br>";
		echo "Dictionary URL: $row[10]";
	}
	if ($row[9] == '0')
		echo "** Spell-checker is OFF<br>";
	echo "Maximum size before moved to file system: $row[13] KiloBytes<br>";

	echo "<br>";
	echo '<br><a href="./">Return to Administration panel</a>';
	echo '<br><a href="./config.php">Reconfigure these options</a>';
	mysql_close($connection);
	die;
}
?>

<HTML>
<HEAD>
<TITLE>webmail Configuration</TITLE>
</HEAD>
<BODY>

<?php

$query = "SELECT * FROM config";
@        $res = mysql_db_query($dbname, $query, $connection);

        $row = mysql_fetch_row($res);

        // 0 = signuptype
        // 1 = authtype
        // 2 = delimiter
        // 3 = allowaccount
        // 4 = allowgeneral
        // 5 = popname
        // 6 = greeting
        // 7 = titlebar
        // 8 = browsertitle
	// 9 = spellchecker
        // 10 = dictionaryurl
	// 11 = domainlist
	// 12 = acceptdomain
	// 13 = maximumsize

?>

popper_mod configuration options<br>
<form name="options" method="post" action="config.php?action=saveconfig">
<h3>Email signup options</h3>
Do you want easy account signup, or do you want the classic popper account signup?  If you choose "Easy Signup", you
will get the functionality that popper_mod has always had.  I.E., all the user must do is input their email address
and password, and popper_mod does the account setup for them.  If you want your users to have more configuration
power, then choose "Classic Signup".<br>
<br>
<input type="radio" name="signuptype" value="1" <?php if (($row[0] == "1") && ($res != 0)) echo "checked=\"true\""; ?>>Easy Signup<br>
<input type="radio" name="signuptype" value="2" <?php if (($row[0] == "2") && ($res != 0)) echo "checked=\"true\""; ?>>Classic Signup<br>

<h3>Mail Servers</h3>
What hostname prefix does your POP3 mail server have?  For example, we use <i>mail.ectisp.net</i>, so we would enter
<i>mail</i>, here.<br>
<br>
<input type="text" name="popname" <?php if ($res != 0) echo "value=\"$row[5]\""; ?>>

<h3>Authentication Nuances</h3>
What does your POP3 server expect to receive in a USER request?  We use simply the email address name.  For example,
a <i>matthew@ectisp.net</i> email address would need to send <i>matthew</i> in the USER request.  If this is also true for you,
select the first option.  If you send the domain name along with the email address name in the user request, select
the second option, and please include the appropriate delimiter.  For example, if your server requires the full
email address <i>matthew@ectisp.net</i> in the USER request, then select the second option, and put <i>@</i> in the delimiter
field.  If you need a custom string like "domain-user", select the third option and put the string format into the String
field.  Use ^^ to designate where popper_mod should fill in the email address name.  For "ectisp-matthew" you would enter
"ectisp-^^".<br>
<br>
<input type="radio" name="authtype" value="1" <?php if (($row[1] == "1") && ($res != 0)) echo "checked=\"true\""; ?>>1. Email name only<br>
<input type="radio" name="authtype" value="2" <?php if (($row[1] == "2") && ($res != 0)) echo "checked=\"true\""; ?>>2. Send email and domain
 &nbsp; Delimiter: <input type="text" name="delimiter" size="2" <?php if ($res != 0) echo "value=\"$row[2]\""; ?>><br>
<input type="radio" name="authtype" value="3" <?php if (($row[1] == "3") && ($res != 0)) echo "checked=\"true\""; ?>>3. Custom
 &nbsp; String: <input type="text" name="customstring" size="30" <?php if ($res != 0) echo "value=\"$row[2]\""; ?>><br>

<h3>User options</h3>
Do you want users to be able to add and remove POP3 accounts?  If you check the box, then users can add as many POP3
accounts as they wish, AND delete them as they wish.  Do you want to allow users to change general configuration settings
such as signature, lines per mail, and whether or not to keep their mail on the POP server.  You will likely not want to
check this.<br>
<br>
Allow POP3 account configuration?<input type="checkbox" name="allowaccount" value="1" <?php if (($row[3] == "1") && ($res != 0)) 
	echo "checked=\"true\""; ?>><br>
Allow general configuration?<input type="checkbox" name="allowgeneral" value="1" <?php if (($row[4] == "1") && ($res != 0))
	echo "checked=\"true\""; ?>><br>

<h3>Site options</h3>
Enter the greeting text, the titlebar text, and the browsertitle text that you want popper_mod to display.  You no
longer need to set these options in config.inc.php<br>
<br>
Greeting <input type="text" name="greeting" size="50" <?php if ($res != 0) echo "value=\"$row[6]\""; ?>><br>
Titlebar <input type="text" name="titlebar" size="50" <?php if ($res != 0) echo "value=\"$row[7]\""; ?>><br>
Browsertitle <input type="text" name="browsertitle" size="50" <?php if ($res != 0) echo "value=\"$row[8]\""; ?>><br>
<br>

<h3>Acceptable Domain Options</h3>
If you wish, you can configure popper_mod to allow new user accounts on certain domains only.  Keep in mind that
this does not check where the user is coming from, it checks what email address the user is trying to set up.  If
you allow only aaa.com and bbb.com, that means that a user setting up address test@aaa.com will be allowed, but
the same user attempting to set up test@ccc.com will not.  If you wish to accept any email addresses, turn off
Acceptable Domains.  The domains should be in list format, seperated by a comma.  Whitespace is OK between 
the domain names.   Make sure to enter only the domain names, not the mail servers.<br>
<br>
Example: ectisp.net, symatec-computer.com<br>
<br>
Allow Acceptable Domains only? 
<input type="radio" name="acceptdomain" value="1" <?php if (($row[12] == "1") && ($res != 0)) echo "checked=\"true\""; ?>> On
<input type="radio" name="acceptdomain" value="0" <?php if (($row[12] == "0") && ($res != 0)) echo "checked=\"true\""; ?>> Off<br>
<h5>Acceptable Domain list</h5>
<textarea cols=80 rows=6 name="domainlist"><?php if ($res != 0 && !empty($row[11])) echo "$row[11]"; ?></textarea><br>
<br>

<h3>Spell-checker Options</h3>
To use the cludgy, yet still useful spell-checker in popper_mod, you need to have a Unix-based host machine and
you also need to have ispell installed and in your path.  If you do not have ispell, you can get it from GNU at
url <A HREF="http://www.gnu.org/software/ispell/ispell.html">http://www.gnu.org/software/ispell/ispell.html</a>.
If you don't have ispell, make sure to turn this off to avoid a broken spellcheck button and confused users.<br>
<br>
Also, you need some kind of dictionary URL for the software to be able to return a list of possible replacement words
to the user.  The default URL uses the Merriam-Webster WWW dictionary.  If you are using the English language, this
is probably the best dictionary to use.  If you need help fitting the FORM variables into the URL, post a message on
the support forum and I'll help you figure out what to put here.  The popper_mod software will fill in the misspelled
word right after the entered URL, so you want that variable to be last, and don't forget the trailing equal sign.<br>
<br>
I plan on implementing a better spell-checking solution into popper_mod, but this is a first step.<br>
<br>
Turn on the spell-checker? 
<input type="radio" name="spellchecker" value="1" <?php if (($row[9] == "1") && ($res != 0)) echo "checked=\"true\""; ?>>Yes 
<input type="radio" name="spellchecker" value="0" <?php if (($row[9] == "0") && ($res != 0)) echo "checked=\"true\""; ?>>No<br>
Dictionary lookup URL
<input type="text" size="75%" name="dictionaryurl" value="<?php if ($res != 0 && !empty($row[10]))  echo $row[10]; else echo "http://www.m-w.com/cgi-bin/dictionary?book=Dictionary&va="; ?>"><br>
<br>

<h3>Tuning</h3>
Large attachments can cause "Mysql server has gone away" errors when users download their mail.  Mysql comes with
a default max_packet_size of only 2 megabytes.  Factor in encoding overhead and you can easily bump up against this
limit! <br>
<br>
Using the value below, you can manipulate popper_mod into saving a user's mail into the filesystem instead of the SQL
server based on a size criteria.  This will work for mails that do not contain attachments, as well.  You can even
set this value to 0, which will cause popper_mod to store all user mails on the local file system, if you wish.<br>
<br>
Keep in mind that there is a small security issue in doing this.  The popper_mod distribution now contains "default.html"
and "index.html" null files to keep people from browsing your /tmp directory.  It would be even better to deny access to /tmp
in your webserver configuration file.  The filenames are generated with 20 byte random characters, and they carry the extension
equivalent to the id of your user.  <br>
<br>
This value needs to be entered in kilobytes.  The default of 1900 kilobytes (or 1.9MB) is a good starting point.  Don't
change it unless you realize what you're doing.<br>
<br>
<input type="text" size="20" name="maximumsize" value="<?php if ($res != 0 && !empty($row[13])) echo $row[13]; else echo "1900"; ?>"> KiloBytes<br>
<input type="submit" value="Save my configuration"> 
<input type="reset" value="Reset and start over"> &nbsp; <a href="./">Abort and return to Administration panel</a></form>
</BODY>
</HTML>
