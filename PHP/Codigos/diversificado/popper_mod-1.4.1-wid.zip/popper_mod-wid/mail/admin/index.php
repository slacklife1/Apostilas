<?php

include ("popper.inc.php");
session_start();

if ($action == "logout") 
{
	session_unregister("SESSION");

	echo ("INFO: You have been successfully logged out.  ");
	echo ("<a href=\"$PHP_SELF\">Log in again.</A>");
        echo ("<br><i>support: <a href=\"http://www.symatec-computer.com/forums/\">www.symatec-computer.com/forums/</i>");
        die;
	
}


if (!session_is_registered("SESSION")) {
if (!$submit)
{
?>
	<html>
	<head>
	<title>webmail Adminstration</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	</head>

	<body bgcolor="#FFFFFF" text="#000000">

	<TABLE cellpadding=0 cellspacing=0 align=center width=75%>
	<TR bgcolor=#93BEE2 align="center" style="height: 19px;">
	<TD align=left>&nbsp;&nbsp;<font>Welcome&nbsp;to&nbsp;Webmail&nbsp;administration</font></td>
	<TD width=100%>&nbsp;</td>
	<TD nowrap><font>Please&nbsp;Sign&nbsp;In</font>&nbsp;</td>
	</TR></TABLE>
	<TABLE cellpadding=0 cellspacing=10 align=center width=70%>
	<TR>
	<FORM METHOD="POST">
	<TD><B>Login</B></TD><TD><INPUT name="login" size=30 type="text"></TD><TD><I>enter your username</I></TD></TR>
	<TR><TD><B>Password</B></TD><TD><INPUT name="passwd" size=30 type="password"></TD><TD><I>password is case sensitive</I></TD>
	</TR>
	<TR>
	<TD></TD>
	<TD>
	<input name="submit" type="submit" value="Sign In"></TD>
	</TR>
	</TABLE>
	</FORM> 
<?php
	die;
}

	else

{
	
	if ($savelogin == "changeme")
	{
		echo ("ERROR: You have not configured a username and password for your administrator panel!<br>");
		echo ("Please edit your popper.inc.php file in the /admin directory and change the savelogin<br>");
		echo ("and savepasswd variables to the login name and password of your choice.  Thanks!<br>");
		echo ("<br><i>support: <a href=\"http://www.symatec-computer.com/forums/\">www.symatec-computer.com/forums/</i>");
		die;
	}

	if (!$login || !$passwd)
	{
		echo ("ERROR: You did not enter a username and/or password.  ");
		echo ("<a href=\"$PHP_SELF\">Click here to retry.</A>");
		echo ("<br><i>support: <a href=\"http://www.symatec-computer.com/forums/\">www.symatec-computer.com/forums/</i>");
		die;
	}

$connection = mysql_connect($host, $user, $pass) or die ("Unable to connect to server!");

//Check MySQL for admin name and password.
$query = "select * from admin";
$results = mysql_db_query($dbname, $query, $connection);
while($row = @mysql_fetch_row($results)) {
$savelogin =  $row[0];
$savepasswd = $row[1];  
$passwd = md5($passwd);
}
	if ($login != $savelogin || $passwd != $savepasswd)
	{
		echo ("ERROR: You entered an incorrect username and/or password.  ");
		echo ("<a href=\"$PHP_SELF\">Click here to retry.</A>");
		echo ("<br><i>support: <a href=\"http://www.symatec-computer.com/forums/\">www.symatec-computer.com/forums/</i>");
		die;
	}

session_start();
session_register("SESSION");


}
}

$connection = mysql_connect($host, $user, $pass) or die ("Unable to connect to server!");

$ValidOrder = array(
	'name',
	'lastlogin', 
	'tablesize',
);
if (in_array($order, $ValidOrder))
	$sortfactor = $order;
else
	$sortfactor = 'id';

if ('deluser' == $action)

{
	// Delete a user :)
	//

	$tblname = "mail_" . $user_id;

	$query = "SELECT name FROM users where id=$user_id";
        	$result = mysql_db_query($dbname, $query, $connection);

	$row = mysql_fetch_row($result);
	$name = $row[0];

	$query = "SELECT mail FROM $tblname WHERE is_mime=5";
	$delres = @mysql_db_query($dbname, $query, $connection);

	while ($dellist = @mysql_fetch_row($delres))
	{
		$ulfile = explode(",", $dellist[0]);
                unlink("../".trim($ulfile[0]));
	}
	
	$query = "DROP TABLE $tblname";
	mysql_db_query($dbname, $query, $connection); 

	$query = "DELETE FROM accounts where user_id=$user_id";
	mysql_db_query($dbname, $query, $connection);
	
	$query = "DELETE FROM conf where user_id=$user_id";
	mysql_db_query($dbname, $query, $connection);

	$query = "DELETE FROM users where id=$user_id";
	mysql_db_query($dbname, $query, $connection);

	$query = "DELETE FROM addresses where user_id=$user_id";
	mysql_db_query($dbname, $query, $connection);

	echo "user number <b>$user_id</b> (<i>$name</i>) deleted\n\n";
	
}

if ('delitem' == $action)

{
	// Delete certain item(s)
	//

	$tblname = "mail_" . $user_id;

	$query = "SELECT name FROM users where id=$user_id";
       	$result = mysql_db_query($dbname, $query, $connection);

	$row = mysql_fetch_row($result);
        	$name = $row[0];

	if ($dobin == "1")
	{	
		$query = "DELETE FROM $tblname WHERE folder='bin'";
		mysql_db_query($dbname, $query, $connection);
		echo "* deleted Recycle Bin\n";
	}
	if ($dosent == "2")
	{
		$query = "DELETE FROM $tblname WHERE folder='sent'";
		mysql_db_query($dbname, $query, $connection); 
		echo "* deleted Sent Items\n";
	}
	if ($doinbox == "3")
	{
		$query = "DELETE FROM $tblname WHERE folder='inbox'";
		mysql_db_query($dbname, $query, $connection); 
		echo "* deleted Inbox\n";

	}
	if ($dooptimize == "4")
	{
		$query = "OPTIMIZE TABLE $tblname";
		mysql_db_query($dbname, $query, $connection); 
		echo "* optimized table\n";
	}

	echo " from user number <b>$user_id</b> (<i>$name</i>)\n\n";
}

if ('delall' == $action)

{
	$query = "SELECT id, name FROM users ORDER BY id";
		$result = mysql_db_query($dbname, $query, $connection);

	while(list($id, $name) = mysql_fetch_row($result))
	{

	$tblname = "mail_" . $id;
	echo "user number: <b>$id</b> email address: <i>$name</i>  ";
	
		if ($allbin == "1")
		{
			echo "* emptied recycle bin";
			$query = "DELETE FROM $tblname where folder='bin'";
			mysql_db_query($dbname, $query, $connection); 
		}

		if ($allsent == "2")
		{
			echo "* emptied sent items";
			$query = "DELETE FROM $tblname where folder='sent'";
	                mysql_db_query($dbname, $query, $connection); 
		}

		if ($optimize == "3")
		{
			echo "* optimized";
			$query = "OPTIMIZE TABLE $tblname";
			mysql_db_query($dbname, $query, $connection);
		}

	echo "<br>";

	}
}


////Creating an admin account on the MySql database
if($AdminLoad == "Database") {
if($NewLogin != "") { $savelogin=$NewLogin;}
if($NewPasswd != "") { $savepasswd=$NewPasswd;}

$query = "drop table admin";
mysql_db_query($dbname, $query, $connection);
        echo "* admin Table droped and reset if existed*<br>";
$query = "create table admin (AdminUser text, AdminPasswd text)";
        echo "* added table admin and fields AdminUser and AdminPasswd*<br>";
        mysql_db_query($dbname, $query, $connection);

$pwd = md5($savepasswd);
$query = "INSERT INTO admin (AdminUser, AdminPasswd) VALUES ('$savelogin', '$pwd')";
        echo "* added admins login name and password to database*<br>";
        mysql_db_query($dbname, $query, $connection);

}


?>

<p>Welcome, Administrator.<br>
this version is: <b><?php echo $version; ?></b>&nbsp;
the latest version is: <?php $incl = @include
"http://www.waseca.net/wasecasoft/popper/NEWEST_VERSION_IS.php"; if(!$incl) echo
"<br>can't connect to popper_mod site for new version"; ?><br>
database time is: 
<?php 

	$query = "SELECT now()";
	$result = mysql_db_query($dbname, $query, $connection);
	$thetime = mysql_fetch_row($result);
	echo $thetime[0];
?><br>
<a href="<?php echo $PHP_SELF; ?>?action=logout">Click here to log out.</a>

 <a href="<?php echo $PHP_SELF; ?>?order=<?php echo $sortfactor; ?>">Refresh this page</a><br>
 <a href="./config.php">Configure popper_mod global options</a><br>
 <a href="./config.php?action=viewconfig">View current popper_mod configuration</a><br>
 <a href="./ChangePass.php">Change Username and Password (and upgrade login to database)</a><br>
</p>
<form name="deluser" method="post" action="index.php?action=deluser&order=<?php echo $sortfactor; ?>">
  Delete user:
<input type="text" name="user_id">
 <p> <input type="submit" name="Submit4" value="You are the Weakest Link, Goodbye!"></p>
</form>

<form name="delitem" method="post" action="index.php?action=delitem&order=<?php echo $sortfactor; ?>">
  User number:
  <input type="text" name="user_id">
  <input type="checkbox" name="dobin" value="1">
  Recycle bin 
  <input type="checkbox" name="dosent" value="2">
  Sent Items 
  <input type="checkbox" name="doinbox" value="3">
  Inbox |
  <input type="checkbox" name="dooptimize" value="4">
  <i>Optimize</i>
  <p><input type="submit" name="Submit3" value="Perform on Individual"></p>
</form>

<form name="delall" method="post" action="index.php?action=delall&order=<?php echo $sortfactor; ?>">
  <p> 
    <input type="checkbox" name="allbin" value="1">
    Delete <b>all</b> recycle bins<br>
    <input type="checkbox" name="allsent" value="2">
    Delete <b>all</b> sent items<br>
    <input type="checkbox" name="optimize" value="3">
    <i>Optimize tables</i></p>
  <p>
    <input type="submit" name="Submit" value="Perform on All">
  </p>
</form>

<?php

if ('Expand' == $statfootprint)
	{

		echo '
		<p>
			Current user stats: &nbsp &nbsp
			<a href="index.php?order=id&statfootprint=Expand">Sorted by id</a> &nbsp &nbsp 
			<a href="index.php?order=name&statfootprint=Expand">Sorted by name</a> &nbsp &nbsp 
			<a href="index.php?order=lastlogin&statfootprint=Expand">Sorted by lastlogin</a> &nbsp &nbsp 
			<a href="index.php?order=tablesize&statfootprint=Expand">Sorted by accountsize</a>
		</p>';

		echo '
		<form name="change" method="get" action="index.php">
			View: <input type="submit" name="statfootprint" value="Collapse">
			<input type="hidden" name="order" value="';  echo $sortfactor;	echo '">
		</form>';

	$query = "SELECT id, name, pwd, lastlogin from users ORDER BY id";
	$result = mysql_db_query($dbname, $query, $connection); 

	$query = "SHOW TABLE STATUS";
	$tabstats = mysql_db_query($dbname, $query, $connection);

	$query = "CREATE TEMPORARY TABLE stats (tablename varchar(20), tablesize mediumint, id int(11), name varchar(50), pwd varchar(30), lastlogin datetime) type=heap";
	mysql_db_query($dbname, $query, $connection);
	while ($tabray = @mysql_fetch_row($tabstats))
	{
		 switch($tabray[0])
		 {
			case 'users':
			case 'accounts':
			case 'conf':
			case 'addresses':
			case 'stats':
			case 'confirmations':
			case 'config':
	
			// Don't log these
	
				break;
	
			default:
				 $query = "INSERT INTO stats (tablename, tablesize) VALUES ('$tabray[0]', '$tabray[5]')";
				 mysql_db_query($dbname, $query, $connection); 
				 break;

		 }		
	}

	while ($tabray = mysql_fetch_row($result))
	{
		 $tblname = "mail_" . $tabray[0];
		 $query = "UPDATE stats SET id='$tabray[0]', name='$tabray[1]', pwd='$tabray[2]', lastlogin = '$tabray[3]' WHERE tablename='$tblname'";
		 mysql_db_query($dbname, $query, $connection);
	}

	echo '
	<table width="99%" border="0">
		<THEAD ALIGN="CENTER">
				<TR>
					<TD>ID</TD>
					<TD>Email Address</TD>
					<TD>Password</TD>
					<TD>Last Login</TD>
					<TD>Size</TD>
				</TR>
		</THEAD>';

	$query = "SELECT id, name, pwd, lastlogin, tablesize FROM stats ORDER BY $sortfactor";
		$result = mysql_db_query($dbname, $query, $connection);

	while(list($id, $name, $pwd, $lastlogin, $tablesize) = @mysql_fetch_row($result))
	{

		echo '<tr style="font-size: medium; color: blue">';
			echo "<td>";	echo $id;		echo "</td>";
			echo "<td>";	echo $name;		echo "</td>";
			echo "<td>"; 	echo $pwd;		echo "</td>";
			echo "<td>";	echo $lastlogin;	echo "</td>";
			echo "<td>";	echo $tablesize;	echo "</td>";
			echo "<td>";	echo " ";		echo "</td>";
		echo "</tr>";

	}	

	echo '</TABLE>';   // end of <TABLE>

	$query = "DROP TABLE stats";
	mysql_db_query($dbname, $query, $connection);


}	// END of if ($statfootprint == "Expand")

else	// else we're in the collapsed view

{
	if ('tablesize' == $sortfactor)
	       $sortfactor = "id"; 

	echo '
	<p>
		Current user list: &nbsp &nbsp 
		<a href="index.php?order=id">Sorted by id</a> &nbsp &nbsp 
		<a href="index.php?order=name">Sorted by name</a> &nbsp &nbsp 
		<a href="index.php?order=lastlogin">Sorted by lastlogin</a> &nbsp &nbsp
	</p>'; 

	echo '
	<form name="change" method="get" action="index.php">
		View: <input type="submit" name="statfootprint" value="Expand">
		<input type="hidden" name="order" value="';  echo $sortfactor; echo '">
	</form>';

	$query = "SELECT id, name, pwd, lastlogin from users ORDER BY $sortfactor";
		$result = mysql_db_query($dbname, $query, $connection);

	echo '
	<table width="99%" border="1">
		<THEAD ALIGN="CENTER">
			<TR>
				<TD>ID</TD>
				<TD>Email Address</TD>
				<TD>Password</TD>
				<TD>Last Login</TD>
			</TR>
			<TR></TR>
		</THEAD>';

	while(list($id, $name, $pwd, $lastlogin) = mysql_fetch_row($result))
	{	

		echo "
		<tr>
			<td>$id</td>
			<td>$name</td>
			<td>$pwd</td>
			<td>$lastlogin</td>
		</tr>";

	}
	
	echo '</TABLE>';  // end the <TABLE>

	mysql_close($connection);

}

?>

</table>
</body>
</html>

