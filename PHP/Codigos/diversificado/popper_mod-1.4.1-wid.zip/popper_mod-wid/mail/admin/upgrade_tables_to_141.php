<?php

include ("popper.inc.php");

session_start();
if (!session_is_registered("SESSION"))
{

if (!$submit)
{
?>
        <html>
        <head>
        <title>webmail Adminstration</title>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
        </head>

        <body bgcolor="#FFFFFF" text="#000000">

        <TABLE cellpadding=0 cellspacing=0 align=center width=75%>
        <TR bgcolor=#93BEE2 align="center" style="height: 19px;">
        <TD align=left>&nbsp;&nbsp;<font>Welcome&nbsp;to&nbsp;Webmail&nbsp;administration</font></td>
        <TD width=100%>&nbsp;</td>
        <TD nowrap><font>Please&nbsp;Sign&nbsp;In</font>&nbsp;</td>
        </TR></TABLE>
        <TABLE cellpadding=0 cellspacing=10 align=center width=70%>
        <TR>
        <FORM>
        <TD><B>Login</B></TD><TD><INPUT name="login" size=30 type="text"></TD><TD><I>enter your username</I></TD></TR>
        <TR><TD><B>Password</B></TD><TD><INPUT name="passwd" size=30 type="password"></TD><TD><I>password is case sensitive</I></TD>
        </TR>
        <TR>
        <TD></TD>
        <TD>
        <input name="submit" type="submit" value="Sign In"></TD>
        </TR>
        </TABLE>
        </FORM> 
<?php
        die;
}

        else

{
        if (!$login || !$passwd)
        {
                echo ("ERROR: You did not enter a username and/or password.  ");
                echo ("<a href=\"$PHP_SELF\">Click here to retry.</A>");
                echo ("<br><i>support: <a href=\"http://www.symatec-computer.com/forums/\">www.symatec-computer.com/forums/</i>");
                die;
        }

	 if ($login != $savelogin || $passwd != $savepasswd)
        {
                echo ("ERROR: You entered an incorrect username and/or password.  ");
                echo ("<a href=\"$PHP_SELF\">Click here to retry.</A>");
                echo ("<br><i>support: <a href=\"http://www.symatec-computer.com/forums/\">www.symatec-computer.com/forums/</i>");
                die;
        }

session_start();
session_register("SESSION");


}
}

$connection = mysql_connect($host, $user, $pass) or die ("Unable to connect to server!");

if ('go' == $action)
{
	$query = "SELECT MIN(id) FROM users";
	$res = mysql_db_query($dbname, $query, $connection);
	$row = mysql_fetch_row($res);
	echo "your first user_id is: $row[0]<br>";
	$firstid = $row[0];
	
	$query = "SELECT MAX(id) FROM users";
	$res = mysql_db_query($dbname, $query, $connection);
	$row = mysql_fetch_row($res);
	echo "your last user_id is: $row[0]<br>";
	$lastid = $row[0];

	echo '<br>';
	
	//Adding a field to table
	$query = "ALTER TABLE conf ADD welcome tinyint(1) NOT NULL DEFAULT '0'";
	echo "* added welcome flag to conf table *<br>";
	mysql_db_query($dbname, $query, $connection);

	
	//version 3.0 and up
	$query = "ALTER TABLE conf ADD side_address tinyint(1) NOT NULL DEFAULT '1'";
	echo "* added side_address flag to conf table *<br>";
	mysql_db_query($dbname, $query, $connection);



	$query = "ALTER TABLE conf ADD side_nav tinyint(1) NOT NULL DEFAULT '1'";
	echo "* added side_nav flag to conf table *<br>";
	mysql_db_query($dbname, $query, $connection);


	$query = "ALTER TABLE conf ADD skins text";
	echo "* added skins flag to conf table *<br>";
	mysql_db_query($dbname, $query, $connection);


	$query = "ALTER TABLE conf ADD spam_dir text";
	echo "* added spam_dir flag to conf table *<br>";
	mysql_db_query($dbname, $query, $connection);

	//Version 1.4.1 and up
	$query = "ALTER TABLE conf ADD addsort text";
	echo "* added addsort flag to conf table *<br>";
	mysql_db_query($dbname, $query, $connection);
	
	$query = "ALTER TABLE addresses ADD quickclick tinyint(1) NOT NULL DEFAULT '1'";
	echo "* added quickclick flag to conf table *<br>";
	mysql_db_query($dbname, $query, $connection);


	//////////////////////
	echo "<h3>process complete!</h3>";
	die;
}	
?>
<HTML>
<HEAD><TITLE>popper_mod Upgrade Script</TITLE></HEAD>
<BODY>
Welcome.  This script will upgrade your popper_mod 1.2.4 or before's
database.  Starting with popper_mod 1.2.5, I have added an index
for the folders, and cut the DB definitions for folder from 255 
(unnecessary -- the maximum folder size is 30) to 30.
This script also adds a new configuration field to turn off and on 
the welcome screen.  If you have run this script before, it is not 
necessary to run it again.  If you aren't sure, go ahead and run it,
it won't destroy, damage, or change any data.  
<br>
In 1.3 side nav configuration was added, skins and a spam directory option
(spam feature only works with certain pop3 servers)
<br>
In 1.4, Address book sorting feature was added and a option to only show chosen
contacts in side_nav address book
<br><br>
Make sure that you have the admin/popper.inc.php file setup correctly
with your database information and passwords, and then hit "OK".<br>
<br>
Please note that this process make take quite some time depending
on the speed of your SQL server and the amount of users you have.  Also
make sure that you have adequate permissions on your database, or the
changes may not take effect at all!<br>
<br>
<form name="go" method="post" action="upgrade_tables_125_to_200.php?action=go">
<input type="submit" value="OK"></form>
</BODY>
</HTML>


