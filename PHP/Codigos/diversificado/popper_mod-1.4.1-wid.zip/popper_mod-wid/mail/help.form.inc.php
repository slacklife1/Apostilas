
<center><h2>Welcome to Webmail help</h2></center>

<h3>Table of Contents</h3>
<ol>
	<li><a href="#intro">Introduction</a></li>
	<li><a href="#toolbar">The toolbars</li>
	<li><a href="#titlebar">The titlebar</li>
	<li><a href="#new">Compose a new message</li>
	<li><a href="#read">Reading mails</li>
	<li><a href="#address">Addressbook</li>
	<li><a href="#folders">Using folders</li>
	<li><a href="#contact">Contact</li>
</ol>

<h3><a name="intro">Introduction</a></h3>
Welcome to the popper_mod Webmail client.  This software gives you the ability to receive your email
from any compatible web browser, anywhere. 
<br>
You can read, answer, forward your mails, compose new messages, send
attachments, see received attachments and documents and much more. 
<ul>
	<li>
		Access your mailbox
	</li>
	<li>
		Compose new messages
	</li>
	<li>
		Answer and forward your mails
	</li>
	<li>
		Send and receive attachments
	</li>
	<li>
		Online addressbook
	</li>
</ul>

<h3><a name="toolbar">The toolbar</a></h3>
<p><img src="graphics/help_toolbar.gif" alt="Toolbar image"></p>
The toolbar is the most important part of this mail client. All the commands are executed through this bar.<br>
<p>The single functions are described below:</p>
<img src="graphics/newmail.gif" alt="New mail image" style="float: left;">
This lets you compose a new mail message.<br>
<br clear=all>
<img src="graphics/reply.gif" alt="Reply image" style="float: left;">
Reply to the email you are currently viewing.  If possible, the original text will be quoted.<br>
<br clear=all>
<img src="graphics/replytoall.gif" alt="Reply to all image" style="float: left;">
Reply to all the recipients of the email you are currently viewing.<br>
<br clear=all>
<img src="graphics/forward.gif" alt="Forward image" style="float: left;">
Forward the email you are currently viewing to someone else.<br>
<br clear=all>
<img src="graphics/print.gif" alt="Print image" style="float: left;">
Print the email you are currently viewing.<br>
<br clear=all>
<img src="graphics/prop.gif" alt="Source code image" style="float: left;">
Show the mail headers.  This button is useful in tracking down junkmail.<br>
<br clear=all>
<img src="graphics/cancel.gif" alt="Delete image" style="float: left;">
Delete the email you are currently viewing.  The message is first placed in your Recycle Bin 
folder.  It will not be permanently deleted until you empty your Recycle Bin.<br>
<br clear=all>
<img src="graphics/cancelm.gif" alt="Delete image" style="float: left;">
Delete ALL emails in the current folder.  If you are not in the Recycle Bin, all emails will
be moved to the Recycle Bin.  If you ARE in the Recycle Bin, the emails will be removed
PERMANENTELY.<br>
<br clear=all>
<img src="graphics/sendandreceive.gif" alt="Send and receive image" style="float: left;">
Checks for new mail.<br>
<br clear=all>
<img src="graphics/address.gif" alt="New mail image" style="float: left;">
Opens up your addressbook.<br>
<br clear=all>
<img src="graphics/config.gif" alt="New mail image" style="float: left;">
Open the Webmail options.  You can Delete your webmail account, add a signature,
change mail viewing parameters, and change your mail server preferences here.<br>
<br clear=all>
<h3><a name="toolbar2">The mail toolbar</a></h3>
<p><img src="graphics/help_sel_tool.gif" alt="Toolbar image"></p>
This small toolbar allows to perform actions on checked mails in the current folder.  Select
the desired mails by checking the small box in front of them.<br>
<p>The single functions are described below:</p>
<img src="graphics/del.gif" alt="Del" style="float: left;">
The selected mails will be deleted.<br>
<br clear=all>
<img src="graphics/add_addr.gif" alt="Addressbook" style="float: left;">
The email address of the person who sent you the selected mails will be placed into the addressbook.<br>
<br clear=all>
<img src="graphics/stop.gif" alt="Ban" style="float: left;">
Future mails from the senders of the selected mails will be automatically placed in the Recycle Bin.
This allows you to filter SPAM (junk) mails.<br>
<br clear=all>
<img src="graphics/move.gif" alt="Move" style="float: left;">
This button allows you to move selected emails to another folder.  You can even move emails out
of the Recycle Bin if you accidently deleted them!<br>
<br clear=all>
<h3><a name="titlebar">The titlebar</a></h3>
At the top, to the far right of your name, you will find the logout button
<img src="graphics/logoff.gif" alt="Logoff button"> in the titlebar.  When you
press this button, you will be logged off. Please logoff if you are finished reading your mail!<br>
<br>
When you see this button within a child window, the current operation is cancelled and you will be returned to 
the main mail view screen.<br>
<br>
Clicking the logo in the left upper corner <img src="graphics/logo.gif" alt="Logo"> will return
you to the welcome screen.

<h3><a name="new">Compose a new message</a></h3>
You can start composing a new message by clicking on the "New Mail" button <img src="graphics/newmail.gif" alt="New mail image"> or directly
clicking on an addressbook entry in the left hand corner.
By clicking on the addressbook symbols <img src="graphics/small_address.gif" alt="Addressbook symbol"> near the "To", "Cc" and "Bcc" field
you can select recipients from the addressbook.
If you want to send the mail, click the "Send" button at the bottom. When you click the "Save to Drafts" button, the message will be
stored in the "Drafts" folder. You then can open and modify it later.<br>

<h3><a name="read">Reading mails</a></h3>
To display the mail content, simply click on the sender of the  mail. The mail will be shown in the large textbox beneath.
If there is a clip <img src="graphics/attachment_small.gif" alt="Clip image"> in front of a mail message, then the mail
contains an attachment.  The attachments are shown as little icons in the at the top of the mail message in the right hand 
side of the gray header box.  Clicking on an attachment opens it in a new browser window.  You also can right-click and 
choose "Save target as..." to save the attachment.<br>

<h3><a name="address">Addressbook</a></h3>
To use the Addressbook, click on the Addressbook button in the toolbar.  
<img src="graphics/address.gif" alt="Addressbook image"><br>
<br clear=all>
<img src="graphics/newaddress.gif" alt="New Address image" style="float: left;">
Enter a new address.<br>
<br clear=all>
<img src="graphics/properties.gif" alt="Properties image" style="float: left;">
Change the information for the currently selected address.<br>
<br clear=all>
<img src="graphics/cancel.gif" alt="Delete image" style="float: left;">
Delete the currently selected address.<br>
<br clear=all>
<img src="graphics/block_big.gif" alt="Ban image" style="float: left;">
Show the addresses that are marked as banned addresses. All mails sent from these senders will be automatically
placed in the Recycle Bin.<br>
<br clear=all>
<h3><a name="folders">Using folders</a></h3>
<img src="graphics/help_folders.gif"><br>
<br>
Use the above drop down box to navigate through your folders.  Simply click on the drop down arrow, click on the 
folder you want to change to, and then click on the "Open Folder" button. <br>
<br>
To work with your folders, click on "Manage Folders".  Clicking on Manage Folders will open up a new screen that
will look like this: <br><br>
<img src="graphics/managefolders.gif"><br>
<i>[When you first start your account you will not have anything under "Your Folders".  The "message boards" and "work" folders
are just examples.]</i><br><br>
You can add as many folders as you wish to your account.  To add a folder, click the "Add New Folder"
button.  You can move messages to your folders by using the move button <img src="graphics/move.gif" alt="Move">.  You can
find this button on the small mail toolbar.  To read more about the small mail toolbar, 
<a href="#toolbar2">click here</a>.<br>
<br>
You can also remove, delete, and empty your folders here.  Renaming a folder will change the name of that folder.  If you
Delete a folder, it completely disappears and SO DO ALL MESSAGE WITHIN THAT FOLDER!  If you Empty a folder, it will move
all messages in that folder to the Recycle Bin.  If you Empty the Recycle Bin, it will permanentely remove the messages!<br>
<h3><a name="contact">Contact the Author</a></h3>
Don't hesitate to contact me if you have questions or suggestions about this Webmail system.<br>
<br>
Support Website: <a href="http://forums.symatec-computer.com/">http://forums.symatec-computer.com/</a><br>
<br>
<?php die; ?>
