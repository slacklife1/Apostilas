<?php

global $del;
session_register("foldername");
session_register("del");

?>

<center>
<h2><?php echo($strings["l_Move"]);?></h2>
<form method="post" action="<?php echo("$GLOBALS[REQUEST_URI]");?>">
	Which folder do you want to move the checked messages to?<br><br>
	<select name="foldername">
		<optgroup label="Standard Folders">
		 <option value="inbox">Inbox</option>
		 <option value="sent">Sent Items</option>
		 <option value="bin">Recycle Bin</option>
		 <option value="saved">Saved</option>
		<optgroup label="Your Folders">
<?php

		include "config.inc.php";
		$connection = mysql_connect($host, $user, $pass) or die ("SQL server problem");
		
		$tblname = "mail_" . $this->userid;
		$query = "SELECT DISTINCT folder from $tblname";
		$result = mysql_db_query($dbname, $query, $connection);

		while ($folders = mysql_fetch_row($result))
		{
			switch ($folders[0])
			{
				case 'inbox';
				case 'outbox';
				case 'sent';
				case 'bin';
				case 'drafts';
				case 'trash';
				case 'saved';

					break;
				
				default:
					
					echo "<option value=\"$folders[0]\">$folders[0]</option>";
			}
		}

?>
	</select>
	<br>
	<br>
	<input class="button" type="submit" name="moveack" value="Move">&nbsp;
	<input class="button" type="submit" name="moveack" value="Cancel">
</form>
</center>
