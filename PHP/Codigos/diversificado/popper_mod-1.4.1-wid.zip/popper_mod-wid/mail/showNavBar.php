<?php

echo "<TABLE border=0 width=100%>\n";
echo "<TR>\n";

if($view == "year")
	echo "<TD align=center><b>Year</b></TD>\n";
else
	echo "<TD align=center><A HREF=\"showCalendarYear.php?".Date_Calc::dateFormat($year,$month,$day,"year=%Y&month=%m&day=%d")."\"><b>Year</b></A></TD>\n";

if($view == "month")
	echo "<TD align=center><b>Month</b></TD>\n";
else
	echo "<TD align=center><A HREF=\"showCalendarMonth.php?".Date_Calc::dateFormat($year,$month,$day,"year=%Y&month=%m&day=%d")."\"><b>Month</b></A></TD>\n";

if($view == "week")
	echo "<TD align=center><b>Week</b></TD>\n";
else
	echo "<TD align=center><A HREF=\"showCalendarWeek.php?".Date_Calc::dateFormat($year,$month,$day,"year=%Y&month=%m&day=%d")."\"><b>Week</b></A></TD>\n";

if($view == "day")
	echo "<TD align=center><b>Day</b></TD>\n";
else
	echo "<TD align=center><A HREF=\"showCalendarDay.php?".Date_Calc::dateFormat($year,$month,$day,"year=%Y&month=%m&day=%d")."\"><b>Day</b></A></TD>\n";

echo "</TR>\n";
echo "</TABLE>\n";


?>
