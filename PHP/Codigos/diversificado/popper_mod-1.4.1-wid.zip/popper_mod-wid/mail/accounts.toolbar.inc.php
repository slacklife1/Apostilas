<?php require('skin.db'); //Skinning
//$graphic_dir = "graphics";
	$disable = $this->cur_account_id == 0;
?>
	<tr class="toolbar">
		<td colspan="3">
		<img src="<?=$graphic_dir ?>/toolbar_left.gif" alt="|">
<?php
		if ($disable) {
?>
			<a href="<?php echo("$GLOBALS[PHP_SELF]?action=newaccount"); ?>"><img src="<?=$graphic_dir ?>/newaddress.gif" alt="<?php echo($strings["l_NewAccount"]);?>" title="<?php
echo($strings["l_NewAccount"]);?>" border="0"></a>
			<img style="margin: 0px, 11px, 0px, 11px;" src="<?=$graphic_dir ?>/properties_dis.gif" alt="Alter account" border="0">
			<img src="<?=$graphic_dir ?>/spacing.gif" alt="">
			<img style="margin: 0px, 11px, 0px, 11px;" src="<?=graphics ?>/cancel_dis.gif" alt="Delete account" border="0">
<?php
		}
		else {
?>
			<a href="<?php echo("$GLOBALS[PHP_SELF]?action=newaccount"); ?>"><img src="<?=$graphic_dir ?>/newaddress.gif" alt="<?php echo($strings["l_NewAccount"]);?>" title="<?php echo($strings["l_NewAccount"]);?>" border="0"></a>
			<a href="<?php echo("$GLOBALS[PHP_SELF]?action=newaccount&update=1"); ?>"><img src="<?=$graphic_dir ?>/properties.gif" alt="<?php echo($strings["l_EditAccount"]);?>" title="<?php echo($strings["l_EditAccount"]);?>" border="0"></a>
			<img src="<?=$graphic_dir ?>/spacing.gif" alt="">
			<a href="<?php echo("$GLOBALS[PHP_SELF]?action=delaccount"); ?>"><img src="<?=$graphic_dir ?>/cancel.gif" alt="<?php echo($strings["l_DelAccount"]);?>" title="<?php echo($strings["l_DelAccount"]);?>" border="0"></a>
<?php
		}
?>
		</td>
	</tr>
