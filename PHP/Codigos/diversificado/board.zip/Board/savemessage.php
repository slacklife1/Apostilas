<?
	include("BoardFunctions.php");

	//Check if we got all the required fields. If not, give an error message...
	if(trim($author)=="")
		$error .="Please specify you name!\n<br>";
	
	if(trim($descr)=="")
		$error .="Please specify a subject!\n<br>";

	if(trim($text)=="")
		$error .="Please include a message text!\n<br>";

	//If we have an error, we resend the user back to where it came from...
	if($error)
		ReDirect("$page?msg_id=$parent&replytext=".urlencode($text)."&error=".urlencode($error));
	else
	{

		//Connect to the database
		$db=Connect() or die("Unable to connect to database server");
				
		//Fix a filename for this message:
		$filename=md5 (uniqid (rand()));;
		while(file_exists($GLOBALS["filedir"].$filename))
			$filename=md5 (uniqid (rand()));;
		
		//Insert message into the database
		$q = " INSERT INTO ".$GLOBALS["tablename"]." ( parent_msg_id,  descr, url,  author, filename, stamp) ";
		$q.= " VALUES( $parent,  '".addslashes($descr)."', '".addslashes($url)."', '".addslashes($author)."', '$filename', now())";
		mysql_db_query($GLOBALS["dbname"], $q);
		
		//Check to make sure everything worked ok
		if(mysql_errno())
			$error.="An error occured: ".mysql_error()."\n<br>";

		//Update the parent message: Set the 'has children' flag
		$q = " UPDATE ".$GLOBALS["tablename"]." set haschild=1 WHERE msg_id = $parent";
		mysql_db_query($GLOBALS["dbname"], $q);
		
		//Check to make sure everything worked ok
		if(mysql_errno())
			$error.="An error occured: ".mysql_error()."\n<br>";
		
		//Save the message to disc
		$f= fopen($GLOBALS["filedir"].$filename, "w");
		fwrite($f, $text);
		fclose($f);
		
		//Send the user back to the main page
		//This can be changed to 'ReDirect("$page?msg_id=$parent&error=".urlencode($error));' 
		//if you want the user to go back to the previous page
		ReDirect("board.php?error=".urlencode($error));
	}

?>