<?
	include("BoardFunctions.php");
?>
<html>
<head>
<title>Board</title>
</head>
<body bgcolor="#000000" text="#ffffff" link="#bb0000" vlink="#888888">
<font size="+1">
<?	
	//Print out the error message, if we have one
	if($error)
		echo "<table align=center><tr><td bgcolor=\"#ff0000\"><b>".stripslashes(urldecode($error))."</b></td></tr></table>";
?>
<a href="board.php">Back</a>
<?

	$page="viewmessage.php";
	if(empty($msg_id))
		echo "No message chosen!";		//This will only happen if the user types in 'viewmessage.php' manually
	else
	{			
		//Connect to db
		$db=Connect() or die("Unable to connect to database server");
	
		//Fetch the message
		$q = " SELECT msg_id, parent_msg_id, filename, descr, stamp, author, email, url, haschild FROM ".$GLOBALS["tablename"];
		$q.= " WHERE msg_id = ".$msg_id;
		//$q.= " ORDER BY stamp DESC ";
		
		$result = mysql_db_query($GLOBALS["dbname"], $q);
			
		//Output the message
		if($result > 0)
		{
			$row = mysql_fetch_array($result);
			echo "<ul>";
			
			//Output the child thread if we have one..
			PrintThread($row, $db);	
			echo "</ul><hr>";
			
			//Open the message file
			if(file_exists($GLOBALS["filedir"].$row["filename"]))
			{
				$file=file($GLOBALS["filedir"].$row["filename"]);
			
				//Output the file, but strip slashes
				foreach($file as $line)
					echo stripslashes($line)."<br>";
			}
			
			//Output the URL
			if($row["url"] != "" && $row["url"] != "http://")
				echo "<br><a href=\"".$row["url"]."\">".$row["url"]."</a>";
		}
			
		
	
	
?>
<hr>
<form action="savemessage.php" method="post">
<table>
<tr><td valign=top><font size="+1"><b>Subject:</b></font></td><td><input type=text name=descr value="<? 

	//Output subject
	if( strtolower(substr($row["descr"], 0, 3))!="re:")
		echo "Re: ";
	echo $row["descr"];
?>" size="40"></td></tr>
<tr><td valign=top><font size="+1"><b>Name:</b></font></td><td><input type=text name=author size="40"></td></tr>
<tr><td valign=top><font size="+1"><b>Link:</b></font></td><td><input type=text name=url value="http://" size="40"><br><br></td></tr>
<tr><td valign=top><font size="+1"><b>Message:</b></font></td><td>
<textarea rows=15 cols=60 name=text>
<?
	//If we're sent back to this page because of an error, output that text
	if(trim($replytext) != "")
		echo stripslashes(urldecode($replytext));
	else
	{
		if($file)
		{
			//Otherwise output original message
			echo "\n\nOn ".$row["stamp"]." ".$row["author"]." wrote:\n";
			reset($file);
			foreach($file as $line)
				echo "-".stripslashes($line);
		}	
	}
?>
</textarea>
</td></tr><tr><td align=center colspan=2>
<input type=hidden name="parent" value="0">
<input type=hidden name="page" value="viewmessage.php">
<input type=submit value="Submit"></td></tr>
<input type=hidden name="parent" value="<?=$msg_id ?>">
</table>
</form>
<? } ?>
</font>	
</body>
</html>
	