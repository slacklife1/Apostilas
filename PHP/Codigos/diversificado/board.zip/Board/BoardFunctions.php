<?
	
	$GLOBALS["dbhost"]    = "localhost";						//Database host
	$GLOBALS["dbuser"]    = "user";							//database username
	$GLOBALS["dbpass"]    = "password";						//Database password
	$GLOBALS["dbname"]    = "database";						//Name of the database
	$GLOBALS["filedir"]   = "/messages/";						//Full path to saved messages
	$GLOBALS["tablename"] = "L_MESSAGE";						//Name of the table to be used
	$GLOBALS["fullpath"]  = "http://localhost/Board";				//Full URL to where the board is located (without ending slash / )	
	
	//No more settings...

//Connect to the db
function Connect()
{
	//Connect to db
	return mysql_connect($GLOBALS["dbhost"], $GLOBALS["dbuser"], $GLOBALS["dbpass"]);
}

function PrintThread($row, $db)
{
	//Only print this if we're printing from the main board page (Ie, were not viewing a message)
	if(!$row["first"])
		echo "<li><b><a href=\"viewmessage.php?msg_id=".$row["msg_id"]."\">".$row["descr"]."</a></b> - ".$row["author"]." - ".$row["stamp"];
	echo "<ul>";
	
	//If there are child messages... (replies)
	if($row["haschild"])
	{
		$q = " SELECT msg_id, parent_msg_id, filename, descr, stamp, author, email, url, haschild FROM ".$GLOBALS["tablename"];
		$q.= " WHERE parent_msg_id = ".$row["msg_id"];
		$q.= " ORDER BY stamp DESC ";
		
		if($row["limit"])
			$q.=" LIMIT ".$row["start"].", ".$row["limit"];
		
		$result = mysql_db_query($GLOBALS["dbname"], $q);
			
		//Print the threads for all the children:
		if($result > 0)
			while($row = mysql_fetch_array($result))
				PrintThread($row, $db);
	}
	echo "</ul>";
	if($result>0)
		return mysql_num_rows($result);
}

//Redirect user to another page
function Redirect($page)
{
	$t=$GLOBALS["fullpath"]; 
	header("Location: $t/$page\n\n");
}

?>