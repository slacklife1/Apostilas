
drop table L_MESSAGE

create table L_MESSAGE
(
    MSG_ID         int  auto_increment  not null,
    PARENT_MSG_ID  int                  not null,
    STAMP          datetime                     ,
    DESCr          varchar(30)                  ,
    AUTHOR         varchar( 30)                 ,
    EMAIL          varchar( 50)                 ,
    URL            varchar( 140)                ,
    FILENAME       varchar( 80  )               ,
    haschild       int                          ,
    primary key    (MSG_ID)
);

alter table L_MESSAGE
add index l_msg_id ( msg_id);

alter table L_MESSAGE
add index l_parent_msg_id ( parent_msg_id);
