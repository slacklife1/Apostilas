<?	
	include("BoardFunctions.php");

?>
<html>
<head>
<title>Board</title>
</head>
<body bgcolor="#000000" text="#ffffff" link="#bb0000" vlink="#888888">
<font size="+1">
<?
	//session_register('page');
	//$page="board.php";

	if(trim($error)!="")
		echo "<table align=center><tr><td bgcolor=\"#ff0000\"><b>".stripslashes(urldecode($error))."</b></td></tr></table>";
	
	if(empty($start))
		$start=0;
	$perpage=30;		//How many thread to be shown...

	$row=array("msg_id" => 0, "haschild" => 1, "first" => 1, "limit" => $perpage, "start" =>$start);

	//Connect to the database	
	$db=Connect() or die("Unable to connect to database server");
	
	//Printthread outputs the message tree. If a msg_id is set, only the message and its
	//children are shown.
	$qty=PrintThread($row, $db);
		
	echo "<table width=400 align=center><tr><td align=left>";
	if($start>0)
	{
		echo "<a href=\"board.php?start=";
		echo ($start-$perpage)<0?0:($start-$perpage);
		echo "\">Previous $perpage</a>";
	}
	echo "</td><td align=right>";
	if($qty==$perpage)
		echo "<a href=\"board.php?start=".($start+$perpage)."\">Next $perpage</a>";
	echo "</td></tr></table>";
		
		
?>
<hr>
<form action="savemessage.php" method="post">
<table>
<tr><td valign=top><font size="+1"><b>Subject:</b></font></td><td><input type=text name=descr value="" size="40"></td></tr>
<tr><td valign=top><font size="+1"><b>Name:</b></font></td><td><input type=text name=author size="40"></td></tr>
<tr><td valign=top><font size="+1"><b>Link:</b></font></td><td><input type=text name=url value="http://" size="40"><br><br></td></tr>
<tr><td valign=top><font size="+1"><b>Message:</b></font></td><td>
<textarea rows=15 cols=60 name=text>
<?
	//If we're sent back to this page because of an error, output the text we wrote
	if(trim($replytext) != "")
		echo stripslashes(urldecode($replytext));
?>
</textarea>
</td></tr><tr><td align=center colspan=2>
<input type=hidden name="parent" value="0">
<input type=hidden name="page" value="board.php">
<input type=submit value="Submit"></td></tr>
</table>
</form>
</font>
</body>
</html>