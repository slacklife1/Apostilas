Title: Bored
Description: A simple messageboard with threads. Consists of one database table (coded for MySQL, but most likely easy to adapt) and saves every message in a seperate file to avoid filling the database with message texts. First Release, comments welcome!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=268&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
