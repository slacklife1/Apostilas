<?php
/************************************************************************/
/* PHP NewsletterRequest v1.0                                           */
/* ===========================                                          */
/*                                                                      */
/*   Written by Steve Dawson - http://www.stevedawson.com               */
/*   Freelance Web Developer - PHP, Perl and Javascript programming     */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/************************************************************************/
##
## Change the info below to your details
$YourEmail = "speed@ic24.net";          ## Email address to receive the newsletter signup requests on.
$WebsiteURL = "http://www.stevedawson.com";   ## Your website URL
$emailsubject = "Newsletter Sign Up Request - stevedawson.com"; ## Email Subject Line
$ThanksURL = "thankyou.htm";                    ## Location of the Thankyou page

## Make sure they used our newsletter form, Just a bit of error checking
if(!isset($email)) {
 header("location: $WebsiteURL"); ## If not, send them here. (the website URL you enetered above)
 exit();
}

## The text which will be displayed in the email. (Change to suit you requirements)	
	$emailtext = "
----------------------------------------------------
   Newsletter Sign Up From ".$WebsiteURL."
----------------------------------------------------
Newsletter Signup Request

Please add me to your Newsletter Email List
My email address is:  ".$email."

Kind Regards,
Newsletter Sign Up Request
$WebsiteURL
";

## The following sends the email, with the required information
	@mail("$YourEmail", $emailsubject, $emailtext, "From: $email");
	
## Conceding they were kind enough to fill in the form lets send em somewhere nice ;-)
	header("Location: $ThanksURL"); ## To the thankyou page we stipulated, above.
	exit;

?>