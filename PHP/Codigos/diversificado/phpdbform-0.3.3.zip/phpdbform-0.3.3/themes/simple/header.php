<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title><?php print "$site_title - $page_title"; ?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=<?php print CHARSET; ?>">
	<style type="text/css">
	<?php include("themes/$theme/adm.css"); ?>
	</style>
</head>
<body>
<table border="0" cellpadding="0" cellspacing="0" width="100%" height="100%">
<tr><td valign="middle" align="center">
<table border="1" cellpadding="4" cellspacing="0" align="center">
<tr>
<td>
<span class="title">&nbsp;<?php print $page_title; ?></span>
</td>
</tr>
<tr>
<td valign="middle">
<br>
