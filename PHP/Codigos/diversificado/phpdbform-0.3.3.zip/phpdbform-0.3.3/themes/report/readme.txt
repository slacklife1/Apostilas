This is the first theme for phpdbform!

Some styles don't work with netscape 4.7x, if you use this browser, rename adm_ne.css as adm.css and everything should run ok.

Paulo Assis