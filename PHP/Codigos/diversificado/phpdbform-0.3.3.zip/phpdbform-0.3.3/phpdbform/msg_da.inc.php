<?php
// English Messages
// Steen Rab�l <srabol@mail.tele.dk>

define( "CHARSET", "iso-8859-1" );
$error_msg = array(
"<BR> Kunne ikke oprette forbindelse<BR>\n",
"<BR> Kunne ikke �bne database<BR>\n",
"<BR> Kunne ikke *inds�tte* post\n<BR>",
"<BR> Kunne ikke *opdatere* post\n<BR>",
"<BR> Kunne ikke *slette* post\n<BR>",
"<BR> Kunne ikke *l�se* post\n<BR>",
"<BR> Kunne ikke *l�se* post i opslags tabel\n<BR>",
"<BR> Kunne ikke *l�se* post i listbox tabel\n<BR>",
"<BR> Felt nummer overskrider antallet af felter i klassen\n<BR>",
"<BR> Kunne ikke �bne fil fra form\n<BR>",
"<BR> Bruger/kodeord er forkert!<BR>",
"<BR> Forkerte parametre til phpdbimage!<BR>"
);

define( "MSG_ADD_NEW_REC", "Tilf�j ny" );
define( "MSG_SELECT_BUTTON", "V�lg" );
define( "MSG_INSERT_BUTTON","opdater/inds�t" );
define( "MSG_INSERTONLY_BUTTON","Inds�t" );
define( "MSG_UPDATE_BUTTON","Opdater" );
define( "MSG_DELETE_BUTTON","      Slet     " );

define( "MSG_NAME", "Navn:");
define( "MSG_PASSWORD", "Kodeord:" );

define( "MSG_BYE", "Farvel!" );
?>