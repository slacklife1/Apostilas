<?php
// Mensagens em Portugu�s - Brasil
// Paulo Assis <paulo@coral.srv.br>

define( "CHARSET", "iso-8859-1" );
$error_msg = array(
	"<BR> N�o foi poss�vel conectar<BR>\n",
	"<BR> N�o foi poss�vel abrir o banco de dados<BR>\n",
	"<BR> N�o foi poss�vel *inserir* registro\n<BR>",
	"<BR> N�o foi poss�vel *alterar* o registro\n<BR>",
	"<BR> N�o foi poss�vel *excluir* o registro\n<BR>",
	"<BR> N�o foi poss�vel *ler* o registro\n<BR>",
	"<BR> N�o foi poss�vel *ler* a tabela para sele��o de registros\n<BR>",
	"<BR> N�o foi poss�vel ler tabela para a listbox\n<BR>",
	"<BR> N�mero do campo excede o definido na classe\n<BR>",
	"<BR> N�o foi poss�vel abrir arquivo do formul�rio\n<BR>",
	"<BR> Usu�rio/senha incorretos!<BR>",
	"<BR> Par�metros inv�lidos para o phpdbimage!<BR>"
);

define( "MSG_ADD_NEW_REC", "Adicionar Novo" );
define( "MSG_SELECT_BUTTON", "Selecionar" );
define( "MSG_INSERT_BUTTON", "Alterar/Adicionar" );
define( "MSG_INSERTONLY_BUTTON","Adicionar" );
define( "MSG_UPDATE_BUTTON","Alterar" );
define( "MSG_DELETE_BUTTON", "     Deletar     " );

define( "MSG_NAME", "Nome:");
define( "MSG_PASSWORD", "Senha:" );

define( "MSG_BYE", "Tchau..." );
?>
