<?php
// Polish Messages
// Marcin Chojnowski <martii@obgyn.edu.pl> 

define( "CHARSET", "iso-8859-2" );
$error_msg = array(
	"<BR> Nie mo�na si� po��czy�<BR>\n",
	"<BR> Nie mo�na otworzy� bazy<BR>\n",
	"<BR> Nie uda�o si� *wstawi�* rekordu\n<BR>",
	"<BR> Nie uda�o si� *aktualizowa�* rekordu\n<BR>",
	"<BR> Nie uda�o si� *usun��* rekordu\n<BR>",
	"<BR> Nie uda�o si� *odczyta�* rekordu\n<BR>",
	"<BR> Nie uda�o si� *odczyta�* tabeli lookup\n<BR>",
	"<BR> Nie uda�o si� *odczyta�* tabeli listbox\n<BR>",
	"<BR> Pole liczba przewy�sza ilo�� p�l w klasie\n<BR>",
	"<BR> Nie mo�na otworzy� pliku z formularza\n<BR>",
	"<BR> U�ytkownik/has�o niepoprawne!<BR>",
	"<BR> Z�e parametry dla phpdbimage!<BR>"
);

define( "MSG_ADD_NEW_REC", "Dodaj nowy" );
define( "MSG_SELECT_BUTTON", "Wybierz" );
define( "MSG_INSERT_BUTTON","Aktualizuj/Dodaj" );
define( "MSG_INSERTONLY_BUTTON","Dodaj" );
define( "MSG_UPDATE_BUTTON","Aktualizuj" );
define( "MSG_DELETE_BUTTON","      Usu�     " );

define( "MSG_NAME", "Nazwa:");
define( "MSG_PASSWORD", "Has�o:" );

define( "MSG_BYE", "Do zobaczenia!" );
?>
