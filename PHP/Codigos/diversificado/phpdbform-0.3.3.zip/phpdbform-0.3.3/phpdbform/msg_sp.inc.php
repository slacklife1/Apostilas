<?php
// Spanish Messages
// Roberto Rosario <skeletor@iname.com>

define( "CHARSET", "iso-8859-1" );
$error_msg = array(
	"<BR> Error conectando<BR>\n",
	"<BR> Error accesando base de datos<BR>\n",
	"<BR> Error *insertando* fichero\n<BR>",
	"<BR> Error *actualizando* fichero\n<BR>",
	"<BR> Error *borrando* fichero\n<BR>",
	"<BR> Error *leyendo* fichero\n<BR>",
	"<BR> Error *leyendo* tabla auxiliar de busqueda\n<BR>",
	"<BR> Error *leyendo* tabla remota para la lista\n<BR>",
	"<BR> Demasiados campos especificados\n<BR>",
	"<BR> Error accesando el fichero para la forma\n<BR>",
	"<BR> Error en nombre/contrase�a!<BR>",
	"<BR> Parametros incorrectos para phpdbimage!<BR>"
);

define( "MSG_ADD_NEW_REC", "A�adir otro" );
define( "MSG_SELECT_BUTTON", "Seleccionar" );
define( "MSG_INSERT_BUTTON","Actualizar/Crear" );
define( "MSG_INSERTONLY_BUTTON","Crear" );
define( "MSG_UPDATE_BUTTON","Actualizar" );
define( "MSG_DELETE_BUTTON","      Borrar     " );

define( "MSG_NAME", "Nombre:");
define( "MSG_PASSWORD", "Contrase�a:" );

define( "MSG_BYE", "Adios!" );
?>
