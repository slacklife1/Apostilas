<?php

define ("MSG_ERR_NO_CONN",			"0");
define ("MSG_ERR_NO_OPEN_DB",			"1");
define ("MSG_ERR_NO_INSERT",			"2");
define ("MSG_ERR_NO_UPDATE",			"3");
define ("MSG_ERR_NO_DELETE",			"4");
define ("MSG_ERR_NO_RECORD",			"5");
define ("MSG_ERR_NO_LOOKUP",			"6");
define ("MSG_ERR_NO_LISTBOX",			"7");
define ("MSG_ERR_TOO_MANY_FIELDS",		"8");
define ("MSG_ERR_NO_FILE",			"9");
define ("MSG_ERR_BAD_PASSWD",			"10");
define ("MSG_ERR_BAD_PARAM_IMAGE",		"11");
?>
