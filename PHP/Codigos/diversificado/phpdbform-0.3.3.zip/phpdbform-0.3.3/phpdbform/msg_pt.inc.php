<?php
// Mensagens em Portugu�s - Portugal
// Carlos Viana <carlos.a.viana@pop3si.com>

define( "CHARSET", "iso-8859-1" );
$error_msg = array(
	"<BR> N�o foi poss�vel fazer a conec��o � base de dados<BR>\n",
	"<BR> N�o foi poss�vel abrir a base de dados<BR>\n",
	"<BR> N�o foi poss�vel *inserir* registro\n<BR>",
	"<BR> N�o foi poss�vel *alterar* o registro\n<BR>",
	"<BR> N�o foi poss�vel *eliminar* o registro\n<BR>",
	"<BR> N�o foi poss�vel *ler* o registro\n<BR>",
	"<BR> N�o foi poss�vel *ler* a tabela para sele��o de registros\n<BR>",
	"<BR> N�o foi poss�vel ler tabela para a listbox\n<BR>",
	"<BR> N�mero do campo excede o definido na classe\n<BR>",
	"<BR> N�o foi poss�vel abrir ficheiro do formul�rio\n<BR>",
	"<BR> Utilizador/senha incorretos!<BR>",
	"<BR> Par�metros inv�lidos para o phpdbimage!<BR>"
);

define( "MSG_ADD_NEW_REC", "  Adicionar  " );
define( "MSG_SELECT_BUTTON", "  Selecionar  " );
define( "MSG_INSERT_BUTTON", "Alterar/Adicionar" );
define( "MSG_INSERTONLY_BUTTON","Adicionar" );
define( "MSG_UPDATE_BUTTON","Alterar" );
define( "MSG_DELETE_BUTTON", "     Eliminar     " );

define( "MSG_NAME", "Nome:");
define( "MSG_PASSWORD", "Password:" );

define( "MSG_BYE", "At� � pr�xima..." );
?>