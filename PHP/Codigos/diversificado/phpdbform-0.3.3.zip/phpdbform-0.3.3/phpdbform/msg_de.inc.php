<?php
// German Messages
// 23rd November 2000 - Goeran Zaengerlein - goeran@zaengerlein.de

define( "CHARSET", "iso-8859-1" );
$error_msg = array(
	"<BR> Kann keine Verbindung aufbauen<BR>\n",
	"<BR> Kann Datenbank nicht �ffnen<BR>\n",
	"<BR> Kann Eintrag nicht *einf�gen*\n<BR>",
	"<BR> Kann Eintrag nicht *�ndern*\n<BR>",
	"<BR> Kann Eintrag nicht *l�schen*\n<BR>",
	"<BR> Kann Eintrag nicht *lesen*\n<BR>",
	"<BR> Kann lookup-Tabelle nicht *lesen*\n<BR>",
	"<BR> Kann listbox-Tabelle nicht *lesen*\n<BR>",
	"<BR> Feld Anzahl �bersteigt die Zahl der Felder in der Klasse\n<BR>",
	"<BR> Can't open file from form\n<BR>",
	"<BR> User/password incorrect!<BR>",
	"<BR> Wrong parameters for phpdbimage!<BR>"
);

define( "MSG_ADD_NEW_REC", "Neu hinzuf�gen" );
define( "MSG_SELECT_BUTTON", "Ausw�hlen" );
define( "MSG_INSERT_BUTTON","�ndern/Einf�gen" );
define( "MSG_INSERTONLY_BUTTON","Einf�gen" );
define( "MSG_UPDATE_BUTTON","�ndern" );
define( "MSG_DELETE_BUTTON","      L�schen     " );

define( "MSG_NAME", "Name:");
define( "MSG_PASSWORD", "Passwort:" );

define( "MSG_BYE", "Bye!" );
?>
