<?php
// Messages en Fran�ais
// By Eric KASTLER - free.sites@surlewoueb.com

define( "CHARSET", "iso-8859-1" );
$error_msg = array(
	"<BR> Connection impossible<BR>\n",
	"<BR> Ne peut pas *ouvrir* la base de donn�e<BR>\n",
	"<BR> Ne peut pas *ins�rer* l'enregistrement\n<BR>",
	"<BR> Ne peut pas *mettre* � jour l'enregistrement\n<BR>",
	"<BR> Ne peut pas *effacer* l'enregistrement\n<BR>",
	"<BR> Ne peut pas *lire* l'enregistrement\n<BR>",
	"<BR> Ne peut pas *lire* le registre de la table\n<BR>",
	"<BR> Ne peut pas *lire* la table par liste d�roulante\n<BR>",
	"<BR> Le nombre de champs exc�de ceux d�finis dans la classe (class)\n<BR>",
	"<BR> Ne peut pas ouvrir le fichier depuis le formulaire\n<BR>",
	"<BR> Utilisateur/Mot de Passe incorrect !<BR>",
	"<BR> Wrong parameters for phpdbimage!<BR>"
);

define( "MSG_ADD_NEW_REC", "Ajouter un Enregistrement" );  // short = "Ajouter"
define( "MSG_SELECT_BUTTON", "S�lectionner" );
define( "MSG_INSERT_BUTTON","Mettre � jour/Ins�rer" );
define( "MSG_INSERTONLY_BUTTON","Ins�rer" );
define( "MSG_UPDATE_BUTTON","Mettre � jour" );
define( "MSG_DELETE_BUTTON","      Effacer     " );

define( "MSG_NAME", "Nom:");
define( "MSG_PASSWORD", "Mot de passe:" );

define( "MSG_BYE", "Bye!" );
?>
