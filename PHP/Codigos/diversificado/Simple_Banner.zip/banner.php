<!doctype html public "-//W3C//DTD HTML 4.0 //EN">
<html>
<head>
       <title>Simple Banner Display !</title>
</head>
<body>
<?php

/*############################################################################
This is very simple banner script, it displays banners listed in list.db file.
In file list.db you can place your url of site, image source and alt text.
Every record in list.db needs to be split with "|" char, otherwise that vars
will be listed as one.
When you input your banners in list.db all you have to do is include banner.php
in your index page and the code will display different banner every time.

I am working on bigger banner manager script that will use MySQL. In that new
script you will have visit counters, administration panel and stuff like that,
so visit my home page for more scripts !

Author: Armin Kalajdzija
E-Mail: kalajdzija@hotmail.com
Website: www.ak85.tk

Copyright Armin Kalajdzija, 2002.
############################################################################*/

$base_file = "list.db";     //banner list file
$count = 0;   //banner counter

if ($fdb = fopen($base_file,"r")) {   //file open
    while (!feof($fdb)) {
          $buffer = fgets($fdb,1024);     //get the first line of file


          if (isset($buffer) and ($buffer <> "")) {   //buffer check
             $count = $count + 1;
             list($link[$count],$src[$count],$altemp) = split("[|]",$buffer);   //split
             $alt[$count] = substr($altemp,0,(strlen($altemp) - 2));    //deletes the new line in alt

          }
    }
}

fclose($fdb);     //file closed

$display_banner = rand(1,$count);      //generates the randome number from 1 to the number of banners :)
echo "<a href=$link[$display_banner]><img src='$src[$display_banner]' alt='$alt[$display_banner]' border=0></a>";   //displays the image on site

?>
</body>
</html>
