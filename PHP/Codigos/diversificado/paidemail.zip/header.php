<?
include("config.php");
include("font.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title><? echo "$title"; ?></title>




<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
<style type="text/css">
.logoTop {position: relative; text-align:center; font-size:43px; color:RED; font-weight:bold; font-family: impact;}
.logoBottom {position: relative; text-align:center; font-size:24px; padding:0; color:RED; font-family: impact;}
</style>

</head><body bgcolor=BLUE>

<TABLE BORDER=1 BGCOLOR=BLUE WIDTH=100%>
               <TR>
                  <TD WIDTH=100%><PRE>
<form method='post' name='login' action='loginin.php'>
               User ID                       Password                    
          <input name='id' type='text'>          <input name='pass' type='password'>
          <input type='submit' name='submit' value='Login'>                       <input type='Reset'></form>
</TD>
</TR>
</TABLE>
<TABLE BORDER=1 BGCOLOR=BLUE WIDTH=100% HEIGHT=100%>
               <TR>
                  <TD WIDTH=30><CENTER><PRE>

<A HREF=''>Home</A> 


<A HREF='help.php'>HELP</A>


<A HREF='signup.php'>SignUp</A>



</TD>
<TD BGCOLOR=WHITE><CENTER><PRE>
<?
$filepointer = fopen("$path/message.dat", "r");
while (!feof($filepointer))
{
$line = fgets($filepointer, 4096);
print $line;
}
fclose($filepointer);
?></TD>
</TR>
</TABLE>