<?
include("c:/program files/apache group/apache/htdocs/include/config.php");
include("c:/program files/apache group/apache/htdocs/include/font.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title><? echo "$title"; ?></title>




<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
<style type="text/css">
.logoTop {position: relative; text-align:center; font-size:43px; color:RED; font-weight:bold; font-family: impact;}
.logoBottom {position: relative; text-align:center; font-size:24px; padding:0; color:RED; font-family: impact;}
</style>

</head><body bgcolor=BLUE>

<TABLE BORDER=1 BGCOLOR=BLUE WIDTH=100%>
               <TR>
                  <TD WIDTH=100%><CENTER><PRE>
<form method='post' name='login' action='loginin.php'>
               User ID                       Password                    
          <input name='id' type='text'>          <input name='pass' type='password'>
          <input type='submit' name='submit' value='Login'>                       <input type='Reset'></form>
</TD>
</TR>
</TABLE>
<TABLE BORDER=1 BGCOLOR=BLUE WIDTH=100%>
               <TR>
                  <TD WIDTH=30><CENTER><PRE>

<A HREF=''>Home</A> 


<A HREF='help.php'>HELP</A>


<A HREF='signup.php'>SignUp</A>


</TD>
<TD BGCOLOR=WHITE>
<?
if (isset($referal))
{
session_register("ref");
$ref = "$referal";
}
echo "<HTML>
           <head>
<title>$title</title>";

?>
<PRE><CENTER>
All fields are required.</CENTER>
<form  method='post' action='read.php'>
 <PRE>
First Name:  </font> <font face=arial size=6 color=red>*<input type='text' name='firstName' MAXLENGTH='75'></font>
Last Name:   </font> <font face=arial size=6 color=red>*<input type='text' name='lastName' MAXLENGTH='75'></font>
E-Mail:      </font> <font face=arial size=6 color=red>*<input type='text' name='email' MAXLENGTH='75'></font>
Address:     </font> <font face=arial size=6 color=red>*<input type='text' name='address'></font> 
Zip Code:    </font> <font face=arial size=6 color=red>*<input type='text' name='zip'  MAXLENGTH='75'></font>
City:        </font> <font face=arial size=6 color=red>*<input type='text' name='city'></font>
State:       </font> <font face=arial size=6 color=red>*<input type='text' name='state'></font>
URL:         </font> <font face=arial size=6 color=red>*<input type='text' name='url'></font>
User ID:     </font> <font face=arial size=6 color=red>*<input type='text' name='user'></font> Select a unique user id.
Password:    </font> <font face=arial size=6 color=red>*<input type='text' name='password'></font>
<CENTER><input type='submit' name='submit'>
</form>

</TD>
</TR>
</TABLE>