<?
$msite_url = 'http://supersearch.no-ip.org/paidemail';
$title = 'Paid-E-mail';
$admin_path = 'c:/program files/apache group/apache/htdocs/paidemail/admin';
$admin_email = 'f.mix@attbi.com';
$admin_url = 'http://supersearch.no-ip.org/paidemail/admin';
$path = 'c:/program files/apache group/apache/htdocs/paidemail';
?>
