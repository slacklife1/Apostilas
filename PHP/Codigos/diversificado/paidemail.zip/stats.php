<?
if (isset($logedin))
{
include("cheader.php");
include("$path/member/$user.info.dat");

}
else
{
include("header.php");
}
//if (isset($news))
//{

//$filepointer = fopen("$path/member/news.dat", "r");
//while (!feof($filepointer))
//{
//$line = fgets($filepointer, 4096);
//print $line;
//}
//fclose($filepointer);
//}
?>

<HTML><HEAD><TITLE><?print "$title $blogo";?></title></head>
<BODY><CENTER>
<table border=1 width=100%>
<tr>
<td><CENTER>ClickThrus earned.</CENTER></td>
<td>
<?


$counter_file = "$path/member/$user.pclick.dat"; 
$accNum = file($counter_file); 
$a = $accNum[0] / 2;
echo "$a";

?></td>

</tr>
</table>
 
<PRE> 
Copy and past the code below into your web page.
<?

echo "<TEXTAREA ROWS=4 COLS=30>$code</TEXTAREA>";
?>

  
 
