<?
include("config.php");
$link = @mysql_connect("$db_host", "$db_user", "$db_pass");
if (mysql_create_db("$db_name", $link) == true)
{
echo "Database created";
}
else
{
echo "connection error";
}
mysql_close($link);
?>