<?
$step1 = fopen("$path/config.php", "w+");
fputs($step1, "<?\r\n");
fputs($step1, "$", 1024);
fputs($step1, "msite_url = '$site_url'", 1024);
fputs($step1, ";\r\n", 1024);
fputs($step1, "$", 1024);
fputs($step1, "title = '$title'", 1024);
fputs($step1, ";\r\n", 1024);
fputs($step1, "$", 1024);
fputs($step1, "admin_path = '$admin_path'", 1024);
fputs($step1, ";\r\n", 1024);
fputs($step1, "$", 1024);
fputs($step1, "admin_email = '$admin_email'", 1024);
fputs($step1, ";\r\n", 1024);
fputs($step1, "$", 1024);
fputs($step1, "admin_url = '$admin_url'", 1024);
fputs($step1, ";\r\n", 1024);
fputs($step1, "$", 1024);
fputs($step1, "path = '$path'", 1024);
fputs($step1, ";\r\n", 1024);
fputs($step1, "?>\r\n");
fclose($step1);
$step2 = fopen("$path/go/config.php", "w+");
fputs($step2, "<?\r\n");
fputs($step2, "$", 1024);
fputs($step2, "msite_url = '$site_url'", 1024);
fputs($step2, ";\r\n", 1024);
fputs($step2, "$", 1024);
fputs($step2, "title = '$title'", 1024);
fputs($step2, ";\r\n", 1024);
fputs($step2, "$", 1024);
fputs($step2, "admin_path = '$admin_path'", 1024);
fputs($step2, ";\r\n", 1024);
fputs($step2, "$", 1024);
fputs($step2, "admin_email = '$admin_email'", 1024);
fputs($step2, ";\r\n", 1024);
fputs($step2, "$", 1024);
fputs($step2, "admin_url = '$admin_url'", 1024);
fputs($step2, ";\r\n", 1024);
fputs($step2, "$", 1024);
fputs($step2, "path = '$path'", 1024);
fputs($step2, ";\r\n", 1024);
fputs($step2, "?>\r\n");
fclose($step2);





if ($step2 == true)
{
echo "config.php is built.";
echo "<meta http-equiv='Refresh' content='1; URL=$msite_url'>";
}
else
{
echo "<CENTER>Check first to see if the config.php was created,<BR>if not then contact the
developer at f.mix@attbi.com";
}
?>