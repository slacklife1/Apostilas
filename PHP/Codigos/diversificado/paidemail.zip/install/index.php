<HTML>
     <HEAD>
          <TITLE>Welcome to Freemans Custom Designs Setup</TITLE>
</HEAD>

<BODY BGCOLOR=WHITE>
<TABLE BORDER=1 BGCOLOR=BLUE WIDTH=100%>
<TR>
<TD><CENTER>
Setup
</TD>
</TR>
</TABLE>


<TABLE BORDER=1 BGCOLOR=BLUE HEIGHT=100% WIDTH=100%>
<TR>
<TD BGCOLOR=WHITE>
<PRE><CENTER>
User Agreement
By installing and using this software you as the purchaser agree
to the following terms.

The copyright and sole owner of the design belongs to the developer
Freeman Mix also known as Freemans Custom Designs.
You the purchaser agree that if any alterations take place you 
the purchaser will notify the developer of the changes you the 
purchaser will and cannot resell the software inclosed in this package, 
you the purchaser take full responsibility for the way you use this 
software. In other wards you just purchase the right to use the
inclosed software you may alter it for your own use only.
if you agree to these terms you may continue. Thank You for your
Purchase through Freemans Custom Designs!

<CENTER><A HREF='step1.php'>NEXT</A>
</TD>
</TR>
</TABLE>


<TABLE BORDER=1 BGCOLOR=BLUE WIDTH=100%>
<TR>
<TD>
</TD>
</TR>
</TABLE>
</BODY>
</HTML>
