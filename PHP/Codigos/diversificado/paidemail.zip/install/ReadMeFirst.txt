This script has been redone do to a error when files were bieng zipped.

To install:
------------------------------------------------------------------------
open the install directory in your browser. eg(http://www.you.com/install/)
and follow the instructions thats all there is to it.
if by any chance somthing goes wrong just send us a email and we will fix the new problems.
if you are using unix make sure to set the proper permissions on the directories.
they will need read and wright permission.
please keep in mind that these scripts are done on win,
and they use sessions alot.At this current time you will have to set the redirect url manually.
we are currently working on a mysql version that will have a auto send script.
if you have trouble after the setup is complete look through
the scripts for $aurl and change it to $msite_url. that was the big trouble maker.
thank you. if you try this on unix let us know how it goes.

Developer email:
f.mix@attbi.com