<HTML>
     <HEAD>
          <TITLE>Welcome to Freemans Custom Designs Setup step1</TITLE>
</HEAD>

<BODY BGCOLOR=WHITE>
<TABLE BORDER=1 BGCOLOR=BLUE WIDTH=100%>
<TR>
<TD><CENTER>
Setup step1
</TD>
</TR>
</TABLE>


<TABLE BORDER=1 BGCOLOR=BLUE HEIGHT=100% WIDTH=100%>
<TR>
<TD BGCOLOR=WHITE>
<PRE><CENTER>
First you will need to enter the info for you to build your
config.php file. Do not use trailing / slashes on any of the paths.</CENTER>


<form  method='post' action='setup_step1.php'>
 <PRE>
The full path to the main index. remember no trailing slashes/.
Path:              </font> <font face=arial size=6 color=red>*<input type='text' name='path'></font>
The full url to the admin directory.eg(http://your.index/admin)
Admin URL:         </font> <font face=arial size=6 color=red>*<input type='text' name='admin_url'></font>
The full path to the admin directory. eg(c:/path)
Admin Path:        </font> <font face=arial size=6 color=red>*<input type='text' name='admin_path'></font>
Your email address.
Admin E-Mail:      </font> <font face=arial size=6 color=red>*<input type='text' name='admin_email'></font>
The full url to the front index of the program.
Site URL:          </font> <font face=arial size=6 color=red>*<input type='text' name='site_url'></font>
Select a name for your affiliate site.
Site Title:        </font> <font face=arial size=6 color=red>*<input type='text' name='title'></font> Select a unique user id.

<CENTER><input type='submit' name='submit'></CENTER>
</form>

</TD>
</TR>
</TABLE>


<TABLE BORDER=1 BGCOLOR=BLUE WIDTH=100%>
<TR>
<TD>
</TD>
</TR>
</TABLE>
</BODY>
</HTML>
