<?
session_start();
session_register("user");
$user = "$id";
include("config.php");
$file = "$path/member/$user.pass.dat";
if (file_exists($file))
{

include("$path/member/$user.pass.dat");

if (($id == $user) and ($pass == $password))
{
header("SET-COOKIE: logedin=$id; expires=Monday, 07-Jan-2005 00:00:00 GMT;");

echo "<meta http-equiv='Refresh' content='2; URL=$msite_url/stats.php'>";

}
else
{
echo "<center>You Entered the wrong username or password</center>";
echo "<center><PRE>
          <form method='post' name='login' action='loginin.php'>
               Login
User ID:  <input name='id' type='text'>
Password: <input name='pass' type='password'></td></tr>
          <input type='submit' name='submit'><input type='Reset'></form>";
}

}
else
{
echo "<center>You Entered the wrong username or password</center>";
echo "<center><PRE>
          <form method='post' name='login' action='loginin.php'>
               Login
User ID:  <input name='id' type='text'>
Password: <input name='pass' type='password'></td></tr>
          <input type='submit' name='submit'><input type='Reset'></form>";
}

?>