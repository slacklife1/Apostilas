<?
session_start();
include("cheader.php");
include("$path/member/$user.info.dat");

echo "<HTML>
           <head>
<title>$title</title>";

?>
<body bgcolor=white>
<PRE><CENTER>
All fields are required.</CENTER>
<form  method='post' action='edit.php'>
 <PRE>
First Name:  </font> <font face=arial size=6 color=red>*<input type='text' name='firstName' value='<?print "$firstName";?>' MAXLENGTH='75'></font>
Last Name:   </font> <font face=arial size=6 color=red>*<input type='text' name='lastName' value='<?print "$lastName";?>' MAXLENGTH='75'></font>
E-Mail:      </font> <font face=arial size=6 color=red>*<input type='text' name='email'  value='<?print "$email";?>'MAXLENGTH='75'></font>
Address:     </font> <font face=arial size=6 color=red>*<input type='text' name='address' value='<?print "$address";?>'></font>  
Zip Code:    </font> <font face=arial size=6 color=red>*<input type='text' name='zip'  value='<?print "$zip";?>' MAXLENGTH='75'></font>
City:        </font> <font face=arial size=6 color=red>*<input type='text' name='city' value='<?print "$city";?>'></font>
State:       </font> <font face=arial size=6 color=red>*<input type='text' name='state' value='<?print "$state";?>'></font>
<CENTER><input type='submit' name='submit' value='Update'>
</form>
</body>
</HTML>

<?



?>
