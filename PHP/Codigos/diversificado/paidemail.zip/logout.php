<?
session_start();
session_unset();
include("config.php");
if (isset($logedin))
{
setcookie("logedin", "", time() - 60);
echo "<meta http-equiv='Refresh' content='1; URL=$msite_url/index.php'>";
}
else
{
echo "<meta http-equiv='Refresh' content='1; URL=$msite_url/index.php'>";

}


?>