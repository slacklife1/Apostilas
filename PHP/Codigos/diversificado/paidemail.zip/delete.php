<?
session_start();
session_unregister("$user");
setcookie("logedin", "", time() - 60);

include("config.php");






if (file_exists("$path/member/$user.info.dat"))
{
unlink("$path/member/$user.info.dat");
echo "<center>Account deleted</center>";
}



if (file_exists("$path/member/$user.total.dat"))
{
unlink("$path/member/$user.total.dat");
echo "<center>Account deleted</center>";
}



if (file_exists("$path/member/$user.pclick.dat"))
{
unlink("$path/member/$user.pclick.dat");
echo "<center>Account deleted</center>";
echo "<meta http-equiv='Refresh' content='3; URL=$aurl/index.php'>";
}

//if (file_exists("$path/member/$user.ref.dat"))
//{
//unlink("$path/member/$user.ref.dat");
//echo "<center>Account deleted</center>";
//}


?>