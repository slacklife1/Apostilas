<TABLE BORDER=1 BGCOLOR=BLUE WIDTH=100% HEIGHT=100%>
               <TR>
                  <TD WIDTH=30><CENTER><PRE>

<A HREF=''>Home</A> 


<A HREF='help.php'>HELP</A>


<A HREF='signup.php'>SignUp</A>


<A HREF='login.php'>Login</A>
</TD>
<TD BGCOLOR=WHITE>
<?
echo "$message";
?>

</TD>
</TR>
</TABLE>



