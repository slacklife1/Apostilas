<TABLE BORDER=1 BGCOLOR=BLUE WIDTH=100% HEIGHT=100%>
               <TR>
                  <TD WIDTH=30><CENTER><PRE>

<A HREF=''>Home</A> 


<A HREF='help.php'>Help</A>


<A HREF='stats.php?news=show'>News</A>


<A HREF='stats.php'>Stats</A>


<A HREF='edituser.php'>Edit user info</A>


<A HREF='delete.php'>Delete account</A>


<A HREF='logout.php'>Log Out</A>

</TD>
<TD BGCOLOR=WHITE>
<?
echo "$message";
?>

</TD>
</TR>
</TABLE>



