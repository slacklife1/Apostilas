<?
if (isset($logedin))
{

include("header.php");
}
else
{
include("header.php");
}

?>
<HTML>
    <HEAD>
         <TITLE><?print "$title $blogo";?></TITLE>
</HEAD>




