<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>





<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
<STYLE TYPE="text/css">;
.text12 { font-size: 12pt; font-family: Helvetica, Arial, sans-serif };
.text11 { font-size: 11pt; font-family: Helvetica, Arial, sans-serif };
.text10 { font-size: 10pt; font-family: Helvetica, Arial, sans-serif };
.text9 { font-size: 9pt; font-family: Helvetica, Arial, sans-serif };
.text8 { font-size: 8pt; font-family: Helvetica, Arial, sans-serif };
.text7 { font-size: 7.5pt; font-family: Helvetica, Arial, sans-serif };
.standard {font-size: 10 pt; font-family: Verdana, arial, helvetica, sans-serif};
.midd {font-size: 9 pt; font-family: Verdana, arial, helvetica, sans-serif};
.small {font-size: 8 pt; font-family: Verdana, arial, helvetica, sans-serif};
a:link, a:visited {
 color: RED;
 text-decoration: underline;
 font-weight: ;
}
a:hover, a:active {
 color: <? echo "$linkcoloractive";  ?>;
 text-decoration: underline;
 font-weight: bold;
}
</style>
</head>


