<?
session_start();
include("config.php");
?>

<?
$credit ='1';
$counter_file = "$path/member/$user.pclick.dat"; 
$accNum = file($counter_file); 
$a = $accNum[0]+=$credit;
$cf = fopen("$path/member/$user.pclick.dat", "w");
fputs($cf, "$a\r\n", 1024);  
fclose($cf);

?>
<html>

<head>
<?
echo "<META HTTP-EQUIV='refresh' content='1;URL=$ur1'>";
?>
<title>Page will change shortly</title>
</head>

<body>

<div align="center">
  <center>
  <table border="1" width="100%" bordercolor="#000000" cellspacing="0" cellpadding="5" bgcolor="#FFFF00" height="100%">
    <tr>
      <td width="100%" valign="middle" align="center">
        <p align="center"><font color="#000000" size="5" face="Verdana"><b>
        You will be redirected shortly.</b></font></td>
    </tr>
  </table>
  </center>
</div>

</body>

</html>
