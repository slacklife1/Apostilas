<?

include("config.php");
?>
<?php

$infofile = "$path/member/$user.info.dat";
if (file_exists($infofile))
{

$info = fopen("$infofile", "a+");
fputs($info, "<?\r\n");
fputs($info, "$");
fputs($info, "firstName");
fputs($info, "='$firstName';\r\n");
fputs($info, "$");
fputs($info, "lastName");
fputs($info, "='$lastName';\r\n");
fputs($info, "$");
fputs($info, "email");
fputs($info, "='$email';\r\n");
fputs($info, "$");
fputs($info, "address");
fputs($info, "='$address';\r\n");
fputs($info, "$");
fputs($info, "zip");
fputs($info, "='$zip';\r\n");
fputs($info, "$");
fputs($info, "city");
fputs($info, "='$city';\r\n");
fputs($info, "$");
fputs($info, "state");
fputs($info, "='$state';\r\n");
fputs($info, "$");
fputs($info, "refcode");
fputs($info, "='$msite_url/signup.php?ref=$user';\r\n");
fputs($info, "?>\r\n");
fclose($info);



echo "<center>Your account has been updated!</center>";
echo "<meta http-equiv='Refresh' content='3; URL=$aurl/edituser.php'>";
}

else
{
print "Data Base Error";
}
?>