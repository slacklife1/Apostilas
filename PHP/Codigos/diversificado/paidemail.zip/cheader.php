<?
include("config.php");
include("font.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title><? echo "$title"; ?></title>




<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
<style type="text/css">
.logoTop {position: relative; text-align:center; font-size:43px; color:RED; font-weight:bold; font-family: impact;}
.logoBottom {position: relative; text-align:center; font-size:24px; padding:0; color:RED; font-family: impact;}
</style>

</head><body bgcolor=BLUE>

<TABLE BORDER=1 BGCOLOR=BLUE WIDTH=100%>
               <TR>
                  <TD WIDTH=100%><CENTER>
<span class="logoBottom"><CENTER><?print "$blogo";?></CENTER></span>
</TD>
</TR>
</TABLE>
<TABLE BORDER=1 BGCOLOR=BLUE WIDTH=100% HEIGHT=100%>
               <TR>
                  <TD WIDTH=30><CENTER><PRE>

<A HREF=''>Home</A> 


<A HREF='help.php'>Help</A>


<A HREF='stats.php?news=show'>News</A>


<A HREF='stats.php'>Stats</A>


<A HREF='edituser.php'>Edit user info</A>


<A HREF='delete.php'>Delete account</A>


<A HREF='logout.php'>Log Out</A>

</TD>
<TD BGCOLOR=WHITE>
