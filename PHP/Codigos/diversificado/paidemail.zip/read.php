<?

include("config.php");

if (isset($ref))
{
$counter_file = "$path/member/$ref.ref.dat"; 
$accNum = file($counter_file); 
$accNum[0]++; 
$reffile = "$path/member/$ref.ref.dat";
$refclick = fopen("$reffile", "w+");
fputs($refclick, "$accNum[0]\r\n");
fclose($refclick);

}

$infofile = "$path/member/$user.info.dat";
if (file_exists($infofile))
{
print "The user Name is already in use go back and try again";
}
else
{
$info = fopen("$infofile", "a+");
fputs($info, "<?\r\n");
fputs($info, "$");
fputs($info, "firstName");
fputs($info, "='$firstName';\r\n");
fputs($info, "$");
fputs($info, "lastName");
fputs($info, "='$lastName';\r\n");
fputs($info, "$");
fputs($info, "email");
fputs($info, "='$email';\r\n");
fputs($info, "$");
fputs($info, "address");
fputs($info, "='$address';\r\n");
fputs($info, "$");
fputs($info, "zip");
fputs($info, "='$zip';\r\n");
fputs($info, "$");
fputs($info, "city");
fputs($info, "='$city';\r\n");
fputs($info, "$");
fputs($info, "state");
fputs($info, "='$state';\r\n");
fputs($info, "$");
fputs($info, "code");
fputs($info, "='<A HREF=\"$msite_url/go/?user=$user\">\r\nThe most Revenue generating program on the web.</A>';\r\n");
fputs($info, "?>\r\n");
fputs($info, "$");
fputs($info, "url");
fputs($info, "='$url';\r\n");
fputs($info, "?>\r\n");
fclose($info);
}

$passfile = "$path/member/$user.pass.dat";
if (file_exists($passfile))
{
print "The user Name is already in use go back and try again";
}
else
{
$pass = fopen("$passfile", "a+");
fputs($pass, "<?\r\n");
fputs($pass, "$");
fputs($pass, "user");
fputs($pass, "='$user';\r\n");
fputs($pass, "$");
fputs($pass, "password");
fputs($pass, "='$password';\r\n");
fputs($pass, "?>\r\n");
fclose($pass);
}

$totalfile = "$path/member/$user.total.dat";
if (file_exists($totalfile))
{
print "The user Name is already in use go back and try again";
}
else
{
$total = fopen("$totalfile", "a+");
fputs($total, "30.00\r\n");
fclose($total);
}


//$reffile = "$path/member/$user.ref.dat";
//if (file_exists($reffile))
//{
//print "The user Name is already in use go back and try again";
//}
//else
//{
//$refclick = fopen("$reffile", "w+");
//fputs($refclick, "0\r\n");
//fclose($refclick);
//}



$pclickfile = "$path/member/$user.pclick.dat";
if (file_exists($pclickfile))
{
print "The user Name is already in use go back and try again";
}
else
{
$pclick = fopen("$pclickfile", "a+");
fputs($pclick, "8000\r\n");
fclose($pclick);

echo "<center>Your account has been created!</center>";
echo "<meta http-equiv='Refresh' content='3; URL=$msite_url/index.php'>";

}
?>