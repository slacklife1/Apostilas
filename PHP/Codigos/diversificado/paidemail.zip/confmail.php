<?
session_start();
include("header.php");
echo "<html><body>";
mail ("$email", "Piad to Email ", "Thank you for joining $title program\nClick to continue:\nhttp://supersearch.no-ip.org/signup.php?email=$email&referal=$ref");

echo "<PRE>A E-mail has been sent to the E-mail address you provided\n";
echo "Follow the instructions in it to complete the process.";
echo "</body></html>";

?>