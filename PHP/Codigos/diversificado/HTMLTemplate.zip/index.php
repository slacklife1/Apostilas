<?php include("compressedtemplateclass.php"); ?>
<?php
 $template = new template();
 $template->usetemplate("message.tpl");
 $template->tag("MyTag","This text is italic.");
 $template->tag("MySecondTag","Change this text to bold.","b");
 $template->tag("message","This is from a string.","b");
 $template->tag("self",$template->gettemplate("message.tpl",true));
 $template->tag("phpcode",$template->gettemplate("index.php"));
 $template->tag("howtouse",$template->gettemplate("howtouse.tpl"));
 $template->tag("templateclass.php",$template->gettemplate("templateclass.php",true));
 $template->display();
?>