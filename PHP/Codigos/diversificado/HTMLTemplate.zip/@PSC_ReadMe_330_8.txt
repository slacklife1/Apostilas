Title: HTML Templates for PHP using BFCTemplate v2
Description: I've outdone myself again! Here's probably the last version. Hmm....I think this class should be compiled into the PHP kernal. Anyway, here it is. This version has the capability to mimic any HTML tag, though some may be a little awkward, and it has a new attribute for the tag() function to overide the predefined tag prototype. Check it out...Oh...and at least rate it...Sheesh!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=330&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
