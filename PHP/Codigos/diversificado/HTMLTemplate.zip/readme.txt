I've included a compress version of the template class.
I would suggest using that one for your site.

-Christopher Brown-Floyd
mailto:chris@bfworld.com
