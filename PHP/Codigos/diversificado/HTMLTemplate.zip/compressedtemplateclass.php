<?php
/* 
   BFCTemplate-PHP Version 1
   CREATED BY: Christopher Brown-Floyd
   Email: chris@bfworld.com
   DATE CREATED: May 25, 2001
*/
class template {
var $thistemplate="";
function usetemplate($_pth) {$this->thistemplate = $this->gettemplate($_pth);}

function gettemplate($_pth,$encodetohtml=false) {$_tpl = "";
if (file_exists($_pth)) {$templatefp = fopen($_pth, "r");if (!feof($templatefp)) {$_tpl = fread($templatefp,filesize($_pth));}fclose($templatefp);}
if ($encodetohtml) {$_tpl = $this->tohtml($_tpl);}return $_tpl;}

function tag($tagname,$uservalue,$overidetype="") {
$_ts = 0;$_te = 0;$divstart = "";$divend = "";$pstart = 0;$tagprototype = "";$tagprotolen = false;
$tagparams = "";$ld = "<tag:" . $tagname;$rd = "/>";$vt=false;$start_te = 0;$starttaglen = strlen($ld);
$_tpl = $this->thistemplate;while (($_ts<=strlen($_tpl)) && ($_ts>=0)) {$_ts = strpos($_tpl,$ld,$_ts);
if (is_bool($_ts)) {break;}$_te = strpos($_tpl,$rd,$_ts);$start_te = $_ts + $starttaglen;
if ($_te>$starttaglen) {$tagparams = substr($_tpl,$_ts+$starttaglen,$_te-$start_te);if ($tagparams!="") {
$pstart = strpos($tagparams,"as=");if (is_integer($pstart)) {$tagprototype = trim(substr($tagparams,$pstart,strpos($tagparams," ",$pstart)-$pstart));
$tagparams = trim(str_replace($tagprototype," ",$tagparams));$tagprotolen = strrpos($tagprototype,"\"");
if (is_integer($tagprotolen) && $tagprotolen==0) {$tagprotolen = 1;}else {$tagprotolen = $tagprotolen-4;}
$tagprototype = trim(substr($tagprototype,4,$tagprotolen));}}if ($overidetype!="") {$tagprototype=$overidetype;}
if ($tagprototype=="input") {$vt=true;}if (!$vt && $tagprototype!="") {$divstart = "<".trim($tagprototype." ".$tagparams).">";
$divend = "</" . $tagprototype . ">";$_tpl = substr($_tpl,0,$_ts).$divstart.$uservalue.$divend.substr($_tpl,$_te+2);} elseif ($tagprototype!="") {
$_tpl = substr($_tpl,0,$_ts)."<".$tagprototype." ".$tagparams.' value="'.$uservalue.'" />'.substr($_tpl,$_te+2);
} else {$_tpl = substr($_tpl,0,$_ts).$uservalue.substr($_tpl,$_te+2);}$_ts = $_te+2;$vt=false;}}$this->thistemplate = $_tpl;}

function saveas($_pth) {if (file_exists($_pth)) {rename($_pth,$_pth . ".bak");}
$templatefp = fopen($_pth, "w");$fout = fwrite($templatefp,$this->thistemplate);fclose($templatefp);}

function display() {echo($this->thistemplate);}

function htmlencode() {$this->thistemplate = $this->tohtml($this->thistemplate);}

function tohtml($_tpl) {$phpcrlf = chr(13).chr(10);$_tpl = str_replace("&","&amp;",$_tpl);$_tpl = str_replace("<","&lt;",$_tpl);
$_tpl = str_replace(" ","&nbsp;",$_tpl);$_tpl = str_replace($phpcrlf,"<br />",$_tpl);return $_tpl;}

function removetags() {$_ts = 0;$_te = 0;$ld = "<tag:";$rd = "/>";$starttaglen = strlen($ld);
$_tpl = $this->thistemplate;while (($_ts<=strlen($_tpl)) && ($_ts>=0)) {$_ts = strpos($_tpl,$ld,$_ts);
if (!$_ts) {break;}if ($_ts>=0) {$_te = strpos($_tpl,$rd,$_ts);if ($_te>$starttaglen) {
$_tpl = substr($_tpl,0,$_ts).substr($_tpl,$_te+2);$_ts = $_te+2;}}}$this->thistemplate = $_tpl;}}
?>