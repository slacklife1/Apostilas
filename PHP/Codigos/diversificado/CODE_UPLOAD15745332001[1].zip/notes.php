<?php
header ("Cache-Control: no-cache, must-revalidate");  // HTTP/1.1
header ("Pragma: no-cache");                          // HTTP/1.0
//-----------------------------------------------------------------//
//  Notes V1.0                                                     //
//                                                                 //
//      Coded by Don Steele                                        //
//       Don@starsplace.net                                        //
//                                                                 //
//       this script is released free under the GNU license        //
//       No Warrenties are provided with this script               //
//       use at your own risk of data loss, security breaches,     //
//       distruction of the known world, and loss of hair          //
//-----------------------------------------------------------------//

########Begin Config############
//mysql login
$login="mylogin";
//mysql password
$pass ="mypassword";
//this should stay loclhost unless u are connectiong to a diffrent server
$db=mysql_connect("localhost",$login,$pass);
//this is the database where the table "notes" resides
mysql_select_db("mydatabase",$db);
//set this to 1 if you would prefer that the list of records appere in a table
//instead of a listbox
$table="0";
########End Config##############



switch ($main) {
case left:
//print the left nav
leftnav($db,$table,$PHP_SELF);
break;
case right:
//print the right nav
$dy = date("m-d-Y h:i:s a");
print "<html>";
print "<h2>Notes v1.0 <br> $dy</h2><br>";
print "</html>";
break;
}

if ($id) {
//fetch the record with the id passed
print_page("select * from notes where id = '$id'",$db,$PHP_SELF);
}

if ($select) {
//fetch the record with the name passed
print_page("select * from notes where name = '$select'",$db,$PHP_SELF);
}

if ($action == "Save"){
//save an existing record
save_page($message,$t3,$id,$db);
}

if ($action == "Delete") {
//delete a record
delete_record($id,$db);
}

if ($action == "New") {
//new record
new_record($PHP_SELF);
}

if ($pleasedo == "Save") {
save_new($message,$t3,$db);
}

######### nothing to do build default page #########
print <<<_EOF_

<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<frameset cols="161,622*" frameborder="NO" border="0" framespacing="0" rows="*">
  <frame name="leftFrame" src="$PHP_SELF?main=left">
  <frame name="mainFrame" src="$PHP_SELF?main=right">
</frameset>
<noframes><body bgcolor="#FFFFFF">

</body></noframes>
</html>

_EOF_;

################### end of default page ###############

######################## end of if statements ###########################
######################## begin functions      ###########################



function delete_record($id,$db) {
//delete a record
$sql="delete from notes where id = '$id'";
$result=MySQL_query($sql,$db);
refresh_page($PHP_SELF,$db);

}


function save_new($message,$t3,$db) {
$dtime=date("m-d-Y h:i:s a");
$message=addslashes($message);
$name=addslashes($t3);
$sql="insert into notes values ('0','$message','$dtime','$name')";
$result=MySQL_query($sql,$db);
refresh_page($PHP_SELF,$db);
}


function save_page($message,$t3,$id,$db) {


//save a record
$dtime=date("m-d-Y h:i:s a");
$message=addslashes($message);
$name=addslashes($t3);
$sql="delete from notes where id = '$id'";
$result=MySQL_query($sql,$db);
$sql="insert into notes values ('0','$message','$dtime','$name')";
$result=MySQL_query($sql,$db);
refresh_page($PHP_SELF,$db);
}

function refresh_page($PHP_SELF,$db) {
print <<<_EOF_
<script language="JavaScript">
parent.location="$PHP_SELF?main=";
</script>

_EOF_;
mysql_close($db);
exit;
}


function new_record($PHP_SELF) {
//print the blank page to add a record
print <<<_EOF_

<html>
<head>
<title>Untitled Document</title>
</head>
<body bgcolor="#FFFFFF">
<form name="form1" action="$PHP_SELF" method="post">
<center>Type your note and click SAVE<br>
<input type="text" name="t3" value="">
<input type="hidden" name="id" value=""><br>
<textarea name="message" cols="70" rows="20"
wrap="VIRTUAL"></textarea><br>
<input type="submit" name="pleasedo" value="Save">
</center>
</form>
<p>&nbsp;</p><p>&nbsp;</p></body>
</html>

_EOF_;

}

function print_page ($sql,$db,$PHP_SELF) {
if ($table == "") { $table="0"; }
//connect to the database
mysql_select_db("stuff",$db);
$result=MySQL_query($sql,$db);
$myrow=MySQL_fetch_array($result);
$note=stripslashes($myrow["note"]);
$date=stripslashes($myrow["date"]);
$id=stripslashes($myrow["id"]);
$name=stripslashes($myrow["name"]);
//print out the page


print <<<_EOF_

<html>
<head>
<title>Untitled Document</title>
</head>
<body bgcolor="#FFFFFF">
<form name="form1" action="$PHP_SELF" method="post">
<center>last modified $date <br>
<input type="text" name="t3" value="$name">
<input type="hidden" name="id" value="$id"><br>
<textarea name="message" cols="70" rows="20"
wrap="VIRTUAL">$note</textarea><br>
<input type="submit" name="action" value="Save">
<input type="submit" name="action" value="Delete">
</center>
</form>
<p>&nbsp;</p><p>&nbsp;</p></body>
</html>

_EOF_;
}

function leftnav($db,$table,$PHP_SELF) {
//for some reason this acts wierd when done with the print <<< _EOF_
// so i left it this way ????? any suggestions
$sql="select * from notes order by name";
$result=MySQL_query($sql,$db);

print "<html>";
print "<head>";
print "<title>Untitled Document</title>";
print "<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>";
print "</head>";
print "<body bgcolor='#669900' text='#FFFFFF' link='#FFFFFF' vlink='#FFFFFF' alink='#FFFFFF'>";
if ($table == "0") { print "<form name=\"form1\" method=\"post\" action=\"$PHP_SELF\" target=\"mainFrame\">\n"; }
print "<table width='85%' border='1' align='left'>";
print "<tr bgcolor='#336600'>";
print "<td>Notes:</td>";
print "</tr>";
print "<tr>";
print "<td bgcolor='#0099FF'><a href='$PHP_SELF?action=New' target='mainFrame'>[Add Note]</a></td>";
print "</tr>";
print "<tr bgcolor='#666600'>";
print "<td>Current Notes</td>";
print "</tr>";
if ($table == "1") {
while($myrow=MySQL_fetch_array($result))
 {
$t3=stripslashes($myrow["name"]);
$id=$myrow["id"];
print "<tr>";
print "<td><a href='$PHP_SELF?id=$id' target='mainFrame'>$t3</a></td>";
print "</tr>";
}
}
if ($table == "0") {

print "  <tr><td><select name=\"select\" size=\"15\">\n";
while($myrow=MySQL_fetch_array($result))
 {
$t3=stripslashes($myrow["name"]);
$id=$myrow["id"];
print "    <option>$t3</option>\n";
}
print "  </select><br><input type=\"Submit\" name=\"ntable\" value=\"View\"</td></tr>\n";
}

print "</table>";
if ($table == "0") { print "</form>";  }
print "<p>&nbsp; </p>";
print "<p>&nbsp;</p>";
print "<p>&nbsp;</p>";
print "</body>";
print "</html>";



}
?>
