BLOG - An Open Source Diary/Journal/Blog Script
by Jonathan Beckett (jonbeckett@pluggedout.com)
===============================================

Version 1.51 beta


Contents
========
 - Introduction
 - Internet Links for the Blog Project
 - Requirements
 - Installation Steps
 - How to Add/Edit/Remove Blog Entries
 - Development & Support 
 - About the Developer
 - Contact Information
 

Introduction
============
Blog is an open source Online Diary/Journal solution written
by Jonathan Beckett. It is intended as a "starting point" for you
to build on top of for your own solution - although you must retain
the comments at the top of each page and the accompanying files
(such as this one) detailing things like the project homepage
for the benefit of others.

If you are new to the world of web development, Blog has a development
discussion board (the URL is provided below) for users of the script
to request help and to swap tips with each other.

It is important that the blog script is not seen as a "solution". You
may not be able to just "plug it in and go", so should not complain if
you find your web host causes complications.

If nothing else, please use Blog to help you learn about PHP and MySQL.

Regards

Jonathan Beckett


Internet Links for the Blog Project
===================================

BLOG Project Homepage
 - http://www.pluggedout.com/projects_blog.php

BLOG Project Discussion Forum
 - http://www.pluggedout.com/forums/viewforum.php?f=5


Requirements
============
 - PHP 4.x
 - MySQL


Installation Steps
==================
  1. Place the unzipped files somewhere into your web root.
     (make the lib and images folders if necessary and copy their contents over).
     
  2. Run the SQL in database.sql (supplied) through your database.
     (most web hosts include phpmysql as standard - paste the SQL into it).
     
  3. Change the config.php script to suit your settings.
     (make sure you set the username, password and database name to match
      the place you ran the SQL script).
  
  4. Update the contents of lib/html_user.php to suit yourself.
     (don't be scared that it looks like programming!)


How to Add/Edit/Remove Items
============================
Use the admin.php page - it will prompt for a login (using the
username and password from the config file), and from there it
should be self explanatory.


Development & Support
=====================
If you want to help with Blog or want some support, feel free to
visit the Blog discussion forums at the following URL...
http://www.pluggedout.com/forums/viewforum.php?f=5


About The Developer
===================
The Blog script was written by Jonathan Beckett. In the daytime
he is a professional software and website developer, working in both
the Windows and Linux worlds. He's usually got time to reply to emails,
but he would encourage you to visit the BLOG forum if you are stuck.


Contact Information
===================
 - Name     : Jonathan Beckett
 - Location : Marlow, Bucks, United Kingdom
 - E-Mail   : kafooey@yahoo.co.uk
 - URL      : http://www.pluggedout.com
 - Forums   : http://www.pluggedout.com/forums/
