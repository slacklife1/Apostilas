<?php
/*
#===========================================================================
#= Script : Blog
#= File   : index.php
#= Version: 1.51 beta
#= Author : Jonathan Beckett
#= Email  : jonbeckett@pluggedout.com
#= Website: http://www.pluggedout.com/projects_blog.php
#= Support: http://www.pluggedout.com/forums/viewforum.php?f=5
#===========================================================================
#= Copyright (c) 2003 Jonathan Beckett
#= You are free to use and modify this script as long as this header
#= section stays intact. This file is part of BLOG.
#=
#= This program is free software; you can redistribute it and/or modify
#= it under the terms of the GNU General Public License as published by
#= the Free Software Foundation; either version 2 of the License, or
#= (at your option) any later version.
#=
#= This program is distributed in the hope that it will be useful,
#= but WITHOUT ANY WARRANTY; without even the implied warranty of
#= MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#= GNU General Public License for more details.
#=
#= You should have received a copy of the GNU General Public License
#= along with BLOG files; if not, write to the Free Software
#= Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#===========================================================================
*/

require "./lib/session.php";
require "./lib/config.php";
require "./lib/database.php";
require "./lib/html.php";
require "./lib/html_user.php";
require "./lib/misc.php";

// get the data from the database
$result = db_prepare();

// start outputting the page

// head tag
print html_pageheader("Blog 1.5 beta : Online Journal/Diary Solution");

// body tag
print html_pagebody();

// banner
print html_pagestart();

// start whole page table to hold calendar, list and entries
print "<table width='100%' border='0' cellspacing='1' cellpadding='5'><tr><td valign='top' width='200'>\n";

	// show the calendar
	print html_calendar($month,$year);

	// white space
	print html_gap();

	// show the blog list
	print html_bloglist($list_rows,$blogid);

// seperate the main columns of the page table
print "  </td><td valign='top'>\n";

	// show the diary entry (or entries)
	print html_blogview($view_rows,$view_comment_rows);

// seperate the main columns of the page table
print "  </td><td valign='top' width='150'>\n";

	print html_myprofile();

	// white space
	print html_gap();
	
	print html_mylinks();
	
// end the page table
print "</td></tr></table>\n";

// put in any other stuff
print html_pageend();

// finish
print html_pagefooter();

?>