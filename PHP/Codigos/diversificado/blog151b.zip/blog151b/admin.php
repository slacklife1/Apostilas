<?php
/*
#===========================================================================
#= Script : Blog
#= File   : admin.php
#= Version: 1.51 beta
#= Author : Jonathan Beckett
#= Email  : jonbeckett@pluggedout.com
#= Website: http://www.pluggedout.com/projects_blog.php
#= Support: http://www.pluggedout.com/forums/viewforum.php?f=5
#===========================================================================
#= Copyright (c) 2003 Jonathan Beckett
#= You are free to use and modify this script as long as this header
#= section stays intact. This file is part of BLOG.
#=
#= This program is free software; you can redistribute it and/or modify
#= it under the terms of the GNU General Public License as published by
#= the Free Software Foundation; either version 2 of the License, or
#= (at your option) any later version.
#=
#= This program is distributed in the hope that it will be useful,
#= but WITHOUT ANY WARRANTY; without even the implied warranty of
#= MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#= GNU General Public License for more details.
#=
#= You should have received a copy of the GNU General Public License
#= along with BLOG files; if not, write to the Free Software
#= Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#===========================================================================
*/

require "./lib/session.php";
require "./lib/config.php";
require "./lib/database.php";
require "./lib/html.php";
require "./lib/misc.php";

// get the data from the database
$result = db_prepare();

// start outputting the page

// head tag
print html_pageheader("Blog 2");

// body tag
print html_pagebody();

// banner
print html_pagestart();

if ($_SESSION["userid"]=="") {

	// login attempted - no session data
	if ($_GET["action"]=="postlogin"){
		$html = "<br><table width='400' border='0' cellspacing='1' cellpadding='1' bgcolor='#cccccc' align='center'>\n"
			."  <tr><td bgcolor='#dddddd' align='center'><span class='small'><b>Login Failure</b></span></td></tr>\n"
			."  <tr><td bgcolor='#ffffff' align='center'>\n"
			."<p class='normal' align='center'>You have attempted to login and the login has failed. This could be for a number of reasons, such as an incorrect username and/or password, or a problem with session variables on your web server. If you cannot resolve the issue, please report it to the Pluggedout discussion board (<a href='http://www.pluggedout.com/forums'>www.pluggedout.com/forums</a>)</p>\n"
			."  </td></tr>\n"
			."</table>\n";
		print $html;
	}

	// show a login form
	$html = "<br><br>"
		."<form method='POST' action='".form_url("blog_exec.php?action=login")."'>\n"
		."<table align='center' border='0' cellspacing='1' cellpadding='2' bgcolor='#cccccc'>\n"
		."<tr><td colspan='2' bgcolor='#dddddd' align='center'><span class='small'>Login Form</span></td></tr>\n"
		."<tr><td bgcolor='#eeeeee'><span class='normal'>Username</span></td><td bgcolor='#eeeeee'><input type='text' class='text' name='username' size='20'></td></tr>\n"
		."<tr><td bgcolor='#eeeeee'><span class='normal'>Password</span></td><td bgcolor='#eeeeee'><input type='password' class='text' name='password' size='20'></td></tr>\n"
		."<tr><td colspan='2' bgcolor='#ffffff' align='right'><input type='submit' value='Login' class='button'></td></tr>\n"
		."</table>\n"
		."</form>\n";
	print $html;		


} else {

	if ($_GET["action"]=="" || $_GET["action"]=="postlogin") {

		// start whole page table to hold calendar, list and entries
		print "<table width='100%' border='0' cellspacing='1' cellpadding='5'><tr><td valign='top' width='200'>\n";
		// show the calendar
		print html_calendar($month,$year);
		// white space
		print html_gap();
		// add link
		print "<p class='large' align='center'><a href='".form_url("admin.php?action=add_blog")."'>Add Blog</a></p>";
		// white space
		print html_gap();
		// show the blog list
		print html_bloglist($list_rows,$blogid);
		// white space
		print html_gap();
		// show the logout control
		print html_logout($list_rows,$blogid);
		// seperate the main columns of the page table
		print "  </td><td valign='top'>\n";
		// show the diary entry (or entries)
		print html_blogview($view_rows,$view_comment_rows);
		// end the page table
		print "</td></tr></table>\n";

	}

	if ($_GET["action"]=="add_blog") {
		// show the add blog form
		$html = "<table border='0' cellspacing='1' cellpadding='1' bgcolor='#cccccc' align='center'>\n"
			."  <tr><td bgcolor='#dddddd' align='center'><span class='small'><b>Add Blog</b></span></td></tr>\n"
			."  <tr><td bgcolor='#ffffff' align='center'>\n"
			."<form method='POST' action='".form_url("blog_exec.php?action=add_blog")."'>\n"
			."<table border='0' cellspacing='1' cellpadding='1' align='center'>\n"
			."  <tr><td bgcolor='#eeeeee'><span class='normal'>Title</span></td><td bgcolor='#eeeeee'><input type='text' name='title' size='75'></td></tr>\n"
			."  <tr><td bgcolor='#eeeeee'><span class='normal'>Body</span></td><td bgcolor='#eeeeee'><textarea name='body' cols='75' rows='15'></textarea></td></tr>\n"
			."  <tr><td bgcolor='#eeeeee' colspan='2' align='right'><input type='submit' value='Add Blog Entry'></td></tr>\n"
			."</table>\n"
			."</form>\n"
			."  </td></tr>\n"
			."</table>\n";
		print $html;
	}

	if ($_GET["action"]=="edit_blog") {
		// get blog from database
		$con = db_connect();
		$sql = "SELECT * FROM blog WHERE nIdCode=".$_GET["blogid"];
		$result = mysql_query($sql,$con);
		if ($result!=false) {
			// show blog editing form
			$row = mysql_fetch_array($result);

			$html = "<table border='0' cellspacing='1' cellpadding='1' bgcolor='#cccccc' align='center'>\n"
				."  <tr><td bgcolor='#dddddd' align='center'><span class='small'><b>Edit Blog</b></span></td></tr>\n"
				."  <tr><td bgcolor='#ffffff' align='center'>\n"
				."<form method='POST' action='".form_url("blog_exec.php?action=edit_blog")."'>\n"
				."  <input type='hidden' name='blogid' value='".$row["nIdCode"]."'>\n"
				."  <table border='0' cellspacing='1' cellpadding='1' align='center'>\n"
				."  <tr><td bgcolor='#eeeeee'><span class='normal'>Title</span></td><td bgcolor='#eeeeee'><input type='text' name='title' size='75' value='".$row["cTitle"]."'></td></tr>\n"
				."  <tr><td bgcolor='#eeeeee'><span class='normal'>Body</span></td><td bgcolor='#eeeeee'><textarea name='body' cols='75' rows='15'>".$row["cBody"]."</textarea></td></tr>\n"
				."  <tr><td bgcolor='#eeeeee' colspan='2' align='right'><input type='submit' value='Make Changes'></td></tr>\n"
				."  </table>\n"
				."</form>\n"
				."</td></tr></table>\n";
			print $html;
		}
	}
}

// put in any other stuff
print html_pageend();

// finish
print html_pagefooter();

?>