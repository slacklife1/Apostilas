<?php
/*
#===========================================================================
#= Script : Blog
#= File   : comment_view.php
#= Version: 1.51 beta
#= Author : Jonathan Beckett
#= Email  : jonbeckett@pluggedout.com
#= Website: http://www.pluggedout.com/projects_blog.php
#= Support: http://www.pluggedout.com/forums/viewforum.php?f=5
#===========================================================================
#= Copyright (c) 2003 Jonathan Beckett
#= You are free to use and modify this script as long as this header
#= section stays intact. This file is part of BLOG.
#=
#= This program is free software; you can redistribute it and/or modify
#= it under the terms of the GNU General Public License as published by
#= the Free Software Foundation; either version 2 of the License, or
#= (at your option) any later version.
#=
#= This program is distributed in the hope that it will be useful,
#= but WITHOUT ANY WARRANTY; without even the implied warranty of
#= MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#= GNU General Public License for more details.
#=
#= You should have received a copy of the GNU General Public License
#= along with BLOG files; if not, write to the Free Software
#= Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#===========================================================================
*/

require "./lib/session.php";
require "./lib/config.php";
require "./lib/database.php";
require "./lib/html.php";
require "./lib/misc.php";

// get the data from the database
$result = db_prepare();

// head tag
print html_pageheader("Blog 2");

// body tag
print html_pagebody();

// banner
print html_pagestart();

$i = $_GET["i"];
if ($i!=""){
	print html_commentsview($i);
}

// put in any other stuff
print html_pageend();

// finish
print html_pagefooter();

?>