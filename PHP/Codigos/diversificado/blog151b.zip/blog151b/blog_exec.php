<?php
/*
#===========================================================================
#= Script : Blog
#= File   : blog_exec.php
#= Version: 1.51 beta
#= Author : Jonathan Beckett
#= Email  : jonbeckett@pluggedout.com
#= Website: http://www.pluggedout.com/projects_blog.php
#= Support: http://www.pluggedout.com/forums/viewforum.php?f=5
#===========================================================================
#= Copyright (c) 2003 Jonathan Beckett
#= You are free to use and modify this script as long as this header
#= section stays intact. This file is part of BLOG.
#=
#= This program is free software; you can redistribute it and/or modify
#= it under the terms of the GNU General Public License as published by
#= the Free Software Foundation; either version 2 of the License, or
#= (at your option) any later version.
#=
#= This program is distributed in the hope that it will be useful,
#= but WITHOUT ANY WARRANTY; without even the implied warranty of
#= MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#= GNU General Public License for more details.
#=
#= You should have received a copy of the GNU General Public License
#= along with BLOG files; if not, write to the Free Software
#= Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#===========================================================================
*/

include "./lib/session.php";
include "./lib/config.php";
include "./lib/database.php";


$con = db_connect();

// Handle the action of adding a blog
if ($_GET["action"]=="add_blog" && $_SESSION["userid"]!=""){
	$url = form_url("admin.php");
	$title = mysql_escape_string($_POST["title"]);
	$body = mysql_escape_string($_POST["body"]);
	$sql = "INSERT INTO blog (dEntryDate,cTitle,cBody) VALUES (Now(),".sql_quote($title).",".sql_quote($body).")";
	$result = mysql_query($sql,$con);
	$html_result = "The 'add blog' function has failed. It generated the folling SQL;\n[".$sql."]";
}

// Handle the action of editing a blog
if ($_GET["action"]=="edit_blog" && $_SESSION["userid"]!=""){
	$url = form_url("admin.php");
	$title = mysql_escape_string($_POST["title"]);
	$body = mysql_escape_string($_POST["body"]);
	$sql = "UPDATE blog SET cTitle=".sql_quote($title).",cBody=".sql_quote($body)." WHERE nIdCode=".$_POST["blogid"];
	$result = mysql_query($sql,$con);
	$html_result = "The 'edit blog' function has failed. It generated the folling SQL;\n[".$sql."]";
}

//Handle the action of removing a blog
if ($_GET["action"]=="remove_blog" && $_SESSION["userid"]!=""){
	$url = form_url($_SERVER["HTTP_REFERER"]);
	$sql = "DELETE FROM blog WHERE nIdCode=".$_GET["blogid"];
	$result = mysql_query($sql,$con);
	$html_result = "The 'remove blog' function has failed. It generated the folling SQL;\n[".$sql."]";
}

// Handle the action of logging into the admin interface
if ($_GET["action"]=="login"){
	if (ereg("\?",$_SERVER["HTTP_REFERER"])){
		$url = form_url($_SERVER["HTTP_REFERER"]."&action=postlogin");
	} else {
		$url = form_url($_SERVER["HTTP_REFERER"]."?action=postlogin");
	}
	if ($_POST["username"]==$login_username && $_POST["password"]==$login_password){
		$_SESSION["userid"]= $login_username;
		$result = true;
	} else {
		$result = true; // force return to index page
	}
}

// Handle the action of logging out of the admin interface
if ($_GET["action"]=="logout"){
	// log the user out
	$url = ereg_replace("action=","oldaction=",form_url($_SERVER["HTTP_REFERER"]));
	$_SESSION["userid"]="";
	$result = true;
}

// Handle the action of adding a comment to a blog
if ($_GET["action"]=="add_comment"){

	$url = form_url($_SERVER["HTTP_REFERER"]);

	// transfer and prepare data from add comment form
	$blogid = mysql_escape_string($_POST["blogid"]);
	$username = sql_quote(mysql_escape_string(strip_tags($_POST["username"])));
	$email = sql_quote(mysql_escape_string(strip_tags($_POST["email"])));
	$furl = sql_quote(mysql_escape_string(strip_tags($_POST["url"])));
	$comment = sql_quote(mysql_escape_string(strip_tags($_POST["comment"])));

	// check there is something in the username and comment
	$result=true;

	if ( preg_match("/[a-zA-Z0-9]/",$username) && preg_match("/[a-zA-Z0-9]/",$comment) ) {
		$result = true;
	} else {
		$result = false;
	}

	if ($result!=false) {
		// insert the comment
		$sql_insert = "INSERT INTO blog_comments (nBlogId,cUsername,cEMail,cURL,cComment) VALUES (".$blogid.",".$username.",".$email.",".$furl.",".$comment.");";
		$result = mysql_query($sql_insert,$con);
		if ($result!=false) {
			// update the comment count for the blog
			$sql_update = "UPDATE blog SET nComments=nComments+1 WHERE nIdCode=".$blogid;
			mysql_query($sql_update,$con);
			$result = true;
		} else {
			$result = false;
			$html_result = "The 'add comment' function has failed. The HTML generated was as follows<br>Insert SQL : [".$sql_insert."]<br>Update SQL : [".$sql_update."]";
		}
	}
}

// Handle problems with any of the above
if ($result==false){
	// record not added
	print "<h2>A Problem has occurred...</h2>";
	print "<p>A problem has occurred executing an action on the blog script. The message returned is as follows;\n</p>";
	print "<p><b>".$result_html."</b></p>\n";
	print "<ul>\n";
	print "<li>PHP_SELF = ".$_SERVER["PHP_SELF"];
	print "<li>QUERY_STRING = ".$_SERVER["QUERY_STRING"];
	print "<li>HTTP_REFERER = ".$_SERVER["HTTP_REFERER"];
	print "</ul>\n";
} else {
	// redirect to admin page
	header("Location: ".$url);

}

?>