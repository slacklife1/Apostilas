<?php
/*
#===========================================================================
#= Script : Blog
#= File   : html_user.php
#= Version: 1.51 beta
#= Author : Jonathan Beckett
#= Email  : jonbeckett@pluggedout.com
#= Website: http://www.pluggedout.com/projects_blog.php
#= Support: http://www.pluggedout.com/forums/viewforum.php?f=5
#===========================================================================
#= Copyright (c) 2003 Jonathan Beckett
#= You are free to use and modify this script as long as this header
#= section stays intact. This file is part of BLOG.
#=
#= This program is free software; you can redistribute it and/or modify
#= it under the terms of the GNU General Public License as published by
#= the Free Software Foundation; either version 2 of the License, or
#= (at your option) any later version.
#=
#= This program is distributed in the hope that it will be useful,
#= but WITHOUT ANY WARRANTY; without even the implied warranty of
#= MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#= GNU General Public License for more details.
#=
#= You should have received a copy of the GNU General Public License
#= along with BLOG files; if not, write to the Free Software
#= Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#===========================================================================
*/

// this file is intendid for general messing around with HTML
// to include in the blog (i.e. don't change html.php too much)


// Function    : html_myprofile
// Description : Returns the html to represent a table of information about the blog owner
// Arguments   : None
// Returns     : html data
// Author      : Jonathan Beckett
// Last Change : 2003-11-11
function html_myprofile(){
	
	// make an array of data
	// quick explanation : p=profile, f=field, d=data
	// * you can make as many entries as you want - just keep incrementing the number
	
	$title = "My Profile";
	
	$p[1]["f"] = "Username";
	$p[1]["d"] = "...";
	
	$p[2]["f"] = "DOB";
	$p[2]["d"] = "yyyy-mm-dd";
	
	$p[3]["f"] = "Job";
	$p[3]["d"] = "...";

	$p[4]["f"] = "Yahoo IM";
	$p[4]["d"] = "...";

	$p[5]["f"] = "ICQ";
	$p[5]["d"] = "...";
	
	$p[6]["f"] = "Interests";
	$p[6]["d"] = "...";
	
	$p[7]["f"] = "Movies";
	$p[7]["d"] = "...";
	
	$p[8]["f"] = "Music";
	$p[8]["d"] = "...";
	
	$p[9]["f"] = "Books";
	$p[9]["d"] = "...";
	
	
	// start the container table
	$html = "<table width='100%' border='0' bgcolor='#cccccc' cellspacing='1' cellpadding='1'>\n"
		."  <tr><td bgcolor='#dddddd' align='center'><span class='small'><b>".$title."</b></span></td></tr>\n"
		."  <tr><td bgcolor='#ffffff' align='center'><span class='small'>";
	
	// put some content in the table
	$html .= "<table width='100%' border='0' cellspacing='1' cellpadding='2'>\n";
	
	for ($i=1;$i<=count($p);$i++){
		$html.="<tr>"
			."  <td bgcolor='#dddddd'><span class='small'>".$p[$i]["f"]."</span></td>"
			."  <td bgcolor='#eeeeee'><span class='small'>".$p[$i]["d"]."</span></td>"
			."</tr>\n";
	}
	$html .= "</table>\n";
		
		
	// end the container table
	$html .= "</td></tr></table>\n";
	
	return $html;
}


// Function    : html_mylinks
// Description : Returns the html to represent a table of favourite links
// Arguments   : None
// Returns     : html data
// Author      : Jonathan Beckett
// Last Change : 2003-11-11
function html_mylinks(){

	// feel free to fill in as many as you want...
	$title = "Blogs I Like";

	// make an array of data
	// quick explanation : t=title, u=url
	// * you can make as many entries as you want - just keep incrementing the number

	$links[1]["t"] = "website name";
	$links[1]["u"] = "http://www.domain.com";
	
	$links[2]["t"] = "another website";
	$links[2]["u"] = "http://www.domain.com";
	

	// start the container table
	$html = "<table width='100%' border='0' bgcolor='#cccccc' cellspacing='1' cellpadding='1'>\n"
		."  <tr><td bgcolor='#dddddd' align='center'><span class='small'><b>".$title."</b></span></td></tr>\n"
		."  <tr><td bgcolor='#ffffff' align='center'><span class='small'>"
		."  <table width='100%' border='0' cellspacing='1' cellpadding='2'>\n";
		
	// loop through and output the links
	for ($i=1;$i<=count($links);$i++){
		$html .= "<tr><td bgcolor='#dddddd' align='center'><span class='small'><a href='".$links[$i]["u"]."' target='_blank'>".$links[$i]["t"]."</a></span></td></tr>\n";
	}
	
	// end the container table
	$html .= "</table></td></tr></table>\n";
	
	return $html;
}

?>