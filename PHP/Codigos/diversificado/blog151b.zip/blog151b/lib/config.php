<?php
/*
#===========================================================================
#= Script : Blog
#= File   : config.php
#= Version: 1.51 beta
#= Author : Jonathan Beckett
#= Email  : jonbeckett@pluggedout.com
#= Website: http://www.pluggedout.com/projects_blog.php
#= Support: http://www.pluggedout.com/forums/viewforum.php?f=5
#===========================================================================
#= Copyright (c) 2003 Jonathan Beckett
#= You are free to use and modify this script as long as this header
#= section stays intact. This file is part of BLOG.
#=
#= This program is free software; you can redistribute it and/or modify
#= it under the terms of the GNU General Public License as published by
#= the Free Software Foundation; either version 2 of the License, or
#= (at your option) any later version.
#=
#= This program is distributed in the hope that it will be useful,
#= but WITHOUT ANY WARRANTY; without even the implied warranty of
#= MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#= GNU General Public License for more details.
#=
#= You should have received a copy of the GNU General Public License
#= along with BLOG files; if not, write to the Free Software
#= Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#===========================================================================
*/

// Initialise Constants
// (you will need to fill these out to get the present content to work correctly)

// admin access constants
$login_username = "username";
$login_password = "password";

// database connection constants
$db_server = "your_db_server";       // usually 'localhost'
$db_name = "your_db_name";           // whatever your database name is
$db_username = "your_db_username";   // your MySQL Username
$db_password = "your_db_password";   // your MySQL Password

// banner title and subtext
$banner_title = "Blog 1.5 beta : Online Journal / Diary Solution";
$banner_subtext = "Blog is an online journal/diary solution available from <a href='http://www.pluggedout.com/projects_blog.php' class='link'>http://www.pluggedout.com/projects_blog.php</a>.";

// blog behaviour constants
// if viewmode is set to 'single' you will see the body text of one blog only
$viewmode = "";
// if viewcomments is set to'yes', when in single mode, the comments will appear
$viewcomments = "yes";


// *************** MACHINE SETTINGS ******************
// (don't touch any of this)

// prepare global variables for use later
$list_rows="";
$view_rows="";
$view_comment_rows="";
$day="";
$month="";
$year="";

?>