<?php
/*
#===========================================================================
#= Script : Blog
#= File   : html.php
#= Version: 1.51 beta
#= Author : Jonathan Beckett
#= Email  : jonbeckett@pluggedout.com
#= Website: http://www.pluggedout.com/projects_blog.php
#= Support: http://www.pluggedout.com/forums/viewforum.php?f=5
#===========================================================================
#= Copyright (c) 2003 Jonathan Beckett
#= You are free to use and modify this script as long as this header
#= section stays intact. This file is part of BLOG.
#=
#= This program is free software; you can redistribute it and/or modify
#= it under the terms of the GNU General Public License as published by
#= the Free Software Foundation; either version 2 of the License, or
#= (at your option) any later version.
#=
#= This program is distributed in the hope that it will be useful,
#= but WITHOUT ANY WARRANTY; without even the implied warranty of
#= MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#= GNU General Public License for more details.
#=
#= You should have received a copy of the GNU General Public License
#= along with BLOG files; if not, write to the Free Software
#= Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#===========================================================================
*/

// Function    : html_gap
// Description : Returns the html to represent a 5 pixel vertical gap on the page
// Arguments   : None
// Returns     : html data
// Author      : Jonathan Beckett
// Last Change : 2003-11-11
function html_gap(){
	$html = "<table border='0' cellspacing='0' cellpadding='0'><tr><td><img src='images/pix5.gif' width='5' height='5'></td></tr></table>\n";
	return $html;
}


// Function    : html_pageheader
// Description : Returns the html to represent an html page header (everything as far as body)
// Arguments   : $title - Page Title
// Returns     : html data
// Author      : Jonathan Beckett
// Last Change : 2003-11-11
function html_pageheader($title) {
	$html = "<html>\n"
		."<head>\n"
		."<title>".$title."</title>\n"
		."<link rel='stylesheet' href='style.css'>\n"
		."</head>\n";
	return $html;
}


// Function    : html_pagefooter
// Description : Returns the html to represent the end of the html page
// Arguments   : None
// Returns     : html data
// Author      : Jonathan Beckett
// Last Change : 2003-11-11
function html_pagefooter(){
	$html = "</body>\n"
		."</html>\n";
	return $html;
}


// Function    : html_pagebody
// Description : Returns the html to represent the body tag of the html pages
// Arguments   : None
// Returns     : html data
// Author      : Jonathan Beckett
// Last Change : 2003-11-11
function html_pagebody() {

	$html = "<body bgcolor='#ffffff' text='#000000' link='#0000ff' alink='0000ff' vlink='0000ff' style='margin-left:0;margin-right:0;margin-top:0;'>\n";
	return $html;
}


// Function    : html_pagestart
// Description : Returns the html to insert at the start of every page (typically for a banner)
// Arguments   : None
// Returns     : html data
// Author      : Jonathan Beckett
// Last Change : 2003-11-11
function html_pagestart(){

	global $banner_title;
	global $banner_subtext;

	$html = "<table width='100%' border='0' cellspacing='0' cellpadding='2'>\n"
		."  <tr><td bgcolor='#eeeeee'><span class='large'>&nbsp;".$banner_title."</span></td></tr>\n"
		."  <tr><td bgcolor='#dddddd'><span class='small'>&nbsp;&nbsp;".$banner_subtext."</span></td></tr>\n"
		."  <tr><td bgcolor='#ffffff' background='images/shadow.gif'><img src='images/pix1.gif' height='1' width='1'></td></tr>\n"
		."</table>\n";

	return $html;
}


// Function    : html_pageend
// Description : Returns the html to insert at the end of every page
//               (typically for terms or a disclaimer)
// Arguments   : None
// Returns     : html data
// Author      : Jonathan Beckett
// Last Change : 2003-11-11
function html_pageend(){
	$html = "";
	return $html;
}


// Function    : html_calendar
// Description : Returns the html to represent the calendar.
// Arguments   : $month - Month of the year (01 to 12)
//               $year  - Year (yyyy)
// Returns     : html data
// Author      : Jonathan Beckett
// Last Change : 2003-11-11
function html_calendar($month,$year) {

	global $months;
	global $days;

	global $month;
	global $year;
	global $day;

	define ('ADAY', (60*60*24));

	// make arrays of values representing the first of the month
	$datearray = getdate(mktime(0,0,0,$month,1,$year));
	$start = mktime(0,0,0,$month,1,$year);

	$firstdayarray = getdate($start);

	// pre-populate an array with the last blogs for the month being shown
	// (add them to the array on the index of the day of the month)
	$con = db_connect();
	$sql = "SELECT *,DAYOFMONTH(dEntryDate) AS day,MONTH(dEntryDate) AS month,YEAR(dEntryDate) AS year FROM blog WHERE MONTH(dEntryDate)=".sql_quote($month)." AND YEAR(dEntryDate)=".sql_quote($year)." ORDER BY nIdCode;";
	$result = mysql_query($sql,$con);
	if ($result!=false) {
		while ($row = @ mysql_fetch_array($result)){
			$aBlogs[$row["day"]]=$row;
		}
	} else {
		print "<li>Problem with SQL<br>[".$sql."]";
	}

	// work out the URLs for previous and next buttons
	// default
	$prev_month = $month - 1;
	$prev_year = $year;
	$next_month = $month + 1;
	$next_year = $year;

	// handle exceptions
	// end of year
	if ($month==12) {
		$prev_month = $month - 1;
		$prev_year = $year;
		$next_month = 1;
		$next_year = $year + 1;
	}
	// start of year
	if ($month==1) {
		$prev_month = 12;
		$prev_year = $year - 1;
		$next_month = $month + 1;
		$next_year = $year;
	}
	$url_next = $_SERVER["PHP_SELF"]."?month=".$next_month."&year=".$next_year;
	$url_prev = $_SERVER["PHP_SELF"]."?month=".$prev_month."&year=".$prev_year;


	// Create the start of the Calendar Table
	$html = "<table width='100%' border='0' cellpadding='1' cellspacing='1' bgcolor='#bbbbbb'>\n";

	// Create the row with the previous button, month name and next button
	$html .= "<tr><td colspan='7' bgcolor='#dddddd'>\n"
		."  <table width='100%' border='0' cellspacing='0' cellpadding='0'><tr>\n"
		."    <td align='center'><span class='normal'><a class='link' href='".form_url($url_prev)."'>&laquo;</a></span></td>\n"
		."    <td align='center'><span class='normal'><a class='link' href='".form_url($_SERVER["PHP_SELF"]."?year=".$year."&month=".$month)."'>".$datearray["month"]." ".$year."</a></span></td>\n"
		."    <td align='center'><span class='normal'><a class='link' href='".form_url($url_next)."'>&raquo;</a></span></td>\n"
		."  </tr></table>\n"
		."</td></tr>\n";

	// Create the row with Day Headings
	$html .= "<tr>\n";
	foreach($days as $day)
	{
		$html .= "  <td align='center' width='20' bgcolor='#dddddd'><span class='small'>".$day."</span></td>\n";
	}
	$html .= "</tr>\n";

	// Create the rows of days
	for( $count=0;$count<(6*7);$count++)
	{
		$dayarray = getdate($start);
		if((($count) % 7) == 0) {
			if($dayarray['mon'] != $datearray['mon']) break;
			$html .= "</tr>\n<tr>\n";
		}

		if($count < $firstdayarray['wday'] || $dayarray['mon'] != $month) {
			$html .= "<td bgcolor='#ffffff'><span class='small'>&nbsp;</span></td>\n";
		} else {
			// if there are entries for the day make it a link and change the color
			$d = $dayarray["mday"];
			if ($aBlogs[$d]["cBody"]!="") {
				$date_url = form_url($_SERVER["PHP_SELF"]."?year=".$dayarray["year"]."&month=".$dayarray["mon"]."&day=".$dayarray["mday"]);
				$html .= "<td align='center' bgcolor='#dddddd'><span class='small'><a class='link' href='".$date_url."'>".$dayarray[mday]."</a></span></td>\n";
			} else {
				$html .= "<td align='center' bgcolor='#eeeeee'><span class='small'>".$dayarray[mday]."</span></td>\n";
			}
			$start += ADAY;
			// check that day has moved on
			$testday = getdate($start);
			if ($testday["yday"]==$dayarray["yday"]){
				$start += (ADAY/2);
			}
		}
	}

	// end the calendar table
	$html .= "</tr>\n</table>\n";

	return $html;
}


// Function    : html_bloglist
// Description : Returns the html to represent a list of blog entries.
// Arguments   : $list_rows - array of associative arrays containing database rows from the db
//               $blogid    - the selected blogid (if used)
// Returns     : html data
// Author      : Jonathan Beckett
// Last Change : 2003-11-11
function html_bloglist($list_rows,$blogid){

	$html = "<table width='100%' border='0' bgcolor='#cccccc' cellspacing='1' cellpadding='1'>\n"
		."  <tr><td bgcolor='#dddddd' align='center'><span class='small'><b>Blogs</b></span></td></tr>\n";

	if ($list_rows[1]["nIdCode"]!=""){

	for ($i=1;$i<=count($list_rows);$i++){

		// put the admin html in if required
		if ($_SESSION["userid"]!=""){
			$html_admin = "&nbsp;[<a href='".form_url("admin.php?action=edit_blog&blogid=".$list_rows[$i]["nIdCode"])."'>edit</a>]&nbsp;[<a href='".form_url("admin.php?action=remove_blog&blogid=".$list_rows[$i]["nIdCode"])."'>Remove</a>]";
		} else {
			$html_admin = "";
		}

		$html .= "<tr><td bgcolor='#ffffff'>\n";
		if ($viewmode=="single") {
			if ($list_rows[$i]["nBlogId"]==$blogid) {
				$html .= "<table border='0' cellspacing='1' width='100%'><tr><td><table width='100%' cellspacing='0'><tr><td bgcolor='#dddddd'><span class='list_title'><b>".stripslashes($list_rows[$i]["cTitle"])."</b></span></td></tr><tr><td bgcolor='#eeeeee'><span class='list_date'>Written on ".$row["dEntryDate"]."<br>".$list_rows[$i]["nViews"]." views, ".$list_rows[$i]["nComments"]." comments".$html_admin."</span></td></tr></table></td></tr></table>";
			} else {
				$html .= "<table border='0' cellspacing='1' width='100%'><tr><td><table width='100%' cellspacing='0'><tr><td bgcolor='#dddddd'><span class='list_title'><a class='link' href='".form_url("index.php?blogid=".$list_rows[$i]["nIdCode"])."'>".stripslashes($list_rows[$i]["cTitle"])."</a></span></td></tr><tr><td bgcolor='#eeeeee'><span class='list_date'>Written on ".$list_rows[$i]["dEntryDate"]."<br>".$list_rows[$i]["nViews"]." views, ".$list_rows[$i]["nComments"]." comments".$html_admin."</span></td></tr></table></td></tr></table>";
			}
		} else {
			$html .= "<table border='0' cellspacing='1' width='100%'><tr><td><table width='100%' cellspacing='0'><tr><td bgcolor='#dddddd'><span class='list_title'><a class='link' href='#".$list_rows[$i]["nIdCode"]."'>".stripslashes($list_rows[$i]["cTitle"])."</a></span></td></tr><tr><td bgcolor='#eeeeee'><span class='list_date'>Written on ".$list_rows[$i]["dEntryDate"]."<br>".$list_rows[$i]["nViews"]." views, ".$list_rows[$i]["nComments"]." comments".$html_admin."</span></td></tr></table></td></tr></table>";
		}
		$html .= "</td></tr>\n";

	}

	} else {

		// no blogs to list
		$html .= "<tr><td bgcolor='#ffffff' align='center'><span class='small'>No Blogs to List</span></td></tr>\n";

	}

	$html .= "</table>\n";

	return $html;
}


// Function    : html_blogview
// Description : Returns the html to represent the blog bodies being shown
// Arguments   : $view_rows         - array of associative arrays containing blogs from the db
//               $view_comment_rows - array of array of associative arrays containing comments
//                                    on each of the blogs in the view_rows array
// Returns     : html data
// Author      : Jonathan Beckett
// Last Change : 2003-11-11
function html_blogview($view_rows,$view_comment_rows){

	// pull in globals
	global $viewmode;
	global $viewcomments;

	// start the table containing the blog view(s)
	$html = "<table width='100%' border='0' bgcolor='#bbbbbb' cellspacing='1' cellpadding='1'>\n";

	// loop for the number to show
	if ($viewmode=="single"){
		$view_max = 1;
	} else {
		$view_max = count($view_rows);
	}

	if ($view_rows[1]["nIdCode"]!=""){

		for ($i=1;$i<=$view_max;$i++) {

			// get date info out of the date field
			$view_year = substr($view_rows[$i]["dEntryDate"],0,4);
			$view_month = substr($view_rows[$i]["dEntryDate"],5,2);
			$view_day = substr($view_rows[$i]["dEntryDate"],8,2);
			$view_time = substr($view_rows[$i]["dEntryDate"],11,5);

			$view_datearray = getdate(mktime(0,0,0,$view_month,$view_day,$view_year));

			$view_monthname = $view_datearray["month"];

			// create the date and title table row
			$html .= "<tr>\n"
				."<td bgcolor='#dddddd' rowspan='2'><span class='large'>&nbsp;".$view_day."&nbsp;".$view_monthname.",&nbsp;".$view_time."&nbsp;</span></td>\n"
				."<td bgcolor='#dddddd' width='100%' align='center'><span class='normal'><b><a name='".$view_rows[$i]["nIdCode"]."'>".stripslashes($view_rows[$i]["cTitle"])."</a></b></span></td>\n"
				."</tr>\n";

			// create the date, and stats row
			if ($viewmode=="single"){
				$comments = ".";
			} else {
				$comments = ", <a href='#' class='link' onclick=\"window.open('".form_url("comment_view.php?blogid=".$view_rows[$i]["nIdCode"]."&i=".$i)."','Comments','resizable=yes,menubar=no,scrollbars=no,toolbar=no,fullscreen=no,width=500,height=500')\">".$view_rows[$i]["nComments"]." comments</a>";
			}
			$html .= "  <tr><td colspan='2' bgcolor='#eeeeee' align='center'><span class='small'>".$view_rows[$i]["nViews"]." views".$comments."</span></td></tr>\n";

			// create the bodytext table row
			$html .= "  <tr><td colspan='2' bgcolor='#ffffff'><table border='0' width='100%' cellpadding='5'><tr><td><p class='blog_title'>".stripslashes($view_rows[$i]["cTitle"])."</p><p class='blog_body'>".clean_text(stripslashes($view_rows[$i]["cBody"]))."</p></td></tr></table></td></tr>\n";

			// only show comments in single mode
			if ($viewmode=="single" && $viewcomments=="yes"){

				// start the cell containing comments
				$html .= "<tr><td colspan='2' bgcolor='#cccccc'>\n";

				$html .= html_commentsview($i,1);

				// end the cell containing comments or link to comments
				$html .= "</td></tr>\n";

			} else {
				// in multiple mode - therefore show link to view the comments in a seperate page...

			}

		}
	} else {
		// there are no blogs to show
		$html .= "  <tr><td colspan='2' bgcolor='#ffffff'><span class='normal'>There are no blogs for this month yet. Check other months via the navigation controls on the calendar.</span></td></tr>\n";
	}

	// end the table containing the blogs
	$html .="</table>\n";

	return $html;

}


// Function    : html_commentsview
// Description : Returns the html to represent the pop-up comments list used in multiple mode
// Arguments   : $i - index of a blog in the view array of arrays
// Returns     : html data
// Author      : Jonathan Beckett
// Last Change : 2003-11-11
function html_commentsview($i){

	global $view_rows;
	global $view_comment_rows;

	// start the comments table
	$html .= "<table width='100%' border='0' cellspacing='1' cellpadding='2'>\n";

	// loop through the comments array
	for ($j=1;$j<=$view_rows[$i]["nComments"];$j++) {

		if ($row["cURL"]!="") {
			$url = "[<a href='".$view_comment_rows[$i][$j]["cURL"]."' target='_blank'>Web</a>]";
		} else {
			$url = "";
		}
		if (is_email($row["cEmail"])) {
			$email = "[<a href='mailto:".$view_comment_rows[$i][$j]["cEMail"]."'>E-Mail</a>]";
		} else {
			$email = "";
		}
		// create comment header row
		$html .= "<tr><td bgcolor='#dddddd'><span class='small'>".stripslashes($view_comment_rows[$i][$j]["cUsername"])." wrote...".$email."&nbsp;".$url."</span></td></tr>\n";
		// create comment bodytext row
		$html .= "<tr><td bgcolor='#eeeeee'><span class='comment_body'>".stripslashes($view_comment_rows[$i][$j]["cComment"])."</span></td></tr>\n";
	}

	// end the comments table
	$html .= "</table>\n";

	// comment entry form
	$html .= "<table width='100%' border='0' cellpadding='5' cellspacing='0'><tr><td>\n"
		."<form method='POST' action='".form_url("blog_exec.php?action=add_comment")."'>\n"
		."  <input type='hidden' name='blogid' value='".$view_rows[$i]["nIdCode"]."'>\n"
		."  <table border='1' cellspacing='1' cellpadding='2' bgcolor='#dddddd' align='center'>\n"
		."    <tr><td colspan='2' bgcolor='#cccccc' align='center'><span class='small'><b>Add Comment Form</b></span></td></tr>\n"
		."    <tr><td bgcolor='#dddddd'><span class='small'>Name</span></td><td bgcolor='#eeeeee'><input type='text' name='username' size='70' class='text'></td></tr>\n"
		."    <tr><td bgcolor='#dddddd'><span class='small'>E-Mail</span></td><td bgcolor='#eeeeee'><input type='text' name='email' size='70' class='text'></td></tr>\n"
		."    <tr><td bgcolor='#dddddd'><span class='small'>URL</span></td><td bgcolor='#eeeeee'><input type='text' name='url' size='70' class='text'></td></tr>\n"
		."    <tr><td bgcolor='#dddddd'><span class='small'>Comment</span></td><td bgcolor='#eeeeee'><textarea name='comment' cols='70' rows='3' class='text'></textarea></td></tr>\n"
		."    <tr><td bgcolor='#dddddd' colspan='2' align='right'><input type='submit' value='Add Comment' class='button'></td></tr>\n"
		."  </table>\n"
		."</form>\n"
		."</td></tr></table>\n";

	return $html;
}


// Function    : html_logout
// Description : Returns the html to represent a logout button (used in the admin page)
// Arguments   : None
// Returns     : html data
// Author      : Jonathan Beckett
// Last Change : 2003-11-11
function html_logout(){

	$html = "<table width='100%' border='0' bgcolor='#cccccc' cellspacing='1' cellpadding='1'>\n"
		."  <tr><td bgcolor='#dddddd' align='center'><span class='small'><b>Logged in as ".$_SESSION["userid"]."</b></span></td></tr>\n"
		."  <tr><td bgcolor='#ffffff' align='center'><span class='small'><b><a href='".form_url("blog_exec.php?action=logout")."'>Logout</a></b></span></td></tr>\n"
		."</table>\n";

	return $html;
}

?>
