<html>
use this page to display your site news, to add your own colors etc to this page, just paste the head section of antoher page at the top of this page.
<!-- made by qads
qads1@uboot.com
www.qadsscripts.t2u.com -->
<table width="747" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="38" height="21"></td>
    <td width="25"></td>
    <td valign="top" colspan="3"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="669" valign="top" height="21"> 
            <div align="center"><b>News</b></div>
          </td>
        </tr>
      </table>
    </td>
    <td width="15"></td>
  </tr>
  <tr> 
    <td height="279"></td>
    <td valign="top" colspan="5"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="27" height="279"></td>
          <td width="667" valign="top" align="center"> 
            <?php
include("db.inc");
if(IsSet($id))
{}
else
{
$id="1";
}
$sql = "SELECT * FROM `settings`";
$results = mysql_query($sql) or die ("$error ERROR while selecting settings from the Db.</font>");
$get = mysql_fetch_array($results);

$news = "SELECT `title`,`date`,`body`,`by_` FROM `news` WHERE ID='$id' ORDER BY `date` DESC";
$geti = mysql_query($news);


while(list($title, $date, $body, $by_) = mysql_fetch_row($geti))
{
print("<table border='0' width='68%' height='191' bordercolor='$get[border]' style='border: 0 solid $get[border]'>
  <tr>
    <td width='100%' height='19' bgcolor='$get[header_bg]' style='border: 1 solid $get[border]'><font color='$get[header_text]'><b><font size='3'>$get[website_name]
      - $title</font></b></td>
  </tr>
  <tr>
    <td width='100%' height='106' valign='top' style='border-left: 1 solid $get[border]; border-right: 1 solid $get[border]; border-bottom: 1 solid $get[border]' bgcolor='$get[body_color]'><font color='$get[body_text]'>$body</font></td>
  </tr>
  <tr>
    <td width='100%' height='19' bgcolor='$get[footer]' style='border-left: 1 solid $get[border]; border-right: 1 solid $get[border]; border-bottom-style: solid; border-bottom-width: 1'>
      <p align='right'><font color='$get[footer_text]' size='2'><a href='http://www.qadsscripts.t2u.com' target='_blank'>QadsScripts</a> - - Submited By: $by_
      Date: $date</font></td>
  </tr>
  <tr>
    <td width='100%' height='23'></td>
  </tr>
</table>");
}
?>
          </td>
          <td width="15"></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="10"></td>
    <td></td>
    <td width="208"></td>
    <td width="321"></td>
    <td width="140"></td>
    <td></td>
  </tr>
  <tr> 
    <td height="71"></td>
    <td></td>
    <td></td>
    <td valign="top"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="1" height="22"></td>
          <td valign="top" width="316"> 
            <div align="center"><b>Select News</b></div>
          </td>
          <td width="2"></td>
          <td width="2"></td>
        </tr>
        <tr> 
          <td height="49"></td>
          <td colspan="2" valign="top"> 
            <table width="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="318" height="33" valign="top"> 
                  <?php include("db.inc");
	  
	  $sql = "SELECT `ID`,`title` FROM `news` WHERE 1 ORDER BY `ID` DESC";
	$result = mysql_query($sql);
	while(list($ID, $title) = mysql_fetch_row($result))
	{
	$news_box2 = "view.php?id=$ID";
	Print("<a href='$news_box2'>$title</a><br>");
	}
	?>
                </td>
              </tr>
              <tr> 
                <td height="16"></td>
              </tr>
            </table>
          </td>
          <td></td>
        </tr>
      </table>
    </td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="43"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
</table>
