<?php
//made by qads
//qads1@uboot.com
//www.qadsscripts.t2u.com
@mysql_connect('localhost','username','password') or die ("Can't connect with the database.");
@mysql_select_db('phpnews') or die ("Can't connect with the database table.");

//Encrypt password
$pass = MD5($password);

//end
//check DB for user
if($Submit)
{
$Query1 = "SELECT username FROM admin WHERE username = '$username' AND password = '$pass'";
$check = mysql_query($Query1) or die("Error in Query: $Query. mySQL said " . mysql_error() . '.');
$Results = mysql_num_rows($check) or die ("User <i>$user</i> was not found in the Datbase!");
if ($Results != '0')
{
$Login = "1";
session_register("Login");
session_start();
setcookie('admin', $username, time() +8400);
Print("<br><br><p><b>Welcome $username, Please <a href='main.php'>Click here</a>");
}
else
{
echo("Login Failed, please try again.");
}
}
?>
<title>PHPnews Admin Area</title>

