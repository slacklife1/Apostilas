# phpMyAdmin MySQL-Dump
# version 2.2.3
# http://phpwizard.net/phpMyAdmin/
# http://phpmyadmin.sourceforge.net/ (download page)
#
# Host: localhost
# Generation Time: Jun 14, 2002 at 05:56 PM
# Server version: 3.23.47
# PHP Version: 4.1.1
# Database : `phpnews`
# --------------------------------------------------------

#
# Table structure for table `admin`
#

CREATE TABLE admin (
  ID int(11) NOT NULL auto_increment,
  username text NOT NULL,
  password text NOT NULL,
  PRIMARY KEY  (ID)
) TYPE=MyISAM;

#
# Dumping data for table `admin`
#

INSERT INTO admin VALUES (1, 'admin', '1a1dc91c907325c69271ddf0c944bc72');
# --------------------------------------------------------

#
# Table structure for table `news`
#

CREATE TABLE news (
  ID int(11) NOT NULL auto_increment,
  title text NOT NULL,
  date text NOT NULL,
  body text NOT NULL,
  by_ text NOT NULL,
  PRIMARY KEY  (ID)
) TYPE=MyISAM;

#
# Dumping data for table `news`
#

INSERT INTO news VALUES (1, 'test news', '14/06/2002', 'Thank you for downloading this script.', 'Qads');
INSERT INTO news VALUES (2, 'test news 2', '14/06/2002', 'get free scripts @ <a href="http://www.qadsscripts.t2u.com" target="_blank">QadsScripts</a>', 'Qads');
INSERT INTO news VALUES (3, 'Title Goes here', 'the date goes here', 'the main news body is here', 'and this shows who posted this news');
INSERT INTO news VALUES (6, 'test4', '14/06/2002', 'don\'t you just love php? :P', 'admin');
# --------------------------------------------------------

#
# Table structure for table `settings`
#

CREATE TABLE settings (
  ID int(11) NOT NULL default '0',
  website_name text NOT NULL,
  body_color text NOT NULL,
  body_text text NOT NULL,
  header_bg text NOT NULL,
  header_text text NOT NULL,
  footer text NOT NULL,
  footer_text text NOT NULL,
  border text NOT NULL,
  table_BG text NOT NULL
) TYPE=MyISAM;

#
# Dumping data for table `settings`
#

INSERT INTO settings VALUES (1, 'Your Website Name', 'white', 'black', 'red', 'white', 'red', 'white', 'black', 'white');

