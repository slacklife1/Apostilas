<?php
//made by qads
//qads1@uboot.com
//www.qadsscripts.t2u.com
session_start();
if ($Login == '1')
{

$date = date("j/m/Y");
require_once("layout/top.txt");
print("<center><h3>Qads's Scripts - PHPNews</h3>");
include("db.inc");
$error = "<font size='2' color='#FF0000'>";
if($what == 'add')//add news
{
if(IsSet($nsave))
{
$sql = "INSERT INTO `news` (`ID`, `title`, `date`, `body`, `by_`) VALUES (Null, '$title', '$date', '$body', '$By1')";
$results = mysql_query($sql) or die ("$error there was a error while updateing the news table...</font>");
Print("'$title' has been saved into database.");
}
print("<center><form method='POST' action='$php_self'>

  <table border='0' width='70%'>
    <tr>
      <td width='22%' align='right'><b>News Title:</b></td>
      <td width='78%'><input type='text' name='title' size='20'></td>
    </tr>
    <tr>
      <td width='22%' align='right'><b>News Date:</b></td>
      <td width='78%'><input type='text' name='date' size='20' value='$date'></td>
    </tr>
    <tr>
      <td width='22%' align='right' valign='top'><b>News Body:</b></td>
      <td width='78%'><textarea rows='6' name='body' cols='31'></textarea></td>
    </tr>
    <tr>
      <td width='22%' align='right'><b>News By:</b></td>
      <td width='78%'><input type='text' name='By1' size='20' value='$admin'></td>
    </tr>
    <tr>
      <td width='22%' align='right'></td>
      <td width='78%'><input type='hidden' name='nsave'></td>
    </tr>
  </table>
  <p><input type='submit' value='  Save  ' name='B1'><input type='reset' value='Reset' name='B2'></p>
</form>
</center>");

}
if($what == 'view') // view news
{
?>
<table border='0' width='99%' height='26' cellspacing='1'>
  <tr>
    <td width='14%' align='center' height='20' bgcolor='#000000'><b><a href='?what=view&amp;&amp;sort=ID'>ID</a></b></td>
    <td width='28%' align='center' height='20' bgcolor='#000000'><b><a href='?what=view&amp;&amp;sort=title'>Title</a></b></td>
    <td width='18%' align='center' height='20' bgcolor='#000000'><b><a href='?what=view&amp;&amp;sort=body'>Date</a></b></td>
    <td width='20%' align='center' height='20' bgcolor='#000000'><b><a href='?what=view&amp;&amp;sort=by_'>By</a></b></td>
  </tr>
  <?php
if(IsSet($sort))
{}
else
{
$sort = "ID";
}
if(IsSet($del))
{
$sql1 = "DELETE FROM news WHERE ID ='$del'"; 
$results1 = mysql_query($sql1) or die ("$error could't delete $del</font>");
print("News '$del' has been deleted.");
}
$sql = "SELECT `ID`,`title`,`date`,`by_` FROM `news` WHERE 1 ORDER BY `$sort` ASC";
$results = mysql_query($sql);
while(list($ID,$title,$date,$by_) = mysql_fetch_row($results))
{
print("<tr>
    <td width='14%' align='center' height='20'><a href = '?what=view&&del=$ID'>Delete</a> - $ID</td>
    <td width='28%' align='center' height='20'>$title</td>
    <td width='18%' align='center' height='20'>$date</td>
    <td width='20%' align='center' height='20'>$by_</td>
  </tr>
");
}
?>
</table>
<?php
}
if($what == 'settings') // settings
{
$sql = "SELECT * FROM `settings` WHERE ID='1'";
$results = mysql_query($sql) or die ("$error ERROR while selecting settings from the Db.</font>");
$get = mysql_fetch_array($results);
print("<br><center>
perview<br>
<table border='0' width='68%' height='191' bordercolor='$get[border]' style='border: 0 solid $get[border]'>
  <tr>
    <td width='100%' height='19' bgcolor='$get[header_bg]' style='border: 1 solid $get[border]'><font color='$get[header_text]'><b><font size='3'>$get[website_name]
      - title</font></b></td>
  </tr>
  <tr>
    <td width='100%' height='106' valign='top' style='border-left: 1 solid $get[border]; border-right: 1 solid $get[border]; border-bottom: 1 solid $get[border]' bgcolor='$get[body_color]'><font color='$get[body_text]'>body text</font></td>
  </tr>
  <tr>
    <td width='100%' height='19' bgcolor='$get[footer]' style='border-left: 1 solid $get[border]; border-right: 1 solid $get[border]; border-bottom-style: solid; border-bottom-width: 1'>
      <p align='right'><font color='$get[footer_text]' size='2'><a href='http://www.qadsscripts.t2u.com' target='_blank'>QadsScripts</a> - - Submited By: Admin
      Date: $date</font></td>
  </tr>
  <tr>
    <td width='100%' height='23'></td>
  </tr>
</table>
<br>");
if(IsSet($Ssave))
{
$update  = "UPDATE settings SET website_name='$website', body_color='$body_color',body_text='$body_text_color',header_bg='$header_color', header_text='$header_text_color', footer='$footer_color', footer_text='$foot_text_color', border='$table_border_color', table_BG='$table_bg_color' Where ID='1'";
$t = mysql_query($update) or die ("$error could't update settings</font>");
print("Settings updated!");
}
print("
<form method='POST' action='$php_self'>
  <table border='0' width='68%'>
    <tr>
      <td width='47%' align='right'><b>WebSite Name:</b></td>
      <td width='53%'><input type='text' name='website' value='$get[website_name]' size='20'></td>
    </tr>
    <tr>
      <td width='47%' align='right'><b>News Body Color:</b></td>
      <td width='53%'><input type='text' name='body_color' value='$get[body_color]' size='20'></td>
    </tr>
    <tr>
      <td width='47%' align='right'><b>News Body Text Color:</b></td>
      <td width='53%'><input type='text' name='body_text_color' value='$get[body_text]' size='20'></td>
    </tr>
    <tr>
      <td width='47%' align='right'><b>News Header Color:</b></td>
      <td width='53%'><input type='text' name='header_color'value='$get[header_bg]' size='20'></td>
    </tr>
    <tr>
      <td width='47%' align='right'><b>News Header Text Color:</b></td>
      <td width='53%'><input type='text' name='header_text_color' value='$get[header_text]' size='20'></td>
    </tr>
    <tr>
      <td width='47%' align='right'><b>News Footer Color</b></td>
      <td width='53%'><input type='text' name='footer_color' value='$get[footer]' size='20'></td>
    </tr>
    <tr>
      <td width='47%' align='right'><b>News Footer Text Color:</b></td>
      <td width='53%'><input type='text' name='foot_text_color' value='$get[footer_text]' size='20'></td>
    </tr>
    <tr>
      <td width='47%' align='right'><b>News Table Border Color:</b></td>
      <td width='53%'><input type='text' name='table_border_color' value='$get[border]' size='20'></td>
    </tr>
    <tr>
      <td width='47%' align='right'><b>News Table BG Color:</b></td>
      <td width='53%'><input type='text' name='table_bg_color' value='$get[table_BG]' size='20'><input type='hidden' name='Ssave'></td>
    </tr>
  </table>
  <p align='center'><input type='submit' value='  Save  ' name='B1'><input type='reset' value='Reset' name='B2'></p>
</form>");
}
if($what == 'logout') //logout
{
session_destroy();
print("<h1>Good Bye</h1>");
}
if($what == 'account') // change password
{
if(IsSet($Saccount))
{
$pass = MD5($pass);
$sql = "UPDATE admin SET username='$user', password='$pass' Where username='$admin'";
$ch = mysql_query($sql) or die ("$error could't update account information</font>");
print("Account Information has been Updated, you will have to login agian...");
session_destroy();
}
print("<form method='POST' action='$php_self'>

  <table border='0' width='53%'>
    <tr>
      <td width='74%' align='right'><b>New Username:</b></td>
      <td width='58%'>
        <p align='left'><input type='text' name='user' size='20'></td>
    </tr>
    <tr>
      <td width='74%' align='right' valign='top'><b>New Password:</b></td>
      <td width='58%'><input type='password' name='pass' size='20'><input type='hidden' name='Saccount'>
        <p><input type='submit' value='Change' name='B1'></td>
    </tr>
  </table>
</form>");
}

if($what == 'newadmin')
{
if(IsSet($newad))
{
$pass = MD5($pass);
$sql = "INSERT INTO `admin` (`ID`, `username`, `password`) VALUES (Null, '$user', '$pass')";
$add = mysql_query($sql) or die ("$error Could add $user to admin table</font>");
print("$user has been added to admin table");
}
print("<form method='POST' action='$php_self'>

  <table border='0' width='53%'>
    <tr>
      <td width='74%' align='right'><b>Username:</b></td>
      <td width='58%'>
        <p align='left'><input type='text' name='user' size='20'></td>
    </tr>
    <tr>
      <td width='74%' align='right' valign='top'><b>Password:</b></td>
      <td width='58%'><input type='password' name='pass' size='20'><input type='hidden' name='newad'>
        <p><input type='submit' value='  Add  ' name='B1'></td>
    </tr>
  </table>
</form>");
}
require_once("layout/bottem.txt");
}
else
{
include("error.php");
}
?>