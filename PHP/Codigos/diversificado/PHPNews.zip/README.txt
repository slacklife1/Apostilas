thank you for downloading my script.
plase note that you can not remove any links to my site from this script.

how to install it?
use the .sql file to make the mysql database tables.
edit the settings in db.inc
go to www.yoursite/PHPNews/login.htm

username:admin
password:pass


if you have any problems, email me or visit my site at www.qadsscripts.t2u.com
thanks you
qads1@uboot.com
qadsscripts.t2u.com