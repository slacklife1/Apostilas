<html>
<head>
<title>PHP Info</title>
</head>
<body bgcolor="#3A6EA5">
<?php
phpinfo();
?>