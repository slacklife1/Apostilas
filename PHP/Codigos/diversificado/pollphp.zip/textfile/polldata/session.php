<?php
$auth['session']="4df46e427195440939c0787a70e91447";
$auth['uid']="1";
$auth['expire']="1019424198";
?>