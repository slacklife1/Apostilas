<?php
global $HTTP_SERVER_VARS, $HTTP_GET_VARS, $HTTP_POST_VARS, $HTTP_COOKIE_VARS;  
$PHP_SELF = $HTTP_SERVER_VARS["PHP_SELF"];
if (isset($HTTP_GET_VARS)) {
    while (list($name, $value)=each($HTTP_GET_VARS)) {
        $$name=$value;
    }
}
if (isset($HTTP_POST_VARS)) {
    while (list($name, $value)=each($HTTP_POST_VARS)) {
        $$name=$value;
    }
}
if (isset($HTTP_COOKIE_VARS)) {
    while (list($name, $value)=each($HTTP_COOKIE_VARS)) {
        $$name=$value;
    }
}
?>