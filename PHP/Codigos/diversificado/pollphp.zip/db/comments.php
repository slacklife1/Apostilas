<?php

$include_path = dirname(__FILE__);

if (!isset($PHP_SELF)) {
    global $HTTP_SERVER_VARS, $HTTP_GET_VARS, $HTTP_POST_VARS;  
    $PHP_SELF = $HTTP_SERVER_VARS["PHP_SELF"];
    if (isset($HTTP_GET_VARS)) {
        while (list($name, $value)=each($HTTP_GET_VARS)) {
            $$name=$value;
        }
    }
    if (isset($HTTP_POST_VARS)) {
        while (list($name, $value)=each($HTTP_POST_VARS)) {
            $$name=$value;
        }
    }
}

require $include_path."/include/config.inc.php";
require $include_path."/include/$POLLDB[class]";
require $include_path."/include/class_poll.php";
require $include_path."/include/class_pollcomment.php";
$CLASS["db"] = new polldb_sql;
$CLASS["db"]->connect();

$my_comment = new pollcomment();

if (isset($template_set)) {
    $my_comment->set_template_set("$template_set");
}
if (!isset($id)) {
    echo $my_comment->print_message("Poll ID <b>".$id."</b> does not exist or is disabled!");
}
if ($action == "add" && $my_comment->is_comment_allowed($id) && $poll_id==$pcomment) {
    if (empty($message)) {
        echo $my_comment->print_message("You forgot to fill in the message field!<br><a href=\"javascript:history.back()\">Go back</a>");
    }
    elseif (empty($name)) {
        echo $my_comment->print_message("Please enter your name.<br><a href=\"javascript:history.back()\">Go back</a>");
    }
/*
    elseif (empty($email)) {
        echo $my_comment->print_message("You must specify your e-mail address.!<br><a href=\"javascript:history.back()\">Go back</a>");
    }
*/
    else {
        $my_comment->add_comment($id);
        echo $my_comment->print_message("Your message has been sent!",1);
    }
} else {
    echo $my_comment->poll_form($id);
}

?>