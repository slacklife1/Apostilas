<?php
// sys_main.php

// **** all the constants have been moved to config.php

// Initialise the session
session_start();

// fixed constants
$months = Array("January","February","March","April","May","June","July","August","September","October","November","December");
$days = Array("Sun","Mon","Tue","Wed","Thu","Fri","Sat");

// *************************************************************************
// DATABASE FUNCTIONS
// 		show_error()
//      sql_quote()
//      db_connect()
//      db_disconnect()
// *************************************************************************

function zonechange ($current, $target) {
$current = -1 * $current;
$zonedate = mktime(date('G'), date('i'), date('s'), date('n'),date('j'), date('Y'), 1) + (($current + $target) * 3600);
return $zonedate;
}

// function      show_error()
// notes         Displays an error code during a database operation
// returns       nothing
// author        Jonathan Beckett
// last changed  2002-08-15
function show_error()
{
	die("Error " . mysql_errno() . " : " . mysql_error());
}


// function      sql_quote()
// notes         surrounds a string with single quotes
// returns       string
// author        Jonathan Beckett
// last changed  2002-08-15
function sql_quote($input)
{
	return "'".$input."'";
}

// function      db_connect()
// notes         connects to the database
// returns       connection object
// author        Jonathan Beckett
// last changed  2002-08-15
function db_connect()
{

	global $db_server;
	global $db_username;
	global $db_password;
	global $db_name;

	$con = mysql_connect($db_server,$db_username,$db_password);
	if (!(mysql_select_db($db_name,$con)))
	{
		show_error();
	}

	return $con;
}

// function      db_disconnect()
// notes         disconnects from the database
// returns       nothing
// author        Jonathan Beckett
// last changed  2002-08-16
function db_disconnect($con)
{
	close($con);
}


// *************************************************************************
// HTML FUNCTIONS
//		html_selectdateset()
// *************************************************************************


// function      html_selectdateset(set)
// notes         Used to pre-fill the dropdown options of a date select box
// returns       html of options for a date html select
// author        Jonathan Beckett
// last changed  2002-08-15
function html_selectdateset($set,$preset)
{
	$html = "<option value=\"-\">-</option>\n";
	switch ($set)
	{
		case "days":
			for ($day=1;$day<=31;$day++)
			{
				if ($day==$preset) {
					$selected="selected";
				} else {
					$selected="";
				}
				$html .= "<option value=\"".str_pad($day,2,"0",STR_PAD_LEFT)."\" $selected>$day</option>\n";
			}
			break;
		case "months":
			for ($month=1;$month<=12;$month++)
			{
				if ($month==$preset) {
					$selected="selected";
				} else {
					$selected="";
				}
				$html .= "<option value=\"".str_pad($month,2,"0",STR_PAD_LEFT)."\" $selected>$month</option>\n";
			}
	}
	return $html;
}


// *************************************************************************
// MISC FUNCTIONS
//		is_email(email)
//      is_alphanumeric(string)
// *************************************************************************

// function      is_email(email)
// notes         checks the format of an email
// returns       true or false
// author        Jonathan Beckett
// last changed  2002-08-15
function is_email($email) {
	$validEmailExpr = "^[0-9a-z]([-_.]?[0-9a-z])*@[0-9a-z]([-.]?[0-9a-z])*\\.[a-z]{2,3}$";
	if (eregi($validEmailExpr,$email) ) {
		return true;
	} else {
		return false;
	}
}

// function      is_alphanumeric(string)
// notes         checks the format of a string to make sure its only got alphanumeric chars in it
// returns       true or false
// author        Jonathan Beckett
// last changed  2002-08-15
function is_alphanumeric($input) {
	if ( preg_match("/[^a-zA-Z0-9]/",$userid) ) {
		return true;
	} else {
		return false;
	}
}

// function      get_date_part(string,string)
// notes         Returns part of a SQL date - accepts "day" "month" "year" as second argument
// returns       string
// author        Jonathan Beckett
// last changed  2002-08-15
function get_date_part($sqldate,$part) {
	// expects date in format yyyy-mm-dd hh:nn:ss
	switch ($part)
	{
		case "day":
			$result = substr($sqldate,8,2);
			break;
		case "month":
			$result = substr($sqldate,5,2);
			break;
		case "year":
			$result = substr($sqldate,0,4);
			break;
	}
	return $result;
}

?>