<?
include("rsscreator.class.php");

$rss = new UniversalRSSCreator(); 
$rss->title = $site_title; 
$rss->description = $site_desc; 
$rss->link = $site_root_url;
$rss->copyright = $site_copyright;
$rss->language = $site_lang;

$con = db_connect();
$sql = "SELECT * FROM blog ORDER BY nIdCode DESC;";
$result = mysql_query($sql,$con);
if ($result!=false) {
	while ($row = @ mysql_fetch_array($result)) {
		$html_title = stripslashes($row["cTitle"]);
		$html_body = stripslashes($row["cBody"]);
		$html_date = $row["dEntryDate"];

		$i = $row["nIdCode"];
		$article = $i;
		$item = new RSSItem();
		$item->title = $html_title;
		$item->link = $site_root_url."/index.php?view=".$i;
		$item->description = $html_body;
		$item->date = $html_date;

		$rss->addItem($item); 
	}
}
$fp=fopen("rss.xml","w");
fputs($fp,$rss->createRSS("0.91"));
fclose($fp);
?> 