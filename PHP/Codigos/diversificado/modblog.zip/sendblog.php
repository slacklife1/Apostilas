<?php
include "sys_main.php";
include "config.php";

function _dologin() {
	global $admin_password;
	if ($_REQUEST[ 'pass' ] == $admin_password) {
		return true;
	} else {
		return false;
	}
}

$mode = 'login';
$errmsg = '';


if ($_REQUEST[ 'mode' ]) {
	$mode = $_REQUEST[ 'mode' ];
}

if ($_REQUEST[ 'pass' ]) {
	if (_dologin()) {
		setcookie ("blog", $admin_password, time()+31536000, "/", "$sitedomain");
		$con = db_connect();
		$title = mysql_escape_string($_REQUEST["title"]);
		$body = mysql_escape_string($_REQUEST["content"]);
		$body = $body."<P><FONT SIZE=\"-1\">Posted via WAP-enabled Mobile Phone</FONT>";
		if ($pref_currenttimezone && $pref_targettimezone) {
			$timenow = date('Y-m-d H:i:s', zonechange("$pref_currenttimezone", "$pref_targettimezone"));
		}
		if ($timenow) {
			$sql = "INSERT INTO blog (dEntryDate,cTitle,cBody) VALUES ('$timenow',".sql_quote($title).",".sql_quote($body).");";
		} else {
			$sql = "INSERT INTO blog (dEntryDate,cTitle,cBody) VALUES (Now(),".sql_quote($title).",".sql_quote($body).");";
		}
		$result = mysql_query($sql,$con);
		if ($result==false) {
			$errmsg = 'Error: Unable to post blog entry.';
		} else {
			$errmsg = 'Blog entry posted.';
		}
		$mode = 'display';

	} else {
		$errmsg = 'Login failed.';
	}
}

if ($mode == 'clear') {
	setcookie ("blog", "", time()+31536000, "/", "$sitedomain");
	$mode = 'login';
	$errmsg = '';
	$blog = '';
} elseif ($mode == 'login') {
	$blog = $_COOKIE["blog"];
}

header('Content-type: text/vnd.wap.wml');
echo '<?xml version="1.0" encoding="iso-8859-1"?>' . "\n";
?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml"><wml><card title="Post My Blog" newcontext="true"><p>
<?php

if ($mode == 'display') {
	echo '<em>' . htmlspecialchars($errmsg) . '</em><br/><br/>';
?>
	<anchor>
		Another Entry
		<go href="<?php echo $_SERVER[ 'PHP_SELF' ]; ?>" method="post">
		</go>
	</anchor>
	<br/>
	<anchor>
		Logout
		<go href="<?php echo $_SERVER[ 'PHP_SELF' ]; ?>" method="post">
		<postfield name="mode" value="clear"/>
		</go>
	</anchor>
<?php
	include("rssupdate.php");
}

if ($mode == 'login') {

	if ($errmsg != '') {
		echo '<em>' . htmlspecialchars($errmsg) . '</em><br/>';
	}
	?>
	Password: <input type="password" name="pass" emptyok="false" title="Password" value="<?php echo $blog; ?>"/><br/>
	Title: <input type="text" name="title" emptyok="false" title="Title" value="<?php echo $title; ?>"/><br/>
	Content: <input type="text" name="content" emptyok="false" title="Content" value="<?php echo $content; ?>"/><br/>

	<anchor>
		Post Blog
		<go href="<?php echo $_SERVER[ 'PHP_SELF' ]; ?>" method="post">
		<postfield name="pass" value="$(pass)"/>
		<postfield name="title" value="$(title)"/>
		<postfield name="content" value="$(content)"/>
		</go>
	</anchor>
	<br/>
	<anchor>
		Logout
		<go href="<?php echo $_SERVER[ 'PHP_SELF' ]; ?>" method="post">
		<postfield name="mode" value="clear"/>
		</go>
	</anchor>
	<?php
}
?>
</p>
</card>
</wml>