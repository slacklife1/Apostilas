<?php

/*

blog script released as open source
by Jonathan Beckett
Version 1.12, 2003-07-07

Administration Page
===================
this page logs you in and sets a session variable
designating you as the administrator - which
then unlocks the add/edit/remove functions

*/

include "config.php";
include "sys_main.php";

// entries to list per page
$perpage = 20;

// default action
if ($_GET["action"]=="") {
	$action = "add";
} else {
	$action = $_GET["action"];
}

// if this is a login attempt, process it
if ($_POST["password"]!="") {

	// check password against admin password in config.php file
	if ($_POST["password"]==$admin_password) {
		session_register("s_loggedin");
		$s_loggedin = "y";
	} else {
		session_unset();
		session_unregister("s_loggedin");
	}

}



// display admin page based on s_loggedin variable

// page headers
print "<html>\n";
print "<head>\n";
print "<title>".$site_title."</title>\n";
print "<link rel='stylesheet' href='style.css'>\n";
print "</head>\n";
print "<body bgcolor='".$rgb_body_bg."' background='images/wallpaper.gif' text='".$rgb_body_text."' link='".$rgb_body_link."' alink='".$rgb_body_alink."' vlink='".$rgb_body_vlink."' style='margin-left:0;margin-right:0;margin-top:0;'>\n";

// top banner
print "<table width='100%' border='0' cellspacing='0' cellpadding='0' bgcolor='".$rgb_banner_bg."'>\n";
print "  <tr><td><img src='images/blog_banner.jpg' width='580' height='50'></td></tr>\n";
print "  <tr><td bgcolor='".$rgb_banner_line."'><img src='images/pix1.gif'></td></tr>\n";
print "  <tr><td bgcolor='".$rgb_banner_sub_bg."'><span class='normal'><b>&nbsp;<a href='admin.php?action=add' style='text-decoration:none;'>Add Blog Entry</a>&nbsp;�&nbsp;<a href='index.php?selfview=1' style='text-decoration:none;'>Blog Index</a>&nbsp;�&nbsp;<a href='admin_exec.php?action=logout' style='text-decoration:none;'>Logout</a></b></span></td></tr>\n";
print "  <tr><td bgcolor='".$rgb_banner_line."'><img src='images/pix1.gif'></td></tr>\n";
print "</table>\n";

if ($s_loggedin=="y") {

	// we are logged in - show content

	// open the database connection
	$con = db_connect();

	print "<table border='0' width='100%'><tr>\n";

	// left hand table cell (list of entries)
	print "<td width='200' valign='top'>\n";

	// prepare a list of pages of blogs
	$sql = "SELECT * FROM blog";
	$result = mysql_query($sql,$con);
	if ($result!=false) {
		$output = "<span class='small'>Blog Entries : ";
		for ( $i=0 ; $i <= mysql_num_rows($result) ; ($i+=$perpage) ) {
			if ( ($i-1)==$from || ($i==$from) ) {
				$output .= "[<b>".($i+1)." to ".($i + $perpage)."</b>]";
			} else {
				$output .= "[<a href='admin.php?from=".$i."'>".($i+1)." to ".($i + $perpage)."</a>]";
			}
		}
		$output .= "</span>";
	}

	if ($_GET["from"]!="") {
		$sql = "SELECT * FROM blog ORDER BY dEntryDate DESC LIMIT ".$from.",".$perpage;
	} else {
		$sql = "SELECT * FROM blog ORDER BY dEntryDate DESC LIMIT ".$perpage;
	}

	$result = mysql_query($sql,$con);
	if ($result!=false) {

		print "<table width='100%' border='0' cellspacing='1' cellpadding='1' bgcolor='#aabbcc' align='center'>\n";
		print "  <tr><td bgcolor='#ccddff' align='center'><span class='small'><b>Blog Entries</b></span></td></tr>\n";
		print "  <tr><td bgcolor='#ffffff' align='center'>\n";

		print $output;

		while ($row =@ mysql_fetch_array($result)) {
			print "<table width='100%' border='0' cellspacing='1' cellpadding='0'><tr><td><table border='0' cellspacing='0' cellpadding='1' width='100%'>"
				."<tr><td bgcolor='".$rgb_blog_banner_bg."'><span class='normal'><b>".stripslashes($row["cTitle"])."</b></span></td></tr>"
				."<tr><td bgcolor='".$rgb_blog_banner_sub_bg."'><span class='small'>".$row["dEntryDate"]."&nbsp;[<a href='admin.php?action=edit&blogid=".$row["nIdCode"]."'>edit</a>]&nbsp;[<a href='admin.php?action=remove&blogid=".$row["nIdCode"]."'>remove</a>]</span></td></tr>"
				."</table></td></tr></table>\n";

		}

		print "  </td></tr>\n";
		print "</table>\n";
		print "<table border='0' cellspacing='0' cellpadding='0'><tr><td><img src='images/pix5.gif' width='5' height='5'></td></tr></table>\n";

	}

	print "</td>\n";

	// middle table cell (add/edit/confirm functions)
	print "<td valign='top'>\n";


	print "<table width='100%' bgcolor='".$rgb_blog_bg."' cellspacing='1' cellpadding='1'>\n";
	print "<tr>\n";
	print "<td bgcolor='".$rgb_blog_banner_bg."' align='center'><span class='normal'><b>Version Control</b></span></td>\n";
	print "</tr>\n";
	print "<tr>\n";
	print "<td bgcolor='".$rgb_blog_body_bg."'><table border='0' width='100%' cellpadding='5'><tr><td><span class='normal'><center>Current Version: ";
	$old = @include "version.php";
	print "<BR>Newest Version: <a href='http://www.bloggingdoctor.com' style='text-decoration:none;' target='_blank'>";
	$new = @include "http://www.bloggingdoctor.com/version.php";
	if(!$new) {
		print "Unavailable";
	}
	print "</a></center></span></td></tr></table></td>\n";
	print "</tr>\n";
	print "</table>\n";

	// white space
	print "<table border='0' cellspacing='0' cellpadding='0'><tr><td><img src='images/pix5.gif' width='5' height='5'></td></tr></table>\n";

	switch ($action) {
		case "add":
			// show add blog entry form
			print "<table width='100%' border='0' cellspacing='1' cellpadding='1' bgcolor='#aabbcc' align='center'>\n";
			print "  <tr><td bgcolor='#ccddff' align='center'><span class='normal'><b>Add Blog</b></span></td></tr>\n";
			print "  <tr><td bgcolor='#ffffff' align='center'>\n";

			print "<p align='center' class='small'>&nbsp;</p>\n";

			print "<form method='POST' action='admin_exec.php?action=add'>\n";
			print "<input type='hidden' name='password' value=\"".$_POST["password"]."\">\n";
			print "<table border='0' cellspacing='1' cellpadding='1' align='center'>\n";
			print "  <tr><td colspan='2' bgcolor='".$rgb_blog_banner_bg."'><span class='normal'><b>Add Blog Form</b></span></td>\n";
			print "  <tr>\n";
			print "    <td bgcolor='".$rgb_blog_banner_bg."'><span class='normal'>Title</span></td><td bgcolor='".$rgb_blog_banner_sub_bg."'><input type='text' name='title' size='75'></td>\n";
			print "  </tr>\n";
			print "  <tr>\n";
			print "    <td bgcolor='".$rgb_blog_banner_bg."'><span class='normal'>Body</span></td><td bgcolor='".$rgb_blog_banner_sub_bg."'><textarea name='body' cols='75' rows='15'></textarea></td>\n";
			print "  </tr>\n";
			print "  <tr><td bgcolor='".$rgb_blog_banner_bg."' colspan='2' align='right'><input type='submit' value='Add Blog Entry'></td></tr>\n";
			print "</table>\n";
			print "</form>\n";

			print "<p align='center' class='small'>&nbsp;</p>\n";

			print "  </td></tr>\n";
			print "</table>\n";
			print "<table border='0' cellspacing='0' cellpadding='0'><tr><td><img src='images/pix5.gif' width='5' height='5'></td></tr></table>\n";


			break;

		case "edit":
			// get blog from database
			$sql = "SELECT * FROM blog WHERE nIdCode=".$_GET["blogid"];
			$result = mysql_query($sql,$con);
			if ($result!=false) {
				// show blog editing form
				$row = mysql_fetch_array($result);
				$html_title = stripslashes($row["cTitle"]);
				$html_body = stripslashes($row["cBody"]);
				print "<table width='100%' border='0' cellspacing='1' cellpadding='1' bgcolor='#aabbcc' align='center'>\n";
				print "  <tr><td bgcolor='#ccddff' align='center'><span class='normal'><b>Edit Blog</b></span></td></tr>\n";
				print "  <tr><td bgcolor='#ffffff' align='center'>\n";

				print "<p align='center' class='small'>&nbsp;</p>\n";

				print "<form method='POST' action='admin_exec.php?action=edit'>\n";
				print "<input type='hidden' name='blogid' value='".$row["nIdCode"]."'>\n";
				print "<table border='0' cellspacing='1' cellpadding='1' align='center'>\n";
				print "  <tr><td colspan='2' bgcolor='".$rgb_blog_banner_bg."'><span class='normal'><b>Edit Blog Form</b></span></td>\n";
				print "  </tr>\n";
				print "  <tr>\n";
				print "    <td bgcolor='".$rgb_blog_banner_bg."'><span class='normal'>Title</span></td><td bgcolor='".$rgb_blog_banner_sub_bg."'><input type='text' name='title' size='75' value=\"".$html_title."\"></td>\n";
				print "  </tr>\n";
				print "  <tr>\n";
				print "    <td bgcolor='".$rgb_blog_banner_bg."'><span class='normal'>Body</span></td><td bgcolor='".$rgb_blog_banner_sub_bg."'><textarea name='body' cols='75' rows='15'>".$html_body."</textarea></td>\n";
				print "  </tr>\n";
				print "  <tr><td bgcolor='".$rgb_blog_banner_bg."' colspan='2' align='right'><input type='submit' value='Make Changes'></td></tr>\n";
				print "</table>\n";
				print "</form>\n";

				print "<p align='center' class='small'>&nbsp;</p>\n";

				print "  </td></tr>\n";
				print "</table>\n";
				print "<table border='0' cellspacing='0' cellpadding='0'><tr><td><img src='images/pix5.gif' width='5' height='5'></td></tr></table>\n";


			}
			break;

		case "remove":
			// remove requires confirmation
			// ask for confirmation
			$sql = "SELECT * FROM blog WHERE nIdCode=".$_GET["blogid"];
			$result = mysql_query($sql,$con);
			if ($result!=false) {
			$row = mysql_fetch_array($result);
			$html_title = stripslashes($row["cTitle"]);
			$html_body = stripslashes(ereg_replace("\n","<br>",$row["cBody"]));
			$html_date = $row["dEntryDate"];

			print "<table width='100%' border='0' cellspacing='1' cellpadding='1' bgcolor='#aabbcc' align='center'>\n";
			print "  <tr><td bgcolor='#ccddff' align='center'><span class='normal'><b>Remove Blog</b></span></td></tr>\n";
			print "  <tr><td bgcolor='#ffffff' align='center'>\n";
			print "<p align='center' class='small'>&nbsp;</p>\n";
			print "<p align='center' class='normal'>Are you sure you want to remove the blog entry?</p>\n";
			print "<p align='center' class='normal'><a href='admin_exec.php?action=remove&blogid=".$_GET["blogid"]."&confirm=y'>Yes, Remove the Blog Entry</a></p>\n";
			print "<p align='center' class='small'>&nbsp;</p>\n";
			print "  </td></tr>\n";

			print "  <tr><td bgcolor='#ffffff' align='center'>\n";
				print "<table width='100%' border='0' cellspacing='1' cellpadding='1' align='center'>\n";
			print "  <tr>\n";
			print "    <td bgcolor='".$rgb_blog_banner_bg."' align='center'><span class='normal'><b>".$html_title."</b></span></td>\n";
			print "  </tr>\n";
			print "  <tr>\n";
			print "    <td bgcolor='".$rgb_blog_banner_sub_bg."' align='center'><span class='small'>Written on ".$html_date."\n";
			print "</span></td>\n";
			print "  </tr>\n";
			print "  <tr>\n";
			print "    <td bgcolor='".$rgb_blog_body_bg."'><table border='0' width='100%' cellpadding='5'><tr><td><p class='blog_body'>".$html_body."</p></td></tr></table></td>\n";
			print "  </tr>\n";
			print "</table>\n";
			print "  </td></tr>\n";
			print "</table>\n";
			print "<table border='0' cellspacing='0' cellpadding='0'><tr><td><img src='images/pix5.gif' width='5' height='5'></td></tr></table>\n";
}
			break;


		case "editc":
			// edit comments
			$sql = "SELECT * FROM blog_comments WHERE nIdCode=".$_GET["blogidc"];
			$result = mysql_query($sql,$con);
			if ($result!=false) {
				// show comment editing form
				$row = mysql_fetch_array($result);
				$html_name = stripslashes($row["cUsername"]);
				$html_email = stripslashes($row["cEMail"]);
				$html_url = stripslashes($row["cURL"]);
				$html_comment = stripslashes($row["cComment"]);
				print "<table width='100%' border='0' cellspacing='1' cellpadding='1' bgcolor='#aabbcc' align='center'>\n";
				print "  <tr><td bgcolor='#ccddff' align='center'><span class='normal'><b>Edit Blog Comment</b></span></td></tr>\n";
				print "  <tr><td bgcolor='#ffffff' align='center'>\n";
				print "<p align='center' class='small'>&nbsp;</p>\n";
				print "<form method='POST' action='admin_exec.php?action=editc'>\n";
				print "<input type='hidden' name='blogidc' value='".$row["nIdCode"]."'>\n";
				print "<table border='0' cellspacing='1' cellpadding='1' align='center'>\n";
				print "  <tr><td colspan='2' bgcolor='".$rgb_blog_banner_bg."'><span class='normal'><b>Edit Blog Comment</b></span></td>\n";
				print "  </tr>\n";
				print "  <tr>\n";
				print "    <td bgcolor='".$rgb_blog_banner_bg."'><span class='normal'>Name</span></td><td bgcolor='".$rgb_blog_banner_sub_bg."'><input type='text' name='name' size='75' value=\"".$html_name."\"></td>\n";
				print "  </tr>\n";
				print "  <tr>\n";
				print "    <td bgcolor='".$rgb_blog_banner_bg."'><span class='normal'>Email</span></td><td bgcolor='".$rgb_blog_banner_sub_bg."'><input type='text' name='email' size='75' value=\"".$html_email."\"></td>\n";
				print "  </tr>\n";
				print "  <tr>\n";
				print "    <td bgcolor='".$rgb_blog_banner_bg."'><span class='normal'>URL</span></td><td bgcolor='".$rgb_blog_banner_sub_bg."'><input type='text' name='url' size='75' value=\"".$html_url."\"></td>\n";
				print "  </tr>\n";
				print "  <tr>\n";
				print "    <td bgcolor='".$rgb_blog_banner_bg."'><span class='normal'>Comments</span></td><td bgcolor='".$rgb_blog_banner_sub_bg."'><textarea name='body' cols='75' rows='15'>".$html_comment."</textarea></td>\n";
				print "  </tr>\n";
				print "  <tr><td bgcolor='".$rgb_blog_banner_bg."' colspan='2' align='right'><input type='submit' value='Make Changes'></td></tr>\n";
				print "</table>\n";
				print "</form>\n";
				print "<p align='center' class='small'>&nbsp;</p>\n";
				print "  </td></tr>\n";
				print "</table>\n";
				print "<table border='0' cellspacing='0' cellpadding='0'><tr><td><img src='images/pix5.gif' width='5' height='5'></td></tr></table>\n";
			}
			break;

		case "removec":
			// ask for confirmation
			$sql = "SELECT * FROM blog_comments WHERE nIdCode=".$_GET["blogidc"];
			$result = mysql_query($sql,$con);
			if ($result!=false) {
				$row = mysql_fetch_array($result);
				$html_name = stripslashes($row["cUsername"]);
				$html_email = stripslashes($row["cEMail"]);
				$html_url = stripslashes($row["cURL"]);
				$html_comment = stripslashes($row["cComment"]);
				print "<table width='100%' border='0' cellspacing='1' cellpadding='1' bgcolor='#aabbcc' align='center'>\n";
				print "  <tr><td bgcolor='#ccddff' align='center'><span class='normal'><b>Remove Blog Comment</b></span></td></tr>\n";
				print "  <tr><td bgcolor='#ffffff' align='center'>\n";
				print "<p align='center' class='small'>&nbsp;</p>\n";
				print "<p align='center' class='normal'>Are you sure you want to remove the blog comment?</p>\n";
				print "<p align='center' class='normal'><a href='admin_exec.php?action=removec&blogidc=".$_GET["blogidc"]."&confirm=y'>Yes, Remove the Blog Comment</a></p>\n";
				print "<p align='center' class='small'>&nbsp;</p>\n";
				print "  </td></tr>\n";
				print "  <tr><td bgcolor='#ffffff' align='center'>\n";
				if ($row["cURL"]!="") {
					$url = "[<a href='".$row["cURL"]."'>Web</a>]";
				} else {
					$url = "";
				}
				if (is_email($row["cEMail"])) {
					$email = "[<a href='mailto:".$row["cEMail"]."'>E-Mail</a>]";
				} else {
					$email = "";
				}
				print "<tr><td bgcolor='".$rgb_comment_title_bg."'><span class='small'>".stripslashes($row["cUsername"])." wrote...".$email."&nbsp;".$url."</span></td></tr>\n";
				print "<tr><td bgcolor='".$rgb_comment_body_bg."'><span class='normal'>".stripslashes($row["cComment"])."</span></td></tr>\n";
				print "</table>\n";
				print "<table border='0' cellspacing='0' cellpadding='0'><tr><td><img src='images/pix5.gif' width='5' height='5'></td></tr></table>\n";
			}
			break;
	}

	print "</td>\n";

	// right hand table cell (list of comments)
	print "<td width='200' valign='top'>\n";

	// prepare a list of pages of comments
	$sql = "SELECT * FROM blog_comments";
	$result = mysql_query($sql,$con);
	if ($result!=false) {
		$output = "<span class='small'>Blog Comments : ";
		for ( $i=0 ; $i <= mysql_num_rows($result) ; ($i+=$perpage) ) {
			if ( ($i-1)==$fromcom || ($i==$fromcom) ) {
				$output .= "[<b>".($i+1)." to ".($i + $perpage)."</b>]";
			} else {
				$output .= "[<a href='admin.php?fromcom=".$i."'>".($i+1)." to ".($i + $perpage)."</a>]";
			}
		}
		$output .= "</span>";
	}

	if ($_GET["fromcom"]!="") {
		$sql = "SELECT * FROM blog_comments ORDER BY nIdCode DESC LIMIT ".$fromcom.",".$perpage;
	} else {
		$sql = "SELECT * FROM blog_comments ORDER BY nIdCode DESC LIMIT ".$perpage;
	}

	$result = mysql_query($sql,$con);
	if ($result!=false) {

		print "<table width='100%' border='0' cellspacing='1' cellpadding='1' bgcolor='#aabbcc' align='center'>\n";
		print "  <tr><td bgcolor='#ccddff' align='center'><span class='small'><b>Blog Comments</b></span></td></tr>\n";
		print "  <tr><td bgcolor='#ffffff' align='center'>\n";

		print $output;

		while ($row =@ mysql_fetch_array($result)) {

			print "<table width='100%' border='0' cellspacing='1' cellpadding='0'><tr><td><table border='0' cellspacing='0' cellpadding='1' width='100%'>"
				."<tr><td bgcolor='".$rgb_blog_banner_sub_bg."'><span class='small'>".stripslashes($row["cComment"])."&nbsp;[<a href='admin.php?action=editc&blogidc=".$row["nIdCode"]."'>edit</a>]&nbsp;[<a href='admin.php?action=removec&blogidc=".$row["nIdCode"]."'>remove</a>]</span></td></tr>"
				."</table></td></tr></table>\n";

		}

		print "  </td></tr>\n";
		print "</table>\n";
		print "<table border='0' cellspacing='0' cellpadding='0'><tr><td><img src='images/pix5.gif' width='5' height='5'></td></tr></table>\n";

	}

	print "</td>\n";
	print "</table>\n";

} else {

	// not logged in - show login form

if ($blogid) {
	print "<form method='POST' action='admin.php?action=".$action."&blogid=".$blogid."'>\n";
} else {
	print "<form method='POST' action='admin.php?action=".$action."'>\n";
}

	print "<table>\n";
	print "  <tr><td>Admin Password</td><td><input type='password' name='password'></td><td><input type='submit'></td></tr>\n";
	print "</table>\n";
	print "</form>\n";

}

// end admin page
print "</body>\n";
print "</html>\n";

?>