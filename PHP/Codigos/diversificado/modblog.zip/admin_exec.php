<?php
include "config.php";
include "sys_main.php";

$con = db_connect();

switch ($_GET["action"]) {

	case "add":
		$title = mysql_escape_string($_POST["title"]);
		$body = mysql_escape_string($_POST["body"]);
		if ($pref_currenttimezone && $pref_targettimezone) {
			$timenow = date('Y-m-d H:i:s', zonechange("$pref_currenttimezone", "$pref_targettimezone"));
		}

		if ($timenow) {
			$sql = "INSERT INTO blog (dEntryDate,cTitle,cBody) VALUES ('$timenow',".sql_quote($title).",".sql_quote($body).");";
		} else {
			$sql = "INSERT INTO blog (dEntryDate,cTitle,cBody) VALUES (Now(),".sql_quote($title).",".sql_quote($body).");";
		}
		$result = mysql_query($sql,$con);
		$url = "index.php?selfview=1";
		break;

	case "edit":
		$title = mysql_escape_string($_POST["title"]);
		$body = mysql_escape_string($_POST["body"]);
		$sql = "UPDATE blog SET cTitle=".sql_quote($title).",cBody=".sql_quote($body)." WHERE nIdCode=".$_POST["blogid"];
		$result = mysql_query($sql,$con);
		$url = "index.php?view=".$_POST["blogid"]."&selfview=1";
		break;

	case "remove":
		$sql = "DELETE FROM blog WHERE nIdCode=".$_GET["blogid"];
		$result = mysql_query($sql,$con);
		$url = "index.php?selfview=1";
		break;

	case "editc":
		$sql = "SELECT * FROM blog_comments WHERE nIdCode=".$_POST["blogidc"];
		$result = mysql_query($sql,$con);
		$row = mysql_fetch_array($result);
		$blogid = $row["nBlogId"];
		$name = mysql_escape_string($_POST["name"]);
		$email = mysql_escape_string($_POST["email"]);
		$url = mysql_escape_string($_POST["url"]);
		$body = mysql_escape_string($_POST["body"]);
		$sql = "UPDATE blog_comments SET cUsername=".sql_quote($name).",cEMail=".sql_quote($email).",cURL=".sql_quote($url).",cComment=".sql_quote($body)." WHERE nIdCode=".$_POST["blogidc"];
		$result = mysql_query($sql,$con);
		$url = "index.php?view=".$blogid."&selfview=1";
		break;

	case "removec":
		$sql = "SELECT * FROM blog_comments WHERE nIdCode=".$_GET["blogidc"];
		$result = mysql_query($sql,$con);
		$row = mysql_fetch_array($result);
		$blogid = $row["nBlogId"];
		$sql = "DELETE FROM blog_comments WHERE nIdCode=".$_GET["blogidc"];
		$result = mysql_query($sql,$con);
		if ($result!=false) {
			$sql = "UPDATE blog SET nComments=nComments-1 WHERE nIdCode=".$blogid;
			mysql_query($sql,$con);
		}
		$url = "index.php?view=".$blogid."&selfview=1";
		break;

	case "logout":
		$url = "index.php?selfview=1";
		$result = true;
}

if ($result==false){
	// record not added
	print "Problem Processing SQL [".$sql."]";

} else {
	session_unset();
	session_unregister("s_loggedin");
	header("Location: ".$url);
	include("rssupdate.php");
}

?>