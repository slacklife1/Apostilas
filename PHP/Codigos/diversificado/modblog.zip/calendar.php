<?php

function print_calendar($month,$year,$selfview) {

	global $months;
	global $days;
	global $rgb_calendar_bg;
	global $rgb_calendar_banner_bg;
	global $rgb_calendar_banner_sub_bg;
	global $rgb_calendar_body_bg;
	global $rgb_calendar_dayon_bg;
	global $rgb_calendar_dayoff_bg;

	define ('ADAY', (60*60*24));

	// work out month and year to show
	if ($month!="" && $year!="") {
		$month = $month;  // stating the obvious, but it makes it clear
		$year = $year;
		$datearray = getdate(mktime(0,0,0,$month,1,$year)); // initialise calendar for today
	} else {
		$datearray = getdate(); // initialise calendar for today
		$month = $datearray["mon"];
		$year = $datearray["year"];
	}

	$start= mktime(0,0,0,$month,1,$year);
	$firstdayarray = getdate($start);

	// pre-populate an array with the last blogs for the month being shown
	// (add them to the array on the index of the day of the month)
	$con = db_connect();
	$sql = "SELECT *,DAYOFMONTH(dEntryDate) AS day,MONTH(dEntryDate) AS month,YEAR(dEntryDate) AS year FROM blog WHERE MONTH(dEntryDate)=".sql_quote($month)." AND YEAR(dEntryDate)=".sql_quote($year)." ORDER BY nIdCode;";
	$result = mysql_query($sql,$con);
	if ($result!=false) {
		while ($row = @ mysql_fetch_array($result)){
			$aBlogs[$row["day"]]=$row;
		}
	} else {
		print "<li>Problem with SQL<br>[".$sql."]";
	}
	
	// work out the URLs for previous and next buttons
	// default
	$prev_month = $month - 1;
	$prev_year = $year;
	$next_month = $month + 1;
	$next_year = $year;
	// handle exceptions
	// end of year
	if ($month==12) {
		$prev_month = $month - 1;
		$prev_year = $year;
		$next_month = 1;
		$next_year = $year + 1;
	}
	// start of year
	if ($month==1) {
		$prev_month = 12;
		$prev_year = $year - 1;
		$next_month = $month + 1;
		$next_year = $year;
	}
	if ($selfview == "1") {
		$url_next = $_SERVER["SELF"]."index.php?month=".$next_month."&year=".$next_year."&selfview=1";
		$url_prev = $_SERVER["SELF"]."index.php?month=".$prev_month."&year=".$prev_year."&selfview=1";
	} else {
		$url_next = $_SERVER["SELF"]."index.php?month=".$next_month."&year=".$next_year;
		$url_prev = $_SERVER["SELF"]."index.php?month=".$prev_month."&year=".$prev_year;
	}
	print "<table width='100%' border='0' cellpadding='1' cellspacing='1' bgcolor='".$rgb_calendar_bg."'>\n";
	print "<tr><td colspan='7' bgcolor='".$rgb_calendar_banner_bg."'>\n";
	print "  <table width='100%' border='0' cellspacing='0' cellpadding='0'><tr>\n";
	print "    <td align='center'><span class='normal'><a href='".$url_prev."'>&laquo;</a></span></td>\n";

	if ($selfview == "1") {
		print "    <td align='center'><span class='normal'><a href='".$_SERVER["PHP_SELF"]."?year=".$year."&month=".$month."&selfview=1'>".$datearray[month]." ".$year."</a></span></td>\n";
	} else {
		print "    <td align='center'><span class='normal'><a href='".$_SERVER["PHP_SELF"]."?year=".$year."&month=".$month."'>".$datearray[month]." ".$year."</a></span></td>\n";
	}
	print "    <td align='center'><span class='normal'><a href='".$url_next."'>&raquo;</a></span></td>\n";
	print "  </tr></table>\n";
	print "</td></tr>\n";


	// draw day headings
	print "<tr>\n";
	foreach($days as $day)
	{
		print "  <td align='center' width='20' bgcolor='".$rgb_calendar_banner_sub_bg."'><span class='small'>".$day."</span></td>\n";
	}
	print "</tr>\n";

	// draw days
	for( $count=0;$count<(6*7);$count++)
	{
		$dayarray = getdate($start);
		if((($count) % 7) == 0) {
			if($dayarray['mon'] != $datearray['mon'])
				break;
			print "</tr>\n<tr>\n";
		}

		if($count < $firstdayarray['wday'] || $dayarray['mon'] != $month) {
			print "<td bgcolor='".$rgb_calendar_body_bg."'><span class='small'>&nbsp;</span></td>\n";
		} else {

			// if there are entries for the day make it a link and change the color
			$d = $dayarray["mday"];
			if ($aBlogs[$d]["cBody"]!="") {
				if ($selfview == "1") {
					$date_url = $_SERVER["PHP_SELF"]."?year=".$dayarray["year"]."&month=".$dayarray["mon"]."&day=".$dayarray["mday"]."&selfview=1";
				} else {
					$date_url = $_SERVER["PHP_SELF"]."?year=".$dayarray["year"]."&month=".$dayarray["mon"]."&day=".$dayarray["mday"];
				}
				print "<td align='center' bgcolor='".$rgb_calendar_dayon_bg."'><span class='small'><a href='".$date_url."'>".$dayarray[mday]."</a></span></td>\n";
			} else {
				print "<td align='center' bgcolor='".$rgb_calendar_dayoff_bg."'><span class='small'>".$dayarray[mday]."</span></td>\n";
			}
			$start += ADAY;
		}
	}
	// end the calendar table
	print "</tr>\n</table>\n";
}

?>