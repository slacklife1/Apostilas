<?php
include "config.php";
include "sys_main.php";

$con = db_connect();

// prepare data for database
$blogid = mysql_escape_string($_POST["blogid"]);
$username = sql_quote(mysql_escape_string(strip_tags($_POST["username"])));
$email = sql_quote(mysql_escape_string(strip_tags($_POST["email"])));
$url = sql_quote(mysql_escape_string(strip_tags($_POST["url"])));
// $comment = sql_quote(mysql_escape_string(strip_tags($_POST["comment"])));
$comment = mysql_escape_string(strip_tags($_POST["comment"]));

if (isSet($_SERVER)) {
if (isSet($_SERVER["HTTP_X_FORWARDED_FOR"])) {
$myip = $_SERVER["HTTP_X_FORWARDED_FOR"];
} elseif (isSet($_SERVER["HTTP_CLIENT_IP"])) {
$myip = $_SERVER["HTTP_CLIENT_IP"];
} else {
$myip = $_SERVER["REMOTE_ADDR"];
}

} else {
if ( getenv( 'HTTP_X_FORWARDED_FOR' ) ) {
$myip = getenv( 'HTTP_X_FORWARDED_FOR' );
} elseif ( getenv( 'HTTP_CLIENT_IP' ) ) {
$myip = getenv( 'HTTP_CLIENT_IP' );
} else {
$myip = getenv( 'REMOTE_ADDR' );
}
}

$bleh = strrpos($myip,', ')+2;
if ($bleh > 2) {
$myip = substr($myip, $bleh);
}
		
if ($pref_currenttimezone && $pref_targettimezone) {
	$timenow = date('Y-m-d H:i:s', zonechange("$pref_currenttimezone", "$pref_targettimezone"));
}

if ( preg_match("/[a-zA-Z0-9]/",$username) && preg_match("/[a-zA-Z0-9]/",$comment) ) {
	// fine
	$problem = false;
} else {
	$problem = true;
}


if ($timenow) {
	$comment = $comment."<P>IP: ".$myip."<BR>Date: ".$timenow;
} else {
	$comment = $comment."<P>IP: ".$myip."<BR>Date: ".Now();
}

$comment = sql_quote($comment);


if ($problem==false) {
	$sql = "INSERT INTO blog_comments (nBlogId,cUsername,cEMail,cURL,cComment) VALUES (".$blogid.",".$username.",".$email.",".$url.",".$comment.");";
	$result = mysql_query($sql,$con);
	if ($result!=false) {

		$sql = "UPDATE blog SET nComments=nComments+1 WHERE nIdCode=".$blogid;
		mysql_query($sql,$con);

		if (!$selfview) {
			$url = "index.php?view=".$blogid;
		} else {
			$url = "index.php?view=".$blogid."&selfview=1";
		}
		header("Location: ".$url);
	} else {
		print "<li>Problem Processing SQL<br>[".$sql."]";
	}
} else {
	$url = $_SERVER["HTTP_REFERER"];
	header("Location: ".$url);
}
?>