BLOG Mod - A Modded version of the Blog
=======================================

Available at www.bloggingdoctor.com


Requirements
============
 - PHP 4.x
 - MySQL


Installation Steps
==================
  1. put the PHP files in a folder somewhere visible to your webserver
  2. put the image folder inside the initial folder
  3. Run the SQL in database.sql (supplied) through your database.
  4. change the config.php script to suit your settings.
  5. chmod rss.xml to 666 in order to convert your blog into RSS.


How to Add/Edit/Remove Items
============================
Use the admin.php page - it will prompt for a login (using the
password from the config file), and from there it should be self
explanatory.


Notes
=====
You need to blank out the clix id and e-motion email address to
get them to blank out on the right side of the page. The settings
are in the config.php page.