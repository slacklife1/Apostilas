# MySQL SQL Script

CREATE TABLE blog (
  nIdCode bigint(20) NOT NULL auto_increment,
  dEntryDate datetime NOT NULL default '0000-00-00 00:00:00',
  cTitle varchar(100) NOT NULL default '',
  cBody mediumtext NOT NULL,
  nViews bigint(20) NOT NULL default '0',
  nComments bigint(20) NOT NULL default '0',
  UNIQUE KEY nIdCode (nIdCode),
  KEY dEntryDate (dEntryDate)
) TYPE=MyISAM COMMENT='Journal Table';


CREATE TABLE blog_comments (
  nIdCode bigint(20) NOT NULL auto_increment,
  nBlogId bigint(20) NOT NULL default '0',
  cUsername varchar(75) NOT NULL default '',
  cEMail varchar(75) NOT NULL default '',
  cURL varchar(150) NOT NULL default '',
  cComment mediumtext NOT NULL,
  UNIQUE KEY nIdCode (nIdCode)
) TYPE=MyISAM;