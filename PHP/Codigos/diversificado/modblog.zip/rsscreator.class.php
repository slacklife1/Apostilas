<?
/***************************************************************************

RSSCreator class v1.2
(c) Kai Blankenhorn
www.bitfolge.de
kaib@bitfolge.de

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

****************************************************************************


Changelog:

v1.2	07-20-03
	intelligent auto-truncating of RSS 0.91 attributes
	don't create some attributes when they're not set
	documentation improved
	fixed a real and a possible bug with date conversions
	code cleanup

v1.1	06-29-03
	added images to feeds
	now includes most RSS 0.91 attributes
	added RSS 2.0 feeds

v1.0	06-24-03
	initial release



***************************************************************************/



/**
 * An RSSItem is a part of an RSS feed.
 *
 * @version 1.1
 * @author Kai Blankenhorn <kaib@bitfolge.de>
 */
class RSSItem {
	/**
	 * Mandatory attributes of an item.
	 */
	var $title, $description, $link;
	
	/**
	 * Optional attributes of an item.
	 */
	var $author, $date, $image, $category, $comments, $guid;

	// on hold
	// var $source;
}



/**
 * An RSSImage may be added to an RSS feed.
 * @version 1.1
 * @author Kai Blankenhorn <kaib@bitfolge.de>
 */
class RSSImage {
	/**
	 * Mandatory attributes of an image.
	 */
	var $title, $url, $link;
	
	/**
	 * Optional attributes of an image.
	 */
	var $width, $height, $description;
}



/**
 * RSSCreator is the abstract base implementation for concrete
 * implementations that implement a specific version of RSS.
 *
 * @version 1.1
 * @abstract
 * @author Kai Blankenhorn <kaib@bitfolge.de>
 */
class RSSCreator {

	/**
	 * Mandatory attributes of a feed.
	 */
	var $title, $description, $link;
	
	
	/**
	 * Optional attributes of a feed.
	 */
	var $image = null;
	var $RSSURL, $image, $language, $copyright, $pubDate, $lastBuildDate, $editor, $webmaster, $category, $docs, $ttl, $rating, $skipHours, $skipDays;
	
	
	/**
	 * @access private
	 */
	var $items = Array();
	
	
	/**
	 * version information string, do not modify
	 * @access private
	 */
	var $generatorVersion = "RSSCreator 1.2";
	
	
	/**
	 * Adds an RSSItem to the feed.
	 *
	 * @param object RSSItem $item The RSSItem to add to the feed.
	 * @access public
	 */
	function addItem($item) {
		$this->items[] = $item;
	}
		
	
	/**
	 * Converts time strings from RFC 822 formatted date (Thu, 21 Dec 2000 16:01:07 +0200) to
	 * the format described in http://www.w3.org/TR/NOTE-datetime aka ISO 8601 (namely 
	 * 2000-12-21T16:01:07+02:00). The latter is used in Dublin Core date values.
	 * 
	 * @static
	 * @param string	$timeStr	A datetime string in RFC 822 format
	 * @return string	A datetime string in the 'Dublin Core' format
	 */
	function convertTime($timeStr) {
		$months = Array("Jan"=>1,"Feb"=>2,"Mar"=>3,"Apr"=>4,"May"=>5,"Jun"=>6,"Jul"=>7,"Aug"=>8,"Sep"=>9,"Oct"=>10,"Nov"=>11,"Dec"=>12);
		preg_match("~(?:(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun), )?(\\d{1,2}) ([a-zA-Z]{3}) (\\d{4}) (\\d{2}):(\\d{2}):(\\d{2}) (.*)~",$timeStr,$matches);
		$newTime = sprintf("%4d-%02d-%02dT%02d:%02d:%02d",$matches[3],$months[$matches[2]],$matches[1],$matches[4],$matches[5],$matches[6]);
		if ($matches[7]=="GMT") {
			// doesn't always work:
			// $tzd = "Z";
			$tzd = "+00:00";
		} else if ($matches[7][0]=='+' OR $matches[7][0]=='-') {
			$tzd = substr($matches[7],0,3).":".substr($matches[7],3,2);
		}
		return $newTime.$tzd;
	}


	/**
	 * Truncates a string to a certain length at the most sensible point.
	 * First, if there's a '.' character near the end of the string, the string is truncated after this character.
	 * If there is no '.', the string is truncated after the last ' ' character.
	 * If the string is truncated, " ..." is appended.
	 * If the string is already shorter than $length, it is returned unchanged.
	 * 
	 * @static
	 * @param string	string A string to be truncated.
	 * @param int		length the maximum length the string should be truncated to
	 * @return string	the truncated string
	 */
	function iTrunc($string, $length) {
		if (strlen($string)<=$length) {
			return $string;
		}
	
		$pos = strrpos($string,".");
		if ($pos>=$length-4) {
			$string = substr($string,0,$length-4);
			$pos = strrpos($string,".");
		}
		if ($pos>=$length*0.4) {
			return substr($string,0,$pos+1)." ...";
		}
	
		$pos = strrpos($string," ");
		if ($pos>=$length-4) {
			$string = substr($string,0,$length-4);
			$pos = strrpos($string," ");
		}
		if ($pos>=$length*0.4) {
			return substr($string,0,$pos)." ...";
		}
		
		return substr($string,0,$length-4)." ...";
		
	}
	
	
	/**
	 * Builds the RSS feed's text.
	 * @abstract
	 * @return	string	the feed's complete text 
	 */
	function createRSS() {
	}
}



/**
 * RSSCreator10 is an RSSCreator that implements RDF Site Summary (RSS) 1.0.
 *
 * @see http://www.purl.org/rss/1.0/
 * @version 1.1
 * @author Kai Blankenhorn <kaib@bitfolge.de>
 */
class RSSCreator10 extends RSSCreator {
	
	/**
	 * Builds the RSS feed's text. The feed will be compliant to RDF Site Summary (RSS) 1.0.
	 * The feed will contain all items previously added in the same order.
	 * @return	string	the feed's complete text 
	 */
	function createRSS() {
		$rss = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\r\n";
		$rss.= "<rdf:RDF\r\n"; 
		$rss.= "	xmlns=\"http://purl.org/rss/1.0/\"\r\n";
		$rss.= "	xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"\r\n"; 
		$rss.= "	xmlns:dc=\"http://purl.org/dc/elements/1.1/\">\r\n";
		$rss.= "	<channel rdf:about=\"".$this->RSSURL."\">\r\n";
		$rss.= "		<title>".htmlspecialchars($this->title)."</title>\r\n";
		$rss.= "		<description>".htmlspecialchars($this->description)."</description>\r\n";
		$rss.= "		<link>".$this->link."</link>\r\n";
		if ($this->image!=null) {
			$rss.= "		<image rdf:resource=\"".$this->image->url."\" />\r\n"; 
			$rss.= "		<image rdf:about=\"".$this->image->url."\">\r\n";
			$rss.= "			<title>".$this->image->title."</title>\r\n";
			$rss.= "			<link>".$this->image->link."</link>\r\n";
			$rss.= "			<url>".$this->image->url."</url>\r\n";
			$rss.= "		</image>\r\n";
		}
		$rss.= "		<dc:date>".RSSCreator::convertTime(date("r"))."</dc:date>\r\n";
		$rss.= "		<items>\r\n";
		$rss.= "			<rdf:Seq>\r\n";

		for ($i=0;$i<count($this->items);$i++) {
			$rss.= "				<rdf:li rdf:resource=\"".$this->items[$i]->link."\"/>\r\n";
		}
		$rss.= "			</rdf:Seq>\r\n";
		$rss.= "		</items>\r\n";
		$rss.= "	</channel>\r\n";

		for ($i=0;$i<count($this->items);$i++) {
			$rss.= "	<item rdf:about=\"".$this->items[$i]->link."\">\r\n";
			//$rss.= "		<dc:type>Posting</dc:type>\r\n";
			$rss.= "		<dc:format>text/html</dc:format>\r\n";
			if ($this->items[$i]->date!=null) {
				$rss.= "		<dc:date>".htmlspecialchars(RSSCreator::convertTime($this->items[$i]->date))."</dc:date>\r\n";
			}
			if ($this->items[$i]->source!="") {
				$rss.= "		<dc:source>".htmlspecialchars($this->items[$i]->source)."</dc:source>\r\n";
			}
			if ($this->items[$i]->creator!="") {
				$rss.= "		<dc:creator>".htmlspecialchars($this->items[$i]->author)."</dc:creator>\r\n";
			}
			$rss.= "		<title>".htmlspecialchars(strip_tags(strtr($this->items[$i]->title,"\n\r","  ")))."</title>\r\n";
			$rss.= "		<link>".htmlspecialchars($this->items[$i]->link)."</link>\r\n";
			$rss.= "		<description>".htmlspecialchars($this->items[$i]->description)."</description>\r\n";
			$rss.= "	</item>\r\n";
		}
		$rss.= "</rdf:RDF>\r\n";
		return $rss;
	}
}



/**
 * RSSCreator091 is an RSSCreator that implements RSS 0.91 Spec, revision 3.
 *
 * @see http://my.netscape.com/publish/formats/rss-spec-0.91.html
 * @version 1.1
 * @author Kai Blankenhorn <kaib@bitfolge.de>
 */
class RSSCreator091 extends RSSCreator {

	/**
	 * Stores this RSS feed's version number.
	 * @access private
	 */
	var $RSSVersion;

	function RSSCreator091() {
		$this->_setRSSVersion("0.91");
	}
	
	/**
	 * Sets this RSS feed's version number.
	 * @access private
	 */
	function _setRSSVersion($version) {
		$this->RSSVersion = $version;
	}

	/**
	 * Builds the RSS feed's text. The feed will be compliant to RDF Site Summary (RSS) 1.0.
	 * The feed will contain all items previously added in the same order.
	 * @return	string	the feed's complete text 
	 */
	function createRSS() {
		$rss = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\r\n";
		$rss.= "<rss version=\"".$this->RSSVersion."\">\r\n"; 
		$rss.= "	<channel>\r\n";
		$rss.= "		<title>".RSSCreator::iTrunc(htmlspecialchars($this->title),100)."</title>\r\n";
		$rss.= "		<description>".RSSCreator::iTrunc(htmlspecialchars($this->description),500)."</description>\r\n";
		$rss.= "		<link>".$this->link."</link>\r\n";
		$rss.= "		<lastBuildDate>".date("r")."</lastBuildDate>\r\n";
		$rss.= "		<generator>".$this->generatorVersion."</generator>\r\n";

		if ($this->image!=null) {
			$rss.= "		<image>\r\n";
			$rss.= "			<url>".$this->image->url."</url>\r\n"; 
			$rss.= "			<title>".RSSCreator::iTrunc(htmlspecialchars($this->image->title),100)."</title>\r\n"; 
			$rss.= "			<link>".$this->image->link."</link>\r\n";
			if ($this->image->width!="") {
				$rss.= "			<width>".$this->image->width."</width>\r\n";
			}
			if ($this->image->height!="") {
				$rss.= "			<height>".$this->image->height."</height>\r\n";
			}
			if ($this->image->description!="") {
				$rss.= "			<description>".htmlspecialchars($this->image->description)."</description>\r\n";
			}
			$rss.= "		</image>\r\n";
		}
 		if ($this->language!="") {
			$rss.= "		<language>".$this->language."</language>\r\n";
 		}
		if ($this->copyright!="") {
			$rss.= "		<copyright>".RSSCreator::iTrunc(htmlspecialchars($this->copyright),100)."</copyright>\r\n";
		}
		if ($this->editor!="") {
			$rss.= "		<managingEditor>".RSSCreator::iTrunc(htmlspecialchars($this->editor),100)."</managingEditor>\r\n";
		}
		if ($this->webmaster!="") {
			$rss.= "		<webmaster>".RSSCreator::iTrunc(htmlspecialchars($this->webmaster),100)."</webmaster>\r\n";
		}
		if ($this->pubDate!="") {
			$rss.= "		<pubDate>".$this->pubDate."</pubDate>\r\n";
		}
		if ($this->category!="") {
			$rss.= "		<category>".htmlspecialchars($this->category)."</category>\r\n";
		}
		if ($this->docs!="") {
			$rss.= "		<docs>".RSSCreator::iTrunc(htmlspecialchars($this->docs),500)."</docs>\r\n";
		}
		if ($this->ttl!="") {
			$rss.= "		<ttl>".htmlspecialchars($this->ttl)."</ttl>\r\n";
		}
		if ($this->rating!="") {
			$rss.= "		<rating>".RSSCreator::iTrunc(htmlspecialchars($this->rating),500)."</rating>\r\n";
		}
		if ($this->skipHours!="") {
			$rss.= "		<skipHours>".htmlspecialchars($this->skipHours)."</skipHours>\r\n";
		}
		if ($this->skipDays!="") {
			$rss.= "		<skipDays>".htmlspecialchars($this->skipDays)."</skipDays>\r\n";
		}

		for ($i=0;$i<count($this->items);$i++) {
			$rss.= "		<item>\r\n";
			$rss.= "			<title>".RSSCreator::iTrunc(htmlspecialchars(strip_tags($this->items[$i]->title)),100)."</title>\r\n";
			$rss.= "			<link>".htmlspecialchars($this->items[$i]->link)."</link>\r\n";
			$rss.= "			<description>".RSSCreator::iTrunc(htmlspecialchars($this->items[$i]->description),500)."</description>\r\n";
			if ($this->items[$i]->author!="") {
				$rss.= "			<author>".htmlspecialchars($this->items[$i]->author)."</author>\r\n";
			}
			/*
			// on hold
			if ($this->items[$i]->source!="") {
				$rss.= "			<source>".htmlspecialchars($this->items[$i]->source)."</source>\r\n";
			}
			*/
			if ($this->items[$i]->category!="") {
				$rss.= "			<category>".htmlspecialchars($this->items[$i]->category)."</category>\r\n";
			}
			if ($this->items[$i]->comments!="") {
				$rss.= "			<comments>".$this->items[$i]->comments."</comments>\r\n";
			}
			if ($this->items[$i]->date!="") {
				$rss.= "			<pubDate>".htmlspecialchars($this->items[$i]->date)."</pubDate>\r\n";
			}
			$rss.= "		</item>\r\n";
		}
		$rss.= "	</channel>\r\n";
		$rss.= "</rss>\r\n";
		return $rss;
	}
}



/**
 * RSSCreator20 is an RSSCreator that implements RDF Site Summary (RSS) 2.0.
 *
 * @see http://backend.userland.com/rss
 * @version 1.1
 * @author Kai Blankenhorn <kaib@bitfolge.de>
 */
class RSSCreator20 extends RSSCreator091 {

	function RSSCreator20() {
		parent::_setRSSVersion("2.0");
	}
	
}



/**
 * UniversalRSSCreator lets you choose during runtime which
 * RSS version to build.
 *
 * @version 1.1
 * @author Kai Blankenhorn <kaib@bitfolge.de>
 */
class UniversalRSSCreator extends RSSCreator {
	var $rss;
	
	/**
	 * Creates an RSS feed based on the items previously added.
	 *
	 * @see		RSSCreator::addItem()
	 * @param	string	version	RSS version the feed should comply to. Valid values are "0.91", "1.0" or "2.0".
	 * @return	string	the contents of the RSS feed.
	 */
	function createRSS($version = "0.91") {
		switch ($version) {
			case "2.0":
				$this->rss = new RSSCreator20();
				break;
			case "1.0":
				$this->rss = new RSSCreator10();
				break;
			case "0.91":
				$this->rss = new RSSCreator091();
				break;
		}
		
		
		$vars = get_object_vars($this);
		foreach ($vars as $key => $value) {
			if ($key!="rss") {
				eval("\$this->rss->$key = \$this->$key;\n");
			}
		}

		return $this->rss->createRSS();
	}
	
}

?>
