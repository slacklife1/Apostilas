<?php
/*
blog script released as open source
by Jonathan Beckett
Version 1.11, 2003-02-12
*/

/*
Modified by Ryan Thian
http://www.bloggingdoctor.com
Mod Version 0.1.9
*/

include "config.php";
include "sys_main.php";
include "calendar.php";

// find out nIdCode for blog being shown
$con = db_connect();
if ($_GET["view"]=="") { // no blog id specified
	$sql = "SELECT *, EXTRACT(MONTH FROM dEntryDate) AS month FROM blog ORDER BY nIdCode DESC LIMIT 1;";
} else { // blog id specified
	$sql = "SELECT *, EXTRACT(MONTH FROM dEntryDate) AS month FROM blog WHERE nIdCode=".$_GET["view"].";";
}
$result = mysql_query($sql,$con);
if ($result!=false) {
	$blog_row = mysql_fetch_array($result);
	$id = $blog_row["nIdCode"];
	$id_month = $blog_row["month"];
} else {
	print "<p>Problem with SQL<br>[".$sql."]</p>";
}

// increment view counter for blog being shown
if ((!$comment) && (!$selfview) && ($pref_viewscount == "1")) {
	$sql = "UPDATE blog SET nViews=nViews+1 WHERE nIdCode=".$id;
	$result = mysql_query($sql,$con);
}

// page headers
print "<html>\n";
print "<head>\n";
print "<title>".$site_title."</title>\n";
print "<META NAME='DESCRIPTION' CONTENT='".$site_desc."'><META NAME='KEYWORDS' CONTENT='".$site_keywords."'>\n";
print "<link rel='stylesheet' href='style.css'>\n";
print "</head>\n";
print "<body bgcolor='".$rgb_body_bg."' background='images/wallpaper.gif' text='".$rgb_body_text."' link='".$rgb_body_link."' alink='".$rgb_body_alink."' vlink='".$rgb_body_vlink."' style='margin-left:0;margin-right:0;margin-top:0;'>\n";

// top banner
print "<table width='100%' border='0' cellspacing='0' cellpadding='0' bgcolor='".$rgb_banner_bg."'>\n";

if ($selfview == "1") {
	print "<tr><td><a href='index.php?selfview=1'><img src='images/blog_banner.jpg' border='0' width='580' height='50'></a></td></tr>\n";
} else {
	print "<tr><td><a href='index.php'><img src='images/blog_banner.jpg' border='0' width='580' height='50'></a></td></tr>\n";
}

print "<tr><td bgcolor='".$rgb_banner_line."'><img src='images/pix1.gif'></td></tr>\n";

print "<tr><td bgcolor='".$rgb_banner_sub_bg."'><span class='small'>&nbsp;&nbsp;Blog Mod is a modified open source diary/journal/blog solution. Visit the <a href='http://www.bloggingdoctor.com' target=_blank>Blog Mod</a> for the updated version.</span></td></tr>\n";

print "<tr><td bgcolor='".$rgb_banner_line."'><img src='images/pix1.gif'></td></tr>\n";
print "</table>\n";

// insert the left side (which also retrieves the diary entry)

// create the SQL - if we have a month and year, restrict to it.
//                - if we have a day too, restrict to it
//                - if we have a 'view' (actual blog) show the month of the blog, and switch its anchor off
//                - if no month year or day, show the month of the last blog

if (!$search) {

	if ($_GET["month"]!="" || $_GET["year"]!="" || $_GET["day"]!="") {
		// month day year used
		if ($_GET["month"]!="" && $_GET["year"]!="") {
			// do we have a day too?
			if ($_GET["day"]!="") {
				// month day and year supplied
				$title = "Blogs for ".$_GET["year"]."-".$_GET["month"]."-".$_GET["day"];
				$sql = "SELECT * FROM blog WHERE MONTH(dEntryDate)=".$_GET["month"]." AND YEAR(dEntryDate)=".$_GET["year"]." AND DAYOFMONTH(dEntryDate)=".$_GET["day"]." ORDER BY nIdCode DESC;";
			} else {
				// month and year only supplied
				$title = "Blogs for ".$months[$_GET["month"]-1].", ".$_GET["year"];
				$refdate = mktime(0,0,0,$_GET["month"],1,$_GET["year"]);
				$aRefDate = getdate($refdate);
				$sql = "SELECT * FROM blog WHERE MONTH(dEntryDate)=".$_GET["month"]." AND YEAR(dEntryDate)=".$_GET["year"]." ORDER BY nIdCode DESC;";
			}
		} else {
			// incomplete date - use month of blog_row
			$refyear = substr($blog_row["dEntryDate"],0,4);
			$title = "Blogs for ".$months[$blog_row["month"]-1].", ".$refyear;
			$sql = "SELECT * FROM blog WHERE MONTH(dEntryDate)=".$blog_row["month"]." AND YEAR(dEntryDate)=".$refyear." ORDER BY nIdCode DESC;";
		}
	} else {
		// use month from the blog_row record (most recent or specific)
		$refyear = substr($blog_row["dEntryDate"],0,4);
		$title = "Blogs for ".$months[$blog_row["month"]-1].", ".$refyear;
		$sql = "SELECT * FROM blog WHERE MONTH(dEntryDate)=".$blog_row["month"]." AND YEAR(dEntryDate)=".$refyear." ORDER BY nIdCode DESC;";
	}
	$result = mysql_query($sql,$con);
} else {
	$sql="SELECT * FROM blog WHERE cTitle LIKE '%$search%' OR cBody LIKE '%$search%' ORDER BY nIdCode DESC";
	$result = mysql_query($sql);
}
$html_list = "";
$html_title = "";

if ($result!=false) {
	while ($row = @ mysql_fetch_array($result)) {

		if (!$search) {
			if ($selfview == "1") {
				$anchor_link = "<table border='0' cellspacing='1' width='100%'><tr><td><table width='100%' cellspacing='0'><tr><td bgcolor='".$rgb_bloglist_title_bg."'><span class='list_title'><a href='index.php?view=".$row["nIdCode"]."&selfview=1'>".stripslashes($row["cTitle"])."</a></span></td></tr><tr><td bgcolor='".$rgb_bloglist_detail_bg."'><span class='list_date'>Written on ".$row["dEntryDate"]."<br>";
			} else {
				$anchor_link = "<table border='0' cellspacing='1' width='100%'><tr><td><table width='100%' cellspacing='0'><tr><td bgcolor='".$rgb_bloglist_title_bg."'><span class='list_title'><a href='index.php?view=".$row["nIdCode"]."'>".stripslashes($row["cTitle"])."</a></span></td></tr><tr><td bgcolor='".$rgb_bloglist_detail_bg."'><span class='list_date'>Written on ".$row["dEntryDate"]."<br>";
			}
		} else {
			if ($selfview == "1") {
				$anchor_link = "<table border='0' cellspacing='1' width='100%'><tr><td><table width='100%' cellspacing='0'><tr><td bgcolor='".$rgb_bloglist_title_bg."'><span class='list_title'><a href='index.php?view=".$row["nIdCode"]."&selfview=1&search=".$search."'>".stripslashes($row["cTitle"])."</a></span></td></tr><tr><td bgcolor='".$rgb_bloglist_detail_bg."'><span class='list_date'>Written on ".$row["dEntryDate"]."<br>";
			} else {
				$anchor_link = "<table border='0' cellspacing='1' width='100%'><tr><td><table width='100%' cellspacing='0'><tr><td bgcolor='".$rgb_bloglist_title_bg."'><span class='list_title'><a href='index.php?view=".$row["nIdCode"]."&search=".$search."'>".stripslashes($row["cTitle"])."</a></span></td></tr><tr><td bgcolor='".$rgb_bloglist_detail_bg."'><span class='list_date'>Written on ".$row["dEntryDate"]."<br>";
			}

		}

		if ($pref_showviews == "1") {
			$anchor_link .= "".$row["nViews"]." views";
		}

		if ($pref_showcomments == "1") {
			$anchor_link .= ", ".$row["nComments"]." comments";
		}

		$anchor_link .= "</span></td></tr></table></td></tr></table>";
		$normal_link = "<table border='0' cellspacing='1' width='100%'><tr><td><table width='100%' cellspacing='0'><tr><td bgcolor='".$rgb_bloglist_title_bg."'><span class='list_title'><b>".stripslashes($row["cTitle"])."</b></span></td></tr><tr><td bgcolor='".$rgb_bloglist_detail_bg."'><span class='list_date'>Written on ".$row["dEntryDate"]."<br>";

		if ($pref_showviews == "1") {
			$normal_link .= "".$row["nViews"]." views";
		}

		if ($pref_showcomments == "1") {
			$normal_link .= ", ".$row["nComments"]." comments";
		}

		$normal_link .= "</span></td></tr></table></td></tr></table>";

		if ($_GET["view"]!="") {
			// a record has been specified
			if ($_GET["view"]==$row["nIdCode"]){
				$html_list .= $normal_link;
				$html_title = stripslashes($row["cTitle"]);
				$html_body = stripslashes(ereg_replace("\n","<br>",$row["cBody"]));
				$html_date = $row["dEntryDate"];
				if ($pref_showviews == "1") {
					$html_views = $row["nViews"];
				}
				$id = $row["nIdCode"];
			} else {
				$html_list .= $anchor_link;
			}
		} else {
			// no record specified
			// if this is the first record, use it
			if ($html_title==""){
				if ($_SERVER["PHP_SELF"]=="/blog/index.php") {
					$html_list .= $normal_link;
				} else {
					$html_list .= $anchor_link;
				}
				$html_title = stripslashes($row["cTitle"]);
				$html_body = stripslashes(ereg_replace("\n","<br>",$row["cBody"]));
				$html_date = $row["dEntryDate"];
				if ($pref_showviews == "1") {
					$html_views = $row["nViews"];
				}
				$id = $row["nIdCode"];
			} else {
				$html_list .= $anchor_link;
			}
		}
	}
}

if ($html_list=="") {
	$html_list="<p class='normal' align='center'>No Entries Yet</p>\n";
}


// output the Blog Entry List
print "<table width='100%' border='0' cellspacing='1' cellpadding='3'>\n";

print "<tr><td valign='top' width='200'>\n";

// show the calendar
if ($_GET["month"]!="" && $_GET["year"]!="") {
	$month = $_GET["month"];
	$year = $_GET["year"];
} else {
	if ($_GET["view"]!="") {
		// use the month and year of the active record
		$month = substr($html_date,5,2);
		$year = substr($html_date,0,4);
		$datearray = getdate(mktime(0,0,0,$month,1,$year));
	} else {
		// use today
		$datearray = getdate();
		$month = $datearray["mon"];
		$year = $datearray["year"];
	}
}
print_calendar($month,$year,$selfview);

// white space
print "<table border='0' cellspacing='0' cellpadding='0'><tr><td><img src='images/pix5.gif' width='5' height='5'></td></tr></table>\n";

print "<table width='100%' bgcolor='".$rgb_bloglist_bg."' cellspacing='1' cellpadding='1'>\n";

// output the blog list
print "<table width='100%' bgcolor='".$rgb_bloglist_bg."' cellspacing='1' cellpadding='1'>\n";

if (!$search) {
	print "<tr><td bgcolor='".$rgb_bloglist_banner_bg."' align='center'><span class='small'><b>".$title."</b></span></td></tr><tr><td bgcolor='#ffffff'>".$html_list."</td></tr>\n";
} else {
	$resultsnumber = mysql_numrows($result);
	print "<tr><td bgcolor='".$rgb_bloglist_banner_bg."' align='center'><span class='small'>Search for <b>'".$search."'</b>. <i>".$resultsnumber." results</i></span></td></tr><tr><td bgcolor='#ffffff'>".$html_list."</td></tr>\n";
}
print "</table>\n";
print "</td><td valign='top' align='center'>\n";

?>
<!------ Start of HTML Code ------->
<table width="250" border="1" cellpadding="4" 
cellspacing="0" bordercolor="#840300" bgcolor="#D70500"><form 
action="http://www.hotscripts.com/cgi-bin/rate.cgi" method="POST" target=blank>
<tr>
<td>
<table width="100%" border="0" cellspacing="0" 
cellpadding="0">
<tr>
<td><strong><font color="#FFFFFF">If you like my 
script, please rate it!</font></strong><input type="hidden" 
name="ID" value="23881">
<input type="hidden" name="external" value="1"></td>
</tr>
<tr>
<td><select name="rate" size="1">
<option value="5" selected>Excellent!</option>
<option value="4">Very Good</option>
<option value="3">Good</option>
<option value="2">Fair</option>
<option value="1">Poor</option>
</select>
<input name="submit" type="submit" value="Cast My Vote!"> </td>
</tr>
</table></td>
</tr></form>
</table>
<!------ End of HTML Code ------->
<?

// Admin Panel
if ($selfview == "1") { 
	// white space
	print "<table border='0' cellspacing='0' cellpadding='0'><tr><td><img src='images/pix5.gif' width='5' height='5'></td></tr></table>\n";
	print "<table width='100%' bgcolor='".$rgb_blog_bg."' cellspacing='1' cellpadding='1'>\n";
	print "<tr>\n";
	print "<td bgcolor='".$rgb_blog_banner_bg."' align='center'><span class='normal'><b>Admin Panel</b></span></td>\n";
	print "</tr>\n";
	print "<tr>\n";
	print "<td bgcolor='".$rgb_blog_body_bg."'><table border='0' width='100%' cellpadding='5'><tr><td><span class='small'><center>&nbsp;<a href='admin.php?action=add' style='text-decoration:none;'>Add Blog Entry</a>&nbsp;::&nbsp;<a href='admin.php?action=edit&blogid=".$id."' style='text-decoration:none;'>Edit Current Entry</a>&nbsp;::&nbsp;<a href='admin.php?action=remove&blogid=".$id."' style='text-decoration:none;'>Remove Current Entry</a></center></span></td></tr></table></td>\n";
	print "</tr>\n";
	print "</table>\n";
}

// white space
print "<table border='0' cellspacing='0' cellpadding='0'><tr><td><img src='images/pix5.gif' width='5' height='5'></td></tr></table>\n";

// show the appropriate diary entry
if ($html_title!="") {
	print "<table width='100%' bgcolor='".$rgb_blog_bg."' cellspacing='1' cellpadding='1'>\n";
	print "<tr>\n";
	print "<td bgcolor='".$rgb_blog_banner_bg."' align='center'><span class='normal'><b>".$html_title."</b></span></td>\n";
	print "</tr>\n";
	print "<tr>\n";
	print "<td bgcolor='".$rgb_blog_banner_sub_bg."' align='center'><span class='small'>Written on ".$html_date."\n";
	print "</span></td>\n";
	print "</tr>\n";
	print "<tr>\n";
	print "<td bgcolor='".$rgb_blog_body_bg."'><table border='0' width='100%' cellpadding='5'><tr><td><p class='blog_body'>".$html_body."</p></td></tr></table></td>\n";
	print "</tr>\n";
	print "</table>\n";

	// white space
	print "<table border='0' cellspacing='0' cellpadding='0'><tr><td><img src='images/pix5.gif' width='5' height='5'></td></tr></table>\n";

	if ($pref_showcomments == "1") {
		// show comments
		print "<table width='100%' bgcolor='".$rgb_blog_bg."' cellspacing='1' cellpadding='1'>\n";
		print "<tr>\n";
		print "<td bgcolor='".$rgb_comments_bg."'>\n";

		if (id!="") {
			// show the comments
			print "<table width='100%' border='0' cellspacing='1' cellpadding='2'>\n";
			$sql = "SELECT * FROM blog_comments WHERE nBlogId=".$id." ORDER BY nIdCode DESC";
			$result = mysql_query($sql,$con);
			if ($result!=false) {

				print "<td bgcolor='".$rgb_blog_banner_bg."' align='center'><span class='normal'><b>Comments</b></span></td>\n";

				while ($row = @ mysql_fetch_array($result)) {
					if ($row["cURL"]!="") {
						$pos = strpos($row["cURL"], "http://");
						if ($pos === false) {
							$url = "[<a href='http://".$row["cURL"]."' target=_blank>Web</a>]";
						} else {
							$url = "[<a href='".$row["cURL"]."' target=_blank>Web</a>]";
						}
					} else {
						$url = "";
					}

					if (is_email($row["cEMail"])) {
						$email = "[<a href='mailto:".$row["cEMail"]."'>E-Mail</a>]";
					} else {
						$email = "";
					}
					print "<tr><td bgcolor='".$rgb_comment_title_bg."'><span class='small'>".stripslashes($row["cUsername"])." wrote...".$email."&nbsp;".$url."</span></td></tr>\n";

					$ccomment=$row["cComment"];
					$pos_break=strpos($ccomment,"<P>IP");
					if ($pos_break > "0") {
						$ccommenthead=substr($ccomment,0,$pos_break);
						$ccommentip="</span><span class='small'>".substr($ccomment,$pos_break, strlen($ccomment));
						print "<tr><td bgcolor='".$rgb_comment_body_bg."'><span class='normal'>".stripslashes($ccommenthead).stripslashes($ccommentip)."</span></td></tr>\n";
					} else {
						print "<tr><td bgcolor='".$rgb_comment_body_bg."'><span class='normal'>".stripslashes($ccomment)."</span></td></tr>\n";
					}

				}
			} else {
				print "<tr><td align='center'><span class='small'>Problem Processing SQL</span></td></tr>";
			}
			print "</table>\n";
			// End of showing comments
		}
		print "</td></tr>\n";

		if ($pref_addcomments == "1"){
			// comment entry form
			print "<tr>\n";
			print "<td bgcolor='".$rgb_comments_bg."'>\n";
			if ($comment == "1") {
				print "<table width='100%' cellpadding='5' cellspacing='0'><tr><td>\n";
				print "<form method='POST' action='comment_add.php'>\n";
				print "<input type='hidden' name='blogid' value='".$id."'>\n";
				print "<input type='hidden' name='selfview' value='".$selfview."'>\n";
				print "<table border='0' cellspacing='1' cellpadding='2' bgcolor='".$rgb_commentform_bg."' align='center'>\n";
				print "<tr><td colspan='2' bgcolor='".$rgb_commentform_banner_bg."' align='center'><span class='small'><b>Add Comment Form</b></span></td></tr>\n";
				print "<tr><td bgcolor='".$rgb_commentform_field_bg."'><span class='small'>Name</span></td><td bgcolor='".$rgb_commentform_input_bg."'><input type='text' name='username' size='70' class='text'></td></tr>\n";
				print "<tr><td bgcolor='".$rgb_commentform_field_bg."'><span class='small'>E-Mail</span></td><td bgcolor='".$rgb_commentform_input_bg."'><input type='text' name='email' size='70' class='text'></td></tr>\n";
				print "<tr><td bgcolor='".$rgb_commentform_field_bg."'><span class='small'>URL</span></td><td bgcolor='".$rgb_commentform_input_bg."'><input type='text' name='url' size='70' class='text'></td></tr>\n";
				print "<tr><td bgcolor='".$rgb_commentform_field_bg."'><span class='small'>Comment</span></td><td bgcolor='".$rgb_commentform_input_bg."'><textarea name='comment' cols='70' rows='3' class='text'></textarea></td></tr>\n";
				print "<tr><td bgcolor='".$rgb_commentform_field_bg."' colspan='2' align='right'><input type='submit' value='Add Comment' class='button'></td></tr>\n";
				print "</table>\n";
				print "</form>\n";
				print "</td></tr></table>\n";
			} else {
				if ($selfview == "1") {
					print "<center><span class='list_title'><a href='index.php?view=".$_GET["view"]."&selfview=1&comment=1'>Add Comments</a></span></center>\n";
				} else {
					print "<center><span class='list_title'><a href='index.php?view=".$_GET["view"]."&comment=1'>Add Comments</a></span></center>\n";
				}
				print "</td></tr>\n";
			}			
		}
		// end of show comments
		print "</table>\n";
	}
	
} else {
	// there was no record to show
	print "<table width='100%' bgcolor='".$rgb_blog_bg."' cellspacing='1' cellpadding='20'>\n";
	if (!$search) {
		print "<tr><td align='center' bgcolor='".$rgb_blog_body_bg."'><span class='normal'>There are no Blog Entries in this Date Range.</span></td></tr>\n";
	} else {
		print "<tr><td align='center' bgcolor='".$rgb_blog_body_bg."'><span class='normal'>There are no Blog Entries containing \"<b>".$search."</b>\".</span></td></tr>\n";
	}
	print "</table>\n";
	// end of there was no record to show
}
// end of the center section

print "</td>\n";


// insert the right side
print "<td width='200' valign='top'>\n";

print "<center><a href='rss.xml'><img src='images/xml.gif' width='36' height='14'></a></center>\n";

// white space
print "<table border='0' cellspacing='0' cellpadding='0'><tr><td><img src='images/pix5.gif' width='5' height='5'></td></tr></table>\n";

if ($pref_intro) {
	print "<table width='100%' border='0' cellspacing='1' cellpadding='1' bgcolor='#aabbcc' align='center'>\n";
	print "<tr><td bgcolor='#ccddff' align='center'><span class='small'><b>Introduction</b></span></td></tr>\n";
	print "<tr><td bgcolor='#ffffff'>\n";
	print "<table width='100%' border='0' cellspacing='0' cellpadding='0' bgcolor='#ffffff' align='center'>\n";
	print "<tr><td><span class='small'><br>".$pref_intro."<br><br></span></td></tr>\n";
	print "</table>\n";
	print "</td></tr>\n";
	print "</table>\n";
}

$sql="SELECT * FROM blog ORDER BY nViews DESC LIMIT 0 , 5";
$result = mysql_query($sql);
if ($result!=false) {
	print "<table width='100%' border='0' cellspacing='1' cellpadding='1' bgcolor='#aabbcc' align='center'>\n";
	print "<tr><td bgcolor='#ccddff' align='center'><span class='small'><b>Most Read Topics</b></span></td></tr>\n";
	print "<tr><td bgcolor='#ffffff'>\n";
	print "<table border='0' cellspacing='0' cellpadding='0' bgcolor='#ffffff' align='center'>\n";
	print "<tr><td><br></td></tr>\n";
	while ($row = @ mysql_fetch_array($result)) {
		$s=stripslashes($row["cTitle"]);
		$s_len=strlen($s);
		if ($s_len > "20") {
			$s=substr($s,0,20);
			$s=substr($s,0,strrpos($s," "));
			if ($selfview == "1") {
				print "<tr><td><span class='small'><a href='index.php?view=".$row["nIdCode"]."&selfview=1'>".$s."...</a></span></td></tr>\n";
			} else {
				print "<tr><td><span class='small'><a href='index.php?view=".$row["nIdCode"]."'>".$s."...</a></span></td></tr>\n";
			}
		} else {
			if ($selfview == "1") {
				print "<tr><td><span class='small'><a href='index.php?view=".$row["nIdCode"]."&selfview=1'>".$s."</a></span></td></tr>\n";
			} else {
				print "<tr><td><span class='small'><a href='index.php?view=".$row["nIdCode"]."'>".$s."</a></span></td></tr>\n";
			}

		}
	}
	print "<tr><td><br></td></tr>\n";
	print "</table>\n";
	print "</td></tr>\n";
	print "</table>\n";
}

if ($pref_showcomments == "1") {
	$sql="SELECT * FROM blog ORDER BY nComments DESC LIMIT 0 , 5";
	$result = mysql_query($sql);
	if ($result!=false) {
		print "<table width='100%' border='0' cellspacing='1' cellpadding='1' bgcolor='#aabbcc' align='center'>\n";
		print "<tr><td bgcolor='#ccddff' align='center'><span class='small'><b>Most Commented</b></span></td></tr>\n";
		print "<tr><td bgcolor='#ffffff'>\n";
		print "<table border='0' cellspacing='0' cellpadding='0' bgcolor='#ffffff' align='center'>\n";
		print "<tr><td><br></td></tr>\n";
		while ($row = @ mysql_fetch_array($result)) {
			if ($row["nComments"] > "0") {
				$s=stripslashes($row["cTitle"]);
				$s_len=strlen($s);
				if ($s_len > "20") {
					$s=substr($s,0,20);
					$s=substr($s,0,strrpos($s," "));
					if ($selfview == "1") {
						print "<tr><td><span class='small'><a href='index.php?view=".$row["nIdCode"]."&selfview=1'>".$s."...</a></span></td></tr>\n";
					} else {
						print "<tr><td><span class='small'><a href='index.php?view=".$row["nIdCode"]."'>".$s."...</a></span></td></tr>\n";
					}
				} else {
					if ($selfview == "1") {
						print "<tr><td><span class='small'><a href='index.php?view=".$row["nIdCode"]."&selfview=1'>".$s."</a></span></td></tr>\n";
					} else {
						print "<tr><td><span class='small'><a href='index.php?view=".$row["nIdCode"]."'>".$s."</a></span></td></tr>\n";
					}
				}
			}
		}
		print "<tr><td><br></td></tr>\n";
		print "</table>\n";
		print "</td></tr>\n";
		print "</table>\n";
	}

	$sql = "SELECT * FROM blog_comments ORDER BY nIdCode DESC LIMIT 0 , 5";
	$result = mysql_query($sql);
	if ($result!=false) {
		print "<table width='100%' border='0' cellspacing='1' cellpadding='1' bgcolor='#aabbcc' align='center'>\n";
		print "<tr><td bgcolor='#ccddff' align='center'><span class='small'><b>Recent Comments</b></span></td></tr>\n";
		print "<tr><td bgcolor='#ffffff'>\n";
		print "<table border='0' cellspacing='0' cellpadding='0' bgcolor='#ffffff' align='center'>\n";
		print "<tr><td><br></td></tr>\n";
		while ($row = @ mysql_fetch_array($result)) {
			$s=stripslashes($row["cComment"]);
			$pos_break=strpos($s,"<P>IP");
			if ($pos_break > "0") {
				$s=substr($s,0,$pos_break);
			}
			$s_len=strlen($s);
			if ($s_len > "20") {
				$s=substr($s,0,20);
				$s=substr($s,0,strrpos($s," "));
				if ($selfview == "1") {
					print "<tr><td><span class='small'><a href='index.php?view=".$row["nBlogId"]."&selfview=1'>".$s."...</a></span></td></tr>\n";
				} else {
					print "<tr><td><span class='small'><a href='index.php?view=".$row["nBlogId"]."'>".$s."...</a></span></td></tr>\n";
				}
			} else {
				if ($selfview == "1") {
					print "<tr><td><span class='small'><a href='index.php?view=".$row["nBlogId"]."&selfview=1'>".$s."</a></span></td></tr>\n";
				} else {
					print "<tr><td><span class='small'><a href='index.php?view=".$row["nBlogId"]."'>".$s."</a></span></td></tr>\n";
				}
			}
		}
		print "<tr><td><br></td></tr>\n";
		print "</table>\n";
		print "</td></tr>\n";
		print "</table>\n";
	}
}

print "<table width='100%' border='0' cellspacing='1' cellpadding='1' bgcolor='#aabbcc' align='center'>\n";
print "<tr><td bgcolor='#ccddff' align='center'><span class='small'><b>Links</b></span></td></tr>\n";
print "<tr><td bgcolor='#ffffff'>\n";
print "<table border='0' cellspacing='0' cellpadding='0' bgcolor='#ffffff' align='center'>\n";
print "<tr><td><br></td></tr>\n";
print "<tr><td><span class='small'><a href='http://www.rtsoftware.org' target=_blank>Quality Software</A></span></td></tr>\n";
print "<tr><td><span class='small'><a href='http://www.address-book.org' target=_blank>My Online Address Book</A></span></td></tr>\n";
print "<tr><td><span class='small'><a href='http://www.neophotos.com' target=_blank>NeoPhotos</A></span></td></tr>\n";
print "<tr><td><span class='small'><a href='http://www.bloggingdoctor.com'>Blog Mod</a></span></td></tr>\n";
print "<tr><td><br></td></tr>\n";
print "</table>\n";
print "</td></tr>\n";
print "</table>\n";

print "<table width='100%' border='0' cellspacing='1' cellpadding='1' bgcolor='#aabbcc' align='center'>\n";
print "<tr><td bgcolor='#ccddff' align='center'><span class='small'><b>Earn $$$</b></span></td></tr>\n";
print "<tr><td bgcolor='#ffffff'>\n";
print "<table border='0' cellspacing='0' cellpadding='0' bgcolor='#ffffff' align='center'>\n";
print "<tr><td><br></td></tr>\n";
print "<tr><td><span class='small'><a href='http://paypopup.com/pubsignup.php?ref=rtsoftware' target=_blank>PayPopup</a></span></td></tr>\n";
print "<tr><td><span class='small'><a href='http://www.revenuepilot.com/gopilot/home.jsp?id=4873' target=_blank>RevenuePilot</a></span></td></tr>\n";
print "<tr><td><br></td></tr>\n";
print "</table>\n";
print "</td></tr>\n";
print "</table>\n";


if ($pref_search == "1") {
	print "<table width='100%' border='0' cellspacing='1' cellpadding='1' bgcolor='#aabbcc' align='center'>\n";
	print "<tr><td bgcolor='#ccddff' align='center'><span class='small'><b>Search Entries</b></span></td></tr>\n";
	print "<tr><td bgcolor='#ffffff'>\n";
	print "<table border='0' cellspacing='0' cellpadding='0' bgcolor='#ffffff' align='center'>\n";
	print "<tr><td><br></td></tr>\n";
	if ($selfview == "1") {
		print "<tr><td><span class='small'><form method='POST' action='".$PHP_SELF."?selfview=1'><input type='text' size='15' name='search'></form></span></td></tr>\n";
	} else {
		print "<tr><td><span class='small'><form method='POST' action='".$PHP_SELF."'><input type='text' size='15' name='search'></form></span></td></tr>\n";
	}
	print "<tr><td><br></td></tr>\n";
	print "</table>\n";
	print "</td></tr>\n";
	print "</table>\n";
}

print "<table width='100%' border='0' cellspacing='1' cellpadding='1' bgcolor='#aabbcc' align='center'>\n";
print "<tr><td bgcolor='#ccddff' align='center'><span class='small'><b>".date('Y-m-d H:i:s', zonechange("$pref_currenttimezone", "$pref_targettimezone"))."</b></span></td></tr>\n";
print "</table>\n";

print "</td></tr></table>\n";
// finish

print "<table width='100%' border='0' cellspacing='0' cellpadding='0' bgcolor='".$rgb_banner_bg."'>\n";
print "<tr><td bgcolor='#ccddff' align='center'><span class='small'>Disclaimer: All entries seen here reflect the author's state of mind at the time of posting and are subjected to changes.<br>You have no permission to reproduce whatever is written here. Legal actions will be taken against violators.<br>".$site_copyright."</td></tr>\n";
print "</table>\n";

print "</body>\n";
print "</html>\n";
?>