<?php

// Initialise Constants
// (you will need to fill these out to get the present content to work correctly)

$admin_password = "yourpassword"; // asked when you go to add an entry via entry_form.php

$db_server = "localhost"; // database server, usually localhost
$db_name = "databasename"; // database name
$db_username = "databaseuser"; // database user
$db_password = "databasepassword"; // database password

$site_root_url = "http://www.yourdomain.com"; //Domain of your blog
$site_url = "http://www.yourdomain.com/blog_directory"; //URL of your blog
$sitedomain = "yourdomain.com"; //your domain without the "http://www"
$site_title = "your_title"; //Title of your blog
$site_desc = "Description of your blog"; //Description of your blog
$site_keywords = "keywords,for,your,site"; //Keywords for your site, separated by commas
$site_copyright = "Copyright � 2003. All rights reserved.";
$site_lang = "en-us";

// 0 for no, 1 for yes
$pref_intro = "My New Blog"; //example of introduction, "" if you do not want any
$pref_showviews = "1"; // show view count
$pref_viewscount = "1"; // count the number of views
$pref_showcomments = "1"; // show comments
$pref_addcomments = "1"; // allow adding of comments
$pref_currenttimezone = "-4"; // timezone of server e.g. "-4" for GMT -0400, "" if you do not know
$pref_targettimezone = "8"; // timezone of your location e.g. "8" for GMT +0800, "" if you do not know
$pref_search = "1"; // allow search

// $pref_currenttimezone = "";
// $pref_targettimezone = "";
// $pref_showedit = "1"; // allow editing by yourself = obsolete
// $pref_comments = "1"; // allow viewing and adding of comments = obsolete
// $imood_email = "your_imood_email";
// $clix_id = "your_clix_id";

// colors
$rgb_body_bg = "#eeeeff";
$rgb_body_text = "#000000";
$rgb_body_link = "#0000aa";
$rgb_body_alink = "#0000aa";
$rgb_body_vlink = "#0000aa";

$rgb_banner_bg = "#ffffff";
$rgb_banner_line = "#888888";
$rgb_banner_sub_bg = "#aaccee";

$rgb_bloglist_title_bg = "#ccddee";
$rgb_bloglist_detail_bg = "#ddeeff";

$rgb_bloglist_bg = "#aabbcc";
$rgb_bloglist_banner_bg = "#ccddff";

$rgb_blog_bg = "#aabbcc";
$rgb_blog_banner_bg = "#ccddff";
$rgb_blog_banner_sub_bg = "#bbccdd";
$rgb_blog_body_bg = "#ffffff";

$rgb_comments_bg = "#eeeeff";
$rgb_comment_title_bg = "#ccddee";
$rgb_comment_body_bg = "#bbccdd";

$rgb_commentform_bg = "#aaaaaa";
$rgb_commentform_banner_bg = "#cccccc";
$rgb_commentform_field_bg = "#bbccdd";
$rgb_commentform_input_bg = "#ccddee";

$rgb_feature_bg = "#aabbcc";
$rgb_feature_banner_bg = "#ccddff";
$rgb_feature_body_bg = "#ffffff";

$rgb_calendar_bg = "#aabbcc";
$rgb_calendar_banner_bg = "#ccddff";
$rgb_calendar_banner_sub_bg = "#bbccee";
$rgb_calendar_body_bg = "#ffffff";
$rgb_calendar_dayon_bg = "#ddddee";
$rgb_calendar_dayoff_bg = "#eeeeff";
?>