<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html>
<head>
<title>Motiontheque Blog App</title>
<link rel="stylesheet" type="text/css" href="main_style.css" />
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
</head>
<body>                                  
<?php
// error message
echo "Unauthorized access";
?>
<br />
Please <a href="admin_login.php">log in</a> again.
</body>
</html>