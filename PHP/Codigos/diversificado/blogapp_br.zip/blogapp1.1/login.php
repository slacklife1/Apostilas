<?php
$f_user = $_POST[f_user];
$f_pass = $_POST[f_pass];
$status = authenticate($f_user, $f_pass);

// if  user/pass combination is correct
if ($status == 1)
	{
	// initiate a session
	session_start();
	
	// register some session variables
	session_register("SESSION");

	// including the username
	session_register("SESSION_UNAME");
	$SESSION_UNAME = $f_user;
	
	// redirect to protected page
	header("Location: admin.php");
	exit();
	}
else
// user/pass check failed
	{
	// redirect to error page
	header("Location: error.php");
	exit();
	}
	
// authenticate username/password against a database
// returns: 0 if username and password is incorrect
//          1 if username and password are correct
function authenticate($theuser, $thepass)
	{
	// configuration variables
	include("config.php");
	global $connection;
	
	//connect to database
	$connection = @mysql_connect($host, $user, $pass) or die("Unable to connect to database!");

	//select database
	@mysql_select_db($db, $connection) or die("Unable to select database!");
	
	//query string	
	$query = "SELECT id from blogapp_user WHERE username = '$theuser' AND password = PASSWORD('$thepass')";
	
        //store query in a variable
	$result = @mysql_query($query, $connection) or die ("Error in query: $query. " . mysql_error());
	
	// if row exists -> user/pass combination is correct
	if (mysql_num_rows($result) == 1)
		{
		return 1;
       		}
	// user/pass combination is wrong
	else
		{
		return 0;
		}
	}
?>