<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html>
<head>
<title>Motiontheque Blog App</title>
<link rel="stylesheet" type="text/css" href="admin_style.css" />
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
</head>
<body>
                                  
<div style="text-align: center;">
<form action="login.php" method="post">
	<p>Username:<br />
	<input type="text" size="20" name="f_user" /> 
	<br />Password:<br />
	<input type="password" size="20" name="f_pass" />
	<br />	
	<input type="submit" name="submit" value="Log In">
	</p>
</form> 

</body>
</html>
