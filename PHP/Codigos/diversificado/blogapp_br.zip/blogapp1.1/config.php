<?php
//define variables
$limit = 2; 
$host = "localhost";
$user = "username";
$pass = "password";
$db = "database_name";

//connect to database
$connection = @mysql_connect($host, $user, $pass) or die("Unable to connect to database!");

//select database
@mysql_select_db($db, $connection) or die("Unable to select database!");
?>