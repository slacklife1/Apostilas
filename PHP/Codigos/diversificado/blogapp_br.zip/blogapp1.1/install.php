<?
include("config.php");

$query = "CREATE TABLE blogapp_comments";
$query .="(id int(10) unsigned NOT NULL auto_increment,";
$query .="post_id int(10) unsigned NOT NULL default '0',";
$query .="name varchar(50) NOT NULL default '', ";
$query .="comment text NOT NULL, PRIMARY KEY  (id),";
$query .="KEY post_id (post_id))"; 


$query2 = "CREATE TABLE blogapp_posts";
$query2 .="(id int(10) unsigned NOT NULL auto_increment,";
$query2 .="pdate timestamp(14) NOT NULL,";
$query2 .="title varchar(50) NOT NULL default '',";
$query2 .="author varchar(50) NOT NULL default '',";
$query2 .="content text NOT NULL, PRIMARY KEY  (id), KEY pdate (pdate))";

$query3 = "CREATE TABLE blogapp_user";
$query3 .="(id int(10) NOT NULL auto_increment,";
$query3 .="username varchar(50) NOT NULL default '',";
$query3 .="password varchar(50) NOT NULL default '',";
$query3 .="PRIMARY KEY  (id))";

$query4 = "INSERT INTO blogapp_user (id, username, password) VALUES (1, 'admin', '032c41e8435273a7')";

mysql_query($query);
mysql_query($query2);
mysql_query($query3);
mysql_query($query4);

header("Location: admin_login.php");
?>