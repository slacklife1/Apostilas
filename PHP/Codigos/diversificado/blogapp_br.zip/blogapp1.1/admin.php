<?php
//admin.php - secure page

//session check
session_start();
if (!session_is_registered("SESSION"))
	{
	// if session check fails redirect to error page
	header("Location: error.php");
	exit();
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 

<html>
<head>
<title>Motiontheque Blog App</title>
<link rel="stylesheet" type="text/css" href="admin_style.css" />
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
</head>
<body>
<?php
//include config settings
include("config.php");

function index()
	{
	?>
	<div class="indexHolder">
	<p class="indexTitle">Motiontheque Blogapp Control Panel</p>
	
	<!--print links -->
	<p class="indexTitle">
	<a class="indexLink" href="<?php echo "{$_SERVER['PHP_SELF']}?action=addPost"; ?>">add post</a></p>
	
	<p class="indexTitle">
	<a class="indexLink" href="<?php echo "{$_SERVER['PHP_SELF']}?action=showPosts"; ?>">edit or delete posts and comments</a></p>
	
	<p class="indexTitle">
	<a class="indexLink" href="<?php echo "{$_SERVER['PHP_SELF']}?action=changePass"; ?>">change username and/or password</a></p>
	</div>
	<?php
	echo "\n";
	}

function showPosts() 
	{
       	global $connection, $limit;
       	
       	$page = $_GET[page];                 
    	$query_count = "SELECT title FROM blogapp_posts";      
    	$result_count = mysql_query($query_count);       
    	$totalrows = mysql_num_rows($result_count);    	 
    	
    	if(!$page)
    		{
    		$page = 1;
    		} 
        
        $limitvalue = $page * $limit - ($limit);
        $query = "SELECT id,title,author,content, DATE_FORMAT(pdate, '%Y-%m-%d') as date FROM blogapp_posts ORDER BY pdate DESC LIMIT $limitvalue, $limit";    
    	$result    = mysql_query($query) or die("Error: " . mysql_error());
    	
    	if(mysql_num_rows($result) == 0)
    		{
    		echo "There are no posts available";
    		}
    		
    	//begin holder
    	echo "<div class=\"holderSingle\">";
    	echo "\n\t";
    	echo "<p class=\"title\">";
    	echo "\n\t";
    	echo "Select post to edit or delete</p>";
    	echo "\n";
    		   
       	//loop to display all items
    	while ($row = mysql_fetch_assoc($result)) 
    		{
        	//define variables
		$date = $row['date'];        
  		$title = htmlentities ($row['title']);
  		$author = $row['author'];
        	$content = nl2br($row['content']);
        
        	//begin display
        	echo "\n\t";
        	echo "<div class=\"title\">";
        	echo "\n\t";
        	echo "$title";
        	echo "\n\t";
        	echo "</div>";
        	echo "\n\t";
        	echo "<div class=\"post-text\">";
        	echo "\n\t";
        	echo "$content";
        	        
        	//get number of comments
        	$comment_query = "SELECT count(*) FROM blogapp_comments WHERE post_id={$row['id']}";
        	$comment_result = mysql_query($comment_query);
        	$comment_row = mysql_fetch_row($comment_result);
        
        	// display number of comments with link
        	echo "\n\t";
        	echo "<p class=\"author\">";
        	echo "\n\t";
        	echo "<a href=\"{$_SERVER['PHP_SELF']}?action=showSingle&id={$row['id']}\">edit or delete this post</a>";
        	echo "\n\t";
        	echo "<br /><br />";
        	echo "\n\t";
        	echo "posted by $author on $date &nbsp;";
        	echo "\n\t";
        	echo "<a href=\"{$_SERVER['PHP_SELF']}?action=showComments&id={$row['id']}\">edit comments</a>($comment_row[0])</p>";
        	echo "\n\t";
                echo "</div>";
                echo "\n\n";
        	}
        	
        if($page > 1)
        	{  
        	$pageprev = $page - 1;
        	echo "\t"; 
        	echo "<a href=\"{$_SERVER['PHP_SELF']}?action=showPosts&page=$pageprev\">PREV</a>&nbsp;";  
    		}
    	else 
    		{
    		echo "\t";
    		echo "PREV&nbsp;";
    		echo "\n";
    		}
    		
    	$numofpages = $totalrows / $limit;
    	
    	for($i = 1; $i <= $numofpages; $i++)
    		{ 
        	if($i == $page)
        		{
        		echo "\t";
        		echo "$i";
        		echo "\n";
        		}
        	else
        		{
        		echo "\t";
        		echo "<a href=\"{$_SERVER['PHP_SELF']}?action=showPosts&page=$i\">$i</a>&nbsp;";
        		echo "\n";
        		}
        	}
        		
        if(($totalrows % $limit) != 0)
        	{ 
        	if($i == $page)
        		{
        		echo "$i";
        		echo "&nbsp;\n";
        		}
        	else 
        		{
        		echo "\t";
        		echo "<a href=\"{$_SERVER['PHP_SELF']}?action=showPosts&page=$i\">$i</a>&nbsp;";
        		echo "\n";
        		}
        	}
        		
        if(($totalrows - ($limit * $page)) > 0)
        	{
        	if(!$page)
    			{
    	       		$page = 1;
    			}  
        	$pagenext = $page + 1;
        	echo "\t";
        	echo"<a href=\"{$_SERVER['PHP_SELF']}?action=showPosts&page=$pagenext\">NEXT</a>"; 
        	echo "\n"; 
    		}
    	else 
    		{
    		echo "\t";
    		echo "&nbsp; NEXT ";
    		echo "\n";
    		}
    		
    	echo "\t";    		
    	echo "<br /><br /><a href=\"admin.php\">back to main menu</a>";
    	echo "\n\n";
    	echo "</div>";
    	echo "\n";
    	}
    	
function showSingle($id) 
		{
    		global $connection;
    
    		//query string
    		$query = "SELECT * FROM blogapp_posts WHERE id=$id";
    		
    		//store query result in a variable
    		$result = mysql_query($query);
    
    		//in case of error display friendly message
    		if (mysql_num_rows($result) == 0) 
    			{
        		echo "Bad news id\n";
        		return;
    			}
    
    		$row = mysql_fetch_assoc($result);
    		
    		//define variables
     		$title = htmlentities ($row['title']);
    		$content = nl2br($row['content']);
    
    		//display
    		echo "<div class=\"holderSingle\">";
    		echo "\n\t";    		
   		echo "<div class=\"title\">";
   		echo "\n\t";
   		echo "Topic title: $title";
   		echo "\n\t";
   		echo "</div>";
   		echo "\n\n\t";
    		echo "<div class=\"post-text\">";
    		echo "\n\t";
    		echo "$content";
    		echo "<br /><br /><br />";    		    		
    		//edit links
    		echo "\n\t";
    		echo "<a class=\"buttons\" href=\"{$_SERVER['PHP_SELF']}?action=deletePost&id={$row['id']}\">delete</a>";
    		echo "&nbsp;&nbsp;&nbsp;";
    		echo"\n\t";
    		echo "<a class=\"buttons\" href=\"{$_SERVER['PHP_SELF']}?action=editPost&id={$row['id']}\">edit</a>";
    		echo "\n\t";
    		echo "<br /><br /><a href=\"admin.php\">back to main menu</a>";
    		echo "\n\n\t";
    		echo "</div>";
    		echo "\n";
    		
    		//close holderSingle
    		echo "</div>"; 
    		echo "\n";  		
    		}
		
function showComments($id) 
		{
    		/* bring db connection variable into scope */
    		global $connection;
    
    		//query string
    		$query = "SELECT * FROM blogapp_comments WHERE post_id=$id";
    		
    		//store query result in a variable
    		$result = mysql_query ($query);
    		
    		//begin display
    		echo "<div class=\"holderSingle\">";
    		echo "\n\t";
    
    		//loop to display comments
    		while ($row = mysql_fetch_assoc($result)) 
    			{
       			//define variables
       			$name = htmlentities ($row['name']);
       			
                        echo "<div class=\"title\">";
                        echo "\n\t";
        		echo "by: $name";
        		echo "\n\t";
        		echo "</div>";
        		echo "\n\n\t";
    
        		$comment = strip_tags ($row['comment'], '<a><b><i><u>');
       			$comment = nl2br ($comment);
        		echo "<div class=\"post-text\">";
        		echo "\n\t";
        		echo "$comment";
        		echo "\n\t";
        		
        		//edit links
    			echo "<br /><br /><br />";
    			echo "\n\t";
    			echo "<a class=\"buttons\" href=\"{$_SERVER['PHP_SELF']}?action=deleteComment&id={$row['id']}\">delete</a>";
    			echo "\n\t";
    			echo "&nbsp;&nbsp;";
    			echo "\n\t";
    			echo "<a class=\"buttons\" href=\"{$_SERVER['PHP_SELF']}?action=editComment&id={$row['id']}\">edit</a>";
    			echo "\n\t"; 
    			echo "</div>";
                        }
       		echo "\n\t";
       		echo "<br /><br />";
       		echo "\n\t";
       		echo "<a href=\"admin.php\">back to main menu</a>";
       		echo "</div>";
       		echo "\n";
        	}

function addPost()
	{
	global $connection;
	$submit = $_POST[submit];
	
	if(!$submit)
		{
		//display form
		?>
<div class="formholder">
<p class="title">Add post form</p>
<form action="<?php $_SERVER['PHP_SELF'] ?>" method="post">
	<b>Title:</b><br />
	<input type="text" name="title" style="{width: 300px;}"/><br />
	<b>Author:</b><br />
	<input type="text" name="author" style="{width: 300px;}"/><br />
	<b>Content:</b><br />
	<textarea rows="50" name="content" style="{width: 400px;}"></textarea><br />
	<input type="submit" name="submit" value="submit" />
</form>
<a href="admin.php">Go back to main menu</a>
</div>
      
		<?php
		echo "\n";
		}
	else
		{
		//process form
		
		//define variables
		$title = $_POST[title];
		$author = $_POST[author];
		$content = $_POST[content];

		//query string
 		$query = "INSERT INTO blogapp_posts(title, author, content, pdate) VALUES('$title', '$author', '$content', NOW())";
 		
 		//store query result in a variable
 	        $result = mysql_query($query) or die("Error in query: $query. " .mysql_error());
 		
 		//print result
 		echo "<p>Post added successfully<br />";
 		echo "\n";
 		echo "<a href=\"admin.php\">Go back to main menu</a></p>";
 		}
 	}
	
function deletePost($id)
	{
	global $connection;
	
	//query string
	$query = "DELETE FROM blogapp_posts WHERE id= '$id'";
	
	//store query results in a new variable
	$result = mysql_query($query) or die ("Error in query: $query. " .mysql_error());
	 
	//print notification message
	echo "Post deleted successfully.";
	echo "\n";
	echo "<a href=\"admin.php\">Go back to the main menu</a>";
	echo "\n";
	}
	
function deleteComment($id)
	{
	global $connection;
	
	//query string
	$query = "DELETE FROM blogapp_comments WHERE id= '$id'";
	
	//store query results in a new variable
	$result = mysql_query($query) or die ("Error in query: $query. " .mysql_error());
	 
	//print notification message
	echo "Comment deleted successfully.";
	echo "\n";
	echo "<a href=\"admin.php\">Go back to the main menu</a>";
	echo "\n";
	}
	
function editPost($id)
	{
	global $connection;
	$submit = $_POST[submit];
	
	if(!$submit)
		{
		//query string
		$query = "SELECT title, author, content FROM blogapp_posts WHERE id='$id'";
	
		//store query results in a new variable
		$result = mysql_query($query) or die ("Error in query: $query. " .mysql_error());
	
		//if there is a record for the query
       		if(mysql_num_rows($result) >0)
			{
			//turn it into an object
	       		$row = mysql_fetch_object($result);
		
			//print form with values pre-filled
	       		?>
<div class="formholder">
<p class="title">Edit post form</p>
<form action="<?php $_SERVER['PHP_SELF'] ?>" method="post">
	<input type="hidden" name="id" value="<?php echo $id; ?>" />	
	<b>Title:</b><br />
	<input type="text" name="title" value="<?php echo $row->title; ?>" style="{width: 300px;}" />	
        <br /><b>Author:</b><br />
	<input type="text" name="author" value="<?php echo $row->author; ?>" style="{width: 300px;}" />	
	<br /><b>Content:</b><br />
	<textarea name="content" rows="50" style="{width: 400px;}"><? echo $row->content; ?></textarea><br />	
	<input type="submit" name="submit" value="submit" />
</form>
<a href="admin.php">Go back to main menu</a>
</div>
	       		<?php
	       		echo "\n";
	       		}
		//if there is not a record for the query
		else
			{
	       		echo "<p>The post could not be located in the database!</p>";
	       		}
	  	}
	//process form 
	else
		{
		//define variables
		$title = $_POST[title];
		$author = $_POST[author];
		$content = $_POST[content];
		
		//query string
       		$query = "UPDATE blogapp_posts SET title = '$title', author = '$author', content = '$content', pdate = pdate WHERE id = '$id'";
		
		//store query results in a new variable
       		$result = mysql_query($query) or die ("Error in query: $query. " .mysql_error());
		
		//print result
		echo "Update successful!";
		echo "\n";
		echo "<a href=\"admin.php\">Go Back To The main Menu</a>";
		echo "\n";
		}

	}
	
function editComment($id)
	{
	global $connection;
	$submit = $_POST[submit];
	
	if(!$submit)
		{
		//query string
		$query = "SELECT name, comment FROM blogapp_comments WHERE id='$id'";
	
		//store query results in a new variable
		$result = mysql_query($query) or die ("Error in query: $query. " .mysql_error());
	
		//if there is a record for the query
       		if(mysql_num_rows($result) >0)
			{
			//turn it into an object
	       		$row = mysql_fetch_object($result);
		
			//print form with values pre-filled
	       		?>
<div class="formholder">
<p class="title">Edit comment form</p>
<form action="<?php $_SERVER['PHP_SELF'] ?>" method="post">
	<input type="hidden" name="id" value="<? echo $id; ?>" />	
	<b>Name:</b><br />
	<input type="text" name="name" value="<? echo $row->name; ?>" style="{width: 300px;}" />	
        <br /><b>Comment:</b><br />
	<textarea name="comment" rows="20" style="{width: 400px;}"><? echo $row->comment; ?></textarea>	
	<input type="submit" name="submit" value="submit" />
</form>
<a href="admin.php">Go back to main menu</a>
</div>
	       		<?php
	       		}
		//if there is not a record for the query
		else
			{
	       		echo "<p>The post could not be located in the database!</p>";
	       		}
	  	}
	//process form 
	else
		{
		//define variables
		$name = $_POST[name];
		$comment = $_POST[comment];
		
		//query string
       		$query = "UPDATE blogapp_comments SET name = '$name', comment = '$comment' WHERE id = '$id'";
		
		//store query results in a new variable
       		$result = mysql_query($query) or die ("Error in query: $query. " .mysql_error());
		
		//print result
		echo "Update successful!";
		echo "<a href=\"admin.php\">Go Back To The main Menu</a>";
		}

	}
	
function changePass()
	{
	global $connection;
	$submitPass = $_POST[submitPass];
	$username = $_POST[username];
	$password = $_POST[password];
	$newusername = $_POST[newusername];
	$newpass1 = $_POST[newpass1];
	$newpass2 = $_POST[newpass2];
	
	if(!$submitPass)
		{
		?>
<div class="formholder">
<p class="title">Change username and/or password form</p>
<form action="<?php $_SERVER['PHP_SELF'] ?>" method="post">
	<b>Username:</b><br />
	<input type="text" name="username" style="{width: 300px;}" />	
        <br /><br />
        <b>Current password:</b><br />
        <input type="text" name="password" style="{width: 300px;}" />
        <br /><br />
        <b>New username:</b><br />
	<input type="text" name="newusername" style="{width: 300px;}" />	
        <br /><br />
        <b>New password:</b><br />
        <input type="text" name="newpass1" style="{width: 300px;}" />
        <br /><br />
        <b>Confirm new password:</b><br />
        <input type="text" name="newpass2" style="{width: 300px;}" />
	<br />
	<input type="submit" name="submitPass" value="submit" />
</form>
<a href="admin.php">Go back to main menu</a>
</div>
		<?php
		}
	else
		{
		$query = "SELECT id from blogapp_user WHERE username = '$username' AND password = PASSWORD('$password')";
		$result = mysql_query($query, $connection) or die ("Error in query: $query. " . mysql_error());
		
		// if row exists -> user/pass combination is correct
		if (mysql_num_rows($result) == 1)
			{
			if($newpass1==$newpass2)
				{
				$update_query = "UPDATE blogapp_user SET username = '$newusername', password = PASSWORD('$newpass1')";
				$update_result = mysql_query($update_query, $connection) or die ("Error in query: $query. " . mysql_error());
				echo "<p>Username and password updated successfully!</p>";
				echo "\n";
				echo "<a href=\"admin.php\">Go back to main menu</a>";
				}
			else
				{
				echo "<p>sorry, your new password didn't math the confirmation</p>";
				}
			}
		else
			{
			echo "<p>sorry, your username/password didn't match</p>";
			?>
			<a href="admin.php">Go back to main menu</a>
			<?php
			}
		}
	}	
	
//switch between functions according to action passed along with URL

		switch($_GET['action']) 
			{    
    			case 'addPost':
        		addPost();
        		break;
        		
        		case 'editPost':
        		editPost($_GET['id']);
        		break;
        		
        		case 'deletePost':
        		deletePost($_GET['id']);
        		break;
        		
        		case 'editComment':
        		editComment($_GET['id']);
        		break;
        		
        		case 'deleteComment':
        		deleteComment($_GET['id']);
        		break;
        		
        		case 'showComments':
        		showComments($_GET['id']);
        		break;
        		
        		case 'showSingle':
        		showSingle($_GET['id']);
        		break;
        		
        		case 'showPosts':
        		showPosts();
        		break;
        		
        		case 'changePass':
        		changePass();
        		break;
        		
        		default:
        		index();
			}
	
?>
</body>
</html>