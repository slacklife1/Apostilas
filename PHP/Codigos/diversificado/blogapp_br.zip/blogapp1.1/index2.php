<?
//include config settings
include("config.php");

function showPosts() 
	{
       	global $connection, $limit;
       	
       	$page = $_GET[page];                 
    	$query_count = "SELECT title FROM blogapp_posts";      
    	$result_count = @mysql_query($query_count);       
    	$totalrows = mysql_num_rows($result_count);    	 
    	
    	if(!$page)
    		{
    		$page = 1;
    		} 
        
        $limitvalue = $page * $limit - ($limit);
        $query = "SELECT id,title,author,content, DATE_FORMAT(pdate, '%Y-%m-%d') as date FROM blogapp_posts ORDER BY pdate DESC LIMIT $limitvalue, $limit";    
    	$result = @mysql_query($query) or die("Error: " . mysql_error());
    	
    	if(mysql_num_rows($result) == 0)
    		{
    		echo "Nothing to Display!";
    		}
    		   
       	//loop to display all items
    	while ($row = mysql_fetch_assoc($result)) 
    		{
        	//define variables
		$date = $row['date'];        
  		$title = htmlentities ($row['title']);
  		$author = $row['author'];
        	$content = nl2br($row['content']);
        
        	//begin display
        	echo "<div class=\"post-title\">";
        	echo "\n";
        	echo "$title";
        	echo "\n";
        	echo "</div>";
        	echo "\n";
        	echo "<div class=\"post-text\">";
        	echo "\n";
        	echo "$content";
        	echo "\n";
        	echo "</div>";
        	echo "\n";
        
        	//get number of comments
        	$comment_query = "SELECT count(*) FROM blogapp_comments WHERE post_id={$row['id']}";
        	$comment_result = mysql_query($comment_query);
        	$comment_row = mysql_fetch_row($comment_result);
        
        	// display number of comments with link 
        	echo "<p class=\"author\">";
        	echo "\n";
        	echo "posted by $author on $date &nbsp;";
        	echo "\n";
        	echo "<a href=\"{$_SERVER['PHP_SELF']}?action=show&amp;id={$row['id']}\">Comments</a>";
        	echo "\n";
        	echo "($comment_row[0])";
        	echo "\n";
        	echo "</p>";
        	echo "\n";
        
        	//end
        	}
        	
        if($page > 1)
        	{  
        	$pageprev = $page - 1; 
        	echo "<a href=\"{$_SERVER['PHP_SELF']}?page=$pageprev\">PREV</a>&nbsp;";
        	echo "\n";  
    		}
    	else 
    		{
    		echo "PREV&nbsp;";
    		echo "\n";
    		}
    		
    	$numofpages = $totalrows / $limit;
    	
    	for($i = 1; $i <= $numofpages; $i++)
    		{ 
        	if($i == $page)
        		{
        		echo "$i";
        		echo "&nbsp;";
        		echo "\n";
        		}
        	else
        		{
        		echo "<a href=\"{$_SERVER['PHP_SELF']}?page=$i\">$i</a>&nbsp;";
        		echo "\n";
        		}
        	}
        		
        if(($totalrows % $limit) != 0)
        	{ 
        	if($i == $page)
        		{ 
        		echo "$i";
        		echo "&nbsp;";
        		echo "\n";
        		}
        	else 
        		{
        		echo "<a href=\"{$_SERVER['PHP_SELF']}?page=$i\">$i</a>&nbsp;";
        		echo "\n";
        		}
        	}
        		
        if(($totalrows - ($limit * $page)) > 0)
        	{
        	if(!$page)
    			{
    	       		$page = 1;
    			}  
        	$pagenext = $page + 1;
        	echo "<a href=\"{$_SERVER['PHP_SELF']}?page=$pagenext\">NEXT</a>";
        	echo "\n";  
    		}
    	else 
    		{
    		echo "&nbsp; NEXT ";
    		echo "\n";
    		}
    	}

function showSingle($id) 
		{
    		global $connection;
    
    		//query string
    		$query = "SELECT * FROM blogapp_posts WHERE id=$id";
    		
    		//store query result in a variable
    		$result = mysql_query($query);
    
    		//in case of error display friendly message
    		if (mysql_num_rows($result) == 0) 
    			{
        		echo "Bad news id";
        		echo "\n";
        		return;
    			}
    
    		$row = mysql_fetch_assoc($result);
    		
    		//define variables
     		$title = htmlentities ($row['title']);
    		$content = nl2br($row['content']);
    
    		//display
    		
   		echo "<div class=\"post-title\">";
   		echo "\n";
   		echo "$title";
   		echo "\n";
   		echo "</div>";
   		echo "\n";
    		echo "<div class=\"post-text\">";
    		echo "$content";
    		echo "\n";
    		echo "</div>";
    		echo "\n";
    
    		//display comments below single item
    		showComments($id);
		}

function showComments($id) 
		{
    		//variables
    		global $connection;
    
    		//query string
    		$query = "SELECT * FROM blogapp_comments WHERE post_id=$id";
    		
    		//store query result in a variable
    		$result = mysql_query($query);
    		
    		//begin display
    		echo "Comments:<br />";
    		echo "\n";
    
    		//loop to display comments
    		while ($row = mysql_fetch_assoc($result)) 
    			{
       			//define variables
       			$name = htmlentities ($row['name']);
        
        		echo "<div class=\"comment-author\">";
        		echo "\n";
        		echo "by: $name";
        		echo "\n";
        		echo "</div>";
        		echo "\n";
    
        		$comment = strip_tags ($row['comment'], '<a><b><i><u>');
       			$comment = nl2br ($comment);
        		echo "<div class=\"comment-text\">";
        		echo "\n";
        		echo "$comment";
        		echo "\n";
        		echo "</div>";
        		echo "\n";
                        }
    
    		//form to enter comments
    		echo "<form action=\"{$_SERVER['PHP_SELF']}?action=addcomment&amp;id=$id\" method=\"post\">";
    		echo "\n"; 
    		echo "<p>";
    		echo "\n";
    		echo "<b>name:</b>";
    		echo "\n";
    		echo "<br /><input type=\"text\" size=\"30\" name=\"name\" />";
    		echo "\n";
   		echo "<br /><textarea cols=\"40\" rows=\"5\" name=\"comment\"></textarea>";
   		echo "\n";
    		echo "<br /><input type=\"submit\" name=\"submit\" value=\"Add Comment\" />";
    		echo "\n";
    		echo "</p>";
    		echo "\n";
    		echo "</form>";
    		echo "\n";    
		}

function addComment($id) 
		{
    		global $connection;
    
    		//query string
    		$query = "INSERT INTO blogapp_comments VALUES('',$id,'{$_POST['name']}', '{$_POST['comment']}')";
    		mysql_query($query);
    		
    		//display friendly message    
    		echo "Comment entered. Thanks!<br />";
    		echo "\n";
    		echo "<a href=\"{$_SERVER['PHP_SELF']}\">Back to main page</a>";
    		echo "\n";
		}

//switch between functions according to action passed along with URL

		switch($_GET['action']) 
			{    
    			case 'show':
        		showSingle($_GET['id']);
        		break;
    
    			case 'all':
        		showPosts(1);
        		break;
    
    			case 'addcomment':
        		addComment($_GET['id']);
        		break;
    
    			default:
        		showPosts();
			}
?>