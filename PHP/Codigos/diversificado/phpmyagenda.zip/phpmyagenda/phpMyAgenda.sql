# phpMyAdmin MySQL-Dump
# http://phpwizard.net/phpMyAdmin/
#
# Host: localhost Base de donn�es: phpmyagenda

# --------------------------------------------------------
#
# Structure de la table 'admin'
#

DROP TABLE IF EXISTS admin;
CREATE TABLE admin (
   id int(5) DEFAULT '0' NOT NULL auto_increment,
   user varchar(50) NOT NULL,
   pass varchar(50) NOT NULL,
   lang varchar(20) DEFAULT 'english' NOT NULL,
   active tinyint(2) DEFAULT '0' NOT NULL,
   lastlogin datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
   permissions varchar(20) DEFAULT '00011' NOT NULL,
   sid varchar(255) NOT NULL,
   addplace tinyint(2) DEFAULT '0' NOT NULL,
   placerights tinyint(2) DEFAULT '0' NOT NULL,
   placeautoupdate tinyint(2) DEFAULT '0' NOT NULL,
   PRIMARY KEY (id),
   KEY id (id),
   UNIQUE id_2 (id)
);

#
# Contenu de la table 'admin'
#

INSERT INTO admin VALUES ( '3', 'write', 'efb2a684e4afb7d55e6147fbe5a332ee', 'english', '1', '2001-08-27 23:21:19', '022', '', '1', '2', '1');
INSERT INTO admin VALUES ( '4', 'admin', '1a1dc91c907325c69271ddf0c944bc72', 'francais', '1', '2001-09-19 21:54:30', '122', 'c3ab456b36dd2d9ef6cf3ed6b1b1ba95', '0', '2', '1');

# --------------------------------------------------------
#
# Structure de la table 'contacts'
#

DROP TABLE IF EXISTS contacts;
CREATE TABLE contacts (
   id int(5) DEFAULT '0' NOT NULL auto_increment,
   name varchar(100) NOT NULL,
   email varchar(100) NOT NULL,
   url smallint(5) DEFAULT '0' NOT NULL,
   phone varchar(100) NOT NULL,
   fax varchar(100) NOT NULL,
   address varchar(255) NOT NULL,
   town varchar(100) NOT NULL,
   zipcode varchar(20) NOT NULL,
   country varchar(50) NOT NULL,
   valid tinyint(1) DEFAULT '0' NOT NULL,
   name1 varchar(50) NOT NULL,
   name2 varchar(50) NOT NULL,
   name3 varchar(50) NOT NULL,
   name4 varchar(50) NOT NULL,
   name5 varchar(50) NOT NULL,
   surname1 varchar(20) NOT NULL,
   surname2 varchar(20) NOT NULL,
   surname3 varchar(20) NOT NULL,
   surname4 varchar(20) NOT NULL,
   surname5 varchar(20) NOT NULL,
   function1 varchar(20) NOT NULL,
   function2 varchar(20) NOT NULL,
   function3 varchar(20) NOT NULL,
   function4 varchar(20) NOT NULL,
   function5 varchar(20) NOT NULL,
   email1 varchar(255) NOT NULL,
   email2 varchar(255) NOT NULL,
   email3 varchar(255) NOT NULL,
   email4 varchar(255) NOT NULL,
   email5 varchar(255) NOT NULL,
   phone1 varchar(20) NOT NULL,
   phone2 varchar(20) NOT NULL,
   phone3 varchar(20) NOT NULL,
   phone4 varchar(20) NOT NULL,
   phone5 varchar(20) NOT NULL,
   fax1 varchar(20) NOT NULL,
   fax2 varchar(20) NOT NULL,
   fax3 varchar(20) NOT NULL,
   fax4 varchar(20) NOT NULL,
   fax5 varchar(20) NOT NULL,
   owner int(5) DEFAULT '0' NOT NULL,
   PRIMARY KEY (id),
   KEY id (id),
   UNIQUE id_2 (id),
   KEY contacturl (url)
);

# --------------------------------------------------------
#
# Structure de la table 'date'
#

DROP TABLE IF EXISTS date;
CREATE TABLE date (
   id int(5) DEFAULT '0' NOT NULL auto_increment,
   start datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
   end datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
   event smallint(5) DEFAULT '1' NOT NULL,
   place smallint(5) DEFAULT '1' NOT NULL,
   valid tinyint(1) DEFAULT '0' NOT NULL,
   owner int(5) DEFAULT '0' NOT NULL,
   PRIMARY KEY (id),
   KEY id (id),
   UNIQUE id_2 (id)
);

# --------------------------------------------------------
#
# Structure de la table 'events'
#

DROP TABLE IF EXISTS events;
CREATE TABLE events (
   id int(5) DEFAULT '0' NOT NULL auto_increment,
   title varchar(255) NOT NULL,
   description text NOT NULL,
   url smallint(5) DEFAULT '0' NOT NULL,
   type smallint(5) DEFAULT '0' NOT NULL,
   contact1 smallint(5) DEFAULT '0' NOT NULL,
   contact2 smallint(5) DEFAULT '0' NOT NULL,
   contact3 smallint(5) DEFAULT '0' NOT NULL,
   contact4 smallint(5) DEFAULT '0' NOT NULL,
   contact5 smallint(5) DEFAULT '0' NOT NULL,
   valid smallint(5) DEFAULT '0' NOT NULL,
   owner int(5) DEFAULT '0' NOT NULL,
   image varchar(255) NOT NULL,
   KEY id (id),
   UNIQUE id_2 (id),
   PRIMARY KEY (id),
   KEY referer (contact1)
);

# --------------------------------------------------------
#
# Structure de la table 'eventtype'
#

DROP TABLE IF EXISTS eventtype;
CREATE TABLE eventtype (
   id smallint(5) DEFAULT '0' NOT NULL auto_increment,
   type varchar(50) NOT NULL,
   type_en varchar(50) NOT NULL,
   owner int(5) DEFAULT '0' NOT NULL,
   PRIMARY KEY (id),
   KEY id (id),
   UNIQUE id_2 (id)
);

# --------------------------------------------------------
#
# Structure de la table 'place'
#

DROP TABLE IF EXISTS place;
CREATE TABLE place (
   id int(5) DEFAULT '0' NOT NULL auto_increment,
   name varchar(100) NOT NULL,
   address varchar(255) NOT NULL,
   town varchar(100) NOT NULL,
   zipcode varchar(20) NOT NULL,
   country varchar(50) NOT NULL,
   contact1 smallint(5) DEFAULT '0' NOT NULL,
   url smallint(5) DEFAULT '0' NOT NULL,
   phone varchar(100) NOT NULL,
   fax varchar(100) NOT NULL,
   valid tinyint(1) DEFAULT '0' NOT NULL,
   contact2 smallint(5) DEFAULT '0' NOT NULL,
   contact3 smallint(5) DEFAULT '0' NOT NULL,
   contact4 smallint(5) DEFAULT '0' NOT NULL,
   contact5 smallint(5) DEFAULT '0' NOT NULL,
   owner int(5) DEFAULT '0' NOT NULL,
   PRIMARY KEY (id),
   KEY id (id),
   UNIQUE id_2 (id),
   KEY url (url)
);

# --------------------------------------------------------
#
# Structure de la table 'placerights'
#

DROP TABLE IF EXISTS placerights;
CREATE TABLE placerights (
   id int(11) DEFAULT '0' NOT NULL auto_increment,
   userid int(11) DEFAULT '0' NOT NULL,
   placeid int(11) DEFAULT '0' NOT NULL,
   PRIMARY KEY (id, userid),
   KEY userid (userid)
);

# --------------------------------------------------------
#
# Structure de la table 'url'
#

DROP TABLE IF EXISTS url;
CREATE TABLE url (
   id int(5) DEFAULT '0' NOT NULL auto_increment,
   url varchar(255) NOT NULL,
   owner int(5) DEFAULT '0' NOT NULL,
   PRIMARY KEY (id),
   KEY id (id),
   UNIQUE id_2 (id)
);

