<?php
include("settings.php");
if(isset($login)){
    $query=mysql_query("SELECT * FROM $tb_user WHERE id='$user'") or die(mysql_error());

    while($array = mysql_fetch_array($query,MYSQL_ASSOC)) {
        $session["password"]=$array["password"];
        $session["aid"]=$array["id"];
    }

    if(empty($session["user"])){
        header("Location: login.php?error=1");
    }

    if($pwd==$session["password"]){

        @session_start();
        session_register("aid","password");
        $aid=$session["aid"];
        $password=$pwd;

        header("Location: index.php");

        exit;

    } else {
        header("Location: login.php?error=2");
        exit;
    }
}

if(isset($error)) {

    if($error==1){
        echo "<p>Login Failed<br>Wrong Username";
    }
    if($error==2){
        echo "<p>Login Failed<br>Wrong Password";
    }

}

$body = <<<EOV
<form method=post>
<p>Username: <input class=box type="text" name="user">
<br>Password: <input class=box type="password" name="pwd">
<br><input class=box type="submit" name="login" value="Login">
</p>
<p>Can't remember your password? You're out of luck until I write the send-you-your-passwork script.</p>
</form>
EOV;

include("inc.template.php");
?>
