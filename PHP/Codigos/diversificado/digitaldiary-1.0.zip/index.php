<?php
session_start();
include("settings.php");

$user_query=mysql_query("SELECT * FROM $tb_user") or die(mysql_error());
while($array = mysql_fetch_array($user_query,MYSQL_ASSOC)) {
    $id=$array["user"];
    $$id=$array["email"];
}
$query=mysql_query("SELECT * FROM $tb_entries ORDER BY id DESC LIMIT $limit") or die(mysql_error());
while($row = mysql_fetch_array($query)) {
    $j = mysql_num_fields($query);
    for($i=0;$i<$j;$i++) {
        $k = mysql_field_name($query,$i);
        $$k = $row[$k];
    }
  if ((($uid == "$aid") & ($secid == "private")) || ($secid != "private")) {
    $entry=substr(stripslashes($entry), 0, 200);
    if($foo!=$date){
        print("<center><font class=\"title\">$day, $date</font></center><BR>\n");
        $foo=$date;
    }
    $email=$$uid;
    if ($title != "") {
        $previous .= "$title - ";
    }
    $previous .= "$entry ...<BR>\n";
    $count=mysql_query("SELECT id FROM $tb_comments WHERE eid = '$id'") or die(mysql_error());
    $count=mysql_num_rows($count);
    if($count=="0") {
        $comment="Post Comment";
    }
    if($count=="1"){
        $comment="1 Comment";
    }
    if($count>"1"){
        $comment=$count." Comments";
    }
    $previous .= "<font class=\"footerentry\">posted by <a href=\"view.php?user=$uid\">$uid</a> | <a href=\"comments.php?id=$id\">$comment</a></font><BR><BR>\n";
  }
}
$body = "<p class=\"medHead\">The Last Few Entries</p>$previous";
include("inc.template.php");
?>

