<?php
if (isset($aid)) {
$content = <<<EOV
    <p>Hello, $aid!</p>
    <p><b>Your Diary</b><br>
    <a href="view.php">View</a><br>
    <a href="update.php">Write</a><br>
    <p><b>Your Settings</b><br>
    <a href="user.php?user=$aid">User Info</a><br>
    <a href="config.php">Preferences</a><br>
    Password
    </p>
    <p><b>Misceallenous</b><br>
    <a href="user.php">User Lookup</a><br>
    <p><a href="logout.php">Logout</a></p>
EOV;
} else {
    $content = <<<EOV
    <p class="smallHead">Welcome!</p>
    <a href="login.php">Login</a><br>
    <a href="create.php">Create a Diary</a><br>
    <!--<form action="login.php" method=post>
      Username<br>
      <input class=box type=text name=name size=12><br>
      Password<br>
      <input class=box type=password name=pwd size=12><br>
      <input class=box type=submit name=login value="Login">
    </form>-->
    <p><b>Misceallenous</b><br>
    <a href="user.php">User Lookup</a><br>

EOV;
}
echo $content;
?>
