<?php
session_start();
include("settings.php");

if (!isset($id)) {
  echo "This script cannot be called by itself.";
  //exit;
} else {
  $eid = "$id";
}

//if (!isset($aid)) {
//    echo "You must be <a href=\"login.php\">logged in</a> to update your journal.";
//    header("Location: login.php");
//    exit;
//}

if (isset($update)) {
    if ($aid == "") {
        $aid = "Anonymous";
    }
    $time = time();
    mysql_query("INSERT INTO $tb_comments VALUES('','$aid','$eid','$time','$entry','$REMOTE_ADDR')") or die(mysql_error());
    $body = "Done.";
    //header("Location: ");
} else {
    /* Get the original entry. */
    $query = mysql_query("SELECT * FROM $tb_entries WHERE id='$eid'") or die(mysql_error());
  if ((($uid == "$aid") & ($secid == "private")) || ($secid != "private")) {
    while($row = mysql_fetch_array($query)) {  
        $j = mysql_num_fields($query);
        for($i=0; $i<$j; $i++) {
            $k = mysql_field_name($query,$i);   
            $$k = $row[$k];
        }           

        $entry = nl2br(stripslashes($entry));  
        $timestamp = date("F j, Y, g:i a",$time);

    $query = mysql_query("SELECT sec_name, fn, mn, ln FROM $tb_user WHERE id='$uid'") or die(mysql_error());
    while ($row = mysql_fetch_array($query)) {
        $j = mysql_num_fields($query);
        for($i=0; $i<$j; $i++) {
            $k = mysql_field_name($query,$i);   
            $$k = $row[$k];
        }           

    }

    $name = "<a href=\"user.php?user=$uid\">";
    if ($sec_name == "Yes") {
      if ($mn != "") {
        $name .= "$fn $mn $ln";
      } else {
        $name .= "$fn $ln";
      }
    } else {
      $name .= "$uid";
    }
    $name .= "</a>";
    if ($mood != "") { $environment = "Mood: $mood"; }
    if (($music != "") & ($mood != "")) {
      $environment .= "<br>Music: $music";
    } elseif ($music != "") {
      $environment .= "Music: $music";
    }
$original = <<<EOV
    <p class="medHead">Read & Write Comments</p>
    <p>$name wrote on $timestamp...</p>
    <table width="100%">
      <tr>
        <td><b>$title</b></td>
        <td align="right">$timestamp</td>
      </tr>
      <tr>
        <td colspan="2"><p class="smallHead">$environment</p>$entry</td>
      </tr>
      <tr><td colspan="2"><hr></td></tr>
    </table>
EOV;
    }

    /* Get all the comments */
    $query = mysql_query("SELECT * FROM $tb_comments WHERE eid='$id' ORDER BY id") or die(mysql_error());
    while($row = mysql_fetch_array($query)) {  
        $j = mysql_num_fields($query);
        for($i=0; $i<$j; $i++) {
            $k = mysql_field_name($query,$i);   
            $$k = $row[$k];
        }           
        $entry = nl2br(stripslashes($entry));  
        $timestamp = date("F j, Y, g:i a",$time);
        if (($who != "Anonymous") & ($aid != "Anonymous") & ($uid != "Anonymous")) {
            $who = "<a href=\"user.php?user=$uid\">$uid</a>";
        } else {
            $who = "$uid";
        } 
$comment = <<<EOV
      <tr>
        <td>Comment ID $id</td>
        <td align="right">$timestamp</td>
      </tr>
      <tr>
        <td colspan="2"><span class="entry">$entry</span></td>
      </tr>
      <tr>
        <td align="right" colspan="2">$who</td>
      </tr>
      <tr>
        <td align="center" colspan="2"><hr width="50%"></td>
      </tr>
EOV;
        $comments .= "$comment";
    }

    /* check for user, anonymous, etc? */
    /* Get user preferences. */
    $query = mysql_query("SELECT * FROM $tb_user WHERE id='$uid'") or die(mysql_error());
    while ($row = mysql_fetch_array($query)) {
        $j = mysql_num_fields($query);
        for($i=0; $i<$j; $i++) {
            $k = mysql_field_name($query,$i);   
            $$k = $row[$k];
        }           

    }

$formtemplate = <<<EOV
              <P><b>Comments:</b><br />
                <textarea class="box" name="entry" cols="50" rows="10" wrap="soft" style="width: 70%"></textarea>
                <BR>
                <span style="color:#909090;">(HTML okay; by default, newlines 
                will be auto-formatted to <TT>&lt;BR&gt;</TT>)</span>
              <INPUT class="box" TYPE=SUBMIT VALUE="Submit Comments" name="update">
EOV;

    if ($nocomments == "1") {
      $body = "<p>Comments have been disabled for this entry by the author.</p>";
    } elseif ($sec_comments == "Nobody") {
      $body = "<p>The author's preferences do not allow commenting.</p>";
    } else {
      if (($sec_comments == "Users") & (!isset($aid) || ($aid == "Anonymous") )) {
        $body = "<p><font color=red>ERROR</font>: You must be logged in to comment on this entry.</p>";
      } elseif ((($sec_comments == "Users") || ($sec_comments == "Anyone")) & (isset($aid))) {
        $user = "$aid";
        $form = "$formtemplate";
        $warning = "<p><b>$aid</b> is logged in and allowed to comment.</p>";
      } elseif ($sec_comments == "Anyone") {
        $user = "Anonymous";
        $warning = "<p>You are not <a href=\"login.php\">logged in</a>. Post will be anonymous, logged to $REMOTE_ADDR.</p>";
        $form = "$formtemplate";
      } else {
        $form = "$formtemplate";
      }
$body .= <<<EOV
        $original
	<table width="90%" align="center">
        $comments
	</table>

    <form method=post name=updateForm>
      <input type=hidden name=id value="$eid">
      <input type=hidden name=uid value="$aid">
        $warning
        $form
     </form>
EOV;

    }    
  } else {
    $body = "This entry has been marked <b>private</b> by the author.";
  }
}
include("inc.template.php");
?>

