<?php

$mysqlhost="localhost";
$mysqldb="journal";
$mysqluser="journal";
$mysqlpwd="journal";

$tb_entries="entries";
$tb_comments="comments";
$tb_user="users";

$stitle="Digital Diary 1.0";
$limit="6";

// END OF VARIABLES... Leave the rest of it alone
// unless you know what you're doing.

/* get the microtime - basic */
function getmicrotime()
{
    list($usec, $sec) = explode(" ",microtime());
    return ((float)$usec + (float)$sec);
}

$time_start = getmicrotime();

$conn = mysql_connect($mysqlhost, $mysqluser, $mysqlpwd) or die(mysql_error());
mysql_select_db($mysqldb, $conn) or die(mysql_error());
?>
