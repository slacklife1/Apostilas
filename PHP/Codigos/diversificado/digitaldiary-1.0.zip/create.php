<?php
include("settings.php");

function verifyname($name) {
  if (ereg("^[A-Za-z0-9]+$","$name")) {
    $length = strlen($name);
    if (($length < 20) & ($length > 4)) {
      $name = strtolower(str_replace(" ","",$name));
    } else {
      $error = "Name must be between 4 and 20 characters.";
    } 
  } else {
    $error = "Invalid username. Only alphanumeric characters.";
  }
  $result["error"] = $error;
  $result["name"] = $name;
  return $result;
}

if ((isset($aid,$fn,$ln,$gender,$month,$day,$year,$email,$password,$password2)) & ($year != "19")) {
    $result = (verifyname($aid));

    if ($result["error"] == "") {
      $aid = $result["name"];
      $query = mysql_query("SELECT * FROM $tb_user WHERE id='$aid'") or die(mysql_error());
      $member = mysql_fetch_array($query);
      if ($member[id] == "$aid") {
        $body = "The name <b>$aid</b> is already in use. Pick another name.";
      } else {
        if($password != $password2) {
          $body = "Passwords do not match. Re-enter and try again. <br><a href=\"javscript:go.history(-1);\">Back</a>";
        } else {
          if (strlen($password) < 5) {
            $body = "Password too short.";
          } else {
            $created = time();
            mysql_query("INSERT INTO $tb_user VALUES('$aid','$fn','$mn','$ln','$city','$region','$country','$gender','$month','$day','$year','$www','$wwwname','$aim','$icq','$yim','$msn','$about','$sec_locality','$sec_gender','$sec_email','$sec_age','$sec_name','$sec_comments','$password','$email','$status','$created')") or die(mysql_error());
            $body = "<b>$aid</b> added to the database. Go login!";
          }
        }
      }
   } else {
     $body = $result["error"];
   }
} else {
   if (isset($submit)) {
     $notice = "<p class=\"medHead\">Please fill in ALL the required fields.<p>";
   }
$body = <<<EOV
   <p class="medHead">Creating A New Account</p>
   <p>PHP Testers! If you choose to create test accounts, PLEASE <a href="demo/">do it in the demo version</a>.</p>
   <p>Inactive diaries will be purged after three (3) months.</p>
$notice
<p><b>Bold</b> items are required.</p>
<p>Pick your username. Names will be converted to lowercase. Letters and numbers only, please.</p>

<table border="0" cellspacing="0" cellpadding="0">
  <tr>
      <td><form name="step1" method="post"><b>User ID</b> 
  <input class="boxHi2" type="text" name="aid">

  <p class="smallHead">Basic Information</p>
  <p>Information will be displayed based on the privacy preferences that you select below.</p>
        <table border="0" cellspacing="1" cellpadding="1" width="100%">
          <tr> 
            <td align="right" width="30%"><b>First</b>:</td>
            <td width="70%"> 
              <input class="boxHi2" type="text" name="fn">
      </td>
    </tr>
    <tr> 
            <td align="right" width="30%">Middle:</td>
            <td width="70%"> 
              <input class="box" type="text" name="mn">
      </td>
    </tr>
    <tr> 
            <td align="right" width="30%"><b>Last</b>:</td>
            <td width="70%"> 
              <input class="boxHi2" type="text" name="ln">
      </td>
    </tr>
    <tr> 
            <td align="right" width="30%">City:</td>
            <td width="70%"> 
              <input class="box" type="text" name="city">
      </td>
    </tr>
    <tr> 
            <td align="right" width="30%">State/Region:</td>
            <td width="70%"> 
              <input class="box" type="text" name="region"> No abbreviations, please.
      </td>
    </tr>
    <tr> 
            <td align="right" width="30%">Country:</td>
            <td width="70%"> 
              <input class="box" type="text" name="country">
      </td>
    </tr>
    <tr> 
            <td align="right" width="30%"><b>Gender</b>:</td>
            <td width="70%"> 
              <select class="boxHi2" name="gender">
          <option selected>Male</option>
          <option>Female</option>
        </select>
      </td>
    </tr>
    <tr> 
            <td align="right" width="30%"><b>Birthday</b>:</td>
            <td width="70%"> 
              <select class="boxHi2" name="month">
          <option value="1" selected>January</option>
          <option value="2">February</option>
          <option value="3">March</option>
          <option value="4">April</option>
          <option value="5">May</option>
          <option value="6">June</option>
          <option value="7">July</option>
          <option value="8">August</option>
          <option value="9">September</option>
          <option value="10">October</option>
          <option value="11">November</option>
          <option value="12">December</option>
        </select>
        <select class="boxHi2" name="day">
          <option selected>1</option>
          <option>2</option>
          <option>3</option>
          <option>4</option>
          <option>5</option>
          <option>6</option>
          <option>7</option>
          <option>8</option>
          <option>9</option>
          <option>10</option>
          <option>11</option>
          <option>12</option>
          <option>13</option>
          <option>14</option>
          <option>15</option>
          <option>16</option>
          <option>17</option>
          <option>18</option>
          <option>19</option>
          <option>20</option>
          <option>21</option>
          <option>22</option>
          <option>23</option>
          <option>24</option>
          <option>25</option>
          <option>26</option>
          <option>27</option>
          <option>28</option>
          <option>29</option>
          <option>30</option>
          <option>31</option>
        </select>
        , 
        <input class="boxHi2" type="text" name="year" size="8" maxlength="4" value="19">
      </td>
    </tr>
    <tr> 
            <td align="right" width="30%"><b>Email</b>:</td>
            <td width="70%"> 
              <input class="boxHi2" type="text" name="email">
      </td>
    </tr>
    <tr> 
            <td align="right" width="30%"><b>Password</b>:</td>
            <td width="70%"> 
              <input class="boxHi2" type="password" name="password">
      </td>
    </tr>
    <tr> 
            <td align="right" width="30%"><b>Verify</b>:</td>
            <td width="70%"> 
              <input class="boxHi2" type="password" name="password2">
      </td>
    </tr>
  </table>
  <p class="smallHead">More Information</p>
     <p>Leave unnecessary fields <b>blank</b>.</p>
        <table width="100%">
        <tr>
          <td width="30%" align="right">Webpage URL:</td>
          <td width="70%">
            <input class="box" type="text" name="www" value="$www">
          </td>
        </tr>
        <tr>
          <td width="30%" align="right">Webpage Name:</td>
          <td width="70%">
            <input class="box" type="text" name="wwwname" value="$wwwname">
          </td>
        </tr>
          <tr> 
            <td align="right" width="30%">AIM:</td>
            <td width="70%"> 
              <input class="box" type="text" name="aim">
      </td>
    </tr>
    <tr> 
            <td align="right" width="30%">ICQ:</td>
            <td width="70%"> 
              <input class="box" type="text" name="icq">
      </td>
    </tr>
    <tr> 
            <td align="right" width="30%">YIM:</td>
            <td width="70%"> 
              <input class="box" type="text" name="yim">
      </td>
    </tr>
    <tr> 
            <td align="right" width="30%">MSN:</td>
            <td width="70%"> 
              <input class="box" type="text" name="msn">
      </td>
    </tr>
  </table>
  <p class="smallHead">Privacy Preferences</p>
  <p>By default, the least amount of information is shared.</p>
        <table border="0" cellspacing="1" cellpadding="1" width="100%">
          <tr> 
            <td width="70%">Display your locality?</td>
            <td width="30%"> 
              <select class="boxHi2" name="sec_locality">
                <option>Yes</option>
                <option selected>No</option>
              </select>
            </td>
          </tr>
          <tr> 
            <td width="70%">Display your gender?</td>
            <td width="30%"> 
              <select class="boxHi2" name="sec_gender">
                <option>Yes</option>
                <option selected>No</option>
              </select>
            </td>
          </tr>
          <tr> 
            <td width="70%">Display your email address? </td>
            <td width="30%"> 
              <select class="boxHi2" name="sec_email">
                <option>Yes</option>
                <option selected>No</option>
              </select>
            </td>
          </tr>
          <tr> 
            <td width="70%">Display your age? </td>
            <td width="30%"> 
              <select class="boxHi2" name="sec_age">
                <option>Yes</option>
                <option selected>No</option>
              </select>
            </td>
          </tr>
          <tr> 
            <td width="70%">Display your name?</td>
            <td width="30%"> 
              <select class="boxHi2" name="sec_name">
                <option>Yes</option>
                <option selected>No</option>
              </select>
            </td>
          </tr>
          <tr>
            <td width="70%">Who can comment on your entries?</td>
            <td width="30%"> 
              <select class="boxHi2" name="sec_comments">
                <option>Anyone</option>
                <option selected>Users</option>
                <option>Nobody</option>
              </select>
            </td>
          </tr>
        </table>
        <p class="smallHead">About You</p>
  <p>A simple profile. Free-form, anything goes.</p>
  <p>
    <textarea class="box" name="about" cols="80" rows="6" wrap="VIRTUAL"></textarea>
  </p>

  <input class="box" type="submit" name="submit" value="Create Account">
</form>	</td>
    </tr>
  </table>
  
EOV;
}
include("inc.template.php");

?>
