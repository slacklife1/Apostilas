<?php
session_start();
include("settings.php");
if (!isset($aid)) {
    $body = "You must be <a href=\"login.php\">logged in</a> to update your journal.";
    include("inc.template.php");
    exit;
}
if (isset($update)) {
  $time = mktime($hour,$minute,0,$month,$day,$year);
  mysql_query("INSERT INTO $tb_entries VALUES('','$aid','$time','$title','$entry','$secid','$mood','$music','$nocomment')") or die(mysql_error());
  $body = "Updated.";
  //header("Location: ");
} elseif (isset($modify)) {
  if ($notime == "1") {
    mysql_query("UPDATE $tb_entries SET title='$title', entry='$entry', secid='$secid', mood='$mood', music='$music' WHERE id=$modify'") or die(mysql_error());
  } else {
    mysql_query("UPDATE $tb_entries SET time='$time', title='$title', entry='$entry', secid='$secid', mood='$mood', music='$music' WHERE id=$modify'") or die(mysql_error());
  }
    header("Location: view.php");
} else {

$inid = "$id";
$query = mysql_query("SELECT * FROM $tb_entries WHERE id='$id'") or die(mysql_error());
while($row = mysql_fetch_array($query)) {  
    $j = mysql_num_fields($query);
    for($i=0; $i<$j; $i++) {
        $k = mysql_field_name($query,$i);   
        $$k = $row[$k];
    }
}

if (isset($inid) & ($aid == "$uid")) {
  $body = "Mine, bitch!";
  $modify = "<input type=hidden name=modify value=$id><input type=hidden name=uid value=$uid>Don't update time: <input type=checkbox name=notime value=1> (useful if only updating security level)";
  if ($nocomments == "1") { $ncstatus = "checked"; }
  if ($secid == "public") { $secpub = "selected"; }
  if ($secid == "private") { $secpri = "selected"; }
  if ($secid == "friends") { $secfri = "selected"; }
} else {
  $body = "This isn't your entry to update.";
}

$onload = " onLoad=\"settime();\"";
$body = <<<EOV
    <form method=post name=updateForm>
      <TABLE width="295">
        <tr valign=TOP> 
          <td align=RIGHT rowspan=2>Date:&nbsp;</td>
          <td NOWRAP> 
            <input class="box" name=year size=5 maxlength=4>
            - 
            <input class="box" name=month size=3 maxlength=2>
            - 
            <input class="box" name=day size=3 maxlength=2>
          </td>
        </tr>
        <tr> 
          <td><i>(yyyy-mm-dd)</i></td>
        </tr>
        <tr valign=TOP> 
          <td align=RIGHT rowspan=2>Local time:&nbsp;</td>
          <td> 
            <input class="box" name=hour size=3 maxlength=2>
            : 
            <input class="box" name=minute size=3 maxlength=2>
          </td>
        </tr>
        <tr> 
          <td><i>(24 hour time)</i></td>
        </tr>
      </TABLE>
      <UL>
        <TABLE width=90%>
          <TR> 
            <TD>Subject: <I>(optional, for use on longer entries)</I><BR>
              <INPUT class="box" NAME="title" SIZE=50 MAXLENGTH=100 VALUE="$title">
              <P><b>Event:</b><br />
                <textarea class="box" name="entry" cols="50" rows="10" wrap="soft" style="width: 99%">$entry</textarea>
                <BR>
                <span style="color:#909090;">(HTML okay; by default, newlines 
                will be auto-formatted to <TT>&lt;BR&gt;</TT>)</span>
            </TD>
          </TR>
          <TR> 
            <TD ALIGN=CENTER> 
              <INPUT class="box" TYPE=SUBMIT VALUE="Update Journal" name="update">
            </TD>
          </TR>
          <TR> 
            <TD NOWRAP> 
              <P><span class="smallHead">Optional Settings</span>
      <p>$modify</p>
              <P>Security Level: 
                <select class="box" name='secid'>
                  <option value="public" $secpub>Public</option>
                  <option value="private" $secpri>Private</option>
                  <option value="friends" $secfri>Friends</option>
                </select> Who is allowed to <b>view</b> this entry. Friends doesn't work currently.</p>
<p class="light"><b><font color="red">NOTE:</font> If you are testing out this script</b>, please edit your entries after you're done
<br>and mark them as private. It keeps the front page less cluttered. Thanks for checking it out!</p>
              <P>Disallow Comments: 
                <INPUT TYPE=CHECKBOX NAME="nocomments" VALUE=1 $ncstatus>
              
              <P>Current Mood: 
                <INPUT class="box" NAME="mood" SIZE=15 MAXLENGTH=30 VALUE="$mood">
              <P>Current Music: 
                <INPUT class="box" NAME="music" SIZE=40 MAXLENGTH=60 VALUE="$music">
            </TD>
          </TR>
          <TR> 
            <TD ALIGN=CENTER> 
              <INPUT class="box" TYPE=SUBMIT VALUE="Update Journal" name="update">
            </TD>
          </TR>
        </TABLE>
      </UL>
    </FORM><SCRIPT LANGUAGE="JavaScript"><!--
        // for those of you reading the source.... the server will
        // automatically fill in the form with the time values for
        // the west coast, but what this does is if the client can
        // use JavaScript (nearly 99% of the time nowadays), we'll
        // prefill the time in from their computer's clock
function settime() {
        function twodigit (n) {
                if (n < 10) { return "0" + n; }
                else { return n; }
        }

        now = new Date();
        f = document.updateForm;
        f.year.value = now.getYear() < 1900 ? now.getYear() + 1900 : now.getYear();
        f.month.value = twodigit(now.getMonth()+1);
        f.day.value = twodigit(now.getDate());
        f.hour.value = twodigit(now.getHours());
        f.minute.value = twodigit(now.getMinutes());
}

// --></SCRIPT>
EOV;
}
include("inc.template.php");

?>

