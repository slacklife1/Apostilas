<?php
session_start();
include("settings.php");

if (!isset($user)) {
    $user = "$aid";
}

//$user_query=mysql_query("SELECT * FROM $tb_user WHERE id='$user'") or die(mysql_error());
//while($array = mysql_fetch_array($user_query,MYSQL_ASSOC)) {
//    $id=$array["user"];
//    $$id=$array["email"];
//}

$body .= "<p class=\"medHead\"><a href=\"user.php?user=$user\">$user</a>'s Digital Diary Entries</p>";

$query = mysql_query("SELECT * FROM $tb_entries WHERE uid='$user' ORDER BY id DESC") or die(mysql_error());
//$query = mysql_query("SELECT * FROM $tb_entries WHERE uid='$user' ORDER BY id DESC LIMIT $limit") or die(mysql_error());
while($row = mysql_fetch_array($query)) {  
    $j = mysql_num_fields($query);
    for($i=0; $i<$j; $i++) {
        $k = mysql_field_name($query,$i);   
        $$k = $row[$k];
    }           
    $entry = nl2br(stripslashes($entry));  
    $timestamp = date("F j, Y, g:i a",$time);

  if ((($uid == "$aid") & ($secid == "private")) || ($secid != "private")) {
   if ($nocomments != "1") {
    $count = mysql_query("SELECT id FROM $tb_comments WHERE eid = '$id'") or die(mysql_error());
    $count = mysql_num_rows($count);

    if ($count == "0") {
        $comment = "Post Comment";
    }
    if($count == "1") {
        $comment = "1 Comment";
    }
    if($count > 1) {
        $comment = $count . " Comments";
    }
    $bottom = "<a href=\"comments.php?id=$id\">$comment</a>";
   } else {
    $bottom = "";
   }
    if ($aid == "$user") {
        $bottom .= " | <a href=\"update.php?id=$id\">Edit</a>";
        //$bottom .= " | <font color=\"silver\">Edit</font>";
        if ($secid == "private") {
            $bottom .= " | Private";
        }
    }

    if ($mood != "") { $mood = "Mood: $mood"; }
    if ($music != "") { $music = "Music: $music"; }
    if (($mood != "") & ($music != "")) { $mood = $mood . "<br>"; }
   
$body .= <<<EOV
<table width="100%">
<tr>
<td class="medHead">$title</td>
<td align="right">$timestamp</td>
</tr>
<tr>
<td colspan="2">
<p class="smallHead">$mood$music</p>
$entry
</td>
</tr>
<tr>
<td colspan="2">
<p align="right" class="smallHead">$bottom</p>
</td>
</tr>
</table>
<hr>
EOV;
  }
}
include("inc.template.php");
?>
