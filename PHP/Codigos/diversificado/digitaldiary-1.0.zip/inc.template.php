
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
<title><?php echo $stitle; ?></title>
<style type="text/css">
td,body { font: 11px Tahoma, Verdana,  Arial; }
th { background-color: #eeeeee; }
.dlc { font: 11px  Tahoma, Verdana, Arial; font-weight: bold; }
.smallHead { font: 12px Tahoma, Verdana, Arial; font-weight: bold; }
.medHead { font: 14px Tahoma, Verdana, Arial; font-weight: bold; }
.largeHead { font: 18px Tahoma, Verdana, Arial; font-weight: bold; }
A:link, A:visited, A:active { color: rgb(182,82,84); text-decoration: none; } 
A:hover { text-decoration: underline overline; color: rgb(232,132,134); }
.light { background-color: #eeeeee; color: black; }
.dark { background-color: #cccccc; color: white; }
.box { background-color: #fdfdfd; font: 8pt Tahoma; border: 1px solid #bdbdbd; padding: 1px 1px 1px 1px; color: Black; scrollbar-face-color: #CCCCCC; scrollbar-shadow-color: #FFFFFF; scrollbar-highlight-color: #FFFFFF; scrollbar-3dlight-color: #FFFFFF; scrollbar-darkshadow-color: #FFFFFF; scrollbar-track-color: #FFFFFF; scrollbar-arrow-color: #000000; }
.boxHi { background-color: #ffffff; font: bold 8pt Tahoma; border: 2px solid red; padding: 2px 3px 1px 3px; color: Black; }
.boxHi2 { background-color: #ffffff; font: bold 8pt Tahoma; border: 2px solid #bdbdbd; padding: 2px 3px 1px 3px; color: Black; }
</style>
</head>

<body<?php echo $onload; ?>>
<TABLE cellspacing="3" cellpadding="3" border="0" width="100%">  
  <TR>
    <TD colspan="2" class="light"><span class="largeHead"><a href="index.php">Digital Diary</a> - Version 1.0</span></TD>
    </TR>
  <TR>
    <TD valign="top">
    <!-- Navigation START -->
    <?php include("inc.menu.php"); ?>
    <!-- Navigation END -->
    </TD>
    <TD valign="top" align="left">
    <!-- Body Content START -->
    <?php echo $body; ?>	
    <!-- Body Content END -->
    </TD>
  </TR>
  <TR>
    <TD colspan="2" class="light"><? echo "Traced to $REMOTE_ADDR, port $REMOTE_PORT. "; $time_end = getmicrotime(); $time = number_format(($time_end - $time_start),3);  echo "Rendered in $time seconds."; ?> Updated <? echo date("D M d \a\\t g:ia.", getlastmod()); ?><br>
Powered By <a href="http://gb.moundalexis.com/~alexm/dd.php">Digital Diary</a>.</TD>
    </TR></TABLE>
</body>
</html>
