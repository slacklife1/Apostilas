<?php
session_start();
include("settings.php");

if (!isset($aid)) {
    header("Location: login.php");
    exit;
}

$s = " selected";

if(isset($update)){
    mysql_query("UPDATE $tb_user SET fn='$fn', mn='$mn', ln='$ln', city='$city', region='$region', country='$country', gender='$gender', month='$month', day='$day', year='$year', www='$www', wwwname='$wwwname', aim='$aim', icq='$icq', yim='$yim', msn='$msn', about='$about', sec_locality='$sec_locality', sec_gender='$sec_gender', sec_email='$sec_email', sec_age='$sec_age', sec_name='$sec_name', sec_comments='$sec_comments', email='$email' WHERE id='$aid'") or die(mysql_error());
    header("Location: config.php");
} else {
    $query=mysql_query("SELECT * FROM $tb_user WHERE id='$aid'") or die(mysql_error());
    while($row = mysql_fetch_array($query)) {
        $j = mysql_num_fields($query);
        for($i=0;$i<$j;$i++) {
            $k = mysql_field_name($query,$i);
            $$k = $row[$k];
        }
        $about=stripslashes($about);
    }
    
    if ($gender=="Male") { $genderm="$s"; } else { $genderf="$s"; }
    if ($sec_locality=="Yes") { $q1y="$s"; } else { $q1n="$s"; }
    if ($sec_gender=="Yes") { $q2y="$s"; } else { $q2n="$s"; }
    if ($sec_email=="Yes") { $q3y="$s"; } else { $q3n="$s"; }
    if ($sec_age=="Yes") { $q4y="$s"; } else { $q4n="$s"; }
    if ($sec_name=="Yes") { $q5y="$s"; } else { $q5n="$s"; }
    if ($sec_comments=="Anyone") {
       $q6a="$s";
    } elseif ($sec_comments=="Users") { 
       $q6u="$s"; 
    } else { 
       $q6n="$s"; 
    }
$body = <<<EOV
<p class="medHead">Update Config</p>
<table cellspacing=0 cellpadding=0 border=0>
 <tr>
  <td valign="top" align="left">
  <form name="step1" method="post">
  <p><b>Bold</b> items are required.</p>
  <p class="medHead">Basic Information</p>
  
<p>Information is displayed based on your privacy preferences below.</p>
      <table border="0" cellspacing="1" cellpadding="1" width="100%">
<tr>
<td align="right" width="30%"><b>User ID:</td>
<td width="70%">$aid</td>
</tr>
        <tr> 
    <td align="right" width="30%"><b>First</b>:</td>
    <td width="70%"> 
      <input class="box" type="text" name="fn" value="$fn">
    </td>
  </tr>
  <tr> 
    <td align="right" width="30%">Middle:</td>
    <td width="70%"> 
      <input class="box" type="text" name="mn" value="$mn">
    </td>
  </tr>
  <tr> 
    <td align="right" width="30%"><b>Last</b>:</td>
    <td width="70%"> 
      <input class="box" type="text" name="ln" value="$ln">
    </td>
  </tr>
  <tr> 
    <td align="right" width="30%">City:</td>
    <td width="70%"> 
      <input class="box" type="text" name="city" value="$city">
    </td>
  </tr>
  <tr> 
    <td align="right" width="30%">State/Region:</td>
    <td width="70%"> 
      <input class="box" type="text" name="region" value="$region">
    </td>
  </tr>
  <tr> 
    <td align="right" width="30%">Country:</td>
    <td width="70%"> 
      <input class="box" type="text" name="country" value="$country">
    </td>
  </tr>
  <tr> 
    <td align="right" width="30%"><b>Gender</b>: </td>
    <td width="70%"> 
      <select class="box" name="gender"><option$genderm>Male
        <option$genderf>Female 
      </select>
    </td>
  </tr>
  <tr> 
    <td align="right" width="30%"><b>Birthday</b>:</td>
    <td width="70%"> 
      <input class="box" type="text" name="month" value="$month" maxlength="2" size="2">
      <input class="box" type="text" name="day" value="$day" maxlength="2" size="2">
      , 
      <input class="box" type="text" name="year" size="4" maxlength="4" value="$year">
      <i>Example: 02 05 1978</i> </td>
  </tr>
  <tr> 
    <td align="right" width="30%"><b>Email</b>:</td>
    <td width="70%"> 
      <input class="box" type="text" name="email" value="$email">
    </td>
  </tr>
</table>
<p class="medHead">More Information</p>
      <table width="100%" border="0" cellspacing="1" cellpadding="1">
        <tr> 
          <td width="30%" align="right">Webpage URL:</td>
          <td width="70%"> 
            <input class="box" type="text" name="www" value="$www">
          </td>
        </tr>
        <tr> 
          <td width="30%" align="right">Webpage Name:</td>
          <td width="70%"> 
            <input class="box" type="text" name="wwwname" value="$wwwname">
          </td>
        </tr>
        <tr> 
          <td width="30%" align="right">AIM:</td>
          <td width="70%"> 
            <input class="box" type="text" name="aim" value="$aim">
          </td>
        </tr>
        <tr> 
          <td width="30%" align="right">ICQ:</td>
          <td width="70%"> 
            <input class="box" type="text" name="icq" value="$icq">
          </td>
        </tr>
        <tr> 
          <td width="30%" align="right">YIM:</td>
          <td width="70%"> 
            <input class="box" type="text" name="yim" value="$yim">
          </td>
        </tr>
        <tr>
          <td width="30%" align="right">MSN:</td>
          <td width="70%"> 
            <input class="box" type="text" name="msn" value="$msn">
          </td>
        </tr>
      </table>
      <p class="medHead">Privacy Preferences</p>
<p>By default, the least amount of information is shared.</p>
      <table width="100%" border="0" cellspacing="1" cellpadding="1">
        <tr> 
          <td width="70%">Display your locality? </td>
          <td width="30%"> 
            <select class="box" name="sec_locality"><option$q1y>Yes
    <option$q1n>No 
            </select>
          </td>
        </tr>
        <tr> 
          <td width="70%">Display your gender?</td>
          <td width="30%"> 
            <select class="box" name="sec_gender"><option$q2y>Yes
    <option$q2n>No 
            </select>
          </td>
        </tr>
        <tr> 
          <td width="70%">Display your email address? </td>
          <td width="30%"> 
            <select class="box" name="sec_email"><option$q3y>Yes
    <option$q3n>No 
            </select>
          </td>
        </tr>
        <tr> 
          <td width="70%">Display your age? </td>
          <td width="30%"> 
            <select class="box" name="sec_age"><option$q4y>Yes
    <option$q4n>No 
            </select>
          </td>
        </tr>
        <tr> 
          <td width="70%">Display your name? </td>
          <td width="30%"> 
            <select class="box" name="sec_name"><option$q5y>Yes
    <option$q5n>No 
            </select>
          </td>
        </tr>
        <tr>
          <td width="70%">Who can comment on your entries?</td>
          <td width="30%"> 
            <select class="box" name="sec_comments"><option$q6a>Anyone
    <option$q6u>Users <option$q6n>Nobody 
            </select>
          </td>
        </tr>
      </table>
      <p class="medHead">About You</p>
      <p>A simple profile. Free-form, anything goes.</p>
  <p>
    <textarea class="box" name="about" cols="80" rows="6" wrap="VIRTUAL">$about</textarea>
  </p>
<input class="box" type="submit" name="update" value="Update">
</td>
</tr>
</table>
</form>
EOV;
include("inc.template.php");
}
?>
