<?php
session_start();
include("settings.php");

if (isset($user)) {

$query=mysql_query("SELECT * FROM $tb_user WHERE id='$user'") or die(mysql_error());
    while($row = mysql_fetch_array($query)) {
        $j = mysql_num_fields($query);
        for($i=0;$i<$j;$i++) {
            $k = mysql_field_name($query,$i);
            $$k = $row[$k];
        }
        $about=nl2br(stripslashes($about));
    }

/* Header */
$body = <<<EOV
<body bgcolor="#FFFFFF">
<p class="medHead">User Information</p>
<p>If you are this user, you can edit your information (or choose what information is considered public) at the <a href="config.php">Personal Settings</a> page.</p>
<table align="left" border="0" cellspacing="1" cellpadding="1">
EOV;

/* Pull user information. */
$user = $id;

/* Username */
$body .= <<<EOV
  <tr> 
    <td align="right" width="20%"><b>User:</b></td>
    <td width="80%"><a href="view.php?user=$user">$user</a></td>
  </tr>
EOV;

/* Name */
if ($sec_name == "Yes") {
  if ($mn != "") {
    $name = "$fn $mn $ln";
  } else {
    $name = "$fn $ln";
  }
$body .= <<<EOV
  <tr> 
    <td align="right" width="20%"><b>Name:</b></td>
    <td width="80%">$name</td>
  </tr>
EOV;
}

/* Website */
if ($www != "") {
  if ($wwwname != "") {
    $web = "<a href=\"$www\">$wwwname</a>";
  } else {
    $web = "<a href=\"$www\">$www</a>";
  }
$body .= <<<EOV
  <tr> 
    <td align="right" width="20%"><b>Website:</b></td>
    <td width="80%">$web</td>
  </tr>
EOV;
}

/* Location */
if ($sec_locality == "Yes") {
  $location = "$city $region $country";
$body .= <<<EOV
  <tr> 
    <td align="right" width="20%"><b>Location:</b></td>
    <td width="80%">$location</td>
  </tr>
EOV;
}

/* Birthday */
if ($sec_age == "Yes") {
  $dob = "$month/$day/$year";
} else {
  $dob = "$month/$day";
}
$body .= <<<EOV
  <tr> 
    <td align="right" width="20%"><b>Birthdate:</b></td>
    <td width="80%">$dob</td>
  </tr>
EOV;

/* Email */
if ($sec_email =="Yes") {
list($account,$domain) = split('@', $email);
$body .= <<<EOV
  <tr>
    <td align="right" width="20%"><b>Email:</b></td>
    <td width="80%">$account at $domain</td>
  </tr>
EOV;
}

/* AOL Instant Messenger */
if ($aim != "") {
$body .= <<<EOV
  <tr> 
    <td align="right" width="20%"><b>AIM:</b></td>
    <td width="80%">$aim (<a href="aim:addbuddy?screenname=$aim">Add Buddy</a>, 
      <a href="aim:goim?screenname=$aim&amp;message=Hello+there!.+How+are+you?">Send 
      Message</a>)</td>
  </tr>
EOV;
}

/* Mirabillis ICQ */
if ($icq != "") {
$body .= <<<EOV
  <tr> 
    <td align="right" width="20%"><b>ICQ:</b></td>
    <td width="80%"><img src="http://web.icq.com/whitepages/online?icq=$icq&amp;img=5" height='18' width='18'> 
      $icq (<a href="http://wwp.icq.com/scripts/search.dll?to=$icq">Add User</a>, 
      <a href="http://wwp.icq.com/scripts/contact.dll?msgto=$icq">Send Message</a>)</td>
  </tr>
EOV;
}

/* Yahoo Instant Messenger -- NOT IMPLEMENTED! */
if ($yim != "") {
$body .= <<<EOV
  <tr> 
    <td align="right" width="20%"><b>YIM:</b></td>
    <td width="80%">$yim</td>
  </tr>
EOV;
}

/* MSN Messenger -- NOT IMPLEMENTED! */
if ($msn != "") {
$body .= <<<EOV
  <tr> 
    <td align="right" width="20%"><b>MSN:</b></td>
    <td width="80%">$msn</td>
  </tr>
EOV;
}

/* About Biography */
if ($about != "") {
$body .= <<<EOV
  <tr> 
    <td align="right" width="20%" valign="top"><b>Bio:</b></td>
    <td width="80%">$about</td>
  </tr>
EOV;
}

/* If Mode = Full, Pull Some More Statistics */
if ($mode == "full") {

/* Creation Date */
$datecreation = date("F j, Y, g:i a",$created);

/* Date Last Updated */
$query = mysql_query("SELECT * FROM $tb_entries WHERE uid='$user' ORDER BY time DESC LIMIT 1") or die(mysql_error());
    while($row = mysql_fetch_array($query)) {
        $j = mysql_num_fields($query);
        for($i=0;$i<$j;$i++) {
            $k = mysql_field_name($query,$i);
            $$k = $row[$k];
        }
    }
$datemodified = date("F j, Y, g:i a",$time);

/* Number Of Entries */
$query = mysql_query("SELECT * FROM $tb_entries WHERE uid='$user'") or die(mysql_error());
$userentries = mysql_num_rows($query);

/* Number Of Comments Made */
$query = mysql_query("SELECT * FROM $tb_comments WHERE uid='$user'") or die(mysql_error());
$putcomments = mysql_num_rows($query);

/* Number Of Comments Received */
$query = mysql_query("SELECT id FROM $tb_entries WHERE uid='$user'") or die(mysql_error());
    while($row = mysql_fetch_array($query)) {
        $j = mysql_num_fields($query);
        for($i=0;$i<$j;$i++) {
            $k = mysql_field_name($query,$i);
            $$k = $row[$k];
        }

        $subquery = mysql_query("SELECT id FROM $tb_comments WHERE eid='$id'") or die(mysql_error());
        $getcomments = ($getcomments + mysql_num_rows($subquery));
    }

$body .= <<<EOV
  <tr> 
    <td align="right" width="20%"><b>Date Created:</b></td>
    <td width="80%">$datecreation</td>
  </tr>
  <tr> 
    <td align="right" width="20%"><b>Date Updated:</b></td>
    <td width="80%">$datemodified</td>
  </tr>
  <tr> 
    <td align="right" width="20%"><b>Diary Entries:</b></td>
    <td width="80%">$userentries</td>
  </tr>
  <tr> 
    <td align="right" width="20%"><b>Comments:</b></td>
    <td width="80%"><b>Posted</b>: $putcomments - <b>Received</b>: $getcomments</td>
  </tr>
</table>
EOV;
} else {
$body .= <<<EOV
  <tr>
    <td width="20%">&nbsp;</td>
    <td width="80%"><br><a href="user.php?user=$user&mode=full">(more details)</a></td>
  </tr>
</table>
EOV;
}
} else {
  if (isset($lookup)) {
    $body .= "User not found.";
  } else {
$body .= <<<EOV
  <form method=post>
  Lookup A User By Name<br>
  <input class="box" type="text" name="user"><br>
  <input class="box" type="submit" name="lookup" value="lookup">
  </form>
  <p>Bear in mind, it doesn't work too well at this point. If you lookup a name not in the database, it won't work. [grin]</p>
EOV;
  }
}
include("inc.template.php");
?>
