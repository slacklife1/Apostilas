<?php
include("header.html");
if($password == "logged"){

$getoldnews = fopen("news.txt", "r+");
$filenames = "news.txt";
$theoldnews = fread($getoldnews, filesize($filenames));
$filterednews = stripslashes($theoldnews);

?>
<form action="<? PHP_SELF ?>" method="get">
<p><input type="text" name="date" value="<?php echo(date("m/d/y h:i a")); ?>">
<p>Your name:<input type="text" name="name">
<p>Content:
<p><textarea rows="20" cols="20" name="lnews"></textarea>
<p><input type="hidden" name="oldnews" value="<?php echo($filterednews); ?>">
<p><input type="submit" name="submit" value="submit">
</form>
<?php
if($submit == "submit"){
$news = fopen("news.txt", "w+");
$filename = "news.txt";
$oldnew = fread($news, filesize($filename));
fwrite($news, "<br><p>$date<br><p>Written by<b>  $name</b><br><p><b> $lnews</b> <br>$oldnews");
fclose($news);
}else{
}
}else{
}
include('footer.html');
?>