Hello!
THis is ubernews verson 1.0.
Here are some things you need to know.
-you can change the header and footer files or you can use the current ones (not good idea).
-in login2.php you need to set a password.
You can use this for free, and modify it as you need to, but please, mention my name.
thanks,
Ozak
