<?php
include('header.html');
if(file_exists("news.txt")){
$news = fopen("news.txt", r);
$filename = 'news.txt';
$readnews = fread($news, filesize($filename));
fclose($news);
echo($readnews);
}else{
echo("no news");
}
include('footer.html');
?>