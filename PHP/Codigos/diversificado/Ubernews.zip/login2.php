<?php
$setpassword = crypt("PUT A PASSWORD HERE");
if(crypt($pass,$setpassword) == $setpassword){
setcookie("password", "logged");
include("header.html");
?>
Password Correct! <a href="addnews.php">Go here to add news">
<?
include('footer.html');
}else{
include('header.html');
?>
Invalid Pass
<?
include('footer.html');
}
?>
