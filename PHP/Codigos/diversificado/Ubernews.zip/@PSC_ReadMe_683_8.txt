Title: Ubernews
Description: The code itself is a simple yet effective news system. It required no database, only the availibilty to use PHP. Uses crypt to keep everything secure
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=683&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
