<?php
include("header.html");
?>
<form action="login2.php" method="get">
Password:<input type="password" name="pass">
<p><input type="submit">
<?php
include("footer.html");
?>