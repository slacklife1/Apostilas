<?
/********************************************************************************/
/* EasyBookMarker: Advanced Bookmarks Management System                         */
/* ====================================================                         */
/*                                                                              */
/* Copyright (c) 2003 by Angel Stoitsov and Mario Stoitsov                      */
/*    http://software.stoitsov.com                                              */
/*                                                                              */
/* This file is part of EasyBookMarker.                                         */
/* EasyBookMarker is free software; you can redistribute it and/or modify       */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation; either version 2 of the License, or         */
/*    (at your option) any later version.                                       */
/* EasyBookMarker is distributed in the hope that it will be useful,            */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/* You should have received a copy of the GNU General Public License            */
/*    along with EasyBookMarker; if not, write to the Free Software             */
/*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */
/********************************************************************************/
/*

// Unzip the zip file in some subdirectory (e.g. EasyBookMarker) under the root
// directory on your server. Then follow the three easy steps below

// STEP ONE: Create the tables below under your desired DataBase
//           using phpMyAdmin for example

// ********************************************************************
// *********************** Database Tables
// ********************************************************************
/*

DROP TABLE IF EXISTS `bmcategory`;
CREATE TABLE `bmcategory` (
  `ID` bigint(20) NOT NULL auto_increment,
  `CName` varchar(200) NOT NULL default 'Category Name',
  `CDescription` varchar(255) NOT NULL default 'Category Description',
  `Parent` bigint(20) default '0',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM;
INSERT INTO `bmcategory` (`ID`, `CName`, `CDescription`, `Parent`) VALUES (1, 'Banks', 'USA', 0),
(4, 'Physics', 'All about physics', 0),
(5, 'Conferences', 'Related conferences', 4),
(6, 'Credit Cards', 'USA', 1);

DROP TABLE IF EXISTS `bmlink`;
CREATE TABLE `bmlink` (
  `ID` bigint(20) NOT NULL auto_increment,
  `LUrl` varchar(255) NOT NULL default '',
  `LName` varchar(200) NOT NULL default '',
  `LDescription` text NOT NULL,
  `Date` date NOT NULL default '0000-00-00',
  `Modify` date NOT NULL default '0000-00-00',
  `Visit` date NOT NULL default '0000-00-00',
  `Hits` bigint(20) NOT NULL default '0',
  `Parent` bigint(20) default '0',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM;
INSERT INTO `bmlink` (`ID`, `LUrl`, `LName`, `LDescription`, `Date`, `Modify`, `Visit`, `Hits`, `Parent`) VALUES (1, 'https://www48.americanexpress.com/en/en_US/logon/IntlLogLogon.jsp?Face=en_US&DestPage=https%3A%2F%2Fwww48.americanexpress.com%2Fen%2Fcards%3Frequest_type%3Dauthreg_acctAccountSummary%26Face%3Den_US', 'American Express', 'Credit Cards', '2003-02-09', '2003-07-30', '2003-07-30', 1, 6),
(2, 'https://chaseonline.chase.com', 'Chase', 'chase online', '2003-01-23', '2003-07-30', '2003-07-30', 1, 1),
(4, 'https://www.paypal.com/cgi-bin/webscr?cmd=_login-run', 'PayPal', 'ebay', '2003-02-09', '2003-07-30', '2003-07-30', 0, 1),
(6, 'https://www.wilmingtontrust.com', 'Wilmington Trust', 'Wilmington', '2003-01-31', '2003-07-30', '2003-07-30', 0, 1),
(17, 'http://alinea.bg/', 'alinea.bg', 'BG', '2003-01-18', '2003-07-30', '2003-07-30', 0, 0),
(18, 'http://bgfree.biz/', 'bgfree.biz', 'BG', '2003-01-18', '2003-07-30', '2003-07-30', 0, 0),
(21, 'http://mario.stoitsov.com/', 'mario.stoitsov.com', 'BG', '2003-01-18', '2003-07-30', '2003-07-30', 0, 0),
(22, 'http://mp3.bgfree.biz/', 'mp3.bgfree.biz', 'BG', '2003-01-18', '2003-07-30', '2003-07-30', 0, 0),
(25, 'http://stoitsov.com/', 'stoitsov.com', 'BG', '2003-03-05', '2003-07-30', '2003-07-30', 0, 0),
(28, 'http://www.aps.org/', 'American Physical Society', 'for the advancement and diffusion of knowledge of physics', '2003-02-06', '2003-07-30', '2003-07-30', 0, 4),
(29, 'http://ie.lbl.gov/toimass.html', 'Atomic Masses', 'Mass chart', '2003-01-18', '2003-07-30', '2003-07-30', 0, 4),
(35, 'http://www.orau.gov/ria/', 'First RIA Summer School on Exotic Beam Physics', 'ornl', '2003-01-18', '2003-07-30', '2003-07-30', 0, 5),
(45, 'http://alice-france.in2p3.fr/qm2002/', 'Quark matter 2002', 'France', '2003-01-18', '2003-07-30', '2003-07-30', 0, 5),
(47, 'http://www.sciencedirect.com/science?_ob=JournalURL&_cdi=6706&_auth=y&_acct=C000050221&_version=1&_urlVersion=0&_userid=10&md5=5a7cbb5d17d602fee4c60955da87f665', 'ScienceDirect', 'Atomic Data and Nuclear Data Tables', '2003-03-05', '2003-07-30', '2003-07-30', 0, 4),
(48, 'http://xxx.lanl.gov/find/nucl-th', 'Search Physics archives', 'e-prints', '2003-01-22', '2003-07-30', '2003-07-30', 0, 4);

*/

// STEP TWO: Edit your preferences below

// ********************************************************************
// *********************** Config options
// ********************************************************************
$EasyBookmarker["mysql_host"]="localhost";       // change to your MySQL Host
$EasyBookmarker["mysql_user"]="dbuser";      // change to your MySQL Username
$EasyBookmarker["mysql_pass"]="dbpass"; // change to your MySQL Password
$EasyBookmarker["mysql_base"]="dbname";       // Database name, to contain EasyClassifields tables
$EasyBookmarker["web_user"]="adminuser";        // Username for WEB - based editing interface
$EasyBookmarker["web_pass"]="adminpass";        // Password for WEB - based editing interface
$EasyBookmarker["table_width"]="740";      // Max EasyBookmarker Width default=740px - Expect 800x600 users, rather than 1024x768
$EasyBookmarker["links_per_page"]=20;      // How many links to display on Search & Show pages
$EasyBookmarker["DarkColor"]="#BE3F3F";    // Color of the headings, tables, links
$EasyBookmarker["Background"]="white";     //  Page Background color
$EasyBookmarker["LightColor1"]="#FFE7E7";  // Table Highlight type 1
$EasyBookmarker["LightColor2"]="#F5F5F5";  // Table Highlight type 2
// ********************************************************************

// LAST STEP THREE: POINT TO INDEX.PHP and ENJOY !!!

// ********************************************************************
// You do not need to edit below this line
// ********************************************************************

// ********************************************************************
// ********************* Initialization & Constants
// ********************************************************************
$EasyBookmarker["version"]="2.01b";
session_start();
if (!session_is_registered("expanded_folders")) {
	$expanded_folders="0";	session_register("expanded_folders");
        $Order=1;               session_register("Order");
        $Chart=1;               session_register("Chart");
}
$sql=mysql_connect($EasyBookmarker["mysql_host"],$EasyBookmarker["mysql_user"],$EasyBookmarker["mysql_pass"]) or
			Die (bmError("Problem!","<br>The database server is offline. Try again shortly.","If the problem persists, contact the system administrator."));
mysql_select_db($EasyBookmarker["mysql_base"]) or
			Die (bmError("Problem!","<br>The database is down for maintenance. It takes about 2 minutes to complete.","If the problem persists, contact the system administrator."));

if (isset($follow_link)) {
	bmMyQuery("UPDATE bmLink SET Hits=Hits+1, Visit='".date("Y-m-d")."' WHERE ID=$follow_link;");
	$Link=bmMyFetch("SELECT LUrl From bmLink WHERE ID=$follow_link;");
	Header("Location: ".$Link["LUrl"]);
	exit;
}

// ********************************************************************
// ********************** Functions
// ********************************************************************
// include_once "functions.php"; // (Mark 2)

function bmError($Heading="Error!",$Error="",$Solution="") {
return "<br><table border=0 cellspacing=0 cellpadding=0 align=center><tr><td><div style='background-color:#FFD8D8; border: 2px solid red; padding:10 10 10 10; font: 11px Verdana;'>
		<font color=red><b>$Heading</b></font><br><P>".mysql_error()."<b>$Error</b></P><i>$Solution</i></div></td></tr></table><br>";
} // function Error

function bmTr($width=1,$height=1) {
	return "<img src='tr.gif' width='$width' height='$height' alt='' border='0'>";
}

function bmElement($Element="default",$Arg1="default",$Arg2="default",$Arg3="default",$Arg4="default",$Arg5="default",$Arg6="default") {
	switch ($Element) {
		case "form" : // Element, Action, Name, Method, Aditional
			$Action=$Arg1; $Name=$Arg2; $Method=$Arg3; $Aditional=$Arg4;
			if ($Name=="default") $Name="my";
			if ($Method=="default") $Method="POST";
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			return "<form action='$Action' name='$Name' method='$Method'".$Aditional.">\n";
		break;
		case "hidden" : // Element, Name, Value
			$Name=$Arg1; $Value=$Arg2;
			if ($Value=="default") $Value="";
			return "<input type='hidden' name='".$Name."' value='".$Value."'>\n";
		break;
		case "text" : // Element, Name, Value, Width, Aditional, Class
			$Name=$Arg1; $Value=$Arg2; $Width=$Arg3; $Aditional=$Arg4; $Class=$Arg5;
			if (strpos($Name,"[")===FALSE) {
				$ID="";
			} else {
				$Tmp=split("\[",$Name);
				$TmpID=split("\]",$Tmp[1]);
				$ID=" ID='".$TmpID[0]."' ";
			}
			if ($Value=="default") $Value="";
			if ($Width=="default") { $Width=""; } else { $Width=" style='width: $Width;' "; }
			if ($Class=="default") { $Class=" class='f_text'"; } else { $Class=" class='".$Class."'"; }
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			return "<input type='text'".$Class.$ID." name='".$Name."' value='".$Value."'".$Width.$Aditional.">\n";
		break;
		case "textarea" : // Element, Name, Value, Width, Height
			$Name=$Arg1; $Value=$Arg2; $Width=$Arg3; $Height=$Arg4;
			if ($Value=="default") $Value="";
			if ($Width=="default") { $Width=""; } else { $Width=" style='width: $Width;' "; }
			if ($Height=="default") { $Height=""; } else { $Height=" Rows='$Height' "; }
			return "<textarea class='f_text' name='".$Name."'".$Widht.$Height.">".$Value."</textarea>\n";
		break;
		case "password" : // Element, Name, Value, Width, Aditional
			$Name=$Arg1; $Value=$Arg2; $Width=$Arg3; $Aditional=$Arg4;
			if (strpos($Name,"[")===FALSE) {
				$ID="";
			} else {
				$Tmp=split("[",$Name);
				$TmpID=split("]",$Tmp[1]);
				$ID=" ID='".$TmpID[0]."' ";
			}
			if ($Value=="default") $Value="";
			if ($Width=="default") { $Width=""; } else { $Width=" style='width: $Width;' "; }
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			return "<input type='password' class='f_text'".$ID." name='".$Name."' value='".$Value."'".$Width.$Aditional.">\n";
		break;
		case "radio" : // Element, Name, Value, Selected, Aditional
			$Name=$Arg1; $Value=$Arg2; $Selected=$Arg3; $Aditional=$Arg4;
			if (strpos($Name,"[")===FALSE) {
				$ID="";
			} else {
				$Tmp=split("[",$Name);
				$TmpID=split("]",$Tmp[1]);
				$ID=" ID='".$TmpID[0]."' ";
			}
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			if ($Selected=="default") { $Selected=""; } else { $Selected=" checked"; }
			return "<input type='radio'".$ID." name='".$Name."' value='".$Value."'".$Selected.$Aditional.">"; break;
		break;
		case "checkbox" : // Element, Name, Value, Selected, Aditional
			$Name=$Arg1; $Value=$Arg2; $Selected=$Arg3; $Aditional=$Arg4;
			if (strpos($Name,"[")===FALSE) {
				$ID="";
			} else {
				$Tmp=split("[",$Name);
				$TmpID=split("]",$Tmp[1]);
				$ID=" ID='".$TmpID[0]."' ";
			}
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			if ($Selected=="default") { $Selected=""; } else { $Selected=" checked"; }
			return "<input type='checkbox'".$ID." name='".$Name."' value='".$Value."'".$Selected.$Aditional.">";
		break;
		case "submit" : // Element, Heading, Class
			$Value=$Arg1;
			$Class=$Arg2;
			if ($Class=="default") { $Class="f_text"; }
			return "<input type='submit' class='$Class' name='submit' value='$Value'>";
		break;
		case "button" : // Element, Name, Heading, OnClick
			$Name=$Arg1; $Value=$Arg2; $OnClick=$Arg3;
			if ($OnClick=="default") { $OnClick=""; } else { $OnClick=" OnClick='".$OnClick."'"; }
			return "<input type='button' class='f_text' name='".$Name."' value='".$Value."'".$OnClick.">";
		break;
		case "select" : // Element, Name, Values, Selected, Width, Labels, Aditional
			$Name=$Arg1; $Values=$Arg2; $Selected=$Arg3; $Width=$Arg4; $Labels=$Arg5; $Aditional=$Arg6;
			if (!is_array($Values)) $Values=Array("!!!���� �������� ���������!!!");
			if ($Width=="default") { $Width=""; } else { $Width=" style='width: $Width;' "; }
			if ($Aditional=="default") { $Aditional=""; } else { $Aditional=" ".$Aditional; }
			if (strpos($Name,"[")===FALSE) {
				$ID="";
			} else {
				$Tmp=split("\[",$Name);
				$TmpID=split("\]",$Tmp[1]);
				$ID=" ID='".$TmpID[0]."' ";
			}
			$ret="<select class='f_text' name='".$Name."'".$ID.$Width.$Aditional.">";
			while(list($key,$val)=each($Values)) {
				$CurrentLabel="";
				if (isset($Labels[$key])) $CurrentLabel=" Label='".$Labels[$key]."'";
				$ret.="<option value='".$key."'".$CurrentLabel.($Selected==$key ? " selected" : "" ).">".$val."</option>\n";
			} // while
			$ret.="</select>";
			return $ret;
		break;
		case "reset" : // Element, Heading
			$Value=$Arg1;
			if ($Value=="default") $Value="��������";
			return "<input type='reset' class='f_text' name='reset' value='".$Value."'>";
		break;
		default : // (ANY)
			return "</form>";
		break;
	} // switch
} // function Element

function bmHeading($Heading,$BR=1) {
	if ($BR!=0) $ret="&nbsp;&nbsp;&nbsp;";
	$ret.="<span class='h1s'>".$Heading."</span>";
	for ($t=0; $t<$BR; $t++) $ret.="<BR>";
	return $ret."\n";
} // heading

function bmMyQuery($Query) {
Global $sql;
	$Res=mysql_query($Query) or Die (bmError("Error!","<br>Invalid DataBase Query.","<PRE>The query is:<br>$Query</PRE>If the problem persists, contact the system administrator."));
	return $Res;
} // function MyQuery

function bmMyFetch($Query) {
Global $sql;
	$Res=mysql_fetch_array(mysql_query($Query)) or Die (bmError("Error!","<br>Invalid DataBase Query.","<PRE>The query is:<br>$Query</PRE>If the problem persists, contact the system administrator."));
	return $Res;
} // function MyFetch

function bmHackers($Text) {
	$ret=strip_tags($Text);	$ret=escapeshellcmd($ret);
	$ret=trim($ret);	$ret=str_replace("'","`",$ret);
	return $ret;
}

function ExpandFolder($FolderID) {
Global $PHP_SELF,$expanded_folders;
	$ret=""; $Temp2=array();
	if (isExpandedFolder($FolderID)) { // Expanded
		$Temp=split(",",$expanded_folders);
		for ($t=0; $t<count($Temp); $t++) {
			if ($Temp[$t]!=$FolderID) $ret.=",".$Temp[$t];
		} // for
	} else { // Collapsed
		$ret.=$expanded_folders.",".$FolderID;
	}
	if (substr($ret,0,1)==",") $ret=substr($ret,1,strlen($ret));
	if (strlen($ret)>0) {
		$first="?xpanded_folders=";
	} else {
		unset($ret); $first="?xpanded_folders=";
	}
	return "<a href='".$PHP_SELF.$first.$ret.(!isExpandedFolder($FolderID) ? "#Loc".$FolderID : "" )."' class=normal title='Expand/Collapse Folder'>";
}


function isExpandedFolder($FolderID) {
Global $expanded_folders;
	if ($expanded_folders=="E_ALL" or $FolderID==0) return TRUE;
	$Temp=split(",",$expanded_folders);
	for ($t=0; $t<count($Temp); $t++) {
		if ($Temp[$t]==$FolderID) return TRUE;
	} // for
	return false;
}

function AllFolders($Act="expand") {
global $sql,$expanded_folders;
	if ($Act=="expand") { // Expand All
		$first="?xpanded_folders=0";
		$CatSelects=bmMyQuery("SELECT * FROM bmCategory ORDER BY CName;");
		while ($CatSelect=mysql_fetch_array($CatSelects)) {
			$first.=",".$CatSelect["ID"];
		} // while
	} else { // Collapse All
		$first="?xpanded_folders=";
	}
	return "<a href='".$PHP_SELF.$first."' class=normal title='".ucfirst($Act)." Folders'>";
}

function to_stamp($Date) {
	$MDate=split("-",$Date);
	return mktime(12,00,00,$MDate[1],$MDate[2],$MDate[0]);
}

function Export($Parent=0, &$level, &$RH) {
Global $sql;
	$Folders=bmMyQuery("SELECT * FROM bmCategory WHERE Parent=$Parent ORDER BY CName;");
	if (mysql_num_rows($Folders)==0) { // No subFolders
		return "";
	} else { // There are some subFolders
		while ($Folder=mysql_fetch_array($Folders)) {
			$level[$Folder["ID"]]=$level[$Parent]+1;
			For ($t=0; $t<$level[$Folder["ID"]]*2; $t++) $RH.=" ";
			$RH.="<DT><H3 FOLDED ADD_DATE=\"1047045444\" DESCRIPTION=\"".$Folder["CDescription"]."\">".$Folder["CName"]."</H3>\n";
			$Links=bmMyQuery("SELECT * FROM bmLink WHERE Parent=".$Folder["ID"]." ORDER BY LName;");
			For ($t=0; $t<$level[$Folder["ID"]]*2; $t++) $RH.=" ";
			$RH.="<DL><p>\n";
			while ($Link=mysql_fetch_array($Links)) {
				For ($t=0; $t<$level[$Folder["ID"]]*2; $t++) $RH.=" ";
				$RH.="<DT><A HREF=\"".$Link["LUrl"]."\" ADD_DATE=\"".to_stamp($Link["Date"])."\" LAST_VISIT=\"".to_stamp($Link["Visit"])."\" LAST_MODIFIED=\"".to_stamp($Link["Modify"])."\" DESCRIPTION=\"".$Link["LDescription"]."\" HITS=\"".$Link["Hits"]."\">".$Link["LName"]."</A>\n";
			} // while links
			Export($Folder["ID"],$level, $RH);
			For ($t=0; $t<$level[$Folder["ID"]]*2; $t++) $RH.=" ";
			$RH.="</DL><p>\n";
		} // while
	} // if parent
}


function ShowFolder($Parent=0, &$level, &$ResultHtml, &$Light) {
Global $sql,$Stoitsov,$EasyBookmarker;
	$Folders=bmMyQuery("SELECT * FROM bmCategory WHERE Parent=$Parent ORDER BY CName;");
	if (mysql_num_rows($Folders)==0 or !isExpandedFolder($Parent)) { // No subFolders or Folder is collapsed
		return "";
	} else { // There are some subFolders
		while ($Folder=mysql_fetch_array($Folders)) {
			$Light++;
			if (isset($Stoitsov["User"])) {
				if ($Light % 2 == 0) { $color="bgcolor=".$EasyBookmarker["Background"].""; } else { $color="bgcolor=".$EasyBookmarker["LightColor1"].""; }
			}
			$level[$Folder["ID"]]=$level[$Parent]+1;
			$ResultHtml.="<table border='0' cellspacing='0' cellpadding='0' width='".$EasyBookmarker["table_width"]."'>
			<tr><td><a name='Loc".$Folder["ID"]."'></a>".bmTr($level[$Parent]*10).
			($level[$Parent]==1 ? ExpandFolder($Folder["ID"])."<img src='".(isExpandedFolder($Folder["ID"]) ? "expanded" : "collapsed" )."_folder.gif' width='32' height='32' alt='' border='0'>"
			: ExpandFolder($Folder["ID"])."<img src='".(isExpandedFolder($Folder["ID"]) ? "minus" : "plus" ).".gif' width='12' height='16' alt='' border='0'>")."</a></td>
			<td $color width=100% valign=bottom>&nbsp;".ExpandFolder($Folder["ID"])."<b>".$Folder["CName"]."</b></a>".($level[$Parent]==1 ? "<BR>&nbsp;" : " - " )."<i>".$Folder["CDescription"]."</i></td>
			".(isset($Stoitsov["User"]) ? "<td $color><a href='$PHP_SELF?page=edit_folder&id=".$Folder["ID"]."'><img src='folder_dark.gif' width='16' height='16' alt='Edit folder' border='0'
			></a><a href='$PHP_SELF?page=add_folder&parent=".$Folder["ID"]."'><img src='folder_light.gif' width='16' height='16' alt='Add folder' border='0'
			></a><a href='$PHP_SELF?page=add_link&parent=".$Folder["ID"]."'><img src='new_link.gif' width='16' height='16' alt='Add link' border='0'></a><br></td>" : "" )."</tr></table>";
			if (isExpandedFolder($Folder["ID"])) {
				$ResultHtml.=ShowLinks($Folder["ID"],$level[$Parent]*10);
			}
			ShowFolder($Folder["ID"],$level, $ResultHtml, &$Light);
		} // while
	} // if parent
}

function ShowBrief($What,$HowMany) {
Global $sql, $EasyBookmarker;
	$Links=bmMyQuery("SELECT * FROM bmLink ORDER BY $What LIMIT 0,".$HowMany.";");
	$ResultHtml="";
	while ($Link=mysql_fetch_array($Links)) {
                $ResultHtml.="&#149; <a href='$PHP_SELF?follow_link=".$Link["ID"]."' target=\"_new\"  OnMouseover='self.status=\"GoTo: ".$Link["LUrl"]."\"; return true;' OnMouseOut='self.status=\"EasyBookmarker ver.".$EasyBookmarker["version"]."\"; return true;' class=normal>".$Link["LName"]."</a><br>";
	}
	return $ResultHtml;
}

function ShowLinks($Parent=0, $distance) {
Global $sql, $Stoitsov,$EasyBookmarker,$OrderQry;
	$Links=bmMyQuery("SELECT * FROM bmLink WHERE Parent=$Parent ORDER BY $OrderQry;");
	$num_links=mysql_num_rows($Links);
	$i=0;
	while ($Link=mysql_fetch_array($Links)) {
		$i++;
		if (isset($Stoitsov["User"])) {
			if ($i % 2 != 0) { $color="bgcolor=".$EasyBookmarker["Background"].""; } else { $color="bgcolor=".$EasyBookmarker["LightColor2"]; }
		}
		$ret.= "<table border='0' cellspacing='0' cellpadding='0' width='".$EasyBookmarker["table_width"]."'>
		<tr><td>".bmTr($distance).($distance<11 ? bmTr(11)."<img src='toplink.gif' width='10' height='16' alt='' border='0'>" :
		"<img src='lnk_".($i==$num_links ? "down" : "middle" ).".gif' width='12' height='16' alt='' border='0'><img src='link.gif' width='10' height='16' alt='' border='0'>" )."<br></td>
                <td width=100% $color><a href='$PHP_SELF?follow_link=".$Link["ID"]."' target=\"_new\"   OnMouseover='self.status=\"GoTo: ".$Link["LUrl"]."\"; return true;' OnMouseOut='self.status=\"EasyBookmarker ver.".$EasyBookmarker["version"]."\"; return true;' class=normal targer=_new>".$Link["LName"]."</a> (<i>".$Link["LDescription"]."</i>)</td>
                ".(isset($Stoitsov["User"]) ? "<td $color><a href='$PHP_SELF?page=edit_link&id=".$Link["ID"]."&parent=".$Link["Parent"]."'><img src='edit_link.gif' width='16' height='16' alt='Edit link' border='0'></a>&nbsp;<a href='$PHP_SELF?action=delete_link&bmID=".$Link["ID"]."'><img src='delete_link.gif' width='16' height='16' alt='Delete link' border='0'></a><br></td>" : "" )."</tr></table>";
	} // while
	return $ret;
}






// ********************************************************************
// ************************ Actions
// ********************************************************************
if ($action=="login") {
	if ($bmUsername==$EasyBookmarker["web_user"] && $bmPassword==$EasyBookmarker["web_pass"]) { // valid user
		$Stoitsov["User"]=$EasyBookmarker["web_user"];
		session_register("Stoitsov");
	} else { // invalid user
		$Error="<b>Invalid username or password.</b><br>";
		$page="login";
	}// if
} // Login

if ($action=="remote") {
	if ($bmUsername==$EasyBookmarker["web_user"] && $bmPassword==$EasyBookmarker["web_pass"]) { // valid user
		$Stoitsov["User"]=$EasyBookmarker["web_user"];
		session_register("Stoitsov");
		$action="add_link";
		$bmLUrl=$url; $bmLName=$name; $bmLDescription="Imported from Quick Add function"; $bmParent="0";
	} else { // invalid user
		$Error="<b>Invalid username or password.</b><br>";
		$page="remote";
	}// if
} // Remote

if ($action=="add_folder") {
	if (!isset($Stoitsov["User"])) { // invalid user
		$page="login";
		$Error="<b>You need to be a registered user in order to add folders.</b><br>";
	} else { // valid
		unset($Error);
		if (strlen(bmHackers($bmCName))<1) $Error="<b>Folder Name is empty.</b><br>";
		if (strlen(bmHackers($bmCDescription))<1) $Error.="<b>Folder Description is empty.</b><br>";
		if (isset($Error)) { // There are errors
			$page="add_folder";
			$parent=$bmParent;
		} else { // Add Folder
			bmMyQuery("INSERT INTO bmCategory VALUES(null,'".bmHackers($bmCName)."','".bmHackers($bmCDescription)."','$bmParent');");
		} // if Errors
	} // if valid
} // Add Folder

if ($action=="edit_folder") {
	if (!isset($Stoitsov["User"])) { // invalid user
		$page="login";
		$Error="<b>You need to be a registered user in order to edit folders.</b><br>";
	} else { // valid
		unset($Error);
		if (strlen(bmHackers($bmCName))<1) $Error="<b>Folder Name is empty.</b><br>";
		if (strlen(bmHackers($bmCDescription))<1) $Error.="<b>Folder Description is empty.</b><br>";
		if (isset($Error)) { // There are errors
			$page="edit_folder";
			$id=$bmID;
		} else { // Edit Folder
			bmMyQuery("UPDATE bmCategory SET Parent='".$bmParent."', CName='".bmHackers($bmCName)."', CDescription='".bmHackers($bmCDescription)."' WHERE ID=$bmID;");
		} // if Errors
	} // if valid
} // Edit Folder

if ($action=="delete_folder") {
	if (!isset($Stoitsov["User"])) { // invalid user
		$page="login";
		$Error="<b>You need to be a registered user in order to delete folders.</b><br>";
	} else { // valid
		bmMyQuery("DELETE FROM bmCategory WHERE ID=$bmID;");
	} // if valid
} // Delete Folder

if ($action=="add_link") {
	if (!isset($Stoitsov["User"])) { // invalid user
		$page="login";
		$Error="<b>You need to be a registered user in order to add links.</b><br>";
	} else { // valid
		unset($Error);
		if (strlen(bmHackers($bmLUrl))<8) $Error="<b>The link is invalid.</b><br>";
		if (strlen(bmHackers($bmLName))<1) $Error="<b>Site Name is empty.</b><br>";
		if (strlen(bmHackers($bmLDescription))<1) $Error.="<b>Site Description is empty.</b><br>";
		if (isset($Error)) { // There are errors
			$page="add_link";
			$parent=$bmParent;
		} else { // Add Link
			bmMyQuery("INSERT INTO bmLink VALUES(null,'".bmHackers($bmLUrl)."','".bmHackers($bmLName)."','".bmHackers($bmLDescription)."','".date("Y-m-d")."','".date("Y-m-d")."','".date("Y-m-d")."',0,'$bmParent');");
		} // if Errors
	} // if valid
} // Add Link

if ($action=="edit_link") {
	if (!isset($Stoitsov["User"])) { // invalid user
		$page="login";
		$Error="<b>You need to be a registered user in order to edit links.</b><br>";
	} else { // valid
		unset($Error);
		if (strlen(bmHackers($bmLUrl))<8) $Error="<b>The link is invalid.</b><br>";
		if (strlen(bmHackers($bmLName))<1) $Error="<b>Site Name is empty.</b><br>";
		if (strlen(bmHackers($bmLDescription))<1) $Error.="<b>Site Description is empty.</b><br>";
		if (isset($Error)) { // There are errors
			$page="add_link";
			$parent=$bmParent;
			$id=$bmID;
		} else { // Edit Link
			bmMyQuery("UPDATE bmLink SET Parent='".$bmParent."', LUrl='".bmHackers($bmLUrl)."', LName='".bmHackers($bmLName)."', LDescription='".bmHackers($bmLDescription)."', Modify='".date("Y-m-d")."', Visit='".date("Y-m-d")."' WHERE ID=$bmID;");
		} // if Errors
	} // if valid
} // Edit Link

if ($action=="delete_link") {
	if (!isset($Stoitsov["User"])) { // invalid user
		$page="login";
		$Error="<b>You need to be a registered user in order to delete links.</b><br>";
	} else { // valid
		bmMyQuery("DELETE FROM bmLink WHERE ID=$bmID;");
	} // if valid
} // Delete Folder

if ($action=="export") {
	if (!isset($Stoitsov["User"])) { // invalid user
		$page="login";
		$Error="<b>You need to be a registered user in order to export bookmarks.</b><br>";
	} else { // valid
		$RH="<!DOCTYPE NETSCAPE-Bookmark-file-1>\n<!-- This is an automatically generated file.\nIt will be read and overwritten.\nDo Not Edit! -->\n<TITLE>Bookmarks</TITLE>\n<H1>Bookmarks</H1>\n";
		$RH.="<DL><p>\n";
		Export(0,$level,$RH);
		$Links=bmMyQuery("SELECT * FROM bmLink WHERE Parent=0 ORDER BY LName;");
		while ($Link=mysql_fetch_array($Links)) {
			$RH.="<DT><A HREF=\"".$Link["LUrl"]."\" ADD_DATE=\"".to_stamp($Link["Date"])."\" LAST_VISIT=\"".to_stamp($Link["Visit"])."\" LAST_MODIFIED=\"".to_stamp($Link["Modify"])."\" DESCRIPTION=\"".$Link["LDescription"]."\" HITS=\"".$Link["Hits"]."\">".$Link["LName"]."</A>\n";
		} // while links
		$RH.="</DL><p>\n";
		header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
		header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
		header("Cache-Control: no-store, no-cache, must-revalidate");
		header("Cache-Control: post-check=0, pre-check=0", false);
		header("Pragma: no-cache");
		header("Content-type: application/octet-stream");
		header("Content-Disposition: attachment; filename=bookmark.htm");
		print $RH;
		exit;
	} // if
} // export

if ($action=="import") {
	if (!isset($Stoitsov["User"])) { // invalid user
		$page="login";
		$Error="<b>You need to be a registered user in order to import bookmarks.</b><br>";
	} else { // valid
		if ($_FILES['file_name']['type']!="text/html") { // invalid format
			$page="import";
			$Error="<b>You can import only valid HTML/TEXT files.</b><br>";
		} else { // Valid format, grab
			$fd = fopen ($_FILES['file_name']['tmp_name'], "r");
			$Level=-1;
			$ParentID=Array();
			$ParentID[0]=0;
			while (!feof ($fd)) {
				$buffer = trim(fgets($fd, 4096));
				$buffer=str_replace(chr(10),"",$buffer);
				$buffer=str_replace(chr(13),"",$buffer);
				$buffer=str_replace("<DT>","",$buffer);
				$buffer=str_replace("'","`",$buffer);
				if ($buffer=="<DL><p>") $Level++;
				if ($buffer=="</DL><p>") $Level--;
				if (strlen($buffer)>9 && $Level>=0) { // Valid tag
					// Determine Type of line
					if (substr($buffer,1,2)=="H3") { // Its a folder
						$bmCName=strip_tags($buffer);
						bmMyQuery("INSERT INTO bmCategory Values(null,'".$bmCName."','Imported folder','".$ParentID[$Level]."');");
						$ParentID[$Level+1]=mysql_insert_id();
					} elseif (substr($buffer,1,6)=="A HREF") { // Its a link
						$SplitValues=Array("HREF","ADD_DATE","LAST_VISIT","LAST_MODIFIED","DESCRIPTION","HITS");
						$TableValues=Array("bmLUrl","bmDate","bmVisit","bmModify","bmLDescription","bmHits");
						for ($t=0; $t<count($SplitValues); $t++) {
							$Temp1=split($SplitValues[$t]."=\"",$buffer);
							$Temp2=split("\"",$Temp1[1]);
							$var=$TableValues[$t];
							if ($Temp2[0]<0) $Temp2[0]="";
							$$var=$Temp2[0];
						} // for
						bmMyQuery("INSERT INTO bmLink VALUES(null,'".$bmLUrl."','".strip_tags($buffer)."','".$bmLDescription."','".date("Y-m-d",$bmDate)."','".date("Y-m-d",$bmModify)."','".date("Y-m-d",$bmVisit)."',0,'".$ParentID[$Level]."');");
					} // determine line type
				} // while
			} // valid tag
			fclose ($fd);
		} // valid format
	} // valid user
}

if ($action=="logout") { unset($Stoitsov["User"]); }                 // Logout
if (isset($xpanded_folders)) { $expanded_folders=$xpanded_folders; } // expanded
if (isset($setOrder)) { $Order=$setOrder; }                          // Link Order
if (isset($setChart)) { $Chart=$setChart; }                          // Chart Order

session_write_close();

switch ($Order) {
	case 2: $OrderQry="Date DESC"; break;
	case 3: $OrderQry="Visit Desc"; break;
	case 4: $OrderQry="Modify Desc"; break;
	case 5: $OrderQry="Hits Desc"; break;
	default: $OrderQry="LName ASC"; break;
}
switch ($Chart) {
	case 2: $ChartHeading="Newest Links"; $ChartQry="Date DESC"; break;
	case 3: $ChartHeading="Last Visited Links"; $ChartQry="Visit Desc"; break;
	case 4: $ChartHeading="Last Modified Links"; $ChartQry="Modify Desc"; break;
	case 5: $ChartHeading="Most Rated (Click-through) Links"; $ChartQry="Hits Desc"; break;
	default: $ChartHeading="Alphabeticaly"; $ChartQry="LName ASC"; break;
}



// ********************************************************************
// **************   EasyBookmarker Screen Creation
// ********************************************************************

// Start: Main page
if (!isset($page)) {
	$ResultHtml="";
	$level[0]=1;
	$Light=0;
	ShowFolder(0,$level,$FoldersHtml, &$Light);
	$ResultHtml="<div align=center><table border='0' cellspacing='0' cellpadding='0' width='".$EasyBookmarker["table_width"]."'>
	<tr><td><img src='topfolder.gif' width='32' height='32' alt='Root folder' border='0'><br></td>
	<td width=100%>&nbsp;".bmHeading("EasyBookmarker",0)."</td>
	".(isset($Stoitsov["User"]) ? "<td $color><a href='$PHP_SELF?page=add_folder&parent=0'><img src='folder_light.gif' width='16' height='16' alt='Add folder' border='0'
	></a><a href='$PHP_SELF?page=add_link&parent=0'><img src='new_link.gif' width='16' height='16' alt='Add link' border='0'></a><br></td>" : "" )."</td></tr></table>";
	$ResultHtml.=ShowLinks(0,0);
	$ResultHtml.=$FoldersHtml.
	"</div>";
} // End: Main Page

// Start: Chart page
if (isset($page) && $page=="show_links") {
	$ResultHtml="";
	if (!isset($From)) $From=0;
	$TotalLinks=mysql_num_rows(bmMyQuery("SELECT ID FROM bmLink;"));
	$Links=bmMyQuery("SELECT * FROM bmLink ORDER BY $ChartQry LIMIT $From,".$EasyBookmarker["links_per_page"].";");
	If ($TotalLinks-$From-$EasyBookmarker["links_per_page"]>0) { $More=TRUE; } else { $More=FALSE; }
	$ResultHtml=bmHeading("Bookmarks",1)."&nbsp;&nbsp;&nbsp;<b>".$ChartHeading."</b><div align=center><table border='0' cellspacing='1' cellpadding='2' width='".$EasyBookmarker["table_width"]."'>
	<tr><td><span class=".$EasyBookmarker["Background"].">#</span></td><td><span class=".$EasyBookmarker["Background"].">Name/Description</span></td><td nowrap><span class=".$EasyBookmarker["Background"].">Added</span></td><td nowrap><span class=".$EasyBookmarker["Background"].">Modified</span></td><td nowrap><span class=".$EasyBookmarker["Background"].">Visited</span></td><td nowrap><span class=".$EasyBookmarker["Background"].">Clicks</span></td>
        ".(isset($Stoitsov["User"]) ? "<td nowrap><span class=".$EasyBookmarker["Background"].">Edit</span></td><td nowrap><span class=".$EasyBookmarker["Background"].">Delete</span></td>" : "" )."</tr>
	";
	$i=$From;
	while ($Link=mysql_fetch_array($Links)) {
		$i++;
		if ($i % 2 != 0) { $color="bgcolor=".$EasyBookmarker["Background"].""; } else { $color="bgcolor=".$EasyBookmarker["LightColor2"].""; }
		$ResultHtml.="<tr $color><td valign=top nowrap align=right>".$i.".</td>
		<td valign=top width=100%><a href='$PHP_SELF?follow_link=".$Link["ID"]."' class=normal>".$Link["LName"]."</a> (<i>".$Link["LDescription"]."</i>)</td>
		<td valign=top nowrap>".$Link["Date"]."</td>
		<td valign=top nowrap>".$Link["Modify"]."</td>
		<td valign=top nowrap>".$Link["Visit"]."</td>
		<td valign=top nowrap align=center>".$Link["Hits"]."</td>
                ".(isset($Stoitsov["User"]) ? "<td valign=top $color><a href='$PHP_SELF?page=edit_link&id=".$Link["ID"]."&parent=".$Link["Parent"]."'><img src='edit_link.gif' width='16' height='16' alt='Edit link' border='0'>
                </a></td><td valign=top $color>&nbsp;<a href='$PHP_SELF?action=delete_link&bmID=".$Link["ID"]."'><img src='delete_link.gif' width='16' height='16' alt='Delete link' border='0'></a><br></td>" : "" )."</tr>";
	}
	$ResultHtml.="</table>
	<hr size=1 noshade color='".$EasyBookmarker["LightColor2"]."' width='".$EasyBookmarker["table_width"]."'>
	<table border='0' cellspacing='1' cellpadding='2' width='".$EasyBookmarker["table_width"]."'><tr>
	".($From!=0 ? "<td><a href='$PHP_SELF?page=show_links&setChart=$Chart&From=".($From-$EasyBookmarker["links_per_page"])."' class=normal>< Previous page</a></td>" : "" )."
	".($More ? "<td align=right><a href='$PHP_SELF?page=show_links&setChart=$Chart&From=".($From+$EasyBookmarker["links_per_page"])."' class=normal>Next page ></a></td>" : "" )."
	</tr></table></div>";
} // End: Chart Page


// Start: Search page
if (isset($page) && $page=="search") {
	$ResultHtml="";
	$bmSearch=bmHackers($bmSearch);
	if (!isset($From)) $From=0;
	$TotalLinks=mysql_num_rows(bmMyQuery("SELECT ID FROM bmLink WHERE LName like '%".$bmSearch."%' OR LDescription like '%".$bmSearch."%' OR LUrl like '%".$bmSearch."%';"));
	$Links=bmMyQuery("SELECT * FROM bmLink WHERE LName like '%".$bmSearch."%' OR LDescription like '%".$bmSearch."%' OR LUrl like '%".$bmSearch."%' ORDER BY Hits Desc LIMIT $From,".$EasyBookmarker["links_per_page"].";");
	If ($TotalLinks-$From-$EasyBookmarker["links_per_page"]>0) { $More=TRUE; } else { $More=FALSE; }
	$ResultHtml=bmHeading("Bookmarks",1)."&nbsp;&nbsp;&nbsp;<b>Search for \"".$bmSearch."\"</b><div align=center><table border='0' cellspacing='1' cellpadding='2' width='".$EasyBookmarker["table_width"]."'>
	<tr><td><span class=".$EasyBookmarker["Background"].">#</span></td><td><span class=".$EasyBookmarker["Background"].">Name/Description</span></td><td nowrap><span class=".$EasyBookmarker["Background"].">Added</span></td><td nowrap><span class=".$EasyBookmarker["Background"].">Modified</span></td><td nowrap><span class=".$EasyBookmarker["Background"].">Visited</span></td><td nowrap><span class=".$EasyBookmarker["Background"].">Clicks</span></td>
        ".(isset($Stoitsov["User"]) ? "<td nowrap><span class=".$EasyBookmarker["Background"].">Edit</span></td><td nowrap><span class=".$EasyBookmarker["Background"].">Delete</span></td>" : "" )."</tr>
	";
	$i=$From;
	while ($Link=mysql_fetch_array($Links)) {
		$i++;
		if ($i % 2 != 0) { $color="bgcolor=".$EasyBookmarker["Background"].""; } else { $color="bgcolor=".$EasyBookmarker["LightColor2"].""; }
		$ResultHtml.="<tr $color><td valign=top nowrap align=right>".$i.".</td>
		<td valign=top width=100%><a href='$PHP_SELF?follow_link=".$Link["ID"]."' class=normal>".$Link["LName"]."</a> (<i>".$Link["LDescription"]."</i>)</td>
		<td valign=top nowrap>".$Link["Date"]."</td>
		<td valign=top nowrap>".$Link["Modify"]."</td>
		<td valign=top nowrap>".$Link["Visit"]."</td>
		<td valign=top nowrap align=center>".$Link["Hits"]."</td>
                ".(isset($Stoitsov["User"]) ? "<td valign=top $color><a href='$PHP_SELF?page=edit_link&id=".$Link["ID"]."&parent=".$Link["Parent"]."'><img src='edit_link.gif' width='16' height='16' alt='Edit link' border='0'>
                </a></td><td valign=top $color>&nbsp;<a href='$PHP_SELF?action=delete_link&bmID=".$Link["ID"]."'><img src='delete_link.gif' width='16' height='16' alt='Delete link' border='0'></a><br></td>" : "" )."</tr>";
	}
	$ResultHtml.="</table>
	<hr size=1 noshade color='".$EasyBookmarker["LightColor2"]."' width='".$EasyBookmarker["table_width"]."'>
	<table border='0' cellspacing='1' cellpadding='2' width='".$EasyBookmarker["table_width"]."'><tr>
	".($From!=0 ? "<td><a href='$PHP_SELF?page=search&bmSearch=$bmSearch&From=".($From-$EasyBookmarker["links_per_page"])."' class=normal>< Previous page</a></td>" : "" )."
	".($More ? "<td align=right><a href='$PHP_SELF?page=search&bmSearch=$bmSearch&From=".($From+$EasyBookmarker["links_per_page"])."' class=normal>Next page ></a></td>" : "" )."
	</tr></table></div>";
} // End: Search Page


// Start: Export page
if ($page=="export") {
	$ResultHtml="";
	if (!isset($Stoitsov["User"])) { // invalid user
		$page="login";
		$Error="You need to be registered user in order to add categories.";
	} else { // valid
	$ResultHtml.= bmHeading("Export Bookmarks",2);
	$ResultHtml.= "<ul><p>This function helps you move your bookmarks from EasyBookmarker to your favorite Browser. Once you downloaded the file, follow these instructions:</p>
	<b>M$ Internet Explorer</b>
	<ul>
	<li>File Menu</li>
	<li>Import and Export...</li>
	<li>In the wizard, select Import Favorites</li>
	<li>Choose Import from file or address option</li>
	<li>Select the downloaded file</li>
	</ul><br>
	<b>Netscape 6</b>
	<ul>
	<li>Bookmarks Menu</li>
	<li>Manage bookmarks</li>
	<li>File Menu</li>
	<li>Import bookmarks...</li>
	<li>Select the downloaded file</li>
	</ul>
	<p>Its that simple.</p>
	<p><b>To download your bookmarks, click the link below.</b> If your download does not start, right-click the link and choose Save as option.</p>
	<a href='$PHP_SELF?action=export' class=normal>Download now</a></ul>";
}
} // End: Export Page

// Start: import page
if ($page=="import") {
$ResultHtml="";
	if (!isset($Stoitsov["User"])) { // invalid user
		$page="login";
		$Error="You need to be registered user in order to add categories.";
	} else { // valid
	$ResultHtml.= bmHeading("Import Bookmarks",2).
	"<ul><p>This function helps you move your bookmarks from your favorite Browser to the EasyBookmarker.</p>
	<p>Tested & works fine with exported bookmarks from:</p>
	<ul>
	<li>M$ Internet Explorer 5 and above</li>
	<li>Netscape Navigator</li>
	<li>Netscape Communicator</li>
	<li>Netscape 6</li>
	<li>EasyBookmarker 2.0 and above</li>
	</ul>
	<form action='$PHP_SELF' method=post enctype='multipart/form-data'>
	<input type='hidden' name='MAX_FILE_SIZE' value='".(1024*1024*1024)."'>
	<b>Choose your local bookmarks file:</b><br>
	<input type=file name='file_name' class=f_text><br><br>
	".bmElement("submit","Import","f_button").
	bmElement("hidden","action","import").
	"</form>".$Error."
	</ul>";
	}
} // End: Import Page


// Start: Add Folder page
if (isset($page) && $page=="add_folder" && isset($parent)) {
$ResultHtml="";
	if (!isset($Stoitsov["User"])) { // invalid user
		$page="login";
		$Error="You need to be a registered user in order to add categories.";
	} else { // valid
		if ($parent!=0) {
			$UnderCategory=bmMyFetch("SELECT * FROM bmCategory WHERE ID=$parent LIMIT 1");
		} else {
			$UnderCategory["CName"]="EasyBookmarker";
		}
		$ResultHtml.=bmHeading("Edit Bookmarks",1).
		"&nbsp;&nbsp;&nbsp;<b>New Folder under ".$UnderCategory["CName"]."</b><br><br>
			<div align=center>
			<table border='0' cellspacing='1' cellpadding='2' bgcolor='".$EasyBookmarker["DarkColor"]."' width=200>
				<tr>
					<td>&nbsp;<font color=".$EasyBookmarker["Background"]."><b>.: New Folder Information</b></font></td>
				</tr>
				".bmElement("form",$PHP_SELF,"Folder","POST")."
				<tr>
					<td bgcolor=".$EasyBookmarker["Background"]."><b>Name:</b> [200 Chars max]<br>
					".bmElement("text","bmCName","",250)."</td>
				</tr>
				<tr>
					<td bgcolor=".$EasyBookmarker["Background"]."><b>Description:</b> [255 Chars max]<br>
					".bmElement("text","bmCDescription","",250)."</td>
				</tr>
				<tr>
					<td align=right>".bmElement("submit","Create","f_button")."</td>
				</tr>
				".bmElement("hidden","bmParent",$parent).bmElement("hidden","action","add_folder").bmElement()."
			</table><br>".
			$Error
			."</div>
		";
	} // if valid
} // End: Add Folder page

// Start: Edit Folder page
if (isset($page) && $page=="edit_folder" && isset($id)) {
	$ResultHtml="";
	if (!isset($Stoitsov["User"])) { // invalid user
		$page="login";
		$Error="You need to be registered user in order to edit the folders.";
	} else { // valid
		$EditFolder=bmMyFetch("SELECT * FROM bmCategory WHERE ID=$id LIMIT 1");
		$isEmpty=mysql_num_rows(bmMyQuery("SELECT * FROM bmLink Where Parent=".$EditFolder["ID"].";"))+
		mysql_num_rows(bmMyQuery("SELECT * FROM bmCategory Where Parent=".$EditFolder["ID"].";"));
		$CatSelects=bmMyQuery("SELECT * FROM bmCategory Where ID<>$id ORDER BY BINARY CName;");
		$Under=$Categories[0]="EasyBookmarker";
		while ($CatSelect=mysql_fetch_array($CatSelects)) {
			$Categories[$CatSelect["ID"]]=$CatSelect["CName"];
			if ($CatSelect["Parent"]==$EditFolder["ID"]) $Under=$CatSelect["CName"];
		} // while
		$ResultHtml.= bmHeading("Edit Bookmarks",1).
		 "&nbsp;&nbsp;&nbsp;<b>Edit Folder under ".$Under."</b><br><br>
			<div align=center>
			<table border='0' cellspacing='1' cellpadding='2' bgcolor='".$EasyBookmarker["DarkColor"]."' width=200>
				<tr>
					<td>&nbsp;<font color=".$EasyBookmarker["Background"]."><b>.: Folder Information</b></font></td>
				</tr>
				".bmElement("form",$PHP_SELF,"Folder","POST")."
				<tr>
					<td bgcolor=".$EasyBookmarker["Background"]."><b>Move folder under:</b> [no change - no move]<br>
					".bmElement("select","bmParent",$Categories,$EditFolder["Parent"],250)."</td>
				</tr>
				<tr>
					<td bgcolor=".$EasyBookmarker["Background"]."><b>Name:</b> [200 Chars max]<br>
					".bmElement("text","bmCName",$EditFolder["CName"],250)."</td>
				</tr>
				<tr>
					<td bgcolor=".$EasyBookmarker["Background"]."><b>Description:</b> [255 Chars max]<br>
					".bmElement("text","bmCDescription",$EditFolder["CDescription"],250)."</td>
				</tr>
				<tr>
					<td align=right>".bmElement("submit","Change","f_button")."</td>
				</tr>
				".bmElement("hidden","action","edit_folder").
				bmElement("hidden","parent",$EditFolder["Parent"]).
				bmElement("hidden","bmID",$EditFolder["ID"]).bmElement()."
			</table><br>".
			$Error.
			($isEmpty==0 ? "<a href='$PHP_SELF?action=delete_folder&bmID=$id' class=normal>You may delete this folder. It is empty.</a>" : "You can not delete this folder. It is not empty." )
			."</div>
		";
	} // if valid
} // End: Edit Folder page

// Start: Add Link page
if (isset($page) && $page=="add_link" && isset($parent)) {
$ResultHtml="";
	if (!isset($Stoitsov["User"])) { // invalid user
		$page="login";
		$Error="You need to be a registered user in order to add links.";
	} else { // valid
		if ($parent!=0) {
			$UnderCategory=bmMyFetch("SELECT * FROM bmCategory WHERE ID=$parent LIMIT 1");
		} else {
			$UnderCategory["CName"]="EasyBookmarker";
		}
		$ResultHtml.= bmHeading("Edit Bookmarks",1).
		"&nbsp;&nbsp;&nbsp;<b>New Link under ".$UnderCategory["CName"]."</b><br><br>
			<div align=center>
			<table border='0' cellspacing='1' cellpadding='2' bgcolor='".$EasyBookmarker["DarkColor"]."' width=200>
				<tr>
					<td>&nbsp;<font color=".$EasyBookmarker["Background"]."><b>.: New Link Information</b></font></td>
				</tr>
				".bmElement("form",$PHP_SELF,"Link","POST")."
				<tr>
					<td bgcolor=".$EasyBookmarker["Background"]."><b>Link:</b> [255 Chars max]<br>
					".bmElement("text","bmLUrl","http://",250)."</td>
				</tr>
				<tr>
					<td bgcolor=".$EasyBookmarker["Background"]."><b>Site Name:</b> [200 Chars max]<br>
					".bmElement("text","bmLName","",250)."</td>
				</tr>
				<tr>
					<td bgcolor=".$EasyBookmarker["Background"]."><b>Site Description:</b><br>
					".bmElement("text","bmLDescription","",250)."</td>
				</tr>
				<tr>
					<td align=right>".bmElement("submit","Add","f_button")."</td>
				</tr>
				".bmElement("hidden","bmParent",$parent).
				bmElement("hidden","action","add_link").bmElement()."
			</table><br>".
			$Error
			."</div>
		";
	} // if valid
} // End: Add Link page

// Start: Edit Link page
if (isset($page) && $page=="edit_link" && isset($id) && isset($parent)) {
$ResultHtml="";
	if (!isset($Stoitsov["User"])) { // invalid user
		$page="login";
		$Error="You need to be a registered user in order to edit the links.";
	} else { // valid
		if ($parent!=0) {
			$UnderCategory=bmMyFetch("SELECT * FROM bmCategory WHERE ID=$parent LIMIT 1");
		} else {
			$UnderCategory["CName"]="EasyBookmarker";
		}
		$EditLink=bmMyFetch("SELECT * FROM bmLink WHERE ID=$id LIMIT 1");
		$CatSelects=bmMyQuery("SELECT * FROM bmCategory ORDER BY BINARY CName;");
		$Categories[0]="EasyBookmarker";
		while ($CatSelect=mysql_fetch_array($CatSelects)) {
			$Categories[$CatSelect["ID"]]=$CatSelect["CName"];
		} // while category
		$ResultHtml.= bmHeading("Edit Bookmarks",1).
		"&nbsp;&nbsp;&nbsp;<b>Edit Link under ".$UnderCategory["CName"]."</b><br><br>
			<div align=center>
			<table border='0' cellspacing='1' cellpadding='2' bgcolor='".$EasyBookmarker["DarkColor"]."' width=200>
				<tr>
					<td>&nbsp;<font color=".$EasyBookmarker["Background"]."><b>.: Link Information</b></font></td>
				</tr>
				".bmElement("form",$PHP_SELF,"Link","POST")."
				<tr>
					<td bgcolor=".$EasyBookmarker["Background"]."><b>Move Link under:</b> [no change - no move]<br>
					".bmElement("select","bmParent",$Categories,$parent,250)."</td>
				</tr>
				<tr>
					<td bgcolor=".$EasyBookmarker["Background"]."><b>Link:</b> [255 Chars max]<br>
					".bmElement("text","bmLUrl",$EditLink["LUrl"],250)."</td>
				</tr>
				<tr>
					<td bgcolor=".$EasyBookmarker["Background"]."><b>Site Name:</b> [200 Chars max]<br>
					".bmElement("text","bmLName",$EditLink["LName"],250)."</td>
				</tr>
				<tr>
					<td bgcolor=".$EasyBookmarker["Background"]."><b>Site Description:</b><br>
					".bmElement("text","bmLDescription",$EditLink["LDescription"],250)."</td>
				</tr>
				<tr>
					<td align=right>".bmElement("submit","Change","f_button")."</td>
				</tr>
				".bmElement("hidden","action","edit_link").
				bmElement("hidden","parent",$parent).
				bmElement("hidden","bmID",$EditLink["ID"]).bmElement()."
			</table><br>".
			$Error.
			"<a href='$PHP_SELF?action=delete_link&bmID=$id' class=normal>You may delete this link.</a>"
			."</div>
		";
	} // if valid
} // End: Edit Link page


// Start: Quick Add
if (isset($page) && $page=="quick_add") {
		$ResultHtml="";
		$ResultHtml.=bmHeading("Quick Add",1).
		"&nbsp;&nbsp;&nbsp;<b>Add your favorite links on the fly.</b><br><ul>
		<p>There is a powerful function in EasyBookmarker called QuickAdd. You may add the page you are currently browsing with your
		favorite browser by clicking on a link in it's Favorites (Netscape Bookmarks). To achieve that, you must:</p>
		<b>M$ Internet Explorer</b><ul>
		<li>Right click the following link: <a href=\"javascript:document.location = 'http://".$HTTP_HOST.$PHP_SELF."?page=remote&name=' + escape(document.title) + '&url=' + escape(document.location)\" onClick=\"javascript:alert('You must drag this link to your browser\'s toolbar or add it to your favorites.'); return false\" class=normal>MyEasyBookmarker - QuickAdd</a>;</li>
		<li>Choose \"Add to Favorites...\" from the pop-up menu;</li>
		<li>Whenever you deside to add a page to the EasyBookmarker, simply click on \"MyEasyBookmarker - QuickAdd\" located in your Favorites menu.</li>
		</ul><br>
		<b>Netscape</b><ul>
		<li>Right click the following link: <a href=\"javascript:document.location = 'http://".$HTTP_HOST.$PHP_SELF."?page=remote&name=' + escape(document.title) + '&url=' + escape(document.location)\" onClick=\"javascript:alert('You must drag this link to your browser\'s toolbar or add it to your favorites.'); return false\" class=normal>MyEasyBookmarker - QuickAdd</a>;</li>
		<li>Choose \"File Bookmark for Link...\" from the pop-up menu;</li>
		<li>Whenever you deside to add a page to the EasyBookmarker, simply click on \"MyEasyBookmarker - QuickAdd\" located in your Bookmarks menu.</li>
		</ul><p>Hope you like it!</p></ul>
		";
}

if (isset($page) && $page=="remote") {
		$ResultHtml="";
		$ResultHtml.=bmHeading("User authorization",1).
		"&nbsp;&nbsp;&nbsp;You need to be registered user in order to add bookmarks.<br><br>
		<div align=center>
		<table border='0' cellspacing='1' cellpadding='2' bgcolor='".$EasyBookmarker["DarkColor"]."' width=200>
			<tr>
				<td colspan=2>&nbsp;<font color=".$EasyBookmarker["Background"]."><b>.: Login</b></font></td>
			</tr>
			".bmElement("form",$PHP_SELF,"Login","POST")."
			<tr>
				<td bgcolor=".$EasyBookmarker["Background"]." align=right><b>Username:</b></td>
				<td bgcolor=".$EasyBookmarker["Background"].">".bmElement("text","bmUsername",$bmUsername,100)."</td>
			</tr>
			<tr>
				<td bgcolor=".$EasyBookmarker["Background"]." align=right><b>Password:</b></td>
				<td bgcolor=".$EasyBookmarker["Background"].">".bmElement("password","bmPassword","",100)."</td>
			</tr>
			<tr>
				<td colspan=2 align=right>".bmElement("submit","Login","f_button")."</td>
			</tr>
			".bmElement("hidden","action","remote").
			bmElement("hidden","name",urldecode($name)).
			bmElement("hidden","url",urldecode($url)).
			bmElement()."
		</table><br>".
		$Error
		."</div>
	";
}
// End: Quick_Add







// Login page
if (isset($page) && $page=="login") {
	$ResultHtml="";
	$ResultHtml.=bmHeading("User authorization",1).
	"&nbsp;&nbsp;&nbsp;You need to be registered user in order to add, move, edit or delete bookmarks.<br><br>
	<div align=center>
	<table border='0' cellspacing='1' cellpadding='2' bgcolor='".$EasyBookmarker["DarkColor"]."' width=200>
		<tr>
			<td colspan=2>&nbsp;<font color=".$EasyBookmarker["Background"]."><b>.: Login</b></font></td>
		</tr>
		".bmElement("form",$PHP_SELF,"Login","POST")."
		<tr>
			<td bgcolor=".$EasyBookmarker["Background"]." align=right><b>Username:</b></td>
			<td bgcolor=".$EasyBookmarker["Background"].">".bmElement("text","bmUsername",$bmUsername,100)."</td>
		</tr>
		<tr>
			<td bgcolor=".$EasyBookmarker["Background"]." align=right><b>Password:</b></td>
			<td bgcolor=".$EasyBookmarker["Background"].">".bmElement("password","bmPassword","",100)."</td>
		</tr>
		<tr>
			<td colspan=2 align=right>".bmElement("submit","Login","f_button")."</td>
		</tr>
		".bmElement("hidden","action","login").bmElement()."
	</table><br>".
	$Error
	."</div>
	";
}

// ********************************************************************
// ********************** HTML Output
// ********************************************************************
//                                You may edit to suit your site design
//                  but *please* leave the donation button & author names

// Start HTML HEADER
echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<html>
<head>
<title>.: EasyBookmarker - v".$EasyBookmarker["version"]." :.</title>
<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=windows-1251\">
<META NAME=\"description\" CONTENT=\"EasyBookmarker Software - by http://software.stoitsov.com\">
<META NAME=\"author\" CONTENT=\"Idea&minor development - Mario Stoitsov, Script by Cyber/SAS\">
";

// CSS Style - Edit to fit your site design
echo "<style type=\"text/css\">
body {
	font: 11px Arial, Helvetica; color:black;
	background-color: ".$EasyBookmarker["Background"]."; scrollbar-DarkShadow-Color: ".$EasyBookmarker["DarkColor"].";
	scrollbar-Track-Color: ".$EasyBookmarker["DarkColor"]."; scrollbar-Face-Color:	".$EasyBookmarker["DarkColor"].";
	scrollbar-Shadow-Color:	".$EasyBookmarker["Background"]."; scrollbar-Highlight-Color: ".$EasyBookmarker["Background"].";
	scrollbar-3dLight-Color: ".$EasyBookmarker["DarkColor"]."; scrollbar-Arrow-Color: ".$EasyBookmarker["Background"].";
}
td {
	font: 11px Arial, Helvetica; color: black;
}
table.main_tbl {
	border: 1px dotted ".$EasyBookmarker["DarkColor"].";
}
.h1s {
	font: 18px Verdana; font-weight:bold; color: ".$EasyBookmarker["DarkColor"].";
}
.f_text {
	font: 11px Arial, Helvetica;
	color: black;
	background-color: ".$EasyBookmarker["Background"].";
	border: 1px dotted ".$EasyBookmarker["DarkColor"].";
}
.f_button {
	font: 11px Arial, Helvetica;
	color: ".$EasyBookmarker["Background"].";
	background-color: ".$EasyBookmarker["DarkColor"].";
	border: 1px solid black;
}
a:link.normal, a:visited.normal {
	font: 11px Verdana; color: ".$EasyBookmarker["DarkColor"]."; text-decoration:none;
}
a:hover.normal {
	font: 11px Verdana; color: red; text-decoration:none;
}
</style>
";

// Start HTML BODY
echo "</head>
<body leftmargin='0' rightmargin='0' topmargin='2'>
<table border='0' cellspacing='0' cellpadding='0' width='100%'>
	<tr>
		<td><a href='$PHP_SELF'><img src='logo.gif' width='400' height='129' alt='EasyBookmarker' border='0'></a><br></td>
		<td width='100%' background='topbg.gif'>".bmTr()."<br></td>
		<td><a href='http://software.stoitsov.com' target=_stoitsov.com><img src='freesoftware.gif' width='305' height='129' alt='Get more free software!' border='0'></a><br></td>
	</tr>
</table>
".bmTr(1,3)."<br>
<table border='0' cellspacing='0' cellpadding='0' width='100%'>
".bmElement("form",$PHP_SELF,"Search","POST")."
	<tr>
		<td nowrap>&nbsp;<b>Search for:</b>&nbsp;</td>
		<td nowrap>".bmElement("text","bmSearch","",100).bmElement("submit","Go!","f_button")."</td>
		".bmElement("hidden","page","search").bmElement()."
		<td nowrap>&nbsp;&nbsp;&nbsp;<b>User:</b> ".
		(!isset($Stoitsov["User"]) ? "<i>Guest</i> [<a href='$PHP_SELF?page=login' class=normal>Login</a>]" : "<i>".$Stoitsov["User"]."</i> [<a href='$PHP_SELF?action=logout' class=normal>Logout</a>]" )
		."</td><td nowrap>&nbsp;".(isset($Stoitsov["User"]) ? "&nbsp;&nbsp;<img src='edit_link.gif' width='16' height='16' alt='' border='0'><br>" : "" )."</td>
		<td nowrap>&nbsp;".(isset($Stoitsov["User"]) ? "<b>Bookmarks:</b> <a href='$PHP_SELF?page=import' class=normal>Import</a>/<a href='$PHP_SELF?page=export' class=normal>Export</a>" : "" )."</td>
		<td nowrap>".AllFolders("expand")."<img src='folder_dark.gif' width='16' height='16' alt='Expand All' border='0' hspace=4></a></td>
		<td nowrap>".AllFolders("expand")."Expand All</a></td>
		<td nowrap>".AllFolders("collapse")."<img src='folder_light.gif' width='16' height='16' alt='Collapse All' border='0' hspace=4></a></td>
		<td nowrap>".AllFolders("collapse")."Collapse All</a></td>
		<td nowrap><a href='$PHP_SELF?page=quick_add' class=normal><img src='new_link.gif' width='16' height='16' alt='' border='0' hspace=2></a><br></td>
		<td width=100%><a href='$PHP_SELF?page=quick_add' class=normal>Quick Add</a>".bmTr()."<br></td>
	</tr>".bmElement()."
	<tr>
		<td width='100%' colspan='11'>".bmTr(1,3)."<br></td>
	</tr>
	<tr>
		<td width='100%' bgcolor='".$EasyBookmarker["DarkColor"]."' colspan='11'>".bmTr(1,1)."<br></td>
	</tr>
</table>
<div align=right>
<b>Order:</b>
<a href='$PHP_SELF?setOrder=1' class=normal>".($Order==1 ? "<b>A-Z</b>" : "A-Z" )."</a>,
<a href='$PHP_SELF?setOrder=2' class=normal>".($Order==2 ? "<b>Newest</b>" : "Newest" )."</a>,
<a href='$PHP_SELF?setOrder=3' class=normal>".($Order==3 ? "<b>Visited</b>" : "Visited" )."</a>,
<a href='$PHP_SELF?setOrder=4' class=normal>".($Order==4 ? "<b>Modified</b>" : "Modified" )."</a>,
<a href='$PHP_SELF?setOrder=5' class=normal>".($Order==5 ? "<b>Rated</b>" : "Rated" )."</a> | <b>Show:</b>
<a href='$PHP_SELF?page=show_links&setChart=1' class=normal>".($Chart==1 ? "<b>A-Z</b>" : "A-Z" )."</a>,
<a href='$PHP_SELF?page=show_links&setChart=2' class=normal>".($Chart==2 ? "<b>Newest</b>" : "Newest" )."</a>,
<a href='$PHP_SELF?page=show_links&setChart=3' class=normal>".($Chart==3 ? "<b>Visited</b>" : "Visited" )."</a>,
<a href='$PHP_SELF?page=show_links&setChart=4' class=normal>".($Chart==4 ? "<b>Modified</b>" : "Modified" )."</a>,
<a href='$PHP_SELF?page=show_links&setChart=5' class=normal>".($Chart==5 ? "<b>Rated</b>" : "Rated" )."</a>
&nbsp;&nbsp;
</div>
<br>
";

// Output current screen
if (!isset($page) && !isset($Stoitsov["User"])) {
	echo "<div align=center><table border=0 width=95%><tr><td width=70% valign=top>".
        $ResultHtml."</td><td valign=top width=30%>".bmHeading("Last 30 visited",2).ShowBrief("Visit",30)."</td></tr></table></div>";
} else {
	echo $ResultHtml;
}

// HTML FOOTER START
echo "<br><br><table border='0' cellspacing='0' cellpadding='0' width='100%'>
	<tr>
		<td width='100%' bgcolor='".$EasyBookmarker["DarkColor"]."'>".bmTr(1,1)."<br></td>
	</tr>
	<tr>
                <td width='100%' align=right>
                <font color='".$EasyBookmarker["DarkColor"]."'><b>EasyBookMarker</b> v".$EasyBookmarker["version"]." is a free software by </font><a href='http://software.stoitsov.com' class=normal target=_stoitsov.com>Software.Stoitsov.com</a>&nbsp;&nbsp;<br>
                <a href='https://www.paypal.com/affil/pal=mario%40stoitsov.com' target=_donate><img src='donate.gif' width='110' height='23' alt='Support us!' border='0' hspace=4 align=right></a>
                <font color='".$EasyBookmarker["DarkColor"]."'><b>To keep it free & developing:</b></font>

                </td>
	</tr>
</table>
";
// End HTML Output
echo "</body>\n</html>";

/*	******************************************************************
        ********************** EasyBookmarker v2.01b *********************
	******************************************** software.stoitsov.com  */
?>
