<?php
	include("head.php");
?>
<br><br>
	<table bgcolor="#003366" cellpadding="0" border="1" cellspacing="0" align="center" width="95%" style="BORDER-COLLAPSE: collapse" bordercolor="#000000">
	<?
	if(!$step)
	{
	?>
	<form action="install.php?step=2" method="POST">
	<tr>
		<td colspan="2" width="100%" bgcolor="#000000">Database Information</td>
	</tr>
	<tr>
		<td width="35%"><b>Database Host:</b><br><font size="2">(Default is localhost)</font></td>
		<td width="65%"><input type="text" maxlength="255" size="35" name="dbhost" value="localhost"></td>
	</tr>
	<tr>
		<td width="35%"><b>Database Username:</b></td>
		<td width="65%"><input type="text" maxlength="255" size="35" name="dbuser"></td>
	</tr>
	<tr>
		<td width="35%"><b>Database Password:</b></td>
		<td width="65%"><input type="password" maxlength="255" size="35" name="dbpswd"></td>
	</tr>
	<tr>
		<td width="35%"><b>Database Name:</b><br><font size="2">(The name of the database you wsih to use)</font></td>
		<td width="65%"><input type="text" maxlength="255" size="35" name="dbname"></td>
	</tr>
	<tr>
		<td colspan="2" width="100%" bgcolor="#000000">Color and Table Configuration</td>
	</tr>
	<tr>
		<td width="35%"><b>Table Background Color:</b><br><font size="2">(Use color name or color code I.E. #8080FF)</font></td>
		<td width="65%"><input type="text" maxlength="10" size="10" name="bgcolor"></td>
	</tr>
	<tr>
		<td width="35%"><b>Cell Padding:</b></td>
		<td width="65%"><input type="text" maxlength="5" size="10" name="cellpadding"></td>
	</tr>
	<tr>
		<td width="35%"><b>Cell Spacing:</b></td>
		<td width="65%"><input type="text" maxlength="5" size="10" name="cellspacing"></td>
	</tr>
	<tr>
		<td width="35%"><b>Border Width:</b><br><font size="2">(Type 0 for no border)</font></td>
		<td width="65%"><input type="text" maxlength="5" size="10" name="border"></td>
	</tr>
	<tr>
		<td width="35%"><b>Border Color:</b><br><font size="2">(Leave blank if no border)</font></td>
		<td width="65%"><input type="text" maxlength="10" size="10" name="bordercolor"></td>
	</tr>
	<tr>
		<td width="35%"><b>Header Color:</b><br><font size="2">(Use color name or color code I.E. #8080FF)</font></td>
		<td width="35%"><input type="text" maxlength="10" size="10" name="header"></td>
	</tr>
	<tr>
		<td width="35%"><b>Table Alignment:</b></td>
		<td width="65%"><input type="text" maxlength="10" size="10" name="alignment"></td>
	</tr>
	<tr>
		<td width="35%"><b>Table Width:</b></td>
		<td width="65%"><input type="text" maxlength="10" size="10" name="tbwidth"></td>
	</tr>
	<tr>
		<td width="35%"><b>Table CSS Styles:</b><br><font size="2">(Leave blank for none)</font></td>
		<td width="65%"><input type="text" maxlength="255" size="35" name="tbstyle"></td>
	</tr>
	<tr>
		<td colspan="2" width="100%" bgcolor="#000000">Subscribe/Unsubscribe Form Configuration</td>
	</tr>
	<tr>
		<td width="35%"><b>Ask for User's Name?</b></td>
		<td width="65%"><input type="radio" name="askname" value="yes" checked>&nbsp;Yes | <input type="radio" name="askname" value="no">&nbsp;No</td>
	</tr>
	<tr>
		<td width="35%"><b>Name Text:</b><br><font size="2">(Only if checked yes above)</font></td>
		<td width="65%"><input type="text" maxlength="255" size="35" name="nametext" value="Your Name:"></td>
	</tr>
	<tr>
		<td width="35%"><b>Email Text:</b></td>
		<td width="65%"><input type="text" maxlength="255" size="35" name="emailtext" value="Your Email:"></td>
	</tr>
	<tr>
		<td width="35%"><b>Subscription Code Text:</b></td>
		<td width="65%"><input type="text" maxlength="255" size="35" name="subcode" value="Your Subscription Code:"></td>
	</tr>
	<tr>
		<td width="35%"><b>Subscribe Text:</b><br><font size="2">(I.E. Subscribe to our Newsletter)</font></td>
		<td widht="65%"><input type="text" maxlength="255" size="35" name="subtext"></td>
	</tr>
	<tr>
		<td width="35%"><b>Unsubscribe Text:</b><br><font size="2">(I.E. Unsubscribe from our Newsletter)</font></td>
		<td widht="65%"><input type="text" maxlength="255" size="35" name="unsubtext"></td>
	</tr>
	<tr>
		<td width="35%"><b>Subscribe Submit Text:</b><br><font size="2">(The text on the submit button to subscribe)</td>
		<td width="65%"><input type="text" maxlength="255" size="35" name="subscribe_submit" value="Subscribe!"></td>
	</tr>
	<tr>
		<td width="35%"><b>Unsubscribe Submit Text:</b><br><font size="2">(The text on the submit button to unsubscribe)</td>
		<td width="65%"><input type="text" maxlength="255" size="35" name="unsubscribe_submit" value="Unsubscribe"></td>
	</tr>
	<tr>
		<td colspan="2" width="100%" bgcolor="#000000">Newsletter Configuration</td>
	</tr>
	<tr>
		<td width="35%"><b>Admin Password:</b></td>
		<td width="65%"><input type="password" maxlength="16" size="35" name="adminpswd"></td>
	</tr>
	<tr>
		<td width="35%"><b>Subscribed Email Subject:</b><br><font size="2">(Subject of subscription email)</font></td>
		<td width="35%"><input type="text" name="sub_email" maxlength="255" size="35"></td>
	</tr>
	<tr>
		<td width="35%"><b>Subscribed Text:</b><br><font size="2">(The text shown when a user has subscribed)</font></td>
		<td width="65%"><textarea name="success_subscribe" cols="29" rows="5">You have been subscribed. You will receive an email in a few minutes containing important information if you wish to unsubscribe someday.</textarea></td>
	</tr>
	<tr>
		<td width="35%"><b>Unsubscribed Text:</b><br><font size="2">(The text shown when a user has unsubscribed)</font></td>
		<td width="65%"><textarea name="success_unsubscribe" cols="29" rows="5">You have been unsubscribed. I'm sorry to see you leave the newsletter.</textarea></td>
	</tr>
	<tr>
		<td width="35%"><b>Subscription Email Fail Text:</b><br><font size="2">(The text shown when the subscribe email has not sent to user)</font></td>
		<td width="65%"><textarea name="email_fail" cols="29" rows="5">Subscription email was not sent. Contact us for the subscription information.</textarea></td>
	</tr>
	<tr>
		<td width="35%"><b>Doesn't Match Text:</b><br><font size="2">(Text shown when email and subscription code do not match</font></td>
		<td width="65%"><textarea name="no_match" cols="29" rows="5">The subscription code you gave and the email you gave do not match. You have not been unsubscribed.</textarea></td>
	</tr>
	<tr>
		<td width="35%"><b>Newsletter Name:</b></td>
		<td width="65%"><input type="text" name="newsletter" maxlength="255" size="35"></td>
	</tr>
	<tr>
		<td width="35%"><b>Website URL:</b></td>
		<td width="65%"><input type="text" name="website" maxlength="255" size="35"></td>
	</tr>
	<tr>
		<td width="35%"><b>Webmaster's Email:</b><bR><font size="2">(Tip: Put your name and then email in greater and less then signs. I.E. Stephen Craton &lt;webmaster@melchior.us&gt;</td>
		<td width="65%"><input type="text" name="master_email" maxlength="255" size="35"></td>
	</tr>
	<tr>
		<td colspan="2" width="100%" bgcolor="#000000"><center><input type="submit" name="submit" value="Install Tapped Newsletter"> or <input type="reset" name="reset" value="Start Over"></center></td>
	</tr>
	<?
	}
	elseif($step == "2")
	{
		$line1 = "<?\n\n";
		$line2 = "//Tapped Newsletter Copyright� 2002 WiredPHP\n\n";
		$line3 = "\$host = \"$dbhost\";\n";
		$line4 = "\$username = \"$dbuser\";\n";
		$line5 = "\$password = \"$dbpswd\";\n";
		$line6 = "\$database = \"$dbname\";\n";
		$line7 = "\$tb_bgcolor = \"$bgcolor\";\n";
		$line8 = "\$padding = \"$cellpadding\";\n";
		$line9 = "\$spacing = \"$cellspacing\";\n";
		$line10 = "\$border = \"$border\";\n";
		$line11 = "\$bordercolor = \"$bordercolor\";\n";
		$line12 = "\$head = \"$header\";\n";
		$line13 = "\$align = \"$alignment\";\n";
		$line14 = "\$width = \"$tbwidth\";\n";
		$line15 = "\$style = \"$tbstyle\";\n";
		$line16 = "\$name2 = \"$askname\";\n";
		$line17 = "\$email_text = \"$emailtext\";\n";
		$line18 = "\$code_text = \"$subcode\";\n";
		$line19 = "\$subscribe_text = \"$subtext\";\n";
		$line20 = "\$unsbuscribe_text = \"$unsubtext\";\n";
		$line21 = "\$submit_subscribe = \"$subscribe_submit\";\n";
		$line22 = "\$psswd = \"$adminpswd\";\n";
		$line23 = "\$subscribe_subject = \"$sub_email\";\n";
		$line24 = "\$success_subscribe = \"$success_subscribe\";\n";
		$line25 = "\$unsubscribed = \"$success_unsubscribe\";\n";
		$line26 = "\$failed_email = \"$email_fail\";\n";
		$line27 = "\$code_match = \"$no_match\";\n";
		$line28 = "\$newsletter = \"$newsletter\";\n";
		$line29 = "\$website = \"$website\";\n";
		$line30 = "\$webmaster_email = \"$master_email\";\n";
		$line31 = "\$name_text = \"$nametext\";\n";
		$line32 = "\$submit_unsubscribe = \"$unsubscribe_submit\";\n";
		$line33 = "\n\n";
		$line34 = "?>";
		
		$output = $line1.$line2.$line3.$line4.$line5.$line6.$line7.$line8.$line9.$line10.$line11.$line12.$line13.$line14.$line15.$line16.$line17.$line18.$line19.$line20.$line21.$line22.$line23.$line24.$line25.$line26.$line27.$line28.$line29.$line30.$line31.$line32.$line33;
		
		$fp = fopen("cfg.php", "w");
		$install = fwrite($fp, $output);
		
		$line1 = "<?\n";
		$line2 = "function db_connect()\n";
		$line3 = "{\n";
		$line4 = "\$result = mysql_pconnect(\"$dbhost\", \"$dbuser\", \"$dbpswd\");\n";
		$line5 = "if(!\$result)\n";
		$line6 = "	return false;\n";
		$line7 = "if(!mysql_select_db(\"$dbname\"))\n";
		$line8 = "	return false;\n\n";
		$line9 = "return \$result;\n";
		$line10 = "}\n?>";
		
		$output = $line1.$line2.$line3.$line4.$line5.$line6.$line7.$line8.$line9.$line10;

		$fp2 = fopen("db.php", "w");
		$install2 = fwrite($fp2, $output);
		
		function db_connect($dbhost, $dbuser, $dbpswd, $dbname)
		{
			$result = mysql_pconnect("$dbhost", "$dbuser", "$dbpswd");
			if(!$result)
				return false;
			if(!mysql_select_db("$dbname"))
				return false;
			return $result;
		}
		$conn = db_connect($dbhost, $dbuser, $dbpswd, $dbname);
		$sql = "CREATE TABLE newsletter (id int(255) NOT NULL auto_increment,name varchar(255) NOT NULL default '', email varchar(255) NOT NULL default '', code varchar(255) NOT NULL default '', PRIMARY KEY  (id)) TYPE=MyISAM;";
		$install3 = mysql_query($sql, $conn);
		
		if(!$install || !$install2 || !$install3)
		{
			echo "<tr><td>Installation Failed! <a href='mailto:webmaster@melchior.us'>Email me</a> for help.</td></tr>";
		}
		else
		{
			echo "<tr><td>Tapped Newsletter is now installed! Have fun using it and be sure to check more scripts out at <a href='http://php.melchior.us'>WiredPHP</a>.</td></tr>";
		}
	}
	?>
	</table>
<?php
	include("foot.php");
?>