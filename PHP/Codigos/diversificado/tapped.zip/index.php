<?php
	include("head.php");
	include("cfg.php");
?>
<br><br>
	<? echo "<table bgcolor='$tb_bgcolor' cellpadding='$padding' border='$border' cellspacing='$spacing' align='$align' width='$width' style='$style' bordercolor='$bordercolor'>"; ?>
	<form action="subscribe.php" method="POST">
	<tr>
		<td colspan="2" width="100%" bgcolor="<? echo $head; ?>"><? echo "$subscribe_text"; ?></td>
	</tr>
	<?
		if($name2 == "yes")
		{
	?>
	<tr>
		<td width="35%"><? echo $name_text; ?></td>
		<td width="65%"><input type="text" name="name" value="" maxlength="255"></td>
	</tr>
	<?
		}
	?>
	<tr>
		<td width="35%"><? echo $email_text; ?></td>
		<td width="65%"><input type="text" name="email" value="" maxlength="255"></td>
	</tr>
	<tr>
		<td width="100%" colspan="2" align="center"><input type="submit" name="subscribe" value="<? echo $submit_subscribe; ?>"></td>
	</tr>
	</form>
	<form action="unsubscribe.php" method="POST">
	<tr>
		<td colspan="2" width="100%" bgcolor="#000000"><? echo $unsbuscribe_text; ?></td>
	</tr>
	<tr>
		<td width="35%"><? echo $name_text; ?></td>
		<td width="35%"><input type="text" name="email" value="" maxlength="255"></td>
	</tr>
	<tr>
		<td width="35%"><? echo $code_text; ?></td>
		<td width="65%"><input type="text" name="code" maxlength="16" value=""></td>
	</tr>
	<tr>
		<td width="100%" colspan="2" align="center"><input type="submit" name="unsubscribe" value="<? echo $submit_unsubscribe; ?>"></td>
	</tr>
	</form>
	</table>
<?php
	include("foot.php");
?>