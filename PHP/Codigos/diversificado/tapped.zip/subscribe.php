<?
	include("head.php");
	include("cfg.php");
	include("db.php");
?>
		<br><br>
		<?php
			
			function valid_email($email)
			{
				if(ereg("^[a-zA-Z0-9_]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-\.]+$", $email))
					return true;
				else
					return false;
			}
			
			if(empty($HTTP_POST_VARS))
			{
				echo "Please <a href='javascript:history.back(-1)'>go back</a> and fill in all of the form.";
				exit;
			}
			if(!valid_email($email))
			{
				echo "Please <a href='javascript:history.back(-1)'>go back</a> and give us a valid email address.";
				exit;
			}
			
			$code = date("dhtsg");
			$sql = "insert into newsletter values ('', '$name', '$email', '$code')";
			$conn = db_connect();
			$result = mysql_query($sql, $conn);
			if(!$result)
			{
				echo "Subscription failed. Try again later.<br>";
				echo mysql_error() . "<br>";
			}
			else
			{
				echo "$success_subscribe<br><br>";
				$to = $email;
				$subject = "$subscribe_subject";
				$content = "Below is important information about your newsletter subscripton to $website. You must keep this if you want to unsubscribe.\n\n Name: ".$name."\n Email: ".$email."\n Subscription Code: ".$code."\n\nIf you subscribed by accident, go here and enter the subscription code given above: $website\n\nThanks,\n$webmaster_email";
				$from = "From: $webmaster_email";
				
				$mail = mail($to, $subject, $content, $from);
				
				if(!$mail)
				{
					echo "<br><br>$failed_email";
				}
			}			
			
		?>
	</td>
</tr>
</table>
<?
	include("foot.php");
?>