<?
	include("head.php");
	include("cfg.php");
	include("db.php");
?>
		<br><br>
		<?php
			
			function valid_email($email)
			{
				if(ereg("^[a-zA-Z0-9_]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-\.]+$", $email))
					return true;
				else
					return false;
			}
			
			if(empty($HTTP_POST_VARS))
			{
				echo "Please <a href='javascript:history.back(-1)'>go back</a> and fill in all of the form.";
				exit;
			}
			if(!valid_email($email))
			{
				echo "Please <a href='javascript:history.back(-1)'>go back</a> and give us a valid email address.";
				exit;
			}
			function check_code($email, $code)
			{
				$sql = "select * from newsletter where email='$email' and code='$code'";
				$conn = db_connect();
				if(!$conn)
					return 0;
				$result = mysql_query($sql, $conn);
				if(!$result)
					return 0;
				if(mysql_num_rows($result)>0)
					return 1;
				else
					return 0;				
			}
			if(!check_code($email, $code))
			{
				echo "$code_match";
				exit;
			}
			
			$sql = "delete from newsletter where email='$email' and code='$code'";
			$conn = db_connect();
			$delete = mysql_query($sql, $conn);
			if(!$delete)
			{
				echo "Unable to unsubscribe from newsletter. Try again later.<br>";
				echo mysql_error();
			}
			else
			{
				echo "$unsubscribed";
			}							
		?>
	</td>
</tr>
</table>
<?
	include("foot.php");
?>