Tapped Newslleter v1.0
Developed by Stephen Craton
Copyright� 2002 WiredPHP
---------------------------

Thank you for downloading Tapped Newsletter. Be sure to check out
more PHP script from WiredPHP at http://php.melchior.us.

-------------|
Requirments: |
-------------|

1. A webserver with PHP4 and MySql 3 installed or newer versions
2. Common Sense

-------------|
Installation:|
-------------|

1. Configure the head.php and foot.php files to your liking.
2. Upload all the files to your web server.
3. CHMOD cfg.php and db.php to 777 (Writeable and excuteable by all)
4. Open install.php in your favorite browser and follow the instructions
5. After installing, delete the install.php file from your server.
6. You're all set to use Tapped Newsletter!

-----------|
How to Use:|
-----------|

To send out an email to the newsletter, go to the email.php file on your
server and type in the password you specified during instalation as your
admin password. Then follow the instructions. (FIX) To end a line and go
to a new one, you MUST type in <br>.

--------------------------------------------------------------------------
DO NOT REMOVE THE COPYRIGHT UNLESS YOU HAVE PERMISSION FROM STEPHEN CRATON
http://php.melchior.us-------------------webmaster@melchior.us------------
--------------------------------------------------------------------------
Tapped Newsletter COPYRIGHT� 2002 WiredPHP