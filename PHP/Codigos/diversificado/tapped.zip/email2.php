<?
	include("head.php");
	include("cfg.php");
	include("db.php");
?>
		<br><br>
		<? echo "<table bgcolor='$tb_bgcolor' cellpadding='$padding' border='$border' cellspacing='$spacing' align='$align' width='$width' style='$style' bordercolor='$bordercolor'>"; ?>
		<?php
			if($empswd432 != "Email")
			{
				echo "You do not have permission to email the user group.";
				exit;
			}
			$sql = "select * from newsletter";
			$conn = db_connect();
			$result = mysql_query($sql, $conn);
			if(!$result)
			{
				echo "Error:<br>".mysql_error();
			}
			while($row = mysql_fetch_array($result)) {
			$email = stripslashes($row["email"]);
			$name = stripslashes($row["name"]);
			$content = stripslashes($content);
			$content = str_replace("<br>", "\n", $content);
			$from = "From: $webmaster_email";
			$to = "To: $name <$email>";
			$subject = "$newsletter";
			mail($to, $subject, $content, $from);
			echo "<tr><td>Email to <i>$name</i> at <b>$email</b> sent!</td></tr>";
			}
		?>
		</table>
	</td>
</tr>
</table>
<?
	include("foot.php");
?>