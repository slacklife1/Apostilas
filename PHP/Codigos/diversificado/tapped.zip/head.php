<html>
<head>
  <title>Tapped News</title>
  <meta name="description" content="">
  <meta name="keywords" content="">
  <style type="text/css">
  <!--
       A:link {text-decoration: none;}
       A:visited {text-decoration: none;}
  -->
  </style>
</head>
<body bgcolor="#003366" text="#FFFFFF" link="#C0C0C0" vlink="#969696">
<table bgcolor="#003366" border="0" cellpadding="0" cellspacing="0" align="Center" width="100%">
<tr>
	<td><img src="logo.gif" width="225" height="65" alt="Newsletter" border="0" align="right"></td>
</tr>
<tr>
	<td><p align="left" style="text-indent:.2in">To become part of the newsletter, please fill out the form labeled '<b>Subscribe</b>'. If you want to unsubscribe from the newsletter, fill out the form labeled '<b>Unsubscribe</b>'.</p></td>
</tr>
</table>