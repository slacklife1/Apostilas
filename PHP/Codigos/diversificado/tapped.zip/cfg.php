<?

//Tapped Newsletter Copyright� 2002 WiredPHP

$host = "localhost";
$username = "gorzekc_tenchiws";
$password = "malone";
$database = "gorzekc_tenchiws";
$tb_bgcolor = "#003366";
$padding = "0";
$spacing = "0";
$border = "0";
$bordercolor = "";
$head = "#000000";
$align = "center";
$width = "95%";
$style = "";
$name2 = "yes";
$email_text = "Your Email:";
$code_text = "Your Subscription Code:";
$subscribe_text = "Subscribe";
$unsbuscribe_text = "Unsubscribe";
$submit_subscribe = "Subscribe!";
$psswd = "blek123";
$subscribe_subject = "Newsletter Subscription";
$success_subscribe = "You have been subscribed. You will receive an email in a few minutes containing important information if you wish to unsubscribe someday.";
$unsubscribed = "You have been unsubscribed. I\'m sorry to see you leave the newsletter.";
$failed_email = "Subscription email was not sent. Contact us for the subscription information.";
$code_match = "The subscription code you gave and the email you gave do not match. You have not been unsubscribed.";
$newsletter = "Tapped Newsletter";
$website = "http://www.melchior.us";
$webmaster_email = "Stephen Craton <webmaster@melchior.us>";
$name_text = "Your Name:";
$submit_unsubscribe = "Unsubscribe";


