<?
function db_connect()
{
$result = mysql_pconnect("localhost", "gorzekc_tenchiws", "malone");
if(!$result)
	return false;
if(!mysql_select_db("gorzekc_tenchiws"))
	return false;

return $result;
}
?>