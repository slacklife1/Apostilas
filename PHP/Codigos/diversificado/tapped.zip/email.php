<?
	include("head.php");
	include("cfg.php");
?>
		<br><br>
		<? echo "<table bgcolor='$tb_bgcolor' cellpadding='$padding' border='$border' cellspacing='$spacing' align='$align' width='$width' style='$style' bordercolor='$bordercolor'>"; ?>
		<?php
			if(!$pass)
			{
		?>
		<form action="<? $PHP_SELF ?>" method="POST">
		<tr>
			<td width="35%"><b>Password:</b></td>
			<td width="65%"><input type="password" name="psswrd" value="" maxlength="255"></td>
		</tr>
		<tr>
			<td width="100%" colspan="2" align="center"><input type="submit" name="pass" value="Enter"></td>
		</tr>
		</form>
		<?
		}
		else
		{
			if($psswrd != "$psswd")
			{
				echo "You do not have permission to view this page!";
				exit;
			}
		?>
		<form action="email2.php" method="POST">
		<tr>
			<td width="100%" colspan="2" align="center"><textarea name="content" rows="15" cols="85"></textarea></td>
		</tr>
		<tr>
			<td width="100%" colspan="2" align="center"><input type="submit" name="empswd432" value="Email"></td>
		</tr>
		</form>
		<?
			}
		?>
		</table>
	</td>
</tr>
</table>
<?
	include("foot.php");
?>