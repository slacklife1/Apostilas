<br><br><br>
<!-- DO NOT REMOVE THIS FOLLOWING COPYRIGHT!!! -->
<div align="right"><font size="1">Tapped Newsletter Copyright&copy; 2002 <a href="http://php.melchior.us" target="_blank">WiredPHP</a></div>
</body>
</html>