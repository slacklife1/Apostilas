<?php
// $Horde: imp/scripts/custom_login.php,v 1.1.2.3 2002/04/23 04:49:18 chuck Exp $

// CUSTOMIZE THIS
define('IMP_BASE', '..');

require_once IMP_BASE . '/lib/base.php';
require_once IMP_BASE . '/config/servers.php';

/* Set up the password encryption token. */
Secret::setKey('imp');

/* Use the first server defined in servers.php. */
// CUSTOMIZE THIS

$server_key = 'localhost';

$server_value = $servers[$server_key]['server'];
$protocol_value = $servers[$server_key]['protocol'];
$port_value = $servers[$server_key]['port'];
$folders_value = $servers[$server_key]['folders'];
$namespace_value = $servers[$server_key]['namespace'];
$maildomain_value = $servers[$server_key]['maildomain'];
$realm_value = $servers[$server_key]['realm'];
$url = '/' . $registry->getParam('initial_page','horde');

?>

<!-- CUSTOMIZE THIS -->
<form action="<?= Horde::applicationUrl('redirect.php') ?>" method="post">
User: <input name="imapuser" type="text" size="20" /><br />
Pass: <input name="pass" type="password" size="20" /><br />
<input type="hidden" name="server" value="<?= $server_value ?>" />
<input type="hidden" name="protocol" value="<?= $protocol_value ?>" />
<input type="hidden" name="port" value="<?= $port_value ?>" />
<input type="hidden" name="folders" value="<?= $folders_value ?>" />
<input type="hidden" name="namespace" value="<?= $namespace_value ?>" />
<input type="hidden" name="maildomain" value="<?= $maildomain_value ?>" />
<input type="hidden" name="realm" value="<?= $realm_value ?>" />
<input type="hidden" name="url" value="<?= $url ?>" />
<input type="submit" value="Log in" />
</form>
