<script language="JavaScript" type="text/javascript">
<!--
function open_compose_win(args)
{
    var url = "<?= Horde::url($this->applicationWebPath('%application%/compose.php', $application)) ?>";
    if (url.indexOf('?') == -1) glue = '?';
    else glue = '&amp;';
    var now = new Date();
    var name = "compose_windows_" + now.getTime();
    if (args != "") {
        url = url + glue + args + "&amp;uniq=" + now.getTime();
    } else {
        url = url + glue + "uniq=" + now.getTime();
    }
    param = "toolbar=no,location=no,status=yes,scrollbars=yes,resizable=yes,width=700,height=650,left=0,top=0";
    eval("name = window.open(url, name, param)");
    if (!eval("name.opener")) {
        eval("name.opener = self");
    }
}
// -->
</script>
