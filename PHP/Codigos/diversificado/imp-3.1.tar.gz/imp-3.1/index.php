<?php
/*
 * $Horde: imp/index.php,v 2.58.2.2 2002/04/12 16:57:50 jan Exp $
 *
 * Copyright 1999-2002 Charles J. Hagenbuch <chuck@horde.org>
 * Copyright 1999-2002 Jon Parise <jon@horde.org>
 *
 * See the enclosed file COPYING for license information (GPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 */

define('IMP_BASE', dirname(__FILE__));
$imp_configured = (@is_readable(IMP_BASE . '/config/conf.php') &&
                   @is_readable(IMP_BASE . '/config/html.php') &&
                   @is_readable(IMP_BASE . '/config/mime_drivers.php') &&
                   @is_readable(IMP_BASE . '/config/prefs.php') &&
                   @is_readable(IMP_BASE . '/config/servers.php'));

if ($imp_configured) {
    include_once IMP_BASE . '/lib/base.php';

    $uri = 'redirect.php';
    if (!empty($HTTP_SERVER_VARS['QUERY_STRING'])) {
        $uri .= '?' . $HTTP_SERVER_VARS['QUERY_STRING'];
    }

    header('Location: ' . Horde::applicationUrl($uri, true));
    exit;

/* IMP isn't configured */
} else {
    include IMP_BASE . '/templates/index/notconfigured.inc';
}

?>
