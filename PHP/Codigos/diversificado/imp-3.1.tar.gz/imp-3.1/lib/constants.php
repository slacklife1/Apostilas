<?php
// $Horde: imp/lib/constants.php,v 1.1.2.2 2002/04/12 16:57:56 jan Exp $

// Actions
/** @const DELETE_MESSAGES Delete messages.            */ define('DELETE_MESSAGES', 101);
/** @const UNDELETE_MESSAGES Undeleted messages.       */ define('UNDELETE_MESSAGES', 102);
/** @const MOVE_MESSAGES Move messages.                */ define('MOVE_MESSAGES', 103);
/** @const COPY_MESSAGES Copy messages.                */ define('COPY_MESSAGES', 104);
/** @const IMP_LOGIN Run login attempt.                */ define('IMP_LOGIN', 105);
/** @const REPLY Reply to an email.                    */ define('REPLY', 106);
/** @const REPLY_ALL Reply to all.                     */ define('REPLY_ALL', 107);
/** @const FORWARD Forward an email.                   */ define('FORWARD', 108);
/** @const DELETE_FOLDER Delete a folder.              */ define('DELETE_FOLDER', 109);
/** @const CREATE_FOLDER Create a folder.              */ define('CREATE_FOLDER', 110);
/** @const RENAME_FOLDER Rename a folder.              */ define('RENAME_FOLDER', 111);
/** @const DOWNLOAD_ATTACH Download a part.            */ define('DOWNLOAD_ATTACH', 112);
/** @const VIEW_ATTACH View a part.                    */ define('VIEW_ATTACH', 113);
/** @const SEND_MESSAGE Send a message.                */ define('SEND_MESSAGE', 114);
/** @const VIEW_SOURCE View a raw email.               */ define('VIEW_SOURCE', 115);
/** @const SAVE_MESSAGE Save message disk.             */ define('SAVE_MESSAGE', 116);
/** @const SUBSCRIBE_FOLDER Subscribe folder.          */ define('SUBSCRIBE_FOLDER', 117);
/** @const UNSUBSCRIBE_FOLDER Unsubscribe folder.      */ define('UNSUBSCRIBE_FOLDER', 118);
/** @const BOUNCE_MESSAGE Bounce message.              */ define('BOUNCE_MESSAGE', 119);
/** @const BOUNCE_COMPOSE Display bounce form.         */ define('BOUNCE_COMPOSE', 120);
/** @const SPAM_REPORT Report an email as spam.        */ define('SPAM_REPORT', 121);
/** @const ADD_ATTACHMENT Add an attachment.           */ define('ADD_ATTACHMENT', 122);
/** @const DELETE_ATTACHMENT Remove an attachment.     */ define('DELETE_ATTACHMENT', 123);
/** @const MAILTO Send a message to an address.        */ define('MAILTO', 124);
/** @const COMPOSE Display the compose form.           */ define('COMPOSE', 125);
/** @const DRAFT Resume a message saved as a draft.    */ define('DRAFT', 126);
/** @const SAVE_DRAFT. Save a draft.                   */ define('SAVE_DRAFT', 127);
/** @const HIDE_DELETED Don't show deleted messages.   */ define('HIDE_DELETED', 128);
/** @const LOGIN_COMPOSE Go directly to compose.       */ define('LOGIN_COMPOSE', 129);
/** @const SEARCH Run a search on one or more folders. */ define('SEARCH', 130);
/** @const SPELL_CHECK Spell check a message.          */ define('SPELL_CHECK', 131);
/** @const SPELL_CHECK_FORWARD Spell check next words. */ define('SPELL_CHECK_FORWARD', 132);
/** @const SPELL_CHECK_CANCEL Discard spell check.     */ define('SPELL_CHECK_CANCEL', 133);
/** @const SPELL_CHECK_DONE Finish spell check.        */ define('SPELL_CHECK_DONE', 134);
/** @const MESSAGE_MISSING Report no such message.     */ define('MESSAGE_MISSING', 135);
/** @const PASSWD_INPUT Password form.                 */ define('PASSWD_INPUT', 136);
/** @const PASSWD_DISALLOW Password changing failed.   */ define('PASSWD_DISALLOW', 137);
/** @const PASSWD_CHANGE Change password.              */ define('PASSWD_CHANGE', 138);
/** @const EXPAND_FOLDER Show any subfolders.          */ define('EXPAND_FOLDER', 139);
/** @const COLLAPSE_FOLDER Hide any subfolders.        */ define('COLLAPSE_FOLDER', 140);
/** @const EXPAND_ALL_FOLDERS Show every subfolder.    */ define('EXPAND_ALL_FOLDERS', 141);
/** @const COLLAPSE_ALL_FOLDERS Hide every subfolder.  */ define('COLLAPSE_ALL_FOLDERS', 142);
/** @const REFRESH_FOLDERS Refresh folder information. */ define('REFRESH_FOLDERS', 143);
/** @const POLL_FOLDER Check folders.                  */ define('POLL_FOLDER', 144);
/** @const NOPOLL_FOLDER Don't check folders.          */ define('NOPOLL_FOLDER', 145);
/** @const TOGGLE_SUBSCRIBED_VIEW Show subscribed/all. */ define('TOGGLE_SUBSCRIBED_VIEW', 146);
/** @const FLAG_MESSAGES Apply an IMAP flag.           */ define('FLAG_MESSAGES', 147);
/** @const PRINT_MESSAGE Display message for printing. */ define('PRINT_MESSAGE', 148);
/** @const FILTER Run filters.                         */ define('FILTER', 149);
/** @const FILTER_CREATE Create a new mailbox filter.  */ define('FILTER_CREATE', 150);
/** @const FILTER_MODIFY Change an existing filter.    */ define('FILTER_MODIFY', 151);
/** @const FILTER_DELETE Remove a filter.              */ define('FILTER_DELETE', 152);
/** @const FILTER_DOWN Apply a filter later.           */ define('FILTER_DOWN', 153);
/** @const FILTER_UP Apply a filter sooner.            */ define('FILTER_UP', 154);
/** @const EXPAND_ADDRESSES Expand message recipients. */ define('EXPAND_ADDRESSES', 155);
/** @const ADD_ADDRESS Add address to addressbook.     */ define('ADD_ADDRESS', 156);
/** @const DOWNLOAD_FOLDER Download folder as mbox.    */ define('DOWNLOAD_FOLDER', 157);
/** @const IMP_BLACKLIST Blacklist spammers            */ define('IMP_BLACKLIST', 158);
/** @const EMPTY_MAILBOX Empty a mailbox               */ define('EMPTY_MAILBOX', 159);
/** @const EXPUNGE_MAILBOX Expunge mailbox.            */ define('EXPUNGE_MAILBOX', 160);
/** @const SORTTHREAD Sort By Thread                   */ define('SORTTHREAD', 161);

// IMAP Flags
/** @const IMP_ALL Match all IMAP flags.      */ define('IMP_ALL', 0);
/** @const IMP_UNSEEN \\UNSEEN flag.          */ define('IMP_UNSEEN', 1);
/** @const IMP_DELETED \\DELETED flag.        */ define('IMP_DELETED', 2);
/** @const IMP_ANSWERED \\ANSWERED flag.      */ define('IMP_ANSWERED', 4);
/** @const IMP_FLAGGED \\FLAGGED flag.        */ define('IMP_FLAGGED', 8);
/** @const IMP_DRAFT \\DRAFT flag.            */ define('IMP_DRAFT', 16);
/** @const IMP_PERSONAL An email is personal. */ define('IMP_PERSONAL', 32);

?>
