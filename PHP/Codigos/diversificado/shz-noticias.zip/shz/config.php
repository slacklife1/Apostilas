<?php

//****************************************************************

// Aqui voc� coloca um nome de usuario para a autentica��o 
// no cadastro de noticias.

$nome="shz";

// Aqui voc� coloca uma senha para de usuario para a autentica��o 
// no cadastro de noticias.

$senha="";

// Aqui voc� coloca endere�o do servidor de MySQL.
// Ex. localhost  (servidor local)

$dbserver="localhost";

// Aqui voc� coloca o usuario para conex�o no servidor MySQL.
// Ex. root   (usuario com direito a tudo)

$dbuser="root";

// Aqui voc� coloca a senha do usuario para conex�o no servidor MySQL.
// Obs. caso seu servidor n�o tenha sido mudado voc� poode deixar sem senha 
// e com usuario root.

$dbpass="";

// Aqui voc� coloca o nome da dase de dados criada.
// Obs. Caso voce n�o tenha mudado essa op��o na instala��o deixe
// esse campo como esta, que � o pad�o.

$dbname="noticias";

// Aqui voc� coloca o nome da tabela para noticia criada.
// Obs. Caso voce n�o tenha mudado o arquivo install.php da
// instala��o n�o mude esse campo.

$dbtb="noticias";

// Aqui voc� coloca o nome da tabela para usuario criada.
// Obs. Caso voce n�o tenha mudado no arquivo install.php, (da
// instala��o) n�o mude esse campo.

$dbtbu="usuario";

// Aqui voc� coloca o endereco do seu site sem o http://.
// Ex. www.shz.com.br

$site="localhost";

//Aqui voc� coloca o caminho para o sistema de not�cias sem http:// e com / no final.
// Ex. www.shz.com.br/shz/not

$esite="localhost/shz/";

//Titulo do site
$tituloshz = "SHZ";

//Configura��o de cores e formata��o do texto do SHZ Not�cias
//Cor de fundo do SHZ Not�cias
$colorbg = "#ffffff";

//Cor de fundo da barra de rolagem
$colorbgb = "ffffff";

//Cor de detalhes da barra de rolagem
$colorbf = "000000";

//Cor do texto do SHZ Not�cias
$colortex = "#000000";

//Tamanho do texto padr�o
$sizetex = "2";

//Tamanho do texto pequeno
$sizetex1 = "1";

//Tamanho do texto grande
$sizetex2 = "3";

//Configura��o de cores de links
//Fundo de link (quando o mouse passar por cima do link o
//fundo do texto fica da cor definida abaixo
$colorbgt = "#bababa";

//Cor do texto quando o mouse passar por cima
$colortexl = "#ececec";

//Cor do texto quando voc� clicar no link
$colortexl2 = "#666666";

//Quando voc� clicar no link o fundo do texto fica da
//cor definida abaixo
$colorbgt2 = "#bababa";

/*
                          -==SHZ==-
			      David Fante & Audry Le�o Fante

                         DEUS � FIEL!

"Fez tamb�m Jac� um voto, dizendo:
Se Deus for comigo, e me guardar nesta jornada que empreendo, e me der p�o para comer e roupa
que me vista, de maneira que eu volte em paz para a casa de meu pai, ent�o, o Senhor ser� o
meu Deus;" Gn 28:20-21
*/
?>
