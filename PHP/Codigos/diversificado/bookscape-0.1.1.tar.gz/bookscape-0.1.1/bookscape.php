<?
// location of netscape bookmarks
$bookmarks = 'bookmarks.html';

// names of bookmark folders to skip 
$bookmarks_skip = 'Personal Toolbar Folder,ftp,secret';

// set to '1' to ignore unsorted bookmarks at start
$bookmarks_sort = 0;

// set to '1' to ignore bookmark seperators
$horizontal_skip = 0;

// change color settings to your liking
$set = (array(
	      bgcolor => '#001020',  /*background*/
	      txcolor => '#e0e0e0', /*text      */
	      lncolor => '#f0f0f0',/*link      */
	      tbcolor => '#103040'/*table     */
	      ));

//////////////////////////////////////////////////////
// End of configuration, may the source be with you //
//////////////////////////////////////////////////////

// version number
$bookmarks_vs="0.1.1";

// function for reading through bookmark folders
function ReadBookmarkFolder($buffer, $query_array0, $query_array1, $query_array2, $bookmarks_skip) {
  global $PHP_SELF;
  $target_num = strpos($buffer, '">', 5)+2;
  $target_len = strpos($buffer, '</H3>', 5) - $target_num;
  $query_array0 = substr($buffer, $target_num, $target_len);

  // echo unless instructed to ignore through $bookmarks_skip
  if ($query_array0) {
    $skip_it = 0;
    $tok = strtok($bookmarks_skip,',');
    while($tok) {
      $needle_probe = strcmp($query_array0, $tok);
      if (!$needle_probe) {
	$skip_it = 1;
      }
      $tok = strtok(',');
    }
    if (!$skip_it) {
      echo "<a name=\"$query_array0\"></a><a href=\"$PHP_SELF?target=$query_array0||$query_array1||$query_array2\"><b>$query_array0/</b></a><br>";
    }
  }
}

// function for reading through bookmark links
function ReadBookmarkLink($buffer,$query_array1) {
  echo substr($buffer, $query_array1+4);
  echo '<br>';
}


// html: this performs the initiatization of <html> and <body>
?>
<html>
<body <?echo "bgcolor=\"$set[bgcolor]\" text=\"$set[txcolor]\" link=\"$set[lncolor]\" vlink=\"$set[lncolor]\" alink=\"$set[lncolor]\" "?>>
<table><tr><td align="center" valign="top">
<?


// tokenize any available query string
$query_array = explode('||', (substr($QUERY_STRING,7)));

// work with any available query string
if ($QUERY_STRING) {
  $target_num = $query_array[1] + 36;
  $books=fopen("$bookmarks", 'r');
  // watch nesting level and apply compass to Bookmarks title
  if (($query_array[0]) && (!strstr($query_array[2], $query_array[0]))) {
    $query_array[2] = $query_array[2] . $query_array[0] . '/';
    $target_now = strtok($query_array[2],'/');
    while(($target_now) && ($target_now != $query_array[0])) {
      $target_int += 4;
      $target_now_tmp = $target_now_tmp . $target_now . '/';
      $target_all = $target_all . "/<a href=\"$PHP_SELF?target=$target_now||$target_int||$target_now_tmp\">$target_now</a>";
      $target_now = strtok('/');
    }
  } elseif (($query_array[0]) && (strstr($query_array[2], $query_array[0]))) {
    $target_now = strtok($query_array[2],'/');
    while(($target_now) && ($target_now != $query_array[0])) {
      $target_int += 4;
      $target_now_tmp = $target_now_tmp . $target_now . '/';
      $target_all = $target_all . "/<a href=\"$PHP_SELF?target=$target_now||$target_int||$target_now_tmp\">$target_now</a>";
      $target_now = strtok('/');
    }
  }
  $query_array[1] += 4;


  // html: this outputs the neat navigation menu
?>
<font color="<?echo $set[lncolor]?>" size="5">
<a href="<?echo $PHP_SELF?>">Bookmarks</a><?echo $target_all . "/" . $query_array[0]?><br>	
</font></td></tr><tr><td><font color="<?echo $set[lncolor]?>" size="4">
<?


   // nested inside string
   while (($buffer = fgets($books, 4096)) && (!$halted)) {
     // what a messy bugfix! things like (folder = 'webbies') and (folder = 'web') were getting confused at the same nesting depth,
     // also navigator exchibited nasty 'FOLDED ' state that required "-7" to compensate...
     // let me get everything working and I'll come back to this for optimisation.
     if ((!$start_folder) &&
	 ((substr($buffer, ($target_num + strlen($query_array[0])), 1) == '<') || (substr($buffer, ($target_num + strlen($query_array[0]) -7), 1) == '<') )&&  
	 ((substr($buffer, $target_num, strlen($query_array[0])) == $query_array[0]) || (substr($buffer, $target_num -7, strlen($query_array[0])) == $query_array[0])))
     {
       $start_folder = 1;
     }
     if ((substr($buffer, $query_array[1]-4, 5) == '<DL><') && ($start_folder)) {
       $engage = 1;
     }
     if ((substr($buffer, $query_array[1]-4, 5+1) == '</DL><') && ($engage)) {
       $halted = 1;
     }
     // read folder at the right time
     if ((substr($buffer, $query_array[1], 5) == '<DT><') && ($engage) && (!$halted)) {
       ReadBookmarkFolder($buffer, $query_array[0], $query_array[1], $query_array[2], $bookmarks_skip);
     }
     // read file at the right time
     if ((strstr($buffer, '<A HREF=')) && (substr($buffer, $query_array[1], 5) == '<DT><') && ($engage) && (!$halted)) {
       ReadBookmarkLink($buffer,$query_array[1]);
     }
     // read horizontal line at the right time
     if ((!$horizontal_skip) && (substr($buffer, $query_array[1], 4) == '<HR>') && ($engage) && (!$halted)) {
       echo '<hr>';
     }
   }
  fclose($books);
}

// without a query string, we can only work with bookmarks.html at start
else {
  $query_array[1] = 4;
  $books = fopen("$bookmarks", 'r');
  
  
  // html: not being nested leaves us with a simple navigation task
?>
<font color="<?echo $set[lncolor]?>" size="5">
<a href="<?echo $PHP_SELF?>">Bookmarks</a><br>	
</font></td></tr><tr><td><font color="<?echo $set[lncolor]?>" size="4">
<?


   // outside string
   while ($buffer = fgets($books, 4096)) {
     // read folder all the time
     if (substr($buffer, $query_array[1], 5) == '<DT><') {
       ReadBookmarkFolder($buffer, $query_array[0], $query_array[1], $query_array[2], $bookmarks_skip);
     }
     // read file all the time
     if ((!$bookmarks_sort) && (strstr($buffer, '<A HREF=')) && (substr($buffer, $query_array[1], 5) == '<DT><')) {
       ReadBookmarkLink($buffer,$query_array[1]);
     }
     if ((!$horizontal_skip) && (substr($buffer, $query_array[1], 4) == '<HR>')) {
       echo '<hr>';
     }
   }
  fclose($books);
}


// html: tidy up everything </body> </html>
?>
</font></td></tr><tr>
<td align="center"><font color="<?echo $set[lncolor]?>" size="3">
<br><a href="http://www.maritimesource.com/programmer/programming.php3"><?echo "BookScape-$bookmarks_vs"?></a><br></font>
</td></tr></table></body></html>
