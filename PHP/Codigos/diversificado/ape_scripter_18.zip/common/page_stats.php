<?
if ($page=="") {
	$browser  =  $HTTP_USER_AGENT ;
	$ip  =  $REMOTE_ADDR ;
	$refer = $HTTP_REFERER;

	//LOG ENTRY
	$row_stats = sql("INSERT INTO $stats_visitor_table VALUES('$default_dir','$ip','$browser',now(),'$refer')",0, $sDB, $nConnection);

	//OVERALL COUNT
	$row_stats = sql("SELECT * from stats_count where siteid='".$default_dir."'",0, $sDB, $nConnection);
	if ($row_stats["visitors"]) {
		$row_stats = sql("UPDATE stats_count set visitors = visitors + 1 WHERE siteid = '".$default_dir."'",0, $sDB, $nConnection);
	
	}
	else {
		$row_stats = sql("INSERT INTO stats_count VALUES ('".$default_dir."',1)",0, $sDB, $nConnection);
	
	}
	
}
else {
	//PAGE STATS
	if ($page) {
		$row_stats = sql("SELECT * from $stats_pages_table where page='".$page."'",0, $sDB, $nConnection);

		if ($row_stats["visitors"]) {
			$row_stats = sql("UPDATE $stats_pages_table set visitors = visitors + 1 WHERE page = '".$page."'",0, $sDB, $nConnection);
		}
		else {
			$row_stats = sql("INSERT INTO $stats_pages_table VALUES ('".$page."',1)",0, $sDB, $nConnection);
		}
	}

}
?>