<?

//This is tested and working, but you need GD library 
function IMG_MakeThumbnails($filename,$filetype,$filepaths,$filepatht,$filewidth,$fileheight,$smallstart) { 
	$filename = $filename; // file name on source path 
	$filetype = $filetype; // file type (gif or jpg in mime format like image/gif or image/pjpeg) 
	$filepaths = $filepaths; //source :: /usr/home/cardwww/www/images/ 
	$filepatht = $filepatht; //target :: /usr/home/cardwww/www/images/ 
	$filewidth = $filewidth; // resize image width 
	$filehight = $filehight; // resize image hight 
	$smallstart = $smallstart; // Small Image start with 

	if ($filetype =="jpg") { 
		$src_img = imagecreatefromjpeg($filepaths."/".$filename); 
		$dst_img = imagecreate($filewidth,$fileheight); 
		imagecopyresized($dst_img,$src_img,0,0,0,0,$filewidth,$fileheight,imagesx($src_img),imagesy($src_img)); 
		imagejpeg($dst_img, "$filepatht/$smallstart$filename"); 
	}
	else if ($filetype =="png") { 
		$src_img = imagecreatefrompng($filepaths."/".$filename); 
		$dst_img = imagecreate($filewidth,$fileheight); 
		imagecopyresized($dst_img,$src_img,0,0,0,0,$filewidth,$fileheight,imagesx($src_img),imagesy($src_img)); 
		imagepng($dst_img, "$filepatht/$smallstart$filename"); 
	} 
}

function IMG_ScaleHeight ($filename, $targetheight) {
  $size = getimagesize($filename);
  $targetwidth = $targetheight * ($size[0] / $size[1]);
  return $targetwidth;
}
        
function IMG_ScaleWidth ($filename, $targetwidth) {
  $size = getimagesize($filename);
  $targetheight = $targetwidth * ($size[1] / $size[0]);
  return $targetheight;
}

?>