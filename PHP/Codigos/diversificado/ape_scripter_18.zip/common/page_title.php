<?
echo $default_name;
if ($show_category) {
		echo " - ".ucwords($show_category);
}
else if (!$page && $start_page) {
		echo " - ".ucwords($start_page);
}
else if ($page) {
	if ($page == "story") {
		$row = sql("select subject from $item_table where post = ".$post,0, $sDB, $nConnection);
		echo " - ".$row["subject"];
	}
	else {
		if (substr($page,0,1)=="_") {
			echo " - ".ucwords(substr($page,1,strlen($page)));
		}
		else if (substr($page,0,2)=="s_" || substr($page,0,2)=="m_") {
			echo " - ".ucwords(substr($page,2,strlen($page)));
		}
		else {
			echo " - ".ucwords($page);
		}

	}
}


?>