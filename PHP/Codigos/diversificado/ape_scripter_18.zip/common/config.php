<?

//START EDITING --------------------------------

//USERLEVELS
$followups_called = "Comments";
$slideshow_speed = 5;

//Change the number of front page days displayed
$number_of_frontpage_news_days = 5;

$advanced_admin_level = 9;
$op_level = 8;
$add_article_level = 7;
$poll_manage_level = 7;
$links_manage_level = 7;
$rss_manage_level = 7;
$comment_moderator_level = 6; //depericated
$default_userlevel = 2;
$can_comment_level = 2;
$can_edit_comments = 2;
$muted_level = 1;

$level1 = 1;
$level2 = 2;
$level3 = 3;
$level4 = 4;
$level5 = 5;
$level6 = 6;
$level7 = 7;
$level8 = 8;
$level9 = 9;

//10 is to disable
$rainbow_level = 10;
$pink_level = 10;

//ADVANCED EDITING ----------------------------------

$allowable_uploads = array ("jpg", "png", "zip", "bmp", "exe", "doc", "xls");
$resizeable_images= array ("jpg", "png");
$movie_formats= array ("avi", "mpg");

$public_folder = "pub/";
$base_photo_dir = $public_folder."photos/";
$base_movie_dir = $public_folder."movies/";
$base_attachements_dir = $public_folder."attachements/";
$xml_headlines_filename = $public_folder."channels/".$default_dir."_rss_headlines.xml";

// assign our path in a form PHP for Windows OR *NIX understands
//$path1 = $_SERVER["DOCUMENT_ROOT"]."\\".$default_dir."\\attachements\\";
$path1 = $_SERVER["DOCUMENT_ROOT"]."/".$default_dir."/pub/attachements/";

//(MOST) SITE TABLES

$bookmarks_table = "bookmarks";
$user_handles_table = $default_dir."_user_handles
$followup_subscriptions_table = $default_dir."_subscriptions_followups";
$rss_table = $default_dir."_rss";
$messages_table = $default_dir."_messages";
$status_table = $default_dir."_status";
$photos_table = $default_dir."_photos";
$sitemarks_table = $default_dir."_sitemarks";
$event_table = $default_dir."_event";
$item_table = $default_dir."_items";
$vote_table = $default_dir."_polls_votes";
$polls_table = $default_dir."_polls";
$submissions_table = $default_dir."_submissions";
$item_table_que = $default_dir."_items_que";
$helpdesk_table = $default_dir."_tickets";
$source_table = $default_dir."_source";
$assignments_table = $default_dir."_assignments";
$ban_table = $default_dir."_ban";
$reads_table = $default_dir."_reads";
$followup_table = $default_dir."_followup";
$followup_que_table = $default_dir."_followup_que";
$links_table = $default_dir."_links";
$revisions_table = $default_dir."_revisions";
$stats_visitor_table = $default_dir."_stats_visitor";
$stats_pages_table = $default_dir."_stats_pages";

$default_domain = $_SERVER["HTTP_HOST"];
$default_url = "http://".$default_domain."/".$default_dir;

	include $default_path."common/database_connect.php";
	include $default_path."common/functions.php";

    //GET SITE INFO
    
    $row = sql("SELECT * from config where dir_name = '".$default_dir."'",0, $sDB, $nConnection);
    $front_page_type = $row["front_page_type"]; 
    $followup_que = $row["followup_que"]; 
    $start_page = $row["start_page"];    
    $default_name = $row["default_name"];
    $level_icons = $row["level_icons"];    
    $tz_offset = $row["tz_offset"];
    $user_menu_align = $row["user_menu_align"];
    $default_email = $row["email"];


include $default_path."common/login_check.php";

?>
