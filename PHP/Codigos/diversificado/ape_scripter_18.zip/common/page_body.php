<?
if (!$page && !$start_page) {
    $tomorrow  = mktime (0,0,0,date("m")  ,date("d")+2,date("Y"));
    $yesterday  = mktime (0,0,0,date("m")  ,date("d")-1,date("Y"));
    //NEWS ENTRIES
    echo "<a name='news'>";
    
    if($show_category) {
    	$show_category = " AND category = '$show_category' ";
    	$show_days=90;
    }
    else {
    	$show_days=$number_of_frontpage_news_days-1;
    }
    $cmd_article="select * from $item_table where (date BETWEEN DATE_SUB('".date("Y-m-d",$yesterday)."', INTERVAL $show_days DAY) AND '".date("Y-m-d",$tomorrow)."') AND showasnews = 0 AND $item_table.level <=".$userlevel." $show_category order by date desc";
    $res_article=mysql_db_query($sDB,$cmd_article,$nConnection);
    while($row_article=mysql_fetch_array($res_article)) {
      include $default_path.'bin/display_'.$front_page_type.'.php';
    }
    if ($front_page_type == 'headers') {
     echo '</table>';
    }
}
else if (!$page && $start_page) {
    include $default_path.'bin/'.$start_page.'.php';
}
else if (substr($page,0,1)=='_') {
    include $page.'.php';
}
else if (substr($page,0,2)=='m_') {
    include $default_path.'mod/'.$page.'.php';
}
else {
    include $default_path.'bin/'.$page.'.php';
}

?>