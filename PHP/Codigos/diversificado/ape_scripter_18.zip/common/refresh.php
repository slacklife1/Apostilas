<meta http-equiv="REFRESH" content="0;url=<? echo $refresh_target; ?>">
</body>
</html>
