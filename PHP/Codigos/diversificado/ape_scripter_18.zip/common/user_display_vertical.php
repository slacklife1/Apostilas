<?
echo "<br><a name='login'>";
if (substr($QUERY_STRING,0,7) == "logout=") {
	$QUERY_STRING = "";
}

if ($status && $login_confirmed==0) {
	echo "<table width='95%' align='center'><tr><td>";
	echo "<font class='small_font'>".$status."</font>";
	echo "</td></tr></table>";
}
else if ($status && $login_confirmed==1) {
	echo "<table border='0' cellpadding='0' cellspacing='0' align='".$user_menu_align."'>";
	echo "  <tr>";
	echo "    <td>";
	echo "<font class='small_font'>".$status."</font>";
	echo "    </td>";
	echo "  </tr>";
	echo "</table>";
}


if (!$login_confirmed) {
	echo "<form method='POST' action='".$PHP_SELF."?".$QUERY_STRING."'>";
	echo "<table border='0' cellpadding='1' cellspacing='2' align='".$user_menu_align."' valign='bottom'>";
	echo "  <tr>";
	echo "    <td><font class='small_font'>USER: </font></td>";
	echo "    <td><input type='text' name='username' size='10'></td>";
	echo "  </tr>";
	echo "  <tr>";
	echo "    <td><font class='small_font'>PASS: </font></td>";
	echo "    <td><input type='password' name='password' size='10'></td>";
	echo "  </tr>";
	echo "  <tr>";
	echo "    <td><input type='submit' value='Login' name='B1'></td>";
	echo "  </tr>";
	echo "  <tr>";
	echo "  <td align='center' colspan='5'><font class='small_font'>[ <a class='usermenulink' href='index.php?page=create%20account'>CREATE AN ACCOUNT?</a> ] <br> [ <a  class='usermenulink' href='index.php?page=lost password'>LOST PASSWORD?</a> ]</font></td>";
	echo "  </tr>";
	echo "</table><input type='hidden' name='loggin' value='1'></form>";
}
?>
