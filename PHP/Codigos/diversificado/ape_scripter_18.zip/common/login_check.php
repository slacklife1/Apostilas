<?

$row_ban = sql("select b_ip from $ban_table where b_ip = '".$REMOTE_ADDR."'",0, $sDB, $nConnection);

if ($row_ban) {
	echo "YOUR IP HAS BEEN BANNED";
	exit;
}

if ($logout) {
	setcookie("FudgedORG", $logout, time() - 3600, "/"); /* set cookie to 3 hours ago */
}
else if ($loggin || $FudgedORG) {
	if ($loggin) {
		//$row_user = sql("select * from users, PERMISSIONS where username = '$username' and password = '$password' AND PERMISSIONS.p_userid = users.userid AND PERMISSIONS.p_siteid = '".$default_dir."'",0, $sDB, $nConnection);
		
		$cmd_user = "select * from users, PERMISSIONS where username = '$username' AND PERMISSIONS.p_userid = users.userid AND PERMISSIONS.p_siteid = '".$default_dir."'";
		$res_user = mysql_db_query($sDB,$cmd_user,$nConnection);
		$row_user = mysql_fetch_array($res_user);
		
		$chkpass = crypt($password, $row_user["password"]);
    		if ($row_user["password"] == $chkpass) {
    			$login_confirmed = 1;

			mt_srand ((double) microtime() * 1000000);
			// creates a random number
			$cookieval = mt_rand  (0000000000, 9999999999);
			$row = sql("update users set remote_addr = '".$REMOTE_ADDR."', cookieval = '$cookieval' where username = '$username'",0, $sDB, $nConnection);
			setcookie("FudgedORG", $cookieval, time()+94608000, "/");  /* expires in 3 years */
    		}

	}
	else if ($FudgedORG) {
		$row_user = sql("select * from users,PERMISSIONS where cookieval = '$FudgedORG' AND PERMISSIONS.p_userid = users.userid AND PERMISSIONS.p_siteid = '".$default_dir."'",0, $sDB, $nConnection);    		
		if($row_user) {
			$login_confirmed = 1;
		}
	}

	if ($login_confirmed == 1) {
		//MAIN SITE LAST LOGIN
		$row = sql("update users set lastlogin = '".today($tz_offset,"f")."', remote_addr = '".$REMOTE_ADDR."' WHERE userid=".$row_user["userid"],0, $sDB, $nConnection);
		$status = $status."<table border='0' cellpadding='1' cellspacing='2'>";
		$status = $status."<tr>";
		$status = $status."<td align='".$user_menu_align."' valign='middle'>";

		if ($FudgedORG) {
			$logout_value = $FudgedORG;
		}
		else {
			$logout_value = $cookieval;
		}

		//MENU ROW
		$status = $status."<font class='small_font'>";

		//WELCOME ROW

		$row_color = sql("select levelcolor, leveldesc from levels,users where userid = ".$row_user["userid"]." AND levels.level = users.level", 0, $sDB, $nConnection);

		$status = $status."<font class='headline'><font color='".$row_color["levelcolor"]."'>".$row_user["username"]."</font></font><br>";
		$status = $status."<font class='small_font'><a class='systemlink' href='".$PHP_SELF."?page=levels'>".$row_color["leveldesc"]."</a></font><br><br>";

		//OPTIONS / LOGOUT
		if ($row_user["level"] >= $add_article_level) {
			$status = $status." [ <a class='menulink' href='".$PHP_SELF."?page=add item'>ADD ARTICLE</a> ]<br>";
		}

		$status = $status." [ <a class='menulink' href='".$PHP_SELF."?page=control panel'>CONTROL PANEL</a> ]<br>";
		$status = $status." [ <a class='menulink' href='".$PHP_SELF."?page=address book'>ADDRESS BOOK</a> ]<br>";
		$status = $status." [ <a class='menulink' href='".$PHP_SELF."?page=bookmarks'>BOOKMARKS</a> ]<br>";
		

		$status = $status." [ <a class='menulink' href='".$PHP_SELF."?logout=$logout_value'>LOGOUT</a> ]<br><br>";

		$status = $status."</font></td>";
		$status = $status."</tr>";
		$status = $status."</table>";

		$row_level = sql("select * from PERMISSIONS WHERE p_userid = ".$row_user["userid"]." AND p_siteid = '".$default_dir."'",0, $sDB, $nConnection);
		$userlevel = $row_level["level"];

		$row_ilevel = sql("UPDATE users set level = ".$userlevel. " WHERE userid = ".$row_user["userid"],0, $sDB, $nConnection);
	}
	else {
		$status = "Please check your <b>USERNAME</b> and <b>PASSWORD</b>.";
	}
}
else {
	//Annonymous USER
	$row = sql("update users set lastlogin = '".today($tz_offset,"f")."' WHERE userid=999",0, $sDB, $nConnection);
}

//SET GLOBAL VARS
$userid = $row_user["userid"];
$username = $row_user["username"];
$useremail = $row_user["email"];

if ($userlevel == 0 || $userid == 0) {
	$userlevel = 0;
	$userid = 999;
}
?>