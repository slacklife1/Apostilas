<?
if ($page=="") {
	if ($show_category) {
		echo ucwords($show_category);
	}
	else {
		if (!$page && $start_page) {
   			echo strtoupper($start_page);
		}
		else {
			echo "NEWS";		
		}
	}
}
else {
	if ($page == "story") {
		$row = sql("select subject from $item_table where post = ".$post,0, $sDB, $nConnection);
		//echo $row["subject"];
	}
	else if ($page == "category") {
		echo "Category: $category";
	}	
	else {
		if (substr($page,0,1)=="_") {
			echo strtoupper(substr($page,1,strlen($page)));
		}
		else if (substr($page,0,2)=="s_" || substr($page,0,2)=="m_") {
			echo strtoupper(substr($page,2,strlen($page)));
		}
		else {
			echo strtoupper($page);
		}
	}
}
?>
