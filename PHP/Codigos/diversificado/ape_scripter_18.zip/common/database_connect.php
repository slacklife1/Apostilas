<?

//TOBD: ENCRYPTED - 290403
//DATABASE CONNECTION INFORMAION (ADMIN EDIT)

//START EDIT
$sUser = "";
$sPass = "";
$sDB = "acervus";
$sServer = "localhost";
//STOP EDIT

$nConnection = mysql_connect($sServer, $sUser, $sPass);
if($nConnection<1) {
  echo "Database unavailable!<br>";
  exit;
}

?>