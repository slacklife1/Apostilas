<?
function SiteMarks($mySQL_now_date,$table, $sDB,$nConnection) {




     //SITEMARKS
    $cmd_sm="select * from $table where sm_date = '$mySQL_now_date' order by sm_date desc";
    $res_sm=mysql_db_query($sDB,$cmd_sm,$nConnection);
    while($row_sm=mysql_fetch_array($res_sm)) {
	if (!$R) {
		echo "<br>";
		echo "<font class='headline'>Today's <a class='systemlink' href='?page=site%20marks&show=all'>Site Marks</a></font>";
		echo "<br>";
	}
	
	echo "- <font class='small_font'><a href='".$row_sm["sm_url"]."'>".$row_sm["sm_title"]."</a><br></font>";    	
	$R=1;
    }
    
    if ($R==1) {
    	$R=0;	
    }

}	
function getPrevMonth($this_month, $this_year)
{
	if ($this_month==1)
	{
		$pmonth = 12;
		$pyear = $this_year - 1;

	} else
	{
		$pmonth = $this_month - 1;
		$pyear = $this_year;

	}
	return str_pad($pmonth, 2, "0", STR_PAD_LEFT).$pyear;

}

function getNextMonth($this_month, $this_year)
{
	if ($this_month==12)
	{
		$nmonth = 1;
		$nyear = $this_year + 1;
	} else
	{
		$nmonth = $this_month + 1;
		$nyear = $this_year;

	}
	return str_pad($nmonth, 2, "0", STR_PAD_LEFT).$nyear;

}

function sql($cmd, $type, $sDB,$nConnection) {
    $res = mysql_db_query($sDB,$cmd,$nConnection);
    if (mysql_errno() > 0) { echo "<P ALIGN=center>" . mysql_error() . "</P>".$cmd; }
    if (strtolower(substr($cmd,0,6)) == "select") {
    	//echo $cmd;
    	//echo "<br>";
    	//echo strtolower(substr($cmd,0,6));
    	//echo "<br>";
    	return mysql_fetch_array($res);
    }
}

function today($tz_offset,$type) {

	if ($type=="d") {
	  return date("Y-m-d",time()+$tz_offset*3600);	
	}
	else {
	  return date("Y-m-d H:i:s",time()+$tz_offset*3600);	
	}
	
}

function gen_password() { 
    $len = 8; 
    mt_srand((double)microtime() * 1000000); 
    $pwd = ''; 

    for($i = 0; $i < $len ; $i++) { 
    $num = mt_rand(48, 122); 

        if (($num > 96 && $num < 123 ) || ($num > 64 && $num < 91) || ($num > 47 && $num < 58)) 
            $pwd .= chr($num); 
        else 
            $i--; 
    } 

    return $pwd; 
}

function validate_email ($address) {
	return (ereg('^[-!#$%&\'*+\\./0-9=?A-Z^_`a-z{|}~]+'. '@'. '[-!#$%&\'*+\\/0-9=?A-Z^_`a-z{|}~]+\.' . '[-!#$%&\'*+\\./0-9=?A-Z^_`a-z{|}~]+$', $address));
}

function strcount($needle, $haystack) {
	$strcount = explode($needle, $haystack);
	return count($strcount);
}

function makeRainbow($text) {

	$color_d1 = 255;
	$slen = strlen($text);
	$mul = $color_d1 / strlen($text);
	for($i = 0; $i < $slen; $i++) {
		$color_d1 = 255 * sin($i / ($slen / 3));
		$color_h1 = dechex($color_d1);

		$color_d2 = $mul * $i;
		$color_h2 = dechex($color_d2);
		
		$k = $slen;
		$j = $k - $i;
		if ($j < 0) $j = 0;
		$color_d3 = $mul * $j;
		$color_h3 = dechex($color_d3);
		
		$rt .=  "<FONT COLOR='#".$color_h3.$color_h1.$color_h2."'>".substr($text, $i,1)."</FONT>";
	}
	return $rt;
}	


//BUILD TABLE VERSION 1.1
function BuildTable($cmd,$sDB,$nConnection) {

$res = mysql_db_query($sDB,$cmd,$nConnection);

//Generic SQL Error responses, can save you much time.
if (mysql_errno() > 0) { echo "<P ALIGN=center>" . mysql_error() . "</P>"; }

	//Is there an array (recordset)
	if($row=mysql_fetch_array($res)) {
		
		echo "<TABLE CELLPADDING='2' CELLSPACING='1' BORDER='0'>";
		echo "<TR CLASS='table_header_color'>";
		
		$num_fields = MYSQL_NUM_FIELDS($res);
		$num_rows = MYSQL_NUM_ROWS($res);
		
		//Loop though the X number of fields to create a table header. 
		for ($i=0;$i<$num_fields;$i++) {
			echo "<TD><FONT CLASS='normal_font'><b>".strtoupper(MYSQL_FIELD_NAME($res,$i))."</b></FONT></TD>";
		}
		echo "</TR>";
		
		while ($row=mysql_fetch_array($res)) {
	
			//Make every other row dark
			if ($r == "<tr class='table_dark_row_color'>") {
				$r = "<tr class='table_light_row_color'>";
			}
			else {
				$r ="<tr class='table_dark_row_color'>";
			}
			echo $r;
	
			//For the number of fields print the data contained in each field, per row
			for ($i=0;$i<$num_fields;$i++) {
				echo "<TD><FONT CLASS='small_font'>".$row[MYSQL_FIELD_NAME($res,$i)]."</FONT></TD>";
			}
			echo "</TR>";		
			
			
		}
		echo "</TABLE>";
		
	}
	
} 

?>