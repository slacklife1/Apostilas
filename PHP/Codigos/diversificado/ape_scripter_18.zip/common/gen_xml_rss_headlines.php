<?

$now = date("D, d M Y H:i:s T"); 

$rss_output .= "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n";
$rss_output .= "<!DOCTYPE rss PUBLIC \"-//Netscape Communications//DTD RSS 0.91//EN\" \"http://my.netscape.com/publish/formats/rss-0.91.dtd\">\n";
$rss_output .= "<rss version=\"0.92\">\n";
$rss_output .= "<channel>\n";
$rss_output .= "<title>".$default_name."</title>\n";
$rss_output .= "<link>".$default_url."</link>\n";
$rss_output .= "<description>".$default_description."</description>\n";
$rss_output .= "<language>en-us</language>\n";
$rss_output .= "<pubDate>$now</pubDate>\n";
$rss_output .= "<lastBuildDate>$now</lastBuildDate>\n";
$rss_output .= "<managingEditor>".$default_email."</managingEditor>\n";

    	$cmd_article="select * from $item_table, PERMISSIONS where showasnews = 0 AND $item_table.level = 0 AND p_siteid = '".$default_dir."' AND p_userid = $userid order by date desc LIMIT 0,10";
    	$res_article=mysql_db_query($sDB,$cmd_article,$nConnection);
    	while($row_article=mysql_fetch_array($res_article)) {
	    $rss_output .= "<item>\n";
            $rss_output .= "<title>".htmlentities($row_article["subject"])."</title>\n";
            $rss_output .= "<link>".htmlentities($default_url."?page=story&post=".$row_article["post"])."</link>\n";
            $rss_output .= "<description></description>\n";
            $rss_output .= "</item>\n"; 
	} 
$rss_output .= "</channel></rss>\n"; 

    if (!$handle = fopen($xml_headlines_filename, 'w+')) {
         echo "<br><br><font class='feedback_font'>1 Cannot open RSS file ($xml_headlines_filename) check that the file exisits and that permissions are set to 777 writeable.</font>";
    }
    else if (!fwrite($handle, $rss_output)) {
     	 echo "<br><br><font class='feedback_font'>2 Cannot open RSS file ($xml_headlines_filename) check that the file exisits and that permissions are set to 777 writeable.</font>";    	
    }
    fclose($handle);
					
       


?>
