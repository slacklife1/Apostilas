<?

if ($default_name && $username && $password) {
	include $default_path."common/functions.php";
	include $default_path."common/database_connect.php";

	echo "<b>Installing Tables...</b><br><br>";

	//USER TABLE
	echo "<b>User Table and Account...</b><br>";
	$password = crypt($password);
	$row = sql("CREATE TABLE users ( userid int(11) NOT NULL auto_increment, username varchar(25) NOT NULL default '',  location varchar(100) NOT NULL default '',  membersince date NOT NULL default '0000-00-00',  email varchar(100) NOT NULL default '',  url varchar(200) NOT NULL default '',  icq varchar(25) NOT NULL default '',  yim varchar(25) NOT NULL default '',  aim varchar(25) NOT NULL default '',  msn varchar(50) NOT NULL default '',  phonepage varchar(50) NOT NULL default '',  password varchar(34) NOT NULL default '',  extra text,  remote_addr text,  cookieval varchar(10) default NULL,  lastlogin datetime default NULL,  status tinyint(4) NOT NULL default '0',  level varchar(4) NOT NULL default '',  commentcount int(11) NOT NULL default '0',  PRIMARY KEY  (userid)) TYPE=MyISAM",0, $sDB, $nConnection);
	$row = sql("INSERT INTO `users` ( `userid` , `username` , `location` , `membersince` , `email` , `url` , `icq` , `yim` , `aim` , `msn` , `phonepage` , `password` , `extra` , `remote_addr` , `cookieval` , `lastlogin` , `status` , `level` , `commentcount` ) VALUES ('1', '$username', '', '0000-00-00', '', '', '', '', '', '', '', '$password', NULL , NULL , '1234567890', '2003-05-01 14:59:10', '0', '9', '0')",0, $sDB, $nConnection);
	echo "Done.<br><br>";

	//PERMISSIONS TABLE
	echo "<b>Permission Table...</b><br>";
	$row = sql("CREATE TABLE `PERMISSIONS` (  `p_userid` int(11) NOT NULL default '0',  `p_siteid` varchar(50) NOT NULL default '',  `level` tinyint(4) NOT NULL default '0') TYPE=MyISAM",0, $sDB, $nConnection);
	$row = sql("INSERT INTO `PERMISSIONS` ( `p_userid` , `p_siteid` , `level` ) VALUES ('1', '$dir_name', '9')",0, $sDB, $nConnection);
	$row = sql("INSERT INTO `PERMISSIONS` ( `p_userid` , `p_siteid` , `level` ) VALUES ('999', '$dir_name', '1')",0, $sDB, $nConnection);
	echo "Done.<br><br>";

	//CONFIG TABLE
	echo "<b>Configuration Table...</b><br>";
	$row = sql("CREATE TABLE config ( user_menu_align varchar(10) NOT NULL default '',  default_name varchar(50) NOT NULL default '',  dir_name varchar(50) NOT NULL default '',  tz_offset varchar(5) NOT NULL default '',  start_page varchar(100) NOT NULL default '',  front_page_type varchar(50) NOT NULL default '',  level_icons tinyint(4) NOT NULL default '0',  followup_que tinyint(4) NOT NULL default '0') TYPE=MyISAM",0, $sDB, $nConnection);
	$row = sql("INSERT INTO config VALUES ('center', '$default_name', '$dir_name', '0', '', 'blog', 1, 1)",0, $sDB, $nConnection);
	echo "Done.<br><br>";

	//CONTACTS TABLE
	echo "<b>Contacts Table...</b><br>";
	$row = sql("CREATE TABLE contacts ( c_idnum tinyint(4) NOT NULL auto_increment, c_siteid varchar(50) NOT NULL default '', c_location varchar(100) NOT NULL default '', c_title varchar(50) NOT NULL default '', c_name varchar(50) NOT NULL default '', c_phone1 varchar(15) NOT NULL default '', c_phone2 varchar(15) NOT NULL default '', PRIMARY KEY  (c_idnum)) TYPE=MyISAM",0, $sDB, $nConnection);
	echo "Done.<br><br>";

	//CONTACTS USERS TABLE
	echo "<b>Contacts Users Table...</b><br>";
	$row = sql("CREATE TABLE contacts_users ( cu_siteid varchar(50) NOT NULL default '', cu_userid int(11) NOT NULL default '0') TYPE=MyISAM",0, $sDB, $nConnection);
	echo "Done.<br><br>";

	//STATS COUNT TABLE
	echo "<b>Stats Count Table...</b><br>";
	$row = sql("CREATE TABLE stats_count ( siteid varchar(50) NOT NULL default '0', visitors bigint(20) NOT NULL default '0') TYPE=MyISAM",0, $sDB, $nConnection);
	echo "Done.<br><br>";

	//STATUS TABLE
	echo "<b>Status  Table...</b><br>";
	$row = sql("CREATE TABLE status ( user_status tinyint(4) NOT NULL default '0', type_status varchar(25) NOT NULL default '', type_color varchar(15) NOT NULL default '', PRIMARY KEY  (user_status)) TYPE=MyISAM",0, $sDB, $nConnection);
	echo "Done.<br><br>";

	//STATUS EXTRA TABLE
	echo "<b>Status Extra Table...</b><br>";
	$row = sql("CREATE TABLE status_extra ( st_userid int(11) NOT NULL default '0', st_extra varchar(100) NOT NULL default '') TYPE=MyISAM",0, $sDB, $nConnection);
	echo "Done.<br><br>";

	//SUBSCRIPTIONS TABLE
	echo "<b>Subscriptions Table...</b><br>";
	$row = sql("CREATE TABLE `subscriptions` (  `s_userid` int(11) NOT NULL default '0',  `s_siteid` varchar(50) NOT NULL default '',  `s_email` tinyint(4) NOT NULL default '0') TYPE=MyISAM;",0, $sDB, $nConnection);
	echo "Done.<br><br>";

	//UPDATED TABLE
	echo "<b>Updated Table...</b><br>";
	$row = sql("CREATE TABLE updated ( date datetime NOT NULL default '0000-00-00 00:00:00', default_name varchar(50) NOT NULL default '', dir_name varchar(50) NOT NULL default '') TYPE=MyISAM",0, $sDB, $nConnection);
	echo "Done.<br><br>";

	//LEVELS TABLE
	echo "<b>Levels Table...</b><br>";
	$row = sql("CREATE TABLE levels ( level tinyint(4) NOT NULL default '0', leveldesc varchar(20) NOT NULL default '', levelcolor varchar(6) NOT NULL default '', levellongdesc text NOT NULL) TYPE=MyISAM",0, $sDB, $nConnection);
	$row = sql("INSERT INTO levels VALUES (9, 'root', '00CC66', 'Full site and user control.')",0, $sDB, $nConnection);
	$row = sql("INSERT INTO levels VALUES (8, 'Operator', '00CF63', 'Top level user and site maintenance.')",0, $sDB, $nConnection);
	$row = sql("INSERT INTO levels VALUES (7, 'Contributer', '00CF63', 'News posting rights without delete and can approve comments, news. No user maintenance.')",0, $sDB, $nConnection);
	$row = sql("INSERT INTO levels VALUES (6, 'Moderator', '6365CE', 'Can approve comments from the queue')",0, $sDB, $nConnection);
	$row = sql("INSERT INTO levels VALUES (5, 'Level 5', '00C000', '')",0, $sDB, $nConnection);
	$row = sql("INSERT INTO levels VALUES (4, 'Level 4', 'C0C000', '')",0, $sDB, $nConnection);
	$row = sql("INSERT INTO levels VALUES (3, 'Level 3', '00C0C0', '')",0, $sDB, $nConnection);
	$row = sql("INSERT INTO levels VALUES (2, 'Member', 'CC6600', 'Basic user account.')",0, $sDB, $nConnection);
	$row = sql("INSERT INTO levels VALUES (1, 'Muted', 'FFFFFF', 'Can`t comment. Not deleted.')",0, $sDB, $nConnection);
	$row = sql("INSERT INTO levels VALUES (0, 'NULL', '000000', 'Hasn`t logged in since the date on their profile.')",0, $sDB, $nConnection);
	echo "Done.<br><br>";

	//BUDDYLIST TABLE
	echo "<b>Buddylist Table...</b><br>";
	$row = sql("CREATE TABLE buddy_list ( b_userid int(11) NOT NULL default '0', b_buddy int(11) NOT NULL default '0', PRIMARY KEY  (b_userid,b_buddy)) TYPE=MyISAM",0, $sDB, $nConnection);
	echo "Done.<br><br>";

	//BOOKMARKS TABLE
	echo "<b>Bookmarks Table...</b><br>";
	$row = sql("CREATE TABLE bookmarks ( bookmark_no int(11) NOT NULL auto_increment, bookmark_userid int(20) NOT NULL default '0', bookmark_title varchar(255) NOT NULL default '', bookmark_category varchar(255) NOT NULL default '', bookmark_url varchar(255) NOT NULL default '', PRIMARY KEY  (bookmark_userid,bookmark_no)) TYPE=MyISAM",0, $sDB, $nConnection);
	echo "Done.<br><br>";

	//INSTALL MAIN TABLES
	echo "<b>Main Table(s)...</b><br>";
		$row_user = sql("CREATE TABLE `".$dir_name."_assignments` (   `a_no` int(11) NOT NULL auto_increment,  `a_userid` int(11) NOT NULL default '0',  `a_post` int(11) NOT NULL default '0',  `a_date` datetime NOT NULL default '0000-00-00 00:00:00',  `a_exclude` char(1) NOT NULL default '',  PRIMARY KEY  (`a_no`)) TYPE=MyISAM AUTO_INCREMENT=1",0, $sDB, $nConnection);    			
		$row_user = sql("CREATE TABLE `".$dir_name."_ban` (  `b_no` int(11) NOT NULL auto_increment,  `b_userid` int(11) NOT NULL default '0',  `b_email` varchar(150) NOT NULL default '0',  `b_date` datetime NOT NULL default '0000-00-00 00:00:00',  `b_ip` varchar(15) NOT NULL default '',  `b_unban` char(1) NOT NULL default '',  PRIMARY KEY  (`b_no`)) TYPE=MyISAM AUTO_INCREMENT=1",0, $sDB, $nConnection);    			
		$row_user = sql("CREATE TABLE `".$dir_name."_followup` (  `siteid` varchar(50) NOT NULL default '0',  `c_num` int(11) NOT NULL auto_increment,  `c_user` int(11) NOT NULL default '0',  `c_post` int(11) NOT NULL default '0',  `c_text` text NOT NULL,  `c_date` datetime NOT NULL default '0000-00-00 00:00:00',  `frontpage` char(1) NOT NULL default '',  PRIMARY KEY  (`c_num`)) TYPE=MyISAM AUTO_INCREMENT=1",0, $sDB, $nConnection);    			
		$row_user = sql("CREATE TABLE `".$dir_name."_followup_log` (  `ap_userid` int(11) NOT NULL default '0',  `ap_followup` int(11) NOT NULL default '0',  `ap_date` datetime NOT NULL default '0000-00-00 00:00:00') TYPE=MyISAM",0, $sDB, $nConnection);    			
		$row_user = sql("CREATE TABLE `".$dir_name."_followup_que` (  `siteid` varchar(50) NOT NULL default '0',  `c_num` int(11) NOT NULL auto_increment,  `c_user` int(11) NOT NULL default '0',  `c_post` int(11) NOT NULL default '0',  `c_text` text NOT NULL,  `c_date` datetime NOT NULL default '0000-00-00 00:00:00',  PRIMARY KEY  (`c_num`)) TYPE=MyISAM AUTO_INCREMENT=1",0, $sDB, $nConnection);    			
		$row_user = sql("CREATE TABLE `".$dir_name."_items` (  `post` int(11) NOT NULL auto_increment,  `date` datetime NOT NULL default '0000-00-00 00:00:00',  `userid` int(11) NOT NULL default '0',  `subject` varchar(250) NOT NULL default '',  `category` varchar(100) NOT NULL default '',  `status` varchar(20) NOT NULL default '',  `story` text NOT NULL,  `fullstory` longtext NOT NULL,  `level` tinyint(4) NOT NULL default '1',  `comments` int(11) NOT NULL default '0',  `reads` tinyint(4) NOT NULL default '0',  `showasnews` tinyint(4) default '0',  `priority` tinyint(4) NOT NULL default '0',  `ref_siteid` varchar(50) NOT NULL default '',  `attached1` varchar(150) NOT NULL default '',  `allowcomments` char(1) NOT NULL default '',  `source` tinyint(4) NOT NULL default '0',  `thank` int(11) NOT NULL default '0',  PRIMARY KEY  (`post`)) TYPE=MyISAM COMMENT='Main Story Table' AUTO_INCREMENT=16",0, $sDB, $nConnection);    			
		$row_user = sql("CREATE TABLE `".$dir_name."_items_que` (  `nq_num` int(11) NOT NULL auto_increment,  `nq_date` datetime NOT NULL default '0000-00-00 00:00:00',  `nq_userid` int(11) NOT NULL default '0',  `nq_subject` varchar(254) NOT NULL default '',  `nq_story` text NOT NULL,  PRIMARY KEY  (`nq_num`)) TYPE=MyISAM AUTO_INCREMENT=1",0, $sDB, $nConnection);    			
		$row_user = sql("CREATE TABLE `".$dir_name."_links` (  `link_no` bigint(20) NOT NULL auto_increment,  `link_title` varchar(255) NOT NULL default '',  `link_category` varchar(255) NOT NULL default '',  `link_description` text NOT NULL,  `link_url` varchar(255) NOT NULL default '',  PRIMARY KEY  (`link_no`)) TYPE=MyISAM AUTO_INCREMENT=7",0, $sDB, $nConnection);    			
		$row_user = sql("CREATE TABLE `".$dir_name."_photos` (  `photo_no` varchar(100) NOT NULL default '',  `photo_userid` int(11) NOT NULL default '0',  `photo_caption` text NOT NULL,  `photo_caption_date` datetime NOT NULL default '0000-00-00 00:00:00',  `photo_name` varchar(255) NOT NULL default '',  `photo_title` varchar(255) NOT NULL default '') TYPE=MyISAM",0, $sDB, $nConnection);    			
		$row_user = sql("CREATE TABLE `".$dir_name."_polls` (  `poll_num` int(11) NOT NULL auto_increment,  `poll_post` int(11) NOT NULL default '0',  `poll_question` varchar(255) NOT NULL default '',  `poll_ans1` varchar(200) NOT NULL default '',  `poll_ans2` varchar(200) NOT NULL default '',  `poll_ans3` varchar(200) NOT NULL default '',  `poll_ans4` varchar(200) NOT NULL default '',  `poll_res1` int(11) NOT NULL default '0',  `poll_res2` int(11) NOT NULL default '0',  `poll_res3` int(11) NOT NULL default '0',  `poll_res4` int(11) NOT NULL default '0',  `poll_date` datetime NOT NULL default '0000-00-00 00:00:00',  PRIMARY KEY  (`poll_num`)) TYPE=MyISAM AUTO_INCREMENT=1",0, $sDB, $nConnection);    			
		$row_user = sql("CREATE TABLE `".$dir_name."_polls_votes` (  `vote_userid` int(11) NOT NULL default '0',  `vote_poll` int(11) NOT NULL default '0',  PRIMARY KEY  (`vote_userid`,`vote_poll`)) TYPE=MyISAM",0, $sDB, $nConnection);    			
		$row_user = sql("CREATE TABLE `".$dir_name."_reads` (  `r_post` int(11) NOT NULL default '0',  `r_siteid` varchar(150) NOT NULL default '0',  `r_userid` int(11) NOT NULL default '0',  `r_lastread` datetime NOT NULL default '0000-00-00 00:00:00') TYPE=MyISAM",0, $sDB, $nConnection);    			
		$row_user = sql("CREATE TABLE `".$dir_name."_revisions` (  `r_id` int(11) NOT NULL auto_increment,  `r_post` int(11) NOT NULL default '0',  `r_userid` int(11) NOT NULL default '0',  `r_date` datetime NOT NULL default '0000-00-00 00:00:00',  `r_org_userid` int(11) NOT NULL default '0',  `r_org_date` datetime NOT NULL default '0000-00-00 00:00:00',  PRIMARY KEY  (`r_id`)) TYPE=MyISAM AUTO_INCREMENT=23",0, $sDB, $nConnection);    			
		$row_user = sql("CREATE TABLE `".$dir_name."_rss` (  `rss_no` int(11) NOT NULL default '0',  `rss_name` varchar(255) NOT NULL default '',  `rss_url` varchar(255) NOT NULL default '',  `rss_cache_name` varchar(100) NOT NULL default '',  `rss_headlines` tinyint(4) NOT NULL default '0',  `rss_topsite` tinyint(4) NOT NULL default '0',  PRIMARY KEY  (`rss_no`)) TYPE=MyISAM",0, $sDB, $nConnection);    			
		$row_user = sql("CREATE TABLE `".$dir_name."_sitemarks` (  `sm_id` bigint(20) NOT NULL auto_increment,  `sm_title` text NOT NULL,  `sm_url` text NOT NULL,  `sm_date` date NOT NULL default '0000-00-00',  PRIMARY KEY  (`sm_id`)) TYPE=MyISAM AUTO_INCREMENT=1",0, $sDB, $nConnection);    			
		$row_user = sql("CREATE TABLE `".$dir_name."_source` (  `source_no` int(11) NOT NULL auto_increment,  `source_userid` int(20) NOT NULL default '0',  `source_source` varchar(255) NOT NULL default '',  `source_type` varchar(255) NOT NULL default '',  `source_url` varchar(255) NOT NULL default '',  PRIMARY KEY  (`source_userid`,`source_no`)) TYPE=MyISAM AUTO_INCREMENT=1",0, $sDB, $nConnection);    			
		$row_user = sql("CREATE TABLE `".$dir_name."_stats_pages` (  `page` varchar(255) NOT NULL default '0',  `visitors` bigint(20) NOT NULL default '0') TYPE=MyISAM",0, $sDB, $nConnection);    			
		$row_user = sql("CREATE TABLE `".$dir_name."_stats_visitor` (  `siteid` varchar(50) NOT NULL default '0',  `ip` varchar(15) NOT NULL default '0',  `browser` varchar(100) NOT NULL default '0',  `recieved` datetime NOT NULL default '0000-00-00 00:00:00',  `refer` varchar(254) NOT NULL default '') TYPE=MyISAM",0, $sDB, $nConnection);    			
		$row_user = sql("CREATE TABLE `".$dir_name."_submissions` (  `sub_num` int(11) NOT NULL auto_increment,  `sub_date` datetime NOT NULL default '0000-00-00 00:00:00',  `sub_post` int(11) NOT NULL default '0',  `sub_user` int(11) NOT NULL default '0',  `sub_text` text NOT NULL,  `pinked` char(1) NOT NULL default '',  PRIMARY KEY  (`sub_num`)) TYPE=MyISAM AUTO_INCREMENT=1",0, $sDB, $nConnection);    			
		$row_user = sql("CREATE TABLE `".$dir_name."_subscriptions_followups` (  `s_userid` int(11) NOT NULL default '0',  `s_item` int(11) NOT NULL default '0',  PRIMARY KEY  (`s_item`,`s_userid`)) TYPE=MyISAM",0, $sDB, $nConnection);
		$row_user = sql("CREATE TABLE `".$dir_name."_user_handles (  h_userid int(11) NOT NULL default '0',  h_handle varchar(20) NOT NULL default '',  PRIMARY KEY  (h_userid)) TYPE=MyISAM",0, $sDB, $nConnection);

	echo "Done.<br><br>";
	
	echo "<font color='red'>*If* the above processed without errors you are almost done the install.</font><br><br>";

	echo "<b>FINAL INSTALLATION STEPS</b><br><br>";

	echo "<ul>";
	echo "<li>DELETE the setup.php file!<br>It is a possible (likely) risk to leave this file on your sever, please go delete it NOW.</li>";
	echo "</ul>";

	echo "<b>THAT'S IT.</b><br><br>You are finished installing the <a href='http://www.acervus.ca'>Acervus Scripter</a>! If everything went well you should now be able to see a working site at the url below. Remember that this is just the default layout, you can now get creative and give the site any look and feel you desire. The important files are your stylesheet, <b>template.css</b> and the HTML layout in <b>template.html</b>. Please referr to the documentation on the Acervus Scripter website (it'll get there) on how to completly customize your new site and use it's Control Panel options. You can get and give support there.";
	echo "<br><br>";
	echo "<b><a href='http://".$_SERVER["HTTP_HOST"]."/'>".$default_name."</a></b>";

}
else {
	echo "<form method='POST' action=''>";
	echo "  <table border='0' align='center'>";

	echo "    <tr>";
	echo "      <td>";
	echo "	    <b>DEFAULT NAME:</b>";
	echo "      <br>This websites full name.";
	echo "	    </td>";
	echo "      <td>";
	echo "      <input type='text' name='default_name' size='50' maxlength='100' value='$default_name'>";
	echo "	    </td>";
	echo "    </tr>";

	echo "    <tr>";
	echo "      <td>";
	echo "	    <b>USERNAME NAME:</b>";
	echo "      <br>Choose a username, this account will have full permission rights to the site.";
	echo "	    </td>";
	echo "      <td>";
	echo "      <input type='text' name='username' size='50' maxlength='100' value='$username'>";
	echo "	    </td>";
	echo "    </tr>";

	echo "    <tr>";
	echo "      <td>";
	echo "	    <b>PASSWORD:</b>";
	echo "      <br>Admin Password.";
	echo "	    </td>";
	echo "      <td>";
	echo "      <input type='text' name='password' size='50' maxlength='100' value='$password'>";
	echo "	    </td>";
	echo "    </tr>";

	echo "    <tr>";
	echo "      <td colspan=2 align=center>";
	echo "	    <input type='submit' name='INSTALL' value='INSTALL ACERVUS SCRIPTER'>";
	echo "	    </td>";
	echo "    </tr>";

	echo "</table>";
	echo "</form>";
}
?>
