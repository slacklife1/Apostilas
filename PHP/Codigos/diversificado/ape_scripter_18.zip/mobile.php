<?
$default_path="";
$default_dir="";
include "common/config.php";
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Acervus.ca
</title>
<LINK REL="SHORTCUT ICON" HREF="/favicon.ico" TYPE="image/x-icon">
<link href="mobile.css" rel="stylesheet" type="text/css">
</head>

<body link='#0000FF' text='#000000' bgcolor='#FFFFFF' vlink='#800080'>

<table border="0" cellpadding="0" cellspacing="0" width="100%">
                      <tr>
                        <td>
                        <font face="Arial"><b><a href="<? echo $default_url; ?>">
                        <font size="2">
                        <? echo $default_name; ?>
                        </font></a></b><font size="2"> </font></font>
                        </td>
	       		<td align='right'>
			<font class='normal_font'><? include "common/page_header.php"; ?></font>
                        </td>
                      </tr>
                      <tr>
                        <td width="100%" colspan="2" >
                        <img src="gfx/1x1.gif" width="1" height ="5"></td>
                      </tr>
                      <tr>
                        <td width="100%" colspan="2" bgcolor="#000000">
                        <img src="gfx/1x1.gif" width="1" height ="1"></td>
                      </tr>
                        <td width="100%" colspan="2">
	          
                        <?  include "common/user_display_vertical.php"; ?>
			<?  include "common/page_body.php";  ?>
                       </td>
         </table>
</body>
</html>

<?
include "common/page_stats.php";
?>