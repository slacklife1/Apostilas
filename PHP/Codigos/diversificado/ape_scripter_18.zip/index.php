<?
$default_path="";
$default_dir="";
include "common/config.php";
if ($template) {
  include  $default_path."pak/".$template.".html";	
}
else {
	if (file_exists("template.html")) {
	  include "template.html";	
	}
	else {
  	  include $default_path."pak/template.html";	  
	}
}
?>