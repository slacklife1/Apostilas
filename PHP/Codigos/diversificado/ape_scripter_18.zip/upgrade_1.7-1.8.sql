# Replace all files except common/database_connect.php and common/config.php if it's been editied.
# Table structure for table `_user_handles`
#

CREATE TABLE _user_handles (
  h_userid int(11) NOT NULL default '0',
  h_handle varchar(20) NOT NULL default '',
  PRIMARY KEY  (h_userid)
) TYPE=MyISAM;

