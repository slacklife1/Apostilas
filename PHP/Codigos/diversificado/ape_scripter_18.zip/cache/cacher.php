<?

/*
This shows a basic way to create a cache of your frontpage. You can call this file via a cron tab
or other schedualer. Implement the the cache by using the code below in template.html.

              <? 
              if (!$page) {
	              include "cache/cache.html"; 
	          }
	          else {
	              include "common/page_body.php";
	          }
              ?>

/* PUT data comes in on the stdin stream */
$putdata = fopen("http://www.expectnothing.com/index.php?template=cache","r");

/* Open a file for writting */
$fp = fopen("/home/virtual/site45/fst/var/www/html/cache/cache.html","w");

/* Read the data 1kb at a time
   and write to the file */
while ($data = fread($putdata,1024))
  fwrite($fp,$data);

/* Close the streams */
fclose($fp);
fclose($putdata);
?>
