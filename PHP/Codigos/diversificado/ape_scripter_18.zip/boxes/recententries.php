<?

echo "<table class='box_body'>";
echo "  <tr>";
echo "    <td class='box_content'>";

$cmd="select subject, category, date, post from $item_table, PERMISSIONS WHERE $item_table.level <=".$userlevel." AND p_siteid = '".$default_dir."' AND p_userid = $userid AND category <> 'Tickets' order by date desc LIMIT 0,5";
if ($res=mysql_db_query($sDB,$cmd,$nConnection)) {
	while ($row=mysql_fetch_array($res)) {
		echo "<font class='small_font'><a class='systemlink' href='".$PHP_SELF."?page=story&post=".$row["post"]."'>".$row["subject"]."</a></font><br>";
		echo "<font class='date_font'>".$row["date"]."</font><br>";
	}
}

echo "    </td>";
echo "  </tr>";
echo "</table>";
echo "<br>";
?>




