<?
echo "<table class='box_body'>";
echo "  <tr>";
echo "    <td class='box_content'>";

	echo "<font class='headline'><a href='?page=comments board'>Comments Board</a></font>";
	echo "<br><font class='small_font'>[Last ten posted comments]</font>";
	
	$cmd_ch="select * from $item_table, $followup_table, PERMISSIONS WHERE post = c_post AND $item_table.level <=".$userlevel." AND p_siteid = '".$default_dir."' AND p_userid = $userid  order by c_date DESC LIMIT 0,10";
	$res_ch=mysql_db_query($sDB,$cmd_ch,$nConnection);
	echo "<br><ul>";
	while ($row_ch=mysql_fetch_array($res_ch)) {

	  $cmd_user = "select username,userid,location,membersince,commentcount from users where userid = ".$row_ch["c_user"];
	  $res_user=mysql_db_query($sDB,$cmd_user,$nConnection);
	  $row_user=mysql_fetch_array($res_user);

  	  $cmd_color = "SELECT levelcolor,leveldesc from levels,users, PERMISSIONS where userid = ".$row_ch["c_user"]." AND p_userid = ".$row_ch["c_user"]." AND userid = p_userid AND p_siteid = '".$default_dir."' AND PERMISSIONS.level = levels.level";
	  $res_color=mysql_db_query($sDB,$cmd_color,$nConnection);
	  $row_color=mysql_fetch_array($res_color);

          $cmd_subject = "select subject from $item_table where post = ".$row_ch["c_post"];
          $res_subject=mysql_db_query($sDB,$cmd_subject,$nConnection);
          $row_subject=mysql_fetch_array($res_subject);
	  
	  echo "<li>";
	  echo "<font class='small_font'><b><a class='systemlink' href='".$PHP_SELF."?page=user profile&profile=".$row_user["userid"]."'><font color='".$row_color["levelcolor"]."'>".$row_user["username"]."</font></a></b></font>";
	  echo "<br>";
	  echo "<font class='small_font'><b></b><a href='".$PHP_SELF."?page=story&post=".$row_ch["c_post"]."#".$followups_called."'>".$row_subject["subject"]."</a><font class='small_font'> [".$row_ch["comments"]."]</font></font>";
	  
	  echo "</li>";	

	}
	echo "</ul>";

echo "    </td>";
echo "  </tr>";
echo "</table>";
echo "<br>";
?>