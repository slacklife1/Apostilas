<?
echo "<table class='box_body'>";
echo "  <tr>";
echo "    <td class='box_content'>";

	echo "<font class='headline'><a href='?page=item stats'>MOST READ ITEMS</a></font>";
	echo "<br><font class='small_font'>[Comments]</font><br><br>";
	
	$sql = "SELECT subject, post, comments from $item_table order by reads desc limit 0,10";
	$result = mysql_query($sql);
	while ($row = mysql_fetch_array($result)) {
	  echo "<font class='small_font'><a href='".$PHP_SELF."?page=story&post=".$row["post"]."'>".$row["subject"]."</a></font> ";
	  echo "<font class='small_font'> [".$row["comments"]."] </font><br>";
	}

echo "    </td>";
echo "  </tr>";
echo "</table>";
echo "<br>";
?>