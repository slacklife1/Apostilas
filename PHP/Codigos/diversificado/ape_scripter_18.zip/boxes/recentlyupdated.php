<?
echo "<table class='box_body'>";
echo "  <tr>";
echo "    <td class='box_content'>";

$cmd="select * from updated order by date desc LIMIT 0,10";
$res=mysql_db_query($sDB,$cmd,$nConnection);
while ($row=mysql_fetch_array($res)) {
	echo "<font class='small_font'><a class='systemlink' href='http://".$default_domain."/".$row["dir_name"]."'>".$row["default_name"]."</a></font><br>";
	echo "<font class='date_font'>".$row["date"]."</font><br>";
}

echo "    </td>";
echo "  </tr>";
echo "</table>";
echo "<br>";
?>


