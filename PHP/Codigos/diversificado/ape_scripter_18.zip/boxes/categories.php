<?
echo "<table class='box_body'>";
echo "  <tr>";
echo "    <td class='box_content'>";

//Restrict category listing to only those with permission.
//$cmd="select category from $item_table, PERMISSIONS WHERE category <> '' AND $item_table.level <=".$userlevel." AND p_siteid = '".$default_dir."' group by category";

//List categories without restriction
$cmd="select category from $item_table WHERE category <> '' group by category";
$res=mysql_db_query($sDB,$cmd,$nConnection);

while ($row=mysql_fetch_array($res)) {
	echo "<li><font class='small_font'><a class='systemlink' href='?page=category&category=".$row["category"]."'>".$row["category"]."</a></font></li>";
}

echo "    </td>";
echo "  </tr>";
echo "</table>";
echo "<br>";
?>



