<?

if(!$year){$year=date("Y"); }
if(!$req_month || $req_month=="none")
{
	$req_month=date("m");

}
$dt_and_tm=mktime(0,0,0,$req_month,1,$year);

// what are the months and year immediately ahead and behind the current one?

$prev_result = getPrevMonth($req_month, $year);
$prev_month = substr($prev_result, 0, 2);
$prev_year = substr($prev_result, 2);

$next_result = getNextMonth($req_month, $year);
$next_month = substr($next_result, 0, 2);
$next_year = substr($next_result, 2);

/*    #
***********************************************************************************
# *** Find out the month number from the time stamp we just created
*************
# *** Find out the day of the week from the same(0 to 6 for Sunday to
*************
# *** Saturday) add "1" so that it becomes 1 to 7
*************
#
*************************************************************************************
*/
$month=date("n",$dt_and_tm);
$week_day=date("w",$dt_and_tm)+1;


/*   #
************************************************************************************
# *** Set number days in requested month
*************
#
************************************************************************************
*/

if($month==1 || $month==3 || $month==5 || $month==7 || $month==8 ||
$month==10 || $month==12)
{
	$no_of_days=31;
}
elseif($month==4 || $month==6 || $month==9 || $month==11)
{
	$no_of_days=30;
}

/* #
**************************************************************************************
# *** If the month requested is Feb. Check whether it is Leap Year
**************
#
**************************************************************************************
*/

elseif($month==2)
{
	if(date("L",$dt_and_tm))
	{ $no_of_days=29 ;}
	else
	{$no_of_days=28;}
}
$month_full=date("F",$dt_and_tm);

// Is there a match in the calendar for today?

$today_year = date(Y);
$today_month = date(n);
if ($today_year==$year && $today_month==$month)
{
	$today_day = date(j);
	$today_match = "true";

} else {
	$today_match = "false";
}


/*
#
***************************************************************************************
# ************ HTML code goes from here
*****************
# ************ First row in HTML table displays month and year
*****************
# ************ Second row is allotted for week days
*****************
# ************ Table contains six more rows (total 42 table cells)
*****************
#
***************************************************************************************

*/

?>

<table align='center' width="100%">
<tr bgcolor=""><td colspan=7>
<table border=0 width="100%">
<tr valign='top'>
<td width = "100%" valign="center">

<? if ($show_monthyear_selector) { ?>
		<form method=POST action='?page=archive'>
		<select size="1" name="req_month">
			<option value='01'<? if ($req_month=="01"){ echo " SELECTED";}?>>January</option>
			<option value='02'<? if ($req_month=="02"){ echo " SELECTED";}?>>Feburary</option>
			<option value='03'<? if ($req_month=="03"){ echo " SELECTED";}?>>March</option>
			<option value='04'<? if ($req_month=="04"){ echo " SELECTED";}?>>April</option>
			<option value='05'<? if ($req_month=="05"){ echo " SELECTED";}?>>May</option>
			<option value='06'<? if ($req_month=="06"){ echo " SELECTED";}?>>June</option>
			<option value='07'<? if ($req_month=="07"){ echo " SELECTED";}?>>July</option>
			<option value='08'<? if ($req_month=="08"){ echo " SELECTED";}?>>August</option>
			<option value='09'<? if ($req_month=="09"){ echo " SELECTED";}?>>September</option>
			<option value='10'<? if ($req_month=="10"){ echo " SELECTED";}?>>October</option>
			<option value='11'<? if ($req_month=="11"){ echo " SELECTED";}?>>November</option>
			<option value='12'<? if ($req_month=="12"){ echo " SELECTED";}?>>December</option>
		</select>
		<select size="1" name="year">
			<option value='2002'<? if ($year=="2002"){ echo " SELECTED";}?>>2002</option>			
			<option value='2003'<? if ($year=="2003"){ echo " SELECTED";}?>>2003</option>
			<option value='2004'<? if ($year=="2004"){ echo " SELECTED";}?>>2004</option>
			<option value='2005'<? if ($year=="2005"){ echo " SELECTED";}?>>2005</option>
			<option value='2005'<? if ($year=="2006"){ echo " SELECTED";}?>>2006</option>
			<option value='2007'<? if ($year=="2007"){ echo " SELECTED";}?>>2007</option>
			<option value='2008'<? if ($year=="2008"){ echo " SELECTED";}?>>2008</option>
			<option value='2009'<? if ($year=="2009"){ echo " SELECTED";}?>>2009</option>
			<option value='2010'<? if ($year=="2010"){ echo " SELECTED";}?>>2010</option>
		</select> <input type="submit" value="Browse" name="submit"></form></td>
<? } else {

echo "<font class='normal_font'><b>$month_full  $year</b></font></td>";

} ?>

<td align="right"><? echo "<a href='?page=archive&req_month=$prev_month&year=$prev_year'><img src=../gfx/pmonth.gif border=0></a>"; ?></td>
<td align="left"><? echo "<a href='?page=archive&req_month=$next_month&year=$next_year'><img src=../gfx/nmonth.gif border=0></a>"; ?></td>
</tr>
</table>

</td></tr>
<tr class='table_header_color '>
<?
if ($show_big_calendar) {
?>
<td width='14%'><font class='small_font'><font color='#ffffff'>Sunday</font></td>
<td width='14%'><font class='small_font'><font color='#ffffff'>Monday</font></td>
<td width='14%'><font class='small_font'><font color='#ffffff'>Tuesday</font></td>
<td width='14%'><font class='small_font'><font color='#ffffff'>Wednesday</font></td>
<td width='14%'><font class='small_font'><font color='#ffffff'>Thursday</font></td>
<td width='14%'><font class='small_font'><font color='#ffffff'>Friday</font></td>
<td width='14%'><font class='small_font'><font color='#ffffff'>Saturday</font></td>
<?
}
else {
?>
<td width='14%'><font class='small_font'><font color='#ffffff'>Sun</font></td>
<td width='14%'><font class='small_font'><font color='#ffffff'>Mon</font></td>
<td width='14%'><font class='small_font'><font color='#ffffff'>Tue</font></td>
<td width='14%'><font class='small_font'><font color='#ffffff'>Wed</font></td>
<td width='14%'><font class='small_font'><font color='#ffffff'>Thu</font></td>
<td width='14%'><font class='small_font'><font color='#ffffff'>Fri</font></td>
<td width='14%'><font class='small_font'><font color='#ffffff'>Sat</font></td>
<?
}
?>

</tr>
<tr class='table_dark_row_color'>

<?php

/*
#
**************************************************************************************
# *** We need to start form week day and print total number of days
*****************
# *** in this month.For that we need to find out the last cell.
*****************
# *** While looping end current row and start new row for each 7 cells
*****************
#
**************************************************************************************
*/
$last_cell=$week_day+$no_of_days;
for($i=1;$i<=42;$i++)
{
	if($i==$week_day){$day=1;}
	if($i<$week_day || $i>=$last_cell)
	{

		echo "<td><font class='small_font'>&nbsp;</font></td>";
		if($i%7==0){echo "</tr><tr class='table_dark_row_color'>\n";}
	}
	else
	{
		if ($day <= 9) {
			$wday = "0".$day;
		}
		else {
			$wday = $day;
		}
		if ($month <= 9) {
			$wmonth = "0".$month;
		}
		else {
			$wmonth = $month;
		}

		// if the day is today, paint it orange
		if(($today_match)&& ($today_day==$day)) {
			echo "<td bgcolor=orange>";
			if ($show_big_calendar) {
				echo "<font class='normal_font'>";
			}
			else {
				echo "<font class='small_font'>";				
			}
			$cmd = "select date from $item_table where substring(date,1,10) = '$year-$wmonth-$wday'";
			$res=mysql_db_query($sDB,$cmd,$nConnection);
			if ($row=mysql_fetch_array($res)) {
				echo "<a style=color:#000000;text-decoration:underline href='".$PHP_SELF."?page=archive&sdate=1&cyear=".$year."&cmonth=".$wmonth."&cday=".$wday."'>$day</a>";
			}
			else {
				echo "$day";
			}
			echo "</font></td>";
		}
		else {
			echo "<td>";
			if ($show_big_calendar) {
				echo "<font class='normal_font'>";
			}
			else {
				echo "<font class='small_font'>";				
			}
			$cmd = "select date from $item_table where substring(date,1,10) = '$year-$wmonth-$wday'";
			$res=mysql_db_query($sDB,$cmd,$nConnection);
			if ($row=mysql_fetch_array($res)) {
				echo "<a style=color:#000000;text-decoration:underline href='".$PHP_SELF."?page=archive&sdate=1&cyear=".$year."&cmonth=".$wmonth."&cday=".$wday."'>$day</a>";
			}
			else {
				echo "$day";
			}
			echo "</font></td>";
		}
		$day++;
		if($i%7==0) { echo "</tr><tr class='table_dark_row_color'>\n"; }

	}
}
echo "</table>";

?>
