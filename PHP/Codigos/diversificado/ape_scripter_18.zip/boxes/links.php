<?
echo "<table class='box_body'>";
echo "  <tr>";
echo "    <td class='box_content'>";

$cmd="select * from $links_table order by link_category, link_title";
if ($res=mysql_db_query($sDB,$cmd,$nConnection)) {
	while ($row=mysql_fetch_array($res)) {
		if ($last_category <> $row["link_category"]) {
			if ($passl) {
				echo "<br>";
			}
			echo "<font class='small_font'>";
			echo "<b>".strtoupper($row["link_category"])."</b></font><br>";
			$last_category = $row["link_category"];
			$passl=1;
		}
		echo "<font class='small_font'>";
		echo "<a class='systemlink' href='".$row["link_url"]."'>".$row["link_title"]."</a></font><br>";
	}
}

if ($userlevel >= $links_manage_level) {
	echo "<br><center><font class='small_font'>[ <a class='systemlink' href='".$PHP_SELF."?page=manage links'>MANAGE LINKS</a> ]</font></center>";
}

echo "    </td>";
echo "  </tr>";
echo "</table>";
echo "<br>";
?>



