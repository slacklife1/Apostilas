<?
echo "<table class='box_body'>";
echo "  <tr>";
echo "    <td class='box_content'>";

$cmd_poll = "SELECT * from $polls_table order by poll_date desc LIMIT 0,1";
$res_poll=mysql_db_query($sDB,$cmd_poll,$nConnection);
if (mysql_errno() > 0) { echo "<P ALIGN=center>" . mysql_error() . "</P>"; }

if ($row_poll=mysql_fetch_array($res_poll)){
	$cmd_vote = "SELECT vote_poll from $vote_table WHERE vote_userid = ".$userid." AND vote_poll = ".$row_poll["poll_num"];
	$res_vote=mysql_db_query($sDB,$cmd_vote,$nConnection);
	if ($row_vote=mysql_fetch_array($res_vote)) {
		echo "<font class='normal_font'><b>".$row_poll["poll_question"]."</b></font><br>";
		echo "<font class='date_font'>".$row_poll["poll_date"]."</font><br><br>";

		$poll_total = $row_poll["poll_res1"] + $row_poll["poll_res2"] + $row_poll["poll_res3"] + $row_poll["poll_res4"];
		if ($row_poll["poll_ans1"]) {
			echo "<font class='normal_font'>".$row_poll["poll_ans1"]."</font>";
			if ($row_poll["poll_res1"]) {
				$res1 = round($row_poll["poll_res1"] / $poll_total*100,2);
				echo "<br><img src='../gfx/poll.gif' width='$res1%' height='10'>";
				echo "<br><font class='small_font'>".$res1."% (".$row_poll["poll_res1"].")</font>";
			}
			else {
				echo "<br><img src='../gfx/poll.gif' width='0' height='10'>";
				echo "<br><font class='small_font'>0%</font>";
			}
		}
		if ($row_poll["poll_ans2"]) {
			echo "<br><br><font class='normal_font'>".$row_poll["poll_ans2"]."</font>";

			if ($row_poll["poll_res2"]) {
				$res2 = round($row_poll["poll_res2"] / $poll_total*100,2);
				echo "<br><img src='../gfx/poll.gif' width='$res2%' height='10'>";
				echo "<br><font class='small_font'>".$res2."% (".$row_poll["poll_res2"].")</font>";
			}
			else {
				echo "<br><img src='../gfx/poll.gif' width='0' height='10'>";
				echo "<br><font class='small_font'>0%</font>";
			}
		}
		if ($row_poll["poll_ans3"]) {
			echo "<br><br><font class='normal_font'>".$row_poll["poll_ans3"]."</font>";
			if ($row_poll["poll_res3"]) {
				$res3 = round($row_poll["poll_res3"] / $poll_total*100,2);
				echo "<br><img src='../gfx/poll.gif' width='$res3%' height='10'>";
				echo "<br><font class='small_font'>".$res3."% (".$row_poll["poll_res3"].")</font>";
			}
			else {
				echo "<br><img src='../gfx/poll.gif' width='0' height='10'>";
				echo "<br><font class='small_font'>0%</font>";
			}
		}
		if ($row_poll["poll_ans4"]) {
			echo "<br><br><font class='normal_font'>".$row_poll["poll_ans4"]."</font>";

			if ($row_poll["poll_res4"]) {
				$res4 = round($row_poll["poll_res4"] / $poll_total*100,2);
				echo "<br><img src='../gfx/poll.gif' width='$res4%' height='10'>";
				echo "<br><font class='small_font'>".$res4."% (".$row_poll["poll_res4"].")</font>";
			}
			else {
				echo "<br><img src='../gfx/poll.gif' width='0' height='10'>";
				echo "<br><font class='small_font'>0%</font>";
			}
		}
		echo "<br><br><font class='small_font'>TOTAL VOTES: $poll_total <br><a class='systemlink' href='".$PHP_SELF."?page=poll'>ARCHIVE</a></font>";
	}
	else {
		echo "<font class='normal_font'><b>".$row_poll["poll_question"]."</b></font><br>";
		if ($row_poll["poll_ans1"]) {
			echo "<font class='small_font'>- <a href='".$PHP_SELF."?page=poll&poll_num=".$row_poll["poll_num"]."&poll1=1&VOTE=1'>".$row_poll["poll_ans1"]."</a></font><br>";
		}
		if ($row_poll["poll_ans2"]) {
			echo "<font class='small_font'>- <a href='".$PHP_SELF."?page=poll&poll_num=".$row_poll["poll_num"]."&poll1=2&VOTE=1'>".$row_poll["poll_ans2"]."</a></font><br>";
		}
		if ($row_poll["poll_ans3"]) {
			echo "<font class='small_font'>- <a href='".$PHP_SELF."?page=poll&poll_num=".$row_poll["poll_num"]."&poll1=3&VOTE=1'>".$row_poll["poll_ans3"]."</a></font><br>";
		}
		if ($row_poll["poll_ans4"]) {
			echo "<font class='small_font'>- <a href='".$PHP_SELF."?page=poll&poll_num=".$row_poll["poll_num"]."&poll1=4&VOTE=1'>".$row_poll["poll_ans4"]."</a></font><br>";
		}
	}
}


echo "    </td>";
echo "  </tr>";
echo "</table>";
echo "<br>";
?>