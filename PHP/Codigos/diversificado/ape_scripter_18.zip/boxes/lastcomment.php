<?

echo "<table class='box_body'>";
echo "  <tr>";
echo "    <td class='box_content'>";

$cmdC="select $followup_table.c_text,$followup_table.c_date,$followup_table.c_post,$followup_table.c_post,$followup_table.c_user,$item_table.subject,$item_table.category,users.userid,users.username from $item_table,$followup_table,users, PERMISSIONS where $followup_table.c_post = $item_table.post and users.userid = $followup_table.c_user AND $item_table.level <=".$userlevel." AND p_siteid = '".$default_dir."' order by c_num desc LIMIT 0,1";
$resC=mysql_db_query($sDB,$cmdC,$nConnection);
if (mysql_errno() > 0) { echo "<P ALIGN=center>" . mysql_error() . "</P>"; }

if ($rowC=mysql_fetch_array($resC)) {
	echo "<font class='small_font'>";
	echo substr($rowC["c_text"],0,1000)." <a class='systemlink' href='".$PHP_SELF."?page=story&post=".$rowC["c_post"]."#comment".$rowC["c_post"]."'>...</a>";
	echo "</font><br><br>";

	echo "<font class='small_font'>";
	echo "  <a class='systemlink' href='".$PHP_SELF."?page=user profile&profile=".$rowC["userid"]."'>".$rowC["username"]."</a>";
	echo "<font class='small_colored'>";
	echo "  in response to:</font>";
	echo "  <br><a class='systemlink' href='".$PHP_SELF."?page=story&post=".$rowC["c_post"]."#comment".$rowC["c_post"]."'>".substr($rowC["subject"],0,30)."</a>";
	echo "  <br><br>[ <a class='systemlink' href='".$PHP_SELF."?page=comments%20board&limit=today'>TODAY</a> ] [ <a class='systemlink' href='".$PHP_SELF."?page=comments%20board&limit=last30'>LAST 30</a> ]";
	echo "</font><br>";
}

echo "    </td>";
echo "  </tr>";
echo "</table>";
echo "<br>";
?>