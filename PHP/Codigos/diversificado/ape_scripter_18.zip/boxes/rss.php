                <?
                
		include $default_path."common/onyx-rss.php";

		$cmd_rss = "SELECT * FROM $rss_table WHERE rss_topsite = 1 ORDER BY rss_no ASC";
		
		$res_rss = mysql_db_query($sDB,$cmd_rss,$nConnection) or die(mysql_error());
		$rss =& new ONYX_RSS();
		$rss->setCachePath('cache/');
		$rss->setFetchMode(ONYX_FETCH_OBJECT);
		$rss->setDebugMode(false);
		$rss->setExpiryTime(0);
		//$rss->startBuffer("rss.xml");
		
		while ($row_rss = @mysql_fetch_object($res_rss))
		{
		   if ($rss->parse($row_rss->rss_url, $row_rss->rss_cache_name))
		   {
		      echo "<table border='0' width='100%'>";
		      $meta = $rss->getData(ONYX_META);
		
		      echo "<tr><td><font class='normal_font'><b><a href='".$meta->link."'>".$meta->title."</a></font></b></td><td></td></tr>";
		      while ($item = $rss->getNextItem())
		      {
		  	if ($headline_limit < $row_rss->rss_headlines) {
		  		echo "<tr><td colspan='2'>";      	
		  		echo "<font class='small_font'><a href='".$item->link."'>".$item->title."</a></font><br>";
		  		//echo "<font class='date_font'>".$meta->pubDate."</font><br>\n";         
		  		echo "</td></tr>";
		  		$headline_limit++;  	
		  	}
		      }
		      echo "</table>\n";
		      $headline_limit=0;
		   }
		}
		
		//$rss->endBuffer();
	
		?>    