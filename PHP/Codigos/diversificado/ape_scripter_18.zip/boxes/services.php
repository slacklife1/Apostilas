<?	
echo "<table class='box_body'>";
echo "  <tr>";
echo "    <td class='box_content'>";

	echo "<font class='normal_font'><a href='?'>HOME</a></font>";
	echo "<br>";
	echo "<font class='normal_font'><a href='?page=contacts'>CONTACT</a></font>";
	echo "<br>";
	echo "<font class='normal_font'><a href='?page=photos'>PHOTOS</a></font>";
	echo "<br>";
	echo "<font class='normal_font'><a href='?page=public folder'>PUBLIC FOLDER</a></font>";
	echo "<br>";
	echo "<font class='normal_font'><a href='?page=links'>LINKS</a></font>";
	echo "<br>";
	echo "<br>";	

	//echo"<font class='normal_font'>&nbsp;&nbsp;&nbsp;</font></b>";
    	echo "<a href='_rss_headlines.xml'><img align='absmiddle' src='../gfx/xml.gif' border='0'></a>";

echo "    </td>";
echo "  </tr>";
echo "</table>";
?>



