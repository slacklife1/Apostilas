<?
echo "<table><tr>";
echo "<form method='POST' action='?page=archive&search=1'>";
echo "<td><input type='text' name='query' value='$query' size='25'></td>";
echo "<td><input type='submit' value='Search' name='Search'></td>";
echo "</form>";
echo "</tr>";
echo "<tr><td colspan='2'>";
echo "<font class='small_font'><b><a href='?page=categories'>CATEGORIES</a></b> | <b><a href='?page=archive'>ARCHIVE</a></b></font>";
echo "</td></tr>";
echo "</table>";

?>



