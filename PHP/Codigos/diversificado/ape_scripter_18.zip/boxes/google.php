<?	
echo "<table class='box_body'>";
echo "  <tr>";
echo "    <td class='box_content'>";
?>
<!-- Search Google -->
<FORM method=GET action="http://www.google.com/search">
<TABLE bgcolor="#FFFFFF"><tr align='center'><td>
<A HREF="http://www.google.com/">
<IMG SRC="../gfx/google.gif" 
border="0" ALT="Google" align="absmiddle"></A><br>
<INPUT TYPE=text name=q size=15 maxlength=255 value="">
<INPUT type=submit name=btnG VALUE="GO!">
</td></tr></TABLE></FORM>
<!-- Search Google -->
<?
echo "    </td>";
echo "  </tr>";
echo "</table>";
echo "<br>";
?>



