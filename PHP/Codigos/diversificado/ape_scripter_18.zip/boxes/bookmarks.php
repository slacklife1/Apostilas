<?

if ($userid <> 999) {

	$cmd="select * from $bookmarks_table where bookmark_userid = ".$userid." order by bookmark_category, bookmark_title";
	if ($res=mysql_db_query($sDB,$cmd,$nConnection)) {
		while ($row=mysql_fetch_array($res)) {
			if ($last_category <> $row["bookmark_category"]) {
				echo "<br>";
				echo "<font class='normal_font'>";
				echo "<b>".strtoupper($row["bookmark_category"])."</b></font><br>";
				$last_category = $row["bookmark_category"];
			}
			if (strtolower(substr($row["bookmark_url"],0,7)) == "http://") {
				echo "<font class='small_font'><a class='systemlink' href='".$row["bookmark_url"]."' target='_blank'>".$row["bookmark_title"]."</a><br></font>";
			}
			else {
				$cmd_bookmark="select comments,allowcomments,date from $item_table where post = ".$row["bookmark_url"];
				$res_bookmark=mysql_db_query($sDB,$cmd_bookmark,$nConnection);
				$row_bookmark=mysql_fetch_array($res_bookmark);

				$cmd_lc="select * from $followup_table where c_post = ".$row["bookmark_url"];
				$res_lc=mysql_db_query($sDB,$cmd_lc,$nConnection);
				$row_lc=mysql_fetch_array($res_lc);

				echo "<font class='small_font'><a class='systemlink' href='?page=story&post=".$row["bookmark_url"]."'>".$row["bookmark_title"]."</a><br></font>";
			}
		}
	}
}

echo "<br><br><font class='small_font'><a class='systemlink' href='?page=edit bookmarks'>EDIT BOOKMARKS</a></font><br><br>";
?>

