<?php
/* Philp News Management System
 * written by Martin Schulze (martinschulze@phoop.net)
 * You may modify this file if you want to but do not claim
 * that you wrote Philp, because Martin Schulze did.
 */
?>
<html>
<head>
	<title>Philp 2.0 Installation</title>
	<link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>
<?php
require("./config.php");
require("./dbmysql.php");

if((int)str_replace(".", "", phpversion()) < 410) {
	global $_POST, $_GET, $_SESSION, $_SERVER, $_ENV, $_FILES, $_REQUEST;
	
	$_POST = $HTTP_POST_VARS;
	$_GET = $HTTP_GET_VARS;
	$_SESSION = $HTTP_SESSION_VARS;
	$_SERVER = $HTTP_SERVER_VARS;
	$_ENV = $HTTP_ENV_VARS;
	$_FILES = $HTTP_POST_FILES;
	$_REQUEST = array();
	
	while(list($key, $value) = each($HTTP_POST_VARS)) $_REQUEST[$key] = $value;	
	while(list($key, $value) = each($HTTP_GET_VARS)) $_REQUEST[$key] = $value;
	while(list($key, $value) = each($HTTP_COOKIE_VARS)) $_REQUEST[$key] = $value;
};

if(get_magic_quotes_gpc() == 0) {
	while(list($key, $value) = each($_GET)) $_GET[$key] = addslashes($value);
	while(list($key, $value) = each($_POST)) $_POST[$key] = addslashes($value);
	while(list($key, $value) = each($_REQUEST)) $_REQUEST[$key] = addslashes($value);
};

function nextstep() {
	echo "<br><br><a href=\"setup.php?step=".++$_REQUEST["step"]."\">Next step</a>\n";
};

if(isset($_REQUEST["step"])) echo "<u>Step ".$_REQUEST["step"]."</u><br><br>\n";

switch($_REQUEST["step"]) {
	case 1:
		echo "Please check if the following DB-settings are correct.<br>\nIf they aren't please correct them (config.php).";
		echo "Host: $dbhost<br>\n";
		echo "User: $dbuser<br>\n";
		echo "Pass: $dbpass<br>\n";
		echo "Database name: $dbname<br>\n";
		echo "Use persistent connections: $persistent<br>\n";
		
		nextstep();
		break;
	case 2:
		$dba = new basicdb($dbhost, $dbuser, $dbpass, $dbname);
		
		
		echo "Trying to connect to connect to the database...";
		if($dba->connect()) echo "success\n<br>";
		else {
			echo "failed\n<br>";
			echo "Connecting to the database failed. Please check your config.php.<br>\n";
			echo "Contact your host if you don't the parameters for the database.";
			break;
		};
		
		echo "Seems connecting to the database works. The tables are now being created.\n<br>";
		nextstep();
		break;
	case 3:
		$dba = new basicdb($dbhost, $dbuser, $dbpass, $dbname);
		$dba->connect();
		
		echo "Creating table philp_newsitems...";
		if($dba->query("CREATE TABLE philp_newsitems (
							itemid int(6) NOT NULL auto_increment,
							title varchar(255) NOT NULL default '',
							body text NOT NULL,
							date int(15) NOT NULL default '0',
							poster varchar(20) NOT NULL default '',
							email varchar(60) default NULL,
							PRIMARY KEY  (itemid),
							UNIQUE KEY itemid (itemid)
						) TYPE=MyISAM")) echo "success<br>\n";
		else {
			echo "Creating the table failed. Check your database settings.";
			break;
		};
		
		echo "Creating table philp_users...";
		if($dba->query("CREATE TABLE philp_users (
							userid int(3) unsigned NOT NULL auto_increment,
							name varchar(20) NOT NULL default '',
							email varchar(60) NOT NULL default '',
							pass varchar(32) NOT NULL default '',
							PRIMARY KEY  (userid),
							UNIQUE KEY name (name)
						) TYPE=MyISAM")) echo "success<br>\n";
		else {
			echo "Creating the table failed. Check your database settings.";
			break;
		};
		
		echo "Seems everything went OK. In the fourth we will create an user.";
		nextstep();		
		break;
	case 4:
		?>
		<form action="setup.php" method="POST">
		<input type="hidden" name="step" value="5">
		Username: <input type="text" name="name"><br>
		Password: <input type="password" name="pass"><br>
		repeat the password: <input type="password" name="pass2"><br>
		Your E-Mail-Address: <input type="text" name="email"><br>
		
		<input type="submit" value="Create user">
		</form>
		<?php
		break;
	case 5:
		$dba = new basicdb($dbhost, $dbuser, $dbpass, $dbname);
		$dba->connect();
		
		if($_POST["pass"] != $_POST["pass2"]) {
			echo "The passwords you entered do not match together.<br>\nPlease go back and enter them once again.";
			break;
		};
		
		if($dba->query("INSERT INTO philp_users (name,email,pass) VALUES ('".$_POST["username"]."',md5('".$_POST["pass"]."'),'".$_POST["email"]."')")) {
			echo "User succesfully created.<br>\n";
		} else break;
		?>
		Congratulations. You installed Philp 2.0 succesfully.<br>
		Please delete this file now.
		<a href="philpadmin.php">Click here to enter the admin panel.</a>
		<?php		
		break;
	default:
		?>
		Welcome to the Philp 2.0-Installation.<br>
		Click next step to proceed.<br><br>		
		<a href="setup.php?step=1">next step</a>
		<?php	
};
?>
</body>
</html>