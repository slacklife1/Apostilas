<?php
/* Philp News Management System
 * written by Martin Schulze (martinschulze@phoop.net)
 * You may modify this file if you want to but do not claim
 * that you wrote Philp, because Martin Schulze did.
 */

if(file_exists("./setup.php")) {
	echo "Please delete the \"setup.php\".";
	exit;
};
 
$selfdir = dirname(__FILE__);
require("$selfdir/global.php");

if(checkadmin($_POST["fadmuser"], md5($_POST["fadmpass"]))) {
	setcookie("philpuser", $_POST["fadmuser"]);
	setcookie("philppass", md5($_POST["fadmpass"]));
	?>
	<html>
	<head>
	<title>Philp Administration Panel // overview</title>
	<link rel="stylesheet" type="text/css" href="admin.css">
	</head>	
	<body>
	<div align="center">
	Choose your task:<br><br>
	<a href="tasks.php?action=posts">Post management</a><br>
	<a href="tasks.php?action=users">User management</a><br>
	<a href="tasks.php?action=edittemplate">Edit template</a>
	</div>
	</body>	
	</html>
	<?php
} else {
	?>
	<html>
	<head>
	<title>Philp Administration Panel</title>
	<link type="text/css" rel="stylesheet" href="admin.css">
	</head>
	<body>
	<br><br><br>
	<div align="center">
	<?php
	tablehead("30%");
	formhead($self);
	?>
		<tr>
			<td colspan="2">
				Philp Administration Panel
			</td>
		</tr>
		<tr>
			<td>
				<input type="text" name="fadmuser"><br>
				<span class="small">Username</span>
			</td>
			<td>
				<input type="password" name="fadmpass"><br>
				<span class="small">Password</span>
			</td>
		</tr>
	<?php
	tablefoot();
	formfoot("Log in");
	?>
	</div>
	</body>	
	</html>
	<?php
};
?>