<?php
class basicdb {
    var $lastquery;
    var $lastresult;//from query
    var $lastrecord;//from fetcharray
	
	var $cid;//connection id

    var $lasterrorno;
    var $lasterror;
	
	var $querycount = 0;
	var $querytime = 0;
	
	//vars for the DB connection
	var $dbhost;
	var $dbuser;
	var $dbpass;
	var $dbname;
	var $persistent;
	
	function basicdb($dbhost, $dbuser, $dbpass, $dbname) {
		$this->dbhost = $dbhost;
		$this->dbuser = $dbuser;
		$this->dbpass = $dbpass;
		$this->dbname = $dbname;
	}
    
    function connect() {//Konstruktor, verbindet zur Datenbank
		if(!$this->cid){//check for already existing connection
			global $persistent;
            if ($persistent) {
                $this->cid = mysql_pconnect($this->dbhost, $this->dbuser, $this->dbpass);
            } else {
                $this->cid = mysql_connect($this->dbhost, $this->dbuser, $this->dbpass);
            };
    
            if (!$this->cid) {
                $this->error();
                return FALSE;
            };
    
            if (!mysql_select_db($this->dbname, $this->cid)) {
                $this->error();
                return FALSE;
            } else return TRUE;
		};
    }
    
    function fetcharray($resultid = -1) {//holt assoziatives Array aus Datenbank
        if($resultid == -1) {
			$this->lastrecord = mysql_fetch_array($this->lastresult, MYSQL_ASSOC);
			return $this->lastrecord;
		};
		$this->lastrecord = mysql_fetch_array($resultid, MYSQL_ASSOC);
        return $this->lastrecord;
    }
    
    function query($sql) {//query the database
        //update querycount (plus 1)
        $this->querycount++;
        
        $this->lastquery = $sql;
		
		$querystartime = microtime();
        $this->lastresult = mysql_query($this->lastquery, $this->cid);
		$queryendtime = microtime();
		$this->querytime += $queryendtime - $querystartime;
		
        
        if (!$this->lastresult) {
            $this->error();
        };
        
        return $this->lastresult;
    }
    
    function queryfirst($sql) {//return first row of selected data
        $this->lastquery = $sql;
		
        $this->query($this->lastquery);
        $this->fetcharray($this->lastresult);
		
        return $this->lastrecord;
    }
    
    function error() {//show the last error
        $this->lasterrorno = mysql_errno();
        $this->lasterror = mysql_error();
		
        echo "\n<br>Huh?...it seems we have a problem with the database:<br>\n";
        echo "<b>Error Number: ".$this->lasterrorno."<br>\nError Description: ".$this->lasterror."</b><br>\n";
		//echo "In Script: <b>".__FILE__."</b>, Line: <b>".__LINE__."</b><br>\n";
		
		if(empty($this->lastquery)) {
			$this->lastquery = "<b>There weren't any querys, check your DB-Settings (config.php).</b>";
		}
        echo "The last query was: ".$this->lastquery."\n";
    }
	
	function close() {
		return mysql_close($this->cid);
	}
	
	function affectedrows($resultid = -1) {
		if($resultid == -1){
			return @mysql_affected_rows($this->lastresult);	
		};
		
		return @mysql_affected_rows($resultid);
	}
	
	function numrows($resultid = -1) {
		if($resultid == -1){
			return mysql_num_rows($this->lastresult);	
		};
		
		return mysql_num_rows($resultid);
	}
	
	function freeresult($resultid = -1) {
		if($resultid == -1){
			$resultid = $this->lastresult;
		};
		
		return @mysql_free_result($resultid);
	}
	
	function insertid($resultid = -1) {
		if($resultid == -1){
			$resultid = $this->lastresult;
		};
		
		return mysql_insert_id($resultid);
	}
};
?>
