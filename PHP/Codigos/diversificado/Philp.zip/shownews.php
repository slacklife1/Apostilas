<?php
/* Philp News Management System
 * written by Martin Schulze (martinschulze@phoop.net)
 * You may modify this file if you want to but do not claim
 * that you wrote Philp, because Martin Schulze did.
 */
$selfdir = dirname(__FILE__);
require("$selfdir/global.php");

//read the template
$tpl = fopen("$selfdir/newsbit.tpl", "r");
define(template, strtolower(fread($tpl, filesize("$selfdir/newsbit.tpl"))));
fclose($tpl);

//read news from DB
$items = $dba->query("SELECT * FROM philp_newsitems ORDER by date DESC LIMIT $newscount");

//replace placeholders in template with values
while($newsitem = $dba->fetcharray($items)) {
	$itemedited = template;//reset template
	while(list($pattern, $value) = each($newsitem)) {
		if($pattern == "date") $value = date($timeformat, $value);
		if($pattern == "body") $value = nl2br($value);
		$itemedited = str_replace("%$pattern%", $value, $itemedited);
		//$itemedited = str_replace("%commentlink%", "<a href=\"comments.php?postingid=".$newsitem["itemid"]."\">Comments?</a> (".getcommentcount($item["itemid"]).")", $itemedited);
	};
	
	echo $itemedited;
};
?>
