<?php
/* Philp News Management System
 * written by Martin Schulze (martinschulze@phoop.net)
 * You may modify this file if you want to but do not claim
 * that you wrote Philp, because Martin Schulze did.
 */

//Host of the Database, usually localhost
$dbhost = "localhost";

//Loginname for the Database
$dbuser = "";

//Password for logging in to the DB
$dbpass = "";

//the database where the tables for Philp are
$dbname = "";

//wether to use persistent connections or not
//if you don't know what this is leave it at 0
//use pconnects = 1
//do not use pconnects = 0
$persistent = 0;

//how many news you want to see on the mainpage
$newscount = 8;

//how to display the date, see www.php.net/date for information
//on how to use this or leave it the way it is :p
$timeformat = "l, n. F Y, H:i:s";

//enter the name of the file you placed your stylesheet in
//absolute or relative pathes will work (relative to the comments.php)
//you may leave this empty but then the comments will look ugly
//DON'T EDIT THIS IT IS NOT IMPLEMENTED YET
$stylefile = "";
?>
