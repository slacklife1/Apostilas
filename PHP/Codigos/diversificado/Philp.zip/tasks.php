<html>
<head>
<title>Philp Administration Panel // user managment</title>
<link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>
<?php
/* Philp News Management System
 * written by Martin Schulze (martinschulze@phoop.net)
 * You may modify this file if you want to but do not claim
 * that you wrote Philp, because Martin Schulze did.
 */
 
require("./global.php");

if(!checkadmin($_COOKIE["philpuser"], $_COOKIE["philppass"])) die("You're not allowed to acces this page.");

switch($_REQUEST["action"]) {
//#######################User management############################
	case "users":
		?>
		<div align="center">
		<?php
		//if you want to create a new user
		tablehead("250");
		formhead($self, "makenewuser");
		?>
		<tr>
			<td colspan="2">Add a new user</td>
		</tr>
		<tr>
			<td>
				Name
			</td>
			<td>
				<input type="text" name="fnewusername" maxlength="20">
			</td>
		</tr>
		<tr>
			<td>
				E-Mail-Address
			</td>
			<td>
				<input type="text" name="fnewuseremail" maxlength="60">
			</td>
		</tr>
		<tr>
			<td>
				Password
			</td>
			<td>
				<input type="password" name="fnewuserpass">
			</td>
		</tr>
		<tr>
			<td>
				Password
			</td>
			<td>
				<input type="password" name="fnewuserpass2">
			</td>
		</tr>
		<?php
		tablefoot();
		formfoot("Add new user");
		
		//if you want to delete/edit users
		echo "\n<hr noshade color=\"black\">\n";
		tablehead("50%");
		formhead($self, "editusers");
		?>
		<tr>
			<td colspan="4">
				Edit/delete already existing users
			</td>
		</tr>
		<tr>
			<td width="25%">Username</td>
			<td width="25%">E-Mail-Address</td>
			<td width="25%">Password (only enter if you want to edit)</td>
			<td width="25%">Delete user</td>
		</tr>
		<?php		
		$dba->query("SELECT name,email,userid FROM philp_users");
		while($user = $dba->fetcharray()) {
			echo "\n<tr>\n";
			
			echo "<td><input type=\"text\" name=\"users[".$user["userid"]."][name]\" value=\"".$user["name"]."\"></td>\n";
			echo "<td><input type=\"text\" name=\"users[".$user["userid"]."][email]\" value=\"".$user["email"]."\" size=\"30\"></td>\n";
			echo "<td><input type=\"text\" name=\"users[".$user["userid"]."][pass]\"></td>\n";
			echo "<td><a href=\"$self?action=deleteuser&userid=".$user["userid"]."\">Delete this user</a></td>\n";
			
			echo "</tr>\n";			
		};
		echo "<tr><td colspan=\"4\"><b>Note: If you change your password your have to login once again to perform other tasks.</b></td></tr>";
		tablefoot();
		formfoot("Save changes");
		
		echo "\n</div>\n";
		break;
	case "makenewuser":
		if((empty($_POST["fnewusername"])) || (empty($_POST["fnewuseremail"])) || (empty($_POST["fnewuserpass"])) || (empty($_POST["fnewuserpass2"]))) {
			echo "Please fill out all fields of the form.";
			exit;
		};		
		if($_POST["fnewuserpass"] != $_POST["fnewuserpass2"]) {
			echo "The 2 passwords do not match together. Please double check them.\n";
			exit;
		};
		if($_POST["fumpass"] != $umpass) {
			echo "The password for the user administration is wrong.";
			exit;
		};
		
		$sqlquery = "INSERT INTO philp_users
						(name,email,pass)
						VALUES
						('".$_POST["fnewusername"]."',
						 '".$_POST["fnewuseremail"]."',
						 md5('".$_POST["fnewuserpass"]."'))";
		
		if($dba->query($sqlquery)) {
			echo "<html><body>User succesfully added.</body></html>";
		} else {
			echo "<html><body>An error occured while trying to add the user.</body></html>";
		};
		break;
	case "editusers":
		while(list($userid, $values) = each($_POST["users"])) {
			$sqlquery = "UPDATE philp_users SET name='".$values["name"]."', email='".$values["email"]."'";
			if(!empty($values["pass"])) $sqlquery .= ", pass=md5('".$values["pass"]."')";
			$dba->query($sqlquery);
		};
		
		echo "Users succesfully updated.";
		break;
	case "deleteuser":
		if($dba->query("DELETE FROM philp_users WHERE userid = ".$_GET["userid"])) {
			echo "User succesfully removed";
		} else {
			echo "An error occured while trying to remove the user.";
		};
		break;
//##########################Post management############################
	case "posts":
		echo "\n<div align=\"center\">\n";
		formhead($self, "dopost");
		tablehead(450);
		?>
		<tr>
			<td colspan="2">
				Post a new message
			</td>
		</tr>
		<tr>
			<td>
				The headline
			</td>
			<td>
				<input type="text" name="fheadline" size="45">
			</td>
		</tr>
		<tr>
			<td>
				The body of the message
			</td>
			<td>
				<textarea name="fbody" wrap="virtual" cols="50" rows="8"></textarea>
			</td>
		</tr>
		<?php
		tablefoot();
		formfoot("Post new message");
		echo "\n<hr noshade color=\"black\">\n";
		
		formhead($self, "doedit");
		tablehead(800);
		echo "\n<tr><td colspan=\"4\">Most recent postings</td></tr>\n";
		echo "<tr><td>Posted by</td><td>Headline</td><td>Body</td><td>Delete this post</td></tr>";
		
		$dba->query("SELECT poster,title,body,itemid FROM philp_newsitems LIMIT $newscount");
		while($item = $dba->fetcharray()) {
			echo "\n<tr>\n";
			echo "<td width=\"100\">".$item["poster"]."</td>\n";
			echo "<td width=\"250\"><input type=\"text\" name=\"items[".$item["itemid"]."][headline]\" value=\"".$item["title"]."\" size=\"45\"></td>\n";
			echo "<td width=\"250\"><textarea name=\"items[".$item["itemid"]."][body]\" cols=\"50\" rows=\"8\">".$item["body"]."</textarea></td>\n";
			echo "<td><a href=\"$self?action=deletepost&itemid=".$item["itemid"]."\">Delete post</a></td>\n";
			echo "</tr>\n";
		};
		?>
		<tr>
			<td colspan="4"><b>Note: Only the number of postings you specified to show in config.php are displayed</b></td>		
		</tr>
		<?php
		tablefoot();
		formfoot("Save changes");
		echo "\n</div>\n";
		break;
	case "dopost":
		if(empty($_POST["fheadline"]) || empty($_POST["fbody"])) {
			echo "Please fill out all fields of the form.";
			exit;
		};
		$dba->queryfirst("SELECT email FROM philp_users WHERE name='".$_COOKIE["philpuser"]."'");
		
		$sqlquery = "INSERT INTO philp_newsitems
						(title,body,poster,date,email)
						VALUES
						('".$_POST["fheadline"]."',
						 '".$_POST["fbody"]."',
						 '".$_COOKIE["philpuser"]."',
						 '".time()."',
						 '".$dba->lastrecord["email"]."')";
		if($dba->query($sqlquery)) echo "Message was succesfully posted.";
		
		break;
	case "doedit":
		while(list($itemid, $values) = each($_POST["items"])) {
			$dba->query("UPDATE philp_newsitems SET title = '".$values["headline"]."', body = '".$values["body"]."' WHERE itemid = ".$itemid."");
		};
		
		echo "Data succesfully updated.";
		break;
	case "deletepost":
		if($dba->query("DELETE FROM philp_newsitems WHERE itemid=".$_GET["itemid"])) echo "Post succesfully deleted";
		break;
//####################Template Management###################
	case "edittemplate":
		$fh = fopen("$selfdir/newsbit.tpl", "r");
		$template = fread($fh, filesize("$selfdir/newsbit.tpl"));
		fclose($fh);
		
		echo "\n<div align=\"center\">\n";
		formhead($self, "doedittemplate");
		tablehead("500");
		?>
		<tr>
			<td>Edit the template</td>
		</tr>
		<tr>
			<td>
				<textarea name="fnewtplvalue" wrap="virtual" cols="130" rows="20"><?php echo $template; ?></textarea>
			</td>
		</tr>
		<?php
		tablefoot();
		formfoot("Save changes");
		
		echo "\n<hr noshade color=\"black\">";
		
		tablehead(450);
		?>
		<tr><td colspan="2">Template variables reference</td></tr>
		<tr>
			<td>%title%</td>
			<td>The headline of the current posting</td>
		</tr>
		<tr>
			<td>%email%</td>
			<td>The E-Mail-Address of the poster</td>
		</tr>
		<tr>
			<td>%poster%</td>
			<td>The name of the current poster</td>
		</tr>
		<tr>
			<td>%date%</td>
			<td>Outputs the date in the specified format, see the config.php</td>
		</tr>
		<tr>
			<td>%body%</td>
			<td>Outputs the message of the posting itself</td>
		</tr>
		<tr>
			<td colspan="2">
				<b>Note: Insert this variables into the template field above.
				You don't need to use all of them but you may use them more than once.
				(Don't know why you would but you can :p)</b>
			</td>
		</tr>
		</div>
		<?php
		tablefoot();
		break;
	case "doedittemplate":
		if(empty($_POST["fnewtplvalue"])) echo "You left the template field empty.";
		else {
			$fh = fopen("$selfdir/newsbit.tpl", "w") or die("Could not open template file");
			fwrite($fh, $_POST["fnewtplvalue"]);
			fclose($fh);
			echo "Template succesfully edited.";
		};
		break;
};
?>
<br><br>
<div align="center"><a href="javascript:history.back()">Back to previous page</a></div>
</body></html>