<?php
/* Philp News Management System
 * written by Martin Schulze (martinschulze@phoop.net)
 * You may modify this file if you want to but do not claim
 * that you wrote Philp, because Martin Schulze did.
 */

@error_reporting(7);
set_magic_quotes_runtime(1);

//import DB-Class and settings
$selfdir = dirname(__FILE__);
require("$selfdir/config.php");
require("$selfdir/dbmysql.php");

//add compatibility for PHP-Versions older than 4.1.0
if((int)str_replace(".", "", phpversion()) < 410) {
	global $_POST, $_GET, $_SESSION, $_SERVER, $_ENV, $_FILES, $_REQUEST;
	
	$_POST = $HTTP_POST_VARS;
	$_GET = $HTTP_GET_VARS;
	$_SESSION = $HTTP_SESSION_VARS;
	$_SERVER = $HTTP_SERVER_VARS;
	$_ENV = $HTTP_ENV_VARS;
	$_FILES = $HTTP_POST_FILES;
	$_REQUEST = array();
	
	while(list($key, $value) = each($HTTP_POST_VARS)) $_REQUEST[$key] = $value;	
	while(list($key, $value) = each($HTTP_GET_VARS)) $_REQUEST[$key] = $value;
	while(list($key, $value) = each($HTTP_COOKIE_VARS)) $_REQUEST[$key] = $value;
};

if(get_magic_quotes_gpc() == 0) {
	while(list($key, $value) = each($_GET)) $_GET[$key] = mysql_escape_string($value);
	while(list($key, $value) = each($_POST)) $_POST[$key] = mysql_escape_string($value);
	while(list($key, $value) = each($_REQUEST)) $_REQUEST[$key] = mysql_escape_string($value);
};

//connect to the Database
$dba = new basicdb($dbhost, $dbuser, $dbpass, $dbname);
$dba->connect();

$self = $_SERVER["PHP_SELF"];

//common functions
function convertlb($string) {
	str_replace("\r\n", "\n", $string);
	str_replace("\r", "\n", $string);
	
	return $string;
};

function tablehead($width = "100%") {
	echo "\n<table cellpadding=\"4\" cellspacing=\"1\" border=\"0\" width=\"$width\" bgcolor=\"#000000\">";
};

function tablefoot() {
	echo "\n</table>\n";
};

function formhead($targetfile, $action = "", $method = "POST") {
	echo "\n<form action=\"$targetfile\" method=\"$method\">\n";
	if(!empty($action)) echo "<input type=\"hidden\" name=\"action\" value=\"$action\">\n";
};

function formfoot($buttontext) {
	echo "\n<br><br>\n<input type=\"submit\" value=\"$buttontext\">\n&nbsp;<input type=\"reset\" value=\"Reset form\">\n</form>\n";
};

function checkadmin($checkuser, $checkpass) {
	global $dba;
	
	$dba->query("SELECT name FROM philp_users WHERE name = '$checkuser' AND pass = '$checkpass'");	
	if($dba->numrows() === 1) return TRUE;
	else return FALSE;
};

function getcommentcount($postingid) {
	global $dba;
		
	$dba->queryfirst("SELECT count(*) AS count FROM philp_comments WHERE postingid = $postingid");
	return $dba->lastrecord["count"];
};
?>
