<html>
<head>
<?php
/* Philp News Management System
 * written by Martin Schulze (martinschulze@phoop.net)
 * You may modify this file if you want to but do not claim
 * that you wrote Philp, because Martin Schulze did.
 */

$selfdir = dirname(__FILE__);
require("$selfdir/global.php");

if(!isset($_REQUEST["postingid"])) {
	echo "No valid postingID was supplied.";
	exit;
};

if(!empty($stylefile)) echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"$stylefile\">\n";
echo "</head>\n<body>\n";

switch($_REQUEST["action"]) {
	case "docomment"://post comment to database
		//code here
		$dba->queryfirst("SELECT title,body FROM philp_newsitems WHERE itemid=".$_REQUEST["postingid"]);
		echo "<title>Comment on posting: [".$dba->lastrecord["title"]."]</title>\n";
		break;
	default://show all current comments and the form
		echo "<b>".$dba->lastrecord["title"]."</b><br><br>\n";
		echo nl2br($dba->lastrecord["body"])."<br>\n<hr noshade color=\"black\">";
		echo "Got something to say?<br><br>\n";
		formhead($self, "docomment");
		?>
		<input type="hidden" name="postingid" value="<?php echo $_REQUEST["postingid"]; ?>">
		Your name: <input type="text" name="fname">
		Your E-Mail-Address <input type="text" name="femail"><br><br>
		Your comment:<br>
		<textarea name="fcomment" wrap="virtual" cols="40" rows="8"></textarea>
		<?php
		formfoot("Save comment");
		break;
};
?>
</body>
</html>