<?
///////////////////////////////////
//      paBugs 1.0               //
//     Written by Todd           //
//   todd@phparena.uni.cc        //
//     �2001 PHP Arena           //
//  http://www.phparena.uni.cc   //
///////////////////////////////////
//Begin paBugs Installer
?>
<style type="text/css">
SELECT, option, textarea, input {   FONT-FAMILY:tahoma;color:#000000; FONT-SIZE: 12px; background-color:#eeeeee  }
a:link,a:visited,a:active {text-decoration:none; color:#990000; font-weight:plain;}
a:hover {text-decoration:none; color:#660000; font-weight: plain;}
</style>
<?
require "pabugsconfig.php"; //Require the settings file
echo "<title>paBugs 1.0 Installer</title><body bgcolor=\"#EEEEEE\" text=\"#000000\">";
if ($action == "install") {
	function errorcheck($error,$query) {
	        if (!empty($error)) {
        	echo "<font face=\"Tahoma\" size=\"2\"><font color=\"#FF0000\"><b>Error</b></font><p>The error was: $error<p>The MySQL query that created this error was: $query<p>The paBugs Installation <b>was not</b> completed";
        	die();
        } else {
        	echo "<font face=\"Tahoma\" size=\"2\"><font color=\"#00AA00\"><b>Done</b><br></font>";
        }	
	}
	
	$cryptpass = md5($password); //Encrypt the admin password (For security)
	echo "<font face=\"Tahoma\" size=\"2\">Installing paBugs...<p>";
	
	//Check to see if the Sessions directory exists and is writeable
	echo "<font face=\"Tahoma\" size=\"2\">Checking to see if the 'sessions' directory exists: "; 
	if (!file_exists("sessions")) {
		die("<font face=\"Tahoma\" size=\"2\"><font color=\"#FF0000\"><b>Error</b></font><p>The sessions directory does not exist. Please make sure you created a directory called 'sessions' in your paBugs directory.");
	} else {
		echo("<font face=\"Tahoma\" size=\"2\"><font face=\"Tahoma\" size=\"2\"><font color=\"#00AA00\"><b>Done-Directory Exists</font></b><br>");
	}
	echo "<font face=\"Tahoma\" size=\"2\">Checking to see if the 'sessions' directory is writeable: "; 
        @$file = fopen ("./sessions/test.txt", "w") or die ("<font face=\"Tahoma\" size=\"2\"><font color=\"#FF0000\"><b>Error</b></font><p>paFileDB was unable to write to the 'sessions' directory. Please make sure it is CHMODed 777 and try again.<p>The paFileDB Installation <b>was not</b> completed");
        echo "<font face=\"Tahoma\" size=\"2\"><font color=\"#00AA00\"><b>Done-Directory Is Writeable</font></b><br>";
        @fputs ($file, "This is a test file that was made during the paBugs setup to see if the 'sessions' directory is writeable. You can delete this file.");
        @fclose ($file);
	
	//Create the pabugs_bugs table
	echo "<font face=\"Tahoma\" size=\"2\">Creating table pabugs_bugs: ";
	$query = "CREATE TABLE pabugs_bugs (
        bug_id int(10) NOT NULL auto_increment,
        bug_category int(10),
        bug_priority int(1),
        bug_submitdate int(50),
        bug_updatedate int(50),
        bug_status int(1),
        bug_approver text,
        bug_summary text,
        bug_description text,
        bug_additional text,
        PRIMARY KEY (bug_id)
        )";
        mysql_query($query);
        $error = mysql_error();
        errorcheck($error,$query);
        //End Create pabugs_bugs
        
        //Create the pabugs_category table
	echo "<font face=\"Tahoma\" size=\"2\">Creating table pabugs_category: ";
	$query = "CREATE TABLE pabugs_category (
        category_id int(10) NOT NULL auto_increment,
        category_name text,
        category_desc text,
        category_bugs int(10),
        category_parent int(10),
        PRIMARY KEY (category_id)
        )";
        mysql_query($query);
        $error = mysql_error();
        errorcheck($error,$query);
        //End Create pabugs_category
        
        //Create the pabugs_admin table
	echo "<font face=\"Tahoma\" size=\"2\">Creating table pabugs_admin: ";
	$query = "CREATE TABLE pabugs_admin (
        admin_id int(10) NOT NULL auto_increment,
        admin_username text,
        admin_password text,
        admin_email text,
        admin_status int(1),
        admin_notify int(1),
        PRIMARY KEY (admin_id)
        )";
        mysql_query($query);
        $error = mysql_error();
        errorcheck($error,$query);
        //End Create pabugs_admin
        
        //Insert admin username into pabugs_admin
	echo "<font face=\"Tahoma\" size=\"2\">Inserting admin info into pabugs_admin: ";
	$query = "INSERT INTO pabugs_admin VALUES(NULL, '$username', '$cryptpass', '$email', '1', '1')";
        mysql_query($query);
        $error = mysql_error();
        errorcheck($error,$query);
        //End insert data
        echo "<p><font face=\"Tahoma\" size=\"2\">The paBugs 1.0 installation has sucessfully been completed! You can access your bugs database <a href=\"pabugs.php\">here</a> and access your admin center <a href=\"pabugsadmin\">here</a> and log in with the Admin name and password you specified when installing. For maximum security, please delete installer.php from your server</font>";
        die();
        
} else {
        echo "<font face=\"Tahoma\" size=\"2\">This script will set up your MySQL database for paBugs 1.0. Please make your your database configuration in pabugsconfig.php is correct and fill out the form to create the first administrator.<p>";
        echo "<form name=\"form\" method=\"POST\" action=\"installer.php\">";
    	echo "<font face=\"Tahoma\" size=\"2\">Admin UserName:</font>";
    	echo "<input type=\"text\" name=\"username\" size=\"50\"><br>";
    	echo "<font face=\"Tahoma\" size=\"2\">Admin Password:</font>";
    	echo "<input type=\"text\" name=\"password\" size=\"50\"><br>";
    	echo "<font face=\"Tahoma\" size=\"2\">Admin E-mail Address:</font>";
    	echo "<input type=\"text\" name=\"email\" size=\"50\"><br>";
    	echo "<input type=\"hidden\" name=\"action\" value=\"install\">";
    	echo "<input type=\"submit\" name=\"Submit\" value=\"Submit\">";
    	echo "</form>";
}
?>