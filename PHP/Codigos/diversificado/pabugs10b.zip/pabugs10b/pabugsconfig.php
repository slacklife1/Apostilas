<?
//Database Settings

$dbserver = "localhost"; //This is the server address of the MySQL database server.

$dbname = "pabugs"; //This is the name of the MySQL database that paFileDB will use.

$dbuser = "username"; //This is the username required to connect to the database.

$dbpass = "password"; //This is the password required to connect to the database

//Display Settings
/*
NOTE: The default text color needs to be set in either the <body> tag or CSS of the header file.
*/
$showstats = 1; //Show the PHP Execution Time stats on the bottom of every page. Unless you want to know how much CPU usage paBugs is using or just like those stats, set this to 0. If you want to show the stats, set it to 1. If you have no idea what all this means, set it to 0.

$trackername = "Bugs"; //This is the name of your bug tracker. For example: My Bugs, Bugs In SomeProgram, or The Very Large Bug Database For Windows ME

$logoimage = "pabugs.gif"; //This is the name of the image you want to use for the logo. Make sure it is in the "images" directory

$font = "Tahoma"; //This is the font to display the text in.

$fontsize = 2; //This is the size of the text.

$header = "header.html"; //This is the header file to be shown on every page.

$footer = "footer.html"; //This is the footer file to be shown on every page.

$rollcolor = "#EEEEEE"; //This is the color you want for the tables (Category list and bug list tables) when you move the mouse over them. The roll over color only works in Internet Explorer

$tbg1 = "#FFFFFF"; //This is the first table background color on the View Bug page

$text1 = "#000000"; //This is the color of the text that will be used when text is displayed on tables using the first background color.

$tbg2 = "#EEEEEE"; //This is the second table background color on the View Bug page

$text2 = "#000000"; //This is the color of the text that will be used when text is displayed on tables using the second background color.

$tableheader = "#AAAAAA"; //This is the background color of the table headers

$tableheadertext = "#000000"; //This is the background color of the text on the table headers

$highlight = "#FF0000"; //This is the highlight color. When someone searches the tracker and views one of the search results, the word they searched for is put in this color.

//Script Settings
$timeoffset = "0"; //This is the time offset (For example, if your server's time is in GMT, but you want the times in your tracker to be in Central US Time, you would set this to -6

$timezone = "Central Time"; //This is the time zone the times are in.

$pabugsurl = "http://www.mydomain.com/pabugs"; //This is the URL to the directory where paBugs is installed.

//Ignore everything down here.

mysql_pconnect("$dbserver","$dbuser","$dbpass") or die("There was an error connecting to the MySQL database."); //Connect to the DB and stop the script if there is a problem connecting.
mysql_selectdb("$dbname") or die("paBugs successfully connected to the MySQL server, but there was an error choosing the database \"$dbname\". Please make sure it exists on the server."); //Select the DB and stop the script if there is a problem selecting the DB.
$offsecs = $timeoffset * 3600;

?>