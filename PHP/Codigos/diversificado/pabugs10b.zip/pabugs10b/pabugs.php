<?
///////////////////////////////////
//      paBugs 1.0 Beta          //
//     Written by Todd           //
//   todd@phparena.uni.cc        //
//     �2001 PHP Arena           //
//  http://www.phparena.uni.cc   //
///////////////////////////////////
//Begin paBugs Main File
$starttime = microtime();
$starttime = explode(" ",$starttime);
$starttime = $starttime[1] + $starttime[0];
#####IF YOU ARE EDITING paBugs DO NOT PUT ANY CODE HERE THAT WILL CAUSE HTML OUTPUT. YOU CAN PUT CODE THAT CAUSES HTML OUTPUT DOWN A FEW LINES#####
session_save_path("./sessions");
session_start();
#####YOU CAN BEGIN ANY HTML OUTPUT AFTER THIS COMMENT#####
function show_copy() {
	echo "<center><p><font face=Tahoma size=2>Powered by paBugs 1.0 Beta<br>�2001 <a href=\"http://www.phparena.uni.cc\" target=\"_blank\">PHP Arena</a></font></center>";
}
?>
<script language="JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
<?
require "./pabugsext.ext";
require "pabugsconfig.$phpext"; //Require the config file.
$userip = getenv ("REMOTE_ADDR");
$usercryptip = md5($userip);
if (!empty($pabugsuser)) {
$query="SELECT * FROM pabugs_admin WHERE admin_username = '$pabugsuser'";
$result=mysql_query($query);
echo mysql_error();
$resdata = mysql_fetch_array($result);
$realpass = $resdata['admin_password'];
if ($pabugspw == $realpass && $usercryptip == $pabugsadminip) {
	$adminlogged = "1";
}
}
require "$header";
$pageurl = $HTTP_SERVER_VARS['REQUEST_URI'];
function jumpmenu($pageurl,$phpext,$timezone,$PHPSESSID,$font) { //Begin the jump menu function

echo ("
<p><p><table width=\"75%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\"><tr><td width=\"100%\">
<form name=\"form1\">
     <select name=\"menu1\" onChange=\"MM_jumpMenu('parent',this,0)\">
     <option value=\"$pageurl\" selected>Category Jump</option>
     <option value=\"$pageurl\">---------</option>");
     $query="SELECT * FROM pabugs_category ORDER BY category_id";
     $result=mysql_query($query);
     $number=mysql_numrows($result);
     $i = 0;
     while ($i < $number){
     $catid = mysql_result($result,$i,"category_id");
     $catname = mysql_result($result,$i,"category_name");
     $catpar = mysql_result($result,$i,"category_parent");
     if ($catpar == 0) {
     echo "<option value=\"pabugs.$phpext?PHPSESSID=$PHPSESSID&action=viewcat&id=$catid\">$catname</option>";
     }
     $i++;
     $query="SELECT * FROM pabugs_category ORDER BY category_id";
     $res = mysql_query($query);
     $n2 = mysql_numrows($res);
     $n = 0;
     while ($n < $n2) {
           $subcid = mysql_result($res,$n,"category_id");
           $subname = mysql_result($res,$n,"category_name");
           $subpar = mysql_result($res,$n,"category_parent");
           if ($subpar == $catid) {
                   echo "<option value=\"pabugs.$phpext?PHPSESSID=$PHPSESSID&action=viewcat&id=$subcid\">---$subname</option>";
           }
           $n++;
     }
     
    }
    echo ("  </select>
   </form><br><font face=\"$font\" size=\"1\">All times are $timezone</font></td></tr></table>");
} //End jump menu
function admintable($admintable,$pabugsuser) {
	echo ("
	<p><table width=\"75%\" border=\"1\" align=\"center\" cellpadding=\"1\" cellspacing=\"0\" bordercolor=\"eeeeee\">
        <tr bgcolor=\"#eeeeee\"> 
        <td width=\"100%\" align=\"left\"><center><font face=\"Tahoma\" size=\"2\" color=\"#000000\">You are currently logged in as $pabugsuser. Here are your authorized administrator options:</center></font></td></tr>
        <tr bgcolor=\"#ffffff\">
        <td width=\"100%\" align=\"left\"><center><font face=\"Tahoma\" size=\"2\" color=\"#000000\"><center>$admintable</center></td></tr></table>
        ");
}

echo("<table width=\"75%\" border=\"0\" align=\"center\" cellpadding=\"1\" cellspacing=\"0\">
<tr> 
<td width=\"50%\" align=\"left\"><font face=\"$font\" size=\"6\">$trackername
<font size=\"3\"></font></font><br><font face=\"$font\" size=\"$fontsize\"></font></td>

<td width=\"50%\" align=\"right\"><a href=\"pabugs.$phpext?PHPSESSID=$PHPSESSID\"><img src=\"images/$logoimage\" border=\"0\"></a></td>
</tr>
<tr><td width=\"75%\" colspan=\"3\"><center><a href=\"pabugs.$phpext?PHPSESSID=$PHPSESSID&action=search\"><img src=\"images/search.gif\" border=\"0\"></a>&nbsp;&nbsp;<a href=\"pabugs.$phpext?PHPSESSID=$PHPSESSID&action=report\"><img src=\"images/report.gif\" border=\"0\"></a>&nbsp;&nbsp;<a href=\"pabugs.$phpext?PHPSESSID=$PHPSESSID\"><img src=\"images/home.gif\" border=\"0\"></a></center></td></tr>
"); //Print out the header table

if ($action == "viewcat") {
	if ($order == "new2old") {
		$order = " DESC";
		$sorttext = "<a href=\"pabugs.$phpext?PHPSESSID=$PHPSESSID&action=viewcat&id=$id&order=old2new\">Sort Oldest to Newest</a>";
	}
	if ($order == "old2new") {
		$order = "";
		$sorttext = "<a href=\"pabugs.$phpext?PHPSESSID=$PHPSESSID&action=viewcat&id=$id&order=new2old\">Sort Newest to Oldest</a>"; 
	} else {
		$order = " DESC";
		$sorttext = "<a href=\"pabugs.$phpext?PHPSESSID=$PHPSESSID&action=viewcat&id=$id&order=old2new\">Sort Oldest to Newest</a>";
	}
	$query="SELECT * FROM pabugs_category WHERE category_id = '$id'";
        $result=mysql_query($query);
        $resdata = mysql_fetch_array($result);
       	$name = $resdata['category_name'];
       	$desc = $resdata['category_desc'];
        if ($adminlogged == "1") {
        	$admintable = "<font face=\"Tahoma\" size=\"2\"><a href=\"pabugsadmin?PHPSESSID=$PHPSESSID\">Admin Center</a> | <a href=\"pabugsadmin/adminmain.$phpext?PHPSESSID=$PHPSESSID&action=logout\">Logout</a> | <a href=\"pabugsadmin/adminmain.$phpext?PHPSESSID=$PHPSESSID&adminact=cat&catact=add&catadd=form\">Add Category</a> | <a href=\"pabugsadmin/adminmain.$phpext?PHPSESSID=$PHPSESSID&adminact=cat&catact=delete&catdelete=conf&id=$id\">Delete Category</a> | <a href=\"pabugsadmin/adminmain.$phpext?PHPSESSID=$PHPSESSID&adminact=cat&catact=edit&catedit=form&id=$id\">Edit Category</a> | <a href=\"pabugsadmin/adminmain.$phpext?PHPSESSID=$PHPSESSID&adminact=cat&catact=recount&catrecount=recount&id=$id\">Recount Category</a> | <a href=\"pabugsadmin/adminmain.$phpext?PHPSESSID=$PHPSESSID&adminact=bug&bugact=add&bugadd=form\">Add Bug</a></font>";
        	}
        echo("<tr>
        <td width=\"50%\" colspan=\"3\"><img src=\"images/closedfolder.gif\">&nbsp;<font face=\"$font\" size=\"1\"><a href=pabugs.$phpext?PHPSESSID=$PHPSESSID>$trackername</a>&nbsp;>>&nbsp;<img src=\"images/openfolder.gif\">&nbsp;$name</font></td>
        </tr>
        
        </table><p>&nbsp;</p>");
        
        ###Begin Sub Categories###
        $query="SELECT * FROM pabugs_category ORDER BY category_id";
        $result2=mysql_query($query);
        $numcats=mysql_numrows($result2);
        $a = 0;
        $numsubcats = 0;
        while ($a < $numcats){
        	$parentcat = mysql_result($result2,$a,"category_parent");
        	if ($parentcat == $id) {
        	$numsubcats++;
        	}
        	$a++;
        	
        }
        
        
        if ($numsubcats !== 0) {
        echo("<table width=\"75%\" border=\"1\" align=\"center\" bgcolor=\"$tablebgcolor\" cellpadding=\"1\" cellspacing=\"0\">
        <tr>
        <td width=\"82%\"><font face=\"$font\" size=\"$fontsize\"><b><center>Category Info</center></b></font></td>
        </tr>");
        $query="SELECT * FROM pabugs_category ORDER BY category_id";
        $result2=mysql_query($query);
        $number2=mysql_numrows($result2);
        $n = 0;

        while ($n < $number2){
        	
                $cid = mysql_result($result2,$n,"category_id");
                $catname = mysql_result($result2,$n,"category_name");
                $tbugs = mysql_result($result2,$n,"category_bugs");
                $desc = mysql_result($result2,$n,"category_desc");
                $parent = mysql_result($result2,$n,"category_parent");
                if ($parent == $id) {
                echo "<tr>
                <td width=\"82%\" height=\"22\" onMouseOver=\"this.style.backgroundColor='$rollcolor'; this.style.cursor='hand';\" onMouseOut=\"this.style.backgroundColor='';\" onclick=\"window.location.href='pabugs.$phpext?PHPSESSID=$PHPSESSID&action=viewcat&id=$cid'\"><font size=\"$fontsize\" face=\"$font\"><a href=\"pabugs.$phpext?PHPSESSID=$PHPSESSID&action=viewcat&id=$cid\">$catname</a></font><br>
                <font size=\"1\" face=\"$font\">>>Description: $desc<br>>>Total Bugs In Category: $tbugs</font>
                </tr>";
                }
                $n++;
        }
        echo "</table></p>";
        }
        ###End Sub Categories###
        echo("<table width=\"75%\" border=\"1\" cellspacing=\"0\" cellpadding=\"2\" bgcolor=\"$tablebgcolor\" align=\"center\">
        <tr> 
        <td width=\"6%\" align=\"center\" colspan=\"3\"><b><font face=\"$font\" size=\"$fontsize\">Bug Info</font></b></td>
        </tr>");
        $query="SELECT * FROM pabugs_bugs ORDER BY bug_id$order";
        $result=mysql_query($query);
        $number=mysql_numrows($result);
        
        
        $i = 0;
        $numincat = 0;
        while ($i < $number){
        	
                $bid = mysql_result($result,$i,"bug_id");
                $bcid = mysql_result($result,$i,"bug_category");
                $bpriority = mysql_result($result,$i,"bug_priority");
                $bdate = mysql_result($result,$i,"bug_submitdate");
                $budate = mysql_result($result,$i,"bug_updatedate");
                $bstatus = mysql_result($result,$i,"bug_status");
                $bsum = mysql_result($result,$i,"bug_summary");
                if ($bcid == "$id" && $bstatus != 0) {
                $numincat++;
                if ($budate !== $bdate) {
                $offtime = $budate + $offsecs;
                $updated = date("g:i A m/d/y","$offtime");
                } else { $updated = "Never"; }
                $offtime = $bdate + $offsecs;
                $realtime = date("g:i A m/d/y","$offtime");
                $prioritytext = "1 2 3 4 5";
                $prioritytext = str_replace("$bpriority" , "<font size=2><b>$bpriority</b></font>", "$prioritytext");
                if ($bpriority == 1) {
                	$priorityline = "<img src=\"images/green.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<font face=\"$font\" size=\"1\">1</font>";
                }
                if ($bpriority == 2) {
                	$priorityline = "<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/green.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<font face=\"$font\" size=\"1\">2</font>";
                }
                if ($bpriority == 3) {
                	$priorityline = "<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/green.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<font face=\"$font\" size=\"1\">3</font>";
                }
                if ($bpriority == 4) {
                	$priorityline = "<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/green.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<font face=\"$font\" size=\"1\">4</font>";
                }
                if ($bpriority == 5) {
                	$priorityline = "<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/green.gif\" border=\"0\">&nbsp;<font face=\"$font\" size=\"1\">5</font>";
                }
                
                if ($bstatus == 1) {
                	$statustext = "Not Fixed";
                }
                if ($bstatus == 2) {
                	$statustext = "Being Worked On";
                }
                if ($bstatus == 3) {
                	$statustext = "Fixed";
                }
                
                echo "
                <tr onMouseOver=\"this.style.backgroundColor='$rollcolor'; this.style.cursor='hand';\" onMouseOut=\"this.style.backgroundColor='';\" onclick=\"window.location.href='pabugs.$phpext?PHPSESSID=$PHPSESSID&action=viewbug&id=$bid'\"> 
                
                <td width=\"50%\"><font face=\"$font\" size=\"$fontsize\"><a href=\"pabugs.$phpext?PHPSESSID=$PHPSESSID&action=viewbug&id=$bid\">$bsum</a></font>
                </td>
                <td width=\"25%\"><font face=\"$font\" size=\"1\">>>Priority: $priorityline<br>>>Status: $statustext</font></td>
                <td width=\"25%\"><font face=\"$font\" size=\"1\">>>Added: $realtime<br>>>Last Updated: $updated</a></font></td>
                </tr>
                
                ";
                
                }
                $i++;
        }
        if ($numincat == 0) {
        	echo "
        	<tr>
        	<td width=\"50%\"><font face=\"$font\" size=\"$fontsize\"><center>There are no bugs in this category.</center></font>
                </tr>";
        } else {
        	if ($numincat == 1) {
        		$bw = "There is 1 bug";
        	} else {
        		$bw = "There are $numincat bugs";
        	}
        	echo "
        	<tr>
        	<td width=\"50%\" colspan=\"3\"><font face=\"$font\" size=\"$fontsize\"><center>$bw in this category.</center></font>
                </tr>";
        }
        
        echo "</table><table width=\"75%\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\" align=\"center\"><tr><td width=\"100%\" align=\"right\" colspan=\"2\"><font face=\"$font\" size=\"$fontsize\">$sorttext</font></td></tr>";
        jumpmenu($pageurl,$phpext,$timezone,$PHPSESSID,$font);
        show_copy();
        require "$footer";
        if ($adminlogged == 1) { admintable($admintable,$pabugsuser); }
        if ($showstats == 1) {
	$endtime = microtime();
        $endtime = explode(" ",$endtime);
        $endtime = $endtime[1] + $endtime[0];
        $stime = $endtime - $starttime;
        echo "\n<center><font face=\"Tahoma\" size=\"1\"> This page took '$stime' seconds to execute</center></font>\n";
}
        exit();
} 
if ($action == "viewbug") {
	if ($adminlogged == "1") {
        	$admintable = "<font face=\"Tahoma\" size=\"2\"><a href=\"pabugsadmin?PHPSESSID=$PHPSESSID\">Admin Center</a> | <a href=\"pabugsadmin/adminmain.$phpext?PHPSESSID=$PHPSESSID&action=logout\">Logout</a> | <a href=\"pabugsadmin/adminmain.$phpext?PHPSESSID=$PHPSESSID&adminact=bug&bugact=add&bugadd=form\">Add Bug</a> | <a href=\"pabugsadmin/adminmain.$phpext?PHPSESSID=$PHPSESSID&adminact=bug&bugact=delete&bugdelete=conf&id=$id\">Delete Bug</a> | <a href=\"pabugsadmin/adminmain.$phpext?PHPSESSID=$PHPSESSID&adminact=bug&bugact=edit&bugedit=form&id=$id\">Edit Bug</a></font>";
        }
        $query="SELECT * FROM pabugs_bugs WHERE bug_id = '$id'";
        $result=mysql_query($query);
        $resdata2 = mysql_fetch_array($result);
       	$bugcat = $resdata2['bug_category'];
       	$bugpriority = $resdata2['bug_priority'];
       	$bugdate = $resdata2['bug_submitdate'];
       	$bugudate = $resdata2['bug_updatedate'];
       	$bugstatus = $resdata2['bug_status'];
       	$bugsummary = $resdata2['bug_summary'];
       	$bugdescription = $resdata2['bug_description'];
       	$bugadditional = $resdata2['bug_additional'];
       	$query="SELECT * FROM pabugs_category WHERE category_id = '$bugcat'";
        $result=mysql_query($query);
        $resdata = mysql_fetch_array($result);
       	$cname = $resdata['category_name'];
       	$cid = $resdata['category_id'];
       	if ($bugudate !== $bugdate) {
                $offtime = $bugudate + $offsecs;
                $updated = date("g:i A m/d/y","$offtime");
        } else { $updated = "Never"; }
        $offtime = $bugdate + $offsecs;
        $realtime = date("g:i A m/d/y","$offtime");
        $prioritytext = "1 2 3 4 5";
        $prioritytext = str_replace("$bugpriority" , "<font size=3><b>$bugpriority</b></font>", "$prioritytext");
                if ($bugpriority == 1) {
                	$priorityline = "<img src=\"images/green.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<font face=\"$font\" size=\"$fontsize\">1</font>";
                }
                if ($bugpriority == 2) {
                	$priorityline = "<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/green.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<font face=\"$font\" size=\"$fontsize\">2</font>";
                }
                if ($bugpriority == 3) {
                	$priorityline = "<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/green.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<font face=\"$font\" size=\"$fontsize\">3</font>";
                }
                if ($bugpriority == 4) {
                	$priorityline = "<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/green.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<font face=\"$font\" size=\"$fontsize\">4</font>";
                }
                if ($bugpriority == 5) {
                	$priorityline = "<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/gray.gif\" border=\"0\">&nbsp;<img src=\"images/green.gif\" border=\"0\">&nbsp;<font face=\"$font\" size=\"$fontsize\">5</font>";
                }
        if ($bugstatus == 1) {
                $statustext = "Not Fixed";
        }
        if ($bugstatus == 2) {
                $statustext = "Being Worked On";
        }
        if ($bugstatus == 3) {
                $statustext = "Fixed";
        }
        $hl = trim($hl);
        if (!empty($hl)) {
        	$bugsummary = str_replace("$hl" , "<font color=\"$highlight\"><b>$hl</b></font>", "$bugsummary");
        	$bugdescription = str_replace("$hl" , "<font color=\"$highlight\"><b>$hl</b></font>", "$bugdescription");
        	$bugadditional = str_replace("$hl" , "<font color=\"$highlight\"><b>$hl</b></font>", "$bugadditional");
        }
        
       	echo("<tr>
        <td width=\"50%\" colspan=\"3\"><img src=\"images/closedfolder.gif\">&nbsp;<font face=\"$font\" size=\"1\"><a href=pabugs.$phpext?PHPSESSID=$PHPSESSID>$trackername</a>&nbsp;>>&nbsp;<img src=\"images/closedfolder.gif\">&nbsp;<a href=pabugs.$phpext?PHPSESSID=$PHPSESSID&action=viewcat&id=$cid>$cname</a>&nbsp;>>&nbsp;<img src=\"images/openfolder.gif\">&nbsp;View Bug</font></td></tr>");
        echo "</table><p>&nbsp;</p>";
        $bugadditional = trim($bugadditional);
        if (empty($bugadditional)) { $bugadditional = "None"; }
        echo("
        <center><table border=\"1\" cellpadding=\"2\" cellspacing=\"1\" width=\"75%\">
        <tr bgcolor=\"$tableheader\">
        <td width=\"50%\" colspan=\"2\">
        <p align=\"center\"><font face=\"$font\" size=\"$fontsize\" color=\"$tableheadertext\"><b>Bug Information</b></td></tr>
        <tr bgcolor=\"$tbg1\">
        <td width=\"50%\" colspan=\"2\"><font face=\"$font\" size=\"$fontsize\" color=\"$text1\"><b>Summary:</b> $bugsummary</td></tr>
        <tr bgcolor=\"$tbg2\">
        <td width=\"50%\"><font face=\"$font\" size=\"$fontsize\" color=\"$text2\"><b>Priority:</b> $priorityline</td>
        <td width=\"50%\"><font face=\"$font\" size=\"$fontsize\" color=\"$text2\"><b>Status:</b> $statustext</td>
        </tr>
        <tr bgcolor=\"$tbg1\">
        <td width=\"50%\" colspan=\"2\"><font face=\"$font\" size=\"$fontsize\" color=\"$text1\"><b>Description:</b> $bugdescription</td></tr>
        <tr bgcolor=\"$tbg2\">
        <td width=\"50%\"><font face=\"$font\" size=\"$fontsize\" color=\"$text2\"><b>Added:</b> $realtime</td>
        <td width=\"50%\"><font face=\"$font\" size=\"$fontsize\" color=\"$text2\"><b>Last Updated:</b> $updated</td>
        </tr>
        <tr bgcolor=\"$tbg1\">
        <td width=\"50%\" colspan=\"2\"><font face=\"$font\" size=\"$fontsize\" color=\"$text1\"><b>Additional Info:</b> $bugadditional</td></tr>
        </table></center>
        ");        
                
        jumpmenu($pageurl,$phpext,$timezone,$PHPSESSID,$font);
        show_copy();
        require "$footer";
        if ($adminlogged == 1) { admintable($admintable,$pabugsuser); }
        if ($showstats == 1) {
	$endtime = microtime();
        $endtime = explode(" ",$endtime);
        $endtime = $endtime[1] + $endtime[0];
        $stime = $endtime - $starttime;
        echo "\n<center><font face=\"Tahoma\" size=\"1\"> This page took '$stime' seconds to execute</center></font>\n";
}
        exit();
} 
if ($action == "report") {
	if ($adminlogged == "1") {
        	$admintable = "<font face=\"Tahoma\" size=\"2\"><a href=\"pabugsadmin?PHPSESSID=$PHPSESSID\">Admin Center</a> | <a href=\"pabugsadmin/adminmain.$phpext?PHPSESSID=$PHPSESSID&action=logout\">Logout</a></font>";
        	}
	echo("<tr>
        <td width=\"50%\" colspan=\"3\"><img src=\"images/closedfolder.gif\">&nbsp;<font face=\"$font\" size=\"1\"><a href=pabugs.$phpext?PHPSESSID=$PHPSESSID>$trackername</a>&nbsp;>>&nbsp;<img src=\"images/openfolder.gif\">&nbsp;Report Bug</font></td>
        </tr>
        </table><p>&nbsp;</p>
        <table width=\"75%\" border=\"0\" align=\"center\" cellspacing=\"0\">
        <tr> 
        <td>");
	if ($report == "report") {
		                $summary = trim($summary);
		                if (empty($summary)) {
					die ("<font face=\"$font\" size=$fontsize>You have left the Bug Summary field empty! Please go back and fill it in.");
				}
				$description = trim($description);
				if (empty($description)) {
					die ("<font face=\"$font\" size=$fontsize>You have left the Bug Description field empty! Please go back and fill it in.");
				}
				if (empty($additional)) {
					$additional = "None";
				}
				$time = time();
                                $description = str_replace ("\n", "<br>", "$description");
                                $additional = str_replace ("\n", "<br>", "$additional");
                                $addsql = "INSERT INTO pabugs_bugs VALUES(NULL, '$catid', '$priority', '0', '0', '0', 'Guest', '$summary', '$description', '$additional')";
                                $result = mysql_query($addsql);
                                echo "<p><font face=\"$font\" size=$fontsize>The bug has been reported! Please note that the bug will not appear in the database until an admin approves it.";
	                        $query="SELECT * FROM pabugs_admin ORDER BY admin_id";
                        	$result=mysql_query($query);
                                $number=mysql_numrows($result);
                                $i = 0;

                                while ($i < $number){
                                	$email = mysql_result($result,$i,"admin_email");
                                	$notify = mysql_result($result,$i,"admin_notify");
                                	$un = mysql_result($result,$i,"admin_username");
                                	if ($notify == 1) {
                                		$message = "";
                                		$message .= "Hello, $un\n\n";
                                		$message .= "Someone has reported a bug in your bug tracker, $trackername and it needs to be approved by an admin in order for the bug to be displayed in the database. Here are the details of the bug\n";
                                		$message .= "Summary: $summary\n";
                                		$message .= "Description: $description\n";
                                		$message .= "Additional Info: $additional\n";
                                		$message .= "Priority: $priority (Out of 5)\n\n";
                                		$message .= "You may access your admin center to approve this bug by going to $pabugsurl/pabugsadmin and logging in with your username and password.\n";
                                		$message .= "You can disable e-mail notification by going to the \"Change Options\" section of the admin center.";
                                		$subject = "[paBugs] Notification: New Bug Reported";
                                		mail("$email", "$subject", "$message");
                                	
                                	}
                                	$i++;
                                }
	}
	if (empty($report)) {
		                function showcategories() {
		                echo ("<select name=\"catid\">");
                                $query="SELECT * FROM pabugs_category ORDER BY category_id";
                	        $result=mysql_query($query);
                                $number=mysql_numrows($result);
                                $i = 0;
                                while ($i < $number){
                        	        $cid = mysql_result($result,$i,"category_id");
                                	$cname = mysql_result($result,$i,"category_name");
                                	echo "<option value=\"$cid\">$cname</option>";
                                	$i++;
                                }
                                echo("</select>");
                                }
			       echo ("
		               <form name=\"form1\" method=\"post\" action=\"pabugs.$phpext\">
		               <input type=\"hidden\" name=\"PHPSESSID\" value=\"$PHPSESSID\">
                               <table width=\"100%\" border=\"1\" align=\"center\" cellspacing=\"0\">
                               <tr> 
                               <td colspan=\"2\"> 
                               <div align=\"center\"><font face=\"$font\" size=\"4\"><font color=\"#000000\">Report 
                               a Bug<br>
                               <font size=\"2\">&gt;&gt;This form will allow you to report a bug so it can be added to the bug tracker.</font></font></font></div>
                               </td>
                               </tr>
                               <tr> 
                               <td width=\"25%\"><font size=\"$fontsize\" face=\"$font\">Bug Summary:</font></td>
                               <td width=\"75%\"> <font face=\"$font\" size=\"1\"> 
                               <input type=\"text\" name=\"summary\" size=\"50\">
                               <br>
                               This is a short, one line summary of the bug you are reporting (Example: \"[Feature] Causes [Error Message]\")</font> 
                               </td>
                               </tr>
                               <tr> 
                               <td width=\"25%\"><font size=\"$fontsize\" face=\"$font\">Bug Description:</font></td>
                               <td width=\"75%\"> <font face=\"$font\" size=\"1\"> 
                               <textarea name=\"description\" cols=\"70\" rows=\"5\"></textarea>
                               <br>
                               This is a detailed description of the bug you are reporting, such as what the bug is, steps to reproduce the bug, ect.</font></td>
                               </tr>
                               <tr> 
                               <td width=\"25%\"><font size=\"$fontsize\" face=\"$font\">Bug Priority:</font></td>
                               <td width=\"75%\"> <font face=\"$font\" size=\"1\"> 
                               <select name=\"priority\">
                                <option value=\"1\">1</option>
                                <option value=\"2\">2</option>
                                <option value=\"3\">3</option>
                                <option value=\"4\">4</option>
                                <option value=\"5\">5</option>
                               </select>
                               <br>
                               This is the priority or importance of the bug with 1 being the lowest and 5 being the highest. (Example: Security holes are a 5, spelling errors are a 1)</font></td>
                               </tr>
                               <tr> 
                               <td width=\"25%\"><font size=\"$fontsize\" face=\"$font\">Additional Info:</font></td>
                               <td width=\"75%\"> <font face=\"$font\" size=\"1\"> 
                               <textarea name=\"additional\" cols=\"70\" rows=\"5\"></textarea>
                               <br>
                               This is any additional info you may have about the bug (Example: URL to download bug fixes.)</font></td>
                               </tr>
                               <tr> 
                               <td width=\"25%\"><font size=\"$fontsize\" face=\"$font\">Category:</font></td>
                               <td width=\"75%\"><font face=\"$font\" size=\"$fontsize\">"); showcategories(); echo ("<br>
                               Choose a category that the bug belongs in.</font> 
                               </td>
                               <tr> 
                               <td height=\"24\" colspan=\"2\"> 
                               <div align=\"center\">&nbsp; 
                               <input type=\"submit\" name=\"Submit\" value=\"Submit\">
                               <input type=\"reset\" name=\"Submit2\" value=\"Reset\">
                               <br>
                               <input type=\"hidden\" name=\"action\" value=\"report\">
                               <input type=\"hidden\" name=\"report\" value=\"report\">
                               </div>
                               </td>
                               </tr>
                               </table>
                               </form>");
	}
	echo "</td></tr></table>";
	jumpmenu($pageurl,$phpext,$timezone,$PHPSESSID,$font);
        show_copy();
        require "$footer";
        if ($adminlogged == 1) { admintable($admintable,$pabugsuser); }
        if ($showstats == 1) {
	$endtime = microtime();
        $endtime = explode(" ",$endtime);
        $endtime = $endtime[1] + $endtime[0];
        $stime = $endtime - $starttime;
        echo "\n<center><font face=\"Tahoma\" size=\"1\"> This page took '$stime' seconds to execute</center></font>\n";
}
        exit();
}
if ($action == "search") {
	if ($adminlogged == "1") {
        	$admintable = "<font face=\"Tahoma\" size=\"2\"><a href=\"pabugsadmin?PHPSESSID=$PHPSESSID\">Admin Center</a> | <a href=\"pabugsadmin/adminmain.$phpext?PHPSESSID=$PHPSESSID&action=logout\">Logout</a></font>";
        	}
	echo("<tr>
        <td width=\"50%\" colspan=\"3\"><img src=\"images/closedfolder.gif\">&nbsp;<font face=\"$font\" size=\"1\"><a href=pabugs.$phpext?PHPSESSID=$PHPSESSID>$trackername</a>&nbsp;>>&nbsp;<img src=\"images/openfolder.gif\">&nbsp;Search</font></td>
        </tr>
        </table><p>&nbsp;</p>
        <table width=\"100%\" border=\"0\" align=\"center\" cellspacing=\"0\">
        <tr> 
        <td>");
	if ($search == "search") {
		$string = trim ($string);
		if (empty($string)) {
			die("<font face=\"$font\" size=\"$fontsize\">Please enter words to search for.");
		}
		echo("<table width=\"75%\" border=\"1\" cellspacing=\"0\" cellpadding=\"2\" bgcolor=\"$tablebgcolor\" align=\"center\">
                <tr> 
                <td width=\"6%\" align=\"center\" colspan=\"3\"><b><font face=\"$font\" size=\"$fontsize\">Search Results For: $string</font></b></td>
                </tr>");
	        $query="SELECT * FROM pabugs_bugs ORDER BY bug_id DESC";
                $result=mysql_query($query);
                $number=mysql_numrows($result);
                $i = 0;
                $hits = 0;
                while ($i < $number){
                	$bid = mysql_result($result,$i,"bug_id");
                	$bpriority = mysql_result($result,$i,"bug_priority");
             	        $bdate = mysql_result($result,$i,"bug_submitdate");
                        $budate = mysql_result($result,$i,"bug_updatedate");
                        $bstatus = mysql_result($result,$i,"bug_status");
                        $bsummary = mysql_result($result,$i,"bug_summary");
                        $bdesc = mysql_result($result,$i,"bug_description");
                        $badditional = mysql_result($result,$i,"bug_additional");
                        $maininfo = "$bsummary $bdesc $badditional";
                        
                        if (preg_match ("/$string/i", "$maininfo") && $bstatus != 0) {
                        	$hits++;
                        	if ($budate !== $bdate) {
                                $offtime = $budate + $offsecs;
                                $updated = date("g:i A m/d/y","$offtime");
                                } else { $updated = "Never"; }
                                $offtime = $bdate + $offsecs;
                                $realtime = date("g:i A m/d/y","$offtime");
                                $prioritytext = "1 2 3 4 5";
                                $prioritytext = str_replace("$bpriority" , "<font size=2><b>$bpriority</b></font>", "$prioritytext");
                                if ($bstatus == 1) {
                                	$statustext = "Not Fixed";
                                }
                                if ($bstatus == 2) {
                                	$statustext = "Being Worked On";
                                }
                                if ($bstatus == 3) {
                                	$statustext = "Fixed";
                                }
                        	echo "
                                <tr onMouseOver=\"this.style.backgroundColor='$rollcolor'; this.style.cursor='hand';\" onMouseOut=\"this.style.backgroundColor='';\" onclick=\"window.location.href='pabugs.$phpext?PHPSESSID=$PHPSESSID&action=viewbug&id=$bid&hl=$string'\"> 
                                <td width=\"50%\"><font face=\"$font\" size=\"$fontsize\"><a href=\"pabugs.$phpext?PHPSESSID=$PHPSESSID&action=viewbug&id=$bid&hl=$string\">$bsummary</a></font>
                                </td>
                                <td width=\"25%\"><font face=\"$font\" size=\"1\">>>Priority: $prioritytext<br>>>Status: $statustext</font></td>
                                <td width=\"25%\"><font face=\"$font\" size=\"1\">>>Added: $realtime<br>>>Last Updated: $updated</a></font></td>
                                </tr>
                                ";
                        }
                        $i++;
                }
                if ($hits == 0) {
                         echo "<tr><td width=\"100%\" colspan=\"3\"><font face=\"$font\" size=\"$fontsize\">No matches were found for $string.</td></tr>";
                }
                if ($hits == 1) {
                         echo "<tr><td width=\"100%\" colspan=\"3\"><font face=\"$font\" size=\"$fontsize\"><b>1</b> match was found for $string.</td></tr>";
                }
                if ($hits > 1) {
                         echo "<tr><td width=\"100%\" colspan=\"3\"><font face=\"$font\" size=\"$fontsize\"><b>$hits</b> matches were found for $string.</td></tr>";
                }
	        echo "</table>";
	}
	if (empty($search)) {
		echo ("
		               <form name=\"form1\" method=\"post\" action=\"pabugs.$phpext\">
		               <input type=\"hidden\" name=\"PHPSESSID\" value=\"$PHPSESSID\">
                               <table width=\"75%\" border=\"1\" align=\"center\" cellspacing=\"0\">
                               <tr> 
                               <td colspan=\"2\"> 
                               <div align=\"center\"><font face=\"$font\" size=\"4\"><font color=\"#000000\">Search<br>
                               <font size=\"2\">&gt;&gt;This form will allow you to search the bug tracker for a certian word.</font></font></font></div>
                               </td>
                               </tr>
                               <tr> 
                               <td width=\"25%\"><font size=\"$fontsize\" face=\"$font\">Search For:</font></td>
                               <td width=\"75%\"> <font face=\"$font\" size=\"1\"> 
                               <input type=\"text\" name=\"string\" size=\"50\">
                               <br>
                               Choose a word or words to search the tracker for.</font> 
                               </td>
                               </tr>
                               <tr> 
                               <td height=\"24\" colspan=\"2\"> 
                               <div align=\"center\">&nbsp; 
                               <input type=\"submit\" name=\"Submit\" value=\"Submit\">
                               <input type=\"reset\" name=\"Submit2\" value=\"Reset\">
                               <br>
                               <input type=\"hidden\" name=\"action\" value=\"search\">
                               <input type=\"hidden\" name=\"search\" value=\"search\">
                               </div>
                               </td>
                               </tr>
                               </table>
                               </form>");
	}
	jumpmenu($pageurl,$phpext,$timezone,$PHPSESSID,$font);
        show_copy();
        require "$footer";
        if ($adminlogged == 1) { admintable($admintable,$pabugsuser); }
        if ($showstats == 1) {
	$endtime = microtime();
        $endtime = explode(" ",$endtime);
        $endtime = $endtime[1] + $endtime[0];
        $stime = $endtime - $starttime;
        echo "\n<center><font face=\"Tahoma\" size=\"1\"> This page took '$stime' seconds to execute</center></font>\n";
}
        exit();
}

else {$action = ""; }
if (empty($action)) {
	if ($adminlogged == "1") {
        	$admintable = "<font face=\"Tahoma\" size=\"2\"><a href=\"pabugsadmin?PHPSESSID=$PHPSESSID\">Admin Center</a> | <a href=\"pabugsadmin/adminmain.$phpext?PHPSESSID=$PHPSESSID&adminact=cat&catact=add&catadd=form\">Add Category</a> | <a href=\"pabugsadmin/adminmain.$phpext?PHPSESSID=$PHPSESSID&action=logout\">Logout</a></font>";
        	}
	echo("<tr>
        <td width=\"50%\" colspan=\"3\"><img src=\"images/openfolder.gif\">&nbsp;<font face=\"$font\" size=\"1\">$trackername</font></td>
        </tr>
        </table><p>&nbsp;</p>
        <table width=\"75%\" border=\"1\" align=\"center\" bgcolor=\"$tablebgcolor\" cellpadding=\"1\" cellspacing=\"0\">
        <tr>
        <td width=\"82%\"><font face=\"$font\" size=\"$fontsize\"><b><center>Category Info</center></b></font></td>
        </tr>");
        $query="SELECT * FROM pabugs_category ORDER BY category_id";
        $result=mysql_query($query);
        $number=mysql_numrows($result);
        $i = 0;
        if ($number == 0) {
        	echo "<tr>
        	<td width=\"82%\"><center><font face=\"$font\" size=\"$fontsize\">There are no categories in this bug tracker.</center></font>
                </tr>";
        }
        

        while ($i < $number){
        	
                $cid = mysql_result($result,$i,"category_id");
                $catname = mysql_result($result,$i,"category_name");
                $tbugs = mysql_result($result,$i,"category_bugs");
                $desc = mysql_result($result,$i,"category_desc");
                $parent = mysql_result($result,$i,"category_parent");
                if ($parent == 0) {
                echo "<tr>
                <td width=\"82%\" height=\"22\" onMouseOver=\"this.style.backgroundColor='$rollcolor'; this.style.cursor='hand';\" onMouseOut=\"this.style.backgroundColor='';\" onclick=\"window.location.href='pabugs.$phpext?PHPSESSID=$PHPSESSID&action=viewcat&id=$cid'\"><font size=\"$fontsize\" face=\"$font\"><a href=\"pabugs.$phpext?PHPSESSID=$PHPSESSID&action=viewcat&id=$cid\">$catname</a></font><br>
                <font size=\"1\" face=\"$font\">>>Description: $desc<br>>>Total Bugs In Category: $tbugs</font>
                </tr>";
                }
                $i++;
        }
        echo "</table>";
        jumpmenu($pageurl,$phpext,$timezone,$PHPSESSID,$font);
        show_copy();
        require "$footer";
        if ($adminlogged == 1) { admintable($admintable,$pabugsuser); }
        if ($showstats == 1) {
	$endtime = microtime();
        $endtime = explode(" ",$endtime);
        $endtime = $endtime[1] + $endtime[0];
        $stime = $endtime - $starttime;
        echo "\n<center><font face=\"Tahoma\" size=\"1\"> This page took '$stime' seconds to execute</center></font>\n";
}
        exit();
}

?>