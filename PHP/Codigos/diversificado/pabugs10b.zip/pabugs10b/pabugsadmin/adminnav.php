<?
#####IF YOU ARE EDITING paFileDB DO NOT PUT ANY CODE HERE THAT WILL CAUSE HTML OUTPUT. YOU CAN PUT CODE THAT CAUSES HTML OUTPUT DOWN A FEW LINES#####
session_save_path("../sessions");
session_start();
#####YOU CAN BEGIN ANY HTML OUTPUT AFTER THIS COMMENT#####
require "../pabugsext.ext";
require "../pabugsconfig.$phpext";
function show_copy() {
	echo "<center><p><font face=Tahoma size=2>Powered by paBugs 1.0 Beta<br>�2001 <a href=\"http://www.phparena.uni.cc\" target=\"_blank\">PHP Arena</a></font></center>";
} ?>
<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Adminnav</title>
<style type="text/css">
SELECT, option, textarea, input {   FONT-FAMILY:tahoma;color:#000000; FONT-SIZE: 12px; background-color:#eeeeee  }
a:link,a:visited,a:active {text-decoration:none; color:#990000; font-weight:plain;}
a:hover {text-decoration:none; color:#660000; font-weight: plain;}
</style>
<SCRIPT LANGUAGE='JAVASCRIPT' TYPE='TEXT/JAVASCRIPT'>
 <!--
/****************************************************
     AUTHOR: WWW.CGISCRIPT.NET, LLC
     URL: http://www.cgiscript.net
     Use the code for FREE but leave this message intact.
     Download your FREE CGI/Perl Scripts today!
     ( http://www.cgiscript.net/scripts.htm )
****************************************************/
var win=null;
function NewWindow(mypage,myname,w,h,pos,infocus){
if(pos=="random"){myleft=(screen.width)?Math.floor(Math.random()*(screen.width-w)):100;mytop=(screen.height)?Math.floor(Math.random()*((screen.height-h)-75)):100;}
if(pos=="center"){myleft=(screen.width)?(screen.width-w)/2:100;mytop=(screen.height)?(screen.height-h)/2:100;}
else if((pos!='center' && pos!="random") || pos==null){myleft=0;mytop=20}
settings="width=" + w + ",height=" + h + ",top=" + mytop + ",left=" + myleft + ",scrollbars=no,location=no,directories=no,status=no,menubar=no,toolbar=no,resizable=no";win=window.open(mypage,myname,settings);
win.focus();}
// -->
</script>
</head>
<body bgcolor="#eeeeee">
<?
if ($sessionpw == $cryptpass) {
?>


<p><font face="Tahoma" size="2"><b>Category Options</b><br>
</font><font face="Tahoma" size="1">-<a href="adminmain.<? echo $phpext; ?>?adminact=cat&catact=add&catadd=form&PHPSESSID=<? echo $PHPSESSID; ?>" target="main">Add Category</a><br>
<font size="1">-<a href="adminmain.<? echo $phpext; ?>?adminact=cat&catact=edit&catedit=list&PHPSESSID=<? echo $PHPSESSID; ?>" target="main">Edit Category</a><br>
-<a href="adminmain.<? echo $phpext; ?>?adminact=cat&catact=delete&catdelete=list&PHPSESSID=<? echo $PHPSESSID; ?>" target="main">Delete Category</a><br>
-<a href="adminmain.<? echo $phpext; ?>?adminact=cat&catact=recount&catrecount=list&PHPSESSID=<? echo $PHPSESSID; ?>" target="main">Recount Category</a></font></p>
<p><b><font face="Tahoma" size="2">Bug Options</font></b><font face="Tahoma" size="1"><br>
<font size="1">-<a href="adminmain.<? echo $phpext; ?>?adminact=bug&bugact=add&bugadd=form&PHPSESSID=<? echo $PHPSESSID; ?>" target="main">Add Bug</a></font><br>
<font size="1">-<a href="adminmain.<? echo $phpext; ?>?adminact=bug&bugact=edit&bugedit=list&PHPSESSID=<? echo $PHPSESSID; ?>" target="main">Edit Bug</a></font><br>
<font size="1">-<a href="adminmain.<? echo $phpext; ?>?adminact=bug&bugact=delete&bugdelete=list&PHPSESSID=<? echo $PHPSESSID; ?>" target="main">Delete Bug</a></font><br>
<font size="1">-<a href="adminmain.<? echo $phpext; ?>?adminact=bug&bugact=approve&bugapprove=list&PHPSESSID=<? echo $PHPSESSID; ?>" target="main">Approve Bug</a></font></p>
<?
$query="SELECT * FROM pabugs_admin WHERE admin_username = '$pabugsuser'";
$result=mysql_query($query);
$resdata = mysql_fetch_array($result);
$superadmin = $resdata['admin_status'];
if ($superadmin == 1) {
?>
<p><font face="Tahoma"><b><font size="2">Admin Options</font></b><br>
<font size="1">-<a href="adminmain.<? echo $phpext; ?>?adminact=users&useract=add&useradd=form&PHPSESSID=<? echo $PHPSESSID; ?>" target="main">Add Admin</a><br>
-<a href="adminmain.<? echo $phpext; ?>?adminact=users&useract=edit&useredit=list&PHPSESSID=<? echo $PHPSESSID; ?>" target="main">Edit/Delete Admin</a><br>
<?
}
?>
<p><font face="Tahoma"><b><font size="2">Your Options</font></b><br>
<font size="1">-<a href="adminmain.<? echo $phpext; ?>?adminact=info&infoact=options&infooptions=form&PHPSESSID=<? echo $PHPSESSID; ?>" target="main">Change Options</a><br>
-<a href="adminmain.<? echo $phpext; ?>?adminact=info&infoact=password&infopassword=form&PHPSESSID=<? echo $PHPSESSID; ?>" target="main">Change Password</a><br>
<p><font face="Tahoma"><b><font size="2">Other Options</font></b><br>
<font size="1">-<a href="adminmain.<? echo $phpext; ?>?adminact=misc&miscact=manual&PHPSESSID=<? echo $PHPSESSID; ?>" target="main">View Manual</a><br>
-<a href="adminmain.<? echo $phpext; ?>?adminact=misc&miscact=license&PHPSESSID=<? echo $PHPSESSID; ?>" target="main">View paBugs License</a></font></font><br>
-<a href="javascript:NewWindow('http://www.phparena.uni.cc/pabugs/versioncheck.php?scriptversion=10b','versionwindow','400','200','custom','front');">Version Check</a><br>
-<a href="adminmain.<? echo $phpext; ?>?action=logout" target="main">Logout</a></font></font><br>
<p>
<font size="1" face="Tahoma">Logged in as:<br><?php echo $pabugsuser ?>
<? } else {
	echo "<body bgcolor=\"#eeeeee\">";
	echo "<font face=\"Tahoma\" size=\"2\">Please Log In";
	}

 show_copy();	?>
</body>

</html>
