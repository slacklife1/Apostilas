<?
///////////////////////////////////
//      paBugs 1.0 Beta          //
//     Written by Todd           //
//   todd@phparena.uni.cc        //
//     �2001 PHP Arena           //
//  http://www.phparena.uni.cc   //
///////////////////////////////////
//Begin paBugs Main Admin File

$starttime = microtime();
$starttime = explode(" ",$starttime);
$starttime = $starttime[1] + $starttime[0];

session_save_path("../sessions");
session_start();
session_register('pabugsuser');
session_register('pabugspw');
session_register('pabugsadminip');
require "../pabugsext.ext";
require "../pabugsconfig.$phpext";
if ($action == "login") { //Begin the login process
	        $query="SELECT * FROM pabugs_admin WHERE admin_username = '$formname'";
	        $result=mysql_query($query);
                $resdata = mysql_fetch_array($result);
       	        $realpass = $resdata['admin_password'];
       	        $cryptform = md5($formpass);
       	        if ($cryptform == $realpass) {
       	        	$pabugsuser = $formname;
       	        	$pabugspw = $realpass;
       	        	$adminip = getenv ("REMOTE_ADDR");
       	        	$pabugsadminip = md5($adminip);
       	        	@header ("Location: index.$phpext?PHPSESSID=$PHPSESSID");
       	        	echo("<meta http-equiv=\"refresh\" content=\"1; url=index.$phpext\">");
                        echo "<body bgcolor=\"#eeeeee\">";
                        echo "<font face=Tahoma size=2>If you are not taken to your admin center in 5 seconds, <a href=\"index.$phpext?PHPSESSID=$PHPSESSID\">click here</a>"; //Tell the user that they're logged in
                        
                        exit(); //End the script 
	} else {
		
		$error = "yes";
	}//End wrong pass
}
?>
<style type="text/css">
SELECT, option, textarea, input {   FONT-FAMILY:tahoma;color:#000000; FONT-SIZE: 12px; background-color:#eeeeee  }
a:link,a:visited,a:active {text-decoration:none; color:#990000; font-weight:plain;}
a:hover {text-decoration:none; color:#660000; font-weight: plain;}
</style>
<body bgcolor="#eeeeee">
<?
if ($action == "logout") { //Begin the login process
                session_destroy();
                echo "<body bgcolor=\"#eeeeee\">";
                echo "<font face=Tahoma size=2>You have been logged out!<p>"; //Tell the user that they're logged in
	        exit(); //End the script 

}
if ($action == "lostpassword") {
	if ($lp == "step1") {
		if ($step == "form") {
				echo ("
	                        <form action=\"adminmain.$phpext\" name=\"form\" method=\"post\">
	                        <table width=\"70%\" border=\"1\" align=\"center\" cellspacing=\"0\">
                                <tr> 
                                <td colspan=\"2\"> 
                                <div align=\"center\"><font face=\"Tahoma\" size=\"4\"><font color=\"#000000\">Lost Password<br>
                                <font size=\"2\">&gt;&gt;Enter your username below to get your lost password.</font></font></font></div>
                                </td>
                                </tr>
                                <tr> 
                                <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Admin Username:</font></td>
                                <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                                <input type=\"text\" name=\"formname\" size=\"50\">
                                </font></td>
                                </tr>
                                <tr> 
                                <td height=\"24\" colspan=\"2\"> 
                                <div align=\"center\">&nbsp; 
                                <input type=\"submit\" name=\"Submit\" value=\"Submit\">
                                <input type=\"reset\" name=\"Submit2\" value=\"Reset\">
                                <br>
                                <input type=\"hidden\" name=\"action\" value=\"lostpassword\">
                                <input type=\"hidden\" name=\"lp\" value=\"step1\">
                                <input type=\"hidden\" name=\"step\" value=\"send\">
                                </div>
                                </td>
                                </tr>
                                </table>
                                </form>
                                ");
                }
                if ($step == "send") {
                	$query="SELECT * FROM pabugs_admin WHERE admin_username = '$formname'";
                        $result=mysql_query($query);
                        $resdata = mysql_fetch_array($result);
                        $un = $resdata['admin_username'];
                        $pw = $resdata['admin_password'];
                        $email = $resdata['admin_email'];
                        $id = $resdata['admin_id'];
                        $status = $resdata['admin_status'];
                        $notify = $resdata['admin_notify'];
                        $un = trim($un);
                        if (empty($un)) {
                        	die ("<font face=\"Tahoma\" size=\"2\">There is not an admin with the username $formname");
                        }
                        $str = "$id$un$pw";
                        $str2 = "$email$status$notify";
                        $code1 = md5($str);
                        $code2 = md5($str2);
                        $code = "$code1$code2";
                        $ip = getenv ("REMOTE_ADDR");
                        $message .= "Someone with the IP address $ip has used the lost password link at the bug tracker, $trackername, to reset the password of the admin, $un.\n";
                        $message .= "If you did not use the lost password link, then simply ignore this email. If you would like to reset your password, either click or copy and paste into your browser the link below:\n\n";
                        $message .= "$pabugsurl/pabugsadmin/adminmain.php?action=lostpassword&lp=step2&step=form&admin=$id&code=$code";
                        $subject = "[paBugs] Forgot Password";
                        mail("$email", "$subject", "$message");
                        echo "<font face=\"Tahoma\" size=\"2\">An e-mail has been sent to $email with more instructions for resetting your password. It should arrive in your e-mail inbox soon.";
                }
        }
	if ($lp == "step2") {
		if ($step == "form") {
			$query="SELECT * FROM pabugs_admin WHERE admin_id = '$admin'";
                        $result=mysql_query($query);
                        $resdata = mysql_fetch_array($result);
                        $un = $resdata['admin_username'];
                        $pw = $resdata['admin_password'];
                        $email = $resdata['admin_email'];
                        $id = $resdata['admin_id'];
                        $status = $resdata['admin_status'];
                        $notify = $resdata['admin_notify'];
                        $str = "$id$un$pw";
                        $str2 = "$email$status$notify";
                        $code1 = md5($str);
                        $code2 = md5($str2);
                        $checkcode = "$code1$code2";
                        if ($code == $checkcode) {
                        	echo ("
	                        <form action=\"adminmain.$phpext\" name=\"form\" method=\"post\">
	                        <table width=\"70%\" border=\"1\" align=\"center\" cellspacing=\"0\">
                                <tr> 
                                <td colspan=\"2\"> 
                                <div align=\"center\"><font face=\"Tahoma\" size=\"4\"><font color=\"#000000\">Lost Password<br>
                                <font size=\"2\">&gt;&gt;Please enter a new password</font></font></font></div>
                                </td>
                                </tr>
                                <tr> 
                                <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Password:</font></td>
                                <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                                <input type=\"text\" name=\"formpass\" size=\"50\">
                                </font></td>
                                </tr>
                                <tr> 
                                <td height=\"24\" colspan=\"2\"> 
                                <div align=\"center\">&nbsp; 
                                <input type=\"submit\" name=\"Submit\" value=\"Submit\">
                                <input type=\"reset\" name=\"Submit2\" value=\"Reset\">
                                <br>
                                <input type=\"hidden\" name=\"action\" value=\"lostpassword\">
                                <input type=\"hidden\" name=\"admin\" value=\"$admin\">
                                <input type=\"hidden\" name=\"lp\" value=\"step2\">
                                <input type=\"hidden\" name=\"step\" value=\"change\">
                                <input type=\"hidden\" name=\"formcode\" value=\"$code\">
                                </div>
                                </td>
                                </tr>
                                </table>
                                </form>
                                ");
                        } else {
                        	die ("<font face=\"Tahoma\" size=\"2\">The confirmation code was incorrect. Please make sure you entered the URL into your browser exactly as it appeared in the e-mail");
                        }
               }
               if ($step == "change") {
               	        $query="SELECT * FROM pabugs_admin WHERE admin_id = '$admin'";
                        $result=mysql_query($query);
                        $resdata = mysql_fetch_array($result);
                        $un = $resdata['admin_username'];
                        $pw = $resdata['admin_password'];
                        $email = $resdata['admin_email'];
                        $id = $resdata['admin_id'];
                        $status = $resdata['admin_status'];
                        $notify = $resdata['admin_notify'];
                        $str = "$id$un$pw";
                        $str2 = "$email$status$notify";
                        $code1 = md5($str);
                        $code2 = md5($str2);
                        $checkcode = "$code1$code2";
                        if ($formcode == $checkcode) {
                        	$newcrypt = md5($formpass);
				$query = "UPDATE pabugs_admin SET admin_password = '$newcrypt' WHERE admin_id = '$admin'";
       	                        $result=mysql_query($query);
       	                        die("<font face=\"Tahoma\" size=\"2\">Your password has been changed. Please remember this password. You may go back and log in with your username and new password.");
                        } else {
                              die ("<font face=\"Tahoma\" size=\"2\">There was an error. Please repeat the Lost Password process.");   
                        }
                        
               	
               	}
	
		
	}
exit();
}



$query="SELECT * FROM pabugs_admin WHERE admin_username = '$pabugsuser'";
$result=mysql_query($query);
$resdata = mysql_fetch_array($result);
$realpass = $resdata['admin_password'];
$adminip = getenv ("REMOTE_ADDR");
$md5ip = md5($adminip);
if ($pabugspw == $realpass && !empty($pabugsuser) && $md5ip == $pabugsadminip) {
	if ($adminact == "cat") {
		if ($catact == "add") {
			if ($catadd == "add") {
			        $addsql = "INSERT INTO pabugs_category VALUES(NULL, '$catname', '$catdescription', '0', '$parent')";
                                $result = mysql_query($addsql);
                                echo "<p><font face=Tahoma size=2>The category has been added!";
                                exit();	
			}
			if ($catadd == "form") {
				function showcats() {
				echo("
				<select name=\"parent\">
                                <option value=\"0\" selected>None</option>");
                                $query="SELECT * FROM pabugs_category ORDER BY category_id";
                                $result=mysql_query($query);
                                $number=mysql_numrows($result);
                                $i = 0;
                                while ($i < $number){
                                $catid = mysql_result($result,$i,"category_id");
                                $catname = mysql_result($result,$i,"category_name");
                                $catparent = mysql_result($result,$i,"category_parent");
                                if ($catparent == 0) {
                                echo "<option value=\"$catid\">-$catname</option>";
                                }
                                $i++;
                                }
                                echo ("</select>");
                                }
				
				echo("
		                <form name=\"form1\" method=\"post\" action=\"adminmain.$phpext\">
		                <input type=\"hidden\" name=\"PHPSESSID\" value=\"$PHPSESSID\">
                                <table width=\"70%\" border=\"1\" align=\"center\" cellspacing=\"0\">
                                <tr> 
                                <td colspan=\"2\"> 
                                <div align=\"center\"><font face=\"Tahoma\" size=\"4\"><font color=\"#000000\">Add 
                                a Category<br>
                                <font size=\"2\">&gt;&gt;This form will allow you to add a category to 
                                the tracker</font></font></font></div>
                                </td>
                                </tr>
                                <tr> 
                                <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Category Name:</font></td>
                                <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                                <input type=\"text\" name=\"catname\" size=\"50\">
                                <br>
                                This is the name of the category you are adding.</font></td>
                                </tr>
                                <tr> 
                                <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Category Description:</font></td>
                                <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                                <input type=\"text\" name=\"catdescription\" size=\"50\">
                                <br>
                                This is a description of the category.</font></td>
                                </tr>
                                <tr> 
                                <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Parent Category:</font></td>
                                <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\">");
                                showcats();
                                echo("<br>
                                If this category will be a subcategory, select the category that it will be a subcategory of. If it isn't a subcategory, select \"None\".</font></td>
                                </tr>

                                <tr> 
                                <td height=\"24\" colspan=\"2\"> 
                                <div align=\"center\">&nbsp; 
                                <input type=\"submit\" name=\"Submit\" value=\"Submit\">
                                <input type=\"reset\" name=\"Submit2\" value=\"Reset\">
                                <br>
                                <input type=\"hidden\" name=\"adminact\" value=\"cat\">
                                <input type=\"hidden\" name=\"catact\" value=\"add\">
                                <input type=\"hidden\" name=\"catadd\" value=\"add\">
                                </div>
                                </td>
                                </tr>
                                </table>
                                </form>
		                ");	
			}
		}
		if ($catact == "edit") {
			if ($catedit == "edit") {
				$query = "UPDATE pabugs_category SET category_name = '$catname' WHERE category_id = '$catid'";
        			$result=mysql_query($query);
        			echo mysql_error();
        			$query = "UPDATE pabugs_category SET category_desc = '$catdescription' WHERE category_id = '$catid'";
        			$result=mysql_query($query);
        			$query = "UPDATE pabugs_category SET category_parent = '$parent' WHERE category_id = '$catid'";
        			$result=mysql_query($query);
        			echo mysql_error();
        			echo "<font face=Tahoma size=2>The category has been edited!";
			}
			if ($catedit == "form") {
				$query="SELECT * FROM pabugs_category WHERE category_id = '$id'";
           		        $result=mysql_query($query);
          		        $resdata = mysql_fetch_array($result);
       	 		        $edname = $resdata['category_name'];
       	 		        $eddesc = $resdata['category_desc'];
       	 		        $curparent = $resdata['category_parent'];
       	 		        function showcats($curparent) {
       	 		        echo("
				<select name=\"parent\">
                                <option value=\"0\">None</option>");
                                
                                $query="SELECT * FROM pabugs_category ORDER BY category_id";
                                $result=mysql_query($query);
                                $number=mysql_numrows($result);
                                $i = 0;
                                while ($i < $number){
                                $catid = mysql_result($result,$i,"category_id");
                                $catname = mysql_result($result,$i,"category_name");
                                $catparent = mysql_result($result,$i,"category_parent");
                                if ($catparent == 0) {
                                if ($curparent == $catid) {
                                	$sel = " selected";
                                } else {
                                	$sel = "";
                                }
                                echo "<option value=\"$catid\"$sel>-$catname</option>";
                                }
                                $i++;
                                }
                        
                                echo ("</select>");
       	 		        }
       	 		        
       	 		        echo("
       	  		        <form name=\"form1\" method=\"post\" action=\"adminmain.$phpext\">
       	  		        <input type=\"hidden\" name=\"PHPSESSID\" value=\"$PHPSESSID\">
                                <table width=\"70%\" border=\"1\" align=\"center\" cellspacing=\"0\">
                                <tr> 
                                <td colspan=\"2\"> 
                                <div align=\"center\"><font face=\"Tahoma\" size=\"4\"><font color=\"#000000\">Edit 
                                a Category<br>
                                <font size=\"2\">&gt;&gt;This form will allow you to edit a category in 
                                the tracker</font></font></font></div>
                                </td>
                                </tr>
                                <tr> 
                                <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Category Name:</font></td>
                                <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                                <input type=\"text\" name=\"catname\" size=\"50\" value=\"$edname\">
                                <br>
                                This is the name of the category you are editing.</font></td>
                                </tr>
                                <tr> 
                                <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Category Description:</font></td>
                                <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                                <input type=\"text\" name=\"catdescription\" size=\"50\" value=\"$eddesc\">
                                <br>
                                This is a description of the category.</font></td>
                                </tr>
                                <tr> 
                                <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Parent Category:</font></td>
                                <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\">");
                                showcats($curparent);
                                echo("<br>
                                If this category will be a subcategory, select the category that it will be a subcategory of. If it isn't a subcategory, select \"None\".</font></td>
                                </tr>
                                <tr> 
                                <td height=\"24\" colspan=\"2\"> 
                                <div align=\"center\">&nbsp; 
                                <input type=\"submit\" name=\"Submit\" value=\"Submit\">
                                <input type=\"reset\" name=\"Submit2\" value=\"Reset\">
                                <br>
                                <input type=\"hidden\" name=\"adminact\" value=\"cat\">
                                <input type=\"hidden\" name=\"catact\" value=\"edit\">
                                <input type=\"hidden\" name=\"catid\" value=\"$id\">
                                <input type=\"hidden\" name=\"catedit\" value=\"edit\">
                                </div>
                                </td>
                                </tr>
                                </table>
                                </form>
                        	");
			}
			if ($catedit == "list") {
				echo "<font face=Tahoma size=2>Select a category to edit:<p>";
        	                $query="SELECT * FROM pabugs_category ORDER BY category_id";
                        	$result=mysql_query($query);
                                $number=mysql_numrows($result);
                                if($number==0){echo "<font face=Tahoma size=2>There are no categories to edit"; exit();}
                                $i = 0;
                
                                while ($i < $number){
                                	$id = mysql_result($result,$i,"category_id");
                                	$name = mysql_result($result,$i,"category_name");
                                	$desc = mysql_result($result,$i,"category_desc");
                                	echo "<a href=\"adminmain.$phpext?adminact=cat&catact=edit&catedit=form&id=$id&PHPSESSID=$PHPSESSID\"><font face=Tahoma size=2>$name -- $desc</a><p>";
                                	$i++;
                                }
			}
		}
		if ($catact == "delete") {
			if ($catdelete == "delete") {
				$sqldel = "DELETE FROM pabugs_category WHERE category_id='$id'";
          		        mysql_query($sqldel);
           		        echo "<font face=Tahoma size=2>The category has been deleted!";
			}
			if ($catdelete == "conf") {
				$query="SELECT * FROM pabugs_category WHERE category_id = '$id'";
                                $result=mysql_query($query);
                                $resdata = mysql_fetch_array($result);
       	                        $tgname = $resdata['category_name'];
       	                        $tgdesc = $resdata['category_desc'];
       	                        echo "<font face=Tahoma size=2>You are about to delete the category: <b>$tgname -- $tgdesc</b>! Are you sure you want to do this?<br>";
       	                        echo "<font face=Tahoma size=2><a href=\"adminmain.$phpext?adminact=cat&catact=delete&catdelete=delete&id=$id&PHPSESSID=$PHPSESSID\">Yes</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=\"adminmain.$phpext?PHPSESSID=$PHPSESSID\">No</a>";	
			}
			if ($catdelete == "list") {
				echo "<font face=Tahoma size=2>Select a category to delete:<p>";
                        	$query="SELECT * FROM pabugs_category ORDER BY category_id";
                		$result=mysql_query($query);
                   	        $number=mysql_numrows($result);
                      	        if($number==0){echo "<font face=Tahoma size=2>There are no categories to delete"; exit();}
                   	        $i = 0;
        	
                   	        while ($i < $number){
                   	     	        $id = mysql_result($result,$i,"category_id");
                                        $name = mysql_result($result,$i,"category_name");
                                        $desc = mysql_result($result,$i,"category_desc");
                      	  	        echo "<a href=\"adminmain.$phpext?adminact=cat&catact=delete&catdelete=conf&id=$id&PHPSESSID=$PHPSESSID\"><font face=Tahoma size=2>$name -- $desc</a><p>";
                        		$i++;
                    	        }
			}
		}
		if ($catact == "recount") {
			if ($catrecount == "recount") {
				
				$Gore = 0;
				$Bush = 0;
        	                $florida="SELECT * FROM pabugs_bugs ORDER BY bug_id";
                                $result=mysql_query($florida);
                                $number=mysql_numrows($result);
                                $i = 0;
                                $democrat = $id;
                                while ($i < $number){
        	
                                $vote = mysql_result($result,$i,"bug_category");
                                $status = mysql_result($result,$i,"bug_status");
                                if ($status != 0){
                                	$nstat = 1;
                                } else {
                                	$nstat = 0;
                                }
                                	
                                if ($vote == $democrat && $status != 0) {
                                	$Gore++;
                                	
                                }
                                $Bush = $Bush + 0;
                                $i++;
                                }
                                $Winner = $Gore;
                                $query = "UPDATE pabugs_category SET category_bugs = '$Gore' WHERE category_id = '$id'";
        	                $result=mysql_query($query);
        	                echo "<font face=Tahoma size=2>paBugs found $Gore bugs in the category and updated the database";
        	                /*Well, we can't have everything, can we? Vote Democratic in 2004. If you don't live in the US, simply ignore this.*/
			}
			if ($catrecount == "list") {
				echo "<font face=Tahoma size=2>Use the recount feature if paBugs is not displaying the correct amount of bugs in a category. (For example, if paBugs says there are 5 bugs in category XX, but there are only 3, use this feature.) Select the category you want to recount below:<p>";
        	                $query="SELECT * FROM pabugs_category ORDER BY category_id";
                        	$result=mysql_query($query);
                                $number=mysql_numrows($result);
                                $votes = "categories";
                                if($number==0){echo "<font face=Tahoma size=2>There are no $votes to recount"; exit();}
                                $i = 0;

                                while ($i < $number){
                                	$id = mysql_result($result,$i,"category_id");
                                	$name = mysql_result($result,$i,"category_name");
                                	$desc = mysql_result($result,$i,"category_desc");
                                	$total = mysql_result($result,$i,"category_bugs");
                                	echo "<a href=\"adminmain.$phpext?adminact=cat&catact=recount&catrecount=recount&id=$id&state=florida&PHPSESSID=$PHPSESSID\"><font face=Tahoma size=2>$name -- $desc -- $total bugs</a><p>";
                                	$i++;
                                }
			}
		}
	}
	if ($adminact == "bug") {
		if ($bugact == "add") {
			if ($bugadd == "add") {
				$summary = trim($summary);
				if (empty($summary)) {
					die ("<font face=Tahoma size=2>You have left the Bug Summary field empty! Please go back and fill it in.");
				}
				$description = trim($description);
				if (empty($description)) {
					die ("<font face=Tahoma size=2>You have left the Bug Description field empty! Please go back and fill it in.");
				}
				$additional = trim($additional);
				if (empty($additional)) {
					$additional = "None";
				}
				$time = time();
                                $description = str_replace ("\n", "<br>", "$description");
                                $additional = str_replace ("\n", "<br>", "$additional");
                                $addsql = "INSERT INTO pabugs_bugs VALUES(NULL, '$catid', '$priority', '$time', '$time', '$status', '$pabugsuser', '$summary', '$description', '$additional')";
                                $result = mysql_query($addsql);
                                $query="SELECT * FROM pabugs_category WHERE category_id = '$catid'";
                                $result=mysql_query($query);
                                $resdata = mysql_fetch_array($result);
       	                        $tbugs = $resdata['category_bugs'];
       	                        $newb = $tbugs + 1;
       	                        $query = "UPDATE pabugs_category SET category_bugs = '$newb' WHERE category_id = '$catid'";
        	                $result=mysql_query($query);
                                echo "<p><font face=Tahoma size=2>The bug has been added!";
                                if ($m == 1) {
                                      	$query="SELECT * FROM pabugs_bugs WHERE bug_submitdate = '$time'";
                                        $result=mysql_query($query);
                                        $resdata2 = mysql_fetch_array($result);
       	                                $newid = $resdata2['bug_id'];
       	                                echo mysql_error();
                	                echo "<meta http-equiv=\"refresh\" content=\"1; url=pabugs.$phpext?PHPSESSID=$PHPSESSID&action=viewbug&bid=$newid&id=$catid\">";
                                }
				
			}
			if ($bugadd == "form") {
				function showcategories() {
                                echo ("<select name=\"catid\">");
                                $query="SELECT * FROM pabugs_category ORDER BY category_id";
                	        $result=mysql_query($query);
                                $number=mysql_numrows($result);
                                $i = 0;
                                while ($i < $number){
                        	        $cid = mysql_result($result,$i,"category_id");
                                	$cname = mysql_result($result,$i,"category_name");
                                	$cpar = mysql_result($result,$i,"category_parent");
                                	if ($cpar == 0) {
                                	echo "<option value=\"$cid\">$cname</option>";
                                	}
                                	$i++;
                                	$query="SELECT * FROM pabugs_category ORDER BY category_id";
                                	$res = mysql_query($query);
                                	$n2 = mysql_numrows($res);
                                	$n = 0;
                                	while ($n < $n2) {
                                		$subcid = mysql_result($res,$n,"category_id");
                                		$subname = mysql_result($res,$n,"category_name");
                                		$subpar = mysql_result($res,$n,"category_parent");
                                		if ($subpar == $cid) {
                                			echo "<option value=\"$subcid\">---$subname</option>";
                                		}
                                		$n++;
                                	}
                                }
                                echo("</select>");
                                }
			       echo ("
		               <form name=\"form1\" method=\"post\" action=\"adminmain.$phpext\">
		               <input type=\"hidden\" name=\"PHPSESSID\" value=\"$PHPSESSID\">
                               <table width=\"70%\" border=\"1\" align=\"center\" cellspacing=\"0\">
                               <tr> 
                               <td colspan=\"2\"> 
                               <div align=\"center\"><font face=\"Tahoma\" size=\"4\"><font color=\"#000000\">Add 
                               a Bug<br>
                               <font size=\"2\">&gt;&gt;This form will allow you to add a bug to the 
                               database</font></font></font></div>
                               </td>
                               </tr>
                               <tr> 
                               <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Bug Summary:</font></td>
                               <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                               <input type=\"text\" name=\"summary\" size=\"50\">
                               <br>
                               This is a short, one line summary of the bug you are adding (Example: \"[Feature] Causes [Error Message]\")</font> 
                               </td>
                               </tr>
                               <tr> 
                               <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Bug Description:</font></td>
                               <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                               <textarea name=\"description\" cols=\"70\" rows=\"5\"></textarea>
                               <br>
                               This is a detailed description of the bug you are adding, such as what the bug is, steps to reproduce the bug, and any other additional info.</font></td>
                               </tr>
                               <tr> 
                               <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Bug Priority:</font></td>
                               <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                               <select name=\"priority\">
                                <option value=\"1\">1</option>
                                <option value=\"2\">2</option>
                                <option value=\"3\">3</option>
                                <option value=\"4\">4</option>
                                <option value=\"5\">5</option>
                               </select>
                               <br>
                               This is the priority or importance of the bug with 1 being the lowest and 5 being the highest. (Example: Security holes are a 5, spelling errors are a 1)</font></td>
                               </tr>
                               <tr> 
                               <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Bug Status:</font></td>
                               <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                               <select name=\"status\">
                                <option value=\"0\">Not Approved</option>
                                <option value=\"1\" selected>Not Fixed</option>
                                <option value=\"2\">Currently Being Worked On</option>
                                <option value=\"3\">Fixed</option>
                               </select>
                               <br>
                               This is the current status of the bug. To make sure people know what the status is, change this whenever it changes (Not Approved will not show the bug in the database. Bugs reported by people are given this status and must be approved in the Approve Bugs section)</font></td>
                               </tr>
                               <tr> 
                               <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Additional Info:</font></td>
                               <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                               <textarea name=\"additional\" cols=\"70\" rows=\"5\"></textarea>
                               <br>
                               This is any additional info you may have about the bug (Example: URL to download bug fixes.)</font></td>
                               </tr>
                               <tr> 
                               <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Category:</font></td>
                               <td width=\"75%\"><font face=\"Tahoma\" size=\"1\">"); showcategories(); echo ("<br>
                               Choose a category to add the bug to.</font> 
                               </td>
                               <tr> 
                               <td height=\"24\" colspan=\"2\"> 
                               <div align=\"center\">&nbsp; 
                               <input type=\"submit\" name=\"Submit\" value=\"Submit\">
                               <input type=\"reset\" name=\"Submit2\" value=\"Reset\">
                               <br>
                               <input type=\"hidden\" name=\"bugact\" value=\"add\">
                               <input type=\"hidden\" name=\"bugadd\" value=\"add\">
                               <input type=\"hidden\" name=\"adminact\" value=\"bug\">");
                               if ($m == 1) {
                       	              echo "<input type=\"hidden\" name=\"m\" value=\"1\">";
          	               }
                               echo ("</div>
                               </td>
                               </tr>
                               </table>
                               </form>
		               ");
			}
		}
		if ($bugact == "edit") {
			if ($bugedit == "edit") {
				if (empty($summary)) {
					die ("<font face=Tahoma size=2>You have left the Bug Summary field empty! Please go back and fill it in.");
				}
				if (empty($description)) {
					die ("<font face=Tahoma size=2>You have left the Bug Description field empty! Please go back and fill it in.");
				}
				if (empty($additional)) {
					$additional = "None";
				}
				$time = time();
				$description  = str_replace ("\n", "<br>", "$description");
				$additional  = str_replace ("\n", "<br>", "$additional");
				$query="SELECT * FROM pabugs_bugs WHERE bug_id = '$id'";
                                $result=mysql_query($query);
                                $resdata = mysql_fetch_array($result);
       	                        $oldtime = $resdata['bug_submitdate'];
       	                        if ($oldtime == 0) {
       	                        	$query = "UPDATE pabugs_bugs SET bug_submitdate = '$time' WHERE bug_id = '$id'";
                                        $result=mysql_query($query);
                                }
                                $query = "UPDATE pabugs_bugs SET bug_category = '$catid' WHERE bug_id = '$id'";
                                $result=mysql_query($query);
                                $query = "UPDATE pabugs_bugs SET bug_priority = '$priority' WHERE bug_id = '$id'";
                                $result=mysql_query($query);
                                $query = "UPDATE pabugs_bugs SET bug_updatedate = '$time' WHERE bug_id = '$id'";
                                $result=mysql_query($query);
                                $query = "UPDATE pabugs_bugs SET bug_status = '$status' WHERE bug_id = '$id'";
                                $result=mysql_query($query);
                                $query = "UPDATE pabugs_bugs SET bug_summary = '$summary' WHERE bug_id = '$id'";
                                $result=mysql_query($query);
                                $query = "UPDATE pabugs_bugs SET bug_description = '$description' WHERE bug_id = '$id'";
                                $result=mysql_query($query);
                                $query = "UPDATE pabugs_bugs SET bug_additional = '$additional' WHERE bug_id = '$id'"; 
                                $result=mysql_query($query);
                                if ($oldstatus == 1 or $oldstatus == 2 or $oldstatus == 3) {
                                	$query="SELECT * FROM pabugs_category WHERE category_id = '$oldcat'";
                                        $result=mysql_query($query);
                                        $resdata = mysql_fetch_array($result);
       	                                $tbugs = $resdata['category_bugs'];
       	                                $newtbugs = $tbugs - 1;
       	                                $query = "UPDATE pabugs_category SET category_bugs = '$newtbugs' WHERE category_id = '$oldcat'"; 
                                        $result=mysql_query($query);
                                }
                                if ($status == 1 or $status == 2 or $status == 3) {
                                $query="SELECT * FROM pabugs_category WHERE category_id = '$catid'";
                                $result=mysql_query($query);
                                $resdata = mysql_fetch_array($result);
       	                        $tbugs = $resdata['category_bugs'];
       	                        $newtbugs = $tbugs + 1;
       	                        $query = "UPDATE pabugs_category SET category_bugs = '$newtbugs' WHERE category_id = '$catid'"; 
                                $result=mysql_query($query);
                                }
        	                echo "<font face=Tahoma size=2>The bug has been edited!";
        	                #echo "<meta http-equiv=\"refresh\" content=\"0; url=pafiledb.$phpext?action=viewfile&fid=$fileid&id=$catid&edit=done\">";	
				
			}
			if ($bugedit == "form") {
				$query="SELECT * FROM pabugs_bugs WHERE bug_id = '$id'";
                                $result=mysql_query($query);
                                $resdata = mysql_fetch_array($result);
       	                        $esummary = $resdata['bug_summary'];
       	                        $edescription = $resdata['bug_description'];
       	                        $epriority = $resdata['bug_priority'];
       	                        $estatus = $resdata['bug_status'];
       	                        $eadditional = $resdata['bug_additional'];
       	                        $ecategory = $resdata['bug_category'];
       	                        function eshowcats($ecategory) {               
                                /*echo ("<select name=\"catid\">");
                                $query="SELECT * FROM pabugs_category ORDER BY category_id";
                        	$result=mysql_query($query);
                                $number=mysql_numrows($result);
                                $i = 0;
                                while ($i < $number){
                                	$cid = mysql_result($result,$i,"category_id");
                                	$cname = mysql_result($result,$i,"category_name");
                                	if ($ecategory == "$cid") {
                        	        echo "<option value=\"$cid\" selected>$cname</option>";
                               } else {
                                	echo "<option value=\"$cid\">$cname</option>";
                                	}
                                	$i++;
                                }
                                echo("</select>");
                        }*/
                                echo ("<select name=\"catid\">");
                                $query="SELECT * FROM pabugs_category ORDER BY category_id";
                	        $result=mysql_query($query);
                                $number=mysql_numrows($result);
                                $i = 0;
                                while ($i < $number){
                        	        $cid = mysql_result($result,$i,"category_id");
                                	$cname = mysql_result($result,$i,"category_name");
                                	$cpar = mysql_result($result,$i,"category_parent");
                                	if ($cpar == 0) {
                                		if ($ecategory == $cid) {
                                			$sel = " selected";
                                		} else {
                                			$sel = "";
                                		}
                                	echo "<option value=\"$cid\"$sel>$cname</option>";
                                	}
                                	$i++;
                                	$query="SELECT * FROM pabugs_category ORDER BY category_id";
                                	$res = mysql_query($query);
                                	$n2 = mysql_numrows($res);
                                	$n = 0;
                                	while ($n < $n2) {
                                		$subcid = mysql_result($res,$n,"category_id");
                                		$subname = mysql_result($res,$n,"category_name");
                                		$subpar = mysql_result($res,$n,"category_parent");
                                		if ($subpar == $cid) {
                                			if ($ecategory == $subcid) {
                                			$sel = " selected";
                                		        } else {
                                			$sel = "";
                                		}
                                			echo "<option value=\"$subcid\"$sel>---$subname</option>";
                                		}
                                		$n++;
                                	}
                                }
                                echo("</select>");
                                }
                                function eshowstatus($estatus) {
                                	if ($estatus == 0) {
                                		echo ("<select name=\"status\">
                                                <option value=\"0\" selected>Not Approved</option>
                                                <option value=\"1\">Not Fixed</option>
                                                <option value=\"2\">Currently Being Worked On</option>
                                                <option value=\"3\">Fixed</option>
                                                </select>");
                                        }
                                        if ($estatus == 1) {
                                		echo ("<select name=\"status\">
                                                <option value=\"0\">Not Approved</option>
                                                <option value=\"1\" selected>Not Fixed</option>
                                                <option value=\"2\">Currently Being Worked On</option>
                                                <option value=\"3\">Fixed</option>
                                                </select>");
                                        }
                                        if ($estatus == 2) {
                                		echo ("<select name=\"status\">
                                                <option value=\"0\">Not Approved</option>
                                                <option value=\"1\">Not Fixed</option>
                                                <option value=\"2\" selected>Currently Being Worked On</option>
                                                <option value=\"3\">Fixed</option>
                                                </select>");
                                        }
                                        if ($estatus == 3) {
                                		echo ("<select name=\"status\">
                                                <option value=\"0\">Not Approved</option>
                                                <option value=\"1\">Not Fixed</option>
                                                <option value=\"2\">Currently Being Worked On</option>
                                                <option value=\"3\" selected>Fixed</option>
                                                </select>");
                                        }
                                }
                                function eshowpriority($epriority) {
                                	if ($epriority == 1) {
                                		echo ("<select name=\"priority\">
                                                <option value=\"1\" selected>1</option>
                                                <option value=\"2\">2</option>
                                                <option value=\"3\">3</option>
                                                <option value=\"4\">4</option>
                                                <option value=\"5\">5</option>
                                                </select>");
                                        }
                                        if ($epriority == 2) {
                                		echo ("<select name=\"priority\">
                                                <option value=\"1\">1</option>
                                                <option value=\"2\" selected>2</option>
                                                <option value=\"3\">3</option>
                                                <option value=\"4\">4</option>
                                                <option value=\"5\">5</option>
                                                </select>");
                                        }
                                        if ($epriority == 3) {
                                		echo ("<select name=\"priority\">
                                                <option value=\"1\">1</option>
                                                <option value=\"2\">2</option>
                                                <option value=\"3\" selected>3</option>
                                                <option value=\"4\">4</option>
                                                <option value=\"5\">5</option>
                                                </select>");
                                        }
                                        if ($epriority == 4) {
                                		echo ("<select name=\"priority\">
                                                <option value=\"1\">1</option>
                                                <option value=\"2\">2</option>
                                                <option value=\"3\">3</option>
                                                <option value=\"4\" selected>4</option>
                                                <option value=\"5\">5</option>
                                                </select>");
                                        }
                                        if ($epriority == 5) {
                                		echo ("<select name=\"priority\">
                                                <option value=\"1\">1</option>
                                                <option value=\"2\">2</option>
                                                <option value=\"3\">3</option>
                                                <option value=\"4\">4</option>
                                                <option value=\"5\" selected>5</option>
                                                </select>");
                                        }
                                        
                                }
                                $edescription  = str_replace ("<br>", "\n", "$edescription");
                                $eadditional  = str_replace ("<br>", "\n", "$eadditional");
       	                        echo ("
		               <form name=\"form1\" method=\"post\" action=\"adminmain.$phpext\">
		               <input type=\"hidden\" name=\"PHPSESSID\" value=\"$PHPSESSID\">
                               <table width=\"70%\" border=\"1\" align=\"center\" cellspacing=\"0\">
                               <tr> 
                               <td colspan=\"2\"> 
                               <div align=\"center\"><font face=\"Tahoma\" size=\"4\"><font color=\"#000000\">Edit 
                               a Bug<br>
                               <font size=\"2\">&gt;&gt;This form will allow you to edit a bug to the 
                               database</font></font></font></div>
                               </td>
                               </tr>
                               <tr> 
                               <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Bug Summary:</font></td>
                               <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                               <input type=\"text\" name=\"summary\" size=\"50\" value=\"$esummary\">
                               <br>
                               This is a short, one line summary of the bug you are adding (Example: \"[Feature] Causes [Error Message]\")</font> 
                               </td>
                               </tr>
                               <tr> 
                               <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Bug Description:</font></td>
                               <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                               <textarea name=\"description\" cols=\"70\" rows=\"5\">$edescription</textarea>
                               <br>
                               This is a detailed description of the bug you are adding, such as what the bug is, steps to reproduce the bug, and any other additional info.</font></td>
                               </tr>
                               <tr> 
                               <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Bug Priority:</font></td>
                               <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> "); eshowpriority($epriority); echo ("
                               <br>
                               This is the priority or importance of the bug with 1 being the lowest and 5 being the highest. (Example: Security holes are a 5, spelling errors are a 1)</font></td>
                               </tr>
                               <tr> 
                               <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Bug Status:</font></td>
                               <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\">"); eshowstatus($estatus); echo ("
                               <br>
                               This is the current status of the bug. To make sure people know what the status is, change this whenever it changes (Not Approved will not show the bug in the database. Bugs reported by people are given this status and must be approved in the Approve Bugs section)</font></td>
                               </tr>
                               <tr> 
                               <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Additional Info:</font></td>
                               <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                               <textarea name=\"additional\" cols=\"70\" rows=\"5\">$eadditional</textarea>
                               <br>
                               This is any additional info you may have about the bug (Example: URL to download bug fixes.)</font></td>
                               </tr>
                               <tr> 
                               <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Category:</font></td>
                               <td width=\"75%\"><font face=\"Tahoma\" size=\"1\">"); eshowcats($ecategory); echo ("<br>
                               Choose a category to add the bug to.</font> 
                               </td>
                               <tr> 
                               <td height=\"24\" colspan=\"2\"> 
                               <div align=\"center\">&nbsp; 
                               <input type=\"submit\" name=\"Submit\" value=\"Submit\">
                               <input type=\"reset\" name=\"Submit2\" value=\"Reset\">
                               <br>
                               <input type=\"hidden\" name=\"bugact\" value=\"edit\">
                               <input type=\"hidden\" name=\"id\" value=\"$id\">
                               <input type=\"hidden\" name=\"bugedit\" value=\"edit\">
                               <input type=\"hidden\" name=\"oldstatus\" value=\"$estatus\">
                               <input type=\"hidden\" name=\"oldcat\" value=\"$ecategory\">
                               <input type=\"hidden\" name=\"adminact\" value=\"bug\">");
                               echo ("</div>
                               </td>
                               </tr>
                               </table>
                               </form>
		               ");
			}
			if ($bugedit == "list") {
				echo "<font face=Tahoma size=2>You can select a bug to edit below<p>";
                        	$query="SELECT * FROM pabugs_bugs ORDER BY bug_id";
                		$result=mysql_query($query);
                   	        $number=mysql_numrows($result);
                      	        if($number==0){echo "<font face=Tahoma size=2>There are no bugs in the database."; exit();}
                   	        $i = 0;
        	                echo "<font face=Tahoma size=2>Select a bug to edit:<p>";
                   	        while ($i < $number){
                   	     	        $id = mysql_result($result,$i,"bug_id");
                                        $summary = mysql_result($result,$i,"bug_summary");
                                        $status = mysql_result($result,$i,"bug_status");
                      	  	        echo "<a href=\"adminmain.$phpext?adminact=bug&bugact=edit&bugedit=form&id=$id&PHPSESSID=$PHPSESSID\"><font face=Tahoma size=2>$summary</a><p>";
                      	  	        
                        		$i++;
                    	        }
                    	}
		}
		if ($bugact == "delete") {
			if ($bugdelete == "delete") {
				$query="SELECT * FROM pabugs_bugs WHERE bug_id = '$id'";
                                $result=mysql_query($query);
                                $resdata = mysql_fetch_array($result);
       	                        $bcid = $resdata['bug_category'];
       		                $sqldel = "DELETE FROM pabugs_bugs WHERE bug_id='$id'";
                                mysql_query($sqldel);
                                $query="SELECT * FROM pabugs_category WHERE category_id = '$bcid'";
                                $result=mysql_query($query);
                                $resdata = mysql_fetch_array($result);
       	                        $tbugs = $resdata['category_bugs'];
       	                        $newb = $tbugs - 1;
       	                        $query = "UPDATE pabugs_category SET category_bugs = '$newb' WHERE category_id = '$bcid'";
       	                        $result=mysql_query($query);
                                echo "<font face=Tahoma size=2>The bug has been deleted!";
                                #echo "<meta http-equiv=\"refresh\" content=\"0; url=pafiledb.$phpext\">";
				
			}
			if ($bugdelete == "conf") {
				$query="SELECT * FROM pabugs_bugs WHERE bug_id = '$id'";
                                $result=mysql_query($query);
                                $resdata = mysql_fetch_array($result);
       	                        $target = $resdata['bug_summary'];
       	                        echo "<font face=Tahoma size=2>You are about to delete the bug: <b>$target</b>! Are you sure you want to do this?<br>";
       	                        echo "<font face=Tahoma size=2><a href=\"adminmain.$phpext?adminact=bug&bugact=delete&bugdelete=delete&id=$id&PHPSESSID=$PHPSESSID\">Yes</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=\"pabugs.$phpext?PHPSESSID=$PHPSESSID\">No</a>";
			}
			if ($bugdelete == "list") {
				echo "<font face=Tahoma size=2>You can select a bug to delete below<p>";
                        	$query="SELECT * FROM pabugs_bugs ORDER BY bug_id";
                		$result=mysql_query($query);
                   	        $number=mysql_numrows($result);
                      	        if($number==0){echo "<font face=Tahoma size=2>There are no bugs in the database."; exit();}
                   	        $i = 0;
        	                echo "<font face=Tahoma size=2>Select a bug to delete:<p>";
                   	        while ($i < $number){
                   	     	        $id = mysql_result($result,$i,"bug_id");
                                        $summary = mysql_result($result,$i,"bug_summary");
                                        $status = mysql_result($result,$i,"bug_status");
                      	  	        echo "<a href=\"adminmain.$phpext?adminact=bug&bugact=delete&bugdelete=conf&id=$id&PHPSESSID=$PHPSESSID\"><font face=Tahoma size=2>$summary</a><p>";
                      	  	        
                        		$i++;
                    	        }
                    	}
                }
		if ($bugact == "approve") {
			echo "<font face=Tahoma size=2>Bugs that are reported by people are added to the database as unapproved bugs which means they won't be shown in the database until an admin approves it. Here is a list of unapproved bugs. After selecting a bug, you will be taken to a form where you can change the bug information and approve the bug.<p>";
                        	$query="SELECT * FROM pabugs_bugs ORDER BY bug_id";
                		$result=mysql_query($query);
                   	        $number=mysql_numrows($result);
                      	        if($number==0){echo "<font face=Tahoma size=2>There are no bugs in the database."; exit();}
                   	        $i = 0;
        	                $total = 0;
        	                echo "<font face=Tahoma size=2>Select a bug to approve:<p>";
                   	        while ($i < $number){
                   	     	        $id = mysql_result($result,$i,"bug_id");
                                        $summary = mysql_result($result,$i,"bug_summary");
                                        $status = mysql_result($result,$i,"bug_status");
                                        if ($status == 0) {
                                        $total++;
                      	  	        echo "<a href=\"adminmain.$phpext?adminact=bug&bugact=edit&bugedit=form&id=$id&PHPSESSID=$PHPSESSID\"><font face=Tahoma size=2>$summary</a><p>";
                      	  	        }
                        		$i++;
                    	        }
                    	        if ($total == 0) {echo "<font face=Tahoma size=2>There are no bugs in the database that need to be approved."; exit(); }
		}
	}
	$query="SELECT * FROM pabugs_admin WHERE admin_username = '$pabugsuser'";
        $result=mysql_query($query);
        $resdata = mysql_fetch_array($result);
        $superadmin = $resdata['admin_status'];
	if ($adminact == "users"  && $superadmin == 1) {
		if ($useract == "add") {
			if ($useradd == "add") {
				if (empty($username)) {
					die ("<font face=Tahoma size=2>You have left the Username field empty! Please go back and fill it in.");
				}
				if (empty($password)) {
					die ("<font face=Tahoma size=2>You have left the Password field empty! Please go back and fill it in.");
				}
				if (empty($email)) {
					die ("<font face=Tahoma size=2>You have left the E-mail Address field empty! Please go back and fill it in.");
				}
				$query="SELECT * FROM pabugs_admin ORDER BY admin_id";
                		$result=mysql_query($query);
                   	        $number=mysql_numrows($result);
                   	        $i = 0;
                   	        while ($i < $number){
                   	     	        $un = mysql_result($result,$i,"admin_username");
                                        if ($username == $un) {
                                        die("<font face=Tahoma size=2>There is already an admin with the username $username!");
                      	  	        }
                        		$i++;
                    	        }
                    	        $md5pass = md5($password);
                    	        $addsql = "INSERT INTO pabugs_admin VALUES(NULL, '$username', '$md5pass', '$email', '$status', '$notify')";
                                $result = mysql_query($addsql);
                                echo "<font face=\"Tahoma\" size=\"2\">The admin $username has been added!</font>";
			}
			if ($useradd == "form") {
				echo("
		                <form name=\"form1\" method=\"post\" action=\"adminmain.$phpext\">
		                <input type=\"hidden\" name=\"PHPSESSID\" value=\"$PHPSESSID\">
                                <table width=\"70%\" border=\"1\" align=\"center\" cellspacing=\"0\">
                                <tr> 
                                <td colspan=\"2\"> 
                                <div align=\"center\"><font face=\"Tahoma\" size=\"4\"><font color=\"#000000\">Add 
                                a Admin<br>
                                <font size=\"2\">&gt;&gt;This form will allow you to add an admin to 
                                the database. Admins can access this admin center to add bugs, approve bugs, ect.</font></font></font></div>
                                </td>
                                </tr>
                                <tr> 
                                <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Admin Username:</font></td>
                                <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                                <input type=\"text\" name=\"username\" size=\"50\">
                                <br>
                                This is the username of the admin you are adding.</font></td>
                                </tr>
                                <tr> 
                                <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Admin Password:</font></td>
                                <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                                <input type=\"text\" name=\"password\" size=\"50\">
                                <br>
                                This is the password that the admin you are adding will have to use to log in.</font></td>
                                </tr>
                                <tr> 
                                <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Admin E-Mail Address:</font></td>
                                <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                                <input type=\"text\" name=\"email\" size=\"50\">
                                <br>
                                This is the e-mail address of the admin you are adding.</font></td>
                                </tr>
                               <tr> 
                               <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Allow User Edit:</font></td>
                               <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                               <select name=\"status\">
                                <option value=\"0\">No</option>
                                <option value=\"1\" selected>Yes</option>
                               </select>
                               <br>
                               Choose if the admin you are adding will be allowed to add, edit, and delete other users.</font></td>
                               </tr>
                               <tr> 
                               <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">E-mail Notification:</font></td>
                               <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                               <select name=\"notify\">
                                <option value=\"0\">No</option>
                                <option value=\"1\" selected>Yes</option>
                               </select>
                               <br>
                               Choose if the admin will receive an e-mail notification when someone reports a bug. If you choose yes, make sure the e-mail address above is correct</font></td>
                               </tr>
                                <tr> 
                                <td height=\"24\" colspan=\"2\"> 
                                <div align=\"center\">&nbsp; 
                                <input type=\"submit\" name=\"Submit\" value=\"Submit\">
                                <input type=\"reset\" name=\"Submit2\" value=\"Reset\">
                                <br>
                                <input type=\"hidden\" name=\"adminact\" value=\"users\">
                                <input type=\"hidden\" name=\"useract\" value=\"add\">
                                <input type=\"hidden\" name=\"useradd\" value=\"add\">
                                </div>
                                </td>
                                </tr>
                                </table>
                                </form>
		                ");
			}
		}
		if ($useract == "edit") {
			if ($useredit == "options") {
				if ($useroptions == "change") {
					if (empty($username)) {
					die ("<font face=Tahoma size=2>You have left the Username field empty! Please go back and fill it in.");
				        }
				        if (empty($email)) {
					die ("<font face=Tahoma size=2>You have left the E-mail Address field empty! Please go back and fill it in.");
				        }
					$query = "UPDATE pabugs_admin SET admin_username = '$username' WHERE admin_id = '$id'";
       	                                $result=mysql_query($query);
       	                                $query = "UPDATE pabugs_admin SET admin_email = '$email' WHERE admin_id = '$id'";
       	                                $result=mysql_query($query);
       	                                $query = "UPDATE pabugs_admin SET admin_status = '$status' WHERE admin_id = '$id'";
       	                                $result=mysql_query($query);
       	                                $query = "UPDATE pabugs_admin SET admin_notify = '$notify' WHERE admin_id = '$id'";
       	                                $result=mysql_query($query);
       	                                echo "<font face=\"Tahoma\" size=\"2\">The admin has been edited!";
				}
				if ($useroptions == "form") {
					$query="SELECT * FROM pabugs_admin WHERE admin_id = '$id'";
           		                $result=mysql_query($query);
          		                $resdata = mysql_fetch_array($result);
       	 		                $euser = $resdata['admin_username'];
       	 		                $eemail = $resdata['admin_email'];
       	 		                $estatus = $resdata['admin_status'];
       	 		                $enotify = $resdata['admin_notify'];
       	 		                function eshowstatus($estatus) {
                                	if ($estatus == 0) {
                                		echo ("<select name=\"status\">
                                        <option value=\"0\" selected>No</option>
                                        <option value=\"1\">Yes</option>
                                        </select>");
                                        }
                                        if ($estatus == 1) {
                                		echo ("<select name=\"status\">
                                        <option value=\"0\">No</option>
                                        <option value=\"1\" selected>Yes</option>
                                        </select>");
                                        }
                                        } 
                                        function eshownotify($enotify) {
                                	if ($enotify == 0) {
                                		echo ("<select name=\"notify\">
                                        <option value=\"0\" selected>No</option>
                                        <option value=\"1\">Yes</option>
                                       </select>");
                                        }
                                        if ($enotify == 1) {
                                		echo ("<select name=\"notify\">
                                        <option value=\"0\">No</option>
                                        <option value=\"1\" selected>Yes</option>
                                        </select>");
                                        }
                                        }
					echo("
		                        <form name=\"form1\" method=\"post\" action=\"adminmain.$phpext\">
		                        <input type=\"hidden\" name=\"PHPSESSID\" value=\"$PHPSESSID\">
                                        <table width=\"70%\" border=\"1\" align=\"center\" cellspacing=\"0\">
                                        <tr> 
                                        <td colspan=\"2\"> 
                                        <div align=\"center\"><font face=\"Tahoma\" size=\"4\"><font color=\"#000000\">Edit 
                                        an Admin<br>
                                        <font size=\"2\">&gt;&gt;This form will allow you to edit an admin to.</font></font></font></div>
                                        </td>
                                        </tr>
                                        <tr> 
                                        <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Admin Username:</font></td>
                                        <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                                        <input type=\"text\" name=\"username\" size=\"50\" value=\"$euser\">
                                        <br>
                                        You can change the username of the admin or keep it the same.</font></td>
                                        </tr>
                                        <tr> 
                                        <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Admin E-Mail Address:</font></td>
                                        <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                                        <input type=\"text\" name=\"email\" size=\"50\" value=\"$eemail\">
                                        <br>
                                        This is the new e-mail address of the admin you are editing.</font></td>
                                        </tr>
                                       <tr> 
                                       <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Allow User Edit:</font></td>
                                       <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\">"); eshowstatus($estatus); echo("
                                       <br>
                                       Choose if the admin you are editing will be allowed to add, edit, and delete other users.</font></td>
                                       </tr>
                                       <tr> 
                                       <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">E-mail Notification:</font></td>
                                       <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\">"); eshownotify($enotify); echo("
                                       <br>
                                       Choose if the admin will receive an e-mail notification when someone reports a bug. If you choose yes, make sure the e-mail address above is correct</font></td>
                                       </tr>
                                        <tr> 
                                        <td height=\"24\" colspan=\"2\"> 
                                        <div align=\"center\">&nbsp; 
                                        <input type=\"submit\" name=\"Submit\" value=\"Submit\">
                                        <input type=\"reset\" name=\"Submit2\" value=\"Reset\">
                                        <br>
                                        <input type=\"hidden\" name=\"adminact\" value=\"users\">
                                        <input type=\"hidden\" name=\"id\" value=\"$id\">
                                        <input type=\"hidden\" name=\"useract\" value=\"edit\">
                                        <input type=\"hidden\" name=\"useroptions\" value=\"change\">
                                        <input type=\"hidden\" name=\"useredit\" value=\"options\">
                                        </div>
                                        </td>
                                        </tr>
                                        </table>
                                        </form>
		                ");
				}
			}
			if ($useredit == "password") {
				if ($userpassword == "change") {
					if (empty($password)) {
					die ("<font face=Tahoma size=2>You have left the Password field empty! Please go back and fill it in.");
				        }
				        $newcrypt = md5($password);
				        $query = "UPDATE pabugs_admin SET admin_password = '$newcrypt' WHERE admin_id = '$id'";
       	                                $result=mysql_query($query);
       	                                echo "<font face=\"Tahoma\" size=\"2\">The password has been changed!";
				}
				if ($userpassword == "form") {
					$query="SELECT * FROM pabugs_admin WHERE admin_id = '$id'";
	                                $result=mysql_query($query);
                                        $resdata = mysql_fetch_array($result);
       	                                $tguser = $resdata['admin_username'];
       	                                echo("
		                        <form name=\"form1\" method=\"post\" action=\"adminmain.$phpext\">
		                        <input type=\"hidden\" name=\"PHPSESSID\" value=\"$PHPSESSID\">
                                        <table width=\"70%\" border=\"1\" align=\"center\" cellspacing=\"0\">
                                        <tr> 
                                        <td colspan=\"2\"> 
                                        <div align=\"center\"><font face=\"Tahoma\" size=\"4\"><font color=\"#000000\">Change Admin Password<br>
                                        <font size=\"2\">&gt;&gt;This form will allow you to change the password of $tguser.</font></font></font></div>
                                        </td>
                                        </tr>
                                        <tr> 
                                        <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">New Password:</font></td>
                                        <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                                        <input type=\"text\" name=\"password\" size=\"50\">
                                        <br>
                                        This is the new password that the admin will have.</font></td>
                                        </tr>
                                        <tr> 
                                        <td height=\"24\" colspan=\"2\"> 
                                        <div align=\"center\">&nbsp; 
                                        <input type=\"submit\" name=\"Submit\" value=\"Submit\">
                                        <input type=\"reset\" name=\"Submit2\" value=\"Reset\">
                                        <br>
                                        <input type=\"hidden\" name=\"adminact\" value=\"users\">
                                        <input type=\"hidden\" name=\"id\" value=\"$id\">
                                        <input type=\"hidden\" name=\"useract\" value=\"edit\">
                                        <input type=\"hidden\" name=\"userpassword\" value=\"change\">
                                        <input type=\"hidden\" name=\"useredit\" value=\"password\">
                                        </div>
                                        </td>
                                        </tr>
                                        </table>
                                        </form>
		                        ");
				}
			}
			if ($useredit == "list") {
				echo "<font face=Tahoma size=2>Here is a list of admins that can be edited:<p>";
        	                $query="SELECT * FROM pabugs_admin ORDER BY admin_id";
                        	$result=mysql_query($query);
                                $number=mysql_numrows($result);
                                if($number==0){echo "<font face=Tahoma size=2>There are no admins to edit"; exit();}
                                $i = 0;

                                while ($i < $number){
                                	$id = mysql_result($result,$i,"admin_id");
                                	$username = mysql_result($result,$i,"admin_username");
                                	echo "<font face=Tahoma size=2>$username - <a href=\"adminmain.$phpext?adminact=users&useract=edit&useredit=options&useroptions=form&id=$id&PHPSESSID=$PHPSESSID\">Change Options</a> - <a href=\"adminmain.$phpext?adminact=users&useract=edit&useredit=password&userpassword=form&id=$id&PHPSESSID=$PHPSESSID\">Change Password</a> - <a href=\"adminmain.$phpext?adminact=users&useract=delete&userdelete=conf&id=$id&PHPSESSID=$PHPSESSID\">Delete</a><p>";
                                	$i++;
                                }
			}
		}
		if ($useract == "delete") {
			if ($userdelete == "delete") {
				$query="SELECT * FROM pabugs_admin WHERE admin_id = '$id'";
                                $result=mysql_query($query);
                                $resdata = mysql_fetch_array($result);
       	                        $tgname = $resdata['admin_username'];
				$sqldel = "DELETE FROM pabugs_admin WHERE admin_id='$id'";
                                mysql_query($sqldel);
                                echo "<font face=\"Tahoma\" size=\"2\">The admin <b>$tgname</b> has been deleted!";
			}
			if ($userdelete == "conf") {
				$query="SELECT * FROM pabugs_admin WHERE admin_id = '$id'";
                                $result=mysql_query($query);
                                $resdata = mysql_fetch_array($result);
       	                        $tgname = $resdata['admin_username'];
       	                        echo "<font face=Tahoma size=2>You are about to delete the admin: <b>$tgname</b>! Are you sure you want to do this?<br>";
       	                        echo "<font face=Tahoma size=2><a href=\"adminmain.$phpext?adminact=users&useract=delete&userdelete=delete&id=$id&PHPSESSID=$PHPSESSID\">Yes</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href=\"adminmain.$phpext?PHPSESSID=$PHPSESSID\">No</a>";	
			}
		}
	}
	if ($adminact == "info") {
		if ($infoact == "options") {
			if ($infooptions == "change") {
				$query = "UPDATE pabugs_admin SET admin_email = '$email' WHERE admin_username = '$pabugsuser'";
       	                        $result=mysql_query($query);
       	                        $query = "UPDATE pabugs_admin SET admin_notify = '$notify' WHERE admin_username = '$pabugsuser'";
       	                        $result=mysql_query($query);
       	                        echo "<font face=\"Tahoma\" size=\"2\">Your options have been changed!";
			}
			if ($infooptions == "form") {
				        $query="SELECT * FROM pabugs_admin WHERE admin_username = '$pabugsuser'";
           		                $result=mysql_query($query);
          		                $resdata = mysql_fetch_array($result);
       	 		                $euser = $resdata['admin_username'];
       	 		                $eemail = $resdata['admin_email'];
       	 		                $estatus = $resdata['admin_status'];
       	 		                $enotify = $resdata['admin_notify'];
                                        function eshownotify($enotify) {
                                	if ($enotify == 0) {
                                		echo ("<select name=\"notify\">
                                        <option value=\"0\" selected>No</option>
                                        <option value=\"1\">Yes</option>
                                       </select>");
                                        }
                                        if ($enotify == 1) {
                                		echo ("<select name=\"notify\">
                                        <option value=\"0\">No</option>
                                        <option value=\"1\" selected>Yes</option>
                                        </select>");
                                        }
                                        }
					echo("
		                        <form name=\"form1\" method=\"post\" action=\"adminmain.$phpext\">
		                        <input type=\"hidden\" name=\"PHPSESSID\" value=\"$PHPSESSID\">
                                        <table width=\"70%\" border=\"1\" align=\"center\" cellspacing=\"0\">
                                        <tr> 
                                        <td colspan=\"2\"> 
                                        <div align=\"center\"><font face=\"Tahoma\" size=\"4\"><font color=\"#000000\">Change Options<br>
                                        <font size=\"2\">&gt;&gt;This form will allow you to change your options.</font></font></font></div>
                                        </td>
                                        </tr>
                                        <tr> 
                                        <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">E-Mail Address:</font></td>
                                        <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                                        <input type=\"text\" name=\"email\" size=\"50\" value=\"$eemail\">
                                        <br>
                                        Enter your e-mail address in this field. Make sure it is correct.</font></td>
                                        </tr>
                                       <tr> 
                                       <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">E-mail Notification:</font></td>
                                       <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\">"); eshownotify($enotify); echo("
                                       <br>
                                       Choose if you want to receive an e-mail notification when someone reports a bug. If you choose yes, make sure the e-mail address above is correct</font></td>
                                       </tr>
                                        <tr> 
                                        <td height=\"24\" colspan=\"2\"> 
                                        <div align=\"center\">&nbsp; 
                                        <input type=\"submit\" name=\"Submit\" value=\"Submit\">
                                        <input type=\"reset\" name=\"Submit2\" value=\"Reset\">
                                        <br>
                                        <input type=\"hidden\" name=\"adminact\" value=\"info\">
                                        <input type=\"hidden\" name=\"id\" value=\"$id\">
                                        <input type=\"hidden\" name=\"infoact\" value=\"options\">
                                        <input type=\"hidden\" name=\"infooptions\" value=\"change\">
                                        </div>
                                        </td>
                                        </tr>
                                        </table>
                                        </form>");
			}
		}
		if ($infoact == "password") {
			if ($infopassword == "change") {
				if (empty($password)) {
				die ("<font face=Tahoma size=2>You have left the Password field empty! Please go back and fill it in.");
				}
				$newcrypt = md5($password);
				$query = "UPDATE pabugs_admin SET admin_password = '$newcrypt' WHERE admin_username = '$pabugsuser'";
       	                        $result=mysql_query($query);
       	                        echo "<font face=\"Tahoma\" size=\"2\">Your password has been changed!";
			}
			if ($infopassword == "form") {
       	                        echo("
 		                <form name=\"form1\" method=\"post\" action=\"adminmain.$phpext\">
 		                <input type=\"hidden\" name=\"PHPSESSID\" value=\"$PHPSESSID\">
                                <table width=\"70%\" border=\"1\" align=\"center\" cellspacing=\"0\">
                                <tr> 
                                <td colspan=\"2\"> 
                                <div align=\"center\"><font face=\"Tahoma\" size=\"4\"><font color=\"#000000\">Change Admin Password<br>
                                <font size=\"2\">&gt;&gt;This form will allow you to change your password.</font></font></font></div>
                                </td>
                                </tr>
                                <tr> 
                                <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">New Password:</font></td>
                                <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
                                <input type=\"text\" name=\"password\" size=\"50\">
                                <br>
                                This is the new password that you want.</font></td>
                                </tr>
                                <tr> 
                                <td height=\"24\" colspan=\"2\"> 
                                <div align=\"center\">&nbsp; 
                                <input type=\"submit\" name=\"Submit\" value=\"Submit\">
                                <input type=\"reset\" name=\"Submit2\" value=\"Reset\">
                                <br>
                                <input type=\"hidden\" name=\"adminact\" value=\"info\">
                                <input type=\"hidden\" name=\"id\" value=\"$id\">
                                <input type=\"hidden\" name=\"infoact\" value=\"password\">
                                <input type=\"hidden\" name=\"infopassword\" value=\"change\">
                                </div>
                                </td>
                                </tr>
                                </table>
                                </form>
		                ");
			}
		}
	}
	if ($adminact == "misc") {
		if ($miscact == "manual") {
			@virtual ("../manual.html") or die("<font face=\"Tahoma\" size=\"2\">paBugs is unable to display the manual. Did you upload manual.html to the paBugs directory?");
			
		}
		if ($miscact == "license") {
			@virtual ("../license.html") or die("<font face=\"Tahoma\" size=\"2\">paBugs is unable to display the license. Did you upload license.html to the paBugs directory?");
			
		}
	}
	$newadminact = trim($adminact);
	if (empty($newadminact)) {
		echo "<font face=\"Tahoma\" size=\"2\">Welcome to your paBugs admin center, $pabugsuser! You may use the links on the left to manage your bug tracker.<p>";
	}
	
}



else { //If the user isn't logged in, ask for the admin pass.

	if ($error == "yes") {
		$msg = "Your username and/or password was incorrect. Please re-enter your username and password below.";
	}
	if ($error !== "yes") {
		$msg = "This form will allow you to login to your paBugs Admin Center.";
	}
	echo ("
	<form action=\"adminmain.$phpext\" name=\"form\" method=\"post\">
	<table width=\"70%\" border=\"1\" align=\"center\" cellspacing=\"0\">
        <tr> 
        <td colspan=\"2\"> 
        <div align=\"center\"><font face=\"Tahoma\" size=\"4\"><font color=\"#000000\">Login<br>
        <font size=\"2\">&gt;&gt;$msg</font></font></font></div>
        </td>
        </tr>
        <tr> 
        <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Admin Username:</font></td>
        <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
        <input type=\"text\" name=\"formname\" size=\"50\">
        </font></td>
        </tr>
        <tr> 
        <td width=\"25%\"><font size=\"2\" face=\"Tahoma\">Password:</font></td>
        <td width=\"75%\"> <font face=\"Tahoma\" size=\"1\"> 
        <input type=\"password\" name=\"formpass\" size=\"50\">
        </font><br><font size=\"1\" face=\"Tahoma\"><a href=\"adminmain.php?action=lostpassword&lp=step1&step=form\">Forgot Password</a></font></td>
        </tr>
        <tr> 
        <td height=\"24\" colspan=\"2\"> 
        <div align=\"center\">&nbsp; 
        <input type=\"submit\" name=\"Submit\" value=\"Submit\">
        <input type=\"reset\" name=\"Submit2\" value=\"Reset\">
        <br>
        <input type=\"hidden\" name=\"action\" value=\"login\">
        </div>
        </td>
        </tr>
        </table>
        </form>
        ");
                                
} //End login

if ($showstats == 1) {
	$endtime = microtime();
        $endtime = explode(" ",$endtime);
        $endtime = $endtime[1] + $endtime[0];
        $stime = $endtime - $starttime;
        echo "\n<center><font face=\"Tahoma\" size=\"1\"> This page took '$stime' seconds to execute</center></font>\n";
}
?>