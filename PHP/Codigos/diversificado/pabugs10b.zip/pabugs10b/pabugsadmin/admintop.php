<?
session_save_path("../sessions");
session_start();
require "../pabugsext.ext";
?>
<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>admin top</title>
<style type="text/css">
SELECT, option, textarea, input {   FONT-FAMILY:tahoma;color:#000000; FONT-SIZE: 12px; background-color:#eeeeee  }
a:link,a:visited,a:active {text-decoration:none; color:#990000; font-weight:plain;}
a:hover {text-decoration:none; color:#660000; font-weight: plain;}
</style>
<base target="contents">
</head>
<body bgcolor="#eeeeee">


<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1" height="85">
  <tr>
    <td width="34%" align="left" rowspan="2" height="85">
    <img border="0" src="admincenter.gif"></td>
    <td width="66%" align="center" height="56">
    <p align="center"><font face="Tahoma" size="2">Welcome to your paBugs 
    Admin Center. This will allow you to manage your bug tracker.</font></td>
  </tr>
  <tr>
    <td width="66%" align="center" height="29"><font face="Tahoma" size="1">[<a target="yourtracker" href="../pabugs.<? echo $phpext; ?>?PHPSESSID=<? echo $PHPSESSID; ?>">Your 
    Bug Tracker</a>] - [<a target="supportforum" href="http://www.phparena.uni.cc/forum">paBugs 
    Support Forums</a>] - [<a target="pafiledbhome" href="http://www.phparena.uni.cc/pabugs/features.php">paBugs 
    Homepage</a>]</font></td>
  </tr>
</table>

</body>

</html>
