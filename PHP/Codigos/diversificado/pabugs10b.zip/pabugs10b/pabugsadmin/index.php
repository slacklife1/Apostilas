<?
session_save_path("../sessions");
session_start();
require "../pabugsext.ext";
$pabuser = trim($pabugsuser);
if (empty($pabuser)) {
	$action = "showloginform";
	require ("adminmain.$phpext");
}

?>
<html>

<head>
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>paBugs 1.0 Beta Admin Center</title>
<style type="text/css">
SELECT, option, textarea, input {   FONT-FAMILY:tahoma;color:#000000; FONT-SIZE: 12px; background-color:#eeeeee  }
a:link,a:visited,a:active {text-decoration:none; color:#990000; font-weight:plain;}
a:hover {text-decoration:none; color:#660000; font-weight: plain;}
</style>
</head>

<frameset rows="150,*" framespacing="0" border="0" frameborder="0">
  <frame name="top" scrolling="no" noresize target="contents" src="admintop.<? echo $phpext; ?>?PHPSESSID=<? echo $PHPSESSID; ?>">
  <frameset cols="150,*">
    <frame name="nav" target="main" scrolling="auto" src="adminnav.<? echo $phpext; ?>?PHPSESSID=<? echo $PHPSESSID; ?>" noresize>
    <frame name="main" scrolling="auto" src="adminmain.<? echo $phpext; ?>?PHPSESSID=<? echo $PHPSESSID; ?>">
  </frameset>
  <noframes>
  <body>

  <p>This page uses frames, but your browser doesn't support them.</p>

  </body>
  </noframes>
</frameset>

</html>