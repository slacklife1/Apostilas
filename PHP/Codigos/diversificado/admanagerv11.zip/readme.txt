sugarfree ad manager
by, heelflipboy
http://www.sugarfreenet.com - more DBZ, less cavities
http://www.sugarfreenet.com/scripts - scripts section

Version 1.1

note:
This will let you add ads to a random ad thing.  You just
put the URL to the ad and the image, and you can put in
more ads.  Its easy to do.

setup
-----------------
To set up the ad manager, upload all the files to a new directory you create, called ads or something like that.  Then upload all the files to that directory.  Change the variables in all the php files.  CHMOD ads.txt to 777, and go to the login.php3 page.  Type in your password, and start adding ads.  If you need to delete an add, open up the ads.txt file.  I will try to make a version that will let you delete ads without doing this.

changes
-----------------
1.1 - fixed HTML and some other things like that.
1.0 - created