<?PHP
Require "databases.inc";
Require "counter.inc";

$c = New mCounter;
echo $c->ShowAsImage();
?>
