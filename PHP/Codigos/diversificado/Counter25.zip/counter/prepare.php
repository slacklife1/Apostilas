<?PHP
 Require "lib/prepbutton.inc";
 Require "lib/colors.php";

 // It's additional code if you can prepare your own figures.
 // You can delete files 0.jpg ... 9.jpg and 0a.jpg
 // and change counter.jpg and figure.jpg to your own images.

 For ($i = 0; $i < 11; $i++) {
  $img = New mTextButton;
  $img->ImageType = "JPG";
  $img->FileName = "images/figure.jpg";
  $img->FontSize = 3;
  If ($i == 10) {
   $img->DestFile = "images/0a.jpg";
   $img->Text = "0";
   $img->TextColor = "lightgrey";
  } Else {
   $img->DestFile = "images/" . $i . ".jpg";
   $img->Text = $i;
   $img->TextColor = "white";
  }
  $img->OutputType = 2;
  $img->CreateButton();
 }
?>
