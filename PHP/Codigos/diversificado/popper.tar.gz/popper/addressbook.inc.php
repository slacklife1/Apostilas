	<tr class="window">
		<td width="35%" valign="top">
			<?php $this->show_addresses() ?>
		</td>

		<td>
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
			<tr>
				<td class="windowtitle">
					Address details
				</td>
			</tr>
			<tr>
				<td>
					<?php $this->show_address(); ?>
				</td>
			</tr>
		</table>
		</td>

	</tr>