<HTML>
<HEAD>
<TITLE>James' Homepage</TITLE>
<meta http-equiv="refresh" content="1;url=http://www.ractive.ch/gpl/popper.html"> 
</HEAD>
<BODY>
<center>
<h2>
If you were not redirected automatically, please follow <A HREF="http://www.ractive.ch/gpl/popper.html">this link</A>.<br>
<br>
You should everything you're looking for there.<br><br>
<a href="mailto:james@ractive.ch">james@ractive.ch</a>
</h2>
</center>
</BODY>
</HTML>
