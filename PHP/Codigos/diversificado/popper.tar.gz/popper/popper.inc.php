<?php
	$host = "localhost";
	$user = "username";
	$pass = "yourpassword";
	$dbname = "nameofthedatabase";
?>
