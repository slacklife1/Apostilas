<p style="text-align: right; font-size: smaller;">
<a href="http://www.ractive.ch/gpl/popper.html" style="color: #000000;">popper</a> 1.41 (C) by J.P. Bergamin
</p>
</body>
</html>
