<?
####################################
#             SquawkBox       
#           From NukedWeb     
#     http://www.nukedweb.com/
####################################
#
# Hey! If you like the way this script works, why not take it a step further? There's another script available
# called SquawkHost, that lets you run your own free blogger service. You can offer a service just like this one,
# to other webmasters. It can be configured to place a link on all bloggers back to your site. Check it out!
#     http://www.nukedweb.com/phpscripts/squawkhost.php


$boxurl = "http://www.nukedweb.com/phpscripts/"; // FULL URL where SquawkBox is installed. ALWAYS end with a trailing slash!
$refrsh_seconds = "10"; // Number of seconds between refreshes
$refrsh_times = "10"; // Number of times to refresh before stopping
$max_msgs_displayed = "0"; // Max messages to display. Use 0 to list all messages
$msgfile = "./msgs.txt"; // text file used to store messages
$mainmod = "squawk.php"; // filename of this file.
$adminpass = "mypass";


$headerfile = ""; // File to be included at the top of the script. e.g., $headerfile = "./top.php";
$footerfile = ""; // File to be included at the bottom of the script. e.g., $footerfile = "./bottom.php";
$bgcolor = "#507ca0";
$textcolor = "#FFFFFF";
$linkcolor = "#FFFFFF";
$alinkcolor = "#DDDDDD";
$vlinkcolor = "#FFFFFF";
$fontname = "Verdana, Arial, Helvetica, sans-serif";
$fontsize = "-3";
$text_box_width = "10"; //width of the text boxes on the Post page. Adjust these so you dont get the horizontal scrollbar.

if ($setcookie){
	if ($setcookie!=$adminpass){
		print "The password you used is not the same as the one set in the configuration. Remember the password is case-sensitive.";
		exit;
	}
	setcookie("ckSquawkPass", $setcookie, time()+313560000);
	print "The Password cookie has been set. Go back to your page, and you should see an X next to each post. Click it to delete that post. :)";
	exit;
}

if (($delete=="1") && ($ckSquawkPass) && ($ckSquawkPass==$adminpass)){
	$realname = urldecode($realname);
	$email = urldecode($email);
	$message = urldecode($message);
	$allmsgs = join("", file("./$msgfile"));
	$allmsgs = str_replace($realname."|".$email."|".$message."\r\n", "", $allmsgs);
	$allmsgs = str_replace($realname."|".$email."|".$message."\n", "", $allmsgs);
	$msgptr = fopen($msgfile,"w");
	$allmsgs = str_replace("\r", "", $allmsgs);
	$filaction = fwrite($msgptr, $allmsgs);
	$filclse = fclose($msgptr);
	$realname="";
	$email="";
	$message="";
}

if ($message){
	#$dump = str_replace(" ", "", $message);
	#$dump = str_replace("-", "", $dump);
	#$dump = str_replace(chr(160), "", $dump);
	#if (!$dump) $post="1";
	#$dump = str_replace(" ", "", $realname);
	#$dump = str_replace("-", "", $dump);
	#$dump = str_replace(chr(160), "", $dump);
	#if (!$dump) $realname="Guest";
	#$dump = str_replace(" ", "", $email);
	#$dump = str_replace("-", "", $dump);
	#$dump = str_replace(chr(160), "", $dump);
	#if (!$dump) $post="1";
	if ($post!="1"){
		$realname = str_replace("|", "", $realname);
		$email = str_replace("|", "", $email);
		$message = str_replace("|", "", $message);
		$realname = str_replace("\n", "", $realname);
		$email = str_replace("\n", "", $email);
		$message = str_replace("\n", "", $message);
		$realname = str_replace("\r", "", $realname);
		$email = str_replace("\r", "", $email);
		$message = str_replace("\r", "", $message);
		$realname = strip_tags($realname);
		$message = strip_tags($message);
		$message = wraptext($message);
		$allmsgs = join("", file("./$msgfile"));
		$allmsgs = $realname."|".$email."|".$message."\n".$allmsgs;
		$msgptr = fopen($msgfile,"w");
		$allmsgs = str_replace("\r", "", $allmsgs);
		$filaction = fwrite($msgptr, $allmsgs);
		$filclse = fclose($msgptr);
	}
}

if ($post=="1"){
	print "<html><head><title></title>$refreshtag</head><body bgcolor='$bgcolor' text='$textcolor' link='$linkcolor' alink='$alinkcolor' vlink='$vlinkcolor'>";
	print "<form name='postmsg' method='post' action='".$boxurl.$mainmod."'>
	  <font face='$fontname' size='$fontsize' color='$textcolor'>&nbsp;&nbsp;[<a href=\"javascript:history.go('-1');\">Go Back</a>]</font><br>
	  <font face='$fontname' size='$fontsize' color='$textcolor'>&nbsp;&nbsp;Name:<br>
	  &nbsp;&nbsp;<input type='text' name='realname' size='$text_box_width'>
	  <br>
	  &nbsp;&nbsp;Email:<br>
	  &nbsp;&nbsp;<input type='text' name='email' size='$text_box_width'>
	  <br>
	  &nbsp;&nbsp;Message:<br>
	  &nbsp;&nbsp;<textarea name='message' wrap='VIRTUAL' cols='$text_box_width'></textarea><br>&nbsp;&nbsp;<input type='submit' value='Post!'>
	  </font>
	  <br><font face='$fontname' size='$fontsize' color='$textcolor'>&nbsp;&nbsp;[<a href='http://www.nukedweb.com/phpscripts/' target='_nukedweb'>SquawkBox</a>] 
	</form>";
	exit;
}



if ($refrsh_times > 0){
	if ($refrsh_times==$refresh) $refreshtag = "";
	if ($refrsh_times!=$refresh) {
		$refresh++;
		srand(make_rndm_seed());
		$randtag = rand(1,99999);
		$refreshtag = "<meta http-equiv='refresh' content='$refrsh_times;URL=".$boxurl.$mainmod."?refresh=$refresh&tag=$randtag'>";
	}
}

if ($refrsh_times=="0" || $refrsh_times==""){
	srand(make_rndm_seed());
	$randtag = rand(1,99999);
	$refreshtag = "<meta http-equiv='refresh' content='$refrsh_times;URL=".$boxurl.$mainmod."?tag=$randtag'>";
}
	

print "<html><head><title></title>$refreshtag</head><body bgcolor='$bgcolor' text='$textcolor' link='$linkcolor' alink='$alinkcolor' vlink='$vlinkcolor'>";
if ($headerfile) include $headerfile;
print "<font face='$fontname' size='$fontsize' color='$textcolor'>[<a href='".$boxurl.$mainmod."?post=1'>Post</a>] ";
if (!$refreshtag) print "[<a href='$mainmod'>Refresh</a>]";
print "</font><hr>";
$msgsarray = file("./$msgfile");
$msgcnt = count($msgsarray);
for ($x=0;$x<$msgcnt;$x++){
	$lyn = $msgsarray[$x];
	#print $lyn;
	$armsg = explode("|", $lyn);
	$realname = $armsg[0];
	$email = $armsg[1];
	$onemsg = $armsg[2];
	$onemsg = str_replace("\n", "", $onemsg);
	$onemsg = str_replace("\r", "", $onemsg);
	if (!$realname) $realname = "Guest";
	if (!$email) $whotag = $realname;
	if ($email) $whotag = "<a href='mailto:$email'>$realname</a>";
	if (($ckSquawkPass) && ($ckSquawkPass==$adminpass)) $adminurl = "[<a href='".$mainmod."?delete=1&realname=".urlencode($realname)."&email=".urlencode($email)."&message=".urlencode($onemsg)."'>X</a>] ";
	print "<font face='$fontname' size='$fontsize' color='$textcolor'>".$adminurl.$whotag." - $onemsg</font><hr>";
	if ($max_msgs_displayed > 0){
		$chkmaxcnt = $max_msgs_displayed - 1;
		if ($x==$chkmaxcnt) $x = $msgcnt;
	}
}

print "<font face='$fontname' size='$fontsize' color='$textcolor'>[<a href='http://www.nukedweb.com/phpscripts/' target='_nukedweb'>SquawkBox</a>]";
if ($footerfile) include $footerfile;
print "</body></html>";



function make_rndm_seed() {
    list($usec, $sec) = explode(' ', microtime());
    return (float) $sec + ((float) $usec * 100000);
}
function wraptext($text){
	$text = str_replace("&nbsp;", " ", $text);
	$text = str_replace(chr(160), " ", $text);
	$text = explode(" ", $text);
	$cnt = count($text);
	for($x=0;$x<$cnt;$x++){
		$oneword = $text[$x];
		if (strlen($oneword)>20){
			for($z=0;$z<strlen($oneword);$z++){
				$z = $z + 20;
				$oneword = substr($oneword, 0, $z) . " " . substr($oneword, $z, strlen($oneword));
			}
		}
		$sentence .= $oneword." ";
	}
	return substr($sentence, 0, strlen($sentence) - 1);
}
?>