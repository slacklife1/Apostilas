TLD CHECK README FILE


		OVERVIEW
There are 6 files included in this package.
1. License.txt - Contains copyright and license information to outline proper use of this software.
2. Readme.txt - Contains an overview of the software package, installation tips, and the history of the TLD Check script.
3. tld_check.php - The core script of this software package.
3. tld_check_form.php - The form printed on the bottom of tld_check.php.
5. header.inc - The code that should be displayed before Weather Port's content.
6. footer.inc - The code that should be displayed after Weather Port's content.


		INSTALLATION
1. Copy all files to a directory within your web hosting account.
2. Set the variables in "tld_check.php" to the proper colors for your web site.
3. Edit your header and footer files to match your web site.


For help with this script, please consult the WebWorkz Ware Support section at:
http://www.webworkzware.com/index.php/page/support


		HISTORY
3/17/01:	v1.0 released.