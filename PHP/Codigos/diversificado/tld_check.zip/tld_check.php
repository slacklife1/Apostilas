<?
include ("header.inc");
/* Please set the following variables to match your web site */

// Background color of the top row of entry table
$topbackground = "#FF9900";

// Selected font color for top row of entry table
$topfontcolor = "#FFFFFF";

// Background color of the bottom row of entry table
$bottombackground = "#FFFFFF";

// Selected font color for bottom row of entry table
$bottomfontcolor = "#000000";

// Border color of your entry table
$border = "#000000";


function whois ($a_server, $a_query, $a_port=43)
{
$available = "No match";
$a_query = str_replace("www.", "", $a_query);
$a_query = str_replace("http://", "", $a_query);

$sock = fsockopen($a_server,$a_port);

IF (!$sock)
{
echo ("<b>Could Not Connect To Server.</b>");
}

fputs($sock,"$a_query\r\n");

while(!feof($sock))
$result .= fgets($sock,128);

fclose($sock);

IF (eregi($available,$result))
{
echo ("<font color=\"blue\"><b>$a_query is available.</b></font>");
}

ELSE
{
echo ("<font color=\"red\"><b>$a_query is not available.</b></font>");
}

}




IF ($query != "")
{

IF (!eregi(".com",$query) AND !eregi(".net",$query) AND !eregi(".org",$query))
{
echo ("<b>You must specify a .com, .net, or .org domain name.</b>");
}

ELSE
{
$server = "whois.networksolutions.com";
whois($server,$query);
}

}

ELSE IF (isset($query))
{
echo ("<b>Domain name left blank. Please fill in a domain name and try again.</b>");
}

?>

<br><br>

<?
include ("tld_check_form.inc");
include ("footer.inc");
?>
