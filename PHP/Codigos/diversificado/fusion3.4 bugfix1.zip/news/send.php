<?php
/******************
fusion
by the fusion team

fusionphp.com
******************/
$dfile = "news.db"; // full path to news.db
$config = "config.php"; // your config file
$head = <<< html
<!HTML here>
html;
$foot = <<< html
<!HTML here>
html;

// dont edit this ----------------
require $config;
echo $head;
if($mid == ""){
$file = file($dfile);
while(list(,$value) = each($file)){
list($newsm1,$fullnewsm,$userm,$subm,$emailm,$iconm,$datem,$rand) = explode("|<|", $value);
if($rand == $id){
echo <<< html
send the article <b><i>"$subm"</i></b> to a friend.
<table border="0" width="375"><td>
<form action="?mid=send&id=$id" method="post">
<fieldset>
<legend>Your info</legend>
your name: <input type="text" name="n"><br>
your email: <input type="text" name="e"><br>
your message:<br>
<textarea name="m" rows="5" cols="30">
</textarea>
</fieldset>
<br>
<fieldset>
<legend>Friends info</legend>
friends name: <input type="text" name="fn"><br>
friends email: <input type="text" name="fe"><br>
</fieldset>
<br>
<fieldset>
<legend>send it or reset it</legend>
<input type="submit" value="submit">
<input type="reset" value="reset">
<br><br>
</fieldset>
</form>
<br><br>
html;
}
}
}
if($mid == "send"){
$msg1 = "hi $fn,\ncheck out this news post: $furl/news.txt?id=$id\n\n$m\n\nfrom $n";
mail("$fe","hi,$fn check out this post!","$msg1","From: $e");
echo "the article has been sent to $fe, from $n. Go back <a href=\"$site\">$site</a> ";
}
echo $foot;
?>
