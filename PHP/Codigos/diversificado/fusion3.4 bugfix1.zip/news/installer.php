<?php

/******************
fusion news
by the fusion team

version 3.4

fusionphp.com
******************/

//variables (change these)

$config = "config.php"; //your config file
$users = "users.php"; //your users file

//stop (theres no more editing)

include $config;

//start
if($id == ""){
if($first == "yes"){
$title = "fusion install";
$content = <<< html
most information should be right. please review it.<br>
<br>
<table width=500 cellspacing=0 cellpadding=0 border=0>
<tr>
<td width=200 valign="top">
<form action="?id=go" method="post">
url to your site:
</td>
<td width=300 valign="top">
<input type="text" name="site1" value="http://$SERVER_NAME" size=31>
</td>
</tr>
<tr>
<td width=200 valign="top">
url to the fusion directory:
</td>
<td width=300 valign="top">
<input type="text" name="furl1" value="http://$SERVER_NAME/news" size=31>
</td>
</tr>
<tr>
<td width=200 valign="top">
url to the full news file:
</td>
<td width=300 valign="top">
<input type="text" name="fullnews" value="http://$SERVER_NAME/news/news.php" size=31>
</td>
</tr>
<tr>
<td width=200 valign="top">
url to the send to a friend file:
</td>
<td width=300 valign="top">
<input type="text" name="send" value="http://$SERVER_NAME/news/send.php" size=31>
</td>
</tr>
<tr>
<td width=200 valign="top">
allow bbcode?
</td>
<td width=300 valign="top">
<input type="radio" name="bbc" value="y" checked> yes<br>
<input type="radio" name="bbc" value="n"> no
</td>
</tr>

<tr>
<td width=200 valign="top">
allow html?
</td>
<td width=300 valign="top">
<input type="radio" name="html" value="y" checked> yes<br>
<input type="radio" name="html" value="n"> no
</td>
</tr>
<tr>
<td width=200 valign="top">
use smilies
</td>
<td width=300 valign="top">
<input type="radio" name="sm" value="y" checked> yes<br>
<input type="radio" name="sm" value="n"> no
</td>
</tr>
<tr>
<td width=500 valign="top">
<b>admin info</b><br>
<br>
</td>
</tr>
<tr>
<td width=200 valign="top">
username:
</td>
<td width=300 valign="top">
<input type="text" name="username">
</td>
</tr>
<tr>
<td width=200 valign="top">
pass:
</td>
<td width=300 valign="top">
<input type="text" name="password">
</td>
</tr>
<tr>
<td width=200 valign="top">
email:
</td>
<td width=300 valign="top">
<input type="text" name="email">
</td>
</tr>
<tr>
<td width=200 valign="top">
icon url:
</td>
<td width=300 valign="top">
<input type="text" name="icon">
</td>
</tr>
<tr>
<td width=300 valign="top">
<input type="submit" value="save"></form>
</td>
</tr>
</table>
<br>
html;
}
}
else{
$title = "already installed";
$content = "already installed";
}

//go
if($id == "go"){
if($bbc == "y"){
$bbca = 1;
}
else{
$bbca = 0;
}
if($html == "y"){
$h = 1;
}
else{
$h = 0;
}
if($sm == "y"){
$sm = 1;
}
else{
$sm = 0;
}

$p1 = $SCRIPT_FILENAME;
$p2 = str_replace("/installer.php", "", $p1);

//what to write
$save = "<?php
\$site = \"$site1\";
\$furl = \"$furl1\";
\$hurl = \"$site1\";
\$fullnewsurl = \"$fullnews\";
\$newsfile = \"$p2/news.txt\";
\$headlines = \"$p2/headlines.txt\";
\$fnewsfile = \"$p2/news.php\";
\$dfile = \"$p2/news.db\";
\$arc = \"$p2/archive.db\";
\$fnewsfile = \"$p2/news.php\";
\$datefor = \"m/d/y\";
\$numofposts = 11;
\$numofh = 5;
\$bb = $bbca;
\$ht = $h;
\$first = \"no\";
\$header = \"\";
\$footer = \"\";
\$arctemp = \"\";
\$arcftemp = \"\";
\$headercom = \"\";
\$footercom = \"\";
\$skin = \"basic\";
\$temp = \"<b>{subject}</b> posted by {user} on {date}<br>
{news}<br>
{send}<br>
<br>\";
\$ftemp = \"<b>{subject}</b> posted by {user} on {date}<br>
{news}<br>
{send}<br>\";
\$smilies = $sm;
\$sflink = \"$send\";
\$sf = \"send to a friend\";
\$fs = \"<b>full story</b>\";
?>";

$configfile = fopen($config,w);
fputs($configfile,$save);
fclose($configfile);

//what to write
$fp=fopen($users,a);
fwrite($fp,"$username|$email|$icon|$password|3|\n");
fclose($fp);

$title = "setup complete";
$content = "setup complete. <a href=\"\">go back</a>.";
}

?>
<html>
<title>fusion news</title>
<style>
<!--
body, td { color: black; font: 8pt verdana; font-weight: none; text-decoration: none }
input, textarea, select { color:black; font: 8pt verdana; font-weight: none; text-decoration: none; background: white; border: 1 solid black; }
-->
</style>
<body bgcolor="white" text="black" link="00a8ff" vlink="00a8ff" alink="00a8ff">
<center>
<table width="571" border="0" cellspacing="1" cellpadding="2" bgcolor="bbbbbb">
<tr> <td bgcolor="white" colspan="2">Fusion news</td></tr>
</table><br>
<table width="571" border="0" cellspacing="1" cellpadding="2" bgcolor="bbbbbb"><tr>
<td bgcolor="00a8ff" colspan="2"><font color="white"><?echo $title;?></font></td>
</tr><tr>
<td bgcolor="white" colspan="2">
<?echo $content;?>
</td></tr>
</table>
<br>
powered by <a href="http://www.fusionphp.com">fusion news</a>
</center>
</body>
</html>
