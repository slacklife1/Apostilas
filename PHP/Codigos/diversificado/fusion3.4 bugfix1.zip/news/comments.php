<?php
/******************
fusion comments system
by the fusion team
version beta 1.0
fusionphp.com
******************/
$config = "config.php"; // your config file
require $config;

echo $headercom;
if($mid == ""){
  if(!$id){
  echo "error";
  }else{
echo <<< html
<form action="?mid=post&num=$id" method="post">
your name: <input type="text" name="name"><br>
your email: <input type="text" name="email"><br>
comments:<br>
<textarea name="co" cols=45 rows=11></textarea><br>
<input type="submit" value="submit">
</form>
html;
  }
}
if($mid == "post"){
  if(!$name or !$email or !$co){
    $title = "field left blank";
  }else{
    $name = ereg_replace("\\\'", "'", $name);
    $name = ereg_replace('\\\"', '"', $name);
    $co = ereg_replace("\\\'", "'", $co);
    $co = ereg_replace('\\\"', '"', $co);
    $fp = fopen("comments.db",r);
    $cont = fgets($fp, filesize("comments.db"));
    fclose($fp);
    $fp = fopen("comments.db",a);
    fputs($fp, "<?php\nif(\$id == \"$num\"){\n?>$co - By <a href=\"mailto:$email\">$name</a><br><br>\n<?php\n}?>");
    fclose($fp);
  }

  if($comformpop == "checked"){
    echo "Your comment has been posted.<br>You may close this window.";
  }else{
echo <<< HTML
<META HTTP-EQUIV=Refresh CONTENT="1; URL=$site">
HTML;
  }
}
?>

<?php
{
if($mid == "view"){
  include "comments.db";
}
echo $footercom;
}
?>
