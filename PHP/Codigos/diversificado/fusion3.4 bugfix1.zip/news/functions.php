<?php

/******************
fusion news management
by the fusion team

version 3.4

fusionphp.com
TODO: comments archiving, monthly archiving, searching
******************/
function InsertBBCode($fusnewsm){
$fusnewsm = eregi_replace("\\[color=([^\\[]*)\\]([^\\[]*)\\[/color\\]","<font color=\"\\1\">\\2</font>",$fusnewsm);
$fusnewsm = eregi_replace("\\[size=([^\\[]*)\\]([^\\[]*)\\[/size\\]","<font size=\"\\1\">\\2</font>",$fusnewsm);
$fusnewsm = eregi_replace("\\[font=([^\\[]*)\\]([^\\[]*)\\[/font\\]","<font face=\"\\1\">\\2</font>",$fusnewsm);
$fusnewsm = eregi_replace("\\[img height=([^\\[]*)\\ width=([^\\[]*)\\]([^\\[]*)\\[/img\\]","<img src=\"\\3\" height=\"\\1\" width=\"\\2\">",$fusnewsm);
$fusnewsm = eregi_replace("\\[img width=([^\\[]*)\\ height=([^\\[]*)\\]([^\\[]*)\\[/img\\]","<img src=\"\\3\" width=\"\\1\" height=\"\\2\">",$fusnewsm);
$fusnewsm = eregi_replace("\\[img]([^\\[]*)\\[/img\\]","<img src=\"\\1\">",$fusnewsm);
$fusnewsm = eregi_replace("\\[flash=([^\\[]*)\\,([^\\[]*)\\]([^\\[]*)\\[/flash\\]","<object classid=\"clsid: D27CDB6E-AE6D-11cf-96B8-444553540000\" width=\\1 height=\\2><param name=movie value=\\3><param name=play value=true><param name=loop value=true><param name=quality value=high><embed src=\\3 width=\\1 height=\\2 play=true loop=true quality=high></embed></object>",$fusnewsm);
$fusnewsm = eregi_replace("\\[align=([^\\[]*)\\]([^\\[]*)\\[/align\\]","<p align=\"\\1\">\\2</p>",$fusnewsm);
$fusnewsm = eregi_replace("\\[shadow=([^\\[]*)\\,([^\\[]*)\\,([^\\[]*)\\]([^\\[]*)\\[/shadow\\]","<font style=\"Filter: Shadow(color=\\1, Direction=\\2); Width=\\3px;\">\\4</font>",$fusnewsm);
$fusnewsm = eregi_replace("\\[glow=([^\\[]*)\\,([^\\[]*)\\,([^\\[]*)\\]([^\\[]*)\\[/glow\\]","<font style=\"Filter: Glow(color=\\1, Strength=\\2); Width=\\3px;\">\\4</font>",$fusnewsm);
$fusnewsm = str_replace("[move]", "<marquee>", $fusnewsm);
$fusnewsm = str_replace("[/move]", "</marquee>", $fusnewsm);
$fusnewsm = str_replace("[hr]", "<hr>", $fusnewsm);
$fusnewsm = str_replace("[sub]", "<sub>", $fusnewsm);
$fusnewsm = str_replace("[/sub]", "</sub>", $fusnewsm);
$fusnewsm = str_replace("[tt]", "<tt>", $fusnewsm);
$fusnewsm = str_replace("[/tt]", "</tt>", $fusnewsm);
$fusnewsm = str_replace("[sup]", "<sup>", $fusnewsm);
$fusnewsm = str_replace("[/sup]", "</sup>", $fusnewsm);
$fusnewsm = str_replace("[s]", "<s>", $fusnewsm);
$fusnewsm = str_replace("[/s]", "</s>", $fusnewsm);
$fusnewsm = str_replace("[b]", "<b>", $fusnewsm);
$fusnewsm = str_replace("[/b]", "</b>", $fusnewsm);
$fusnewsm = str_replace("[i]", "<i>", $fusnewsm);
$fusnewsm = str_replace("[/i]", "</i>", $fusnewsm);
$fusnewsm = str_replace("[u]", "<u>", $fusnewsm);
$fusnewsm = str_replace("[/u]", "</u>", $fusnewsm);
$fusnewsm = str_replace("[*]", "<li>", $fusnewsm);
$fusnewsm = str_replace("[list]", "<ul>", $fusnewsm);
$fusnewsm = str_replace("[/list]", "</ul>", $fusnewsm);
$fusnewsm = eregi_replace("\\[email\\]([^\\[]*)\\[/email\\]", "<a href=\"mailto:\\1\">\\1</a>",$fusnewsm);
$fusnewsm = eregi_replace("\\[email=([^\\[]*)\\]([^\\[]*)\\[/email\\]", "<a href=\"mailto:\\1\">\\2</a>",$fusnewsm);
$fusnewsm = str_replace("[quote]", "<blockquote><span class=\"12px\">quote:</span><hr>", $fusnewsm);
$fusnewsm = str_replace("[/quote]", "<hr></blockquote>", $fusnewsm);
$fusnewsm = str_replace("[code]","<blockquote><pre>",$fusnewsm);
$fusnewsm = str_replace("[/code]","</pre></blockquote>",$fusnewsm);
$fusnewsm = eregi_replace("\\[url\\]www.([^\\[]*)\\[/url\\]", "<a href=\"http://www.\\1\" target=_blank>\\1</a>",$fusnewsm);
$fusnewsm = eregi_replace("\\[url\\]([^\\[]*)\\[/url\\]","<a href=\"\\1\" target=_blank>\\1</a>",$fusnewsm);
$fusnewsm = eregi_replace("\\[url=([^\\[]*)\\]([^\\[]*)\\[/url\\]","<a href=\"\\1\" target=_blank>\\2</a>",$fusnewsm);
$fusnewsm = eregi_replace("(^|[>[:space:]\n])([[:alnum:]]+)://([^[:space:]]*)([[:alnum:]#?/&=])([<[:space:]\n]|$)","\\1<a href=\"\\2://\\3\\4\" target=\"_blank\">\\2://\\3\\4</a>\\5", $fusnewsm);
return $fusnewsm;
}

function InsertSmillies($fusnewsm, $fusurl){
$fusnewsm = eregi_replace(":)", "<img src=\"$fusurl/img/smile.gif\">", $fusnewsm);
$fusnewsm = str_replace(";)", "<img src=\"$fusurl/img/wink.gif\">", $fusnewsm);
$fusnewsm = str_replace(":P", "<img src=\"$fusurl/img/tongue.gif\">", $fusnewsm);
$fusnewsm = str_replace(":mad:", "<img src=\"$fusurl/img/mad.gif\">", $fusnewsm);
$fusnewsm = str_replace(":D", "<img src=\"$fusurl/img/biggrin.gif\">", $fusnewsm);
$fusnewsm = str_replace(":cool", "<img src=\"$fusurl/img/cool.gif\">", $fusnewsm);
$fusnewsm = str_replace(":p", "<img src=\"$fusurl/img/tounge.gif\">", $fusnewsm);
$fusnewsm = str_replace(":soppy:", "<img src=\"$fusurl/img/soppy.gif\">", $fusnewsm);
$fusnewsm = str_replace(":(", "<img src=\"$fusurl/img/sad.gif\">", $fusnewsm);
$fusnewsm = str_replace(":surprised:", "<img src=\"$fusurl/img/boggle.gif\">", $fusnewsm);
$fusnewsm = str_replace(":?:", "<img src=\"$fusurl/img/confused.gif\">", $fusnewsm);
$fusnewsm = str_replace(":worry:", "<img src=\"$fusurl/img/worry.gif\">", $fusnewsm);
$fusnewsm = str_replace(":sleep:", "<img src=\"$fusurl/img/sleep.gif\">", $fusnewsm);
$fusnewsm = str_replace(":tired:", "<img src=\"$fusurl/img/tired.gif\">", $fusnewsm);
$fusnewsm = str_replace(":ooh:", "<img src=\"$fusurl/img/ooh.gif\">", $fusnewsm);
$fusnewsm = str_replace(":embarrasment:", "<img src=\"$fusurl/img/embarrasment.gif\">", $fusnewsm);
$fusnewsm = str_replace(":urgh:", "<img src=\"$fusurl/img/urgh.gif\">", $fusnewsm);
$fusnewsm = str_replace(":stress:", "<img src=\"$fusurl/img/stress.gif\">", $fusnewsm);
$fusnewsm = str_replace(":rolleyes:", "<img src=\"$fusurl/img/rolleyes.gif\">", $fusnewsm);
$fusnewsm = str_replace(":dunno:", "<img src=\"$fusurl/img/notsure.gif\">", $fusnewsm);
$fusnewsm = str_replace(":eek:", "<img src=\"$fusurl/img/eek.gif\">", $fusnewsm);
$fusnewsm = str_replace(":blush:", "<img src=\"$fusurl/img/blush.gif\">", $fusnewsm);
$fusnewsm = str_replace(":huh:", "<img src=\"$fusurl/img/huh.gif\">", $fusnewsm);
return $fusnewsm;
}

function buildarchivereader(){
require "config.php";// your config file
$dfile = "archive.db";
$file = file($dfile);
    while(list(,$value) = each($file)){
         list($newsm1,$fullnewsm,$userm,$subm,$emailm,$iconm,$datem,$rand) = explode("|<|", $value);
         if($fullnewsm == ""){
           $fullnewsl = "";
         }else{
         if($fsnw == "checked") {
           $fullnewsl = "<br><a href='#$rand' onClick=window.open(\"$furl/fnarchive.php?id=$rand\",\"\",\"height=$fullnewsh,width=$fullnewsw,toolbar=no,menubar=no,scrollbars=$fullnewss2,resizable=no\")>$fs</a>";
         } else{
           $fullnewsl = "<br><a href=\"$furl/fnarchive.php?id=$rand\">$fs</a>";
         }
         }
         //use icon?
         if($iconm == ""){
           $icon1 = "";
         }else{
           $icon1 = "<img src=\"$iconm\">";
         }
         //replace user variables
         $tem = str_replace("{subject}", $subm, $arctemp);
         $tem = str_replace("{user}", "<a href=\"mailto:$emailm\">$userm</a>", $tem);
         $tem = str_replace("{date}", $datem, $tem);
         $tem = str_replace("{news}", "$newsm1 $fullnewsl", $tem);
         $tem = str_replace("{icon}", $icon1, $tem);
         $subject = str_replace(" ", "%20", $subm);
         //needed for comments archiving
         /*if($compop == "checked") {
           $tem = str_replace("{viewc}", "<a href='#' onClick=window.open(\"$furl/comments.php?mid=view&id=$subject\",\"\",\"height=$comheight,width=$comwidth,toolbar=no,menubar=no,scrollbars=yes,resizable=$comresize2\")>view</a>", $tem);
         }else{
         $tem = str_replace("{viewc}", "<a href=\"$furl/comments.php?mid=view&id=$subject\">view</a>", $tem);
         }
         if($comformpop == "checked") {
           $tem = str_replace("{postc}", "<a href='#' onClick=window.open(\"$furl/comments.php?id=$subject\",\"\",\"height=400,width=400,toolbar=no,menubar=no,scrollbars=no,resizable=no\")>post</a>", $tem);
         }else{
           $tem = str_replace("{postc}", "<a href=\"$furl/comments.php?id=$subject\">post</a>", $tem);
         } */
         //replace user variables
         $ftem = str_replace("{subject}", $subm, $arcftemp);
         $ftem = str_replace("{user}", "<a href=\"mailto:$emailm\">$userm</a>", $ftem);
         $ftem = str_replace("{date}", $datem, $ftem);
         $ftem = str_replace("{news}", $fullnewsm, $ftem);
         $ftem = str_replace("{icon}", $icon1, $ftem);
         //needed for monthly archiving
         /*if($b <= $numofposts){
           what to write*/
           $cont  .= "<!--fusion $curve--><a name=\"$rand\">$tem\n";
           $cont1 .= "<?php if(\$id == \"$rand\"){?> $header $ftem<br> $footer <?php }?>";
       /*    $cont2 .= "<a href=\"$hurl#$rand\">$subm</a><br>\n";
           $contdat .= "$newsm1|<|$fullnewsm|<|$userm|<|$subm|<|$emailm|<|$iconm|<|$datem|<|$rand|<|\n";
         }else{
           $contb .= "$tem\n";
         }
         } */
         $b++;
    }
    $newsp = fopen("archive.txt",w);
    fputs($newsp,$cont);
    fclose($newsp);

    $fnewsf = fopen("fnarchive.php",w);
    fputs($fnewsf,$cont1);
    fclose($fnewsf);
}
?>
