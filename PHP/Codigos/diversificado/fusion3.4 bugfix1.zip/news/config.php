<?php
$site = "http://www.site.com";
$furl = "http://www.site.com/news";
$hurl = "http://www.site.com/index.php";
$fullnewsurl = "http://www.site.com/news/news.php";
$newsfile = "news.txt";
$headlines = "headlines.txt";
$fnewsfile = "news.php";
$dfile = "news.db";
$arc = "archive.txt";
$datefor = "m.d.y";
$numofposts = 11;
$numofh = 5;
$bb = 1;
$ht = 1;
$first = "yes";
$header = "";
$footer = "";
$skin = "basic";
$temp = "";
$ftemp = "";
$smilies = 1;
$sflink = "send.php";
$sf = "send article to a friend";
$fs = "<b>full story</b>";
?>