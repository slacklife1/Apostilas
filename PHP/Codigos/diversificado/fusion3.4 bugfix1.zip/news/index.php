<?php

/******************
fusion news management
by the fusion team

version  3.4

fusionphp.com
******************/

// change these if needed

$config = "config.php"; // your config file
$users = "users.php"; // your users file
$lang = "lang.eng.txt"; // your language

// dont edit past here ********

include_once ("functions.php");
require $config;
require $lang;
$curve = "3.4";

//login
if($id == ""){
if($first == "yes"){
$title = $langt_first;
$content = $lang_first;
}elseif(isset($HTTP_COOKIE_VARS["fusion"])){
$title = $langt_logged;
$content = $lang_reg;
if(isset($HTTP_COOKIE_VARS["fusionadmin"])){
$content .= $lang_admin_links;
}
$content .= $lang_logoutm;
}else{
$title = $langt_login;
$content = <<< html
$lang_loginm
<table width=300 cellspacing=0 cellpadding=0 border=0>
<tr>
<td width=100 valign="top">
<form action="?id=login" method="post">
$lang_user:
</td>
<td width=200 valign="top">
<input type="text" class="post" name="username">
</td>
</tr>
<tr>
<td width=100 valign="top">
$lang_pass:
</td>
<td width=200 valign="top">
<input type="password" class="post" name="password">
</td>
</tr>
<tr>
<td width=211 valign="top">
<br>
<input type="submit" class="mainoption" value="$lang_submit"><br>
</form>
</td>
</tr>
</table>
html;
}
}

//-------------------

//login
if($id == "login"){
$file = file($users);
while(list(,$value) = each($file)){
list($user,$email,$icon,$pass,$le) = explode("|", $value);
if($username == $user && $password == $pass){
setcookie("fusion", "logged", time()+43200);
setcookie("fusionuser", $user, time()+43200);
setcookie("fusionmail", $email, time()+43200);
setcookie("fusionicon", $icon, time()+43200);
if($le == 3){
setcookie("fusionadmin", "logged", time()+43200);
}elseif($le == 2){
setcookie("fusionedit", "logged", time()+43200);
}
header("Location: ./");
$log = 1;
}else{
if($log == ""){
$title = $langt_bad;
$content = $lang_bad;
}
}
}
}

//-------------------

//admin
if($id == "admin"){
if(isset($HTTP_COOKIE_VARS["fusionadmin"])){
$title = $langt_admin;
$content = <<< html
<table width=577 cellspacing=0 cellpadding=0 border=0>
<tr>
<td width=200 valign="top">
<form action="?id=save" method="post">
your site:
</td>
<td width=377 valign="top">
<input type="text" class="post" name="site1" value="$site" size="70">
</td>
</tr>
<tr>
<td width=200 valign="top">
full url to ur fusion map:
</td>
<td width=300 valign="top">
<input type="text" class="post" name="furl1" value="$furl" size="70">
</td>
</tr>
<tr>
<td width=200 valign="top">
news file:
</td>
<td width=300 valign="top">
<input type="text" class="post" name="news" value="$newsfile" size="70">
</td>
</tr>
<tr>
<td width=200 valign="top">
full news file:
</td>
<td width=300 valign="top">
<input type="text" class="post" name="fnews" value="$fnewsfile" size="70">
</td>
</tr>
<tr>
<td width=200 valign="top">
headlines file:
</td>
<td width=300 valign="top">
<input type="text" class="post" name="headline" value="$headlines" size="70">
</td>
</tr>
<tr>
<td width=200 valign="top">
data file:
</td>
<td width=300 valign="top">
<input type="text" class="post" name="daf" value="$dfile" size="70">
</td>
</tr>
<tr>
<td width=200 valign="top">
archive file:
</td>
<td width=300 valign="top">
<input type="text" class="post" name="a" value="$arc" size="70">
</td>
</tr>
<tr>
<td width=200 valign="top">
url to full news file:
</td>
<td width=300 valign="top">
<input type="text" class="post" name="newsd" value="$fullnewsurl" size="70">
</td>
</tr>
<tr>
<td width=200 valign="top">
url to page with news:
</td>
<td width=300 valign="top">
<input type="text" class="post" name="url" value="$hurl" size="70">
</td>
</tr>
<tr>
<td width=200 valign="top">
send to friend page:
</td>
<td width=300 valign="top">
<input type="text" class="post" name="sflink1" value="$sflink" size="70">
</td>
</tr>
<tr>
<td width=200 valign="top">
send to friend link:
</td>
<td width=300 valign="top">
<input type="text" class="post" name="send" value="$sf" size="70">
</td>
</tr>
<tr>
<td width=200 valign="top">
Send to friend options:
</td>
<td valign="top">
<input type="checkbox" class="post" name="stfpu" $stfpop> Allow STF form popup
</td>
</tr>
<tr>
<td width=200 valign="top">
full story link:
</td>
<td width=300 valign="top">
<input type="text" class="post" name="story" value="$fs" size="70">
</td>
</tr>
<tr>
<td width=200 valign="top">
date format (<a href="http://www.php.net/manual/en/function.date.php" target="new">help</a>):
</td>
<td width=300 valign="top">
<input type="text" class="post" name="df" value="$datefor">
</td>
</tr>
<tr>
<td width=200 valign="top">
number of posts seen:
</td>
<td width=300 valign="top">
<input type="text" class="post" name="posts" value="$numofposts" size=2>
</td>
</tr>
<tr>
<td width=200 valign="top">
number of headlines seen:
</td>
<td width=300 valign="top">
<input type="text" class="post" name="h" value="$numofh" size=2>
</td>
</tr>
<tr>
<td width=200 valign="top">
skin:
</td>
<td width=300 valign="top">
<input type="text" class="post" name="s" value="$skin">
</td>
</tr>
<tr>
<td width=200 valign="top">
allow bbcode?
</td>
<td width=300 valign="top">
<input type="checkbox" class="post" name="bbc" $bb>
</td>
</tr>
<tr>
<td width=200 valign="top">
allow html?
</td>
<td width=300 valign="top">
<input type="checkbox" class="post" name="html" $ht>
</td>
</tr>
<tr>
<td width=200 valign="top">
allow smilies?
</td>
<td width=300 valign="top">
<input type="checkbox" class="post" name="sm" $smilies>
</td>
</tr>
<tr>
<td width=200 valign="top">
Comments options:
</td>
<td valign="top">
<input type="checkbox" class="post" name="cpfu" $comformpop>  Allow Comments form popup
<br><input type="checkbox" class="post" name="cpu" $compop>  Allow Comments popup
<br>Popup options:
<br> width:<input type="text" class="post" name="cpuw" value="$comwidth" size=6>
 height:<input type="text" class="post" name="cpuh" value="$comheight" size=6>(in pixels ["100" is minimum])
<br> resizeable:<input type="checkbox" class="post" name="cpuresize" $comresize>
</p>
</td>
</tr>
<tr>
<td width=200 valign="top">
full story options:
</td>
<td valign="top">
<input type="checkbox" class="post" name="fspu" $fsnw> Allow Full Story popup
<br>Popup options:
<br> width:<input type="text" class="post" name="fspuw" value="$fullnewsw" size=6>
 height:<input type="text" class="post" name="fspuh" value="$fullnewsh" size=6>(in pixels ["100" is minimum])
<br> scrollbars:<input type="checkbox" class="post" name="fpuscrolling" $fullnewss>(only shown
when needed)
<br> resizeable:<input type="checkbox" class="post" name="fpuresize" $fullnewsz>
</td>
</tr>
<tr>
<td width=200 valign="top" colspan="2">
<b>note:</b> all fields required to work
</td>
</tr>
<tr>
<td width=211 valign="top">
<br>
<input type="submit" class="mainoption" value="$lang_submit"><input type="reset" class="mainoption" value="$lang_reset">
</form>
</td>
</tr>
</table>
html;
}else{
$title = $langt_bad;
$content = $lang_not_admin;
}
}

//------------------------

//save
if($id == "save"){
if (isset($HTTP_POST_VARS[bbc]))
{$bbca = "checked";}
else
{$bbca = "";}
if (isset($HTTP_POST_VARS[html]))
{$hm = "checked";}
else
{$hm = "";}
if (isset($HTTP_POST_VARS[sm]))
{$sm = "checked";}
else
{$sm = "";}
if (isset($HTTP_POST_VARS[fspu]))
{$fspu = "checked";}
else
{$fspu = "";}
if (isset($HTTP_POST_VARS[cpu]))
{$fcpu = "checked";}
else
{$fcpu = "";}
if (isset($HTTP_POST_VARS[stfpu]))
{$fstfpu = "checked";}
else
{$fstfpu = "";}
if (isset($HTTP_POST_VARS[cpfu]))
{$fcpfu = "checked";}
else
{$fcpfu = "";}
if (isset($HTTP_POST_VARS[fspu]))
{$fspu = "checked";}
else
{$fspu = "";}
if (isset($HTTP_POST_VARS[fpuscrolling]))
{$fspus = "checked"; $fspus2 = "yes";}
else
{$fspus = "";$fspus2 = "no";}
if (isset($HTTP_POST_VARS[cpuresize]))
{$fcpuz = "checked"; $fcpuz2 = "yes";}
else
{$fcpuz = "";$fcpuz2 = "no";}
if (isset($HTTP_POST_VARS[fpuresize]))
{$fspuz = "checked"; $fspuz2 = "yes";}
else
{$fspuz = ""; $fspuz2 = "no";}
if($fspuw < 100){
$fspuw = "100";
}
if($fspuh < 100){
$fspuh = "100";
}
if($cpuw < 100){
$cpuw = "100";
}
if($cpuh < 100){
$cpuh = "100";
}
if($s == ""){
$s = "basic";
}

$p1 = $SCRIPT_FILENAME;
$p2 = str_replace("index.php", "", $p1);

//write to file
$page = $config;
$fp = fopen($page,w);
$current = fread($fp, filesize($page));
fclose($fp);

$temp = ereg_replace('\"', '\\"',$temp);
$ftemp = ereg_replace('\"', '\\"',$ftemp);
$header = ereg_replace('\"', '\\"',$header);
$footer = ereg_replace('\"', '\\"',$footer);
//what to write
$save = "<?php
\$site = \"$site1\";
\$furl= \"$furl1\";
\$hurl = \"$url\";
\$fullnewsurl = \"$newsd\";
\$newsfile = \"$news\";
\$headlines = \"$headline\";
\$fnewsfile = \"$fnews\";
\$dfile = \"$daf\";
\$arc = \"$a\";
\$datefor = \"$df\";
\$numofposts = $posts;
\$numofh = $h;
\$bb = \"$bbca\";
\$ht = \"$hm\";
\$first = \"no\";
\$header = \"$header\";
\$footer = \"$footer\";
\$skin = \"$s\";
\$temp = \"$temp\";
\$ftemp = \"$ftemp\";
\$arctemp = \"$arctemp\";
\$arcftemp = \"$arcftemp\";
\$headercom = \"$headercom\";
\$footercom = \"$footercom\";
\$smilies = \"$sm\";
\$stfpop = \"$fstfpu\";
\$comformpop = \"$fcpfu\";
\$compop = \"$fcpu\";
\$comwidth = \"$cpuw\";
\$comheight = \"$cpuh\";
\$comresize = \"$fcpuz\";
\$comresize2 = \"$fcpuz2\";
\$comrebool = \"$fcpuz2\";
\$fsnw = \"$fspu\";
\$fullnewsw = \"$fspuw\";
\$fullnewsh = \"$fspuh\";
\$fullnewss = \"$fspus\";
\$fullnewss2 = \"$fspus2\";
\$fullnewsz2 = \"$fspuz2\";
\$fullnewsz = \"$fspuz\";
\$sflink = \"$sflink1\";
\$sf = \"$send\";
\$fs = \"$story\";
?>";

$configfile = fopen($config,w);
fputs($configfile,$save);
fclose($configfile);

$title = $langt_saved;
$content = $lang_saved;
}

//------------------------
//edit template
if($id == "template"){
if(isset($HTTP_COOKIE_VARS["fusionadmin"])){
$title = $langt_temp;
$content = <<< html
$lang_temp
<form action="?id=savetemp" method="post">
normal news:<br>
<textarea name="tem" class="post" cols=80 rows=20>$temp</textarea><br>
<br>
full news:<br>
<textarea name="ftem" class="post" cols=80 rows=20>$ftemp</textarea><br>
<br>
<input type="submit" class="mainoption" value="$lang_submit"><br>
</form>
html;
}else{
$title = $langt_bad;
$content = $lang_not_admin;
}
}

//------------------------
//save template
if($id == "savetemp"){
$fp = fopen($config,r);
$current = fread($fp, filesize($config));
fclose($fp);
$temp = addslashes($temp);
$ftemp= addslashes($ftemp);
$old = "\$temp = \"$temp\";";
$old1 = "\$ftemp = \"$ftemp\";";
$new = "\$temp = \"$tem\";";
$new1 = "\$ftemp = \"$ftem\";";

$newm = str_replace($old, $new, $current);
$newm = str_replace($old1, $new1, $newm);

$configfile = fopen($config,w);
fputs($configfile,$newm);
fclose($configfile);

$title = $langt_saved;
$content = $lang_saved;
}

//------------------------
//edit archive template
if($id == "arctemplate"){
if(isset($HTTP_COOKIE_VARS["fusionadmin"])){
$title = $langt_temp;
$content = <<< html
$lang_arctemp
<form action="?id=savearctemp" method="post">
normal news:<br>
<textarea name="arctem" class="post" cols=80 rows=20>$arctemp</textarea><br>
<br>
full news:<br>
<textarea name="arcftem" class="post" cols=80 rows=20>$arcftemp</textarea><br>
<br>
<input type="submit" class="mainoption" value="$lang_submit"><br>
</form>
html;
}else{
$title = $langt_bad;
$content = $lang_not_admin;
}
}

//------------------------
//save archive template
if($id == "savearctemp"){
$fp = fopen($config,r);
$current = fread($fp, filesize($config));
fclose($fp);
$arctemp = addslashes($arctemp);
$arcftemp= addslashes($arcftemp);
$old = "\$arctemp = \"$arctemp\";";
$old1 = "\$arcftemp = \"$arcftemp\";";
$new = "\$arctemp = \"$arctem\";";
$new1 = "\$arcftemp = \"$arcftem\";";

$newm = str_replace($old, $new, $current);
$newm = str_replace($old1, $new1, $newm);

$configfile = fopen($config,w);
fputs($configfile,$newm);
fclose($configfile);

$title = $langt_saved;
$content = $lang_saved;
}

//------------------------
//edit header
if($id == "headercom"){
if(isset($HTTP_COOKIE_VARS["fusionadmin"])){
$title = $langt_hf;
$content = <<< html
$lang_hfcom
<form action="?id=saveheadercom" method="post">
header:<br>
<textarea name="header1com" class="post" cols=80 rows=20>$headercom</textarea><br>
<br>
footer:<br>
<textarea name="footer1com" class="post" cols=80 rows=20>$footercom</textarea><br>
<br >
<input type="submit" class="mainoption" value="save"><br>
</form>
html;
}
else{
$title = $langt_bad;
$content = $lang_not_admin;
}
}

//------------------------
//edit header
if($id == "saveheadercom"){
//write to file
$fp = fopen($config,r);
$current = fread($fp, filesize($config));
fclose($fp);
$header = addslashes($header);
$footer = addslashes($footer);
$old = "\$headercom = \"$headercom\";";
$old1 = "\$footercom = \"$footercom\";";
$new = "\$headercom = \"$header1com\";";
$new1 = "\$footercom = \"$footer1com\";";

$newm = str_replace($old, $new, $current);
$newm = str_replace($old1, $new1, $newm);

$configfile = fopen($config,w);
fputs($configfile,$newm);
fclose($configfile);

$title = $langt_saved;
$content = $lang_saved;
}

//------------------------
//edit header
if($id == "header"){
if(isset($HTTP_COOKIE_VARS["fusionadmin"])){
$title = $langt_hf;
$content = <<< html
$lang_hf
<form action="?id=saveheader" method="post">
header:<br>
<textarea name="header1" class="post" cols=80 rows=20>$header</textarea><br>
<br>
footer:<br>
<textarea name="footer1" class="post" cols=80 rows=20>$footer</textarea><br>
<br >
<input type="submit" class="mainoption" value="save"><br>
</form>
html;
}
else{
$title = $langt_bad;
$content = $lang_not_admin;
}
}

//------------------------
//edit header
if($id == "saveheader"){
//write to file
$fp = fopen($config,r);
$current = fread($fp, filesize($config));
fclose($fp);
$header = addslashes($header);
$footer = addslashes($footer);
$old = "\$header = \"$header\";";
$old1 = "\$footer = \"$footer\";";
$new = "\$header = \"$header1\";";
$new1 = "\$footer = \"$footer1\";";

$newm = str_replace($old, $new, $current);
$newm = str_replace($old1, $new1, $newm);

$configfile = fopen($config,w);
fputs($configfile,$newm);
fclose($configfile);

$title = $langt_saved;
$content = $lang_saved;
}

//------------------------

//add user
if($id == "add"){
if(isset($HTTP_COOKIE_VARS["fusionadmin"])){
$title = $langt_add;
$content = <<< html
<table width=400 cellspacing=0 cellpadding=0 border=0>
<tr>
<td width=200 valign="top">
<form action="?id=signup" method="post">
$lang_user:
</td>
<td width=200 valign="top">
<input type="text" class="post" name="username">
</td>
</tr>
<tr>
<td width=200 valign="top">
$lang_mail:
</td>
<td width=200 valign="top">
<input type="text" class="post" name="email">
</td>
</tr>
<tr>
<td width=200 valign="top">
$lang_pass:
</td>
<td width=200 valign="top">
<input type="text" class="post" name="password">
</td>
</tr>
<tr>
<td width=200 valign="top">
$lang_icon:
</td>
<td width=200 valign="top">
<input type="text" class="post" name="icon">
</td>
</tr>
<tr>
<td width=200 valign="top">
$lang_user_lv:
</td>
<td width=200 valign="top">
<select name="le">
<option value="1">normal</option>
<option value="2">editor</option>
<option value="3">admin</option>
</select>
</td>
</tr>
<tr>
<td width=211 valign="top">
<br>
<input type="submit" class="mainoption" value="$lang_submit"><input type="reset" class="mainoption" value="$lang_reset">
</form>
</td>
</tr>
</table>
html;
}
else{
$title = $langt_bad;
$content = $lang_not_admin;
}
}

//------------------------
if($id == "signup"){
//left blank?
if(!$username or !$email or !$password){
$title = "field left blank";
$content = "field left blank";
}
else{
//get file
$file = file($users);
while(list(,$value) = each($file)){
list($fuser,$femail,$ficon,$fpass,$fle) = split( "\|", $value);

if($username == $fuser){

$title = $langt_bad;
$content = $lang_bad_name;
$yes = 0;
}else{
$yes = 1;
}
}

if($yes == 1){
$fp = fopen($users,a);
fwrite($fp,"$username|$email|$icon|$password|$le|\n");
fclose($fp);

$title = $langt_added;
$content = "$username was added.";
}
else{
$title = $langt_bad;
$content = $lang_bad_name;
}
}
}

//------------------------
//edit users
if($id == "user"){
if(isset($HTTP_COOKIE_VARS["fusionadmin"])){
$title = "edit users";
$content = <<< html
<form action="?id=edit" method="post">
user:<br>
<select name="user">
html;
$file = file($users);
$u = 0;
while(list(,$value) = each($file)){
list($fuser,$femail,$ficon,$fpass,$fle) = explode("|", $value);
$content .= "<option name=\"user\" value=\"$fuser\">$fuser</option>\n";
$u++;
}
$content .= <<< html
</select>
<input type="submit" class="mainoption" value="edit">
</form>
html;
}
else{
$title = "not admin";
$content = "not admin";
}
}

//------------------------
//edit users
if($id == "edit"){
if(isset($HTTP_COOKIE_VARS["fusionadmin"])){
$file = file($users);
while(list(,$value) = each($file)){
list($fuser,$femail,$ficon,$fpass,$fle) = explode("|", $value);
if($user == $fuser){
$title = $langt_editu;
$nor1 = "";
$edi1 = "";
$adm1 = "";
if($fle == 1){
$nor1 = "selected";
}elseif($fle == 2){
$edi1 = "selected";
}elseif($fle == 3){
$adm1 = "selected";
}
$content = <<< html
<script language="javascript">
<!--
function Delete(){
  if(document.formpke.deleteuser.value == "no"){
     document.formpke.deleteuser.value = "yes";
  }else{
     document.formpke.deleteuser.value = "no";
  }
}
//-->
</script>
<form action="?id=edit1" method="post" name="formpke">
<input type="hidden" name="name" value="$fuser">
<input type="hidden" name="deleteuser" value="no">
<table width=400 cellspacing=0 cellpadding=0 border=0>
<tr>
<td width=400 valign="top">
<form action="?id=signup" method="post">
<b>$fuser</b>
</td>
</tr>
<tr>
<td width=200 valign="top">
$lang_mail:
</td>
<td width=200 valign="top">
<input type="text" class="post" name="mail1" value="$femail">
</td>
</tr>
<tr>
<td width=200 valign="top">
$lang_pass:
</td>
<td width=200 valign="top">
<input type="text" class="post" name="passw" value="$fpass">
</td>
</tr>
<tr>
<td width=200 valign="top">
$lang_icon:
</td>
<td width=200 valign="top">
<input type="text" class="post" name="icon1" value="$ficon">
</td>
</tr>
<tr>
<td width=200 valign="top">
$lang_user_lv:
</td>
<td width=200 valign="top">
<select name="fle">
<option value="1" $nor1>normal</option>
<option value="2" $edi1>editor</option>
<option value="3" $adm1>admin</option>
</select>
</td>
</tr>
<tr>
<td width=211 valign="top">
delete? <input type="checkbox" class="post" name="del" onClick=Delete();><br>
<br>
<input type="submit" class="mainoption" value="$lang_submit"><input class="mainoption" type="reset" class="mainoption" value="$lang_reset">
</form>
</td>
</tr>
</table>
html;
}
}
}
else{
$title = $langt_bad;
$content = $lang_not_admin;
}
}

//------------------------
//edit users
if($id == "edit1"){
if(!$mail1){
$title = $langt_bad;
$content = $langt_bad;
}
else{
$file = file($users);
while(list(,$value) = each($file)){
list($fuser,$femail,$ficon,$fpass,$le) = split("\|", $value);
if($name == $fuser){
if($deleteuser == "yes"){
$oldword = "$fuser|$femail|$ficon|$fpass|$fle|\n";
$newword = "";
}
else{
$oldword = "$fuser|$femail|$ficon|$fpass|$le|";
$newword = "$name|$mail1|$icon1|$passw|$fle|";
}
$fp = fopen($users,r);
$data = fread($fp, filesize($users));
fclose($fp);

$newdata = str_replace($oldword, $newword, $data);
$fp = fopen($users,w);
fputs($fp,$newdata);
fclose($fp);

$title = $langt_editu;
$content = $lang_editud;
}
}
}
}

//-------------------
//post news
//-------------------

//post news
if($id == "postnews"){
  if(isset($HTTP_COOKIE_VARS["fusion"])){
    $title = $langt_post;
    if($action == "preview"){
      $news = ereg_replace("\\\'", "'", $news);
      $news = ereg_replace('\\\"', '"', $news);
      $news1 = ereg_replace("\n", "<br />", $news);
      $fullnews = ereg_replace("\\\'", "'", $fullnews);
      $fullnews = ereg_replace('\\\"', '"', $fullnews);
      $fullnews1 = ereg_replace("\n", "<br />", $fullnews);
      //bbcode
      if($bb == "checked"){
        $news1 = InsertBBCode($news1);
        $fullnews1 = InsertBBCode($fullnews1);
      } else {
        $news1 = $news;
        $fullnews1 = $fullnews;
      }
      if($smilies == "checked"){
        $news1 = InsertSmillies($news1,$furl);
        $fullnews1 = InsertSmillies($fullnews1,$furl);
      }
      //html
      if($ht != "checked"){
        $news1 = strip_tags($news1);
        $fullnews1 = strip_tags($fullnews1);
      }
$content = <<< html
<p align="center"><b>Fusion Preview</b>
<table width="100%" border="0" cellspacing="1" cellpadding="2" bgcolor="#DCDCDC">
 <tr>
  <td align=left bgcolor="f5f5f5" colspan="2">
      <font color="black">News:</font><font color="black">&nbsp;</font>
  </td>
 </tr>
 <tr>
  <td bgcolor="white" colspan="2"><align=left>$news1
  </td>
 </tr>
 <tr>
  <td align=left bgcolor="f5f5f5" colspan="2">
      <font color="black">Fullnews:</font>
  </td>
 </tr>
 <tr>
  <td bgcolor="white" colspan="2"><align=left>$fullnews1
  </td>
 </tr>
</table><br>
html;
   }
$content .= <<< html
<table width=690 cellspacing=0 cellpadding=0 border=0>
<tr>
<td align=left width=110 valign="top">
<form action="?id=post" method="post" name="newsposting" ENCTYPE="multipart/form-data" onSubmit="submitonce(this);">
$lang_user:
</td>
<td align=left width=390 valign="top">
<input type="hidden" name="user" value="$fusionuser">
$fusionuser
</td>
</tr>
<tr>
<td align=left width=110 valign="top">
$lang_mail:
</td>
<td align=left width=390 valign="top">
<input type="text" class="post" name="email" value="$fusionmail">
</td>
</tr>
<tr>
<td align=left width=110 valign="top">
$lang_icon:
</td>
<td align=left width=390 valign="top">
<input type="text" class="post" name="icon" value="$fusionicon">
</td>
</tr>
<tr>
<td align=left width=110 valign="top">
$lang_sub:
</td>
<td align=left width=390 valign="top">
<input type="text" class="post" name="subject" value="$subject">
</td>
</tr>
<tr>
<td align=left width=690 valign="top" align="left" colspan="2"><br><b>$lang_intro:</b></td>
</tr>
</table>

<script language="JavaScript">
<!--
function setsmileyn(text) {
	if (document.newsposting.news.createTextRange && document.newsposting.news.caretPos) {
		var caretPos = document.newsposting.news.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.newsposting.news.value += text;
	document.newsposting.news.focus(caretPos)
}

function storeCaret(text) {
	if (text.createTextRange) {
		text.caretPos = document.selection.createRange().duplicate();
	}
}

function setsmiley2n(text) {
	if (document.newsposting.fullnews.createTextRange && document.newsposting.fullnews.caretPos) {
		var caretPos = document.newsposting.fullnews.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.newsposting.fullnews.value += text;
	document.newsposting.fullnews.focus(caretPos)
}

function submitonce(theform) {
	// if IE 4+ or NS 6+
	if (document.all || document.getElementById) {
		// hunt down "submit" and "reset"
		for (i=0;i<theform.length;i++) {
			var tempobj=theform.elements[i];
			if(tempobj.type.toLowerCase()=="submit"||tempobj.type.toLowerCase()=="reset") {
				//disable it
				tempobj.disabled=true;
			}
		}
	}
}

function Preview() {
        document.newsposting.action = "?id=postnews&action=preview";
}
//-->
</script>

<table width=690 cellspacing=0 cellpadding=0 border=0>
<tr>
<td width=500 valign="top" align="left" colspan="2">
<a href="Javascript:setsmileyn(':)');"><img src="img/smile.gif" border="0"></a><a href="Javascript:setsmileyn(';)');"><img src="img/wink.gif" border="0"></a>
<a href="Javascript:setsmileyn(':P');"><img src="img/tongue.gif" border="0"></a><a href="Javascript:setsmileyn(':mad:');"><img src="img/mad.gif" border="0"></a>
<a href="Javascript:setsmileyn(':D');"><img src="img/biggrin.gif" border="0"></a><a href="Javascript:setsmileyn(':cool');"><img src="img/cool.gif" border="0"></a>
<a href="Javascript:setsmileyn(':soppy:');"><img src="img/soppy.gif" border="0"></a><a href="Javascript:setsmileyn(':(');"><img src="img/sad.gif" border="0"></a>
<a href="Javascript:setsmileyn(':surprised:');"><img src="img/boggle.gif" border="0"></a><a href="Javascript:setsmileyn(':?:');"><img src="img/confused.gif" border="0"></a>
<a href="Javascript:setsmileyn(':worry:');"><img src="img/worry.gif" border="0"></a><a href="Javascript:setsmileyn(':sleep:');"><img src="img/sleep.gif" border="0"></a>
<a href="Javascript:setsmileyn(':tired:');"><img src="img/tired.gif" border="0"></a><a href="Javascript:setsmileyn(':ooh:');"><img src="img/ooh.gif" border="0"></a>
<a href="Javascript:setsmileyn(':embarrasment:');"><img src="img/embarrasment.gif" border="0"></a><a href="Javascript:setsmileyn(':urgh:');"><img src="img/urgh.gif" border="0"></a>
<a href="Javascript:setsmileyn(':stress:');"><img src="img/stress.gif" border="0"></a><a href="Javascript:setsmileyn(':rolleyes:');"><img src="img/rolleyes.gif" border="0"></a>
<a href="Javascript:setsmileyn(':dunno:');"><img src="img/notsure.gif" border="0"></a><a href="Javascript:setsmileyn(':eek:');"><img src="img/eek.gif" border="0"></a>
<a href="Javascript:setsmileyn(':blush:');"><img src="img/blush.gif" border="0"></a><a href="Javascript:setsmileyn(':huh:');"><img src="img/huh.gif" border="0"></a>
</td>
</tr>
<tr>
<td width="110" valign="top" align="left">
<a href="Javascript:setsmileyn('[b]text[/b]');"><img src="img/bold.gif" border="0" alt="Bold Font"></a>
<a href="Javascript:setsmileyn('[i]text[/i]');"><img src="img/italic.gif" border="0" alt="Italics font"></a>
<a href="Javascript:setsmileyn('[u]text[/u]');"><img src="img/underline.gif" border="0" alt="Underline"></a>
<a href="Javascript:setsmileyn('[s]text[/s]');"><img src="img/strike.gif" border="0" alt="Strike Out"></a><br>
<a href="Javascript:setsmileyn('[sub]text[/sub]');"><img src="img/sub.gif" border="0" alt="Subscript"></a>
<a href="Javascript:setsmileyn('[sup]text[/sup]');"><img src="img/sup.gif" border="0" alt="Superscript"></a>
<a href="Javascript:setsmileyn('[shadow=red,left,1]TEXT[/shadow]');"><img src="img/shadow.gif" border="0" alt="Shadow Text"></a>
<a href="Javascript:setsmileyn('[glow=red,2,1]TEXT[/glow]');"><img src="img/glow.gif" border="0" alt="Glow Text"></a><br>
<a href="Javascript:setsmileyn('[color=red]text[/color]');"><img src="img/color.gif" border="0" alt="Font color"></a>
<a href="Javascript:setsmileyn('[font=verdana]text[/font]');"><img src="img/fontface.gif" border="0" alt="Font face"></a>
<a href="Javascript:setsmileyn('[size=2]text[/size]');"><img src="img/fontsize.gif" border="0" alt="font size"></a>
<a href="Javascript:setsmileyn('[align=left]text[/align]');"><img src="img/fontleft.gif" border="0" alt="Font alignment"></a><br>
<a href="Javascript:setsmileyn('[tt]text[/tt]');"><img src="img/tele.gif" border="0" alt="Teletype"></a>
<a href="Javascript:setsmileyn('[hr]');"><img src="img/hr.gif" border="0" alt="Horizontal Line"></a>
<a href="Javascript:setsmileyn('[move]STUFF[/move]');"><img src="img/move.gif" border="0" alt="Move"></a>
<a href="Javascript:setsmileyn('[quote]text[/quote]');"><img src="img/quote2.gif" border="0" alt="Quote"></a><br>
<a href="Javascript:setsmileyn('[flash=200,200]URL[/flash]');"><img src="img/flash.gif" border="0" alt="Flash Image"></a>
<a href="Javascript:setsmileyn('[img]URL[/img]');"><img src="img/img.gif" border="0" alt="Image"></a>
<a href="Javascript:setsmileyn('[email=mailto:username@site.com]Mail Meg![/email]');"><img src="img/email2.gif" border="0" alt="E-mail link"></a>
<a href="Javascript:setsmileyn('[url=http://www.url.com]address[/url]');"><img src="img/url.gif" border="0" alt="hyperlink"></a><br>
<a href="Javascript:setsmileyn('[list][*]text1[*]text2[*]text3[/list]');"><img src="img/list.gif" border="0" alt="List"></a>
</td>
<td width=390 valign="top" align="left"><textarea class="post" name="news" rows="15" cols="80" ONSELECT="javascript:storeCaret(this);" ONCLICK="javascript:storeCaret(this);" ONKEYUP="javascript:storeCaret(this);" ONCHANGE="javascript:storeCaret(this);">$news</textarea></td>
</tr>
<tr>
<td width=500 valign="top" align="left" colspan="2"><br><b>$lang_full:</b></td>
</tr>
<tr>
<td width=500 valign="top" align="left" colspan="2">
<a href="Javascript:setsmiley2n(':)');"><img src="img/smile.gif" border="0"></a><a href="Javascript:setsmiley2n(';)');"><img src="img/wink.gif" border="0"></a>
<a href="Javascript:setsmiley2n(':P');"><img src="img/tongue.gif" border="0"></a><a href="Javascript:setsmiley2n(':mad:');"><img src="img/mad.gif" border="0"></a>
<a href="Javascript:setsmiley2n(':D');"><img src="img/biggrin.gif" border="0"></a><a href="Javascript:setsmiley2n(':cool');"><img src="img/cool.gif" border="0"></a>
<a href="Javascript:setsmiley2n(':soppy:');"><img src="img/soppy.gif" border="0"></a><a href="Javascript:setsmiley2n(':(');"><img src="img/sad.gif" border="0"></a>
<a href="Javascript:setsmiley2n(':surprised:');"><img src="img/boggle.gif" border="0"></a><a href="Javascript:setsmiley2n(':?:');"><img src="img/confused.gif" border="0"></a>
<a href="Javascript:setsmiley2n(':worry:');"><img src="img/worry.gif" border="0"></a><a href="Javascript:setsmiley2n(':sleep:');"><img src="img/sleep.gif" border="0"></a>
<a href="Javascript:setsmiley2n(':tired:');"><img src="img/tired.gif" border="0"></a><a href="Javascript:setsmiley2n(':ooh:');"><img src="img/ooh.gif" border="0"></a>
<a href="Javascript:setsmiley2n(':embarrasment:');"><img src="img/embarrasment.gif" border="0"></a><a href="Javascript:setsmiley2n(':urgh:');"><img src="img/urgh.gif" border="0"></a>
<a href="Javascript:setsmiley2n(':stress:');"><img src="img/stress.gif" border="0"></a><a href="Javascript:setsmiley2n(':rolleyes:');"><img src="img/rolleyes.gif" border="0"></a>
<a href="Javascript:setsmiley2n(':dunno:');"><img src="img/notsure.gif" border="0"></a><a href="Javascript:setsmiley2n(':eek:');"><img src="img/eek.gif" border="0"></a>
<a href="Javascript:setsmiley2n(':blush:');"><img src="img/blush.gif" border="0"></a><a href="Javascript:setsmiley2n(':huh:');"><img src="img/huh.gif" border="0"></a>
</td>
</tr>
<tr>
<td width="110" valign="top" align="left">
<a href="Javascript:setsmiley2n('[b]text[/b]');"><img src="img/bold.gif" border="0" alt="Bold Font"></a>
<a href="Javascript:setsmiley2n('[i]text[/i]');"><img src="img/italic.gif" border="0" alt="Italics font"></a>
<a href="Javascript:setsmiley2n('[u]text[/u]');"><img src="img/underline.gif" border="0" alt="Underline"></a>
<a href="Javascript:setsmiley2n('[s]text[/s]');"><img src="img/strike.gif" border="0" alt="Strike Out"></a><br>
<a href="Javascript:setsmiley2n('[sub]text[/sub]');"><img src="img/sub.gif" border="0" alt="Subscript"></a>
<a href="Javascript:setsmiley2n('[sup]text[/sup]');"><img src="img/sup.gif" border="0" alt="Superscript"></a>
<a href="Javascript:setsmiley2n('[shadow=red,left,1]TEXT[/shadow]');"><img src="img/shadow.gif" border="0" alt="Shadow Text"></a>
<a href="Javascript:setsmiley2n('[glow=red,2,1]TEXT[/glow]');"><img src="img/glow.gif" border="0" alt="Glow Text"></a><br>
<a href="Javascript:setsmiley2n('[color=red]text[/color]');"><img src="img/color.gif" border="0" alt="Font color"></a>
<a href="Javascript:setsmiley2n('[font=verdana]text[/font]');"><img src="img/fontface.gif" border="0" alt="Font face"></a>
<a href="Javascript:setsmiley2n('[size=2]text[/size]');"><img src="img/fontsize.gif" border="0" alt="font size"></a>
<a href="Javascript:setsmiley2n('[align=left]text[/align]');"><img src="img/fontleft.gif" border="0" alt="Font alignment"></a><br>
<a href="Javascript:setsmiley2n('[tt]text[/tt]');"><img src="img/tele.gif" border="0" alt="Teletype"></a>
<a href="Javascript:setsmiley2n('[hr]');"><img src="img/hr.gif" border="0" alt="Horizontal Line"></a>
<a href="Javascript:setsmiley2n('[move]STUFF[/move]');"><img src="img/move.gif" border="0" alt="Move"></a>
<a href="Javascript:setsmiley2n('[quote]text[/quote]');"><img src="img/quote2.gif" border="0" alt="Quote"></a><br>
<a href="Javascript:setsmiley2n('[flash=200,200]URL[/flash]');"><img src="img/flash.gif" border="0" alt="Flash Image"></a>
<a href="Javascript:setsmiley2n('[img]URL[/img]');"><img src="img/img.gif" border="0" alt="Image"></a>
<a href="Javascript:setsmiley2n('[email=mailto:username@site.com]Mail Meg![/email]');"><img src="img/email2.gif" border="0" alt="E-mail link"></a>
<a href="Javascript:setsmiley2n('[url=http://www.url.com]address[/url]');"><img src="img/url.gif" border="0" alt="hyperlink"></a><br>
<a href="Javascript:setsmiley2n('[list][*]text1[*]text2[*]text3[/list]');"><img src="img/list.gif" border="0" alt="List"></a>
</td>
<td width=500 valign="top" align="left"><textarea class="post" name="fullnews" rows="15" cols="80" ONSELECT="javascript:storeCaret(this);" ONCLICK="javascript:storeCaret(this);" ONKEYUP="javascript:storeCaret(this);" ONCHANGE="javascript:storeCaret(this);">$fullnews</textarea></td>
</tr>
<tr>
<td width=110 valign="top" align="left">&nbsp;</td>
<td width=390 valign="top" align="left">
<input type="submit" class="mainoption" value="$lang_submit">
<input type="submit" class="mainoption" value="Preview" onClick="Preview()">
<input type="reset" class="mainoption" value="$lang_reset"><br><br></td>
</tr>
</form>
</table>
html;
}else{
header("Location: ./");
}
}

//--------------
if($id == "editposts"){
if(isset($HTTP_COOKIE_VARS["fusion"])){
$title = $langt_editp;
$content = "<table width=\"100%\"><tr><td width=50%><b>$lang_sub</a></td><td width=25%><b>$lang_user</b></td><td width=25%><b>$lang_date</b></td></tr>";
$file = file($dfile);
$e = 0;
while(list(,$value) = each($file)){
list($newsm,$fnewsm,$userm,$subm,$emailm,$iconm,$datem,$rand) = explode("|<|", $value);
$content .= "<tr><td width=50%><a href=\"?id=editposts2&num=$rand&action=post\">$subm</a></td><td width=25%>$userm</td><td widht=25%>$datem</td></tr>";
$e++;
}
$content .= "</table>";
}
}

//---

if($id == "editposts2"){
  if(isset($HTTP_COOKIE_VARS["fusion"])){
    $title = $langt_editp;
    if($action == "preview"){
      $news = ereg_replace("\\\'", "'", $news);
      $news = ereg_replace('\\\"', '"', $news);
      $news1 = ereg_replace("\n", "<br />", $news);
      $fullnews = ereg_replace("\\\'", "'", $fullnews);
      $fullnews = ereg_replace('\\\"', '"', $fullnews);
      $fullnews1 = ereg_replace("\n", "<br />", $fullnews);
      //bbcode
      if($bb == "checked"){
        $news1 = InsertBBCode($news1);
        $fullnews1 = InsertBBCode($fullnews1);
      } else {
        $news1 = $news1;
        $fullnews1 = $fullnews1;
      }
      if($smilies == "checked"){
        $news1 = InsertSmillies($news1,$furl);
        $fullnews1 = InsertSmillies($fullnews1,$furl);
      }
      //html
      if($ht != "checked"){
        $news1 = strip_tags($news1);
        $fullnews1 = strip_tags($fullnews1);
      }
    }
    $file = file($dfile);
    while(list(,$value) = each($file)){
      list($newsm,$fnewsm,$userm,$subm,$emailm,$iconm,$datem,$rand) = explode("|<|", $value);
      if($num == $rand){
      if($action == "preview"){
        $newsm = ereg_replace("<br />", "\n", $news);
        $fnewsm = ereg_replace("<br />", "\n", $fullnews);
$content = <<< html
<p align="center"><b>Fusion Preview</b>
<table width="100%" border="0" cellspacing="1" cellpadding="2" bgcolor="#DCDCDC">
 <tr>
  <td align=left bgcolor="f5f5f5" colspan="2">
      <font color="black">News:</font><font color="black">&nbsp;</font>
  </td>
 </tr>
 <tr>
  <td bgcolor="white" colspan="2"><align=left>$news1
  </td>
 </tr>
 <tr>
  <td align=left bgcolor="f5f5f5" colspan="2">
      <font color="black">Fullnews:</font>
  </td>
 </tr>
 <tr>
  <td bgcolor="white" colspan="2"><align=left>$fullnews1
  </td>
 </tr>
</table><br>
html;
      } else {
        $newsm = str_replace("<br />", "\n", $newsm);
        $fnewsm = str_replace("<br />", "\n", $fnewsm);
      }
$content .= <<< html
<form action="index.php?id=editposts3" method="post" name="editfuspost" ENCTYPE="multipart/form-data" onSubmit="submitonce(this);">
<table width=500 cellspacing=0 cellpadding=0 border=0>
<tr>
<td align=left width=200 valign="top">
<input type="hidden" name="icon" value="$iconm">
<input type="hidden" name="email" value="$emailm">
<input type="hidden" name="name" value="$userm">
<input type="hidden" name="num" value="$rand">
<input type="hidden" name="date" value="$datem">
$lang_user:
</td>
<td align=left width=300 valign="top">
$userm
</td>
</tr>
<tr>
<td align=left width=200 valign="top">
$lang_mail:
</td>
<td align=left width=300 valign="top">
$emailm
</td>
</tr>
html;
if($iconm == ""){
$icona = "";
}
else{
$icona = "
<tr>
<td width=200 valign=\"top\">
$lang_icon:
</td>
<td width=300 valign=\"top\">
<img src=\"$iconm\"/>
</td>
</tr>
";
}
$content .= <<< html
$icona
<tr>
<td align=left width=200 valign="top">
$lang_sub:
</td>
<td align=left width=300 valign="top">
<input type="text" class="post" name="subject" value="$subm">
</td>
</tr>
</table>

<script language="JavaScript">
<!--
function setsmiley(text) {
	if (document.editfuspost.news.createTextRange && document.editfuspost.news.caretPos) {
		var caretPos = document.editfuspost.news.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.editfuspost.news.value += text;
	document.editfuspost.news.focus(caretPos)
}

function storeCaret(text) {
	if (text.createTextRange) {
		text.caretPos = document.selection.createRange().duplicate();
	}
}

function setsmiley2(text) {
	if (document.editfuspost.fullnews.createTextRange && document.editfuspost.fullnews.caretPos) {
		var caretPos = document.editfuspost.fullnews.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.editfuspost.fullnews.value += text;
	document.editfuspost.fullnews.focus(caretPos)
}

function submitonce(theform) {
	// if IE 4+ or NS 6+
	if (document.all || document.getElementById) {
		// hunt down "submit" and "reset"
		for (i=0;i<theform.length;i++) {
			var tempobj=theform.elements[i];
			if(tempobj.type.toLowerCase()=="submit"||tempobj.type.toLowerCase()=="reset") {
				//disable it
				tempobj.disabled=true;
			}
		}
	}
}

function Preview() {

        document.editfuspost.action = "index.php?id=editposts2&action=preview"
}
//-->
</script>

<table width=690 cellspacing=0 cellpadding=0 border=0>
<tr>
<td width=500 valign="top" align="left" colspan="2">
<a href="Javascript:setsmiley(':)');"><img src="img/smile.gif" border="0"></a><a href="Javascript:setsmiley(';)');"><img src="img/wink.gif" border="0"></a>
<a href="Javascript:setsmiley(':P');"><img src="img/tongue.gif" border="0"></a><a href="Javascript:setsmiley(':mad:');"><img src="img/mad.gif" border="0"></a>
<a href="Javascript:setsmiley(':D');"><img src="img/biggrin.gif" border="0"></a><a href="Javascript:setsmiley(':cool');"><img src="img/cool.gif" border="0"></a>
<a href="Javascript:setsmiley(':soppy:');"><img src="img/soppy.gif" border="0"></a><a href="Javascript:setsmiley(':(');"><img src="img/sad.gif" border="0"></a>
<a href="Javascript:setsmiley(':surprised:');"><img src="img/boggle.gif" border="0"></a><a href="Javascript:setsmiley(':?:');"><img src="img/confused.gif" border="0"></a>
<a href="Javascript:setsmiley(':worry:');"><img src="img/worry.gif" border="0"></a><a href="Javascript:setsmiley(':sleep:');"><img src="img/sleep.gif" border="0"></a>
<a href="Javascript:setsmiley(':tired:');"><img src="img/tired.gif" border="0"></a><a href="Javascript:setsmiley(':ooh:');"><img src="img/ooh.gif" border="0"></a>
<a href="Javascript:setsmiley(':embarrasment:');"><img src="img/embarrasment.gif" border="0"></a><a href="Javascript:setsmiley(':urgh:');"><img src="img/urgh.gif" border="0"></a>
<a href="Javascript:setsmiley(':stress:');"><img src="img/stress.gif" border="0"></a><a href="Javascript:setsmiley(':rolleyes:');"><img src="img/rolleyes.gif" border="0"></a>
<a href="Javascript:setsmiley(':dunno:');"><img src="img/notsure.gif" border="0"></a><a href="Javascript:setsmiley(':eek:');"><img src="img/eek.gif" border="0"></a>
<a href="Javascript:setsmiley(':blush:');"><img src="img/blush.gif" border="0"></a><a href="Javascript:setsmiley(':huh:');"><img src="img/huh.gif" border="0"></a>
</td>
</tr>
<tr>
<td width="110" valign="top" align="left">
<a href="Javascript:setsmiley('[b]text[/b]');"><img src="img/bold.gif" border="0" alt="Bold Font"></a>
<a href="Javascript:setsmiley('[i]text[/i]');"><img src="img/italic.gif" border="0" alt="Italics font"></a>
<a href="Javascript:setsmiley('[u]text[/u]');"><img src="img/underline.gif" border="0" alt="Underline"></a>
<a href="Javascript:setsmiley('[s]text[/s]');"><img src="img/strike.gif" border="0" alt="Strike Out"></a><br>
<a href="Javascript:setsmiley('[sub]text[/sub]');"><img src="img/sub.gif" border="0" alt="Subscript"></a>
<a href="Javascript:setsmiley('[sup]text[/sup]');"><img src="img/sup.gif" border="0" alt="Superscript"></a>
<a href="Javascript:setsmiley('[shadow=red,left,1]TEXT[/shadow]');"><img src="img/shadow.gif" border="0" alt="Shadow Text"></a>
<a href="Javascript:setsmiley('[glow=red,2,1]TEXT[/glow]');"><img src="img/glow.gif" border="0" alt="Glow Text"></a><br>
<a href="Javascript:setsmiley('[color=red]text[/color]');"><img src="img/color.gif" border="0" alt="Font color"></a>
<a href="Javascript:setsmiley('[font=verdana]text[/font]');"><img src="img/fontface.gif" border="0" alt="Font face"></a>
<a href="Javascript:setsmiley('[size=2]text[/size]');"><img src="img/fontsize.gif" border="0" alt="font size"></a>
<a href="Javascript:setsmiley('[align=left]text[/align]');"><img src="img/fontleft.gif" border="0" alt="Font alignment"></a><br>
<a href="Javascript:setsmiley('[tt]text[/tt]');"><img src="img/tele.gif" border="0" alt="Teletype"></a>
<a href="Javascript:setsmiley('[hr]');"><img src="img/hr.gif" border="0" alt="Horizontal Line"></a>
<a href="Javascript:setsmiley('[move]STUFF[/move]');"><img src="img/move.gif" border="0" alt="Move"></a>
<a href="Javascript:setsmiley('[quote]text[/quote]');"><img src="img/quote2.gif" border="0" alt="Quote"></a><br>
<a href="Javascript:setsmiley('[flash=200,200]URL[/flash]');"><img src="img/flash.gif" border="0" alt="Flash Image"></a>
<a href="Javascript:setsmiley('[img]URL[/img]');"><img src="img/img.gif" border="0" alt="Image"></a>
<a href="Javascript:setsmiley('[email=mailto:username@site.com]Mail Meg![/email]');"><img src="img/email2.gif" border="0" alt="E-mail link"></a>
<a href="Javascript:setsmiley('[url=http://www.url.com]address[/url]');"><img src="img/url.gif" border="0" alt="hyperlink"></a><br>
<a href="Javascript:setsmiley('[list][*]text1[*]text2[*]text3[/list]');"><img src="img/list.gif" border="0" alt="List"></a>
</td>
<td width=390 valign="top" align="left"><textarea class="post" name="news" rows="15" cols="80" ONSELECT="javascript:storeCaret(this);" ONCLICK="javascript:storeCaret(this);" ONKEYUP="javascript:storeCaret(this);" ONCHANGE="javascript:storeCaret(this);">$newsm</textarea></td>
</tr>
<tr>
<td width=500 valign="top" align="left" colspan="2"><br><b>$lang_full:</b></td>
</tr>
<tr>
<td width=500 valign="top" align="left" colspan="2">
<a href="Javascript:setsmiley2(':)');"><img src="img/smile.gif" border="0"></a><a href="Javascript:setsmiley2(';)');"><img src="img/wink.gif" border="0"></a>
<a href="Javascript:setsmiley2(':P');"><img src="img/tongue.gif" border="0"></a><a href="Javascript:setsmiley2(':mad:');"><img src="img/mad.gif" border="0"></a>
<a href="Javascript:setsmiley2(':D');"><img src="img/biggrin.gif" border="0"></a><a href="Javascript:setsmiley2(':cool');"><img src="img/cool.gif" border="0"></a>
<a href="Javascript:setsmiley2(':soppy:');"><img src="img/soppy.gif" border="0"></a><a href="Javascript:setsmiley2(':(');"><img src="img/sad.gif" border="0"></a>
<a href="Javascript:setsmiley2(':surprised:');"><img src="img/boggle.gif" border="0"></a><a href="Javascript:setsmiley2(':?:');"><img src="img/confused.gif" border="0"></a>
<a href="Javascript:setsmiley2(':worry:');"><img src="img/worry.gif" border="0"></a><a href="Javascript:setsmiley2(':sleep:');"><img src="img/sleep.gif" border="0"></a>
<a href="Javascript:setsmiley2(':tired:');"><img src="img/tired.gif" border="0"></a><a href="Javascript:setsmiley2(':ooh:');"><img src="img/ooh.gif" border="0"></a>
<a href="Javascript:setsmiley2(':embarrasment:');"><img src="img/embarrasment.gif" border="0"></a><a href="Javascript:setsmiley2(':urgh:');"><img src="img/urgh.gif" border="0"></a>
<a href="Javascript:setsmiley2(':stress:');"><img src="img/stress.gif" border="0"></a><a href="Javascript:setsmiley2(':rolleyes:');"><img src="img/rolleyes.gif" border="0"></a>
<a href="Javascript:setsmiley2(':dunno:');"><img src="img/notsure.gif" border="0"></a><a href="Javascript:setsmiley2(':eek:');"><img src="img/eek.gif" border="0"></a>
<a href="Javascript:setsmiley2(':blush:');"><img src="img/blush.gif" border="0"></a><a href="Javascript:setsmiley2(':huh:');"><img src="img/huh.gif" border="0"></a>
</td>
</tr>
<tr>
<td width="110" valign="top" align="left">
<a href="Javascript:setsmiley2('[b]text[/b]');"><img src="img/bold.gif" border="0" alt="Bold Font"></a>
<a href="Javascript:setsmiley2('[i]text[/i]');"><img src="img/italic.gif" border="0" alt="Italics font"></a>
<a href="Javascript:setsmiley2('[u]text[/u]');"><img src="img/underline.gif" border="0" alt="Underline"></a>
<a href="Javascript:setsmiley2('[s]text[/s]');"><img src="img/strike.gif" border="0" alt="Strike Out"></a><br>
<a href="Javascript:setsmiley2('[sub]text[/sub]');"><img src="img/sub.gif" border="0" alt="Subscript"></a>
<a href="Javascript:setsmiley2('[sup]text[/sup]');"><img src="img/sup.gif" border="0" alt="Superscript"></a>
<a href="Javascript:setsmiley2('[shadow=red,left,1]TEXT[/shadow]');"><img src="img/shadow.gif" border="0" alt="Shadow Text"></a>
<a href="Javascript:setsmiley2('[glow=red,2,1]TEXT[/glow]');"><img src="img/glow.gif" border="0" alt="Glow Text"></a><br>
<a href="Javascript:setsmiley2('[color=red]text[/color]');"><img src="img/color.gif" border="0" alt="Font color"></a>
<a href="Javascript:setsmiley2('[font=verdana]text[/font]');"><img src="img/fontface.gif" border="0" alt="Font face"></a>
<a href="Javascript:setsmiley2('[size=2]text[/size]');"><img src="img/fontsize.gif" border="0" alt="font size"></a>
<a href="Javascript:setsmiley2('[align=left]text[/align]');"><img src="img/fontleft.gif" border="0" alt="Font alignment"></a><br>
<a href="Javascript:setsmiley2('[tt]text[/tt]');"><img src="img/tele.gif" border="0" alt="Teletype"></a>
<a href="Javascript:setsmiley2('[hr]');"><img src="img/hr.gif" border="0" alt="Horizontal Line"></a>
<a href="Javascript:setsmiley2('[move]STUFF[/move]');"><img src="img/move.gif" border="0" alt="Move"></a>
<a href="Javascript:setsmiley2('[quote]text[/quote]');"><img src="img/quote2.gif" border="0" alt="Quote"></a><br>
<a href="Javascript:setsmiley2('[flash=200,200]URL[/flash]');"><img src="img/flash.gif" border="0" alt="Flash Image"></a>
<a href="Javascript:setsmiley2('[img]URL[/img]');"><img src="img/img.gif" border="0" alt="Image"></a>
<a href="Javascript:setsmiley2('[email=mailto:username@site.com]Mail Meg![/email]');"><img src="img/email2.gif" border="0" alt="E-mail link"></a>
<a href="Javascript:setsmiley2('[url=http://www.url.com]address[/url]');"><img src="img/url.gif" border="0" alt="hyperlink"></a><br>
<a href="Javascript:setsmiley2('[list][*]text1[*]text2[*]text3[/list]');"><img src="img/list.gif" border="0" alt="List"></a>
</td>
<td width=390 valign="top" align="left"><textarea class="post" name="fullnews" rows="15" cols="80" ONSELECT="javascript:storeCaret(this);" ONCLICK="javascript:storeCaret(this);" ONKEYUP="javascript:storeCaret(this);" ONCHANGE="javascript:storeCaret(this);">$fnewsm</textarea></td>
</tr>
<tr>
<td width=110 valign="top" align="left">&nbsp;</td>
<td width=390 valign="top" align="left">$lang_delete <input type="checkbox" class="post" value="1" name="del"><br>
<br>
<input type="submit" class="mainoption" value="submit">
<input type="submit" class="mainoption" value="Preview" onClick="Preview()"><br>
<br>
</tr>
<br></td>
</tr>
</form>
</table>
</form>
html;
}
}
}
else{
header("Location: ./");
}
}

//---
if($id == "post"){
  if(!$subject or !$news){
    $title = $langt_bad;
    $content = $lang_errorpost;
  }else{
    //set cookie
    setcookie("fusionmail", $email, time()+43200);
    setcookie("fusionicon", $icon, time()+43200);
    // make random num.. super rand!!
    mt_srand((double)microtime()*1000000);
    $random = mt_rand();
    //date
    $date = (date($datefor));
    //replace slashes
    $news1 = ereg_replace("\\\'", "'", $news);
    $news2 = ereg_replace('\\\"', "\"", $news1);
    $news3 = ereg_replace("\n", "<br />", $news2);

    $fnews1 = ereg_replace("\\\'", "'", $fullnews);
    $fnews2 = ereg_replace('\\\"', "\"", $fnews1);
    $fnews3 = ereg_replace("\n", "<br />", $fnews2);

    $sub1 = ereg_replace('\\\"', "\"", $subject);
    $sub2 = ereg_replace("\\\'", "'", $sub1);

    //bbcode
    if($bb == "checked"){
      $newsm = InsertBBCode($news3);
      $fnewsm = InsertBBCode($fnews3);
    }else{
      $newsm = $news3;
      $fnewsm = $fnews3;
    }
    if($smilies == "checked"){
      $newsm = InsertSmillies($newsm,$furl);
      $fnewsm = InsertSmillies($fnewsm,$furl);
    }
    //html
    if($ht != "checked"){
       $newsm = strip_tags($newsm);
       $fnewsm = strip_tags($fnewsm);
    }
    //info
    $pagem = $dfile;
    $fpm = fopen($pagem,r);
    $currentm = fread($fpm, filesize($pagem));
    fclose($fpm);

    $info = "$newsm|<|$fnewsm|<|$user|<|$sub2|<|$email|<|$icon|<|$date|<|$random|<|\n$currentm";
    $dafile = fopen($dfile,"r+");
    fputs($dafile,$info);
    fclose($dafile);
    // build ----------
    $cont = "";
    $cont1 = "";
    $cont2 = "";
    $contb = "";
    $contdat = "";
    $b = 1;
    $file = file($dfile);
    while(list(,$value) = each($file)){
         list($newsm1,$fullnewsm,$userm,$subm,$emailm,$iconm,$datem,$rand) = explode("|<|", $value);
         if($fullnewsm == ""){
           $fullnewsl = "";
         }else{
         if($fsnw == "checked") {
           $fullnewsl = "<br><a href='#' onClick=window.open(\"$fullnewsurl?id=$rand\",\"\",\"height=$fullnewsh,width=$fullnewsw,toolbar=no,menubar=no,scrollbars=$fullnewss2,resizable=no\")>$fs</a>";
         } else{
           $fullnewsl = "<br><a href=\"$fullnewsurl?id=$rand\">$fs</a>";
         }
         }
         //use icon?
         if($iconm == ""){
           $icon1 = "";
         }else{
           $icon1 = "<img src=\"$iconm\">";
         }
         //replace user variables
         $tem = str_replace("{subject}", $subm, $temp);
         $tem = str_replace("{user}", "<a href=\"mailto:$emailm\">$userm</a>", $tem);
         $tem = str_replace("{date}", $datem, $tem);
         $tem = str_replace("{news}", "$newsm1 $fullnewsl\n", $tem);
         $tem = str_replace("{icon}", $icon1, $tem);
         $tem = str_replace("{send}", "<a href='#' onClick=window.open(\"$sflink?id=$rand\",\"\",\"height=400,width=400,toolbar=no,menubar=no,scrollbars=no,resizable=no\")>$sf</a>", $tem);
         $subject = str_replace(" ", "%20", $subm);
         if($compop == "checked") {
           $tem = str_replace("{viewc}", "<a href='#' onClick=window.open(\"$furl/comments.php?mid=view&id=$subject\",\"\",\"height=$comheight,width=$comwidth,toolbar=no,menubar=no,scrollbars=yes,resizable=$comresize2\")>view</a>", $tem);
         }else{
         $tem = str_replace("{viewc}", "<a href=\"$furl/comments.php?mid=view&id=$subject\">view</a>", $tem);
         }
         if($comformpop == "checked") {
           $tem = str_replace("{postc}", "<a href='#' onClick=window.open(\"$furl/comments.php?id=$subject\",\"\",\"height=400,width=400,toolbar=no,menubar=no,scrollbars=no,resizable=no\")>post</a>", $tem);
         }else{
           $tem = str_replace("{postc}", "<a href=\"$furl/comments.php?id=$subject\">post</a>", $tem);
         }
         //replace user variables
         $ftem = str_replace("{subject}", $subm, $ftemp);
         $ftem = str_replace("{user}", "<a href=\"mailto:$emailm\">$userm</a>", $ftem);
         $ftem = str_replace("{date}", $datem, $ftem);
         $ftem = str_replace("{news}", $fullnewsm, $ftem);
         $ftem = str_replace("{icon}", $icon1, $ftem);
         $ftem = str_replace("{send}", "<a href='#' onClick=window.open(\"$sflink?id=$rand\",\"\",\"height=400,width=400,toolbar=no,menubar=no,scrollbars=no,resizable=no\")>$sf</a>", $ftem);
         if($b <= $numofposts){
           //what to write
           $cont  .= "<!--fusion $curve--><a name=\"$rand\">$tem\n";
           $cont1 .= "<?php if(\$id == \"$rand\"){?> $header $ftem<br> $footer <?php }?>";
           $cont2 .= "<a href=\"$hurl#$rand\">$subm</a><br>\n";
           $contdat .= "$newsm1|<|$fullnewsm|<|$userm|<|$subm|<|$emailm|<|$iconm|<|$datem|<|$rand|<|\n";
         }else{
           $contb .= "$newsm1|<|$fullnewsm|<|$userm|<|$subm|<|$emailm|<|$iconm|<|$datem|<|$rand|<|\n";
         }
         $b++;
    }
    $newsp = fopen($newsfile,w);
    fputs($newsp,$cont);
    fclose($newsp);

    $fnewsf = fopen($fnewsfile,w);
    fputs($fnewsf,$cont1);
    fclose($fnewsf);

    $hfile = fopen($headlines,w);
    fputs($hfile,$cont2);
    fclose($hfile);

    $dafile = fopen($dfile,w);
    fputs($dafile,$contdat);
    fclose($dafile);

    $af = fopen($arc,a);
    fputs($af,$contb);
    fclose($af);
    buildarchivereader();

    $title = $langt_posted;
    $content = $lang_posted;
  }
}

//-----------------
//edit it
if($id == "editposts3"){
if(!$subject or !$news){
$title = $langt_bad;
$content = "Your subject and news must be filled in.";
}
else{
$file = file($dfile);
while(list(,$value) = each($file)){
list($news1,$fnews1,$user1,$sub1,$email1,$icon1,$date1,$rand1) = explode("|<|", $value);
if($num == $rand1){
if($user1 != $fusionuser && !isset($HTTP_COOKIE_VARS["fusionadmin"]) && !isset($HTTP_COOKIE_VARS["fusionedit"])){
$title = $langt_bad;
$content = $lang_noedit;
}
else{

//replace \" and \' with " and '
$newsm = ereg_replace("\\\'", "'", $news);
$newsm = ereg_replace('\\\"', "\"", $newsm);
$news3 = ereg_replace("\n", "<br />", $newsm);

$fnewsm = ereg_replace("\\\'", "'", $fullnews);
$fnewsm = ereg_replace('\\\"', "\"", $fnewsm);
$fnews3 = ereg_replace("\n", "<br />", $fnewsm);

$subm = ereg_replace('\\\"', "\"", $subject);
$subm  = ereg_replace("\\\'", "'", $subm);

//bbcode
if($bb == "checked"){
$newsm = InsertBBCode($news3);
$fnewsm = InsertBBCode($fnews3);
} else {
$newsm = $news3;
$fnewsm = $fnews3;
}

if($smilies == "checked"){
$newsm = InsertSmillies($newsm,$furl);
$fnewsm = InsertSmillies($fnewsm,$furl);
}

//html
if($ht != "checked"){
$newsm = strip_tags($newsm);
$fnewsm = strip_tags($fnewsm);
}

$file = file($dfile);
while(list(,$value) = each($file)){
list($news1,$fnews1,$user1,$sub1,$email1,$icon1,$date1,$rand1) = explode("|<|", $value);

if($num == $rand1){
if($del == 1){
$old = "$news1|<|$fnews1|<|$user1|<|$sub1|<|$email1|<|$icon1|<|$date1|<|$rand1|<|\n";
$new = "";
}
else{
$old = "$news1|<|$fnews1|<|$user1|<|$sub1|<|$email1|<|$icon1|<|$date1|<|$rand1|<|";
$new = "$newsm|<|$fnewsm|<|$name|<|$subm|<|$email|<|$icon|<|$date|<|$num|<|";
}
$fpm = fopen($dfile,r);
$dat = fread($fpm, filesize($dfile));
fclose($fpm);
$data = str_replace($old, $new, $dat);

$dafile = fopen($dfile,w);
fputs($dafile, $data);
fclose($dafile);
}
}

// build ----------

$cont = "";
$cont1 = "";
$cont2 = "";
$file = file($dfile);
while(list(,$value) = each($file)){
list($newsg,$fnewsg,$userg,$subg,$emailg,$icong,$dateg,$randg) = explode("|<|", $value);
$newsg = ereg_replace("\n", "<br />", $newsg);
$fnewsg = ereg_replace("\n", "<br />", $fnewsg);
if($fnewsg == ""){
$fullnewsl = "";
}
else{
if($fsnw == "checked") {
$fullnewsl = "<a href='#' onClick=window.open(\"$fullnewsurl?id=$randg\",\"\",\"height=$fullnewsh,width=$fullnewsw,toolbar=no,menubar=no,scrollbars=$fullnewss2,resizable=$fullnewsz2\")>$fs</a>";
} else{
$fullnewsl = "<a href=\"$fullnewsurl?id=$randg\">$fs</a>";
}
}
if($icong == ""){
$icon1 = "";
}
else{
$icon1 = "<img src=\"$icong\">";
}

//replace user variables
$tem = str_replace("{subject}", $subg, $temp);
$tem = str_replace("{user}", "<a href=\"mailto:$emailg\">$userg</a>", $tem);
$tem = str_replace("{date}", $dateg, $tem);
$tem = str_replace("{news}", "$newsg $fullnewsl\n", $tem);
$tem = str_replace("{icon}", $icon1, $tem);
$tem = str_replace("{send}", "<a href='#' onClick=window.open(\"$sflink?id=$randg\",\"\",\"height=400,width=400,toolbar=no,menubar=no,scrollbars=no,resizable=no\")>$sf</a>", $tem);
$subject = str_replace(" ", "%20", $subg);
if ($compop == "checked") {
$tem = str_replace("{viewc}", "<a href='#' onClick=window.open(\"$furl/comments.php?mid=view&id=$subject\",\"\",\"height=$comheight,width=$comwidth,toolbar=no,menubar=no,scrollbars=yes,resizable=$comresize2\")>view</a>", $tem);
} else {
$tem = str_replace("{viewc}", "<a href=\"$furl/comments.php?mid=view&id=$subject\">view</a>", $tem);
}
if ($comformpop == "checked") {
$tem = str_replace("{postc}", "<a href='#' onClick=window.open(\"$furl/comments.php?id=$subject\",\"\",\"height=400,width=400,toolbar=no,menubar=no,scrollbars=no,resizable=no\")>post</a>", $tem);
} else {
$tem = str_replace("{postc}", "<a href=\"$furl/comments.php?id=$subject\">post</a>", $tem);
}

//replace user variables
$ftem = str_replace("{subject}", $subg, $ftemp);
$ftem = str_replace("{user}", "<a href=\"mailto:$emailg\">$userg</a>", $ftem);
$ftem = str_replace("{date}", $dateg, $ftem);
$ftem = str_replace("{news}", $fnewsg, $ftem);
$ftem = str_replace("{icon}", $icon1, $ftem);
$ftem = str_replace("{send}", "<a href='#' onClick=window.open(\"$sflink?id=$randg\",\"\",\"height=400,width=400,toolbar=no,menubar=no,scrollbars=no,resizable=no\")>$sf</a>", $ftem);

//what to write
$cont .= "<!--fusion $curve--><a name=\"$randg\">$tem\n";

$cont1 .= "<?php
if(\$id == \"$randg\"){?>
$header
$ftem<br>
$footer
<?php
}
?>";

$cont2 .= "<!--generated by fusion--><a href=\"$hurl#$randg\">$subg</a><br>\n";
}

$newsp = fopen($newsfile,w);
fputs($newsp,$cont);
fclose($newsp);

$fnewsf = fopen($fnewsfile,w);
fputs($fnewsf,$cont1);
fclose($fnewsf);

$hfile = fopen($headlines,w);
fputs($hfile,$cont2);
fclose($hfile);

//news posted

$title = $langt_edited;
$content = $lang_edited;
}
}
}
}
}

if($id == "build"){
//quick build

$cont = "";
$cont1 = "";
$cont2 = "";
$file = file($dfile);
while(list(,$value) = each($file)){
list($newsg,$fnewsg,$userg,$subg,$emailg,$icong,$dateg,$randg) = explode("|<|", $value);
if($fnewsg == ""){
$fullnewsl = "";
}else{
if($fsnw == "checked") {
$fullnewsl = "<a href='#' onClick=window.open(\"$fullnewsurl?id=$randg\",\"\",\"height=$fullnewsh,width=$fullnewsw,toolbar=no,menubar=no,scrollbars=$fullnewss2,resizable=$fullnewsz2\")>$fs</a>";
} else{
$fullnewsl = "<a href=\"$fullnewsurl?id=$randg\">$fs</a>";
}
}
if($icong != ""){
$icon1 = "<img src=\"$icong\">";
}
//replace user variables
$tem = str_replace("{subject}", $subg, $temp);
$tem = str_replace("{user}", "<a href=\"mailto:$emailg\">$userg</a>", $tem);
$tem = str_replace("{date}", $dateg, $tem);
$tem = str_replace("{news}", "$newsg $fullnewsl\n", $tem);
$tem = str_replace("{icon}", $icon1, $tem);
$tem = str_replace("{send}", "<a href='#' onClick=window.open(\"$sflink?id=$randg\",\"\",\"height=400,width=400,toolbar=no,menubar=no,scrollbars=no,resizable=no\")>$sf</a>", $tem);
$subject = str_replace(" ", "%20", $subg);
if ($compop == "checked") {
$tem = str_replace("{viewc}", "<a href='#' onClick=window.open(\"$furl/comments.php?mid=view&id=$subject\",\"\",\"height=$comheight,width=$comwidth,toolbar=no,menubar=no,scrollbars=yes,resizable=$comresize2\")>view</a>", $tem);
} else {
$tem = str_replace("{viewc}", "<a href=\"$furl/comments.php?mid=view&id=$subject\">view</a>", $tem);
}
if ($comformpop == "checked") {
$tem = str_replace("{postc}", "<a href='#' onClick=window.open(\"$furl/comments.php?id=$subject\",\"\",\"height=400,width=400,toolbar=no,menubar=no,scrollbars=no,resizable=no\")>post</a>", $tem);
} else {
$tem = str_replace("{postc}", "<a href=\"$furl/comments.php?id=$subject\">post</a>", $tem);
}
//replace user variables
$ftem = str_replace("{subject}", $subg, $ftemp);
$ftem = str_replace("{user}", "<a href=\"mailto:$emailg\">$userg</a>", $ftem);
$ftem = str_replace("{date}", $dateg, $ftem);
$ftem = str_replace("{news}", $fnewsg, $ftem);
$ftem = str_replace("{icon}", $icon1, $ftem);
$ftem = str_replace("{send}", "<a href='#' onClick=window.open(\"$sflink?id=$randg\",\"\",\"height=400,width=400,toolbar=no,menubar=no,scrollbars=no,resizable=no\")>$sf</a>", $ftem);
$cont .= "<!--fusion $curve--><a name=\"$randg\">$tem\n";

$cont1 .= "<?php
if(\$id == \"$randg\"){?>
$header
$ftem
$footer
<?php
}
?>";

$cont2 .= "<!--generated by fusion--><a href=\"$hurl#$randg\">$subg</a><br>\n";
}

$newsp = fopen($newsfile,w);
fputs($newsp,$cont);
fclose($newsp);

$fnewsf = fopen($fnewsfile,w);
fputs($fnewsf,$cont1);
fclose($fnewsf);

$hfile = fopen($headlines,w);
fputs($hfile,$cont2);
fclose($hfile);

buildarchivereader();

$title = $langt_build;
$content = $lang_build;
}

//-----------------

// log out.. delete all cookies
if($id == "logout") {
//delete cookie
setcookie("fusion", "", time()-11);
setcookie("fusionuser", "", time()-11);
setcookie("fusionedit", "", time()-11);
setcookie("fusionmail", "", time()-11);
setcookie("fusionicon", "", time()-11);
setcookie("fusionadmin", "", time()-11);

header("Location: ./");
}

// this is the skin stuff.. darn that's a lot

if(isset($HTTP_COOKIE_VARS["fusion"])){
$logout1 = "<a href=\"?id=logout\">$lang_logout</a>";
$logout2 = "<a href=\"?id=logout\"><img src=\"./$skin/logout.gif\" border=0 alt=\"$lang_logout\"></a>";
}else{
$logout1 = "<a href=\"\">$lang_login</a>";
$logout2 = "<a href=\"\"><img src=\"./$skin/login.gif\" border=0 alt=\"$lang_login\"></a>";
}
if(isset($fusionadmin)){
$l = $lang_admin_skinl;
$lb = $lang_admin_skinl2;
}
$links = <<< html
<a href="">main</a> | <a href="?id=postnews&action=">$lang_postnews</a> | <a href="?id=editposts">$lang_editps</a> | $l $logout1
html;
$linksb = <<< html
<a href="">main</a><br>
<a href="?id=postnews&action=">$lang_postnews</a><br>
<a href="?id=editposts">$lang_editps</a><br>
$lb<br>
$logout1
html;
if(isset($fusionadmin)){
$icon1 = <<< html
<a href="?id=admin"><img src="./$skin/admin.gif" border=0 alt="admin"></a>
<a href="?id=header"><img src="./$skin/header.gif" border=0 alt="edit header/footer"></a>
<a href="?id=arctemplate"><img src="./$skin/template.gif" border=0 alt="edit archive templates"></a>
<a href="?id=template"><img src="./$skin/template.gif" border=0 alt="edit templates"></a>
<a href="?id=headercom"><img src="./$skin/header.gif" border=0 alt="edit header comments"></a>
<a href="?id=add"><img src="./$skin/adduser.gif" border=0 alt="add user"></a>
<a href="?id=user"><img src="./$skin/editusers.gif" border=0 alt="edit users"></a>
<a href="?id=build"><img src="./$skin/build.gif" border=0 alt="build news"></a>
html;
}
$icon = <<< html
<a href=""><img src="./$skin/main.gif" border=0 alt="main"></a>
<a href="?id=postnews&action="><img src="./$skin/post.gif" border=0 alt="post news"></a>
<a href="?id=editposts"><img src="./$skin/edit.gif" border=0 alt="edit posts"></a>
$icon1
$logout2
html;

//open skin
if(file_exists("./$skin/index.php")){
$cs1 = implode(" ", file("./$skin/index.php"));
}elseif(file_exists("./$skin/index.htm")){
$cs1 = implode(" ", file("./$skin/index.htm"));
}elseif(file_exists("./$skin/index.txt")){
$cs1 = implode(" ", file("./$skin/index.txt"));
}elseif(file_exists("./$skin/skin.php")){
$cs1 = implode(" ", file("./$skin/skin.php"));
}elseif(file_exists("./$skin/skin.html")){
$cs1 = implode(" ", file("./$skin/skin.html"));
}elseif(file_exists("./$skin/skin.htm")){
$cs1 = implode(" ", file("./$skin/skin.htm"));
}elseif(file_exists("./$skin/skin.txt")){
$cs1 = implode(" ", file("./$skin/skin.txt"));
}else{
$cs1 = implode(" ", file("./$skin/index.html"));
}
$cs = str_replace("{main}", $content, $cs1);
$cs = str_replace("{title}", $title, $cs);
$cs = str_replace("{icons}", $icon, $cs);
$cs = str_replace("{linksn}", $links, $cs);
$cs = str_replace("{linksb}", $linksb, $cs);
echo $cs;

// woohoo!!!! fusion is back!! until 4.0. have fun hacking it d=

?>
