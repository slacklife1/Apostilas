Go to

http://www.fusionphp.com/readme.php

for updated readme files

