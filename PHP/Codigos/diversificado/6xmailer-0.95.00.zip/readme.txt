=============================================================================
6XMailer - A PHP POP3 mail reader.
Copyright (C) 2001  6XGate Systems, Inc.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==============================================================================

These scripts in this zip file or tarball are only at the BETA stage of production and have
not been fully tested in a production environment.

The documents and user's manual are located in the documents directory.

NOTE: You must check the configuration file to make sure that the mailer will work with your
system, if not, problems may occur.

Please refer to the install.txt file for requirements, installation instructions, and
configuration information.  ALWAYS!!!  Since this script is im BETA, these instructions
will change.

If anyone would like to help me with coding, documentation, or any other aspect of this
mailer such as themes or language packs, then goto www.sixxgate.da.ru and e-mail me at the
e-mail address under the Contacting Us page.
