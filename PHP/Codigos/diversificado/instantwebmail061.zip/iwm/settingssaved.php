<?php
$language = "English";
$adminUsername = "username";
$adminPassword = "password";
$preset["host"] = array();
$preset["port"] = array();
$preset["username"] = array();
$colsOrRows = "cols";
$frameSizeHeaderList = "50";
$formatText = true;
$theme = "Dark";
$title = "Instant Web Mail";
$footer = "";
$logInHeader = "<div style=\'margin-top: -10px; margin-left: -10px\'><a href=\'http://instantwebmail.sourceforge.net/\'><img src=\'images/instantwebmail.jpeg\' height=\'87\' width=\'514\' alt=\'Instant Web Mail\'/></a></div><br/><br/><br/><br/>";
$logInFooter = "";
?>