<?php
$l1 = "B��d!!!";
$l2 = "&lt;&lt;&lt; Wr��";
$l3 = "Program nie m�g� pol�czyc si� z serverem POP . Tu jest opis b��du:";
$l4 = "Program nie m�g� si� zalogowac na serverze POP - przypuszczalnie z�e has�o lub login";
$l5 = "OK";
$l6 = "Zaloguj si�";
$l7 = " Has�o:";
$l8 = "Nazwa u�ytkownika:";
$l9 = "Port serwera POP :";
$l10 = "Nazwa serwera POP :";
$l11 = "Nie ma wiadomo�ci w skrzynce.";
$l12 = "Program nie m�g� uruchomi� komendy TOP .";
$l13 = "[Bez tytu�u]";
$l15 = "Nie mo�na za�adowa� wiadomo�ci #$id.";
$l16 = "Wysy�aj�cy:";
$l17 = "Adresat:";
$l18 = "Data:";
$l19 = "Organizacja:";
$l20 = "Program pocztowy:";
$l21 = "Odpowiedz do:";
$l22 = "Nag��wki";
$l23 = "Prze�lij te� do:";
$l24 = "Odpowiedz";
$l25 = "Prze�lij";
$l26 = "Skasuj";
$l27 = "Odpowiedz wszystkim";
$l28 = "Drukuj";
$l29 = "Poka� �r�d�o";
$l30 = "J�zyk:";
$l31 = "Czy na pewno chcesz skasowa� zaznaczone wiadomo�ci?";
$l32 = "Wiadomo�� #$id nie mo�e by� skasowana.";
$l33 = "Nowa wiadomo��";
$l34 = "Od�wie�";
$l35 = "[Nieznana nazwa pliku]";
$l36 = "Temat";
$l37 = "Od:";
$l38 = "Do:";
$l39 = "A tak�e do:";
$l40 = "Do wiadomo�ci tak�e:";
$l41 = "Za��cznik:";
$l42 = "Wy�lij jako HTML";
$l43 = "Wy�lij";
$l44 = "Jeste� pewien, �e chcesz wys�a� wiadomo�� ?";
# Do not translate [date] and [sender]. Think of them as variables. The
# string will be transformed into e.g. "On 08-08-2001 12:42, John Doe
# <doe@example.com> wrote":
$l45 = "Dnia [date], [sender] napisa�(a):";
$l46 = "Przekazana wiadomo��";
$l47 = "ty�";
$l48 = "Nie zapomnij wpisa� w�a�ciwego adresu.";
$l49 = "Nie zapomnij wpisac w�a�ciwego adresu odbiorcy.";
# The character set corresponding to your language:
$l50 = "ISO-8859-2";
$l51 = "Program nie m�g� odczyta� za��cznik�w. Spowodowane to by�o przypuszczalnie z�ymi prawami dost�pu.Prosz� si� skontaktowa� z administatorem.";
$l52 = "Wyloguj si�";
$l53 = "Licencja: <a href='license.txt' target='_blank'>GNU General Public License</a>";
$l54 = "O programie";
$l55 = "Ustaw serwer POP :";
$l56 = "Ustaw port serwera POP :";
$l57 = "Ustaw login u�ytkownika POP :";
$l58 = "Podziel ramki";
$l59 = "Pionowo";
$l60 = "Poziomo";
$l61 = "Ustawienia";
$l62 = "Zapisz ustawienia";
$l63 = "Procentowy podzia� nag��wka wiadomo�ci:";
$l64 = "Procentowy podzia� ramki wiadomo�ci:";
$l65 = "Stopka ( wszystkie strony):";
$l66 = "Logowanie w nag��wku strony:";
$l67 = "Logowanie w stopce strony";
$l68 = "Tytu� wywietlany w pasku tytu�owym:";
$l69 = "Program nie ma uprawnie� do zapisu w pliku settingssaved.php. Plik musi byc ustawiony na chmod 666.";
$l70 = "Ustawienia zosta�y zapisane.";
$l71 = "Zachowaj stare has�o";
$l72 = "Nowe has�o:";
$l73 = "Has�o do strony administratora:";
$l74 = "Login do strony administratora:";
$l75 = "Dost�p zabroniony.";
$l76 = "%s automatyczne sprawdzanie";
$l77 = "W��cz";
$l78 = "Wy��cz";
$l79 = "Co ile minut sprawdza� skrzynk�?:";
$l80 = "Jeste� pewien, �e chcesz sie wylogowac?";
$l81 = "Temat:";
$l82 = "<a href='readme.html' target='_blank'>Obejrzyj plik readme</a>";
$l83 = "Wiadomo�� tekstowa:";
$l84 = "Tak";
$l85 = "Nie";
$l86 = "Zapytaj o odbiorc�";
$l87 = "Wa�no��:";
$l88 = "Wysoka";
$l89 = "Normalna";
$l90 = "Niska";
$l91 = "Najwy�sza";
$l92 = "Najni�sza";
$l93 = "Ta opcja w��cza lub wy��cza formatowanie tekstu. Je�li ja w��czysz , tekstowe wiadomo�ci b�da formatowane w taki spos�b, �e *bold* b�dzie konwertowane na <b>bold</b>, /italic/ konwertowane na <i>italic</i>, a_podkre�lenie_bedzie _ konwertowane do <u>underlined</u>.";
$l94 = "Pomoc";
$l95 = "Zamknij";
$l96 = "Je�li chcesz by u�ytkownicy tego programu korzystali z jednego serwera POP lub ma�ej liczby predefiniowanych serwer�w POP , zapisz list� tych serwer�w oddzielon� przecinkami oraz spacj�: <i>mail1.jaki�.serwer.com, mail2.jaki�.serwer.com, mail3.jaki�.serwer.com.pl</i>";
$l97 = "Wpisz jeden lub wi�cej port�w oddzielonych przecinkami i spacj�, np. <i>110, 111</i>.";
$l98 = "Wpisz jedno lub wi�cej kont POP oddzielonych przecinkami i spacj�, np. <i>u�ytkownik1, u�ytkownik2</i>.";
$l99 = "Tw�j adres @-mail:";
$l100 = "Nie zaznaczy�e� �adnej wiadomo�ci do skasowania.";
$l101 = "Jeste� pewien, �e chcesz skasowa� wszystkie zaznaczone wiadomo�ci?";
$l102 = "(Od)znacz wszystkie";
$l103 = "Powt�rz has�o";
$l104 = "Has�a, kt�re wpisa�e� nie s� takie same.";



function l14($timeStamp) {
	return date("m-d-Y h:i a", $timeStamp);
}
?>