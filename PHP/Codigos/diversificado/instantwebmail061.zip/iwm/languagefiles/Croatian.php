<?php
$l1 = "Greka";
$l2 = "&lt;&lt;&lt; Natrag";
$l3 = "Nemogu se konektirati na POP server. Poruka o greci:";
$l4 = "Nemogu se konektirati na POP server. Vjerojatno ste upisali krivi nadimak i/ili lozinku.";
$l5 = "OK";
$l6 = "Ulaz";
$l7 = "Lozinka";
$l8 = "Nadimak (na pr. orbis, orb012 ..):";
$l9 = "Port:";
$l10 = "POP3 server";
$l11 = "Trenutno nemate nijedne E-mail poruke.";
$l12 = "Program nemoe pokrenuti TOP naredbu.";
$l13 = "[No subject]";
$l15 = "Nemogu otvoriti poruku #$id.";
$l16 = "Poiljatelj:";
$l17 = "Primatelj:";
$l18 = "Datum:";
$l19 = "Organizacija:";
$l20 = "Mail client:";
$l21 = "Odgovor:";
$l22 = "Zaglavlje";
$l23 = "alji i na adrese:";
$l24 = "Odgovori";
$l25 = "Proslijedi";
$l26 = "Brii";
$l27 = "Odgovori svima";
$l28 = "Printaj";
$l29 = "Pokai kod";
$l30 = "Jezik:";
$l31 = "Jeste li sigurni da elite obrisati ozna�ene poruke?";
$l32 = "Poruka #$id nemoe biti obrisana.";
$l33 = "Nova poruka";
$l34 = "Osvjei";
$l35 = "[Unknown file name]";
$l36 = "Subjekt:";
$l37 = "Od:";
$l38 = "Primatelj:";
$l39 = "Viestruko slanje:";
$l40 = "Tajno viestruko slanje:";
$l41 = "Priloene datoteke:";
$l42 = "Poalji kao HTML";
$l43 = "Poalji";
$l44 = "Jeste li sigurni da poruku elite odmah poslati ?";
# Do not translate [date] and [sender]. Think of them as variables. The
# string will be transformed into e.g. "On 08-08-2001 12:42, John Doe
# <doe@example.com> wrote":
$l45 = "Na [date], [sender] je napisao:";
$l46 = "Proslije�ena poruka";
$l47 = "ti";
$l48 = "Ne zaboravite unijeti to�nu E-mail adresu poiljatelja.";
$l49 = "Ne zaboravite unijeti to�nu E-mail adresu primatelja.";
# The character set corresponding to your language:
$l50 = "windows-1250";
$l51 = "Nemogu otvoriti i pro�itati priloenu datoteku. Vjerojatno je problem u pravima na direktoriju. Kontaktirajte sistem administratora.";
$l52 = "Izlaz";
$l53 = "Licenca: <a href='license.txt' target='_blank'>GNU General Public License</a>";
$l54 = "O programu";
$l55 = "Odre�eni POP server:";
$l56 = "Odre�eni POP server port:";
$l57 = "Odre�eni POP username:";
$l58 = "Podijeli prozor";
$l59 = "Okomito";
$l60 = "Vodoravno";
$l61 = "Postavke";
$l62 = "Snimi promjene";
$l63 = "Postotak za veli�ini zaglavlja:";
$l64 = "Postotak za veli�inu tijela poruke:";
$l65 = "Dno prozora (za sve stranice):";
$l66 = "Log-in page header:";
$l67 = "Log-in page footer:";
$l68 = "Naslov stranice:";
$l69 = "Program nema ovlasti pisati u settingssaved.php. Program mora biti prilagodjen kao chmod 666.";
$l70 = "Promjene su snimljene.";
$l71 = "Zadri staru lozinku";
$l72 = "Nova lozinka:";
$l73 = "Lozinka za administraciju:";
$l74 = "Nadimak za administraciju:";
$l75 = "Niste autorizirani.";
$l76 = "%s automatska provjera";
$l77 = "Uklju�eno";
$l78 = "Isklju�eno";
$l79 = "Broj minuta prije ponovne provjere:";
$l80 = "Jeste li sigurni da elite iza�i?";
$l81 = "Izgled:";
$l82 = "<a href='readme.html' target='_blank'>Vidi Readme datoteku</a>";
$l83 = "Formatirani tekst:";
$l84 = "Da";
$l85 = "Ne";
$l86 = "Trai poruku primatelja o prispje�u";
$l87 = "Prioritet:";
$l88 = "Visoko";
$l89 = "Normalno";
$l90 = "Malo";
$l91 = "Najve�e";
$l92 = "Najmanje";
$l93 = "This setting turns formatted message text on or off. If you turn it on, plain text messages will be formatted in such a way that *bold* gets converted to <b>bold</b>, /italic/ gets converted to <i>italic</i>, and _underlined_ gets converted to <u>underlined</u>.";
$l94 = "Pomo�";
$l95 = "Zatvori";
$l96 = "If you want to limit the users of this program to only using one POP server or a small number of predefined POP servers, write a list of those servers separated by a comma and a space: <i>mail1.example.com, mail2.example.com, mail3.example.com</i>";
$l97 = "Unesite jedan ili vie portova odvojenih zarezom, na primjer <i>110, 111</i>.";
$l98 = "Unesite jedan ili vie nadimaka odvojenih zarezom, na primjer <i>user1, user2</i>.";
$l99 = "Vaa E-mail adresa:";
$l100 = "Niste izabrali ni jednu poruku za brisanje.";
$l101 = "Jeste li sigurni da elite obrisati izabrane poruke?";
$l102 = "(Od)izaberi sve";
$l103 = "Ponovi lozinku";
$l104 = "Lozinke nisu identi�ne.";



function l14($timeStamp) {
	return date("m-d-Y h:i a", $timeStamp);
}
?>