<?php
$l1 = "Ocorreu um erro";
$l2 = "&lt;&lt;&lt; Voltar";
$l3 = "O programa n�o consegui establecer liga��o com o servidor de POP3. Esta foi a mensagem de erro:";
$l4 = "O programa nao consegui registar-se no servidor de POP3. Provavelmente o seu utilizador ou password est�o errados.";
$l5 = "OK";
$l6 = "Log in";
$l7 = "Password do servidor POP:";
$l8 = "Utilizador do servidor POP:";
$l9 = "Porto do servidor POP:";
$l10 = "Nome do servidor POP:";
$l11 = "N�o existem mensagens na sua mailbox.";
$l12 = "Este programa n�o conseguiu executar o comando TOP.";
$l13 = "[Sem assunto]";
$l15 = "O programa falhou a obter a mensagem #$id.";
$l16 = "Remetente:";
$l17 = "Destinat�rio:";
$l18 = "Data:";
$l19 = "Organiza��o:";
$l20 = "Cliente de Mail:";
$l21 = "Responder a:";
$l22 = "Cabe�alhos";
$l23 = "Carbon copy:";
$l24 = "Responder";
$l25 = "Reencaminhar";
$l26 = "Apagar";
$l27 = "Responder a todos";
$l28 = "Imprimir";
$l29 = "Ver mensagem";
$l30 = "Lingua:";
$l31 = "Tem certeza que deseja apagar a mensagem seleccionada?";
$l32 = "A Messagem #$id n�o pode ser removida.";
$l33 = "Nova mensagem";
$l34 = "Actualizar";
$l35 = "[Nome de ficheiro desconhecido]";
$l36 = "Assunto:";
$l37 = "De:";
$l38 = "Para:";
$l39 = "C�pia:";
$l40 = "BCC:";
$l41 = "Ficheiro em anexo:";
$l42 = "Enviar como HTML";
$l43 = "Enviar";
$l44 = "Tem certeza que pretende enviar a mensagem agora?";
# Do not translate [date] and [sender]. Think of them as variables. The
# string will be transformed into e.g. "On 08-08-2001 12:42, John Doe
# <doe@example.com> wrote":
$l45 = "Em [date], [sender] escreveu:";
$l46 = "Mensagem reencaminhada";
$l47 = "vo�e";
$l48 = "N�o esque�a de colocar um endere�o v�lido de envio.";
$l49 = "N�o esque�a de colocar um endere�o v�lido de recep��o.";
# The character set corresponding to your language:
$l50 = "ISO-8859-1";
$l51 = "Este programa n�o foi capaz de ler um dos ficheiros em anexo. Isto deve-se provavelmente a permiss�es erradas na directoria de upload. Contacte o administrador de sistema.";
$l52 = "Log out";
$l53 = "Licen�a: <a href='license.txt' target='_blank'>GNU General Public License</a>";
$l54 = "Acerca de";
$l55 = "Servidor POP pr�-definido:";
$l56 = "Porto de servidor POP pr�-definido:";
$l57 = "Utilizador de servidor POP pr�-definido:";
$l58 = "Dividir frames";
$l59 = "Verticalmente";
$l60 = "Horizontalmente";
$l61 = "Defini��es";
$l62 = "Guardar defini��es";
$l63 = "Percentagem no frame de caixa de mensagens:";
$l64 = "Percentagem no frame de mensagens:";
$l65 = "Rodap� (todas as p�ginas):";
$l66 = "Cabecalho da p�gina de login:";
$l67 = "Rodap� da p�gina de login:";
$l68 = "Titulo visivel no nome da janela:";
$l69 = "O programa n�o tem permiss�es de escrita no ficheiro settingssaved.php. Este ficheiro necessita de permiss�es de escrita, altere as permiss�es para 666.";
$l70 = "As defini��es foram gravadas.";
$l71 = "Manter password antiga";
$l72 = "Nova password:";
$l73 = "Password de administra��o:";
$l74 = "Utilizador de administra��o:";
$l75 = "Acesso negado.";
$l76 = "%s verifica��o autom�tica";
$l77 = "Activar";
$l78 = "Desactivar";
$l79 = "Numero de minutos entre cada verifica��o:";
$l80 = "Tem certeza que deseja sair?";
$l81 = "Tema:";
$l82 = "<a href='readme.html' target='_blank'>Ver o ficheiro readme</a>";
$l83 = "Mensagem de texto formatado:";
$l84 = "Sim";
$l85 = "N�o";
$l86 = "Ask for a receipt";
$l87 = "Priority:";
$l88 = "High";
$l89 = "Normal";
$l90 = "Low";
$l91 = "Highest";
$l92 = "Lowest";
$l93 = "This setting turns formatted message text on or off. If you turn it on, plain text messages will be formatted in such a way that *bold* gets converted to <b>bold</b>, /italic/ gets converted to <i>italic</i>, and _underlined_ gets converted to <u>underlined</u>.";
$l94 = "Help";
$l95 = "Close";
$l96 = "If you want to limit the users of this program to only using one POP server or a small number of predefined POP servers, write a list of those servers separated by a comma and a space: <i>mail1.example.com, mail2.example.com, mail3.example.com</i>";
$l97 = "Enter one or more port numbers separated by a comma and a space, e.g. <i>110, 111</i>.";
$l98 = "Enter one or more POP usernames separated by a comma and a space, e.g. <i>user1, user2</i>.";
$l99 = "Your email address:";
$l100 = "You did not select any messages to be deleted.";
$l101 = "Are you sure that you want to delete the selected messages?";
$l102 = "(De)select all";
$l103 = "Repeat the password";
$l104 = "The two passwords you entered are not the same.";



function l14($timeStamp) {
	return date("d/m/Y H:i", $timeStamp);
}
?>