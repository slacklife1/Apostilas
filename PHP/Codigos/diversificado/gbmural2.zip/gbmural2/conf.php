<?php

$db[nome] = "gbmural";
$db[host] = "localhost";
$db[user] = "root";
$db[pass] = "";

$link[index] = "index.php";
$link[smiles] = "img/smilies.php";
$link[ubbc] = "ubbc.js";
$link[postar] = "?page=postar";
$link[inserir] = "?page=inserir";
$link[psm] = "img";
$link[css] = "style.css";

$lpp = "8";
$tm = "300";
$paginacao[link] = "$PHP_SELF?";

$cor[topico] = "#FFFFFF";

$no_icq = "--------";
$titulo = "GB Mural 2.0";
$thanks_msg = "Mensagem enviada com sucesso!";
$error_msg = "N�o foi poss�vel enviar a mensagem. Tente novamente.";
$smyles = "1";
$url_site = "http://www.meusite.com.br";
$specialchar = "1";

$td[msg] = "mensagens";
$td[user] = "usuarios";

?>
