<html>
<head>
<title>Smiles - Mural Acheivoce.com</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<table width="500" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>
      <div align="center"><font face="Geneva, Arial, Helvetica, san-serif" size="4">Lista 
        de smiles<font size="1" face="Verdana"><br>
        <strong>Para adicionar qualquer smile em sua mensagem basta copiar o c&oacute;digo do escolhido 
        e colocar na caixa de mensagem.</strong></font></font></div>
    </td>
  </tr>
  <tr>
    <td> 
      <table width="500" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="anjo.gif" width="21" height="21"><br>
              :anjo: </font></b></div></td>
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="arma.gif" width="94" height="25"><br>
              :arma: </font></b></div></td>
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="arma2.gif" width="100" height="33"><br>
              :arma2: </font></b></div></td>
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="arma3.gif" width="75" height="26"><br>
              :arma3: </font></b></div></td>
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="blackpower.gif" width="33" height="28"><br>
              :blackpower: </font></b></div></td>
        </tr>
        <tr> 
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="boing.gif" width="31" height="31"><br>
              :boing: </font></b></div></td>
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="bronca.gif" width="15" height="15"><br>
              :bronca: </font></b></div></td>
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="chines.gif" width="20" height="20"><br>
              :chines: </font></b></div></td>
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="chopp.gif" width="60" height="40"><br>
              :chopp: </font></b></div></td>
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="choro.gif" width="21" height="16"><br>
              :choro: </font></b></div></td>
        </tr>
        <tr> 
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="dindin.gif" width="15" height="15"><br>
              :dimdim: </font></b></div></td>
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="dormindo.gif" width="40" height="20"><br>
              :dormindo: </font></b></div></td>
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="fodase.gif" width="33" height="15"><br>
              :fodase: </font></b></div></td>
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="privada.gif" width="24" height="26"><br>
              :privada: </font></b></div></td>
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="invisivel.gif" width="15" height="15"><br>
              :invisivel: </font></b></div></td>
        </tr>
        <tr> 
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="leilao.gif" width="30" height="26"><br>
              :leilao:</font></b></div></td>
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="lingua.gif" width="16" height="16"><br>
              :lingua: </font></b></div></td>
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="louco.gif" width="25" height="24"><br>
              :louco: </font></b></div></td>
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="mexicano.gif" width="28" height="19"><br>
              :mexicano: </font></b></div></td>
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="morcego.gif" width="64" height="22"><br>
              :morcego: </font></b></div></td>
        </tr>
        <tr> 
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="nao.gif" width="22" height="19"><br>
              :nao: </font></b></div></td>
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="nervoso.gif" width="16" height="16"><br>
              :nervoso: </font></b></div></td>
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="ok.gif" width="33" height="15"><br>
              :ok: </font></b></div></td>
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="pum.gif" width="65" height="35"><br>
              :pum: </font></b></div></td>
          <td> <div align="center"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="som.gif" width="19" height="18"><br>
              :som: </font></b></div></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
