<?php
// Smiles da p�gina principal
$msg=str_replace(":)","<img src=\"".$link[psm]."/smiley.gif\">",$msg);
$msg=str_replace(";)","<img src=\"".$link[psm]."/wink.gif\">",$msg);
$msg=str_replace(":D","<img src=\"".$link[psm]."/cheesy.gif\">",$msg);
$msg=str_replace(";D","<img src=\"".$link[psm]."/grin.gif\">",$msg);
$msg=str_replace("~(","<img src=\"".$link[psm]."/angry.gif\">",$msg);
$msg=str_replace(":(","<img src=\"".$link[psm]."/sad.gif\">",$msg);
$msg=str_replace(":o","<img src=\"".$link[psm]."/shocked.gif\">",$msg);
$msg=str_replace("8)","<img src=\"".$link[psm]."/cool.gif\">",$msg);
$msg=str_replace("???","<img src=\"".$link[psm]."/huh.gif\">",$msg);
$msg=str_replace("::/","<img src=\"".$link[psm]."/rolleyes.gif\">",$msg);
$msg=str_replace(":P","<img src=\"".$link[psm]."/tongue.gif\">",$msg);
$msg=str_replace(":-[","<img src=\"".$link[psm]."/embarassed.gif\">",$msg);
$msg=str_replace(":-X","<img src=\"".$link[psm]."/lipsrsealed.gif\">",$msg);
$msg=str_replace(":-/","<img src=\"".$link[psm]."/undecided.gif\">",$msg);
$msg=str_replace(":-*","<img src=\"".$link[psm]."/kiss.gif\">",$msg);
$msg=str_replace("'(","<img src=\"".$link[psm]."/cry.gif\">",$msg);
$msg=str_replace("C)","<img src=\"".$link[psm]."/coracao.gif\">",$msg);
// Smiles da p�gina POP UP
$msg=str_replace(":anjo:","<img src=\"".$link[psm]."/anjo.gif\">",$msg);
$msg=str_replace(":arma:","<img src=\"".$link[psm]."/arma.gif\">",$msg);
$msg=str_replace(":arma2:","<img src=\"".$link[psm]."/arma2.gif\">",$msg);
$msg=str_replace(":arma3:","<img src=\"".$link[psm]."/arma3.gif\">",$msg);
$msg=str_replace(":blackpower:","<img src=\"".$link[psm]."/blackpower.gif\">",$msg);
$msg=str_replace(":boing:","<img src=\"".$link[psm]."/boing.gif\">",$msg);
$msg=str_replace(":bronca:","<img src=\"".$link[psm]."/bronca.gif\">",$msg);
$msg=str_replace(":chines:","<img src=\"".$link[psm]."/chines.gif\">",$msg);
$msg=str_replace(":choop:","<img src=\"".$link[psm]."/chopp.gif\">",$msg);
$msg=str_replace(":choro:","<img src=\"".$link[psm]."/choro.gif\">",$msg);
$msg=str_replace(":dimdim:","<img src=\"".$link[psm]."/dimdim.gif\">",$msg);
$msg=str_replace(":dormindo:","<img src=\"".$link[psm]."/dormindo.gif\">",$msg);
$msg=str_replace(":fodase:","<img src=\"".$link[psm]."/fodase.gif\">",$msg);
$msg=str_replace(":privada:","<img src=\"".$link[psm]."/privada.gif\">",$msg);
$msg=str_replace(":invisivel:","<img src=\"".$link[psm]."/invisivel.gif\">",$msg);
$msg=str_replace(":leilao:","<img src=\"".$link[psm]."/leilao.gif\">",$msg);
$msg=str_replace(":lingua:","<img src=\"".$link[psm]."/lingua.gif\">",$msg);
$msg=str_replace(":louco:","<img src=\"".$link[psm]."/louco.gif\">",$msg);
$msg=str_replace(":mexicano:","<img src=\"".$link[psm]."/mexicano.gif\">",$msg);
$msg=str_replace(":morcego:","<img src=\"".$link[psm]."/morcego.gif\">",$msg);
$msg=str_replace(":nao:","<img src=\"".$link[psm]."/nao.gif\">",$msg);
$msg=str_replace(":nervoso:","<img src=\"".$link[psm]."/nervoso.gif\">",$msg);
$msg=str_replace(":ok:","<img src=\"".$link[psm]."/ok.gif\">",$msg);
$msg=str_replace(":pum:","<img src=\"".$link[psm]."/pum.gif\">",$msg);
$msg=str_replace(":som:","<img src=\"".$link[psm]."/som.gif\">",$msg);
?>
