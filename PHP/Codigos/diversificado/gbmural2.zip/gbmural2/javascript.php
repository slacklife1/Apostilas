<script language="JavaScript">
function abrir(url) { 
window.open(url+'.php','500x400','toolbar=no,status=no,scrollbars=yes,location=no,menubar=no,directories=no,width=400,height=300');
}
</script>
