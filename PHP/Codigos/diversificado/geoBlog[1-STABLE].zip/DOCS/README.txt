GEOBLOG 1.0 STABLE README

GeoBlog is free software distributed under the General Public License and is OSI
certified. If you were asked to pay for this software please email
the7thguest@mindfuk.net with where you bought it and any other information you
believe is relevant.

GeoBlog has been tested by the W3C online test page, and complies with the
internet standards for HTML and CSS. If you have found otherwise please email
the7thguest@mindfuk.net with the file and line that contains the problem.

GeoBlog has been tested for errors, bugs and security issues to the best of my
ability. If you encounter a problem with the software, please report it to
the7thguest@mindfuk.net with a description and other relevant information such
as the page and line before posting it to any other mailing lists such as
bugtraq.

This software is distributed as-is with no warranty or guarantee of it being
suitable for your system. While I make the best efforts to ensure it is bug
free, I cannot and will not be held responsible for any damage to your system or
information as a result of using this software.

You are not permitted remove any meta-tags, copyrights or any footers (Page
powered by...). Removing such code voids your license agreement. By removing
them you agree to stop publicly using the software and to pay me �50 in damages
for every page modified.

By using this software you accept the terms and conditions set in place by the
GPL v.2 and this document. If you do not agree, you may not use this software.
