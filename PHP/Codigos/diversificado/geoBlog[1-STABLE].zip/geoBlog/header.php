<?php
include("config.php");

function convdate($timestamp)
{
	$day = substr($timestamp, 6, 2);
	$month = substr($timestamp, 4, 2);
	$year = substr($timestamp, 0, 4);
	return $day . "/" . $month . "/" . $year;
}

function strip($data) {
	$data = addslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}

$timer['start'] = microtime();
?>