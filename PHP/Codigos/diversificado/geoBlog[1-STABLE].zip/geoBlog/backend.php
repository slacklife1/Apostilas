<?php
include("header.php");
$me = $_SERVER['PHP_SELF'];
$Apathweb = explode("/", $me);
$myFileName = array_pop($Apathweb);
$pathweb = implode("/", $Apathweb);
$myURL = "http://".$_SERVER['HTTP_HOST'].$pathweb;

header("Content-Type: text/xml");
echo ("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
?>

<!DOCTYPE rss PUBLIC "-//Netscape Communications//DTD RSS 0.91//EN"
 "http://my.netscape.com/publish/formats/rss-0.91.dtd">

<rss version="0.91">

<channel>
<title>geoBlog RSS Feed</title>
<link><?php print($myURL); ?></link>
<description>Blog Feed!</description>
<language>en-us</language>

<?php
$query = mysql_query("SELECT * FROM geo_blog ORDER BY id DESC LIMIT 50");
while ($row = mysql_fetch_array ($query)) {
print("    <item>
	<title>" . $row['title'] . "</title>
	<link>" . $myURL . "/viewblog.php?id=" . $row['id'] . "</link>
	</item>");
}
?>


</channel>
</rss>