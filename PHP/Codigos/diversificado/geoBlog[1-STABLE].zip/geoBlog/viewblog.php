<?php
include("header.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><?php print $blog_title; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="styles.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="600" border="0" class="table">
  <tr> 
    <td><?php print($blog_user); ?></td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td width="723"> <table width="100%" border="0">
        <tr> 
          <?php
		if(!is_numeric($id)) { 
		print "Dont be a H4x0r!";
		exit();
		} else {
		$query[654] = mysql_query("SELECT * FROM geo_blog WHERE id='$id'");
		$result = mysql_fetch_array($query[654]);
		?>
          <td width="9%"><div align="right"><strong>Title:</strong></div></td>
          <td width="68%"><?php print $result['title']; ?> </td>
          <td width="23%" rowspan="3"><div align="center"><?php if($showimage == "yes") { print("<img src=\"images/" . $result['mood'] . ".gif\">"); } ?></div></td>
        </tr>
        <tr> 
          <td><div align="right"><strong>Mood:</strong></div></td>
          <td><?php print $result['mood']; ?></td>
        </tr>
        <tr> 
          <td><div align="right"><strong>Song:</strong></div></td>
          <td><?php print $result['playlist']; ?></td>
        </tr>
        <tr> 
          <td><div align="right"></div></td>
          <td colspan="3"><br> <?php print $result['content']; ?></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td colspan="3"><div align="right"><a href="index.php"><strong>Back</strong></a></div></td>
        </tr>
      </table>
	  <?php
	  }//End If
      $n_views = $result['views'] + 1;
	  $query[805] = mysql_query("UPDATE geo_blog SET views='$n_views' WHERE id='$id'");
	  ?>
	  </td>
  </tr>
</table>
<p>&nbsp;</p>
<p><br>
</p>
<table width="600" border="0" class="table">
  <tr>
    <td>
      <?php
if(is_numeric($id)) {
$query[816] = mysql_query("SELECT * FROM geo_comment WHERE linkid='$id' ORDER BY id LIMIT 5");
print("<table width=\"100%\" border=\"0\">");
while($result = mysql_fetch_array($query[816])) {
$email = stripslashes($result['email']);
$user = stripslashes($result['user']);
$content = stripslashes($result['content']);
print("<tr> 
          <td width=\"12%\"><div align=\"right\"><strong>Username:</strong></div></td>
          <td width=\"88%\"><a href=\"mailto:" . $email . "\">" . $user . "</td>
        </tr>
        <tr> 
          <td><div align=\"right\"><strong>Wrote:</strong></div></td>
          <td valign=\"top\">" . $content . "</td>
        </tr>");
} //End While
$returned = mysql_num_rows($query[816]);
if(mysql_num_rows($query[816]) < 1) {
	print("<tr> 
          <td width=\"88%\"><div align=\"center\">There are no comments</div></td>
        </tr>");
}//End If
print("</table>");
}//end if
?>
    </td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr>
    <td><?php if($returned >= 1) {
	print("<a href=\"viewcomment.php?id=" . $id . "\">View All Comments</a>");
	} else {
	print("No Comments");
	}
	?></td>
    <td><div align="right"><a href="addcomment.php?id=<?php print $id; ?>">Add 
        A New Comment</a></div></td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td>Powered By<b> <a href="http://geoblog.the-bronze.me.uk">geoBlog</a>&nbsp;</b>written 
      by<b> The7thGuest</b></td>
  </tr>
</table>
<div align="left">
  <?php
include("footer.php")
?>
</div>
</body>
</html>