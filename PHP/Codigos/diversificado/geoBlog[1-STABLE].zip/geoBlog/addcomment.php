<?php
include("header.php");

$id = $_GET['id'];
$sub_user = $_GET['sub_user'];
$sub_email = $_GET['sub_email'];
$sub_comment = $_GET['sub_comment'];
$Submit = $_GET['Submit'];

if($Submit) {
	if(!$sub_user || !$sub_comment) {
		$msg1 = "Please fill all the fields this time";
	} else {
		$ip = $_SERVER['REMOTE_ADDR'];
		$comment = strip($sub_comment);
		$comment = str_replace("\n", "<br>", $comment);
		$user = strip($sub_user);
		$email = strip($sub_email);
		$query[8] = mysql_query("INSERT INTO geo_comment SET linkid='$id', user='$user', content='$comment', email='$email', ip='$ip'");
		$message = "Thank you for your comments. Please continue browsing the blog...";
	} // End Else
} // End If Submit
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><?php print $blog_title; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="styles.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="600" border="0" class="table">
  <tr> 
    <td><?php print($blog_user); ?></td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td>
	<?php
	if(!is_numeric($id) && !$sub_id) {
		print("Dont be a h4xor. " . $_SERVER['REMOTE_ADDR'] . " <--- Your IP is recorded");
		exit();
	} else {
		if($message) {
			print $message;
		} else {
	?>
      <form action="addcomment.php" method="get" name="form1">
        <div align="center">The email field is optional<br>
          <?php print $msg1; ?> </div>
        <table width="100%" border="0">
          <tr> 
            <td width="34%" valign="top"> <div align="right">Name:</div></td>
            <td width="66%"><input name="sub_user" type="text" class="formobjects" id="sub_name2" size="35"> 
              <input name="id" type="hidden" id="id" value="<?php print $id; ?>"> 
            </td>
          </tr>
          <tr> 
            <td valign="top"> <div align="right">Email:</div></td>
            <td><input name="sub_email" type="text" class="formobjects" id="sub_email2" size="35"> 
            </td>
          </tr>
          <tr> 
            <td valign="top"> <div align="right">Comment:</div></td>
            <td><textarea name="sub_comment" cols="30" rows="5" class="formobjects" id="textarea"></textarea> 
            </td>
          </tr>
          <tr> 
            <td valign="top"><div align="right">Add Comment:</div></td>
            <td><input name="Submit" type="submit" class="formbutton" value="Submit"></td>
          </tr>
        </table>
      </form>
	  <?php
	  } //End Else
	  } //End Else
	  ?>
	  </td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td width="247" height="14"><a href="viewcomment.php?id=<?php print $id; ?>">View 
      Comments</a></td>
    <td width="204"><a href="viewblog.php?id=<?php print $id; ?>">Back To Blog</a></td>
    <td width="133"><div align="right"><a href="index.php">Back To Index</a></div></td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td>Powered By<b> <a href="http://geoblog.the-bronze.me.uk">geoBlog</a> </b>written 
      by<b> The7thGuest</b></td>
  </tr>
</table>
<?php
include("footer.php")
?>
</body>
</html>
