<?php
$timer['finish'] = microtime();
$timer['total'] = $timer['finish'] - $timer['start'];

if(count($query) == 1) {
	$queries = count($query) . " query";
} else {
	$queries = count($query) . " queries";
} //end if

print("Page loaded in " . $timer['total'] . " seconds<br>");
print("Using " . $queries . "");
?>