<?php
include("header.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><?php print $blog_title; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="styles.css" rel="stylesheet" type="text/css">
<meta name="Script" content="geoBlog 1.0 STABLE">
<meta name="Author" content="The7thGuest">
<meta name="Homepage" content="http://geoblog.the-bronze.me.uk">
</head>

<body>
<table width="600" border="0" class="table">
  <tr> 
    <td><?php print($blog_user); ?></td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td>
	<?php
	$query[550] = mysql_query("SELECT * FROM geo_blog ORDER BY id DESC LIMIT 50");
	print mysql_error();
	while($result = mysql_fetch_array($query[550])) {
		$temp_id = $result['id'];
		$temp_date = convdate($result['timestamp']);
		$temp_title = $result['title'];
		$temp_views = $result['views'];
		$query[758] = mysql_query("SELECT count(*) AS total FROM geo_comment WHERE linkid=$temp_id");
		$comments = mysql_fetch_array($query[758]);
		if($comments['total'] < 1) {
			$comments['total'] = 0;
		}
		print("<b>" . $temp_date . " - <a href=\"viewblog.php?id=" . $temp_id . "\">" . $temp_title . "</a></b>&nbsp;&nbsp;&nbsp;&nbsp;(" . $temp_views . " views, " . $comments['total'] . " comments)<br>");
	} //End While
	?>
	</td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td>Powered By<b> <a href="http://geoblog.the-bronze.me.uk">geoBlog</a> </b>written 
      by<b> The7thGuest</b></td>
  </tr>
</table>
<?php
include("footer.php")
?>
</body>
</html>