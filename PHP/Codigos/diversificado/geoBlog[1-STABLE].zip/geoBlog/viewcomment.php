<?php
include("header.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><?php print $blog_title; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="styles.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="600" border="0" class="table">
  <tr> 
    <td><?php print $blog_user; ?></td>
  </tr>
</table>
<?php
if(!is_numeric($id)) {
print("Dont Be A h4x0r!!!");
exit();
}//End If
?>
<br>
<?php
$query[816] = mysql_query("SELECT * FROM geo_comment WHERE linkid='$id' ORDER BY id LIMIT 5");
while($result = mysql_fetch_array($query[816])) {
$email = stripslashes($result['email']);
$user = stripslashes($result['user']);
$content = stripslashes($result['content']);
print("
	<table width=\"600\" border=\"0\" class=\"table\">
        <tr> 
          <td width=\"12%\"><div align=\"right\"><strong>Username:</strong></div></td>
          <td width=\"88%\"><a href=\"mailto:" . $email . "\">" . $user . "</td>
        </tr>
        <tr> 
          <td><div align=\"right\"><strong>Wrote:</strong></div></td>
          <td>" . $content . "</td>
        </tr>
      </table>
	  <br>");
} //End While
if(mysql_num_rows($query[816]) < 1) {
	print "<table width=\"600\" border=\"0\" class=\"table\">
        <tr> 
          <td width=\"88%\"><div align=\"center\">There are no comments</div></td>
        </tr>
		</table>";
}//End If
?>
<br>
<table width="600" border="0" class="table">
  <tr>
    <td width="247" height="14"><a href="addcomment.php?id=<?php print $id; ?>">Add 
      A Comment</a></td>
    <td width="204"><a href="viewblog.php?id=<?php print $id; ?>">Back To Blog</a></td>
    <td width="133"><div align="right"><a href="index.php">Back To Index</a></div></td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td>Powered By <b><a href="http://geoblog.the-bronze.me.uk">geoBlog</a> </b>written 
      by<b> The7thGuest</b></td>
  </tr>
</table>
<?php
include("footer.php")
?>
</body>
</html>