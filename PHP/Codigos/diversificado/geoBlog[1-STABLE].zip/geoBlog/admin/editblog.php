<?php
session_start();
include("header.php");
if($_SESSION['login'] != "user_valid_and_logged_in") {
header("Location: ../index.php");
}

$id = $_GET['id'];
$sub_title = $_GET['sub_title'];
$sub_content = $_GET['sub_content'];
$sub_song = $_GET['sub_song'];
$sub_mood = $_GET['sub_mood'];
$Submit = $_GET['Submit'];

if($Submit) {
$content = htmlspecialchars($sub_content);
$content = nl2br($content);
$content = parsetohtml($content);
$query[4654] = mysql_query("UPDATE geo_blog SET title='$sub_title', content='$content', mood='$sub_mood', playlist='$sub_song' WHERE id='$sub_id'");
$message = "Your blog has been edited. You can verify this by viewing the blog listing. -Thank You</a>";
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><?php print $blog_title; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../styles.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="600" border="0" class="table">
  <tr> 
    <td><?php print($blog_user); ?>
      <?php
	if(!$sub_id && !is_numeric($id)) {
	 print("<b>There has been an error processing your request</b>");
	} else {
	 $query[900] = mysql_query("SELECT * FROM geo_blog WHERE id='$id' LIMIT 1");
	 $result = mysql_fetch_array($query[900]);
	} //End Else
	?>
    </td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td width="723">
	<?php
	if(!$message) {
	?>
	  <form name="form1" method="get" action="editblog.php">
        <p>Title:<br>
          <input name="sub_title" type="text" class="formobjects" id="sub_title" value="<?php print $result['title']; ?>" size="30">
          <input name="sub_id" type="hidden" id="sub_id" value="<?php print $result['id']; ?>">
        </p>
        <p>Mood:<br>
          <select name="sub_mood" class="formobjects" id="sub_mood">
            <option value="Happy" selected>Happy</option>
            <option value="Sad">Sad</option>
            <option value="Extatic">Extatic</option>
            <option value="Depressed">Depressed</option>
            <option value="Unknown">Unknown</option>
            <option value="Mellow">Mellow</option>
            <option value="Upset">Upset</option>
          </select>
        </p>
        <p>Song: <br>
          <input name="sub_song" type="text" class="formobjects" id="sub_song" value="<?php print $result['playlist']; ?>" size="30">
        </p>
        <p> Content: BBCode [<a href="help.php#bbcode" target="_blank"><strong>?</strong></a>]<br>
          <textarea name="sub_content" cols="50" rows="10" class="formobjects" id="sub_content"><?php $content = parsetobbc($result['content']); print $content; ?></textarea>
        </p>
        <p>
          <input name="Submit" type="submit" class="formbutton" value="Submit">
        </p>
      </form>
	  <?php
	  } else {
	  print $message;
	  } //end if
	  ?>
	  <div align="right"><a href="admin.php"><strong>Back to Administration</strong></a></div>
	  </td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td>Powered By<b> <a href="http://geoblog.the-bronze.me.uk">geoBlog </a></b>written 
      by<b> The7thGuest</b></td>
  </tr>
</table>
<?php
include("../footer.php")
?>
</body>
</html>