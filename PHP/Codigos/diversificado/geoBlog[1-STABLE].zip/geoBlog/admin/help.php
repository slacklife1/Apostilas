<?php
include("header.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><?php print $blog_title; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../styles.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="600" border="0" class="table">
  <tr> 
    <td><?php print($blog_user); ?></td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td><p><strong>BBCode:<a name="bbcode"></a></strong></p>
      <p>BBCode is implemented in geoBlog as of version one. It MUST be used instead 
        of HTML.<br>
        Example:<br>
        URL --&gt; [url=http://www.google.com]Go To Google[/url] --&gt; Adds a 
        link to your blog<br>
        IMG --&gt; [img]http://www.google.com/images/web_logo_left.gif[/img] --&gt; 
        Adds an image to your blog<br>
        BOLD --&gt; [b]Text to make bold[/b] --&gt; Makes the encapsulated text 
        bold.</p>
      <p>&nbsp;</p>
      <p><strong>Optimize:<a name="optimize"></a></strong></p>
      <p>The type of field used to store your blog and comment data can hole a 
        lot of information, but even it it is not full... it will take the same 
        ammount of memory. Optimisation allows the database to free up the unused 
        memory in all the tables, and should be done every couple of blogs.</p>
      <p>&nbsp;</p>
      <p><strong>Show Images:<a name="showimages"></a></strong></p>
      <p>geoBlog has the option of showing small, passport style images in the 
        top right corner of all your blogs, these images can be found in the /images 
        folder and are based on the mood you set.</p>
      </td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td>Powered By<b> <a href="http://geoblog.the-bronze.me.uk">geoBlog</a> </b>written 
      by<b> The7thGuest</b></td>
  </tr>
</table>
<?php
include("../footer.php")
?>
</body>
</html>