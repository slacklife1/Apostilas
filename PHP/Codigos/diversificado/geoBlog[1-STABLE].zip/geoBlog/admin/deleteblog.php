<?php
session_start();
include("header.php");
if($_SESSION['login'] != "user_valid_and_logged_in") {
header("Location: ../index.php");
}
$id = $_GET['id'];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><?php print $blog_title; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../styles.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="600" border="0" class="table">
  <tr> 
    <td><?php print($blog_user); ?>
      <?php
	
	?>
    </td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td width="723"> 
      <?php
	if(!is_numeric($id)) {
	 print("<b>There has been an error processing your request</b>");
	} else {
 	$query[4654] = mysql_query("DELETE FROM geo_blog WHERE id='$id'");
	print("Your blog has been Deleted. You can verify this by viewing the blog listing. -Thank You<br><br>");
	} //End Else
	?>
      <div align="right"><br>
        <strong><a href="admin.php">Back to Administration</a></strong></div></td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td>Powered By<b> <a href="http://geoblog.the-bronze.me.uk">geoBlog</a> </b>written 
      by<b> The7thGuest</b></td>
  </tr>
</table>
<?php
include("../footer.php")
?>
</body>
</html>