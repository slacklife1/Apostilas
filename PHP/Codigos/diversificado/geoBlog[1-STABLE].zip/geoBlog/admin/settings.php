<?php
include("header.php");
session_start();
if($_SESSION['login'] != "user_valid_and_logged_in") { 
header("Location: ../index.php"); 
}// End If

$Submit = $_GET['Submit'];
$sub_user = $_GET['sub_user'];
$sub_pass = $_GET['sub_pass'];
$sub_pass1 = $_GET['sub_pass1'];
$sub_pass2 = $_GET['sub_pass2'];
$sub_email = $_GET['sub_email'];
$sub_title = $_GET['sub_title'];
$sub_image = $_GET['sub_image'];
$sub_id = $_GET['sub_id'];

if($Submit) {
	$query[7236] = mysql_query("UPDATE geo_config SET user='$sub_user', email='$sub_email', title='$sub_title', showimages='$sub_image' WHERE id='$sub_id'");
	$msg = "<div align=\"center\">Update Complete</div>";
	if($sub_pass) {
		if($sub_pass == $blog_md5_hash) {
			if($sub_pass1 && $sub_pass2 && $sub_pass1 == $sub_pass2) {
				$nu_pass = md5($sub_pass1);
				mysql_query("UPDATE geo_settings SET pass='$nu_pass' WHERE id='$sub_id'");
				$message = "password changed";
			} else {
				$message = "passwords are invalid";
			}
		}
	}
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><?php print $blog_title; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../styles.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="600" border="0" class="table">
  <tr> 
    <td><?php print($blog_user); ?></td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td> 
      <?php
	  if($msg) {
	  	print $msg;
		} else {
	$query[837] = mysql_query("SELECT * FROM geo_config ORDER BY id LIMIT 1");
	$result = mysql_fetch_array($query[837]);
	?>
      <?php print $message; ?> 
      <form name="form1" method="get" action="settings.php">
        <table width="100%" border="0">
          <tr> 
            <td width="18%"><div align="right">Username:&nbsp;</div></td>
            <td width="82%"><input name="sub_user" type="text" class="formobjects" id="sub_pass3" value="<?php print $result['user']; ?>"> 
              <input name="sub_id" type="hidden" id="sub_id" value="<?php print $result['id']; ?>"></td>
          </tr>
          <tr> 
            <td><div align="right">Old Password: <br>
              </div></td>
            <td><input name="sub_pass" type="text" class="formobjects" id="sub_pass2"></td>
          </tr>
          <tr> 
            <td><div align="right">New Password: </div></td>
            <td><input name="sub_pass1" type="text" class="formobjects" id="sub_pass"></td>
          </tr>
          <tr> 
            <td><div align="right">New Password 2: </div></td>
            <td><input name="sub_pass2" type="text" class="formobjects" id="sub_pass4"></td>
          </tr>
          <tr> 
            <td><div align="right">Email: </div></td>
            <td><input name="sub_email" type="text" class="formobjects" id="sub_pass5" value="<?php print $result['email']; ?>"></td>
          </tr>
          <tr> 
            <td><div align="right">Title: </div></td>
            <td><input name="sub_title" type="text" class="formobjects" id="sub_pass7" value="<?php print $result['title']; ?>"></td>
          </tr>
          <tr> 
            <td><div align="right">[<a href="help.php#showimages" target="_blank"><strong>?</strong></a>] 
                Show Images:</div></td>
            <td><p> 
                <select name="sub_image" id="sub_image">
                  <option value="yes" selected>Yes</option>
                  <option value="no">No</option>
                </select>
              </p>
              </td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td><input name="Submit" type="submit" class="formbutton" value="Submit"></td>
          </tr>
        </table>
		<?php
		}//End If
		?>
        <p align="right"><a href="admin.php"><strong>Back to Administration</strong></a></p>
      </form>
	</td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td>Powered By<b> <a href="http://geoblog.the-bronze.me.uk">geoBlog</a> </b>written 
      by<b> The7thGuest</b></td>
  </tr>
</table>
<?php
include("../footer.php")
?>
</body>
</html>