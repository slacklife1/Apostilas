<?php
session_start();
include("header.php");

$id = $_GET['id'];
$lid = $_GET['lid'];

if($id) {
$query[0237834] = mysql_query("DELETE FROM geo_comment WHERE id='$id' and linkid='$lid'");
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><?php print $blog_title; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../styles.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="600" border="0" class="table">
  <tr> 
    <td><?php print($blog_user); ?></td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td> <div align="center"></div>
      <?php
	if($id) { print "The comment has been removed"; } else { print "No ID specified"; }
	?>
	</div>
      <div align="right"><br>
        <strong><a href="listcomment.php?id=<?php print $lid; ?>">Back to Comment 
        Listing</a> || <a href="admin.php">Back to Administration</a></strong></div></td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td>Powered By<b> <a href="http://geoblog.the-bronze.me.uk">geoBlog</a> </b> written 
      by <b>The7thGuest</b></td>
  </tr>
</table>
<?php
include("../footer.php")
?>
</body>
</html>