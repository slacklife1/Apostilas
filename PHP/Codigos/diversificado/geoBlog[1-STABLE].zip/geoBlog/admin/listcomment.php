<?php
session_start();
include("header.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><?php print $blog_title; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../styles.css" rel="stylesheet" type="text/css">
</head>

<script language="javascript">

function del(id, lid) {
        if(window.confirm("Are you sure you want to Remove this Entry?")) {
               window.location.href = "deletecomment.php?id="+id+"&lid="+lid    }
}
</script>

<body>
<table width="600" border="0" class="table">
  <tr> 
    <td><?php print($blog_user); ?></td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td> 
      <?php
	if($id) { 
	$query[747] = mysql_query("SELECT * FROM geo_comment WHERE linkid='$id'");
	while($result = mysql_fetch_array($query[747])) {
	print ( $result['user'] . "&nbsp;&nbsp;<a href=\"javascript:del(" . $result['id'] . ", " . $result['linkid'] .")\">Delete</a><br>");
	}// End while
		if(mysql_num_rows($query[747]) < 1) {
		print "<table width=\"600\" border=\"0\" class=\"table\">
       	 <tr> 
       	   <td width=\"88%\"><div align=\"center\">There are no comments</div></td>
       	 </tr>
			</table>";
		}//End If
	} else {
	print "No ID specified"; 
	} //End If
	?>
      <div align="right"><br>
        <strong><a href="admin.php">Back to Administration</a></strong></div></td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td>Powered By<b> <a href="http://geoblog.the-bronze.me.uk">geoBlog</a> </b>written 
      by<b> The7thGuest</b></td>
  </tr>
</table>
<?php
include("../footer.php")
?>
</body>
</html>