<?php
session_start();
include("header.php");
if($_SESSION['login'] != "user_valid_and_logged_in") {
header("Location: ../index.php");
}

$sub_title = $_POST['sub_title'];
$sub_content = $_POST['sub_content'];
$sub_song = $_POST['sub_song'];
$sub_mood = $_POST['sub_mood'];
$Submit = $_POST['Submit'];

if($Submit) {
$post_time = date(Ymd);
$content = htmlspecialchars($sub_content);
$content = str_replace("\n", "<br>", $content);
$content = parsetohtml($content);
$query[6541] = mysql_query("INSERT INTO geo_blog SET title='$sub_title', content='$content', playlist='$sub_song', mood='$sub_mood', timestamp='$post_time'");
print mysql_error();
$message = "Your blog has been added. You can verify this by viewing the blog listing. -Thank You";
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><?php print $blog_title; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../styles.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="600" border="0" class="table">
  <tr> 
    <td><?php print($blog_user); ?>
    </td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td width="723">
	<?php
	if(!$message) {
	?>
	<form name="form1" method="post" action="addblog.php">
        <table width="100%" border="0">
          <tr> 
            <td>Title:<br> </td>
            <td><input name="sub_title" type="text" id="sub_title" value="" size="30"></td>
          </tr>
          <tr> 
            <td>Mood:</td>
            <td><select name="sub_mood" class="formobjects" id="sub_mood">
                <option value="Unknown" selected>Unknown</option>
                <option value="Happy">Happy</option>
                <option value="Sad">Sad</option>
                <option value="Extatic">Extatic</option>
                <option value="Depressed">Depressed</option>
                <option value="Mellow">Mellow</option>
                <option value="Upset">Upset</option>
              </select></td>
          </tr>
          <tr> 
            <td>Song:</td>
            <td><input name="sub_song" type="text" id="sub_song" value="" size="30"></td>
          </tr>
          <tr> 
            <td valign="top"><p>Content:</p>
              <p>BBCode [<a href="help.php#bbcode" target="_blank"><strong>?</strong></a>]</p></td>
            <td><textarea name="sub_content" cols="50" rows="10" id="textarea"></textarea></td>
          </tr>
          <tr>
            <td valign="top">&nbsp;</td>
            <td><input type="submit" name="Submit" value="Submit"></td>
          </tr>
        </table>
        </form>
	  <?php
	  } else {
	  print $message;
	  } //end if
	  ?>
      <div align="right"><a href="admin.php"><strong>Back to Administration</strong></a></div></td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td>Powered By<b> <a href="http://geoblog.the-bronze.me.uk">geoBlog</a> </b> written 
      by<b> The7thGuest</b></td>
  </tr>
</table>
<?php
include("../footer.php")
?>
</body>
</html>