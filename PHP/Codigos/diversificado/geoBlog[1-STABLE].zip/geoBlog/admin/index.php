<?php
include("header.php");
session_start();

if($_SESSION['login'] == "user_valid_and_logged_in") { header("Location: admin.php"); }

if($Submit) {
	//&& $sub_user == $blog_username
	if(md5($sub_pass) == $blog_md5_pass && $sub_user == $blog_username) {
		$_SESSION['login'] = "user_valid_and_logged_in";
		header("Location: admin.php");
	} else {
		header("Location: ../index.php");
	} //End Else
}	
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><?php print $blog_title; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../styles.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="600" border="0" class="table">
  <tr> 
    <td><?php print($blog_user); ?></td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td><form name="form1" method="post" action="index.php">
        <table width="100%" border="0">
          <tr> 
            <td><div align="right">Username:&nbsp;</div></td>
            <td><input name="sub_user" type="text" class="formobjects" id="sub_pass3"></td>
          </tr>
          <tr> 
            <td><div align="right">Password: <br>
              </div></td>
            <td><input name="sub_pass" type="password" class="formobjects" id="sub_pass2"></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td><input name="Submit" type="submit" class="formbutton" value="Submit"></td>
          </tr>
        </table>
        </form></td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td>Powered By<b> <a href="http://geoblog.the-bronze.me.uk">geoBlog</a> </b>written 
      by<b> The7thGuest</b></td>
  </tr>
</table>
<?php
include("../footer.php")
?>
</body>
</html>