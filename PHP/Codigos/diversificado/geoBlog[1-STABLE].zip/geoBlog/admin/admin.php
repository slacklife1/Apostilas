<?php
session_start();
include("header.php");
if($_SESSION['login'] != "user_valid_and_logged_in") {
header("Location: ../index.php");
} //End IF
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><?php print $blog_title; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../styles.css" rel="stylesheet" type="text/css">
</head>

<script language="javascript">

function del(id) {
        if(window.confirm("Are you sure you want to Remove this Entry?")) {
               window.location.href = "deleteblog.php?id="+id     }
}
</script>

<body>
<table width="600" border="0" class="table">
  <tr> 
    <td><?php print($blog_user); ?></td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td> <p align="right"><strong> <a href="../index.php">Home</a> || <a href="optimise.php">Optimize</a> || <a href="settings.php">Change 
        Settings</a> ||&nbsp;<a href="addblog.php">Add A Blog</a></strong></p>
      <p>
        <?php
	$query[550] = mysql_query("SELECT * FROM geo_blog ORDER BY id DESC LIMIT 50");
	print mysql_error();
	while($result = mysql_fetch_array($query[550])) {
		$temp_id = $result['id'];
		$temp_date = convdate($result['timestamp']);
		$temp_title = $result['title'];
		$temp_views = $result['views'];
		print("<b>" . $temp_date . " - " . "<a href=\"../viewblog.php?id=" . $temp_id . "\" target=\"new_\">" . $temp_title . "</a></b>&nbsp;&nbsp;&nbsp;&nbsp;(<a href=\"editblog.php?id=" . $temp_id ."\">edit</a>)&nbsp;&nbsp;(<a href=\"javascript:del(" . $temp_id .")\">delete</a>)&nbsp;&nbsp;(<a href=\"listcomment.php?id=" . $temp_id . "\">comments</a>)<br>");
	} //End While
	?>
      </p></td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td>Powered By<b> <a href="http://geoblog.the-bronze.me.uk">geoBlog</a> </b> written 
      by<b> The7thGuest</b></td>
  </tr>
</table>
<?php
include("../footer.php")
?>
</body>
</html>