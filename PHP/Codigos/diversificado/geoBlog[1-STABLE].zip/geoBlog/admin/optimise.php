<?php
include("header.php");
session_start();
if($_SESSION['login'] != "user_valid_and_logged_in") { header("Location: ../index.php"); }

$query[74] = mysql_query("OPTIMIZE TABLE `geo_config`");
$query[75] = mysql_query("OPTIMIZE TABLE `geo_blog`");
$query[76] = mysql_query("OPTIMIZE TABLE `geo_comment`");

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><?php print $blog_title; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../styles.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="600" border="0" class="table">
  <tr> 
    <td><?php print($blog_user); ?></td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td><div align="center"> 
        <p>Your Database Has Been Optimized</p>
        <p align="right"><strong><a href="help.php#optimize" target="_blank">What 
          Is This?</a> || <a href="admin.php">Back To Administration</a></strong></p>
      </div></td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td>Powered By<b> <a href="http://geoblog.the-bronze.me.uk">geoBlog</a> </b>written 
      by<b> The7thGuest</b></td>
  </tr>
</table>
<?php
include("../footer.php")
?>
</body>
</html>