<?php
$Submit = $_POST['Submit'];
$sub_dbhost = $_POST['sub_dbhost'];
$sub_dbuser = $_POST['sub_dbuser'];
$sub_dbpass = $_POST['sub_dbpass'];
$sub_dbase = $_POST['sub_dbase'];
$sub_user = $_POST['sub_user'];
$sub_pass1 = $_POST['sub_pass1'];
$sub_pass2 = $_POST['sub_pass2'];
$sub_email = $_POST['sub_email'];
$sub_title = $_POST['sub_title'];
$sub_images = $_POST['sub_images'];

if($Submit) {
	if(!$sub_dbhost || !$sub_dbuser || !$sub_dbpass || !$sub_dbase) {
		$message = "Database fields incomplete!";
	} else {
		if($sub_pass1 != $sub_pass2) {
			$message = "Passwords dont match!";
		} else {
			if(!$sub_pass1 || !$sub_user || !$sub_email) {
				$message = "Please fill <u>all</u> fields!";
			} else {
				//Do install stuff here
				$enc_pass = md5($sub_pass1);
				mysql_connect($sub_dbhost, $sub_dbuser, $sub_dbpass);
				$msg1 .= "Connecting to DB<br>";
				mysql_select_db($sub_dbase);
				$msg1 .= "Selecting DB<br>";
				
				mysql_query("CREATE TABLE geo_config (id tinyint(2) NOT NULL auto_increment, user varchar(255) NOT NULL default '', pass varchar(255) NOT NULL default '', email varchar(255) NOT NULL default '', title varchar(255) NOT NULL default '', showimages char(3) NOT NULL default 'no', PRIMARY KEY  (id), UNIQUE KEY id (id)) TYPE=MyISAM;"); //Setup Config Table
				$msg1 .= "Making Config Table<br>";
				
				mysql_query("CREATE TABLE geo_blog (id int(10) NOT NULL auto_increment, timestamp varchar(20) NOT NULL, title varchar(255) NOT NULL default '', content text NOT NULL, mood varchar(100) NOT NULL default '', playlist varchar(255) NOT NULL default '', views int(10) NOT NULL default '0', PRIMARY KEY  (id), UNIQUE KEY id (id)) TYPE=MyISAM;"); //Setup Blog Table
				$msg1 .= "Making Blog Table<br>";
				
				mysql_query("CREATE TABLE geo_comment (id int(10) NOT NULL auto_increment, linkid int(10) NOT NULL default '0', timestamp timestamp(14) NOT NULL, title varchar(255) NOT NULL default '', content text NOT NULL, user varchar(100) NOT NULL default '', email varchar(100) NOT NULL default '', ip varchar(30) NOT NULL default '', PRIMARY KEY  (id), UNIQUE KEY id (id)) TYPE=MyISAM;"); //Making Comments Table
				$msg1 .= "Making Comments Table<br>";
				
				mysql_query("INSERT INTO geo_config SET user='$sub_user', pass='$enc_pass', email='$sub_email', title='$sub_title', showimages='$sub_images'");
				$msg1 .= "Inserting Admin Info<br>";
				
$fp = fopen("config.php", "w");
fwrite($fp, '<?php
$dbhost = "' . $sub_dbhost . '";
$dbuser = "' . $sub_dbuser . '";
$dbpass = "' . $sub_dbpass . '";
$dbase = "' . $sub_dbase . '";
mysql_connect($dbhost, $dbuser, $dbpass);
mysql_select_db($dbase);
$query[5236] = mysql_query("SELECT * FROM geo_config");
$user_results = mysql_fetch_array($query[5236]);
$blog_user = $user_results[\'title\'];
$blog_username = $user_results[\'user\'];
$blog_email = $user_results[\'email\'];
$blog_md5_pass = $user_results[\'pass\'];
$showimage = $user_results[\'showimages\'];
?>');
fclose($fp);
				
				
				
				$msg1 .= "Install Complete, delete install.php and view index.php";
			}
		}
	}//End If
}//End if
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>geoBlog Install</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="styles.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="600" border="0" class="table">
  <tr> 
    <td>geoBlog Version 1.0 -- Install.php</td>
  </tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td> <?php
	if(!$msg1) {
	?>
	<form action="install.php" method="post" name="form1" id="form1">
        <div align="center"><?php print $message; ?><br>
        </div>
        <table width="100%" border="0">
          <tr> 
            <td colspan="2"><div align="center"><strong>Database Settings</strong></div></td>
          </tr>
          <tr> 
            <td width="26%"><div align="right">Host:</div></td>
            <td width="74%"><input name="sub_dbhost" type="text" class="formobjects" id="sub_dbhost" size="30"></td>
          </tr>
          <tr> 
            <td><div align="right">Username:</div></td>
            <td><input name="sub_dbuser" type="text" class="formobjects" id="sub_dbuser" size="30"></td>
          </tr>
          <tr> 
            <td><p align="right">Password:</p></td>
            <td><input name="sub_dbpass" type="text" class="formobjects" id="sub_dbpass" size="30"></td>
          </tr>
          <tr> 
            <td><div align="right">Database:</div></td>
            <td><input name="sub_dbase" type="text" class="formobjects" id="sub_dbase" size="30"></td>
          </tr>
        </table>
        <br>
        <table width="100%" border="0">
          <tr> 
            <td colspan="2"><div align="center"><strong>Administrator Settings</strong></div></td>
          </tr>
          <tr> 
            <td width="26%"><div align="right">Username:</div></td>
            <td width="74%"><input name="sub_user" type="text" class="formobjects" id="sub_user" size="30"></td>
          </tr>
          <tr> 
            <td><div align="right">Password 1:</div></td>
            <td><input name="sub_pass1" type="text" class="formobjects" id="sub_pass1" size="30"></td>
          </tr>
          <tr> 
            <td><div align="right">Password 2:</div></td>
            <td><input name="sub_pass2" type="text" class="formobjects" id="sub_pass2" size="30"></td>
          </tr>
          <tr>
            <td><div align="right">Email:</div></td>
            <td><input name="sub_email" type="text" class="formobjects" id="sub_email" size="30"></td>
          </tr>
        </table>
        <br>
        <table width="100%" border="0">
          <tr> 
            <td colspan="2"><div align="center"><strong>geoBlog Settings</strong></div></td>
          </tr>
          <tr> 
            <td width="26%"><div align="right">Title:</div></td>
            <td width="74%"><input name="sub_title" type="text" class="formobjects" id="sub_title" size="30"></td>
          </tr>
          <tr> 
            <td><div align="right">Show Images:</div></td>
            <td><input name="sub_images" type="checkbox" class="formobjects" id="sub_images" value="yes"></td>
          </tr>
        </table>
        <br>
        <table width="100%" border="0">
          <tr>
            <td width="64%"><div align="right">
                <input name="Submit" type="submit" class="formbutton" value="Install">
              </div></td>
            <td width="36%">&nbsp;</td>
          </tr>
        </table>
      </form>
	  <?php
	  } else {
	  print $msg1;
	  }
	  ?>
	  </td>
</tr>
</table>
<br>
<table width="600" border="0" class="table">
  <tr> 
    <td>Powered By<b> <a href="http://geoblog.the-bronze.me.uk">geoBlog</a> </b>written 
      by<b> The7thGuest</b></td>
  </tr>
</table>
</body>
</html>