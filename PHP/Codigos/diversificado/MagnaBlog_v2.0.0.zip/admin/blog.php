<?
/*
#===========================================================================
#= Script               : MagnaBlog
#= Version              : 2.0.0
#= PHP Developer        : Shade @ Digital-Angst
#= Aesthetics Developer : Nikki @ Digital-Angst
#= Website: http://www.digital-angst.net/
#= Support: http://www.digital-angst.net/forums/
#===========================================================================
#= Copyright (c) 2003 Shade, Nikkki
#= You are free to use and modify this script as long as this header
#= section stays intact. This file is part of MagnaBlog.
#=
#= You are required to link to digital-angst.net somewhere on your blog.
#=
#= You may not redistribute (or resell) this script from your own site or
#= from anywhere else without special permission (purchase of rights) from
#= the authors.
#= 
#= You may not use code from any of the files contained in MangaBlog in
#= any other script unless that script is limited only to functioning
#= on a website for which you have downloaded MagnaBlog, or unless you've
#= obtained special permission from the authors. 

#= You may edit/alter/expand the source code of this script as much as
#= you like, providing you do not redistribute your changes without
#= permission.
#=
#= This program is distributed in the hope that it will be useful,
#= but WITHOUT ANY WARRANTY; without even the implied warranty of
#= MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#===========================================================================
*/
  include('../config.inc.php');
  $mpage=new Page();
  $mpage->DisplayHeader();
  if (!$mpage->Admin)
  { ?>
    <?= $mpage->config[NotLoggedIn] ?>
  <?
    $mpage->DisplayFooter();
  }
  if($blogrolling)
  {
   $title = $_POST['title'];
   $title = ($title) ? trim($title) : "No title provided";
   $doingtwo = $_POST['doingtwo'];
   $doingtwo = ($doingtwo) ? trim($doingtwo) : "Notta";
   $content = $_POST['content'];
   $content = ($content) ? trim($content) : "Bogus Entry";
   $content = str_replace("\r", "<br />",$content);
   $content = stripslashes($content);
   $content = addslashes($content);
   $sql = "insert into mblog_Blog (Title, Doing, DoingTwo, Content, DisableComments, Sent)
          values (\"$title\", \"$doing\", \"$doingtwo\", \"$content\", \"$disablecomments\", NOW())";
   $mpage->DoQuery($sql);
   echo "<h1>DONE!</h1><br /><a href=\"" . $mpage->config[WebAddy] . "/admin/index.php\">Back To The Index</a>"; 
   $mpage->DisplayFooter();
   exit();
  }
?>
  <h3>Blog It</h3>
  <form method="post">
    Title: <input type="text" name="title" style="width: 300px;" /><br /><br />
    <select name="doing">
<?
  $sql = "select * from mblog_Doing order by Id";
  $b = $mpage->DoQuery($sql, 1);  
  foreach ($b as $s)
  {
?>
       <option value="<?= $s[Id] ?>"> <?= $s[Title] ?></option>
<? } ?>
     </select>
     <input type="text" name="doingtwo" style="width: 228px;" /><br /><br />
     Blog:<br /><textarea name="content" cols="50" rows="15"></textarea><br /><br />
     Disable Comments:
      <select name="disablecomments">
        <option value="N">No</option>
	<option value="Y">Yes</option>
      </select><br /><br />
      <input type="submit" name="blogrolling" value=":: Blog It ::" />&nbsp;<input type="reset" value=":: Reset All ::" />
  </form>
<a href="<?= $mpage->config[WebAddy] ?>/admin/index.php" title="Return To Index">Return to the index</a>
<? $mpage->DisplayFooter(); ?>