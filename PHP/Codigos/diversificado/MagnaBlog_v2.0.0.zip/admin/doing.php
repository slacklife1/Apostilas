<?
/*
#===========================================================================
#= Script               : MagnaBlog
#= Version              : 2.0.0
#= PHP Developer        : Shade @ Digital-Angst
#= Aesthetics Developer : Nikki @ Digital-Angst
#= Website: http://www.digital-angst.net/
#= Support: http://www.digital-angst.net/forums/
#===========================================================================
#= Copyright (c) 2003 Shade, Nikkki
#= You are free to use and modify this script as long as this header
#= section stays intact. This file is part of MagnaBlog.
#=
#= You are required to link to digital-angst.net somewhere on your blog.
#=
#= You may not redistribute (or resell) this script from your own site or
#= from anywhere else without special permission (purchase of rights) from
#= the authors.
#= 
#= You may not use code from any of the files contained in MangaBlog in
#= any other script unless that script is limited only to functioning
#= on a website for which you have downloaded MagnaBlog, or unless you've
#= obtained special permission from the authors. 

#= You may edit/alter/expand the source code of this script as much as
#= you like, providing you do not redistribute your changes without
#= permission.
#=
#= This program is distributed in the hope that it will be useful,
#= but WITHOUT ANY WARRANTY; without even the implied warranty of
#= MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#===========================================================================
*/
  include('../config.inc.php');
  $mpage=new Page();
  $mpage->DisplayHeader();
  if (!$mpage->Admin)
  { ?>
    <?= $mpage->config[NotLoggedIn] ?>
  <?
    $mpage->DisplayFooter();
  }
if ($add)
  { ?>
    <h1>Add an action</h1>
    <form action=""><p>
     Create new action of: <input type="text" name="title" style="width: 228px;" /><br /><br />
     <input type="submit" name="addaction" value=":: Add It ::" />&nbsp;<input type="reset" value=":: Reset It ::" />
    </p></form>
    <a href="<?= $mpage->config[WebAddy] ?>/admin/index.php" title="Return To Index">Return to the index</a>
<?
  $mpage->DisplayFooter();
  }
  if ($addaction)
  {
   $sql = "INSERT INTO mblog_Doing SET Title=\"$title\"";
   $mpage->DoQuery($sql);
   echo "    <h1>DONE!</h1><br /><a href=\"" . $mpage->config[WebAddy] . "/admin/index.php\">Back To The Index</a>";
   $mpage->DisplayFooter();
  }
  if ($edit)
  {
   $sql = "SELECT * FROM mblog_Doing WHERE Id=\"$edit\"";
   $r = $mpage->DoQuery($sql, 1);
   $r = $r[0];
?>
    <h1>Edit Action '<?= $r[Title] ?>'</h1>
    <form action=""><p>
     <input type="hidden" name="id" value="<?= $r[Id] ?>" />
     Change action to <input type="text" name="title" value="<?= $r[Title] ?>" style="width: 228px;" /><br /><br />
     <input type="submit" name="changeaction" value=":: Edit It ::" />&nbsp;<input type="reset" value=":: Reset It ::" />
    </p></form>
    <a href="<?= $mpage->config[WebAddy] ?>/admin/index.php" title="Return To Index">Return to the index</a>
<?
  $mpage->DisplayFooter();
  }
  if ($changeaction)
  {
   $sql = "UPDATE mblog_Doing SET Title=\"$title\" where Id=\"$id\" ";
   $mpage->DoQuery($sql);
   echo "<h1>DONE!</h1><br /><a href=\"" . $mpage->config[WebAddy] . "/admin/index.php\">Back To The Index</a>";
   $mpage->DisplayFooter();
  }
  if ($delete)
  {
   echo "Click <a href=\"" . $mpage->config[WebAddy] . "/admin/doing.php?deleteconfirm=$delete\">here</a> if you really want to delete this action.<br /><br />Click <a href=\"" . $mpage->config[WebAddy] . "/admin/index.php\" title=\"Return To Index\">here</a> to return to the index.";
   $mpage->DisplayFooter();
  }
  if ($deleteconfirm)
  {
   $sql = "delete from mblog_Doing where Id=\"$deleteconfirm\" "; 
   $mpage->DoQuery($sql); 
   echo "<h1>DONE!</h1><br /><a href=\"" . $mpage->config[WebAddy] . "/admin/index.php\">Back To The Index</a>"; 
   $mpage->DisplayFooter();
  }
?>
    <h1>Actions</h1>
    <a href="<?= $mpage->config[WebAddy] ?>/admin/doing.php?add=1">Add Action</a><br /><br />
    <table>
<?
  $sql = "SELECT * FROM mblog_Doing ORDER BY Id asc";
  $r = $mpage->DoQuery($sql, 1);
  foreach ($r as $s) { ?>
      <tr>
        <td><?= $s[Title] ?></td>
        <td><a href="<?= $mpage->config[WebAddy] ?>/admin/doing.php?edit=<?= $s[Id] ?>" title="Edit">Edit</a></td>
        <td><a href="<?= $mpage->config[WebAddy] ?>/admin/doing.php?delete=<?= $s[Id] ?>" title="Delete">Delete</a></td>
      </tr>
<? } ?>
    </table>
    <br />
    <a href="<?= $mpage->config[WebAddy] ?>/admin/index.php" title="Return To Index">Return to the index</a>
<? $mpage->DisplayFooter(); ?>