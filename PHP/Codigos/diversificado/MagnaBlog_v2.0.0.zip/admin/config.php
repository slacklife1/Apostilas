<?
/*
#===========================================================================
#= Script               : MagnaBlog
#= Version              : 2.0.0
#= PHP Developer        : Shade @ Digital-Angst
#= Aesthetics Developer : Nikki @ Digital-Angst
#= Website: http://www.digital-angst.net/
#= Support: http://www.digital-angst.net/forums/
#===========================================================================
#= Copyright (c) 2003 Shade, Nikkki
#= You are free to use and modify this script as long as this header
#= section stays intact. This file is part of MagnaBlog.
#=
#= You are required to link to digital-angst.net somewhere on your blog.
#=
#= You may not redistribute (or resell) this script from your own site or
#= from anywhere else without special permission (purchase of rights) from
#= the authors.
#= 
#= You may not use code from any of the files contained in MangaBlog in
#= any other script unless that script is limited only to functioning
#= on a website for which you have downloaded MagnaBlog, or unless you've
#= obtained special permission from the authors. 

#= You may edit/alter/expand the source code of this script as much as
#= you like, providing you do not redistribute your changes without
#= permission.
#=
#= This program is distributed in the hope that it will be useful,
#= but WITHOUT ANY WARRANTY; without even the implied warranty of
#= MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#===========================================================================
*/
  include('../config.inc.php');
  $mpage=new Page();
  $mpage->DisplayHeader();
  if (!$mpage->Admin)
  { ?>
    <?= $mpage->config[NotLoggedIn] ?>
  <?
    $mpage->DisplayFooter();
  }
  if ($editconfig)
  {
   $sql = "UPDATE `mblog_Config` SET `Value` = '$blogname' WHERE `Id` = '1'";
   $mpage->DoQuery($sql);
   $sql = "UPDATE `mblog_Config` SET `Value` = '$email' WHERE `Id` = '2'";
   $mpage->DoQuery($sql);
   $sql = "UPDATE `mblog_Config` SET `Value` = '$adminname' WHERE `Id` = '3'";
   $mpage->DoQuery($sql);
   $sql = "UPDATE `mblog_Config` SET `Value` = '$notloggedin' WHERE `Id` = '4'";
   $mpage->DoQuery($sql);
   $sql = "UPDATE `mblog_Config` SET `Value` = '$webaddy' WHERE `Id` = '5'";
   $mpage->DoQuery($sql);
   $sql = "UPDATE `mblog_Config` SET `Value` = '$loginsubmit' WHERE `Id` = '6'";
   $mpage->DoQuery($sql);
   $sql = "UPDATE `mblog_Config` SET `Value` = '$loginremember' WHERE `Id` = '7'";
   $mpage->DoQuery($sql);
   $sql = "UPDATE `mblog_Config` SET `Value` = '$loginprename' WHERE `Id` = '8'";
   $mpage->DoQuery($sql);
   $sql = "UPDATE `mblog_Config` SET `Value` = '$loginbadpass' WHERE `Id` = '9'";
   $mpage->DoQuery($sql);
   $sql = "UPDATE `mblog_Config` SET `Value` = '$logintitle' WHERE `Id` = '10'";
   $mpage->DoQuery($sql);
   $sql = "UPDATE `mblog_Config` SET `Value` = '$loginshowbox' WHERE `Id` = '11'";
   $mpage->DoQuery($sql);
   $sql = "UPDATE `mblog_Config` SET `Value` = '$calshowsidebox' WHERE `Id` = '12'";
   $mpage->DoQuery($sql);
   $sql = "UPDATE `mblog_Config` SET `Value` = '$commentspost' WHERE `Id` = '13'";
   $mpage->DoQuery($sql);
   $sql = "UPDATE `mblog_Config` SET `Value` = '$commentssingle' WHERE `Id` = '14'";
   $mpage->DoQuery($sql);
   $sql = "UPDATE `mblog_Config` SET `Value` = '$commentsmultiple' WHERE `Id` = '15'";
   $mpage->DoQuery($sql);
   $sql = "UPDATE `mblog_Config` SET `Value` = '$commentsdisable' WHERE `Id` = '16'";
   $mpage->DoQuery($sql);
   $sql = "UPDATE `mblog_Config` SET `Value` = '$blognumpage' WHERE `Id` = '17'";
   $mpage->DoQuery($sql);
   $sql = "UPDATE `mblog_Config` SET `Value` = '$blogcutofftext' WHERE `Id` = '18'";
   $mpage->DoQuery($sql);
   $sql = "UPDATE `mblog_Config` SET `Value` = '$bloglinktitle' WHERE `Id` = '19'";
   $mpage->DoQuery($sql);
   echo "<h1>DONE!</h1><br /><a href=\"" . $mpage->config[WebAddy] . "/admin/index.php\">Back To The Index</a>"; 
   $mpage->DisplayFooter();
  }
   $sql = "SELECT * FROM mblog_Config";
   $r = $mpage->DoQuery($sql, 1);
   $r = $r[0];
   $r[Item] = $s[Value];
?>
    <h1>Configuration Settings</h1>
    <form action="">
    <table>
      <tr>
        <td><strong>Blog Name:</strong></td>
        <td><input name="blogname" value="<?= $mpage->config[BlogName] ?>" style="width: 200px;" /></td>
      </tr>
      <tr>
        <td><strong>Email:</strong></td>
        <td><input name="email" value="<?= $mpage->config[Email] ?>" style="width: 200px;" /></td>
      </tr>
      <tr>
        <td><strong>Admin Name:</strong></td>
        <td><input name="adminname" value="<?= $mpage->config[AdminName] ?>" style="width: 200px;" /></td>
      </tr>
      <tr>
        <td><strong>Not Logged In:</strong></td>
        <td><input name="notloggedin" value="<?= $mpage->config[NotLoggedIn] ?>" style="width: 200px;" /></td>
      </tr>
      <tr>
        <td><strong>Web Addy:</strong></td>
        <td><input name="webaddy" value="<?= $mpage->config[WebAddy] ?>" style="width: 200px;" /></td>
      </tr>
      <tr>
        <td><strong>Login Submit:</strong></td>
        <td><input name="loginsubmit" value="<?= $mpage->config[LoginSubmit] ?>" style="width: 200px;" /></td>
      </tr>
      <tr>
        <td><strong>Login Remember:</strong></td>
        <td><input name="loginremember" value="<?= $mpage->config[LoginRemember] ?>" style="width: 200px;" /></td>
      </tr>
      <tr>
        <td><strong>Login Pre-name:</strong></td>
        <td><input name="loginprename" value="<?= $mpage->config[LoginPreName] ?>" style="width: 200px;" /></td>
      </tr>
      <tr>
        <td><strong>Login Bad Pass:</strong></td>
        <td><input name="loginbadpass" value="<?= $mpage->config[LoginBadPass] ?>" style="width: 200px;" /></td>
      </tr>
      <tr>
        <td><strong>Login Title:</strong></td>
        <td><input name="logintitle" value="<?= $mpage->config[LoginTitle] ?>" style="width: 200px;" /></td>
      </tr>
      <tr>
        <td><strong>Login Show Box:</strong></td>
        <td>
          <select name="loginshowbox">
            <option value="0" <?= ($mpage->config[LoginShowBox] == 0) ? "selected=\"selected\"" : "" ?>>No</option>
            <option value="1" <?= ($mpage->config[LoginShowBox] == 1) ? "selected=\"selected\"" : "" ?>>Yes</option>
          </select>
        </td>
      </tr>
      <tr>
        <td><strong>Cal Show Side Box:</strong></td>
        <td>
          <select name="calshowsidebox">
            <option value="0" <?= ($mpage->config[CalShowSideBox] == 0) ? "selected=\"selected\"" : "" ?>>No</option>
            <option value="1" <?= ($mpage->config[CalShowSideBox] == 1) ? "selected=\"selected\"" : "" ?>>Yes</option>
          </select>
        </td>
      </tr>
      <tr>
        <td><strong>Comments Post:</strong></td>
        <td><input name="commentspost" value="<?= $mpage->config[CommentsPost] ?>" style="width: 200px;" /></td>
      </tr>
      <tr>
        <td><strong>Comments Single:</strong></td>
        <td><input name="commentssingle" value="<?= $mpage->config[CommentsSingle] ?>" style="width: 200px;" /></td>
      </tr>
      <tr>
        <td><strong>Comments Multiple:</strong></td>
        <td><input name="commentsmultiple" value="<?= $mpage->config[CommentsMultiple] ?>" style="width: 200px;" /></td>
      </tr>
      <tr>
        <td><strong>Comments Disable:</strong></td>
        <td><input name="commentsdisable" value="<?= $mpage->config[CommentsDisable] ?>" style="width: 200px;" /></td>
      </tr>
      <tr>
        <td><strong>Blog Num Page:</strong></td>
        <td><input name="blognumpage" value="<?= $mpage->config[BlogNumPage] ?>" style="width: 200px;" /></td>
      </tr>
      <tr>
        <td><strong>Blog Cut Off Text:</strong></td>
        <td>
          <select name="blogcutofftext">
            <option value="0" <?= ($mpage->config[CalShowSideBox] == 0) ? "selected=\"selected\"" : "" ?>>No</option>
            <option value="1" <?= ($mpage->config[CalShowSideBox] == 1) ? "selected=\"selected\"" : "" ?>>Yes</option>
          </select>
        </td>
      </tr>
      <tr>
        <td><strong>Blog Link Title:</strong></td>
        <td><input name="bloglinktitle" value="<?= $mpage->config[BlogLinkTitle] ?>" style="width: 200px;" /></td>
      </tr>
      <tr>
        <td colspan="2" style="text-align: center;"><input type="submit" name="editconfig" value=":: Do It ::" />&nbsp;<input type="reset" value=":: Reset All ::" /></td>
      </tr>
    </table>
    </form>
<a href="<?= $mpage->config[WebAddy] ?>/admin/index.php" title="Return To Index">Return to the index</a>
<? $mpage->DisplayFooter(); ?>