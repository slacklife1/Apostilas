<?
/*
#===========================================================================
#= Script               : MagnaBlog
#= Version              : 2.0.0
#= PHP Developer        : Shade @ Digital-Angst
#= Aesthetics Developer : Nikki @ Digital-Angst
#= Website: http://www.digital-angst.net/
#= Support: http://www.digital-angst.net/forums/
#===========================================================================
#= Copyright (c) 2003 Shade, Nikkki
#= You are free to use and modify this script as long as this header
#= section stays intact. This file is part of MagnaBlog.
#=
#= You are required to link to digital-angst.net somewhere on your blog.
#=
#= You may not redistribute (or resell) this script from your own site or
#= from anywhere else without special permission (purchase of rights) from
#= the authors.
#= 
#= You may not use code from any of the files contained in MangaBlog in
#= any other script unless that script is limited only to functioning
#= on a website for which you have downloaded MagnaBlog, or unless you've
#= obtained special permission from the authors. 

#= You may edit/alter/expand the source code of this script as much as
#= you like, providing you do not redistribute your changes without
#= permission.
#=
#= This program is distributed in the hope that it will be useful,
#= but WITHOUT ANY WARRANTY; without even the implied warranty of
#= MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#===========================================================================
*/
  include('../config.inc.php');
  $mpage=new Page();
  $mpage->DisplayHeader();
  if (!$mpage->Admin)
  { ?>
    <?= $mpage->config[NotLoggedIn] ?>
  <?
    $mpage->DisplayFooter();
  }
  if ($delete)
  {
     echo "Click <a href=\"" . $mpage->config[WebAddy] . "/admin/comments.php?deleteconfirm=$delete&entry=$entry\">here</a> if you really want to delete this comment.<br /><br />Click <a href=\"" . $mpage->config[WebAddy] . "/admin/index.php\" title=\"Return To Index\">here</a> to return to the index.";
     $mpage->DisplayFooter();
     exit();
  }
  if ($deleteconfirm)
  {
     $sql = "delete from mblog_Comments where Id=\"$deleteconfirm\" "; 
     $mpage->DoQuery($sql); 
      $sql = "update mblog_Blog set NumComments=(NumComments - 1) where Id = \"$entry\"";
      $mpage->DoQuery($sql);
     echo "<h1>DONE!</h1><br /><a href=\"" . $mpage->config[WebAddy] . "/admin/index.php\">Back To The Index</a>"; 
     $mpage->DisplayFooter();
     exit();
  }
?>
<?
  $doing_array = array();
  $sql = "select * from mblog_Doing order by Id desc";
  $b = $mpage->DoQuery($sql, 1);  
  foreach ($b as $r)
  {
   $doing_array[$r[Id]] = $r[Title];
  } 
  $sql = "SELECT *, UNIX_TIMESTAMP(Sent) AS date FROM mblog_Comments where itemnum=\"$id\" order by date desc";
  $b = $mpage->DoQuery($sql, 1);
  foreach ($b as $s) { 
?>
<h1><?= $s[Title] ?></h1>
<p class="content"><em><?= date("F j, Y @ g:i a",$s[date]) ?></em><br />
<strong>From:</strong> <a href="mailto:<?= $s[Email] ?>"><?= $s[Name] ?></a><br />
<? if ($s[SiteUrl]) { ?><strong>Site:</strong> <a href="<?= $s[SiteUrl] ?>" target="_blank" title="<?= $s[SiteUrl] ?>"><?= $s[SiteUrl] ?></a><br /><? } ?>
<strong><?= $doing_array[$s[Doing]] ?></strong> <?= $s[DoingTwo] ?><br />
<?= $s[Content] ?><br /><br />
<a href="<?= $mpage->config[WebAddy] ?>/admin/comments.php?delete=<?= $s[Id] ?>&entry=<?= $id ?>" title="Delete">Delete This Comment</a><br />
</p>
<? } ?>
<br /><a href="<?= $mpage->config[WebAddy] ?>/admin/index.php" title="Return To Index">Return to the index</a>
<? $mpage->DisplayFooter(); ?>