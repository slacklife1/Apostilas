<?
/*
#===========================================================================
#= Script               : MagnaBlog
#= Version              : 2.0.0
#= PHP Developer        : Shade @ Digital-Angst
#= Aesthetics Developer : Nikki @ Digital-Angst
#= Website: http://www.digital-angst.net/
#= Support: http://www.digital-angst.net/forums/
#===========================================================================
#= Copyright (c) 2003 Shade, Nikkki
#= You are free to use and modify this script as long as this header
#= section stays intact. This file is part of MagnaBlog.
#=
#= You are required to link to digital-angst.net somewhere on your blog.
#=
#= You may not redistribute (or resell) this script from your own site or
#= from anywhere else without special permission (purchase of rights) from
#= the authors.
#= 
#= You may not use code from any of the files contained in MangaBlog in
#= any other script unless that script is limited only to functioning
#= on a website for which you have downloaded MagnaBlog, or unless you've
#= obtained special permission from the authors. 

#= You may edit/alter/expand the source code of this script as much as
#= you like, providing you do not redistribute your changes without
#= permission.
#=
#= This program is distributed in the hope that it will be useful,
#= but WITHOUT ANY WARRANTY; without even the implied warranty of
#= MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#===========================================================================
*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title><?= $this->config[BlogName] ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"  />
<script type="text/javascript" src="http://www.digital-angst.net/scripts/blog/java.js"></script>
<style type="text/css">
<!--
 @import url("<?= $this->config[WebAddy] ?>/style.css");
-->
</style>
</head>
<body>
<div id="container">
  <div id="header"><img src="<?= $this->config[WebAddy] ?>/images/header.jpg" alt=""  /></div>
  <div id="boxes">
      <ul>
	<li><a href="<?= $this->config[WebAddy] ?>/index.php" title="Home page">Home</a></li>
	<li><a href="<?= $this->config[WebAddy] ?>/index.php?rss=1" title="Generate RSS feed">Generate RSS feed</a></li>
	<li><a href="http://validator.w3.org/check/referer" title="Help us keep our site up to snuff!">Valid XHTML</a></li>
<?
  // BEGIN BLOCK - Edit/Replace: these are your Admin and Logout functions
  if ($this->LoggedIn)
  { ?>
	<li><a href="<?= $this->config[WebAddy] ?>/admin/">Admin</a></li>
	<li><a href="<?= $_SERVER[SCRIPT_NAME] ?>?sc_logout=1">Logout</a></li>
<?  } 
  // END BLOCK 
?>
      </ul><? if ($this->LoggedIn) { echo "<br />"; } ?>
<?
  // BEGIN BLOCK  - Edit/Replace where you want to show the login box
  if ($this->config[LoginShowBox] == 1) 
  {
   if (!$this->LoggedIn)
   { ?>
    <br /><span class="boxtitle"><?= $this->config[LoginTitle] ?></span>
   <?
   $this->LoginBox();
   }
  }
  // END BLOCK 

  if ($this->config[LoginShowBox] == 0) 
  {
   echo "<br />";
  }

  // BEGIN BLOCK  - Edit/Replace where you want to show the calendar
  if ($this->config[CalShowSideBox] == 1) 
  {
   $now   = time();
   $year  = date("Y", $now);
   $month = date("n", $now);
   $day   = date("j", $now);
   $this->setDate($month, $year);
   $sql = "select *, UNIX_TIMESTAMP(Sent) AS date from mblog_Blog where MONTH(Sent) = $month"; 
   $r = $this->DoQuery($sql, 1);
   foreach ($r as $s)
   {
    $this->addEvent("<a href=\"" . $this->config[WebAddy] . "/archive.php?id=$s[Id]\" title=\"$s[Title]\">$s[Title]</a>", date("j",$s[date]));
   }
   $this->renderCalendar();
   echo $this->output;
  }
  // END BLOCK 
?>
  </div>
  <div id="content">