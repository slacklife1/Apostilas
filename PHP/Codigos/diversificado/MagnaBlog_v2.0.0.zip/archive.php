<?
/*
#===========================================================================
#= Script               : MagnaBlog
#= Version              : 2.0.0
#= PHP Developer        : Shade @ Digital-Angst
#= Aesthetics Developer : Nikki @ Digital-Angst
#= Website: http://www.digital-angst.net/
#= Support: http://www.digital-angst.net/forums/
#===========================================================================
#= Copyright (c) 2003 Shade, Nikkki
#= You are free to use and modify this script as long as this header
#= section stays intact. This file is part of MagnaBlog.
#=
#= You are required to link to digital-angst.net somewhere on your blog.
#=
#= You may not redistribute (or resell) this script from your own site or
#= from anywhere else without special permission (purchase of rights) from
#= the authors.
#= 
#= You may not use code from any of the files contained in MangaBlog in
#= any other script unless that script is limited only to functioning
#= on a website for which you have downloaded MagnaBlog, or unless you've
#= obtained special permission from the authors. 

#= You may edit/alter/expand the source code of this script as much as
#= you like, providing you do not redistribute your changes without
#= permission.
#=
#= This program is distributed in the hope that it will be useful,
#= but WITHOUT ANY WARRANTY; without even the implied warranty of
#= MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#===========================================================================
*/
  require("class.inc.php");
  $mpage=new Page();
  $mpage->DisplayHeader();
  $sql = "select *, UNIX_TIMESTAMP(Sent) AS date from mblog_Blog where Id = $id"; 
  $s = $mpage->DoQuery($sql, 1);
  $s = $s[0];
  $doing_array = array();
  $sql = "select * from mblog_Doing order by Id desc";
  $b = $mpage->DoQuery($sql, 1);  
  foreach ($b as $r)
  {
   $doing_array[$r[Id]] = $r[Title];
  } 
  $doing = $s[Doing];
  $s[Content] = preg_replace("#(^|[\n ])([\w]+?://[^ \"\n\r\t<]*)#is", "\\1<a href=\"\\2\" title=\"\">\\2</a>", $s[Content]); 
  $s[Content] = preg_replace("#(^|[\n ])((www|ftp)\.[^ \"\t\n\r<]*)#is", "\\1<a href=\"http://\\2\" title=\"\">\\2</a>", $s[Content]); 
  $s[Content] = preg_replace("#(^|[\n ])([a-z0-9&\-_.]+?)@([\w\-]+\.([\w\-\.]+\.)*[\w]+)#i", "\\1<a href=\"mailto:\\2@\\3\" title=\"\">\\2@\\3</a>", $s[Content]);
  $s[DoingTwo] = preg_replace("#(^|[\n ])([\w]+?://[^ \"\n\r\t<]*)#is", "\\1<a href=\"\\2\" title=\"\">\\2</a>", $s[DoingTwo]); 
  $s[DoingTwo] = preg_replace("#(^|[\n ])((www|ftp)\.[^ \"\t\n\r<]*)#is", "\\1<a href=\"http://\\2\" title=\"\">\\2</a>", $s[DoingTwo]); 
  $s[DoingTwo] = preg_replace("#(^|[\n ])([a-z0-9&\-_.]+?)@([\w\-]+\.([\w\-\.]+\.)*[\w]+)#i", "\\1<a href=\"mailto:\\2@\\3\" title=\"\">\\2@\\3</a>", $s[DoingTwo]);
?>
      <h1><?= $s[Title] ?></h1>
      <p class="content"><em><?= date("F j, Y @ g:ia",$s[date]) ?></em></p>
      <p class="content"><strong><?= $doing_array[$s[Doing]] ?></strong> <?= $s[DoingTwo] ?><br />
      <? if ($s[DisableComments] == Y) { ?><?= $mpage->config[CommentsDisable] ?><? } else { ?><a href="javascript:openScript('<?= $mpage->config[WebAddy] ?>/comment.php?itemnum=<?= $s[Id] ?>',520,300);"><?= $mpage->config[CommentsPost] ?></a><? if ($s[NumComments]) { ?> - <? if ($s[NumComments] == 1) { ?><?= $s[NumComments] ?> <?= $mpage->config[CommentsSingle] ?><? } else { ?><?= $s[NumComments] ?> <?= $mpage->config[CommentsMultiple] ?><? } } }?><br /><br />
      <?= $s[Content] ?></p>
<? $mpage->DisplayFooter(); ?>