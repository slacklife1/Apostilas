<?
/*
#===========================================================================
#= Script               : MagnaBlog
#= Version              : 2.0.0
#= PHP Developer        : Shade @ Digital-Angst
#= Aesthetics Developer : Nikki @ Digital-Angst
#= Website: http://www.digital-angst.net/
#= Support: http://www.digital-angst.net/forums/
#===========================================================================
#= Copyright (c) 2003 Shade, Nikkki
#= You are free to use and modify this script as long as this header
#= section stays intact. This file is part of MagnaBlog.
#=
#= You are required to link to digital-angst.net somewhere on your blog.
#=
#= You may not redistribute (or resell) this script from your own site or
#= from anywhere else without special permission (purchase of rights) from
#= the authors.
#= 
#= You may not use code from any of the files contained in MangaBlog in
#= any other script unless that script is limited only to functioning
#= on a website for which you have downloaded MagnaBlog, or unless you've
#= obtained special permission from the authors. 

#= You may edit/alter/expand the source code of this script as much as
#= you like, providing you do not redistribute your changes without
#= permission.
#=
#= This program is distributed in the hope that it will be useful,
#= but WITHOUT ANY WARRANTY; without even the implied warranty of
#= MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#===========================================================================
*/
class Page
{
   var $svr;
   var $IdNum;
   var $Admin;
   var $LoggedIn;
   var $Username;
   var $BadPassword;
   var $Unverified;
   var $SessionId;
   var $user;
   var $config = array();
   var $exec_arr = array();
   var $var_arr;
   var $svr_msconnect;
   var $svr_numq;
   var $svr_qustore  = array();
   var $svr_tmestore = array();
   var $svr_debug;
   var $month;
   var $year;
   var $output;
   var $cal;
   var $title;
   var $daysInMonth;
   var $events;
   var $errorReporting;
   function getmicrotime()
   {
    // tee hee, something from php.net!
    list($usec, $sec) = explode(" ",microtime());
    return ((float)$usec + (float)$sec);
   }
   function InitVars()
   {
    $this->exec_arr["mblog_standard"] = array();
    $this->exec_arr["mblog_standard"]["makesession"]  = 1;
    $this->exec_arr["mblog_standard"]["sqlsetup"]     = 1;
    $this->exec_arr["mblog_standard"]["sqlfile"]      = "config.inc.php";
    $this->exec_arr["mblog_standard"]["authorize"]    = 1;
    $this->exec_arr["mblog_standard"]["loginout"]     = 1;
    $this->exec_arr["mblog_standard"]["config"]       = 1;
   }
   function Page($nl = "mblog_standard")
   {
    $this->Initialize($nl);
   }
   function InitConfigVars()
   {
    $sql = "select Item, Value from mblog_Config";
    $r = $this->DoQuery($sql,1);
    foreach($r as $s)
    {
     $this->config[$s[Item]] = $s[Value];
    }
   }
   function Initialize($nl)
   {
    $this->InitVars();
    $this->var_arr = $this->exec_arr[$nl];
    if ($this->var_arr["makesession"]) $this->SessionSetup();
    if ($this->var_arr["sqlsetup"])    $this->SQLinit();
    if ($this->var_arr["authorize"])   $this->SetupInfo();
    if ($this->var_arr["loginout"])    $this->LoginOutProc();
    if ($this->var_arr["config"])      $this->InitConfigVars();
    if ($this->LoggedIn)
    {
     $sql = "update mblog_SessionTable set time = '".time()."' where SessionId = '$this->SessionId'";
     $this->DoQuery($sql);
     $sql = "update mblog_UserTable set LastSeen = NOW() where Id = $this->IdNum";
     $this->DoQuery($sql);
    }
   }
   function LoginOutProc()
   {
    global $sc_logout, $sc_login, $sc_pass, $sc_remem;
    if ($this->LoggedIn && $sc_logout)
    {
     $sql = "delete from mblog_SessionTable where SessionID = \"$this->SessionId\"";
     $this->DoQuery($sql);
     setcookie ("scu1", "", time() - 3600000);
     setcookie ("scp1", "", time() - 3600000);
     $this->user = array();
     $this->IdNum = 0;   
     $this->Admin = 0;   
     $this->LoggedIn = 0;      
     $this->Username = "ANONYMOUS";
     return;
    }
    elseif (!$this->LoggedIn && $sc_login)
    {
     $sql = "select * from mblog_UserTable where Login=\"$sc_login\" AND Pass=md5(concat(\"$sc_pass\", Salt));";
     $this->user = $this->DoQuery($sql,1);
     if (sizeof($this->user) && $this->user[0][Verified])
     {
      $this->user = $this->user[0];
      $sql = "insert into mblog_SessionTable set UserId = ".$this->user[Id].", SessionId = \"".$this->SessionId."\", Time = \"".time()."\" ";
      $this->DoQuery($sql);
      if ($sc_remem == "1") 
      {
       setcookie ("scu1", $this->user[Login], time() + 3600000);
       setcookie ("scp1", $this->user[Pass], time() + 3600000);
      }
      $this->Username = $this->user[Login];
      $this->IdNum    = $this->user[Id];
      $this->Admin    = $this->user[Admin];
      $this->LoggedIn = 1;
     }
     elseif (sizeof($this->user))
     {
      $this->Unverified  = 1;
     }
     else
     {
      $this->BadPassword = 1;
     }
    }
   }
   function SetupInfo()
   {
    $sql = "select mblog_UserTable.* from mblog_SessionTable left join mblog_UserTable on mblog_UserTable.Id = UserId where SessionId = \"$this->SessionId\" ";
    $this->user = $this->DoQuery($sql,1);
    if (!sizeof($this->user) && $_COOKIE["scu1"] && $_COOKIE["scp1"])
    {
     $this->CookieHandler();
    }
    if (!sizeof($this->user))
    {
     $this->IdNum = 0;
     $this->Admin = 0;
     $this->LoggedIn = 0;
     $this->Username = "ANONYMOUS";
     return;
    }
    $this->user = $this->user[0];
    $this->Username = $this->user[Login];
    $this->IdNum    = $this->user[Id];
    $this->Admin    = $this->user[Admin];
    $this->LoggedIn = 1;      
    return;
   }
   function CookieHandler()
   {
    $sql = "select * from mblog_UserTable where Login=\"$_COOKIE[scu1]\" AND Pass=\"$_COOKIE[scp1]\" AND Verified=1";
    $this->user = $this->DoQuery($sql,1);
    if (sizeof($this->user))
    {
     $sql = "insert into mblog_SessionTable (UserId, SessionId, Time) values (" . $this->user[0][Id]  . ", '$this->SessionId', '" . time() . "')";
     $this->DoQuery($sql);
     setcookie ("scu1", $_COOKIE[scu1], time() + 3600000);
     setcookie ("scp1", $_COOKIE[scp1], time() + 3600000);       
    }
    else
    {
     setcookie ("scu1", "", time() - 3600000);
     setcookie ("scp1", "", time() - 3600000);
    }
   }
   function SQLinit($debug = 0)
   {
    $numq =0;
    $this->svr_debug = $this->var_arr["sqldebug"];
    require($this->var_arr["sqlfile"]);
    $this->svr_msconnect = @mysql_connect($db_host, $db_login, $db_pass);
    @mysql_select_db($db_data);
    if (!$this->svr_msconnect)
    { ?>
      <? mysql_error() ?>
    <?
      exit;
    }
   }
   function DoQuery($sql, $assoc=0)
   {
    if ($this->svr_debug)
    {
     array_push($this->svr_qustore, $sql);
     $t1 = $this->getmicrotime();
    }
    $result = mysql_query($sql, $this->svr_msconnect);
    if ($this->svr_debug)
    {
     $t2 = $this->getmicrotime(); 
     array_push($this->svr_tmestore, $t2 - $t1);
    }
    if (mysql_errno())
    {
     echo "Error in mysql statement: " . mysql_error();
     $sq  = mysql_escape_string($sql);
     $err = mysql_escape_string(mysql_error()); 
     $sql = "insert into mblog_ErrorLog set Sql = '$sq', Error = '$err'";
     mysql_query($sql);
     echo "<P> $sql";
     exit;
    }
    $this->svr_numq++;
    if ($result === TRUE) return array();
    $res = array();
    if ($assoc)
     while ($row = mysql_fetch_array($result, MYSQL_ASSOC))
     array_push($res, $row);
    else
     while ($row = mysql_fetch_row($result)  ) 
     array_push($res, $row);
    return $res;
   }

   function SessionSetup()
   {
    if ($_COOKIE['PHPSESSID'])
     $idins = $_COOKIE['PHPSESSID'];
    elseif ($_GET['PHPSESSID'])
     $idins = $_GET['PHPSESSID'];
    elseif ($_POST['PHPSESSID'])
     $idins = $_POST['PHPSESSID'];
    else
     $idins = md5(microtime() . $_SERVER['REMOTE_ADDR']);
    if (!$_COOKIE['PHPSESSID']) session_id($idins);
     session_start();
    $this->SessionId = $idins;
   }
   function DisplayHeader()
   {
    if (file_exists('install.php'))
    {
     echo "Please ensure the install.php page is deleted";
     exit();
    }
    ini_set("url_rewriter.tags", "a=href,area=href,frame=src,iframe=src,input=src");
    include('header.inc.php');
   }
   function DisplayFooter()
   {
    include('footer.inc.php');
    exit();
   }
   function RandomChars($number)
   {
    list($usec, $sec) = explode(' ', microtime());
    $sdnum = (float) $sec + ((float) $usec * 100000);
    mt_srand($sdnum);
    while (strlen($ret) < $number)
    {
     $letter = chr(  mt_rand(48, 123) );
     if (preg_match("/\w/", $letter) && $letter != "_") $ret .= $letter;
    }
    return $ret;
   }
   function LoginBox()
   { 
    ?>
        <form method="post" action=""><p>
          <? if ($this->BadPassword) { ?>
             <span style="color: red"><?= $this->config[LoginBadPass] ?></span><br />
          <? } ?>
          <input name="sc_login" value="<?= $this->config[LoginPreName] ?>" onfocus="this.value=''" class="login1" /><br />
          <input name="sc_pass" type="password" onfocus="this.value=''" class="login1" /><br />
          <input name="sc_remem" value="1" type="checkbox" /> <?= $this->config[LoginRemember] ?><br />
          <input class="submit" type="submit" value="<?= $this->config[LoginSubmit] ?>" />
        </p></form>
   <? }
   function GetSetIntSessVar($min, $max, $default, $varname)
   {
    $vn  = $_SESSION["$varname"];
    $vn  = (is_numeric($vn)) ? $vn : $default;
    $vn  = (($vn >= "$min") && ($vn <= "$max")) ? floor($vn) : $default;
    $vng = $_GET["$varname"];
    $vng = (is_numeric($vng)) ? $vng : "";
    $vng = (($vng >= "$min") && ($vng <= "$max")) ? floor($vng) : "";
    $vn = (is_numeric($vng)) ? $vng : $vn;
    $_SESSION["$varname"] = $vn;
    return $vn;
   }
   function __construct()
   {
    $this->Calendar();
   }
   function Calendar()
   {
    $this->setDate(date("n", time()), date("Y", time()));
    $this->events=array();
    $this->errorReporting=true;
   }
   function setErrorReporting($bool)
   {
    if (!is_bool($bool))
    {
     $this->error("Calendar::setErrorReporting() failed: argument must be a boolean value");
    }
    else
    {
     $this->errorReporting=$bool;
    }
   }
   function error($msg)
   {
    if ($this->errorReporting===true)
    {
     echo "\n$msg\n";
    }
   }
   function setDate($month, $year, $title=NULL)
   {
    if ($month<1 || $month>12)
    {
     $this->error("Calendar::setDate() failed: month must be an integer from 1 to 12");
     return false;
    }
    else
    {
     $this->month=$month;
    }
    if ($year<1975)
    {
     $this->error("Calendar::setDate() failed: year must be a valid 4 digit year on or after 1975");
     return false;
    }
    else
    {
     $this->year=$year;
    }
    if ($title===NULL)
    {
     $this->title=date("F Y", mktime(0,0,0,$this->month,1,$this->year));
    }
    else
    {
     $this->title=$title;
    }	
     $this->daysInMonth=date("t", mktime(0,0,0,$this->month, 1, $this->year));
     return true;
   }
   function renderCalendar()
   {
    $this->cal=array();
    $this->cal=array_pad($this->cal, 42, NULL);
    $this->output='';
    $this->monthToCal();
    $this->createOutput();
   }
   function monthToCal()
   {
    $firstDay=date("w", mktime(0,0,0,$this->month, 1, $this->year));
    for ($x=$firstDay; $x<($this->daysInMonth+$firstDay); $x++)
    {
     $this->cal[$x]=$x-$firstDay+1;
    }
   }
   function createOutput()
   {
    $row=0;
    $eventsOutput='';
    $currentMonth=date("n", time());
    $currentDay=date("j", time());
    $currentYear=date("Y", time());
    if ($currentMonth==$this->month && $currentYear==$this->year)
    {
     $highlightToday=true;
    }
    else
    {
     $highLightToday=false;
    }
    $this->output.='	  <div id="calendar" class="calendar">'."\n";
    $this->output.='	    <table border="0" class="cal" id="cal">'."\n";
    $days=array("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat");
    $this->output.='	      <tr class="calTitle" id="calTitle">'."\n";
    $this->output.='	        <td colspan="7">'."\n";
    $this->output.="\t" . "\t  " . $this->title . "\n";
    $this->output.="	        </td>\n";
    $this->output.="	      </tr>\n";
    $this->output.='	      <tr class="calDaysTitleRow" id="calDaysTitleRow">'."\n";
    foreach ($days as $val)
    {
     $this->output.="	        <td>$val</td>\n";
    }
    $this->output.="	      </tr>\n";
    $this->output.='	      <tr class="calDaysRow" id="calDaysRow0">'."\n";
    foreach($this->cal as $key=>$val)
    {
     if ($val===NULL)
     {
      $this->output.='	        <td class="noDay">&nbsp;</td>'."\n";
     }
     else
     {
      if (!isset($keyStart))
      {
       $keyStart=$key;
      }
      if ($keyStart > 6) { $keyStart=0; }
      if ($highlightToday && $currentDay==$val)
      {
       $tdClass="today";
      }
      else
      {
       $tdClass=$days[$keyStart];
      }
      if ($this->hasEvents($val))
      {
       $eventsOutput.=$this->renderEventsByDay($val);
       $thisDay='<a href="javascript:void(0)" class="eventLink" onclick="document.getElementById(\'eventsForDay'.$val.'\').style.display=\'block\'">'.$val.'</a>';
      }
      else
      {
       $thisDay=$val;
      }
     $this->output.="	        <td class=\"$tdClass\">$thisDay</td>\n";
     $keyStart++;
    }
    if ((($key+1)%7) == 0)
    {
     $row++;
     $this->output.="	      </tr>\n";
     if ($row!=6)
     {
      $this->output.="	      <tr class=\"calDaysRow\" id=\"calDaysRow$row\">\n";
      }
     }
    }
    $this->output.="	    </table>\n";
    $this->output.=$eventsOutput;
    $this->output.="	  </div>\n";
   }
   function addEvent($event, $day)
   {
    if ($day<1 || $day>$this->daysInMonth)
    {
     $this->error("Calendar::addEvent() falied: the specified day is not valid for this month.  only ".$this->daysInMonth." days in this month");
     return false;
    }
    else
    {
     $this->events[$day][]=$event;
     return true;
    }
   }
   function getEventsByDay($day)
   {
    if ($this->hasEvents($day))
    {
     $events=$this->events[$day];
     return $events;
    }
    else
    {
     return false;
    }
   }
   function hasEvents($day)
   {
    if (!is_numeric($day))
    {
     $this->error("Calendar::hasEvents() failed: argument must be an integer between 1 and 31");
     return false;
    }
    if (isset($this->events[$day]))
    {
     if (count($this->events[$day])>0)
     {
      return true;
     }
     else
     {
      return false;
     }
    }
    else
    {
     return false;
    }
   }
   function renderEventsByDay($day)
   {
    if ($this->hasEvents($day))
    {
     $eventsOutput='	    <div class="events" id="eventsForDay'.$day.'" style="display: none">'."\n";
     $eventsOutput.="	      <span style='font-weight: bold; text-align: center;'>:: $this->title</span>\n";
     foreach($this->events[$day] as $key=>$val)
     {
      $rowClass=(($key+1) % 2) ? "eventRow" : "altEventRow";
      $eventsOutput.='	      <div class="'.$rowClass.'">'.$val.'</div>'."\n";
     }
     $eventsOutput.='	      <a href="javascript:void(0)" onclick="document.getElementById(\'eventsForDay'.$day.'\').style.display=\'none\'">[close]</a>';
     $eventsOutput.="	    </div>\n";
     return $eventsOutput;
    }
    else
    {
     return false;
    }
   }
   function getNextMonth()
   {
    $return=array();
    if ($this->month+1>12)
    {
     $return['month']=1;
     $return['year']=$this->year+1;
    }
    else
    {
     $return['month']=$this->month+1;
     $return['year']=$this->year;
    }
    return $return;
   }
   function getPrevMonth()
   {
    $return=array();
    if ($this->month-1<1)
    {
     $return['month']=12;
     $return['year']=$this->year-1;
    }
    else
    {
     $return['month']=$this->month-1;
     $return['year']=$this->year;
    }
    return $return;
   }
}
?>