<?
/*
#===========================================================================
#= Script               : MagnaBlog
#= Version              : 2.0.0
#= PHP Developer        : Shade @ Digital-Angst
#= Aesthetics Developer : Nikki @ Digital-Angst
#= Website: http://www.digital-angst.net/
#= Support: http://www.digital-angst.net/forums/
#===========================================================================
#= Copyright (c) 2003 Shade, Nikkki
#= You are free to use and modify this script as long as this header
#= section stays intact. This file is part of MagnaBlog.
#=
#= You are required to link to digital-angst.net somewhere on your blog.
#=
#= You may not redistribute (or resell) this script from your own site or
#= from anywhere else without special permission (purchase of rights) from
#= the authors.
#= 
#= You may not use code from any of the files contained in MangaBlog in
#= any other script unless that script is limited only to functioning
#= on a website for which you have downloaded MagnaBlog, or unless you've
#= obtained special permission from the authors. 

#= You may edit/alter/expand the source code of this script as much as
#= you like, providing you do not redistribute your changes without
#= permission.
#=
#= This program is distributed in the hope that it will be useful,
#= but WITHOUT ANY WARRANTY; without even the implied warranty of
#= MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#===========================================================================
*/
  include('class.inc.php');
  $mpage=new Page();
  $mpage->DisplayHeader();
  function CutOff($text, $id="")
  {
   $chars = 250;
   return (strlen($text) > $chars) ? substr($text,0,($chars - 3)). '...' : $text;
  }
  if ($rss)
  { ?>
    <h1>RSS</h1><br />
    To set up an RSS feed, please use the following URL:<br /><br />
    <?= $mpage->config[WebAddy] ?>/rss.php<br />
  <?
    $mpage->DisplayFooter();
  }

  $page = ($page >= 1) ? floor($page) : 1;
  $lim  = 0;
  $numpage = $mpage->config[BlogNumPage];
  $limit = " limit " . ($page - 1) * $numpage . ", $numpage ";
  $news  = (is_numeric($news)) ? $news : "";
  $limitclause = (!$news) ? "$limit" : "";
  $sql = "select *, UNIX_TIMESTAMP(Sent) AS date from mblog_Blog order by Id desc $limitclause";
  $b = $mpage->DoQuery($sql, 1);
  $sql = "select count(*) from mblog_Blog";
  $tpsc = $mpage->DoQuery($sql);
  $tpsc = $tpsc[0][0];
  $tpsc = ($tpsc) ? $tpsc : 1;
  $tpsc = floor(($tpsc - 1) / $numpage) + 1;
  $sql = "select count(Id) from mblog_Blog";
  $c = $mpage->DoQuery($sql);
  $c = $c[0][0];
  if ($c <= $numpage) { } else { ?>
    <form method="get" action=""><p><strong>Past Entries:</strong> <select name="page" onchange="submit()"><? for ($x = 1; $x <= $tpsc; $x++) { ?><option value="<?= $x ?>" <?= ($page == $x) ? "selected=\"selected\"" : "" ?>> Page <?= $x ?></option><? } ?></select></p></form>
<? } 
  $sql = "select *, UNIX_TIMESTAMP(Sent) AS date from mblog_Blog order by Id desc $limitclause";
  $b = $mpage->DoQuery($sql, 1);
  $sql = "select * from mblog_Doing order by Id desc";
  $a = $mpage->DoQuery($sql, 1);  
  $doing_array = array();
  foreach ($a as $r)
  {
   $doing_array[$r[Id]] = $r[Title];
  } 
  foreach ($b as $s) {
  $s[Content] = preg_replace("#(^|[\n ])([\w]+?://[^ \"\n\r\t<]*)#is", "\\1<a href=\"\\2\" title=\"\">\\2</a>", $s[Content]); 
  $s[Content] = preg_replace("#(^|[\n ])((www|ftp)\.[^ \"\t\n\r<]*)#is", "\\1<a href=\"http://\\2\" title=\"\">\\2</a>", $s[Content]); 
  $s[Content] = preg_replace("#(^|[\n ])([a-z0-9&\-_.]+?)@([\w\-]+\.([\w\-\.]+\.)*[\w]+)#i", "\\1<a href=\"mailto:\\2@\\3\" title=\"\">\\2@\\3</a>", $s[Content]);
  $s[DoingTwo] = preg_replace("#(^|[\n ])([\w]+?://[^ \"\n\r\t<]*)#is", "\\1<a href=\"\\2\" title=\"\">\\2</a>", $s[DoingTwo]); 
  $s[DoingTwo] = preg_replace("#(^|[\n ])((www|ftp)\.[^ \"\t\n\r<]*)#is", "\\1<a href=\"http://\\2\" title=\"\">\\2</a>", $s[DoingTwo]); 
  $s[DoingTwo] = preg_replace("#(^|[\n ])([a-z0-9&\-_.]+?)@([\w\-]+\.([\w\-\.]+\.)*[\w]+)#i", "\\1<a href=\"mailto:\\2@\\3\" title=\"\">\\2@\\3</a>", $s[DoingTwo]);
?>      <h1><?= $s[Title] ?></h1>
      <p class="content"><em><?= date("F j, Y @ g:ia",$s[date]) ?></em></p>
      <p class="content"><strong><?= $doing_array[$s[Doing]] ?></strong> <?= $s[DoingTwo] ?></p>
<?
   if ($mpage->config[BlogCutOffText] == 1)
   {
    $string = strip_tags($s[Content], '');
   ?>
       <p><?= CutOff($string, $s[Id]); ?><br />
   <? }
   else
   { ?>
    <p><?= $s[Content] ?><br />
   <? } ?>
     <a href="<?= $mpage->config[WebAddy] ?>/archive.php?id=<?= $s[Id] ?>"><?= $mpage->config[BlogLinkTitle] ?></a> - <? if ($s[DisableComments] == Y) { ?><?= $mpage->config[CommentsDisable] ?><? } else { ?><a href="javascript:openScript('<?= $mpage->config[WebAddy] ?>/comment.php?itemnum=<?= $s[Id] ?>',520,300);"><?= $mpage->config[CommentsPost] ?></a><? if ($s[NumComments]) { ?> - <? if ($s[NumComments] == 1) { ?><?= $s[NumComments] ?> <?= $mpage->config[CommentsSingle] ?><? } else { ?><?= $s[NumComments] ?> <?= $mpage->config[CommentsMultiple] ?><? } } ?>
    <? } ?><br /><br /></p><? } 
  if ($c <= $numpage) { } else { ?>
    <form method="get" action=""><p><strong>Past Entries:</strong> <select name="page" onchange="submit()"><? for ($x = 1; $x <= $tpsc; $x++) { ?><option value="<?= $x ?>" <?= ($page == $x) ? "selected=\"selected\"" : "" ?>> Page <?= $x ?></option><? } ?></select></p></form>
<? } $mpage->DisplayFooter(); ?>