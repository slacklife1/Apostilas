<?
/*
#===========================================================================
#= Script               : MagnaBlog
#= Version              : 2.0.0
#= PHP Developer        : Shade @ Digital-Angst
#= Aesthetics Developer : Nikki @ Digital-Angst
#= Website: http://www.digital-angst.net/
#= Support: http://www.digital-angst.net/forums/
#===========================================================================
#= Copyright (c) 2003 Shade, Nikkki
#= You are free to use and modify this script as long as this header
#= section stays intact. This file is part of MagnaBlog.
#=
#= You are required to link to digital-angst.net somewhere on your blog.
#=
#= You may not redistribute (or resell) this script from your own site or
#= from anywhere else without special permission (purchase of rights) from
#= the authors.
#= 
#= You may not use code from any of the files contained in MangaBlog in
#= any other script unless that script is limited only to functioning
#= on a website for which you have downloaded MagnaBlog, or unless you've
#= obtained special permission from the authors. 

#= You may edit/alter/expand the source code of this script as much as
#= you like, providing you do not redistribute your changes without
#= permission.
#=
#= This program is distributed in the hope that it will be useful,
#= but WITHOUT ANY WARRANTY; without even the implied warranty of
#= MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#===========================================================================
*/
  setcookie ('name', $name,time()+31536000);
  setcookie ('siteurl', $siteurl,time()+31536000);
  setcookie ('email', $email,time()+31536000);
  if ($deletecookie)
  {
   setcookie ('name', $name, time()-60);
   setcookie ('siteurl', $siteurl, time()-60);
   setcookie ('email', $email, time()-60);
   echo "<h3>DONE!</h3>";    
   exit();
  }
  include('config.inc.php');
  $mpage=new Page();
  if ($comment)
   {
    $content = eregi_replace('([[:alnum:]]+)://([^[:space:]]*)([[:alnum:]#?/&=])', '<a href=\"\1://\2\3\" target=\"_blank\">\1://\2\3</a>', $content);
    $content = str_replace("\r", "<br />",$content);
    $content = stripslashes($content);
    $content = addslashes($content);
    if((!$name) || (!$email) || (!$content))
     {
      echo "<strong>Sorry, you forgot some required information...</strong><br />Try Again"; 
      exit();
     }
    else {
      $title = $_POST['title'];
      $title = ($title) ? trim($title) : "No title";
      $sql = "insert into mblog_Comments (ItemNum, Name, IP, Title, SiteUrl, IsPrivate, Content, Email, Sent)
        values (\"$itemnum\", \"$name\", \"$REMOTE_ADDR\", \"$title\", \"$siteurl\", \"$isprivate\", \"$content\", \"$email\", NOW())";
      $mpage->DoQuery($sql);
      $sql = "update mblog_Blog set NumComments=(NumComments + 1) where Id = \"$itemnum\"";
      $mpage->DoQuery($sql);
      $admin = $mpage->config[AdminName];
      $website_addy = $mpage->config[WebAddy];
      $mail = $mpage->config[Email];
      $blogname = $mpage->config[BlogName];
      $subject = "Comment Posted On $blogname";
      $message .= "Hello $admin,<br /><br />"; 
      $message .= "This is your email notification that a comment has been posted at $blogname.<br />"; 
      $message .= "To view, please login at: <a href=\"$website_addy/admin/\">$website_addy/admin/</a> <br /><br />"; 
      $message .= "Sincerely,<br />"; 
      $message .= "Your friendly bot<br />"; 
      $message .= "----------------------<br />"; 
      $message .= "Powered by Magnablog - <a href=\"http://www.digital-angst.net\">http://www.digital-angst.net</a>"; 
      $headers .= "From: $mail\n";
      $headers .= "MIME-Version: 1.0\n";
      $headers .= "Content-type: text/html; charset=iso-8859-1\n";
      mail($mail, $subject, $message, $headers);
      echo "<h3>DONE!</h3>"; 
      exit();
     }
   }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>Post Comment</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"  />
<style type="text/css">
<!--
 @import url("style.css");
-->
</style>
</head>
<body>
<?
  $sql = "SELECT *, UNIX_TIMESTAMP(Sent) AS date FROM mblog_Comments where itemnum=\"$itemnum\" order by date desc";
  $b = $mpage->DoQuery($sql, 1);
  foreach ($b as $s) { 
?>
<p><strong><?= $s[Title] ?></strong> - <?= date("F j, Y @ g:i a",$s[date]) ?><br />
From: <a href="mailto:<?= $s[Email] ?>"><?= $s[Name] ?></a><br />
<? if ($s[SiteUrl]) { ?>Site: <a href="<?= $s[SiteUrl] ?>" title="<?= $s[SiteUrl] ?>"><?= $s[SiteUrl] ?></a><br /><? } ?>
<strong><?= $s[Doing] ?></strong> <?= $s[DoingTwo] ?><br />
<? if ($s[IsPrivate] == "Yes") { echo "<strong>Private Comment to $admin</strong>"; } else { ?><?= $s[Content] ?><? } ?></p>
<hr />
<? } ?>
<h3>Post A New Comment</h3>
<form method="post" action="">
<p>
  <strong>Title Of Your Comment:</strong> (Not Required)<br /><input type="text" name="title" value="" style="width: 350px;" /><br /><br />
  <strong>Your Name:</strong> (Required)<br /><input type="text" name="name" value="<?= $_COOKIE['name'] ?>" style="width: 350px;" /><br /><br />
  <strong>Email:</strong> (Required)<br /><input type="text" name="email" value="<?= $_COOKIE['email'] ?>" style="width: 350px;" /><br /><br />
  <strong>Site Url:</strong> (Not Required)<br /><input type="text" name="siteurl" value="<?= $_COOKIE['siteurl'] ?>" style="width: 350px;" /><br /><br />
  <strong>Private Comment To <?= $mpage->config[AdminName] ?>?</strong> (Required)
  <select name="isprivate">
    <option>No</option>
    <option>Yes</option>
  </select><br /><br />
  <strong>Comment:</strong> (Required)<br />
  <textarea name="content" cols="66" rows="10"></textarea><br /><br />
  <input type="submit" name="comment" value=":: Submit ::" />&nbsp;<input type="reset" value=":: Reset All ::" /><br /><br />
  Your IP, <strong><? echo "$REMOTE_ADDR"; ?></strong> has been logged<br />
</p>
</form>
<? if (isset($_COOKIE['name'])) { ?>
<form method="post" action="">
 <p>
 <input type="submit" name="deletecookie" value=":: Delete Cookies On This Computer ::" />
 </p>
</form>
<? } ?>
</body>
</html>