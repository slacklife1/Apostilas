<?
/*
#===========================================================================
#= Script               : MagnaBlog
#= Version              : 2.0.0
#= PHP Developer        : Shade @ Digital-Angst
#= Aesthetics Developer : Nikki @ Digital-Angst
#= Website: http://www.digital-angst.net/
#= Support: http://www.digital-angst.net/forums/
#===========================================================================
#= Copyright (c) 2003 Shade, Nikkki
#= You are free to use and modify this script as long as this header
#= section stays intact. This file is part of MagnaBlog.
#=
#= You are required to link to digital-angst.net somewhere on your blog.
#=
#= You may not redistribute (or resell) this script from your own site or
#= from anywhere else without special permission (purchase of rights) from
#= the authors.
#= 
#= You may not use code from any of the files contained in MangaBlog in
#= any other script unless that script is limited only to functioning
#= on a website for which you have downloaded MagnaBlog, or unless you've
#= obtained special permission from the authors. 

#= You may edit/alter/expand the source code of this script as much as
#= you like, providing you do not redistribute your changes without
#= permission.
#=
#= This program is distributed in the hope that it will be useful,
#= but WITHOUT ANY WARRANTY; without even the implied warranty of
#= MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#===========================================================================
*/
if($submit) {
   function RandomChars($number)
   {
        list($usec, $sec) = explode(' ', microtime());
        $sdnum = (float) $sec + ((float) $usec * 100000);
        mt_srand($sdnum);
        while (strlen($ret) < $number)
        {
           $letter = chr(  mt_rand(48, 123) );
           if (preg_match("/\w/", $letter) && $letter != "_") $ret .= $letter;
        }
        return $ret;
   }
  mysql_pconnect("$db_host","$db_login","$db_pass");
  mysql_select_db("$db_data");
  $time = time();
  $q = array();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>Magnablog - Installation</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"  />
<script type="text/javascript" src="java.js"></script>
<style type="text/css">
<!--
 @import url("style.css");
#container2 {
	padding: 0px;
	margin: auto;
	width: 602px;
	text-align: justify;
	border: 1px solid #FF0000;
}
-->
</style>
</head>
<body>
<div id="container2">
  <img src="images/header.jpg" alt="" style="border-bottom: 1px solid #a00000;" /><br /><br />
   <div id="form">
<?
  $q[]="DROP TABLE IF EXISTS `mblog_Blog`;";
  $q[]="CREATE TABLE `mblog_Blog` (
  `Id` int(11) NOT NULL auto_increment,
  `NumComments` int(11) NOT NULL default '0',
  `Title` varchar(250) default NULL,
  `Doing` tinyint(2) default '1',
  `DoingTwo` varchar(250) default NULL,
  `Content` text NOT NULL,
  `Sent` datetime default NULL,
  `DisableComments` char(1) NOT NULL default 'N',
  PRIMARY KEY  (`Id`)
) TYPE=MyISAM;";
  $q[]="INSERT INTO `mblog_Blog` VALUES (1, 0, 'Blogrolling, the angsty way', 1, 
'Music of some sort', 'Congratulations, your blog seems to be working. Feel free 
to delete this, as everything seems to be perfect. ', '2004-01-15 12:00:00', 'N');";
  $q[]="DROP TABLE IF EXISTS `mblog_Comments`;";
  $q[]="CREATE TABLE `mblog_Comments` (
  `Id` int(11) NOT NULL auto_increment,
  `ItemNum` int(11) default NULL,
  `Name` varchar(250) default NULL,
  `IP` varchar(15) default NULL,
  `SiteUrl` varchar(250) default NULL,
  `Email` varchar(250) default NULL,
  `Title` varchar(250) default NULL,
  `IsPrivate` char(3) NOT NULL default 'No',
  `Content` text NOT NULL,
  `Sent` datetime default NULL,
  PRIMARY KEY  (`Id`)
) TYPE=MyISAM;";
  $q[]="DROP TABLE IF EXISTS `mblog_Config`;";
  $q[]="CREATE TABLE `mblog_Config` (
  `Id` int(11) NOT NULL auto_increment,
  `Item` varchar(50) NOT NULL default '',
  `Value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`Id`)
) TYPE=MyISAM;";
  $q[]="INSERT INTO `mblog_Config` VALUES (1, 
'BlogName', '" . $blogname . "');";
  $q[]="INSERT INTO `mblog_Config` VALUES (2, 
'Email', '" . $email . "');";
  $q[]="INSERT INTO `mblog_Config` VALUES (3, 
'AdminName', '" . $admin . "');";
  $q[]="INSERT INTO `mblog_Config` VALUES (4, 
'NotLoggedIn', 'You must be logged in to be here.');";
  $q[]="INSERT INTO `mblog_Config` VALUES (5, 
'WebAddy', '". $website_addy . "');";
  $q[]="INSERT INTO `mblog_Config` VALUES (6, 
'LoginSubmit', 'Log Me In Dammit');";
  $q[]="INSERT INTO `mblog_Config` VALUES (7, 
'LoginRemember', 'Remember Me');";
  $q[]="INSERT INTO `mblog_Config` VALUES (8, 
'LoginPreName', 'Login!');";
  $q[]="INSERT INTO `mblog_Config` VALUES (9, 
'LoginBadPass', 'Bad Password, try again.');";
  $q[]="INSERT INTO `mblog_Config` VALUES (10, 
'LoginTitle', 'Login To Admin');";
  $q[]="INSERT INTO `mblog_Config` VALUES (11, 
'LoginShowBox', '1');";
  $q[]="INSERT INTO `mblog_Config` VALUES (12, 
'CalShowSideBox', '1');";
  $q[]="INSERT INTO `mblog_Config` VALUES (13, 
'CommentsPost', 'Comment On This');";
  $q[]="INSERT INTO `mblog_Config` VALUES (14, 
'CommentsSingle', 'Comment');";
  $q[]="INSERT INTO `mblog_Config` VALUES (15, 
'CommentsMultiple', 'Comments');";
  $q[]="INSERT INTO `mblog_Config` VALUES (16, 
'CommentsDisable', 'I have Disabled Comments For This Post...');";
  $q[]="INSERT INTO `mblog_Config` VALUES (17, 
'BlogNumPage', '5');";
  $q[]="INSERT INTO `mblog_Config` VALUES (18, 
'BlogCutOffText', '1');";
  $q[]="INSERT INTO `mblog_Config` VALUES (19, 
'BlogLinkTitle', 'Link');";
  $q[]="DROP TABLE IF EXISTS `mblog_Doing`;";
  $q[]="CREATE TABLE `mblog_Doing` (
  `Id` int(11) NOT NULL auto_increment,
  `Title` varchar(250) NOT NULL default '',
  PRIMARY KEY  (`Id`)
) TYPE=MyISAM;";
  $q[]="INSERT INTO `mblog_Doing` VALUES (1, 'Listening To:');";
  $q[]="INSERT INTO `mblog_Doing` VALUES (2, 'Reading:');";
  $q[]="INSERT INTO `mblog_Doing` VALUES (3, 'Watching:');";
  $q[]="INSERT INTO `mblog_Doing` VALUES (4, 'Thinking Of:');";
  $q[]="INSERT INTO `mblog_Doing` VALUES (5, 'Surfing:');";
  $q[]="INSERT INTO `mblog_Doing` VALUES (6, 'Feeling:');";
  $q[]="DROP TABLE IF EXISTS `mblog_ErrorLog`;";
  $q[]="CREATE TABLE `mblog_ErrorLog` (
  `Id` int(11) NOT NULL auto_increment,
  `SQL` text,
  `Error` text,
  PRIMARY KEY  (`Id`)
) TYPE=MyISAM;";
  $q[]="DROP TABLE IF EXISTS `mblog_SessionTable`;";
  $q[]="CREATE TABLE `mblog_SessionTable` (
  `Id` int(11) NOT NULL auto_increment,
  `UserId` int(11) default NULL,
  `SessionId` char(50) default NULL,
  `time` int(11) NOT NULL default '0',
  PRIMARY KEY  (`Id`),
  KEY `Opt` (`SessionId`)
) TYPE=MyISAM;";
  $q[]="DROP TABLE IF EXISTS `mblog_UserTable`;";
  $q[]="CREATE TABLE `mblog_UserTable` (
  `Id` int(11) NOT NULL auto_increment,
  `Login` varchar(15) default NULL,
  `Pass` varchar(32) NOT NULL default '',
  `Email` varchar(50) NOT NULL default '',
  `Admin` int(11) NOT NULL default '0',
  `Salt` varchar(10) NOT NULL default '',
  `Verified` tinyint(4) default '0',
  `Verify` tinyint(4) NOT NULL default '0',
  `DateJoined` datetime NOT NULL default '0000-00-00 00:00:00',
  `LastSeen` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`Id`),
  UNIQUE KEY `Login` (`Login`)
) TYPE=MyISAM;";
            $salt = randomchars(10);
            $pws  = md5($_POST[pass] . $salt);
  $q[]="INSERT INTO `mblog_UserTable` VALUES (1, '" . $admin . "',
 '" . $pws . "', '" . $email . "', 1,
 '" . $salt . "', 1, 1, '2004-01-15 12:00:00', '2004-01-15 12:00:00');";
  echo "<h1>Creating tables</h1><p>";
  foreach($q as $q2do) {
   echo "<pre>$q2do</pre>";
   $q2do = mysql_query($q2do) or die("Magnablog database creation failed. This is likely because the database connection is incorrect. Please hit the back button and try again.");
  }
  $fp = fopen("$path/config.inc.php", 'w'); 
  if (!$fp)  { 
   print 'Could not open config file for writing - Please ensure it is has the proper permissions'; 
   exit();
  } 
  $config_data = '<?php'."";
  $config_data .= "\n// Configuration info for MagnaBlog \n// Do not change anything in this file!\n\n";
  $config_data .= '$path = \'' . $path . '\';' . "\n";  
  $config_data .= '$db_host = \'' . $db_host . '\';' . "\n";
  $config_data .= '$db_data = \'' . $db_data . '\';' . "\n";
  $config_data .= '$db_login = \'' . $db_login . '\';' . "\n";
  $config_data .= '$db_pass = \'' . $db_pass . '\';' . "\n\n";
  $config_data .= 'include_once' . '(' . '\'class.inc.php\'' . ')' . ';' . "\n\n";
  $config_data .= '?' . '>';
  fwrite($fp, $config_data);
  fclose($fp); 
   echo '</p>';
?>
  <h1>Done</h1><br />
  Just a couple more steps until you're finished.<br />
  <ul>
    <li>Delete this file (<strong>./install.php</strong>)</li>
    <li>Change config file settings to read only (<strong>./config.inc.php</strong>)</li>
    <li>Click <a href="index.php" title="Index page">here</a> to go to the index page</li>
    <li>Please remember to link to <a href="http://www.digital-angst.net/" title="Digital-angst.net">Digital-angst.net</a></li>
  </ul>
  <strong>Happy Blogging!</strong><br /><br />
   </div>
</div>
</body>
</html>
<? 
 exit();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>Magnablog - Installation</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"  />
<script type="text/javascript" src="java.js"></script>
<style type="text/css">
<!--
 @import url("style.css");
#container2 {
	padding: 0px;
	margin: auto;
	width: 602px;
	text-align: justify;
	border: 1px solid #FF0000;
}
-->
</style>
</head>
<body>
<div id="container2">
  <img src="images/header.jpg" alt="" style="border-bottom: 1px solid #a00000;" /><br /><br />
   <div id="form">
     <h1>abstract</h1>
     <p>Magnablog is a light yet incredibly powerful set of blog webware, boasting an object oriented PHP system, a web-based install, and several admin features. It has built-in javascript and integrated CSS, coded in XHTML Strict. Complete with RSS feed generation and options to make your journal or online diary a personal place, Mangablog is a tool to power your site, but give you the flexibility you deserve.</p>
     <h1>features</h1>
     <ul>
       <li>Object Oriented PHP</li>
       <li>Standardized MySQL functions</li>
       <li>Web based install</li>
       <li>Line breaks (pressing enter) automatically converted to &#60;br /&#62;</li>
       <li>Actions and blog entries autolink URLs, allowing you to save time typing in code</li>
       <li>Database configuration, making Magnablog <strong>almost</strong> completely web based, save the hardcore customizer.</li>
       <li>Commenting enabled on blog entries by your readers</li>
       <li>Private commenting to the admin optional</li>
       <li>Livejounal style blogging, including actions such as "listening to", "reading", "surfing", "feeling", "thinking of", and "watching". You can edit, delete and add actions at will.</li>
       <li>Fast database connection, allowing you to add, edit and delete your posts as you please.</li>
       <li>Admin area, protected by MD5 encryption and a process called Salting, allows you to configure your blog and not have to worry about security.</li>
       <li>Month to month calendar for quick access to entries</li>
       <li>Autogenerated RSS feed</li>
       <li>Option to show full entries, or cut off at a definable amount of characters</li>
       <li>Configuration settings to disable calendar and loginbox functions, as well as many other variables</li>
     </ul>
     <h1>directions</h1>
     <p>1. Fill in paths, information and passwords however you please.<br />
     2. Hit :: Install It ::.<br />
     3. Change permissions of file "config.inc.php" to read only.<br />
     4. Delete file "install.php" (this file)<br />
     5. Please remember to link to Digital-angst.net<br /></p>
<?
	if(!is_writable("./config.inc.php")) {
		echo "<h1>WARNING</h1><br />File: config.inc.php could not be written to.<br />Please CHMOD this file to 777, then refresh this page.<br /><br />";
	 	exit();
	}
?>
     <h1>install form</h1>
     <form action="" method="post">
     <table style="margin-left: auto; margin-right: auto;">
       <tr>
         <td>Website Addresss:</td>
	 <td><input name="website_addy" type="text" size="50" value="<? echo "http://$HTTP_HOST" . dirname($PHP_SELF); ?>" /></td>
       </tr>
       <tr>
 	 <td>Root Path:</td>
	 <td><input name="path" type="text" size="50" value="<? echo dirname($SCRIPT_FILENAME); ?>" /></td>
       </tr>
       <tr>
	 <td>Title Of Your Blog:</td>
	 <td><input name="blogname" type="text" size="50" /></td>
       </tr>
       <tr>
	 <td>Database Hostname:</td>
  	 <td><input name="db_host" value="localhost" type="text" size="50" /></td>
       </tr>
       <tr>
	 <td>Database Username:</td>
	 <td><input name="db_login" type="text" size="50" /></td>
       </tr>
       <tr>
	 <td>Database Password:</td>
	 <td><input name="db_pass" type="text" size="50" /></td>
       </tr>
       <tr>
	 <td>Database Name:</td>
	 <td><input name="db_data" type="text" size="50" /></td>
       </tr>
       <tr>
	 <td>Username:</td>
	 <td><input name="admin" type="text" size="50" /></td>
       </tr>
       <tr>
	 <td>Password:</td>
  	 <td><input name="pass" type="password" size="51" /></td>
       </tr>
       <tr>
	 <td>Email:</td>
	 <td><input name="email" type="text" size="50" /></td>
       </tr>
     </table>
     <div style="width: 250px; margin-left: auto; margin-right: auto;">
       <br />
       <input type="submit" name="submit" value=":: Install It ::" class="button" />&nbsp;<input type="reset" value=":: Reset All ::" class="button" />
     </div>
     </form>
  </div>
</div>
</body>
</html>