<?php
/***************************************
** Title........: Exmaple for XML DB Interpreter
** Filename.....: xml.example.php
** Author.......: Richard Heyes
** Version......:
** Notes........:
** Last changed.: 07/08/2000
** Last change..:
***************************************/

        include('class.xml.db.interpreter.inc');

/***************************************
** Begin
***************************************/
        $xml = new xml_dbas();
        $xml->set_schema('xml.schema.xml', TRUE);
        $xml->parse_schema();
        $xml->create_dbas('localhost', 'richard', '95219430450');

        header('Content-Type: text/plain');
        print_r($xml->get_sql());
        print_r($xml->get_sql_errors());
?>
