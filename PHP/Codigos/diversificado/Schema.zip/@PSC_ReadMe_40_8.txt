Title: XML DB Schema Interpreter Class
Description: An easy to use class for handling your database schemas (table layout/design etc). Store the schema as an XML file and use this class to parse the file and (optionally) execute the SQL that's generated. Can be used for entire databases or single tables. Works with MySQL, but as there is only one function that deals with DB specific commands, it could be changed to work with other database software very easily. 
NOTE: This is merely an object designed for inclusion in your own scripts / applications. By Richard Heyes. Updates at: http://www.heyes-computing.net/scripts/index.html
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=40&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
