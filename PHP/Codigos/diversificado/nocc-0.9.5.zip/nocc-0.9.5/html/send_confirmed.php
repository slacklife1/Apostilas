<!-- start of $Id: send_confirmed.php,v 1.2.2.1 2001/11/19 19:31:33 nicocha Exp $ -->
<p class="inbox">
 <?php echo $html_send_confirmed; ?>
</p>

<p class="inbox">
 <a href="<?php echo $PHP_SELF ?>?action.php"><?php echo $html_return_to_inbox; ?></a>
</p>

<!-- end of $Id: send_confirmed.php,v 1.2.2.1 2001/11/19 19:31:33 nicocha Exp $ -->