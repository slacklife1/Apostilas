<!-- start of $Id: send_error.php,v 1.4 2001/11/08 13:23:33 rossigee Exp $ -->
<p><?php echo $html_error_occurred; ?> : <?php echo $ev->getMessage(); ?></p>
<!-- end of $Id: send_error.php,v 1.4 2001/11/08 13:23:33 rossigee Exp $ -->
