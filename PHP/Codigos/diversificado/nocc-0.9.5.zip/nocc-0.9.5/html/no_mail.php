<!-- start of $Id: no_mail.php,v 1.2 2001/10/25 15:22:34 rossigee Exp $ -->
<tr bgcolor="<?php echo $glob_theme->inbox_color ?>">
	<td align="center" colspan="7" class="inbox">
		<?php echo $html_no_mail ?>
	</td>
</tr>
<!-- end of $Id: no_mail.php,v 1.2 2001/10/25 15:22:34 rossigee Exp $ -->