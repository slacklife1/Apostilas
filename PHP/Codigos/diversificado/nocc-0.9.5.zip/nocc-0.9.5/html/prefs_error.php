<!-- start of $Id: prefs_error.php,v 1.1 2001/11/08 13:23:33 rossigee Exp $ -->
<p><?php echo $html_error_occurred; ?> : <?php echo $ev->getMessage(); ?></p>
<!-- end of $Id: prefs_error.php,v 1.1 2001/11/08 13:23:33 rossigee Exp $ -->
