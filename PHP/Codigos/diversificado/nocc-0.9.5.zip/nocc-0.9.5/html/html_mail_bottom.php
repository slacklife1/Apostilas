<!-- start of $Id: html_mail_bottom.php,v 1.3 2001/10/25 15:22:34 rossigee Exp $ -->
</td></tr>
</table>

</td></tr></table>
<!-- end of $Id: html_mail_bottom.php,v 1.3 2001/10/25 15:22:34 rossigee Exp $ -->
