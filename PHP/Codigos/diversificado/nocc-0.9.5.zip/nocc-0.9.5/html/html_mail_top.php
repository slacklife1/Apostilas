<!-- start of $Id: html_mail_top.php,v 1.8 2001/10/25 15:22:34 rossigee Exp $ -->
<table border="0" align="center" cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td bgcolor="<?php echo $glob_theme->inside_color ?>" align="left">
			<table border="0" cellpadding="2" cellspacing="1" bgcolor="<?php echo $glob_theme->inside_color ?>" width="100%">
<!-- end of $Id: html_mail_top.php,v 1.8 2001/10/25 15:22:34 rossigee Exp $ -->
