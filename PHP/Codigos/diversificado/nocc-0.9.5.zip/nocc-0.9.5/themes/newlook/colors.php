<?php
/*
 * $Header: /cvsroot/nocc/nocc/webmail/themes/newlook/colors.php,v 1.5 2001/05/27 11:01:07 wolruf Exp $
 *
 * Copyright 2001 Nicolas Chalanset <nicocha@free.fr>
 * Copyright 2001 Olivier Cahagne <cahagn_o@epita.fr>
 *
 * See the enclosed file COPYING for license information (GPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 * 
 * This theme is made by Anton Jakimov <t0xa@ls2.lv>
 */


// ################### color configuration ################### //

// Color on the pages background - default is 'white'
$glob_theme->bgcolor = '#ffffff" background="themes/newlook/img/bg.gif';

// Color of the login box border - default is 'black'
$glob_theme->login_border = '#000000';

// Inside color of the login box
$glob_theme->login_box_bgcolor = '#ffffff" background="themes/newlook/img/shtamp.gif';

// Color of the navigation button (inbox, write, answer, etc.)
// default is 'sky blue'
$glob_theme->menu_color = '#0099CC';

// The same as above when the user is in that part
// default is 'orange'
$glob_theme->menu_color_on = '#00AFEA';

// Mail properties color (to, from, subject, attachments, etc.)
// default is 'sky blue'
$glob_theme->mail_properties = '#99ccff';

// Color of all the inside border
// default is 'grey'
$glob_theme->inside_color = '#f7f7f7';
#$glob_theme->inside_color = '#';

// Color of the Inbox line and the garbage line and of the outside page
// default is 'dark blue'
$glob_theme->tr_color = '#006699';

// color for the highlight of the sorting in the mailbox
// default is 'yellow'
$glob_theme->sort_color = '#FEEC85';

// Color of the links
$glob_theme->link_color = '#003298';

// Color of the text
$glob_theme->text_color = '#000000';

// Color of the Inbox Text display (Delete, new, attachment ...)
// default is 'white'
$glob_theme->inbox_text_color = '#d2d2d2';

// Color of the Inbox display - default is 'white'
$glob_theme->inbox_color = '#e6e6e6';

// Color of the Message display - default is 'white'
$glob_theme->mail_color = '#ffffff';

// Color of the visited links
$glob_theme->vlink_color ='#003298';

$glob_theme->alink_color = '#003298';
?>