<?php
/*
 * $Header: /cvsroot/nocc/nocc/webmail/themes/standard/colors.php,v 1.3 2001/05/27 11:01:07 wolruf Exp $
 *
 * Copyright 2001 Nicolas Chalanset <nicocha@free.fr>
 * Copyright 2001 Olivier Cahagne <cahagn_o@epita.fr>
 *
 * See the enclosed file COPYING for license information (GPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 */


// ################### color configuration ################### //

// Color on the pages background - default is 'white'
$glob_theme->bgcolor = '#ffffff';

// Color of the login box border - default is 'black'
$glob_theme->login_border = '#000000';

// Inside color of the login box
$glob_theme->login_box_bgcolor = '#cccccc';

// Color of the navigation button (inbox, write, answer, etc.)
// default is 'sky blue'
$glob_theme->menu_color = '#99ccff';

// The same as above when the user is in that part
// default is 'orange'
$glob_theme->menu_color_on = '#FFC061';

// Mail properties color (to, from, subject, attachments, etc.)
// default is 'sky blue'
$glob_theme->mail_properties = '#99ccff';

// Color of all the inside border
// default is 'grey'
$glob_theme->inside_color = '#f0f0f0';

// Color of the Inbox line and the garbage line and of the outside page
// default is 'dark blue'
$glob_theme->tr_color = '#002266';

// color for the highlight of the sorting in the mailbox
// default is 'yellow'
$glob_theme->sort_color = '#ffffcc';

// Color of the links
$glob_theme->link_color = '#0033cc';

// Color of the text
$glob_theme->text_color = '#000000';

// Color of the Inbox Text display (Delete, new, attachment ...)
// default is 'white'
$glob_theme->inbox_text_color = '#ffffff';

// Color of the Inbox display - default is 'white'
$glob_theme->inbox_color = '#ffffff';

// Color of the Message display - default is 'white'
$glob_theme->mail_color = '#ffffff';

// Color of the visited links
$glob_theme->vlink_color ='#0033cc';

$glob_theme->alink_color = '#0033cc';
?>