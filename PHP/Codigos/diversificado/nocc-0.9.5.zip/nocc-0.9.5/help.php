<?php
/*
 * $Header: /cvsroot/nocc/nocc/webmail/help.php,v 1.8 2001/10/19 10:34:25 nicocha Exp $ 
 *
 * Copyright 2001 Nicolas Chalanset <nicocha@free.fr>
 * Copyright 2001 Olivier Cahagne <cahagn_o@epita.fr>
 *
 * See the enclosed file COPYING for license information (GPL).  If you
 * did not receive this file, see http://www.fsf.org/copyleft/gpl.html.
 */


require_once ('./conf.php');
require_once ('./check_lang.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $lang ?>" lang="<?php echo $lang ?>">
<head>
<title>NOCC - <?php echo $html_help ?></title>
<meta content="text/html; charset=<?php echo $charset ?>" http-equiv="Content-Type" />
<link href="themes/<?php echo $theme ?>/style.css" rel="stylesheet" type="text/css" />
</head>
<body alink="<?php echo $glob_theme->alink_color?>" bgcolor="<?php echo $glob_theme->bgcolor ?>" link="<?php echo $glob_theme->link_color ?>" text="<?php echo $glob_theme->text_color ?>" vlink="<?php echo $glob_theme->vlink_color ?>">

</body>
</html>