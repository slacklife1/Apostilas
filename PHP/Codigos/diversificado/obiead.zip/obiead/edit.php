<link rel="stylesheet" href="inc/css.css">
<script src="inc/modules.js"></script>
<?
//////////////////////////////////////////////////////////
//			--obieAD--			//
//							//
//		-The AD banner management-		//
//		-Version 1.0 created on Dec/02-		//
//							//
//	Writen by Minh Nguyen Duong @ obie.		//
//	All right reserved - http://obiewebsite.sourceforge.net	//
//							//
//	obiePAD included				//
//							//
//	This Software is FREE and can be modified 	//
//	and redistributed under the condition that 	//
//	the copyright and information above stays 	//
//	intact and with the script.			//
//							//
//	If you redistribute obieAD, please link back	//
//	to http://obiewebsite.sourceforge.net			//
//////////////////////////////////////////////////////////
include "config.php";

if($mode=='norm') $title='Database';
else $title='Submiter database';

$tongsosubmit = sizeof (file($submitfile)) - 1;
$tongsodata = sizeof (file($adsfile)) - 1;

#If the call for the script is to log them in, DO IT! 
if($action == "login" && $a_u==$admin_username && $a_p==$admin_password): 

//HEADER
print("
<table border=0 cellpadding=1 cellspacing=1 width=100% bgcolor=#F0F0F0>
<tr><td width=150 align=center valign=top>");
include "inc/admin_cp.php";
print("</td><td width=99% bgcolor=#FFFFFF align=right valign=top>");

    #This makes sure all fields are filled out. 
    if((!$username)or(!$password)){ 
        #If there is one missing, send them to the error. 
        error_message("One or more required fields were left blank!", $username, $password); 
    } 
    #Open the datafile and login the user. 
    if($mode=='norm') $file=file($adsfile);
    else $file=file($submitfile); 
    while(list(,$value)=each($file)){ 
        list($fname,$femail,$furl,$fbanner,$fuser,$fpass,$fcounter,$ferror,$blank)=split( "\|", $value); 
        if($username==$fuser && $password==$fpass){ 

	    $adpath =  str_replace('^/','',$fbanner);
    	    $pos = strpos($fbanner, "^");
	    if($pos===false) $uploaded=0; 
	    else $uploaded=1;

            echo "<h3>Change user <font color=red>$fuser</font> profiles<br><font size=1>in <font color=red>$title</font></font></h3>
	<div align=center><p><u><font size=\"1\">Note : All fields are required</font></u></p>
	<a href=\"$furl\" target=\"_blank\"><img src=\"$adpath\" width=$w height=$h border=0></a><p>
	<table border=0 width=80% bgcolor=#DFDFDF cellspacing=1 cellpadding=1><tr><td align=left valign=top>"; 
	    echo "</td></tr><FORM action=\"$PHP_SELF?action=change\" method=\"post\"> 
		<tr><td>
		<input type=\"hidden\" name=\"mode\" value=\"$mode\">
		<p><b>Change your users' profiles</b></p>
		</td></tr>
		<tr><td width=40% bgcolor=#F0F0F0>Name: </td><td width=60% bgcolor=#F0F0F0><INPUT type=\"text\" name=\"name\" value='$fname'></td></tr>
		<tr><td width=40% bgcolor=#F0F0F0>E-mail Address:  </td><td width=60% bgcolor=#F0F0F0 align=left><INPUT type=\"text\" name=\"email\" value='$femail'></td></tr>
		<tr><td width=100%><b>Change user's banner info</b></p></td></tr>
		<tr><td width=40% bgcolor=#F0F0F0>Website Address:  </td><td width=60% bgcolor=#F0F0F0 align=left><INPUT type=\"text\" name=\"url\" value='$furl'> </td></tr>
		<tr><td width=40% bgcolor=#F0F0F0>Banner URL:  </td><td width=60% bgcolor=#F0F0F0 align=left>
		";

		if($uploaded==0) print("<INPUT type=\"text\" name=\"banner\" value='$fbanner'>");
		else print("Uploaded to your server<INPUT type=\"hidden\" name=\"banner\" value='$fbanner'>");

		print("</td></tr><tr><td width=40% bgcolor=#F0F0F0>Counter :  </td><td width=60% bgcolor=#F0F0F0 align=left><input type=\"text\" name=\"counter\" value='$fcounter'> </td></tr>
		<tr><td width=40% bgcolor=#F0F0F0>Error count :  </td><td width=60% bgcolor=#F0F0F0 align=left><input type=\"text\" name=\"error\" value='$ferror'></td></tr>
		<tr><td width=100%><b>Change password of user</b><br>(to locking this account, reseting password ....etc)</b></p></td></tr>
		<tr><td width=40% bgcolor=#F0F0F0>Username (can not be changed):  </td><td width=60% bgcolor=#F0F0F0 align=left><b>$fuser</b><input type=\"hidden\" name=\"username\" value='$fuser'>
		</td></tr>
		<tr><td width=40% bgcolor=#F0F0F0>Password:  </td><td width=60% bgcolor=#F0F0F0 align=left><INPUT type=\"text\" name=\"password\" value='$fpass'> 
		<input type=hidden name=\"a_u\" value='$a_u'>
		<input type=hidden name=\"a_p\" value='$a_p'></td></tr>
		<tr><td width=100%><INPUT type=\"submit\" value=\"Change datas\">
		<input type=reset value=\"Reset\">
		<input type=button value=Cancel onclick=\"history.back();\"></td></tr>
		</FORM>");

//FOOTER
print("</td></tr></table>");

            $logink="1"; 
        } 
    } 
    if($logink==""): 
        error_message("Login failed, bad username/password", $username, $password); 
    endif; 
elseif($action=="change"): 

print("
<table border=0 cellpadding=1 cellspacing=1 width=100% bgcolor=#F0F0F0>
<tr><td width=150 align=center valign=top>");
include "inc/admin_cp.php";
print("</td><td width=99% bgcolor=#FFFFFF align=right valign=top>");

    #This makes sure all fields are filled out. 
    if((!$name)or(!$email)or(!$url)or(!banner)or(!$username)or(!$password)){ 
        #If there is one missing, send them to the error. 
        error_message("One or more required fields were left blank! Please re-login.", $username, $password); 
    } 
    #Open the datafile and login the user. 
    if($mode=='norm') $file=file($adsfile);
    else $file=file($submitfile); 
    while(list(,$value)=each($file)){ 
        list($fname,$femail,$furl,$fbanner,$fuser,$fpass,$fcounter,$ferror,$blank)=split( "\|", $value); 
        if($username==$fuser){ 
            $xaucu="$fname|$femail|$furl|$fbanner|$fuser|$fpass|$fcounter|$ferror|\n"; 
            $xaumoi="$name|$email|$url|$banner|$username|$password|$counter|$error|\n"; 
            	if ($mode=='norm') $fp = fopen($adsfile, "r");
	    	else $fp = fopen($submitfile, "r");  
            	if ($mode=='norm') $data = fread($fp, filesize($adsfile));
		else $data = fread($fp, filesize($submitfile));  
            fclose($fp);  
            $newdata = str_replace($xaucu, $xaumoi, $data);  
            	if ($mode=='norm') $fp = fopen($adsfile,"w");
		else $fp = fopen($submitfile,"w");
            fwrite($fp,$newdata) or die ("error writing"); 
            fclose($fp); 
            $succ = "1"; 
		if($mode=='norm') $setaction='viewall';
		else $setaction='submit';
            print("<h3>User's infomations was changed successfully!</h3>
		<p><i>Please wait, I will transfer you to where you came....</i>"); 
	    print("<script>setTimeout(\"self.location='admin.php?a_u=$a_u&a_p=$a_p&action=$setaction';\",5000);</script>");
        } 
    } 
    if(!$succ): 
        error_message("Login failed, bad username/password", $username, $password); 
    endif; 
else:?>
<h3>Staff only<br>
<font size=1><b>Only administrators can edit submiters' infomations</b></font></h3>
<p><font size=1>If you are administrator, please login first <a href="admin.php">here</a></p>
<FORM action="<?$PHP_SELF;?>?action=login" method="post"> 
<P>Username: <INPUT type="text" name="username"> 
<P>Password: <INPUT type="password" name="password"> 
<P><INPUT type="submit" value="Log-in">
</FORM> 
<?endif;
//Thong bao loi
function error_message($message, $username, $password){?>
<font size=1><b>Only administrators can edit submiters' infomations</b></font></h3>
<p><font size=1>If you are administrator, please login first <a href=\"admin.php\">here</a></p>
<H3><?echo $message;?></H3> 
<FORM action="<?$PHP_SELF;?>" method="post"> 
<P>Username: <INPUT type="text" name="username" value="<?echo $username;?>"> 
<P>Password: <INPUT type="password" name="password" value="<?echo $password;?>"> 
<P><INPUT type="submit" value="Log-in">
<input type=hidden name=\"a_u\" value='$a_u'>
<input type=hidden name=\"a_p\" value='$a_p'>
</FORM> 
<?exit; 
}?>
</td></tr></table></div>
<p></p><p align="center">
Powered by <a target="_blank" href="http://obiewebsite.sourceforge.net"><b>obie</b>AD</a> version <? print($obieADversion); ?>. The AD banners management</p>
