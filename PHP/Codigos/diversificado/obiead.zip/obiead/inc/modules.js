//////////////////////////////////////////////////////////////////
//		Javascript modules for obieAD			//
//								//
//		Writen by Minh Nguyen Duong @ obie		//
//		------http://www/obiewebsite.sourceforge.net-----		//
//		Updated on Dec/02				//
//		All right reserved				//
//////////////////////////////////////////////////////////////////
var testresults
var testsb;

function checkemail(ob){
var str=ob.value
var filter=/^.+@.+\..{2,4}$/
if (filter.test(str))
testresults=true
else{
alert('ERROR: The email address "' + ob.value + '" is not correct\nPlease type your correct email address')
testresults=false
ob.style.backgroundColor = '#FAE085';
ob.select()
}
return (testresults)
}


function checkvalue(ob){
sb = ob.value.length;
if (sb >= 1)
{testsb=true;}
else {
testsb = false;
alert('ERROR: The keyword "' + ob.value + '"\n\n is too short');
ob.focus();
}
return(testsb);
}

function openclosediv(thisdiv) {
	if (document.all) {
		thisMenu = eval("document.all." + thisdiv + ".style")
		if (thisMenu.display == "block") {
			thisMenu.display = "none"
		}
		else {
			thisMenu.display = "block"
		}
		return false
	}
	else {
		return true
	}
}

function selectcode() {
document.all.backupdata.select();
document.all.backupdata.focus();
}

function copycode() {
	selectcode();
	textRange = document.all.backupdata.createTextRange();
	textRange.execCommand("RemoveFormat");
	textRange.execCommand("Copy");
	alert('Backup data was copied to your clipboard\n\n\nTo save your backup file:\nSTEP ONE: Open your own text editor as a new file. Eg: Window NotePAD\nSTEP TWO: Paste into this and save as your backup file');
}

if (document.all){document.write('<div id="curscroll" style="position:absolute;visibility:hidden"></div>')}

function mota(x)

{var follow=x
if (document.all){

	curscroll.style.visibility="visible"
	curscroll.innerHTML='<table ID=\"sample\" border=0 cellspacing=1 bgcolor=black><tr><td width=100% bgcolor=lightyellow>' + x + '</td></tr></table>'
	//IF YOU WANT TO ADD FADING EFFECT FOR TOOLTIPS, PLEASE REMOVE '//'. HAVE FUN
	//document.all.sample.style.filter = 'alpha(opacity=80);'
}
curscroll.style.left=document.body.scrollLeft+event.clientX+20
curscroll.style.top=document.body.scrollTop+event.clientY+0
}

function tatmota(){
	curscroll.style.visibility="hidden"
}

function run(url) {
    setTimeout("top.location.href='" + url + "'",5000);
}

function setchmod(x){
document.all.chmodfr.src='func.php?action=chmodf&file=' + x;
}
