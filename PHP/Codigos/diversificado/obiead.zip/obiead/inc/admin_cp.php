<?
print("
<script>
function opennotepad(x){
url = 'notepad.php?file2edit=' + x +'&a_u=$a_u&a_p=$a_p';
notepad=window.open(url,\"obieNotePAD\",\"width=720,height=530,top=0,left=0,resizable=yes,scrollbars=no,menubar=no,toolbar=no,status=no,location=no\")}
</script>
");

print("<title>ObieAD - control panel</title>
<p></p><table bgcolor=#F0F0F0 border=0 cellspacing=1 cellpadding=1 width=180><tr><td>

<a href=\"admin.php?a_u=$a_u&a_p=$a_p&action=viewall\" onmouseover=\"mota('You can view, edit and delete banners in your database');\" onmouseout=\"tatmota();\"><img src=inc/foldericon.png border=0>Database manager</a><font color=red>  ($tongsodata)</font><br>

<br><a href=\"admin.php?a_u=$a_u&a_p=$a_p&action=submit\" onmouseover=\"mota('You can view, ADD, edit and delete banners<br>in <u>submiter</u> database, they are waiting for you :-)');\" onmouseout=\"tatmota();\"><img src=inc/foldericon.png border=0>Submiter DB manager</a><font color=red>  ($tongsosubmit)</font><br>

<br><a href=\"admin.php?a_u=$a_u&a_p=$a_p&action=gencode\" onmouseover=\"mota('<font color=red>Note : </font>After changing ONLY the <u>style</u> of obieAD<br>or/and the <u>size</u> of the banner<br>or/and the <u>number of icons</u> (with style 2 or 3)<br> in configuration file,<br>you must generate the code <b>again</b>');\" onmouseout=\"tatmota();\"><img src=inc/muiten.gif border=0>Generate code</a><br>(current style : <font color=red>$style</font>)<br>
");


print("<hr size=1 color=gray><b>TOOLS</b><p>
<a href=\"cp.php?a_u=$admin_username&a_p=$admin_password&admin=login\" onmouseover=\"mota('Using Obie Config Admin(R) online to edit the obieAD configuration');\" onmouseout=\"tatmota();\">Edit configuration</a><br>");

if ($readterm == 1) print("
<br><a href=\"javascript:opennotepad(2);\" onmouseover=\"mota('Edit your term of services file<br>(the file that new users must read before signing up)<br><br><i>Support HTML code</i>');\" onmouseout=\"tatmota();\">Edit term of service file</a><br>
");

print("<br><a href=\"javascript:opennotepad(3);\" onmouseover=\"mota('Edit index.php file as your OWN<br><br><i>obieAD does not need index.php</i><br>Please change or delete it if you want');\" onmouseout=\"tatmota();\">Edit welcome file (index.php)</a><br>");

print("<br><a href=\"admin.php?a_u=$a_u&a_p=$a_p&action=backup\" onmouseover=\"mota('Back up database, submiter database and config file');\" onmouseout=\"tatmota();\">Backup your data</a><br>");
print("<hr size=1 color=gray><b>HELP</b><p>
<a href=\"manual/index_en.htm\" target=\"_blank\">obieAD manual</a><br>
<a href=\"func.php?action=about\">About obieAD</a>
<hr size=1 color=gray>
Administrators can test your AD system functions by visit those links below<br><br>
<a href=\"func.php?action=testobiead\" target=\"_blank\">Test banner</a><br>
<a href=\"func.php?action=showall\" target=\"_blank\">Show all banner</a><br>
<a href=\"func.php?action=showsubmiters\" target=\"_blank\">Show submiters</a><br>
-<a href=\"signup.php\" target=\"_blank\">Signup</a><br>
-<a href=\"login.php\" target=\"_blank\">Login</a>
</td></tr></table>");
?>