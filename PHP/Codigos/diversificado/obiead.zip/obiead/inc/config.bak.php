<?
//////////////////////////////////////////////////////////
//			--obieAD--			//
//							//
//		-The AD banner management-		//
//		-Version 1.2 created on Dec/02-		//
//							//
//	Writen by Minh Nguyen Duong @ obie.		//
//	All right reserved - http://obiewebsite.sourceforge.net	//
//							//
//	obiePAD included				//
//							//
//	This Software is FREE and can be modified 	//
//	and redistributed under the condition that 	//
//	the copyright and information above stays 	//
//	intact and with the script.			//
//							//
//	If you redistribute obieAD, please link back	//
//	to http://obiewebsite.sourceforge.net			//
//////////////////////////////////////////////////////////
$obieADversion = 'demo'; //Latest version ID of obieAD, please do not change it
///////////////////////////////////////////////////
//Config file
//==>Note : Variables starts with the character '$'
///////////////////////////////////////////////////


//BANNER SYSTEM INFO///////////////////////////////////////////////////

	//****************IMPORTANT: Please set your correct script_path**********************
	//****************Note : DO NOT add '/' at the end of $script_path********************

	$script_path = 'http://localhost/demo/obiead';  //eg: http://domain.com/cgi-bin/obiead

//ObieAD CONFIG INFO///////////////////////////////////////////////////

	$adsfile = 'inc/database.db';  //REAL ADs data stored in this database
	$submitfile = 'inc/submiter_database.db';  //Submiter database

	$upload_banner = 1;  //Users can upload their own banners to your obieAD system.
	$maxadsize = 10240;  //Size of users banner file. 10240 bytes = 1Kb

	$yesmail = 1;  //Send a mail to users after they banner added to the system. 1 for on, 0 for off

	$readterm = 1;  //User must read 'term of service' before signing up. 1 for on, 0 for off

	$termcontent = 'inc/term.htm';  //YOUR term of services file.(support HTML tags)


//ADMINISTRATOR INFO///////////////////////////////////////////////////

	$admin_username = 'admin';
	$admin_password = 'admin';
	$admin_email = 'admin@admin.com';
	$admin_website = 'http://localhost/';

	$entry_on_page = 20;  //Max entries will be showed on a page

//DISPLAY INFO///////////////////////////////////////////////////

	$background_color = 'white'; //Background color of icons bar	

	$w = 90;  //Banner width
	$h = 30;  //Banner height

	$style = 2;  //obieAD style 1 for one banner - 2 for horizol icons - 3 for vertical icons
	$numicons = 4;  //Icons will showing in webpages (only for style 2 or style 3)

	$auto_error = 1;  //Auto checking bad images, 1 for on, 0 for off (only for style 1)
	$max = 100;  //Number of errors will be deleted. 100 is recommended (only for style 1)

?>
