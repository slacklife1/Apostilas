<link rel="stylesheet" href="inc/css.css">
<?php
//////////////////////////////////////////////////////////
//			--obieAD--			//
//							//
//		-The AD banner management-		//
//		-Version 1.0 created on Dec/02-		//
//							//
//	Writen by Minh Nguyen Duong @ obie.		//
//	All right reserved - http://obiewebsite.sourceforge.net	//
//							//
//	obiePAD included				//
//							//
//	This Software is FREE and can be modified 	//
//	and redistributed under the condition that 	//
//	the copyright and information above stays 	//
//	intact and with the script.			//
//							//
//	If you redistribute obieAD, please link back	//
//	to http://obiewebsite.sourceforge.net			//
//////////////////////////////////////////////////////////

//INCLUDE FUNCTION----------------------------------
include "config.php";

print("<body bgcolor=$background_color><center>\n\n");

//Don't change anything below
if(!$style || $style>3) print("<b>ObieAD style error</b><br>
Administrators of this AD system must set the style in configure file<br>
::<b>1</b> for single banner<br>::<b>2</b> for horizol icons bar<br>::<b>3</b> for vertical icons bar");

if($style==1){
srand ((double)microtime()*1000000);
$f_contents = file ("$adsfile");
$tongso = sizeof ($f_contents);

//if ($tongso-1==0) print("Database is empty");
//else {

$line = $f_contents[array_rand ($f_contents)];
$ads = explode ("|", $line);
if($ads[4]=='root')
	{
	$line = $f_contents[1];
	$ads = explode ("|", $line);
	}

	    	$ads[3] =  str_replace('^/','',$ads[3]);

		print("<a href=\"func.php?action=count&ad=$ads[4]\" target=\"_blank\"><img src=\"$ads[3]\" width=$w height=$h border=0 alt=\"Go to : $ads[0]\nClicks : $ads[6] times\" ");
		if ($auto_error==1) {
				print("onerror=\"document.all.bannerframe.src='func.php?action=error&ad=$ads[4]&code=$ads[7]';\"></a>");
				print("<br><IFRAME marginheight='0' marginwidth='0' background='#000000' width='0' height='0' scrolling='no' frameborder='0' align='center' src='#' name='bannerframe'></IFRAME>");
				}
		else print("></a>");
		
}

if ($style==2 || $style==3){

$f_contents = file ("$adsfile");
$tongso = sizeof ($f_contents);
if ($numicons >= $tongso-1) {
		for ($i=1;$i<$tongso;$i++){
		$line[$n] = $f_contents[$i];
		$ads = explode ("|", $line[$n]);
		if($ads[4]=='root')
			{
			$ads = explode ("|", $line[$n+1]);
			}
		$ads[3] =  str_replace('^/','',$ads[3]);
		print("<a href=\"func.php?action=count&ad=$ads[4]\" target=\"_blank\"><img src=\"$ads[3]\" width=$w height=$h border=0 alt=\"Go to : $ads[0]\nClicks : $ads[6] times\"\"></a>");
		if ($style==3) print("<br><br>");
		else if ($style==2) print(" ");
		$n = $n + 1;
		}	
}
else {
	$n = 1;
	for ($i=0;$i<=$numicons;$i++){
		$check = 'TRUE';
		$numran = rand(1,$tongso);  //Get the random number
		for ($j=1;$j<=$n;$j++){
		if ($line[$j] == $f_contents[$numran]){ $check = 'FALSE'; }
		}
		if ($check == 'TRUE'){
		$line[$n] = $f_contents[$numran];
		$n = $n + 1;
		} else { $i = $i - 1; }
	}
	for ($i=1;$i<=$numicons;$i++){
	$ads = explode ("|", $line[$i]);
	if($ads[4]=='root')
		{
		$ads = explode ("|", $line[$i+1]);
		}
	$ads[3] =  str_replace('^/','',$ads[3]);
	print("<a href=\"func.php?action=count&ad=$ads[4]\" target=\"_blank\"><img src=\"$ads[3]\" width=$w height=$h border=0 alt=\"Go to : $ads[0]\nClicks : $ads[6] times\"\"></a>");
	if ($style==3) print("<br><br>");
	else if ($style==2) print(" ");
	}
}
}
//}
//End the obieAD code
?>
