<link rel="stylesheet" href="inc/css.css">
<script src="inc/modules.js"></script>
<? include "config.php"; ?>
<script>
function meserror(){
	window.status='The image for your banner IS NOT FOUND. Please type a correct URL to your image';
}

function checkimage(ob){
uri = ob.value;
document.all.ex.src = uri;
}

function checkad(){
wok=<? print("$w"); ?>;
hok=<? print("$h"); ?>;

if(document.all.adfile.value.length>0 && document.all.banner.value.length==0){
	document.all.ex.src=document.all.adfile.value;

	var file = document.all.adfile.value;
	var dir = file.substring(0,file.lastIndexOf('\\')+1);
	var url = file.substring(dir.length,file.length+1);
	var ext = url.substring(url.lastIndexOf(".") + 1, url.length);
	ext = ext.toLowerCase();
	w = document.all.ex.width;
	h = document.all.ex.height;

	//Width : w | Height : h | Extension  : ext
	document.all.adext.value=ext;

	var str=document.all.email.value;
	var filter=/^.+@.+\..{2,4}$/
	
	if (filter.test(str))
		emailok=1;
	else{
		emailok=0;
		alert('ERROR: The email address "' + str + '" is not correct\nPlease type your correct email address')
		document.all.email.style.backgroundColor = '#FAE085';
		document.all.email.select()
	}

	if(ext=="gif")	extok=1;

	else {
		extok=0;
		alert("ERROR: This file extension (*."+ext+") is not be accept\n\nWe only accept *.GIF image");
	}
	if(w<=wok || h<=hok)	sizeok=1;
	else {
		sizeok=0;
		alert("ERROR: The size of your banner ( "+w+" x "+h+" ) is not be accept\n\nSize recommended : "+wok+" x "+hok+" ");
	}
	if(extok==1 && sizeok==1 && emailok==1) return true;
	else return false;
}
else if(document.all.adfile.value.length==0 && document.all.banner.value.length>0){

	document.all.ex.src=document.all.banner.value;

	var file = document.all.banner.value;
	var dir = file.substring(0,file.lastIndexOf('\\')+1);
	var url = file.substring(dir.length,file.length+1);
	var ext = url.substring(url.lastIndexOf(".") + 1, url.length);
	ext = ext.toLowerCase();
	w = document.all.ex.width;
	h = document.all.ex.height;

	//Width : w | Height : h | Extension  : ext
	document.all.adext.value=ext;

	var str=document.all.email.value;
	var filter=/^.+@.+\..{2,4}$/
	
	if (filter.test(str))
		emailok=1;
	else{
		emailok=0;
		alert('ERROR: The email address "' + str + '" is not correct\nPlease type your correct email address')
		document.all.email.style.backgroundColor = '#FAE085';
		document.all.email.select()
	}

	if(ext=="gif")	extok=1;

	else {
		extok=0;
		alert("ERROR: This file extension (*."+ext+") is not be accept\n\nWe accept *.GIF image");
	}
	if (w<=wok || h<=hok)	sizeok=1;
	else {
		sizeok=0;
		alert("ERROR: The size of your banner ( "+w+" x "+h+" ) is not be accept\n\nSize recommended : "+wok+" x "+hok+" ");
	}
	if(extok==1 && sizeok==1 && emailok==1) return true;
	else return false;
}
else if(document.all.adfile.value.length==0 && document.all.banner.value.length==0){
	alert("You has not filled all required form yet");
	document.all.adfile.style.backgroundColor = '#FAE085';
	document.all.banner.style.backgroundColor = '#FAE085';
	return false;
}
else if(document.all.adfile.value.length>0 && document.all.banner.value.length>0){
	alert("Opps!!!\n\nYou must choose only one in two ways to using our AD service: \n\n+ Give us a banner URL or\n+ upload your own image file for your banner");
	document.all.adfile.style.backgroundColor = '#FAE085';
	document.all.banner.style.backgroundColor = '#FAE085';
	return false;
}
}
</script>
<? 
//////////////////////////////////////////////////////////
//			--obieAD--			//
//							//
//		-The AD banner management-		//
//		-Version 1.0 created on Dec/02-		//
//							//
//	Writen by Minh Nguyen Duong @ obie.		//
//	All right reserved - http://obiewebsite.sourceforge.net	//
//							//
//	obiePAD included				//
//							//
//	This Software is FREE and can be modified 	//
//	and redistributed under the condition that 	//
//	the copyright and information above stays 	//
//	intact and with the script.			//
//							//
//	If you redistribute obieAD, please link back	//
//	to http://obiewebsite.sourceforge.net			//
//////////////////////////////////////////////////////////

if($action == "signup"){ 

	if((!$name)or(!$email)or(!$url)or(!$username)or(!$password)){ 
        error_message("One or more required fields were left blank!", $name, $email, $url, $banner, $username, $password); 
	}


    $file=file($submitfile); 
    while(list(,$value)=each($file)){ 
        list($fname,$femail,$furl,$fbanner,$fuser,$fpass,$fcounter,$ferror,$blank)=split( "\|", $value); 
        if($username==$fuser){ 
            #If the username is allready in user, error time. 
            error_message("ERROR in submiters database<br>Username is allready in use by someone else.", $name, $email, $url, $banner, $username, $password, $banner, $error); 
        } 
    } 
    $file=file($adsfile); 
    while(list(,$value)=each($file)){ 
        list($fname,$femail,$furl,$fbanner,$fuser,$fpass,$fcounter,$ferror,$blank)=split( "\|", $value); 
        if($username==$fuser){ 
            #If the username is allready in user, error time. 
            error_message("ERROR in database<br>Username is allready in use by someone else.", $name, $email, $url, $banner, $username, $password, $banner, $error); 
        } 
    }
    #If the username isn't in use, make it in use. 
        if ($adfile=='none') { 	
		
        } 
	else if(filesize($adfile)>$maxadsize){
		print("<p>The file <b>$adfile</b> is too large</p>
		<p>We accept the size of banner file is < <b>$maxadsize</b> bytes");
	}
        else {

	        copy($adfile, "userbanners/$username" .".gif"); 
	        unlink($adfile); 
		$banner = "^/userbanners/" .$username .".gif";
        } 

    $fp=fopen($submitfile,"a"); 
    fwrite($fp,"$name|$email|$url|$banner|$username|$password|$counter|$error|\n"); 
    fclose($fp); 
    #Now we notify the person that they have signed up successfully. 
?> 
<H3>Success!</H3> 
<P>Thank you for signing up.<P>Your information was successfully added into our 
<u>submiter</u> database.<BR> 
You may login using the Username: <b><?echo $username;?></b> and Password: <b><?echo $password;?></b><br>
after the Administrators agree to add your banner to the system.<p>
Please check your email soon.<BR>
<hr size=1 color=black>
<a href="<? print($admin_website); ?>">Come back to our site</a>
<br>For more infomations, please drop us a line at <a href="mailto:<? print($admin_email); ?>"><? print($admin_email); ?></a>
<? 
}
#If the action is for anything else, show this. 
else if($term=='agree' || $readterm=='0'){
print(' 
<h3>Advertisement system<br>
<font size="1">For placing your banner on our website, please sign-up an account</font></h3>
<p><u><font size="1">Note : All fields are required</font></u></p>

<FORM action="' .$PHP_SELF .'" ENCTYPE="multipart/form-data" onsubmit="return checkad();" method="post"> 
<input type="hidden" name="error" value="0">
<input type=hidden name=action value=signup>
<input type=hidden name=adext>
<table border="0" cellpadding="2" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="80%" bgcolor="#3333CC">
  <tr>
    <td width="100%" bgcolor="#99CCFF" colspan="2"><b>Profiles</b></td>
  </tr>
  <tr>
    <td width="25%" bgcolor="#FFFFFF" align="left" valign="top"><P>Your site 
    name<P><b>Real</b> e-mail</td>
    <td width="75%" bgcolor="#FFFFFF" align="left" valign="top"> 
    <INPUT type="text" name="name" size="20"><p> <INPUT type="text" name="email" size="20">
    <br>We will send you a mail after we agree to add your banner</td>
  </tr>
  <tr>
    <td width="100%" bgcolor="#99CCFF" colspan="2"><b>Your banner</b></td>
  </tr>
  <tr>
    <td width="25%" bgcolor="#FFFFFF" align="left" valign="top"><P>Website<p>
    Banner URL
    <br>You must choose only one of two ways</td>
    <td width="75%" bgcolor="#FFFFFF" align="left" valign="top"> 
    <INPUT type="text" name="url" size="30" value="http://"> eg: 
    http://domain.com<p> 
    <b>[ONE]</b> - Banner image on your server : <INPUT type="text" name="banner" size="40" onblur=checkimage(this)> <br>
    eg: 
    http://yourdomain.com/images/banner.gif</p>');

if($upload_banner==1) print('OR <b>[TWO]</b> - Upload your own banner : <input type="file" size=30 name="adfile" onblur=checkimage(this)>');
else print("<p>Uploading your own banner image is not avaiable</p><input type=hidden name=adfile>");

print('   <p> 
    <font color=red>Note</font> : our banner size is <b>' .$w .'</b> pixels width and <b>' .$h .'</b> 
    pixels height</p>Example image<br>
    <table border=0 bgcolor=gray cellspacing=1 cellpadding=0 width=' .$w .' height=' .$h .'><tr><td bgcolor=#F0F0F0>
    <img name=ex src="inc/blank.gif" onerror="meserror();">
    </td></tr></table>
    <p> <input type="hidden" name="counter" size="20" value="0"></td>
  </tr>
  <tr>
    <td width="100%" bgcolor="#99CCFF" colspan="2"><b>Choose login</b></td>
  </tr>
  <tr>
    <td width="25%" bgcolor="#FFFFFF" align="left" valign="top"><P>Username<P>
    Password</td>
    <td width="75%" bgcolor="#FFFFFF" align="left" valign="top"> 
    <INPUT type="text" name="username" size="10" maxlength=10> 
    Less than 10 characters<p> <INPUT type="password" name="password" size="10" maxlength=10> 
    Less than 10 characters</td>
  </tr>
  <tr>
    <td width="100%" bgcolor="#FFFFFF" colspan="2"><input type="hidden" name="error" value="0"><INPUT name=sb type="submit" value="Sign-up"><input type=reset></td>
  </tr>
</table>
</FORM>');
}

else if (!$term && $readterm=='1') {
	print("	<center><h3>Advertisement system<br>
	<font size=\"1\">Please read term of services before</font></h3>
	<table border=0 cellspacing=1 bgcolor=black><tr><td bgcolor=white>");

	include "$termcontent";

	print("</td></tr></table><p><input type=button value=Agree onclick=\"self.location.replace('$PHP_SELF?term=agree');\">  <input type=button value=DisAgree onclick=\"self.location='$admin_website';\">");
	}
function error_message($message, $name, $email, $url, $banner, $username, $password){include "config.php";?> 
<h3>Advertisement system<br>
<font size="1">For placing your banner on our website, please sign-up an account</font></h3>
<font color=red size=2><b>ERROR</b> : <?echo $message;?></font>
<p>Please go back to correct it</p>
<?exit; 
}?> 
<p></p><p align="center">
Powered by <a target="_blank" href="http://obiewebsite.sourceforge.net/ref.php"><b>obie</b>AD</a> version <? print($obieADversion); ?>. The AD banners management</p>
