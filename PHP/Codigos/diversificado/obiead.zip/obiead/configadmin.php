<?
//
//-----------------------------CONFIGURATIONS of only ConfigAdmin--------------------------------
//-------------Please do not change below, it only for this PHP script developer-----------------
//

$configdatafile="config_data.php";  //Must be *.php extension. Remember it is the SERVER PATH to this file

$fully_editor=0;

$my_script_name = 'obieAD';  //Name of your PHP script

$version='1.1'; //Version of Config Admin, please do not change it

//$admin_username='admin';  //Username and Password for USERS and YOU to log in your script's Control Panel
//$admin_password='admin';

?>