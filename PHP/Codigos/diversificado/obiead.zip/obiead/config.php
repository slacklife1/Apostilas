<?
//////////////////////////////////////////////////////////////////
//		   --Obie Config Admin--			//
//								//
//		--USEFUL for PHP programmers--			//
//								//
//		-Version 1.0 created on Mar/03 -		//
//								//
//	Writen by Minh Nguyen Duong @ obie.			//
//	All right reserved - http://obiewebsite.sourceforge.net		//
//								//
//								//
//	This Software is FREE and can be modified 		//
//	and redistributed under the condition that 		//
//	the copyright and information above stays 		//
//	intact and with the script.				//
//								//
//	If you redistribute Obie Config Admin, please link back	//
//	to http://obiewebsite.sourceforge.net				//
//								//
//////////////////////////////////////////////////////////////////
//USING: Usual way, replace this file as your old config.php	//
// file then simple to include your config file as the command:	//
// include "config.php";	 				//
//								//
//ADMIN Control panel : Go to cp.php				//
//Default username/password is admin/admin			//
//////////////////////////////////////////////////////////////////

//------------------------------------DO NOT CHANGE BELOW----------------------------------------
include "configadmin.php";
if($norun!=1){
$file = file($configdatafile);
$total=sizeof($file);
$j=0;



for($i=1;$i<$total-1;$i++){
	$vars=explode("|",$file[$i]);

	for($k=0;$k<=2;$k++){
		$vars[$k] = str_replace("<br>","\n",$vars[$k]);
	}

	//$vars[1]=str_replace("_"," ",$vars[1]);
	$varname[$j]=$vars[0];
	$var[$j]=$vars[1];
	$vardes[$j]=$vars[2];

	$evs="$" .$varname[$j] ."=\"" .$var[$j] ."\";";
	eval(" $evs ");
	$j++;
}
}
?>
