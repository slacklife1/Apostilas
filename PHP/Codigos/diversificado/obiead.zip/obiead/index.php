<link rel="stylesheet" href="inc/css.css">
<script src="inc/modules.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="Content-Language" content="en-us">
<title>AD service - Powered by obieAD </title>
<body topmargin="0" leftmargin="0" bgcolor="#FFFFFF">

<div align=center>
<table border=0 width=80%><tr><td>
<br><br>
<table border="0" cellpadding="2" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="100%" bgcolor="#CCE6FF">
  <tr>
    <td width="60%" bgcolor="#FFFFFF" align="left" valign="top"><img src="logo.gif">
	<p><h3>Are you a new user</h3>
      <p>FREE placing your banner AD on our website.
	<ul>
      <li></li>
      <li>Up to 1000 visitors a day on our website</li>
      <li>Auto count visitors clicking on your banner</li>
      <li>....and many more</li>
    </ul>
    <p align="center"><a href="signup.php">SIGN UP NOW</a><p><br></p></td>
    <td width="40%" align="center" valign="middle"><h3>Members AREA</h3><br>
	You must login to editing<br>your banner's info<p>
<FORM action="login.php" method="post"> 
<input type=hidden name="action" value="login">
<P>Username: 
<INPUT type="text" name="username" value="" size="15"> 
<p>Password: 
<INPUT type="password" name="password" value="" size="15"> 
<p><INPUT type="submit" value="Log-in"> 
</FORM>

    </td>
  </tr>
</table>
<p>
<center>
<a href="http://domain.com">Home</a>  |  
<a href="func.php?action=showall">Show all banners AD</a>  |  
<a href="func.php?action=showsubmiters">Show waiting banners</a>  |  
<a href="signup.php">Signup an account</a> |  
<a href="login.php">Member's area</a></center>
</td></tr></table></div>
<p><br></p>
<center>
Copyright <a href="http://ww.obiewebsite.sourceforge.net" target="_blank">Obie</a> and obieAD version 1.1. All right reserved.
</center>
</body>
