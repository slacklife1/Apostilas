<link rel="stylesheet" href="inc/css.css">
<center><font size=1>Advertisement system</font><br>
<?
//////////////////////////////////////////////////////////
//			--obieAD--			//
//							//
//		-The AD banner management-		//
//		-Version 1.0 created on Dec/02-		//
//							//
//	Writen by Minh Nguyen Duong @ obie.		//
//	All right reserved - http://obiewebsite.sourceforge.net	//
//							//
//	obiePAD included				//
//							//
//	This Software is FREE and can be modified 	//
//	and redistributed under the condition that 	//
//	the copyright and information above stays 	//
//	intact and with the script.			//
//							//
//	If you redistribute obieAD, please link back	//
//	to http://obiewebsite.sourceforge.net			//
//////////////////////////////////////////////////////////
include "config.php";

//Counter function
if($action=='count' && $ad){
    $file=file($adsfile); 
    while(list(,$value)=each($file)){ 
        list($fname,$femail,$furl,$fbanner,$fuser,$fpass,$fcounter,$ferror)=split( "\|", $value); 
        if($ad==$fuser){ 
            $xaucu="$fname|$femail|$furl|$fbanner|$fuser|$fpass|$fcounter|$ferror|\n"; 
	    $fcounter = $fcounter + 1;
            $xaumoi="$fname|$femail|$furl|$fbanner|$fuser|$fpass|$fcounter|$ferror|\n"; 
            $fp = fopen($adsfile, "r");  
            $data = fread($fp, filesize($adsfile));  
            fclose($fp);  
            $newdata = str_replace($xaucu, $xaumoi, $data);  
            $fp = fopen($adsfile,"w");  
            fwrite($fp,$newdata) or die ("error writing"); 
            fclose($fp); 
            $succ = "1"; 
	    print("<center>Connecting the site <b>$furl</b><p><br></p><i>Please wait....</i></center>");
	    print("<script>self.location.replace('$furl');</script>");
        } 
    } 
}
if($action=='error' && $ad){
    if ($code <= $max){
    $file=file($adsfile); 
    while(list(,$value)=each($file)){ 
        list($fname,$femail,$furl,$fbanner,$fuser,$fpass,$fcounter,$ferror)=split( "\|", $value); 
        if($ad==$fuser){ 
            $xaucu="$fname|$femail|$furl|$fbanner|$fuser|$fpass|$fcounter|$ferror|\n"; 
	    $ferror = $ferror + 1;
            $xaumoi="$fname|$femail|$furl|$fbanner|$fuser|$fpass|$fcounter|$ferror|\n"; 
            $fp = fopen($adsfile, "r");  
            $data = fread($fp, filesize($adsfile));  
            fclose($fp);  
            $newdata = str_replace($xaucu, $xaumoi, $data);  
            $fp = fopen($adsfile,"w");  
            fwrite($fp,$newdata) or die ("error writing"); 
            fclose($fp); 
            $succ = "1"; 
	    print("ERROR ad");
        } 
     } 
    }
    else {

    $file=file($adsfile); 
    while(list(,$value)=each($file)){ 
        list($fname,$femail,$furl,$fbanner,$fuser,$fpass,$fcounter,$ferror,$blank)=split( "\|", $value); 
        if($ad==$fuser){ 
            $xaucu="$fname|$femail|$furl|$fbanner|$fuser|$fpass|$fcounter|$ferror|\n";
	    $adadd = $xaucu;
            $xaumoi=""; 
            $fp = fopen($adsfile, "r");  
            $data = fread($fp, filesize($adsfile));  
            fclose($fp);  
            $newdata = str_replace($xaucu, $xaumoi, $data);  
            $fp = fopen($adsfile,"w");  
            fwrite($fp,$newdata) or die ("error writing"); 
            fclose($fp); 
            $succ = "1"; 
        } 
    } 
    $fp=fopen($submitfile,"a"); 
    fwrite($fp,$adadd); 
    fclose($fp); 
$mailmessage="Hi,
We moved your banner AD to our Submiter database because your banner image is error.

Your AD info :
--------------
Username: $fuser
Password: $fpass
Banner URL: $fbanner
	
You can show our Submiter database at : $script_path/func.php?action=showsubmiters
and edit your account at : $script_path/login.php (Repair mode)

Thanks for using our services
$admin_email
$admin_website";
	
   mail($femail, "Your banner is error", $mailmessage, "From: $admin_email\r\n" ."Reply-To: $admin_email\r\n" ."X-Mailer: PHP/" . phpversion());

}	
}
if($action=='showall'){

    $file=file($adsfile);
    $file = array_reverse($file);
    $tongsomembers = sizeof($file) - 1;
    $sf = sizeof($file);
    if(!$page) $page=0;
    $i = 0;
    print("<title>View all banners</title>");
    print("<h3>View all members
	<br><font size=1>There are <font color=red>$tongsomembers</font> banner(s) registered with our AD services</font></h3>
    <table width=80% border=0 cellpadding=1 cellspacing=2 bgcolor=#F0F0F0><tr><td width=1% align=center valign=middle background=\"inc/nentable.gif\"><img src=blank width=1 height=26></td>
    <td  background=\"inc/nentable.gif\" width=89% align=center valign=middle><b>Banners</b></td><td width=5%  background=\"inc/nentable.gif\"><b>Clicks</b></td><td width=5%  background=\"inc/nentable.gif\"><b>Errors</b></td>");
    print("</tr>");
    while(list(,$value)=each($file)){ 
        list($fname,$femail,$furl,$fbanner,$fuser,$fpass,$fcounter,$ferror)=split( "\|", $value);
	if ($fuser!='root'){
	if($i<($page*$entry_on_page + $entry_on_page) && $i>=($page*$entry_on_page)){
        $xaucu="$fname|$femail|$furl|$fbanner|$fuser|$fpass|$fcounter|$ferror|\n";
	$fbanner =  str_replace('^/','',$fbanner);
	print("<tr bgcolor=white><td width=1%>" .($i+1) ."</td><td width=89%><center><a href=\"$furl\" target=\"_blank\"><img src=\"$fbanner\" width=$w height=$h border=0 alt=\"Sitename : $fname\nURL: $furl\"></a></center></td><td width=5%>$fcounter</td><td width=5%>$ferror</td>");
	}}
    $i++;
    } 
    print("</table><br>");
    $tongsotrang=floor($sf/$entry_on_page) + 1;
    print("There are <b>$tongsotrang</b> pages<p><br></p>");
    if($page!=0) print(" <a href=\"func.php?action=showall&page=" .($page-1) ."\"><img border=0 src=inc/prev.gif></a> ");
    if($page*$entry_on_page<$sf-$entry_on_page-1) print(" <a href=\"func.php?action=showall&page=" .($page+1) ."\"><img border=0 src=inc/next.gif></a> </center>");
}

if ($action=='chmodf' && $file){
chmod ($file, 0744);
print("<script>alert('CHMOD file \"$file\" successfully');</script>");
}

if ($action=='phpinfo'){
phpinfo();
}

if($action=='about'){
print("
<title>About obieAD </title>
<div align=center>
<table class=bar border=\"0\" cellpadding=\"2\" cellspacing=\"1\" style=\"border-collapse: collapse\" bordercolor=\"#111111\" width=\"80%\" bgcolor=\"#CCE6FF\">
  <tr>
    <td width=\"100%\"><center><img src=\"logo.gif\" alt=\"obieAD logo\">
    <p>-<b>Smart AD banner management</b>-</p>
    <p>-Version $obieADversion created on Dec/02-</p>
    <p>Writen by Minh Nguyen Duong @ obie.</p>
    <p>All right reserved - <a target=\"_blank\" href=\"http://obiewebsite.sourceforge.net\">
    http://obiewebsite.sourceforge.net</a></p>
    <p><b>obie</b>PAD included</p>
    <p>This Software is FREE and can be modified <br>
    and redistributed under the condition 
    that the <br>
    copyright and information above stays intact and with the script.
    </p>
    <p>If you redistribute <b>obie</b>AD, please link back to
    <a target=\"_blank\" href=\"http://obiewebsite.sourceforge.net\">http://obiewebsite.sourceforge.net</a></p>
    <p>&nbsp; </p>
    </center></td>
  </tr>
</table>
</div>
");
}

if ($action=='showsubmiters'){
    $file=file($submitfile);
    $file = array_reverse($file);
    $tongsosubmiters = sizeof($file) - 1;
    print("<title>Show all submiters</title><h3>Show all submiters
	<br><font size=1>Total <font color=red>$tongsosubmiters</font> users submited for our AD system</font></h3>");
    print("<table cellspacing=1 border=0 bgcolor=#F0F0F0 width=92%>
	<tr><td width=1% background=\"inc/nentable.gif\"><img src=blank width=1 height=26></td><td width=10% background=\"inc/nentable.gif\"><b>Site name</b></td><td width=59% background=\"inc/nentable.gif\"><b>Banner</b></td><td width=15% background=\"inc/nentable.gif\"><b>Username</b></td>
	<td width=15% background=\"inc/nentable.gif\"><b>Status</b></td></tr>");
    $i=1;
    while(list(,$value)=each($file)){ 
        list($fname,$femail,$furl,$fbanner,$fuser,$fpass,$fcounter,$ferror)=split( "\|", $value);
	if ($fuser!='root'){
		$fbanner =  str_replace('^/','',$fbanner);
		print("<tr bgcolor=white><td width=1%>$i</td><td width=10%>$fname</tD><td width=59%><a href=\"$furl\" title=\"URL: $furl\nUser email: $femail\"><img width=$w height=$h src=$fbanner border=0></a></tD><td width=15%>$fuser</td><td width=15%>");
		if ($ferror>=$max) print("<font color=red>BAD IMAGE</font>");
		else print("Waiting....");
		print("</td></tr>");
		}
	$i=$i+1;
	}
    print("</table>");
}
if ($action=='testobiead'){
print("<p><font size=2><b>Testing obieAD</b></font><hr size=1 color=#DFDFDF>
	<u>\$background_color</u> variable : <b>$background_color</b><br>
	You can change it in config.php file<p>
	<script src=obiead.js></script>");
}

?>
<p></p><p align="center">
Powered by <a target="_blank" href="http://obiewebsite.sourceforge.net"><b>obie</b>AD</a> version <? print($obieADversion); ?>. The AD banners management</p>
</center>
