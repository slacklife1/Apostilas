<link rel="stylesheet" href="inc/css.css">
<script src="inc/modules.js"></script>
<? 
//////////////////////////////////////////////////////////
//			--obieAD--			//
//							//
//		-The AD banner management-		//
//		-Version 1.0 created on Dec/02-		//
//							//
//	Writen by Minh Nguyen Duong @ obie.		//
//	All right reserved - http://obiewebsite.sourceforge.net	//
//							//
//	obiePAD included				//
//							//
//	This Software is FREE and can be modified 	//
//	and redistributed under the condition that 	//
//	the copyright and information above stays 	//
//	intact and with the script.			//
//							//
//	If you redistribute obieAD, please link back	//
//	to http://obiewebsite.sourceforge.net			//
//////////////////////////////////////////////////////////
include "config.php";

$mode="login";

if ($auto_error==0) $auto_error='OFF';
else $auto_error='ON';

if($a_u == $admin_username && $a_p==$admin_password){
	$kieu='text';$ten1='<b>Staff only</b><br>Change clicks counter:';$ten2='<br>Change error counter:';
	$text0='<b>ADMIN</b>, you are editing infomations of account ';}
else $kieu='hidden';

//Check repair or login mode


#If the call for the script is to log them in, DO IT! 
if($action == "login"): 
    #This makes sure all fields are filled out. 
    if((!$username)or(!$password)){ 
        #If there is one missing, send them to the error. 
        error_message("One or more required fields were left blank!", $username, $password); 
    } 
    $file=file($adsfile);
    while(list(,$value)=each($file)){ 
        list($fname,$femail,$furl,$fbanner,$fuser,$fpass,$fcounter,$ferror,$blank)=split( "\|", $value); 
        if($username==$fuser && $username!='root') {$mode='login';}
	else {$mode='repair';}
	}


    #Open the datafile and login the user. 
    if($mode=='repair') {
	$file=file($submitfile);
	$chuy="<p><font color=red size=2><b>Your banner is in waiting database</b><br>
	<font color=black size=1>After Admin agreeing, your banner will be showed in our AD banner list</font></font></p>";
	}
    else $file=file($adsfile); 
    while(list(,$value)=each($file)){ 
        list($fname,$femail,$furl,$fbanner,$fuser,$fpass,$fcounter,$ferror,$blank)=split( "\|", $value); 
        if($username==$fuser && $password==$fpass && $username!='root'){ 
	$fbanner2 =  str_replace('^/','',$fbanner);
	    echo "<title>obieAD login</title><h3>Advertisement system<br>
<font size=\"1\">Edit your account</font></h3>
Hello $text0 <font color=red><b>$fuser</b></font>, you are loged in<br>
Clicks counter : <font color=red><b>$fcounter</b></font><br>
Bad image : <font color=red><b>$ferror</b></font> times (auto detect bad images is <font color=red><b>$auto_error</b></font>)
<p><u><font size=\"1\">Note : All fields are required</font></u></p>
$chuy
<FORM action=\"$PHP_SELF?action=change&a_u=$a_u&a_p=$a_p\" method=\"post\" onsubmit=\"return checkemail(document.all.email);\"> 
<input type=\"hidden\" name=\"error\" value=\"0\" size=\"20\">
<input type=hidden name=\"mode\" value=\"$mode\">
<table border=\"0\" cellpadding=\"2\" cellspacing=\"1\" style=\"border-collapse: collapse\" bordercolor=\"#111111\" width=\"80%\" bgcolor=\"#3333CC\">
  <tr>
    <td width=\"100%\" bgcolor=\"#99CCFF\" colspan=\"2\"><b>Change your profiles</b></td>
  </tr>
  <tr>
    <td width=\"25%\" bgcolor=\"#FFFFFF\" align=\"left\" valign=\"top\"><P>Your site 
    name<P><b>Real</b> e-mail</td>
    <td width=\"75%\" bgcolor=\"#FFFFFF\" align=\"left\" valign=\"top\"> 
    <INPUT type=\"text\" name=\"name\" size=\"20\" value=\"$fname\"><p> 
    <INPUT type=\"text\" name=\"email\" size=\"20\" value=\"$femail\"></td>
  </tr>
  <tr>
    <td width=\"100%\" bgcolor=\"#99CCFF\" colspan=\"2\"><b>Change your banner info</b></td>
  </tr>
  <tr>
    <td width=\"25%\" bgcolor=\"#FFFFFF\" align=\"left\" valign=\"top\"><P>Website<p>
    Banner URL</td>
    <td width=\"75%\" bgcolor=\"#FFFFFF\" align=\"left\" valign=\"top\"> 
    <INPUT type=\"text\" name=\"url\" size=\"30\" value=\"$furl\"> eg: 
    http://domain.com<p> 
    <INPUT type=\"text\" name=\"banner\" size=\"50\" value=\"$fbanner\" onBlur=\"checkimage(this);\"> <br>
    Note: If banner URL like \"<b>^userbanners/</b>xyz.gif\", please do not change it.</p>
    <p> 
    Note : our banner size is <b>$w</b> pixels width and <b>$h</b> 
    pixels height</p>
    <table border=0 bgcolor=gray cellspacing=1 cellpadding=0 width=$w height=$h><tr><td bgcolor=#F0F0F0>
    <img name=ex src=\"$fbanner2\" height=$h width=$w onerror=\"alert('The image for your banner IS NOT FOUND\\n\\nPlease type a correct URL to your image');\">
    </td></tr></table>
    <p>$ten1 <input type=\"$kieu\" name=\"counter\" size=\"10\" value=\"$fcounter\" maxlength=10>
    $ten2 <input type=\"$kieu\" name=\"error\" value=\"$ferror\" size=\"10\"><INPUT type=\"hidden\" name=\"username\" size=\"10\" value=\"$fuser\" maxlength=10></td>
  </tr>
  <tr>
    <td width=\"100%\" bgcolor=\"#99CCFF\" colspan=\"2\"><b>Change password</b><br>You must re-login after change password</td>
  </tr>
  <tr>
    <td width=\"25%\" bgcolor=\"#FFFFFF\" align=\"left\" valign=\"top\"><P>
    Password</td>
    <td width=\"75%\" bgcolor=\"#FFFFFF\" align=\"left\" valign=\"top\"> 
    <INPUT type=\"password\" name=\"password\" size=\"10\" value=\"$fpass\" maxlength=10> 
    Less than 10 characters</td>
  </tr>
  <tr>
    <td width=\"100%\" bgcolor=\"#FFFFFF\" colspan=\"2\">
    <INPUT type=\"submit\" value=\"Change datas\"></td>
  </tr>
</table>
</FORM>";

            $logink="1"; 
        } 
    } 
    if($logink!=1): 
        error_message("Login failed, bad username/password", $username, $password); 
    endif; 
elseif($action=="change"): 
    #This makes sure all fields are filled out. 
    if((!$name)or(!$email)or(!$url)or(!banner)or(!$username)or(!$password)){ 
        #If there is one missing, send them to the error. 
        error_message("One or more required fields were left blank! Please re-login.", $username, $password); 
    } 
    #Open the datafile and login the user. 
    	if($mode=='repair') $file=file($submitfile);
    	else $file=file($adsfile); 
    while(list(,$value)=each($file)){ 
        list($fname,$femail,$furl,$fbanner,$fuser,$fpass,$fcounter,$ferror,$blank)=split( "\|", $value); 
        if($username==$fuser && $username!='root'){ 
            $xaucu="$fname|$femail|$furl|$fbanner|$fuser|$fpass|$fcounter|$ferror|\n"; 
            $xaumoi="$name|$email|$url|$banner|$username|$password|$counter|$error|\n"; 
            	if($mode=='repair') $fp = fopen($submitfile, "r");
            	else $fp = fopen($adsfile, "r");
            	if($mode=='repair') $data = fread($fp, filesize($submitfile));
            	else $data = fread($fp, filesize($adsfile));  
            fclose($fp);  
            $newdata = str_replace($xaucu, $xaumoi, $data);  
            	if($mode=='repair') $fp = fopen($submitfile,"w");
	    	else $fp = fopen($adsfile,"w");  
            fwrite($fp,$newdata) or die ("error writing"); 
            fclose($fp); 
            $succ = "1"; 
	    if ($a_u == $admin_username && $a_p == $admin_password){
		print("<h3>Member information was changed by admin successfully</h3>
		<p><A HREF=\"admin.php?a_u=$a_u&a_p=$a_p&action=viewall\">Back to admin control panel</A>");
		}
	    else {
		print("<h3>Everything was changed successfully!</h3>
		<p><A HREF=\"login.php?username=$username&password=$password&action=login&mode=$mode\">Back to account control panel</A>"); 
	    }
        } 
    } 
    if(!$succ): 
        error_message("Login failed, bad username/password", $username, $password); 
    endif; 
else:?> 
<h3>Advertisement system<br>
<title>Login page</title>
<font size="1">You must login to editing your banner's info</font></h3>
<FORM action="<?=$PHP_SELF;?>" method="post"> 
<input type=hidden name=action value=login>
<P>Username: <INPUT type="text" name="username" size=\"20\"> 
<P>Password: <INPUT type="password" name="password" size=\"20\"> 
<p><INPUT type="submit" value="Log-in">
</FORM> 
<?endif;
//Thong bao loi
function error_message($message, $username, $password){?> 
<h3>Advertisement system<br>
<title>Loging in failed</title>
<font size="1">You must login to editing your banner's info</font></h3>
<font color=red><b><?echo $message;?></b></font></H3> 
<FORM action="<?=$PHP_SELF;?>" method="post"> 
<input type=hidden name=action value=login>
<input type=hidden name="mode" value="$mode">
<P>Username: 
<INPUT type="text" name="username" value="<?echo $username;?>" size=\"20\"> 
<P>Password: 
<INPUT type="password" name="password" value="<?echo $password;?>" size=\"20\">
<p><INPUT type="submit" value="Log-in">
</FORM>
<p><a href="<? $PHP_SELF; ?>?action=lostpass&ad=<? print($username); ?>">Forgot your password, we can help you</a>
<?exit; 
}?>
<?
if ($action=='lostpass' && $ad){
//Mail the password to this account's email address
    $pass2email = 'no';
    	if($mode=='repair') $file=file($submitfile);
    	else $file=file($adsfile); 
    while(list(,$value)=each($file)){ 
        list($fname,$femail,$furl,$fbanner,$fuser,$fpass,$fcounter,$ferror,$blank)=split( "\|", $value); 
        if($ad==$fuser && $ad!='root'){ 
		$pass2email = $femail;
		$passsend = $fpass;
		$message = "Hi $fuser,

You have using our password lookup service

Here is yours:
Username : $fuser
Password : $passsend
------------
Please go to the URL : 
$script_path/login.php to login and edit your account

------------
Advertisement service of $admin_website";
		//mail function here
		mail($pass2email, "obieAD - password lookup", $message, "From: $admin_email\r\n" ."Reply-To: $admin_email\r\n" ."X-Mailer: PHP/" . phpversion());
		print("<hr size=1 color=black><b>Forgot password</b><p>We mailed the password to your mail box : <b>$pass2email</b><p>Please check the your mailbox and re-login");
        } 
    } 
    if ($pass2email == 'no') print("<hr size=1 color=black><b>Forgot password</b><p>No account found</p><p>Please view our Submiter database <a href=func.php?action=showsubmiters target=_blank>here</a> to find your account (It may was deleted) and Re-login with\"<b>repair</b>\" mode");
}

?>
<p></p><p align="center">
Powered by <a target="_blank" href="http://obiewebsite.sourceforge.net"><b>obie</b>AD</a> version <? print($obieADversion); ?>. The AD banners management</p>
