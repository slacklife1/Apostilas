<!--
Obie Config Admin (OCA)
The Visual configuration variables for any your PHP scripts
http://obiewebsite.sourceforge.net
-->

<style>
<!--
.ocatext         { font-family: Verdana; font-size: 8pt; color: black }
.ocainput  { background-color: #F0F0F0; border: 1 solid lightgrey font-family: Verdana; font-size: 8pt; }
body         { font-family: Verdana; font-size: 9pt; color: black }
a{color:#0060C8;text-decoration:none;}
a:hover {color:red;text-decoration:none;}
-->
</style>
<script>
function run(url) {
    setTimeout("top.location.href='" + url + "'",2000);
}

function chkconf(){
var i=0;
kiemtra=1;
if(document.all.chkbox2.checked==false){
	for(i=0;i<document.formconf.elements.length;i++){
		if(document.formconf.elements[i].value=='') {
		kiemtra=0;
		document.formconf.elements[i].style.backgroundColor='lightpink';
		document.formconf.elements[i].focus();
		}
	}
if(kiemtra==0) {
	alert("There are blank form(s)");
	return false;
}
else return true;
}
else return true;
}

function kt(oldconf,newconf){
	if(oldconf!=newconf) {
	if(document.all.chkbox.checked==false)

		 alert("WARNING\n\nYou are changing you VARIABLE NAME\nAre you SURE to continue\n\n\nYour OLD VARIABLE NAME is  \$" + oldconf + "");

	else window.status='WARNING : You are changing you VARIABLE NAME';

	document.all.stats.value =  "Changed VARIABLE NAME \"" +oldconf+ "\" to \"" +newconf+ "\"\n" + document.all.stats.value;
	}
}
function kt2(oldconf,newconf,nameofconf){
	if(oldconf!=newconf) {
	document.all.stats.value =  "Changed VARIABLE VALUE \"" +oldconf+ "\" to \"" +newconf+ "\" (of variable $"+nameofconf+")\n" + document.all.stats.value;
	}
}
</script>
<?
//////////////////////////////////////////////////////////////////
//		   --Obie Config Admin--			//
//								//
//		--USEFUL for PHP programmers--			//
//								//
//		-Version 1.0 created on Mar/03 -		//
//								//
//	Writen by Minh Nguyen Duong @ obie.			//
//	All right reserved - http://obiewebsite.sourceforge.net		//
//								//
//								//
//	This Software is FREE and can be modified 		//
//	and redistributed under the condition that 		//
//	the copyright and information above stays 		//
//	intact and with the script.				//
//								//
//	If you redistribute Obie Config Admin, please link back	//
//	to http://obiewebsite.sourceforge.net				//
//////////////////////////////////////////////////////////////////
//Change log: 							//
//								//
//								//
//								//
//////////////////////////////////////////////////////////////////
//USING:							//
//Please read carefully Obie Config Admin manual		//
//								//
//////////////////////////////////////////////////////////////////

$norun=1;
include "configadmin.php";
$file = file($configdatafile);
$total=sizeof($file);

////////////////////////////////////////////////////////////////////////////////////////////////
//Edit and update configuration file
////////////////////////////////////////////////////////////////////////////////////////////////
////Start parsing//////////////////////
$j=0;
for($i=1;$i<$total-1;$i++){
	$vars=explode("|",$file[$i]);

	//Format input data
	for($k=0;$k<=2;$k++){
		$vars[$k] = str_replace("<br>","\n",$vars[$k]);
	}
	$vars[1]=str_replace("_"," ",$vars[1]);
	$varname[$j]=$vars[0];
	$var[$j]=$vars[1];
	$vardes[$j]=$vars[2];

	$evs="$" .$varname[$j] ."=\"" .$var[$j] ."\";";
	eval(" $evs ");
	$j++;
}
//==>Your variables is READY for using

///End parsing/////////////////

if(!$a_u || !$a_p){
		print("<title>$my_script_name control panel</title>
		<div class=ocatext align=center><center>
		<h3>$my_script_name control panel<br><font size=1>Staff only</font></h3><p>
		<form action=\"$PHP_SELF\" method=\"POST\">
		<input type=hidden name=admin value=login>
		Username <input class=ocainput type=text name=\"a_u\" size=20><br>
		Password   <input class=ocainput type=password name=\"a_p\" size=20><br>
		<br><input class=ocainput type=submit value=\"Log in\">
		</form>
		<body onload=\"document.all.a_u.focus();\">
		</div></center>");
}
else if($a_u!=$admin_username || $a_p!=$admin_password){
		print("<p>Wrong username or password. Please go back to re-login</p>");
}
///////////Start of control panel///////////////
if($admin=='login' && $a_u==$admin_username && $a_p==$admin_password){

if($a_u==$admin_username && $a_p==$admin_password){


	print("<title>$my_script_name control panel </title>");
	print("<h3><font color=navy>$my_script_name</font><br><font size=2>Script Control Panel</font></h3><hr size=1 color=black>");

	if(!file_exists($configdatafile)){
	print("
	<script>
	alert('You are using ConfigAdmin for the first time\\n\\nPlease create your new configuration data file');
	self.location='$PHP_SELF?a_u=$a_u&a_p=$a_p&admin=login&go=new';
	</script>
	<div style=\"display:none\">");
	}

	if($fully_editor==1)
	print("<div align=center>
	<table cellspacing=1 cellpadding=2 bgcolor=#AED0F2 border=0 width=100% class=ocatext>
	<tr>
	<td bgcolor=white width=1% align=center><a href=\"$PHP_SELF?admin=login&a_u=$a_u&a_p=$a_p\">Edit variables</a></td>
	<td bgcolor=white width=1% align=center><a href=\"$PHP_SELF?admin=login&a_u=$a_u&a_p=$a_p&go=add\">Add new variable</a></td>
	<td bgcolor=white width=1% align=center><a href=\"$PHP_SELF?admin=login&a_u=$a_u&a_p=$a_p&go=new\" onclick=\"return confirm('Are you sure\\n\\nIt will RESET your current config file. All your data will be destroyed.\\n\\nOnly using this function if you use ConfigAdmin in the FIRST time','');\">Reset/Create new</a></td>
	<td bgcolor=white width=2% align=center><a href=\"$PHP_SELF?admin=login&a_u=$a_u&a_p=$a_p&go=gen\">Generate usual config file</a></td>
	</tr></table></div><br>
	<div align=center>
	<table cellspacing=1 cellpadding=4 bgcolor=gray border=0 width=100% class=ocatext>
	<tr><td bgcolor=#F0F0F0>");
	}

/////////START GO///////////////////////////////

	if(!$go && $fully_editor==1){	
	//THIS IS THE FULL CONTROL PANEL FOR THE DEVELOPER OF PHP SCRIPT

	print("<font face=Verdana size=1>
	<h4>::Edit your Variables of $my_script_name</h4>
	<div align=center>
	<table width=99% cellspacing=1 cellpadding=4 border=0 bgcolor=gray class=ocatext>
	<tr>
	<td bgcolor=lightgrey width=1%>ID</td>
	<td bgcolor=lightgrey width=13%>Variable NAME<br><img src=blank.gif height=1 width=100></td>
	<td bgcolor=lightgrey width=33%>Variable VALUE<br><img src=blank.gif height=1 width=300></td>
	<td bgcolor=lightgrey width=52%>Description of variable</td>
	<td bgcolor=lightgrey width=1%>Action</td>
	</tr>

	<form action=$PHP_SELF method=POST name=formconf onsubmit=\"return chkconf();\">
	<input type=hidden name=admin value=update>
	<input type=hidden name=a_u value=$a_u>
	<input type=hidden name=a_p value=$a_p>");


	for($i=1;$i<$total-1;$i++){
		//$file[$i]=str_replace("_"," ",$file[$i]);
		$vars=explode("|",$file[$i]);

		//Format input data
		$chkpos=0;	
		$varname[$j]=$vars[0];
		$var[$j]=$vars[1];
		$vardes[$j]=$vars[2];

		$string=$file[$i];
		$string=str_replace(" ","_",$string);
		
		print("<tr>
		<td width=1% bgcolor=white>$i</td>
		<td width=13% bgcolor=white><font size=2><b>$</b></font>");

		print(" <input class=ocainput size=10 type=text name=confs[] value=\"$varname[$j]\" onblur=\"if (this.value=='') {alert('Not accept BLANK value of this field');this.focus();}else kt('$varname[$j]',this.value);\">");

		print("</td><td width=33% bgcolor=white><font size=2><b>=</b></font>");

		print(" <input class=ocainput size=30 type=text name=confs[] value=\"" .str_replace("_"," ",$var[$j]) ."\" onblur=\"kt2('$var[$j]',this.value,'$varname[$j]');\">");

		print("</td><td width=52% bgcolor=white>");

		print("<input size=30 class=ocainput type=text name=confs[] value=\"" .str_replace("_"," ",$vardes[$j]) ."\" onblur=\"if(this.value=='') this.value='none';\">");


		print("</td>
		<td width=1% bgcolor=white>
		<a href=\"$PHP_SELF?admin=del&a_u=$a_u&a_p=$a_p&string=$string\" onclick=\"return confirm('Are you sure to DELETE variable \$$varname[$j]','');\">Delete</a>
		</td></tr>");

		$j++;
	}
	print("</table></div>
	<p>
	 Hide all warnings <input type=checkbox name=chkbox><br>
	 Use BLANK forms <input type=checkbox name=chkbox2><br>
	<p><input type=submit value=Update class=ocainput style=\"background-color='orange';\">  <input class=ocainput type=reset value=\"Reset all values\"></form>
	<p>Status<br><textarea cols=80 rows=5 name=stats class=ocainput></textarea>");
	}
	
	if($fully_editor==0){
	//THIS IS THE CONTROL PANEL FOR USERS OF YOUR PHP SCRIPT

	print("<font face=Verdana size=1><h4>::Edit configurations</h4><div align=center>");

	print("<table width=99% cellspacing=1 cellpadding=4 border=0 bgcolor=gray class=ocatext>
	<tr>
	<td bgcolor=lightgrey width=1%>ID</td>
	<td bgcolor=lightgrey width=98%>Description<br><img src=blank.gif height=1 width=100></td>
	<td bgcolor=lightgrey width=1%>Value</td>
	<td bgcolor=lightgrey width=1%>Default VALUE<br><img src=blank.gif height=1 width=140></td>
	</tr>

	<form action=$PHP_SELF method=POST name=formconf onsubmit=\"return chkconf();\">
	<input type=hidden name=admin value=update>
	<input type=hidden name=a_u value=$a_u>
	<input type=hidden name=a_p value=$a_p>");


	for($i=1;$i<$total-1;$i++){
		//$file[$i]=str_replace("_"," ",$file[$i]);
		$vars=explode("|",$file[$i]);

		//Format input data
		$chkpos=0;	
		$varname[$j]=$vars[0];
		$var[$j]=$vars[1];
		$vardes[$j]=$vars[2];

		$string=$file[$i];
		$string=str_replace(" ","_",$string);

		$var[$j]=str_replace("_"," ",$var[$j]);		
		
		print("<tr>
		<td width=1% bgcolor=white>$i</td>
		<td width=97% bgcolor=white><font size=2>" .str_replace("_"," ",$vardes[$j]) ."</font></td>
		<td width=1% bgcolor=white>");

		print(" <input class=ocainput size=10 type=hidden name=confs[] value=\"$varname[$j]\" onblur=\"if (this.value=='') {alert('Not accept BLANK value of this field');this.focus();}else kt('$varname[$j]',this.value);\">");

		//if($var[$j]=='admin') $noac="onfocus=\"this.blur();\"";
		//else $noac="";

		print(" <input class=ocainput size=30 type=text name=confs[] value=\"$var[$j]\" onblur=\"kt2('$var[$j]',this.value,'$varname[$j]');\">");

		print("<input size=30 class=ocainput type=hidden name=confs[] value=\"$vardes[$j]\" onblur=\"if(this.value=='') this.value='none';\">");


		print("</td>
		<td width=1% bgcolor=white>"
		.str_replace("_"," ",$var[$j])
		."</td></tr>");

		$j++;
	}
	print("</table></div>
	<p>
	 Hide all warnings <input type=checkbox name=chkbox checked><br>
	 Use BLANK forms <input type=checkbox name=chkbox2><br>
	<p><input type=submit value=Update class=ocainput style=\"background-color='orange';\">  <input class=ocainput type=reset value=\"Reset all values\"></form>
	<p>Status<br><textarea cols=80 rows=5 name=stats class=ocainput></textarea>");

	}

	if($go=='add' && $fully_editor==1){
		print("<h4>::ADD new variable</h4>");
		print("<p><u>NOTE</u> : This version support only 4 scalar types (Boolean, Integer, floating-point number (float), string) and NULL type. 
		Obie Config Admin does not support Array, Object and resource types. If you need to use those types in your scripts, please using an usual config file, not using Obie Config Admin</p>");
		print("<form action=\"$PHP_SELF\" method=POST name=formconf onsubmit=\"return chkconf();\">
		<input type=hidden name=admin value=addnew>
		<input type=hidden name=a_u value=$a_u>
		<input type=hidden name=a_p value=$a_p>
		<div align=center>
		<table width=99% cellspacing=1 cellpadding=4 border=0 bgcolor=gray class=ocatext>
		<tr>
		<td bgcolor=lightgrey width=14%>Variable NAME<br><img src=blank.gif height=1 width=100></td>
		<td bgcolor=lightgrey width=33%>Variable VALUE<br><img src=blank.gif height=1 width=300></td>
		<td bgcolor=lightgrey width=53%>Description (not require)</td>
		</tr>
		<tr>
		<td bgcolor=white width=14%>$ <input class=ocainput type=text size=10 name=conf1 onblur=\"if (this.value=='') {alert('Not accept BLANK value of this field');this.focus();}\"><br><img src=blank.gif height=1 width=100></td>
		<td bgcolor=white width=33%>= <input class=ocainput type=text size=30 name=conf2></td>
		<td bgcolor=white width=53%><input class=ocainput type=text size=30 name=conf3></td>
		</tr>
		</table></div>
		<p>Use BLANK values : <input type=checkbox name=chkbox2>
		<p><input class=ocainput type=submit value=\"Add new Variable\"></form>
		<p><u><b>IMPORTANT:</b></u> Do not add blank charactor in \"Variable NAME\" and make it is a number. Not \"$test var\" and Not \"$1242\".
		");
	}	

	if($go=='new' && $fully_editor==1){
		$fp=fopen($configdatafile,"w"); 
		fwrite($fp,"<?\n?>"); 
		fclose($fp); 		
		print("<p align=center>New configuration file : <b>$configdatafile</b> has been created</p>");
	}	

	if($go=='gen' && $a_u==$admin_username && $a_p==$admin_password && $fully_editor==1){
		print("<h4>::Your usual config.php file</h4>
		<textarea cols=80 rows=15 wrap=off>
<?
////////////////////////////////////////////////////////////////////////////
//Your usual config.php file, copy and paste to your config.php file if
// you do not want to continue using Obie Config Admin
//
//More useful PHP scripts at obiewebsite.sourceforge.net
////////////////////////////////////////////////////////////////////////////

");
	
		for($i=1;$i<$total-1;$i++){
		$vars=explode("|",$file[$i]);
		$vars[1]=str_replace("_"," ",$vars[1]);
		$vars[2]=str_replace("_"," ",$vars[2]);
		print("\$$vars[0] = '$vars[1]';  //$vars[2]\n\n");
		}
		print("?></textarea>");
	}


/////////////////////////////////////////////END GO//////////////////////////////////////
	print("</td></tr></table></div>");
}
//////////////////////////////////End of control panel///////////////////////////////////




//////Start of updating function/////////
if($admin=='update' && $a_u==$admin_username && $a_p==$admin_password){
$confdat = "<?\n";
$j=1;$mcerror=0;$chkoca=0;
	foreach ($confs as $dat){
		$dat = str_replace("\n","<br>",$dat);
		$dat=str_replace(" ","_",$dat);
		$gerror=0;
		if($j==1) {

			$chuso=ord($dat{0});
			if($chuso>=48 && $chuso<=57) {$mcerror=1;$gerror=1;};
			for($i=0;$i<strlen($dat);$i++){
				$chuso=ord($dat{$i});
				if($chuso>=48 && $chuso<=57) $chkoca++;
			}
			if($chkoca==strlen($dat)) {$mcerror=1;$gerror=1;}

			if($gerror==1) $errorvars=$errorvars .$dat ." , ";	

			$dat=$dat ."|";

		}
		if($j==2) $dat=$dat ."|";
		if($j==3) $dat=$dat ."|\n";
		$j++;
		$confdat = $confdat .$dat;
		if($j>3) $j=1;
	}

	$confdat = $confdat ."?>";
    if($mcerror==1) print("<p align=center>Error variables:<br><br><b>$errorvars</b><br><br><p align=center><font color=red>SYNCTAX ERROR: Variable name is not a number OR not start as a number!<br>
	For example: NOT <font color=black>\$<b><u>12345</u></b></font> or NOT <font color=black>\$<b><u>4</u></b>abcd</font></font></p>
	<p align=center><a href=\"javascript:history.back();\">Click here</a> to go back and fix it.</p>");

    else{
	if($version!='demo'){	
		$fp=fopen($configdatafile,"w"); 
		fwrite($fp,"$confdat"); 
		fclose($fp); 
	}
	print("<p align=center><b>Your config file has been Updated</b></p>
	<p align=center>Please wait....... to tranfering or back to <a 	href=\"$PHP_SELF?admin=login&a_u=$a_u&a_p=$a_p\">Control Panel</a>
	<script>run('$PHP_SELF?admin=login&a_u=$a_u&a_p=$a_p');</script>");
    }
}
//////End of updating function/////////


if($admin=='addnew' && $a_u==$admin_username && $a_p==$admin_password){
$conf1=str_replace(" ","_",$conf1);
$conf2=str_replace(" ","_",$conf2);
$conf3=str_replace(" ","_",$conf3);

	$mcerror=0;$chkoac=0;
		$chuso=ord($conf1{0});
		if($chuso>=48 && $chuso<=57) $mcerror=1;
		for($i=0;$i<strlen($conf1);$i++){
			$chuso=ord($conf1{$i});
			if($chuso>=48 && $chuso<=57) $chkoca++;
		}
		if($chkoca==strlen($conf1)) $mcerror=1;

    if($mcerror==1) print("<p align=center>Error variables:<br><br><b>$conf1</b><br><br><p align=center><font color=red>SYNCTAX ERROR: Variable name is not a number OR not start as a number!<br>
	For example: NOT <font color=black>\$<b><u>12345</u></b></font> or NOT <font color=black>\$<b><u>4</u></b>abcd</font></font></p>
	<p align=center><a href=\"javascript:history.back();\">Click here</a> to go back and fix it.</p>");

    else{
    for($i=1;$i<$total;$i++){
        if($file[$i] == "?>"){ 
            $xaucu="?>";
            $xaumoi="$conf1|$conf2|$conf3|\n?>"; 
	
            $fp = fopen($configdatafile, "r");  
            $data = fread($fp, filesize($configdatafile));  
            fclose($fp);  
            $newdata = str_replace($xaucu, $xaumoi, $data);  
            $fp = fopen($configdatafile,"w");  
            fwrite($fp,$newdata) or die ("error writing"); 
            fclose($fp); 
            $succ = "1"; 

	print("<p align=center><b>Your new Variable has been added</b></p>
	<p align=center>Please wait....... to tranfering or back to <a href=\"$PHP_SELF?admin=login&a_u=$a_u&a_p=$a_p\">Control Panel</a>
	<script>run('$PHP_SELF?admin=login&a_u=$a_u&a_p=$a_p&go=add');</script>");
        } 
    } 
    }
}


if($admin=='del' && $a_u==$admin_username && $a_p==$admin_password && $string){
print("<p align=center><i>Deleting item...........</i></p><p><br></p>");
$string=str_replace(" ","_",$string);
    for($i=1;$i<$total-1;$i++){
        if($string ."\n" == $file[$i]){ 
            $xaucu="$string\n"; 
            $xaumoi=""; 
	
            $fp = fopen($configdatafile, "r");  
            $data = fread($fp, filesize($configdatafile));  
            fclose($fp);  
            $newdata = str_replace($xaucu, $xaumoi, $data);  
            $fp = fopen($configdatafile,"w");  
            fwrite($fp,$newdata) or die ("error writing"); 
            fclose($fp); 
            $succ = "1"; 

		print("<p align=center><b>Variable deleted</b></p>
		<p align=center>Please wait....... to tranfering or back to <a href=\"$PHP_SELF?admin=login&a_u=$a_u&a_p=$a_p\">Control Panel</a>
		<script>run('$PHP_SELF?admin=login&a_u=$a_u&a_p=$a_p');</script>");
        } 
    } 
}


if($admin)
	print("<p></font><font face=Verdana size=1><center>Powered by <a target=\"_blank\" href=\"http://obiewebsite.sourceforge.net\"><b>Obie Config Admin</b></a> (OCA) version $version
	<br>The Visual configuration variables for any your PHP scripts</p></center></font>");
?>
