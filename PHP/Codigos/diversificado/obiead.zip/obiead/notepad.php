<link rel="stylesheet" href="inc/css.css">
<script src="inc/modules.js"></script>
<body bgcolor="#F0F0F0" style="border:0" scroll="no">
<?
//////////////////////////////////////////////////////////
//			--obieAD--			//
//							//
//		-The AD banner management-		//
//		-Version 1.0 created on Dec/02-		//
//							//
//	Writen by Minh Nguyen Duong @ obie.		//
//	All right reserved - http://obiewebsite.sourceforge.net	//
//							//
//	obiePAD included				//
//							//
//	This Software is FREE and can be modified 	//
//	and redistributed under the condition that 	//
//	the copyright and information above stays 	//
//	intact and with the script.			//
//							//
//	If you redistribute obieAD, please link back	//
//	to http://obiewebsite.sourceforge.net			//
//////////////////////////////////////////////////////////
include "config.php";

if (!$file2edit || $file2edit==1) {
	$configfile = 'config.php';
	$kieu = 'button';
}

if ($file2edit==2) {
	$configfile = $termcontent;
	$kieu = 'hidden';
}
else if ($file2edit==3){
	$configfile = 'index.php';
	$kieu = 'hidden';
}

//Print header
print("<title>$configfile - obiePAD(R) </title>");
print("<h3>obiePAD - Editing <font color=navy>$configfile</font><br><br>");
if (!$file2edit || $file2edit==1) print("<font size=1><u>Note</u> : You must keep the <u>format</u> of config.php file.<br>You may change only the value of variables that starts with \"\$\" charactor. Eg: \$var1='obie'; ==> \$var1='yahoo';</font><br><font size=1><u>Note 2</u>: If you have just change the username and/or the password, you must click \"Refresh\" button and login again</font></h3>");
else print("<font size=1><a href=\"$configfile\" target=\"_blank\">PREVIEW</a> of <font color=navy>$configfile</font> file</h3>");

Function output($thisFile) {
	$fd = fopen( $thisFile, "r" );
	$contents = fread( $fd, filesize( $thisFile ) );
	fclose($fd);
	$myContents1 = str_replace("<","<",$contents);
	$myContents = str_replace(">",">",$myContents1);
	print $myContents;      
}
if ($a_u==$admin_username && $a_p == $admin_password){

	print("<form action=$PHP_SELF?file2edit=$file2edit&a_u=$a_u&a_p=$a_p&action=saveconfig method=post>");
	print("<Textarea name=\"conf\" cols=80 rows=20 wrap=off style=\"width:100%;height:70%;font-family: Fixedsys; color: #000000; background-color: white;\">");
	
	output("$configfile");
	
	print("</Textarea>");
	//PRINT HTMLAREA SCRIPTING
	print("$scr");
	print("<input type=\"submit\" value=\"Save changes\" style=\"background-color:#DFDFDF;\"> <input type=\"reset\" value=\"Reset\"> <input type=\"button\" value=\"Refresh\" onclick=\"location.href='$PHP_SELF?file2edit=$file2edit&a_u=$a_u&a_p=$a_p';\">  <input type=\"$kieu\" value=\"Restore default\" onclick=\"checkrestore();\">  <input type=\"button\" value=\"   Exit  \" onclick=\"checkexit();\">
	 File : <select name=\"opt\" onchange=\"document.all.conf.value='Loading file, please wait....';location.href='$PHP_SELF?file2edit=' + document.all.opt.value + '&a_u=$a_u&a_p=$a_p';\"><option value=0>----browse file----</option><option value=1>config.php</option><option value=2>term.htm</option><option value=3>index.php</option></select></form>");


if ($action=='saveconfig'){
	if($obieADversion=='demo'){
		print("<font color=red>This function was disabled in Demo version</font>");
	}
	else{
		$fp = fopen ("$configfile", "w+");
		$conf = str_replace("\'","'",$conf);
		$conf = str_replace('\"','"',$conf);	
		//$conf = str_replace("\\'","\'",$conf);
		fwrite ($fp, $conf);
		fclose ($fp);
		print("<b>$configfile</b> has been saved<br>Please press the \"Refresh\" button to show new content</p>");
	}
}

if ($action=='restore'){
	if($obieADversion=='demo'){
		print("<font color=red>This function was disabled in Demo version</font>");
	}
	else{
	copy("inc/config.bak.php",$configfile);
	print("<b>config.php</b> has been restored<br>You must edit config.php <b>again</b> to continue using your obieAD</p>");
	}
}


}
else {
print("<font color=red>ERROR:</font> Wrong password<h3>Admin login<br></h3>
<form action=\"$PHP_SELF\" method=\"GET\">
Username <input type=text name=\"a_u\" size=20><br>
Password <input type=password name=\"a_p\" size=20><br>
<input type=submit value=\"Login\">
</form>
<body onload=\"document.all.a_u.focus();\">");
}
?>
<script>
function checkexit(){
   clear = confirm("Did you save your changes of config.php\n\nAre you sure to exit",'');
   if(clear) {
   window.close();

  } else {}
 }
function checkrestore(){
   clear2 = confirm("Your current config.php file will be DELETED and REPLACED by our default config.php file\n\n\nAre you SURE to continue",'');
   if(clear2) {
   location.href='<?$PHP_SELF;?>?<? print("file2edit=$file2edit&a_u=$a_u&a_p=$a_p"); ?>&action=restore';

  } else {}
 }
/*
function checksave(){
	req = ['a','b'];
	n=2;
	check=0;
	for (i=0;i<=n-1,$i++){
		if(document.all.conf.value.indexOf(req[i]) != -1) {check=1;}
	}
	if (check==1){alert('OK');}
	else if (check==0){alert('No');}
	else {alert('Error');}
}
*/
</script>
