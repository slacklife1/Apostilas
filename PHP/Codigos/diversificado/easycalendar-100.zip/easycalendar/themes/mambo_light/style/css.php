<?
/*      ******************************************************************
        **********************  EasyCalendar  ************************
	******************************************** software.stoitsov.com  */
// CSS Style - Edit to fit your site design

echo "<style type=\"text/css\">


/************** .feature styles ***************/
.feature{padding: 0px 0px 10px 10px;font-size: 80%;}
.feature h3{padding: 30px 0px 5px 0px;text-align: center;}
.feature img{float: left;padding: 10px 10px 0px 0px;}

/************** .story styles *****************/
.story{clear: both;padding: 10px 0px 0px 10px;font-size: 80%;}
.story p{padding: 0px 0px 10px 0px;}
#content{float: left;width: 55%;}
h3{font-family: Arial,sans-serif;font-size: 100%;color: #334d55;margin: 0px;padding: 0px;}





/* DEFAULTS */
// BODY {font-size: 12px ; font-family: 'Trebuchet MS', Arial, Helvetica, sans-serif; color:#000000; margin: 0px 0px 0px 0px; padding: 0px 0px 0px 0px;background-color: $BGLEFT0; scrollbar-DarkShadow-Color:$FDC; scrollbar-Track-Color:$FDC; scrollbar-Face-Color:$FDC; scrollbar-Shadow-Color:$FBG; scrollbar-Highlight-Color:$FBG; scrollbar-3dLight-Color:$FDC; scrollbar-Arrow-Color:$FBG;}
BODY {font-size: 12px ; font-family: Arial, Helvetica, sans-serif; color:#000000; margin: 0px 0px 0px 0px; padding: 0px 0px 0px 0px;background-color: $BGLEFT0; scrollbar-DarkShadow-Color:$FDC; scrollbar-Track-Color:$FDC; scrollbar-Face-Color:$FDC; scrollbar-Shadow-Color:$FBG; scrollbar-Highlight-Color:$FBG; scrollbar-3dLight-Color:$FDC; scrollbar-Arrow-Color:$FBG;}
td,tr,p,div {font-family: 'Trebuchet MS', Arial, Helvetica, sans-serif;font-size: 11px;color: #333333;}
h4 {color: #333333; font-family: 'Trebuchet MS', Arial, Helvetica, sans-serif;font-size: 16px; font-weight: bold;}
h5 {color: #333333; font-family: 'Trebuchet MS', Arial, Helvetica, sans-serif;font-size: 14px; font-weight: bold;}
h6 {color: #333333; font-family: 'Trebuchet MS', Arial, Helvetica, sans-serif;font-size: 12px; font-weight: bold;}
table.main_tbl {border: 1px dotted; color:$EPS;}
p           {font-size:  12px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif;}
p.news      {font-size:  12px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; margin-top:5; margin-bottom:5;}
td          {font-size:  12px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; color: black;}
.f_text     {font-size:  11px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; color:$FDC;  background-color: $FBG; border: 1px dotted $EPS;}
.info_panel {font-size:  11px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; color:$FDC;  background-color: $FLC; border: 1px dotted $EPS;}
.f_button   {font-size:  11px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; color:white; background-color: $EPS;  border: 1px solid black;}
.strong     {font-size:  12px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; color:$EPS; font-weight:bold;}
.boxheading {font-size:  12px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; font-weight: bold;color: black;}
.h1s        {font-size:  14px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; font-weight:bold; color: $EPS;}
.h1m        {font-size:  14px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; font-weight:bold; color: yellow;}
.h2s        {font-size:  12px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; font-weight:bold; color:$EPS;}
.h3s        {font-size:  12px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; font-weight:bold; color:$EPS;}
.small      {font-size:  10px; font-family:  'Trebuchet MS', 'Trebuchet MS', Arial, Helvetica, sans-serif, sans-serif; color: $EPS; text-decoration: none; font-weight: normal;}

/* LeftBlock*/
.menuL {font-size: 11px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; color: black;}
a:link.menuL, a:visited.menuL {font-size: 11px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; color: #023a59; text-decoration:none; font-style:normal;}
a:hover.menuL {font-size: 11px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; color: white; text-decoration:none; font-style:normal;}
a:link.invert, a:visited.invert {font-size: 11px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; color: #023a59; text-decoration:none; font-style:normal;}
a:hover.invert {font-size: 11px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; color: white; text-decoration:none; font-style:normal;}

/* RightBlock*/
.menuR {font-size: 11px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; color: black;}
a:link.menuR, a:visited.menuR {font-size: 11px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; color: #023a59; text-decoration:none; font-style:normal;}
a:hover.menuR {font-size: 11px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; color: white; text-decoration:none; font-style:normal;}

/* Classifields */
a:link.normalc, a:visited.normalc {font: 16px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; color: $EPS; text-decoration: none; font-weight:bold; font-style:normal;}
a:hover.normalc {font-size: 16px; font-family:  Arial; color: red; text-decoration:  none; font-weight:bold; font-style:normal;}
a:link.normali, a:visited.normali {font: 11px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; color: $EPS; text-decoration:  none; font-style:italic;}
a:hover.normali {font-size: 11px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; color: red; text-decoration:  none; font-style:italic;}

/* Normal links in  other Esay Applications */
a:link.normal, a:visited.normal {font-size: 11px; font-family:  'Trebuchet MS', 'Trebuchet MS', Arial, Helvetica, sans-serif, sans-serif; color: $EPS; text-decoration:none; text-align:left; font-style:normal;}
a:hover.normal {font-size: 11px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; color: red; text-decoration:none; text-align:left; font-style:normal;}

/* Default links  */
a:link, a:visited {font-size: 11px; font-family:  'Trebuchet MS', Arial, Helvetica, sans-serif; color: $EPS; text-decoration: none; }
a:hover {color: #FF6600; text-decoration: none;}

/* Horizontal Line */
hr {background: #C0C0C0; height:2px; border: 1px inset;}
hr.separator {background: #C0C0C0;height: 1px;width: 75px;border: 0px;}


</style>";

?>
