<?
// Timer class
if(!defined('_PHP_TIMER_INCLUDED')) {define('_PHP_TIMER_INCLUDED',1);} class phpTimer {function phpTimer (){ $this->_version = '0.1';$this->_enabled = true;}function start ($name = 'default'){ if($this->_enabled){ $this->_timing_start_times[$name] = explode(' ', microtime());}}function stop ($name = 'default'){ if($this->_enabled){ $this->_timing_stop_times[$name] = explode(' ', microtime());}}function get_current ($name = 'default'){ if($this->_enabled){ if (!isset($this->_timing_start_times[$name])){ return 0;}if (!isset($this->_timing_stop_times[$name])){ $stop_time = explode(' ', microtime());}else{ $stop_time = $this->_timing_stop_times[$name];}$current = $stop_time[1] - $this->_timing_start_times[$name][1];$current += $stop_time[0] - $this->_timing_start_times[$name][0];return sprintf("%.10f",$current);}else{ return 0;}}}
$timer =& new phpTimer(); $timer->start('main');

$version="2.5";

// Theme colors
$EPS=$Easy[$PageSection];
$BGLEFT="#023a51d";
$BGLEFT1="#D0A07E";
$BGLEFT0="#5A0000"; //"#2a4a69";
$BGLEFT2="#fef48f";
$BGTEXT="#dcdcce";
$BGRIGHT1="#9dcba8";
$BGRIGHT2="#738qad";

$theme_path=$edp_relative_path."themes/".$ThemeName;

//spacer function
function Tr($width=1,$height=1) {global $theme_path; return "<img src='".$theme_path."/images/tr.gif' width='$width' height='$height' alt='' border='0'>";}

// header
echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<html><head><title>$sitetitle</title>
<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; $sitecharset\">
<META NAME=\"description\" CONTENT=\" $sitecontent \">
<META NAME=\"author\" CONTENT=\" $siteauthor \"> ";

include_once $theme_path."/style/css.php";

echo "<script language='JavaScript'>function YesNo(fURL,fMessage) { if (confirm(fMessage)) { self.top.location.href=fURL; } }</script>";
echo "</head><body>";

echo "<table width='775' border='0' align='left' cellpadding='0' cellspacing='0'>
      <tr><td colspan='".(Count($RightBlockArray)>0 ? "3" : "2")."' >
           <table width='775' border='0' align='left' cellpadding='0' cellspacing='0' >
             <tr><td width='100%' rowspan='3' valign='bottom' bgcolor=$BGLEFT0>
                <img src='".$theme_path."/images/logo.png' width='775' height='95'><br>
                </td>
             </tr>
           </table>
          </td>
      </tr>";

// left td starts
echo "<tr><td width='64' valign='top' bgcolor=$BGLEFT0>";
// left navigator start (always)
echo "<br>
        <table width='150' border='0' cellspacing='0' cellpadding='0'>
        <tr> <td background=$theme_path/images/bkg.gif width='150' height='5'></td>
        </tr>
        <tr><td valign='top'  bgcolor=$BGLEFT1 width='150' height='27'><br><b>&nbsp;Navigation</b><br>
             <table width='95%' border='0' align='center' cellpadding='0' cellspacing='0'>";
              for ($i=0; $i<$FREEMAX; $i++) { if($i==$PageSection){ $j=$i;
                         echo "<tr><td valign=top align=left  background='".$theme_path."/images/bkg.gif'>&nbsp;</td><td  nowrap><a href='".$edp_relative_path.$FREED[$i]."/index.php?PageSection=".$i."' class=menuL nowrap>&nbsp;&nbsp;&nbsp;&nbsp;".str_replace("_"," ",str_replace("edp_","",$FREET[$i]))."</a></td></tr>";
                } else { echo "<tr><td  valign=top align=left bgcolor='".$Easy[$i]."'>&nbsp;</td><td  nowrap><a href='".$edp_relative_path.$FREED[$i]."/index.php?PageSection=".$i."' class=menuL>&nbsp;&nbsp;&nbsp;&nbsp;".str_replace("_"," ",str_replace("edp_","",$FREET[$i]))."</a></td></tr>"; } }

echo "       </table>
           <br></td>
        </tr>
        <tr> <td background=$theme_path/images/bkg.gif width='150' height='5'></td>
</tr>
      </table>";
// left navigator end

//  left block main menu start (if exists)
$DimLB=Count($LeftBlockArray);
if($DimLB>0){
echo "<br>
    <table width='150' border='0' cellspacing='0' cellpadding='0'>
        <tr> <td background=$theme_path/images/bkg.gif width='150' height='5'></td></tr>
        <tr>
          <td valign='top' bgcolor=$BGLEFT1 width='150' height='27'>
            <table width='95%' border='0' align='center' cellpadding='0' cellspacing='0'>
              <tr><td>&nbsp</td><td><br>
                  $LeftBlockArray[0]
                </td>
              </tr>
            </table></td>
        </tr>
        <tr> <td background=$theme_path/images/bkg.gif width='150' height='5'></td></tr>
       </table>";
}
//  left block main menu end (if exists)

// left login start (always)

echo "<br>
        <table width='150' border='0' cellspacing='0' cellpadding='0'>
        <tr> <td background=$theme_path/images/bkg.gif width='150' height='5'></td></tr>
        <tr><td valign='top' bgcolor=$BGLEFT2 width='150' height='27'><br><b>&nbsp;$Login</b><br>
             <table width='95%' border='0' align='center' cellpadding='0' cellspacing='0'>
               ".($Adminmenu!="" ? "<tr><td valign=top align=left><br>&nbsp;</td><td  valign=top align=left nowrap>$Adminmenu<br><br></td></tr>" : "")."
               <tr><td valign=top align=left>&nbsp;</td><td  valign=top align=left nowrap>".$user."<br><br></td></tr>
             </table>
           </td>
        <tr> <td background=$theme_path/images/bkg.gif width='150' height='5'></td></tr>
      </table>";
// left login end

//  left other blocks menus start (if exist)
if($DimLB>1){
echo "<br><table width='150' border='0' cellspacing='0' cellpadding='0'>
        <tr> <td background=$theme_path/images/bkg.gif width='150' height='5'></td></tr>
          <tr><td valign='top' bgcolor=$BGLEFT1 width='150' height='27'><br>
                 <table width='95%' border='0' align='center' cellpadding='0' cellspacing='0'>
                  <tr><td valign=top align=left>&nbsp;</td> <td>";
                       for ($i=1; $i<count($LeftBlockArray); $i++){ echo $LeftBlockArray[$i]; }
echo "                </td>
                  </tr>
                 </table>
              </td>
          </tr>
          <tr> <td background=$theme_path/images/bkg.gif width='150' height='5'></td></tr>
          <tr><td bgcolor=$BGLEFT0 width='150' height='27'> </td></tr>
          </table>";
}
//  left other blocks menus end (if exist)
echo "</td>"; // left td ends


// center text starts
   $DimRB=Count($RightBlockArray);
   echo "<td width='".($DimRB > 0 ? "447 " : "625")."' rowspan='2' valign='top' bgcolor='#f0f0f0'>";
            if($DimRB > 0) {echo "<br>"; } else { echo "<div align='right' class='small'><font color=$EPS><b>$FREET[$PageSection]&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div><div>".TR(1,4)."</div>";}
      echo "<table width='96%' border='0' align='center' cellpadding='0' cellspacing='0'>
             <tr><td><table width='100%' border='0' cellspacing='0' cellpadding='0'>
                     <tr> <td width='5%'   bgcolor=$BGTEXT  width='23' height='23'> </td>
                     <td width='93%' bgcolor='$BGTEXT'>&nbsp;</td>
                     <td width='2%' bgcolor=$BGTEXT  width='23' height='23'> </td>
                    </tr></table>
                </td>
             </tr>
             <tr><td bgcolor='$BGTEXT'> <table align='center' width='95%' border='0' cellspacing='0' cellpadding='0'><tr><td valign=top>$ResultHtml</td></tr></table></td></tr>
             <tr><td><table width='100%' border='0' cellspacing='0' cellpadding='0'><tr><td width='5%'   width='23' height='23'> </td><td width='93%' >&nbsp;</td><td width='2%'   width='23' height='23'> </td></tr></table></td></tr>
            </table>
         </td>";
// center text ends (large if no RB or small if RB is presented

//  RightBlocks start (if exists)
if($DimRB>0){
 echo "<td width='164' rowspan='2' valign='top' bgcolor='#f0f0f0'><div align='right' class='small'><font color=$EPS><b>$FREET[$PageSection]&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div><div>".TR(1,4)."</div>";

// zero RightBlock start (if Exists)
if($RightBlockArray[0]!=""){
 echo "<table width='164' border='0' cellspacing='0' cellpadding='0'>
        <tr> <td background=$theme_path/images/bkg.gif width='164' height='5'> </td></tr>
        <tr>
          <td valign='top'  bgcolor=$BGRIGHT1 >
            <table width='100%' border='0' cellspacing='0' cellpadding='0'>
              <tr><td width='6%'  bgcolor=$BGRIGHT1 >&nbsp;</td> <td width='93%'  bgcolor=$BGRIGHT1><br>$RightBlockArray[0]</td></tr>
            </table>
          </td>
        </tr>
        <tr> <td background=$theme_path/images/bkg.gif width='164' height='5'> </td></tr>
        <tr> <td color=white width='164' height='12'> </td></tr>
       </table>";
}
// zero RightBlock end

//  other right blocks start (if exist)
if($DimRB>1){
  echo "<table width='164' border='0' cellspacing='0' cellpadding='0'>
        <tr> <td background=$theme_path/images/bkg.gif width='164' height='5'> </td></tr>
          <tr >
          <td valign='top'  bgcolor=$BGRIGHT2>
             <table width='100%' border='0' cellspacing='0' cellpadding='0'>
              <tr> <td width='6%'  bgcolor=$BGRIGHT2>&nbsp;</td> <td width='94%'  bgcolor=$BGRIGHT2><br>";
                 for ($i=1; $i<Count($RightBlockArray); $i++){ echo $RightBlockArray[$i];}
             echo" </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr> <td background=$theme_path/images/bkg.gif width='164' height='5'> </td></tr>
      </table><br><br>";
}
//  other right blocks end
echo "</td></tr>";
}
//  RightBlocks end (if exists)


// bottom
 echo " <tr><td valign='bottom'   bgcolor=$BGLEFT0  width='164' height='35'> </td> </tr>
        <tr><td colspan='3' valign='bottom' bgcolor='$BGLEFT0'><br><br>
        <table width='775' border='0' align='left' cellpadding='6' cellspacing='0'>
        <tr><td align='center' bgcolor=white>";
// footer start
echo " <a href='http://software.stoitsov.com' class=normal><b>EasyCalendar 2003</b><br>
       <img src='".$theme_path."/images/bottom_logo.png' width='206' height='31' alt='software.stoitsov.com' border='0'></a><br>";
$timer->stop('main');
echo "<span class=\"small\">&nbsp;Page created in ".($timer->get_current('main'))." sec</span><br><br>";


// vote hotscripts start
echo  "<table width=100%>
       <tr><td background='".$theme_path."/images/bkg.gif' height='14' width=100% colspan=3></td></tr>
       <tr><td background='".$theme_path."/images/bkg.gif' height='1' width=100% colspan=0></td>
           <td width='100%' align=left bgcolor=white valign=middle  nowrap >
            <font color='".$EPS."'><b>&nbsp;&nbsp;&nbsp;If you like the script, please vote for it.&nbsp;<br>&nbsp;&nbsp;&nbsp;We do appreciate this much.&nbsp;</font>
           </td>
           <td width='100%' align=center valign=middle  nowrap background='".$theme_path."/images/bkg.gif'>
            <form action='http://www.hotscripts.com/cgi-bin/rate.cgi' method='POST' target='_new'>
            <input type=hidden name='ID' value='25604'>
            &nbsp;&nbsp;&nbsp;&nbsp;<a href='http://www.hotscripts.com/Detailed/25604.html' target='_new'><b>HotScripts.com</b></a> :<br>
            <select name='rate' size='1' style='font-size:10px;'>
            <option selected value='5'>Excellent!</option>
            <option value='4'>Very Good</option>
            <option value='3'>Good</option>
            <option value='2'>Fair</option>
            <option value='1'>Poor</option>
            </select>&nbsp;<input type='submit' value='Rate It!' style='font-size:10px;'></form>
           </td>
       </tr>
       <tr><td background='".$theme_path."/images/bkg.gif' height='14' width=100% colspan=3 style='padding: 15px;'></td></tr>
       </table>";
// vote hotscripts end
// footer end
echo "         </td>
           </tr>
          </table>
         </td>
       </tr>
</table>

</body> </html>";

?>
