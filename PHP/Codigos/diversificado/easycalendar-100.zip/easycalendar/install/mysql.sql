# phpMyAdmin SQL Dump
# version 2.5.4
# http://www.phpmyadmin.net
#
# Host: localhost
# Generation Time: Dec 29, 2003 at 04:20 PM
# Server version: 3.23.54
# PHP Version: 4.3.0
#
# Database : `easycalendar`
#

# --------------------------------------------------------

#
# Table structure for table `edp_Notes`
#

DROP TABLE IF EXISTS `edp_Notes`;
CREATE TABLE `edp_Notes` (
  `ID` bigint(20) NOT NULL auto_increment,
  `puHeading` varchar(255) NOT NULL default '',
  `puBody` text NOT NULL,
  `puDate` date NOT NULL default '0000-00-00',
  `puUserID` bigint(20) NOT NULL default '0',
  `puTopic` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`ID`),
  KEY `ID` (`ID`),
  KEY `puDate` (`puDate`),
  KEY `puUserID` (`puUserID`)
) TYPE=MyISAM AUTO_INCREMENT=8 ;

#
# Dumping data for table `edp_Notes`
#

INSERT INTO `edp_Notes` (`ID`, `puHeading`, `puBody`, `puDate`, `puUserID`, `puTopic`) VALUES (4, 'Year/Month/Week/Today Views', '[p]The navigation is simple. You have month, year view from which you can choose your desire year, month and day to view. The today link returns you to the current month.[/p]\r\n\r\n[p]When in month view you see all events for the particular month as well as the events for the particular day of course if there such events.[/p]\r\n\r\n[p]The left column of the month field shows the week of the year. If you use this link you are entering in the week view mode where all the events of the particual week are listed.[/p]', '2003-12-28', 1, 'edp_Notes'),
(5, 'Add/Edit/Delete Notes and Events', '[p]Registered user view all publick as well as his private events but he can dellete/edit only his own notes and events. Administrator can do everithing.[/p]\r\n\r\n[p]To add new even you should be loged on as registered user or administrator and to use the lower right triangle icon of the particular day [/p]\r\n\r\n[p]For existing notes or events you can use edit/delete links to modify or delete the events.[/p]', '2003-12-28', 1, 'edp_Notes'),
(6, 'Add/Manage Users', '[p][b]EasyCalendar[/b] has two level users:[br] \r\n �- registered user who can add notes and events, view modify and delete his notes and events already posted;[br]\r\n �- administrator who can see/edit/delete all notes and events, modify site configuration and manage the users.[/p]\r\n[p]Registered users can register using the admin link.[/p]', '2003-12-28', 1, 'edp_Notes'),
(7, 'CONGRATULATIONS', '[p]You have [color=blue]EasyCalendar[/color] up and running.[/p]\r\n[p]After the instalation your username and password are set to [color=blue]demo[/color],[color=blue]demo[/color]. [br]You should change them as soon as possible.[/p]\r\n[p]ENJOY!!! [/p]', '2003-12-28', 1, 'edp_Notes');

# --------------------------------------------------------

#
# Table structure for table `edp_calendar`
#

DROP TABLE IF EXISTS `edp_calendar`;
CREATE TABLE `edp_calendar` (
  `IID` mediumint(5) unsigned NOT NULL auto_increment,
  `uid` tinyint(3) unsigned NOT NULL default '0',
  `m` tinyint(2) NOT NULL default '0',
  `d` tinyint(2) NOT NULL default '0',
  `y` smallint(4) NOT NULL default '0',
  `start_time` time NOT NULL default '00:00:00',
  `end_time` time NOT NULL default '00:00:00',
  `title` varchar(50) NOT NULL default '',
  `text` text NOT NULL,
  `pub` int(11) NOT NULL default '0',
  PRIMARY KEY  (`IID`),
  KEY `id` (`IID`),
  KEY `m` (`m`),
  KEY `y` (`y`),
  KEY `uid` (`uid`)
) TYPE=MyISAM AUTO_INCREMENT=6 ;

#
# Dumping data for table `edp_calendar`
#

INSERT INTO `edp_calendar` (`IID`, `uid`, `m`, `d`, `y`, `start_time`, `end_time`, `title`, `text`, `pub`) VALUES (1, 1, 1, 1, 2004, '00:00:00', '00:00:00', 'Happy New Year', 'Happy New Year to all registered users.', 0),
(2, 1, 1, 1, 2004, '14:00:00', '15:00:00', 'Arc tangent-atan', 'Returns the arc tangent of arg in radians.', 0),
(3, 1, 1, 16, 2004, '00:00:00', '00:00:00', 'What is PHP?', 'Widely-used Open Source general-purpose scripting language that is especially suited for Web development and can be embedded into HTML.', 0),
(4, 1, 1, 16, 2004, '00:00:00', '00:00:00', 'What can PHP do?', 'Server-side scripting, comand-line scripting, writing client-side GUI applications.', 0),
(5, 1, 12, 29, 2003, '00:00:00', '00:00:00', 'First day of the EasyCalendar', 'Happy New Year with the new tool!', 0);

# --------------------------------------------------------

#
# Table structure for table `edp_config`
#

DROP TABLE IF EXISTS `edp_config`;
CREATE TABLE `edp_config` (
  `ID` bigint(10) NOT NULL default '0',
  `sitetitle` varchar(200) NOT NULL default '',
  `sitecharset` varchar(200) NOT NULL default '',
  `sitecontent` varchar(200) NOT NULL default '',
  `siteauthor` varchar(200) NOT NULL default '',
  `pagesectionhome` varchar(200) NOT NULL default '',
  `themename` varchar(200) NOT NULL default '',
  `abackground` varchar(200) NOT NULL default '',
  `adarkcolor` varchar(200) NOT NULL default '',
  `agraycolor` varchar(200) NOT NULL default '',
  `alightcolor` varchar(200) NOT NULL default '',
  `ebackground` varchar(200) NOT NULL default '',
  `elightcolor1` varchar(200) NOT NULL default '',
  `eightcolor2` varchar(200) NOT NULL default '',
  `earticles` varchar(200) NOT NULL default '',
  `econtact` varchar(200) NOT NULL default '',
  `enews_per_page` varchar(200) NOT NULL default '',
  `ehead_per_page` varchar(200) NOT NULL default '',
  `etable_width` varchar(200) NOT NULL default '',
  `elinks_per_page` varchar(200) NOT NULL default '',
  `enew_days` varchar(200) NOT NULL default '',
  `epage_width` varchar(200) NOT NULL default '',
  `egd_version` varchar(200) NOT NULL default '',
  `epics_per_page` varchar(200) NOT NULL default '',
  `edemo_mode` varchar(200) NOT NULL default '',
  `emedia_folder` varchar(200) NOT NULL default '',
  `ecats_per_page` varchar(200) NOT NULL default '',
  `eupload_fields` varchar(200) NOT NULL default '',
  `eupload_resizex` varchar(200) NOT NULL default '',
  `eupload_resizey` varchar(200) NOT NULL default '',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM;

#
# Dumping data for table `edp_config`
#

INSERT INTO `edp_config` (`ID`, `sitetitle`, `sitecharset`, `sitecontent`, `siteauthor`, `pagesectionhome`, `themename`, `abackground`, `adarkcolor`, `agraycolor`, `alightcolor`, `ebackground`, `elightcolor1`, `eightcolor2`, `earticles`, `econtact`, `enews_per_page`, `ehead_per_page`, `etable_width`, `elinks_per_page`, `enew_days`, `epage_width`, `egd_version`, `epics_per_page`, `edemo_mode`, `emedia_folder`, `ecats_per_page`, `eupload_fields`, `eupload_resizex`, `eupload_resizey`) VALUES (0, '.: Free Software - Stoitsov.com :.', 'charset=windows-1251', 'Free PHP Software - http://software.stoitsov.com', 'Mario Stoitsov, Cyber/SAS', '0', 'mambo', '#FFFFFF', '#000000', 'Gray', '#F0F0F0', '#FFFFFF', '#FFF9DD', '#F5F5F5', 'News', 'FALSE', '3', '20', '90%', '20', '7', '771', '2', '10', 'FALSE', 'MediaFolders', '4', '10', '500', '400'),
(1, '.: Free Software - Stoitsov.com :.', 'charset=windows-1251', 'Free PHP Software - http://software.stoitsov.com', 'Mario Stoitsov, Cyber/SAS', '0', 'mambo_light', '#FFFFFF', '#000000', 'Gray', '#F0F0F0', '#FFFFFF', '#FFF9DD', '#F5F5F5', 'Notes', 'FALSE', '6', '20', '', '', '', '', '', '', '', '', '', '', '', '');

# --------------------------------------------------------

#
# Table structure for table `edp_pconfig`
#

DROP TABLE IF EXISTS `edp_pconfig`;
CREATE TABLE `edp_pconfig` (
  `ID` bigint(10) NOT NULL auto_increment,
  `dpFREE` varchar(10) NOT NULL default '',
  `dpFREED` varchar(100) NOT NULL default '',
  `dpFREET` varchar(20) NOT NULL default '',
  `dpLBData` varchar(200) NOT NULL default '',
  `dpRBData` varchar(200) NOT NULL default '',
  PRIMARY KEY  (`ID`)
) TYPE=MyISAM AUTO_INCREMENT=1004 ;

#
# Dumping data for table `edp_pconfig`
#

INSERT INTO `edp_pconfig` (`ID`, `dpFREE`, `dpFREED`, `dpFREET`, `dpLBData`, `dpRBData`) VALUES (2, '#5A0000', 'dynamicpages', 'edp_Notes', '', ''),
(1, '#5A0000', 'staticpages/easycalendar', 'edp_Easy_Calendar', '', '');

# --------------------------------------------------------

#
# Table structure for table `edp_pupublish`
#

DROP TABLE IF EXISTS `edp_pupublish`;
CREATE TABLE `edp_pupublish` (
  `ID` bigint(20) NOT NULL auto_increment,
  `puHeading` varchar(255) NOT NULL default '',
  `puBody` text NOT NULL,
  `puDate` date NOT NULL default '0000-00-00',
  `puUserID` bigint(20) NOT NULL default '0',
  `puTopic` varchar(255) NOT NULL default '',
  `puTopicID` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  KEY `ID` (`ID`),
  KEY `puDate` (`puDate`),
  KEY `puUserID` (`puUserID`)
) TYPE=MyISAM AUTO_INCREMENT=29 ;

#
# Dumping data for table `edp_pupublish`
#

INSERT INTO `edp_pupublish` (`ID`, `puHeading`, `puBody`, `puDate`, `puUserID`, `puTopic`, `puTopicID`) VALUES (26, 'Add/Edit/Delete Notes and Events', '[p]Registered user view all publick as well as his private events but he can dellete/edit only his own notes and events. Administrator can do everithing.[/p]\r\n\r\n[p]To add new even you should be loged on as registered user or administrator and to use the lower right triangle icon of the particular day [/p]\r\n\r\n[p]For existing notes or events you can use edit/delete links to modify or delete the events.[/p]', '2003-12-28', 1, 'edp_Notes', 5),
(28, 'Year/Month/Week/Today Views', '[p]The navigation is simple. You have month, year view from which you can choose your desire year, month and day to view. The today link returns you to the current month.[/p]\r\n\r\n[p]When in month view you see all events for the particular month as well as the events for the particular day of course if there such events.[/p]\r\n\r\n[p]The left column of the month field shows the week of the year. If you use this link you are entering in the week view mode where all the events of the particual week are listed.[/p]', '2003-12-28', 1, 'edp_Notes', 4);

# --------------------------------------------------------

#
# Table structure for table `edp_puusers`
#

DROP TABLE IF EXISTS `edp_puusers`;
CREATE TABLE `edp_puusers` (
  `ID` bigint(20) NOT NULL auto_increment,
  `puUsername` varchar(50) NOT NULL default '',
  `puPassword` varchar(50) NOT NULL default '',
  `puScreenName` varchar(200) NOT NULL default '',
  `puMail` varchar(255) NOT NULL default '',
  `puAdmin` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  KEY `ID` (`ID`),
  KEY `puAdmin` (`puAdmin`),
  KEY `puScreenName` (`puScreenName`),
  KEY `puUsername` (`puUsername`)
) TYPE=MyISAM AUTO_INCREMENT=3 ;

#
# Dumping data for table `edp_puusers`
#

INSERT INTO `edp_puusers` (`ID`, `puUsername`, `puPassword`, `puScreenName`, `puMail`, `puAdmin`) VALUES (1, 'demo', 'demo', 'Demo User', 'demo@demo.com', 1),
(2, 'demo1', 'demo1', 'Demo User1', 'demo1@demo1', 0);

# --------------------------------------------------------

#
# Table structure for table `edp_usersonline`
#

DROP TABLE IF EXISTS `edp_usersonline`;
CREATE TABLE `edp_usersonline` (
  `timestamp` int(15) NOT NULL default '0',
  `ip` varchar(40) NOT NULL default '',
  PRIMARY KEY  (`timestamp`),
  KEY `ip` (`ip`)
) TYPE=MyISAM;

#
# Dumping data for table `edp_usersonline`
#

INSERT INTO `edp_usersonline` (`timestamp`, `ip`) VALUES (1072732651, '192.168.0.5'),
(1072732642, '192.168.0.5'),
(1072732639, '192.168.0.5'),
(1072732635, '192.168.0.5'),
(1072732627, '192.168.0.5'),
(1072732631, '192.168.0.5'),
(1072732605, '192.168.0.5'),
(1072732612, '192.168.0.5'),
(1072732614, '192.168.0.5'),
(1072732725, '192.168.0.5'),
(1072732617, '192.168.0.5'),
(1072732619, '192.168.0.5'),
(1072732621, '192.168.0.5'),
(1072732623, '192.168.0.5'),
(1072732646, '192.168.0.5');
