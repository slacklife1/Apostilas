<SCRIPT LANGUAGE="JavaScript">
function sendColor ( color ) { window.opener.document.formFREE.<?php echo $color ?>.value= color; window.close (); }
</SCRIPT>

<?
echo "<body leftmargin='0' rightmargin='0' topmargin='0' rightmargin=0 bgcolor=#000000>";
echo "<CENTER><TABLE BORDER=1 bgcolor=#FFFFFF width=100%><TR>";
$i = 0;
for ( $r = 0; $r < 16; $r += 1 ) {
  for ( $g = 0; $g < 16; $g += 4 ) {
    for ( $b = 0; $b < 16; $b += 4 ) {
      if ( $i == 0 ) {echo "<TR>\n";} else if ( $i % 16 == 0 ) {echo "</TR><TR>\n";}
      $c = sprintf ( "%X0%X0%X0", $r, $g, $b );
      echo "<TD BGCOLOR=\"#".$c."\"><A HREF=\"javascript:sendColor('#".$c."')\" ><IMG SRC=\"../images/spacer.gif\" WIDTH=\"15\" HEIGHT=\"15\" BORDER=\"0\" alt='#".$c."'></A></TD>\n";
      $i++;
    }
  }
}
//$c = "FFFFFF";
//echo "<TD BGCOLOR='#".$c."'><A HREF=\"javascript:sendColor('#".$c."')\"><IMG SRC=\"../images/spacer.gif\" WIDTH=\"15\" HEIGHT=\"15\" BORDER=\"0\"></A></TD>\n";
echo "</TR></TABLE></CENTER></body>\n";
?>


