<?
/*      ******************************************************************
        **********************  EasyCalendar  ************************
        ******************************************** software.stoitsov.com
        ==================== EDIT YOUR SERVER DATA  ======================  */

 // Server data VAIO
 $Easy["mysql_host"]="vaio";           // change to your MySQL Host
 $Easy["mysql_user"]="user";           // change to your MySQL Username
 $Easy["mysql_pass"]="userpass";       // change to your MySQL Password
 $Easy["mysql_base"]="easycalendar";   // Database name, to contain EasyCalendar tables

?>
