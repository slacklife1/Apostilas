<?
  echo $action;
	$ResultHtml="";
  $ResultHtml.=puHeading("User authorization",1). "You need to be registered user in order to add, edit or delete ".$Easy["Articles"].".<br><br><br>
	<div align=center>
   <table border='0' cellspacing='1' cellpadding='2' bgcolor='".$Easy[$PageSection]."' width=200>
    <tr><td colspan=2>&nbsp;<font color=".$Easy["Background"]."><b>.: Login</b></font></td> </tr> ".puElement("form",$EDP_SELF,"Login","POST")."
    <tr><td bgcolor=".$Easy["Background"]." align=right><b>Username:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("text","puUsername",$puUsername,100)."</td> </tr>
    <tr><td bgcolor=".$Easy["Background"]." align=right><b>Password:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("password","puPassword","",100)."</td> </tr>
    <tr> <td colspan=2 align=right>".puElement("submit","Login","f_button")."</td> </tr> ".puElement("hidden","action",$action).puElement("hidden","action","login").puElement()."
  </table><br>". $Error ."</div><br>";

    $ResultHtml.=puHeading("Forgot your Paswword?",1)."Please, contact one of the site Administrators listed below.<br><br>
		<div align=center>
		<table border='0' cellspacing='1' cellpadding='2' width=90%>
       <tr bgcolor='".$Easy[$PageSection]."'> <td colspan=4>&nbsp;<font color=".$Easy["Background"]."><b>.: Site Administrators</b></font></td> </tr>
       <tr bgcolor='".$Easy["LightColor1"]."'>
				<td><b>Screen Name</b></td>
				<td><b>E-mail</b></td>
			</tr>";
    $RegUsers=puMyQuery("SELECT puScreenName, puMail FROM edp_puusers WHERE puAdmin=1 Order by puScreenName");
		$i=0;
    while ($RegUser=mysql_fetch_array($RegUsers)) { $i++;
     if ($i % 2 != 0) { $color=""; } else { $color=" bgcolor='".$Easy["LightColor2"]."'"; }
			$ResultHtml.="
			<tr".$color.">
				<td><b>".$RegUser["puScreenName"]."</b></td>
				<td><a href='mailto:".$RegUser["puMail"]."'>".$RegUser["puMail"]."</a></td>
      </tr> ";
		}
		$ResultHtml.="
      <tr bgcolor='".$Easy[$PageSection]."'><td>".puTr()."<br></td><td>".puTr()."<br></td></tr>
    </table></div><br><hr><br> ";


?>



