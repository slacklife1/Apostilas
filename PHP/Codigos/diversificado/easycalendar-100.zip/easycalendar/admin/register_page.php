<?
	$ResultHtml="";
  if ($do=="reg_user") {
    $ResultHtml.=puHeading("Register New User",1). "Registered users can add, edit or delete ".$Easy["Articles"]." and Calendar events.<br><br><br>
		<div align=center>
      <table border='0' cellspacing='1' cellpadding='2' bgcolor='".$Easy[$PageSection]."' width=350>
      <tr><td colspan=2>&nbsp;<font color=".$Easy["Background"]."><b>.: New user information</b></font></td> </tr> ".puElement("form",$EDP_SELF,"NewUser","POST")."
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>Username:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("text","puUsername","",100)."</td> </tr>
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>Password:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("text","puPassword","",100)."</td> </tr>
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>Screen name:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("text","puScreenName","",200)."</td> </tr>
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>E-mail:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("text","puMail","",200)."</td> </tr>
      ".puElement("hidden","puAdmin",0)."
      <tr> <td colspan=2 align=right>".puElement("submit","Create","f_button")."</td> </tr> ".puElement("hidden","action","reg_user").puElement()."
    </table><br>". $Error ."</div><br><hr><br> ";
  } elseif ($do=="edit_reg_user" && isset($id)) {
    $EditUser=puMyFetch("SELECT * FROM edp_puusers WHERE ID=$id LIMIT 1;");
    $ResultHtml.=puHeading("Edit Registered User",1). "Registered users can add, edit or delete ".$Easy["Articles"]." and Calendar events.<br><br><br>
		<div align=center>
      <table border='0' cellspacing='1' cellpadding='2' bgcolor='".$Easy[$PageSection]."' width=350>
      <tr><td colspan=2>&nbsp;<font color=".$Easy["Background"]."><b>.: User information</b></font></td> </tr> ".puElement("form",$EDP_SELF,"EditUser","POST")."
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>Username:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("text","puUsername",$EditUser["puUsername"],100)."</td> </tr>
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>Password:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("text","puPassword",$EditUser["puPassword"],100)."</td> </tr>
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>Screen name:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("text","puScreenName",$EditUser["puScreenName"],200)."</td> </tr>
      <tr><td bgcolor=".$Easy["Background"]." align=right><b>E-mail:</b></td> <td bgcolor=".$Easy["Background"].">".puElement("text","puMail",$EditUser["puMail"],200)."</td> </tr>
      ".puElement("hidden","puAdmin",0)."
      <tr> <td colspan=2 align=right>".puElement("submit","Change","f_button")."</td> </tr> ".puElement("hidden","action","edit_reg_user").puElement("hidden","puID",$EditUser["ID"]).
      puElement()." </table><br>". $Error ."</div> ";
  } else {
    $ResultHtml.=puHeading("New user registered",1). "Registered users can add, edit or delete ".$Easy["Articles"]." and Calendar events.<br><br><br>
		<div align=center>
		<table border='0' cellspacing='1' cellpadding='2' width=90%>
       <tr bgcolor='".$Easy[$PageSection]."'> <td colspan=5>&nbsp;<font color=".$Easy["Background"]."><b>.: You can change registration details using the link 'Edit'. </b></font></td> </tr>
       <tr bgcolor='".$Easy["LightColor1"]."'>
        <td><b>User Name</b></td>
        <td><b>Password</b></td>
				<td><b>Screen Name</b></td>
				<td><b>E-mail</b></td>
				<td align=center><b>Edit</b></td>
			</tr>";
    $RegUser=mysql_fetch_array(puMyQuery("SELECT * FROM edp_puusers WHERE ID=$puID Order by puScreenName"));
    $color=" bgcolor='".$Easy["LightColor2"]."'";
    $ResultHtml.="
			<tr".$color.">
        <td><b>".$RegUser["puUsername"]."</b></td>
        <td><b>".$RegUser["puPassword"]."</b></td>
				<td><b>".$RegUser["puScreenName"]."</b></td>
				<td><a href='mailto:".$RegUser["puMail"]."'>".$RegUser["puMail"]."</a></td>
        <td align=center><a href='$EDP_SELF&page=register&do=edit_reg_user&id=".$RegUser["ID"]."'>Edit</a></td>
      </tr>
      <tr bgcolor='".$Easy[$PageSection]."'><td>".puTr()."<br></td><td>".puTr()."<br></td><td>".puTr()."<br></td><td>".puTr()."<br></td><td>".puTr()."<br></td></tr>
    </table>".puElement("form",$EDP_SELF,"Login","POST").puElement("hidden","puPassword",$RegUser["puPassword"]).puElement("hidden","puUsername",$RegUser["puUsername"]).puElement("hidden","action","login").puElement("submit","Login","f_button").puElement()."
    </div><br><hr><br> ";
  }
?>
