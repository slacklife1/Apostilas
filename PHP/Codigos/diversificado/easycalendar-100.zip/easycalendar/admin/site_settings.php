<?
/*      ******************************************************************
        **********************  EasyCalendar  ************************
	******************************************** software.stoitsov.com  */

if($op=="ConfigUpdate") TopicUpdates($xpID);
$idid=1; if(isset($def)) {$idid=0;}

$result = mysql_query("SELECT ID, sitetitle, sitecharset, sitecontent, siteauthor, pagesectionhome, themename, earticles, econtact, enews_per_page, ehead_per_page, etable_width, elinks_per_page, enew_days, epage_width, egd_version, epics_per_page, edemo_mode, emedia_folder, ecats_per_page,  eupload_fields, eupload_resizex, eupload_resizey  from edp_config where ID=$idid");
list($xID, $sitetitle, $sitecharset, $sitecontent, $siteauthor, $pagesectionhome, $themename,  $earticles, $econtact, $enews_per_page, $ehead_per_page, $etable_width, $elinks_per_page, $enew_days, $epage_width, $egd_version, $epics_per_page, $edemo_mode, $emedia_folder, $ecats_per_page,  $eupload_fields, $eupload_resizex, $eupload_resizey) = mysql_fetch_row($result);
$Config=mysql_query("SELECT * FROM edp_pconfig ORDER BY ID");
 $toc=-1; while ($Conf=mysql_fetch_array($Config) ) {$toc++;  $dbID[$toc]=$Conf["ID"];
 $dbFREE[$toc]=$Conf["dpFREE"]; $dbFREED[$toc]=$Conf["dpFREED"]; $dbFREET[$toc]=$Conf["dpFREET"];
 $dbLBData[$toc]=$Conf["dpLBData"]; $dbRBData[$toc]=$Conf["dpRBData"];}

$ResultHtml= "<table>
               <tr><td><left><font class='title'><b>SITE CONFIG</b></font></left><br><br><left><font class='option'><b><a href='$EDP_SELF&page=config&do=add_page&du=site&def=1'>Click here to restore the default settin of the site if needed.<br>Then modify and save.</a></b></font></left></td></tr>
               <tr><td><form action='$EDP_SELF&page=config&do=add_page&du=site' method='post'>
                      <table>
                      <tr><td></td><td align=center><font class='option'><b>Heading META tags</b></font><td></td></tr>
                      <tr><td><b>SiteTitle:</b></td><td><input type='text' name='xsitetitle' value='$sitetitle' size='40' maxlength='200'></td><td width=40% align=left> tag</td></tr>
                      <tr><td><b>Charset:</b></td><td><input type='text' name='xsitecharset' value='$sitecharset' size='40' maxlength='200'></td><td> tag</td></tr>
                      <tr><td><b>Content:</b></td><td><input type='text' name='xsitecontent' value='$sitecontent' size='40' maxlength='200'></td><td> tag</td></tr>
                      <tr><td><b>Author:</b></td><td><input type='text' name='xsiteauthor' value='$siteauthor' size='40' maxlength='200'></td><td> tag</td></tr>
                      <tr><td></td><td><br></td><td></td></tr>
                      </table>
                      <table>
                      <tr><td nowrap><b>Page Order:</b></td><td align=left><b>Select the desired page order</b></td><td></td></tr>
                      <tr><td></td><td valign=top>";
                                           $cTable=count($dbID);
                                           for ($i=0; $i < $cTable;  $i++) { $ii=$i+1;
                                           $ResultHtml.="<select name=\"xpID[$i]\">";
                                           for ($j=0; $j < $cTable; $j++) {$jj=$j+1;
                                           $ResultHtml.="<option   value='".$jj."'";
                                           if($dbID[$i]==$dbID[$j]) {$ResultHtml.="selected"; }
                                           $ResultHtml.=">".str_replace("_"," ",str_replace("edp_","",$dbFREET[$j]));}
                                           $ResultHtml.="</select>&nbsp;&nbsp;$i";
                                           if($ii==1) {$ResultHtml.="&nbsp;<b>(home page)</b>"; } $ResultHtml.="<br>";}
                                           $ResultHtml.="
                                           </td><td></td></tr>
                      <tr><td></td><td><br></td><td></td></tr>
                      </table>
                      <table>
                      <tr><td nowrap><b>Theme:</b></td><td><select name='xthemename'>";
                                         $handle=opendir("".$edp_relative_path."/themes");
                                         $themelist=""; while ($file = readdir($handle)) {if ( (!ereg("[ ]",$file)) ) {$themelist .= "$file.";}}
                                         closedir($handle); $themelist = explode(".", $themelist); sort($themelist);
                                         for ($i=0; $i < sizeof($themelist); $i++) {
                                         if($themelist[$i]!="") {$ResultHtml.= "<option name='xthemename' value='$themelist[$i]' ";
                                         if($themelist[$i]==$themename) $ResultHtml.= "selected"; $ResultHtml.= ">$themelist[$i]\n";}}
                                         $ResultHtml.= "</td><td nowrap>Choose the theme from here.</td></tr>
                      <tr><td></td><td><br></td><td></td></tr>
                      </table>
                      <table>
                      <tr><td class=small colspan=2><b>EasyCalendar settings only</b></td></tr>
                      <tr><td  nowrap><b>News Item:</b></td><td><input type='text' name='xearticles' value='$earticles' size='10' maxlength='200'></td><td> Name of the posted items e.g. News, Reviews, Articles, Help etc.</td></tr>
                      <tr><td  nowrap><b>Contact:</b></td><td nowrap>";
                          if ($econtact=="TRUE") {
                          $ResultHtml.= "<input type='radio' name='xecontact' value='TRUE' checked>Yes &nbsp;
                          <input type='radio' name='xecontact' value='FALSE'>No";
                          } else {
                          $ResultHtml.= "<input type='radio' name='xecontact' value='TRUE' >Yes &nbsp;
                          <input type='radio' name='xecontact' value='FALSE'  checked>No";
                         } $ResultHtml.= "</td><td> Show Author's e-mails or not</td></tr>
                     <tr><td  nowrap><b>Vews Per Page:</b></td><td><input type='text' name='xenews_per_page' value='$enews_per_page' size='10' maxlength='200'></td><td>Number of News Items per page</td></tr>
                     <tr><td  nowrap><b>Head Per Page:</b></td><td><input type='text' name='xehead_per_page' value='$ehead_per_page' size='10' maxlength='200'></td><td>Number of Items per page in: Search, Contents & Author`s Pages</td></tr>";

                     $aaa="<tr><td colspan=2 class=small><br><b>EasyBookMarker settings only</b></td></tr>
                     <tr><td><b>Table Width:</b></td><td><input type='text' name='xetable_width' value='$etable_width' size='10' maxlength='200'></td><td>Max Page Width</td></tr>
                     <tr><td><b>Links Per Page:</b></td><td><input type='text' name='xelinks_per_page' value='$elinks_per_page' size='10' maxlength='200'></td><td>Number of links per page</td></tr>

                     <tr><td colspan=2 class=small><br><b>EasyClassifielsd settings only</b></td></tr>
                     <tr><td><b>Link Age:</b></td><td><input type='text' name='xenew_days' value='$enew_days' size='10' maxlength='200'></td><td align=left> Link`s age (in days)</td></tr>

                     <tr><td colspan=2 class=small><br><b>Easy-E-Ccards and Gallery settings</b></td></tr>
                     <tr><td><b>Page Width:</b></td><td><input type='text' name='xepage_width' value='$epage_width' size='10' maxlength='200'></td><td>Max Easy-E-Cards Page Width</td></tr>
                     <tr><td><b>GD Version:</b></td><td>";
                          if ($egd_version==1) {$ResultHtmla.= "<input type='radio' name='xegd_version' value='1' checked>1 &nbsp;<input type='radio' name='xegd_version' value='2'>2";
                          } else {$ResultHtmla.= "<input type='radio' name='xegd_version' value='1' >1 &nbsp;<input type='radio' name='xegd_version' value='2'  checked>2";
                          } $ResultHtmla.= "</td><td>(2 for GD ver. 2 or higher)</td></tr>
                     <tr><td><b>Pics Per Page:</b></td><td><input type='text' name='xepics_per_page' value='$epics_per_page' size='10' maxlength='200'></td><td>Pictures Per Page</td></tr>

                     <tr><td colspan=2 class=small><br><b>EasyGallery settings only</b></td></tr>
                     <tr><td><b><br>Demo Mode:</b></td><td nowrap>";
                          if ($edemo_mode=="TRUE") {$ResultHtmla.= "<input type='radio' name='xedemo_mode' value='TRUE' checked>Yes &nbsp;<input type='radio' name='xedemo_mode' value='FALSE'>No";
                          } else {$ResultHtmla.= "<input type='radio' name='xedemo_mode' value='TRUE' >Yes &nbsp;<input type='radio' name='xedemo_mode' value='FALSE'  checked>No";
                          } $ResultHtmla.= "</td><td> Yes: Download, Delete and Reindex functions disabled</td></tr>
                     <tr><td><b>Media Folder:</b></td><td><input type='text' name='xemedia_folder' value='$emedia_folder' size='10' maxlength='200'></td><td> Name of a CHMODED 777 folder with apache owner and group</td></tr>
                     <tr><td><b>Cats Per Page:</b></td><td><input type='text' name='xecats_per_page' value='$ecats_per_page' size='10' maxlength='200'></td><td> Number of Categories per page</td></tr>
                     <tr><td><b> Upload Fields:</b></td><td><input type='text' name='xeupload_fields' value='$eupload_fields' size='10' maxlength='200'></td><td> Number of files to upload in a single pass</td></tr>
                     <tr><td><b> Resize X:</b></td><td><input type='text' name='xeupload_resizex' value='$eupload_resizex' size='10' maxlength='200'></td><td> Maximum X size of uploaded picture</td></tr>
                     <tr><td><b>Resize Y:</b></td><td><input type='text' name='xeupload_resizey' value='$eupload_resizey' size='10' maxlength='200'></td><td> Maximum Y size of uploaded picture</td></tr>";
                     $ResultHtml.= "</table>
     <br><br><input type='hidden' name='op' value='ConfigUpdate'><center><input type='submit' value='SAVE CHANGES'></center></form>
    </td></tr></table>";


function ConfigUpdates($dbID, $xpID, $xID, $xsitetitle, $xsitecharset, $xsitecontent, $xsiteauthor, $xpagesectionhome,
                             $xthemename, $xearticles, $xecontact, $xenews_per_page, $xehead_per_page,
                             $xetable_width, $xelinks_per_page, $xenew_days, $xepage_width, $xegd_version, $xepics_per_page,
                             $xedemo_mode, $xemedia_folder, $xecats_per_page, $xeupload_fields, $xeupload_resizex, $xeupload_resizey ) {
Global $PageSection, $idid, $FREEID, $EDP_SELF;
$xpagesectionhome=0;
for ($i=0; $i< count($xpID); $i++) {mysql_query("UPDATE edp_pconfig SET  ID='$xpID[$i]'  where ID=$dbID[$i]");}
mysql_query("UPDATE edp_config SET  ID='$xID',sitetitle='$xsitetitle',sitecharset='$xsitecharset',sitecontent='$xsitecontent', siteauthor='$xsiteauthor', pagesectionhome='$xpagesectionhome', themename='$xthemename',  earticles='$xearticles', econtact='$xecontact', enews_per_page='$xenews_per_page', ehead_per_page='$xehead_per_page', etable_width='$xetable_width', elinks_per_page='$xelinks_per_page', enew_days='$xenew_days', epage_width='$xepage_width', egd_version='$xegd_version', epics_per_page='$xepics_per_page', edemo_mode='$xedemo_mode', emedia_folder='$xemedia_folder', ecats_per_page='$xecats_per_page',  eupload_fields='$xeupload_fields', eupload_resizex='$xeupload_resizex', eupload_resizey='$xeupload_resizey' where ID=$idid");
Header("Location: $EDP_SELF&page=config&do=add_page&du=site");
}

function TopicUpdates($xpID) {
Global $PageSection, $FREEID;
for ($i=0; $i< count($xpID); $i++) {$ypID[$i]=$xpID[$i]+1000;  mysql_query("UPDATE edp_pconfig SET  ID='$ypID[$i]'  where ID=$FREEID[$i]");}
for ($i=0; $i< count($xpID); $i++) {mysql_query("UPDATE edp_pconfig SET  ID='$xpID[$i]'  where ID=$ypID[$i]");}
Header("Location: $EDP_SELF&page=config&do=add_page&du=site");
}


if($op=="ConfigUpdate") ConfigUpdates($dbID, $xpID, $xID, $xsitetitle, $xsitecharset, $xsitecontent, $xsiteauthor, $xpagesectionhome, $xthemename,  $xearticles, $xecontact, $xenews_per_page, $xehead_per_page, $xetable_width, $xelinks_per_page, $xenew_days, $xepage_width, $xegd_version, $xepics_per_page, $xedemo_mode, $xemedia_folder, $xecats_per_page,  $xeupload_fields, $xeupload_resizex, $xeupload_resizey);


?>

<SCRIPT LANGUAGE="JavaScript">
function selectColor ( color ) { url = "<? echo $edp_relative_path."admin/colors.php?color="; ?>" + color; var colorWindow = window.open(url,"ColorSelection","width=390,height=343,resizable=no,scrollbars=no"); }
</SCRIPT>

