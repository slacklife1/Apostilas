<?
    $id = $HTTP_GET_VARS['id']; $uid = $Stoitsov["ID"];

  Calendar($useradmin, $m, $y, $d, $str, $str1);

  $ResultHtml.= $str1."<hr><br>";
?>
