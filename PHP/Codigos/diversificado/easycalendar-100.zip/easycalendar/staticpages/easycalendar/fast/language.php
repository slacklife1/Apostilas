<?


$language['months'] = array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
$language['days'] = array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
$language['abrvdays'] = array("<font color=#B1C6F3>Su</font>", "Mo", "Tu", "We", "Th", "Fr", "<font color=#B1C6F3>Sa</font>");

// eventdisplay.php
$language['otheritems'] = "Also On This Day:";
$language['deleteconfirm'] = "Are you sure you want to delete this item?";
$language['postedby'] = "Posted by";

// index.php
$language['login'] = "Login";
$language['logout'] = "Logout";
$language['adminlnk'] = "User Admin";
$language['changepw'] = "Change Password";


// editnews_page.php
$language['datetext'] = "Date:";
$language['title'] = "Title:";
$language['text'] = "Text:";
$language['cancel'] = "Cancel";
$language['editeventtitle'] = "phpEventCalendar: Event Edit Screen";
$language['editheader'] = "Edit Event";
$language['editbutton'] = "Update";
$language['updated'] = "Updated";
$language['addeventtitle'] = "phpEventCalendar: Event Add Screen";
$language['addheader'] = "Add New Event";
$language['addbutton'] = "Post";
$language['added'] = "Added";
$language['starttime'] = "Start Time:";
$language['endtime'] = "End Time:";
$language['titlemissing'] = "The Title is Missing";
$language['missingevent'] = "Error: event does not exit";
$language['accessdenied'] = "Authorization Required.  You are not logged in.  Click <a href=\"index.php\">here</a> to return to the calendar.";
$language['popaccessdenied'] = "Access Denied!!!  Please login to access this page.";


?>

