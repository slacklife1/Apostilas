<?
/*      ******************************************************************
        **********************  EasyCalendar  ************************
	******************************************** software.stoitsov.com  */
include_once "admin/serverdata.php";
mysql_connect($Easy["mysql_host"],$Easy["mysql_user"],$Easy["mysql_pass"]);
mysql_select_db($Easy["mysql_base"]);
$home=mysql_fetch_array(mysql_query("SELECT dpFREED FROM edp_pconfig WHERE ID=1"));
Header("Location:".$home["dpFREED"]);
?>


