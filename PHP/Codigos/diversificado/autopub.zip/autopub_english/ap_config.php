<?

//////////////////////////////////////////////////////////////////////
// AUTOPUB 1.0
// Marc Cagninacci - http://www^phpforums.net - marc@phpforums.net
//////////////////////////////////////////////////////////////////////



// CHANGE ALL THAT !


$apserver="localhost"; // Host name
$aplogin="";       // Your login
$appassword="";	     // Your pass
$apbase="";     // DB name
$aptable="autopub";    // Table name

$apbgcolor= "#666699" ;  // Background color
$aptxtcolor= "#ffffff" ; // Font color
$apliencolor= "fffff0" ; // Link color
$apfont= "verdana" ;     // Font face
$apsize= "2" ;           // Font size

$apwidth= "77" ;  // Logo's width
$apheight= "30" ; // Logo's height
$apinvite= "Your Logo there ?<br> Click to add." ; // Text link under the logo
$apdelai = "1200" ; // D�lay in seconds before someone can replace the existant logo with another one

$apretour= "http://www.yoursite.com/index.php" ; //Absolute URL for the page where is included ap_affich.php
$apsite= "Your Site" ;                            // Your site name
$apemail= "you@yoursite.com" ;                  // Your email

?>
