<?


//////////////////////////////////////////////////////////////////////
// AUTOPUB 1.0
// Marc Cagninacci - http://www^phpforums.net - marc@phpforums.net
//////////////////////////////////////////////////////////////////////


require ("ap_config.php");
?>
<html>
<head>
<title><? echo $apsite; ?> - AutoPub</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<style type="text/css">
<!--
a:link {  font-family: <? echo $apfont; ?>; color:<? echo $apliencolor; ?>; font-size: 12; text-decoration: none}
a:actif {  font-family: <? echo $apfont; ?>; color:<? echo $apliencolor; ?>; font-size: 12; text-decoration: none}
a:hover { font-family: <? echo $apfont; ?>; color:<? echo $apliencolor; ?>;  font-size: 12; text-decoration: none}
a:visited { font-family: <? echo $apfont; ?>; color:<? echo $apliencolor; ?>; font-size: 12; text-decoration: none}

-->
</style>


<body bgcolor="<? echo $apbgcolor; ?>" text="<? echo $textcolor; ?>">
<?
$apdelaimn= $apdelai/60 ;

echo "<p align='center'><font color='$aptxtcolor' face='$apfont' size='$apsize'>$apsite allows you to add a logo with a link to your site, until someone replaces it with an other one.<br>But your link will stay during <b>$apdelaimn minutes</b> at least.<br></font></p>";

 
$apconnect= mysql_connect($apserver, $aplogin, $appassword);
mysql_select_db($apbase, $apconnect);
$apquestion= mysql_query("select * from $aptable");
$aprow= mysql_fetch_row($apquestion);
$aplibre= $aprow[3] + $apdelai ;
mysql_free_result($apquestion);
$aptime= time();

if($aplibre <= $aptime){
echo"<font color='$aptxtcolor' face='$apfont' size='$apsize'><li>The Logo must be a GIF file</li><li>It have to be $apwidth pixels width and $apheight height</li>.</font>";

?>
<form action="ap_form.php" method="post">
<input type="text" size="30" name="aplien">&nbsp <b><font face='<? echo $apfont; ?>' size='<? echo $apsize; ?>' color="<? echo $aptxtcolor; ?>">Link to your site </b>(like http://www.yoursite.com)</font><br>
<input type="text" size="30" name="aplogo">&nbsp <b><font face='<? echo $apfont; ?>' size='<? echo $apsize; ?>' color="<? echo $aptxtcolor; ?>">Url of the logo </b>(like http://www.yoursite.com/image/yourlogo)<br> <b>ATTENTION</b> Don't type the".gif "extension, it will be added by the script.</font><br><br>
<input type="submit" name="Submit" value=" OK ">
</form>
<?

  
	if(($aplien!="") && ($aplogo!=""))
  {
	
    $sql ="UPDATE $aptable SET aplien='$aplien'";
    $resultat = mysql_query($sql);
    $sql ="UPDATE $aptable SET aplogo='$aplogo'";
    $resultat = mysql_query($sql);
    $sql ="UPDATE $aptable SET aptime='$aptime'";
    $resultat = mysql_query($sql);
    echo "<p align='center'><font color='$aptxtcolor' face='$apfont' size='$apsize'>Done<br></font></p>";
    
  }
  else
  {
    echo "<br><br><p align='center'><font color='$aptxtcolor' face='$apfont' size='$apsize'>Textareas aren't checked, have a look again before clicking OK !.<br><br></font></p>";

  }
}

else  {
    $apreste= (($aplibre - $aptime)/60)+1;
	if($apreste>10) {
  $aprestemn= substr ($apreste,0,2);
			}
		else	{
  $aprestemn= substr ($apreste,0,1);
		}
  echo "<p align='center'><font color='$aptxtcolor' face='$apfont' size='$apsize'><br>By th way, the logo you have seen will stay here for less than <b>$aprestemn minutes</b> again. So you can't add yours before, but you can prepare for the next time :<br><br><li>You will have to type your website's URL</li><li>Then your logo's URL</li><li>Your logo must be a GIF file</li><li>It have to be $apwidth pixels width and $apheight height</li><br><br>That's all we need.<br>See you soon !<br><br><br></font></p>";

}
echo"<p align='center'><a href='$apretour'><b>Back</b></a><br><br><font color='$aptxtcolor' face='$apfont' size='$apsize'>In case of trouble-shooting,</font><a href='mailto:$apemail'><b>&nbspwrite us.</b></a></p>";
?> 

</body>
</html>
           
	
