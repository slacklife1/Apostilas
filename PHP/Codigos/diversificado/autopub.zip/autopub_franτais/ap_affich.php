<?

//////////////////////////////////////////////////////////////////////
// AUTOPUB 1.0
// Marc Cagninacci - http://www^phpforums.net - marc@phpforums.net
//////////////////////////////////////////////////////////////////////

require ("autopub/ap_config.php");
?>
<html>
<head>
<title><? echo $apsite; ?> - AutoPub</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<style type="text/css">
<!--
a:link {  font-family: <? echo $apfont; ?>; color:<? echo $apliencolor; ?>; font-size: 10; text-decoration: none}
a:actif {  font-family: <? echo $apfont; ?>; color:<? echo $apliencolor; ?>; font-size: 10; text-decoration: none}
a:hover { font-family: <? echo $apfont; ?>; color:<? echo $apliencolor; ?>;  font-size: 10; text-decoration: none}
a:visited { font-family: <? echo $apfont; ?>; color:<? echo $apliencolor; ?>; font-size: 10; text-decoration: none}

-->
</style>

<?
$apconnect= mysql_connect ($apserver, $aplogin, $appassword);
mysql_select_db ($apbase, $apconnect);
$apquery= mysql_query("select * from $aptable");
$aprang= mysql_fetch_row($apquery);
$aplien= $aprang[1];
$aplogo= $aprang[2];
?>
<body bgcolor="<?PHP echo $apbgcolor ; ?>" text="<?PHP echo $aptxtcolor ; ?>">
<table align="center" width="<?PHP echo $apwidth+2 ; ?>" border="0" cellspacing="2">
  <tr>
    <td bgcolor="<?PHP echo $apbgcolor ; ?>" >
      <div align="center"><a href="<?PHP echo $aplien ; ?>"><img src="<?PHP echo $aplogo ; ?>.gif" width="<?PHP echo $apwidth ; ?>" height="<?PHP echo $apheight ; ?>" border="0"></a></div>
    </td>
  </tr>
  <tr>
    <td bgcolor="<?PHP echo $apbgcolor ; ?>" ><div align="center"><br><font size="1"><a href="autopub/ap_form.php" target="_top"><?PHP echo $apinvite ; ?></font></div></td>
  </tr>
</table>
</body>
</html>
