<?

//////////////////////////////////////////////////////////////////////
// AUTOPUB 1.0
// Marc Cagninacci - http://www^phpforums.net - marc@phpforums.net
//////////////////////////////////////////////////////////////////////



// RENSEIGNEZ ou modifiez TOUTES LES VARIABLES CI-DESSOUS


$apserver="localhost"; // Nom du serveur
$aplogin="";       // Votre identifiant de connection
$appassword="";	     // Votre mot de passe
$apbase="";     // Nom de la Base
$aptable="autopub";    // Nom de la table

$apbgcolor= "#666699" ;  // Couleur d'arri�re plan
$aptxtcolor= "#ffffff" ; // Couleur du texte
$apliencolor= "fffff0" ; // Couleur des liens
$apfont= "verdana" ;     // Police
$apsize= "2" ;           // Taille de police

$apwidth= "77" ;  // Largeur du logo
$apheight= "30" ; // Hauteur du logo
$apinvite= "Votre Logo ici ?<br> Cliquez pour vous inscrire." ; // Texte du lien sous le logo affich�
$apdelai = "1200" ; // D�lai en secondes avant de pouvoir changer de logo (ici 20 minutes)

$apretour= "http://www.phpforums.net/index.php" ; //URL absolue de la page o� est inclus ap_affich.php
$apsite= "PhpForums" ;                            // Nom de votre site
$apemail= "marc@phpforums.net" ;                  // Votre email

?>
