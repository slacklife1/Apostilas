<?


//////////////////////////////////////////////////////////////////////
// AUTOPUB 1.0
// Marc Cagninacci - http://www^phpforums.net - marc@phpforums.net
//////////////////////////////////////////////////////////////////////


require ("ap_config.php");
?>
<html>
<head>
<title><? echo $apsite; ?> - AutoPub</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<style type="text/css">
<!--
a:link {  font-family: <? echo $apfont; ?>; color:<? echo $apliencolor; ?>; font-size: 12; text-decoration: none}
a:actif {  font-family: <? echo $apfont; ?>; color:<? echo $apliencolor; ?>; font-size: 12; text-decoration: none}
a:hover { font-family: <? echo $apfont; ?>; color:<? echo $apliencolor; ?>;  font-size: 12; text-decoration: none}
a:visited { font-family: <? echo $apfont; ?>; color:<? echo $apliencolor; ?>; font-size: 12; text-decoration: none}

-->
</style>


<body bgcolor="<? echo $apbgcolor; ?>" text="<? echo $textcolor; ?>">
<?
$apdelaimn= $apdelai/60 ;

echo "<p align='center'><font color='$aptxtcolor' face='$apfont' size='$apsize'>$apsite vous propose d'afficher un logo pointant sur votre Site gratuitement, jusqu'&agrave; ce qu'un autre visiteur affiche le sien &agrave; la place.<br>Mais votre logo restera affich&eacute; pendant <b>$apdelaimn minutes</b> minimum.<br></font></p>";

 
$apconnect= mysql_connect($apserver, $aplogin, $appassword);
mysql_select_db($apbase, $apconnect);
$apquestion= mysql_query("select * from $aptable");
$aprow= mysql_fetch_row($apquestion);
$aplibre= $aprow[3] + $apdelai ;
mysql_free_result($apquestion);
$aptime= time();

if($aplibre <= $aptime){
echo"<font color='$aptxtcolor' face='$apfont' size='$apsize'><li>Votre logo doit &ecirc;tre au format GIF</li><li>Il doit mesurer $apwidth pixels de large sur $apheight de haut</li>.</font>";

?>
<form action="ap_form.php" method="post">
<input type="text" size="30" name="aplien">&nbsp <b><font face='<? echo $apfont; ?>' size='<? echo $apsize; ?>' color="<? echo $aptxtcolor; ?>">Lien vers votre site </b>(au format http://www.votresite.com)</font><br>
<input type="text" size="30" name="aplogo">&nbsp <b><font face='<? echo $apfont; ?>' size='<? echo $apsize; ?>' color="<? echo $aptxtcolor; ?>">Url de votre Logo </b>(au format http://www.votresite.com/image/votrelogo)<br> <b>ATTENTION</b> Ne saisissez pas l'extension ".gif ", elle sera ajout&eacute;e automatiquement.</font><br><br>
<input type="submit" name="Submit" value="Publier">
</form>
<?

  
	if(($aplien!="") && ($aplogo!=""))
  {
	
    $sql ="UPDATE $aptable SET aplien='$aplien'";
    $resultat = mysql_query($sql);
    $sql ="UPDATE $aptable SET aplogo='$aplogo'";
    $resultat = mysql_query($sql);
    $sql ="UPDATE $aptable SET aptime='$aptime'";
    $resultat = mysql_query($sql);
    echo "<p align='center'><font color='$aptxtcolor' face='$apfont' size='$apsize'>Publication effectu�e<br></font></p>";
    
  }
  else
  {
    echo "<br><br><p align='center'><font color='$aptxtcolor' face='$apfont' size='$apsize'>N'oubliez pas d'indiquer les deux URL.<br><br></font></p>";

  }
}

else  {
    $apreste= (($aplibre - $aptime)/60)+1;
	if($apreste>10) {
  $aprestemn= substr ($apreste,0,2);
			}
		else	{
  $aprestemn= substr ($apreste,0,1);
		}
  echo "<p align='center'><font color='$aptxtcolor' face='$apfont' size='$apsize'><br>Selon ce principe, le logo actuel va encore rester affich� moins de <b>$aprestemn minutes</b> sur les $apdelaimn initiales. Vous ne pouvez donc pas proposer le v&ocirc;tre avant ce d�lai, mais vous pouvez d&eacute;j&agrave; vous pr&eacute;parer pour la prochaine fois :<br><br><li>Vous devrez saisir l'URL de votre Site</li><li>Egalement l'URL de votre Logo</li><li>Votre logo doit &ecirc;tre au format GIF</li><li>Il doit mesurer $apwidth pixels de large sur $apheight de haut</li><br><br>C'est tout ce dont vous aurez besoin.<br>A bient&ocirc;t !<br><br><br></font></p>";

}
echo"<p align='center'><a href='$apretour'><b>Retour</b></a><br><br><font color='$aptxtcolor' face='$apfont' size='$apsize'>En cas de probl&egrave;me,</font><a href='mailto:$apemail'><b>&nbsp&eacute;crivez-nous</b></a></p>";
?> 

</body>
</html>
           
	
