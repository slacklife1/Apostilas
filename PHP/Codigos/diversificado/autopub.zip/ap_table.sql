CREATE TABLE autopub (
   apid int(1) DEFAULT '1' NOT NULL,
   aplien varchar(255) NOT NULL,
   aplogo varchar(255) NOT NULL,
   aptime varchar(150) NOT NULL,
   UNIQUE id (apid)
);
INSERT INTO autopub VALUES( '1', 'http://www.phpforums.net', 'http://www.phpforums.net/image/PFNbouton', '966782939');
