<?php
include "phpCards.header.php";
$query1 = ("SELECT * from $cardInfoTable");
$result1 = mysql_query($query1);
$total_num_rows = mysql_num_rows($result1);  
?>

	<TR>
	<TD ALIGN="CENTER"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><B><?php echo "$SelectCatMsg"; ?></B></FONT></TD>
	</TR>
	<TR>
	<TD ALIGN="CENTER"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3">
	<?	
	// query the database for all cards with selected category ID
	$query = "SELECT * from $cardCatTable";


		$result = MYSQL_QUERY($query);
		$number = MYSQL_NUMROWS($result);
		$i=="0";

		/* If there are no matches in the DB, then return an error message */
		IF ($number==$i):
		print "$NoMatchesTxt</TD></TR>";
		include "phpCards.footer.php";
		exit;
		
		ELSE:	
		?>
		<FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="2">There are <?php echo "$total_num_rows"; ?> cards in the database.</font>
		<h3>Categories:</h3></td></tr>
		
		 &nbsp;</TD></TR>
		 <TR><TD><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3">
		 <UL>
		 <?php
		while  ($row  =  mysql_fetch_row($result))  {


		?>
		 <LI><a href="phpCardsChoose.php?CatID=<?php echo "$row[0]"; ?>&CatName=<?php echo "$row[1]"; ?>"><?php echo "$row[1]"; ?></a>
		 <?php
		} 
		?>
		 </FONT></TD></TR> 
		 <?php 


 	
		ENDIF;
		?>
		</TABLE>
		</FORM>
		<BR><BR>
	
	
	</FONT></TD>
</TR>

<?php
include "phpCards.footer.php";
?>