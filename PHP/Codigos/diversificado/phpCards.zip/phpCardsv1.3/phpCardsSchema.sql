
#
# Table structure for table 'phpCardData'
#

CREATE TABLE phpCardData (
   imageID int(20) NOT NULL auto_increment,
   CardCategory int(20) NOT NULL,
   CardImage varchar(50) NOT NULL,
   CardThumb varchar(50) NOT NULL,
   DefaultMsg varchar(150) NOT NULL,
   PRIMARY KEY (imageID)
);




#
# Table structure for table 'phpCatData'
#

CREATE TABLE phpCatData (
   CatID int(10) NOT NULL auto_increment,
   CatName varchar(35) NOT NULL,
   PRIMARY KEY (CatID)
);




#
# Table structure for table 'phpCardUsers'
#

CREATE TABLE phpCardUsers (
   CardDate varchar(14),
   SendName varchar(60) NOT NULL,
   SendEmail varchar(60) NOT NULL,
   RecName varchar(60) NOT NULL,
   RecEmail varchar(60) NOT NULL,
   CardHeader varchar(150) NOT NULL,
   CardMessage blob NOT NULL,
   MessageID varchar(25) NOT NULL,
   CardImage varchar(50) NOT NULL,
   HaveRead varchar(4) NOT NULL,
   PRIMARY KEY (MessageID)
);

# creates first postcard and category
INSERT INTO phpCatData VALUES( '1', 'General');
INSERT INTO phpCardData VALUES( '1', '1', '1.jpg', '1-th.jpg', 'Sample Card Message');

