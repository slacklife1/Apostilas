<?php
include "../phpCards.header.php";
?>

	<TR><form method=post action="phpCardsSaveNew.php" ENCTYPE="multipart/form-data">
	<TD ALIGN="CENTER"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><B><?php echo "$AdminEditMsg"; ?></B></FONT>	
		 &nbsp;</TD></TR>
		 <tr><TD VALIGN="TOP"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3">
		Upload Thumbnail:<BR>
		<INPUT NAME="urlpic" TYPE="file" SIZE="20">
		<br><BR>Upload Full size:<BR>
		 <INPUT NAME="fullsize" TYPE="file" SIZE="20"><br><br><b><?php echo "$MessageTxt"; ?>:</b><br><textarea name="CardHeader" rows="2" cols="25" wrap="virtual"></textarea><br>
		<br>
		<b><?php echo "$AdminCatUpdateTxt"; ?></b><br>
		<select name="CardCategory">
				<?php
				$newquery = "SELECT * from $cardCatTable";
				$newresult = MYSQL_QUERY($newquery);
				$newnumber = MYSQL_NUMROWS($newresult);
				
				?>
				
				<?php
				 while  ($row  =  mysql_fetch_row($newresult))  {
				 ?>
				 <OPTION VALUE="<?php echo "$row[0]"; ?>"><?php echo "$row[1]"; ?></OPTION>
				 <?
				}
			
				?>
		</select>
		
		
		 </FONT></TD></TR> 
		
				<INPUT TYPE="hidden" name="SelectedCard" value="<?php echo "$SelectedCard"; ?>"><?php echo "$SelectedCard"; ?>
		<tr><td align="center">

		<FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="-1"><input type="submit" value="Next"></font></td></tr>
		</TABLE>
		</FORM>
		<BR><BR>
	
	
	</FONT></TD>
	</form>
</TR>

<?php
include "../phpCards.footer.php";
?>