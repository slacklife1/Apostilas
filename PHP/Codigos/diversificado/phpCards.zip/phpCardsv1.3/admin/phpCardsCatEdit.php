<?php
include "../phpCards.header.php";
?>

	<TR>
	<TD ALIGN="CENTER"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><b><?php echo "$AdminEditCatTxt"; ?></b></FONT></td></tr>

	<tr><td><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3">
	<?
	IF ($action=="delete"):
	 echo "$AdminConfirmDeleteCatTxt"; ?>
	<FORM METHOD=POST ACTION="<? echo "$PHP_SELF"; ?>">

	<INPUT TYPE="submit" NAME="action" VALUE="yes">
	<INPUT TYPE="hidden" NAME="CatID" VALUE="<? echo"$CatID"; ?>">
	</FORM>
	<br><br><a href="index.php"><?php echo "$BackTxt"; ?></a></font>
	</td></tr>
	<?php
	include "../phpCards.footer.php";
		exit;

	// yep... they really want to delete it.
ELSEIF ($action=="yes"):

$query = "delete from $cardCatTable WHERE (CatID='$CatID')";
$result = MYSQL_QUERY($query);

?>

<?php 
echo "$AdminConfirmCatDeleteMsg";
?>
<BR>
<BR><a href="index.php"><?php echo "$BackTxt"; ?></a>
</font>
	</td></tr>
	<?php
	include "../phpCards.footer.php";
		exit;

ELSEIF ($action=="add"):
 echo "$AdminAddCatTxt"; ?>
	<FORM METHOD=POST ACTION="<? echo "$PHP_SELF"; ?>">
	<FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><?php echo "$NewCategoryNameTxt"; ?>: <input type="text" name="CatName"></font>
	<INPUT TYPE="submit" NAME="action" VALUE="add category">
	</FORM>
<br><br><a href="index.php"><?php echo "$BackTxt"; ?></a></font>
	</td></tr>
	<?php
	include "../phpCards.footer.php";
		exit;
			
ELSEIF ($action=="add category"):
 echo "$AdminAddCatTxt"; 
		// update the info in the database
	$query = "INSERT into $cardCatTable VALUES ('','$CatName')";
	$result = MYSQL_QUERY($query);
	?>
<FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><?php echo "$AdminConfirmAdd"; ?></font>
<br><br><a href="index.php"><?php echo "$BackTxt"; ?></a></font>
	</td></tr>
	<?php
	include "../phpCards.footer.php";
		exit;

ELSEIF ($action=="edit"):
		// query the database for all cards with selected category ID
		$query = "SELECT * from $cardCatTable WHERE CatID='$CatID'";
		$result = MYSQL_QUERY($query);
		$number = MYSQL_NUMROWS($result);
		$i=="0";

		/* If there are no matches in the DB, then return an error message */
		IF ($number==$i):
		print "$NoMatchesTxt</TD></TR>";
		include "../phpCards.footer.php";
		exit;
		
		ELSE:	
		?>
		 &nbsp;</TD></TR>
		 <TR><TD><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3">
		 <UL>
		 <?php
		while  ($row  =  mysql_fetch_row($result))  {
	?>
	<form method=post action="<?php echo "$PHP_SELF"; ?>">
	<?php echo "$CategoryNameTxt"; ?>: <input type="text" name="CatName" value="<?php echo "$row[1]"; ?>">
	<?php
	}
	ENDIF;
	?>
	<br>
	<br>
	<input type="hidden" name="CatID" value="<?php echo "$CatID"; ?>">
	<input type="submit" name="action" value="update">
	</form> 

<br><br><a href="index.php"><?php echo "$BackTxt"; ?></a></font>
	</td></tr>
	<?php
	include "../phpCards.footer.php";
		exit;
ELSEIF ($action=="update"):
		// update the info in the database
	$query = "UPDATE $cardCatTable SET CatName='$CatName' WHERE (CatID='$CatID')";
	$result = MYSQL_QUERY($query);

	?>
<FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><?php echo "$AdminConfirmEdit"; ?></font>
<br><br><a href="index.php"><?php echo "$BackTxt"; ?></a></font>
	</td></tr>
	<?php
	include "../phpCards.footer.php";
		exit;
ENDIF;
?>				