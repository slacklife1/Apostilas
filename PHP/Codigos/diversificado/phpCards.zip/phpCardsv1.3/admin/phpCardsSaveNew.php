<?php
include "../phpCards.header.php";
srand((double)microtime()*1000000);
$randval = rand();
?>

	<TR><form method=post action="phpCardsSave.php" ENCTYPE="multipart/form-data">
	<TD ALIGN="CENTER"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><b><?php echo "$AdminNewTxt"; ?></b></FONT>
	<?	

	// checks to see if an image was chosen
	// uploads the thumbnail
		IF ($urlpic!="none"):
			copy($urlpic,"$CardPicPath"."/"."$randval"."-th.gif"); 
			$size = GetImageSize("$CardPicPath"."/"."$randval"."-th.gif"); 

			IF ($size[2]=="2"):
			// This is really a jpg! - rename it as such
			$newthumb="$randval"."-th.jpg";
			rename("$CardPicPath"."/"."$randval"."-th.gif", "$CardPicPath"."/"."$randval"."-th.jpg"); 
			ELSEIF ($size[2]=="1"):
			// Gif it is!
			$newthumb = "$randval"."-th.gif";
			ENDIF;

			unlink($urlpic);
	
		
			ENDIF;



	// checks to see if an image was chosen
			IF ($fullsize!="none"):
			// uploads the full size image
			copy($fullsize,"$CardPicPath"."/"."$randval".".gif"); 
			$size = GetImageSize("$CardPicPath"."/"."$randval".".gif"); 

				IF ($size[2]=="2"):
				// This is really a jpg! - rename it as such
				$newimagename="$randval".".jpg";
				rename("$CardPicPath"."/"."$randval".".gif", "$CardPicPath"."/"."$randval".".jpg"); 
				ELSEIF ($size[2]=="1"):
				// Gif it is!
				$newimagename = "$randval".".gif";
				ENDIF;

			unlink($fullsize);
			
			
		
			ENDIF;
			

	// update the info in the database
	$query = "INSERT into $cardInfoTable VALUES ('','$CardCategory','$newimagename', '$newthumb','$CardHeader')";

	$result = MYSQL_QUERY($query);

	?>
		</td>
		</tr><tr><td align="center">
				
				<a href="index.php"><?php echo "$BackTxt"; ?></a></font></td></tr>
		</TABLE>
		</FORM>
		<BR><BR>
	
	
	</FONT></TD>
	</form>
</TR>

<?php
include "../phpCards.footer.php";
?>