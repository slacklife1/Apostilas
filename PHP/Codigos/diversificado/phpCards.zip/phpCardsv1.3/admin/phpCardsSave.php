<?php
include "../phpCards.header.php";
?>

	<TR><form method=post action="phpCardsSave.php" ENCTYPE="multipart/form-data">
	<TD ALIGN="CENTER"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><B><?php echo "$AdminEditMsg"; ?></B></FONT>
	<?	
	srand((double)microtime()*1000000);
	$randval = rand();
	// checks to see if an image was chosen
	// uploads the thumbnail
	IF ($updateThumb=="yes"):
		IF ($urlpic!="none"):
			copy($urlpic,"$CardPicPath"."/"."$randval"."-th.gif"); 
			$size = GetImageSize("$CardPicPath"."/"."$randval"."-th.gif"); 

			IF ($size[2]=="2"):
			// This is really a jpg! - rename it as such
			$newthumb="$randval"."-th.jpg";
			rename("$CardPicPath"."/"."$randval"."-th.gif", "$CardPicPath"."/"."$randval"."-th.jpg"); 
			ELSEIF ($size[2]=="1"):
			// Gif it is!
			$newthumb = "$randval"."-th.gif";
			ENDIF;

			unlink($urlpic);
	
		
			ENDIF;


	ELSEIF ($updateThumb=="no"):
	$newthumb="$ThumbName";
	ENDIF;
	

	// checks to see if an image was chosen
	IF ($updateFull=="yes"):
			IF ($fullsize!="none"):
			// uploads the full size image
			copy($fullsize,"$CardPicPath"."/"."$randval".".gif"); 
			$size = GetImageSize("$CardPicPath"."/"."$randval".".gif"); 

				IF ($size[2]=="2"):
				// This is really a jpg! - rename it as such
				$newimagename="$randval".".jpg";
				rename("$CardPicPath"."/"."$randval".".gif", "$CardPicPath"."/"."$randval".".jpg"); 
				ELSEIF ($size[2]=="1"):
				// Gif it is!
				$newimagename = "$randval".".gif";
				ENDIF;

			unlink($fullsize);
			
			
		
			ENDIF;
			


	ELSEIF ($updateFull=="no"):
	$newimagename="$ImageName";
	ENDIF;

	// update the info in the database
	$query = "UPDATE $cardInfoTable SET CardImage='$newimagename', CardThumb='$newthumb', DefaultMsg='$CardHeader', CardCategory='$CardCategory' WHERE (ImageID='$SelectedCard')";

	$result = MYSQL_QUERY($query);


	// query the database for all cards with selected category ID
	$query = "SELECT * from $cardInfoTable WHERE imageID='$SelectedCard'";


		$result = MYSQL_QUERY($query);
		$number = MYSQL_NUMROWS($result);
		$i=="0";

		/* If there are no matches in the DB, then return an error message */
		IF ($number==$i):
		print "<br><br>$ChooseCardTxt<br><br><form><input type=\"button\" onclick=\"button('javascript:history.back(1)')\" value=\"$BackTxt\"></form></TD></TR>";
		include "../phpCards.footer.php";
		exit;
		
		ELSE:	
		?>
		<?php
		 while  ($row  =  mysql_fetch_row($result))  {

		// gets the mage size so that the thumbnails and full size images 
		// will have their sizes dynamically created in the IMG tag
		$FullSize = GetImageSize ("../"."$CardRelURL"."$row[2]");
		$ThumbSize = GetImageSize ("../"."$CardRelURL"."$row[3]");
		?>
		 &nbsp;</TD></TR>
		 <TR><TD ALIGN="CENTER"><IMG SRC="<?php echo "$CardImageURL"; ?><?php echo "$row[2]"; ?>" <?php echo $FullSize[3]; ?> BORDER="0" ALT=""></TD></tr>
		 <tr><TD VALIGN="TOP"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3">
		 <BR><b>Update Thumbnail?</b><br>
		<INPUT TYPE="radio" NAME="updateThumb" VALUE="yes">Yes  <INPUT TYPE="radio" NAME="updateThumb" VALUE="no" CHECKED>No<BR>Upload Thumbnail:<BR>
		<INPUT NAME="urlpic" TYPE="file" SIZE="20">
		<BR><BR>
		 <b>Update Full Size?</b>
		 <BR>
		 <INPUT TYPE="radio" NAME="updateFull" VALUE="yes">Yes <INPUT TYPE="radio" NAME="updateFull" VALUE="no" CHECKED>No<BR>Upload Full size:<BR>
		 <INPUT NAME="fullsize" TYPE="file" SIZE="20"><br><br><b><?php echo "$MessageTxt"; ?>:</b><br><textarea name="CardHeader" rows="2" cols="25" wrap="virtual"><?php echo "$row[4]"; ?></textarea><br>
		<br>
		<b><?php echo "$AdminCatUpdateTxt"; ?></b><br>
		<input type="hidden" name="ImageName" value="<?php echo "$row[2]"; ?>">
		<input type="hidden" name="SelectedCard" value="<?php echo "$SelectedCard"; ?>">
		<input type="hidden" name="ImageName" value="<?php echo "$row[2]"; ?>">
		<input type="hidden" name="ThumbName" value="<?php echo "$row[3]"; ?>">
		<input type="hidden" name="SelectedCard" value="<?php echo "$SelectedCard"; ?>">
		<select name="CardCategory">
		<OPTION VALUE="<?php echo "$row[1]"; ?>" selected><?php echo "$AdminDoNotChange"; ?></OPTION>
				<?php
				$newquery = "SELECT * from $cardCatTable";
				$newresult = MYSQL_QUERY($newquery);
				$newnumber = MYSQL_NUMROWS($newresult);
				
				?>
				
				<?php
				 while  ($row  =  mysql_fetch_row($newresult))  {
				 ?>
				 <OPTION VALUE="<?php echo "$row[0]"; ?>"><?php echo "$row[1]"; ?></OPTION>
				 <?
				}
				?>
		</select>
		
		
		 </FONT></TD></TR> 
		 
		 <?php 

		}
		
		ENDIF;
		?>
		<tr><td align="center">
		
		<input type="hidden" name="ImageSize" value='<?php echo $FullSize[3]; ?>'>
<br><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="-1"><input type="submit" value="Next"><br><br><a href="index.php"><?php echo "$BackTxt"; ?></a></font></td></tr>
		</TABLE>
		</FORM>
		<BR><BR>
	
	
	</FONT></TD>
	</form>
</TR>

<?php
include "../phpCards.footer.php";
?>