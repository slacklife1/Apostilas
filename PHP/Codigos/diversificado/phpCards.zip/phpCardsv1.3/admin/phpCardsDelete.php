<?php
include "../phpCards.header.php";
?>

	<TR>
	<TD ALIGN="CENTER"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><b><?php echo "$AdminDeleteCardTxt"; ?></b></FONT></td></tr>

	<tr><td><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3">
	<?
	IF ($action=="delete"):
	 echo "$AdminConfirmDeleteCardTxt"; ?>
	<FORM METHOD=POST ACTION="<? echo "$PHP_SELF"; ?>">

	<INPUT TYPE="submit" NAME="action" VALUE="yes">
	<INPUT TYPE="hidden" NAME="ImageID" VALUE="<? echo"$ImageID"; ?>">
	</FORM>
	<form><input type="button" onclick="button('javascript:history.back(1)')" value="<?php echo "$BackTxt"; ?>"></form>
	<?php
	include "../phpCards.footer.php";
	exit;

	// yep... they really want to delete it.
ELSEIF ($action=="yes"):

$query = "delete from $cardInfoTable WHERE (ImageID='$ImageID')";
$result = MYSQL_QUERY($query);

?>
Your selection has been deleted.
<BR>
<BR>
<?
			
ENDIF;
?>				
				<a href="index.php"><?php echo "$BackTxt"; ?></a></font></td></tr>
		</TABLE>
		</FORM>
		<BR><BR>
	
	
	</FONT></TD>
	</form>
</TR>

<?php
include "../phpCards.footer.php";
?>