<?php
include "../phpCards.header.php";
?>

	<TR>
	<TD ALIGN="CENTER"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><B><?php echo "$AdminSelectCatMsg"; ?></B></FONT></TD>
	</TR>
	<TR>
	<TD ALIGN="CENTER"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3">
	<?	
	// query the database for all cards with selected category ID
	$query = "SELECT * from $cardCatTable";


		$result = MYSQL_QUERY($query);
		$number = MYSQL_NUMROWS($result);
		$i=="0";

		/* If there are no matches in the DB, then return an error message */
		IF ($number==$i):
		print "$NoMatchesTxt</TD></TR>";
		include "../phpCards.footer.php";
		exit;
		
		ELSE:	
		?>
		<h3>Categories: <?php echo "$row[6]"; ?></h3></td></tr>
		
		 &nbsp;</TD></TR>
		 <TR><TD><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3">
		 <UL>
		 <?php
		while  ($row  =  mysql_fetch_row($result))  {


		?>
		 <LI><a href="phpCardsChoose.php?CatID=<?php echo "$row[0]"; ?>"><?php echo "$row[1]"; ?></a> - <FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="-2">[<a href="phpCardsCatEdit.php?action=edit&CatID=<?php echo "$row[0]"; ?>"><?php echo "$AdminEditCatMsg"; ?></a>] [<a href="phpCardsCatEdit.php?action=delete&CatID=<?php echo "$row[0]"; ?>"><?php echo "$AdminDeleteCatTxt"; ?></a>]</font>
		 <?php
		} 
		?>
		<br><br><center><a href="phpCardsAdd.php"><?php echo "$AdminAddCardTxt"; ?></a> | 
		<a href="phpCardsCatEdit.php?action=add"><?php echo "$AdminAddCatTxt"; ?></a>
		</center>
		 </FONT></TD></TR> 
		 <?php 


 	
		ENDIF;
		?>
		</TABLE>
		</FORM>
		<BR><BR>
	
	
	</FONT></TD>
</TR>

<?php
include "$CardPath"."phpCards.footer.php";
?>