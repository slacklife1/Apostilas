<?php
include "../phpCards.header.php";
?>

	<TR>
	<TD ALIGN="CENTER" COLSPAN="2"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><B><?php echo "$AdminSelectMsg"; ?></B><BR><?php echo "$EnlargeMsg"; ?></FONT></TD>
	</TR>
	<TR>
	<form method=post action="phpCardsEdit.php">
	<TD ALIGN="CENTER" COLSPAN="2"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3">
	<?	
	// query the database for all cards with selected category ID
	$query = "SELECT * from $cardInfoTable WHERE CardCategory='$CatID'";


		$result = MYSQL_QUERY($query);
		$number = MYSQL_NUMROWS($result);
		$i=="0";

		/* If there are no matches in the DB, then return an error message */
		IF ($number==$i):
		print "Sorry, there are no cards in the database.</TD></TR>";
		include "../phpCards.footer.php";
		exit;
		
		ELSE:	
		?>
		<h3>Cards in Category: <?php echo "$row[6]"; ?></h3></td></tr>
		<?php
		while  ($row  =  mysql_fetch_row($result))  {

		// gets the mage size so that the thumbnails and full size images 
		// will have their sizes dynamically created in the IMG tag
		$ThumbSize = GetImageSize ("../"."$CardRelURL"."$row[3]");
		$FullSize = GetImageSize ("../"."$CardRelURL"."$row[2]");
		?>
		 &nbsp;</TD></TR>
		 <TR><TD ALIGN="CENTER"><a href='javascript:openPopWin("<?php echo "$CardImageURL"; ?><?php echo "$row[2]"; ?>", <?php echo $FullSize[0]; ?>, <?php echo $FullSize[1]; ?>, "", 1, 1)'><IMG SRC="<?php echo "$CardImageURL"; ?><?php echo "$row[3]"; ?>" <?php echo $ThumbSize[3]; ?> BORDER="0" ALT=""></A></TD><TD VALIGN="TOP"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><b><?php echo "$MessageTxt"; ?>:</b><br>&quot;<?php echo "$row[4]"; ?>&quot;<br><br><br><input type="radio" name="SelectedCard" VALUE="<?php echo "$row[0]"; ?>"><?php echo "$SelectCardTxt"; ?><br>
		 <div align="right"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="-2"><a href="phpCardsDelete.php?ImageID=<?php echo "$row[0]"; ?>&action=delete"><?php echo "$AdminDeleteCardTxt"; ?></a></font></div>
		 </FONT></TD></TR> 
		 <?php 


		}  	
		ENDIF;
		?>
		<tr><td colspan="2" align="center"><input type="submit" name="action" value="Next"></td></tr>
		</TABLE>
		</FORM>
		<BR><BR>
	
	
	</FONT></TD>
	</form>
</TR>

<?php
include "../phpCards.footer.php";
?>