<?php
include "phpCards.header.php";

srand((double)microtime()*1000000);
$randval = rand();
$gdate=date("M d, Y"); 

?>

	<TR>
	<TD ALIGN="CENTER"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><B><?php echo "$SentMsg"; ?></B></FONT>
	<?	
	// insert info into card user database
	$query = "INSERT into $cardUserTable VALUES	('$gdate','$SendName','$SendEmail','$RecName','$RecEmail','$CardHeader','$CardMessage','$randval','$CardImage','0')";
	$result = MYSQL_QUERY($query);

// send mail to the recipient notifying tem of the card that s waiting for them
mail("$RecEmail", "$SendName has sent you a Virtual Card from $SiteName", "Dear $RecName, 
$SendName went to $SiteName and has sent you a virtual greeting card!  To pickup your card, just click on the URL below:

$ProgURL/phpCardsPickup.php?MessageID=$randval
	
$SiteName
$SiteTag
$SiteURL","FROM:$AdminAddress");


		?>
		 &nbsp;<br><br>
		<FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><a href="<?php echo "$ProgURL"; ?>">Send Another Virtual Card</a></font> </TD></TR>
		</TABLE>
				<BR><BR>
	
	
	</FONT></TD>
	</form>
</TR>

<?php
include "phpCards.footer.php";
?>