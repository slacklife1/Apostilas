<?php
include "phpCards.header.php";

// begin errorchecking
IF ($CardMessage==""):
?><TR>
	<TD ALIGN="CENTER"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><B><?php echo "$MessageErrorMsg"; ?></B><br><form><input type="button" onclick="button('javascript:history.back(1)')" value="<?php echo "$BackTxt"; ?>"></form></FONT>
   &nbsp;</TD></TR>
<?
include "phpCards.footer.php";
exit;
ELSEIF ($SendName==""):
?><TR>
	<TD ALIGN="CENTER"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><B><?php echo "$SendNameErrorMsg"; ?></B><br><form><input type="button" onclick="button('javascript:history.back(1)')" value="<?php echo "$BackTxt"; ?>"></form></FONT>
   &nbsp;</TD></TR>
<?
include "phpCards.footer.php";
exit;
ELSEIF ($SendEmail==""):
?><TR>
	<TD ALIGN="CENTER"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><B><?php echo "$SendEmailErrorMsg"; ?></B><br><form><input type="button" onclick="button('javascript:history.back(1)')" value="<?php echo "$BackTxt"; ?>"></form></FONT>
   &nbsp;</TD></TR>
<?
include "phpCards.footer.php";
exit;
ELSEIF ($RecName==""):
?><TR>
	<TD ALIGN="CENTER"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><B><?php echo "$RecNameErrorMsg"; ?></B><br><form><input type="button" onclick="button('javascript:history.back(1)')" value="<?php echo "$BackTxt"; ?>"></form></FONT>
   &nbsp;</TD></TR>
<?
include "phpCards.footer.php";
exit;
ELSEIF ($RecEmail==""):
?><TR>
	<TD ALIGN="CENTER"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><B><?php echo "$RecEmailErrorMsg"; ?></B><br><form><input type="button" onclick="button('javascript:history.back(1)')" value="<?php echo "$BackTxt"; ?>"></form></FONT>
   &nbsp;</TD></TR>
<?
ELSE:
?>

	<TR><form method=post action="phpCardsSend.php">
	<TD ALIGN="CENTER"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><B><?php echo "$PreviewMsg"; ?></B></FONT>
   &nbsp;</TD></TR>
		 <TR><TD ALIGN="CENTER"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><b>&quot;<?php echo "$CardHeader"; ?>&quot;</b></font><br><IMG SRC="<?php echo "$CardImageURL"; ?><?php echo "$ImageName"; ?>" <?php echo "ImageSize"; ?> BORDER="0" ALT=""></TD></tr>
		 <tr><TD VALIGN="TOP"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3">
		 <?php echo "$DearTxt"; ?> <?php echo "$RecName"; ?>,
		 <p align="justify"><?php echo "$CardMessage"; ?></p>
		 <?php echo "$SincerelyTxt"; ?>: <a href="mailto:<?php echo "$SendEmail"; ?>"><?php echo "$SendName"; ?> </a>
		 </FONT></TD></TR> 
		 <?php 

	
		?>
		<tr><td align="center"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><b><?php echo "$SendOrChangeTxt"; ?></b></font><br>
		<table>
		<tr>
			<td><input type="submit" value="Next"><input type="hidden" name="SelectedCard" value="<?php echo "$SelectedCard"; ?>">
		<input type="hidden" name="RecName" value="<?php echo "$RecName"; ?>">
		<input type="hidden" name="RecEmail" value="<?php echo "$RecEmail"; ?>">
		<input type="hidden" name="SendName" value="<?php echo "$SendName"; ?>">
		<input type="hidden" name="SendEmail" value="<?php echo "$SendEmail"; ?>">
		<input type="hidden" name="CardMessage" value="<?php echo "$CardMessage"; ?>">
		<input type="hidden" name="CardHeader" value="<?php echo "$CardHeader"; ?>">
		<input type="hidden" name="CardImage" value="<?php echo "$ImageName"; ?>">
		</td></FORM><form><td><input type="button" onclick="button('javascript:history.back(1)')" value="Back">
		</tr></form>
		</table></td></tr>
		</TABLE>
	
		<BR><BR>
	
	
	</FONT></TD>
	</form>
</TR>

<?php
ENDIF;
include "phpCards.footer.php";
?>