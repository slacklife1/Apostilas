<?php
include "phpCards.header.php";
$query = "SELECT * from $cardUserTable WHERE MessageID='$MessageID'";
$result = MYSQL_QUERY($query);
$number = MYSQL_NUMROWS($result);
$i=="0";

// If there are no matches in the DB, then return an error message 
IF ($number==$i):
print "$WrongIDTxt</TD></TR>";
include "phpCards.footer.php";
exit;

ELSE:
while  ($row  =  mysql_fetch_row($result))  {
$FullSize = GetImageSize ("$CardRelURL"."$row[8]");
?>

	<TR>
	<TD ALIGN="CENTER"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><B><?php echo "$PickupMsg"; ?></B></FONT>
   &nbsp;</TD></TR>
		 <TR><TD ALIGN="CENTER"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><b>&quot;<?php echo "$row[5]"; ?>&quot;</b></font><br><IMG SRC="<?php echo "$CardImageURL"; ?><?php echo "$row[8]"; ?>" width="<?php echo $FullSize[0]; ?>" height="<?php echo $FullSize[1]; ?>" BORDER="0" ALT=""></TD></tr>
		 <tr><TD VALIGN="TOP"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3">
		 <?php echo "$DearTxt"; ?> <?php echo "$row[3]"; ?>,
		 <p align="justify"><?php echo "$row[6]"; ?></p>
		 <?php echo "$SincerelyTxt"; ?>: <a href="mailto:<?php echo "$row[2]"; ?>"><?php echo "$row[1]"; ?> </a>
		 </FONT></TD></TR> 
		 <?php 

	
		?>
		<tr><td align="center">
		<FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><b><?php echo "$SendReplyTxt"; ?></b></font><br>
		</td></tr>
		</TABLE>
		
	
		
		<BR><BR>
<?php
IF ($row[9]=="0"):
$pickupdate=date("M d, Y"); 
mail("$row[2]", "$row[3] has picked up your Virtual Card from $SiteName", "Dear $row[1], 
$row[3] picked up your greeting card from $SiteName on $pickupdate.  Thank you for using $SiteName!

$SiteName
$SiteTag
$SiteURL","FROM:$AdminAddress");
ENDIF;
}

$query = "UPDATE $cardUserTable SET  HaveRead = '1' WHERE MessageID='$MessageID'";
$result = MYSQL_QUERY($query);
?>	
	
	</FONT></TD>
	</form>
</TR>

<?php
ENDIF;
include "phpCards.footer.php";
?>