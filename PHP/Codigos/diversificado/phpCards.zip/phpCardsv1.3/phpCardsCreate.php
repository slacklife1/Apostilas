<?php
include "phpCards.header.php";
?>

	<TR><form method=post action="phpCardsPreview.php">
	<TD ALIGN="CENTER"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><B><?php echo "$EnterMsg"; ?></B></FONT>
	<?	
	// query the database for all cards with selected category ID
	$query = "SELECT * from $cardInfoTable WHERE imageID='$SelectedCard'";


		$result = MYSQL_QUERY($query);
		$number = MYSQL_NUMROWS($result);
		$i=="0";

		/* If there are no matches in the DB, then return an error message */
		IF ($number==$i):
		print "<br><br>$ChooseCardTxt<br><br><form><input type=\"button\" onclick=\"button('javascript:history.back(1)')\" value=\"$BackTxt\"></form></TD></TR>";
		include "phpCards.footer.php";
		exit;
		
		ELSE:	
		?>
		<?php
		 while  ($row  =  mysql_fetch_row($result))  {

		// gets the mage size so that the thumbnails and full size images 
		// will have their sizes dynamically created in the IMG tag
		$FullSize = GetImageSize ("$CardRelURL"."$row[2]");
		?>
		 &nbsp;</TD></TR>
		 <TR><TD ALIGN="CENTER"><IMG SRC="<?php echo "$CardImageURL"; ?><?php echo "$row[2]"; ?>" <?php echo $FullSize[3]; ?> BORDER="0" ALT=""></TD></tr>
		 <tr><TD VALIGN="TOP"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><b><?php echo "$MessageTxt"; ?>:</b><br><textarea name="CardHeader" rows="2" cols="25" wrap="virtual"><?php echo "$row[4]"; ?></textarea><br>
		 <br><b><?php echo "$UserMessageTxt"; ?>:</b><br><textarea name="CardMessage" rows="4" cols="25" wrap="virtual"></textarea><br>
		 <br>
		<b>*<?php echo "$SenderNameTxt"; ?>:</b><br>
		<input type="text" name="SendName">
		<br>
		<br>
		<b>*<?php echo "$SenderEmailTxt"; ?>:</b><br>
		<input type="text" name="SendEmail">
		<br>
		<br>
		<b>*<?php echo "$RecNameTxt"; ?>:</b><br>
		<input type="text" name="RecName">
		<br>
		<br>
		<b>*<?php echo "$RecEmailTxt"; ?>:</b><br>
		<input type="text" name="RecEmail">
		<input type="hidden" name="ImageName" value="<?php echo "$row[2]"; ?>">
		<input type="hidden" name="SelectedCard" value="<?php echo "$SelectedCard"; ?>">
		 </FONT></TD></TR> 
		 
		 <?php 

		}
		
		ENDIF;
		?>
		<tr><td align="center">
		
		<input type="hidden" name="ImageSize" value='<?php echo $FullSize[3]; ?>'>
		<FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3">* <?php echo "$RequiredTxt"; ?></font><br><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="-1"><input type="submit" value="Next"></font></td></tr>
		</TABLE>
		</FORM>
		<BR><BR>
	
	
	</FONT></TD>
	</form>
</TR>

<?php
include "phpCards.footer.php";
?>