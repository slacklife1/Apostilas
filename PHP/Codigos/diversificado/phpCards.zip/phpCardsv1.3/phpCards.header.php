<?php
$CardPath = "/usr/home/snipe.net/html/phpCards1.3/";
include "$CardPath"."phpCards.Config.php";
include "$CardPath"."lang/"."$CardLanguageFile";
?>
<HTML>
<HEAD>
<TITLE><?php echo "$SiteName"; ?> - <?php echo "$CardProgramName"; ?></TITLE>
<SCRIPT Language="JavaScript">

  
<!--   
var popWin = null    
var winCount = 0 
var winName = "popWin" 
function openPopWin(winURL, winWidth, winHeight, winFeatures, winLeft, winTop){ 
  var d_winLeft = 20  
  var d_winTop = 20   
  winName = "popWin" + winCount++  
  closePopWin()           
  if (openPopWin.arguments.length >= 4)    
    winFeatures = "," + winFeatures 
  else  
    winFeatures = ""  
  if (openPopWin.arguments.length == 6)   
    winFeatures += getLocation(winWidth, winHeight, winLeft, winTop) 
  else 
    winFeatures += getLocation(winWidth, winHeight, d_winLeft, d_winTop) 
  popWin = window.open(winURL, winName, "width=" + winWidth  
           + ",height=" + winHeight + winFeatures) 
  } 
function closePopWin(){     
  if (navigator.appName != "Microsoft Internet Explorer"  
      || parseInt(navigator.appVersion) >=4)  
    if(popWin != null) if(!popWin.closed) popWin.close()  
  } 
function getLocation(winWidth, winHeight, winLeft, winTop){ 
  return "" 
  } 

  // back button script
function button(location) {
top.location = location
}
//-->
</SCRIPT> 
</HEAD>

<BODY BGCOLOR="#FFFFFF" LINK="#646464" ALINK="#FFA346" VLINK="#646464">
<FONT FACE="<?php echo "$CardFontFace"; ?>">
<H3><?php echo "$CardProgramName"; ?></H3>
<center>
<TABLE BGCOLOR="<?php echo "$CardTableColor"; ?>" WIDTH="<?php echo "$CardTableWidth"; ?>" BORDER="0" cellspacing="0" cellpadding="5">