phpCards v1.3 
Created: 9/7/00
UPDATED: 9/12/00
--------------------------------------------------------------------
| phpCards v1.3 was written and designed by A. Gianotto.            |
| This is the third release of the software, and I do anticpate     |
| more changes coming fairly soon.                                  |
| ------------------------------------------------------------------|
| This software is free                                             |
| for personal and commercial use, as long as the HTML comment tags |
| containing the credits remains intact.  To report bugs, find out  |
| if an upgrade has been released, or for installation support, you |
| can e-mail snipe@snipe.net.                                       |
| ------------------------------------------------------------------|
| You may NOT, however, UNDER ANY CIRCUMSTANCES, include this       |
| in a collection which will be sold for any profit without         |
| consulting me first.  Free collections are alright as long as due |
| credit is given.                                                  |
| ------------------------------------------------------------------|
| When e-mailing, please specify the script you are using (in this  |
| case phpCards v1.3), and the specific problems or error           |
| messages you are receiving.  I am NOT a mind reader, so it's the  |
| ONLY way I will even attempt to help you!                         |
|                                                                   |
| If you make any improvements to this script, please let me know!  |
| I'm always interested in peeking at other people's code,          |
| especially if it's better than mine!                              |
|                                                                   |
| One final shameless plug: feel free to stop by my website, at     |
| www.snipe.net.  There are humourous articles, tech tips, graphics |
| tutorials, and more, so poke around a bit.  Who knows... Maybe    |
| I'll add some PHP or mySQL tutorials up there!  :-)               |
--------------------------------------------------------------------
--------------------------------------------------------------------
DEMO:
--------------------------------------------------------------------
You can find a demo of this software here:
http://www.snipe.net/phpCards1.3/index.php

Admin:
http://www.snipe.net/phpCards1.3/admin/index.php
--------------------------------------------------------------------
FEATURE LIST:
--------------------------------------------------------------------
This is a postcard script with a web based admin for easy maintenance.  

USER INTERFACE-
--------------------------------------------------------------------
1.  Multiple (unlimited) categories for cards
2.  Default text comes with each card but can be edited by the user if they want
3.  Sends an email with their pickup URL
4.  Sends an email to the sender when the user picks it up.  This only happens ONCE 
    so that if the recipient goes back several times to look at it, the sender 
    will not get spammed
5.  Full-size preview of the image pops up in javascript window
6.  Card Preview
7.  Error checking on required fields

ADMIN INTERFACE -
--------------------------------------------------------------------
1. Ability to add new cards, edit the full size and thumbnail images as well as default
   text and category on existing cards, and delete cards
2. Ability to add, edit, and delete categories

BEHIND THE SCENES-
--------------------------------------------------------------------
1.  It utilizes a "language" file, so that every bit of text that appears in both the 
    user and admin screens can be translated in one file 
2.  All variables are in a configuration file which makes a brand new install take 
    about 20 minutes if you type slow.  Colors, database names, font face, 
    directory structure, and other important variables are all totally customizable
3.  The image/thumbnail height and width is dynamically generated, ensuring that the page
    will load nicely
4.  Highly Intuitive interface
5.  Draws from header and footer files to enable fast adapting to site-specific look and feel
6.  QuickLinking to specific Categories (ie. "http://snipe.net/phpCards/admin/phpCardsChoose.php?CatID=1")
7.  Sent card data is retained in it's own table, so that if you delete a category or
    specific card, any users who have already been sent this card but have not yet
    picked it up will still be able to retrieve their card

--------------------------------------------------------------------
INSTALLATION:
--------------------------------------------------------------------
1. Create the database tables and insert valuesas per the phpCardsSchema.sql file
2. All configuration variables are contained within the phpCards.Config.php
   with the exception of ONE in the phpCards.header.inc file. In the 
   phpCards.header.php file, you must change the very first variable ($CardPath) 
   to match the file path of your own server.

  In phpCards.Config.php, the Database Settings and the Site Variables are 
  the only things you will need to change. 
3.  Upload the images directory and chmod to 777.

--------------------------------------------------------------------
CHANGELOG:
--------------------------------------------------------------------
Version 1.2 - 9/7/00
1.  Added feature for x number of cards to display per page

Version 1.3 - 9/12/00
1.  Minor bug fixes, and SQL insert query so you don't have to manually add data 
    into the database when first installed.  
    
    Also added a french language file thanks to Matthieu, webmaster
    of http://www.web-pratique.com.
2.  Added row count on main page so users can see how many cards are in the database in
    total, and then also for each subsection.

--------------------------------------------------------------------
UPGRADE INSTALL:
--------------------------------------------------------------------
The upgrade should be pretty easy.  Upload the following files from the newer version:

1.  phpCardsPreview.php
2.  phpCardsPickup.php
3.  phpCardsChoose.php
4.  phpCards.footer.php
5.  index.php
6.  phpCardsCreate.php

If you do not want to re-edit the configuration file again, simply add 
this variable anywhere to the phpCards.Config.php file:

$per_page = 2; // how many cards should display on each page

That will allow you to specify how many cards should appear on each page.

--------------------------------------------------------------------
TO DO:
--------------------------------------------------------------------
1.  Some sort of garbage collection for old postcards
2.  Deleting images from server to save space - (we couldn't do that 
    this time around because if we deleted an image and then a user tried to 
    retrieve it, the image on their card would come up broken.
3.  Additional language files
4.  Adding the very few remaining hardcoded text segments into the language files



