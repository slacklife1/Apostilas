</TABLE>
</FONT>
<FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="-2" color="#959595">phpCards v1.3.  Report any bugs to <a href="mailto:<?php echo "$AdminAddress"; ?>"><?php echo "$AdminAddress"; ?></a>.  Click <a href="<?php echo "$ProgURL"; ?>/README.txt">here</a> to see the install and feature list. Developed by <A HREF="mailto:snipe@snipe.net">A Gianotto</A> of <A HREF="http://www.snipe.net">Snipe.Net</A>.</font>
</center>
</BODY>
</HTML>
