<?php
include "phpCards.header.php";
?>

	<TR>
	<TD ALIGN="CENTER" COLSPAN="2"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><B><?php echo "$SelectMsg"; ?></B><BR><?php echo "$EnlargeMsg"; ?></FONT></TD>
	</TR>
	<TR>
	<form method=post action="phpCardsCreate.php">
	<TD ALIGN="CENTER" COLSPAN="2"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3">
	<?	
$query = ("SELECT * from $cardInfoTable WHERE CardCategory='$CatID'");


// Set page #, if no page isspecified, assume page 1  
if (!$page) {  
   $page = 1;  
}  
$prev_page = $page - 1;  
$next_page = $page + 1;  

// Set up specified page  
$page_start = ($per_page * $page) - $per_page; 
// query the database for all cards with selected category ID
$result = mysql_query($query);
$num_rows = mysql_num_rows($result);  



if ($num_rows <= $per_page) {  
   $num_pages = 1;  
} else if (($num_rows % $per_page) == 0) {  
   $num_pages = ($num_rows / $per_page);  
} else {  
   $num_pages = ($num_rows / $per_page) + 1;  
}  
$num_pages = (int) $num_pages;  

if (($page > $num_pages) || ($page < 0)) {  
   error("You have specified an invalid page number");  
}  
		
$query = $query . " LIMIT $page_start, $per_page";  
$result = mysql_query($query); 
$i=="0";		
		/* If there are no matches in the DB, then return an error message */
		IF ($num_rows==$i):
		print "Sorry, there are no cards in the database.</TD></TR>";
		include "phpCards.footer.php";
		exit;
		
		ELSE:
		?>
		<FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="4"><b>There are <? echo "$num_rows"; ?> Cards in Category: <?php echo "$CatName"; ?></b></font></td></tr>
		<?php
		while ($row = mysql_fetch_array($result)) {  

		// gets the mage size so that the thumbnails and full size images 
		// will have their sizes dynamically created in the IMG tag
		$ThumbSize = GetImageSize ("$CardRelURL"."$row[CardThumb]");
		$FullSize = GetImageSize ("$CardRelURL"."$row[CardImage]");
		?>
		 &nbsp;</TD></TR>
		 <TR><TD ALIGN="CENTER"><a href='javascript:openPopWin("<?php echo "$CardImageURL"; ?><?php echo "$row[CardImage]"; ?>", <?php echo $FullSize[0]; ?>, <?php echo $FullSize[1]; ?>, "", 1, 1)'><IMG SRC="<?php echo "$CardImageURL"; ?><?php echo "$row[CardThumb]"; ?>" <?php echo $ThumbSize[3]; ?> BORDER="0" ALT=""></A></TD><TD VALIGN="TOP"><FONT FACE="<?php echo "$CardFontFace"; ?>" SIZE="3"><b><?php echo "$MessageTxt"; ?>:</b><br>&quot;<?php echo "$row[DefaultMsg]"; ?>&quot;<br><br><br><input type="radio" name="SelectedCard" VALUE="<?php echo "$row[imageID]"; ?>"><?php echo "$SelectCardTxt"; ?>
		 </FONT></TD></TR> 
		 <?php 


		}  	
		ENDIF;
		?>
		<tr><td colspan="2" align="center"><input type="submit" name="action" value="Create Card">
		<br>
		<br>
		<?php
		// Previous  
if ($prev_page)  { 
   echo "<B><a href=\"$PHP_SELF?page=$prev_page&CatID=$CatID\">&lt;&nbsp;Prev</a></B>";  
} 

// Page # direct links  
// If you don't want direct links to each page, you should be able to 
// safely remove this chunk. 
for ($i = 1; $i <= $num_pages; $i++) {  
   if ($i != $page) {  
      echo " <B><a href=$PHP_SELF?page=$i&CatID=$CatID>$i</a></B>";  
   } else {  
      echo "<br>Page ". "$i". " of "."$num_pages<br>";  
   }  
}  

// Next  
if ($page != $num_pages) {  
   echo "&nbsp;<B><a href=\"$PHP_SELF?page=$next_page&CatID=$CatID\">Next&nbsp;&gt;</a></B>" ; 
} 

		
		?>
		<BR>
		<BR>
		<A HREF="index.php"><?php echo "$BackTxt"; ?></A></td></tr>
		</TABLE>
		</FORM>

		<BR><BR>
	
	
	</FONT></TD>
	</form>
</TR>

<?php
include "phpCards.footer.php";
?>