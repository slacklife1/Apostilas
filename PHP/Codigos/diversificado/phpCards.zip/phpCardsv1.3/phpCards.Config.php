<?
//**********************************************//
// File name: phpCardsConfig.php
// Version: 1.3
// Date Created: 9/6/00
// Date Updated: 9/12/00
// Author: A. Gianotto
// Email: snipe@snipe.net
// User Demo: http://www.snipe.net/phpCards
//
//
//**********************************************//
// Database Variables:
//**********************************************//

$hostname = "localhost";  // database host
$dbUser = "yourdbuser";  //database username
$dbPass = "yourpass";  //database password
$dbName = "yourdbname";  // database name
$cardInfoTable = "phpCardData";  //card data table name
$cardCatTable = "phpCatData";  //card category table name
$cardUserTable = "phpCardUsers";  //card user table name


//**********************************************//
// Site Variables:
//**********************************************//

$CardLanguageFile ="eng.lang.php";  // determines what language include file to use
$CardImageURL = "http://www.your-site.com/phpCards/images/";  //with trailing slash
$CardRelURL = "images/";
$CardPicPath = "/usr/home/your-site.com/html/phpCards/images"; // no trailing slash
$AdminAddress = "snipe@your-site.com";
$SiteName = "your-site.com";
$SiteURL = "http://www.your-site.com";
$SiteTag = "";  // site tagline for email messages
$ProgURL = "http://www.your-site.com/phpCards"; // no trailing slash
$CardProgramName = "Virtual Postcards";
$CardFontFace = "Arial, Helvetica, verdana, ms sans serif";
$CardTableColor = "#FFCC99"; // main table background color
$CardTableWidth = "410"; // table with in pixels
$per_page = 2; // how many cards should display on each page


//**********************************************//
// Special Characters Handling - Do NOT EDIT:
//**********************************************//

$CardMessage = stripslashes($CardMessage); // to remove any slashes caused by magic quotes 
$CardMessage = eregi_replace( "'", "&#39;", $CardMessage); //to change the ' to be displayed via html asciicode 
$CardMessage = eregi_replace( '"', "&quot;", $CardMessage); 

$CardHeader = stripslashes($CardHeader); // to remove any slashes caused by magic quotes 
$CardHeader = eregi_replace( "'", "&#39;", $CardHeader); //to change the ' to be displayed via html asciicode 
$CardHeader = eregi_replace( '"', "&quot;", $CardHeader); 

//**********************************************//
// Database Query:
//**********************************************//
MYSQL_CONNECT($hostname,$dbUser,$dbPass) OR DIE("Unable to connect to database");
@mysql_select_db( "$dbName") or die( "Uhhh.. negatory!!  Unable to select database $query. $dbName"); 

?>
