<?
$SelectCatMsg = "W�hle eine Kategorie aus";
$SelectMsg = "W�hle bitte ein Bild aus";
$EnlargeMsg = "Klicke auf das Bild, um es als Vollbild zu sehen";
$MessageTxt = "Bild�berschrift";
$SelectCardTxt = "W�hle diese Karte aus";
$EnterMsg = "F�lle Deine Karte aus";
$UserMessageTxt = "Deine Nachricht";
$SenderNameTxt = "Dein Name";
$SenderEmailTxt = "Deine eMail-Adresse";
$RecNameTxt = "Empf�nger-Name";
$RecEmailTxt = "Empf�nger-eMail";
$RequiredTxt = "Diese Felder m�ssen ausgef�llt werden";
$PreviewMsg = "So sieht Deine Karte aus";
// database error messages
$WrongIDTxt = "Entschuldigung, unter dieser Adresse gibt es keine Karte. Bist Du sicher, dass Du die richtige Adresse in den Browser kopiert hast?";
$NoMatchesTxt = "Enschuldigung, es sind keine Karten in der Datenbank.";
$ChooseCardTxt = "Entschuldigung, Du musst eine Karte ausw�hlen. Benutze den Zur�ck-Button und w�hle eine Karte aus.";
$DearTxt = "Liebe(r)";
$SincerelyTxt = "Von";
$SendOrChangeTxt = "Wenn Du mit Deiner Karte zufrieden bist, benutze den NEXT-Button.  Anderenfalls klicke auf den Zur�ck-Button und �ndere die Karte.";
$BackTxt = "zur�ck";
// error messages
$MessageErrorMsg = "Gehe zur�ck und trage eine Nachricht ein";
$SendNameErrorMsg = "Gehe zur�ck und trage Deinen Namen ein";
$SendEmailErrorMsg = "Gehe zur�ck und trage Deine eMail-Adresse ein";
$RecNameErrorMsg = "Gehe zur�ck und trage den Namen des Empf�ngers ein";
$RecEmailErrorMsg = "Gehe zur�ck und trage die eMail-Adresse des Empf�ngers ein";
$SentMsg = "Die Nachricht wurde gesendet";
$PickupMsg = "Das ist Deine Karte";
$SendReplyTxt = "Klicke <A HREF='"."$ProgURL"."'>hier</a> um Gr��e zur�ckzusenden";
// Admin messages
$AdminSelectCatMsg = "ADMIN: W�hle die Karten-Kategorie aus, die Du �ndern m�chtest oder Klicke auf den Link, um eine neue Kategorie zu erstellen.";
$AdminSelectMsg = "ADMIN: W�hle die Karte aus, die Du �ndern m�chtest";
$AdminEditMsg = "ADMIN:  �ndere das Vollbild, das Vorschaubild und/oder den Bildtext";
$AdminCatUpdateTxt = "Update Kategorie";
$AdminDoNotChange = "Nicht �ndern";
$AdminNewTxt = "ADMIN: Die neue Karte wurde hinzugef�gt";
$AdminDeleteCardTxt = "Delete Card";
$AdminConfirmDeleteCardTxt = "ADMIN: Bist Du sicher, dass Du diese Karte l�schen m�chtest?";
$AdminEditCatMsg = "Kategorie bearbeiten";
$AdminConfirmDeleteCatTxt = "Bist Du sicher, dass Du diese Kategorie l�schen m�chtest?";
$AdminAddCatTxt = "Neue Kategorie hinzuf�gen";
$AdminConfirmAdd = "Die neue Kategorie wurde hinzugef�gt";
$AdminEditCatTxt = "Kategorie-Bezeichnung";
$AdminDeleteCatTxt = "L�schen";
$AdminConfirmEdit = "Der Kategorie-Name wurde ge�ndert";
$AdminConfirmCatDeleteMsg = "Die Kategorie wurde erfolgreich gel�scht";
$CategoryNameTxt = "Kategorie-Name";
$NewCategoryNameTxt = "Neue Kategorie";
$AdminAddCardTxt = "Neue Karte hinzuf�gen";

?>