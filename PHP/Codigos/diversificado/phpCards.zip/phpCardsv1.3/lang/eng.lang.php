<?
$SelectCatMsg = "Select a Category of cards you wish to view";
$SelectMsg = "Please Select an Image to Send Below";
$EnlargeMsg = "Click on the image to see the full size view";
$MessageTxt = "Message";
$SelectCardTxt = "Select This Card";
$EnterMsg = "Customize Your Card Below";
$UserMessageTxt = "Your Message";
$SenderNameTxt = "Your Name";
$SenderEmailTxt = "Your Email Address";
$RecNameTxt = "Recipient's Name";
$RecEmailTxt = "Recipient's Email";
$RequiredTxt = "Indicates A Required Field";
$PreviewMsg = "Below is your Card as It Will Appear";
// database error messages
$WrongIDTxt = "Sorry, there are no cards in the database that match that ID number.  Please be sure you have copied the entire URL into the browser window";
$NoMatchesTxt = "Sorry, there are no cards in the database.";
$ChooseCardTxt = "Sorry, you must choose a card in order to proceed.  Please use the back button and choose a card.";
$DearTxt = "Dear";
$SincerelyTxt = "From";
$SendOrChangeTxt = "If you are happy with your card the way it is, click the Next button.  Otherwise, click on the Back button and make the necessary changes.";
$BackTxt = "Back";
// error messages
$MessageErrorMsg = "Please go back and enter a message";
$SendNameErrorMsg = "Please go back and enter your name";
$SendEmailErrorMsg = "Please go back and enter your email address";
$RecNameErrorMsg = "Please go back and enter the name of the person you are sending this card to";
$RecEmailErrorMsg = "Please go back and enter the recipient's email address";
$SentMsg = "Your Message Has Been Sent";
$PickupMsg = "Pick Up Your Virtual Greeting Card";
$SendReplyTxt = "Click <A HREF='"."$ProgURL"."'>here</a> to send a reply greeting";
// Admin messages
$AdminSelectCatMsg = "ADMIN: Select the category of the card you wish to edit, or click on the link to create a new category";
$AdminSelectMsg = "ADMIN: Select the card you wish to edit";
$AdminEditMsg = "ADMIN:  Edit the full size image, thumbnail, and/or default message below";
$AdminCatUpdateTxt = "Update Category";
$AdminDoNotChange = "Do Not Change";
$AdminNewTxt = "ADMIN: Your New Card Has Been Added";
$AdminDeleteCardTxt = "Delete Card";
$AdminConfirmDeleteCardTxt = "ADMIN: Are you sure you want to delete this card?";
$AdminEditCatMsg = "Edit Category";
$AdminConfirmDeleteCatTxt = "Are you sure you wish to delete this category?";
$AdminAddCatTxt = "Add New Category";
$AdminConfirmAdd = "Your category has been added";
$AdminEditCatTxt = "Edit Category Info";
$AdminDeleteCatTxt = "Delete";
$AdminConfirmEdit = "Your category name has been successfully changed";
$AdminConfirmCatDeleteMsg = "Your category name has been successfully deleted";
$CategoryNameTxt = "Category Name";
$NewCategoryNameTxt = "New Category Name";
$AdminAddCardTxt = "Add A New Card";

?>