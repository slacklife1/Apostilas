<?php
$SelectCatMsg = "Seleccione la categoria de tarjetas que usted desea ver";
$SelectMsg = "Por favor, selecione para env&iacute;o una de las im&aacute;genes abajo";
$EnlargeMsg = "Hava clic en la im&aacute;gen para verla en tama&ntilde;o normal";
$MessageTxt = "Mensaje";
$SelectCardTxt = "Seleccionar esta tarjeta";
$EnterMsg = "Modifique su tarjeta";
$UserMessageTxt = "Su Mensaje";
$SenderNameTxt = "Su Nombre";
$SenderEmailTxt = "Su Direcci&oacute;n de Correo Electr&oacute;nico (email)";
$RecNameTxt = "Nobre del Recipiente";
$RecEmailTxt = "Correo Eletr&oacute;nico (email) del Recipiente";
$RequiredTxt = "Indica que es un campo requerido";
$PreviewMsg = "Abajo se muestra su tarjeta como aparacer&aacute;";
// mensajes de error de la base de datos
$WrongIDTxt = "Lo siento, no hay tarjetas en la base de datos que coincidan con ese n&uacute;mero de ID. Por favor, revise que haya copiado la URL completa en la ventana del navegador de Web"; 
$NoMatchesTxt = "Lo siento, no hay tarjetas en la base de datos";
$ChooseCardTxt = "Lo siento, debe de elegir una tarjeta para poder seguir. Por favor, use el boton de regreso para seleccionar una de las tarjetas";
$DearTxt = "Estimado(a)";
$SincerelyTxt = "De";
$SendOrChangeTxt = "Si esta contento con la tarjeta que ha creado, hava clic
en el boton Continuar, de otro modo haga clic en Regresar para hacer los cambies que crea necesarios";
$BackTxt = "Regreso";
// mensajes de error
$MessageErrorMsg = "Por favor, regrese a la p&acute; anterior e ingrese un mensaje"; 
$SendNameErrorMsg = "Por favor, regrese a la p&acute; anterior e ingrese su nombre";
$SendEmailErrorMsg = "Por favor, regrese a la p&acute; anterior e ingrese su direcci&oacute;n de correo electr&oacuote;nico (email)";
$RecNameErrorMsg = "Por favor, regrese a la p&acute; anterior e ingrese el nombre del recipiente de esta tarjeta";
$RecEmailErrorMsg = "Por favor, regrese a la p&acute; anterior e ingrese la direcci&oacute;n de correo electr&oacuote;nico (email) del recipiente de esta tarjeta";
$SentMsg = "Su Mensaje Has Sido Enviado";
$PickupMsg = "Recoja Su Tarjete de Saludos Virtual";
$SendReplyTxt = "Haga clic <a href='".$ProgURL."'>aqu&iacute;</a> para enviar un saludo de respuesta";
// mensajes de administracion
$AdminSelectCatMsg = "ADMINISTRACION: Seleccione la categoria de la tarjeta que quiere editar, o haga clic en el enlaze para creau una nueva categoria";
$AdminSelectMsg = "ADMINISTRACION: Seleccione la tarjeta que quiere editar";
$AdminEditMsg = "ADMINISTRACION:  Edite la imag&eacute; de tama&ntilde;o normal, m&iacute;nima, y/o el mensaje por defecto";
$AdminCatUpdateTxt = "Acutalize la categoria";
$AdminDoNotChange = "No hacer cambios";
$AdminNewTxt = "ADMINISTRACION: Su nueva tarjeta a sido a&ntilde;adida";
$AdminDeleteCardTxt = "Remover Tarjeta";
$AdminConfirmDeleteCardTxt = "ADMINISTRACION: &lquest;Esta seguro que desea remover esta tarjeta?";
$AdminEditCatMsg = "Editar la Categoria";
$AdminConfirmDeleteCatTxt = "&lquest;Esta seguro que desea remover esta categoria?Are you sure you wish to delete this category?";
$AdminAddCatTxt = "A&ntilde;adir Nueva Categoria";
$AdminConfirmAdd = "Su Categoria Ha Sido A&ntilde;adida";
$AdminEditCatTxt = "Editar Informaci&oacute;n De Esta Categoria";
$AdminDeleteCatTxt = "Remover";
$AdminConfirmEdit = "El nombre de su categoria ha sido cambiado";
$AdminConfirmCatDeleteMsg = "Su categoria has sido removida";
$CategoryNameTxt = "Nombre de la Categoria";
$NewCategoryNameTxt = "Nuevo nombre de la Categoria";
$AdminAddCardTxt = "A&ntilde;ada una nueva Tarjeta";

?>
