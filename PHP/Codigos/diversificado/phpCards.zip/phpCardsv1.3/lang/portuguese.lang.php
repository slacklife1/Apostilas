<?
$SelectCatMsg = "Seleccione a categoria de postais que deseja ver";
$SelectMsg = "Por favor escolha a imagem que deseja enviar (em baixo)";
$EnlargeMsg = "Clique na imagem para visualizar a mesma em tamanho real";
$MessageTxt = "Mensagem";
$SelectCardTxt = "Seleccionar este postal";
$EnterMsg = "Personalize o seu postal em baixo";
$UserMessageTxt = "A sua mensagem";
$SenderNameTxt = "O seu nome";
$SenderEmailTxt = "O seu endere�o de e-mail";
$RecNameTxt = "Nome do destinat�rio";
$RecEmailTxt = "E-mail do destinat�rio";
$RequiredTxt = "Indica um campo obrigat�rio";
$PreviewMsg = "O seu postal ser� visualizado da seguinte forma:";
// database error messages
$WrongIDTxt = "Pedimos desculpa, mas n�o existem registos na nossa base de dados com esse n�mero. Certifique-se que introduziu os dados correctos na janela do browser.";
$NoMatchesTxt = "Pedimos desculpa, n�o existem postais na base de dados.";
$ChooseCardTxt = "Pedimos desculpa, mas deve sellecionar um postal de modo a prosseguir.  Por favor utilize o bot�o voltar no seu browser e fa�a a escolha.";
$DearTxt = "Caro";
$SincerelyTxt = "De";
$SendOrChangeTxt = "Se est� contente com o seu postal clique em continuar.  Sen�o clique em voltar e fa�a a sua escolha.";
$BackTxt = "Voltar";
// error messages
$MessageErrorMsg = "Por favor volte atr�s e escreva uma mensagem";
$SendNameErrorMsg = "Por favor volte atr�s e introduza o seu nome.";
$SendEmailErrorMsg = "Por favor volte atr�s e introduza o seu e-mail.";
$RecNameErrorMsg = "Por favor volte atr�s e introduza o nome do destinat�rio.";
$RecEmailErrorMsg = "Por favor volte atr�s e introduza o e-mail do destinat�rio";
$SentMsg = "A sua mensagem foi enviada.";
$PickupMsg = "Recolha o seu cart�o.";
$SendReplyTxt = "Clique <A HREF='"."$ProgURL"."'>aqui</a> para enviar uma resposta de felicita��o,";
// Admin messages
$AdminSelectCatMsg = "ADMIN: Seleccione a categoria de postais que deseja editar ou clique no link para criar uma nova categoria";
$AdminSelectMsg = "ADMIN: Seleccione o postal que deseja editar";
$AdminEditMsg = "ADMIN:  Edite a imagem em corpo inteiro, pr�-visualiza��o e a mensagem";
$AdminCatUpdateTxt = "Actualizar categoria";
$AdminDoNotChange = "N�o alterar";
$AdminNewTxt = "ADMIN: O seu novo postal foi adicionado";
$AdminDeleteCardTxt = "Eliminar postal";
$AdminConfirmDeleteCardTxt = "ADMIN: Tem a certeza que deseja eliminar este postal?";
$AdminEditCatMsg = "Editar categoria";
$AdminConfirmDeleteCatTxt = "Tem a certeza que deseja eliminar esta categoria?";
$AdminAddCatTxt = "Adicionar nova categoria";
$AdminConfirmAdd = "A categoria especificada foi adicionada";
$AdminEditCatTxt = "Editar informa��o da categoria";
$AdminDeleteCatTxt = "Eliminar";
$AdminConfirmEdit = "O nome da categoria especificada foi alterada com sucesso!";
$AdminConfirmCatDeleteMsg = "A categoria especificada foi eliminada com sucesso!";
$CategoryNameTxt = "Nome da categoria";
$NewCategoryNameTxt = "Nome da nova categoria";
$AdminAddCardTxt = "Adicionar um novo postal";

?>
