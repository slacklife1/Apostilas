<?
$SelectCatMsg = "V�lj kategori av vykort du vill se";
$SelectMsg = "V�lj den bild du vill skicka nedanf�r";
$EnlargeMsg = "Klicka p� bilden f�r naturlig storlek";
$MessageTxt = "Meddelande";
$SelectCardTxt = "V�lj detta kort";
$EnterMsg = "F�r�ndra ditt kort nedanf�r";
$UserMessageTxt = "Ditt meddelande";
$SenderNameTxt = "Ditt namn";
$SenderEmailTxt = "Din E-mail adress";
$RecNameTxt = "Mottagarens namn";
$RecEmailTxt = "Mottagarens E-mail adress";
$RequiredTxt = "Ej fullst�ndigt ifyllt";
$PreviewMsg = "Nedan visas ditt vykort";
// database error messages
$WrongIDTxt = "Det finns inget vykort med detta ID nummer. Kolla om du fyllt i hela l�nken i ditt browserf�nster.";
$NoMatchesTxt = "Det finns inga kort i databasen.";
$ChooseCardTxt = "Du m�ste v�lja kort innan du kan g� vidare. Anv�nd bak�tknappen och v�lj ett kort.";
$DearTxt = "B�ste";
$SincerelyTxt = "Fr�n";
$SendOrChangeTxt = "�r du n�jd med ditt vykort klicka p� n�sta. Annars, klicka p� tillbaka och g�r dina �ndringar.";
$BackTxt = "Tillbaka";
// error messages
$MessageErrorMsg = "Tillbaka f�r att fylla i meddelande";
$SendNameErrorMsg = "Tillbaka f�r att fylla i ditt namn";
$SendEmailErrorMsg = "Tillbaka f�r att fylla i avs�ndarens email adress";
$RecNameErrorMsg = "Tillbaka f�r att fylla i namnet p� mottagaren till vykortet";
$RecEmailErrorMsg = "Tillbaka f�r att fylla i mottagarens email adress";
$SentMsg = "Ditt meddelande �r skickat";
$PickupMsg = "H�mta ditt virtuella vykort";
$SendReplyTxt = "Klicka <A HREF='"."$ProgURL"."'>h�r</a> f�r att skicka tackkort";
// Admin messages
$AdminSelectCatMsg = "ADMIN: V�lj kategori p� det kort du vill �ndra, eller klicka p� l�nken f�r att skapa en ny kategori.";
$AdminSelectMsg = "ADMIN: V�lj det kort som du vill �ndra";
$AdminEditMsg = "ADMIN:  �ndra bilderna och meddelande nedan";
$AdminCatUpdateTxt = "Uppdatera kategori";
$AdminDoNotChange = "�ndra inte";
$AdminNewTxt = "ADMIN: Kortet inlagt";
$AdminDeleteCardTxt = "Ta bort kort";
$AdminConfirmDeleteCardTxt = "ADMIN: Vill du verkligen ta bort kortet?";
$AdminEditCatMsg = "�ndra kategori";
$AdminConfirmDeleteCatTxt = "Vill du verkligen ta bort kategorin?";
$AdminAddCatTxt = "L�gg till ny kategori";
$AdminConfirmAdd = "Kategorin inlagd";
$AdminEditCatTxt = "�ndra kategori info";
$AdminDeleteCatTxt = "Ta bort";
$AdminConfirmEdit = "Kategorin �ndrad";
$AdminConfirmCatDeleteMsg = "Kategorin �r borttagen";
$CategoryNameTxt = "Kategori";
$NewCategoryNameTxt = "Ny kategori";
$AdminAddCardTxt = "L�gg till nytt kort";

?>