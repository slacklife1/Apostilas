<?
$SelectCatMsg = "Selezionare la categoria di cartoline che vuoi vedere";
$SelectMsg = "Selezionare l'immagine da inviare qui sotto";
$EnlargeMsg = "Clikkare sull'immagine per vederla a grandezza intera!";
$MessageTxt = "Messaggio";
$SelectCardTxt = "Seleziona questa cartolina";
$EnterMsg = "Crea la tua cartolina";
$UserMessageTxt = "Il tuo messaggio";
$SenderNameTxt = "Il tuo nome";
$SenderEmailTxt = "Il tuo indirizzo Email";
$RecNameTxt = "Nome destinatario";
$RecEmailTxt = "Indirizzo EMail destinatario";
$RequiredTxt = "Indica un campo obbligatorio";
$PreviewMsg = "Questa e' l'anteprima della cartolina";
// database error messages
$WrongIDTxt = "Spiacente, non ci sono cartoline nel database corrispondenti al numero inserito. Controlla di aver copiato bene l'indirizzo";
$NoMatchesTxt = "Spiacente, non ci sono cartoline nel database.";
$ChooseCardTxt = "Spiacente, prima di procedere devi selezionare una cartolina.  Clikka sul tasto 'PRECEDENTE' e scegline una.";
$DearTxt = "Ciao...";
$SincerelyTxt = "Da";
$SendOrChangeTxt = "Se la tua cartolina ti piace clikka sul tasto 'SUCCESSIVO'.  Altrimenti clikka sul tasto 'PRECEDENTE' e fai le modifiche che vuoi.";
$BackTxt = "PRECEDENTE";
// error messages
$MessageErrorMsg = "Torna indietro e inserisci un messaggio";
$SendNameErrorMsg = "Torna indietro e inserisci il tuo nome";
$SendEmailErrorMsg = "Torna indietro e inserisci il tuo indirizzo Email";
$RecNameErrorMsg = "Torna indietro e inserisci il nome del destinatario";
$RecEmailErrorMsg = "Torna indietro e inserisci l'indirizzo Email del destinatario";
$SentMsg = "Il tuo messaggio e' stato inviato!";
$PickupMsg = "Preleva la tua cartolina";
$SendReplyTxt = "Clikka <A HREF='"."$ProgURL"."'>qui</a> per mandare una risposta!";
// Admin messages
$AdminSelectCatMsg = "ADMIN: Selezionare la categoria di cartoline che vuoi editare o clikka sul link per creare una categoria nuova";
$AdminSelectMsg = "ADMIN: Seleziona la cartolina che vuoi editare";
$AdminEditMsg = "ADMIN:  Modifica l'immagine intera, l'anteprima e/o il messaggio predefinito qui sotto";
$AdminCatUpdateTxt = "Aggiorna categoria";
$AdminDoNotChange = "Non cambiare";
$AdminNewTxt = "ADMIN: La nuova cartolina e' stata aggiunta";
$AdminDeleteCardTxt = "Cancella cartolina";
$AdminConfirmDeleteCardTxt = "ADMIN: Sei sicuro di voler cancellare questa cartolina?";
$AdminEditCatMsg = "Edita Categoria";
$AdminConfirmDeleteCatTxt = "Sei sicuro di voler cancellare questa categoria?";
$AdminAddCatTxt = "Aggiungi una nuova categoria";
$AdminConfirmAdd = "La tua categoria e' stata aggiunta";
$AdminEditCatTxt = "Modifica le informazioni della categoria";
$AdminDeleteCatTxt = "Cancella";
$AdminConfirmEdit = "Il nome della categoria e' stato modificato con successo";
$AdminConfirmCatDeleteMsg = "La categoria e' stata cancellata con successo";
$CategoryNameTxt = "Nome categoria";
$NewCategoryNameTxt = "Nuovo nome di categoria";
$AdminAddCardTxt = "Aggiungi una nuova cartolina";

?>