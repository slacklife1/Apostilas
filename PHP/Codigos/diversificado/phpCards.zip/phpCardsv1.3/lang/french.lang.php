<?
// this file was translated and sent in thanks to Matthieu, webmaster of http://www.web-pratique.com
// Many thanks, Mattieu!  Anyone who wishes to translate additional files may send them to snipe@snipe.net.
// Please be sure to let us know which program the file is for!

$SelectCatMsg = "Choisissez une cat�gorie de e-carte, que vous voulez envoyer.";
$SelectMsg = "Choisissez quelle image voulez vous envoyer sur votre carte postale";
$EnlargeMsg = "Cliquez sur l'image pour l'agrandir";
$MessageTxt = "Message";
$SelectCardTxt = "Choisir cette carte";
$EnterMsg = "Personnalisez votre carte ci dessous:";
$UserMessageTxt = "Votre Message";
$SenderNameTxt = "Votre Nom";
$SenderEmailTxt = "Votre adresse email";
$RecNameTxt = "Nom du destinataire";
$RecEmailTxt = "Email du destinataire";
$RequiredTxt = "signifie que le champ est obligatoire";
$PreviewMsg = "Ci dessous voici votre carte telle qu'elle apparaitra � votre correspondant";
// database error messages
$WrongIDTxt = "D�sol�, aucune carte ne correspond � ce n�. v�rifiez l'url que vous avez �crite";
$NoMatchesTxt = "D�sol�, aucune carte n'est disponible.";
$ChooseCardTxt = "D�sol�, vous devez choisir une carte avant de continuer.  Please use the back button and choose a card.";
$DearTxt = "Ch�r(e)";
$SincerelyTxt = "De";
$SendOrChangeTxt = "Si votre carte vous pla�t, cliquez sur le bouton 'suivant', sinon cliquez sur le bouton 'pr�c�dent' et effectuez les modifications souhait�es.";
$BackTxt = "Pr�c�dent";
// error messages
$MessageErrorMsg = "Revenez � l'�cran pr�c�dent et �crivez un Message";
$SendNameErrorMsg = "Revenez � l'�cran pr�c�dent et �crivez votre nom";
$SendEmailErrorMsg = "Revenez � l'�cran pr�c�dent et �crivez adresse email";
$RecNameErrorMsg = "Revenez � l'�cran pr�c�dent et �crivez le nom du destinataire";
$RecEmailErrorMsg = "Revenez � l'�cran pr�c�dent et �crivez l'email du destinataire";
$SentMsg = "Un email a �t� envoy� a votre correspondant pour qu'il vienne lire votre carte postale";
$PickupMsg = "Lire votre Carte postale";
$SendReplyTxt = "<A HREF='"."$ProgURL"."'>Cliquez ici</a> pour envoyez vous aussi une carte postale";
// Admin messages
$AdminSelectCatMsg = "ADMIN: Choisissez la cat�gorie de la carte que vous voulez �diter, ou cliquez sur le lien pour cr�er une nouvelle cat�gorie.";
$AdminSelectMsg = "ADMIN: Choisissez la carte que vous voulez �diter";
$AdminEditMsg = "ADMIN:  Modifier la taille r�elle de l'image, le thumbnail, et/ou le message par d�faut ci dessous:";
$AdminCatUpdateTxt = "Mettre � jour la Cat�gorie";
$AdminDoNotChange = "Ne pas modifier";
$AdminNewTxt = "ADMIN: Votre nouvelle carte a �t� ajout�e";
$AdminDeleteCardTxt = "Effacer la carte";
$AdminConfirmDeleteCardTxt = "ADMIN: Etes vous s�r de vouloir effacer cette carte ?";
$AdminEditCatMsg = "Modifier la Cat�gorie";
$AdminConfirmDeleteCatTxt = "Etes vous s�r de vouloir effacer cette cat�gorie ?";
$AdminAddCatTxt = "Ajouter une Cat�gorie";
$AdminConfirmAdd = "Votre cat�gorie a �t� ajout�e";
$AdminEditCatTxt = "Modifier les infos de la cat�gorie";
$AdminDeleteCatTxt = "Effacer";
$AdminConfirmEdit = "Le nom de votre cat�gorie a bien �t� modifi�";
$AdminConfirmCatDeleteMsg = "Le nom de votre cat�gorie a �t� effac�";
$CategoryNameTxt = "Nom de la cat�gorie:";
$NewCategoryNameTxt = "Nouveau nom de la cat�gorie";
$AdminAddCardTxt = "Ajouter une nouvelle carte";

?>