<?
/******************************************************************************
Power Banner Manager 2.0 !
(open.inc.php file)

Copyright Armin Kalajdzija, 2003.
E-Mail: armin@akde.com
WebSite: http://www.akde.com
******************************************************************************/

if (isset($hostname) and isset($database) and isset($db_login) and isset($db_pass)) {
    $dbconn = mysql_connect($hostname, $db_login, $db_pass) or die("Could not connect to database");
    mysql_select_db($database) or die("Could not select database");
}else{
    die("Missing data in config.inc.php file !");
}
?>