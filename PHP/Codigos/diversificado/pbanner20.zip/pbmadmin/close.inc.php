<?
/******************************************************************************
Power Banner Manager 2.0 !
(close.inc.php file)

Copyright Armin Kalajdzija, 2003.
E-Mail: armin@akde.com
WebSite: http://www.akde.com
******************************************************************************/

if (isset($dbconn)) {
    mysql_close($dbconn);
}
?>