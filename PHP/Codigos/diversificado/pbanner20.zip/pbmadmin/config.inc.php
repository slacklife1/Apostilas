<?
/*****************************************************************************
Power Banner Manager 2.0 !
(config.inc.php file)

Copyright Armin Kalajdzija, 2003.
E-Mail: armin@akde.com
WebSite: http://www.akde.com
*****************************************************************************/

//Database Setting
$hostname = "localhost";
$database = "pbanner";
$db_login = "armin";
$db_pass = "";

//Script Settings
$scriptdir = getcwd()."\\";       //Enter "\\" if your server is on windows platform
                                  //or type "/" if it is on linux/unix platform

$maxdisplay = 10;                 //How many banners you want to display per page

?>
