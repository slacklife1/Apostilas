<?
/******************************************************************************
Power Banner Manager 2.0 !
(visit.php file)

Copyright Armin Kalajdzija, 2003.
E-Mail: armin@akde.com
WebSite: http://www.akde.com
******************************************************************************/

include "config.inc.php";
include "open.inc.php";

    $query = "SELECT url,visits FROM powerban WHERE id=$id";
    $result = mysql_query($query) or die("Query failed");
    
    $rows = mysql_fetch_row($result);
    
    $visits = $rows[1] + 1;
    $cdate = date("Y-m-d h:i:s");
    
    $query = "UPDATE powerban SET visits=$visits WHERE id=$id";
    $result = mysql_query($query) or die("Query failed");

    $query = "INSERT INTO powerban_stats_visits (id, address, agent, datetime, referer) VALUES ('$id', '$REMOTE_ADDR', '$HTTP_USER_AGENT', '$cdate', '$HTTP_REFERER')";
    $result = mysql_query($query) or die("Query failed");

    header("Location:$rows[0]");

include "close.inc.php";

?>
