<?
/******************************************************************************
Power Banner Manager 2.0 !
(footer.inc.php file)

Copyright Armin Kalajdzija, 2003.
E-Mail: armin@akde.com
WebSite: http://www.akde.com
******************************************************************************/


print "<br><p ";
if (isset($chardir) and ($chardir <> "")) {
  print "dir='rtl' ";
}
print "align='center'><table width='404' border='0'><tr>";
print "<td background='images/footer.gif' height='24' width='410' >";
print "<div align='center'><font face='Verdana' size='1'><a href='mailto:armin@akde.com'>$footer_copyright_text Armin Kalajdzija, 2003.</a></div></td></tr></table>";

?>
