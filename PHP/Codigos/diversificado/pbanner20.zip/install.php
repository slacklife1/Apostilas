<?
/******************************************************************************
Power Banner Manager 2.0 !
(install.php file)

Copyright Armin Kalajdzija, 2003.
E-Mail: armin@akde.com
Web Site: http://www.akde.com
******************************************************************************/

include "pbmadmin/config.inc.php";

if (isset($install)) {

if (isset($hostname) and isset($database) and isset($db_login) and isset($db_pass)) {

    if (isset($user_pass) and isset($user_pass2) and ($user_pass == $user_pass2)) {
        $user_pass3 = crypt($user_pass);
    }else{
        die("<font face='Verdana' size='2'>Passwords must be the same</font>");
    }
    
    $dbconn = mysql_connect($hostname, $db_login, $db_pass) or die("Could not connect");
    print "<div align='center'>Connected to host!<br>";

    mysql_select_db($database) or die("Could not select database");
    print "Database selected !<br>";
    
    if (isset($user_login) and ($user_login <> "") and isset($user_pass) and ($user_pass <> "")) {
        
        $query = "DROP TABLE powerban";
        $result = mysql_query($query);
        $query = "DROP TABLE powerban_stats_views";
        $result = mysql_query($query);
        $query = "DROP TABLE powerban_stats_visits";
        $result = mysql_query($query);
        $query = "DROP TABLE powerban_auth";
        $result = mysql_query($query);
        $query = "DROP TABLE powerban_zones";
        $result = mysql_query($query);
    
        $query = "CREATE TABLE powerban (name varchar(30) , src text , alt text , url text , visits char(3) DEFAULT '0' , id varchar(4) , type char(1) DEFAULT '1' , dis_times varchar(10) , dised_times varchar(10) DEFAULT '0' , added int(3) , uid char(3) , target varchar(10) , dtype varchar(5) , zone varchar(4))";
        $result = mysql_query($query) or die("Query failed");
        print "Main table 'powerban' is created !<br>";
    
        $query = "CREATE TABLE  powerban_auth (login text , password text , ip text , date datetime , permit char(1) , uid char(3) , language text)";
        $result = mysql_query($query) or die("Query failed");
        print "Table powerban_auth is created !<br>";
        
        $query = "CREATE TABLE powerban_stats_views (id varchar(4) , date date)";
        $result = mysql_query($query) or die("Query failed");
        print "Table powerban_stats_views is created !<br>";
        
        $query = "CREATE TABLE powerban_stats_visits (id int(10) unsigned DEFAULT '0' , host text , address text , agent text , datetime datetime , referer text)";
        $result = mysql_query($query) or die("Query failed");
        print "Table powerban_stats_visits is created !<br>";
        
        $query = "CREATE TABLE powerban_zones (zid varchar(4) , zname varchar(30) , uid varchar(4))";
        $result = mysql_query($query) or die("Query failed");
        print "Table powerban_zones is created !<br>";
        
        $query = "INSERT INTO powerban_auth (login, password, permit, uid, language) VALUES ('$user_login', '$user_pass3', '1', '1', 'english.inc.php')";
        $result = mysql_query($query) or die("Query failed");
        print "Administrator account created !<br>";
    
        mysql_close($dbconn);
        
        print "Power Banner Manager is installed :)<br><br>";
        print "<b>DON'T FORGET TO DELETE THIS SCRIPT AFTER INSTALATION !!!</b><br><br>";
        print "<a href='pbmadmin/admin.php'>To continue click here</a></div>";
        die;

    }else{
       print "<font face='Verdana' size='2'>You need to fill in every textbox !</font>";
       die;
    }
    
}else{
   die("<font face='Verdana' size='2'>Missing data in config.inc.php file !</font>");
}

}
?>
<html>
<head>
<title>Power Banner Manager Instalation !</title>
</head>

<body bgcolor="#FFFFFF" text="#000000">
<form name="installfrm" method="post" action="install.php">
  <table width="503" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#32587F">
    <tr bgcolor="#32587F">
      <td colspan="2" height="31"><font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>
        Power Banner Manager Instalation !</b></font></td>
    </tr>
    <tr bordercolor="#FFFFFF" valign="bottom">
      <td colspan="2" height="32"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>Administrator
        Information:</b></font></td>
    </tr>
    <tr bordercolor="#FFFFFF">
      <td width="221"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Admin
        Login:</font></td>
      <td width="276"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">
        <input type="text" name="user_login" size="30">
        </font></td>
    </tr>
    <tr bordercolor="#FFFFFF">
      <td width="221"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Admin
        Password:</font></td>
      <td width="276"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">
        <input type="password" name="user_pass" size="30">
        </font></td>
    </tr>
    <tr bordercolor="#FFFFFF">
      <td width="221"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Admin
        Password (again):</font></td>
      <td width="276"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">
        <input type="password" name="user_pass2" size="30">
        </font></td>
    </tr>
    <tr valign="bottom" bordercolor="#FFFFFF">
      <td colspan="2" height="44"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>MySQL
        Information:</b></font></td>
    </tr>
    <tr bordercolor="#FFFFFF">
      <td width="221"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Hostname:</font></td>
      <td width="276"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><?php echo $hostname; ?></font></td>
    </tr>
    <tr bordercolor="#FFFFFF">
      <td width="221"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Database:</font></td>
      <td width="276"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><?php echo $database; ?></font></td>
    </tr>
    <tr bordercolor="#FFFFFF">
      <td width="221"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Login:</font></td>
      <td width="276"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><?php echo $db_login; ?></font></td>
    </tr>
    <tr bordercolor="#FFFFFF">
      <td width="221"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Password:</font></td>
      <td width="276"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><?php echo $db_pass; ?></font></td>
    </tr>
  </table>
  <p align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="1">Note:
    If you want to change any data, you will need to edit config.inc.php and refresh
    this install.php :)</font></p>
  <p align="center">
    <input type="submit" name="install" value="Install">
    <input type="reset" name="reset" value="Clear Info">
  </p>
</form><br>
<p align='center'><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>Support my Open Source Projects and make Power Banner Manager and other free script stay free.<br>Make donation over PayPal !
<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="business" value="akde@lsinter.net">
<input type="hidden" name="item_name" value="AKDe Open Source PHP Projects">
<input type="hidden" name="no_note" value="1">
<input type="hidden" name="currency_code" value="EUR">
<input type="hidden" name="tax" value="0">
<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but04.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
</form></p>
</body>
</html>


