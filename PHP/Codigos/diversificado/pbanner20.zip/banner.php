<?
/******************************************************************************
Power Banner Manager 2.0 !
(banner.php file)

Copyright Armin Kalajdzija, 2003.
E-Mail: armin@akde.com
WebSite: http://www.akde.com
******************************************************************************/

include "pbmadmin/config.inc.php";
include "pbmadmin/open.inc.php";

$bcount = 0;
$found = false;
$fbcount = 0;

$query = "SELECT * FROM powerban";

if (isset($bid) && ($bid <> "")) {
    $query .= " WHERE id = '$bid'";
}else if (isset($uid) && ($uid <> "") or (isset($zid) && ($zid <> ""))) {
    $query .= " WHERE ";
    if (isset($uid) && ($uid <> "")) {
        $query .= "uid = '$uid'";
    }
    if (isset($uid) && ($uid <> "") && (isset($zid) && ($zid <> ""))) {
        $query .= " AND ";
    }
    if (isset($zid) && ($zid <> "")) {
        $query .= " zone = '$zid'";
    }
}

$result = mysql_query($query) or die("Unable to get banner list");
while ($line = mysql_fetch_array($result)) {
    $bcount = $bcount + 1;
    $banners[$bcount] = $line;
}

while ($found <> true) {
    if ($fbcount == $bcount) {
        die("No more banners to display");
    }else{
        $dban = rand(1,$bcount);
        
        if (($banners[$dban]["dis_times"] > $banners[$dban]["dised_times"]) or ($banners[$dban]["dis_times"] == 0)) {
            $found = true;
            $banners[$dban]["dised_times"] += 1;
            
            $query = "UPDATE powerban SET dised_times=".$banners[$dban]["dised_times"]." WHERE id=".$banners[$dban]["id"];
            $result = mysql_query($query) or die("Query failed");
            
            if ($banners[$dban]["type"] == 1) {                  
               if ($banners[$dban]["dtype"] == 1) {
                  echo "<a href='pbmadmin/visit.php?id=".$banners[$dban]["id"]."' target='".$banners[$dban]["target"]."'><img src='".$banners[$dban]["src"]."' alt='".$banners[$dban]["alt"]."' border=0></a>";
               }else if ($banners[$dban]["dtype"] == 2) {
                  
                  $fp = fopen ("pbmadmin/tmp/bantemp.htm", "w");
                  fputs($fp,"<title>".$banners[$dban]["alt"]."</title>");
                  fputs($fp,"<a href='../visit.php?id=".$banners[$dban]["id"]."' target='".$banners[$dban]["target"]."'><img src='".$banners[$dban]["src"]."' alt='".$banners[$dban]["alt"]."' border=0></a>");
                  fclose($fp);
                  
                  echo "<script language='JavaScript'>\n";
                  echo "function popup() {\n";
                  echo "var f = document.forms[0];\n";
                  echo "var docServerPath = 'pbmadmin/tmp/bantemp.htm';\n";
                  echo "window1=window.open(docServerPath,'messageWindow1','scrollbars=no,width=490,height=70');\n";
                  echo "}</script>\n";

               }
            }else if($banners[$dban]["type"] == 2) {
              $swfdims = split('[x]',$banners[$dban]["url"]);
              print "<object classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' codebase='http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0' width='$swfdims[0]' height='$swfdims[1]'>";
              print "<param name=movie value='".$banners[$dban]["src"]."'>";
              print "<param name=quality value=high>";
              print "<embed src='".$banners[$dban]["src"]."' quality=high pluginspage='http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash' type='application/x-shockwave-flash' width='$swfdims[0]' height='$swfdims[1]'>";
              print "</embed></object>";
            }
            
        }else{
            $found = false;
            $fbcount += 1;
        }
    }
}

include "pbmadmin/close.inc.php";
?>