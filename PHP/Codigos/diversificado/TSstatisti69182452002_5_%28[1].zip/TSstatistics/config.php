<?php

/************************************************
*                                               *
*  TSstatistics                                 *
*                                               *
*  by Thomas Schuster                           *
*  http://www.TSinter.net                       *
*                                               *
*  file: config.php                             *
*  version: 2.5                                 *
*  license: GNU General Public License          *
*  created: 04.04.2002                          *
*  email: admin@TSinter.net                     *
*                                               *
*                                               *
*  Object oriented traffic analyser. Needs no   *
*  database. Tracks the visitors of a website.  *
*  Filters out over 100 robots. Reload restric- *
*  tion. Displays hits per hour/day/month,      *
*  various toplists, all graphical. Auto back-  *
*  up. Administration center.                   *
*                                               *
*  Copyright (c) 2001-2002 TSinter.net          *
*  All rights reserved.                         *
*                                               *
************************************************/


//-------------------------------//
// Do not change anything below! //
//-------------------------------//


// If the client browser supports cookies, TScounter will use session management.
session_start();
session_register("cookie");


// Include the classes.
include_once($DOCUMENT_ROOT.$script_path."class_support.php");
include_once($DOCUMENT_ROOT.$script_path."class_counter.php");
include_once($DOCUMENT_ROOT.$script_path."class_statistics.php");

// Instanciate a new object.
$statistics = new TSstatistics($script_path);
$statistics->_processPageRequest($statistics->_cookieCheck());

?>
