<?php

/************************************************
*                                               *
*  TSstatistics                                 *
*                                               *
*  by Thomas Schuster                           *
*  http://www.TSinter.net                       *
*                                               *
*  file: class_statistics.php                   *
*  version: 2.5                                 *
*  license: GNU General Public License          *
*  created: 04.04.2002                          *
*  email: admin@TSinter.net                     *
*                                               *
*                                               *
*  Object oriented traffic analyser. Needs no   *
*  database. Tracks the visitors of a website.  *
*  Filters out over 100 robots. Reload restric- *
*  tion. Displays hits per hour/day/month,      *
*  various toplists, all graphical. Auto back-  *
*  up. Administration center.                   *
*                                               *
*  Copyright (c) 2001-2002 TSinter.net          *
*  All rights reserved.                         *
*                                               *
************************************************/


class TSstatistics extends TScounter {

  //-------------------------------------------//
  // Specify language ["deutsch" || "english"] //
  //-------------------------------------------//
  var $language = "deutsch";

  //---------------------------------//
  // Specify max. size of bars in px //
  //---------------------------------//
  var $MAX_HORIZONT_BAR = 25;
  var $MAX_VERT_BAR_VISITS = 40;
  var $MAX_VERT_BAR_IMPRESSIONS = 80;

  //---------------------------------------//
  // Specify days of month for auto backup //
  //---------------------------------------//
  var $backup_dates = array( 5, 10, 15, 20, 25, 30);
  
  


  //-------------------------------//
  // Do not change anything below! //
  //-------------------------------//


  /* array for different languages */
  var $string;


  /* data files */
  var $log_data;
  var $password_data;
  var $backup_log;
  var $search_engine_library;
  var $language_library;


  /* data directories (absolute path) */
  var $templates_dir;
  var $backup_dir;
  

  /* data directories (relative path) */
  var $image_path;
  var $class_path;
  var $data_path;


  /* templates */
  var $traffic_template;
  var $toplist_template;
  var $overview_template;


  /* css file */
  var $css;


  /* bar images */
  var $bar_image;


  /* request information */
  var $referer;
  var $url;
  var $top_level_domain;




  /*
  ** Function: TSstatistics
  ** Input: STRING class_path
  ** Output: VOID
  ** Description: This is the constructor of the class.
  */
  function TSstatistics($class_path) {

    # Call the constructor of the parent class.
    $this->TScounter($class_path);

    # Check the php version.
    if ($this->_checkMinimumVersion("4.1.0")) {

      # php version is at least 4.1.0
      $this->referer = $_SERVER["HTTP_REFERER"];
    }
    else {

      # php version is older than 4.1.0
      global $HTTP_SERVER_VARS;
      $this->referer = $HTTP_SERVER_VARS["HTTP_REFERER"];
    }

    $this->class_path = $class_path;
    $this->data_path = $class_path."data/";
    $this->image_path = $class_path."images/";
    $this->templates_path = $class_path."templates/";

    # Bar images
    $this->bar_image["horizontal"]["blue"] = $this->image_path."blue_horizontal.gif";
    $this->bar_image["horizontal"]["green"] = $this->image_path."darkgreen_horizontal.gif";
    $this->bar_image["vertical"]["blue"] = $this->image_path."blue_vertical.gif";
    $this->bar_image["vertical"]["green"] = $this->image_path."darkgreen_vertical.gif";

    $this->backup_dir = $this->class_dir."backup/";
    $this->templates_dir = $this->class_dir."templates/";

    # Set the path to the data files.
    $this->log_data["browser"] = $this->data_dir."browser.log";
    $this->log_data["entry_page"] = $this->data_dir."entry_page.log";
    $this->log_data["os"] = $this->data_dir."os.log";
    $this->log_data["referer"] = $this->data_dir."referer.log";
    $this->log_data["top_level_domain"] = $this->data_dir."domain.log";
    $this->log_data["spider"] = $this->data_dir."spider.log";
    $this->log_data["search_engine"] = $this->data_dir."search_engine.log";
    $this->log_data["search_query"] = $this->data_dir."search_query.log";
    $this->log_data["month"] = $this->data_dir."month_".$this->month."_".$this->year.".log";
    $this->prev_log_data["month"] = $this->data_dir."month_".($this->month - 1)."_".$this->year.".log";
    #$this->log_data["year"] = $this->class_dir.$this->year.".log";

    $this->password_data = $this->data_dir."password.dat";
    $this->backup_log = $this->data_dir."backup.log";
    
    # Templates
    $this->traffic_template = $this->templates_dir."traffic_template.php";
    $this->toplist_template = $this->templates_dir."toplist_template.php";
    $this->overview_template = $this->templates_dir."overview_template.php";
    $this->css = "<link rel=\"stylesheet\" href=\"".$this->templates_path."statistics.css\" type=\"text/css\" />";

    $this->search_engine_library = $this->data_dir."search_engine.lib";
    $this->language_library = $this->data_dir."language.lib";
    
    # Set the language.
    $this->_setLanguage($this->language);

    # Store the information about the referer in an array. This array
    # contains host, path and query.
    $this->url = parse_url($this->referer);
    
  }



  function _setLanguage($language) {

    # Prepare output for specified language.
    switch ($language) {
      case "deutsch":
        $this->language = 1;
        break;
      case "english":
        $this->language = 0;
        break;
    }
    
    $language_file = @file($this->language_library);
    
    for ($i = 0; $i < sizeof($language_file); $i++)
      $language_line[$i] = explode("|", $language_file[$i]);

    $this->string["impressions"] = $language_line[4][$this->language];
    $this->string["visits"] = $language_line[5][$this->language];
    
    $this->string["toplist_head"]["browser"] = $language_line[1][$this->language];
    $this->string["toplist_head"]["os"] = $language_line[2][$this->language];
    $this->string["toplist_head"]["referer"] = $language_line[3][$this->language];
    $this->string["toplist_head"]["impression"] = $language_line[4][$this->language];
    $this->string["toplist_head"]["entry_page"] = $language_line[6][$this->language];
    $this->string["toplist_head"]["search_engine"] = $language_line[7][$this->language];
    $this->string["toplist_head"]["search_query"] = $language_line[8][$this->language];
    $this->string["toplist_head"]["spider"] = $language_line[9][$this->language];
    $this->string["toplist_head"]["top_level_domain"] = $language_line[10][$this->language];
    $this->string["toplist_head"]["of_string"] = $language_line[11][$this->language];
    
    $this->string["traffic_head"]["monthly_stat"] = $language_line[13][$this->language];
    $this->string["traffic_head"]["annual_stat"] = $language_line[14][$this->language];
    $this->string["traffic_head"]["requests_day"] = $language_line[15][$this->language];
    $this->string["traffic_head"]["requests_hour"] = $language_line[16][$this->language];
    $this->string["traffic_head"]["requests_month"] = $language_line[17][$this->language];
    $this->string["traffic_head"]["mean"] = $language_line[18][$this->language];
    
    $this->string["overview"]["today"] = $language_line[20][$this->language];
    $this->string["overview"]["total"] = $language_line[21][$this->language];
    $this->string["overview"]["per_day"] = $language_line[22][$this->language];
    $this->string["overview"]["record"] = $language_line[23][$this->language];
    $this->string["overview"]["choose"] = $language_line[24][$this->language];
    
    $this->string["admin"]["password"] = $language_line[26][$this->language];
    $this->string["admin"]["manual_backup"] = $language_line[27][$this->language];
    $this->string["admin"]["restore"] = $language_line[28][$this->language];
    $this->string["admin"]["see_tracks"] = $language_line[29][$this->language];
    $this->string["admin"]["welcome"] = $language_line[30][$this->language];
    $this->string["admin"]["password_repeat"] = $language_line[31][$this->language];
    $this->string["admin"]["password_differ"] = $language_line[32][$this->language];
    $this->string["admin"]["fields_all"] = $language_line[33][$this->language];
    $this->string["admin"]["fields_missing"] = $language_line[34][$this->language];
    $this->string["admin"]["password_wrong"] = $language_line[35][$this->language];
    $this->string["admin"]["user_wrong"] = $language_line[36][$this->language];
    $this->string["admin"]["user_add"] = $language_line[37][$this->language];
    $this->string["admin"]["no_track"] = $language_line[38][$this->language];
    $this->string["admin"]["backup_success"] = $language_line[39][$this->language];
    $this->string["admin"]["backup_fail"] = $language_line[40][$this->language];
    $this->string["admin"]["restore_success"] = $language_line[41][$this->language];
    $this->string["admin"]["restore_fail"] = $language_line[42][$this->language];
    $this->string["admin"]["time_current"] = $language_line[43][$this->language];
    $this->string["admin"]["time_backup"] = $language_line[44][$this->language];

    $this->string["overview"]["since"] = $language_line[46][$this->language];

  }




  //------------------//
  //  Admin functions //
  //------------------//


  /*
  ** Function: _install
  ** Input: STRING user, STRING pass
  ** Output: VOID
  ** Description: Install TSstatistics, create files/directories.
  */
  function _install($user, $pass) {

    switch ($this->_setPassword($this->data_dir, $this->password_data, $user, $pass)) {

      case 1:
        # New user added
        return  $user." ".$this->string["admin"]["user_add"];
      
      case 2:
        # LOCK_EX error
        return "LOCK_EX error on ".$this->password_data;

      case 3:
        # LOCK_UN error
        return "LOCK_UN error on ".$this->password_data;
    }
  
  }

  



  /*
  ** Function: _login
  ** Input: STRING user, STRING pass
  ** Output: STRING
  ** Description: Administration center login check.
  */
  function _login($user, $pass) {

    switch ($this->_processLogin($this->password_data, $user, $pass)) {

      case 1:
        # Correct login
        return  $this->string["admin"]["welcome"].", ".$user."!";
      
      case 2:
        # Wrong password
        $this->string["admin"]["password_wrong"];

      case 3:
        # Wrong user name
        return $user." ".$this->string["admin"]["user_wrong"];
    }

  }


  
  
  /*
  ** Function: _getTimeOfLastBackup
  ** Input: VOID
  ** Output: STRING lastBackup
  ** Description: Get the time, when the last backup was made.
  */
  function _getTimeOfLastBackup() {
    if (file_exists($this->backup_log)) {
      $log_file = @file($this->backup_log);

      $log_line = explode("|", $log_file[0]);
      $lastBackup = date("j.n.Y, H:i", $log_line[1]);
    }
    else $lastBackup = "n/a";

    return $lastBackup;
  }




  /*
  ** Function: _getListOfLogfiles
  ** Input: STRING category
  ** Output: STRING log_files[]
  ** Description: Get a list of specifies logfiles.
  */
  function _getListOfLogfiles($category) {

    if (!$log_files = $this->_getListOfFiles($this->data_dir, $this->data_path, $category))
      return FALSE;
    else return $log_files;
  }




  /*
  ** Function: _manualBackup
  ** Input: VOID
  ** Output: VOID
  ** Description: Backup the datafiles.
  */
  function _manualBackup() {

    switch ($this->_backup($this->log_data, $this->backup_dir, $this->backup_log)) {
      case 1:
        # Successful backup
        return $this->string["admin"]["backup_success"];
      default:
        # Backup failed
        return $this->string["admin"]["backup_fail"];
    }

  }




  /*
  ** Function: _restoreBackup
  ** Input: VOID
  ** Output: VOID
  ** Description: Restore data from backup.
  */
  function _restoreBackup() {

    if (file_exists($this->backup_dir)) {
      $bak_data = $this->_getDirArray($this->backup_dir);
      for ($i = 0; $i < sizeof($bak_data); $i++)
        copy($this->backup_dir.$bak_data[$i], $this->data_dir.basename($bak_data[$i], ".bak").".log");
      $message = $this->string["admin"]["restore_success"];
    }
    else $message = $this->string["admin"]["restore_fail"];

    return $message;
  }






  //-----------------//
  // Input functions //
  //-----------------//



  /*
  ** Function: _processPageRequest
  ** Input: BOOLEAN cookie_support
  ** Output: VOID
  ** Description: Meta function which calls necessary functions to log request.
  */
  function _processPageRequest($cookie_support)  {
    
    $backup_day = FALSE;
    # Ckeck if there should be made an automatic backup of the datafiles.
    for ($i = 0; $i < sizeof($this->backup_dates); $i++) {

      if ($this->day == $this->backup_dates[$i]) {
        # It is "backup day".
        $backup_day = TRUE;

        if (file_exists($this->backup_log)) {
          $log_file = @file($this->backup_log);

          # Check if the files are already backed up today.
          $log_line = explode("|", $log_file[1]);

          if ($log_line[1] == 0) {
            # No automatic backup made today.
            $this->_backup($this->log_data, $this->backup_dir, $this->backup_log);
            # Note that backups were made.
            $log_line[1] = 1;
            $log_file[1] = implode("|", $log_line);
            $this->_writeArray($this->backup_log, $log_file, "w");
          }

        }
        else $this->_backup($this->log_data, $this->backup_dir, $this->backup_log);

      }
    }

    if ($backup_day == FALSE) {

      # Make sure that in the backup_log is noted that no backups were made yet.
      # That is important, because when the "backup day" arrives, we want to make a backup.

      if (file_exists($this->backup_log)) {
        $log_file = @file($this->backup_log);
        $log_line = explode("|", $log_file[1]);

        if ($log_line[1] == 1) {
          # Note that backups should be made the next "backup day".
          $log_line[1] = 0;
          $log_file[1] = implode("|", $log_line);
          $this->_writeArray($this->backup_log, $log_file, "w");
        }
      }
    }
    
    # If a real visitor requests a webpage, process that request.
    if (!$this->_identifyClientAs("spider")) {
      # Start the main process.
   
      switch ($cookie_support) {
        
        case TRUE:
         
        # User was already counted, cookies are supported.
          if ($this->_compare("sessionID") || $this->_compare("ip")) {

            # Add the actual webpage to the user track and
            # increase the page impressions.
           
            $this->_trackVisitor("old visitor");
            $this->_log("impression");
          }
          else {

            # We have to search the corresponding user
            # track of the actual user in the logfile.
            # If the index is < 0, we have reached the
            # end of the logfile. We log the new visitor,
            # which has never visited us before.
        
            $this->currentIndex--;
            if ($this->currentIndex >= 0)
              $this->_processPageRequest(TRUE);
            else {
              $this->_log("visit");
              $this->_log("entry_page");
              $this->_log("referer");
              $this->_log("browser");
              $this->_log("os");
              $this->_log("top_level_domain");
              $this->_trackVisitor("new visitor");
              $this->_log("impression");
            }
          }
          break;
      
        case FALSE:
     
          # No session id generated yet. Either this is
          # the first page request of the visitor or the
          # client browser does not support cookies.
     
          if ($this->_compare("ip")) {

            # Client browser does not support cookies but
            # we can track the visitor by the IP.
   
            $this->_trackVisitor("old visitor");
            $this->_log("impression");
          }

          else if ($this->_reloadRestriction()) {

            # Another visitor has requested the website during
            # the period of time defined as reload restriction.
            # It is possible that the visitor we are actually
            # tracking has already been counted during that reload
            # restriction. To check this, we search the IP in the
            # older user tracks until the elapsed time is higher
            # than the reload restriction.

            # If the index is < 0, we have reached the
            # end of the logfile. We log the new visitor,
            # which has never visited us before.

            $this->currentIndex--;
            if ($this->currentIndex >= 0)
              $this->_processPageRequest(FALSE);
            else {
              $this->_log("visit");
              $this->_log("entry_page");
              $this->_log("referer");
              $this->_log("browser");
              $this->_log("os");
              $this->_log("top_level_domain");
              $this->_trackVisitor("new visitor");
              $this->_log("impression");
            }
          }

          else {

            # A new visitor has entered the website.
   
            $this->_log("visit");
            $this->_log("entry_page");
            $this->_log("referer");
            $this->_log("browser");
            $this->_log("os");
            $this->_log("top_level_domain");
            $this->_trackVisitor("new visitor");
            $this->_log("impression");
          }
          break;
      }
    }
    else $this->_log("spider");
  }





  /*
  ** Function: _logTimeOfRequest
  ** Input: VOID
  ** Output: VOID
  ** Description: Log the time of the page request.
  */
  function _logTimeOfRequest($category) {

    $impression_logged = FALSE;

    if(!file_exists($this->log_data["month"])) {

      # Create the log array and set all values to zero.
      # Every line in the logfile contains a "\r\n" at the end.


      # Requests per hour (this month).
      for ($i = 0; $i < 24; $i++) {
        $visits["hour"][$i] = 0;
        $impressions["hour"][$i] = 0;
      }

      $visits["hour"][24] = "\r\n";
      $impressions["hour"][24] = "\r\n";


      # Requests per day (this month).
      for ($i = 0; $i < $this->daysPerMonth; $i++) {
        $visits["day"][$i] = 0;
        $impressions["day"][$i] = 0;
      }

      $visits["day"][$this->daysPerMonth] = "\r\n";
      $impressions["day"][$this->daysPerMonth] = "\r\n";


      # Requests this day.
      $visits["today"] = 0;
      $impressions["today"] = 0;

     
      # Check if there is a logfile for the previous month.
      if (file_exists($this->prev_log_data["month"])) {

        # Extract the values from the previous logfile and
        # write them into the current (not yet existing) one.

        $log_file = @file($this->prev_log_data["month"]);

        # Reset the monthly impression statistics.
        for ($i = 15; $i < sizeof($log_file); $i++)
          unset($log_file[$i]);

        # Visits during the current year, sorted by months.
        $visits["year"] = explode("|", $log_file[10]);

        # All time visits.
        $visits["total"] = explode("|", $log_file[11]);

        # Visits record day.
        $visits["record"] = explode("|", $log_file[12]);
        
        # Impressions during the current year, sorted by months.
        $impressions["year"] = explode("|", $log_file[3]);

        # All time impressions.
        $impressions["total"] = explode("|", $log_file[4]);

        # Impressions record day.
        $impressions["record"] = explode("|", $log_file[5]);

      }

      else {

        # Initialize all values with zero.
        
        # Requests this year, sorted by months.
        for ($i = 0; $i < 12; $i++) {
          $visits["year"][$i] = 0;
          $impressions["year"][$i] = 0;
        }

        $visits["year"][12] = "\r\n";
        $impressions["year"][12] = "\r\n";


        # All time requests.
        $visits["total"][0] = 0;
        $impressions["total"][0] = 0;
        
        $visits["total"][1] = time();
        $impressions["total"][1] = time();

        $visits["total"][2] = "\r\n";
        $impressions["total"][2] = "\r\n";


        # The days with the most requests.
        $visits["record"][0] = 0;
        $impressions["record"][0] = 0;

        # Field for the timestamp.
        $visits["record"][1] = "-";
        $impressions["record"][1] = "-";

        $visits["record"][2] = "\r\n";
        $impressions["record"][2] = "\r\n";


        # The following lines are the comments of the file, which will be generated
        # at the end of this function. This is the static part of the log array.
        # It has to be declared only when generating a new datafile. The dynamic
        # part follows at the end of this function.
        $log_file[0] = "page impressions *hour, day, year, total, record day*\r\n";
        $log_file[6] = "---\r\n";
        $log_file[7] = "visits *hour, day, year, total, record day*\r\n";
        $log_file[13] = "---\r\n";
        $log_file[14] = "*page impressions this month*\r\n";
        
        $log_file[15] = $this->webpage."|0|\r\n";
        $impression_logged = TRUE;

      }

    }

    else {

      # Extract the values of the current logfile.

      $log_file = @file($this->log_data["month"]);

      $visits["hour"] = explode("|", $log_file[8]);
      $visits["day"] = explode("|", $log_file[9]);
      $visits["year"] = explode("|", $log_file[10]);
      $visits["total"] = explode("|", $log_file[11]);
      $visits["today"] = $visits["day"][$this->day - 1];
      $visits["record"] = explode("|", $log_file[12]);
      
      $impressions["hour"] = explode("|", $log_file[1]);
      $impressions["day"] = explode("|", $log_file[2]);
      $impressions["year"] = explode("|", $log_file[3]);
      $impressions["total"] = explode("|", $log_file[4]);
      $impressions["today"] = $impressions["day"][$this->day - 1];
      $impressions["record"] = explode("|", $log_file[5]);

    }

    switch ($category) {

      case "visit":
        
        $visits["hour"][$this->hour]++;
        $visits["day"][$this->day - 1]++;
        $visits["year"][$this->month - 1]++;
        $visits["total"][0]++;
        $visits["today"]++;

        # Check for a new record day.
        if ($visits["today"] > $visits["record"][0]) {
          $visits["record"][0] = $visits["today"];
          $visits["record"][1] = time();
        }

        # We do not want to log any impressions here.
        $impression_logged = TRUE;

        break;
      
      case "impression":
        
        # Get the list of the page impressions for this month and
        # log the request.
        for ($i = 15; $i < sizeof($log_file); $i++) {
          $impressions["webpages"] = explode("|", $log_file[$i]);
          if (!strcmp($this->webpage, $impressions["webpages"][0])) {
            $impressions["webpages"][1]++;
            $log_file[$i] = implode("|",  $impressions["webpages"]);
            $impression_logged = TRUE;
            break;
          }
        }

        $impressions["hour"][$this->hour]++;
        $impressions["day"][$this->day - 1]++;
        $impressions["year"][$this->month - 1]++;
        $impressions["total"][0]++;
        $impressions["today"]++;

        # Check for a new record day.
        if ($impressions["today"] > $impressions["record"][0]) {
          $impressions["record"][0] = $impressions["today"];
          $impressions["record"][1] = time();
        }
       
        break;
    }

    # Now follows the dynamic part of the log array. It
    # contains updating the impressions and visits and
    # the page impressions statistics for this month.

    # Update the page impressions in the log array.
    $log_file[1] = implode("|", $impressions["hour"]);
    $log_file[2] = implode("|", $impressions["day"]);
    $log_file[3] = implode("|", $impressions["year"]);
    $log_file[4] = implode("|", $impressions["total"]);
    $log_file[5] = implode("|", $impressions["record"]);

    # Update the visits in the log array.
    $log_file[8] = implode("|", $visits["hour"]);
    $log_file[9] = implode("|", $visits["day"]);
    $log_file[10] = implode("|", $visits["year"]);
    $log_file[11] = implode("|", $visits["total"]);
    $log_file[12] = implode("|", $visits["record"]);

    # First request of a webpage this month.
    if ($impression_logged == FALSE)
      $log_file[sizeof($log_file)] = $this->webpage."|1|\r\n";

    # Store data in logfile.
    $this->_writeArray($this->log_data["month"], $log_file, "w");

  }




  /*
  ** Function: _log
  ** Input: STRING category
  ** Output: VOID
  ** Description: Log request by storing the data in logfiles.
  */
  function _log($category) {

    switch ($category) {

      case "entry_page":
        $subject = $this->webpage;
        break;

      case "referer":
        $subject = $this->url["host"];

        if ($subject != "" && $search_engine = $this->_identifyClientAs("search_engine")) {
          $subject = $search_engine;
          $log_data = $this->log_data["search_engine"];
          $this->_log("search_query");
        }

        break;

      case "browser":
        $subject = $this->_checkBrowser();
        break;

      case "os":
        $subject = $this->_checkOS();
        break;

      case "top_level_domain":
        $host_string = gethostbyaddr($this->ip);

        if (!strcmp($host_string, $this->ip)) {
          # Host is also a ip number.
          $this->top_level_domain = "n/a";
        }          
        else {
          $host_array = explode(".", $host_string);
          $this->top_level_domain = $host_array[sizeof($host_array) - 1];
        }

        $subject = $this->top_level_domain;
        break;

      case "impression":

        # Call the function which logs the time of the request.
        $this->_logTimeOfRequest($category);

        # The following instructions log all the impressions of a webpage
        # independent from any time period. The result is a "all time" history.

        $log_data = $this->log_data["hits"];
        $subject = $this->webpage;
        break;

      case "visit":

        # Call the function which logs the time of the request.
        $this->_logTimeOfRequest($category);

        $log_data = $this->log_data["hits"];
        $subject = $category;
        break;

      case "search_query":

        # Get the search query. The syntax of the queries depends
        # on the search engine.
        preg_match_all("/(key=|p=|q=).*/", $this->url["query"], $matches);

        # Extract the keywords.
        $query_string = substr($matches[0][0], strlen($matches[1][0]));
        $query_temp = explode("&", $query_string);
        $query_array = explode("+", $query_temp[0]);
        $query = implode(" ", $query_array);
        $subject = urldecode($query);
        break;

      case "spider":

        $subject = $this->_identifyClientAs("spider");
        break;

    }

    if (!isset($log_data))
      $log_data = $this->log_data[$category];

    $log_file = @file($log_data);
    
    if ($subject != "" && $this->_incrementIfEqual($subject, $log_file, 0, 1) != 1) {
      # there is no entry yet, so we have to add a new one
      if (!strcmp($subject, "visit"))
        $start_value = $this->visitorStartValue;
      else $start_value = 1;
      $line = $subject."|".$start_value."|\r\n";
      $this->_writeLine($log_data, $line, "a");
    }
    else {
      # write the already changed array back to the pageImpressions_data
      $this->_writeArray($log_data, $log_file, "w");
    }
  }




  /*
  ** Function: _checkBrowser
  ** Input: VOID
  ** Output: STRING browser
  ** Description: Get the browser name of the visitor.
  */
  function _checkBrowser() {

    preg_match_all("/(microsoft internet explorer|msie|netscape6|mozilla|gecko|opera|konqueror
                      |lynx|omniweb|netpositive)[\/\sa-z]*([0-9]+)([\.0-9a-z]+)/i",
                      $this->user_agent, $matches);

    if (sizeof($matches[0]) == 0)
      $browser = "n/a";

    for ($i = 0; $i < sizeof($matches[0]); $i++) {
      if (eregi("opera", $matches[0][$i])) {
        if (!$matches[3][$i])
          $matches[3][$i] = ".0";
        $browser = "Opera ".$matches[2][$i].$matches[3][$i];
      }
      else if (eregi("MSIE", $matches[0][$i])) {
        if (!$matches[3][$i])
          $matches[3][$i] = ".0";
        $browser = "Internet Explorer ".$matches[2][$i].$matches[3][$i];
      }
      else if (eregi("Netscape6", $matches[0][$i])) {
        if (!$matches[3][$i])
          $matches[3][$i] = ".0";
        $browser = "Netscape ".$matches[2][$i].$matches[3][$i];
      }
      else if (eregi("Gecko", $matches[0][$i])) {
        preg_match_all("/(rv:)[\/\sa-z]*([0-9]+)([\.0-9a-z]+)/i", $this->user_agent, $matches2);
        $browser = "Mozilla ".$matches2[2][0].$matches2[3][0];
      }
      else if (eregi("Konqueror", $matches[0][$i])) {
        preg_match_all("/(Konqueror\/)[\/\sa-z]*([0-9]+)([\.0-9a-z]+)/i", $this->user_agent, $matches2);
        $browser = "Konqueror ".$matches2[2][0].$matches2[3][0];
      }
      else if (eregi("Lynx", $matches[0][$i])) {
        preg_match_all("/(Lynx\/)[\/\sa-z]*([0-9]+)([\.0-9a-z]+)/i", $this->user_agent, $matches2);
        $browser = "Lynx ".$matches2[2][0].$matches2[3][0];
      }
      else if (eregi("OmniWeb", $matches[0][$i])) {
        preg_match_all("/(OmniWeb\/)[\/\sa-z]*([0-9]+)([\.0-9a-z]+)/i", $this->user_agent, $matches2);
        $browser = "OmniWeb ".$matches2[2][0].$matches2[3][0];
      }
      else if (eregi("NetPositive", $matches[0][$i])) {
        preg_match_all("/(NetPositive\/)[\/\sa-z]*([0-9]+)([\.0-9a-z]+)/i", $this->user_agent, $matches2);
        $browser = "NetPositive ".$matches2[2][0].$matches2[3][0];
      }
      else if (eregi("Mozilla/4", $matches[0][$i])) {
        if (!$matches[3][$i])
          $matches[3][$i] = ".0";
        $browser = "Netscape Communicator ".$matches[2][$i].$matches[3][$i];
      }
      else $browser = "n/a";
    }
    return $browser;
  }



  /*
  ** Function: _checkOS
  ** Input: VOID
  ** Output: STRING os
  ** Description: Get the OS name of the visitor.
  */
  function _checkOS() {

    $os = "n/a";

    if (strstr($this->user_agent, "Win 9x 4.90"))
      $os = "Windows ME";
    else if (strstr($this->user_agent, "Win 95"))
      $os = "Windows 95";
    else if (strstr($this->user_agent, "Win98") || strstr($this->user_agent, "Windows 98"))
      $os = "Windows 98";
    else if (strstr($this->user_agent, "Windows NT 5.1") || strstr($this->user_agent, "Windows XP"))
      $os = "Windows XP";
    else if (strstr($this->user_agent, "Windows NT 5.0") || strstr($this->user_agent, "Windows 2000"))
      $os = "Windows 2000";
    else if (strstr($this->user_agent, "Windows NT") || strstr($this->user_agent, "WinNT"))
      $os = "Windows NT";
    else if (strstr($this->user_agent, "Linux"))
      $os = "Linux";
    else if(eregi("sunos/([0-9]{1,2}.[0-9]{1,2}){0,1}", $this->user_agent, $matches))
      $os = "Sun OS ".$matches[1];
    else if (strstr($this->user_agent, "Mac OS X"))
      $os = "Mac OS X";
    else if (strstr($this->user_agent, "Macintosh") || strstr($this->user_agent, "Mac_PowerPC"))
      $os = "Mac OS";
    else if (strstr("BeOS", $this->user_agent))
      $os = "BeOS";
    else if (stristr("unix", $this->user_agent) || stristr("hp-ux", $this->user_agent))
      $os = "Unix";
    else if (strstr("OS/2", $this->user_agent))
      $os = "OS/2";
    else if (strstr("FreeBSD", $this->user_agent))
      $os = "FreeBSD";
    else if (strstr("OpenBSD", $this->user_agent))
      $os = "OpenBSD";
    else if (strstr("IRIX", $this->user_agent))
      $os = "IRIX";
    else if (strstr("OSF", $this->user_agent))
      $os = "OSF";

    return $os;
  }




  /*
  ** Function: _identifyClientAs
  ** Input: STRING category
  ** Output: STRING or FALSE
  ** Description: Check if the current visitor matches a specified category.
  */
  function _identifyClientAs($category) {

    switch ($category) {
      case "spider":
        $library_data = $this->spider_library;
        $subject = $this->user_agent;
        break;
      case "search_engine":
        $library_data = $this->search_engine_library;
        $subject = $this->url["host"];
        break;
    }


    $library_file = @file($library_data);

    # Compare the spider library with the user_agent.
    # If there are any matches, the current page has
    # been requested by a spider or a robot.

    for ($i = 0; $i < sizeof($library_file); $i++) {
      $library_line = explode("|", $library_file[$i]);
      if (@eregi($library_line[0], $subject))
        return $library_line[1];
    }

    return FALSE;
  }






  //------------------//
  // Output functions //
  //------------------//




  /*
  ** Function: _displayTopList
  ** Input:
  ** Output: VOID
  ** Description: Displays a toplist of a specified category.
  */
  function _displayTopList($time_period, $category, $count) {
  
    $head_string = $this->string["toplist_head"][$category];
  
    if (!strcmp($category, "impression")) {
      $time = explode("_", $time_period);
      $month = $time[1];
      $year = $time[2];
      $time_string = " [".$month."/".$year."] ";
      $temp_file = @file($this->data_dir.$time_period.".log");
      
      # Load the unsorted data in an array.
      for ($i = 15; $i < sizeof($temp_file); $i++)
        $sort_file[$i - 15] = $temp_file[$i];
    }
    
    else if (file_exists($this->log_data[$category])) {
    
      # Load the unsorted data in an array.
      $sort_file = @file($this->log_data[$category]);
    }

    if (isset($sort_file)) {
      # Sort the array by the specified column.
      $toplist = $this->_getSortedArray($sort_file, 1);
      $total_hits = $this->_getSumOfColumn($sort_file, 1);

      # Prepare the toplist array for output.
      if (sizeof($sort_file) <= $count)
          $top_number = sizeof($sort_file);
      else $top_number = $count;
      
      $toplist["headline"] = "TOP ".$top_number." ";
      $toplist["headline"] .= $this->string["toplist_head"][$category];
      if (!strcmp($category, "impression"))
        $toplist["headline"] .= $time_string;
      $toplist["headline"] .= " (".$this->string["toplist_head"]["of_string"]." ";
      $toplist["headline"] .= sizeof($sort_file).")";
      
      $toplist["name"] = $toplist[0];

      for ($i = 0; $i < sizeof($toplist[1]); $i++) {
        $toplist["hits"]["absolute"][$i] = $toplist[1][$i];
        $toplist["hits"]["relative"][$i] = round($toplist[1][$i] / $total_hits * 100);
      }

      for ($i = 0; $i < sizeof($toplist["hits"]["relative"]); $i++)
        $toplist["bar_width"][$i] = $toplist["hits"]["absolute"][$i]
                                    / $toplist["hits"]["absolute"][0]
                                    * $this->MAX_HORIZONT_BAR;

      # Display the toplist on the screen.
      include($this->toplist_template);
      
    }
  }




  /*
  ** Function: _getTrafficStatistics
  ** Input: STRING month, STRING year
  ** Output: STRING traffic[]
  ** Description: Generate an array with all the traffic information.
  */
  function _getTrafficStatistics($time_period) {

    $log_data  = $this->data_dir.$time_period.".log";
    $traffic_file = file($log_data);

    # extract the plain data from the log_file
    $traffic["impressions"]["hour"] = explode("|", $traffic_file[1]);
    $traffic["impressions"]["month"] = explode("|", $traffic_file[2]);
    $traffic["impressions"]["year"] = explode("|", $traffic_file[3]);
    $traffic["impressions"]["total"] = explode("|", $traffic_file[4]);
    $traffic["impressions"]["record"] = explode("|", $traffic_file[5]);

    $traffic["visits"]["hour"] = explode("|", $traffic_file[8]);
    $traffic["visits"]["month"] = explode("|", $traffic_file[9]);
    $traffic["visits"]["year"] = explode("|", $traffic_file[10]);
    $traffic["visits"]["total"] = explode("|", $traffic_file[11]);
    $traffic["visits"]["record"] = explode("|", $traffic_file[12]);
    
    # hits per hour should be an average per day (same for visits)
    for ($i = 0; $i < sizeof($traffic["impressions"]["hour"]); $i++) {

      # loop through all hours and divide hits through number of days
      $traffic["impressions"]["hour"][$i] = round($traffic["impressions"]["hour"][$i]
                                                  / $this->day, 1);

      $traffic["visits"]["hour"][$i] = round($traffic["visits"]["hour"][$i] / $this->day, 1);
    }
    
    return $traffic;
  }
  

  

  /*
  ** Function: _displayTrafficStatistics
  ** Input: STRING mode
  ** Output: VOID
  ** Description: Displays the traffic statistics of a specified time period.
  */
  function _displayTrafficStatistics($mode, $time_period) {

    # Extract the month and the year out of the time_period
    $time = explode("_", $time_period);
    $month = $time[1];
    $year = $time[2];

    # Get the number of days of specified month.
    if ($month == "2")
      $daysPerMonth = 28;
    else if (($month == "4") || ($month == "6") || ($month == "9") || ($month == "11"))
      $daysPerMonth = 30;
    else $daysPerMonth = 31;

    $traffic = $this->_getTrafficStatistics($time_period);

    switch ($mode) {
      case "month":
        $traffic["headline"] = $this->string["traffic_head"]["monthly_stat"];
        $traffic["headline"] .= " ".$month."/".$year." - ";
        $traffic["headline"] .= $this->string["traffic_head"]["requests_day"];
        $MAX_1 = 16;
        $MAX_2 = $daysPerMonth;
        # Generate the dates.
        for ($i = 0; $i < $MAX_2; $i++)
          $traffic["date"][$i] = ($i + 1).".".$month.".";
        break;
      case "hour":
        $traffic["headline"] = $this->string["traffic_head"]["monthly_stat"];
        $traffic["headline"] .= " ".$month."/".$year." - ";
        $traffic["headline"] .= $this->string["traffic_head"]["requests_hour"];
        $traffic["headline"] .= " ".$this->string["traffic_head"]["mean"];
        $MAX_1 = 12;
        $MAX_2 = 24;
        # Generate the time zones.
        for ($i = 0; $i < $MAX_2; $i++)
          $traffic["date"][$i] = $i.":00";
        break;
      case "year":
        $traffic["headline"] = $this->string["traffic_head"]["annual_stat"];
        $traffic["headline"] .= " ".$year." - ";
        $traffic["headline"] .= $this->string["traffic_head"]["requests_month"];
        $MAX_1 = 12;
        $MAX_2 = 12;
        # Generate the dates.
        for ($i = 0; $i < $MAX_2; $i++)
          $traffic["date"][$i] = ($i + 1)."/".$year;
        break;
    }
    
   
    # Get the highest value.
    $temp_array["visits"] = $traffic["visits"][$mode];
    $temp_array["impressions"] = $traffic["impressions"][$mode];
    rsort($temp_array["visits"]);
    rsort($temp_array["impressions"]);
    $maximum["impressions"] = $temp_array["impressions"][0];
    $maximum["visits"] = $temp_array["visits"][0];
    
    # Set the height of the bars.
    for ($i = 0; $i < sizeof($traffic["visits"][$mode]) - 1; $i++) {
    
      $traffic["visits"][$mode]["height"][$i] = $traffic["visits"][$mode][$i]
                                                / $maximum["visits"]
                                                * $this->MAX_VERT_BAR_VISITS;
                                                
      $traffic["impressions"][$mode]["height"][$i] = $traffic["impressions"][$mode][$i]
                                                     / $maximum["impressions"]
                                                     * $this->MAX_VERT_BAR_IMPRESSIONS;
    }
    
    include($this->traffic_template);

  }
  
  


  /*
  ** Function: _displayOverview
  ** Input: VOID
  ** Output: VOID
  ** Description: Displays the traffic statistics summary (todays request, record days,...).
  */
  function _displayOverview() {
  
    # Get the current traffic statistics.
    $traffic = $this->_getTrafficStatistics("month_".date("n")."_".date("Y"));
    
    $overview["visits"]["today"] = $traffic["visits"]["month"][$this->day - 1];
    $overview["visits"]["record"]["value"] = $traffic["visits"]["record"][0];
    
    $overview["visits"]["record"]["date"]
    = $this->_getFormatedTime($traffic["visits"]["record"][1], "day");
    
    $overview["visits"]["total"] = $traffic["visits"]["total"][0];
    $overview["since"] = $this->_getFormatedTime($traffic["visits"]["total"][1], "day");
    
    # Compute the visits per day.
    $overview["visits"]["mean"]
    = round($traffic["visits"]["total"][0]
            / ((time() - $traffic["visits"]["total"][1]) / 86400));
    
    $overview["impressions"]["today"] = $traffic["impressions"]["month"][$this->day - 1];
    $overview["impressions"]["record"]["value"] = $traffic["impressions"]["record"][0];
    
    $overview["impressions"]["record"]["date"]
    = $this->_getFormatedTime($traffic["impressions"]["record"][1], "day");
    
    $overview["impressions"]["total"] = $traffic["impressions"]["total"][0];
    
    # Compute the impressions per day.
    $overview["impressions"]["mean"]
    = round($traffic["impressions"]["total"][0]
            / ((time() - $traffic["impressions"]["total"][1]) / 86400));
    
    include($this->overview_template);

  }



    
}


?>
