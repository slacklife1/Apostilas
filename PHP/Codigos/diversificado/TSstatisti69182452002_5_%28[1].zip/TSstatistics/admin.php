<?php

/************************************************
*                                               *
*  TSstatistics                                 *
*                                               *
*  by Thomas Schuster                           *
*  http://www.TSinter.net                       *
*                                               *
*  file: admin.php                              *
*  version: 2.5                                 *
*  license: GNU General Public License          *
*  created: 04.04.2002                          *
*  email: admin@TSinter.net                     *
*                                               *
*                                               *
*  Object oriented traffic analyser. Needs no   *
*  database. Tracks the visitors of a website.  *
*  Filters out over 100 robots. Reload restric- *
*  tion. Displays hits per hour/day/month,      *
*  various toplists, all graphical. Auto back-  *
*  up. Administration center.                   *
*                                               *
*  Copyright (c) 2001-2002 TSinter.net          *
*  All rights reserved.                         *
*                                               *
************************************************/


//----------------------------------------//
// Specify the relative path to the       //
// script directory.                      //
// (ex. "/include/scripts/TSstatistics/") //
//----------------------------------------//
$script_path = "/path/";


//-------------------------------//
// Do not change anything below! //
//-------------------------------//
include($DOCUMENT_ROOT.$script_path."config.php");

echo($statistics->css);

if (isset($action) && !strcmp($action, "logout"))
  session_unregister("logged_in");


if (isset($login) && $login) {
  # Somebody has pressed the login button.
  if (($password != "") && ($name != ""))
    $message = $statistics->_login($name, $password);
  else $message = "name und/oder passwort fehlen";
}

if (session_is_registered("logged_in")) {

  if (isset($action)) {

    switch ($action) {

      case "manualBackup":
        # Admin wants to make a backup of all datafiles.
        $message = $statistics->_manualBackup();
        break;
      case "restoreBackup":
        # Admin wants to restore data from backup files.
        $message = $statistics->_restoreBackup();
        break;

    }

  }


  ?>

  <table class="statisticsAdmin">
    <tr>
      <td class="statisticsAdminHeadline">
        TSstatistics &raquo; Administration Center
      </td>
    </tr>
    <tr>
      <td class="statisticsAdminMessage">
        <?php if (isset($message)) echo($message); ?>
      </td>
    </tr>
    <tr>
      <td class="statisticsAdminMain">
        <?php echo($statistics->string["admin"]["time_current"]); ?> <?php echo($statistics->_getFormatedTime(time(), "minute")); ?> <br />
        <?php echo($statistics->string["admin"]["time_backup"]); ?> <?php echo($statistics->_getTimeOfLastBackup()); ?> <br />
        <br />
        <a href="<?php echo($PHP_SELF."?action=logout"); ?>">Logout</a> <br />
        <br />
        <a href="<?php echo($PHP_SELF."?action=manualBackup\">".$statistics->string["admin"]["manual_backup"]); ?></a> <br />
        <a href="<?php echo($PHP_SELF."?action=restoreBackup\">".$statistics->string["admin"]["restore"]); ?></a> <br />
        <br />
        <?php echo($statistics->string["admin"]["see_tracks"]); ?><br />
        <?php
        $user_tracks = $statistics->_getListOfLogfiles("track");
        for ($i = 0; $i < sizeof($user_tracks); $i++) {
          echo("<a href=".$user_tracks[$i]["path"]." target=\"blank\">".$user_tracks[$i]["name"]."</a> (".$user_tracks[$i]["size"]." kb)<br />");
        }
        ?>
        <br />
      </td>
    </tr>
    <tr>
      <td class="statisticsAdminFooter">
        <a href="http://php.TSinter.net/statistics/index.php" target="_blank">TSstatistics</a>&trade; 
        &copy; 2001-2002 
        <a href="http://www.TSinter.net" target="_blank">TSinter.net</a>
      </td>
    </tr>
  </table>

  <?php

}

else {

  ?>
	<form name="form1" method="post" action="<?php echo($PHP_SELF); ?>">
	  <table class="statisticsAdminLogin">
		<tr>
		  <td class="statisticsAdminHeadline" colspan="2">
			  TSstatistics &raquo; Administration Center &raquo; Login
		  </td>
		<tr>
		  <td class="statisticsAdminMessage" colspan="2">
			<?php if (isset($message)) echo($message); ?>
		  </td>
		</tr>
		<tr>
  		<td class="statisticsAdminLoginRight">Name:</td>
      <td class="statisticsAdminLoginLeft"> 
        <input class="statisticsAdminLoginLeft" type="text" name="name">
  		</td>
		</tr>
		<tr>
  		<td class="statisticsAdminLoginRight"><?php echo($statistics->string["admin"]["password"]); ?>:</td>
      <td class="statisticsAdminLoginLeft"> 
        <input class="statisticsAdminLoginLeft" type="text" name="password">
      </td>
		</tr>
    <tr>
      <td class="statisticsAdminLoginRight">&nbsp; </td>
      <td class="statisticsAdminLoginLeft"> 
        <input class="statisticsAdminLoginSubmit" type="submit" name="login" value="Login">
        <br />
        <br />
      </td>
		</tr>
		<tr>
		  <td class="statisticsAdminFooter" colspan="2">
			  <a href="http://php.TSinter.net/statistics/index.php" target="_blank">TSstatistics</a>&trade; 
        &copy; 2001-2002 
        <a href="http://www.TSinter.net" target="_blank">TSinter.net</a>
		  </td>
		</tr>
	  </table>
	</form>

  <?php
}

?>
