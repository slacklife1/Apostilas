<?php

/************************************************
*                                               *
*  TSstatistics                                 *
*                                               *
*  by Thomas Schuster                           *
*  http://www.TSinter.net                       *
*                                               *
*  file: overview_template.php                  *
*  version: 2.5                                 *
*  license: GNU General Public License          *
*  created: 04.04.2002                          *
*  email: admin@TSinter.net                     *
*                                               *
*                                               *
*  Object oriented traffic analyser. Needs no   *
*  database. Tracks the visitors of a website.  *
*  Filters out over 100 robots. Reload restric- *
*  tion. Displays hits per hour/day/month,      *
*  various toplists, all graphical. Auto back-  *
*  up. Administration center.                   *
*                                               *
*  Copyright (c) 2001-2002 TSinter.net          *
*  All rights reserved.                         *
*                                               *
************************************************/

?>

<table class="statisticsOverview">
  <tr>
    <td class="statisticsOverviewMenu">
      -
    </td>
    <td class="statisticsOverviewMenu">
      <?php echo($this->string["overview"]["today"]); ?>
    </td>
    <td class="statisticsOverviewMenu" colspan="2">
      <?php echo($this->string["overview"]["record"]); ?>
    </td>
    <td class="statisticsOverviewMenuSince">
      <?php echo($this->string["overview"]["total"]." ".$this->string["overview"]["since"]." ".$overview["since"]); ?>
    </td>
    <td class="statisticsOverviewMenuMean">
      &Oslash; <?php echo($this->string["overview"]["per_day"]); ?>
    </td>
  </tr>
  <tr>
    <td class="statisticsOverviewMenu">
      <?php echo($this->string["visits"]); ?>
    </td>
    <td class="statisticsOverviewValue">
      <?php echo($overview["visits"]["today"]); ?>
    </td>
    <td class="statisticsOverviewValue">
      <?php echo($overview["visits"]["record"]["value"]); ?>
    </td>
    <td class="statisticsOverviewValue">
      <?php echo($overview["visits"]["record"]["date"]); ?>
    </td>
    <td class="statisticsOverviewValue">
      <?php echo($overview["visits"]["total"]); ?>
    </td>
    <td class="statisticsOverviewValue">
      <?php echo($overview["visits"]["mean"]); ?>
    </td>
  </tr>
  <tr>
    <td class="statisticsOverviewMenu">
      <?php echo($this->string["impressions"]); ?>
    </td>
    <td class="statisticsOverviewValue">
      <?php echo($overview["impressions"]["today"]); ?>
    </td>
    <td class="statisticsOverviewValue">
      <?php echo($overview["impressions"]["record"]["value"]); ?>
    </td>
    <td class="statisticsOverviewValue">
      <?php echo($overview["impressions"]["record"]["date"]); ?>
    </td>
    <td class="statisticsOverviewValue">
      <?php echo($overview["impressions"]["total"]); ?>
    </td>
    <td class="statisticsOverviewValue">
      <?php echo($overview["impressions"]["mean"]); ?>
    </td>
  </tr>
</table>
