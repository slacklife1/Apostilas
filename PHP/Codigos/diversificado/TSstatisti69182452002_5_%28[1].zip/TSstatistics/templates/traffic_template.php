<?php

/************************************************
*                                               *
*  TSstatistics                                 *
*                                               *
*  by Thomas Schuster                           *
*  http://www.TSinter.net                       *
*                                               *
*  file: traffic_template.php                   *
*  version: 2.5                                 *
*  license: GNU General Public License          *
*  created: 04.04.2002                          *
*  email: admin@TSinter.net                     *
*                                               *
*                                               *
*  Object oriented traffic analyser. Needs no   *
*  database. Tracks the visitors of a website.  *
*  Filters out over 100 robots. Reload restric- *
*  tion. Displays hits per hour/day/month,      *
*  various toplists, all graphical. Auto back-  *
*  up. Administration center.                   *
*                                               *
*  Copyright (c) 2001-2002 TSinter.net          *
*  All rights reserved.                         *
*                                               *
************************************************/


for ($j = 0; $j < $MAX_2; $j = $j + $MAX_1) {
?>
<table class="statisticsTraffic" border="0">
  <?php

  // Headline
  if ($j == 0) {
    echo('<tr>');
    echo('<td class="statisticsTrafficHeadline" colspan="2">');
    echo($traffic["headline"]);
    echo('</td>');
    echo('</tr>');
  }
  ?>
  <tr>
    <td class="statisticsTrafficContent">
      <table class="statisticsTrafficContent" border="0">
        <tr>
          <?php

          // Bars
          for ($i = 0; ($i < $MAX_1) && ($i + $j < $MAX_2); $i++) {
            echo('<td class="statisticsTrafficContentBar" valign="bottom">');

            echo('<img class="statisticsTrafficContentBar" src="'.$this->bar_image["vertical"]["blue"].'" width="10"');
            echo('height="'.$traffic["visits"][$mode]["height"][$i + $j].'" alt="visits" />');

            echo('<img class="statisticsTrafficContentBar" src="'.$this->bar_image["vertical"]["green"].'" width="10"');
            echo('height="'.$traffic["impressions"][$mode]["height"][$i + $j].'" alt="impressions" />');
            echo('</td>');
          }
          ?>
        </tr>
        <tr>
          <?php

          // Dates
          for ($i = 0; ($i < $MAX_1) && ($i + $j < $MAX_2); $i++) {
            echo('<td class="statisticsTrafficContentDate">');
            echo($traffic["date"][$i + $j]);
            echo('</td>');
          }
          ?>
        </tr>
        <tr>
          <?php

          // Visits
          for ($i = 0; ($i < $MAX_1) && ($i + $j < $MAX_2); $i++) {
            echo('<td class="statisticsTrafficContentVisit">');
            echo($traffic["visits"][$mode][$i + $j]);
            echo('</td>');
          }
          ?>
        </tr>
        <tr>
          <?php

          // Impressions
          for ($i = 0; ($i < $MAX_1) && ($i + $j < $MAX_2); $i++) {
            echo('<td class="statisticsTrafficContentImpression">');
            echo($traffic["impressions"][$mode][$i + $j]);
            echo('</td>');
          }
          ?>
        </tr>
      </table>
    </td>
    <?php

    // Legend
    if ($j == 0) {
      ?>
      <td class="statisticsTrafficLegend">
        <table class="statisticsTrafficLegend">
          <tr>
            <td class="statisticsTrafficLegendBody">
              <img src="<?php echo($this->bar_image["horizontal"]["blue"]); ?>" width="20" height="10" alt="Visits" />
              <?php echo($this->string["visits"]); ?> <br />
              <img src="<?php echo($this->bar_image["horizontal"]["green"]); ?>" width="20" height="10" alt="Impressions" />
              <?php echo($this->string["impressions"]); ?>
            </td>
          </tr>
        </table>
      </td>
      <?php
      }
  ?>
  </tr>
</table>
<?php
}
?>
