<?php

/************************************************
*                                               *
*  TSstatistics                                 *
*                                               *
*  by Thomas Schuster                           *
*  http://www.TSinter.net                       *
*                                               *
*  file: toplist_template.php                   *
*  version: 2.5                                 *
*  license: GNU General Public License          *
*  created: 04.04.2002                          *
*  email: admin@TSinter.net                     *
*                                               *
*                                               *
*  Object oriented traffic analyser. Needs no   *
*  database. Tracks the visitors of a website.  *
*  Filters out over 100 robots. Reload restric- *
*  tion. Displays hits per hour/day/month,      *
*  various toplists, all graphical. Auto back-  *
*  up. Administration center.                   *
*                                               *
*  Copyright (c) 2001-2002 TSinter.net          *
*  All rights reserved.                         *
*                                               *
************************************************/

?>

<table class="statisticsToplist" border="0">
  <tr>
    <td class="statisticsToplistHeadline" colspan="4">

      <?php

      // Headline
      echo($toplist["headline"]);

      ?>

    </td>
  </tr>

  <?php

  for ($i = 0; ($i < $count) && ($i < sizeof($sort_file)); $i++) {

    // Name
    echo('<tr>');
    echo('<td class="statisticsToplistName">');
    echo($toplist[0][$i]);
    echo('</td>');

    // Bar
    echo('<td class="statisticsToplistBar">');
    echo('<img class="statisticsToplistBar" src="'.$this->bar_image["horizontal"]["blue"].'" width="'.$toplist["bar_width"][$i].'" height="10" alt="" />');
    echo('</td>');

    // Relative number as a percentage
    echo('<td class="statisticsToplistRelative">');
    echo($toplist["hits"]["relative"][$i]." %");
    echo('</td>');

    // Absolute number
    echo('<td class="statisticsToplistAbsolute">');
    echo("(".$toplist["hits"]["absolute"][$i].")");
    echo('</td>');
    echo('</tr>');

  }

  ?>

</table>
