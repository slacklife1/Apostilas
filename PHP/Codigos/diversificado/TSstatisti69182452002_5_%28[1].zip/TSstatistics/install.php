<?php

/************************************************
*                                               *
*  TSstatistics                                 *
*                                               *
*  by Thomas Schuster                           *
*  http://www.TSinter.net                       *
*                                               *
*  file: install.php                            *
*  version: 2.5                                 *
*  license: GNU General Public License          *
*  created: 04.04.2002                          *
*  email: admin@TSinter.net                     *
*                                               *
*                                               *
*  Object oriented traffic analyser. Needs no   *
*  database. Tracks the visitors of a website.  *
*  Filters out over 100 robots. Reload restric- *
*  tion. Displays hits per hour/day/month,      *
*  various toplists, all graphical. Auto back-  *
*  up. Administration center.                   *
*                                               *
*  Copyright (c) 2001-2002 TSinter.net          *
*  All rights reserved.                         *
*                                               *
************************************************/


//----------------------------------------//
// Specify the relative path to the       //
// script directory.                      //
// (ex. "/include/scripts/TSstatistics/") //
//----------------------------------------//
$script_path = "/path/";


//-------------------------------//
// Do not change anything below! //
//-------------------------------//
include($DOCUMENT_ROOT.$script_path."config.php");

if ($install) {
  # Somebody has pressed the install button.
  if (($name != "") && ($password != "") && ($password_repeat != "")) {

    if (!strcmp($password, $password_repeat)) {

      # Add this user to the administrator database.
      $message = $statistics->_install($name, $password);

      if (file_exists($statistics->password_data)) {

        # To prevent others from getting also admin rights,
        # delete this webpage from server.

        $statistics->_delete($statistics->doc_root.$statistics->webpage);

        if (file_exists($statistics->doc_root.$statistics->webpage)) {
          # Failed to delete this webpage.
          $message .= "Warning: Delete ".$statistics->webpage." manually from your server!";
        }
        else $message .= "Now <a href=\"admin.php\">login</a>";
      }
    }
    else $message = "Error: Passwords are different. Please try again.";
  }
  else $message = "Please fill out all fields.";
}

?>

<form name="form1" method="post" action="<?php echo($PHP_SELF); ?>">
  <table class="statisticsAdminLogin">
  <tr>
    <td class="statisticsAdminHeadline" colspan="2">
    headline login
    </td>
  <tr>
    <td class="statisticsAdminMessage" colspan="2">
    <?php echo($message); ?>
    </td>
  </tr>
  <tr>
    <td class="statisticsAdminLoginRight"> name:</td>
    <td class="statisticsAdminLoginLeft"> 
      <input type="text" name="name">
    </td>
  </tr>
  <tr>
    <td class="statisticsAdminLoginRight"> password:</td>
    <td class="statisticsAdminLoginLeft"> 
      <input type="text" name="password">
    </td>
  </tr>
  <tr>
    <td class="statisticsAdminLoginRight">repeat password:</td>
    <td class="statisticsAdminLoginLeft"> 
      <input type="text" name="password_repeat">
    </td>
  </tr>
  <tr>
    <td class="statisticsAdminLoginRight">&nbsp; </td>
    <td class="statisticsAdminLoginLeft"> 
      <input type="submit" name="install" value="Install TSstatistics 2.5 now!">
    </td>
  </tr>
  <tr>
    <td class="statisticsAdminFooter" colspan="2">
      footer
    </td>
  </tr>
  </table>
</form>
        
