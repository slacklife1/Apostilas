Title: TSstatistics 2.5
Description: TSstatistics 2.5 is an object oriented analysis tool, which generates extensive statistics about the traffic of a website.
Features: 
counting the visitors of the website (via session management and ip-comparison with a reload restriction) 
counting the page impressions of every webpage 
track the visitors way through the website 
graphical display of the request per hour/day/month/year 
spider/robots are not counted 
search engines and search queries are logged 
systems of visitors are logged 
auto backup 
administration center
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=518&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
