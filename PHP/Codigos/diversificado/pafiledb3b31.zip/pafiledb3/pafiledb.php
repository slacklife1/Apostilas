<?php
/*
  paFileDB 3.0
  �2001 PHP Arena
  Written by Todd
  todd@phparena.uni.cc
  http://www.phparena.uni.cc
  Keep all copyright links on the script visible
  Please read the license included with this script for more information.
*/
if (file_exists("./install.php")) { die("Error: The file install.php (paFileDB installer) still exists on the server! This is a security risk! Please delete the file to continue using paFileDB."); }
/* this section is for Global Vars should they get turned off 
 $action = $_GET['action']; 
 if (empty($action)) {$action = $_POST['action'];}  
 $file = $_GET['file']; 
 if (empty($file)) {$file = $_POST['file'];}  
 $id = $_GET['id']; 
 if (empty($id)) {$id = $_POST['id'];}  
 $login = $_GET['login']; 
 if (empty($login)) {$login = $_POST['login'];}  
 $ad = $_GET['ad']; 
 if (empty($ad)) {$ad = $_POST['ad'];}  
 $edit = $_GET['edit']; 
 if (empty($edit)) {$edit = $_POST['edit'];}  
 $logged = $_POST['logged']; 
 $formpass = $_POST['formpass']; 
 $formname = $_POST['formname']; 
 $delete = $_GET['delete']; 
 if (empty($delete)) {$delete = $_POST['delete'];}  
 $upload = $_POST['upload']; 
 $add = $_POST['add']; 
 $select = $_GET['select']; 
 if (empty($select)) {$select = $_POST['select'];}  
 $category = $_GET['category']; 
 if (empty($category)) {$category = $_POST['category'];}  
 $rate = $_POST['rate']; 
 $rating = $_POST['rating']; 
 end of global vars */
$starttime = microtime();	
$starttime = explode(" ",$starttime);
$starttime = $starttime[1] + $starttime[0];
session_save_path("./sessions");
session_start();

$logged = "";
if ($action == "download") {
	ob_start();
	require "./includes/mysql.php";
	$pafiledb_sql->connect($db);
        $config = $pafiledb_sql->query($db,"SELECT * FROM $db[prefix]_settings",1);
	include "./includes/download.php";
	ob_end_clean();
	exit();
}
require "./includes/mysql.php";
require "./includes/functions.php";
$pafiledb_sql->connect($db);
$config = $pafiledb_sql->query($db,"SELECT * FROM $db[prefix]_settings",1);
require "./lang/$config[13].php";
include "./includes/admin/auth.php";
if ($logged == 1 && $ad == "backupdb") {
	include "includes/admin/backupdb.php";
	exit();
}
?>
<html>
<head>
<!--Download database powered by paFileDB 3.0. Visit http://www.phparena.uni.cc/pafiledb for your own free copy!-->
<!--If you're actually reading these comments, then you need a life....................-->
<title>paFileDB 3.0</title>
<style type="text/css">
<?php include "./styles/$config[11]/style.css"; ?>
</style>
<script language="JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
</head>
<body>
<center>
<!--Begin main table-->
<table width="100%" height="99%" border="0" cellpadding="2" cellspacing="0" bgcolor="#FFFFFF" class="table">
<tr>
<td width="100%" height="100%" valign="top">
<!--Begin header table-->
<table width="100%" height="100" border="0" cellpadding="2" cellspacing="0" class="table">
<tr>
<td width="25%" valign="center" align="center">
<a href="pafiledb.php"><img src="styles/<?php echo $config[11]; ?>/images/logo.gif" border="0"></a>
</td><td width="75%" valign="center" align="right">
<a href="pafiledb.php?action=search"><img src="styles/<?php echo $config[11]; ?>/images/search.gif" border="0"></a>&nbsp;&nbsp;<a href="pafiledb.php?action=stats"><img src="styles/<?php echo $config[11]; ?>/images/stats.gif" border="0"></a>&nbsp;&nbsp;<a href="<?php echo $config[5]; ?>"><img src="styles/<?php echo $config[11]; ?>/images/homepage.gif" border="0"></a>
</td></tr></table>
<!--End header table-->
<!--Begin page table-->
<?php
if ($logged == 1 && $ad != "logout") {
	$width = 100;
} else {
	$width = 80;
}
?>
<table width="<?php echo $width; ?>%" height="30" border="0" cellpadding="2" cellspacing="0" class="table" align="center">
<tr>
<td width="100%" valign="top" align="left" colspan="2">
<?php
switch ($action) {
	case category:
		include "./includes/category.php";
	break;
	case file:
		include "./includes/file.php";
	break;
	case viewall:
		include "./includes/viewall.php";
	break;
	case search:
		include "./includes/search.php";
	break;
	case license:
		include "./includes/license.php";
	break;
	case rate:
		include "./includes/rate.php";
	break;
	case admin:
		include "./includes/admin.php";
	break;
	case email:
		include "./includes/email.php";
	break;
	case stats:
		include "./includes/stats.php";
	break;
	default:
		include "./includes/main.php";
	break;
}
?>
</td></tr>
<tr>
<td width="50%" align="left">
<?php jumpmenu($db,$HTTP_SERVER_VARS['REQUEST_URI'],$pafiledb_sql,$str); ?>
</td><td width="50%" align="right"><?php echo "$str[time] $config[8]"; ?></td></tr></table>
<!--End page table-->
<!--Begin footer table-->
<table width="100%" height="30" border="0" cellpadding="2" cellspacing="0" class="footer">
<tr>
<td width="100%" valign="center" align="center">
<?php echo $str[power]; ?> paFileDB 3.0 Beta 3.1<br>�2002 <a href="http://www.phparena.net" class="small" target="phparena">PHP Arena</a>
</td></tr>
<tr><td width="100%" valign="center" align="center">
<?php
$endtime = microtime();
$endtime = explode(" ",$endtime);
$endtime = $endtime[1] + $endtime[0];
$stime = $endtime - $starttime;
if ($config[12] == 1) {
?>
<table width="30%" border="1" cellpadding="2" class="stats" bordercolor="#000000">
<tr><td width="50%" align="left"><?php echo $str[exectime]; ?>:</td><td width="50%" align="right"><?php echo round($stime,4); ?> Seconds</td></tr>
<tr><td width="50%" align="left"><?php echo $str[numqueries]; ?>:</td><td width="50%" align="right"><?php echo $query_count; ?> Queries</td></tr>
</table>
<?php
if ($showqueries == 1) {
	?>
	<p>
	<table width="100%" border="1" cellpadding="2" class="headertable" bordercolor="#000000">
	<tr><td width="100%" class="headercell" align="center"><b>Queries Used</b></td></tr>
	<?php echo $queries_used; ?>
	</table>
<?php
}
}
?>
</table>
<!--End footer table-->
<!--End main table-->
</td></tr></table>