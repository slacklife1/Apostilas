<?php
/*
  paFileDB 3.0
  �2001 PHP Arena
  Written by Todd
  todd@phparena.uni.cc
  http://www.phparena.uni.cc
  Keep all copyright links on the script visible
  Please read the license included with this script for more information.

  ##########
  #paFileDB 3.0 Language File
  #Portuguese - Brasilian
  #Translated by Kallaur
  ##########

  ##########	
  #If you are translating this file, DO NOT translate anything in brackets, such as {something}, any variables ($something) or arrays #($something[somethingelse]), or HTML tags (<something></something>) or else parts of the script will not work
  #Also, do not delete any lines in this script
  ##########

*/

//Start Beta 2 Language File
$str[time] = "Todos os hor�rios est�o em";
$str[power] = "Desenvolvido por";
$str[exectime] = "Tempo de execu��o";
$str[numqueries] = "MySQL Queries Usadas";
$str[adminops] = "Op��es Admin";
$str[mainpage] = "P�gina Principal";
$str[addcat] = "Add Categoria";
$str[editcat] = "Editar Categoria";
$str[delcat] = "Deletar Category";
$str[ordercat] = "Reorder Categorias";
$str[category] = "Categora";
$str[files] = "�tens";
$str[jump] = "Selecione Categoria";
$str[logged] = "Logado como";
$str[admincenter] = "�rea Admin";
$str[logout] = "Logout";
$str[file] = "�tem";
$str[date] = "Data Adicionada";
$str[rating] = "Avalia��es";
$str[dls] = "Downloads";
$str[email] = "Envie por e-mail a um amigo";
$str[emailinfo] = "Se voc� quiser informar um amigo sobre este �tem, preencha e envie este formul�rio e um email ser� enviado a ele!";
$str[yname] = "Seu Nome";
$str[yemail] = "Seu E-mail";
$str[fname] = "Nome do Amigo";
$str[femail] = "E-mail do Amigo";
$str[esub] = "T�tulo da Mensagem";
$str[etext] = "Texto do E-mail";
$str[defaultmail] = "Eu achei que voc� estaria interessado em fazer o download do arquivo em";
$str[semail] = "Enviar E-mail";
$str[msg] .= "Ol� $friend[name],\n";
$str[msg] .= "$email[message]\n\n";
$str[msg] .= "----------\n";
$str[msg] .= "Este E-mail foi enviado atrav�s \"{dbname}\" database. O webmasters de \"{dbname}\" n�o tem responsabilidade sobre os E-mails enviados atrav�s do site.";
$str[econf] = "Obrigado! Seu E-mail foi enviado para o endere�o de E-mail de $friend[name]'s.";
$str[editfile] = "Editar �tem";
$str[deletefile] = "Deletar �tem";
$str[desc] = "Descri��o";
$str[creator] = "Autor";
$str[version] = "Vers�o";
$str[scrsht] = "Screenshot";
$str[docs] = "Documenta��o";
$str[lastdl] = "�ltimo Download";
$str[never] = "Nunca";
$str[votes] = "votos";
$str[download] = "Fazer Download";
$str[rate] = "Avalie o �tem";
$str[license] = "Termo de Compromisso";
$str[licensewarn] = "Voc� tem que concordar com o Termo de Compromisso para fazer o download";
$str[iagree] = "Concordo";
$str[dontagree] = "Discordo";
$str[rerror] = "Desculpe, voc� j� avalio este �tem.";
$str[rateinfo] = "Voc� est� para avaliar o �tem <i>{filename}</i>. Selecione a op��o abaixo. 1 � p�ssimo, 10 � �timo.";
$str[rconf] = "Voc� avaliou o �tem <i>{filename}</i> em {rate}. A nova m�dia de avalia��o � $nrating {newrating}/10.";
$str[stats] = "Stats";
$str[statstext] .= "Existem  $num[files] �tens em  $num[cats] categorias<br>";
$str[statstext] .= "O �tem mais antigo � <a href=\"pafiledb.php?action=file&id= $oldest[file_id]\"> $oldest[file_name]</a><br>";
$str[statstext] .= "O �tem mais novo � <a href=\"pafiledb.php?action=file&id= $newest[file_id]\"> $newest[file_name]</a><br>";
$str[statstext] .= "O menos popular baseado em avalia��es � <a href=\"pafiledb.php?action=file&id= $lpopular[file_id]\"> $lpopular[file_name]</a> with a rating of $least/10<br>";
$str[statstext] .= "O mais popular baseado em avalia��es � <a href=\"pafiledb.php?action=file&id= $popular[file_id]\"> $popular[file_name]</a> with a rating of  $most/10<br>";
$str[statstext] .= "O menos popular baseado em downloads � <a href=\"pafiledb.php?action=file&id= $leastdl[file_id]\"> $leastdl[file_name]</a> with  $leastdl[file_dls] downloads<br>";
$str[statstext] .= "O mais popular baseado em downloads � <a href=\"pafiledb.php?action=file&id= $mostdl[file_id]\"> $mostdl[file_name]</a> with  $mostdl[file_dls] downloads<br>";
$str[statstext] .= "Foram feitos  $totaldls[0] downloads<br>";
$str[statstext] .= "A m�dia de de avalia��es � $avg/10<br>";
$str[statstext] .= "A m�dia de downloads de cada �tem � $avgdls<br>";
$str[search] = "Buscar";
$str[results] = "Resultados para";
$str[nomatches] = "Desculpe, nehum resultado foi encontrado para";
$str[matches] = "resultados foram encontrados para";
$str[sfor] = "Busca para";
$str[viewall] = "Ver todos os �tens";
$str[vainfo] = "Ver todos os �tens no Banco de Dados";
$str[next] = "Pr�ximo";
$str[prev] = "Anterior";
$str[pagenums] = "P�ginas";
//You have reached Line 100. If you're not tired now, you will be soon.
$str[acinfo] = "Benvindo a �rea Administrativa de seu paFileDB 3. Voc� pode usar a �rea Administrativa para alterar suas configura��es. Voc� pode selecionar o link acima para modificar seu Banco de dados.";
$str[cmanage] = "Gerenciar Categorias";
$str[fmanage] = "Gerenciar �tens";
$str[cumanage] = "Gerenciar Campos Extras";
$str[lmanage]= "Gerenciar Termo";
$str[amanage] = "Gerenciar Contas Admin";
$str[csettings] = "Alterar Configura��es";
$str[asettings] = "Configura��es de sua Conta";
$str[utils] = "Utilidades";
$str[aminfo] = "Voc� pode usar esta se��o para adicionar, apagar ou alterar contas de acesso administrativo.";
$str[aadmin] = "Add Admin";
$str[eadmin] = "Editar Admin";
$str[dadmin] = "Deletar Admin";
$str[un] = "Usu�rio";
$str[uninfo] = "Digite aqui o nome do novo usu�rio para a nova conta";
$str[aemail] = "E-mail Admin";
$str[aemailinfo] = "Digite o endere�o de E-mail aqui";
$str[apass] = "Senha";
$str[apassinfo] = "Digite aqui a senha para a nova conta. Pode ser alterada a qualquer hora";
$str[aeditperm] = "Editar Permiss�es Admin";
$str[aeditperminfo] = "Selecione se deseja que o novo usu�rio possa alterar, adicionr ou apagar outros usu�rios.";
$str[yes] = "Sim";
$str[no] = "N�o";
$str[aadderror] = "J� existe um usu�rio com este nome $form[username]";
$str[adminadded] = "O Usu�rio <i>$form[username]</i> foi adicionado!";
$str[changepass] = "Mudar Senha";
$str[newpass] = "Nova Senha";
$str[editerror] = "Voc� n�o selecionou usu�rio para editar!";
$str[infochanged] = "As informa��es do usu�rio foram alteradas!";
$str[passchanged] = "A senha do usu�rio foi alterada!";
$str[delerror] = "Voc� n�o selecionou usu�rio para apagar!";
$str[deleted] = "O usu�rio selecionado foi apagado.";
$str[cmaninfo] = "Voc� pode usar esta se��o para adicionar, alterar, ordenar ou apagar categorias. Para adicionar �tens, voc� tem que ter ao menos uma categoria criada. Clique no link abaixo para gerenciar suas categorias.";
$str[acat] = "Add Categoria";
$str[ecat] = "Editar Categoria";
$str[dcat] = "Deletar Categoria";
$str[rcat] = "Re ordenar Categorias";
$str[catadded] = "Sua nova categoria, <i>$form[name]</i> foi adicionada!";
$str[catname] = "Nome da Categoria";
$str[catnameinfo] = "Este ser� o nome da categoria.";
$str[catdesc] = "Descri��o da Categoria";
$str[catdescinfo] = "Esta � a descri��o geral dos �tens da Categoria";
$str[catparent] = "Categoria de Refer�ncia";
$str[catparentinfo] = "Se quer que esta seja uma sub categoria, selecione qual seria a categoria principal.";
$str[none] = "Nenhum";
$str[catedited] = "Sua Categoria, <i>$form[name]</i> foi editada!";
$str[delfiles] = "Apagar �tens da Categoria?";
$str[catsdeleted] = "As Categorias selecionadas foram apagadas.";
$str[cdelerror] = "Voc� n�o selecionou nenhuma Categoria para apagar!";
$str[rcatinfo] = "Voc� pode re ordenar as Categorias mudando a ordem que aparecer�o na p�gina principal. Para reordenar as Categorias, escolha a ordem que deseja alterando os n�meros. 1 ser� mostrada primeiro, 2 ser� mostrada em segundo, ect. Isto n� afeta sub categorias.";
$str[rcatdone] = "As Categorias foram re ordenadas!";
$str[custominfo] = "Voc� pode usar os campos personalizados da �rea Administrativa do paFileDB para adicionar, editar e apagar os campos. Voc� pode usar estes campos para adicionar mais informa��es ao �tem. Por exemplo, se quiser informar o tamanho de um arquivo, voc� pode adicionar esta nova op��o.";
$str[afield] = "Add Campo";
$str[efield] = "Editar Campo";
$str[dfield] = "Deletar Campo";
$str[fieldname] = "Nome do Campo";
$str[fieldnameinfo] = "Este � o nome do campo, por exemplo 'Tamanho do Arquivo'";
$str[fielddesc] = "Descri��o do Campo";
$str[fielddescinfo] = "Esta � a descri��o do Campo, por exemplo 'Tamanho do Arquivo em Megabytes'";
$str[fieldadded] = "Seu novo Campo, <i>$form[name]</i> foi adicionado!";
$str[fieldedited] = "Seu novo Campo, <i>$form[name]</i> foi editado!";
$str[dfielderror] = "Voc� n�o selecionou nenum Campo para Apagar!";
$str[fieldsdel] = "Seus Campos selecionados foram apagados!";
$str[fmanageinfo] = "Voc� pode usar a se��o de Gerenciamento de �tens do paFileDB para adicionar, editar ou apagar �tens.<br><b>Dica:</b> Para as opera��es, tenha certeza que est� logado com senha administrativa e navegue normalmente pelas categorias.";
$str[afile] = "Add �tem";
$str[efile] = "Editar �tem";
$str[dfile] = "Deletar �tem";
$str[upload] = "Enviar �tem";
$str[uploadinfo] = "Enviar este arquivo";
$str[uploaderror] = "O arquivo $userfile_name j� existe! Por favor renomeie-o e tente novamente.";
$str[uploaddone] = "O arquivo $userfile_name foi enviado! A URL para o arquivo �";
$str[uploaddone2] = "Clique aqui para colocar esta URL no campo de URL.";
$str[filename] = "Nome do �tem";
$str[filenameinfo] = "Este � o nome do �tem que voc� est� adicionando, como 'paFileDB 3' ou 'Minha Figura.'";
$str[filesd] = "Descri��o Abreviada";
$str[filesdinfo] = "Esta � a descri��o abreviada do �tem. Ser� mostrada na p�gina que lista os �tens da categoria, ent�o esta descri��o tem que ser curta";
$str[fileld] = "Descri��o Longa";
$str[fileldinfo] = "Esta � a descri��o longa do �tem. Ser� mostrado na p�gina exclusiva do �tem";
$str[filecreator] = "Criador/Autor";
$str[filecreatorinfo] = "Este o nome de quem criou o �tem.";
$str[fileversion] = "Vers�o do �tem";
$str[fileversioninfo] = "Esta � a vers�o do �tem, como 3.0 ou 1.3 Beta";
$str[filess] = "Screenshot URL";
$str[filessinfo] = "Esta � a URL para a imagem do �tem. Por exemplo, se voc� est� adicionado uma skin de Winamp, esta dever� ser a URL para a imagem da skin no Winamp";
$str[filedocs] = "Documenta��o/URL do Manual";
$str[filedocsinfo] = "Esta � a URL da Documenta��o ou Manual do �tem";
$str[fileurl] = "URL do Download";
$str[fileurlinfo] = "Esta � a URL do �tem a ser baixado. Voc� pode digitar manualmente ou <a href=\"javascript:NewWindow('pafiledb.php?action=admin&ad=file&file=upload','fileupload','600','450','custom','front');\">Enviar o arquivo ao servidor</a>";
$str[filepi] = "Post Icon";
$str[filepiinfo] = "Voc� pode escolher um post icon para o �tem. O post icon ser� mostrado ao lado do �tem.";
$str[filecat] = "Categoria";
$str[filecatinfo] = "Esta � a Categoria a qual pertence o �tem.";
$str[filelicense] = "Licen�a";
$str[filelicenseinfo] = "Este � o Termo que deve ser acordado antes do Download.";
$str[filepin] = "�tem Pin";
$str[filepininfo] = "Escolha se o �tem ser� discriminado como pin ou n�o. Os �tens Pin ser�o sempre mostrados no topo da lista.";
$str[fileadded] = "Seu novo �tem, <i>$form[name]</i> foi adicionado!";
$str[fileedited] = "Seu �tem, <i>$form[name]</i> foi editado!";
$str[fderror] = "Voc� n�o selecionou nenhum �tem para ser apagado!";
//You have reached Line 200. PHP Arena is not responsible for deaths related to sitting in front of your computer for a long time while translating this file.
$str[filesdeleted] = "Os �tens selecionados foram apagados!";
$str[lmanageinfo] = "Voc� pode usar a se��o de Gerenciamento de Licen�a do paFileDB para adicionar, editar e deletar o Termo de Download. Voc� pode adicionar uma licen�a para um �tem. Se o �tem tem uma licen�a, o usu�rio tem que aceit�-la antes de efetuar o download.";
$str[alicense] = "Adicionar Licen�a";
$str[elicense] = "Editar Licen�a";
$str[dlicense] = "Deletar Licen�a";
$str[lname] = "Nome da Licen�a";
$str[ltext] = "Texto da Licen�a";
$str[licenseadded] = "Sua nova Licen�a, <i>$form[name]</i> foi adicionada!";
$str[licenseedited] = "Sua licen�a, <i>$form[name]</i> foi editada!";
$str[lderror] = "Voc� n�o selecionou nenhuma licen�a para deletar!";
$str[ldeleted] = "As Licen�as selecionadas foram apagadas.";
$str[login] = "Login";
$str[username] = "Nome";
$str[password] = "Senha";
$str[loggedin] = "Voc� efetuou o Login com sucesso. <a href=\"pafiledb.php?action=admin&ad=main\">Clique Aqui</a> para acessar a �rea Administrativa.";
$str[loginerror] = "Voc� digitou o Nome ou Senha Incorretos!";
$str[loggedout] = "Voc� fez o Logout com Sucesso.";
$str[changeemail] = "Mudar endere�o de E-mail";
$str[emailad] = "Endere�o de E-mail";
$str[confpass] = "Confirmar Senha";
$str[nopermission] = "Desculpe, voc� n�o tem permiss�o para usar esta �rea.";
$str[emailchanged] = "Seu E-mail foi alterado!";
$str[changepasserror] = "Sua senha e confirma��o de senha n�o conferem. Volte e tente novamente";
$str[yourpasschanged] = "Sua Senha foi alterada!";
$str[dbname] = "Nome da Database";
$str[dbnameinfo] = "Este � o nome da database, como 'Windows Registry Hacks'";
$str[dbdesc] = "Descri��o da Database";
$str[dbdescinfo] = "Esta � a descri��o dos �tens contidos na database, como 'Registry hacks that make Windows useful";
$str[dburl] = "URL da Database";
$str[dburlinfo] = "Este � o diret�rio onde paFileDB est� instalado";
$str[topnum] = "Top �tens";
$str[topnuminfo] = "Este � o n�mero de �tens que ser�o mostrados na tabela de Top Download �tens";
$str[hpurl] = "URL da Homepage";
$str[hpurlinfo] = "Esta � a URl de sua Homepage";
$str[nfdays] = "Dias para Novos";
$str[nfdaysinfo] = "Quantos dias ser� mostrado o arquivo como Novo �tem. Se indicado 5, ent�o todos os �tens adicionados a menos de 5 dias ser�o indicados como Novos �tens";
$str[timeoffset] = "Fuso Hor�rio";
$str[timeoffsetinfo] = "Este � o Fuso Hor�rio. Por exemplo, se o servidor est� na zona Eastern time mas voc� quer o hor�rio em Central Time, voc� tem que mudar para -1";
$str[tz] = "Zona de Hor�rio";
$str[tzinfo] = "Esta � a Zona de Hor�rio que ser� exibida";
$str[header] = "Header";
$str[headerinfo] = "O arquivo header � mostrado no cabe�alho dos resultados do paFileDB";
$str[footer] = "Footer";
$str[footerinfo] = "O arquivo footer � o rodap� dos resultados do paFileDB.";
$str[styleset] = "Estilo";
$str[stylesetinfo] = "Escolha o Estilo que quer usar";
$str[stats2] = "Mostrar Estat�sticas";
$str[statsinfo] = "Escolha se quer mostrar as estat�sticas de execu��o do script (N�mero total de MySQL queries e quanto tempo demorou para executar o script)";
$str[settingschanged] = "As configura��es do paFileDB foram alteradas!";
$str[lang] = "Arquivo de Linguagem";
$str[langinfo] = "Selecione a Linguagem para usar em paFileDB.";

//Start Beta 2.1 Language File
$str[settings] = "Settings";
$str[pafdbsettings] = "paFileDB Settings";

//Start Beta 3 Language File 
$str[sortby] = "Listar por"; 
$str[sort] = "Listar"; 
$str[name] = "Nome"; 
$str[bdb] = "Backup de Database"; 
$str[rdb] = "Restaurar Database"; 
$str[rdbinfo] = "Voc� pode restaurar a Database do pafiledb3 criada anteriormente. <b>NOTA:</b> Isso ir� DELETAR tudo o que existe na Database atual, inclusive informa��es administrativas!<p>Escolha um arquivo para restaurar:"; 
$str[rdbdone] = "Sua Database foi restaurada! Se as informa��es administrativas da database restaurada e sua antiga s�o diferentes, voc� pode fazer o login novamente, voc� deve criar o login novamente."; 
$str[home] = "Homepage";


?>