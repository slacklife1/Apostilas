<?php
/*
  paFileDB 3.0
  �2001 PHP Arena
  Written by Todd
  todd@phparena.uni.cc
  http://www.phparena.uni.cc
  Keep all copyright links on the script visible
  Please read the license included with this script for more information.

  ########## 
  #paFileDB 3.0 Language File 
  #Swedish/Svenska 
  #�versatt av Jakob Naredi - WannaSurf.to 
  ########## 

  ##########	
  #If you are translating this file, DO NOT translate anything in brackets, such as {something}, any variables ($something) or arrays #($something[somethingelse]), or HTML tags (<something></something>) or else parts of the script will not work
  #Also, do not delete any lines in this script
  ##########

*/

//Start Beta 2 Language File
$str[time] = "Alla tider �r";
$str[power] = "Skapat av";
$str[exectime] = "Laddningstid";
$str[numqueries] = "MySQL Queries anv�nds";
$str[adminops] = "Admins val";
$str[mainpage] = "F�rstasida";
$str[addcat] = "L�gg till kategori";
$str[editcat] = "�ndra kategori";
$str[delcat] = "Ta bort kategori";
$str[ordercat] = "�ndra ordning bland kategorierna";
$str[category] = "Kategori";
$str[files] = "Filer";
$str[jump] = "Kategorimeny";
$str[logged] = "Inloggad som";
$str[admincenter] = "Admin Center";
$str[logout] = "Logga ut";
$str[file] = "Fil";
$str[date] = "Lades till den";
$str[rating] = "Betyg";
$str[dls] = "Nerladdningar";
$str[email] = "E-mail filen till en kompis";
$str[emailinfo] = "Om du tror att din kompis gillar den h�r filen, kan du fylla i de h�r f�lten s� kommer informationen om den att skickas till din kompis!";
$str[yname] = "Ditt namn";
$str[yemail] = "Din E-mail";
$str[fname] = "Din kompis namn";
$str[femail] = "Din kompis E-mail";
$str[esub] = "Rubrik p� ditt E-mail";
$str[etext] = " Texten i ditt E-mail";
$str[defaultmail] = "Jag tror att du �r intreserad av att ladda ner en fil som finns p�";
$str[semail] = "Skicka E-mail";
$str[msg] .= "Hej $friend[name],\n";
$str[msg] .= "$email[message]\n\n";
$str[msg] .= "----------\n";
$str[msg] .= "Det h�r mailet skickades via \"{dbname}\" fil databas. Webmastern f�r \"{dbname}\" fil databas tar inget ansvar f�r mailen skickade d�rifr�n.";
$str[econf] = "Tack! Ditt mail skickades utan problem till $friend[name]'s e-mail addres.";
$str[editfile] = "�ndra fil";
$str[deletefile] = "Ta bort fil";
$str[desc] = "Beskrivning";
$str[creator] = "Skapare";
$str[version] = "Version";
$str[scrsht] = "Screenshot";
$str[docs] = "Dokumentation";
$str[lastdl] = "Last Download";
$str[never] = "Nyare";
$str[votes] = "r�ster";
$str[download] = "Ladda ner filen";
$str[rate] = "Betygs�tt filen";
$str[license] = "License Avtal";
$str[licensewarn] = "Du m�ste godk�nna det h�r license avtalet innan du kan forts�tta";
$str[iagree] = "Jag godk�nner";
$str[dontagree] = "Jag godk�nner inte";
$str[rerror] = "Tyv�rr, du har redan betygsatt den h�r filen.";
$str[rateinfo] = "Du kommer att betygs�tta <i>{filename}</i>. Fyll bara i vilket betyg du vill ge den. 1 �r s�mst och 10 �r b�st.";
$str[rconf] = "Du har gett filen <i>{filename}</i> ett betyg p� {rate}. Det ger den ett nytt betyg p� $nrating {newrating}/10.";
$str[stats] = "Statistik";
$str[statstext] .= "Det finns nu  $num[files] filer i  $num[cats] kategorier<br>";
$str[statstext] .= "Den �lsta filen �r <a href=\"pafiledb.php?action=file&id= $oldest[file_id]\"> $oldest[file_name]</a><br>";
$str[statstext] .= "Den senaste filen �r <a href=\"pafiledb.php?action=file&id= $newest[file_id]\"> $newest[file_name]</a><br>";
$str[statstext] .= "Den minst popul�ra filen baserat p� betyg �r <a href=\"pafiledb.php?action=file&id= $lpopular[file_id]\"> $lpopular[file_name]</a> med ett betyg p� $least/10<br>";
$str[statstext] .= "Den mest popul�ra filen baserat p� betyg �r <a href=\"pafiledb.php?action=file&id= $popular[file_id]\"> $popular[file_name]</a> med ett betyg p�  $most/10<br>";
$str[statstext] .= "Den minst popul�ra filen baserat p� antalet nedladdningar �r <a href=\"pafiledb.php?action=file&id= $leastdl[file_id]\"> $leastdl[file_name]</a> med  $leastdl[file_dls] nedladdningar<br>";
$str[statstext] .= "Den mest popul�ra filen baserat p� antalet nedladdningar �r <a href=\"pafiledb.php?action=file&id= $mostdl[file_id]\"> $mostdl[file_name]</a> med  $mostdl[file_dls] nedladdningar<br>";
$str[statstext] .= "Den totala m�ngden nedladdningar �r  $totaldls[0] <br>";
$str[statstext] .= "Det genomsnittliga betyget �r  $avg/10<br>";
$str[statstext] .= "Det genomsnittliga antalet neddladningar per fil �r $avgdls<br>";
$str[search] = "S�k";
$str[results] = "Resultat f�r";
$str[nomatches] = "Sorry, no matches were found for";
$str[matches] = "matches were found for";
$str[sfor] = "S�k efter";
$str[viewall] = "Se alla filer";
$str[vainfo] = "Se alla filer i databasen";
$str[next] = "N�sta";
$str[prev] = "F�rra";
$str[pagenums] = "Sidor";
//You have reached Line 100. If you're not tired now, you will be soon.
$str[acinfo] = "V�lkommen till paFileDB 3 Admin Center. Du kan anv�nda Admin Center f�r att editera fildatabasen och och �ndra paFileDB inst�llningar. V�lj en l�nk nedan f�r att editera databasen.";
$str[cmanage] = "Kategori editering";
$str[fmanage] = "Fil edtitering";
$str[cumanage] = "Egna f�llt editering";
$str[lmanage]= "License editering";
$str[amanage] = "Admin konton editering";
$str[csettings] = "�ndra inst�llningar";
$str[asettings] = "Ditt kontos inst�llningar";
$str[utils] = "Anv�ndbarhet";
$str[aminfo] = "Du kan anv�nda den h�r avdelningen av admin center f�r att l�gga till, �ndra, eller ta bort extra admin konton.";
$str[aadmin] = "L�gg till Admin";
$str[eadmin] = "�ndra Admin";
$str[dadmin] = "Ta bort Admin";
$str[un] = "Anv�ndarnamn";
$str[uninfo] = "Fyll i anv�ndarnamnet f�r det nya kontot h�r";
$str[aemail] = "E-mail";
$str[aemailinfo] = "Fyll i den admin's e-mail addres h�r";
$str[apass] = "L�senord";
$str[apassinfo] = "Fyll i l�senordet f�r det nya admin kontot h�r";
$str[aeditperm] = "�ndra Adminkontots r�ttigheter";
$str[aeditperminfo] = "V�lj om du vill att den nya admin kommer att kunna l�gga till, �ndra eller ta bort andra admin konton.";
$str[yes] = "Ja";
$str[no] = "Nej";
$str[aadderror] = "Det finns redan ett Admin konto med anv�ndarnamnet $form[username]";
$str[adminadded] = "Admin kontot <i>$form[username]</i> har lagts till!";
$str[changepass] = "�ndra l�senord";
$str[newpass] = "Nytt l�senord";
$str[editerror] = "Du valde inte n�got admin konto att �ndra!";
$str[infochanged] = "Adminkontots information har �ndrats!";
$str[passchanged] = "Adminkontots l�senord har �ndrats!";
$str[delerror] = "Du valde inte n�gra konton att ta bort!";
$str[deleted] = "De konton du valde har tagits bort.";
$str[cmaninfo] = "Du kan anv�nda kategori editering i Admin Center f�r att l�gga till, �ndra, ta bort och �ndra ordning p� kategorier. F�r att kunna l�gga till filer i databasen m�ste du minst ha en kategori. Du kan v�lja en l�nk nedan f�r att editera kategorier.";
$str[acat] = "L�gg till en kategori";
$str[ecat] = "�ndra en kategori";
$str[dcat] = "Ta bort en kategori";
$str[rcat] = "�ndra ordningen p� kategorierna";
$str[catadded] = "Din nya kategori, <i>$form[name]</i> har lagts till!";
$str[catname] = "Kategorinamn";
$str[catnameinfo] = "Detta kommer att bli namnet p� kategorin.";
$str[catdesc] = "Kategoribeskrivning";
$str[catdescinfo] = "Detta �r beskrivningen av kategorin";
$str[catparent] = "Huvudkategori";
$str[catparentinfo] = "Om du vill att den h�r kategorin ska vara en underkategori, v�lj vilken kategori som den ska vara en underkategori till.";
$str[none] = "Ingen";
$str[catedited] = "Din kategori, <i>$form[name]</i> har editerats!";
$str[delfiles] = "Ta bort filer i kategori?";
$str[catsdeleted] = "Kategorin du valde har tagits bort.";
$str[cdelerror] = "Du valde inga kategorier att ta bort!";
$str[rcatinfo] = "Du kan �ndra ordningen p� kategorierna som de visas p� f�rstasidan. F�r att �ndra ordningen p� kategorierna, V�lj i vilken ordning de ska komma. 1 kommer att visas f�rst, 2 kommer att visas tv�a, ect. Detta har ingen inverkan p� underkategorier.";
$str[rcatdone] = "Kategoriernas ordning �ndrades!";
$str[custominfo] = "Du kan anv�nda egna f�llt avdelningen p� paFileDB admin center f�r att l�gga till, �ndra och ta bort egna f�llt. Du kan anv�nda egna f�llt f�r att f� ut mer information om filen. T.ex. kan du l�gga till ett f�llt d�r du ber�ttar om filstroleken, du kan skapa ett nytt f�llt och sen g� in i �ndra/L�gg till fil och sen skriva i informationen d�r.";
$str[afield] = "L�gg till f�llt";
$str[efield] = "�ndra f�llt";
$str[dfield] = "Ta bort f�llt";
$str[fieldname] = "F�lltets namn";
$str[fieldnameinfo] = "Det h�r �r namnet f�r f�lltet, t.ex. filstorlek'";
$str[fielddesc] = "F�llt beskrivning";
$str[fielddescinfo] = "Det h�r �r beskrivningen av f�ltet, t.ex. Filstorlek i mb.'";
$str[fieldadded] = "Ditt nya f�llt, <i>$form[name]</i> har lagts till!";
$str[fieldedited] = "Ditt f�llt, <i>$form[name]</i> har editerats!";
$str[dfielderror] = "Du har inte valt n�gpt f�llt att ta bort!";
$str[fieldsdel] = "Ditt f�lt har tagits bort!";
$str[fmanageinfo] = "Du kan anv�nda fil editerings avdelningen p� paFileDB admin center F�r att l�gga till, �ndra eller ta bort filer.<br><b>Tips:</b> F�r att enkelt l�gga till , �ndra eller ta bort en fil, g� till den kategorin d�r du normalt skulle ha laddat ner filen. D�r dyker det d� upp l�nkar.";
$str[afile] = "L�gg till fil";
$str[efile] = "Edit File";
$str[dfile] = "Ta bort fil";
$str[upload] = "Ladda upp fil";
$str[uploadinfo] = "Ladda upp den h�r filen";
$str[uploaderror] = "Filen $userfile_name finns redan, byt namn och prova igen.";
$str[uploaddone] = "Filen $userfile_name haar laddats upp! UELn till filen �r";
$str[uploaddone2] = "Klicka h�r f�r att klistra in URLn till l�gg till f�ltet.";
$str[filename] = "Fil namn";
$str[filenameinfo] = "Det h�r �r namnet p� filen du l�gger till, t.ex 'paFileDB 3' eller 'Bilspelet.'";
$str[filesd] = "Kort beskrivning";
$str[filesdinfo] = "Det h�r �r den korta beskrivningen p� spelet. Den kommer att vissas p� kategorisidan tillsammans med alla andra filer, s� den h�r beskrivningen ska vara kort";
$str[fileld] = "L�ng beskrivning";
$str[fileldinfo] = "Det h�r �r en l�ngr beskrivning av spelet. Den kommer bara att visa p� filens egna sida. S� den kan vara l�ngre.";
$str[filecreator] = "Skapare";
$str[filecreatorinfo] = "Det h�r �r namnet p� skaparen av filen.";
$str[fileversion] = "Filen version";
$str[fileversioninfo] = "Det h�r �r versionen av filen, t.ex. 3.0 or 1.3 Beta";
$str[filess] = "Screenshot URL";
$str[filessinfo] = "Det h�r �r URLn till en screenshot p� filen.";
$str[filedocs] = "Dokumentation/Manual URL";
$str[filedocsinfo] = "Det h�r �r URLn till dockumentationen eller manualen f�r filen";
$str[fileurl] = "Nerladdnings URL";
$str[fileurlinfo] = "Det h�r �r URLn till st�llet d�r filen kan laddas ner, du kan antingen fylla i adressen eller <a href=\"javascript:NewWindow('pafiledb.php?action=admin&ad=file&file=upload','fileupload','600','450','custom','front');\">ladda upp filen till servern</a>";
$str[filepi] = "Ikon";
$str[filepiinfo] = "Du kan v�lja en ikon som visas bredvid filens namn i kategorin.";
$str[filecat] = "Kategori";
$str[filecatinfo] = "H�r v�ljer du i vilken kategori filen ska listas.";
$str[filelicense] = "License";
$str[filelicenseinfo] = "H�r v�ljer du vilket license avtal som m�ste godk�nnas innan filen laddas upp.";
$str[filepin] = "Topp fil";
$str[filepininfo] = "V�lj om du vill att filen ska vara en toppfil. Toppfiler visas alltod l�ngst upp.";
$str[fileadded] = "Din nya fil, <i>$form[name]</i> har lagts till!";
$str[fileedited] = "YDin fil, <i>$form[name]</i> har �ndrats!";
$str[fderror] = "Du valde ingen fil att ta bort!";
//You have reached Line 200. PHP Arena is not responsible for deaths related to sitting in front of your computer for a long time while translating this file.
$str[filesdeleted] = "The files you selected have been deleted!";
$str[lmanageinfo] = "You can use the license management section of the paFileDB admin center to add, edit, and delete license agreements. You can select a license for a file on the file add or edit page. If a file has a license agreement, a user will have to agree to it before downloading the file.";
$str[alicense] = "Add License";
$str[elicense] = "Edit License";
$str[dlicense] = "Delete License";
$str[lname] = "License Name";
$str[ltext] = "License Text";
$str[licenseadded] = "Your new license agreement, <i>$form[name]</i> has been added!";
$str[licenseedited] = "Din license, <i>$form[name]</i> har �ndrats!";
$str[lderror] = "Du valde ingen license att ta bort!";
$str[ldeleted] = "Licenserna som du valde har tagits bort.";
$str[login] = "Logga in";
$str[username] = "Anv�ndarnamn";
$str[password] = "L�senord";
$str[loggedin] = "Du har loggats in. <a href=\"pafiledb.php?action=admin&ad=main\">Klicka h�r</a> f�r att komma till admin center.";
$str[loginerror] = "Du har fyllt i ett ogiltigt anv�ndarnamn eller l�senord!";
$str[loggedout] = "Du har loggats ut.";
$str[changeemail] = "�ndra E-mail Addres";
$str[emailad] = "E-mail Addres";
$str[confpass] = "Repetera l�senord";
$str[nopermission] = "Tyv�rr har du inte till�telse att bes�ka den h�r avdelningen.";
$str[emailchanged] = "Din e-mail addres har �ndrats!";
$str[changepasserror] = "Dina l�senord du fyllde i matchade inte. G� tillbaka och �ndra dem.";
$str[yourpasschanged] = "Ditt l�senord har �ndrats!";
$str[dbname] = "Databas  namn";
$str[dbnameinfo] = "Det h�r �r namnet p� databasen, t.ex. 'Windows program'";
$str[dbdesc] = "Databas beskrivning";
$str[dbdescinfo] = "H�r �r beskrivningen �ver filerna i data basen, t.ex. 'Nyttiga Windows program";
$str[dburl] = "Databas URL";
$str[dburlinfo] = "Det h�r �r URLn st�llet d�r paFileDB �r instalerat";
$str[topnum] = "Topp Nummer";
$str[topnuminfo] = "H�r v�ljer du hur m�nga filer som ska visas i Topp X nedladdningar listan";
$str[hpurl] = "Hemside URL";
$str[hpurlinfo] = "H�r �r adressen till din hemsida";
$str[nfdays] = "Nya filer dagar";
$str[nfdaysinfo] = "hur m�nga dagar kommer dina filer att markeras med en NY FIL ikon?";
$str[timeoffset] = "Tidszone";
$str[timeoffsetinfo] = "Om servern �r placerad i ett nnat land kan du h�r �ndra tidsinst�llningarna s� att de passar in p� din sida.";
$str[tz] = "Tids Zone";
$str[tzinfo] = "H�r �r tidszonen som kommer att anv�ndas";
$str[header] = "Header";
$str[headerinfo] = "Header filen kommer att visas f�re paFileDB koden visas";
$str[footer] = "Footer";
$str[footerinfo] = "Footer filen kommer att visas efter paFileDB koden visas.";
$str[styleset] = "Style inst�llning";
$str[stylesetinfo] = "V�lj vilken style som du vill anv�nda";
$str[stats2] = "Visa statistik";
$str[statsinfo] = "V�lj om du vill visa laddningstiderna f�rscriptet (Totalt antal MySQL queries och hur l�ng tid det tog f�r scriptet att k�ra)";
$str[settingschanged] = "Dina paFileDB inst�llningar har �ndrats!";
$str[lang] = "Spr�k fil";
$str[langinfo] = "V�lj vilket spr�k som ska anv�ndas.";

//Start Beta 2.1 Language File
$str[settings] = "Inst�llningar";
$str[pafdbsettings] = "paFileDB inst�llningar";

//Start Beta 3 Language File
$str[sortby] = "Sortera efter"; 
$str[sort] = "Sort"; 
$str[name] = "Namn"; 
$str[bdb] = "G�r en Backup"; 
$str[rdb] = "L�gg tillbaks databas"; 
$str[rdbinfo] = "Du kan l�gga upp en backup som du har gjort tidigare. <b>OBS:</b> Det kommer att ta bort allt som finns nu, inklusive admin sektionen!<p>V�lj en filen som backupen ligger p�:"; 
$str[rdbdone] = "Din gammla databas har lagts upp igen! Om informationen om admin �r anno�unda i den h�r databasen m�ste du logga in p� nytt."; 
$str[home] = "Hemsida"; 
?>