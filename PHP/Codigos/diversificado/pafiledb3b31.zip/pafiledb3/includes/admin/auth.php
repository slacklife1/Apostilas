<?php
/*
  paFileDB 3.0
  �2001 PHP Arena
  Written by Todd
  todd@phparena.uni.cc
  http://www.phparena.uni.cc
  Keep all copyright links on the script visible
  Please read the license included with this script for more information.
*/
if (!empty($user)) {
	$admin = $pafiledb_sql->query($db, "SELECT * FROM $db[prefix]_admin WHERE admin_username = '$user'", 1);
	$adminip = getenv ("REMOTE_ADDR");
	$md5ip = md5($adminip);
	if ($pass == $admin[admin_password] && $md5ip == $ip) {
		$logged = 1;
	}
} else {
	$logged = 0;
}
?>