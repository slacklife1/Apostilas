<?php

// Turn on output buffering
// see readme.txt for site monitoring tools

ob_start();

include('sendsms.php');

ob_end_clean();

?>