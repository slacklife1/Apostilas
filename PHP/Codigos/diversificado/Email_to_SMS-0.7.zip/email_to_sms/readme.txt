$Date: 2002/05/17 01:09:26 $
$Revision: 1.7 $

+--------------------------+
| EMAIL -> SMS 0.7 README  |
+--------------------------+
by: Keyvan Minoukadeh - keyvan@k1m.com - http://www.k1m.com
Last update: 17-May-2002

-----------
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
-----------

******************
* INTRO
******************
PHP Script intended to be run every x minutes / hours (using something like 
cron) to check a POP3 account for email and forward on to mobile
using free web based SMS services (lycos.co.uk, uboot.com, genie.co.uk, sms.ac)

This script uses the following PHP classes:
- POP3 - http://www.thewebmasters.net/php/POP3.phtml - by: CDI
- Mime_email_class 0.5 - Marc Logemann - http://www.logemann.info/
- Config Reader 0.1 - http://www.k1m.com/
It will also require you to download SMS Web Sender class:
- SMS Web Sender 0.4 - http://www.k1m.com/scripts/sms_web_sender/
(you will need to create an 'sms_web_sender' directory and copy the files into it)

Linux users: You can also setup an email alias piping straight to the script
which will not require cron, pop3 access, but will speed up the arrival
of messages to your mobile.


******************
* FEATURES
******************
+ Leave mail on server (stores and compares UIDL numbers)
+ Email alias piping (have your email processed the second it arrives)
+ Specify mobile number in subject line (if you'd like to sms others through email)
+ Random SMS site to send through (specify as many accounts as you line in config)
+ Basic filtering of the To: header to reduce Spam
+ and more...


******************
* QUICK START
******************
1. Extract files
2. Edit config.conf with your own settings
3. Upload to server (if not already on there)
4. chmod stats.txt so it's readable and writable (666)
5. Access sendsms.php through the browser to make sure it's working
6. Set up scheduling


******************
* FAQ
******************
-- WHAT IS IT?
 A PHP script to check an email account through POP3 and forward messages
 as SMS to a mobile number using a number of free SMS sending web sites.

-- WHY USE IT?
 Because you want to know when you've got mail and maybe even see a bit of the
 message.

-- IS IT RELIABLE?
 SMS DELIVERY?
  This depends on the site being used, if the login and send process changes
  in any way for a particular site, it's very likely that your message won't
  be delivered.  If you're looking for a reliable SMS delivery service, you're
  going to have to look elsewhere (and probably pay for it).
 THE SCRIPT ITSELF?
  Unfortunately I haven't been able to test it as much as I'd liked to,
  if you come across any problems, let me know.

-- HOW CAN I SET THE SCRIPT TO RUN EVERY X MINUTES/HOURS
 If you're using a linux system, add a cron entry similar to:
 * * * * * wget -O /dev/null http://www.domain.com/email_to_sms/sendsms.php
 the above will check every minute
 0 * * * * wget -O /dev/null http://www.domain.com/email_to_sms/sendsms.php
 the above will check every hour
 */5 * * * * wget -O /dev/null http://www.domain.com/email_to_sms/sendsms.php
 the above will check every 5 minutes
 If you have PHP compiled as CGI you can also call the script directly rather
 than using wget/lynx/curl/etc...

-- HOW CAN I SET AN ALIAS TO PIPE STRAIGHT TO THE SCRIPT?
 I've only tested this on systems running Postfix and Exim:
 1. First make sure piping is supported by your MTA and enabled on the system.
 2. Edit sendsms_cmd.php and make sure the first line points to your PHP executable
 3. Edit config.conf and make sure output is off (output = 'pop_none')
 4. chmod sendsms_cmd.php so it's executable.
 5. follow steps below...

 Postfix (and I assume sendmail will be the same):
  Edit your aliases file (possibly: /etc/postfix/aliases)
  and add an entry similar to:
  sms:       "|/home/domain/email_to_sms/sendsms_cmd.php"

 Exim:
  Edit your valiases file (possibly: /etc/valiases/)
  and add an entry similar to:
  sms@yourdomain.com: |/home/domain/email_to_sms/sendsms_cmd.php

 NOTE: I'm no expert on MTA software, I know there are other ways you can have
 the email message piped to the  script (.forward, procmail, etc..) I've not
 had time to test those, so can't offer any sort of help on that.

-- CAN I GET RID OF THE TAGS/ADS AT THE BOTTOM/TOP OF THE MESSAGE?
 No.  That's added automatically by the site sending the message, and probably
 helps keep the service free.
 To have clean messages you're probably going to have pay for a SMS sending
 service.

-- I HAVE A PROBLEM GETTING THE SCRIPT TO RUN/CHECK EMAIL/SEND SMS/ETC...
 Please post a detailed summary of the problem on the forum:
 http://www.k1m.com/forum/ in the relevant script section.
 Also, please check the site to see which versions of PHP the script has been
 tested on.


******************
* CHANGES
******************
0.7 (17-MAY-2002)  - removed sms_web_sender class (you will need to download
		     it from http://www.k1m.com)
		   - updated to work with latest SMS Web Sender (at time of writing:
		     0.4)
		   - changes in config file: admin_mobile changed to mobile_number
		     and mobile_ccode, sms_additional_login renamed to sms_login,
		     sms_username, sms_password, sms_site removed (use sms_login),
		     see config.conf for more info.

0.6 (31-MAR-2002)  - added sendsms_cmd.php for use with email alias piping
		     using Mime_email_class 0.5 by Marc Logemann
		     message format changes (thanks to David Richards)
		     new config file format

0.55 (15-DEC-2001) - added message format string to global.php
		     to allow you to customise the sms message and
		     small bug fixed.

0.5 (9-DEC-2001)   - using new SMS Web Sender class which supports
		     a number of free SMS sites,
		     basic filtering of the To: header (should help
		     reduce the amount of spam being forwarded on)

0.4 (29-SEP-2001)  - jm_sms version 0.7 included,
		     random mtnsms server chosen to start
		     with incase of problems, sendsms_silent.php
		     added (might help with site monitor 
		     services), error check added for empty
		     config file.

0.3 (8-SEP-2001)   - main new feature: leave mail on server
		     this is an extra variable you can set
		     in global.php and will basically
		     store UIDLs of messages in array and
		     serialize it into config file, each
		     new message will compare it's UIDL
		     to the ones in the array to see if
		     it's already been processed or not.

0.2 (26-AUG-2001)  - fixed timeout problem, and hopefully
		     problem with body of email not being
		     included with SMS.
		     Included check_email.php incase of
		     problems.

0.1 (22-AUG-2001)  - original


Please post any questions, comments, problems, to the forum:
http://www.k1m.com/forum/