<?php

// email to sms files
require_once('functions.php');

// mime parsing
require_once('php_mime_class/mime_email.class.php');

// config reader class files
require_once('config_reader/class.config_base.php');
require_once('config_reader/class.config_reader.php');

// pop3 class files
require_once('pop3/class.POP3.php3');
require_once('kpop3.php');

// sms web sender class files
define('SWS_INCLUDE_PATH', 'sms_web_sender/');
require_once(SWS_INCLUDE_PATH.'class.sms_web_sender.php');

?>