<?php

// an array serialized
// resets it to default values

require_once('includes.php');

// read config file
$c = new config_reader('config.conf');
$c = $c->load();

update_stats($c['stats_file'], array(
				'count'=>0, 
				'process_email'=>1, 
				'admin_mail_sent'=>0, 
				'prev_uidl_array'=>array()));

echo "Done..";

?>
