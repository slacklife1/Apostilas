<?php
require('../../lib/Classes.php');
$Auth = new Auth;
$Auth->log_out();
header("Location: $Auth->referer");
?>
