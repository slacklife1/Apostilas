<?php 
include ('../lib/Classes.php');
$Session = new Session;
$Auth = new Auth;
$Auth->require_auth();
if ($login && $HTTP_POST_VARS[redirect]) {
	header("Location: $HTTP_POST_VARS[redirect]");
}
?>

