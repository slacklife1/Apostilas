<?php
include ('../lib/Classes.php');
$Session = new Session;
?>
<a href="loginform.php">Log in</a>
<a href="scripts/logout.php">Log out</a>
<br>
logged in as : <?php print $login ?>
