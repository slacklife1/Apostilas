<html>
<head>
<title>Log In</title>
<link rel="stylesheet" href="/style.css" type="text/css">
</head>
<body>
<div align="center">
<!--
Thanks are due to the PHPLIB project for the javascripts
below. Their site is located at http://phplib.netuse.de
//-->
<script language="javascript" src="/md5.js"></script>
<script language="javascript">
<!--
function doChallengeResponse() {
str = document.login.acct_name.value + ":" +
MD5(document.login.acct_pass.value) + ":" +
document.login.challenge.value;
document.login.response.value = MD5(str);
document.login.acct_pass.value = "";
document.login.submit();
}
// -->
</script>
<h1>Log In</h1>
<?php if ($failed): ?>
<font color="red"><h2>login failed</h2></font>
<?php endif; ?>
<form name="login" action="<?php echo $REQUEST_URI; ?>" method="post">
<input type="hidden" name="challenge" value="<?php print $this->challenge; ?>">
<input type="hidden" name="response"  value="">
<input type="hidden" name="redirect" value="<?php print $this->redirect; ?>">
<table border="1" cellpadding="1" cellspacing="0">
<tr>
<td>
<table border="0" cellpadding="3" cellspacing="1">
<tr>
<td colspan="2" align="center">
<h3>Log in</h3>
<hr>
<tr>
<th align="right">
Account Name:
<td valign="top">
<input type="text" name="acct_name" maxlength="15" size="20" value="<?php 
	echo $acct_name; ?>">
<tr>
<th align="right">
Password:
<td>
<input type="text" name="acct_pass" maxlength="32" size="20">
<tr>
<td  colspan="2" align="center">
<hr>
<input onClick="doChallengeResponse(); return false;" 
type="submit" name="submitbtn"  class="btn" value=" submit ">
</table>
</table>
</form>
</div>
</body>
</html>
