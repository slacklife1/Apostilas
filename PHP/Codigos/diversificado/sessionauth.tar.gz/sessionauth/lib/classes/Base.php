<?php
class Base {
   // add any functions you want all of your other classes to have
	// to this class, and they all will inherit them.

	var $docroot = "/usr/local/etc/htdocs/"; // you'll want to change this.
 
	function pconnect() {
		
		// change the username and password to fit your site.
		
		mysql_pconnect("localhost", "username", "password") or die (mysql_error());
		mysql_select_db("cookbook") or die (mysql_error());
	}
}
