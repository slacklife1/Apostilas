<?php
class Session  extends Base {
	
	function Session() {
		// Keep the session file somewhere where they won't make a 
		// mess. If this is ever used on Win32, it must be changed.
		session_save_path("/usr/local/tmp/.php");
		
		session_start();
		$this->sess_id = session_id();
	}
	
	function sess_destroy() {
		// if you want anything to happen when you explicitly destroy a 
		// session, ad it here.
		session_destroy();
	}
}
?>
