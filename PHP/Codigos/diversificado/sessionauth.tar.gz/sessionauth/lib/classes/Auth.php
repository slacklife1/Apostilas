<?php

/* Authentication class for PHP4. In order to make this work,
 * you will need the following: PHP version 4, and a MySQL
 * table with your account information. In addition, you need the
 * following files form this package: 
 *	1) Base.php - the base class file. This has the MySQL connection paramaters.
 *	2) MD5.jss - a javacript program that does MD5 encryption. This
 *    is the same program used by PHPLib (http://phplib.netuse.de)
 *		I have also blatently stolen some of their code and used it where noted
 *		on the login form because it is so darn cool. 
 * 3) loginform.php - an example login form page. 
 * 4) login.php - the script that does the logging-in.
 * 5) Session.php - a simple session class
 *
 * If anything is missing you can download it at the following URL:
 *
 *   http://www.junkonline.com/norman/
 *
 * I know my documentation is spotty here, and for that I apologize. I
 * am making this public just so you can get an idea of how to get 
 * sessioning and authentication working in PHP 4. Email me with any 
 * complaints or questions.
*/

class Auth  extends Base {

	var $acct_table = 'members'; // the table your accounts are in
	var $username_col = 'username'; // the name of the username column
	var $pass_col = 'passwd'; // the name of the password column
	var $status_col = 'status'; // name of the account status column
	var $use_permissions = FALSE; // if true use permissions

	function Auth() {
		global $HTTP_REFERER;
		global $HTTP_POST_VARS;
		if (!$HTTP_POST_VARS[redirect]) {
			$this->redirect = $HTTP_REFERER;
		}
		else {
			$this->redirect = $HTTP_POST_VARS[redirect];
		}
	}
	 	
	function require_auth($level="") {
		
		/* level can be any single permission "level" you make up.
		 * permission levels can have any label, but must
		 * be recorded in MySQL as "Y" or "N". For example, a level
		 * might be "admin" or "user," etc. If level is unspecified,
		 * permissions are not checked and any active account can access
		 * the page. 
		*/
		
		global $login;
		global $permissions;
		global $acct_name;
		
		if ($acct_name) {
			$this->authenticate();
		}
		
		elseif (!$login) {
			srand(time());
			$this->challenge = md5(time() + rand(0,10000));
			$this->show_login_form();
		}
		
		elseif ($level && $permissions[$level] != "Y") {
			print "Insufficient permisions!\n";
			exit;
		}
		
		elseif ($level && !$permissions) {
			$this->show_login_form("failed");
			exit;
		}
	}
	
	function authenticate() {
		
		// These are the names of the vars from the login form,
		// so make sure you use them when you create your form 
		// in HTML.
		
		global $acct_name;
		global $acct_pass;
		global $challenge;
		global $response;
		
		$this->pconnect(); // this function comes from the Base.php file

		$lookup = "SELECT * FROM $this->acct_table WHERE $this->username_col = 
			'$acct_name'";
		$result = mysql_query($lookup) or die(mysql_error());
		
		if (mysql_num_rows($result) != 1) {
			$this->show_login_form("failed");
		}
		
		else {
			$a = mysql_fetch_array($result);
			if ($a[$this->status_col] != 'active') die("Account deactivated");
			$this->a = $a;
			if (!$response) { // for non-javascript browsers
				if ($a[$this->pass_col] == $acct_pass) $this->set_login_cookie();
				else $this->show_login_form("failed");
			}
			else { // for javascript browsers
				$check = $a[$this->username_col] . ":" . md5($a[$this->pass_col]) . ":" . 
					$challenge;
				$check = md5($check);
				if ($check == $response) $this->set_login_cookie();
				else {
					$this->show_login_form("failed");
				}
			}
		}
	}

	function set_login_cookie($id="") {
		global $login;
		$login = $this->a[$this->username_col];
		session_register(login);
		if ($this->use_permissions) {
			global $permissions
			$permissions = array( 'admin' => $this->a[admin], 'topsites' => 
				$this->a[topsites],
				'editor' => $this->a[editor], 'moderator' => $this->a[moderator] );
			session_register(permissions);
		}
	}

	function force_login($id, $permission="") {
		$login = $id;
		session_register($login);
		// permissions support to be implemented later
	}
	
	function log_out() {
		session_destroy();
	}
		
	function show_login_form($failed="") {
		global $PHP_SELF;
		global $REQUEST_URI;
		global $redirect;
		$form = $this->docroot . '/include/login.php';
		require($form);
		exit;
	}
}
?>
