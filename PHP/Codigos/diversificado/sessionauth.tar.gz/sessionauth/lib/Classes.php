<?php
$class_root = "./classes";
require("$class_root/Base.php");
require("$class_root/Session.php");
require("$class_root/Auth.php");
?>
